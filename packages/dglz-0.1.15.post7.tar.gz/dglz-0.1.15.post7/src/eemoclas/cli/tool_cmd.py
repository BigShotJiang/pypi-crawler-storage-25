"""``eemo tool`` -- utility tools for non-training operations."""

from __future__ import annotations

import json
from pathlib import Path

import typer

from eemoclas.cli.utils import (
    console,
    print_cli_error,
    print_cli_header,
    print_cli_success,
)

app = typer.Typer(help="工具集：非训练相关的实用工具")


@app.command("data-to-batchs-index")
def data_to_batchs_index(
    manifest: str = typer.Option(
        ..., "--manifest", "-m",
        help="输入 manifest.csv 文件路径",
    ),
    output_dir: str = typer.Option(
        ..., "--output-dir", "-o",
        help="输出目录（不存在则自动创建）",
    ),
    batch_sizes: str | None = typer.Option(
        None, "--batch-sizes", "-b",
        help="每个 batch 的样本数量，逗号分隔（如 50,80,60）",
    ),
    batch_config: str | None = typer.Option(
        None, "--batch-config", "-c",
        help="batch 配置 JSON 文件路径（与 --batch-sizes 二选一）",
    ),
    seed: int | None = typer.Option(
        None, "--seed", "-s",
        help="随机种子，确保可复现",
    ),
    prefix: str = typer.Option(
        "batch", "--prefix", "-p",
        help="输出文件前缀（默认 batch）",
    ),
    verbose: bool = typer.Option(
        False, "--verbose", "-v",
        help="启用详细输出模式",
    ),
) -> None:
    """从重采样 manifest 中按指定大小不放回抽取，生成 batch CSV 索引文件。"""
    from rich.panel import Panel
    from rich.table import Table

    from eemoclas.tools.batch_indexer import create_batch_indexes

    print_cli_header("工具 — 分批索引生成 (data-to-batchs-index)")

    # --- Parse batch_sizes ---
    if batch_sizes is not None and batch_config is not None:
        print_cli_error("--batch-sizes 和 --batch-config 不能同时指定")
        raise typer.Exit(code=1)

    if batch_sizes is not None:
        try:
            sizes = [int(s.strip()) for s in batch_sizes.split(",")]
        except ValueError:
            print_cli_error(f"无法解析 --batch-sizes: {batch_sizes}")
            raise typer.Exit(code=1)
    elif batch_config is not None:
        config_path = Path(batch_config)
        if not config_path.exists():
            print_cli_error(f"配置文件不存在: {batch_config}")
            raise typer.Exit(code=1)
        with open(config_path, encoding="utf-8") as f:
            cfg = json.load(f)
        sizes = cfg["batch_sizes"]
        if seed is None and "seed" in cfg:
            seed = cfg["seed"]
    else:
        print_cli_error("必须指定 --batch-sizes 或 --batch-config")
        raise typer.Exit(code=1)

    # --- Validate manifest ---
    manifest_path = Path(manifest)
    if not manifest_path.exists():
        print_cli_error(f"Manifest 文件不存在: {manifest}")
        raise typer.Exit(code=1)

    if verbose:
        console.print(Panel(
            f"[bold]输入:[/bold] {manifest}\n"
            f"[bold]输出目录:[/bold] {output_dir}\n"
            f"[bold]Batch 大小:[/bold] {sizes}\n"
            f"[bold]随机种子:[/bold] {seed}",
            title="参数",
            border_style="blue",
        ))

    # --- Run ---
    try:
        result = create_batch_indexes(
            manifest_path=str(manifest_path),
            output_dir=output_dir,
            batch_sizes=sizes,
            seed=seed,
            prefix=prefix,
        )
    except (ValueError, FileNotFoundError) as exc:
        print_cli_error(str(exc))
        raise typer.Exit(code=1)

    # --- Output summary ---
    print_cli_success(f"生成完成: {result['num_batches']} 个 batch")

    if verbose:
        table = Table(title="Batch 索引", show_lines=False)
        table.add_column("文件", style="cyan")
        table.add_column("样本数", justify="right", style="green")
        for i, sz in enumerate(result["batch_sizes"]):
            fname = result["output_files"][i]
            table.add_row(fname, str(sz))
        if result["remainder_size"] > 0:
            table.add_row("remainder.csv", str(result["remainder_size"]))
        console.print(table)

    console.print(f"  总样本: {result['total_samples']}  |  "
                  f"已抽取: {sum(sizes)}  |  "
                  f"剩余: {result['remainder_size']}")
    console.print(f"  输出目录: {output_dir}")
