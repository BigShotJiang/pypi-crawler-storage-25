"""Subject-state resampler for Classifier 1 (normal vs depression)."""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
import torch
import yaml

from eemoclas.data.eeg_io import load_train_mat
from eemoclas.data.eeg_splitter import split_train_emotion
from eemoclas.data.feature_extraction import compute_trial_stats
from eemoclas.data.preprocessing import (
    channel_select,
    clip_signal,
    z_score,
)
from eemoclas.resampling.base_resampler import BaseResampler
from eemoclas.resampling.manifest import (
    build_emotion_manifest_row,
    build_subject_state_manifest_row,
)
from eemoclas.resampling.stats import compute_resample_stats
from eemoclas.resampling.truncated_gaussian import TruncatedGaussianWindowSampler
from eemoclas.utils.seeding import set_split_seed

logger = logging.getLogger(__name__)

# Emotion label constants.
EMOTION_NEU = 0  # neutral
EMOTION_POS = 1  # positive


def _subject_state_worker(item: tuple) -> list[dict]:
    """Process a single subject for subject-state resampling.

    Picklable top-level function for :class:`ProcessPoolExecutor`.
    Receives all state via *item* tuple so no ``self`` reference is needed.
    """
    subject_entry, params, global_offset, samples_dir_str = item
    samples_dir = Path(samples_dir_str)

    subject_id = subject_entry["subject_id"]
    group_label = int(subject_entry["group_label"])
    mat_path = subject_entry["mat_path"]

    fs = params["fs"]
    samples_per_subject = params["samples_per_subject"]
    base_seed = params["base_seed"]
    channel_set = params["channel_set"]
    mu_seconds = params["mu_seconds"]
    sigma_seconds = params["sigma_seconds"]
    lower_seconds = params["lower_seconds"]
    upper_seconds = params["upper_seconds"]
    window_seconds = params["window_seconds"]
    c_eff = params["c_eff"]
    token_meta = params["token_meta"]

    save_raw = params.get("save_raw", False)

    raw = load_train_mat(mat_path)
    neu_segments = split_train_emotion(raw["EEG_data_neu"])
    pos_segments = split_train_emotion(raw["EEG_data_pos"])

    # 8 segments: 4 neutral + 4 positive.
    all_segments = list(neu_segments) + list(pos_segments)
    emotion_labels = [EMOTION_NEU] * 4 + [EMOTION_POS] * 4
    segment_ids = [f"neu_{i}" for i in range(4)] + [
        f"pos_{i}" for i in range(4)
    ]

    manifest_rows: list[dict] = []

    for repeat in range(samples_per_subject):
        seed = base_seed + global_offset + repeat
        rng = np.random.default_rng(seed)

        sampler = TruncatedGaussianWindowSampler(
            fs=fs,
            window_seconds=window_seconds,
            mu_seconds=mu_seconds,
            sigma_seconds=sigma_seconds,
            lower_seconds=lower_seconds,
            upper_seconds=upper_seconds,
            seed=seed,
        )

        trials = []
        raw_crops: list = []  # always keep raw crops for stats
        raw_trials: list = []
        centers_sec: list[float] = []
        starts: list[int] = []
        ends: list[int] = []

        for seg_idx, seg in enumerate(all_segments):
            segment_points = seg.shape[1]
            window = sampler.sample_window(segment_points)
            cropped = sampler.crop(seg, window)  # (30, window_points)

            raw_crops.append(cropped)  # always keep for stats

            raw_trial = None
            if save_raw:
                raw_trial = torch.from_numpy(cropped).clone().float()

            # Preprocessing: channel select + bandpass → z-score → clip.
            processed = channel_select(cropped, channel_set=channel_set)
            processed = z_score(processed)
            processed = clip_signal(processed)

            trials.append(processed)  # (C_eff, window_points)
            if save_raw:
                raw_trials.append(raw_trial)
            centers_sec.append(window["center_seconds"])
            starts.append(window["start_sample"])
            ends.append(window["end_sample"])

        # Random permutation of the 8 trials.
        perm = rng.permutation(8).tolist()
        trials = [trials[i] for i in perm]
        raw_crops = [raw_crops[i] for i in perm]
        raw_trials_perm = [raw_trials[i] for i in perm] if save_raw else []
        perm_emotion_labels = [emotion_labels[i] for i in perm]
        perm_segment_ids = [segment_ids[i] for i in perm]
        perm_centers = [centers_sec[i] for i in perm]
        perm_starts = [starts[i] for i in perm]
        perm_ends = [ends[i] for i in perm]

        # Compute stats (always, regardless of save_raw)
        stats_raw_arr = np.stack([compute_trial_stats(t, fs=fs) for t in raw_crops])     # [8, 30, 35]
        stats_pp_arr = np.stack([compute_trial_stats(t, fs=fs) for t in trials])         # [8, C_eff, 35]

        # Stack as [8, C_eff, window_points].
        x = np.stack(trials, axis=0)
        x_tensor = torch.from_numpy(x).float()

        sample_id = f"ss_{subject_id}_{repeat:04d}"

        # Validate token_meta length.
        if len(token_meta) != x_tensor.shape[-2]:
            raise ValueError(
                f"token_meta length {len(token_meta)} != C_eff {x_tensor.shape[-2]}"
            )

        sample = {
            "x": x_tensor,
            "stats_raw": torch.from_numpy(stats_raw_arr),
            "stats_pp": torch.from_numpy(stats_pp_arr),
            "y": torch.LongTensor([group_label]),
            "subject_id": subject_id,
            "group_label": group_label,
            "trial_emotion_labels": torch.LongTensor(perm_emotion_labels),
            "trial_segment_ids": perm_segment_ids,
            "token_meta": token_meta,
            "meta": {
                "sampler": "truncated_gaussian",
                "mu_seconds": mu_seconds,
                "sigma_seconds": sigma_seconds,
                "window_seconds": window_seconds,
                "permutation": perm,
                "center_seconds": perm_centers,
                "start_sample": perm_starts,
                "end_sample": perm_ends,
            },
        }

        path = str(samples_dir / f"{sample_id}.pt")
        torch.save(sample, path)

        raw_sample_path = ""
        if save_raw:
            raw_x = np.stack([t.numpy() for t in raw_trials_perm], axis=0)
            raw_tensor = torch.from_numpy(raw_x).float()
            raw_path = str(samples_dir / f"{sample_id}_raw.pt")
            raw_sample = {
                "x": raw_tensor,
                "y": torch.LongTensor([group_label]),
                "subject_id": subject_id,
                "group_label": group_label,
                "trial_emotion_labels": torch.LongTensor(perm_emotion_labels),
                "trial_segment_ids": perm_segment_ids,
                "meta": sample["meta"],
            }
            torch.save(raw_sample, raw_path)
            raw_sample_path = raw_path

        row = build_subject_state_manifest_row(
            sample_id=sample_id,
            sample_path=path,
            subject_id=subject_id,
            group_label=group_label,
            num_trials=8,
            c_eff=c_eff,
            length=x_tensor.shape[-1],
            seed=seed,
            source_segments=json.dumps(segment_ids),
            trial_segment_ids=json.dumps(perm_segment_ids),
            trial_emotion_labels=json.dumps(perm_emotion_labels),
            raw_sample_path=raw_sample_path,
        )
        manifest_rows.append(row)

    return manifest_rows


def _subject_state_worker_two_layer(item: tuple) -> list[dict]:
    """Two-layer subject_state worker: trial pool + composition.

    Returns a single-element list containing a dict with keys:
      - "ss_rows": list[dict]  subject_state manifest rows
      - "emotion_rows": list[dict]  emotion manifest rows (empty if not coupled)

    Wrapped in a list for compatibility with ``_parallel_map``.
    """
    (
        subject_entry, params, global_offset,
        ss_samples_dir_str, emotion_samples_dir_str,
    ) = item
    ss_samples_dir = Path(ss_samples_dir_str)
    emotion_samples_dir = Path(emotion_samples_dir_str) if emotion_samples_dir_str else None

    subject_id = subject_entry["subject_id"]
    group_label = int(subject_entry["group_label"])
    mat_path = subject_entry["mat_path"]

    fs = params["fs"]
    base_seed = params["base_seed"]
    channel_set = params["channel_set"]
    mu_seconds = params["mu_seconds"]
    sigma_seconds = params["sigma_seconds"]
    lower_seconds = params["lower_seconds"]
    upper_seconds = params["upper_seconds"]
    window_seconds = params["window_seconds"]
    c_eff = params["c_eff"]
    token_meta = params["token_meta"]

    crops_per_segment = params["crops_per_segment"]
    compositions_per_subject = params["compositions_per_subject"]
    permutations_per_draw = params["permutations_per_draw"]
    save_emotion = params.get("save_emotion", False)
    save_raw = params.get("save_raw", False)

    raw = load_train_mat(mat_path)
    neu_segments = split_train_emotion(raw["EEG_data_neu"])
    pos_segments = split_train_emotion(raw["EEG_data_pos"])

    # ================================================================
    # Layer 1: Build trial pool
    # ================================================================
    trial_pool: list[dict] = []
    raw_trial_pool: list = []
    sample_idx = global_offset

    for i, seg in enumerate(neu_segments):
        segment_points = seg.shape[1]
        for c in range(crops_per_segment):
            seed = base_seed + sample_idx
            sampler = TruncatedGaussianWindowSampler(
                fs=fs, window_seconds=window_seconds,
                mu_seconds=mu_seconds, sigma_seconds=sigma_seconds,
                lower_seconds=lower_seconds, upper_seconds=upper_seconds,
                seed=seed,
            )
            window = sampler.sample_window(segment_points)
            cropped = sampler.crop(seg, window)

            if save_raw:
                raw_trial_pool.append(torch.from_numpy(cropped).clone().float())

            processed = channel_select(cropped, channel_set=channel_set)
            processed = z_score(processed)
            processed = clip_signal(processed)

            trial_pool.append({
                "tensor": torch.from_numpy(processed).float(),
                "raw_crop": cropped,  # always keep for stats
                "processed_np": processed,  # always keep for stats
                "emotion": EMOTION_NEU,
                "seg_id": f"neu_{i}",
                "crop_idx": c,
                "seed": seed,
                "window": window,
            })
            sample_idx += 1

    for i, seg in enumerate(pos_segments):
        segment_points = seg.shape[1]
        for c in range(crops_per_segment):
            seed = base_seed + sample_idx
            sampler = TruncatedGaussianWindowSampler(
                fs=fs, window_seconds=window_seconds,
                mu_seconds=mu_seconds, sigma_seconds=sigma_seconds,
                lower_seconds=lower_seconds, upper_seconds=upper_seconds,
                seed=seed,
            )
            window = sampler.sample_window(segment_points)
            cropped = sampler.crop(seg, window)

            if save_raw:
                raw_trial_pool.append(torch.from_numpy(cropped).clone().float())

            processed = channel_select(cropped, channel_set=channel_set)
            processed = z_score(processed)
            processed = clip_signal(processed)

            trial_pool.append({
                "tensor": torch.from_numpy(processed).float(),
                "raw_crop": cropped,  # always keep for stats
                "processed_np": processed,  # always keep for stats
                "emotion": EMOTION_POS,
                "seg_id": f"pos_{i}",
                "crop_idx": c,
                "seed": seed,
                "window": window,
            })
            sample_idx += 1

    # ================================================================
    # Save emotion samples (coupled mode only)
    # ================================================================
    emotion_rows: list[dict] = []
    if save_emotion and emotion_samples_dir is not None:
        prefix = "ne" if group_label == 0 else "de"
        for idx, trial in enumerate(trial_pool):
            x_tensor = trial["tensor"]
            emotion = trial["emotion"]
            seg_id = trial["seg_id"]
            crop_idx = trial["crop_idx"]

            # Compute stats (always, regardless of save_raw)
            stats_raw_arr = compute_trial_stats(trial["raw_crop"], fs=fs)       # (30, 35)
            stats_pp_arr = compute_trial_stats(trial["processed_np"], fs=fs)    # (C_eff, 35)

            if len(token_meta) != x_tensor.shape[-2]:
                raise ValueError(
                    f"token_meta length {len(token_meta)} != C_eff {x_tensor.shape[-2]}"
                )

            sample_id = f"{prefix}_{subject_id}_{seg_id}_{crop_idx:04d}"

            sample = {
                "x": x_tensor,
                "stats_raw": torch.from_numpy(stats_raw_arr),
                "stats_pp": torch.from_numpy(stats_pp_arr),
                "y": torch.LongTensor([emotion]),
                "subject_id": subject_id,
                "group_label": group_label,
                "emotion_label": emotion,
                "segment_id": seg_id,
                "token_meta": token_meta,
                "meta": {
                    "sampler": "truncated_gaussian",
                    "center_seconds": trial["window"]["center_seconds"],
                    "start_sample": trial["window"]["start_sample"],
                    "end_sample": trial["window"]["end_sample"],
                },
            }

            path = str(emotion_samples_dir / f"{sample_id}.pt")
            torch.save(sample, path)

            raw_emotion_path = ""
            if save_raw:
                raw_emo_tensor = raw_trial_pool[idx]
                raw_emo_path = str(emotion_samples_dir / f"{sample_id}_raw.pt")
                raw_emo_sample = {
                    "x": raw_emo_tensor,
                    "y": torch.LongTensor([emotion]),
                    "subject_id": subject_id,
                    "group_label": group_label,
                    "emotion_label": emotion,
                    "segment_id": seg_id,
                    "meta": {
                        "sampler": "truncated_gaussian",
                        "center_seconds": trial["window"]["center_seconds"],
                        "start_sample": trial["window"]["start_sample"],
                        "end_sample": trial["window"]["end_sample"],
                    },
                }
                torch.save(raw_emo_sample, raw_emo_path)
                raw_emotion_path = raw_emo_path

            row = build_emotion_manifest_row(
                sample_id=sample_id,
                sample_path=path,
                subject_id=subject_id,
                group_label=group_label,
                emotion_label=emotion,
                segment_id=seg_id,
                center_seconds=trial["window"]["center_seconds"],
                start_sample=trial["window"]["start_sample"],
                end_sample=trial["window"]["end_sample"],
                c_eff=c_eff,
                length=x_tensor.shape[-1],
                seed=trial["seed"],
                raw_sample_path=raw_emotion_path,
            )
            emotion_rows.append(row)

    # ================================================================
    # Layer 2: Compose subject_state samples
    # ================================================================
    neu_indices = [i for i, t in enumerate(trial_pool) if t["emotion"] == EMOTION_NEU]
    pos_indices = [i for i, t in enumerate(trial_pool) if t["emotion"] == EMOTION_POS]

    ss_rows: list[dict] = []
    rng = np.random.default_rng(base_seed + global_offset)

    for crop_round in range(crops_per_segment):
        for d in range(compositions_per_subject):
            selected_neu = rng.choice(neu_indices, size=4, replace=True).tolist()
            selected_pos = rng.choice(pos_indices, size=4, replace=True).tolist()
            selected_all = selected_neu + selected_pos

            for k in range(permutations_per_draw):
                seed = base_seed + sample_idx
                perm_rng = np.random.default_rng(seed)
                perm = perm_rng.permutation(8).tolist()

                perm_trials = [trial_pool[selected_all[p]] for p in perm]
                perm_emotion_labels = [perm_trials[p]["emotion"] for p in range(8)]
                perm_seg_ids = [perm_trials[p]["seg_id"] for p in range(8)]

                x = np.stack([t["tensor"].numpy() for t in perm_trials], axis=0)
                x_tensor = torch.from_numpy(x).float()

                # Compute stats (always, regardless of save_raw)
                stats_raw_arr = np.stack([compute_trial_stats(t["raw_crop"], fs=fs) for t in perm_trials])     # [8, 30, 35]
                stats_pp_arr = np.stack([compute_trial_stats(t["processed_np"], fs=fs) for t in perm_trials])  # [8, C_eff, 35]

                if len(token_meta) != x_tensor.shape[-2]:
                    raise ValueError(
                        f"token_meta length {len(token_meta)} != C_eff {x_tensor.shape[-2]}"
                    )

                sample_id = f"ss_{subject_id}_{crop_round:04d}_{d:04d}_{k:04d}"

                sample = {
                    "x": x_tensor,
                    "stats_raw": torch.from_numpy(stats_raw_arr),
                    "stats_pp": torch.from_numpy(stats_pp_arr),
                    "y": torch.LongTensor([group_label]),
                    "subject_id": subject_id,
                    "group_label": group_label,
                    "trial_emotion_labels": torch.LongTensor(perm_emotion_labels),
                    "trial_segment_ids": perm_seg_ids,
                    "token_meta": token_meta,
                    "meta": {
                        "sampler": "truncated_gaussian",
                        "mu_seconds": mu_seconds,
                        "sigma_seconds": sigma_seconds,
                        "window_seconds": window_seconds,
                        "permutation": perm,
                        "crop_round": crop_round,
                        "composition_idx": d,
                        "permutation_idx": k,
                        "selected_neu_indices": selected_neu,
                        "selected_pos_indices": selected_pos,
                    },
                }

                path = str(ss_samples_dir / f"{sample_id}.pt")
                torch.save(sample, path)

                raw_sample_path = ""
                if save_raw:
                    raw_perm_trials = [raw_trial_pool[selected_all[p]] for p in perm]
                    raw_x = np.stack([t.numpy() for t in raw_perm_trials], axis=0)
                    raw_tensor = torch.from_numpy(raw_x).float()
                    raw_path = str(ss_samples_dir / f"{sample_id}_raw.pt")
                    raw_sample = {
                        "x": raw_tensor,
                        "y": torch.LongTensor([group_label]),
                        "subject_id": subject_id,
                        "group_label": group_label,
                        "trial_emotion_labels": torch.LongTensor(perm_emotion_labels),
                        "trial_segment_ids": perm_seg_ids,
                        "meta": sample["meta"],
                    }
                    torch.save(raw_sample, raw_path)
                    raw_sample_path = raw_path

                segment_ids = [f"neu_{i}" for i in range(4)] + [f"pos_{i}" for i in range(4)]
                row = build_subject_state_manifest_row(
                    sample_id=sample_id,
                    sample_path=path,
                    subject_id=subject_id,
                    group_label=group_label,
                    num_trials=8,
                    c_eff=c_eff,
                    length=x_tensor.shape[-1],
                    seed=seed,
                    source_segments=json.dumps(segment_ids),
                    trial_segment_ids=json.dumps(perm_seg_ids),
                    trial_emotion_labels=json.dumps(perm_emotion_labels),
                    raw_sample_path=raw_sample_path,
                )
                ss_rows.append(row)
                sample_idx += 1

    return [{"ss_rows": ss_rows, "emotion_rows": emotion_rows}]


class SubjectStateResampler(BaseResampler):
    """Generate the resampled dataset for Classifier 1.

    For each subject the 50-second neutral and positive recordings are split
    into 8 segments (4 neutral + 4 positive).  For each repeated draw the
    sampler crops a random 10-second window from every segment, applies
    preprocessing, randomly permutes the 8 trials, and stacks them into a
    single ``[8, C_eff, 2500]`` tensor.

    The resulting sample encodes a **subject-level** state (normal /
    depression) rather than an emotion-level label.
    """

    def run(self) -> None:
        """Execute the full resampling pipeline."""
        self.save_config_snapshot()

        cfg = self.config
        resample_cfg = cfg.get("resample", cfg.get("resampling", {}))
        mode = resample_cfg.get("mode", "legacy")

        if mode == "two_layer":
            self._run_two_layer()
        else:
            self._run_legacy()

    def _run_legacy(self) -> None:
        """Original single-layer resampling (backward compatible)."""
        cfg = self.config
        data_cfg = cfg["data"]
        resample_cfg = cfg.get("resample", cfg.get("resampling", {}))

        fs: int = data_cfg.get("fs", 250)
        samples_per_subject: int = resample_cfg.get("samples_per_subject", 20)
        base_seed: int = cfg.get("seed", 42)
        channel_set: str = data_cfg.get("channel_set", "standard")

        mu_seconds: float = resample_cfg.get("mu_seconds", 25.0)
        sigma_seconds: float = resample_cfg.get("sigma_seconds", 8.0)
        lower_seconds: float = resample_cfg.get("lower_seconds", 5.0)
        upper_seconds: float = resample_cfg.get("upper_seconds", 45.0)
        window_seconds: float = resample_cfg.get("window_seconds", 10.0)

        subjects_csv = data_cfg.get(
            "index_file", data_cfg.get("subjects_csv", "train_subjects.csv")
        )
        subject_list = self._load_subject_list(subjects_csv)

        from eemoclas.utils.config import resolve_c_eff
        c_eff = resolve_c_eff(cfg)

        _, token_meta = channel_select(
            np.zeros((30, 2500)),
            channel_set=channel_set,
            return_meta=True,
        )

        save_raw = resample_cfg.get("save_raw", False)

        _cfg = {
            "fs": fs,
            "samples_per_subject": samples_per_subject,
            "base_seed": base_seed,
            "channel_set": channel_set,
            "mu_seconds": mu_seconds,
            "sigma_seconds": sigma_seconds,
            "lower_seconds": lower_seconds,
            "upper_seconds": upper_seconds,
            "window_seconds": window_seconds,
            "c_eff": c_eff,
            "token_meta": token_meta,
            "save_raw": save_raw,
        }

        samples_per_subject_count = samples_per_subject
        subject_offsets: dict[str, int] = {}
        offset = 0
        for entry in subject_list:
            subject_offsets[entry["subject_id"]] = offset
            offset += samples_per_subject_count

        items = [
            (entry, _cfg, subject_offsets[entry["subject_id"]], str(self.samples_dir))
            for entry in subject_list
        ]

        manifest_rows = self._parallel_map(
            _subject_state_worker,
            items,
            desc="subject_state_legacy",
        )

        self.write_manifest(manifest_rows)
        stats = compute_resample_stats(manifest_rows, task_name="subject_state")
        self.write_stats(stats)

        logger.info(
            "Subject-state (legacy) resampling complete: %d samples from %d subjects.",
            len(manifest_rows),
            len(subject_list),
        )

    def _run_two_layer(self) -> None:
        """Two-layer resampling: trial pool -> composition + optional emotion output."""
        cfg = self.config
        data_cfg = cfg["data"]
        resample_cfg = cfg.get("resample", cfg.get("resampling", {}))

        # Per-group parameters from flattened per_target
        group_params = {}
        for group_key, group_label_val in [("normal", 0), ("depression", 1)]:
            gp = resample_cfg.get(group_key, {})
            crops = gp.get("crops_per_segment", 50)
            comps = gp.get("compositions_per_subject", 20)
            perms = gp.get("permutations_per_draw", 10)
            if crops < 1 or comps < 1 or perms < 1:
                raise ValueError(
                    f"subject_state {group_key}: crops_per_segment={crops}, "
                    f"compositions_per_subject={comps}, permutations_per_draw={perms} "
                    f"must all be >= 1"
                )
            group_params[group_label_val] = {
                "crops_per_segment": crops,
                "compositions_per_subject": comps,
                "permutations_per_draw": perms,
            }

        # Detect coupled mode
        emotion_output_dirs = data_cfg.get("emotion_output_dirs")
        coupled = emotion_output_dirs is not None

        # Create emotion output directories
        if coupled:
            for gl, emo_path in emotion_output_dirs.items():
                emo_samples = Path(emo_path) / "samples"
                emo_samples.mkdir(parents=True, exist_ok=True)

        fs: int = data_cfg.get("fs", 250)
        base_seed: int = cfg.get("seed", 42)
        channel_set: str = data_cfg.get("channel_set", "standard")
        sampling_cfg = resample_cfg.get("sampling", {})
        gaussian_cfg = sampling_cfg.get("gaussian", {})
        mu_seconds: float = resample_cfg.get("mu_seconds", gaussian_cfg.get("mu_seconds", 25.0))
        sigma_seconds: float = resample_cfg.get("sigma_seconds", gaussian_cfg.get("sigma_seconds", 8.0))
        lower_seconds: float = resample_cfg.get("lower_seconds", gaussian_cfg.get("lower_seconds", 5.0))
        upper_seconds: float = resample_cfg.get("upper_seconds", gaussian_cfg.get("upper_seconds", 45.0))
        window_seconds: float = resample_cfg.get("window_seconds", sampling_cfg.get("window_seconds", 10.0))

        save_raw = resample_cfg.get("save_raw", False)

        subjects_csv = data_cfg.get(
            "index_file", data_cfg.get("subjects_csv", "train_subjects.csv")
        )
        subject_list = self._load_subject_list(subjects_csv)

        from eemoclas.utils.config import resolve_c_eff
        c_eff = resolve_c_eff(cfg)

        _, token_meta = channel_select(
            np.zeros((30, 2500)),
            channel_set=channel_set,
            return_meta=True,
        )

        # Assign deterministic global offsets per subject
        subject_offsets: dict[str, int] = {}
        offset = 0
        for entry in subject_list:
            gl = int(entry["group_label"])
            gp = group_params[gl]
            per_subject = 8 * gp["crops_per_segment"] + gp["crops_per_segment"] * gp["compositions_per_subject"] * gp["permutations_per_draw"]
            subject_offsets[entry["subject_id"]] = offset
            offset += per_subject

        # Build work items
        items = []
        for entry in subject_list:
            gl = int(entry["group_label"])
            gp = group_params[gl]

            emo_dir = str(emotion_output_dirs.get(gl, "")) if coupled else ""

            _params = {
                "fs": fs,
                "base_seed": base_seed,
                "channel_set": channel_set,
                "mu_seconds": mu_seconds,
                "sigma_seconds": sigma_seconds,
                "lower_seconds": lower_seconds,
                "upper_seconds": upper_seconds,
                "window_seconds": window_seconds,
                "c_eff": c_eff,
                "token_meta": token_meta,
                "crops_per_segment": gp["crops_per_segment"],
                "compositions_per_subject": gp["compositions_per_subject"],
                "permutations_per_draw": gp["permutations_per_draw"],
                "save_emotion": coupled,
                "save_raw": save_raw,
            }
            items.append((
                entry, _params,
                subject_offsets[entry["subject_id"]],
                str(self.samples_dir),
                emo_dir,
            ))

        # Execute via _parallel_map (supports --workers for multi-process)
        raw_results = self._parallel_map(
            _subject_state_worker_two_layer,
            items,
            desc="subject_state_two_layer",
        )

        # Unpack wrapped results
        all_ss_rows: list[dict] = []
        all_emotion_rows: list[dict] = []
        for result in raw_results:
            all_ss_rows.extend(result["ss_rows"])
            all_emotion_rows.extend(result["emotion_rows"])

        # Write subject_state manifest and stats
        self.write_manifest(all_ss_rows)
        ss_stats = compute_resample_stats(all_ss_rows, task_name="subject_state")
        self.write_stats(ss_stats)

        logger.info(
            "Subject-state (two_layer) resampling complete: %d samples from %d subjects.",
            len(all_ss_rows),
            len(subject_list),
        )

        # Write emotion manifests and stats (coupled mode)
        if coupled and all_emotion_rows:
            normal_rows = [r for r in all_emotion_rows if r["group_label"] == 0]
            depression_rows = [r for r in all_emotion_rows if r["group_label"] == 1]

            for emo_target, emo_rows, gl in [
                ("normal_emotion", normal_rows, 0),
                ("depression_emotion", depression_rows, 1),
            ]:
                emo_output = Path(emotion_output_dirs[gl])
                emo_manifest_path = emo_output / "manifest.csv"

                if emo_rows:
                    df = pd.DataFrame(emo_rows)
                    if "sample_id" in df.columns:
                        df = df.drop_duplicates(subset=["sample_id"], keep="first")
                    df.to_csv(emo_manifest_path, index=False)

                    emo_stats = compute_resample_stats(emo_rows, task_name=emo_target)
                    with open(emo_output / "stats.json", "w", encoding="utf-8") as f:
                        json.dump(emo_stats, f, indent=2, ensure_ascii=False)

                    with open(emo_output / "config_snapshot.yaml", "w", encoding="utf-8") as f:
                        yaml.dump(cfg, f, default_flow_style=False, allow_unicode=True)
                else:
                    pd.DataFrame().to_csv(emo_manifest_path, index=False)

                logger.info(
                    "%s (coupled) complete: %d samples.",
                    emo_target, len(emo_rows),
                )

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _load_subject_list(csv_path: str) -> list[dict]:
        """Load the subject list from a CSV file.

        Expected columns: ``subject_id``, ``group_label``, ``mat_path``.

        Returns
        -------
        list[dict]
            One dict per subject.
        """
        import pandas as pd
        from pathlib import Path

        path = Path(csv_path)
        if not path.exists():
            raise FileNotFoundError(f"Subjects CSV not found: {csv_path}")

        df = pd.read_csv(path)
        required = {"subject_id", "group_label", "mat_path"}
        missing = required - set(df.columns)
        if missing:
            raise ValueError(
                f"Subjects CSV missing required columns: {missing}"
            )

        # Drop duplicate subjects to prevent duplicate samples
        before = len(df)
        df = df.drop_duplicates(subset=["subject_id"], keep="first")
        dup_count = before - len(df)
        if dup_count > 0:
            from eemoclas.resampling.base_resampler import logger as _br_logger
            _br_logger.warning(
                "Dropped %d duplicate subject_id(s) from %s.",
                dup_count, csv_path,
            )

        return df.to_dict(orient="records")
