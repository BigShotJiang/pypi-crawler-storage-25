"""V3 All-in-One Multi-Task Classifier.

Input:  ``[B, 8, C_eff, 2500]``
Output: ``[B, 9]`` — 1 subject-state binary logit + 8 trial emotion binary logits.

Apache-2.0  --  SuShuHeng
"""

from __future__ import annotations

import torch
import torch.nn as nn

from eemoclas.model.trial_cnn_transformer import TrialCNNTransformer
from eemoclas.model.transformer_blocks import TransformerEncoderBlock
from eemoclas.model.classification_head import ClassificationHead


class AllInOneCNNTransformer(nn.Module):
    """Multi-task classifier: subject-state + per-trial emotion.

    Architecture:
        1. Shared TrialCNNTransformer encodes each of 8 trials → [B, 8, D]
        2. Trial position embeddings added
        3. Subject-level CLS token prepended → [B, 9, D]
        4. Subject Transformer encodes the 9-token sequence
        5. CLS output → Subject Head (binary logit)
        6. Trial outputs → shared Emotion Head (8 binary logits)
        7. Concatenate → [B, 9]
    """

    def __init__(self, config: dict) -> None:
        super().__init__()

        trial_cfg = config.get("trial_encoder", {})
        subject_cfg = config.get("subject_encoder", {})
        subject_head_cfg = config.get("subject_head", {})
        emotion_head_cfg = config.get("emotion_head", {})

        embedding_dim = trial_cfg.get("projection_dim", 128)
        num_trials = config.get("num_trials", 8)

        # --- Shared trial-level encoder ---
        self.trial_encoder = TrialCNNTransformer(
            input_channels=trial_cfg.get("input_channels", 30),
            input_length=trial_cfg.get("input_length", 2500),
            projection_dim=embedding_dim,
            cnn_channels=trial_cfg.get("cnn_channels", [16, 32, 64]),
            kernel_sizes=trial_cfg.get("kernel_sizes", [15, 9, 5]),
            strides=trial_cfg.get("strides", [2, 2, 2]),
            cnn_dropout=trial_cfg.get("cnn_dropout", 0.1),
            transformer_num_layers=trial_cfg.get("transformer_num_layers", 2),
            transformer_num_heads=trial_cfg.get("transformer_num_heads", 4),
            transformer_dim_feedforward=trial_cfg.get("transformer_dim_feedforward", 256),
            transformer_dropout=trial_cfg.get("transformer_dropout", 0.1),
            use_cls_token=trial_cfg.get("use_cls_token", True),
            pooling=trial_cfg.get("pooling", "cls"),
            use_channel_embedding=trial_cfg.get("use_channel_embedding", True),
            use_band_embedding=trial_cfg.get("use_band_embedding", True),
            channel_names=trial_cfg.get("channel_names", None),
            band_names=trial_cfg.get("band_names", None),
        )

        # --- Subject-level CLS token ---
        self.subject_cls_token = nn.Parameter(torch.zeros(embedding_dim))
        nn.init.trunc_normal_(self.subject_cls_token, std=0.02)

        # --- Trial positional embedding ---
        self.trial_position_embedding = nn.Embedding(num_trials, embedding_dim)

        # --- Subject-level Transformer ---
        self.subject_transformer = TransformerEncoderBlock(
            d_model=subject_cfg.get("d_model", embedding_dim),
            num_layers=subject_cfg.get("num_layers", 2),
            num_heads=subject_cfg.get("num_heads", 4),
            dim_feedforward=subject_cfg.get("dim_feedforward", 256),
            dropout=subject_cfg.get("dropout", 0.1),
            activation=subject_cfg.get("activation", "gelu"),
            batch_first=subject_cfg.get("batch_first", True),
            norm_first=subject_cfg.get("norm_first", True),
        )

        # --- Subject classification head (binary, 1 logit) ---
        self.subject_head = ClassificationHead(
            input_dim=subject_head_cfg.get("input_dim", embedding_dim),
            num_classes=1,
            hidden_dims=subject_head_cfg.get("hidden_dims", [128]),
            dropout=subject_head_cfg.get("dropout", 0.3),
        )

        # --- Shared emotion classification head (binary, 1 logit) ---
        self.emotion_head = ClassificationHead(
            input_dim=emotion_head_cfg.get("input_dim", embedding_dim),
            num_classes=1,
            hidden_dims=emotion_head_cfg.get("hidden_dims", [128]),
            dropout=emotion_head_cfg.get("dropout", 0.3),
        )

        self.num_trials = num_trials
        self.embedding_dim = embedding_dim

    def forward(
        self,
        x: torch.Tensor,
        token_meta: list[dict] | None = None,
        x_raw: torch.Tensor | None = None,
        stats_raw: torch.Tensor | None = None,
        stats_pp: torch.Tensor | None = None,
    ) -> torch.Tensor:
        """Forward pass.

        Args:
            x: ``[B, 8, C_eff, 2500]`` — preprocessed EEG data.
            token_meta: Channel/band metadata per token.
            x_raw, stats_raw, stats_pp: Ignored (interface compatibility).

        Returns:
            ``[B, 9]`` — 1 subject-state binary logit + 8 trial emotion binary logits.
        """
        B, T_trials, C_eff, T_len = x.shape

        # Step 1: Encode all trials with shared trial encoder
        h = x.reshape(B * T_trials, C_eff, T_len)
        h = self.trial_encoder(h, token_meta=token_meta)  # [B*8, D]
        h = h.reshape(B, T_trials, self.embedding_dim)     # [B, 8, D]

        # Step 2: Add trial position embeddings
        positions = torch.arange(T_trials, device=x.device)
        h = h + self.trial_position_embedding(positions).unsqueeze(0)

        # Step 3: Prepend subject-level CLS token
        cls = self.subject_cls_token.view(1, 1, self.embedding_dim).expand(B, -1, -1)
        h = torch.cat([cls, h], dim=1)  # [B, 9, D]

        # Step 4: Subject-level Transformer
        h = self.subject_transformer(h)  # [B, 9, D]

        # Step 5: Split CLS and trial outputs
        cls_out = h[:, 0, :]    # [B, D]
        trial_out = h[:, 1:, :]  # [B, 8, D]

        # Step 6: Subject head → [B, 1] → squeeze → [B]
        subject_logit = self.subject_head(cls_out).squeeze(-1)  # [B]

        # Step 7: Shared emotion head → [B*8, 1] → reshape → [B, 8]
        trial_flat = trial_out.reshape(B * T_trials, self.embedding_dim)
        emotion_logit = self.emotion_head(trial_flat).squeeze(-1)  # [B*8]
        emotion_logit = emotion_logit.reshape(B, T_trials)         # [B, 8]

        # Step 8: Concatenate → [B, 9]
        output = torch.cat([subject_logit.unsqueeze(1), emotion_logit], dim=1)

        return output
