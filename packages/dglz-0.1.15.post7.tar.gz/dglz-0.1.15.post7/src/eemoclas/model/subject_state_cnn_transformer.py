"""Classifier 1: normal / depression subject-level model."""

from __future__ import annotations

import torch
import torch.nn as nn

from eemoclas.model.trial_cnn_transformer import TrialCNNTransformer
from eemoclas.model.transformer_blocks import TransformerEncoderBlock
from eemoclas.model.classification_head import ClassificationHead


class SubjectStateCNNTransformer(nn.Module):
    """
    Subject-level binary classifier (normal vs. depression).

    Two-level Transformer architecture:
      1. **Trial-level**: Each of the 8 trials per subject is encoded by a
         shared :class:`TrialCNNTransformer` into a ``D``-dim vector.
      2. **Subject-level**: Trial embeddings (with positional encoding and a
         subject-level CLS token) are fed into a second Transformer.  The CLS
         output is classified into 2 classes.

    Input:  ``[B, 8, C_eff, 2500]``
    Output: ``[B, 2]``
    """

    def __init__(self, config: dict) -> None:
        super().__init__()

        trial_cfg = config.get("trial_encoder", {})
        subject_cfg = config.get("subject_encoder", {})
        head_cfg = config.get("classification_head", {})

        # --- trial-level encoder (shared across 8 trials) ---
        self.trial_encoder = TrialCNNTransformer(
            input_channels=trial_cfg.get("input_channels", 30),
            input_length=trial_cfg.get("input_length", 2500),
            projection_dim=trial_cfg.get("projection_dim", 128),
            cnn_channels=trial_cfg.get("cnn_channels", [16, 32, 64]),
            kernel_sizes=trial_cfg.get("kernel_sizes", [15, 9, 5]),
            strides=trial_cfg.get("strides", [2, 2, 2]),
            cnn_dropout=trial_cfg.get("cnn_dropout", 0.1),
            transformer_num_layers=trial_cfg.get("transformer_num_layers", 2),
            transformer_num_heads=trial_cfg.get("transformer_num_heads", 4),
            transformer_dim_feedforward=trial_cfg.get("transformer_dim_feedforward", 256),
            transformer_dropout=trial_cfg.get("transformer_dropout", 0.1),
            use_cls_token=trial_cfg.get("use_cls_token", True),
            pooling=trial_cfg.get("pooling", "cls"),
            use_channel_embedding=trial_cfg.get("use_channel_embedding", True),
            use_band_embedding=trial_cfg.get("use_band_embedding", True),
            channel_names=trial_cfg.get("channel_names", None),
            band_names=trial_cfg.get("band_names", None),
        )

        embedding_dim = trial_cfg.get("projection_dim", 128)
        num_trials = config.get("num_trials", 8)

        # --- subject-level CLS token ---
        self.subject_cls_token = nn.Parameter(torch.zeros(embedding_dim))
        nn.init.trunc_normal_(self.subject_cls_token, std=0.02)

        # --- trial positional embedding ---
        self.trial_position_embedding = nn.Embedding(num_trials, embedding_dim)

        # --- subject-level Transformer ---
        self.subject_transformer = TransformerEncoderBlock(
            d_model=subject_cfg.get("d_model", embedding_dim),
            num_layers=subject_cfg.get("num_layers", 2),
            num_heads=subject_cfg.get("num_heads", 4),
            dim_feedforward=subject_cfg.get("dim_feedforward", 256),
            dropout=subject_cfg.get("dropout", 0.1),
            activation=subject_cfg.get("activation", "gelu"),
            batch_first=subject_cfg.get("batch_first", True),
            norm_first=subject_cfg.get("norm_first", True),
        )

        # --- classification head ---
        self.classification_head = ClassificationHead(
            input_dim=head_cfg.get("input_dim", embedding_dim),
            num_classes=head_cfg.get("num_classes", 2),
            hidden_dims=head_cfg.get("hidden_dims", [128]),
            dropout=head_cfg.get("dropout", 0.3),
        )

        self.num_trials = num_trials
        self.embedding_dim = embedding_dim

    def forward(
        self,
        x: torch.Tensor,
        token_meta: list[dict] | None = None,
        x_raw: torch.Tensor | None = None,
        stats_raw: torch.Tensor | None = None,
        stats_pp: torch.Tensor | None = None,
    ) -> torch.Tensor:
        """
        Args:
            x: ``[B, 8, C_eff, 2500]``
            token_meta: list of dicts describing each token's channel / band.

        Returns:
            logits ``[B, 2]``
        """
        B, T_trials, C_eff, T_len = x.shape

        # Step 1: Encode all trials with shared trial encoder.
        h = x.reshape(B * T_trials, C_eff, T_len)      # [B*8, C_eff, 2500]
        h = self.trial_encoder(h, token_meta=token_meta) # [B*8, D]
        h = h.reshape(B, T_trials, self.embedding_dim)   # [B, 8, D]

        # Step 2: Add trial position embeddings.
        positions = torch.arange(T_trials, device=x.device)  # [8]
        h = h + self.trial_position_embedding(positions).unsqueeze(0)
        # [B, 8, D]

        # Step 3: Prepend subject-level CLS token.
        cls = self.subject_cls_token.view(1, 1, self.embedding_dim).expand(B, -1, -1)
        h = torch.cat([cls, h], dim=1)  # [B, 9, D]

        # Step 4: Subject-level Transformer.
        h = self.subject_transformer(h)  # [B, 9, D]

        # Step 5: Extract CLS output.
        h = h[:, 0, :]  # [B, D]

        # Step 6: Classification head.
        logits = self.classification_head(h)  # [B, 2]

        return logits
