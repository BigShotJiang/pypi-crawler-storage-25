"""Dual-branch subject-state classifier with trial-level Fusion Transformer."""

from __future__ import annotations

import torch
import torch.nn as nn

from eemoclas.model.dual_branch_emotion import (
    _build_trial_encoder,
    _make_raw_token_meta,
)
from eemoclas.model.transformer_blocks import TransformerEncoderBlock
from eemoclas.model.classification_head import ClassificationHead
from eemoclas.data.feature_extraction import FEATURE_INDEX, POWER_FEATURE_INDICES


class DualBranchSubjectStateCNNTransformer(nn.Module):
    """Dual-branch subject-state classifier with trial-level fusion.

    Two independent TrialCNNTransformer branches encode each of the 8
    trials for both raw (30-channel) and preprocessed (C_eff-channel)
    inputs. The resulting 16 trial embeddings are interleaved and fed
    into a Fusion Transformer (which replaces the original subject-level
    Transformer). Branch embeddings and trial position embeddings are
    added for disambiguation.

    Input:  ``x`` [B, 8, C_eff, 2500] (PP), ``x_raw`` [B, 8, 30, 2500] (raw)
    Output: [B, 2] logits
    """

    def __init__(self, config: dict) -> None:
        super().__init__()

        # Support both flat config and nested "model" sub-dict
        model_cfg = config.get("model", config)
        raw_cfg = model_cfg.get("raw_trial_encoder", {})
        pp_cfg = model_cfg.get("pp_trial_encoder", {})
        fusion_cfg = model_cfg.get("fusion_transformer", {})
        head_cfg = model_cfg.get("classification_head", {})
        num_trials = model_cfg.get("num_trials", config.get("num_trials", 8))

        D = raw_cfg.get("projection_dim", 128)

        # --- Two independent trial encoders ---
        self.raw_encoder = _build_trial_encoder(raw_cfg)
        self.pp_encoder = _build_trial_encoder(pp_cfg)

        # --- Synthetic token_meta for raw branch ---
        self._raw_token_meta = _make_raw_token_meta()

        # --- Branch embedding (0=raw, 1=pp) ---
        self.branch_embedding = nn.Embedding(2, D)

        # --- Trial position embedding ---
        self.trial_position_embedding = nn.Embedding(num_trials, D)

        # --- CLS token for fusion ---
        self.cls_token = nn.Parameter(torch.zeros(1, 1, D))
        nn.init.trunc_normal_(self.cls_token, std=0.02)

        # --- Fusion Transformer (replaces subject-level Transformer) ---
        self.fusion_transformer = TransformerEncoderBlock(
            d_model=fusion_cfg.get("d_model", D),
            num_layers=fusion_cfg.get("num_layers", 2),
            num_heads=fusion_cfg.get("num_heads", 4),
            dim_feedforward=fusion_cfg.get("dim_feedforward", 256),
            dropout=fusion_cfg.get("dropout", 0.1),
            activation=fusion_cfg.get("activation", "gelu"),
            batch_first=fusion_cfg.get("batch_first", True),
            norm_first=fusion_cfg.get("norm_first", True),
        )

        # --- Classification head ---
        self.classification_head = ClassificationHead(
            input_dim=head_cfg.get("input_dim", D),
            num_classes=head_cfg.get("num_classes", 2),
            hidden_dims=head_cfg.get("hidden_dims", [128]),
            dropout=head_cfg.get("dropout", 0.3),
        )

        # --- Stats feature projection (optional) ---
        self._use_stats = False
        self._feature_indices: list[int] = []
        self._power_mask: torch.Tensor = torch.empty(0, dtype=torch.bool)
        stats_cfg = model_cfg.get("stats_features")
        if stats_cfg and stats_cfg.get("enabled"):
            n_sel = len(stats_cfg.get("features", []))
            if n_sel > 0:
                C_raw = raw_cfg.get("input_channels", 30)
                C_pp = pp_cfg.get("input_channels")
                if not C_pp or C_pp <= 0:
                    raise ValueError(
                        "pp_trial_encoder.input_channels not set. "
                        "This is auto-detected from data when using `eemo train`. "
                        f"Got: {C_pp!r}"
                    )
                proj_dim = stats_cfg.get("projection_dim", 64)
                self.raw_stats_mlp = nn.Sequential(
                    nn.Linear(C_raw * n_sel, proj_dim),
                    nn.BatchNorm1d(proj_dim),
                    nn.ReLU(),
                    nn.Dropout(0.1),
                    nn.Linear(proj_dim, D),
                )
                self.pp_stats_mlp = nn.Sequential(
                    nn.Linear(C_pp * n_sel, proj_dim),
                    nn.BatchNorm1d(proj_dim),
                    nn.ReLU(),
                    nn.Dropout(0.1),
                    nn.Linear(proj_dim, D),
                )
                self._use_stats = True
                self._feature_indices = [
                    FEATURE_INDEX[n] for n in stats_cfg["features"]
                ]
                self._power_mask = torch.tensor(
                    [int(i in POWER_FEATURE_INDICES) for i in self._feature_indices],
                    dtype=torch.bool,
                )

        self.num_trials = num_trials
        self.embedding_dim = D

    def _normalize_stats(self, stats: torch.Tensor) -> torch.Tensor:
        """Log-transform power features, leave rest unchanged."""
        if not self._power_mask.any():
            return stats
        stats = stats.clone()
        power_cols = stats[..., self._power_mask]
        stats[..., self._power_mask] = torch.log1p(power_cols.abs())
        return stats

    def forward(
        self,
        x: torch.Tensor,
        token_meta: list[dict] | None = None,
        x_raw: torch.Tensor | None = None,
        stats_raw: torch.Tensor | None = None,
        stats_pp: torch.Tensor | None = None,
    ) -> torch.Tensor:
        """
        Args:
            x:       ``[B, 8, C_eff, 2500]`` (preprocessed)
            token_meta: channel/band metadata for PP branch.
            x_raw:   ``[B, 8, 30, 2500]`` (raw, required)
            stats_raw: ``[B, 8, C_raw, 35]`` raw stats features (optional)
            stats_pp:  ``[B, 8, C_pp, 35]`` preprocessed stats features (optional)

        Returns:
            logits ``[B, 2]``
        """
        if x_raw is None:
            raise ValueError("DualBranchSubjectStateCNNTransformer requires x_raw")

        B = x.size(0)
        T = self.num_trials

        # --- Layer 1: Encode all trials with shared encoders ---
        raw_flat = x_raw.reshape(B * T, 30, -1)                   # [B*8, 30, 2500]
        pp_flat = x.reshape(B * T, x.size(2), -1)                # [B*8, C_eff, 2500]

        raw_feats = self.raw_encoder(raw_flat, token_meta=self._raw_token_meta)
        raw_feats = raw_feats.reshape(B, T, self.embedding_dim)   # [B, 8, D]

        pp_feats = self.pp_encoder(pp_flat, token_meta=token_meta)
        pp_feats = pp_feats.reshape(B, T, self.embedding_dim)     # [B, 8, D]

        # --- Stats feature injection (per-sample: mean-pool then broadcast) ---
        if self._use_stats and stats_raw is not None:
            raw_stats_sample = stats_raw.mean(dim=1)  # [B, 8, C_raw, 35] -> [B, C_raw, 35]
            pp_stats_sample = stats_pp.mean(dim=1)    # [B, 8, C_pp, 35] -> [B, C_pp, 35]
            raw_sel = self._normalize_stats(raw_stats_sample[..., self._feature_indices])
            pp_sel = self._normalize_stats(pp_stats_sample[..., self._feature_indices])
            raw_proj = self.raw_stats_mlp(raw_sel.flatten(1))   # [B, D]
            pp_proj = self.pp_stats_mlp(pp_sel.flatten(1))      # [B, D]
            raw_feats = raw_feats + raw_proj.unsqueeze(1)        # [B, 8, D]
            pp_feats = pp_feats + pp_proj.unsqueeze(1)           # [B, 8, D]

        # --- Layer 2: Interleave + embed ---
        # Interleave: (raw_0, pp_0, raw_1, pp_1, ...) -> [B, 16, D]
        interleaved = torch.stack([raw_feats, pp_feats], dim=2).reshape(
            B, 2 * T, self.embedding_dim
        )

        # Branch embedding: alternating 0,1,0,1,...
        branch_ids = torch.tensor(
            [0, 1] * T, device=interleaved.device
        )
        interleaved = interleaved + self.branch_embedding(branch_ids)

        # Trial position embedding: 0,0,1,1,2,2,...,7,7
        trial_ids = torch.tensor(
            [i // 2 for i in range(2 * T)], device=interleaved.device
        )
        interleaved = interleaved + self.trial_position_embedding(trial_ids)

        # --- Prepend CLS token ---
        cls = self.cls_token.expand(B, -1, -1)                    # [B, 1, D]
        tokens = torch.cat([cls, interleaved], dim=1)              # [B, 17, D]

        # --- Fusion Transformer ---
        fused = self.fusion_transformer(tokens)                    # [B, 17, D]

        # --- CLS pool + classify ---
        out = fused[:, 0, :]                                       # [B, D]
        return self.classification_head(out)                       # [B, 2]
