"""Multi-task loss for AllInOne model.

Supports three modes:
- weighted_sum: w_subj * BCE_subj + w_emo * BCE_emo
- uncertainty:  Kendall et al. learned task weighting
- per_trial:    w_subj * BCE_subj + w_emo * mean(BCE per trial)

Apache-2.0  --  SuShuHeng
"""

from __future__ import annotations

import torch
import torch.nn as nn
import torch.nn.functional as F


class MultiTaskLoss(nn.Module):
    """Multi-task binary cross-entropy loss for AllInOne model.

    Parameters
    ----------
    config : dict
        Training loss config. Expected keys:
        - ``type``: ``"weighted_sum"`` | ``"uncertainty"`` | ``"per_trial"``
        - ``subject_state_weight``: float (default 1.0)
        - ``emotion_weight``: float (default 1.0)
    """

    def __init__(self, config: dict) -> None:
        super().__init__()
        self.loss_type = config.get("type", "weighted_sum")
        self.w_subj = float(config.get("subject_state_weight", 1.0))
        self.w_emo = float(config.get("emotion_weight", 1.0))

        if self.loss_type not in ("weighted_sum", "uncertainty", "per_trial"):
            raise ValueError(
                f"Unknown multitask loss type: {self.loss_type!r}. "
                f"Choose from 'weighted_sum', 'uncertainty', 'per_trial'."
            )

        if self.loss_type == "uncertainty":
            # Learnable log-sigma parameters (Kendall et al., 2018)
            self.log_sigma_subj = nn.Parameter(torch.zeros(1))
            self.log_sigma_emo = nn.Parameter(torch.zeros(1))

    def forward(
        self,
        logits: torch.Tensor,
        targets: dict,
    ) -> dict:
        """Compute multi-task loss.

        Parameters
        ----------
        logits : torch.Tensor
            Model output ``[B, 9]``.
        targets : dict
            ``{"group_label": [B] int, "trial_emotion_labels": [B, 8] int}``

        Returns
        -------
        dict
            ``{"loss": scalar, "subject_loss": scalar, "emotion_loss": scalar}``
        """
        subject_logits = logits[:, 0]      # [B]
        emotion_logits = logits[:, 1:9]    # [B, 8]

        group_label = targets["group_label"].float()
        emotion_labels = targets["trial_emotion_labels"].float()

        bce_subj = F.binary_cross_entropy_with_logits(subject_logits, group_label)

        if self.loss_type == "weighted_sum":
            bce_emo = F.binary_cross_entropy_with_logits(emotion_logits, emotion_labels)
            total = self.w_subj * bce_subj + self.w_emo * bce_emo

        elif self.loss_type == "uncertainty":
            bce_emo = F.binary_cross_entropy_with_logits(emotion_logits, emotion_labels)
            precision_subj = torch.exp(-2 * self.log_sigma_subj)
            precision_emo = torch.exp(-2 * self.log_sigma_emo)
            total = (
                precision_subj * bce_subj + self.log_sigma_subj
                + precision_emo * bce_emo + self.log_sigma_emo
            ).squeeze()

        elif self.loss_type == "per_trial":
            bce_per_trial = F.binary_cross_entropy_with_logits(
                emotion_logits, emotion_labels, reduction="none"
            )  # [B, 8]
            bce_emo_mean = bce_per_trial.mean()
            total = self.w_subj * bce_subj + self.w_emo * bce_emo_mean
            bce_emo = bce_emo_mean

        return {
            "loss": total,
            "subject_loss": bce_subj.detach(),
            "emotion_loss": bce_emo.detach() if isinstance(bce_emo, torch.Tensor) else torch.tensor(float(bce_emo)),
        }
