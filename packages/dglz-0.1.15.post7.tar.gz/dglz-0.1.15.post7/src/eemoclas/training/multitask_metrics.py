"""Multi-task metrics for AllInOne model.

Computes per-task metrics (subject_state + emotion) independently.
No combined/weighted metric is computed.

Apache-2.0  --  SuShuHeng
"""

from __future__ import annotations

import numpy as np
from sklearn.metrics import (
    accuracy_score,
    cohen_kappa_score,
    confusion_matrix,
    f1_score,
    matthews_corrcoef,
    precision_score,
    recall_score,
    roc_auc_score,
)


def _compute_specificity(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    """Compute specificity = TN / (TN + FP)."""
    cm = confusion_matrix(y_true, y_pred, labels=[0, 1])
    if cm.shape == (2, 2):
        tn, fp = cm[0, 0], cm[0, 1]
        denom = tn + fp
        return round(tn / denom, 4) if denom > 0 else 0.0
    return 0.0


def _compute_auc(y_true: np.ndarray, y_prob: np.ndarray) -> float:
    """Compute ROC AUC, return 0.0 if not computable."""
    try:
        n_classes = len(np.unique(y_true))
        if n_classes < 2:
            return 0.0
        return round(float(roc_auc_score(y_true, y_prob)), 4)
    except ValueError:
        return 0.0


def _compute_task_metrics(
    loss: float,
    y_true: np.ndarray,
    y_pred: np.ndarray,
    y_prob: np.ndarray | None,
    prefix: str,
) -> dict:
    """Compute full metrics for one task, prefixed."""
    y_true = np.asarray(y_true)
    y_pred = np.asarray(y_pred)
    metrics = {
        f"{prefix}loss": round(loss, 4),
        f"{prefix}accuracy": round(accuracy_score(y_true, y_pred), 4),
        f"{prefix}f1": round(f1_score(y_true, y_pred, average="macro", zero_division=0), 4),
        f"{prefix}precision": round(precision_score(y_true, y_pred, average="macro", zero_division=0), 4),
        f"{prefix}recall": round(recall_score(y_true, y_pred, average="macro", zero_division=0), 4),
        f"{prefix}specificity": _compute_specificity(y_true, y_pred),
        f"{prefix}kappa": round(float(cohen_kappa_score(y_true, y_pred)), 4),
        f"{prefix}mcc": round(float(matthews_corrcoef(y_true, y_pred)), 4),
    }
    if y_prob is not None:
        metrics[f"{prefix}auc"] = _compute_auc(y_true, np.asarray(y_prob))
    return metrics


def compute_multitask_train_metrics(
    subject_loss: float,
    emotion_loss: float,
    total_loss: float,
    group_labels: np.ndarray,
    group_preds: np.ndarray,
    emotion_labels: np.ndarray,
    emotion_preds: np.ndarray,
) -> dict:
    """Compute training metrics for multi-task model."""
    result = {"total_loss": round(total_loss, 4)}
    result["subject_loss"] = round(subject_loss, 4)
    result["emotion_loss"] = round(emotion_loss, 4)
    result["subject_accuracy"] = round(accuracy_score(group_labels, group_preds), 4)
    result["emotion_accuracy"] = round(accuracy_score(emotion_labels, emotion_preds), 4)
    return result


def compute_multitask_val_metrics(
    subject_loss: float,
    emotion_loss: float,
    total_loss: float,
    group_labels: np.ndarray,
    group_preds: np.ndarray,
    group_probs: np.ndarray,
    emotion_labels: np.ndarray,
    emotion_preds: np.ndarray,
    emotion_probs: np.ndarray,
) -> dict:
    """Compute full validation metrics for multi-task model."""
    result = {"total_loss": round(total_loss, 4)}
    result.update(
        _compute_task_metrics(subject_loss, group_labels, group_preds, group_probs, "subject_")
    )
    result.update(
        _compute_task_metrics(emotion_loss, emotion_labels, emotion_preds, emotion_probs, "emotion_")
    )
    return result


# --- Constants for ResultsWriter integration ---

MULTITASK_CSV_COLUMNS = [
    "epoch",
    "train_subject_loss", "train_emotion_loss", "train_total_loss",
    "train_subject_accuracy", "train_emotion_accuracy",
    "val_subject_loss", "val_emotion_loss", "val_total_loss",
    "val_subject_accuracy", "val_emotion_accuracy",
    "val_subject_auc", "val_emotion_auc",
    "val_subject_f1", "val_emotion_f1",
    "val_subject_precision", "val_emotion_precision",
    "val_subject_recall", "val_emotion_recall",
    "val_subject_specificity", "val_emotion_specificity",
    "val_subject_kappa", "val_emotion_kappa",
    "val_subject_mcc", "val_emotion_mcc",
    "lr", "epoch_time",
]

# (key1, key2, title, ylabel, filename)
MULTITASK_DUAL_LINE_METRICS = [
    ("val_subject_accuracy", "val_emotion_accuracy", "Validation Accuracy", "Accuracy", "val_accuracy"),
    ("val_subject_auc", "val_emotion_auc", "Validation AUC", "AUC", "val_auc"),
    ("val_subject_f1", "val_emotion_f1", "Validation F1", "F1", "val_f1"),
    ("val_subject_precision", "val_emotion_precision", "Validation Precision", "Precision", "val_precision"),
    ("val_subject_recall", "val_emotion_recall", "Validation Recall", "Recall", "val_recall"),
    ("val_subject_specificity", "val_emotion_specificity", "Validation Specificity", "Specificity", "val_specificity"),
    ("val_subject_kappa", "val_emotion_kappa", "Validation Kappa", "Kappa", "val_kappa"),
    ("val_subject_mcc", "val_emotion_mcc", "Validation MCC", "MCC", "val_mcc"),
    ("train_subject_accuracy", "train_emotion_accuracy", "Training Accuracy", "Accuracy", "train_accuracy"),
    ("train_subject_loss", "train_emotion_loss", "Training Loss", "Loss", "train_loss"),
]
