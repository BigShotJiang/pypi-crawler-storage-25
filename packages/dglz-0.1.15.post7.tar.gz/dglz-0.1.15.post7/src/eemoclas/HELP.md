# DGLZ CLI 使用指南

> **版本**: 0.1.15.post7 | **命令行工具**: `eemo` | **Python 包**: `eemoclas`

---

## 目录

1. [项目简介](#1-项目简介)
2. [高级训练策略教程（版本更新适应性训练）](#2-高级训练策略教程版本更新适应性训练)
3. [安装与环境配置](#3-安装与环境配置)
4. [快速上手：从原始数据到提交文件](#4-快速上手从原始数据到提交文件)
5. [完整命令参考](#5-完整命令参考)
6. [配置文件参考](#6-配置文件参考)
7. [目录结构说明](#7-目录结构说明)
8. [权重初始化与训练恢复](#8-权重初始化与训练恢复)
9. [常见问题](#9-常见问题)

---

## 1. 项目简介

DGLZ 是一个基于 **三阶段 CNN-Transformer 层级分类器** 的 EEG 脑电情绪识别系统。流水线将任务分解为三个阶段：

```
原始 EEG (.mat)
       │
       ▼
┌──────────────────────────────┐
│ 第一阶段：被试状态分类        │  正常人 vs 抑郁症患者
│ model: SubjectStateCNNTransformer │
└──────────┬───────────────────┘
           │ 硬路由
     ┌─────┴─────┐
     ▼           ▼
┌─────────┐  ┌───────────────┐
│ 第二阶段 │  │ 第三阶段       │  中性 vs 积极
│ 正常人   │  │ 抑郁症患者     │
│ 情绪分类 │  │ 情绪分类       │
└─────────┘  └───────────────┘
     │           │
     └─────┬─────┘
           ▼
   提交文件 (.xlsx / .csv)
```

**七个分类器说明：**

**V1 单路模型（预处理分支 → 分类）：**

| 分类器 | 模型名称 | 输入形状 | 输出 | 任务 | 架构特点 |
|--------|----------|----------|------|------|----------|
| 分类器 1 | `subject_state` | `[B, 8, C_eff, 2500]` | `[B, 2]` | 正常人 / 抑郁症患者 | 含 `subject_transformer` 聚合 8 个试次 |
| 分类器 2 | `normal_emotion` | `[B, C_eff, 2500]` | `[B, 2]` | 中性 / 积极（正常人） | 逐试次独立分类 |
| 分类器 3 | `depression_emotion` | `[B, C_eff, 2500]` | `[B, 2]` | 中性 / 积极（抑郁症） | 逐试次独立分类，dropout 0.35 |

**V2 双路模型（Raw 分支 + 预处理分支 → Fusion Transformer 融合）：**

| 分类器 | 模型名称 | 输入形状 | 输出 | 架构特点 |
|--------|----------|----------|------|----------|
| 分类器 4 | `dual_subject_state` | `[B, 8, 30, 2500]` + `[B, 8, C_eff, 2500]` | `[B, 2]` | Trial-level 交错融合（16 tokens → Fusion TF），含统计特征注入 |
| 分类器 5 | `dual_normal_emotion` | `[B, 30, 2500]` + `[B, C_eff, 2500]` | `[B, 2]` | Late 融合（stack [2, D] → Fusion TF），含统计特征注入 |
| 分类器 6 | `dual_depression_emotion` | `[B, 30, 2500]` + `[B, C_eff, 2500]` | `[B, 2]` | 同 dual_normal_emotion，dropout 0.35 |

**V3 多任务模型：**

| 分类器 | 模型名称 | 输入形状 | 输出 | 架构特点 |
|--------|----------|----------|------|----------|
| 分类器 7 | `all_in_one` | `[B, 8, C_eff, 2500]` | `[B, 9]` | 共享 TrialCNN + Subject TF + 双 ClassificationHead（1 subject + 8 emotion），复用 subject_state 数据 |

### V0.1.15.post7 新特性

- **高级训练策略教程**：HELP.md 新增 Section 2「高级训练策略教程（版本更新适应性训练）」，面向有经验用户的保姆级训练优化指南
  - **策略一：大批次探索训练与学习率调优**：使用 batch_index 分批数据 + init-weight 权重初始化 + LR 区间扩展（`lr = best_lr × 2`、`min_lr = best_lr × 0.1`）+ `cosine_t_max` 递减收敛
  - **策略二：模型架构参数搜索**：系统性地调整 Transformer 层数/头数/维度等参数，对每个架构组合执行策略一的 LR 调参循环
  - **策略三：小批次精调微训**：基于最佳架构 + 最佳权重，使用小批次数据进行精调微训（小 lr + 短 epoch + 正则化）
  - **实验记录表格模板**：Markdown 表格模板用于记录跨实验的配置和指标对比
  - **完整工作流示例**：`subject_state` 全流程串联，从数据分批到最终微调
  - 每个策略均提供 **YAML 配置文件方式** 和 **CLI `-o` 覆盖方式** 两种展现形式

### V0.1.15.post6 修复

- **two_layer 重采样样本数修复**：`subject_state` 的 two_layer 模式下，`crops_per_segment` 原先仅影响 trial pool 大小，未参与 Layer 2 输出计数。修复后样本数按 `crops_per_segment × compositions_per_subject × permutations_per_draw` 乘法计算，与配置语义一致
  - **sample_id 格式更新**：`ss_{subject}_{d}_{k}` → `ss_{subject}_{crop_round}_{d}_{k}`
  - **meta 新增字段**：`crop_round` 记录高斯采样轮次

### V0.1.15.post5 新特性

- **预训练权重初始化 (`init-weight`)**：所有 7 个分类器支持从已有 `.ckpt` 文件加载 `model_state_dict` 作为权重初始化（不恢复训练状态），用于 transfer learning / fine-tuning 场景
  - **配置文件**：每个分类器的 `training.init_weight` 段独立配置 `path` 和 `strict`
  - **CLI 参数**：`--init-weight <path>` 全局覆盖 + `--init-weight-strict true/false` 控制加载模式
  - **两种加载模式**：`strict: true`（要求结构完全匹配）/ `strict: false`（默认，允许部分不匹配）
  - **与 `--resume` 互斥**：init-weight 仅加载权重，训练从 epoch 1 开始
  - **日志 + Rich 输出**：权重加载时记录路径、strict 模式、missing/unexpected keys
- **配置面板模型过滤**：`eemo train` 的配置面板仅展示本次参与训练的分类器的配置变量，全局段（project/signal/experiment 等）始终展示

### V0.1.15.post4 新特性

- **HELP.md 全面文档更新**：文档覆盖全部 7 个分类器（V1 单路 × 3 + V2 双路 × 3 + V3 多任务 × 1）
  - **7 分类器详细说明**：每个分类器的架构、输入输出、训练配置差异一览表
  - **`eemo tool data-to-batchs-index` 命令文档**：完整的 CLI 参数说明和使用示例
  - **训练配置变量全面说明**：`data_source`（full/batch_index 模式）、`preload`（内存预加载）、`cosine_t_max`（余弦退火周期）、`stats_features`（统计特征注入）
  - **`--resume` 恢复训练使用方法**：自动恢复 / 指定路径恢复 / 强制重训 + K-fold 折级恢复
  - **权重初始化说明**：`seeding.init_seed` 三级种子控制确定性权重初始化

### V0.1.15.post1 新特性

- **调度器余弦退火周期配置**: 所有 7 个分类器的 `train_full.yaml` 配置中新增 `cosine_t_max` 字段，显式控制余弦退火周期（默认等于 epochs，可自定义实现 warm restart）
- **`eemo tool data-to-batchs-index` CLI 命令**: 新增 `eemo tool` CLI 组及其第一个子命令，支持从重采样 manifest 中按指定大小不放回抽取，生成 batch CSV 索引文件 + remainder CSV + 摘要 JSON
- **训练数据集 batch_index 模式**: `train_full.yaml` 所有模型新增 `data_source` 配置段，支持 `batch_index` 模式通过 CSV 索引文件加载指定子集

### V0.1.15 新特性

- **V3 All-in-One 多任务分类器**: 新增 `AllInOneCNNTransformer` 模型（`all_in_one`），输入 `[B, 8, C_eff, 2500]`，输出 `[B, 9]`（1 个 subject state 二分类 + 8 个 trial emotion 二分类）
  - 共享 TrialCNNTransformer + Subject Transformer + CLS token + 双 ClassificationHead
  - 支持三种多任务损失: `weighted_sum`（默认）/ `uncertainty`（Kendall 自动权重）/ `per_trial`（逐 trial 独立计算）
  - 两个分类头各自独立输出 9 项指标: accuracy/AUC/F1/precision/recall/specificity/kappa/MCC/loss
  - 支持 `best_checkpoints` 配置，可自定义多个最佳权重保存（任意 subject_*/emotion_*/total_* 指标）
  - 训练 Plot 生成 subject/emotion 双线对比图
  - CSV 扩展至 ~27 列
  - 完全兼容训练中断恢复、数据预加载、早停等现有功能

### V0.1.14 新特性

- **频域/时域统计特征注入 Dual-Branch 模型**：为 V2 双路分类器新增 35 维 per-channel 统计特征提取与注入
  - **35 个特征**：band power (16) + FFT direct (3) + time-domain (8) + Hjorth (3) + spectral shape (5)
  - **重采样阶段预生成**：`eemo resample` 自动在样本 .pt 文件中保存 `stats_raw` 和 `stats_pp`
  - **配置可选**：每个 dual_* 分类器通过 `stats_features` 段独立选择使用的特征子集
  - **残差注入**：2 层 MLP (Linear→BatchNorm→ReLU→Dropout→Linear) 投影后残差加到 Fusion Transformer 输入
  - **向后兼容**：旧样本无 stats 字段时自动跳过，旧配置无 stats_features 段时默认禁用
- **C_eff 自动解析**：训练时从重采样 `config_snapshot.yaml` 自动推断有效通道数，不再依赖 YAML 硬编码 `input_channels`
  - V1 单路模型：自动注入 `trial_encoder.input_channels`
  - V2 双路模型：自动注入 `pp_trial_encoder.input_channels`（Raw 分支保持 30 通道）
- **配置清理**：移除 `train_full.yaml` 中训练阶段不使用的冗余字段（`channels`、`band_definitions`、`channel_band_config`、`input_channels`）

### V0.1.14.post4 修复

- **Windows DataLoader pickle 兼容性**：修复 Windows 下 `num_workers > 0` + 预加载启用时 `TypeError: cannot pickle '_thread.RLock'` 错误
  - **根因**：`CompressedPreloader` 持有 `PreloadDisplay` → Rich `Console` → `threading.RLock`，Windows spawn 模式需 pickle 数据集
  - **修复**：`CompressedPreloader` 新增 `__getstate__`/`__setstate__`，pickle 时排除 `_display`（工作进程无需 display）
- **C_eff 数据驱动检测**（替代 config_snapshot 解析）
  - **检测优先级**：manifest CSV `c_eff` 列 → 数据集第一个样本 tensor shape → 报错退出
  - **Dual-branch 校验**：`pp_trial_encoder.input_channels` 缺失或为 0 时抛出明确 `ValueError`，而非静默使用错误默认值
- **Orchestrator 测试重构**：`TestCEffResolution` → `TestCEffDetection`，覆盖 manifest/sample/优先级/报错路径

### V0.1.14.post3 新特性

- **训练 Plot 实时生成**：每 epoch 通过后台线程自动生成 PNG 图片（loss、accuracy、AUC、F1、LR、epoch_time + train/val 对比曲线），训练过程中可实时查看
- **CSV 指标增强**：新增 `epoch_time` 列记录每 epoch 耗时，移除已弃用的 `val_balanced_accuracy`
- **训练中断/恢复**：完整三层保障机制
  - 自动发现：训练启动时自动检测 `latest_model.ckpt`，存在则自动恢复
  - `--resume` 指定路径：手动指定 checkpoint 路径恢复训练
  - `--fresh` 强制重训：跳过自动恢复，从头开始训练
  - Ctrl+C 优雅中断：捕获中断信号，保存 checkpoint + 刷新 plot 后退出
- **增强 Checkpoint**：现在保存 scheduler 状态、训练历史、最佳指标值、early stopping 状态，实现完整训练恢复
- **K-fold 折级恢复**：K-fold 训练中断后可精确到 fold+epoch 粒度恢复，已完成的 fold 自动跳过
- **日志对齐**：恢复训练时 training.log 连续追加（不写重复 header），plot 从完整历史重新生成，CSV-checkpoint 一致性校验

### V0.1.14.post2 修复

- **C_eff 数据驱动自动检测**：训练时 C_eff 不再依赖 `config_snapshot.yaml` 解析，改为从数据集自动检测。优先级：manifest CSV 的 `c_eff` 列 → 第一个样本的 tensor shape → 报错。消除因配置快照缺失/损坏导致 `input_channels=0` 的 RuntimeError

### V0.1.14.post1 修复

- **Stats MLP 零维度临时修复**（已被 V0.1.14.post2 替代）

### V0.1.13.post2 新特性

- **`eemo agent claude --mode v1/v2`**：Agent 部署支持 V1/V2 双模式
  - **V1（默认）**：两阶段单路训练（subject_state → normal_emotion + depression_emotion），Stage 2 门控
  - **V2**：三阶段双路训练（dual_subject_state, dual_normal_emotion, dual_depression_emotion），阶段独立无门控
- **共享 skill 脚本参数化**：所有 skill 脚本（configs_creator, configs_runner, get_results, move_exp, agent-state）通过 `--mode v1/v2` 参数支持双模式
- **active_state.json**：全局训练状态文件（`.agent/active_state.json`）跟踪当前 mode、stage、batch、step
- **V1 state 自动迁移**：旧版用户升级后自动将 `.agent/dglztr/` 迁移至 `.agent/v1/dglztr/`

### V0.1.13.post1 修复

- **Ctrl+C 优雅退出修复**：修复 Ctrl+C 无法完全终止 CLI 的问题
  - **全局中断兜底**：所有 `eemo` 命令按 Ctrl+C 后立即退出，显示"操作已取消"（exit code 130）
  - **训练中断捕获**：`eemo train` 训练中按 Ctrl+C 显示"训练已中断，正在清理资源..."
  - **Rich Live 线程清理**：训练面板的 Rich Live 线程在 finally 块中确保停止，不再残留
  - **DataLoader 进程终止**：并行训练模式下子进程通过 join(timeout) + terminate 确保退出
  - **预加载显示清理**：PreloadDisplay 添加 __del__ 安全网 + try/finally 确保线程停止
  - **重采样进程取消**：`eemo resample` 并行模式下 Ctrl+C 取消所有 Future 并强制关闭进程池

### V0.1.13 新特性

- **`eemo update` 功能对齐**：`eemo update` 命令全面功能对齐 JwzTumor `jwzt update`
  - **3 次 pip 重试策略**：精确版本安装 → 回退 `--upgrade` → 二次 `--upgrade`，提高安装成功率
  - **`--no-cache-dir`**：避免 CDN 缓存导致获取旧版本
  - **移除硬编码 `--index-url`**：使用用户配置的 pip 源（镜像/代理），适配国内网络环境
  - **结构化操作日志**：`~/.dglz/update.log` 采用 `[ACTION] | detail` 格式，记录 ALREADY_LATEST / SUCCESS / FAILED / DETACHED 四种状态
  - **Windows .bat 脚本增强**：3 次重试逻辑与 Linux 一致，每阶段写入日志，完善错误处理（生成/写入/启动各环节独立 try/except）
  - **自动检测审计**：`~/.dglz/update_detect.json` 记录每次版本检测的详细结果（success/cache_hit/network_error），便于排查更新问题
  - **平台检测优化**：使用 `sys.platform == "win32"` 替代 `platform.system()`
  - **自动检测修复**：修复 `eemo` 命令执行后版本更新提示和 `update_detect.json` 不生成的问题（Typer 的 `SystemExit` 阻止了检测逻辑执行）

### V0.1.12 新特性

- **`eemo update` 命令**：新增 `eemo update` 命令，支持自动检测 PyPI 最新版本并执行 `pip install` 升级。更新成功后在当前目录生成 `UPDATE.md` 文件（覆盖式），包含当前版本到最新版本的更新日志和迁移步骤
- **版本自动检测**：每次执行 `eemo` 命令时自动检测 PyPI 最新版本（10 分钟缓存 + 3s 超时跳过），有新版本时在终端末尾显示黄色提示。更新日志以 CSV 格式随 package 打包分发。缓存和更新日志存储在 `~/.dglz/` 目录

### V0.1.12.post1 修复

- **更新检测缓存优化**：版本检测缓存从 3 小时缩短为 10 分钟，缓存目录从 `~/.eemo/` 迁移至 `~/.dglz/`
- **更新日志记录**：`eemo update` 执行成功后自动追加记录到 `~/.dglz/update.log`，包含时间戳和版本变更信息

### V0.1.12.post2 修复

- **Windows 自更新修复**：修复 Windows 下 `eemo update` 因 `eemo.exe` 被当前进程锁定导致更新失败的问题。Windows 下自动使用分离的后台 `.bat` 脚本执行 pip install，避免文件锁冲突
- **更新失败恢复指引**：pip 安装失败时显示手动恢复命令 `pip install DGLZ --upgrade`

### V0.1.4 新特性

- **统一配置格式**：`train_full.yaml` 将三个分类器配置合并为单一文件
- **多模型训练**：支持顺序/并行/混合训练模式
- **点分键值覆盖**：通过 `--override` 在命令行动态修改配置
- **Dataclass 强类型配置系统**：31 个类型化配置类，支持 IDE 自动补全和运行时校验
- **实验管理**：统一输出目录 `experiments/{name}/`，含检查点、日志、指标、结果子目录
- **Rich 终端美化**：双面板实时显示、配置面板、训练摘要表格
- **增强优化器/调度器**：3 种优化器（adamw/adam/sgd）、6 种调度器（cosine/cosine_warmup/cosine_warmrestarts/steplr/plateau/onecycle）+ warmup 支持
- **增强配置校验**：自动检测配置格式，校验必填字段并计算有效通道数

### V0.1.6 新特性

- **多线程重采样**：`eemo resample --workers N` 支持多线程并行处理被试数据，显著加速重采样流程
- **`pip install DGLZ`**：支持用户直接通过 PyPI 安装和升级
- **配置变量增强**：标签平滑、梯度裁剪、Holdout 划分模式、详细调度器参数、实验注释等
- **实验注释**：`experiment.notes` 字段支持记录调参目的和参数变更原因

### V0.1.7 新特性

- **训练流水线修复**：完整实现多模型训练编排器，支持端到端训练（数据加载→模型创建→训练循环→检查点保存）
- **Rich 重采样进度条**：重采样过程显示实时进度条（旋转器、进度条、计数、耗时）
- **Dict 批次支持**：Trainer 现在支持字典格式批次数据（x/y/token_meta），兼容 ResampledTensorDataset

### V0.1.8 新特性

- **完整配置面板**：训练启动前显示全部配置变量（含每模型的 optimizer/scheduler/model/splitting/seeding/augmentation）
- **训练日志生成**：自动写入 `experiments/{name}/logs/training.log`，记录完整训练过程
- **日志排版优化**：采用紧凑单行 epoch 格式，便于 grep 和解析

### V0.1.8.post1 新特性

- **多核并行重采样**：`eemo resample -w N` 使用 `ProcessPoolExecutor`（spawn 模式）绕过 GIL，真正利用多核 CPU 加速 bandpass 滤波等 CPU 密集操作
- **进度条剩余时间**：Rich 进度条新增预计剩余时间（ETA）显示

### V0.1.8.post2 新特性

- **K-Fold 交叉验证**：完整实现 `StratifiedGroupKFold` 多折训练循环，支持跨折指标聚合（mean/std/per-fold values）
- **KFold 目录隔离**：holdout 产物放在 `checkpoints/{model}/` 根级，kfold 产物放在 `fold_{i}/` 子目录，互不干扰
- **最佳折拷贝**：根据 `checkpoint_metric` 选出最优折，将检查点拷贝到 `fold_best/`
- **`kfold_summary.yaml`**：跨折聚合指标文件，含每折详情 + 全局 mean/std
- **训练状态追踪**：`training_state.yaml` 支持 fold 级别状态更新

### V0.1.8.post3 新特性

- **配置变量修复**：`early_stopping_patience` 现在正确从配置文件读取（之前因嵌套字典路径错误而始终默认为 15）
- **`save_best` / `save_latest` 支持**：Trainer 现在正确读取并遵守配置中的 `save_best` 和 `save_latest` 标志
- **SilentProgressBar 修复**：修复非 verbose 模式下多折训练的 TypeError

### V0.1.8.post4 新特性

- **训练终端输出优化**：verbose 模式下移除进度条上方的重复日志输出，终端仅显示配置面板、进度条和 Log 面板
- **Log 面板行数限制**：限制为 30 行，新日志出现在面板底部，超出时自动移除顶部旧日志

### V0.1.8.post5 新特性

- **PyTorch 调度器警告修复**：修复 warmup 包装器中 `get_lr()` 触发的 PyTorch `UserWarning`（"To get the last learning rate..."）
- **训练警告抑制**：训练期间自动抑制所有 `UserWarning`（如 `enable_nested_tensor` 等），确保终端输出整洁不被警告打断

### V0.1.8.post6 新特性

- **智能浮点数格式化**：Log 面板和日志文件的浮点数精度优化，指标最多支持小数点后 8 位（自动去除尾随零），学习率使用科学计数法（如 `3.00e-04`），整数值（如 epoch）无小数点

### V0.1.9 新特性

- **训练智能体系统**：`eemo agent claude --path .claude/` 部署 dglztr/dglzvr 双智能体训练系统，含 7 个自定义 skill、记忆模板和状态管理

### V0.1.9.post1 新特性

- **结构化早停配置**：新增 `early_stop` 嵌套配置（取代旧 `early_stopping_patience` 扁平键），支持开关 `enable`、耐心值 `patience`、监督指标 `early_metric`、模式 `metric_mode`、最小改进阈值 `up_delta`
- **结构化最佳模型监控**：新增 `monitor_best` 嵌套配置（取代旧 `checkpoint_metric`/`save_best`/`save_latest`），支持主监控指标 `monitor_metric`、模式 `metric_mode`、最新检查点 `save_latest`、额外保存最佳 AUC `save_best_auc`、额外保存最佳准确率 `save_best_acc`
- **多最佳检查点保存**：训练器现可同时保存 `best_model.ckpt`（主监控指标）、`best_val_auc.ckpt`（最佳 AUC）和 `best_val_accuracy.ckpt`（最佳准确率）
- **向后兼容**：旧的 `early_stopping_patience`、`checkpoint_metric`、`save_best`、`save_latest` 扁平键仍可用，自动回退

### V0.1.9.post2 新特性

- **配置面板浮点数格式优化**：配置面板的浮点数精度从固定 4 位小数改为自适应格式——学习率等小数值使用科学计数法（如 `1.0e-03`），其他浮点数最多支持 6 位小数并自动去除尾随零
- **统一格式化函数**：`_fmt()` 和 `_format_value()` 均采用相同的智能格式化规则

### V0.1.9.post3 修复

- **`eemo agent claude` 路径修复**：修复目标路径层级较少时（如 Windows `F:\dglz\.claude`）`_copy_tree` 的 `IndexError`，改用动态基准目录计算相对路径

### V0.1.9.post4 修复

- **`exp-train` K-Fold 兼容**：`list`/`summary`/`compare`/`clean` 现在正确识别 K-Fold 实验目录（`fold_best/best_model.ckpt`），不再误报为"未找到"或"失败"
- **`ckpt list` K-Fold 兼容**：递归扫描 `fold_0/`、`fold_1/` 等 K-Fold 子目录中的检查点文件

### V0.1.10 新特性

- **Focal Loss 支持**：新增 `FocalLoss` 损失函数，用于处理类别不平衡问题。通过 `training.loss: "focal"` 启用，支持聚焦参数 `focal_gamma`（默认 2.0，gamma=0 等同交叉熵）、类别权重 `class_weight` 和标签平滑 `label_smoothing`

### V0.1.10.post1 新特性

- **数据增强管线修复**：修复配置中启用 `augmentation.enabled: true` 但训练时未实际应用的 bug。现在 GaussianNoise、TimeMask、ChannelDropout 三种增强在 `train_epoch()` 中正确应用（仅在训练阶段，不影响验证）
- **Mixup 数据混合**：新增 Mixup 正则化技术，通过 `training.mixup_alpha` 配置（0.0=禁用，推荐起始值 0.2），对小数据集缓解过拟合有效
- **SWA 随机权重平均**：新增 SWA 支持，通过 `training.swa_start_epoch` 配置（0=禁用，推荐总 epochs 的 75%），训练后期平均权重提升泛化能力，通常可免费提升 1-3% 准确率

### V0.1.10.post2 修复

- **重采样 per_target 配置修复**：修复 `resample.yaml` 中 `per_target` 配置项在 dataclass 类型转换时丢失的 bug，导致 `samples_per_subject` 等参数始终使用默认值而非用户配置值
- **重采样 manifest 去重**：`write_manifest()` 自动按 `sample_id` 去重；`_load_subject_list()` 按 `subject_id` 去重，防止源 CSV 中的重复被试记录生成重复样本
- **`ckpt export` K-Fold 兼容**：自动查找 `fold_best/best_model.ckpt` 作为 K-Fold 最佳检查点

### V0.1.10.post3 新特性

- **subject_state 两层级重采样**：新增 `two_layer` 模式，支持按被试组别（正常人/抑郁症患者）独立配置裁剪次数（`crops_per_segment`）、抽取次数（`compositions_per_subject`）和排列数（`permutations_per_draw`），实现样本级别的 1:1 类标平衡
- **emotion 双模式重采样**：新增 `emotion_mode` 配置项，支持 `independent`（独立采样，默认）和 `coupled`（由 subject_state 捆绑生成）两种模式。`coupled` 模式下 emotion 分类器的数据集数量由 subject_state 的 trial pool 直接派生

### V0.1.10.post4 修复

- **两层级重采样并行化修复**：修复 `_run_two_layer()` 使用手动顺序循环绕过 `_parallel_map()` 的 bug，导致 `--workers` 多线程参数无效，CPU 占用率低。现在两层级模式正确使用 `_parallel_map()` 支持多进程并行

### V0.1.10.post5 新功能

- **原始数据输出**：`eemo resample` 新增 `save_raw` 配置项和 `--save-raw` CLI 标志。启用后，重采样同时输出原始未预处理数据（30 通道 × 2500 采样点），保存为独立的 `_raw.pt` 文件，manifest 新增 `raw_sample_path` 列。支持全部三个分类器（subject_state, normal_emotion, depression_emotion），subject_state two_layer 模式的 coupled emotion 也支持 raw 输出

### V0.1.11 新特性

- **双路模型架构**：新增 3 个 DualBranch 模型（dual_subject_state, dual_normal_emotion, dual_depression_emotion），使用独立的 Raw 分支（30 通道原始 EEG）+ 预处理分支（C_eff 通道）→ Fusion Transformer 融合架构。Emotion 模型使用 Late Fusion（stack [B,2,D] → Fusion TF），Subject State 模型使用 Trial-level Fusion（interleave [B,16,D] → Fusion TF）
- **双路训练支持**：Trainer 和 Orchestrator 自动检测 `dual_` 前缀模型名，设置 `load_raw=True` 加载原始数据，通过 `x_raw` 参数传递给模型前向传播
- **双路推理支持**：`eemo infer-three-stage` 新增 `--dual-branch` 标志，自动使用 `dual_` 前缀模型，在预处理前保存原始数据
- **数据集 load_raw**：所有数据集类新增 `load_raw` 参数，从 manifest 的 `raw_sample_path` 列加载原始 .pt 文件

### V0.1.11.post1 修复

- **单路模型 forward 签名兼容**：为三个单路模型（SubjectStateCNNTransformer、NormalEmotionCNNTransformer、DepressionEmotionCNNTransformer）的 `forward()` 方法添加 `x_raw` 参数，修复 Trainer 和推理流水线传递 `x_raw` 关键字参数时的 TypeError

### V0.1.11.post2 修复

- **双路模型配置注释补全**：为 `train_full.yaml` 中三个双路模型配置段添加完整的中文变量注释（任务定义、模型结构、训练超参数、数据划分、种子管理），与单路模型配置注释风格保持一致

### V0.1.11.post3 新特性

- **内存预加载**：训练数据 float16 压缩后渐进式预加载到内存，减少每 epoch 磁盘 I/O。内存充足时全量常驻，不足时自动切换动态滑动窗口（队尾进/队头出，实时感知空余内存）
- **并行安全**：100% 加载完成后才升级为全量模式，杜绝多分类器同时启动的 OOM 竞态
- **跨平台**：Linux（`/proc/meminfo`）+ Windows（`ctypes`）+ macOS（`sysctl`），基于空余内存计算预算，保留 5% 给系统
- **配置**：所有模型新增 `preload` 段，默认启用（`compression: float16`, `system_reserve_ratio: 0.05`, `skip_meta: true`）

### V0.1.11.post4 修复

- **配置快照保留**：训练实验的 `config.yaml` 现在直接复制用户原始 YAML 配置文件，保留所有变量注释、顺序和未映射字段（如 `experiment.notes`）

### V0.1.11.post5 新特性

- **K-fold 预加载复用**：内存充足时数据只加载一次，所有 fold 共享全量缓存；内存不足时自动回退逐 fold 流式加载
- **预加载可视化**：`--verbose` 模式下实时显示 Rich 面板（预加载进度条 + 内存占用 + DEBUG 日志子面板），全量加载完成后面板自动消失

### V0.1.11.post6

- **移除 balanced_accuracy 指标**：由于重采样后数据集已平衡（1:1），`balanced_accuracy` 与标准 `accuracy` 等价，全面移除 `balanced_accuracy`/`val_balanced_accuracy`，统一使用 `accuracy`/`val_accuracy`
  - 训练指标、早停监控、最佳模型保存、检查点文件名、CSV 输出、终端显示全面更新
  - 检查点文件名：`best_val_balanced_accuracy.ckpt` → `best_val_accuracy.ckpt`
- **双路模型配置对齐**：
  - `preload` 预加载配置扩展至全部 6 个模型（原先仅 `subject_state`）
  - 双路模型 `augmentation` 增加 PP/RAW 独立分支配置结构
  - 新增 `BranchAugmentationConfig` 数据类及对应 loader 支持

### V0.1.11.post8 修复

- **预加载面板 holdout 模式缺失**：修复 holdout/流式模式下 `prepare_epoch()` 未调用 `PreloadDisplay` 生命周期方法（start/update/finish）的 BUG，现在 holdout 模式下也能正常显示预加载进度面板和进度条
- **移除 DEBUG 子面板**：移除预加载面板中的 DEBUG 日志子面板，消除显示闪烁及与训练进度条的冲突
- **流式模式面板常驻**：非全量加载（流式模式）时预加载进度面板保持可见，不再自动消失

### V0.1.11.post9 新特性

- **动态流式内存预加载优化**：非全量预加载模式下，系统自动感知内存变化并动态调整缓存比例：
  - **内存空闲扩展**：当系统内存持续空闲 60 秒以上时，自动停止逐出已消耗样本，扩大缓存窗口，提升预加载百分比
  - **内存压力收缩**：当系统内存需求增加时，主动逐出缓存以维持 `system_reserve_ratio` 百分比的空闲内存
  - **自动升级全量模式**：流式模式下若缓存扩展至 100% 覆盖所有样本，自动升级为全量模式（后续 epoch 不再逐出）
  - **状态日志**：空闲↔压力状态切换时输出日志，便于监控

---

## 2. 高级训练策略教程（版本更新适应性训练）

> **面向有经验的用户**：本节介绍如何利用 `eemo` 的分批训练、预训练权重初始化、学习率调参循环等功能，系统性地优化分类器性能。
>
> **前置条件**：已完成重采样（`eemo resample`），拥有重采样 manifest CSV 文件。
>
> **核心理念**：将大量重采样数据分为多个递减批次 → 先用大批次数据探索最佳学习率 → 搜索最佳模型架构参数 → 最后用小批次数据微调精炼。

---

### 2.1 前置准备 — 数据分批

当重采样数据量较大（例如 ~80000 个样本）时，不建议一次性全部用于训练。更好的做法是将数据分为多个**数量逐渐减少的批次**：

| 批次 | 样本数 | 用途 |
|------|--------|------|
| `batch_001` | 50000 | 探索训练 + 学习率调优（策略一） |
| `batch_002` | 20000 | 中等规模微调（策略三） |
| `batch_003` | 10000 | 小规模精调（策略三） |

**分批命令示例**（以 `subject_state` 为例）：

```bash
# 从 subject_state 的重采样 manifest 中抽取 3 个批次
eemo tool data-to-batchs-index \
  --manifest data/resampled/subject_state/version_001/manifest.csv \
  --output-dir data/batchs/subject_state/run001 \
  --batch-sizes 50000,20000,10000 \
  --seed 42 --verbose
```

**生成的文件：**

```
data/batchs/subject_state/run001/
├── batch_001.csv       # 第 1 批（50000 个样本的 manifest 行）
├── batch_002.csv       # 第 2 批（20000 个样本）
├── batch_003.csv       # 第 3 批（10000 个样本）
├── remainder.csv       # 未分配的剩余样本（本次示例中为 0 行）
└── summary.json        # 摘要信息（batch_sizes, total, seed 等）
```

**通用模板**（替换 `<model_name>` 为你的分类器名称）：

```bash
eemo tool data-to-batchs-index \
  --manifest data/resampled/<model_name>/version_001/manifest.csv \
  --output-dir data/batchs/<model_name>/run001 \
  --batch-sizes <大>,<中>,<小> \
  --seed 42 --verbose
```

> **提示**：`batch-sizes` 的总和不应超过 manifest 中的样本总数。使用 `--verbose` 查看 Rich 面板输出和批次摘要表格。

---

### 2.2 策略一：大批次探索训练与学习率调优

本策略使用最大的 `batch_001` 数据进行训练，通过多轮迭代找到当前模型架构下的**最佳学习率**和**最佳权重**。

#### 子阶段 A：首次探索训练

**目标**：使用 `batch_001`（50000 样本）进行首次长周期训练，获取 baseline 权重和 `best_lr`（训练过程中验证指标最佳时的学习率）。

**方式一：修改 train_full.yaml 配置文件**

在配置文件中找到目标分类器的 `training:` 段，按以下关键变量调整：

```yaml
    training:
      data_source:                           # ← 修改：使用 batch_index 模式
        mode: "batch_index"
        batch_index_csv: "data/batchs/subject_state/run001/batch_001.csv"
      init_weight:
        path: null                           # ← 首次训练：不使用预训练权重
        strict: false
      epochs: 200                            # ← 修改：长训练周期（原默认 100）
      optimizer:
        lr: 1.0e-3                           # ← 初始学习率（典型起点 1e-3）
      scheduler:
        cosine_t_max: 200                    # ← 修改：等于 epochs（原默认 100）
        min_lr: 1.0e-6                       # ← 最低学习率
      early_stop:
        patience: 20                         # ← 修改：给够耐心（原默认 15）
      monitor_best:
        save_best_auc: true                  # ← 修改：保存 best_val_auc.ckpt 供后续 init-weight 使用
        save_best_acc: true
```

**方式二：使用 CLI `-o` 覆盖（不修改配置文件）**

```bash
eemo train --config configs/train_full.yaml -m subject_state \
  -o models.subject_state.training.data_source.mode=batch_index \
  -o models.subject_state.training.data_source.batch_index_csv=data/batchs/subject_state/run001/batch_001.csv \
  -o models.subject_state.training.epochs=200 \
  -o models.subject_state.training.optimizer.lr=0.001 \
  -o models.subject_state.training.scheduler.cosine_t_max=200 \
  -o models.subject_state.training.early_stop.patience=20 \
  -o models.subject_state.training.monitor_best.save_best_auc=true \
  --experiment-name subject_state_exp001 \
  --verbose
```

**训练后操作：**

1. 打开实验目录中的 `logs/` 文件夹，找到 `metrics_history.csv`
2. 找到 `val_auc` 最大的那一行（即 `best_val_auc` 对应的 epoch）
3. 记录该行的以下值到实验记录表格（见 [2.5 节](#25-实验记录表格模板)）：
   - `val_accuracy` → `best_val_acc`
   - `val_auc` → `best_val_auc`
   - `lr` → **`best_lr`**（这是后续调参的关键参考值）
4. 记录 `best_val_auc.ckpt` 的完整路径，下一轮训练将用此权重进行 init-weight 初始化

#### 子阶段 B：LR 调参循环

**目标**：基于上一轮的 `best_lr`，通过 init-weight 加载上一轮最佳权重，扩展学习率搜索区间，逐步缩小 `cosine_t_max` 收敛到最优 lr。

**LR 区间扩展策略：**

| 参数 | 计算方式 | 说明 |
|------|---------|------|
| `lr`（本轮初始学习率） | `best_lr × 2` | 以 best_lr 为基准，向上扩展 2 倍 |
| `min_lr`（本轮最小学习率） | `best_lr × 0.1` | 以 best_lr 为基准，向下扩展 10 倍 |
| `cosine_t_max` | 逐轮递减：200→175→155→140→125→... | 每轮减少 15-25，根据收敛趋势灵活判断 |
| `epochs` | 保持 200 | 给足训练空间 |
| `init_weight.path` | 上一轮的 `best_val_auc.ckpt` | 加载上一轮最佳权重作为起点 |

> **为什么缩小 cosine_t_max？**：随着训练轮次推进，模型已接近最优区域，不需要完整 200 epoch 的余弦周期。缩短周期让学习率更快从 `lr` 降到 `min_lr`，实现更精细的参数搜索。

**第 2 轮调参示例**（假设第 1 轮 `best_lr = 3.5e-4`）：

**方式一：修改 train_full.yaml 配置文件**

```yaml
    training:
      data_source:
        mode: "batch_index"
        batch_index_csv: "data/batchs/subject_state/run001/batch_001.csv"
      init_weight:
        path: "experiments/subject_state_exp001/checkpoints/subject_state/best_val_auc.ckpt"  # ← 修改：加载上轮最佳权重
        strict: false                         # ← 宽松模式（允许少量 key 不匹配）
      epochs: 200                             # ← 保持 200
      optimizer:
        lr: 7.0e-4                            # ← 修改：best_lr × 2 = 3.5e-4 × 2
      scheduler:
        cosine_t_max: 175                     # ← 修改：从 200 递减到 175
        min_lr: 3.5e-5                        # ← 修改：best_lr × 0.1 = 3.5e-4 × 0.1
      early_stop:
        patience: 20
      monitor_best:
        save_best_auc: true
        save_best_acc: true
```

**方式二：使用 CLI `-o` 覆盖**

```bash
eemo train --config configs/train_full.yaml -m subject_state \
  --init-weight experiments/subject_state_exp001/checkpoints/subject_state/best_val_auc.ckpt \
  --init-weight-strict false \
  -o models.subject_state.training.data_source.mode=batch_index \
  -o models.subject_state.training.data_source.batch_index_csv=data/batchs/subject_state/run001/batch_001.csv \
  -o models.subject_state.training.epochs=200 \
  -o models.subject_state.training.optimizer.lr=0.0007 \
  -o models.subject_state.training.scheduler.min_lr=3.5e-5 \
  -o models.subject_state.training.scheduler.cosine_t_max=175 \
  -o models.subject_state.training.early_stop.patience=20 \
  -o models.subject_state.training.monitor_best.save_best_auc=true \
  --experiment-name subject_state_exp002 \
  --verbose
```

**第 3 轮及后续**：重复上述流程，将 `init_weight.path` 指向上一轮的 `best_val_auc.ckpt`，根据上一轮新的 `best_lr` 重新计算 `lr` 和 `min_lr`，继续递减 `cosine_t_max`。

**循环终止条件**：连续 2-3 轮 `best_val_auc` 提升幅度 < 0.5% 时，可认为当前架构参数下的最佳 lr 已找到。

**注意事项：**

- `--init-weight` 与 `--resume` **互斥**，不能同时使用。init-weight 仅加载模型权重，训练从 epoch 1 重新开始
- 每轮训练使用**不同的 `--experiment-name`**，避免检查点目录冲突
- `cosine_t_max` 不建议低于 ~50（周期太短，学习率无法充分衰减）
- 所有训练结果记录到实验表格（见 [2.5 节](#25-实验记录表格模板)），便于横向比较

---

### 2.3 策略二：模型架构参数搜索

在策略一找到当前架构的最佳 lr 后，可以尝试调整 Transformer 的架构参数（如层数、头数、维度等），对每个新架构组合重复策略一的 LR 调参循环，找到该架构下的最佳权重和 lr。

**可调整的架构参数：**

| 参数 | 默认值 | 推荐尝试值 | 配置路径（以 subject_state 为例） |
|------|--------|-----------|-------------------------------|
| Transformer 层数 | 2 | 3, 4 | `models.subject_state.model.trial_encoder.transformer.num_layers` |
| 注意力头数 | 4 | 2, 8 | `models.subject_state.model.trial_encoder.transformer.num_heads` |
| FFN 隐藏维度 | 256 | 128, 512 | `models.subject_state.model.trial_encoder.transformer.dim_feedforward` |
| 投影维度 | 128 | 64, 256 | `models.subject_state.model.trial_encoder.projection_dim` |
| 分类头 Dropout | 0.3 | 0.2, 0.4 | `models.subject_state.model.classification_head.dropout` |

> **subject_state 额外参数**：还有 `subject_transformer.num_layers`、`subject_transformer.num_heads`、`subject_transformer.dim_feedforward` 可调整。

**架构搜索原则：**

- 每次**只改 1-2 个参数**，不要同时修改多个（否则无法判断哪个参数起了作用）
- 每个新架构组合执行策略一的完整 LR 调参循环（2-4 轮）
- 将每个架构组合的结果记录到实验表格的不同行

**示例：将 Transformer 层数从 2 改为 3**

**方式一：修改 train_full.yaml 配置文件**

```yaml
    model:
      trial_encoder:
        transformer:
          num_layers: 3              # ← 修改：从 2 增加到 3
    training:
      data_source:
        mode: "batch_index"
        batch_index_csv: "data/batchs/subject_state/run001/batch_001.csv"
      init_weight:
        path: null                   # ← 架构改变，从头训练（或使用 strict=false 的 init-weight）
        strict: false
      epochs: 200
      optimizer:
        lr: 1.0e-3
      scheduler:
        cosine_t_max: 200
        min_lr: 1.0e-6
      early_stop:
        patience: 20
      monitor_best:
        save_best_auc: true
        save_best_acc: true
```

**方式二：使用 CLI `-o` 覆盖**

```bash
eemo train --config configs/train_full.yaml -m subject_state \
  -o models.subject_state.model.trial_encoder.transformer.num_layers=3 \
  -o models.subject_state.training.data_source.mode=batch_index \
  -o models.subject_state.training.data_source.batch_index_csv=data/batchs/subject_state/run001/batch_001.csv \
  -o models.subject_state.training.epochs=200 \
  -o models.subject_state.training.optimizer.lr=0.001 \
  -o models.subject_state.training.scheduler.cosine_t_max=200 \
  -o models.subject_state.training.early_stop.patience=20 \
  -o models.subject_state.training.monitor_best.save_best_auc=true \
  --experiment-name subject_state_arch_L3_exp001 \
  --verbose
```

> **注意**：架构改变后，如果使用 `--init-weight` 加载旧架构的权重，**必须设置 `--init-weight-strict false`**（宽松模式允许不匹配的 key 被跳过）。或者直接从头训练（不使用 init-weight）。

**架构搜索完成后**：比较所有架构组合的 `best_val_auc`，选出指标最好的架构参数和对应的最佳权重。

---

### 2.4 策略三：小批次精调微训

基于策略一/二筛选出的**最佳架构 + 最佳权重**，使用更小的批次数据（`batch_002`、`batch_003`）进行精调微训。

**微调核心原则：**

| 参数 | 微调设置 | 说明 |
|------|---------|------|
| `lr` | `best_lr × (0.1 ~ 0.5)` | 使用远小于探索阶段的学习率 |
| `min_lr` | `lr × 0.01 ~ 0.1` | 保守的最小学习率 |
| `epochs` | 30-80 | 短训练周期，不需要 200 |
| `cosine_t_max` | 等于 `epochs` | 完整一个短余弦周期 |
| `init_weight.path` | 最佳架构的最佳权重 | 加载策略一/二的最终权重 |
| `init_weight.strict` | `true` | 架构不变，使用严格匹配 |

**可选正则化手段**（微调时推荐启用）：

| 参数 | 推荐值 | 配置路径 |
|------|--------|---------|
| 标签平滑 | 0.1 | `training.label_smoothing` |
| Mixup 混合 | 0.2 | `training.mixup_alpha` |
| 梯度裁剪 | 1.0 | `training.gradient_clip_val` |

#### batch_002 微调示例（20000 样本）

**方式一：修改 train_full.yaml 配置文件**

```yaml
    training:
      data_source:
        mode: "batch_index"
        batch_index_csv: "data/batchs/subject_state/run001/batch_002.csv"  # ← 修改：使用第 2 批
      init_weight:
        path: "experiments/subject_state_arch_L3_exp003/checkpoints/subject_state/best_val_auc.ckpt"  # ← 修改：最佳架构的最佳权重
        strict: true                          # ← 架构不变，严格匹配
      epochs: 60                              # ← 修改：短训练周期
      optimizer:
        lr: 1.05e-4                           # ← 修改：best_lr × 0.3（假设 best_lr = 3.5e-4）
      scheduler:
        cosine_t_max: 60                      # ← 修改：等于 epochs
        min_lr: 1.0e-5                        # ← 修改：保守的最小学习率
      label_smoothing: 0.1                    # ← 修改：启用标签平滑
      mixup_alpha: 0.2                        # ← 修改：启用 Mixup
      gradient_clip_val: 1.0                  # ← 修改：启用梯度裁剪
      early_stop:
        patience: 15
      monitor_best:
        save_best_auc: true
        save_best_acc: true
```

**方式二：使用 CLI `-o` 覆盖**

```bash
eemo train --config configs/train_full.yaml -m subject_state \
  --init-weight experiments/subject_state_arch_L3_exp003/checkpoints/subject_state/best_val_auc.ckpt \
  --init-weight-strict true \
  -o models.subject_state.training.data_source.mode=batch_index \
  -o models.subject_state.training.data_source.batch_index_csv=data/batchs/subject_state/run001/batch_002.csv \
  -o models.subject_state.training.epochs=60 \
  -o models.subject_state.training.optimizer.lr=0.000105 \
  -o models.subject_state.training.scheduler.cosine_t_max=60 \
  -o models.subject_state.training.scheduler.min_lr=1.0e-5 \
  -o models.subject_state.training.label_smoothing=0.1 \
  -o models.subject_state.training.mixup_alpha=0.2 \
  -o models.subject_state.training.gradient_clip_val=1.0 \
  --experiment-name subject_state_finetune_b2 \
  --verbose
```

#### batch_003 进一步精调（10000 样本）

在 batch_002 微调结果的基础上，使用更小的 batch_003 进一步精调：

**方式一：修改 train_full.yaml 配置文件**

```yaml
    training:
      data_source:
        batch_index_csv: "data/batchs/subject_state/run001/batch_003.csv"  # ← 修改：使用第 3 批
      init_weight:
        path: "experiments/subject_state_finetune_b2/checkpoints/subject_state/best_val_auc.ckpt"  # ← 修改：上轮微调最佳权重
        strict: true
      epochs: 40                              # ← 修改：更短周期
      optimizer:
        lr: 3.5e-5                            # ← 修改：best_lr × 0.1（更保守）
      scheduler:
        cosine_t_max: 40
        min_lr: 5.0e-6                        # ← 修改：更小的最小学习率
```

**方式二：使用 CLI `-o` 覆盖**

```bash
eemo train --config configs/train_full.yaml -m subject_state \
  --init-weight experiments/subject_state_finetune_b2/checkpoints/subject_state/best_val_auc.ckpt \
  --init-weight-strict true \
  -o models.subject_state.training.data_source.mode=batch_index \
  -o models.subject_state.training.data_source.batch_index_csv=data/batchs/subject_state/run001/batch_003.csv \
  -o models.subject_state.training.epochs=40 \
  -o models.subject_state.training.optimizer.lr=3.5e-5 \
  -o models.subject_state.training.scheduler.cosine_t_max=40 \
  -o models.subject_state.training.scheduler.min_lr=5.0e-6 \
  -o models.subject_state.training.label_smoothing=0.1 \
  --experiment-name subject_state_finetune_b3 \
  --verbose
```

> **提示**：微调阶段如果 `val_auc` 不再提升甚至下降，说明模型可能已经过拟合。此时应停止微调，使用上一轮的最佳权重作为最终结果。

---

### 2.5 实验记录表格模板

建议使用以下 Markdown 表格记录每次实验的配置和指标，便于横向对比：

| 实验编号 | 策略 | 数据批次 | init-weight | 架构参数 | lr | min_lr | cosine_t_max | epochs | best_val_acc | best_val_auc | best_lr | 备注 |
|---------|------|---------|-------------|---------|------|--------|-------------|--------|-------------|-------------|---------|------|
| exp001 | 探索 | batch_001 | 无 | L2/H4/D256/P128 | 1.0e-3 | 1.0e-6 | 200 | 200 | 0.847 | 0.912 | 3.5e-4 | 首次基线 |
| exp002 | LR调参 | batch_001 | exp001/best_val_auc | L2/H4/D256/P128 | 7.0e-4 | 3.5e-5 | 175 | 200 | 0.863 | 0.928 | 2.1e-4 | lr 区间收窄 |
| exp003 | LR调参 | batch_001 | exp002/best_val_auc | L2/H4/D256/P128 | 4.2e-4 | 2.1e-5 | 155 | 200 | 0.868 | 0.931 | 1.8e-4 | 收敛，此架构最佳 |
| exp004 | 架构搜索 | batch_001 | 无 | **L3**/H4/D256/P128 | 1.0e-3 | 1.0e-6 | 200 | 200 | 0.855 | 0.921 | 2.8e-4 | 尝试 3 层 |
| exp005 | LR调参 | batch_001 | exp004/best_val_auc | **L3**/H4/D256/P128 | 5.6e-4 | 2.8e-5 | 175 | 200 | 0.872 | 0.935 | 1.5e-4 | L3 最佳 |
| finetune_b2 | 微调 | batch_002 | exp005/best_val_auc | L3/H4/D256/P128 | 4.5e-5 | 5.0e-6 | 60 | 60 | 0.881 | 0.942 | — | 微调 batch_002 |
| finetune_b3 | 微调 | batch_003 | finetune_b2/best_val_auc | L3/H4/D256/P128 | 1.5e-5 | 1.0e-6 | 40 | 40 | 0.885 | 0.948 | — | 最终模型 |

**列说明：**

- **架构参数**：简写格式 `L=num_layers / H=num_heads / D=dim_feedforward / P=projection_dim`
- **init-weight**：记录使用的权重来源（`无`=随机初始化，`exp001/best_val_auc`=指定实验的最佳权重）
- **best_lr**：训练过程中 `val_auc` 最大时的学习率值，从 `metrics_history.csv` 中读取
- **best_val_acc / best_val_auc**：整个训练过程中的最佳验证指标

---

### 2.6 完整工作流示例（subject_state 全流程串联）

以下是一个 `subject_state` 分类器从分批到微调的完整流程，所有命令使用 CLI `-o` 覆盖方式：

**Step 1：数据分批**

```bash
eemo tool data-to-batchs-index \
  --manifest data/resampled/subject_state/version_001/manifest.csv \
  --output-dir data/batchs/subject_state/run001 \
  --batch-sizes 50000,20000,10000 \
  --seed 42 --verbose
```

**Step 2：首次探索训练（exp001）**

```bash
eemo train --config configs/train_full.yaml -m subject_state \
  -o models.subject_state.training.data_source.mode=batch_index \
  -o models.subject_state.training.data_source.batch_index_csv=data/batchs/subject_state/run001/batch_001.csv \
  -o models.subject_state.training.epochs=200 \
  -o models.subject_state.training.scheduler.cosine_t_max=200 \
  -o models.subject_state.training.optimizer.lr=0.001 \
  -o models.subject_state.training.early_stop.patience=20 \
  -o models.subject_state.training.monitor_best.save_best_auc=true \
  --experiment-name subject_state_exp001 \
  --verbose
```

训练完成后：从 `metrics_history.csv` 读取 `best_lr = 3.5e-4`，记录到表格。

**Step 3：第 2 轮 LR 调参（exp002）**

```bash
eemo train --config configs/train_full.yaml -m subject_state \
  --init-weight experiments/subject_state_exp001/checkpoints/subject_state/best_val_auc.ckpt \
  --init-weight-strict false \
  -o models.subject_state.training.data_source.mode=batch_index \
  -o models.subject_state.training.data_source.batch_index_csv=data/batchs/subject_state/run001/batch_001.csv \
  -o models.subject_state.training.epochs=200 \
  -o models.subject_state.training.optimizer.lr=0.0007 \
  -o models.subject_state.training.scheduler.min_lr=3.5e-5 \
  -o models.subject_state.training.scheduler.cosine_t_max=175 \
  -o models.subject_state.training.monitor_best.save_best_auc=true \
  --experiment-name subject_state_exp002 \
  --verbose
```

训练完成后：`best_lr = 2.1e-4`，`best_val_auc` 从 0.912 提升到 0.928。

**Step 4：第 3 轮 LR 调参（exp003）— 确认收敛**

```bash
eemo train --config configs/train_full.yaml -m subject_state \
  --init-weight experiments/subject_state_exp002/checkpoints/subject_state/best_val_auc.ckpt \
  --init-weight-strict false \
  -o models.subject_state.training.data_source.mode=batch_index \
  -o models.subject_state.training.data_source.batch_index_csv=data/batchs/subject_state/run001/batch_001.csv \
  -o models.subject_state.training.epochs=200 \
  -o models.subject_state.training.optimizer.lr=0.00042 \
  -o models.subject_state.training.scheduler.min_lr=2.1e-5 \
  -o models.subject_state.training.scheduler.cosine_t_max=155 \
  -o models.subject_state.training.monitor_best.save_best_auc=true \
  --experiment-name subject_state_exp003 \
  --verbose
```

训练完成后：`best_val_auc = 0.931`（仅提升 0.3%），确认 L2/H4 架构收敛。

**Step 5：架构搜索 — 尝试 3 层 Transformer（exp004）**

```bash
eemo train --config configs/train_full.yaml -m subject_state \
  -o models.subject_state.model.trial_encoder.transformer.num_layers=3 \
  -o models.subject_state.training.data_source.mode=batch_index \
  -o models.subject_state.training.data_source.batch_index_csv=data/batchs/subject_state/run001/batch_001.csv \
  -o models.subject_state.training.epochs=200 \
  -o models.subject_state.training.optimizer.lr=0.001 \
  -o models.subject_state.training.scheduler.cosine_t_max=200 \
  -o models.subject_state.training.monitor_best.save_best_auc=true \
  --experiment-name subject_state_arch_L3_exp004 \
  --verbose
```

**Step 6：对 L3 架构进行 LR 调参（exp005）** → 最终 L3 架构 `best_val_auc = 0.935` > L2 的 0.931，选择 L3。

**Step 7：batch_002 微调**

```bash
eemo train --config configs/train_full.yaml -m subject_state \
  --init-weight experiments/subject_state_arch_L3_exp005/checkpoints/subject_state/best_val_auc.ckpt \
  --init-weight-strict true \
  -o models.subject_state.training.data_source.mode=batch_index \
  -o models.subject_state.training.data_source.batch_index_csv=data/batchs/subject_state/run001/batch_002.csv \
  -o models.subject_state.training.epochs=60 \
  -o models.subject_state.training.optimizer.lr=4.5e-5 \
  -o models.subject_state.training.scheduler.cosine_t_max=60 \
  -o models.subject_state.training.scheduler.min_lr=5.0e-6 \
  -o models.subject_state.training.label_smoothing=0.1 \
  --experiment-name subject_state_finetune_b2 \
  --verbose
```

**Step 8：batch_003 进一步精调**

```bash
eemo train --config configs/train_full.yaml -m subject_state \
  --init-weight experiments/subject_state_finetune_b2/checkpoints/subject_state/best_val_auc.ckpt \
  --init-weight-strict true \
  -o models.subject_state.training.data_source.mode=batch_index \
  -o models.subject_state.training.data_source.batch_index_csv=data/batchs/subject_state/run001/batch_003.csv \
  -o models.subject_state.training.epochs=40 \
  -o models.subject_state.training.optimizer.lr=1.5e-5 \
  -o models.subject_state.training.scheduler.cosine_t_max=40 \
  -o models.subject_state.training.scheduler.min_lr=1.0e-6 \
  --experiment-name subject_state_finetune_b3 \
  --verbose
```

**最终结果**：`subject_state_finetune_b3` 的 `best_val_auc.ckpt` 即为最终训练产物。

---

## 3. 安装与环境配置

### 3.1 前置要求

- Python >= 3.13
- Conda（推荐）或 pip
- CUDA（可选，GPU 加速训练）

### 3.2 创建 Conda 环境

```bash
conda create -n dglz python=3.13 -y
conda activate dglz
```

### 3.3 安装项目

```bash
# 用户安装（推荐）
pip install DGLZ --index-url https://pypi.org/simple/

# 已安装但需要更新到最新版本
pip install DGLZ --upgrade --index-url https://pypi.org/simple/

# 使用 eemo update 自动更新（推荐）
eemo update

# 开发模式安装（仅开发者）
pip install -e .
```

### 3.4 验证安装

```bash
# 查看版本号
eemo version
# 输出: eemo (DGLZ) 版本 0.1.9.post4

# 环境健康检查
eemo doctor
# 检查 Python、NumPy、PyTorch、CUDA 等依赖
```

### 3.5 导出默认配置模板

```bash
# 导出配置模板到 configs/ 目录
eemo get --path configs
```

导出文件（来自 `configs/base/`）：`train_full.yaml`、`resample.yaml`、`infer_three_stage.yaml`、`preprocess.yaml`

---

## 4. 快速上手：从原始数据到提交文件

以下是从原始 EEG 数据到最终提交文件的 **完整流程**：

### 第一步：准备原始数据

将训练数据和测试数据放置到以下目录结构：

```
dataset/
├── 训练集/
│   ├── 正常人/          # 40-44 名正常被试 .mat 文件
│   │   ├── HC1003timedata.mat
│   │   └── ...
│   └── 抑郁症患者/      # 18-20 名抑郁症被试 .mat 文件
│       ├── DEP1003timedata.mat
│       └── ...
└── 公开测试集/          # 10 名测试被试 .mat 文件
    ├── P_test1.mat
    └── ...
```

### 第二步：生成数据索引

扫描原始数据目录，生成训练集和测试集的索引 CSV 文件：

```bash
eemo prepare \
  --train-dir "dataset/训练集" \
  --test-dir "dataset/公开测试集" \
  --output-dir data/index
```

**输出文件：**
- `data/index/train_subjects.csv` — 训练被试索引（含 subject_id、mat_path、group_label）
- `data/index/test_subjects.csv` — 测试被试索引

### 第三步：离线重采样

为三个分类器生成重采样训练数据集：

```bash
# 使用统一重采样配置
eemo resample --config configs/resample.yaml --verbose

# 多线程并行处理
eemo resample --config configs/resample.yaml -w 8 --verbose
```

**输出目录：**
- `data/resampled/subject_state/version_001/` — manifest.csv + samples/*.pt
- `data/resampled/normal_emotion/version_001/`
- `data/resampled/depression_emotion/version_001/`

### 第四步：训练模型

**统一配置训练：**

```bash
# 训练全部分类器（7 个）
eemo train --config configs/train_full.yaml --verbose

# 仅训练指定的模型
eemo train --config configs/train_full.yaml -m subject_state --verbose
eemo train --config configs/train_full.yaml -m subject_state,normal_emotion --verbose

# 训练 V2 双路模型
eemo train --config configs/train_full.yaml -m dual_subject_state --verbose
eemo train --config configs/train_full.yaml -m dual_subject_state,dual_normal_emotion,dual_depression_emotion --verbose

# 训练 V3 多任务模型
eemo train --config configs/train_full.yaml -m all_in_one --verbose

# 使用并行模式训练
eemo train --config configs/train_full.yaml --mode parallel --verbose

# 使用混合模式（部分顺序、部分并行）
eemo train --config configs/train_full.yaml --mode mixed \
  --parallel-models normal_emotion,depression_emotion --verbose

# 通过命令行覆盖配置参数
eemo train --config configs/train_full.yaml \
  -o experiment.name=exp_v1 \
  -o models.subject_state.training.epochs=200 \
  -o models.subject_state.training.optimizer.lr=0.002 \
  --verbose

# 使用 batch_index 模式分批训练
eemo train --config configs/train_full.yaml -m subject_state \
  -o models.subject_state.training.data_source.mode=batch_index \
  -o models.subject_state.training.data_source.batch_index_csv=data/batchs/subject_state/run001/batch_001.csv \
  --verbose
```

**实验目录结构（V0.1.8）：**
```
experiments/
└── default/
    ├── config.yaml                    # 配置快照
    ├── training_state.yaml            # 训练状态（含 fold 级别信息）
    ├── checkpoints/
    │   ├── subject_state/
    │   │   ├── best_model.ckpt        # holdout 产物（仅 holdout 模式）
    │   │   ├── latest_model.ckpt      # holdout 产物
    │   │   ├── fold_0/                # kfold 产物（仅 kfold 模式）
    │   │   │   ├── best_model.ckpt
    │   │   │   └── latest_model.ckpt
    │   │   ├── fold_1/
    │   │   ├── ...
    │   │   ├── fold_best/             # 最佳折的完整拷贝
    │   │   │   ├── best_model.ckpt
    │   │   │   └── latest_model.ckpt
    │   │   └── kfold_summary.yaml     # 跨折聚合指标
    │   ├── normal_emotion/
    │   └── depression_emotion/
    ├── logs/
    │   ├── training.log               # 全局训练日志
    │   ├── subject_state_fold_0/      # kfold 每折的指标 CSV
    │   │   └── metrics_history.csv
    │   └── ...
    ├── metrics/
    └── results/
```

**训练参数提示：**
- 使用 `--resume` 可从最近检查点恢复训练
- 早停耐心值默认 15-20 轮，可在配置文件 `early_stop.patience` 中调整
- 使用 `--override` / `-o` 动态修改任意配置参数，无需编辑文件

### 第五步：运行三阶段推理

使用训练好的三个模型对测试数据进行推理：

```bash
eemo infer-three-stage \
  --config configs/infer_three_stage.yaml \
  --verbose
```

**输出文件：**
- `outputs/submission.xlsx` — 提交格式结果（Excel）
- `outputs/submission.csv` — 提交格式结果（CSV）
- `outputs/routing_summary.csv` — 被试路由详情

### 第六步（可选）：检查结果

```bash
# 校验配置文件
eemo config validate --config configs/train_full.yaml

# 查看生效的配置内容
eemo config show --config configs/train_full.yaml

# 查看训练实验列表
eemo exp-train list

# 查看实验详情
eemo exp-train summary --name exp_v1

# 查看检查点信息
eemo ckpt info experiments/default/checkpoints/subject_state/best_val_accuracy.ckpt

# 查看推理结果摘要
eemo exp-pred summary-pred --dir outputs
```

---

## 5. 完整命令参考

### 5.1 `eemo version` — 显示版本号

```bash
eemo version
```

显示当前安装的 DGLZ 版本号。

---

### 5.2 `eemo doctor` — 环境健康检查

```bash
eemo doctor
```

自动检查以下项目：
- Python 版本
- NumPy、PyTorch、SciPy、Pandas、Typer、Rich、scikit-learn
- CUDA 可用性和设备信息
- 操作系统平台

---

### 5.3 `eemo prepare` — 生成数据索引

```bash
eemo prepare [OPTIONS]
```

扫描原始 .mat 数据目录，生成训练集和测试集的索引 CSV 文件。

| 选项 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `--train-dir` | TEXT | `data/raw/train` | 训练集 .mat 文件目录 |
| `--test-dir` | TEXT | `data/raw/test` | 测试集 .mat 文件目录 |
| `--output-dir` | TEXT | `data/index` | 索引 CSV 输出目录 |
| `--config` | TEXT | `configs/preprocess.yaml` | 预处理配置文件路径 |

**示例：**
```bash
eemo prepare --train-dir "dataset/训练集" --test-dir "dataset/公开测试集"
```

---

### 5.4 `eemo resample` — 离线重采样

```bash
eemo resample --config <配置文件> [OPTIONS]
```

为分类器生成重采样训练数据集。

| 选项 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `--config` | TEXT | **（必填）** | 重采样配置 YAML 文件路径 |
| `--workers` / `-w` | INT | 1 | 并行工作线程数（覆盖配置文件中的 `resample.workers`） |
| `--verbose` | FLAG | false | 启用详细输出模式 |

**示例：**
```bash
# 使用统一重采样配置（一次运行全部三个分类器）
eemo resample --config configs/resample.yaml --verbose

# 使用 4 个线程并行重采样，加速处理
eemo resample --config configs/resample.yaml --workers 4 --verbose

# CLI --workers 覆盖配置文件中的 resample.workers 值
eemo resample --config configs/resample.yaml -w 8
```

---

### 5.5 `eemo train` — 训练分类器

```bash
eemo train --config <配置文件> [OPTIONS]
```

训练一个或多个分类器模型。使用统一配置文件 `train_full.yaml`。

| 选项 | 类型 | 默认值 | 说明 |
|-----------|------|--------|------|
| `--config` | TEXT | **（必填）** | 训练配置 YAML 文件路径 |
| `--models` / `-m` | TEXT | 全部模型 | 逗号分隔的模型名称（仅统一格式） |
| `--mode` | TEXT | `sequential` | 训练模式: `sequential`、`parallel`、`mixed` |
| `--parallel-models` | TEXT | 无 | mixed 模式下并行训练的模型（逗号分隔） |
| `--override` / `-o` | TEXT | 无 | 点分键值覆盖（可重复使用） |
| `--experiment-name` | TEXT | 配置文件值 | 实验名称（用于日志和检查点目录） |
| `--verbose` | FLAG | false | 启用详细输出模式 |
| `--resume` | TEXT | None | 从指定检查点路径恢复训练（留空则自动检测 `latest_model.ckpt`） |
| `--fresh` | FLAG | false | 强制从头开始训练，跳过自动恢复 |
| `--init-weight` | TEXT | None | 预训练权重 .ckpt 路径（对所有分类器统一覆盖），与 `--resume` 互斥 |
| `--init-weight-strict` | TEXT | null | 权重加载模式: `true`（严格匹配）/ `false`（宽松匹配） |

**统一配置示例：**
```bash
# 训练全部模型
eemo train --config configs/train_full.yaml --verbose

# 仅训练被试状态分类器
eemo train --config configs/train_full.yaml -m subject_state --verbose

# 并行训练全部模型
eemo train --config configs/train_full.yaml --mode parallel --verbose

# 使用命令行覆盖配置
eemo train --config configs/train_full.yaml \
  -o experiment.name=exp_v2 \
  -o models.subject_state.training.epochs=200 \
  -o models.subject_state.training.optimizer.lr=0.002 \
  --verbose
```

**K-Fold 交叉验证训练：**
```bash
# 使用 5 折交叉验证训练（默认配置即为 StratifiedGroupKFold）
eemo train --config configs/train_full.yaml -m subject_state --verbose

# 通过命令行切换为 holdout 模式
eemo train --config configs/train_full.yaml -m subject_state \
  -o models.subject_state.splitting.method=holdout --verbose

# 调整折数和训练轮数
eemo train --config configs/train_full.yaml -m subject_state \
  -o models.subject_state.splitting.n_splits=3 \
  -o models.subject_state.training.epochs=50 --verbose
```

**K-Fold 训练输出说明：**
- 每折独立训练，权重保存在 `checkpoints/{model}/fold_{i}/`
- 最佳折的检查点拷贝到 `checkpoints/{model}/fold_best/`
- 跨折聚合指标保存在 `checkpoints/{model}/kfold_summary.yaml`
- holdout 和 kfold 模式的文件路径隔离，同一实验目录下互不干扰

**`--override` 点分键值语法：**

| 覆盖表达式 | 效果 |
|-----------|------|
| `experiment.name=exp_v2` | 修改实验名称 |
| `models.subject_state.training.epochs=200` | 修改被试状态模型训练轮数 |
| `models.subject_state.training.optimizer.lr=0.002` | 修改学习率 |
| `signal.fs=512` | 修改采样频率 |
| `signal.zscore.enabled=false` | 禁用 z-score |

支持自动类型推断：整数（`42`）、浮点数（`0.001`）、布尔值（`true`/`false`）、None（`null`）、列表（`[1,2,3]`）、字符串。

---

### 5.6 `eemo pred` — 单模型预测（调试用）

```bash
eemo pred <NAME> --config <配置> --model <检查点> --data <数据> [OPTIONS]
```

| 参数/选项 | 类型 | 默认值 | 说明 |
|-----------|------|--------|------|
| `NAME` | 参数 | **（必填）** | 模型名称：`subject_state`、`normal_emotion`、`depression_emotion` |
| `--config` | TEXT | **（必填）** | 配置 YAML 文件路径 |
| `--model` | TEXT | **（必填）** | 模型检查点文件路径 (.ckpt) |
| `--data` | TEXT | **（必填）** | 数据清单 CSV 或数据目录路径 |
| `--output` | TEXT | `outputs/pred.csv` | 预测结果输出 CSV 路径 |

**示例：**
```bash
eemo pred subject_state \
  --config configs/train_full.yaml \
  --model experiments/default/checkpoints/subject_state/best_val_accuracy.ckpt \
  --data data/resampled/subject_state/version_001/manifest.csv \
  --output outputs/pred_ss.csv
```

---

### 5.7 `eemo infer-three-stage` — 三阶段推理流水线

```bash
eemo infer-three-stage [OPTIONS]
```

| 选项 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `--config` | TEXT | `configs/infer_three_stage.yaml` | 三阶段推理配置文件路径 |
| `--subject-state-model` | TEXT | None | 覆盖配置中的被试状态模型路径 |
| `--normal-emotion-model` | TEXT | None | 覆盖配置中的正常人情绪模型路径 |
| `--depression-emotion-model` | TEXT | None | 覆盖配置中的抑郁症情绪模型路径 |
| `--test-dir` | TEXT | None | 覆盖配置中的测试数据目录 |
| `--output` | TEXT | `outputs/submission` | 输出路径（不含扩展名） |
| `--verbose` | FLAG | false | 启用详细输出模式 |

**示例：**
```bash
# 使用配置文件中的路径
eemo infer-three-stage --config configs/infer_three_stage.yaml --verbose

# 通过命令行覆盖模型路径
eemo infer-three-stage \
  --subject-state-model experiments/default/checkpoints/subject_state/best_val_accuracy.ckpt \
  --normal-emotion-model experiments/default/checkpoints/normal_emotion/best_val_accuracy.ckpt \
  --depression-emotion-model experiments/default/checkpoints/depression_emotion/best_val_accuracy.ckpt \
  --test-dir dataset/公开测试集
```

---

### 5.8 `eemo config` — 配置文件管理

```bash
eemo config <SUBCOMMAND> [OPTIONS]
```

#### `config validate` — 校验配置文件

```bash
eemo config validate --config <配置文件>
```

校验配置文件完整性，检查必填字段并计算有效通道数 (C_eff)。支持训练配置、重采样配置和推理配置格式。

#### `config show` — 显示生效的配置内容

```bash
eemo config show --config <配置文件> [--model <配置段>]
```

以表格形式显示配置文件的所有键值对。`--model` 可筛选指定顶层配置段（如 `signal`、`models`、`experiment` 等）。

---

### 5.9 `eemo get` — 导出默认配置模板

```bash
eemo get [--path <导出目录>]
```

从 `configs/base/` 导出带详细注释的配置模板。

| 选项 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `--path` | TEXT | `configs` | 配置模板导出目录 |

导出文件：`train_full.yaml`、`resample.yaml`、`infer_three_stage.yaml`、`preprocess.yaml`

---

### 5.10 `eemo exp-train` — 训练实验管理

```bash
eemo exp-train <SUBCOMMAND> [OPTIONS]
```

#### `exp-train list` — 列出所有训练实验

```bash
eemo exp-train list [--checkpoint-dir <目录>]
```

| 选项 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `--checkpoint-dir` | TEXT | `experiments/default/checkpoints` | 检查点根目录 |

#### `exp-train summary` — 查看实验详情

```bash
eemo exp-train summary --name <实验名> [--checkpoint-dir <目录>]
```

#### `exp-train compare` — 比较多个实验

```bash
eemo exp-train compare --names <名称1,名称2,...> [--checkpoint-dir <目录>]
```

#### `exp-train clean` — 清理过期实验

```bash
eemo exp-train clean [--before <日期>] [--keep-best <数量>] [--dry-run] [--checkpoint-dir <目录>]
```

| 选项 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `--before` | TEXT | None | 删除早于此日期的实验 (YYYY-MM-DD) |
| `--keep-best` | INT | 3 | 保留最佳 N 个实验 |
| `--dry-run` | FLAG | true | 仅预览，不实际删除 |
| `--checkpoint-dir` | TEXT | `checkpoints` | 检查点根目录 |

---

### 5.11 `eemo exp-pred` — 推理结果管理

```bash
eemo exp-pred <SUBCOMMAND> [OPTIONS]
```

#### `exp-pred summary-pred` — 查看推理结果摘要

```bash
eemo exp-pred summary-pred --dir <输出目录>
```

#### `exp-pred compare-pred` — 比较多次推理结果

```bash
eemo exp-pred compare-pred --dirs <目录1,目录2,...>
```

#### `exp-pred export-pred` — 导出推理结果

```bash
eemo exp-pred export-pred --dir <输出目录> [--format <格式>]
```

| `--format` 可选值 | 说明 |
|-------------------|------|
| `csv` | CSV 格式（默认） |
| `xlsx` | Excel 格式 |
| `json` | JSON 格式 |

---

### 5.12 `eemo ckpt` — 检查点管理

```bash
eemo ckpt <SUBCOMMAND> [OPTIONS]
```

#### `ckpt list` — 列出所有检查点

```bash
eemo ckpt list [--checkpoint-dir <目录>] [--config <配置文件>]
```

| 选项 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `--config` | TEXT | None | 配置 YAML（用于解析检查点目录） |
| `--checkpoint-dir` | TEXT | `experiments/default/checkpoints` | 检查点根目录 |

#### `ckpt info` — 显示检查点详情

```bash
eemo ckpt info <检查点文件路径>
```

显示轮次、指标、配置快照和模型参数量。

#### `ckpt export` — 导出模型最佳检查点

```bash
eemo ckpt export <模型名称> [--output <输出路径>] [--checkpoint-dir <目录>]
```

| 参数/选项 | 类型 | 默认值 | 说明 |
|-----------|------|--------|------|
| `NAME` | 参数 | **（必填）** | 模型名称：`subject_state`、`normal_emotion`、`depression_emotion` |
| `--output` | TEXT | None | 导出目标路径 |
| `--checkpoint-dir` | TEXT | `experiments/default/checkpoints` | 检查点根目录 |

---

### 5.13 `eemo tool` — 工具集（非训练操作）

```bash
eemo tool <SUBCOMMAND> [OPTIONS]
```

#### `tool data-to-batchs-index` — 分批索引生成

从重采样 manifest CSV 中按指定大小不放回抽取，生成 batch CSV 索引文件，用于分批训练微调。

```bash
eemo tool data-to-batchs-index --manifest <manifest.csv> --output-dir <输出目录> [OPTIONS]
```

**工作原理：**
1. 读取 manifest CSV，获取所有 `sample_id`
2. 使用 numpy RNG 按 `seed` 随机打乱
3. 按指定 `batch_sizes` 依次抽取，每个 batch 生成一个 CSV 文件
4. 抽取完成后剩余样本生成 `remainder.csv`（下次可基于此文件继续抽取）
5. 同时生成 `summary.json` 摘要文件

**生成的文件：**
```
output_dir/
├── batch_001.csv       # 第 1 个 batch（含 manifest 完整行）
├── batch_002.csv       # 第 2 个 batch
├── remainder.csv       # 剩余未抽取样本（下次可作输入）
└── summary.json        # 摘要（batch_sizes, total, seed 等）
```

| 选项 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `--manifest` / `-m` | TEXT | **（必填）** | 输入 manifest.csv 文件路径 |
| `--output-dir` / `-o` | TEXT | **（必填）** | 输出目录（不存在则自动创建） |
| `--batch-sizes` / `-b` | TEXT | 无 | 每个 batch 的样本数量，逗号分隔（如 `50,80,60`） |
| `--batch-config` / `-c` | TEXT | 无 | batch 配置 JSON 文件路径（与 `--batch-sizes` 二选一） |
| `--seed` / `-s` | INT | None | 随机种子，确保可复现 |
| `--prefix` / `-p` | TEXT | `batch` | 输出文件前缀 |
| `--verbose` / `-v` | FLAG | false | 启用详细输出模式（Rich 面板 + 表格） |

**示例：**
```bash
# 从 subject_state manifest 抽取 3 个 batch
eemo tool data-to-batchs-index \
  --manifest data/resampled/subject_state/version_001/manifest.csv \
  --output-dir data/batchs/subject_state/run001 \
  --batch-sizes 400,400,400 \
  --seed 42 --verbose

# 使用 JSON 配置文件指定 batch 大小
eemo tool data-to-batchs-index \
  --manifest data/resampled/normal_emotion/version_001/manifest.csv \
  --output-dir data/batchs/normal_emotion/run001 \
  --batch-config batch_config.json \
  --verbose

# 基于 remainder 继续抽取
eemo tool data-to-batchs-index \
  --manifest data/batchs/subject_state/run001/remainder.csv \
  --output-dir data/batchs/subject_state/run002 \
  --batch-sizes 200 --seed 123
```

**使用 batch 索引训练：**
```bash
# 使用 batch_index 模式训练
eemo train --config configs/train_full.yaml -m subject_state \
  -o models.subject_state.training.data_source.mode=batch_index \
  -o models.subject_state.training.data_source.batch_index_csv=data/batchs/subject_state/run001/batch_001.csv \
  --verbose
```

**`--batch-config` JSON 文件格式：**
```json
{
  "batch_sizes": [400, 400, 400],
  "seed": 42
}
```

---

## 6. 配置文件参考

### 6.1 配置文件概览

| 文件 | 用途 | 对应命令 |
|------|------|----------|
| `train_full.yaml` | 统一训练配置（三个模型合一） | `train` |
| `resample.yaml` | 统一重采样配置 | `resample` |
| `infer_three_stage.yaml` | 三阶段推理 | `infer-three-stage` |
| `preprocess.yaml` | 数据预处理参数 | `prepare` |

所有配置模板通过 `eemo get` 导出，源文件位于 `configs/base/`。

### 6.2 配置格式自动检测

系统自动检测配置文件格式，无需手动指定：

- **训练格式**：包含顶层 `models` 字典，每个模型含 `model`/`training` 子段
- **推理格式**：包含顶层 `models` 字典，每个模型含 `checkpoint`/`config` 子段
- **重采样格式**：包含顶层 `resample` + `signal` 字段
- **预处理格式**：包含顶层 `data` + `signal` 字段（无 `models` 或 `resample`）

---

### 6.3 统一训练配置 (`train_full.yaml`)

统一配置将七个分类器的所有参数集中在一个文件中，每个模型独立配置 task/model/training/augmentation/splitting/seeding：

```yaml
# 项目信息
project:
  repo_name: "DGLZ"
  package_name: "eemoclas"
  cli_name: "eemo"
  experiment_family: "eeg_three_stage_cnn_transformer"

# 信号参数
signal:
  fs: 250                       # 采样频率 (Hz)
  train_segment_points: 12500   # 每段采样点数
  window_points: 2500           # 窗口采样点数 (10s × 250Hz)
  clip_std: 5.0                 # z-score 后截断阈值
  zscore:
    enabled: true
    eps: 1.0e-6

# 重采样配置
resample:
  targets: ["subject_state", "normal_emotion", "depression_emotion"]
  permute_trials: true
  save_format: "pt"
  seed: 42
  save_config_snapshot: true
  save_stats: true
  sampling:
    method: "truncated_gaussian"
    fs: 250
    window_seconds: 10
    gaussian:
      mu_seconds: 25
      sigma_seconds: 8
      lower_seconds: 5
      upper_seconds: 45

# 数据来源
data:
  index_dir: "data/index"
  manifests:
    subject_state: "data/resampled/subject_state/version_001/manifest.csv"
    normal_emotion: "data/resampled/normal_emotion/version_001/manifest.csv"
    depression_emotion: "data/resampled/depression_emotion/version_001/manifest.csv"
  config_snapshots:
    subject_state: "data/resampled/subject_state/version_001/config_snapshot.yaml"
    normal_emotion: "data/resampled/normal_emotion/version_001/config_snapshot.yaml"
    depression_emotion: "data/resampled/depression_emotion/version_001/config_snapshot.yaml"

# ===== 七个模型各自独立配置 =====
models:
  subject_state:
    task:
      name: "subject_state"
      dataset_class: "SubjectStateDataset"
      num_classes: 2
      label_names: ["normal", "depression"]

    model:
      class_name: "SubjectStateCNNTransformer"
      input_num_trials: 8
      input_length: 2500
      num_classes: 2
      trial_encoder:
        projection_dim: 128
        cnn_channels: [16, 32, 64]
        kernel_sizes: [15, 9, 5]
        strides: [2, 2, 2]
        cnn_dropout: 0.1
        pooling: "cls"
        token_embedding:
          use_channel_embedding: true
          use_band_embedding: true
          use_cls_token: true
          embedding_dim: 128
        transformer:
          num_layers: 2
          num_heads: 4
          dim_feedforward: 256
          dropout: 0.1
          activation: "gelu"
          norm_first: true
          batch_first: true
      subject_transformer:       # 仅 subject_state 有此段
        use_cls_token: true
        use_trial_position_embedding: true
        embedding_dim: 128
        num_layers: 2
        num_heads: 4
        dim_feedforward: 256
        dropout: 0.1
        activation: "gelu"
        norm_first: true
        batch_first: true
      classification_head:
        hidden_dims: [128]
        dropout: 0.3

    training:
      data_source:                       # 训练数据来源（V0.1.15.post1+）
        mode: "full"                     # "full"（全部样本）| "batch_index"（指定 CSV 子集）
        batch_index_csv: null            # batch_index 模式时的 CSV 路径
      epochs: 100
      batch_size: 16
      optimizer:
        type: "adamw"           # 可选: adamw / adam / sgd
        lr: 1.0e-3
        weight_decay: 1.0e-4
        betas: [0.9, 0.999]    # adamw / adam 专用
        eps: 1.0e-8
      scheduler:
        type: "cosine"          # 可选: cosine / cosine_warmup / cosine_warmrestarts / steplr / plateau / onecycle
        cosine_t_max: 100       # 余弦退火周期（V0.1.15.post1+，默认等于 epochs）
        min_lr: 1.0e-6
        warmup_epochs: 5
      loss: "cross_entropy"     # cross_entropy | focal
      focal_gamma: 2.0          # Focal Loss 聚焦参数（仅 loss="focal"）
      class_weight: "auto"       # auto / null / [w0, w1]
      label_smoothing: 0.0       # 标签平滑系数
      gradient_clip_val: 0.0     # 梯度裁剪阈值 (0.0=不裁剪)
      mixup_alpha: 0.0           # Mixup 数据混合 (0.0=禁用)
      swa_start_epoch: 0         # SWA 起始轮 (0=禁用)
      swa_lr: 5.0e-5             # SWA 学习率
      early_stop:
        enable: true
        patience: 15
        early_metric: "val_accuracy"
        metric_mode: "max"
        up_delta: 1.0e-6
      monitor_best:
        monitor_metric: "val_accuracy"
        metric_mode: "max"
        save_latest: true
        save_best_auc: false
        save_best_acc: true
      preload:                             # 内存预加载（V0.1.11.post3+）
        enabled: true                      # 启用内存预加载
        compression: "float16"             # float16 (2x) | bfloat16 | none
        system_reserve_ratio: 0.05         # 系统保留内存比例
        preload_val: false                 # 是否也预加载验证集
        skip_meta: true                    # 跳过 meta 字典

    augmentation:
      enabled: false
      gaussian_noise: { enabled: false, std: 0.01 }
      time_mask: { enabled: false, max_mask_ratio: 0.1 }
      channel_dropout: { enabled: false, drop_prob: 0.1 }

    splitting:
      method: "StratifiedGroupKFold"
      n_splits: 5
      group_key: "subject_id"
      stratify_key: "group_label"
      seed: 42

    seeding:
      random_seed: 42
      split_seed: 42
      init_seed: 42

  normal_emotion:
    # 结构同上，差异见下表
    task:
      name: "normal_emotion"
      num_classes: 2
      label_names: ["neutral", "positive"]
    model:
      class_name: "NormalEmotionCNNTransformer"
      # 无 subject_transformer
    training:
      batch_size: 32
      scheduler:
        cosine_t_max: 100

  depression_emotion:
    task:
      name: "depression_emotion"
      num_classes: 2
      label_names: ["neutral", "positive"]
    model:
      class_name: "DepressionEmotionCNNTransformer"
      classification_head:
        dropout: 0.35
    training:
      epochs: 120
      batch_size: 24
      scheduler:
        cosine_t_max: 120
      early_stop:
        patience: 20

  dual_subject_state:
    # V2 双路模型（V0.1.11+）
    task:
      name: "dual_subject_state"
      dataset_class: "SubjectStateDataset"
      num_classes: 2
      label_names: ["normal", "depression"]
    model:
      class_name: "DualBranchSubjectStateCNNTransformer"
      num_trials: 8
      input_length: 2500
      num_classes: 2
      raw_trial_encoder:                  # Raw 分支（30 通道原始 EEG）
        input_length: 2500
        projection_dim: 128
        cnn_channels: [16, 32, 64]
        kernel_sizes: [15, 9, 5]
        strides: [2, 2, 2]
        cnn_dropout: 0.1
        pooling: "cls"
        use_channel_embedding: true
        use_band_embedding: false         # Raw 分支无频带信息
      pp_trial_encoder:                   # 预处理分支（C_eff 通道）
        input_length: 2500
        projection_dim: 128
        cnn_channels: [16, 32, 64]
        kernel_sizes: [15, 9, 5]
        strides: [2, 2, 2]
        cnn_dropout: 0.1
        pooling: "cls"
        use_channel_embedding: true
        use_band_embedding: true          # PP 分支含频带信息
      fusion_transformer:                 # Fusion Transformer 融合
        d_model: 128
        num_layers: 2
        num_heads: 4
        dim_feedforward: 256
        dropout: 0.1
        activation: "gelu"
        norm_first: true
        batch_first: true
      classification_head:
        input_dim: 128
        num_classes: 2
        hidden_dims: [128]
        dropout: 0.3
      stats_features:                     # 统计特征注入（V0.1.14+）
        enabled: true
        features: [band_power_delta, band_power_theta, ...]  # 25 个特征
        projection_dim: 64
    training:
      load_raw: true                      # 双路模型标志：加载原始数据
      scheduler:
        cosine_t_max: 100

  dual_normal_emotion:
    # V2 双路情绪模型（Late Fusion）
    model:
      class_name: "DualBranchEmotionCNNTransformer"
      # 结构同 dual_subject_state，但无 num_trials 字段
    training:
      batch_size: 32
      load_raw: true
      scheduler:
        cosine_t_max: 100

  dual_depression_emotion:
    # V2 双路抑郁症情绪模型
    model:
      class_name: "DualBranchEmotionCNNTransformer"
      classification_head:
        dropout: 0.35
    training:
      epochs: 120
      batch_size: 24
      load_raw: true
      scheduler:
        cosine_t_max: 120
      early_stop:
        patience: 20

  all_in_one:
    # V3 多任务模型（V0.1.15+）
    task:
      name: "all_in_one"
      dataset_class: "SubjectStateDataset"
      num_classes: 9
      label_names: ["normal", "depression"]
    model:
      class_name: "AllInOneCNNTransformer"
      input_length: 2500
      num_trials: 8
      num_classes: 9                      # 1 subject + 8 emotion
      trial_encoder:                      # 同 V1 subject_state 的 trial_encoder
        projection_dim: 128
        # ...
      subject_encoder:                    # Subject 级别编码
        d_model: 128
        num_layers: 2
        num_heads: 4
        dim_feedforward: 256
        dropout: 0.1
      subject_head:                       # 被试状态分类头
        input_dim: 128
        num_classes: 1
        hidden_dims: [128]
        dropout: 0.3
      emotion_head:                       # 情绪分类头（8 个试次）
        input_dim: 128
        num_classes: 1
        hidden_dims: [128]
        dropout: 0.3
    training:
      epochs: 100
      batch_size: 16
      load_raw: false
      optimizer:
        lr: 5.0e-4
        weight_decay: 1.0e-2
      scheduler:
        cosine_t_max: 100
      loss:
        type: "weighted_sum"              # weighted_sum | uncertainty | per_trial
        subject_state_weight: 1.0
        emotion_weight: 1.0
      early_stop:
        patience: 15
        early_metric: "val_emotion_accuracy"
      monitor_best:
        monitor_metric: "val_emotion_accuracy"
      best_checkpoints:                   # 多最佳检查点保存
        - metric: "val_emotion_accuracy"
          filename: "best_emotion_accuracy.ckpt"
        - metric: "val_subject_accuracy"
          filename: "best_subject_accuracy.ckpt"

# 全局日志配置
logging:
  level: "INFO"
  format: "%(asctime)s | %(levelname)-8s | %(name)s | %(message)s"
  log_every_n_steps: 10

# 实验管理
experiment:
  name: "default"
  save_dir: "experiments"
  save_best: true
  save_latest: true
  checkpoint_metric: "val_accuracy"
  monitor_metrics:
    - val_accuracy
    - val_loss
  val_check_interval: 1.0        # 验证频率 (1.0=每 epoch, 0.5=每半 epoch)
  notes: ""                      # 实验注释: 记录调参目的、参数变更原因等

# 推理路由
inference:
  routing: "hard"
  use_4_4_constraint: true
  positive_label: 1
  neutral_label: 0
  output_format: "xlsx"

# 评估指标
metrics:
  primary: "accuracy"
  report:
    - accuracy
    - accuracy
    - macro_f1
    - roc_auc
```

**七个模型的主要差异：**

**V1 单路模型（3 个）：**

| 配置项 | subject_state | normal_emotion | depression_emotion |
|--------|--------------|----------------|-------------------|
| `model.class_name` | SubjectStateCNNTransformer | NormalEmotionCNNTransformer | DepressionEmotionCNNTransformer |
| `subject_transformer` | 有（聚合 8 试次） | 无 | 无 |
| `training.epochs` | 100 | 100 | 120 |
| `training.batch_size` | 16 | 32 | 24 |
| `training.scheduler.cosine_t_max` | 100 | 100 | 120 |
| `training.early_stop.patience` | 15 | 15 | 20 |
| `classification_head.dropout` | 0.3 | 0.3 | 0.35 |
| `training.load_raw` | false | false | false |

**V2 双路模型（3 个）：**

| 配置项 | dual_subject_state | dual_normal_emotion | dual_depression_emotion |
|--------|--------------------|---------------------|------------------------|
| `model.class_name` | DualBranchSubjectStateCNNTransformer | DualBranchEmotionCNNTransformer | DualBranchEmotionCNNTransformer |
| 融合方式 | Trial-level 交错（16 tokens） | Late fusion（2 tokens） | Late fusion（2 tokens） |
| `stats_features` | 有（25 特征） | 有（25 特征） | 有（25 特征） |
| `training.epochs` | 100 | 100 | 120 |
| `training.batch_size` | 16 | 32 | 24 |
| `training.scheduler.cosine_t_max` | 100 | 100 | 120 |
| `training.load_raw` | true | true | true |
| `classification_head.dropout` | 0.3 | 0.3 | 0.35 |

**V3 多任务模型（1 个）：**

| 配置项 | all_in_one |
|--------|-----------|
| `model.class_name` | AllInOneCNNTransformer |
| `model.num_classes` | 9（1 subject + 8 emotion） |
| `training.optimizer.lr` | 5e-4（低于其他模型） |
| `training.optimizer.weight_decay` | 1e-2（高于其他模型） |
| `training.loss` | weighted_sum（多任务损失） |
| `training.early_stop.early_metric` | val_emotion_accuracy |
| `best_checkpoints` | 4 个独立检查点 |

---

### 6.4 `data_source` 训练数据来源配置（V0.1.15.post1+）

控制训练数据集的加载模式：

```yaml
training:
  data_source:
    mode: "full"              # "full"（全部样本）| "batch_index"（指定 CSV 子集）
    batch_index_csv: null     # batch_index 模式时的 CSV 路径
```

| 字段 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `mode` | string | `"full"` | `"full"` 加载 manifest 全部样本；`"batch_index"` 仅加载 CSV 指定样本 |
| `batch_index_csv` | string/null | null | `batch_index` 模式时指定的索引 CSV 路径（由 `eemo tool data-to-batchs-index` 生成） |

**使用场景：**
- `full` 模式：标准训练，加载全部重采样数据
- `batch_index` 模式：分批训练微调，从大量重采样数据中分批加载。配合 `eemo tool data-to-batchs-index` 生成的 batch CSV 使用

**命令行覆盖：**
```bash
eemo train --config configs/train_full.yaml -m subject_state \
  -o models.subject_state.training.data_source.mode=batch_index \
  -o models.subject_state.training.data_source.batch_index_csv=data/batchs/ss/batch_001.csv
```

---

### 6.5 `preload` 内存预加载配置（V0.1.11.post3+）

控制训练数据是否预加载到内存以加速训练：

```yaml
training:
  preload:
    enabled: true                 # 启用预加载
    compression: "float16"        # 压缩方式
    system_reserve_ratio: 0.05    # 系统保留内存比例
    preload_val: false            # 是否也预加载验证集
    skip_meta: true               # 跳过 meta 字典
```

| 字段 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `enabled` | bool | `true` | 是否启用内存预加载 |
| `compression` | string | `"float16"` | 张量压缩方式：`"float16"`（2x 压缩）、`"bfloat16"`、`"none"`（不压缩） |
| `system_reserve_ratio` | float | `0.05` | 系统保留内存占总内存比例（5%），防止 OOM |
| `preload_val` | bool | `false` | 是否也预加载验证集数据（与训练集共享内存预算） |
| `skip_meta` | bool | `true` | 跳过 `meta` 字典不缓存（不参与前向计算，节省内存） |

**工作机制：**
- 渐进式加载：训练开始后逐步将样本加载到内存，100% 加载完成后升级为全量模式
- 动态滑动窗口：内存不足时自动使用流式模式（队尾进/队头出），实时感知空余内存
- 并发安全：两个分类器同时启动时各自逐步加载，不会竞态 OOM
- 跨平台：Linux (`/proc/meminfo`) + Windows (`ctypes`) + macOS (`sysctl`)

---

### 6.6 `stats_features` 统计特征注入配置（V0.1.14+）

仅 V2 双路模型支持。将频域/时域统计特征通过 MLP 投影后残差注入 Fusion Transformer：

```yaml
model:
  stats_features:
    enabled: true               # 是否启用
    features:                   # 从 35 个特征中选择子集
      - "band_power_delta"
      - "band_power_theta"
      - "band_power_alpha"
      - "band_power_beta"
      - "band_power_gamma"
      # ... 共 25 个推荐特征
    projection_dim: 64           # MLP 中间层维度
```

| 字段 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `enabled` | bool | `true` | 是否启用统计特征注入（`false` 时模型行为与 V2 基线相同） |
| `features` | list | 25 个特征 | 从 35 个可用特征中选择使用的特征子集（按名称选择） |
| `projection_dim` | int | `64` | 2 层 MLP 的中间层维度（输入 C×N_sel，输出 d_model） |

**35 个可用特征分类：**
- 频段功率 (16): band_power_delta/theta/alpha/beta/gamma × (raw+pp), band_ratio_*
- FFT 直接 (3): peak_frequency, median_frequency, fft_max_power
- 时域 (8): mean, std, skewness, kurtosis, rms, hjorth_activity/mobility/complexity
- 频谱形状 (5): spectral_entropy/centroid/bandwidth, total_power, relative_*

---

### 6.7 `scheduler.cosine_t_max` 余弦退火周期（V0.1.15.post1+）

显式控制余弦退火调度器的周期参数：

```yaml
training:
  scheduler:
    type: "cosine"
    cosine_t_max: 100        # 余弦退火周期
    min_lr: 1.0e-6
    warmup_epochs: 5
```

| 字段 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `cosine_t_max` | int | `0`（等于 epochs） | 余弦退火周期。设为 0 或不设置时等于 `training.epochs`；设为具体值可实现 warm restart |

**使用场景：**
- `cosine_t_max: 100` + `epochs: 100` → 标准单周期余弦退火
- `cosine_t_max: 50` + `epochs: 100` → 两个完整周期（warm restart）
- `cosine_t_max: 0` → 自动等于 epochs（默认行为）

---

### 6.8 优化器配置详解

支持三种优化器，使用嵌套 `optimizer` 对象配置：

```yaml
training:
  optimizer:
    type: "adamw"         # 优化器类型
    lr: 1.0e-3            # 学习率
    weight_decay: 1.0e-4  # 权重衰减
```

| 参数 | adamw | adam | sgd | 说明 |
|------|-------|------|-----|------|
| `betas` | [0.9, 0.999] | [0.9, 0.999] | — | 一阶/二阶矩估计系数 |
| `eps` | 1e-8 | 1e-8 | — | 防除零常数 |
| `amsgrad` | — | false | — | AMSGrad 变体 |
| `momentum` | — | — | 0.9 | 动量 |
| `nesterov` | — | — | false | Nesterov 动量 |

---

### 6.9 调度器配置详解

支持 6 种学习率调度器 + warmup 预热：

```yaml
training:
  scheduler:
    type: "cosine"
    cosine_t_max: 100       # 余弦退火周期（V0.1.15.post1+）
    min_lr: 1.0e-6
    warmup_epochs: 5
```

| 调度器 | 专用参数 | 说明 |
|--------|---------|------|
| `cosine` | `cosine_t_max` | 余弦退火（默认），周期默认等于 epochs |
| `cosine_warmup` | — | 带预热的余弦退火 |
| `cosine_warmrestarts` | `warmrestart_t0`, `warmrestart_t_mult` | 带热重启的余弦退火 |
| `steplr` | `step_size`, `step_gamma` | 阶梯式衰减 |
| `plateau` | `plateau_factor`, `plateau_patience`, `plateau_mode` | 自适应降低学习率 |
| `onecycle` | `onecycle_pct_start` | 1Cycle 策略 |

---

### 6.10 三阶段推理配置 (`infer_three_stage.yaml`)

```yaml
inference:
  routing: "hard"
  use_4_4_constraint: true
  positive_label: 1
  neutral_label: 0
  output_format: "xlsx"
  submit_columns:
    - user_id
    - trial_id
    - Emotion_label

models:
  subject_state:
    checkpoint: "experiments/default/checkpoints/subject_state/best_val_accuracy.ckpt"
    config: "configs/train_full.yaml"
  normal_emotion:
    checkpoint: "experiments/default/checkpoints/normal_emotion/best_val_accuracy.ckpt"
    config: "configs/train_full.yaml"
  depression_emotion:
    checkpoint: "experiments/default/checkpoints/depression_emotion/best_val_accuracy.ckpt"
    config: "configs/train_full.yaml"

test_data:
  test_dir: "dataset/公开测试集"
  test_index_file: "data/index/test_subjects.csv"
  auto_detect_test_key: true
  trial_points: 2500
  num_trials: 8

preprocess:
  channel_band_config_source: "checkpoint_config"
  require_same_channel_band_config: true
  clip_std: 5.0
  zscore:
    enabled: true
    eps: 1.0e-6

postprocessing:
  method: "subject_topk"
  positive_count_per_subject: 4
  negative_count_per_subject: 4
```

---

## 7. 目录结构说明

### 7.1 项目根目录

```
DGLZ/
├── configs/
│   └── base/                       # 标准配置模板（eemo get 的来源）
│       ├── train_full.yaml         # 统一训练配置
│       ├── resample.yaml           # 统一重采样配置
│       ├── infer_three_stage.yaml  # 三阶段推理配置
│       └── preprocess.yaml         # 预处理配置
├── src/eemoclas/                   # 源代码
│   ├── cli/                        # CLI 命令实现
│   ├── config/                     # Dataclass 配置系统 (V0.1.4)
│   │   ├── dataclasses.py          # 31 个类型化配置类
│   │   ├── loader.py               # YAML 加载 + 格式检测
│   │   └── overrides.py            # 点分键值覆盖
│   ├── data/                       # 数据 I/O、预处理
│   ├── datasets/                   # PyTorch 数据集类
│   ├── model/                      # CNN-Transformer 模型
│   ├── prediction/                 # 推理与后处理
│   ├── resampling/                 # 离线重采样
│   ├── training/                   # 训练循环 + 编排器 (V0.1.4)
│   │   ├── orchestrator.py         # 多模型训练编排器
│   │   ├── experiment.py           # 实验管理器
│   │   ├── callbacks.py            # 多指标检查点回调
│   │   ├── optimizer.py            # 增强优化器
│   │   └── scheduler.py            # 增强调度器
│   └── utils/                      # 日志、显示、指标
│       └── display.py              # Rich 终端美化 (V0.1.4)
├── tests/                          # 单元测试（303 个测试）
├── pyproject.toml                  # 项目配置
├── HELP.md                         # 本文件
└── plan/                           # 设计文档
```

### 7.2 数据目录

```
data/
├── index/                          # 数据索引
│   ├── train_subjects.csv          # 训练被试索引
│   └── test_subjects.csv           # 测试被试索引
└── resampled/                      # 重采样数据
    ├── subject_state/version_001/
    │   ├── manifest.csv            # 样本清单
    │   ├── config_snapshot.yaml    # 配置快照
    │   ├── stats.json              # 统计信息
    │   └── samples/                # .pt 样本文件
    ├── normal_emotion/version_001/
    └── depression_emotion/version_001/
```

### 7.3 实验输出目录 (V0.1.8)

```
experiments/                        # 实验根目录
└── <实验名>/
    ├── config.yaml                 # 完整配置快照
    ├── training_state.yaml         # 多模型训练状态（含 fold 级别）
    ├── checkpoints/                # 模型检查点
    │   ├── subject_state/
    │   │   ├── best_model.ckpt     # holdout 最优模型
    │   │   ├── latest_model.ckpt   # holdout 最新模型
    │   │   ├── fold_0/             # kfold 各折检查点
    │   │   │   ├── best_model.ckpt
    │   │   │   └── latest_model.ckpt
    │   │   ├── fold_1/
    │   │   ├── fold_best/          # 最佳折检查点拷贝
    │   │   │   ├── best_model.ckpt
    │   │   │   └── latest_model.ckpt
    │   │   └── kfold_summary.yaml  # 跨折聚合指标
    │   ├── normal_emotion/
    │   └── depression_emotion/
    ├── logs/                       # 训练日志
    │   ├── training.log
    │   ├── subject_state_fold_0/   # kfold 每折指标
    │   │   └── metrics_history.csv
    │   └── metrics_history.csv     # holdout 指标
    ├── metrics/                    # 指标 CSV（预留）
    └── results/                    # 训练结果

outputs/                            # 推理输出
├── submission.xlsx                 # 提交文件 (Excel)
├── submission.csv                  # 提交文件 (CSV)
├── routing_summary.csv             # 路由详情
└── pred_*.csv                      # 单模型预测结果
```

---

## 8. 权重初始化与训练恢复

### 8.1 预训练权重初始化（`init-weight`）

所有 7 个分类器支持从已有 `.ckpt` 文件加载 `model_state_dict` 作为预训练权重初始化。仅加载模型权重，不恢复训练状态（optimizer/scheduler/early_stopping/epoch），训练从 epoch 1 开始。适用于 transfer learning / fine-tuning 场景。

**配置文件方式：**

在每个分类器的 `training` 段配置 `init_weight`：

```yaml
training:
  init_weight:                              # 预训练权重初始化配置
    path: null                              # 预训练权重 .ckpt 文件路径（null=不使用，从随机初始化开始）
    strict: false                           # 权重加载模式: true=严格匹配 | false=宽松匹配
```

**CLI 方式（推荐，全局覆盖）：**

```bash
# 使用预训练权重初始化所有训练的分类器
eemo train --config configs/train_full.yaml -m subject_state \
  --init-weight experiments/run01/checkpoints/subject_state/best_val_accuracy.ckpt \
  --verbose

# 指定严格匹配模式
eemo train --config configs/train_full.yaml -m subject_state \
  --init-weight best_model.ckpt --init-weight-strict true --verbose
```

**参数说明：**

| 参数 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `init_weight.path` / `--init-weight` | TEXT | null | `.ckpt` 文件路径 |
| `init_weight.strict` / `--init-weight-strict` | true/false | false | 权重加载模式 |

**strict 模式：**

| 模式 | 行为 |
|------|------|
| `false`（默认） | 允许部分权重不匹配，跳过缺失/多余 key，记录 warning 日志 |
| `true` | 要求源/目标模型结构完全一致，key 不匹配时抛出 RuntimeError |

**优先级**：CLI `--init-weight` > YAML `init_weight.path`

**互斥关系**：`--init-weight` 与 `--resume` 互斥，同时指定会报错退出

**日志输出示例：**

```
2026-05-13 22:00:00 | INFO | dglz.orchestrator | Init weights loaded from experiments/run01/checkpoints/subject_state/best_model.ckpt (strict=False)
2026-05-13 22:00:00 | WARNING | dglz.orchestrator | Init weight missing keys: ['classification_head.fc.weight', 'classification_head.fc.bias']
```

### 8.2 随机种子初始化（`seeding.init_seed`）

每个分类器通过 `seeding.init_seed` 控制模型权重的确定性初始化：

```yaml
seeding:
  random_seed: 42          # 全局随机种子（Python random, NumPy）
  split_seed: 42           # 数据划分种子（K-fold / holdout）
  init_seed: 42            # 模型权重初始化种子
```

**三级种子体系：**

| 种子 | 作用范围 | 影响内容 |
|------|---------|---------|
| `random_seed` | 全局 | Python `random`、NumPy RNG，影响数据打乱、增强随机性 |
| `split_seed` | 数据划分 | `StratifiedGroupKFold` / holdout 划分结果 |
| `init_seed` | 模型权重 | PyTorch 模型参数的随机初始化 |

**使用场景：**
- **完全复现**：三个种子相同值 → 训练结果完全一致
- **仅变初始化**：固定 `random_seed` + `split_seed`，仅改 `init_seed` → 相同数据划分，不同初始权重
- **仅变划分**：固定 `random_seed` + `init_seed`，仅改 `split_seed` → 相同初始化，不同 train/val 划分

**每个分类器的 init_seed 默认值：**

| 分类器 | init_seed |
|--------|-----------|
| subject_state | 42 |
| normal_emotion | 42 |
| depression_emotion | 42 |
| dual_subject_state | 42 |
| dual_normal_emotion | 42 |
| dual_depression_emotion | 42 |
| all_in_one | 42 |

**命令行覆盖：**
```bash
# 改变 subject_state 的权重初始化种子
eemo train --config configs/train_full.yaml -m subject_state \
  -o models.subject_state.seeding.init_seed=123 --verbose
```

### 8.3 训练恢复（`--resume`）

DGLZ 提供三层训练中断/恢复保障：

**1. 自动发现恢复：**

训练启动时自动检测 `latest_model.ckpt`，存在则恢复训练：
```bash
# 正常启动即可，系统自动检测
eemo train --config configs/train_full.yaml -m subject_state --verbose
# 如果存在 latest_model.ckpt → 自动从该 epoch 恢复
```

**2. 指定路径恢复：**

手动指定 checkpoint 路径恢复：
```bash
eemo train --config configs/train_full.yaml -m subject_state \
  --resume experiments/default/checkpoints/subject_state/fold_0/latest_model.ckpt \
  --verbose
```

**3. 强制重训：**

跳过自动恢复，从头开始训练：
```bash
eemo train --config configs/train_full.yaml -m subject_state \
  --fresh --verbose
```

**恢复范围：**
- **Holdout 模式**：恢复 epoch 级别（optimizer/scheduler/early_stopping/history 全部恢复）
- **K-fold 模式**：恢复 fold+epoch 级别（已完成 fold 自动跳过，中断 fold 从中断 epoch 继续）

**K-fold 折级恢复示例：**
```bash
# 5-fold 训练在 fold_2 epoch_37 中断
# 重新运行同一命令 → fold_0/fold_1 自动跳过，fold_2 从 epoch 38 继续

eemo train --config configs/train_full.yaml -m subject_state --verbose
```

**恢复状态包含：**
- 模型权重（`model_state_dict`）
- 优化器状态（`optimizer_state_dict`）
- 调度器状态（`scheduler_state_dict`）
- 早停状态（`early_stopping_state`）
- 训练历史（`history` + `best_metric_value`）
- 训练 Plot 从完整历史重新生成

---

## 9. 常见问题

### Q: `eemo doctor` 显示 CUDA 不可用？

确保已安装 CUDA 版本的 PyTorch：
```bash
nvidia-smi  # 查看 CUDA 版本
pip install torch torchvision --index-url https://download.pytorch.org/whl/cu124
```

### Q: 统一配置文件的结构是什么？

统一配置 (`train_full.yaml`) 将三个模型集中在一个文件的 `models` 字段下，支持多模型训练、`--models` 选择、`--override` 动态覆盖。配置文件支持标签平滑 (`label_smoothing`)、梯度裁剪 (`gradient_clip_val`)、Holdout 划分模式等高级训练参数。

### Q: 如何仅训练部分模型？

```bash
# 仅训练被试状态分类器
eemo train --config configs/train_full.yaml -m subject_state --verbose

# 训练两个模型
eemo train --config configs/train_full.yaml -m subject_state,normal_emotion --verbose
```

### Q: 如何使用命令行动态修改训练参数？

使用 `--override` / `-o` 选项，可重复使用：
```bash
eemo train --config configs/train_full.yaml \
  -o experiment.name=exp_v2 \
  -o models.subject_state.training.epochs=200 \
  -o models.subject_state.training.optimizer.lr=0.002 \
  -o models.normal_emotion.training.batch_size=64 \
  --verbose
```

### Q: 重采样时提示 `.mat` 文件找不到？

检查 `data.index_file` 路径是否正确，确保 `prepare` 命令已生成索引 CSV。路径支持中文目录名。

### Q: 如何使用 K-Fold 交叉验证？

配置文件默认使用 `StratifiedGroupKFold`。通过 `splitting.method` 切换模式：
```bash
# K-Fold 训练（默认）
eemo train --config configs/train_full.yaml -m subject_state --verbose

# 切换为 holdout 单折训练
eemo train --config configs/train_full.yaml -m subject_state \
  -o models.subject_state.splitting.method=holdout --verbose

# 调整折数
eemo train --config configs/train_full.yaml -m subject_state \
  -o models.subject_state.splitting.n_splits=3 --verbose
```

K-Fold 结果查看 `checkpoints/{model}/kfold_summary.yaml`，最佳折检查点在 `fold_best/`。

### Q: 如何调整训练参数？

编辑 `configs/train_full.yaml` 或使用 `--override`：
- `training.epochs` — 增大延长训练
- `training.optimizer.lr` — 调整学习率（推荐范围 1e-4 ~ 1e-3）
- `training.batch_size` — 根据显存调整
- `training.class_weight: "auto"` — 缓解类别不平衡

### Q: 如何增加训练样本数量？

编辑配置中的 `resample` 段：
- `resample.samples_per_subject` — 每被试样本数（subject_state）
- `resample.samples_per_segment` — 每段样本数（normal_emotion / depression_emotion）
- 增大后重新运行 `eemo resample`

### Q: 如何使用不同的频带配置？

修改配置中的 `channel_band_config`：
```yaml
channel_band_config:
  default_bands: ["delta", "theta", "alpha", "beta"]  # 使用 4 个频带
  # C_eff = 30 × 4 = 120
```
修改后需重新运行重采样和训练。

### Q: 推理时如何覆盖模型路径？

```bash
eemo infer-three-stage \
  --subject-state-model path/to/ss.ckpt \
  --normal-emotion-model path/to/ne.ckpt \
  --depression-emotion-model path/to/de.ckpt
```

### Q: 如何查看训练好的模型指标？

```bash
# 校验配置
eemo config validate --config configs/train_full.yaml

# 查看检查点详情
eemo ckpt info experiments/default/checkpoints/subject_state/best_val_accuracy.ckpt

# 查看所有实验对比
eemo exp-train compare --names exp1,exp2,exp3
```

### Q: 单元测试如何运行？

```bash
conda run -n dglz python -m pytest tests/ -v
```

### Q: 如何查看完整的生效配置？

```bash
# 查看完整配置
eemo config show --config configs/train_full.yaml

# 查看指定段
eemo config show --config configs/train_full.yaml --model signal
```
