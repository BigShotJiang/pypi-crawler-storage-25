"""Batch indexer -- extract subsets from a resampled manifest CSV.

Generates batch CSV files (manifest subsets) for incremental training.
"""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd


def create_batch_indexes(
    manifest_path: str,
    output_dir: str,
    batch_sizes: list[int],
    seed: int | None = None,
    prefix: str = "batch",
) -> dict:
    """从 manifest CSV 不放回抽取，生成 batch 索引文件。

    Parameters
    ----------
    manifest_path:
        输入 manifest.csv 文件路径。
    output_dir:
        输出目录（不存在则创建）。
    batch_sizes:
        每个 batch 的样本数量列表。长度决定 batch 数量。
    seed:
        随机种子，确保可复现。None 时不设种子。
    prefix:
        输出文件前缀，默认 "batch"。

    Returns
    -------
    dict
        抽取摘要信息（total_samples, num_batches, batch_sizes, remainder_size, ...）。

    Raises
    ------
    FileNotFoundError
        manifest_path 不存在。
    ValueError
        batch_sizes 非法（含 0 或总和超过样本数）。
    """
    manifest_path = Path(manifest_path)
    if not manifest_path.exists():
        raise FileNotFoundError(f"Manifest not found: {manifest_path}")

    df = pd.read_csv(manifest_path)
    total = len(df)

    # Validate batch_sizes
    if not batch_sizes:
        raise ValueError("batch_sizes must not be empty")
    for i, sz in enumerate(batch_sizes):
        if sz <= 0:
            raise ValueError(f"batch_sizes[{i}] must be > 0, got {sz}")
    if sum(batch_sizes) > total:
        raise ValueError(
            f"batch sizes sum ({sum(batch_sizes)}) exceeds total samples ({total})"
        )

    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)

    rng = np.random.default_rng(seed)
    indices = np.arange(total)
    rng.shuffle(indices)

    output_files: list[str] = []
    offset = 0

    for i, size in enumerate(batch_sizes):
        batch_indices = indices[offset : offset + size]
        batch_df = df.iloc[batch_indices].reset_index(drop=True)
        filename = f"{prefix}_{i + 1:03d}.csv"
        batch_df.to_csv(out / filename, index=False)
        output_files.append(filename)
        offset += size

    # Remainder
    remainder_size = total - offset
    if remainder_size > 0:
        rem_indices = indices[offset:]
        rem_df = df.iloc[rem_indices].reset_index(drop=True)
        rem_filename = "remainder.csv"
        rem_df.to_csv(out / rem_filename, index=False)
        output_files.append(rem_filename)

    # Summary
    result = {
        "source_manifest": str(manifest_path),
        "total_samples": total,
        "num_batches": len(batch_sizes),
        "batch_sizes": batch_sizes,
        "remainder_size": remainder_size,
        "seed": seed,
        "output_files": output_files,
    }

    with open(out / "batch_summary.json", "w", encoding="utf-8") as f:
        json.dump(result, f, indent=2, ensure_ascii=False)

    return result
