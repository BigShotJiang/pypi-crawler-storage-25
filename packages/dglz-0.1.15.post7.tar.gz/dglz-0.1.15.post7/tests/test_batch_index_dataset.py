"""Tests for batch_index_csv support in ResampledTensorDataset."""

import tempfile
from pathlib import Path

import pandas as pd
import torch

from eemoclas.datasets.resampled_dataset import ResampledTensorDataset


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _create_manifest_and_samples(tmp_path: Path) -> Path:
    """Create a minimal manifest with corresponding .pt sample files."""
    samples_dir = tmp_path / "samples"
    samples_dir.mkdir()

    rows = []
    for i in range(10):
        sample_path = samples_dir / f"sample_{i:04d}.pt"
        torch.save(
            {
                "x": torch.randn(8, 30, 2500),
                "y": i % 2,
                "subject_id": f"sub_{i % 5}",
                "token_meta": [{}] * 30,
                "meta": {"idx": i},
            },
            sample_path,
        )
        rows.append(
            {
                "sample_id": f"sample_{i:04d}",
                "sample_path": str(sample_path),
                "subject_id": f"sub_{i % 5}",
                "group_label": i % 2,
            }
        )

    manifest_path = tmp_path / "manifest.csv"
    pd.DataFrame(rows).to_csv(manifest_path, index=False)
    return manifest_path


def _create_batch_csv(tmp_path: Path, sample_ids: list[str]) -> Path:
    """Create a batch CSV with the given sample IDs."""
    batch_path = tmp_path / "batch.csv"
    pd.DataFrame({"sample_id": sample_ids}).to_csv(batch_path, index=False)
    return batch_path


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


class TestBatchIndexDataset:
    """Tests for batch_index_csv filtering in ResampledTensorDataset."""

    def test_full_mode_loads_all(self, tmp_path):
        """Default (no batch_index_csv) loads all 10 samples."""
        manifest_path = _create_manifest_and_samples(tmp_path)
        dataset = ResampledTensorDataset(manifest_path)
        assert len(dataset) == 10

    def test_batch_index_filters_samples(self, tmp_path):
        """batch_index_csv with 3 IDs yields exactly 3 samples."""
        manifest_path = _create_manifest_and_samples(tmp_path)
        batch_path = _create_batch_csv(
            tmp_path,
            ["sample_0001", "sample_0005", "sample_0009"],
        )
        dataset = ResampledTensorDataset(manifest_path, batch_index_csv=str(batch_path))
        assert len(dataset) == 3

    def test_batch_index_preserves_order(self, tmp_path):
        """Order follows original manifest, not batch CSV order."""
        manifest_path = _create_manifest_and_samples(tmp_path)
        # Batch CSV lists samples in reverse order
        batch_path = _create_batch_csv(
            tmp_path,
            ["sample_0005", "sample_0002", "sample_0000"],
        )
        dataset = ResampledTensorDataset(manifest_path, batch_index_csv=str(batch_path))

        # Manifest order is sample_0000, sample_0002, sample_0005
        row0_id = dataset.manifest.iloc[0]["sample_id"]
        row1_id = dataset.manifest.iloc[1]["sample_id"]
        row2_id = dataset.manifest.iloc[2]["sample_id"]

        assert row0_id == "sample_0000"
        assert row1_id == "sample_0002"
        assert row2_id == "sample_0005"

    def test_batch_index_empty_result(self, tmp_path):
        """batch_index_csv with non-matching IDs yields 0 samples."""
        manifest_path = _create_manifest_and_samples(tmp_path)
        batch_path = _create_batch_csv(
            tmp_path,
            ["nonexistent_001", "nonexistent_002"],
        )
        dataset = ResampledTensorDataset(manifest_path, batch_index_csv=str(batch_path))
        assert len(dataset) == 0

    def test_none_batch_index_same_as_full(self, tmp_path):
        """batch_index_csv=None behaves the same as not providing it."""
        manifest_path = _create_manifest_and_samples(tmp_path)
        dataset_default = ResampledTensorDataset(manifest_path)
        dataset_none = ResampledTensorDataset(manifest_path, batch_index_csv=None)
        assert len(dataset_none) == len(dataset_default)
        assert len(dataset_none) == 10
