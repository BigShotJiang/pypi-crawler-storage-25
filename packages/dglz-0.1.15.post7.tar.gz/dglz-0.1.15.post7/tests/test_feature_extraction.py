"""Tests for the feature_extraction module (35 per-channel EEG features)."""

import numpy as np
import pytest
import torch

from eemoclas.data.feature_extraction import (
    FEATURE_INDEX,
    FEATURE_NAMES,
    N_FEATURES,
    POWER_FEATURE_INDICES,
    compute_channel_stats,
    compute_trial_stats,
    select_features,
)


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

FS = 250  # standard EEG sampling rate


# ---------------------------------------------------------------------------
# Feature metadata
# ---------------------------------------------------------------------------

class TestFeatureMetadata:
    """Tests for feature name / index metadata."""

    def test_feature_count_is_35(self):
        assert N_FEATURES == 35
        assert len(FEATURE_NAMES) == 35

    def test_no_duplicate_feature_names(self):
        assert len(set(FEATURE_NAMES)) == 35

    def test_feature_index_bidirectional(self):
        for i, name in enumerate(FEATURE_NAMES):
            assert FEATURE_INDEX[name] == i
            assert FEATURE_NAMES[FEATURE_INDEX[name]] == name

    def test_power_feature_indices_valid(self):
        assert POWER_FEATURE_INDICES == {0, 1, 2, 3, 4, 10, 16, 17, 18}
        for idx in POWER_FEATURE_INDICES:
            assert 0 <= idx < 35


# ---------------------------------------------------------------------------
# compute_channel_stats
# ---------------------------------------------------------------------------

class TestComputeChannelStats:
    """Tests for single-channel feature computation."""

    def test_output_shape_and_dtype(self):
        rng = np.random.default_rng(42)
        signal = rng.standard_normal(1250)
        stats = compute_channel_stats(signal, fs=FS)
        assert stats.shape == (35,)
        assert stats.dtype == np.float32

    def test_no_nan_inf_for_zero_signal(self):
        signal = np.zeros(1250, dtype=np.float64)
        stats = compute_channel_stats(signal, fs=FS)
        assert np.all(np.isfinite(stats))

    def test_no_nan_inf_for_tiny_signal(self):
        signal = np.full(1250, 1e-30)
        stats = compute_channel_stats(signal, fs=FS)
        assert np.all(np.isfinite(stats))

    def test_deterministic_output(self):
        rng = np.random.default_rng(123)
        signal = rng.standard_normal(1250)
        a = compute_channel_stats(signal, fs=FS)
        b = compute_channel_stats(signal, fs=FS)
        np.testing.assert_array_equal(a, b)

    def test_sine_wave_peak_frequency(self):
        """A 10 Hz sine should have peak_frequency near 10 Hz."""
        t = np.arange(0, 2.0, 1.0 / FS)
        signal = np.sin(2 * np.pi * 10.0 * t)
        stats = compute_channel_stats(signal, fs=FS)
        peak_freq = stats[FEATURE_INDEX["peak_frequency"]]
        assert abs(peak_freq - 10.0) < 2.0  # generous FFT bin tolerance

    def test_short_signal_handled(self):
        """Very short signals should not crash."""
        rng = np.random.default_rng(7)
        signal = rng.standard_normal(32)
        stats = compute_channel_stats(signal, fs=FS)
        assert stats.shape == (35,)
        assert np.all(np.isfinite(stats))

    def test_rejects_2d_input(self):
        with pytest.raises(ValueError, match="1-D"):
            compute_channel_stats(np.zeros((3, 100)), fs=FS)


# ---------------------------------------------------------------------------
# compute_trial_stats
# ---------------------------------------------------------------------------

class TestComputeTrialStats:
    """Tests for multi-channel trial feature computation."""

    def test_output_shape(self):
        rng = np.random.default_rng(42)
        trial = rng.standard_normal((5, 1250))
        stats = compute_trial_stats(trial, fs=FS)
        assert stats.shape == (5, 35)
        assert stats.dtype == np.float32

    def test_per_channel_independence(self):
        """Changing one channel should only affect that channel's features."""
        rng = np.random.default_rng(99)
        trial_a = rng.standard_normal((3, 1250))
        trial_b = trial_a.copy()
        # Modify channel 1 only
        trial_b[1] = rng.standard_normal(1250) * 10.0

        stats_a = compute_trial_stats(trial_a, fs=FS)
        stats_b = compute_trial_stats(trial_b, fs=FS)

        # Channel 0 unchanged
        np.testing.assert_array_equal(stats_a[0], stats_b[0])
        # Channel 2 unchanged
        np.testing.assert_array_equal(stats_a[2], stats_b[2])
        # Channel 1 differs
        assert not np.array_equal(stats_a[1], stats_b[1])

    def test_single_channel_trial(self):
        rng = np.random.default_rng(5)
        trial = rng.standard_normal((1, 1250))
        stats = compute_trial_stats(trial, fs=FS)
        assert stats.shape == (1, 35)

    def test_rejects_1d_input(self):
        with pytest.raises(ValueError, match="2-D"):
            compute_trial_stats(np.zeros(1250), fs=FS)


# ---------------------------------------------------------------------------
# select_features
# ---------------------------------------------------------------------------

class TestSelectFeatures:
    """Tests for feature subset selection."""

    def test_subset_selection_shape_and_order(self):
        rng = np.random.default_rng(42)
        stats = rng.standard_normal((4, 35)).astype(np.float32)
        names = ["band_power_alpha", "mean", "spectral_entropy"]
        sub = select_features(stats, names)
        assert sub.shape == (4, 3)
        for i, name in enumerate(names):
            col = FEATURE_INDEX[name]
            np.testing.assert_array_equal(sub[:, i], stats[:, col])

    def test_all_features_returns_identical(self):
        rng = np.random.default_rng(0)
        stats = rng.standard_normal(35).astype(np.float32)
        sub = select_features(stats, FEATURE_NAMES)
        np.testing.assert_array_equal(sub, stats)

    def test_works_with_torch_tensor(self):
        rng = np.random.default_rng(42)
        stats_np = rng.standard_normal((3, 35)).astype(np.float32)
        stats_t = torch.from_numpy(stats_np)

        names = ["band_power_delta", "rms", "hjorth_complexity"]
        sub = select_features(stats_t, names)
        assert isinstance(sub, torch.Tensor)
        assert sub.shape == (3, 3)

        # Verify values match numpy indexing
        for i, name in enumerate(names):
            col = FEATURE_INDEX[name]
            np.testing.assert_array_equal(
                sub[:, i].numpy(), stats_np[:, col]
            )

    def test_single_feature(self):
        stats = np.zeros((2, 35), dtype=np.float32)
        stats[:, FEATURE_INDEX["peak_frequency"]] = 42.0
        sub = select_features(stats, ["peak_frequency"])
        assert sub.shape == (2, 1)
        np.testing.assert_array_equal(sub[:, 0], [42.0, 42.0])

    def test_1d_input(self):
        rng = np.random.default_rng(1)
        stats = rng.standard_normal(35).astype(np.float32)
        names = ["mean", "std"]
        sub = select_features(stats, names)
        assert sub.shape == (2,)


# ---------------------------------------------------------------------------
# Integration: stats injection in dual-branch models
# ---------------------------------------------------------------------------

class TestIntegrationStatsInModel:
    """End-to-end test: stats computation -> tensor -> model forward."""

    def test_emotion_model_with_stats(self):
        """Emotion dual-branch model forward pass with stats injection."""
        import torch
        from eemoclas.model.dual_branch_emotion import DualBranchEmotionCNNTransformer

        config = {
            "model": {
                "raw_trial_encoder": {
                    "input_channels": 30, "input_length": 2500, "projection_dim": 64,
                    "cnn_channels": [16], "kernel_sizes": [7], "strides": [2],
                    "use_band_embedding": False,
                },
                "pp_trial_encoder": {
                    "input_channels": 30, "input_length": 2500, "projection_dim": 64,
                    "cnn_channels": [16], "kernel_sizes": [7], "strides": [2],
                    "use_band_embedding": True,
                },
                "fusion_transformer": {"d_model": 64, "num_layers": 1, "num_heads": 2, "dim_feedforward": 64},
                "classification_head": {"input_dim": 64, "num_classes": 2, "hidden_dims": [32]},
                "stats_features": {
                    "enabled": True,
                    "features": ["band_power_alpha", "mean", "hjorth_activity"],
                    "projection_dim": 32,
                },
            },
        }
        model = DualBranchEmotionCNNTransformer(config)
        model.eval()

        B = 2
        with torch.no_grad():
            logits = model(
                torch.randn(B, 30, 2500),
                x_raw=torch.randn(B, 30, 2500),
                stats_raw=torch.randn(B, 30, 35),
                stats_pp=torch.randn(B, 30, 35),
            )
        assert logits.shape == (B, 2)

    def test_emotion_model_without_stats(self):
        """Emotion model without stats (backward compat)."""
        import torch
        from eemoclas.model.dual_branch_emotion import DualBranchEmotionCNNTransformer

        config = {
            "model": {
                "raw_trial_encoder": {
                    "input_channels": 30, "input_length": 2500, "projection_dim": 64,
                    "cnn_channels": [16], "kernel_sizes": [7], "strides": [2],
                    "use_band_embedding": False,
                },
                "pp_trial_encoder": {
                    "input_channels": 30, "input_length": 2500, "projection_dim": 64,
                    "cnn_channels": [16], "kernel_sizes": [7], "strides": [2],
                    "use_band_embedding": True,
                },
                "fusion_transformer": {"d_model": 64, "num_layers": 1, "num_heads": 2, "dim_feedforward": 64},
                "classification_head": {"input_dim": 64, "num_classes": 2, "hidden_dims": [32]},
            },
        }
        model = DualBranchEmotionCNNTransformer(config)
        model.eval()
        with torch.no_grad():
            logits = model(torch.randn(2, 30, 2500), x_raw=torch.randn(2, 30, 2500))
        assert logits.shape == (2, 2)

    def test_subject_state_model_with_stats(self):
        """Subject-state model forward pass with per-sample stats."""
        import torch
        from eemoclas.model.dual_branch_subject_state import DualBranchSubjectStateCNNTransformer

        config = {
            "model": {
                "num_trials": 8,
                "raw_trial_encoder": {
                    "input_channels": 30, "input_length": 2500, "projection_dim": 64,
                    "cnn_channels": [16], "kernel_sizes": [7], "strides": [2],
                    "use_band_embedding": False,
                },
                "pp_trial_encoder": {
                    "input_channels": 30, "input_length": 2500, "projection_dim": 64,
                    "cnn_channels": [16], "kernel_sizes": [7], "strides": [2],
                    "use_band_embedding": True,
                },
                "fusion_transformer": {"d_model": 64, "num_layers": 1, "num_heads": 2, "dim_feedforward": 64},
                "classification_head": {"input_dim": 64, "num_classes": 2, "hidden_dims": [32]},
                "stats_features": {
                    "enabled": True,
                    "features": ["band_power_alpha", "mean"],
                    "projection_dim": 32,
                },
            },
        }
        model = DualBranchSubjectStateCNNTransformer(config)
        model.eval()

        B = 2
        with torch.no_grad():
            logits = model(
                torch.randn(B, 8, 30, 2500),
                x_raw=torch.randn(B, 8, 30, 2500),
                stats_raw=torch.randn(B, 8, 30, 35),
                stats_pp=torch.randn(B, 8, 30, 35),
            )
        assert logits.shape == (B, 2)

    def test_stats_none_backward_compat(self):
        """Model with stats enabled but stats_raw=None skips injection."""
        import torch
        from eemoclas.model.dual_branch_emotion import DualBranchEmotionCNNTransformer

        config = {
            "model": {
                "raw_trial_encoder": {
                    "input_channels": 30, "input_length": 2500, "projection_dim": 64,
                    "cnn_channels": [16], "kernel_sizes": [7], "strides": [2],
                    "use_band_embedding": False,
                },
                "pp_trial_encoder": {
                    "input_channels": 30, "input_length": 2500, "projection_dim": 64,
                    "cnn_channels": [16], "kernel_sizes": [7], "strides": [2],
                    "use_band_embedding": True,
                },
                "fusion_transformer": {"d_model": 64, "num_layers": 1, "num_heads": 2, "dim_feedforward": 64},
                "classification_head": {"input_dim": 64, "num_classes": 2, "hidden_dims": [32]},
                "stats_features": {
                    "enabled": True,
                    "features": ["band_power_alpha"],
                    "projection_dim": 32,
                },
            },
        }
        model = DualBranchEmotionCNNTransformer(config)
        model.eval()
        with torch.no_grad():
            logits = model(
                torch.randn(2, 30, 2500),
                x_raw=torch.randn(2, 30, 2500),
                stats_raw=None, stats_pp=None,
            )
        assert logits.shape == (2, 2)

    def test_stats_mlp_with_zero_input_channels_raises(self):
        """Regression: pp input_channels=0 must raise ValueError.

        The orchestrator auto-detects C_eff from data. If it ever passes
        input_channels=0 (detection failure), the model constructor must
        raise a clear error rather than silently creating a broken MLP.
        """
        import torch
        from eemoclas.model.dual_branch_subject_state import DualBranchSubjectStateCNNTransformer

        # Simulate detection failure injecting input_channels=0
        config = {
            "model": {
                "num_trials": 8,
                "raw_trial_encoder": {
                    "input_channels": 30, "input_length": 2500, "projection_dim": 64,
                    "cnn_channels": [16], "kernel_sizes": [7], "strides": [2],
                    "use_band_embedding": False,
                },
                "pp_trial_encoder": {
                    "input_channels": 0, "input_length": 2500, "projection_dim": 64,
                    "cnn_channels": [16], "kernel_sizes": [7], "strides": [2],
                    "use_band_embedding": True,
                },
                "fusion_transformer": {"d_model": 64, "num_layers": 1, "num_heads": 2, "dim_feedforward": 64},
                "classification_head": {"input_dim": 64, "num_classes": 2, "hidden_dims": [32]},
                "stats_features": {
                    "enabled": True,
                    "features": ["band_power_alpha", "mean"],
                    "projection_dim": 32,
                },
            },
        }
        with pytest.raises(ValueError, match="input_channels not set"):
            DualBranchSubjectStateCNNTransformer(config)

    def test_stats_mlp_without_input_channels_raises(self):
        """Regression: missing pp input_channels must raise ValueError.

        The orchestrator auto-detects C_eff from data and injects it.
        If pp_trial_encoder.input_channels is missing entirely, the model
        must raise rather than falling back to a potentially wrong default.
        """
        import torch
        from eemoclas.model.dual_branch_emotion import DualBranchEmotionCNNTransformer

        # No input_channels in pp_trial_encoder at all
        config = {
            "model": {
                "raw_trial_encoder": {
                    "input_length": 2500, "projection_dim": 64,
                    "cnn_channels": [16], "kernel_sizes": [7], "strides": [2],
                    "use_band_embedding": False,
                },
                "pp_trial_encoder": {
                    "input_length": 2500, "projection_dim": 64,
                    "cnn_channels": [16], "kernel_sizes": [7], "strides": [2],
                    "use_band_embedding": True,
                },
                "fusion_transformer": {"d_model": 64, "num_layers": 1, "num_heads": 2, "dim_feedforward": 64},
                "classification_head": {"input_dim": 64, "num_classes": 2, "hidden_dims": [32]},
                "stats_features": {
                    "enabled": True,
                    "features": ["band_power_alpha", "std", "rms"],
                    "projection_dim": 32,
                },
            },
        }
        with pytest.raises(ValueError, match="input_channels not set"):
            DualBranchEmotionCNNTransformer(config)

    def test_data_driven_c_eff_detection(self):
        """Integration: C_eff auto-detected from manifest/sample should work."""
        import torch
        from eemoclas.model.dual_branch_subject_state import DualBranchSubjectStateCNNTransformer

        # Simulate orchestrator injecting C_eff=30 from manifest
        config = {
            "model": {
                "num_trials": 8,
                "raw_trial_encoder": {
                    "input_channels": 30, "input_length": 2500, "projection_dim": 64,
                    "cnn_channels": [16], "kernel_sizes": [7], "strides": [2],
                    "use_band_embedding": False,
                },
                "pp_trial_encoder": {
                    "input_channels": 30,  # auto-injected by orchestrator from data
                    "input_length": 2500, "projection_dim": 64,
                    "cnn_channels": [16], "kernel_sizes": [7], "strides": [2],
                    "use_band_embedding": True,
                },
                "fusion_transformer": {"d_model": 64, "num_layers": 1, "num_heads": 2, "dim_feedforward": 64},
                "classification_head": {"input_dim": 64, "num_classes": 2, "hidden_dims": [32]},
                "stats_features": {
                    "enabled": True,
                    "features": ["band_power_alpha", "mean"],
                    "projection_dim": 32,
                },
            },
        }
        model = DualBranchSubjectStateCNNTransformer(config)

        # MLP dimensions correct: 30 channels * 2 features = 60
        assert model.pp_stats_mlp[0].in_features == 30 * 2

        model.eval()
        B = 2
        with torch.no_grad():
            logits = model(
                torch.randn(B, 8, 30, 2500),
                x_raw=torch.randn(B, 8, 30, 2500),
                stats_raw=torch.randn(B, 8, 30, 35),
                stats_pp=torch.randn(B, 8, 30, 35),
            )
        assert logits.shape == (B, 2)
