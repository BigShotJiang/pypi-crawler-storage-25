"""Tests for init-weight pre-trained weight initialization.

Apache-2.0  --  SuShuHeng
"""

import pytest
from pathlib import Path
import torch
import torch.nn as nn
from unittest.mock import patch, MagicMock


class TestInitWeightConfig:
    """Test InitWeightConfig dataclass and loader."""

    def test_defaults(self):
        from eemoclas.config.dataclasses import InitWeightConfig
        cfg = InitWeightConfig()
        assert cfg.path is None
        assert cfg.strict is False

    def test_custom_values(self):
        from eemoclas.config.dataclasses import InitWeightConfig
        cfg = InitWeightConfig(path="/some/ckpt", strict=True)
        assert cfg.path == "/some/ckpt"
        assert cfg.strict is True

    def test_in_training_config(self):
        from eemoclas.config.dataclasses import TrainingConfig
        tc = TrainingConfig()
        assert tc.init_weight.path is None
        assert tc.init_weight.strict is False

    def test_loader_parses_init_weight_dict(self):
        from eemoclas.config.loader import _build_training
        data = {
            "epochs": 50,
            "init_weight": {"path": "/some/checkpoint.ckpt", "strict": True},
        }
        tc = _build_training(data)
        assert tc.init_weight.path == "/some/checkpoint.ckpt"
        assert tc.init_weight.strict is True

    def test_loader_handles_missing_init_weight(self):
        from eemoclas.config.loader import _build_training
        data = {"epochs": 50}
        tc = _build_training(data)
        assert tc.init_weight.path is None
        assert tc.init_weight.strict is False


class TestInitWeightOrchestrator:
    """Test init-weight loading in orchestrator."""

    def test_loads_weights_from_checkpoint(self, tmp_path):
        """Verify model weights are loaded from a .ckpt file."""
        model = nn.Linear(10, 2)
        ckpt_path = tmp_path / "test.ckpt"
        torch.save({
            "model_state_dict": model.state_dict(),
            "epoch": 10,
            "metrics": {},
        }, str(ckpt_path))

        loaded = nn.Linear(10, 2)
        ckpt = torch.load(str(ckpt_path), map_location="cpu", weights_only=False)
        result = loaded.load_state_dict(ckpt["model_state_dict"], strict=False)

        for (n1, p1), (n2, p2) in zip(
            model.named_parameters(), loaded.named_parameters()
        ):
            assert n1 == n2
            assert torch.equal(p1, p2)

    def test_strict_false_allows_mismatch(self, tmp_path):
        """strict=False should not raise on key mismatch."""
        ckpt_path = tmp_path / "mismatch.ckpt"
        torch.save({
            "model_state_dict": {"weight": torch.randn(2, 10), "bias": torch.randn(2)},
            "epoch": 1,
            "metrics": {},
        }, str(ckpt_path))

        model = nn.Linear(10, 2)
        ckpt = torch.load(str(ckpt_path), map_location="cpu", weights_only=False)
        result = model.load_state_dict(ckpt["model_state_dict"], strict=False)
        assert len(result.missing_keys) == 0
        assert len(result.unexpected_keys) == 0

    def test_strict_true_raises_on_mismatch(self, tmp_path):
        """strict=True should raise on key mismatch."""
        ckpt_path = tmp_path / "mismatch.ckpt"
        torch.save({
            "model_state_dict": {
                "weight": torch.randn(2, 10),
                "extra_key": torch.randn(3),
            },
            "epoch": 1,
            "metrics": {},
        }, str(ckpt_path))

        model = nn.Linear(10, 2)
        ckpt = torch.load(str(ckpt_path), map_location="cpu", weights_only=False)
        with pytest.raises(RuntimeError):
            model.load_state_dict(ckpt["model_state_dict"], strict=True)

    def test_file_not_found_raises(self):
        """Non-existent path should raise FileNotFoundError."""
        with pytest.raises(FileNotFoundError):
            torch.load("/nonexistent/path.ckpt", map_location="cpu", weights_only=False)

    def test_missing_model_state_dict_raises(self, tmp_path):
        """Checkpoint without model_state_dict should raise ValueError."""
        ckpt_path = tmp_path / "no_weights.ckpt"
        torch.save({"epoch": 1, "metrics": {}}, str(ckpt_path))

        ckpt = torch.load(str(ckpt_path), map_location="cpu", weights_only=False)
        assert "model_state_dict" not in ckpt


class TestInitWeightCLI:
    """Test CLI parameter handling."""

    def test_init_weight_and_resume_mutex(self):
        """--init-weight and --resume together should fail."""
        from typer.testing import CliRunner
        from eemoclas.cli.main import app

        runner = CliRunner()
        result = runner.invoke(app, [
            "train", "--config", "nonexistent.yaml",
            "--init-weight", "some.ckpt",
            "--resume", "other.ckpt",
        ])
        assert result.exit_code != 0


class TestConfigPanelFilter:
    """Test config panel model filter."""

    def test_model_filter_shows_only_specified(self):
        from eemoclas.config.loader import load_config
        import tempfile

        yaml_content = """
project:
  repo_name: "DGLZ"
  package_name: "eemoclas"
  cli_name: "eemo"
  experiment_family: "test"
signal:
  fs: 250
  train_segment_points: 12500
  window_points: 2500
  clip_std: 5.0
  zscore: {enabled: true, eps: 1.0e-6}
channels: {mode: "by_name", selected: "all"}
band: {definitions: {}, channel_band_config: {default_bands: ["broadband"], per_channel: {}}}
experiment: {name: "test", save_dir: "experiments", save_best: true, save_latest: true, checkpoint_metric: "val_accuracy", monitor_metrics: ["val_accuracy"], val_check_interval: 1.0, notes: ""}
logging: {level: "INFO", format: "%(message)s", log_every_n_steps: 10}
metrics: {primary: "accuracy", report: ["accuracy", "macro_f1", "roc_auc"]}
inference: {routing: "hard", use_4_4_constraint: true}
models:
  subject_state:
    task: {name: "subject_state", dataset_class: "SubjectStateDataset", num_classes: 2, label_names: ["a", "b"]}
    model: {class_name: "SubjectStateCNNTransformer", input_num_trials: 8, input_length: 2500, num_classes: 2}
    training: {epochs: 10, batch_size: 16}
    splitting: {method: "holdout", train_ratio: 0.8, val_ratio: 0.2, group_key: "subject_id", stratify_key: "group_label", seed: 42}
    seeding: {random_seed: 42, split_seed: 42, init_seed: 42}
    augmentation: {enabled: false}
  normal_emotion:
    task: {name: "normal_emotion", dataset_class: "NormalEmotionDataset", num_classes: 2, label_names: ["a", "b"]}
    model: {class_name: "NormalEmotionCNNTransformer", input_num_trials: 8, input_length: 2500, num_classes: 2}
    training: {epochs: 10, batch_size: 32}
    splitting: {method: "holdout", train_ratio: 0.8, val_ratio: 0.2, group_key: "subject_id", stratify_key: "emotion_label", seed: 42}
    seeding: {random_seed: 42, split_seed: 42, init_seed: 42}
    augmentation: {enabled: false}
"""
        with tempfile.NamedTemporaryFile(mode="w", suffix=".yaml", delete=False) as f:
            f.write(yaml_content)
            f.flush()
            config = load_config(f.name)

        # Without filter: both models shown
        sections_all = config.runtime_config_display_sections()
        assert "subject_state - task" in sections_all
        assert "normal_emotion - task" in sections_all

        # With filter: only subject_state shown
        sections_filtered = config.runtime_config_display_sections(
            model_names=["subject_state"]
        )
        assert "subject_state - task" in sections_filtered
        assert "normal_emotion - task" not in sections_filtered

        # Global sections always present
        assert "project" in sections_filtered
        assert "signal" in sections_filtered
        assert "experiment" in sections_filtered

    def test_no_filter_shows_all(self):
        """model_names=None should show all models (backward compat)."""
        from eemoclas.config.loader import load_config
        import tempfile

        yaml_content = """
project: {repo_name: "DGLZ", package_name: "eemoclas", cli_name: "eemo", experiment_family: "test"}
signal: {fs: 250, train_segment_points: 12500, window_points: 2500, clip_std: 5.0, zscore: {enabled: true, eps: 1.0e-6}}
channels: {mode: "by_name", selected: "all"}
band: {definitions: {}, channel_band_config: {default_bands: ["broadband"], per_channel: {}}}
experiment: {name: "test", save_dir: "experiments", save_best: true, save_latest: true, checkpoint_metric: "val_accuracy", monitor_metrics: ["val_accuracy"], val_check_interval: 1.0, notes: ""}
logging: {level: "INFO", format: "%(message)s", log_every_n_steps: 10}
metrics: {primary: "accuracy", report: ["accuracy"]}
inference: {routing: "hard", use_4_4_constraint: true}
models:
  subject_state:
    task: {name: "subject_state", dataset_class: "SubjectStateDataset", num_classes: 2, label_names: ["a", "b"]}
    model: {class_name: "SubjectStateCNNTransformer", input_num_trials: 8, input_length: 2500, num_classes: 2}
    training: {epochs: 10, batch_size: 16}
    splitting: {method: "holdout", train_ratio: 0.8, val_ratio: 0.2, group_key: "subject_id", stratify_key: "group_label", seed: 42}
    seeding: {random_seed: 42, split_seed: 42, init_seed: 42}
    augmentation: {enabled: false}
"""
        with tempfile.NamedTemporaryFile(mode="w", suffix=".yaml", delete=False) as f:
            f.write(yaml_content)
            f.flush()
            config = load_config(f.name)

        sections = config.runtime_config_display_sections(model_names=None)
        assert "subject_state - task" in sections
