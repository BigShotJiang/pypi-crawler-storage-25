"""Test training components."""

import pytest

from eemoclas.training.early_stopping import EarlyStopping


class TestEarlyStopping:
    """Tests for EarlyStopping."""

    def test_early_stopping_max_mode(self):
        """Test early stopping with mode=max (accuracy-like metrics)."""
        es = EarlyStopping(patience=3, mode="max")

        # First call always accepts
        assert es.step(0.5) is False
        assert es.best_score == 0.5

        # Improvement
        assert es.step(0.6) is False
        assert es.best_score == 0.6

        # No improvement, counter = 1
        assert es.step(0.55) is False
        assert es.counter == 1

        # No improvement, counter = 2
        assert es.step(0.55) is False
        assert es.counter == 2

        # No improvement, counter = 3, patience exhausted
        assert es.step(0.55) is True
        assert es.counter == 3

    def test_early_stopping_min_mode(self):
        """Test early stopping with mode=min (loss-like metrics)."""
        es = EarlyStopping(patience=3, mode="min")

        # First call
        assert es.step(1.0) is False
        assert es.best_score == 1.0

        # Improvement (lower is better)
        assert es.step(0.8) is False
        assert es.best_score == 0.8

        # No improvement, counter = 1
        assert es.step(0.9) is False
        assert es.counter == 1

        # No improvement, counter = 2
        assert es.step(0.85) is False
        assert es.counter == 2

        # No improvement, counter = 3, patience exhausted
        assert es.step(0.9) is True
        assert es.counter == 3

    def test_early_stopping_patience_1(self):
        """Test with patience=1 (stop after first non-improvement)."""
        es = EarlyStopping(patience=1, mode="max")

        assert es.step(0.5) is False
        assert es.step(0.4) is True

    def test_early_stopping_min_delta(self):
        """Test that min_delta requires a minimum improvement threshold."""
        es = EarlyStopping(patience=3, mode="max", min_delta=0.1)

        assert es.step(0.5) is False

        # Improvement of 0.05 < min_delta => not an improvement
        assert es.step(0.55) is False
        assert es.counter == 1

        # Improvement of 0.1 == min_delta => still not > best + delta
        assert es.step(0.6) is False
        assert es.counter == 2

        # Improvement of 0.11 > 0.5 + 0.1 => improvement
        assert es.step(0.61) is False
        assert es.counter == 0
        assert es.best_score == 0.61

    def test_early_stopping_invalid_mode(self):
        """Test that invalid mode raises ValueError."""
        with pytest.raises(ValueError, match="mode must be"):
            EarlyStopping(patience=3, mode="invalid")

    def test_early_stopping_invalid_patience(self):
        """Test that patience < 1 raises ValueError."""
        with pytest.raises(ValueError, match="patience"):
            EarlyStopping(patience=0)

    def test_early_stopping_reset_on_improvement_max(self):
        """Test that counter resets on improvement in max mode."""
        es = EarlyStopping(patience=5, mode="max")

        es.step(0.5)
        es.step(0.4)  # counter = 1
        es.step(0.3)  # counter = 2
        es.step(0.6)  # improvement, counter resets

        assert es.counter == 0
        assert es.best_score == 0.6

    def test_early_stopping_reset_on_improvement_min(self):
        """Test that counter resets on improvement in min mode."""
        es = EarlyStopping(patience=5, mode="min")

        es.step(1.0)
        es.step(1.1)  # counter = 1
        es.step(1.2)  # counter = 2
        es.step(0.9)  # improvement, counter resets

        assert es.counter == 0
        assert es.best_score == 0.9


class TestEarlyStoppingState:
    """Tests for EarlyStopping state serialization."""

    def test_state_dict_keys(self):
        es = EarlyStopping(patience=5, mode="max", min_delta=0.01)
        es.step(0.5)
        es.step(0.6)
        es.step(0.55)  # counter = 1
        state = es.state_dict()
        assert "best_score" in state
        assert "counter" in state
        assert state["best_score"] == 0.6
        assert state["counter"] == 1

    def test_load_state_dict_restores_state(self):
        es1 = EarlyStopping(patience=5, mode="max", min_delta=0.01)
        es1.step(0.5)
        es1.step(0.6)
        es1.step(0.55)  # counter = 1
        state = es1.state_dict()

        es2 = EarlyStopping(patience=5, mode="max", min_delta=0.01)
        es2.load_state_dict(state)
        assert es2.best_score == 0.6
        assert es2.counter == 1
        # Continues from restored state
        assert es2.step(0.54) is False  # counter = 2
        assert es2.counter == 2

    def test_load_state_dict_on_fresh_stopping(self):
        es = EarlyStopping(patience=3, mode="max")
        es.load_state_dict({"best_score": 0.9, "counter": 2})
        assert es.best_score == 0.9
        assert es.counter == 2
        # One more non-improvement triggers stop
        assert es.step(0.8) is True
