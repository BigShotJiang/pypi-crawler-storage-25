"""Test AllInOneCNNTransformer model."""

import pytest
import torch

from eemoclas.model.all_in_one import AllInOneCNNTransformer


def _minimal_config(projection_dim=32, input_channels=4):
    return {
        "trial_encoder": {
            "input_channels": input_channels,
            "input_length": 2500,
            "projection_dim": projection_dim,
            "cnn_channels": [16, 32],
            "kernel_sizes": [7, 5],
            "strides": [2, 2],
            "cnn_dropout": 0.1,
            "use_cls_token": True,
            "pooling": "cls",
            "use_channel_embedding": True,
            "use_band_embedding": True,
            "transformer_num_layers": 1,
            "transformer_num_heads": 2,
            "transformer_dim_feedforward": 64,
            "transformer_dropout": 0.1,
        },
        "subject_encoder": {
            "d_model": projection_dim,
            "num_layers": 1,
            "num_heads": 2,
            "dim_feedforward": 64,
            "dropout": 0.1,
        },
        "subject_head": {
            "input_dim": projection_dim,
            "num_classes": 1,
            "hidden_dims": [projection_dim],
            "dropout": 0.3,
        },
        "emotion_head": {
            "input_dim": projection_dim,
            "num_classes": 1,
            "hidden_dims": [projection_dim],
            "dropout": 0.3,
        },
        "num_trials": 8,
        "num_classes": 9,
    }


class TestAllInOneCNNTransformer:

    def test_output_shape(self):
        config = _minimal_config(input_channels=4)
        model = AllInOneCNNTransformer(config)
        x = torch.randn(2, 8, 4, 2500)
        out = model(x)
        assert out.shape == (2, 9)

    def test_batch_size_1(self):
        config = _minimal_config(input_channels=6)
        model = AllInOneCNNTransformer(config)
        x = torch.randn(1, 8, 6, 2500)
        out = model(x)
        assert out.shape == (1, 9)

    def test_gradient_flow(self):
        config = _minimal_config(input_channels=4)
        model = AllInOneCNNTransformer(config)
        x = torch.randn(1, 8, 4, 2500, requires_grad=True)
        out = model(x)
        out.sum().backward()
        assert x.grad is not None

    def test_heads_are_separate(self):
        config = _minimal_config(input_channels=4)
        model = AllInOneCNNTransformer(config)
        subj_params = set(id(p) for p in model.subject_head.parameters())
        emo_params = set(id(p) for p in model.emotion_head.parameters())
        assert subj_params.isdisjoint(emo_params)

    def test_with_token_meta(self):
        c_eff = 3
        config = _minimal_config(input_channels=c_eff)
        model = AllInOneCNNTransformer(config)
        x = torch.randn(1, 8, c_eff, 2500)
        token_meta = [
            {"source_channel": "FP1", "band_name": "alpha"},
            {"source_channel": "FP2", "band_name": "alpha"},
            {"source_channel": "FZ", "band_name": "alpha"},
        ]
        out = model(x, token_meta=token_meta)
        assert out.shape == (1, 9)

    def test_unused_kwargs_no_error(self):
        config = _minimal_config(input_channels=4)
        model = AllInOneCNNTransformer(config)
        x = torch.randn(1, 8, 4, 2500)
        out = model(
            x,
            x_raw=torch.randn(1, 8, 30, 2500),
            stats_raw=torch.randn(1, 8, 30, 35),
            stats_pp=torch.randn(1, 8, 4, 35),
        )
        assert out.shape == (1, 9)

    @pytest.mark.skipif(not torch.cuda.is_available(), reason="No GPU")
    def test_cuda(self):
        config = _minimal_config(input_channels=4)
        model = AllInOneCNNTransformer(config).cuda()
        x = torch.randn(1, 8, 4, 2500, device="cuda")
        out = model(x)
        assert out.shape == (1, 9)
        assert out.device.type == "cuda"
