"""Test multi-task metrics computation."""

import numpy as np
import pytest

from eemoclas.training.multitask_metrics import (
    compute_multitask_train_metrics,
    compute_multitask_val_metrics,
)


def _make_data(n=20):
    rng = np.random.RandomState(42)
    return {
        "subject_loss": 0.5,
        "emotion_loss": 0.6,
        "total_loss": 1.1,
        "group_labels": rng.randint(0, 2, n),
        "group_preds": rng.randint(0, 2, n),
        "emotion_labels": rng.randint(0, 2, n * 8),
        "emotion_preds": rng.randint(0, 2, n * 8),
        "group_probs": rng.rand(n),
        "emotion_probs": rng.rand(n * 8),
    }


class TestComputeMultitaskTrainMetrics:

    def test_returns_dict_with_required_keys(self):
        d = _make_data()
        result = compute_multitask_train_metrics(
            d["subject_loss"], d["emotion_loss"], d["total_loss"],
            d["group_labels"], d["group_preds"],
            d["emotion_labels"], d["emotion_preds"],
        )
        assert "subject_loss" in result
        assert "emotion_loss" in result
        assert "total_loss" in result
        assert "subject_accuracy" in result
        assert "emotion_accuracy" in result

    def test_loss_values_passed_through(self):
        d = _make_data()
        result = compute_multitask_train_metrics(
            0.5, 0.6, 1.1,
            d["group_labels"], d["group_preds"],
            d["emotion_labels"], d["emotion_preds"],
        )
        assert result["subject_loss"] == 0.5
        assert result["emotion_loss"] == 0.6
        assert result["total_loss"] == 1.1


class TestComputeMultitaskValMetrics:

    def test_returns_all_metric_keys(self):
        d = _make_data()
        result = compute_multitask_val_metrics(
            d["subject_loss"], d["emotion_loss"], d["total_loss"],
            d["group_labels"], d["group_preds"], d["group_probs"],
            d["emotion_labels"], d["emotion_preds"], d["emotion_probs"],
        )
        expected_prefixes = ["subject_", "emotion_"]
        expected_metrics = [
            "accuracy", "auc", "f1", "precision", "recall",
            "specificity", "kappa", "mcc", "loss",
        ]
        for prefix in expected_prefixes:
            for metric in expected_metrics:
                assert f"{prefix}{metric}" in result, f"Missing key: {prefix}{metric}"
        assert "total_loss" in result

    def test_accuracy_between_0_and_1(self):
        d = _make_data()
        result = compute_multitask_val_metrics(
            d["subject_loss"], d["emotion_loss"], d["total_loss"],
            d["group_labels"], d["group_preds"], d["group_probs"],
            d["emotion_labels"], d["emotion_preds"], d["emotion_probs"],
        )
        assert 0 <= result["subject_accuracy"] <= 1
        assert 0 <= result["emotion_accuracy"] <= 1
