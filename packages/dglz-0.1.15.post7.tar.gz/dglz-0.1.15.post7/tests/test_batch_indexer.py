"""Tests for batch_indexer -- extract subsets from a resampled manifest CSV."""

from __future__ import annotations

import json
from pathlib import Path

import pandas as pd
import pytest

from eemoclas.tools.batch_indexer import create_batch_indexes


@pytest.fixture
def manifest_csv(tmp_path: Path) -> Path:
    """Create a small manifest CSV for testing."""
    rows = []
    for i in range(20):
        rows.append({
            "sample_id": f"sample_{i:04d}",
            "sample_path": f"samples/sample_{i:04d}.pt",
            "subject_id": f"sub_{i % 5}",
            "group_label": i % 2,
            "c_eff": 30,
            "length": 2500,
        })
    df = pd.DataFrame(rows)
    csv_path = tmp_path / "manifest.csv"
    df.to_csv(csv_path, index=False)
    return csv_path


class TestBasicSplit:
    """3 batches of [5,5,5] from 20 samples -> 3 batches + remainder(5)."""

    def test_creates_expected_files(self, manifest_csv: Path, tmp_path: Path):
        out = tmp_path / "out"
        result = create_batch_indexes(
            manifest_path=str(manifest_csv),
            output_dir=str(out),
            batch_sizes=[5, 5, 5],
            seed=42,
        )
        assert result["num_batches"] == 3
        assert result["remainder_size"] == 5
        assert result["total_samples"] == 20
        # 3 batch files + remainder + summary json
        assert (out / "batch_001.csv").exists()
        assert (out / "batch_002.csv").exists()
        assert (out / "batch_003.csv").exists()
        assert (out / "remainder.csv").exists()
        assert (out / "batch_summary.json").exists()

    def test_each_batch_has_correct_size(self, manifest_csv: Path, tmp_path: Path):
        out = tmp_path / "out"
        create_batch_indexes(
            manifest_path=str(manifest_csv),
            output_dir=str(out),
            batch_sizes=[5, 5, 5],
            seed=42,
        )
        for i in range(1, 4):
            df = pd.read_csv(out / f"batch_{i:03d}.csv")
            assert len(df) == 5
        rem_df = pd.read_csv(out / "remainder.csv")
        assert len(rem_df) == 5


class TestNoRemainder:
    """Batch sizes sum to total -> no remainder file."""

    def test_no_remainder_file(self, manifest_csv: Path, tmp_path: Path):
        out = tmp_path / "out"
        result = create_batch_indexes(
            manifest_path=str(manifest_csv),
            output_dir=str(out),
            batch_sizes=[10, 10],
            seed=42,
        )
        assert result["remainder_size"] == 0
        assert not (out / "remainder.csv").exists()
        assert "remainder.csv" not in result["output_files"]


class TestUnequalBatches:
    """Unequal batch sizes [3,7,2] -> 3 batches + remainder(8)."""

    def test_unequal_sizes(self, manifest_csv: Path, tmp_path: Path):
        out = tmp_path / "out"
        result = create_batch_indexes(
            manifest_path=str(manifest_csv),
            output_dir=str(out),
            batch_sizes=[3, 7, 2],
            seed=42,
        )
        assert result["num_batches"] == 3
        assert result["remainder_size"] == 8
        assert len(pd.read_csv(out / "batch_001.csv")) == 3
        assert len(pd.read_csv(out / "batch_002.csv")) == 7
        assert len(pd.read_csv(out / "batch_003.csv")) == 2
        assert len(pd.read_csv(out / "remainder.csv")) == 8


class TestNoOverlapBetweenBatches:
    """No sample appears twice across all output files."""

    def test_no_duplicate_samples(self, manifest_csv: Path, tmp_path: Path):
        out = tmp_path / "out"
        create_batch_indexes(
            manifest_path=str(manifest_csv),
            output_dir=str(out),
            batch_sizes=[5, 5, 5],
            seed=42,
        )
        all_ids: list[str] = []
        for name in ["batch_001.csv", "batch_002.csv", "batch_003.csv", "remainder.csv"]:
            df = pd.read_csv(out / name)
            all_ids.extend(df["sample_id"].tolist())
        # 20 unique samples, no duplicates
        assert len(all_ids) == 20
        assert len(set(all_ids)) == 20


class TestSeedReproducibility:
    """Same seed produces identical output."""

    def test_same_seed_same_result(self, manifest_csv: Path, tmp_path: Path):
        out1 = tmp_path / "out1"
        out2 = tmp_path / "out2"
        create_batch_indexes(
            manifest_path=str(manifest_csv),
            output_dir=str(out1),
            batch_sizes=[5, 5, 5],
            seed=123,
        )
        create_batch_indexes(
            manifest_path=str(manifest_csv),
            output_dir=str(out2),
            batch_sizes=[5, 5, 5],
            seed=123,
        )
        for name in ["batch_001.csv", "batch_002.csv", "batch_003.csv", "remainder.csv"]:
            df1 = pd.read_csv(out1 / name)
            df2 = pd.read_csv(out2 / name)
            pd.testing.assert_frame_equal(df1, df2)


class TestSumExceedsTotalRaises:
    """ValueError when batch sizes sum exceeds total samples."""

    def test_raises(self, manifest_csv: Path, tmp_path: Path):
        with pytest.raises(ValueError, match="exceeds total samples"):
            create_batch_indexes(
                manifest_path=str(manifest_csv),
                output_dir=str(tmp_path / "out"),
                batch_sizes=[15, 10],  # sum=25 > 20
                seed=42,
            )


class TestZeroBatchSizeRaises:
    """ValueError when a batch size is zero."""

    def test_raises(self, manifest_csv: Path, tmp_path: Path):
        with pytest.raises(ValueError, match="must be > 0"):
            create_batch_indexes(
                manifest_path=str(manifest_csv),
                output_dir=str(tmp_path / "out"),
                batch_sizes=[5, 0, 5],
                seed=42,
            )


class TestManifestColumnsPreserved:
    """Output CSV files have all original columns."""

    def test_columns_match(self, manifest_csv: Path, tmp_path: Path):
        out = tmp_path / "out"
        original_df = pd.read_csv(manifest_csv)
        original_cols = list(original_df.columns)

        create_batch_indexes(
            manifest_path=str(manifest_csv),
            output_dir=str(out),
            batch_sizes=[5, 5, 5],
            seed=42,
        )
        batch_df = pd.read_csv(out / "batch_001.csv")
        assert list(batch_df.columns) == original_cols


class TestCustomPrefix:
    """Custom prefix is used for filenames."""

    def test_prefix_applied(self, manifest_csv: Path, tmp_path: Path):
        out = tmp_path / "out"
        create_batch_indexes(
            manifest_path=str(manifest_csv),
            output_dir=str(out),
            batch_sizes=[5, 5],
            seed=42,
            prefix="mybatch",
        )
        assert (out / "mybatch_001.csv").exists()
        assert (out / "mybatch_002.csv").exists()


class TestBatchSummaryJson:
    """batch_summary.json has correct structure and values."""

    def test_summary_content(self, manifest_csv: Path, tmp_path: Path):
        out = tmp_path / "out"
        result = create_batch_indexes(
            manifest_path=str(manifest_csv),
            output_dir=str(out),
            batch_sizes=[5, 5, 5],
            seed=42,
            prefix="batch",
        )
        with open(out / "batch_summary.json") as f:
            summary = json.load(f)

        assert summary["total_samples"] == 20
        assert summary["num_batches"] == 3
        assert summary["batch_sizes"] == [5, 5, 5]
        assert summary["remainder_size"] == 5
        assert summary["seed"] == 42
        assert "batch_001.csv" in summary["output_files"]
        assert "batch_002.csv" in summary["output_files"]
        assert "batch_003.csv" in summary["output_files"]
        assert "remainder.csv" in summary["output_files"]
        assert summary["source_manifest"] == str(manifest_csv)
