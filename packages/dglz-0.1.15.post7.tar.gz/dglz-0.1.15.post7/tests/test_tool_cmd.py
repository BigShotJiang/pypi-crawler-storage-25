"""Tests for eemo tool data-to-batchs-index CLI command."""
from __future__ import annotations

import json
from pathlib import Path

import pandas as pd
import pytest
from typer.testing import CliRunner

from eemoclas.cli.tool_cmd import app


@pytest.fixture
def runner() -> CliRunner:
    return CliRunner()


@pytest.fixture
def manifest_csv(tmp_path: Path) -> Path:
    """Create a small manifest CSV for testing."""
    rows = []
    for i in range(20):
        rows.append({
            "sample_id": f"sample_{i:04d}",
            "sample_path": f"samples/sample_{i:04d}.pt",
            "subject_id": f"sub_{i % 5}",
            "group_label": i % 2,
        })
    csv_path = tmp_path / "manifest.csv"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    return csv_path


@pytest.fixture
def batch_config_json(tmp_path: Path) -> Path:
    """Create a batch config JSON file."""
    config = {"batch_sizes": [5, 5], "seed": 42}
    config_path = tmp_path / "batch_config.json"
    with open(config_path, "w") as f:
        json.dump(config, f)
    return config_path


class TestToolCmd:
    def test_batch_sizes_success(self, runner: CliRunner, manifest_csv: Path, tmp_path: Path):
        result = runner.invoke(app, [
            "-m", str(manifest_csv),
            "-o", str(tmp_path / "out"),
            "-b", "5,5",
            "-s", "42",
        ])
        assert result.exit_code == 0
        assert (tmp_path / "out" / "batch_001.csv").exists()
        assert (tmp_path / "out" / "batch_002.csv").exists()
        assert (tmp_path / "out" / "remainder.csv").exists()

    def test_batch_config_success(self, runner: CliRunner, manifest_csv: Path, tmp_path: Path, batch_config_json: Path):
        result = runner.invoke(app, [
            "-m", str(manifest_csv),
            "-o", str(tmp_path / "out"),
            "-c", str(batch_config_json),
        ])
        assert result.exit_code == 0
        assert (tmp_path / "out" / "batch_001.csv").exists()

    def test_neither_sizes_nor_config(self, runner: CliRunner, manifest_csv: Path, tmp_path: Path):
        result = runner.invoke(app, [
            "-m", str(manifest_csv),
            "-o", str(tmp_path / "out"),
        ])
        assert result.exit_code == 1

    def test_both_sizes_and_config(self, runner: CliRunner, manifest_csv: Path, tmp_path: Path, batch_config_json: Path):
        result = runner.invoke(app, [
            "-m", str(manifest_csv),
            "-o", str(tmp_path / "out"),
            "-b", "5,5",
            "-c", str(batch_config_json),
        ])
        assert result.exit_code == 1

    def test_missing_manifest(self, runner: CliRunner, tmp_path: Path):
        result = runner.invoke(app, [
            "-m", str(tmp_path / "nonexistent.csv"),
            "-o", str(tmp_path / "out"),
            "-b", "5",
        ])
        assert result.exit_code == 1

    def test_verbose_output(self, runner: CliRunner, manifest_csv: Path, tmp_path: Path):
        result = runner.invoke(app, [
            "-m", str(manifest_csv),
            "-o", str(tmp_path / "out"),
            "-b", "5,5",
            "-v",
        ])
        assert result.exit_code == 0
        # Verbose mode should include summary info
        assert "总样本" in result.output or "batch" in result.output.lower()
