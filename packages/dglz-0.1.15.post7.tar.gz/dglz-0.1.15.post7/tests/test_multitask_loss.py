"""Test MultiTaskLoss."""

import pytest
import torch

from eemoclas.training.multitask_loss import MultiTaskLoss


def _make_logits(batch_size=4):
    return torch.randn(batch_size, 9)


def _make_targets(batch_size=4):
    return {
        "group_label": torch.randint(0, 2, (batch_size,)),
        "trial_emotion_labels": torch.randint(0, 2, (batch_size, 8)),
    }


class TestMultiTaskLossWeightedSum:

    def test_output_keys(self):
        config = {"type": "weighted_sum", "subject_state_weight": 1.0, "emotion_weight": 1.0}
        loss_fn = MultiTaskLoss(config)
        logits = _make_logits()
        targets = _make_targets()
        result = loss_fn(logits, targets)
        assert "loss" in result
        assert "subject_loss" in result
        assert "emotion_loss" in result

    def test_loss_is_scalar(self):
        config = {"type": "weighted_sum", "subject_state_weight": 1.0, "emotion_weight": 1.0}
        loss_fn = MultiTaskLoss(config)
        logits = _make_logits()
        targets = _make_targets()
        result = loss_fn(logits, targets)
        assert result["loss"].dim() == 0

    def test_gradient_flows(self):
        config = {"type": "weighted_sum", "subject_state_weight": 1.0, "emotion_weight": 1.0}
        loss_fn = MultiTaskLoss(config)
        logits = _make_logits().requires_grad_(True)
        targets = _make_targets()
        result = loss_fn(logits, targets)
        result["loss"].backward()
        assert logits.grad is not None

    def test_weight_affects_loss(self):
        config_a = {"type": "weighted_sum", "subject_state_weight": 10.0, "emotion_weight": 0.1}
        config_b = {"type": "weighted_sum", "subject_state_weight": 0.1, "emotion_weight": 10.0}
        torch.manual_seed(42)
        logits = torch.randn(4, 9)
        targets = _make_targets()
        loss_a = MultiTaskLoss(config_a)(logits.clone(), targets)["loss"].item()
        loss_b = MultiTaskLoss(config_b)(logits.clone(), targets)["loss"].item()
        assert loss_a != pytest.approx(loss_b, abs=1e-4)


class TestMultiTaskLossUncertainty:

    def test_uncertainty_has_parameters(self):
        config = {"type": "uncertainty"}
        loss_fn = MultiTaskLoss(config)
        assert hasattr(loss_fn, "log_sigma_subj")
        assert hasattr(loss_fn, "log_sigma_emo")
        assert isinstance(loss_fn.log_sigma_subj, torch.nn.Parameter)

    def test_uncertainty_loss_computes(self):
        config = {"type": "uncertainty"}
        loss_fn = MultiTaskLoss(config)
        logits = _make_logits()
        targets = _make_targets()
        result = loss_fn(logits, targets)
        assert result["loss"].dim() == 0


class TestMultiTaskLossPerTrial:

    def test_per_trial_output_keys(self):
        config = {"type": "per_trial", "subject_state_weight": 1.0, "emotion_weight": 1.0}
        loss_fn = MultiTaskLoss(config)
        logits = _make_logits()
        targets = _make_targets()
        result = loss_fn(logits, targets)
        assert "loss" in result
        assert "subject_loss" in result
        assert "emotion_loss" in result


class TestMultiTaskLossInvalidType:

    def test_invalid_type_raises(self):
        config = {"type": "invalid_type"}
        with pytest.raises(ValueError, match="Unknown multitask loss type"):
            MultiTaskLoss(config)
