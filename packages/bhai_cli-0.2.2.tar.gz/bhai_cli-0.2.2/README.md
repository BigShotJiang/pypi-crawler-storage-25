# 🇮🇳 BHAI-CLI

**The Dual-Brain AI Coding Agent — 22 Indian Languages. One CLI.**

> भाई · ভাই · ભાઈ · ਭਾਈ · భాయ్ · ಭಾಯ್ · भाऊ · ভাই

BHAI is a lean, zero-state resilient CLI tool that acts as your 10x Senior SDE from India. It uses a **Dual-Brain Architecture** — a VibeLLM for persona and intent parsing, and a CoderAgent for tool-calling execution — all powered by [litellm](https://github.com/BerriAI/litellm) for universal LLM provider support and [Sarvam AI](https://sarvam.ai) for 22 Indian language understanding.

> *"You are BHAI, a 10x Senior SDE from India. Sab bhasha samajhte ho. You roast O(N²) loops and unoptimized Dockerfiles."*

---

## ✨ Features

- **🧠 Dual-Brain Architecture**: VibeLLM (persona + intent) → CoderAgent (tool execution) → VibeLLM (swagger summary)
- **🇮🇳 22 Indian Languages**: Speak in Hindi, Punjabi, Bengali, Tamil, Telugu, Gujarati, Marathi, Kannada, Malayalam, and more — powered by Sarvam AI
- **🌍 Universal LLM Support**: Every provider on Earth — OpenAI, Anthropic, Groq, Google Gemini, Sarvam, Mistral, Cerebras, Ollama, Bedrock, and more via litellm
- **🎙️ Indic Voice Interface**: Sarvam Saaras v3 (STT) translates any Indian language to English, Bulbul v3 (TTS) reads responses back
- **🔧 MCP-Style Tools**: `execute_bash`, `web_search`, `codebase_context` — with a hard `[Y/n]` guardrail on every command
- **⚡ Zero-State Resilience**: Boots in <300ms, persistent YAML config, hot-swappable model overrides
- **📦 PyPI-Ready**: Clean `src/` layout, Poetry-managed, lean dependency footprint

---

## 🚀 Installation

```bash
pip install bhai-cli
```

**With voice support (optional):**
```bash
pip install "bhai-cli[audio]"
# Also needs: sudo apt install libportaudio2  (Linux)
```

---

## ⚙️ Setup

```bash
bhai-code setup
```

The interactive wizard will configure:
1. **VibeLLM** — Your persona brain (e.g., `sarvam/sarvam-105b`, `groq/llama-3.3-70b-versatile`)
2. **CoderAgent** — Your tool-calling brain (e.g., `openai/gpt-4o`, `anthropic/claude-sonnet-4-20250514`)
3. **Sarvam AI** — Voice interface API key (optional)

### Model Format

Uses [litellm's model naming](https://docs.litellm.ai/docs/providers):

| Provider | Format | Example |
|----------|--------|---------|
| OpenAI | `openai/model` | `openai/gpt-4o` |
| Anthropic | `anthropic/model` | `anthropic/claude-sonnet-4-20250514` |
| Google | `gemini/model` | `gemini/gemini-2.5-flash` |
| Groq | `groq/model` | `groq/llama-3.3-70b-versatile` |
| Sarvam | `sarvam/model` | `sarvam/sarvam-105b` |
| Mistral | `mistral/model` | `mistral/mistral-large-latest` |
| Cerebras | `cerebras/model` | `cerebras/llama-3.3-70b` |
| Ollama | `ollama/model` | `ollama/llama3` |

---

## 💬 Usage

### Text Mode

```bash
# Single prompt
bhai-code text "find all TODO comments in this project"

# Interactive chat
bhai-code text "what does this codebase do?" --interactive

# Override models on the fly
bhai-code text "optimize this Dockerfile" --vibe-model groq/llama-3.3-70b-versatile --coder-model openai/gpt-4o
```

### Voice Mode

```bash
# Live microphone
bhai-code listen

# From audio file
bhai-code listen --file recording.wav
```

### View Config

```bash
bhai-code config
```

---

## 🏗️ Architecture

```
User Input (Any of 22 Indian Languages / English)
         │
         ▼
┌─────────────────────┐
│   VibeLLM (Brain A)  │  ← Persona + Intent Parsing
│   Sarvam-105B / any  │
└──────────┬──────────┘
           │ {"task": "clean English intent"}
           ▼
┌─────────────────────┐
│  CoderAgent (Brain B)│  ← Tool-Calling Execution
│  Any litellm model   │
│                      │
│  Tools:              │
│  • execute_bash      │  ← [Y/n] guardrail
│  • web_search        │  ← DuckDuckGo
│  • codebase_context  │  ← AST signatures
└──────────┬──────────┘
           │ Results
           ▼
┌─────────────────────┐
│   VibeLLM (Brain A)  │  ← Swagger Summary
└─────────────────────┘
```

---

## 🔧 Tools

| Tool | Description |
|------|-------------|
| `execute_bash` | Run shell commands with mandatory `[Y/n]` confirmation, timeout handling |
| `web_search` | DuckDuckGo search for real-time debugging and docs lookup |
| `codebase_context` | Smart directory scanner with AST-based signature extraction (anti-context-rot) |

---

## 📁 Project Structure

```
bhai-cli/
├── src/bhai_cli/
│   ├── __init__.py          # Package metadata
│   ├── cli.py               # Typer CLI (setup, text, listen, config)
│   ├── config_manager.py    # Pydantic YAML/env config engine
│   ├── orchestrator.py      # Dual-Brain routing logic
│   ├── audio_engine.py      # Sarvam STT/TTS + mic recording
│   └── tools/
│       ├── __init__.py      # Tool registry + JSON schemas
│       ├── bash.py          # execute_bash with guardrails
│       ├── search.py        # web_search via DuckDuckGo
│       └── codebase.py      # codebase_context with AST
├── tests/
├── pyproject.toml           # Poetry config (lean deps)
├── README.md
└── LICENSE                  # Apache-2.0
```

---

## 🔑 Environment Variables

| Variable | Description |
|----------|-------------|
| `SARVAM_API_KEY` | Sarvam AI API key |
| `VIBE_API_KEY` | VibeLLM provider API key |
| `CODER_API_KEY` | CoderAgent provider API key |
| `GROQ_API_KEY` | Groq API key (auto-detected by litellm) |
| `OPENAI_API_KEY` | OpenAI API key (auto-detected by litellm) |
| `ANTHROPIC_API_KEY` | Anthropic API key (auto-detected by litellm) |
| `GEMINI_API_KEY` | Google Gemini API key (auto-detected by litellm) |

You can also use a `.env` file in your working directory.

---

## 🗺️ Roadmap (v2)

- [ ] MCP Server connectivity for external tool integration
- [ ] Streaming responses
- [ ] Multi-turn CoderAgent memory
- [ ] Plugin system for custom tools

---

## 📄 License

Apache-2.0 — see [LICENSE](LICENSE).

Built with ❤️ from India by [Madhav Kapila](https://github.com/madhavkapila).
