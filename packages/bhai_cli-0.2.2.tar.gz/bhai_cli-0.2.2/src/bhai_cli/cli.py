"""
BHAI-CLI — Typer CLI Application.

Commands:
  bhai-code setup   — Interactive configuration wizard
  bhai-code text    — Send a text prompt to BHAI
  bhai-code listen  — Voice input via Sarvam STT → BHAI pipeline
"""

from __future__ import annotations

import asyncio
from typing import Optional
import sys

import typer
import pyfiglet
from rich.console import Console
from rich.panel import Panel
from rich.prompt import Prompt, Confirm
from rich.table import Table
from rich.text import Text

__version__ = "0.2.0"
from bhai_cli.config_manager import (
    load_config,
    save_config,
    CONFIG_FILE,
    SECRETS_FILE,
    CONFIG_DIR,
    _mask_key,
)

console = Console()

# ---------------------------------------------------------------------------
# CLI Setup
# ---------------------------------------------------------------------------

# "BHAI" in 6 Indian scripts
BHAI_LANGS = [
    ("भाई", "Hindi"),
    ("ভাই", "Bengali"),
    ("ભાઈ", "Gujarati"),
    ("ਭਾਈ", "Punjabi"),
    ("భాయ్", "Telugu"),
    ("ಭಾಯ್", "Kannada"),
]


def print_banner() -> None:
    """Print the BHAI-CLI ASCII banner with multilingual flair."""
    ascii_banner = pyfiglet.figlet_format("BHAI - CLI", font="slant")
    banner_text = Text(ascii_banner, style="bold bright_cyan")
    console.print(banner_text)

    # Show "BHAI" in multiple Indian scripts
    lang_line = " · ".join(f"[bold]{word}[/][dim]({lang})[/]" for word, lang in BHAI_LANGS)
    console.print(f"  {lang_line}\n")

    console.print(
        "[bold yellow]🇮🇳 The Dual-Brain Agentic Coding CLI — 22 Indian Languages.[/]\n"
        "[dim]Powered by litellm & Sarvam AI | v" + __version__ + "[/]\n"
    )

app = typer.Typer(
    name="bhai-code",
    help="BHAI — Your 10x Senior SDE from India. 22 Languages. One CLI.",
    add_completion=False,
    rich_markup_mode="rich",
    no_args_is_help=False,  # We handle no args manually for the interactive menu
)

def _version_callback(value: bool) -> None:
    if value:
        print_banner()
        raise typer.Exit()

@app.callback(invoke_without_command=True)
def main(
    ctx: typer.Context,
    version: bool = typer.Option(
        False, "--version", "-v",
        help="Show version and exit.",
        callback=_version_callback,
        is_eager=True,
    ),
) -> None:
    """[bold cyan]BHAI-CLI[/] — 10x Senior SDE Agent from India. 22 Languages."""
    if ctx.invoked_subcommand is None:
        print_banner()
        interactive_menu()

def interactive_menu():
    """Interactive main menu when run without subcommands."""
    while True:
        console.print("\n[bold cyan]Main Menu[/]")
        console.print("  [1] 💬 Chat (Agentic text mode)")
        console.print("  [2] 🎙️  Listen (Voice mode)")
        console.print("  [3] ⚙️  Setup Wizard")
        console.print("  [4] 📋 View Config")
        console.print("  [5] ❌ Exit\n")
        
        choice = Prompt.ask("[bold green]Choose an option[/]", choices=["1", "2", "3", "4", "5"])
        
        if choice == "1":
            text(prompt="", vibe_model=None, coder_model=None, interactive=False)
        elif choice == "2":
            listen(vibe_model=None, coder_model=None, file=None)
        elif choice == "3":
            setup()
        elif choice == "4":
            config()
        elif choice == "5":
            console.print("\n[bold yellow]BHAI:[/] Accha bhai, phir milenge! 🤙")
            sys.exit(0)


# ---------------------------------------------------------------------------
# bhai-code setup
# ---------------------------------------------------------------------------

@app.command()
def setup() -> None:
    """[bold yellow]⚙️  setup[/] — Interactive wizard for VibeLLM, CoderAgent, and Sarvam AI."""
    print_banner()
    
    console.print(
        Panel(
            "[bold white]Let's get your agentic engine running, boss.[/]\n"
            "[dim]We need to configure your Persona (Brain A) and your Execution Engine (Brain B).[/]",
            title="[bold yellow]Setup Wizard[/]",
            border_style="yellow",
            padding=(1, 2),
        )
    )

    cfg = load_config()

    console.print("\n[bold cyan]━━━ Brain A: VibeLLM (Persona & Intent) ━━━[/]")
    console.print(
        "[dim]Handles the BHAI persona and parses your intent.\n"
        "Format: provider/model-name (e.g., sarvam/sarvam-105b, groq/llama-3.3-70b-versatile, ollama/llama3)[/]\n"
    )
    cfg.vibe.model = Prompt.ask("VibeLLM model", default=cfg.vibe.model)
    
    # Hide existing key in prompt default
    vibe_key_default = "(configured)" if cfg.vibe.api_key else ""
    vibe_key_input = Prompt.ask("VibeLLM API key", default=vibe_key_default, password=True)
    if vibe_key_input != "(configured)":
        cfg.vibe.api_key = vibe_key_input
        
    cfg.vibe.api_base = Prompt.ask("VibeLLM API base URL [dim](optional)[/]", default=cfg.vibe.api_base or "")
    if cfg.vibe.model.startswith("ollama/"):
        cfg.vibe.ollama_port = int(Prompt.ask("Ollama port for VibeLLM", default=str(cfg.vibe.ollama_port)))

    console.print("\n[bold cyan]━━━ Brain B: CoderAgent (Tool Execution) ━━━[/]")
    console.print(
        "[dim]Executes coding tasks using tools autonomously.\n"
        "Recommended: groq/llama-3.3-70b-versatile, openai/gpt-4o, anthropic/claude-sonnet-4-20250514[/]\n"
    )
    cfg.coder.model = Prompt.ask("CoderAgent model", default=cfg.coder.model)
    
    coder_key_default = "(configured)" if cfg.coder.api_key else ""
    coder_key_input = Prompt.ask("CoderAgent API key", default=coder_key_default, password=True)
    if coder_key_input != "(configured)":
        cfg.coder.api_key = coder_key_input
        
    cfg.coder.api_base = Prompt.ask("CoderAgent API base URL [dim](optional)[/]", default=cfg.coder.api_base or "")
    if cfg.coder.model.startswith("ollama/"):
        cfg.coder.ollama_port = int(Prompt.ask("Ollama port for CoderAgent", default=str(cfg.coder.ollama_port)))


    console.print("\n[bold cyan]━━━ Sarvam AI (Voice Interface) ━━━[/]")
    console.print("[dim]Optional: Enables voice input (STT) and output (TTS).[/]\n")
    
    sarvam_key_default = "(configured)" if cfg.sarvam.api_key else ""
    sarvam_key_input = Prompt.ask("Sarvam API key [dim](leave empty to skip)[/]", default=sarvam_key_default, password=True)
    if sarvam_key_input != "(configured)":
        cfg.sarvam.api_key = sarvam_key_input

    save_config(cfg)

    console.print()
    console.print(
        Panel(
            f"[bold green]✅ All set, boss! Config saved to:[/] {CONFIG_DIR}\n"
            f"[dim](API keys saved securely in secrets.yaml)[/]\n\n"
            f"🧠 [bold]VibeLLM:[/]    {cfg.vibe.model}\n"
            f"🛠️  [bold]CoderAgent:[/] {cfg.coder.model}\n"
            f"🎙️  [bold]Sarvam:[/]     {'Active ✓' if cfg.sarvam.api_key else 'Skipped (Text-only)'}",
            title="[bold green]Setup Complete[/]",
            border_style="green",
            padding=(1, 2),
        )
    )

# ---------------------------------------------------------------------------
# bhai-code text
# ---------------------------------------------------------------------------

@app.command()
def text(
    prompt: str = typer.Argument("", help="Your message to BHAI. If empty, starts interactive mode."),
    vibe_model: Optional[str] = typer.Option(None, "--vibe-model", "-vm", help="Override VibeLLM model."),
    coder_model: Optional[str] = typer.Option(None, "--coder-model", "-cm", help="Override CoderAgent model."),
    interactive: bool = typer.Option(False, "--interactive", "-i", help="Enter interactive chat mode (always active if prompt is empty)."),
) -> None:
    """[bold magenta]💬 text[/] — Send a text prompt to BHAI or start interactive session."""
    if not prompt:
        print_banner()
        console.print("[bold cyan]Welcome to BHAI Interactive Mode.[/]\n[dim]Type 'exit', 'quit', or 'nikal' to leave.[/]\n")
        interactive = True

    from bhai_cli.orchestrator import BhaiOrchestrator

    cfg = load_config(vibe_model_override=vibe_model, coder_model_override=coder_model)
    orchestrator = BhaiOrchestrator(cfg)

    if prompt:
        asyncio.run(orchestrator.process(prompt))

    if interactive:
        while True:
            try:
                user_input = Prompt.ask("[bold green]You[/]")
                if not user_input.strip():
                    continue
                if user_input.strip().lower() in ("exit", "quit", "bye", "chal hatja", "nikal"):
                    console.print("\n[bold yellow]BHAI:[/] Accha bhai, phir milenge! 🤙")
                    break
                asyncio.run(orchestrator.process(user_input))
            except (KeyboardInterrupt, EOFError):
                console.print("\n[bold yellow]BHAI:[/] Theek hai boss, baad mein baat karte hain! 👋")
                break

# ---------------------------------------------------------------------------
# bhai-code listen
# ---------------------------------------------------------------------------

@app.command()
def listen(
    vibe_model: Optional[str] = typer.Option(None, "--vibe-model", "-vm", help="Override VibeLLM model."),
    coder_model: Optional[str] = typer.Option(None, "--coder-model", "-cm", help="Override CoderAgent model."),
    file: Optional[str] = typer.Option(None, "--file", "-f", help="Path to an audio file instead of live mic."),
) -> None:
    """[bold red]🎙️  listen[/] — Voice input — speak to BHAI in any Indian language."""
    print_banner()
    from bhai_cli.orchestrator import BhaiOrchestrator
    from bhai_cli.audio_engine import (
        AudioRecorder, load_audio_file, speech_to_text, text_to_speech, play_audio,
    )

    cfg = load_config(vibe_model_override=vibe_model, coder_model_override=coder_model)

    if not cfg.sarvam.api_key:
        console.print(
            Panel(
                "[bold red]⚠ Sarvam API key not configured.[/]\n"
                "Run [cyan]bhai-code setup[/] to add your Sarvam key,\n"
                "or use [cyan]bhai-code text[/] for text-only mode.",
                title="[bold red]Error[/]", border_style="red"
            )
        )
        raise typer.Exit(1)

    orchestrator = BhaiOrchestrator(cfg)
    audio_bytes = None
    audio_file = file or cfg.audio_fallback_file

    if audio_file:
        console.print(f"[dim]Loading audio from: {audio_file}[/]")
        audio_bytes = load_audio_file(audio_file)
        if audio_bytes is None:
            raise typer.Exit(1)
    else:
        recorder = AudioRecorder()
        console.print(
            Panel(
                "[bold white]Press ENTER to start recording, then ENTER again to stop.[/]",
                title="[bold magenta]🎙️  Live Recording[/]",
                border_style="magenta", padding=(1, 2),
            )
        )
        input() 

        if not recorder.start():
            console.print("[bold red]Failed to start recording. Falling back to text mode.[/]")
            raise typer.Exit(1)

        console.print("[bold red blink]🔴 Recording... Press ENTER to stop.[/]")
        input()

        audio_bytes = recorder.stop()
        if audio_bytes is None:
            console.print("[bold red]No audio captured.[/]")
            raise typer.Exit(1)
        console.print("[bold green]✅ Audio captured successfully.[/]")

    with console.status("[bold cyan]Transcribing with Sarvam Saaras v3... 🎧[/]"):
        success, transcript = asyncio.run(
            speech_to_text(audio_bytes, api_key=cfg.sarvam.api_key, model=cfg.sarvam.stt_model, mode=cfg.sarvam.stt_mode)
        )

    if not success:
        console.print(f"[bold red]STT failed:[/] {transcript}")
        console.print("[dim]Falling back to text mode. Use bhai-code text instead.[/]")
        raise typer.Exit(1)

    console.print(f"[bold green]📝 You said:[/] {transcript}\n")
    result = asyncio.run(orchestrator.process(transcript))

    async def _speak(text: str) -> None:
        ok, audio = await text_to_speech(
            text, api_key=cfg.sarvam.api_key, model=cfg.sarvam.tts_model,
            speaker=cfg.sarvam.tts_speaker, language=cfg.sarvam.tts_language,
        )
        if ok and audio:
            with console.status("[bold magenta]Speaking... 🔊[/]"):
                await play_audio(audio)

    try:
        asyncio.run(_speak(result[:2500]))
    except Exception:
        pass

# ---------------------------------------------------------------------------
# bhai-code config
# ---------------------------------------------------------------------------

@app.command()
def config() -> None:
    """[bold cyan]📋 config[/] — Show current configuration."""
    print_banner()
    cfg = load_config()

    table = Table(title="BHAI Configuration Engine", show_header=True, header_style="bold cyan", border_style="dim", expand=True)
    table.add_column("Key", style="bold white")
    table.add_column("Value", style="cyan")

    table.add_row("Config Directory", str(CONFIG_DIR))
    table.add_section()
    table.add_row("[yellow]VibeLLM Model[/]", cfg.vibe.model)
    table.add_row("VibeLLM API Key", _mask_key(cfg.vibe.api_key))
    table.add_row("VibeLLM API Base", cfg.vibe.api_base or "[dim](default)[/]")
    if cfg.vibe.model.startswith("ollama/"):
        table.add_row("VibeLLM Ollama Port", str(cfg.vibe.ollama_port))
    table.add_section()
    table.add_row("[yellow]CoderAgent Model[/]", cfg.coder.model)
    table.add_row("CoderAgent API Key", _mask_key(cfg.coder.api_key))
    table.add_row("CoderAgent API Base", cfg.coder.api_base or "[dim](default)[/]")
    if cfg.coder.model.startswith("ollama/"):
        table.add_row("CoderAgent Ollama Port", str(cfg.coder.ollama_port))
    table.add_section()
    table.add_row("[yellow]Sarvam API Key[/]", _mask_key(cfg.sarvam.api_key))
    table.add_row("STT Model", cfg.sarvam.stt_model)
    table.add_row("TTS Model", cfg.sarvam.tts_model)
    table.add_section()
    table.add_row("Command Timeout", f"{cfg.command_timeout}s")

    console.print(table)
    console.print()

if __name__ == "__main__":
    app()
