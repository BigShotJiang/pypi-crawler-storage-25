"""
Orchestrator — The Dual-Brain Agentic Engine for BHAI-CLI.

Brain A (VibeLLM): Persona + intent parsing + planning + final review.
Brain B (CoderAgent): Tool-use execution via litellm.

Agentic Loop (Manager-Worker):
  1. VibeLLM parses intent → creates a plan
  2. CoderAgent executes the plan using tools autonomously
  3. VibeLLM reviews results → decides: done, or iterate with more instructions
  4. Loop until VibeLLM says DONE or max iterations reached
"""

from __future__ import annotations

import asyncio
import json
from typing import Optional

import litellm
from rich.console import Console
from rich.panel import Panel
from rich.markdown import Markdown

from bhai_cli.config_manager import BhaiConfig
from bhai_cli.tools import TOOL_SCHEMAS, dispatch_tool

console = Console()

# ---------------------------------------------------------------------------
# System Prompts
# ---------------------------------------------------------------------------

VIBE_SYSTEM_PROMPT = (
    "You are BHAI, a 10x Senior SDE from India. You understand all 22 official Indian "
    "languages. You have swagger and a religious devotion to performance. You roast O(N²) "
    "loops and unoptimized Dockerfiles. You speak with authority in Hindi/Hinglish, "
    "with occasional Punjabi and regional Indian flavor.\n\n"
    "Your job:\n"
    "1. Parse the user's intent (any Indian language, Hinglish, or English) into a clear "
    "English task description.\n"
    "2. IMPORTANT: You control a CoderAgent that has tools to read/edit files, list directories, and run bash commands! "
    "If the user asks to explain a file, run code, or do ANY system task, DO NOT ask them to upload or paste it. "
    "Instead, output a JSON block to delegate it: {\"task\": \"Read HelloWorld.py and explain it, then run it with a=4 b=10\"}.\n"
    "3. If strictly chatting with no system/code actions needed, respond conversationally with swagger.\n"
    "4. After CoderAgent results, review them and decide:\n"
    '   - If the task is COMPLETE, say "BHAI_DONE" somewhere in your response.\n'
    '   - If MORE WORK is needed, output another {"task": "next step description"}.\n\n'
    "Rules: NEVER execute anything yourself. Be concise. Use Hindi/Hinglish naturally, "
    "with occasional regional phrases. You are proudly Indian — sab bhasha samajhte ho."
)

CODER_SYSTEM_PROMPT = (
    "You are the CoderAgent, an autonomous agentic coding engine.\n"
    "You receive task descriptions and execute them using tools.\n\n"
    "## Core Principles (inspired by top agentic tools):\n"
    "1. THINK before acting. Plan your approach.\n"
    "2. ALWAYS read files before editing them — never guess at content.\n"
    "3. Use tools autonomously — chain them as needed.\n"
    "4. Use list_directory and codebase_context to understand structure first.\n"
    "5. Use read_file to see exact file contents before edit_file.\n"
    "6. Use execute_bash for running tests, git, docker, and system commands.\n"
    "7. Verify your changes work by running relevant commands.\n"
    "8. Report results factually — what you did, what worked, what failed.\n\n"
    "## Tools Available:\n"
    "- list_directory: Explore project structure\n"
    "- codebase_context: Get function/class signatures (AST-based)\n"
    "- read_file: Read file contents (ALWAYS do this before editing)\n"
    "- write_file: Create new files\n"
    "- edit_file: Search-and-replace in existing files\n"
    "- execute_bash: Run shell commands (user confirms each one)\n"
    "- web_search: Search the internet for docs/solutions\n\n"
    "Rules:\n"
    "- NEVER fabricate file contents or command outputs.\n"
    "- Be precise with edit_file — the old_text must match EXACTLY.\n"
    "- For bash: use proper flags, be specific.\n"
    "- Chain tool calls to complete complex tasks end-to-end."
)


class BhaiOrchestrator:
    """Dual-brain agentic orchestrator for BHAI-CLI."""

    def __init__(self, config: BhaiConfig):
        self.config = config
        self.conversation_history: list[dict] = []
        self._setup_litellm()

    def _setup_litellm(self) -> None:
        import os
        if self.config.vibe.api_key:
            self._set_provider_key(self.config.vibe.model, self.config.vibe.api_key)
        if self.config.coder.api_key:
            self._set_provider_key(self.config.coder.model, self.config.coder.api_key)
        if self.config.sarvam.api_key:
            os.environ.setdefault("SARVAM_API_KEY", self.config.sarvam.api_key)
        litellm.suppress_debug_info = True

    @staticmethod
    def _set_provider_key(model: str, api_key: str) -> None:
        import os
        prefix = model.split("/")[0].upper() if "/" in model else ""
        env_map = {
            "GROQ": "GROQ_API_KEY",
            "ANTHROPIC": "ANTHROPIC_API_KEY",
            "OPENAI": "OPENAI_API_KEY",
            "SARVAM": "SARVAM_API_KEY",
            "GEMINI": "GEMINI_API_KEY",
            "MISTRAL": "MISTRAL_API_KEY",
            "CEREBRAS": "CEREBRAS_API_KEY",
            "DEEPSEEK": "DEEPSEEK_API_KEY",
            "XAI": "XAI_API_KEY",
            "QWEN": "DASHSCOPE_API_KEY",
            "AI_STUDIO": "AISTUDIO_API_KEY",
            "OLLAMA": "",
            "OLLAMA_CHAT": "",
        }
        env_var = env_map.get(prefix, "")
        if env_var:
            os.environ.setdefault(env_var, api_key)

    # ── VibeLLM (Brain A) ──

    async def vibe_parse(self, user_input: str) -> tuple[Optional[str], str]:
        """VibeLLM: extract intent or conversational response."""
        messages = [
            {"role": "system", "content": VIBE_SYSTEM_PROMPT},
            *self.conversation_history,
            {"role": "user", "content": user_input},
        ]
        kwargs = {
            "model": self.config.vibe.model,
            "messages": messages,
            "temperature": self.config.vibe.temperature,
            "max_tokens": self.config.vibe.max_tokens,
        }
        if self.config.vibe.api_base:
            kwargs["api_base"] = self.config.vibe.api_base

        try:
            response = await litellm.acompletion(**kwargs)
            content = response.choices[0].message.content or ""
            self.conversation_history.append({"role": "user", "content": user_input})
            self.conversation_history.append({"role": "assistant", "content": content})
            if len(self.conversation_history) > 20:
                self.conversation_history = self.conversation_history[-16:]
            task = self._extract_task(content)
            return task, content
        except Exception as e:
            error_msg = f"VibeLLM error ({type(e).__name__}): {e}"
            console.print(f"[bold red]⚠ {error_msg}[/]")
            return None, error_msg

    @staticmethod
    def _extract_task(vibe_response: str) -> Optional[str]:
        """Extract {"task": "..."} from VibeLLM's response."""
        try:
            start = vibe_response.find('{"task"')
            if start == -1:
                start = vibe_response.find("```json")
                if start != -1:
                    start = vibe_response.find("{", start)
                    end = vibe_response.find("```", start)
                    if end != -1:
                        return json.loads(vibe_response[start:end].strip()).get("task")
                return None
            depth = 0
            for i in range(start, len(vibe_response)):
                if vibe_response[i] == "{":
                    depth += 1
                elif vibe_response[i] == "}":
                    depth -= 1
                    if depth == 0:
                        return json.loads(vibe_response[start:i+1]).get("task")
            return None
        except (json.JSONDecodeError, KeyError, IndexError):
            return None

    # ── CoderAgent (Brain B) ──

    async def coder_execute(self, task: str) -> str:
        """CoderAgent: execute task using autonomous tool-calling loop."""
        messages = [
            {"role": "system", "content": CODER_SYSTEM_PROMPT},
            {"role": "user", "content": task},
        ]
        max_iterations = 25
        all_results: list[str] = []

        for iteration in range(max_iterations):
            kwargs = {
                "model": self.config.coder.model,
                "messages": messages,
                "tools": TOOL_SCHEMAS,
                "temperature": self.config.coder.temperature,
                "max_tokens": self.config.coder.max_tokens,
            }
            if self.config.coder.api_base:
                kwargs["api_base"] = self.config.coder.api_base

            try:
                response = await litellm.acompletion(**kwargs)
                message = response.choices[0].message

                if not message.tool_calls:
                    final = message.content or ""
                    return final if final else "\n\n".join(all_results)

                messages.append(message.model_dump())

                for tool_call in message.tool_calls:
                    func_name = tool_call.function.name
                    try:
                        func_args = json.loads(tool_call.function.arguments)
                    except json.JSONDecodeError:
                        func_args = {}

                    # Show tool call with iteration counter
                    console.print(
                        f"[dim][{iteration+1}/{max_iterations}][/] "
                        f"[bold magenta]🔧 {func_name}[/]("
                        f"{', '.join(f'{k}={repr(v)[:60]}' for k, v in func_args.items())})"
                    )

                    if func_name == "execute_bash":
                        func_args.setdefault("timeout", self.config.command_timeout)

                    result = await dispatch_tool(func_name, func_args)
                    all_results.append(f"[{func_name}] {result[:500]}")
                    messages.append({
                        "role": "tool",
                        "tool_call_id": tool_call.id,
                        "content": result,
                    })

            except Exception as e:
                error = f"CoderAgent error ({type(e).__name__}): {e}"
                console.print(f"[bold red]⚠ {error}[/]")
                return error

        return "Max iterations reached.\n" + "\n".join(all_results)

    # ── Agentic Pipeline ──

    async def process(self, user_input: str) -> str:
        """
        Full agentic dual-brain pipeline.

        Manager-Worker loop:
          1. VibeLLM parses intent → creates task
          2. CoderAgent executes task
          3. VibeLLM reviews results → either DONE or creates next task
          4. Loop until BHAI_DONE or max agentic rounds
        """
        console.print(Panel(
            f"[bold white]{user_input}[/]",
            title="[bold green]📥 Input[/]", border_style="green", padding=(0, 2),
        ))

        # ── Step 1: VibeLLM initial parse ──
        with console.status("[bold cyan]BHAI is thinking... 🧠[/]"):
            task, vibe_response = await self.vibe_parse(user_input)

        # If VibeLLM says it's just a conversation (no task)
        if task is None:
            console.print()
            console.print(Panel(
                Markdown(vibe_response),
                title="[bold yellow]🎤 BHAI says[/]", border_style="yellow", padding=(1, 2),
            ))
            return vibe_response

        # ── Agentic loop: VibeLLM plans → CoderAgent executes → repeat ──
        max_agentic_rounds = 5
        final_response = vibe_response

        for round_num in range(max_agentic_rounds):
            console.print(f"\n[bold cyan]📋 Task [{round_num+1}]:[/] {task}\n")

            # CoderAgent executes
            coder_result = await self.coder_execute(task)

            # VibeLLM reviews results
            review_prompt = (
                f"CoderAgent completed round {round_num+1}.\n"
                f"Task was: {task}\n\n"
                f"Results:\n{coder_result[:3000]}\n\n"
                "Review the results. If everything looks good and the user's "
                'original request is fulfilled, say "BHAI_DONE" in your response.\n'
                "If more work is needed, output another {\"task\": \"next step\"}.\n"
                "Summarize what was done so far with your BHAI swagger."
            )

            with console.status(f"[bold cyan]BHAI reviewing round {round_num+1}... 🎯[/]"):
                next_task, final_response = await self.vibe_parse(review_prompt)

            # Check if VibeLLM says we're done
            if "BHAI_DONE" in final_response or next_task is None:
                break

            # VibeLLM wants more work
            task = next_task
            console.print(Panel(
                Markdown(final_response),
                title=f"[bold yellow]🎤 BHAI — Round {round_num+1}[/]",
                border_style="yellow", padding=(1, 2),
            ))

        # ── Final summary ──
        console.print()
        # Clean BHAI_DONE from display
        display_response = final_response.replace("BHAI_DONE", "").strip()
        console.print(Panel(
            Markdown(display_response),
            title="[bold yellow]🎤 BHAI says[/]", border_style="yellow", padding=(1, 2),
        ))
        return display_response
