"""
Simple ML Training Library - 轻量级训练库
"""
import pandas as pd
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import math
import os
import time
from sklearn.model_selection import train_test_split

# Environment
os.environ['CUDA_LAUNCH_BLOCKING'] = '1'
os.environ['TORCH_USE_CUDA_DSA'] = '1'

# ====================== Default Config ======================
DEFAULT_CONFIG = {
    'd_model': 128,
    'n_heads': 2,
    'n_layers': 1,
    'lr': 5e-4,
    'weight_decay': 1e-4,
    'batch_size': 2,
    'val_ratio': 0.2,
    'patience': 10,
    'clip_grad': 1.0,
    'warmup_epochs': 10
}

# ====================== Transformer Components ======================
class TransformerBlock(nn.Module):
    def __init__(self, dim, heads):
        super().__init__()
        self.norm1 = nn.LayerNorm(dim)
        self.attn = nn.MultiheadAttention(dim, heads, batch_first=True)
        self.norm2 = nn.LayerNorm(dim)
        self.mlp = nn.Sequential(
            nn.Linear(dim, dim),
            nn.SiLU(),
            nn.Linear(dim, dim)
        )

    def forward(self, x):
        x = x + self.attn(self.norm1(x), self.norm1(x), self.norm1(x))[0]
        x = x + self.mlp(self.norm2(x))
        return x

class AnswerModel(nn.Module):
    def __init__(self, feature_dim, d_model=128, n_heads=2, n_layers=1):
        super().__init__()
        self.emb = nn.Linear(feature_dim, d_model)
        self.pos_emb = nn.Parameter(torch.randn(1, 4, d_model) * 0.02)
        self.layers = nn.ModuleList([
            TransformerBlock(d_model, n_heads) for _ in range(n_layers)
        ])
        self.norm = nn.LayerNorm(d_model)
        self.head = nn.Linear(d_model, 1)

    def forward(self, x, mask=None):
        x = self.emb(x)
        x = x + self.pos_emb
        for layer in self.layers:
            x = layer(x)
        x = self.norm(x)
        logits = self.head(x).squeeze(-1)
        if mask is not None:
            logits = logits.masked_fill(mask == 0, -1e4)
        return logits

# ====================== Data Loader ======================
class SimpleDataLoader:
    def __init__(self):
        self.feat_cols = None

    from typing import Optional
    def load_and_process(self, path, save_processed=True, processed_path: Optional[str] = None):
        """Load raw data and process"""
        if processed_path is None:
            current_dir = os.path.dirname(os.path.abspath(__file__))
            pipeline_dir = os.path.join(current_dir, 'pipeline_data')
            os.makedirs(pipeline_dir, exist_ok=True)
            PROCESS_PATH = pipeline_dir/"PROCESSED_FINAL.xlsx"
            processed_path = PROCESS_PATH
       
        df = pd.read_excel(path)
        df = df[df["Answer"] != "GLOBAL"].copy()
        ratio_cols = ["Count","Mean","Median","Std","Variance","Min","Max","Range","Skewness","Kurtosis"]
        gmm_cols = ["GMM_pi","GMM_mu","GMM_sigma"]
        self.feat_cols = ratio_cols + gmm_cols
        
        units = []
        all_rows = []
        
        for db_name, group in df.groupby("Database"):
            group = group.sort_values("Answer").copy()
            if len(group) != 4: continue
            
            feats = group[self.feat_cols].values.astype(np.float32)
            label = int(group["Right_Answer_Pos"].iloc[0]) - 1
            label = np.clip(label, 0, 3)
            mask = (feats.sum(axis=1) != 0).astype(np.float32)
            
            for i in range(4):
                pi, mu, sigma = feats[i, -3:]
                if np.isnan(pi) or np.isnan(mu) or np.isnan(sigma):
                    pi, mu, sigma = 0.1, 100.0, 5.0
                mu = np.clip(mu, 1e-3, 1e6)
                sigma = np.clip(sigma, 1e-3, 1e6)
                feats[i, -3:] = [pi, np.log(mu), np.log(sigma)]
            
            feats = np.nan_to_num(feats, 0.0, 1e3, -1e3)
            
            # Group normalization
            g_mean = feats.mean(0, keepdims=True)
            g_std = feats.std(0, keepdims=True) + 1e-6
            feats = (feats - g_mean) / g_std
            feats = np.clip(feats, -5, 5)
            
            units.append((feats, label, mask))
            
            for i, ans in enumerate(group["Answer"].values):
                row = [db_name, ans, label] + feats[i].tolist()
                all_rows.append(row)
        
        if save_processed:
            pd.DataFrame(all_rows, columns=["Database","Answer","True_Label(0=A,1=B,2=C,3=D)"] + self.feat_cols
                        ).to_excel(processed_path, index=False)
            print(f"✅ Saved processed data to {processed_path}")
        
        return units, self.feat_cols
    
    def load_processed(self, processed_path):
        """Load already processed data"""
        df = pd.read_excel(processed_path)
        self.feat_cols = [col for col in df.columns if col not in ["Database", "Answer", "True_Label(0=A,1=B,2=C,3=D)"]]
        
        units = []
        for db_name, group in df.groupby("Database"):
            group = group.sort_values("Answer").copy()
            if len(group) != 4: continue
            feats = group[self.feat_cols].values.astype(np.float32)
            label = int(group["True_Label(0=A,1=B,2=C,3=D)"].iloc[0])
            mask = np.ones(4, dtype=np.float32)
            units.append((feats, label, mask))
        
        return units, self.feat_cols
    
    def split_data(self, units, val_ratio=0.2, random_state=42):
        return train_test_split(units, test_size=val_ratio, random_state=random_state)
    
    def get_batches(self, units, batch_size):
        np.random.shuffle(units)
        for i in range(0, len(units), batch_size):
            b = units[i:i+batch_size]
            x = np.stack([o[0] for o in b])
            y = np.array([o[1] for o in b])
            m = np.stack([o[2] for o in b])
            yield torch.tensor(x, dtype=torch.float32), torch.tensor(y, dtype=torch.long), torch.tensor(m, dtype=torch.float32)

# ====================== Trainer ======================
class SimpleTrainer:
    def __init__(self, model, device, config=None):
        self.model = model.to(device)
        self.device = device
        self.config = {**DEFAULT_CONFIG, **(config or {})}
        
        self.optimizer = torch.optim.AdamW(
            model.parameters(), 
            lr=self.config['lr'], 
            weight_decay=self.config['weight_decay']
        )
        self.criterion = nn.CrossEntropyLoss()
        self.best_val_loss = np.inf
        self.wait = 0
    
    def train_epoch(self, train_units, data_loader):
        self.model.train()
        total_loss, correct, total = 0, 0, 0
        
        for x, y, m in data_loader.get_batches(train_units, self.config['batch_size']):
            x, y, m = x.to(self.device), y.to(self.device), m.to(self.device)
            p = self.model(x, m)
            loss = self.criterion(p, y)
            
            self.optimizer.zero_grad()
            loss.backward()
            nn.utils.clip_grad_norm_(self.model.parameters(), self.config['clip_grad'])
            self.optimizer.step()
            
            total_loss += loss.item() * x.size(0)
            correct += (p.argmax(1) == y).sum().item()
            total += x.size(0)
        
        return total_loss / total, correct / total
    
    def validate(self, val_units, data_loader):
        self.model.eval()
        total_loss, correct, total = 0, 0, 0
        
        with torch.no_grad():
            for x, y, m in data_loader.get_batches(val_units, self.config['batch_size']):
                x, y, m = x.to(self.device), y.to(self.device), m.to(self.device)
                p = self.model(x, m)
                total_loss += self.criterion(p, y).item() * x.size(0)
                correct += (p.argmax(1) == y).sum().item()
                total += x.size(0)
        
        return total_loss / total, correct / total
    
    def should_stop(self, val_loss):
        if val_loss < self.best_val_loss:
            self.best_val_loss = val_loss
            self.wait = 0
            return False
        else:
            self.wait += 1
            return self.wait >= self.config['patience']
    
    def save_best(self, path="model/best_final_model.pth"):
        torch.save(self.model.state_dict(), path)
    
    def save(self, path):
        torch.save(self.model.state_dict(), path)