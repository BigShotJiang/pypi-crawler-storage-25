"""
Prediction Library - 模型预测库
"""
import pandas as pd
import numpy as np
import torch
import torch.nn as nn
from typing import Dict, List, Tuple, Optional
import os

current_dir = os.path.dirname(os.path.abspath(__file__))
pipeline_dir = os.path.join(current_dir, 'pipeline_data')
os.makedirs(pipeline_dir, exist_ok=True)
OUTPUT_PATH = pipeline_dir/"PREDICTION_RESULTS.xlsx"

class Predictor:
    """模型预测器类"""
    
    # 默认特征列
    DEFAULT_FEAT_COLS = [
        "Count", "Mean", "Median", "Std", "Variance", "Min", "Max",
        "Range", "Skewness", "Kurtosis", "GMM_pi", "GMM_mu", "GMM_sigma"
    ]
    
    # 答案映射
    ANSWER_MAP = {0: "ANSWER A", 1: "ANSWER B", 2: "ANSWER C", 3: "ANSWER D"}
    
    def __init__(self, model_class, feature_dim: int, model_path: str, device: Optional[str] = None):
        """
        初始化预测器
        
        Args:
            model_class: 模型类 (如 AnswerModel)
            feature_dim: 特征维度
            model_path: 模型权重文件路径
            device: 设备 ('cuda' 或 'cpu')，None则自动选择
        """
        self.device = torch.device(device if device else ("cuda" if torch.cuda.is_available() else "cpu"))
        
        # 加载模型
        print(f"🔹 Loading trained model from {model_path}...")
        self.model = model_class(feature_dim).to(self.device)
        self.model.load_state_dict(torch.load(model_path, map_location=self.device))
        self.model.eval()  # 预测模式
        print(f"✅ Model loaded on {self.device}!\n")
        
        self.feat_cols = self.DEFAULT_FEAT_COLS
        self.answer_map = self.ANSWER_MAP
    
    def predict_single(self, features: np.ndarray, mask: Optional[np.ndarray] = None) -> Tuple[int, np.ndarray]:
        """
        预测单个样本
        
        Args:
            features: 特征数组 shape (4, feature_dim)
            mask: 掩码数组 shape (4,)，None则全为1
        
        Returns:
            (预测的标签, 原始logits)
        """
        if mask is None:
            mask = np.ones(4, dtype=np.float32)
        
        x = torch.tensor(features, dtype=torch.float32).unsqueeze(0).to(self.device)
        m = torch.tensor(mask, dtype=torch.float32).unsqueeze(0).to(self.device)
        
        with torch.no_grad():
            output = self.model(x, m)
            pred_label = torch.argmax(output, dim=1).item()
            logits = output.cpu().numpy()
        
        return pred_label, logits
    
    def predict_dataframe(self, df: pd.DataFrame, group_col: str = "Database", 
                          answer_col: str = "Answer", label_col: str = "True_Label(0=A,1=B,2=C,3=D)") -> pd.DataFrame:
        """
        预测DataFrame中的数据
        
        Args:
            df: 数据DataFrame
            group_col: 分组列名
            answer_col: 答案列名
            label_col: 真实标签列名
        
        Returns:
            预测结果DataFrame
        """
        results = []
        
        for db_name, group in df.groupby(group_col):
            group = group.sort_values(answer_col).copy()
            if len(group) != 4:
                print(f"⚠️ Warning: {db_name} has {len(group)} answers (expected 4), skipping...")
                continue
            
            # 获取特征
            feats = group[self.feat_cols].values.astype(np.float32)
            true_label = int(group[label_col].iloc[0])
            
            # 预测
            pred_label, logits = self.predict_single(feats)
            
            # 存储结果
            results.append({
                "Database": db_name,
                "True_Answer": self.answer_map[true_label],
                "Predicted_Answer": self.answer_map[pred_label],
                "Correct?": "✅ YES" if pred_label == true_label else "❌ NO",
                "True_Label": true_label,
                "Pred_Label": pred_label,
                "Raw_Prediction_Logits": logits.tolist()
            })
        
        return pd.DataFrame(results)
    
    def predict_from_excel(self, data_path: str, sheet_name: int = 0) -> pd.DataFrame:
        """
        从Excel文件读取数据并预测
        
        Args:
            data_path: Excel文件路径
            sheet_name: 工作表名或索引
        
        Returns:
            预测结果DataFrame
        """
        print(f"📊 Loading data from {data_path}...")
        df = pd.read_excel(data_path, sheet_name=sheet_name)
        print(f"✅ Loaded {len(df)} rows from {len(df['Database'].unique())} databases\n")
        
        return self.predict_dataframe(df)
    
    from typing import Optional
    def save_results(self, results_df: pd.DataFrame, output_path: Optional[str] = None):
        """保存预测结果到Excel"""
        if output_path is None:
            output_path = OUTPUT_PATH
        
        results_df.to_excel(output_path, index=False)
        print(f"\n✅ Prediction saved to: {output_path}")
    
    def print_summary(self, results_df: pd.DataFrame):
        """打印预测结果摘要"""
        print("=" * 80)
        print("📊 PREDICTION RESULTS")
        print("=" * 80)
        
        # 显示主要结果
        display_cols = ["Database", "True_Answer", "Predicted_Answer", "Correct?"]
        print(results_df[display_cols].to_string(index=False))
        print("=" * 80)
        
        # 计算准确率
        accuracy = (results_df["Correct?"] == "✅ YES").mean()
        correct_count = (results_df["Correct?"] == "✅ YES").sum()
        total_count = len(results_df)
        
        print(f"\n📈 Total Prediction Accuracy: {correct_count}/{total_count} = {accuracy:.2%}")
        
        # 显示错误样本
        errors = results_df[results_df["Correct?"] == "❌ NO"]
        if len(errors) > 0:
            print(f"\n⚠️ Errors ({len(errors)} samples):")
            print(errors[["Database", "True_Answer", "Predicted_Answer"]].to_string(index=False))
        
        return accuracy


class BatchPredictor(Predictor):
    """批量预测器 - 支持多个模型文件"""
    
    def __init__(self, model_class, feature_dim: int, model_paths: List[str], device: Optional[str] = None):
        """
        初始化批量预测器
        
        Args:
            model_class: 模型类
            feature_dim: 特征维度
            model_paths: 多个模型权重文件路径列表
            device: 设备
        """
        self.device = torch.device(device if device else ("cuda" if torch.cuda.is_available() else "cpu"))
        self.models = []
        
        for path in model_paths:
            model = model_class(feature_dim).to(self.device)
            model.load_state_dict(torch.load(path, map_location=self.device))
            model.eval()
            self.models.append((path, model))
        
        print(f"✅ Loaded {len(self.models)} models on {self.device}")
    
    def predict_ensemble(self, features: np.ndarray, mask: Optional[np.ndarray] = None, 
                        method: str = 'vote') -> Tuple[int, np.ndarray]:
        """
        集成预测
        
        Args:
            features: 特征数组
            mask: 掩码数组
            method: 集成方法 ('vote' 投票, 'avg' 平均logits)
        
        Returns:
            (预测标签, 平均logits)
        """
        if mask is None:
            mask = np.ones(4, dtype=np.float32)
        
        x = torch.tensor(features, dtype=torch.float32).unsqueeze(0).to(self.device)
        m = torch.tensor(mask, dtype=torch.float32).unsqueeze(0).to(self.device)
        
        all_logits = []
        all_preds = []
        
        with torch.no_grad():
            for path, model in self.models:
                output = model(x, m)
                all_logits.append(output.cpu().numpy())
                all_preds.append(torch.argmax(output, dim=1).item())
        
        if method == 'vote':
            # 投票法
            pred_label = max(set(all_preds), key=all_preds.count)
        else:
            # 平均logits
            avg_logits = np.mean(all_logits, axis=0)
            pred_label = np.argmax(avg_logits)
        
        return pred_label, np.mean(all_logits, axis=0)