from __future__ import annotations

"""
models.py — Public data-transfer objects.

"""

import re
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional


# ── API response models ───────────────────────────────────────────────────────

@dataclass
class DocumentInfo:
    filename: str
    content: str
    size: int
    modified_time: Optional[datetime] = None


@dataclass
class ChatResponse:
    response: str
    query: str
    session_id: str
    user_id: str
    timestamp: datetime


@dataclass
class MatchingDocsResponse:
    status: str
    query: str
    response: str
    with_data: bool
    session_id: str
    user_id: str
    timestamp: datetime


@dataclass
class HealthResponse:
    status: str
    message: str
    timestamp: datetime
    details: Optional[Dict[str, Any]] = None


@dataclass
class BatchResult:
    batch_number: int
    response: Any
    files_processed: List[str]
    success: bool
    error_message: Optional[str] = None
    processing_time: Optional[float] = None


# ── Sync classification models ────────────────────────────────────────────────

class FileStatus(Enum):
    """
    Classified intent for a single source file before upload.

    NEW       → never uploaded; use add_docs
    CHANGED   → uploaded before, chunks exist on disk; use refresh_docs
    UNCHANGED → reserved, not currently used
    UNKNOWN   → source file missing from disk; caller decides
    """
    NEW       = "new"
    CHANGED   = "changed"
    UNCHANGED = "unchanged"
    UNKNOWN   = "unknown"


@dataclass
class FileClassification:
    """Pre-flight classification result for one source file."""
    filename: str
    status: FileStatus
    endpoint: str    # "add_docs" | "refresh_docs" | "skip"
    reason: str


@dataclass
class SyncPlan:
    """Full pre-flight plan produced by sync_documents(dry_run=True)."""
    to_add: List[str]
    to_refresh: List[str]
    to_skip: List[str]
    classifications: List[FileClassification]

    def summary(self) -> Dict[str, Any]:
        return {
            "to_add":     len(self.to_add),
            "to_refresh": len(self.to_refresh),
            "to_skip":    len(self.to_skip),
            "total":      len(self.classifications),
        }


@dataclass
class SyncResult:
    """Outcome of a sync_documents() call."""
    added: List[str]
    refreshed: List[str]
    skipped: List[str]
    failed: Dict[str, str]   # filename → error message
    plan: SyncPlan

    def to_dict(self) -> Dict[str, Any]:
        return {
            "added":     self.added,
            "refreshed": self.refreshed,
            "skipped":   self.skipped,
            "failed":    self.failed,
            "plan":      self.plan.summary(),
        }


# ── Chunk name codec ──────────────────────────────────────────────────────────

_CHUNK_RE = re.compile(
    r"^(?P<stem>.+?)_part(?P<part>\d+)\.txt$"
)


@dataclass
class VersionedChunkName:
    """
    Encodes and decodes the chunk filename convention.

    Pattern:  {stem}_part{part}.txt

    Examples
    --------
    VersionedChunkName.build("report.pdf", part=3).filename
    → "report_part3.txt"

    VersionedChunkName.parse("report_part3.txt")
    → VersionedChunkName(stem="report", part=3, ext=".txt")
    """
    stem: str
    part: int
    ext: str = ".txt"
    # version kept for backwards-compat but no longer used in filenames
    version: int = 1

    @property
    def filename(self) -> str:
        return f"{self.stem}_part{self.part}.txt"

    @classmethod
    def build(cls, source_name: str, part: int, version: int = 1) -> VersionedChunkName:
        """
        Create from a source filename.
        All chunks are written as .txt regardless of source format.
        The version parameter is accepted for backwards-compatibility but ignored.
        """
        p = Path(source_name)
        return cls(stem=p.stem, part=part, ext=".txt", version=version)

    @classmethod
    def parse(cls, filename: str) -> Optional[VersionedChunkName]:
        """
        Decode a chunk filename. Returns None if not SDK-convention.
        """
        m = _CHUNK_RE.match(Path(filename).name)
        if not m:
            return None
        return cls(
            stem=m.group("stem"),
            part=int(m.group("part")),
            ext=".txt",
        )

    @staticmethod
    def is_versioned(filename: str) -> bool:
        return _CHUNK_RE.match(Path(filename).name) is not None