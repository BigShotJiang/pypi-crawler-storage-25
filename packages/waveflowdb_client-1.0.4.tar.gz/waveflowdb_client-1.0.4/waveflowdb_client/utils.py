"""
utils.py — File processing, batch creation, and structured logging.
"""

import csv
import hashlib
import json
import logging
import os
import shutil
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from .exceptions import FileProcessingError, UnsupportedFileTypeError
from .models import VersionedChunkName

logger = logging.getLogger(__name__)


# ─────────────────────────────────────────────────────────────────────────────
#  TEXT EXTRACTION  (one function per format, easy to extend)
# ─────────────────────────────────────────────────────────────────────────────

def _read_plain(path: str, encoding: str = "utf-8") -> str:
    with open(path, "r", encoding=encoding, errors="replace") as f:
        return f.read()


def _extract_pdf(path: str) -> str:
    try:
        import PyPDF2
    except ImportError as exc:
        raise FileProcessingError(f"PyPDF2 not installed: {exc}") from exc
    text_parts: List[str] = []
    with open(path, "rb") as f:
        reader = PyPDF2.PdfReader(f)
        for page in reader.pages:
            text_parts.append(page.extract_text() or "")
    return "\n\n".join(text_parts)


def _extract_docx(path: str) -> str:
    try:
        from docx import Document
    except ImportError as exc:
        raise FileProcessingError(f"python-docx not installed: {exc}") from exc
    doc = Document(path)
    return "\n\n".join(p.text for p in doc.paragraphs if p.text.strip())


def _extract_py(path: str) -> str:
    return _read_plain(path)


def _extract_ipynb(path: str) -> str:
    with open(path, "r", encoding="utf-8") as f:
        nb = json.load(f)
    return "\n\n".join(
        "".join(cell["source"]) if isinstance(cell["source"], list) else cell["source"]
        for cell in nb.get("cells", [])
        if cell.get("cell_type") == "code"
    )


_EXTRACTORS = {
    "txt":   _read_plain,
    "py":    _extract_py,
    "ipynb": _extract_ipynb,
    "pdf":   _extract_pdf,
    "docx":  _extract_docx,
}

# Extensions that are text-like and benefit from paragraph chunking
_TEXT_LIKE = {"txt", "py", "ipynb", "pdf", "docx"}

# Extensions that are kept as structured records (split by row/record)
_RECORD_LIKE = {"csv", "jsonl", "ndjson"}

# Extensions that are kept atomic (never split)
_ATOMIC = {"json"}


def extract_text(file_path: str) -> str:
    """Return the full text of a file regardless of format."""
    ext = Path(file_path).suffix.lstrip(".").lower()
    extractor = _EXTRACTORS.get(ext)
    if extractor:
        return extractor(file_path)
    # Fallback: treat as plain text
    return _read_plain(file_path)


# ─────────────────────────────────────────────────────────────────────────────
#  CHUNKING HELPERS
# ─────────────────────────────────────────────────────────────────────────────

def paragraph_chunk(text: str, max_chars: int) -> List[str]:
    """
    Split text on blank lines.  No paragraph is ever split mid-way.
    Consecutive short paragraphs are merged until the limit is reached.
    """
    paragraphs = [p.strip() for p in text.split("\n\n") if p.strip()]
    chunks: List[str] = []
    current: List[str] = []
    current_len = 0

    for para in paragraphs:
        para_len = len(para) + 2  # +2 for the "\n\n" separator
        if current and current_len + para_len > max_chars:
            chunks.append("\n\n".join(current))
            current = []
            current_len = 0
        current.append(para)
        current_len += para_len

    if current:
        chunks.append("\n\n".join(current))

    return chunks or [text]   # at minimum one chunk (the whole text)


def _split_csv_safe(
    file_path: str,
    safe_limit: int,
    chunks_dir: Path,
    base_chunk_name_fn,          # callable(part: int) -> str
) -> List[str]:
    """Split a CSV by rows; never break a row across chunks."""
    p = Path(file_path)
    output_files: List[str] = []

    # Detect encoding
    encoding = "utf-8"
    for enc in ("utf-8", "cp1252", "latin-1"):
        try:
            with open(p, "r", newline="", encoding=enc) as f:
                csv.reader(f).__next__()
            encoding = enc
            break
        except (UnicodeDecodeError, StopIteration):
            continue

    with open(p, "r", newline="", encoding=encoding, errors="replace") as f:
        reader = csv.reader(f)
        try:
            header = next(reader)
        except StopIteration:
            raise FileProcessingError(f"CSV file is empty: {file_path}")

        header_bytes = len(",".join(header).encode("utf-8"))
        part, rows, current_size = 1, [], header_bytes

        for row in reader:
            try:
                row_bytes = len(",".join(row).encode("utf-8"))
            except Exception:
                continue  # skip unserializable rows

            if row_bytes > safe_limit:
                raise FileProcessingError(
                    f"A single CSV row exceeds safe limit ({safe_limit} bytes)"
                )

            if current_size + row_bytes > safe_limit and rows:
                out = chunks_dir / base_chunk_name_fn(part)
                _write_csv(out, header, rows)
                output_files.append(str(out))
                part += 1
                rows, current_size = [], header_bytes

            rows.append(row)
            current_size += row_bytes

        if rows:
            out = chunks_dir / base_chunk_name_fn(part)
            _write_csv(out, header, rows)
            output_files.append(str(out))

    return output_files


def _write_csv(path: Path, header: List[str], rows: List[List[str]]) -> None:
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(header)
        w.writerows(rows)


def _split_jsonl_safe(
    file_path: str,
    safe_limit: int,
    chunks_dir: Path,
    base_chunk_name_fn,
) -> List[str]:
    """Split JSONL by record; each line is atomic."""
    p = Path(file_path)
    output_files: List[str] = []
    part, buffer, current_size = 1, [], 0

    def flush():
        nonlocal part, buffer, current_size
        if not buffer:
            return
        out = chunks_dir / base_chunk_name_fn(part)
        with open(out, "w", encoding="utf-8") as f:
            for line in buffer:
                f.write(line + "\n")
        output_files.append(str(out))
        part += 1
        buffer.clear()
        current_size = 0

    with open(p, "r", encoding="utf-8", errors="replace") as f:
        for lineno, raw in enumerate(f, 1):
            line = raw.strip()
            if not line:
                continue
            try:
                json.loads(line)
            except Exception as exc:
                raise FileProcessingError(
                    f"Invalid JSON at line {lineno} in {file_path}: {exc}"
                ) from exc

            line_bytes = len((line + "\n").encode("utf-8"))
            if line_bytes > safe_limit:
                raise FileProcessingError(
                    f"Single JSONL record exceeds safe limit ({safe_limit} bytes)"
                )
            if current_size + line_bytes > safe_limit:
                flush()
            buffer.append(line)
            current_size += line_bytes

    flush()
    return output_files


# ─────────────────────────────────────────────────────────────────────────────
#  FILE PROCESSOR
# ─────────────────────────────────────────────────────────────────────────────

class FileProcessor:
    """
    Validates and reads files.

    allowed_extensions is passed from Config so .env is the single source.
    """

    def __init__(self, allowed_extensions: List[str]):
        self.allowed_extensions = [e.lower() for e in allowed_extensions]

    def is_supported(self, filename: str) -> bool:
        ext = Path(filename).suffix.lstrip(".").lower()
        return ext in self.allowed_extensions

    def assert_supported(self, filename: str) -> None:
        if not self.is_supported(filename):
            raise UnsupportedFileTypeError(filename, self.allowed_extensions)

    def read_content(self, filepath: str) -> str:
        """
        Read and return full text content of any supported file.

        Chunks written by BatchManager are always plain .txt files regardless
        of the original source format. Running a format-specific extractor
        (e.g. _extract_pdf) on an already-extracted .txt chunk would either
        fail or produce garbage, so versioned chunks are always read as plain
        text directly.
        """
        self.assert_supported(filepath)
        if VersionedChunkName.is_versioned(filepath):
            return _read_plain(filepath)
        return extract_text(filepath)


# ─────────────────────────────────────────────────────────────────────────────
#  BATCH MANAGER  (sequential, version-aware, checksum-skipping)
# ─────────────────────────────────────────────────────────────────────────────

class BatchManager:
    """
    Converts a list of source files into upload-ready batches.

    Chunk naming follows the SDK convention:
        {stem}_part{part}.txt
    Chunks already on disk are reused — safe to re-run after a crash.
    """

    def __init__(
        self,
        max_files: int,
        max_size_mb: int,
        allowed_extensions: List[str],
    ):
        self.max_files = max_files
        self.max_bytes = max_size_mb * 1024 * 1024
        self.file_processor = FileProcessor(allowed_extensions)

    def create_batches(
        self,
        files: List[str],
        base_path: str,
    ) -> Tuple[List[List[str]], str]:
        """
        Process files into upload batches.

        Returns (batches, chunks_dir).
          batches    : list of lists of chunk basenames
          chunks_dir : directory where chunk files live
        """
        safe_limit = int(self.max_bytes * 0.8)
        chunks_dir = Path(base_path) / "chunks"
        chunks_dir.mkdir(parents=True, exist_ok=True)

        file_info: List[Tuple[str, int]] = []

        for fname in files:
            src = Path(base_path) / fname
            if not src.is_file():
                logger.warning("File not found, skipping: %s", src)
                continue
            if not self.file_processor.is_supported(fname):
                logger.warning("Unsupported extension, skipping: %s", fname)
                continue

            ext = src.suffix.lstrip(".").lower()

            def _chunk_name(part: int, _fname=fname) -> str:
                return VersionedChunkName.build(_fname, part=part).filename

            if ext == "json":
                cname = _chunk_name(1)
                dst = chunks_dir / cname
                if not dst.exists():
                    shutil.copy2(src, dst)
                file_info.append((str(dst), dst.stat().st_size))

            elif ext == "csv":
                parts = _split_csv_safe(str(src), safe_limit, chunks_dir, _chunk_name)
                for p in parts:
                    file_info.append((p, Path(p).stat().st_size))

            elif ext in ("jsonl", "ndjson"):
                parts = _split_jsonl_safe(str(src), safe_limit, chunks_dir, _chunk_name)
                for p in parts:
                    file_info.append((p, Path(p).stat().st_size))

            elif ext in _TEXT_LIKE:
                text = extract_text(str(src))
                chunks = paragraph_chunk(text, max_chars=safe_limit)
                for i, chunk_text in enumerate(chunks, 1):
                    cname = _chunk_name(i)
                    dst = chunks_dir / cname
                    if not dst.exists():
                        dst.write_text(chunk_text, encoding="utf-8")
                    file_info.append((str(dst), dst.stat().st_size))

            else:
                size = src.stat().st_size
                if size > safe_limit:
                    text = src.read_text(encoding="utf-8", errors="replace")
                    chunks = paragraph_chunk(text, max_chars=safe_limit)
                    for i, chunk_text in enumerate(chunks, 1):
                        cname = _chunk_name(i)
                        dst = chunks_dir / cname
                        if not dst.exists():
                            dst.write_text(chunk_text, encoding="utf-8")
                        file_info.append((str(dst), dst.stat().st_size))
                else:
                    cname = _chunk_name(1)
                    dst = chunks_dir / cname
                    if not dst.exists():
                        shutil.copy2(src, dst)
                    file_info.append((str(dst), dst.stat().st_size))

        batches: List[List[str]] = []
        current_batch: List[str] = []
        current_size = 0

        for abs_path, size in file_info:
            name = Path(abs_path).name
            if size > self.max_bytes:
                raise FileProcessingError(
                    f"Chunk '{name}' ({size} bytes) exceeds max batch size ({self.max_bytes} bytes)"
                )
            if current_batch and (
                len(current_batch) >= self.max_files
                or current_size + size > self.max_bytes
            ):
                batches.append(current_batch)
                current_batch, current_size = [], 0
            current_batch.append(name)
            current_size += size

        if current_batch:
            batches.append(current_batch)

        logger.info("Batch creation: %d source files → %d batches", len(files), len(batches))
        return batches, str(chunks_dir)


class Logger:
    """Structured CSV-based logger for skipped files, API errors, and performance."""

    def __init__(self, log_dir: str):
        Path(log_dir).mkdir(parents=True, exist_ok=True)
        self._log_dir = Path(log_dir)

    def _append_csv(self, filename: str, header: List[str], row: list) -> None:
        path = self._log_dir / filename
        exists = path.exists()
        with open(path, "a", newline="", encoding="utf-8") as f:
            w = csv.writer(f)
            if not exists:
                w.writerow(header)
            w.writerow(row)

    def log_skipped_file(self, filename: str, reason: str) -> None:
        self._append_csv(
            "skipped_files.csv",
            ["timestamp", "filename", "reason"],
            [_utcnow(), filename, reason],
        )

    def log_api_error(self, operation: str, batch_num: int, message: str) -> None:
        self._append_csv(
            "api_errors.csv",
            ["timestamp", "operation", "batch_num", "message"],
            [_utcnow(), operation, batch_num, message],
        )

    def log_performance(self, **kwargs) -> None:
        row = {"timestamp": _utcnow(), **{k: str(v) for k, v in kwargs.items()}}
        path = self._log_dir / "performance.csv"
        exists = path.exists()
        with open(path, "a", newline="", encoding="utf-8") as f:
            w = csv.DictWriter(f, fieldnames=row.keys())
            if not exists:
                w.writeheader()
            w.writerow(row)


def _utcnow() -> str:
    return datetime.now(timezone.utc).isoformat()