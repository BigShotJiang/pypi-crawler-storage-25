"""
client.py — VectorLakeClient
"""
from __future__ import annotations

import hashlib
import json
import logging
import os
import sys
import time
from pathlib import Path
from typing import Any, Dict, List, Optional

import requests

from .config import Config
from .exceptions import (
    APIError, ConfigError, InvalidSearchTypeError,
    ThrottleError, ValidationError, VectorLakeError,
)
from .models import FileClassification, FileStatus, SyncPlan, SyncResult, VersionedChunkName
from .utils import BatchManager, FileProcessor, Logger

# ── Logging: always attach a handler so basicConfig no-op doesn't silence us ──
logger = logging.getLogger(__name__)
if not logger.handlers:
    _handler = logging.StreamHandler(sys.stdout)
    _handler.setFormatter(logging.Formatter("%(levelname)s [%(name)s]: %(message)s"))
    logger.addHandler(_handler)
    logger.setLevel(logging.INFO)
logger.propagate = False

_VALID_SEARCH_TYPES = ("flat", "flat_filter")


# ── tqdm shim: real tqdm when available, plain-print fallback otherwise ────────

try:
    from tqdm import tqdm as _tqdm

    def _progress_bar(iterable, *, total: int, desc: str, initial: int = 0, unit: str = "it"):
        return _tqdm(
            iterable, total=total, desc=desc, unit=unit,
            initial=initial,
            dynamic_ncols=True, file=sys.stdout,
        )

except ImportError:
    class _FallbackBar:
        def __init__(self, iterable, *, total, desc, initial=0, unit="it"):
            self._it    = iterable
            self._total = total
            self._desc  = desc
            self._n     = initial

        def __iter__(self):
            for item in self._it:
                self._n += 1
                yield item

        def set_postfix_str(self, s, **_):
            pct = int(self._n / self._total * 100) if self._total else 0
            print(f"  [{self._desc}] {self._n}/{self._total} ({pct}%) — {s}", flush=True)

        def update(self, n=1):
            self._n += n

        def __enter__(self):  return self
        def __exit__(self, *_): pass

    def _progress_bar(iterable, *, total, desc, initial=0, unit="it"):
        return _FallbackBar(iterable, total=total, desc=desc, initial=initial, unit=unit)


# ── helpers ────────────────────────────────────────────────────────────────────

def _md5(filepath: str) -> str:
    h = hashlib.md5()
    with open(filepath, "rb") as f:
        for block in iter(lambda: f.read(65536), b""):
            h.update(block)
    return h.hexdigest()


def _divider(label: str = "", width: int = 60) -> str:
    return f"\n{'─' * width}\n  {label}\n{'─' * width}" if label else f"{'─' * width}"


def _source_ext(chunk_name: str, base_path: str) -> str:
    """
    Recover the original source file extension from a chunk filename.

    Parses the chunk stem via VersionedChunkName, then looks for the source
    file in base_path to get its real extension. Falls back to "txt" if the
    source file is not found (e.g. direct-upload mode).
    """
    parsed = VersionedChunkName.parse(chunk_name)
    if parsed:
        candidates = list(Path(base_path).glob(f"{parsed.stem}.*"))
        # Exclude other chunk files in the same dir
        candidates = [c for c in candidates if not VersionedChunkName.is_versioned(c.name)]
        if candidates:
            return candidates[0].suffix.lstrip(".").lower()
    return Path(chunk_name).suffix.lstrip(".").lower() or "txt"


class VectorLakeClient:
    """
    Main entry point for the VectorLake SDK.

    Raises ConfigError at init if API key is missing.
    """

    def __init__(self, config: Optional[Config] = None, **kwargs):
        if config is None:
            config = Config(**kwargs)

        self.config = config
        logger.info("VectorLakeClient ready — %s", config)

        self._logger = Logger(config.log_dir)
        self._batch_manager = BatchManager(
            max_files=config.max_files_per_batch,
            max_size_mb=config.max_batch_size_mb,
            allowed_extensions=config.allowed_extensions,
        )
        self._file_processor = FileProcessor(config.allowed_extensions)

    # ── Internal: HTTP ────────────────────────────────────────────────────────

    def _headers(self) -> Dict[str, str]:
        return {
            "Content-Type": "application/json",
            "x-api-key": self.config.api_key,
        }

    def _make_request(
        self,
        endpoint: str,
        payload: Dict[str, Any],
        operation: str = "",
        batch_num: int = 0,
    ) -> Dict[str, Any]:
        """POST with retry + exponential backoff. Always returns a plain dict."""
        headers    = self._headers()
        request_kb = len(json.dumps(payload).encode()) / 1024
        logger.debug("Batch %d — payload %.1f KB", batch_num, request_kb)
        last_error: Optional[APIError] = None

        for attempt in range(self.config.max_retries):
            try:
                t0   = time.time()
                resp = requests.post(
                    endpoint,
                    json=payload,
                    headers=headers,
                    timeout=self.config.timeout,
                )
                latency_ms = (time.time() - t0) * 1000
                logger.debug("Batch %d — HTTP %d in %.0f ms", batch_num, resp.status_code, latency_ms)

                try:
                    body = resp.json()
                except Exception:
                    body = {"status_code": resp.status_code, "text": resp.text}

                if operation:
                    self._logger.log_performance(
                        operation=operation,
                        batch_num=batch_num,
                        latency_ms=round(latency_ms, 1),
                        request_kb=round(request_kb, 1),
                        response_kb=round(len(resp.content) / 1024, 1),
                        http_status=resp.status_code,
                    )

                if resp.status_code == 429:
                    wait = int(resp.headers.get("Retry-After", 2 ** attempt))
                    logger.warning(
                        "Rate-limited on batch %d (attempt %d); retrying in %ds",
                        batch_num, attempt + 1, wait,
                    )
                    if operation:
                        self._logger.log_api_error(
                            operation, batch_num,
                            f"ThrottleError: rate-limited, waiting {wait}s",
                        )
                    time.sleep(wait)
                    last_error = ThrottleError()
                    continue

                if resp.status_code >= 400:
                    msg = (
                        body.get("message", f"HTTP {resp.status_code}")
                        if isinstance(body, dict) else resp.text
                    )
                    err = APIError(msg, resp.status_code, resp.text)
                    if operation:
                        self._logger.log_api_error(operation, batch_num, str(err))
                    return err.to_response()

                return body

            except requests.exceptions.Timeout as exc:
                wait = 2 ** attempt
                logger.warning("Timeout on attempt %d; retrying in %ds", attempt + 1, wait)
                last_error = APIError(f"Request timed out: {exc}")
                time.sleep(wait)

            except requests.exceptions.ConnectionError as exc:
                wait = 2 ** attempt
                logger.warning("Connection error on attempt %d; retrying in %ds", attempt + 1, wait)
                last_error = APIError(f"Connection error: {exc}")
                time.sleep(wait)

            except requests.exceptions.RequestException as exc:
                err = APIError(str(exc))
                if operation:
                    self._logger.log_api_error(operation, batch_num, str(err))
                return err.to_response()

        final_error = last_error or APIError("Max retries exceeded")
        if operation:
            self._logger.log_api_error(operation, batch_num, str(final_error))
        return final_error.to_response()

    # ── Internal: grand total helper ──────────────────────────────────────────

    def _compute_grand_total(self, base_path: str) -> int:
        """Count total batches across ALL supported files in base_path. Zero extra HTTP calls."""
        all_files = [
            f for f in os.listdir(base_path)
            if os.path.isfile(os.path.join(base_path, f))
            and self._file_processor.is_supported(f)
        ]
        if not all_files:
            return 0
        all_batches, _ = self._batch_manager.create_batches(all_files, base_path)
        return len(all_batches)

    # ── Internal: batch processing ────────────────────────────────────────────

    def _process_files_in_batches(
        self,
        operation: str,
        user_id: str,
        vector_lake_description: str,
        start_from_batch: int = 1,
        end_batch: Optional[int] = None,
        intelligent_segmentation: bool = True,
        session_id: Optional[str] = None,
        files: Optional[List[str]] = None,
        batch_delay: float = 1.0,
        grand_total_batches: Optional[int] = None,
    ) -> Dict[str, Any]:
        """Sequential batch upload with live progress. Resumes from start_from_batch."""
        base_path = self.config.vector_lake_path

        if files is None:
            files = [
                f for f in os.listdir(base_path)
                if os.path.isfile(os.path.join(base_path, f))
                and self._file_processor.is_supported(f)
            ]

        if not files:
            return {
                "success": False,
                "error":   "NoFilesError",
                "message": "No supported files found in upload directory.",
            }

        batches, chunks_dir = self._batch_manager.create_batches(files, base_path)
        total_batches       = len(batches)
        display_total       = grand_total_batches or total_batches
        total_chunks        = sum(len(b) for b in batches)

        # ── resolve end_batch ──────────────────────────────────────────────
        resolved_end = min(end_batch, total_batches) if end_batch is not None else total_batches
        if resolved_end < start_from_batch:
            return {
                "success": False,
                "error":   "InvalidRangeError",
                "message": f"end_batch ({resolved_end}) must be >= start_from_batch ({start_from_batch}).",
            }

        # ── startup banner ─────────────────────────────────────────────────
        print(_divider(f"▶  {operation.upper()}"))
        print(f"   Source files  : {len(files)}")
        print(f"   Chunks        : {total_chunks}")
        print(f"   This run      : {total_batches} batches")
        print(f"   Overall total : {display_total} batches")
        print(f"   Batch range   : #{start_from_batch} → #{resolved_end}")
        print(_divider())

        logger.info(
            "%s — %d files | %d batches (overall: %d) | range #%d → #%d",
            operation, len(files), total_batches, display_total,
            start_from_batch, resolved_end,
        )

        endpoint       = self.config.endpoints[operation]
        batch_outputs: List[Dict] = []
        ok_count = fail_count = 0

        active  = [
            (i, b) for i, b in enumerate(batches)
            if start_from_batch <= (i + 1) <= resolved_end
        ]
        initial = start_from_batch - 1

        with _progress_bar(
            active,
            total=display_total,
            desc=operation,
            initial=initial,
            unit="batch",
        ) as bar:
            for i, batch in bar:
                batch_num = i + 1
                t0        = time.time()

                try:
                    logger.info(
                        "[BATCH START] op=%s batch=%d/%d files=%s",
                        operation, batch_num, display_total, batch,
                    )

                    file_contents = []
                    files_meta    = []
                    for fname in batch:
                        chunk_path = os.path.join(chunks_dir, fname)
                        if not os.path.exists(chunk_path):
                            chunk_path = os.path.join(base_path, fname)
                        file_contents.append(self._file_processor.read_content(chunk_path))
                        files_meta.append({
                            "filename":  fname,
                            "extension": _source_ext(fname, base_path),
                        })

                    payload = {
                        "session_id":               session_id,
                        "user_id":                  user_id,
                        "vector_lake_description":  vector_lake_description,
                        "files_name":               batch,
                        "files_data":               file_contents,
                        "files_meta":               files_meta,
                        "intelligent_segmentation": intelligent_segmentation,
                    }
                    request_start_ts = time.time()
                    result           = self._make_request(endpoint, payload, operation, batch_num)
                    elapsed_ms       = round((time.time() - request_start_ts) * 1000, 1)
                    elapsed          = round(time.time() - t0, 2)
                    succeeded        = not result.get("error")

                    if succeeded:
                        ok_count += 1
                        status = "✓"
                    else:
                        fail_count += 1
                        status = "✗"
                        logger.warning(
                            "Batch %d failed: %s",
                            batch_num, result.get("message", result.get("error")),
                        )

                    logger.info(
                        "[BATCH END] op=%s batch=%d/%d success=%s elapsed_ms=%.1f files=%s",
                        operation, batch_num, display_total, succeeded, elapsed_ms, batch,
                    )

                    batch_outputs.append({
                        "batch_number":    batch_num,
                        "files":           batch,
                        "success":         succeeded,
                        "processing_time": elapsed,
                        "elapsed_ms":      elapsed_ms,
                        "response":        result,
                    })

                    bar.set_postfix_str(
                        f"{elapsed}s | ok={ok_count} fail={fail_count} {status}"
                    )

                except VectorLakeError as exc:
                    elapsed    = round(time.time() - t0, 2)
                    elapsed_ms = round((time.time() - t0) * 1000, 1)
                    fail_count += 1
                    logger.error("Batch %d VectorLakeError: %s", batch_num, exc)
                    logger.info(
                        "[BATCH END] op=%s batch=%d/%d success=False elapsed_ms=%.1f error=%s",
                        operation, batch_num, display_total, elapsed_ms, exc,
                    )
                    batch_outputs.append({
                        "batch_number":    batch_num,
                        "files":           batch,
                        "success":         False,
                        "processing_time": elapsed,
                        "elapsed_ms":      elapsed_ms,
                        "response":        None,
                        "error":           exc.to_response(),
                    })
                    bar.set_postfix_str(
                        f"VectorLakeError | ok={ok_count} fail={fail_count} ✗"
                    )

                except Exception as exc:
                    elapsed    = round(time.time() - t0, 2)
                    elapsed_ms = round((time.time() - t0) * 1000, 1)
                    fail_count += 1
                    logger.exception("Unexpected error on batch %d", batch_num)
                    logger.info(
                        "[BATCH END] op=%s batch=%d/%d success=False elapsed_ms=%.1f error=%s",
                        operation, batch_num, display_total, elapsed_ms, type(exc).__name__,
                    )
                    batch_outputs.append({
                        "batch_number":    batch_num,
                        "files":           batch,
                        "success":         False,
                        "processing_time": elapsed,
                        "elapsed_ms":      elapsed_ms,
                        "response":        None,
                        "error":           {"error": type(exc).__name__, "message": str(exc)},
                    })
                    bar.set_postfix_str(
                        f"{type(exc).__name__} | ok={ok_count} fail={fail_count} ✗"
                    )

                if i < len(batches) - 1:
                    time.sleep(batch_delay)

        # ── completion summary ──────────────────────────────────────────────
        overall = "✓  All batches succeeded" if fail_count == 0 else f"⚠  {fail_count} batch(es) failed"
        print(_divider(f"■  {operation.upper()} COMPLETE"))
        print(f"   {overall}")
        print(f"   Batch range   : #{start_from_batch} → #{resolved_end}")
        print(f"   Succeeded : {ok_count}/{total_batches} (this run)")
        print(f"   Failed    : {fail_count}")
        print(_divider())

        return {
            "mode":               "batch",
            "total_batches":      total_batches,
            "start_batch":        start_from_batch,
            "end_batch":          resolved_end,
            "successful_batches": ok_count,
            "failed_batches":     fail_count,
            "batches":            sorted(batch_outputs, key=lambda x: x["batch_number"]),
        }

    # ── Internal: classify files for sync ─────────────────────────────────────

    def _classify_files(
        self,
        files: List[str],
        base_path: str,
        chunks_dir: str,
    ) -> SyncPlan:
        """
        Classify each source file by checking whether chunks already exist on disk.

        Rules
        ─────
        No chunk exists on disk   → NEW     → add_docs
        Chunk(s) exist on disk    → CHANGED → refresh_docs
        Source file missing       → UNKNOWN → add_docs (safe default)
        """
        to_add, to_refresh, to_skip = [], [], []
        classifications = []

        print(_divider("🔍  CLASSIFYING FILES"))
        with _progress_bar(files, total=len(files), desc="classify", unit="file") as bar:
            for fname in bar:
                src = Path(base_path) / fname
                bar.set_postfix_str(fname[:40])

                if not src.exists():
                    classifications.append(FileClassification(
                        filename=fname,
                        status=FileStatus.UNKNOWN,
                        endpoint="add_docs",
                        reason="Source file not on disk — defaulting to add_docs",
                    ))
                    to_add.append(fname)
                    continue

                existing_chunks = sorted(
                    Path(chunks_dir).glob(f"{src.stem}_part*.txt")
                )

                if not existing_chunks:
                    classifications.append(FileClassification(
                        filename=fname,
                        status=FileStatus.NEW,
                        endpoint="add_docs",
                        reason="No chunks on disk — first upload",
                    ))
                    to_add.append(fname)
                else:
                    classifications.append(FileClassification(
                        filename=fname,
                        status=FileStatus.CHANGED,
                        endpoint="refresh_docs",
                        reason=f"Chunks exist on disk ({len(existing_chunks)}) — routing to refresh",
                    ))
                    to_refresh.append(fname)

        print(f"\n   NEW={len(to_add)}  CHANGED={len(to_refresh)}  UNCHANGED={len(to_skip)}")
        print(_divider())

        return SyncPlan(
            to_add=to_add,
            to_refresh=to_refresh,
            to_skip=to_skip,
            classifications=classifications,
        )

    # ── Public: upload ────────────────────────────────────────────────────────

    def add_documents(
        self,
        user_id: str,
        vector_lake_description: str,
        start_from_batch: int = 1,
        end_batch: Optional[int] = None,
        intelligent_segmentation: bool = True,
        session_id: Optional[str] = None,
        files: Optional[List[str]] = None,
        files_name: Optional[List[str]] = None,
        files_data: Optional[List[str]] = None,
    ) -> Dict[str, Any]:
        """
        Add NEW documents to the index.

        Server behaviour: rejects files that already exist in the namespace.
        Use sync_documents() when the folder contains a mix of new and
        previously-uploaded files.

        Modes
        ─────
        Direct : supply files_name + files_data
        Batch  : leave both None → reads all supported files from vector_lake_path
        """
        try:
            if files_name is not None and files_data is not None:
                print(_divider("▶  ADD_DOCUMENTS  (direct mode)"))
                result = self._direct_upload(
                    "add_docs", user_id, vector_lake_description,
                    files_name, files_data, intelligent_segmentation, session_id,
                )
                status = "✓  Done" if not result.get("error") else f"✗  {result.get('message', result.get('error'))}"
                print(f"   {status}")
                print(_divider())
                return result

            grand_total = self._compute_grand_total(self.config.vector_lake_path)
            return self._process_files_in_batches(
                "add_docs", user_id, vector_lake_description,
                start_from_batch, end_batch,
                intelligent_segmentation, session_id, files,
                grand_total_batches=grand_total,
            )
        except VectorLakeError as exc:
            return exc.to_response()
        except Exception as exc:
            return {"success": False, "error": type(exc).__name__, "message": str(exc)}

    def refresh_documents(
        self,
        user_id: str,
        vector_lake_description: str,
        start_from_batch: int = 1,
        end_batch: Optional[int] = None,
        intelligent_segmentation: bool = True,
        session_id: Optional[str] = None,
        files: Optional[List[str]] = None,
        files_name: Optional[List[str]] = None,
        files_data: Optional[List[str]] = None,
    ) -> Dict[str, Any]:
        """
        Refresh (update) EXISTING documents in the index.

        Server behaviour: rejects files that do not already exist.
        Use sync_documents() when the folder contains a mix of new and
        previously-uploaded files.

        Modes
        ─────
        Direct : supply files_name + files_data
        Batch  : leave both None → reads all supported files from vector_lake_path
        """
        try:
            if files_name is not None and files_data is not None:
                print(_divider("▶  REFRESH_DOCUMENTS  (direct mode)"))
                result = self._direct_upload(
                    "refresh_docs", user_id, vector_lake_description,
                    files_name, files_data, intelligent_segmentation, session_id,
                )
                status = "✓  Done" if not result.get("error") else f"✗  {result.get('message', result.get('error'))}"
                print(f"   {status}")
                print(_divider())
                return result

            grand_total = self._compute_grand_total(self.config.vector_lake_path)
            return self._process_files_in_batches(
                "refresh_docs", user_id, vector_lake_description,
                start_from_batch, end_batch,
                intelligent_segmentation, session_id, files,
                grand_total_batches=grand_total,
            )
        except VectorLakeError as exc:
            return exc.to_response()
        except Exception as exc:
            return {"success": False, "error": type(exc).__name__, "message": str(exc)}

    def sync_documents(
        self,
        user_id: str,
        vector_lake_description: str,
        start_from_batch: int = 1,
        end_batch: Optional[int] = None,
        intelligent_segmentation: bool = True,
        session_id: Optional[str] = None,
        files: Optional[List[str]] = None,
        dry_run: bool = False,
    ) -> Dict[str, Any]:
        """
        Intelligently sync a folder by routing each file to the correct endpoint.

        Classification (based on chunks already on disk)
        ────────────────────────────────────────────────
        No chunk on disk     → NEW     → add_docs
        Chunk(s) exist       → CHANGED → refresh_docs

        dry_run=True returns the classification plan without uploading anything.
        """
        try:
            base_path  = self.config.vector_lake_path
            chunks_dir = str(Path(base_path) / "chunks")
            Path(chunks_dir).mkdir(parents=True, exist_ok=True)

            if files is None:
                files = [
                    f for f in os.listdir(base_path)
                    if os.path.isfile(os.path.join(base_path, f))
                    and self._file_processor.is_supported(f)
                ]

            if not files:
                return {
                    "success": False,
                    "error":   "NoFilesError",
                    "message": "No supported files found in upload directory.",
                }

            grand_total = self._compute_grand_total(base_path)
            plan        = self._classify_files(files, base_path, chunks_dir)
            logger.info(
                "Sync plan — add: %d | refresh: %d | skip: %d",
                len(plan.to_add), len(plan.to_refresh), len(plan.to_skip),
            )

            if dry_run:
                print(_divider("■  DRY RUN COMPLETE — no files uploaded"))
                print(f"   NEW={len(plan.to_add)}  REFRESH={len(plan.to_refresh)}  SKIP={len(plan.to_skip)}")
                print(_divider())
                return {
                    "mode": "dry_run",
                    "plan": plan.summary(),
                    "classifications": [
                        {
                            "filename": c.filename,
                            "status":   c.status.value,
                            "endpoint": c.endpoint,
                            "reason":   c.reason,
                        }
                        for c in plan.classifications
                    ],
                }

            add_result = refresh_result = None

            if plan.to_add:
                add_result = self._process_files_in_batches(
                    "add_docs", user_id, vector_lake_description,
                    start_from_batch, end_batch,
                    intelligent_segmentation, session_id,
                    files=plan.to_add,
                    grand_total_batches=grand_total,
                )

            if plan.to_refresh:
                refresh_result = self._process_files_in_batches(
                    "refresh_docs", user_id, vector_lake_description,
                    start_from_batch, end_batch,
                    intelligent_segmentation, session_id,
                    files=plan.to_refresh,
                    grand_total_batches=grand_total,
                )

            added, refreshed, failed = [], [], {}

            def _collect(result, dest):
                if not result:
                    return
                for b in result.get("batches", []):
                    if b.get("success"):
                        dest.extend(b.get("files", []))
                    else:
                        for f in b.get("files", []):
                            failed[f] = str(b.get("error", "unknown error"))

            _collect(add_result, added)
            _collect(refresh_result, refreshed)

            print(_divider("■  SYNC COMPLETE"))
            print(f"   Added     : {len(added)}")
            print(f"   Refreshed : {len(refreshed)}")
            print(f"   Skipped   : {len(plan.to_skip)}")
            print(f"   Failed    : {len(failed)}")
            if failed:
                for fname, reason in failed.items():
                    print(f"     ✗ {fname}: {reason}")
            print(_divider())

            sync_result = SyncResult(
                added=added, refreshed=refreshed,
                skipped=plan.to_skip, failed=failed, plan=plan,
            )
            return {
                "mode":            "sync",
                **sync_result.to_dict(),
                "add_batches":     add_result,
                "refresh_batches": refresh_result,
            }

        except VectorLakeError as exc:
            return exc.to_response()
        except Exception as exc:
            return {"success": False, "error": type(exc).__name__, "message": str(exc)}

    def _direct_upload(
        self,
        operation: str,
        user_id: str,
        vector_lake_description: str,
        files_name: List[str],
        files_data: List[str],
        intelligent_segmentation: bool,
        session_id: Optional[str],
    ) -> Dict[str, Any]:
        if len(files_name) != len(files_data):
            return ValidationError(
                "files_name and files_data must have the same length"
            ).to_response()

        basenames  = [os.path.basename(n) for n in files_name]
        files_meta = [
            {"filename": b, "extension": Path(b).suffix.lstrip(".").lower()}
            for b in basenames
        ]

        payload = {
            "session_id":               session_id,
            "user_id":                  user_id,
            "vector_lake_description":  vector_lake_description,
            "files_name":               basenames,
            "files_data":               files_data,
            "files_meta":               files_meta,
            "intelligent_segmentation": intelligent_segmentation,
        }
        return self._make_request(
            self.config.endpoints[operation], payload, operation, batch_num=1
        )

    # ── Public: query ─────────────────────────────────────────────────────────

    def chat_with_docs(
        self,
        query: str,
        user_id: str,
        vector_lake_description: str,
        pattern: str = "static",
        session_id: Optional[str] = None,
        files_name: Optional[List[str]] = None,
        files_data: Optional[List[str]] = None,
    ) -> Dict[str, Any]:
        """Chat over the stored index (static) or temporary docs (dynamic)."""
        try:
            payload: Dict[str, Any] = {
                "session_id":              session_id,
                "user_id":                 user_id,
                "vector_lake_description": vector_lake_description,
                "query":                   query,
                "pattern":                 pattern,
            }
            if files_name and files_data:
                if len(files_name) != len(files_data):
                    return ValidationError(
                        "files_name and files_data must have the same length"
                    ).to_response()
                payload.update({
                    "files_name": [os.path.basename(n) for n in files_name],
                    "files_data": files_data,
                    "pattern":    "dynamic",
                })
            return self._make_request(
                self.config.endpoints["chat_with_docs"], payload, "chat_with_docs"
            )
        except VectorLakeError as exc:
            return exc.to_response()
        except Exception as exc:
            return {"success": False, "error": type(exc).__name__, "message": str(exc)}

    def get_matching_docs(
        self,
        query: str,
        user_id: str,
        vector_lake_description: str,
        pattern: str = "static",
        session_id: Optional[str] = None,
        hybrid_filter: bool = False,
        search_type: Optional[str] = None,
        top_docs: int = 10,
        threshold: float = 0.2,
        files_name: Optional[List[str]] = None,
        files_data: Optional[List[str]] = None,
        with_data: bool = False,
    ) -> Dict[str, Any]:
        """
        Retrieve top-matching document chunks.

        Parameters
        ----------
        hybrid_filter : bool — always required when using search_type.
            Applies keyword-based hybrid filter on the server side.

        search_type : "flat" | "flat_filter" | None
            "flat"        — semantic search across ALL documents; hybrid_filter
                            applied as scoring signal only, does not restrict scope.
            "flat_filter" — semantic search ONLY over documents that pass the
                            hybrid_filter; narrows candidates before ranking.
            None          — omitted from payload; server uses its default.
        """
        try:
            if search_type is not None and search_type not in _VALID_SEARCH_TYPES:
                return InvalidSearchTypeError(search_type).to_response()

            if search_type is not None and not hybrid_filter:
                return ValidationError(
                    f"hybrid_filter=True is required when search_type={search_type!r}."
                ).to_response()

            endpoint_key = (
                "top_matching_docs_with_data" if with_data else "top_matching_docs"
            )
            payload: Dict[str, Any] = {
                "session_id":              session_id,
                "user_id":                 user_id,
                "vector_lake_description": vector_lake_description,
                "query":                   query,
                "hybrid_filter":           hybrid_filter,
                "top_docs":                top_docs,
                "threshold":               threshold,
                "pattern":                 pattern,
            }
            if search_type is not None:
                payload["search_type"] = search_type

            if files_name and files_data:
                if len(files_name) != len(files_data):
                    return ValidationError(
                        "files_name and files_data must have the same length"
                    ).to_response()
                payload.update({
                    "files_name": [os.path.basename(n) for n in files_name],
                    "files_data": files_data,
                    "pattern":    "dynamic",
                })

            return self._make_request(
                self.config.endpoints[endpoint_key], payload, endpoint_key
            )
        except VectorLakeError as exc:
            return exc.to_response()
        except Exception as exc:
            return {"success": False, "error": type(exc).__name__, "message": str(exc)}

    # ── Public: info ──────────────────────────────────────────────────────────

    def health_check(
        self,
        user_id: str,
        vector_lake_description: str,
        session_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        try:
            payload = {
                "user_id":                 user_id,
                "vector_lake_description": vector_lake_description,
                "session_id":              session_id,
            }
            return self._make_request(self.config.endpoints["health"], payload, "health")
        except VectorLakeError as exc:
            return exc.to_response()
        except Exception as exc:
            return {"success": False, "error": type(exc).__name__, "message": str(exc)}

    def get_namespace_details(
        self,
        user_id: str,
        vector_lake_description: Optional[str] = None,
        session_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        try:
            payload: Dict[str, Any] = {"user_id": user_id, "session_id": session_id}
            if vector_lake_description:
                payload["vector_lake_description"] = vector_lake_description
            return self._make_request(
                self.config.endpoints["get_namespace_details_by_userid"],
                payload, "get_namespace_details",
            )
        except VectorLakeError as exc:
            return exc.to_response()
        except Exception as exc:
            return {"success": False, "error": type(exc).__name__, "message": str(exc)}

    def get_docs_information(
        self,
        user_id: str,
        vector_lake_description: str,
        session_id: Optional[str] = None,
        keyword: Optional[str] = None,
        threshold: int = 70,
    ) -> Dict[str, Any]:
        try:
            payload: Dict[str, Any] = {
                "session_id":              session_id,
                "user_id":                 user_id,
                "vector_lake_description": vector_lake_description,
                "threshold":               threshold,
            }
            if keyword:
                payload["keyword"] = keyword
            return self._make_request(
                self.config.endpoints["get_docs_information"], payload, "get_docs_information"
            )
        except VectorLakeError as exc:
            return exc.to_response()
        except Exception as exc:
            return {"success": False, "error": type(exc).__name__, "message": str(exc)}

    def full_corpus_search(
        self,
        user_id: str,
        vector_lake_description: str,
        keyword: str,
        session_id: Optional[str] = None,
        top_docs: int = 10,
    ) -> Dict[str, Any]:
        try:
            payload = {
                "session_id":              session_id,
                "user_id":                 user_id,
                "vector_lake_description": vector_lake_description,
                "keyword":                 keyword,
                "top_docs":                top_docs,
            }
            return self._make_request(
                self.config.endpoints["full_corpus_search"], payload, "full_corpus_search"
            )
        except VectorLakeError as exc:
            return exc.to_response()
        except Exception as exc:
            return {"success": False, "error": type(exc).__name__, "message": str(exc)}