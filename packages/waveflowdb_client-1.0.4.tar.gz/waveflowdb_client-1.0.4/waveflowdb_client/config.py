"""
config.py — SDK configuration, loaded from env / .env file or constructor args.
"""

import os
from pathlib import Path
from typing import Optional, Dict, Any

from .exceptions import ConfigError

# ── Try to load a .env file if python-dotenv is available ────────────────────
try:
    from dotenv import load_dotenv
    load_dotenv(dotenv_path=Path(".env"), override=False)
except ImportError:
    pass  # dotenv is optional; env vars can be set by the shell


def _env_list(key: str, default: str) -> list[str]:
    """Read a comma-separated env var into a cleaned list."""
    raw = os.getenv(key, default)
    return [x.strip().lower() for x in raw.split(",") if x.strip()]


def _env_int(key: str, default: int) -> int:
    try:
        return int(os.getenv(key, str(default)))
    except ValueError:
        return default


# Default extension list — overridden by VECTOR_LAKE_ALLOWED_EXTENSIONS in .env
_DEFAULT_EXTENSIONS = "txt,csv,json,jsonl,py,docx,pdf"


class Config:
    """
    All SDK settings in one place.

    Priority (highest → lowest):
      1. Constructor keyword arguments
      2. Environment variables / .env file
      3. Hard-coded defaults
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        host: Optional[str] = None,
        service_port: Optional[int] = None,
        timeout: Optional[int] = None,
        max_retries: Optional[int] = None,
        max_files_per_batch: Optional[int] = None,
        max_batch_size_mb: Optional[int] = None,
        vector_lake_path: Optional[str] = None,
        log_dir: Optional[str] = None,
        allowed_extensions: Optional[list[str]] = None,
    ):
        # ── Resolve every value (constructor > env > default) ────────────────
        self.api_key: Optional[str] = (
            api_key or os.getenv("VECTOR_LAKE_API_KEY")
        )
        self.host: str = (
            (host or os.getenv("VECTOR_LAKE_HOST", "https://waveflow-analytics.com"))
            .rstrip("/")
        )
        self.service_port: Optional[int] = (
            service_port
            if service_port is not None
            else (_env_int("VECTOR_LAKE_PORT", 0) or None)
        )
        self.timeout: int = timeout or _env_int("VECTOR_LAKE_TIMEOUT", 240)
        self.max_retries: int = max_retries or _env_int("VECTOR_LAKE_MAX_RETRIES", 2)
        self.max_files_per_batch: int = (
            max_files_per_batch
            or _env_int("VECTOR_LAKE_MAX_FILES_PER_BATCH", 100)
        )
        self.max_batch_size_mb: int = (
            max_batch_size_mb
            or _env_int("VECTOR_LAKE_MAX_BATCH_SIZE_MB", 0.5)
        )
        self.vector_lake_path: str = (
            vector_lake_path
            or os.getenv("VECTOR_LAKE_PATH", "upload")
        )
        self.log_dir: str = log_dir or os.getenv("VECTOR_LAKE_LOG_DIR", "logs")

        # ── Extension list — single source of truth ───────────────────────────
        self.allowed_extensions: list[str] = (
            allowed_extensions
            or _env_list("VECTOR_LAKE_ALLOWED_EXTENSIONS", _DEFAULT_EXTENSIONS)
        )

        # ── Validate ──────────────────────────────────────────────────────────
        if not self.api_key:
            raise ConfigError(
                "API key is required. Pass api_key= or set VECTOR_LAKE_API_KEY."
            )

        # ── Create required directories ───────────────────────────────────────
        Path(self.log_dir).mkdir(parents=True, exist_ok=True)
        Path(self.vector_lake_path).mkdir(parents=True, exist_ok=True)

    # ── URL helpers ───────────────────────────────────────────────────────────

    @property
    def base_url_query(self) -> str:
        if self.service_port:
            return f"{self.host}:{self.service_port}"
        return f"{self.host}/query"

    @property
    def base_url_upload(self) -> str:
        if self.service_port:
            return f"{self.host}:{self.service_port + 1}"
        return f"{self.host}/upload"

    # ── Endpoint map ──────────────────────────────────────────────────────────

    @property
    def endpoints(self) -> Dict[str, str]:
        q = self.base_url_query
        u = self.base_url_upload
        return {
            # Query service
            "chat_with_docs":               f"{q}/chat_with_docs",
            "top_matching_docs":            f"{q}/top_matching_docs",
            "top_matching_docs_with_data":  f"{q}/top_matching_docs_with_data",
            "full_corpus_search":           f"{q}/full_corpus_search",
            # Upload service
            "add_docs":                             f"{u}/add_docs",
            "refresh_docs":                         f"{u}/refresh_docs",
            "health":                               f"{u}/health",
            "get_namespace_details_by_userid":      f"{u}/get_namespace_details_by_userid",
            "get_docs_information":                 f"{u}/get_docs_information",
        }

    def __repr__(self) -> str:
        return (
            f"Config(host={self.host!r}, port={self.service_port}, "
            f"extensions={self.allowed_extensions})"
        )
