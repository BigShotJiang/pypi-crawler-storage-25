"""
waveflowdb_client — VectorLake Python SDK v2.0.0
"""

__version__ = "2.0.0"

from .client import VectorLakeClient
from .config import Config
from .exceptions import (
    VectorLakeError,
    ConfigError,
    ValidationError,
    InvalidSearchTypeError,
    FileProcessingError,
    UnsupportedFileTypeError,
    APIError,
    ThrottleError,
)
from .models import (
    DocumentInfo,
    ChatResponse,
    MatchingDocsResponse,
    HealthResponse,
    BatchResult,
    FileStatus,
    FileClassification,
    SyncPlan,
    SyncResult,
    VersionedChunkName,
)

__all__ = [
    "VectorLakeClient",
    "Config",
    "VectorLakeError",
    "ConfigError",
    "ValidationError",
    "InvalidSearchTypeError",
    "FileProcessingError",
    "UnsupportedFileTypeError",
    "APIError",
    "ThrottleError",
    "DocumentInfo",
    "ChatResponse",
    "MatchingDocsResponse",
    "HealthResponse",
    "BatchResult",
    "FileStatus",
    "FileClassification",
    "SyncPlan",
    "SyncResult",
    "VersionedChunkName",
]
