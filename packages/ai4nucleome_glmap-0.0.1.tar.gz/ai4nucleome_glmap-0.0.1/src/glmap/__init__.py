"""GLMap: Profiling genomic language models as individuals in a population.

This 0.0.1 release reserves the ``glmap`` name on PyPI. The full library —
including model loaders, scoring code, panel construction, and the
clip + double-center matrix pipeline — will be released as ``glmap >= 1.0.0``
together with the accompanying paper.

See https://github.com/ai4nucleome/GLMap for status updates.
"""

__version__ = "0.0.1"
