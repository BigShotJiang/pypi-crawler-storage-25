# GLMap

> **Placeholder release (v0.0.1).** The full v1.0.0 will be released together
> with the accompanying paper.

**GLMap** (Genomic Language Model Map) is a training-free, architecture-agnostic
framework for representing and comparing genomic language models (GLMs) by
their likelihood responses over a fixed panel of DNA sequences. Applied to 123
publicly available GLMs scored on a panel of 10,000 DNA probes, GLMap places
autoregressive and masked-language models in a common space, yields model
distances stable to the choice of probes, and predicts downstream task
performance with Spearman ρ ≈ 0.7.

## Status

This 0.0.1 release reserves the `glmap` name on PyPI. The full library —
including model loaders, scoring code, panel construction, and the
clip + double-center matrix pipeline — is in active preparation:

- [ ] Paper submitted
- [ ] Code repository public release
- [ ] PyPI v1.0.0

Track progress at <https://github.com/ai4nucleome/GLMap>.

## Citation

If you wish to cite GLMap before the v1.0.0 release, please cite the preprint:

```
Hou, Y., Long, W., Su, H., Feng, J., Zhang, Y.
Profiling genomic language models as individuals in a population.
(In submission, 2026.)
```

## License

Apache-2.0.
