"""maribox configuration management."""
