"""Shared utilities for browser-recon analyzers and report generators."""

from __future__ import annotations

from typing import Any
from urllib.parse import urlsplit

from browser_recon.models import CapturedRequest

# ---------------------------------------------------------------------------
# API request classification
# ---------------------------------------------------------------------------

API_RESOURCE_TYPES = {"XHR", "Fetch", "xhr", "fetch"}


def is_api_request(req: CapturedRequest) -> bool:
    """Check if a CapturedRequest is an API call (XHR/Fetch or JSON response)."""
    if req.resource_type in API_RESOURCE_TYPES:
        return True
    if req.mime_type and "json" in req.mime_type.lower():
        return True
    return False


# ---------------------------------------------------------------------------
# URL helpers
# ---------------------------------------------------------------------------


def base_url(url: str) -> str:
    """Strip query params to get a dedup key."""
    parts = urlsplit(url)
    return f"{parts.scheme}://{parts.netloc}{parts.path}"


# ---------------------------------------------------------------------------
# Report formatting helpers
# ---------------------------------------------------------------------------


def short_mime(mime: str) -> str:
    """Shorten MIME type for display (strip application/ or text/ prefix)."""
    if not mime:
        return ""
    for prefix in ("application/", "text/"):
        if mime.startswith(prefix):
            return mime[len(prefix) :]
    return mime


def yn(val: bool | None) -> str:
    """Return 'Y'/'Yes' or 'N'/'No' for a boolean value."""
    return "Y" if val else "N"


# ---------------------------------------------------------------------------
# Cookie classification helpers
# ---------------------------------------------------------------------------

# Google/YouTube set cookies named SID, SSID, HSID, LSID, SIDCC, etc.
# These are Google session cookies, not auth cookies for the target site.
GOOGLE_COOKIE_NAMES = frozenset(
    (
        "sid",
        "hsid",
        "ssid",
        "lsid",
        "apisid",
        "sapisid",
        "sidcc",
        "nid",
        "ogpc",
        "1p_jar",
    )
)

# Prefixes used by Google's partitioned cookies (__Secure-1P*, __Host-*, etc.)
GOOGLE_COOKIE_PREFIXES = (
    "__secure-1p",
    "__secure-3p",
    "__host-1p",
    "__host-3p",
)


def is_auth_cookie(cookie: dict[str, Any]) -> bool:
    """Check if a cookie is genuinely auth-related (not a Google default cookie)."""
    name = cookie.get("name", "").lower()
    if name in GOOGLE_COOKIE_NAMES:
        return False
    if any(name.startswith(p) for p in GOOGLE_COOKIE_PREFIXES):
        return False
    auth_patterns = (
        "session",
        "token",
        "auth",
        "jwt",
        "login",
        "access_token",
        "refresh_token",
    )
    return any(p in name for p in auth_patterns)


def is_antibot_cookie(cookie: dict[str, Any]) -> bool:
    """Check if a cookie is from an anti-bot service."""
    name = cookie.get("name", "").lower()
    bot_patterns = (
        "cf_",
        "__cf",
        "_cf_",
        "datadome",
        "incap_",
        "visid_",
        "reese84",
        "ak_bmsc",
        "bm_",
    )
    if any(name.startswith(p) or p in name for p in bot_patterns):
        return True
    # PerimeterX: cookies start with "px" or contain "_px"
    if name.startswith("px") or "_px" in name:
        return True
    return False
