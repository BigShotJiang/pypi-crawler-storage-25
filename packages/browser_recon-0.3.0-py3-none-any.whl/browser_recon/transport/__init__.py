"""Transport subpackage: uploader for scrubbed blobs."""
