"""Thin-CLI capture upload + scan-event polling (T53.7).

After capture finishes the thin CLI no longer runs validation,
scrubbing, or detection locally -- those moved server-side in
T53.2 / T53.3 / T53.4. This module owns the two HTTP calls that
remain:

* :func:`upload_capture` -- ``POST /scans/{scan_id}/capture`` with
  the raw (unscrubbed) capture envelope. Returns the polling
  endpoint URL the CLI hits to render live progress.
* :func:`fetch_scan_events` -- ``GET /scans/{scan_id}/events?since=...``
  one round of the polling loop. The CLI calls this on a 1.5 s
  cadence until the scan reaches a terminal status.

The error taxonomy reuses
:mod:`browser_recon.transport.uploader` -- the existing
``UploadAuthError`` / ``UploadServerError`` / ``UploadNetworkError``
classes already cover the failure modes we care about.
"""

from __future__ import annotations

import json
import logging
from dataclasses import dataclass
from typing import Any

import httpx

from browser_recon.transport.uploader import (
    UploadAuthError,
    UploadError,
    UploadNetworkError,
    UploadServerError,
    _classify_response,
)

logger = logging.getLogger(__name__)

__all__ = [
    "CaptureUploadResponse",
    "ScanEvent",
    "ScanEventsResponse",
    "fetch_scan_events",
    "upload_capture",
]

#: 60 seconds is generous for a 10 MB JSON blob over a typical
#: residential uplink. The server's BackgroundTasks queue dispatches
#: the heavy work; the request itself just lands the bytes in S3
#: and returns 202 within ~500 ms on the happy path.
_CAPTURE_UPLOAD_TIMEOUT = 60.0

#: Polling cadence has a 5 s connect + 10 s read budget. The route
#: handler is a single SELECT; anything past that points at a
#: networking blip we should retry, not a slow server.
_POLL_CONNECT_TIMEOUT = 5.0
_POLL_READ_TIMEOUT = 10.0


@dataclass(frozen=True)
class CaptureUploadResponse:
    """Body of ``POST /scans/{scan_id}/capture``.

    Mirrors the server's
    :class:`browser_recon_server.routes.scans.CaptureUploadResponse`
    by hand so the CLI doesn't import a server-side Pydantic model.
    """

    scan_id: str
    status: str
    events_url: str
    report_url: str


@dataclass(frozen=True)
class ScanEvent:
    """One ``scan_events`` row as the CLI sees it on the wire."""

    step: str
    status: str
    message: str
    metadata: dict[str, Any]
    created_at: str


@dataclass(frozen=True)
class ScanEventsResponse:
    """Body of ``GET /scans/{scan_id}/events``.

    ``cursor`` is opaque to the CLI: round-trip whatever the server
    sent on the previous poll back as ``since`` on the next one.
    """

    events: list[ScanEvent]
    cursor: str | None
    scan_status: str


def upload_capture(
    *,
    server_url: str,
    api_key: str,
    scan_id: str,
    target_url: str,
    intent_text: str,
    starter_template: str,
    capture: dict[str, Any],
    cli_version: str,
    transport: httpx.BaseTransport | None = None,
) -> CaptureUploadResponse:
    """POST ``/scans/{scan_id}/capture`` with the unscrubbed blob.

    The capture envelope MUST carry ``sanitised_capture`` (the raw
    pre-scrub dict; the server scrubs after validation) and
    ``primary_domain`` (eTLD+1). The server returns 202 + the
    polling URL the CLI uses to render the spinner.

    Raises one of the
    :class:`browser_recon.transport.uploader.UploadError` subclasses
    on failure; the CLI translates these to exit codes.
    """
    url = f"{server_url.rstrip('/')}/scans/{scan_id}/capture"
    body = {
        "target_url": target_url,
        "intent_text": intent_text,
        "starter_template": starter_template,
        "capture": capture,
    }
    headers = {
        "Accept": "application/json",
        "Content-Type": "application/json",
        "Authorization": f"Bearer {api_key}",
        "User-Agent": f"browser-recon/{cli_version}",
    }

    client_kwargs: dict[str, Any] = {}
    if transport is not None:
        client_kwargs["transport"] = transport
    with httpx.Client(**client_kwargs) as client:
        try:
            resp = client.post(
                url,
                json=body,
                headers=headers,
                timeout=_CAPTURE_UPLOAD_TIMEOUT,
            )
        except (httpx.TimeoutException, httpx.ConnectError) as exc:
            raise UploadNetworkError(f"could not reach {url}: {exc}") from exc

    err_cls = _classify_response(resp.status_code)
    if err_cls is not None:
        raise err_cls(f"{resp.status_code}: {resp.text}")

    try:
        data = resp.json()
    except (ValueError, json.JSONDecodeError) as exc:
        raise UploadServerError(f"non-JSON response: {resp.text!r}") from exc
    if not isinstance(data, dict):
        raise UploadServerError(f"unexpected response shape: {data!r}")

    try:
        return CaptureUploadResponse(
            scan_id=str(data["scan_id"]),
            status=str(data["status"]),
            events_url=str(data["events_url"]),
            report_url=str(data["report_url"]),
        )
    except KeyError as exc:
        raise UploadServerError(f"missing key in response: {exc}") from exc


def fetch_scan_events(
    *,
    server_url: str,
    api_key: str,
    scan_id: str,
    since: str | None = None,
    cli_version: str | None = None,
    transport: httpx.BaseTransport | None = None,
) -> ScanEventsResponse:
    """One round of ``GET /scans/{scan_id}/events?since=<cursor>``.

    Returns the parsed events + cursor + scan_status. Network errors
    surface as :class:`UploadNetworkError`; auth as
    :class:`UploadAuthError`; other 4xx/5xx as
    :class:`UploadServerError`. The polling loop catches and
    retries the network class; the rest are fatal.

    ``cli_version`` populates the ``User-Agent`` header so the server
    can log version distribution. Defaults to the installed package
    version when ``None``.
    """
    from browser_recon import __version__ as _pkg_version

    url = f"{server_url.rstrip('/')}/scans/{scan_id}/events"
    params: dict[str, str] = {}
    if since is not None:
        params["since"] = since
    headers = {
        "Accept": "application/json",
        "Authorization": f"Bearer {api_key}",
        "User-Agent": f"browser-recon/{cli_version or _pkg_version}",
    }

    client_kwargs: dict[str, Any] = {}
    if transport is not None:
        client_kwargs["transport"] = transport
    timeout = httpx.Timeout(
        connect=_POLL_CONNECT_TIMEOUT,
        read=_POLL_READ_TIMEOUT,
        write=_POLL_READ_TIMEOUT,
        pool=_POLL_READ_TIMEOUT,
    )
    with httpx.Client(**client_kwargs) as client:
        try:
            resp = client.get(
                url,
                params=params,
                headers=headers,
                timeout=timeout,
            )
        except (httpx.TimeoutException, httpx.ConnectError) as exc:
            raise UploadNetworkError(f"could not reach {url}: {exc}") from exc

    if resp.status_code == 401:
        raise UploadAuthError(f"401: {resp.text}")
    if resp.status_code >= 400:
        raise UploadServerError(f"{resp.status_code}: {resp.text}")

    try:
        data = resp.json()
    except (ValueError, json.JSONDecodeError) as exc:
        raise UploadServerError(f"non-JSON response: {resp.text!r}") from exc
    if not isinstance(data, dict):
        raise UploadServerError(f"unexpected response shape: {data!r}")

    raw_events = data.get("events") or []
    if not isinstance(raw_events, list):
        raise UploadServerError(f"events must be a list: {raw_events!r}")
    events: list[ScanEvent] = []
    for row in raw_events:
        if not isinstance(row, dict):
            continue
        events.append(
            ScanEvent(
                step=str(row.get("step", "")),
                status=str(row.get("status", "")),
                message=str(row.get("message", "") or ""),
                metadata=dict(row.get("metadata") or {}),
                created_at=str(row.get("created_at", "")),
            )
        )

    cursor_raw = data.get("cursor")
    cursor: str | None
    if cursor_raw is None:
        cursor = None
    else:
        cursor = str(cursor_raw)

    scan_status = str(data.get("scan_status", ""))
    if not scan_status:
        raise UploadServerError("response missing scan_status")

    # Reference unused symbols so future linters don't strip the
    # exception base import that callers re-raise.
    _ = UploadError
    return ScanEventsResponse(
        events=events,
        cursor=cursor,
        scan_status=scan_status,
    )
