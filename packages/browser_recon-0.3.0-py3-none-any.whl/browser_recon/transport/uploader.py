"""Upload a packaged blob to the server. Handles retries per the spec.

Spec: ``documentation/phase-1-privacy-transport-spec.md`` §
The Transport layer / uploader (~line 220).

Public API:

* :func:`upload_to_server` — POST the blob and return a
  :class:`ScansResponse` on success, or raise one of the
  :class:`UploadError` subclasses on failure.

Retry policy (one retry, then surface the failure):

* network timeout / connection refused — retry after 5 s
* 5xx — retry after 5 s
* 429 — retry after the ``Retry-After`` header value (seconds), or 5 s
* 401 / 402 / 413 / 422 — never retried; raised as typed errors
"""

from __future__ import annotations

import gzip
import hashlib
import json
import logging
import time
from collections.abc import Callable
from dataclasses import dataclass
from typing import Any

import httpx

logger = logging.getLogger(__name__)

__all__ = [
    "AccountSummary",
    "ClarifyState",
    "CompleteScanResponse",
    "DraftScanResponse",
    "FilterStatusResponse",
    "FilteredEndpoint",
    "FlowConfirmSummary",
    "RecommendedReplayEndpoint",
    "RefineIntentResponse",
    "ReplayCheckEntry",
    "ReplayCheckResponse",
    "ReplayUploadResponse",
    "ScanListItem",
    "ScanListResponse",
    "ScansResponse",
    "UploadAuthError",
    "UploadBlobMalformed",
    "UploadBlobTooLarge",
    "UploadError",
    "UploadNetworkError",
    "UploadQuotaExhausted",
    "UploadServerError",
    "ValidationUploadResponse",
    "complete_scan",
    "create_draft_scan",
    "fetch_account_summary",
    "fetch_filter_status",
    "fetch_replay_check",
    "fetch_scan_list",
    "poll_filter_status",
    "skip_intent",
    "start_intent_session",
    "submit_cancel_scan",
    "submit_intent_answer",
    "submit_refine_intent",
    "submit_replay",
    "submit_rerun_stage",
    "submit_validation",
    "upload_to_server",
]

_RETRY_DELAY_SECONDS = 5.0
_DEFAULT_TIMEOUT = 30.0


@dataclass(frozen=True)
class ScansResponse:
    """Decoded JSON response from POST /scans."""

    scan_id: str
    report_url: str
    tier_used: str
    scans_remaining_in_period: int
    warnings: list[str]


class UploadError(RuntimeError):
    """Base for all uploader errors."""


class UploadAuthError(UploadError):
    """401 - the API key was rejected."""


class UploadQuotaExhausted(UploadError):
    """402 - free tier exhausted."""

    def __init__(self, message: str, signup_url: str = "") -> None:
        super().__init__(message)
        self.signup_url = signup_url


class UploadBlobTooLarge(UploadError):
    """413 - the (uncompressed) blob exceeds the server's cap."""


class UploadBlobMalformed(UploadError):
    """422 - server rejected the blob shape."""


class UploadNetworkError(UploadError):
    """Network timeout / connection refused after the single retry."""


class UploadServerError(UploadError):
    """5xx (or persistent 429) after the single retry."""


def _gzip_blob(blob: dict[str, Any]) -> bytes:
    """Serialise the blob to canonical JSON and gzip-compress."""
    payload = json.dumps(blob, separators=(",", ":")).encode("utf-8")
    return gzip.compress(payload)


def _sha256(payload: bytes) -> str:
    return hashlib.sha256(payload).hexdigest()


def _classify_response(status_code: int) -> type[UploadError] | None:
    """Map a status code to the right exception type. Return None for 2xx."""
    if 200 <= status_code < 300:
        return None
    if status_code == 401:
        return UploadAuthError
    if status_code == 402:
        return UploadQuotaExhausted
    if status_code == 413:
        return UploadBlobTooLarge
    if status_code == 422:
        return UploadBlobMalformed
    if 500 <= status_code < 600:
        return UploadServerError
    if status_code == 429:
        # Caller handles 429 separately for retry; if we still see a 429
        # after retry, it was non-retriable.
        return UploadServerError
    return UploadServerError


def _attempt(
    *,
    client: httpx.Client,
    server_url: str,
    payload: bytes,
    headers: dict[str, str],
    timeout: float,
) -> httpx.Response:
    """Single POST /scans attempt. Caller wraps for retry."""
    return client.post(
        f"{server_url.rstrip('/')}/scans",
        content=payload,
        headers=headers,
        timeout=timeout,
    )


def _retry_after_seconds(resp: httpx.Response, fallback: float) -> float:
    """Read the ``Retry-After`` header (integer-seconds form) or fall back."""
    hdr = resp.headers.get("retry-after", "").strip()
    if hdr.isdigit():
        return float(hdr)
    return fallback


def upload_to_server(
    blob: dict[str, Any],
    *,
    server_url: str,
    api_key: str = "",
    client_id: str = "",
    cli_version: str = "",
    timeout: float = _DEFAULT_TIMEOUT,
    transport: httpx.BaseTransport | None = None,
) -> ScansResponse:
    """Upload ``blob`` to ``server_url`` and return the parsed response.

    Args:
        blob: the 12-key dict produced by
            :func:`browser_recon.scrubber.blob_packager.package_for_local_markdown`.
        server_url: server base URL (without trailing slash).
        api_key: optional Bearer credential. Empty means anonymous.
        client_id: stable per-install identifier (forwarded as
            ``X-Client-Id``).
        cli_version: forwarded as ``X-CLI-Version``.
        timeout: per-attempt HTTP timeout in seconds.
        transport: optional ``httpx`` transport (used by the unit tests
            to inject :class:`httpx.MockTransport`). Defaults to ``None``,
            i.e. real HTTP.

    Raises:
        UploadAuthError: 401.
        UploadQuotaExhausted: 402; ``signup_url`` attribute carries the
            link returned by the server when present.
        UploadBlobTooLarge: 413.
        UploadBlobMalformed: 422.
        UploadNetworkError: timeouts / connection refused after retry.
        UploadServerError: 5xx (or persistent 429) after retry.
    """
    payload = _gzip_blob(blob)
    sha = _sha256(payload)

    headers = {
        "Content-Type": "application/json",
        "Content-Encoding": "gzip",
        "X-Blob-Sha256": sha,
        "X-Client-Id": client_id,
        "X-CLI-Version": cli_version,
    }
    if api_key:
        headers["Authorization"] = f"Bearer {api_key}"

    client_kwargs: dict[str, Any] = {}
    if transport is not None:
        client_kwargs["transport"] = transport

    with httpx.Client(**client_kwargs) as client:
        # First attempt -- catch network-level failures and retry once.
        try:
            resp = _attempt(
                client=client,
                server_url=server_url,
                payload=payload,
                headers=headers,
                timeout=timeout,
            )
        except (httpx.TimeoutException, httpx.ConnectError) as exc:
            logger.warning(
                "upload network error on first attempt: %s; retrying in %s s",
                exc,
                _RETRY_DELAY_SECONDS,
            )
            time.sleep(_RETRY_DELAY_SECONDS)
            try:
                resp = _attempt(
                    client=client,
                    server_url=server_url,
                    payload=payload,
                    headers=headers,
                    timeout=timeout,
                )
            except (httpx.TimeoutException, httpx.ConnectError) as exc2:
                raise UploadNetworkError(
                    f"could not reach {server_url}: {exc2}"
                ) from exc2

        # Retry once on 5xx or 429.
        if resp.status_code >= 500 or resp.status_code == 429:
            wait = _RETRY_DELAY_SECONDS
            if resp.status_code == 429:
                wait = _retry_after_seconds(resp, _RETRY_DELAY_SECONDS)
            logger.warning(
                "upload got %d; retrying in %s s",
                resp.status_code,
                wait,
            )
            time.sleep(wait)
            try:
                resp = _attempt(
                    client=client,
                    server_url=server_url,
                    payload=payload,
                    headers=headers,
                    timeout=timeout,
                )
            except (httpx.TimeoutException, httpx.ConnectError) as exc:
                raise UploadNetworkError(
                    f"could not reach {server_url}: {exc}"
                ) from exc

    err_cls = _classify_response(resp.status_code)
    if err_cls is not None:
        if err_cls is UploadQuotaExhausted:
            signup = ""
            try:
                body = resp.json()
            except (ValueError, json.JSONDecodeError):
                body = None
            if isinstance(body, dict):
                signup_raw = body.get("signup_url", "")
                if isinstance(signup_raw, str):
                    signup = signup_raw
            raise UploadQuotaExhausted(resp.text, signup_url=signup)
        raise err_cls(f"{resp.status_code}: {resp.text}")

    data = resp.json()
    return ScansResponse(
        scan_id=str(data["scan_id"]),
        report_url=str(data["report_url"]),
        tier_used=str(data["tier_used"]),
        scans_remaining_in_period=int(data["scans_remaining_in_period"]),
        warnings=list(data.get("warnings", [])),
    )


# ---------------------------------------------------------------------------
# GET /scans (fix #9.A) -- fetch the user's scan list for ``recon list``
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class ScanListItem:
    """One row of ``GET /scans``. Mirrors the server-side Pydantic model.

    ``created_at`` / ``completed_at`` / ``expires_at`` are kept as the
    raw ISO-8601 strings the server returned; the CLI does its own
    formatting for the table view, and JSON pass-through preserves the
    on-the-wire shape verbatim.
    """

    report_id: str
    target_url: str
    target_domain: str
    tier_used: str
    status: str
    created_at: str
    completed_at: str | None
    expires_at: str | None


@dataclass(frozen=True)
class ScanListResponse:
    """Decoded JSON response from GET /scans."""

    scans: list[ScanListItem]
    total: int
    limit: int
    offset: int


def fetch_scan_list(
    *,
    server_url: str,
    api_key: str,
    limit: int = 50,
    offset: int = 0,
    timeout: float = _DEFAULT_TIMEOUT,
    transport: httpx.BaseTransport | None = None,
) -> ScanListResponse:
    """GET /scans on ``server_url`` and return the parsed response.

    Auth is mandatory: the server rejects missing / malformed Bearer
    tokens with 401, which we surface as :class:`UploadAuthError` so
    callers can map to the existing auth-error UX path.

    No retry policy on this endpoint -- it's a read-only call the user
    triggered interactively (``recon list``), so a single network
    failure short-circuits to :class:`UploadNetworkError` immediately
    rather than holding the terminal for 5 seconds.
    """
    headers = {
        "Accept": "application/json",
        "Authorization": f"Bearer {api_key}",
    }
    params: dict[str, str] = {"limit": str(limit), "offset": str(offset)}

    client_kwargs: dict[str, Any] = {}
    if transport is not None:
        client_kwargs["transport"] = transport

    url = f"{server_url.rstrip('/')}/scans"
    with httpx.Client(**client_kwargs) as client:
        try:
            resp = client.get(
                url,
                headers=headers,
                params=params,
                timeout=timeout,
            )
        except (httpx.TimeoutException, httpx.ConnectError) as exc:
            raise UploadNetworkError(f"could not reach {server_url}: {exc}") from exc

    err_cls = _classify_response(resp.status_code)
    if err_cls is not None:
        raise err_cls(f"{resp.status_code}: {resp.text}")

    data = resp.json()
    raw_scans = data.get("scans", [])
    items = [
        ScanListItem(
            report_id=str(row["report_id"]),
            target_url=str(row["target_url"]),
            target_domain=str(row["target_domain"]),
            tier_used=str(row["tier_used"]),
            status=str(row["status"]),
            created_at=str(row["created_at"]),
            completed_at=(
                str(row["completed_at"])
                if row.get("completed_at") is not None
                else None
            ),
            expires_at=(
                str(row["expires_at"]) if row.get("expires_at") is not None else None
            ),
        )
        for row in raw_scans
    ]
    return ScanListResponse(
        scans=items,
        total=int(data["total"]),
        limit=int(data["limit"]),
        offset=int(data["offset"]),
    )


# ---------------------------------------------------------------------------
# GET /auth/me (fix #9.A) -- credit-balance footer for ``recon list``
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class AccountSummary:
    """Decoded JSON response from GET /auth/me."""

    email: str
    tier: str
    scan_credits: int


def fetch_account_summary(
    *,
    server_url: str,
    api_key: str,
    timeout: float = _DEFAULT_TIMEOUT,
    transport: httpx.BaseTransport | None = None,
) -> AccountSummary:
    """GET /auth/me on ``server_url`` and return the parsed response.

    Used by ``recon list`` to render the "X credits remaining" footer.
    Same auth + error-mapping contract as :func:`fetch_scan_list`.
    """
    headers = {
        "Accept": "application/json",
        "Authorization": f"Bearer {api_key}",
    }
    client_kwargs: dict[str, Any] = {}
    if transport is not None:
        client_kwargs["transport"] = transport

    url = f"{server_url.rstrip('/')}/auth/me"
    with httpx.Client(**client_kwargs) as client:
        try:
            resp = client.get(url, headers=headers, timeout=timeout)
        except (httpx.TimeoutException, httpx.ConnectError) as exc:
            raise UploadNetworkError(f"could not reach {server_url}: {exc}") from exc

    err_cls = _classify_response(resp.status_code)
    if err_cls is not None:
        raise err_cls(f"{resp.status_code}: {resp.text}")

    data = resp.json()
    return AccountSummary(
        email=str(data["email"]),
        tier=str(data["tier"]),
        scan_credits=int(data["scan_credits"]),
    )


def fetch_scan_state(
    *,
    server_url: str,
    api_key: str,
    scan_id: str,
    timeout: float = _DEFAULT_TIMEOUT,
    transport: httpx.BaseTransport | None = None,
) -> ScanState:
    """GET /scans/{scan_id}/state. Used by ``recon scan --scan-id <id>``.

    Same auth + error-mapping contract as :func:`fetch_account_summary`.
    A 404 means the scan doesn't exist OR isn't owned by the
    authenticated user (we collapse 403 -> 404 server-side to avoid a
    cross-user existence oracle).
    """
    headers = {
        "Accept": "application/json",
        "Authorization": f"Bearer {api_key}",
    }
    client_kwargs: dict[str, Any] = {}
    if transport is not None:
        client_kwargs["transport"] = transport

    url = f"{server_url.rstrip('/')}/scans/{scan_id}/state"
    with httpx.Client(**client_kwargs) as client:
        try:
            resp = client.get(url, headers=headers, timeout=timeout)
        except (httpx.TimeoutException, httpx.ConnectError) as exc:
            raise UploadNetworkError(f"could not reach {server_url}: {exc}") from exc

    err_cls = _classify_response(resp.status_code)
    if err_cls is not None:
        raise err_cls(f"{resp.status_code}: {resp.text}")

    data = resp.json()
    return ScanState(
        scan_id=str(data["scan_id"]),
        status=str(data["status"]),
        target_url=str(data["target_url"]),
        target_domain=str(data["target_domain"]),
        intent_text=(
            str(data["intent_text"]) if data.get("intent_text") is not None else None
        ),
        starter_template=str(data["starter_template"]),
        has_captured_blob=bool(data["has_captured_blob"]),
    )


# ---------------------------------------------------------------------------
# Phase 2 (T4) intent-capture endpoints
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class DraftScanResponse:
    """Decoded JSON response from POST /scans/draft."""

    scan_id: str
    target_url: str
    target_domain: str
    status: str


@dataclass(frozen=True)
class ClarifyState:
    """Decoded JSON response from the three intent endpoints."""

    scan_id: str
    done: bool
    current_question: str | None
    inferred_data_kind: str
    rounds_used: int


@dataclass(frozen=True)
class ScanState:
    """Decoded JSON response from ``GET /scans/{id}/state``.

    Used by ``recon scan --scan-id <id>`` to hydrate the local CLI
    state from a dashboard-minted draft scan before launching Chrome.
    """

    scan_id: str
    status: str
    target_url: str
    target_domain: str
    intent_text: str | None
    starter_template: str
    has_captured_blob: bool


def _post_json(
    *,
    url: str,
    api_key: str,
    body: dict[str, Any] | None,
    timeout: float,
    transport: httpx.BaseTransport | None,
    extra_headers: dict[str, str] | None = None,
) -> dict[str, Any]:
    """Tiny wrapper around the four POST /scans intent endpoints."""
    from browser_recon import __version__ as _pkg_version

    headers = {
        "Accept": "application/json",
        "Authorization": f"Bearer {api_key}",
        "User-Agent": f"browser-recon/{_pkg_version}",
    }
    if body is not None:
        headers["Content-Type"] = "application/json"
    if extra_headers:
        headers.update(extra_headers)
    client_kwargs: dict[str, Any] = {}
    if transport is not None:
        client_kwargs["transport"] = transport
    with httpx.Client(**client_kwargs) as client:
        try:
            resp = client.post(
                url,
                json=body,
                headers=headers,
                timeout=timeout,
            )
        except (httpx.TimeoutException, httpx.ConnectError) as exc:
            raise UploadNetworkError(f"could not reach {url}: {exc}") from exc

    err_cls = _classify_response(resp.status_code)
    if err_cls is not None:
        if err_cls is UploadQuotaExhausted:
            signup = ""
            try:
                payload = resp.json()
            except (ValueError, json.JSONDecodeError):
                payload = None
            if isinstance(payload, dict):
                raw = payload.get("signup_url", "")
                if isinstance(raw, str):
                    signup = raw
            raise UploadQuotaExhausted(resp.text, signup_url=signup)
        raise err_cls(f"{resp.status_code}: {resp.text}")
    data = resp.json()
    if not isinstance(data, dict):
        raise UploadServerError(f"unexpected response shape: {data!r}")
    return data


#: Generous timeout for endpoints that trigger server-side LLM work
#: (filter on /complete, synthesis on /validation). Each call may
#: drive 5 parallel Anthropic prompts of ~5-30 s each; 120 s leaves
#: comfortable headroom while still failing fast on a genuinely-down
#: server.
_LLM_ENDPOINT_TIMEOUT = 120.0

#: Retry budget for endpoints that trigger LLM work AND span the
#: redeploy window. The CLI's local validation can take 5-15 minutes
#: against a slow site; if the operator pushes a commit during that
#: window, Render's auto-deploy gracefully restarts the container,
#: which kills the in-flight upload (CLI sees a timeout / connection
#: refused). One retry after a short backoff catches the post-deploy
#: window; we cap at 3 attempts to bound the worst case.
_LLM_ENDPOINT_RETRIES = 2  # i.e. 3 attempts total (initial + 2 retries)
_LLM_RETRY_BACKOFF_SECONDS: tuple[float, ...] = (5.0, 15.0)


def _post_json_with_retries(
    *,
    url: str,
    api_key: str,
    body: dict[str, Any] | None,
    timeout: float,
    transport: httpx.BaseTransport | None,
    extra_headers: dict[str, str] | None = None,
    sleep: Callable[[float], None] | None = None,
) -> dict[str, Any]:
    """``_post_json`` wrapper that retries on transient transport errors.

    Retries only for :class:`UploadNetworkError` (timeout / connection
    refused) and :class:`UploadServerError` (5xx). Auth, quota, and
    bad-request errors fail fast -- they're not retriable. The retry
    budget is :data:`_LLM_ENDPOINT_RETRIES` with the backoff schedule
    in :data:`_LLM_RETRY_BACKOFF_SECONDS`.

    Used by :func:`submit_validation` and :func:`complete_scan` so a
    redeploy mid-upload (or a one-off rate limit) doesn't lose the
    user's whole scan after they've already paid the credit + waited
    through capture + validation.

    ``sleep`` is resolved at call time (not as a captured default at
    import time) so tests can patch ``time.sleep`` via monkeypatch
    without having to thread the override through every caller.
    """
    if sleep is None:
        sleep = time.sleep
    last_error: UploadError | None = None
    for attempt in range(_LLM_ENDPOINT_RETRIES + 1):
        try:
            return _post_json(
                url=url,
                api_key=api_key,
                body=body,
                timeout=timeout,
                transport=transport,
                extra_headers=extra_headers,
            )
        except (UploadNetworkError, UploadServerError) as exc:
            last_error = exc
            if attempt >= _LLM_ENDPOINT_RETRIES:
                break
            backoff = _LLM_RETRY_BACKOFF_SECONDS[attempt]
            logger.warning(
                "upload to %s failed (%s); retrying in %.1fs (attempt %d/%d)",
                url,
                exc,
                backoff,
                attempt + 2,
                _LLM_ENDPOINT_RETRIES + 1,
            )
            sleep(backoff)
    assert last_error is not None  # the loop above raises or returns
    raise last_error


def create_draft_scan(
    *,
    server_url: str,
    api_key: str,
    target_url: str,
    primary_domain: str = "",
    client_id: str = "",
    cli_version: str = "",
    timeout: float = _DEFAULT_TIMEOUT,
    transport: httpx.BaseTransport | None = None,
) -> DraftScanResponse:
    """POST /scans/draft -- create a placeholder Scan row."""
    body: dict[str, Any] = {
        "target_url": target_url,
        "primary_domain": primary_domain or None,
        "client_id": client_id,
    }
    extra = {
        "X-Client-Id": client_id,
        "X-CLI-Version": cli_version,
    }
    data = _post_json(
        url=f"{server_url.rstrip(chr(47))}/scans/draft",
        api_key=api_key,
        body=body,
        timeout=timeout,
        transport=transport,
        extra_headers=extra,
    )
    return DraftScanResponse(
        scan_id=str(data["scan_id"]),
        target_url=str(data["target_url"]),
        target_domain=str(data["target_domain"]),
        status=str(data["status"]),
    )


def _parse_clarify(data: dict[str, Any]) -> ClarifyState:
    return ClarifyState(
        scan_id=str(data["scan_id"]),
        done=bool(data["done"]),
        current_question=(
            str(data["current_question"])
            if data.get("current_question") is not None
            else None
        ),
        inferred_data_kind=str(data["inferred_data_kind"]),
        rounds_used=int(data["rounds_used"]),
    )


def start_intent_session(
    *,
    server_url: str,
    api_key: str,
    scan_id: str,
    intent_text: str,
    starter_template: str,
    timeout: float = _DEFAULT_TIMEOUT,
    transport: httpx.BaseTransport | None = None,
) -> ClarifyState:
    """POST /scans/{scan_id}/intent -- start the clarifying loop."""
    data = _post_json(
        url=f"{server_url.rstrip(chr(47))}/scans/{scan_id}/intent",
        api_key=api_key,
        body={
            "intent_text": intent_text,
            "starter_template": starter_template,
        },
        timeout=timeout,
        transport=transport,
    )
    return _parse_clarify(data)


def submit_intent_answer(
    *,
    server_url: str,
    api_key: str,
    scan_id: str,
    answer: str,
    timeout: float = _DEFAULT_TIMEOUT,
    transport: httpx.BaseTransport | None = None,
) -> ClarifyState:
    """POST /scans/{scan_id}/intent/answer -- one round of the loop."""
    data = _post_json(
        url=f"{server_url.rstrip(chr(47))}/scans/{scan_id}/intent/answer",
        api_key=api_key,
        body={"answer": answer},
        timeout=timeout,
        transport=transport,
    )
    return _parse_clarify(data)


def skip_intent(
    *,
    server_url: str,
    api_key: str,
    scan_id: str,
    timeout: float = _DEFAULT_TIMEOUT,
    transport: httpx.BaseTransport | None = None,
) -> ClarifyState:
    """POST /scans/{scan_id}/intent/skip -- finalise immediately."""
    data = _post_json(
        url=f"{server_url.rstrip(chr(47))}/scans/{scan_id}/intent/skip",
        api_key=api_key,
        body=None,
        timeout=timeout,
        transport=transport,
    )
    return _parse_clarify(data)


@dataclass(frozen=True)
class FilteredEndpoint:
    """One Bucket A / B endpoint emitted by ``POST /scans/{id}/complete``.

    The CLI passes ``url`` strings to ``select_candidate_endpoints``'s
    ``endpoint_allowlist`` kwarg to scope round-2 validation to the
    server's filtered subset. The other fields are advisory and are
    forwarded verbatim into the validation step's progress UI.
    """

    url: str
    method: str
    response_type: str = ""
    response_summary: str = ""
    authentication: str = ""
    anti_bot_tier: int | None = None
    bucket: str = ""  # "A" | "B" | "unknown"


@dataclass(frozen=True)
class FlowConfirmSummary:
    """T9 / phase-2 § 5.4: post-capture confirmation summary from the server.

    The CLI / dashboard surfaces ``flow_summary`` to the user verbatim
    (max 3 sentences). ``confidence`` drives the D3 routing on
    mismatch:

    * ``confidence > 0.5`` -- D3.b path: offer the
      ``closest_match_intent`` as a one-click refine.
    * ``confidence <= 0.5`` -- D3.a path: offer re-record or generic
      report.

    All fields default to safe placeholder values so a malformed
    server response can't crash the CLI.
    """

    flow_summary: str = ""
    matches_intent: bool = True
    mismatch_reason: str | None = None
    closest_match_intent: str | None = None
    confidence: float = 0.0


@dataclass(frozen=True)
class CompleteScanResponse:
    """Decoded JSON response from POST /scans/{id}/complete (T8 + T9).

    T9 inserts a post-capture confirmation step BEFORE the filter:

    * ``status="awaiting_confirmation"`` -- ``flow_confirm`` is
      populated; ``filtered_endpoints`` is empty. The CLI shows the
      summary to the user and POSTs ``/refine-intent`` with one of
      the four actions.
    * ``status="awaiting_validation"`` -- legacy / fallback path: no
      LLM client / confirm prompt failed; the server ran the filter
      directly and ``filtered_endpoints`` is the Bucket A+B list.

    The CLI reads ``filtered_endpoints`` (when populated) to scope
    its validation pass via
    :func:`browser_recon.validation.select_candidate_endpoints`'s
    ``endpoint_allowlist`` kwarg.
    """

    scan_id: str
    status: str
    filtered_endpoints: list[FilteredEndpoint]
    tier_used: str
    scans_remaining_in_period: int
    warnings: list[str]
    flow_confirm: FlowConfirmSummary | None = None


@dataclass(frozen=True)
class RefineIntentResponse:
    """Decoded JSON response from POST /scans/{id}/refine-intent (T9).

    Mirrors :class:`CompleteScanResponse` so the CLI can reuse the
    same parser. ``filtered_endpoints`` is populated for the
    ``confirm`` / ``refine`` / ``generic`` actions; empty for
    ``rerecord``. ``status`` flips to ``"abandoned"`` for rerecord.
    """

    scan_id: str
    status: str
    filtered_endpoints: list[FilteredEndpoint]
    flow_confirm: FlowConfirmSummary | None = None


@dataclass(frozen=True)
class FilterStatusResponse:
    """Decoded JSON response from GET /scans/{id}/filter-status."""

    status: str  # "pending" | "ready" | "failed" | "complete"
    filtered_endpoints: list[FilteredEndpoint]
    error: str | None


@dataclass(frozen=True)
class RecommendedReplayEndpoint:
    """One Bucket A endpoint the CLI should fire during ground-truth replay.

    Mirrors the server-side ``RecommendedEndpointForReplay`` pydantic
    model on ``POST /scans/{id}/validation``. Carries the URL +
    method + the captured ``response_summary`` (T6) so the CLI's
    matcher has the shape descriptor to compare against.
    """

    url: str
    method: str
    response_summary: str = ""
    response_type: str = ""


@dataclass(frozen=True)
class ValidationUploadResponse:
    """Decoded JSON response from POST /scans/{id}/validation.

    The ``recommended_*`` fields are the T11 ground-truth replay
    payload. They default to empty for backward-compat with pre-T11
    server builds; the CLI treats empty fields as "no replay to run"
    and skips the replay step entirely.
    """

    scan_id: str
    status: str
    report_url: str
    recommended_library: str = ""
    recommended_headers: tuple[str, ...] = ()
    recommended_endpoints: tuple[RecommendedReplayEndpoint, ...] = ()


@dataclass(frozen=True)
class ReplayUploadResponse:
    """Decoded JSON response from POST /scans/{id}/replay (T11)."""

    scan_id: str
    replay_confidence: float
    matches: int
    total: int


def _parse_filtered_endpoint(raw: dict[str, Any]) -> FilteredEndpoint:
    """Read one ``FilteredEndpoint`` row from the wire format.

    Tolerates missing fields -- pre-T8 servers / partial responses
    populate only ``url`` + ``method``. Defensive defaults match the
    server-side Pydantic model so a successful round trip is shape-
    preserving.
    """
    anti_bot_raw = raw.get("anti_bot_tier")
    anti_bot_tier: int | None
    if isinstance(anti_bot_raw, int):
        anti_bot_tier = anti_bot_raw
    else:
        anti_bot_tier = None
    return FilteredEndpoint(
        url=str(raw.get("url") or ""),
        method=str(raw.get("method") or ""),
        response_type=str(raw.get("response_type") or ""),
        response_summary=str(raw.get("response_summary") or ""),
        authentication=str(raw.get("authentication") or ""),
        anti_bot_tier=anti_bot_tier,
        bucket=str(raw.get("bucket") or ""),
    )


def complete_scan(
    blob: dict[str, Any],
    *,
    server_url: str,
    api_key: str,
    scan_id: str,
    client_id: str = "",
    cli_version: str = "",
    timeout: float = _LLM_ENDPOINT_TIMEOUT,
    transport: httpx.BaseTransport | None = None,
) -> CompleteScanResponse:
    """POST /scans/{scan_id}/complete -- round 1 of T8 two-round validation.

    Attaches the captured blob to a draft scan, runs detection +
    analysis + intent_filter, and returns the Bucket A + B endpoint
    list so the CLI can scope its validation pass. Same retry policy
    + error types as :func:`upload_to_server`.

    The response shape changed in T8: pre-T8 callers expecting
    :class:`ScansResponse` get a :class:`CompleteScanResponse` now
    (``filtered_endpoints`` + ``status`` instead of a single
    ``report_url``). Round 2 (``submit_validation``) returns the
    actual report URL.
    """
    payload = _gzip_blob(blob)
    sha = _sha256(payload)

    headers = {
        "Content-Type": "application/json",
        "Content-Encoding": "gzip",
        "X-Blob-Sha256": sha,
        "X-Client-Id": client_id,
        "X-CLI-Version": cli_version,
        "Authorization": f"Bearer {api_key}",
    }

    client_kwargs: dict[str, Any] = {}
    if transport is not None:
        client_kwargs["transport"] = transport

    url = f"{server_url.rstrip(chr(47))}/scans/{scan_id}/complete"

    with httpx.Client(**client_kwargs) as client:
        try:
            resp = client.post(url, content=payload, headers=headers, timeout=timeout)
        except (httpx.TimeoutException, httpx.ConnectError):
            time.sleep(_RETRY_DELAY_SECONDS)
            try:
                resp = client.post(
                    url, content=payload, headers=headers, timeout=timeout
                )
            except (httpx.TimeoutException, httpx.ConnectError) as exc2:
                raise UploadNetworkError(
                    f"could not reach {server_url}: {exc2}"
                ) from exc2

        if resp.status_code >= 500 or resp.status_code == 429:
            wait = _RETRY_DELAY_SECONDS
            if resp.status_code == 429:
                wait = _retry_after_seconds(resp, _RETRY_DELAY_SECONDS)
            time.sleep(wait)
            try:
                resp = client.post(
                    url, content=payload, headers=headers, timeout=timeout
                )
            except (httpx.TimeoutException, httpx.ConnectError) as exc:
                raise UploadNetworkError(
                    f"could not reach {server_url}: {exc}"
                ) from exc

    err_cls = _classify_response(resp.status_code)
    if err_cls is not None:
        if err_cls is UploadQuotaExhausted:
            signup = ""
            try:
                body = resp.json()
            except (ValueError, json.JSONDecodeError):
                body = None
            if isinstance(body, dict):
                signup_raw = body.get("signup_url", "")
                if isinstance(signup_raw, str):
                    signup = signup_raw
            raise UploadQuotaExhausted(resp.text, signup_url=signup)
        raise err_cls(f"{resp.status_code}: {resp.text}")

    data = resp.json()
    raw_eps = data.get("filtered_endpoints", []) or []
    filtered = [_parse_filtered_endpoint(ep) for ep in raw_eps if isinstance(ep, dict)]
    return CompleteScanResponse(
        scan_id=str(data["scan_id"]),
        status=str(data.get("status") or "pending"),
        filtered_endpoints=filtered,
        tier_used=str(data["tier_used"]),
        scans_remaining_in_period=int(data["scans_remaining_in_period"]),
        warnings=list(data.get("warnings", [])),
        flow_confirm=_parse_flow_confirm(data.get("flow_confirm")),
    )


def _parse_flow_confirm(raw: Any) -> FlowConfirmSummary | None:
    """Parse the ``flow_confirm`` field of a /complete or /refine-intent
    response.

    Returns ``None`` when the server omitted the field (pre-T9 server
    builds, or a fallback path that ran the filter directly without
    flow_confirm). Otherwise returns a populated :class:`FlowConfirmSummary`
    with defensive defaults so a malformed payload can't crash the CLI.
    """
    if not isinstance(raw, dict):
        return None
    confidence = raw.get("confidence")
    try:
        confidence_f = float(confidence) if confidence is not None else 0.0
    except (TypeError, ValueError):
        confidence_f = 0.0
    return FlowConfirmSummary(
        flow_summary=str(raw.get("flow_summary") or ""),
        matches_intent=bool(raw.get("matches_intent", True)),
        mismatch_reason=(
            str(raw["mismatch_reason"])
            if raw.get("mismatch_reason") is not None
            else None
        ),
        closest_match_intent=(
            str(raw["closest_match_intent"])
            if raw.get("closest_match_intent") is not None
            else None
        ),
        confidence=confidence_f,
    )


def submit_refine_intent(
    *,
    server_url: str,
    api_key: str,
    scan_id: str,
    action: str,
    refined_intent: str | None = None,
    timeout: float = _DEFAULT_TIMEOUT,
    transport: httpx.BaseTransport | None = None,
) -> RefineIntentResponse:
    """POST /scans/{id}/refine-intent -- T9 post-capture confirmation.

    ``action`` is one of ``confirm`` / ``refine`` / ``rerecord`` /
    ``generic``. ``refined_intent`` is required + non-empty for
    ``refine`` and ignored for the other three.
    """
    body: dict[str, Any] = {"action": action}
    if refined_intent is not None:
        body["refined_intent"] = refined_intent
    data = _post_json(
        url=f"{server_url.rstrip(chr(47))}/scans/{scan_id}/refine-intent",
        api_key=api_key,
        body=body,
        timeout=timeout,
        transport=transport,
    )
    raw_eps = data.get("filtered_endpoints", []) or []
    filtered = [_parse_filtered_endpoint(ep) for ep in raw_eps if isinstance(ep, dict)]
    return RefineIntentResponse(
        scan_id=str(data["scan_id"]),
        status=str(data.get("status") or "pending"),
        filtered_endpoints=filtered,
        flow_confirm=_parse_flow_confirm(data.get("flow_confirm")),
    )


# ---------------------------------------------------------------------------
# T8 / phase-2 § 5.7: filter-status polling + round-2 validation upload
# ---------------------------------------------------------------------------


_FILTER_POLL_INTERVAL_SECONDS = 2.0
_FILTER_POLL_TIMEOUT_SECONDS = 60.0


def fetch_filter_status(
    *,
    server_url: str,
    api_key: str,
    scan_id: str,
    timeout: float = _DEFAULT_TIMEOUT,
    transport: httpx.BaseTransport | None = None,
) -> FilterStatusResponse:
    """GET /scans/{id}/filter-status -- single poll attempt.

    Returns the current filter result. The caller (typically
    :func:`poll_filter_status`) loops on this until the status flips
    to ``ready`` / ``complete`` / ``failed`` or the timeout elapses.

    Network / server errors raise the same typed exceptions as the
    other transport helpers; the polling wrapper translates a
    persistent failure into a degrade-gracefully fallback.
    """
    headers = {
        "Accept": "application/json",
        "Authorization": f"Bearer {api_key}",
    }
    client_kwargs: dict[str, Any] = {}
    if transport is not None:
        client_kwargs["transport"] = transport

    url = f"{server_url.rstrip(chr(47))}/scans/{scan_id}/filter-status"
    with httpx.Client(**client_kwargs) as client:
        try:
            resp = client.get(url, headers=headers, timeout=timeout)
        except (httpx.TimeoutException, httpx.ConnectError) as exc:
            raise UploadNetworkError(f"could not reach {server_url}: {exc}") from exc

    err_cls = _classify_response(resp.status_code)
    if err_cls is not None:
        raise err_cls(f"{resp.status_code}: {resp.text}")

    data = resp.json()
    raw_eps = data.get("filtered_endpoints", []) or []
    filtered = [_parse_filtered_endpoint(ep) for ep in raw_eps if isinstance(ep, dict)]
    error_raw = data.get("error")
    return FilterStatusResponse(
        status=str(data.get("status") or "pending"),
        filtered_endpoints=filtered,
        error=str(error_raw) if isinstance(error_raw, str) else None,
    )


def poll_filter_status(
    *,
    server_url: str,
    api_key: str,
    scan_id: str,
    interval_seconds: float = _FILTER_POLL_INTERVAL_SECONDS,
    timeout_seconds: float = _FILTER_POLL_TIMEOUT_SECONDS,
    sleep: Any = time.sleep,
    now: Any = time.monotonic,
    request_timeout: float = _DEFAULT_TIMEOUT,
    transport: httpx.BaseTransport | None = None,
) -> FilterStatusResponse:
    """Poll ``GET /filter-status`` until the filter resolves or times out.

    Returns the final :class:`FilterStatusResponse`. Per phase-2 §
    5.7 we cap at 60 seconds and poll every 2 seconds. ``sleep`` and
    ``now`` are injected so unit tests can drive the loop without
    real time.

    On a transient network failure the loop keeps polling -- the
    server may have restarted mid-filter. A persistent failure that
    spans the entire 60s window collapses to a synthesised ``"failed"``
    response so the caller can degrade gracefully (per spec § 5.7
    "longer than 60s falls back to the v0.1.0 inventory report").
    """
    deadline = now() + timeout_seconds
    last_status: FilterStatusResponse | None = None
    last_error: str | None = None

    while True:
        status_resp: FilterStatusResponse | None
        try:
            status_resp = fetch_filter_status(
                server_url=server_url,
                api_key=api_key,
                scan_id=scan_id,
                timeout=request_timeout,
                transport=transport,
            )
        except UploadAuthError:
            # Auth errors are terminal -- looping will not fix them.
            raise
        except (UploadNetworkError, UploadServerError) as exc:
            last_error = str(exc)
            logger.debug("filter-status poll failed: %s", exc)
            status_resp = None
        if status_resp is not None:
            last_status = status_resp
            if status_resp.status in {"ready", "failed", "complete"}:
                return status_resp

        if now() >= deadline:
            error_str = (
                last_error
                if last_error is not None
                else "filter did not finish within the polling window"
            )
            if last_status is not None:
                return FilterStatusResponse(
                    status="failed",
                    filtered_endpoints=last_status.filtered_endpoints,
                    error=error_str,
                )
            return FilterStatusResponse(
                status="failed",
                filtered_endpoints=[],
                error=error_str,
            )

        sleep(interval_seconds)


def submit_validation(
    *,
    server_url: str,
    api_key: str,
    scan_id: str,
    validation_result: dict[str, Any] | None,
    timeout: float = _LLM_ENDPOINT_TIMEOUT,
    transport: httpx.BaseTransport | None = None,
) -> ValidationUploadResponse:
    """POST /scans/{id}/validation -- round 2 of T8 two-round validation.

    Hands the validation JSON to the server, which stitches it into
    ``Report.findings`` and runs the synthesis prompts. Returns the
    final report URL on success.

    ``validation_result`` is the dict-shaped
    :class:`browser_recon.models.ValidationResult` produced by
    :func:`browser_recon.validation.validate` (after :func:`asdict`).
    Pass ``None`` when the CLI couldn't validate (filter failed +
    --no-validation interaction); the server still runs synthesis but
    without a validation block.

    This endpoint triggers server-side synthesis (5 parallel Anthropic
    prompts) so the default timeout is bumped to
    :data:`_LLM_ENDPOINT_TIMEOUT` (120 s) and transport-level errors
    are retried per :data:`_LLM_ENDPOINT_RETRIES` -- this is the
    upload that runs longest after the user has already paid the
    credit, so losing it to a redeploy collision or a transient
    network blip is the worst-case UX failure.
    """
    body: dict[str, Any] = {"validation_result": validation_result}
    data = _post_json_with_retries(
        url=f"{server_url.rstrip(chr(47))}/scans/{scan_id}/validation",
        api_key=api_key,
        body=body,
        timeout=timeout,
        transport=transport,
    )

    # T11: extract the recommendation payload so the CLI can run
    # ground-truth replay. Tolerate missing fields for back-compat with
    # pre-T11 server builds (defaults to empty -> CLI skips replay).
    rec_endpoints_raw = data.get("recommended_endpoints") or []
    rec_endpoints: list[RecommendedReplayEndpoint] = []
    if isinstance(rec_endpoints_raw, list):
        for entry in rec_endpoints_raw:
            if not isinstance(entry, dict):
                continue
            rec_endpoints.append(
                RecommendedReplayEndpoint(
                    url=str(entry.get("url") or ""),
                    method=str(entry.get("method") or ""),
                    response_summary=str(entry.get("response_summary") or ""),
                    response_type=str(entry.get("response_type") or ""),
                )
            )

    rec_headers_raw = data.get("recommended_headers") or []
    rec_headers: tuple[str, ...]
    if isinstance(rec_headers_raw, list):
        rec_headers = tuple(str(h) for h in rec_headers_raw if isinstance(h, str))
    else:
        rec_headers = ()

    rec_library_raw = data.get("recommended_library")
    rec_library = str(rec_library_raw) if isinstance(rec_library_raw, str) else ""

    return ValidationUploadResponse(
        scan_id=str(data["scan_id"]),
        status=str(data.get("status") or "complete"),
        report_url=str(data["report_url"]),
        recommended_library=rec_library,
        recommended_headers=rec_headers,
        recommended_endpoints=tuple(rec_endpoints),
    )


@dataclass
class ReplayCheckEntry:
    """One per-host rate-limit verdict returned by ``GET /scans/{id}/replay-check``.

    Mirrors the wire shape on the server side
    (``browser_recon_server.routes.scans.ReplayCheckEntry``) so the CLI
    can decode the response without re-encoding the field names.
    """

    host: str
    should_skip: bool
    last_confidence: float | None
    last_replay_age_seconds: int | None
    note: str | None


@dataclass
class ReplayCheckResponse:
    """Body of ``GET /scans/{id}/replay-check`` (T27.3)."""

    cooldown_seconds: int
    entries: list[ReplayCheckEntry]


def fetch_replay_check(
    *,
    server_url: str,
    api_key: str,
    scan_id: str,
    hosts: list[str],
    timeout: float = _LLM_ENDPOINT_TIMEOUT,
    transport: httpx.BaseTransport | None = None,
) -> ReplayCheckResponse:
    """GET /scans/{id}/replay-check?host=... -- T27.3 rate-limit probe.

    Asks the server whether replay against each host should be skipped
    because it was hit within the configured cooldown window. The
    server returns the cached confidence value for any skipped host so
    the CLI can reuse it without firing the live call.

    Empty / malformed responses degrade gracefully -- we return an
    empty entries list and the replay engine falls back to its default
    "fire everything" behaviour. The check is informational; the
    server-side ``upload_replay`` endpoint also writes
    ``replay_history`` regardless.
    """
    if not hosts:
        return ReplayCheckResponse(cooldown_seconds=60, entries=[])
    base = f"{server_url.rstrip(chr(47))}/scans/{scan_id}/replay-check"
    # ``httpx.QueryParams`` accepts ``list[tuple[str, Any]]`` but mypy's
    # stub is narrowly typed; the explicit wrap keeps both happy and is
    # the documented "repeat the key" form for ?host=a&host=b.
    params = httpx.QueryParams([("host", h) for h in hosts if h])
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Accept": "application/json",
    }
    try:
        if transport is not None:
            with httpx.Client(transport=transport, timeout=timeout) as client:
                resp = client.get(base, params=params, headers=headers)
        else:
            with httpx.Client(timeout=timeout) as client:
                resp = client.get(base, params=params, headers=headers)
    except httpx.HTTPError:
        # Best-effort probe: a network blip here just means the CLI
        # fires the replay it would have fired pre-T27.3. Don't blow
        # up the scan.
        return ReplayCheckResponse(cooldown_seconds=60, entries=[])
    if resp.status_code != 200:
        return ReplayCheckResponse(cooldown_seconds=60, entries=[])
    try:
        data = resp.json()
    except ValueError:
        return ReplayCheckResponse(cooldown_seconds=60, entries=[])
    cooldown = int(data.get("cooldown_seconds") or 60)
    raw_entries = data.get("entries") or []
    entries: list[ReplayCheckEntry] = []
    if isinstance(raw_entries, list):
        for raw in raw_entries:
            if not isinstance(raw, dict):
                continue
            entries.append(
                ReplayCheckEntry(
                    host=str(raw.get("host") or ""),
                    should_skip=bool(raw.get("should_skip", False)),
                    last_confidence=(
                        float(raw["last_confidence"])
                        if raw.get("last_confidence") is not None
                        else None
                    ),
                    last_replay_age_seconds=(
                        int(raw["last_replay_age_seconds"])
                        if raw.get("last_replay_age_seconds") is not None
                        else None
                    ),
                    note=raw.get("note"),
                )
            )
    return ReplayCheckResponse(cooldown_seconds=cooldown, entries=entries)


def submit_cancel_scan(
    *,
    server_url: str,
    api_key: str,
    scan_id: str,
    timeout: float = _LLM_ENDPOINT_TIMEOUT,
    transport: httpx.BaseTransport | None = None,
) -> bool:
    """POST /scans/{id}/cancel -- T27.4 synthesis cancellation.

    Best-effort: a network failure here returns ``False`` (the user
    still gets the Ctrl+C effect locally; the server-side flag just
    doesn't flip). Returns ``True`` on a 200 response. Idempotent on
    the server side; a second call doesn't double-refund or double-log.
    """
    url = f"{server_url.rstrip(chr(47))}/scans/{scan_id}/cancel"
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Accept": "application/json",
    }
    try:
        if transport is not None:
            with httpx.Client(transport=transport, timeout=timeout) as client:
                resp = client.post(url, headers=headers)
        else:
            with httpx.Client(timeout=timeout) as client:
                resp = client.post(url, headers=headers)
    except httpx.HTTPError:
        return False
    return resp.status_code == 200


def submit_replay(
    *,
    server_url: str,
    api_key: str,
    scan_id: str,
    matches: int,
    total: int,
    confidence: float,
    per_endpoint: list[dict[str, Any]],
    timeout: float = _LLM_ENDPOINT_TIMEOUT,
    transport: httpx.BaseTransport | None = None,
) -> ReplayUploadResponse:
    """POST /scans/{id}/replay -- T11 ground-truth replay upload.

    Persists the CLI's per-endpoint replay outcome on the scan so the
    report renderer can surface a low-confidence banner when
    ``confidence < 0.5``. Idempotent on the server side: a second call
    overwrites the first row's values, which lets a future
    ``recon replay <scan-id>`` command re-run the live calls and update
    the dashboard without duplicating rows.

    Network failure on this call does not invalidate the report -- the
    replay is informational only. The CLI swallows errors here and
    proceeds to open the report.

    Uses the same retry helper as ``submit_validation`` / ``complete_scan``
    so a Render redeploy mid-upload (or a one-off 502 from the edge)
    doesn't lose the replay confidence the user is going to see in the
    report. Live observation: target.com scan at IST 19:46 hit a 502
    on this exact endpoint with the v0.1.0 default timeout + no retries.
    """
    body: dict[str, Any] = {
        "matches": int(matches),
        "total": int(total),
        "confidence": float(confidence),
        "per_endpoint": list(per_endpoint),
    }
    data = _post_json_with_retries(
        url=f"{server_url.rstrip(chr(47))}/scans/{scan_id}/replay",
        api_key=api_key,
        body=body,
        timeout=timeout,
        transport=transport,
    )
    return ReplayUploadResponse(
        scan_id=str(data["scan_id"]),
        replay_confidence=float(data["replay_confidence"]),
        matches=int(data["matches"]),
        total=int(data["total"]),
    )


# ---------------------------------------------------------------------------
# T18 / phase-2.5: per-section rerun (FREE for the user).
# ---------------------------------------------------------------------------


@dataclass
class RerunPromptResponse:
    """Body of ``POST /scans/{id}/rerun-prompt`` (T18).

    Mirrors :class:`browser_recon_server.routes.scans.RerunPromptResponse`
    so the CLI can decode it with the same shape the dashboard JS uses.
    """

    scan_id: str
    prompt_name: str
    section: dict[str, Any]
    rerun_count: int
    rerun_count_cap: int


def submit_rerun_prompt(
    *,
    server_url: str,
    api_key: str,
    scan_id: str,
    prompt_name: str,
    timeout: float = _LLM_ENDPOINT_TIMEOUT,
    transport: httpx.BaseTransport | None = None,
) -> RerunPromptResponse:
    """POST /scans/{id}/rerun-prompt -- T18 free per-section retry.

    The server re-runs the named prompt against the persisted
    detection / analysis / validation state and persists the new
    output to ``Report.synthesis``. Cost is borne by the operator; the
    server enforces a 3-rerun-per-section cap so a buggy CLI loop can
    not drain LLM credit.

    Uses the same retry helper as :func:`submit_validation` -- a brief
    network blip mid-rerun shouldn't make the user re-issue the
    command (each call is mid-cost: one Sonnet 4.6 call) when the
    actual server-side state is fine.

    Maps server-side errors onto the existing typed exceptions:

    * 401 -> :class:`UploadAuthError`
    * 410 -> :class:`UploadServerError` (capture state gone)
    * 429 -> :class:`UploadServerError` (rate limit; the message
      string carries the cap)
    * 502 -> :class:`UploadServerError` (LLM call failed upstream)
    """
    body = {"prompt_name": prompt_name}
    data = _post_json_with_retries(
        url=f"{server_url.rstrip(chr(47))}/scans/{scan_id}/rerun-prompt",
        api_key=api_key,
        body=body,
        timeout=timeout,
        transport=transport,
    )
    section_raw = data.get("section")
    section: dict[str, Any] = section_raw if isinstance(section_raw, dict) else {}
    return RerunPromptResponse(
        scan_id=str(data.get("scan_id") or scan_id),
        prompt_name=str(data.get("prompt_name") or prompt_name),
        section=section,
        rerun_count=int(data.get("rerun_count") or 0),
        rerun_count_cap=int(data.get("rerun_count_cap") or 0),
    )


# ---------------------------------------------------------------------------
# T24 / Phase 2.6+: stage-level rerun (filter / synthesis / full).
# ---------------------------------------------------------------------------


@dataclass
class RerunStageResponse:
    """Body of ``POST /scans/{id}/rerun-stage`` (T24).

    Mirrors :class:`browser_recon_server.routes.scans.RerunStageResponse`.

    * ``stage`` -- the stage that was re-run (``filter`` / ``synthesis``
      / ``full``).
    * ``new_scan_id`` -- the freshly-minted child scan's UUID; only
      populated on ``stage == "full"``. The CLI can chain a
      ``recon list`` or open the dashboard / debug page off this id.
    """

    scan_id: str
    stage: str
    status: str
    rerun_count: int
    rerun_count_cap: int
    new_scan_id: str | None = None


def submit_rerun_stage(
    *,
    server_url: str,
    api_key: str,
    scan_id: str,
    stage: str,
    timeout: float = _LLM_ENDPOINT_TIMEOUT,
    transport: httpx.BaseTransport | None = None,
) -> RerunStageResponse:
    """POST /scans/{id}/rerun-stage -- T24 stage-level retry.

    Three stages are accepted:

    * ``"filter"`` -- re-runs T7 intent-filter; cascades to synthesis.
      FREE.
    * ``"synthesis"`` -- re-runs the synthesis stage. FREE.
    * ``"full"`` -- mints a new scan with ``parent_scan_id`` linkage
      from the existing capture; runs filter + synthesis fresh. Costs
      one credit.

    Maps server-side errors onto the existing typed exceptions:

    * 401 -> :class:`UploadAuthError`
    * 402 -> :class:`UploadQuotaExhausted` (``full`` stage only)
    * 410 -> :class:`UploadServerError` (capture state gone)
    * 429 -> :class:`UploadServerError` (rate limit; message carries
      the cap)
    * 502 -> :class:`UploadServerError` (LLM call failed upstream)
    """
    body = {"stage": stage}
    data = _post_json_with_retries(
        url=f"{server_url.rstrip(chr(47))}/scans/{scan_id}/rerun-stage",
        api_key=api_key,
        body=body,
        timeout=timeout,
        transport=transport,
    )
    new_scan_id_raw = data.get("new_scan_id")
    new_scan_id = str(new_scan_id_raw) if isinstance(new_scan_id_raw, str) else None
    return RerunStageResponse(
        scan_id=str(data.get("scan_id") or scan_id),
        stage=str(data.get("stage") or stage),
        status=str(data.get("status") or "ok"),
        rerun_count=int(data.get("rerun_count") or 0),
        rerun_count_cap=int(data.get("rerun_count_cap") or 0),
        new_scan_id=new_scan_id,
    )
