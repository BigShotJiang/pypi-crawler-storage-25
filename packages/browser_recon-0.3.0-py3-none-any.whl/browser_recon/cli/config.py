"""Config loading for the recon CLI.

Search order: ``--config`` flag, ``RECON_CONFIG`` env var, platform default
(``~/.browser-recon/config.toml`` on Unix, ``%APPDATA%\\browser-recon\\
config.toml`` on Windows), built-in defaults. Uses stdlib ``tomllib``
(Python 3.11+) -- ``tomli`` is in ``pyproject.toml`` only as historical
backfill and is not imported here.

The expected config-file layout::

    [server]
    url = "https://api.recon.app"

    [auth]
    api_key = "rec_live_..."

    [defaults]
    mode = "quick"
    output_dir = "./browser-recon-output"
    open_after_scan = true

Missing sections / keys fall back to the dataclass defaults declared
below. The :func:`init_config` helper writes a minimal ``[server]`` +
``[auth]`` config back to disk -- used by ``recon login`` to persist a
freshly-validated API key.
"""

from __future__ import annotations

import os
import platform
import tomllib
from dataclasses import dataclass
from pathlib import Path

# Module-level constants so that the dataclass field defaults and the
# ``load_config`` fallbacks share a single source of truth.
_DEFAULT_SERVER_URL = "https://api.recon.app"
_DEFAULT_API_KEY = ""
_DEFAULT_MODE = "quick"
_DEFAULT_OUTPUT_DIR = "./browser-recon-output"
_DEFAULT_OPEN_AFTER_SCAN = True


@dataclass
class Config:
    """Resolved configuration. All fields have defaults."""

    server_url: str = _DEFAULT_SERVER_URL
    api_key: str = _DEFAULT_API_KEY
    mode: str = _DEFAULT_MODE
    output_dir: str = _DEFAULT_OUTPUT_DIR
    open_after_scan: bool = _DEFAULT_OPEN_AFTER_SCAN
    # Path the config was loaded from (``None`` if defaults-only).
    source_path: Path | None = None


def default_config_path() -> Path:
    """Return the platform-default config path. Does NOT check existence."""
    if platform.system() == "Windows":
        appdata = os.environ.get("APPDATA")
        if appdata:
            return Path(appdata) / "browser-recon" / "config.toml"
        # Fallback if APPDATA is not set (rare; CI environments).
        return Path.home() / "AppData" / "Roaming" / "browser-recon" / "config.toml"
    return Path.home() / ".browser-recon" / "config.toml"


def _resolve_config_path(path: Path | str | None) -> Path | None:
    """Resolve which config path to load from, in priority order.

    Returns the first candidate path (existence not checked here for
    explicit overrides -- the caller decides whether a missing override
    is a hard error). The platform-default path is only returned when
    it actually exists.
    """
    # 1. Explicit --config flag.
    if path is not None:
        return Path(path).expanduser()

    # 2. RECON_CONFIG env var.
    env_path = os.environ.get("RECON_CONFIG")
    if env_path:
        return Path(env_path).expanduser()

    # 3. Platform default (only if it exists).
    default = default_config_path()
    if default.exists():
        return default

    return None


def load_config(path: Path | str | None = None) -> Config:
    """Load config from the resolved path; fall back to defaults if missing.

    The ``--config`` flag and ``RECON_CONFIG`` env var, when set, are
    honored even if the file doesn't exist (this raises
    ``FileNotFoundError`` so misconfiguration is loud rather than silent).
    A missing platform-default file is *not* an error -- defaults are
    returned silently.

    Args:
        path: explicit override. Takes priority over ``RECON_CONFIG`` and
            the platform default. If provided and the file doesn't exist,
            raises ``FileNotFoundError``.
    """
    config_path = _resolve_config_path(path)

    if config_path is None:
        return Config()

    if not config_path.exists():
        # Loud failure for explicit overrides -- quiet for platform default.
        if path is not None or os.environ.get("RECON_CONFIG"):
            raise FileNotFoundError(f"Config file not found: {config_path}")
        return Config()

    with config_path.open("rb") as fh:
        data = tomllib.load(fh)

    server = data.get("server", {})
    auth = data.get("auth", {})
    defaults = data.get("defaults", {})

    return Config(
        server_url=server.get("url", _DEFAULT_SERVER_URL),
        api_key=auth.get("api_key", _DEFAULT_API_KEY),
        mode=defaults.get("mode", _DEFAULT_MODE),
        output_dir=defaults.get("output_dir", _DEFAULT_OUTPUT_DIR),
        open_after_scan=defaults.get("open_after_scan", _DEFAULT_OPEN_AFTER_SCAN),
        source_path=config_path,
    )


def _toml_quote(value: str) -> str:
    """Render ``value`` as a TOML basic string.

    The fields we write (server URL, API key) are ASCII and never
    contain quotes / backslashes / control chars. We still escape
    backslash + double-quote defensively so a future caller can't
    silently emit invalid TOML.
    """
    escaped = value.replace("\\", "\\\\").replace('"', '\\"')
    return f'"{escaped}"'


def init_config(
    path: Path | str | None = None,
    *,
    server_url: str,
    api_key: str,
) -> Path:
    """Write a minimal ``config.toml`` for ``recon login``.

    Creates the parent directory if missing. The file is written with
    ``0o600`` perms (owner read/write only) so the API key is not
    world-readable on shared systems. The same perms are re-applied on
    overwrite, since the previous file may have been more permissive.

    Only the ``[server]`` and ``[auth]`` sections are written. The
    ``[defaults]`` section is intentionally omitted -- ``load_config``
    falls back to the dataclass defaults for any missing keys.

    Args:
        path: explicit destination; defaults to :func:`default_config_path`.
        server_url: the API server's base URL. Trailing slashes are
            stripped to keep ``urljoin`` paths tidy.
        api_key: the raw ``rec_live_...`` key returned by ``/auth/callback``.

    Returns:
        The :class:`Path` actually written.
    """
    target = Path(path).expanduser() if path is not None else default_config_path()
    target.parent.mkdir(parents=True, exist_ok=True)

    body = (
        "[server]\n"
        f"url = {_toml_quote(server_url.rstrip('/'))}\n"
        "\n"
        "[auth]\n"
        f"api_key = {_toml_quote(api_key.strip())}\n"
    )
    target.write_text(body, encoding="utf-8")
    target.chmod(0o600)
    return target
