"""Live progress polling for the thin-CLI scan flow (T53.7).

After the CLI uploads the raw capture via
:func:`browser_recon.transport.capture_upload.upload_capture`, the
server runs its 8-step pipeline (capture / detection / analysis /
intent_filter / validation / scrub / synthesis / render) and writes
one ``scan_events`` row per transition. This module owns the poll
loop that drives the live spinner the user sees while that happens.

Two rendering modes:

* **Live spinner** (default): :class:`rich.live.Live` redraws a
  multi-line table every poll. Running steps show an animated
  braille spinner; complete steps show a check; pending steps stay
  dim. Mirrors the Claude Code tool-call display.
* **Plain text** (``--no-progress`` or non-TTY stdout): one line
  printed per step transition. CI-safe, no terminal control bytes.

The polling cadence is 1.5 s. Transient network failures (timeout /
connection refused) are retried in place; three consecutive
failures kill the loop with a clear error. Auth or non-network
server errors are fatal on the first occurrence.
"""

from __future__ import annotations

import logging
import sys
import time
from typing import IO, Any

from rich.console import Console
from rich.live import Live
from rich.spinner import Spinner
from rich.table import Table
from rich.text import Text

from browser_recon.transport.capture_upload import (
    ScanEvent,
    ScanEventsResponse,
    fetch_scan_events,
)
from browser_recon.transport.uploader import (
    UploadAuthError,
    UploadNetworkError,
    UploadServerError,
)

logger = logging.getLogger(__name__)

__all__ = [
    "PIPELINE_STEPS",
    "PollOutcome",
    "StepRow",
    "poll_scan_events",
    "render_steps_table",
]

#: Pipeline step order. Mirrors
#: :mod:`browser_recon_server.pipeline_orchestrator`; the CLI shows
#: all eight rows from the first paint so the user immediately sees
#: the full shape of the run.
PIPELINE_STEPS: tuple[str, ...] = (
    "capture",
    "detection",
    "analysis",
    "intent_filter",
    "validation",
    "scrub",
    "synthesis",
    "render",
)

#: Terminal scan statuses. The loop stops as soon as the server
#: surfaces one of these.
_TERMINAL_STATUSES: frozenset[str] = frozenset({"complete", "failed"})

#: How long to wait between polls. 1.5 s is the spec target -- long
#: enough that a chatty pipeline doesn't drown the server, short
#: enough that the spinner stays responsive.
_POLL_INTERVAL_SECONDS = 1.5

#: How many consecutive network failures the loop tolerates before
#: giving up. Three rounds at 1.5 s each gives the server ~5 s to
#: recover from a transient blip; past that we want a hard failure
#: rather than an infinite "trying...".
_MAX_CONSECUTIVE_FAILURES = 3


class StepRow:
    """One row of the live spinner table.

    Holds the step's current status (``pending`` / ``running`` /
    ``complete`` / ``errored``) plus the latest human-readable
    message. The rendering layer reads ``status`` to choose between
    the spinner / check / X glyph; ``message`` is whatever the
    server's ``emit_event`` last said.
    """

    __slots__ = ("message", "status", "step")

    def __init__(self, step: str) -> None:
        self.step = step
        self.status = "pending"
        self.message = ""

    def apply(self, event: ScanEvent) -> None:
        """Update this row from a single ``ScanEvent``.

        We track three event-statuses: ``started`` (-> running),
        ``complete`` (-> complete), ``errored`` (-> errored). Unknown
        statuses are folded into ``running`` so a future server-side
        addition doesn't silently freeze the row.
        """
        ev_status = event.status
        if ev_status == "started":
            self.status = "running"
        elif ev_status == "complete":
            self.status = "complete"
        elif ev_status == "errored":
            self.status = "errored"
        else:
            self.status = "running"
        if event.message:
            self.message = event.message


class PollOutcome:
    """Result of :func:`poll_scan_events`.

    ``terminal_status`` is the final ``scan_status`` value the server
    reported -- either ``"complete"`` or ``"failed"``. ``rows``
    carries the last-known state of every step so the caller can
    fish out the failing step's message for the exit-1 summary.
    ``failed_step`` is the name of the step whose ``errored`` event
    flipped the scan to ``failed``; ``None`` when the loop exited
    cleanly.
    """

    __slots__ = ("failed_step", "rows", "terminal_status")

    def __init__(
        self,
        *,
        terminal_status: str,
        rows: dict[str, StepRow],
        failed_step: str | None,
    ) -> None:
        self.terminal_status = terminal_status
        self.rows = rows
        self.failed_step = failed_step


def _initial_rows() -> dict[str, StepRow]:
    """Seed one :class:`StepRow` per pipeline step, all ``pending``."""
    return {step: StepRow(step) for step in PIPELINE_STEPS}


def _apply_events(rows: dict[str, StepRow], events: list[ScanEvent]) -> str | None:
    """Fold each event into its row; return the first errored step name.

    Events arrive oldest-first per the server's
    ``ORDER BY created_at ASC`` cursor contract, so iterating in
    order produces the correct final state for each row.
    """
    failed: str | None = None
    for event in events:
        row = rows.get(event.step)
        if row is None:
            # Unknown step name -- log it but don't break the loop.
            # A future server-side stage rename would land here.
            logger.debug("ignoring unknown step %r", event.step)
            continue
        row.apply(event)
        if event.status == "errored" and failed is None:
            failed = event.step
    return failed


def render_steps_table(rows: dict[str, StepRow]) -> Table:
    """Render the current step rows as a borderless 3-column table.

    Column 1 is the glyph (spinner / check / X / dim circle);
    column 2 is the step name; column 3 is the latest message.
    The rich :class:`~rich.live.Live` redraws this table on every
    poll so the spinner advances visibly.
    """
    table = Table.grid(padding=(0, 1), expand=False)
    table.add_column(width=2, no_wrap=True)
    table.add_column(min_width=14, no_wrap=True)
    table.add_column(overflow="fold")

    for step in PIPELINE_STEPS:
        row = rows[step]
        glyph: Any
        name_style = "white"
        message_style = "white"
        if row.status == "complete":
            glyph = Text("✓", style="bold green")
        elif row.status == "errored":
            glyph = Text("✗", style="bold red")
            message_style = "red"
        elif row.status == "running":
            glyph = Spinner("dots", style="cyan")
        else:
            glyph = Text(" ", style="dim")
            name_style = "dim"
            message_style = "dim"

        message = row.message or ("pending" if row.status == "pending" else "")
        table.add_row(
            glyph,
            Text(step, style=name_style),
            Text(message, style=message_style),
        )
    return table


def _plain_status_glyph(status: str) -> str:
    """One-char text glyph for the plaintext renderer."""
    return {
        "complete": "[done]",
        "errored": "[fail]",
        "running": "[run] ",
        "pending": "[wait]",
    }.get(status, "[??]  ")


def _print_plain_transition(stream: IO[str], event: ScanEvent) -> None:
    """Print a single-line summary of an event for CI / non-TTY use."""
    glyph = _plain_status_glyph(
        {"started": "running", "complete": "complete", "errored": "errored"}.get(
            event.status, "running"
        )
    )
    line = f"{glyph} {event.step:<14} {event.message or event.status}"
    stream.write(line + "\n")
    stream.flush()


def poll_scan_events(
    *,
    server_url: str,
    api_key: str,
    scan_id: str,
    cli_version: str | None = None,
    no_progress: bool = False,
    stream: IO[str] | None = None,
    transport: Any | None = None,
    sleep: Any = time.sleep,
    fetcher: Any = None,
    poll_interval_seconds: float = _POLL_INTERVAL_SECONDS,
) -> PollOutcome:
    """Poll ``/scans/{scan_id}/events`` until the scan finishes.

    Args:
        server_url: server base URL.
        api_key: bearer token.
        scan_id: the scan to poll.
        no_progress: when True, render plain-text per-step lines
            instead of the live rich spinner. Auto-True when
            ``stream.isatty()`` returns False.
        stream: where progress lands. Defaults to ``sys.stdout``.
        transport: optional httpx test transport; threaded into
            :func:`fetch_scan_events`.
        sleep: hook for the inter-poll sleep so tests can run the
            loop without real wallclock delay.
        fetcher: hook for the events fetch. Defaults to
            :func:`fetch_scan_events`. Tests pass a stub that yields
            canned :class:`ScanEventsResponse` instances.
        poll_interval_seconds: cadence between polls.

    Returns:
        :class:`PollOutcome` describing the terminal state.

    Raises:
        UploadAuthError: 401 from the events endpoint (the CLI
            translates this to ``EXIT_AUTH_ERROR``).
        UploadServerError: non-network 4xx/5xx, OR three consecutive
            network failures (the loop gives up).
    """
    if stream is None:
        stream = sys.stdout
    if fetcher is None:
        fetcher = fetch_scan_events

    if not no_progress:
        is_tty = bool(getattr(stream, "isatty", lambda: False)())
        if not is_tty:
            no_progress = True

    rows = _initial_rows()
    cursor: str | None = None
    failed_step: str | None = None
    seen_event_keys: set[tuple[str, str, str]] = set()
    consecutive_failures = 0

    console: Console | None = None
    live: Live | None = None
    if not no_progress:
        # Bind the rich Console to the same stream so a caller that
        # routed stdout to a StringIO (tests, scripts) still gets the
        # rendered output -- rich's default would write to its own
        # global console otherwise.
        console = Console(file=stream, force_terminal=True)
        live = Live(
            render_steps_table(rows),
            console=console,
            refresh_per_second=10,
            transient=False,
        )
        live.start()

    try:
        while True:
            try:
                response: ScanEventsResponse = fetcher(
                    server_url=server_url,
                    api_key=api_key,
                    scan_id=scan_id,
                    since=cursor,
                    cli_version=cli_version,
                    transport=transport,
                )
            except UploadAuthError:
                # Fatal -- bubble up unchanged so the caller's
                # exit-code mapper gets the right error class.
                raise
            except UploadNetworkError as exc:
                consecutive_failures += 1
                logger.debug(
                    "events poll failed (%d/%d): %s",
                    consecutive_failures,
                    _MAX_CONSECUTIVE_FAILURES,
                    exc,
                )
                if consecutive_failures >= _MAX_CONSECUTIVE_FAILURES:
                    raise UploadServerError(
                        f"three consecutive poll failures: {exc}"
                    ) from exc
                sleep(poll_interval_seconds)
                continue
            except UploadServerError:
                # Non-network server failure (auth shape, 5xx after
                # the request itself succeeded): hand back to caller.
                raise

            consecutive_failures = 0

            # The cursor advances independently of whether we saw new
            # events; the server returns it on every poll.
            cursor = response.cursor

            new_events: list[ScanEvent] = []
            for event in response.events:
                key = (event.step, event.status, event.created_at)
                if key in seen_event_keys:
                    continue
                seen_event_keys.add(key)
                new_events.append(event)

            failure = _apply_events(rows, new_events)
            if failure is not None and failed_step is None:
                failed_step = failure

            if no_progress:
                for event in new_events:
                    _print_plain_transition(stream, event)
            elif live is not None:
                live.update(render_steps_table(rows))

            if response.scan_status in _TERMINAL_STATUSES:
                return PollOutcome(
                    terminal_status=response.scan_status,
                    rows=rows,
                    failed_step=failed_step,
                )

            sleep(poll_interval_seconds)
    finally:
        if live is not None:
            live.stop()
