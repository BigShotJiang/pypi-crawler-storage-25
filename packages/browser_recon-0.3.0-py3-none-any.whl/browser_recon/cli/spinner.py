"""CLI spinner / in-place status line (task T37).

Replaces the firehose ``XHR/Fetch:`` per-request log + the per-validation
sub-step log with a single in-place status line that rewrites itself via
``\r``. Permanent events (clicks, anti-bot detections, errors,
per-endpoint validation summaries) still drop to their own line and
stay; only the noisy progress counter is collapsed into the spinner.

Design notes:

* The braille frame set ``⣾⣽⣻⢿⡿⣟⣯⣷`` is the Claude Code spinner; it
  reads as motion at the ~80-100ms update cadence we get from the CDP
  request stream and the validation phase callbacks.
* ``isatty()`` gates everything: when stdout is piped to a file / CI log
  the in-place updates would scribble control characters into the
  artefact, so we fall back to a one-line-per-change log. The fallback
  also de-duplicates identical consecutive updates so the validation
  sub-steps don't write the same line twice.
* No external deps. ``rich`` / ``tqdm`` would bring transitive bloat the
  rest of the CLI doesn't need and they each have their own opinions
  about terminal control that fight with the rest of our log lines.

The class is deliberately small and synchronous. The CDP monitor and
validation orchestrator drive it via callback methods; the CLI owns the
single instance for the duration of the scan and tears it down at the
end of each phase via :meth:`CliSpinner.finish`.
"""

from __future__ import annotations

import sys
from typing import Any

__all__ = ["BRAILLE_FRAMES", "CliSpinner", "NullSpinner"]

#: Claude Code spinner frames -- order matters, the sequence is what
#: produces the "rotating dot" illusion at update cadence.
BRAILLE_FRAMES: tuple[str, ...] = (
    "⣾",  # ⣾
    "⣽",  # ⣽
    "⣻",  # ⣻
    "⢿",  # ⢿
    "⡿",  # ⡿
    "⣟",  # ⣟
    "⣯",  # ⣯
    "⣷",  # ⣷
)

# ANSI "erase to end of line" sequence. We always emit it after ``\r`` so
# a previous longer line (e.g. "Captured 999 requests · last: …") doesn't
# leave trailing characters behind a shorter one ("Captured 1000 …").
_CLEAR_TO_EOL = "\033[K"


class CliSpinner:
    """A tiny, stdlib-only spinner that rewrites a single output line.

    Three operations:

    * :meth:`update` -- advances the spinner frame and rewrites the
      current line in place. No newline.
    * :meth:`permanent_line` -- writes a line that stays (cleans the
      spinner line first, then re-prints the spinner below).
    * :meth:`finish` -- erases the spinner line and optionally commits a
      final status message in its place.

    The constructor reads ``stream.isatty()`` once and caches it; if the
    stream is not a TTY (piped / CI / redirected) the class downgrades
    to one-line-per-update mode that's safe for log files.
    """

    def __init__(
        self,
        stream: Any = None,
        frames: tuple[str, ...] = BRAILLE_FRAMES,
    ) -> None:
        self.stream = stream if stream is not None else sys.stdout
        self.frames = frames
        self.frame_idx = 0
        self.last_text = ""
        isatty = getattr(self.stream, "isatty", None)
        # The double-getattr dance keeps us safe against test doubles
        # that only stub ``write`` / ``flush``.
        self.enabled = bool(isatty()) if callable(isatty) else False

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def update(self, text: str) -> None:
        """Update the spinner line in place.

        On a TTY: rewrites the current line with ``\r`` + clear-to-EOL
        + a fresh frame + ``text``. On non-TTY: writes one newline-
        terminated line per change (suppresses consecutive duplicates so
        the validation sub-steps don't double-log into CI artifacts).
        """
        if not self.enabled:
            if text != self.last_text:
                self.stream.write(text + "\n")
                self.stream.flush()
            self.last_text = text
            return
        frame = self.frames[self.frame_idx % len(self.frames)]
        self.frame_idx += 1
        self.stream.write("\r" + _CLEAR_TO_EOL + "[" + frame + "] " + text)
        self.stream.flush()
        self.last_text = text

    def permanent_line(self, text: str) -> None:
        """Write a line that stays above the spinner.

        On a TTY: clears the spinner's line, writes ``text`` + newline,
        then re-prints the spinner with its current ``last_text`` so the
        progress counter keeps living below the permanent message. On
        non-TTY: just writes the line.
        """
        if not self.enabled:
            self.stream.write(text + "\n")
            self.stream.flush()
            return
        self.stream.write("\r" + _CLEAR_TO_EOL + text + "\n")
        self.stream.flush()
        if self.last_text:
            # Re-print the spinner below the permanent line. We re-use
            # ``update`` so the frame advances; the cadence stays sane
            # because the next genuine ``update`` arrives within
            # ~milliseconds in practice.
            self.update(self.last_text)

    def finish(self, final_text: str | None = None) -> None:
        """Erase the spinner line and optionally commit a final message.

        ``final_text`` lands as a stand-alone newline-terminated line in
        place of the spinner. Pass ``None`` (the default) when the
        caller plans to print its own follow-up output via
        :func:`print` -- this just clears the in-place line so the
        cursor is back at the start of a fresh row.
        """
        if not self.enabled:
            # In non-TTY mode we never wrote a "live" line we need to
            # erase; just emit ``final_text`` if it was supplied.
            if final_text:
                self.stream.write(final_text + "\n")
                self.stream.flush()
            self.last_text = ""
            return
        self.stream.write("\r" + _CLEAR_TO_EOL)
        if final_text:
            self.stream.write(final_text + "\n")
        self.stream.flush()
        self.last_text = ""


class NullSpinner:
    """No-op spinner used when ``--quiet`` or ``--verbose`` is set.

    ``--quiet`` suppresses progress reporting entirely; ``--verbose``
    falls back to the firehose log path (every captured request as a
    separate INFO line), so the spinner would compete with the existing
    log output. In both cases the orchestration code wants something
    that exposes the same surface but does nothing.
    """

    enabled: bool = False

    def update(self, text: str) -> None:  # noqa: D401 -- no-op
        return None

    def permanent_line(self, text: str) -> None:  # noqa: D401 -- no-op
        return None

    def finish(self, final_text: str | None = None) -> None:  # noqa: D401
        return None
