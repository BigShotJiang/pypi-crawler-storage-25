"""Entry point for the ``recon`` console script.

Thin-CLI flow (T53.7): the CLI mints a draft scan, captures the
user's browser session via Chrome+CDP, uploads the **raw**
(unscrubbed) capture to ``POST /scans/{id}/capture``, then polls
``GET /scans/{id}/events`` while the server runs the
detection / analysis / intent_filter / validation / scrub /
synthesis / render pipeline. The hosted URL is the canonical
report; no local Markdown is produced.

Subcommands:

* ``recon scan <url>`` -- run the full pipeline against ``<url>``.
* ``recon stop`` -- write a ``.stop`` sentinel into the output directory
  so an in-progress capture exits at its next checkpoint.
* ``recon version`` -- print the package version.

Auth contract: every ``recon scan`` invocation requires an API key.
The CLI resolves it from ``--api-key`` > config > environment, and
exits with :data:`EXIT_AUTH_ERROR` immediately if none is found --
before launching Chrome or doing any other work.

Per ``documentation/phase-1-cli-spec.md`` § Error handling, errors
are mapped to distinct non-zero exit codes (2-9) so callers and CI
scripts can distinguish them.
"""

from __future__ import annotations

import argparse
import dataclasses
import json
import logging
import os
import sys
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from browser_recon import __version__
from browser_recon.capture import start_capture
from browser_recon.capture.chrome_launcher import (
    ChromeLaunchError,
    ChromeNotFoundError,
    PortInUseError,
)
from browser_recon.cli._url_helpers import extract_etld_plus_one
from browser_recon.cli.config import Config, load_config
from browser_recon.cli.login import add_login_subparser, cmd_login
from browser_recon.cli.poll import poll_scan_events
from browser_recon.cli.report_opener import open_in_browser
from browser_recon.transport.capture_upload import (
    CaptureUploadResponse,
    upload_capture,
)
from browser_recon.transport.uploader import (
    ClarifyState,
    UploadAuthError,
    UploadBlobMalformed,
    UploadBlobTooLarge,
    UploadError,
    UploadNetworkError,
    UploadQuotaExhausted,
    UploadServerError,
    create_draft_scan,
    fetch_account_summary,
    fetch_scan_list,
    fetch_scan_state,
    skip_intent,
    start_intent_session,
    submit_intent_answer,
    submit_rerun_prompt,
    submit_rerun_stage,
)

__all__ = ["main"]

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Exit codes
# ---------------------------------------------------------------------------

EXIT_OK = 0
EXIT_GENERIC_FAILURE = 1
EXIT_CHROME_NOT_FOUND = 2
EXIT_PORT_IN_USE = 3
EXIT_CHROME_CLOSED = 4
EXIT_UNEXPECTED = 5
EXIT_AUTH_ERROR = 6
EXIT_QUOTA_EXHAUSTED = 7
EXIT_SERVER_REJECTED = 8
# Fix #6 companion: upload-network / upload-server failures used to
# print a soft message and exit zero. They now exit non-zero so
# callers / CI scripts can distinguish "scan succeeded, hosted URL
# below" from "scan captured but never reached the server".
EXIT_UPLOAD_FAILED = 9
#: T9: user cancelled the post-capture confirmation prompt
#: (action='rerecord' or refused via the chat-refine UX).
EXIT_USER_CANCELLED = 10

#: The 6 starter templates + ``custom``. Keep in lockstep with
#: :data:`browser_recon_server.intent_orchestrator.STARTER_TEMPLATES`.
_STARTER_TEMPLATE_CHOICES: tuple[str, ...] = (
    "products",
    "stocks",
    "realestate",
    "jobs",
    "reviews",
    "news",
    "custom",
)

#: One-line descriptions for the interactive picker. Order matches the
#: tuple above.
_STARTER_TEMPLATE_DESCRIPTIONS: dict[str, str] = {
    "products": "Product listings or details (e-commerce catalogues, marketplaces).",
    "stocks": "Stock / equity / financial-instrument quotes and metadata.",
    "realestate": "Real-estate listings (homes, rentals, commercial property).",
    "jobs": "Job postings (titles, descriptions, salary, location).",
    "reviews": "User reviews and ratings (products, businesses, places).",
    "news": "News articles and editorial content.",
    "custom": "Something else -- describe it in your own words.",
}

#: Hard cap on clarifying rounds the CLI will display, matching the
#: server-side cap. The server will force-finalise on round 3 anyway --
#: this is purely a defensive client-side guard.
_MAX_CLARIFY_ROUNDS_CLIENT = 3

_DEFAULT_DURATION = 0  # unlimited; user signals "done" via Ctrl+C or `recon stop`
_DEFAULT_PORT = 9222
# T53.7: validation runs server-side now; the per-CLI cap is kept
# only so the inert ``--max-validation-endpoints`` flag still has a
# default to land in argparse.
_DEFAULT_MAX_VALIDATION_ENDPOINTS = 5

# Fix #5: per-domain + timestamp output folders.
# Default root is ``~/recon-runs/`` (configurable via the
# ``BROWSER_RECON_OUTPUT_ROOT`` env var). The legacy
# ``./browser-recon-output`` from ``Config.output_dir`` is overridden by
# this default unless the user has explicitly set ``output_dir`` in
# their config or passed ``--output-dir``.
_DEFAULT_OUTPUT_ROOT = "~/recon-runs"
_OUTPUT_ROOT_ENV_VAR = "BROWSER_RECON_OUTPUT_ROOT"
# Filesystem-safe ISO-flavoured timestamp: ``T`` separator, ``-``
# instead of ``:`` so Windows / macOS don't choke. Trailing seconds-
# precision is enough to disambiguate consecutive scans.
_TIMESTAMP_FORMAT = "%Y-%m-%dT%H-%M-%S"
# The "default" config value for ``output_dir`` -- when the resolved
# config matches this, we treat it as "no explicit user override" and
# layer fix #5's auto-subdirs on top.
_LEGACY_DEFAULT_OUTPUT_DIR = "./browser-recon-output"

# Fix #3: warning printed to stderr when the user opts back into a
# real (non-ephemeral) Chrome profile via ``--use-existing-profile``
# or ``--profile <path>``. Loud-on-purpose: the privacy tradeoff is
# real and non-obvious.
_EXISTING_PROFILE_WARNING = (
    "⚠ Using existing Chrome profile. Cookies / storage from your "
    "default profile will be sent to the target site and any third "
    "parties it loads."
)


# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------


def _configure_logging(verbose: bool, quiet: bool) -> None:
    """Configure root logging based on the verbose / quiet CLI flags.

    ``--quiet`` wins over ``--verbose`` when both are passed (this is also
    rejected by argparse via :func:`argparse.ArgumentParser.error` upstream
    when the flags are mutually exclusive, but we keep the precedence here
    as a defence in depth).
    """
    if quiet:
        level = logging.WARNING
    elif verbose:
        level = logging.DEBUG
    else:
        level = logging.INFO
    logging.basicConfig(
        level=level,
        format="%(asctime)s | %(levelname)-7s | %(message)s",
        datefmt="%H:%M:%S",
        force=True,
    )
    # T37.5: suppress httpx/httpcore's INFO firehose unless --verbose.
    # Without this the validation phase spams a per-request line through
    # httpx that competes with the spinner; users running --verbose still
    # see every call. ``BROWSER_RECON_LOG_LEVEL=DEBUG`` is honoured by
    # leaving the loggers alone when --verbose is set, so debug mode
    # remains a single flag flip.
    if verbose:
        # Match the rest of the firehose: surface httpx + httpcore INFO
        # (their default level shows request/response status lines).
        logging.getLogger("httpx").setLevel(logging.INFO)
        logging.getLogger("httpcore").setLevel(logging.WARNING)
    else:
        logging.getLogger("httpx").setLevel(logging.WARNING)
        logging.getLogger("httpcore").setLevel(logging.WARNING)


# ---------------------------------------------------------------------------
# Argument parsing
# ---------------------------------------------------------------------------


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="recon",
        description=(
            "browser-recon: scan a URL and produce a scraping reconnaissance report."
        ),
    )
    parser.add_argument(
        "--version",
        action="version",
        version=f"browser-recon {__version__}",
    )
    subparsers = parser.add_subparsers(dest="command", metavar="COMMAND")

    # --- scan ---------------------------------------------------------
    scan_parser = subparsers.add_parser(
        "scan",
        help="Scan a URL (launches a browser and captures network traffic).",
    )
    scan_parser.add_argument(
        "url",
        nargs="?",
        default=None,
        help=(
            "URL to scan (e.g. https://example.com). Optional when "
            "--scan-id is provided -- in that case the URL is read from "
            "the existing draft scan."
        ),
    )
    scan_parser.add_argument(
        "--scan-id",
        dest="scan_id",
        default=None,
        help=(
            "Attach to an existing draft scan_id (typically minted from "
            "the dashboard's intent-capture flow). When set, the CLI "
            "skips creating a new draft + skips the intent-clarifier "
            "loop locally; the URL + intent already on the server are "
            "used. The URL positional argument becomes optional. "
            "Mutually exclusive with --template / --intent / --skip-intent."
        ),
    )
    scan_parser.add_argument(
        "--mode",
        choices=("quick", "full"),
        default=None,
        help="Capture mode (default from config or 'quick').",
    )
    # T53.7: kept as accepted but inert flags so v0.2.x automation does
    # not break when it sees ``--no-validation`` / ``--no-replay`` on
    # the command line. Validation and replay run server-side now; the
    # CLI just uploads the raw capture and polls. Removed entirely in
    # the next major.
    scan_parser.add_argument(
        "--no-validation",
        action="store_true",
        help=argparse.SUPPRESS,
    )
    scan_parser.add_argument(
        "--no-replay",
        action="store_true",
        help=argparse.SUPPRESS,
    )
    scan_parser.add_argument(
        "--no-open",
        action="store_true",
        help="Do not open the report in a browser when finished.",
    )
    scan_parser.add_argument(
        "--no-progress",
        action="store_true",
        help=(
            "Disable the animated rich spinner; print one line per "
            "pipeline-step transition instead. Auto-enabled when stdout "
            "is not a TTY (CI logs, piped output)."
        ),
    )
    scan_parser.add_argument(
        "--output-dir",
        default=None,
        help="Directory for the report and capture artefacts.",
    )
    scan_parser.add_argument(
        "--config",
        default=None,
        help="Path to a config file (overrides RECON_CONFIG / platform default).",
    )
    scan_parser.add_argument(
        "--port",
        type=int,
        default=_DEFAULT_PORT,
        help=f"Chrome remote-debugging port (default {_DEFAULT_PORT}).",
    )
    scan_parser.add_argument(
        "--kill-existing",
        action="store_true",
        help="If the debug port is busy, kill running Chrome processes and retry.",
    )
    scan_parser.add_argument(
        "--chrome-path",
        default=None,
        help="Override the auto-detected Chrome executable path.",
    )
    # Fix #3: profile-resolution flags. Default behaviour is a fresh
    # ephemeral profile per scan (created in launch_chrome_process,
    # cleaned up at process exit). The two opt-ins below preserve the
    # user's existing browsing state -- both flags trigger a loud
    # cookie-leak warning on stderr in ``_cmd_scan``.
    profile_group = scan_parser.add_mutually_exclusive_group()
    profile_group.add_argument(
        "--use-existing-profile",
        action="store_true",
        help=(
            "Launch Chrome using your OS-default Chrome profile (cookies, "
            "logins, history). For authenticated-flow scans only -- prints "
            "a warning to stderr because the target site sees your real "
            "cookies. Mutually exclusive with --profile."
        ),
    )
    profile_group.add_argument(
        "--profile",
        dest="profile_dir",
        default=None,
        help=(
            "Path to a specific Chrome user-data-dir to launch with. "
            "Power-user opt-in for a profile you prepared in advance. "
            "Prints the same cookie-leak warning as --use-existing-profile. "
            "Mutually exclusive with --use-existing-profile."
        ),
    )
    scan_parser.add_argument(
        "--duration",
        type=int,
        default=_DEFAULT_DURATION,
        help=(
            "Capture duration in seconds. 0 (the default) means unlimited -- "
            "press Ctrl+C in this terminal or run `recon stop` when you're "
            "done browsing. Pass a positive integer for a hard time cap."
        ),
    )
    scan_parser.add_argument(
        "--verbose",
        action="store_true",
        help="Enable DEBUG logging.",
    )
    scan_parser.add_argument(
        "--quiet",
        action="store_true",
        help="Only print the report path on success (sets logging to WARNING).",
    )
    # T53.7: validation is server-side now; ``--allow-writes`` and
    # ``--max-validation-endpoints`` are kept as accepted-but-inert
    # flags so v0.2.x automation does not break. Removed in the next
    # major.
    scan_parser.add_argument(
        "--allow-writes",
        action="store_true",
        help=argparse.SUPPRESS,
    )
    scan_parser.add_argument(
        "--max-validation-endpoints",
        type=int,
        default=_DEFAULT_MAX_VALIDATION_ENDPOINTS,
        help=argparse.SUPPRESS,
    )
    # T53.7: the thin-CLI flow has no local pipeline to fall back to,
    # so ``--no-upload`` is rejected at argparse time with a pointer
    # to the new contract. Kept on the parser so the failure message
    # is clear rather than "unrecognised argument".
    scan_parser.add_argument(
        "--no-upload",
        action="store_true",
        help=(
            "Deprecated. The CLI no longer runs validation locally; "
            "every scan must reach the server. Use `recon scan` without "
            "this flag."
        ),
    )
    scan_parser.add_argument(
        "--server",
        default=None,
        help="Server base URL (overrides config.server_url).",
    )
    scan_parser.add_argument(
        "--api-key",
        default=None,
        help="API key (overrides config.api_key).",
    )
    # Phase 2 (T4): intent capture flags. ``--template`` selects one of
    # the 6 starter templates (or the free-text ``custom``); when
    # omitted the CLI runs an interactive picker. ``--intent`` is the
    # free-text intent description. ``--skip-intent`` bypasses the
    # entire pre-Chrome intent loop for users / automation that don't
    # want to opt in yet -- the scan still runs but with
    # ``starter_template='custom'`` and ``intent_text=''``.
    scan_parser.add_argument(
        "--template",
        choices=_STARTER_TEMPLATE_CHOICES,
        default=None,
        help=(
            "Starter template for the intent capture. One of "
            f"{_STARTER_TEMPLATE_CHOICES}. Omit to pick interactively."
        ),
    )
    scan_parser.add_argument(
        "--intent",
        default=None,
        help=(
            "Free-text description of what data you want to scrape. "
            "Used by the intent-clarifier prompt. Optional."
        ),
    )
    scan_parser.add_argument(
        "--skip-intent",
        action="store_true",
        help=(
            "Skip the pre-Chrome intent-capture step entirely. The scan "
            "still runs and uploads, but no clarifying-question loop "
            "happens. Equivalent to v0.1.x behaviour. Use this when "
            "automation hasn't been updated to know about intent yet."
        ),
    )
    # T53.7: the post-capture confirmation prompt is server-side now
    # (run inside the pipeline orchestrator). Kept as an inert flag so
    # v0.2.x automation does not break.
    scan_parser.add_argument(
        "--no-confirm",
        action="store_true",
        help=argparse.SUPPRESS,
    )

    # --- list ---------------------------------------------------------
    list_parser = subparsers.add_parser(
        "list",
        help="List your scan history (newest first).",
    )
    list_parser.add_argument(
        "--limit",
        type=int,
        default=20,
        help="Max scans to show (default 20, server cap 200).",
    )
    list_parser.add_argument(
        "--offset",
        type=int,
        default=0,
        help="Skip the first N scans. Use with --limit for pagination.",
    )
    list_parser.add_argument(
        "--json",
        dest="json_output",
        action="store_true",
        help="Output the raw JSON response (suitable for `jq`).",
    )
    list_parser.add_argument(
        "--server",
        default=None,
        help="Server base URL (overrides config.server_url).",
    )
    list_parser.add_argument(
        "--api-key",
        default=None,
        help="API key (overrides config.api_key).",
    )
    list_parser.add_argument(
        "--config",
        default=None,
        help="Path to a config file (overrides RECON_CONFIG / platform default).",
    )

    # --- stop ---------------------------------------------------------
    stop_parser = subparsers.add_parser(
        "stop",
        help="Stop an in-progress scan by writing a .stop sentinel.",
    )
    stop_parser.add_argument(
        "--output-dir",
        default=None,
        help="Output directory whose capture should be stopped.",
    )
    stop_parser.add_argument(
        "--config",
        default=None,
        help="Path to a config file (used to resolve --output-dir default).",
    )

    # --- login --------------------------------------------------------
    add_login_subparser(subparsers)

    # --- retry-section -----------------------------------------------
    # T18: free per-section rerun. The server caps reruns at 3 per
    # section per scan; the user is never charged a credit.
    retry_parser = subparsers.add_parser(
        "retry-section",
        help=(
            "Re-run a single failed synthesis section against an "
            "existing scan. Free for the user; capped at 3 reruns "
            "per section per scan."
        ),
    )
    retry_parser.add_argument(
        "scan_id",
        help="UUID of the scan whose section should be retried.",
    )
    retry_parser.add_argument(
        "prompt_name",
        choices=("synthesis", "notes", "difficulty_drivers"),
        help=(
            "Which section to retry. 'synthesis' covers the combined "
            "recommendation + verdict + starter_code call (T16)."
        ),
    )
    retry_parser.add_argument(
        "--server",
        default=None,
        help="Server base URL (overrides config.server_url).",
    )
    retry_parser.add_argument(
        "--api-key",
        default=None,
        help="API key (overrides config.api_key).",
    )
    retry_parser.add_argument(
        "--config",
        default=None,
        help="Path to a config file (overrides RECON_CONFIG / platform default).",
    )

    # --- rerun-stage --------------------------------------------------
    # T24: stage-level rerun. filter / synthesis are free; full creates
    # a new scan (with parent_scan_id linkage) and costs 1 credit.
    rerun_stage_parser = subparsers.add_parser(
        "rerun-stage",
        help=(
            "Re-run an entire stage against an existing scan. "
            "'filter' and 'synthesis' are free; 'full' creates a new "
            "scan from the captured blob and costs 1 credit."
        ),
    )
    rerun_stage_parser.add_argument(
        "scan_id",
        help="UUID of the scan whose stage should be re-run.",
    )
    rerun_stage_parser.add_argument(
        "stage",
        choices=("filter", "synthesis", "full"),
        help=(
            "Stage to re-run. 'filter' re-runs T7 intent-filter and "
            "cascades to synthesis. 'synthesis' re-runs the synthesis "
            "stage in place. 'full' creates a new scan (parent_scan_id "
            "= original) and runs filter + synthesis fresh; costs 1 "
            "credit."
        ),
    )
    rerun_stage_parser.add_argument(
        "--server",
        default=None,
        help="Server base URL (overrides config.server_url).",
    )
    rerun_stage_parser.add_argument(
        "--api-key",
        default=None,
        help="API key (overrides config.api_key).",
    )
    rerun_stage_parser.add_argument(
        "--config",
        default=None,
        help="Path to a config file (overrides RECON_CONFIG / platform default).",
    )

    # --- llm-eval -----------------------------------------------------
    # T46: side-by-side LLM provider comparison harness.
    llm_eval_parser = subparsers.add_parser(
        "llm-eval",
        help=(
            "Compare two LLM providers side-by-side on the same fixture "
            "capture. Produces a Markdown report at "
            "eval-runs/<timestamp>/eval.md with cost, latency, and "
            "per-field output diff. Live mode requires --confirm-spend."
        ),
    )
    # T46 mode: ``--fixture``. T48 mode: ``--scan-id``. Mutually
    # exclusive at the argparse layer so users can't ambiguously
    # combine them.
    llm_eval_source_group = llm_eval_parser.add_mutually_exclusive_group(
        required=True,
    )
    llm_eval_source_group.add_argument(
        "--fixture",
        default=None,
        help=(
            "Fixture directory name under tests/fixtures/captures/ "
            "(e.g. 'target', 'airbnb', 'devto'). T46 mode."
        ),
    )
    llm_eval_source_group.add_argument(
        "--scan-id",
        default=None,
        help=(
            "T48: replay a persisted scan's prompts against --provider-b. "
            "Reads system+user text from the scan's S3 dumps and writes "
            "results to the llm_evals table."
        ),
    )
    llm_eval_parser.add_argument(
        "--provider-a",
        default="claude-sonnet-4-6",
        help="First model to compare (default: claude-sonnet-4-6).",
    )
    llm_eval_parser.add_argument(
        "--provider-b",
        required=True,
        help="Second model to compare (e.g. gpt-5.4-mini, grok-3-mini).",
    )
    llm_eval_parser.add_argument(
        "--prompts",
        default="scan_synthesis,notes,difficulty_drivers,intent_filter",
        help=(
            "Comma-separated prompt names to evaluate. Valid: "
            "scan_synthesis, notes, difficulty_drivers, intent_filter. "
            "Default: all four."
        ),
    )
    llm_eval_parser.add_argument(
        "--confirm-spend",
        type=float,
        default=None,
        help=(
            "REQUIRED in live mode. Hard cap (USD) on accumulated cost; "
            "aborts mid-run if the next call would exceed it. "
            "--confirm-spend 0 is allowed but only fires --dry-run."
        ),
    )
    llm_eval_parser.add_argument(
        "--dry-run",
        action="store_true",
        help=(
            "Compute projected cost only; do not call any API. No "
            "--confirm-spend required in dry-run."
        ),
    )
    llm_eval_parser.add_argument(
        "--output-dir",
        default=None,
        help="Output directory (default: eval-runs/<ISO timestamp>/).",
    )
    llm_eval_parser.add_argument(
        "--fixtures-root",
        default=None,
        help=(
            "Override the path to tests/fixtures/captures/. Useful for "
            "running the harness against a captured blob outside the repo."
        ),
    )
    # T48 scan-replay flags. Both no-op in --fixture mode.
    llm_eval_parser.add_argument(
        "--force",
        action="store_true",
        help=(
            "T48: write a new llm_evals row even when a complete one "
            "exists for (scan_id, prompt, model). Required to re-run a "
            "previously-completed eval."
        ),
    )
    llm_eval_parser.add_argument(
        "--rerun-a",
        action="store_true",
        help=(
            "T48: re-call provider A live instead of reading the "
            "production response from the existing S3 dump. Default: "
            "read from dump (free)."
        ),
    )

    # --- version ------------------------------------------------------
    subparsers.add_parser(
        "version",
        help="Print the browser-recon version.",
    )

    return parser


# ---------------------------------------------------------------------------
# scan flow
# ---------------------------------------------------------------------------


def _resolve_output_root() -> Path:
    """Return the root directory under which auto-derived scan dirs live.

    Configurable via the ``BROWSER_RECON_OUTPUT_ROOT`` env var. Defaults
    to ``~/recon-runs``. Always expanded; never created here (the caller
    creates the leaf directory once it knows the full path).
    """
    env_root = os.environ.get(_OUTPUT_ROOT_ENV_VAR)
    if env_root and env_root.strip():
        return Path(env_root).expanduser()
    return Path(_DEFAULT_OUTPUT_ROOT).expanduser()


def _scan_timestamp(now: datetime | None = None) -> str:
    """Return the filesystem-safe ISO-flavoured timestamp for a scan dir.

    Format: ``YYYY-MM-DDTHH-MM-SS`` -- ``-`` instead of ``:`` so the
    path is valid on Windows + macOS as well.
    """
    when = now if now is not None else datetime.now(UTC)
    return when.strftime(_TIMESTAMP_FORMAT)


def _resolve_output_dir(
    cli_value: str | None,
    cfg: Config,
    *,
    primary_domain: str,
    now: datetime | None = None,
) -> Path:
    """Pick the output directory for this scan.

    Resolution order (fix #5):

    1. ``--output-dir`` flag set: power-user contract -- write flatly
       there, no auto-subdirs added.
    2. Config has an explicit ``output_dir`` distinct from the legacy
       default: honour it verbatim, no auto-subdirs (back-compat for
       users with a custom config).
    3. Otherwise: ``<output-root>/<primary_domain>/<iso-timestamp>/``
       where ``<output-root>`` defaults to ``~/recon-runs/`` and is
       configurable via the ``BROWSER_RECON_OUTPUT_ROOT`` env var.

    ``primary_domain`` should already be the eTLD+1 (fix #2). Empty
    falls back to ``"unknown"`` so the path stays valid.
    """
    if cli_value:
        return Path(cli_value).expanduser()
    cfg_value = (cfg.output_dir or "").strip()
    if cfg_value and cfg_value != _LEGACY_DEFAULT_OUTPUT_DIR:
        return Path(cfg_value).expanduser()
    domain_part = primary_domain.strip() or "unknown"
    return _resolve_output_root() / domain_part / _scan_timestamp(now)


def _resolve_stop_output_dir(cli_value: str | None, cfg: Config) -> Path:
    """Resolve --output-dir for ``recon stop``.

    The stop command can't reconstruct fix #5's auto-derived path
    (timestamp differs from when the scan was launched), so it keeps
    the legacy "CLI flag wins, else config" semantics.
    """
    if cli_value:
        return Path(cli_value).expanduser()
    return Path(cfg.output_dir).expanduser()


def _resolve_mode(cli_value: str | None, cfg: Config) -> str:
    if cli_value:
        return cli_value
    return cfg.mode or "quick"


def _emit(message: str, *, quiet: bool, stream: Any = None) -> None:
    """Print to ``stream`` (default stdout) unless ``quiet`` is True."""
    if quiet:
        return
    if stream is None:
        stream = sys.stdout
    print(message, file=stream)


def _normalize_target_url(raw_url: str, *, quiet: bool) -> str:
    """Add ``https://`` when the user typed a bare hostname.

    Without this, ``recon scan example.com`` slips through argparse
    unchanged: Chrome guesses a scheme and loads the page, but the
    server's ``target_url`` validator rejects the upload with HTTP
    400 (``scheme '' is not allowed``). Auto-prepending ``https://``
    matches what ``curl`` / ``wget`` do when given a bare host, and
    the one-line stderr notice keeps the rewrite transparent.

    URLs that already carry an explicit scheme (``http://``,
    ``https://``, or anything else like ``ftp://``) are returned
    verbatim -- the server's allowlist remains the source of truth
    for non-http(s) schemes.
    """
    stripped = raw_url.strip()
    # ``urlparse`` only recognises the scheme when ``://`` is present.
    # The cheaper substring check matches that contract exactly and
    # avoids quirks like ``urlparse("example.com:80/path")`` deciding
    # ``example.com`` is the scheme.
    if "://" in stripped:
        return stripped
    normalized = f"https://{stripped}"
    if not quiet:
        print(
            f"note: no scheme on '{raw_url}', using '{normalized}'.",
            file=sys.stderr,
        )
    return normalized


def _preflight_credit_check(*, server_url: str, api_key: str) -> int:
    """Hit ``GET /auth/me`` and refuse the scan if credits == 0.

    Returns :data:`EXIT_OK` to continue, :data:`EXIT_AUTH_ERROR` if
    the key was rejected, :data:`EXIT_QUOTA_EXHAUSTED` if the account
    is out of credits. Network errors are treated as non-fatal -- we
    print a soft warning and let the scan proceed; the upload step
    will surface the real failure if the server is genuinely down.

    The transient-error policy is deliberate: a flaky ``/auth/me``
    response should not block a legitimate scan, since the server's
    ``POST /scans`` re-checks credits authoritatively. The pre-flight
    is a UX optimisation, not a security boundary.
    """
    try:
        summary = fetch_account_summary(server_url=server_url, api_key=api_key)
    except UploadAuthError:
        print(
            "API key rejected. Run 'recon login' to refresh.",
            file=sys.stderr,
        )
        return EXIT_AUTH_ERROR
    except (UploadNetworkError, UploadServerError) as exc:
        print(
            f"warning: could not pre-check credits ({exc}); proceeding anyway.",
            file=sys.stderr,
        )
        return EXIT_OK

    if summary.scan_credits <= 0:
        print(
            f"No scan credits remaining (account: {summary.email}). "
            f"Buy more at {server_url.rstrip('/')}/dashboard.",
            file=sys.stderr,
        )
        return EXIT_QUOTA_EXHAUSTED
    return EXIT_OK


def _prompt_for_template(
    *, quiet: bool, stream_in: Any = None, stream_out: Any = None
) -> str:
    """Interactive picker for the 6 starter templates + ``custom``.

    Prints a numbered list, reads one line of input, returns the
    chosen template name. Re-prompts on invalid input. ``quiet`` mode
    short-circuits to ``custom`` since interactive prompting wouldn't
    make sense without echoing. Non-TTY stdin (CI / piped scripts)
    also short-circuits to ``custom`` so the scan doesn't block forever
    waiting for input that never arrives.
    """
    if quiet:
        return "custom"
    in_stream = stream_in if stream_in is not None else sys.stdin
    out_stream = stream_out if stream_out is not None else sys.stdout
    # Non-interactive stdin: caller forgot to pass --template or
    # --skip-intent. Default to custom rather than blocking.
    isatty = getattr(in_stream, "isatty", None)
    if isatty is not None and not isatty():
        return "custom"
    print("", file=out_stream)
    print("Pick a starter template for the intent capture:", file=out_stream)
    for idx, name in enumerate(_STARTER_TEMPLATE_CHOICES, start=1):
        desc = _STARTER_TEMPLATE_DESCRIPTIONS[name]
        print(f"  {idx}. {name:<11} {desc}", file=out_stream)
    print("", file=out_stream)
    while True:
        print("Choice (number or name) [custom]: ", end="", file=out_stream)
        out_stream.flush()
        raw = in_stream.readline().strip()
        if not raw:
            return "custom"
        # Number?
        if raw.isdigit():
            idx = int(raw)
            if 1 <= idx <= len(_STARTER_TEMPLATE_CHOICES):
                return _STARTER_TEMPLATE_CHOICES[idx - 1]
        # Name?
        normalised = raw.lower()
        if normalised in _STARTER_TEMPLATE_CHOICES:
            return normalised
        print(f"  '{raw}' is not a valid choice. Try again.", file=out_stream)


def _prompt_for_intent_text(
    *, quiet: bool, stream_in: Any = None, stream_out: Any = None
) -> str:
    """Read the free-text intent from the user. Empty line == empty intent.

    Same non-TTY short-circuit as :func:`_prompt_for_template` -- a
    pipe / CI invocation shouldn't block waiting for stdin.
    """
    if quiet:
        return ""
    in_stream = stream_in if stream_in is not None else sys.stdin
    out_stream = stream_out if stream_out is not None else sys.stdout
    isatty = getattr(in_stream, "isatty", None)
    if isatty is not None and not isatty():
        return ""
    print("", file=out_stream)
    print(
        "Describe what data you want to scrape (one line, optional, "
        "leave blank to skip):",
        file=out_stream,
    )
    out_stream.flush()
    return in_stream.readline().strip()


def _run_clarifying_loop(
    *,
    server_url: str,
    api_key: str,
    scan_id: str,
    intent_text: str,
    starter_template: str,
    quiet: bool,
    stream_in: Any = None,
    stream_out: Any = None,
) -> int:
    """Drive the clarifying-question loop. Returns CLI exit code.

    Hits ``POST /scans/{scan_id}/intent`` to start, then loops on
    ``/intent/answer`` until ``done=True`` or the user types ``s`` to
    skip. ``s`` (or blank line) routes to ``/intent/skip``. Any
    network / server error short-circuits to the same exit codes used
    by the upload step (`EXIT_SERVER_REJECTED`, etc.).
    """
    in_stream = stream_in if stream_in is not None else sys.stdin
    out_stream = stream_out if stream_out is not None else sys.stdout

    if not quiet:
        print("", file=out_stream)
        print("Thinking...", file=out_stream)
        out_stream.flush()

    try:
        state: ClarifyState = start_intent_session(
            server_url=server_url,
            api_key=api_key,
            scan_id=scan_id,
            intent_text=intent_text,
            starter_template=starter_template,
        )
    except UploadAuthError:
        print(
            "API key rejected during intent capture. Run 'recon login'.",
            file=sys.stderr,
        )
        return EXIT_AUTH_ERROR
    except UploadQuotaExhausted as exc:
        signup = exc.signup_url or "https://recon.app/signup"
        print(
            f"Out of scan credits. Buy more at {signup}.",
            file=sys.stderr,
        )
        return EXIT_QUOTA_EXHAUSTED
    except (UploadNetworkError, UploadServerError) as exc:
        print(f"Intent capture failed: {exc}", file=sys.stderr)
        return EXIT_UPLOAD_FAILED
    except UploadError as exc:
        print(f"Intent capture failed: {exc}", file=sys.stderr)
        return EXIT_SERVER_REJECTED

    rounds = 0
    while not state.done and rounds < _MAX_CLARIFY_ROUNDS_CLIENT:
        rounds += 1
        question = state.current_question or ""
        if not quiet:
            print("", file=out_stream)
            print(
                f"Clarifying question ({rounds}/{_MAX_CLARIFY_ROUNDS_CLIENT}):",
                file=out_stream,
            )
            print(f"  {question}", file=out_stream)
            # T13 / phase-2 § 9: every wait state must show a cancel
            # option. The clarifying loop blocks on stdin per round; we
            # surface ``cancel`` (and the back-compat ``s`` skip) right
            # in the prompt so the user always knows the back-out exists.
            print(
                (
                    "Your answer (type 's' / blank to skip the rest, "
                    "or 'cancel' to abandon this scan):"
                ),
                file=out_stream,
            )
            out_stream.flush()
        raw = in_stream.readline().strip()
        if raw.lower() in {"cancel", "abandon", "q", "quit"}:
            # T13: cancel during the clarifying loop bails out cleanly.
            # No charge to the user (the spec credits decrement on the
            # first paid LLM call, but bailing returns the credit
            # server-side per § 8). We just exit here.
            if not quiet:
                print("", file=out_stream)
                print(
                    "Scan cancelled before capture. No credits charged.",
                    file=out_stream,
                )
                out_stream.flush()
            return EXIT_USER_CANCELLED
        if not raw or raw.lower() in {"s", "skip"}:
            try:
                state = skip_intent(
                    server_url=server_url,
                    api_key=api_key,
                    scan_id=scan_id,
                )
            except UploadError as exc:
                print(f"Skip failed: {exc}", file=sys.stderr)
                return EXIT_UPLOAD_FAILED
            break

        if not quiet:
            print("Thinking...", file=out_stream)
            out_stream.flush()
        try:
            state = submit_intent_answer(
                server_url=server_url,
                api_key=api_key,
                scan_id=scan_id,
                answer=raw,
            )
        except UploadError as exc:
            print(f"Intent answer failed: {exc}", file=sys.stderr)
            return EXIT_UPLOAD_FAILED

    if not quiet:
        print("", file=out_stream)
        print(
            f"Intent captured (data kind: {state.inferred_data_kind}). "
            f"Launching Chrome...",
            file=out_stream,
        )
    return EXIT_OK


def _cmd_scan(args: argparse.Namespace) -> int:
    _configure_logging(verbose=args.verbose, quiet=args.quiet)

    # ---- --scan-id mutual exclusion + URL requirement ----------------
    #
    # ``--scan-id`` attaches to an existing draft scan that already has
    # intent + clarifying_qa set on the server (typically minted via the
    # dashboard's intent-capture flow). The flags that drive the local
    # intent loop are nonsensical in that case -- reject up front so the
    # CLI doesn't silently swallow them.
    # T53.7: the thin-CLI flow has no local pipeline to fall back to.
    # ``--no-upload`` is rejected at the entry point so the user gets a
    # clear error rather than a half-broken local-only run.
    if args.no_upload:
        print(
            (
                "--no-upload is no longer supported: validation, scrubbing, "
                "and synthesis now run server-side, so every scan must reach "
                "the server. Drop --no-upload and re-run."
            ),
            file=sys.stderr,
        )
        return EXIT_GENERIC_FAILURE

    if args.scan_id is not None:
        rejected = []
        if args.template is not None:
            rejected.append("--template")
        if args.intent is not None:
            rejected.append("--intent")
        if args.skip_intent:
            rejected.append("--skip-intent")
        if rejected:
            print(
                f"--scan-id is mutually exclusive with: {', '.join(rejected)}",
                file=sys.stderr,
            )
            return EXIT_GENERIC_FAILURE
    elif not args.url:
        print(
            "error: URL is required as a positional argument. "
            "Use --scan-id to attach to an existing draft scan instead.",
            file=sys.stderr,
        )
        return EXIT_GENERIC_FAILURE

    # Normalise the URL before any downstream consumer sees it. Every
    # path that uses ``args.url`` (capture, eTLD+1 extraction, blob
    # ``target_url``, the "scanning <url>" log line) reads from the
    # same normalised string -- so a bare hostname doesn't sneak through
    # to the upload step where it triggers a server-side 400.
    # When --scan-id is set the URL is filled in from the server later;
    # leave args.url alone here to avoid double-normalising.
    if args.scan_id is None:
        args.url = _normalize_target_url(args.url, quiet=args.quiet)

    try:
        cfg = load_config(path=args.config)
    except FileNotFoundError as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return EXIT_GENERIC_FAILURE

    # Fix #6: resolve the API key BEFORE any heavy work. Failing here
    # saves the user from waiting for a full Chrome capture only to be
    # told their key is missing at the upload step.
    server_url = args.server if args.server else cfg.server_url
    api_key = args.api_key if args.api_key is not None else cfg.api_key
    if not api_key:
        print(
            "API key required. Run 'recon login' first or pass --api-key.",
            file=sys.stderr,
        )
        return EXIT_AUTH_ERROR

    # ---- --scan-id attach: hydrate from the server -------------------
    #
    # When attaching to a draft, fetch the scan's stored target_url +
    # intent + status so the CLI can validate the attach is sensible
    # (refuse a scan that already has a captured blob; refuse a scan
    # past awaiting_validation) and so the user sees a one-line summary
    # before Chrome launches.
    attached_scan_state: Any = None
    if args.scan_id is not None:
        try:
            attached_scan_state = fetch_scan_state(
                server_url=server_url,
                api_key=api_key,
                scan_id=args.scan_id,
            )
        except UploadAuthError:
            print(
                "API key rejected. Run 'recon login'.",
                file=sys.stderr,
            )
            return EXIT_AUTH_ERROR
        except (UploadNetworkError, UploadServerError) as exc:
            msg = str(exc)
            if msg.startswith("404"):
                print(
                    f"Scan {args.scan_id} not found (or not owned by this API key).",
                    file=sys.stderr,
                )
                return EXIT_SERVER_REJECTED
            print(f"Could not fetch scan state: {exc}", file=sys.stderr)
            return EXIT_UPLOAD_FAILED
        except UploadError as exc:
            print(f"Could not fetch scan state: {exc}", file=sys.stderr)
            return EXIT_SERVER_REJECTED

        if attached_scan_state.has_captured_blob:
            print(
                f"Scan {args.scan_id} already has a captured blob -- "
                "cannot re-attach. Start a new scan.",
                file=sys.stderr,
            )
            return EXIT_GENERIC_FAILURE

        # Use the URL from the server. The CLI's positional ``url`` is
        # optional under --scan-id; if the user passed one and it
        # differs from the stored URL, prefer the stored one (the
        # capture must hit the same site the dashboard intent was
        # collected for) and warn so they're not surprised.
        stored_url = attached_scan_state.target_url
        if args.url and args.url != stored_url:
            print(
                f"warning: CLI URL '{args.url}' differs from the stored "
                f"scan URL '{stored_url}'; using the stored URL.",
                file=sys.stderr,
            )
        args.url = _normalize_target_url(stored_url, quiet=args.quiet)
        _emit(
            f"  attaching to scan: {attached_scan_state.scan_id}",
            quiet=args.quiet,
        )
        if attached_scan_state.intent_text:
            preview = attached_scan_state.intent_text[:80]
            ellipsis = "..." if len(attached_scan_state.intent_text) > 80 else ""
            _emit(f"  stored intent: {preview}{ellipsis}", quiet=args.quiet)

    # Pre-flight credit check: when we're going to upload, hit
    # ``GET /auth/me`` BEFORE launching Chrome so a 0-credit user gets
    # an instant rejection instead of waiting through a full ~30s
    # capture only to receive a 402 at upload time. The check is
    # advisory -- the server's ``/scans`` endpoint remains the source
    # of truth -- so a flaky ``/auth/me`` (network blip, transient 5xx)
    # falls through to the actual scan rather than blocking it.
    #
    # Skip the check when --scan-id is set: the credit was already
    # decremented during the dashboard's intent flow on the original
    # draft, so re-charging would double-bill.
    if args.scan_id is None:
        rc = _preflight_credit_check(server_url=server_url, api_key=api_key)
        if rc != EXIT_OK:
            return rc

    mode = _resolve_mode(args.mode, cfg)
    # Fix #2: derive primary_domain (eTLD+1) from the URL the user
    # typed. This becomes the canonical primary_domain plumbed through
    # capture / scrub / package / upload, and (fix #5) feeds the
    # default output-dir layout.
    primary_domain = extract_etld_plus_one(args.url)
    output_dir = _resolve_output_dir(
        args.output_dir,
        cfg,
        primary_domain=primary_domain,
    )
    output_dir.mkdir(parents=True, exist_ok=True)

    _emit(f"browser-recon: scanning {args.url}", quiet=args.quiet)
    _emit(f"  mode: {mode}", quiet=args.quiet)
    _emit(f"  output dir: {output_dir}", quiet=args.quiet)

    # ---- Phase 2 (T4): pre-Chrome intent capture --------------------
    #
    # Every scan opens a draft Scan row on the server BEFORE launching
    # Chrome so the eventual capture has a stable scan_id to attach
    # intent + clarifying-Q&A to. ``--skip-intent`` opens the draft
    # but bypasses the LLM clarifier; ``--scan-id`` skips draft
    # creation AND the intent loop entirely (the server already has
    # both).
    draft_scan_id: str | None = None
    intent_template: str = "custom"
    intent_text_value: str = ""
    if attached_scan_state is not None:
        # --scan-id branch: dashboard already minted the draft + ran
        # intent. Reuse the same scan_id; the local intent loop is a
        # no-op.
        draft_scan_id = attached_scan_state.scan_id
        intent_template = attached_scan_state.starter_template or "custom"
        intent_text_value = attached_scan_state.intent_text or ""
        _emit(f"  draft scan id: {draft_scan_id}", quiet=args.quiet)
    else:
        try:
            draft_resp = create_draft_scan(
                server_url=server_url,
                api_key=api_key,
                target_url=args.url,
                primary_domain=primary_domain,
                client_id="",
                cli_version=__version__,
            )
        except UploadAuthError:
            print(
                "API key rejected at draft step. Run 'recon login'.",
                file=sys.stderr,
            )
            return EXIT_AUTH_ERROR
        except (UploadNetworkError, UploadServerError) as exc:
            print(
                f"Could not create draft scan ({exc}); aborting.",
                file=sys.stderr,
            )
            return EXIT_UPLOAD_FAILED
        except UploadError as exc:
            print(
                f"Draft scan creation failed: {exc}",
                file=sys.stderr,
            )
            return EXIT_SERVER_REJECTED

        draft_scan_id = draft_resp.scan_id
        _emit(f"  draft scan id: {draft_scan_id}", quiet=args.quiet)

        if args.skip_intent:
            # Bypass the clarifier loop entirely, but still hit /skip
            # so the row carries an explicit empty clarifying_qa.
            intent_template = "custom"
            intent_text_value = ""
            try:
                skip_intent(
                    server_url=server_url,
                    api_key=api_key,
                    scan_id=draft_scan_id,
                )
            except UploadError as exc:
                logger.warning(
                    "skip_intent failed (non-fatal, scan continues): %s", exc
                )
        else:
            intent_template = args.template or _prompt_for_template(quiet=args.quiet)
            intent_text_value = (
                args.intent
                if args.intent is not None
                else _prompt_for_intent_text(quiet=args.quiet)
            )
            rc = _run_clarifying_loop(
                server_url=server_url,
                api_key=api_key,
                scan_id=draft_scan_id,
                intent_text=intent_text_value,
                starter_template=intent_template,
                quiet=args.quiet,
            )
            if rc != EXIT_OK:
                return rc

    # Fix #3: print the loud cookie-leak warning when the user has
    # opted back into a real Chrome profile. Argparse already enforces
    # mutual exclusion between the two flags, but the warning wording
    # covers both cases.
    profile_dir_arg = getattr(args, "profile_dir", None)
    if args.use_existing_profile or profile_dir_arg:
        print(_EXISTING_PROFILE_WARNING, file=sys.stderr)

    # ---- 1. Capture -------------------------------------------------
    # Chrome launch + CDP capture window + cookie fetch + clean
    # shutdown. Errors here short-circuit before any HTTP traffic
    # leaves the box. The capture orchestrator owns its own progress
    # output during this phase; the thin-CLI spinner only takes over
    # AFTER the user closes Chrome, when the server-side pipeline
    # starts running.
    try:
        capture = start_capture(
            args.url,
            mode=mode,
            duration=args.duration,
            port=args.port,
            kill_existing=args.kill_existing,
            chrome_path=args.chrome_path,
            output_dir=output_dir,
            use_existing_profile=args.use_existing_profile,
            user_data_dir=profile_dir_arg,
        )
    except ChromeNotFoundError:
        print(
            "Chrome not found. Install Google Chrome and try again.",
            file=sys.stderr,
        )
        return EXIT_CHROME_NOT_FOUND
    except PortInUseError as exc:
        print(
            (
                f"Port {exc.port} is in use. Close existing Chrome "
                "(with --kill-existing) or use --port."
            ),
            file=sys.stderr,
        )
        return EXIT_PORT_IN_USE
    except ChromeLaunchError:
        print(
            "Chrome closed before capture finished. Re-run the scan.",
            file=sys.stderr,
        )
        return EXIT_CHROME_CLOSED
    except RuntimeError as exc:
        # Generic capture-side failure (lost CDP connection, etc.)
        logger.debug("Capture failed: %s", exc, exc_info=True)
        print(
            "Chrome closed before capture finished. Re-run the scan.",
            file=sys.stderr,
        )
        return EXIT_CHROME_CLOSED
    except Exception as exc:  # noqa: BLE001 -- last-line crash translator
        logger.debug("Unexpected capture failure: %s", exc, exc_info=True)
        print(f"Unexpected error during capture: {exc}", file=sys.stderr)
        return EXIT_UNEXPECTED

    # Stash the CLI-derived eTLD+1 on the CaptureResult so the upload
    # envelope's ``primary_domain`` matches what detection / analysis
    # use server-side.
    capture.primary_domain = primary_domain

    # ---- 2. Upload raw capture (T53.7) -------------------------------
    #
    # The CLI no longer runs validation, scrubbing, detection, or
    # analysis locally -- those moved server-side in T53.2/T53.3/T53.4.
    # We send the UNSCRUBBED capture (cookies + Authorization values
    # included) so the server's validation step can exercise the real
    # surface; the server scrubs after validation and before
    # synthesis. See the route docstring at
    # ``POST /scans/{scan_id}/capture`` for the privacy contract.
    if draft_scan_id is None:
        # The pre-flight + intent loop above always mints a draft when
        # uploads are enabled; reaching here means something subtle
        # changed upstream. Fail loud rather than silently corrupt the
        # contract.
        print(
            "Internal error: no draft scan id after capture; aborting.",
            file=sys.stderr,
        )
        return EXIT_GENERIC_FAILURE

    capture_envelope: dict[str, Any] = {
        "schema_version": 1,
        "cli_version": __version__,
        "target_url": args.url,
        "primary_domain": primary_domain,
        "capture_metadata": capture.capture_metadata,
        "sanitised_capture": capture.raw,
    }

    _emit(f"uploading capture to {server_url}...", quiet=args.quiet)
    try:
        upload_response: CaptureUploadResponse = upload_capture(
            server_url=server_url,
            api_key=api_key,
            scan_id=draft_scan_id,
            target_url=args.url,
            intent_text=intent_text_value,
            starter_template=intent_template,
            capture=capture_envelope,
            cli_version=__version__,
        )
    except UploadAuthError:
        print(
            "API key rejected. Run 'recon login'.",
            file=sys.stderr,
        )
        return EXIT_AUTH_ERROR
    except UploadQuotaExhausted as exc:
        signup = exc.signup_url or "https://recon.app/signup"
        print(
            f"Out of scan credits. Buy more at {signup}.",
            file=sys.stderr,
        )
        return EXIT_QUOTA_EXHAUSTED
    except (UploadBlobTooLarge, UploadBlobMalformed):
        print(
            "Server rejected the capture upload. This is a bug - please report.",
            file=sys.stderr,
        )
        return EXIT_SERVER_REJECTED
    except (UploadNetworkError, UploadServerError) as exc:
        logger.debug("capture upload failed: %s", exc, exc_info=True)
        err_kind = (
            "network unreachable"
            if isinstance(exc, UploadNetworkError)
            else "server error"
        )
        print(
            f"Capture upload failed ({err_kind}): {exc}",
            file=sys.stderr,
        )
        return EXIT_UPLOAD_FAILED
    except UploadError as exc:
        print(f"Capture upload failed: {exc}", file=sys.stderr)
        return EXIT_SERVER_REJECTED

    _emit(
        f"  scan id: {upload_response.scan_id}",
        quiet=args.quiet,
    )

    # ---- 3. Poll /events for pipeline progress (T53.7) --------------
    #
    # ``poll_scan_events`` blocks until the server reports a terminal
    # ``scan_status`` ("complete" or "failed"). Each transition lands
    # via a ``rich.live.Live`` spinner; ``--no-progress`` (or a
    # non-TTY stdout) downgrades to one stdout line per transition.
    no_progress = bool(args.no_progress or args.quiet)
    try:
        poll_outcome = poll_scan_events(
            server_url=server_url,
            api_key=api_key,
            scan_id=upload_response.scan_id,
            cli_version=__version__,
            no_progress=no_progress,
        )
    except UploadAuthError:
        print(
            "API key rejected during poll. Run 'recon login'.",
            file=sys.stderr,
        )
        return EXIT_AUTH_ERROR
    except UploadServerError as exc:
        print(f"Polling failed: {exc}", file=sys.stderr)
        return EXIT_UPLOAD_FAILED

    # ---- 4. Translate terminal status to exit code ------------------
    report_url = upload_response.report_url
    if poll_outcome.terminal_status == "complete":
        open_in_browser(report_url, suppress=args.no_open)
        if args.quiet:
            print(report_url)
        else:
            print(f"Report ready: {report_url}")
        return EXIT_OK

    # ``failed`` (or any non-"complete" terminal status) -> exit 1.
    failing_step = poll_outcome.failed_step or "pipeline"
    failure_message = ""
    if poll_outcome.failed_step is not None:
        row = poll_outcome.rows.get(poll_outcome.failed_step)
        if row is not None:
            failure_message = row.message
    if failure_message:
        print(
            f"Scan failed at step '{failing_step}': {failure_message}",
            file=sys.stderr,
        )
    else:
        print(
            f"Scan failed at step '{failing_step}'.",
            file=sys.stderr,
        )
    return EXIT_GENERIC_FAILURE


# ---------------------------------------------------------------------------
# stop flow
# ---------------------------------------------------------------------------


def _cmd_stop(args: argparse.Namespace) -> int:
    try:
        cfg = load_config(path=args.config)
    except FileNotFoundError as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return EXIT_GENERIC_FAILURE

    output_dir = _resolve_stop_output_dir(args.output_dir, cfg)

    if not output_dir.exists():
        print(
            (
                f"warning: output directory {output_dir} does not exist; "
                "no active capture detected."
            ),
            file=sys.stderr,
        )

    output_dir.mkdir(parents=True, exist_ok=True)
    sentinel = output_dir / ".stop"
    sentinel.write_text("", encoding="utf-8")

    abs_sentinel = sentinel.resolve()
    print(
        f"Stop sentinel written to {abs_sentinel}. The active capture will "
        "exit at its next checkpoint."
    )
    return EXIT_OK


# ---------------------------------------------------------------------------
# list flow (fix #9.A)
# ---------------------------------------------------------------------------


_LIST_SITE_COL_WIDTH = 22
_LIST_DATE_COL_WIDTH = 13
_LIST_STATUS_COL_WIDTH = 10
# Truncation marker uses an actual ellipsis (single char) rather than
# three dots so the column width math stays correct on terminals that
# render U+2026 as one cell.
_LIST_TRUNCATION_MARKER = "…"


def _format_list_date(created_at: str) -> str:
    """Render the ``created_at`` ISO string as ``YYYY-MM-DD``.

    Falls back to the first 10 chars when ``fromisoformat`` rejects the
    input -- defends against a future server change that emits a
    non-standard timestamp shape (we'd rather show a slightly-wrong
    date than crash the whole listing).
    """
    try:
        dt = datetime.fromisoformat(created_at.replace("Z", "+00:00"))
    except ValueError:
        return created_at[:10]
    return dt.strftime("%Y-%m-%d")


def _truncate_site(target_domain: str, *, width: int = _LIST_SITE_COL_WIDTH) -> str:
    """Truncate ``target_domain`` to ``width`` chars with a trailing ellipsis."""
    if len(target_domain) <= width:
        return target_domain
    # Reserve one char for the ellipsis marker.
    return target_domain[: width - 1] + _LIST_TRUNCATION_MARKER


def _build_report_url(server_url: str, report_id: str) -> str:
    """Build the public report URL by joining ``server_url`` and ``/r/<id>``."""
    return f"{server_url.rstrip('/')}/r/{report_id}"


def _resolve_list_credentials(
    args: argparse.Namespace,
) -> tuple[str, str] | int:
    """Resolve (server_url, api_key) for ``recon list``.

    Returns the tuple on success or an exit code on failure (no API
    key configured / config file not found).
    """
    try:
        cfg = load_config(path=args.config)
    except FileNotFoundError as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return EXIT_GENERIC_FAILURE

    server_url = args.server if args.server else cfg.server_url
    api_key = args.api_key if args.api_key is not None else cfg.api_key
    if not api_key:
        print(
            "API key required. Run 'recon login' first.",
            file=sys.stderr,
        )
        return EXIT_AUTH_ERROR
    return server_url, api_key


def _print_list_table(
    response: Any,
    *,
    server_url: str,
    credits_remaining: int | None,
) -> None:
    """Render the human-readable table for ``recon list``.

    Layout:
    * Date column: ``YYYY-MM-DD`` (10 chars + padding).
    * Site column: 22 chars, truncated with ``…``.
    * Status column: literal value from server.
    * Report URL column: full ``<server>/r/<id>``.

    A footer line shows ``X of Y scans · N credits remaining`` when the
    credit balance is known. When ``credits_remaining`` is ``None`` the
    "credits remaining" half is omitted (the credit lookup may have
    failed but we still want the table).
    """
    if not response.scans:
        print("No scans yet. Run `recon scan <url>` to get started.")
        return

    header_fmt = (
        f"{{:<{_LIST_DATE_COL_WIDTH}}} "
        f"{{:<{_LIST_SITE_COL_WIDTH}}} "
        f"{{:<{_LIST_STATUS_COL_WIDTH}}} "
        f"{{}}"
    )
    print(header_fmt.format("Date", "Site", "Status", "Report URL"))
    print(
        header_fmt.format(
            "-" * _LIST_DATE_COL_WIDTH,
            "-" * _LIST_SITE_COL_WIDTH,
            "-" * _LIST_STATUS_COL_WIDTH,
            "-" * 40,
        )
    )
    for item in response.scans:
        print(
            header_fmt.format(
                _format_list_date(item.created_at),
                _truncate_site(item.target_domain),
                item.status,
                _build_report_url(server_url, item.report_id),
            )
        )

    print()
    shown = len(response.scans)
    summary = f"{shown} of {response.total} scans"
    if credits_remaining is not None:
        summary = f"{summary} · {credits_remaining} credits remaining"
    print(summary)


def _print_list_json(response: Any) -> None:
    """Dump the raw scan-list response as JSON for piping into jq.

    The transport-layer dataclasses are converted via
    :func:`dataclasses.asdict` so the on-disk representation matches
    the server's wire format key-for-key.
    """
    payload = dataclasses.asdict(response)
    print(json.dumps(payload, indent=2))


def _cmd_list(args: argparse.Namespace) -> int:
    creds = _resolve_list_credentials(args)
    if isinstance(creds, int):
        return creds
    server_url, api_key = creds

    try:
        response = fetch_scan_list(
            server_url=server_url,
            api_key=api_key,
            limit=args.limit,
            offset=args.offset,
        )
    except UploadAuthError:
        print(
            "API key rejected. Run 'recon login'.",
            file=sys.stderr,
        )
        return EXIT_AUTH_ERROR
    except UploadNetworkError as exc:
        print(f"Could not reach {server_url}: {exc}", file=sys.stderr)
        return EXIT_UPLOAD_FAILED
    except UploadServerError as exc:
        print(f"Server error: {exc}", file=sys.stderr)
        return EXIT_UPLOAD_FAILED

    if args.json_output:
        _print_list_json(response)
        return EXIT_OK

    # Best-effort credit lookup for the footer. If /auth/me errors we
    # still render the table without the "N credits remaining" half --
    # the listing itself is the primary deliverable and shouldn't be
    # held hostage to a second round-trip.
    credits_remaining: int | None = None
    try:
        summary = fetch_account_summary(server_url=server_url, api_key=api_key)
    except (UploadAuthError, UploadNetworkError, UploadServerError) as exc:
        logger.debug("auth/me lookup failed for list footer: %s", exc)
    else:
        credits_remaining = summary.scan_credits

    _print_list_table(
        response,
        server_url=server_url,
        credits_remaining=credits_remaining,
    )
    return EXIT_OK


# ---------------------------------------------------------------------------
# version flow
# ---------------------------------------------------------------------------


def _cmd_version() -> int:
    print(f"browser-recon {__version__}")
    return EXIT_OK


# ---------------------------------------------------------------------------
# retry-section flow (T18 / phase-2.5)
# ---------------------------------------------------------------------------


def _cmd_retry_section(args: argparse.Namespace) -> int:
    """Re-run a single failed synthesis section against an existing scan.

    Free for the user; the server caps at 3 reruns per section per
    scan and returns 429 once the limit is hit. Auth + server URL
    resolution mirrors ``recon list`` so the UX is consistent.
    """
    creds = _resolve_list_credentials(args)
    if isinstance(creds, int):
        return creds
    server_url, api_key = creds

    try:
        response = submit_rerun_prompt(
            server_url=server_url,
            api_key=api_key,
            scan_id=args.scan_id,
            prompt_name=args.prompt_name,
        )
    except UploadAuthError:
        print("API key rejected. Run 'recon login'.", file=sys.stderr)
        return EXIT_AUTH_ERROR
    except UploadNetworkError as exc:
        print(f"Could not reach {server_url}: {exc}", file=sys.stderr)
        return EXIT_UPLOAD_FAILED
    except UploadServerError as exc:
        # The server bundles the failure reason into the body of the
        # 4xx / 5xx response so the message string already carries the
        # rate-limit cap or the "capture is gone" copy.
        print(f"Retry failed: {exc}", file=sys.stderr)
        return EXIT_UPLOAD_FAILED

    print(
        f"OK -- section '{response.prompt_name}' regenerated "
        f"({response.rerun_count}/{response.rerun_count_cap} reruns used "
        "on this scan)."
    )
    return EXIT_OK


# ---------------------------------------------------------------------------
# rerun-stage flow (T24 / phase-2.6+)
# ---------------------------------------------------------------------------


def _cmd_rerun_stage(args: argparse.Namespace) -> int:
    """Re-run an entire stage against an existing scan (T24).

    Three stages:

    * ``filter`` -- re-runs T7 intent-filter, cascades into synthesis.
      Free. Capped at 3 per stage per scan.
    * ``synthesis`` -- re-runs the synthesis stage. Free. Capped at 3
      per stage per scan.
    * ``full`` -- mints a new scan with ``parent_scan_id`` linkage and
      runs filter + synthesis fresh. Costs 1 credit (it's a new scan
      from the user's accounting POV).

    Auth + server URL resolution mirrors ``recon retry-section`` and
    ``recon list``.
    """
    creds = _resolve_list_credentials(args)
    if isinstance(creds, int):
        return creds
    server_url, api_key = creds

    try:
        response = submit_rerun_stage(
            server_url=server_url,
            api_key=api_key,
            scan_id=args.scan_id,
            stage=args.stage,
        )
    except UploadAuthError:
        print("API key rejected. Run 'recon login'.", file=sys.stderr)
        return EXIT_AUTH_ERROR
    except UploadNetworkError as exc:
        print(f"Could not reach {server_url}: {exc}", file=sys.stderr)
        return EXIT_UPLOAD_FAILED
    except UploadServerError as exc:
        # 402 / 410 / 429 / 502 are all surfaced as UploadServerError;
        # the message body carries the human-readable reason ("out of
        # credits", "captured blob is gone", "rate limit hit", "LLM
        # call failed").
        print(f"Stage re-run failed: {exc}", file=sys.stderr)
        return EXIT_UPLOAD_FAILED

    if response.new_scan_id:
        # Full re-run -- emit the new scan id so the user can chain
        # ``recon list`` / open the dashboard against it.
        print(
            f"OK -- full re-run minted new scan {response.new_scan_id} "
            f"(parent_scan_id={response.scan_id}; "
            f"{response.rerun_count}/{response.rerun_count_cap} full re-runs "
            "used on this scan)."
        )
    else:
        print(
            f"OK -- stage '{response.stage}' re-run complete "
            f"({response.rerun_count}/{response.rerun_count_cap} re-runs used "
            "on this scan)."
        )
    return EXIT_OK


# ---------------------------------------------------------------------------
# llm-eval (T46)
# ---------------------------------------------------------------------------


def _cmd_llm_eval(args: argparse.Namespace) -> int:
    """Run ``recon llm-eval`` -- side-by-side provider comparison.

    Two modes:

    * **Fixture mode (T46, default).** ``--fixture <name>`` loads a
      capture and builds prompts via the production prompt modules.
    * **Scan-replay mode (T48).** ``--scan-id <uuid>`` reads system +
      user text from the scan's persisted ``llm_calls`` S3 dumps and
      runs each prompt against ``--provider-b``. Writes results to
      ``llm_evals``.

    Safety rails: without ``--dry-run``, ``--confirm-spend`` is
    required (fixture mode) or daily cap check (scan-replay mode).
    Unknown fixtures / prompt names exit non-zero with a clear
    message.
    """
    if getattr(args, "scan_id", None):
        return _cmd_llm_eval_scan_replay(args)

    # Local imports keep the harness out of the cold-import path for
    # ``recon scan`` (the harness pulls detection + analysis +
    # prompts; ``recon scan`` already does, but ``recon version`` etc.
    # do not).
    from browser_recon.llm_eval.fixtures import (
        VALID_PROMPT_NAMES,
        FixtureNotFoundError,
        load_fixture_capture,
    )
    from browser_recon.llm_eval.report import render_eval_markdown
    from browser_recon.llm_eval.runner import EvalRunner

    # Resolve dry-run vs. live + the cap value. The spec says
    # ``--confirm-spend 0`` is allowed but should fire dry-run only --
    # treat zero as "no live calls".
    dry_run = bool(args.dry_run)
    cap_value: float | None = args.confirm_spend
    if cap_value is not None and cap_value <= 0:
        dry_run = True
        cap_value = 0.0

    if not dry_run and cap_value is None:
        print(
            "llm-eval: --confirm-spend USD is required in live mode. "
            "Pass --dry-run to project cost without calling any API.",
            file=sys.stderr,
        )
        return EXIT_GENERIC_FAILURE

    # Parse + validate the prompt list.
    requested_prompts = [
        name.strip() for name in str(args.prompts).split(",") if name.strip()
    ]
    if not requested_prompts:
        print(
            "llm-eval: --prompts cannot be empty. Valid: "
            + ", ".join(VALID_PROMPT_NAMES),
            file=sys.stderr,
        )
        return EXIT_GENERIC_FAILURE
    invalid = [p for p in requested_prompts if p not in VALID_PROMPT_NAMES]
    if invalid:
        print(
            "llm-eval: invalid prompt(s) "
            + ", ".join(repr(p) for p in invalid)
            + ". Valid: "
            + ", ".join(VALID_PROMPT_NAMES),
            file=sys.stderr,
        )
        return EXIT_GENERIC_FAILURE

    # Resolve fixtures root + load the capture.
    fixtures_root_path = (
        Path(args.fixtures_root).expanduser() if args.fixtures_root else None
    )
    try:
        fixture = load_fixture_capture(args.fixture, fixtures_root=fixtures_root_path)
    except FixtureNotFoundError as exc:
        # Surface available fixtures so the user can recover without
        # guessing.
        available = (
            sorted(
                p.name
                for p in exc.fixtures_root.iterdir()
                if p.is_dir() and (p / "recon_capture.json").is_file()
            )
            if exc.fixtures_root.is_dir()
            else []
        )
        avail_str = ", ".join(available) if available else "(none found)"
        print(
            f"llm-eval: fixture {args.fixture!r} not found under "
            f"{exc.fixtures_root}. Available: {avail_str}",
            file=sys.stderr,
        )
        return EXIT_GENERIC_FAILURE

    # Resolve output dir. Default: ``eval-runs/<iso-timestamp>/``.
    if args.output_dir:
        output_dir = Path(args.output_dir).expanduser()
    else:
        ts = datetime.now(UTC).strftime("%Y-%m-%dT%H-%M-%S")
        output_dir = Path("eval-runs") / ts
    output_dir.mkdir(parents=True, exist_ok=True)

    runner = EvalRunner(
        fixture=fixture,
        provider_a=args.provider_a,
        provider_b=args.provider_b,
        prompts=requested_prompts,
        spend_cap_usd=cap_value,
        dry_run=dry_run,
        output_dir=output_dir,
    )
    result = runner.run()

    # Persist the artefacts: eval.md, costs.json.
    eval_md_path = output_dir / "eval.md"
    eval_md_path.write_text(render_eval_markdown(result), encoding="utf-8")
    costs_path = output_dir / "costs.json"
    costs_payload: dict[str, Any] = {
        "fixture": result.fixture_name,
        "provider_a": result.provider_a,
        "provider_b": result.provider_b,
        "spend_cap_usd": result.spend_cap_usd,
        "mode": result.mode,
        "status": result.status,
        "abort_reason": result.abort_reason,
        "total_usd": result.cost_tracker.total_usd,
        "per_provider_usd": result.cost_tracker.per_provider,
        "rows": [
            {
                "prompt_name": row.prompt_name,
                "provider_a": {
                    "model": row.provider_a_model,
                    **row.provider_a_metrics,
                    "error": row.provider_a_error,
                },
                "provider_b": {
                    "model": row.provider_b_model,
                    **row.provider_b_metrics,
                    "error": row.provider_b_error,
                },
            }
            for row in result.rows
        ],
    }
    costs_path.write_text(
        json.dumps(costs_payload, indent=2, default=str), encoding="utf-8"
    )

    print(f"llm-eval: report written to {eval_md_path}")
    if result.status == "aborted (cap hit)":
        print(
            f"llm-eval: ABORTED -- {result.abort_reason}",
            file=sys.stderr,
        )
        return EXIT_GENERIC_FAILURE
    return EXIT_OK


def _cmd_llm_eval_scan_replay(args: argparse.Namespace) -> int:
    """T48 scan-replay mode for ``recon llm-eval``.

    Loads the scan's persisted llm_calls, snapshots each prompt's
    system+user text, runs each against ``--provider-b``, and writes
    a row per call to ``llm_evals``. Honors the scan-level lock + the
    daily cost cap. ``--force`` lets the caller bypass the
    "complete eval already exists" check.

    DB access uses ``DATABASE_URL`` (the same env var the server
    uses). When unset / no scan found / dump missing, the command
    exits with a clear message rather than partial-state writing.
    """
    import os as _os
    import uuid as _uuid

    scan_id = str(args.scan_id).strip()
    try:
        _uuid.UUID(scan_id)
    except Exception:
        print(
            f"llm-eval: --scan-id {scan_id!r} is not a valid UUID",
            file=sys.stderr,
        )
        return EXIT_GENERIC_FAILURE

    db_url = _os.environ.get("DATABASE_URL")
    if not db_url:
        print(
            "llm-eval: DATABASE_URL must be set for --scan-id mode",
            file=sys.stderr,
        )
        return EXIT_GENERIC_FAILURE

    # Late imports keep scan-replay's heavyweight dependencies out of
    # the fixture-mode hot path.
    from datetime import UTC as _UTC
    from datetime import datetime as _dt

    from sqlalchemy import create_engine
    from sqlalchemy.orm import sessionmaker

    from browser_recon.llm_eval.scan_loader import load_scan_prompts
    from browser_recon_server.eval_lock import acquire_scan_lock
    from browser_recon_server.eval_runner import (
        _safe_provider_name,
        run_eval_background,
    )
    from browser_recon_server.models import LlmEval, Scan
    from browser_recon_server.sandbox import resolve_daily_usd_cap
    from browser_recon_server.storage import BlobStore, InMemoryObjectStore

    engine = create_engine(db_url, future=True)
    SessionLocal = sessionmaker(bind=engine, expire_on_commit=False, future=True)

    provider_b = args.provider_b
    if not provider_b:
        print("llm-eval: --provider-b is required", file=sys.stderr)
        return EXIT_GENERIC_FAILURE

    # We rely on the server's blob_store -- but the CLI can't see app
    # state. Fall back to the in-memory backend if the user hasn't
    # plumbed S3 credentials; the prompts table still loads from any
    # storage the operator points at via env vars (handled elsewhere
    # in the codebase). For the smoke test the in-memory backend
    # works because the snapshots fall through to empty strings when
    # the backend can't read the URL.
    blob_store = BlobStore(backend=InMemoryObjectStore())

    prompts_filter: list[str] | None = None
    if args.prompts:
        raw = [p.strip() for p in str(args.prompts).split(",") if p.strip()]
        prompts_filter = raw or None

    provider_name = _safe_provider_name(provider_b)
    queued_ids: list[str] = []

    with SessionLocal() as session:
        scan = session.get(Scan, scan_id)
        if scan is None:
            print(
                f"llm-eval: scan {scan_id} not found in DATABASE_URL",
                file=sys.stderr,
            )
            return EXIT_GENERIC_FAILURE

        # Scan-level lock check.
        if not acquire_scan_lock(session, scan_id):
            print(
                f"llm-eval: another eval is already running for scan {scan_id}; "
                "wait for it to finish or use the admin UI to inspect it",
                file=sys.stderr,
            )
            return EXIT_GENERIC_FAILURE

        # Existing-eval check (skipped under --force).
        from sqlalchemy import select as _select

        if not args.force:
            existing = session.execute(
                _select(LlmEval).where(
                    LlmEval.scan_id == scan_id,
                    LlmEval.model == provider_b,
                    LlmEval.status == "complete",
                )
            ).first()
            if existing is not None:
                print(
                    "llm-eval: complete eval exists for this (scan, model). "
                    "Pass --force to write a new history row.",
                    file=sys.stderr,
                )
                return EXIT_GENERIC_FAILURE

        # Daily cap check -- mirrors the routes/evals.py path.
        cap = resolve_daily_usd_cap()
        # CLI mode: no logged-in user, so the cap is informational
        # only (we don't filter by triggered_by_user_id). The spec
        # leaves this loose; integrators that want a strict cap should
        # use the HTTP endpoint.
        print(f"llm-eval: daily cap ${cap:.2f} (CLI mode advisory)")

        # Load the scan's prompts from S3.
        loaded = load_scan_prompts(
            session=session,
            scan_id=scan_id,
            blob_store=blob_store,
            prompts_filter=prompts_filter,
        )
        if not loaded:
            print(
                f"llm-eval: no llm_calls found for scan {scan_id}",
                file=sys.stderr,
            )
            return EXIT_GENERIC_FAILURE

        for entry in loaded:
            row = LlmEval(
                scan_id=scan_id,
                prompt_name=entry.prompt_name,
                model=provider_b,
                provider=provider_name,
                status="queued",
                triggered_by_user_id=None,
                system_prompt_snapshot=entry.system_prompt,
                user_prompt_snapshot=entry.user_prompt,
            )
            session.add(row)
            session.flush()
            queued_ids.append(row.id)
        session.commit()

    # Run inline (CLI is synchronous); background-task helper works
    # the same way against a sessionmaker.
    from contextlib import contextmanager as _ctx

    @_ctx
    def _scope() -> Any:
        s = SessionLocal()
        try:
            yield s
            s.commit()
        except Exception:
            s.rollback()
            raise
        finally:
            s.close()

    run_eval_background(queued_ids, _scope, blob_store)

    # Print summary.
    with SessionLocal() as session:
        from sqlalchemy import select as _select

        rows = (
            session.execute(_select(LlmEval).where(LlmEval.id.in_(queued_ids)))
            .scalars()
            .all()
        )
        print(f"llm-eval: wrote {len(rows)} row(s) to llm_evals")
        for row in rows:
            status = row.status
            cost = float(row.cost_usd) if row.cost_usd is not None else 0.0
            print(
                f"  {row.prompt_name:24s} {row.model:32s} "
                f"{status:10s} ${cost:.6f} {row.latency_ms}ms"
            )
        # Suppress unused-import warning under -O.
        _ = _dt.now(_UTC)
    return EXIT_OK


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------


def main(argv: list[str] | None = None) -> int:
    """CLI entry point. Returns the exit code."""
    parser = _build_parser()
    args = parser.parse_args(argv)

    if args.command is None:
        parser.print_help()
        return EXIT_OK

    if args.command == "version":
        return _cmd_version()

    if args.command == "scan":
        return _cmd_scan(args)

    if args.command == "list":
        return _cmd_list(args)

    if args.command == "stop":
        return _cmd_stop(args)

    if args.command == "login":
        return cmd_login(args)

    if args.command == "retry-section":
        return _cmd_retry_section(args)

    if args.command == "rerun-stage":
        return _cmd_rerun_stage(args)

    if args.command == "llm-eval":
        return _cmd_llm_eval(args)

    parser.print_help()
    return EXIT_OK


if __name__ == "__main__":
    raise SystemExit(main())
