"""URL helpers for the CLI -- eTLD+1 normalisation.

The :func:`extract_etld_plus_one` helper takes a URL the user typed (or
just a hostname) and returns its registrable domain ("eTLD+1").
Examples:

* ``https://www.walmart.com/foo`` -> ``walmart.com``
* ``https://walmart.com``        -> ``walmart.com``
* ``https://api.example.co.uk/`` -> ``example.co.uk``
* ``https://example.com.au/``    -> ``example.com.au``
* ``localhost``                  -> ``localhost``
* ``127.0.0.1``                  -> ``127.0.0.1``
* ``""`` / malformed             -> ``""`` / input as-is

Why a stdlib helper instead of ``tldextract``? ``tldextract`` is the
robust answer (it ships the full Mozilla Public Suffix List), but it
isn't already a transitive dep, and the spec for fix #2 says: don't add
``tldextract`` just for this. A small curated suffix table is fine for
Phase 1; we cover the common ``.co.uk`` / ``.com.au`` / etc. compound
suffixes plus the long tail of single-segment public suffixes.

If the curated list ever grows uncomfortable, swap this module for a
``tldextract`` shim -- callers depend only on the ``extract_etld_plus_one``
signature.
"""

from __future__ import annotations

from urllib.parse import urlsplit

__all__ = ["extract_etld_plus_one"]


# Known multi-segment public suffixes (eTLDs that span 2+ DNS labels).
# Curated subset: covers the suffixes most likely to appear in a scraping
# target (commerce sites in UK, Australia, India, Japan, Brazil, etc.).
# When the public suffix actually spans 3 labels (e.g. ``parliament.uk``)
# we add it here too -- the lookup tries the longest match first.
#
# This is intentionally NOT exhaustive. The full PSL has ~9k entries
# we don't need; the cost of a wrong answer here is "the report header
# says ``api.example.co.uk`` instead of ``example.co.uk``", which is
# survivable.
_MULTI_PART_SUFFIXES: frozenset[str] = frozenset(
    {
        # United Kingdom
        "co.uk",
        "org.uk",
        "ac.uk",
        "gov.uk",
        "ltd.uk",
        "me.uk",
        "net.uk",
        "nhs.uk",
        "plc.uk",
        "sch.uk",
        # Australia
        "com.au",
        "net.au",
        "org.au",
        "edu.au",
        "gov.au",
        "id.au",
        # New Zealand
        "co.nz",
        "net.nz",
        "org.nz",
        "ac.nz",
        "govt.nz",
        # India
        "co.in",
        "net.in",
        "org.in",
        "ac.in",
        "gov.in",
        "firm.in",
        # Japan
        "co.jp",
        "ne.jp",
        "or.jp",
        "ac.jp",
        "go.jp",
        # Brazil
        "com.br",
        "net.br",
        "org.br",
        "gov.br",
        # South Africa
        "co.za",
        "net.za",
        "org.za",
        "ac.za",
        "gov.za",
        # Singapore
        "com.sg",
        "net.sg",
        "org.sg",
        "edu.sg",
        "gov.sg",
        # Hong Kong
        "com.hk",
        "net.hk",
        "org.hk",
        "edu.hk",
        "gov.hk",
        # Mexico
        "com.mx",
        "net.mx",
        "org.mx",
        "edu.mx",
        "gob.mx",
        # Korea (rep.)
        "co.kr",
        "ne.kr",
        "or.kr",
        "go.kr",
        "re.kr",
        # Israel
        "co.il",
        "net.il",
        "org.il",
        "ac.il",
        "gov.il",
        # Argentina
        "com.ar",
        "net.ar",
        "org.ar",
        "edu.ar",
        "gov.ar",
        # Colombia
        "com.co",
        "net.co",
        "org.co",
        "edu.co",
        "gov.co",
        # Turkey
        "com.tr",
        "net.tr",
        "org.tr",
        "edu.tr",
        "gov.tr",
        # Russia
        "com.ru",
        "net.ru",
        "org.ru",
    }
)


def _looks_like_ip(host: str) -> bool:
    """Return True if ``host`` is an IPv4 dotted-quad or an IPv6 literal.

    IPs have no eTLD+1; we return them verbatim. Lightweight check; we
    don't need full validation -- ``ipaddress.ip_address`` would raise
    on edge cases we don't care to distinguish here.
    """
    if ":" in host:  # IPv6
        return True
    parts = host.split(".")
    if len(parts) != 4:
        return False
    return all(p.isdigit() and 0 <= int(p) <= 255 for p in parts)


def _hostname_from_url(url: str) -> str:
    """Pull out the hostname from ``url``. Tolerates raw hostnames too.

    ``urlsplit`` returns an empty hostname for inputs missing a scheme
    (e.g. ``walmart.com``); fall back to splitting on ``/`` to recover
    the host portion in those cases.
    """
    if not url:
        return ""
    try:
        parts = urlsplit(url)
    except ValueError:
        return ""
    host = parts.hostname or ""
    if host:
        return host
    # urlsplit gave us nothing (no scheme). Fall back to manual parsing.
    candidate = url.strip()
    # Strip any leading scheme-like prefix the user typed without ``//``.
    if "://" in candidate:
        candidate = candidate.split("://", 1)[1]
    # Drop path / query / fragment.
    for sep in ("/", "?", "#"):
        if sep in candidate:
            candidate = candidate.split(sep, 1)[0]
    # Drop userinfo (``user:pass@host``) and port.
    if "@" in candidate:
        candidate = candidate.rsplit("@", 1)[1]
    if candidate.startswith("["):
        # bracketed IPv6 literal without scheme
        end = candidate.find("]")
        if end != -1:
            return candidate[1:end].lower()
    if ":" in candidate and candidate.count(":") == 1:
        candidate = candidate.split(":", 1)[0]
    return candidate.lower()


def extract_etld_plus_one(url: str) -> str:
    """Return the eTLD+1 (registrable domain) of ``url``.

    Behaviour:

    * ``https://www.walmart.com/foo`` -> ``"walmart.com"``
    * ``https://walmart.com``        -> ``"walmart.com"``
    * ``https://api.example.co.uk/`` -> ``"example.co.uk"``
    * ``walmart.com``                -> ``"walmart.com"`` (raw host)
    * ``localhost``                  -> ``"localhost"``
    * ``127.0.0.1``                  -> ``"127.0.0.1"``
    * ``""`` or unparseable          -> ``""`` / verbatim input
    * Trailing ``.`` (FQDN form)     -> stripped before matching

    We never raise. The CLI passes whatever the user typed; a wrong
    answer is preferable to a crash.
    """
    if not isinstance(url, str) or not url.strip():
        return ""

    host = _hostname_from_url(url).strip().lower().rstrip(".")
    if not host:
        return url

    if host == "localhost":
        return "localhost"

    if _looks_like_ip(host):
        return host

    parts = host.split(".")
    if len(parts) <= 1:
        # Bare hostname with no dot -- return as-is.
        return host

    # Try the longest known multi-part suffix first (3-segment, then
    # 2-segment). If neither matches, treat the rightmost single segment
    # as the public suffix (the common ``.com`` / ``.io`` / ``.dev``
    # case).
    if len(parts) >= 3:
        three_seg = ".".join(parts[-3:])
        if three_seg in _MULTI_PART_SUFFIXES:
            # eTLD+1 = the segment to the left of the 3-segment suffix
            # plus the suffix itself.
            if len(parts) >= 4:
                return ".".join(parts[-4:])
            # Only 3 segments and they ARE the suffix: nothing to add.
            return three_seg

    if len(parts) >= 2:
        two_seg = ".".join(parts[-2:])
        if two_seg in _MULTI_PART_SUFFIXES:
            if len(parts) >= 3:
                return ".".join(parts[-3:])
            return two_seg

    # Default: last two segments.
    return ".".join(parts[-2:])
