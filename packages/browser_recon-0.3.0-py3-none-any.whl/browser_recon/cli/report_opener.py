"""Open a URL in the user's default browser. Isolated for testability.

Wraps :func:`webbrowser.open` so the rest of the CLI can swap in a mock
during tests and so a single ``--no-open`` flag can short-circuit the
behaviour without sprinkling conditionals around the call sites.
"""

from __future__ import annotations

import logging
import webbrowser

logger = logging.getLogger(__name__)


def open_in_browser(url: str, *, suppress: bool = False) -> bool:
    """Open ``url`` in the default browser unless ``suppress`` is True.

    Returns ``True`` if the browser was instructed to open (or would
    have been but for ``suppress``); ``False`` on backend failure.
    """
    if suppress:
        logger.debug("Browser open suppressed for %s", url)
        return True
    try:
        return webbrowser.open(url)
    except webbrowser.Error as exc:
        logger.warning("Could not open browser: %s", exc)
        return False
