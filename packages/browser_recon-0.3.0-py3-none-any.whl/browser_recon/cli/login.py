"""``recon login`` -- validate an API key and persist it to ``config.toml``.

The CLI side of the auth flow. The expected user journey:

1. Sign into the dashboard with a real email (magic-link).
2. Copy the ``rec_live_...`` API key shown on the callback page.
3. Run ``recon login --api-key <key>`` (or run ``recon login`` and paste
   when prompted -- the prompt uses :func:`getpass.getpass` so the key
   never lands in shell history).

The subcommand calls :func:`fetch_account_summary` (``GET /auth/me``)
to confirm the key is real and unrevoked. On success it writes a
minimal ``[server]`` + ``[auth]`` ``config.toml`` via
:func:`init_config` and prints the resolved account email + remaining
scan credits. Subsequent ``recon scan`` / ``recon list`` invocations
pick up the new credentials automatically.

Exit codes:

* ``0`` -- success (or idempotent re-run with an identical key).
* ``1`` -- invalid key, network error, or refusal to overwrite an
  existing different key without ``--force``.
"""

from __future__ import annotations

import argparse
import getpass
import sys
from pathlib import Path

from browser_recon.cli.config import (
    Config,
    default_config_path,
    init_config,
    load_config,
)
from browser_recon.transport.uploader import (
    AccountSummary,
    UploadAuthError,
    UploadError,
    UploadNetworkError,
    fetch_account_summary,
)

#: Exit code returned for any failure that ``recon login`` distinguishes
#: from a clean shutdown (invalid key, network, refusal-without-force).
#: Kept as a module constant so tests can import it instead of pinning
#: a magic ``1`` literal.
EXIT_FAIL = 1


def _read_api_key(args: argparse.Namespace) -> str:
    """Resolve the API key from ``--api-key`` or an interactive prompt.

    The prompt uses :func:`getpass.getpass` so the key isn't echoed and
    doesn't show up in shell history -- worth the extra UX nuance for
    a credential that survives indefinitely.
    """
    # ``argparse.Namespace`` attribute access yields ``Any``; coerce
    # to ``str`` so the function's declared return type is honoured
    # without a downstream ``Any`` leak (mypy --strict).
    if args.api_key is not None:
        key = str(args.api_key).strip()
    else:
        try:
            key = getpass.getpass("API key: ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nlogin cancelled.", file=sys.stderr)
            raise SystemExit(EXIT_FAIL) from None
    if not key:
        print(
            "error: API key cannot be empty. Get one from <server>/dashboard.",
            file=sys.stderr,
        )
        raise SystemExit(EXIT_FAIL)
    if not key.startswith("rec_live_"):
        # Soft warning -- the server is the source of truth, but the
        # caller almost certainly mis-pasted (e.g. grabbed the wrong
        # value from the dashboard page).
        print(
            "warning: API keys normally start with 'rec_live_'. "
            "Continuing anyway -- the server will reject if invalid.",
            file=sys.stderr,
        )
    return key


def _resolve_server_url(args: argparse.Namespace, cfg: Config) -> str:
    """Pick the server URL: ``--server`` → existing config → default."""
    # See ``_read_api_key`` for the ``str()`` rationale -- argparse
    # attributes are typed ``Any``.
    if args.server is not None:
        return str(args.server).rstrip("/")
    return cfg.server_url.rstrip("/")


def _refuse_overwrite_without_force(
    args: argparse.Namespace,
    cfg: Config,
    new_key: str,
    config_target: Path,
) -> None:
    """Bail if ``config.toml`` holds a different key and ``--force`` is
    absent. An identical key is treated as idempotent (silent OK).
    """
    if not config_target.exists():
        return
    existing = (cfg.api_key or "").strip()
    if not existing:
        return
    if existing == new_key:
        # Idempotent re-run; let the caller short-circuit.
        return
    if not args.force:
        print(
            f"error: {config_target} already contains an API key. "
            "Re-run with --force to overwrite.",
            file=sys.stderr,
        )
        raise SystemExit(EXIT_FAIL)


def _validate_with_server(*, server_url: str, api_key: str) -> AccountSummary:
    """Hit ``GET /auth/me`` and translate transport errors into stderr
    messages with non-zero exit codes."""
    try:
        return fetch_account_summary(server_url=server_url, api_key=api_key)
    except UploadAuthError:
        print(
            f"error: API key rejected by {server_url}. "
            "Get a fresh one from /dashboard.",
            file=sys.stderr,
        )
        raise SystemExit(EXIT_FAIL) from None
    except UploadNetworkError as exc:
        print(f"error: could not reach server: {exc}", file=sys.stderr)
        raise SystemExit(EXIT_FAIL) from None
    except UploadError as exc:
        # Catch-all for 5xx, malformed body, etc.
        print(f"error: server returned {exc}", file=sys.stderr)
        raise SystemExit(EXIT_FAIL) from None


def cmd_login(args: argparse.Namespace) -> int:
    """Top-level handler for ``recon login``.

    Returns the exit code expected by ``main`` (0 on success, non-zero
    on failure). Failures inside the helpers raise :class:`SystemExit`
    directly so we don't have to thread error codes through every
    return path.
    """
    config_target = (
        Path(args.config).expanduser() if args.config else default_config_path()
    )

    try:
        cfg = load_config(args.config) if config_target.exists() else Config()
    except FileNotFoundError:
        # ``--config /tmp/missing.toml`` -- treat as a fresh write target.
        cfg = Config()

    api_key = _read_api_key(args)
    server_url = _resolve_server_url(args, cfg)
    _refuse_overwrite_without_force(args, cfg, api_key, config_target)

    # Idempotent: same key already present, just print a friendly note.
    if (cfg.api_key or "").strip() == api_key and config_target.exists():
        print(f"Already signed in. Config: {config_target}")
        return 0

    summary = _validate_with_server(server_url=server_url, api_key=api_key)

    written = init_config(
        config_target,
        server_url=server_url,
        api_key=api_key,
    )

    plural = "credit" if summary.scan_credits == 1 else "credits"
    print(
        f"Signed in as {summary.email}. {summary.scan_credits} scan {plural} remaining."
    )
    print(f"Config: {written}")
    return 0


def add_login_subparser(
    subparsers: argparse._SubParsersAction[argparse.ArgumentParser],
) -> None:
    """Register the ``login`` subcommand on the top-level parser."""
    login_parser = subparsers.add_parser(
        "login",
        help="Validate an API key and store it in config.toml.",
    )
    login_parser.add_argument(
        "--api-key",
        default=None,
        help="API key to store. If omitted, prompts interactively (hidden).",
    )
    login_parser.add_argument(
        "--server",
        default=None,
        help="API server URL. Defaults to existing config or built-in default.",
    )
    login_parser.add_argument(
        "--config",
        default=None,
        help="Path to write config.toml (default: ~/.browser-recon/config.toml).",
    )
    login_parser.add_argument(
        "--force",
        action="store_true",
        help="Overwrite an existing api_key in config.toml without prompting.",
    )


__all__ = ["add_login_subparser", "cmd_login"]
