"""CLI subpackage for browser-recon."""
