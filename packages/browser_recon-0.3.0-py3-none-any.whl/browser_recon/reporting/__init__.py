"""Reporting subpackage.

Hosts shared formatting helpers (currently
:mod:`browser_recon.reporting.duration`). T53.6 moved the local
Markdown report renderer to ``browser_recon_server.markdown_renderer``;
the renderer is no longer wired into the CLI.
"""
