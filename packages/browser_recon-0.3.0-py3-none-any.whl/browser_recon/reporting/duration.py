"""Human-readable duration formatting for scan timing fields (fix #4).

The local-Markdown report and the hosted HTML report both surface the
four scan-phase timings (capture, validation, scrub+upload, total
wall-clock). Both renderers run the values through
:func:`format_duration` so the formatting stays consistent across
surfaces.

The single sentinel value is ``None`` -- used both for "phase did not
run" (e.g. ``--no-validation``) and for "old blob without timings".
Renderers map ``None`` to a context-appropriate label ("skipped" for
validation, em-dash for everything else) before calling this formatter
on the numeric values.
"""

from __future__ import annotations

__all__ = ["format_duration"]


def format_duration(seconds: float | None) -> str:
    """Format a duration in seconds for the report metadata block.

    Output bands:
        * ``None``        -> ``"—"`` (em-dash; "no value")
        * ``< 60``        -> ``"X.Xs"`` (one decimal, e.g. ``"5.7s"``)
        * ``< 3600``      -> ``"Xm Ys"`` (rounded to whole seconds,
          e.g. ``"4m 40s"``)
        * ``>= 3600``     -> ``"Xh Ym"`` (rounded to whole minutes,
          e.g. ``"2h 15m"``)

    Negative values are clamped to ``0.0s`` (defence against clock skew
    on systems where ``time.monotonic()`` deltas come back slightly
    negative due to fp rounding -- shouldn't happen but a 0.0 floor is
    cheaper than a stack trace in the report renderer).
    """
    if seconds is None:
        return "—"
    if seconds < 0:
        seconds = 0.0
    if seconds < 60:
        return f"{seconds:.1f}s"
    if seconds < 3600:
        m, s = divmod(int(round(seconds)), 60)
        return f"{m}m {s}s"
    h, rem = divmod(int(round(seconds)), 3600)
    m, _ = divmod(rem, 60)
    return f"{h}h {m}m"
