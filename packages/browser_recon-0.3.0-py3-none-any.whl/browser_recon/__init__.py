"""browser-recon: scan a URL and produce a scraping reconnaissance report."""

__version__: str = "0.3.0"
