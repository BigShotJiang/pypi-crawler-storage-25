"""Cost cap enforcement for ``recon llm-eval`` (T46).

The eval harness must never silently blow past the user's
``--confirm-spend`` cap. :class:`CostTracker` accumulates per-call cost
and exposes :meth:`reserve` -- callers invoke it BEFORE each provider
call with the projected cost of the imminent call; if accumulated +
projected would exceed the cap, the tracker raises
:class:`CostCapExceeded` and the run aborts.

The tracker is also used in dry-run mode to project total cost without
enforcing -- dry runs always have ``cap_usd=None``.
"""

from __future__ import annotations

from dataclasses import dataclass, field


class CostCapExceeded(RuntimeError):
    """Raised when reserving a projected cost would breach the cap.

    Carries the projected vs. would-be-total so the CLI can surface a
    clear message in the report header (``status: aborted (cap hit)``)
    and exit non-zero.
    """

    def __init__(
        self,
        *,
        cap_usd: float,
        accumulated_usd: float,
        projected_usd: float,
    ) -> None:
        self.cap_usd = cap_usd
        self.accumulated_usd = accumulated_usd
        self.projected_usd = projected_usd
        super().__init__(
            f"Spend cap ${cap_usd:.4f} would be exceeded: "
            f"accumulated=${accumulated_usd:.4f} + "
            f"projected=${projected_usd:.4f}"
        )


@dataclass
class CostTracker:
    """Accumulator that enforces a hard USD cap.

    ``cap_usd=None`` (the dry-run case) disables enforcement; the
    tracker still records per-provider totals so the report can show
    "projected" cost.
    """

    cap_usd: float | None
    _accumulated: float = 0.0
    _per_provider: dict[str, float] = field(default_factory=dict)

    @property
    def total_usd(self) -> float:
        return self._accumulated

    @property
    def per_provider(self) -> dict[str, float]:
        """Read-only view of per-provider totals (defensive copy)."""
        return dict(self._per_provider)

    def reserve(self, *, provider: str, projected_usd: float) -> None:
        """Check that adding ``projected_usd`` to the accumulated total
        stays within the cap.

        Raises :class:`CostCapExceeded` when ``cap_usd`` is set and the
        next call would breach it. The tracker is NOT mutated on a
        breach so the caller can record the aborted state without a
        partial increment.

        ``projected_usd`` is the dispatcher's pre-call cost estimate
        derived from ``compute_cost(model, usage_estimate)``. The
        post-call true cost lands via :meth:`record`.
        """
        if self.cap_usd is None:
            return
        if self._accumulated + projected_usd > self.cap_usd + 1e-9:
            raise CostCapExceeded(
                cap_usd=self.cap_usd,
                accumulated_usd=self._accumulated,
                projected_usd=projected_usd,
            )

    def record(self, *, provider: str, cost_usd: float) -> None:
        """Add the post-call true cost to the accumulator + per-provider total.

        Always called with the real ``LLMResponse.cost_usd`` after a
        successful provider call. Dry-run mode calls this with the
        projected cost so the report can show a single "spent / projected"
        column without forking the table renderer.
        """
        self._accumulated += cost_usd
        self._per_provider[provider] = self._per_provider.get(provider, 0.0) + cost_usd


__all__ = ["CostCapExceeded", "CostTracker"]
