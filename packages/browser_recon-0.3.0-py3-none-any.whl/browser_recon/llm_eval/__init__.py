"""Side-by-side LLM provider eval harness (T46).

The ``recon llm-eval`` CLI subcommand replays the same fixture capture
through two providers (typically Claude vs an OpenAI / Grok model) so
we can compare cost / latency / output shape on real prompts without
running a full scan against each provider.

The harness is a HARNESS ONLY -- actual cross-provider eval runs
require live API keys and manual review (a HUMAN follow-up step). The
runner aborts unless one of these is set explicitly:

* ``--dry-run`` -- compute projected cost only; no API calls.
* ``--confirm-spend USD`` -- hard cap on accumulated cost; aborts mid
  run if the next call would exceed it.

Nothing under :mod:`browser_recon.llm_eval` touches the production
scan pipeline -- it loads the fixture into a synthetic
``synthesis_input`` dict and feeds it into the existing prompt
modules. The result is a Markdown report at
``<output-dir>/eval.md`` plus per-prompt JSON dumps.
"""

from __future__ import annotations

from browser_recon.llm_eval.cost_tracker import CostCapExceeded, CostTracker
from browser_recon.llm_eval.fixtures import (
    PROMPT_BUILDERS,
    VALID_PROMPT_NAMES,
    FixtureNotFoundError,
    load_fixture_capture,
)
from browser_recon.llm_eval.report import render_eval_markdown
from browser_recon.llm_eval.runner import EvalRunner, EvalRunResult, PromptEvalRow

__all__ = [
    "CostCapExceeded",
    "CostTracker",
    "EvalRunResult",
    "EvalRunner",
    "FixtureNotFoundError",
    "PROMPT_BUILDERS",
    "PromptEvalRow",
    "VALID_PROMPT_NAMES",
    "load_fixture_capture",
    "render_eval_markdown",
]
