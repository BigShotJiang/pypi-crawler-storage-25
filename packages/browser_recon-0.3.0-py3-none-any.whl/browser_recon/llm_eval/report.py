"""Markdown report renderer for ``recon llm-eval`` (T46).

Produces ``eval.md`` with a header (fixture, providers, spend cap,
status) and one section per prompt that contains:

* Per-provider metrics table (input tokens, output tokens, cost,
  latency).
* "Recommendation differences" -- a short bullet list highlighting
  per-field divergence between providers A and B.
* Relative links to the raw JSON dumps so the reviewer can drill in.

The renderer is pure: it takes :class:`PromptEvalRow` instances from
:mod:`browser_recon.llm_eval.runner` and returns a string. No
filesystem I/O happens here -- the caller writes the result wherever
it wants.
"""

from __future__ import annotations

from collections.abc import Iterable, Mapping
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:  # pragma: no cover -- typing-only
    from browser_recon.llm_eval.runner import EvalRunResult, PromptEvalRow


def render_eval_markdown(result: EvalRunResult) -> str:
    """Render the full eval report.

    ``result.status`` reads ``"completed"`` on a clean run,
    ``"dry-run"`` when no API calls fired, or ``"aborted (cap hit)"``
    when the cost cap tripped mid-run.
    """
    parts: list[str] = []
    parts.append(_render_header(result))
    parts.append("\n---\n")
    for row in result.rows:
        parts.append(_render_prompt_section(row, mode=result.mode))
        parts.append("\n---\n")
    # Trim the trailing separator so the doc ends with content.
    while parts and parts[-1].strip() == "---":
        parts.pop()
    return "".join(parts).rstrip() + "\n"


def _render_header(result: EvalRunResult) -> str:
    cap = (
        f"${result.spend_cap_usd:.2f}"
        if result.spend_cap_usd is not None
        else "(dry-run)"
    )
    total = result.cost_tracker.total_usd
    per_provider = result.cost_tracker.per_provider
    a_cost = per_provider.get(result.provider_a, 0.0)
    b_cost = per_provider.get(result.provider_b, 0.0)
    spent_line = (
        f"**Total {'projected' if result.mode == 'dry-run' else 'spent'}:** "
        f"${total:.4f} "
        f"(A: ${a_cost:.4f}, B: ${b_cost:.4f})"
    )
    lines: list[str] = [
        f"# LLM Eval Report — {result.started_at}",
        "",
        f"**Fixture:** {result.fixture_name}",
        f"**Provider A:** {result.provider_a}",
        f"**Provider B:** {result.provider_b}",
        f"**Spend cap:** {cap}",
        f"**Mode:** {result.mode}",
        spent_line,
        f"**Status:** {result.status}",
    ]
    if result.abort_reason:
        lines.append(f"**Abort reason:** {result.abort_reason}")
    return "\n".join(lines) + "\n"


def _render_prompt_section(row: PromptEvalRow, *, mode: str) -> str:
    lines: list[str] = []
    lines.append(f"## {row.prompt_name}\n")

    # Metrics table.
    lines.append(
        "| Metric | " + row.provider_a_model + " | " + row.provider_b_model + " |"
    )
    lines.append("|---|---|---|")
    a = row.provider_a_metrics
    b = row.provider_b_metrics
    if mode == "dry-run":
        a_in = a["input_tokens"]
        b_in = b["input_tokens"]
        a_out = a["output_tokens"]
        b_out = b["output_tokens"]
        lines.append(f"| Input tokens (est.) | {a_in:,} | {b_in:,} |")
        lines.append(f"| Output tokens (proj.) | {a_out:,} | {b_out:,} |")
        lines.append(
            f"| Cost (projected) | ${a['cost_usd']:.4f} | ${b['cost_usd']:.4f} |"
        )
        lines.append("| Latency | n/a | n/a |")
    else:
        lines.append(
            f"| Input tokens | {a['input_tokens']:,} | {b['input_tokens']:,} |"
        )
        lines.append(
            f"| Output tokens | {a['output_tokens']:,} | {b['output_tokens']:,} |"
        )
        lines.append(f"| Cost | ${a['cost_usd']:.4f} | ${b['cost_usd']:.4f} |")
        lines.append(f"| Latency | {a['latency_ms']:,} ms | {b['latency_ms']:,} ms |")
    lines.append("")

    # Diff section.
    diff_block = _render_diff_block(row)
    if diff_block:
        lines.append("### Output differences\n")
        lines.append(diff_block)
        lines.append("")

    # Errors (if either provider failed).
    if row.provider_a_error or row.provider_b_error:
        lines.append("### Errors\n")
        if row.provider_a_error:
            lines.append(f"- A ({row.provider_a_model}): `{row.provider_a_error}`")
        if row.provider_b_error:
            lines.append(f"- B ({row.provider_b_model}): `{row.provider_b_error}`")
        lines.append("")

    # Links to raw dumps.
    if row.provider_a_dump_path or row.provider_b_dump_path:
        link_a = (
            f"[Full output A]({row.provider_a_dump_path})"
            if row.provider_a_dump_path
            else "(no output A)"
        )
        link_b = (
            f"[Full output B]({row.provider_b_dump_path})"
            if row.provider_b_dump_path
            else "(no output B)"
        )
        lines.append(f"{link_a} · {link_b}")
        lines.append("")
    return "\n".join(lines)


def _render_diff_block(row: PromptEvalRow) -> str:
    """Emit a bullet list of per-field divergences between A and B.

    For dry-run rows (no parsed outputs), this returns an empty string
    so the section header is suppressed.

    For live rows where one side errored, we still surface the
    populated side so the reviewer sees what came back.
    """
    a_payload = row.provider_a_parsed
    b_payload = row.provider_b_parsed
    if a_payload is None and b_payload is None:
        return ""

    a_summary = _summarise_payload(a_payload)
    b_summary = _summarise_payload(b_payload)

    lines: list[str] = []
    all_keys = sorted(set(a_summary) | set(b_summary))
    diffs_seen = False
    for key in all_keys:
        a_val = a_summary.get(key, "<missing>")
        b_val = b_summary.get(key, "<missing>")
        if a_val == b_val:
            continue
        diffs_seen = True
        lines.append(f"- `{key}`: A={a_val!r} vs B={b_val!r}")
    if not diffs_seen:
        lines.append("- (no per-field differences detected)")
    return "\n".join(lines)


def _summarise_payload(payload: Mapping[str, Any] | None) -> dict[str, Any]:
    """Pick the load-bearing scalar fields out of a parsed Pydantic dump.

    Most prompt outputs are nested dicts (recommendation, verdict,
    starter_code, drivers list, ...). For the eval report we surface
    the top-level scalars + a handful of well-known nested keys so the
    reviewer can eyeball "did A and B agree on primary_library?" without
    scrolling through the raw JSON.
    """
    if payload is None:
        return {}
    summary: dict[str, Any] = {}
    for key, value in payload.items():
        if isinstance(value, (str, int, float, bool)) or value is None:
            summary[key] = value
        elif isinstance(value, dict):
            # One-level descent for nested objects so we surface
            # recommendation.primary_library / recommendation.confidence
            # etc. without dumping the whole tree.
            for sub_key, sub_value in value.items():
                if isinstance(sub_value, (str, int, float, bool)) or sub_value is None:
                    summary[f"{key}.{sub_key}"] = sub_value
        elif isinstance(value, list):
            summary[f"{key}.count"] = len(value)
    return summary


__all__ = ["render_eval_markdown"]


# Public for tests: bundle of helpers a caller might want.
def render_diff_block(row: PromptEvalRow) -> str:
    """Public alias of :func:`_render_diff_block` for testing."""
    return _render_diff_block(row)


def summarise_payload(payload: Mapping[str, Any] | None) -> dict[str, Any]:
    """Public alias of :func:`_summarise_payload` for testing."""
    return _summarise_payload(payload)


def _ensure_unused(_: Iterable[Any]) -> None:
    """Silences linters about unused imports we want available for typing."""
    return None
