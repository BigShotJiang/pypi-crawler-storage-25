"""Load a persisted scan's LLM calls into eval-ready request objects (T48).

The fixture-based eval harness (T46) builds prompts from a captured
``recon_capture.json`` blob; the scan-replay path lifts the **exact**
system + user text that production sent for a real scan. That lets
operators ask "would running this same scan against grok-3-mini have
produced a better recommendation?" without re-running the entire
capture + analysis pipeline.

The loader is intentionally lightweight: it speaks SQLAlchemy + the
blob store but does NOT pull the analysis / detection layers. The CLI
already constructed those payloads when the scan ran; we just re-read
them out of the existing dumps.
"""

from __future__ import annotations

import gzip
import json
import logging
from dataclasses import dataclass
from typing import Any

from sqlalchemy import select
from sqlalchemy.orm import Session

from browser_recon_server.models import LlmCall
from browser_recon_server.storage import BlobStore

logger = logging.getLogger(__name__)


@dataclass
class LoadedScanPrompt:
    """One prompt's persisted system + user text + production result."""

    prompt_name: str
    prompt_version: str
    model: str  # the model production used (provider A in the spec)
    provider: str  # ditto, populated from ``llm_calls.provider``
    system_prompt: str
    user_prompt: str
    response_body: dict[str, Any] | None  # production response, for diff view
    cost_usd: float
    latency_ms: int
    input_tokens: int
    output_tokens: int


def load_scan_prompts(
    *,
    session: Session,
    scan_id: str,
    blob_store: BlobStore,
    prompts_filter: list[str] | None = None,
) -> list[LoadedScanPrompt]:
    """Fetch each ``llm_calls`` row for the scan + read its S3 dump.

    Returns one :class:`LoadedScanPrompt` per row. Failures (missing
    dump, malformed JSON) drop the row with a warning -- the caller
    decides whether a partial replay is acceptable. ``prompts_filter``
    restricts the result to the named prompts when set (CLI
    ``--prompts`` plumb-through).

    Multiple calls per prompt (retry path) collapse to the most recent
    success: we sort by ``created_at`` descending and take the first
    error-free row per ``prompt_name``.
    """
    stmt = (
        select(LlmCall)
        .where(LlmCall.scan_id == scan_id)
        .order_by(LlmCall.created_at.desc())
    )
    rows = session.execute(stmt).scalars().all()
    by_prompt: dict[str, LlmCall] = {}
    for row in rows:
        if prompts_filter and row.prompt_name not in prompts_filter:
            continue
        if row.prompt_name in by_prompt:
            continue
        # Prefer success rows; skip error rows unless they're all we have.
        if row.error_class is not None:
            by_prompt.setdefault(row.prompt_name, row)
            continue
        by_prompt[row.prompt_name] = row

    out: list[LoadedScanPrompt] = []
    backend = getattr(blob_store, "_backend", None)
    for prompt_name, row in by_prompt.items():
        if backend is None or not row.s3_prompt_path:
            logger.warning(
                "scan_loader: no backend or s3_prompt_path for %s; skipping",
                prompt_name,
            )
            continue
        try:
            payload = backend.get(row.s3_prompt_path)
        except Exception:  # noqa: BLE001
            logger.exception(
                "scan_loader: backend fetch failed for %s url=%s",
                prompt_name,
                row.s3_prompt_path,
            )
            continue
        try:
            decoded = gzip.decompress(payload)
        except Exception:  # noqa: BLE001
            decoded = payload
        try:
            parsed = json.loads(decoded.decode("utf-8"))
        except Exception:  # noqa: BLE001
            logger.exception(
                "scan_loader: dump not JSON for %s url=%s",
                prompt_name,
                row.s3_prompt_path,
            )
            continue
        if not isinstance(parsed, dict):
            continue
        system_text = (
            parsed.get("system") if isinstance(parsed.get("system"), str) else ""
        )
        user_text = parsed.get("user") if isinstance(parsed.get("user"), str) else ""
        response_body = (
            parsed.get("response") if isinstance(parsed.get("response"), dict) else None
        )
        out.append(
            LoadedScanPrompt(
                prompt_name=prompt_name,
                prompt_version=row.prompt_version,
                model=row.model,
                provider=row.provider or "anthropic",
                system_prompt=str(system_text or ""),
                user_prompt=str(user_text or ""),
                response_body=response_body,
                cost_usd=float(row.cost_usd) if row.cost_usd is not None else 0.0,
                latency_ms=row.latency_ms,
                input_tokens=row.input_tokens,
                output_tokens=row.output_tokens,
            )
        )
    return out


__all__ = ["LoadedScanPrompt", "load_scan_prompts"]
