"""Fixture loaders + per-prompt ``LLMRequest`` builders (T46).

Each ``recon llm-eval`` invocation needs to:

1. Load ``tests/fixtures/captures/<name>/recon_capture.json``.
2. Run the local-only detection + analysis layers against the sanitised
   capture so the synthesis prompts get realistic inputs.
3. For each requested prompt, build an :class:`LLMRequest` whose
   ``system`` and ``user`` strings match what the production pipeline
   would have sent.

The builders below mirror what
:func:`browser_recon_server.scan_pipeline.run_pipeline` does for the
real synthesis stage, minus the database and orchestration glue. They
return ``LLMRequest`` instances with a "neutral" model field; the
runner overrides ``model`` per provider before dispatch.

This module is import-safe -- it does not import SQLAlchemy, the route
handlers, or any code that pulls a live DB. The synthesis_input
adapter only reads ``target_url`` / ``target_domain`` / ``intent_text``
/ ``starter_template`` / ``clarifying_qa`` off the scan object, so a
small duck-typed stand-in is enough.
"""

from __future__ import annotations

import json
from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from browser_recon_server.analysis_server.orchestrator import run_analysis
from browser_recon_server.detection_server.orchestrator import run_detection
from browser_recon_server.llm.types import DEFAULT_MAX_TOKENS, LLMRequest
from browser_recon_server.prompts import (
    difficulty_drivers as difficulty_drivers_prompt,
)
from browser_recon_server.prompts import (
    intent_filter as intent_filter_prompt,
)
from browser_recon_server.prompts import (
    notes as notes_prompt,
)
from browser_recon_server.prompts import (
    scan_synthesis as scan_synthesis_prompt,
)
from browser_recon_server.synthesis_input import build_synthesis_input

#: All prompt names the eval harness knows how to build. Ordered so the
#: default ``--prompts`` value covers the four T46 acceptance prompts.
VALID_PROMPT_NAMES: tuple[str, ...] = (
    "scan_synthesis",
    "notes",
    "difficulty_drivers",
    "intent_filter",
)

#: Fixed prompt -> default-output-tokens projection. Real outputs vary;
#: 2000 tokens is a defensible upper bound for cost projection per the
#: T46 spec ("output_tokens=2000").
DEFAULT_PROJECTED_OUTPUT_TOKENS = 2000


class FixtureNotFoundError(FileNotFoundError):
    """Raised when ``tests/fixtures/captures/<name>/recon_capture.json`` is missing.

    Carries the requested fixture name + the resolved root path so the
    CLI can surface a "available fixtures: ..." hint.
    """

    def __init__(self, *, name: str, fixtures_root: Path) -> None:
        self.name = name
        self.fixtures_root = fixtures_root
        super().__init__(f"fixture {name!r} not found under {fixtures_root}")


# ---------------------------------------------------------------------------
# Fixture root resolution
# ---------------------------------------------------------------------------


def _default_fixtures_root() -> Path:
    """Return the path to ``tests/fixtures/captures/`` relative to the repo.

    Walks up from this file until it finds a ``tests`` directory, so
    the harness works both from the repo checkout and from a wheel
    install (in which case it falls back to a sensible default the
    caller can override via :func:`load_fixture_capture`'s
    ``fixtures_root`` argument).
    """
    here = Path(__file__).resolve()
    for ancestor in here.parents:
        candidate = ancestor / "tests" / "fixtures" / "captures"
        if candidate.is_dir():
            return candidate
    # Fall back to a path relative to CWD. The caller may pass an
    # explicit root via the public API instead.
    return Path("tests/fixtures/captures").resolve()


# ---------------------------------------------------------------------------
# Duck-typed Scan stand-in
# ---------------------------------------------------------------------------


@dataclass
class _LocalScan:
    """Duck-typed :class:`Scan` stand-in for the synthesis-input adapter.

    The adapter only reads the fields listed below; we intentionally do
    NOT import the real SQLAlchemy ``Scan`` model so the harness stays
    DB-free.
    """

    target_url: str
    target_domain: str
    intent_text: str | None = None
    starter_template: str = "custom"
    clarifying_qa: list[dict[str, Any]] | None = None
    # ``intent_filter.build_user_prompt`` reads through the
    # encryption-aware helpers which expect attributes on the row. The
    # helpers fall back to ``getattr(scan, ..., None)`` for legacy data;
    # default these to None so the helpers see "no encrypted payload"
    # and read ``intent_text`` / ``clarifying_qa`` directly.
    intent_text_ciphertext: bytes | None = None
    intent_text_nonce: bytes | None = None
    intent_text_key_version: int | None = None
    clarifying_qa_ciphertext: bytes | None = None
    clarifying_qa_nonce: bytes | None = None
    clarifying_qa_key_version: int | None = None


# ---------------------------------------------------------------------------
# Fixture loader
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class LoadedFixture:
    """Bundle returned by :func:`load_fixture_capture`.

    ``synthesis_input`` is the dict every prompt's ``build_user_prompt``
    reads. ``analysis`` and ``endpoints_dicts`` are surfaced for the
    intent-filter builder, which has a non-standard signature that
    takes the inventory directly rather than reading it off the dict.
    """

    name: str
    blob: dict[str, Any]
    synthesis_input: dict[str, Any]
    scan: _LocalScan
    analysis: Any  # AnalysisResult; typed Any to keep this module SQLAlchemy-free
    endpoints_dicts: list[dict[str, Any]]


def load_fixture_capture(
    name: str,
    *,
    fixtures_root: Path | None = None,
    intent_text: str | None = None,
    starter_template: str = "custom",
) -> LoadedFixture:
    """Load ``recon_capture.json`` for ``name`` and run detection + analysis.

    ``intent_text`` defaults to a stable string that lets the intent
    prompts render without surfacing empty-intent edge cases. Override
    via the kwarg when the eval should test a specific user intent.
    """
    root = fixtures_root or _default_fixtures_root()
    capture_path = root / name / "recon_capture.json"
    if not capture_path.is_file():
        raise FixtureNotFoundError(name=name, fixtures_root=root)

    sanitised = json.loads(capture_path.read_text(encoding="utf-8"))

    target_url = _extract_target_url(sanitised, name)
    target_domain = _extract_target_domain(target_url, name)

    # Build the 12-key blob shape ``build_synthesis_input`` expects.
    blob: dict[str, Any] = {
        "schema_version": 1,
        "cli_version": "llm-eval",
        "client_id": f"llm-eval-{name}",
        "target_url": target_url,
        "created_at": "2026-05-12T00:00:00+00:00",
        "rules_version": 2,
        "capture_metadata": {"mode": "llm-eval", "fixture": name},
        "scrub_manifest": {"rules_version": 2, "cookie_values_stripped": 0},
        "sanitised_capture": sanitised,
    }

    detection = run_detection(sanitised)
    analysis = run_analysis(sanitised, detection)

    scan = _LocalScan(
        target_url=target_url,
        target_domain=target_domain,
        intent_text=intent_text or f"Scrape {target_domain} data for evaluation",
        starter_template=starter_template,
        clarifying_qa=[],
    )

    synthesis_input = build_synthesis_input(
        scan=scan,  # type: ignore[arg-type]
        blob=blob,
        detection=detection,
        analysis=analysis,
        validation=None,
    )
    # The intent-aware prompts (notes / difficulty_drivers / intent_filter)
    # read ``intent_text`` / ``starter_template`` directly off the
    # synthesis_input dict. ``build_filtered_synthesis_input`` would
    # populate these, but it requires a bucket_assignment we don't have
    # yet (that's literally the output of intent_filter). Inject them
    # here so the unfiltered build path still gives the prompts the
    # intent context they expect.
    synthesis_input.setdefault("intent_text", scan.intent_text)
    synthesis_input.setdefault("starter_template", scan.starter_template)

    endpoints_dicts = list(synthesis_input.get("endpoints", []))

    return LoadedFixture(
        name=name,
        blob=blob,
        synthesis_input=synthesis_input,
        scan=scan,
        analysis=analysis,
        endpoints_dicts=endpoints_dicts,
    )


def _extract_target_url(sanitised: dict[str, Any], name: str) -> str:
    """Pull a target URL from the sanitised capture; fall back to fixture name.

    Different capture vintages stash the target URL in slightly
    different keys (``target_url`` at the top level, or nested under
    ``capture_metadata.target_url``). We probe both and fall back to a
    constructed URL so detection / analysis always have a domain to
    anchor on.
    """
    direct = sanitised.get("target_url")
    if isinstance(direct, str) and direct.strip():
        return direct
    metadata = sanitised.get("capture_metadata")
    if isinstance(metadata, dict):
        nested = metadata.get("target_url")
        if isinstance(nested, str) and nested.strip():
            return nested
    return f"https://{name}.com/"


def _extract_target_domain(target_url: str, fallback: str) -> str:
    """Best-effort eTLD+1 extraction; falls back to the fixture name."""
    if not target_url:
        return f"{fallback}.com"
    from urllib.parse import urlparse

    host = urlparse(target_url).hostname or ""
    return host or f"{fallback}.com"


# ---------------------------------------------------------------------------
# Per-prompt builders
# ---------------------------------------------------------------------------


def _build_request_scan_synthesis(fixture: LoadedFixture, *, model: str) -> LLMRequest:
    return LLMRequest(
        prompt_name=scan_synthesis_prompt.PROMPT_NAME,
        prompt_version=scan_synthesis_prompt.PROMPT_VERSION,
        system=scan_synthesis_prompt.SYSTEM_PROMPT,
        user=scan_synthesis_prompt.build_user_prompt(fixture.synthesis_input),
        output_schema=scan_synthesis_prompt.CombinedSynthesisOutput,
        model=model,
        max_tokens=DEFAULT_MAX_TOKENS,
    )


def _build_request_notes(fixture: LoadedFixture, *, model: str) -> LLMRequest:
    return LLMRequest(
        prompt_name=notes_prompt.PROMPT_NAME,
        prompt_version=notes_prompt.PROMPT_VERSION,
        system=notes_prompt.SYSTEM_PROMPT,
        user=notes_prompt.build_user_prompt(fixture.synthesis_input),
        output_schema=notes_prompt.NotesOutput,
        model=model,
        max_tokens=DEFAULT_MAX_TOKENS,
    )


def _build_request_difficulty_drivers(
    fixture: LoadedFixture, *, model: str
) -> LLMRequest:
    return LLMRequest(
        prompt_name=difficulty_drivers_prompt.PROMPT_NAME,
        prompt_version=difficulty_drivers_prompt.PROMPT_VERSION,
        system=difficulty_drivers_prompt.SYSTEM_PROMPT,
        user=difficulty_drivers_prompt.build_user_prompt(fixture.synthesis_input),
        output_schema=difficulty_drivers_prompt.DifficultyDriversOutput,
        model=model,
        max_tokens=DEFAULT_MAX_TOKENS,
    )


def _build_request_intent_filter(fixture: LoadedFixture, *, model: str) -> LLMRequest:
    # ``intent_filter.build_user_prompt`` has a non-standard signature
    # that takes the scan + endpoint inventory + target_domain directly
    # (rather than reading them off the synthesis_input dict). Reuse
    # the analysis output we already computed.
    user = intent_filter_prompt.build_user_prompt(
        scan=fixture.scan,  # type: ignore[arg-type]
        endpoints=fixture.endpoints_dicts,
        target_domain=fixture.scan.target_domain,
        dependency_chain=fixture.synthesis_input.get("candidate_edges", []),
    )
    return LLMRequest(
        prompt_name=intent_filter_prompt.PROMPT_NAME,
        prompt_version=intent_filter_prompt.PROMPT_VERSION,
        system=intent_filter_prompt.SYSTEM_PROMPT,
        user=user,
        output_schema=intent_filter_prompt.FilterOutput,
        model=model,
        max_tokens=DEFAULT_MAX_TOKENS,
    )


PROMPT_BUILDERS: dict[str, Callable[[LoadedFixture], Callable[..., LLMRequest]]] = {
    "scan_synthesis": lambda f: (
        lambda *, model: _build_request_scan_synthesis(f, model=model)
    ),
    "notes": lambda f: lambda *, model: _build_request_notes(f, model=model),
    "difficulty_drivers": lambda f: (
        lambda *, model: _build_request_difficulty_drivers(f, model=model)
    ),
    "intent_filter": lambda f: (
        lambda *, model: _build_request_intent_filter(f, model=model)
    ),
}


def build_request(
    *, prompt_name: str, fixture: LoadedFixture, model: str
) -> LLMRequest:
    """Build the ``LLMRequest`` for ``prompt_name`` against ``fixture``.

    Raises :class:`ValueError` for unknown prompt names so the CLI can
    surface ``invalid prompt 'bogus'; valid: ...``. The ``model`` field
    is set on the returned request so the dispatcher routes to the right
    provider.
    """
    if prompt_name not in VALID_PROMPT_NAMES:
        valid_list = ", ".join(VALID_PROMPT_NAMES)
        raise ValueError(f"unknown prompt {prompt_name!r}; valid: {valid_list}")
    factory = PROMPT_BUILDERS[prompt_name](fixture)
    return factory(model=model)


__all__ = [
    "DEFAULT_PROJECTED_OUTPUT_TOKENS",
    "FixtureNotFoundError",
    "LoadedFixture",
    "PROMPT_BUILDERS",
    "VALID_PROMPT_NAMES",
    "build_request",
    "load_fixture_capture",
]
