"""Side-by-side eval runner (T46).

Orchestrates the per-prompt comparison between two providers. The
runner is the only piece that calls :class:`LLMClient` -- everything
upstream is pure (fixture loading, prompt building) and everything
downstream is pure (Markdown rendering). That split keeps the unit
tests easy: mock the client and the runner becomes a state machine
over the prompt list.

Public entry point: :meth:`EvalRunner.run` returns an
:class:`EvalRunResult` with one :class:`PromptEvalRow` per prompt the
user requested. The CLI handler turns the result into ``eval.md`` +
``costs.json`` + ``prompts/<name>-<provider>.json`` dumps.
"""

from __future__ import annotations

import json
import logging
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from browser_recon.llm_eval.cost_tracker import CostCapExceeded, CostTracker
from browser_recon.llm_eval.fixtures import (
    DEFAULT_PROJECTED_OUTPUT_TOKENS,
    LoadedFixture,
    build_request,
)
from browser_recon_server.llm.client import LLMClient
from browser_recon_server.llm.pricing import compute_cost
from browser_recon_server.llm.types import LLMRequest, LLMResponse

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Dataclasses
# ---------------------------------------------------------------------------


@dataclass
class PromptEvalRow:
    """One prompt × two providers worth of comparison data.

    ``provider_*_parsed`` carries the Pydantic ``model_dump()`` of the
    response so the report renderer can surface per-field differences
    without depending on the live ``BaseModel`` class.

    ``provider_*_dump_path`` is the relative path (from ``eval.md``)
    where the runner wrote the raw JSON dump. ``None`` when no dump
    was produced (dry-run or the call errored before parsing).
    """

    prompt_name: str
    provider_a_model: str
    provider_b_model: str
    provider_a_metrics: dict[str, Any] = field(default_factory=dict)
    provider_b_metrics: dict[str, Any] = field(default_factory=dict)
    provider_a_parsed: dict[str, Any] | None = None
    provider_b_parsed: dict[str, Any] | None = None
    provider_a_error: str | None = None
    provider_b_error: str | None = None
    provider_a_dump_path: str | None = None
    provider_b_dump_path: str | None = None


@dataclass
class EvalRunResult:
    """End-to-end result of one :meth:`EvalRunner.run` invocation."""

    fixture_name: str
    provider_a: str
    provider_b: str
    spend_cap_usd: float | None
    mode: str  # "dry-run" or "live"
    started_at: str
    rows: list[PromptEvalRow] = field(default_factory=list)
    cost_tracker: CostTracker = field(default_factory=lambda: CostTracker(cap_usd=None))
    status: str = "pending"
    abort_reason: str | None = None


# ---------------------------------------------------------------------------
# Runner
# ---------------------------------------------------------------------------


def _estimate_input_tokens(request: LLMRequest) -> int:
    """Per-task heuristic: ``len(system + user) / 4``.

    Both providers' tokenisers diverge from this by ~15 % at the
    extremes, but for cost projection the order of magnitude is what
    matters. The heuristic deliberately avoids pulling tiktoken / the
    Anthropic tokenizer so the harness has no extra runtime deps.
    """
    char_count = len(request.system) + len(request.user)
    return max(1, char_count // 4)


def _project_cost(
    *,
    model: str,
    input_tokens: int,
    output_tokens: int = DEFAULT_PROJECTED_OUTPUT_TOKENS,
) -> float:
    """Wrap :func:`compute_cost` so the runner doesn't fork the usage shape.

    The real dispatcher reports ``cache_creation_input_tokens`` and
    ``cache_read_input_tokens`` -- for a projection we assume cold
    cache (both zero) which is the worst-case bound the spend cap
    should be sized against.
    """
    usage = {
        "input_tokens": input_tokens,
        "output_tokens": output_tokens,
        "cache_creation_input_tokens": 0,
        "cache_read_input_tokens": 0,
    }
    return compute_cost(model, usage)


class EvalRunner:
    """Driver: load fixture, build prompts, call providers, collect rows.

    The runner is stateless across :meth:`run` invocations; instantiate
    one per CLI call. The ``client_factory`` injection seam exists for
    the unit tests -- the default factory builds the production
    :class:`LLMClient` with no observability wiring (no scan_id / no
    blob store) so eval calls never write rows to ``llm_calls``.
    """

    def __init__(
        self,
        *,
        fixture: LoadedFixture,
        provider_a: str,
        provider_b: str,
        prompts: list[str],
        spend_cap_usd: float | None,
        dry_run: bool,
        output_dir: Path,
        client_factory: Any = None,
        now: Any = None,
    ) -> None:
        self._fixture = fixture
        self._provider_a = provider_a
        self._provider_b = provider_b
        self._prompts = prompts
        self._spend_cap = spend_cap_usd
        self._dry_run = dry_run
        self._output_dir = output_dir
        self._client_factory = client_factory or (lambda: LLMClient())
        self._now = now or _utc_now_iso

    def run(self) -> EvalRunResult:
        """Execute every (prompt, provider) call; return the assembled report.

        On a ``CostCapExceeded`` raised by the tracker, the run aborts
        immediately and ``status`` is set to ``"aborted (cap hit)"``.
        Earlier-prompt rows are preserved so the user can see where
        the budget went.
        """
        mode = "dry-run" if self._dry_run else "live"
        cap = None if self._dry_run else self._spend_cap
        result = EvalRunResult(
            fixture_name=self._fixture.name,
            provider_a=self._provider_a,
            provider_b=self._provider_b,
            spend_cap_usd=self._spend_cap,
            mode=mode,
            started_at=self._now(),
            cost_tracker=CostTracker(cap_usd=cap),
        )

        client = None if self._dry_run else self._client_factory()
        prompts_dir = self._output_dir / "prompts"
        if not self._dry_run:
            prompts_dir.mkdir(parents=True, exist_ok=True)

        try:
            for prompt_name in self._prompts:
                row = self._eval_one_prompt(
                    prompt_name=prompt_name,
                    client=client,
                    cost_tracker=result.cost_tracker,
                    prompts_dir=prompts_dir,
                )
                result.rows.append(row)
            result.status = "dry-run" if self._dry_run else "completed"
        except CostCapExceeded as exc:
            result.status = "aborted (cap hit)"
            result.abort_reason = (
                f"would exceed cap ${exc.cap_usd:.4f}: "
                f"accumulated=${exc.accumulated_usd:.4f} + "
                f"projected=${exc.projected_usd:.4f}"
            )

        return result

    def _eval_one_prompt(
        self,
        *,
        prompt_name: str,
        client: LLMClient | None,
        cost_tracker: CostTracker,
        prompts_dir: Path,
    ) -> PromptEvalRow:
        """Run one prompt against both providers; return a populated row."""
        row = PromptEvalRow(
            prompt_name=prompt_name,
            provider_a_model=self._provider_a,
            provider_b_model=self._provider_b,
        )

        request_a = build_request(
            prompt_name=prompt_name, fixture=self._fixture, model=self._provider_a
        )
        request_b = build_request(
            prompt_name=prompt_name, fixture=self._fixture, model=self._provider_b
        )

        input_tokens_a = _estimate_input_tokens(request_a)
        input_tokens_b = _estimate_input_tokens(request_b)
        projected_a = _project_cost(model=self._provider_a, input_tokens=input_tokens_a)
        projected_b = _project_cost(model=self._provider_b, input_tokens=input_tokens_b)

        if self._dry_run:
            row.provider_a_metrics = {
                "input_tokens": input_tokens_a,
                "output_tokens": DEFAULT_PROJECTED_OUTPUT_TOKENS,
                "cost_usd": projected_a,
                "latency_ms": 0,
            }
            row.provider_b_metrics = {
                "input_tokens": input_tokens_b,
                "output_tokens": DEFAULT_PROJECTED_OUTPUT_TOKENS,
                "cost_usd": projected_b,
                "latency_ms": 0,
            }
            # Track projected cost so the header shows a useful total.
            cost_tracker.record(provider=self._provider_a, cost_usd=projected_a)
            cost_tracker.record(provider=self._provider_b, cost_usd=projected_b)
            return row

        # Live mode -- reserve cap, call, record true cost, dump JSON.
        assert client is not None
        cost_tracker.reserve(provider=self._provider_a, projected_usd=projected_a)
        a_metrics, a_parsed, a_error = self._call_provider(
            client=client, request=request_a
        )
        row.provider_a_metrics = a_metrics
        row.provider_a_parsed = a_parsed
        row.provider_a_error = a_error
        if a_metrics.get("cost_usd") is not None:
            cost_tracker.record(
                provider=self._provider_a, cost_usd=float(a_metrics["cost_usd"])
            )
        if a_parsed is not None:
            dump_a = prompts_dir / f"{prompt_name}-{self._provider_a}.json"
            dump_a.write_text(
                json.dumps(a_parsed, indent=2, default=str), encoding="utf-8"
            )
            row.provider_a_dump_path = f"prompts/{dump_a.name}"

        cost_tracker.reserve(provider=self._provider_b, projected_usd=projected_b)
        b_metrics, b_parsed, b_error = self._call_provider(
            client=client, request=request_b
        )
        row.provider_b_metrics = b_metrics
        row.provider_b_parsed = b_parsed
        row.provider_b_error = b_error
        if b_metrics.get("cost_usd") is not None:
            cost_tracker.record(
                provider=self._provider_b, cost_usd=float(b_metrics["cost_usd"])
            )
        if b_parsed is not None:
            dump_b = prompts_dir / f"{prompt_name}-{self._provider_b}.json"
            dump_b.write_text(
                json.dumps(b_parsed, indent=2, default=str), encoding="utf-8"
            )
            row.provider_b_dump_path = f"prompts/{dump_b.name}"

        return row

    def _call_provider(
        self,
        *,
        client: LLMClient,
        request: LLMRequest,
    ) -> tuple[dict[str, Any], dict[str, Any] | None, str | None]:
        """One dispatch -- return ``(metrics, parsed_dump, error_message)``.

        Catches every exception from ``client.run`` so a flaky provider
        on prompt 2 doesn't abort the whole eval. The error message is
        surfaced in the report and the metrics row carries best-effort
        defaults (zero tokens, zero cost) so the table renders cleanly.
        """
        start = time.monotonic()
        try:
            response: LLMResponse = client.run(request)
        except Exception as exc:  # noqa: BLE001 -- intentional broad catch
            latency_ms = int((time.monotonic() - start) * 1000)
            logger.warning(
                "llm-eval: %s on %s failed: %s",
                request.prompt_name,
                request.model,
                exc,
            )
            return (
                {
                    "input_tokens": 0,
                    "output_tokens": 0,
                    "cost_usd": 0.0,
                    "latency_ms": latency_ms,
                },
                None,
                f"{type(exc).__name__}: {exc}",
            )

        latency_ms = int((time.monotonic() - start) * 1000)
        usage = response.usage
        metrics = {
            "input_tokens": int(usage.get("input_tokens", 0)),
            "output_tokens": int(usage.get("output_tokens", 0)),
            "cache_read_input_tokens": int(usage.get("cache_read_input_tokens", 0)),
            "cache_creation_input_tokens": int(
                usage.get("cache_creation_input_tokens", 0)
            ),
            "cost_usd": float(response.cost_usd),
            "latency_ms": latency_ms,
        }
        try:
            parsed_dump = response.parsed.model_dump()
        except Exception:  # pragma: no cover -- defensive belt
            parsed_dump = None
        return metrics, parsed_dump, None


def _utc_now_iso() -> str:
    """Return a UTC ISO-8601 timestamp -- injectable for deterministic tests."""
    from datetime import UTC, datetime

    return datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%SZ")


__all__ = [
    "EvalRunResult",
    "EvalRunner",
    "PromptEvalRow",
]
