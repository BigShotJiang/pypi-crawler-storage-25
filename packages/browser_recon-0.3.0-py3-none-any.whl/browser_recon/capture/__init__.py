"""Public capture API: start_capture() launches Chrome and runs the CDP monitor."""

from __future__ import annotations

import asyncio
import logging
import subprocess
from pathlib import Path
from typing import Any

from browser_recon.capture.cdp_monitor import CDPNetworkMonitor
from browser_recon.capture.chrome_launcher import (
    ChromeNotFoundError,
    PortInUseError,
    launch,
)
from browser_recon.models import CaptureResult

__all__ = [
    "ChromeNotFoundError",
    "PortInUseError",
    "start_capture",
]

logger = logging.getLogger(__name__)

# 0 = unlimited; the capture only ends when the user signals "done"
# (Ctrl+C in the CLI, or ``recon stop`` writing a sentinel file).
# Slow-loading sites and multi-step flows (login -> navigate ->
# trigger XHR) routinely exceed any wall-clock cap we'd pick, and
# silently truncating the capture is worse than letting the user
# decide when they're finished. ``CDPNetworkMonitor.monitor`` already
# treats ``duration=0`` as "no time limit" -- this constant just
# carries that contract through the public ``start_capture`` API.
_DEFAULT_DURATION = 0
_DEFAULT_PORT = 9222


def start_capture(
    url: str,
    mode: str = "quick",
    *,
    duration: int = _DEFAULT_DURATION,
    port: int = _DEFAULT_PORT,
    chrome_path: str | None = None,
    kill_existing: bool = False,
    output_dir: Path | None = None,
    api_only: bool = False,
    save_responses: bool = True,
    max_response_kb: int = 500,
    url_filters: list[str] | None = None,
    capture_interactions: bool = True,
    use_existing_profile: bool = False,
    user_data_dir: Path | str | None = None,
    progress_sink: Any = None,
) -> CaptureResult:
    """Launch Chrome, run the CDP monitor, return a CaptureResult.

    ``mode='quick'`` skips DOM snapshots (``capture_dom=False``); ``mode='full'``
    includes them. Other kwargs forward to :class:`CDPNetworkMonitor`.

    ``use_existing_profile`` and ``user_data_dir`` forward verbatim to
    :func:`browser_recon.capture.chrome_launcher.launch` (fix #3 --
    fresh ephemeral profile is the default; opt back in via these
    kwargs when an authenticated-session capture is needed).

    Raises :exc:`ChromeNotFoundError` / :exc:`PortInUseError` from the launcher;
    raises :exc:`ValueError` on an unknown mode.
    """
    if mode not in ("quick", "full"):
        raise ValueError(f"mode must be 'quick' or 'full', got {mode!r}")

    capture_dom = mode == "full"

    chrome_proc: subprocess.Popen[bytes] | None = None
    try:
        chrome_proc = launch(
            url,
            port=port,
            kill_existing=kill_existing,
            chrome_path=chrome_path,
            use_existing_profile=use_existing_profile,
            user_data_dir=user_data_dir,
        )
        logger.info("Chrome launched (pid=%d) -> %s", chrome_proc.pid, url)

        monitor = CDPNetworkMonitor(
            port=port,
            capture_dom=capture_dom,
            url_filters=url_filters,
            save_responses=save_responses,
            max_response_kb=max_response_kb,
            api_only=api_only,
            capture_interactions=capture_interactions,
            progress_sink=progress_sink,
        )

        # Set up stop file if output_dir provided
        if output_dir is not None:
            output_dir = Path(output_dir)
            output_dir.mkdir(parents=True, exist_ok=True)
            monitor.set_stop_file(output_dir / ".stop")

        # Run the async pipeline. ``output_dir`` is threaded into
        # ``monitor.export()`` so ``recon_capture.json`` + ``responses/``
        # land next to ``recon_report.md`` (T11 capture-folder fix --
        # previously the export defaulted to ``./browser-recon/``
        # under the CWD, splitting capture artefacts away from the
        # scan's own output folder).
        raw = asyncio.run(_run_capture(monitor, duration, output_dir=output_dir))

        metadata = _compute_capture_metadata(raw, mode=mode, duration=duration)

        return CaptureResult(
            target_url=url,
            mode=mode,
            capture_metadata=metadata,
            raw=raw,
            output_dir=output_dir,
        )
    finally:
        if chrome_proc is not None:
            _shutdown_chrome(chrome_proc)


async def _run_capture(
    monitor: CDPNetworkMonitor,
    duration: int,
    *,
    output_dir: Path | None = None,
) -> dict[str, Any]:
    """Run the full async capture lifecycle and return the raw export dict.

    ``output_dir`` is forwarded to :meth:`CDPNetworkMonitor.export` so
    ``recon_capture.json`` and ``responses/`` land in the scan's own
    per-domain + timestamp directory rather than the CWD-relative
    legacy default. ``None`` falls through to the legacy default
    inside :meth:`export` (used by callers outside the CLI scan flow).
    """
    await monitor.connect()
    try:
        await monitor.monitor(duration=duration)
        await monitor.fetch_cookies()
    finally:
        await monitor.close()
    return monitor.export(output_dir=output_dir)


def _shutdown_chrome(proc: subprocess.Popen[bytes]) -> None:
    """Best-effort: SIGTERM, then wait, then SIGKILL if needed."""
    try:
        proc.terminate()
        proc.wait(timeout=10)
    except subprocess.TimeoutExpired:
        proc.kill()
        try:
            proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            logger.warning("Chrome process did not exit after kill()")
    except Exception as exc:  # noqa: BLE001 -- best-effort cleanup
        logger.warning("Failed to terminate Chrome: %s", exc)


def _compute_capture_metadata(
    raw: dict[str, Any],
    *,
    mode: str,
    duration: int,
) -> dict[str, Any]:
    """Compute a quality_score and warnings from the raw export dict.

    Quality is "did this capture get enough data to be useful?":

    * ``api_endpoints >= 5`` -> +0.4
    * ``cookies >= 3``       -> +0.2
    * ``interactions >= 1``  -> +0.2
    * ``page_loads >= 1``    -> +0.2
    * Cap at 1.0.

    Warnings flag the components that scored 0.

    ``mode`` and ``duration`` are kept on capture_metadata for downstream
    context.
    """
    api_endpoints = raw.get("api_endpoints", []) or []
    cookies = raw.get("cookies", []) or []
    interactions = raw.get("interactions", []) or []
    page_loads = raw.get("page_loads", []) or []

    score = 0.0
    warnings: list[str] = []

    if len(api_endpoints) >= 5:
        score += 0.4
    else:
        warnings.append(
            f"thin api capture: {len(api_endpoints)} endpoints (target >= 5)"
        )
    if len(cookies) >= 3:
        score += 0.2
    else:
        warnings.append(f"thin cookie capture: {len(cookies)} cookies (target >= 3)")
    if len(interactions) >= 1:
        score += 0.2
    else:
        warnings.append("no user interactions captured")
    if len(page_loads) >= 1:
        score += 0.2
    else:
        warnings.append("no page navigations captured")

    return {
        "mode": mode,
        "duration_seconds": duration,
        "quality_score": min(1.0, round(score, 2)),
        "warnings": warnings,
        "api_endpoint_count": len(api_endpoints),
        "cookie_count": len(cookies),
        "interaction_count": len(interactions),
        "page_load_count": len(page_loads),
    }
