"""CDPNetworkMonitor — core CDP network monitoring engine.

Straight extraction (task 1.a.16) from
``~/.claude/skills/browser-recon/scripts/monitor.py``. Connects to Chrome
via the Chrome DevTools Protocol, captures network requests/responses,
WebSocket traffic, cookies, and DOM snapshots. The class itself is
copied verbatim — the only changes from the source are:

* import paths rewritten from the skill's ``sys.path``-injected
  ``models`` / ``detectors`` / ``analyzers`` packages to the
  ``browser_recon.*`` package layout, and
* ``dict`` / ``list`` annotations tightened to ``dict[str, Any]`` /
  ``list[...]`` so the module passes ``mypy --strict``.

The CLI orchestration (chrome launch + monitor + report writing) lives
in the wrapper script ``cdp_monitor.py`` in the source skill; that
wrapper is task 1.a.18's responsibility and is intentionally not ported
here.
"""

from __future__ import annotations

import asyncio
import json
import logging
import re
import time
from collections.abc import Callable
from dataclasses import asdict
from datetime import UTC, datetime
from pathlib import Path
from typing import Any
from urllib.parse import urlsplit

import websockets

from browser_recon.analysis.headers import is_cdn_url
from browser_recon.analysis.interactions import (
    DOM_CHANGE_PREFIX,
    INTERACTION_PREFIX,
    build_dom_observer_script,
    build_injection_script,
    parse_dom_change_signal,
    parse_interaction_log,
)
from browser_recon.analysis.redirects import extract_redirect_info
from browser_recon.detection.rules.anti_bot import AntiBotDetector
from browser_recon.detection.rules.auth_flow import AuthFlowDetector
from browser_recon.detection.rules.rate_limit_signals import RateLimitDetector
from browser_recon.models import (
    CapturedCookie,
    CapturedInteraction,
    CapturedRequest,
    CapturedWebSocket,
    DOMSnapshot,
)

logger = logging.getLogger("cdp-monitor")


# ---------------------------------------------------------------------------
# CDPNetworkMonitor
# ---------------------------------------------------------------------------


class CDPNetworkMonitor:
    """Connects to Chrome via CDP and captures network activity.

    Attributes:
        port: Chrome remote debugging port.
        requests: Dictionary of captured requests keyed by request ID.
        websockets_log: List of captured WebSocket connections.
        cookies: List of captured cookies (populated on stop).
    """

    def __init__(
        self,
        port: int = 9222,
        capture_dom: bool = False,
        url_filters: list[str] | None = None,
        save_responses: bool = True,  # FLIPPED — was False
        max_response_kb: int = 500,
        api_only: bool = True,  # FLIPPED — was False
        capture_interactions: bool = True,  # FLIPPED — was False
        progress_sink: Any = None,
    ) -> None:
        self.port = port
        self.capture_dom = capture_dom
        self.url_filters = [
            kw.strip().lower() for kw in (url_filters or []) if kw.strip()
        ]
        self.save_responses = save_responses
        self.max_response_bytes = max_response_kb * 1024
        self.api_only = api_only
        self.capture_interactions = capture_interactions
        # T37: optional spinner-like sink with ``update`` / ``permanent_line``
        # methods. When set, the monitor routes the noisy per-request log
        # into ``update`` (single in-place line) and the load-bearing
        # events (clicks, anti-bot, navigation, scrolls under verbose)
        # into ``permanent_line``. ``None`` keeps the legacy firehose
        # logging untouched -- the ``--verbose`` CLI path takes this
        # branch on purpose so power users still get every line.
        self.progress_sink = progress_sink
        # Running count of captured requests surfaced through the
        # spinner. Excludes filtered noise (static / tracker / preflight
        # short-circuits) so the counter matches the "kept" total.
        self._captured_count = 0

        # Captured data
        self.requests: dict[str, CapturedRequest] = {}
        self.websockets_log: dict[str, CapturedWebSocket] = {}
        self.cookies: list[CapturedCookie] = []
        self.dom_snapshots: list[DOMSnapshot] = []
        self.interactions: list[CapturedInteraction] = []

        # Detectors — wired in __init__
        self.anti_bot = AntiBotDetector()
        self.rate_limit = RateLimitDetector()
        self.auth_flow = AuthFlowDetector()

        # Internal state
        self._pending_dom_captures: list[dict[str, str]] = []
        self._pending_body_fetches: list[str] = []
        self._ws: Any = None  # primary WebSocket
        self._extra_ws: list[Any] = []  # additional tab WebSockets
        self._extra_tasks: list[asyncio.Task[None]] = []
        self._msg_id = 0
        self._running = False
        self._start_time = 0.0
        self._skipped_count = 0
        self._skipped_static_count = 0
        self._connected_targets: set[str] = set()
        self._stop_file: Path | None = None
        self._event_handlers: dict[str, Callable[[dict[str, Any]], None]] = {}

        # SPA DOM capture state
        self._dom_capture_count = 0
        self._max_dom_snapshots = 30
        self._last_dom_capture_url = ""
        self._last_dom_capture_time = 0.0
        self._ready_dom_captures: list[dict[str, str]] = []

    # ------------------------------------------------------------------
    # Connection
    # ------------------------------------------------------------------

    async def connect(self) -> None:
        """Connect to Chrome's CDP WebSocket endpoint.

        Connects to the first page target as primary, and stores all
        page target IDs for multi-tab monitoring.
        """
        import urllib.request

        discovery_url = f"http://127.0.0.1:{self.port}/json"

        targets: list[dict[str, Any]] = []
        for attempt in range(10):
            try:
                with urllib.request.urlopen(discovery_url, timeout=5) as resp:
                    targets = json.loads(resp.read())
                break
            except Exception as exc:
                if attempt == 9:
                    raise ConnectionError(
                        f"Cannot connect to Chrome on port {self.port}.\n"
                        "Make sure Chrome is running with remote debugging:\n\n"
                        "  Open a terminal (cmd or PowerShell) and run:\n"
                        '  "C:\\Program Files\\Google\\Chrome\\Application'
                        '\\chrome.exe" '
                        f"--remote-debugging-port={self.port} "
                        '--user-data-dir="%TEMP%\\chrome-recon" '
                        "https://example.com\n\n"
                        "  IMPORTANT: Close ALL other Chrome windows first, "
                        "or use\n"
                        "  the --user-data-dir flag above to isolate the session."
                    ) from exc
                logger.info("Waiting for Chrome (attempt %d/10)...", attempt + 1)
                await asyncio.sleep(2)

        # Find ALL page targets
        page_targets = [t for t in targets if t.get("type") == "page"]
        if not page_targets:
            raise ConnectionError(
                "Chrome is running but no page target found. Open a tab and try again."
            )

        # Connect to the first page target as primary
        primary = page_targets[0]
        ws_url = primary["webSocketDebuggerUrl"]
        logger.info("Connected to Chrome CDP: %s", ws_url)
        self._ws = await websockets.connect(ws_url, max_size=50 * 1024 * 1024)
        self._connected_targets.add(primary["id"])

        # Connect to additional page targets
        for target in page_targets[1:]:
            await self._connect_extra_tab(target)

    async def _connect_extra_tab(self, target: dict[str, Any]) -> None:
        """Connect to an additional page target for multi-tab monitoring."""
        target_id = target.get("id", "")
        if target_id in self._connected_targets:
            return
        ws_url = target.get("webSocketDebuggerUrl", "")
        if not ws_url:
            return
        try:
            ws = await websockets.connect(ws_url, max_size=50 * 1024 * 1024)
            self._extra_ws.append(ws)
            self._connected_targets.add(target_id)
            # Enable domains on this connection
            msg_id_n = self._msg_id + 1000000  # offset to avoid collision
            await ws.send(
                json.dumps({"id": msg_id_n, "method": "Network.enable", "params": {}})
            )
            await ws.send(
                json.dumps({"id": msg_id_n + 1, "method": "Page.enable", "params": {}})
            )
            logger.info(
                "Connected to extra tab: %s", target.get("title", target_id)[:60]
            )
        except Exception as exc:
            logger.debug("Could not connect to extra tab %s: %s", target_id, exc)

    async def _poll_new_tabs(self) -> None:
        """Check for new page targets and connect to them."""
        import urllib.request

        discovery_url = f"http://127.0.0.1:{self.port}/json"
        try:
            with urllib.request.urlopen(discovery_url, timeout=2) as resp:
                targets = json.loads(resp.read())
            page_targets = [t for t in targets if t.get("type") == "page"]
            for target in page_targets:
                if target["id"] not in self._connected_targets:
                    await self._connect_extra_tab(target)
                    # Start a listener task for the new tab
                    if self._extra_ws:
                        ws = self._extra_ws[-1]
                        task = asyncio.create_task(self._extra_tab_listener(ws))
                        self._extra_tasks.append(task)
        except Exception:
            pass  # Non-critical — poll will retry next cycle

    async def _extra_tab_listener(self, ws: Any) -> None:
        """Listen for CDP events from an extra tab WebSocket."""
        handlers = self._event_handlers
        try:
            while self._running:
                try:
                    raw = await asyncio.wait_for(ws.recv(), timeout=1.0)
                except TimeoutError:
                    continue
                except websockets.exceptions.ConnectionClosed:
                    break
                msg = json.loads(raw)
                method = msg.get("method", "")
                handler = handlers.get(method)
                if handler:
                    handler(msg.get("params", {}))
        except asyncio.CancelledError:
            pass
        except Exception:
            pass

    async def _send(self, method: str, params: dict[str, Any] | None = None) -> int:
        """Send a CDP command on the primary WebSocket."""
        self._msg_id += 1
        msg = {"id": self._msg_id, "method": method, "params": params or {}}
        await self._ws.send(json.dumps(msg))
        return self._msg_id

    async def _enable_domains(self) -> None:
        """Enable CDP domains needed for monitoring."""
        await self._send("Network.enable")
        await self._send("Page.enable")
        if self.capture_dom:
            await self._send("DOM.enable")
            await self._send("Page.setLifecycleEventsEnabled", {"enabled": True})

        # Enable Runtime if either interactions or DOM capture needs it
        if self.capture_interactions or self.capture_dom:
            await self._send("Runtime.enable")

        # Register bindings for reliable communication (not interceptable by page JS)
        if self.capture_interactions:
            await self._send("Runtime.addBinding", {"name": "__reconInteraction"})
            # Inject interaction tracker into current page
            await self._inject_interaction_script()
            # Auto-inject on every new page load via
            # Page.addScriptToEvaluateOnNewDocument
            await self._send(
                "Page.addScriptToEvaluateOnNewDocument",
                {"source": build_injection_script()},
            )

        if self.capture_dom:
            await self._send("Runtime.addBinding", {"name": "__reconDomChange"})
            # Inject DOM observer into current page
            await self._inject_dom_observer_script()
            # Auto-inject on every new page load
            await self._send(
                "Page.addScriptToEvaluateOnNewDocument",
                {"source": build_dom_observer_script()},
            )

        domains = ["Network", "Page"]
        if self.capture_dom:
            domains.append("DOM")
        if self.capture_interactions or self.capture_dom:
            domains.append("Runtime")
        logger.info("CDP domains enabled: %s", " + ".join(domains))

    # ------------------------------------------------------------------
    # DOM Capture
    # ------------------------------------------------------------------

    async def _capture_dom_snapshot(self, url: str = "", frame_id: str = "") -> None:
        """Capture the full rendered DOM of the current page."""
        try:
            doc_msg_id = await self._send("DOM.getDocument", {"depth": 0})
            doc_result = await self._wait_for_response(doc_msg_id)
            if not doc_result:
                return

            root_node_id = doc_result.get("result", {}).get("root", {}).get("nodeId")
            if not root_node_id:
                return

            html_msg_id = await self._send("DOM.getOuterHTML", {"nodeId": root_node_id})
            html_result = await self._wait_for_response(html_msg_id)
            if not html_result:
                return

            outer_html = html_result.get("result", {}).get("outerHTML", "")
            if not outer_html:
                return

            # Get page title via JS evaluation
            title = ""
            try:
                title_msg_id = await self._send(
                    "Runtime.evaluate",
                    {"expression": "document.title", "returnByValue": True},
                )
                title_result = await self._wait_for_response(title_msg_id)
                if title_result is not None:
                    title = (
                        title_result.get("result", {})
                        .get("result", {})
                        .get("value", "")
                    )
            except Exception:
                pass

            # Lightweight DOM analysis
            html_lower = outer_html.lower()
            snapshot = DOMSnapshot(
                url=url,
                title=title,
                timestamp=time.time(),
                outer_html=outer_html,
                frame_id=frame_id,
                has_json_ld='type="application/ld+json"' in html_lower,
                has_microdata="itemscope" in html_lower,
                has_og_tags='property="og:' in html_lower,
                data_attributes_count=outer_html.count("data-"),
                iframe_count=html_lower.count("<iframe"),
                form_count=html_lower.count("<form"),
                total_element_count=outer_html.count("</"),
            )

            # Extract meta tags
            meta_pattern = re.compile(r"<meta\s+([^>]+?)/?>", re.IGNORECASE)
            for match in meta_pattern.finditer(outer_html[:50000]):
                attrs_str = match.group(1)
                attrs: dict[str, str] = {}
                for attr_match in re.finditer(
                    r'(\w+)\s*=\s*["\']([^"\']*)["\']', attrs_str
                ):
                    attrs[attr_match.group(1).lower()] = attr_match.group(2)
                if attrs:
                    snapshot.meta_tags.append(attrs)

            self.dom_snapshots.append(snapshot)
            self._dom_capture_count += 1
            logger.info(
                "DOM captured [%d/%d]: %s (%d elements, %d KB)",
                self._dom_capture_count,
                self._max_dom_snapshots,
                url[:80],
                snapshot.total_element_count,
                len(outer_html) // 1024,
            )

        except Exception as exc:
            logger.warning("DOM capture failed for %s: %s", url[:80], exc)

    async def _wait_for_response(
        self, msg_id: int, timeout: float = 5.0
    ) -> dict[str, Any] | None:
        """Wait for a specific CDP response by message ID.

        Continues to dispatch events while waiting.
        """
        deadline = time.time() + timeout
        while time.time() < deadline:
            try:
                raw = await asyncio.wait_for(
                    self._ws.recv(), timeout=min(1.0, deadline - time.time())
                )
                msg = json.loads(raw)
                if msg.get("id") == msg_id:
                    return msg  # type: ignore[no-any-return]
                # Still dispatch events while waiting
                method = msg.get("method", "")
                if method and hasattr(self, "_event_handlers"):
                    handler = self._event_handlers.get(method)
                    if handler:
                        handler(msg.get("params", {}))
            except (TimeoutError, websockets.exceptions.ConnectionClosed):
                break
        return None

    # ------------------------------------------------------------------
    # Interaction Capture
    # ------------------------------------------------------------------

    async def _inject_interaction_script(self) -> None:
        """Inject the interaction tracking JS into the current page."""
        try:
            await self._send(
                "Runtime.evaluate",
                {"expression": build_injection_script(), "returnByValue": True},
            )
        except Exception as exc:
            logger.debug("Interaction script injection failed: %s", exc)

    async def _inject_dom_observer_script(self) -> None:
        """Inject the SPA DOM observer JS into the current page."""
        try:
            await self._send(
                "Runtime.evaluate",
                {"expression": build_dom_observer_script(), "returnByValue": True},
            )
        except Exception as exc:
            logger.debug("DOM observer script injection failed: %s", exc)

    # ------------------------------------------------------------------
    # Binding-based event handler (primary channel)
    # ------------------------------------------------------------------

    def _on_binding_called(self, params: dict[str, Any]) -> None:
        """Handle Runtime.bindingCalled — primary channel for injected scripts."""
        name = params.get("name", "")
        payload_str = params.get("payload", "")

        if name == "__reconInteraction":
            try:
                data = json.loads(payload_str)
            except (json.JSONDecodeError, TypeError):
                return
            interaction = CapturedInteraction(
                action=data.get("action", ""),
                timestamp=data.get("timestamp", 0) / 1000.0,
                page_url=data.get("page_url", ""),
                selector=data.get("selector", ""),
                tag=data.get("tag", ""),
                text=data.get("text", "")[:100],
                input_name=data.get("input_name", ""),
                input_type=data.get("input_type", ""),
                input_value=data.get("input_value", ""),
                href=data.get("href", ""),
                scroll_y=data.get("scroll_y", 0),
                scroll_max_y=data.get("scroll_max_y", 0),
            )
            self.interactions.append(interaction)
            self._log_interaction(interaction)

        elif name == "__reconDomChange":
            try:
                data = json.loads(payload_str)
            except (json.JSONDecodeError, TypeError):
                return
            url = data.get("url", "")
            trigger = data.get("trigger", "unknown")
            if url:
                self._queue_spa_dom_capture(url, trigger)

    def _queue_spa_dom_capture(self, url: str, trigger: str) -> None:
        """Queue a DOM capture from SPA route change, with dedup and cap."""
        now = time.time()

        # Cap: stop after max snapshots
        if self._dom_capture_count >= self._max_dom_snapshots:
            return

        # Dedup: same URL within 5 seconds
        if (
            url == self._last_dom_capture_url
            and (now - self._last_dom_capture_time) < 5.0
        ):
            return

        # Skip if already queued for this URL
        for queued in self._ready_dom_captures:
            if queued.get("url") == url:
                return

        self._last_dom_capture_url = url
        self._last_dom_capture_time = now
        self._ready_dom_captures.append({"url": url, "frame_id": ""})
        if self.progress_sink is not None:
            self.progress_sink.permanent_line(
                f"> SPA route change ({trigger}): {url[:100]}"
            )
        else:
            logger.info("SPA route change (%s): %s", trigger, url[:100])

    def _log_interaction(self, interaction: CapturedInteraction) -> None:
        """Log an interaction event to the console."""
        if interaction.action == "click":
            label = interaction.text[:50] or interaction.selector
            arrow = f" → {interaction.href[:80]}" if interaction.href else ""
            if self.progress_sink is not None:
                # T37 / 37.2: clicks are load-bearing -- they drop to a
                # permanent line that stays above the spinner.
                self.progress_sink.permanent_line(
                    f"> CLICK: <{interaction.tag}> {label}{arrow}"
                )
            else:
                logger.info(
                    "CLICK: <%s> %s %s",
                    interaction.tag,
                    label,
                    f"→ {interaction.href[:80]}" if interaction.href else "",
                )
        elif interaction.action == "input":
            val_display = (
                interaction.input_value
                if interaction.input_value != "[MASKED]"
                else "[MASKED]"
            )
            if self.progress_sink is not None:
                self.progress_sink.permanent_line(
                    f"> INPUT: {interaction.input_name or interaction.selector} "
                    f"({interaction.input_type}) = {val_display[:50]}"
                )
            else:
                logger.info(
                    "INPUT: %s (%s) = %s",
                    interaction.input_name or interaction.selector,
                    interaction.input_type,
                    val_display[:50],
                )
        elif interaction.action == "submit":
            if self.progress_sink is not None:
                self.progress_sink.permanent_line(
                    f"> SUBMIT: form on {interaction.page_url[:80]}"
                )
            else:
                logger.info("SUBMIT: form on %s", interaction.page_url[:80])
        elif interaction.action == "scroll":
            # T37 / 37.2: scrolls are noisy. Suppressed under the
            # spinner; firehose path still logs them so --verbose
            # restores the legacy behaviour.
            if self.progress_sink is None:
                pct = round(
                    interaction.scroll_y / max(interaction.scroll_max_y, 1) * 100
                )
                logger.info("SCROLL: %d%% of page", pct)

    def _on_console_api_called(self, params: dict[str, Any]) -> None:
        """Handle Runtime.consoleAPICalled — fallback for when bindings fail."""
        if params.get("type") != "log":
            return
        args = params.get("args", [])
        if not args:
            return
        text = args[0].get("value", "")
        if not isinstance(text, str):
            return

        # --- DOM change signal (fallback) ---
        if text.startswith(DOM_CHANGE_PREFIX) and self.capture_dom:
            signal = parse_dom_change_signal(text)
            if signal:
                url = signal.get("url", "")
                trigger = signal.get("trigger", "unknown")
                if url:
                    self._queue_spa_dom_capture(url, trigger)
            return

        # --- Interaction signal (fallback) ---
        if not text.startswith(INTERACTION_PREFIX):
            return

        interaction = parse_interaction_log(text)
        if interaction:
            # Dedup: skip if binding already delivered this
            # (check last 5 by timestamp proximity)
            for recent in self.interactions[-5:]:
                if (
                    abs(recent.timestamp - interaction.timestamp) < 0.05
                    and recent.action == interaction.action
                    and recent.selector == interaction.selector
                ):
                    return  # Already delivered via binding
            self.interactions.append(interaction)
            self._log_interaction(interaction)

    # ------------------------------------------------------------------
    # Event Handlers
    # ------------------------------------------------------------------

    # Extensions considered static/non-API assets
    _STATIC_EXTENSIONS = frozenset(
        (
            ".css",
            ".js",
            ".mjs",
            ".map",
            ".png",
            ".jpg",
            ".jpeg",
            ".gif",
            ".svg",
            ".webp",
            ".ico",
            ".bmp",
            ".avif",
            ".woff",
            ".woff2",
            ".ttf",
            ".eot",
            ".otf",
            ".mp4",
            ".webm",
            ".ogg",
            ".mp3",
            ".wav",
            ".pdf",
            ".zip",
            ".gz",
            ".br",
        )
    )

    # CDP resource types considered static/non-API
    _STATIC_RESOURCE_TYPES = frozenset(
        (
            "Image",
            "Media",
            "Font",
            "Stylesheet",
            "Script",
            "Manifest",
            "SignedExchange",
            "Ping",
            "CSPViolationReport",
            "Preflight",
        )
    )

    # Resource types we always want to capture
    _KEEP_RESOURCE_TYPES = frozenset(
        (
            "XHR",
            "Fetch",
            "Document",
            "WebSocket",
            "EventSource",
        )
    )

    def _url_matches_filter(self, url: str) -> bool:
        """Check if a URL matches the active keyword filters."""
        if not self.url_filters:
            return True
        url_lower = url.lower()
        return any(keyword in url_lower for keyword in self.url_filters)

    # Domains that are always third-party trackers / analytics —
    # not useful for scraping recon. Only specific tracker subdomains,
    # not broad domains like facebook.com or bing.com (those could host
    # legitimate APIs the user cares about).
    _TRACKER_DOMAINS = frozenset(
        (
            "googletagmanager.com",
            "google-analytics.com",
            "googleadservices.com",
            "googlesyndication.com",
            "googleads.g.doubleclick.net",
            "connect.facebook.net",  # Facebook tracking pixel SDK
            "doubleclick.net",
            "demdex.net",
            "omtrdc.net",
            "scorecardresearch.com",
            "quantserve.com",
            "hotjar.com",
            "clarity.ms",
            "bat.bing.com",
            "amazon-adsystem.com",
            "criteo.com",
            "outbrain.com",
            "taboola.com",
            "protechts.net",  # PerimeterX CDN
        )
    )

    # URL path patterns for media content delivered via XHR/Fetch
    _MEDIA_URL_PATTERNS = (
        "/playlist/vid/",  # LinkedIn video segments (dms.licdn.com)
        "/playlist/audio/",  # Audio streams
        "/hls-",  # HLS video segments
        # Note: DASH manifests caught by _MEDIA_MIME_TYPES (application/dash+xml)
        # Don't add "/dash/" here — matches "/api/dashboard/"
    )

    # MIME types that indicate media content (checked at response time)
    _MEDIA_MIME_TYPES = frozenset(
        (
            "video/mp4",
            "video/webm",
            "video/ogg",
            "video/iso.segment",
            "audio/mpeg",
            "audio/ogg",
            "audio/wav",
            "audio/mp4",
            "application/dash+xml",
            "application/x-mpegurl",
            "application/vnd.apple.mpegurl",
            "text/vtt",  # Subtitles/captions
            "image/svg+xml",  # SVG icons fetched via XHR
        )
    )

    def _is_static_request(self, url: str, resource_type: str) -> bool:
        """Check if a request is for a static asset (skippable in api_only mode)."""
        if resource_type in self._KEEP_RESOURCE_TYPES:
            # Even XHR/Fetch can be media — check URL patterns
            url_lower = url.lower()
            if any(p in url_lower for p in self._MEDIA_URL_PATTERNS):
                return True
            # Check tracker domains even for XHR/Fetch
            if self._is_tracker_domain(url_lower):
                return True
            # CDN domains (static.licdn.com etc.) — not useful API data
            if is_cdn_url(url):
                return True
            return False

        url_path = url.split("?")[0].split("#")[0].lower()
        if any(url_path.endswith(ext) for ext in self._STATIC_EXTENSIONS):
            return True

        if resource_type in self._STATIC_RESOURCE_TYPES:
            return True

        url_lower = url.lower()
        if any(
            p in url_lower
            for p in (
                "data:image/",
                "data:font/",
                "data:application/font",
            )
        ):
            return True

        if self._is_tracker_domain(url_lower):
            return True

        return False

    @staticmethod
    def _is_tracker_domain(url_lower: str) -> bool:
        """Check if URL belongs to a known tracker/analytics domain."""
        try:
            hostname = urlsplit(url_lower).hostname or ""
        except Exception:
            return False
        for domain in CDPNetworkMonitor._TRACKER_DOMAINS:
            if hostname == domain or hostname.endswith("." + domain):
                return True
        return False

    @staticmethod
    def _short_url_for_progress(url: str, max_len: int = 80) -> str:
        """Trim a URL to the path (and the first query param) for the spinner line.

        The spinner re-prints itself on every captured request; long
        URLs would wrap on narrow terminals and break the in-place
        ``\r`` rewrite. We pick the path + (truncated) query so the
        user still sees enough to recognise the endpoint they just
        triggered.
        """
        try:
            parts = urlsplit(url)
        except Exception:
            return url[:max_len]
        path = parts.path or "/"
        if parts.query:
            path = f"{path}?{parts.query}"
        if len(path) > max_len:
            return path[: max_len - 3] + "..."
        return path

    @staticmethod
    def _make_response_filename(req: CapturedRequest) -> str:
        """Generate a unique-ish filename for a response body.

        For GraphQL requests, includes the queryId so different operations
        don't overwrite each other (e.g., graphql_voyagerFeedDash...).
        """
        url = req.url
        # For GraphQL: extract queryId for a meaningful filename
        if "graphql" in url.lower() and "queryId=" in url:
            query_id = url.split("queryId=")[1].split("&")[0]
            # Shorten queryId: take operation name before the hash
            op_name = query_id.split(".")[0] if "." in query_id else query_id
            host = url.split("//")[-1].split("/")[0].replace(":", "_")
            return f"{host}_graphql_{op_name}"[:80]

        # Default: use URL path
        safe_name = (
            url.split("?")[0].split("//")[-1].replace("/", "_").replace(":", "_")[:80]
        )
        return safe_name

    def _on_request_will_be_sent(self, params: dict[str, Any]) -> None:
        """Handle Network.requestWillBeSent."""
        req_data = params.get("request", {})
        request_id = params.get("requestId", "")
        url = req_data.get("url", "")
        method = req_data.get("method", "GET")
        headers = req_data.get("headers", {})
        resource_type = params.get("type", "Other")
        timestamp = time.time()

        # --- Skip non-HTTP URLs (chrome-extension://, data:, about:, etc.) ---
        if not url.startswith(("http://", "https://")):
            return

        # --- Redirect chain tracking ---
        redirect_info = extract_redirect_info(params)
        if redirect_info and request_id in self.requests:
            self.requests[request_id].redirect_chain.append(redirect_info)

        # --- Apply api_only filter ---
        if self.api_only and self._is_static_request(url, resource_type):
            self._skipped_static_count += 1
            return

        # --- Apply URL keyword filter ---
        if not self._url_matches_filter(url):
            self._skipped_count += 1
            return

        initiator = params.get("initiator", {})

        captured = CapturedRequest(
            request_id=request_id,
            url=url,
            method=method,
            resource_type=resource_type,
            request_headers=headers,
            post_data=req_data.get("postData"),
            timestamp=timestamp,
            initiator_type=initiator.get("type", ""),
            initiator_url=initiator.get("url", ""),
        )
        self.requests[request_id] = captured

        # --- Auth flow detection ---
        auth_det = self.auth_flow.check_request(url, method, headers, timestamp)
        if auth_det:
            if self.progress_sink is not None:
                # Auth flows are load-bearing: the user needs to see the
                # detection so they can decide whether to authenticate
                # for the next pass.
                self.progress_sink.permanent_line(
                    f"> AUTH FLOW: {auth_det.flow_type} detected -- "
                    f"{auth_det.evidence_detail}"
                )
            else:
                logger.info(
                    "AUTH FLOW: %s detected -- %s",
                    auth_det.flow_type,
                    auth_det.evidence_detail,
                )

        # --- Real-time logging ---
        # T37: count + spinner update on the kept requests. Falls back
        # to the legacy per-request log line when no progress_sink is
        # wired (i.e. --verbose path).
        is_loggable = False
        if resource_type in ("XHR", "Fetch"):
            is_loggable = True
            if self.progress_sink is None:
                logger.info("XHR/Fetch: %s %s", method, url[:150])
        elif resource_type == "WebSocket":
            is_loggable = True
            if self.progress_sink is None:
                logger.info("WebSocket: %s", url[:150])
        elif any(p in url.lower() for p in ["/api/", "/graphql"]):
            is_loggable = True
            if self.progress_sink is None:
                logger.info("API:       %s %s", method, url[:150])
        elif self.url_filters:
            is_loggable = True
            if self.progress_sink is None:
                logger.info("Matched:   %s %s", method, url[:150])

        if is_loggable and self.progress_sink is not None:
            self._captured_count += 1
            # Surface only the path so the line stays bounded in width
            # even for 200-char query strings (matters on narrow
            # terminals -- a long line on the spinner wraps and breaks
            # the in-place rewrite).
            short_url = self._short_url_for_progress(url)
            self.progress_sink.update(
                f"Captured {self._captured_count} requests · "
                f"last: {method} {short_url} · "
                f"click around, Ctrl+C to stop"
            )

        # --- Anti-bot URL detection ---
        det = self.anti_bot.check_url(url, timestamp=timestamp)
        if det:
            if self.progress_sink is not None:
                self.progress_sink.permanent_line(
                    f"! ANTI-BOT: {det.service} detected -- {det.evidence_detail}"
                )
            else:
                logger.warning(
                    "ANTI-BOT:  %s detected -- %s",
                    det.service,
                    det.evidence_detail,
                )

    def _on_response_received(self, params: dict[str, Any]) -> None:
        """Handle Network.responseReceived."""
        request_id = params.get("requestId", "")
        resp = params.get("response", {})

        if request_id not in self.requests:
            return

        captured = self.requests[request_id]
        url = captured.url
        status_code = resp.get("status")
        response_headers = resp.get("headers", {})
        timestamp = captured.timestamp

        captured.status_code = status_code
        captured.response_headers = response_headers
        captured.mime_type = resp.get("mimeType", "")
        captured.remote_ip = resp.get("remoteIPAddress", "")

        # --- Remove media MIME requests that slipped past request-time filters ---
        if self.api_only and captured.mime_type.lower() in self._MEDIA_MIME_TYPES:
            del self.requests[request_id]
            self._skipped_static_count += 1
            return

        # --- Anti-bot header detection ---
        header_dets = self.anti_bot.check_response_headers(
            response_headers,
            request_url=url,
            timestamp=timestamp,
        )
        for det in header_dets:
            if self.progress_sink is not None:
                self.progress_sink.permanent_line(
                    f"! ANTI-BOT: {det.service} detected -- {det.evidence_detail}"
                )
            else:
                logger.warning(
                    "ANTI-BOT:  %s detected -- %s",
                    det.service,
                    det.evidence_detail,
                )

        # --- Rate limit detection ---
        if status_code is not None:
            rl_det = self.rate_limit.check_response(url, status_code, response_headers)
            if rl_det:
                if self.progress_sink is not None:
                    self.progress_sink.permanent_line(
                        f"! RATE LIMIT: {status_code} on {url[:100]} "
                        f"(limit={rl_det.limit or '?'}, "
                        f"remaining={rl_det.remaining or '?'})"
                    )
                else:
                    logger.warning(
                        "RATE LIMIT: %d on %s (limit=%s, remaining=%s)",
                        status_code,
                        url[:100],
                        rl_det.limit or "?",
                        rl_det.remaining or "?",
                    )

        # --- Auth flow response detection ---
        if status_code is not None:
            auth_det = self.auth_flow.check_response(
                url, status_code, response_headers, timestamp
            )
            if auth_det:
                if self.progress_sink is not None:
                    self.progress_sink.permanent_line(
                        f"> AUTH FLOW: {auth_det.flow_type} detected -- "
                        f"{auth_det.evidence_detail}"
                    )
                else:
                    logger.info(
                        "AUTH FLOW: %s detected -- %s",
                        auth_det.flow_type,
                        auth_det.evidence_detail,
                    )

    def _on_loading_finished(self, params: dict[str, Any]) -> None:
        """Handle Network.loadingFinished — track size and queue body fetch."""
        request_id = params.get("requestId", "")
        if request_id not in self.requests:
            return

        req = self.requests[request_id]
        req.response_size = params.get("encodedDataLength", 0)

        # Queue response body fetch — Content-Type primary classification
        if self.save_responses:
            mime_lower = req.mime_type.lower()
            # Skip media MIME types even if resource_type is XHR/Fetch
            if mime_lower in self._MEDIA_MIME_TYPES:
                return
            is_api_like = (
                req.resource_type in ("XHR", "Fetch")
                or mime_lower
                in (
                    "application/json",
                    "application/graphql+json",
                    "application/graphql-response+json",
                )
                or any(p in req.url.lower() for p in ["/api/", "/graphql"])
                or "json" in mime_lower
            )
            # Also save HTML response bodies for page navigations (Document requests)
            is_html_page = req.resource_type == "Document" and "html" in mime_lower
            if (
                is_api_like or is_html_page
            ) and req.response_size <= self.max_response_bytes:
                self._pending_body_fetches.append(request_id)

    def _on_ws_created(self, params: dict[str, Any]) -> None:
        """Handle Network.webSocketCreated."""
        ws = CapturedWebSocket(
            url=params.get("url", ""),
            request_id=params.get("requestId", ""),
        )
        self.websockets_log[ws.request_id] = ws
        if self.progress_sink is not None:
            self.progress_sink.permanent_line(f"> WS opened: {ws.url[:150]}")
        else:
            logger.info("WS opened: %s", ws.url[:150])

    _MAX_WS_FRAMES = 100  # Keep last N frames per direction to bound memory

    def _on_ws_frame_sent(self, params: dict[str, Any]) -> None:
        """Handle Network.webSocketFrameSent."""
        request_id = params.get("requestId", "")
        payload = params.get("response", {}).get("payloadData", "")
        if request_id in self.websockets_log:
            frames = self.websockets_log[request_id].frames_sent
            frames.append(payload[:500])
            if len(frames) > self._MAX_WS_FRAMES:
                del frames[: len(frames) - self._MAX_WS_FRAMES]

    def _on_ws_frame_received(self, params: dict[str, Any]) -> None:
        """Handle Network.webSocketFrameReceived."""
        request_id = params.get("requestId", "")
        payload = params.get("response", {}).get("payloadData", "")
        if request_id in self.websockets_log:
            frames = self.websockets_log[request_id].frames_received
            frames.append(payload[:500])
            if len(frames) > self._MAX_WS_FRAMES:
                del frames[: len(frames) - self._MAX_WS_FRAMES]

    def _on_frame_navigated(self, params: dict[str, Any]) -> None:
        """Handle Page.frameNavigated — queue DOM capture after navigation."""
        frame = params.get("frame", {})
        if frame.get("parentId"):
            return
        url = frame.get("url", "")
        frame_id = frame.get("id", "")
        if url and not url.startswith("about:"):
            self._pending_dom_captures.append({"url": url, "frame_id": frame_id})
            if self.progress_sink is not None:
                self.progress_sink.permanent_line(f"> Page navigated: {url[:100]}")
            else:
                logger.info("Page navigated: %s", url[:100])

    def _on_lifecycle_event(self, params: dict[str, Any]) -> None:
        """Handle Page.lifecycleEvent — capture DOM when page is fully loaded."""
        event_name = params.get("name", "")
        if event_name in ("networkIdle", "networkAlmostIdle", "load"):
            if self._pending_dom_captures:
                self._ready_dom_captures.extend(self._pending_dom_captures)
                self._pending_dom_captures.clear()

    # ------------------------------------------------------------------
    # Main Monitor Loop
    # ------------------------------------------------------------------

    async def monitor(self, duration: int = 0) -> None:
        """Listen for CDP events until stopped or duration expires."""
        await self._enable_domains()
        self._running = True
        self._start_time = time.time()
        last_tab_poll = time.time()

        if self.progress_sink is not None:
            # T37: collapse the multi-line banner into one permanent
            # line above the live spinner. The original banner is
            # great context but the spinner repaints itself faster
            # than the eye can read 8 separate lines on a normal scan.
            self.progress_sink.permanent_line(
                "browser-recon: monitoring active -- browse the site, "
                "Ctrl+C (or `recon stop`) when done."
            )
            # Prime the spinner with the zero-count line so the user
            # immediately sees the live indicator even before the first
            # captured request.
            self.progress_sink.update(
                "Captured 0 requests · click around, Ctrl+C to stop"
            )
        else:
            print()
            logger.info("=" * 65)
            logger.info("  MONITORING ACTIVE -- Browse the website now!")
            if self.url_filters:
                logger.info(
                    "  URL filter: only capturing URLs containing: %s",
                    ", ".join(f'"{kw}"' for kw in self.url_filters),
                )
            else:
                logger.info("  URL filter: OFF (capturing all requests)")
            if self.api_only:
                logger.info(
                    "  API-only mode: ON "
                    "(skipping images, JS, CSS, fonts, media, trackers)"
                )
            if self.capture_dom:
                logger.info("  DOM capture: ON (snapshots on each page load)")
            if self.save_responses:
                logger.info(
                    "  Response save: ON (API/XHR bodies, max %dKB each)",
                    self.max_response_bytes // 1024,
                )
            if self.capture_interactions:
                logger.info(
                    "  Interaction capture: ON "
                    "(clicks, inputs, scrolls — passwords masked)"
                )
            # T13 (phase-2 § 9): document the cancel path explicitly. The
            # user can either Ctrl+C in this terminal (writes the .stop
            # sentinel + uploads what's been captured so far) OR run
            # ``recon stop`` from another terminal. Two phrasings because
            # the user's mental model of "abort" can mean either "give up"
            # or "I'm done, finalise the report".
            logger.info("  Press Ctrl+C (or run `recon stop`) when done to")
            logger.info("    generate the report from what's been captured.")
            logger.info("=" * 65)
            print()

        # Map CDP event names to handler methods
        handlers: dict[str, Callable[[dict[str, Any]], None]] = {
            "Network.requestWillBeSent": self._on_request_will_be_sent,
            "Network.responseReceived": self._on_response_received,
            "Network.loadingFinished": self._on_loading_finished,
            "Network.webSocketCreated": self._on_ws_created,
            "Network.webSocketFrameSent": self._on_ws_frame_sent,
            "Network.webSocketFrameReceived": self._on_ws_frame_received,
        }
        if self.capture_dom:
            handlers["Page.frameNavigated"] = self._on_frame_navigated
            handlers["Page.lifecycleEvent"] = self._on_lifecycle_event
        if self.capture_interactions or self.capture_dom:
            handlers["Runtime.consoleAPICalled"] = self._on_console_api_called
            handlers["Runtime.bindingCalled"] = self._on_binding_called

        self._event_handlers = handlers

        # Start listener tasks for already-connected extra tabs
        for ws in self._extra_ws:
            task = asyncio.create_task(self._extra_tab_listener(ws))
            self._extra_tasks.append(task)

        try:
            while self._running:
                if duration and (time.time() - self._start_time) > duration:
                    logger.info("Duration limit (%ds) reached.", duration)
                    break

                # Check stop file
                if self._stop_file and self._stop_file.exists():
                    logger.info("Stop file detected -- shutting down cleanly...")
                    try:
                        self._stop_file.unlink()
                    except Exception:
                        pass
                    break

                # Poll for new tabs every 5 seconds
                now = time.time()
                if now - last_tab_poll >= 5.0:
                    await self._poll_new_tabs()
                    last_tab_poll = now

                # Process pending DOM captures
                if self.capture_dom and self._ready_dom_captures:
                    capture_info = self._ready_dom_captures.pop(0)
                    # SPA captures (no frame_id) need more time for DOM to settle
                    delay = 1.5 if not capture_info.get("frame_id") else 0.5
                    await asyncio.sleep(delay)
                    await self._capture_dom_snapshot(
                        url=capture_info["url"],
                        frame_id=capture_info.get("frame_id", ""),
                    )

                # Process pending response body fetches
                if self._pending_body_fetches:
                    req_id = self._pending_body_fetches.pop(0)
                    await self._fetch_response_body(req_id)

                # Receive from primary WebSocket
                try:
                    raw = await asyncio.wait_for(self._ws.recv(), timeout=1.0)
                except TimeoutError:
                    continue
                except websockets.exceptions.ConnectionClosed:
                    logger.warning("Chrome closed the connection.")
                    break

                msg = json.loads(raw)
                method = msg.get("method", "")

                handler = handlers.get(method)
                if handler:
                    handler(msg.get("params", {}))

        except asyncio.CancelledError:
            pass

        # Cancel extra tab listeners
        for task in self._extra_tasks:
            task.cancel()
        for task in self._extra_tasks:
            try:
                await task
            except asyncio.CancelledError:
                pass

        elapsed = time.time() - self._start_time
        if self.progress_sink is not None:
            self.progress_sink.finish(
                f"Monitoring stopped. Captured {len(self.requests)} requests "
                f"in {elapsed:.0f}s."
            )
            if self._skipped_count:
                self.progress_sink.permanent_line(
                    f"  ({self._skipped_count} requests filtered out by URL keywords)"
                )
            if self._skipped_static_count:
                self.progress_sink.permanent_line(
                    f"  ({self._skipped_static_count} static assets skipped "
                    "by api-only mode)"
                )
        else:
            logger.info(
                "Monitoring stopped. Captured %d requests in %.0fs.",
                len(self.requests),
                elapsed,
            )
            if self._skipped_count:
                logger.info(
                    "  (%d requests filtered out by URL keywords)",
                    self._skipped_count,
                )
            if self._skipped_static_count:
                logger.info(
                    "  (%d static assets skipped by api-only mode)",
                    self._skipped_static_count,
                )

    def set_stop_file(self, path: Path) -> None:
        """Set a stop file path. Monitor will stop when this file exists."""
        self._stop_file = path
        # Clean up any leftover stop file from previous run
        if path.exists():
            path.unlink()

    def stop(self) -> None:
        """Signal the monitor to stop."""
        self._running = False

    async def _fetch_response_body(self, request_id: str) -> None:
        """Fetch and store the response body for a request via CDP."""
        if request_id not in self.requests:
            return
        try:
            msg_id = await self._send(
                "Network.getResponseBody", {"requestId": request_id}
            )
            result = await self._wait_for_response(msg_id, timeout=3.0)
            if not result:
                return
            body = result.get("result", {}).get("body", "")
            is_base64 = result.get("result", {}).get("base64Encoded", False)

            if is_base64:
                self.requests[
                    request_id
                ].response_body = f"[binary, base64 encoded, ~{len(body)} chars]"
            elif body:
                if len(body) > self.max_response_bytes:
                    body = body[: self.max_response_bytes] + "\n... [TRUNCATED]"
                self.requests[request_id].response_body = body
        except Exception:
            pass  # Non-critical

    async def fetch_cookies(self) -> None:
        """Fetch all cookies from the browser session."""
        try:
            msg_id = await self._send("Network.getAllCookies")
            result = await self._wait_for_response(msg_id, timeout=10.0)
            if not result:
                logger.warning(
                    "Cookie fetch timed out (10s) -- skipping cookie analysis."
                )
                return

            for c in result.get("result", {}).get("cookies", []):
                val = c.get("value", "")
                # T34.1: keep the FULL cookie value in ``_full_value`` so
                # the local validation + replay pipelines can ship it on
                # the wire. ``value_preview`` stays as the 50-char
                # truncated form for legacy reads (renderer, detectors).
                # The PII scrubber clears ``_full_value`` before upload
                # so the untruncated value never leaves the user's
                # machine.
                self.cookies.append(
                    CapturedCookie(
                        name=c.get("name", ""),
                        value_preview=val[:50] + "..." if len(val) > 50 else val,
                        domain=c.get("domain", ""),
                        path=c.get("path", ""),
                        secure=c.get("secure", False),
                        http_only=c.get("httpOnly", False),
                        same_site=c.get("sameSite", ""),
                        _full_value=val,
                    )
                )

            # Anti-bot cookie analysis was previously emitted here as a
            # warning log. It has been removed (fix #1.A) because the
            # underlying ``check_cookies`` did naive name-substring
            # matching with no cookie-domain scoping, producing false
            # positives on stale cross-contaminated cookies. The real
            # detection pipeline runs at report time via
            # ``run_detection`` over the sanitised blob; the per-vendor
            # detectors there scope cookies correctly.
        except Exception as e:
            logger.warning("Cookie fetch failed: %s -- skipping cookie analysis.", e)

    async def close(self) -> None:
        """Close all WebSocket connections."""
        for ws in self._extra_ws:
            try:
                await ws.close()
            except Exception:
                pass
        if self._ws:
            await self._ws.close()

    # ------------------------------------------------------------------
    # Request Classification
    # ------------------------------------------------------------------

    @staticmethod
    def _classify_request(req: CapturedRequest) -> str:
        """Classify a request using Content-Type primary, URL secondary."""
        # Resource type primary signal
        if req.resource_type in ("XHR", "Fetch"):
            return "api"
        if "json" in req.mime_type.lower():
            return "api"
        if req.resource_type == "Document":
            return "page_load"

        # URL patterns as secondary signal
        if any(p in req.url.lower() for p in ["/api/", "/graphql"]):
            return "api"

        # Static check
        url_path = req.url.split("?")[0].split("#")[0].lower()
        static_exts = (
            ".css",
            ".js",
            ".png",
            ".jpg",
            ".jpeg",
            ".gif",
            ".svg",
            ".woff",
            ".woff2",
            ".ttf",
            ".ico",
            ".map",
        )
        if any(url_path.endswith(ext) for ext in static_exts):
            return "static"

        return "other"

    # ------------------------------------------------------------------
    # Export
    # ------------------------------------------------------------------

    def export(self, output_dir: Path | str | None = None) -> dict[str, Any]:
        """Export captured data. Returns the report dict and saves files.

        Creates:
            <output_dir>/
                recon_capture.json     -- Raw data
                responses/             -- Individual response body files
                dom_snapshots/         -- Full HTML per page (if --capture-dom)

        ``output_dir`` is the same scan-output directory the CLI plumbs
        through ``start_capture(output_dir=...)`` (per-domain + timestamp
        subdir under ``~/recon-runs``). When ``None`` we fall back to a
        cwd-relative ``./browser-recon/`` for backward-compat with
        callers that invoke the monitor outside the CLI scan flow.

        Report generation (summary.md, report.md) is done by the CLI
        entrypoint using the reports/ package.
        """
        elapsed = time.time() - self._start_time if self._start_time else 0

        if output_dir is None:
            resolved = Path.cwd() / "browser-recon"
        else:
            resolved = Path(output_dir)
        resolved.mkdir(parents=True, exist_ok=True)
        output_dir = resolved
        output_file = output_dir / "recon_capture.json"

        # Classify requests
        api_endpoints: list[dict[str, Any]] = []
        static_assets: list[dict[str, Any]] = []
        page_loads: list[dict[str, Any]] = []
        other_requests: list[dict[str, Any]] = []

        for req in self.requests.values():
            # Skip data URIs
            if req.url.startswith("data:"):
                continue

            entry = asdict(req)
            entry.pop("response_body", None)

            category = self._classify_request(req)
            if category == "api":
                api_endpoints.append(entry)
            elif category == "page_load":
                page_loads.append(entry)
            elif category == "static":
                static_assets.append(entry)
            else:
                other_requests.append(entry)

        report: dict[str, Any] = {
            "meta": {
                "captured_at": datetime.now(UTC).isoformat(),
                "duration_seconds": round(elapsed, 1),
                "total_requests": len(self.requests),
                "dom_capture_enabled": self.capture_dom,
                "url_filters": self.url_filters if self.url_filters else None,
                "api_only_mode": self.api_only,
                "requests_filtered_out": self._skipped_count,
                "static_assets_skipped": self._skipped_static_count,
            },
            "summary": {
                "api_endpoints_count": len(api_endpoints),
                "static_assets_count": len(static_assets),
                "page_loads_count": len(page_loads),
                "websocket_connections_count": len(self.websockets_log),
                "cookies_count": len(self.cookies),
                "dom_snapshots_count": len(self.dom_snapshots),
                "unique_domains": list(
                    {
                        req.url.split("/")[2]
                        for req in self.requests.values()
                        if req.url.startswith("http")
                    }
                ),
            },
            "api_endpoints": api_endpoints,
            "page_loads": page_loads,
            "websocket_connections": [
                asdict(ws) for ws in self.websockets_log.values()
            ],
            "cookies": [asdict(c) for c in self.cookies],
            "anti_bot_analysis": self.anti_bot.get_summary(),
            "rate_limit_analysis": self.rate_limit.get_summary(),
            "auth_flow_analysis": self.auth_flow.get_summary(),
            "dom_snapshots": [
                {
                    "url": snap.url,
                    "title": snap.title,
                    "timestamp": snap.timestamp,
                    "frame_id": snap.frame_id,
                    "html_size_kb": len(snap.outer_html) // 1024,
                    "total_element_count": snap.total_element_count,
                    "has_json_ld": snap.has_json_ld,
                    "has_microdata": snap.has_microdata,
                    "has_og_tags": snap.has_og_tags,
                    "data_attributes_count": snap.data_attributes_count,
                    "iframe_count": snap.iframe_count,
                    "form_count": snap.form_count,
                    "meta_tags": snap.meta_tags[:30],
                }
                for snap in self.dom_snapshots
            ],
            "static_assets_summary": {
                "count": len(static_assets),
                "total_size_bytes": sum(
                    a.get("response_size", 0) for a in static_assets
                ),
            },
            "other_requests": other_requests,
            "interactions": (
                [asdict(i) for i in self.interactions] if self.interactions else []
            ),
        }

        # Save full HTML snapshots as separate files
        if self.dom_snapshots:
            dom_dir = output_dir / "dom_snapshots"
            dom_dir.mkdir(exist_ok=True)
            for i, snap in enumerate(self.dom_snapshots):
                safe_name = (
                    snap.url.split("//")[-1]
                    .replace("/", "_")
                    .replace("?", "_")
                    .replace("&", "_")[:80]
                )
                html_file = dom_dir / f"{i:02d}_{safe_name}.html"
                html_file.write_text(snap.outer_html, encoding="utf-8")
            logger.info(
                "  DOM snapshots saved to: %s (%d files)",
                dom_dir.resolve(),
                len(self.dom_snapshots),
            )

        # Save response bodies as individual files —
        # split into api/ and html/ subfolders
        responses_saved = 0
        if self.save_responses:
            api_dir = output_dir / "responses" / "api"
            html_dir = output_dir / "responses" / "html"
            api_dir.mkdir(parents=True, exist_ok=True)
            html_dir.mkdir(parents=True, exist_ok=True)
            _resp_name_counter: dict[str, int] = {}
            for req in self.requests.values():
                if req.response_body and not req.response_body.startswith("[binary"):
                    safe_name = self._make_response_filename(req)

                    # Route to subfolder based on request type
                    is_html_doc = (
                        req.resource_type == "Document"
                        and "html" in req.mime_type.lower()
                    )
                    if is_html_doc:
                        target_dir = html_dir
                        ext = ".html"
                    else:
                        target_dir = api_dir
                        ext = ".json" if "json" in req.mime_type.lower() else ".txt"

                    base_key = f"{req.method}_{safe_name}{ext}"
                    # Avoid collisions: append counter if name already used
                    count = _resp_name_counter.get(base_key, 0)
                    _resp_name_counter[base_key] = count + 1
                    if count > 0:
                        resp_file = (
                            target_dir / f"{req.method}_{safe_name}_{count}{ext}"
                        )
                    else:
                        resp_file = target_dir / base_key
                    resp_file.write_text(req.response_body, encoding="utf-8")
                    req.saved_response_file = resp_file.name
                    responses_saved += 1
            if responses_saved:
                logger.info(
                    "  Response bodies saved to: %s (%d files)",
                    (output_dir / "responses").resolve(),
                    responses_saved,
                )

        # Save main JSON report
        output_file.write_text(json.dumps(report, indent=2, default=str))

        # Print quick summary to console
        print()
        logger.info("=" * 65)
        logger.info("  CAPTURE SUMMARY")
        logger.info("=" * 65)
        logger.info("  Output folder:     %s", output_dir.resolve())
        logger.info("  Total requests:    %d", report["meta"]["total_requests"])
        logger.info("  API endpoints:     %d", report["summary"]["api_endpoints_count"])
        logger.info(
            "  WebSocket conns:   %d",
            report["summary"]["websocket_connections_count"],
        )
        logger.info("  Cookies:           %d", report["summary"]["cookies_count"])
        logger.info("  DOM snapshots:     %d", report["summary"]["dom_snapshots_count"])
        if self.save_responses:
            bodies_saved = sum(
                1
                for r in self.requests.values()
                if r.response_body and not r.response_body.startswith("[binary")
            )
            logger.info("  Response bodies:   %d saved", bodies_saved)
        logger.info(
            "  Unique domains:    %d",
            len(report["summary"]["unique_domains"]),
        )
        if self.url_filters:
            logger.info(
                "  URL filter:        %s",
                ", ".join(f'"{kw}"' for kw in self.url_filters),
            )
            logger.info("  Filtered out:      %d requests", self._skipped_count)
        if self.api_only:
            logger.info(
                "  Static skipped:    %d (api-only mode)",
                self._skipped_static_count,
            )
        logger.info("=" * 65)
        print()

        # Anti-bot console summary
        ab_summary = report["anti_bot_analysis"]
        if ab_summary["protected"]:
            print()
            logger.warning("=" * 65)
            logger.warning("  ANTI-BOT PROTECTION DETECTED")
            logger.warning("=" * 65)
            for svc in ab_summary["services_detected"]:
                evidence = [
                    d["evidence_detail"]
                    for d in ab_summary["details"]
                    if d["service"] == svc
                ]
                logger.warning("  %s", svc)
                for ev in evidence:
                    logger.warning("    -> %s", ev)
            logger.warning("=" * 65)
            print()
        else:
            logger.info("No anti-bot protection detected.")

        # Rate limit console summary
        rl_summary = report["rate_limit_analysis"]
        if rl_summary.get("rate_limited"):
            logger.warning(
                "Rate limiting detected on %d endpoint(s).",
                rl_summary.get("endpoints_affected", 0),
            )

        # Auth flow console summary
        af_summary = report["auth_flow_analysis"]
        if af_summary.get("auth_detected"):
            logger.info(
                "Auth flows detected: %s",
                ", ".join(af_summary.get("flow_types", [])),
            )

        if api_endpoints:
            logger.info("Top API endpoints found:")
            seen: set[str] = set()
            for ep in api_endpoints[:20]:
                url_short = ep["url"].split("?")[0]
                key = f"{ep['method']} {url_short}"
                if key not in seen:
                    seen.add(key)
                    logger.info(
                        "  %s %s [%s]",
                        ep["method"],
                        url_short[:100],
                        ep.get("mime_type", "?"),
                    )

        # Output files listing
        print()
        logger.info("=" * 65)
        logger.info("  OUTPUT FILES")
        logger.info("=" * 65)
        logger.info("  %s/", output_dir.resolve())
        logger.info("    recon_capture.json   (raw data)")
        if responses_saved:
            logger.info("    responses/           (%d files)", responses_saved)
        if self.dom_snapshots:
            logger.info("    dom_snapshots/       (%d files)", len(self.dom_snapshots))
        logger.info("=" * 65)
        print()

        return report
