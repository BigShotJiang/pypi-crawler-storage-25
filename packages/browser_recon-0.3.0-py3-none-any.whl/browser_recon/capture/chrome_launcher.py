"""Chrome launcher: start Chrome with remote debugging on a given port.

Verbatim port (with public renames and a port-specific conflict check)
of the four private helpers in
``~/.claude/skills/browser-recon/scripts/cdp_monitor.py`` (lines
75-157, task 1.a.15). Per ``phase-1-capture-spec.md`` § How capture
works -- Launch.

The public entry point :func:`launch` orchestrates the three steps:

1. Resolve a Chrome executable -- caller-supplied or auto-detected via
   :func:`find_chrome` (cross-platform: Windows, macOS, Linux, plus a
   ``shutil.which`` fallback).
2. Detect a port-conflict via :func:`is_port_in_use` (a portable
   ``socket.bind`` probe -- no ``lsof``/``netstat`` dependency).
   If the port is busy and ``kill_existing`` is False, raise
   :exc:`PortInUseError`. Otherwise call :func:`kill_chrome_processes`,
   wait briefly for the OS to release the port, and re-probe.
3. Launch Chrome via :func:`launch_chrome_process` and return the
   :class:`subprocess.Popen` handle so callers manage the lifecycle.

Per the spec, this is NOT headless -- the user drives a real Chrome
window.

Profile resolution (fix #3, ``documentation/fixes_needed.md`` § 3).
By default, every scan gets a fresh ephemeral user-data-dir created
via :func:`tempfile.mkdtemp`. The directory is registered for cleanup
at process exit via :func:`atexit.register` so it survives Chrome
crashes, ``KeyboardInterrupt``, and normal exit.

Two opt-ins keep state across scans:

* :func:`launch` accepting ``use_existing_profile=True`` reuses the
  user's OS-default Chrome profile via
  :func:`default_chrome_profile_path` -- the only mode that exposes
  the user's real cookies + storage to the target site. The CLI prints
  a loud warning when this is set.
* :func:`launch` accepting ``user_data_dir=<path>`` points at any
  pre-prepared user-data-dir. No cleanup; the caller manages it.
"""

from __future__ import annotations

import atexit
import json
import logging
import os
import platform
import shutil
import socket
import subprocess
import tempfile
import time
from pathlib import Path

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Exceptions
# ---------------------------------------------------------------------------


class ChromeNotFoundError(RuntimeError):
    """Raised when no Chrome executable can be located."""


class PortInUseError(RuntimeError):
    """Raised when the requested debug port is already bound."""

    def __init__(self, port: int, message: str = "") -> None:
        self.port = port
        super().__init__(message or f"Port {port} is in use.")


class ChromeLaunchError(RuntimeError):
    """Raised when Chrome cannot be launched for any other reason."""


# ---------------------------------------------------------------------------
# Helpers (all public so tests and other capture modules can reuse them)
# ---------------------------------------------------------------------------


def is_port_in_use(port: int, host: str = "127.0.0.1") -> bool:
    """Return True if ``host:port`` already has a listener.

    Portable across Linux, macOS and Windows: tries to ``bind`` a fresh
    TCP socket and treats any ``OSError`` (typically ``EADDRINUSE``) as
    "in use". The bound socket is closed immediately by the ``with``
    block, so this probe leaves no listener behind.
    """
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        try:
            sock.bind((host, port))
        except OSError:
            return True
        return False


def default_chrome_profile_path() -> Path:
    """Return the OS-default Chrome user-data-dir for the current host.

    Used by :func:`launch` when ``use_existing_profile=True`` (the
    opt-in for authenticated-flow scans -- see ``--use-existing-profile``
    in ``browser_recon/cli/main.py``).

    Platform mapping (per fix #3 spec):

    * Linux: ``~/.config/google-chrome``
    * macOS: ``~/Library/Application Support/Google/Chrome``
    * Windows: ``%LOCALAPPDATA%\\Google\\Chrome\\User Data``
      (falls back to ``~/AppData/Local/Google/Chrome/User Data`` if
      ``LOCALAPPDATA`` is unset).
    """
    home = Path.home()
    system = platform.system()
    if system == "Windows":
        local_app_data = os.environ.get("LOCALAPPDATA")
        base = Path(local_app_data) if local_app_data else home / "AppData" / "Local"
        return base / "Google" / "Chrome" / "User Data"
    if system == "Darwin":
        return home / "Library" / "Application Support" / "Google" / "Chrome"
    # Linux / other POSIX.
    return home / ".config" / "google-chrome"


def make_ephemeral_user_data_dir() -> Path:
    """Create a fresh per-scan user-data-dir and register it for cleanup.

    Returns the new directory path. The directory is created via
    :func:`tempfile.mkdtemp` with a ``browser-recon-`` prefix (so it's
    obvious in ``/tmp`` listings what produced it) and registered with
    :func:`atexit.register` so it survives:

    * normal Python exit
    * uncaught exceptions
    * ``KeyboardInterrupt`` propagating out of the CLI
    * Chrome crashing while the parent Python process is alive (the
      atexit handler still fires when Python exits afterwards)

    Callers wanting belt-and-braces cleanup can still wrap their own
    ``try/finally`` around the launch; the atexit hook is idempotent
    via ``shutil.rmtree(..., ignore_errors=True)``.
    """
    user_data_dir = Path(tempfile.mkdtemp(prefix="browser-recon-"))
    atexit.register(shutil.rmtree, str(user_data_dir), True)
    _seed_first_run_state(user_data_dir)
    logger.debug("Registered ephemeral profile for cleanup: %s", user_data_dir)
    return user_data_dir


def _seed_first_run_state(user_data_dir: Path) -> None:
    """Pre-populate the user-data-dir so Chrome skips its welcome UI.

    On Linux specifically (Debian/Ubuntu/Fedora .deb/.rpm builds of
    Chrome), passing ``--no-first-run`` on argv is NOT enough: the
    binary still pops a GTK "Welcome to Google Chrome -- make me your
    default browser? send usage stats?" modal that steals focus from
    the CDP-attached tab. Clicking through it often closes that tab,
    and the capture exits with zero requests recorded.

    Two on-disk artefacts together suppress the dialog reliably:

    * ``<user-data-dir>/First Run`` -- the Chromium "first run already
      happened" sentinel. Chromium's ``IsFirstRun()`` returns false
      when this file is present, so the welcome flow short-circuits.
    * ``<user-data-dir>/Local State`` -- the global preferences JSON.
      Pre-answering ``check_default_browser`` and the metrics-reporting
      consent stops the dialog from showing even on builds where the
      sentinel alone isn't honoured (some Fedora packages).

    Both are best-effort: failures are logged and ignored, since a
    permission glitch on the tempdir shouldn't block the scan.
    """
    try:
        # Empty sentinel -- Chromium only checks for presence.
        (user_data_dir / "First Run").touch()
        local_state = {
            "browser": {
                "check_default_browser": False,
                "default_browser_setting_enabled": False,
            },
            "user_experience_metrics": {
                "reporting_enabled": False,
            },
        }
        (user_data_dir / "Local State").write_text(
            json.dumps(local_state), encoding="utf-8"
        )
    except OSError as exc:
        logger.warning("Failed to seed first-run state in %s: %s", user_data_dir, exc)


def find_chrome() -> str | None:
    """Auto-detect a Chrome executable path.

    Searches platform-specific install locations first, then falls back
    to :func:`shutil.which` for any of the common Chrome/Chromium
    binary names. Returns the path as a string, or ``None`` if no
    Chrome installation was found.
    """
    if platform.system() == "Windows":
        candidates = [
            Path(os.environ.get("PROGRAMFILES", ""))
            / "Google"
            / "Chrome"
            / "Application"
            / "chrome.exe",
            Path(os.environ.get("PROGRAMFILES(X86)", ""))
            / "Google"
            / "Chrome"
            / "Application"
            / "chrome.exe",
            Path(os.environ.get("LOCALAPPDATA", ""))
            / "Google"
            / "Chrome"
            / "Application"
            / "chrome.exe",
        ]
    elif platform.system() == "Darwin":
        candidates = [
            Path("/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"),
        ]
    else:
        candidates = [
            Path("/usr/bin/google-chrome"),
            Path("/usr/bin/google-chrome-stable"),
            Path("/usr/bin/chromium"),
            Path("/usr/bin/chromium-browser"),
        ]

    for candidate in candidates:
        if candidate.exists():
            return str(candidate)

    # Fallback: PATH lookup.
    for name in [
        "chrome",
        "google-chrome",
        "google-chrome-stable",
        "chromium",
        "chromium-browser",
    ]:
        found = shutil.which(name)
        if found:
            return found

    return None


def kill_chrome_processes() -> None:
    """Kill all Chrome processes on the host.

    Mirrors the source skill's coarse approach: ``taskkill`` on
    Windows, ``pkill -f chrome`` everywhere else. Failures are logged
    as warnings rather than raised -- a missing ``pkill`` or a "no
    matching processes" exit is non-fatal here, since the caller will
    re-probe :func:`is_port_in_use` afterwards.
    """
    logger.info("Killing existing Chrome processes...")
    try:
        if platform.system() == "Windows":
            subprocess.run(
                ["taskkill", "/F", "/IM", "chrome.exe"],
                capture_output=True,
                timeout=10,
            )
        else:
            subprocess.run(
                ["pkill", "-f", "chrome"],
                capture_output=True,
                timeout=10,
            )
    except Exception as exc:  # noqa: BLE001 -- best-effort cleanup
        logger.warning("Failed to kill Chrome: %s", exc)


def launch_chrome_process(
    chrome_path: str,
    port: int,
    url: str,
    user_data_dir: Path | str | None = None,
) -> subprocess.Popen[bytes]:
    """Spawn Chrome with remote debugging on ``port`` and load ``url``.

    Builds the argv list, redirects stdout/stderr to ``DEVNULL`` so
    Chrome's chatter doesn't pollute the parent process, then sleeps
    for 3 seconds to give the debug port time to come up before
    returning. Returns the live :class:`subprocess.Popen` handle.

    Parameters
    ----------
    user_data_dir:
        Explicit ``--user-data-dir`` for Chrome. When ``None`` (default)
        an ephemeral per-scan profile is created via
        :func:`make_ephemeral_user_data_dir` and registered for
        process-exit cleanup. Pass a ``Path`` / ``str`` to opt into a
        specific (non-cleaned-up) profile -- e.g. the OS-default
        profile from :func:`default_chrome_profile_path`.
    """
    resolved_user_data_dir: Path
    is_ephemeral_profile: bool
    if user_data_dir is None:
        resolved_user_data_dir = make_ephemeral_user_data_dir()
        is_ephemeral_profile = True
    else:
        resolved_user_data_dir = Path(user_data_dir)
        is_ephemeral_profile = False
    cmd = [
        chrome_path,
        f"--remote-debugging-port={port}",
        f"--user-data-dir={resolved_user_data_dir}",
    ]
    # A fresh ephemeral profile triggers Chrome's first-run UI:
    # "Welcome to Chrome", "Set as default browser?", and (on newer
    # builds) the "What's new" tab. Those dialogs steal focus from the
    # target tab and the user clicking through them often closes the
    # CDP-attached page, killing the capture before any traffic is
    # recorded. The flags below are the same ones Puppeteer / Playwright
    # set by default; they apply only to ephemeral profiles so that
    # ``--use-existing-profile`` users keep their real Chrome experience
    # untouched.
    if is_ephemeral_profile:
        cmd.extend(
            [
                "--no-first-run",
                "--no-default-browser-check",
                "--disable-features=ChromeWhatsNewUI",
            ]
        )
    cmd.append(url)
    logger.info("Launching Chrome: %s", " ".join(cmd))
    proc: subprocess.Popen[bytes] = subprocess.Popen(
        cmd,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )
    # Wait for Chrome to start and open the debugging port.
    time.sleep(3)
    return proc


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------


def launch(
    url: str,
    port: int = 9222,
    kill_existing: bool = False,
    chrome_path: str | None = None,
    *,
    use_existing_profile: bool = False,
    user_data_dir: Path | str | None = None,
) -> subprocess.Popen[bytes]:
    """Launch Chrome with remote debugging on ``port`` and load ``url``.

    Parameters
    ----------
    url:
        The initial URL to open in the launched Chrome window.
    port:
        The remote-debugging port. Default ``9222`` matches the
        existing capture pipeline.
    kill_existing:
        When True, if ``port`` is already in use, kill all running
        Chrome processes and retry. When False (default), raise
        :exc:`PortInUseError`.
    chrome_path:
        Optional explicit path to a Chrome executable. When omitted,
        the function auto-detects via :func:`find_chrome`.
    use_existing_profile:
        When True, launch Chrome using the OS-default user-data-dir
        (per :func:`default_chrome_profile_path`). The user's existing
        cookies + storage will be sent to the target site -- the CLI
        prints a loud warning when this is set. Mutually exclusive with
        ``user_data_dir``.
    user_data_dir:
        Explicit ``--user-data-dir`` path for Chrome. When set, takes
        precedence over ``use_existing_profile``. When both are unset
        (default), an ephemeral profile is created via
        :func:`make_ephemeral_user_data_dir` and cleaned up at process
        exit.

    Returns
    -------
    subprocess.Popen[bytes]
        The live Chrome process. Callers are responsible for terminating
        it (e.g. ``proc.terminate(); proc.wait(timeout=10)``).

    Raises
    ------
    ChromeNotFoundError
        Chrome could not be located and ``chrome_path`` was not given.
    PortInUseError
        ``port`` is already in use, and either ``kill_existing`` was
        False or the port remained busy after killing Chrome.
    """
    resolved_path = chrome_path or find_chrome()
    if resolved_path is None:
        raise ChromeNotFoundError(
            "Chrome not found. Install Chrome or pass chrome_path explicitly."
        )
    logger.info("Chrome found at: %s", resolved_path)

    if is_port_in_use(port):
        if not kill_existing:
            raise PortInUseError(
                port,
                f"Port {port} is in use. Pass kill_existing=True to kill the "
                "holder and retry.",
            )
        kill_chrome_processes()
        # Give the OS a moment to release the port.
        time.sleep(2)
        if is_port_in_use(port):
            raise PortInUseError(
                port,
                f"Port {port} still in use after killing Chrome.",
            )

    # Resolve the user-data-dir before launching:
    # 1. Explicit ``user_data_dir`` wins (power-user contract; no
    #    cleanup since the caller manages the path).
    # 2. ``use_existing_profile`` -> OS default Chrome profile (no
    #    cleanup; reusing the user's real profile).
    # 3. Otherwise -> None, meaning ``launch_chrome_process`` will
    #    create + register an ephemeral tempdir.
    resolved_user_data_dir: Path | str | None
    if user_data_dir is not None:
        resolved_user_data_dir = user_data_dir
    elif use_existing_profile:
        resolved_user_data_dir = default_chrome_profile_path()
    else:
        resolved_user_data_dir = None

    return launch_chrome_process(
        resolved_path, port, url, user_data_dir=resolved_user_data_dir
    )
