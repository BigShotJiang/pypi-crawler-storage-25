"""Detection subpackage (capture-time only).

T53.6 trimmed this package to the live detectors the CDP capture path
needs at request time (anti-bot URL/cookie pattern matching, auth-flow
classification, rate-limit-signal extraction). The full detection
orchestrator + per-vendor rules now live server-side under
:mod:`browser_recon_server.detection_server`.
"""
