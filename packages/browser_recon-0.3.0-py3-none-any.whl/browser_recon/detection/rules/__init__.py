"""Detection rules (capture-time only).

T53.6 trimmed this package to the live detectors the CDP capture
path uses inside :mod:`browser_recon.capture.cdp_monitor`:

* :mod:`browser_recon.detection.rules.anti_bot` -- anti-bot URL +
  cookie pattern matcher.
* :mod:`browser_recon.detection.rules.auth_flow` -- auth-flow
  request classifier.
* :mod:`browser_recon.detection.rules.rate_limit_signals` --
  per-host rate-limit header extractor.

Heavyweight rules (block-page detection, GraphQL fingerprinting,
pagination heuristics, per-vendor anti-bot drilldowns) moved to the
server-side ``browser_recon_server.detection_server`` package.
"""
