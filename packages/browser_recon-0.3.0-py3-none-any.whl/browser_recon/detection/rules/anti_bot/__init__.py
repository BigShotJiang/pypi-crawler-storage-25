"""Anti-bot protection detection via URL patterns, response headers, and cookies.

Extracted from the existing browser-recon skill at
``~/.claude/skills/browser-recon/scripts/detectors/anti_bot.py`` (task 1.a.05).

This is a single-file consolidated module covering all vendors. Task 1.b will
split it into per-vendor modules.

Tier A fixes applied (per ``build-sequence.md`` § Tier A — anti_bot.py):

1. **Arkose Labs split** — ``client-api.arkoselabs.com`` and
   ``arkoselabs.com`` were previously bundled under the ``Kasada`` vendor
   entry, which is wrong (they are the Arkose Labs FunCaptcha service, not
   Kasada). They now live under a separate ``Arkose Labs`` vendor key.
2. **Turnstile narrowing** — the loose ``/turnstile/`` URL pattern fired on
   any URL containing that substring (e.g.,
   ``random-site.com/some/turnstile/widget``). Narrowed to
   ``challenges.cloudflare.com/turnstile/`` so it only fires on the
   Cloudflare Turnstile origin. Yes, this is now technically a substring of
   ``challenges.cloudflare.com``; it is preserved as a recognisable line
   item documenting Turnstile specifically.
3. **DataDome ``/captcha/`` narrowing** — the bare ``/captcha/`` URL
   pattern fired on any URL containing that substring (e.g.,
   ``api.coinmarketcap.com/data-api/v3/captcha/type``, which is CMC's own
   captcha API and unrelated to DataDome). Narrowed to
   ``datadome.co/captcha/`` so it only fires on the DataDome captcha
   origin. As with Turnstile, this is now technically a substring of
   ``datadome.co``; it is preserved as a recognisable line item
   documenting the DataDome captcha endpoint specifically.

Apart from those three fixes and the import path swap (skill flat-layout
hack → ``browser_recon.models``), behaviour is identical to the source
skill.
"""

from __future__ import annotations

from dataclasses import asdict
from typing import Any

from browser_recon.models import AntiBotDetection

# ---------------------------------------------------------------------------
# Detection patterns
# ---------------------------------------------------------------------------

ANTI_BOT_URL_PATTERNS: dict[str, list[str]] = {
    "Cloudflare": [
        "/cdn-cgi/",
        "challenges.cloudflare.com",
        "challenges.cloudflare.com/turnstile/",
        "cloudflare.com/cdn-cgi/challenge-platform",
    ],
    "DataDome": [
        "datadome.co",
        "dd.datadome",
        "datadome.co/captcha/",
    ],
    "Akamai Bot Manager": [
        "akamaized.net",
        "/akam/",
        "/akamai/",
        "ds-aksb-a.akamaihd.net",
    ],
    "PerimeterX": [
        "px-cdn.net",
        "px-cloud.net",
        "pxchk.net",
        "/px/captcha",
        "captcha.px-cdn",
    ],
    "hCaptcha": [
        "hcaptcha.com",
        "newassets.hcaptcha.com",
    ],
    "reCAPTCHA": [
        "google.com/recaptcha",
        "recaptcha.net",
        "gstatic.com/recaptcha",
    ],
    "Kasada": [
        "/ips.js",
    ],
    "Arkose Labs": [
        "client-api.arkoselabs.com",
        "arkoselabs.com",
    ],
    "Shape Security (F5)": [
        "/shape/",
        "shape.com",
    ],
    "Imperva / Incapsula": [
        "incapsula.com",
        "imperva.com",
        "/_Incapsula_Resource",
    ],
    "GeeTest": [
        "geetest.com",
        "gt.geetest.com",
    ],
    "FingerprintJS": [
        "fingerprintjs.com",
        "fpjs.io",
        "fpcdn.io",
        "/fp.js",
    ],
    "AWS WAF": [
        "awswaf.com",
        "/captcha/awswaf",
    ],
    "Distil Networks (Imperva)": [
        "distilnetworks.com",
        "/distil_identify",
    ],
}

ANTI_BOT_RESPONSE_HEADERS: dict[str, list[str]] = {
    "Cloudflare": ["cf-ray", "cf-cache-status", "cf-mitigated"],
    "Akamai Bot Manager": ["x-akamai-session-info", "akamai-grn"],
    "DataDome": ["x-datadome", "x-datadome-cid"],
    "Imperva / Incapsula": ["x-iinfo", "x-cdn"],
    "AWS WAF": ["x-amzn-waf-action"],
}

ANTI_BOT_COOKIE_PATTERNS: dict[str, list[str]] = {
    "Cloudflare": ["__cf_bm", "cf_clearance", "__cflb", "_cfuvid"],
    "DataDome": ["datadome", "datadome_device_id"],
    "Akamai Bot Manager": ["_abck", "ak_bmsc", "bm_sz", "bm_sv"],
    "PerimeterX": ["_pxhd", "_pxvid", "_px3", "_pxde"],
    "Imperva / Incapsula": [
        "visid_incap_",
        "incap_ses_",
        "nlbi_",
        "reese84",
    ],
    "Kasada": ["_xid", "x-kpsdk"],
    "GeeTest": ["geetest_"],
    "Shape Security (F5)": ["_imp_apg_r_", "_imp_apg_v_"],
}


# ---------------------------------------------------------------------------
# Detector
# ---------------------------------------------------------------------------


class AntiBotDetector:
    """Detects anti-bot protection services from network traffic.

    Maintains a running list of detections, deduplicated by
    (service, evidence_type) to avoid spamming the same finding.
    """

    def __init__(self) -> None:
        self.detections: list[AntiBotDetection] = []
        self._seen: set[tuple[str, str]] = set()

    def check_url(self, url: str, timestamp: float = 0.0) -> AntiBotDetection | None:
        """Check if a request URL matches known anti-bot patterns."""
        url_lower = url.lower()
        for service, patterns in ANTI_BOT_URL_PATTERNS.items():
            for pattern in patterns:
                if pattern.lower() in url_lower:
                    return self._add_detection(
                        service=service,
                        evidence_type="url_pattern",
                        evidence_detail=f"URL contains '{pattern}'",
                        request_url=url,
                        timestamp=timestamp,
                    )
        return None

    def check_response_headers(
        self, headers: dict[str, str], request_url: str, timestamp: float = 0.0
    ) -> list[AntiBotDetection]:
        """Check response headers for anti-bot service indicators."""
        results: list[AntiBotDetection] = []
        headers_lower = {k.lower(): v for k, v in headers.items()}
        for service, header_names in ANTI_BOT_RESPONSE_HEADERS.items():
            for header_name in header_names:
                if header_name.lower() in headers_lower:
                    det = self._add_detection(
                        service=service,
                        evidence_type="response_header",
                        evidence_detail=f"Header '{header_name}' present",
                        request_url=request_url,
                        timestamp=timestamp,
                    )
                    if det:
                        results.append(det)
        return results

    # NOTE: ``check_cookies`` was removed in fix #1.A (cookie cross-
    # contamination). The legacy substring-match-with-no-domain-check
    # produced false positives on every fixture (stale cookies from
    # prior captures attributed to the current scan's primary domain).
    # The per-vendor detectors in ``presence_only.py``, ``cloudflare.py``,
    # and ``datadome.py`` already handle cookies correctly with cookie
    # domain scoping.

    def _add_detection(
        self,
        service: str,
        evidence_type: str,
        evidence_detail: str,
        request_url: str,
        timestamp: float,
    ) -> AntiBotDetection | None:
        """Add a detection if not already seen for this (service, type) pair."""
        key = (service, evidence_type)
        if key in self._seen:
            return None
        self._seen.add(key)
        det = AntiBotDetection(
            service=service,
            evidence_type=evidence_type,
            evidence_detail=evidence_detail,
            request_url=request_url[:200],
            timestamp=timestamp,
        )
        self.detections.append(det)
        return det

    def get_summary(self) -> dict[str, Any]:
        """Generate a summary of all anti-bot detections. Findings only."""
        if not self.detections:
            return {
                "protected": False,
                "services_detected": [],
                "details": [],
            }

        services = list({d.service for d in self.detections})
        details = [asdict(d) for d in self.detections]

        return {
            "protected": True,
            "services_detected": services,
            "details": details,
        }
