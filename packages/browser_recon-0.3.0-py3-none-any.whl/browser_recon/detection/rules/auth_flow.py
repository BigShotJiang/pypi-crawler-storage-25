"""Authentication flow detection from request/response patterns.

Extracted from the existing browser-recon skill at
``~/.claude/skills/browser-recon/scripts/detectors/auth_flow.py`` (task
1.a.06). Straight extraction — no behaviour change beyond swapping the
skill's flat-layout import hack for a proper ``browser_recon.models``
import.

Tier B extensions (session-cookie auth, CSRF tokens, HMAC signatures, API
keys) are intentionally deferred to task 1.b. This module covers only the
five flow_types implemented in the source skill: ``login_endpoint``,
``bearer_token``, ``oauth_redirect``, ``www_authenticate``,
``token_refresh``.
"""

from __future__ import annotations

import re
from dataclasses import asdict
from typing import Any

from browser_recon.models import AuthFlowDetection

LOGIN_PATH_PATTERNS = re.compile(
    r"/(login|signin|sign-in|authenticate|auth/login|oauth|token|auth/token)"
    r"(/|$|\?)",
    re.IGNORECASE,
)

TOKEN_REFRESH_PATTERNS = re.compile(
    r"/(token/refresh|auth/refresh|refresh[-_]?token)(/|$|\?)",
    re.IGNORECASE,
)

#: Pattern that flags genuine OAuth callback URLs.
#:
#: v0.1.0 used ``[?&](code|access_token|id_token|state)=`` which fired on
#: any URL with a bare ``state=<value>`` query param. That triggered a
#: well-known false positive on Target's product/search APIs (which use
#: ``state=GJ`` / ``state=CA`` to scope results to a US/Indian state) --
#: see the fixture audit at the top of ``tests/unit/test_auth_flow.py``
#: for the historical receipt. T7 fixed that by requiring ``code=`` /
#: ``access_token=`` / ``id_token=`` membership.
#:
#: T40.2 tightens the rule further: a bare ``?code=<n>`` query param
#: is itself ambiguous -- ad-network user-sync endpoints
#: (``ib.adnxs.com/setuid?entity=305&code=...``) and tracking pixels
#: routinely use ``code=`` as an opaque identifier with no OAuth
#: semantics. The canonical OAuth 2.0 authorisation-code-grant redirect
#: URI carries BOTH ``code=`` AND ``response_type=`` -- the latter is
#: never present on ad-tech URLs because nothing else uses that name.
#: We treat ``code=`` as conditional on ``response_type=`` co-occurrence;
#: ``access_token=`` / ``id_token=`` remain unconditional strong signals
#: because those names are vanishingly rare in non-OAuth query strings
#: (and when they do occur, they ARE bearing a token of interest).
OAUTH_REDIRECT_TOKEN_PATTERNS = re.compile(
    r"[?&](access_token|id_token)=",
    re.IGNORECASE,
)
OAUTH_REDIRECT_CODE_PATTERN = re.compile(
    r"[?&]code=",
    re.IGNORECASE,
)
OAUTH_REDIRECT_RESPONSE_TYPE_PATTERN = re.compile(
    r"[?&]response_type=",
    re.IGNORECASE,
)
OAUTH_REDIRECT_STATE_PATTERN = re.compile(
    r"[?&]state=",
    re.IGNORECASE,
)
#: Backwards-compat alias. Older callers (and the existing test suite)
#: import ``OAUTH_REDIRECT_PATTERNS`` directly. Post-T40.2 there is no
#: single regex that captures "real OAuth redirect" -- the rule needs
#: two separate matches on the same URL -- so this alias now points at
#: the unconditional token-bearing pattern (``access_token`` /
#: ``id_token``). Callers that need the full rule should call
#: :meth:`AuthFlowDetector.check_request` directly.
OAUTH_REDIRECT_PATTERNS = OAUTH_REDIRECT_TOKEN_PATTERNS


class AuthFlowDetector:
    """Detects authentication flows from network traffic.

    Deduplicates by (flow_type, evidence_url base path).
    """

    def __init__(self) -> None:
        self.detections: list[AuthFlowDetection] = []
        self._seen: set[tuple[str, str]] = set()

    def check_request(
        self,
        url: str,
        method: str,
        headers: dict[str, str],
        timestamp: float = 0.0,
    ) -> AuthFlowDetection | None:
        # POST to login/auth endpoints
        if method.upper() == "POST" and LOGIN_PATH_PATTERNS.search(url):
            return self._add(
                flow_type="login_endpoint",
                evidence_url=url,
                evidence_detail=f"POST {url[:120]}",
                timestamp=timestamp,
            )

        # Bearer token on request
        headers_lower = {k.lower(): v for k, v in headers.items()}
        auth = headers_lower.get("authorization", "")
        if auth.lower().startswith("bearer "):
            return self._add(
                flow_type="bearer_token",
                evidence_url=url,
                evidence_detail="Authorization: Bearer header present",
                timestamp=timestamp,
            )

        # OAuth redirect pattern in URL.
        #
        # T7 (Phase 2 / FOLDS-V01) tightened the rule to require
        # ``code=`` / ``access_token=`` / ``id_token=`` -- bare
        # ``state=`` was producing ~14 false positives per Target
        # capture.
        #
        # T40.2 tightens further: a bare ``?code=<n>`` query param
        # alone still fires on ad-tech URLs (e.g.
        # ``ib.adnxs.com/setuid?entity=305&code=18072661950483823394``,
        # which is AppNexus's user-sync, NOT an OAuth callback). The
        # canonical OAuth 2.0 authorisation-code-grant redirect URI
        # carries BOTH ``code=`` AND ``response_type=`` (RFC 6749
        # §4.1); the response_type parameter has no non-OAuth meaning
        # in the wild. We therefore require ``code=`` + ``response_type=``
        # co-occurrence to count.
        #
        # ``access_token=`` / ``id_token=`` remain unconditional --
        # those names don't appear in non-OAuth query strings in
        # practice, and when they do, they are bearing a token of
        # interest worth surfacing.
        is_token_redirect = bool(OAUTH_REDIRECT_TOKEN_PATTERNS.search(url))
        is_code_grant_redirect = bool(
            OAUTH_REDIRECT_CODE_PATTERN.search(url)
            and OAUTH_REDIRECT_RESPONSE_TYPE_PATTERN.search(url)
        )
        if is_token_redirect or is_code_grant_redirect:
            return self._add(
                flow_type="oauth_redirect",
                evidence_url=url,
                evidence_detail="OAuth redirect params in URL",
                timestamp=timestamp,
            )

        return None

    def check_response(
        self,
        url: str,
        status_code: int,
        headers: dict[str, str],
        timestamp: float = 0.0,
    ) -> AuthFlowDetection | None:
        headers_lower = {k.lower(): v for k, v in headers.items()}

        # 401/403 with WWW-Authenticate
        if status_code in (401, 403) and "www-authenticate" in headers_lower:
            www_auth = headers_lower["www-authenticate"]
            scheme = www_auth.split()[0] if www_auth else "unknown"
            return self._add(
                flow_type="www_authenticate",
                evidence_url=url,
                evidence_detail=f"{status_code} with WWW-Authenticate: {scheme}",
                timestamp=timestamp,
            )

        # Token refresh patterns
        if TOKEN_REFRESH_PATTERNS.search(url):
            return self._add(
                flow_type="token_refresh",
                evidence_url=url,
                evidence_detail=f"Token refresh endpoint: {url[:120]}",
                timestamp=timestamp,
            )

        return None

    def _add(
        self,
        flow_type: str,
        evidence_url: str,
        evidence_detail: str,
        timestamp: float,
    ) -> AuthFlowDetection | None:
        key = (flow_type, evidence_url[:100])
        if key in self._seen:
            return None
        self._seen.add(key)
        det = AuthFlowDetection(
            flow_type=flow_type,
            evidence_url=evidence_url[:200],
            evidence_detail=evidence_detail,
            timestamp=timestamp,
        )
        self.detections.append(det)
        return det

    def get_summary(self) -> dict[str, Any]:
        if not self.detections:
            return {"auth_detected": False, "flows": []}
        flow_types = list({d.flow_type for d in self.detections})
        return {
            "auth_detected": True,
            "flow_types": flow_types,
            "flows": [asdict(d) for d in self.detections],
        }
