"""Rate limit signal detection from response status codes and headers.

Extracted from the existing browser-recon skill at
``~/.claude/skills/browser-recon/scripts/detectors/rate_limit.py`` (task
1.a.08). Straight extraction — no behaviour change beyond swapping the
skill's flat-layout import hack for proper ``browser_recon.models`` /
``browser_recon.utils`` imports.

Two header variants are recognised:

* ``X-RateLimit-*`` — the legacy / de-facto convention.
* ``RateLimit-*`` — the IETF draft convention (no ``X-`` prefix).

A signal fires when the response status code is ``429`` OR a
``*RateLimit-Limit`` header is present. Detections dedupe by
``base_url`` (query stripped). ``Retry-After`` is captured opportunistically
when present; no parsing or weighting is applied to it here. New header
variants are intentionally NOT added in this extraction.
"""

from __future__ import annotations

from dataclasses import asdict
from typing import Any

from browser_recon.models import RateLimitInfo
from browser_recon.utils import base_url


class RateLimitDetector:
    """Detects rate limiting signals from HTTP responses.

    Deduplicates by base URL (query params stripped).
    """

    def __init__(self) -> None:
        self.detections: list[RateLimitInfo] = []
        self._seen: set[str] = set()

    def check_response(
        self, url: str, status_code: int, headers: dict[str, str]
    ) -> RateLimitInfo | None:
        headers_lower = {k.lower(): v for k, v in headers.items()}

        retry_after = headers_lower.get("retry-after")
        limit, remaining, reset, variant = self._extract_rate_headers(headers_lower)

        has_signal = status_code == 429 or limit is not None
        if not has_signal:
            return None

        key = base_url(url)
        if key in self._seen:
            return None
        self._seen.add(key)

        info = RateLimitInfo(
            request_url=url[:200],
            status_code=status_code,
            retry_after=retry_after,
            limit=limit,
            remaining=remaining,
            reset=reset,
            header_variant=variant,
        )
        self.detections.append(info)
        return info

    def _extract_rate_headers(
        self, headers_lower: dict[str, str]
    ) -> tuple[str | None, str | None, str | None, str]:
        # Standard X-RateLimit-* headers
        if "x-ratelimit-limit" in headers_lower:
            return (
                headers_lower.get("x-ratelimit-limit"),
                headers_lower.get("x-ratelimit-remaining"),
                headers_lower.get("x-ratelimit-reset"),
                "x-ratelimit",
            )
        # IETF draft RateLimit-* headers
        if "ratelimit-limit" in headers_lower:
            return (
                headers_lower.get("ratelimit-limit"),
                headers_lower.get("ratelimit-remaining"),
                headers_lower.get("ratelimit-reset"),
                "ratelimit",
            )
        return None, None, None, ""

    def get_summary(self) -> dict[str, Any]:
        if not self.detections:
            return {"rate_limited": False, "details": []}
        return {
            "rate_limited": True,
            "endpoints_affected": len(self.detections),
            "has_429": any(d.status_code == 429 for d in self.detections),
            "details": [asdict(d) for d in self.detections],
        }
