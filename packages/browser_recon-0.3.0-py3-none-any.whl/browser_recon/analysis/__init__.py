"""Analysis subpackage (capture-time only).

T53.6 trimmed this package to the small set of helpers
:mod:`browser_recon.capture.cdp_monitor` needs while Chrome is live:

* :mod:`browser_recon.analysis.headers` -- header/CDN classifiers
  exposed via :func:`is_cdn_url`.
* :mod:`browser_recon.analysis.interactions` -- DOM-observer +
  interaction-log injection / parse helpers.
* :mod:`browser_recon.analysis.redirects` -- redirect-chain
  extractor for the CDP response listener.

The full endpoint-inventory orchestrator + architecture / framework /
dependency classifiers moved to ``browser_recon_server.analysis_server``
in T53.2.
"""
