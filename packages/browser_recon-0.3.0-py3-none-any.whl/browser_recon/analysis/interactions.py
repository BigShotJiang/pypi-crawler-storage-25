"""User interaction capture via injected JavaScript.

Injects event listeners for click, input, scroll, and form submit events.
Captures are sent back via console.log and picked up by Runtime.consoleAPICalled.

SECURITY: Password fields and other sensitive inputs are always masked.

Extracted from the existing browser-recon skill at
``~/.claude/skills/browser-recon/scripts/analyzers/interactions.py`` (task
1.a.14). Verbatim port modulo the ``sys.path`` import-hack swap for proper
``browser_recon.models`` imports and strict typing tightening.

Audit
-----
* Sensitive-field masking is performed CLIENT-SIDE inside the injected JS
  (``isSensitive(el)`` + the ``[MASKED]`` string substitution); the
  Python-side ``parse_interaction_log`` just trusts whatever ``input_value``
  arrives and copies it through. This is intentional: the server side never
  sees the raw value, so there is nothing to re-mask.
* The JS is embedded as a single raw triple-quoted string with one
  interpolation point — ``json.dumps(list(_SENSITIVE_NAME_PATTERNS))`` —
  spliced in before the literal patterns line. Splice shape preserved.
* ``timestamp`` is divided by 1000 in the parser because the JS sends
  ``Date.now()`` in milliseconds and the rest of the pipeline keeps
  timestamps in Python-style seconds.
* ``parse_dom_change_signal`` returns the raw decoded payload as a dict;
  it does not coerce keys or types. Caller is responsible for shape checks.
* No bugs spotted.
"""

from __future__ import annotations

import json
from typing import Any

from browser_recon.models import CapturedInteraction

# Fields that should NEVER have their values captured
_SENSITIVE_FIELD_TYPES = {"password"}
_SENSITIVE_NAME_PATTERNS = {
    "password",
    "passwd",
    "pass",
    "pwd",
    "secret",
    "pin",
    "cvv",
    "cvc",
    "csv",
    "ssn",
    "social_security",
    "credit_card",
    "card_number",
    "cardnumber",
    "cc_number",
    "security_code",
    "security_answer",
    "bank_account",
    "routing_number",
}


INTERACTION_PREFIX = "__RECON_INTERACTION__"
DOM_CHANGE_PREFIX = "__RECON_DOM_CHANGE__"


def build_injection_script() -> str:
    """Return the JavaScript to inject into each page.

    The script listens for click, input, scroll, and submit events,
    then logs structured JSON via console.log with a __RECON_INTERACTION__
    prefix so the CDP handler can identify and parse them.
    """
    # The sensitive patterns are embedded directly in the JS for client-side masking
    sensitive_patterns_js = json.dumps(list(_SENSITIVE_NAME_PATTERNS))

    return (
        r"""
(function() {
    if (window.__reconInteractionInjected) return;
    window.__reconInteractionInjected = true;

    const SENSITIVE_PATTERNS = """
        + sensitive_patterns_js
        + r""";
    const PREFIX = '__RECON_INTERACTION__';

    function isSensitive(el) {
        if (!el) return false;
        const type = (el.type || '').toLowerCase();
        if (type === 'password') return true;
        const name = ((el.name || '') + (el.id || '') + (el.placeholder || '')).toLowerCase();
        return SENSITIVE_PATTERNS.some(p => name.includes(p));
    }

    function getSelector(el) {
        if (!el || !el.tagName) return '';
        let sel = el.tagName.toLowerCase();
        if (el.id) sel += '#' + el.id;
        else if (el.className && typeof el.className === 'string') {
            const cls = el.className.trim().split(/\s+/).slice(0, 2).join('.');
            if (cls) sel += '.' + cls;
        }
        // Add type for inputs
        if (el.type && el.tagName.toLowerCase() === 'input') {
            sel += '[type=' + el.type + ']';
        }
        return sel;
    }

    function getText(el) {
        if (!el) return '';
        // For buttons/links, get visible text
        const text = (el.textContent || el.innerText || el.value || el.alt || el.title || '').trim();
        return text.substring(0, 100);
    }

    function emit(data) {
        try {
            var payload = JSON.stringify(data);
            if (typeof window.__reconInteraction === 'function') {
                window.__reconInteraction(payload);
            } else {
                console.log(PREFIX + payload);
            }
        } catch(e) {
            try { console.log(PREFIX + JSON.stringify(data)); } catch(e2) {}
        }
    }

    // --- Click events ---
    function captureAncestorAriaLabels(el) {
        // T42.2 — walk up to 3 ancestors (parent/grand/great-grand)
        // collecting aria-labels. SVG icon buttons and consent-dialog
        // dismiss elements often have empty own-element attributes but
        // an aria-label on the enclosing <button> / overlay <div>.
        var labels = [];
        try {
            var current = el && el.parentElement;
            var depth = 0;
            while (current && depth < 3) {
                var label = (current.getAttribute && current.getAttribute('aria-label')) || '';
                if (label && label.trim()) {
                    labels.push(label.trim().substring(0, 200));
                } else {
                    labels.push('');
                }
                current = current.parentElement;
                depth++;
            }
        } catch(_e) {}
        return labels;
    }

    document.addEventListener('click', function(e) {
        const el = e.target;
        if (!el || !el.tagName) return;
        // T40.1 — capture aria-label + role separately so the Python
        // side can pick the most human-readable label without re-doing
        // DOM lookups. Cap each at 200 chars to keep the payload small.
        var ariaLabel = '';
        var role = '';
        try {
            ariaLabel = (el.getAttribute && el.getAttribute('aria-label')) || '';
            role = (el.getAttribute && el.getAttribute('role')) || '';
        } catch(_e) {}
        const data = {
            action: 'click',
            timestamp: Date.now(),
            page_url: location.href,
            selector: getSelector(el),
            tag: el.tagName.toLowerCase(),
            text: getText(el),
            aria_label: (ariaLabel || '').substring(0, 200),
            role: (role || '').substring(0, 200),
            // T42.2 — list of up to 3 ancestor aria-labels (nearest first).
            // Empty-string entries are preserved so the Python side can
            // find the first NON-empty one without losing depth context.
            ancestor_aria_labels: captureAncestorAriaLabels(el),
            href: el.href || el.closest('a')?.href || ''
        };
        emit(data);
    }, true);

    // --- Input events (debounced) ---
    let inputTimers = new Map();
    document.addEventListener('input', function(e) {
        const el = e.target;
        if (!el || !el.tagName) return;
        // Debounce: only emit after 500ms of no typing
        const key = getSelector(el);
        if (inputTimers.has(key)) clearTimeout(inputTimers.get(key));
        inputTimers.set(key, setTimeout(function() {
            inputTimers.delete(key);
            const sensitive = isSensitive(el);
            const data = {
                action: 'input',
                timestamp: Date.now(),
                page_url: location.href,
                selector: getSelector(el),
                tag: el.tagName.toLowerCase(),
                input_name: el.name || el.id || '',
                input_type: el.type || '',
                input_value: sensitive ? '[MASKED]' : (el.value || '').substring(0, 200)
            };
            emit(data);
        }, 500));
    }, true);

    // --- Form submit events ---
    document.addEventListener('submit', function(e) {
        const form = e.target;
        if (!form || form.tagName?.toLowerCase() !== 'form') return;
        const fields = [];
        const inputs = form.querySelectorAll('input, select, textarea');
        inputs.forEach(function(el) {
            const sensitive = isSensitive(el);
            fields.push({
                name: el.name || el.id || '',
                type: el.type || el.tagName.toLowerCase(),
                value: sensitive ? '[MASKED]' : (el.value || '').substring(0, 100)
            });
        });
        const data = {
            action: 'submit',
            timestamp: Date.now(),
            page_url: location.href,
            selector: getSelector(form),
            tag: 'form',
            text: form.action || '',
            input_value: JSON.stringify(fields).substring(0, 500)
        };
        emit(data);
    }, true);

    // --- Scroll events (throttled) ---
    let lastScrollEmit = 0;
    window.addEventListener('scroll', function() {
        const now = Date.now();
        if (now - lastScrollEmit < 2000) return;  // Max once per 2s
        lastScrollEmit = now;
        const data = {
            action: 'scroll',
            timestamp: now,
            page_url: location.href,
            scroll_y: Math.round(window.scrollY),
            scroll_max_y: Math.round(document.documentElement.scrollHeight - window.innerHeight)
        };
        emit(data);
    }, {passive: true});
})();
""".strip()
    )


def parse_interaction_log(log_text: str) -> CapturedInteraction | None:
    """Parse a console.log message into a CapturedInteraction.

    Returns None if the message isn't an interaction log.
    """
    if not log_text.startswith(INTERACTION_PREFIX):
        return None

    try:
        data = json.loads(log_text[len(INTERACTION_PREFIX) :])
    except (json.JSONDecodeError, TypeError):
        return None

    # T42.2 — ancestor_aria_labels is optional; legacy payloads (older
    # captures from before this field was added) decode with an empty
    # list. Each entry is also defensively capped at 200 chars in case
    # the JS-side cap was bypassed by a manipulated capture.
    raw_ancestors = data.get("ancestor_aria_labels") or []
    if not isinstance(raw_ancestors, list):
        raw_ancestors = []
    ancestor_aria_labels: list[str] = [
        (str(item)[:200] if item is not None else "") for item in raw_ancestors[:3]
    ]

    return CapturedInteraction(
        action=data.get("action", ""),
        timestamp=data.get("timestamp", 0) / 1000.0,  # JS ms → Python seconds
        page_url=data.get("page_url", ""),
        selector=data.get("selector", ""),
        tag=data.get("tag", ""),
        text=data.get("text", "")[:100],
        input_name=data.get("input_name", ""),
        input_type=data.get("input_type", ""),
        input_value=data.get("input_value", ""),
        href=data.get("href", ""),
        scroll_y=data.get("scroll_y", 0),
        scroll_max_y=data.get("scroll_max_y", 0),
        # T40.1 — new fields fall back to empty string for legacy payloads.
        aria_label=(data.get("aria_label") or "")[:200],
        role=(data.get("role") or "")[:200],
        # T42.2 — ancestor aria-label fallback chain.
        ancestor_aria_labels=ancestor_aria_labels,
    )


def build_dom_observer_script() -> str:
    """Return JavaScript that detects SPA route changes and significant DOM mutations.

    Hooks History API (pushState/replaceState), listens for popstate/hashchange,
    and uses MutationObserver to detect in-place DOM changes. Signals are sent
    via Runtime.addBinding (__reconDomChange) with console.log fallback.
    """
    return r"""
(function() {
    if (window.__reconDomObserverInjected) return;
    window.__reconDomObserverInjected = true;

    var DOM_PREFIX = '__RECON_DOM_CHANGE__';
    var lastEmittedUrl = '';
    var lastEmitTime = 0;
    var DEDUP_INTERVAL = 5000;

    function emitChange(trigger) {
        var now = Date.now();
        var url = location.href;
        if (url === lastEmittedUrl && (now - lastEmitTime) < DEDUP_INTERVAL) return;
        lastEmittedUrl = url;
        lastEmitTime = now;
        var payload = JSON.stringify({
            trigger: trigger,
            url: url,
            title: document.title || '',
            timestamp: now
        });
        try {
            if (typeof window.__reconDomChange === 'function') {
                window.__reconDomChange(payload);
            } else {
                console.log(DOM_PREFIX + payload);
            }
        } catch(e) {}
    }

    // --- Hook history.pushState ---
    var origPushState = history.pushState;
    history.pushState = function() {
        origPushState.apply(this, arguments);
        setTimeout(function() { emitChange('pushState'); }, 1500);
    };

    // --- Hook history.replaceState ---
    var origReplaceState = history.replaceState;
    history.replaceState = function() {
        origReplaceState.apply(this, arguments);
        setTimeout(function() { emitChange('replaceState'); }, 1500);
    };

    // --- popstate ---
    window.addEventListener('popstate', function() {
        setTimeout(function() { emitChange('popstate'); }, 1500);
    });

    // --- hashchange ---
    window.addEventListener('hashchange', function() {
        setTimeout(function() { emitChange('hashchange'); }, 1500);
    });

    // --- MutationObserver for in-place DOM changes ---
    var mutationTimer = null;
    var mutationCount = 0;
    var MUTATION_DELAY = 3000;
    var MUTATION_THRESHOLD = 5;

    if (typeof MutationObserver !== 'undefined') {
        var observer = new MutationObserver(function(mutations) {
            var added = 0;
            for (var i = 0; i < mutations.length; i++) {
                added += mutations[i].addedNodes.length;
            }
            mutationCount += added;
            if (mutationTimer) clearTimeout(mutationTimer);
            mutationTimer = setTimeout(function() {
                if (mutationCount >= MUTATION_THRESHOLD) {
                    emitChange('mutation');
                }
                mutationCount = 0;
                mutationTimer = null;
            }, MUTATION_DELAY);
        });

        // Start observing once body is available
        function startObserving() {
            if (document.body) {
                observer.observe(document.body, { childList: true, subtree: true });
            } else {
                setTimeout(startObserving, 200);
            }
        }
        startObserving();
    }
})();
""".strip()


def parse_dom_change_signal(text: str) -> dict[str, Any] | None:
    """Parse a __RECON_DOM_CHANGE__ prefixed message into a dict.

    Returns dict with {trigger, url, title, timestamp} or None if not a valid signal.
    """
    if not text.startswith(DOM_CHANGE_PREFIX):
        return None
    try:
        decoded = json.loads(text[len(DOM_CHANGE_PREFIX) :])
    except (json.JSONDecodeError, TypeError):
        return None
    if not isinstance(decoded, dict):
        return None
    return decoded
