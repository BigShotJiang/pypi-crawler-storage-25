"""Redirect-event extraction from CDP ``Network.requestWillBeSent`` events.

Extracted from the existing browser-recon skill at
``~/.claude/skills/browser-recon/scripts/analyzers/redirects.py`` (task
1.a.12). Verbatim port of ``extract_redirect_info`` modulo strict typing.

This module is a single CDP-event-shape extractor used by the capture
layer when ``Network.requestWillBeSent`` fires with a ``redirectResponse``
member. The output is a plain dict (not a dataclass) because the four
fields are dropped straight onto a ``CapturedRequest.redirect_chain``
list at capture time. Tracking the chain itself (joining successive
extractions to a single ``request_id``) is the caller's job.

Audit
-----
* Module name suggests it tracks redirect chains, but it only extracts
  one redirect record from one CDP event. The "chain" terminology lives
  in the caller. Naming is mildly misleading but not buggy; preserved
  as-is for behavioural parity with the source skill.
* No other issues spotted: ``params.get("redirectResponse")`` correctly
  short-circuits when the key is absent or explicitly ``None``;
  ``.get(..., default)`` calls handle missing fields cleanly.
"""

from __future__ import annotations

from typing import Any


def extract_redirect_info(params: dict[str, Any]) -> dict[str, Any] | None:
    """Return redirect details if the event represents a redirect, else None.

    CDP includes a ``redirectResponse`` key in ``Network.requestWillBeSent``
    when the request is the result of a redirect from a previous request.
    """
    redirect_response = params.get("redirectResponse")
    if redirect_response is None:
        return None

    request = params.get("request", {})
    return {
        "from_url": redirect_response.get("url", ""),
        "status_code": redirect_response.get("status", 0),
        "to_url": request.get("url", ""),
        "response_headers": redirect_response.get("headers", {}),
    }
