"""Data models for browser-recon.

This is the foundation module: every other ``browser_recon`` module imports
its dataclasses from here, and this module imports nothing from the rest of
the package. Stdlib only.

The first half of the file (``Core capture models`` through ``User
interactions``) is copied verbatim from the existing skill at
``~/.claude/skills/browser-recon/scripts/models.py`` — these dataclasses
describe the raw capture artefacts.

The second half (``Evidence and findings`` onward) defines the Phase 1
detection / analysis / validation / synthesis / rendering payloads, derived
from the specs under ``documentation/phase-1-*-spec.md``.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

# ---------------------------------------------------------------------------
# Core capture models
# ---------------------------------------------------------------------------


@dataclass
class CapturedRequest:
    """A single captured network request with response metadata."""

    request_id: str
    url: str
    method: str
    resource_type: str
    request_headers: dict[str, str] = field(default_factory=dict)
    post_data: str | None = None
    timestamp: float = 0.0
    initiator_type: str = ""
    initiator_url: str = ""
    status_code: int | None = None
    response_headers: dict[str, str] = field(default_factory=dict)
    mime_type: str = ""
    response_size: int = 0
    remote_ip: str = ""
    response_body: str | None = None
    redirect_chain: list[dict[str, Any]] = field(default_factory=list)
    saved_response_file: str = ""  # Filename set by export() after saving to disk


@dataclass
class CapturedWebSocket:
    """A detected WebSocket connection."""

    url: str
    request_id: str
    frames_sent: list[str] = field(default_factory=list)
    frames_received: list[str] = field(default_factory=list)


@dataclass
class CapturedCookie:
    """A captured browser cookie.

    ``value_preview`` is the 50-char truncated value safe for upload --
    anti-bot tokens (Akamai ``_abck``, ``bm_sz``) are stored verbatim
    on disk by ``capture/cdp_monitor.py`` but get reduced to a preview
    when the blob is serialised, then completely cleared by the PII
    scrubber before the network boundary.

    ``_full_value`` (T34.1) holds the untruncated cookie value for use
    by the LOCAL validation + replay pipelines, which need the real
    cookie to authenticate against the target site. This field is
    populated only in-memory on the user's machine and is stripped at
    scrub time -- it MUST NEVER leave the local box.
    """

    name: str
    value_preview: str
    domain: str
    path: str
    secure: bool = False
    http_only: bool = False
    same_site: str = ""
    #: T34.1: full (untruncated) cookie value, used by validation /
    #: replay pipelines locally. Stripped by the PII scrubber before
    #: upload. Empty for legacy fixtures + post-scrub blobs.
    _full_value: str = ""


@dataclass
class DOMSnapshot:
    """A captured DOM snapshot for a page."""

    url: str
    title: str
    timestamp: float
    outer_html: str
    frame_id: str = ""
    has_json_ld: bool = False
    has_microdata: bool = False
    has_og_tags: bool = False
    meta_tags: list[dict[str, str]] = field(default_factory=list)
    data_attributes_count: int = 0
    iframe_count: int = 0
    form_count: int = 0
    total_element_count: int = 0


# ---------------------------------------------------------------------------
# Anti-bot detection
# ---------------------------------------------------------------------------


@dataclass
class AntiBotDetection:
    """A single anti-bot protection detection."""

    service: str
    evidence_type: str  # "url_pattern", "response_header", "cookie"
    evidence_detail: str
    request_url: str
    timestamp: float = 0.0


# ---------------------------------------------------------------------------
# Rate limiting
# ---------------------------------------------------------------------------


@dataclass
class RateLimitInfo:
    """Rate limit information extracted from a response."""

    request_url: str
    status_code: int
    retry_after: str | None = None
    limit: str | None = None
    remaining: str | None = None
    reset: str | None = None
    header_variant: str = ""  # "x-ratelimit", "ratelimit" (IETF), "custom"


# ---------------------------------------------------------------------------
# Pagination
# ---------------------------------------------------------------------------


@dataclass
class PaginationPattern:
    """Detected pagination pattern for an endpoint group."""

    base_url: str
    pattern_type: str  # "query_param", "link_header", "cursor"
    param_name: str = ""
    observed_values: list[str] = field(default_factory=list)
    has_link_header: bool = False


# ---------------------------------------------------------------------------
# Authentication flow
# ---------------------------------------------------------------------------


@dataclass
class AuthFlowDetection:
    """Detected authentication flow pattern."""

    flow_type: (
        str  # "login_endpoint", "bearer_token", "token_refresh", "oauth_redirect"
    )
    evidence_url: str
    evidence_detail: str
    related_endpoints: list[str] = field(default_factory=list)
    timestamp: float = 0.0


# ---------------------------------------------------------------------------
# CORS
# ---------------------------------------------------------------------------


@dataclass
class CORSInfo:
    """CORS configuration for an endpoint."""

    request_url: str
    allow_origin: str = ""
    allow_methods: str = ""
    allow_headers: str = ""
    allow_credentials: bool = False
    externally_callable: bool = False


# ---------------------------------------------------------------------------
# Caching
# ---------------------------------------------------------------------------


@dataclass
class CachingInfo:
    """Caching headers for an endpoint."""

    request_url: str
    cache_control: str = ""
    etag: str = ""
    last_modified: str = ""
    vary: str = ""


# ---------------------------------------------------------------------------
# Replay headers
# ---------------------------------------------------------------------------


@dataclass
class ReplayHeaders:
    """Headers needed to replay a request to an endpoint."""

    request_url: str
    authorization: str = ""
    csrf_tokens: dict[str, str] = field(default_factory=dict)
    custom_x_headers: dict[str, str] = field(default_factory=dict)
    required_cookies: list[str] = field(default_factory=list)
    referer: str = ""
    origin: str = ""
    x_requested_with: str = ""


# ---------------------------------------------------------------------------
# GraphQL
# ---------------------------------------------------------------------------


@dataclass
class GraphQLEndpoint:
    """Detected GraphQL endpoint."""

    url: str
    detected_via: str  # "url_pattern", "request_body"
    sample_query: str = ""
    introspection_possible: bool = True  # flag for user to try


# ---------------------------------------------------------------------------
# User interactions
# ---------------------------------------------------------------------------


@dataclass
class CapturedInteraction:
    """A single captured user interaction (click, input, scroll)."""

    action: str  # "click", "input", "scroll", "submit"
    timestamp: float
    page_url: str
    selector: str = ""  # CSS-like selector of the element
    tag: str = ""  # tag name (button, input, a, etc.)
    text: str = ""  # visible text or label (truncated)
    input_name: str = ""  # form field name/id (for inputs)
    input_type: str = ""  # input type attribute
    input_value: str = ""  # value entered (MASKED for sensitive fields)
    href: str = ""  # link target (for <a> clicks)
    scroll_y: int = 0  # scroll position (for scroll events)
    scroll_max_y: int = 0  # max scroll height
    # T40.1 — fields used by flow_segmentation._click_label to derive a
    # human-readable label for the scraping plan. Priority chain:
    # aria_label → text → role → href → ancestor_aria_label → selector.
    # All optional; older capture blobs without these fields fall back
    # to the legacy selector form.
    aria_label: str = ""  # element's aria-label attribute
    role: str = ""  # element's role attribute (e.g. "button", "link")
    # T42.2 — up to 3 ancestor aria-labels (parent, grandparent,
    # great-grandparent), captured in order from nearest to furthest.
    # Used as a 5th-rule fallback in ``_click_label`` for SVG icon
    # buttons and consent-dialog dismiss elements whose own attributes
    # are empty but whose enclosing button / overlay carries the label.
    ancestor_aria_labels: list[str] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Evidence and findings  (Phase 1 detection — new)
# ---------------------------------------------------------------------------


@dataclass
class Evidence:
    """A single piece of evidence supporting a detection finding.

    Shape from ``phase-1-detection-spec.md`` § ``Common Module —
    evidence_collector``. Every Finding cites at least one Evidence; a claim
    without evidence is a bug.
    """

    signal: str  # "header" | "cookie" | "url_pattern" | "js_file" | ...
    value: str  # the actual matched string
    endpoint: str  # endpoint where observed, or "*" for global
    confidence_weight: float  # 0.0-1.0; sums into the Finding's confidence
    timestamp: float | None = None  # when in the capture this signal appeared


@dataclass
class Finding:
    """A single structured detection finding.

    Shape derived from ``phase-1-detection-spec.md`` § Outputs and the
    per-vendor / per-module example output contracts (Cloudflare line ~150,
    DataDome ~267, auth ~570, pagination ~653, rate-limit ~725, GraphQL ~791).

    ``per_endpoint`` is intentionally typed ``dict[str, Any]`` because its
    value shape varies by ``kind``: anti-bot and auth findings use ``int``
    severity tiers, while pagination, rate-limit, and graphql findings nest
    a per-endpoint detail dict.
    """

    kind: str  # "anti_bot" | "auth" | "pagination" | ...
    confidence: float  # 0.0-1.0
    evidence: list[Evidence]  # never empty
    vendor: str | None = None  # "Cloudflare" / "DataDome" / None
    severity_label: str = ""  # human-readable label
    severity_tier: int | None = None  # 0-6 for tiered vendors, else None
    per_endpoint: dict[str, Any] = field(default_factory=dict)
    notes: str | None = None  # free-text caveat; spec uses str|None


@dataclass
class DetectionResult:
    """Top-level output of the detection layer.

    The spec's ``DetectionResult`` is essentially a list of findings; we keep
    a small amount of metadata alongside so consumers can tell which
    detector version produced the result without having to look it up.
    """

    findings: list[Finding] = field(default_factory=list)
    detector_version: str = ""
    capture_metadata: dict[str, Any] = field(default_factory=dict)


# ---------------------------------------------------------------------------
# Analysis  (Phase 1 — new)
# ---------------------------------------------------------------------------


@dataclass
class FrameworkHint:
    """A single framework / generator hint inferred from response bodies.

    Supporting type for ``AnalysisResult.framework_hints``. The analysis spec
    shows hints as plain strings in the example, but a structured form keeps
    the version and the matched signal separable for the renderer.
    """

    name: str  # "next.js", "react", "angular", ...
    version: str = ""  # "13.4.1" if observable, else ""
    evidence: list[Evidence] = field(default_factory=list)


@dataclass
class EndpointEntry:
    """A single deduplicated, normalised API endpoint in the inventory.

    Shape from ``phase-1-analysis-spec.md`` § Endpoint inventory (~line 28).
    """

    url_template: str  # "/api/products?category=<value>"
    method: str
    response_type: str = ""  # "json" | "html" | "text" | ...
    response_shape: str = ""  # "object" | "array<T>" | "paginated<T>"
    sample_count: int = 0
    required_headers: list[str] = field(default_factory=list)
    required_cookies: list[str] = field(default_factory=list)
    required_csrf_tokens: dict[str, str] = field(default_factory=dict)
    #: T34.6: actual captured values for the ``required_headers`` names,
    #: post-scrub. Renderer uses this to surface real values for
    #: non-sensitive headers (User-Agent, Accept, Referer, sec-* hints)
    #: in the curl + httpx snippets while still emitting a templated
    #: placeholder for sensitive headers (Cookie, Authorization,
    #: ``*-Token``, ``*-Key``, custom auth/identity headers). Empty for
    #: legacy fixtures or rows where the value couldn't be sampled.
    required_header_values: dict[str, str] = field(default_factory=dict)
    authentication: str = ""  # "none" | "session_cookie" | "bearer" | ...
    pagination: dict[str, Any] = field(default_factory=dict)
    anti_bot_tier: int | None = None
    rate_limit_signals: dict[str, Any] = field(default_factory=dict)
    cors_externally_callable: bool = False
    evidence: list[Evidence] = field(default_factory=list)
    # Phase 2 / spec § 5.6: per-MIME response summary (≤500 chars).
    # Populated by the analysis orchestrator from the captured response
    # body; consumed by the filter and synthesis prompts so the LLM can
    # reason about response shape without seeing raw bodies.
    response_summary: str = ""
    # T19 / spec § 5.5 (extension to T7): bucket-classifier signals
    # the filter prompt uses to discriminate Bucket B prerequisites
    # from Bucket C trackers. Shape: ``{ms_to_next_data_call,
    # response_bytes, is_pixel_or_empty, sets_cookies,
    # consumed_by_count, consumed_cookies}``. Populated by
    # :func:`browser_recon.analysis.bucket_signals.compute_all_signals`;
    # see that module for per-field semantics. Empty dict by default
    # (degrades gracefully when the orchestrator skips signal
    # computation, e.g. on legacy fixtures or in unit tests).
    bucket_signals: dict[str, Any] = field(default_factory=dict)


@dataclass
class DependencyEdge:
    """A rule-generated candidate dependency between two endpoints.

    Generated by the analysis layer's value-tracking pass. The synthesis
    layer's dependency-curator prompt promotes the real ones into curated
    ``DependencyStep`` entries.
    """

    from_endpoint: str
    from_field: str  # e.g., "results[].id"
    to_endpoint: str
    to_param: str  # e.g., "id (path)"
    confidence: float = 0.0


@dataclass
class CORSEntry:
    """Per-endpoint CORS summary surfaced in the analysis result."""

    endpoint: str
    allow_origin: str = ""
    allow_methods: str = ""
    allow_headers: str = ""
    allow_credentials: bool = False
    externally_callable: bool = False


@dataclass
class Action:
    """A single click→XHR action in the user's demo flow.

    Output of :func:`browser_recon.analysis.flow_segmentation.segment_flow`
    (Phase 2, spec § 5.3). Each action represents a captured click that
    produced ≥1 XHR/Fetch request inside the click→next-click correlation
    window.

    Fields:

    * ``label`` — human-readable boundary label (e.g.
      ``"Click on Electronics"``). Synthesised from the click's text /
      tag / href.
    * ``click_target`` — minimal echo of the originating click event:
      ``{tag, text, selector_hint, href}``. Pure dict so JSON
      round-tripping for storage / LLM prompts stays trivial.
    * ``requests`` — URLs of the XHR / Fetch requests bundled into this
      action, in capture order.
    * ``started_at`` — epoch seconds of the click event.
    * ``ended_at`` — epoch seconds of the last bundled request (so
      ``ended_at >= started_at`` always; equal to ``started_at`` is
      possible only when a request fires within a sub-millisecond of
      the click, which we accept as a degenerate but valid boundary).
    """

    label: str
    click_target: dict[str, Any]
    requests: list[str]
    started_at: float
    ended_at: float


@dataclass
class FlowSegmentation:
    """Click→XHR segmentation of the captured demo flow.

    Output of :func:`browser_recon.analysis.flow_segmentation.segment_flow`.
    ``actions`` is ordered by ``started_at``; ``background_requests``
    holds URLs of XHRs/Fetches that did not fall inside any click's
    correlation window (analytics polls, lazy-loads, prefetches).
    """

    actions: list[Action] = field(default_factory=list)
    background_requests: list[str] = field(default_factory=list)


@dataclass
class AnalysisResult:
    """Top-level output of the analysis layer.

    Shape from ``phase-1-analysis-spec.md`` § Outputs (~line 21).

    ``flow_segmentation`` (T5, spec § 5.3) carries the click→XHR
    correlation as a structured :class:`FlowSegmentation` (actions list +
    background-requests bucket). The legacy ``flow_timeline`` field is
    retained for now — downstream renderer / synthesis-input consumers
    still read it; removal is a separate task.
    """

    architecture: str = ""  # "page_based" | "spa" | "api_driven" | "hybrid"
    framework_hints: list[FrameworkHint] = field(default_factory=list)
    endpoints: list[EndpointEntry] = field(default_factory=list)
    dependency_chain: list[DependencyEdge] = field(default_factory=list)
    flow_timeline: list[dict[str, Any]] = field(default_factory=list)
    cors_summary: list[CORSEntry] = field(default_factory=list)
    notes: list[str] = field(default_factory=list)
    flow_segmentation: FlowSegmentation = field(default_factory=FlowSegmentation)


# ---------------------------------------------------------------------------
# Validation  (Phase 1 — new)
# ---------------------------------------------------------------------------


@dataclass
class EndpointValidation:
    """Active-validation result for a single endpoint.

    Shape from ``phase-1-validation-spec.md`` § Outputs (~line 28). The
    ``library_comparison`` and ``rate_limit`` fields are dict-typed because
    the spec's example uses heterogeneous nested dicts whose exact keys vary
    by library / outcome.
    """

    endpoint: str
    method: str
    library_comparison: dict[str, dict[str, Any]] = field(default_factory=dict)
    best_library: str = ""  # "httpx" | "curl_cffi" | ...
    best_impersonation: str = ""  # "chrome120" | "" if N/A
    min_required_headers: list[str] = field(default_factory=list)
    cookies_required: bool = False
    rate_limit: dict[str, Any] = field(default_factory=dict)
    warnings: list[str] = field(default_factory=list)
    #: T34.13: bucket tag ("A" or "B") used by the report renderer to
    #: split Validation Results into a rich Bucket A table and a
    #: compact Bucket B reachability sub-table. Empty string for legacy
    #: scans / callers that don't supply bucket info.
    bucket: str = ""
    #: T35.2: other captured URLs that collapsed into this endpoint via
    #: response-shape dedup (same method + response_type + top_level_keys
    #: signature). Always empty for Bucket B entries (shape dedup is
    #: only applied within Bucket A). The report renderer surfaces this
    #: as "X also represents these N URLs" so users can spot when two
    #: genuinely different endpoints happen to share a shape.
    aliased_urls: list[str] = field(default_factory=list)
    #: T51.6: aggregated bandwidth + cost projection across every HTTP
    #: request fired during validation of this endpoint (library
    #: compare, header reduction, cookie dependency, rate-limit probe).
    #: Keys: ``request_count`` / ``bytes_sent_total`` /
    #: ``bytes_received_total`` / ``avg_request_bytes`` /
    #: ``avg_response_bytes`` / ``per_1k_requests_mb`` /
    #: ``per_1k_requests_usd``. The USD figure picks the per-GB rate
    #: from ``PROXY_DATACENTER_PRICE_USD_PER_GB`` /
    #: ``PROXY_RESIDENTIAL_PRICE_USD_PER_GB`` based on the endpoint's
    #: best_proxy_tier; direct-IP scans report 0.0 (the report layer
    #: renders this as "N/A -- direct IP"). Empty dict for Bucket B and
    #: for the "all libraries blocked" stub.
    bandwidth_summary: dict[str, Any] = field(default_factory=dict)


@dataclass
class ValidationResult:
    """Top-level output of the validation layer.

    Shape from ``phase-1-validation-spec.md`` § Outputs (~line 26).

    T51.8 attaches three derived projections so the server can persist
    them straight into ``validation_runs`` without re-walking the
    per_endpoint rows:

    * :attr:`per_endpoint_llm_view` -- list of compact dicts (~250 tok
      each), one per Bucket A endpoint, consumed by the synthesis
      prompt.
    * :attr:`per_endpoint_report_view` -- list of richer dicts, one per
      Bucket A endpoint, consumed by the report renderer.
    * :attr:`scan_validation_summary` -- the stat-strip aggregate for
      the report's top-of-section panel.

    All three default empty so legacy / Bucket-B-only validation runs
    don't break the wire shape.
    """

    per_endpoint: list[EndpointValidation] = field(default_factory=list)
    proxy_results: list[dict[str, Any]] = field(default_factory=list)
    per_endpoint_llm_view: list[dict[str, Any]] = field(default_factory=list)
    per_endpoint_report_view: list[dict[str, Any]] = field(default_factory=list)
    scan_validation_summary: dict[str, Any] = field(default_factory=dict)


# ---------------------------------------------------------------------------
# Synthesis  (Phase 1 — new)
# ---------------------------------------------------------------------------


@dataclass
class Recommendation:
    """The recommendation-prompt output: tooling, proxy, cost band.

    Shape from ``phase-1-synthesis-spec.md`` § Outputs (~line 51) and the
    ``RecommendationOutput`` Pydantic schema (~line 406).
    """

    primary_library: (
        str  # "httpx" | "curl_cffi" | "requests" | "playwright" | "paid_unblocker"
    )
    confidence: float  # 0.0-1.0
    proxy_type: str  # "datacenter" | "residential" | "mobile" | "none"
    proxy_confidence: float  # 0.0-1.0
    cost_band_low_usd: float
    cost_band_high_usd: float
    rationale: str
    impersonation: str | None = None  # "chrome120" | "safari17" | None
    safe_rate_per_second: float | None = None  # from validation, when measured
    cost_unit_count: int = 1000


@dataclass
class StarterCode:
    """The starter-code-prompt output: a runnable Python script.

    Shape from ``phase-1-synthesis-spec.md`` § Outputs (~line 63) and the
    starter-code prompt's output JSON shape (~line 199).
    """

    code: str
    language: str = "python"
    notes: list[str] = field(default_factory=list)


@dataclass
class DependencyStep:
    """One curated step in the scraping dependency chain.

    Shape from ``phase-1-synthesis-spec.md`` § dependency curator prompt
    (~line 261). The synthesis-result example at line 69 shows a shorter
    form (``order``, ``endpoint``, ``produces`` / ``consumes``); we follow
    the curator-prompt schema here because it is the canonical output shape
    that downstream consumers (renderer, DB) read.
    """

    order: int
    from_endpoint: str
    from_field: str
    to_endpoint: str
    to_param: str
    confidence: float
    rationale: str = ""


@dataclass
class DifficultyDriver:
    """One labelled reason this site is hard or easy to scrape.

    Shape from ``phase-1-synthesis-spec.md`` § difficulty drivers prompt
    (~line 295). ``severity`` is one of ``"high" | "medium" | "low" |
    "easy"``.
    """

    label: str
    severity: str
    explanation: str
    evidence_refs: list[str] = field(default_factory=list)


@dataclass
class SynthesisResult:
    """Top-level output of the synthesis layer.

    Shape from ``phase-1-synthesis-spec.md`` § Outputs (~line 49). The
    ``notes`` field is added for the Notes prompt (~line 310) which the
    SynthesisResult example does not explicitly list but the architecture
    enumerates as one of the 6 LLM calls.
    """

    verdict: str
    recommendation: Recommendation
    starter_code: StarterCode
    dependency_chain: list[DependencyStep] = field(default_factory=list)
    difficulty_drivers: list[DifficultyDriver] = field(default_factory=list)
    notes: list[str] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Top-level Report  (Phase 1 rendering — new)
# ---------------------------------------------------------------------------


@dataclass
class Report:
    """The full payload assembled by the server pipeline and fed to the renderer.

    Shape from ``phase-1-rendering-spec.md`` § Inputs (~line 22). The spec's
    example sketches ``detection_findings=[...]`` inline; we hold a
    ``DetectionResult`` instead so the Report composes cleanly with the
    other ``*Result`` types and so the detector_version metadata travels
    with the findings.

    ``scan_timings`` (fix #4) carries the four per-phase wall-clock
    timings (capture / validation / scrub_upload / total). Each value is
    a ``float`` in seconds, or ``None`` for "phase did not run"
    (validation skipped via ``--no-validation``). Empty dict for old
    captures that pre-date fix #4 -- the renderer falls back to the
    legacy single-Duration row in that case.
    """

    report_id: str
    scan_id: str
    target_url: str
    target_domain: str
    created_at: str  # ISO-8601 string
    detection_result: DetectionResult
    analysis_result: AnalysisResult
    synthesis_result: SynthesisResult
    validation_result: ValidationResult | None = None  # None when --no-validation
    tier_used: str = "free"  # "free" | "paid"
    cli_version: str = ""
    rules_version: str = ""
    scrub_manifest: dict[str, Any] = field(default_factory=dict)
    capture_metadata: dict[str, Any] = field(default_factory=dict)
    scan_timings: dict[str, float | None] = field(default_factory=dict)
    #: T11 ground-truth replay confidence (``matches/total``). ``None``
    #: when replay was not run (legacy scan, --no-replay, --no-upload, or
    #: replay crashed). The renderer surfaces a banner when the value is
    #: present and ``< 0.5``.
    replay_confidence: float | None = None
    #: Per-endpoint replay outcome (T11). One dict per Bucket A endpoint:
    #: ``{"url": str, "method": str, "matched": bool, "status": int,
    #: "reason": str}``. Empty list when replay did not run.
    replay_per_endpoint: list[dict[str, Any]] = field(default_factory=list)
    # ----- Phase 2 / T12: surfaced from scan row for the new layout -----
    #: User free-text intent (encrypted at rest in T14). Empty string for
    #: legacy scans. Used by the header intent banner.
    intent_text: str = ""
    #: One of ``products`` / ``stocks`` / ``realestate`` / ``jobs`` /
    #: ``reviews`` / ``news`` / ``custom``. Defaults to ``"custom"`` so
    #: the header banner always has a label to render.
    starter_template: str = "custom"
    #: Up to 3 ``{"question": str, "answer": str}`` pairs from the
    #: clarifying-question loop. Empty list when the loop was skipped.
    clarifying_qa: list[dict[str, Any]] = field(default_factory=list)
    #: Persisted T7 intent-filter output. Shape: ``{"bucket_a", "bucket_b",
    #: "bucket_c", "promoted_to_b", "demoted_from_a", "defaulted_to_c",
    #: "rationale"}`` (lists of url_template strings + a string).
    #: Empty dict when filter has not run -- the renderer falls back to
    #: empty Bucket A / B sections in that case.
    bucket_assignment: dict[str, Any] = field(default_factory=dict)
    #: T13 / phase-2 § 9: ``True`` when the user explicitly chose the
    #: "Continue with generic report" action on the post-capture
    #: confirmation step. Distinct from ``bucket_assignment == {}``
    #: alone -- legacy scans also have an empty assignment but should
    #: still attempt the rich layout. When this flag is True the
    #: renderer:
    #:
    #: * hides the PREREQUISITES section,
    #: * renders SCRAPING PLAN as a flat endpoint table (v0.1.x style),
    #: * swaps the intent line for "Generic scan -- no intent
    #:   filtering applied".
    skipped_filter: bool = False
    #: Persisted T9 flow_confirm output. Shape: ``{"flow_summary": str,
    #: "matches_intent": bool, "mismatch_reason": str | None,
    #: "closest_match_intent": str | None, "confidence": float}``.
    #: Empty dict when the prompt did not run.
    flow_confirm_result: dict[str, Any] = field(default_factory=dict)
    #: ISO-8601 timestamp of the most recent ground-truth replay that
    #: confirmed the recommendation still matches reality. Empty string
    #: means "never validated" (the drift footer renders an em-dash).
    last_validated_at: str = ""


# ---------------------------------------------------------------------------
# Capture orchestration  (task 1.a.18 — new)
# ---------------------------------------------------------------------------


@dataclass
class CaptureResult:
    """Result of one browser-recon capture session.

    The ``raw`` field holds the full export dict from CDPNetworkMonitor —
    20-ish top-level keys (api_endpoints, cookies, interactions, etc.).
    ``capture_metadata`` carries quality_score (0.0-1.0) and warnings.

    ``primary_domain`` is the eTLD+1 derived from the URL the user typed
    on the CLI (fix #2). Empty string when the value was not plumbed
    through (older test fixtures, defensive default). Downstream
    consumers (analysis, renderers, output-dir derivation) prefer this
    field over the most-frequent-host heuristic.
    """

    target_url: str
    mode: str  # "quick" | "full"
    capture_metadata: dict[str, Any] = field(default_factory=dict)
    raw: dict[str, Any] = field(default_factory=dict)
    output_dir: Path | None = None
    primary_domain: str = ""
