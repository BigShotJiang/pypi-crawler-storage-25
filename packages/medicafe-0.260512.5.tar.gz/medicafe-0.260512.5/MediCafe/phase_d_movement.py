#!/usr/bin/env python
"""Shared Phase D DAT movement and reject classification helpers.

This module is intentionally small and Python 3.4 compatible.  It is used by
XP-facing bundle text, recommendations, and developer replay tooling so live
follow-up movement is described consistently without changing anchor verdicts.
"""
from __future__ import print_function


MOVEMENT_ZERO_SELECTION = 'zero_selection'
MOVEMENT_SELECTED_REJECTED = 'selected_rejected'
MOVEMENT_SELECTED_PASSED_NO_CANONICAL = 'selected_passed_no_canonical'
MOVEMENT_MILESTONE_CANDIDATE = 'milestone_candidate'
MOVEMENT_FOLLOWUP_ONLY_NOT_ANCHOR_CLOSURE = 'followup_only_not_anchor_closure'

DAT_BLOCKER_EMPTY_FILE = 'empty_dat_file'
DAT_BLOCKER_PATIENT_ANCHOR = 'patient_anchor_missing'
DAT_BLOCKER_PAYER_ANCHOR = 'payer_anchor_missing'
DAT_BLOCKER_MIXED = 'mixed'


def _safe_int(value, default=0):
    try:
        if value is None or value == '':
            return default
        return int(value)
    except Exception:
        return default


def _dict(value):
    return value if isinstance(value, dict) else {}


def _counter_dict(value):
    out = {}
    data = _dict(value)
    for key, count in data.items():
        key_s = str(key or '').strip()
        count_i = _safe_int(count, 0)
        if key_s and count_i > 0:
            out[key_s] = count_i
    return out


def _first_count(data, keys, default=0):
    for key in keys:
        if key in data:
            return _safe_int(data.get(key), default)
    return default


def extract_phase_d_dat_counts(payload, fallback=None):
    """Return stable selected/pass/reject/canonical/v2 counts from a summary-like dict."""
    data = _dict(payload)
    fb = _dict(fallback)
    tel = _dict(data.get('dat_telemetry'))
    return {
        'selected': _first_count(tel, ('dat_selected_count',), _first_count(data, (
            'selected', 'dat_selected_count', 'phase_d_dat_selected_count', 'rows_selected'), _first_count(fb, (
                'selected', 'dat_selected_count', 'phase_d_dat_selected_count', 'rows_selected'), 0))),
        'qa_pass': _first_count(tel, ('dat_qa_pass_count',), _first_count(data, (
            'qa_pass', 'dat_qa_pass_count', 'phase_d_dat_qa_pass_count', 'qa_pass_count'), _first_count(fb, (
                'qa_pass', 'dat_qa_pass_count', 'phase_d_dat_qa_pass_count', 'qa_pass_count'), 0))),
        'qa_reject': _first_count(tel, ('dat_qa_reject_count',), _first_count(data, (
            'qa_reject', 'dat_qa_reject_count', 'phase_d_dat_qa_reject_count', 'qa_reject_count'), _first_count(fb, (
                'qa_reject', 'dat_qa_reject_count', 'phase_d_dat_qa_reject_count', 'qa_reject_count'), 0))),
        'canonical': _first_count(tel, ('dat_canonical_record_count',), _first_count(data, (
            'canonical', 'dat_canonical_record_count', 'phase_d_dat_canonical_record_count'), _first_count(fb, (
                'canonical', 'dat_canonical_record_count', 'phase_d_dat_canonical_record_count'), 0))),
        'v2_inserted': _first_count(tel, ('phase_d_dat_v2_inserted_total', 'dat_v2_inserted_total'), _first_count(data, (
            'v2_inserted', 'phase_d_dat_v2_inserted_total', 'dat_v2_inserted_total'), _first_count(fb, (
                'v2_inserted', 'phase_d_dat_v2_inserted_total', 'dat_v2_inserted_total'), 0))),
    }


def classify_phase_d_movement(counts_or_payload, followup_only=False):
    """Classify Phase D DAT movement using the shared bundle/replay vocabulary."""
    if followup_only:
        return MOVEMENT_FOLLOWUP_ONLY_NOT_ANCHOR_CLOSURE
    counts = counts_or_payload if isinstance(counts_or_payload, dict) else {}
    if not any(key in counts for key in ('selected', 'qa_pass', 'qa_reject', 'canonical', 'v2_inserted')):
        counts = extract_phase_d_dat_counts(counts_or_payload)
    selected = _safe_int(counts.get('selected'), 0)
    qa_pass = _safe_int(counts.get('qa_pass'), 0)
    qa_reject = _safe_int(counts.get('qa_reject'), 0)
    canonical = _safe_int(counts.get('canonical'), 0)
    if selected <= 0 and qa_pass <= 0 and qa_reject <= 0 and canonical <= 0:
        return MOVEMENT_ZERO_SELECTION
    if selected > 0 and qa_pass > 0 and canonical > 0:
        return MOVEMENT_MILESTONE_CANDIDATE
    if selected > 0 and qa_pass > 0 and canonical <= 0:
        return MOVEMENT_SELECTED_PASSED_NO_CANONICAL
    return MOVEMENT_SELECTED_REJECTED


def extract_dat_reject_counts(payload):
    data = _dict(payload)
    tel = _dict(data.get('dat_telemetry'))
    counts = _counter_dict(tel.get('dat_qa_reject_counts_by_reason'))
    if counts:
        return counts
    counts = _counter_dict(data.get('dat_qa_reject_counts_by_reason'))
    if counts:
        return counts
    generic = _counter_dict(data.get('reject_counts_by_code'))
    out = {}
    for key, value in generic.items():
        if key.startswith('QA_DAT_'):
            out[key] = value
    return out


def extract_dat_reject_file_prefix_counts(payload):
    data = _dict(payload)
    tel = _dict(data.get('dat_telemetry'))
    counts = _counter_dict(tel.get('dat_reject_file_prefix_counts'))
    if counts:
        return counts
    return _counter_dict(data.get('dat_reject_file_prefix_counts'))


def _sorted_count_items(counts):
    items = []
    for key, value in _counter_dict(counts).items():
        items.append((key, value))
    items.sort(key=lambda item: (-item[1], item[0]))
    return items


def _blocker_for_code(code):
    if code == 'QA_DAT_EMPTY_FILE':
        return DAT_BLOCKER_EMPTY_FILE
    if code == 'QA_DAT_PATIENT_ANCHOR_MISSING':
        return DAT_BLOCKER_PATIENT_ANCHOR
    if code == 'QA_DAT_PAYER_ANCHOR_MISSING':
        return DAT_BLOCKER_PAYER_ANCHOR
    return DAT_BLOCKER_MIXED


def _developer_action_for_blocker(blocker):
    if blocker == DAT_BLOCKER_EMPTY_FILE:
        return (
            'developer_action: inspect DAT source discovery/parser handling for empty or header-only DAT artifacts; '
            'exclude or classify unreadable DAT files before QA.'
        )
    if blocker == DAT_BLOCKER_PATIENT_ANCHOR:
        return (
            'developer_action: repair DAT patient anchor mapping from redacted patient-key presence and join telemetry; '
            'do not require XP operator inspection.'
        )
    if blocker == DAT_BLOCKER_PAYER_ANCHOR:
        return (
            'developer_action: repair DAT payer anchor mapping from redacted payer alias telemetry; '
            'do not require XP operator inspection.'
        )
    return (
        'developer_action: review the DAT reject mix and address the largest parser/anchor blocker first using '
        'redacted reject samples and field-presence telemetry.'
    )


def classify_dat_reject_next_action(payload):
    """Return safe developer-facing DAT reject blocker telemetry."""
    reject_counts = extract_dat_reject_counts(payload)
    file_counts = extract_dat_reject_file_prefix_counts(payload)
    items = _sorted_count_items(reject_counts)
    dominant_code = ''
    dominant_count = 0
    blocker = ''
    if items:
        dominant_code, dominant_count = items[0]
        total = sum(value for _key, value in items)
        if len(items) > 1 and dominant_count * 2 <= total:
            blocker = DAT_BLOCKER_MIXED
        else:
            blocker = _blocker_for_code(dominant_code)
    return {
        'dominant_reject_code': dominant_code,
        'dominant_reject_count': dominant_count,
        'dat_reject_blocker_class': blocker or '',
        'dat_reject_counts_by_reason': reject_counts,
        'safe_artifact_file_prefix_counts': file_counts,
        'recommended_developer_action': _developer_action_for_blocker(blocker) if blocker else '',
    }


def format_count_map(counts, limit=8):
    items = _sorted_count_items(counts)
    if limit and len(items) > limit:
        items = items[:limit]
    if not items:
        return 'none'
    return ','.join('{0}:{1}'.format(key, value) for key, value in items)
