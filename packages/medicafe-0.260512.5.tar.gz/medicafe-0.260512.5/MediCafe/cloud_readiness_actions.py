#!/usr/bin/env python
"""
Action and phase-orchestration helpers extracted from MediCafe.cloud_readiness.
"""
from __future__ import print_function

from functools import wraps


_LOCAL_HELPER_NAMES = set(['_cloud_readiness_module', '_sync_cloud_readiness_globals', '_with_cloud_readiness_globals'])


def _cloud_readiness_module():
    from MediCafe import cloud_readiness as _cr
    return _cr


def _sync_cloud_readiness_globals():
    cr = _cloud_readiness_module()
    g = globals()
    for name, value in cr.__dict__.items():
        if name in _LOCAL_HELPER_NAMES:
            continue
        g[name] = value


def _with_cloud_readiness_globals(fn):
    @wraps(fn)
    def _wrapped(*args, **kwargs):
        _sync_cloud_readiness_globals()
        return fn(*args, **kwargs)
    return _wrapped


def _phase_b_manual_env(proc_env, env, artifact_classes=None):
    proc_env['target_folder'] = env.get('target_folder', '')
    proc_env['source_folder'] = env.get('source_folder', '')


def _phase_d_manual_env(proc_env, env, artifact_classes=None):
    classes = _normalize_phase_d_reprocess_classes(artifact_classes)
    if classes:
        proc_env['MEDICAFE_PHASE_D_ARTIFACT_CLASSES'] = ','.join(classes)


def _phase_d_manual_target_from_lab(lab_root, target_anchor_run_id='', target_context_run_id=''):
    anchor = str(target_anchor_run_id or '').strip()
    context = str(target_context_run_id or '').strip()
    if anchor and context:
        return anchor, context
    state = {}
    try:
        state = _load_json_dict(os.path.join(lab_root or '.', 'diagnostics_state.json'))
    except Exception:
        state = {}
    if not isinstance(state, dict):
        state = {}
    if not anchor:
        anchor = str(
            state.get('last_shadow_pipeline_run_id')
            or state.get('active_run_id')
            or ''
        ).strip()
    if not context:
        context = str(
            state.get('last_phase_d_run_id')
            or state.get('last_shadow_pipeline_run_id')
            or anchor
            or ''
        ).strip()
    return anchor, context


_SIMPLE_PHASE_SPECS = {
    'b': {
        'open_prefix': 'artifact_discovery_summary_',
        'open_suffixes': ('.txt', '.json'),
        'open_missing_msg': 'No artifact discovery summaries found.',
        'send_prefix_specs': [('artifact_discovery_summary_', None)],
        'send_extra_meta_key': 'phase_b_evidence',
        'send_no_attach_msg': 'No discovery summaries to attach.',
        'manual_script': 'discover_artifacts.py',
        'manual_kind': 'phase_b_manual',
        'manual_env_fn': _phase_b_manual_env,
    },
    'c': {
        'open_prefix': 'ingest_write_summary_',
        'open_suffixes': ('.txt', '.json'),
        'open_missing_msg': 'No Phase C ingest summaries found.',
        'send_prefix_specs': [('ingest_write_summary_', None), ('ingest_write_anomalies_', '.jsonl'), ('phase_c_shadow_recovery_', None)],
        'send_extra_meta_key': 'phase_c_evidence',
        'send_no_attach_msg': 'No Phase C summaries or anomalies to attach.',
        'manual_script': 'ingest_from_manifest.py',
        'manual_kind': 'phase_c_manual',
        'manual_env_fn': None,
    },
    'd': {
        'open_prefix': 'qa_canonical_summary_',
        'open_suffixes': ('.txt', '.json'),
        'open_missing_msg': 'No Phase D summaries found.',
        'send_prefix_specs': [('qa_canonical_summary_', None), ('qa_reject_samples_', '.jsonl')],
        'send_extra_meta_key': 'phase_d_evidence',
        'send_no_attach_msg': 'No Phase D summaries or reject samples to attach.',
        'manual_script': 'run_qa_canonical.py',
        'manual_kind': 'phase_d_manual',
        'manual_env_fn': _phase_d_manual_env,
    },
    'e': {
        'open_prefix': 'projection_parity_summary_',
        'open_suffixes': ('.txt', '.json'),
        'open_missing_msg': 'No Phase E summaries found.',
        'send_prefix_specs': [('projection_parity_summary_', None), ('projection_deviation_samples_', '.jsonl')],
        'send_extra_meta_key': 'phase_e_evidence',
        'send_no_attach_msg': 'No Phase E summaries or deviation samples to attach.',
        'manual_script': 'run_projection_parity.py',
        'manual_kind': 'phase_e_manual',
        'manual_env_fn': None,
    },
}


@_with_cloud_readiness_globals
def _open_simple_phase_summary(repo_root, phase_key):
    spec = _SIMPLE_PHASE_SPECS[phase_key]
    lab_root = resolve_lab_root(repo_root)
    reports_dir = os.path.join(lab_root, 'reports')
    path, msg = _find_latest_by_prefix(reports_dir, spec['open_prefix'], spec['open_suffixes'])
    if path:
        return (True, '', path)
    if msg:
        return (False, msg, None)
    return (False, spec['open_missing_msg'], None)


@_with_cloud_readiness_globals
def _send_simple_phase_evidence(repo_root, phase_key):
    spec = _SIMPLE_PHASE_SPECS[phase_key]
    lab_root = resolve_lab_root(repo_root)
    return _send_phase_evidence(
        lab_root,
        spec['send_prefix_specs'],
        spec['send_extra_meta_key'],
        spec['send_no_attach_msg'],
    )


@_with_cloud_readiness_globals
def _run_simple_phase_manual(repo_root, python_exe, env, phase_key, artifact_classes=None):
    spec = _SIMPLE_PHASE_SPECS[phase_key]
    ok_script, script_msg, script_repo_root, script, _ = _resolve_unified_model_script(
        repo_root, python_exe, spec['manual_script']
    )
    if not ok_script:
        return (False, script_msg, None)
    try:
        lab_root = resolve_lab_root(repo_root)
        proc_env = os.environ.copy()
        proc_env['MEDICAFE_LAB_DIR'] = lab_root
        env_fn = spec.get('manual_env_fn')
        if env_fn is not None:
            env_fn(proc_env, env, artifact_classes=artifact_classes)
        target_anchor = ''
        target_context = ''
        if phase_key == 'd':
            target_anchor, target_context = _phase_d_manual_target_from_lab(
                lab_root,
                target_anchor_run_id=(env or {}).get('MEDICAFE_DIAGNOSTIC_TARGET_ANCHOR_RUN_ID', ''),
                target_context_run_id=(env or {}).get('MEDICAFE_DIAGNOSTIC_TARGET_CONTEXT_RUN_ID', ''),
            )
        attempt_id = _new_diagnostic_attempt_id(spec['manual_kind'])
        ok_launch, msg_launch, _meta_launch = _launch_tracked_diagnostic_async(
            repo_root,
            python_exe,
            proc_env,
            lab_root,
            spec['manual_kind'],
            attempt_id,
            script_repo_root,
            [python_exe, script],
            target_anchor_run_id=target_anchor,
            target_context_run_id=target_context,
            child_env_lab_root=lab_root,
        )
        if not ok_launch:
            return (False, msg_launch, None)
        return (True, '', None)
    except Exception as e:
        return (False, str(e), None)

@_with_cloud_readiness_globals
def _find_latest_run_id_by_prefix(reports_dir, prefix, suffix_choices):
    """
    Find latest file by prefix (mtime). Parse run_id from filename.
    Returns (run_id, path) or (None, None).
    Filename pattern: {prefix}{run_id}.{ext}
    """
    if not reports_dir or not os.path.exists(reports_dir):
        return (None, None)
    try:
        items = os.listdir(reports_dir)
    except (IOError, OSError):
        return (None, None)
    candidates = []
    prefix_len = len(prefix)
    for item in items:
        if not item.startswith(prefix):
            continue
        for suf in suffix_choices:
            if item.endswith(suf):
                path = os.path.join(reports_dir, item)
                if os.path.isfile(path):
                    rest = item[prefix_len:]
                    if '.' in rest:
                        run_id = rest.rsplit('.', 1)[0]
                    else:
                        run_id = rest
                    if run_id and len(run_id) >= 17 and '-' in run_id:
                        candidates.append((run_id, path))
                break
    if not candidates:
        return (None, None)
    try:
        return max(candidates, key=lambda x: os.path.getmtime(x[1]))
    except (IOError, OSError, ValueError):
        return (None, None)

@_with_cloud_readiness_globals
def _select_latest_evidence_files(lab_root, prefix_specs, prefer_diagnostics_lineage=False):
    """
    Select latest coherent run's evidence files per prefix_specs.
    prefix_specs: [(prefix, suffix), ...] where suffix is None for (.txt, .json) or e.g. '.jsonl'.
    Returns [(basename, fullpath), ...].
    """
    reports_dir = os.path.join(lab_root, 'reports')
    if not reports_dir or not os.path.exists(reports_dir):
        return []
    if not prefix_specs:
        return []
    primary_prefix, primary_suffix = prefix_specs[0]
    suffix_choices = ('.txt', '.json') if primary_suffix is None else (primary_suffix,)
    run_id = ''
    if prefer_diagnostics_lineage:
        run_id = _preferred_evidence_run_id(lab_root, reports_dir)
    if run_id:
        candidate_path = ''
        for suffix in suffix_choices:
            path = os.path.join(reports_dir, '{0}{1}{2}'.format(primary_prefix, run_id, suffix))
            if os.path.isfile(path):
                candidate_path = path
                break
        if not candidate_path:
            run_id = ''
    if not run_id:
        run_id, _ = _find_latest_run_id_by_prefix(reports_dir, primary_prefix, suffix_choices)
    if not run_id:
        return []
    extra_files = []
    seen = set()
    for prefix, suffix in prefix_specs:
        if suffix is None:
            group = {'prefix': prefix, 'suffixes': ('.json', '.txt')}
            for path in _collect_group_paths_for_run(reports_dir, run_id, group):
                basename = os.path.basename(path)
                if basename not in seen:
                    extra_files.append((basename, path))
                    seen.add(basename)
        else:
            basename = prefix + run_id + suffix
            path = os.path.join(reports_dir, basename)
            if os.path.isfile(path) and basename not in seen:
                extra_files.append((basename, path))
                seen.add(basename)
    return extra_files

@_with_cloud_readiness_globals
def _send_phase_evidence(lab_root, prefix_specs, extra_meta_key, no_attach_msg):
    """
    Send latest coherent run's evidence. prefix_specs: [(prefix, suffix), ...].
    Requires at least one phase artifact; context files are additive only.
    """
    if collect_support_bundle is None or submit_support_bundle_email is None:
        return (False, 'Support bundle tools unavailable.', None)
    reports_err = _reports_dir_access_error(lab_root)
    if reports_err:
        return (False, reports_err, None)
    phase_files = _select_latest_evidence_files(
        lab_root,
        prefix_specs,
        prefer_diagnostics_lineage=False,
    )
    if not phase_files:
        return (False, no_attach_msg, None)
    extra_meta = {
        extra_meta_key: True,
        'send_source': 'manual_{0}'.format(extra_meta_key),
        'lab_root': lab_root,
    }
    manifest_for_zip = None
    extra_files = []
    try:
        from MediCafe import evidence_manifest as _em_manifest

        anchor = ''
        st = _load_json_dict(os.path.join(lab_root, 'diagnostics_state.json'))
        if isinstance(st, dict):
            anchor = str(st.get('last_shadow_pipeline_run_id', '') or '').strip()
        _req = _em_manifest.build_evidence_request(
            extra_meta_key,
            'manual_{0}'.format(extra_meta_key),
            lab_root,
            anchor_run_id=anchor,
            _prefetched_evidence_tuples=list(phase_files),
        )
        manifest_for_zip = _em_manifest.resolve_evidence_manifest(_req)
        for _k, _v in _em_manifest.manifest_to_extra_meta(manifest_for_zip).items():
            extra_meta[_k] = _v
    except Exception:
        manifest_for_zip = None
    if manifest_for_zip is None:
        extra_files = list(phase_files)
        for ctx_name in ('diagnostics_state.json', 'run_cursor.json'):
            ctx_path = os.path.join(lab_root, ctx_name)
            if os.path.isfile(ctx_path):
                extra_files.append((ctx_name, ctx_path))
    try:
        delivery_preflight = _collect_delivery_diagnostics()
        extra_meta['email_delivery_preflight'] = delivery_preflight
        zip_path = collect_support_bundle(
            include_traceback=False,
            extra_meta=extra_meta,
            extra_files=extra_files if extra_files else None,
            evidence_manifest=manifest_for_zip,
        )
        if not zip_path:
            return (False, 'Failed to create support bundle.', None)
        ok, msg, _ = _submit_bundle_with_delivery_diagnostics(
            zip_path=zip_path,
            allow_interactive_reauth=True,
        )
        return (ok, msg, None)
    except Exception as e:
        return (False, 'Error: {0}'.format(e), None)

@_with_cloud_readiness_globals
def run_pipeline(repo_root, python_exe, env, env_flag_fn):
    """
    When shadow_auto=1: spawn run_shadow_pipeline.py (non-blocking).
    When shadow_auto=0: Phase A blocks (subprocess.call), then B/C/D spawn via Popen.
    Env from os.environ.copy() + overlay MEDICAFE_LAB_DIR, target_folder, source_folder.
    """
    try:
        orchestration = shadow_orchestrator.start_or_attach_shadow_pipeline(
            action_id=shadow_orchestrator.ACTION_STARTUP,
            entrypoint=shadow_orchestrator.ENTRYPOINT_STARTUP,
            repo_root=repo_root,
            python_exe=python_exe,
            env=env,
            env_flag_fn=env_flag_fn,
            ops=_orchestrator_ops(),
        )
        ok, msg, data = _coerce_orchestrator_result_to_legacy(orchestration)
        if not ok:
            _maybe_send_orchestrator_failure_report(
                repo_root=repo_root,
                lab_root=resolve_lab_root(repo_root),
                orchestration_result=orchestration,
                trigger='run_pipeline_startup',
            )
        return (ok, msg, data)
    except Exception as e:
        # Typed orchestrator failures call _maybe_send_orchestrator_failure_report above.
        # Uncaught exceptions (e.g. OSError WinError 87) previously returned only a console
        # notice with no auto-report; mirror the failure bundle path for operator visibility.
        try:
            import traceback as _traceback
            _lab_exc = None
            try:
                _lab_exc = resolve_lab_root(repo_root)
            except Exception:
                _lab_exc = os.path.join(repo_root or os.getcwd(), 'lab')
            _maybe_send_orchestrator_failure_report(
                repo_root=repo_root,
                lab_root=_lab_exc,
                orchestration_result={
                    'status': shadow_orchestrator.STATUS_FAILED,
                    'error_code': 'ORCHESTRATION_EXCEPTION',
                    'message': str(e),
                    'payload': {
                        'exception_class': type(e).__name__,
                        'exception_message': str(e),
                        'traceback': _traceback.format_exc(),
                        'trigger_context': 'run_pipeline_startup_uncaught_exception',
                    },
                },
                trigger='run_pipeline_startup_exception',
            )
        except Exception:
            pass
        return (False, 'Cloud Readiness startup orchestration failed: {0}'.format(e), None)

@_with_cloud_readiness_globals
def open_phase_b_summary(repo_root):
    return _open_simple_phase_summary(repo_root, 'b')

@_with_cloud_readiness_globals
def open_manifest_location(repo_root):
    """Return manifest file path for explorer /select. Launcher opens explorer, not viewer."""
    lab_root = resolve_lab_root(repo_root)
    cursor_path = os.path.join(lab_root, 'run_cursor.json')
    manifest_path = None
    if os.path.exists(cursor_path):
        try:
            with open(cursor_path, 'r', encoding='utf-8') as f:
                cursor = json.load(f)
            manifest_path = cursor.get('last_manifest_path')
        except (IOError, OSError, ValueError):
            pass
    if not manifest_path or not os.path.exists(manifest_path):
        reports_dir = os.path.join(lab_root, 'reports')
        if os.path.exists(reports_dir):
            try:
                report_items = os.listdir(reports_dir)
            except (IOError, OSError) as e:
                return (False, 'Unable to read reports directory: {0}'.format(e), None)
            manifests = [
                os.path.join(reports_dir, x) for x in report_items
                if x.startswith('artifact_manifest_') and x.endswith('.jsonl')
                and os.path.isfile(os.path.join(reports_dir, x))
            ]
            if manifests:
                try:
                    manifest_path = max(manifests, key=os.path.getmtime)
                except (IOError, OSError, ValueError):
                    return (False, 'Unable to resolve latest manifest file.', None)
    if manifest_path and os.path.exists(manifest_path):
        return (True, '', manifest_path)
    return (False, 'No manifest found. Run discovery from Cloud Readiness first.', None)

@_with_cloud_readiness_globals
def run_phase_b_manual(repo_root, python_exe, env):
    return _run_simple_phase_manual(repo_root, python_exe, env, 'b')

@_with_cloud_readiness_globals
def send_phase_b_evidence(repo_root):
    return _send_simple_phase_evidence(repo_root, 'b')

@_with_cloud_readiness_globals
def open_phase_c_summary(repo_root):
    return _open_simple_phase_summary(repo_root, 'c')

@_with_cloud_readiness_globals
def run_phase_c_manual(repo_root, python_exe, env):
    return _run_simple_phase_manual(repo_root, python_exe, env, 'c')

@_with_cloud_readiness_globals
def send_phase_c_evidence(repo_root):
    return _send_simple_phase_evidence(repo_root, 'c')

@_with_cloud_readiness_globals
def open_phase_d_summary(repo_root):
    return _open_simple_phase_summary(repo_root, 'd')

@_with_cloud_readiness_globals
def open_phase_d_reject_sample(repo_root):
    lab_root = resolve_lab_root(repo_root)
    reports_dir = os.path.join(lab_root, 'reports')
    path, msg = _find_latest_by_prefix(reports_dir, 'qa_reject_samples_', ('.jsonl',))
    if path:
        return (True, '', path)
    if msg:
        return (False, msg, None)
    return (False, 'No Phase D reject sample files found.', None)

@_with_cloud_readiness_globals
def run_phase_d_manual(repo_root, python_exe, env, artifact_classes=None, target_anchor_run_id='', target_context_run_id=''):
    env2 = dict(env or {})
    if target_anchor_run_id:
        env2['MEDICAFE_DIAGNOSTIC_TARGET_ANCHOR_RUN_ID'] = str(target_anchor_run_id or '')
    if target_context_run_id:
        env2['MEDICAFE_DIAGNOSTIC_TARGET_CONTEXT_RUN_ID'] = str(target_context_run_id or '')
    return _run_simple_phase_manual(repo_root, python_exe, env2, 'd', artifact_classes=artifact_classes)

def _new_diagnostic_attempt_id(diagnostic_kind):
    try:
        from MediCafe import diagnostic_attempts as _diagnostic_attempts
        return _diagnostic_attempts.generate_attempt_id()
    except Exception:
        safe = ''.join([
            ch if ch.isalnum() or ch in ('-', '_', '.') else '_'
            for ch in str(diagnostic_kind or 'diagnostic')
        ])
        return '{0}_{1}_{2}'.format(safe or 'diagnostic', os.getpid(), int(time.time()))


def _diagnostic_attempt_path_for_meta(lab_root, diagnostic_kind, attempt_id):
    try:
        from MediCafe import diagnostic_attempts as _diagnostic_attempts
        path = _diagnostic_attempts.attempt_path(lab_root, diagnostic_kind, attempt_id)
        return str(path or '')
    except Exception:
        safe_kind = ''.join([
            ch if ch.isalnum() or ch in ('-', '_', '.') else '_'
            for ch in str(diagnostic_kind or 'diagnostic')
        ])
        safe_attempt = ''.join([
            ch if ch.isalnum() or ch in ('-', '_', '.') else '_'
            for ch in str(attempt_id or '')
        ])
        if not safe_attempt:
            return ''
        return os.path.join(
            lab_root,
            'reports',
            'diagnostic_attempt_{0}_{1}.json'.format(safe_kind or 'diagnostic', safe_attempt),
        )


def _launch_tracked_diagnostic_async(
        repo_root,
        python_exe,
        env,
        lab_root,
        diagnostic_kind,
        attempt_id,
        child_cwd,
        child_args,
        target_anchor_run_id='',
        target_context_run_id='',
        issue_code='',
        child_env_lab_root=''):
    """
    Launch scripts/unified_model/run_tracked_diagnostic.py around a child command.

    The attempt record is written under lab_root while MEDICAFE_LAB_DIR for the
    child process can be redirected with child_env_lab_root.
    """
    ok_wrapper, wrapper_msg, wrapper_repo_root, wrapper_script, _ = _resolve_unified_model_script(
        repo_root, python_exe, 'run_tracked_diagnostic.py'
    )
    if not ok_wrapper:
        return (False, wrapper_msg, None)
    proc_env = os.environ.copy()
    if env:
        proc_env.update(env)
    proc_env['MEDICAFE_LAB_DIR'] = str(child_env_lab_root or lab_root)
    attempt_path = _diagnostic_attempt_path_for_meta(lab_root, diagnostic_kind, attempt_id)
    cmd = [
        python_exe,
        wrapper_script,
        '--lab-dir',
        lab_root,
        '--kind',
        diagnostic_kind,
        '--attempt-id',
        attempt_id,
        '--target-anchor-run-id',
        str(target_anchor_run_id or ''),
        '--target-context-run-id',
        str(target_context_run_id or ''),
        '--issue-code',
        str(issue_code or ''),
        '--cwd',
        child_cwd,
        '--',
    ] + list(child_args or [])
    proc = subprocess.Popen(
        cmd,
        cwd=wrapper_repo_root,
        env=proc_env,
    )
    return (True, '', {
        'process': proc,
        'pid': getattr(proc, 'pid', None),
        'attempt_id': attempt_id,
        'attempt_path': attempt_path,
        'tracked_wrapper_script': wrapper_script,
        'tracked_child_command': list(child_args or []),
        'target_anchor_run_id': str(target_anchor_run_id or ''),
        'target_context_run_id': str(target_context_run_id or ''),
        'issue_code': str(issue_code or ''),
    })


@_with_cloud_readiness_globals
def run_phase_d_dat_smoke(
        repo_root,
        python_exe,
        env,
        reference_phase_d_summary_path=None,
        recommendation_anchor_run_id='',
        recommendation_context_run_id='',
        recommendation_issue_code=''):
    """
    Run scripts/unified_model/run_phase_d_dat_smoke.py against repo_root/phase_d_dat_smoke_lab (background).
    Diagnostic only; does not close QA milestone. Reports: reports/phase_d_dat_smoke_report_<anchor>.txt

    Returns (ok, message, meta).
    """
    ok_script, script_msg, script_repo_root, script, _ = _resolve_unified_model_script(
        repo_root, python_exe, 'run_phase_d_dat_smoke.py'
    )
    if not ok_script:
        return (False, script_msg, None)
    requested_anchor = ''
    requested_context = ''
    requested_issue = ''
    try:
        smoke_lab = os.path.join(repo_root, 'phase_d_dat_smoke_lab')
        if is_pipeline_running(smoke_lab):
            return (False, 'DAT smoke already running for phase_d_dat_smoke_lab.', {'already_running': True})
        attempt_lab_root = resolve_lab_root(repo_root)
        requested_anchor = str(recommendation_anchor_run_id or '').strip()
        requested_context = str(recommendation_context_run_id or '').strip()
        requested_issue = str(recommendation_issue_code or '').strip()
        now_utc = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())
        attempt_id = '{0}:{1}:{2}:{3}'.format(
            requested_anchor or 'anchor',
            requested_context or 'context',
            requested_issue or 'issue',
            str(int(time.time())),
        )
        begin_phase_d_dat_smoke_attempt(
            repo_root,
            anchor_run_id=requested_anchor,
            context_run_id=requested_context,
            issue_code=requested_issue,
            started_at_utc=now_utc,
            attempt_id=attempt_id,
        )
        state_path = phase_d_dat_smoke_state_path(repo_root)
        proc_env = os.environ.copy()
        if env:
            proc_env.update(env)
        proc_env['MEDICAFE_LAB_DIR'] = smoke_lab
        args = [python_exe, script, '--lab-dir', smoke_lab, '--state-path', state_path]
        ref_path = str(reference_phase_d_summary_path or '').strip()
        if ref_path:
            args.extend(['--reference-phase-d-summary', ref_path])
        if requested_anchor:
            args.extend(['--requested-anchor-run-id', requested_anchor])
        if requested_context:
            args.extend(['--requested-context-run-id', requested_context])
        if requested_issue:
            args.extend(['--requested-issue-code', requested_issue])
        if attempt_id:
            args.extend(['--attempt-id', attempt_id])
        launch_ok, launch_msg, launch_meta = _launch_tracked_diagnostic_async(
            repo_root,
            python_exe,
            proc_env,
            attempt_lab_root,
            'phase_d_dat_smoke',
            attempt_id,
            script_repo_root,
            args,
            target_anchor_run_id=requested_anchor,
            target_context_run_id=requested_context,
            issue_code=requested_issue,
            child_env_lab_root=smoke_lab,
        )
        if not launch_ok:
            raise RuntimeError(launch_msg)
        launch_meta = launch_meta if isinstance(launch_meta, dict) else {}
        return (True, '', {
            'async_launch': True,
            'pid': launch_meta.get('pid'),
            'attempt_id': attempt_id,
            'attempt_path': launch_meta.get('attempt_path', ''),
            'tracked_wrapper_script': launch_meta.get('tracked_wrapper_script', ''),
            'reference_phase_d_summary_path': ref_path,
            'requested_anchor_run_id': requested_anchor,
            'requested_context_run_id': requested_context,
            'requested_issue_code': requested_issue,
        })
    except Exception as e:
        try:
            now_utc = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())
            st = read_phase_d_dat_smoke_state(repo_root)
            st['last_attempt_id'] = str(st.get('last_attempt_id', '') or '').strip()
            st['last_requested_anchor_run_id'] = str(requested_anchor or '').strip()
            st['last_requested_context_run_id'] = str(requested_context or '').strip()
            st['last_remediation_issue_code'] = str(requested_issue or '').strip()
            st['last_finished_at_utc'] = now_utc
            st['last_status'] = 'failed'
            st['last_report_path'] = ''
            st['last_assessment'] = 'spawn_failed'
            st['cooldown_until_utc'] = ''
            write_phase_d_dat_smoke_state(repo_root, st)
        except Exception:
            pass
        return (False, str(e), None)

_LAST_HISTORICAL_HELPER_LOAD_DIAGNOSTICS = {}


def get_last_historical_phase_d_reprocess_helper_diagnostics():
    """Last structured helper-load outcome for historical Phase D reprocess (XP/support triage)."""
    global _LAST_HISTORICAL_HELPER_LOAD_DIAGNOSTICS
    diag = _LAST_HISTORICAL_HELPER_LOAD_DIAGNOSTICS
    return dict(diag) if isinstance(diag, dict) else {}


def _publish_historical_helper_diagnostics(diag):
    global _LAST_HISTORICAL_HELPER_LOAD_DIAGNOSTICS
    if isinstance(diag, dict):
        _LAST_HISTORICAL_HELPER_LOAD_DIAGNOSTICS = dict(diag)
    else:
        _LAST_HISTORICAL_HELPER_LOAD_DIAGNOSTICS = {}


def _clear_historical_phase_d_reprocess_runtime_refs():
    """Clear dynamic Phase D helper pointers in cloud_readiness_actions and cloud_readiness."""
    global _collect_phase_d_reject_snapshot_impl
    global _execute_historical_phase_d_reprocess_impl
    global _normalize_phase_d_reprocess_classes_impl
    global _preview_historical_phase_d_reprocess_impl
    _collect_phase_d_reject_snapshot_impl = None
    _execute_historical_phase_d_reprocess_impl = None
    _normalize_phase_d_reprocess_classes_impl = None
    _preview_historical_phase_d_reprocess_impl = None
    try:
        cr = _cloud_readiness_module()
        cr._collect_phase_d_reject_snapshot_impl = None
        cr._execute_historical_phase_d_reprocess_impl = None
        cr._normalize_phase_d_reprocess_classes_impl = None
        cr._preview_historical_phase_d_reprocess_impl = None
    except Exception:
        pass


def _load_historical_reprocess_module_from_path(script_path):
    """
    Load phase_d_historical_reprocess from disk without a package import path.

    Prefer importlib when available (Python 3.5+, including 3.12+ where ``imp`` was removed).
    Fall back to ``imp.load_source`` on Python 3.4 / XP environments without ``module_from_spec``.
    """
    import importlib.util

    spec_from_file = getattr(importlib.util, 'spec_from_file_location', None)
    module_from_spec = getattr(importlib.util, 'module_from_spec', None)
    if spec_from_file is not None and module_from_spec is not None:
        spec = spec_from_file('_medicafe_phase_d_historical_reprocess_runtime', script_path)
        loader = getattr(spec, 'loader', None) if spec is not None else None
        if spec is not None and loader is not None:
            module = module_from_spec(spec)
            loader.exec_module(module)
            return module

    try:
        import imp as _imp
    except ImportError:
        _imp = None
    load_source = getattr(_imp, 'load_source', None) if _imp is not None else None
    if load_source is None:
        raise ImportError(
            'Cannot load historical Phase D helper: imp unavailable and importlib helpers incomplete')
    return load_source('_medicafe_phase_d_historical_reprocess_runtime', script_path)


@_with_cloud_readiness_globals
def _ensure_historical_phase_d_reprocess_helpers(repo_root, python_exe=None):
    """
    Load historical Phase D helpers from the resolved script path when package
    imports are unavailable in the installed XP runtime.
    """
    global _collect_phase_d_reject_snapshot_impl
    global _execute_historical_phase_d_reprocess_impl
    global _normalize_phase_d_reprocess_classes_impl
    global _preview_historical_phase_d_reprocess_impl

    diag = {
        'hist_helper_stage': 'init',
        'recommended_action_kind': 'historical_phase_d_reprocess',
        'resolved_script_path': '',
        'script_path_candidates': [],
        'script_resolution_ok': False,
        'resolution_message': '',
        'import_exception_class': '',
        'import_exception_message': '',
        'helper_functions_missing': False,
        'hist_helper_load_ok': False,
    }

    if _preview_historical_phase_d_reprocess_impl is not None and _execute_historical_phase_d_reprocess_impl is not None:
        diag['hist_helper_stage'] = 'already_initialized'
        diag['hist_helper_load_ok'] = True
        diag['resolution_message'] = 'helper already loaded in-process'
        _publish_historical_helper_diagnostics(diag)
        return (True, '', None)
    try:
        py = python_exe or getattr(sys, 'executable', '') or ''
    except Exception:
        py = ''
    script_checks = []
    ok_script = False
    script_msg = ''
    script_path = ''
    try:
        ok_script, script_msg, _script_repo_root, script_path, script_checks = _resolve_unified_model_script(
            repo_root,
            py,
            'phase_d_historical_reprocess.py',
        )
    except Exception as e:
        diag['hist_helper_stage'] = 'resolution_exception'
        diag['import_exception_class'] = e.__class__.__name__
        diag['import_exception_message'] = str(e)
        diag['resolution_message'] = str(e)[:500]
        _publish_historical_helper_diagnostics(diag)
        return (False, 'Historical Phase D re-evaluation helper unavailable: {0}'.format(str(e) or e.__class__.__name__), None)
    candidates = []
    if isinstance(script_checks, list):
        for entry in script_checks:
            if isinstance(entry, dict) and entry.get('script_path'):
                candidates.append(str(entry.get('script_path')))
    if script_path and script_path not in candidates:
        candidates.insert(0, str(script_path))
    diag['script_path_candidates'] = candidates[:48]
    diag['resolved_script_path'] = str(script_path or '')
    diag['script_resolution_ok'] = bool(ok_script)
    diag['resolution_message'] = str(script_msg or '')
    if not ok_script or not script_path:
        diag['hist_helper_stage'] = 'script_missing'
        _publish_historical_helper_diagnostics(diag)
        return (False, 'Historical Phase D re-evaluation helper unavailable: {0}'.format(script_msg or 'script not found'), None)
    _clear_historical_phase_d_reprocess_runtime_refs()
    module = None
    try:
        module = _load_historical_reprocess_module_from_path(script_path)
        _collect_phase_d_reject_snapshot_impl = getattr(module, 'collect_phase_d_reject_snapshot', None)
        _execute_historical_phase_d_reprocess_impl = getattr(module, 'execute_historical_phase_d_reprocess', None)
        _normalize_phase_d_reprocess_classes_impl = getattr(module, 'normalize_artifact_classes', None)
        _preview_historical_phase_d_reprocess_impl = getattr(module, 'preview_historical_phase_d_reprocess', None)
        try:
            cr = _cloud_readiness_module()
            cr._collect_phase_d_reject_snapshot_impl = _collect_phase_d_reject_snapshot_impl
            cr._execute_historical_phase_d_reprocess_impl = _execute_historical_phase_d_reprocess_impl
            cr._normalize_phase_d_reprocess_classes_impl = _normalize_phase_d_reprocess_classes_impl
            cr._preview_historical_phase_d_reprocess_impl = _preview_historical_phase_d_reprocess_impl
        except Exception:
            pass
    except Exception as e:
        _clear_historical_phase_d_reprocess_runtime_refs()
        diag['hist_helper_stage'] = 'import_failed'
        diag['import_exception_class'] = e.__class__.__name__
        diag['import_exception_message'] = str(e)
        diag['resolution_message'] = 'dynamic historical module load failed'
        _publish_historical_helper_diagnostics(diag)
        return (False, 'Historical Phase D re-evaluation helper unavailable: {0}'.format(str(e) or e.__class__.__name__), None)
    if _preview_historical_phase_d_reprocess_impl is None or _execute_historical_phase_d_reprocess_impl is None:
        _clear_historical_phase_d_reprocess_runtime_refs()
        diag['hist_helper_stage'] = 'symbols_missing'
        diag['helper_functions_missing'] = True
        diag['resolution_message'] = 'required functions missing after dynamic load'
        _publish_historical_helper_diagnostics(diag)
        return (False, 'Historical Phase D re-evaluation helper unavailable: helper functions missing in {0}'.format(script_path), None)
    diag['hist_helper_stage'] = 'load_ok'
    diag['hist_helper_load_ok'] = True
    _publish_historical_helper_diagnostics(diag)
    return (True, '', module)

@_with_cloud_readiness_globals
def preview_historical_phase_d_reprocess(repo_root, artifact_classes=None, remediation_context_run_id=None):
    ok_helper, helper_msg, _ = _ensure_historical_phase_d_reprocess_helpers(repo_root)
    if not ok_helper:
        return (False, helper_msg, None)
    lab_root = resolve_lab_root(repo_root)
    data = _preview_historical_phase_d_reprocess_impl(
        lab_root,
        artifact_classes=artifact_classes,
        remediation_context_run_id=remediation_context_run_id,
    )
    ok = bool(isinstance(data, dict) and data.get('ok'))
    msg = '' if ok else str((data or {}).get('error', '') or 'Unable to build historical Phase D re-evaluation preview.')
    return (ok, msg, data)

@_with_cloud_readiness_globals
def run_historical_phase_d_reprocess(repo_root, python_exe, env, artifact_classes=None, remediation_context_run_id=None):
    ok_helper, helper_msg, _ = _ensure_historical_phase_d_reprocess_helpers(repo_root, python_exe=python_exe)
    if not ok_helper:
        return (False, helper_msg, None)
    lab_root = resolve_lab_root(repo_root)
    data = _execute_historical_phase_d_reprocess_impl(
        lab_root,
        artifact_classes=artifact_classes,
        remediation_context_run_id=remediation_context_run_id,
    )
    if not isinstance(data, dict) or not data.get('ok'):
        msg = str((data or {}).get('error', '') or 'Unable to reset historical Phase D reject state.')
        return (False, msg, data)
    classes = _normalize_phase_d_reprocess_classes(data.get('targeted_artifact_classes', []))
    target_anchor = str(remediation_context_run_id or data.get('remediation_context_run_id') or '').strip()
    if target_anchor:
        ok_run, msg_run, _ = run_phase_d_manual(
            repo_root,
            python_exe,
            env,
            artifact_classes=classes,
            target_anchor_run_id=target_anchor,
            target_context_run_id=target_anchor,
        )
    else:
        ok_run, msg_run, _ = run_phase_d_manual(repo_root, python_exe, env, artifact_classes=classes)
    if not ok_run:
        data['phase_d_launch_error'] = msg_run
        return (
            False,
            'Historical Phase D reject state was reset, but the filtered Phase D rerun could not be started: {0}'.format(msg_run),
            data,
        )
    msg = 'Historical Phase D re-evaluation started for {0}. Return to 1) Follow recommendation after the rerun settles.'.format(
        ', '.join(classes) or 'the targeted classes'
    )
    return (True, msg, data)

@_with_cloud_readiness_globals
def send_phase_d_evidence(repo_root):
    return _send_simple_phase_evidence(repo_root, 'd')

@_with_cloud_readiness_globals
def open_phase_e_summary(repo_root):
    return _open_simple_phase_summary(repo_root, 'e')

@_with_cloud_readiness_globals
def open_phase_e_deviation_samples(repo_root):
    lab_root = resolve_lab_root(repo_root)
    reports_dir = os.path.join(lab_root, 'reports')
    path, msg = _find_latest_by_prefix(reports_dir, 'projection_deviation_samples_', ('.jsonl',))
    if path:
        return (True, '', path)
    if msg:
        return (False, msg, None)
    return (False, 'No Phase E deviation sample files found.', None)

@_with_cloud_readiness_globals
def run_phase_e_manual(repo_root, python_exe, env):
    return _run_simple_phase_manual(repo_root, python_exe, env, 'e')

@_with_cloud_readiness_globals
def send_phase_e_evidence(repo_root):
    return _send_simple_phase_evidence(repo_root, 'e')

@_with_cloud_readiness_globals
def run_shadow_pipeline(repo_root, python_exe, env):
    try:
        def _env_flag(name, default):
            raw = env.get(name)
            if raw is None:
                raw = os.environ.get(name)
            if raw is None:
                return default
            return str(raw).strip().lower() in ('1', 'true', 'yes', 'on', 'y')

        orchestration = shadow_orchestrator.start_or_attach_shadow_pipeline(
            action_id=shadow_orchestrator.ACTION_MANUAL_FULL_PIPELINE,
            entrypoint=shadow_orchestrator.ENTRYPOINT_MANUAL,
            repo_root=repo_root,
            python_exe=python_exe,
            env=env,
            env_flag_fn=_env_flag,
            ops=_orchestrator_ops(),
        )
        ok, msg, data = _coerce_orchestrator_result_to_legacy(orchestration)
        if not ok:
            _maybe_send_orchestrator_failure_report(
                repo_root=repo_root,
                lab_root=resolve_lab_root(repo_root),
                orchestration_result=orchestration,
                trigger='run_shadow_pipeline_manual',
            )
        return (ok, msg, data)
    except Exception as e:
        try:
            import traceback as _traceback
            _lab_exc = None
            try:
                _lab_exc = resolve_lab_root(repo_root)
            except Exception:
                _lab_exc = os.path.join(repo_root or os.getcwd(), 'lab')
            _maybe_send_orchestrator_failure_report(
                repo_root=repo_root,
                lab_root=_lab_exc,
                orchestration_result={
                    'status': shadow_orchestrator.STATUS_FAILED,
                    'error_code': 'ORCHESTRATION_EXCEPTION',
                    'message': str(e),
                    'payload': {
                        'exception_class': type(e).__name__,
                        'exception_message': str(e),
                        'traceback': _traceback.format_exc(),
                        'trigger_context': 'run_shadow_pipeline_manual_uncaught_exception',
                    },
                },
                trigger='run_shadow_pipeline_manual_exception',
            )
        except Exception:
            pass
        return (False, str(e), None)

@_with_cloud_readiness_globals
def open_phase_f_shadow_report(repo_root):
    lab_root = resolve_lab_root(repo_root)
    reports_dir = os.path.join(lab_root, 'reports')
    path, msg = _find_latest_by_prefix(reports_dir, 'shadow_run_report_', ('.txt', '.json'))
    if path:
        return (True, '', path)
    if msg:
        return (False, msg, None)
    return (False, 'No Shadow Health reports found yet.', None)

@_with_cloud_readiness_globals
def open_phase_f_evidence_index(repo_root):
    lab_root = resolve_lab_root(repo_root)
    reports_dir = os.path.join(lab_root, 'reports')
    path, msg = _find_latest_by_prefix(reports_dir, 'shadow_evidence_index_', ('.json',))
    if path:
        return (True, '', path)
    if msg:
        return (False, msg, None)
    return (False, 'No Phase F evidence indexes found.', None)

@_with_cloud_readiness_globals
def run_phase_f_manual(repo_root, python_exe, env, pipeline_running=None):
    """
    Rebuild Phase F (latest-at-execution). Does not pass --pipeline-run-id.
    Returns (ok, msg, pipeline_running).
    """
    ok_script, script_msg, script_repo_root, script, _ = _resolve_unified_model_script(
        repo_root, python_exe, 'package_shadow_run_report.py'
    )
    if not ok_script:
        return (False, script_msg, None)
    try:
        def _env_flag(name, default):
            raw = env.get(name)
            if raw is None:
                raw = os.environ.get(name)
            if raw is None:
                return default
            return str(raw).strip().lower() in ('1', 'true', 'yes', 'on', 'y')

        ready_ok, ready_msg, _ = ensure_lab_ready(repo_root, python_exe, env, _env_flag)
        if not ready_ok:
            return (False, ready_msg or 'Phase A bootstrap failed.', None)

        lab_root = resolve_lab_root(repo_root)
        if pipeline_running is None:
            pipeline_running = is_pipeline_running(lab_root)
        proc_env = os.environ.copy()
        proc_env['MEDICAFE_LAB_DIR'] = lab_root
        cmd = [python_exe, script, '--auto-report', '0']
        attempt_id = _new_diagnostic_attempt_id('phase_f_manual')
        ok_launch, msg_launch, _meta_launch = _launch_tracked_diagnostic_async(
            repo_root,
            python_exe,
            proc_env,
            lab_root,
            'phase_f_manual',
            attempt_id,
            script_repo_root,
            cmd,
            child_env_lab_root=lab_root,
        )
        if not ok_launch:
            return (False, msg_launch, None)
        return (True, '', pipeline_running)
    except Exception as e:
        return (False, str(e), None)

@_with_cloud_readiness_globals
def run_phase_f_manual_for_run_id(repo_root, python_exe, env, run_id):
    """
    Rebuild Phase F for explicit run_id (strict). Always passes --pipeline-run-id.
    Does NOT read state. Returns (ok, msg, None).
    """
    ok_script, script_msg, script_repo_root, script, _ = _resolve_unified_model_script(
        repo_root, python_exe, 'package_shadow_run_report.py'
    )
    if not ok_script:
        return (False, script_msg, None)
    run_id = (run_id or '').strip()
    if not run_id:
        return (False, 'run_id is required.', None)
    try:
        def _env_flag(name, default):
            raw = env.get(name)
            if raw is None:
                raw = os.environ.get(name)
            if raw is None:
                return default
            return str(raw).strip().lower() in ('1', 'true', 'yes', 'on', 'y')

        ready_ok, ready_msg, _ = ensure_lab_ready(repo_root, python_exe, env, _env_flag)
        if not ready_ok:
            return (False, ready_msg or 'Phase A bootstrap failed.', None)

        lab_root = resolve_lab_root(repo_root)
        proc_env = os.environ.copy()
        proc_env['MEDICAFE_LAB_DIR'] = lab_root
        cmd = [python_exe, script, '--pipeline-run-id', run_id, '--auto-report', '0']
        attempt_id = _new_diagnostic_attempt_id('phase_f_manual_for_run_id')
        ok_launch, msg_launch, _meta_launch = _launch_tracked_diagnostic_async(
            repo_root,
            python_exe,
            proc_env,
            lab_root,
            'phase_f_manual_for_run_id',
            attempt_id,
            script_repo_root,
            cmd,
            target_anchor_run_id=run_id,
            target_context_run_id=run_id,
            child_env_lab_root=lab_root,
        )
        if not ok_launch:
            return (False, msg_launch, None)
        return (True, '', None)
    except Exception as e:
        return (False, str(e), None)

@_with_cloud_readiness_globals
def send_phase_f_evidence(repo_root):
    lab_root = resolve_lab_root(repo_root)
    no_attach_msg = 'No Shadow Health report/evidence files found to attach.'
    if collect_support_bundle is None or submit_support_bundle_email is None:
        return (False, 'Support bundle tools unavailable.', None)
    reports_err = _reports_dir_access_error(lab_root)
    if reports_err:
        return (False, reports_err, None)
    phase_files = _select_latest_evidence_files(lab_root, [
        ('shadow_run_report_', None),
        ('shadow_evidence_index_', '.json'),
        ('phase_f_mismatch_', '.txt'),
    ])
    if not phase_files:
        reports_dir = os.path.join(lab_root, 'reports')
        mismatch_path, _ = _find_latest_by_prefix(reports_dir, 'phase_f_mismatch_', ('.txt',))
        if mismatch_path:
            basename = os.path.basename(mismatch_path)
            phase_files = [(basename, mismatch_path)]
    if not phase_files:
        return (False, no_attach_msg, None)
    send_run_id = ''
    for _basename, _fullpath in phase_files:
        if str(_basename).startswith('shadow_run_report_'):
            send_run_id = _shadow_run_report_run_id_from_path(_fullpath)
            if send_run_id:
                break
    if not send_run_id:
        try:
            state = _load_json_dict(os.path.join(lab_root, 'diagnostics_state.json'))
            send_run_id = str(state.get('last_shadow_pipeline_run_id', '') or '').strip()
        except Exception:
            send_run_id = ''
    phase_c_rid = ''
    failed_ph = ''
    try:
        st = _load_json_dict(os.path.join(lab_root, 'diagnostics_state.json'))
        failed_ph = str(st.get('last_shadow_pipeline_failed_phase', '') or '').strip().upper()
        phase_c_rid = str(st.get('last_phase_c_run_id', '') or '').strip()
        phase_ids = st.get('last_shadow_pipeline_phase_run_ids')
        if isinstance(phase_ids, dict) and not phase_c_rid:
            phase_c_rid = str(phase_ids.get('C', '') or '').strip()
    except Exception:
        failed_ph = ''
    jpath = ''
    tpath = ''
    ipath = ''
    for _bn, _pth in phase_files:
        b = str(_bn)
        if b.startswith('shadow_run_report_') and b.endswith('.json'):
            jpath = _pth
        elif b.startswith('shadow_run_report_') and b.endswith('.txt'):
            tpath = _pth
        elif b.startswith('shadow_evidence_index_') and b.endswith('.json'):
            ipath = _pth
    corr_lines = [
        'manual_phase_f_evidence_correlation',
        'shadow_run_id={0}'.format(send_run_id or '-'),
        'failed_phase={0}'.format(failed_ph or '-'),
        'phase_c_run_id={0}'.format(phase_c_rid or '-'),
    ]
    if send_run_id and phase_c_rid and send_run_id != phase_c_rid:
        corr_lines.append('note=Phase F anchor differs from Phase C run id')
    manual_corr = ('phase_f_manual_correlation_note.txt', '\n'.join(corr_lines) + '\n')
    extra_meta = {
        'phase_f_evidence': True,
        'run_id': send_run_id,
        'send_source': 'manual_phase_f_evidence',
        'lab_root': lab_root,
    }
    manifest_for_zip = None
    extra_files = [manual_corr]
    try:
        from MediCafe import evidence_manifest as _em_manifest

        _req = _em_manifest.build_evidence_request(
            'phase_f_evidence',
            'manual_phase_f_evidence',
            lab_root,
            anchor_run_id=send_run_id,
            active_run_id=send_run_id,
            failed_phase=failed_ph,
            phase_f_report_json_path=jpath,
            phase_f_report_txt_path=tpath,
            phase_f_evidence_index_path=ipath,
            _prefetched_evidence_tuples=list(phase_files),
        )
        manifest_for_zip = _em_manifest.resolve_evidence_manifest(_req)
        for _k, _v in _em_manifest.manifest_to_extra_meta(manifest_for_zip).items():
            extra_meta[_k] = _v
    except Exception:
        manifest_for_zip = None
    if manifest_for_zip is None:
        extra_files = list(phase_files)
        for ctx_name in ('diagnostics_state.json', 'run_cursor.json'):
            ctx_path = os.path.join(lab_root, ctx_name)
            if os.path.isfile(ctx_path):
                extra_files.append((ctx_name, ctx_path))
        try:
            st = _load_json_dict(os.path.join(lab_root, 'diagnostics_state.json'))
            failed_ph = str(st.get('last_shadow_pipeline_failed_phase', '') or '').strip().upper()
            phase_c_rid = str(st.get('last_phase_c_run_id', '') or '').strip()
            phase_ids = st.get('last_shadow_pipeline_phase_run_ids')
            if isinstance(phase_ids, dict) and not phase_c_rid:
                phase_c_rid = str(phase_ids.get('C', '') or '').strip()
            if failed_ph == 'C' and phase_c_rid:
                cpath = os.path.join(lab_root, 'reports', 'ingest_write_summary_{0}.json'.format(phase_c_rid))
                if os.path.isfile(cpath):
                    extra_files.append((os.path.basename(cpath), cpath))
        except Exception:
            pass
        try:
            from scripts.unified_model.lab_lock import read_lab_lock_diagnostic_metadata as _lab_lock_diag
            _stub = _lab_lock_diag(lab_root)
            if isinstance(_stub, dict) and _stub:
                extra_files.append(('shadow_lock_redacted.json', _stub))
        except Exception:
            pass
        extra_files.append(manual_corr)
    try:
        delivery_preflight = _collect_delivery_diagnostics()
        extra_meta['email_delivery_preflight'] = delivery_preflight
        zip_path = collect_support_bundle(
            include_traceback=False,
            extra_meta=extra_meta,
            extra_files=extra_files,
            evidence_manifest=manifest_for_zip,
        )
        if not zip_path:
            return (False, 'Failed to create support bundle.', None)
        ok, msg, _ = _submit_bundle_with_delivery_diagnostics(
            zip_path=zip_path,
            allow_interactive_reauth=True,
        )
        return (ok, msg, None)
    except Exception as e:
        return (False, 'Error: {0}'.format(e), None)

@_with_cloud_readiness_globals
def open_report_delivery_status(repo_root):
    """
    Write and return a compact delivery-status snapshot for support bundle sends.
    Returns (ok, message, path).
    """
    lab_root = resolve_lab_root(repo_root)
    reports_dir = os.path.join(lab_root, 'reports')
    try:
        if reports_dir and not os.path.exists(reports_dir):
            os.makedirs(reports_dir, exist_ok=True)
        path = os.path.join(reports_dir, 'report_delivery_status.txt')
        lines = get_report_delivery_status_lines(lab_root)
        with open(path, 'w', encoding='utf-8') as f:
            f.write('\n'.join(lines) + '\n')
        return (True, '', path)
    except Exception as e:
        return (False, str(e), None)

@_with_cloud_readiness_globals
def run_migration_health_audit(
        repo_root,
        python_exe,
        env,
        scope='both',
        write_report=False,
        cloud_required=False,
        migration_stage='xp_validation'):
    """Run audit_migration_health synchronously and return parsed summary payload.

    Returns (ok, msg, data) where data includes parsed payload + operator hints.
    """
    script_info = _audit_script_path(repo_root, python_exe=python_exe)
    if not script_info.get('ok'):
        return (False, script_info.get('message') or 'audit_migration_health.py not found.', None)
    script = script_info.get('path')
    try:
        lab_root = resolve_lab_root(repo_root)
        proc_env = os.environ.copy()
        proc_env['MEDICAFE_LAB_DIR'] = lab_root
        if env and isinstance(env, dict):
            for k in ('GOOGLE_CLOUD_PROJECT', 'MEDICAFE_HEALTH_URL'):
                if env.get(k):
                    proc_env[k] = str(env.get(k))

        stage = str(migration_stage or 'xp_validation').strip().lower() or 'xp_validation'
        cmd = [
            python_exe,
            script,
            '--scope',
            scope,
            '--migration-stage',
            stage,
            '--json',
            '--no-text',
            '--output-mode',
            'write' if write_report else 'stdout',
        ]
        if cloud_required:
            cmd.append('--cloud-required')
        p = subprocess.Popen(cmd, cwd=script_info.get('cwd') or repo_root, env=proc_env, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        out_b, err_b = p.communicate()
        out = out_b.decode('utf-8', 'replace') if hasattr(out_b, 'decode') else str(out_b)
        err = err_b.decode('utf-8', 'replace') if hasattr(err_b, 'decode') else str(err_b)
        payload = _extract_json_object_from_text(out)
        if not payload:
            return (False, 'Audit did not return parseable JSON. {0}'.format(err.strip() or 'No stderr.'), None)
        hints = _audit_hint_lines_from_payload(payload)
        data = {'payload': payload, 'hints': hints, 'stdout': out, 'stderr': err, 'returncode': int(p.returncode)}
        msg = 'Audit completed with status={0}, score={1}, exit_code={2}'.format(
            payload.get('overall', {}).get('status', '?'),
            payload.get('overall', {}).get('score', '?'),
            payload.get('overall', {}).get('exit_code', p.returncode),
        )
        return (True, msg, data)
    except Exception as e:
        return (False, str(e), None)

@_with_cloud_readiness_globals
def open_latest_migration_health_report(repo_root):
    """Open latest audit_migration_health summary report (txt preferred, then json)."""
    lab_root = resolve_lab_root(repo_root)
    reports_dir = os.path.join(lab_root, 'reports')
    path, msg = _find_latest_by_prefix(reports_dir, 'audit_migration_health_summary_', ('.txt', '.json'))
    if path:
        return (True, '', path)
    if msg:
        return (False, msg, None)
    return (False, 'No migration health audit summaries found. Run an audit first.', None)
_IMPL__find_latest_run_id_by_prefix = _find_latest_run_id_by_prefix
_IMPL__select_latest_evidence_files = _select_latest_evidence_files
_IMPL__send_phase_evidence = _send_phase_evidence
_IMPL_run_pipeline = run_pipeline
_IMPL_open_phase_b_summary = open_phase_b_summary
_IMPL_open_manifest_location = open_manifest_location
_IMPL_run_phase_b_manual = run_phase_b_manual
_IMPL_send_phase_b_evidence = send_phase_b_evidence
_IMPL_open_phase_c_summary = open_phase_c_summary
_IMPL_run_phase_c_manual = run_phase_c_manual
_IMPL_send_phase_c_evidence = send_phase_c_evidence
_IMPL_open_phase_d_summary = open_phase_d_summary
_IMPL_open_phase_d_reject_sample = open_phase_d_reject_sample
_IMPL_run_phase_d_manual = run_phase_d_manual
_IMPL_run_phase_d_dat_smoke = run_phase_d_dat_smoke
_IMPL_preview_historical_phase_d_reprocess = preview_historical_phase_d_reprocess
_IMPL_run_historical_phase_d_reprocess = run_historical_phase_d_reprocess
_IMPL_send_phase_d_evidence = send_phase_d_evidence
_IMPL_open_phase_e_summary = open_phase_e_summary
_IMPL_open_phase_e_deviation_samples = open_phase_e_deviation_samples
_IMPL_run_phase_e_manual = run_phase_e_manual
_IMPL_send_phase_e_evidence = send_phase_e_evidence
_IMPL_run_shadow_pipeline = run_shadow_pipeline
_IMPL_open_phase_f_shadow_report = open_phase_f_shadow_report
_IMPL_open_phase_f_evidence_index = open_phase_f_evidence_index
_IMPL_run_phase_f_manual = run_phase_f_manual
_IMPL_run_phase_f_manual_for_run_id = run_phase_f_manual_for_run_id
_IMPL_send_phase_f_evidence = send_phase_f_evidence
_IMPL_open_report_delivery_status = open_report_delivery_status
_IMPL_run_migration_health_audit = run_migration_health_audit
_IMPL_open_latest_migration_health_report = open_latest_migration_health_report
