#!/usr/bin/env python
"""
Shared diagnostic attempt lifecycle records.

This module is intentionally stdlib-only and Python 3.4 compatible.  It writes
attempt JSON under lab/reports so tests, runbooks, probes, and support bundles
can share one small contract for "we tried this diagnostic, and here is what
actually happened".
"""
from __future__ import print_function

import calendar
import json
import os
import random
import re
import time


DIAGNOSTIC_ATTEMPT_SCHEMA_VERSION = 1
_ATTEMPT_STATUS_OPEN = ("started", "running")
_SAFE_TOKEN_RE = re.compile(r"[^A-Za-z0-9_.-]+")
_TAIL_LIMIT = 8000


def utc_now():
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def _safe_str(value):
    return str(value or "").strip()


def safe_filename_token(value, fallback):
    token = _SAFE_TOKEN_RE.sub("_", _safe_str(value))
    token = token.strip("._-")
    if not token:
        token = _safe_str(fallback)
    if not token:
        token = "unknown"
    return token[:120]


def _reports_dir(lab_root):
    return os.path.join(_safe_str(lab_root), "reports")


def _kind_token(diagnostic_kind):
    return safe_filename_token(diagnostic_kind, "diagnostic")


def generate_attempt_id():
    return safe_filename_token(
        "{0}_{1}_{2}".format(
            time.strftime("%Y%m%dT%H%M%SZ", time.gmtime()),
            os.getpid(),
            random.randint(1000, 9999),
        ),
        "attempt",
    )


def attempt_path(lab_root, diagnostic_kind, attempt_id):
    filename = "diagnostic_attempt_{0}_{1}.json".format(
        _kind_token(diagnostic_kind),
        safe_filename_token(attempt_id, "attempt"),
    )
    return os.path.join(_reports_dir(lab_root), filename)


def latest_attempt_path(lab_root, diagnostic_kind):
    filename = "diagnostic_attempt_{0}_latest.json".format(_kind_token(diagnostic_kind))
    return os.path.join(_reports_dir(lab_root), filename)


def _coerce_list(value):
    if value is None:
        return []
    if isinstance(value, (list, tuple)):
        return list(value)
    return [value]


def _tail(value, limit):
    text = _safe_str(value)
    if not text:
        return ""
    limit = int(limit or _TAIL_LIMIT)
    if len(text) <= limit:
        return text
    return text[-limit:]


def _coerce_bool(value):
    return bool(value)


def _coerce_int_or_none(value):
    if value is None or value == "":
        return None
    try:
        return int(value)
    except Exception:
        return None


def _iso_to_epoch(value):
    text = _safe_str(value)
    if not text:
        return None
    try:
        return calendar.timegm(time.strptime(text, "%Y-%m-%dT%H:%M:%SZ"))
    except Exception:
        return None


def read_json_file(path, default=None):
    if default is None:
        default = {}
    if not path or not os.path.isfile(path):
        return default
    try:
        with open(path, "r", encoding="utf-8") as handle:
            doc = json.load(handle)
        if isinstance(doc, dict):
            return doc
    except Exception:
        pass
    return default


def _safe_rename(tmp_path, dest_path):
    try:
        if os.path.isfile(dest_path):
            os.remove(dest_path)
    except Exception:
        pass
    os.rename(tmp_path, dest_path)


def _fallback_write_json(path, payload):
    parent = os.path.dirname(path)
    if parent and not os.path.isdir(parent):
        os.makedirs(parent)
    tmp = "{0}.tmp.{1}.{2}".format(path, os.getpid(), random.randint(1000, 9999))
    try:
        with open(tmp, "w", encoding="utf-8") as handle:
            json.dump(payload, handle, ensure_ascii=False, indent=2, sort_keys=True)
            handle.write("\n")
            try:
                handle.flush()
                os.fsync(handle.fileno())
            except Exception:
                pass
        _safe_rename(tmp, path)
        return True
    except Exception:
        try:
            if os.path.isfile(tmp):
                os.remove(tmp)
        except Exception:
            pass
    return False


def write_json_file(path, payload):
    parent = os.path.dirname(path)
    if parent and not os.path.isdir(parent):
        try:
            os.makedirs(parent)
        except Exception:
            pass
    try:
        from MediCafe.json_io import write_json_atomic
    except Exception:
        write_json_atomic = None
    if write_json_atomic is not None:
        try:
            ok = write_json_atomic(
                path,
                payload,
                "diagnostic_attempt",
                "diagnostic_attempts",
                indent=2,
                sort_keys=True,
                lock=True,
                ensure_ascii=False,
            )
            if ok:
                return True
        except Exception:
            pass
    return _fallback_write_json(path, payload)


def read_attempt(lab_root, diagnostic_kind, attempt_id=None):
    if attempt_id:
        path = attempt_path(lab_root, diagnostic_kind, attempt_id)
    else:
        path = latest_attempt_path(lab_root, diagnostic_kind)
    return read_json_file(path, {})


def write_attempt(lab_root, attempt_doc):
    diagnostic_kind = attempt_doc.get("diagnostic_kind")
    attempt_id = attempt_doc.get("attempt_id")
    if not diagnostic_kind or not attempt_id:
        return False
    main_path = attempt_path(lab_root, diagnostic_kind, attempt_id)
    latest_path = latest_attempt_path(lab_root, diagnostic_kind)
    ok_main = write_json_file(main_path, attempt_doc)
    ok_latest = write_json_file(latest_path, attempt_doc)
    return bool(ok_main and ok_latest)


def _base_attempt_doc(diagnostic_kind, attempt_id, target_anchor_run_id,
                      target_context_run_id, issue_code, expected_artifacts,
                      fail_closed, now_utc):
    return {
        "schema_version": DIAGNOSTIC_ATTEMPT_SCHEMA_VERSION,
        "diagnostic_kind": _safe_str(diagnostic_kind),
        "attempt_id": _safe_str(attempt_id),
        "target_anchor_run_id": _safe_str(target_anchor_run_id),
        "target_context_run_id": _safe_str(target_context_run_id),
        "issue_code": _safe_str(issue_code),
        "status": "started",
        "started_at_utc": _safe_str(now_utc),
        "finished_at_utc": "",
        "child_pid": None,
        "script_path": "",
        "cwd": "",
        "returncode": None,
        "stdout_tail": "",
        "stderr_tail": "",
        "expected_artifacts": _coerce_list(expected_artifacts),
        "resolved_artifacts": [],
        "accepted_for_anchor": False,
        "fail_closed": _coerce_bool(fail_closed),
        "primary_report_path": "",
        "domain_status": "",
        "domain_detail": "",
    }


def begin_attempt(lab_root, diagnostic_kind, target_anchor_run_id="",
                  target_context_run_id="", issue_code="", attempt_id=None,
                  expected_artifacts=None, fail_closed=False, now_utc=None):
    if not attempt_id:
        attempt_id = generate_attempt_id()
    doc = _base_attempt_doc(
        diagnostic_kind,
        safe_filename_token(attempt_id, "attempt"),
        target_anchor_run_id,
        target_context_run_id,
        issue_code,
        expected_artifacts,
        fail_closed,
        now_utc or utc_now(),
    )
    write_attempt(lab_root, doc)
    return doc


def _load_for_update(lab_root, diagnostic_kind, attempt_id):
    doc = read_attempt(lab_root, diagnostic_kind, attempt_id)
    if not doc:
        doc = _base_attempt_doc(
            diagnostic_kind,
            safe_filename_token(attempt_id, "attempt"),
            "",
            "",
            "",
            [],
            False,
            utc_now(),
        )
    return doc


def mark_spawned(lab_root, diagnostic_kind, attempt_id, child_pid=None,
                 script_path="", cwd=""):
    doc = _load_for_update(lab_root, diagnostic_kind, attempt_id)
    doc["status"] = "running"
    doc["child_pid"] = _coerce_int_or_none(child_pid)
    if script_path is not None:
        doc["script_path"] = _safe_str(script_path)
    if cwd is not None:
        doc["cwd"] = _safe_str(cwd)
    write_attempt(lab_root, doc)
    return doc


def finish_attempt(lab_root, diagnostic_kind, attempt_id, returncode=0,
                   stdout_tail="", stderr_tail="", resolved_artifacts=None,
                   accepted_for_anchor=True, primary_report_path="",
                   domain_status="", domain_detail="", finished_at_utc=None):
    doc = _load_for_update(lab_root, diagnostic_kind, attempt_id)
    doc["status"] = "succeeded"
    doc["finished_at_utc"] = finished_at_utc or utc_now()
    doc["returncode"] = _coerce_int_or_none(returncode)
    doc["stdout_tail"] = _tail(stdout_tail, _TAIL_LIMIT)
    doc["stderr_tail"] = _tail(stderr_tail, _TAIL_LIMIT)
    doc["resolved_artifacts"] = _coerce_list(resolved_artifacts)
    doc["accepted_for_anchor"] = _coerce_bool(accepted_for_anchor)
    doc["fail_closed"] = False
    doc["primary_report_path"] = _safe_str(primary_report_path)
    if domain_status is not None:
        doc["domain_status"] = _safe_str(domain_status)
    if domain_detail is not None:
        doc["domain_detail"] = _safe_str(domain_detail)
    write_attempt(lab_root, doc)
    return doc


def fail_attempt(lab_root, diagnostic_kind, attempt_id, returncode=None,
                 stdout_tail="", stderr_tail="", resolved_artifacts=None,
                 primary_report_path="", domain_status="", domain_detail="",
                 fail_closed=True, finished_at_utc=None):
    doc = _load_for_update(lab_root, diagnostic_kind, attempt_id)
    doc["status"] = "failed"
    doc["finished_at_utc"] = finished_at_utc or utc_now()
    doc["returncode"] = _coerce_int_or_none(returncode)
    doc["stdout_tail"] = _tail(stdout_tail, _TAIL_LIMIT)
    doc["stderr_tail"] = _tail(stderr_tail, _TAIL_LIMIT)
    doc["resolved_artifacts"] = _coerce_list(resolved_artifacts)
    doc["accepted_for_anchor"] = False
    doc["fail_closed"] = _coerce_bool(fail_closed)
    doc["primary_report_path"] = _safe_str(primary_report_path)
    if domain_status is not None:
        doc["domain_status"] = _safe_str(domain_status)
    if domain_detail is not None:
        doc["domain_detail"] = _safe_str(domain_detail)
    write_attempt(lab_root, doc)
    return doc


def reconcile_attempt(lab_root, diagnostic_kind, attempt_id=None,
                      stale_after_sec=3600, now_epoch=None,
                      finished_at_utc=None):
    doc = read_attempt(lab_root, diagnostic_kind, attempt_id)
    if not doc:
        return {}
    status = _safe_str(doc.get("status"))
    if status not in _ATTEMPT_STATUS_OPEN:
        return doc
    started_epoch = _iso_to_epoch(doc.get("started_at_utc"))
    if started_epoch is None:
        started_epoch = 0
    if now_epoch is None:
        now_epoch = time.time()
    stale_after_sec = int(stale_after_sec or 0)
    if (float(now_epoch) - float(started_epoch)) < stale_after_sec:
        return doc
    doc["status"] = "timeout"
    doc["finished_at_utc"] = finished_at_utc or utc_now()
    doc["accepted_for_anchor"] = False
    doc["fail_closed"] = True
    if not doc.get("domain_status"):
        doc["domain_status"] = "timeout"
    if not doc.get("domain_detail"):
        doc["domain_detail"] = "diagnostic attempt exceeded stale_after_sec={0}".format(stale_after_sec)
    write_attempt(lab_root, doc)
    return doc


def _matches_collect_filter(doc, diagnostic_kind, anchor_run_id, context_run_id):
    if diagnostic_kind and _safe_str(doc.get("diagnostic_kind")) != _safe_str(diagnostic_kind):
        return False
    if anchor_run_id and _safe_str(doc.get("target_anchor_run_id")) != _safe_str(anchor_run_id):
        return False
    if context_run_id and _safe_str(doc.get("target_context_run_id")) != _safe_str(context_run_id):
        return False
    return True


def collect_bundle_attempt_files(lab_root, diagnostic_kind=None, anchor_run_id=None,
                                 context_run_id=None, include_latest=True):
    reports = _reports_dir(lab_root)
    if not os.path.isdir(reports):
        return []
    paths = []
    seen = {}
    try:
        names = os.listdir(reports)
    except Exception:
        return []
    for name in names:
        if not name.startswith("diagnostic_attempt_") or not name.endswith(".json"):
            continue
        if not include_latest and name.endswith("_latest.json"):
            continue
        path = os.path.join(reports, name)
        doc = read_json_file(path, {})
        if not _matches_collect_filter(doc, diagnostic_kind, anchor_run_id, context_run_id):
            continue
        if path not in seen:
            seen[path] = True
            paths.append(path)
    paths.sort()
    return paths
