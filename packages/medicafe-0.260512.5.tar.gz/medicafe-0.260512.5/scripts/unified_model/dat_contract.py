#!/usr/bin/env python
"""
Shared DAT field/provenance resolution used by parse, QA, join alignment,
canonical extraction, and Phase D decision logging.
XP-compatible: Python 3.4.4, stdlib only.
"""
from __future__ import print_function

try:
    from patient_field_mapper import normalize_external_patient_id
except ImportError:
    normalize_external_patient_id = None

try:
    from dat_payer_resolution import (
        DAT_PAYER_RESOLUTION_DIAG_UNRESOLVED,
        DAT_PAYER_RESOLUTION_SOURCE_EXISTING,
        DAT_PAYER_RESOLUTION_STATUS_MISSING,
        DAT_PAYER_RESOLUTION_STATUS_RESOLVED,
        resolve_payer_id_from_iname,
    )
except ImportError:
    DAT_PAYER_RESOLUTION_DIAG_UNRESOLVED = "insurance_name_present_but_not_payer_anchor"
    DAT_PAYER_RESOLUTION_SOURCE_EXISTING = "existing_payer_anchor"
    DAT_PAYER_RESOLUTION_STATUS_MISSING = "missing"
    DAT_PAYER_RESOLUTION_STATUS_RESOLVED = "resolved"
    resolve_payer_id_from_iname = None


_NORMALIZED_FIELD_KEYS = (
    "chart_number",
    "patient_id",
    "first_name",
    "last_name",
    "patient_name",
    "date_of_service",
    "payer_id",
    "insurance_name",
    "member_id",
    "dat_payer_resolution_status",
    "dat_payer_resolution_source",
    "dat_payer_resolution_diagnostic",
    "dat_payer_resolution_insurance_id",
    "dat_payer_resolution_insurance_name_key",
    "dat_payer_resolution_candidate_payer_ids",
)

_DAT_PAYER_ANCHOR_KEYS = ("payer_id", "PAYERID", "INSID", "insurance_id")
_DAT_INSURANCE_NAME_KEYS = ("insurance_name", "INAME")


def _to_text(value):
    if value is None:
        return ""
    return str(value).strip()


def _first_text(mapping, keys):
    if not isinstance(mapping, dict):
        return ""
    for key in keys:
        value = _to_text(mapping.get(key))
        if value:
            return value
    return ""


def _normalize_patient_id_boundary(value, source):
    text = _to_text(value)
    if normalize_external_patient_id is None:
        return text
    diag = normalize_external_patient_id(value, source)
    if diag.get("is_valid"):
        return diag.get("value") or ""
    return text


def _first_text_with_source(mapping, keys):
    if not isinstance(mapping, dict):
        return "", ""
    for key in keys:
        value = _to_text(mapping.get(key))
        if value:
            return value, key
    return "", ""


def _empty_payer_resolution(status, source, diagnostic):
    return {
        "status": status,
        "source": source,
        "diagnostic": diagnostic,
        "insurance_id": "",
        "insurance_name_key": "",
        "candidate_payer_ids_text": "",
        "candidate_payer_ids": [],
    }


def _stored_payer_resolution(record, fallback_status, fallback_source, fallback_diagnostic):
    resolution = _empty_payer_resolution(fallback_status, fallback_source, fallback_diagnostic)
    if not isinstance(record, dict):
        return resolution
    stored_status = _to_text(record.get("dat_payer_resolution_status"))
    stored_source = _to_text(record.get("dat_payer_resolution_source"))
    stored_diagnostic = _to_text(record.get("dat_payer_resolution_diagnostic"))
    stored_insurance_id = _to_text(record.get("dat_payer_resolution_insurance_id"))
    stored_name_key = _to_text(record.get("dat_payer_resolution_insurance_name_key"))
    stored_candidates = _to_text(record.get("dat_payer_resolution_candidate_payer_ids"))
    if stored_status:
        resolution["status"] = stored_status
    if stored_source:
        resolution["source"] = stored_source
    if stored_diagnostic:
        resolution["diagnostic"] = stored_diagnostic
    if stored_insurance_id:
        resolution["insurance_id"] = stored_insurance_id
    if stored_name_key:
        resolution["insurance_name_key"] = stored_name_key
    if stored_candidates:
        resolution["candidate_payer_ids_text"] = stored_candidates
        resolution["candidate_payer_ids"] = stored_candidates.split(",")
    return resolution


def resolve_dat_payer_anchor(record, provenance=None, payer_resolution_context=None):
    """
    Resolve the DAT payer anchor and diagnostic-only insurance name.

    INAME/insurance_name is intentionally not a payer anchor. It is retained only
    for diagnostics so Medisoft rows with an insurance display name but no payer
    identifier still fail the payer-anchor contract.
    """
    record = record if isinstance(record, dict) else {}
    provenance = provenance if isinstance(provenance, dict) else {}
    payer_id, payer_source = _first_text_with_source(record, _DAT_PAYER_ANCHOR_KEYS)
    insurance_name, insurance_source = _first_text_with_source(record, _DAT_INSURANCE_NAME_KEYS)
    resolution = _empty_payer_resolution(
        DAT_PAYER_RESOLUTION_STATUS_MISSING,
        "",
        "",
    )
    if payer_id:
        status = DAT_PAYER_RESOLUTION_STATUS_RESOLVED
        resolution = _stored_payer_resolution(
            record,
            DAT_PAYER_RESOLUTION_STATUS_RESOLVED,
            DAT_PAYER_RESOLUTION_SOURCE_EXISTING,
            "",
        )
    elif insurance_name and resolve_payer_id_from_iname is not None:
        resolution = resolve_payer_id_from_iname(
            insurance_name,
            resolution_context=payer_resolution_context,
        )
        payer_id = resolution.get("payer_id") or ""
        payer_source = resolution.get("source") or ""
        status = resolution.get("status") or DAT_PAYER_RESOLUTION_STATUS_MISSING
    else:
        status = DAT_PAYER_RESOLUTION_STATUS_MISSING
    diagnostic = ""
    if not payer_id and insurance_name:
        diagnostic = resolution.get("diagnostic") or DAT_PAYER_RESOLUTION_DIAG_UNRESOLVED
    return {
        "payer_id": payer_id,
        "payer_anchor_source": payer_source,
        "payer_anchor_status": status,
        "payer_anchor_keys": ",".join(_DAT_PAYER_ANCHOR_KEYS),
        "insurance_name": insurance_name,
        "insurance_name_source": insurance_source,
        "insurance_name_diagnostic_only": bool(insurance_name),
        "payer_anchor_diagnostic": diagnostic,
        "dat_payer_resolution_status": resolution.get("status") or status,
        "dat_payer_resolution_source": resolution.get("source") or payer_source,
        "dat_payer_resolution_diagnostic": diagnostic,
        "dat_payer_resolution_insurance_id": resolution.get("insurance_id") or "",
        "dat_payer_resolution_insurance_name_key": resolution.get("insurance_name_key") or "",
        "dat_payer_resolution_candidate_payer_ids": resolution.get("candidate_payer_ids_text") or "",
        "source_ref": _first_text(provenance, ("source_ref",)) or _first_text(record, ("source_ref",)),
    }


def _to_int_or_none(value):
    if value is None:
        return None
    text = _to_text(value)
    if not text:
        return None
    try:
        return int(text)
    except (TypeError, ValueError):
        return None


def resolve_dat_fields(record, provenance=None, payer_resolution_context=None):
    """
    Resolve DAT join/contract fields plus row provenance from mixed legacy aliases.
    Returns a dict with normalized field names and available provenance keys.
    """
    record = record if isinstance(record, dict) else {}
    provenance = provenance if isinstance(provenance, dict) else {}

    chart_number = _first_text(record, ("chart_number", "CHART", "patient_chart"))
    patient_id = _normalize_patient_id_boundary(
        _first_text(record, ("patient_id", "PATID", "patid")),
        "dat_record.patient_id",
    )
    first_name = _first_text(record, ("first_name", "FIRST", "FIRSTNAME"))
    last_name = _first_text(record, ("last_name", "LAST", "LASTNAME"))
    patient_name = _first_text(record, ("patient_name", "PATNAME"))
    if not patient_name:
        patient_name = _to_text((first_name + " " + last_name).strip())
    # Alias ladder note: keep existing precedence stable.
    # `DATE` is the Medisoft fixed-width DAT service-date column (see
    # MediLink/MediLink_PatientProcessor.py and MediLink/MediLink_837p_encoder*.py which
    # treat parsed_data['DATE'] as surgery/service date). Placed after the pre-existing
    # CSV/DOCX-origin aliases so established precedence contracts (e.g.,
    # `test_v2_dat_precedence_prefers_extract_dat_join_identity_fields`) are preserved.
    date_of_service = _first_text(
        record,
        ("date_of_service", "DOS", "DATE1", "service_date", "DATE"),
    )
    payer_anchor = resolve_dat_payer_anchor(
        record,
        provenance=provenance,
        payer_resolution_context=payer_resolution_context,
    )
    payer_id = payer_anchor.get("payer_id") or ""
    insurance_name = payer_anchor.get("insurance_name") or ""
    member_id = _first_text(record, ("member_id", "MEMID"))
    if not member_id:
        member_id = patient_id

    return {
        "chart_number": chart_number,
        "patient_id": patient_id,
        "first_name": first_name,
        "last_name": last_name,
        "patient_name": patient_name,
        "date_of_service": date_of_service,
        "payer_id": payer_id,
        "insurance_name": insurance_name,
        "member_id": member_id,
        "source_ref": _first_text(provenance, ("source_ref",)) or _first_text(record, ("source_ref",)),
        "record_index": _to_int_or_none(
            provenance.get("record_index") if provenance.get("record_index") is not None else record.get("record_index")
        ),
        "attachment_sha256": (
            _first_text(provenance, ("attachment_sha256", "sha256"))
            or _first_text(record, ("attachment_sha256", "sha256"))
        ),
    }


def normalize_dat_record(record, provenance=None, payer_resolution_context=None):
    """
    Copy record and inject normalized DAT aliases.
    Provenance is accepted for interface symmetry but not written back into the row.
    """
    if not isinstance(record, dict):
        return {}
    normalized = dict(record)
    resolved = resolve_dat_fields(
        record,
        provenance=provenance,
        payer_resolution_context=payer_resolution_context,
    )
    payer_anchor = resolve_dat_payer_anchor(
        record,
        provenance=provenance,
        payer_resolution_context=payer_resolution_context,
    )
    for key in _NORMALIZED_FIELD_KEYS:
        if key in resolved:
            normalized[key] = resolved.get(key) or ""
        else:
            normalized[key] = payer_anchor.get(key) or ""
    return normalized


def build_dat_decision_context(record, provenance=None, payer_resolution_context=None):
    """Context bundle shared by extractor_skip and constraint_fail DAT evidence."""
    resolved = resolve_dat_fields(
        record,
        provenance=provenance,
        payer_resolution_context=payer_resolution_context,
    )
    payer_anchor = resolve_dat_payer_anchor(
        record,
        provenance=provenance,
        payer_resolution_context=payer_resolution_context,
    )
    patient_id = resolved.get("patient_id") or ""
    chart_number = resolved.get("chart_number") or ""
    patient_anchor_status = "resolved" if patient_id else "missing"
    patient_anchor_diagnostic = ""
    if not patient_id and chart_number:
        patient_anchor_diagnostic = "patid_required_chart_not_usable"
    context = {
        "source_ref": resolved.get("source_ref") or "",
        "record_index": resolved.get("record_index"),
        "attachment_sha256": resolved.get("attachment_sha256") or "",
        "resolved_patient_id": patient_id,
        "dat_patient_anchor_status": patient_anchor_status,
        "dat_patient_anchor_keys": "patient_id,PATID,patid",
        "dat_patient_anchor_diagnostic": patient_anchor_diagnostic,
        "resolved_date_of_service": resolved.get("date_of_service") or "",
        "resolved_payer_id": resolved.get("payer_id") or "",
        "resolved_payer_id_source": payer_anchor.get("payer_anchor_source") or "",
        "dat_payer_anchor_status": payer_anchor.get("payer_anchor_status") or "",
        "dat_payer_anchor_keys": payer_anchor.get("payer_anchor_keys") or "",
        "dat_payer_anchor_diagnostic": payer_anchor.get("payer_anchor_diagnostic") or "",
        "resolved_chart_number": chart_number,
        "chart_number_role": "supplemental_not_patient_anchor" if chart_number else "",
        "chart_anchor_usable": False,
        "resolved_insurance_name": resolved.get("insurance_name") or "",
        "resolved_insurance_name_source": payer_anchor.get("insurance_name_source") or "",
        "resolved_insurance_name_diagnostic_only": bool(payer_anchor.get("insurance_name_diagnostic_only")),
        "dat_payer_resolution_status": payer_anchor.get("dat_payer_resolution_status") or "",
        "dat_payer_resolution_source": payer_anchor.get("dat_payer_resolution_source") or "",
        "dat_payer_resolution_diagnostic": payer_anchor.get("dat_payer_resolution_diagnostic") or "",
        "dat_payer_resolution_insurance_id": payer_anchor.get("dat_payer_resolution_insurance_id") or "",
        "dat_payer_resolution_insurance_name_key": payer_anchor.get("dat_payer_resolution_insurance_name_key") or "",
        "dat_payer_resolution_candidate_payer_ids": payer_anchor.get("dat_payer_resolution_candidate_payer_ids") or "",
        "resolved_member_id": resolved.get("member_id") or "",
        "resolved_patient_name": resolved.get("patient_name") or "",
    }
    if context["record_index"] is None:
        context.pop("record_index")
    return context
