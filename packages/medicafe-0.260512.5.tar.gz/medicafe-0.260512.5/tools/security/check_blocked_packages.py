#!/usr/bin/env python3
"""Fail CI if known-compromised package versions are declared in this repo."""

from __future__ import annotations

import ast
import re
import sys
from pathlib import Path

BLOCKED = {
    "mistralai": {"2.4.6": "Mini Shai-Hulud campaign (PyPI compromise)"},
    "guardrails-ai": {"0.10.1": "Mini Shai-Hulud campaign (PyPI compromise)"},
    "@opensearch-project/opensearch": {
        "3.5.3": "Mini Shai-Hulud campaign (npm compromise)",
        "3.6.2": "Mini Shai-Hulud campaign (npm compromise)",
        "3.7.0": "Mini Shai-Hulud campaign (npm compromise)",
        "3.8.0": "Mini Shai-Hulud campaign (npm compromise)",
    },
}

REQ_FILES = [
    Path("requirements.txt"),
    Path("cloud/orchestrator/requirements.txt"),
    Path("tools/requirements.txt"),
]


def _normalize_name(raw: str) -> str:
    return raw.strip().lower().replace("_", "-")


def _parse_req_line(line: str):
    line = line.strip()
    if not line or line.startswith("#"):
        return None
    line = line.split(";", 1)[0].strip()
    # Inline comments (requirements files) and markers already stripped above via ";".
    if "#" in line:
        line = line.split("#", 1)[0].strip()
    if not line:
        return None
    # PEP 508 optional extras: package[extra,...]==version (must not bypass denylist).
    m = re.match(
        r"^([A-Za-z0-9_.\-@/]+)(?:\[[^\]]*\])?\s*([=~!<>]{1,2})\s*([^\s]+)$",
        line,
    )
    if not m:
        return None
    return _normalize_name(m.group(1)), m.group(2), m.group(3).strip()


def _scan_requirements():
    findings = []
    for path in REQ_FILES:
        if not path.exists():
            continue
        for lineno, line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
            parsed = _parse_req_line(line)
            if not parsed:
                continue
            name, op, version = parsed
            if op != "==":
                continue
            blocked_versions = BLOCKED.get(name)
            if blocked_versions and version in blocked_versions:
                findings.append((str(path), lineno, name, version, blocked_versions[version]))
    return findings


def _scan_setup_py():
    path = Path("setup.py")
    if not path.exists():
        return []
    text = path.read_text(encoding="utf-8")
    tree = ast.parse(text)
    findings = []
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        if not isinstance(node.func, ast.Name) or node.func.id != "setup":
            continue
        for kw in node.keywords:
            if kw.arg != "install_requires" or not isinstance(kw.value, (ast.List, ast.Tuple)):
                continue
            for elt in kw.value.elts:
                if not isinstance(elt, ast.Constant) or not isinstance(elt.value, str):
                    continue
                parsed = _parse_req_line(elt.value)
                if not parsed:
                    continue
                name, op, version = parsed
                if op != "==":
                    continue
                blocked_versions = BLOCKED.get(name)
                if blocked_versions and version in blocked_versions:
                    findings.append((str(path), getattr(elt, "lineno", 0), name, version, blocked_versions[version]))
    return findings


def main():
    findings = []
    findings.extend(_scan_requirements())
    findings.extend(_scan_setup_py())

    if findings:
        print("Detected blocked package versions:")
        for path, lineno, name, version, reason in findings:
            print("- {0}:{1} -> {2}=={3} ({4})".format(path, lineno, name, version, reason))
        return 1

    print("No blocked package versions found in dependency declarations.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
