#!/usr/bin/env python
from __future__ import print_function

import os
import sys

import pytest


_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)

from MediBot import MediBot_Preprocessor_lib as preprocessor_lib


def test_scrub_csv_header_token_strips_trademark_suffix_from_surgery_column():
    assert preprocessor_lib.scrub_csv_header_token("Surgery Date\u2122") == "Surgery Date"


def test_classify_after_scrub_detects_surgery_alias_on_claim_like_feed():
    raw = [
        "Claim",
        "Payer",
        "Status",
        "Patient",
        "Proc",
        "Surgery Date\u2122",
        "Allowed",
        "Paid",
        "Pt Resp",
        "Charged",
    ]
    assert preprocessor_lib.classify_csv_header_subtype(raw)["csv_subtype"] == "claim_payment_no_surgery_date"
    scrubbed = [preprocessor_lib.scrub_csv_header_token(h) for h in raw]
    sub = preprocessor_lib.classify_csv_header_subtype(scrubbed)
    assert sub.get("has_surgery_date_alias") is True
    assert sub.get("csv_subtype") == "surgery_schedule"


def test_clean_header_accepts_lowercase_dos_alias():
    cleaned = preprocessor_lib.clean_header(["category", "dos", "patient_id"])
    assert "Surgery Date" in cleaned
    assert "dos" not in cleaned


def test_clean_header_accepts_mixed_case_service_date_aliases():
    cleaned_with_spaces = preprocessor_lib.clean_header(["category", "date of service", "patient_id"])
    assert "Surgery Date" in cleaned_with_spaces
    assert "date of service" not in cleaned_with_spaces

    cleaned_with_underscore = preprocessor_lib.clean_header(["category", "SERVICE_DATE", "patient_id"])
    assert "Surgery Date" in cleaned_with_underscore
    assert "SERVICE_DATE" not in cleaned_with_underscore


def test_clean_header_raises_when_no_surgery_date_alias_exists():
    with pytest.raises(ValueError) as exc_info:
        preprocessor_lib.clean_header(["category", "patient_id", "next_action"])

    assert "CSV missing required surgery date header after cleaning." in str(exc_info.value)
    assert "csv_subtype=unknown_missing_surgery_date" in str(exc_info.value)


def test_classify_claim_payment_csv_does_not_treat_serv_as_surgery_date():
    classification = preprocessor_lib.classify_csv_header_subtype([
        "Claim", "Payer", "Status", "Patient", "Proc", "Serv",
        "Allowed", "Paid", "Pt Resp", "Charged"
    ])

    assert classification["csv_subtype"] == "claim_payment_no_surgery_date"
    assert classification["matched_family"] == "claim_payment"
    assert classification["service_like_headers"] == ["Serv"]
    assert classification["serv_alias_policy"] == "not_accepted_without_value_shape_validation"

    with pytest.raises(ValueError) as exc_info:
        preprocessor_lib.clean_header([
            "Claim", "Payer", "Status", "Patient", "Proc", "Serv",
            "Allowed", "Paid", "Pt Resp", "Charged"
        ])
    assert "csv_subtype=claim_payment_no_surgery_date" in str(exc_info.value)
    assert "serv_alias_policy=not_accepted_without_value_shape_validation" in str(exc_info.value)


def test_classify_patient_demographic_csv_without_surgery_date():
    classification = preprocessor_lib.classify_csv_header_subtype([
        "Name", "Patient ID", "Address", "Home Phone", "DOB", "Gender",
        "Primary Insurance", "Primary Policy Number", "Primary Group Number",
        "Secondary Insurance"
    ])

    assert classification["csv_subtype"] == "patient_demographic_no_surgery_date"
    assert classification["matched_family"] == "patient_demographic"


def test_clean_header_rate_limits_repeated_missing_surgery_date_warning(monkeypatch):
    captured = []

    def capture_log(message, level="INFO", **_kwargs):
        captured.append((level, message))

    preprocessor_lib._MISSING_SURGERY_DATE_HEADER_COUNTS.clear()
    monkeypatch.setattr(preprocessor_lib.MediLink_ConfigLoader, "log", capture_log)

    for _idx in range(2):
        with pytest.raises(ValueError):
            preprocessor_lib.clean_header(["category", "patient_id", "next_action"])

    warnings = [item for item in captured if item[0] == "WARNING"]
    debug = [item for item in captured if item[0] == "DEBUG"]
    assert len(warnings) == 1
    assert "CSV missing required surgery date header after cleaning." in warnings[0][1]
    assert any("repeat suppressed count=2" in item[1] for item in debug)
