import json
import os
import shutil
import sys
import tempfile
import zipfile


ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
TOOLS = os.path.join(ROOT, "tools")
if TOOLS not in sys.path:
    sys.path.insert(0, TOOLS)
TESTS = os.path.join(ROOT, "tests")
if TESTS not in sys.path:
    sys.path.insert(0, TESTS)

import replay_xp_bundle
from workflow_boundary_contract import assert_workflow_boundary_clean


def _write_json(path, payload):
    parent = os.path.dirname(path)
    if parent and not os.path.isdir(parent):
        os.makedirs(parent)
    with open(path, "w") as handle:
        json.dump(payload, handle, indent=2, sort_keys=True)
        handle.write("\n")


def _write_text(path, text):
    parent = os.path.dirname(path)
    if parent and not os.path.isdir(parent):
        os.makedirs(parent)
    with open(path, "w") as handle:
        handle.write(text)


def _bundle(root, name="medicafe_bundle_anchor", include_txt=True, smoke_mismatch=False, smoke_state=None):
    bundle_dir = os.path.join(root, name)
    os.makedirs(bundle_dir)
    anchor = "PIPE"
    phase_d = "DRID"
    xp_json = r"C:\Python34\Lib\site-packages\lab\reports\phase_d_invalid_external_id_contract_report_DRID.json"
    xp_txt = r"C:\Python34\Lib\site-packages\lab\reports\phase_d_invalid_external_id_contract_report_DRID.txt"
    _write_json(os.path.join(bundle_dir, "meta.json"), {
        "bundle_kind": "run_evidence_bundle",
        "send_source": "unit_test",
        "app_version": "9.9.9",
        "recommended_action_kind": "resolve_external_patient_id_contract_pressure",
    })
    _write_json(os.path.join(bundle_dir, "evidence_scope.json"), {
        "anchor_run_id": anchor,
        "phase_run_id_map": {"B": "BRID", "C": "CRID", "D": phase_d, "E": "ERID"},
    })
    _write_json(os.path.join(bundle_dir, "diagnostics_state.json"), {
        "last_shadow_pipeline_run_id": anchor,
        "last_phase_d_run_id": phase_d,
        "last_shadow_pipeline_phase_run_ids": {"B": "BRID", "C": "CRID", "D": phase_d, "E": "ERID"},
    })
    _write_json(os.path.join(bundle_dir, "run_cursor.json"), {
        "last_shadow_pipeline_run_id": anchor,
    })
    _write_json(os.path.join(bundle_dir, "shadow_run_report_PIPE.json"), {
        "run_id": anchor,
        "phase_run_ids": {"B": "BRID", "C": "CRID", "D": phase_d, "E": "ERID"},
        "phase_d_dat_selected_count": 3,
        "phase_d_dat_qa_pass_count": 2,
        "phase_d_dat_canonical_record_count": 2,
        "source_summary_paths": {
            "D": r"C:\Python34\Lib\site-packages\lab\reports\qa_canonical_summary_DRID.json"
        },
    })
    _write_json(os.path.join(bundle_dir, "qa_canonical_summary_DRID.json"), {
        "run_id": phase_d,
        "phase_d_data_plane_stage": "data_quality_blocked",
        "phase_d_entity_scope": "v1",
        "dat_telemetry": {
            "dat_selected_count": 3,
            "dat_qa_pass_count": 2,
            "dat_qa_reject_count": 1,
            "dat_canonical_record_count": 2,
        },
        "phase_d_developer_unblock": {
            "schema_version": "phase_d_developer_unblock_v1",
            "recommended_action_kind": "resolve_external_patient_id_contract_pressure",
            "operator_manual_review_required": False,
            "safe_for_bundle": True,
            "contains_pii": False,
            "evidence_reports": [
                {"path": xp_json, "archive_name": os.path.basename(xp_json), "required": True, "contains_pii": False, "safe_for_bundle": True},
                {"path": xp_txt, "archive_name": os.path.basename(xp_txt), "required": True, "contains_pii": False, "safe_for_bundle": True},
            ],
        },
    })
    _write_json(os.path.join(bundle_dir, "phase_d_invalid_external_id_contract_report_DRID.json"), {
        "schema_version": "phase_d_invalid_external_id_contract_report_v1",
        "rows": [{"field_name": "external_patient_id", "count": 2, "safe_examples": ["shape:blank"]}],
    })
    if include_txt:
        _write_text(os.path.join(bundle_dir, "phase_d_invalid_external_id_contract_report_DRID.txt"), "redacted report\n")
    if smoke_mismatch:
        _write_text(os.path.join(bundle_dir, "run_evidence_smoke_anchor_mismatch_PIPE.txt"), "ignored_smoke_mismatch=true\n")
    if smoke_state:
        _write_json(os.path.join(bundle_dir, "phase_d_dat_smoke_state.json"), smoke_state)
    return bundle_dir


def _make_anchor_zero_with_followup(bundle_dir):
    anchor = "PIPE"
    anchor_d = "DRID"
    followup_d = "FOLLOWD"
    _write_json(os.path.join(bundle_dir, "diagnostics_state.json"), {
        "last_shadow_pipeline_run_id": anchor,
        "last_phase_d_run_id": followup_d,
        "last_shadow_pipeline_phase_run_ids": {"B": "BRID", "C": "CRID", "D": anchor_d, "E": "ERID"},
    })
    _write_json(os.path.join(bundle_dir, "shadow_run_report_PIPE.json"), {
        "run_id": anchor,
        "phase_run_ids": {"B": "BRID", "C": "CRID", "D": anchor_d, "E": "ERID"},
        "phase_d_dat_selected_count": 0,
        "phase_d_dat_qa_pass_count": 0,
        "phase_d_dat_qa_reject_count": 0,
        "phase_d_dat_canonical_record_count": 0,
        "source_summary_paths": {
            "D": r"C:\Python34\Lib\site-packages\lab\reports\qa_canonical_summary_DRID.json"
        },
    })
    _write_json(os.path.join(bundle_dir, "qa_canonical_summary_DRID.json"), {
        "run_id": anchor_d,
        "phase_d_data_plane_stage": "data_quality_blocked",
        "dat_telemetry": {
            "dat_selected_count": 0,
            "dat_qa_pass_count": 0,
            "dat_qa_reject_count": 0,
            "dat_canonical_record_count": 0,
        },
    })
    _write_json(os.path.join(bundle_dir, "qa_canonical_summary_FOLLOWD.json"), {
        "run_id": followup_d,
        "phase_d_data_plane_stage": "data_quality_blocked",
        "dat_telemetry": {
            "dat_selected_count": 22,
            "dat_qa_pass_count": 0,
            "dat_qa_reject_count": 22,
            "dat_canonical_record_count": 0,
            "dat_qa_reject_counts_by_reason": {
                "QA_DAT_EMPTY_FILE": 12,
                "QA_DAT_PATIENT_ANCHOR_MISSING": 8,
                "QA_DAT_PAYER_ANCHOR_MISSING": 2,
            },
            "dat_reject_file_prefix_counts": {
                "Z": 12,
                "ZM": 10,
            },
        },
    })
    _write_text(os.path.join(bundle_dir, "qa_reject_samples_FOLLOWD.jsonl"),
                '{"reject_code":"QA_DAT_EMPTY_FILE","artifact_id":"redacted"}\n')
    _write_text(os.path.join(bundle_dir, "run_evidence_phase_d_followup_note_PIPE.txt"), "\n".join([
        "Run Evidence Phase D Follow-up Note",
        "reviewed_anchor_phase_d_run_id=DRID",
        "followup_phase_d_run_id=FOLLOWD",
        "phase_d_movement_classification=followup_only_not_anchor_closure",
        "accepted_as_reviewed_anchor_milestone=False",
        "phase_d_counts=selected:22,qa_pass:0,qa_reject:22,canonical:0",
        r"qa_canonical_summary_path=C:\Python34\Lib\site-packages\lab\reports\qa_canonical_summary_FOLLOWD.json",
        r"qa_reject_samples_path=C:\Python34\Lib\site-packages\lab\reports\qa_reject_samples_FOLLOWD.jsonl",
        "live_state_warning=Current diagnostics_state may show post-anchor Phase D movement; do not count it as reviewed anchor milestone progress unless the matching Phase D summary is attached and marked as the reviewed anchor.",
    ]) + "\n")


def test_replay_rebases_paths_without_mutating_original_bundle():
    tmp = tempfile.mkdtemp()
    try:
        bundle_dir = _bundle(tmp)
        original_qa = os.path.join(bundle_dir, "qa_canonical_summary_DRID.json")
        original_text = open(original_qa).read()
        out_dir = os.path.join(tmp, "out")
        result = replay_xp_bundle.replay_bundle(bundle_dir, out_dir, keep_labs=True)
        assert result["developer_unblock_status"] == "complete"
        assert result["milestone_verdict"] == "Partially advanced"
        hydrated_qa = result["qa_canonical_summary_path"]
        hydrated = json.load(open(hydrated_qa))
        paths = [row["path"] for row in hydrated["phase_d_developer_unblock"]["evidence_reports"]]
        assert all(path.startswith(result["scratch_lab_dir"]) for path in paths)
        assert open(original_qa).read() == original_text
        assert "C:\\\\Python34\\\\Lib\\\\site-packages\\\\lab\\\\reports" in original_text
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def test_replay_shortens_long_hydrated_report_names_and_preserves_original_mapping():
    tmp = tempfile.mkdtemp()
    try:
        bundle_dir = _bundle(tmp)
        long_name = "diagnostic_attempt_{0}.json".format("x" * 150)
        long_source = os.path.join(bundle_dir, long_name)
        _write_json(long_source, {"schema_version": "diagnostic_attempt_v1"})

        qa_path = os.path.join(bundle_dir, "qa_canonical_summary_DRID.json")
        qa_payload = json.load(open(qa_path))
        qa_payload["phase_d_developer_unblock"]["evidence_reports"].append({
            "path": r"C:\Python34\Lib\site-packages\lab\reports\{0}".format(long_name),
            "archive_name": long_name,
            "required": True,
            "contains_pii": False,
            "safe_for_bundle": True,
        })
        _write_json(qa_path, qa_payload)

        result = replay_xp_bundle.replay_bundle(bundle_dir, os.path.join(tmp, "out"), keep_labs=True)
        hydrated_qa = json.load(open(result["qa_canonical_summary_path"]))
        long_paths = [
            row["path"]
            for row in hydrated_qa["phase_d_developer_unblock"]["evidence_reports"]
            if row.get("archive_name") == long_name
        ]
        assert len(long_paths) == 1
        assert os.path.isfile(long_paths[0])
        assert os.path.basename(long_paths[0]) != long_name
        assert os.path.basename(long_paths[0]).endswith(".json")
        assert len(os.path.basename(long_paths[0])) <= replay_xp_bundle.HYDRATED_BASENAME_LIMIT
        assert result["developer_unblock_status"] == "complete"
        assert os.path.isfile(long_source)

        rows = [
            row for row in result["hydrated_path_mapping"]
            if row["original_bundle_path"] == long_name
        ]
        assert len(rows) == 1
        assert rows[0]["hydrated_name_changed"] is True
        assert rows[0]["hydrated_lab_path"] == os.path.abspath(long_paths[0])
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def test_replay_reports_followup_phase_d_without_changing_anchor_milestone():
    tmp = tempfile.mkdtemp()
    try:
        bundle_dir = _bundle(tmp)
        _make_anchor_zero_with_followup(bundle_dir)
        result = replay_xp_bundle.replay_bundle(bundle_dir, os.path.join(tmp, "out"), keep_labs=False)
        assert result["phase_d_dat_counts"] == {
            "selected": 0,
            "qa_pass": 0,
            "qa_reject": 0,
            "canonical": 0,
            "v2_inserted": 0,
        }
        assert result["milestone_verdict"] == "Not advanced"
        followup = result["followup_phase_d"]
        assert followup["reviewed_anchor_phase_d_run_id"] == "DRID"
        assert followup["followup_phase_d_run_id"] == "FOLLOWD"
        assert followup["selected_count"] == 22
        assert followup["qa_pass_count"] == 0
        assert followup["qa_reject_count"] == 22
        assert followup["canonical_count"] == 0
        assert followup["accepted_as_reviewed_anchor_milestone"] is False
        assert followup["phase_d_movement_classification"] == "followup_only_not_anchor_closure"
        assert followup["dominant_reject_code"] == "QA_DAT_EMPTY_FILE"
        assert followup["dominant_reject_count"] == 12
        assert followup["dat_reject_blocker_class"] == "empty_dat_file"
        assert followup["qa_canonical_summary_path"].endswith("qa_canonical_summary_FOLLOWD.json")
        assert followup["qa_reject_samples_path"].endswith("qa_reject_samples_FOLLOWD.jsonl")
        assert "post-anchor Phase D movement" in followup["live_state_warning"]
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def test_replay_reports_degraded_developer_unblock_when_required_file_missing():
    tmp = tempfile.mkdtemp()
    try:
        bundle_dir = _bundle(tmp, include_txt=False)
        result = replay_xp_bundle.replay_bundle(bundle_dir, os.path.join(tmp, "out"), keep_labs=False)
        assert result["developer_unblock_status"] == "degraded"
        missing = result["developer_unblock"]["missing_reports"]
        want = "phase_d_invalid_external_id_contract_report_DRID.txt"
        assert any(
            row == want or (isinstance(row, str) and row.replace("\\", "/").endswith(want))
            for row in missing
        )
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def test_replay_marks_smoke_mismatch_as_ignored():
    tmp = tempfile.mkdtemp()
    try:
        bundle_dir = _bundle(tmp, smoke_mismatch=True)
        result = replay_xp_bundle.replay_bundle(bundle_dir, os.path.join(tmp, "out"), keep_labs=False)
        assert result["smoke"]["verdict"] == "ignored_mismatch"
        assert result["smoke"]["accepted_for_anchor"] is False
        assert result["smoke"]["ignored_smoke_mismatch"] is True
        assert_workflow_boundary_clean("phase_d_dat_smoke", {
            "anchor_run_id": "PIPE",
        }, [
            {
                "name": "run_evidence_smoke_anchor_mismatch_PIPE.txt",
                "role": "package",
                "identity": {"anchor_run_id": "PIPE"},
                "classification": result["smoke"]["verdict"],
            },
        ])
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def test_replay_keeps_started_smoke_state_non_terminal():
    tmp = tempfile.mkdtemp()
    try:
        bundle_dir = _bundle(tmp, smoke_state={
            "last_status": "started",
            "last_requested_anchor_run_id": "PIPE",
            "last_requested_context_run_id": "DRID",
            "last_report_path": "",
        })
        result = replay_xp_bundle.replay_bundle(bundle_dir, os.path.join(tmp, "out"), keep_labs=False)
        smoke = result["smoke"]
        assert smoke["verdict"] == "state_present_not_accepted"
        assert smoke["accepted_for_anchor"] is False
        assert_workflow_boundary_clean("phase_d_dat_smoke", {
            "anchor_run_id": "PIPE",
            "context_run_id": "DRID",
        }, [
            {
                "name": "phase_d_dat_smoke_state.json",
                "role": "attempt",
                "identity": {"anchor_run_id": "PIPE", "context_run_id": "DRID"},
                "status": smoke.get("last_status"),
            },
            {
                "name": "replay_summary",
                "role": "package",
                "identity": {"anchor_run_id": "PIPE", "context_run_id": "DRID"},
                "classification": smoke["verdict"],
            },
        ])
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def test_main_generates_summary_and_codex_handoff_for_parent_dir():
    tmp = tempfile.mkdtemp()
    try:
        parent = os.path.join(tmp, "bundles")
        os.makedirs(parent)
        _bundle(parent, "medicafe_bundle_one")
        _bundle(parent, "medicafe_bundle_two")
        out_dir = os.path.join(tmp, "reports")
        rc = replay_xp_bundle.main(["--input", parent, "--out-dir", out_dir])
        assert rc == 0
        summary_path = os.path.join(out_dir, "replay_summary.json")
        handoff_path = os.path.join(out_dir, "codex_handoff_prompt.md")
        summary = json.load(open(summary_path))
        handoff = open(handoff_path).read()
        assert len(summary["bundles"]) == 2
        assert "original_bundle_dir" in handoff
        assert "Smoke verdict" in handoff or "smoke_verdict" in handoff
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def test_zip_input_is_supported():
    tmp = tempfile.mkdtemp()
    try:
        src_parent = os.path.join(tmp, "src")
        os.makedirs(src_parent)
        bundle_dir = _bundle(src_parent, "medicafe_bundle_zip")
        zip_path = os.path.join(tmp, "bundle.zip")
        with zipfile.ZipFile(zip_path, "w") as zf:
            for dirpath, dirnames, filenames in os.walk(bundle_dir):
                for name in filenames:
                    path = os.path.join(dirpath, name)
                    zf.write(path, os.path.relpath(path, src_parent))
        out_dir = os.path.join(tmp, "reports")
        rc = replay_xp_bundle.main(["--input", zip_path, "--out-dir", out_dir])
        assert rc == 0
        summary = json.load(open(os.path.join(out_dir, "replay_summary.json")))
        assert len(summary["bundles"]) == 1
        assert summary["bundles"][0]["bundle_name"] == "medicafe_bundle_zip"
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
