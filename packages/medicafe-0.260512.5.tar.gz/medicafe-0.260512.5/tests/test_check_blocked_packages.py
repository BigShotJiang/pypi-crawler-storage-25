# -*- coding: utf-8 -*-
"""Unit tests for tools/security/check_blocked_packages.py."""

import importlib.util
from pathlib import Path

_ROOT = Path(__file__).resolve().parents[1]


def _load_module():
    path = _ROOT / "tools" / "security" / "check_blocked_packages.py"
    spec = importlib.util.spec_from_file_location("check_blocked_packages", path)
    mod = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(mod)
    return mod


def test_parse_req_line_pep508_extras():
    m = _load_module()
    assert m._parse_req_line("guardrails-ai[cuda]==0.10.1") == ("guardrails-ai", "==", "0.10.1")
    assert m._parse_req_line("mistralai[a,b]==2.4.6") == ("mistralai", "==", "2.4.6")


def test_parse_req_line_inline_comment():
    m = _load_module()
    assert m._parse_req_line("mistralai==2.4.6  # compromised pin") == ("mistralai", "==", "2.4.6")


def test_parse_req_line_plain_pin_unchanged():
    m = _load_module()
    assert m._parse_req_line("mistralai==2.4.6") == ("mistralai", "==", "2.4.6")
    assert m._parse_req_line("mistralai==2.4.7") == ("mistralai", "==", "2.4.7")


def test_scan_requirements_detects_blocked_with_extras(tmp_path, monkeypatch):
    m = _load_module()
    req = tmp_path / "requirements.txt"
    req.write_text("guardrails-ai[vec]==0.10.1\n", encoding="utf-8")
    monkeypatch.setattr(m, "REQ_FILES", [req])
    findings = m._scan_requirements()
    assert findings
    assert any("guardrails-ai" in str(t) for t in findings)
