# PITH

Local AI knowledge management for solopreneurs and small teams.

**Coming soon.** Visit [pithhq.com](https://pithhq.com) for updates.
