"""View-model builder for the job-cohort detail page.

Pure data layer - no FastAPI / templates / I/O beyond the SQLAlchemy
session the caller passes in. The route handler in
``web/routes/findings.py`` is the only consumer.

Spec: [146-audit-job-history-trend](../../../specs/146-audit-job-history-trend/spec.md).

Per-version detection lives in ``per_version_detection.py``; this
module orchestrates the per-version walk but doesn't know how to run
detection rules itself.
"""

from __future__ import annotations

import hashlib
from dataclasses import dataclass, field
from datetime import datetime
from decimal import Decimal
from typing import TYPE_CHECKING, Any

from governor_core.utils.diff import generate_code_diff

if TYPE_CHECKING:
    from sqlalchemy.orm import Session

    from governor_core.sync.models import BigQueryJob


# ─── Dataclasses ──────────────────────────────────────────────────────


@dataclass
class JobVersion:
    """One distinct query body within the scan window for a destination_table.

    A version begins the first time we see a given query_hash for the
    table and closes the next time the hash changes (chronologically by
    ``creation_time``). Everything is filled by ``cohort_view``; the
    per-version-detection fields stay empty until ``per_version_detection``
    populates them in the orchestration step.
    """

    version_id: str
    """``query_hashes['normalized_literals']`` if present, else
    ``sha1(query)``. Stable across executions of the same body."""

    version_index: int
    """1-based chronological order. v1 = first version seen in the window."""

    query_text: str
    """Representative query body - the latest execution at this hash."""

    first_seen: datetime
    """``creation_time`` of the first execution at this hash."""

    last_seen: datetime
    """``creation_time`` of the last execution at this hash."""

    executions: list["BigQueryJob"]
    """Every cached execution at this hash, chronological."""

    total_cost: Decimal
    """Sum of ``total_cost`` across all executions at this hash."""

    diff_against_previous: list[str] | None
    """Unified diff of this version's query body against the previous
    version's, as ``generate_code_diff`` lines. ``None`` for v1."""

    # ── Per-version detection (filled by per_version_detection) ──
    rules_fired: set[str] = field(default_factory=set)
    """Rule types that produced ≥ 1 candidate when run against the
    representative job (latest execution at this version_id)."""

    resolved_rules: set[str] = field(default_factory=set)
    """Rules that fired on the IMMEDIATELY-PREVIOUS version but not on
    this one. Renders as a strikethrough chip on this version's card,
    explaining "this version no longer triggers <rule>"."""

    newly_introduced_rules: set[str] = field(default_factory=set)
    """Rules that fire here but did NOT fire on the immediately-previous
    version. Renders as a "New in this version" chip on this card."""


@dataclass
class ChartPoint:
    """One data point on the cost-trend chart. Bucket-by-day per the
    spec's closed decision (per-day granularity, skip days with zero
    executions). Sortable by ``day``."""

    day: str
    """Calendar date as ``YYYY-MM-DD`` (UTC)."""

    cost_usd: float
    """Sum of ``total_cost`` across executions on this day."""

    bytes_processed: int
    """Sum of ``total_bytes_processed`` across executions on this day."""

    bytes_human: str
    """Pre-formatted byte size for the tooltip (e.g. ``"5.4 TB"``)."""

    slot_ms: int
    """Sum of ``total_slot_ms`` across executions on this day."""

    execution_count: int
    """How many executions ran on this day."""

    version_id: str
    """The version_id of the FIRST execution on this day. When a day's
    executions span a version transition, only the first one's version
    drives the marker - version transitions in mid-day are rare."""

    version_index: int
    """1-based version index for the day's first execution."""

    is_version_change_marker: bool
    """``True`` when the first execution on this day is the FIRST
    execution at its version_id (i.e., this day starts a new version)."""

    first_job_id: str
    """``job_id`` of the first execution on this day. Drives the chart
    point's click-through to the per-execution page."""

    has_issue: bool = False
    """``True`` when at least one of this day's executions was part of
    the opportunity's ``related_job_ids`` set - i.e., this day's runs
    are what tripped the detection rule. Drives the red line-segment
    overlay on the cost-trend chart so users see at a glance WHICH
    days' executions caused the flagged opportunity (vs. days that
    ran clean even though the rule has fired on the table)."""


@dataclass
class JobCohortView:
    """Top-level view-model the cohort template consumes."""

    destination_table: str
    """Full ``project.dataset.table`` form."""

    versions: list[JobVersion]
    """Chronological. Empty when ``has_no_executions``."""

    chart_points: list[ChartPoint]
    """One per UTC day with ≥ 1 execution. Skip days with zero - the
    X axis is the dense sequence of executed days, not a calendar."""

    total_cost_usd: Decimal
    """Sum across every cached execution for this table, regardless of
    version. Drives the stat-strip card."""

    total_executions: int
    """Sum across every version. Drives the stat-strip card."""

    days_with_executions: int
    """``len(chart_points)``. Drives the stat-strip card."""

    latest_suggestions: list[dict[str, Any]] = field(default_factory=list)
    """Suggestion cards - one per rule that fires on the LATEST version's
    representative job. Same dict shape the opportunity-detail template
    consumes (rule_type, display_name, explanation, diff_lines, …).
    Filled by per_version_detection."""

    @property
    def has_no_executions(self) -> bool:
        return not self.versions

    def chart_points_payload(self) -> list[dict[str, Any]]:
        """JSON-serialisable list for the chart's ``data-points``
        attribute. Avoids the Jinja ``__dict__`` trick that doesn't
        work cleanly on dataclass instances."""
        return [
            {
                "day": p.day,
                "cost_usd": p.cost_usd,
                "bytes_processed": p.bytes_processed,
                "bytes_human": p.bytes_human,
                "slot_ms": p.slot_ms,
                "execution_count": p.execution_count,
                "version_id": p.version_id,
                "version_index": p.version_index,
                "is_version_change_marker": p.is_version_change_marker,
                "has_issue": p.has_issue,
                "first_job_id": p.first_job_id,
            }
            for p in self.chart_points
        ]


# ─── Hashing + grouping helpers ──────────────────────────────────────


def _query_version_hash(job: "BigQueryJob") -> str:
    """Return a stable per-query-body identifier.

    Prefer ``query_hashes['normalized_literals']`` - BigQuery's own
    structural hash, computed by the optimizer. Falls back to
    ``sha1(query)`` for older cached rows where the column is missing
    (and for tests that don't bother setting it).
    """
    qh = job.query_hashes if isinstance(job.query_hashes, dict) else None
    if qh:
        normalized = qh.get("normalized_literals")
        if normalized:
            return str(normalized)
    raw = job.query or ""
    return hashlib.sha1(raw.encode("utf-8")).hexdigest()


def _group_by_version(jobs: list["BigQueryJob"]) -> list[JobVersion]:
    """Walk chronologically and close a version each time the hash
    changes. ``jobs`` MUST already be sorted by ``creation_time`` ASC.

    Uses the LATEST execution's query body as ``query_text`` so the
    rendered diff reflects what BigQuery most recently saw - not a
    stale earlier representative.
    """
    versions: list[JobVersion] = []
    current_hash: str | None = None
    bucket: list["BigQueryJob"] = []

    def _flush(version_index: int) -> None:
        if not bucket:
            return
        latest = bucket[-1]
        versions.append(
            JobVersion(
                version_id=current_hash or "",
                version_index=version_index,
                query_text=latest.query or "",
                first_seen=bucket[0].creation_time,
                last_seen=latest.creation_time,
                executions=list(bucket),
                total_cost=sum(
                    (j.total_cost or Decimal("0") for j in bucket),
                    start=Decimal("0"),
                ),
                diff_against_previous=None,  # filled below in a second pass
            )
        )

    for job in jobs:
        h = _query_version_hash(job)
        if current_hash is None:
            current_hash = h
            bucket = [job]
            continue
        if h == current_hash:
            bucket.append(job)
            continue
        _flush(len(versions) + 1)
        current_hash = h
        bucket = [job]
    _flush(len(versions) + 1)

    # Second pass: compute diffs against the previous version's text.
    for i in range(1, len(versions)):
        versions[i].diff_against_previous = generate_code_diff(
            versions[i - 1].query_text,
            versions[i].query_text,
        )

    return versions


# ─── Chart point aggregation ─────────────────────────────────────────


def _format_bytes(n: int) -> str:
    """Mirror the dashboard's byte formatter so the chart tooltip uses
    the same wording the cost-drivers table does."""
    n_f = float(n or 0)
    if n_f >= 1024**4:
        return f"{n_f / 1024**4:.2f} TB"
    if n_f >= 1024**3:
        return f"{n_f / 1024**3:.2f} GB"
    if n_f >= 1024**2:
        return f"{n_f / 1024**2:.2f} MB"
    if n_f >= 1024:
        return f"{n_f / 1024:.2f} KB"
    return f"{int(n_f)} B"


def _aggregate_chart_points(
    jobs: list["BigQueryJob"],
    versions: list[JobVersion],
    issue_job_ids: set[str] | None = None,
) -> list[ChartPoint]:
    """One point per UTC day with ≥ 1 execution. Skip days with zero -
    the X axis is the dense sequence of executed days (per spec
    decision). Marks the FIRST day at each version_id as a
    version-change marker so the chart can overlay a scatter point.

    When ``issue_job_ids`` is provided, each day's point gets
    ``has_issue=True`` if any of that day's executions are in the set
    - the chart uses this to colour the line red for those days."""
    _issue_set = issue_job_ids or set()
    if not jobs:
        return []

    # Pre-index version metadata for O(1) lookup.
    version_by_id: dict[str, JobVersion] = {v.version_id: v for v in versions}
    # The version-change marker fires on the first day we see a given
    # version_id - record which days qualify before we build the points.
    seen_version_ids: set[str] = set()

    # Bucket by date. Preserve insertion order (Python 3.7+ guarantees).
    by_day: dict[str, list["BigQueryJob"]] = {}
    for job in jobs:
        day = job.creation_time.date().isoformat()
        by_day.setdefault(day, []).append(job)

    points: list[ChartPoint] = []
    for day, day_jobs in by_day.items():
        # Day's first execution (chronological) drives the
        # version_id / marker / first_job_id.
        first = day_jobs[0]
        first_hash = _query_version_hash(first)
        version = version_by_id.get(first_hash)
        is_marker = first_hash not in seen_version_ids
        seen_version_ids.add(first_hash)

        cost = sum(
            (j.total_cost or Decimal("0") for j in day_jobs),
            start=Decimal("0"),
        )
        bytes_total = sum(j.total_bytes_processed or 0 for j in day_jobs)
        slot_total = sum(j.total_slot_ms or 0 for j in day_jobs)

        day_has_issue = any(j.job_id in _issue_set for j in day_jobs)
        points.append(
            ChartPoint(
                day=day,
                cost_usd=float(cost),
                bytes_processed=bytes_total,
                bytes_human=_format_bytes(bytes_total),
                slot_ms=slot_total,
                execution_count=len(day_jobs),
                version_id=first_hash,
                version_index=version.version_index if version else 0,
                is_version_change_marker=is_marker,
                has_issue=day_has_issue,
                first_job_id=first.job_id,
            )
        )
    return points


# ─── Public entry point ──────────────────────────────────────────────


def build_cohort_view(
    session: "Session",
    *,
    config_id: str,
    destination_table: str,
    rule_overrides: dict[str, bool] | None = None,
) -> JobCohortView | None:
    """Return the cohort view for ``destination_table``, or ``None``
    when no executions exist for it under the active ``config_id``.

    Caller (the route handler) 404s on ``None``. Reads are scoped to
    ``config_id`` per spec 145's project-switch fix - stale URLs from a
    previously-audited project surface as 404s instead of leaking
    foreign data.

    ``rule_overrides`` is the audit's per-config detection-rule toggle
    dict (from ``AuditConfig.detection_rule_overrides``). When provided
    the per-version detection layer honours the user's toggles; when
    ``None`` every rule is treated as enabled (audit's own default).
    """
    from governor_core.sync.models import BigQueryJob

    jobs = (
        session.query(BigQueryJob)
        .filter(
            BigQueryJob.config_id == config_id,
            BigQueryJob.destination_table == destination_table,
        )
        .order_by(BigQueryJob.creation_time.asc())
        .all()
    )
    if not jobs:
        return None

    versions = _group_by_version(jobs)
    chart_points = _aggregate_chart_points(jobs, versions)
    total_cost = sum(
        (j.total_cost or Decimal("0") for j in jobs),
        start=Decimal("0"),
    )

    view = JobCohortView(
        destination_table=destination_table,
        versions=versions,
        chart_points=chart_points,
        total_cost_usd=total_cost,
        total_executions=len(jobs),
        days_with_executions=len(chart_points),
    )

    # Per-version detection - populates JobVersion.{rules_fired,
    # resolved_rules, newly_introduced_rules} + view.latest_suggestions.
    # Imported lazily so layer-1 unit tests can build the view-model
    # without the cloud-rules import cost.
    from governor_audit.jobs.per_version_detection import populate_per_version_detection

    populate_per_version_detection(
        session=session,
        config_id=config_id,
        view=view,
        rule_overrides=rule_overrides or {},
    )

    return view


def build_chart_points_payload(
    session: "Session",
    *,
    config_id: str,
    destination_table: str,
    issue_job_ids: set[str] | None = None,
) -> list[dict[str, Any]]:
    """Lightweight helper: return the cost-trend chart payload for a
    table without the per-version detection / suggestion cards.

    Same chart shape the cohort view uses, just without the rule-fire
    walk per version. Embedded on the opportunity detail page so the
    user can see the cost trend in context without paying for the full
    cohort render. Returns an empty list when no jobs are cached.

    ``issue_job_ids`` (optional): the union of ``related_job_ids``
    across all opportunities for this table. Days whose executions
    intersect that set get ``has_issue=True`` in the payload - the
    chart partial renders those days' line segments in red.
    """
    from governor_core.sync.models import BigQueryJob

    jobs = (
        session.query(BigQueryJob)
        .filter(
            BigQueryJob.config_id == config_id,
            BigQueryJob.destination_table == destination_table,
        )
        .order_by(BigQueryJob.creation_time.asc())
        .all()
    )
    if not jobs:
        return []
    versions = _group_by_version(jobs)
    chart_points = _aggregate_chart_points(
        jobs, versions, issue_job_ids=issue_job_ids
    )
    # Mirror JobCohortView.chart_points_payload - keep the shape stable
    # so the chart partial doesn't have to branch on caller.
    return [
        {
            "day": p.day,
            "cost_usd": p.cost_usd,
            "bytes_processed": p.bytes_processed,
            "bytes_human": p.bytes_human,
            "slot_ms": p.slot_ms,
            "execution_count": p.execution_count,
            "version_id": p.version_id,
            "version_index": p.version_index,
            "is_version_change_marker": p.is_version_change_marker,
            "has_issue": p.has_issue,
            "first_job_id": p.first_job_id,
        }
        for p in chart_points
    ]


__all__ = [
    "JobCohortView",
    "JobVersion",
    "ChartPoint",
    "build_cohort_view",
    "build_chart_points_payload",
]
