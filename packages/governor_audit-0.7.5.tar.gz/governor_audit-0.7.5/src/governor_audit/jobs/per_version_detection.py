"""Per-version detection runner for the cohort view.

For each ``JobVersion`` in the cohort, we run audit's detection rules
against a single representative job (the latest execution at that
version's hash) and record which rules fire. The cohort view then
diffs adjacent versions' rule-fire sets to render the
``Resolved in current version`` and ``New in this version`` chips,
and surfaces the LATEST version's candidates as the page's
*Available improvements* section.

This is intentionally a separate module from ``cohort_view`` so the
view-model layer has no dependency on the cloud rule catalog or the
solution-template registry. Layer-1 unit tests construct
``JobCohortView`` shapes directly without touching detection.

Spec: [146-audit-job-history-trend](../../../specs/146-audit-job-history-trend/spec.md).
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from sqlalchemy.orm import Session

    from governor_audit.jobs.cohort_view import JobCohortView
    from governor_core.opportunities.rules.base import OpportunityCandidate
    from governor_core.sync.models import BigQueryJob


logger = logging.getLogger("governor_audit.jobs.per_version_detection")


# Rules NEVER run per-version on this page - they're dataset-level
# (storage_billing) or otherwise out-of-scope for a single-job manifest.
_PER_VERSION_RULE_BLACKLIST: frozenset[str] = frozenset({"storage_billing_optimization"})


def _is_rule_active(entry, overrides: dict[str, bool]) -> bool:
    """Mirror the audit's runtime rule-active logic. Audit owns its
    own defaults - missing key → True (NOT the cloud catalog's
    ``entry.enabled``, which has been observed to disable rules audit
    wants live; see PR #310 / spec 146 plan)."""
    rt = entry.rule_type
    if rt in _PER_VERSION_RULE_BLACKLIST:
        return False
    if rt in overrides:
        return bool(overrides[rt])
    return True


def detect_for_version(
    *,
    session: "Session",
    config_id: str,
    representative_job: "BigQueryJob",
    rule_overrides: dict[str, bool],
) -> dict[str, "OpportunityCandidate"]:
    """Run the rule catalog against a 1-element synthetic manifest.

    Returns ``{rule_type: candidate}`` for rules that produced ≥ 1
    candidate. No persistence - this runs in-memory per page render.
    """
    # Lazy imports avoid the circular-init dance with governor_core's
    # Base.metadata (audit's other modules use the same pattern).
    from governor_audit.scan.synthetic_manifest import build_synthetic_manifest
    from governor_core.opportunities.catalog import get_detection_rule_catalog

    synthetic_manifest = build_synthetic_manifest([representative_job])

    out: dict[str, "OpportunityCandidate"] = {}
    for entry in get_detection_rule_catalog():
        if not _is_rule_active(entry, rule_overrides):
            continue
        try:
            rule = entry.rule_class()
        except Exception as exc:  # noqa: BLE001
            logger.warning("rule %s failed to instantiate: %s", entry.rule_type, exc)
            continue
        try:
            thresholds = rule.get_thresholds()
            candidates = rule.detect(
                jobs=[representative_job],
                manifest_content=synthetic_manifest,
                thresholds=thresholds,
            )
        except Exception as exc:  # noqa: BLE001
            logger.warning(
                "rule %s.detect raised %s - skipping", entry.rule_type, exc
            )
            continue
        if candidates:
            # Per-page detection: one rule fires once per (table, hash).
            # If the rule emits multiple candidates for the same table,
            # the first wins for the chip set; the cards step below
            # processes them all.
            out[entry.rule_type] = candidates[0]
    return out


def _build_suggestion_card(
    candidate: "OpportunityCandidate",
    representative_job: "BigQueryJob",
    synthetic_manifest: dict,
    *,
    session: "Session",
    config_id: str,
) -> dict[str, Any] | None:
    """Mirror the per-card logic in ``web/routes/opportunities.py``'s
    improvement_views loop. Returns the dict shape the
    ``opportunities/detail.html`` improvement card consumes, so the
    cohort template can render it via the same partial / inline
    fragment.

    Returns ``None`` when the candidate has no deterministic
    before/after diff (template registry didn't fire) - those are
    text-only and we drop them per the existing cohort-page UX:
    actionable diffs only.
    """
    from governor_audit.scan.detection import _try_apply_template
    from governor_core.opportunities.catalog import get_detection_rule_catalog
    from governor_core.utils.diff import generate_code_diff

    template_result = _try_apply_template(
        candidate,
        [representative_job],
        synthetic_manifest,
        session=session,
        config_id=config_id,
    )

    diff_lines = None
    if (
        template_result
        and template_result.get("before_content")
        and template_result.get("after_content")
        and template_result["before_content"] != template_result["after_content"]
    ):
        diff_lines = generate_code_diff(
            template_result["before_content"],
            template_result["after_content"],
        )

    # Display name from the rule catalog (best-effort).
    meta_entry = next(
        (e for e in get_detection_rule_catalog() if e.rule_type == candidate.opportunity_type),
        None,
    )
    display_name = (
        meta_entry.display_name
        if meta_entry
        else candidate.opportunity_type.replace("_", " ").title()
    )

    return {
        "rule_type": candidate.opportunity_type,
        "display_name": display_name,
        "explanation": (template_result or {}).get("explanation") or candidate.explanation or "",
        "template_id": (template_result or {}).get("template_id"),
        "before_content": (template_result or {}).get("before_content"),
        "after_content": (template_result or {}).get("after_content"),
        "rollback": (template_result or {}).get("rollback"),
        "diff_lines": diff_lines,
        "occurrences": 1,
    }


def populate_per_version_detection(
    *,
    session: "Session",
    config_id: str,
    view: "JobCohortView",
    rule_overrides: dict[str, bool],
) -> None:
    """Walk the cohort's versions in chronological order, running
    detection on each, populating ``rules_fired`` /
    ``resolved_rules`` / ``newly_introduced_rules`` on each version,
    and finally building the ``view.latest_suggestions`` cards from
    the LATEST version's candidates.
    """
    if not view.versions:
        return

    prev_fired: set[str] = set()
    latest_candidates: dict[str, "OpportunityCandidate"] = {}

    for index, version in enumerate(view.versions):  # chronological
        # Latest execution at this hash is the representative - it's
        # what the rule sees if a future scan catches the same body.
        rep = version.executions[-1]
        candidates = detect_for_version(
            session=session,
            config_id=config_id,
            representative_job=rep,
            rule_overrides=rule_overrides,
        )
        version.rules_fired = set(candidates.keys())
        if index == 0:
            # No previous version inside this scan window - neither chip
            # is meaningful. Findings on v1 just are; they aren't
            # "new" relative to a previous-version baseline that
            # doesn't exist.
            version.resolved_rules = set()
            version.newly_introduced_rules = set()
        else:
            version.resolved_rules = prev_fired - version.rules_fired
            version.newly_introduced_rules = version.rules_fired - prev_fired
        prev_fired = version.rules_fired
        latest_candidates = candidates  # last iteration wins

    # Build cards for the latest version's candidates.
    if latest_candidates:
        from governor_audit.scan.synthetic_manifest import build_synthetic_manifest

        latest_version = view.versions[-1]
        rep = latest_version.executions[-1]
        synthetic_manifest = build_synthetic_manifest([rep])
        cards: list[dict[str, Any]] = []
        for cand in latest_candidates.values():
            card = _build_suggestion_card(
                cand,
                rep,
                synthetic_manifest,
                session=session,
                config_id=config_id,
            )
            if card is not None:
                cards.append(card)
        view.latest_suggestions = cards


__all__ = [
    "detect_for_version",
    "populate_per_version_detection",
]
