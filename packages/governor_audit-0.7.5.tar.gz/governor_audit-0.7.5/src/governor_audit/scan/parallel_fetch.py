"""Concurrent dispatch for the three independent INFORMATION_SCHEMA
queries in the scan pipeline.

``run_scan`` originally ran ``JOBS_BY_PROJECT``, ``COLUMNS``, and
``TABLE_STORAGE`` sequentially. The three queries have no data
dependencies on each other - they're separate reads against
``INFORMATION_SCHEMA`` at the same ``(project, region)`` - so total
network wall-time is ``sum(latencies)`` instead of ``max(latencies)``.

This module wraps ``concurrent.futures.ThreadPoolExecutor`` with a
thin ``run_in_parallel`` helper that captures task failures into the
result dict rather than re-raising. The orchestrator then decides
which failures are fatal (jobs is, columns + storage are not - see
v0.4.13 outer-guard semantics).

Threads (not asyncio) because ``google-cloud-bigquery``'s ``Client``
is sync; almost all the wall time is HTTP I/O so the GIL is fine.
"""

from __future__ import annotations

import concurrent.futures
import logging
from typing import Any, Callable, TypeVar

T = TypeVar("T")
logger = logging.getLogger("governor_audit.scan.parallel_fetch")


def run_in_parallel(
    tasks: dict[str, Callable[[], T]],
    *,
    max_workers: int = 3,
    timeout_s: float | None = None,
) -> dict[str, Any]:
    """Run ``tasks`` concurrently. Return a name → ``result | Exception`` dict.

    Failures don't propagate - each is captured as the exception value
    so the caller can inspect partial completion. The orchestrator
    then decides which failures are fatal: the JOBS fetch is, COLUMNS
    and TABLE_STORAGE aren't (their original ``sync_*`` helpers
    already log + continue on failure).

    ``max_workers`` is bounded at 3 because there are only ever 3
    independent fetches in the audit pipeline. Larger pools waste
    threads and risk tripping per-user BigQuery API quota.
    """
    results: dict[str, Any] = {}
    if not tasks:
        return results

    with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as pool:
        future_to_name = {pool.submit(fn): name for name, fn in tasks.items()}
        for future in concurrent.futures.as_completed(
            future_to_name, timeout=timeout_s
        ):
            name = future_to_name[future]
            try:
                results[name] = future.result()
            except Exception as exc:  # noqa: BLE001
                logger.warning("Parallel task %r raised %s", name, exc)
                results[name] = exc
    return results


def is_failure(value: Any) -> bool:
    """True iff ``value`` is an Exception instance returned by
    ``run_in_parallel``. Centralised so call sites don't need to
    repeat the ``isinstance(..., Exception)`` check.
    """
    return isinstance(value, Exception)


__all__ = ["run_in_parallel", "is_failure"]
