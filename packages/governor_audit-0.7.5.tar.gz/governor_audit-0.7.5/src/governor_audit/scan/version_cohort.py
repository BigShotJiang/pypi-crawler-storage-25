"""Latest-version cohort filter for ``BigQueryJob`` lists.

The audit's unit-of-analysis is "the historical run of the latest deployed
query version" - not "every execution in the scan window". Without
collapsing to the latest cohort, a clean run after a bad version dilutes
the average, AND - more importantly - detection rules will keep firing
on evidence from older versions that the deployed code has since fixed.

Two layers use this helper:

1. **Scan-time** (this is the architectural-purity change for v0.7.3):
   ``scan/orchestrator.py`` filters ``jobs_in_scope`` to the latest cohort
   BEFORE handing them to the detection rules. As a result, no rule ever
   sees evidence from a prior query version. ``slot_contention`` fired on
   v1's executions stops firing on the next scan once v2 is the deployed
   version - even if v1's jobs are still in the 180-day scan window.

2. **Read-time**: dashboard / opportunities-listing handlers use the same
   helper to gate per-table counts when reporting on jobs.

Both code paths share THIS module so the cohort definition can't drift.
"""

from __future__ import annotations

import hashlib
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from governor_core.sync.models import BigQueryJob


def version_id_for(job: "BigQueryJob") -> str:
    """Stable per-execution version key.

    Prefers ``query_hashes.normalized_literals`` (BigQuery's own
    parameterised-query hash, which collapses identical SQL with
    different literal values into a single version). Falls back to a
    sha1 of the raw query body so jobs missing the hash field still
    bucket deterministically.
    """
    qh = job.query_hashes or {}
    if isinstance(qh, dict):
        nl = qh.get("normalized_literals")
        if nl:
            return nl
    return "raw:" + hashlib.sha1((job.query or "").encode("utf-8")).hexdigest()[:16]


def latest_version_cohort_job_ids(jobs) -> set[str]:
    """Return the set of ``BigQueryJob.job_id`` values that belong to
    the LATEST query-version cohort for their ``destination_table``.

    For each destination_table:
      1. Find the most-recent execution by ``creation_time``.
      2. Read its ``version_id`` (= normalized_literals hash, with a
         sha1-of-raw-query fallback).
      3. Add every cached execution at that destination running that
         same version_id.

    Jobs without a destination_table (consumption queries) are
    included unchanged - those are grouped by query_hash downstream,
    which is already version-aware by construction (each distinct
    hash IS a distinct version, so "latest cohort for a hash" is just
    every execution of that hash).
    """
    if not jobs:
        return set()

    # First pass: latest (creation_time, version_id) per destination.
    latest_by_dest: dict[str, tuple] = {}
    for job in jobs:
        dest = job.destination_table
        if not dest or job.creation_time is None:
            continue
        prev = latest_by_dest.get(dest)
        if prev is None or job.creation_time > prev[0]:
            latest_by_dest[dest] = (job.creation_time, version_id_for(job))

    # Second pass: collect job_ids whose (destination, version_id)
    # matches the destination's latest, plus every consumption job.
    cohort: set[str] = set()
    for job in jobs:
        dest = job.destination_table
        if not dest:
            cohort.add(job.job_id)  # consumption - hash-grouping is version
            continue
        target = latest_by_dest.get(dest)
        if target is None:
            cohort.add(job.job_id)  # creation_time missing - include anyway
            continue
        if version_id_for(job) == target[1]:
            cohort.add(job.job_id)
    return cohort


__all__ = ["latest_version_cohort_job_ids", "version_id_for"]
