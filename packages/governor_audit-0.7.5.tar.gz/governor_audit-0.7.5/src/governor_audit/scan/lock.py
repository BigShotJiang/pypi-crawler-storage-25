"""Advisory scan lock at ``~/.governor-audit/scan.lock``.

Single-tenant invariant per research D-8. The lock is a JSON file
containing the holding scan's PID + start time. ``governor-audit unlock``
clears stale locks (PID gone).

Acquisition is atomic via ``os.open(..., O_CREAT|O_EXCL)`` so two
``governor-audit scan`` invocations starting at the same moment can't
both observe "no lock" and both proceed - a single-writer invariant
``_wipe_previous_scan_state`` depends on. Stale-takeover from a dead
holder is also atomic: we open the existing path with O_RDWR and
rewrite the payload after confirming the prior PID is gone, rather
than ``unlink`` + ``write_text`` which would race with a second
attempt.
"""

from __future__ import annotations

import errno
import json
import os
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path

from governor_audit.config.loader import config_dir, ensure_config_dir
from governor_audit.utils.process import is_process_running

LOCK_FILENAME = "scan.lock"


class ScanLockHeldError(Exception):
    def __init__(self, holder_pid: int, started_at: str | None) -> None:
        self.holder_pid = holder_pid
        self.started_at = started_at
        super().__init__(
            f"Scan lock held by PID {holder_pid}"
            + (f" (started {started_at})" if started_at else "")
            + ". If the process is dead, run `governor-audit unlock`."
        )


def lock_path(dir_override: Path | None = None) -> Path:
    return config_dir(dir_override) / LOCK_FILENAME


def read_lock(dir_override: Path | None = None) -> dict | None:
    path = lock_path(dir_override)
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text())
    except (json.JSONDecodeError, OSError):
        return None


def _write_payload_atomic(path: Path, payload: dict) -> None:
    """Write the lock payload via a temp file + ``os.replace`` so a
    crash mid-write leaves either the old payload (if any) or the
    new one - never a zero-byte file that ``read_lock`` would
    silently treat as "no lock"."""
    tmp = path.with_name(path.name + ".tmp")
    fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    try:
        with os.fdopen(fd, "w") as f:
            json.dump(payload, f)
            f.flush()
            os.fsync(f.fileno())
    except Exception:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise
    os.replace(tmp, path)


@contextmanager
def acquire_scan_lock(dir_override: Path | None = None):
    """Acquire the scan lock for the duration of the context.

    Raises ``ScanLockHeldError`` if another live process holds it.
    Clears stale locks (holding PID is gone) and proceeds.

    Atomicity:
      * Fresh acquisition uses ``O_CREAT | O_EXCL`` - only one of N
        racing processes wins.
      * Stale takeover: if the create raises ``EEXIST``, we read the
        existing payload. If the PID is alive, we raise
        ``ScanLockHeldError``. If it's dead, we overwrite the payload
        in place via ``_write_payload_atomic`` (temp + ``os.replace``)
        so a second-racing takeover lands deterministically on one or
        the other writer's payload - never on a partial file.
    """
    ensure_config_dir(dir_override)
    path = lock_path(dir_override)
    payload = {
        "pid": os.getpid(),
        "started_at": datetime.now(timezone.utc).isoformat(),
    }

    acquired = False
    try:
        fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    except OSError as exc:
        if exc.errno != errno.EEXIST:
            raise
        # File already exists - check whether the holder is alive.
        existing = read_lock(dir_override)
        if existing is not None:
            holder_pid = int(existing.get("pid", -1))
            if holder_pid > 0 and is_process_running(holder_pid):
                raise ScanLockHeldError(holder_pid, existing.get("started_at"))
        # Stale (or unparseable) lock - take it over atomically.
        _write_payload_atomic(path, payload)
        acquired = True
    else:
        try:
            with os.fdopen(fd, "w") as f:
                json.dump(payload, f)
                f.flush()
                os.fsync(f.fileno())
            acquired = True
        except Exception:
            try:
                os.unlink(path)
            except OSError:
                pass
            raise

    try:
        yield path
    finally:
        if acquired:
            try:
                path.unlink(missing_ok=True)
            except OSError:
                pass


__all__ = ["ScanLockHeldError", "acquire_scan_lock", "lock_path", "read_lock"]
