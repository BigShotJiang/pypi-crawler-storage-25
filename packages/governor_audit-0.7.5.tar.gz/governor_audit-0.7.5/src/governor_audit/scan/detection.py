"""Audit-side detection runner.

Lightweight wrapper around the ``governor_core.opportunities.rules``
catalogue. The cloud version routes detection through a heavy
``DetectionEngine`` (OpenTelemetry, OpportunityService dedup, rolling
windows, manifest history). The audit package skips all of that - it
has no manifest, no Opportunity history to roll up against, and no
users to attribute changes to. It also deliberately drops savings-
estimation: every persisted Opportunity carries ``expected_savings =
0`` (see ``_persist_candidate``).

What we actually do:

  1. Load every enabled rule's class from ``get_detection_rule_catalog()``
  2. Call ``rule.detect(jobs, manifest_content=None, thresholds=defaults)``
  3. Persist the resulting ``OpportunityCandidate`` list as ``Opportunity``
     rows tied to our sentinel ManifestConfiguration / DetectionJob
  4. Tag each opportunity's audit-side metadata via ``AuditOpportunityMetadata``

Rules that fundamentally need a dbt manifest (e.g.
``partition_pruning``'s run-results path) handle a None manifest
gracefully - they drop back to the BigQuery-insights-only branch.

This isn't a regression of governor-cloud's detection quality. The
audit's read-only use case is "tell me which queries are problematic
right now" - fancy temporal cross-referencing is exactly the kind of
complexity the audit package was scoped to skip.
"""

from __future__ import annotations

import logging
import uuid
from datetime import datetime, timezone
from decimal import Decimal
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from sqlalchemy.orm import Session

    from governor_core.sync.models import BigQueryJob

logger = logging.getLogger("governor_audit.scan.detection")


def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


def _fetch_available_columns(session, config_id, dataset, identifier):
    """Look up ``TableColumnMetadata`` for a single ``(dataset,
    identifier)`` and return a list of column names ordered by
    ``ordinal_position``. Empty list when no metadata is present."""
    try:
        from governor_core.sync.models import TableColumnMetadata

        rows = (
            session.query(TableColumnMetadata.column_name)
            .filter(
                TableColumnMetadata.config_id == config_id,
                TableColumnMetadata.dataset_name == dataset,
                TableColumnMetadata.table_name == identifier,
            )
            .order_by(TableColumnMetadata.ordinal_position)
            .all()
        )
    except Exception as exc:  # noqa: BLE001
        logger.debug("column lookup failed dataset=%s table=%s: %s", dataset, identifier, exc)
        return []
    return [r[0] for r in rows]


def _try_apply_template(cand, jobs, synthetic_manifest, *, session=None, config_id=None):
    """Try to produce a deterministic before/after diff for ``cand`` by
    invoking the ``governor_core.solutions.templates`` registry.

    Returns a dict suitable for merging into ``evidence_snapshot`` under
    the ``_template_result`` key, or ``None`` if no template applied.

    The template registry is the same one ``governor-web`` uses to seed
    its LLM solution generator. The audit-side use is purely
    deterministic - no LLM, no GitHub, no manifest. Each template reads
    structured fields from ``opportunity.evidence_snapshot`` (e.g.
    ``dead_ctes`` list) and rewrites the SQL via regex/AST.
    """
    if not cand.related_job_ids:
        return None

    first_job_id = cand.related_job_ids[0]
    job = next((j for j in jobs if j.job_id == first_job_id), None)
    if job is None or not job.query or not job.destination_table:
        return None

    parts = job.destination_table.split(".")
    if len(parts) != 3:
        return None
    database, schema, identifier = parts

    file_path = f"audit://q/{first_job_id}.sql"
    available_columns: list[str] = []
    if session is not None and config_id is not None:
        available_columns = _fetch_available_columns(
            session, config_id, schema, identifier
        )
    synthetic_node = {
        "name": identifier,
        "resource_type": "model",
        "config": {"materialized": "table"},
        "raw_code": job.query,
        "original_file_path": file_path,
        "database": database,
        "schema": schema,
        "identifier": identifier,
        # Consumed by the deterministic ExpandSelectStarTemplate (others
        # ignore it). Empty list = no INFORMATION_SCHEMA.COLUMNS data
        # synced for this table → template returns None and UI falls
        # back to plain text.
        "available_columns": available_columns,
    }
    source_files = {file_path: job.query}

    # Mirror the OpportunityCandidate's fields onto a shim object the
    # templates can read - ``match_template`` reads
    # ``opportunity.opportunity_type`` and ``opportunity.evidence_snapshot``
    # but the candidate hasn't been persisted as an ``Opportunity`` ORM
    # row yet at this point.
    class _CandShim:
        opportunity_type = cand.opportunity_type
        evidence_snapshot = cand.evidence_snapshot or {}
        affected_table = cand.affected_table

    try:
        from governor_core.solutions.templates import match_template

        result = match_template(_CandShim(), source_files, synthetic_node)
    except Exception as exc:  # noqa: BLE001
        logger.debug(
            "template registry raised %s for candidate type=%s - skipping",
            exc,
            cand.opportunity_type,
        )
        return None

    if result is None:
        return None

    return {
        "template_id": result.template_id,
        "file_path": result.file_path,
        "before_content": result.before_content,
        "after_content": result.after_content,
        "explanation": result.explanation,
        "rollback": result.rollback,
    }


def run_audit_detection(
    *,
    session: "Session",
    jobs: list["BigQueryJob"],
    config_id: str,
    detection_job_id: str,
    scan_run_id: str,
    rule_overrides: dict[str, bool] | None = None,
) -> int:
    """Run every enabled detection rule against ``jobs`` and persist the
    resulting opportunities.

    ``rule_overrides`` is the per-config toggle dict from
    ``AuditConfig.detection_rule_overrides`` (audit-side) - present
    keys win over the cloud catalog's ``entry.enabled`` flag.
    Without it, only the cloud's hardcoded defaults are honoured and
    the user's /admin/settings toggles silently do nothing.

    Returns the number of opportunities created (existing rows are
    upserted in place; the count is fresh-rows-only).

    Rule failures are caught per-rule so one broken rule doesn't kill
    the whole scan - the audit user wants partial results over an empty
    page.
    """
    from governor_audit.scan.categorization import (
        IMPROVEMENT_RULE_TYPES,
        ISSUE_RULE_TYPES,
        is_failed_job as _is_failed_job,
    )
    from governor_audit.scan.information_schema import (
        extract_dbt_invocation_id,
        extract_dbt_node_id,
        extract_query_hash,
        is_dbt_originated,
    )
    from governor_audit.scan.synthetic_manifest import build_synthetic_manifest
    from governor_core.opportunities.catalog import get_detection_rule_catalog

    overrides = rule_overrides or {}

    # Spec 149: partition input by success vs failure.
    #
    # ISSUE rules (slot_contention, partition_pruning, shuffle_spill, etc.)
    # depend on cost / slot math that's meaningless for failed jobs, so they
    # only see ``successful_jobs``.
    #
    # IMPROVEMENT rules (select_star, dead_cte, unused_join, redundant_order_by,
    # cross_join_unaggregated, self_join_anti_pattern, etc.) are pure AST
    # rewrites that don't depend on execution outcome - and a failing query
    # is often failing *because* of the very pattern they fix (cross-join OOM,
    # SELECT * timing out). They run against the union of successful + failed.
    # Cost attribution on failure-derived improvement opportunities lands at
    # $0, but the rewrite itself is still actionable on the /failures page.
    #
    # Failure detection is defensive: BigQuery's INFORMATION_SCHEMA may surface
    # ``error_result`` as either NULL or as a struct whose fields are all
    # NULL. ``_is_failed_job`` treats both as "no failure".
    successful_jobs = [j for j in jobs if not _is_failed_job(j)]
    failed_jobs = [j for j in jobs if _is_failed_job(j)]
    failed_count = len(failed_jobs)
    if failed_count:
        logger.info(
            "audit detection: %d failed job(s) - issue rules skip them, "
            "improvement rules see them (%d successful + %d failed)",
            failed_count,
            len(successful_jobs),
            failed_count,
        )

    def _is_rule_active(entry) -> bool:
        # Audit-side toggle wins. Missing key → audit default of True
        # (NOT the cloud catalog's ``entry.enabled``). Some shipped
        # governor-core wheels return False for rules audit wants on;
        # falling back to that was suppressing entire rule classes on
        # fresh installs even though the settings page implied they
        # were live.
        if entry.rule_type in overrides:
            return bool(overrides[entry.rule_type])
        return True

    catalog = [entry for entry in get_detection_rule_catalog() if _is_rule_active(entry)]
    logger.info(
        "audit detection: %d rules enabled (of %d total catalog entries)",
        len(catalog),
        len(get_detection_rule_catalog()),
    )

    # Build a manifest-shaped dict from the scan's BigQueryJob rows so the
    # seven manifest-locked rules (dead_cte, dead_column intra-query,
    # dead_window_expression, unused_aggregation_output, redundant_order_by,
    # unused_join, manifest-guarded select_star) light up. See
    # specs/144-audit-query-only-rules/data-model.md.
    synthetic_manifest = build_synthetic_manifest(successful_jobs)
    logger.info(
        "audit detection: synthetic manifest built nodes=%d",
        len(synthetic_manifest["nodes"]),
    )

    # Index per-job dbt attribution + query hash via the cached query body.
    # BigQueryJob doesn't carry labels (FR-042), so we approximate using
    # the dbt comment-prefix path - same fallback the orchestrator uses.
    job_attribution: dict[str, dict] = {}
    for j in successful_jobs:
        # Build the same dict shape the rules helpers expect, on demand.
        as_dict = {
            "job_id": j.job_id,
            "query": j.query,
            "query_hashes": j.query_hashes,
        }
        # Audit-H7: cache hits and certain script-style jobs have no
        # ``query_hashes.normalized_literals`` entry. Without a synthetic
        # fallback, every NULL-hash job would land in a single bogus
        # roll-up bucket in ``AuditOpportunityMetadata.query_hash``
        # ("1247 occurrences" of "no hash"). Use ``job:<id>`` so each
        # hash-less job gets its own group - matches the findings UI's
        # grouping fallback at web/routes/findings.py.
        real_hash = extract_query_hash(as_dict)
        job_attribution[j.job_id] = {
            "is_dbt": is_dbt_originated(as_dict),
            "dbt_node_id": extract_dbt_node_id(as_dict),
            "dbt_invocation_id": extract_dbt_invocation_id(as_dict),
            "query_hash": real_hash if real_hash else f"job:{j.job_id}",
        }

    # Phase 1: run every enabled rule and collect candidates, sorted
    # into ``issue`` and ``improvement`` buckets per scan/categorization.py.
    issue_candidates: list = []
    improvements_by_table: dict[str, list] = {}

    for entry in catalog:
        try:
            rule = entry.rule_class()
        except Exception as exc:  # noqa: BLE001
            logger.warning("rule %s failed to instantiate: %s", entry.rule_type, exc)
            continue

        # The storage rule reads ``_storage_metrics`` from its threshold
        # dict (a sidecar override pattern). Audit's scan now ingests
        # TABLE_STORAGE + SCHEMATA_OPTIONS into ``TableStorageMetric``,
        # so we hydrate the threshold from the DB rather than passing an
        # empty list. The rule still tolerates an empty list, so a scan
        # where the storage sync failed simply produces zero storage
        # opportunities - never an error.
        thresholds = rule.get_thresholds()
        if rule.rule_type == "storage_billing_optimization":
            from governor_core.sync.models import TableStorageMetric

            thresholds["_storage_metrics"] = (
                session.query(TableStorageMetric)
                .filter(TableStorageMetric.config_id == config_id)
                .all()
            )

        # Improvement rules see successful + failed; issue rules see
        # successful only. See partition rationale at the top of this fn.
        rule_jobs = (
            successful_jobs + failed_jobs
            if entry.rule_type in IMPROVEMENT_RULE_TYPES
            else successful_jobs
        )
        try:
            candidates = rule.detect(
                jobs=rule_jobs,
                manifest_content=synthetic_manifest,
                thresholds=thresholds,
            )
        except Exception as exc:  # noqa: BLE001
            logger.warning(
                "rule %s.detect raised %s - skipping its findings",
                rule.rule_type,
                exc,
            )
            continue

        for cand in candidates:
            if cand.opportunity_type in IMPROVEMENT_RULE_TYPES:
                improvements_by_table.setdefault(cand.affected_table, []).append(cand)
            elif cand.opportunity_type in ISSUE_RULE_TYPES:
                issue_candidates.append(cand)
            else:
                # Rule isn't categorised - skip rather than persist a
                # row that won't render correctly in either UI surface.
                logger.debug(
                    "uncategorised rule_type=%s - skipping candidate",
                    cand.opportunity_type,
                )

    logger.info(
        "audit detection: %d issue candidate(s), %d improvement candidate(s) "
        "across %d affected tables",
        len(issue_candidates),
        sum(len(v) for v in improvements_by_table.values()),
        len(improvements_by_table),
    )

    # Phase 2a: persist every issue candidate. Each one gathers any
    # improvement firing on the same destination table and attaches them
    # under ``evidence_snapshot["_improvements"]`` so the issue's detail
    # page can still render the inline diff stack. The issue's own
    # template (e.g. ``SwitchStorageBillingTemplate``) goes to
    # ``_template_result`` for backward compatibility.
    created = 0
    for cand in issue_candidates:
        # Pass the full job list so improvement opportunities derived
        # from failed jobs can hydrate their template too.
        template_result = _try_apply_template(
            cand,
            jobs,
            synthetic_manifest,
            session=session,
            config_id=config_id,
        )

        # Improvements that apply to the same table. Dedupe by
        # ``rule_type`` so one rule firing N times for the same query
        # surfaces as a single card with an ``occurrences`` count
        # rather than N near-duplicate entries cluttering the page.
        #
        # Only attach improvements whose deterministic template
        # actually fires - template-less suggestions (text only, no
        # diff) are dropped here so the UI never shows a
        # "no template yet" card.
        attached_improvements: list[dict] = []
        seen_rule_types: set[str] = set()
        for imp_cand in improvements_by_table.get(cand.affected_table, []):
            if imp_cand.opportunity_type in seen_rule_types:
                for entry in attached_improvements:
                    if entry["rule_type"] == imp_cand.opportunity_type:
                        entry["occurrences"] = entry.get("occurrences", 1) + 1
                        break
                continue

            imp_template = _try_apply_template(
                imp_cand,
                jobs,
                synthetic_manifest,
                session=session,
                config_id=config_id,
            )
            if imp_template is None:
                continue

            seen_rule_types.add(imp_cand.opportunity_type)
            # ``confidence`` from the core candidate is intentionally
            # dropped here (audit H2): no consumer in audit reads it
            # for filtering, ordering, or rendering. Persisting a field
            # that doesn't gate behaviour is misleading.
            entry_dict = {
                "rule_type": imp_cand.opportunity_type,
                "explanation": imp_cand.explanation,
                "severity_score": int(imp_cand.severity_score or 0),
                "occurrences": 1,
                **imp_template,
            }
            attached_improvements.append(entry_dict)

        cand_evidence = dict(cand.evidence_snapshot or {})
        if template_result is not None:
            cand_evidence["_template_result"] = template_result
        if attached_improvements:
            cand_evidence["_improvements"] = attached_improvements

        if _persist_candidate(
            session,
            cand,
            cand_evidence,
            config_id=config_id,
            detection_job_id=detection_job_id,
            scan_run_id=scan_run_id,
            job_attribution=job_attribution,
        ):
            created += 1

    # Phase 2b: persist every improvement candidate as its own Opportunity
    # row so models without an issue still surface in /opportunities
    # ("opportunities for all models", not just for issues).
    #
    # Per-job rules (select_star, dead_cte, redundant_order_by, …)
    # emit ONE candidate per execution, each carrying
    # ``related_job_ids = [that_job_id]``. A daily-rebuilt model with
    # 99 executions in the scan window produces 99 candidates for the
    # same (rule, table). The OLD logic deduped at the candidate
    # level via a ``seen`` set - it kept only the first candidate
    # and silently dropped the other 98, so the persisted Opportunity
    # carried just one job's id in ``related_job_ids``. The
    # dashboard's per-job ``suggestion_count`` then showed 1 on a
    # single (effectively random) job and 0 on the other 98 firings
    # of the same query - the reported pattern.
    #
    # Fix: union the job_ids across ALL candidates for each
    # ``(rule_type, affected_table)`` BEFORE persisting, so every
    # job that triggered the rule gets attribution.
    merged_by_key: dict[tuple[str, str], "OpportunityCandidate"] = {}
    for table_cands in improvements_by_table.values():
        for imp_cand in table_cands:
            key = (imp_cand.opportunity_type, imp_cand.affected_table)
            if key not in merged_by_key:
                # First candidate for this key - keep it as the
                # canonical row. Copy the job-ids list so subsequent
                # mutations don't leak back into the original
                # candidate (rules don't expect their dataclass to be
                # mutated by the orchestrator).
                imp_cand.related_job_ids = list(imp_cand.related_job_ids or [])
                merged_by_key[key] = imp_cand
            else:
                # Same key - union job_ids in-place on the canonical
                # candidate. Preserve insertion order via dict-fromkeys
                # so the persisted JSON has a stable shape.
                canonical = merged_by_key[key]
                canonical.related_job_ids = list(
                    dict.fromkeys(
                        (canonical.related_job_ids or [])
                        + (imp_cand.related_job_ids or [])
                    )
                )

    for imp_cand in merged_by_key.values():
        template_result = _try_apply_template(
            imp_cand,
            jobs,
            synthetic_manifest,
            session=session,
            config_id=config_id,
        )
        # Drop template-less suggestions - without a deterministic
        # diff there's nothing actionable to show on the detail page.
        if template_result is None:
            continue

        cand_evidence = dict(imp_cand.evidence_snapshot or {})
        cand_evidence["_template_result"] = template_result

        if _persist_candidate(
            session,
            imp_cand,
            cand_evidence,
            config_id=config_id,
            detection_job_id=detection_job_id,
            scan_run_id=scan_run_id,
            job_attribution=job_attribution,
        ):
            created += 1

    session.flush()
    logger.info("audit detection: %d new opportunities", created)
    return created


def _persist_candidate(
    session,
    cand,
    evidence_snapshot: dict,
    *,
    config_id: str,
    detection_job_id: str,
    scan_run_id: str,
    job_attribution: dict[str, dict],
) -> bool:
    """Upsert an Opportunity row for ``cand``. Returns True when a fresh
    row was inserted (existing rows are updated in place).

    ``expected_savings`` is ALWAYS force-zeroed (it's a NOT NULL column
    on the cloud Opportunity model so something must go in). Audit
    refuses to surface savings figures at all - every UI / MCP path
    that used to render them has been stripped. The query-side rules'
    hardcoded-percentage figures (slot_contention = 20 %, etc.) never
    meant what the column name implied; the storage-billing rule's
    figure relied on pricing constants that are not regional-aware.
    Persisting zero keeps the schema honest and prevents downstream
    code from accidentally treating the field as authoritative.
    """
    from governor_audit.db.models import AuditOpportunityMetadata
    from governor_core.opportunities.models import Opportunity

    persisted_savings = Decimal("0")

    existing = (
        session.query(Opportunity)
        .filter(
            Opportunity.opportunity_type == cand.opportunity_type,
            Opportunity.affected_table == cand.affected_table,
            Opportunity.config_id == config_id,
        )
        .first()
    )
    if existing is not None:
        existing.severity_score = cand.severity_score
        existing.evidence_snapshot = evidence_snapshot
        existing.current_cost_estimate = cand.current_cost_estimate
        existing.expected_savings = persisted_savings
        # related_job_ids must UNION across firings, not overwrite.
        # Per-job rules (select_star, dead_cte, redundant_order_by, …)
        # emit one candidate per job each carrying ``related_job_ids =
        # [that_job_id]``. The dedup-by-(rule_type, affected_table)
        # path then merges them; if we overwrote here, only the LAST
        # candidate's job_id would survive - meaning the dashboard's
        # per-job ``suggestion_count`` would show 1 on a single
        # (typically random) job and 0 on the other 98 firings of
        # the same query. Per-table rules (slot_contention,
        # join_explosion, …) already pass the full job list in one
        # candidate, so the union is a no-op for them.
        existing.related_job_ids = list(
            dict.fromkeys(
                (existing.related_job_ids or []) + (cand.related_job_ids or [])
            )
        )
        existing.explanation = cand.explanation
        existing.last_detection_job_id = detection_job_id
        existing.last_detected_at = _utcnow()
        existing.occurrence_count = (existing.occurrence_count or 0) + 1
        return False

    opp = Opportunity(
        id=uuid.uuid4().hex,
        config_id=config_id,
        opportunity_type=cand.opportunity_type,
        affected_table=cand.affected_table,
        status="active",
        severity_score=cand.severity_score,
        evidence_snapshot=evidence_snapshot,
        current_cost_estimate=cand.current_cost_estimate,
        expected_savings=persisted_savings,
        explanation=cand.explanation,
        related_job_ids=cand.related_job_ids,
        dbt_model_name=cand.dbt_model_name,
        first_detection_job_id=detection_job_id,
        last_detection_job_id=detection_job_id,
        occurrence_count=1,
        last_detected_at=_utcnow(),
        consecutive_clean_days=0,
    )
    session.add(opp)
    session.flush()  # need opp.id for the sidecar

    attribution = next(
        (
            job_attribution.get(jid)
            for jid in (cand.related_job_ids or [])
            if jid in job_attribution
        ),
        None,
    ) or {}
    session.add(
        AuditOpportunityMetadata(
            opportunity_id=opp.id,
            scan_run_id=scan_run_id,
            is_dbt_originated=bool(attribution.get("is_dbt")),
            dbt_node_id=attribution.get("dbt_node_id"),
            dbt_invocation_id=attribution.get("dbt_invocation_id"),
            query_hash=attribution.get("query_hash"),
        )
    )
    return True


__all__ = ["run_audit_detection"]
