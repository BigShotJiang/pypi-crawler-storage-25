"""Build a synthetic dbt-manifest-shaped dict from BigQueryJob rows.

Audit's "no manifest" contract means seven rules in
``governor_core.opportunities.rules`` short-circuit out when called with
``manifest_content=None``. The detection logic those rules wrap is pure
sqlglot AST analysis over SQL text, which audit *does* have via
``BigQueryJob.query``. We close the gap by constructing an in-memory
dict that satisfies the manifest-iteration contract every analyzer
already expects, populated with one synthetic node per unique
``(destination_table, query_hash)`` pair.

The dict is never persisted, never serialised, and never exposed in
HTTP responses. It lives only inside one ``run_audit_detection`` call
frame and is garbage-collected when the scan completes.

See specs/144-audit-query-only-rules/data-model.md for the full schema
and rationale.
"""

from __future__ import annotations

import hashlib
import logging
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from governor_core.sync.models import BigQueryJob

logger = logging.getLogger("governor_audit.scan.synthetic_manifest")


def _strip_ddl_wrapper(sql: str) -> str:
    """Return the inner ``SELECT`` body of a ``CREATE … AS (…)`` query.

    BigQuery dbt models materialise via ``CREATE OR REPLACE TABLE …
    OPTIONS() AS (WITH … SELECT …)``. sqlglot parses this as
    ``Create → Subquery → Select``, so manifest-driven analysers
    walking ``ast.args["with_"]`` on a ``Create`` node never reach the
    real SELECT and silently return zero candidates. Stripping the
    wrapper lets ``analyze_all_dead_ctes`` and friends see the inner
    body that BigQuery actually executes.

    Falls back to the original SQL when:
      * sqlglot can't parse the input;
      * the SQL isn't a ``CREATE … AS (…)`` shape;
      * the inner re-emit is empty.
    """
    try:
        import sqlglot
        from sqlglot import exp
    except Exception:  # noqa: BLE001
        return sql

    try:
        tree = sqlglot.parse_one(sql, dialect="bigquery")
    except Exception:  # noqa: BLE001
        return sql
    if tree is None:
        return sql

    # If the root is already a Select, the SQL is plain - return
    # untouched so the diff and test fixtures keep the original
    # whitespace.
    if isinstance(tree, exp.Select):
        return sql

    # Walk Create → Subquery (and any Insert wrappers) until we hit a
    # Select / WithClause-bearing Select.
    node = tree
    unwrapped = False
    for _ in range(6):  # safety bound; real depth is 1-2
        if isinstance(node, exp.Select):
            break
        inner = node.args.get("expression") or node.args.get("this")
        if not isinstance(inner, exp.Expression):
            break
        node = inner
        unwrapped = True

    if not unwrapped or not isinstance(node, exp.Select):
        return sql

    rendered = node.sql(dialect="bigquery", pretty=True)
    return rendered or sql

# BigQuery's JOBS.query column is truncated past ~1 MB. Parsing past the
# truncation produces plausible-but-wrong AST. Skip jobs whose query is
# within 1 KB of the documented limit; sqlglot rarely chokes on smaller
# inputs and the heuristic is cheap.
_BQ_QUERY_BYTE_LIMIT = 1_000_000
_TRUNCATION_GUARD_BYTES = 1_000


def _query_hash(job: BigQueryJob) -> str:
    """Stable per-query identifier.

    Prefer ``query_hashes.normalized_literals`` from BigQuery's own
    ``query_info`` (so reruns with different WHERE constants share an
    identifier). Fall back to a SHA-256 of the stripped query text when
    ``query_hashes`` is empty (cache-hit jobs lack the field).
    """
    hashes = job.query_hashes if isinstance(job.query_hashes, dict) else {}
    bq_hash = hashes.get("normalized_literals")
    if isinstance(bq_hash, str) and bq_hash:
        return bq_hash
    return hashlib.sha256((job.query or "").strip().encode("utf-8")).hexdigest()


def build_synthetic_manifest(jobs: list[BigQueryJob]) -> dict:
    """Build a manifest-shaped dict from a scan run's BigQueryJob rows.

    The result has shape ``{"nodes": dict[str, dict]}`` with one entry
    per unique ``(destination_table, query_hash)``. Each node carries
    the eight fields documented in data-model.md.

    Skips:
      * jobs lacking ``destination_table`` or ``query`` (script
        statements, certain DDL - log INFO);
      * jobs whose ``destination_table`` does not split into exactly
        three dotted segments (log WARNING, FR-008);
      * jobs whose ``query`` is at or past BigQuery's 1 MB truncation
        boundary (log WARNING, FR-009 best-effort - BigQueryJob has no
        explicit ``query_truncated`` flag).
    """
    nodes: dict[str, dict] = {}
    seen: set[tuple[str, str]] = set()
    skipped_missing = 0
    skipped_segments = 0
    skipped_truncated = 0

    for job in jobs:
        if not job.destination_table or not job.query:
            skipped_missing += 1
            logger.debug(
                "synthetic_manifest skip job=%s reason=missing_table_or_query",
                job.job_id,
            )
            continue

        if len(job.query.encode("utf-8")) >= _BQ_QUERY_BYTE_LIMIT - _TRUNCATION_GUARD_BYTES:
            skipped_truncated += 1
            logger.warning(
                "synthetic_manifest skip job=%s reason=query_truncated_or_oversize",
                job.job_id,
            )
            continue

        parts = job.destination_table.split(".")
        if len(parts) != 3:
            skipped_segments += 1
            logger.warning(
                "synthetic_manifest skip job=%s reason=non_standard_destination dest=%s",
                job.job_id,
                job.destination_table,
            )
            continue
        database, schema, identifier = parts

        query_hash = _query_hash(job)
        dedup_key = (job.destination_table, query_hash)
        if dedup_key in seen:
            continue
        seen.add(dedup_key)

        unique_id = f"model.audit.{database}.{schema}.{identifier}.{query_hash}"
        # ``original_file_path`` is consumed by the deterministic
        # ``governor_core.solutions.templates`` registry to look up the
        # source SQL inside ``source_files``. Audit has no real files -
        # we use a synthetic ``audit://`` URI so the lookup succeeds and
        # the template can run unchanged.
        original_file_path = f"audit://q/{query_hash}.sql"
        # ``raw_code`` is the inner SELECT body - manifest-driven
        # analysers walk ``ast.args["with_"]`` on the parsed AST and
        # don't know how to descend a ``CREATE … AS (…)`` wrapper. The
        # fallback is the original ``job.query`` so analysers that
        # tolerate the wrapper still see something.
        raw_code = _strip_ddl_wrapper(job.query)
        nodes[unique_id] = {
            "unique_id": unique_id,
            # Use the destination table's identifier as the display name so
            # that ``correlate_dbt_model`` (which returns ``node.get("name")``
            # in governor_core/opportunities/rules/base.py) propagates a
            # human-readable table name into ``Opportunity.dbt_model_name``
            # rather than a synthetic ``q_<hash>`` placeholder. The
            # query_hash already lives in ``unique_id`` for dedup-keying.
            "name": identifier,
            "resource_type": "model",
            "config": {"materialized": "table"},
            "raw_code": raw_code,
            "original_file_path": original_file_path,
            "database": database,
            "schema": schema,
            "identifier": identifier,
        }

    # Spec 148 Layer 1 - populate ``depends_on.nodes`` from
    # ``BigQueryJob.referenced_tables``. Without this, every
    # upstream-targeting governor_core analyser (spec 051's
    # cluster_by, spec 131's partition_by, …) sees empty depends_on
    # in audit and silently short-circuits. The lineage signal IS
    # cached on every BigQueryJob row - it just wasn't surfaced to
    # the manifest. This second pass wires the edges using the
    # nodes we just built.
    _populate_depends_on(nodes, jobs)

    if skipped_missing or skipped_segments or skipped_truncated:
        logger.info(
            "synthetic_manifest summary: nodes=%d skipped_missing=%d "
            "skipped_segments=%d skipped_truncated=%d",
            len(nodes),
            skipped_missing,
            skipped_segments,
            skipped_truncated,
        )

    return {"nodes": nodes}


def _populate_depends_on(
    nodes: dict[str, dict], jobs: list[BigQueryJob]
) -> None:
    """Wire ``depends_on.nodes`` on every consumer node from each job's
    ``referenced_tables`` list.

    The node lookup is keyed on ``destination_table`` (project.dataset.table)
    rather than ``unique_id`` because referenced_tables only carry the
    fully-qualified name, not the per-query hash. A single destination
    can have multiple nodes (one per distinct query body); we link each
    consumer node to every producer node sharing the referenced
    destination - when downstream analysers want a specific query
    version they walk ``raw_code`` instead.

    Self-references are dropped (a CTAS that reads its own previous
    version isn't a lineage edge worth modelling). External
    references - referenced_tables entries that don't appear as a
    destination in this scan window - are silently skipped; an
    upstream-targeting analyser would have nothing to do with them
    anyway.
    """
    # Build a destination_table → list[unique_id] lookup. Same
    # destination + multiple query versions = multiple unique_ids.
    by_dest: dict[str, list[str]] = {}
    for uid, node in nodes.items():
        dest_key = ".".join((node["database"], node["schema"], node["identifier"]))
        by_dest.setdefault(dest_key, []).append(uid)

    # Group consumer nodes by destination so we can apply the same
    # depends_on set to every query-version of the same table.
    upstream_by_dest: dict[str, set[str]] = {}
    for job in jobs:
        if not job.destination_table or job.destination_table not in by_dest:
            continue
        # ``getattr`` with default so test fakes that omit the column
        # (and any future BigQueryJob shapes) don't AttributeError.
        refs = getattr(job, "referenced_tables", None) or []
        for ref in refs:
            ref_key = _coerce_referenced_table(ref)
            if ref_key is None or ref_key == job.destination_table:
                # Skip externals (None) and self-references.
                continue
            for upstream_uid in by_dest.get(ref_key, []):
                upstream_by_dest.setdefault(job.destination_table, set()).add(
                    upstream_uid
                )

    # Apply: every node sharing the consumer destination gets the
    # same depends_on.nodes (sorted for stable rendering / diffing).
    for dest, uids in by_dest.items():
        upstreams = upstream_by_dest.get(dest)
        if not upstreams:
            continue
        sorted_upstreams = sorted(upstreams)
        for uid in uids:
            existing = nodes[uid].setdefault(
                "depends_on", {"nodes": [], "macros": []}
            )
            # Preserve any pre-existing entries (defensive - none today,
            # but cheap insurance against a future caller pre-populating).
            existing["nodes"] = sorted(set(existing.get("nodes", [])) | set(sorted_upstreams))


def _coerce_referenced_table(ref: object) -> str | None:
    """Normalise a single ``referenced_tables`` entry to ``project.dataset.table``.

    BigQuery returns referenced_tables as a list of structs with
    ``project_id`` / ``dataset_id`` / ``table_id`` keys; the SQLAlchemy
    JSONB column persists them as plain dicts. Some older rows may
    carry the keys camelCase'd (``projectId`` etc.) - handle both.
    Returns ``None`` for anything we can't parse.
    """
    if ref is None:
        return None
    if isinstance(ref, str):
        return ref
    if isinstance(ref, dict):
        proj = ref.get("project_id") or ref.get("projectId") or ""
        ds = ref.get("dataset_id") or ref.get("datasetId") or ""
        tbl = ref.get("table_id") or ref.get("tableId") or ""
        parts = [p for p in (proj, ds, tbl) if p]
        if len(parts) == 3:
            return ".".join(parts)
    return None


__all__ = ["build_synthetic_manifest"]
