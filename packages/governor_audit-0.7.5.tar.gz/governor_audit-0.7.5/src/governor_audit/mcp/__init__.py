"""Spec 152 - read-only Model Context Protocol server for governor-audit.

Exposes typed query tools against the local SQLite cache
(``~/.governor-audit/state.db``) so MCP-capable chat clients
(Claude Desktop, Cursor, etc.) can answer ad-hoc questions about the
audited workload - "biggest opportunity?", "slot contention this week?",
"partition recommendation for X?" - by calling typed Python tools
instead of clicking through the web UI.

Trust posture: stdio-only (no inbound socket), strictly read-only
(no DB writes, no config writes), BQ-call-free (the catch-all in
``tests/unit/test_billing_project_wiring.py`` will fail the build if
anyone adds a ``build_default_client`` call inside this subpackage).
"""
