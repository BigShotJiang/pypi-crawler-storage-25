"""Structured ``ToolError`` factory helpers.

Every MCP tool that can fail a precondition returns one of these
instead of raising. The MCP SDK serialises them as JSON; chat
clients branch on the ``code`` field to phrase the failure
consistently regardless of which tool errored.
"""

from __future__ import annotations

from governor_audit.mcp.schemas import ToolError


def not_initialised() -> ToolError:
    """``~/.governor-audit/state.db`` doesn't exist."""
    return ToolError(
        code="audit_not_initialised",
        message=(
            "governor-audit hasn't been initialised on this machine. The "
            "local SQLite cache at ~/.governor-audit/state.db doesn't exist."
        ),
        remediation="Run `governor-audit init` then `governor-audit scan`.",
    )


def schema_incompatible(detail: str | None = None) -> ToolError:
    """DB exists but the expected tables are missing - usually means
    the user has an older audit version pinned vs the MCP server."""
    base = (
        "The audit DB schema doesn't match this MCP server's expectations. "
        "This usually means the audit package was upgraded without "
        "running its lightweight migrations."
    )
    return ToolError(
        code="schema_incompatible",
        message=f"{base} ({detail})" if detail else base,
        remediation=(
            "Run `governor-audit migrate` (or any audit web request will "
            "trigger the lightweight migration automatically)."
        ),
    )


def no_successful_scan() -> ToolError:
    """DB initialised but no ``ScanRun.status == 'succeeded'`` rows."""
    return ToolError(
        code="no_successful_scan",
        message=(
            "No successful scan in the local cache yet. Tools that read "
            "scanned data need at least one scan to have completed."
        ),
        remediation="Run `governor-audit scan` (typical default: --days 7).",
    )


def table_not_found(table_full_name: str) -> ToolError:
    """Per-table lookup hit a destination_table that isn't in the cache."""
    return ToolError(
        code="table_not_found",
        message=(
            f"No cached executions for `{table_full_name}` in the latest "
            "scan window."
        ),
        remediation=(
            "Verify the table identifier is fully-qualified "
            "(project.dataset.table); try `list_top_cost_drivers` to see "
            "which tables ARE in the cache."
        ),
    )


def unknown_metric(metric_name: str, valid_keys: list[str]) -> ToolError:
    """``methodology()`` called with an unknown metric_name. Embeds the
    valid key list in the message so the chat can re-ask cleanly."""
    return ToolError(
        code="unknown_metric",
        message=(
            f"`{metric_name}` is not a known methodology metric. Valid "
            f"metric_names: {', '.join(sorted(valid_keys))}."
        ),
        remediation=(
            "Call `methodology` again with one of the listed metric_names."
        ),
    )


def db_locked() -> ToolError:
    """Transient SQLite write-lock contention (usually the web UI in
    mid-write). Caller should retry once."""
    return ToolError(
        code="db_locked",
        message=(
            "The audit SQLite database is currently locked by another "
            "process (most often the governor-audit web UI mid-write)."
        ),
        remediation="Retry in a few seconds.",
    )


def internal_error(detail: str) -> ToolError:
    """Catch-all fall-through for uncaught exceptions inside a tool.
    Always logged server-side; the chat client just sees this
    structured shape."""
    return ToolError(
        code="internal_error",
        message=(
            "The MCP tool raised an unexpected exception. This is a bug "
            f"in the audit. Detail: {detail[:200]}"
        ),
        remediation=(
            "Re-run the question; if it persists, file an issue with "
            "the audit logs."
        ),
    )


__all__ = [
    "not_initialised",
    "schema_incompatible",
    "no_successful_scan",
    "table_not_found",
    "unknown_metric",
    "db_locked",
    "internal_error",
]
