"""Canonical methodology content for the audit.

Single source of truth for **both** the MCP ``methodology()`` tool
(spec 152) AND the web ``/methodology`` page. The web template
iterates the ``METHODOLOGY`` dict to render its accordion; the MCP
tool returns the same entry as ``MethodologyOut``.

Adding a new entry: define it here. The web page picks it up on
the next render; the MCP tool exposes it the next time the server
starts. There is no second file to update.

Starter scope (spec 152 US1): the three metrics named in the spec's
P1 acceptance scenarios (AS-1 / AS-4). The remaining metrics
(consumption_spend, optimisable_spend, bytes_scanned, slot_time,
partition_cluster_recommendations, scan_window, opportunity_types)
land in US3 as the dict is fully built out + the template refactored.
"""

from __future__ import annotations

from governor_audit.mcp.schemas import MethodologyEntry


METHODOLOGY: dict[str, MethodologyEntry] = {
    "total_spend": MethodologyEntry(
        title="Total Spend",
        source_field="INFORMATION_SCHEMA.JOBS_BY_PROJECT.total_bytes_billed",
        formula="total_bytes_billed / 2^40 × $6.25",
        description=(
            "What the queries in the scan window would have cost at "
            "BigQuery's published on-demand rate ($6.25 per TiB, US / EU "
            "multi-region, May 2026). Summed across every cached job."
        ),
        caveats=[
            "On-demand pricing only. If your project uses BigQuery "
            "reservations (committed slots), this number is what the "
            "queries would have cost on on-demand - not what you "
            "actually paid.",
            "Pricing is hard-coded to $6.25/TiB. Regional variations "
            "(Asia, EU) are not applied.",
            "BigQuery rounds total_bytes_billed up to 10 MB per query "
            "and 1 KB per table - tiny queries always look like 10 MB.",
            "Cached query results (cache_hit = TRUE) have "
            "total_bytes_billed = 0 and therefore $0 cost even though "
            "the query ran.",
        ],
        related_metrics=[
            "build_spend",
            "consumption_spend",
            "flagged_jobs",
            "bytes_scanned",
        ],
    ),
    "build_spend": MethodologyEntry(
        title="Build Spend",
        source_field=(
            "INFORMATION_SCHEMA.JOBS_BY_PROJECT.total_bytes_billed "
            "(filtered to build-classified jobs)"
        ),
        formula=(
            "Σ total_cost across jobs where the workload classifier "
            "labelled the job 'build' (statement_type = "
            "CREATE_TABLE_AS_SELECT / MERGE / INSERT / UPDATE / DELETE "
            "or a CREATE materialised view)"
        ),
        description=(
            "Spend on jobs that materialise data - your warehouse-build "
            "side of the workload. Everything that writes (CTAS, MERGE, "
            "INSERT, UPDATE, DELETE) buckets here; SELECT-only consumers "
            "are excluded (they show up under Consumption Spend)."
        ),
        caveats=[
            "Classification is by statement_type, not by who ran the job - "
            "an analyst running CTAS still counts as 'build' work.",
            "MERGE statements with low DML volume can be cheap; the "
            "classifier doesn't gate on bytes written.",
        ],
        related_metrics=["total_spend", "consumption_spend"],
    ),
    "flagged_jobs": MethodologyEntry(
        title="Flagged Jobs",
        source_field=(
            "Count of cached BigQueryJob rows that appear in "
            "Opportunity.related_job_ids for at least one active "
            "opportunity."
        ),
        formula="distinct count of job_id where at least one active opportunity references it",
        description=(
            "Number of cached query executions that hit at least one "
            "detection rule. Pairs with Optimisable Spend (which sums "
            "their dollar cost) - 'how many jobs is the audit telling "
            "you to act on'."
        ),
        caveats=[
            "A single job can fire multiple rules and still counts once.",
            "Reflects the scan window only; older jobs (outside the "
            "INFORMATION_SCHEMA retention boundary) aren't represented.",
            "Suggestion-only opportunities count too - not just issues.",
        ],
        related_metrics=["optimisable_spend", "total_spend"],
    ),
}


__all__ = ["METHODOLOGY"]
