"""Pydantic v2 input/output models for every MCP tool.

The MCP SDK serialises these as JSON and advertises their JSON schemas
to the chat client so it can pick the right tool for ambiguous questions.

Naming convention: ``<Tool>In`` for input, ``<Tool>Out`` for output.
Shared shapes (``ToolError``, ``LogicalJobRow``, ``WindowSpec``,
``MethodologyEntry``, ``ScanSummary``) live at the top of this module.
"""

from __future__ import annotations

from datetime import datetime
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field


# ── Shared shapes ─────────────────────────────────────────────────────


class ToolError(BaseModel):
    """Structured failure response returned by every tool when a
    precondition is not met. Chat clients can branch on ``code``
    without parsing free-form messages."""

    model_config = ConfigDict(frozen=True)

    code: Literal[
        "audit_not_initialised",
        "schema_incompatible",
        "no_successful_scan",
        "table_not_found",
        "unknown_metric",
        "db_locked",
        "internal_error",
    ]
    message: str
    remediation: str


class WindowSpec(BaseModel):
    """Optional time-window override for tools that filter by
    ``creation_time``. Default ``None`` means "use the most recent
    successful scan's window"."""

    since_days: int | None = Field(
        default=None,
        ge=1,
        le=180,
        description=(
            "Restrict to jobs whose creation_time is within this many "
            "days of now. Capped at 180 (the BigQuery "
            "INFORMATION_SCHEMA retention boundary)."
        ),
    )


class LogicalJobRow(BaseModel):
    """Canonical row for logical-job-aggregated outputs.

    Matches the shape ``_aggregate_totals_and_top_jobs`` returns
    (spec 151 polish): builds aggregate by ``destination_table``,
    consumption by ``query_hashes.normalized_literals``. Cost / bytes /
    slot are summed across executions; issue / suggestion counts
    reflect the latest execution only.
    """

    destination_table: str | None = Field(
        default=None,
        description="Destination table for build jobs; None for consumption-only logical jobs.",
    )
    query_hash: str | None = Field(
        default=None,
        description="Set when ``destination_table`` is None - the BigQuery normalized_literals hash.",
    )
    short_label: str
    workload_kind: Literal["build", "consumption", "other"]
    cost_usd: float
    cost_share_pct: float = Field(ge=0.0, le=100.0)
    bytes_processed: int = Field(ge=0)
    slot_time_ms: int = Field(ge=0)
    execution_count: int = Field(ge=1)
    issue_count: int = Field(
        ge=0,
        description="Issue count from the latest execution only (current state to act on).",
    )
    suggestion_count: int = Field(ge=0)
    latest_creation_time: datetime
    is_dbt_originated: bool
    opportunity_id: str | None


class ScanSummary(BaseModel):
    """Compact summary of one ``ScanRun`` row - what most tools cite
    as the "scan_id that produced these results"."""

    scan_id: str
    started_at: datetime
    completed_at: datetime | None
    lookback_days: int
    fetched_job_count: int
    opportunity_count: int | None
    actual_cost_usd: float | None


# ── methodology() - shared between Phase-2 starter dict and the tool ──


class MethodologyEntry(BaseModel):
    """One canonical methodology entry. Lives in ``methodology_text.py``
    as the source of truth for both the MCP tool and the web
    ``/methodology`` page."""

    title: str
    source_field: str | None = None
    formula: str | None = None
    description: str
    caveats: list[str] = Field(default_factory=list)
    related_metrics: list[str] = Field(default_factory=list)


class MethodologyIn(BaseModel):
    metric_name: str = Field(
        description=(
            "One of the keys in the audit methodology dict. Call this tool "
            "with an invalid name to get the full list of valid keys back "
            "in the error response."
        )
    )


class MethodologyOut(BaseModel):
    """Same fields as ``MethodologyEntry`` plus ``metric_name`` so the
    chat can quote it back to the user without losing context."""

    metric_name: str
    title: str
    source_field: str | None = None
    formula: str | None = None
    description: str
    caveats: list[str]
    related_metrics: list[str]


# ── list_top_opportunities ────────────────────────────────────────────


class OpportunityRow(LogicalJobRow):
    """Logical-job row enriched with opportunity-specific fields."""

    opportunity_type: str
    severity_score: int
    affected_table: str | None
    explanation: str = Field(
        default="",
        description="First 500 chars of the opportunity's explanation.",
    )


class TopOpportunitiesIn(BaseModel):
    limit: int = Field(default=20, ge=1, le=100)
    opportunity_type: str | None = Field(
        default=None,
        description=(
            "Filter to a specific rule (e.g. 'slot_contention'). Call "
            "``methodology(metric_name='opportunity_types')`` for the "
            "list of valid values."
        ),
    )
    min_severity: int | None = Field(default=None, ge=0, le=100)


class TopOpportunitiesOut(BaseModel):
    opportunities: list[OpportunityRow]
    total_active: int
    scan_id: str


# ── list_top_cost_drivers ─────────────────────────────────────────────


class TopCostDriversIn(BaseModel):
    limit: int = Field(default=20, ge=1, le=100)
    workload_kind: Literal["build", "consumption"] | None = None


class TopCostDriversOut(BaseModel):
    rows: list[LogicalJobRow]
    scan_id: str
    scan_window_days: int
    grand_total_cost_usd: float


# ── find_jobs_with_rule ───────────────────────────────────────────────


class FindJobsWithRuleIn(WindowSpec):
    rule_type: str
    limit: int = Field(default=50, ge=1, le=500)


class FindJobsWithRuleOut(BaseModel):
    rows: list[LogicalJobRow]
    rule_type: str
    total_matching: int


# ── cohort_for_table ──────────────────────────────────────────────────


class CohortVersionRow(BaseModel):
    version_index: int = Field(ge=1)
    first_seen: datetime
    last_seen: datetime
    execution_count: int = Field(ge=1)
    total_cost_usd: float
    total_slot_ms: int = Field(ge=0)
    resolved_rules: list[str] = Field(default_factory=list)
    newly_introduced_rules: list[str] = Field(default_factory=list)
    diff_against_previous: list[str] | None = None


class CohortForTableIn(BaseModel):
    table_full_name: str = Field(
        description="Fully-qualified BigQuery table identifier: 'project.dataset.table'."
    )


class CohortForTableOut(BaseModel):
    table_full_name: str
    total_executions: int
    total_cost_usd: float
    days_with_executions: int
    versions: list[CohortVersionRow]


# ── layout_recommendation_for_table + list_layout_recommendations ─────


class LayoutCandidateRow(BaseModel):
    column_name: str
    usage_type: Literal["filter", "range_filter", "equi_join", "group_by"]
    score: float
    cost_share: float = Field(ge=0.0, le=1.0)
    contributing_job_count: int = Field(ge=0)
    cluster_rank: int | None = Field(default=None, ge=1, le=4)
    is_partition_pick: bool = False


class LayoutCaveat(BaseModel):
    code: str
    message: str


class LayoutBqSecondOpinionOut(BaseModel):
    bq_recommended_columns: list[str]
    bq_description: str | None = None
    agrees_with_audit_top_pick: bool


class LayoutForTableIn(BaseModel):
    table_full_name: str


class LayoutForTableOut(BaseModel):
    table_full_name: str
    recommended_partition_column: str | None
    recommended_partition_type: str | None
    cluster_columns: list[str]
    candidates: list[LayoutCandidateRow]
    apply_sql: str
    rollback_sql: str
    caveats: list[LayoutCaveat]
    table_total_bytes: int
    table_total_cost_in_window_usd: float
    is_currently_partitioned: bool
    bq_second_opinion: LayoutBqSecondOpinionOut | None = None


class LayoutSummaryRow(BaseModel):
    table_full_name: str
    recommended_partition_column: str | None
    cluster_columns: list[str]
    table_total_bytes: int
    table_total_cost_in_window_usd: float
    contributing_job_count: int
    caveat_count: int


class ListLayoutsIn(BaseModel):
    min_size_gb: int = Field(default=10, ge=1, le=10_000)
    limit: int = Field(default=20, ge=1, le=200)


class ListLayoutsOut(BaseModel):
    recommendations: list[LayoutSummaryRow]
    scan_id: str
    scan_window_days: int


# ── scan_status ───────────────────────────────────────────────────────


class ScanStatusOut(BaseModel):
    """Note: this is the one tool where ``latest_succeeded_scan = None``
    is a legitimate response (audit installed but never scanned). The
    error path ``no_successful_scan`` is NOT used here."""

    in_progress: bool
    current_phase: Literal[
        "starting",
        "fetching",
        "persisting",
        "detection",
        "recommendations",
    ] | None = None
    started_at: datetime | None = None
    completed_at: datetime | None = None
    latest_succeeded_scan: ScanSummary | None = None


# ── recent_failures ───────────────────────────────────────────────────


class FailureGroupRow(BaseModel):
    query_hash: str
    representative_job_id: str
    failure_reason: str
    failure_count: int = Field(ge=1)
    total_slot_ms: int = Field(ge=0)
    earliest_seen: datetime
    latest_seen: datetime
    destination_table: str | None


class RecentFailuresIn(WindowSpec):
    limit: int = Field(default=50, ge=1, le=500)


class RecentFailuresOut(BaseModel):
    failures: list[FailureGroupRow]
    total_failures_in_window: int


# ── Cluster A: Temporal ───────────────────────────────────────────────


class CostBreakdown(BaseModel):
    """Cost / volume / count rolled up by classification."""

    cost_usd: float
    bytes_processed: int = Field(ge=0)
    slot_ms: int = Field(ge=0)
    job_count: int = Field(ge=0)


class CostForDayIn(BaseModel):
    date: str = Field(
        description=(
            "UTC date in ISO format ``YYYY-MM-DD``. Use 'today' for the "
            "current UTC date, or 'yesterday' for the previous one."
        )
    )


class CostForDayOut(BaseModel):
    date: str
    total: CostBreakdown
    build: CostBreakdown
    consumption: CostBreakdown
    other: CostBreakdown
    flagged_jobs_count: int = Field(
        ge=0,
        description="Number of distinct logical jobs on this day with ≥1 active opportunity.",
    )


class DailyCostPoint(BaseModel):
    day: str
    cost_usd: float
    bytes_processed: int = Field(ge=0)
    slot_ms: int = Field(ge=0)
    job_count: int = Field(ge=0)


class DailyCostSummaryIn(BaseModel):
    since_days: int = Field(
        default=7,
        ge=1,
        le=180,
        description="Number of recent days to include. Days with no executions are SKIPPED in the output.",
    )


class DailyCostSummaryOut(BaseModel):
    points: list[DailyCostPoint]
    total_cost_usd: float
    days_with_executions: int


class CostComparedToPreviousPeriodIn(BaseModel):
    period_days: int = Field(
        default=7,
        ge=1,
        le=90,
        description=(
            "Length of EACH period in days. The tool compares the "
            "most-recent ``period_days`` to the immediately-prior "
            "``period_days``. E.g. period_days=7 compares last 7 days "
            "to the 7 days before that."
        ),
    )


class CostComparedToPreviousPeriodOut(BaseModel):
    current_period: CostBreakdown
    previous_period: CostBreakdown
    current_period_start: datetime
    current_period_end: datetime
    previous_period_start: datetime
    previous_period_end: datetime
    delta_cost_usd: float
    delta_pct: float | None = Field(
        default=None,
        description="Percent change. None when previous period had zero cost (division-by-zero).",
    )


# ── Cluster B: People ─────────────────────────────────────────────────


class UserCostRow(BaseModel):
    user_email: str | None
    cost_usd: float
    job_count: int = Field(ge=1)
    bytes_processed: int = Field(ge=0)
    slot_ms: int = Field(ge=0)
    flagged_job_count: int = Field(
        ge=0,
        description="Number of this user's jobs with ≥1 active opportunity.",
    )


class TopUsersByCostIn(BaseModel):
    limit: int = Field(default=20, ge=1, le=200)


class TopUsersByCostOut(BaseModel):
    rows: list[UserCostRow]
    total_cost_usd: float
    distinct_users: int


class UserRuleCountRow(BaseModel):
    user_email: str | None
    affected_table_count: int = Field(
        ge=1,
        description="Distinct tables where this user's jobs tripped the rule.",
    )
    job_count: int = Field(ge=1)
    cost_usd: float


class TopUsersByRuleCountIn(BaseModel):
    rule_type: str
    limit: int = Field(default=20, ge=1, le=200)


class TopUsersByRuleCountOut(BaseModel):
    rule_type: str
    rows: list[UserRuleCountRow]


class UserWorkloadSummaryIn(BaseModel):
    user_email: str


class UserWorkloadRuleHit(BaseModel):
    rule_type: str
    table_count: int = Field(ge=1)
    job_count: int = Field(ge=1)


class UserTopTable(BaseModel):
    table_full_name: str
    cost_usd: float
    job_count: int = Field(ge=1)


class UserWorkloadSummaryOut(BaseModel):
    user_email: str
    total_cost_usd: float
    total_jobs: int
    dbt_cost_usd: float
    non_dbt_cost_usd: float
    flagged_job_count: int
    top_tables: list[UserTopTable]
    rule_hits: list[UserWorkloadRuleHit]


# ── Cluster C: Filter/Search ──────────────────────────────────────────


class JobBriefRow(BaseModel):
    job_id: str
    user_email: str | None
    destination_table: str | None
    creation_time: datetime
    cost_usd: float
    bytes_processed: int = Field(ge=0)
    slot_ms: int = Field(ge=0)
    duration_ms: int = Field(ge=0)
    statement_type: str | None
    cache_hit: bool = False
    is_failed: bool = False


class SearchJobsIn(WindowSpec):
    min_cost_usd: float | None = Field(default=None, ge=0)
    max_cost_usd: float | None = Field(default=None, ge=0)
    min_bytes: int | None = Field(default=None, ge=0)
    max_bytes: int | None = Field(default=None, ge=0)
    min_duration_seconds: int | None = Field(default=None, ge=0)
    max_duration_seconds: int | None = Field(default=None, ge=0)
    statement_type: str | None = Field(
        default=None,
        description="BigQuery statement_type filter, e.g. 'SELECT', 'MERGE', 'CREATE_TABLE_AS_SELECT'.",
    )
    user_email: str | None = Field(default=None)
    cache_hit: bool | None = Field(default=None)
    sql_contains: str | None = Field(
        default=None,
        description=(
            "Case-insensitive substring match against the query text. "
            "Capped at 200 chars to prevent abuse."
        ),
        max_length=200,
    )
    limit: int = Field(default=50, ge=1, le=500)


class SearchJobsOut(BaseModel):
    rows: list[JobBriefRow]
    total_matching: int


class FindJobsByDestinationIn(BaseModel):
    destination_table: str = Field(
        description="Fully-qualified BigQuery table: 'project.dataset.table'."
    )
    limit: int = Field(default=50, ge=1, le=500)


class FindJobsByDestinationOut(BaseModel):
    destination_table: str
    rows: list[JobBriefRow]
    total_executions: int
    total_cost_usd: float


# ── Cluster D: Rule analytics ─────────────────────────────────────────


class RuleSummaryRow(BaseModel):
    rule_type: str
    opportunity_count: int = Field(ge=1)
    total_cost_usd: float
    top_affected_tables: list[str] = Field(
        description="Up to 3 affected_table names, ranked by per-table opportunity cost.",
    )


class RuleSummaryOut(BaseModel):
    rules: list[RuleSummaryRow]
    total_opportunities: int


class WorstOffendersPerRuleIn(BaseModel):
    rule_type: str
    limit: int = Field(default=10, ge=1, le=100)


class WorstOffenderRow(BaseModel):
    affected_table: str
    cost_usd: float
    job_count: int = Field(ge=1)
    severity_score: int = Field(ge=0, le=100)
    opportunity_id: str


class WorstOffendersPerRuleOut(BaseModel):
    rule_type: str
    rows: list[WorstOffenderRow]


# ── Cluster E: Table-level ────────────────────────────────────────────


class OpportunityBriefRow(BaseModel):
    opportunity_id: str
    rule_type: str
    severity_score: int = Field(ge=0, le=100)
    current_cost_estimate_usd: float
    explanation: str = Field(
        default="",
        description="First 500 chars of the opportunity's explanation.",
    )
    is_issue: bool


class OpportunitiesForTableIn(BaseModel):
    table_full_name: str


class OpportunitiesForTableOut(BaseModel):
    table_full_name: str
    issues: list[OpportunityBriefRow]
    suggestions: list[OpportunityBriefRow]
    total_count: int


class TableSummaryIn(BaseModel):
    table_full_name: str


class TableSummaryOut(BaseModel):
    table_full_name: str
    total_cost_usd: float
    total_executions: int
    distinct_versions: int
    days_with_executions: int
    latest_execution_at: datetime | None
    issue_count: int
    suggestion_count: int
    has_layout_recommendation: bool
    is_currently_partitioned: bool | None = Field(
        default=None,
        description="None when no LayoutRecommendation row exists for this table.",
    )


# ── Cluster F: Workload ───────────────────────────────────────────────


class WorkloadBreakdownOut(BaseModel):
    build: CostBreakdown
    consumption: CostBreakdown
    other: CostBreakdown
    total_cost_usd: float
    build_pct: float = Field(ge=0.0, le=100.0)
    consumption_pct: float = Field(ge=0.0, le=100.0)
    other_pct: float = Field(ge=0.0, le=100.0)


class DbtOriginSummaryOut(BaseModel):
    dbt: CostBreakdown
    non_dbt: CostBreakdown
    dbt_pct: float = Field(ge=0.0, le=100.0)
    top_non_dbt_users: list[UserCostRow] = Field(
        description="Top 5 non-dbt users by cost. Empty when 100% of spend is dbt.",
    )


# ── Cluster H: Storage ────────────────────────────────────────────────


class DatasetStorageRow(BaseModel):
    dataset_name: str
    billing_model: str = Field(description="LOGICAL or PHYSICAL")
    active_logical_bytes: int = Field(ge=0)
    long_term_logical_bytes: int = Field(ge=0)
    active_physical_bytes: int = Field(ge=0)
    long_term_physical_bytes: int = Field(ge=0)
    table_count: int = Field(ge=0)
    monthly_cost_usd: float
    compression_ratio: float = Field(
        ge=0.0,
        description="logical_bytes / physical_bytes. > 1 means physical billing would be cheaper.",
    )


class DatasetStorageSummaryOut(BaseModel):
    datasets: list[DatasetStorageRow]
    total_monthly_cost_usd: float
    physical_datasets: int
    logical_datasets: int


# ── Cluster I: Config ─────────────────────────────────────────────────


class AuditConfigSummaryOut(BaseModel):
    gcp_project_id: str
    bigquery_region: str
    billing_project_id: str | None
    lookback_days: int
    min_solution_cost_usd: float
    dbt_only_default: bool
    detection_top_n_jobs: int | None
    enabled_rules: list[str] = Field(
        description="Detection rule types enabled in the active config (catalog defaults + per-rule overrides).",
    )
    disabled_rules: list[str]
    llm_provider: str | None = Field(default=None)
    llm_model: str | None = Field(default=None)
    audit_version: str


__all__ = [
    # Shared
    "ToolError",
    "WindowSpec",
    "LogicalJobRow",
    "ScanSummary",
    "MethodologyEntry",
    "MethodologyIn",
    "MethodologyOut",
    # Tool I/O
    "TopOpportunitiesIn",
    "TopOpportunitiesOut",
    "OpportunityRow",
    "TopCostDriversIn",
    "TopCostDriversOut",
    "FindJobsWithRuleIn",
    "FindJobsWithRuleOut",
    "CohortForTableIn",
    "CohortForTableOut",
    "CohortVersionRow",
    "LayoutForTableIn",
    "LayoutForTableOut",
    "LayoutCandidateRow",
    "LayoutCaveat",
    "LayoutBqSecondOpinionOut",
    "ListLayoutsIn",
    "ListLayoutsOut",
    "LayoutSummaryRow",
    "ScanStatusOut",
    "RecentFailuresIn",
    "RecentFailuresOut",
    "FailureGroupRow",
    # Cluster A - Temporal
    "CostBreakdown",
    "CostForDayIn",
    "CostForDayOut",
    "DailyCostPoint",
    "DailyCostSummaryIn",
    "DailyCostSummaryOut",
    "CostComparedToPreviousPeriodIn",
    "CostComparedToPreviousPeriodOut",
    # Cluster B - People
    "UserCostRow",
    "TopUsersByCostIn",
    "TopUsersByCostOut",
    "UserRuleCountRow",
    "TopUsersByRuleCountIn",
    "TopUsersByRuleCountOut",
    "UserWorkloadSummaryIn",
    "UserWorkloadSummaryOut",
    "UserWorkloadRuleHit",
    "UserTopTable",
    # Cluster C - Filter / Search
    "JobBriefRow",
    "SearchJobsIn",
    "SearchJobsOut",
    "FindJobsByDestinationIn",
    "FindJobsByDestinationOut",
    # Cluster D - Rule analytics
    "RuleSummaryRow",
    "RuleSummaryOut",
    "WorstOffendersPerRuleIn",
    "WorstOffenderRow",
    "WorstOffendersPerRuleOut",
    # Cluster E - Table-level
    "OpportunityBriefRow",
    "OpportunitiesForTableIn",
    "OpportunitiesForTableOut",
    "TableSummaryIn",
    "TableSummaryOut",
    # Cluster F - Workload
    "WorkloadBreakdownOut",
    "DbtOriginSummaryOut",
    # Cluster H - Storage
    "DatasetStorageRow",
    "DatasetStorageSummaryOut",
    # Cluster I - Config
    "AuditConfigSummaryOut",
]
