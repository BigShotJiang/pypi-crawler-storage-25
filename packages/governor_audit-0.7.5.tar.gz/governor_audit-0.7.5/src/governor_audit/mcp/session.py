"""Read-only session helper for the MCP server.

A thin context manager that opens a fresh SQLAlchemy session per tool
call, surfaces the three precondition errors (DB missing, schema
incompatible, DB locked) as ``ToolError`` shapes rather than raw
exceptions, and guarantees the session is closed regardless of
outcome.

The MCP server runs ``anyio`` task groups; SQLAlchemy sessions are
not thread-safe, so we open a new session per tool call rather than
sharing one. The engine itself is cached at module level (lazy-built
on first use) per [research.md](../../specs/152-audit-mcp-server/research.md) §10
so process startup stays fast.
"""

from __future__ import annotations

import logging
from contextlib import contextmanager
from pathlib import Path
from typing import Iterator

from governor_audit.mcp.schemas import ToolError

logger = logging.getLogger("governor_audit.mcp.session")


# Cached engine - built lazily on first ``read_session()`` call.
# None until then; reset by tests via ``_reset_engine_cache()``.
_ENGINE_CACHE = None


class _MCPPreconditionError(Exception):
    """Internal exception carrying a ``ToolError`` payload.

    Caught by every tool's outer try/except and converted to the
    tool's return value. Never bubbles to the MCP SDK transport.
    """

    def __init__(self, tool_error: ToolError):
        super().__init__(tool_error.message)
        self.tool_error = tool_error


@contextmanager
def read_session() -> Iterator:
    """Open + yield a SQLAlchemy session against the audit DB. Closes
    on exit. Raises ``_MCPPreconditionError`` (carrying a structured
    ``ToolError``) on the three known precondition failures:

      - DB file missing → ``audit_not_initialised``
      - DB present but schema doesn't match → ``schema_incompatible``
      - DB locked by another writer → ``db_locked``

    Other exceptions propagate normally; the caller's outer
    try/except maps them to ``internal_error``.
    """
    # Lazy import - keeps process startup fast for the chat client.
    from sqlalchemy.exc import OperationalError

    from governor_audit.db.session import db_path

    from governor_audit.mcp import errors as _errs

    expected_path: Path = db_path()
    if not expected_path.exists():
        raise _MCPPreconditionError(_errs.not_initialised())

    engine = _get_engine()
    factory = _get_session_factory(engine)

    try:
        session = factory()
    except OperationalError as exc:
        if "locked" in str(exc).lower():
            raise _MCPPreconditionError(_errs.db_locked()) from exc
        raise

    try:
        # Cheap probe - confirms the schema has the audit tables we
        # need. If ``scan_runs`` is missing the DB is from a different
        # tool entirely.
        _probe_schema(session)
        yield session
    except _MCPPreconditionError:
        raise
    except OperationalError as exc:
        msg = str(exc).lower()
        if "locked" in msg:
            raise _MCPPreconditionError(_errs.db_locked()) from exc
        if "no such table" in msg or "no such column" in msg:
            raise _MCPPreconditionError(
                _errs.schema_incompatible(detail=str(exc)[:100])
            ) from exc
        raise
    finally:
        session.close()


def _get_engine():
    """Return the cached engine, building it on first call.

    Heavy imports (``sqlalchemy``, ``governor_core``) are deferred
    until this function runs - keeps the chat client's MCP-server
    cold-start under ~200ms.
    """
    global _ENGINE_CACHE
    if _ENGINE_CACHE is None:
        from governor_audit.db.session import build_engine, create_all

        engine = build_engine()
        # ``create_all`` is the audit's idempotent migration step
        # (spec 151 polish - adds new columns to existing tables).
        # Safe to run on every cold start; no-op when up to date.
        # MCP itself does NOT mutate; this only adds missing columns
        # the user's older audit DB might be missing.
        try:
            create_all(engine)
        except Exception:  # noqa: BLE001
            # Migration failure shouldn't kill the server - surface
            # the symptom at the first tool call via the schema probe.
            logger.warning(
                "MCP server: create_all migration check failed; "
                "tools will surface schema_incompatible if needed."
            )
        _ENGINE_CACHE = engine
    return _ENGINE_CACHE


def _get_session_factory(engine):
    """Build a session factory for the cached engine. Sessionmaker is
    cheap to construct; we build a fresh one per tool call rather
    than cache it."""
    from governor_audit.db.session import make_session_factory

    return make_session_factory(engine)


def _probe_schema(session) -> None:
    """Raise ``schema_incompatible`` if the audit's core tables are
    missing. Bounded: one SELECT 1 LIMIT 1 against ``scan_runs``."""
    from sqlalchemy import text

    from governor_audit.mcp import errors as _errs

    try:
        session.execute(text("SELECT 1 FROM scan_runs LIMIT 1"))
    except Exception as exc:  # noqa: BLE001
        msg = str(exc).lower()
        if "no such table" in msg or "no such column" in msg:
            raise _MCPPreconditionError(
                _errs.schema_incompatible(detail=str(exc)[:100])
            ) from exc
        raise


def _reset_engine_cache() -> None:
    """Tests only - reset the cached engine so the next ``read_session``
    call rebuilds against (e.g.) a fresh tmp-dir DB."""
    global _ENGINE_CACHE
    if _ENGINE_CACHE is not None:
        try:
            _ENGINE_CACHE.dispose()
        except Exception:  # noqa: BLE001
            pass
    _ENGINE_CACHE = None


__all__ = [
    "read_session",
    "_MCPPreconditionError",
    "_reset_engine_cache",
]
