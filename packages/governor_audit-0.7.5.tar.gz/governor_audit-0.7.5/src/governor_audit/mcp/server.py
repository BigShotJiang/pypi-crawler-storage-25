"""MCP stdio server entrypoint.

The chat client (Claude Desktop, Cursor, etc.) spawns this process per
the user's MCP configuration; we register the audit's read-only tools
on a ``FastMCP`` instance and start the SDK's stdio transport loop.

Lazy imports inside the build function keep cold start fast: the chat
client launches us every time it (re)attaches, so heavy module-load
at the top would feel sluggish.
"""

import logging

# Schema imports stay at module level so the MCP SDK's annotation
# resolver can evaluate them at tool-registration time. The heavy
# tool-body imports (which pull in sqlalchemy + governor-core) stay
# deferred inside the tool functions per research.md §10 - those
# fire on first call, not on registration.
from governor_audit.mcp.schemas import (
    CohortForTableIn,
    CostComparedToPreviousPeriodIn,
    CostForDayIn,
    DailyCostSummaryIn,
    FindJobsByDestinationIn,
    FindJobsWithRuleIn,
    LayoutForTableIn,
    ListLayoutsIn,
    MethodologyIn,
    OpportunitiesForTableIn,
    RecentFailuresIn,
    SearchJobsIn,
    TableSummaryIn,
    TopCostDriversIn,
    TopOpportunitiesIn,
    TopUsersByCostIn,
    TopUsersByRuleCountIn,
    UserWorkloadSummaryIn,
    WorstOffendersPerRuleIn,
)

logger = logging.getLogger("governor_audit.mcp.server")


_INSTRUCTIONS = (
    "Read-only MCP server for governor-audit. Tools surface the same "
    "data the audit web UI shows - top opportunities, cost drivers, "
    "partition & cluster recommendations, scan status, query "
    "cohorts, failed jobs, and a methodology lookup so you can "
    "explain how each number is calculated. Tools never write to the "
    "audit DB and never make BigQuery API calls - they read only "
    "from the local SQLite cache populated by `governor-audit scan`."
)


def build_server():
    """Construct the ``FastMCP`` server with every tool registered.

    Returns the SDK instance; the caller chooses how to run it.
    Factored out so tests can introspect registrations without
    actually entering the stdio loop.
    """
    from mcp.server.fastmcp import FastMCP

    from governor_audit.mcp.tools.cost_drivers import list_top_cost_drivers
    from governor_audit.mcp.tools.failures_and_cohort import (
        cohort_for_table as _cohort_for_table_impl,
        recent_failures as _recent_failures_impl,
    )
    from governor_audit.mcp.tools.layout import (
        layout_recommendation_for_table,
        list_layout_recommendations,
    )
    from governor_audit.mcp.tools.methodology import methodology
    from governor_audit.mcp.tools.opportunities import (
        find_jobs_with_rule,
        list_top_opportunities,
    )
    from governor_audit.mcp.tools.people import (
        top_users_by_cost,
        top_users_by_rule_count,
        user_workload_summary,
    )
    from governor_audit.mcp.tools.rule_analytics import (
        rule_summary,
        worst_offenders_per_rule,
    )
    from governor_audit.mcp.tools.scan import scan_status
    from governor_audit.mcp.tools.search import (
        find_jobs_by_destination,
        search_jobs,
    )
    from governor_audit.mcp.tools.tables_and_workload import (
        audit_config_summary,
        dataset_storage_summary,
        dbt_origin_summary,
        opportunities_for_table,
        table_summary,
        workload_breakdown,
    )
    from governor_audit.mcp.tools.temporal import (
        cost_compared_to_previous_period,
        cost_for_day,
        daily_cost_summary,
    )
    from governor_audit.version import get_app_version

    server = FastMCP(
        name="governor-audit",
        instructions=_INSTRUCTIONS,
        # FastMCP's defaults are stdio-friendly; we keep them.
    )

    @server.tool(
        name="list_top_opportunities",
        description=(
            "Top-N active opportunities ranked by **aggregated** cost "
            "across the whole logical job (destination_table for "
            "builds, query_hash for consumption). Read-only. Default "
            "limit=20, max=100. Filter by opportunity_type or "
            "min_severity. Identical numbers to the /opportunities "
            "web page."
        ),
    )
    def _list_top_opportunities(payload: TopOpportunitiesIn):
        return list_top_opportunities(payload).model_dump(mode="json")

    @server.tool(
        name="list_top_cost_drivers",
        description=(
            "Top-N logical jobs by aggregated cost regardless of "
            "whether they have findings. Optionally filter by "
            "workload_kind ('build' or 'consumption'). Read-only. "
            "Identical numbers to the dashboard's Top 20 Spenders chart."
        ),
    )
    def _list_top_cost_drivers(payload: TopCostDriversIn):
        return list_top_cost_drivers(payload).model_dump(mode="json")

    @server.tool(
        name="find_jobs_with_rule",
        description=(
            "Logical jobs that fired a specific detection rule "
            "(e.g. 'slot_contention', 'select_star'). Optional "
            "since_days window (capped at 180). Returns rows ranked "
            "by aggregated cost. Read-only."
        ),
    )
    def _find_jobs_with_rule(payload: FindJobsWithRuleIn):
        return find_jobs_with_rule(payload).model_dump(mode="json")

    @server.tool(
        name="layout_recommendation_for_table",
        description=(
            "Spec-151 partition + cluster recommendation for one "
            "destination table, including the apply SQL (copy + "
            "rename procedure where needed), rollback steps, ranked "
            "candidate columns, caveats, and BigQuery's own "
            "second-opinion (when the IAM grant allows). Read-only - "
            "the SQL is for the user to copy + run in BigQuery."
        ),
    )
    def _layout_recommendation_for_table(payload: LayoutForTableIn):
        return layout_recommendation_for_table(payload).model_dump(mode="json")

    @server.tool(
        name="list_layout_recommendations",
        description=(
            "Every persisted partition + cluster recommendation from "
            "the latest scan, ranked by window cost descending. "
            "min_size_gb defaults to 10 (the cluster-recommendation "
            "threshold). Read-only."
        ),
    )
    def _list_layout_recommendations(payload: ListLayoutsIn):
        return list_layout_recommendations(payload).model_dump(mode="json")

    @server.tool(
        name="scan_status",
        description=(
            "Current scan in progress (phase, started_at) plus the "
            "most recent successful scan summary. Empty response is "
            "valid - means the audit is installed but never scanned. "
            "Read-only."
        ),
    )
    def _scan_status():
        return scan_status().model_dump(mode="json")

    @server.tool(
        name="methodology",
        description=(
            "Calculation methodology for a named metric. Returns the "
            "same explanation the /methodology web page shows. On "
            "unknown name, the error message includes the list of "
            "valid metric_names so you can re-ask. Read-only."
        ),
    )
    def _methodology(payload: MethodologyIn):
        return methodology(payload).model_dump(mode="json")

    # ── Cohort + failures (formerly stubs, now live). ─────────────────
    @server.tool(
        name="cohort_for_table",
        description=(
            "Every cached execution of one destination_table grouped by "
            "query version (normalized_literals hash). Returns each "
            "version's first/last seen, execution count, total cost, "
            "and what rules fired or were resolved relative to the "
            "previous version. Read-only."
        ),
    )
    def _cohort_for_table(payload: CohortForTableIn):
        return _cohort_for_table_impl(payload).model_dump(mode="json")

    @server.tool(
        name="recent_failures",
        description=(
            "Failed BigQuery jobs in the scan window, grouped by query "
            "body (normalized hash), ranked by total slot-ms wasted. "
            "Each row has the BQ error reason, failure count, and the "
            "earliest/latest occurrence. Read-only."
        ),
    )
    def _recent_failures(payload: RecentFailuresIn):
        return _recent_failures_impl(payload).model_dump(mode="json")

    # ── Cluster A: Temporal ─────────────────────────────────────────
    @server.tool(
        name="cost_for_day",
        description=(
            "Total BigQuery cost for a single UTC day, broken down by "
            "build / consumption / other workload, plus the count of "
            "distinct flagged jobs on that day. Accepts ISO 'YYYY-MM-DD' "
            "or the keywords 'today' / 'yesterday'. Read-only."
        ),
    )
    def _cost_for_day(payload: CostForDayIn):
        return cost_for_day(payload).model_dump(mode="json")

    @server.tool(
        name="daily_cost_summary",
        description=(
            "Day-by-day cost / bytes / slot-ms / job count for the last "
            "N days (default 7, max 180). Days with zero executions are "
            "skipped from the output. Use this for 'cost trend last "
            "week' style questions. Read-only."
        ),
    )
    def _daily_cost_summary(payload: DailyCostSummaryIn):
        return daily_cost_summary(payload).model_dump(mode="json")

    @server.tool(
        name="cost_compared_to_previous_period",
        description=(
            "Compare cost between the most-recent N days and the N days "
            "immediately before that. Returns both periods plus the "
            "delta (absolute USD + percent). 'Is spend trending up or "
            "down?' style answer. Read-only."
        ),
    )
    def _cost_compared(payload: CostComparedToPreviousPeriodIn):
        return cost_compared_to_previous_period(payload).model_dump(mode="json")

    # ── Cluster B: People ────────────────────────────────────────────
    @server.tool(
        name="top_users_by_cost",
        description=(
            "Ranking of user_email principals by aggregated cost across "
            "all their cached jobs. Includes flagged-job count per user. "
            "Service accounts (typical for dbt / scheduled workloads) "
            "show up alongside human users. Read-only."
        ),
    )
    def _top_users_by_cost(payload: TopUsersByCostIn):
        return top_users_by_cost(payload).model_dump(mode="json")

    @server.tool(
        name="top_users_by_rule_count",
        description=(
            "For one detection rule (e.g. 'slot_contention'), rank "
            "users by the number of affected tables their jobs tripped "
            "the rule on. Tells you who is producing the most findings "
            "of a given kind. Read-only."
        ),
    )
    def _top_users_by_rule(payload: TopUsersByRuleCountIn):
        return top_users_by_rule_count(payload).model_dump(mode="json")

    @server.tool(
        name="user_workload_summary",
        description=(
            "Deep dive on a single user_email: total cost, executions, "
            "dbt vs ad-hoc split, top affected tables, and which "
            "detection rules their jobs trip. Read-only."
        ),
    )
    def _user_workload_summary(payload: UserWorkloadSummaryIn):
        return user_workload_summary(payload).model_dump(mode="json")

    # ── Cluster C: Filter / Search ───────────────────────────────────
    @server.tool(
        name="search_jobs",
        description=(
            "Multi-criteria search over cached BigQueryJob rows. All "
            "filters optional: min/max cost, bytes, duration; "
            "statement_type; user_email; cache_hit; SQL substring "
            "(case-insensitive); since_days window. Returns a compact "
            "row shape (no full SQL) ranked by cost desc. Read-only."
        ),
    )
    def _search_jobs(payload: SearchJobsIn):
        return search_jobs(payload).model_dump(mode="json")

    @server.tool(
        name="find_jobs_by_destination",
        description=(
            "All cached jobs that wrote to a specific destination_table "
            "('project.dataset.table'). Returns rows ranked by "
            "creation_time desc plus total executions / total cost. "
            "Read-only."
        ),
    )
    def _find_jobs_by_destination(payload: FindJobsByDestinationIn):
        return find_jobs_by_destination(payload).model_dump(mode="json")

    # ── Cluster D: Rule analytics ────────────────────────────────────
    @server.tool(
        name="rule_summary",
        description=(
            "For every detection rule that has at least one active "
            "opportunity, return the count of opps, total estimated "
            "cost, and the top-3 affected tables. Use this for "
            "'what's broken and where?' overview questions. Read-only."
        ),
    )
    def _rule_summary():
        return rule_summary().model_dump(mode="json")

    @server.tool(
        name="worst_offenders_per_rule",
        description=(
            "For one detection rule, return the affected tables ranked "
            "by aggregated cost (not the rule's hardcoded estimate). "
            "Use this to find the most expensive tables tripping a "
            "specific rule. Read-only."
        ),
    )
    def _worst_offenders_per_rule(payload: WorstOffendersPerRuleIn):
        return worst_offenders_per_rule(payload).model_dump(mode="json")

    # ── Cluster E: Table-level ───────────────────────────────────────
    @server.tool(
        name="opportunities_for_table",
        description=(
            "Every active opportunity for one affected_table, split "
            "into issues vs suggestions. Useful for drilling into a "
            "specific model the user mentioned. Read-only."
        ),
    )
    def _opportunities_for_table(payload: OpportunitiesForTableIn):
        return opportunities_for_table(payload).model_dump(mode="json")

    @server.tool(
        name="table_summary",
        description=(
            "Single-table card: total cost, executions, distinct query "
            "versions, days-with-executions, latest execution time, "
            "issue + suggestion counts, and whether a layout "
            "recommendation exists. Read-only."
        ),
    )
    def _table_summary(payload: TableSummaryIn):
        return table_summary(payload).model_dump(mode="json")

    # ── Cluster F: Workload ──────────────────────────────────────────
    @server.tool(
        name="workload_breakdown",
        description=(
            "Total scan-window cost split by workload classification "
            "(build / consumption / other) with percentages. Quick "
            "'where is my money going?' answer. Read-only."
        ),
    )
    def _workload_breakdown():
        return workload_breakdown().model_dump(mode="json")

    @server.tool(
        name="dbt_origin_summary",
        description=(
            "Cost split between dbt-originated jobs and everything "
            "else, plus the top 5 non-dbt users by cost (useful for "
            "spotting unattributed ad-hoc workloads). Read-only."
        ),
    )
    def _dbt_origin_summary():
        return dbt_origin_summary().model_dump(mode="json")

    # ── Cluster H: Storage ───────────────────────────────────────────
    @server.tool(
        name="dataset_storage_summary",
        description=(
            "Per-dataset storage rollup: billing model, active + "
            "long-term bytes (logical and physical), table count, "
            "monthly storage cost in USD, and compression ratio. "
            "Read-only."
        ),
    )
    def _dataset_storage_summary():
        return dataset_storage_summary().model_dump(mode="json")

    # ── Cluster I: Config ────────────────────────────────────────────
    @server.tool(
        name="audit_config_summary",
        description=(
            "The active audit configuration: GCP project, region, "
            "billing project, lookback days, scan defaults, enabled / "
            "disabled detection rules, LLM provider/model (without "
            "API key), and audit version. Use this to ground 'which "
            "project am I scanning?' style questions. Read-only."
        ),
    )
    def _audit_config_summary():
        return audit_config_summary().model_dump(mode="json")

    logger.info(
        "MCP server constructed: governor-audit %s, %d tools registered",
        get_app_version(),
        24,
    )
    return server


def run_stdio() -> None:
    """Build the server and enter the stdio transport loop. Called by
    the ``governor-audit mcp run`` CLI subcommand."""
    server = build_server()
    server.run(transport="stdio")


__all__ = ["build_server", "run_stdio"]
