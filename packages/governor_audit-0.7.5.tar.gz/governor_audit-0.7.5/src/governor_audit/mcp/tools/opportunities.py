"""``list_top_opportunities`` + ``find_jobs_with_rule``.

Both project from the same aggregated dict shape ``_aggregate_totals_and_top_jobs``
produces (spec 151 polish), enriched with opportunity-level metadata
(opportunity_type, severity_score, affected_table, explanation) for
``list_top_opportunities``.
"""

from __future__ import annotations

from governor_audit.mcp.schemas import (
    FindJobsWithRuleIn,
    FindJobsWithRuleOut,
    LogicalJobRow,
    OpportunityRow,
    ToolError,
    TopOpportunitiesIn,
    TopOpportunitiesOut,
)
from governor_audit.mcp.session import _MCPPreconditionError, read_session


def list_top_opportunities(
    payload: TopOpportunitiesIn,
) -> TopOpportunitiesOut | ToolError:

    from governor_audit.config.loader import ConfigNotFoundError, load_config
    from governor_audit.mcp import errors as _errs
    from governor_audit.mcp.tools.cost_drivers import (
        _latest_scan_meta,
        _row_to_logical_job_row,
    )
    from governor_audit.scan.sentinels import config_id_for
    from governor_audit.web.routes.findings import _aggregate_totals_and_top_jobs
    from governor_core.opportunities.models import Opportunity

    try:
        config = load_config()
    except ConfigNotFoundError:
        return _errs.not_initialised()

    active_config_id = config_id_for(config.gcp_project_id, config.bigquery_region)

    try:
        with read_session() as session:
            # The aggregator's ``opportunity_id`` field points to the
            # best opportunity for each logical job. We use the aggregator
            # to get the row-level numbers, then look up the linked
            # opportunity for the enrichment fields the chat client cares
            # about (severity_score, affected_table, explanation snippet).
            top, _totals, _opp_summary = _aggregate_totals_and_top_jobs(
                session,
                # Over-fetch then filter - opportunity_type / min_severity
                # narrow the candidate set; we still want ``limit`` matches.
                top_n=payload.limit * 4 if payload.opportunity_type or payload.min_severity else payload.limit,
                project_id=config.gcp_project_id,
                config_id=active_config_id,
            )
            if not top:
                return _errs.no_successful_scan()

            # Only rows with a linked opportunity belong here.
            top = [r for r in top if r.get("opportunity_id")]

            opp_ids = [r["opportunity_id"] for r in top if r.get("opportunity_id")]
            opps_by_id: dict[str, Opportunity] = {}
            if opp_ids:
                from governor_audit.scan.persistence import (
                    _SQLITE_MAX_IN_PARAMS,
                    _chunked,
                )

                for batch in _chunked(opp_ids, _SQLITE_MAX_IN_PARAMS):
                    opps = (
                        session.query(Opportunity)
                        .filter(Opportunity.id.in_(batch))
                        .filter(Opportunity.status == "active")
                        .all()
                    )
                    for o in opps:
                        opps_by_id[o.id] = o

            total_active = session.query(Opportunity).filter(
                Opportunity.status == "active",
                Opportunity.config_id == active_config_id,
            ).count()

            rows: list[OpportunityRow] = []
            for r in top:
                opp = opps_by_id.get(r["opportunity_id"]) if r.get("opportunity_id") else None
                if opp is None:
                    continue
                if (
                    payload.opportunity_type is not None
                    and opp.opportunity_type != payload.opportunity_type
                ):
                    continue
                severity = int(opp.severity_score or 0)
                if (
                    payload.min_severity is not None
                    and severity < payload.min_severity
                ):
                    continue
                base = _row_to_logical_job_row(r)
                rows.append(_to_opportunity_row(base, opp, severity))
                if len(rows) >= payload.limit:
                    break

            scan_id, _ = _latest_scan_meta(session, active_config_id)
            return TopOpportunitiesOut(
                opportunities=rows,
                total_active=total_active,
                scan_id=scan_id or "",
            )
    except _MCPPreconditionError as exc:
        return exc.tool_error
    except Exception as exc:  # noqa: BLE001
        return _errs.internal_error(str(exc))


def find_jobs_with_rule(
    payload: FindJobsWithRuleIn,
) -> FindJobsWithRuleOut | ToolError:
    """Find logical jobs that fired the named detection rule, ranked
    by aggregated cost. Used for "did I have slot contention this week?"
    """
    from datetime import datetime, timedelta, timezone

    from governor_audit.config.loader import ConfigNotFoundError, load_config
    from governor_audit.mcp import errors as _errs
    from governor_audit.mcp.tools.cost_drivers import _row_to_logical_job_row
    from governor_audit.scan.sentinels import config_id_for
    from governor_audit.web.routes.findings import _aggregate_totals_and_top_jobs
    from governor_core.opportunities.models import Opportunity

    try:
        config = load_config()
    except ConfigNotFoundError:
        return _errs.not_initialised()

    active_config_id = config_id_for(config.gcp_project_id, config.bigquery_region)

    try:
        with read_session() as session:
            # Find every active opportunity matching the rule type.
            matching_opps = (
                session.query(Opportunity)
                .filter(
                    Opportunity.status == "active",
                    Opportunity.config_id == active_config_id,
                    Opportunity.opportunity_type == payload.rule_type,
                )
                .all()
            )
            if not matching_opps and not _config_has_any_scan(session):
                return _errs.no_successful_scan()

            related_job_ids: set[str] = set()
            for opp in matching_opps:
                for jid in opp.related_job_ids or []:
                    related_job_ids.add(jid)

            top, _totals, _opp_summary = _aggregate_totals_and_top_jobs(
                session,
                # Over-fetch so we have a wide pool to filter through;
                # logical-job rows can collapse many jobs.
                top_n=payload.limit * 10,
                project_id=config.gcp_project_id,
                config_id=active_config_id,
            )

            cutoff = None
            if payload.since_days is not None:
                cutoff = datetime.now(timezone.utc) - timedelta(days=payload.since_days)

            rows: list[LogicalJobRow] = []
            for r in top:
                # Pick rows whose representative ``job_id`` is in the
                # rule's related set. job_id stays on the aggregated
                # dict from the cost-rep selection in the aggregator.
                if r.get("job_id") not in related_job_ids:
                    continue
                if cutoff is not None:
                    ct = r.get("creation_time")
                    if ct is None or ct < cutoff:
                        continue
                rows.append(_row_to_logical_job_row(r))
                if len(rows) >= payload.limit:
                    break

            return FindJobsWithRuleOut(
                rows=rows,
                rule_type=payload.rule_type,
                total_matching=len(matching_opps),
            )
    except _MCPPreconditionError as exc:
        return exc.tool_error
    except Exception as exc:  # noqa: BLE001
        return _errs.internal_error(str(exc))


def _to_opportunity_row(
    base: LogicalJobRow,
    opp,
    severity_score: int,
) -> OpportunityRow:
    """Enrich a base ``LogicalJobRow`` with opportunity fields."""
    explanation = (opp.explanation or "")[:500]
    return OpportunityRow(
        destination_table=base.destination_table,
        query_hash=base.query_hash,
        short_label=base.short_label,
        workload_kind=base.workload_kind,
        cost_usd=base.cost_usd,
        cost_share_pct=base.cost_share_pct,
        bytes_processed=base.bytes_processed,
        slot_time_ms=base.slot_time_ms,
        execution_count=base.execution_count,
        issue_count=base.issue_count,
        suggestion_count=base.suggestion_count,
        latest_creation_time=base.latest_creation_time,
        is_dbt_originated=base.is_dbt_originated,
        opportunity_id=base.opportunity_id,
        opportunity_type=opp.opportunity_type,
        severity_score=severity_score,
        affected_table=opp.affected_table,
        explanation=explanation,
    )


def _config_has_any_scan(session) -> bool:
    """Disambiguates the "no scan yet" vs "no matching rules" cases -
    used to pick which structured error to return."""
    from sqlalchemy import desc

    from governor_audit.db.models import ScanRun

    row = (
        session.query(ScanRun)
        .filter(ScanRun.status == "succeeded")
        .order_by(desc(ScanRun.completed_at))
        .first()
    )
    return row is not None


__all__ = ["list_top_opportunities", "find_jobs_with_rule"]
