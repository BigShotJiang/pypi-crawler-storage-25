"""``methodology(metric_name)`` - return the calculation explanation
for a named metric. Pure lookup against the canonical dict in
``mcp/methodology_text.py``; no DB session needed."""

from __future__ import annotations

from governor_audit.mcp.methodology_text import METHODOLOGY
from governor_audit.mcp.schemas import MethodologyIn, MethodologyOut, ToolError


def methodology(payload: MethodologyIn) -> MethodologyOut | ToolError:
    """Return the methodology entry for ``payload.metric_name``.

    On unknown name, returns ``unknown_metric`` whose ``message``
    includes the sorted valid-key list so the chat client can re-ask
    with a valid one in a single follow-up turn.
    """
    from governor_audit.mcp import errors as _errs

    entry = METHODOLOGY.get(payload.metric_name)
    if entry is None:
        return _errs.unknown_metric(
            metric_name=payload.metric_name,
            valid_keys=list(METHODOLOGY.keys()),
        )

    return MethodologyOut(
        metric_name=payload.metric_name,
        title=entry.title,
        source_field=entry.source_field,
        formula=entry.formula,
        description=entry.description,
        caveats=list(entry.caveats),
        related_metrics=list(entry.related_metrics),
    )


__all__ = ["methodology"]
