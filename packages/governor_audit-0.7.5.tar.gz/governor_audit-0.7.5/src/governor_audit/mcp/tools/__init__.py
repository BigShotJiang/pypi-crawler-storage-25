"""Per-domain MCP tool modules. Each exposes one or two ``async def``
handlers the server registers with the MCP SDK."""
