"""People / owner analytics - top_users_by_cost,
top_users_by_rule_count, user_workload_summary.

Group BigQueryJob rows by ``user_email`` (= the principal that
submitted the BigQuery job, typically a service account for dbt /
scheduled workloads, an analyst's email for ad-hoc work).

Read-only. Local SQLite only.
"""

from __future__ import annotations

from governor_audit.mcp.schemas import (
    TopUsersByCostIn,
    TopUsersByCostOut,
    TopUsersByRuleCountIn,
    TopUsersByRuleCountOut,
    ToolError,
    UserCostRow,
    UserRuleCountRow,
    UserTopTable,
    UserWorkloadRuleHit,
    UserWorkloadSummaryIn,
    UserWorkloadSummaryOut,
)
from governor_audit.mcp.session import _MCPPreconditionError, read_session


def top_users_by_cost(
    payload: TopUsersByCostIn,
) -> TopUsersByCostOut | ToolError:
    from governor_audit.config.loader import ConfigNotFoundError, load_config
    from governor_audit.mcp import errors as _errs
    from governor_audit.scan.sentinels import config_id_for
    from governor_core.opportunities.models import Opportunity
    from governor_core.sync.models import BigQueryJob

    try:
        config = load_config()
    except ConfigNotFoundError:
        return _errs.not_initialised()

    active_config_id = config_id_for(config.gcp_project_id, config.bigquery_region)

    try:
        with read_session() as session:
            jobs = (
                session.query(BigQueryJob)
                .filter(BigQueryJob.config_id == active_config_id)
                .all()
            )
            if not jobs:
                return _errs.no_successful_scan()

            # Build flagged_job_ids first (single pass over opps).
            opps = (
                session.query(Opportunity)
                .filter(Opportunity.config_id == active_config_id)
                .filter(Opportunity.status == "active")
                .all()
            )
            flagged_job_ids: set[str] = set()
            for opp in opps:
                for jid in (opp.related_job_ids or []):
                    flagged_job_ids.add(jid)

            agg: dict[str | None, dict] = {}
            grand_total = 0.0
            for job in jobs:
                key = job.user_email
                a = agg.setdefault(
                    key,
                    {
                        "cost_usd": 0.0,
                        "job_count": 0,
                        "bytes_processed": 0,
                        "slot_ms": 0,
                        "flagged_job_count": 0,
                    },
                )
                cost = float(job.total_cost or 0)
                a["cost_usd"] += cost
                a["job_count"] += 1
                a["bytes_processed"] += int(job.total_bytes_processed or 0)
                a["slot_ms"] += int(job.total_slot_ms or 0)
                if job.job_id in flagged_job_ids:
                    a["flagged_job_count"] += 1
                grand_total += cost

            sorted_rows = sorted(
                agg.items(), key=lambda kv: kv[1]["cost_usd"], reverse=True
            )[: payload.limit]

            rows = [
                UserCostRow(user_email=email, **stats)
                for email, stats in sorted_rows
            ]
            return TopUsersByCostOut(
                rows=rows,
                total_cost_usd=grand_total,
                distinct_users=len(agg),
            )
    except _MCPPreconditionError as exc:
        return exc.tool_error
    except Exception as exc:  # noqa: BLE001
        return _errs.internal_error(str(exc))


def top_users_by_rule_count(
    payload: TopUsersByRuleCountIn,
) -> TopUsersByRuleCountOut | ToolError:
    from governor_audit.config.loader import ConfigNotFoundError, load_config
    from governor_audit.mcp import errors as _errs
    from governor_audit.scan.sentinels import config_id_for
    from governor_core.opportunities.models import Opportunity
    from governor_core.sync.models import BigQueryJob

    try:
        config = load_config()
    except ConfigNotFoundError:
        return _errs.not_initialised()

    active_config_id = config_id_for(config.gcp_project_id, config.bigquery_region)

    try:
        with read_session() as session:
            opps = (
                session.query(Opportunity)
                .filter(Opportunity.config_id == active_config_id)
                .filter(Opportunity.status == "active")
                .filter(Opportunity.opportunity_type == payload.rule_type)
                .all()
            )
            if not opps:
                return TopUsersByRuleCountOut(
                    rule_type=payload.rule_type, rows=[]
                )

            related_ids: set[str] = set()
            opps_by_table: dict[str, list] = {}
            for opp in opps:
                opps_by_table.setdefault(opp.affected_table or "", []).append(opp)
                for jid in (opp.related_job_ids or []):
                    related_ids.add(jid)

            jobs_by_id: dict[str, "BigQueryJob"] = {}
            if related_ids:
                jobs = (
                    session.query(BigQueryJob)
                    .filter(BigQueryJob.config_id == active_config_id)
                    .filter(BigQueryJob.job_id.in_(related_ids))
                    .all()
                )
                jobs_by_id = {j.job_id: j for j in jobs}

            # Group by user_email.
            user_stats: dict[str | None, dict] = {}
            for opp in opps:
                user_emails = set()
                user_cost = 0.0
                user_jobs = 0
                for jid in (opp.related_job_ids or []):
                    j = jobs_by_id.get(jid)
                    if j is None:
                        continue
                    user_emails.add(j.user_email)
                    user_cost += float(j.total_cost or 0)
                    user_jobs += 1
                for email in user_emails:
                    a = user_stats.setdefault(
                        email,
                        {"affected_table_count": 0, "job_count": 0, "cost_usd": 0.0, "_tables": set()},
                    )
                    a["_tables"].add(opp.affected_table or "")
                    a["job_count"] += user_jobs
                    a["cost_usd"] += user_cost
            # finalise affected_table_count from the set we accumulated
            for email, a in user_stats.items():
                a["affected_table_count"] = len(a["_tables"])
                a.pop("_tables", None)

            sorted_rows = sorted(
                user_stats.items(), key=lambda kv: kv[1]["cost_usd"], reverse=True
            )[: payload.limit]
            rows = [
                UserRuleCountRow(user_email=email, **stats)
                for email, stats in sorted_rows
            ]
            return TopUsersByRuleCountOut(
                rule_type=payload.rule_type, rows=rows
            )
    except _MCPPreconditionError as exc:
        return exc.tool_error
    except Exception as exc:  # noqa: BLE001
        return _errs.internal_error(str(exc))


def user_workload_summary(
    payload: UserWorkloadSummaryIn,
) -> UserWorkloadSummaryOut | ToolError:
    from governor_audit.config.loader import ConfigNotFoundError, load_config
    from governor_audit.mcp import errors as _errs
    from governor_audit.scan.information_schema import is_dbt_originated
    from governor_audit.scan.sentinels import config_id_for
    from governor_core.opportunities.models import Opportunity
    from governor_core.sync.models import BigQueryJob

    try:
        config = load_config()
    except ConfigNotFoundError:
        return _errs.not_initialised()

    active_config_id = config_id_for(config.gcp_project_id, config.bigquery_region)

    try:
        with read_session() as session:
            jobs = (
                session.query(BigQueryJob)
                .filter(BigQueryJob.config_id == active_config_id)
                .filter(BigQueryJob.user_email == payload.user_email)
                .all()
            )
            if not jobs:
                return UserWorkloadSummaryOut(
                    user_email=payload.user_email,
                    total_cost_usd=0.0,
                    total_jobs=0,
                    dbt_cost_usd=0.0,
                    non_dbt_cost_usd=0.0,
                    flagged_job_count=0,
                    top_tables=[],
                    rule_hits=[],
                )

            total_cost = 0.0
            dbt_cost = 0.0
            non_dbt_cost = 0.0
            user_job_ids: set[str] = set()
            table_agg: dict[str, dict] = {}
            for job in jobs:
                cost = float(job.total_cost or 0)
                total_cost += cost
                user_job_ids.add(job.job_id)
                # BigQueryJob table doesn't persist raw BQ labels;
                # is_dbt_originated falls back to the query prefix.
                as_dict = {
                    "query": job.query,
                    "query_hashes": job.query_hashes,
                }
                if is_dbt_originated(as_dict):
                    dbt_cost += cost
                else:
                    non_dbt_cost += cost
                if job.destination_table:
                    a = table_agg.setdefault(
                        job.destination_table,
                        {"cost_usd": 0.0, "job_count": 0},
                    )
                    a["cost_usd"] += cost
                    a["job_count"] += 1

            top_tables_sorted = sorted(
                table_agg.items(), key=lambda kv: kv[1]["cost_usd"], reverse=True
            )[:5]
            top_tables = [
                UserTopTable(table_full_name=tbl, **stats)
                for tbl, stats in top_tables_sorted
            ]

            opps = (
                session.query(Opportunity)
                .filter(Opportunity.config_id == active_config_id)
                .filter(Opportunity.status == "active")
                .all()
            )
            flagged = 0
            rule_table_counts: dict[str, dict] = {}
            for opp in opps:
                related = set(opp.related_job_ids or [])
                touched_by_user = related & user_job_ids
                if not touched_by_user:
                    continue
                flagged += len(touched_by_user)
                r = rule_table_counts.setdefault(
                    opp.opportunity_type,
                    {"table_count": 0, "job_count": 0, "_tables": set()},
                )
                r["_tables"].add(opp.affected_table or "")
                r["job_count"] += len(touched_by_user)
            rule_hits = []
            for rt, r in rule_table_counts.items():
                rule_hits.append(
                    UserWorkloadRuleHit(
                        rule_type=rt,
                        table_count=len(r["_tables"]),
                        job_count=r["job_count"],
                    )
                )
            rule_hits.sort(key=lambda h: h.job_count, reverse=True)

            return UserWorkloadSummaryOut(
                user_email=payload.user_email,
                total_cost_usd=total_cost,
                total_jobs=len(jobs),
                dbt_cost_usd=dbt_cost,
                non_dbt_cost_usd=non_dbt_cost,
                flagged_job_count=flagged,
                top_tables=top_tables,
                rule_hits=rule_hits,
            )
    except _MCPPreconditionError as exc:
        return exc.tool_error
    except Exception as exc:  # noqa: BLE001
        return _errs.internal_error(str(exc))


__all__ = [
    "top_users_by_cost",
    "top_users_by_rule_count",
    "user_workload_summary",
]
