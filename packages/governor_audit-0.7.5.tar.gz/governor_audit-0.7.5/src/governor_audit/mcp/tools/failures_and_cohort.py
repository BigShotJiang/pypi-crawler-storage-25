"""Upgrades for the two former stub tools - ``recent_failures`` and
``cohort_for_table``. Both now query real data; both wrap helpers that
already exist elsewhere in the codebase so the contract matches the
web UI's failures page / job-cohort view exactly.
"""

from __future__ import annotations

from datetime import datetime, timedelta, timezone

from governor_audit.mcp.schemas import (
    CohortForTableIn,
    CohortForTableOut,
    CohortVersionRow,
    FailureGroupRow,
    RecentFailuresIn,
    RecentFailuresOut,
    ToolError,
)
from governor_audit.mcp.session import _MCPPreconditionError, read_session


def recent_failures(payload: RecentFailuresIn) -> RecentFailuresOut | ToolError:
    from governor_audit.config.loader import ConfigNotFoundError, load_config
    from governor_audit.mcp import errors as _errs
    from governor_audit.scan.categorization import is_failed_job
    from governor_audit.scan.sentinels import config_id_for
    from governor_core.sync.models import BigQueryJob

    try:
        config = load_config()
    except ConfigNotFoundError:
        return _errs.not_initialised()

    active_config_id = config_id_for(config.gcp_project_id, config.bigquery_region)

    try:
        with read_session() as session:
            q = (
                session.query(BigQueryJob)
                .filter(BigQueryJob.config_id == active_config_id)
            )
            if payload.since_days is not None:
                cutoff = datetime.now(timezone.utc) - timedelta(days=payload.since_days)
                q = q.filter(BigQueryJob.creation_time >= cutoff)
            all_jobs = q.all()
            failed = [j for j in all_jobs if is_failed_job(j)]

            # Group by (destination_table, normalized_literals_hash) so
            # one failing query body that hits 50 retries collapses.
            def _hash(job) -> str:
                qh = job.query_hashes or {}
                nl = qh.get("normalized_literals") if isinstance(qh, dict) else None
                return nl or job.job_id

            groups: dict[str, dict] = {}
            for job in failed:
                key = _hash(job)
                err = job.error_result or {}
                reason = (
                    err.get("reason") if isinstance(err, dict) else None
                ) or "unknown"
                g = groups.setdefault(
                    key,
                    {
                        "representative_job_id": job.job_id,
                        "failure_reason": reason,
                        "failure_count": 0,
                        "total_slot_ms": 0,
                        "earliest_seen": job.creation_time,
                        "latest_seen": job.creation_time,
                        "destination_table": job.destination_table,
                    },
                )
                g["failure_count"] += 1
                g["total_slot_ms"] += int(job.total_slot_ms or 0)
                if job.creation_time and job.creation_time < g["earliest_seen"]:
                    g["earliest_seen"] = job.creation_time
                if job.creation_time and job.creation_time > g["latest_seen"]:
                    g["latest_seen"] = job.creation_time

            rows = []
            for h, g in groups.items():
                rows.append(
                    FailureGroupRow(
                        query_hash=h,
                        representative_job_id=g["representative_job_id"],
                        failure_reason=g["failure_reason"],
                        failure_count=g["failure_count"],
                        total_slot_ms=g["total_slot_ms"],
                        earliest_seen=g["earliest_seen"],
                        latest_seen=g["latest_seen"],
                        destination_table=g["destination_table"],
                    )
                )
            rows.sort(key=lambda r: r.total_slot_ms, reverse=True)

            return RecentFailuresOut(
                failures=rows[: payload.limit],
                total_failures_in_window=len(failed),
            )
    except _MCPPreconditionError as exc:
        return exc.tool_error
    except Exception as exc:  # noqa: BLE001
        return _errs.internal_error(str(exc))


def cohort_for_table(payload: CohortForTableIn) -> CohortForTableOut | ToolError:
    from governor_audit.config.loader import ConfigNotFoundError, load_config
    from governor_audit.jobs.cohort_view import build_cohort_view
    from governor_audit.mcp import errors as _errs
    from governor_audit.scan.sentinels import config_id_for

    try:
        config = load_config()
    except ConfigNotFoundError:
        return _errs.not_initialised()

    active_config_id = config_id_for(config.gcp_project_id, config.bigquery_region)

    try:
        with read_session() as session:
            view = build_cohort_view(
                session,
                config_id=active_config_id,
                destination_table=payload.table_full_name,
            )
            if view is None or view.has_no_executions:
                return ToolError(
                    code="table_not_found",
                    message=(
                        f"No cached executions for table "
                        f"{payload.table_full_name!r}."
                    ),
                    remediation=(
                        "Check the table name (project.dataset.table). "
                        "If correct, the table may not have been written "
                        "to during the scan window."
                    ),
                )

            versions = []
            for v in view.versions:
                slot_total = sum(
                    int(j.total_slot_ms or 0) for j in (v.executions or [])
                )
                versions.append(
                    CohortVersionRow(
                        version_index=v.version_index,
                        first_seen=v.first_seen,
                        last_seen=v.last_seen,
                        execution_count=len(v.executions or []),
                        total_cost_usd=float(v.total_cost or 0),
                        total_slot_ms=slot_total,
                        resolved_rules=list(v.resolved_rules or []),
                        newly_introduced_rules=list(v.newly_introduced_rules or []),
                        diff_against_previous=v.diff_against_previous,
                    )
                )

            return CohortForTableOut(
                table_full_name=view.destination_table,
                total_executions=view.total_executions,
                total_cost_usd=float(view.total_cost_usd or 0),
                days_with_executions=view.days_with_executions,
                versions=versions,
            )
    except _MCPPreconditionError as exc:
        return exc.tool_error
    except Exception as exc:  # noqa: BLE001
        return _errs.internal_error(str(exc))


__all__ = ["recent_failures", "cohort_for_table"]
