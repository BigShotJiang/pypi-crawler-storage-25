"""Filter / search tools - search_jobs (multi-criteria),
find_jobs_by_destination.

Both query BigQueryJob with a set of optional filters and return a
``JobBriefRow`` list (compact shape; no full SQL body, no labels - the
LLM rarely needs those for first-pass questions).

Read-only.
"""

from __future__ import annotations

from datetime import datetime, timedelta, timezone

from sqlalchemy import or_, desc

from governor_audit.mcp.schemas import (
    FindJobsByDestinationIn,
    FindJobsByDestinationOut,
    JobBriefRow,
    SearchJobsIn,
    SearchJobsOut,
    ToolError,
)
from governor_audit.mcp.session import _MCPPreconditionError, read_session


def _is_failed_job(job) -> bool:
    err = job.error_result
    if err is None:
        return False
    if isinstance(err, dict):
        return any(
            v not in (None, "", {}, []) for v in err.values()
        )
    return bool(err)


def _row_to_brief(job) -> JobBriefRow:
    return JobBriefRow(
        job_id=job.job_id,
        user_email=job.user_email,
        destination_table=job.destination_table,
        creation_time=job.creation_time,
        cost_usd=float(job.total_cost or 0),
        bytes_processed=int(job.total_bytes_processed or 0),
        slot_ms=int(job.total_slot_ms or 0),
        duration_ms=int(job.duration_ms or 0),
        statement_type=job.statement_type,
        cache_hit=bool(job.cache_hit),
        is_failed=_is_failed_job(job),
    )


def search_jobs(payload: SearchJobsIn) -> SearchJobsOut | ToolError:
    from governor_audit.config.loader import ConfigNotFoundError, load_config
    from governor_audit.mcp import errors as _errs
    from governor_audit.scan.sentinels import config_id_for
    from governor_core.sync.models import BigQueryJob

    try:
        config = load_config()
    except ConfigNotFoundError:
        return _errs.not_initialised()

    active_config_id = config_id_for(config.gcp_project_id, config.bigquery_region)

    try:
        with read_session() as session:
            q = (
                session.query(BigQueryJob)
                .filter(BigQueryJob.config_id == active_config_id)
            )

            if payload.since_days is not None:
                cutoff = datetime.now(timezone.utc) - timedelta(days=payload.since_days)
                q = q.filter(BigQueryJob.creation_time >= cutoff)

            if payload.min_cost_usd is not None:
                q = q.filter(BigQueryJob.total_cost >= payload.min_cost_usd)
            if payload.max_cost_usd is not None:
                q = q.filter(BigQueryJob.total_cost <= payload.max_cost_usd)
            if payload.min_bytes is not None:
                q = q.filter(BigQueryJob.total_bytes_processed >= payload.min_bytes)
            if payload.max_bytes is not None:
                q = q.filter(BigQueryJob.total_bytes_processed <= payload.max_bytes)
            if payload.min_duration_seconds is not None:
                q = q.filter(
                    BigQueryJob.duration_ms >= payload.min_duration_seconds * 1000
                )
            if payload.max_duration_seconds is not None:
                q = q.filter(
                    BigQueryJob.duration_ms <= payload.max_duration_seconds * 1000
                )
            if payload.statement_type:
                q = q.filter(BigQueryJob.statement_type == payload.statement_type)
            if payload.user_email:
                q = q.filter(BigQueryJob.user_email == payload.user_email)
            if payload.cache_hit is not None:
                q = q.filter(BigQueryJob.cache_hit == payload.cache_hit)
            if payload.sql_contains:
                # Case-insensitive substring match. SQLite + Postgres
                # both support ``LIKE`` with %; we lowercase both sides.
                needle = f"%{payload.sql_contains.lower()}%"
                q = q.filter(BigQueryJob.query.ilike(needle))

            total = q.count()
            rows_raw = q.order_by(desc(BigQueryJob.total_cost)).limit(payload.limit).all()
            rows = [_row_to_brief(j) for j in rows_raw]

            return SearchJobsOut(rows=rows, total_matching=total)
    except _MCPPreconditionError as exc:
        return exc.tool_error
    except Exception as exc:  # noqa: BLE001
        return _errs.internal_error(str(exc))


def find_jobs_by_destination(
    payload: FindJobsByDestinationIn,
) -> FindJobsByDestinationOut | ToolError:
    from governor_audit.config.loader import ConfigNotFoundError, load_config
    from governor_audit.mcp import errors as _errs
    from governor_audit.scan.sentinels import config_id_for
    from governor_core.sync.models import BigQueryJob

    try:
        config = load_config()
    except ConfigNotFoundError:
        return _errs.not_initialised()

    active_config_id = config_id_for(config.gcp_project_id, config.bigquery_region)

    try:
        with read_session() as session:
            q = (
                session.query(BigQueryJob)
                .filter(BigQueryJob.config_id == active_config_id)
                .filter(BigQueryJob.destination_table == payload.destination_table)
            )
            total = q.count()
            if total == 0:
                return ToolError(
                    code="table_not_found",
                    message=(
                        f"No cached jobs target destination_table "
                        f"{payload.destination_table!r}."
                    ),
                    remediation=(
                        "Check the table name (project.dataset.table). "
                        "If correct, the table may not have been written to "
                        "during the scan window."
                    ),
                )
            rows_raw = (
                q.order_by(desc(BigQueryJob.creation_time)).limit(payload.limit).all()
            )
            total_cost = sum(float(j.total_cost or 0) for j in q.all())
            rows = [_row_to_brief(j) for j in rows_raw]
            return FindJobsByDestinationOut(
                destination_table=payload.destination_table,
                rows=rows,
                total_executions=total,
                total_cost_usd=total_cost,
            )
    except _MCPPreconditionError as exc:
        return exc.tool_error
    except Exception as exc:  # noqa: BLE001
        return _errs.internal_error(str(exc))


__all__ = ["search_jobs", "find_jobs_by_destination"]
