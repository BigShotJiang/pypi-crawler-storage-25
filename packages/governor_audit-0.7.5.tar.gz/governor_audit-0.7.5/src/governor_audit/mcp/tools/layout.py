"""``layout_recommendation_for_table`` + ``list_layout_recommendations``.

Reads spec-151 ``LayoutRecommendation`` rows. Returns the same apply
SQL the web view shows verbatim - chat clients can paste it into
BigQuery without any translation.
"""

from __future__ import annotations

from governor_audit.mcp.schemas import (
    LayoutBqSecondOpinionOut,
    LayoutCandidateRow,
    LayoutCaveat,
    LayoutForTableIn,
    LayoutForTableOut,
    LayoutSummaryRow,
    ListLayoutsIn,
    ListLayoutsOut,
    ToolError,
)
from governor_audit.mcp.session import _MCPPreconditionError, read_session


def layout_recommendation_for_table(
    payload: LayoutForTableIn,
) -> LayoutForTableOut | ToolError:
    from sqlalchemy import desc

    from governor_audit.config.loader import ConfigNotFoundError, load_config
    from governor_audit.db.models import LayoutRecommendation, ScanRun
    from governor_audit.mcp import errors as _errs
    from governor_audit.scan.sentinels import config_id_for

    try:
        config = load_config()
    except ConfigNotFoundError:
        return _errs.not_initialised()

    active_config_id = config_id_for(config.gcp_project_id, config.bigquery_region)

    try:
        with read_session() as session:
            latest_scan = (
                session.query(ScanRun)
                .filter(ScanRun.status == "succeeded")
                .order_by(desc(ScanRun.completed_at))
                .first()
            )
            if latest_scan is None:
                return _errs.no_successful_scan()

            rec = (
                session.query(LayoutRecommendation)
                .filter(
                    LayoutRecommendation.scan_run_id == latest_scan.id,
                    LayoutRecommendation.config_id == active_config_id,
                    LayoutRecommendation.table_full_name == payload.table_full_name,
                )
                .first()
            )
            if rec is None:
                return _errs.table_not_found(payload.table_full_name)

            candidates = [
                LayoutCandidateRow(
                    column_name=c.column_name,
                    usage_type=c.usage_type,  # type: ignore[arg-type]
                    score=float(c.score),
                    cost_share=float(c.cost_share),
                    contributing_job_count=int(c.contributing_job_count),
                    cluster_rank=c.cluster_rank,
                    is_partition_pick=bool(c.is_partition_pick),
                )
                for c in rec.candidates
            ]
            cluster_columns = [
                c.column_name
                for c in sorted(
                    (c for c in rec.candidates if c.cluster_rank is not None),
                    key=lambda c: c.cluster_rank or 0,
                )
            ]

            bq_op_list = getattr(rec, "bq_second_opinion", None) or []
            bq_op = bq_op_list[0] if bq_op_list else None
            bq_view = None
            if bq_op is not None:
                bq_view = LayoutBqSecondOpinionOut(
                    bq_recommended_columns=list(bq_op.bq_recommended_columns or []),
                    bq_description=bq_op.bq_description,
                    agrees_with_audit_top_pick=bool(bq_op.agrees_with_audit_top_pick),
                )

            caveats = [
                LayoutCaveat(code=c.get("code", ""), message=c.get("message", ""))
                for c in (rec.caveats or [])
            ]

            return LayoutForTableOut(
                table_full_name=rec.table_full_name,
                recommended_partition_column=rec.recommended_partition_column,
                recommended_partition_type=rec.recommended_partition_type,
                cluster_columns=cluster_columns,
                candidates=candidates,
                apply_sql=rec.apply_sql,
                rollback_sql=rec.rollback_sql,
                caveats=caveats,
                table_total_bytes=int(rec.table_total_bytes),
                table_total_cost_in_window_usd=float(rec.table_total_cost_in_window_usd),
                is_currently_partitioned=bool(rec.table_is_currently_partitioned),
                bq_second_opinion=bq_view,
            )
    except _MCPPreconditionError as exc:
        return exc.tool_error
    except Exception as exc:  # noqa: BLE001
        return _errs.internal_error(str(exc))


def list_layout_recommendations(
    payload: ListLayoutsIn,
) -> ListLayoutsOut | ToolError:
    from sqlalchemy import desc

    from governor_audit.config.loader import ConfigNotFoundError, load_config
    from governor_audit.db.models import LayoutRecommendation, ScanRun
    from governor_audit.mcp import errors as _errs
    from governor_audit.scan.sentinels import config_id_for

    try:
        config = load_config()
    except ConfigNotFoundError:
        return _errs.not_initialised()

    active_config_id = config_id_for(config.gcp_project_id, config.bigquery_region)
    min_bytes = payload.min_size_gb * (2**30)

    try:
        with read_session() as session:
            latest_scan = (
                session.query(ScanRun)
                .filter(ScanRun.status == "succeeded")
                .order_by(desc(ScanRun.completed_at))
                .first()
            )
            if latest_scan is None:
                return _errs.no_successful_scan()

            recs = (
                session.query(LayoutRecommendation)
                .filter(
                    LayoutRecommendation.scan_run_id == latest_scan.id,
                    LayoutRecommendation.config_id == active_config_id,
                    LayoutRecommendation.table_total_bytes >= min_bytes,
                )
                .order_by(
                    desc(LayoutRecommendation.table_total_cost_in_window_usd),
                )
                .limit(payload.limit)
                .all()
            )

            rows = []
            for rec in recs:
                cluster_picks = [
                    c.column_name
                    for c in sorted(
                        (c for c in rec.candidates if c.cluster_rank is not None),
                        key=lambda c: c.cluster_rank or 0,
                    )
                ]
                rows.append(
                    LayoutSummaryRow(
                        table_full_name=rec.table_full_name,
                        recommended_partition_column=rec.recommended_partition_column,
                        cluster_columns=cluster_picks,
                        table_total_bytes=int(rec.table_total_bytes),
                        table_total_cost_in_window_usd=float(
                            rec.table_total_cost_in_window_usd
                        ),
                        contributing_job_count=int(rec.contributing_job_count),
                        caveat_count=len(rec.caveats or []),
                    )
                )

            return ListLayoutsOut(
                recommendations=rows,
                scan_id=latest_scan.id,
                scan_window_days=int(latest_scan.requested_lookback_days or 0),
            )
    except _MCPPreconditionError as exc:
        return exc.tool_error
    except Exception as exc:  # noqa: BLE001
        return _errs.internal_error(str(exc))


__all__ = [
    "layout_recommendation_for_table",
    "list_layout_recommendations",
]
