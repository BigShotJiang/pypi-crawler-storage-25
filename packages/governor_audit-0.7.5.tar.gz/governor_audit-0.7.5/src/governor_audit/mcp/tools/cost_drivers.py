"""``list_top_cost_drivers`` - top-N logical jobs by aggregated cost.

Wraps the existing ``_aggregate_totals_and_top_jobs`` (spec 151
polish) so MCP and dashboard numbers stay identical (FR-006). The
parity test in ``tests/integration/test_mcp_web_ui_parity.py`` pins
this guarantee.
"""

from __future__ import annotations

from governor_audit.mcp.schemas import (
    LogicalJobRow,
    ToolError,
    TopCostDriversIn,
    TopCostDriversOut,
)
from governor_audit.mcp.session import _MCPPreconditionError, read_session


def list_top_cost_drivers(
    payload: TopCostDriversIn,
) -> TopCostDriversOut | ToolError:
    from governor_audit.config.loader import ConfigNotFoundError, load_config
    from governor_audit.mcp import errors as _errs
    from governor_audit.scan.sentinels import config_id_for
    from governor_audit.web.routes.findings import _aggregate_totals_and_top_jobs

    try:
        config = load_config()
    except ConfigNotFoundError:
        return _errs.not_initialised()

    active_config_id = config_id_for(config.gcp_project_id, config.bigquery_region)

    try:
        with read_session() as session:
            top, totals, _opp_summary = _aggregate_totals_and_top_jobs(
                session,
                top_n=payload.limit,
                project_id=config.gcp_project_id,
                config_id=active_config_id,
            )
            if not top:
                return _errs.no_successful_scan()

            # Filter by workload kind if requested. The aggregator's
            # output already carries ``workload_kind`` per row.
            if payload.workload_kind is not None:
                top = [
                    row for row in top
                    if row.get("workload_kind") == payload.workload_kind
                ]

            scan_id, scan_window_days = _latest_scan_meta(session, active_config_id)

            rows = [_row_to_logical_job_row(row) for row in top]
            return TopCostDriversOut(
                rows=rows,
                scan_id=scan_id or "",
                scan_window_days=scan_window_days,
                grand_total_cost_usd=float(totals.get("total_cost_usd") or 0),
            )
    except _MCPPreconditionError as exc:
        return exc.tool_error
    except Exception as exc:  # noqa: BLE001
        return _errs.internal_error(str(exc))


def _row_to_logical_job_row(row: dict) -> LogicalJobRow:
    """Map the dict shape ``_aggregate_totals_and_top_jobs`` returns
    into the Pydantic ``LogicalJobRow``. Field names are intentionally
    aligned with the aggregator so this stays a near-1:1 map (FR-006).
    """
    dest = row.get("destination_table")
    if dest == "-":
        dest = None
    # Reuse the aggregator's query_hash field via the raw row dict
    # when present; older rows may not have it. (Spec 152 includes
    # this in the per-execution dict for consumption aggregation.)
    return LogicalJobRow(
        destination_table=dest,
        query_hash=row.get("query_hash"),
        short_label=row.get("short_label") or "",
        workload_kind=row.get("workload_kind") or "other",  # type: ignore[arg-type]
        cost_usd=float(row.get("cost_usd") or 0),
        cost_share_pct=float(row.get("cost_share_pct") or 0),
        bytes_processed=int(row.get("bytes_processed") or 0),
        slot_time_ms=int(row.get("slot_time_ms") or 0),
        execution_count=int(row.get("execution_count") or 1),
        issue_count=int(row.get("issue_count") or 0),
        suggestion_count=int(row.get("suggestion_count") or 0),
        latest_creation_time=row.get("creation_time"),
        is_dbt_originated=bool(row.get("is_dbt_originated")),
        opportunity_id=row.get("opportunity_id"),
    )


def _latest_scan_meta(session, config_id: str) -> tuple[str | None, int]:
    """Return ``(scan_id, lookback_days)`` for the latest successful
    scan that produced the rows we're returning. Used so the chat
    client can quote provenance ('this is from scan X, 7-day window')."""
    from sqlalchemy import desc

    from governor_audit.db.models import ScanRun

    row = (
        session.query(ScanRun)
        .filter(ScanRun.gcp_project_id.isnot(None))
        .filter(ScanRun.status == "succeeded")
        .order_by(desc(ScanRun.completed_at))
        .first()
    )
    if row is None:
        return None, 0
    return row.id, int(row.requested_lookback_days or 0)


__all__ = ["list_top_cost_drivers"]
