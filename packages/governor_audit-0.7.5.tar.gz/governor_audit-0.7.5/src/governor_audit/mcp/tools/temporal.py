"""Temporal cost rollups - cost_for_day / daily_cost_summary /
cost_compared_to_previous_period.

All three answer "what about today / this week / vs last week" by
running aggregate queries against the cached BigQueryJob rows in the
active (project, region) scope.

Read-only. No BigQuery work - everything is local SQLite.
"""

from __future__ import annotations

from datetime import datetime, timedelta, timezone
from decimal import Decimal
from typing import Iterable

from sqlalchemy import and_, func

from governor_audit.mcp.schemas import (
    CostBreakdown,
    CostComparedToPreviousPeriodIn,
    CostComparedToPreviousPeriodOut,
    CostForDayIn,
    CostForDayOut,
    DailyCostPoint,
    DailyCostSummaryIn,
    DailyCostSummaryOut,
    ToolError,
)
from governor_audit.mcp.session import _MCPPreconditionError, read_session


def _utc_today_iso() -> str:
    return datetime.now(timezone.utc).date().isoformat()


def _resolve_date(raw: str) -> str:
    """Accept 'today' / 'yesterday' / ISO date. Returns ISO date."""
    raw = (raw or "").strip().lower()
    if raw == "today":
        return _utc_today_iso()
    if raw == "yesterday":
        return (datetime.now(timezone.utc).date() - timedelta(days=1)).isoformat()
    # ISO validation
    try:
        datetime.strptime(raw, "%Y-%m-%d")
    except ValueError as exc:
        raise _MCPPreconditionError(
            ToolError(
                code="internal_error",
                message=f"Invalid date {raw!r}",
                remediation="Pass an ISO date 'YYYY-MM-DD' or the keyword 'today' / 'yesterday'.",
            )
        ) from exc
    return raw


def _workload_kind(job) -> str:
    """Mirrors governor_audit.scan.categorization, but applied at
    the MCP layer to roll up per-day totals without re-fetching the
    full opportunity dependency graph."""
    st = (getattr(job, "statement_type", None) or "").upper()
    if st in ("INSERT", "UPDATE", "DELETE", "MERGE", "CREATE_TABLE_AS_SELECT", "TRUNCATE_TABLE"):
        return "build"
    if st == "SELECT":
        return "consumption"
    return "other"


def _empty_breakdown() -> dict[str, dict]:
    return {
        k: {"cost_usd": 0.0, "bytes_processed": 0, "slot_ms": 0, "job_count": 0}
        for k in ("total", "build", "consumption", "other")
    }


def _accumulate(b: dict, job) -> None:
    b["cost_usd"] += float(job.total_cost or 0)
    b["bytes_processed"] += int(job.total_bytes_processed or 0)
    b["slot_ms"] += int(job.total_slot_ms or 0)
    b["job_count"] += 1


def _rollup_jobs(jobs: Iterable) -> dict[str, dict]:
    out = _empty_breakdown()
    for job in jobs:
        _accumulate(out["total"], job)
        _accumulate(out[_workload_kind(job)], job)
    return out


def _to_cost_breakdown(d: dict) -> CostBreakdown:
    return CostBreakdown(**d)


# ── cost_for_day ─────────────────────────────────────────────────────


def cost_for_day(payload: CostForDayIn) -> CostForDayOut | ToolError:
    from governor_audit.config.loader import ConfigNotFoundError, load_config
    from governor_audit.mcp import errors as _errs
    from governor_audit.scan.sentinels import config_id_for
    from governor_core.opportunities.models import Opportunity
    from governor_core.sync.models import BigQueryJob

    try:
        config = load_config()
    except ConfigNotFoundError:
        return _errs.not_initialised()

    active_config_id = config_id_for(config.gcp_project_id, config.bigquery_region)

    try:
        resolved = _resolve_date(payload.date)
    except _MCPPreconditionError as exc:
        return exc.tool_error

    start = datetime.fromisoformat(resolved).replace(tzinfo=timezone.utc)
    end = start + timedelta(days=1)

    try:
        with read_session() as session:
            jobs = (
                session.query(BigQueryJob)
                .filter(BigQueryJob.config_id == active_config_id)
                .filter(BigQueryJob.creation_time >= start)
                .filter(BigQueryJob.creation_time < end)
                .all()
            )
            rolled = _rollup_jobs(jobs)

            # Flagged-jobs count for the day: distinct destination_tables
            # / query_hashes whose related_job_ids intersect this day's
            # cached jobs. Cheap because we already loaded the day's
            # jobs above.
            day_job_ids = {j.job_id for j in jobs}
            flagged = 0
            if day_job_ids:
                opps = (
                    session.query(Opportunity)
                    .filter(Opportunity.config_id == active_config_id)
                    .filter(Opportunity.status == "active")
                    .all()
                )
                flagged_tables: set[str] = set()
                for opp in opps:
                    rj = set(opp.related_job_ids or [])
                    if rj & day_job_ids:
                        flagged_tables.add(opp.affected_table or f"_opp:{opp.id}")
                flagged = len(flagged_tables)

            return CostForDayOut(
                date=resolved,
                total=_to_cost_breakdown(rolled["total"]),
                build=_to_cost_breakdown(rolled["build"]),
                consumption=_to_cost_breakdown(rolled["consumption"]),
                other=_to_cost_breakdown(rolled["other"]),
                flagged_jobs_count=flagged,
            )
    except _MCPPreconditionError as exc:
        return exc.tool_error
    except Exception as exc:  # noqa: BLE001
        return _errs.internal_error(str(exc))


# ── daily_cost_summary ───────────────────────────────────────────────


def daily_cost_summary(
    payload: DailyCostSummaryIn,
) -> DailyCostSummaryOut | ToolError:
    from governor_audit.config.loader import ConfigNotFoundError, load_config
    from governor_audit.mcp import errors as _errs
    from governor_audit.scan.sentinels import config_id_for
    from governor_core.sync.models import BigQueryJob

    try:
        config = load_config()
    except ConfigNotFoundError:
        return _errs.not_initialised()

    active_config_id = config_id_for(config.gcp_project_id, config.bigquery_region)

    now = datetime.now(timezone.utc)
    cutoff = now - timedelta(days=payload.since_days)

    try:
        with read_session() as session:
            jobs = (
                session.query(BigQueryJob)
                .filter(BigQueryJob.config_id == active_config_id)
                .filter(BigQueryJob.creation_time >= cutoff)
                .order_by(BigQueryJob.creation_time.asc())
                .all()
            )

            by_day: dict[str, dict] = {}
            grand_total = 0.0
            for job in jobs:
                if job.creation_time is None:
                    continue
                day = job.creation_time.date().isoformat()
                bucket = by_day.setdefault(
                    day,
                    {"cost_usd": 0.0, "bytes_processed": 0, "slot_ms": 0, "job_count": 0},
                )
                cost = float(job.total_cost or 0)
                bucket["cost_usd"] += cost
                bucket["bytes_processed"] += int(job.total_bytes_processed or 0)
                bucket["slot_ms"] += int(job.total_slot_ms or 0)
                bucket["job_count"] += 1
                grand_total += cost

            points = [
                DailyCostPoint(day=day, **bucket)
                for day, bucket in sorted(by_day.items())
            ]
            return DailyCostSummaryOut(
                points=points,
                total_cost_usd=grand_total,
                days_with_executions=len(points),
            )
    except _MCPPreconditionError as exc:
        return exc.tool_error
    except Exception as exc:  # noqa: BLE001
        return _errs.internal_error(str(exc))


# ── cost_compared_to_previous_period ─────────────────────────────────


def cost_compared_to_previous_period(
    payload: CostComparedToPreviousPeriodIn,
) -> CostComparedToPreviousPeriodOut | ToolError:
    from governor_audit.config.loader import ConfigNotFoundError, load_config
    from governor_audit.mcp import errors as _errs
    from governor_audit.scan.sentinels import config_id_for
    from governor_core.sync.models import BigQueryJob

    try:
        config = load_config()
    except ConfigNotFoundError:
        return _errs.not_initialised()

    active_config_id = config_id_for(config.gcp_project_id, config.bigquery_region)

    now = datetime.now(timezone.utc)
    current_end = now
    current_start = now - timedelta(days=payload.period_days)
    previous_end = current_start
    previous_start = current_start - timedelta(days=payload.period_days)

    try:
        with read_session() as session:
            def _sum_for(start: datetime, end: datetime) -> dict:
                jobs = (
                    session.query(BigQueryJob)
                    .filter(BigQueryJob.config_id == active_config_id)
                    .filter(BigQueryJob.creation_time >= start)
                    .filter(BigQueryJob.creation_time < end)
                    .all()
                )
                out = {"cost_usd": 0.0, "bytes_processed": 0, "slot_ms": 0, "job_count": 0}
                for j in jobs:
                    out["cost_usd"] += float(j.total_cost or 0)
                    out["bytes_processed"] += int(j.total_bytes_processed or 0)
                    out["slot_ms"] += int(j.total_slot_ms or 0)
                    out["job_count"] += 1
                return out

            cur = _sum_for(current_start, current_end)
            prev = _sum_for(previous_start, previous_end)

            delta = cur["cost_usd"] - prev["cost_usd"]
            pct: float | None
            if prev["cost_usd"] > 0:
                pct = (delta / prev["cost_usd"]) * 100.0
            else:
                pct = None  # avoid div-by-zero

            return CostComparedToPreviousPeriodOut(
                current_period=CostBreakdown(**cur),
                previous_period=CostBreakdown(**prev),
                current_period_start=current_start,
                current_period_end=current_end,
                previous_period_start=previous_start,
                previous_period_end=previous_end,
                delta_cost_usd=delta,
                delta_pct=pct,
            )
    except _MCPPreconditionError as exc:
        return exc.tool_error
    except Exception as exc:  # noqa: BLE001
        return _errs.internal_error(str(exc))


__all__ = [
    "cost_for_day",
    "daily_cost_summary",
    "cost_compared_to_previous_period",
]
