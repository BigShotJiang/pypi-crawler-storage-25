"""``scan_status()`` - current in-flight scan (if any) + last successful
scan summary.

Special: this is the one tool where "no successful scan" is a
legitimate normal state, not an error. The audit may be installed
but not yet scanned (US1's AS-5 scenario); we want the chat client
to be able to phrase that without bailing on an error.
"""

from __future__ import annotations

from governor_audit.mcp.schemas import ScanStatusOut, ScanSummary, ToolError
from governor_audit.mcp.session import _MCPPreconditionError, read_session


def scan_status() -> ScanStatusOut | ToolError:
    from sqlalchemy import desc

    from governor_audit.db.models import ScanRun
    from governor_audit.mcp import errors as _errs

    try:
        with read_session() as session:
            running = (
                session.query(ScanRun)
                .filter(ScanRun.status == "running")
                .order_by(desc(ScanRun.started_at))
                .first()
            )
            latest = (
                session.query(ScanRun)
                .filter(ScanRun.status == "succeeded")
                .order_by(desc(ScanRun.completed_at))
                .first()
            )

            latest_summary = None
            if latest is not None:
                latest_summary = ScanSummary(
                    scan_id=latest.id,
                    started_at=latest.started_at,
                    completed_at=latest.completed_at,
                    lookback_days=latest.requested_lookback_days,
                    fetched_job_count=latest.fetched_job_count or 0,
                    opportunity_count=latest.opportunity_count,
                    actual_cost_usd=(
                        float(latest.actual_cost_usd)
                        if latest.actual_cost_usd is not None
                        else None
                    ),
                )

            if running is not None:
                return ScanStatusOut(
                    in_progress=True,
                    current_phase=(running.current_phase or "starting"),  # type: ignore[arg-type]
                    started_at=running.started_at,
                    completed_at=None,
                    latest_succeeded_scan=latest_summary,
                )
            return ScanStatusOut(
                in_progress=False,
                current_phase=None,
                started_at=None,
                completed_at=None,
                latest_succeeded_scan=latest_summary,
            )
    except _MCPPreconditionError as exc:
        return exc.tool_error
    except Exception as exc:  # noqa: BLE001
        return _errs.internal_error(str(exc))


__all__ = ["scan_status"]
