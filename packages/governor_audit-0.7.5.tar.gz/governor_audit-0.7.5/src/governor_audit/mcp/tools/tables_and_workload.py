"""Table-level + workload-classification + storage tools.

Bundled because each is short and they share imports.

- ``opportunities_for_table`` / ``table_summary`` (Cluster E)
- ``workload_breakdown`` / ``dbt_origin_summary`` (Cluster F)
- ``dataset_storage_summary`` (Cluster H)
- ``audit_config_summary`` (Cluster I)
"""

from __future__ import annotations

from governor_audit.mcp.schemas import (
    AuditConfigSummaryOut,
    CostBreakdown,
    DatasetStorageRow,
    DatasetStorageSummaryOut,
    DbtOriginSummaryOut,
    OpportunitiesForTableIn,
    OpportunitiesForTableOut,
    OpportunityBriefRow,
    TableSummaryIn,
    TableSummaryOut,
    ToolError,
    UserCostRow,
    WorkloadBreakdownOut,
)
from governor_audit.mcp.session import _MCPPreconditionError, read_session


# ── opportunities_for_table ──────────────────────────────────────────


def opportunities_for_table(
    payload: OpportunitiesForTableIn,
) -> OpportunitiesForTableOut | ToolError:
    from governor_audit.config.loader import ConfigNotFoundError, load_config
    from governor_audit.mcp import errors as _errs
    from governor_audit.scan.categorization import ISSUE_RULE_TYPES
    from governor_audit.scan.sentinels import config_id_for
    from governor_core.opportunities.models import Opportunity

    try:
        config = load_config()
    except ConfigNotFoundError:
        return _errs.not_initialised()

    active_config_id = config_id_for(config.gcp_project_id, config.bigquery_region)

    try:
        with read_session() as session:
            opps = (
                session.query(Opportunity)
                .filter(Opportunity.config_id == active_config_id)
                .filter(Opportunity.affected_table == payload.table_full_name)
                .filter(Opportunity.status == "active")
                .all()
            )

            issues, suggestions = [], []
            for opp in opps:
                row = OpportunityBriefRow(
                    opportunity_id=opp.id,
                    rule_type=opp.opportunity_type,
                    severity_score=int(opp.severity_score or 0),
                    current_cost_estimate_usd=float(opp.current_cost_estimate or 0),
                    explanation=(opp.explanation or "")[:500],
                    is_issue=opp.opportunity_type in ISSUE_RULE_TYPES,
                )
                if row.is_issue:
                    issues.append(row)
                else:
                    suggestions.append(row)

            return OpportunitiesForTableOut(
                table_full_name=payload.table_full_name,
                issues=issues,
                suggestions=suggestions,
                total_count=len(opps),
            )
    except _MCPPreconditionError as exc:
        return exc.tool_error
    except Exception as exc:  # noqa: BLE001
        return _errs.internal_error(str(exc))


# ── table_summary ────────────────────────────────────────────────────


def table_summary(payload: TableSummaryIn) -> TableSummaryOut | ToolError:
    from governor_audit.config.loader import ConfigNotFoundError, load_config
    from governor_audit.db.models import LayoutRecommendation
    from governor_audit.jobs.cohort_view import build_cohort_view
    from governor_audit.mcp import errors as _errs
    from governor_audit.scan.categorization import ISSUE_RULE_TYPES
    from governor_audit.scan.sentinels import config_id_for
    from governor_core.opportunities.models import Opportunity

    try:
        config = load_config()
    except ConfigNotFoundError:
        return _errs.not_initialised()

    active_config_id = config_id_for(config.gcp_project_id, config.bigquery_region)

    try:
        with read_session() as session:
            view = build_cohort_view(
                session,
                config_id=active_config_id,
                destination_table=payload.table_full_name,
            )
            if view is None:
                return ToolError(
                    code="table_not_found",
                    message=(
                        f"No cached executions for table "
                        f"{payload.table_full_name!r}."
                    ),
                    remediation=(
                        "Check the table name (project.dataset.table). "
                        "Re-scan if the table is newly written."
                    ),
                )
            opps = (
                session.query(Opportunity)
                .filter(Opportunity.config_id == active_config_id)
                .filter(Opportunity.affected_table == payload.table_full_name)
                .filter(Opportunity.status == "active")
                .all()
            )
            issue_count = sum(
                1 for o in opps if o.opportunity_type in ISSUE_RULE_TYPES
            )
            suggestion_count = len(opps) - issue_count

            rec = (
                session.query(LayoutRecommendation)
                .filter(LayoutRecommendation.config_id == active_config_id)
                .filter(
                    LayoutRecommendation.table_full_name == payload.table_full_name
                )
                .first()
            )

            latest_creation = None
            if view.versions:
                # Versions chronological; last entry's last_seen is the
                # most recent execution.
                latest_creation = view.versions[-1].last_seen

            return TableSummaryOut(
                table_full_name=payload.table_full_name,
                total_cost_usd=float(view.total_cost_usd or 0),
                total_executions=view.total_executions,
                distinct_versions=len(view.versions),
                days_with_executions=view.days_with_executions,
                latest_execution_at=latest_creation,
                issue_count=issue_count,
                suggestion_count=suggestion_count,
                has_layout_recommendation=rec is not None,
                is_currently_partitioned=(
                    bool(rec.table_is_currently_partitioned) if rec else None
                ),
            )
    except _MCPPreconditionError as exc:
        return exc.tool_error
    except Exception as exc:  # noqa: BLE001
        return _errs.internal_error(str(exc))


# ── workload_breakdown ───────────────────────────────────────────────


def _workload_kind(job) -> str:
    st = (getattr(job, "statement_type", None) or "").upper()
    if st in ("INSERT", "UPDATE", "DELETE", "MERGE", "CREATE_TABLE_AS_SELECT", "TRUNCATE_TABLE"):
        return "build"
    if st == "SELECT":
        return "consumption"
    return "other"


def workload_breakdown() -> WorkloadBreakdownOut | ToolError:
    from governor_audit.config.loader import ConfigNotFoundError, load_config
    from governor_audit.mcp import errors as _errs
    from governor_audit.scan.sentinels import config_id_for
    from governor_core.sync.models import BigQueryJob

    try:
        config = load_config()
    except ConfigNotFoundError:
        return _errs.not_initialised()

    active_config_id = config_id_for(config.gcp_project_id, config.bigquery_region)

    try:
        with read_session() as session:
            jobs = (
                session.query(BigQueryJob)
                .filter(BigQueryJob.config_id == active_config_id)
                .all()
            )
            if not jobs:
                return _errs.no_successful_scan()

            agg = {
                "build": {"cost_usd": 0.0, "bytes_processed": 0, "slot_ms": 0, "job_count": 0},
                "consumption": {"cost_usd": 0.0, "bytes_processed": 0, "slot_ms": 0, "job_count": 0},
                "other": {"cost_usd": 0.0, "bytes_processed": 0, "slot_ms": 0, "job_count": 0},
            }
            for job in jobs:
                kind = _workload_kind(job)
                a = agg[kind]
                a["cost_usd"] += float(job.total_cost or 0)
                a["bytes_processed"] += int(job.total_bytes_processed or 0)
                a["slot_ms"] += int(job.total_slot_ms or 0)
                a["job_count"] += 1

            total = sum(a["cost_usd"] for a in agg.values())
            def _pct(v: float) -> float:
                return (v / total * 100.0) if total > 0 else 0.0

            return WorkloadBreakdownOut(
                build=CostBreakdown(**agg["build"]),
                consumption=CostBreakdown(**agg["consumption"]),
                other=CostBreakdown(**agg["other"]),
                total_cost_usd=total,
                build_pct=_pct(agg["build"]["cost_usd"]),
                consumption_pct=_pct(agg["consumption"]["cost_usd"]),
                other_pct=_pct(agg["other"]["cost_usd"]),
            )
    except _MCPPreconditionError as exc:
        return exc.tool_error
    except Exception as exc:  # noqa: BLE001
        return _errs.internal_error(str(exc))


# ── dbt_origin_summary ───────────────────────────────────────────────


def dbt_origin_summary() -> DbtOriginSummaryOut | ToolError:
    from governor_audit.config.loader import ConfigNotFoundError, load_config
    from governor_audit.mcp import errors as _errs
    from governor_audit.scan.information_schema import is_dbt_originated
    from governor_audit.scan.sentinels import config_id_for
    from governor_core.sync.models import BigQueryJob

    try:
        config = load_config()
    except ConfigNotFoundError:
        return _errs.not_initialised()

    active_config_id = config_id_for(config.gcp_project_id, config.bigquery_region)

    try:
        with read_session() as session:
            jobs = (
                session.query(BigQueryJob)
                .filter(BigQueryJob.config_id == active_config_id)
                .all()
            )
            if not jobs:
                return _errs.no_successful_scan()

            agg = {
                "dbt": {"cost_usd": 0.0, "bytes_processed": 0, "slot_ms": 0, "job_count": 0},
                "non_dbt": {"cost_usd": 0.0, "bytes_processed": 0, "slot_ms": 0, "job_count": 0},
            }
            non_dbt_user_agg: dict[str | None, dict] = {}
            for job in jobs:
                # The audit's BigQueryJob table doesn't persist the
                # raw INFORMATION_SCHEMA ``labels`` column, so dbt
                # attribution falls back to the query-prefix signal
                # (``/* {"app": "dbt"`` - see is_dbt_originated).
                as_dict = {
                    "query": job.query,
                    "query_hashes": job.query_hashes,
                }
                is_dbt = is_dbt_originated(as_dict)
                bucket = agg["dbt" if is_dbt else "non_dbt"]
                cost = float(job.total_cost or 0)
                bucket["cost_usd"] += cost
                bucket["bytes_processed"] += int(job.total_bytes_processed or 0)
                bucket["slot_ms"] += int(job.total_slot_ms or 0)
                bucket["job_count"] += 1
                if not is_dbt:
                    u = non_dbt_user_agg.setdefault(
                        job.user_email,
                        {
                            "cost_usd": 0.0,
                            "job_count": 0,
                            "bytes_processed": 0,
                            "slot_ms": 0,
                            "flagged_job_count": 0,
                        },
                    )
                    u["cost_usd"] += cost
                    u["job_count"] += 1
                    u["bytes_processed"] += int(job.total_bytes_processed or 0)
                    u["slot_ms"] += int(job.total_slot_ms or 0)

            total = agg["dbt"]["cost_usd"] + agg["non_dbt"]["cost_usd"]
            dbt_pct = (agg["dbt"]["cost_usd"] / total * 100.0) if total > 0 else 0.0

            top_users = sorted(
                non_dbt_user_agg.items(), key=lambda kv: kv[1]["cost_usd"], reverse=True
            )[:5]
            top_user_rows = [
                UserCostRow(user_email=email, **stats)
                for email, stats in top_users
            ]

            return DbtOriginSummaryOut(
                dbt=CostBreakdown(**agg["dbt"]),
                non_dbt=CostBreakdown(**agg["non_dbt"]),
                dbt_pct=dbt_pct,
                top_non_dbt_users=top_user_rows,
            )
    except _MCPPreconditionError as exc:
        return exc.tool_error
    except Exception as exc:  # noqa: BLE001
        return _errs.internal_error(str(exc))


# ── dataset_storage_summary ──────────────────────────────────────────


def dataset_storage_summary() -> DatasetStorageSummaryOut | ToolError:
    from governor_audit.config.loader import ConfigNotFoundError, load_config
    from governor_audit.mcp import errors as _errs
    from governor_audit.scan.sentinels import config_id_for
    from governor_core.sync.models import TableStorageMetric

    try:
        config = load_config()
    except ConfigNotFoundError:
        return _errs.not_initialised()

    active_config_id = config_id_for(config.gcp_project_id, config.bigquery_region)

    # Storage pricing - matches packages/core/.../storage_pricing.py.
    # US multi-region rates; per-GiB-month.
    ACTIVE_LOGICAL = 0.02
    LONG_TERM_LOGICAL = 0.01
    ACTIVE_PHYSICAL = 0.04
    LONG_TERM_PHYSICAL = 0.02
    GIB = 2 ** 30

    try:
        with read_session() as session:
            metrics = (
                session.query(TableStorageMetric)
                .filter(TableStorageMetric.config_id == active_config_id)
                .all()
            )
            if not metrics:
                return _errs.no_successful_scan()

            # Aggregate per dataset.
            by_ds: dict[str, dict] = {}
            for m in metrics:
                key = m.dataset_name or ""
                a = by_ds.setdefault(
                    key,
                    {
                        "billing_model": (m.billing_model or "LOGICAL").upper(),
                        "active_logical_bytes": 0,
                        "long_term_logical_bytes": 0,
                        "active_physical_bytes": 0,
                        "long_term_physical_bytes": 0,
                        "table_count": 0,
                    },
                )
                a["active_logical_bytes"] += int(m.active_logical_bytes or 0)
                a["long_term_logical_bytes"] += int(m.long_term_logical_bytes or 0)
                a["active_physical_bytes"] += int(m.active_physical_bytes or 0)
                a["long_term_physical_bytes"] += int(m.long_term_physical_bytes or 0)
                a["table_count"] += 1

            rows: list[DatasetStorageRow] = []
            total_monthly = 0.0
            physical_count = 0
            logical_count = 0
            for ds, a in sorted(by_ds.items()):
                if a["billing_model"] == "PHYSICAL":
                    physical_count += 1
                    monthly = (
                        (a["active_physical_bytes"] / GIB) * ACTIVE_PHYSICAL
                        + (a["long_term_physical_bytes"] / GIB) * LONG_TERM_PHYSICAL
                    )
                else:
                    logical_count += 1
                    monthly = (
                        (a["active_logical_bytes"] / GIB) * ACTIVE_LOGICAL
                        + (a["long_term_logical_bytes"] / GIB) * LONG_TERM_LOGICAL
                    )
                logical_total = a["active_logical_bytes"] + a["long_term_logical_bytes"]
                physical_total = a["active_physical_bytes"] + a["long_term_physical_bytes"]
                compression = (
                    logical_total / physical_total if physical_total > 0 else 0.0
                )
                rows.append(
                    DatasetStorageRow(
                        dataset_name=ds,
                        billing_model=a["billing_model"],
                        active_logical_bytes=a["active_logical_bytes"],
                        long_term_logical_bytes=a["long_term_logical_bytes"],
                        active_physical_bytes=a["active_physical_bytes"],
                        long_term_physical_bytes=a["long_term_physical_bytes"],
                        table_count=a["table_count"],
                        monthly_cost_usd=monthly,
                        compression_ratio=compression,
                    )
                )
                total_monthly += monthly

            return DatasetStorageSummaryOut(
                datasets=rows,
                total_monthly_cost_usd=total_monthly,
                physical_datasets=physical_count,
                logical_datasets=logical_count,
            )
    except _MCPPreconditionError as exc:
        return exc.tool_error
    except Exception as exc:  # noqa: BLE001
        return _errs.internal_error(str(exc))


# ── audit_config_summary ─────────────────────────────────────────────


def audit_config_summary() -> AuditConfigSummaryOut | ToolError:
    from governor_audit.config.loader import ConfigNotFoundError, load_config
    from governor_audit.mcp import errors as _errs
    from governor_audit.scan.categorization import (
        IMPROVEMENT_RULE_TYPES,
        ISSUE_RULE_TYPES,
    )
    from governor_audit.version import get_app_version

    try:
        config = load_config()
    except ConfigNotFoundError:
        return _errs.not_initialised()

    try:
        # Compute enabled/disabled rules from catalog defaults
        # ∪ per-rule overrides.
        all_known = set(ISSUE_RULE_TYPES) | set(IMPROVEMENT_RULE_TYPES)
        overrides = dict(config.detection_rule_overrides or {})
        enabled: list[str] = []
        disabled: list[str] = []
        for rt in sorted(all_known):
            # Override wins; default = enabled.
            if overrides.get(rt) is False:
                disabled.append(rt)
            else:
                enabled.append(rt)

        return AuditConfigSummaryOut(
            gcp_project_id=config.gcp_project_id,
            bigquery_region=config.bigquery_region,
            billing_project_id=config.billing_project_id,
            lookback_days=int(config.scan_defaults.lookback_days),
            min_solution_cost_usd=float(config.scan_defaults.min_solution_cost_usd),
            dbt_only_default=bool(config.scan_defaults.dbt_only),
            detection_top_n_jobs=config.scan_defaults.detection_top_n_jobs,
            enabled_rules=enabled,
            disabled_rules=disabled,
            llm_provider=(config.llm.provider if config.llm.api_key else None),
            llm_model=(config.llm.model if config.llm.api_key else None),
            audit_version=get_app_version(),
        )
    except Exception as exc:  # noqa: BLE001
        return _errs.internal_error(str(exc))


__all__ = [
    "opportunities_for_table",
    "table_summary",
    "workload_breakdown",
    "dbt_origin_summary",
    "dataset_storage_summary",
    "audit_config_summary",
]
