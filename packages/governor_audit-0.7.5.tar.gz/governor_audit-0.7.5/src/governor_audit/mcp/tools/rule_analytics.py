"""Rule analytics - rule_summary (across all rules) and
worst_offenders_per_rule (top tables for one rule).

Both walk the Opportunity table; cheap because the audit DB is bounded.
"""

from __future__ import annotations

from governor_audit.mcp.schemas import (
    RuleSummaryOut,
    RuleSummaryRow,
    ToolError,
    WorstOffenderRow,
    WorstOffendersPerRuleIn,
    WorstOffendersPerRuleOut,
)
from governor_audit.mcp.session import _MCPPreconditionError, read_session


def rule_summary() -> RuleSummaryOut | ToolError:
    from governor_audit.config.loader import ConfigNotFoundError, load_config
    from governor_audit.mcp import errors as _errs
    from governor_audit.scan.sentinels import config_id_for
    from governor_core.opportunities.models import Opportunity

    try:
        config = load_config()
    except ConfigNotFoundError:
        return _errs.not_initialised()

    active_config_id = config_id_for(config.gcp_project_id, config.bigquery_region)

    try:
        with read_session() as session:
            opps = (
                session.query(Opportunity)
                .filter(Opportunity.config_id == active_config_id)
                .filter(Opportunity.status == "active")
                .all()
            )
            if not opps:
                return RuleSummaryOut(rules=[], total_opportunities=0)

            # Per-rule aggregation: count + total cost + per-table cost.
            by_rule: dict[str, dict] = {}
            for opp in opps:
                rt = opp.opportunity_type
                bucket = by_rule.setdefault(
                    rt,
                    {"count": 0, "total_cost": 0.0, "per_table": {}},
                )
                bucket["count"] += 1
                cost = float(opp.current_cost_estimate or 0)
                bucket["total_cost"] += cost
                if opp.affected_table:
                    bucket["per_table"][opp.affected_table] = (
                        bucket["per_table"].get(opp.affected_table, 0.0) + cost
                    )

            rows = []
            for rt, b in by_rule.items():
                top_tables_sorted = sorted(
                    b["per_table"].items(), key=lambda kv: kv[1], reverse=True
                )[:3]
                rows.append(
                    RuleSummaryRow(
                        rule_type=rt,
                        opportunity_count=b["count"],
                        total_cost_usd=b["total_cost"],
                        top_affected_tables=[t for t, _ in top_tables_sorted],
                    )
                )
            rows.sort(key=lambda r: r.total_cost_usd, reverse=True)
            return RuleSummaryOut(rules=rows, total_opportunities=len(opps))
    except _MCPPreconditionError as exc:
        return exc.tool_error
    except Exception as exc:  # noqa: BLE001
        return _errs.internal_error(str(exc))


def worst_offenders_per_rule(
    payload: WorstOffendersPerRuleIn,
) -> WorstOffendersPerRuleOut | ToolError:
    from governor_audit.config.loader import ConfigNotFoundError, load_config
    from governor_audit.mcp import errors as _errs
    from governor_audit.scan.sentinels import config_id_for
    from governor_core.opportunities.models import Opportunity
    from governor_core.sync.models import BigQueryJob

    try:
        config = load_config()
    except ConfigNotFoundError:
        return _errs.not_initialised()

    active_config_id = config_id_for(config.gcp_project_id, config.bigquery_region)

    try:
        with read_session() as session:
            opps = (
                session.query(Opportunity)
                .filter(Opportunity.config_id == active_config_id)
                .filter(Opportunity.status == "active")
                .filter(Opportunity.opportunity_type == payload.rule_type)
                .all()
            )
            if not opps:
                return WorstOffendersPerRuleOut(
                    rule_type=payload.rule_type, rows=[]
                )

            # For each opp, sum cost across its related_job_ids (real
            # aggregated cost, not the rule's hardcoded estimate).
            all_job_ids: set[str] = set()
            for opp in opps:
                for jid in (opp.related_job_ids or []):
                    all_job_ids.add(jid)
            jobs_by_id: dict[str, "BigQueryJob"] = {}
            if all_job_ids:
                from governor_audit.scan.persistence import (
                    _SQLITE_MAX_IN_PARAMS,
                    _chunked,
                )
                for batch in _chunked(list(all_job_ids), _SQLITE_MAX_IN_PARAMS):
                    for j in (
                        session.query(BigQueryJob)
                        .filter(BigQueryJob.config_id == active_config_id)
                        .filter(BigQueryJob.job_id.in_(batch))
                        .all()
                    ):
                        jobs_by_id[j.job_id] = j

            rows = []
            for opp in opps:
                related = list(opp.related_job_ids or [])
                aggregated_cost = sum(
                    float(jobs_by_id[jid].total_cost or 0)
                    for jid in related
                    if jid in jobs_by_id
                )
                rows.append(
                    WorstOffenderRow(
                        affected_table=opp.affected_table or "",
                        cost_usd=aggregated_cost,
                        job_count=len(related),
                        severity_score=int(opp.severity_score or 0),
                        opportunity_id=opp.id,
                    )
                )
            rows.sort(key=lambda r: r.cost_usd, reverse=True)
            return WorstOffendersPerRuleOut(
                rule_type=payload.rule_type,
                rows=rows[: payload.limit],
            )
    except _MCPPreconditionError as exc:
        return exc.tool_error
    except Exception as exc:  # noqa: BLE001
        return _errs.internal_error(str(exc))


__all__ = ["rule_summary", "worst_offenders_per_rule"]
