"""SQLAlchemy engine + session factory for ``~/.governor-audit/state.db``.

Single-process, single-tenant SQLite with WAL mode. The compat shim is
applied to the metadata at import time of ``governor_audit.db.base``;
this module just builds the engine + session.
"""

from __future__ import annotations

import os
from contextlib import contextmanager
from pathlib import Path

from sqlalchemy import create_engine
from sqlalchemy.engine import Engine
from sqlalchemy.orm import Session, sessionmaker

# Importing ``base`` triggers metadata registration + sqlite_compat shim.
from governor_audit.config.loader import config_dir, ensure_config_dir
from governor_audit.db.base import Base, attach_sqlite_pragmas

DB_FILENAME = "state.db"
DB_FILE_MODE = 0o600


def db_path(dir_override: Path | None = None) -> Path:
    return config_dir(dir_override) / DB_FILENAME


def database_url(dir_override: Path | None = None) -> str:
    return f"sqlite:///{db_path(dir_override)}"


def build_engine(
    *,
    dir_override: Path | None = None,
    in_memory: bool = False,
) -> Engine:
    """Build a SQLAlchemy engine pointing at the audit cache."""
    if in_memory:
        url = "sqlite:///:memory:"
    else:
        ensure_config_dir(dir_override)
        url = database_url(dir_override)
    engine = create_engine(url, future=True)
    attach_sqlite_pragmas(engine)
    return engine


def create_all(engine: Engine) -> None:
    """Create every table registered on ``Base.metadata`` (core + audit),
    then apply the lightweight column-add migrations the audit needs
    when ORM models gain new columns after a user's DB was first
    initialised. ``CREATE TABLE IF NOT EXISTS`` doesn't backfill
    columns; this fills that gap.
    """
    Base.metadata.create_all(engine)
    _apply_lightweight_migrations(engine)


def _apply_lightweight_migrations(engine: Engine) -> None:
    """Idempotent ``ALTER TABLE … ADD COLUMN`` for audit-side schema
    bumps. The audit is single-writer / single-user, so we can use
    plain SQLite DDL instead of bringing in Alembic. Each migration
    checks ``PRAGMA table_info`` before issuing the ALTER so re-runs
    are no-ops.

    Add new migrations here when an audit-side model gains a column.
    Cloud-side ``governor_core`` models are migrated via Alembic
    upstream and aren't our problem here.
    """
    from sqlalchemy import text

    migrations = [
        # Spec 151 polish - scan progress bar. ScanRun gained
        # current_phase to drive the configurations-page progress
        # bar; existing DBs need the column backfilled.
        ("scan_runs", "current_phase", "VARCHAR(32)"),
    ]

    import logging as _logging

    _log = _logging.getLogger("governor_audit.db.migrate")

    with engine.begin() as conn:
        for table, column, column_type in migrations:
            try:
                existing = conn.execute(
                    text(f"PRAGMA table_info({table})")
                ).fetchall()
            except Exception as exc:
                # Audit-H11: previously this swallowed any error from
                # PRAGMA silently and skipped the migration. A transient
                # SQLite lock would silently drop a needed column-add,
                # leaving the model declaring a column the DB doesn't
                # have. Log loudly and let the caller decide whether
                # to bail - migrations run once at process startup,
                # so failing fast surfaces problems before any query
                # references the missing column.
                _log.warning(
                    "lightweight migration: PRAGMA table_info(%s) failed "
                    "(%s) - the ALTER TABLE for column %r will be skipped. "
                    "If the column is missing the next query that "
                    "references it will raise; re-running governor-audit "
                    "should retry.",
                    table, exc, column,
                )
                continue
            existing_columns = {row[1] for row in existing}
            if column in existing_columns:
                continue
            try:
                conn.execute(
                    text(f"ALTER TABLE {table} ADD COLUMN {column} {column_type}")
                )
                _log.info(
                    "lightweight migration: added %s.%s (%s)",
                    table, column, column_type,
                )
            except Exception as exc:
                _log.error(
                    "lightweight migration: ALTER TABLE %s ADD COLUMN %s "
                    "%s failed (%s). The next query referencing the "
                    "column will raise.",
                    table, column, column_type, exc,
                )
                raise


def chmod_db_file(dir_override: Path | None = None) -> None:
    """Apply 0600 to the on-disk SQLite file. No-op if file is missing."""
    path = db_path(dir_override)
    if path.exists():
        os.chmod(path, DB_FILE_MODE)


def make_session_factory(engine: Engine):
    return sessionmaker(bind=engine, expire_on_commit=False, future=True)


@contextmanager
def session_scope(session_factory):
    """Provide a transactional scope around a series of operations."""
    session: Session = session_factory()
    try:
        yield session
        session.commit()
    except Exception:
        session.rollback()
        raise
    finally:
        session.close()


__all__ = [
    "DB_FILENAME",
    "Base",
    "build_engine",
    "chmod_db_file",
    "create_all",
    "database_url",
    "db_path",
    "make_session_factory",
    "session_scope",
]
