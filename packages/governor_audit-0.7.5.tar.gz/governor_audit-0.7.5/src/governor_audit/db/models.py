"""governor-audit's own SQLite tables: ``ScanRun`` + ``AuditOpportunityMetadata``.

The reused tables (``BigQueryJob``, ``Opportunity``, ``DetectionJob``,
``ManifestConfiguration``, etc.) come from ``governor_core`` ORM models
via the shared ``Base.metadata``. We do NOT redeclare them - see
data-model.md § "Tables imported from governor-core".

Audit-specific indexes on the reused ``bigquery_jobs`` table are added
at the bottom of this module (after model registration) so they live in
the audit-side schema without modifying the upstream model class.
"""

from __future__ import annotations

import uuid
from datetime import datetime
from decimal import Decimal
from typing import Optional

from sqlalchemy import (
    BigInteger,
    Boolean,
    CheckConstraint,
    DateTime,
    Float,
    ForeignKey,
    Index,
    Integer,
    JSON,
    Numeric,
    String,
    Text,
    UniqueConstraint,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from governor_core.db.base import Base


def _utcnow() -> datetime:
    from datetime import timezone
    return datetime.now(timezone.utc)


def _new_id(prefix: str) -> str:
    return f"{prefix}_{uuid.uuid4().hex}"


class ScanRun(Base):
    """One row per ``governor-audit scan`` invocation.

    Audit-of-audit log surface - every BigQuery query the package issues
    is recorded with its dry-run estimate, actual bytes billed, manifest
    hash in effect, and resulting opportunity count. Surfaced in the
    web UI under ``/scans``.
    """

    __tablename__ = "scan_runs"

    id: Mapped[str] = mapped_column(String(80), primary_key=True)
    started_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, default=_utcnow
    )
    completed_at: Mapped[Optional[datetime]] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    status: Mapped[str] = mapped_column(String(16), nullable=False, default="running")
    requested_lookback_days: Mapped[int] = mapped_column(Integer, nullable=False)
    actual_window_start: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False
    )
    actual_window_end: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False
    )
    cached_job_count: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    fetched_job_count: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    dry_run_estimated_bytes: Mapped[int] = mapped_column(BigInteger, nullable=False)
    actual_bytes_billed: Mapped[Optional[int]] = mapped_column(
        BigInteger, nullable=True
    )
    estimated_cost_usd: Mapped[Decimal] = mapped_column(
        Numeric(10, 4), nullable=False, default=Decimal("0")
    )
    actual_cost_usd: Mapped[Optional[Decimal]] = mapped_column(
        Numeric(10, 4), nullable=True
    )
    gcp_project_id: Mapped[str] = mapped_column(String(64), nullable=False)
    bigquery_region: Mapped[str] = mapped_column(String(64), nullable=False)
    # NEW: tracks whether this scan was filtered to dbt-originated jobs.
    # Cached rows from the opposite filter setting are not reusable for
    # the other filter, so this is the cache-key discriminator too.
    dbt_only_filter: Mapped[bool] = mapped_column(
        Boolean, nullable=False, default=False
    )
    opportunity_count: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    failure_reason: Mapped[Optional[str]] = mapped_column(String(64), nullable=True)
    failure_message: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    # Spec 151 polish - the user-facing scan progress stage so the
    # ``/admin/configurations`` page can render a progress bar while
    # ``status = 'running'``. Updated at each ``timer.phase(...)``
    # boundary in scan/orchestrator.py and committed independently so
    # the auto-refreshing page sees fresh state without waiting for
    # the entire scan to finish.
    #
    # Known values (matches the bar's 4-stage rendering):
    #   "starting"            - initial, before any phase has run
    #   "fetching"            - INFORMATION_SCHEMA jobs/columns/storage
    #   "persisting"          - writing rows to SQLite
    #   "detection"           - running governor-core detection rules
    #   "recommendations"     - table-level layout recommender
    current_phase: Mapped[Optional[str]] = mapped_column(String(32), nullable=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, default=_utcnow
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, default=_utcnow, onupdate=_utcnow
    )

    @staticmethod
    def new_id() -> str:
        return _new_id("scan")


class AuditOpportunityMetadata(Base):
    """Audit-side provenance for each opportunity row.

    Sidecar table - does NOT modify ``governor_core.opportunities.models.Opportunity``
    (which would violate FR-042). Carries: which scan produced this
    opportunity, dbt attribution derived from BigQuery labels at scan
    time (manifest-free), and the normalized-literals query hash used
    for grouping near-identical queries.

    **v2 change**: ``manifest_content_hash`` and ``is_stale`` removed
    (no manifest to track). ``is_dbt_originated`` added.

    **v2.1 change** (this commit): ``dbt_node_id``,
    ``dbt_invocation_id``, ``query_hash`` added. All three are derived
    from BigQuery's INFORMATION_SCHEMA columns at scan time - no
    governor-core schema change required.
    """

    __tablename__ = "audit_opportunity_metadata"

    opportunity_id: Mapped[str] = mapped_column(
        String(36),
        ForeignKey("opportunities.id", ondelete="CASCADE"),
        primary_key=True,
    )
    scan_run_id: Mapped[str] = mapped_column(
        String(80),
        ForeignKey("scan_runs.id", ondelete="CASCADE"),
        nullable=False,
    )
    is_dbt_originated: Mapped[bool] = mapped_column(
        Boolean, nullable=False, default=False
    )
    # NEW: dbt attribution from BigQuery labels (manifest-free). All
    # nullable because non-dbt jobs (analyst SQL, BI tools, etc.) don't
    # carry these labels.
    dbt_node_id: Mapped[str | None] = mapped_column(
        String(512), nullable=True,
        doc="dbt node identifier from labels.node_id, e.g. 'model.warehouse.fct_orders'",
    )
    dbt_invocation_id: Mapped[str | None] = mapped_column(
        String(64), nullable=True,
        doc="dbt invocation UUID from labels.dbt_invocation_id, groups jobs from one `dbt run`",
    )
    # NEW: query-hash grouping. From query_info.query_hashes.normalized_literals.
    # Same hash → same logical query (different literals/comments/parameters).
    # Lets the UI roll up "1247 occurrences of this query" instead of
    # 1247 individual findings.
    query_hash: Mapped[str | None] = mapped_column(
        String(64), nullable=True,
        doc="normalized_literals hash from query_info.query_hashes",
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, default=_utcnow
    )


# Audit-side indexes on the reused bigquery_jobs table - added after
# model registration so they don't require touching the upstream model.
# These accelerate the incremental-fetch and findings-attribution
# workflows critical to scan performance (SC-002 / SC-003).
_bq_jobs_table = Base.metadata.tables.get("bigquery_jobs")
if _bq_jobs_table is not None:
    Index(
        "ix_audit_bigquery_jobs_creation_time",
        _bq_jobs_table.c.creation_time,
    )

Index("ix_audit_scan_runs_started_at", ScanRun.started_at)
Index("ix_audit_scan_runs_status", ScanRun.status)

# Roll-up indexes for the UI: "show me all findings for this dbt model"
# / "group by query hash". Both are nullable, but indexed where present.
Index("ix_audit_opp_metadata_dbt_node_id", AuditOpportunityMetadata.dbt_node_id)
Index("ix_audit_opp_metadata_query_hash", AuditOpportunityMetadata.query_hash)


class LayoutRecommendation(Base):
    """Spec 151 - one persisted recommendation per (scan, table).

    Replaces spec 148's per-opportunity-detail computation. The
    recommender writes one row per qualifying candidate table at scan
    time; the new ``/recommendations/layout`` page reads the latest
    scan's rows for the active (project, region). The chip on
    ``/opportunities/{id}`` links here by ``table_full_name``.

    "Qualifying" means the underlying spec-148 ``build_recommendation``
    returned a non-None ``LayoutRecommendation`` for the table -
    i.e. the materiality + signal-strength gates fired.
    """

    __tablename__ = "layout_recommendations"

    id: Mapped[str] = mapped_column(String(80), primary_key=True)
    scan_run_id: Mapped[str] = mapped_column(
        String(80),
        ForeignKey("scan_runs.id", ondelete="CASCADE"),
        nullable=False,
    )
    config_id: Mapped[str] = mapped_column(String(36), nullable=False)
    table_full_name: Mapped[str] = mapped_column(String(1024), nullable=False)
    # The chosen partition column (NULL when no qualifying partition pick).
    recommended_partition_column: Mapped[str | None] = mapped_column(
        String(256), nullable=True
    )
    recommended_partition_type: Mapped[str | None] = mapped_column(
        String(32), nullable=True,
        doc="BigQuery column type - DATE/TIMESTAMP/DATETIME - for the partition pick",
    )
    # Cost-weighted score for the partition pick (0.0 when no pick).
    partition_score: Mapped[float] = mapped_column(Float, nullable=False, default=0.0)
    # Pre-rendered apply / rollback SQL the user copies into the BQ console.
    apply_sql: Mapped[str] = mapped_column(Text, nullable=False)
    rollback_sql: Mapped[str] = mapped_column(Text, nullable=False)
    # Caveat objects: list of {code: str, message: str}. See
    # ``governor_audit.layout.caveats`` for the enum.
    caveats: Mapped[list] = mapped_column(JSON, nullable=False, default=list)
    # Current state - pulled lazily on detail page for v1; binary signal here.
    table_is_currently_partitioned: Mapped[bool] = mapped_column(
        Boolean, nullable=False, default=False
    )
    # For ranking on the index page.
    table_total_bytes: Mapped[int] = mapped_column(BigInteger, nullable=False, default=0)
    table_total_cost_in_window_usd: Mapped[float] = mapped_column(
        Float, nullable=False, default=0.0,
        doc="Sum of total_cost on contributing jobs in the scan window",
    )
    # DEPRECATED (kept for SQLite schema compat - SQLite can't drop columns
    # without table rebuild, and existing local DBs would break). Never
    # written or read by current code. Remove on next compatibility break.
    estimated_annual_savings_usd_low: Mapped[float | None] = mapped_column(
        Float, nullable=True,
    )
    estimated_annual_savings_usd_high: Mapped[float | None] = mapped_column(
        Float, nullable=True,
    )
    contributing_job_count: Mapped[int] = mapped_column(
        Integer, nullable=False, default=0
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, default=_utcnow
    )

    candidates: Mapped[list["LayoutCandidateColumn"]] = relationship(
        "LayoutCandidateColumn",
        back_populates="recommendation",
        cascade="all, delete-orphan",
        order_by="LayoutCandidateColumn.cluster_rank.is_(None), LayoutCandidateColumn.cluster_rank, LayoutCandidateColumn.score.desc()",
    )

    __table_args__ = (
        UniqueConstraint(
            "scan_run_id", "config_id", "table_full_name",
            name="uq_layout_rec_scan_config_table",
        ),
    )

    @staticmethod
    def new_id() -> str:
        return _new_id("layoutrec")


class LayoutCandidateColumn(Base):
    """One row per (recommendation, column) - the ranked cluster /
    partition candidates that produced the parent recommendation.

    The top-1 partition pick is also reflected in
    ``LayoutRecommendation.recommended_partition_column`` for cheap
    index-page rendering; the top-4 cluster picks have
    ``cluster_rank`` 1–4 and the rest carry ``cluster_rank=NULL``
    (kept for transparency on the detail page).
    """

    __tablename__ = "layout_candidate_columns"

    id: Mapped[str] = mapped_column(String(80), primary_key=True)
    recommendation_id: Mapped[str] = mapped_column(
        String(80),
        ForeignKey("layout_recommendations.id", ondelete="CASCADE"),
        nullable=False,
    )
    column_name: Mapped[str] = mapped_column(String(256), nullable=False)
    # filter | range_filter | equi_join | group_by - kept as the
    # dominant usage type per (rec, column) so the UI can chip-tag it.
    usage_type: Mapped[str] = mapped_column(String(16), nullable=False)
    score: Mapped[float] = mapped_column(Float, nullable=False)
    cost_share: Mapped[float] = mapped_column(
        Float, nullable=False,
        doc="0.0–1.0 fraction of the table's total cost in window attributed to this column",
    )
    contributing_job_count: Mapped[int] = mapped_column(
        Integer, nullable=False, default=0
    )
    cluster_rank: Mapped[int | None] = mapped_column(
        Integer, nullable=True,
        doc="1–4 for the top cluster picks, NULL otherwise; partition pick is recorded on the parent row",
    )
    is_partition_pick: Mapped[bool] = mapped_column(
        Boolean, nullable=False, default=False
    )

    recommendation: Mapped["LayoutRecommendation"] = relationship(
        "LayoutRecommendation", back_populates="candidates"
    )

    __table_args__ = (
        UniqueConstraint(
            "recommendation_id", "column_name", "usage_type",
            name="uq_layout_candidate_rec_col_usage",
        ),
        CheckConstraint(
            "cluster_rank IS NULL OR (cluster_rank >= 1 AND cluster_rank <= 4)",
            name="ck_layout_candidate_cluster_rank_range",
        ),
        CheckConstraint(
            "usage_type IN ('filter', 'range_filter', 'equi_join', 'group_by')",
            name="ck_layout_candidate_usage_type",
        ),
    )

    @staticmethod
    def new_id() -> str:
        return _new_id("layoutcand")


class LayoutBqSecondOpinion(Base):
    """Spec 151 US2 - Google's BigQuery Recommender output for a table,
    surfaced alongside the audit's own recommendation when the caller
    has ``roles/recommender.bigqueryPartitionClusterViewer``.

    One row per ``LayoutRecommendation`` when the fetch succeeded;
    absent when the IAM grant is missing or the API errors. The
    detail page checks for absence and renders a banner explaining
    the grant.
    """

    __tablename__ = "layout_bq_second_opinions"

    id: Mapped[str] = mapped_column(String(80), primary_key=True)
    recommendation_id: Mapped[str] = mapped_column(
        String(80),
        ForeignKey("layout_recommendations.id", ondelete="CASCADE"),
        nullable=False,
        unique=True,
    )
    bq_recommendation_id: Mapped[str | None] = mapped_column(
        String(512), nullable=True,
        doc="Google's recommendation_id from INFORMATION_SCHEMA.RECOMMENDATIONS",
    )
    bq_recommendation_state: Mapped[str | None] = mapped_column(
        String(32), nullable=True,
        doc="ACTIVE / DISMISSED / SUCCEEDED / FAILED from Google's recommender",
    )
    bq_recommended_columns: Mapped[list] = mapped_column(
        JSON, nullable=False, default=list,
        doc="Google's pick - list of column names (typically 1 partition + N cluster)",
    )
    # DEPRECATED (kept for SQLite schema compat). Never written or read.
    bq_estimated_savings_usd: Mapped[float | None] = mapped_column(
        Float, nullable=True,
    )
    bq_description: Mapped[str | None] = mapped_column(
        Text, nullable=True,
        doc="Google's human-readable description of the change",
    )
    bq_insights: Mapped[list] = mapped_column(
        JSON, nullable=False, default=list,
        doc="Sibling rows from INFORMATION_SCHEMA.INSIGHTS for the same target_resource",
    )
    agrees_with_audit_top_pick: Mapped[bool] = mapped_column(
        Boolean, nullable=False,
        doc="True when Google's top column matches the audit's partition (or top cluster if no partition pick)",
    )
    # DEPRECATED (kept for SQLite schema compat). Never written or read.
    overestimation_warning: Mapped[bool] = mapped_column(
        Boolean, nullable=False, default=False,
    )
    last_refresh_time: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True,
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, default=_utcnow
    )

    recommendation: Mapped["LayoutRecommendation"] = relationship(
        "LayoutRecommendation",
        backref="bq_second_opinion",
    )

    @staticmethod
    def new_id() -> str:
        return _new_id("layoutbqop")


class LayoutDeepAnalysisResult(Base):
    """Spec 151 US3 - cached deep-analysis output per (recommendation, column).

    Written only after the user confirms the BigQuery dry-run cost
    estimate. Cached so subsequent clicks for the same column within
    the same scan render from cache without re-charging.
    """

    __tablename__ = "layout_deep_analysis_results"

    id: Mapped[str] = mapped_column(String(80), primary_key=True)
    recommendation_id: Mapped[str] = mapped_column(
        String(80),
        ForeignKey("layout_recommendations.id", ondelete="CASCADE"),
        nullable=False,
    )
    column_name: Mapped[str] = mapped_column(String(256), nullable=False)
    approx_distinct_count: Mapped[int] = mapped_column(BigInteger, nullable=False)
    top_values: Mapped[list] = mapped_column(
        JSON, nullable=False, default=list,
        doc="List of {value: any, count: int} dicts, capped at 20 rows",
    )
    dry_run_cost_usd: Mapped[float] = mapped_column(
        Float, nullable=False,
        doc="What the user saw + confirmed before the chargeable query ran",
    )
    actual_cost_usd: Mapped[float] = mapped_column(Float, nullable=False)
    executed_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, default=_utcnow,
    )

    recommendation: Mapped["LayoutRecommendation"] = relationship(
        "LayoutRecommendation",
        backref="deep_analysis_results",
    )

    __table_args__ = (
        UniqueConstraint(
            "recommendation_id", "column_name",
            name="uq_layout_deep_rec_col",
        ),
    )

    @staticmethod
    def new_id() -> str:
        return _new_id("layoutdeep")


Index(
    "ix_layout_rec_scan_config",
    LayoutRecommendation.scan_run_id,
    LayoutRecommendation.config_id,
)
Index(
    "ix_layout_rec_config_table",
    LayoutRecommendation.config_id,
    LayoutRecommendation.table_full_name,
)


__all__ = [
    "ScanRun",
    "AuditOpportunityMetadata",
    "LayoutRecommendation",
    "LayoutCandidateColumn",
    "LayoutBqSecondOpinion",
    "LayoutDeepAnalysisResult",
]
