"""Schema initialisation for the governor-audit SQLite cache.

governor-audit doesn't use Alembic - it has no Postgres deployment to
migrate, no concurrent writers, no rolling upgrades. The cache schema
is created from ``Base.metadata.create_all`` once on first scan.

This module exposes that as a standalone command so the
``make audit-migrate`` target lines up with the muscle memory of
``make migrate`` for the cloud package. Idempotent: running it on an
already-initialised cache is a no-op.

Usage::

    uv run --package governor-audit python -m governor_audit.db.migrate
"""

from __future__ import annotations

import sys

from governor_audit.db.session import build_engine, create_all, db_path


def main() -> int:
    target = db_path()
    print(f"Initialising SQLite cache at {target}")
    engine = build_engine()
    create_all(engine)
    print(f"Schema ready. (Re-running this command is a no-op.)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
