"""Cross-platform PID liveness probe.

POSIX uses ``os.kill(pid, 0)`` - signal 0 doesn't deliver anything,
just probes for the process. On Windows that path is broken: Python's
``os.kill`` is implemented via ``TerminateProcess`` and ``signal=0``
raises ``OSError [WinError 11]: An attempt was made to load a program
with an incorrect format`` (also seen as ``WinError 87`` in Python <
3.13). So we branch on platform.

The Windows branch uses kernel32's ``OpenProcess`` +
``GetExitCodeProcess`` via ctypes - no extra dependencies. Same
approach as ``governor_audit.cli.commands.start`` v0.3.5; this module
extracts that helper so ``scan.lock`` and any other PID-checker
share one battle-tested implementation.

Public surface: ``is_process_running(pid: int) -> bool``.
"""

from __future__ import annotations

import os


def is_process_running(pid: int) -> bool:
    """Return True if a process with this PID currently exists.

    Negative or zero PIDs return False (defensive - these aren't
    valid PIDs on any supported platform). Errors checking the
    process resolve to the safe direction:

    - POSIX: ``ProcessLookupError`` → False (process is gone),
      ``PermissionError`` → True (process exists but we can't signal,
      e.g. cross-user setuid).
    - Windows: ``OpenProcess`` returning NULL → False (gone or
      protected from us), all other ctypes errors caught and
      treated as False.
    """
    if pid <= 0:
        return False
    if os.name == "nt":
        return _windows_pid_alive(pid)
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    except OSError:
        # Any other OSError on POSIX (rare - bad PID, EINVAL, etc.).
        # Conservative: treat as alive so we don't accidentally clear
        # a lock held by something we just couldn't probe cleanly.
        return True
    return True


def _windows_pid_alive(pid: int) -> bool:
    """Windows-only PID liveness probe via kernel32 ctypes.

    ``OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, False, pid)``
    returns a handle when the process exists (even if we don't have
    permission to fully inspect it). ``GetExitCodeProcess`` then tells
    us whether it's still running (``STILL_ACTIVE`` = 259).
    """
    import ctypes
    from ctypes import wintypes

    PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
    STILL_ACTIVE = 259

    try:
        kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    except OSError:
        # Should never happen on a real Windows host, but be safe.
        return False

    kernel32.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
    kernel32.OpenProcess.restype = wintypes.HANDLE
    kernel32.GetExitCodeProcess.argtypes = [
        wintypes.HANDLE,
        ctypes.POINTER(wintypes.DWORD),
    ]
    kernel32.GetExitCodeProcess.restype = wintypes.BOOL
    kernel32.CloseHandle.argtypes = [wintypes.HANDLE]
    kernel32.CloseHandle.restype = wintypes.BOOL

    handle = kernel32.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, False, pid)
    if not handle:
        return False
    try:
        exit_code = wintypes.DWORD()
        if not kernel32.GetExitCodeProcess(handle, ctypes.byref(exit_code)):
            return False
        return exit_code.value == STILL_ACTIVE
    finally:
        kernel32.CloseHandle(handle)


__all__ = ["is_process_running"]
