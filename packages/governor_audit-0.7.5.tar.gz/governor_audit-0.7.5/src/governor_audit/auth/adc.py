"""gcloud Application Default Credentials probe.

Single read-only check that proves the user can read INFORMATION_SCHEMA
in the configured project + region. Returns a typed result so the
caller (init / doctor / scan) can render the right message.

This module never logs the credential bytes - only the principal email
(``client_email``-equivalent for service accounts; user email for ADC
sessions) and a sanitised version of any BigQuery error.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Any


class ProbeStatus(str, Enum):
    OK = "ok"
    ADC_MISSING = "adc_missing"  # No credentials at all (DefaultCredentialsError)
    ADC_INVALID = "adc_invalid"  # Credentials present but rejected (RefreshError)
    IAM_INSUFFICIENT = "iam_insufficient"  # 403 from BigQuery - needs role grant
    REGION_UNKNOWN = "region_unknown"  # 404 region/dataset not found
    UNKNOWN = "unknown"  # Some other Google API error - message included verbatim


@dataclass(frozen=True)
class ProbeResult:
    status: ProbeStatus
    principal: str | None  # Email of the active gcloud principal, when known.
    message: str  # Human-readable, safe to log/print. No credentials.

    @property
    def ok(self) -> bool:
        return self.status is ProbeStatus.OK


_REQUIRED_IAM_HINT = (
    "Required: roles/bigquery.resourceViewer + roles/bigquery.jobUser "
    "on the project (or a custom role granting bigquery.jobs.list and "
    "bigquery.tables.get on INFORMATION_SCHEMA.SCHEMATA)."
)

_GCLOUD_LOGIN_HINT = "Run: gcloud auth application-default login"


def _principal_email_from_credentials(creds: Any) -> str | None:
    """Try to extract a usable identity from the credentials object.
    Returns ``None`` if we can't (no exception - best-effort)."""
    return (
        getattr(creds, "service_account_email", None)
        or getattr(creds, "_service_account_email", None)
        or getattr(creds, "_target_principal", None)
        or getattr(creds, "_quota_project_id", None)
    )


def probe_adc(project_id: str, region: str) -> ProbeResult:
    """Run one read-only INFORMATION_SCHEMA query as a permission check.

    The query is intentionally minimal:

        SELECT 1 FROM `<project>.region-<region>`.INFORMATION_SCHEMA.SCHEMATA
        LIMIT 1

    It's billed as a metadata query (typically free or fractions of a
    cent). Any successful response means the user can read the project
    in the requested region.
    """
    # Imports are lazy so the module can be imported in environments
    # that don't have google-cloud-bigquery installed (e.g. running the
    # config schema tests in isolation).
    try:
        from google.api_core import exceptions as gcp_exc
        from google.auth import default as google_auth_default
        from google.auth.exceptions import (
            DefaultCredentialsError,
            RefreshError,
        )
        from google.cloud import bigquery
    except ImportError as exc:
        return ProbeResult(
            status=ProbeStatus.UNKNOWN,
            principal=None,
            message=f"google-cloud-bigquery not importable: {exc}",
        )

    # Step 1 - find ADC at all.
    try:
        credentials, _ = google_auth_default(
            scopes=["https://www.googleapis.com/auth/cloud-platform"],
        )
    except DefaultCredentialsError as exc:
        return ProbeResult(
            status=ProbeStatus.ADC_MISSING,
            principal=None,
            message=f"No Application Default Credentials found. {_GCLOUD_LOGIN_HINT}. ({exc})",
        )

    principal = _principal_email_from_credentials(credentials)

    # Step 2 - issue the probe query.
    try:
        client = bigquery.Client(project=project_id, credentials=credentials)
        query = (
            f"SELECT 1 FROM `{project_id}.region-{region}`.INFORMATION_SCHEMA.SCHEMATA "
            "LIMIT 1"
        )
        job = client.query(query)
        # Materialise to force the API call; we don't care about the rows.
        list(job.result(max_results=1))
    except RefreshError as exc:
        return ProbeResult(
            status=ProbeStatus.ADC_INVALID,
            principal=principal,
            message=(
                f"Credentials present but rejected by Google. "
                f"{_GCLOUD_LOGIN_HINT}. ({exc})"
            ),
        )
    except gcp_exc.Forbidden as exc:
        return ProbeResult(
            status=ProbeStatus.IAM_INSUFFICIENT,
            principal=principal,
            message=(
                f"Permission denied on project {project_id!r}. "
                f"{_REQUIRED_IAM_HINT} ({exc.reason or exc})"
            ),
        )
    except gcp_exc.NotFound as exc:
        return ProbeResult(
            status=ProbeStatus.REGION_UNKNOWN,
            principal=principal,
            message=(
                f"Region {region!r} or project {project_id!r} not found by "
                f"BigQuery. Check the region matches a real BigQuery location "
                f"(e.g. 'us', 'australia-southeast1'). ({exc})"
            ),
        )
    except gcp_exc.GoogleAPIError as exc:
        return ProbeResult(
            status=ProbeStatus.UNKNOWN,
            principal=principal,
            message=f"BigQuery API error during ADC probe: {exc}",
        )

    return ProbeResult(
        status=ProbeStatus.OK,
        principal=principal,
        message=(
            f"OK - authenticated{' as ' + principal if principal else ''}, "
            f"INFORMATION_SCHEMA reachable in {project_id}/{region}."
        ),
    )


__all__ = ["ProbeStatus", "ProbeResult", "probe_adc"]
