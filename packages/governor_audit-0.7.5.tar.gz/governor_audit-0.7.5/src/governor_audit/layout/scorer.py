"""Cost-weighted scoring on top of spec 148's per-table column-usage map.

Spec 148's ``lineage.column_usage.analyse_column_usage`` already gives
us per-(table, column) Counters of how many distinct consumer jobs
referenced the column in WHERE / JOIN / GROUP BY. That's a frequency
signal, not a cost signal - a column hit by 100 cheap queries and one
hit by 10 expensive queries get treated equivalently.

This module re-scores those columns by ``Σ(contributing_job.total_cost
× pruning_share)`` where ``pruning_share`` weights equality filters
higher than range filters higher than group-by-only references. The
output is the unit the persistence layer (``recommender.py``) writes
into ``LayoutCandidateColumn`` rows.

We deliberately do *not* replace the spec-148 frequency-based
abstention gates in ``lineage.recommendations.build_recommendation`` -
those gates (materiality threshold, min consumer jobs, partition
column-type validation) are still the right yes/no on "should this
table have a recommendation at all". Cost weighting only changes the
*ranking* of candidates inside a qualifying recommendation.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import TYPE_CHECKING, Iterable

if TYPE_CHECKING:
    from governor_audit.lineage.column_usage import TableColumnUsage
    from governor_core.sync.models import BigQueryJob

logger = logging.getLogger("governor_audit.layout.scorer")


# Pruning-share weights - how much of a query's cost a given column
# reference is "responsible for pruning" when the table gets that
# column as a partition or cluster key. These are heuristic; the
# methodology page documents them so users can reason about why a
# column ranked where it did.
_PRUNING_SHARE = {
    "filter": 1.0,        # equality filter / IN - full prune
    "range_filter": 0.7,  # BETWEEN / >= / < - partial prune
    "equi_join": 0.7,     # join key with filterable side - partial prune
    "group_by": 0.5,      # group-by only - clustering helps, not as much as filter
}


@dataclass(frozen=True)
class ScoredCandidate:
    """One ranked (column, usage_type) entry for the
    persistence layer to turn into a ``LayoutCandidateColumn`` row.
    """

    column_name: str
    usage_type: str            # one of _PRUNING_SHARE.keys()
    score: float               # Σ(job.total_cost × pruning_share)
    cost_share: float          # 0.0–1.0 fraction of the table's window cost
    contributing_job_count: int


def score_candidates(
    *,
    table_full_name: str,
    column_usage: "TableColumnUsage",
    jobs_for_table: Iterable["BigQueryJob"],
) -> list[ScoredCandidate]:
    """Re-score the per-table column-usage Counters by cost.

    ``column_usage`` comes from ``analyse_column_usage``; its
    Counters tell us *which* jobs (count) hit each column in each
    clause. ``jobs_for_table`` is every cached job that references
    this table - we re-walk it with the same usage classifier so
    we can attribute cost per (column, usage_type).

    The output is sorted by ``score`` descending so the caller can
    pick the partition column (top-1, filtered to DATE/TIMESTAMP/
    DATETIME by the existing spec-148 gate) and the cluster picks
    (top-4, excluding the partition column).

    Heuristic notes:
      - A column referenced in multiple clauses by the same job
        contributes once per clause (e.g. WHERE x = 1 GROUP BY x →
        x scores both as ``filter`` and ``group_by``). The
        downstream picker collapses by column when ranking.
      - Jobs missing ``total_cost`` (rare but real - failed jobs,
        cached entries from older audit versions) contribute zero
        cost; their frequency signal is already in
        ``column_usage`` via the spec-148 analyser.
    """
    # First pass - index jobs by query so we can correlate
    # column-usage hits per (column, clause) back to per-job cost.
    # We reuse the same AST extraction as spec 148 rather than
    # re-implementing column extraction - keeps the two views of
    # the workload consistent.
    from governor_audit.lineage.column_usage import (
        _build_alias_map,
        _resolve_column_table,
    )
    import sqlglot
    from sqlglot import exp as sqlglot_exp

    # Per-(column, usage_type) accumulators scoped to this table.
    score_by_key: dict[tuple[str, str], float] = {}
    cost_by_key: dict[tuple[str, str], float] = {}
    jobs_by_key: dict[tuple[str, str], set[str]] = {}
    total_table_cost = 0.0
    # Per-column running totals (across usage types) used for the
    # final dominant-usage choice - we want one (column, usage_type)
    # row to represent each candidate column, not one per clause.
    sum_score_by_column: dict[str, float] = {}
    dominant_usage_by_column: dict[str, str] = {}
    dominant_score_by_column: dict[str, float] = {}

    for job in jobs_for_table:
        cost = float(getattr(job, "total_cost", None) or 0)
        total_table_cost += cost
        sql = getattr(job, "query", None) or ""
        if not sql:
            continue
        try:
            tree = sqlglot.parse_one(sql, dialect="bigquery")
        except Exception:  # noqa: BLE001
            # Unparseable queries are dropped here (and were already
            # skipped upstream in spec 148's analyser). The skipped
            # count is bookkept by the orchestrator via the
            # recommender's overall job count vs. usage's
            # total_consumer_jobs.
            continue
        aliases = _build_alias_map(tree)
        if not aliases:
            continue

        # Walk WHERE → bucket by filter vs range_filter.
        for where in tree.find_all(sqlglot_exp.Where):
            for col in where.find_all(sqlglot_exp.Column):
                if _resolve_column_table(col, aliases) != table_full_name:
                    continue
                # range vs equality: look at the immediate parent
                # comparison operator. Falls back to ``filter`` for
                # anything we don't recognise (IN, EXISTS, etc.).
                parent = col.parent
                if isinstance(parent, (sqlglot_exp.GT, sqlglot_exp.GTE,
                                       sqlglot_exp.LT, sqlglot_exp.LTE,
                                       sqlglot_exp.Between)):
                    usage = "range_filter"
                else:
                    usage = "filter"
                _accumulate(
                    col.name, usage, cost,
                    job_id=getattr(job, "job_id", None),
                    score_by_key=score_by_key,
                    cost_by_key=cost_by_key,
                    jobs_by_key=jobs_by_key,
                )

        # Walk JOIN ON → equi_join (we treat all join-on column
        # refs uniformly; finer-grained classification of inequality
        # joins isn't worth the complexity for v1).
        for join in tree.find_all(sqlglot_exp.Join):
            on_expr = join.args.get("on")
            if on_expr is None:
                continue
            for col in on_expr.find_all(sqlglot_exp.Column):
                if _resolve_column_table(col, aliases) != table_full_name:
                    continue
                _accumulate(
                    col.name, "equi_join", cost,
                    job_id=getattr(job, "job_id", None),
                    score_by_key=score_by_key,
                    cost_by_key=cost_by_key,
                    jobs_by_key=jobs_by_key,
                )

        # Walk GROUP BY → group_by.
        for group in tree.find_all(sqlglot_exp.Group):
            for grouped in group.expressions:
                for col in grouped.find_all(sqlglot_exp.Column):
                    if _resolve_column_table(col, aliases) != table_full_name:
                        continue
                    _accumulate(
                        col.name, "group_by", cost,
                        job_id=getattr(job, "job_id", None),
                        score_by_key=score_by_key,
                        cost_by_key=cost_by_key,
                        jobs_by_key=jobs_by_key,
                    )

    # Collapse per-(column, usage_type) into one ScoredCandidate per
    # column, picking the highest-scoring usage_type as the
    # representative ("dominant"). We surface the dominant usage in
    # the UI chip; the underlying per-(column, usage_type) signal is
    # what ranking is computed against - summed across usage types
    # for the column-level ranking score.
    for (col, usage), score in score_by_key.items():
        sum_score_by_column[col] = sum_score_by_column.get(col, 0.0) + score
        if score > dominant_score_by_column.get(col, -1.0):
            dominant_score_by_column[col] = score
            dominant_usage_by_column[col] = usage

    candidates: list[ScoredCandidate] = []
    for col, total_score in sum_score_by_column.items():
        # Use the dominant usage type's cost / job count as the
        # representative figures - keeps the UI legible without
        # losing the underlying ranking math.
        usage = dominant_usage_by_column[col]
        key = (col, usage)
        candidates.append(ScoredCandidate(
            column_name=col,
            usage_type=usage,
            score=total_score,
            cost_share=(
                cost_by_key.get(key, 0.0) / total_table_cost
                if total_table_cost > 0
                else 0.0
            ),
            contributing_job_count=len(jobs_by_key.get(key, ())),
        ))

    candidates.sort(key=lambda c: c.score, reverse=True)
    if not candidates:
        logger.debug(
            "score_candidates: zero candidates for %s - column_usage had "
            "%d filter / %d join / %d groupby columns but cost re-walk "
            "produced no hits (likely all contributing jobs had cost=0)",
            table_full_name,
            len(column_usage.filter_columns),
            len(column_usage.join_columns),
            len(column_usage.groupby_columns),
        )
    return candidates


def _accumulate(
    column: str,
    usage_type: str,
    cost: float,
    *,
    job_id: str | None,
    score_by_key: dict[tuple[str, str], float],
    cost_by_key: dict[tuple[str, str], float],
    jobs_by_key: dict[tuple[str, str], set[str]],
) -> None:
    """In-place accumulator shared across the AST-walk branches above."""
    pruning_share = _PRUNING_SHARE.get(usage_type, 0.0)
    key = (column, usage_type)
    score_by_key[key] = score_by_key.get(key, 0.0) + cost * pruning_share
    cost_by_key[key] = cost_by_key.get(key, 0.0) + cost
    if job_id is not None:
        jobs_by_key.setdefault(key, set()).add(job_id)


__all__ = ["ScoredCandidate", "score_candidates"]
