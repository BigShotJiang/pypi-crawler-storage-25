"""Caveat detection for layout recommendations (FR-010).

Each caveat is a dict ``{"code": str, "message": str}`` written into
``LayoutRecommendation.caveats``. The UI renders them as a small
warning list under the apply SQL panel so the user can read the risk
profile before they paste anything into the BigQuery console.

Codes:
  - ``IAM_IMPACT``         - partition changes need create + delete on the dataset.
  - ``WRITE_HEAVY``        - many DML statements against the table in the window.
  - ``ALREADY_PARTITIONED`` - informational, when a recommendation changes
    an existing partition column instead of adding one.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable, TYPE_CHECKING

if TYPE_CHECKING:
    from governor_core.sync.models import BigQueryJob


# Threshold for ``WRITE_HEAVY`` - number of DML statements (INSERT,
# UPDATE, DELETE, MERGE) against the table in the scan window above
# which we flag the recommendation. Heuristic; documented on the
# methodology page so users can re-derive.
_WRITE_HEAVY_DML_COUNT_THRESHOLD = 50

# BigQuery's hard cap on partitions per table is 4000 (10000 for
# some configurations). The audit's apply SQL wraps TIMESTAMP /
# DATETIME columns in DATE() so they're day-bucketed, giving roughly
# 365 partitions per year of data. A column spanning > ~10 years
# (or carrying garbage backfill dates like 1900-01-01) busts the cap
# and the apply DDL fails. Surface ``PARTITION_CARDINALITY_RISK`` as
# a warning so the user runs deep-analysis on the partition column
# before applying.
_BQ_PARTITION_CAP = 4000


@dataclass(frozen=True)
class Caveat:
    code: str
    message: str

    def to_dict(self) -> dict[str, str]:
        return {"code": self.code, "message": self.message}


def detect_caveats(
    *,
    table_full_name: str,
    table_is_currently_partitioned: bool,
    recommended_partition_column: str | None,
    jobs_for_table: Iterable["BigQueryJob"],
) -> list[Caveat]:
    """Inspect the recommendation + workload and produce the caveat list.

    Designed to be cheap - single pass over jobs counting DML
    statement types; no extra DB / BQ queries.
    """
    caveats: list[Caveat] = []

    # IAM_IMPACT - always present when the apply path needs the
    # copy-and-rename pattern (i.e. there's a partition change).
    if recommended_partition_column is not None:
        caveats.append(Caveat(
            code="IAM_IMPACT",
            message=(
                "Applying this change uses the copy-and-rename pattern. "
                "It requires bigquery.tables.create and "
                "bigquery.tables.delete on the dataset, plus enough "
                "slot capacity to copy the full table. Plan for "
                "downtime equal to the copy duration unless you "
                "manage the swap behind a view."
            ),
        ))

    # PARTITION_CARDINALITY_RISK - BigQuery hard-caps partitions per
    # table at 4000. Day-bucketed DATE / TIMESTAMP / DATETIME columns
    # only blow this cap on > ~10 years of data or on garbage backfill
    # dates (e.g. 1900-01-01 markers). Scan-time has no real
    # cardinality data, so this is an advisory the user must validate
    # via the deep-analysis button. Audit-H9.
    if recommended_partition_column is not None:
        caveats.append(Caveat(
            code="PARTITION_CARDINALITY_RISK",
            message=(
                "BigQuery caps partitioned tables at "
                f"{_BQ_PARTITION_CAP} partitions (~10 years of daily "
                "values). If `"
                f"{recommended_partition_column}` spans a wider date "
                "range, contains garbage backfill markers (e.g. "
                "1900-01-01), or carries sub-day granularity that "
                "isn't day-bucketed here, the CREATE TABLE in apply "
                "Step 2 will fail with `Too many partitions`. Run the "
                "deep-analysis button on this column to check distinct-"
                "value count before applying."
            ),
        ))

    # ALREADY_PARTITIONED - informational distinction between
    # "adding partitioning" vs "changing an existing partition column".
    if table_is_currently_partitioned and recommended_partition_column is not None:
        caveats.append(Caveat(
            code="ALREADY_PARTITIONED",
            message=(
                "This table is already partitioned. The recommendation "
                "would change the partition column - make sure any "
                "downstream views or scheduled queries that filter on "
                "the current partition column are updated to filter on "
                "the new one, otherwise their scan cost will spike."
            ),
        ))

    # WRITE_HEAVY - count DML jobs against the destination_table.
    dml_count = sum(
        1
        for job in jobs_for_table
        if (
            getattr(job, "destination_table", None) == table_full_name
            and (getattr(job, "statement_type", None) or "").upper()
            in ("INSERT", "UPDATE", "DELETE", "MERGE", "TRUNCATE_TABLE")
        )
    )
    if dml_count > _WRITE_HEAVY_DML_COUNT_THRESHOLD:
        caveats.append(Caveat(
            code="WRITE_HEAVY",
            message=(
                f"{dml_count} DML statements ran against this table in "
                "the scan window. Changing the partition or cluster "
                "scheme adds ongoing write overhead - verify with the "
                "owning team before applying."
            ),
        ))

    return caveats


__all__ = [
    "Caveat",
    "detect_caveats",
]
