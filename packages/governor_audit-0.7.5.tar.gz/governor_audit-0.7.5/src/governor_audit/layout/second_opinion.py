"""Spec 151 US2 - fetch BigQuery's own partition/cluster recommender output.

Region-qualified query against
``region-{region}.INFORMATION_SCHEMA.RECOMMENDATIONS`` filtered to
``google.bigquery.table.PartitionClusterRecommender``, plus a sibling
fetch against ``.INSIGHTS`` keyed by the same ``target_resource``.

Soft-fail policy: any permission / region / API error returns an
empty mapping. The detail page's banner ("Add
``roles/recommender.bigqueryPartitionClusterViewer`` to surface
BigQuery's recommendation") is rendered when this returns nothing
for a given table - so a missing IAM grant is indistinguishable
from "BigQuery has no recommendation for this table" from the
user's perspective, which is fine: in both cases there's nothing
extra to show.

Cheap pass (FR-006 still applies): two metadata queries per region,
each billed at the 10 MB INFORMATION_SCHEMA minimum (~$0.00006).
Negligible against the JOBS_BY_PROJECT scan that already happened.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import TYPE_CHECKING, Iterable

if TYPE_CHECKING:
    from governor_audit.scan.information_schema import BigQueryClientProtocol


logger = logging.getLogger("governor_audit.layout.second_opinion")


@dataclass(frozen=True)
class BqSecondOpinion:
    """Google's recommendation for one ``project.dataset.table``,
    plus any sibling INSIGHTS rows. Returned per-target from
    ``fetch_for_region`` for the orchestrator to attach to the
    matching ``LayoutRecommendation`` row.
    """

    target_resource: str           # full resource id from Google
    table_full_name: str           # parsed ``project.dataset.table``
    recommendation_id: str | None
    state: str | None
    recommended_columns: list[str]
    description: str | None
    insights: list[dict]
    last_refresh_time: object | None


def fetch_for_region(
    *,
    bq_client: "BigQueryClientProtocol",
    project_id: str,
    region: str,
) -> dict[str, BqSecondOpinion]:
    """Return ``{table_full_name: BqSecondOpinion}`` for every
    PartitionClusterRecommender recommendation BigQuery returns in
    the given region.

    Returns an empty dict on any failure - caller MUST treat empty
    as "no second opinion available" rather than re-raising.
    """
    try:
        return _fetch_inner(
            bq_client=bq_client, project_id=project_id, region=region
        )
    except Exception:  # noqa: BLE001
        logger.info(
            "BigQuery Recommender fetch unavailable for project=%s region=%s "
            "(commonly: missing roles/recommender.bigqueryPartitionClusterViewer, "
            "unsupported region, or transient API error). Layout page renders "
            "without the second-opinion panel.",
            project_id,
            region,
        )
        return {}


def _fetch_inner(
    *,
    bq_client: "BigQueryClientProtocol",
    project_id: str,
    region: str,
) -> dict[str, BqSecondOpinion]:
    region_norm = (region or "us").strip().lower()
    # Defence in depth - region is config-derived but we still
    # ban anything that isn't lowercase-alphanumeric-hyphen so the
    # composed SQL can't be tampered with.
    import re

    if not re.fullmatch(r"[a-z0-9-]+", region_norm):
        raise ValueError(f"Invalid BigQuery region: {region!r}")
    if not re.fullmatch(r"[a-zA-Z0-9-]+", project_id):
        raise ValueError(f"Invalid project_id: {project_id!r}")

    recommendations_sql = (
        f"SELECT\n"
        f"  recommendation_id,\n"
        f"  target_resource,\n"
        f"  recommender_subtype,\n"
        f"  description,\n"
        f"  primary_impact,\n"
        f"  state,\n"
        f"  last_refresh_time,\n"
        f"  associated_insights\n"
        f"FROM `{project_id}.region-{region_norm}`.INFORMATION_SCHEMA.RECOMMENDATIONS\n"
        f"WHERE recommender = 'google.bigquery.table.PartitionClusterRecommender'\n"
        f"  AND state = 'ACTIVE'\n"
    )
    rec_rows = list(bq_client.query_rows(recommendations_sql, {}))
    if not rec_rows:
        return {}

    # Fetch sibling INSIGHTS in one query and Python-side join on
    # target_resource. Filtering to PartitionClusterRecommender's
    # paired insight type so we don't drag in unrelated cost / IAM
    # insights.
    insights_sql = (
        f"SELECT\n"
        f"  insight_id,\n"
        f"  target_resource,\n"
        f"  insight_subtype,\n"
        f"  description,\n"
        f"  category,\n"
        f"  severity,\n"
        f"  state,\n"
        f"  last_refresh_time\n"
        f"FROM `{project_id}.region-{region_norm}`.INFORMATION_SCHEMA.INSIGHTS\n"
        f"WHERE category = 'PERFORMANCE'\n"
    )
    try:
        insight_rows = list(bq_client.query_rows(insights_sql, {}))
    except Exception:  # noqa: BLE001
        # INSIGHTS view sometimes has tighter IAM than RECOMMENDATIONS.
        # We can still render the recommender output without it.
        logger.info(
            "INFORMATION_SCHEMA.INSIGHTS fetch failed for project=%s region=%s "
            "- surfacing recommendations without paired insights",
            project_id,
            region,
        )
        insight_rows = []

    insights_by_target: dict[str, list[dict]] = {}
    for row in insight_rows:
        target = row.get("target_resource") or ""
        if not target:
            continue
        insights_by_target.setdefault(target, []).append(row)

    result: dict[str, BqSecondOpinion] = {}
    for row in rec_rows:
        target = row.get("target_resource") or ""
        table_full_name = _target_resource_to_table(target)
        if not table_full_name:
            continue
        recommended_cols = _extract_recommendation_fields(row)
        result[table_full_name] = BqSecondOpinion(
            target_resource=target,
            table_full_name=table_full_name,
            recommendation_id=row.get("recommendation_id"),
            state=row.get("state"),
            recommended_columns=recommended_cols,
            description=row.get("description"),
            insights=insights_by_target.get(target, []),
            last_refresh_time=row.get("last_refresh_time"),
        )
    return result


def _target_resource_to_table(target_resource: str) -> str | None:
    """Parse Google's ``//bigquery.googleapis.com/projects/X/datasets/Y/tables/Z``
    target_resource into ``X.Y.Z``. Returns None on any unexpected shape
    so the caller skips the row rather than mis-attributing the
    recommendation to the wrong table."""
    if not target_resource:
        return None
    marker = "/projects/"
    idx = target_resource.find(marker)
    if idx == -1:
        return None
    tail = target_resource[idx + len(marker):]
    parts = tail.split("/")
    # Expected: [project, "datasets", dataset, "tables", table[, ...]]
    if len(parts) < 5 or parts[1] != "datasets" or parts[3] != "tables":
        return None
    return f"{parts[0]}.{parts[2]}.{parts[4]}"


def _extract_recommendation_fields(row: dict) -> list[str]:
    """Pull the recommended cluster/partition columns from Google's
    ``recommendation_details`` / ``primary_impact`` shape.

    The structure isn't perfectly stable across BQ versions, so we
    inspect a couple of likely paths and fall back to an empty list
    rather than raise.
    """
    recommended_cols: list[str] = []
    # Google nests the recommended columns inside
    # primary_impact.target_resource_attribution or recommendation_details.overview.
    # Try common shapes; cheap to look at all of them.
    primary_impact = row.get("primary_impact") or {}
    details = row.get("recommendation_details") or {}
    candidate_dicts = [primary_impact, details]
    for candidate in candidate_dicts:
        cols = _walk_for_columns(candidate)
        if cols:
            recommended_cols = cols
            break

    return recommended_cols


def _walk_for_columns(node: object) -> list[str]:
    """Best-effort walk through the recommendation payload for a
    ``columns`` list. Stops at the first hit."""
    if isinstance(node, dict):
        for key in ("partition_columns", "cluster_columns", "columns", "fields"):
            value = node.get(key)
            if isinstance(value, list) and value and all(isinstance(v, (str, dict)) for v in value):
                # Strings are taken verbatim; dicts must have a 'name' / 'column' key.
                out = []
                for v in value:
                    if isinstance(v, str):
                        out.append(v)
                    elif isinstance(v, dict):
                        for k in ("name", "column", "column_name"):
                            if k in v:
                                out.append(str(v[k]))
                                break
                if out:
                    return out
        for value in node.values():
            found = _walk_for_columns(value)
            if found:
                return found
    elif isinstance(node, list):
        for item in node:
            found = _walk_for_columns(item)
            if found:
                return found
    return []


def compute_agreement(
    *,
    audit_top_column: str | None,
    bq_columns: Iterable[str],
) -> bool:
    """Return True when BigQuery's top recommended column matches the
    audit's top pick. The audit's top pick is the partition column
    when present, else the top cluster pick (resolved by the caller
    before invocation)."""
    bq_list = list(bq_columns)
    if not audit_top_column or not bq_list:
        return False
    return bq_list[0] == audit_top_column


__all__ = [
    "BqSecondOpinion",
    "compute_agreement",
    "fetch_for_region",
]
