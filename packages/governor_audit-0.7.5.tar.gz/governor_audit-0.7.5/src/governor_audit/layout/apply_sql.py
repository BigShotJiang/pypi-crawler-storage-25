"""Generate the SQL the user copies + runs to apply / rollback a
layout recommendation.

BigQuery doesn't support in-place partition-scheme changes - adding
or changing the partition column on an existing table requires a
**copy-and-rename** pattern (Google docs:
https://cloud.google.com/bigquery/docs/managing-partitioned-tables).
We emit one fenced block per stage so the UI can render copy buttons
per stage:

    1. CREATE the new shadow table with the desired layout.
    2. INSERT the source rows.
    3. Swap names (drop original, rename shadow).

The rollback procedure reverses step 3 against the same shadow name
(intentionally requires the user to *not* have run anything else on
the renamed-back original). We surface this as a caveat (``IAM_IMPACT``)
because the apply requires ``bigquery.tables.create`` AND
``bigquery.tables.delete`` on the dataset.

For cluster-only changes (table is already partitioned, we just want
a different cluster set) we can use ``ALTER TABLE … SET OPTIONS`` -
but the column list change still requires a re-cluster (BQ does it
automatically on next write). We emit the simpler ALTER for this
path.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class ApplyArtifacts:
    apply_sql: str
    rollback_sql: str


def generate_apply_artifacts(
    *,
    table_full_name: str,
    table_is_currently_partitioned: bool,
    recommended_partition_column: str | None,
    recommended_partition_type: str | None,
    recommended_cluster_columns: list[str],
) -> ApplyArtifacts:
    """Return ``(apply_sql, rollback_sql)`` for the requested change.

    Decision tree:
      - Partition column change OR adding partitioning to an
        unpartitioned table → copy-and-rename pattern.
      - Cluster-only change on an already-partitioned table →
        ``ALTER TABLE … SET OPTIONS(clustering_fields=...)``.
      - No partition pick AND no cluster picks → no SQL (caller
        shouldn't have invoked us).
    """
    parts = _split_table_identifier(table_full_name)
    shadow_full = f"{parts['project']}.{parts['dataset']}.{parts['table']}__governor_layout_v1"

    cluster_clause = (
        f"CLUSTER BY {', '.join(_quote_ident(c) for c in recommended_cluster_columns)}"
        if recommended_cluster_columns else ""
    )

    if recommended_partition_column is None:
        if not recommended_cluster_columns:
            return ApplyArtifacts(apply_sql="", rollback_sql="")
        # Cluster-only path. BQ ALTER TABLE supports a clustering
        # change on an already-clustered or unclustered table; the
        # re-cluster happens lazily on next write.
        apply_sql = (
            f"-- Apply: set / replace clustering columns on `{table_full_name}`.\n"
            f"-- This is a metadata-only change; BigQuery re-clusters on next write.\n"
            f"ALTER TABLE `{table_full_name}`\n"
            f"  SET OPTIONS (\n"
            f"    clustering_fields = {_render_string_array(recommended_cluster_columns)}\n"
            f"  );\n"
        )
        rollback_sql = (
            f"-- Rollback: remove the clustering option.\n"
            f"-- (Or replace with the original cluster set you noted before applying.)\n"
            f"ALTER TABLE `{table_full_name}`\n"
            f"  SET OPTIONS (clustering_fields = NULL);\n"
        )
        return ApplyArtifacts(apply_sql=apply_sql, rollback_sql=rollback_sql)

    # Partition change (covers both "add partitioning" and
    # "change existing partition column"). Copy-and-rename.
    partition_type = (recommended_partition_type or "DATE").upper()
    partition_expr = (
        recommended_partition_column
        if partition_type in ("DATE",)
        else f"DATE({_quote_ident(recommended_partition_column)})"
    )
    if partition_type == "DATE":
        partition_clause = f"PARTITION BY {_quote_ident(recommended_partition_column)}"
    elif partition_type in ("TIMESTAMP", "DATETIME"):
        partition_clause = (
            f"PARTITION BY DATE({_quote_ident(recommended_partition_column)})"
        )
    else:
        # INT64 / range partition - unsupported in v1; fall back to
        # DATE() which will fail at apply time. We document this in
        # the comment so the user knows.
        partition_clause = (
            f"PARTITION BY {_quote_ident(recommended_partition_column)}\n"
            f"  -- NOTE: range-partitioned INT64 columns require RANGE_BUCKET;"
            f" this template does not generate the full RANGE clause."
        )

    snapshot_full = (
        f"{parts['project']}.{parts['dataset']}."
        f"{parts['table']}__governor_layout_v0_snapshot"
    )
    parked_full = (
        f"{parts['project']}.{parts['dataset']}."
        f"{parts['table']}__governor_layout_v1_rollback"
    )

    apply_sql = (
        f"-- =============================================================\n"
        f"-- Apply layout change to `{table_full_name}`\n"
        f"-- Pattern: snapshot → copy → swap. BigQuery doesn't support\n"
        f"-- in-place partition-scheme changes. Run each step sequentially.\n"
        f"-- The snapshot in Step 1 makes rollback deterministic (no\n"
        f"-- reliance on time-travel windows or historical name resolution).\n"
        f"-- =============================================================\n"
        f"\n"
        f"-- Step 1: snapshot the original at the current moment so\n"
        f"-- rollback can CLONE it back. Snapshots are metadata-only at\n"
        f"-- creation and only incur storage cost for divergent data.\n"
        f"-- Expires in 7 days; extend with ALTER SNAPSHOT TABLE if you\n"
        f"-- need a longer rollback window.\n"
        f"CREATE SNAPSHOT TABLE `{snapshot_full}`\n"
        f"  CLONE `{table_full_name}`\n"
        f"  OPTIONS (\n"
        f"    expiration_timestamp = TIMESTAMP_ADD(\n"
        f"      CURRENT_TIMESTAMP(), INTERVAL 7 DAY\n"
        f"    )\n"
        f"  );\n"
        f"\n"
        f"-- Step 2: create the shadow table with the new layout.\n"
        f"CREATE TABLE `{shadow_full}`\n"
        f"  {partition_clause}\n"
        f"  {cluster_clause}\n"
        f"AS SELECT * FROM `{table_full_name}`;\n"
        f"\n"
        f"-- Step 3: verify row counts match before swapping.\n"
        f"SELECT\n"
        f"  (SELECT COUNT(*) FROM `{table_full_name}`) AS source_rows,\n"
        f"  (SELECT COUNT(*) FROM `{shadow_full}`) AS shadow_rows;\n"
        f"\n"
        f"-- Step 4: swap names. ONLY run after Step 3 confirms match.\n"
        f"DROP TABLE `{table_full_name}`;\n"
        f"ALTER TABLE `{shadow_full}` RENAME TO `{parts['table']}`;\n"
    )

    rollback_sql = (
        f"-- =============================================================\n"
        f"-- Rollback procedure for `{table_full_name}`\n"
        f"-- Restores from the snapshot created by apply Step 1. Works\n"
        f"-- for as long as the snapshot exists (default 7 days).\n"
        f"-- =============================================================\n"
        f"\n"
        f"-- Step 1: move the new-layout table aside so the original name\n"
        f"-- is free. Kept (not dropped) until you've validated Step 2.\n"
        f"ALTER TABLE `{table_full_name}`\n"
        f"  RENAME TO `{parts['table']}__governor_layout_v1_rollback`;\n"
        f"\n"
        f"-- Step 2: clone the snapshot back into the original name.\n"
        f"-- CLONE is a metadata-only operation - completes in seconds\n"
        f"-- regardless of table size.\n"
        f"CREATE TABLE `{table_full_name}`\n"
        f"  CLONE `{snapshot_full}`;\n"
        f"\n"
        f"-- Step 3: once Step 2 is verified, drop the parked new-layout\n"
        f"-- table and the snapshot. Commented out so you opt in.\n"
        f"-- DROP TABLE `{parked_full}`;\n"
        f"-- DROP SNAPSHOT TABLE `{snapshot_full}`;\n"
    )
    return ApplyArtifacts(apply_sql=apply_sql, rollback_sql=rollback_sql)


def _split_table_identifier(table_full_name: str) -> dict[str, str]:
    parts = table_full_name.split(".")
    if len(parts) != 3:
        raise ValueError(
            f"Expected project.dataset.table, got {table_full_name!r}"
        )
    return {"project": parts[0], "dataset": parts[1], "table": parts[2]}


def _quote_ident(ident: str) -> str:
    """Backtick-quote a BigQuery identifier. We don't accept arbitrary
    user input here - column names come from sqlglot-parsed AST so
    they're already valid identifiers - but defend against the
    obvious."""
    if "`" in ident:
        raise ValueError(f"Invalid identifier (contains backtick): {ident!r}")
    return f"`{ident}`"


def _render_string_array(items: list[str]) -> str:
    quoted = ", ".join(f'"{i}"' for i in items if '"' not in i)
    return f"[{quoted}]"


__all__ = ["ApplyArtifacts", "generate_apply_artifacts"]
