"""Spec 151 US3 - deep analysis on a candidate column.

Two-phase API:

  1. ``preview(bq_client, table, column)`` runs BigQuery dry-runs for
     ``APPROX_COUNT_DISTINCT(col)`` and ``APPROX_TOP_COUNT(col, 20)``,
     returns a USD estimate the route renders in the confirm dialog.
     **No chargeable query is run.**
  2. ``run(bq_client, recommendation, column, acknowledged_cost_usd)``
     re-validates the dry-run cost hasn't drifted upward (defence
     against stale forms), executes the two chargeable queries, and
     writes a ``LayoutDeepAnalysisResult`` row.

FR-007: the user must confirm-after-cost-shown before any
chargeable run; the cached result on the same (recommendation,
column) short-circuits re-runs so the user is never charged twice
for the same analysis within a scan.

Cost computation uses the same on-demand pricing constant as
``scan/information_schema.estimated_cost_usd`` so the figure shown
matches what the rest of the audit reports.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from sqlalchemy.orm import Session

    from governor_audit.db.models import (
        LayoutCandidateColumn,
        LayoutRecommendation,
    )
    from governor_audit.scan.information_schema import BigQueryClientProtocol


logger = logging.getLogger("governor_audit.layout.deep_analysis")


# Above this drift fraction (post-confirm dry-run cost vs ack'd cost),
# the run step refuses to execute and asks the user to re-confirm.
# Heuristic; mirrors the "ack the price, don't surprise the user"
# principle of the consent gate.
_COST_DRIFT_TOLERANCE = 0.25


class DeepAnalysisError(Exception):
    """Raised when the deep-analysis flow refuses to run.

    Subclassed for the two distinct cases - bad column (4xx from the
    route's perspective) vs. cost drift (also 4xx but with a
    different user-facing message)."""


class UnknownColumnError(DeepAnalysisError):
    """The requested column isn't in the recommendation's candidate
    set. Route returns 400; user should pick a column the audit
    actually surfaced as a candidate."""


class CostDriftError(DeepAnalysisError):
    """The post-confirm dry-run cost is materially higher than what
    the user ack'd. Route returns 400 with a "re-confirm" message."""


@dataclass(frozen=True)
class DryRunPreview:
    column_name: str
    table_full_name: str
    distinct_count_sql: str
    top_values_sql: str
    estimated_cost_usd: float
    estimated_bytes_processed: int


@dataclass(frozen=True)
class DeepAnalysisOutcome:
    """What the run step produced - used by the route to render or
    decide cached-vs-fresh."""

    column_name: str
    approx_distinct_count: int
    top_values: list[dict]
    actual_cost_usd: float
    from_cache: bool


def _validate_column(
    *,
    recommendation: "LayoutRecommendation",
    column_name: str,
) -> "LayoutCandidateColumn":
    for candidate in recommendation.candidates:
        if candidate.column_name == column_name:
            return candidate
    raise UnknownColumnError(
        f"Column {column_name!r} is not in the candidate set for "
        f"{recommendation.table_full_name}. Refresh the page if the "
        "scan ran in the background."
    )


def _build_queries(table: str, column: str) -> tuple[str, str]:
    """Both queries quote the identifiers - defence against rogue
    column names that somehow slipped past the candidate check."""
    if "`" in column or "`" in table:
        raise UnknownColumnError(
            "Identifier contains a backtick; refusing to compose SQL"
        )
    distinct_sql = (
        f"SELECT APPROX_COUNT_DISTINCT(`{column}`) AS distinct_count "
        f"FROM `{table}`"
    )
    top_values_sql = (
        f"SELECT `{column}` AS value, COUNT(*) AS cnt "
        f"FROM `{table}` "
        f"WHERE `{column}` IS NOT NULL "
        f"GROUP BY `{column}` "
        f"ORDER BY cnt DESC "
        f"LIMIT 20"
    )
    return distinct_sql, top_values_sql


def preview(
    *,
    bq_client: "BigQueryClientProtocol",
    recommendation: "LayoutRecommendation",
    column_name: str,
) -> DryRunPreview:
    """Compute the deep-analysis cost without running anything
    chargeable. The route renders this in the confirm dialog."""
    _validate_column(recommendation=recommendation, column_name=column_name)
    distinct_sql, top_values_sql = _build_queries(
        recommendation.table_full_name, column_name
    )

    distinct_estimate = bq_client.dry_run(distinct_sql, {})
    top_estimate = bq_client.dry_run(top_values_sql, {})
    total_bytes = (
        distinct_estimate.bytes_billed + top_estimate.bytes_billed
    )
    total_cost = distinct_estimate.cost_usd + top_estimate.cost_usd
    return DryRunPreview(
        column_name=column_name,
        table_full_name=recommendation.table_full_name,
        distinct_count_sql=distinct_sql,
        top_values_sql=top_values_sql,
        estimated_cost_usd=total_cost,
        estimated_bytes_processed=total_bytes,
    )


def run(
    *,
    session: "Session",
    bq_client: "BigQueryClientProtocol",
    recommendation: "LayoutRecommendation",
    column_name: str,
    acknowledged_cost_usd: float,
) -> DeepAnalysisOutcome:
    """Execute the chargeable deep-analysis queries after the user
    confirmed the dry-run cost. Cached results short-circuit the BQ
    call so the same (recommendation, column) is never charged twice."""
    from governor_audit.db.models import LayoutDeepAnalysisResult

    _validate_column(recommendation=recommendation, column_name=column_name)

    # Cache hit - return the prior result without running anything.
    cached = (
        session.query(LayoutDeepAnalysisResult)
        .filter(
            LayoutDeepAnalysisResult.recommendation_id == recommendation.id,
            LayoutDeepAnalysisResult.column_name == column_name,
        )
        .first()
    )
    if cached is not None:
        logger.info(
            "deep_analysis cache hit for recommendation_id=%s column=%s - "
            "returning cached result without re-running BQ",
            recommendation.id,
            column_name,
        )
        return DeepAnalysisOutcome(
            column_name=cached.column_name,
            approx_distinct_count=cached.approx_distinct_count,
            top_values=list(cached.top_values or []),
            actual_cost_usd=cached.actual_cost_usd,
            from_cache=True,
        )

    # Cost drift check - re-dry-run, compare to user's ack'd figure.
    distinct_sql, top_values_sql = _build_queries(
        recommendation.table_full_name, column_name
    )
    re_dry_distinct = bq_client.dry_run(distinct_sql, {})
    re_dry_top = bq_client.dry_run(top_values_sql, {})
    fresh_cost = re_dry_distinct.cost_usd + re_dry_top.cost_usd
    if (
        fresh_cost > acknowledged_cost_usd
        and (
            (fresh_cost - acknowledged_cost_usd)
            / max(acknowledged_cost_usd, 1e-9)
        ) > _COST_DRIFT_TOLERANCE
    ):
        raise CostDriftError(
            f"Estimated cost moved from ${acknowledged_cost_usd:.4f} to "
            f"${fresh_cost:.4f} (> {int(_COST_DRIFT_TOLERANCE * 100)}% drift). "
            "Please re-confirm the new estimate before running."
        )

    # Execute the chargeable queries.
    distinct_rows = list(bq_client.query_rows(distinct_sql, {}))
    top_rows = list(bq_client.query_rows(top_values_sql, {}))

    approx_distinct = 0
    if distinct_rows:
        first = distinct_rows[0]
        approx_distinct = int(first.get("distinct_count") or 0)

    top_values = []
    for row in top_rows[:20]:
        value = row.get("value")
        count = row.get("cnt")
        top_values.append({
            "value": value if isinstance(value, (str, int, float, bool)) else str(value),
            "count": int(count or 0),
        })

    actual_cost = fresh_cost  # we have no better signal than the dry-run
    result = LayoutDeepAnalysisResult(
        id=LayoutDeepAnalysisResult.new_id(),
        recommendation_id=recommendation.id,
        column_name=column_name,
        approx_distinct_count=approx_distinct,
        top_values=top_values,
        dry_run_cost_usd=acknowledged_cost_usd,
        actual_cost_usd=actual_cost,
    )
    session.add(result)
    session.flush()

    return DeepAnalysisOutcome(
        column_name=column_name,
        approx_distinct_count=approx_distinct,
        top_values=top_values,
        actual_cost_usd=actual_cost,
        from_cache=False,
    )


__all__ = [
    "CostDriftError",
    "DeepAnalysisError",
    "DeepAnalysisOutcome",
    "DryRunPreview",
    "UnknownColumnError",
    "preview",
    "run",
]
