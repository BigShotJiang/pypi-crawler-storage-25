"""Spec 151 - table-level partition & cluster recommender.

Lifts the existing spec-148 lineage analyser (which already extracts
per-table column usage via sqlglot and returns up to 4 cluster
candidates) into a **persisted, cost-weighted** recommendation surface
backed by a dedicated ``/recommendations/layout`` page. Replaces the
per-opportunity layout card on ``/opportunities/{id}`` with a chip
linking to the new page.

Why this is "spec 151" and not "spec 148 v2": the analysis was already
table-level under the hood, but it was *rendered* per-opportunity -
which produced the user-visible misframe of "different queries on the
same table getting different advice". Persisting one recommendation
per table + surfacing them on a dedicated index page fixes the framing
without throwing away the AST walker that spec 148 got right.
"""
