"""Orchestrator - run after the scan persists jobs.

For each table the spec-148 lineage analyser identifies as having
enough consumer signal AND that passes the materiality gate
(``DEFAULT_MATERIALITY_BYTES`` from spec 148), this module:

  1. Re-scores the candidate columns by cost weight (``scorer``).
  2. Picks the top-1 partition column (DATE/TIMESTAMP/DATETIME
     gated by the existing spec-148 ``build_recommendation``) and
     the top-4 cluster columns.
  3. Generates apply / rollback SQL (``apply_sql``).
  4. Detects caveats (``caveats``).
  5. Persists one ``LayoutRecommendation`` row + N
     ``LayoutCandidateColumn`` rows for this scan.

Audit does NOT estimate or expose savings figures - the prior
``window_cost × 365 / window_days × Σ cost_share × {0.30, 0.60}``
band was unreliable (365× amplification on short windows) and has
been removed. Users validate impact via the deep-analysis button on
each recommendation.

Cheap pass: zero extra BigQuery queries. Operates entirely on the
already-cached ``BigQueryJob``, ``TableColumnMetadata``, and
``TableStorageMetric`` rows. Soft failure - any exception here is
logged and the scan continues without recommendations rather than
failing the scan.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from governor_audit.db.models import (
    LayoutBqSecondOpinion,
    LayoutCandidateColumn,
    LayoutRecommendation,
)

if TYPE_CHECKING:
    from sqlalchemy.orm import Session

    from governor_audit.scan.information_schema import BigQueryClientProtocol


logger = logging.getLogger("governor_audit.layout.recommender")


# Spec 148's materiality gate is 1 GB; spec 151 talks about a 10 GB
# cluster threshold. The cluster threshold is the more permissive
# of the two for the table-level recommendation surface (everything
# above 10 GB is shown; everything above 100 GB also surfaces a
# partition pick if signal allows). We keep the spec-148 default
# import for now and impose the 10 GB display gate in the index
# template - that way the existing per-opportunity lineage path
# remains backward-compatible.
#
# Production gates: BigQuery's own recommender uses 10 GB for
# clustering and 100 GB for partitioning. Below those thresholds the
# per-partition / per-cluster-block metadata overhead outweighs the
# pruning benefit on most workloads.
CLUSTER_MIN_SIZE_BYTES = 10 * 2**30
PARTITION_MIN_SIZE_BYTES = 100 * 2**30


def run(
    *,
    session: "Session",
    scan_run_id: str,
    config_id: str,
    bq_client: "BigQueryClientProtocol | None" = None,
    project_id: str | None = None,
    region: str | None = None,
) -> int:
    """Build + persist layout recommendations for the just-completed scan.

    When ``bq_client`` + ``project_id`` + ``region`` are provided, US2's
    BigQuery-second-opinion fetch runs after persistence. Missing any
    of those skips the fetch silently - the cheap pass still ships.

    Returns the count of recommendation rows written.
    """
    try:
        return _run_inner(
            session=session,
            scan_run_id=scan_run_id,
            config_id=config_id,
            bq_client=bq_client,
            project_id=project_id,
            region=region,
        )
    except Exception:  # noqa: BLE001
        logger.exception(
            "layout recommender failed for scan_run_id=%s config_id=%s - "
            "scan continues without table-level recommendations",
            scan_run_id,
            config_id,
        )
        return 0


def _run_inner(
    *,
    session: "Session",
    scan_run_id: str,
    config_id: str,
    bq_client: "BigQueryClientProtocol | None" = None,
    project_id: str | None = None,
    region: str | None = None,
) -> int:
    from governor_audit.layout.apply_sql import generate_apply_artifacts
    from governor_audit.layout.caveats import detect_caveats
    from governor_audit.layout.scorer import score_candidates
    from governor_audit.lineage.column_usage import analyse_column_usage
    from governor_audit.lineage.recommendations import (
        DEFAULT_CLUSTER_THRESHOLD,
        DEFAULT_MIN_CONSUMER_JOBS,
        DEFAULT_PARTITION_THRESHOLD,
        MAX_CLUSTER_COLUMNS,
        PARTITION_KEY_TYPES,
    )
    from governor_core.sync.models import (
        BigQueryJob,
        TableColumnMetadata,
        TableStorageMetric,
    )

    # 1. Wipe prior recommendations for this scan_run_id. The scan
    #    orchestrator already wiped scan-data for the config; we make
    #    the recommender re-runnable on a single scan by also wiping
    #    here in case it was invoked twice (rare; helps tests).
    session.query(LayoutRecommendation).filter(
        LayoutRecommendation.scan_run_id == scan_run_id
    ).delete(synchronize_session=False)
    session.flush()

    # 2. Load every cached job for the config that touches some
    #    table. ``referenced_tables`` is JSON-typed; SQLite's storage
    #    is opaque to SQL filtering, so we Python-side filter after
    #    the query.
    all_jobs = (
        session.query(BigQueryJob)
        .filter(BigQueryJob.config_id == config_id)
        .all()
    )

    # Phase-2 latest-version filter: consumers only count when they
    # are running the LATEST deployed version of their own destination
    # query (or are consumption-style with no destination). A model
    # that USED to scan ``proj.ds.events`` on every column unfiltered,
    # but has since been refactored to filter by ``event_date``, must
    # not still pull the dashboard toward partitioning by something
    # else - its prior version's column-usage no longer reflects
    # current load. Matches the unit-of-analysis the dashboard /
    # /opportunities now use (see findings._latest_version_cohort_job_ids).
    from governor_audit.web.routes.findings import (
        _latest_version_cohort_job_ids,
    )

    latest_cohort = _latest_version_cohort_job_ids(all_jobs)
    consumer_jobs = [
        j
        for j in all_jobs
        if (j.referenced_tables or []) and j.job_id in latest_cohort
    ]
    if not consumer_jobs:
        logger.info(
            "layout recommender: no consumer jobs cached for config_id=%s - "
            "skipping (likely first scan or empty workload)",
            config_id,
        )
        return 0

    # 3. Run the spec-148 analyser to get per-table column-usage.
    #    This is the partition / cluster candidate-table discovery
    #    step and reuses the existing AST walker.
    usage_by_table = analyse_column_usage(consumer_jobs)
    if not usage_by_table:
        logger.info(
            "layout recommender: column-usage analysis produced no "
            "qualifying tables for config_id=%s",
            config_id,
        )
        return 0

    # 4. Pre-resolve jobs per table for the cost re-walk. Same
    #    referenced_tables normalization as the opportunities
    #    route uses (handles both string and dict shapes).
    jobs_by_table: dict[str, list] = {}
    for job in consumer_jobs:
        seen: set[str] = set()
        for ref in (job.referenced_tables or []):
            fq = _ref_to_fq(ref)
            if fq is None or fq in seen:
                continue
            seen.add(fq)
            jobs_by_table.setdefault(fq, []).append(job)

    # 5. Pre-load schema + storage rows for ALL tables in scope
    #    (we'll re-key in Python). Spec-148 build_recommendation
    #    needs both per-table.
    schema_rows = (
        session.query(TableColumnMetadata)
        .filter(TableColumnMetadata.config_id == config_id)
        .all()
    )
    schema_by_table: dict[str, list] = {}
    for row in schema_rows:
        key = f"{row.project_id}.{row.dataset_name}.{row.table_name}"
        schema_by_table.setdefault(key, []).append(row)
    storage_rows = (
        session.query(TableStorageMetric)
        .filter(TableStorageMetric.config_id == config_id)
        .all()
    )
    storage_by_table: dict[str, TableStorageMetric] = {
        f"{row.project_id}.{row.dataset_name}.{row.table_name}": row
        for row in storage_rows
    }

    persisted = 0
    for table_full_name, usage in usage_by_table.items():
        try:
            schema = schema_by_table.get(table_full_name, [])
            storage = storage_by_table.get(table_full_name)

            # 5a. Apply the spec-148 yes/no gates (materiality,
            #     min consumer jobs, etc.) by calling the existing
            #     build_recommendation. We use its abstention as our
            #     "should we surface this table at all" gate, then
            #     refine the *ranking* with our cost-weighted scorer.
            schema_by_col = {row.column_name: row.data_type for row in schema}
            total_bytes = int(getattr(storage, "total_logical_bytes", 0) or 0)
            total_partitions = int(getattr(storage, "total_partitions", 0) or 0)
            is_partitioned = total_partitions > 1

            # Cluster recommendations apply above CLUSTER_MIN_SIZE_BYTES.
            # The page filters smaller tables out of the index - we
            # also gate persistence so we don't accumulate noise.
            if total_bytes < CLUSTER_MIN_SIZE_BYTES:
                continue
            if usage.total_consumer_jobs < DEFAULT_MIN_CONSUMER_JOBS:
                continue

            jobs_for_table = jobs_by_table.get(table_full_name, [])
            scored = score_candidates(
                table_full_name=table_full_name,
                column_usage=usage,
                jobs_for_table=jobs_for_table,
            )
            if not scored:
                continue

            # Pick partition + cluster columns from the scored list
            # using the same type / threshold rules spec 148 uses,
            # but with cost-weighted ranking.
            partition_pick = None
            partition_type = None
            partition_score = 0.0
            # Partition pick - only if table is big enough AND not
            # already partitioned. Pick highest-scoring column
            # whose schema type is DATE/TIMESTAMP/DATETIME AND
            # whose underlying frequency clears the spec-148
            # partition threshold (defence against high-cost
            # outliers driving false positives).
            if (
                not is_partitioned
                and total_bytes >= PARTITION_MIN_SIZE_BYTES
                and usage.total_consumer_jobs > 0
            ):
                for sc in scored:
                    col_type = (schema_by_col.get(sc.column_name) or "").upper()
                    if col_type not in PARTITION_KEY_TYPES:
                        continue
                    freq = (
                        usage.filter_columns.get(sc.column_name, 0)
                        / usage.total_consumer_jobs
                    )
                    if freq < DEFAULT_PARTITION_THRESHOLD:
                        continue
                    partition_pick = sc.column_name
                    partition_type = col_type
                    partition_score = sc.score
                    break

            # Cluster picks - top-N excluding the partition column.
            # Use frequency floor from spec 148 to avoid noise.
            cluster_columns: list[str] = []
            cluster_lookup: dict[str, int] = {}
            total_jobs = usage.total_consumer_jobs
            for sc in scored:
                if sc.column_name == partition_pick:
                    continue
                if sc.column_name not in schema_by_col:
                    # Column dropped / renamed - don't recommend
                    # something the user can't actually CLUSTER BY.
                    continue
                combined = (
                    usage.filter_columns.get(sc.column_name, 0)
                    + usage.join_columns.get(sc.column_name, 0)
                )
                freq = min(combined, total_jobs) / total_jobs
                if freq < DEFAULT_CLUSTER_THRESHOLD:
                    continue
                cluster_lookup[sc.column_name] = len(cluster_columns) + 1
                cluster_columns.append(sc.column_name)
                if len(cluster_columns) >= MAX_CLUSTER_COLUMNS:
                    break

            if partition_pick is None and not cluster_columns:
                continue  # nothing to recommend

            # 5b. SQL + caveats.
            artifacts = generate_apply_artifacts(
                table_full_name=table_full_name,
                table_is_currently_partitioned=is_partitioned,
                recommended_partition_column=partition_pick,
                recommended_partition_type=partition_type,
                recommended_cluster_columns=cluster_columns,
            )
            caveats = [
                c.to_dict()
                for c in detect_caveats(
                    table_full_name=table_full_name,
                    table_is_currently_partitioned=is_partitioned,
                    recommended_partition_column=partition_pick,
                    jobs_for_table=jobs_for_table,
                )
            ]

            table_total_cost = sum(
                float(getattr(j, "total_cost", None) or 0)
                for j in jobs_for_table
            )

            # Audit-H17: normalise scores to [0, 1] before persistence.
            # The raw score is ``Σ(job.total_cost × pruning_share)`` in
            # USD, which made a $10k table's columns always rank above
            # a $100 table's regardless of fit quality. Dividing by
            # ``table_total_cost`` yields "fraction of this table's
            # cost that flows through this column" - comparable across
            # tables and bounded.
            def _normalise(raw_score: float) -> float:
                if table_total_cost <= 0:
                    return 0.0
                normalised = raw_score / table_total_cost
                # Clamp - cost_share double-counts when one column
                # appears in multiple clauses of the same job (see
                # scorer.py:150-172), so the raw sum can exceed
                # table_total_cost.
                return max(0.0, min(1.0, normalised))

            normalised_partition_score = _normalise(partition_score)

            # 5c. Persist the recommendation + its candidate rows.
            rec_id = LayoutRecommendation.new_id()
            rec = LayoutRecommendation(
                id=rec_id,
                scan_run_id=scan_run_id,
                config_id=config_id,
                table_full_name=table_full_name,
                recommended_partition_column=partition_pick,
                recommended_partition_type=partition_type,
                partition_score=normalised_partition_score,
                apply_sql=artifacts.apply_sql,
                rollback_sql=artifacts.rollback_sql,
                caveats=caveats,
                table_is_currently_partitioned=is_partitioned,
                table_total_bytes=total_bytes,
                table_total_cost_in_window_usd=table_total_cost,
                contributing_job_count=usage.total_consumer_jobs,
            )
            session.add(rec)
            for sc in scored:
                rank = cluster_lookup.get(sc.column_name)
                is_partition = (sc.column_name == partition_pick)
                if rank is None and not is_partition:
                    # Surface the top extras (next two beyond the
                    # cluster picks) so the detail page can show
                    # "why didn't column X win" without re-running
                    # analysis. Limit total persisted candidates per
                    # rec to keep the table bounded.
                    if (
                        len([c for c in scored
                             if c.score >= sc.score]) > MAX_CLUSTER_COLUMNS + 4
                    ):
                        continue
                session.add(LayoutCandidateColumn(
                    id=LayoutCandidateColumn.new_id(),
                    recommendation_id=rec_id,
                    column_name=sc.column_name,
                    usage_type=sc.usage_type,
                    score=_normalise(sc.score),
                    cost_share=sc.cost_share,
                    contributing_job_count=sc.contributing_job_count,
                    cluster_rank=rank,
                    is_partition_pick=is_partition,
                ))
            persisted += 1
        except Exception:  # noqa: BLE001
            logger.exception(
                "layout recommender: failed to persist table=%s - "
                "skipping this table, continuing with others",
                table_full_name,
            )

    session.flush()
    logger.info(
        "layout recommender: persisted %d recommendations for scan_run_id=%s",
        persisted,
        scan_run_id,
    )

    # US2 - fetch BigQuery's own recommender output (best-effort) +
    # attach to the persisted recommendations as LayoutBqSecondOpinion
    # rows.
    if persisted and bq_client is not None and project_id and region:
        _attach_second_opinions(
            session=session,
            scan_run_id=scan_run_id,
            config_id=config_id,
            bq_client=bq_client,
            project_id=project_id,
            region=region,
            jobs_by_table=jobs_by_table,
        )

    return persisted


def _attach_second_opinions(
    *,
    session: "Session",
    scan_run_id: str,
    config_id: str,
    bq_client: "BigQueryClientProtocol",
    project_id: str,
    region: str,
    jobs_by_table: dict,
) -> None:
    """Fetch INFORMATION_SCHEMA.RECOMMENDATIONS + INSIGHTS and write
    LayoutBqSecondOpinion rows."""
    from governor_audit.layout import second_opinion

    by_table = second_opinion.fetch_for_region(
        bq_client=bq_client,
        project_id=project_id,
        region=region,
    )

    recs = (
        session.query(LayoutRecommendation)
        .filter(
            LayoutRecommendation.scan_run_id == scan_run_id,
            LayoutRecommendation.config_id == config_id,
        )
        .all()
    )

    # Wipe any pre-existing second-opinion rows for these recs (e.g.
    # re-running the recommender within the same scan).
    rec_ids = [r.id for r in recs]
    if rec_ids:
        session.query(LayoutBqSecondOpinion).filter(
            LayoutBqSecondOpinion.recommendation_id.in_(rec_ids)
        ).delete(synchronize_session=False)
        session.flush()

    for rec in recs:
        bq_op = by_table.get(rec.table_full_name)
        if bq_op is None:
            continue
        # Audit's "top pick" = partition column if present, else top
        # cluster column. ``recommendation.candidates`` is ordered
        # cluster_rank-ascending then score-descending, so the first
        # cluster_rank=1 entry is our top cluster pick.
        audit_top_column = (
            rec.recommended_partition_column
            or next(
                (
                    c.column_name
                    for c in rec.candidates
                    if c.cluster_rank == 1
                ),
                None,
            )
        )
        agrees = second_opinion.compute_agreement(
            audit_top_column=audit_top_column,
            bq_columns=bq_op.recommended_columns,
        )
        session.add(LayoutBqSecondOpinion(
            id=LayoutBqSecondOpinion.new_id(),
            recommendation_id=rec.id,
            bq_recommendation_id=bq_op.recommendation_id,
            bq_recommendation_state=bq_op.state,
            bq_recommended_columns=bq_op.recommended_columns,
            bq_description=bq_op.description,
            bq_insights=bq_op.insights,
            agrees_with_audit_top_pick=agrees,
            last_refresh_time=bq_op.last_refresh_time,
        ))

    session.flush()


def _ref_to_fq(ref: object) -> str | None:
    """Normalise a single ``referenced_tables`` entry to
    ``project.dataset.table`` (duplicates opportunities.py's helper -
    kept local to avoid a circular import)."""
    if isinstance(ref, str):
        return ref
    if isinstance(ref, dict):
        proj = ref.get("project_id") or ref.get("projectId") or ""
        ds = ref.get("dataset_id") or ref.get("datasetId") or ""
        tbl = ref.get("table_id") or ref.get("tableId") or ""
        parts = [p for p in (proj, ds, tbl) if p]
        if len(parts) == 3:
            return ".".join(parts)
    return None


__all__ = [
    "CLUSTER_MIN_SIZE_BYTES",
    "PARTITION_MIN_SIZE_BYTES",
    "run",
]
