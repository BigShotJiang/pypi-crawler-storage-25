"""Jinja filters for the audit web UI.

Mirrors ``governor_web.template_filters`` (the cloud's filter module) so
templates copied from there work as-is. We only carry the helpers
audit actually uses - ``timeago`` for "Last scan: 5 minutes ago" style
relative timestamps on the configuration page, plus BigQuery error
reason humanisers.
"""

from __future__ import annotations

import re
from datetime import datetime


# ─── BigQuery error reason helpers ───────────────────────────────────
#
# ``error_result.reason`` is BigQuery's own classifier - a closed
# vocabulary of camelCase tokens. We preserve the raw token everywhere
# it's used as a filter value or grep target (so admins can match it
# against Google's docs and runbooks), and surface a human-readable
# gloss alongside it via tooltips + the dashboard KPI sentence.
#
# Mapping curated against
# https://cloud.google.com/bigquery/docs/error-messages (May 2026).
# Unknown reasons fall through to the humanised camelCase form
# ("someNewReason" → "Some new reason") - better than no description
# when BigQuery adds a new code.
BQ_REASON_DESCRIPTIONS: dict[str, str] = {
    "invalidQuery": (
        "Query syntax error or referenced object doesn't exist."
    ),
    "invalid": (
        "Query syntax or shape was rejected - check the message for specifics."
    ),
    "resourcesExceeded": (
        "Query exceeded the slot or memory limit - often a join blow-up "
        "or unbounded aggregation."
    ),
    "responseTooLarge": (
        "Result set too large to return inline - use a destination table "
        "or add LIMIT."
    ),
    "stopped": (
        "Query was cancelled before completion (user, parent script, or admin)."
    ),
    "notFound": (
        "Referenced table, dataset, or routine doesn't exist (or was deleted)."
    ),
    "accessDenied": (
        "Caller lacks the required permission on a referenced object."
    ),
    "rateLimitExceeded": (
        "Hit a BigQuery per-project or per-user rate limit - usually retriable."
    ),
    "duplicate": (
        "Destination table already exists (CREATE TABLE without "
        "WRITE_TRUNCATE / OR REPLACE)."
    ),
    "internalError": (
        "BigQuery internal error - usually retriable."
    ),
    "backendError": (
        "BigQuery backend failure - usually retriable."
    ),
    "timeout": (
        "Query exceeded the per-job time limit (6 hours by default)."
    ),
    "billingTierLimitExceeded": (
        "Query exceeded the on-demand billing tier (legacy)."
    ),
    "quotaExceeded": (
        "Exceeded a BigQuery quota - check the message for which one."
    ),
    "jobInternalError": (
        "Job-level internal error - usually retriable."
    ),
    "jobBackendError": (
        "Job-level backend failure - usually retriable."
    ),
    "policyViolation": (
        "Query violated an organisation policy or column-level security rule."
    ),
    "tableUnavailable": (
        "Referenced table is temporarily unavailable - usually retriable."
    ),
    "queryTooComplex": (
        "Query plan exceeded BigQuery's complexity limit - split or simplify."
    ),
}


_CAMEL_BOUNDARY = re.compile(r"(?<=[a-z0-9])(?=[A-Z])")


def bq_reason_humanize(code: str | None) -> str:
    """Convert a BigQuery error reason camelCase code to space-separated
    lowercase prose: ``invalidQuery`` → ``invalid query``. Matches the
    visual treatment of detection-rule names (``slot_contention`` →
    ``slot contention``), so reason chips and issue chips read with
    the same calm lowercase weight across the app.

    Returns ``""`` for falsy input. Unknown / future codes flow through
    the camel-splitter, so audit doesn't need to know every BigQuery
    reason ahead of time.
    """
    if not code:
        return ""
    parts = _CAMEL_BOUNDARY.split(code)
    return " ".join(parts).lower()


def bq_reason_description(code: str | None) -> str:
    """Return a one-line human-readable description for a BigQuery
    error reason code. Falls back to the humanised camelCase form when
    the code isn't in the curated mapping.

    Used for ``title=`` tooltips on reason pills - admins keep the raw
    code visible (greppable against Google's docs) but get the prose
    on hover.
    """
    if not code:
        return ""
    if code in BQ_REASON_DESCRIPTIONS:
        return BQ_REASON_DESCRIPTIONS[code]
    return bq_reason_humanize(code)


def timeago(dt: datetime | None) -> str:
    """Format datetime as relative time if < 24h, else absolute date.

    Vendored from governor_web/template_filters.timeago. Returns:
      - "Never" when dt is None
      - "Just now" when < 60 s
      - "5 minutes ago" / "3 hours ago" within 24 h
      - "Apr 28, 2026" otherwise
    """
    if dt is None:
        return "Never"

    now = datetime.now(dt.tzinfo) if dt.tzinfo else datetime.now()
    delta = now - dt
    secs = delta.total_seconds()

    if secs < 0:
        # Future timestamp - surface verbatim, don't lie about elapsed.
        return dt.strftime("%b %d, %Y")
    if secs < 60:
        return "Just now"
    if secs < 3600:
        n = int(secs // 60)
        return f"{n} minute{'s' if n != 1 else ''} ago"
    if secs < 86_400:
        n = int(secs // 3600)
        return f"{n} hour{'s' if n != 1 else ''} ago"
    return dt.strftime("%b %d, %Y")


__all__ = [
    "BQ_REASON_DESCRIPTIONS",
    "bq_reason_description",
    "bq_reason_humanize",
    "timeago",
]
