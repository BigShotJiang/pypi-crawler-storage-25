"""FastAPI application factory for governor-audit.

Single-process, loopback-only web server. Renders findings + scan
history from the local SQLite cache. Boots via:

    make audit-run                                          # devbox shell
    uv run --package governor-audit uvicorn governor_audit.web.main:app

The bind address is loopback per FR-020/FR-021 - defense-in-depth on top
of the uvicorn ``--host`` flag, a custom middleware rejects any request
whose ``Host:`` header isn't a localhost variant.
"""

from __future__ import annotations

from pathlib import Path

from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from starlette.middleware.base import BaseHTTPMiddleware

from governor_audit.version import get_app_version
from governor_audit.web.routes import (
    chat as chat_routes,
    configurations as configurations_routes,
    findings,
    methodology as methodology_routes,
    opportunities as opportunities_routes,
    recommendations_layout as recommendations_layout_routes,
    scan as scan_routes,
    settings as settings_routes,
    setup as setup_routes,
    status as status_routes,
)

_LOOPBACK_HOSTS = frozenset({
    "127.0.0.1",
    "localhost",
    "[::1]",
    "::1",
})


class LoopbackOnlyMiddleware(BaseHTTPMiddleware):
    """Reject any request whose ``Host:`` header doesn't match a loopback
    name. Defense-in-depth on top of the loopback bind address.
    """

    async def dispatch(self, request: Request, call_next):
        host_header = request.headers.get("host", "").split(":", 1)[0].lower()
        if host_header and host_header not in _LOOPBACK_HOSTS:
            return JSONResponse(
                {"error": "loopback only"},
                status_code=403,
            )
        return await call_next(request)


def create_app() -> FastAPI:
    """Build the FastAPI app. Importable as ``governor_audit.web.main:app``
    by uvicorn.
    """
    app_version = get_app_version()
    fastapi_app = FastAPI(
        title="Governor Audit",
        version=app_version,
        docs_url=None,  # No /docs in the local UI
        redoc_url=None,
    )

    fastapi_app.add_middleware(LoopbackOnlyMiddleware)

    templates_dir = Path(__file__).parent / "templates"
    static_dir = Path(__file__).parent / "static"
    templates = Jinja2Templates(directory=str(templates_dir))
    templates.env.globals["app_version"] = app_version

    # Reuse governor-core's currency formatter so audit's USD rendering
    # matches the cloud version exactly ($12.3k / $1.23M / $1,234.56).
    # ``format_slot_hours`` was registered here but never used by any
    # audit template, so it's dropped to reduce the import surface.
    from governor_core.utils.formatters import (
        format_bytes as core_format_bytes,
        format_duration,
        format_usd,
    )
    templates.env.filters["format_usd"] = format_usd
    templates.env.filters["format_bytes"] = core_format_bytes
    templates.env.filters["format_duration"] = format_duration

    # `timeago` matches governor-web's filter so vendored templates
    # render relative timestamps (e.g. "5 minutes ago") identically.
    from governor_audit.web.template_filters import (
        bq_reason_description,
        bq_reason_humanize,
        timeago,
    )
    templates.env.filters["timeago"] = timeago
    templates.env.filters["bq_reason_description"] = bq_reason_description
    templates.env.filters["bq_reason_humanize"] = bq_reason_humanize

    # Lazy callable for layout.html's sidebar footer (the audit's "current
    # user" is whichever gcloud account ADC is bound to). Named
    # ``active_principal_fn`` to avoid colliding with the string
    # ``active_principal`` some routes already pass as template context.
    def _active_principal_global() -> str | None:
        from governor_audit.web.routes.configurations import _active_principal
        try:
            return _active_principal()
        except Exception:  # noqa: BLE001
            return None
    templates.env.globals["active_principal_fn"] = _active_principal_global

    # Expose a few small helpers to the layout's global header strip:
    # - audit_now_fn() returns "now" so the template can compute the
    #   Period chip (lookback_days back from today) without leaking
    #   a datetime literal into Jinja
    # - timedelta is exposed under the same name so the chip's
    #   ``today - timedelta(days=lookback)`` arithmetic works in
    #   the template
    from datetime import datetime as _datetime, timedelta as _timedelta
    templates.env.globals["audit_now_fn"] = _datetime.utcnow
    templates.env.globals["timedelta"] = _timedelta

    # The Period chip in the global header strip reads from the
    # latest succeeded ``ScanRun`` so it reflects what the cached
    # data ACTUALLY covers - not whatever ``scan_defaults.lookback_days``
    # is currently set to. (The next scan would use the config's
    # value, but the chip is about the data on screen RIGHT NOW.)
    # Returns a dict with ``window_start``, ``window_end``,
    # ``requested_lookback_days``, or ``None`` if no successful
    # scan has been recorded yet. The template falls back to the
    # config-based computation in that case so onboarding pages
    # don't see a broken chip.
    def _latest_scan_window_global():
        try:
            from sqlalchemy import desc
            from governor_audit.db.models import ScanRun
            from governor_audit.db.session import (
                build_engine,
                create_all,
                make_session_factory,
            )

            engine = build_engine()
            create_all(engine)
            factory = make_session_factory(engine)
            with factory() as session:
                row = (
                    session.query(ScanRun)
                    .filter(ScanRun.status == "succeeded")
                    .order_by(desc(ScanRun.completed_at))
                    .first()
                )
                if row is None:
                    return None
                return {
                    "window_start": row.actual_window_start,
                    "window_end": row.actual_window_end,
                    "requested_lookback_days": row.requested_lookback_days,
                }
        except Exception:  # noqa: BLE001
            # Cache uninitialised, schema mismatch on first boot, etc.
            # The template's fallback path handles ``None`` gracefully.
            return None

    templates.env.globals["latest_scan_window_fn"] = _latest_scan_window_global

    fastapi_app.state.templates = templates
    fastapi_app.mount(
        "/static",
        StaticFiles(directory=str(static_dir)),
        name="static",
    )

    fastapi_app.include_router(findings.router)
    fastapi_app.include_router(opportunities_routes.router)
    fastapi_app.include_router(status_routes.router)
    fastapi_app.include_router(configurations_routes.router)
    fastapi_app.include_router(scan_routes.router)
    fastapi_app.include_router(settings_routes.router)
    fastapi_app.include_router(setup_routes.router)
    fastapi_app.include_router(methodology_routes.router)
    fastapi_app.include_router(recommendations_layout_routes.router)
    # Spec 153 - in-browser chat surface.
    fastapi_app.include_router(chat_routes.router)

    return fastapi_app


# Module-level app for `uvicorn governor_audit.web.main:app`
app = create_app()


__all__ = ["app", "create_app", "LoopbackOnlyMiddleware"]
