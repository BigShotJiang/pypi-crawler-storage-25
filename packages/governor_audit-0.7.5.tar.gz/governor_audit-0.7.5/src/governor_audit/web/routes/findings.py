"""GET / + GET /dashboard + GET /opportunities + GET /jobs/{job_id}.

Read-only browse pages backed by the local SQLite cache.

GET / redirects based on config state:
  - configured + scans  → /dashboard
  - configured + no scans → /admin/configurations (the actionable page)
  - not configured → /admin/configurations/new

Dashboard layout (matches CLI muscle memory):
  1. KPI cards (total spend / bytes / unique patterns / dbt-originated)
  2. Bar chart of the 20 most expensive jobs (per-job, NOT grouped)
  3. Table of the same 20 jobs with name + date + cost + issues count.
     Each row is clickable → /jobs/{job_id} for the full SQL + metadata.

Issues count is derived from cached ``Opportunity`` rows; until the
detection engine is wired up in this package the column reads 0 for
every job. That's expected for v1 - see spec 141, "scope = read-only
audit"; LLM solutions and detection-rule replay land later.
"""

from __future__ import annotations

from decimal import Decimal

from fastapi import APIRouter, HTTPException, Request
from fastapi.responses import HTMLResponse, RedirectResponse
from sqlalchemy import desc

from governor_audit.config.loader import ConfigNotFoundError, load_config
from governor_audit.db.session import build_engine, create_all, make_session_factory

router = APIRouter()


@router.get("/", response_class=HTMLResponse)
def root(request: Request):
    try:
        load_config()
    except ConfigNotFoundError:
        return RedirectResponse(url="/setup", status_code=303)
    return RedirectResponse(url="/dashboard", status_code=303)


def _format_bytes(n: int | None) -> str:
    """Human-readable bytes (binary units)."""
    if not n:
        return "0 B"
    value = float(n)
    for unit in ("B", "KiB", "MiB", "GiB", "TiB"):
        if value < 1024:
            return f"{value:.1f} {unit}"
        value /= 1024
    return f"{value:.1f} PiB"


def _format_duration_ms(ms: int | None) -> str:
    if not ms:
        return "-"
    if ms < 1000:
        return f"{ms} ms"
    s = ms / 1000
    if s < 60:
        return f"{s:.1f} s"
    m = s / 60
    if m < 60:
        return f"{m:.1f} m"
    return f"{m / 60:.1f} h"


def _is_dbt_originated(query: str | None) -> bool:
    """Best-effort dbt detection from query body. Mirrors
    ``governor_audit.scan.information_schema.is_dbt_originated`` but
    operates on the cached ``query`` text only (BigQueryJob doesn't
    persist labels - that's deliberate per FR-042)."""
    return bool(query) and query.lstrip().startswith('/* {"app": "dbt"')


# Statement types that *materialise* data (write a table) - used by the
# manifest-free build/consumption classifier below.
_MATERIALISING_STATEMENT_TYPES = frozenset(
    {
        "CREATE_TABLE_AS_SELECT",
        "CREATE_TABLE",
        "CREATE_VIEW",
        "CREATE_MATERIALIZED_VIEW",
        "MERGE",
        "INSERT",
        "UPDATE",
        "DELETE",
        "TRUNCATE_TABLE",
    }
)


def _classify_workload(query: str | None, statement_type: str | None) -> str:
    """Workload classifier - write vs. read.

    Audit serves users who scan ANY BigQuery project, not just dbt
    shops. The original dbt-aware classifier parked manual writes
    (Airflow MERGEs, scheduled CTASes, ad-hoc CREATE TABLEs) in an
    "other" bucket that rendered as Unclassified - leaving the
    Build / Consumption split blind to most non-dbt build pipelines.

    The simpler model used here:

    * **build** - any statement that materialises data
      (CTAS, MERGE, INSERT, UPDATE, DELETE, TRUNCATE, CREATE VIEW /
      MATERIALIZED VIEW). dbt-origin is no longer required.
    * **consumption** - anything else (SELECTs, BI tools, ad-hoc
      analysts, reverse-ETL exports).

    The ``query`` argument is kept for API stability - the dashboard's
    cost-summary aggregator and the opportunities route both call
    ``_classify_workload(query, statement_type)`` - but it's now unused.
    """
    del query  # kept for API stability; no longer consulted.
    is_writer = (statement_type or "") in _MATERIALISING_STATEMENT_TYPES
    return "build" if is_writer else "consumption"


def _shorten_destination(table: str | None, project_id: str) -> str:
    """Strip the configured project prefix from a fully-qualified table
    name so the dashboard table doesn't waste 18 chars on something the
    user already chose. Returns ``dataset.table`` when the prefix
    matches, the unchanged value otherwise.
    """
    if not table or not project_id:
        return table or "-"
    prefix = f"{project_id}."
    if table.startswith(prefix):
        return table[len(prefix) :]
    return table


def _split_destination(table: str | None, project_id: str) -> tuple[str, str]:
    """Return ``(dataset, object)`` from a BigQuery table identifier."""
    shortened = _shorten_destination(table, project_id)
    if not shortened or shortened == "-":
        return "-", "-"
    parts = [p for p in shortened.split(".") if p]
    if len(parts) >= 2:
        return parts[-2], parts[-1]
    return "-", parts[0]


# Cohort helpers moved to ``governor_audit.scan.version_cohort`` so that
# both the scan-time detection orchestrator and these read-time route
# helpers compute the cohort the same way. Re-exported here under the
# legacy private names so anything importing them keeps working.
from governor_audit.scan.version_cohort import (
    latest_version_cohort_job_ids as _latest_version_cohort_job_ids,
    version_id_for as _version_id_for,
)


def _build_issue_index(
    session,
    *,
    config_id: str,
    latest_cohort: set[str] | None = None,
) -> tuple[
    dict[str, int],
    list,
    dict,
    dict[str, int],
    set[str],
    dict[str, int],
    dict[str, int],
]:
    """Walk active ``Opportunity`` rows and return:

    * ``issue_counts``: jid → how many ISSUE-rule findings touch this
      job. Drives the dashboard's "Issues" column / red pill - the
      table is titled "Top Cost Drivers with Issues Found" so the
      number must reflect issue rules only (slot_contention,
      join_explosion, partition_pruning, shuffle_spill). Suggestion
      rules (dead_cte, select_star, redundant_order_by, …) used to
      pile in here, which is why a job with only an SQL-rewrite
      suggestion was showing up in the issues table.
    * ``opps``: the raw Opportunity rows (so callers can reuse the
      single query for type-card aggregation).
    * ``opp_summary``: ``{total_count, total_current_cost, type_cards}``
      - the shape the dashboard partials expect. Savings fields were
      removed: audit refuses to surface the existing rules' hardcoded-
      percentage savings figures.
    * ``suggestion_counts``: jid → how many suggestion-rule findings
      touch this job. Used for the Suggestions chip / future UI.
    * ``flagged_job_ids``: any-finding union, for the Flagged Spend
      card which deliberately includes both issues and suggestions
      ("flagged" = anything detection caught).

    A single opportunity may reference multiple jobs (rules group by
    table); we count every (opp, job) pairing.
    """
    from governor_audit.scan.categorization import ISSUE_RULE_TYPES
    from governor_core.opportunities.models import Opportunity

    # storage_billing_optimization is rendered in its own dashboard
    # panel (per-dataset rows + Action). Excluding it from the query-
    # cost issues summary avoids double-counting and keeps the Active
    # Issues panel about per-job query findings only.
    opps = (
        session.query(Opportunity)
        .filter(Opportunity.status == "active")
        .filter(Opportunity.config_id == config_id)
        .filter(Opportunity.opportunity_type != "storage_billing_optimization")
        .all()
    )
    issue_counts: dict[str, int] = {}
    suggestion_counts: dict[str, int] = {}
    # Per-table counts: number of active issue / suggestion opps whose
    # ``affected_table`` matches the logical job. Used by the dashboard
    # aggregator to colour build bars by table-level findings.
    #
    # When ``latest_cohort`` is provided, an opp only counts against
    # its affected_table if at least one of its ``related_job_ids``
    # falls inside the latest-version cohort for that table. Opps
    # whose evidence lives entirely in older versions are treated as
    # stale: the new query version may or may not still trip the
    # rule, so we trust the per-version-detection signal (which gets
    # captured as a NEW opp on the next scan if the rule still fires).
    issue_counts_by_table: dict[str, int] = {}
    suggestion_counts_by_table: dict[str, int] = {}
    flagged_job_ids: set[str] = set()
    by_type: dict[str, dict] = {}
    total_current_cost = 0.0
    for opp in opps:
        is_issue = opp.opportunity_type in ISSUE_RULE_TYPES
        related = list(opp.related_job_ids or [])
        # Cohort gate: when a latest_cohort filter is active, skip
        # affected_table counts whose opp's evidence is all from older
        # versions. The opp row still exists in storage / detail pages,
        # but stops counting on the dashboard / opportunities tables.
        cohort_hit = (
            latest_cohort is None
            or not related
            or any(jid in latest_cohort for jid in related)
        )
        if opp.affected_table and cohort_hit:
            if is_issue:
                issue_counts_by_table[opp.affected_table] = (
                    issue_counts_by_table.get(opp.affected_table, 0) + 1
                )
            else:
                suggestion_counts_by_table[opp.affected_table] = (
                    suggestion_counts_by_table.get(opp.affected_table, 0) + 1
                )
        for jid in related:
            flagged_job_ids.add(jid)
            if is_issue:
                issue_counts[jid] = issue_counts.get(jid, 0) + 1
            else:
                suggestion_counts[jid] = suggestion_counts.get(jid, 0) + 1
        type_key = opp.opportunity_type
        bucket = by_type.setdefault(
            type_key,
            {
                "type_key": type_key,
                "label": type_key.replace("_", " ").title(),
                "count": 0,
                "total_cost": 0.0,
            },
        )
        bucket["count"] += 1
        bucket["total_cost"] += float(opp.current_cost_estimate or 0)
        total_current_cost += float(opp.current_cost_estimate or 0)
    type_cards = sorted(
        by_type.values(),
        key=lambda c: (c["total_cost"], c["count"]),
        reverse=True,
    )
    # ``total_count`` covers both buckets - that's the union of every
    # finding the table knows about. Distinct issue / suggestion totals
    # are exposed alongside so callers can build per-bucket captions
    # without re-walking ``opps``.
    issue_total = sum(
        1 for opp in opps if opp.opportunity_type in ISSUE_RULE_TYPES
    )
    summary = {
        "total_count": len(opps),
        "issue_count": issue_total,
        "suggestion_count": len(opps) - issue_total,
        "total_current_cost": total_current_cost,
        "type_cards": type_cards,
    }
    return (
        issue_counts,
        opps,
        summary,
        suggestion_counts,
        flagged_job_ids,
        issue_counts_by_table,
        suggestion_counts_by_table,
    )


def _aggregate_totals_and_top_jobs(
    session, *, top_n: int = 20, project_id: str = "", config_id: str
) -> tuple[list[dict], dict, dict]:
    """Walk every cached ``BigQueryJob``. Returns (top_jobs, totals, opp_summary).

    * ``top_jobs``: top N rows ordered by issue_count desc, then by cost -
      so the user sees flagged jobs first, biggest-spender first within
      that group. Used for the bar chart + table.
    * ``totals``: aggregate counters for the KPI cards.
    * ``opp_summary``: rule-grouped breakdown for the Active Issues pane.

    Issue-first ordering matches the user's mental model - "show me what's
    actionable, biggest first" - instead of pure cost ordering which
    buries findings under expensive-but-clean jobs.
    """
    from governor_audit.scan.categorization import is_failed_job
    from governor_core.sync.models import BigQueryJob

    # Spec 149: load every cached job, then partition in Python so we
    # can correctly handle the case where BigQuery surfaces
    # ``error_result`` as a non-NULL all-fields-NULL struct on a
    # successful job (a SQL ``IS NULL`` filter would miss those rows
    # and treat every job as failed → empty dashboard → spurious
    # redirect). ``is_failed_job`` defends against both shapes.
    all_cached_jobs = (
        session.query(BigQueryJob)
        .filter(BigQueryJob.config_id == config_id)
        .all()
    )
    jobs = [j for j in all_cached_jobs if not is_failed_job(j)]
    failed_jobs = [j for j in all_cached_jobs if is_failed_job(j)]
    failed_count = len(failed_jobs)
    failed_slot_ms = sum(j.total_slot_ms or 0 for j in failed_jobs)

    # Latest-version cohort: the unit of analysis for every per-row
    # surface (chart, cost-drivers table, Next actions, /opportunities
    # listing). KPI cards still report on the full job set - "Total
    # Spend" is window-wide spend by design.
    latest_cohort = _latest_version_cohort_job_ids(jobs)

    (
        issue_counts,
        opps_for_index,
        opp_summary,
        suggestion_counts,
        flagged_job_ids,
        issue_counts_by_table,
        suggestion_counts_by_table,
    ) = _build_issue_index(
        session, config_id=config_id, latest_cohort=latest_cohort
    )

    # Build a job_id → best opportunity_id map so the dashboard's bar
    # chart can deep-link to /opportunities/{id} instead of /jobs/{id}.
    # Picks the highest-severity issue for each job; falls back to any
    # active opportunity that lists this job in ``related_job_ids``. The
    # five issue rules outrank the SQL-rewrite suggestion rules so the
    # user lands on the most cost-impacting finding for that job.
    from governor_audit.scan.categorization import ISSUE_RULE_TYPES
    from governor_core.opportunities.models import Opportunity

    all_opps_for_jobs = (
        session.query(Opportunity)
        .filter(
            Opportunity.status == "active",
            Opportunity.config_id == config_id,
            Opportunity.opportunity_type != "storage_billing_optimization",
        )
        .all()
    )
    # Each entry: (priority_tuple, opportunity_id). max() over the
    # priority picks the best. Issues outrank improvements; within a
    # tier, higher severity wins.
    opportunity_by_job: dict[str, tuple[tuple[int, int], str]] = {}
    for opp in all_opps_for_jobs:
        is_issue = 1 if opp.opportunity_type in ISSUE_RULE_TYPES else 0
        priority = (is_issue, int(opp.severity_score or 0))
        for jid in opp.related_job_ids or []:
            current = opportunity_by_job.get(jid)
            if current is None or priority > current[0]:
                opportunity_by_job[jid] = (priority, opp.id)

    grand_total_cost = Decimal("0")
    grand_total_bytes = 0
    grand_total_slot_ms = 0
    grand_total_jobs = 0
    build_cost = Decimal("0")
    consumption_cost = Decimal("0")
    unique_hashes: set[str] = set()
    dbt_hashes: set[str] = set()
    dbt_job_count = 0

    flagged_spend = Decimal("0")
    for job in jobs:
        grand_total_jobs += 1
        cost = job.total_cost or Decimal("0")
        grand_total_cost += cost
        grand_total_bytes += job.total_bytes_processed or 0
        grand_total_slot_ms += job.total_slot_ms or 0

        # Build vs consumption split - mirrors governor-web's
        # `_cost_summary.html` cards. ``_classify_workload`` now
        # returns only 'build' or 'consumption' (any write is a build,
        # everything else is consumption - see the function docstring
        # for why we dropped dbt-origin gating).
        kind = _classify_workload(job.query, job.statement_type)
        if kind == "build":
            build_cost += cost
        else:
            consumption_cost += cost

        # Flagged spend: this job's cost counted ONCE if any active
        # opportunity references it. ``flagged_job_ids`` is the union
        # of issue + suggestion sets, so this card stays "spend on
        # jobs detection caught" regardless of which bucket caught it.
        if job.job_id in flagged_job_ids:
            flagged_spend += cost

        qh = job.query_hashes or {}
        hash_key = (
            qh.get("normalized_literals") if isinstance(qh, dict) else None
        ) or f"job:{job.job_id}"
        unique_hashes.add(hash_key)

        if _is_dbt_originated(job.query):
            dbt_job_count += 1
            dbt_hashes.add(hash_key)

    # Group rows by *logical* job before ranking - destination_table
    # for builds (CTAS / MERGE / etc.) and the normalized query_hash
    # for consumption (the same SELECT running thousands of times from
    # BI tools / dbt-test / etc.). Without this the bar chart shows
    # 20 separate ~$33 rows for one model that runs hourly instead of
    # one $600 row for that model. The user reasons about "this
    # model is expensive", not "this particular execution is expensive".
    #
    # Latest-version-cohort filter: only executions whose
    # ``(destination_table, version_id)`` matches the destination's
    # most-recent execution contribute to a group. This makes the
    # reported cost / bytes / slot for a logical job answer the
    # question "what does the LATEST deployed version of this query
    # cost the warehouse?" instead of mixing in the cost of prior
    # versions a redeploy already fixed (or made worse). Consumption
    # queries (no destination_table) are always in their own cohort
    # since each hash IS a distinct version.
    cohort_jobs = [j for j in jobs if j.job_id in latest_cohort]
    groups: dict[str, dict] = {}
    for job in cohort_jobs:
        cost = job.total_cost or Decimal("0")
        # Group key resolution - destination_table first (builds),
        # query_hash second (consumption), job_id last (one-off ad-hoc).
        qh = job.query_hashes or {}
        normalized_hash = (
            qh.get("normalized_literals") if isinstance(qh, dict) else None
        )
        if job.destination_table:
            key = f"dest:{job.destination_table}"
        elif normalized_hash:
            key = f"hash:{normalized_hash}"
        else:
            key = f"job:{job.job_id}"

        group = groups.get(key)
        if group is None:
            # Initialise the group with the *first* job's metadata; the
            # representative job (used for label / opportunity link)
            # is recomputed below to be the highest-cost execution,
            # and the *latest* job (used for issue/suggestion counts +
            # creation_time) tracks the most-recent creation_time.
            group = {
                "_key": key,
                "_representative": job,
                "_representative_cost": cost,
                "_latest": job,
                "_latest_creation_time": job.creation_time,
                "total_cost": Decimal("0"),
                "total_bytes": 0,
                "total_slot_ms": 0,
                "execution_count": 0,
                "job_ids": [],
                "any_dbt_originated": False,
            }
            groups[key] = group

        group["total_cost"] += cost
        group["total_bytes"] += job.total_bytes_processed or 0
        group["total_slot_ms"] += job.total_slot_ms or 0
        group["execution_count"] += 1
        group["job_ids"].append(job.job_id)
        if _is_dbt_originated(job.query):
            group["any_dbt_originated"] = True
        if cost > group["_representative_cost"]:
            group["_representative_cost"] = cost
            group["_representative"] = job
        # Track the latest execution by creation_time. Issue + suggestion
        # counts on the output row come from THIS execution only - a
        # model that ran 20 times all carrying the same 1 issue should
        # display "1 issue" (current state to act on), not 20 (sum
        # across history which is the same issue counted many times).
        cur_latest = group["_latest_creation_time"]
        if job.creation_time is not None and (
            cur_latest is None or job.creation_time > cur_latest
        ):
            group["_latest"] = job
            group["_latest_creation_time"] = job.creation_time

    # Rank logical jobs by aggregated cost desc and slice to top_n.
    ranked_groups = sorted(
        groups.values(),
        key=lambda g: g["total_cost"],
        reverse=True,
    )[:top_n]

    formatted: list[dict] = []
    for group in ranked_groups:
        rep = group["_representative"]
        latest = group["_latest"]
        agg_cost = group["total_cost"]
        share_pct = float((agg_cost / grand_total_cost) * 100) if grand_total_cost else 0.0
        if rep.destination_table:
            short_label = rep.destination_table.split(".")[-1]
        else:
            short_label = rep.job_id.split(":")[-1][-32:]
        destination_dataset, destination_object = _split_destination(
            rep.destination_table, project_id
        )

        # Best opportunity across all executions in the group - pick
        # the one whose priority tuple ``(is_issue, severity_score)``
        # is highest. Issues outrank improvements; within a tier,
        # higher severity wins. Matches the per-execution selection
        # logic above the loop.
        best_opp_id: str | None = None
        best_priority: tuple[int, int] | None = None
        for jid in group["job_ids"]:
            entry = opportunity_by_job.get(jid)
            if entry is None:
                continue
            priority, opp_id = entry
            if best_priority is None or priority > best_priority:
                best_priority = priority
                best_opp_id = opp_id

        formatted.append(
            {
                "job_id": rep.job_id,
                "short_label": short_label,
                "destination_table": rep.destination_table or "-",
                "destination_short": _shorten_destination(
                    rep.destination_table, project_id
                ),
                "destination_dataset": destination_dataset,
                "destination_object": destination_object,
                "statement_type": rep.statement_type or "",
                "workload_kind": _classify_workload(rep.query, rep.statement_type),
                # ``creation_time`` reflects the LATEST execution so
                # the "Run at" column tells the user the freshness of
                # this logical job, not whichever execution happened
                # to be the cost representative.
                "creation_time": latest.creation_time,
                # Cost / bytes / slot are AGGREGATED across every
                # execution in the logical group. Template column
                # headers say "Cost", "Bytes", "Slot time"; the values
                # are sums, the ``execution_count`` sub-text clarifies.
                "cost_usd": float(agg_cost),
                "cost_share_pct": share_pct,
                "bytes_processed": group["total_bytes"],
                "bytes_processed_human": _format_bytes(group["total_bytes"]),
                "slot_time_ms": group["total_slot_ms"],
                "slot_time_human": _format_duration_ms(group["total_slot_ms"]),
                "is_dbt_originated": group["any_dbt_originated"],
                # Issue + suggestion counts:
                #   * For build groups (``dest:<table>``): count opps
                #     whose ``affected_table`` matches the destination.
                #     This is the right semantic for the user - "this
                #     model has N issues" - and avoids the previous
                #     latest-execution-only bug where a model with 3
                #     active findings showed "0 issues" because the
                #     latest re-run happened after the rule fired and
                #     therefore wasn't in any opp's ``related_job_ids``.
                #   * For hash / job groups (consumption queries with
                #     no destination_table): fall back to the latest
                #     execution's per-job count, since opps for those
                #     don't have a meaningful affected_table key.
                "issue_count": (
                    issue_counts_by_table.get(rep.destination_table, 0)
                    if rep.destination_table
                    else issue_counts.get(latest.job_id, 0)
                ),
                "suggestion_count": (
                    suggestion_counts_by_table.get(rep.destination_table, 0)
                    if rep.destination_table
                    else suggestion_counts.get(latest.job_id, 0)
                ),
                "user_email": rep.user_email or "",
                "opportunity_id": best_opp_id,
                # NEW - how many executions this row aggregates over.
                # Templates surface this as "ran N times" sub-text so
                # users understand they're seeing a logical-job total.
                "execution_count": group["execution_count"],
            }
        )

    totals = {
        "total_jobs": grand_total_jobs,
        "total_cost_usd": float(grand_total_cost),
        "build_spend": float(build_cost),
        "consumption_spend": float(consumption_cost),
        "total_bytes_processed": grand_total_bytes,
        "total_bytes_processed_human": _format_bytes(grand_total_bytes),
        "total_slot_ms": grand_total_slot_ms,
        "total_slot_hours": grand_total_slot_ms / (1000 * 60 * 60) if grand_total_slot_ms else 0.0,
        "unique_query_patterns": len(unique_hashes),
        "dbt_originated_count": dbt_job_count,
        "dbt_originated_pattern_count": len(dbt_hashes),
        "total_issues": opp_summary["total_count"],
        # "Flagged spend" = sum of total_cost across cached jobs that
        # have ≥ 1 active Opportunity, deduped per job_id. Previously
        # we summed ``opp.current_cost_estimate`` over every
        # Opportunity row, which double-counted jobs that fired
        # multiple rules. See the ``flagged_spend`` accumulator above.
        "flagged_spend": float(flagged_spend),
        # Spec 149 - failed-jobs surface. Both keys are 0 on a clean
        # warehouse so the dashboard tile renders the empty-state row.
        "failed_jobs_count": int(failed_count or 0),
        "failed_slot_ms": int(failed_slot_ms or 0),
        "failed_slot_ms_human": _format_duration_ms(int(failed_slot_ms or 0)),
    }
    return formatted, totals, opp_summary


_DASHBOARD_PAGE_SIZE = 10
_BAR_CHART_TOP_N = 20


# Sort key catalogue. Maps the ``?sort=`` query param to a function that
# extracts the comparison key from a formatted row dict. Mirrors
# governor-web's $driverSort enum on the cost-drivers table.
_SORT_KEYS = {
    "destination": lambda r: (r.get("destination_table") or "").lower(),
    "dataset": lambda r: (r.get("destination_dataset") or "").lower(),
    "object": lambda r: (r.get("destination_object") or "").lower(),
    "spend": lambda r: r.get("cost_usd") or 0,
    "bytes": lambda r: r.get("bytes_processed") or 0,
    "slot_time": lambda r: r.get("slot_time_ms") or 0,
    "issues": lambda r: r.get("issue_count") or 0,
    "suggestions": lambda r: r.get("suggestion_count") or 0,
    "workload": lambda r: r.get("workload_kind") or "",
    "source": lambda r: 0 if r.get("is_dbt_originated") else 1,
    "run_at": lambda r: r.get("creation_time") or 0,
}
_DEFAULT_SORT = "spend"
_DEFAULT_DIRECTION = "desc"


def _normalise_sort(sort: str | None, direction: str | None) -> tuple[str, str]:
    """Clamp the user-supplied query params to the allow-list."""
    s = sort if sort in _SORT_KEYS else _DEFAULT_SORT
    d = direction if direction in ("asc", "desc") else _DEFAULT_DIRECTION
    return s, d


def _apply_sort(rows: list[dict], sort_by: str, direction: str) -> list[dict]:
    key_fn = _SORT_KEYS[sort_by]
    return sorted(rows, key=key_fn, reverse=(direction == "desc"))


@router.get("/dashboard", response_class=HTMLResponse)
def dashboard(
    request: Request,
    page: int = 1,
    sort: str | None = None,
    direction: str | None = None,
    scan_status: str | None = None,
    scan_detail: str | None = None,
):
    """Dashboard is gated on the cache having at least one job.

    ``?page=N`` server-paginates the issue-only Top Cost Drivers table
    at 10 rows per page; ``?sort=spend&direction=desc`` powers the
    click-to-sort headers. Defaults to spend / desc.

    The table is restricted to jobs with ``issue_count > 0`` per the
    user's ask - "Top Cost Drivers with Issues Found" only shows rows
    the detection engine flagged. The bar chart is unaffected (it's
    labelled "Top 20 Spenders", so it ranks every job by cost).
    """
    from governor_core.utils.pagination import PaginationContext

    templates = request.app.state.templates
    try:
        config = load_config()
    except ConfigNotFoundError:
        return RedirectResponse(url="/setup", status_code=303)

    sort_by, sort_dir = _normalise_sort(sort, direction)

    # Scope every read to the active (project, region) - without this
    # the SQLite cache merges every project ever scanned. See
    # ``governor_audit.scan.sentinels.config_id_for`` for the hash.
    from governor_audit.scan.sentinels import config_id_for

    active_config_id = config_id_for(config.gcp_project_id, config.bigquery_region)

    engine = build_engine()
    create_all(engine)
    factory = make_session_factory(engine)
    with factory() as session:
        # Single aggregator call - get every logical job ordered by
        # cost desc once, then slice in Python. The previous code
        # called ``_aggregate_totals_and_top_jobs`` twice (top-20 for
        # the chart, all rows for the table) which doubled the SQL +
        # JSON-decode + per-job grouping work for no gain. The result
        # set is already sorted by ``total_cost`` desc so ``[:20]``
        # gives chart_jobs and the full list gives all_jobs.
        all_jobs, totals, opp_summary = _aggregate_totals_and_top_jobs(
            session,
            top_n=10_000_000,  # effectively unbounded - Python slice handles trimming
            project_id=config.gcp_project_id,
            config_id=active_config_id,
        )

        # Spec 149 - top failed-job groups, ordered by slot wasted desc.
        # Same hash grouping as /failures so clicks land on the matching
        # detail page. Top 10 to match the cost-drivers list size.
        from governor_audit.scan.categorization import is_failed_job
        from governor_core.sync.models import BigQueryJob

        all_failed_for_dashboard = (
            session.query(BigQueryJob)
            .filter(BigQueryJob.config_id == active_config_id)
            .order_by(desc(BigQueryJob.creation_time))
            .all()
        )
        failed_for_dashboard = [j for j in all_failed_for_dashboard if is_failed_job(j)]

    failed_drivers_groups = _build_failure_groups(failed_for_dashboard)
    failed_drivers = sorted(
        failed_drivers_groups, key=lambda g: g["total_slot_ms"], reverse=True
    )[:10]
    for g in failed_drivers:
        g["total_slot_human"] = _format_duration_ms(g["total_slot_ms"])
        g["destination_short"] = (
            g["destination_object"] or g["destination_table"].split(".")[-1]
            if g["destination_table"] else "-"
        )

    if totals["total_jobs"] == 0:
        return RedirectResponse(url="/admin/configurations", status_code=303)

    # The cost-drivers table now lists Top Cost Drivers with Issues
    # AND Suggestions Found, so the row filter must include both. A
    # job with only a suggestion-typed finding (e.g. select_star) used
    # to be excluded entirely; with the rename the table exposes them
    # alongside issue-typed rows.
    issue_jobs = [
        j for j in all_jobs
        if (j["issue_count"] > 0 or j["suggestion_count"] > 0)
    ]
    issue_jobs = _apply_sort(issue_jobs, sort_by, sort_dir)

    page = max(1, page)
    pagination = PaginationContext(
        page=page,
        page_size=_DASHBOARD_PAGE_SIZE,
        total_items=len(issue_jobs),
    )
    if page > pagination.total_pages:
        page = pagination.total_pages
        pagination = PaginationContext(
            page=page,
            page_size=_DASHBOARD_PAGE_SIZE,
            total_items=len(issue_jobs),
        )

    start = (page - 1) * _DASHBOARD_PAGE_SIZE
    paged_jobs = issue_jobs[start : start + _DASHBOARD_PAGE_SIZE]

    # Bar chart shows the top-N by cost. ``all_jobs`` is already sorted
    # ``total_cost`` desc by the aggregator, so the slice is correct.
    chart_jobs = all_jobs[:_BAR_CHART_TOP_N]
    chart_jobs_payload = [
        {
            "job_id": j["job_id"],
            "label": j["short_label"],
            "cost": j["cost_usd"],
            "bytes_human": j["bytes_processed_human"],
            "issues": j["issue_count"],
            "opportunity_id": j["opportunity_id"],
            # Aggregated logical-job entries (spec 151 polish) carry an
            # execution_count so the tooltip can show "ran N times".
            "execution_count": j.get("execution_count", 1),
        }
        for j in chart_jobs
    ]

    # ── Next actions - top three logical jobs (already aggregated
    # upstream in ``_aggregate_totals_and_top_jobs`` - builds keyed
    # by destination_table, consumption by normalized query_hash)
    # that have a concrete opportunity to land on. ``issue_jobs`` is
    # sorted by aggregated cost desc, so the first three with
    # ``opportunity_id`` set are the right picks.
    next_actions = [j for j in issue_jobs if j.get("opportunity_id")][:3]

    return templates.TemplateResponse(
        request,
        "dashboard/index.html",
        {
            "title": "Dashboard - Governor Audit",
            "config": config,
            "chart_jobs": chart_jobs,
            "chart_jobs_payload": chart_jobs_payload,
            "table_jobs": paged_jobs,
            "next_actions": next_actions,
            "totals": totals,
            "opportunities": opp_summary,
            "pagination": pagination,
            "sort_by": sort_by,
            "sort_dir": sort_dir,
            "scan_banner": _scan_banner_for_dashboard(scan_status, scan_detail),
            "failed_drivers": failed_drivers,
        },
    )


_FAILURES_PAGE_SIZE = 10


def _failure_hash_for_job(job) -> str:
    """Stable group key for a failed BigQueryJob row.

    Prefer ``query_hashes.normalized_literals`` (BigQuery groups
    semantically-equivalent queries), fall back to a hash of the raw
    query body for older rows that don't carry a normalized hash.
    """
    import hashlib

    qh = job.query_hashes or {}
    if isinstance(qh, dict):
        nl = qh.get("normalized_literals")
        if nl:
            return nl
    body = (job.query or "").strip()
    return "raw:" + hashlib.sha1(body.encode("utf-8")).hexdigest()[:16]


def _build_failure_groups(failed_jobs: list) -> list[dict]:
    """Aggregate failed BigQueryJob rows into per-query groups.

    Each group carries the executions count, total slot wasted, last
    error reason / message, last failed timestamp, destination, and the
    most-recent query body (so the listing can show an excerpt and the
    detail page can show the full SQL).
    """
    groups: dict[str, dict] = {}
    for job in failed_jobs:
        key = _failure_hash_for_job(job)
        if key not in groups:
            err = job.error_result if isinstance(job.error_result, dict) else {}
            destination_dataset = ""
            destination_object = ""
            if job.destination_table and "." in job.destination_table:
                parts = job.destination_table.split(".")
                if len(parts) >= 3:
                    destination_dataset = parts[1]
                    destination_object = parts[2]
                else:
                    destination_object = parts[-1]
            groups[key] = {
                "hash_key": key,
                "query": job.query or "",
                "query_excerpt": _truncate_query(job.query),
                "execution_count": 0,
                "total_slot_ms": 0,
                "last_error_reason": err.get("reason") if isinstance(err, dict) else None,
                "last_error_message": err.get("message") if isinstance(err, dict) else None,
                "last_failed_at": job.creation_time,
                "destination_table": job.destination_table or "",
                "destination_dataset": destination_dataset,
                "destination_object": destination_object,
                "user_email": job.user_email or "",
            }
        g = groups[key]
        g["execution_count"] += 1
        g["total_slot_ms"] += job.total_slot_ms or 0
    return list(groups.values())


def _normalise_failure_sort(sort: str | None, direction: str | None) -> tuple[str, str]:
    """Mirror the opportunities table's sort keys so the vendored
    ``failures/_table.html`` (a copy of opportunities/_table.html) can
    drop in unchanged. Default sort: most-failing query first."""
    allowed = {
        "dataset", "table", "author", "reason", "workload",
        "slot", "occurrence", "age", "suggestions",
    }
    sort_by = sort if sort in allowed else "occurrence"
    sort_dir = direction if direction in {"asc", "desc"} else "desc"
    return sort_by, sort_dir


def _apply_failure_sort(rows: list[dict], sort_by: str, sort_dir: str) -> list[dict]:
    """Sort opportunity-shaped failure rows by the same column keys
    the failures table emits (mirrors opportunities' sort grammar)."""
    reverse = sort_dir == "desc"
    keyfn = {
        "dataset": lambda r: (r.get("affected_dataset") or "").lower(),
        "table": lambda r: (r.get("affected_object") or "").lower(),
        "author": lambda r: (r.get("author_email") or "").lower(),
        "reason": lambda r: (r.get("last_error_reason") or "").lower(),
        "workload": lambda r: (r.get("query_workload_kind") or "").lower(),
        "slot": lambda r: r.get("slot_wasted_ms") or 0,
        "occurrence": lambda r: r.get("occurrence_count") or 0,
        "age": lambda r: r.get("last_detected_at") or 0,
        "suggestions": lambda r: r.get("table_suggestion_count") or 0,
    }[sort_by]
    return sorted(rows, key=keyfn, reverse=reverse)


@router.get("/failures", response_class=HTMLResponse)
def failures_index(
    request: Request,
    page: int = 1,
    sort: str | None = None,
    direction: str | None = None,
    search: str | None = None,
    dataset: str | None = None,
    author: str | None = None,
    reason: str | None = None,
    suggestions: str | None = None,
):
    """Spec 149 - list every failed query in the scan window, grouped
    by its ``query_hashes.normalized_literals`` so 100 executions of the
    same broken model surface as one row. Filterable by dataset / author
    / error reason / free-text search; click-to-sort columns; paginated.
    """
    from governor_audit.scan.categorization import is_failed_job
    from governor_audit.web.routes.opportunities import AuditPaginationContext
    from governor_core.sync.models import BigQueryJob

    templates = request.app.state.templates
    try:
        config = load_config()
    except ConfigNotFoundError:
        return RedirectResponse(url="/setup", status_code=303)

    from governor_audit.scan.sentinels import config_id_for

    active_config_id = config_id_for(config.gcp_project_id, config.bigquery_region)

    engine = build_engine()
    create_all(engine)
    factory = make_session_factory(engine)
    with factory() as session:
        all_cached = (
            session.query(BigQueryJob)
            .filter(BigQueryJob.config_id == active_config_id)
            .order_by(desc(BigQueryJob.creation_time))
            .all()
        )
        failed_jobs = [j for j in all_cached if is_failed_job(j)]

    raw_groups = _build_failure_groups(failed_jobs)

    # Tag each group with the suggestion count (number of distinct
    # improvement rules that fired on the group's destination_table or
    # any of its job_ids).
    from governor_audit.scan.categorization import IMPROVEMENT_RULE_TYPES
    from governor_core.opportunities.models import Opportunity

    failed_jobs_by_hash: dict[str, list] = {}
    workload_kind_by_hash: dict[str, str] = {}
    for j in failed_jobs:
        h = _failure_hash_for_job(j)
        failed_jobs_by_hash.setdefault(h, []).append(j.job_id)
        if h not in workload_kind_by_hash:
            workload_kind_by_hash[h] = _classify_workload(j.query, j.statement_type)

    with factory() as session:
        improvement_opps = (
            session.query(Opportunity)
            .filter(Opportunity.config_id == active_config_id)
            .filter(Opportunity.status == "active")
            .filter(Opportunity.opportunity_type.in_(IMPROVEMENT_RULE_TYPES))
            .all()
        )
    table_suggestion_rules: dict[str, set[str]] = {}
    job_suggestion_rules: dict[str, set[str]] = {}
    for opp in improvement_opps:
        if opp.affected_table:
            table_suggestion_rules.setdefault(opp.affected_table, set()).add(opp.opportunity_type)
        for jid in opp.related_job_ids or []:
            job_suggestion_rules.setdefault(jid, set()).add(opp.opportunity_type)

    # Build opportunity-shaped row dicts so the vendored
    # opportunities/_table.html partial works without modification.
    rows: list[dict] = []
    for g in raw_groups:
        rule_set: set[str] = set()
        rule_set |= table_suggestion_rules.get(g["destination_table"], set())
        for jid in failed_jobs_by_hash.get(g["hash_key"], []):
            rule_set |= job_suggestion_rules.get(jid, set())
        rows.append(
            {
                "id": g["hash_key"],
                "affected_dataset": g["destination_dataset"],
                "affected_table": g["destination_table"],
                "affected_object": g["destination_object"],
                "author_email": g["user_email"],
                "last_error_reason": g["last_error_reason"],
                "last_error_message": g["last_error_message"],
                "query_workload_kind": workload_kind_by_hash.get(g["hash_key"], ""),
                "slot_wasted_ms": g["total_slot_ms"],
                "slot_wasted_human": _format_duration_ms(g["total_slot_ms"]),
                "occurrence_count": g["execution_count"],
                "last_detected_at": g["last_failed_at"],
                "table_suggestion_count": len(rule_set),
                "_query": g["query"],
            }
        )

    total_failures = sum(r["occurrence_count"] for r in rows)
    total_slot_ms_all = sum(r["slot_wasted_ms"] for r in rows)
    suggestions_available_count = sum(1 for r in rows if r["table_suggestion_count"] > 0)

    available_datasets = sorted({r["affected_dataset"] for r in rows if r["affected_dataset"]})
    available_authors = sorted({r["author_email"] for r in rows if r["author_email"]})
    available_reasons = sorted({r["last_error_reason"] for r in rows if r["last_error_reason"]})

    # Apply filters.
    search_q = (search or "").strip().lower()
    if search_q:
        rows = [
            r for r in rows
            if search_q in (r.get("_query") or "").lower()
            or search_q in (r["affected_table"] or "").lower()
        ]
    if dataset:
        rows = [r for r in rows if r["affected_dataset"] == dataset]
    if author:
        rows = [r for r in rows if r["author_email"] == author]
    if reason:
        rows = [r for r in rows if r["last_error_reason"] == reason]
    if suggestions == "with":
        rows = [r for r in rows if r["table_suggestion_count"] > 0]
    elif suggestions == "without":
        rows = [r for r in rows if r["table_suggestion_count"] == 0]

    sort_by, sort_dir = _normalise_failure_sort(sort, direction)
    rows = _apply_failure_sort(rows, sort_by, sort_dir)

    page = max(1, page)
    base_pairs = [
        (k, v) for k, v in [
            ("search", search or ""),
            ("dataset", dataset or ""),
            ("author", author or ""),
            ("reason", reason or ""),
            ("suggestions", suggestions or ""),
        ] if v
    ]
    pagination = AuditPaginationContext(
        page=page,
        page_size=_FAILURES_PAGE_SIZE,
        total_items=len(rows),
        base_query_pairs=base_pairs,
        sort=sort_by,
        direction=sort_dir,
    )
    if page > pagination.total_pages and pagination.total_pages > 0:
        page = pagination.total_pages
        pagination = AuditPaginationContext(
            page=page, page_size=_FAILURES_PAGE_SIZE, total_items=len(rows),
            base_query_pairs=base_pairs, sort=sort_by, direction=sort_dir,
        )

    start = (page - 1) * _FAILURES_PAGE_SIZE
    paged_rows = rows[start : start + _FAILURES_PAGE_SIZE]

    top_reason = (
        max(
            available_reasons,
            key=lambda r: sum(
                1 for row in failed_jobs
                if isinstance(row.error_result, dict) and row.error_result.get("reason") == r
            ),
        )
        if available_reasons
        else None
    )

    return templates.TemplateResponse(
        request,
        "failures/index.html",
        {
            "title": "Failures - Governor Audit",
            "config": config,
            "rows": paged_rows,
            # ``summary`` mirrors the opportunities summary shape so the
            # vendored summary cards partial works as-is. We populate
            # only the keys the failures cards reference; everything
            # else stays at falsy defaults.
            "summary": {
                "active_count": total_failures,
                "with_solutions_count": len(rows),
                "suggestions_available_count": suggestions_available_count,
                "total_slot_human": _format_duration_ms(total_slot_ms_all),
                "top_reason": top_reason,
                "clearing_count": 0,
            },
            "available_datasets": available_datasets,
            "available_authors": available_authors,
            "available_reasons": available_reasons,
            "pagination": pagination,
            "signals": {
                "search": search or "",
                "dataset": dataset or "",
                "author": author or "",
                "reason": reason or "",
                "suggestions": suggestions or "",
                "sort": sort_by,
                "direction": sort_dir,
            },
        },
    )


@router.get("/failures/{hash_key}", response_class=HTMLResponse)
def failure_detail(request: Request, hash_key: str):
    """Spec 149 - single failure group detail. Same template as
    opportunities/detail.html: breadcrumb → page header → stat strip
    → Errors observed cards → Available improvements (AST rewrites
    that fired on the failed query). Data is reshaped into the same
    ``row / issue_cards / improvements / job`` keys the vendored
    template expects.
    """
    from types import SimpleNamespace

    from governor_audit.scan.categorization import (
        IMPROVEMENT_RULE_TYPES,
        is_failed_job,
    )
    from governor_core.opportunities.models import Opportunity
    from governor_core.sync.models import BigQueryJob

    templates = request.app.state.templates
    try:
        config = load_config()
    except ConfigNotFoundError:
        return RedirectResponse(url="/setup", status_code=303)

    from governor_audit.scan.sentinels import config_id_for

    active_config_id = config_id_for(config.gcp_project_id, config.bigquery_region)

    engine = build_engine()
    create_all(engine)
    factory = make_session_factory(engine)
    with factory() as session:
        all_cached = (
            session.query(BigQueryJob)
            .filter(BigQueryJob.config_id == active_config_id)
            .order_by(desc(BigQueryJob.creation_time))
            .all()
        )
        group_jobs = [
            j for j in all_cached
            if is_failed_job(j) and _failure_hash_for_job(j) == hash_key
        ]

        if not group_jobs:
            raise HTTPException(status_code=404, detail="Failure group not found")

        head_job = group_jobs[0]

        # Pull AST improvement opportunities that fire on this failure
        # group's destination_table or any of its failed job_ids - these
        # become the "Available improvements" cards on the detail page.
        group_job_ids = {j.job_id for j in group_jobs}
        improvement_opps = (
            session.query(Opportunity)
            .filter(Opportunity.config_id == active_config_id)
            .filter(Opportunity.status == "active")
            .filter(Opportunity.opportunity_type.in_(IMPROVEMENT_RULE_TYPES))
            .all()
        )

    matching_opps = []
    seen_rule_types: set[str] = set()
    for opp in improvement_opps:
        if opp.opportunity_type in seen_rule_types:
            continue
        if opp.affected_table == head_job.destination_table or any(
            jid in group_job_ids for jid in (opp.related_job_ids or [])
        ):
            matching_opps.append(opp)
            seen_rule_types.add(opp.opportunity_type)

    # Build "improvements" list shaped like opportunities/detail.html
    # expects. Mirrors the cards-construction path in
    # web/routes/opportunities.py - pull ``_template_result`` from the
    # opportunity's evidence_snapshot, then compute diff_lines from
    # before/after content via generate_code_diff (same helper the
    # opportunities detail handler uses).
    from governor_core.utils.diff import generate_code_diff

    improvements = []
    for opp in matching_opps:
        snap = opp.evidence_snapshot or {}
        tmpl = snap.get("_template_result") or {}
        before = tmpl.get("before_content") or ""
        after = tmpl.get("after_content") or ""
        diff_lines = None
        if before and after and before != after:
            diff_lines = generate_code_diff(before, after)
        improvements.append(
            {
                "display_name": opp.opportunity_type.replace("_", " ").title(),
                "template_id": tmpl.get("template_id"),
                "explanation": tmpl.get("explanation") or opp.explanation,
                "diff_lines": diff_lines,
                "before_content": before,
                "after_content": after,
                "rollback": tmpl.get("rollback"),
                "occurrences": 1,
            }
        )

    # Build "issue_cards" - one card per distinct error reason in the
    # group. Mirrors opportunities/detail.html "Issues found" section
    # but with the error reason as the rule type and the BigQuery
    # error message as the explanation.
    seen_reasons: dict[str, dict] = {}
    for j in group_jobs:
        err = j.error_result if isinstance(j.error_result, dict) else {}
        reason = err.get("reason") if isinstance(err, dict) else None
        if not reason or reason in seen_reasons:
            continue
        seen_reasons[reason] = {
            "row": SimpleNamespace(
                opportunity_type=reason,
                explanation=err.get("message") or "",
            ),
            "rule_meta": SimpleNamespace(
                description=(
                    "BigQuery's error_result.reason classifies why the job "
                    "failed. Audit groups by it so recurring failure modes "
                    "stand out from one-off mistakes."
                )
            ),
            "template_result": None,
            "diff_lines": None,
        }
    issue_cards = list(seen_reasons.values())

    # Headline / stats. The "row" object mirrors what
    # opportunities/detail.html reads.
    destination_dataset = ""
    destination_object = ""
    if head_job.destination_table and "." in head_job.destination_table:
        parts = head_job.destination_table.split(".")
        if len(parts) >= 3:
            destination_dataset = parts[1]
            destination_object = parts[2]
        else:
            destination_object = parts[-1]

    total_slot_ms = sum(j.total_slot_ms or 0 for j in group_jobs)
    total_executions = len(group_jobs)

    row = SimpleNamespace(
        affected_table=head_job.destination_table or "",
        affected_object=destination_object,
        affected_dataset=destination_dataset,
        dbt_model_name=None,
        author_email=head_job.user_email,
        query_cost_value=0.0,
    )
    job = SimpleNamespace(
        total_bytes_processed=None,
        total_bytes_billed=None,
        total_slot_ms=total_slot_ms,
        duration_ms=None,
    )

    # Visible evidence: the freshest error_result struct, plus headline
    # numbers - populates the right-hand "Evidence" card.
    head_err = head_job.error_result if isinstance(head_job.error_result, dict) else {}
    visible_evidence = {
        "error_reason": head_err.get("reason") if isinstance(head_err, dict) else "",
        "error_message": head_err.get("message") if isinstance(head_err, dict) else "",
        "error_location": head_err.get("location") if isinstance(head_err, dict) else "",
        "executions": total_executions,
        "slot_wasted": _format_duration_ms(total_slot_ms),
        "last_failed_at": (
            head_job.creation_time.strftime("%Y-%m-%d %H:%M:%S UTC")
            if head_job.creation_time else ""
        ),
        "destination_table": head_job.destination_table or "",
    }

    # The full failed query body - surfaced in the "Original SQL" pane
    # of a synthetic improvements card if no real improvement matched,
    # so the page always shows the broken SQL.
    failed_query_body = head_job.query or ""

    return templates.TemplateResponse(
        request,
        "failures/detail.html",
        {
            "title": f"Failure detail - {head_job.destination_table or head_job.job_id}",
            "config": config,
            "row": row,
            "job": job,
            "issue_cards": issue_cards,
            "improvements": improvements,
            "chart_points_payload": None,
            "visible_evidence": visible_evidence,
            "job_lookup_sql": "",
            "failed_query_body": failed_query_body,
            "hash_key": hash_key,
        },
    )


def _truncate_query(query: str | None, *, max_chars: int = 200) -> str:
    """Compact one-line excerpt of a query for the failures table cell."""
    if not query:
        return "-"
    flat = " ".join(query.split())
    if len(flat) <= max_chars:
        return flat
    return flat[: max_chars - 1] + "…"


def _scan_banner_for_dashboard(
    scan_status: str | None, scan_detail: str | None
) -> dict | None:
    """Mirrors the banner schema from configurations.detail. Only the
    success case lands on the dashboard; the others stay on /admin/
    configurations, but we keep the mapping symmetric for safety."""
    if not scan_status:
        return None
    mapping = {
        "succeeded": ("success", "Scan succeeded."),
        "lock_held": ("warning", "Another scan is already running."),
        "bad_args": ("error", "Invalid scan parameters."),
        "error": ("error", "Scan failed."),
    }
    level, headline = mapping.get(scan_status, ("info", "Scan finished."))
    return {"level": level, "headline": headline, "detail": scan_detail or ""}


def _looks_like_destination_table(path: str) -> bool:
    """Cohort vs single-execution disambiguator for ``GET /jobs/{path}``.

    BigQuery destination tables are always ``project.dataset.table``
    (3 dotted segments, no colons). Job IDs always contain colons
    (``project:region.id``) and have no useful 3-dotted-segment shape.
    """
    if ":" in path:
        return False
    return len(path.split(".")) == 3


@router.get("/jobs/{job_id:path}", response_class=HTMLResponse)
def job_detail(request: Request, job_id: str):
    """Job-detail route. Two shapes share this path:

    * ``/jobs/proj.ds.table`` → **cohort view** of every cached
      execution of that destination_table. See spec 146.
    * ``/jobs/<bigquery-job-id>`` → **single-execution view** for one
      ``BigQueryJob`` row (the original behaviour).

    The shape check is deterministic - BigQuery job_ids contain ``:``
    and don't have 3 dotted segments. The cohort path falls through to
    the single-execution path when no executions are cached for the
    table (helpful for stale URLs after a project switch).

    Renders the full SQL, destination, cost, slot time, and any
    ``performance_insights`` BigQuery returned for the single-execution
    case. The job_id can contain colons (``project:region.id``) so we
    use the ``:path`` converter.
    """
    from governor_core.sync.models import BigQueryJob

    templates = request.app.state.templates
    try:
        config = load_config()
    except ConfigNotFoundError:
        return RedirectResponse(url="/setup", status_code=303)

    from governor_core.opportunities.models import Opportunity

    from governor_audit.scan.sentinels import config_id_for

    active_config_id = config_id_for(config.gcp_project_id, config.bigquery_region)

    engine = build_engine()
    create_all(engine)
    factory = make_session_factory(engine)

    # Cohort branch - try first when the path looks like a table.
    if _looks_like_destination_table(job_id):
        from governor_audit.jobs.cohort_view import build_cohort_view

        with factory() as session:
            view = build_cohort_view(
                session,
                config_id=active_config_id,
                destination_table=job_id,
                rule_overrides=dict(config.detection_rule_overrides or {}),
            )
        if view is not None:
            return templates.TemplateResponse(
                request,
                "jobs/cohort.html",
                {
                    "title": f"Job - {view.destination_table} - Governor Audit",
                    "config": config,
                    "view": view,
                },
            )
        # No cohort match - fall through to single-execution lookup.
        # Tables can't legally be valid job_ids (different shape) so the
        # fall-through will 404, but the explicit path keeps the
        # error message unified.

    with factory() as session:
        # Filter on (job_id, active config) - old jobs from previously
        # audited projects share the same SQLite cache, so we 404 them
        # rather than render foreign data when the active project no
        # longer matches.
        job = (
            session.query(BigQueryJob)
            .filter(
                BigQueryJob.job_id == job_id,
                BigQueryJob.config_id == active_config_id,
            )
            .first()
        )
        if not job:
            raise HTTPException(status_code=404, detail=f"Job {job_id} not cached")

        # Issues attached to this job: any active Opportunity whose
        # related_job_ids array contains this job_id. We hydrate in
        # Python because SQLite's JSON containment isn't portable.
        opps_for_job = []
        for opp in (
            session.query(Opportunity)
            .filter(
                Opportunity.status == "active",
                Opportunity.config_id == active_config_id,
            )
            .all()
        ):
            if job.job_id in (opp.related_job_ids or []):
                opps_for_job.append(
                    {
                        "id": opp.id,
                        "type": opp.opportunity_type,
                        "display_name": opp.opportunity_type.replace("_", " ").title(),
                        "affected_table": opp.affected_table,
                        "severity": opp.severity_score,
                        "current_cost": float(opp.current_cost_estimate or 0),
                        "explanation": opp.explanation,
                    }
                )
        opps_for_job.sort(key=lambda o: o["severity"], reverse=True)

        cost = job.total_cost or Decimal("0")
        bytes_processed = job.total_bytes_processed or 0
        bytes_billed = job.total_bytes_billed or 0
        slot_ms = job.total_slot_ms or 0
        duration_ms = job.duration_ms or 0
        qh = job.query_hashes or {}
        hash_value = qh.get("normalized_literals") if isinstance(qh, dict) else None

        ctx = {
            "job_id": job.job_id,
            "user_email": job.user_email or "-",
            "creation_time": job.creation_time,
            "start_time": job.start_time,
            "end_time": job.end_time,
            "destination_table": job.destination_table or "-",
            "destination_short": _shorten_destination(
                job.destination_table, config.gcp_project_id
            ),
            "statement_type": job.statement_type or "-",
            "workload_kind": _classify_workload(job.query, job.statement_type),
            "job_state": job.job_state,
            "job_type": job.job_type or "-",
            "cache_hit": bool(job.cache_hit),
            "query": job.query or "",
            "cost_usd": float(cost),
            "bytes_processed": bytes_processed,
            "bytes_billed": bytes_billed,
            "slot_time_ms": slot_ms,
            "duration_ms": duration_ms,
            "referenced_tables": job.referenced_tables or [],
            "performance_insights": job.performance_insights or {},
            "query_hash": hash_value,
            "is_dbt_originated": _is_dbt_originated(job.query),
        }

        # Cost-trend chart + cohort aggregates for the destination table.
        # The chart shows every cached execution of the same table so
        # users get context even when this specific job didn't trip any
        # rule. Issue days are coloured red based on the union of
        # ``related_job_ids`` across every active opportunity on the
        # table (which may be empty for clean jobs).
        #
        # The aggregates + latest_execution power the 6-card stat strip
        # (mirrors the opportunity detail page): aggregated cost / bytes
        # / slot-hours across every cached execution of the table, plus
        # the most-recent execution's cost / bytes / slot-hours so users
        # can compare the freshest point against the lifetime view.
        from governor_audit.jobs.cohort_view import build_chart_points_payload
        from sqlalchemy import func

        chart_points_payload: list[dict] = []
        cohort_aggregates: dict | None = None
        latest_execution: dict | None = None
        if job.destination_table:
            table_issue_job_ids: set[str] = set()
            for opp in (
                session.query(Opportunity)
                .filter(
                    Opportunity.status == "active",
                    Opportunity.config_id == active_config_id,
                    Opportunity.affected_table == job.destination_table,
                )
                .all()
            ):
                for jid in (opp.related_job_ids or []):
                    table_issue_job_ids.add(jid)

            chart_points_payload = build_chart_points_payload(
                session,
                config_id=active_config_id,
                destination_table=job.destination_table,
                issue_job_ids=table_issue_job_ids,
            )

            # Cohort aggregates - one query, three SUMs + a COUNT.
            agg_row = (
                session.query(
                    func.sum(BigQueryJob.total_cost).label("total_cost"),
                    func.sum(BigQueryJob.total_bytes_processed).label("total_bytes"),
                    func.sum(BigQueryJob.total_slot_ms).label("total_slot_ms"),
                    func.count(BigQueryJob.id).label("execution_count"),
                )
                .filter(
                    BigQueryJob.config_id == active_config_id,
                    BigQueryJob.destination_table == job.destination_table,
                )
                .one()
            )
            cohort_aggregates = {
                "cost_usd": float(agg_row.total_cost or 0),
                "bytes_processed": int(agg_row.total_bytes or 0),
                "slot_time_ms": int(agg_row.total_slot_ms or 0),
                "execution_count": int(agg_row.execution_count or 0),
            }

            # Latest execution - most recent creation_time for the table.
            latest = (
                session.query(BigQueryJob)
                .filter(
                    BigQueryJob.config_id == active_config_id,
                    BigQueryJob.destination_table == job.destination_table,
                )
                .order_by(BigQueryJob.creation_time.desc())
                .first()
            )
            if latest is not None:
                latest_execution = {
                    "job_id": latest.job_id,
                    "creation_time": latest.creation_time,
                    "cost_usd": float(latest.total_cost or 0),
                    "bytes_processed": int(latest.total_bytes_processed or 0)
                    if latest.total_bytes_processed is not None
                    else None,
                    "bytes_billed": int(latest.total_bytes_billed or 0)
                    if latest.total_bytes_billed is not None
                    else None,
                    "slot_time_ms": int(latest.total_slot_ms or 0)
                    if latest.total_slot_ms is not None
                    else None,
                    "duration_ms": int(latest.duration_ms or 0)
                    if latest.duration_ms is not None
                    else None,
                }

    return templates.TemplateResponse(
        request,
        "dashboard/job_detail.html",
        {
            "title": f"Job - {ctx['destination_table']}",
            "config": config,
            "job": ctx,
            "issues": opps_for_job,
            "chart_points_payload": chart_points_payload,
            "cohort_aggregates": cohort_aggregates,
            "latest_execution": latest_execution,
        },
    )


# /opportunities lives in packages/audit/src/governor_audit/web/routes/
# opportunities.py (spec 142) - kept here previously as a stub.
