"""GET /chat - chat page (configured + empty states).
POST /chat/turn - SSE stream of one turn's events.

The chat page is gated on ``config.llm.api_key`` being set. Without
a key, the page renders an empty state that links to the existing
``/admin/settings/llm`` page (FR-001). With a key, the page renders
a streamed chat backed by the user's configured provider.
"""

from __future__ import annotations

import logging

from fastapi import APIRouter, Request
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse
from sse_starlette.sse import EventSourceResponse

from governor_audit.chat import session_ledger
from governor_audit.chat.service import run_turn
from governor_audit.chat.transcript import ChatTurnRequest
from governor_audit.config.loader import ConfigNotFoundError, load_config

logger = logging.getLogger("governor_audit.web.chat")
router = APIRouter()


def _key_configured(config) -> bool:
    """The chat surface is enabled iff a non-empty API key is on the
    persisted LLM config."""
    return bool((config.llm.api_key or "").strip())


@router.get("/chat", response_class=HTMLResponse)
def chat_index(request: Request):
    """Render the chat page.

    Empty state when no LLM key configured - chat input is NOT rendered
    and no outbound call is possible (FR-001). Configured state renders
    the streaming UI.
    """
    try:
        config = load_config()
    except ConfigNotFoundError:
        return RedirectResponse(url="/setup", status_code=303)

    key_configured = _key_configured(config)
    scan_summary = _scan_summary_line()

    return request.app.state.templates.TemplateResponse(
        request,
        "chat/index.html",
        {
            "title": "Audit AI - Governor Audit",
            "config": config,
            "key_configured": key_configured,
            "provider": (config.llm.provider or "gemini").lower(),
            "model": config.llm.model,
            "chat_session_cap_usd": float(
                getattr(config.llm, "chat_session_cap_usd", 1.0) or 0.0
            ),
            "scan_status_summary": scan_summary,
        },
    )


@router.post("/chat/turn")
async def chat_turn(request: Request):
    """Stream one chat turn as Server-Sent Events.

    Body: JSON ``ChatTurnRequest``. Stream: one ``data:`` line per
    typed event (see ``chat/events.py``). Defence-in-depth 401 when
    no key is configured.
    """
    try:
        config = load_config()
    except ConfigNotFoundError:
        return JSONResponse(
            {"error": "audit_not_initialised",
             "remediation": "Run `governor-audit init` first."},
            status_code=503,
        )

    if not _key_configured(config):
        return JSONResponse(
            {"error": "chat_disabled",
             "remediation": "Configure your LLM key at /admin/settings/llm"},
            status_code=401,
        )

    try:
        body = await request.json()
        turn_request = ChatTurnRequest.model_validate(body)
    except Exception as exc:  # noqa: BLE001
        logger.info("chat: invalid /chat/turn body: %s", exc)
        return JSONResponse(
            {"error": "invalid_request",
             "remediation": f"Request body validation failed: {exc!s}"[:200]},
            status_code=400,
        )

    async def event_stream():
        """Generator yielding SSE-shaped dicts."""
        try:
            async for event in run_turn(turn_request, config=config):
                yield {
                    "event": "message",
                    "data": event.model_dump_json(),
                }
        except Exception as exc:  # noqa: BLE001
            logger.exception("chat: run_turn raised at the outer boundary")
            # Best-effort terminal event for the client.
            from governor_audit.chat.events import DoneEvent

            yield {
                "event": "message",
                "data": DoneEvent(
                    finish_reason="provider_error",
                    error_message=str(exc)[:200],
                ).model_dump_json(),
            }

    return EventSourceResponse(
        event_stream(),
        # Prevent intermediaries from buffering our stream - chat
        # responsiveness depends on chunks landing as they emit.
        headers={"Cache-Control": "no-store"},
    )


@router.post("/chat/session/reset")
async def chat_session_reset(request: Request):
    """Clear the server-side cost ledger entry for a session id.

    Called when the user presses 'New chat' / 'Reset session' in the
    browser. The browser mints a fresh ``session_id`` immediately
    after invoking this, so the cap window restarts at zero. Returns
    204 unconditionally - the ledger is best-effort and the worst
    case is a stale entry that ages out of the LRU.
    """
    try:
        body = await request.json()
    except Exception:  # noqa: BLE001
        return JSONResponse(status_code=204, content=None)
    sid = (body or {}).get("session_id")
    if isinstance(sid, str) and sid:
        session_ledger.reset(sid)
    return JSONResponse(status_code=204, content=None)


def _scan_summary_line() -> str:
    """One-line scan status the chat page shows above the input so
    the user knows what data is loaded. Cheap; soft-fails to a
    generic string on any error."""
    try:
        from governor_audit.mcp.tools.scan import scan_status

        result = scan_status()
        if hasattr(result, "in_progress"):
            if result.in_progress:
                return f"Scan in progress (phase: {result.current_phase or 'starting'})."
            latest = result.latest_succeeded_scan
            if latest is None:
                return "No successful scan yet - run `governor-audit scan` first."
            try:
                stamp = latest.completed_at.strftime("%Y-%m-%d %H:%M UTC")
            except Exception:  # noqa: BLE001
                stamp = str(latest.completed_at)
            return (
                f"Latest scan: {stamp} · {latest.lookback_days}-day window · "
                f"{latest.fetched_job_count:,} jobs."
            )
        return ""
    except Exception:  # noqa: BLE001
        return ""


__all__ = ["router"]
