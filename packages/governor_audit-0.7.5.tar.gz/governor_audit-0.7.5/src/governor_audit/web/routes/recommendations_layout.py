"""GET /recommendations/layout - index of table-level layout recommendations.
GET /recommendations/layout/{table_full_name} - per-table detail.

Spec 151. Reads from ``LayoutRecommendation`` rows persisted by the
spec-151 ``layout.recommender`` at scan time. Scoped to the active
(project, region) via the audit's sentinel-config pattern.
"""

from __future__ import annotations

import logging
from typing import Annotated
from urllib.parse import unquote

from fastapi import APIRouter, Form, HTTPException, Request
from fastapi.responses import HTMLResponse, RedirectResponse
from sqlalchemy import desc

from governor_audit.config.loader import ConfigNotFoundError, load_config
from governor_audit.db.models import (
    LayoutRecommendation,
    ScanRun,
)
from governor_audit.db.session import (
    build_engine,
    create_all,
    make_session_factory,
)
from governor_audit.scan.sentinels import config_id_for

logger = logging.getLogger("governor_audit.web.recommendations_layout")
router = APIRouter()


def _load_recommendation_for_table(session, *, config_id: str, table_full_name: str):
    """Shared helper - load the latest-scan recommendation row for the
    given table or return ``None``. Used by both the detail GET and
    the deep-analysis POSTs."""
    latest_scan_id = _latest_scan_id(session, config_id=config_id)
    if latest_scan_id is None:
        return None
    return (
        session.query(LayoutRecommendation)
        .filter(
            LayoutRecommendation.scan_run_id == latest_scan_id,
            LayoutRecommendation.config_id == config_id,
            LayoutRecommendation.table_full_name == table_full_name,
        )
        .first()
    )


def _validate_table_full_name(raw: str) -> str:
    """Decode + validate the URL-encoded ``project.dataset.table`` path
    segment. Raises 400 on anything that doesn't parse cleanly - we
    use this against attempts to inject SQL via the path."""
    decoded = unquote(raw or "")
    parts = decoded.split(".")
    if len(parts) != 3 or not all(parts):
        raise HTTPException(
            status_code=400,
            detail=(
                "Table identifier must be 'project.dataset.table' - "
                f"got {decoded!r}"
            ),
        )
    for part in parts:
        # BigQuery identifiers: letters, digits, underscore, hyphen.
        if not all(ch.isalnum() or ch in "_-" for ch in part):
            raise HTTPException(
                status_code=400,
                detail=f"Invalid character in table identifier: {part!r}",
            )
    return decoded


def _latest_scan_id(session, *, config_id: str) -> str | None:
    """Return the id of the most-recent successful scan for the
    config, or None when no successful scan exists yet."""
    row = (
        session.query(ScanRun.id)
        .filter(ScanRun.gcp_project_id.isnot(None))  # all rows have this
        .filter(ScanRun.status == "succeeded")
        .order_by(desc(ScanRun.completed_at))
        .first()
    )
    return row[0] if row else None


_LAYOUT_INDEX_PAGE_SIZE = 10


@router.get("/recommendations/layout", response_class=HTMLResponse)
def layout_index(request: Request, page: int = 1):
    try:
        config = load_config()
    except ConfigNotFoundError:
        return RedirectResponse(url="/setup", status_code=303)

    from governor_core.utils.pagination import PaginationContext

    active_config_id = config_id_for(config.gcp_project_id, config.bigquery_region)

    engine = build_engine()
    create_all(engine)
    factory = make_session_factory(engine)
    with factory() as session:
        scan_id = _latest_scan_id(session, config_id=active_config_id)
        recommendations = []
        if scan_id is not None:
            recommendations = (
                session.query(LayoutRecommendation)
                .filter(
                    LayoutRecommendation.scan_run_id == scan_id,
                    LayoutRecommendation.config_id == active_config_id,
                )
                .order_by(
                    desc(LayoutRecommendation.table_total_cost_in_window_usd),
                )
                .all()
            )
        # Eager-load cluster picks for the chip lists on each row.
        # The relationship's ordering puts cluster_rank ascending first,
        # so we can take the first 4 rows with non-null cluster_rank
        # for display.
        rec_views = []
        for rec in recommendations:
            cluster_picks = [
                c.column_name for c in rec.candidates
                if c.cluster_rank is not None
            ][:4]
            rec_views.append({
                "id": rec.id,
                "table_full_name": rec.table_full_name,
                "recommended_partition_column": rec.recommended_partition_column,
                "is_currently_partitioned": rec.table_is_currently_partitioned,
                "cluster_picks": cluster_picks,
                "table_total_bytes": rec.table_total_bytes,
                "table_total_cost_in_window_usd": rec.table_total_cost_in_window_usd,
                "contributing_job_count": rec.contributing_job_count,
                "caveat_count": len(rec.caveats or []),
            })

    # Slice + paginate the in-memory ranked list. Recommendation rows
    # are bounded per scan (typically tens, not thousands) so loading
    # everything and paginating in Python is cheaper than re-ranking
    # via SQL.
    page = max(1, page)
    pagination = PaginationContext(
        page=page,
        page_size=_LAYOUT_INDEX_PAGE_SIZE,
        total_items=len(rec_views),
    )
    if page > pagination.total_pages and pagination.total_pages > 0:
        page = pagination.total_pages
        pagination = PaginationContext(
            page=page,
            page_size=_LAYOUT_INDEX_PAGE_SIZE,
            total_items=len(rec_views),
        )
    start = (page - 1) * _LAYOUT_INDEX_PAGE_SIZE
    paged = rec_views[start : start + _LAYOUT_INDEX_PAGE_SIZE]

    return request.app.state.templates.TemplateResponse(
        request,
        "recommendations/layout_index.html",
        {
            "title": "Partition & Cluster - Governor Audit",
            "config": config,
            "recommendations": paged,
            "pagination": pagination,
            "has_latest_scan": scan_id is not None,
        },
    )


@router.get(
    "/recommendations/layout/{table_full_name:path}",
    response_class=HTMLResponse,
)
def layout_detail(request: Request, table_full_name: str):
    try:
        config = load_config()
    except ConfigNotFoundError:
        return RedirectResponse(url="/setup", status_code=303)

    decoded = _validate_table_full_name(table_full_name)
    active_config_id = config_id_for(config.gcp_project_id, config.bigquery_region)

    engine = build_engine()
    create_all(engine)
    factory = make_session_factory(engine)
    with factory() as session:
        scan_id = _latest_scan_id(session, config_id=active_config_id)
        rec = None
        if scan_id is not None:
            rec = (
                session.query(LayoutRecommendation)
                .filter(
                    LayoutRecommendation.scan_run_id == scan_id,
                    LayoutRecommendation.config_id == active_config_id,
                    LayoutRecommendation.table_full_name == decoded,
                )
                .first()
            )
        if rec is None:
            # Empty-state - not a 404. Table may have fallen out of the
            # candidate set on the latest scan (size below threshold,
            # signal too sparse, etc.) - explain and offer a re-scan.
            return request.app.state.templates.TemplateResponse(
                request,
                "recommendations/layout_detail.html",
                {
                    "title": (
                        f"Partition & Cluster - {decoded} - Governor Audit"
                    ),
                    "config": config,
                    "table_full_name": decoded,
                    "recommendation": None,
                    "candidates": [],
                    "has_latest_scan": scan_id is not None,
                },
            )

        candidates = list(rec.candidates)
        partition_candidate = next(
            (c for c in candidates if c.is_partition_pick), None
        )
        cluster_candidates = sorted(
            (c for c in candidates if c.cluster_rank is not None),
            key=lambda c: c.cluster_rank,
        )
        other_candidates = sorted(
            (c for c in candidates
             if not c.is_partition_pick and c.cluster_rank is None),
            key=lambda c: c.score,
            reverse=True,
        )
        # US2 second opinion - relationship is configured as a single
        # backref; ``rec.bq_second_opinion`` is a list because SA
        # backref defaults to one-to-many. Take the first (we wrote
        # at most one via the UNIQUE constraint on recommendation_id).
        bq_op_list = getattr(rec, "bq_second_opinion", None) or []
        bq_op = bq_op_list[0] if bq_op_list else None

        # US3 - list of cached deep-analysis results keyed by column.
        deep_list = getattr(rec, "deep_analysis_results", None) or []
        deep_results_by_column = {d.column_name: d for d in deep_list}

        # Audit-H8: re-order cluster columns by selectivity when deep-
        # analysis data is available. BigQuery clustering is order-
        # sensitive: the leading cluster column drives the most
        # pruning, and higher-cardinality columns prune harder.
        # Scan-time scoring is cost-weighted (no cardinality signal),
        # so once the user opts in to deep analysis for a column,
        # we surface a cardinality-aware ordering. Columns without
        # deep-analysis data keep their cost-weighted rank but sort
        # after any deep-analysed ones (so the page never re-ranks
        # silently below another cluster pick).
        # Audit-H9: if deep-analysis was run on the partition column
        # and the distinct-value count exceeds BigQuery's 4000-partition
        # cap, prepend a hard warning caveat for THIS render only.
        # We expunge the recommendation from the session right after,
        # so the in-place mutation of ``caveats`` doesn't persist.
        from governor_audit.layout.caveats import _BQ_PARTITION_CAP

        render_caveats = list(rec.caveats or [])
        if (
            partition_candidate is not None
            and deep_results_by_column.get(partition_candidate.column_name) is not None
        ):
            deep = deep_results_by_column[partition_candidate.column_name]
            if int(deep.approx_distinct_count or 0) > _BQ_PARTITION_CAP:
                render_caveats = [{
                    "code": "PARTITION_CARDINALITY_EXCEEDED",
                    "message": (
                        f"Deep analysis measured ~{deep.approx_distinct_count:,} "
                        f"distinct values in `{partition_candidate.column_name}`. "
                        f"BigQuery caps partitions at {_BQ_PARTITION_CAP:,} per "
                        "table - the CREATE TABLE in apply Step 2 WILL FAIL. "
                        "Consider partitioning on a coarser column (year / "
                        "month bucket) or running INGESTION_TIME partitioning "
                        "instead."
                    ),
                }, *render_caveats]

        if deep_results_by_column and len(cluster_candidates) > 1:
            def _selectivity_key(cand) -> tuple[int, int, int]:
                deep = deep_results_by_column.get(cand.column_name)
                if deep is None:
                    # Sort after deep-analysed columns; preserve
                    # original cluster_rank as tie-break.
                    return (1, 0, cand.cluster_rank or 0)
                # Higher approx_distinct_count first.
                return (
                    0,
                    -int(deep.approx_distinct_count or 0),
                    cand.cluster_rank or 0,
                )
            cluster_candidates = sorted(cluster_candidates, key=_selectivity_key)

        # Lineage view payload. Walk every cached job whose
        # ``referenced_tables`` contains the target table; aggregate
        # by the job's own ``destination_table`` so the lineage graph
        # shows one node per consumer MODEL, not one per execution.
        # Each consumer node is colored by issue/suggestion presence
        # in active opportunities for that destination, so users can
        # see at a glance which downstreams a layout change would
        # benefit (and which already have other findings).
        lineage_payload = _build_lineage_payload(
            session,
            config_id=active_config_id,
            target_table=decoded,
        )

    return request.app.state.templates.TemplateResponse(
        request,
        "recommendations/layout_detail.html",
        {
            "title": f"Partition & Cluster - {decoded} - Governor Audit",
            "config": config,
            "table_full_name": decoded,
            "recommendation": rec,
            # Render-time caveat list - includes the per-request
            # PARTITION_CARDINALITY_EXCEEDED hard warning from audit-H9
            # when deep_analysis says the partition column would bust
            # the BQ cap. The template MUST read this, not
            # ``rec.caveats``, to see the warning.
            "render_caveats": render_caveats,
            "partition_candidate": partition_candidate,
            "cluster_candidates": cluster_candidates,
            "other_candidates": other_candidates,
            "candidates": candidates,
            "bq_second_opinion": bq_op,
            "deep_results_by_column": deep_results_by_column,
            "has_latest_scan": True,
            "lineage_payload": lineage_payload,
        },
    )


def _build_lineage_payload(
    session, *, config_id: str, target_table: str
) -> dict:
    """Return an ECharts-friendly graph payload describing the target
    table and its downstream consumers.

    Schema::

      {
        "target": "proj.ds.tbl",
        "nodes": [
          {"id": ..., "label": ..., "kind": "target"|"consumer",
           "issue_count": N, "suggestion_count": N,
           "category": "target"|"clean"|"suggestion"|"issue",
           "execution_count": N, "total_cost_usd": float},
          ...
        ],
        "edges": [{"source": <consumer>, "target": <target>}, ...]
      }

    The graph is consumer → target (data-flow direction: the consumer
    reads FROM the target), which matches the dbt-style "downstream
    dependencies" mental model the user asked for.
    """
    from governor_audit.web.routes.findings import (
        _latest_version_cohort_job_ids,
    )
    from governor_audit.web.routes.opportunities import _ref_to_fq
    from governor_core.opportunities.models import Opportunity
    from governor_core.sync.models import BigQueryJob

    # All consumer jobs of the target, restricted to the latest-version
    # cohort so stale-version consumers don't pull the graph toward
    # downstreams that have since been refactored.
    all_consumer_candidates = (
        session.query(BigQueryJob)
        .filter(
            BigQueryJob.config_id == config_id,
            BigQueryJob.referenced_tables.isnot(None),
        )
        .all()
    )
    latest_cohort = _latest_version_cohort_job_ids(all_consumer_candidates)
    consumers_of_target: list[BigQueryJob] = []
    for j in all_consumer_candidates:
        if j.job_id not in latest_cohort:
            continue
        for ref in (j.referenced_tables or []):
            if _ref_to_fq(ref) == target_table:
                consumers_of_target.append(j)
                break

    # Bucket consumers by their own destination_table (the consumer
    # MODEL). Jobs without a destination (true SELECT consumption) go
    # under a synthetic "ad-hoc / BI" bucket per query_hash so they
    # don't all merge into a single node.
    from collections import defaultdict
    from decimal import Decimal

    by_dest: dict[str, dict] = defaultdict(
        lambda: {
            "execution_count": 0,
            "total_cost_usd": Decimal("0"),
        }
    )
    for j in consumers_of_target:
        dest = j.destination_table or f"ad-hoc:{j.job_id[:8]}"
        by_dest[dest]["execution_count"] += 1
        by_dest[dest]["total_cost_usd"] += j.total_cost or Decimal("0")

    # Issue / suggestion counts per consumer destination (active opps
    # only). Same ISSUE_RULE_TYPES set the dashboard uses.
    from governor_audit.scan.categorization import ISSUE_RULE_TYPES

    opps = (
        session.query(Opportunity)
        .filter(
            Opportunity.config_id == config_id,
            Opportunity.status == "active",
            Opportunity.opportunity_type != "storage_billing_optimization",
        )
        .all()
    )
    issue_by_table: dict[str, int] = defaultdict(int)
    sug_by_table: dict[str, int] = defaultdict(int)
    for opp in opps:
        if not opp.affected_table:
            continue
        if opp.opportunity_type in ISSUE_RULE_TYPES:
            issue_by_table[opp.affected_table] += 1
        else:
            sug_by_table[opp.affected_table] += 1

    def _category(dest: str) -> str:
        if issue_by_table.get(dest):
            return "issue"
        if sug_by_table.get(dest):
            return "suggestion"
        return "clean"

    # Build full per-target view first, then filter to keep only the
    # target itself + consumers with active issues. The user wants the
    # graph to highlight where a layout change is most likely to help -
    # clean / suggestion-only consumers don't add signal to that
    # decision and just clutter the view.
    target_node = {
        "id": target_table,
        "label": target_table.split(".")[-1],
        "kind": "target",
        "category": "target",
        "issue_count": issue_by_table.get(target_table, 0),
        "suggestion_count": sug_by_table.get(target_table, 0),
        "execution_count": 0,
        "total_cost_usd": 0.0,
    }
    nodes: list[dict] = [target_node]
    edges: list[dict] = []
    for dest, stats in sorted(
        by_dest.items(),
        key=lambda kv: kv[1]["total_cost_usd"],
        reverse=True,
    ):
        if issue_by_table.get(dest, 0) == 0:
            continue  # only surface consumers with active issues
        nodes.append(
            {
                "id": dest,
                "label": dest.split(".")[-1] if "." in dest else dest,
                "kind": "consumer",
                "category": "issue",
                "issue_count": issue_by_table.get(dest, 0),
                "suggestion_count": sug_by_table.get(dest, 0),
                "execution_count": stats["execution_count"],
                "total_cost_usd": float(stats["total_cost_usd"]),
            }
        )
        edges.append({"source": dest, "target": target_table})

    return {"target": target_table, "nodes": nodes, "edges": edges}


@router.post(
    "/recommendations/layout/{table_full_name:path}/deep/preview",
    response_class=HTMLResponse,
)
def deep_preview(
    request: Request,
    table_full_name: str,
    column_name: Annotated[str, Form()],
):
    """US3 - dry-run the deep-analysis queries + render a confirm
    panel showing the BigQuery cost estimate. Zero chargeable BQ
    work happens here (FR-007)."""
    try:
        config = load_config()
    except ConfigNotFoundError:
        return RedirectResponse(url="/setup", status_code=303)

    decoded = _validate_table_full_name(table_full_name)
    active_config_id = config_id_for(config.gcp_project_id, config.bigquery_region)

    engine = build_engine()
    create_all(engine)
    factory = make_session_factory(engine)
    with factory() as session:
        rec = _load_recommendation_for_table(
            session,
            config_id=active_config_id,
            table_full_name=decoded,
        )
        if rec is None:
            raise HTTPException(
                status_code=404,
                detail="No recommendation found for this table in the latest scan",
            )
        # Verify column is in the candidate set BEFORE we touch BQ.
        if not any(c.column_name == column_name for c in rec.candidates):
            raise HTTPException(
                status_code=400,
                detail=(
                    f"Column {column_name!r} is not in the candidate set "
                    f"for {decoded}"
                ),
            )

        # Spec 150 - billing_project_id MUST flow through.
        from governor_audit.layout.deep_analysis import preview
        from governor_audit.scan.bigquery_client import build_default_client

        bq_client = build_default_client(
            project_id=config.gcp_project_id,
            region=config.bigquery_region,
            billing_project_id=config.billing_project_id,
        )
        try:
            preview_result = preview(
                bq_client=bq_client,
                recommendation=rec,
                column_name=column_name,
            )
        except Exception as exc:  # noqa: BLE001
            logger.exception(
                "deep_preview failed table=%s column=%s",
                decoded, column_name,
            )
            return request.app.state.templates.TemplateResponse(
                request,
                "recommendations/_deep_preview.html",
                {
                    "error": (
                        "Failed to estimate cost - BigQuery rejected the "
                        f"dry-run with: {str(exc)[:200]}"
                    ),
                    "table_full_name": decoded,
                    "column_name": column_name,
                },
            )

    return request.app.state.templates.TemplateResponse(
        request,
        "recommendations/_deep_preview.html",
        {
            "preview": preview_result,
            "table_full_name": decoded,
            "column_name": column_name,
        },
    )


@router.post(
    "/recommendations/layout/{table_full_name:path}/deep/run",
    response_class=HTMLResponse,
)
def deep_run(
    request: Request,
    table_full_name: str,
    column_name: Annotated[str, Form()],
    acknowledged_cost_usd: Annotated[float, Form()],
):
    """US3 - execute the chargeable deep-analysis queries after the
    user confirmed the dry-run cost. Cached results short-circuit
    re-runs within the same scan."""
    try:
        config = load_config()
    except ConfigNotFoundError:
        return RedirectResponse(url="/setup", status_code=303)

    decoded = _validate_table_full_name(table_full_name)
    active_config_id = config_id_for(config.gcp_project_id, config.bigquery_region)

    engine = build_engine()
    create_all(engine)
    factory = make_session_factory(engine)
    with factory() as session:
        rec = _load_recommendation_for_table(
            session,
            config_id=active_config_id,
            table_full_name=decoded,
        )
        if rec is None:
            raise HTTPException(
                status_code=404,
                detail="No recommendation found for this table in the latest scan",
            )

        from governor_audit.layout.deep_analysis import (
            CostDriftError,
            UnknownColumnError,
            run as deep_run_inner,
        )
        from governor_audit.scan.bigquery_client import build_default_client

        bq_client = build_default_client(
            project_id=config.gcp_project_id,
            region=config.bigquery_region,
            billing_project_id=config.billing_project_id,
        )
        try:
            outcome = deep_run_inner(
                session=session,
                bq_client=bq_client,
                recommendation=rec,
                column_name=column_name,
                acknowledged_cost_usd=acknowledged_cost_usd,
            )
            session.commit()
        except UnknownColumnError as exc:
            raise HTTPException(status_code=400, detail=str(exc))
        except CostDriftError as exc:
            # Render the preview panel again with the new estimate so the
            # user can re-confirm. A 400 keeps the cache-busting honest
            # while the panel still gives them the path forward.
            from governor_audit.layout.deep_analysis import preview

            try:
                preview_result = preview(
                    bq_client=bq_client,
                    recommendation=rec,
                    column_name=column_name,
                )
            except Exception:  # noqa: BLE001
                preview_result = None
            return request.app.state.templates.TemplateResponse(
                request,
                "recommendations/_deep_preview.html",
                {
                    "preview": preview_result,
                    "table_full_name": decoded,
                    "column_name": column_name,
                    "error": str(exc),
                },
                status_code=400,
            )
        except Exception as exc:  # noqa: BLE001
            logger.exception(
                "deep_run failed table=%s column=%s", decoded, column_name,
            )
            raise HTTPException(
                status_code=502,
                detail=f"BigQuery query failed: {str(exc)[:200]}",
            )

    return request.app.state.templates.TemplateResponse(
        request,
        "recommendations/_deep_result.html",
        {
            "outcome": outcome,
            "table_full_name": decoded,
            "column_name": column_name,
        },
    )


__all__ = ["router"]
