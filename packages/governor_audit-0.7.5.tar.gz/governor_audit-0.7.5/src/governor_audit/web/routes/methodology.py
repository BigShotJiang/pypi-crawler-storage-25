"""GET /methodology - single-page explainer for every number the audit
surfaces. Source fields, formulas, caveats, limitations. Linked from the
sidebar so operators can audit Governor's audit. Read-only, no DB hit."""

from __future__ import annotations

from fastapi import APIRouter, Request
from fastapi.responses import HTMLResponse, RedirectResponse

from governor_audit.config.loader import ConfigNotFoundError, load_config

router = APIRouter()


@router.get("/methodology", response_class=HTMLResponse)
def methodology(request: Request):
    try:
        config = load_config()
    except ConfigNotFoundError:
        return RedirectResponse(url="/setup", status_code=303)
    return request.app.state.templates.TemplateResponse(
        request,
        "methodology.html",
        {"title": "Methodology - Governor Audit", "config": config},
    )
