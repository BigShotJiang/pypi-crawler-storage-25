"""GET /opportunities - list every active Opportunity in the local cache.
GET /opportunities/{id} - drill-down detail page.

Read-only mirror of governor-web's `/opportunities` UX, scoped to
audit's single (project, region). The list page vendors the cloud's
templates 1:1 (summary cards, filter controls, table, pagination) and
this route hydrates the data shape those templates expect:
``opportunities`` (per-row dict), ``signals`` (filter state), ``summary``
(aggregate stats), ``available_types``,
``pagination`` (with ``query_string_without_page`` /
``query_string_without_sort_or_page``), and ``local_runtime_mode=True``.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Iterable
from urllib.parse import urlencode

from fastapi import APIRouter, HTTPException, Request
from fastapi.responses import HTMLResponse, RedirectResponse
from sqlalchemy import desc

from governor_audit.config.loader import ConfigNotFoundError, load_config
from governor_audit.db.session import (
    build_engine,
    create_all,
    make_session_factory,
)
from governor_core.opportunities.catalog import get_detection_rule_catalog
from governor_core.opportunities.models import Opportunity
from governor_core.sync.models import BigQueryJob

logger = logging.getLogger("governor_audit.web.opportunities")
router = APIRouter()

_PAGE_SIZE = 10
# Default sort flipped from "savings" to "cost" in v0.0.16. Audit no
# longer displays a savings column at all (the existing governor-core
# rules emit hardcoded-percentage savings figures we refuse to surface;
# audit's own rules persist 0; only a real dry-run could justify a
# number, and audit doesn't run dry-runs).
_DEFAULT_SORT = "cost"
_DEFAULT_DIRECTION = "desc"
_VALID_SORTS = (
    "project",
    "dataset",
    "table",
    "author",
    "type",
    "workload",
    "cost",
    "age",
    "state",
    "layout",
    "suggestions",
)


# ── Pagination wrapper - adds the query_string_without_* properties the
# cloud templates use to preserve filter state across page links ────────


@dataclass
class AuditPaginationContext:
    page: int
    page_size: int
    total_items: int
    base_query_pairs: list[tuple[str, str]] = field(default_factory=list)
    sort: str | None = None
    direction: str | None = None

    @property
    def total_pages(self) -> int:
        if self.total_items == 0:
            return 1
        return (self.total_items + self.page_size - 1) // self.page_size

    @property
    def has_prev(self) -> bool:
        return self.page > 1

    @property
    def has_next(self) -> bool:
        return self.page < self.total_pages

    @property
    def start_index(self) -> int:
        if self.total_items == 0:
            return 0
        return (self.page - 1) * self.page_size + 1

    @property
    def end_index(self) -> int:
        return min(self.page * self.page_size, self.total_items)

    def page_range(self, window: int = 2) -> list[int]:
        start = max(1, self.page - window)
        end = min(self.total_pages, self.page + window)
        return list(range(start, end + 1))

    @property
    def query_string_without_page(self) -> str:
        pairs = list(self.base_query_pairs)
        if self.sort:
            pairs.append(("sort", self.sort))
        if self.direction:
            pairs.append(("direction", self.direction))
        return urlencode(pairs)

    @property
    def query_string_without_sort_or_page(self) -> str:
        return urlencode(self.base_query_pairs)


# ── Severity bucket helper ─────────────────────────────────────────────
#
# ``severity_score`` is produced by governor-core rules and is expected
# to be in [0, 100]. We clamp defensively (audit-H12) because nothing
# in audit enforces the range and a rule returning 150 or -10 would
# otherwise blow past the bucket cuts in unexpected ways.
#
# Bucket cuts (80 / 50 / 20) mirror governor-web's opportunity surface
# so a finding shown as "high" in audit matches what cloud users
# would see for the same severity_score. Asymmetric ranges (60 pts of
# critical+high, 30 pts of medium, 20 pts of low) reflect that the
# rules concentrate scores in the upper half - calibration data from
# the cloud catalog informed this split.

_SEVERITY_SCORE_MIN = 0
_SEVERITY_SCORE_MAX = 100
_BUCKET_CUT_CRITICAL = 80
_BUCKET_CUT_HIGH = 50
_BUCKET_CUT_MEDIUM = 20


def _clamp_severity_score(raw: int | float | None) -> int:
    """Defensive clamp on ``Opportunity.severity_score``. Returns an
    int in [0, 100] - never trusts the source.
    """
    if raw is None:
        return _SEVERITY_SCORE_MIN
    try:
        value = int(raw)
    except (TypeError, ValueError):
        return _SEVERITY_SCORE_MIN
    if value < _SEVERITY_SCORE_MIN:
        return _SEVERITY_SCORE_MIN
    if value > _SEVERITY_SCORE_MAX:
        return _SEVERITY_SCORE_MAX
    return value


def _severity_bucket(score: int) -> str:
    score = _clamp_severity_score(score)
    if score >= _BUCKET_CUT_CRITICAL:
        return "critical"
    if score >= _BUCKET_CUT_HIGH:
        return "high"
    if score >= _BUCKET_CUT_MEDIUM:
        return "medium"
    return "low"


_BUCKET_ORDER = {"critical": 0, "high": 1, "medium": 2, "low": 3}


# ── Workload classification ─────────────────────────────────────────────
# Reuse audit's existing manifest-free build/consumption classifier so the
# Workload column doesn't render every row as "Unclassified". The helper
# inspects the job's SQL + statement_type to decide build vs consumption.


def _workload_kind_from_job(job: BigQueryJob | None) -> str | None:
    if job is None:
        return None
    if job.workload_kind:
        return job.workload_kind
    # Fall back to live classification when the column wasn't populated
    # at scan time (rows from earlier audit versions).
    from governor_audit.web.routes.findings import _classify_workload

    kind = _classify_workload(job.query, job.statement_type)
    # Map "other" → None so the template's local_runtime_mode branch
    # renders "Unclassified" only when classification really failed.
    return kind if kind in ("build", "consumption") else None


# ── Per-row view dict - matches the cloud template's expected shape ─────


def _split_table_identifier(table: str | None) -> tuple[str, str]:
    """Return ``(dataset, object)`` from a BigQuery table identifier."""
    if not table:
        return "-", "-"
    parts = [p for p in table.split(".") if p]
    if len(parts) >= 2:
        return parts[-2], parts[-1]
    return "-", parts[0]


def _to_row(
    opp: Opportunity,
    *,
    project_name: str,
    job: BigQueryJob | None,
) -> dict[str, Any]:
    from governor_audit.scan.categorization import (
        ISSUE_RULE_TYPES,
    )

    severity = _clamp_severity_score(opp.severity_score)
    affected_dataset, affected_object = _split_table_identifier(opp.affected_table)
    # Improvements were attached at scan time under
    # ``evidence_snapshot["_improvements"]`` (deduped by rule_type
    # downstream of detection.py). Surface a count + a "has-template"
    # count so the table can show "N suggestions, K with diffs".
    improvements = (opp.evidence_snapshot or {}).get("_improvements") or []
    improvements_with_diff = sum(
        1 for imp in improvements if imp.get("template_id")
    )
    # ``is_issue`` distinguishes the five real cost / performance issue
    # rules (slot_contention, join_explosion, partition_pruning,
    # shuffle_spill, storage_billing_optimization) from the SQL-rewrite
    # suggestion rules. Improvement-only opportunities have no issue to
    # show in the listing's "Issue" column and present their own
    # template_result as a single suggestion card on the detail page.
    is_issue = opp.opportunity_type in ISSUE_RULE_TYPES
    template_result = (opp.evidence_snapshot or {}).get("_template_result") or None
    has_self_template = bool(
        template_result
        and template_result.get("before_content")
        and template_result.get("after_content")
        and template_result.get("before_content") != template_result.get("after_content")
    )
    return {
        "id": opp.id,
        "config_id": opp.config_id,
        "project_name": project_name,
        "affected_table": opp.affected_table,
        "affected_dataset": affected_dataset,
        "affected_object": opp.dbt_model_name or affected_object,
        "dbt_model_name": opp.dbt_model_name,
        "opportunity_type": opp.opportunity_type,
        "is_issue": is_issue,
        "has_self_template": has_self_template,
        "query_workload_kind": _workload_kind_from_job(job),
        "query_cost_value": float(opp.current_cost_estimate or 0),
        # Author = ``user_email`` of the first cached related job -
        # who actually ran the query that produced the row. Surfaces
        # in the listing's Author column + filter and on the detail
        # page header. ``None`` when no cached job remains for this
        # opportunity (rare: cache wipe + scan replace edge cases).
        "author_email": (job.user_email if job is not None else None),
        "improvements_count": len(improvements),
        "improvements_with_diff_count": improvements_with_diff,
        "occurrence_count": len(list(opp.related_job_ids or [])) or 1,
        "last_detected_at": opp.updated_at,
        "created_at": opp.created_at,
        "severity_score": severity,
        "severity_bucket": _severity_bucket(severity),
        "evidence_snapshot": opp.evidence_snapshot or {},
        "explanation": opp.explanation or "",
        "related_job_ids": list(opp.related_job_ids or []),
    }


# ── Summary aggregator ─────────────────────────────────────────────────


def _summary_from_rows(rows: list[dict[str, Any]]) -> dict[str, Any]:
    """Build the aggregate stats the summary cards consume.

    Cost totals dedupe by ``affected_table`` - each table's aggregated
    cost is counted ONCE regardless of how many opportunities fire on
    it. The previous shape summed per-opp rows, so a table with 3
    active findings counted its cost 3× - which is why the
    Query Cost card on /opportunities was reading 2-3× the dashboard's
    Total Spend even though both surfaces should agree on the cost
    of flagged work.
    """
    # Dedupe: one entry per ``affected_table`` (or per opp ID when the
    # row has no destination, so unrelated rows aren't merged under a
    # blank key). Each entry's cost is the table-level aggregated
    # cost - the same value the dashboard's chart / cost-drivers
    # table / Next actions card use.
    cost_by_key: dict[str, float] = {}
    workload_by_key: dict[str, str] = {}
    for r in rows:
        key = r.get("affected_table") or f"_opp:{r['id']}"
        # The aggregated cost is identical across opps that share an
        # affected_table after the listing handler's override; pick the
        # first one we see and ignore subsequent duplicates.
        cost_by_key.setdefault(key, float(r.get("query_cost_value") or 0))
        workload_by_key.setdefault(key, r.get("query_workload_kind") or "")

    total_cost = sum(cost_by_key.values())

    def _kind_total(field: str, kind: str) -> float:  # noqa: ARG001 - kept for signature
        return sum(c for k, c in cost_by_key.items() if workload_by_key.get(k) == kind)

    def _other_total(field: str) -> float:  # noqa: ARG001 - kept for signature
        return sum(
            c
            for k, c in cost_by_key.items()
            if workload_by_key.get(k) not in ("build", "consumption")
        )

    # Distinct-job + per-class metrics. The DB admin thinks in terms
    # of "how many problematic queries do I have", not "how many rule
    # firings happened". We pivot every user-facing headline to the
    # job-deduped count and keep the raw rule-firing count internal.
    #
    # ``flagged_job_count`` dedupes by ``affected_table`` (the same
    # key the dashboard's cost-drivers table uses). It pairs 1:1 with
    # the dashboard's "Flagged Jobs" stat card so the user sees the
    # same number on both surfaces.
    flagged_tables: set[str] = set()
    tables_with_issue: set[str] = set()
    tables_with_suggestion: set[str] = set()
    for r in rows:
        key = r.get("affected_table") or f"_opp:{r['id']}"
        flagged_tables.add(key)
        if r.get("is_issue"):
            tables_with_issue.add(key)
        else:
            tables_with_suggestion.add(key)

    return {
        # Raw rule-firing count - kept for internal callers + the
        # row-level table render, NOT the headline metric.
        "active_count": len(rows),
        # Headline: distinct flagged jobs (= distinct affected_tables).
        "flagged_job_count": len(flagged_tables),
        "jobs_with_issue_count": len(tables_with_issue),
        "jobs_with_suggestion_count": len(tables_with_suggestion),
        # Legacy keys kept so any stale partial doesn't crash, but
        # nothing in the audit UI reads them today.
        "issue_count": len(tables_with_issue),
        "suggestion_count": len(tables_with_suggestion),
        # Solution-readiness keys kept at 0 for any stale partial that
        # still reads them. Audit doesn't generate Solutions.
        "with_solutions_count": 0,
        "clearing_count": 0,
        "verified_count": 0,
        "collecting_count": 0,
        "total_query_cost": total_cost,
        "build_query_cost": _kind_total("query_cost_value", "build"),
        "consumption_query_cost": _kind_total("query_cost_value", "consumption"),
        "other_query_cost": _other_total("query_cost_value"),
    }


# ── Per-table aggregation ──────────────────────────────────────────────


def _aggregate_rows_by_table(
    per_opp_rows: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    """Collapse a list of one-row-per-Opportunity dicts into one row
    per ``affected_table``. Each table's representative row carries
    summary counts (``table_issue_count``, ``table_suggestion_count``,
    ``table_issue_types``) so the listing template can render
    aggregated cells without reaching back into the underlying opps.

    The representative is picked by priority: issue rows outrank
    suggestion-only rows; within a tier, higher ``query_cost_value``
    wins. The representative's metadata (author, workload, opportunity
    detail link) becomes the row's. Aggregate counts always reflect
    the full set of opps for that table regardless of which one
    became representative.
    """

    by_table: dict[str, dict[str, Any]] = {}
    issue_types_by_table: dict[str, list[str]] = {}

    def _priority(r: dict[str, Any]) -> tuple[int, float]:
        is_issue_rank = 1 if r.get("is_issue") else 0
        cost = float(r.get("query_cost_value") or 0)
        return (is_issue_rank, cost)

    for r in per_opp_rows:
        key = r.get("affected_table") or ""
        if not key:
            # No destination table → fall back to per-opp display so we
            # don't merge unrelated rows under a "" key.
            by_table[r["id"]] = {
                **r,
                "table_issue_count": 1 if r.get("is_issue") else 0,
                "table_suggestion_count": 0 if r.get("is_issue") else 1,
                "table_issue_types": [r["opportunity_type"]] if r.get("is_issue") else [],
            }
            continue

        if key not in by_table:
            by_table[key] = {**r}
            issue_types_by_table[key] = []

        rep = by_table[key]
        if _priority(r) > _priority(rep):
            # New row outranks current rep - adopt its metadata.
            by_table[key] = {**r}

        if r.get("is_issue"):
            t = r["opportunity_type"]
            if t not in issue_types_by_table[key]:
                issue_types_by_table[key].append(t)

    # Second pass: count opps per table and attach the aggregates.
    issue_count_by_table: dict[str, int] = {}
    suggestion_count_by_table: dict[str, int] = {}
    for r in per_opp_rows:
        key = r.get("affected_table") or ""
        if not key:
            continue
        if r.get("is_issue"):
            issue_count_by_table[key] = issue_count_by_table.get(key, 0) + 1
        else:
            suggestion_count_by_table[key] = suggestion_count_by_table.get(key, 0) + 1

    aggregated: list[dict[str, Any]] = []
    for key, rep in by_table.items():
        if not rep.get("affected_table"):
            aggregated.append(rep)
            continue
        rep["table_issue_count"] = issue_count_by_table.get(key, 0)
        rep["table_suggestion_count"] = suggestion_count_by_table.get(key, 0)
        rep["table_issue_types"] = issue_types_by_table.get(key, [])
        aggregated.append(rep)
    return aggregated


# ── Filtering ──────────────────────────────────────────────────────────


def _apply_filters(
    rows: list[dict[str, Any]],
    *,
    search: str,
    types: str,
    dataset: str = "",
    workload: str = "",
    suggestions: str = "",
    author: str = "",
    layout: str = "",
) -> list[dict[str, Any]]:
    """Filter the workspace's row set.

    Audit-specific simplifications vs the cloud's filter set:
    - No ``status`` - audit is read-only; every row is ``active``.
      The cloud uses status to track "PR open / merged / clearing"
      lifecycle that doesn't exist here.
    - No ``projects`` - audit is scoped to a single (project, region)
      via ``config_id_for`` at route entry; a project filter is a no-op.
    - No ``smart_view`` - severity buckets aren't well-calibrated in
      audit and there's no resolved state, so Quick Wins / Chronic /
      Unaddressed don't add signal.
    - Workload and Suggestions are binary (Build/Consumption,
      With/Without) - no Unclassified or None states.
    """
    out = rows
    if search:
        needle = search.lower()
        out = [
            r
            for r in out
            if needle in (r["affected_table"] or "").lower()
            or needle in (r["affected_dataset"] or "").lower()
            or needle in (r["affected_object"] or "").lower()
            or needle in (r["dbt_model_name"] or "").lower()
            or needle in r["opportunity_type"].lower()
        ]
    if types:
        # Match if the requested issue type appears in this table's
        # aggregated issue list. ``table_issue_types`` is populated by
        # ``_aggregate_rows_by_table``; the per-opp ``opportunity_type``
        # only reflects the representative row, which would miss
        # tables where the requested issue exists but a higher-cost
        # rule became the representative.
        out = [
            r for r in out
            if types in (r.get("table_issue_types") or [])
            or r.get("opportunity_type") == types
        ]
    if dataset:
        out = [r for r in out if (r["affected_dataset"] or "") == dataset]
    if author:
        out = [r for r in out if (r.get("author_email") or "") == author]
    if workload in ("build", "consumption"):
        out = [r for r in out if r["query_workload_kind"] == workload]
    if suggestions:
        # Use table-level aggregate counts - a table "has suggestions"
        # if any of its opportunities is suggestion-typed.
        if suggestions == "with":
            out = [r for r in out if (r.get("table_suggestion_count") or 0) > 0]
        elif suggestions == "without":
            out = [r for r in out if (r.get("table_suggestion_count") or 0) == 0]
    if layout:
        # Spec 148 - yes/no on whether a partition / cluster
        # recommendation card would render on the row's detail page.
        # The flag is set in ``_annotate_rows_with_layout_signal``
        # which runs AFTER pagination - so layout filtering happens
        # after sort + paginate. To make the filter effective, we
        # must run the annotation BEFORE filtering. The handler
        # short-circuits and skips this branch when the annotation
        # hasn't run yet (e.g. on rows that fell outside the page).
        if layout == "with":
            out = [r for r in out if r.get("has_layout_recommendation")]
        elif layout == "without":
            out = [r for r in out if not r.get("has_layout_recommendation")]
    return out


# ── Sorting ────────────────────────────────────────────────────────────


def _sort_rows(
    rows: list[dict[str, Any]], sort_by: str, direction: str
) -> list[dict[str, Any]]:
    reverse = direction == "desc"
    if sort_by == "project":

        def key(r: dict[str, Any]) -> str:
            return r["project_name"] or ""

    elif sort_by == "dataset":

        def key(r: dict[str, Any]) -> str:
            return (r["affected_dataset"] or "").lower()

    elif sort_by == "table":

        def key(r: dict[str, Any]) -> str:
            return (r["affected_object"] or r["affected_table"] or "").lower()

    elif sort_by == "author":

        def key(r: dict[str, Any]) -> str:
            return (r.get("author_email") or "").lower()

    elif sort_by == "type":

        def key(r: dict[str, Any]) -> str:
            return r["opportunity_type"]

    elif sort_by == "workload":

        def key(r: dict[str, Any]) -> str:
            return r["query_workload_kind"] or "zzz"

    elif sort_by == "cost":

        def key(r: dict[str, Any]) -> float:
            return r["query_cost_value"] or 0

    elif sort_by == "age":

        def key(r: dict[str, Any]) -> datetime:
            return r["last_detected_at"] or datetime.min

    elif sort_by == "state":
        # Cloud sorts state asc=Safe→High→Awaiting; audit's analogue
        # is severity bucket order (critical → low) - we treat
        # asc=low_severity_first, desc=critical_first.
        def key(r: dict[str, Any]) -> int:
            return _BUCKET_ORDER.get(r["severity_bucket"], 99)

        reverse = not reverse  # asc on bucket order = critical first feels wrong; flip

    elif sort_by == "layout":
        # Boolean sort: True > False. ``desc`` puts Yes rows first
        # (the recommendation-having tables - usually what you want
        # to see when sorting by this column). ``asc`` puts None
        # first.
        def key(r: dict[str, Any]) -> int:
            return 1 if r.get("has_layout_recommendation") else 0

    elif sort_by == "suggestions":
        # Numeric sort by the table's aggregated suggestion count.
        def key(r: dict[str, Any]) -> int:
            return int(r.get("table_suggestion_count") or 0)

    else:
        # Default fallback: sort by current cost.
        def key(r: dict[str, Any]) -> float:
            return r["query_cost_value"] or 0

    return sorted(rows, key=key, reverse=reverse)


# ── Routes ─────────────────────────────────────────────────────────────


@router.get("/opportunities", response_class=HTMLResponse)
def opportunities_index(
    request: Request,
    page: int = 1,
    sort: str | None = None,
    direction: str | None = None,
    search: str = "",
    types: str = "",
    dataset: str = "",
    workload: str = "",
    suggestions: str = "",
    author: str = "",
    layout: str = "",
) -> HTMLResponse:
    try:
        config = load_config()
    except ConfigNotFoundError:
        return RedirectResponse(url="/setup", status_code=303)

    sort_by = sort if sort in _VALID_SORTS else _DEFAULT_SORT
    sort_dir = direction if direction in ("asc", "desc") else _DEFAULT_DIRECTION

    # Scope to the active (project, region). The SQLite cache is shared
    # across every project ever audited; without this filter, switching
    # projects shows the previous project's findings.
    from governor_audit.scan.sentinels import config_id_for

    active_config_id = config_id_for(config.gcp_project_id, config.bigquery_region)

    engine = build_engine()
    create_all(engine)
    factory = make_session_factory(engine)
    with factory() as session:
        # Storage-billing rows live in the dashboard's Storage Optimization
        # panel and are dataset-level (not per-job), so they don't belong
        # in this query-cost-driven workspace. Every other rule type
        # (issues + improvements) is listed - improvements still ride
        # along on issue rows under ``evidence_snapshot["_improvements"]``
        # for the inline diff stack on the detail page, AND they now also
        # surface as their own rows so models with only suggestions (no
        # underlying issue) still show up in /opportunities.
        _excluded_types = ["storage_billing_optimization"]
        active_rows = (
            session.query(Opportunity)
            .filter(Opportunity.status == "active")
            .filter(Opportunity.config_id == active_config_id)
            .filter(~Opportunity.opportunity_type.in_(_excluded_types))
            .order_by(desc(Opportunity.current_cost_estimate))
            .all()
        )
        if not active_rows:
            return RedirectResponse(url="/admin/configurations", status_code=303)

        # Hydrate first related job per opportunity for workload classification.
        all_job_ids: set[str] = set()
        for opp in active_rows:
            for jid in opp.related_job_ids or []:
                all_job_ids.add(jid)
        jobs_by_id: dict[str, BigQueryJob] = {}
        if all_job_ids:
            # Chunk the IN clause so SQLite's 999-variable cap doesn't
            # bite when the workspace has thousands of opportunities
            # spanning many distinct jobs. Same reasoning as
            # ``scan/persistence.py:_chunked`` - keep the path working
            # on default SQLite builds without depending on the
            # version's exact ``SQLITE_MAX_VARIABLE_NUMBER``.
            from governor_audit.scan.persistence import (
                _SQLITE_MAX_IN_PARAMS,
                _chunked,
            )

            for batch in _chunked(list(all_job_ids), _SQLITE_MAX_IN_PARAMS):
                jobs = (
                    session.query(BigQueryJob)
                    .filter(
                        BigQueryJob.job_id.in_(batch),
                        BigQueryJob.config_id == active_config_id,
                    )
                    .all()
                )
                for j in jobs:
                    jobs_by_id[j.job_id] = j

        # Source the per-destination aggregated cost from the same
        # function the dashboard uses - ``_aggregate_totals_and_top_jobs``.
        # The previous implementation summed ``total_cost`` over jobs
        # in ``related_job_ids`` of active opps, which (a) included
        # failed jobs that the dashboard explicitly filters out via
        # ``is_failed_job`` and (b) only saw executions the detection
        # rule had captured rather than every cached execution of the
        # destination_table. The result: the same logical row showed
        # one number on the dashboard and a different number here.
        # Now both surfaces read from the same aggregator → guaranteed
        # consistency across the chart, the cost-drivers table, the
        # Next actions card, the /opportunities listing, and any
        # /opportunities/{id} detail page that falls through to this
        # row's ``query_cost_value``.
        from governor_audit.web.routes.findings import (
            _aggregate_totals_and_top_jobs,
        )

        agg_rows, _agg_totals, _agg_opp_summary = _aggregate_totals_and_top_jobs(
            session,
            top_n=10_000_000,  # effectively unbounded - we need every row
            project_id=config.gcp_project_id,
            config_id=active_config_id,
        )
        cost_by_destination: dict[str, float] = {}
        execution_count_by_destination: dict[str, int] = {}
        for r in agg_rows:
            dest = r.get("destination_table")
            if not dest or dest == "-":
                continue
            cost_by_destination[dest] = float(r.get("cost_usd") or 0)
            execution_count_by_destination[dest] = int(
                r.get("execution_count") or 0
            )

        per_opp_rows = []
        for opp in active_rows:
            row = _to_row(
                opp,
                project_name=config.gcp_project_id,
                job=next(
                    (
                        jobs_by_id[j]
                        for j in (opp.related_job_ids or [])
                        if j in jobs_by_id
                    ),
                    None,
                ),
            )
            # Override the per-opp estimate with the aggregated BQ-billed
            # cost across every flagged execution writing to this
            # destination. Falls back to the per-opp estimate when the
            # destination has no cached executions (rare - happens when
            # the cache rolled but the opportunity row is still active).
            dest = row.get("affected_table")
            if dest and dest in cost_by_destination:
                row["query_cost_value"] = cost_by_destination[dest]
                row["execution_count"] = execution_count_by_destination[dest]
            else:
                row["execution_count"] = 1
            per_opp_rows.append(row)

    # Build available filter values from the full per-opp row set.
    # Issue dropdown shows ONLY ISSUE rule types - the cost/perf signals
    # BigQuery's optimizer attaches to ``performance_insights``
    # (slot_contention, shuffle_spill, partition_pruning,
    # join_explosion). Suggestion-typed rules (select_star, dead_cte,
    # etc.) are SQL-rewrite improvements, not issues, and shouldn't
    # appear under a dropdown labelled "Issue".
    from governor_audit.scan.categorization import ISSUE_RULE_TYPES

    _present_types = {r["opportunity_type"] for r in per_opp_rows}
    available_types = sorted(
        ISSUE_RULE_TYPES & _present_types - {"storage_billing_optimization"}
    )
    available_datasets = sorted(
        {r["affected_dataset"] for r in per_opp_rows if r["affected_dataset"] and r["affected_dataset"] != "-"}
    )
    available_authors = sorted(
        {r.get("author_email") for r in per_opp_rows if r.get("author_email")}
    )

    # Aggregate per-opp rows into one row per ``affected_table``. A
    # single object can fire multiple rules (one issue + several
    # suggestions are common for dbt model rebuilds), and the listing
    # was previously emitting one row per Opportunity - so a model
    # with 4 findings showed up 4 times. Users expect one row per
    # object with summary counts; the row click goes to the cohort
    # view at /jobs/{table} for the full per-rule detail.
    rows = _aggregate_rows_by_table(per_opp_rows)

    # Summary BEFORE filters - covers the visible workspace (audit has
    # only one project so this matches the cloud's "all rows in scope").
    summary = _summary_from_rows(per_opp_rows)

    # CRITICAL: pull the headline ``flagged_job_count`` and
    # ``total_query_cost`` from the SAME aggregator the dashboard uses
    # so the two surfaces show identical numbers. The previous local
    # computation deduped by ``affected_table`` from the opportunity
    # rows, which double-counted source-table opportunities (e.g.
    # ``partition_pruning`` cites the SOURCE table, not the job's
    # destination) and missed jobs whose only flagging was an issue
    # rule that didn't carry an ``affected_table``. Reading from
    # ``agg_rows`` (jobs deduped by destination_table / query_hash,
    # filtered to those with ≥1 finding) matches the dashboard's
    # ``pagination.total_items`` 1:1. ``flagged_spend`` matches the
    # dashboard's headline ``$X optimisable spend`` 1:1.
    flagged_agg_rows = [
        r for r in agg_rows
        if (r.get("issue_count") or 0) > 0
        or (r.get("suggestion_count") or 0) > 0
    ]
    # Per-class job counts using the same source-of-truth.
    jobs_with_issue = sum(
        1 for r in flagged_agg_rows if (r.get("issue_count") or 0) > 0
    )
    jobs_with_suggestion = sum(
        1 for r in flagged_agg_rows if (r.get("suggestion_count") or 0) > 0
    )
    summary["flagged_job_count"] = len(flagged_agg_rows)
    summary["jobs_with_issue_count"] = jobs_with_issue
    summary["jobs_with_suggestion_count"] = jobs_with_suggestion
    summary["total_query_cost"] = float(_agg_totals.get("flagged_spend") or 0)
    # Clear the per-workload breakdown; it was derived from the
    # per-opp ``query_cost_value`` and no longer matches the new
    # total. The Query Cost card simply shows ``Per run`` underneath
    # when these are empty (see _summary_cards.html).
    summary["build_query_cost"] = 0.0
    summary["consumption_query_cost"] = 0.0
    summary["other_query_cost"] = 0.0

    # Spec 148 - annotate rows with ``has_layout_recommendation`` so
    # the Layout column, the Layout filter, and the layout sort all
    # see the same boolean.
    #
    # The annotation walks lineage + column-usage per target, which
    # easily runs for ~25 s on a workspace with ~100 affected tables.
    # That made /opportunities feel like a 10-second page transition.
    # Optimisation: skip the up-front bulk annotation when the user
    # isn't filtering or sorting by layout - most page loads - and
    # only annotate the 10 rows actually visible on the rendered page
    # below. Rows not annotated default to ``has_layout_recommendation
    # = False`` so the Layout column simply renders "-" for them,
    # which is the same outcome the bulk path produces for "no
    # recommendation" rows.
    layout_signal_needed_upfront = (
        bool(layout) or sort_by == "layout"
    )
    if layout_signal_needed_upfront:
        _annotate_rows_with_layout_signal(rows, config_id=active_config_id)

    # Apply filters + sort + paginate. Filters operate on the
    # aggregated rows: the per-table representative carries
    # ``table_issue_types`` / ``table_issue_count`` /
    # ``table_suggestion_count`` so issue/suggestion filters still
    # match correctly even though we collapsed multiple opps into one
    # row.
    filtered = _apply_filters(
        rows,
        search=search,
        types=types,
        dataset=dataset,
        workload=workload,
        suggestions=suggestions,
        author=author,
        layout=layout,
    )
    filtered = _sort_rows(filtered, sort_by, sort_dir)

    page = max(1, page)
    base_pairs: list[tuple[str, str]] = []
    if search:
        base_pairs.append(("search", search))
    if types:
        base_pairs.append(("types", types))
    if dataset:
        base_pairs.append(("dataset", dataset))
    if workload:
        base_pairs.append(("workload", workload))
    if suggestions:
        base_pairs.append(("suggestions", suggestions))
    if author:
        base_pairs.append(("author", author))
    if layout:
        base_pairs.append(("layout", layout))

    pagination = AuditPaginationContext(
        page=page,
        page_size=_PAGE_SIZE,
        total_items=len(filtered),
        base_query_pairs=base_pairs,
        sort=sort_by if sort_by != _DEFAULT_SORT else None,
        direction=sort_dir if sort_dir != _DEFAULT_DIRECTION else None,
    )
    if page > pagination.total_pages:
        page = pagination.total_pages
        pagination = AuditPaginationContext(
            page=page,
            page_size=_PAGE_SIZE,
            total_items=len(filtered),
            base_query_pairs=base_pairs,
            sort=sort_by if sort_by != _DEFAULT_SORT else None,
            direction=sort_dir if sort_dir != _DEFAULT_DIRECTION else None,
        )
    start = (page - 1) * _PAGE_SIZE
    paged = filtered[start : start + _PAGE_SIZE]

    # Lazy layout-signal annotation - only the visible 10 rows pay the
    # cost when the user isn't filtering / sorting by layout. The bulk
    # path above handled the layout-filter / layout-sort case; here we
    # cover plain page loads where it'd be ~25 s of wasted work.
    if not layout_signal_needed_upfront:
        _annotate_rows_with_layout_signal(paged, config_id=active_config_id)

    signals = {
        "search": search,
        "types": types,
        "dataset": dataset,
        "workload": workload,
        "suggestions": suggestions,
        "author": author,
        "layout": layout,
        "sort": sort_by,
        "direction": sort_dir,
        "page": page,
    }

    return request.app.state.templates.TemplateResponse(
        request,
        "opportunities/index.html",
        {
            "title": "Opportunities - Governor Audit",
            "opportunities": paged,
            "summary": summary,
            "signals": signals,
            "available_types": available_types,
            "available_datasets": available_datasets,
            "available_authors": available_authors,
            "pagination": pagination,
            "config": config,
        },
    )


@router.get("/opportunities/{opportunity_id}", response_class=HTMLResponse)
def opportunities_detail(request: Request, opportunity_id: str) -> HTMLResponse:
    """Object-overview detail page.

    The URL keeps the per-opportunity_id shape for backward
    compatibility with bookmarks, but the page now lists EVERY active
    finding for the requested opportunity's ``affected_table``. Users
    naturally think in terms of "what's wrong with my model" - one
    page per (rule, table) was forcing them to bounce between pages
    that mostly described the same object.
    """
    try:
        config = load_config()
    except ConfigNotFoundError:
        return RedirectResponse(url="/setup", status_code=303)

    from governor_audit.scan.sentinels import config_id_for
    from governor_core.utils.diff import generate_code_diff

    active_config_id = config_id_for(config.gcp_project_id, config.bigquery_region)

    engine = build_engine()
    create_all(engine)
    factory = make_session_factory(engine)
    with factory() as session:
        # 1. Resolve the requested opp → its affected_table.
        anchor = session.get(Opportunity, opportunity_id)
        if anchor is None or anchor.config_id != active_config_id:
            raise HTTPException(status_code=404, detail="Opportunity not found")

        affected_table = anchor.affected_table

        # 2. Fetch every active opportunity on the same table.
        #    storage_billing rows live on the dashboard panel and are
        #    dataset-level (not table-level) so they don't belong here.
        all_opps_for_table = (
            session.query(Opportunity)
            .filter(
                Opportunity.config_id == active_config_id,
                Opportunity.affected_table == affected_table,
                Opportunity.status == "active",
                Opportunity.opportunity_type != "storage_billing_optimization",
            )
            .order_by(desc(Opportunity.severity_score), desc(Opportunity.current_cost_estimate))
            .all()
        )

        # 3. Hydrate every related job for stat-strip / per-issue
        #    job-lookup SQL. Chunk the IN clause to dodge SQLite's
        #    999-variable cap.
        all_job_ids: set[str] = set()
        for o in all_opps_for_table:
            for jid in o.related_job_ids or []:
                all_job_ids.add(jid)
        jobs_by_id: dict[str, BigQueryJob] = {}
        if all_job_ids:
            from governor_audit.scan.persistence import (
                _SQLITE_MAX_IN_PARAMS,
                _chunked,
            )

            for batch in _chunked(list(all_job_ids), _SQLITE_MAX_IN_PARAMS):
                jobs = (
                    session.query(BigQueryJob)
                    .filter(
                        BigQueryJob.job_id.in_(batch),
                        BigQueryJob.config_id == active_config_id,
                    )
                    .all()
                )
                for j in jobs:
                    jobs_by_id[j.job_id] = j

        def _first_job_for(opp: Opportunity) -> BigQueryJob | None:
            for jid in opp.related_job_ids or []:
                if jid in jobs_by_id:
                    return jobs_by_id[jid]
            return None

        # Aggregated per-destination cost from the canonical dashboard
        # aggregator - so the detail page's "Cost" stat matches the
        # listing's column, the dashboard's Top Cost Drivers table, the
        # Top Spenders chart, and the Next actions card. Without this
        # the detail page shows ``opp.current_cost_estimate`` (the
        # rule-emitted per-opp number) which can diverge from the
        # actual aggregated BQ-billed cost of the destination_table.
        from governor_audit.web.routes.findings import (
            _aggregate_totals_and_top_jobs,
        )

        agg_rows, _, _ = _aggregate_totals_and_top_jobs(
            session,
            top_n=10_000_000,
            project_id=config.gcp_project_id,
            config_id=active_config_id,
        )
        agg_by_destination: dict[str, dict] = {}
        for r in agg_rows:
            dest = r.get("destination_table")
            if dest and dest != "-":
                agg_by_destination[dest] = r

        # Latest cached execution for the affected_table - powers the
        # "Last execution" row of stat cards below the aggregated ones.
        # Falls back to ``None`` when no cached execution exists (very
        # rare; the page would 404 earlier in that case).
        latest_job: BigQueryJob | None = None
        if affected_table:
            latest_job = (
                session.query(BigQueryJob)
                .filter(
                    BigQueryJob.config_id == active_config_id,
                    BigQueryJob.destination_table == affected_table,
                )
                .order_by(desc(BigQueryJob.creation_time))
                .first()
            )

        # 4. Build per-opp views (full row dict).
        def _row_for(opp: Opportunity) -> dict:
            row = _to_row(
                opp,
                project_name=config.gcp_project_id,
                job=_first_job_for(opp),
            )
            dest = row.get("affected_table")
            agg = agg_by_destination.get(dest) if dest else None
            if agg is not None:
                row["query_cost_value"] = float(agg.get("cost_usd") or 0)
                row["execution_count"] = int(agg.get("execution_count") or 0)
                # Aggregated bytes / slot-ms so the stat strip's three
                # numbers are coherent - all three are sums across the
                # logical job, not a mix of "this execution" and "all
                # executions". Listings keep using ``_to_row`` defaults
                # which pull bytes/slot from the representative job;
                # only the detail page reads these aggregated keys.
                row["aggregated_bytes_processed"] = int(
                    agg.get("bytes_processed") or 0
                )
                row["aggregated_slot_time_ms"] = int(
                    agg.get("slot_time_ms") or 0
                )
            return row

        per_opp_views = [
            (o, _first_job_for(o), _row_for(o)) for o in all_opps_for_table
        ]

        # 5. Cost-trend chart payload for the table. Union the
        # ``related_job_ids`` across every active opp on this table -
        # these are the jobs that tripped one or more detection rules.
        # The chart partial colours those days' line segments red so
        # users see at a glance which days' executions caused the
        # flagged issues (vs. days that ran clean even though the
        # opportunity is active across the cohort).
        from governor_audit.jobs.cohort_view import build_chart_points_payload

        _issue_job_ids: set[str] = set()
        for o in all_opps_for_table:
            for jid in (o.related_job_ids or []):
                _issue_job_ids.add(jid)

        chart_points_payload = (
            build_chart_points_payload(
                session,
                config_id=active_config_id,
                destination_table=affected_table,
                issue_job_ids=_issue_job_ids,
            )
            if affected_table
            else []
        )

    # ── Header / stat-strip representative ─────────────────────────
    # Use the highest-priority opp for the title pill + stat strip
    # (issues outrank suggestions; within tier, severity wins; the
    # ORDER BY above did the work). Fall back to the first per_opp_views
    # entry if filtering somehow produced empty.
    if not per_opp_views:
        raise HTTPException(status_code=404, detail="Opportunity not found")
    representative_opp, representative_job, representative_row = per_opp_views[0]

    # ── Per-issue cards ────────────────────────────────────────────
    issue_cards: list[dict[str, Any]] = []
    for o, job, row in per_opp_views:
        if not row["is_issue"]:
            continue
        rule_meta = next(
            (e for e in get_detection_rule_catalog() if e.rule_type == row["opportunity_type"]),
            None,
        )
        evidence_snapshot = row["evidence_snapshot"] or {}
        # ``_template_result`` for issues like storage_billing - most
        # issue rules don't carry their own diff. Suggestion-typed
        # rules go through the unified suggestion list below.
        tr = evidence_snapshot.get("_template_result")
        diff_lines = None
        if tr and tr.get("before_content") and tr.get("after_content") and tr["before_content"] != tr["after_content"]:
            diff_lines = generate_code_diff(tr["before_content"], tr["after_content"])
        visible_evidence = {
            k: v for k, v in evidence_snapshot.items() if not str(k).startswith("_")
        }
        job_lookup_sql = _build_job_lookup_sql(
            job, config.gcp_project_id, config.bigquery_region
        )
        issue_cards.append({
            "row": row,
            "rule_meta": rule_meta,
            "job": job,
            "job_lookup_sql": job_lookup_sql,
            "template_result": tr,
            "diff_lines": diff_lines,
            "visible_evidence": visible_evidence,
        })

    # ── Unified suggestion list ────────────────────────────────────
    # Three sources contribute to the table's full suggestion catalogue:
    #   a. Each issue opp's ``_improvements`` list (improvement
    #      candidates the detection runner attached to issues fired on
    #      the same destination table).
    #   b. Each suggestion-only opp's own ``_template_result``
    #      (suggestion rules surface as their own opp rows since
    #      v0.3.0; their template is what powers the diff card).
    #
    # We dedupe by ``rule_type`` so the user sees one card per
    # SQL-rewrite suggestion no matter how many opps surfaced it. The
    # FIRST occurrence wins so the explanation/text from the
    # representative source is what renders.
    improvement_views: list[dict[str, Any]] = []
    seen_rule_types: set[str] = set()

    def _try_add_card(card: dict[str, Any]) -> None:
        rt = card.get("rule_type")
        if not rt or rt in seen_rule_types:
            return
        seen_rule_types.add(rt)
        before = card.get("before_content")
        after = card.get("after_content")
        if before and after and before != after:
            card["diff_lines"] = generate_code_diff(before, after)
        else:
            card["diff_lines"] = None
        meta = next(
            (e for e in get_detection_rule_catalog() if e.rule_type == rt),
            None,
        )
        card["display_name"] = meta.display_name if meta else rt.replace("_", " ").title()
        improvement_views.append(card)

    for o, _, row in per_opp_views:
        evidence = row["evidence_snapshot"] or {}
        # (a) attached improvements on issue rows.
        for imp in evidence.get("_improvements") or []:
            _try_add_card(dict(imp))
        # (b) suggestion-only opp's own template promoted to a card.
        if not row["is_issue"]:
            tr = evidence.get("_template_result")
            if tr:
                _try_add_card({
                    "rule_type": row["opportunity_type"],
                    "explanation": tr.get("explanation") or row.get("explanation") or "",
                    "template_id": tr.get("template_id"),
                    "before_content": tr.get("before_content"),
                    "after_content": tr.get("after_content"),
                    "rollback": tr.get("rollback"),
                    "occurrences": 1,
                })

    # Top-level Evidence + BigQuery-query-lookup cards. These render
    # for every detail page (issue rows + suggestion-only rows) so
    # the user always has the raw evidence + a paste-able BQ console
    # query without expanding any nested collapsible. ``visible_evidence``
    # is the representative's evidence_snapshot with internal scratch
    # keys stripped (Jinja has no startswith test).
    visible_evidence = {
        k: v
        for k, v in (representative_row.get("evidence_snapshot") or {}).items()
        if not str(k).startswith("_")
    }
    job_lookup_sql = _build_job_lookup_sql(
        representative_job, config.gcp_project_id, config.bigquery_region
    )

    # ── Spec 148 - Layout recommendation card(s) ──────────────────
    # Joins three signals (lineage → column-usage → schema/storage)
    # into per-target "recommend partition by X / cluster on (Y, Z)"
    # suggestions. Read-only; never modifies SQL.
    #
    # Targets: ``affected_table`` itself + every distinct upstream
    # referenced by jobs that triggered an opportunity on the table.
    # The producer-of-affected_table jobs (in ``related_jobs``) read
    # the upstreams, so their ``referenced_tables`` is where the
    # upstream candidates come from. For ``partition_pruning`` this
    # is the right surface: the rule fires on the downstream that
    # did the bad scan, but the partition fix belongs on the
    # upstream it was reading.
    layout_recommendations = _build_layout_recommendations(
        affected_table=affected_table,
        config_id=active_config_id,
        related_jobs=list(jobs_by_id.values()),
    )

    # Spec 151 - replace the full layout-recommendation card with a
    # chip linking to the dedicated /recommendations/layout/<table>
    # page. We render one chip per target that has a persisted
    # ``LayoutRecommendation`` row in the latest scan; the in-memory
    # ``layout_recommendations`` list above is still computed for
    # backward compatibility but no longer consumed by the template.
    layout_chip_targets = _resolve_layout_chip_targets(
        affected_table=affected_table,
        config_id=active_config_id,
        related_jobs=list(jobs_by_id.values()),
    )

    return request.app.state.templates.TemplateResponse(
        request,
        "opportunities/detail.html",
        {
            "title": "Opportunity - Governor Audit",
            # Header / stat-strip representative.
            "row": representative_row,
            "job": representative_job,
            # Latest cached execution of the affected_table - powers
            # the "Last execution" row of stat cards on the detail page.
            "latest_job": latest_job,
            # Per-issue cards (one per issue rule that fired on this table).
            "issue_cards": issue_cards,
            # Unified suggestions list across every opp on this table.
            "improvements": improvement_views,
            # Cost-trend chart for the table.
            "chart_points_payload": chart_points_payload,
            # Top-level evidence + BigQuery query lookup (representative).
            "visible_evidence": visible_evidence,
            "job_lookup_sql": job_lookup_sql,
            # Spec 148 layout recommendations - kept for any inline
            # template references that haven't migrated yet. Spec 151
            # template ignores this and uses ``layout_chip_targets``
            # below instead.
            "layout_recommendations": layout_recommendations,
            # Spec 151 - list of fully-qualified table names that have
            # a persisted LayoutRecommendation row in the latest scan.
            # Template renders one chip per entry linking to the
            # dedicated /recommendations/layout/<table> page.
            "layout_chip_targets": layout_chip_targets,
        },
    )


def _resolve_layout_chip_targets(
    *,
    affected_table: str,
    config_id: str,
    related_jobs: "list[BigQueryJob]",
) -> list[str]:
    """Spec 151 - return the targets that have a persisted
    ``LayoutRecommendation`` row in the latest successful scan.

    Same target set as the spec-148 ``_build_layout_recommendations``
    (the affected table plus every distinct upstream referenced by
    producer jobs), filtered to those that actually have a
    persisted recommendation. Soft-fails to empty list on any error
    so the detail page never breaks because of layout lookup.
    """
    try:
        from governor_audit.db.models import LayoutRecommendation, ScanRun

        engine = build_engine()
        create_all(engine)
        factory = make_session_factory(engine)
        with factory() as session:
            latest_scan_id_row = (
                session.query(ScanRun.id)
                .filter(ScanRun.status == "succeeded")
                .order_by(desc(ScanRun.completed_at))
                .first()
            )
            if latest_scan_id_row is None:
                return []
            latest_scan_id = latest_scan_id_row[0]
            target_candidates = _select_recommendation_targets(
                affected_table, related_jobs
            )
            if not target_candidates:
                return []
            persisted_targets = (
                session.query(LayoutRecommendation.table_full_name)
                .filter(
                    LayoutRecommendation.scan_run_id == latest_scan_id,
                    LayoutRecommendation.config_id == config_id,
                    LayoutRecommendation.table_full_name.in_(target_candidates),
                )
                .all()
            )
            return sorted({row[0] for row in persisted_targets})
    except Exception:  # noqa: BLE001
        logger.exception(
            "layout chip resolution failed for %s - opportunity detail "
            "renders without the layout chip",
            affected_table,
        )
        return []


def _annotate_rows_with_layout_signal(
    rows: "list[dict[str, Any]]", *, config_id: str
) -> None:
    """In-place annotate ``rows`` with ``has_layout_recommendation:
    bool`` so the listing's Layout column can render Yes / None.

    Computed at listing render time but with aggressive sharing
    across rows: one DB query per page (not per row), pre-resolved
    referenced_tables lookup, schema/storage caches keyed on the
    target table identifier (multiple rows often share an upstream
    target - a partition_pruning row's upstream is also the upstream
    of any other downstream that reads the same source).

    Bounded by ``len(rows)`` (the visible page, default 10) so the
    listing's wall-time impact is small even on large audit caches.
    Wrapped in a try/except so any failure leaves the flag unset
    (template renders "-") rather than 500-ing the listing.
    """
    if not rows:
        return

    try:
        from governor_audit.lineage.column_usage import analyse_column_usage
        from governor_audit.lineage.recommendations import build_recommendation
        from governor_core.sync.models import (
            BigQueryJob,
            TableColumnMetadata,
            TableStorageMetric,
        )

        # Default every row to False so the template always has a
        # value to read; flip to True below as we find recommendations.
        for row in rows:
            row.setdefault("has_layout_recommendation", False)

        engine = build_engine()
        create_all(engine)
        factory = make_session_factory(engine)
        with factory() as session:
            # Single load of all jobs in this config that have any
            # referenced_tables - these are the candidate consumers
            # for every target table.
            all_consumer_candidates = (
                session.query(BigQueryJob)
                .filter(
                    BigQueryJob.config_id == config_id,
                    BigQueryJob.referenced_tables.isnot(None),
                )
                .all()
            )

            # Phase-2 latest-version filter: a consumer counts only when
            # it's running its own destination's latest deployed version
            # (or has no destination - true consumption query). Stale
            # versions of a downstream model would otherwise pull the
            # partition / cluster pick toward the columns its OLDER SQL
            # filtered on, even after a refactor changed the access
            # pattern. Mirrors the unit-of-analysis the dashboard uses.
            from governor_audit.web.routes.findings import (
                _latest_version_cohort_job_ids,
            )

            latest_cohort = _latest_version_cohort_job_ids(all_consumer_candidates)
            all_consumer_candidates = [
                j for j in all_consumer_candidates if j.job_id in latest_cohort
            ]

            # Pre-resolve referenced_tables once so per-target lookups
            # are O(1). Also build destination → producer map so we
            # can find the upstream candidates per row.
            jobs_by_referenced_table: dict[str, list[BigQueryJob]] = {}
            jobs_by_destination: dict[str, list[BigQueryJob]] = {}
            for j in all_consumer_candidates:
                if j.destination_table:
                    jobs_by_destination.setdefault(
                        j.destination_table, []
                    ).append(j)
                seen: set[str] = set()
                for ref in (j.referenced_tables or []):
                    fq = _ref_to_fq(ref)
                    if fq is not None and fq not in seen:
                        seen.add(fq)
                        jobs_by_referenced_table.setdefault(fq, []).append(j)

            # Per-target caches reused across rows - multiple rows
            # often share an upstream target.
            schema_cache: dict[str, list] = {}
            storage_cache: dict[str, object] = {}
            target_has_rec_cache: dict[str, bool] = {}

            def _schema_storage(target: str):
                if target in schema_cache:
                    return schema_cache[target], storage_cache[target]
                parts = target.split(".")
                if len(parts) != 3:
                    schema_cache[target] = []
                    storage_cache[target] = None
                    return [], None
                _proj, dataset, table = parts
                schema = (
                    session.query(TableColumnMetadata)
                    .filter(
                        TableColumnMetadata.config_id == config_id,
                        TableColumnMetadata.dataset_name == dataset,
                        TableColumnMetadata.table_name == table,
                    )
                    .all()
                )
                storage = (
                    session.query(TableStorageMetric)
                    .filter(
                        TableStorageMetric.config_id == config_id,
                        TableStorageMetric.dataset_name == dataset,
                        TableStorageMetric.table_name == table,
                    )
                    .first()
                )
                schema_cache[target] = schema
                storage_cache[target] = storage
                return schema, storage

            def _target_qualifies(target: str) -> bool:
                if target in target_has_rec_cache:
                    return target_has_rec_cache[target]
                consumers = jobs_by_referenced_table.get(target, [])
                if not consumers:
                    target_has_rec_cache[target] = False
                    return False
                usage = analyse_column_usage(consumers).get(target)
                if usage is None:
                    target_has_rec_cache[target] = False
                    return False
                schema, storage = _schema_storage(target)
                rec = build_recommendation(
                    target,
                    column_usage=usage,
                    schema=schema,
                    storage=storage,
                )
                qualifies = rec is not None
                target_has_rec_cache[target] = qualifies
                return qualifies

            for row in rows:
                affected = row.get("affected_table") or ""
                if not affected:
                    continue

                # Targets: affected_table itself + every distinct
                # upstream referenced by jobs whose destination is
                # affected_table. Mirrors the detail-page handler so
                # the listing flag is consistent with the card that
                # would actually render.
                targets: set[str] = {affected}
                for producer in jobs_by_destination.get(affected, []):
                    for ref in (producer.referenced_tables or []):
                        fq = _ref_to_fq(ref)
                        if fq and fq != affected:
                            targets.add(fq)

                # Short-circuit on the first qualifying target - the
                # flag is yes/no, we don't need to enumerate all.
                for target in sorted(targets):
                    if _target_qualifies(target):
                        row["has_layout_recommendation"] = True
                        break
    except Exception:  # noqa: BLE001
        logger.exception(
            "layout-signal annotation failed - listing renders "
            "without the Layout column populated"
        )


def _select_recommendation_targets(
    affected_table: str, related_jobs: "Iterable[BigQueryJob]"
) -> list[str]:
    """Pick the table(s) we should run the layout recommender against.

    The opportunity points at ``affected_table`` (the destination of
    whatever job triggered it). For most issue rules the actual
    layout fix belongs on an upstream - ``partition_pruning`` fires
    on the downstream that did a full scan, but the partition_by
    you'd add lives on the upstream that should have been
    partitioned.

    So the candidate target set is ``{affected_table}`` ∪
    ``{every fully-qualified upstream referenced by a producer job
    of affected_table}``. Each candidate is then handed to the
    recommender; the recommender abstains when consumer-side signal
    is weak, so over-broad targeting is harmless.
    """
    targets: set[str] = {affected_table}
    for job in related_jobs:
        # Only producer jobs of affected_table contribute upstreams.
        # Other jobs in the related set might be unrelated reads.
        if getattr(job, "destination_table", None) != affected_table:
            continue
        refs = getattr(job, "referenced_tables", None) or []
        for ref in refs:
            fq = _ref_to_fq(ref)
            if fq and fq != affected_table:
                targets.add(fq)
    return sorted(targets)


def _build_layout_recommendations(
    *,
    affected_table: str,
    config_id: str,
    related_jobs: "list[BigQueryJob]",
) -> list:
    """Return zero or more ``LayoutRecommendation`` objects, one per
    qualifying target table.

    For each target:

    1. Find consumer jobs - every cached job whose ``referenced_tables``
       contains the target. This is the input to L2's column-usage
       analyser.
    2. Look up the target's schema (``TableColumnMetadata``) and
       storage (``TableStorageMetric``) for L3's gates.
    3. Call the recommender. Skip targets that produce ``None``.

    Wrapped in a try/except so any unexpected failure (rogue query,
    schema row mishap) returns an empty list rather than 500-ing the
    detail page. The card is opportunistic; the rest of the page
    must always render.
    """
    try:
        from governor_audit.lineage.column_usage import analyse_column_usage
        from governor_audit.lineage.recommendations import build_recommendation
        from governor_core.sync.models import (
            BigQueryJob,
            TableColumnMetadata,
            TableStorageMetric,
        )

        targets = _select_recommendation_targets(affected_table, related_jobs)
        if not targets:
            return []

        # Load every cached job for this config that has a non-empty
        # referenced_tables list. We then filter Python-side per
        # target - SQLite's JSONB containment story is brittle and
        # the bounded-N audit cache (single-project) makes the
        # in-memory filter cheap. If this becomes a hot path on
        # multi-million-row caches, push the filter down via a
        # SQLite ``json_each`` LATERAL.
        engine = build_engine()
        create_all(engine)
        factory = make_session_factory(engine)
        with factory() as session:
            all_consumer_candidates = (
                session.query(BigQueryJob)
                .filter(
                    BigQueryJob.config_id == config_id,
                    BigQueryJob.referenced_tables.isnot(None),
                )
                .all()
            )

            # Phase-2 latest-version filter: keep only consumers that
            # are running their destination's latest deployed query
            # version. Stale-version consumers would otherwise pull
            # the recommendation toward the columns their OLDER SQL
            # filtered on. Mirrors the unit-of-analysis the dashboard
            # and the scan-time layout recommender now use.
            from governor_audit.web.routes.findings import (
                _latest_version_cohort_job_ids,
            )

            latest_cohort = _latest_version_cohort_job_ids(all_consumer_candidates)
            all_consumer_candidates = [
                j for j in all_consumer_candidates if j.job_id in latest_cohort
            ]

            # Pre-resolve referenced_tables for each candidate to a
            # set of FQ table names so the per-target filter is O(N)
            # instead of O(N × refs_per_job).
            jobs_by_referenced_table: dict[str, list[BigQueryJob]] = {}
            for j in all_consumer_candidates:
                seen: set[str] = set()
                for ref in (j.referenced_tables or []):
                    fq = _ref_to_fq(ref)
                    if fq is not None and fq not in seen:
                        seen.add(fq)
                        jobs_by_referenced_table.setdefault(fq, []).append(j)

            recs: list = []
            for target in targets:
                consumers = jobs_by_referenced_table.get(target, [])
                if not consumers:
                    continue

                usage_by_table = analyse_column_usage(consumers)
                usage = usage_by_table.get(target)
                if usage is None:
                    continue

                parts = target.split(".")
                if len(parts) != 3:
                    continue
                _project, dataset, table = parts

                schema = (
                    session.query(TableColumnMetadata)
                    .filter(
                        TableColumnMetadata.config_id == config_id,
                        TableColumnMetadata.dataset_name == dataset,
                        TableColumnMetadata.table_name == table,
                    )
                    .all()
                )
                storage = (
                    session.query(TableStorageMetric)
                    .filter(
                        TableStorageMetric.config_id == config_id,
                        TableStorageMetric.dataset_name == dataset,
                        TableStorageMetric.table_name == table,
                    )
                    .first()
                )

                rec = build_recommendation(
                    target,
                    column_usage=usage,
                    schema=schema,
                    storage=storage,
                )
                if rec is not None:
                    recs.append(rec)
            return recs
    except Exception:  # noqa: BLE001
        logger.exception(
            "layout recommendations failed for %s - rendering detail "
            "without the card",
            affected_table,
        )
        return []


def _ref_to_fq(ref: object) -> str | None:
    """Normalise a single ``referenced_tables`` entry to ``project.dataset.table``."""
    if isinstance(ref, str):
        return ref
    if isinstance(ref, dict):
        proj = ref.get("project_id") or ref.get("projectId") or ""
        ds = ref.get("dataset_id") or ref.get("datasetId") or ""
        tbl = ref.get("table_id") or ref.get("tableId") or ""
        parts = [p for p in (proj, ds, tbl) if p]
        if len(parts) == 3:
            return ".".join(parts)
    return None


def _build_job_lookup_sql(
    job: BigQueryJob | None, project_id: str, region: str
) -> str | None:
    """Render an ``INFORMATION_SCHEMA.JOBS_BY_PROJECT`` query that
    returns exactly the row corresponding to ``job``.

    Includes a tight ``creation_time`` predicate when we know it,
    because BigQuery requires a partition filter on that view's
    underlying table to keep scan cost bounded.
    """
    if job is None or not job.job_id:
        return None
    region_clean = (region or "us").strip().lower()
    project_clean = (project_id or "").strip()
    if not project_clean:
        return None

    if job.creation_time is not None:
        ts_iso = job.creation_time.replace(microsecond=0).isoformat()
        # Add a 1-hour buffer either side so timezone or rounding skew
        # doesn't drop the row from the scan.
        time_clause = (
            f"  AND creation_time BETWEEN "
            f"TIMESTAMP_SUB(TIMESTAMP(\"{ts_iso}\"), INTERVAL 1 HOUR)\n"
            f"      AND TIMESTAMP_ADD(TIMESTAMP(\"{ts_iso}\"), INTERVAL 1 HOUR)\n"
        )
    else:
        time_clause = (
            "  AND creation_time >= "
            "TIMESTAMP_SUB(CURRENT_TIMESTAMP(), INTERVAL 180 DAY)\n"
        )

    safe_job_id = job.job_id.replace("'", "\\'")
    # Curated column list - the fields useful for diagnosing a single
    # job. Mirrors the scan-time SELECT in
    # ``governor_audit.scan.information_schema.build_information_schema_query``
    # so what the user inspects matches what audit consumed.
    select_clause = (
        "SELECT\n"
        "    job_id,\n"
        "    user_email,\n"
        "    creation_time,\n"
        "    start_time,\n"
        "    end_time,\n"
        "    statement_type,\n"
        "    state,\n"
        "    cache_hit,\n"
        "    error_result,\n"
        "    total_slot_ms,\n"
        "    total_bytes_processed,\n"
        "    total_bytes_billed,\n"
        "    destination_table,\n"
        "    referenced_tables,\n"
        "    labels,\n"
        "    query_info.performance_insights AS performance_insights,\n"
        "    query_info.query_hashes AS query_hashes,\n"
        "    timeline,\n"
        "    query\n"
    )
    return (
        select_clause
        + f"FROM `{project_clean}.region-{region_clean}`."
        "INFORMATION_SCHEMA.JOBS_BY_PROJECT\n"
        f"WHERE job_id = '{safe_job_id}'\n"
        + time_clause
    )


__all__ = ["router"]
