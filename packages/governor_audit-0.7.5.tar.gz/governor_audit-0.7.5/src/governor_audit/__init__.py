"""governor-audit - read-only production audit tool.

Single-user CLI that audits a production dbt deployment using only
``gcloud`` Application Default Credentials, a user-supplied GCP project
+ region, and a ``manifest.json`` uploaded from the user's dev
environment. Queries production BigQuery ``INFORMATION_SCHEMA.JOBS``
for historical job data, runs the existing ``governor-core`` detection
rules, and surfaces findings with code-location pointers from the
manifest.

This package is read-only by design: no PR creation, no shadow
validation, no LLM solution generation in v1. See spec 141 for the
full posture.
"""

from __future__ import annotations

from governor_audit.version import get_app_version

__version__ = get_app_version()
