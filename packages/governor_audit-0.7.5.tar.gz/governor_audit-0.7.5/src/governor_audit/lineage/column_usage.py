"""Column-usage analyser - spec 148 Layer 2.

Walk every cached query's AST, count how often each column appears
in WHERE / JOIN / GROUP-BY clauses, and attribute the references
back to the source table (not the alias).

The output (``dict[fully_qualified_table, TableColumnUsage]``) is
the input to the recommender (Layer 3): a column that 90% of
consumers filter on is a partition-key candidate; columns that
appear in WHERE/JOIN clauses across many distinct queries are
cluster candidates.

Implementation notes:

- Query dedup is by ``query_hashes.normalized_literals`` (BigQuery's
  own constant-folded hash). Same key the spec-147 AST cache uses.
  We parse each unique query exactly once but tally per-job.
- Alias resolution: we walk every ``exp.From`` / ``exp.Join`` node
  to build an alias → fully-qualified-table map per query. Columns
  with an unambiguous alias resolve cleanly. Columns referenced
  without a table prefix (``WHERE x = 1``) are attributed only when
  the query has exactly one source table - otherwise dropped to
  avoid mis-attribution.
- Tally is per-job, not per-occurrence: a job that filters on
  ``event_date`` in two sub-CTEs counts as 1 toward
  ``filter_columns['event_date']``. This matches how the recommender
  reads frequency ("X% of consumer queries filter on …").

Public surface: ``TableColumnUsage``, ``analyse_column_usage``.
"""

from __future__ import annotations

import logging
from collections import Counter
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Iterable

import sqlglot
from sqlglot import exp

if TYPE_CHECKING:
    from governor_core.sync.models import BigQueryJob

logger = logging.getLogger("governor_audit.lineage.column_usage")


@dataclass
class TableColumnUsage:
    """How one fully-qualified table's columns appear in consumer SQL.

    Each Counter maps ``column_name → count of distinct consumer jobs
    that referenced this column in the named clause``. We count by
    job, not by reference: a single job referencing ``event_date`` in
    two sub-CTEs contributes 1 to ``filter_columns['event_date']``.
    """

    filter_columns: Counter = field(default_factory=Counter)
    join_columns: Counter = field(default_factory=Counter)
    groupby_columns: Counter = field(default_factory=Counter)
    total_consumer_jobs: int = 0


def analyse_column_usage(
    jobs: "Iterable[BigQueryJob]",
) -> dict[str, TableColumnUsage]:
    """Return ``dict[fully_qualified_table, TableColumnUsage]`` from
    walking each cached query's AST.

    Jobs without a query body or with an unparseable SQL fragment are
    silently skipped. Each unique query (keyed on
    ``query_hashes.normalized_literals``) is parsed once; the
    extracted column-set is then applied per job that hashes to it.
    """
    # Step 1: bucket jobs by their normalised query hash so we can
    # parse each unique query exactly once. Jobs missing a hash fall
    # back to the raw SQL string as the dedup key.
    jobs_by_query: dict[str, list[object]] = {}
    for job in jobs:
        query = getattr(job, "query", None)
        if not query:
            continue
        hashes = getattr(job, "query_hashes", None) or {}
        if not isinstance(hashes, dict):
            hashes = {}
        key = hashes.get("normalized_literals") or query
        jobs_by_query.setdefault(key, []).append(job)

    # Step 2: for each unique query, parse + extract per-table column
    # references, then apply to every job that shares the hash.
    usage_by_table: dict[str, TableColumnUsage] = {}
    parse_failures = 0

    for _key, sibling_jobs in jobs_by_query.items():
        sample_job = sibling_jobs[0]
        sql = getattr(sample_job, "query", None) or ""
        try:
            tree = sqlglot.parse_one(sql, dialect="bigquery")
        except Exception as exc:  # noqa: BLE001
            parse_failures += 1
            logger.debug(
                "column_usage parse failed: hash=%s error=%s",
                _key[:32] if isinstance(_key, str) else "?",
                exc,
            )
            continue

        per_query = _extract_column_references(tree)
        if not per_query:
            continue

        # Apply to every sibling job. Each table touched by the query
        # gets its ``total_consumer_jobs`` incremented once per job;
        # each column reference contributes 1 per job to the
        # appropriate counter.
        for _ in sibling_jobs:
            for table, refs in per_query.items():
                bucket = usage_by_table.setdefault(table, TableColumnUsage())
                bucket.total_consumer_jobs += 1
                for col in refs.filter_cols:
                    bucket.filter_columns[col] += 1
                for col in refs.join_cols:
                    bucket.join_columns[col] += 1
                for col in refs.groupby_cols:
                    bucket.groupby_columns[col] += 1

    if parse_failures:
        logger.info(
            "column_usage: %d unique queries failed to parse and were skipped",
            parse_failures,
        )

    return usage_by_table


# ───────────────────────────────────────── per-query AST walk


@dataclass
class _PerTableRefs:
    """Dedup-by-set so a column referenced 2× in a single query
    counts as 1 for that query (per-job tallying happens upstream)."""

    filter_cols: set[str] = field(default_factory=set)
    join_cols: set[str] = field(default_factory=set)
    groupby_cols: set[str] = field(default_factory=set)


def _extract_column_references(
    tree: exp.Expression,
) -> dict[str, _PerTableRefs]:
    """Extract column references grouped by source table.

    Returns ``dict[fully_qualified_table, _PerTableRefs]``. Tables we
    can't resolve to a fully-qualified name are dropped (better
    silent than mis-attributed).
    """
    aliases = _build_alias_map(tree)
    if not aliases:
        return {}

    per_table: dict[str, _PerTableRefs] = {
        fq: _PerTableRefs() for fq in set(aliases.values())
    }

    # WHERE clauses → filter_cols
    for where in tree.find_all(exp.Where):
        for col in where.find_all(exp.Column):
            fq = _resolve_column_table(col, aliases)
            if fq is None:
                continue
            per_table.setdefault(fq, _PerTableRefs()).filter_cols.add(
                col.name
            )

    # JOIN ... ON ... clauses → join_cols. ``exp.Join.args["on"]`` is
    # the ON expression; we walk Column refs inside it.
    for join in tree.find_all(exp.Join):
        on_expr = join.args.get("on")
        if on_expr is None:
            continue
        for col in on_expr.find_all(exp.Column):
            fq = _resolve_column_table(col, aliases)
            if fq is None:
                continue
            per_table.setdefault(fq, _PerTableRefs()).join_cols.add(col.name)

    # GROUP BY → groupby_cols. ``exp.Group.expressions`` is the list
    # of grouped expressions; we walk Column refs inside each.
    for group in tree.find_all(exp.Group):
        for grouped in group.expressions:
            for col in grouped.find_all(exp.Column):
                fq = _resolve_column_table(col, aliases)
                if fq is None:
                    continue
                per_table.setdefault(fq, _PerTableRefs()).groupby_cols.add(
                    col.name
                )

    # Drop tables with zero references - they appeared in FROM/JOIN
    # but contributed no column signal.
    return {
        fq: refs
        for fq, refs in per_table.items()
        if refs.filter_cols or refs.join_cols or refs.groupby_cols
    }


def _build_alias_map(tree: exp.Expression) -> dict[str, str]:
    """Map every alias (and bare table name) to a fully-qualified
    ``project.dataset.table`` identifier.

    Ambiguous mappings - same alias resolving to two different
    fully-qualified names within one query - are dropped from the
    map entirely; columns prefixed with that alias will fall through
    the resolution path and be skipped (defensive - mis-attribution
    is worse than silence).
    """
    raw: dict[str, list[str]] = {}

    for table in tree.find_all(exp.Table):
        fq = _table_fully_qualified(table)
        if fq is None:
            continue
        # ``alias_or_name`` returns the alias when set, else the
        # bare table name. Both should resolve to the same fq.
        local = table.alias_or_name
        bare = table.name
        if local:
            raw.setdefault(local, []).append(fq)
        # Also map the bare table identifier so unqualified columns
        # (when there's exactly one source) can resolve.
        if bare and bare != local:
            raw.setdefault(bare, []).append(fq)

    # Collapse to single mapping; drop ambiguous entries.
    resolved: dict[str, str] = {}
    for local, candidates in raw.items():
        unique = set(candidates)
        if len(unique) == 1:
            resolved[local] = next(iter(unique))
    return resolved


def _table_fully_qualified(table: exp.Table) -> str | None:
    """Return ``project.dataset.table`` from an exp.Table node, or
    None if the parts can't be resolved.

    BigQuery's three-part identifier rules are loose: ``proj.ds.t``,
    ```proj.ds.t```, ``ds.t`` (defaults proj from session), or
    ``t`` (defaults proj+ds). Audit's synthetic manifest only handles
    fully-qualified destinations, so unqualified or two-part names
    fall through and the column gets dropped from the analysis -
    we have nothing to compare them against.
    """
    parts = []
    if table.args.get("catalog"):
        parts.append(table.args["catalog"].name)
    if table.args.get("db"):
        parts.append(table.args["db"].name)
    if table.name:
        parts.append(table.name)
    parts = [p for p in parts if p]
    if len(parts) == 3:
        return ".".join(parts)
    return None


def _resolve_column_table(
    col: exp.Column, aliases: dict[str, str]
) -> str | None:
    """Resolve a column's source table via the alias map.

    A column with an explicit table prefix (``t.col``) resolves via
    the alias map. A column without a prefix resolves only when the
    query has exactly one source table (single-table SELECT) -
    otherwise we drop it to avoid mis-attributing the reference to
    the wrong source.
    """
    if col.table:
        return aliases.get(col.table)
    # Unqualified column - only safe to attribute when the query has
    # a single source table.
    distinct_tables = set(aliases.values())
    if len(distinct_tables) == 1:
        return next(iter(distinct_tables))
    return None


__all__ = ["TableColumnUsage", "analyse_column_usage"]
