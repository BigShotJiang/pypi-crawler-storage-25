"""Physical-layout recommender - spec 148 Layer 3.

Joins three signals:

1. **Column usage** (from spec-148 L2) - how often each column
   appears in WHERE / JOIN / GROUP-BY across consumer queries.
2. **Schema** (from ``TableColumnMetadata``) - column types, so
   we can identify DATE/TIMESTAMP/DATETIME candidates for
   partitioning.
3. **Storage** (from ``TableStorageMetric``) - table size
   (materiality gate) and whether the table is already
   partitioned.

…and produces a ``LayoutRecommendation | None`` per table. Returns
``None`` when the data doesn't justify a recommendation - Story 3
of the spec is non-negotiable: a confident-wrong recommendation
costs the user more than a missing one.

Public surface: ``PartitionCandidate``, ``ClusterCandidate``,
``LayoutRecommendation``, ``build_recommendation``.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Iterable

if TYPE_CHECKING:
    from governor_audit.lineage.column_usage import TableColumnUsage
    from governor_core.sync.models import TableColumnMetadata, TableStorageMetric

logger = logging.getLogger("governor_audit.lineage.recommendations")


# ──────────────────────────────────────────────── data classes


@dataclass(frozen=True)
class PartitionCandidate:
    """Recommended partition key for a table."""

    column: str
    column_type: str  # DATE | TIMESTAMP | DATETIME
    filter_frequency: float  # 0.0 – 1.0, fraction of consumer jobs that filter on this col
    consumer_job_count: int


@dataclass(frozen=True)
class ClusterCandidate:
    """Recommended cluster key for a table.

    Multiple cluster candidates per table are ordered by
    ``filter_or_join_frequency`` descending; BigQuery cluster
    ordering matters and putting the highest-frequency column first
    maximises pruning.
    """

    column: str
    filter_or_join_frequency: float  # 0.0 – 1.0


@dataclass(frozen=True)
class LayoutRecommendation:
    """The full per-table recommendation surfaced on the detail page.

    ``partition`` is None when the partition gate didn't fire (size
    below threshold, table already partitioned, no DATE/TIMESTAMP
    column hit the threshold).

    ``cluster`` is empty when no column hit the cluster threshold
    or when every candidate was pruned because it overlaps the
    partition column.

    ``evidence`` carries everything the template needs to render the
    "why" sub-section without re-querying - total bytes, top
    supporting consumer jobs, etc.
    """

    table: str
    partition: PartitionCandidate | None
    cluster: list[ClusterCandidate]
    evidence: dict[str, Any] = field(default_factory=dict)


# ──────────────────────────────────────────────── thresholds (defaults)

# Tables smaller than this don't benefit enough from partitioning to
# offset the per-partition metadata cost. 1 GB matches BigQuery's
# own guidance.
DEFAULT_MATERIALITY_BYTES = 1_000_000_000

# Below this many distinct consumer jobs in the scan window, the
# usage signal is too sparse to draw a confident conclusion. With
# fewer than 5 consumer jobs a single query can swing the recommended
# partition / cluster picks (filter frequency of 1/1 = 100%), which
# produces false positives that cost more than missing recommendations.
DEFAULT_MIN_CONSUMER_JOBS = 5

# A column must be filtered on by at least this fraction of consumer
# jobs to qualify as a partition candidate.
DEFAULT_PARTITION_THRESHOLD = 0.7

# A column must appear in WHERE/JOIN clauses across at least this
# fraction of consumer jobs to qualify as a cluster candidate.
DEFAULT_CLUSTER_THRESHOLD = 0.5

# BigQuery permits up to 4 cluster keys; we cap at the same.
MAX_CLUSTER_COLUMNS = 4

# Column types that are valid partition-key candidates. INT64 with
# range justification is deferred (spec open question T017).
PARTITION_KEY_TYPES = frozenset({"DATE", "TIMESTAMP", "DATETIME"})


# ──────────────────────────────────────────────── public entry point


def build_recommendation(
    table: str,
    *,
    column_usage: "TableColumnUsage | None",
    schema: "Iterable[TableColumnMetadata] | None",
    storage: "TableStorageMetric | None",
    materiality_bytes: int = DEFAULT_MATERIALITY_BYTES,
    min_consumer_jobs: int = DEFAULT_MIN_CONSUMER_JOBS,
    partition_threshold: float = DEFAULT_PARTITION_THRESHOLD,
    cluster_threshold: float = DEFAULT_CLUSTER_THRESHOLD,
) -> LayoutRecommendation | None:
    """Return a recommendation if the data supports one, else None.

    Decision tree (spec 148, Stories 1/2/3):

    1. Insufficient consumer signal (< ``min_consumer_jobs``) →
       ``None``. Story 3.1 - never invent under-spec.
    2. Compute partition candidate (DATE/TIMESTAMP/DATETIME column
       with ``filter_frequency >= partition_threshold``) gated on
       materiality + not-already-partitioned.
    3. Compute cluster candidates (any column with combined
       filter+join frequency ≥ ``cluster_threshold``); drop the
       partition column from the cluster list.
    4. If neither partition nor cluster qualifies → ``None``.
    """
    # Story 3.1 - sparse signal abstention.
    if column_usage is None or column_usage.total_consumer_jobs < min_consumer_jobs:
        logger.debug(
            "recommendations skip table=%s reason=insufficient_consumer_signal "
            "consumer_jobs=%d",
            table,
            column_usage.total_consumer_jobs if column_usage else 0,
        )
        return None

    schema_by_col = _build_schema_lookup(schema or [])
    total_bytes, is_partitioned, total_partitions = _storage_facts(storage)

    partition = _maybe_partition_candidate(
        column_usage,
        schema_by_col,
        total_bytes=total_bytes,
        is_partitioned=is_partitioned,
        materiality_bytes=materiality_bytes,
        threshold=partition_threshold,
    )

    cluster = _cluster_candidates(
        column_usage,
        schema_by_col=schema_by_col,
        partition_col=partition.column if partition else None,
        threshold=cluster_threshold,
    )

    if partition is None and not cluster:
        return None

    return LayoutRecommendation(
        table=table,
        partition=partition,
        cluster=cluster,
        evidence={
            "total_bytes": total_bytes,
            "is_partitioned": is_partitioned,
            "total_partitions": total_partitions,
            "total_consumer_jobs": column_usage.total_consumer_jobs,
        },
    )


# ──────────────────────────────────────────────── partition gate


def _maybe_partition_candidate(
    usage: "TableColumnUsage",
    schema_by_col: dict[str, str],
    *,
    total_bytes: int,
    is_partitioned: bool,
    materiality_bytes: int,
    threshold: float,
) -> PartitionCandidate | None:
    """Return the best partition candidate, or None if the gates fail."""
    # Story 1.4 - too small to bother.
    if total_bytes < materiality_bytes:
        return None
    # Story 1.3 - user already chose a partition column; we don't
    # second-guess. ``total_partitions > 1`` is the practical signal
    # (an unpartitioned table reports either 0 or 1).
    if is_partitioned:
        return None

    total_jobs = usage.total_consumer_jobs
    if total_jobs == 0:
        return None

    # Sort filter columns by frequency desc; pick the highest one
    # whose schema type qualifies as a partition key.
    ranked = sorted(
        usage.filter_columns.items(), key=lambda kv: kv[1], reverse=True
    )
    for col, count in ranked:
        freq = count / total_jobs
        if freq < threshold:
            # Once we drop below threshold, none of the remaining
            # columns can qualify either.
            return None
        col_type = schema_by_col.get(col)
        if col_type and col_type.upper() in PARTITION_KEY_TYPES:
            return PartitionCandidate(
                column=col,
                column_type=col_type.upper(),
                filter_frequency=freq,
                consumer_job_count=total_jobs,
            )
    return None


# ──────────────────────────────────────────────── cluster gate


def _cluster_candidates(
    usage: "TableColumnUsage",
    *,
    schema_by_col: dict[str, str],
    partition_col: str | None,
    threshold: float,
) -> list[ClusterCandidate]:
    """Return up to ``MAX_CLUSTER_COLUMNS`` cluster candidates ranked
    by combined filter+join frequency."""
    total_jobs = usage.total_consumer_jobs
    if total_jobs == 0:
        return []

    # Build (column, combined_freq) tuples summing filter + join
    # references. GROUP BY isn't included - clustering primarily
    # benefits filtering and join performance, not grouping.
    columns: set[str] = (
        set(usage.filter_columns.keys()) | set(usage.join_columns.keys())
    )
    scored: list[tuple[str, float]] = []
    for col in columns:
        if col == partition_col:
            # Story 2.2 - partition column already gives the same
            # pruning benefit; clustering on it is wasted.
            continue
        if col not in schema_by_col:
            # Column doesn't appear in the table's schema (alias
            # mishap, dropped column, etc.). Skip rather than
            # recommend a column the user can't actually cluster on.
            continue
        combined = usage.filter_columns.get(col, 0) + usage.join_columns.get(col, 0)
        # Cap at total_jobs - a column referenced in both WHERE and
        # JOIN by the same job otherwise inflates over 1.0.
        freq = min(combined, total_jobs) / total_jobs
        if freq >= threshold:
            scored.append((col, freq))

    scored.sort(key=lambda t: t[1], reverse=True)
    return [
        ClusterCandidate(column=col, filter_or_join_frequency=freq)
        for col, freq in scored[:MAX_CLUSTER_COLUMNS]
    ]


# ──────────────────────────────────────────────── helpers


def _build_schema_lookup(
    schema: "Iterable[TableColumnMetadata]",
) -> dict[str, str]:
    """``column_name → data_type`` for the affected table."""
    return {row.column_name: row.data_type for row in schema}


def _storage_facts(
    storage: "TableStorageMetric | None",
) -> tuple[int, bool, int]:
    """Extract (total_bytes, is_partitioned, total_partitions) from a
    TableStorageMetric row, handling None gracefully."""
    if storage is None:
        return (0, False, 0)
    total_bytes = int(getattr(storage, "total_logical_bytes", 0) or 0)
    total_partitions = int(getattr(storage, "total_partitions", 0) or 0)
    # An unpartitioned table reports total_partitions = 0 or 1
    # depending on BigQuery's bookkeeping; treat > 1 as the
    # definitive partitioned signal.
    is_partitioned = total_partitions > 1
    return (total_bytes, is_partitioned, total_partitions)


__all__ = [
    "PartitionCandidate",
    "ClusterCandidate",
    "LayoutRecommendation",
    "build_recommendation",
    "DEFAULT_MATERIALITY_BYTES",
    "DEFAULT_MIN_CONSUMER_JOBS",
    "DEFAULT_PARTITION_THRESHOLD",
    "DEFAULT_CLUSTER_THRESHOLD",
    "MAX_CLUSTER_COLUMNS",
    "PARTITION_KEY_TYPES",
]
