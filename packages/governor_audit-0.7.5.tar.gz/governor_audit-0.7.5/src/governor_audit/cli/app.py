"""Top-level Typer app for the ``governor-audit`` CLI.

Exposed via the ``governor-audit`` entry point declared in pyproject.toml.
Each command lives in its own module under ``cli/commands/`` so the app
file stays small and the per-command logic can be exercised in isolation.
"""

from __future__ import annotations

import os

# Force gRPC's native DNS resolver. The bundled c-ares resolver fails on
# some macOS networks with IPv6-only DNS responses, surfacing as
# "503 failed to connect to all addresses" during project discovery.
# Native uses the OS resolver and avoids the issue. Set before any
# google-cloud-bigquery imports so it takes effect on the first gRPC
# channel. setdefault preserves an explicit override from the env.
os.environ.setdefault("GRPC_DNS_RESOLVER", "native")

import typer
from rich.console import Console

from governor_audit.cli.commands import init as _init
from governor_audit.cli.commands import reset as _reset
from governor_audit.cli.commands import reset_config as _reset_config
from governor_audit.cli.commands import scan as _scan
from governor_audit.cli.commands import start as _start
from governor_audit.cli.commands import status as _status
from governor_audit.cli.commands import stop as _stop
# Spec 152 - MCP stdio server subcommand.
from governor_audit.cli.commands.mcp import mcp_app as _mcp_app
from governor_audit.version import get_app_version

app = typer.Typer(
    name="governor-audit",
    no_args_is_help=True,
    add_completion=False,
    help=(
        "Read-only BigQuery cost-audit tool. Single-user, gcloud ADC only, "
        "no GCS / no GitHub / no dbt installation.\n\n"
        "Quickstart: `gcloud auth application-default login` then "
        "`governor-audit start` - the browser walks you through setup."
    ),
)

app.command(name="start")(_start.start_command)
app.command(name="stop")(_stop.stop_command)
app.command(name="init")(_init.init_command)
app.command(name="scan")(_scan.scan_command)
app.command(name="status")(_status.status_command)
app.command(name="reset")(_reset.reset_command)
app.command(name="reset-config")(_reset_config.reset_config_command)
app.add_typer(_mcp_app, name="mcp")


@app.callback(invoke_without_command=True)
def _root(
    ctx: typer.Context,
    version: bool = typer.Option(
        False,
        "--version",
        "-V",
        help="Print the package version and exit.",
        is_eager=True,
    ),
) -> None:
    if version:
        Console().print(f"governor-audit {get_app_version()}")
        raise typer.Exit(0)
    if ctx.invoked_subcommand is None:
        # No subcommand and no --version → show help and exit 0.
        Console().print(ctx.get_help())
        raise typer.Exit(0)


if __name__ == "__main__":
    app()
