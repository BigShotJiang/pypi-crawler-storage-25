"""``governor-audit reset-config`` - drop and recreate the config file.

Force-rewrites ``~/.governor-audit/config.json`` to a fresh, default
state. Useful when the file has accumulated stale per-rule overrides
(toggles persisted by older builds where the cloud catalog leaked
through and disabled rules audit wants live), or when you just want
the next ``governor-audit start`` to walk you through the setup
wizard again.

What this does:

  - Removes the existing ``~/.governor-audit/config.json``.
  - The next ``governor-audit start`` (or ``init``) treats the user as
    first-run and writes a fresh config with audit's current defaults.
  - The cache (``state.db``) and scan history are preserved - use
    ``governor-audit reset`` if you want to wipe those too.
"""

from __future__ import annotations

import logging
from typing import Annotated

import typer
from rich.console import Console

logger = logging.getLogger("governor_audit.cli.reset_config")
console = Console()


def reset_config_command(
    yes: Annotated[
        bool,
        typer.Option(
            "--yes",
            "-y",
            help="Skip the confirmation prompt. Use in non-interactive scripts.",
        ),
    ] = False,
) -> None:
    """Drop ``~/.governor-audit/config.json`` so the next start triggers
    the setup wizard again with audit's current defaults."""
    from governor_audit.config.loader import config_path

    path = config_path()

    if not path.exists():
        console.print(
            f"[yellow]No config file at[/] [cyan]{path}[/] - nothing to reset."
        )
        return

    if not yes:
        console.print(
            f"[bold red]This will delete[/] [cyan]{path}[/] and force the "
            "next [cyan]governor-audit start[/] through the setup wizard."
        )
        console.print(
            "Cached scan data ([cyan]~/.governor-audit/state.db[/]) is preserved - "
            "use [cyan]governor-audit reset[/] if you also want to wipe that."
        )
        if not typer.confirm("Continue?", default=False):
            console.print("[yellow]Aborted.[/] Nothing was deleted.")
            raise typer.Exit(1)

    path.unlink()
    logger.info("audit reset-config: deleted %s", path)
    console.print(f"[green]✓[/] Deleted [cyan]{path}[/].")
    console.print(
        "Run [cyan]governor-audit start[/] (or [cyan]init[/]) to recreate it."
    )


__all__ = ["reset_config_command"]
