"""``governor-audit mcp`` subcommand - spec 152.

Two actions:

  - ``governor-audit mcp run`` - start the MCP stdio server. This is
    what the chat client's MCP-configuration block invokes. Blocks
    until the client disconnects.
  - ``governor-audit mcp config`` - print a JSON snippet ready to
    paste into Claude Desktop's ``claude_desktop_config.json`` (or
    Cursor's equivalent). The absolute binary path is computed
    at runtime via ``shutil.which`` so the snippet is copy-paste
    ready on the user's machine.
"""

from __future__ import annotations

import json
import shutil
import sys

import typer
from rich.console import Console

mcp_app = typer.Typer(
    name="mcp",
    no_args_is_help=True,
    add_completion=False,
    help=(
        "Read-only Model Context Protocol server for governor-audit. "
        "Lets MCP-capable chat clients (Claude Desktop, Cursor, etc.) "
        "ask natural-language questions about your audit cache."
    ),
)


@mcp_app.command(
    name="run",
    help="Start the MCP stdio server. Run this from your chat client's MCP config, not directly.",
)
def run_command() -> None:
    """Boot the stdio server. Blocks until the client disconnects."""
    from governor_audit.mcp.server import run_stdio

    run_stdio()


@mcp_app.command(
    name="config",
    help=(
        "Print a JSON snippet ready to paste into your chat client's "
        "MCP configuration (Claude Desktop, Cursor, etc.)."
    ),
)
def config_command(
    plain: bool = typer.Option(
        False,
        "--plain",
        help="Print just the JSON, no surrounding instructions. Useful for piping.",
    ),
) -> None:
    """Render the chat-client config snippet."""
    binary = shutil.which("governor-audit") or sys.argv[0]
    snippet = {
        "mcpServers": {
            "governor-audit": {
                "command": binary,
                "args": ["mcp", "run"],
            }
        }
    }
    body = json.dumps(snippet, indent=2)

    if plain:
        # Stdout only - for piping into a file or jq.
        print(body)
        return

    console = Console()
    console.print(
        "[bold]Add this block to your chat client's MCP configuration:[/bold]\n"
    )
    console.print(
        "  • Claude Desktop: "
        "[dim]~/Library/Application Support/Claude/claude_desktop_config.json[/dim]"
    )
    console.print(
        "  • Cursor: [dim]Settings → MCP → Add server[/dim]\n"
    )
    console.print(body)
    console.print(
        "\n[dim]After saving, restart your chat client. Then ask any "
        "audit question - try 'what's my most expensive flagged "
        "model?'.[/dim]"
    )


__all__ = ["mcp_app"]
