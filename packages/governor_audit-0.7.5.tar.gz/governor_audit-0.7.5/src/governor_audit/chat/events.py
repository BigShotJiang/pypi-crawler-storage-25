"""SSE event shapes emitted by ``POST /chat/turn``.

Five typed events, each serialised to one SSE ``data:`` line. The
client routes incoming events by ``type`` to update transcript DOM
nodes. See [research.md](../../../specs/153-audit-chat-ui/research.md) §3.
"""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel


class TextEvent(BaseModel):
    """Incremental assistant text chunk."""

    type: Literal["text"] = "text"
    chunk: str


class ToolCallEvent(BaseModel):
    """The LLM decided to call a tool. The audit will invoke it; the
    matching ``ToolResultEvent`` follows once it returns."""

    type: Literal["tool_call"] = "tool_call"
    tool_name: str
    arguments: dict
    call_id: str


class ToolResultEvent(BaseModel):
    """A tool returned. ``is_error`` flags ``ToolError`` payloads so
    the client can render them with the error styling."""

    type: Literal["tool_result"] = "tool_result"
    call_id: str
    output_summary: str
    output_json: dict
    is_error: bool = False


class CostEvent(BaseModel):
    """Turn cost from the provider's usage metadata plus the new
    running session total. The client uses ``session_total_usd`` to
    drive its cap-related UI."""

    type: Literal["cost"] = "cost"
    turn_cost_usd: float
    session_total_usd: float
    session_cap_usd: float | None
    input_tokens: int
    output_tokens: int


class DoneEvent(BaseModel):
    """Final event of every turn. The client closes its EventSource
    on receipt and re-enables the input box (unless cost_cap, in
    which case the input stays disabled until the user resets or
    raises the cap)."""

    type: Literal["done"] = "done"
    finish_reason: Literal[
        "stop", "tool_error", "cost_cap", "provider_error"
    ] = "stop"
    error_message: str | None = None


# Union type the orchestrator yields.
ChatEvent = TextEvent | ToolCallEvent | ToolResultEvent | CostEvent | DoneEvent


__all__ = [
    "TextEvent",
    "ToolCallEvent",
    "ToolResultEvent",
    "CostEvent",
    "DoneEvent",
    "ChatEvent",
]
