"""Server-side per-session cost ledger for the chat surface.

Audit is a single-user, single-process, loopback-only app (uvicorn
with workers=1 by construction), so an in-memory dict is the right
storage tier - no Redis, no DB row, no cross-worker sync. The
chat page mints a UUID on first render and passes it back on every
turn; the server uses it as the ledger key.

This replaces the prior client-trusted ``session_total_cost_usd`` on
``ChatTurnRequest`` - that field could be set to 0 by a tampered
browser, defeating the cap entirely.

Bounded LRU keeps the ledger from growing unboundedly if the browser
keeps minting fresh session ids (e.g. private tabs, "New chat"
buttons). At MAX_SESSIONS we evict the oldest by last-touched time.
"""

from __future__ import annotations

import threading
import time

# Max distinct session ids kept in memory. 1000 is generous for a
# single-user local app - covers months of "New chat" presses
# without manual reset.
_MAX_SESSIONS = 1000


class _SessionLedger:
    """Thread-safe (session_id → total USD, last_touched) store.

    Used by the chat orchestrator to enforce the per-session cap
    server-side. All callers go through the module-level singleton.
    """

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._totals: dict[str, float] = {}
        self._touched: dict[str, float] = {}

    def get_total(self, session_id: str) -> float:
        """Return the running USD total for the session (0.0 if new)."""
        with self._lock:
            if session_id in self._touched:
                self._touched[session_id] = time.monotonic()
            return float(self._totals.get(session_id, 0.0))

    def add(self, session_id: str, delta_usd: float) -> float:
        """Add ``delta_usd`` to the session's running total and
        return the new total. Negative deltas are clamped to zero
        (defensive - cost should only ever grow)."""
        if delta_usd < 0:
            delta_usd = 0.0
        with self._lock:
            current = float(self._totals.get(session_id, 0.0))
            new_total = current + delta_usd
            self._totals[session_id] = new_total
            self._touched[session_id] = time.monotonic()
            self._evict_if_needed_locked()
            return new_total

    def reset(self, session_id: str) -> None:
        """Drop the session's accumulated total - used by the
        explicit 'New chat' / 'Reset session cost' user actions."""
        with self._lock:
            self._totals.pop(session_id, None)
            self._touched.pop(session_id, None)

    def _evict_if_needed_locked(self) -> None:
        """Evict the least-recently-touched session if the table
        is over the cap. Caller MUST hold ``self._lock``."""
        if len(self._totals) <= _MAX_SESSIONS:
            return
        # Pick the oldest by last-touched.
        oldest = min(self._touched.items(), key=lambda kv: kv[1])[0]
        self._totals.pop(oldest, None)
        self._touched.pop(oldest, None)


_LEDGER = _SessionLedger()


def get_total(session_id: str) -> float:
    """Module-level accessor for the singleton."""
    return _LEDGER.get_total(session_id)


def add(session_id: str, delta_usd: float) -> float:
    """Module-level accessor for the singleton."""
    return _LEDGER.add(session_id, delta_usd)


def reset(session_id: str) -> None:
    """Module-level accessor for the singleton."""
    _LEDGER.reset(session_id)


def _reset_all_for_tests() -> None:
    """Test-only - clear the entire ledger so cases don't pollute
    each other. Not part of the public API."""
    with _LEDGER._lock:
        _LEDGER._totals.clear()
        _LEDGER._touched.clear()


__all__ = ["get_total", "add", "reset"]
