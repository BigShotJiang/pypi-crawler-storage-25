"""Gemini provider adapter - wraps ``google-genai`` streaming + tool-use
into the audit's provider-agnostic ``ProviderStreamPiece`` shape.

The adapter is intentionally thin: translate the SDK's chunks one
direction (Gemini → ``ProviderStreamPiece``) and the orchestrator's
messages / tools shape the other (audit-neutral → Gemini's
``Content`` / ``Tool`` / ``FunctionDeclaration``). All higher-level
logic (tool-use loop, cost accounting, cap enforcement) lives in
``chat/service.py``.
"""

from __future__ import annotations

import json
import logging
from typing import AsyncIterator

from governor_audit.chat.providers.base import ProviderStreamPiece

logger = logging.getLogger("governor_audit.chat.providers.gemini")


class GeminiProvider:
    """Implements the ``Provider`` Protocol against ``google-genai``."""

    name = "gemini"

    def __init__(self, *, api_key: str, model: str):
        from google import genai

        self.model = model
        self._client = genai.Client(api_key=api_key)

    async def stream(
        self,
        *,
        messages: list[dict],
        tools: list[dict],
        system_prompt: str,
    ) -> AsyncIterator[ProviderStreamPiece]:
        from google.genai import types

        # Translate audit-neutral message shape → google-genai Contents.
        contents = _messages_to_contents(messages)
        gemini_tools = _build_gemini_tools(tools)
        config = types.GenerateContentConfig(
            system_instruction=system_prompt,
            tools=gemini_tools if gemini_tools else None,
            # Disable Gemini's automatic function-calling so the
            # orchestrator stays in control of the tool-use loop.
            automatic_function_calling=types.AutomaticFunctionCallingConfig(
                disable=True,
            ) if gemini_tools else None,
        )

        # google-genai's async streaming entrypoint is an async iterator.
        stream = await self._client.aio.models.generate_content_stream(
            model=self.model,
            contents=contents,
            config=config,
        )

        # Track the latest cumulative usage values across the stream
        # so we can emit ONCE after the stream ends. Gemini reports
        # ``prompt_token_count`` as the input size for THIS call
        # (constant across chunks) and ``candidates_token_count`` as
        # a running total that grows as output streams. Per-chunk
        # emission would double-count; we want the final values.
        #
        # ``thoughts_token_count`` is billed at the output rate on
        # Pro-thinking models - omitting it would under-charge the
        # cap. ``cached_content_token_count`` is billed at a fraction
        # of input rate; we count it as input (matches Gemini's
        # invoice line item).
        latest_input = 0
        latest_output = 0
        latest_thoughts = 0
        latest_cached = 0
        latest_stop: str | None = None
        async for chunk in stream:
            # Walk every part in every candidate. Gemini interleaves
            # text + function_call parts in a single chunk.
            candidates = getattr(chunk, "candidates", None) or []
            for candidate in candidates:
                content = getattr(candidate, "content", None)
                if content is None:
                    continue
                for part in getattr(content, "parts", None) or []:
                    text = getattr(part, "text", None)
                    if text:
                        yield ProviderStreamPiece(kind="text", text=text)
                        continue
                    fn_call = getattr(part, "function_call", None)
                    if fn_call is not None:
                        # Gemini's function-call args may come back
                        # as dict already, or as JSON-string.
                        raw_args = getattr(fn_call, "args", None) or {}
                        if isinstance(raw_args, str):
                            try:
                                raw_args = json.loads(raw_args)
                            except Exception:  # noqa: BLE001
                                raw_args = {"_raw": raw_args}
                        # Gemini requires us to echo ``thought_signature``
                        # back on the follow-up turn's matching Part -
                        # without it the API returns 400 INVALID_ARGUMENT
                        # ("Function call is missing a thought_signature").
                        # The signature lives on the Part itself (not on
                        # the FunctionCall) and is opaque bytes.
                        thought_signature = getattr(part, "thought_signature", None)
                        extras: dict = {}
                        if thought_signature is not None:
                            extras["thought_signature"] = thought_signature
                        yield ProviderStreamPiece(
                            kind="tool_call",
                            tool_name=getattr(fn_call, "name", "") or "",
                            tool_arguments=dict(raw_args) if isinstance(raw_args, dict) else {},
                            tool_call_id=getattr(fn_call, "id", "") or _synth_call_id(getattr(fn_call, "name", "")),
                            provider_extras=extras,
                        )
            usage = getattr(chunk, "usage_metadata", None)
            if usage is not None:
                latest_input = int(getattr(usage, "prompt_token_count", 0) or 0)
                latest_output = int(getattr(usage, "candidates_token_count", 0) or 0)
                latest_thoughts = int(getattr(usage, "thoughts_token_count", 0) or 0)
                latest_cached = int(
                    getattr(usage, "cached_content_token_count", 0) or 0
                )
            for cand in candidates:
                fr = getattr(cand, "finish_reason", None)
                if fr is not None:
                    latest_stop = str(fr)

        # Emit exactly one usage + stop piece per stream, after the
        # provider has finished producing chunks. Robust against
        # Gemini changing which chunk carries ``finish_reason``.
        # Thoughts tokens are billed as output; cached input as input.
        if latest_input or latest_output or latest_thoughts or latest_cached:
            yield ProviderStreamPiece(
                kind="usage",
                input_tokens=latest_input + latest_cached,
                output_tokens=latest_output + latest_thoughts,
            )
        if latest_stop is not None:
            yield ProviderStreamPiece(kind="stop", stop_reason=latest_stop)


def _messages_to_contents(messages: list[dict]):
    """Translate the audit-neutral conversation shape into a list of
    google-genai ``Content`` objects.

    Audit-neutral shape (mirrors the OpenAI / Anthropic conventions):
      {"role": "user", "content": "text"}
      {"role": "assistant", "content": "text"}
      {"role": "assistant", "tool_calls": [{"id": ..., "name": ..., "arguments": ...}]}
      {"role": "tool", "tool_call_id": ..., "content": {...}}

    Gemini's ``Content`` uses ``role`` ∈ {"user", "model"} only;
    tool results go in as ``Part.function_response``.
    """
    from google.genai import types

    out = []
    for msg in messages:
        role = msg.get("role")
        if role == "user":
            text = msg.get("content", "") or ""
            out.append(types.Content(role="user", parts=[types.Part(text=text)]))
        elif role == "assistant":
            parts = []
            text = msg.get("content")
            if text:
                parts.append(types.Part(text=text))
            for call in msg.get("tool_calls") or []:
                # Replay the original ``thought_signature`` Gemini gave
                # us - required for the API to accept the follow-up
                # turn (400 INVALID_ARGUMENT without it).
                extras = call.get("provider_extras") or {}
                thought_signature = extras.get("thought_signature")
                part_kwargs: dict = {
                    "function_call": types.FunctionCall(
                        id=call.get("id") or _synth_call_id(call.get("name", "")),
                        name=call.get("name", ""),
                        args=call.get("arguments") or {},
                    )
                }
                if thought_signature is not None:
                    part_kwargs["thought_signature"] = thought_signature
                parts.append(types.Part(**part_kwargs))
            if parts:
                out.append(types.Content(role="model", parts=parts))
        elif role == "tool":
            # Tool result - Gemini wants it as a function_response part
            # on a user-role Content.
            payload = msg.get("content") or {}
            if isinstance(payload, str):
                try:
                    payload = json.loads(payload)
                except Exception:  # noqa: BLE001
                    payload = {"value": payload}
            out.append(
                types.Content(
                    role="user",
                    parts=[
                        types.Part(
                            function_response=types.FunctionResponse(
                                id=msg.get("tool_call_id"),
                                name=msg.get("name", ""),
                                response=payload if isinstance(payload, dict) else {"value": payload},
                            )
                        )
                    ],
                )
            )
    return out


def _build_gemini_tools(tools: list[dict]):
    """Translate audit-neutral tool descriptors into Gemini's
    ``[Tool(function_declarations=[FunctionDeclaration(...)])]``."""
    from google.genai import types

    if not tools:
        return []
    declarations = []
    for tool in tools:
        declarations.append(
            types.FunctionDeclaration(
                name=tool["name"],
                description=tool.get("description", ""),
                parameters=_sanitise_schema_for_gemini(
                    tool.get("parameters") or {"type": "object", "properties": {}}
                ),
            )
        )
    return [types.Tool(function_declarations=declarations)]


def _sanitise_schema_for_gemini(schema: dict) -> dict:
    """Gemini's FunctionDeclaration accepts a subset of JSON Schema.
    Strip / map fields it doesn't accept (e.g. ``$ref`` resolution,
    ``additionalProperties`` quirks). For Phase 1 we copy the schema
    through and trust that Pydantic's emitted shape is sufficient;
    if Gemini complains in practice we'll add transforms here.
    """
    # Gemini rejects ``$defs`` / ``$ref``. If Pydantic emitted any,
    # we'd need to inline them; for the simple tool shapes the audit
    # exposes, this hasn't been observed.
    return schema


_call_seq = 0


def _synth_call_id(name: str) -> str:
    """Synthesise a tool-call id when Gemini didn't return one. The
    orchestrator just needs uniqueness within a session."""
    global _call_seq
    _call_seq += 1
    return f"{name or 'tool'}-{_call_seq}"


__all__ = ["GeminiProvider"]
