"""Provider-agnostic Protocol every chat adapter implements.

Per-SDK quirks live in the matching ``providers/<name>.py``. The
orchestrator (`chat/service.py`) treats every provider through this
Protocol so adding Anthropic / OpenAI later is a single new file.
"""

from __future__ import annotations

from typing import AsyncIterator, Literal, Protocol

from pydantic import BaseModel


class ProviderStreamPiece(BaseModel):
    """One normalised unit produced by a provider's streaming
    response. The orchestrator routes these into user-facing event
    types (``chat/events.py``).

    Four ``kind`` variants:

    - ``text``: incremental text chunk. ``text`` carries the chunk.
    - ``tool_call``: LLM wants to call a tool. ``tool_name``,
      ``tool_arguments``, ``tool_call_id`` populated. ``provider_extras``
      may carry opaque per-provider data the orchestrator needs to
      replay verbatim on the follow-up turn (e.g. Gemini's
      ``thought_signature``).
    - ``usage``: end-of-turn usage metadata. ``input_tokens`` +
      ``output_tokens`` populated.
    - ``stop``: provider finished the turn. ``stop_reason`` optional.
    """

    kind: Literal["text", "tool_call", "usage", "stop"]
    text: str = ""
    tool_name: str = ""
    tool_arguments: dict = {}
    tool_call_id: str = ""
    input_tokens: int = 0
    output_tokens: int = 0
    stop_reason: str = ""
    # Provider-opaque round-trip data. Each provider stashes whatever
    # it needs to echo back on the follow-up turn - Gemini requires
    # ``thought_signature`` on tool-call parts; Anthropic / OpenAI
    # have their own quirks. Other providers MUST ignore unrecognised
    # keys.
    provider_extras: dict = {}


class Provider(Protocol):
    """Interface for one LLM provider adapter.

    The orchestrator iterates ``stream(...)`` once per LLM call, then
    if the LLM asked for tool calls, sends a follow-up message with
    the tool results and iterates again until the provider stops.
    """

    name: str
    model: str

    def stream(
        self,
        *,
        messages: list[dict],
        tools: list[dict],
        system_prompt: str,
    ) -> AsyncIterator[ProviderStreamPiece]:
        """Stream provider events normalised to ``ProviderStreamPiece``.

        ``messages`` is a provider-neutral conversation history in the
        LLM-SDK-standard shape:
            ``[{"role": "user", "content": "..."}, ...]``
            ``[{"role": "assistant", "tool_use": [...]}, ...]``
            ``[{"role": "tool", "tool_call_id": "...", "content": "..."}, ...]``
        Each adapter translates this into its SDK's expected shape.
        """
        ...


__all__ = ["Provider", "ProviderStreamPiece"]
