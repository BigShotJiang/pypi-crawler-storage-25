"""Testing-only fake provider.

Driven by a per-test script of ``ProviderStreamPiece`` events. The
orchestrator tests + the SSE integration test use this rather than
calling ``google-genai``, so we test our event-routing logic in
isolation from SDK quirks.

NOT registered in the production provider map - accessing it
requires importing this module directly.
"""

from __future__ import annotations

from typing import AsyncIterator

from governor_audit.chat.providers.base import ProviderStreamPiece


# Module-level script: tests append a list of events, the next
# ``FakeProvider`` instance consumes them. The first list is the
# first turn's stream; the second list (if present) is the
# follow-up turn's stream after a tool result.
_SCRIPTED_STREAMS: list[list[ProviderStreamPiece]] = []


def push_scripted_stream(pieces: list[ProviderStreamPiece]) -> None:
    """Append a turn's pieces to the script. Tests usually push 1
    or 2 sub-streams (one per LLM call inside the tool-use loop)."""
    _SCRIPTED_STREAMS.append(list(pieces))


def reset_script() -> None:
    """Drop all scripted streams. Tests call this in their setup."""
    _SCRIPTED_STREAMS.clear()


class FakeProvider:
    """Implements the ``Provider`` Protocol with scripted pieces."""

    name = "fake"
    model = "fake-model-1"

    def __init__(self, *, name: str = "fake", model: str = "fake-model-1"):
        self.name = name
        self.model = model

    async def stream(
        self,
        *,
        messages: list[dict],
        tools: list[dict],
        system_prompt: str,
    ) -> AsyncIterator[ProviderStreamPiece]:
        if not _SCRIPTED_STREAMS:
            raise RuntimeError(
                "FakeProvider: no scripted streams pushed. Call "
                "push_scripted_stream(...) in your test setup."
            )
        pieces = _SCRIPTED_STREAMS.pop(0)
        for piece in pieces:
            yield piece


__all__ = ["FakeProvider", "push_scripted_stream", "reset_script"]
