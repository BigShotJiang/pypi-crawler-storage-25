"""Per-provider chat adapters. Each provider implements the
``Provider`` Protocol from ``base.py``; the orchestrator picks the
adapter at turn time based on the user's configured LLM provider."""
