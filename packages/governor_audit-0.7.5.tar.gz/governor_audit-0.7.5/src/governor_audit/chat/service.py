"""Chat turn orchestrator.

``run_turn(...)`` consumes a conversation history + a new user message
and yields a stream of typed ``ChatEvent`` objects:

  Text chunks → ``TextEvent``
  LLM-initiated tool calls → ``ToolCallEvent`` + ``ToolResultEvent``
  Per-turn cost from provider usage metadata → ``CostEvent``
  End-of-turn signal → ``DoneEvent``

The route handler in ``web/routes/chat.py`` consumes this generator
and emits one SSE ``data:`` line per event.

Each tool call routes through ``chat.tools_adapter.invoke_mcp_tool``
which delegates to the spec-152 MCP tool functions in-process. The
chat module owns no DB / network state of its own.
"""

from __future__ import annotations

import asyncio
import logging
import os
from typing import AsyncIterator

from governor_audit.chat.events import (
    ChatEvent,
    CostEvent,
    DoneEvent,
    TextEvent,
    ToolCallEvent,
    ToolResultEvent,
)
from governor_audit.chat import session_ledger
from governor_audit.chat.pricing import (
    cost_for_turn,
    estimate_minimum_turn_cost,
    would_exceed_cap,
)
from governor_audit.chat.providers.base import Provider, ProviderStreamPiece
from governor_audit.chat.system_prompt import render_system_prompt
from governor_audit.chat.tools_adapter import (
    build_tool_descriptors,
    invoke_mcp_tool,
    summarise_tool_result,
)
from governor_audit.chat.transcript import ChatTurnRequest

logger = logging.getLogger("governor_audit.chat.service")


# Cap on how many tool-use loops we'll run before forcing the
# assistant to finalise. Defence against runaway loops that would
# burn the cap silently before any visible text.
_MAX_TOOL_USE_ITERATIONS = 8


async def run_turn(
    request: ChatTurnRequest,
    *,
    config,
    provider: Provider | None = None,
) -> AsyncIterator[ChatEvent]:
    """Drive one chat turn end-to-end.

    Arguments:
      request: validated ``ChatTurnRequest`` from the client.
      config: ``AuditConfig`` - used for project_id, region, the
        LLM provider + model + cap settings.
      provider: optional injection for tests. Production code passes
        None and we build the configured provider from ``config.llm``.

    Yields ``ChatEvent`` instances. Closes with exactly one
    ``DoneEvent`` regardless of which path was taken.
    """
    cap_usd = float(getattr(config.llm, "chat_session_cap_usd", 1.0) or 0.0)
    max_output_tokens = int(getattr(config.llm, "max_tokens", 4096) or 4096)

    # Read the running session total from the server-side ledger.
    # Browser-supplied numbers are NOT trusted - a tampered client
    # could send 0 forever and defeat the cap (C4 audit finding).
    session_total = session_ledger.get_total(request.session_id)

    # Cost-cap precheck - refuse to issue any LLM call if we'd
    # exceed the cap on this turn's WORST-CASE budget (input tokens
    # we can estimate + the max output the model is allowed to emit).
    # Output rate on Gemini Pro is 4× input; ignoring it lets a turn
    # cross the cap by the full max-tokens budget (C5 audit finding).
    estimated_input = _estimate_input_tokens(request)
    min_cost = estimate_minimum_turn_cost(
        provider=config.llm.provider,
        model=config.llm.model,
        estimated_input_tokens=estimated_input,
        estimated_output_tokens=max_output_tokens,
    )
    if would_exceed_cap(
        session_total_usd=session_total,
        estimated_min_turn_cost=min_cost,
        cap_usd=cap_usd,
    ):
        yield DoneEvent(finish_reason="cost_cap")
        return

    # Build provider (production path) or accept injected (test path).
    if provider is None:
        try:
            provider = _build_provider(config)
        except Exception as exc:  # noqa: BLE001
            logger.exception("chat: failed to build provider")
            yield DoneEvent(
                finish_reason="provider_error",
                error_message=f"Could not build LLM provider: {exc}"[:200],
            )
            return

    # Compose the audit-neutral message list. Re-tokenises per turn
    # (FR-007 - stateless server, no persistence).
    messages = _build_messages(request)
    tools = build_tool_descriptors()
    scan_summary = _scan_summary_line()
    system_prompt = render_system_prompt(
        project_id=config.gcp_project_id,
        region=config.bigquery_region,
        scan_summary=scan_summary,
        tool_descriptors=tools,
    )

    # ``session_total`` was already read from the ledger above and
    # reflects the user's running spend BEFORE this turn. Tokens
    # below accumulate per-CALL: each tool-use iteration is a
    # separate LLM API invocation that Gemini bills independently
    # for its full prompt - summing per-call counts is the right
    # answer for "what did the user pay" (not double-counting; the
    # API call genuinely reprocessed the conversation prefix).
    turn_cost_running = 0.0
    in_tokens_total = 0
    out_tokens_total = 0

    for _iteration in range(_MAX_TOOL_USE_ITERATIONS):
        had_tool_calls = False
        # Each record captures call_id / name / args / result /
        # provider_extras so the follow-up turn can replay the
        # assistant's tool-call message with whatever opaque fields
        # the provider requires (e.g. Gemini's thought_signature).
        tool_call_records: list[dict] = []

        try:
            piece_iter: AsyncIterator[ProviderStreamPiece] = provider.stream(
                messages=messages,
                tools=tools,
                system_prompt=system_prompt,
            )
        except Exception as exc:  # noqa: BLE001
            logger.exception("chat: provider.stream raised before yielding")
            yield DoneEvent(
                finish_reason="provider_error",
                error_message=str(exc)[:200],
            )
            return

        try:
            async for piece in piece_iter:
                if piece.kind == "text" and piece.text:
                    yield TextEvent(chunk=piece.text)
                elif piece.kind == "tool_call":
                    had_tool_calls = True
                    yield ToolCallEvent(
                        tool_name=piece.tool_name,
                        arguments=dict(piece.tool_arguments or {}),
                        call_id=piece.tool_call_id,
                    )
                    # Invoke the MCP tool off the asyncio loop.
                    result = await asyncio.to_thread(
                        invoke_mcp_tool, piece.tool_name, dict(piece.tool_arguments or {})
                    )
                    is_error = bool(result.get("code"))  # ToolError shape has ``code``
                    summary = summarise_tool_result(piece.tool_name, result)
                    yield ToolResultEvent(
                        call_id=piece.tool_call_id,
                        output_summary=summary,
                        output_json=result,
                        is_error=is_error,
                    )
                    tool_call_records.append({
                        "call_id": piece.tool_call_id,
                        "name": piece.tool_name,
                        "arguments": dict(piece.tool_arguments or {}),
                        "result": result,
                        "provider_extras": dict(piece.provider_extras or {}),
                    })
                elif piece.kind == "usage":
                    in_tokens_total += piece.input_tokens
                    out_tokens_total += piece.output_tokens
                    turn_cost_running = cost_for_turn(
                        provider=config.llm.provider,
                        model=config.llm.model,
                        input_tokens=in_tokens_total,
                        output_tokens=out_tokens_total,
                    )
                elif piece.kind == "stop":
                    # End of this LLM call. If it asked for tool calls,
                    # we need to feed the results back and loop again;
                    # otherwise we're done.
                    pass
        except Exception as exc:  # noqa: BLE001
            logger.exception("chat: provider stream raised mid-stream")
            # Persist any partial cost we did accumulate - the provider
            # may have billed us for the tokens before the error fired.
            if turn_cost_running > 0:
                session_ledger.add(request.session_id, turn_cost_running)
            yield DoneEvent(
                finish_reason="provider_error",
                error_message=str(exc)[:200],
            )
            return

        if not had_tool_calls:
            # Final turn - commit the cost to the server-side ledger
            # before emitting done. The browser display is informational;
            # the cap enforcement reads from the ledger on next turn.
            session_total = session_ledger.add(
                request.session_id, turn_cost_running
            )
            yield CostEvent(
                turn_cost_usd=turn_cost_running,
                session_total_usd=session_total,
                session_cap_usd=cap_usd if cap_usd > 0 else None,
                input_tokens=in_tokens_total,
                output_tokens=out_tokens_total,
            )
            yield DoneEvent(finish_reason="stop")
            return

        # Append the assistant's tool calls + the tool results to the
        # message list so the next loop iteration can continue.
        # ``arguments`` carries the real LLM-supplied call args (was
        # mistakenly empty before - meant the follow-up turn lost
        # the LLM's intent). ``provider_extras`` round-trips
        # provider-specific opaque fields (e.g. Gemini's
        # ``thought_signature``) the API requires on the matching
        # function_call Part.
        messages.append({
            "role": "assistant",
            "tool_calls": [
                {
                    "id": rec["call_id"],
                    "name": rec["name"],
                    "arguments": rec["arguments"],
                    "provider_extras": rec["provider_extras"],
                }
                for rec in tool_call_records
            ],
        })
        for rec in tool_call_records:
            messages.append({
                "role": "tool",
                "tool_call_id": rec["call_id"],
                "name": rec["name"],
                "content": rec["result"],
            })

        # Cost-cap mid-loop check - if a long tool-use loop has driven
        # the session over the cap, stop without another LLM call and
        # persist what we've spent.
        if cap_usd > 0 and (session_total + turn_cost_running) >= cap_usd:
            session_total = session_ledger.add(
                request.session_id, turn_cost_running
            )
            yield CostEvent(
                turn_cost_usd=turn_cost_running,
                session_total_usd=session_total,
                session_cap_usd=cap_usd,
                input_tokens=in_tokens_total,
                output_tokens=out_tokens_total,
            )
            yield DoneEvent(finish_reason="cost_cap")
            return

    # Hit the iteration cap - persist what we've spent.
    session_total = session_ledger.add(request.session_id, turn_cost_running)
    yield CostEvent(
        turn_cost_usd=turn_cost_running,
        session_total_usd=session_total,
        session_cap_usd=cap_usd if cap_usd > 0 else None,
        input_tokens=in_tokens_total,
        output_tokens=out_tokens_total,
    )
    yield DoneEvent(
        finish_reason="tool_error",
        error_message=(
            f"Tool-use loop exceeded {_MAX_TOOL_USE_ITERATIONS} iterations. "
            "Reset the conversation and rephrase the question."
        ),
    )


def _build_messages(request: ChatTurnRequest) -> list[dict]:
    """Translate ``ChatTurnRequest`` history into the audit-neutral
    message shape providers consume. Tool calls + results from prior
    turns are preserved so the model has full context."""
    out: list[dict] = []
    for msg in request.history:
        if msg.role == "user":
            out.append({"role": "user", "content": msg.content})
        elif msg.role == "assistant":
            # Replay any text content first, then tool calls + results.
            if msg.content:
                out.append({"role": "assistant", "content": msg.content})
            if msg.tool_calls:
                out.append({
                    "role": "assistant",
                    "tool_calls": [
                        {
                            "id": f"hist-{i}",
                            "name": tc.tool_name,
                            "arguments": tc.arguments,
                        }
                        for i, tc in enumerate(msg.tool_calls)
                    ],
                })
                for i, tc in enumerate(msg.tool_calls):
                    out.append({
                        "role": "tool",
                        "tool_call_id": f"hist-{i}",
                        "name": tc.tool_name,
                        "content": tc.output_json,
                    })
    out.append({"role": "user", "content": request.user_message})
    return out


def _estimate_input_tokens(request: ChatTurnRequest) -> int:
    """Crude estimate for the cap precheck - 1 token ≈ 4 chars. Good
    enough to spot an obviously-over-cap turn before any LLM call."""
    total_chars = len(request.user_message)
    for msg in request.history:
        total_chars += len(getattr(msg, "content", "") or "")
        for tc in getattr(msg, "tool_calls", None) or []:
            total_chars += len(str(tc.arguments)) + len(str(tc.output_json))
    return max(50, total_chars // 4)


def _build_provider(config) -> Provider:
    """Factory - picks the adapter for the configured provider.

    MVP supports Gemini only. Anthropic + OpenAI land in a follow-up
    spec; this raises ``NotImplementedError`` for now.
    """
    name = (config.llm.provider or "").strip().lower()
    api_key = (config.llm.api_key or "").strip()
    if not api_key:
        # Defence-in-depth - the route should 401 before reaching here.
        raise RuntimeError("LLM API key not configured.")

    # Test seam - env var unlocks the fake provider for integration
    # tests that don't want to call a real LLM.
    if os.environ.get("AUDIT_CHAT_FAKE_PROVIDER") == "1":
        from governor_audit.chat.providers.fake import FakeProvider

        return FakeProvider()

    if name == "gemini":
        from governor_audit.chat.providers.gemini import GeminiProvider

        return GeminiProvider(api_key=api_key, model=config.llm.model)

    raise NotImplementedError(
        f"Provider {name!r} is not yet supported by the chat surface. "
        "Spec 153 MVP ships Gemini only; Anthropic + OpenAI are a "
        "follow-up. Switch your LLM provider in /admin/settings/llm."
    )


def _scan_summary_line() -> str:
    """One-line description of the latest scan, used in the system
    prompt so the LLM cites freshness. Falls back gracefully if no
    scan has succeeded yet."""
    try:
        from governor_audit.mcp.tools.scan import scan_status

        result = scan_status()
        # ``scan_status`` returns either ``ScanStatusOut`` or ``ToolError``.
        if hasattr(result, "in_progress"):
            if result.in_progress:
                return (
                    f"A scan is currently in progress "
                    f"(phase: {result.current_phase or 'starting'})."
                )
            if result.latest_succeeded_scan is not None:
                latest = result.latest_succeeded_scan
                return (
                    f"Latest successful scan: {latest.scan_id} "
                    f"({latest.lookback_days}-day lookback, "
                    f"{latest.fetched_job_count} jobs fetched)."
                )
            return "No successful scan yet."
        return "Scan status unavailable."
    except Exception:  # noqa: BLE001
        logger.debug("chat: scan summary lookup failed; using fallback", exc_info=True)
        return "Scan status unavailable."


__all__ = ["run_turn"]
