"""Adapter - wraps the spec-152 MCP tools as LLM-callable functions.

The LLM SDK wants:
  - A list of tool **descriptors** (name, description, JSON schema for
    arguments).
  - A way to **invoke** a tool by name with the LLM's argument blob.

We get both for free from spec 152: each MCP tool's input Pydantic
model gives us the JSON schema; the function itself is the invoker.

This file is the only place the LLM's tool surface meets the audit's
read-only tool surface. The static-AST check in
``tests/unit/chat/test_no_persistence.py`` keeps drift impossible -
adding any new tool path here that isn't a spec-152 import will fail
the build.
"""

from __future__ import annotations

import logging
from typing import Any, Callable

from pydantic import BaseModel

from governor_audit.mcp.schemas import (
    CohortForTableIn,
    CostComparedToPreviousPeriodIn,
    CostForDayIn,
    DailyCostSummaryIn,
    FindJobsByDestinationIn,
    FindJobsWithRuleIn,
    LayoutForTableIn,
    ListLayoutsIn,
    MethodologyIn,
    OpportunitiesForTableIn,
    RecentFailuresIn,
    SearchJobsIn,
    TableSummaryIn,
    ToolError,
    TopCostDriversIn,
    TopOpportunitiesIn,
    TopUsersByCostIn,
    TopUsersByRuleCountIn,
    UserWorkloadSummaryIn,
    WorstOffendersPerRuleIn,
)

logger = logging.getLogger("governor_audit.chat.tools_adapter")


# Map of MCP tool name → (input model, callable, one-line description).
# Descriptions come from the spec-152 contracts; keeping them inline
# here so the chat tool descriptors stay self-contained.
def _build_registry() -> dict[str, tuple[type[BaseModel], Callable[[Any], Any], str]]:
    # Lazy imports - the tool-body modules pull in SQLAlchemy + the audit's
    # ORM models. We don't want to pay that cost on module import; we
    # pay it once on the first tool-descriptor build (during the first
    # chat turn) and then cache the registry at module scope.
    from governor_audit.mcp.tools.cost_drivers import list_top_cost_drivers
    from governor_audit.mcp.tools.failures_and_cohort import (
        cohort_for_table,
        recent_failures,
    )
    from governor_audit.mcp.tools.layout import (
        layout_recommendation_for_table,
        list_layout_recommendations,
    )
    from governor_audit.mcp.tools.methodology import methodology
    from governor_audit.mcp.tools.opportunities import (
        find_jobs_with_rule,
        list_top_opportunities,
    )
    from governor_audit.mcp.tools.people import (
        top_users_by_cost,
        top_users_by_rule_count,
        user_workload_summary,
    )
    from governor_audit.mcp.tools.rule_analytics import (
        rule_summary,
        worst_offenders_per_rule,
    )
    from governor_audit.mcp.tools.search import (
        find_jobs_by_destination,
        search_jobs,
    )
    from governor_audit.mcp.tools.tables_and_workload import (
        audit_config_summary,
        dataset_storage_summary,
        dbt_origin_summary,
        opportunities_for_table,
        table_summary,
        workload_breakdown,
    )
    from governor_audit.mcp.tools.temporal import (
        cost_compared_to_previous_period,
        cost_for_day,
        daily_cost_summary,
    )

    return {
        "list_top_opportunities": (
            TopOpportunitiesIn,
            list_top_opportunities,
            "Top-N active opportunities ranked by aggregated cost across the whole logical job (destination_table for builds, query_hash for consumption). Filter by opportunity_type or min_severity.",
        ),
        "list_top_cost_drivers": (
            TopCostDriversIn,
            list_top_cost_drivers,
            "Top-N logical jobs by aggregated cost regardless of whether they have findings. Optional workload_kind filter ('build' or 'consumption').",
        ),
        "find_jobs_with_rule": (
            FindJobsWithRuleIn,
            find_jobs_with_rule,
            "Logical jobs that fired a specific detection rule (e.g. 'slot_contention', 'select_star'). Optional since_days window (capped at 180).",
        ),
        "layout_recommendation_for_table": (
            LayoutForTableIn,
            layout_recommendation_for_table,
            "Partition + cluster recommendation for one destination table, including the apply SQL, rollback steps, ranked candidate columns, caveats, and BigQuery's own second-opinion if available.",
        ),
        "list_layout_recommendations": (
            ListLayoutsIn,
            list_layout_recommendations,
            "Every persisted partition + cluster recommendation from the latest scan, ranked by window cost descending. min_size_gb defaults to 10.",
        ),
        "scan_status": (
            _NoArgs,
            _call_scan_status,
            "Current scan in progress (phase, started_at) plus the most recent successful scan summary. Empty response is valid - means the audit is installed but never scanned.",
        ),
        "methodology": (
            MethodologyIn,
            methodology,
            "Calculation methodology for a named metric. Returns the same explanation the /methodology web page shows.",
        ),
        "cohort_for_table": (
            CohortForTableIn,
            cohort_for_table,
            "Every cached execution of one destination_table grouped by query version (normalized_literals hash). Each version returns first/last seen, execution count, total cost, and rules fired/resolved relative to the previous version.",
        ),
        "recent_failures": (
            RecentFailuresIn,
            recent_failures,
            "Failed BigQuery jobs in the scan window, grouped by query body, ranked by total slot-ms wasted. Each row has the BQ error reason, failure count, and earliest/latest occurrence.",
        ),
        # ── Cluster A: Temporal ────────────────────────────────────
        "cost_for_day": (
            CostForDayIn,
            cost_for_day,
            "Total BigQuery cost for a single UTC day broken down by build/consumption/other workload, plus the count of distinct flagged jobs. Accepts ISO 'YYYY-MM-DD' or 'today' / 'yesterday'.",
        ),
        "daily_cost_summary": (
            DailyCostSummaryIn,
            daily_cost_summary,
            "Day-by-day cost / bytes / slot-ms / job count for the last N days (default 7, max 180). Days with zero executions are skipped. Use for 'cost trend last week' style questions.",
        ),
        "cost_compared_to_previous_period": (
            CostComparedToPreviousPeriodIn,
            cost_compared_to_previous_period,
            "Compare cost between the most-recent N days and the N days immediately before that. Returns both periods plus delta (absolute USD + percent). 'Is spend trending up or down?' style answer.",
        ),
        # ── Cluster B: People ──────────────────────────────────────
        "top_users_by_cost": (
            TopUsersByCostIn,
            top_users_by_cost,
            "Ranking of user_email principals by aggregated cost across all their cached jobs. Includes flagged-job count per user. Service accounts (dbt / scheduled) show up alongside human users.",
        ),
        "top_users_by_rule_count": (
            TopUsersByRuleCountIn,
            top_users_by_rule_count,
            "For one detection rule (e.g. 'slot_contention'), rank users by the number of affected tables their jobs tripped the rule on.",
        ),
        "user_workload_summary": (
            UserWorkloadSummaryIn,
            user_workload_summary,
            "Deep dive on a single user_email: total cost, executions, dbt vs ad-hoc split, top affected tables, and which detection rules their jobs trip.",
        ),
        # ── Cluster C: Filter / Search ────────────────────────────
        "search_jobs": (
            SearchJobsIn,
            search_jobs,
            "Multi-criteria search over cached BigQueryJob rows. All filters optional: min/max cost / bytes / duration; statement_type; user_email; cache_hit; SQL substring (case-insensitive); since_days window. Ranked by cost desc.",
        ),
        "find_jobs_by_destination": (
            FindJobsByDestinationIn,
            find_jobs_by_destination,
            "All cached jobs that wrote to a specific destination_table ('project.dataset.table'). Returns rows ranked by creation_time desc plus total executions / total cost.",
        ),
        # ── Cluster D: Rule analytics ─────────────────────────────
        "rule_summary": (
            _NoArgs,
            _call_rule_summary,
            "For every detection rule with ≥1 active opportunity, return the count of opps, total estimated cost, and the top-3 affected tables. Use for 'what's broken and where?' overview questions.",
        ),
        "worst_offenders_per_rule": (
            WorstOffendersPerRuleIn,
            worst_offenders_per_rule,
            "For one detection rule, return the affected tables ranked by aggregated cost (not the rule's hardcoded estimate). Use to find the most expensive tables tripping a specific rule.",
        ),
        # ── Cluster E: Table-level ────────────────────────────────
        "opportunities_for_table": (
            OpportunitiesForTableIn,
            opportunities_for_table,
            "Every active opportunity for one affected_table, split into issues vs suggestions.",
        ),
        "table_summary": (
            TableSummaryIn,
            table_summary,
            "Single-table card: total cost, executions, distinct query versions, days-with-executions, latest execution time, issue + suggestion counts, layout-recommendation status.",
        ),
        # ── Cluster F: Workload ───────────────────────────────────
        "workload_breakdown": (
            _NoArgs,
            _call_workload_breakdown,
            "Total scan-window cost split by workload classification (build / consumption / other) with percentages.",
        ),
        "dbt_origin_summary": (
            _NoArgs,
            _call_dbt_origin_summary,
            "Cost split between dbt-originated jobs and everything else, plus the top 5 non-dbt users by cost.",
        ),
        # ── Cluster H: Storage ────────────────────────────────────
        "dataset_storage_summary": (
            _NoArgs,
            _call_dataset_storage_summary,
            "Per-dataset storage rollup: billing model, active + long-term bytes (logical and physical), table count, monthly storage cost in USD, compression ratio.",
        ),
        # ── Cluster I: Config ─────────────────────────────────────
        "audit_config_summary": (
            _NoArgs,
            _call_audit_config_summary,
            "The active audit configuration: GCP project, region, billing project, lookback days, scan defaults, enabled / disabled detection rules, LLM provider/model, audit version.",
        ),
    }


class _NoArgs(BaseModel):
    """Sentinel empty input for tools that take no arguments
    (currently just ``scan_status``)."""


def _call_scan_status(_payload: _NoArgs):
    from governor_audit.mcp.tools.scan import scan_status
    return scan_status()


def _call_rule_summary(_payload: _NoArgs):
    from governor_audit.mcp.tools.rule_analytics import rule_summary
    return rule_summary()


def _call_workload_breakdown(_payload: _NoArgs):
    from governor_audit.mcp.tools.tables_and_workload import workload_breakdown
    return workload_breakdown()


def _call_dbt_origin_summary(_payload: _NoArgs):
    from governor_audit.mcp.tools.tables_and_workload import dbt_origin_summary
    return dbt_origin_summary()


def _call_dataset_storage_summary(_payload: _NoArgs):
    from governor_audit.mcp.tools.tables_and_workload import dataset_storage_summary
    return dataset_storage_summary()


def _call_audit_config_summary(_payload: _NoArgs):
    from governor_audit.mcp.tools.tables_and_workload import audit_config_summary
    return audit_config_summary()


# Cached registry - built once on first access. Tests can reset by
# calling ``_reset_registry_cache()``.
_REGISTRY: dict[str, tuple[type[BaseModel], Callable[[Any], Any], str]] | None = None


def _get_registry() -> dict[str, tuple[type[BaseModel], Callable[[Any], Any], str]]:
    global _REGISTRY
    if _REGISTRY is None:
        _REGISTRY = _build_registry()
    return _REGISTRY


def _reset_registry_cache() -> None:
    """Tests only - drop the cached registry so a fresh build runs
    on next access."""
    global _REGISTRY
    _REGISTRY = None


def build_tool_descriptors() -> list[dict[str, Any]]:
    """Return a JSON-Schema-shaped list of tool descriptors that LLM
    SDKs accept. The shape is provider-neutral:

        [
            {
                "name": "list_top_opportunities",
                "description": "Top-N active opportunities …",
                "parameters": <pydantic JSON schema>,
            },
            ...
        ]

    Each provider adapter wraps this list in its SDK's preferred
    container (Gemini's ``tools=[{"function_declarations": [...]}]``,
    Anthropic's ``tools=[{"name", "description", "input_schema"}]``,
    etc.).
    """
    out: list[dict[str, Any]] = []
    for name, (input_model, _func, description) in _get_registry().items():
        out.append(
            {
                "name": name,
                "description": description,
                "parameters": input_model.model_json_schema(),
            }
        )
    return out


def invoke_mcp_tool(name: str, arguments: dict) -> dict[str, Any]:
    """Look the tool up by name, validate ``arguments`` into the right
    input model, call the function, return the result serialised to
    JSON-friendly dict.

    On any failure (unknown tool, validation error, tool returns
    ``ToolError``) the return value is still a dict - keeping the LLM
    seeing a consistent shape and letting it phrase the error to the
    user naturally.
    """
    registry = _get_registry()
    entry = registry.get(name)
    if entry is None:
        logger.warning("chat: LLM called unknown tool %r", name)
        return ToolError(
            code="internal_error",
            message=f"Unknown tool: {name!r}.",
            remediation=(
                "The LLM picked a tool name not in the audit's registry. "
                "This is usually transient; retrying the question often "
                "resolves it."
            ),
        ).model_dump(mode="json")

    input_model, func, _description = entry

    try:
        # ``_NoArgs`` accepts an empty dict; all others validate their
        # specific shape. Pydantic gives us field-level errors for free.
        payload = input_model.model_validate(arguments or {})
    except Exception as exc:  # noqa: BLE001
        logger.info("chat: tool %s rejected arguments %r: %s", name, arguments, exc)
        return ToolError(
            code="internal_error",
            message=(
                f"Argument validation failed for {name}: "
                f"{str(exc)[:200]}"
            ),
            remediation=(
                "The LLM passed an argument shape the tool doesn't accept. "
                "Rephrase the question or specify the missing fields "
                "explicitly."
            ),
        ).model_dump(mode="json")

    try:
        result = func(payload)
    except Exception as exc:  # noqa: BLE001
        logger.exception("chat: tool %s raised", name)
        return ToolError(
            code="internal_error",
            message=f"{name} raised: {str(exc)[:200]}",
            remediation=(
                "The tool failed unexpectedly. Re-running the question "
                "often resolves it; if not, check the audit logs."
            ),
        ).model_dump(mode="json")

    # MCP tools return either a success Pydantic model or a ToolError.
    # Both have ``.model_dump``.
    if hasattr(result, "model_dump"):
        return result.model_dump(mode="json")
    # Fallback - non-Pydantic returns shouldn't happen but we shouldn't
    # crash if they do.
    return {"value": result}


def summarise_tool_result(name: str, output: dict) -> str:
    """One-line summary for the transcript row header. Best-effort -
    surfaces the most useful field from each tool's output shape."""
    if output.get("code"):  # ToolError shape
        return f"{output['code']}: {output.get('message', '')[:80]}"

    # Per-tool friendly summaries.
    if name == "list_top_opportunities":
        n = len(output.get("opportunities", []))
        return f"{n} opportunit{'y' if n == 1 else 'ies'} (scan {output.get('scan_id', '?')[:8]}…)"
    if name == "list_top_cost_drivers":
        n = len(output.get("rows", []))
        total = output.get("grand_total_cost_usd", 0)
        return f"{n} drivers (${total:.2f} total in window)"
    if name == "find_jobs_with_rule":
        n = len(output.get("rows", []))
        total = output.get("total_matching", 0)
        return f"{n} logical jobs ({total} matching opportunities)"
    if name == "layout_recommendation_for_table":
        partition = output.get("recommended_partition_column") or "-"
        cluster = ", ".join(output.get("cluster_columns") or []) or "-"
        return f"partition={partition}, cluster={cluster}"
    if name == "list_layout_recommendations":
        n = len(output.get("recommendations", []))
        return f"{n} layout recommendations"
    if name == "scan_status":
        if output.get("in_progress"):
            return f"in progress · phase={output.get('current_phase', '?')}"
        latest = output.get("latest_succeeded_scan")
        if latest is None:
            return "no successful scan yet"
        return f"latest scan: {latest.get('scan_id', '?')[:8]}… ({latest.get('lookback_days', '?')}d lookback)"
    if name == "methodology":
        return output.get("title", name)

    return f"{name} returned"


__all__ = [
    "build_tool_descriptors",
    "invoke_mcp_tool",
    "summarise_tool_result",
    "_reset_registry_cache",
]
