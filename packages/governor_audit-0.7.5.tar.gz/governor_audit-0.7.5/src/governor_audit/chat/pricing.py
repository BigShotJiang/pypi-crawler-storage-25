"""Token → USD conversion for the chat surface.

Each provider's published rate card lives in ``KNOWN_RATES``. When the
user's configured model isn't in the table, we fall back to the most
expensive known rate for the provider family and log a warning - the
user should know we're estimating rather than reading exact rates.

Same approach the audit takes for BigQuery's $6.25/TiB on-demand rate
(spec 151 methodology page). Cost figures here drive FR-006 and the
per-session cap enforcement in ``service.run_turn``.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass

logger = logging.getLogger("governor_audit.chat.pricing")


@dataclass(frozen=True)
class RateCard:
    """Per-(provider, model) pricing card in USD per 1M tokens.

    Rates copied from each provider's published price list as of
    May 2026. If a provider changes rates this file is the single
    point of truth to update.
    """

    provider: str
    model: str
    input_per_1m: float   # USD per 1,000,000 input tokens
    output_per_1m: float  # USD per 1,000,000 output tokens


# MVP - Gemini only. Anthropic + OpenAI rate cards land when those
# adapter modules are added.
KNOWN_RATES: dict[tuple[str, str], RateCard] = {
    # Gemini 3.1 Pro Preview, May 2026 published rates.
    # Source: https://ai.google.dev/pricing (verify when this date drifts).
    ("gemini", "gemini-3.1-pro-preview"): RateCard(
        provider="gemini",
        model="gemini-3.1-pro-preview",
        input_per_1m=1.25,
        output_per_1m=5.00,
    ),
    # A cheaper fallback if the user picks an older model.
    ("gemini", "gemini-2.5-flash"): RateCard(
        provider="gemini",
        model="gemini-2.5-flash",
        input_per_1m=0.075,
        output_per_1m=0.30,
    ),
}


# Per-provider "conservative" rate used when the configured model
# isn't in the table. Picks the most-expensive published rate so we
# never *under*-bill the user (they'd be surprised to hit the cap
# later than expected).
_FALLBACK_BY_PROVIDER: dict[str, RateCard] = {
    "gemini": RateCard(
        provider="gemini",
        model="<unknown>",
        input_per_1m=1.25,
        output_per_1m=5.00,
    ),
}


def cost_for_turn(
    *,
    provider: str,
    model: str,
    input_tokens: int,
    output_tokens: int,
) -> float:
    """Return turn cost in USD. Floor at zero so callers can sum
    without worrying about negative drift on weird inputs."""
    rate = KNOWN_RATES.get((provider, model))
    if rate is None:
        rate = _FALLBACK_BY_PROVIDER.get(provider)
        if rate is None:
            logger.warning(
                "chat pricing: unknown provider %r, returning $0 (cap "
                "enforcement may be inaccurate). Add a RateCard to "
                "chat/pricing.py.",
                provider,
            )
            return 0.0
        logger.info(
            "chat pricing: unknown model %r for provider %r - using "
            "conservative fallback rate. Add a RateCard for accurate "
            "billing.",
            model,
            provider,
        )

    in_cost = (input_tokens / 1_000_000) * rate.input_per_1m
    out_cost = (output_tokens / 1_000_000) * rate.output_per_1m
    return max(0.0, in_cost + out_cost)


def estimate_minimum_turn_cost(
    *,
    provider: str,
    model: str,
    estimated_input_tokens: int,
    estimated_output_tokens: int,
) -> float:
    """Conservative upper-bound for the *next* turn's cost, used by
    the cap check before issuing an LLM call.

    Counts BOTH input cost and the worst-case output cost (output
    rate is typically 4× input on Gemini Pro, so omitting it lets a
    turn cross the cap by the full max-tokens budget). Caller passes
    the model's configured ``max_output_tokens`` so the precheck
    matches what the LLM could actually produce.
    """
    return cost_for_turn(
        provider=provider,
        model=model,
        input_tokens=max(0, estimated_input_tokens),
        output_tokens=max(0, estimated_output_tokens),
    )


def would_exceed_cap(
    *,
    session_total_usd: float,
    estimated_min_turn_cost: float,
    cap_usd: float,
) -> bool:
    """True iff issuing this turn would push the session total at-or-
    over the configured cap. ``cap_usd == 0`` disables the cap.

    Uses ``>=`` deliberately - hitting the cap exactly is the same
    user signal as exceeding it (the next turn would tip over), and
    leaving the boundary inclusive prevents a session from sitting
    at exactly $1.00 with the next $0.001 turn slipping through.
    """
    if cap_usd <= 0:
        return False
    return (session_total_usd + estimated_min_turn_cost) >= cap_usd


__all__ = [
    "RateCard",
    "KNOWN_RATES",
    "cost_for_turn",
    "estimate_minimum_turn_cost",
    "would_exceed_cap",
]
