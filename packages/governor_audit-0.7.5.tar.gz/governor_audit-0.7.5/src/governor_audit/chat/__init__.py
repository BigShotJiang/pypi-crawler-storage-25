"""Spec 153 - in-browser chat for governor-audit.

A chat surface inside the audit web UI. When configured with an LLM
key (gated by the existing /admin/settings/llm page), the user can
ask natural-language questions about their audit data; the LLM's
tool surface is exactly the spec-152 MCP tools (in-process function
calls - no stdio detour).

Trust posture:
- Stays loopback-only EXCEPT for the LLM provider call itself, which
  is the entire point of the feature. Egress is opt-in via the
  existing LLM settings page.
- Conversation history is browser-local. Zero chat-content persistence.
- Read-only end-to-end: every LLM tool call routes through the spec-152
  MCP tools, which the static-AST check from spec 152 already pins to
  no-write semantics.
"""
