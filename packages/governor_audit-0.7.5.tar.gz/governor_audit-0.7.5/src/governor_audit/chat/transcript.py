"""Wire shapes for the browser ↔ server message exchange.

The browser sends a ``ChatTurnRequest`` to ``POST /chat/turn`` and the
server streams events back. The conversation history accompanies every
turn (the server is stateless across turns - FR-007 / SC-006).
"""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, Field


class ToolCallRecord(BaseModel):
    """One tool call + its result as it appears in the transcript.

    Surfaced to the user via an expandable row (FR-005).
    """

    tool_name: str
    arguments: dict
    output_summary: str = Field(
        description="One-line summary of the tool result for the row header."
    )
    output_json: dict = Field(
        description="Full tool output payload, available on row expand."
    )
    is_error: bool = Field(
        default=False,
        description="True when the tool returned a ToolError instead of success.",
    )


class TranscriptUserMessage(BaseModel):
    role: Literal["user"] = "user"
    content: str


class TranscriptAssistantMessage(BaseModel):
    role: Literal["assistant"] = "assistant"
    content: str
    tool_calls: list[ToolCallRecord] = Field(default_factory=list)
    turn_cost_usd: float = 0.0
    cost_paid_in_input_tokens: int = 0
    cost_paid_in_output_tokens: int = 0


class ChatTurnRequest(BaseModel):
    """Body of POST /chat/turn.

    Conversation content is stateless on the server (every POST
    carries the full history), but ``session_id`` keys a small
    server-side cost ledger (see ``chat.session_ledger``) so the
    per-session cap can't be defeated by a tampered client. The
    browser mints a UUID on chat-page load and reuses it for every
    turn until the user presses 'New chat'.
    """

    session_id: str = Field(
        min_length=8, max_length=128,
        description="Browser-minted session identifier. Required - "
                    "anchors the server-side cost-cap ledger.",
    )
    history: list[TranscriptUserMessage | TranscriptAssistantMessage] = Field(
        default_factory=list
    )
    user_message: str


__all__ = [
    "ToolCallRecord",
    "TranscriptUserMessage",
    "TranscriptAssistantMessage",
    "ChatTurnRequest",
]
