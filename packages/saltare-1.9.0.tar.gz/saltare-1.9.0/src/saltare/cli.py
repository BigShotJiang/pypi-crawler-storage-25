"""`saltare` command-line entry point."""

from __future__ import annotations

import argparse
import importlib
import os
import sys
from typing import Any


def _is_saltare_main_entry() -> bool:
    """True iff this process was started as a saltare CLI invocation
    (either the pip-installed `saltare` console script, or `python -m
    saltare`). Importing `saltare.cli` from a third-party script must
    NOT trigger the re-exec — that would surprise everyone."""
    arg0 = sys.argv[0] if sys.argv else ""
    base = os.path.basename(arg0)
    # pip's console_scripts wrapper is named exactly "saltare" (or
    # "saltare-script.py" on Windows). Strip a trailing extension to
    # match both forms.
    base_stem = base.split(".")[0] if base else ""
    if base_stem == "saltare" or base_stem == "saltare-script":
        return True
    # `python -m saltare` resolves argv[0] to the saltare package's
    # __main__.py, e.g. `/.../site-packages/saltare/__main__.py`.
    if arg0.endswith("__main__.py") and "saltare" in arg0:
        return True
    return False


def _ensure_optimized() -> None:
    """If we're not running with `python -OO` (`sys.flags.optimize >= 2`),
    re-exec ourselves with that flag set. CPython strips both `assert`
    statements and docstrings under `-OO`, which trims the heap by a few
    MiB once FastAPI / Starlette / Pydantic finish importing — those
    libraries carry hundreds of multi-line docstrings each. We also set
    `MALLOC_ARENA_MAX=1` in the re-exec environment so glibc's per-
    thread arena state lands in a single arena from process start
    (calling `mallopt(M_ARENA_MAX, 1)` later in PyInit__core only
    affects future allocations, not arenas already populated by
    CPython's bootstrap).

    Skip the re-exec if the user explicitly opts out via `SALTARE_NO_OPTIMIZE=1`
    (some apps inspect `__doc__` at runtime). Also skip if we've already
    re-execed once (`SALTARE_REEXECED=1`), to avoid an infinite loop in
    bizarre environments where `-OO` doesn't lift `sys.flags.optimize`.
    Finally, skip when this module is imported by code that isn't a
    saltare CLI invocation — re-execing somebody else's script would be
    rude.
    """
    if sys.flags.optimize >= 2:
        return
    if os.environ.get("SALTARE_NO_OPTIMIZE", "").lower() in {"1", "true", "yes"}:
        return
    if os.environ.get("SALTARE_REEXECED") == "1":
        return
    if not _is_saltare_main_entry():
        return
    new_env = os.environ.copy()
    new_env["SALTARE_REEXECED"] = "1"
    new_env["PYTHONOPTIMIZE"] = "2"
    # Bound glibc's per-thread arenas before CPython runs any malloc.
    # Setting it here, before exec, beats calling mallopt() mid-process
    # because the bootstrap allocations themselves stay in one arena.
    new_env.setdefault("MALLOC_ARENA_MAX", "1")
    # CPython faulthandler dumps a stack on segfault / SIGABRT to
    # stderr — invaluable for diagnosing native-extension crashes
    # in production. Free; no measurable cost when nothing crashes.
    new_env.setdefault("PYTHONFAULTHANDLER", "1")
    os.execvpe(
        sys.executable,
        [sys.executable, "-OO", "-m", "saltare"] + sys.argv[1:],
        new_env,
    )


# Re-exec runs as early as possible — before importing `saltare` (which
# pulls _core, the dispatcher, etc.) — so that those imports themselves
# happen under -OO and shed their docstrings. The `_is_saltare_main_entry`
# gate makes this safe for third-party callers who import `saltare.cli`
# without intending to run it.
_ensure_optimized()


from saltare import __version__, run  # noqa: E402


def _load_app(target: str) -> Any:
    module_name, sep, attr = target.partition(":")
    if not sep or not module_name or not attr:
        raise SystemExit(
            f"invalid app target: {target!r} (expected 'module:attribute')"
        )
    sys.path.insert(0, "")
    try:
        module = importlib.import_module(module_name)
    except ImportError as exc:
        raise SystemExit(
            f"cannot import module {module_name!r}: {exc}"
        ) from exc
    try:
        return getattr(module, attr)
    except AttributeError as exc:
        raise SystemExit(
            f"module {module_name!r} has no attribute {attr!r}"
        ) from exc


# Mirrors the recogniser inside `src/zig/server.zig::applyRuntimeKey`.
# Keep the two in sync — this list is the authoritative source for
# documentation; the Zig side is the runtime enforcer.
_RUNTIME_CONFIG_KEYS: dict[str, type] = {
    "rate_limit_per_sec": int,
    "rate_limit_burst": int,
    "max_connections_per_ip": int,
    "max_connection_lifetime_secs": int,
    "access_log": bool,
}


def _check_config(path: str) -> int:
    """Dry-run validate a runtime-config-path file. Returns 0 on clean
    parse, 1 if any line is malformed / has an unknown key / has a
    bad value type. Mirrors the parser in `reloadRuntimeConfig`."""
    try:
        with open(path) as f:
            text = f.read()
    except OSError as exc:
        sys.stderr.write(f"saltare check-config: cannot open {path!r}: {exc}\n")
        return 1
    except UnicodeDecodeError as exc:
        sys.stderr.write(f"saltare check-config: file {path!r} is not valid UTF-8: {exc}\n")
        return 1
    bad = 0
    seen = 0
    for lineno, raw in enumerate(text.splitlines(), start=1):
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        if "=" not in line:
            sys.stderr.write(f"  L{lineno}: missing '=' separator: {line!r}\n")
            bad += 1
            continue
        key, _, value = line.partition("=")
        key = key.strip()
        value = value.strip()
        spec = _RUNTIME_CONFIG_KEYS.get(key)
        if spec is None:
            sys.stderr.write(
                f"  L{lineno}: unknown key {key!r}; valid: "
                f"{sorted(_RUNTIME_CONFIG_KEYS)}\n"
            )
            bad += 1
            continue
        if spec is int:
            try:
                int(value)
            except ValueError:
                sys.stderr.write(f"  L{lineno}: {key} expects int, got {value!r}\n")
                bad += 1
                continue
        elif spec is bool:
            if value not in ("true", "false", "1", "0", "yes", "no"):
                sys.stderr.write(
                    f"  L{lineno}: {key} expects boolean (true/false/1/0/yes/no), "
                    f"got {value!r}\n"
                )
                bad += 1
                continue
        seen += 1
    if bad:
        sys.stderr.write(f"saltare check-config: {bad} error(s), {seen} ok\n")
        return 1
    sys.stderr.write(f"saltare check-config: {seen} key(s) ok in {path}\n")
    return 0


def main(argv: list[str] | None = None) -> None:
    parser = argparse.ArgumentParser(
        prog="saltare",
        description="Low-RAM ASGI HTTP server with a Zig backbone.",
    )
    parser.add_argument(
        "app",
        nargs="?",
        help="ASGI app target as 'module:attr' (e.g. 'main:app').",
    )
    parser.add_argument(
        "--check-config", type=str, default=None, metavar="FILE",
        help="dry-run validate a runtime-config-path file (key=value); exit 0 ok, 1 fail",
    )
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8000)
    parser.add_argument(
        "--header-timeout",
        type=int,
        default=5,
        help="seconds from accept to parsed headers (slowloris guard)",
    )
    parser.add_argument(
        "--keep-alive-timeout",
        type=int,
        default=5,
        help="seconds between requests on a kept-alive connection",
    )
    parser.add_argument(
        "--body-timeout",
        type=int,
        default=30,
        help="seconds from parsed headers to fully received body",
    )
    parser.add_argument(
        "--write-timeout",
        type=int,
        default=30,
        help="maximum seconds in the writing state",
    )
    parser.add_argument(
        "--max-concurrent-connections",
        type=int,
        default=1024,
        help="accepted connections held open at once (overflow is dropped)",
    )
    parser.add_argument(
        "--max-keepalive-requests",
        type=int,
        default=1000,
        help="requests per keep-alive connection before forcing close",
    )
    parser.add_argument(
        "--max-request-body",
        type=int,
        default=1024 * 1024,
        help="largest request body (in bytes) the server will accept",
    )
    parser.add_argument(
        "--shutdown-timeout",
        type=int,
        default=30,
        help="seconds to wait for in-flight requests after SIGTERM/SIGINT",
    )
    parser.add_argument(
        "--uds",
        type=str,
        default=None,
        metavar="PATH",
        help="bind a Unix domain socket at PATH instead of host:port",
    )
    parser.add_argument(
        "--metrics-path",
        type=str,
        default=None,
        metavar="PATH",
        help="serve Prometheus-format metrics at PATH (e.g. '/metrics')",
    )
    parser.add_argument(
        "--access-log",
        action="store_true",
        help="emit one JSON line per completed request to stderr",
    )
    parser.add_argument(
        "--proxy-headers",
        action="store_true",
        help="trust X-Forwarded-For/Proto from upstream proxies",
    )
    parser.add_argument(
        "--ws-keepalive-timeout",
        type=int,
        default=20,
        help="seconds between server-side WebSocket pings (close at 2× this)",
    )
    parser.add_argument(
        "--workers",
        type=int,
        default=1,
        help="number of pre-fork worker processes (1 = single process)",
    )
    parser.add_argument(
        "--health-path",
        type=str,
        default=None,
        metavar="PATH",
        help="answer GETs at PATH (e.g. '/healthz') with 200 'ok' from "
             "Zig — no Python dispatch (k8s probe-friendly)",
    )
    parser.add_argument(
        "--cors-preflight-allow-all",
        action="store_true",
        help="answer OPTIONS-with-Origin from Zig with permissive CORS "
             "headers — skips Python for browser preflight",
    )
    parser.add_argument(
        "--rate-limit-per-sec",
        type=int,
        default=0,
        metavar="N",
        help="per-IP request rate ceiling (0 = disabled). Token bucket "
             "implemented in Zig; over-rate IPs get 429 before Python.",
    )
    parser.add_argument(
        "--rate-limit-burst",
        type=int,
        default=100,
        metavar="N",
        help="burst ceiling for the per-IP rate limiter (default 100)",
    )
    parser.add_argument(
        "--tracemalloc-path",
        type=str,
        default=None,
        metavar="PATH",
        help="enable tracemalloc tracking and serve a top-30 Python "
             "allocation dump at PATH (e.g. '/debug/tracemalloc'). "
             "Diagnostic only — has CPU + RAM cost.",
    )
    parser.add_argument(
        "--favicon-204",
        action="store_true",
        help="answer GET /favicon.ico with 204 No Content from Zig "
             "(skips Python dispatch for browser favicon hits)",
    )
    parser.add_argument(
        "--max-connections-per-ip",
        type=int,
        default=0,
        metavar="N",
        help="per-IP open-connection ceiling (0 = disabled). Over-cap "
             "peers get a TCP-level close at accept time.",
    )
    parser.add_argument(
        "--access-log-path",
        type=str,
        default=None,
        metavar="PATH",
        help="route access-log JSON lines to PATH instead of stderr",
    )
    parser.add_argument(
        "--request-id-header",
        type=str,
        default=None,
        metavar="NAME",
        help="auto-generate an 8-byte hex request ID per request and "
             "echo it as response header NAME (e.g. 'X-Request-ID'). "
             "Apps can read it via scope['x-request-id'].",
    )
    parser.add_argument(
        "--server-timing",
        action="store_true",
        help="emit `Server-Timing: total;dur=<ms>` on every response",
    )
    parser.add_argument(
        "--listen-backlog",
        type=int,
        default=256,
        metavar="N",
        help="`listen(2)` backlog (default 256). Capped by /proc/sys/net/core/somaxconn.",
    )
    parser.add_argument(
        "--tcp-keepidle", type=int, default=0, metavar="SEC",
        help="seconds idle before kernel sends first keepalive probe "
             "(0 = kernel default, usually 7200)",
    )
    parser.add_argument(
        "--tcp-keepintvl", type=int, default=0, metavar="SEC",
        help="seconds between keepalive probes (0 = kernel default, usually 75)",
    )
    parser.add_argument(
        "--tcp-keepcnt", type=int, default=0, metavar="N",
        help="unanswered probes before connection is dropped (0 = kernel default, usually 9)",
    )
    parser.add_argument(
        "--proxy-protocol",
        action="store_true",
        help="parse HAProxy PROXY-protocol v1 (text) or v2 (binary) "
             "header at every accept (required behind L4 LBs like AWS "
             "NLB/ALB, HAProxy, GCP TCP LB)",
    )
    parser.add_argument(
        "--tcp-user-timeout-ms", type=int, default=0, metavar="MS",
        help="TCP_USER_TIMEOUT in milliseconds — caps unacked write "
             "windows for sub-second failure detection (Linux only)",
    )
    parser.add_argument(
        "--auto-raise-nofile",
        action="store_true",
        help="raise the soft RLIMIT_NOFILE to the hard limit at startup",
    )
    parser.add_argument(
        "--max-connection-lifetime", type=int, default=0, metavar="SEC",
        help="hard cap on a single connection's wall-clock lifetime "
             "(seconds; 0 = disabled)",
    )
    parser.add_argument(
        "--tls-session-cache-size", type=int, default=0, metavar="N",
        help="OpenSSL session cache size (0 = disabled). "
             "~20 KiB resident per cached session at peak.",
    )
    parser.add_argument(
        "--startup-request",
        action="store_true",
        help="issue an internal GET / after lifespan startup to warm "
             "FastAPI route compilation / pydantic validators",
    )
    parser.add_argument(
        "--server-header", type=str, default=None, metavar="VALUE",
        help="override the `Server:` response header (empty string omits it entirely)",
    )
    parser.add_argument(
        "--ssl-ca-file", type=str, default=None, metavar="PATH",
        help="CA bundle for client-cert verification (mTLS)",
    )
    parser.add_argument(
        "--ssl-verify-client",
        action="store_true",
        help="require + verify client cert against --ssl-ca-file (mTLS)",
    )
    parser.add_argument(
        "--tcp-fastopen-qlen", type=int, default=0, metavar="N",
        help="TCP_FASTOPEN server-side queue length (0 = disabled)",
    )
    parser.add_argument(
        "--gc-collect-every-n-requests", type=int, default=0, metavar="N",
        help="run gc.collect(0) every N completed dispatches (0 = leave-alone)",
    )
    parser.add_argument(
        "--http-pool-max", type=int, default=128, metavar="N",
        help="max HTTP state objects to pool (0 disables, default 128)",
    )
    parser.add_argument(
        "--http2", action="store_true",
        help="enable HTTP/2 support (ALPN required for TLS, default disabled)",
    )
    parser.add_argument(
        "--response-gzip", action="store_true",
        help="gzip-encode single-shot responses when client sent Accept-Encoding: gzip (lazy libz)",
    )
    parser.add_argument(
        "--response-gzip-min-bytes", type=int, default=512, metavar="N",
        help="don't gzip responses smaller than N bytes (default 512)",
    )
    parser.add_argument(
        "--response-gzip-level", type=int, default=6, metavar="N",
        help="zlib compression level 1-9 (default 6)",
    )
    parser.add_argument(
        "--response-brotli", action="store_true",
        help="negotiate Accept-Encoding: br (single-shot only; needs libbrotli)",
    )
    parser.add_argument(
        "--response-brotli-quality", type=int, default=4, metavar="N",
        help="brotli quality 0-11 (default 4)",
    )
    parser.add_argument(
        "--response-zstd", action="store_true",
        help="negotiate Accept-Encoding: zstd (single-shot only; needs libzstd)",
    )
    parser.add_argument(
        "--response-zstd-level", type=int, default=3, metavar="N",
        help="zstd compression level 1-22 (default 3)",
    )
    parser.add_argument(
        "--request-decompression", action="store_true",
        help="decompress request bodies with Content-Encoding: gzip (capped by --max-request-body)",
    )
    parser.add_argument(
        "--max-request-uri", type=int, default=8192, metavar="N",
        help="reject request-line targets longer than N bytes with 414 (default 8192; 0 disables)",
    )
    parser.add_argument(
        "--max-request-head-bytes", type=int, default=0, metavar="N",
        help="reject request head sections larger than N bytes with 431 (0 = pool-buffer ceiling)",
    )
    parser.add_argument(
        "--latency-histogram", action="store_true",
        help="emit Prometheus saltare_request_duration_seconds_bucket on /metrics",
    )
    parser.add_argument(
        "--traceparent-propagation", action="store_true",
        help="surface W3C Trace Context (traceparent/tracestate) on scope and echo on response",
    )
    parser.add_argument(
        "--reload", action="store_true",
        help="dev autoreload: poll watch dirs, SIGTERM + respawn on change (disables --workers > 1)",
    )
    parser.add_argument(
        "--reload-dir", action="append", metavar="DIR", default=None,
        help="directory to watch for code changes (repeatable; default: cwd)",
    )
    parser.add_argument(
        "--reload-include", action="append", metavar="GLOB", default=None,
        help="fnmatch glob for files to watch (repeatable; default: '*.py')",
    )
    parser.add_argument(
        "--reload-exclude", action="append", metavar="GLOB", default=None,
        help="fnmatch glob to exclude (repeatable; sensible defaults skip __pycache__/.git/etc.)",
    )
    parser.add_argument(
        "--reload-poll-secs", type=float, default=0.5, metavar="SECS",
        help="reloader poll interval in seconds (default 0.5)",
    )
    parser.add_argument(
        "--dispatch-path", type=str, default=None, metavar="PATH",
        help="JSON dispatch-state snapshot endpoint (e.g. /debug/dispatch); off by default",
    )
    parser.add_argument(
        "--runtime-config-path", type=str, default=None, metavar="FILE",
        help="key=value file re-read on SIGHUP to hot-update rate limits / access log",
    )
    parser.add_argument(
        "--dispatch-token", type=str, default=None, metavar="TOKEN",
        help="shared-secret Bearer token gating /debug/dispatch (also reads SALTARE_DISPATCH_TOKEN env)",
    )
    parser.add_argument(
        "--ktls", action="store_true",
        help="enable OpenSSL kTLS (sendfile-over-HTTPS, kernel TLS records; needs OpenSSL >=3.0 + Linux >=4.13)",
    )
    parser.add_argument(
        "--hsts-max-age", type=int, default=0, metavar="SECS",
        help="when >0, emit Strict-Transport-Security: max-age=SECS on every response (RFC 6797; 0 disables)",
    )
    parser.add_argument(
        "--hsts-include-subdomains", action="store_true",
        help="add `includeSubDomains` to the HSTS header (only meaningful with --hsts-max-age)",
    )
    parser.add_argument(
        "--hsts-preload", action="store_true",
        help="add `preload` to the HSTS header (HSTS preload list eligibility — implies includeSubDomains + max-age >= 31536000)",
    )
    parser.add_argument(
        "--drain-path", type=str, default=None, metavar="PATH",
        help="POST/PUT to PATH (e.g. '/admin/drain') flips the worker into graceful drain — Zig-side intercept (no Python dispatch). Pair with --health-path for k8s rolling deploys.",
    )
    parser.add_argument(
        "--drain-wait-seconds", type=int, default=5, metavar="N",
        help="seconds to wait for in-flight requests during drain (default 5)",
    )
    parser.add_argument(
        "--access-log-exclude", action="append", default=None, metavar="PATH",
        help="path (request-target, exact match) to skip from --access-log output (repeatable). Typical use: silence noisy probes like /metrics, /healthz, /favicon.ico without losing app-traffic visibility.",
    )
    parser.add_argument(
        "--ws-reject-log", action="store_true",
        help="emit a single stderr line every time a WebSocket upgrade is rejected (`saltare: ws-reject path=... code=... reason=...`). Diagnoses Channels' Origin / Host / Auth middleware closing connects before `accept()`. Off by default.",
    )
    parser.add_argument(
        "--ws-pump-interval-ms", type=int, default=50, metavar="MS",
        help="interval between forced asyncio-loop pumps for live WebSocket connections (default 50). Lower for sub-50ms `channel_layer.group_send` server-push latency; raise on bandwidth-pinched deployments. Floor 10ms.",
    )
    parser.add_argument(
        "--ws-handshake-timeout", type=float, default=2.0, metavar="SECS",
        help="seconds the WS-upgrade pump waits for the consumer to accept/close (default 2.0). Bump for slow cold-start middleware (long DB warm-up); drop for latency-sensitive deployments.",
    )
    parser.add_argument(
        "--ws-compression-level", type=int, default=6, metavar="N",
        help="WebSocket permessage-deflate level 1-9 (default 6)",
    )
    parser.add_argument(
        "--ws-compression-server-takeover", action="store_true",
        help="enable WS context takeover for better compression on long connections (adds ~8KB per connection)",
    )
    parser.add_argument(
        "--version",
        action="version",
        version=f"saltare {__version__}",
    )
    args = parser.parse_args(argv)

    # `--check-config FILE` is a dry-run for the runtime-config-path file
    # SIGHUP would re-read. Parses every line, reports unknown keys + bad
    # values without starting the server. Exit 0 on clean parse, 1 if any
    # line was unrecognised or numeric values were out of range. Lets ops
    # validate a config push before sending the SIGHUP that activates it.
    if args.check_config:
        sys.exit(_check_config(args.check_config))

    if not args.app:
        parser.error("missing app target (e.g. 'main:app')")

    # v1.7.1 startup banner — one stderr line at boot identifying the
    # server and its version. Sized to coexist with `--access-log`
    # output (no `info:` prefix, no log level), and routed to stderr
    # so it doesn't interleave with stdout-bound app output. Operators
    # who want quieter boots can suppress via `2>/dev/null`.
    sys.stderr.write(
        f"saltare {__version__} — low-RAM ASGI HTTP server (Zig backbone)\n"
    )

    # Guardrail: a one-digit rate limit is almost always a typo. Print a
    # single warning at boot — the user can ignore if intentional.
    if 0 < args.rate_limit_per_sec < 10:
        sys.stderr.write(
            f"saltare: warning: --rate-limit-per-sec={args.rate_limit_per_sec} "
            "is unusually low; double-check this isn't a typo (real values "
            "for HTTP APIs are usually 100+)\n"
        )

    app = _load_app(args.app)
    run(
        app,
        host=args.host,
        port=args.port,
        header_timeout=args.header_timeout,
        keep_alive_timeout=args.keep_alive_timeout,
        body_timeout=args.body_timeout,
        write_timeout=args.write_timeout,
        max_concurrent_connections=args.max_concurrent_connections,
        max_keepalive_requests=args.max_keepalive_requests,
        max_request_body=args.max_request_body,
        shutdown_timeout=args.shutdown_timeout,
        uds_path=args.uds,
        metrics_path=args.metrics_path,
        access_log=args.access_log,
        proxy_headers=args.proxy_headers,
        ws_keepalive_timeout=args.ws_keepalive_timeout,
        workers=args.workers,
        health_path=args.health_path,
        cors_preflight_allow_all=args.cors_preflight_allow_all,
        rate_limit_per_sec=args.rate_limit_per_sec,
        rate_limit_burst=args.rate_limit_burst,
        tracemalloc_path=args.tracemalloc_path,
        favicon_204=args.favicon_204,
        max_connections_per_ip=args.max_connections_per_ip,
        access_log_path=args.access_log_path,
        request_id_header=args.request_id_header,
        server_timing=args.server_timing,
        listen_backlog=args.listen_backlog,
        tcp_keepidle=args.tcp_keepidle,
        tcp_keepintvl=args.tcp_keepintvl,
        tcp_keepcnt=args.tcp_keepcnt,
        proxy_protocol=args.proxy_protocol,
        tcp_user_timeout_ms=args.tcp_user_timeout_ms,
        auto_raise_nofile=args.auto_raise_nofile,
        max_connection_lifetime=args.max_connection_lifetime,
        tls_session_cache_size=args.tls_session_cache_size,
        startup_request=args.startup_request,
        server_header=args.server_header,
        ssl_ca_file=args.ssl_ca_file,
        ssl_verify_client=args.ssl_verify_client,
        tcp_fastopen_qlen=args.tcp_fastopen_qlen,
        gc_collect_every_n_requests=args.gc_collect_every_n_requests,
        http_pool_max=args.http_pool_max,
        http2=args.http2,
        response_gzip=args.response_gzip,
        response_gzip_min_bytes=args.response_gzip_min_bytes,
        response_gzip_level=args.response_gzip_level,
        response_brotli=args.response_brotli,
        response_brotli_quality=args.response_brotli_quality,
        response_zstd=args.response_zstd,
        response_zstd_level=args.response_zstd_level,
        request_decompression=args.request_decompression,
        max_request_uri=args.max_request_uri,
        max_request_head_bytes=args.max_request_head_bytes,
        latency_histogram=args.latency_histogram,
        traceparent_propagation=args.traceparent_propagation,
        reload=args.reload,
        reload_dirs=args.reload_dir,
        reload_includes=args.reload_include,
        reload_excludes=args.reload_exclude,
        reload_poll_secs=args.reload_poll_secs,
        dispatch_path=args.dispatch_path,
        runtime_config_path=args.runtime_config_path,
        # SALTARE_DISPATCH_TOKEN env var wins over a missing CLI flag.
        # CLI args show up in `ps aux` and k8s audit logs; env-driven
        # secrets are the safer default for production.
        dispatch_token=args.dispatch_token or os.environ.get("SALTARE_DISPATCH_TOKEN") or None,
        ktls=args.ktls,
        hsts_max_age=args.hsts_max_age,
        hsts_include_subdomains=args.hsts_include_subdomains,
        hsts_preload=args.hsts_preload,
        drain_path=args.drain_path,
        drain_wait_seconds=args.drain_wait_seconds,
        access_log_exclude=args.access_log_exclude,
        ws_reject_log=args.ws_reject_log,
        ws_pump_interval_ms=args.ws_pump_interval_ms,
        ws_handshake_timeout=args.ws_handshake_timeout,
        ws_compression_level=args.ws_compression_level,
        ws_compression_server_takeover=args.ws_compression_server_takeover,
    )
