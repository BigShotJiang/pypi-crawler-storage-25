#!/usr/bin/env python3
"""
Rewind MCP Server — Expose memory as MCP tools for Claude Code, OpenCode, etc.

Usage:
    # In Claude Code's ~/.claude/settings.json or .mcp.json:
    {
      "mcpServers": {
        "rewind": {
          "command": "python3",
          "args": ["-m", "rewind.integrations.mcp_server"],
          "env": {
            "REWIND_API_URL": "http://localhost:8031",
            "REWIND_API_KEY": "your-api-key"
          }
        }
      }
    }

    # Or run standalone:
    python3 -m rewind.integrations.mcp_server --port 8031

This exposes 6 MCP tools:
    - memory_search: Search across all memory layers
    - memory_store: Store a new memory
    - memory_extract: Extract structured memories from conversation text
    - memory_stats: Get memory system statistics
    - memory_feedback: Report a correction for retrieval feedback
    - graph_traverse: Multi-hop knowledge graph traversal
"""

import json
import os
import sys
from typing import Any

import httpx

# MCP protocol constants
JSONRPC_VERSION = "2.0"
MCP_PROTOCOL_VERSION = "2025-06-18"

REWIND_API_URL = os.environ.get("REWIND_API_URL", "http://localhost:8031")
REWIND_API_KEY = os.environ.get("REWIND_API_KEY", "")


# ── Tool Definitions ─────────────────────────────────────────────────────────

TOOLS = [
    {
        "name": "memory_search",
        "description": (
            "Search persistent memory across all layers (keyword, semantic, graph, "
            "communications, documents). Returns ranked results with source attribution. "
            "Use this before answering questions about prior work, decisions, people, "
            "dates, preferences, or commitments."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": "Natural language search query",
                },
                "limit": {
                    "type": "integer",
                    "description": "Maximum number of results (default: 10)",
                    "default": 10,
                },
                "namespace": {
                    "type": "string",
                    "description": "Optional namespace/path prefix filter",
                },
                "layers": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": (
                        "Optional: specific layers to search "
                        "(l0, l1, l3, l4, l5, l6). Default: all enabled layers."
                    ),
                },
            },
            "required": ["query"],
        },
    },
    {
        "name": "memory_store",
        "description": (
            "Store a new memory. The system auto-routes to the appropriate layer "
            "based on content type (fact → graph, conversation → comms, document → docs)."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "content": {
                    "type": "string",
                    "description": "The memory content to store",
                },
                "metadata": {
                    "type": "object",
                    "description": (
                        "Optional metadata (type, source, tags, timestamp)"
                    ),
                },
                "collection": {
                    "type": "string",
                    "description": (
                        "Optional target collection "
                        "(knowledge, conversations, documents, memory)"
                    ),
                },
            },
            "required": ["content"],
        },
    },
    {
        "name": "memory_extract",
        "description": (
            "Extract structured memories (decisions, facts, commitments) from "
            "conversation text and store them in the knowledge graph and vector layers."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "text": {
                    "type": "string",
                    "description": "Conversation text to extract memories from",
                },
                "context": {
                    "type": "string",
                    "description": "Optional context (e.g., meeting name, date)",
                },
            },
            "required": ["text"],
        },
    },
    {
        "name": "memory_stats",
        "description": (
            "Get memory system statistics: total queries, layer usage, "
            "storage sizes, health status."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {},
        },
    },
    {
        "name": "memory_feedback",
        "description": (
            "Report that a previously retrieved memory was incorrect or misleading. "
            "This feeds the retrieval feedback system, adjusting future scoring."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": "The original query that retrieved bad information",
                },
                "incorrect_source": {
                    "type": "string",
                    "description": "Path or ID of the source that was incorrect",
                },
                "correction": {
                    "type": "string",
                    "description": "What the correct information should be",
                },
            },
            "required": ["query", "incorrect_source", "correction"],
        },
    },
    {
        "name": "graph_traverse",
        "description": (
            "Traverse the knowledge graph from a starting entity. Discovers related "
            "entities via Hebbian-strengthened connections and spreading activation."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "entity": {
                    "type": "string",
                    "description": "Starting entity name",
                },
                "hops": {
                    "type": "integer",
                    "description": "Number of hops to traverse (1-3, default: 2)",
                    "default": 2,
                },
                "min_weight": {
                    "type": "number",
                    "description": (
                        "Minimum edge weight threshold (0.0-1.0, default: 0.5)"
                    ),
                    "default": 0.5,
                },
            },
            "required": ["entity"],
        },
    },
]


# ── API Client ────────────────────────────────────────────────────────────────

class RewindAPIClient:
    """Thin HTTP client for the Rewind API."""

    def __init__(self, base_url: str, api_key: str = ""):
        self.base_url = base_url.rstrip("/")
        self.headers = {"Content-Type": "application/json"}
        if api_key:
            self.headers["Authorization"] = f"Bearer {api_key}"

    def _post(self, path: str, data: dict) -> dict:
        """POST to Rewind API."""
        with httpx.Client(timeout=30.0) as client:
            resp = client.post(
                f"{self.base_url}{path}",
                json=data,
                headers=self.headers,
            )
            resp.raise_for_status()
            return resp.json()

    def _get(self, path: str, params: dict | None = None) -> dict:
        """GET from Rewind API."""
        with httpx.Client(timeout=30.0) as client:
            resp = client.get(
                f"{self.base_url}{path}",
                params=params,
                headers=self.headers,
            )
            resp.raise_for_status()
            return resp.json()

    def search(self, query: str, limit: int = 10,
               namespace: str | None = None,
               layers: list[str] | None = None) -> dict:
        """Search memory."""
        payload: dict[str, Any] = {"query": query, "limit": limit}
        if namespace:
            payload["namespace"] = namespace
        if layers:
            payload["layers"] = layers
        return self._post("/v1/memory/search", payload)

    def store(self, content: str, metadata: dict | None = None,
              collection: str | None = None) -> dict:
        """Store a memory."""
        payload: dict[str, Any] = {"content": content}
        if metadata:
            payload["metadata"] = metadata
        if collection:
            payload["collection"] = collection
        return self._post("/v1/memory/store", payload)

    def extract(self, text: str, context: str | None = None) -> dict:
        """Extract structured memories from text."""
        payload: dict[str, Any] = {"text": text}
        if context:
            payload["context"] = context
        return self._post("/v1/memory/extract", payload)

    def stats(self) -> dict:
        """Get memory stats."""
        return self._get("/v1/memory/stats")

    def feedback(self, query: str, incorrect_source: str,
                 correction: str) -> dict:
        """Report a correction."""
        return self._post("/v1/memory/feedback", {
            "query": query,
            "incorrect_source": incorrect_source,
            "correction": correction,
        })

    def graph_traverse(self, entity: str, hops: int = 2,
                       min_weight: float = 0.5) -> dict:
        """Traverse the knowledge graph."""
        return self._post("/v1/graph/traverse", {
            "entity": entity,
            "hops": hops,
            "min_weight": min_weight,
        })


# ── MCP Protocol Handler ─────────────────────────────────────────────────────

class MCPServer:
    """MCP stdio server for Rewind memory tools."""

    def __init__(self):
        self.client = RewindAPIClient(REWIND_API_URL, REWIND_API_KEY)

    def handle_request(self, request: dict) -> dict:
        """Route MCP JSON-RPC requests."""
        method = request.get("method", "")
        req_id = request.get("id")
        params = request.get("params", {})

        if method == "initialize":
            return self._response(req_id, {
                "protocolVersion": MCP_PROTOCOL_VERSION,
                "capabilities": {"tools": {"listChanged": False}},
                "serverInfo": {
                    "name": "rewind",
                    "version": "0.1.0",
                },
            })

        elif method == "notifications/initialized":
            return None  # No response needed for notifications

        elif method == "tools/list":
            return self._response(req_id, {"tools": TOOLS})

        elif method == "tools/call":
            return self._handle_tool_call(req_id, params)

        elif method == "ping":
            return self._response(req_id, {})

        else:
            return self._error(req_id, -32601, f"Method not found: {method}")

    def _handle_tool_call(self, req_id: Any, params: dict) -> dict:
        """Execute a tool call."""
        tool_name = params.get("name", "")
        args = params.get("arguments", {})

        try:
            if tool_name == "memory_search":
                result = self.client.search(
                    query=args["query"],
                    limit=args.get("limit", 10),
                    namespace=args.get("namespace"),
                    layers=args.get("layers"),
                )
            elif tool_name == "memory_store":
                result = self.client.store(
                    content=args["content"],
                    metadata=args.get("metadata"),
                    collection=args.get("collection"),
                )
            elif tool_name == "memory_extract":
                result = self.client.extract(
                    text=args["text"],
                    context=args.get("context"),
                )
            elif tool_name == "memory_stats":
                result = self.client.stats()
            elif tool_name == "memory_feedback":
                result = self.client.feedback(
                    query=args["query"],
                    incorrect_source=args["incorrect_source"],
                    correction=args["correction"],
                )
            elif tool_name == "graph_traverse":
                result = self.client.graph_traverse(
                    entity=args["entity"],
                    hops=args.get("hops", 2),
                    min_weight=args.get("min_weight", 0.5),
                )
            else:
                return self._error(req_id, -32602, f"Unknown tool: {tool_name}")

            return self._response(req_id, {
                "content": [
                    {
                        "type": "text",
                        "text": json.dumps(result, indent=2, default=str),
                    }
                ],
            })

        except httpx.HTTPStatusError as e:
            return self._response(req_id, {
                "content": [
                    {
                        "type": "text",
                        "text": f"Rewind API error: {e.response.status_code} — {e.response.text}",
                    }
                ],
                "isError": True,
            })
        except Exception as e:
            return self._response(req_id, {
                "content": [
                    {"type": "text", "text": f"Error: {e}"}
                ],
                "isError": True,
            })

    def _response(self, req_id: Any, result: dict) -> dict:
        return {"jsonrpc": JSONRPC_VERSION, "id": req_id, "result": result}

    def _error(self, req_id: Any, code: int, message: str) -> dict:
        return {
            "jsonrpc": JSONRPC_VERSION,
            "id": req_id,
            "error": {"code": code, "message": message},
        }

    def run_stdio(self):
        """Run as MCP stdio server (stdin/stdout JSON-RPC)."""
        for line in sys.stdin:
            line = line.strip()
            if not line:
                continue
            try:
                request = json.loads(line)
                response = self.handle_request(request)
                if response is not None:
                    sys.stdout.write(json.dumps(response) + "\n")
                    sys.stdout.flush()
            except json.JSONDecodeError:
                error = {
                    "jsonrpc": JSONRPC_VERSION,
                    "id": None,
                    "error": {"code": -32700, "message": "Parse error"},
                }
                sys.stdout.write(json.dumps(error) + "\n")
                sys.stdout.flush()


# ── Entry Point ───────────────────────────────────────────────────────────────

def main():
    """Run the Rewind MCP server."""
    import argparse

    parser = argparse.ArgumentParser(description="Rewind MCP Server")
    parser.add_argument(
        "--url", default=REWIND_API_URL,
        help="Rewind API URL (default: $REWIND_API_URL or http://localhost:8031)",
    )
    parser.add_argument(
        "--api-key", default=REWIND_API_KEY,
        help="Rewind API key (default: $REWIND_API_KEY)",
    )
    args = parser.parse_args()

    os.environ["REWIND_API_URL"] = args.url
    os.environ["REWIND_API_KEY"] = args.api_key

    server = MCPServer()
    server.run_stdio()


if __name__ == "__main__":
    main()
