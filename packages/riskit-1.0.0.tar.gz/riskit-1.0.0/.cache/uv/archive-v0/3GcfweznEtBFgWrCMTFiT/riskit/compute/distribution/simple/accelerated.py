from dataclasses import dataclass
from typing import Literal, cast

from riskit.compute.backend.accelerated import JaxUncertainty, JaxUncertaintySamples
from riskit.type import Array, JaxArray, jaxtyped

import jax
import jax.numpy as jnp
import jax.random as jrandom
from jaxtyping import Float, PRNGKeyArray

# TODO: Test that provided RNG is really used


@jaxtyped
@dataclass(kw_only=True)
class JaxGaussian(JaxUncertainty):
    mean: Float[JaxArray, "V D"]
    covariance: Float[JaxArray, "V D D"]
    key: PRNGKeyArray

    @staticmethod
    def create(
        *,
        mean: Float[JaxArray, "V D"] | Float[Array, "V D"],
        covariance: Float[JaxArray, "V D D"] | Float[Array, "V D D"],
        seed: int = 42,
        key: PRNGKeyArray | None = None,
    ) -> "JaxGaussian":
        return JaxGaussian(
            mean=jnp.asarray(mean),
            covariance=jnp.asarray(covariance),
            key=key if key is not None else jrandom.key(seed),
        )

    def sample(self, count: int) -> JaxUncertaintySamples:
        self.key, samples = sample_gaussian(
            key=self.key, mean=self.mean, covariance=self.covariance, count=count
        )

        return samples

    @property
    def shape(self) -> tuple[int, int]:
        return cast(tuple[int, int], self.mean.shape)


@jaxtyped
@dataclass(kw_only=True)
class JaxUniform(JaxUncertainty):
    lower: Float[JaxArray, "*S"]
    upper: Float[JaxArray, "*S"]
    key: PRNGKeyArray

    @staticmethod
    def create(
        *,
        lower: Float[JaxArray, "*S"] | Float[Array, "*S"],
        upper: Float[JaxArray, "*S"] | Float[Array, "*S"],
        seed: int = 42,
        key: PRNGKeyArray | None = None,
    ) -> "JaxUniform":
        return JaxUniform(
            lower=jnp.asarray(lower),
            upper=jnp.asarray(upper),
            key=key if key is not None else jrandom.key(seed),
        )

    def __post_init__(self) -> None:
        assert uniform_bounds_are_valid(lower=self.lower, upper=self.upper)

    def sample(self, count: int) -> JaxUncertaintySamples:
        self.key, samples = sample_uniform(
            key=self.key,
            lower=self.lower,
            upper=self.upper,
            count=count,
            shape=self.shape,
        )

        return samples

    @property
    def shape(self) -> tuple[int, ...]:
        return self.lower.shape


@jax.jit(static_argnames=("count",))
@jaxtyped
def sample_gaussian(
    *,
    key: PRNGKeyArray,
    mean: Float[JaxArray, "V D"],
    covariance: Float[JaxArray, "V D D"],
    count: int,
) -> tuple[PRNGKeyArray, Float[JaxArray, "V D N"]]:
    key, subkey = jrandom.split(key)
    keys = jrandom.split(subkey, mean.shape[0])

    samples = jax.vmap(
        lambda k, m, c: jrandom.multivariate_normal(k, m, c, shape=(count,))
    )(keys, mean, covariance)

    return key, samples.transpose(0, 2, 1)


@jax.jit(static_argnames=("count", "shape"))
@jaxtyped
def sample_uniform(
    *,
    key: PRNGKeyArray,
    lower: Float[JaxArray, "*S"],
    upper: Float[JaxArray, "*S"],
    count: int,
    shape: tuple[int, ...],
) -> tuple[PRNGKeyArray, Float[JaxArray, "*S N"]]:
    key, subkey = jrandom.split(key)
    samples = roll_axes_left(
        jrandom.uniform(subkey, shape=(count, *shape), minval=lower, maxval=upper)
    )

    return key, samples


@jax.jit
@jaxtyped
def roll_axes_left(array: Float[JaxArray, "..."]) -> Float[JaxArray, "..."]:
    rest = array.shape[1:]
    return array.transpose(*range(1, len(rest) + 1), 0)


@jax.jit
@jaxtyped
def uniform_bounds_are_valid(
    *, lower: Float[JaxArray, "*S"], upper: Float[JaxArray, "*S"]
) -> Literal[True]:
    valid = jnp.all(upper >= lower)
    jax.debug.callback(report_invalid_bounds, valid, lower, upper)
    return True


def report_invalid_bounds(
    valid: bool, lower: Float[JaxArray, "*S"], upper: Float[JaxArray, "*S"]
) -> None:
    if not valid:
        print(
            f"All upper bounds must be greater than lower bounds. Got lower: {lower}, upper: {upper}."
        )
