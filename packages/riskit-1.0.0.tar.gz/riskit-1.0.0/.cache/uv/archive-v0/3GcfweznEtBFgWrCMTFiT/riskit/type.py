try:
    from beartype import beartype  # pyright: ignore[reportMissingImports]

    typechecker = beartype
except ImportError:
    typechecker = None

from typing import Any, Final

from jaxtyping import jaxtyped as jaxtyping_jaxtyped
from numpy import ndarray

try:
    from jax import Array as JaxArray  # pyright: ignore[reportMissingImports]
except ImportError:
    JaxArray = Any

Array = ndarray
"""A regular NumPy array."""

jaxtyped: Final = jaxtyping_jaxtyped(typechecker=typechecker)
"""Wrapper around `jaxtyping.jaxtyped` that conditionally applies type checking."""
