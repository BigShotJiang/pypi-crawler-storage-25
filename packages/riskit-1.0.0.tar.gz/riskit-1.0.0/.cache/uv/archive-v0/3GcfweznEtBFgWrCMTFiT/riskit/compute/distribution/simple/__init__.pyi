from .accelerated import JaxGaussian as JaxGaussian, JaxUniform as JaxUniform
from .basic import NumPyGaussian as NumPyGaussian, NumPyUniform as NumPyUniform
