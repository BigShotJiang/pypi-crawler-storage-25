from dataclasses import dataclass
from typing import cast

from riskit.compute.backend.basic import NumPyUncertainty, NumPyUncertaintySamples
from riskit.type import Array, jaxtyped

import numpy as np
from jaxtyping import Float

# TODO: Test that provided RNG is really used
type Rng = np.random.Generator


@jaxtyped
@dataclass(kw_only=True, frozen=True)
class NumPyGaussian(NumPyUncertainty):
    mean: Float[Array, "V D"]
    covariance: Float[Array, "V D D"]
    rng: Rng

    @staticmethod
    def create(
        *,
        mean: Float[Array, "V D"],
        covariance: Float[Array, "V D D"],
        seed: int = 42,
        rng: Rng | None = None,
    ) -> "NumPyGaussian":
        return NumPyGaussian(
            mean=mean,
            covariance=covariance,
            rng=rng if rng is not None else np.random.default_rng(seed),
        )

    def sample(self, count: int) -> NumPyUncertaintySamples:
        V, D = self.mean.shape

        L = np.linalg.cholesky(self.covariance)
        z = self.rng.standard_normal(size=(V, D, count))

        return self.mean[..., None] + (L @ z)

    @property
    def shape(self) -> tuple[int, int]:
        return cast(tuple[int, int], self.mean.shape)


@jaxtyped
@dataclass(kw_only=True, frozen=True)
class NumPyUniform(NumPyUncertainty):
    lower: Float[Array, "*S"]
    upper: Float[Array, "*S"]
    rng: Rng

    @staticmethod
    def create(
        *,
        lower: Float[Array, "*S"],
        upper: Float[Array, "*S"],
        seed: int = 42,
        rng: Rng | None = None,
    ) -> "NumPyUniform":
        return NumPyUniform(
            lower=lower,
            upper=upper,
            rng=rng if rng is not None else np.random.default_rng(seed),
        )

    def __post_init__(self) -> None:
        assert np.all(self.upper >= self.lower), (
            "All upper bounds must be greater than lower bounds."
        )

    def sample(self, count: int) -> NumPyUncertaintySamples:
        return roll_axes_left(
            self.rng.uniform(
                low=self.lower,
                high=self.upper,
                size=(count, *self.lower.shape),
            )
        )

    @property
    def shape(self) -> tuple[int, ...]:
        return self.lower.shape


def roll_axes_left(array: Array) -> Array:
    rest = array.shape[1:]
    return array.transpose(*range(1, len(rest) + 1), 0)
