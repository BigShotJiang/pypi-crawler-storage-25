import lazy_loader as lazy

from .factory import risk as risk  # noqa: E402, I001
from .sampler import sampler as sampler  # noqa: E402, I001

__getattr__, __dir__, __all__ = lazy.attach_stub(__name__, __file__)
# `risk` and `sampler` are bound eagerly above to shadow the same-named
# subpackages, which would otherwise be bound on this package as a side
# effect of any deeper import and bypass the lazy-loader's mapping.
