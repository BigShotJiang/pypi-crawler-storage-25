from typing import Annotated, Any, Callable, NamedTuple, Protocol, Self, overload

from riskit.risk.common import Backend, Compute
from riskit.type import Array, jaxtyped

import numpy as np
from jaxtyping import Float, Int


class NumPyCompute(Compute[Array]):
    def sum(self, data: Array, *, axis: int) -> Array:
        return np.sum(data, axis=axis)

    def mean(self, data: Array, *, axis: int) -> Array:
        return np.mean(data, axis=axis)

    def var(self, data: Array, *, axis: int) -> Array:
        return np.var(data, axis=axis)

    def quantile(self, data: Array, *, q: float, axis: int) -> Array:
        return np.quantile(data, q, axis=axis)

    def sort(self, data: Array, *, axis: int) -> Array:
        return np.sort(data, axis=axis)

    def take(self, data: Array, *, indices: Array, axis: int) -> Array:
        return np.take(data, indices=indices, axis=axis)

    def exp(self, data: Float[Array, "*S"]) -> Float[Array, "*S"]:
        return np.exp(data)

    def log(self, data: Float[Array, "*S"]) -> Float[Array, "*S"]:
        return np.log(data)

    def max(self, data: Array, *, axis: int, keepdims: bool = False) -> Array:
        return np.max(data, axis=axis, keepdims=keepdims)

    def arange(self, start: int, stop: int) -> Int[Array, " N"]:
        return np.arange(start, stop)

    def axpby(
        self,
        *,
        a: float = 1.0,
        x: Float[Array, "*S"],
        b: float = 1.0,
        y: Float[Array, "*S"],
    ) -> Float[Array, "*S"]:
        return a * x + b * y

    def scale(self, scalar: float, data: Float[Array, "*S"]) -> Float[Array, "*S"]:
        return scalar * data

    def subtract(
        self, x: Float[Array, "*S"], y: Float[Array, "*S"]
    ) -> Float[Array, "*S"]:
        return x - y


def numpy_backend() -> "NumPyBackend":
    return NumPyBackend()


class NumPyBackend(
    Backend["NumPyCosts", "NumPyRisk", Array],
):
    @staticmethod
    def create() -> "NumPyBackend":
        return numpy_backend()

    def execute[T](
        self,
        fn: Callable[[Compute[Array], Array], T],
        costs: "NumPyCosts",
        *args: Any,
        static_argument_indices: tuple[int, ...] | None = None,
    ) -> T:
        return fn(NumPyCompute(), costs, *args)

    @overload
    def to_risk(self, array: Float[Array, "T M"]) -> "NumPyRisk": ...

    @overload
    def to_risk(self, array: Float[Array, " M"], *, time_steps: int) -> "NumPyRisk": ...

    @jaxtyped
    def to_risk(
        self,
        array: Float[Array, "T M"] | Float[Array, " M"],
        *,
        time_steps: int | None = None,
    ) -> "NumPyRisk":
        match array.shape:
            case (M,):
                assert time_steps is not None, (
                    f"Received array of shape ({M},). You must specify the number of time steps "
                    "the risk should be padded to."
                )
                return np.full((time_steps, M), array / time_steps)

            case (T, M):
                assert time_steps is None, (
                    f"Received array of shape ({T}, {M}). Do not specify time_steps in this case."
                )
                return array
            case _:
                assert False, (
                    f"Cannot convert array of shape {array.shape} to NumPyRisk."
                )


type NumPyInputs = Float[Array, "T D_u M"]
"""Batch of control inputs. The dimensions are (time steps, control dimensions, trajectories)."""

type NumPyStates = Float[Array, "T D_x M"]
"""Batch of states. The dimensions are (time steps, state dimensions, trajectories)."""

type NumPyUncertaintySamples = Float[Array, "*S N"]
"""Batch of uncertainty samples. The dimensions are (...uncertainty dimensions, uncertainty samples)."""

type NumPyCosts = Annotated[Float[Array, "T M N"], numpy_backend]
"""Batch of costs. The dimensions are (time steps, trajectories, uncertainty samples)."""

type NumPyRisk = Float[Array, "T M"]
"""Batch of risk values. The dimensions are (time steps, trajectories)."""


class NumPyUncertainty(Protocol):
    def sample(self, count: int) -> NumPyUncertaintySamples:
        """Returns samples from the distribution of the uncertain variable(s)."""
        ...


class NumPyBatchCostFunction[TrajectoriesT, UncertaintySamplesT](Protocol):
    def __call__(
        self, *, trajectories: TrajectoriesT, uncertainties: UncertaintySamplesT
    ) -> NumPyCosts:
        """Describes the cost function that should be used for evaluating risk."""
        ...


class NumPyInputAndState(NamedTuple):
    u: NumPyInputs
    x: NumPyStates

    def get(self) -> Self:
        return self

    @property
    def time_steps(self) -> int:
        return self.u.shape[0]

    @property
    def trajectory_count(self) -> int:
        return self.u.shape[2]
