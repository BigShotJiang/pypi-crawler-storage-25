from typing import TYPE_CHECKING, Final

import riskit.compute.distribution.simple as simple


class distribution:
    class numpy:
        gaussian: Final = simple.NumPyGaussian.create
        uniform: Final = simple.NumPyUniform.create

    class jax:
        if TYPE_CHECKING:
            gaussian: Final = simple.JaxGaussian.create
            uniform: Final = simple.JaxUniform.create
        else:

            @staticmethod
            def gaussian(*args, **kwargs):
                return simple.JaxGaussian.create(*args, **kwargs)

            @staticmethod
            def uniform(*args, **kwargs):
                return simple.JaxUniform.create(*args, **kwargs)
