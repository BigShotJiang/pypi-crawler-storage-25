from typing import Final

from riskit.compute.backend.accelerated import JaxBackend
from riskit.compute.backend.basic import NumPyBackend


class backend:
    numpy: Final = NumPyBackend
    jax: Final = JaxBackend
