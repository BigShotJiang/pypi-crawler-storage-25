"""Gymnasium environment for tendon-driven dexterous hand."""
