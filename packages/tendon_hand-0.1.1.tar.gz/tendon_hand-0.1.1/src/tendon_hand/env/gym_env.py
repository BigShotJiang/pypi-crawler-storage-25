"""Gymnasium environment: V3 dexterous hand periodic open-close tracking.

Action: 17-D normalized motor commands ∈ [-1, 1]
Observation: 22 normalized joint pos + 22 normalized joint vel + 3 phase = 47D
Reward: -MSE(pose tracking) - smoothness_penalty + bonus for close match
"""

from __future__ import annotations

import os
from typing import Any

import numpy as np

import gymnasium as gym
from gymnasium import spaces

from tendon_hand.core.models.transmission import CascadeTransmissionModel
from tendon_hand.sim.pybullet_adapter import PyBulletHandAdapter


from tendon_hand.utils.asset_resolver import resolve_urdf_path

# Actuated joints (exclude fixed palm_right / palm_left joints)
_ACTUATED_JOINTS = [
    "palm_1_joint",
    "knuckle_1_joint",
    "finger_1_link2_joint",
    "finger_1_link1_joint",
    "palm_3_joint",
    "palm_4_joint",
    "knuckle_2_joint",
    "finger_2_link3_joint",
    "finger_2_link2_joint",
    "finger_2_link1_joint",
    "knuckle_3_joint",
    "finger_3_link3_joint",
    "finger_3_link2_joint",
    "finger_3_link1_joint",
    "knuckle_4_joint",
    "finger_4_link3_joint",
    "finger_4_link2_joint",
    "finger_4_link1_joint",
    "knuckle_5_joint",
    "finger_5_link3_joint",
    "finger_5_link2_joint",
    "finger_5_link1_joint",
]

# Motor names and close pose (physical values)
_MOTOR_NAMES = CascadeTransmissionModel().motor_names
_CLOSE_MOTOR_DICT = {
    "thumb_m1": 2.5, "thumb_m2": 1.0, "thumb_m3": -0.5,
    "index_m1": 5.8, "index_m2": 4.2, "index_m3": -0.4,
    "middle_m1": 5.8, "middle_m2": 4.2, "middle_m3": -0.3,
    "ring_m1": 5.8, "ring_m2": 4.2, "ring_m3": -0.4,
    "pinky_m1": 5.8, "pinky_m2": 4.2, "pinky_m3": -0.4,
    "wrist_m4": 0.0, "wrist_m5": 0.0,
}


class DexterousHandEnv(gym.Env):
    """V3 dexterous hand RL environment.

    Task: track a periodic OPEN ↔ CLOSE target pose.
    """

    metadata = {"render_modes": ["human", "rgb_array"], "render_fps": 60}

    def __init__(
        self,
        urdf_path: str,
        render_mode: str | None = None,
        cycle_steps: int = 120,
        max_steps: int = 600,
    ):
        super().__init__()
        self.render_mode = render_mode
        self.cycle_steps = cycle_steps
        self.max_steps = max_steps
        self._render_width = 640
        self._render_height = 480

        self.urdf_path = resolve_urdf_path(urdf_path)

        # Import pybullet lazily
        import pybullet as p

        if self.render_mode == "human":
            self.client_id = p.connect(p.GUI)
        else:
            self.client_id = p.connect(p.DIRECT)

        p.setGravity(0, 0, -9.81, physicsClientId=self.client_id)

        self.hand_id: int | None = None
        self.time_step = 1.0 / 60.0
        self.current_step = 0

        self.transmission = CascadeTransmissionModel()
        self._num_motors = len(self.transmission.motor_names)
        self._num_actuated = len(_ACTUATED_JOINTS)

        self._joint_indices: list[int] = []
        self._joint_limits: list[tuple[float, float]] = []

        # Normalized open/close motor poses
        self._open_motor = np.zeros(self._num_motors, dtype=np.float32)
        self._close_motor = np.array([
            self.transmission.normalize_motor(_CLOSE_MOTOR_DICT[name], i)
            for i, name in enumerate(_MOTOR_NAMES)
        ], dtype=np.float32)

        self.action_space = spaces.Box(
            low=-1.0, high=1.0, shape=(self._num_motors,), dtype=np.float32
        )

        obs_dim = self._num_actuated * 2 + 3
        obs_low = np.concatenate([
            np.full(self._num_actuated, -1.0, dtype=np.float32),
            np.full(self._num_actuated, -1.0, dtype=np.float32),
            np.array([-1.0, -1.0, 0.0], dtype=np.float32),
        ])
        obs_high = np.concatenate([
            np.full(self._num_actuated, 1.0, dtype=np.float32),
            np.full(self._num_actuated, 1.0, dtype=np.float32),
            np.array([1.0, 1.0, 1.0], dtype=np.float32),
        ])
        self.observation_space = spaces.Box(
            low=obs_low, high=obs_high, dtype=np.float32
        )

    def _build_joint_map(self) -> None:
        import pybullet as p

        num_joints = p.getNumJoints(self.hand_id, physicsClientId=self.client_id)
        name_to_idx: dict[str, int] = {}
        for j in range(num_joints):
            info = p.getJointInfo(self.hand_id, j, physicsClientId=self.client_id)
            name_to_idx[info[1].decode("utf-8")] = j

        self._joint_indices = []
        self._joint_limits = []
        for name in _ACTUATED_JOINTS:
            idx = name_to_idx[name]
            info = p.getJointInfo(self.hand_id, idx, physicsClientId=self.client_id)
            lo, hi = float(info[8]), float(info[9])
            self._joint_indices.append(idx)
            self._joint_limits.append((lo, hi))

    def _get_phase(self) -> float:
        return (self.current_step % self.cycle_steps) / self.cycle_steps

    def _get_target_motor_pose(self, phase: float) -> np.ndarray:
        alpha = 0.5 * (1.0 - np.cos(phase * 2.0 * np.pi))
        return self._open_motor + alpha * (self._close_motor - self._open_motor)

    def reset(self, seed: int | None = None, options: dict | None = None) -> tuple[np.ndarray, dict]:
        super().reset(seed=seed)
        self.current_step = 0

        import pybullet as p
        import pybullet_data

        p.resetSimulation(physicsClientId=self.client_id)
        p.setGravity(0, 0, -9.81, physicsClientId=self.client_id)
        p.setTimeStep(self.time_step, physicsClientId=self.client_id)
        p.setPhysicsEngineParameter(
            numSolverIterations=10,
            physicsClientId=self.client_id,
        )
        import pybullet_data
        p.setAdditionalSearchPath(pybullet_data.getDataPath(), physicsClientId=self.client_id)
        p.loadURDF("plane.urdf", physicsClientId=self.client_id)

        self.hand_id = p.loadURDF(
            self.urdf_path,
            basePosition=[0, 0, 0.22],
            baseOrientation=p.getQuaternionFromEuler([0, np.pi, 0]),
            useFixedBase=True,
            physicsClientId=self.client_id,
        )
        self._build_joint_map()

        for j in range(p.getNumJoints(self.hand_id, physicsClientId=self.client_id)):
            p.changeDynamics(
                self.hand_id, j,
                linearDamping=0.1,
                angularDamping=0.1,
                physicsClientId=self.client_id,
            )

        # Reset to neutral pose
        neutral_motor = 0.5 * (self._open_motor + self._close_motor)
        neutral_joint = self.transmission.map(neutral_motor)
        for idx, name in zip(self._joint_indices, _ACTUATED_JOINTS):
            p.resetJointState(
                self.hand_id, idx,
                float(neutral_joint.get(name, 0.0)),
                targetVelocity=0,
                physicsClientId=self.client_id,
            )

        for _ in range(5):
            p.stepSimulation(physicsClientId=self.client_id)

        obs = self._get_obs()
        return obs, {}

    def _normalize_joint_pos(self, pos: float, lo: float, hi: float) -> float:
        mid = (lo + hi) / 2.0
        span = (hi - lo) / 2.0
        if span < 1e-6:
            return 0.0
        return float(np.clip((pos - mid) / span, -1.0, 1.0))

    def _get_obs(self) -> np.ndarray:
        import pybullet as p

        joint_states = [
            p.getJointState(self.hand_id, idx, physicsClientId=self.client_id)
            for idx in self._joint_indices
        ]
        q = np.array([s[0] for s in joint_states], dtype=np.float32)
        dq = np.array([s[1] for s in joint_states], dtype=np.float32)

        q_norm = np.array([
            self._normalize_joint_pos(pos, lo, hi)
            for pos, (lo, hi) in zip(q, self._joint_limits)
        ], dtype=np.float32)
        dq_norm = np.clip(dq / 2.0, -1.0, 1.0).astype(np.float32)

        phase = self._get_phase()
        phase_enc = np.array([
            np.sin(phase * 2.0 * np.pi),
            np.cos(phase * 2.0 * np.pi),
            phase,
        ], dtype=np.float32)

        return np.concatenate([q_norm, dq_norm, phase_enc])

    def step(self, action: np.ndarray) -> tuple[np.ndarray, float, bool, bool, dict]:
        import pybullet as p

        action = np.clip(action, -1.0, 1.0)

        # Map 17-D motor action → 22-D joint targets
        joint_targets = self.transmission.map(action)
        for idx, name in zip(self._joint_indices, _ACTUATED_JOINTS):
            target_pos = float(joint_targets.get(name, 0.0))
            p.setJointMotorControl2(
                self.hand_id,
                idx,
                p.POSITION_CONTROL,
                targetPosition=target_pos,
                force=0.3,
                positionGain=0.1,
                velocityGain=0.1,
                physicsClientId=self.client_id,
            )

        p.stepSimulation(physicsClientId=self.client_id)
        self.current_step += 1

        obs = self._get_obs()
        phase = self._get_phase()

        # Target joint pose from interpolated motor target
        target_motor = self._get_target_motor_pose(phase)
        target_joint_dict = self.transmission.map(target_motor)
        q_target = np.array([
            float(target_joint_dict.get(name, 0.0))
            for name in _ACTUATED_JOINTS
        ], dtype=np.float32)

        # Current joint positions
        joint_states = [
            p.getJointState(self.hand_id, idx, physicsClientId=self.client_id)
            for idx in self._joint_indices
        ]
        q = np.array([s[0] for s in joint_states], dtype=np.float32)
        dq = np.array([s[1] for s in joint_states], dtype=np.float32)

        mse = float(np.mean((q - q_target) ** 2))
        smooth_penalty = float(np.mean(dq ** 2))

        reward = -mse - 0.05 * smooth_penalty
        if mse < 0.02:
            reward += 2.0

        terminated = False
        truncated = self.current_step >= self.max_steps

        info = {
            "phase": float(phase),
            "pose_mse": mse,
            "smooth_penalty": smooth_penalty,
        }
        return obs, float(reward), terminated, truncated, info

    def render(self) -> np.ndarray | None:
        if self.render_mode != "rgb_array":
            return None

        import pybullet as p

        vm = p.computeViewMatrixFromYawPitchRoll(
            [0.0, 0.0, 0.12], 0.30, 60, -25, 0, 2,
            physicsClientId=self.client_id,
        )
        pm = p.computeProjectionMatrixFOV(
            60, self._render_width / self._render_height, 0.1, 100.0,
            physicsClientId=self.client_id,
        )
        (_, _, px, _, _) = p.getCameraImage(
            self._render_width, self._render_height,
            viewMatrix=vm, projectionMatrix=pm,
            renderer=p.ER_BULLET_HARDWARE_OPENGL,
            physicsClientId=self.client_id,
        )
        rgb = np.array(px).reshape(self._render_height, self._render_width, 4)[:, :, :3]
        return rgb

    def close(self) -> None:
        import pybullet as p
        if p.isConnected(self.client_id):
            p.disconnect(self.client_id)


# Register with gymnasium
gym.register(
    id="TendonHand-v1",
    entry_point="tendon_hand.env.gym_env:DexterousHandEnv",
)
