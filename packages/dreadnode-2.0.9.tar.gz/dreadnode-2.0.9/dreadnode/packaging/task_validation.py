"""Local validation for task directories (task.yaml + docker-compose.yaml)."""

from __future__ import annotations

import re
import typing as t
from dataclasses import dataclass
from typing import TYPE_CHECKING, Literal

if TYPE_CHECKING:
    from pathlib import Path

import yaml
from pydantic import BaseModel, BeforeValidator, Field, ValidationError, field_validator

from dreadnode.core.util import valid_version


class VerificationConfig(BaseModel):
    script: str | None = Field(None, min_length=1, description="Verification script path")
    timeout: int = Field(30, description="Verification timeout in seconds")
    method: Literal["script", "flag"] | None = Field(None, description="Verification method")
    flag_hash: str | None = Field(None, description="Flag hash (e.g. sha256:...)")
    submission_path: str | None = Field(None, description="Submission file path")


class SolutionConfig(BaseModel):
    script: str = Field(..., min_length=1, description="Solution script path")


def _coerce_str(v: t.Any) -> str | None:
    """Coerce scalar values to strings (YAML parses bare ints like ``2022`` as int)."""
    if v is None:
        return None
    return str(v)


def _coerce_str_list(v: t.Any) -> list[str] | None:
    """Coerce list items to strings."""
    if v is None:
        return None
    if isinstance(v, list):
        return [str(item) for item in v]
    return v  # let pydantic reject non-list


class TaskYamlFields(BaseModel):
    model_config = {"extra": "allow"}

    name: str | None = Field(None, description="Task name (defaults to directory name)")
    version: str | None = Field(None, description="Task version (defaults to 1.0.0 when omitted)")
    instruction: str | None = Field(None, description="Task instruction")
    tags: t.Annotated[list[str] | None, BeforeValidator(_coerce_str_list)] = Field(
        None, description="Task tags"
    )
    difficulty: t.Annotated[str | None, BeforeValidator(_coerce_str)] = Field(
        None, description="Task difficulty level"
    )
    source: str | None = Field(None, description="Task source")
    category: str | None = Field(None, description="Task category")
    author_email: str | None = Field(None, description="Author email")
    author_name: str | None = Field(None, description="Author name")
    max_agent_timeout_sec: int | None = Field(None, description="Max agent timeout in seconds")
    ports: dict[str, list[int]] | None = Field(None, description="Port mappings by service name")
    verification: VerificationConfig | None = Field(None, description="Verification configuration")
    solution: SolutionConfig | None = Field(None, description="Solution configuration")

    @field_validator("version")
    @classmethod
    def validate_version(cls, value: str | None) -> str | None:
        if value is None:
            return value
        if not valid_version(value):
            raise ValueError(f"Task version must use fixed semver (X.Y.Z), got {value!r}")
        return value


@dataclass
class ValidationIssue:
    level: Literal["error", "warning"]
    component: str
    message: str


def discover_task_directories(root: Path) -> tuple[list[Path], list[tuple[Path, Path]]]:
    """Recursively discover task directories under *root*.

    A directory is a task if it contains ``task.yaml``.  Once a task directory
    is found we do **not** descend into it — a task cannot contain other tasks.
    If that situation is detected (a ``task.yaml`` exists inside another task
    directory) it is reported as a conflict.

    Returns:
        ``(task_dirs, conflicts)`` where *conflicts* is a list of
        ``(parent_task_dir, nested_task_dir)`` pairs.
    """
    import os
    from pathlib import Path

    task_dirs: list[Path] = []
    conflicts: list[tuple[Path, Path]] = []
    task_dir_set: set[str] = set()  # resolved string paths for fast prefix check

    root_str = str(root.resolve())

    for dirpath, dirnames, filenames in os.walk(root_str):
        # Skip hidden directories
        dirnames[:] = sorted(d for d in dirnames if not d.startswith("."))

        if "task.yaml" not in filenames:
            continue

        dir_path = Path(dirpath)

        # Check if nested inside an already-found task directory
        nested = False
        for ancestor in task_dir_set:
            if dirpath.startswith(ancestor + os.sep):
                conflicts.append((Path(ancestor), dir_path))
                nested = True
                break

        if nested:
            continue

        task_dirs.append(dir_path)
        task_dir_set.add(dirpath)

        # Don't descend into task directories
        dirnames.clear()

    return task_dirs, conflicts


# ---------------------------------------------------------------------------
# Compose helpers
# ---------------------------------------------------------------------------

# Matches compose port strings like "8080:8080", "3000", "8080:8080/tcp",
# "127.0.0.1:8080:8080", or long-form with target/published.
_PORT_RE = re.compile(
    r"""
    ^                  # anchor to start of string
    (?:[\d.]+:)?       # optional host IP
    (?:\d+:)?          # optional host port
    (\d+)              # container port (the one we care about)
    (?:/\w+)?          # optional protocol
    $                  # anchor to end of string
    """,
    re.VERBOSE,
)


def _extract_compose_ports(
    service_config: dict[str, t.Any],
) -> tuple[set[int], list[str]]:
    """Extract container ports from a compose service definition.

    Returns:
        A tuple of (parsed_ports, unparseable_entries) where *unparseable_entries*
        contains string representations of port entries that could not be parsed.
    """
    ports: set[int] = set()
    unparseable: list[str] = []
    raw_ports = service_config.get("ports")
    if not raw_ports or not isinstance(raw_ports, list):
        return ports, unparseable

    for entry in raw_ports:
        if isinstance(entry, int):
            ports.add(entry)
        elif isinstance(entry, str):
            m = _PORT_RE.match(entry)
            if m:
                ports.add(int(m.group(1)))
            else:
                unparseable.append(entry)
        elif isinstance(entry, dict):
            # Long-form: {target: 8080, published: 8080}
            target = entry.get("target")
            if isinstance(target, int):
                ports.add(target)
            else:
                unparseable.append(str(entry))
        else:
            unparseable.append(str(entry))
    return ports, unparseable


def _extract_build_dockerfile(service_config: dict[str, t.Any]) -> str | None:
    """Return the Dockerfile path referenced by a compose build config, or None."""
    build = service_config.get("build")
    if build is None:
        return None
    if isinstance(build, str):
        # Short form: build: ./dir — uses default Dockerfile
        return "Dockerfile"
    if isinstance(build, dict):
        if build.get("dockerfile_inline"):
            return None  # inline, no file to check
        return build.get("dockerfile", "Dockerfile")
    return None


# ---------------------------------------------------------------------------
# Template variable helpers
# ---------------------------------------------------------------------------

_TEMPLATE_VAR_RE = re.compile(r"\{\{\s*(\w+)\s*\}\}")

_HARDCODED_URL_RE = re.compile(r"(?<!\{)\bhttps?://\S+")


def _extract_template_vars(instruction: str) -> set[str]:
    """Extract ``{{var_name}}`` template variables from an instruction string."""
    return set(_TEMPLATE_VAR_RE.findall(instruction))


def _ports_to_expected_vars(ports: dict[str, list[int]]) -> set[str]:
    """Build the set of template variable names that ports should provide.

    Convention: ``{{service_url}}``, ``{{service_url_PORT}}``,
    ``{{service_host}}``, ``{{service_port}}``.
    """
    names: set[str] = set()
    for service, port_list in ports.items():
        names.add(f"{service}_url")
        names.add(f"{service}_host")
        names.add(f"{service}_port")
        for port in port_list:
            names.add(f"{service}_url_{port}")
    return names


# ---------------------------------------------------------------------------
# Core validation
# ---------------------------------------------------------------------------


def validate_task_directory(
    task_dir: Path, *, root_dir: Path | None = None
) -> list[ValidationIssue]:
    """Validate a task directory, returning a list of issues found.

    Checks (in order):
    - task.yaml exists, parses, and passes schema validation
    - docker-compose.yaml exists, parses, has valid services mapping
    - Port service names in task.yaml exist in compose
    - Port numbers in task.yaml are exposed by the corresponding compose service
    - Dockerfiles referenced by compose build configs exist on disk
    - Template variables in instruction match declared ports
    - Verification/solution scripts exist on disk

    Args:
        task_dir: Path to the task directory.
        root_dir: Root directory of the tasks tree.  Build contexts that
            escape the task directory but remain within *root_dir* are
            considered valid (shared infrastructure pattern).
    """
    issues: list[ValidationIssue] = []

    task_yaml_path = task_dir / "task.yaml"
    if not task_yaml_path.is_file():
        issues.append(ValidationIssue("error", "task.yaml", "file not found"))
        return issues

    try:
        raw = yaml.safe_load(task_yaml_path.read_text())
    except yaml.YAMLError as exc:
        issues.append(ValidationIssue("error", "task.yaml", f"YAML parse error: {exc}"))
        return issues

    if not isinstance(raw, dict):
        issues.append(ValidationIssue("error", "task.yaml", "must contain a YAML mapping"))
        return issues

    try:
        fields = TaskYamlFields.model_validate(raw)
    except ValidationError as exc:
        issues.append(ValidationIssue("error", "task.yaml", f"schema validation: {exc}"))
        return issues

    # --- docker-compose.yaml ---
    compose_path = task_dir / "docker-compose.yaml"
    compose_services: dict[str, t.Any] = {}
    if not compose_path.is_file():
        issues.append(ValidationIssue("error", "docker-compose.yaml", "file not found"))
    else:
        try:
            compose = yaml.safe_load(compose_path.read_text())
        except yaml.YAMLError as exc:
            issues.append(
                ValidationIssue("error", "docker-compose.yaml", f"YAML parse error: {exc}")
            )
        else:
            if not isinstance(compose, dict):
                issues.append(
                    ValidationIssue(
                        "error",
                        "docker-compose.yaml",
                        "must contain a YAML mapping with top-level 'services'",
                    )
                )
            else:
                services = compose.get("services")
                if services is None:
                    issues.append(
                        ValidationIssue(
                            "error",
                            "docker-compose.yaml",
                            "missing required 'services' mapping",
                        )
                    )
                elif not isinstance(services, dict):
                    issues.append(
                        ValidationIssue(
                            "error",
                            "docker-compose.yaml",
                            "'services' must be a mapping",
                        )
                    )
                else:
                    compose_services = services

    # --- Cross-validate ports (service names + port numbers) ---
    if fields.ports and compose_services:
        for service_name, declared_ports in fields.ports.items():
            if service_name not in compose_services:
                issues.append(
                    ValidationIssue(
                        "warning",
                        "ports",
                        f"service '{service_name}' not found in docker-compose.yaml",
                    )
                )
            else:
                exposed, unparseable = _extract_compose_ports(compose_services[service_name])
                for entry in unparseable:
                    issues.append(
                        ValidationIssue(
                            "warning",
                            "ports",
                            f"service '{service_name}' has unparseable port entry: {entry}",
                        )
                    )
                for port in declared_ports:
                    if exposed and port not in exposed:
                        issues.append(
                            ValidationIssue(
                                "warning",
                                "ports",
                                f"port {port} not exposed by service '{service_name}' "
                                f"(exposed: {sorted(exposed)})",
                            )
                        )

    # --- Warn about compose services exposing ports not declared in task.yaml ---
    declared_services = set(fields.ports.keys()) if fields.ports else set()
    for svc_name, svc_config in compose_services.items():
        if not isinstance(svc_config, dict):
            continue
        exposed, unparseable = _extract_compose_ports(svc_config)
        for entry in unparseable:
            issues.append(
                ValidationIssue(
                    "warning",
                    "ports",
                    f"service '{svc_name}' has unparseable port entry: {entry}",
                )
            )
        if exposed and svc_name not in declared_services:
            issues.append(
                ValidationIssue(
                    "warning",
                    "ports",
                    f"service '{svc_name}' exposes ports {sorted(exposed)} "
                    f"but is not declared in task.yaml ports",
                )
            )

    # --- Check Dockerfiles referenced by compose build configs ---
    resolved_task = task_dir.resolve()
    resolved_root = root_dir.resolve() if root_dir else resolved_task
    for svc_name, svc_config in compose_services.items():
        if not isinstance(svc_config, dict):
            continue
        dockerfile = _extract_build_dockerfile(svc_config)
        if dockerfile is None:
            continue
        # Resolve relative to build context
        build = svc_config.get("build", {})
        if isinstance(build, str):
            # Short form: build: ./challenge/nginx — context is the string
            context = build
        elif isinstance(build, dict):
            context = build.get("context", ".")
        else:
            context = "."
        dockerfile_path = (task_dir / context / dockerfile).resolve()
        try:
            dockerfile_path.relative_to(resolved_task)
        except ValueError:
            # Build context escapes task directory — check if it's still
            # within the root tasks tree (shared infrastructure pattern)
            try:
                dockerfile_path.relative_to(resolved_root)
            except ValueError:
                issues.append(
                    ValidationIssue(
                        "warning",
                        "dockerfile",
                        f"service '{svc_name}' build context escapes task directory "
                        f"(resolves to {dockerfile_path})",
                    )
                )
                continue
        if not dockerfile_path.is_file():
            try:
                rel = dockerfile_path.relative_to(resolved_task)
            except ValueError:
                rel = dockerfile_path.relative_to(resolved_root)
            issues.append(
                ValidationIssue(
                    "warning",
                    "dockerfile",
                    f"service '{svc_name}' references '{dockerfile}' but file not found "
                    f"(looked at {rel})",
                )
            )

    # --- Template variable cross-check ---
    if fields.instruction and fields.ports:
        used_vars = _extract_template_vars(fields.instruction)
        available_vars = _ports_to_expected_vars(fields.ports)
        # Only warn about vars that look like service references but don't match any port
        for var in used_vars:
            if var not in available_vars and any(var.startswith(svc) for svc in fields.ports):
                issues.append(
                    ValidationIssue(
                        "warning",
                        "template",
                        f"template variable '{{{{{var}}}}}' not provided by declared ports",
                    )
                )

    # --- Warn about hardcoded URLs in instruction ---
    if fields.instruction:
        for url_match in _HARDCODED_URL_RE.finditer(fields.instruction):
            url = url_match.group(0)
            issues.append(
                ValidationIssue(
                    "warning",
                    "instruction",
                    f"hardcoded URL '{url}' — should this be a template variable?",
                )
            )

    # --- Check referenced scripts exist ---
    if fields.verification and fields.verification.script:
        if not (task_dir / fields.verification.script).is_file():
            issues.append(
                ValidationIssue(
                    "warning", "verification", f"script '{fields.verification.script}' not found"
                )
            )

    if fields.solution and fields.solution.script:
        if not (task_dir / fields.solution.script).is_file():
            issues.append(
                ValidationIssue(
                    "warning", "solution", f"script '{fields.solution.script}' not found"
                )
            )

    return issues
