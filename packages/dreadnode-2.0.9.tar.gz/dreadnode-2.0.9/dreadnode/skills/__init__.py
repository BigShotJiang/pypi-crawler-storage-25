"""Native SDK skills that ship with the dreadnode package."""

from __future__ import annotations

import typing as t
from functools import lru_cache
from pathlib import Path

if t.TYPE_CHECKING:
    from dreadnode.agents.skills import Skill


def _skills_dir() -> Path:
    """Return the directory containing native skill subdirectories."""
    return Path(__file__).parent


@lru_cache(maxsize=1)
def discover_native_skills() -> tuple[Skill, ...]:
    """Discover skills bundled with the SDK.

    Returns a cached tuple of Skill objects from ``dreadnode/skills/``.
    These are always available regardless of which capabilities are loaded.
    """
    from dreadnode.agents.skills import discover_skills

    return tuple(discover_skills(_skills_dir()))
