import importlib
import typing as t

if t.TYPE_CHECKING:
    from dreadnode.agents.tools import Tool, Toolset
    from dreadnode.tools.apply_patch import apply_patch
    from dreadnode.tools.editing import delete_lines, edit_file, insert_lines, multiedit
    from dreadnode.tools.execute import bash, python
    from dreadnode.tools.fetch import fetch
    from dreadnode.tools.glob import glob
    from dreadnode.tools.grep import grep
    from dreadnode.tools.interaction import ask_user, confirm
    from dreadnode.tools.ls import ls
    from dreadnode.tools.memory import Memory
    from dreadnode.tools.read import read
    from dreadnode.tools.think import think
    from dreadnode.tools.todo import todo
    from dreadnode.tools.web_search import web_search
    from dreadnode.tools.write import write

# Lazy imports via __getattr__ — submodules are loaded on demand to
# avoid circular imports.  Only modules that actually exist on disk
# should be listed here.

__all__ = [
    "Memory",
    "apply_patch",
    "ask_user",
    "bash",
    "confirm",
    "delete_lines",
    "edit_file",
    "fetch",
    "glob",
    "grep",
    "insert_lines",
    "ls",
    "multiedit",
    "python",
    "read",
    "think",
    "todo",
    "web_search",
    "write",
]

__lazy_submodules__: list[str] = list(__all__)


def __getattr__(name: str) -> t.Any:
    if name in __lazy_submodules__:
        module = importlib.import_module(f".{name}", __name__)
        globals()[name] = module
        return module

    raise AttributeError(f"module '{__name__}' has no attribute '{name}'")


def default_tools() -> dict[str, "Tool | Toolset"]:
    """All standard tools, keyed by function name.

    Imports are deferred to avoid circular dependencies.
    """
    from dreadnode.tools.apply_patch import apply_patch
    from dreadnode.tools.editing import delete_lines, edit_file, insert_lines, multiedit
    from dreadnode.tools.execute import bash, python
    from dreadnode.tools.fetch import fetch
    from dreadnode.tools.glob import glob
    from dreadnode.tools.grep import grep
    from dreadnode.tools.interaction import ask_user, confirm
    from dreadnode.tools.ls import ls
    from dreadnode.tools.memory import Memory
    from dreadnode.tools.read import read
    from dreadnode.tools.todo import todo
    from dreadnode.tools.web_search import web_search
    from dreadnode.tools.write import write

    tools: list[Tool | Toolset] = [
        read,
        write,
        glob,
        grep,
        ls,
        edit_file,
        multiedit,
        delete_lines,
        insert_lines,
        apply_patch,
        bash,
        python,
        fetch,
        web_search,
        todo,
        ask_user,
        confirm,
        Memory(),
    ]
    return {tool.name: tool for tool in tools}
