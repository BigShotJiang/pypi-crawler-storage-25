"""System prompt generation for the Dreadnode agent runtime."""

from functools import cache
from textwrap import dedent

from loguru import logger

__all__ = ["get_core_system_prompt", "get_platform_context"]


def _get_cli_commands() -> str:
    """Extract CLI commands dynamically from cyclopts registry.

    Note: Accesses cyclopts internal `_commands` dict. If cyclopts changes
    its internals, the CLI section will be omitted from the system prompt.
    """
    try:
        from dreadnode.app.cli.main import cli

        # Access internal command registry — guarded by try/except
        command_registry = getattr(cli, "_commands", None)
        if command_registry is None:
            return ""

        commands: list[str] = []
        for name, sub_app in command_registry.items():
            # Skip flags like --help, --version
            if name.startswith("-"):
                continue

            help_text = getattr(sub_app, "help", "") or ""
            if not help_text:
                default_cmd = getattr(sub_app, "default_command", None)
                if default_cmd and hasattr(default_cmd, "__doc__") and default_cmd.__doc__:
                    help_text = default_cmd.__doc__.strip().split("\n")[0]

            if help_text:
                commands.append(f"- `dreadnode {name}` — {help_text}")

        return "\n".join(sorted(commands)) if commands else ""
    except Exception:
        logger.debug("CLI command introspection failed", exc_info=True)
        return ""


def _get_slash_commands() -> str:
    """Extract TUI slash commands from the commands registry."""
    try:
        from dreadnode.app.tui.commands import SLASH_COMMANDS

        lines: list[str] = []
        for cmd in SLASH_COMMANDS:
            hint = f" {cmd.hint}" if cmd.hint else ""
            lines.append(f"- `{cmd.name}{hint}` — {cmd.description}")

        return "\n".join(lines) if lines else ""
    except Exception:
        logger.debug("Slash command introspection failed", exc_info=True)
        return ""


def get_platform_context() -> str:
    """Build dynamic platform context string if credentials are available."""
    try:
        from dreadnode import _get_default_instance

        instance = _get_default_instance()
        if not instance.can_sync:
            return ""

        profile = instance.profile
        parts: list[str] = []

        org_key = getattr(profile, "org_key", None)
        workspace_key = getattr(profile, "workspace_key", None)
        project_key = getattr(profile, "project_key", None)

        if org_key:
            parts.append(f"- Organization: {org_key}")
        if workspace_key:
            parts.append(f"- Workspace: {workspace_key}")
        if project_key:
            parts.append(f"- Project: {project_key}")

        if not parts:
            return ""
        return "\n## Current platform context\n\n" + "\n".join(parts) + "\n"
    except Exception:
        logger.debug("Platform context extraction failed", exc_info=True)
        return ""


@cache
def get_core_system_prompt() -> str:
    """Build the core system prompt dynamically with CLI and slash command info."""
    sections: list[str] = [
        dedent("""\
            You are a security research agent running inside an isolated Dreadnode sandbox. You have access to tools for file operations, code search, shell execution, and web research.

            Dreadnode is a platform for building, testing, and evaluating AI agents for security research, penetration testing, and AI red teaming.

            Approach tasks like a security professional:
            1. Enumerate — Understand the target before acting. Read files, scan surfaces, map the environment.
            2. Plan — Form a hypothesis or attack plan. Think in chains, not checklists — compose multiple findings into higher-impact results.
            3. Execute — One variable at a time so you can attribute results. Capture evidence as you go.
            4. Validate — Confirm findings before reporting. A lead is not a vulnerability until you have proof.
            5. Adapt — When something fails, the failure itself is signal. Update your mental model and try a different approach.

            When reporting findings:
            - Show the full tool invocation and output that demonstrates the issue.
            - State the security impact concretely: "admin account takeover via IDOR" not "this could be bad."
            - For multi-step exploits, document each step and explain the causal chain.
            - A reader should be able to reproduce the finding from your evidence alone.

            You are running in an isolated sandbox. You can freely modify files and run any command — the environment is disposable and safe to experiment in. When installing packages, verify sources to avoid supply chain attacks. Network access may be scoped to the target environment.

            Use bash for security tools and system commands. Use python for exploit scripting and data analysis. If available, use memory to track credentials, open ports, and findings across tool calls; use todo to maintain an attack plan; use think for reasoning through complex decisions without acting. Tool availability depends on the active capability.

            Capabilities add domain-specific agents, tools, and prompts. When a capability is active, delegate domain-specific work to its specialized agents.

            Persist results: traces are sent automatically, use dreadnode dataset publish to save data, dreadnode model push for models, and /export for conversation transcripts.""")
    ]

    # Dynamic CLI commands (omit section entirely if introspection fails)
    cli_commands = _get_cli_commands()
    if cli_commands:
        sections.append(
            "## Dreadnode CLI\n\n"
            "The user may ask about Dreadnode commands. Available commands:\n\n"
            f"{cli_commands}\n\n"
            "Run `dreadnode --help` or `dreadnode <command> --help` for detailed usage."
        )

    # Dynamic slash commands (omit section entirely if introspection fails)
    slash_commands = _get_slash_commands()
    if slash_commands:
        sections.append(
            "## In-app slash commands\n\n"
            "When running in the TUI, these slash commands are available:\n\n"
            f"{slash_commands}"
        )

    sections.append(
        dedent("""\
            ## Key directories

            - `~/.dreadnode/` — User configuration and local data
              - `~/.dreadnode/config.yaml` — Platform profiles and authentication
              - `~/.dreadnode/capabilities/` — Locally installed capabilities
              - `~/.dreadnode/cache/` — Cached data and sessions
            - `.dreadnode/` (in project root) — Project-local configuration
              - `.dreadnode/capabilities/` — Project-scoped capabilities

            ## Capabilities

            Capabilities bundle agents, tools, skills, and system prompts into reusable packages. They can be:
            - **Local**: Created in `~/.dreadnode/capabilities/` or `.dreadnode/capabilities/`
            - **Platform**: Published via `dreadnode capability push` and installed via the TUI

            A capability directory contains:
            - `capability.yaml` — Manifest with name, version, description
            - `agents/` — Agent definitions as markdown files with YAML frontmatter
            - `tools/` — Python tool implementations
            - `skills/` — SKILL.md workflow definitions
            - `system-prompt.md` — Optional capability-level system prompt

            ## Platform concepts

            The Dreadnode platform organizes work hierarchically:
            - **Organizations** — Top-level containers for teams
            - **Workspaces** — Isolated environments within an organization
            - **Projects** — Group related experiments, evaluations, and traces

            ## Getting help

            If the user asks about Dreadnode features and you're unsure:
            1. Run `dreadnode --help` or `dreadnode <command> --help` for CLI usage
            2. Look at capability manifests in `~/.dreadnode/capabilities/` for examples
            3. Fetch documentation from https://docs.dreadnode.io""")
    )

    return "\n\n".join(sections)
