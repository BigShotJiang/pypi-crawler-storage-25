"""Session context bar (Zone 1) and page status (Zone 3).

SessionContextBar (Zone 1, 2 lines):
  Line 1: @agent_name · active                        Opus 4.6 (High)
  Line 2: ^A agent                                ^K model, ^⇧K reasoning

PageStatus (Zone 3, 1 line):
                                                 53.4k/200k tok · ? help
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from rich.text import Text
from textual.reactive import reactive
from textual.widgets import Static

if TYPE_CHECKING:
    from textual.timer import Timer

from dreadnode.app.model_catalog import display_name_with_effort
from dreadnode.app.tui.model_variants import render_tokens
from dreadnode.app.tui.theme import ACCENT, FG_FAINTEST, FG_MUTED, FG_SUBTLE, INFO, WARNING
from dreadnode.app.tui.widgets.status_bar import StatusBar, _pad_right


class SessionContextBar(Static):
    """Zone 1 — two-line bar showing agent + model context above the composer."""

    agent_name: reactive[str] = reactive("default")
    model_name: reactive[str] = reactive("")
    effort_label: reactive[str] = reactive("")
    busy: reactive[bool] = reactive(False)
    status_text: reactive[str] = reactive("Ready")

    def render(self) -> Text:
        w = self.size.width

        # === Line 1: @agent (+ status)          Model (Effort) ===
        left = Text(no_wrap=True, overflow="ellipsis")
        left.append(f"@{self.agent_name or 'default'}", style=FG_SUBTLE)

        if self.busy:
            left.append(" · ", style=FG_FAINTEST)
            status = (self.status_text or "").strip().lower()
            if status.startswith("awaiting"):
                left.append(status, style=WARNING)
            else:
                left.append("active", style=ACCENT)

        right = Text(no_wrap=True)
        if self.model_name:
            effort = self.effort_label or None
            right.append(display_name_with_effort(self.model_name, effort), style="bold")
            if self.model_name.startswith("dn/"):
                right.append(" · ", style=FG_FAINTEST)
                right.append("dreadnode", style=FG_FAINTEST)

        line1 = _pad_right(left, right, w)

        # === Line 2: keybind hints ===
        hints_left = Text(no_wrap=True)
        hints_left.append("^A", style=FG_FAINTEST)
        hints_left.append(" agent  ", style=FG_FAINTEST)
        hints_left.append("^O", style=FG_FAINTEST)
        hints_left.append(" output", style=FG_FAINTEST)

        hints_right = Text(no_wrap=True)
        hints_right.append("^K", style=FG_FAINTEST)
        hints_right.append(" model, ", style=FG_FAINTEST)
        hints_right.append("^⇧K", style=FG_FAINTEST)
        hints_right.append(" reasoning", style=FG_FAINTEST)

        line2 = _pad_right(hints_left, hints_right, w)

        result = line1.copy()
        result.append("\n")
        result.append_text(line2)
        return result


class ContextBar(SessionContextBar):
    """Public context bar with the broader legacy surface older code expects."""

    connection: reactive[str] = reactive("")
    workspace_label: reactive[str] = reactive("")
    total_tokens: reactive[int] = reactive(0)
    model_max_tokens: reactive[int] = reactive(0)
    output_mode: reactive[str] = reactive("compact")

    def render(self) -> Text:
        w = self.size.width

        left = Text(no_wrap=True, overflow="ellipsis")
        left.append(f"@{self.agent_name or 'default'}", style=FG_SUBTLE)

        if self.busy:
            left.append(" · ", style=FG_FAINTEST)
            status = (self.status_text or "").strip().lower()
            if status.startswith("awaiting"):
                left.append(status, style=WARNING)
            else:
                left.append("active", style=ACCENT)

        if self.workspace_label:
            left.append(" · ", style=FG_FAINTEST)
            left.append(self.workspace_label, style=FG_MUTED)

        right = Text(no_wrap=True)
        if self.model_name:
            effort = self.effort_label or None
            right.append(display_name_with_effort(self.model_name, effort), style="bold")
            if self.model_name.startswith("dn/"):
                right.append(" · ", style=FG_FAINTEST)
                right.append("dreadnode", style=FG_FAINTEST)

        connection = (self.connection or "").strip()
        if connection:
            if right.plain:
                right.append(" · ", style=FG_FAINTEST)
            right.append(
                "platform" if connection.startswith("http") else connection, style=FG_MUTED
            )

        if self.total_tokens > 0:
            if right.plain:
                right.append(" · ", style=FG_FAINTEST)
            limit = self.model_max_tokens if self.model_max_tokens > 0 else None
            right.append_text(render_tokens(self.total_tokens, limit))

        line1 = _pad_right(left, right, w)

        hints_left = Text(no_wrap=True)
        hints_left.append("^A", style=FG_FAINTEST)
        hints_left.append(" agent  ", style=FG_FAINTEST)
        hints_left.append("^O", style=FG_FAINTEST)
        hints_left.append(
            " show more" if self.output_mode == "compact" else " show less", style=FG_FAINTEST
        )

        hints_right = Text(no_wrap=True)
        hints_right.append("^K", style=FG_FAINTEST)
        hints_right.append(" model, ", style=FG_FAINTEST)
        hints_right.append("^⇧K", style=FG_FAINTEST)
        hints_right.append(" reasoning", style=FG_FAINTEST)

        line2 = _pad_right(hints_left, hints_right, w)

        result = line1.copy()
        result.append("\n")
        result.append_text(line2)
        return result


_ISSUE_DISPLAY_SECONDS = 60


class PageStatus(Static):
    """Zone 3 — single-line page status below the composer.

    runtime_issues is a tuple of (label, names, hint, kind) groups, e.g.:
        (("MCP", "burp, caido", "/mcp", "error"), ("updates", "web-security", "Ctrl+P", "update"))

    Issues auto-dismiss after 60 seconds.
    """

    total_tokens: reactive[int] = reactive(0)
    model_max_tokens: reactive[int] = reactive(0)
    runtime_issues: reactive[tuple[tuple[str, str, str, str], ...]] = reactive(())
    _show_issues: reactive[bool] = reactive(False)
    _dismiss_timer: Timer | None = None

    def watch_runtime_issues(self, value: tuple[tuple[str, str, str, str], ...]) -> None:
        if self._dismiss_timer is not None:
            self._dismiss_timer.stop()
            self._dismiss_timer = None
        if value:
            self._show_issues = True
            self._dismiss_timer = self.set_timer(_ISSUE_DISPLAY_SECONDS, self._hide_issues)
        else:
            self._show_issues = False

    def _hide_issues(self) -> None:
        self._show_issues = False

    def render(self) -> Text:
        w = self.size.width

        left = Text(no_wrap=True)
        if self._show_issues:
            for i, (_label, names, hint, kind) in enumerate(self.runtime_issues):
                if i > 0:
                    left.append(" · ", style=FG_FAINTEST)
                if kind == "update":
                    left.append("↑ ", style=INFO)
                    left.append(names, style=INFO)
                else:
                    left.append("⚠ ", style=WARNING)
                    left.append(names, style=WARNING)
                left.append(f" ({hint})", style=FG_FAINTEST)

        right = Text(no_wrap=True)
        if self.total_tokens > 0:
            limit = self.model_max_tokens if self.model_max_tokens > 0 else None
            right.append_text(render_tokens(self.total_tokens, limit))
            right.append(" · ", style=FG_FAINTEST)
        right.append("? help", style=FG_FAINTEST)

        return _pad_right(left, right, w)


class AppBar(StatusBar):
    """Legacy navigation bar facade for older code and tests."""

    def render(self) -> Text:
        w = self.size.width

        left = Text(no_wrap=True)

        right = Text(no_wrap=True)
        for key, label, last in [
            ("?", "help", False),
            ("^B", "sessions", False),
            ("^T", "traces", False),
            ("^E", "env", False),
            ("F5", "console", True),
        ]:
            right.append(key, style=FG_FAINTEST)
            right.append(f" {label}", style=FG_FAINTEST)
            if not last:
                right.append("  ", style=FG_FAINTEST)

        return _pad_right(left, right, w)
