"""Slash commands, auth helpers, and event parsing for the Dreadnode TUI."""

from __future__ import annotations

import json
import re
import typing as t
from dataclasses import dataclass

from dreadnode.app.api.client import ApiClient
from dreadnode.app.config import Profile, UserConfig, urls_match


@dataclass(slots=True)
class SlashCommand:
    """A TUI slash command definition."""

    name: str
    description: str
    hint: str = ""


SLASH_COMMANDS: list[SlashCommand] = [
    SlashCommand("/help", "Show available commands"),
    SlashCommand("/new", "Create a new session"),
    SlashCommand("/reset", "Reset current session"),
    SlashCommand("/sessions", "List all sessions"),
    SlashCommand("/agents", "List loaded agents"),
    SlashCommand("/agent", "Start agent session", "<name>"),
    SlashCommand("/model", "Get or set model", "[provider/model]"),
    SlashCommand("/reload", "Re-discover capabilities and rebuild registry"),
    SlashCommand(
        "/login", "Authenticate with platform (restarts runtime)", "[api-key] [--server <url>]"
    ),
    SlashCommand("/logout", "Disconnect and revoke credentials"),
    SlashCommand("/whoami", "Show current identity"),
    SlashCommand("/profile", "Switch profile"),
    SlashCommand("/workspace", "View or switch workspace (restarts runtime)", "[key]"),
    SlashCommand("/workspaces", "List workspaces"),
    SlashCommand("/projects", "List projects", "[workspace]"),
    SlashCommand("/models", "Open model picker"),
    SlashCommand("/thinking", "Toggle thinking/reasoning effort", "[on|off|low|medium|high|max]"),
    SlashCommand("/runtimes", "View workspace interactive runtimes"),
    SlashCommand("/environments", "Browse available environments"),
    SlashCommand("/capabilities", "Manage runtime capabilities"),
    SlashCommand("/skills", "Browse and load skills"),
    SlashCommand("/mcp", "View MCP server status"),
    SlashCommand("/secrets", "View configured secrets and provider presets"),
    SlashCommand("/compact", "Compact conversation history", "[guidance]"),
    SlashCommand("/rename", "Rename current session", "<title>"),
    SlashCommand("/tools", "Set tool details mode", "<compact|expanded>"),
    SlashCommand("/export", "Export session transcript", "[filename]"),
    SlashCommand("/traces", "Browse traces for current project"),
    SlashCommand("/sandboxes", "Monitor your sandboxes"),
    SlashCommand("/evaluations", "View workspace evaluation jobs"),
    SlashCommand("/console", "View backend logs"),
    SlashCommand("/copy", "Copy last assistant message (or press y)"),
    SlashCommand("/version", "Show installed Dreadnode version"),
    SlashCommand("/update", "Update Dreadnode CLI to latest version"),
    SlashCommand("/quit", "Exit the TUI"),
]


# ---------------------------------------------------------------------------
# Auth helpers
# ---------------------------------------------------------------------------


def _parse_login_args(args: list[str], default_platform_url: str) -> tuple[str, str | None]:
    """Parse /login arguments into ``(server_url, api_key)``."""
    server_url = default_platform_url
    api_key: str | None = None

    index = 0
    while index < len(args):
        arg = args[index]
        if arg in {"--server", "-s"}:
            index += 1
            if index >= len(args):
                raise ValueError("Usage: /login [api-key] [--server <url>]")
            server_url = args[index]
        elif arg == "apikey":
            index += 1
            if index >= len(args):
                raise ValueError("Usage: /login [api-key] [--server <url>]")
            api_key = args[index]
        elif api_key is None:
            api_key = arg
        else:
            raise ValueError(f"Unknown /login argument: {arg}")
        index += 1

    return server_url, api_key


def _save_profile(profile_name: str, profile: Profile) -> Profile:
    """Persist a server profile to the local config directory."""
    profile._name = profile_name
    user_config = UserConfig.read()
    user_config.save_profile(profile)
    user_config.activate(profile_name)
    user_config.write()
    return profile


def _login_with_api_key(
    server_url: str,
    api_key: str,
    *,
    organization: str | None = None,
    workspace: str | None = None,
    project: str | None = None,
    profile_name: str | None = None,
) -> Profile:
    """Authenticate with the platform using an API key.

    If *profile_name* is given it is used as the config key (allowing custom
    names like ``work`` or ``staging``).  Otherwise the authenticated user's
    username is used, matching the original behaviour.
    """
    from dreadnode.app.config import resolve_default_workspace

    api = ApiClient(server_url, api_key=api_key)
    user = api.get_user()
    if organization is None:
        orgs = api.list_user_organizations()
        if not orgs:
            raise RuntimeError("No organizations found for this account.")
        default_org = orgs[0].key
    else:
        default_org = api.get_organization(organization).key

    if workspace is None:
        default_workspace = resolve_default_workspace(api, default_org).key
    else:
        default_workspace = api.get_workspace(default_org, workspace).key

    if project is None:
        default_project = api.get_default_project_key(default_org, default_workspace)
    else:
        default_project = api.get_project(default_org, default_workspace, project).key

    name = profile_name or user.username

    # Check for existing profile to preserve customizations (e.g. default_model)
    user_config = UserConfig.read()
    existing = user_config.servers.get(name)
    if existing and urls_match(existing.url, server_url):
        existing.api_key = api_key
        existing.email = user.email_address
        existing.username = user.username
        existing.default_organization = default_org
        existing.default_workspace = default_workspace
        existing.default_project = default_project
        return _save_profile(name, existing)

    profile = Profile(
        url=server_url,
        user_key=user.username,
        email=user.email_address,
        username=user.username,
        api_key=api_key,
        default_organization=default_org,
        default_workspace=default_workspace,
        default_project=default_project,
    )
    return _save_profile(name, profile)


# Module-level in-memory profile set by the TUI app during boot.
# When set, _active_profile() and _platform_client() use this instead of
# re-reading from disk — critical for --server overrides where the resolved
# profile differs from the persisted active profile.
_in_memory_profile: tuple[str | None, Profile] | None = None


def _set_in_memory_profile(name: str | None, profile: Profile) -> None:
    """Called by the TUI app after boot/profile-switch to keep command helpers in sync."""
    global _in_memory_profile  # noqa: PLW0603
    _in_memory_profile = (name, profile)


def _clear_in_memory_profile() -> None:
    """Called on logout to fall back to disk config."""
    global _in_memory_profile  # noqa: PLW0603
    _in_memory_profile = None


def _active_profile() -> tuple[str | None, Profile | None]:
    """Return the active profile name and config, or (None, None).

    Prefers the in-memory profile set by the TUI app (which respects --server
    overrides) over the persisted active profile on disk.
    """
    if _in_memory_profile is not None:
        return _in_memory_profile
    result = UserConfig.read().active_profile
    if result is None:
        return None, None
    return result


def _active_profile_name() -> str | None:
    """Return the active profile name, if any."""
    if _in_memory_profile is not None:
        return _in_memory_profile[0]
    return UserConfig.read().active_profile_name


def _disconnect_profile() -> str | None:
    """Revoke credentials for the active profile but keep the profile shell."""
    user_config = UserConfig.read()
    profile_name = user_config.active_profile_name
    if profile_name is None:
        return None
    user_config.disconnect(profile_name)
    user_config.write()
    return profile_name


def _delete_profile(profile_name: str) -> bool:
    """Delete a specific profile from user config."""
    user_config = UserConfig.read()
    deleted = user_config.delete(profile_name)
    if deleted:
        user_config.write()
    return deleted


def _platform_client() -> tuple[ApiClient, Profile]:
    """Create an ApiClient from the active profile."""
    profile_name, profile = _active_profile()
    if profile_name is None or profile is None:
        raise RuntimeError("Not logged in. Use /login first.")
    api = ApiClient(
        profile.url,
        api_key=profile.api_key or None,
    )
    return api, profile


# ---------------------------------------------------------------------------
# Event parsing helpers
# ---------------------------------------------------------------------------


def _extract_generation_text(payload: dict[str, t.Any]) -> str:
    """Extract generated text from a GenerationStep event payload."""
    messages = payload.get("messages")
    if isinstance(messages, list):
        parts: list[str] = []
        for message in messages:
            if not isinstance(message, dict) or message.get("role") != "assistant":
                continue
            parts.append(_extract_content_text(message.get("content")))
        return "".join(parts)
    return _extract_content_text(payload.get("content"))


def _extract_content_text(content: t.Any) -> str:
    """Extract plain text from various content payload shapes."""
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts: list[str] = []
        for item in content:
            if isinstance(item, str):
                parts.append(item)
            elif isinstance(item, dict):
                text = item.get("text")
                if isinstance(text, str):
                    parts.append(text)
        return "".join(parts)
    if isinstance(content, dict):
        text = content.get("text")
        if isinstance(text, str):
            return text
    return ""


def _extract_tool_call(payload: dict[str, t.Any]) -> tuple[str, dict[str, t.Any]]:
    """Extract tool call name and arguments from event payload."""
    tool_call = payload.get("tool_call") or payload.get("toolCall")
    if not isinstance(tool_call, dict):
        return "tool", {}

    name = tool_call.get("name") or "tool"
    raw_args = tool_call.get("arguments")
    function_payload = tool_call.get("function")
    if raw_args is None and isinstance(function_payload, dict):
        raw_args = function_payload.get("arguments")

    if isinstance(raw_args, dict):
        return name, raw_args
    if isinstance(raw_args, str):
        try:
            parsed = json.loads(raw_args)
        except json.JSONDecodeError:
            return name, {}
        if isinstance(parsed, dict):
            return name, parsed
    return name, {}


def _extract_tool_name(payload: dict[str, t.Any]) -> str:
    """Extract tool name from event payload."""
    name, _ = _extract_tool_call(payload)
    return name


# Key argument to show inline for each tool category
_TOOL_KEY_ARGS: dict[str, list[str]] = {
    # Execution tools
    "bash": ["command", "cmd"],
    "shell": ["command", "cmd"],
    "execute": ["cmd"],
    "python": ["code"],
    # File tools
    "read": ["file_path", "path", "filename", "url"],
    "read_file": ["file_path", "path"],
    "write": ["file_path", "path"],
    "write_file": ["file_path", "path"],
    "edit": ["file_path", "path"],
    "edit_file": ["path", "file_path"],
    "multiedit": ["path"],
    "insert_lines": ["path"],
    "delete_lines": ["path"],
    "apply_patch": ["patch_text"],
    # Search tools
    "grep": ["pattern", "query"],
    "search": ["pattern", "query"],
    "glob": ["pattern"],
    "find": ["pattern", "path"],
    "ls": ["path"],
    # Web tools
    "web_search": ["query"],
    "fetch": ["url"],
    # Interaction tools
    "think": ["thought"],
    "ask_user": ["question"],
    "finish_task": ["summary"],
}


_PATH_ARGS = {"file_path", "path", "filename", "url"}


def _truncate_arg(val: str, key: str, max_len: int) -> str:
    """Truncate a tool argument for display, preserving the meaningful part."""
    short = val.strip().replace("\n", " ")
    if len(short) <= max_len:
        return short
    # For path-like args, keep the filename and truncate the middle
    if key in _PATH_ARGS or "/" in short:
        # Find the last path component
        last_sep = short.rfind("/")
        if last_sep > 0:
            tail = short[last_sep:]  # e.g. "/conversation.py"
            if len(tail) < max_len - 4:  # room for ".../" prefix
                head_budget = max_len - len(tail) - 3  # 3 for "..."
                return short[:head_budget] + "..." + tail
    # Default: truncate from the right
    return short[:max_len] + "..."


def _format_tool_label(name: str, args: dict[str, t.Any], max_arg_len: int = 60) -> str:
    """Format tool name with its key argument: `read(pyproject.toml)`."""
    key_names = _TOOL_KEY_ARGS.get(name.lower(), [])
    for key in key_names:
        val = args.get(key)
        if isinstance(val, str) and val.strip():
            return f"{name}({_truncate_arg(val, key, max_arg_len)})"
    # Fallback: show first string arg if short enough
    for val in args.values():
        if isinstance(val, str) and val.strip() and len(val) < 40:
            short = val.strip().replace("\n", " ")
            return f"{name}({short})"
    return name


def _summarize_tool_result(name: str, args: dict[str, t.Any], result: t.Any) -> str | None:
    """Return a compact one-line summary of a tool result."""
    if result is None:
        return None

    def _first_line(text: str) -> str:
        lines = [line.strip() for line in text.splitlines() if line.strip()]
        if not lines:
            return ""
        first = lines[0]
        if len(lines) > 1:
            return f"{first[:100]}..."
        return first[:120] + ("..." if len(first) > 120 else "")

    def _get_text(res: t.Any) -> str:
        if isinstance(res, str):
            return res
        if isinstance(res, dict):
            return (
                str(res.get("stdout", ""))
                or str(res.get("output", ""))
                or str(res.get("error", ""))
                or str(res.get("stderr", ""))
            )
        if isinstance(res, list):
            return "\n".join(str(x) for x in res)
        return str(res)

    text = _get_text(result)
    if not text.strip():
        return None

    offload_match = re.search(
        r"\.\.\. \[(?P<lines>\d+) lines truncated — full output saved to (?P<path>[^\]]+)\] \.\.\.",
        text,
    )
    if offload_match:
        lines = offload_match.group("lines")
        path = offload_match.group("path")
        return f"Output truncated ({lines} lines). Saved to {path}."

    if "full output saved to" in text:
        path_match = re.search(r"full output saved to (?P<path>[^\s\]]+)", text)
        if path_match:
            return f"Output saved to {path_match.group('path')}."

    name_lower = name.lower()

    # Tool-specific smart summaries
    if name_lower in ("read", "read_file"):
        lines = len(text.splitlines())
        return f"Read {lines} line{'s' if lines != 1 else ''}."

    if name_lower in ("glob", "find", "search", "grep"):
        lines = len([line for line in text.splitlines() if line.strip()])
        return f"Found {lines} result{'s' if lines != 1 else ''}."

    if name_lower in ("ls", "list_directory", "list"):
        items = len(text.split())
        return f"Listed {items} item{'s' if items != 1 else ''}."

    if name_lower in ("bash", "shell", "run_command", "execute"):
        cmd = str(args.get("command", "") or args.get("cmd", "") or "").strip()
        if cmd.startswith("ls"):
            items = len(text.split())
            return f"Listed {items} item{'s' if items != 1 else ''}."

    if name_lower in ("edit", "replace", "write", "write_file", "patch"):
        return "Succeeded. File edited."

    # Fallback: Just show the first line of the output
    summary = _first_line(text)
    return summary or None


def _transcript_from_messages(
    messages: list[dict[str, t.Any]],
) -> list[t.Any]:
    """Build transcript entries from server /messages response.

    Pure function extracted from _rebuild_transcript_from_server so it
    can be tested independently.
    """
    from dreadnode.app.tui.widgets.conversation import TranscriptEntry

    entries: list[TranscriptEntry] = []
    for msg in messages:
        role = msg.get("role", "")
        content = msg.get("content", "")
        metadata = msg.get("metadata") or {}

        if metadata.get("compaction"):
            count = metadata.get("messages_compacted", "?")
            trigger = metadata.get("trigger", "manual")
            label = "Auto-compacted" if trigger == "threshold" else "Compacted"
            entries.append(
                TranscriptEntry(
                    kind="system",
                    title="compacted",
                    body=f"{label} — {count} messages summarized",
                    meta=content,
                )
            )
        elif role == "user":
            entries.append(TranscriptEntry(kind="user", title="user", body=content))
        elif role == "assistant":
            if not content.strip():
                continue  # Skip empty assistant messages (tool-only turns)
            entries.append(TranscriptEntry(kind="assistant", title="assistant", body=content))
        elif role == "tool":
            tool_name = msg.get("tool_name") or "tool"
            summary = _summarize_tool_result(tool_name, {}, content) if content else None
            entries.append(
                TranscriptEntry(kind="tool", title=tool_name, body=content, meta=summary)
            )
        elif role == "system":
            continue  # System prompts are not shown in transcript

    return entries
