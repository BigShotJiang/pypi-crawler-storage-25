"""MCP server management screen — inspect servers, browse tools, reconnect."""

from __future__ import annotations

import asyncio
import typing as t

from rich.text import Text
from textual.binding import Binding
from textual.containers import VerticalScroll
from textual.widgets import Static

from dreadnode.app.tui.screens.base import DreadnodeScreen
from dreadnode.app.tui.theme import (
    ACCENT,
    BRAND,
    ERROR,
    FG,
    FG_FAINTEST,
    FG_MUTED,
    SUCCESS,
    WARNING,
)

if t.TYPE_CHECKING:
    from textual.app import ComposeResult
    from textual.events import Key

    from dreadnode.app.tui.client import RuntimeServerClient


class McpScreen(DreadnodeScreen):
    """Full-screen MCP server manager — list, inspect, reconnect."""

    BINDINGS: t.ClassVar[list[Binding]] = [Binding("escape", "dismiss", "Back", show=False)]

    def __init__(
        self, runtime_client: RuntimeServerClient, servers: list[dict[str, t.Any]]
    ) -> None:
        super().__init__()
        self._client = runtime_client
        self._servers = servers  # from runtime_info components
        self._view: str = "list"  # list | detail | tool_list
        self._cursor: int = 0
        self._action_cursor: int = 0
        self._selected_server: dict[str, t.Any] | None = None
        self._server_detail: dict[str, t.Any] | None = None
        self._tool_search: str = ""
        self._loading: bool = False
        self._reconnecting: bool = False

    def compose_content(self) -> ComposeResult:
        yield Static(id="mcp-header")
        yield Static(id="mcp-search")
        with VerticalScroll(id="mcp-scroll"):
            yield Static(id="mcp-content")
        yield Static(id="mcp-hint")

    def on_mount(self) -> None:
        super().on_mount()
        self._render_current_view()

    def on_key(self, event: Key) -> None:
        key = event.key
        if key.startswith("ctrl+") or (key.startswith("f") and key[1:].isdigit()):
            return

        if self._view == "tool_list":
            self._handle_tool_list_key(key, event)
            if key != "escape":
                return  # let scroll keys pass through
        elif self._view == "detail":
            self._handle_detail_key(key)
        else:
            self._handle_list_key(key)

        event.prevent_default()
        event.stop()

    # ── List view ──

    def _handle_list_key(self, key: str) -> None:
        if key == "up":
            self._cursor = max(0, self._cursor - 1)
        elif key == "down":
            self._cursor = min(len(self._servers) - 1, self._cursor + 1)
        elif key == "enter" and self._servers:
            self._selected_server = self._servers[self._cursor]
            self._view = "detail"
            self._action_cursor = 0
            self._server_detail = None
            self._loading = True
            self._render_current_view()
            self._fetch_detail()
            return
        elif key == "escape":
            self.dismiss()
            return
        self._render_current_view()

    def _fetch_detail(self) -> None:
        """Kick off async detail fetch."""
        server = self._selected_server
        if server is None:
            return
        cap = server.get("capability", "")
        name = server.get("name", "")
        self.run_worker(self._do_fetch_detail(cap, name), exclusive=True)

    async def _do_fetch_detail(self, capability: str, server_name: str) -> None:
        try:
            self._server_detail = await self._client.fetch_mcp_detail(capability, server_name)
        except Exception as exc:
            self._server_detail = None
            self.notify(f"Failed to load detail: {exc}", title="MCP", severity="error")
        finally:
            self._loading = False
            self._render_current_view()

    def _render_list(self) -> None:
        header = self.query_one("#mcp-header", Static)
        content = self.query_one("#mcp-content", Static)
        hint = self.query_one("#mcp-hint", Static)

        count = len(self._servers)
        text = Text()
        text.append(" MCP Servers", style=f"bold {FG}")
        if count:
            text.append(f"  {count}", style=FG_MUTED)
        text.append("\n")
        text.append(" Inspect and manage MCP server connections", style=FG_FAINTEST)
        header.update(text)

        if not self._servers:
            content.update(Text("No MCP servers configured", style=f"italic {FG_MUTED}"))
            hint.update(Text("Esc close", style=FG_FAINTEST))
            return

        output = Text()
        current_cap = None
        for i, server in enumerate(self._servers):
            cap = server.get("capability", "")
            if cap != current_cap:
                if current_cap is not None:
                    output.append("\n")
                output.append(f"  {cap}\n", style=FG_MUTED)
                current_cap = cap

            is_selected = i == self._cursor
            prefix = "> " if is_selected else "  "

            status = server.get("status", "?")
            if status == "ok":
                icon, icon_style, label = "✓", SUCCESS, "connected"
            elif status == "degraded":
                icon, icon_style, label = "⚠", WARNING, server.get("detail", "degraded")
            else:
                icon, icon_style, label = "✗", ERROR, server.get("error", "error")

            transport = server.get("transport", "")
            tool_count = server.get("tool_count", 0)

            output.append(prefix, style=ACCENT if is_selected else "")
            output.append(server.get("name", "?"), style=f"bold {FG}" if is_selected else FG)
            output.append(" · ", style=FG_FAINTEST)
            output.append(f"{icon} ", style=icon_style)
            output.append(label, style=FG_MUTED)
            if transport:
                output.append(f" · {transport}", style=FG_FAINTEST)
            if tool_count:
                output.append(f" · {tool_count} tools", style=FG_FAINTEST)
            output.append("\n")

        content.update(output)
        hint.update(Text("↑↓ navigate · Enter select · Esc close", style=FG_FAINTEST))

    # ── Detail view ──

    def _handle_detail_key(self, key: str) -> None:
        actions = self._get_actions()
        if key == "up":
            self._action_cursor = max(0, self._action_cursor - 1)
        elif key == "down":
            self._action_cursor = min(len(actions) - 1, self._action_cursor + 1)
        elif key == "r":
            self._do_reconnect()
            return
        elif key == "enter" and actions:
            action_id = actions[self._action_cursor][0]
            if action_id == "view_tools":
                self._view = "tool_list"
                self._render_current_view()
                return
            if action_id == "reconnect":
                self._do_reconnect()
                return
        elif key == "escape":
            self._view = "list"
            self._server_detail = None
        self._render_current_view()

    def _connect_verb(self, past: bool = False) -> str:
        """Return 'Restart'/'Restarted' for stdio, 'Reconnect'/'Reconnected' otherwise."""
        transport = (self._server_detail or self._selected_server or {}).get("transport", "")
        if transport == "stdio":
            return "Restarted" if past else "Restart"
        return "Reconnected" if past else "Reconnect"

    def _get_actions(self) -> list[tuple[str, str]]:
        """Actions available in detail view."""
        actions: list[tuple[str, str]] = []
        detail = self._server_detail
        if detail and detail.get("tool_count", 0) > 0:
            actions.append(("view_tools", "View tools"))
        actions.append(("reconnect", self._connect_verb()))
        return actions

    def _do_reconnect(self) -> None:
        """Trigger reconnect/restart for current server."""
        server = self._selected_server
        if server is None:
            return
        cap = server.get("capability", "")
        name = server.get("name", "")
        self.run_worker(self._do_reconnect_async(cap, name), exclusive=True)

    async def _do_reconnect_async(self, capability: str, server_name: str) -> None:
        verb = self._connect_verb()
        self._reconnecting = True
        self._render_current_view()
        self.notify(f"{verb}ing...", title="MCP", severity="information", timeout=10)
        # Yield so the UI paints the transition state before blocking on reconnect
        await asyncio.sleep(0)
        try:
            self._server_detail = await self._client.reconnect_mcp_server(capability, server_name)
            status = self._server_detail.get("status", "")
            verb = self._connect_verb(past=True)
            if status in ("connected", "ok"):
                self.notify(verb, title="MCP", severity="information")
            else:
                error = self._server_detail.get("error", "unknown error")
                # Show only the first line — full stderr is already in the status section
                short = error.split("\n", 1)[0] if error else "unknown error"
                self.notify(
                    f"{self._connect_verb()} failed: {short}", title="MCP", severity="error"
                )
        except Exception as exc:
            self.notify(f"{self._connect_verb()} failed: {exc}", title="MCP", severity="error")
        finally:
            self._reconnecting = False
        self._render_current_view()

    def _render_detail(self) -> None:
        header = self.query_one("#mcp-header", Static)
        content = self.query_one("#mcp-content", Static)
        hint = self.query_one("#mcp-hint", Static)

        server = self._selected_server or {}
        detail = self._server_detail

        name = server.get("name", "?")
        text = Text()
        text.append(f" {name}", style=f"bold {FG}")
        text.append("\n")
        text.append(" MCP Server", style=FG_FAINTEST)
        header.update(text)

        output = Text()

        if self._loading:
            output.append("\n  Loading...\n", style=FG_MUTED)
            content.update(output)
            hint.update(Text("Esc back", style=FG_FAINTEST))
            return

        # Status
        status_val = (
            detail.get("status", server.get("status", "?")) if detail else server.get("status", "?")
        )
        if status_val in ("connected", "ok"):
            output.append("  Status: ", style=f"bold {FG}")
            output.append("connected\n", style=ACCENT)
        elif status_val in ("needs_auth", "degraded"):
            output.append("  Status: ", style=f"bold {FG}")
            output.append("needs authentication\n", style=WARNING)
        else:
            output.append("  Status: ", style=f"bold {FG}")
            output.append(f"failed ({status_val})\n", style=ERROR)
            error = (detail or server).get("error")
            if error:
                # Split off "Server stderr:" block — shown separately below
                parts = error.split("\n\nServer stderr:\n", 1)
                output.append(f"  Error: {parts[0]}\n", style=FG_MUTED)

        # Server info from detail endpoint
        if detail:
            transport = detail.get("transport", "")
            output.append("  Transport: ", style=f"bold {FG}")
            output.append(f"{transport}\n", style=FG_MUTED)

            if transport == "stdio":
                output.append("  Command: ", style=f"bold {FG}")
                output.append(f"{detail.get('command', '?')}\n", style=FG_MUTED)
                args = detail.get("args", [])
                if args:
                    output.append("  Args: ", style=f"bold {FG}")
                    output.append(f"{' '.join(str(a) for a in args)}\n", style=FG_MUTED)
            else:
                output.append("  URL: ", style=f"bold {FG}")
                output.append(f"{detail.get('url', '?')}\n", style=FG_MUTED)

            output.append("  Capability: ", style=f"bold {FG}")
            output.append(f"{detail.get('capability', '?')}\n", style=FG_MUTED)

            tool_count = detail.get("tool_count", 0)
            output.append("  Tools: ", style=f"bold {FG}")
            output.append(f"{tool_count} tool{'s' if tool_count != 1 else ''}\n", style=FG_MUTED)

            # Inline tools list (capped to avoid overwhelming the detail view)
            tools = detail.get("tools", [])
            max_inline = 8
            if tools:
                output.append("\n")
                for i, tool in enumerate(tools[:max_inline]):
                    desc = tool.get("description", "")
                    if len(desc) > 60:
                        desc = desc[:57] + "..."
                    output.append(f"    {i + 1}. ", style=FG_FAINTEST)
                    output.append(tool.get("name", "?"), style=FG)
                    if desc:
                        output.append(f" -- {desc}", style=FG_MUTED)
                    output.append("\n")
                if len(tools) > max_inline:
                    remaining = len(tools) - max_inline
                    output.append(
                        f"    ... and {remaining} more (View tools to see all)\n",
                        style=FG_FAINTEST,
                    )
            elif status_val not in ("connected", "ok"):
                output.append(
                    f"\n  Server disconnected -- {self._connect_verb().lower()} to view tools\n",
                    style=f"italic {FG_MUTED}",
                )

        # Server stderr (shown once, after detail fields)
        error = (detail or server).get("error", "") if detail else server.get("error", "")
        if error and "\n\nServer stderr:\n" in error:
            stderr_block = error.split("\n\nServer stderr:\n", 1)[1]
            output.append("\n")
            output.append("  Server stderr:\n", style=f"bold {FG}")
            for line in stderr_block.splitlines():
                output.append(f"    {line}\n", style=FG_MUTED)

        # Actions
        output.append("\n")
        if self._reconnecting:
            verb = self._connect_verb()
            output.append(f"  {verb}ing...\n", style=FG_FAINTEST)
        else:
            actions = self._get_actions()
            for i, (_action_id, label) in enumerate(actions):
                is_selected = i == self._action_cursor
                prefix = "> " if is_selected else "  "
                style = f"bold {FG}" if is_selected else FG
                output.append(f"  {prefix}{i + 1}. ", style=ACCENT if is_selected else FG_FAINTEST)
                output.append(f"{label}\n", style=style)

        content.update(output)
        hint.update(
            Text(
                f"up/down navigate · Enter select · r {self._connect_verb().lower()} · Esc back",
                style=FG_FAINTEST,
            )
        )

    # ── Tool list view ──

    def _handle_tool_list_key(self, key: str, event: Key) -> None:
        if key == "escape":
            if self._tool_search:
                self._tool_search = ""
                self._render_current_view()
            else:
                self._tool_search = ""
                self._view = "detail"
                self._action_cursor = 0
                self._render_current_view()
            return
        if key == "backspace":
            if self._tool_search:
                self._tool_search = self._tool_search[:-1]
                self._render_current_view()
            return
        # Type-to-search: printable characters filter the tool list
        if event.character and event.character.isprintable() and len(event.character) == 1:
            self._tool_search += event.character
            self._render_current_view()
            return
        # Let scroll keys pass through to VerticalScroll

    def _render_tool_list(self) -> None:
        header = self.query_one("#mcp-header", Static)
        content = self.query_one("#mcp-content", Static)
        hint = self.query_one("#mcp-hint", Static)

        all_tools = (self._server_detail or {}).get("tools", [])
        server_name = (self._selected_server or {}).get("name", "?")
        cap_name = (self._selected_server or {}).get("capability", "?")

        # Filter by search query
        query = self._tool_search.lower()
        tools = [
            tool
            for tool in all_tools
            if not query
            or query in tool.get("name", "").lower()
            or query in tool.get("description", "").lower()
        ]

        text = Text()
        text.append(" Tools", style=f"bold {FG}")
        text.append(
            f"  {len(tools)}/{len(all_tools)}" if query else f"  {len(all_tools)}", style=FG_MUTED
        )
        text.append("\n")
        text.append(f" {server_name}", style=FG_FAINTEST)
        header.update(text)

        # Search bar
        search_bar = self.query_one("#mcp-search", Static)
        search_text = Text()
        if self._tool_search:
            search_text.append(f" \u2315 {self._tool_search}", style=FG)
            search_text.append("\u2581", style=FG_FAINTEST)
        else:
            search_text.append(" \u2315 Search\u2026", style=FG_FAINTEST)
        search_bar.update(search_text)

        output = Text()
        if query and not tools:
            output.append(f'No tools matching "{self._tool_search}"\n', style=f"italic {FG_MUTED}")

        for i, tool in enumerate(tools):
            if i > 0:
                output.append(
                    "────────────────────────────────────────────────\n", style=FG_FAINTEST
                )

            tool_name = tool.get("name", "?")
            qualified = f"{cap_name}:{server_name}:{tool_name}"

            output.append(f"{tool_name}  ", style=f"bold {BRAND}")
            output.append(f"{qualified}\n", style=FG_FAINTEST)
            output.append("\n")

            schema = tool.get("input_schema", {})
            properties = schema.get("properties", {})
            required_params = set(schema.get("required", []))

            if properties:
                for param_name, param_info in properties.items():
                    req_label = "required" if param_name in required_params else "optional"
                    param_type = param_info.get("type", "any")

                    output.append(param_name, style=FG)
                    output.append(f" ({req_label}): {param_type}", style=FG_MUTED)
                    param_desc = param_info.get("description")
                    if param_desc:
                        output.append(f" -- {param_desc}", style=FG_FAINTEST)
                    output.append("\n")

                output.append("\n")

            desc = tool.get("description", "")
            if desc:
                output.append(f"{desc}\n", style=FG_MUTED)

        content.update(output)
        hint.update(Text("Type to search · Esc back", style=FG_FAINTEST))

    # ── Rendering dispatch ──

    def _render_current_view(self) -> None:
        # Show search bar only in tool_list view
        search = self.query_one("#mcp-search", Static)
        search.display = self._view == "tool_list"

        if self._view == "list":
            self._render_list()
        elif self._view == "detail":
            self._render_detail()
        elif self._view == "tool_list":
            self._render_tool_list()
