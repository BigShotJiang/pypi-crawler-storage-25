"""Runtime subcommands for the cyclopts CLI."""

import typing as t

import cyclopts

from dreadnode.app.cli.args import PlatformScopeArgs
from dreadnode.app.cli.shared import _render, _render_list, _status_color

cli = cyclopts.App(name="runtime", help="Manage agent runtime environments.")


def _summarize_runtime(p: dict[str, t.Any]) -> str:
    runtime_id = p.get("id", "unknown")
    state = p.get("state", "unknown")
    name = p.get("name") or p.get("runtime_type", "unknown")
    color = _status_color(state)
    return f"[dim]{runtime_id}[/dim] [{color}]{state}[/{color}] [cyan]{name}[/cyan]"


# ---------------------------------------------------------------------------
# list
# ---------------------------------------------------------------------------


@cli.command(name="list")
def list_(
    *,
    as_json: t.Annotated[bool, cyclopts.Parameter(name="--json", negative=())] = False,
    platform: PlatformScopeArgs = PlatformScopeArgs(),
) -> None:
    """List available runtimes."""
    api, profile = platform.connect()
    payload = api.list_runtimes(profile.org_key, profile.workspace_key)
    _render_list(
        payload, as_json=as_json, summary=_summarize_runtime, empty_msg="No runtimes found"
    )


# ---------------------------------------------------------------------------
# get
# ---------------------------------------------------------------------------


@cli.command()
def get(
    runtime_id: str,
    *,
    as_json: t.Annotated[bool, cyclopts.Parameter(name="--json", negative=())] = False,
    platform: PlatformScopeArgs = PlatformScopeArgs(),
) -> None:
    """Get details of a runtime."""
    api, profile = platform.connect()
    payload = api.get_runtime(profile.org_key, profile.workspace_key, runtime_id)
    _render(payload, as_json=as_json, summary=_summarize_runtime)
