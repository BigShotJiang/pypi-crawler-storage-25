"""AIRT subcommands for the cyclopts CLI."""

import json
import typing as t

import cyclopts

from dreadnode.app.cli.args import PlatformScopeArgs
from dreadnode.app.cli.shared import (
    _print_json,
    _render,
    _render_list,
    _status_color,
    _summarize_sandbox,
    console,
)

cli = cyclopts.App(name="airt", help="AI red teaming for models and agents.")


# ---------------------------------------------------------------------------
# Local helpers
# ---------------------------------------------------------------------------


def _parse_json_option(value: str | None, *, field_name: str) -> t.Any:
    if value is None:
        return None
    try:
        return json.loads(value)
    except json.JSONDecodeError as exc:
        raise ValueError(f"{field_name} must be valid JSON") from exc


def _parse_json_object_option(value: str | None, *, field_name: str) -> dict[str, t.Any] | None:
    parsed = _parse_json_option(value, field_name=field_name)
    if parsed is None:
        return None
    if not isinstance(parsed, dict):
        raise TypeError(f"{field_name} must decode to a JSON object")
    return parsed


def _summarize_assessment(p: dict[str, t.Any]) -> str:
    job_id = p.get("id", "unknown")
    status = p.get("status", "unknown")
    name = p.get("name") or "unnamed-assessment"
    color = _status_color(status)
    return f"[dim]{job_id}[/dim] [{color}]{status}[/{color}] [cyan]{name}[/cyan]"


def _summarize_report(p: dict[str, t.Any]) -> str:
    report_id = p.get("id", "unknown")
    report_type = p.get("report_type", "unknown")
    created_at = p.get("created_at", "unknown")
    return f"[dim]{report_id}[/dim] [cyan]{report_type}[/cyan] [dim]{created_at}[/dim]"


# ---------------------------------------------------------------------------
# create
# ---------------------------------------------------------------------------


@cli.command()
def create(
    *,
    name: str,
    project_id: str,
    description: t.Annotated[str | None, cyclopts.Parameter(help="Assessment description")] = None,
    session_id: t.Annotated[str | None, cyclopts.Parameter(help="Session ID to associate")] = None,
    target_config: t.Annotated[
        str | None, cyclopts.Parameter(help="Target configuration as JSON")
    ] = None,
    attacker_config: t.Annotated[
        str | None, cyclopts.Parameter(help="Attacker configuration as JSON")
    ] = None,
    attack_manifest: t.Annotated[
        str | None, cyclopts.Parameter(help="Attack manifest as JSON")
    ] = None,
    workflow_run_id: t.Annotated[str | None, cyclopts.Parameter(help="Workflow run ID")] = None,
    workflow_script: t.Annotated[
        str | None, cyclopts.Parameter(help="Workflow script content")
    ] = None,
    as_json: t.Annotated[bool, cyclopts.Parameter(name="--json", negative=())] = False,
    platform: PlatformScopeArgs = PlatformScopeArgs(),
) -> None:
    """Create a new AIRT assessment."""
    api, profile = platform.connect()
    payload = api.create_airt_assessment(
        profile.org_key,
        profile.workspace_key,
        name=name,
        project_id=project_id,
        description=description,
        session_id=session_id,
        target_config=_parse_json_object_option(target_config, field_name="--target-config"),
        attacker_config=_parse_json_object_option(attacker_config, field_name="--attacker-config"),
        attack_manifest=_parse_json_option(attack_manifest, field_name="--attack-manifest"),
        workflow_run_id=workflow_run_id,
        workflow_script=workflow_script,
    )
    _render(payload, as_json=as_json, summary=_summarize_assessment)


# ---------------------------------------------------------------------------
# list
# ---------------------------------------------------------------------------


@cli.command(name="list")
def list_(
    *,
    project_id: t.Annotated[str | None, cyclopts.Parameter(help="Project ID filter")] = None,
    page: int = 1,
    page_size: int = 50,
    as_json: t.Annotated[bool, cyclopts.Parameter(name="--json", negative=())] = False,
    platform: PlatformScopeArgs = PlatformScopeArgs(),
) -> None:
    """List AIRT assessments."""
    api, profile = platform.connect()
    payload = api.list_airt_assessments(
        profile.org_key,
        profile.workspace_key,
        project_id=project_id,
        page=page,
        page_size=page_size,
    )
    _render_list(
        payload, as_json=as_json, summary=_summarize_assessment, empty_msg="No assessments found"
    )


# ---------------------------------------------------------------------------
# get
# ---------------------------------------------------------------------------


@cli.command()
def get(
    assessment_id: str,
    *,
    as_json: t.Annotated[bool, cyclopts.Parameter(name="--json", negative=())] = False,
    platform: PlatformScopeArgs = PlatformScopeArgs(),
) -> None:
    """Get an AIRT assessment by ID."""
    api, profile = platform.connect()
    payload = api.get_airt_assessment(profile.org_key, profile.workspace_key, assessment_id)
    _render(payload, as_json=as_json, summary=_summarize_assessment)


# ---------------------------------------------------------------------------
# update
# ---------------------------------------------------------------------------


@cli.command()
def update(
    assessment_id: str,
    *,
    name: t.Annotated[str | None, cyclopts.Parameter(help="New assessment name")] = None,
    description: t.Annotated[
        str | None, cyclopts.Parameter(help="New assessment description")
    ] = None,
    status: t.Annotated[
        t.Literal["pending", "running", "completed", "failed"] | None,
        cyclopts.Parameter(help="Assessment status"),
    ] = None,
    as_json: t.Annotated[bool, cyclopts.Parameter(name="--json", negative=())] = False,
    platform: PlatformScopeArgs = PlatformScopeArgs(),
) -> None:
    """Update an AIRT assessment."""
    api, profile = platform.connect()
    payload = api.update_airt_assessment(
        profile.org_key,
        profile.workspace_key,
        assessment_id,
        status=status,
        name=name,
        description=description,
    )
    _render(payload, as_json=as_json, summary=_summarize_assessment)


# ---------------------------------------------------------------------------
# delete
# ---------------------------------------------------------------------------


@cli.command()
def delete(
    assessment_id: str,
    *,
    platform: PlatformScopeArgs = PlatformScopeArgs(),
) -> None:
    """Delete an AIRT assessment."""
    api, profile = platform.connect()
    api.delete_airt_assessment(profile.org_key, profile.workspace_key, assessment_id)
    console.print(f"Deleted AIRT assessment [dim]{assessment_id}[/dim]")


# ---------------------------------------------------------------------------
# sandbox
# ---------------------------------------------------------------------------


@cli.command()
def sandbox(
    assessment_id: str,
    *,
    as_json: t.Annotated[bool, cyclopts.Parameter(name="--json", negative=())] = False,
    platform: PlatformScopeArgs = PlatformScopeArgs(),
) -> None:
    """Get the sandbox linked to an AIRT assessment."""
    api, profile = platform.connect()
    payload = api.get_airt_assessment_sandbox(
        profile.org_key,
        profile.workspace_key,
        assessment_id,
    )
    _render(payload, as_json=as_json, summary=_summarize_sandbox)


# ---------------------------------------------------------------------------
# reports
# ---------------------------------------------------------------------------


@cli.command()
def reports(
    assessment_id: str,
    *,
    as_json: t.Annotated[bool, cyclopts.Parameter(name="--json", negative=())] = False,
    platform: PlatformScopeArgs = PlatformScopeArgs(),
) -> None:
    """List reports for an AIRT assessment."""
    api, profile = platform.connect()
    payload = api.list_airt_reports(profile.org_key, profile.workspace_key, assessment_id)
    _render_list(payload, as_json=as_json, summary=_summarize_report, empty_msg="No reports found")


# ---------------------------------------------------------------------------
# report
# ---------------------------------------------------------------------------


@cli.command()
def report(
    assessment_id: str,
    report_id: str,
    *,
    platform: PlatformScopeArgs = PlatformScopeArgs(),
) -> None:
    """Get a specific report for an AIRT assessment."""
    api, profile = platform.connect()
    payload = api.get_airt_report(profile.org_key, profile.workspace_key, assessment_id, report_id)
    _print_json(payload)


# ---------------------------------------------------------------------------
# analytics
# ---------------------------------------------------------------------------


@cli.command()
def analytics(
    assessment_id: str,
    *,
    platform: PlatformScopeArgs = PlatformScopeArgs(),
) -> None:
    """Get analytics for an AIRT assessment."""
    api, profile = platform.connect()
    payload = api.get_airt_analytics(profile.org_key, profile.workspace_key, assessment_id)
    _print_json(payload)


# ---------------------------------------------------------------------------
# traces
# ---------------------------------------------------------------------------


@cli.command()
def traces(
    assessment_id: str,
    *,
    platform: PlatformScopeArgs = PlatformScopeArgs(),
) -> None:
    """Get trace stats for an AIRT assessment."""
    api, profile = platform.connect()
    payload = api.get_airt_trace_stats(profile.org_key, profile.workspace_key, assessment_id)
    _print_json(payload)


# ---------------------------------------------------------------------------
# attacks
# ---------------------------------------------------------------------------


@cli.command()
def attacks(
    assessment_id: str,
    *,
    platform: PlatformScopeArgs = PlatformScopeArgs(),
) -> None:
    """Get attack spans for an AIRT assessment."""
    api, profile = platform.connect()
    payload = api.get_airt_attack_spans(profile.org_key, profile.workspace_key, assessment_id)
    _print_json(payload)


# ---------------------------------------------------------------------------
# trials
# ---------------------------------------------------------------------------


@cli.command()
def trials(
    assessment_id: str,
    *,
    attack_name: t.Annotated[str | None, cyclopts.Parameter(help="Filter by attack name")] = None,
    min_score: t.Annotated[float | None, cyclopts.Parameter(help="Minimum score filter")] = None,
    jailbreaks_only: t.Annotated[bool, cyclopts.Parameter(negative=())] = False,
    limit: t.Annotated[int, cyclopts.Parameter(help="Maximum results to return")] = 100,
    platform: PlatformScopeArgs = PlatformScopeArgs(),
) -> None:
    """Get trial spans for an AIRT assessment."""
    api, profile = platform.connect()
    payload = api.get_airt_trial_spans(
        profile.org_key,
        profile.workspace_key,
        assessment_id,
        attack_name=attack_name,
        min_score=min_score,
        jailbreaks_only=jailbreaks_only,
        limit=limit,
    )
    _print_json(payload)


# ---------------------------------------------------------------------------
# project-summary
# ---------------------------------------------------------------------------


@cli.command(name="project-summary")
def project_summary(
    project: str,
    *,
    platform: PlatformScopeArgs = PlatformScopeArgs(),
) -> None:
    """Get a summary for an AIRT project."""
    api, profile = platform.connect()
    payload = api.get_airt_project_summary(profile.org_key, profile.workspace_key, project)
    _print_json(payload)


# ---------------------------------------------------------------------------
# findings
# ---------------------------------------------------------------------------


@cli.command()
def findings(
    project: str,
    *,
    severity: t.Annotated[str | None, cyclopts.Parameter(help="Severity filter")] = None,
    category: t.Annotated[str | None, cyclopts.Parameter(help="Category filter")] = None,
    attack_name: t.Annotated[str | None, cyclopts.Parameter(help="Attack name filter")] = None,
    min_score: t.Annotated[float | None, cyclopts.Parameter(help="Minimum score filter")] = None,
    sort_by: t.Literal["score", "severity", "category", "attack_name", "created_at"] = "score",
    sort_dir: t.Literal["asc", "desc"] = "desc",
    page: int = 1,
    page_size: int = 50,
    platform: PlatformScopeArgs = PlatformScopeArgs(),
) -> None:
    """Get findings for an AIRT project."""
    api, profile = platform.connect()
    payload = api.get_airt_project_findings(
        profile.org_key,
        profile.workspace_key,
        project,
        severity=severity,
        category=category,
        attack_name=attack_name,
        min_score=min_score,
        sort_by=sort_by,
        sort_dir=sort_dir,
        page=page,
        page_size=page_size,
    )
    _print_json(payload)


# ---------------------------------------------------------------------------
# generate-project-report
# ---------------------------------------------------------------------------


@cli.command(name="generate-project-report")
def generate_project_report(
    project: str,
    *,
    format: t.Literal["markdown", "json", "both"] = "both",
    model_profile: t.Annotated[str | None, cyclopts.Parameter(help="Model profile as JSON")] = None,
    platform: PlatformScopeArgs = PlatformScopeArgs(),
) -> None:
    """Generate a report for an AIRT project."""
    api, profile = platform.connect()
    payload = api.generate_airt_project_report(
        profile.org_key,
        profile.workspace_key,
        project,
        fmt=format,
        model_profile=_parse_json_object_option(model_profile, field_name="--model-profile"),
    )
    _print_json(payload)
