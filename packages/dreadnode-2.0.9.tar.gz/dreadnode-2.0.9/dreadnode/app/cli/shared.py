"""Shared utility functions for the cyclopts CLI."""

import json
import time
import typing as t
from dataclasses import dataclass
from urllib.parse import urlencode

if t.TYPE_CHECKING:
    from dreadnode.app.cli.args import PlatformArgs
    from dreadnode.app.main import Dreadnode

from dreadnode.core.log import console

T = t.TypeVar("T")


# ---------------------------------------------------------------------------
# Standardized output helpers
# ---------------------------------------------------------------------------


def print_success(message: str, *, indent: int = 0) -> None:
    console.print(f"{' ' * indent}[green]✓[/] {message}")


def print_error(message: str, *, indent: int = 0) -> None:
    console.print(f"{' ' * indent}[red]✗[/] {message}")


def print_warning(message: str, *, indent: int = 0) -> None:
    console.print(f"{' ' * indent}[yellow]![/] {message}")


def print_skip(message: str, *, indent: int = 0) -> None:
    console.print(f"{' ' * indent}[dim]-[/] {message}")


def print_link(profile_url: str, path: str, **query: str) -> None:
    """Print a clickable platform web URL.

    Builds the URL from the server base URL (stripping any ``/api/v1`` suffix),
    the given path, and optional query parameters.
    """
    root = profile_url.rstrip("/")
    for suffix in ("/api/v1", "/api"):
        if root.endswith(suffix):
            root = root[: -len(suffix)]
            break
    qs = f"?{urlencode(query)}" if query else ""
    url = f"{root}/{path.lstrip('/')}{qs}"
    console.print()
    console.print(f"  [dim]→[/dim] [u][link={url}]View on web[/link][/u]")


# ---------------------------------------------------------------------------
# Dreadnode factory
# ---------------------------------------------------------------------------


def configured_dreadnode(args: "PlatformArgs") -> "Dreadnode":
    """Build a configured Dreadnode instance from CLI args."""
    from dreadnode.app.main import Dreadnode

    profile = args.resolve()
    return Dreadnode().configure(
        server=profile.url,
        api_key=profile.api_key,
        organization=profile.organization,
        workspace=profile.workspace,
        project=profile.project,
    )


# ---------------------------------------------------------------------------
# JSON helpers
# ---------------------------------------------------------------------------


def _jsonable(value: t.Any) -> t.Any:
    if hasattr(value, "model_dump"):
        return value.model_dump(mode="json")
    if isinstance(value, list):
        return [_jsonable(item) for item in value]
    if isinstance(value, dict):
        return {key: _jsonable(item) for key, item in value.items()}
    if hasattr(value, "__dict__"):
        return {
            key: _jsonable(item) for key, item in vars(value).items() if not key.startswith("_")
        }
    return value


def _print_json(value: t.Any) -> None:
    print(json.dumps(_jsonable(value), indent=2, sort_keys=True))


# ---------------------------------------------------------------------------
# Parsing helpers
# ---------------------------------------------------------------------------


@dataclass(frozen=True, kw_only=True)
class ArtifactRef:
    """Resolved artifact reference with org always set and name always bare.

    Examples (with default_org='myorg'):
        my-cap            → org=myorg, name=my-cap, version=None
        my-cap@1.0.0      → org=myorg, name=my-cap, version=1.0.0
        acme/my-cap       → org=acme,  name=my-cap, version=None
        acme/my-cap@1.0.0 → org=acme,  name=my-cap, version=1.0.0
    """

    org: str
    name: str
    version: str | None = None

    @classmethod
    def parse(cls, value: str, default_org: str) -> "ArtifactRef":
        """Parse [org/]name[@version] with org fallback."""
        org, name, version = _parse_ref(value)
        return cls(org=org or default_org, name=name, version=version)

    @classmethod
    def parse_versioned(cls, value: str, default_org: str) -> "VersionedRef":
        """Parse a reference that requires a version (e.g. my-cap@1.0.0)."""
        org, name, version = _parse_ref(value)
        if not version:
            raise ValueError(f"version required (e.g. {name}@1.0.0)")
        return VersionedRef(org=org or default_org, name=name, version=version)

    @property
    def qualified_name(self) -> str:
        """Org-qualified name: 'org/name'."""
        return f"{self.org}/{self.name}"

    def with_version(self, version: str) -> "VersionedRef":
        """Return a VersionedRef with the given version."""
        return VersionedRef(org=self.org, name=self.name, version=version)

    def format(self) -> str:
        """Rich-formatted display string: org/name@version."""
        v = self.version or "latest"
        return f"[dim]{self.org}/[/dim][cyan]{self.name}[/cyan]@[dim]{v}[/dim]"


@dataclass(frozen=True, kw_only=True)
class VersionedRef(ArtifactRef):
    """ArtifactRef with version guaranteed non-None.

    Created only through ArtifactRef.parse_versioned(),
    ArtifactRef.with_version(), or ensure_version().
    """

    version: str


def _parse_ref(value: str) -> tuple[str | None, str, str | None]:
    """Shared parsing logic for artifact references."""
    version: str | None = None
    if "@" in value:
        value, version = value.rsplit("@", 1)
        version = version.strip().strip("/") or None
        if version and version.lower() == "latest":
            version = None

    org: str | None = None
    if "/" in value:
        org, value = value.split("/", 1)
        org = org.strip().strip("/") or None

    name = value.strip().strip("/")
    if not name:
        raise ValueError("artifact name cannot be empty")

    return org, name, version


# ---------------------------------------------------------------------------
# Color helpers
# ---------------------------------------------------------------------------


def _status_color(status: str) -> str:
    """Return Rich markup color for a job/resource status."""
    status_lower = status.lower()
    if status_lower in {"running", "pending", "queued", "starting", "uploading"}:
        return "yellow"
    if status_lower in {"completed", "success", "succeeded", "ready", "active"}:
        return "green"
    if status_lower in {"failed", "cancelled", "error", "stopped"}:
        return "red"
    return "default"


def _visibility_markup(visibility: str) -> str:
    """Return Rich-formatted visibility label."""
    if visibility == "public":
        return "[green]public[/green]"
    return "[bright_blue]private[/bright_blue]"


ArtifactType = t.Literal["capability", "dataset", "model", "task"]

_VERSION_LIST_METHODS: dict[str, str] = {
    "capability": "list_capability_versions",
    "dataset": "list_dataset_versions",
    "model": "list_model_versions",
    "task": "list_task_versions",
}


def ensure_version(api: t.Any, artifact_type: ArtifactType, ref: ArtifactRef) -> VersionedRef:
    """Return a VersionedRef, resolving latest from the API if needed."""
    if ref.version:
        return ref.with_version(ref.version)
    method = getattr(api, _VERSION_LIST_METHODS[artifact_type])
    payload = method(ref.org, ref.name)
    versions = payload.get("versions", [])
    if not versions:
        raise ValueError(f"No versions found for {ref.name}")
    return ref.with_version(str(versions[0]))


def ensure_name_only_refs(raw_refs: list[str], default_org: str) -> list[ArtifactRef]:
    """Parse refs for name-level operations and reject version-qualified inputs."""
    refs = [ArtifactRef.parse(value, default_org) for value in raw_refs]
    invalid = [ref for ref in refs if ref.version is not None]
    if invalid:
        joined = ", ".join(f"{ref.qualified_name}@{ref.version}" for ref in invalid)
        raise ValueError(f"visibility is name-level; omit @version for: {joined}")
    return refs


def resolve_publish_flag(publish: bool, public_compat: bool) -> bool:
    """Resolve publish intent, warning when the deprecated compatibility flag is used."""
    if public_compat:
        print_warning("--public is deprecated; use --publish")
    return publish or public_compat


# ---------------------------------------------------------------------------
# Render helpers
# ---------------------------------------------------------------------------

SummaryFn = t.Callable[[dict[str, t.Any]], str]
"""Takes a JSON-serializable dict, returns a one-line human summary."""

PageFetcher = t.Callable[[int, int], t.Any]
"""(page, page_size) -> raw API client response (dict or list)."""


def _collect_pages(
    fetch: PageFetcher,
    *,
    limit: int,
    page_size: int = 100,
    items_key: str = "items",
) -> list[dict[str, t.Any]]:
    """Fetch successive pages until *limit* items are collected or results are exhausted.

    Works with API methods that return either a paginated dict (with *items_key*)
    or a plain list.  Page size is kept constant across requests so that
    server-side offset calculations stay aligned.
    """
    collected: list[dict[str, t.Any]] = []
    page = 1
    while len(collected) < limit:
        result = fetch(page, page_size)
        if isinstance(result, dict):
            items = result.get(items_key, [])
        else:
            items = _to_payload(result)
        collected.extend(
            _to_payload(item) if not isinstance(item, dict) else item for item in items
        )
        if len(items) < page_size:
            break
        page += 1
    return collected[:limit]


def _to_payload(obj: t.Any) -> t.Any:
    """Normalize a response object (Pydantic model or raw dict/list) to JSON-serializable form."""
    if hasattr(obj, "model_dump"):
        return obj.model_dump(mode="json")
    if isinstance(obj, list):
        return [_to_payload(item) for item in obj]
    if isinstance(obj, dict):
        return obj
    if hasattr(obj, "__dict__"):
        return _jsonable(obj)
    return obj


def _render(obj: t.Any, *, as_json: bool, summary: SummaryFn) -> None:
    """Render a single item as JSON or a one-line summary."""
    payload = _to_payload(obj)
    if as_json:
        print(json.dumps(payload, indent=2, sort_keys=True))
    else:
        console.print(summary(payload))


def _render_list(
    obj: t.Any,
    *,
    as_json: bool,
    summary: SummaryFn,
    empty_msg: str,
    items_key: str = "items",
) -> None:
    """Render a paginated list as JSON or per-item summaries."""
    payload = _to_payload(obj)
    if as_json:
        print(json.dumps(payload, indent=2, sort_keys=True))
        return
    items = payload.get(items_key, []) if isinstance(payload, dict) else payload
    if not items:
        console.print(f"[dim]{empty_msg}[/dim]")
        return
    for item in items:
        console.print(summary(_jsonable(item) if not isinstance(item, dict) else item))


def _render_logs(obj: t.Any, *, as_json: bool) -> None:
    """Render a log response (training or optimization)."""
    payload = _to_payload(obj)
    if as_json:
        print(json.dumps(payload, indent=2, sort_keys=True))
        return
    for entry in payload.get("items", []):
        level = entry["level"]
        level_color = (
            "red" if level in {"ERROR", "CRITICAL"} else "yellow" if level == "WARNING" else "dim"
        )
        console.print(
            f"[dim]{entry['timestamp']}[/dim] [{level_color}]{level}[/{level_color}] {entry['message']}"
        )


def _render_artifacts(obj: t.Any, *, as_json: bool) -> None:
    """Render an artifacts response (training or optimization)."""
    payload = _to_payload(obj)
    if as_json:
        print(json.dumps(payload, indent=2, sort_keys=True))
        return
    print(json.dumps(payload.get("artifacts", {}), indent=2, sort_keys=True))


# --- Shared summary functions (used by multiple domain modules) ---


def _summarize_package(p: dict[str, t.Any]) -> str:
    name = p.get("full_name") or p.get("name", "unknown")
    version = p.get("latest_version") or p.get("version", "unknown")
    visibility = p.get("visibility", "private")
    return f"[cyan]{name}[/cyan]@[dim]{version}[/dim] {_visibility_markup(visibility)}"


def _summarize_sandbox(payload: dict[str, t.Any]) -> str:
    sandbox_id = payload.get("id", "unknown")
    provider_sandbox_id = payload.get("provider_sandbox_id", "unknown")
    state = payload.get("state", "unknown")
    sandbox_kind = payload.get("sandbox_kind", "unknown")
    project_key = payload.get("project_key")
    color = _status_color(state)
    project_suffix = f" [dim]project={project_key}[/dim]" if project_key else ""
    return (
        f"[dim]{sandbox_id}[/dim] [{color}]{state}[/{color}] "
        f"[cyan]{sandbox_kind}[/cyan] [dim]{provider_sandbox_id}[/dim]{project_suffix}"
    )


def _render_package_list(packages: t.Any, *, as_json: bool) -> None:
    _render_list(
        packages, as_json=as_json, summary=_summarize_package, empty_msg="No packages found"
    )


# ---------------------------------------------------------------------------
# Wait / poll helpers
# ---------------------------------------------------------------------------

_TERMINAL_STATUSES = {"completed", "partial", "failed", "cancelled"}


def _get_status(obj: t.Any) -> str | None:
    """Extract status from a Pydantic model (.status) or raw dict (.get('status'))."""
    if hasattr(obj, "status"):
        return obj.status
    if isinstance(obj, dict):
        return obj.get("status")
    return None


def _wait_for_job(
    poll_fn: t.Callable[[], T],
    *,
    job_id: str,
    label: str,
    poll_interval_sec: float,
    timeout_sec: float | None,
) -> T:
    """Generic poll-until-terminal loop. ``poll_fn`` takes no args and returns the job."""
    deadline = None if timeout_sec is None else time.monotonic() + timeout_sec
    while True:
        job = poll_fn()
        if _get_status(job) in _TERMINAL_STATUSES:
            return job
        if deadline is not None and time.monotonic() >= deadline:
            raise TimeoutError(f"Timed out waiting for {label} job {job_id}")
        time.sleep(poll_interval_sec)


# ---------------------------------------------------------------------------
# Sync progress callback
# ---------------------------------------------------------------------------


def _sync_progress(name: str, status: str, error: str | None) -> None:
    if status == "uploaded":
        print_success(name, indent=2)
    elif status == "skipped":
        print_skip(name, indent=2)
    elif status == "failed":
        print_error(f"{name}: {error}", indent=2)
