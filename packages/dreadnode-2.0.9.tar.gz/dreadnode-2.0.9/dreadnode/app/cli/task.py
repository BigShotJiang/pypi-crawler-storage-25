"""Task subcommands for the cyclopts CLI."""

import re
import subprocess
import typing as t
from pathlib import Path

import cyclopts

from dreadnode.app.cli.args import PlatformArgs
from dreadnode.app.cli.shared import (
    ArtifactRef,
    _collect_pages,
    _print_json,
    _render_list,
    _sync_progress,
    _visibility_markup,
    configured_dreadnode,
    console,
    ensure_name_only_refs,
    ensure_version,
    print_error,
    print_success,
    print_warning,
    resolve_publish_flag,
)
from dreadnode.packaging.task_validation import ValidationIssue

cli = cyclopts.App(
    name="task",
    help="Environments with success conditions that agents operate in — for evaluations, training, and optimization.",
)


# ---------------------------------------------------------------------------
# Local helpers
# ---------------------------------------------------------------------------

_NAME_PATTERN = re.compile(r"^[a-z0-9][a-z0-9-]*$")


def _summarize_task(p: dict[str, t.Any]) -> str:
    name = p.get("name", "unknown")
    visibility = "public" if p.get("is_public") else "private"
    difficulty = p.get("difficulty")
    category = p.get("category")
    parts = [f"[cyan]{name}[/cyan] {_visibility_markup(visibility)}"]
    meta = [m for m in (category, difficulty) if m]
    if meta:
        parts.append(f"[dim]{' · '.join(meta)}[/dim]")
    return "  ".join(parts)


def _write_file(path: Path, content: str) -> None:
    """Write a file, creating parent directories as needed."""
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content)


# ---------------------------------------------------------------------------
# Starter templates for `init`
# ---------------------------------------------------------------------------

_TASK_YAML = """\
instruction: |
  {description}

  The challenge service is available at: {{{{challenge_url}}}}

  Find the flag and write it to /app/result.txt

difficulty: {difficulty}
category: {category}
tags: [{tags}]

ports:
  challenge: [8080]

verification:
  method: flag
  flag_hash: "sha256:REPLACE_WITH_FLAG_HASH"
  submission_path: /app/result.txt
"""

_DOCKER_COMPOSE_YAML = """\
services:
  challenge:
    build: ./challenge
    ports:
      - "8080:8080"
    healthcheck:
      test: ["CMD", "wget", "-q", "--spider", "http://127.0.0.1:8080/"]
      interval: 2s
      timeout: 5s
      retries: 5
"""

_DOCKERFILE = """\
FROM python:3.11-alpine
WORKDIR /srv
COPY . .
CMD ["python", "-m", "http.server", "8080"]
"""

_VERIFY_SH = """\
#!/bin/bash
# Verification script — exit 0 if the challenge is solved.
# Called by the platform after the agent completes.

RESULT_FILE="/app/result.txt"

if [ ! -f "$RESULT_FILE" ]; then
  echo "No result file found at $RESULT_FILE"
  exit 1
fi

echo "Result: $(cat $RESULT_FILE)"
# TODO: Add your verification logic here
exit 1
"""

_SOLUTION_SH = """\
#!/bin/bash
# Solution script — demonstrates how to solve this task.
# Used for testing and validation during development.

# TODO: Implement the solution
echo "Not implemented yet"
"""


# ---------------------------------------------------------------------------
# init
# ---------------------------------------------------------------------------


@cli.command(alias="new")
def init(
    name: str,
    *,
    difficulty: str = "easy",
    category: str = "security",
    tags: str = "",
    with_verify: t.Annotated[bool, cyclopts.Parameter(negative=())] = False,
    with_solution: t.Annotated[bool, cyclopts.Parameter(negative=())] = False,
    path: Path = Path(),
) -> None:
    """Scaffold a new task directory ready for development.

    Creates task.yaml, docker-compose.yaml, and a starter Dockerfile.
    The result passes ``task validate`` immediately.

    Args:
        name: Task name (e.g. my-crypto-challenge). Lowercase letters,
            digits, and hyphens only.
        difficulty: Difficulty level (easy, medium, hard).
        category: Task category (e.g. security, web, crypto).
        tags: Comma-separated tags.
        with_verify: Also create a starter verify.sh script.
        with_solution: Also create a starter solution.sh script.
        path: Parent directory to create the task folder in.
    """
    if not _NAME_PATTERN.fullmatch(name):
        raise ValueError(
            f'Invalid task name "{name}" — use lowercase letters, digits, and hyphens only'
        )

    task_dir = path.resolve() / name

    if task_dir.exists():
        raise FileExistsError(f"{task_dir} already exists")

    description = f"Solve the {name} challenge."

    _write_file(
        task_dir / "task.yaml",
        _TASK_YAML.format(
            description=description,
            difficulty=difficulty,
            category=category,
            tags=tags,
        ),
    )
    print_success(f"{name}/task.yaml")

    _write_file(task_dir / "docker-compose.yaml", _DOCKER_COMPOSE_YAML)
    print_success(f"{name}/docker-compose.yaml")

    _write_file(task_dir / "challenge" / "Dockerfile", _DOCKERFILE)
    print_success(f"{name}/challenge/Dockerfile")

    if with_verify:
        _write_file(task_dir / "verify.sh", _VERIFY_SH)
        print_success(f"{name}/verify.sh")

    if with_solution:
        _write_file(task_dir / "solution.sh", _SOLUTION_SH)
        print_success(f"{name}/solution.sh")


# ---------------------------------------------------------------------------
# push
# ---------------------------------------------------------------------------


@cli.command(alias="upload")
def push(
    path: Path,
    *,
    name: str | None = None,
    skip_upload: t.Annotated[bool, cyclopts.Parameter(negative=())] = False,
    force: t.Annotated[bool, cyclopts.Parameter(negative=())] = False,
    publish: t.Annotated[bool, cyclopts.Parameter(negative=())] = False,
    public_compat: t.Annotated[
        bool,
        cyclopts.Parameter(name="--public", negative=(), show=False),
    ] = False,
    platform: PlatformArgs = PlatformArgs(),
) -> None:
    """Publish a task to your organization's registry.

    Builds an OCI image from the task directory and pushes it.
    Skips the upload if the remote content already matches (idempotent).
    Pass --publish to make the task discoverable by other organizations.

    Args:
        path: Task directory containing task.yaml and docker-compose.yaml.
        name: Override the registry name.
        skip_upload: Build and validate locally without publishing.
        force: Push even if the remote content already matches.
        publish: Ensure the task is publicly discoverable after publishing.
    """
    publish = resolve_publish_flag(publish, public_compat)
    dn = configured_dreadnode(platform)
    result = dn.push_environment(
        path, name=name, skip_upload=skip_upload, force=force, publish=publish
    )
    if not result.success:
        raise RuntimeError("; ".join(result.errors) or "Task push failed")

    if result.package_name is None or result.package_version is None:
        raise RuntimeError("Task push returned incomplete metadata")

    ref = f"[cyan]{result.package_name}[/cyan]@[dim]{result.package_version or '1.0.0'}[/dim]"
    if skip_upload or not dn.can_sync:
        console.print(f"Built {ref}")
        return
    if result.blobs_uploaded == 0 and result.blobs_skipped > 0:
        console.print(f"{ref} already up to date")
        return
    digest = result.manifest_digest or "unknown"
    console.print(f"Pushed {ref} [dim]({digest})[/dim]")


@cli.command()
def publish(
    refs: t.Annotated[list[str], cyclopts.Parameter(negative_iterable=())],
    *,
    platform: PlatformArgs = PlatformArgs(),
) -> None:
    """Make one or more task families visible to other organizations."""
    dn = configured_dreadnode(platform)
    parsed_refs = ensure_name_only_refs(refs, dn.profile.org_key)
    for ref in parsed_refs:
        dn.set_task_visibility(ref.org, ref.name, is_public=True)
        print_success(f"Published {ref.qualified_name}")


@cli.command()
def unpublish(
    refs: t.Annotated[list[str], cyclopts.Parameter(negative_iterable=())],
    *,
    platform: PlatformArgs = PlatformArgs(),
) -> None:
    """Make one or more task families private."""
    dn = configured_dreadnode(platform)
    parsed_refs = ensure_name_only_refs(refs, dn.profile.org_key)
    for ref in parsed_refs:
        dn.set_task_visibility(ref.org, ref.name, is_public=False)
        print_success(f"Unpublished {ref.qualified_name}")


# ---------------------------------------------------------------------------
# list
# ---------------------------------------------------------------------------


@cli.command(name="list", alias="ls")
def list_(
    *,
    search: str | None = None,
    limit: int = 50,
    include_public: t.Annotated[bool, cyclopts.Parameter(negative=())] = False,
    as_json: t.Annotated[bool, cyclopts.Parameter(name="--json", negative=())] = False,
    platform: PlatformArgs = PlatformArgs(),
) -> None:
    """Show tasks in your organization.

    Args:
        search: Search by name or description.
        limit: Maximum results to show.
        include_public: Include public tasks from other organizations.
        as_json: Output raw JSON instead of a summary.
    """
    api, profile = platform.connect()
    items = _collect_pages(
        lambda page, page_size: api.list_tasks(
            profile.org_key,
            search=search,
            page=page,
            limit=page_size,
            include_public=include_public,
        ),
        limit=limit,
        page_size=100,
        items_key="tasks",
    )
    _render_list(
        items,
        as_json=as_json,
        summary=_summarize_task,
        empty_msg="No tasks found",
    )


# ---------------------------------------------------------------------------
# info
# ---------------------------------------------------------------------------


@cli.command()
def info(
    ref: str,
    *,
    as_json: t.Annotated[bool, cyclopts.Parameter(name="--json", negative=())] = False,
    platform: PlatformArgs = PlatformArgs(),
) -> None:
    """Show details and instructions for a task.

    Displays metadata, visibility, difficulty, tags, and the full
    task instruction. Version is optional — defaults to the latest.

    Args:
        ref: Task to inspect (e.g. my-task, my-task@1.0.0).
        as_json: Output raw JSON instead of formatted summary.
    """
    api, profile = platform.connect()
    vref = ensure_version(api, "task", ArtifactRef.parse(ref, profile.org_key))
    task = api.get_task(vref.org, vref.name, vref.version)

    if as_json:
        _print_json(task)
        return

    console.print(_summarize_task(task))

    tags = task.get("tags")
    if tags and isinstance(tags, list):
        console.print(f"  [dim]tags:[/dim] {', '.join(str(tag) for tag in tags)}")

    instruction = task.get("instruction")
    if instruction:
        console.print()
        console.print("[bold]Instruction[/bold]")
        console.print(f"[dim]{'─' * 40}[/dim]")
        console.print(instruction.strip())


# ---------------------------------------------------------------------------
# pull
# ---------------------------------------------------------------------------


@cli.command(alias="download")
def pull(
    ref: str,
    *,
    upgrade: t.Annotated[bool, cyclopts.Parameter(negative=())] = False,
    platform: PlatformArgs = PlatformArgs(),
) -> None:
    """Download a task for local development or inspection.

    Pulls the task from the registry and extracts it to the local
    package cache. Use this to inspect how a task is built, fork it,
    or test it locally with docker compose.

    Args:
        ref: Task to pull (e.g. my-task or acme/my-task).
        upgrade: Re-download even if already cached locally.
    """
    dn = configured_dreadnode(platform)
    _api, profile = platform.connect()
    parsed = ArtifactRef.parse(ref, profile.org_key)

    package_ref = f"environment://{parsed.qualified_name}"

    result = dn.pull_package([package_ref], upgrade=upgrade)

    if not result.success:
        raise RuntimeError("; ".join(result.errors) or "Pull failed")

    display = parsed.with_version(result.version).format() if result.version else parsed.format()
    if result.dest:
        console.print(f"Pulled {display} to {result.dest}")
    else:
        console.print(f"Pulled {display}")


# ---------------------------------------------------------------------------
# delete
# ---------------------------------------------------------------------------


@cli.command(alias="rm")
def delete(
    ref: str,
    *,
    yes: t.Annotated[bool, cyclopts.Parameter(name="--yes", alias="-y", negative=())] = False,
    platform: PlatformArgs = PlatformArgs(),
) -> None:
    """Remove a published task version from the registry.

    Args:
        ref: Task to delete (e.g. my-task@1.0.0). Version is required.
        yes: Skip the confirmation prompt.
    """
    from rich.prompt import Confirm

    api, profile = platform.connect()
    vref = ArtifactRef.parse_versioned(ref, profile.org_key)

    # Verify it exists before prompting
    api.get_task(vref.org, vref.name, vref.version)

    if not yes:
        if not Confirm.ask(f"Delete {vref.format()}?"):
            console.print("[dim]Cancelled[/dim]")
            return

    api.delete_task(vref.org, vref.name, vref.version)
    print_success(f"Deleted {vref.format()}")


# ---------------------------------------------------------------------------
# sync
# ---------------------------------------------------------------------------


@cli.command()
def sync(
    directory: Path,
    *,
    force: t.Annotated[bool, cyclopts.Parameter(negative=())] = False,
    publish: t.Annotated[bool, cyclopts.Parameter(negative=())] = False,
    public_compat: t.Annotated[
        bool,
        cyclopts.Parameter(name="--public", negative=(), show=False),
    ] = False,
    workers: int = 8,
    platform: PlatformArgs = PlatformArgs(),
) -> None:
    """Publish all tasks from a directory — ideal for CI pipelines.

    Discovers subdirectories containing task.yaml, compares each
    against the registry by content hash, and only publishes those
    that changed.

    Args:
        directory: Root directory containing task subdirectories.
        force: Publish all tasks even if unchanged.
        publish: Ensure published tasks are publicly discoverable.
        workers: Number of parallel upload workers.
    """
    publish = resolve_publish_flag(publish, public_compat)
    dn = configured_dreadnode(platform)
    result = dn.sync_environments(
        directory,
        force=force,
        publish=publish,
        max_workers=workers,
        on_progress=_sync_progress,
        on_status=lambda msg: console.print(msg),
    )

    total = len(result.uploaded) + len(result.skipped) + len(result.failed)
    console.print(
        f"\nSynced {total}: "
        f"[green]{len(result.uploaded)} uploaded[/green], "
        f"[dim]{len(result.skipped)} skipped[/dim], "
        f"[red]{len(result.failed)} failed[/red]"
    )
    if not result.ok:
        raise SystemExit(1)


# ---------------------------------------------------------------------------
# validate
# ---------------------------------------------------------------------------


@cli.command(alias="check")
def validate(
    path: str,
    *,
    strict: t.Annotated[bool, cyclopts.Parameter(negative=())] = False,
    build: t.Annotated[bool, cyclopts.Parameter(negative=())] = False,
    smoke: t.Annotated[bool, cyclopts.Parameter(negative=())] = False,
    timeout: int = 120,
) -> None:
    """Check that task definitions are well-formed before publishing.

    Validates task.yaml, docker-compose.yaml, port mappings, and
    script references. Discovers and validates all tasks when given
    a parent directory.

    Args:
        path: Task directory or parent directory containing multiple tasks.
        strict: Treat warnings as failures (exit code 1).
        build: Also run docker compose build for each task.
        smoke: Full lifecycle test -- boot containers, verify that verify.sh
            rejects unsolved state, and (if solution.sh exists) verify it
            accepts the reference solution. Implies --build.
        timeout: Per-task wall-clock budget in seconds for smoke testing.
    """
    import subprocess

    from dreadnode.packaging.task_validation import (
        ValidationIssue,
        discover_task_directories,
        validate_task_directory,
    )

    if smoke:
        build = True

    resolved = Path(path).resolve()
    if not resolved.exists():
        raise FileNotFoundError(f"Path not found: {resolved}")

    if (resolved / "task.yaml").is_file():
        dirs = [resolved]
        conflicts: list[tuple[Path, Path]] = []
    else:
        dirs, conflicts = discover_task_directories(resolved)
        if not dirs:
            raise FileNotFoundError(f"No task.yaml found in {resolved} or its subdirectories")

    errors: list[tuple[str, str]] = []
    warnings: list[str] = []

    for parent, nested in conflicts:
        rel_parent = parent.relative_to(resolved) if parent != resolved else Path(parent.name)
        rel_nested = nested.relative_to(resolved) if nested != resolved else Path(nested.name)
        errors.append((str(rel_nested), f"task nested inside another task ({rel_parent})"))
        print_error(f"{rel_nested}", indent=2)
        console.print(f"       layout: task nested inside another task ({rel_parent})")

    for task_dir in dirs:
        dir_name = task_dir.name
        try:
            issues = validate_task_directory(task_dir, root_dir=resolved)
            errs = [i for i in issues if i.level == "error"]
            warns = [i for i in issues if i.level == "warning"]

            if build and not errs and (task_dir / "docker-compose.yaml").is_file():
                result = subprocess.run(
                    ["docker", "compose", "build"],  # noqa: S607
                    cwd=task_dir,
                    capture_output=True,
                    text=True,
                    check=False,
                )
                if result.returncode != 0:
                    stderr_lines = [ln for ln in result.stderr.strip().splitlines() if ln.strip()]
                    summary = stderr_lines[-1] if stderr_lines else "build failed"
                    errs.append(ValidationIssue("error", "docker-build", summary))

            if smoke and not errs and (task_dir / "docker-compose.yaml").is_file():
                smoke_issues = _run_smoke_test(task_dir, timeout=timeout)
                for issue in smoke_issues:
                    if issue.level == "error":
                        errs.append(issue)
                    else:
                        warns.append(issue)

            if errs:
                errors.append((dir_name, "; ".join(i.message for i in errs)))
                print_error(dir_name, indent=2)
                for i in errs:
                    console.print(f"       {i.component}: {i.message}")
                if smoke:
                    break
            elif warns:
                warnings.append(dir_name)
                print_warning(dir_name, indent=2)
                for i in warns:
                    if isinstance(i, str):
                        console.print(f"       {i}")
                    else:
                        console.print(f"       {i.component}: {i.message}")
            else:
                print_success(dir_name, indent=2)
        except Exception as exc:
            errors.append((dir_name, str(exc)))
            print_error(f"{dir_name}: {exc}", indent=2)
            if smoke:
                break

    total = len(dirs)
    failed = len(errors)
    warned = len(warnings)
    ok_count = total - failed - warned
    console.print(
        f"\nValidated {total}: "
        f"[green]{ok_count} ok[/green], [yellow]{warned} warn[/yellow], [red]{failed} failed[/red]"
    )
    if errors or (strict and warnings):
        raise SystemExit(1)


# ---------------------------------------------------------------------------
# smoke test helpers
# ---------------------------------------------------------------------------


def _compose_run(
    args: list[str],
    *,
    cwd: Path,
    timeout_sec: float | None = None,
) -> subprocess.CompletedProcess[str]:
    """Run a docker compose command, returning the completed process."""
    import subprocess

    return subprocess.run(  # noqa: S603
        ["docker", "compose", *args],  # noqa: S607
        cwd=cwd,
        capture_output=True,
        text=True,
        check=False,
        timeout=timeout_sec,
    )


def _read_reward(task_dir: Path, timeout_sec: float) -> str | None:
    """Read reward.txt from the client container."""
    result = _compose_run(
        ["exec", "-T", "client", "cat", "/logs/verifier/reward.txt"],
        cwd=task_dir,
        timeout_sec=min(timeout_sec, 10),
    )
    if result.returncode != 0:
        return None
    return result.stdout


def _wait_for_infrastructure(task_dir: Path, deadline: float) -> ValidationIssue | None:
    """Poll until healthchecks pass and seeder exits.

    Returns a ValidationIssue on failure, or None on success.
    """
    import json
    import time

    from dreadnode.packaging.task_validation import ValidationIssue

    while time.monotonic() < deadline:
        result = _compose_run(["ps", "--format", "json"], cwd=task_dir, timeout_sec=10)
        if result.returncode != 0:
            time.sleep(2)
            continue

        services = []
        for raw_line in result.stdout.strip().splitlines():
            stripped = raw_line.strip()
            if not stripped:
                continue
            try:
                services.append(json.loads(stripped))
            except json.JSONDecodeError:
                continue

        if not services:
            time.sleep(2)
            continue

        # Check seeder status
        seeder_done = True
        for svc in services:
            name = svc.get("Service", svc.get("Name", ""))
            state = svc.get("State", "")
            if "seeder" in name.lower():
                if state == "exited":
                    exit_code = svc.get("ExitCode", 0)
                    if exit_code != 0:
                        return ValidationIssue(
                            "error", "smoke-infra", f"seeder exited with code {exit_code}"
                        )
                else:
                    seeder_done = False

        # Check healthchecks
        all_healthy = True
        for svc in services:
            state = svc.get("State", "")
            health = svc.get("Health", "")
            if state == "exited":
                continue
            if health and health != "healthy":
                all_healthy = False
                break

        if all_healthy and seeder_done:
            return None

        time.sleep(2)

    return ValidationIssue("error", "smoke-infra", "services not ready before timeout")


def _run_smoke_test(task_dir: Path, *, timeout: int = 120) -> list:
    """Run the full smoke lifecycle for a single task directory.

    Boots containers, verifies that verify.sh rejects unsolved state (negative
    case), and optionally verifies it accepts the reference solution (positive
    case). Returns a list of ValidationIssue for any problems found.
    """
    import subprocess
    import time

    import yaml

    from dreadnode.packaging.task_validation import ValidationIssue

    issues: list[ValidationIssue] = []

    raw = yaml.safe_load((task_dir / "task.yaml").read_text())
    verification = raw.get("verification") or {}
    solution = raw.get("solution") or {}
    verification_script = verification.get("script") if isinstance(verification, dict) else None
    solution_script = solution.get("script") if isinstance(solution, dict) else None

    if not verification_script:
        issues.append(
            ValidationIssue("warning", "smoke", "no verification script -- skipping smoke test")
        )
        return issues

    deadline = time.monotonic() + timeout

    def remaining() -> float:
        return max(0, deadline - time.monotonic())

    try:
        # --- Phase 1: Infrastructure ---
        console.print("       [dim]smoke: starting containers...[/]")
        result = _compose_run(["up", "-d"], cwd=task_dir, timeout_sec=remaining())
        if result.returncode != 0:
            stderr_lines = [ln for ln in result.stderr.strip().splitlines() if ln.strip()]
            summary = stderr_lines[-1] if stderr_lines else "compose up failed"
            issues.append(ValidationIssue("error", "smoke-infra", summary))
            return issues

        infra_issue = _wait_for_infrastructure(task_dir, deadline)
        if infra_issue:
            issues.append(infra_issue)
            return issues

        elapsed = timeout - remaining()
        console.print(f"       [dim]smoke: infrastructure up ({elapsed:.0f}s)[/]")

        # --- Phase 2: Negative verification ---
        _compose_run(["cp", ".", "client:/task"], cwd=task_dir, timeout_sec=remaining())
        _compose_run(
            ["exec", "-T", "client", "mkdir", "-p", "/logs/verifier", "/app"],
            cwd=task_dir,
            timeout_sec=remaining(),
        )

        _compose_run(
            ["exec", "-T", "client", "bash", f"/task/{verification_script}"],
            cwd=task_dir,
            timeout_sec=remaining(),
        )

        reward = _read_reward(task_dir, remaining())
        if reward is None:
            issues.append(
                ValidationIssue("error", "smoke-verify", "reward.txt not created by verify.sh")
            )
            return issues

        if reward.strip() != "0":
            issues.append(
                ValidationIssue(
                    "error", "smoke-verify", "verify.sh passes without solution (always-pass bug)"
                )
            )
            return issues

        console.print("       [dim]smoke: verify.sh correctly rejects unsolved state[/]")

        # --- Phase 3: Positive verification (optional) ---
        if not solution_script or not (task_dir / solution_script).is_file():
            issues.append(
                ValidationIssue(
                    "warning", "smoke", "no solution script -- skipping positive verification"
                )
            )
            return issues

        if time.monotonic() >= deadline:
            issues.append(ValidationIssue("error", "smoke-solve", f"timed out after {timeout}s"))
            return issues

        result = _compose_run(
            ["exec", "-T", "client", "bash", f"/task/{solution_script}"],
            cwd=task_dir,
            timeout_sec=remaining(),
        )
        if result.returncode != 0:
            stderr_tail = result.stderr.strip().splitlines()[-3:] if result.stderr.strip() else []
            detail = "; ".join(stderr_tail) if stderr_tail else ""
            msg = f"solution.sh failed (exit {result.returncode})"
            if detail:
                msg += f" -- {detail}"
            issues.append(ValidationIssue("warning", "smoke-solve", msg))
            return issues

        console.print("       [dim]smoke: solution.sh completed[/]")

        # Reset reward and re-verify
        _compose_run(
            ["exec", "-T", "client", "rm", "-f", "/logs/verifier/reward.txt"],
            cwd=task_dir,
            timeout_sec=remaining(),
        )
        _compose_run(
            ["exec", "-T", "client", "bash", f"/task/{verification_script}"],
            cwd=task_dir,
            timeout_sec=remaining(),
        )

        reward = _read_reward(task_dir, remaining())
        if reward is None:
            issues.append(
                ValidationIssue(
                    "warning", "smoke-verify", "reward.txt not created after running solution"
                )
            )
            return issues

        if reward.strip() != "1":
            issues.append(
                ValidationIssue(
                    "warning", "smoke-verify", "verify.sh fails with reference solution"
                )
            )
            return issues

        console.print("       [dim]smoke: verify.sh correctly accepts reference solution[/]")

    except subprocess.TimeoutExpired:
        issues.append(ValidationIssue("error", "smoke-infra", f"timed out after {timeout}s"))
    finally:
        _compose_run(["down", "-v", "--remove-orphans"], cwd=task_dir, timeout_sec=30)

    return issues
