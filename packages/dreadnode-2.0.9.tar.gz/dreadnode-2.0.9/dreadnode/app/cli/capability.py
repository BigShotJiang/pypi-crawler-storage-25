"""Capability subcommands for the cyclopts CLI."""

import re
import typing as t
from pathlib import Path

import cyclopts
from rich.prompt import Confirm

from dreadnode.app.cli.args import PlatformArgs
from dreadnode.app.cli.shared import (
    ArtifactRef,
    _collect_pages,
    _print_json,
    _render_list,
    _sync_progress,
    _visibility_markup,
    configured_dreadnode,
    console,
    ensure_name_only_refs,
    ensure_version,
    print_error,
    print_success,
    print_warning,
    resolve_publish_flag,
)

# ---------------------------------------------------------------------------
# Starter file templates for `init`
# ---------------------------------------------------------------------------

_CAPABILITY_YAML = """\
schema: 1
name: {name}
version: "{version}"
description: "{description}"
"""

_CAPABILITY_YAML_AUTHOR = """\
author:
  name: {author}
"""

_AGENT_MD = """\
---
name: example
---
You are a helpful assistant.
"""

_SKILL_MD = """\
---
name: example
description: ""
---
"""

_MCP_JSON = """\
{
  "mcpServers": {}
}
"""

cli = cyclopts.App(
    name="capability",
    help="Composable packages of agents, tools, and skills — capture domain expertise, share it, and refine it over time.",
)


# ---------------------------------------------------------------------------
# init
# ---------------------------------------------------------------------------

_NAME_PATTERN = re.compile(r"^[a-z0-9][a-z0-9-]*$")


def _write_file(path: Path, content: str) -> None:
    """Write a file, creating parent directories as needed."""
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content)


@cli.command(alias="new")
def init(
    name: str,
    *,
    description: str = "A new capability",
    version: t.Annotated[str, cyclopts.Parameter(name="--initial-version")] = "0.1.0",
    author: str | None = None,
    with_skills: t.Annotated[bool, cyclopts.Parameter(negative=())] = False,
    with_mcp: t.Annotated[bool, cyclopts.Parameter(negative=())] = False,
    path: Path = Path(),
) -> None:
    """Scaffold a new capability directory ready for development.

    Creates a capability.yaml manifest and a starter agent definition.
    The result passes ``capability validate`` immediately. Use
    ``capability install`` to make it available to local agents.

    Args:
        name: Capability name (e.g. my-recon-cap). Lowercase letters,
            digits, and hyphens only.
        description: One-line description of what this capability does.
        version: Initial semver version.
        author: Author name to include in the manifest.
        with_skills: Also create a starter skill directory.
        with_mcp: Also create a starter .mcp.json file.
        path: Parent directory to create the capability folder in.
    """
    if not _NAME_PATTERN.fullmatch(name):
        raise ValueError(
            f'Invalid capability name "{name}" — use lowercase letters, digits, and hyphens only'
        )

    cap_dir = path.resolve() / name

    if cap_dir.exists():
        raise FileExistsError(f"{cap_dir} already exists")

    # Build manifest
    manifest = _CAPABILITY_YAML.format(name=name, version=version, description=description)
    if author:
        manifest += _CAPABILITY_YAML_AUTHOR.format(author=author)

    # Write files
    _write_file(cap_dir / "capability.yaml", manifest)
    print_success(f"{name}/capability.yaml")

    _write_file(cap_dir / "agents" / "example.md", _AGENT_MD)
    print_success(f"{name}/agents/example.md")

    if with_skills:
        _write_file(cap_dir / "skills" / "example" / "SKILL.md", _SKILL_MD)
        print_success(f"{name}/skills/example/SKILL.md")

    if with_mcp:
        _write_file(cap_dir / ".mcp.json", _MCP_JSON)
        print_success(f"{name}/.mcp.json")


# ---------------------------------------------------------------------------
# install
# ---------------------------------------------------------------------------


@cli.command()
def install(
    ref: str,
    *,
    force: t.Annotated[bool, cyclopts.Parameter(negative=())] = False,
    copy: t.Annotated[bool, cyclopts.Parameter(negative=())] = False,
    platform: PlatformArgs = PlatformArgs(),
) -> None:
    """Install a capability so agents can use it.

    If the argument is a path to a directory on disk, the capability
    is validated and symlinked into ~/.dreadnode/capabilities/ so edits
    are live. Use --copy to create a frozen snapshot instead.

    Otherwise the argument is treated as a registry reference and the
    capability is downloaded from the platform.

    Args:
        ref: Capability reference or local path.
            Registry: my-cap, my-cap@1.0.0, acme/my-cap.
            Local: ./my-cap, /abs/path/to/cap.
        force: Overwrite if already installed.
        copy: Copy files instead of symlinking (local installs only).
    """
    candidate = Path(ref).resolve()
    if candidate.is_dir():
        _install_from_path(candidate, force=force, copy=copy)
    else:
        _install_from_registry(ref, force=force, platform=platform)


def _install_from_path(source: Path, *, force: bool, copy: bool) -> None:
    """Install a capability from a local directory."""
    from dreadnode.capabilities.capability import Capability
    from dreadnode.capabilities.sync import install_local
    from dreadnode.storage.storage import Storage

    # Validate before touching anything
    cap = Capability(source)

    storage = Storage()
    try:
        install_local(
            source_path=source,
            local_dir=storage.capabilities_path,
            state_path=storage.local_capability_state_path,
            name=cap.name,
            version=cap.version,
            overwrite=force,
            copy=copy,
        )
    except FileExistsError:
        raise FileExistsError(f"{cap.name} already installed — use --force to overwrite") from None

    mode = "copied" if copy else "symlinked"
    local_ref = ArtifactRef(org="local", name=cap.name, version=cap.version)
    print_success(f"Installed {local_ref.format()} ({mode})")


def _install_from_registry(raw_ref: str, *, force: bool, platform: PlatformArgs) -> None:
    """Install a capability from the platform registry."""
    import asyncio

    from dreadnode.capabilities.sync import LocalInstallClient
    from dreadnode.storage.storage import Storage

    api, profile = platform.connect()
    ref = ensure_version(api, "capability", ArtifactRef.parse(raw_ref, profile.org_key))
    source = "public" if ref.org != profile.org_key else "org"

    storage = Storage()
    installer = LocalInstallClient(
        api=api,
        org=ref.org,
        local_dir=storage.capabilities_path,
        state_path=storage.local_capability_state_path,
    )

    try:
        asyncio.run(
            installer.install(
                name=ref.name,
                version=ref.version,
                source=source,
                overwrite=force,
            )
        )
    except FileExistsError:
        raise FileExistsError(f"{ref.name} already installed — use --force to overwrite") from None
    print_success(f"Installed {ref.format()}")


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _summarize_capability(p: dict[str, t.Any]) -> str:
    name = p.get("name", "unknown")
    version = p.get("version", "unknown")
    visibility = "public" if p.get("is_public") else "private"
    description = p.get("description")
    suffix = f" [dim]-[/dim] {description}" if description else ""
    return f"[cyan]{name}[/cyan]@[dim]{version}[/dim] {_visibility_markup(visibility)}{suffix}"


# ---------------------------------------------------------------------------
# push
# ---------------------------------------------------------------------------


@cli.command(alias="upload")
def push(
    path: Path,
    *,
    name: str | None = None,
    skip_upload: t.Annotated[bool, cyclopts.Parameter(negative=())] = False,
    force: t.Annotated[bool, cyclopts.Parameter(negative=())] = False,
    publish: t.Annotated[bool, cyclopts.Parameter(negative=())] = False,
    public_compat: t.Annotated[
        bool,
        cyclopts.Parameter(name="--public", negative=(), show=False),
    ] = False,
    platform: PlatformArgs = PlatformArgs(),
) -> None:
    """Publish a capability to your organization's registry.

    Args:
        path: Capability directory containing capability.yaml.
        name: Override the registry name. Bare names are auto-prefixed
            with the active organization.
        skip_upload: Build and validate locally without publishing.
        force: Overwrite even if this version already exists with different content.
        publish: Ensure the capability is publicly discoverable after publishing.
    """
    publish = resolve_publish_flag(publish, public_compat)
    dn = configured_dreadnode(platform)
    result = dn.push_capability(
        path,
        name=name,
        skip_upload=skip_upload,
        force=force,
        publish=publish,
    )

    display = f"[cyan]{result.name}[/cyan]@[dim]{result.version}[/dim]"
    if result.status == "built":
        console.print(f"Built {display}")
    elif result.status == "up_to_date":
        console.print(f"{display} already up to date")
    else:
        digest = result.digest or "unknown"
        console.print(f"Pushed {display} [dim]({digest})[/dim]")


@cli.command()
def publish(
    refs: t.Annotated[list[str], cyclopts.Parameter(negative_iterable=())],
    *,
    platform: PlatformArgs = PlatformArgs(),
) -> None:
    """Make one or more capability families visible to other organizations."""
    dn = configured_dreadnode(platform)
    parsed_refs = ensure_name_only_refs(refs, dn.profile.org_key)
    for ref in parsed_refs:
        dn.set_capability_visibility(ref.org, ref.name, is_public=True)
        print_success(f"Published {ref.qualified_name}")


@cli.command()
def unpublish(
    refs: t.Annotated[list[str], cyclopts.Parameter(negative_iterable=())],
    *,
    platform: PlatformArgs = PlatformArgs(),
) -> None:
    """Make one or more capability families private."""
    dn = configured_dreadnode(platform)
    parsed_refs = ensure_name_only_refs(refs, dn.profile.org_key)
    for ref in parsed_refs:
        dn.set_capability_visibility(ref.org, ref.name, is_public=False)
        print_success(f"Unpublished {ref.qualified_name}")


# ---------------------------------------------------------------------------
# list
# ---------------------------------------------------------------------------


@cli.command(name="list", alias="ls")
def list_(
    *,
    search: str | None = None,
    limit: int = 50,
    include_public: t.Annotated[bool, cyclopts.Parameter(negative=())] = False,
    as_json: t.Annotated[bool, cyclopts.Parameter(name="--json", negative=())] = False,
    platform: PlatformArgs = PlatformArgs(),
) -> None:
    """Show capabilities in your organization.

    Args:
        search: Search by name or description.
        limit: Maximum results to show.
        include_public: Include public capabilities from other organizations.
        as_json: Output raw JSON instead of a summary.
    """
    api, profile = platform.connect()
    items = _collect_pages(
        lambda page, page_size: api.list_capabilities(
            profile.org_key,
            search=search,
            page=page,
            limit=page_size,
            include_public=include_public,
        ),
        limit=limit,
        page_size=100,
        items_key="capabilities",
    )
    _render_list(
        items,
        as_json=as_json,
        summary=_summarize_capability,
        empty_msg="No capabilities found",
    )


# ---------------------------------------------------------------------------
# info
# ---------------------------------------------------------------------------


@cli.command()
def info(
    ref: str,
    *,
    as_json: t.Annotated[bool, cyclopts.Parameter(name="--json", negative=())] = False,
    platform: PlatformArgs = PlatformArgs(),
) -> None:
    """Show details and available versions for a capability.

    Version is optional — defaults to the latest. Use org/name to
    inspect public capabilities from other organizations.

    Args:
        ref: Capability to inspect (e.g. my-cap, my-cap@1.0.0,
            or acme/my-cap).
        as_json: Output raw JSON instead of a summary.
    """
    api, profile = platform.connect()
    vref = ensure_version(api, "capability", ArtifactRef.parse(ref, profile.org_key))

    detail = api.get_capability(vref.org, vref.name, vref.version)
    versions_payload = api.list_capability_versions(vref.org, vref.name)

    if as_json:
        detail["available_versions"] = versions_payload.get("versions", [])
        _print_json(detail)
        return

    # Human-readable output
    console.print(_summarize_capability(detail))

    version_items = versions_payload.get("versions", [])
    if version_items:
        console.print(f"  [dim]versions:[/dim] {', '.join(str(v) for v in version_items)}")


# ---------------------------------------------------------------------------
# pull
# ---------------------------------------------------------------------------


@cli.command(alias="download")
def pull(
    ref: str,
    *,
    upgrade: t.Annotated[bool, cyclopts.Parameter(negative=())] = False,
    platform: PlatformArgs = PlatformArgs(),
) -> None:
    """Download a capability to read or fork — does not activate it.

    Pulls the capability from the registry and extracts it to the
    local package cache. Unlike ``install``, this does not activate
    the capability for use by agents.

    Args:
        ref: Capability to pull (e.g. my-cap, my-cap@1.0.0, or acme/my-cap).
        upgrade: Re-download even if already cached locally.
    """
    dn = configured_dreadnode(platform)
    _api, profile = platform.connect()
    parsed = ArtifactRef.parse(ref, profile.org_key)

    version_suffix = f":{parsed.version}" if parsed.version else ""
    package_ref = f"capability://{parsed.qualified_name}{version_suffix}"

    result = dn.pull_package([package_ref], upgrade=upgrade)

    if not result.success:
        raise RuntimeError("; ".join(result.errors) or "Pull failed")

    display = parsed.with_version(result.version).format() if result.version else parsed.format()
    if result.dest:
        console.print(f"Pulled {display} to {result.dest}")
    else:
        console.print(f"Pulled {display}")


# ---------------------------------------------------------------------------
# delete
# ---------------------------------------------------------------------------


@cli.command(alias="rm")
def delete(
    ref: str,
    *,
    yes: t.Annotated[bool, cyclopts.Parameter(name="--yes", alias="-y", negative=())] = False,
    platform: PlatformArgs = PlatformArgs(),
) -> None:
    """Remove a published capability version from the registry.

    Args:
        ref: Capability to delete (e.g. my-cap@1.0.0). Version is required.
        yes: Skip the confirmation prompt.
    """
    api, profile = platform.connect()
    vref = ArtifactRef.parse_versioned(ref, profile.org_key)

    # Verify it exists before prompting
    api.get_capability(vref.org, vref.name, vref.version)

    if not yes:
        if not Confirm.ask(f"Delete {vref.format()}?"):
            console.print("[dim]Cancelled[/dim]")
            return

    api.delete_capability(vref.org, vref.name, vref.version)
    print_success(f"Deleted {vref.format()}")


# ---------------------------------------------------------------------------
# sync
# ---------------------------------------------------------------------------


@cli.command()
def sync(
    directory: Path,
    *,
    force: t.Annotated[bool, cyclopts.Parameter(negative=())] = False,
    publish: t.Annotated[bool, cyclopts.Parameter(negative=())] = False,
    public_compat: t.Annotated[
        bool,
        cyclopts.Parameter(name="--public", negative=(), show=False),
    ] = False,
    platform: PlatformArgs = PlatformArgs(),
) -> None:
    """Publish all capabilities from a directory — ideal for CI pipelines.

    Discovers subdirectories containing capability.yaml, compares each
    against the registry by content hash, and only publishes those that
    changed.

    Args:
        directory: Root directory containing capability subdirectories.
        force: Publish all capabilities even if unchanged.
        publish: Ensure published capabilities are publicly discoverable.
    """
    publish = resolve_publish_flag(publish, public_compat)
    dn = configured_dreadnode(platform)
    result = dn.sync_capabilities(
        directory,
        force=force,
        publish=publish,
        on_progress=_sync_progress,
    )

    total = len(result.uploaded) + len(result.skipped) + len(result.failed)
    console.print(
        f"\nSynced {total}: "
        f"[green]{len(result.uploaded)} uploaded[/green], "
        f"[dim]{len(result.skipped)} skipped[/dim], "
        f"[red]{len(result.failed)} failed[/red]"
    )
    if not result.ok:
        raise SystemExit(1)


# ---------------------------------------------------------------------------
# validate
# ---------------------------------------------------------------------------


@cli.command(alias="check")
def validate(
    path: Path,
    *,
    strict: t.Annotated[bool, cyclopts.Parameter(negative=())] = False,
) -> None:
    """Check that a capability is well-formed before publishing.

    Loads and validates agents, tools, skills, and MCP server definitions.
    Validates a single capability if the path contains capability.yaml,
    otherwise discovers and validates all capability subdirectories.

    Args:
        path: Capability directory or parent directory containing
            multiple capabilities.
        strict: Treat warnings as failures (exit code 1).
    """
    from dreadnode.capabilities.capability import Capability

    resolved = path.resolve()
    if not resolved.exists():
        raise FileNotFoundError(f"Path not found: {resolved}")

    if (resolved / "capability.yaml").exists():
        dirs = [resolved]
    else:
        dirs = sorted(
            d for d in resolved.iterdir() if d.is_dir() and (d / "capability.yaml").exists()
        )
        if not dirs:
            raise FileNotFoundError(f"No capability.yaml found in {resolved} or its subdirectories")

    errors: list[tuple[str, str]] = []
    warnings: list[str] = []

    for cap_dir in dirs:
        dir_name = cap_dir.name
        try:
            cap = Capability(cap_dir)
            agents = cap.agents
            tools = cap.tools
            skills = cap.skills_paths or []
            mcp = cap.mcp_server_defs

            health_errors = [h for h in cap.component_health if h.get("status") == "error"]

            summary = (
                f"agents={len(agents)}, tools={len(tools)}, skills={len(skills)}, mcp={len(mcp)}"
            )

            if health_errors:
                warnings.append(cap.name)
                print_warning(f"{cap.name}@{cap.version} ({summary})", indent=2)
                for h in health_errors:
                    console.print(f"       {h.get('component', '?')}: {h.get('error', 'unknown')}")
            else:
                print_success(f"{cap.name}@{cap.version} ({summary})", indent=2)
        except (ValueError, FileNotFoundError) as exc:
            errors.append((dir_name, str(exc)))
            print_error(f"{dir_name}: {exc}", indent=2)

    total = len(dirs)
    failed = len(errors)
    warned = len(warnings)
    ok_count = total - failed - warned
    console.print(
        f"\nValidated {total}: "
        f"[green]{ok_count} ok[/green], [yellow]{warned} warn[/yellow], [red]{failed} failed[/red]"
    )
    if errors or (strict and warnings):
        raise SystemExit(1)
