"""HTTP API handlers (thin adapter layer).

Imports from services and models.
"""

from __future__ import annotations

import json
import logging
from typing import Any

from models import Order, Product, User
from services import order_service, product_service, user_service

logger = logging.getLogger(__name__)


class HTTPRequest:
    """Minimal HTTP request stub."""

    def __init__(self, method: str, path: str, body: dict | None = None, headers: dict | None = None) -> None:
        self.method = method.upper()
        self.path = path
        self.body = body or {}
        self.headers = headers or {}


class HTTPResponse:
    """Minimal HTTP response."""

    def __init__(self, status: int, body: Any = None) -> None:
        self.status = status
        self.body = body

    def to_dict(self) -> dict:
        return {"status": self.status, "body": self.body}

    @classmethod
    def ok(cls, body: Any = None) -> "HTTPResponse":
        return cls(200, body)

    @classmethod
    def created(cls, body: Any = None) -> "HTTPResponse":
        return cls(201, body)

    @classmethod
    def bad_request(cls, message: str) -> "HTTPResponse":
        return cls(400, {"error": message})

    @classmethod
    def not_found(cls, message: str = "Not found") -> "HTTPResponse":
        return cls(404, {"error": message})

    @classmethod
    def server_error(cls, message: str = "Internal server error") -> "HTTPResponse":
        return cls(500, {"error": message})


def handle_register(request: HTTPRequest) -> HTTPResponse:
    """POST /users/register"""
    try:
        user = user_service.register(
            username=request.body["username"],
            email=request.body["email"],
            password=request.body["password"],
        )
        return HTTPResponse.created({"id": user.id, "username": user.username})
    except KeyError as exc:
        return HTTPResponse.bad_request(f"Missing field: {exc}")
    except ValueError as exc:
        return HTTPResponse.bad_request(str(exc))


def handle_login(request: HTTPRequest) -> HTTPResponse:
    """POST /auth/login"""
    user = user_service.authenticate(
        email=request.body.get("email", ""),
        password=request.body.get("password", ""),
    )
    if user is None:
        return HTTPResponse(401, {"error": "Invalid credentials"})
    return HTTPResponse.ok({"id": user.id, "username": user.username})


def handle_list_products(request: HTTPRequest) -> HTTPResponse:
    """GET /products"""
    products = product_service.list_available()
    return HTTPResponse.ok(
        [{"id": p.id, "name": p.name, "price": p.price_dollars, "stock": p.stock} for p in products]
    )


def handle_get_product(request: HTTPRequest, product_id: str) -> HTTPResponse:
    """GET /products/<product_id>"""
    product = product_service.get_product(product_id)
    if not product:
        return HTTPResponse.not_found(f"Product {product_id} not found")
    return HTTPResponse.ok(
        {"id": product.id, "name": product.name, "price": product.price_dollars}
    )


def handle_create_order(request: HTTPRequest) -> HTTPResponse:
    """POST /orders"""
    try:
        order = order_service.create_order(user_id=request.body["user_id"])
        return HTTPResponse.created({"id": order.id, "status": order.status})
    except KeyError as exc:
        return HTTPResponse.bad_request(f"Missing field: {exc}")
    except ValueError as exc:
        return HTTPResponse.bad_request(str(exc))


def handle_pay_order(request: HTTPRequest, order_id: str) -> HTTPResponse:
    """POST /orders/<order_id>/pay"""
    try:
        order = order_service.pay_order(order_id)
        return HTTPResponse.ok({"id": order.id, "status": order.status, "total": order.total_cents})
    except ValueError as exc:
        return HTTPResponse.bad_request(str(exc))


def route(request: HTTPRequest) -> HTTPResponse:
    """Simple manual router."""
    path = request.path.rstrip("/")
    method = request.method

    if path == "/users/register" and method == "POST":
        return handle_register(request)
    elif path == "/auth/login" and method == "POST":
        return handle_login(request)
    elif path == "/products" and method == "GET":
        return handle_list_products(request)
    elif path.startswith("/products/") and method == "GET":
        product_id = path.split("/products/")[1]
        return handle_get_product(request, product_id)
    elif path == "/orders" and method == "POST":
        return handle_create_order(request)
    elif path.endswith("/pay") and method == "POST":
        order_id = path.split("/orders/")[1].replace("/pay", "")
        return handle_pay_order(request, order_id)

    return HTTPResponse.not_found(f"No route matched: {method} {path}")
