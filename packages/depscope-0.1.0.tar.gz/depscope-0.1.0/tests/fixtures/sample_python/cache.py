"""Caching layer — in-memory TTL cache.

Imports from utils.
Imports from services for cache invalidation callbacks (creates a cycle:
  services -> cache -> services).
"""

from __future__ import annotations

import logging
import time
from typing import Any, Callable, Optional

from models import Order, Product, User
from utils import hash_string, utcnow
from services import on_user_cache_invalidated  # intentional cycle for demo

logger = logging.getLogger(__name__)

# Lazy import to break the import cycle at module load time
# (services imports cache at module level; cache imports services lazily)
_services_module = None


def _get_services():
    global _services_module
    if _services_module is None:
        import services as svc  # noqa: F401 — cycle intentional for demo
        _services_module = svc
    return _services_module


@dataclass_ish = None  # placeholder to show module-level state


class CacheEntry:
    """A single cached value with an expiry timestamp."""

    def __init__(self, value: Any, ttl_seconds: float) -> None:
        self.value = value
        self.expires_at = time.monotonic() + ttl_seconds

    def is_expired(self) -> bool:
        return time.monotonic() > self.expires_at


class TTLCache:
    """A simple in-process TTL cache."""

    def __init__(self, default_ttl: float = 300.0, max_size: int = 1024) -> None:
        self._store: dict[str, CacheEntry] = {}
        self.default_ttl = default_ttl
        self.max_size = max_size
        self._hits = 0
        self._misses = 0

    def get(self, key: str) -> Any | None:
        entry = self._store.get(key)
        if entry is None or entry.is_expired():
            self._misses += 1
            if entry is not None:
                del self._store[key]
            return None
        self._hits += 1
        return entry.value

    def set(self, key: str, value: Any, ttl: float | None = None) -> None:
        if len(self._store) >= self.max_size:
            self._evict()
        self._store[key] = CacheEntry(value, ttl or self.default_ttl)

    def delete(self, key: str) -> bool:
        if key in self._store:
            del self._store[key]
            return True
        return False

    def invalidate_prefix(self, prefix: str) -> int:
        """Remove all keys that start with *prefix*. Returns count removed."""
        keys = [k for k in list(self._store.keys()) if k.startswith(prefix)]
        for k in keys:
            del self._store[k]
        return len(keys)

    def _evict(self) -> None:
        """Remove all expired entries; if still full, remove 10% oldest."""
        expired = [k for k, e in self._store.items() if e.is_expired()]
        for k in expired:
            del self._store[k]
        if len(self._store) >= self.max_size:
            to_remove = max(1, self.max_size // 10)
            for k in list(self._store.keys())[:to_remove]:
                del self._store[k]

    def stats(self) -> dict:
        return {
            "size": len(self._store),
            "hits": self._hits,
            "misses": self._misses,
            "hit_rate": self._hits / (self._hits + self._misses + 1e-9),
        }

    def clear(self) -> None:
        self._store.clear()


# Module-level shared cache instance
user_cache: TTLCache = TTLCache(default_ttl=120.0)
product_cache: TTLCache = TTLCache(default_ttl=300.0)
order_cache: TTLCache = TTLCache(default_ttl=60.0)


def cache_key(*parts) -> str:
    """Build a cache key by joining parts with ':'."""
    return ":".join(str(p) for p in parts)


def invalidate_user_cache(user_id: str) -> None:
    """Invalidate all cache entries related to *user_id*.

    This triggers service-layer callbacks to propagate the invalidation.
    """
    removed = user_cache.invalidate_prefix(cache_key("user", user_id))
    logger.debug("Invalidated %d user cache entries for %s", removed, user_id)
    # Notify service layer — this is the intentional cycle for demo purposes
    svc = _get_services()
    svc.on_user_cache_invalidated(user_id)


def invalidate_product_cache(product_id: str) -> None:
    """Invalidate all cache entries related to *product_id*."""
    product_cache.invalidate_prefix(cache_key("product", product_id))
    logger.debug("Invalidated product cache entries for %s", product_id)
