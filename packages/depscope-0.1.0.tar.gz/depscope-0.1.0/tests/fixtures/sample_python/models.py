"""Domain model classes.

Imports from utils.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Optional

from utils import hash_string, slugify, utcnow


@dataclass
class User:
    """A registered user of the system."""

    id: str
    username: str
    email: str
    created_at: datetime = field(default_factory=utcnow)
    is_active: bool = True
    _password_hash: str = field(default="", repr=False)

    @classmethod
    def create(cls, username: str, email: str, password: str) -> "User":
        """Factory: create a new user with a hashed password."""
        uid = hash_string(f"{username}:{email}")
        obj = cls(id=uid, username=username, email=email)
        obj._password_hash = hash_string(password)
        return obj

    @property
    def slug(self) -> str:
        """URL-safe identifier derived from the username."""
        return slugify(self.username)

    def check_password(self, password: str) -> bool:
        """Return True if *password* matches the stored hash."""
        return self._password_hash == hash_string(password)

    def deactivate(self) -> None:
        """Mark the user as inactive."""
        self.is_active = False


@dataclass
class Product:
    """A product in the catalogue."""

    id: str
    name: str
    price_cents: int
    stock: int = 0
    description: str = ""
    created_at: datetime = field(default_factory=utcnow)

    @property
    def price_dollars(self) -> float:
        return self.price_cents / 100

    @classmethod
    def create(cls, name: str, price_cents: int, stock: int = 0) -> "Product":
        pid = hash_string(f"product:{name}:{price_cents}")
        return cls(id=pid, name=name, price_cents=price_cents, stock=stock)

    def is_available(self) -> bool:
        return self.stock > 0


@dataclass
class Order:
    """A customer order."""

    id: str
    user_id: str
    items: list[dict] = field(default_factory=list)
    status: str = "pending"
    created_at: datetime = field(default_factory=utcnow)
    total_cents: int = 0

    @classmethod
    def create(cls, user_id: str) -> "Order":
        oid = hash_string(f"order:{user_id}:{utcnow().isoformat()}")
        return cls(id=oid, user_id=user_id)

    def add_item(self, product: Product, quantity: int = 1) -> None:
        if not product.is_available():
            raise ValueError(f"Product {product.name} is out of stock")
        self.items.append(
            {"product_id": product.id, "quantity": quantity, "unit_price": product.price_cents}
        )
        self.total_cents += product.price_cents * quantity

    def mark_paid(self) -> None:
        self.status = "paid"

    def mark_cancelled(self) -> None:
        self.status = "cancelled"
