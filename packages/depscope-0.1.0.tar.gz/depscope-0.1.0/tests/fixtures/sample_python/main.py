"""Application entry point.

Imports from api and services.
"""

from __future__ import annotations

import logging
import sys
from pathlib import Path

from api import HTTPRequest, route
from services import product_service, user_service

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)-8s  %(name)s  %(message)s",
)
logger = logging.getLogger(__name__)


def seed_database() -> None:
    """Populate the in-memory database with sample data."""
    logger.info("Seeding database…")

    # Users
    try:
        alice = user_service.register("alice", "alice@example.com", "secret123")
        bob = user_service.register("bob", "bob@example.com", "hunter2")
        logger.info("Created users: %s, %s", alice.id, bob.id)
    except ValueError as exc:
        logger.warning("User seed skipped: %s", exc)

    # Products
    try:
        product_service.create_product("Widget Pro", price_cents=1999, stock=50)
        product_service.create_product("Gadget Plus", price_cents=4999, stock=20)
        product_service.create_product("Doohickey", price_cents=999, stock=100)
        logger.info("Products seeded.")
    except Exception as exc:
        logger.warning("Product seed error: %s", exc)


def run_demo_requests() -> None:
    """Exercise the API with a few sample requests."""
    requests = [
        HTTPRequest("GET", "/products"),
        HTTPRequest("POST", "/users/register", {"username": "demo", "email": "demo@x.com", "password": "pw"}),
        HTTPRequest("POST", "/auth/login", {"email": "demo@x.com", "password": "pw"}),
        HTTPRequest("POST", "/orders", {"user_id": "NONEXISTENT"}),
    ]

    for req in requests:
        response = route(req)
        logger.info("%s %s -> %d", req.method, req.path, response.status)


def main(argv: list[str] | None = None) -> int:
    """Main entry point.  Returns exit code."""
    argv = argv or sys.argv[1:]

    seed_database()
    run_demo_requests()

    logger.info("Application finished.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
