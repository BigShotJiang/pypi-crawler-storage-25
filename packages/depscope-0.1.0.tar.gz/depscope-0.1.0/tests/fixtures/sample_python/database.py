"""Database access layer.

Imports from models and utils.
"""

from __future__ import annotations

import logging
from typing import Any, Optional

from models import Order, Product, User
from utils import chunk_list, hash_string, utcnow

logger = logging.getLogger(__name__)

# In-memory store for demo purposes
_store: dict[str, dict[str, Any]] = {
    "users": {},
    "products": {},
    "orders": {},
}


class DatabaseError(Exception):
    """Raised when a database operation fails."""


class Repository:
    """Generic key-value store backed by an in-memory dict."""

    def __init__(self, collection: str) -> None:
        self._collection = collection
        if collection not in _store:
            _store[collection] = {}

    def save(self, obj: Any) -> None:
        """Persist *obj* by its ``id`` attribute."""
        if not hasattr(obj, "id"):
            raise DatabaseError("Object has no id attribute")
        _store[self._collection][obj.id] = obj
        logger.debug("Saved %s id=%s", type(obj).__name__, obj.id)

    def get(self, obj_id: str) -> Any | None:
        return _store[self._collection].get(obj_id)

    def delete(self, obj_id: str) -> bool:
        if obj_id in _store[self._collection]:
            del _store[self._collection][obj_id]
            return True
        return False

    def all(self) -> list:
        return list(_store[self._collection].values())

    def find_by(self, **kwargs) -> list:
        results = []
        for obj in _store[self._collection].values():
            if all(getattr(obj, k, None) == v for k, v in kwargs.items()):
                results.append(obj)
        return results

    def count(self) -> int:
        return len(_store[self._collection])


class UserRepository(Repository):
    """User-specific database operations."""

    def __init__(self) -> None:
        super().__init__("users")

    def find_by_email(self, email: str) -> User | None:
        matches = self.find_by(email=email)
        return matches[0] if matches else None

    def find_by_username(self, username: str) -> User | None:
        matches = self.find_by(username=username)
        return matches[0] if matches else None

    def get_active_users(self) -> list[User]:
        return self.find_by(is_active=True)


class ProductRepository(Repository):
    """Product-specific database operations."""

    def __init__(self) -> None:
        super().__init__("products")

    def find_available(self) -> list[Product]:
        return [p for p in self.all() if p.is_available()]

    def bulk_save(self, products: list[Product]) -> None:
        for chunk in chunk_list(products, 100):
            for p in chunk:
                self.save(p)


class OrderRepository(Repository):
    """Order-specific database operations."""

    def __init__(self) -> None:
        super().__init__("orders")

    def find_by_user(self, user_id: str) -> list[Order]:
        return self.find_by(user_id=user_id)

    def find_pending(self) -> list[Order]:
        return self.find_by(status="pending")


# Singletons
user_repo = UserRepository()
product_repo = ProductRepository()
order_repo = OrderRepository()
