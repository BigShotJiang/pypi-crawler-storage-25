"""Business logic / service layer.

Imports from database, models, utils, and cache.
cache imports services back (the intentional cycle).
"""

from __future__ import annotations

import logging
from typing import Optional

from cache import (
    cache_key,
    invalidate_product_cache,
    invalidate_user_cache,
    order_cache,
    product_cache,
    user_cache,
)
from database import order_repo, product_repo, user_repo
from models import Order, Product, User
from utils import utcnow

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Callback invoked by the cache module (completes the cycle)
# ---------------------------------------------------------------------------


def on_user_cache_invalidated(user_id: str) -> None:
    """React to a user cache invalidation event.

    Called back from cache.invalidate_user_cache to allow the service
    layer to perform any follow-up actions.
    """
    logger.debug("Service layer notified: user cache invalidated for %s", user_id)
    # Invalidate related order caches too
    orders = order_repo.find_by_user(user_id)
    for order in orders:
        order_cache.delete(cache_key("order", order.id))


# ---------------------------------------------------------------------------
# User service
# ---------------------------------------------------------------------------


class UserService:
    """Handles user registration, authentication, and management."""

    def register(self, username: str, email: str, password: str) -> User:
        if user_repo.find_by_email(email):
            raise ValueError(f"Email already registered: {email}")
        if user_repo.find_by_username(username):
            raise ValueError(f"Username taken: {username}")
        user = User.create(username=username, email=email, password=password)
        user_repo.save(user)
        logger.info("Registered user %s", user.id)
        return user

    def authenticate(self, email: str, password: str) -> User | None:
        key = cache_key("user", "auth", email)
        cached = user_cache.get(key)
        if cached:
            return cached

        user = user_repo.find_by_email(email)
        if user and user.check_password(password) and user.is_active:
            user_cache.set(key, user, ttl=300)
            return user
        return None

    def get_user(self, user_id: str) -> User | None:
        key = cache_key("user", user_id)
        cached = user_cache.get(key)
        if cached:
            return cached
        user = user_repo.get(user_id)
        if user:
            user_cache.set(key, user)
        return user

    def deactivate_user(self, user_id: str) -> bool:
        user = user_repo.get(user_id)
        if not user:
            return False
        user.deactivate()
        user_repo.save(user)
        invalidate_user_cache(user_id)
        return True


# ---------------------------------------------------------------------------
# Product service
# ---------------------------------------------------------------------------


class ProductService:
    """Manages the product catalogue."""

    def create_product(self, name: str, price_cents: int, stock: int = 0) -> Product:
        product = Product.create(name=name, price_cents=price_cents, stock=stock)
        product_repo.save(product)
        logger.info("Created product %s", product.id)
        return product

    def get_product(self, product_id: str) -> Product | None:
        key = cache_key("product", product_id)
        cached = product_cache.get(key)
        if cached:
            return cached
        product = product_repo.get(product_id)
        if product:
            product_cache.set(key, product)
        return product

    def list_available(self) -> list[Product]:
        key = cache_key("products", "available")
        cached = product_cache.get(key)
        if cached:
            return cached
        products = product_repo.find_available()
        product_cache.set(key, products, ttl=60)
        return products

    def update_stock(self, product_id: str, delta: int) -> Product:
        product = product_repo.get(product_id)
        if not product:
            raise ValueError(f"Product not found: {product_id}")
        product.stock = max(0, product.stock + delta)
        product_repo.save(product)
        invalidate_product_cache(product_id)
        return product


# ---------------------------------------------------------------------------
# Order service
# ---------------------------------------------------------------------------


class OrderService:
    """Manages order lifecycle."""

    def create_order(self, user_id: str) -> Order:
        user = user_repo.get(user_id)
        if not user or not user.is_active:
            raise ValueError(f"Invalid or inactive user: {user_id}")
        order = Order.create(user_id=user_id)
        order_repo.save(order)
        logger.info("Created order %s for user %s", order.id, user_id)
        return order

    def add_item(self, order_id: str, product_id: str, quantity: int = 1) -> Order:
        order = order_repo.get(order_id)
        product = product_repo.get(product_id)
        if not order:
            raise ValueError(f"Order not found: {order_id}")
        if not product:
            raise ValueError(f"Product not found: {product_id}")
        order.add_item(product, quantity)
        product.stock -= quantity
        product_repo.save(product)
        order_repo.save(order)
        order_cache.delete(cache_key("order", order_id))
        return order

    def pay_order(self, order_id: str) -> Order:
        order = order_repo.get(order_id)
        if not order:
            raise ValueError(f"Order not found: {order_id}")
        if order.status != "pending":
            raise ValueError(f"Order {order_id} is already {order.status}")
        order.mark_paid()
        order_repo.save(order)
        order_cache.delete(cache_key("order", order_id))
        return order


# Singletons
user_service = UserService()
product_service = ProductService()
order_service = OrderService()
