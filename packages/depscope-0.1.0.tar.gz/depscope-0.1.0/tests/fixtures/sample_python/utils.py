"""Shared utility functions used throughout the application.

No local imports — pure utility module.
"""

import hashlib
import logging
import re
from datetime import datetime, timezone
from typing import Any

logger = logging.getLogger(__name__)


def slugify(value: str) -> str:
    """Convert *value* to a URL-safe lowercase slug."""
    value = value.strip().lower()
    value = re.sub(r"[^\w\s-]", "", value)
    value = re.sub(r"[\s_-]+", "-", value)
    return value


def hash_string(value: str) -> str:
    """Return the SHA-256 hex digest of *value*."""
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def utcnow() -> datetime:
    """Return the current UTC datetime."""
    return datetime.now(tz=timezone.utc)


def chunk_list(lst: list, size: int) -> list[list]:
    """Split *lst* into chunks of at most *size* elements."""
    if size <= 0:
        raise ValueError("chunk size must be positive")
    return [lst[i : i + size] for i in range(0, len(lst), size)]


def deep_merge(base: dict, override: dict) -> dict:
    """Recursively merge *override* into *base*, returning a new dict."""
    result = dict(base)
    for key, val in override.items():
        if key in result and isinstance(result[key], dict) and isinstance(val, dict):
            result[key] = deep_merge(result[key], val)
        else:
            result[key] = val
    return result


def safe_get(data: Any, *keys, default=None) -> Any:
    """Navigate nested dicts/lists with a tuple of keys, returning *default* on miss."""
    current = data
    for key in keys:
        try:
            if isinstance(current, dict):
                current = current[key]
            elif isinstance(current, (list, tuple)):
                current = current[int(key)]
            else:
                return default
        except (KeyError, IndexError, TypeError, ValueError):
            return default
    return current


def truncate(text: str, max_length: int = 80, suffix: str = "…") -> str:
    """Return *text* truncated to *max_length* characters."""
    if len(text) <= max_length:
        return text
    return text[: max_length - len(suffix)] + suffix


class Singleton(type):
    """Metaclass that ensures only one instance of a class is created."""

    _instances: dict = {}

    def __call__(cls, *args, **kwargs):
        if cls not in cls._instances:
            cls._instances[cls] = super().__call__(*args, **kwargs)
        return cls._instances[cls]
