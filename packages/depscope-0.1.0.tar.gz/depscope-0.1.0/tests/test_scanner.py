"""Tests for the scanner subpackage."""

from __future__ import annotations

import sys
from pathlib import Path

import pytest

# Add src to path so repo_graph imports work without installing the package
REPO_ROOT = Path(__file__).parent.parent
sys.path.insert(0, str(REPO_ROOT / "src"))

FIXTURES = REPO_ROOT / "tests" / "fixtures" / "sample_python"


# ---------------------------------------------------------------------------
# Walker tests
# ---------------------------------------------------------------------------


class TestWalker:
    def test_finds_python_files(self):
        """walker.walk_repo should find all .py files in the fixture directory."""
        from repo_graph.scanner.walker import walk_repo

        files = walk_repo(FIXTURES)
        py_files = [f for f in files if f.suffix == ".py"]
        assert len(py_files) >= 5, f"Expected at least 5 .py files, got {len(py_files)}"

    def test_finds_specific_files(self):
        """walker should find utils.py, models.py, services.py etc."""
        from repo_graph.scanner.walker import walk_repo

        files = walk_repo(FIXTURES)
        names = {f.name for f in files}
        for expected in ("utils.py", "models.py", "services.py", "api.py", "main.py"):
            assert expected in names, f"{expected} not found in walker output"

    def test_exclude_pattern_works(self):
        """Passing an exclude pattern should remove matching files."""
        from repo_graph.scanner.walker import walk_repo

        files_all = walk_repo(FIXTURES)
        files_excl = walk_repo(FIXTURES, exclude=["**/services.py"])
        names_all = {f.name for f in files_all}
        names_excl = {f.name for f in files_excl}
        assert "services.py" in names_all
        assert "services.py" not in names_excl

    def test_include_pattern_filters(self):
        """Only files matching include patterns should be returned."""
        from repo_graph.scanner.walker import walk_repo

        files = walk_repo(FIXTURES, include=["**/utils.py"])
        names = {f.name for f in files}
        assert names == {"utils.py"}, f"Expected only utils.py, got {names}"

    def test_returns_absolute_paths(self):
        """All returned paths should be absolute."""
        from repo_graph.scanner.walker import walk_repo

        files = walk_repo(FIXTURES)
        for f in files:
            assert f.is_absolute(), f"Expected absolute path, got: {f}"


# ---------------------------------------------------------------------------
# Parser tests
# ---------------------------------------------------------------------------


class TestParser:
    def test_parse_utils_returns_parsed_file(self):
        """parse_file should return a ParsedFile for a valid Python file."""
        from repo_graph.scanner.parser import ParsedFile, parse_file

        pf = parse_file(FIXTURES / "utils.py")
        assert pf is not None
        assert isinstance(pf, ParsedFile)
        assert pf.language == "python"
        assert pf.loc > 0

    def test_parse_utils_has_no_local_imports(self):
        """utils.py has no local imports — all imports should be stdlib."""
        from repo_graph.scanner.parser import parse_file

        pf = parse_file(FIXTURES / "utils.py")
        assert pf is not None
        # utils should not import from local modules (models, services, etc.)
        local_modules = {"models", "services", "database", "cache", "api", "main"}
        for imp in pf.imports:
            assert imp.raw_specifier not in local_modules, (
                f"utils.py unexpectedly imports local module: {imp.raw_specifier}"
            )

    def test_parse_models_imports_utils(self):
        """models.py should have an import from utils."""
        from repo_graph.scanner.parser import parse_file

        pf = parse_file(FIXTURES / "models.py")
        assert pf is not None
        specs = {imp.raw_specifier for imp in pf.imports}
        assert "utils" in specs, f"Expected 'utils' in imports, got: {specs}"

    def test_parse_services_imports_cache(self):
        """services.py should import from cache (creating the cycle)."""
        from repo_graph.scanner.parser import parse_file

        pf = parse_file(FIXTURES / "services.py")
        assert pf is not None
        specs = {imp.raw_specifier for imp in pf.imports}
        assert "cache" in specs, f"Expected 'cache' in imports, got: {specs}"

    def test_parse_extracts_symbols(self):
        """parse_file should extract function and class definitions."""
        from repo_graph.scanner.parser import parse_file

        pf = parse_file(FIXTURES / "utils.py")
        assert pf is not None
        symbol_names = {s.name for s in pf.symbols}
        # utils.py defines slugify, hash_string, utcnow, etc.
        for expected in ("slugify", "hash_string", "utcnow", "chunk_list"):
            assert expected in symbol_names, (
                f"Expected symbol '{expected}' not found. Got: {symbol_names}"
            )

    def test_parse_symbol_public_flag(self):
        """Symbols not starting with _ should be marked is_public=True."""
        from repo_graph.scanner.parser import parse_file

        pf = parse_file(FIXTURES / "utils.py")
        assert pf is not None
        for sym in pf.symbols:
            if sym.name.startswith("_"):
                assert not sym.is_public, f"Private symbol {sym.name} marked public"
            else:
                assert sym.is_public, f"Public symbol {sym.name} marked private"

    def test_parse_extracts_imported_names(self):
        """from X import Y should populate imported_names with Y."""
        from repo_graph.scanner.parser import parse_file

        pf = parse_file(FIXTURES / "models.py")
        assert pf is not None
        for imp in pf.imports:
            if imp.raw_specifier == "utils":
                assert len(imp.imported_names) > 0
                break
        else:
            pytest.skip("models.py does not import from utils (fixture changed?)")

    def test_parse_nonexistent_file_returns_none(self):
        """parse_file should return None for a missing file."""
        from repo_graph.scanner.parser import parse_file

        result = parse_file(Path("/nonexistent/path/fake.py"))
        assert result is None

    def test_loc_counts_nonblank_noncomment(self):
        """LOC should count only non-blank, non-comment lines."""
        from repo_graph.scanner.parser import parse_file

        pf = parse_file(FIXTURES / "utils.py")
        assert pf is not None
        # LOC should be less than total line count (comments + blanks exist)
        total_lines = (FIXTURES / "utils.py").read_text().count("\n")
        assert pf.loc < total_lines, "LOC should exclude blank/comment lines"
        assert pf.loc > 0
