"""Graph subpackage: builds and analyses the module dependency graph."""
