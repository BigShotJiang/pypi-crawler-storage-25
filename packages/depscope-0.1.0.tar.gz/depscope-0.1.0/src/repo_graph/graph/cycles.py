"""Cycle and articulation-point detection for directed graphs."""

from __future__ import annotations

import networkx as nx


def find_cycles(g: nx.DiGraph) -> list[list[str]]:
    """Return a list of strongly-connected components that form real cycles.

    Each element is a list of node ids that are mutually reachable (i.e. an
    SCC of size > 1, or a self-loop).

    Parameters
    ----------
    g:
        A directed NetworkX graph.

    Returns
    -------
    list[list[str]]
        Each inner list contains the node ids participating in one cycle.
        Nodes may appear in more than one entry if cycles overlap.
    """
    cycles: list[list[str]] = []
    for scc in nx.strongly_connected_components(g):
        if len(scc) > 1:
            cycles.append(sorted(scc))
        elif len(scc) == 1:
            # Check for self-loop
            node = next(iter(scc))
            if g.has_edge(node, node):
                cycles.append([node])
    return cycles


def find_articulation_points(g: nx.DiGraph) -> list[str]:
    """Return node ids whose removal would disconnect the (undirected) graph.

    Uses the underlying undirected version of *g* so that the algorithm
    works regardless of edge direction.

    Parameters
    ----------
    g:
        A directed NetworkX graph.

    Returns
    -------
    list[str]
        Sorted list of node ids that are articulation points.
    """
    undirected = g.to_undirected()
    return sorted(nx.articulation_points(undirected))
