"""Compute and attach metrics to a ModuleGraph."""

from __future__ import annotations

import logging

logger = logging.getLogger(__name__)


def compute_metrics(graph, git_info: dict[str, int]):
    """Fill fan_in, fan_out, in_cycle, and commit_count_90d on every node.

    Mutates *graph* in-place and also returns it.

    Parameters
    ----------
    graph:
        A :class:`~repo_graph.graph.builder.ModuleGraph` instance.
    git_info:
        Mapping of relative file path (posix) -> commit count for the last
        N days.  May be empty.

    Returns
    -------
    ModuleGraph
        The same *graph* object, with metrics filled in.
    """
    from repo_graph.graph.cycles import find_cycles

    g = graph.nx_graph

    # Identify cycle members
    cycle_nodes: set[str] = set()
    for scc in find_cycles(g):
        cycle_nodes.update(scc)

    for node_id, node in graph.nodes.items():
        node.fan_in = g.in_degree(node_id)
        node.fan_out = g.out_degree(node_id)
        node.in_cycle = node_id in cycle_nodes

        # Normalise the path key for git_info lookup (posix, no leading slash)
        rel_key = node.path.as_posix() if hasattr(node.path, "as_posix") else str(node.path)
        node.commit_count_90d = git_info.get(rel_key, 0)

    logger.debug(
        "Metrics computed: %d nodes, %d in cycles", len(graph.nodes), len(cycle_nodes)
    )
    return graph
