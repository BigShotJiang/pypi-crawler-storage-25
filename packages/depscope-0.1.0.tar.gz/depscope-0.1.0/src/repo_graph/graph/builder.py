"""Build the module dependency graph from a list of ParsedFile objects."""

from __future__ import annotations

import datetime
import logging
import os
from dataclasses import dataclass, field
from pathlib import Path, PurePosixPath

import networkx as nx

from repo_graph.scanner.parser import ParsedFile, SymbolRecord

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Graph dataclasses
# ---------------------------------------------------------------------------


@dataclass
class SymbolRef:
    """A reference from one module to a symbol defined in another."""

    name: str
    call_count: int
    is_unused: bool
    """True if the symbol is public on the target but never called from source."""
    signature: str = ""
    class_name: str | None = None
    """Enclosing class if this is a method, None for module-level functions."""


@dataclass
class ModuleEdge:
    """A directed import dependency between two modules."""

    source: str
    """Module id of the importing module."""

    target: str
    """Module id of the imported module."""

    symbol_refs: list[SymbolRef] = field(default_factory=list)
    call_count: int = 0
    crosses_boundary: list[str] = field(default_factory=list)


@dataclass
class ModuleNode:
    """Per-module metadata and metrics."""

    id: str
    """Relative path from repo root, '/' delimited."""

    path: Path
    language: str
    loc: int
    symbols: list[SymbolRecord] = field(default_factory=list)
    public_symbols: list[SymbolRecord] = field(default_factory=list)
    fan_in: int = 0
    fan_out: int = 0
    in_cycle: bool = False
    last_modified: str = ""
    commit_count_90d: int = 0


@dataclass
class ModuleGraph:
    """The complete module dependency graph."""

    nodes: dict[str, ModuleNode] = field(default_factory=dict)
    """module_id -> ModuleNode"""

    edges: list[ModuleEdge] = field(default_factory=list)

    nx_graph: nx.DiGraph = field(default_factory=nx.DiGraph)


# ---------------------------------------------------------------------------
# Resolution helpers
# ---------------------------------------------------------------------------


def _module_id(path: Path, repo_root: Path) -> str:
    """Return a '/' delimited relative path id."""
    try:
        rel = path.relative_to(repo_root)
    except ValueError:
        rel = path
    return rel.as_posix()


def _last_modified(path: Path) -> str:
    """Return ISO date of last file modification."""
    try:
        mtime = path.stat().st_mtime
        return datetime.datetime.fromtimestamp(mtime, tz=datetime.timezone.utc).date().isoformat()
    except OSError:
        return ""


class _Resolver:
    """Resolves import specifiers to module ids."""

    def __init__(self, nodes: dict[str, ModuleNode], repo_root: Path) -> None:
        self._nodes = nodes
        self._repo_root = repo_root
        # Build fast lookup: stem -> list[module_id]
        self._by_stem: dict[str, list[str]] = {}
        for mid in nodes:
            stem = PurePosixPath(mid).stem
            self._by_stem.setdefault(stem, []).append(mid)

    def resolve_python(self, raw_specifier: str, source_path: Path) -> str | None:
        """Try to resolve a Python import specifier to a module id.

        Handles:
        - Absolute dotted names: ``foo.bar`` -> look for ``foo/bar.py``
        - Relative imports: ``.foo`` -> relative to *source_path*'s package
        - Single names: ``models`` -> look for ``models.py`` anywhere
        """
        if raw_specifier.startswith("."):
            return self._resolve_python_relative(raw_specifier, source_path)

        # Convert dotted name to path candidate
        parts = raw_specifier.split(".")
        candidate_posix = "/".join(parts) + ".py"
        if candidate_posix in self._nodes:
            return candidate_posix

        # Try as package __init__
        pkg_candidate = "/".join(parts) + "/__init__.py"
        if pkg_candidate in self._nodes:
            return pkg_candidate

        # Fall back to stem match (last component)
        stem = parts[-1]
        matches = self._by_stem.get(stem, [])
        if len(matches) == 1:
            return matches[0]
        if len(matches) > 1:
            # Pick the one closest to the source file
            return self._closest(matches, source_path)

        return None

    def _resolve_python_relative(self, specifier: str, source_path: Path) -> str | None:
        # Count leading dots
        dots = len(specifier) - len(specifier.lstrip("."))
        rel_name = specifier.lstrip(".")

        # Walk up from source_path's directory by *dots* levels
        base = source_path.parent
        for _ in range(dots - 1):
            base = base.parent

        if rel_name:
            parts = rel_name.split(".")
            candidate = base / Path(*parts)
            for suffix in (".py", "/__init__.py", ".ts", ".tsx", ".js"):
                full = (
                    candidate.with_suffix(".py")
                    if suffix == ".py"
                    else candidate / "__init__.py"
                    if suffix == "/__init__.py"
                    else candidate.with_suffix(suffix)
                )
                mid = _module_id(full, self._repo_root)
                if mid in self._nodes:
                    return mid
        else:
            # from . import X — the package itself
            init = base / "__init__.py"
            mid = _module_id(init, self._repo_root)
            if mid in self._nodes:
                return mid

        return None

    def resolve_typescript(self, raw_specifier: str, source_path: Path) -> str | None:
        """Resolve a TypeScript/JS import specifier."""
        if not (raw_specifier.startswith(".") or raw_specifier.startswith("/")):
            # Third-party package — not in graph
            return None

        # Resolve relative to source file directory
        base_dir = source_path.parent
        candidate = (base_dir / raw_specifier).resolve()

        # Try various extensions
        for suffix in (".ts", ".tsx", ".js", ".jsx", "/index.ts", "/index.js"):
            if suffix.startswith("/"):
                full = Path(str(candidate) + suffix[1:])
            else:
                full = candidate.with_suffix(suffix) if not candidate.suffix else candidate
                if suffix not in (".ts", ".tsx", ".js", ".jsx"):
                    full = candidate.parent / (candidate.name + suffix)
                else:
                    full = Path(str(candidate)).with_suffix(suffix)
            mid = _module_id(full, self._repo_root)
            if mid in self._nodes:
                return mid

        # Stem match
        stem = PurePosixPath(raw_specifier).stem
        matches = self._by_stem.get(stem, [])
        if len(matches) == 1:
            return matches[0]
        if len(matches) > 1:
            return self._closest(matches, source_path)

        return None

    def _closest(self, candidates: list[str], source_path: Path) -> str:
        """Return the candidate whose path is closest to source_path."""
        source_parts = source_path.parts
        best = candidates[0]
        best_score = -1
        for c in candidates:
            c_parts = Path(c).parts
            common = sum(
                1
                for a, b in zip(reversed(source_parts), reversed(c_parts))
                if a == b
            )
            if common > best_score:
                best_score = common
                best = c
        return best


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def build_graph(
    parsed_files: list[ParsedFile],
    repo_root: Path,
    boundaries: list[str] | None = None,
) -> ModuleGraph:
    """Build a :class:`ModuleGraph` from *parsed_files*.

    Parameters
    ----------
    parsed_files:
        Output from :func:`~repo_graph.scanner.parser.parse_file`.
    repo_root:
        Absolute path to the repository root.
    boundaries:
        Optional list of path prefixes that define architectural boundaries.
    """
    boundaries = boundaries or []
    graph = ModuleGraph(nx_graph=nx.DiGraph())

    # Phase 1: Create all nodes
    for pf in parsed_files:
        mid = _module_id(pf.path, repo_root)
        public_syms = [s for s in pf.symbols if s.is_public]
        node = ModuleNode(
            id=mid,
            path=pf.path,
            language=pf.language,
            loc=pf.loc,
            symbols=pf.symbols,
            public_symbols=public_syms,
            last_modified=_last_modified(pf.path),
        )
        graph.nodes[mid] = node
        graph.nx_graph.add_node(mid)

    resolver = _Resolver(graph.nodes, repo_root)

    # Phase 2: Build edges
    edge_map: dict[tuple[str, str], ModuleEdge] = {}

    for pf in parsed_files:
        source_id = _module_id(pf.path, repo_root)
        source_node = graph.nodes[source_id]

        # Count how many times each callee name is called in this file
        call_counts: dict[str, int] = {}
        for cs in pf.call_sites:
            call_counts[cs.callee] = call_counts.get(cs.callee, 0) + 1

        for imp in pf.imports:
            if pf.language == "python":
                target_id = resolver.resolve_python(imp.raw_specifier, pf.path)
            else:
                target_id = resolver.resolve_typescript(imp.raw_specifier, pf.path)

            if target_id is None or target_id == source_id:
                continue
            if target_id not in graph.nodes:
                continue

            edge_key = (source_id, target_id)
            if edge_key not in edge_map:
                # Determine crossed boundaries
                crossed = _crossed_boundaries(source_id, target_id, boundaries)
                edge_map[edge_key] = ModuleEdge(
                    source=source_id,
                    target=target_id,
                    crosses_boundary=crossed,
                )
                graph.nx_graph.add_edge(source_id, target_id)

            edge = edge_map[edge_key]

            # Enrich with symbol refs
            target_node = graph.nodes[target_id]
            imported_set = set(imp.imported_names)
            if "*" in imported_set:
                imported_set = {s.name for s in target_node.public_symbols}

            for sym in target_node.public_symbols:
                if sym.name not in imported_set:
                    continue
                cnt = call_counts.get(sym.name, 0)
                existing = next(
                    (r for r in edge.symbol_refs if r.name == sym.name), None
                )
                if existing:
                    existing.call_count += cnt
                    if cnt > 0:
                        existing.is_unused = False
                else:
                    edge.symbol_refs.append(
                        SymbolRef(
                            name=sym.name,
                            call_count=cnt,
                            is_unused=cnt == 0,
                            signature=sym.signature,
                            class_name=sym.class_name,
                        )
                    )

        # Roll up total call count for this edge from its symbol refs
        edge_key_src = _module_id(pf.path, repo_root)
        for edge in edge_map.values():
            if edge.source == edge_key_src:
                edge.call_count = sum(r.call_count for r in edge.symbol_refs)

    graph.edges = list(edge_map.values())

    logger.info(
        "Graph built: %d nodes, %d edges",
        len(graph.nodes),
        len(graph.edges),
    )
    return graph


def _crossed_boundaries(
    source_id: str, target_id: str, boundaries: list[str]
) -> list[str]:
    """Return the names of boundaries crossed by this edge."""
    crossed: list[str] = []
    for boundary in boundaries:
        src_in = source_id.startswith(boundary.rstrip("/") + "/") or source_id == boundary
        tgt_in = target_id.startswith(boundary.rstrip("/") + "/") or target_id == boundary
        if src_in != tgt_in:
            crossed.append(boundary)
    return crossed
