"""Viewer subpackage: HTML report generation."""
