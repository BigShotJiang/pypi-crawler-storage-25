"""HTML report generator — renders the interactive graph viewer."""

from __future__ import annotations

import datetime
import json
import logging
from pathlib import Path

from repo_graph.graph.builder import ModuleGraph
from repo_graph.graph.cycles import find_cycles
from repo_graph.config import RepoGraphConfig

logger = logging.getLogger(__name__)

_TEMPLATE_DIR = Path(__file__).parent / "templates"


def _serialize_graph(graph: ModuleGraph, config: RepoGraphConfig | None = None) -> dict:
    """Convert *graph* to a plain JSON-serialisable dict for the viewer."""
    # Identify cycle members and cycle edges
    cycle_lists = find_cycles(graph.nx_graph)
    cycle_nodes_set: set[str] = set()
    for scc in cycle_lists:
        cycle_nodes_set.update(scc)

    # Find edges that are part of cycles (both endpoints in cycle, AND reverse edge exists)
    cycle_edge_pairs: list[list[str]] = []
    for edge in graph.edges:
        src = edge.source
        tgt = edge.target
        if src in cycle_nodes_set and tgt in cycle_nodes_set:
            if graph.nx_graph.has_edge(tgt, src):
                cycle_edge_pairs.append([src, tgt])

    nodes = []
    for node_id, node in graph.nodes.items():
        nodes.append(
            {
                "id": node_id,
                "language": node.language,
                "loc": node.loc,
                "fan_in": node.fan_in,
                "fan_out": node.fan_out,
                "in_cycle": node.in_cycle,
                "last_modified": node.last_modified,
                "commit_count_90d": node.commit_count_90d,
                "symbols": [
                    {
                        "name": s.name,
                        "kind": s.kind,
                        "signature": s.signature,
                        "line": s.line,
                        "is_public": s.is_public,
                    }
                    for s in node.symbols
                ],
            }
        )

    edges = []
    for edge in graph.edges:
        edges.append(
            {
                "source": edge.source,
                "target": edge.target,
                "call_count": edge.call_count,
                "crosses_boundary": edge.crosses_boundary,
                "symbol_refs": [
                    {
                        "name": r.name,
                        "call_count": r.call_count,
                        "is_unused": r.is_unused,
                        "signature": r.signature,
                        "class_name": r.class_name,
                    }
                    for r in edge.symbol_refs
                ],
            }
        )

    result: dict = {
        "nodes": nodes,
        "edges": edges,
        "cycle_nodes": sorted(cycle_nodes_set),
        "cycle_edges": cycle_edge_pairs,
        "node_positions": config.node_positions if config else {},
        "saved_boundaries": config.saved_boundaries if config else [],
    }
    return result


def generate_html(
    graph: ModuleGraph,
    output_path: Path,
    project_name: str,
    config: RepoGraphConfig | None = None,
) -> None:
    """Render a self-contained interactive HTML file to *output_path*.

    Parameters
    ----------
    graph:
        The fully computed :class:`~repo_graph.graph.builder.ModuleGraph`.
    output_path:
        Destination file path.  Parent directories are created if needed.
    project_name:
        Human-readable project name for the report header.
    """
    output_path.parent.mkdir(parents=True, exist_ok=True)

    graph_data = _serialize_graph(graph, config)
    graph_data["project_name"] = project_name
    graph_json = json.dumps(graph_data, ensure_ascii=False, indent=None)

    # Count cycles
    cycle_count = len(find_cycles(graph.nx_graph))

    from jinja2 import Template
    from markupsafe import Markup

    template_str = (_TEMPLATE_DIR / "base.html").read_text(encoding="utf-8")
    tmpl = Template(template_str)
    rendered = tmpl.render(
        project_name=project_name,
        node_count=len(graph.nodes),
        edge_count=len(graph.edges),
        cycle_count=cycle_count,
        generated_at=datetime.datetime.now(tz=datetime.timezone.utc).strftime(
            "%Y-%m-%d %H:%M UTC"
        ),
        graph_json=Markup(graph_json),
    )

    output_path.write_text(rendered, encoding="utf-8")
    logger.info("HTML report written to %s", output_path)
