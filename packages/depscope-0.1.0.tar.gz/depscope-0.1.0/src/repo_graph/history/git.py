"""Git history integration — commit frequency over last N days."""

from __future__ import annotations

import datetime
import logging
from pathlib import Path

logger = logging.getLogger(__name__)


def get_commit_counts(repo_root: Path, days: int = 90) -> dict[str, int]:
    """Return per-file commit counts for the last *days* days.

    Parameters
    ----------
    repo_root:
        Absolute path to the repository root.
    days:
        How many calendar days to look back.

    Returns
    -------
    dict[str, int]
        Maps posix-relative file paths (from repo root) to commit count.
        Returns an empty dict if git history is unavailable or gitpython
        is not installed.
    """
    try:
        import git as gitpython
    except ImportError:
        logger.debug("gitpython not installed; skipping git history.")
        return {}

    try:
        repo = gitpython.Repo(str(repo_root), search_parent_directories=True)
    except (gitpython.InvalidGitRepositoryError, gitpython.NoSuchPathError) as exc:
        logger.debug("Not a git repo or git unavailable: %s", exc)
        return {}

    since = datetime.datetime.now(tz=datetime.timezone.utc) - datetime.timedelta(days=days)
    since_str = since.strftime("%Y-%m-%dT%H:%M:%SZ")

    counts: dict[str, int] = {}

    try:
        for commit in repo.iter_commits(since=since_str):
            # Each commit lists the files it touched via its stats
            for filepath in commit.stats.files:
                counts[filepath] = counts.get(filepath, 0) + 1
    except Exception as exc:
        logger.debug("Git history walk failed: %s", exc)
        return {}

    logger.info("Git history: %d files with commits in last %d days.", len(counts), days)
    return counts
