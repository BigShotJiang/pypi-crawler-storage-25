"""History subpackage: git log integration."""
