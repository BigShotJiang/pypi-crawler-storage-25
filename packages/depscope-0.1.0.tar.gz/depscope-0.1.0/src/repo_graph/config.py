"""Read/write .repo-graph.yml configuration in the repo root."""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml

logger = logging.getLogger(__name__)

CONFIG_FILENAME = ".repo-graph.yml"

_DEFAULT_INCLUDE = ["**/*.py", "**/*.ts", "**/*.tsx", "**/*.js", "**/*.jsx"]
_DEFAULT_EXCLUDE = [
    "node_modules/**",
    ".venv/**",
    "venv/**",
    "__pycache__/**",
    "*.pyc",
    "dist/**",
    "build/**",
    ".git/**",
    ".repo-graph/**",
]


@dataclass
class RepoGraphConfig:
    """Configuration for a repo-graph scan."""

    boundaries: list[str] = field(default_factory=list)
    """Named architectural boundaries, e.g. ["src/api", "src/core"]."""

    include: list[str] = field(default_factory=lambda: list(_DEFAULT_INCLUDE))
    """Glob patterns (relative to repo root) to include in the scan."""

    exclude: list[str] = field(default_factory=lambda: list(_DEFAULT_EXCLUDE))
    """Glob patterns to exclude from the scan."""

    node_positions: dict[str, dict] = field(default_factory=dict)
    """Saved node positions keyed by module id, e.g. {"src/foo.py": {"x": 100, "y": 200}}."""

    saved_boundaries: list[dict] = field(default_factory=list)
    """Saved boundary rectangles, e.g. [{"name": "API", "rect": {"x":0,"y":0,"w":200,"h":100}}]."""

    # ------------------------------------------------------------------
    # Factory / IO
    # ------------------------------------------------------------------

    @classmethod
    def load(cls, repo_root: Path) -> "RepoGraphConfig":
        """Load config from *repo_root*/.repo-graph.yml, or return defaults."""
        config_path = repo_root / CONFIG_FILENAME
        if not config_path.exists():
            logger.debug("No config file found at %s; using defaults.", config_path)
            return cls()
        try:
            with config_path.open("r", encoding="utf-8") as fh:
                raw: dict[str, Any] = yaml.safe_load(fh) or {}
        except (yaml.YAMLError, OSError) as exc:
            logger.warning("Failed to read %s: %s; using defaults.", config_path, exc)
            return cls()

        return cls(
            boundaries=raw.get("boundaries", []),
            include=raw.get("include", list(_DEFAULT_INCLUDE)),
            exclude=raw.get("exclude", list(_DEFAULT_EXCLUDE)),
            node_positions=raw.get("node_positions", {}),
            saved_boundaries=raw.get("saved_boundaries", []),
        )

    def save(self, repo_root: Path) -> None:
        """Write the current config to *repo_root*/.repo-graph.yml."""
        config_path = repo_root / CONFIG_FILENAME
        data: dict[str, Any] = {
            "boundaries": self.boundaries,
            "include": self.include,
            "exclude": self.exclude,
        }
        if self.node_positions:
            data["node_positions"] = self.node_positions
        if self.saved_boundaries:
            data["saved_boundaries"] = self.saved_boundaries
        with config_path.open("w", encoding="utf-8") as fh:
            yaml.dump(data, fh, default_flow_style=False, allow_unicode=True)
        logger.debug("Config saved to %s.", config_path)
