"""repo-graph: Architecture observation tool — interactive dependency graph for any codebase."""

__version__ = "0.1.0"
