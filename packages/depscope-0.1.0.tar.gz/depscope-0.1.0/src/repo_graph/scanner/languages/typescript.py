"""TypeScript / JavaScript language extractor using tree-sitter."""

from __future__ import annotations

import logging

logger = logging.getLogger(__name__)

_PARSERS: dict[str, object] = {}
_LANGUAGES: dict[str, object] = {}


def _get_parser(lang: str = "typescript"):
    if lang in _PARSERS:
        return _PARSERS[lang]

    try:
        import tree_sitter_typescript as tsts
        from tree_sitter import Language, Parser

        if lang == "tsx":
            language = Language(tsts.language_tsx())
        else:
            language = Language(tsts.language_typescript())

        parser = Parser(language)
        _PARSERS[lang] = parser
        _LANGUAGES[lang] = language
        return parser
    except Exception as exc:
        logger.warning("tree-sitter TypeScript grammar not available: %s", exc)
        return None


def _text(node) -> str:
    """Extract text from a tree-sitter node via its .text bytes attribute."""
    if node is None:
        return ""
    if hasattr(node, "text") and node.text is not None:
        return node.text.decode("utf-8", errors="replace")
    return ""


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def extract(
    source_code: str,
    tree=None,
    lang: str = "typescript",
) -> tuple[list, list, list]:
    """Extract imports, symbols, and call sites from TypeScript *source_code*."""
    from repo_graph.scanner.parser import CallSite, ImportRecord, SymbolRecord

    parser = _get_parser(lang)

    if parser is None:
        return _fallback_extract(source_code)

    if tree is None:
        try:
            tree = parser.parse(bytes(source_code, "utf-8"))
        except Exception as exc:
            logger.warning("tree-sitter parse failed for TS: %s", exc)
            return _fallback_extract(source_code)

    imports: list[ImportRecord] = []
    symbols: list[SymbolRecord] = []
    call_sites: list[CallSite] = []

    def walk(node, depth: int = 0):
        t = node.type

        if t == "import_statement":
            _handle_import(node, imports)

        elif t == "call_expression":
            func = node.child_by_field_name("function")
            args = node.child_by_field_name("arguments")
            if func and _text(func) == "require" and args:
                for arg in args.children:
                    if arg.type == "string":
                        spec = _text(arg).strip("'\"` ")
                        imports.append(
                            ImportRecord(
                                raw_specifier=spec,
                                imported_names=["*"],
                                alias=None,
                                line=node.start_point[0] + 1,
                            )
                        )
            else:
                if func:
                    callee_text = _text(func)
                    callee = callee_text.split(".")[-1]
                    call_sites.append(
                        CallSite(callee=callee, line=node.start_point[0] + 1)
                    )

        elif t in (
            "function_declaration",
            "method_definition",
            "arrow_function",
        ) and depth <= 3:
            _handle_function(node, depth, symbols)

        elif t == "class_declaration" and depth <= 2:
            _handle_class(node, symbols)
            for child in node.children:
                if child.type == "class_body":
                    for stmt in child.children:
                        walk(stmt, depth + 1)
            return

        elif t in (
            "export_statement",
            "lexical_declaration",
            "variable_declaration",
        ):
            _handle_export_or_const(node, depth, symbols)

        if depth < 4:
            for child in node.children:
                if child.type not in ("import_statement", "class_declaration"):
                    walk(child, depth + 1)

    for child in tree.root_node.children:
        walk(child, 0)

    return imports, symbols, call_sites


# ---------------------------------------------------------------------------
# Node handlers
# ---------------------------------------------------------------------------


def _handle_import(node, imports: list):
    from repo_graph.scanner.parser import ImportRecord

    source_node = node.child_by_field_name("source")
    if not source_node:
        for child in node.children:
            if child.type == "string":
                source_node = child
                break
    if not source_node:
        return

    spec = _text(source_node).strip("'\"` ")
    imported_names: list[str] = []

    for child in node.children:
        if child.type == "import_clause":
            for sub in child.children:
                if sub.type == "identifier":
                    imported_names.append(_text(sub))
                elif sub.type == "named_imports":
                    for item in sub.children:
                        if item.type == "import_specifier":
                            name_node = item.child_by_field_name("name")
                            if name_node:
                                imported_names.append(_text(name_node))
                elif sub.type == "namespace_import":
                    imported_names.append("*")

    imports.append(
        ImportRecord(
            raw_specifier=spec,
            imported_names=imported_names or ["*"],
            alias=None,
            line=node.start_point[0] + 1,
        )
    )


def _handle_function(node, depth: int, symbols: list):
    from repo_graph.scanner.parser import SymbolRecord

    name_node = node.child_by_field_name("name")
    if not name_node:
        return
    name = _text(name_node)
    params_node = node.child_by_field_name("parameters") or node.child_by_field_name(
        "formal_parameters"
    )
    params = _text(params_node) if params_node else "()"
    kind = "method" if depth > 1 else "function"
    symbols.append(
        SymbolRecord(
            name=name,
            kind=kind,
            signature=f"function {name}{params}",
            line=node.start_point[0] + 1,
            is_public=not name.startswith("_"),
        )
    )


def _handle_class(node, symbols: list):
    from repo_graph.scanner.parser import SymbolRecord

    name_node = node.child_by_field_name("name")
    if not name_node:
        return
    name = _text(name_node)
    symbols.append(
        SymbolRecord(
            name=name,
            kind="class",
            signature=f"class {name}",
            line=node.start_point[0] + 1,
            is_public=not name.startswith("_"),
        )
    )


def _handle_export_or_const(node, depth: int, symbols: list):
    from repo_graph.scanner.parser import SymbolRecord

    if node.type == "export_statement":
        for child in node.children:
            if child.type in ("function_declaration", "class_declaration"):
                _handle_function(child, depth, symbols)
                return
            elif child.type in ("lexical_declaration", "variable_declaration"):
                _handle_export_or_const(child, depth, symbols)
                return

    elif node.type in ("lexical_declaration", "variable_declaration"):
        for child in node.children:
            if child.type == "variable_declarator":
                name_node = child.child_by_field_name("name")
                if name_node and name_node.type == "identifier":
                    name = _text(name_node)
                    if name and (name.isupper() or name[0].isupper()):
                        symbols.append(
                            SymbolRecord(
                                name=name,
                                kind="constant",
                                signature=f"const {name}",
                                line=node.start_point[0] + 1,
                                is_public=not name.startswith("_"),
                            )
                        )


# ---------------------------------------------------------------------------
# Fallback regex extractor
# ---------------------------------------------------------------------------


def _fallback_extract(source_code: str) -> tuple[list, list, list]:
    import re
    from repo_graph.scanner.parser import CallSite, ImportRecord, SymbolRecord

    imports: list[ImportRecord] = []
    symbols: list[SymbolRecord] = []
    call_sites: list[CallSite] = []

    for lineno, line in enumerate(source_code.splitlines(), start=1):
        stripped = line.strip()

        m = re.match(r"import\s+.*\s+from\s+['\"]([^'\"]+)['\"]", stripped)
        if m:
            imports.append(
                ImportRecord(
                    raw_specifier=m.group(1),
                    imported_names=["*"],
                    alias=None,
                    line=lineno,
                )
            )
            continue

        m = re.match(r".*require\(['\"]([^'\"]+)['\"]\)", stripped)
        if m:
            imports.append(
                ImportRecord(
                    raw_specifier=m.group(1),
                    imported_names=["*"],
                    alias=None,
                    line=lineno,
                )
            )
            continue

        m = re.match(r"(?:export\s+)?(?:async\s+)?function\s+(\w+)\s*(\([^)]*\))?", stripped)
        if m:
            name = m.group(1)
            params = m.group(2) or "()"
            symbols.append(
                SymbolRecord(
                    name=name,
                    kind="function",
                    signature=f"function {name}{params}",
                    line=lineno,
                    is_public=not name.startswith("_"),
                )
            )
            continue

        m = re.match(r"(?:export\s+)?class\s+(\w+)", stripped)
        if m:
            name = m.group(1)
            symbols.append(
                SymbolRecord(
                    name=name,
                    kind="class",
                    signature=f"class {name}",
                    line=lineno,
                    is_public=True,
                )
            )

    return imports, symbols, call_sites
