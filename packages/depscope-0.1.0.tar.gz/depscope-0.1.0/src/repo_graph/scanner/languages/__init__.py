"""Language-specific extractor plugins."""
