"""Python language extractor using tree-sitter."""

from __future__ import annotations

import logging

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Lazy initialisation — tree-sitter may not be installed
# ---------------------------------------------------------------------------

_PARSER = None
_LANGUAGE = None


def _get_parser():
    global _PARSER, _LANGUAGE
    if _PARSER is not None:
        return _PARSER

    try:
        import tree_sitter_python as tspython
        from tree_sitter import Language, Parser

        _LANGUAGE = Language(tspython.language())
        _PARSER = Parser(_LANGUAGE)
        return _PARSER
    except Exception as exc:
        logger.warning("tree-sitter Python grammar not available: %s", exc)
        return None


def _text(node) -> str:
    """Extract text from a tree-sitter node using its byte offsets.

    Uses node.text (bytes) which correctly handles multi-byte characters.
    """
    if node is None:
        return ""
    if hasattr(node, "text") and node.text is not None:
        return node.text.decode("utf-8", errors="replace")
    return ""


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def extract(
    source_code: str,
    tree=None,
) -> tuple[list, list, list]:
    """Extract imports, symbols, and call sites from Python *source_code*."""
    from repo_graph.scanner.parser import CallSite, ImportRecord, SymbolRecord

    parser = _get_parser()

    if parser is None:
        return _fallback_extract(source_code)

    if tree is None:
        try:
            tree = parser.parse(bytes(source_code, "utf-8"))
        except Exception as exc:
            logger.warning("tree-sitter parse failed: %s", exc)
            return _fallback_extract(source_code)

    imports: list[ImportRecord] = []
    symbols: list[SymbolRecord] = []
    call_sites: list[CallSite] = []

    def walk(node, depth: int = 0, current_class: str | None = None):
        t = node.type

        # ------------------------------------------------------------------
        # Import statements
        # ------------------------------------------------------------------
        if t == "import_statement":
            for child in node.children:
                if child.type in ("dotted_name", "aliased_import"):
                    _handle_import_name(child, node, imports)

        elif t == "import_from_statement":
            _handle_from_import(node, imports)

        # ------------------------------------------------------------------
        # Definitions (top-level and class methods)
        # ------------------------------------------------------------------
        elif t in ("function_definition", "async_function_definition") and depth <= 2:
            _handle_function_def(node, depth, symbols, current_class)

        elif t == "class_definition" and depth <= 1:
            cls_name = _handle_class_def(node, symbols)
            # recurse into class body, passing class context for method extraction
            for child in node.children:
                if child.type == "block":
                    for stmt in child.children:
                        walk(stmt, depth + 1, current_class=cls_name)
            return  # already recursed

        # ------------------------------------------------------------------
        # Call expressions
        # ------------------------------------------------------------------
        elif t == "call":
            _handle_call(node, call_sites)
            # Still recurse into the call — arguments may contain nested calls
            for child in node.children:
                walk(child, depth + 1, current_class)
            return

        # Recurse — no depth limit so calls inside assignments, ifs, etc. are found
        for child in node.children:
            if child.type not in (
                "import_statement",
                "import_from_statement",
                "class_definition",
            ):
                walk(child, depth + 1, current_class)

    for child in tree.root_node.children:
        walk(child, 0)

    return imports, symbols, call_sites


# ---------------------------------------------------------------------------
# Node handlers
# ---------------------------------------------------------------------------


def _handle_import_name(node, stmt_node, imports: list):
    from repo_graph.scanner.parser import ImportRecord

    if node.type == "dotted_name":
        raw = _text(node)
        imports.append(
            ImportRecord(
                raw_specifier=raw,
                imported_names=[raw.split(".")[-1]],
                alias=None,
                line=stmt_node.start_point[0] + 1,
            )
        )
    elif node.type == "aliased_import":
        name_node = node.child_by_field_name("name")
        alias_node = node.child_by_field_name("alias")
        if name_node:
            raw = _text(name_node)
            alias = _text(alias_node) if alias_node else None
            imports.append(
                ImportRecord(
                    raw_specifier=raw,
                    imported_names=[alias or raw.split(".")[-1]],
                    alias=alias,
                    line=stmt_node.start_point[0] + 1,
                )
            )


def _handle_from_import(node, imports: list):
    from repo_graph.scanner.parser import ImportRecord

    module_node = node.child_by_field_name("module_name")
    dots = ""

    for child in node.children:
        if child.type in (".", "..."):
            dots += _text(child)
        elif child.type == "relative_import":
            for sub in child.children:
                if sub.type in (".", "..."):
                    dots += _text(sub)
                elif sub.type == "dotted_name":
                    module_node = sub

    raw_module = _text(module_node) if module_node else ""
    raw_specifier = dots + raw_module if dots else raw_module

    # Collect imported names
    imported_names: list[str] = []
    in_names = False
    for child in node.children:
        if child.type == "import":
            in_names = True
            continue
        if child.type == "wildcard_import" or child.type == "import_star":
            imported_names = ["*"]
            break
        if in_names:
            if child.type in ("identifier", "dotted_name"):
                imported_names.append(_text(child))
            elif child.type == "aliased_import":
                name_node = child.child_by_field_name("name")
                if name_node:
                    imported_names.append(_text(name_node))
            elif child.type == "import_from_as_clause":
                for sub in child.children:
                    if sub.type in ("dotted_name", "identifier"):
                        imported_names.append(_text(sub))

    if not raw_specifier:
        return

    imports.append(
        ImportRecord(
            raw_specifier=raw_specifier,
            imported_names=imported_names or ["*"],
            alias=None,
            line=node.start_point[0] + 1,
        )
    )


def _handle_function_def(node, depth: int, symbols: list, class_name: str | None = None):
    from repo_graph.scanner.parser import SymbolRecord

    name_node = node.child_by_field_name("name")
    if not name_node:
        return
    name = _text(name_node)
    params_node = node.child_by_field_name("parameters")
    params_text = _text(params_node) if params_node else "()"
    kind = "method" if class_name else "function"
    signature = f"def {name}{params_text}"
    symbols.append(
        SymbolRecord(
            name=name,
            kind=kind,
            signature=signature,
            line=node.start_point[0] + 1,
            is_public=not name.startswith("_"),
            class_name=class_name,
        )
    )


def _handle_class_def(node, symbols: list) -> str | None:
    from repo_graph.scanner.parser import SymbolRecord

    name_node = node.child_by_field_name("name")
    if not name_node:
        return None
    name = _text(name_node)
    bases = ""
    for child in node.children:
        if child.type == "argument_list":
            bases = _text(child)
    signature = f"class {name}{bases}"
    symbols.append(
        SymbolRecord(
            name=name,
            kind="class",
            signature=signature,
            line=node.start_point[0] + 1,
            is_public=not name.startswith("_"),
            class_name=None,
        )
    )
    return name


def _handle_call(node, call_sites: list):
    from repo_graph.scanner.parser import CallSite

    func_node = node.child_by_field_name("function")
    if not func_node:
        return

    callee_text = _text(func_node)
    callee = callee_text.split(".")[-1] if "." in callee_text else callee_text
    call_sites.append(
        CallSite(callee=callee, line=node.start_point[0] + 1)
    )


# ---------------------------------------------------------------------------
# Fallback regex-based extractor (when tree-sitter is unavailable)
# ---------------------------------------------------------------------------


def _fallback_extract(source_code: str) -> tuple[list, list, list]:
    import re
    from repo_graph.scanner.parser import CallSite, ImportRecord, SymbolRecord

    imports: list[ImportRecord] = []
    symbols: list[SymbolRecord] = []
    call_sites: list[CallSite] = []

    for lineno, line in enumerate(source_code.splitlines(), start=1):
        stripped = line.strip()

        # from X import Y
        m = re.match(r"from\s+([\w.]+)\s+import\s+(.+)", stripped)
        if m:
            spec = m.group(1)
            names_raw = m.group(2).split(",")
            names = [n.strip().split(" as ")[0].strip() for n in names_raw]
            imports.append(
                ImportRecord(
                    raw_specifier=spec,
                    imported_names=names,
                    alias=None,
                    line=lineno,
                )
            )
            continue

        # import X
        m = re.match(r"import\s+([\w.]+)(?:\s+as\s+(\w+))?", stripped)
        if m:
            spec = m.group(1)
            alias = m.group(2)
            imports.append(
                ImportRecord(
                    raw_specifier=spec,
                    imported_names=[alias or spec.split(".")[-1]],
                    alias=alias,
                    line=lineno,
                )
            )
            continue

        # def / async def
        m = re.match(r"(?:async\s+)?def\s+(\w+)\s*(\([^)]*\))?", stripped)
        if m:
            name = m.group(1)
            params = m.group(2) or "()"
            symbols.append(
                SymbolRecord(
                    name=name,
                    kind="function",
                    signature=f"def {name}{params}",
                    line=lineno,
                    is_public=not name.startswith("_"),
                )
            )
            continue

        # class
        m = re.match(r"class\s+(\w+)\s*(\([^)]*\))?", stripped)
        if m:
            name = m.group(1)
            bases = m.group(2) or ""
            symbols.append(
                SymbolRecord(
                    name=name,
                    kind="class",
                    signature=f"class {name}{bases}",
                    line=lineno,
                    is_public=not name.startswith("_"),
                )
            )

    return imports, symbols, call_sites
