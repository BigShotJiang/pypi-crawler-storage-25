"""Repository walker — enumerates source files respecting .gitignore."""

from __future__ import annotations

import logging
from pathlib import Path

import pathspec

logger = logging.getLogger(__name__)

SUPPORTED_EXTENSIONS = {".py", ".ts", ".tsx", ".js", ".jsx"}

_DEFAULT_INCLUDE = ["**/*.py", "**/*.ts", "**/*.tsx", "**/*.js", "**/*.jsx"]
_DEFAULT_EXCLUDE = [
    "node_modules/**",
    ".venv/**",
    "venv/**",
    "__pycache__/**",
    "*.pyc",
    "dist/**",
    "build/**",
    ".git/**",
    ".repo-graph/**",
]


def _load_gitignore(root: Path) -> pathspec.PathSpec | None:
    """Load .gitignore from *root* and return a PathSpec, or None."""
    gitignore = root / ".gitignore"
    if not gitignore.exists():
        return None
    try:
        with gitignore.open("r", encoding="utf-8", errors="replace") as fh:
            lines = fh.readlines()
        return pathspec.PathSpec.from_lines("gitignore", lines)
    except OSError as exc:
        logger.debug("Could not read .gitignore: %s", exc)
        return None


def walk_repo(
    root: Path,
    include: list[str] | None = None,
    exclude: list[str] | None = None,
) -> list[Path]:
    """Return a sorted list of source files under *root*.

    Parameters
    ----------
    root:
        Absolute path to the repository root.
    include:
        Glob patterns relative to *root* to include.  Defaults to all
        supported extensions.
    exclude:
        Glob patterns to exclude.  Layered on top of .gitignore.
    """
    if include is None:
        include = _DEFAULT_INCLUDE
    if exclude is None:
        exclude = _DEFAULT_EXCLUDE

    include_spec = pathspec.PathSpec.from_lines("gitignore", include)
    exclude_spec = pathspec.PathSpec.from_lines("gitignore", exclude)
    gitignore_spec = _load_gitignore(root)

    results: list[Path] = []

    for candidate in sorted(root.rglob("*")):
        if not candidate.is_file():
            continue
        if candidate.suffix not in SUPPORTED_EXTENSIONS:
            continue

        rel = candidate.relative_to(root).as_posix()

        # gitignore check
        if gitignore_spec and gitignore_spec.match_file(rel):
            logger.debug("Gitignore excluded: %s", rel)
            continue

        # exclude check
        if exclude_spec.match_file(rel):
            logger.debug("Exclude pattern matched: %s", rel)
            continue

        # include check — must match at least one include pattern
        if not include_spec.match_file(rel):
            logger.debug("No include pattern matched: %s", rel)
            continue

        results.append(candidate)

    logger.info("Walker found %d files under %s", len(results), root)
    return results
