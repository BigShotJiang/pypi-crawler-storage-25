"""File parser — dispatches to language-specific extractors."""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from pathlib import Path

from repo_graph.cache import ASTCache

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Dataclasses
# ---------------------------------------------------------------------------


@dataclass
class ImportRecord:
    """Represents a single import statement in a source file."""

    raw_specifier: str
    """Module specifier, e.g. ``foo.bar`` or ``./utils``."""

    imported_names: list[str]
    """Names imported from the module (``["*"]`` for wildcard or star imports)."""

    alias: str | None
    """Alias used in ``import foo as f`` — value is ``"f"``."""

    line: int
    """1-based line number where the import appears."""


@dataclass
class SymbolRecord:
    """Represents a top-level or class-level symbol definition."""

    name: str
    kind: str
    """One of ``function``, ``class``, ``method``, ``constant``."""

    signature: str
    """Human-readable signature string, e.g. ``def foo(a, b)``."""

    line: int
    """1-based line number."""

    is_public: bool
    """``True`` if the symbol does not start with ``_``."""

    class_name: str | None = None
    """Enclosing class name for methods; ``None`` for top-level symbols."""


@dataclass
class CallSite:
    """Represents a call expression in the source."""

    callee: str
    """The name (or rightmost attribute segment) being called."""

    line: int
    """1-based line number."""


@dataclass
class ParsedFile:
    """Aggregated parse result for a single source file."""

    path: Path
    language: str
    loc: int
    """Lines of code — non-blank, non-comment lines."""

    imports: list[ImportRecord] = field(default_factory=list)
    symbols: list[SymbolRecord] = field(default_factory=list)
    call_sites: list[CallSite] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Extension -> language mapping
# ---------------------------------------------------------------------------

_EXT_LANG: dict[str, str] = {
    ".py": "python",
    ".ts": "typescript",
    ".tsx": "tsx",
    ".js": "javascript",
    ".jsx": "javascript",
}


def _count_loc(source: str, language: str) -> int:
    """Count non-blank, non-comment lines."""
    comment_prefix = "#" if language == "python" else "//"
    count = 0
    for line in source.splitlines():
        stripped = line.strip()
        if stripped and not stripped.startswith(comment_prefix):
            # Also exclude block comment openers in JS/TS
            if language != "python" and stripped.startswith("/*"):
                continue
            count += 1
    return count


# ---------------------------------------------------------------------------
# Cache serialisation helpers
# ---------------------------------------------------------------------------


def _to_cache(pf: ParsedFile) -> dict:
    return {
        "path": str(pf.path),
        "language": pf.language,
        "loc": pf.loc,
        "imports": [
            {
                "raw_specifier": r.raw_specifier,
                "imported_names": r.imported_names,
                "alias": r.alias,
                "line": r.line,
            }
            for r in pf.imports
        ],
        "symbols": [
            {
                "name": s.name,
                "kind": s.kind,
                "signature": s.signature,
                "line": s.line,
                "is_public": s.is_public,
                "class_name": s.class_name,
            }
            for s in pf.symbols
        ],
        "call_sites": [{"callee": c.callee, "line": c.line} for c in pf.call_sites],
    }


def _from_cache(data: dict) -> ParsedFile:
    return ParsedFile(
        path=Path(data["path"]),
        language=data["language"],
        loc=data["loc"],
        imports=[
            ImportRecord(
                raw_specifier=r["raw_specifier"],
                imported_names=r["imported_names"],
                alias=r.get("alias"),
                line=r["line"],
            )
            for r in data.get("imports", [])
        ],
        symbols=[
            SymbolRecord(
                name=s["name"],
                kind=s["kind"],
                signature=s["signature"],
                line=s["line"],
                is_public=s["is_public"],
                class_name=s.get("class_name"),
            )
            for s in data.get("symbols", [])
        ],
        call_sites=[
            CallSite(callee=c["callee"], line=c["line"])
            for c in data.get("call_sites", [])
        ],
    )


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def parse_file(
    path: Path,
    cache: ASTCache | None = None,
) -> ParsedFile | None:
    """Parse *path* and return a :class:`ParsedFile`, or ``None`` on error.

    Uses the AST cache if *cache* is provided to avoid re-parsing unchanged
    files.
    """
    lang = _EXT_LANG.get(path.suffix)
    if lang is None:
        logger.debug("Unsupported extension: %s", path.suffix)
        return None

    try:
        source = path.read_text(encoding="utf-8", errors="replace")
    except OSError as exc:
        logger.warning("Cannot read %s: %s", path, exc)
        return None

    content_hash = ASTCache.hash_content(source) if cache else ""

    # Cache lookup
    if cache:
        cached = cache.get(path, content_hash)
        if cached is not None:
            try:
                return _from_cache(cached)
            except Exception as exc:
                logger.debug("Cache deserialise error: %s", exc)

    # Dispatch to language extractor
    try:
        if lang == "python":
            from repo_graph.scanner.languages.python import extract

            imports, symbols, call_sites = extract(source)
        elif lang in ("typescript", "tsx"):
            from repo_graph.scanner.languages.typescript import extract

            imports, symbols, call_sites = extract(source, lang=lang)
        else:
            # JavaScript — use TypeScript extractor (it handles JS fine)
            from repo_graph.scanner.languages.typescript import extract

            imports, symbols, call_sites = extract(source, lang="typescript")
    except Exception as exc:
        logger.warning("Parse failure for %s: %s", path, exc)
        return None

    loc = _count_loc(source, lang)

    pf = ParsedFile(
        path=path,
        language=lang,
        loc=loc,
        imports=imports,
        symbols=symbols,
        call_sites=call_sites,
    )

    if cache:
        cache.set(path, content_hash, _to_cache(pf))

    return pf
