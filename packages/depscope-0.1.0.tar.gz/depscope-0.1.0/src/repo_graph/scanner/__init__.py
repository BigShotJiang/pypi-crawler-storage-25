"""Scanner subpackage: walks the filesystem and parses source files."""
