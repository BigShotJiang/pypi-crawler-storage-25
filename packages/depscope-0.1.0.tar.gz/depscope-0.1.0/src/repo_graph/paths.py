"""Canonical path handling utilities."""

from pathlib import Path


def resolve_repo_root(path: str | Path) -> Path:
    """Return the canonical absolute path for a repository root.

    Resolves symlinks, expands user home (~), and returns an absolute Path.
    Raises ValueError if the resulting path does not exist.
    """
    resolved = Path(path).expanduser().resolve()
    if not resolved.exists():
        raise ValueError(f"Path does not exist: {resolved}")
    if not resolved.is_dir():
        raise ValueError(f"Path is not a directory: {resolved}")
    return resolved
