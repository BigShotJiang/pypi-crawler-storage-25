"""Command-line interface for repo-graph."""

from __future__ import annotations

import datetime
import json
import sys
import time
import webbrowser
from pathlib import Path
from typing import Optional

import typer
from rich.console import Console
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn, TimeElapsedColumn
from rich.table import Table

app = typer.Typer(
    name="repo-graph",
    help="Architecture observation tool — generates an interactive dependency graph for any codebase.",
    add_completion=False,
)

console = Console(stderr=True)


# ---------------------------------------------------------------------------
# scan command
# ---------------------------------------------------------------------------


@app.command()
def scan(
    path: Path = typer.Argument(
        default=Path("."),
        help="Path to the repository to scan.",
        exists=False,
    ),
    output: Optional[Path] = typer.Option(
        None,
        "--output",
        "-o",
        help="Output path for the HTML file.  Defaults to <repo>/.repo-graph/graph.html",
    ),
    no_open: bool = typer.Option(
        False,
        "--no-open",
        help="Do not open the generated file in a browser.",
    ),
    include: list[str] = typer.Option(
        [],
        "--include",
        help="Additional glob patterns to include (can be specified multiple times).",
    ),
    exclude: list[str] = typer.Option(
        [],
        "--exclude",
        help="Additional glob patterns to exclude (can be specified multiple times).",
    ),
    json_output: bool = typer.Option(
        False,
        "--json",
        help="Also emit the graph summary as JSON to stdout.",
    ),
    no_cache: bool = typer.Option(
        False,
        "--no-cache",
        help="Disable the AST cache.",
    ),
    no_git: bool = typer.Option(
        False,
        "--no-git",
        help="Skip git history enrichment.",
    ),
) -> None:
    """Scan a repository and generate an interactive dependency graph."""
    from repo_graph.cache import ASTCache
    from repo_graph.config import RepoGraphConfig
    from repo_graph.graph.builder import build_graph
    from repo_graph.graph.cycles import find_cycles
    from repo_graph.graph.metrics import compute_metrics
    from repo_graph.history.git import get_commit_counts
    from repo_graph.paths import resolve_repo_root
    from repo_graph.scanner.parser import parse_file
    from repo_graph.scanner.walker import walk_repo
    from repo_graph.viewer.generator import generate_html

    # ------------------------------------------------------------------
    # Resolve root
    # ------------------------------------------------------------------
    try:
        repo_root = resolve_repo_root(path)
    except ValueError as exc:
        console.print(f"[red]Error:[/red] {exc}")
        raise typer.Exit(code=1)

    project_name = repo_root.name

    console.print(
        Panel(
            f"[bold cyan]repo-graph[/bold cyan]  scanning [yellow]{repo_root}[/yellow]",
            border_style="dim",
        )
    )

    # ------------------------------------------------------------------
    # Load config, merge CLI overrides
    # ------------------------------------------------------------------
    config = RepoGraphConfig.load(repo_root)
    if include:
        config.include = list(include)
    if exclude:
        config.exclude = list(exclude)

    # ------------------------------------------------------------------
    # Cache setup
    # ------------------------------------------------------------------
    cache: ASTCache | None = None
    if not no_cache:
        try:
            cache = ASTCache(repo_root)
        except OSError as exc:
            console.print(f"[yellow]Warning:[/yellow] Could not initialise cache: {exc}")

    # ------------------------------------------------------------------
    # Walk + parse
    # ------------------------------------------------------------------
    parsed_files = []
    import_count = 0
    parse_errors = 0

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        TimeElapsedColumn(),
        console=console,
        transient=True,
    ) as progress:
        walk_task = progress.add_task("Walking repository…", total=None)
        file_paths = walk_repo(repo_root, config.include, config.exclude)
        progress.update(walk_task, description=f"Found [bold]{len(file_paths)}[/bold] source files")

        parse_task = progress.add_task("Parsing files…", total=len(file_paths))
        for fp in file_paths:
            result = parse_file(fp, cache=cache)
            if result is None:
                parse_errors += 1
            else:
                parsed_files.append(result)
                import_count += len(result.imports)
            progress.advance(parse_task)

        # ------------------------------------------------------------------
        # Git history
        # ------------------------------------------------------------------
        git_info: dict[str, int] = {}
        if not no_git:
            progress.update(parse_task, description="Fetching git history…")
            try:
                git_info = get_commit_counts(repo_root)
            except Exception as exc:
                console.print(f"[yellow]Warning:[/yellow] Git history unavailable: {exc}")

        # Remap git keys to be relative to repo_root as posix paths
        remapped_git: dict[str, int] = {}
        for k, v in git_info.items():
            remapped_git[k] = v
            # Also try with leading path stripped
            remapped_git[Path(k).as_posix()] = v

        # ------------------------------------------------------------------
        # Build graph
        # ------------------------------------------------------------------
        progress.update(parse_task, description="Building dependency graph…")
        graph = build_graph(parsed_files, repo_root, boundaries=config.boundaries)

        progress.update(parse_task, description="Computing metrics…")
        compute_metrics(graph, remapped_git)

        # ------------------------------------------------------------------
        # Generate HTML
        # ------------------------------------------------------------------
        if output is None:
            output = repo_root / ".repo-graph" / "graph.html"

        progress.update(parse_task, description="Generating HTML…")
        generate_html(graph, output, project_name, config=config)

    # ------------------------------------------------------------------
    # Summary table
    # ------------------------------------------------------------------
    cycles = find_cycles(graph.nx_graph)

    table = Table(title="Scan Summary", border_style="dim", show_header=True)
    table.add_column("Metric", style="cyan")
    table.add_column("Value", style="bold white", justify="right")

    table.add_row("Repository", str(repo_root))
    table.add_row("Files scanned", str(len(parsed_files)))
    table.add_row("Parse errors", str(parse_errors))
    table.add_row("Imports found", str(import_count))
    table.add_row("Graph nodes", str(len(graph.nodes)))
    table.add_row("Graph edges", str(len(graph.edges)))
    table.add_row("Cycles detected", f"[{'red' if cycles else 'green'}]{len(cycles)}[/]")
    if cycles:
        for i, scc in enumerate(cycles[:5], 1):
            table.add_row(f"  Cycle {i}", " → ".join(scc[:4]) + (" …" if len(scc) > 4 else ""))
        if len(cycles) > 5:
            table.add_row("  …", f"+{len(cycles) - 5} more")
    table.add_row("Output file", str(output))

    console.print(table)

    # ------------------------------------------------------------------
    # JSON output to stdout
    # ------------------------------------------------------------------
    if json_output:
        summary = {
            "repo_root": str(repo_root),
            "files_scanned": len(parsed_files),
            "parse_errors": parse_errors,
            "imports_found": import_count,
            "nodes": len(graph.nodes),
            "edges": len(graph.edges),
            "cycles": len(cycles),
            "output": str(output),
        }
        print(json.dumps(summary, indent=2))

    # ------------------------------------------------------------------
    # Open in browser
    # ------------------------------------------------------------------
    if not no_open and output.exists():
        try:
            webbrowser.open(output.as_uri())
        except Exception as exc:
            console.print(f"[yellow]Could not open browser:[/yellow] {exc}")
    else:
        console.print(f"\n[green]Graph written to:[/green] {output}")


# ---------------------------------------------------------------------------
# watch command
# ---------------------------------------------------------------------------


@app.command()
def watch(
    path: Path = typer.Argument(
        default=Path("."),
        help="Repository to watch.",
        exists=False,
    ),
    output: Optional[Path] = typer.Option(
        None,
        "--output",
        "-o",
        help="Output path for the HTML file. Defaults to <repo>/.repo-graph/graph.html",
    ),
    interval: int = typer.Option(
        3,
        "--interval",
        "-i",
        help="Poll interval in seconds.",
    ),
    no_open: bool = typer.Option(False, "--no-open"),
    no_git: bool = typer.Option(False, "--no-git"),
    no_cache: bool = typer.Option(False, "--no-cache"),
) -> None:
    """Watch a repository and regenerate the graph whenever source files change."""
    from repo_graph.cache import ASTCache
    from repo_graph.config import RepoGraphConfig
    from repo_graph.graph.builder import build_graph
    from repo_graph.graph.metrics import compute_metrics
    from repo_graph.history.git import get_commit_counts
    from repo_graph.paths import resolve_repo_root
    from repo_graph.scanner.parser import parse_file
    from repo_graph.scanner.walker import walk_repo
    from repo_graph.viewer.generator import generate_html

    try:
        repo_root = resolve_repo_root(path)
    except ValueError as exc:
        console.print(f"[red]Error:[/red] {exc}")
        raise typer.Exit(code=1)

    project_name = repo_root.name

    if output is None:
        output = repo_root / ".repo-graph" / "graph.html"

    config = RepoGraphConfig.load(repo_root)

    def _do_scan() -> None:
        cache: ASTCache | None = None
        if not no_cache:
            try:
                cache = ASTCache(repo_root)
            except OSError:
                pass

        file_paths = walk_repo(repo_root, config.include, config.exclude)
        parsed_files = []
        for fp in file_paths:
            result = parse_file(fp, cache=cache)
            if result is not None:
                parsed_files.append(result)

        git_info: dict[str, int] = {}
        if not no_git:
            try:
                git_info = get_commit_counts(repo_root)
            except Exception:
                pass

        remapped_git: dict[str, int] = {}
        for k, v in git_info.items():
            remapped_git[k] = v
            remapped_git[Path(k).as_posix()] = v

        graph = build_graph(parsed_files, repo_root, boundaries=config.boundaries)
        compute_metrics(graph, remapped_git)
        generate_html(graph, output, project_name, config=config)

    def _collect_mtimes() -> dict:
        file_paths = walk_repo(repo_root, config.include, config.exclude)
        return {p: p.stat().st_mtime for p in file_paths}

    console.print(
        f"[bold cyan]repo-graph watch[/bold cyan]  watching [yellow]{repo_root}[/yellow]  "
        f"(interval: {interval}s)  [dim]Ctrl+C to stop[/dim]"
    )

    # Initial scan
    console.print("[dim]Initial scan…[/dim]")
    _do_scan()
    mtimes = _collect_mtimes()
    console.print(f"[green]Graph written to:[/green] {output}")

    if not no_open and output.exists():
        try:
            webbrowser.open(output.as_uri())
        except Exception:
            pass

    try:
        while True:
            time.sleep(interval)
            new_mtimes = _collect_mtimes()
            if new_mtimes != mtimes:
                ts = datetime.datetime.now().strftime("%H:%M:%S")
                console.print(f"[dim]{ts}[/dim] Change detected — regenerating…")
                _do_scan()
                mtimes = new_mtimes
                console.print(f"[dim]{ts}[/dim] [green]Done.[/green]")
    except KeyboardInterrupt:
        console.print("\n[dim]Stopped.[/dim]")


# ---------------------------------------------------------------------------
# init command — write a default config file
# ---------------------------------------------------------------------------


@app.command()
def init(
    path: Path = typer.Argument(default=Path("."), help="Repository root."),
) -> None:
    """Write a default .repo-graph.yml config to the repository root."""
    from repo_graph.config import RepoGraphConfig
    from repo_graph.paths import resolve_repo_root

    try:
        repo_root = resolve_repo_root(path)
    except ValueError as exc:
        console.print(f"[red]Error:[/red] {exc}")
        raise typer.Exit(code=1)

    config = RepoGraphConfig()
    config.save(repo_root)
    console.print(f"[green]Config written:[/green] {repo_root / '.repo-graph.yml'}")


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------


def main() -> None:  # pragma: no cover
    app()


if __name__ == "__main__":
    main()
