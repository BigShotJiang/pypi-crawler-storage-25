"""Simple JSON-based AST cache stored inside the repo."""

import hashlib
import json
import logging
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

CACHE_DIR_NAME = ".repo-graph"


def _cache_dir(repo_root: Path) -> Path:
    return repo_root / CACHE_DIR_NAME / "cache"


class ASTCache:
    """Persistent JSON cache for parsed file data, keyed by file content hash."""

    def __init__(self, repo_root: Path) -> None:
        self._root = _cache_dir(repo_root)
        self._root.mkdir(parents=True, exist_ok=True)

    # ------------------------------------------------------------------
    # Public helpers
    # ------------------------------------------------------------------

    @staticmethod
    def hash_content(content: str | bytes) -> str:
        """Return the sha256 hex digest for *content*."""
        if isinstance(content, str):
            content = content.encode("utf-8")
        return hashlib.sha256(content).hexdigest()

    def _entry_path(self, file_path: Path, content_hash: str) -> Path:
        # Use the hash as the filename so stale entries are simply orphaned.
        return self._root / f"{content_hash}.json"

    # ------------------------------------------------------------------
    # Cache interface
    # ------------------------------------------------------------------

    def get(self, file_path: Path, content_hash: str) -> Any | None:
        """Return cached data for *file_path* at *content_hash*, or None."""
        entry = self._entry_path(file_path, content_hash)
        if not entry.exists():
            return None
        try:
            with entry.open("r", encoding="utf-8") as fh:
                return json.load(fh)
        except (json.JSONDecodeError, OSError) as exc:
            logger.debug("Cache read error for %s: %s", entry, exc)
            return None

    def set(self, file_path: Path, content_hash: str, data: Any) -> None:
        """Store *data* for *file_path* at *content_hash*."""
        entry = self._entry_path(file_path, content_hash)
        try:
            with entry.open("w", encoding="utf-8") as fh:
                json.dump(data, fh, default=str)
        except OSError as exc:
            logger.debug("Cache write error for %s: %s", entry, exc)

    def clear(self) -> None:
        """Remove all cached entries."""
        for p in self._root.glob("*.json"):
            try:
                p.unlink()
            except OSError:
                pass
