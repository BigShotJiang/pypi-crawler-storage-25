from __future__ import annotations

import asyncio
import json
import logging
from typing import Awaitable, Callable

from websockets import connect
from websockets.exceptions import ConnectionClosed


LOGGER = logging.getLogger(__name__)

from bamboo_coding.shared.protocol import (
    AgentRegisterMessage,
    ClientStatusMessage,
    TaskEventMessage,
    TaskMessage,
    TaskQueryResultMessage,
    TaskResultMessage,
    TerminalCloseMessage,
    TerminalInputMessage,
    TerminalHeartbeatMessage,
    TerminalKillMessage,
    TerminalListRequest,
    TerminalListResponse,
    TerminalOpenMessage,
    TerminalOutputMessage,
    TerminalResizeMessage,
    TerminalSignalMessage,
    TerminalStatusMessage,
    TerminalClosedMessage,
)


TerminalControlMessage = (
    TerminalOpenMessage
    | TerminalInputMessage
    | TerminalResizeMessage
    | TerminalCloseMessage
    | TerminalSignalMessage
    | TerminalKillMessage
    | TerminalListRequest
)


class ControllerConnection:
    def __init__(self, controller_url: str, token: str = ''):
        self.controller_url = controller_url
        self.token = token
        self.websocket = None
        self._send_lock = asyncio.Lock()

    async def connect(self):
        headers = {}
        if self.token:
            headers['Authorization'] = f'Bearer {self.token}'
        self.websocket = await connect(self.controller_url, extra_headers=headers or None, ping_interval=20, ping_timeout=20)
        return self.websocket

    async def send_register(self, message: AgentRegisterMessage) -> dict:
        await self._send(message.model_dump())
        return await self._receive()

    async def send_status(self, message: ClientStatusMessage) -> None:
        await self._send(message.model_dump())

    async def send_event(self, message: TaskEventMessage) -> None:
        await self._send(message.model_dump())

    async def send_result(self, message: TaskResultMessage) -> None:
        await self._send(message.model_dump())

    async def send_query_result(self, message: TaskQueryResultMessage) -> None:
        await self._send(message.model_dump())

    async def send_terminal_status(self, message: TerminalStatusMessage) -> None:
        await self._send(message.model_dump())

    async def send_terminal_output(self, message: TerminalOutputMessage) -> None:
        await self._send(message.model_dump())

    async def send_terminal_heartbeat(self, message: TerminalHeartbeatMessage) -> None:
        await self._send(message.model_dump())

    async def send_terminal_closed(self, message: TerminalClosedMessage) -> None:
        await self._send(message.model_dump())

    async def send_terminal_list_response(self, message: TerminalListResponse) -> None:
        await self._send(message.model_dump())

    async def listen(
        self,
        on_task: Callable[[TaskMessage], Awaitable[None]],
        on_terminal_message: Callable[[TerminalControlMessage], Awaitable[None]] | None = None,
    ) -> None:
        if self.websocket is None:
            raise RuntimeError('connection not established')
        try:
            async for raw in self.websocket:
                data = json.loads(raw)
                message_type = data.get('type')
                if message_type == 'task':
                    await on_task(TaskMessage(**data))
                elif on_terminal_message is not None and message_type == 'terminal_open':
                    await on_terminal_message(TerminalOpenMessage(**data))
                elif on_terminal_message is not None and message_type == 'terminal_input':
                    await on_terminal_message(TerminalInputMessage(**data))
                elif on_terminal_message is not None and message_type == 'terminal_resize':
                    await on_terminal_message(TerminalResizeMessage(**data))
                elif on_terminal_message is not None and message_type == 'terminal_close':
                    await on_terminal_message(TerminalCloseMessage(**data))
                elif on_terminal_message is not None and message_type == 'terminal_signal':
                    await on_terminal_message(TerminalSignalMessage(**data))
                elif on_terminal_message is not None and message_type == 'terminal_kill':
                    await on_terminal_message(TerminalKillMessage(**data))
                elif on_terminal_message is not None and message_type == 'terminal_list':
                    await on_terminal_message(TerminalListRequest(**data))
        except ConnectionClosed:
            return

    async def close(self) -> None:
        if self.websocket is not None:
            await self.websocket.close()
            self.websocket = None

    async def _send(self, payload: dict) -> None:
        if self.websocket is None:
            raise RuntimeError('connection not established')
        async with self._send_lock:
            try:
                await self.websocket.send(json.dumps(payload))
            except ConnectionClosed:
                # Controller is gone; the run loop will reconnect. Drop the
                # outbound frame so cleanup paths (heartbeats, terminal_closed)
                # don't crash the runtime during server restarts.
                LOGGER.debug('skipping outbound message; controller connection is closed')

    async def _receive(self) -> dict:
        if self.websocket is None:
            raise RuntimeError('connection not established')
        raw = await self.websocket.recv()
        return json.loads(raw)
