"""Byte-capped scrollback ring buffer for a single terminal session."""
from __future__ import annotations

from collections import deque


class ScrollbackBuffer:
    """Ring buffer of recent PTY output for one terminal session.

    Not thread-safe. All calls must happen on the asyncio event loop
    thread that owns the session.
    """

    def __init__(self, max_bytes: int = 512 * 1024) -> None:
        self._max_bytes = max_bytes
        self._chunks: deque[bytes] = deque()
        self._byte_size = 0

    @property
    def byte_size(self) -> int:
        return self._byte_size

    def append(self, text: str) -> None:
        if not text:
            return
        encoded = text.encode("utf-8")
        self._chunks.append(encoded)
        self._byte_size += len(encoded)
        self._trim()

    def _trim(self) -> None:
        while self._byte_size > self._max_bytes and self._chunks:
            head = self._chunks[0]
            overflow = self._byte_size - self._max_bytes
            if len(head) <= overflow:
                self._chunks.popleft()
                self._byte_size -= len(head)
            else:
                # Keep only the tail of this chunk. Advance past `overflow`
                # bytes, then step forward to the next utf-8 code-point
                # boundary so we never surface a partial multibyte char.
                cut = overflow
                while cut < len(head) and (head[cut] & 0xC0) == 0x80:
                    cut += 1
                self._chunks[0] = head[cut:]
                self._byte_size -= cut

    def snapshot(self) -> str:
        return b"".join(self._chunks).decode("utf-8", errors="replace")

    def clear(self) -> None:
        self._chunks.clear()
        self._byte_size = 0
