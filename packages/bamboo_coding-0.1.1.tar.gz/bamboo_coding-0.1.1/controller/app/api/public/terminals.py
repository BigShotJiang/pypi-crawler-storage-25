from __future__ import annotations

import asyncio
from uuid import uuid4

from fastapi import APIRouter, HTTPException, Request, WebSocket
from fastapi.websockets import WebSocketDisconnect

from shared.protocol import TerminalClosedMessage, TerminalPingMessage, TerminalPongMessage, TerminalStatusMessage


router = APIRouter()
http_router = APIRouter(prefix="/api")


@http_router.get("/terminals")
async def list_terminals(agent_id: str, workspace_path: str, request: Request) -> dict:
    try:
        response = await request.app.state.terminals.request_terminal_list(
            agent_id=agent_id, workspace_path=workspace_path
        )
    except RuntimeError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    return response.model_dump()


@http_router.post("/terminals/{terminal_id}/kill")
async def kill_terminal(terminal_id: str, request: Request) -> dict:
    await request.app.state.terminals.kill_session(terminal_id)
    return {"ok": True}


def _parse_positive_int(value: str | None, default: int) -> int:
    try:
        parsed = int(value or '')
    except ValueError:
        return default
    return parsed if parsed > 0 else default


@router.websocket('/ws/terminal')
async def terminal_socket(websocket: WebSocket) -> None:
    await websocket.accept()

    agent_id = websocket.query_params.get('agent_id') or ''
    path = websocket.query_params.get('path') or ''
    terminal_id = websocket.query_params.get('terminal_id') or str(uuid4())
    cols = _parse_positive_int(websocket.query_params.get('cols'), 120)
    rows = _parse_positive_int(websocket.query_params.get('rows'), 32)
    send_lock = asyncio.Lock()

    async def send_json(payload: dict) -> None:
        async with send_lock:
            await websocket.send_json(payload)

    try:
        if not agent_id:
            raise RuntimeError('Missing agent_id query parameter')
        if not path:
            raise RuntimeError('Missing path query parameter')

        await websocket.app.state.terminals.open_browser_terminal(
            terminal_id=terminal_id,
            agent_id=agent_id,
            path=path,
            cols=cols,
            rows=rows,
            send_json=send_json,
        )
        while True:
            payload = await websocket.receive_json()
            if payload.get('type') == 'terminal_ping':
                TerminalPingMessage(**payload)
                await send_json(TerminalPongMessage(terminal_id=terminal_id).model_dump())
                continue
            await websocket.app.state.terminals.forward_browser_message(terminal_id, payload)
    except WebSocketDisconnect:
        await websocket.app.state.terminals.detach_browser_terminal(terminal_id, reason='browser_disconnected')
    except RuntimeError as exc:
        await send_json(TerminalStatusMessage(terminal_id=terminal_id, status='error', message=str(exc)).model_dump())
        await send_json(TerminalClosedMessage(terminal_id=terminal_id, reason=str(exc)).model_dump())
        await websocket.close()
