from __future__ import annotations

from fastapi import APIRouter, HTTPException, Request


router = APIRouter(prefix="/api")


def _list_public_roots(request: Request) -> list[dict]:
    return [item.model_dump() for item in request.app.state.repositories.list_public_roots()]


async def _dispatch(request: Request, path: str, capability: str, action: str, params: dict, agent_id: str | None = None) -> dict:
    try:
        return await request.app.state.router.dispatch_task(path, capability, action, params, agent_id=agent_id)
    except PermissionError as exc:
        raise HTTPException(status_code=403, detail=str(exc)) from exc
    except RuntimeError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


@router.get("/agents")
async def list_agents(request: Request) -> list[dict]:
    agents = request.app.state.agents.list_agents()
    for agent in agents:
        live_agent = request.app.state.router.live_agents.get(agent["agent_id"])
        agent["roots"] = [dict(root) for root in (live_agent.roots if live_agent is not None else [])]
    return agents


@router.post("/agents/{agent_id}/approve")
async def approve_agent(agent_id: str, request: Request) -> dict:
    import uuid

    token = uuid.uuid4().hex
    agent = request.app.state.agents.approve_agent(agent_id=agent_id, token=token)
    return {
        "approved": True,
        "agent_id": agent["agent_id"],
        "client_id": agent["client_id"],
        "token": agent["token"],
    }


@router.get("/roots")
async def list_roots(request: Request) -> list[dict]:
    return _list_public_roots(request)


@router.get("/fs/tree")
async def get_tree(path: str, request: Request, all: bool = False, agent_id: str | None = None) -> dict:
    return await _dispatch(request, path, "fs.tree", "get", {"all": all}, agent_id=agent_id)


@router.get("/fs/browse")
async def browse(path: str, request: Request, agent_id: str | None = None) -> dict:
    return await _dispatch(request, path, "fs.browse", "get", {}, agent_id=agent_id)


@router.get("/fs/file")
async def read_file(path: str, request: Request, agent_id: str | None = None) -> dict:
    return await _dispatch(request, path, "fs.file.read", "get", {}, agent_id=agent_id)


@router.get("/fs/file/raw")
async def read_file_raw(path: str, request: Request, agent_id: str | None = None) -> dict:
    return await _dispatch(request, path, "fs.file.read_raw", "get", {}, agent_id=agent_id)


@router.put("/fs/file")
async def write_file(path: str, request: Request, agent_id: str | None = None) -> dict:
    body = await request.json()
    return await _dispatch(request, path, "fs.file.write", "put", {"content": body.get("content", ""), "encoding": body.get("encoding", "utf-8")}, agent_id=agent_id)


@router.post("/fs/folder")
async def create_folder(path: str, request: Request, agent_id: str | None = None) -> dict:
    try:
        body = await request.json()
    except Exception:
        body = {}
    exist_ok = bool(body.get("exist_ok", True)) if isinstance(body, dict) else True
    return await _dispatch(request, path, "fs.folder.create", "post", {"exist_ok": exist_ok}, agent_id=agent_id)


@router.delete("/fs/path")
async def delete_path(path: str, request: Request, recursive: bool = False, agent_id: str | None = None) -> dict:
    return await _dispatch(request, path, "fs.path.delete", "delete", {"recursive": recursive}, agent_id=agent_id)


@router.put("/fs/path/rename")
async def rename_path(path: str, request: Request, agent_id: str | None = None) -> dict:
    body = await request.json()
    if not isinstance(body, dict):
        raise HTTPException(status_code=400, detail="Body must be a JSON object")
    destination = body.get("to") or body.get("new_path")
    if not destination:
        raise HTTPException(status_code=400, detail="Missing 'to' field in body")
    return await _dispatch(request, path, "fs.path.rename", "put", {"to": str(destination)}, agent_id=agent_id)


@router.get("/git/status")
async def get_status(path: str, request: Request, agent_id: str | None = None) -> dict:
    return await _dispatch(request, path, "git.status", "get", {}, agent_id=agent_id)


@router.get("/git/diff")
async def get_diff(path: str, request: Request, file: str | None = None, staged: bool = False, context: int = 3, agent_id: str | None = None) -> dict:
    if not file:
        raise HTTPException(status_code=400, detail="Missing file parameter")
    return await _dispatch(request, path, "git.diff", "get", {"file": file, "staged": staged, "context": context}, agent_id=agent_id)


@router.get("/git/commits")
async def get_commits(path: str, request: Request, limit: int = 50, offset: int = 0, agent_id: str | None = None) -> dict:
    if limit < 1 or limit > 100:
        raise HTTPException(status_code=400, detail="limit must be between 1 and 100")
    if offset < 0:
        raise HTTPException(status_code=400, detail="offset must be non-negative")
    return await _dispatch(request, path, "git.commits", "list", {"limit": limit, "offset": offset}, agent_id=agent_id)


@router.get("/git/commit/{commit_hash}")
async def get_commit_details(path: str, commit_hash: str, request: Request, agent_id: str | None = None) -> dict:
    return await _dispatch(request, path, "git.commit_details", "get", {"commit_hash": commit_hash}, agent_id=agent_id)


@router.post("/git/stage")
async def stage(path: str, request: Request, agent_id: str | None = None) -> dict:
    body = await request.json()
    return await _dispatch(request, path, "git.stage", "post", body, agent_id=agent_id)


@router.post("/git/unstage")
async def unstage(path: str, request: Request, agent_id: str | None = None) -> dict:
    body = await request.json()
    return await _dispatch(request, path, "git.unstage", "post", body, agent_id=agent_id)


@router.get("/git/branches")
async def list_branches(path: str, request: Request, agent_id: str | None = None) -> dict:
    return await _dispatch(request, path, "git.branches.list", "get", {}, agent_id=agent_id)


@router.post("/git/branches")
async def create_branch(path: str, request: Request, agent_id: str | None = None) -> dict:
    body = await request.json()
    return await _dispatch(request, path, "git.branches.create", "post", body, agent_id=agent_id)


@router.put("/git/branches/checkout")
async def checkout_branch(path: str, request: Request, agent_id: str | None = None) -> dict:
    body = await request.json()
    return await _dispatch(request, path, "git.branches.checkout", "put", body, agent_id=agent_id)


@router.delete("/git/branches/{name}")
async def delete_branch(path: str, name: str, request: Request, force: bool = False, agent_id: str | None = None) -> dict:
    return await _dispatch(request, path, "git.branches.delete", "delete", {"name": name, "force": force}, agent_id=agent_id)


@router.post("/git/branches/merge")
async def merge_branch(path: str, request: Request, agent_id: str | None = None) -> dict:
    body = await request.json()
    return await _dispatch(request, path, "git.branches.merge", "post", body, agent_id=agent_id)


@router.post("/git/commit")
async def create_commit(path: str, request: Request, agent_id: str | None = None) -> dict:
    body = await request.json()
    return await _dispatch(request, path, "git.commit.create", "post", body, agent_id=agent_id)


@router.get("/git/remotes")
async def list_remotes(path: str, request: Request, agent_id: str | None = None) -> dict:
    return await _dispatch(request, path, "git.remotes.list", "get", {}, agent_id=agent_id)


@router.post("/git/remotes")
async def add_remote(path: str, request: Request, agent_id: str | None = None) -> dict:
    body = await request.json()
    if not isinstance(body, dict) or not body.get("name") or not body.get("url"):
        raise HTTPException(status_code=400, detail="Missing 'name' or 'url'")
    return await _dispatch(request, path, "git.remotes.add", "post", body, agent_id=agent_id)


@router.delete("/git/remotes/{name}")
async def remove_remote(path: str, name: str, request: Request, agent_id: str | None = None) -> dict:
    return await _dispatch(request, path, "git.remotes.remove", "delete", {"name": name}, agent_id=agent_id)


@router.post("/git/remotes/push")
async def push_remote(path: str, request: Request, agent_id: str | None = None) -> dict:
    body = await request.json()
    if not isinstance(body, dict) or not body.get("remote"):
        raise HTTPException(status_code=400, detail="Missing 'remote'")
    return await _dispatch(request, path, "git.remotes.push", "post", body, agent_id=agent_id)


@router.post("/git/remotes/pull")
async def pull_remote(path: str, request: Request, agent_id: str | None = None) -> dict:
    body = await request.json()
    if not isinstance(body, dict) or not body.get("remote"):
        raise HTTPException(status_code=400, detail="Missing 'remote'")
    return await _dispatch(request, path, "git.remotes.pull", "post", body, agent_id=agent_id)


@router.post("/git/search")
async def search_repo(path: str, request: Request, agent_id: str | None = None) -> dict:
    try:
        body = await request.json()
    except Exception:
        body = {}
    if not isinstance(body, dict):
        raise HTTPException(status_code=400, detail="Body must be a JSON object")
    query = str(body.get("query") or "").strip()
    if not query:
        raise HTTPException(status_code=400, detail="Missing 'query'")
    params = {
        "query": query,
        "case_sensitive": bool(body.get("case_sensitive", False)),
        "whole_word": bool(body.get("whole_word", False)),
        "regex": bool(body.get("regex", False)),
        "max_matches": int(body.get("max_matches") or 1000),
    }
    return await _dispatch(request, path, "git.search", "post", params, agent_id=agent_id)
