from fastapi import APIRouter

from .repos import router as repos_router
from .terminals import http_router as terminals_http_router
from .terminals import router as terminals_router


router = APIRouter()
router.include_router(repos_router)
router.include_router(terminals_router)
router.include_router(terminals_http_router)

__all__ = ["router"]
