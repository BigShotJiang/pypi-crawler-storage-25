from __future__ import annotations

import asyncio

from fastapi import APIRouter, WebSocket
from fastapi.websockets import WebSocketDisconnect

from controller.app.core.errors import AgentApprovalError
from shared.protocol import (
    AgentRegisterMessage,
    ClientStatusMessage,
    RegisterRequestMessage,
    TaskEventMessage,
    TaskResultMessage,
    TerminalClosedMessage,
    TerminalHeartbeatMessage,
    TerminalListResponse,
    TerminalOutputMessage,
    TerminalStatusMessage,
)


router = APIRouter()


def _extract_token(websocket: WebSocket) -> str:
    auth_header = websocket.headers.get('authorization', '')
    if auth_header.startswith('Bearer '):
        return auth_header[7:]
    return websocket.query_params.get('token', '')


@router.websocket('/ws/agents')
async def agent_socket(websocket: WebSocket) -> None:
    await websocket.accept()
    send_lock = asyncio.Lock()

    async def send_json(payload: dict) -> None:
        async with send_lock:
            await websocket.send_json(payload)

    token = _extract_token(websocket)
    raw = await websocket.receive_json()
    register = AgentRegisterMessage(**raw)
    client_id = register.client_id or register.client_info.hostname
    agents = websocket.app.state.agents
    repos = websocket.app.state.repositories
    router_service = websocket.app.state.router
    terminals = websocket.app.state.terminals

    if not token:
        existing_agent = agents.get_agent_by_client_id(client_id)
        if existing_agent and existing_agent.get('approval_status') == 'approved' and existing_agent.get('token'):
            await send_json(RegisterRequestMessage(approved=True, client_id=client_id, token=existing_agent['token'], message='approved').model_dump())
        else:
            agents.create_registration_request(client_id)
            await send_json(RegisterRequestMessage(approved=False, client_id=client_id, message='pending approval').model_dump())
        await websocket.close()
        return

    try:
        agent = agents.register_connection(client_id=client_id, token=token, client_info=register.client_info.model_dump())
    except AgentApprovalError:
        agents.create_registration_request(client_id)
        await send_json(RegisterRequestMessage(approved=False, client_id=client_id, message='pending approval').model_dump())
        await websocket.close()
        return

    for repo in register.repositories:
        repos.upsert_repository_binding(
            agent_id=agent['agent_id'],
            repo_id=repo.repo_id,
            name=repo.name,
            path=repo.path,
            status='ready',
        )
    router_service.attach_agent(
        agent_id=agent['agent_id'],
        send_json=send_json,
        capabilities=[item.model_dump() for item in register.capabilities],
        repositories=[item.model_dump() for item in register.repositories],
    )
    await terminals.handle_agent_reconnected(agent['agent_id'])
    await send_json(RegisterRequestMessage(approved=True, client_id=client_id, token=token, message='registered').model_dump())

    try:
        while True:
            payload = await websocket.receive_json()
            message_type = payload.get('type')
            if message_type == 'client_status':
                status = ClientStatusMessage(**payload)
                for repo in status.repositories:
                    repos.upsert_repository_binding(
                        agent_id=agent['agent_id'],
                        repo_id=repo.repo_id,
                        name=repo.name,
                        path=repo.path,
                        status='ready',
                    )
                router_service.attach_agent(
                    agent_id=agent['agent_id'],
                    send_json=send_json,
                    capabilities=[item.model_dump() for item in status.capabilities],
                    repositories=[item.model_dump() for item in status.repositories],
                )
            elif message_type == 'task_event':
                event = TaskEventMessage(**payload)
                await router_service.handle_event(
                    task_id=event.task_id,
                    status=event.status,
                    message=event.message,
                    details=event.details,
                )
            elif message_type == 'task_result':
                result = TaskResultMessage(**payload)
                await router_service.handle_result(
                    task_id=result.task_id,
                    success=result.success,
                    result=result.result,
                    error=result.error,
                )
            elif message_type == 'terminal_status':
                await terminals.handle_terminal_status(TerminalStatusMessage(**payload))
            elif message_type == 'terminal_output':
                await terminals.handle_terminal_output(TerminalOutputMessage(**payload))
            elif message_type == 'terminal_heartbeat':
                await terminals.handle_terminal_heartbeat(TerminalHeartbeatMessage(**payload))
            elif message_type == 'terminal_closed':
                await terminals.handle_terminal_closed(TerminalClosedMessage(**payload))
            elif message_type == 'terminal_list_response':
                await terminals.handle_terminal_list_response(
                    agent['agent_id'], TerminalListResponse(**payload)
                )
    except WebSocketDisconnect:
        pass
    finally:
        router_service.detach_agent(agent['agent_id'])
        agents.mark_disconnected(agent['agent_id'])
        await terminals.handle_agent_disconnected(agent['agent_id'], reason='client_disconnected')
