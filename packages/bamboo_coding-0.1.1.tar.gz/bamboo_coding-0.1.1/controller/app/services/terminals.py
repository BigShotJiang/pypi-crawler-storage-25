from __future__ import annotations

import asyncio
import time
from dataclasses import dataclass
from typing import Awaitable, Callable

from controller.app.services.router import TaskRouter, _normalize_path, _path_is_within_root
from shared.protocol import (
    TerminalCloseMessage,
    TerminalClosedMessage,
    TerminalHeartbeatMessage,
    TerminalInputMessage,
    TerminalListRequest,
    TerminalListResponse,
    TerminalOpenMessage,
    TerminalOutputMessage,
    TerminalResizeMessage,
    TerminalSignalMessage,
    TerminalStatusMessage,
)


SendJson = Callable[[dict], Awaitable[None]]


async def _noop(_payload: dict) -> None:
    return None


@dataclass
class BrowserTerminalSession:
    terminal_id: str
    agent_id: str
    path: str
    cols: int
    rows: int
    send_json: SendJson
    attached: bool = True
    agent_online: bool = True
    last_activity: float = 0.0
    suspected_hang: bool = False


class TerminalRelayService:
    def __init__(self, router: TaskRouter):
        self.router = router
        self.sessions: dict[str, BrowserTerminalSession] = {}
        self._pending_list_requests: dict[
            tuple[str, str], list[asyncio.Future[TerminalListResponse]]
        ] = {}
        self._watchdog_task: asyncio.Task | None = None
        self._watchdog_interval: float = 10.0
        self._watchdog_silence_threshold: float = 30.0

    async def open_browser_terminal(
        self,
        *,
        terminal_id: str,
        agent_id: str,
        path: str,
        cols: int,
        rows: int,
        send_json: SendJson,
    ) -> str:
        normalized_path = _normalize_path(path)
        live_agent = self.router.live_agents.get(agent_id)
        if live_agent is None:
            raise RuntimeError(f"No live agent for selected client {agent_id}")
        if not live_agent.supports('terminal.open', 'post'):
            raise RuntimeError(f"Selected client {agent_id} does not support terminal.open:post")
        if not any(_path_is_within_root(normalized_path, root.get('path', '')) for root in live_agent.roots):
            raise RuntimeError(f"Path {normalized_path} is outside selected client roots")

        session = BrowserTerminalSession(
            terminal_id=terminal_id,
            agent_id=agent_id,
            path=normalized_path,
            cols=cols,
            rows=rows,
            send_json=send_json,
        )
        session.last_activity = time.monotonic()
        self.sessions[terminal_id] = session
        await send_json(TerminalStatusMessage(terminal_id=terminal_id, status='connecting').model_dump())
        await live_agent.send_json(
            TerminalOpenMessage(terminal_id=terminal_id, path=normalized_path, cols=cols, rows=rows).model_dump()
        )
        return terminal_id

    async def forward_browser_message(self, terminal_id: str, payload: dict) -> None:
        session = self.sessions.get(terminal_id)
        if session is None:
            return

        message_type = payload.get('type')
        if message_type == 'terminal_kill':
            await self.kill_session(terminal_id, reason='user_kill')
            return

        live_agent = self.router.live_agents.get(session.agent_id)
        if live_agent is None:
            await self.handle_terminal_closed(TerminalClosedMessage(terminal_id=terminal_id, reason='client_disconnected'))
            return

        if message_type == 'terminal_input':
            message = TerminalInputMessage(**payload)
            await live_agent.send_json(message.model_dump())
        elif message_type == 'terminal_resize':
            message = TerminalResizeMessage(**payload)
            await live_agent.send_json(message.model_dump())
        elif message_type == 'terminal_close':
            message = TerminalCloseMessage(**payload)
            await live_agent.send_json(message.model_dump())
        elif message_type == 'terminal_signal':
            message = TerminalSignalMessage(**payload)
            await live_agent.send_json(message.model_dump())

    async def handle_terminal_status(self, message: TerminalStatusMessage) -> None:
        if message.status != 'suspected_hang':
            session = self.sessions.get(message.terminal_id)
            if session is not None:
                await self._mark_session_active(session)
        await self._safe_send_to_browser(message.terminal_id, message.model_dump())

    async def handle_terminal_output(self, message: TerminalOutputMessage) -> None:
        session = self.sessions.get(message.terminal_id)
        if session is not None:
            await self._mark_session_active(session)
        await self._safe_send_to_browser(message.terminal_id, message.model_dump())

    async def handle_terminal_heartbeat(self, message: TerminalHeartbeatMessage) -> None:
        session = self.sessions.get(message.terminal_id)
        if session is not None:
            await self._mark_session_active(session)
        await self._safe_send_to_browser(message.terminal_id, message.model_dump())

    async def _mark_session_active(self, session: BrowserTerminalSession) -> None:
        session.last_activity = time.monotonic()
        if session.suspected_hang:
            session.suspected_hang = False
            if session.attached:
                try:
                    await session.send_json(
                        TerminalStatusMessage(
                            terminal_id=session.terminal_id,
                            status='attached',
                        ).model_dump()
                    )
                except Exception:
                    pass

    async def handle_terminal_closed(self, message: TerminalClosedMessage) -> None:
        session = self.sessions.pop(message.terminal_id, None)
        if session is None:
            return
        if not session.attached:
            return
        try:
            await session.send_json(message.model_dump())
        except Exception:
            return

    async def detach_browser_terminal(self, terminal_id: str, reason: str = 'browser_disconnected') -> None:
        session = self.sessions.get(terminal_id)
        if session is None:
            return
        session.attached = False
        session.send_json = _noop

    async def handle_agent_disconnected(self, agent_id: str, reason: str = 'client_disconnected') -> None:
        for session in self.sessions.values():
            if session.agent_id != agent_id:
                continue
            if session.attached:
                try:
                    await session.send_json(
                        TerminalStatusMessage(
                            terminal_id=session.terminal_id,
                            status='agent_offline',
                            message=reason,
                        ).model_dump()
                    )
                except Exception:
                    pass
            session.agent_online = False

    async def handle_agent_reconnected(self, agent_id: str) -> None:
        for session in self.sessions.values():
            if session.agent_id != agent_id:
                continue
            session.agent_online = True
            if session.attached:
                try:
                    await session.send_json(
                        TerminalStatusMessage(
                            terminal_id=session.terminal_id,
                            status='agent_reconnected',
                        ).model_dump()
                    )
                except Exception:
                    pass

    async def kill_session(self, terminal_id: str, reason: str = 'user_kill') -> None:
        session = self.sessions.get(terminal_id)
        if session is None:
            return
        live_agent = self.router.live_agents.get(session.agent_id)
        if live_agent is None:
            return
        if live_agent.supports('terminal.close', 'post'):
            try:
                await live_agent.send_json(
                    TerminalCloseMessage(terminal_id=terminal_id, reason=reason).model_dump()
                )
            except Exception:
                return

    async def _safe_send_to_browser(self, terminal_id: str, payload: dict) -> None:
        session = self.sessions.get(terminal_id)
        if session is None:
            return
        if not session.attached or not session.agent_online:
            return
        try:
            await session.send_json(payload)
        except Exception:
            self.sessions.pop(terminal_id, None)
            await self.close_remote_terminal(terminal_id, session.agent_id, reason='browser_send_failed')

    async def close_remote_terminal(self, terminal_id: str, agent_id: str, reason: str) -> None:
        live_agent = self.router.live_agents.get(agent_id)
        if live_agent is None:
            return
        if live_agent.supports('terminal.close', 'post'):
            try:
                await live_agent.send_json(TerminalCloseMessage(terminal_id=terminal_id, reason=reason).model_dump())
            except Exception:
                return

    async def request_terminal_list(
        self,
        *,
        agent_id: str,
        workspace_path: str,
        timeout: float = 5.0,
    ) -> TerminalListResponse:
        live_agent = self.router.live_agents.get(agent_id)
        if live_agent is None:
            raise RuntimeError(f"No live agent for selected client {agent_id}")
        if not live_agent.supports('terminal.list', 'post'):
            # If the client doesn't advertise terminal.list, return an empty list
            # rather than failing — older clients still work.
            return TerminalListResponse(workspace_path=workspace_path, sessions=[])

        normalized = _normalize_path(workspace_path)
        loop = asyncio.get_running_loop()
        future: asyncio.Future[TerminalListResponse] = loop.create_future()
        key = (agent_id, normalized)
        self._pending_list_requests.setdefault(key, []).append(future)
        try:
            await live_agent.send_json(
                TerminalListRequest(workspace_path=normalized).model_dump()
            )
            return await asyncio.wait_for(future, timeout=timeout)
        except (asyncio.TimeoutError, asyncio.CancelledError):
            # Make sure we don't leak a pending future
            waiters = self._pending_list_requests.get(key, [])
            if future in waiters:
                waiters.remove(future)
                if not waiters:
                    self._pending_list_requests.pop(key, None)
            # Best-effort: return empty list on timeout so the UI degrades gracefully
            return TerminalListResponse(workspace_path=normalized, sessions=[])

    async def handle_terminal_list_response(
        self, agent_id: str, message: TerminalListResponse
    ) -> None:
        normalized = _normalize_path(message.workspace_path)
        key = (agent_id, normalized)
        waiters = self._pending_list_requests.pop(key, [])
        for future in waiters:
            if not future.done():
                future.set_result(message)

    async def _hang_watchdog_tick(self) -> None:
        now = time.monotonic()
        for session in list(self.sessions.values()):
            if not session.agent_online:
                continue
            if session.last_activity == 0.0:
                continue
            if session.suspected_hang:
                continue
            if now - session.last_activity > self._watchdog_silence_threshold:
                session.suspected_hang = True
                if session.attached:
                    try:
                        await session.send_json(
                            TerminalStatusMessage(
                                terminal_id=session.terminal_id,
                                status='suspected_hang',
                            ).model_dump()
                        )
                    except Exception:
                        pass

    async def _hang_watchdog_loop(self) -> None:
        try:
            while True:
                await asyncio.sleep(self._watchdog_interval)
                await self._hang_watchdog_tick()
        except asyncio.CancelledError:
            raise

    def start_watchdog(self) -> None:
        if self._watchdog_task is None or self._watchdog_task.done():
            self._watchdog_task = asyncio.create_task(
                self._hang_watchdog_loop(), name='terminal-watchdog'
            )

    async def stop_watchdog(self) -> None:
        task = self._watchdog_task
        if task is None:
            return
        task.cancel()
        try:
            await task
        except asyncio.CancelledError:
            pass
        self._watchdog_task = None
