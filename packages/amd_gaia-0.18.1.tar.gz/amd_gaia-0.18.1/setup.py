# Copyright(C) 2025-2026 Advanced Micro Devices, Inc. All rights reserved.
# SPDX-License-Identifier: MIT

import re

from setuptools import setup

with open("src/gaia/version.py", encoding="utf-8") as fp:
    version_content = fp.read()
    version_match = re.search(r'__version__\s*=\s*["\']([^"\']+)["\']', version_content)
    if not version_match:
        raise ValueError("Unable to find version string in version.py")
    gaia_version = version_match.group(1)

tkml_version = "5.0.4"

setup(
    name="amd-gaia",
    version=gaia_version,
    description="GAIA is a lightweight agent framework designed for the edge and AI PCs.",
    author="AMD",
    url="https://github.com/amd/gaia",
    license="MIT",
    package_dir={"": "src"},
    packages=[
        "gaia",
        "gaia.llm",
        "gaia.llm.providers",
        "gaia.audio",
        "gaia.chat",
        "gaia.ui",
        "gaia.ui.routers",
        "gaia.database",
        "gaia.talk",
        "gaia.testing",
        "gaia.utils",
        "gaia.apps",
        "gaia.apps.docker",
        "gaia.apps.jira",
        "gaia.apps.llm",
        "gaia.apps.summarize",
        "gaia.apps.summarize.templates",
        "gaia.eval",
        "gaia.installer",
        "gaia.rag",
        "gaia.mcp",
        "gaia.mcp.client",
        "gaia.mcp.client.transports",
        "gaia.mcp.servers",
        "gaia.agents",
        "gaia.agents.base",
        "gaia.agents.tools",
        "gaia.agents.blender",
        "gaia.agents.blender.core",
        "gaia.agents.chat",
        "gaia.agents.chat.tools",
        "gaia.agents.builder",
        "gaia.agents.docker",
        "gaia.agents.emr",
        "gaia.agents.emr.dashboard",
        "gaia.agents.jira",
        "gaia.agents.code",
        "gaia.agents.code.orchestration",
        "gaia.agents.code.orchestration.factories",
        "gaia.agents.code.orchestration.steps",
        "gaia.agents.code.orchestration.workflows",
        "gaia.agents.code.prompts",
        "gaia.agents.code.tools",
        "gaia.agents.code.validators",
        "gaia.agents.code_index",
        "gaia.agents.code_index.tools",
        "gaia.agents.routing",
        "gaia.agents.sd",
        "gaia.agents.summarize",
        "gaia.governance",
        "gaia.sd",
        "gaia.vlm",
        "gaia.api",
        "gaia.filesystem",
        "gaia.scratchpad",
        "gaia.web",
        "gaia.code_index",
        "gaia.apps.webui",
        "gaia.connectors",
        "gaia.connectors.catalog",
        "gaia.connectors.providers",
        "gaia.agents.connectors_demo",
        "gaia.agents.email",
        "gaia.agents.email.tools",
    ],
    package_data={
        "gaia.eval": [
            "webapp/*.json",
            "webapp/*.js",
            "webapp/*.md",
            "webapp/public/*.html",
            "webapp/public/*.css",
            "webapp/public/*.js",
        ],
        # Browser-mode Agent UI bundle. Recursive globs in package_data are
        # unreliable across setuptools versions, so we list shallow patterns
        # here and back them up with `recursive-include` in MANIFEST.in. The
        # CI verifier (util/verify_wheel_dist.py) enforces that the wheel
        # actually contains these entries before publish.
        "gaia.apps.webui": [
            "dist/index.html",
            "dist/*.svg",
            "dist/*.png",
            "dist/*.ico",
            "dist/*.webmanifest",
            "dist/*.json",
            "dist/*.txt",
            "dist/assets/*",
        ],
    },
    install_requires=[
        "openai",
        "pydantic>=2.9.2",
        "transformers",
        "accelerate",
        "python-dotenv",
        "aiohttp",
        "rich",
        "requests",
        "beautifulsoup4",
        "watchdog>=2.1.0",
        "pillow>=9.0.0",
    ],
    extras_require={
        "image": [
            "term-image>=0.7.0,<0.8",
        ],
        "api": [
            "fastapi>=0.115.0",
            "uvicorn>=0.32.0",
            "python-multipart>=0.0.9",
        ],
        "ui": [
            "fastapi>=0.115.0",
            "uvicorn>=0.32.0",
            "python-multipart>=0.0.9",
            "httpx>=0.27.0",
            "psutil>=5.9.0",
            # OAuth connections (issue #915): keyring stores refresh tokens in
            # the OS credential store (macOS Keychain, Windows DPAPI, Linux
            # SecretService). Pinned upper bound per supply-chain advisory.
            "keyring>=24.0.0,<26.0.0",
            # RAG runtime deps — gaia.ui.server boots faiss + sentence_transformers
            # eagerly, and gaia.rag.sdk uses pypdf/pymupdf/numpy. See #845.
            # Version specifiers match the standalone "rag" extra; "ui"
            # additionally declares safetensors and a torch lower bound.
            "faiss-cpu>=1.7.0",
            "numpy>=1.24.0",
            "pymupdf>=1.24.0",
            "pypdf",
            "sentence-transformers",
            "safetensors",
            # torch is pinned lower-bound only. The "audio" extra caps
            # torch<2.4 because torchvision<0.19 / torchaudio require it,
            # but "ui" ships neither — capping here would force resolver
            # downgrades for users with torch 2.5+ already installed.
            "torch>=2.0.0",
        ],
        "audio": [
            "torch>=2.0.0,<2.4",
            "torchvision<0.19.0",
            "torchaudio",
        ],
        "blender": [
            "bpy",
        ],
        "mcp": [
            "mcp>=1.1.0",
            "starlette",
            "uvicorn",
        ],
        "telegram": [
            "python-telegram-bot>=20.3",
        ],
        "dev": [
            "pytest",
            "pytest-benchmark",
            "pytest-mock",
            "pytest-asyncio",
            "pyfakefs",
            "memory_profiler",
            "matplotlib",
            "adjustText",
            "plotly",
            "black",
            "pylint",
            "isort",
            "flake8",
            "autoflake",
            "mypy",
            "bandit",
            "responses",
            "requests",
            # gaia.connectors runtime deps surfaced in [dev] so that
            # `pip install -e ".[dev]"` is sufficient to run the unit suite
            # without pulling in the much heavier [ui] extra (faiss, torch).
            "httpx>=0.27.0,<0.29.0",
            "respx>=0.21.0,<0.23.0",
            "keyring>=24.0.0,<26.0.0",
        ],
        "eval": [
            "anthropic",
            "bs4",
            "scikit-learn>=1.5.0",
            "numpy>=2.0,<2.3.0",
            "pypdf",
            "reportlab",
        ],
        "talk": [
            "sounddevice",
            "openai-whisper",
            "kokoro>=0.3.1",
            "soundfile",
            "psutil",
            "pip",  # Required: spacy model download needs pip in venv (uv omits it)
        ],
        "youtube": [
            "llama-index-readers-youtube-transcript",
        ],
        "rag": [
            "faiss-cpu>=1.7.0",
            "numpy>=1.24.0",
            "pymupdf>=1.24.0",
            "pypdf",
            "sentence-transformers",
        ],
        "lint": [
            "black",
            "pylint",
            "isort",
            "flake8",
            "autoflake",
            "mypy",
            "bandit",
        ],
    },
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
    ],
    entry_points={
        "console_scripts": [
            "gaia = gaia.cli:main",
            "gaia-cli = gaia.cli:main",
            "gaia-mcp = gaia.mcp.mcp_bridge:main",
            "gaia-emr = gaia.agents.emr.cli:main",
            "gaia-code = gaia.agents.code.cli:main",
        ]
    },
    python_requires=">=3.10",
    long_description=open("README.md", "r", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    include_package_data=True,
)
