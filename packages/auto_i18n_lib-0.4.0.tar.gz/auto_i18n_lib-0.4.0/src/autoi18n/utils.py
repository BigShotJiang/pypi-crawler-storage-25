import json
import os
import re
import tempfile
from typing import Any, Dict, List, Tuple


WHITESPACE_ONLY_RE = re.compile(r"^\s*$")
NUMBER_LIKE_RE = re.compile(r"^[\d\s\.,:/\-]+$")
HEX_LIKE_RE = re.compile(r"^[A-Fa-f0-9\-]{8,}$")
PURE_LATIN_TECH_RE = re.compile(r"^[A-Za-z0-9_\-\s\.:/@#%+=]+$")

UI_KEY_PREFIX = "ui::"
PENDING_FILENAME = "_pending.json"


def split_preserve_whitespace(text: str) -> Tuple[str, str, str]:
    match = re.match(r"^(\s*)(.*?)(\s*)$", text, flags=re.DOTALL)
    if not match:
        return "", text, ""
    return match.group(1), match.group(2), match.group(3)


def should_translate(text: str, attr_name: str = None) -> bool:
    if text is None:
        return False

    raw = text
    text = text.strip()

    if not text:
        return False

    if WHITESPACE_ONLY_RE.fullmatch(raw):
        return False

    if text.isdigit():
        return False

    if NUMBER_LIKE_RE.fullmatch(text):
        return False

    if HEX_LIKE_RE.fullmatch(text):
        return False

    if PURE_LATIN_TECH_RE.fullmatch(text):
        if attr_name in {"placeholder", "title", "alt", "aria-label", "value"}:
            words = text.split()
            if len(words) >= 2:
                return True
        return False

    return True


def should_translate_ui_text(text: str) -> bool:
    if text is None:
        return False

    raw = str(text)
    text = raw.strip()

    if not text:
        return False

    if WHITESPACE_ONLY_RE.fullmatch(raw):
        return False

    if text.isdigit():
        return False

    if NUMBER_LIKE_RE.fullmatch(text):
        return False

    if HEX_LIKE_RE.fullmatch(text):
        return False

    return True


def normalize_lang(lang: str, source_lang: str = "ru") -> str:
    if not lang:
        return source_lang

    lang = str(lang).strip().lower().replace("_", "-")
    if not lang:
        return source_lang

    return lang


def build_lang_chain(target_lang: str, source_lang: str) -> List[str]:
    target_lang = normalize_lang(target_lang, source_lang=source_lang)
    source_lang = normalize_lang(source_lang, source_lang=source_lang)

    chain: List[str] = []

    def add(item: str) -> None:
        if item and item not in chain:
            chain.append(item)

    add(target_lang)

    if "-" in target_lang:
        add(target_lang.split("-")[0])

    add(source_lang)

    return chain


def safe_json_load(path: str) -> Dict[str, Any]:
    if not os.path.exists(path):
        return {}
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def safe_json_save(path: str, data: Dict[str, Any]) -> None:
    directory = os.path.dirname(path) or "."
    os.makedirs(directory, exist_ok=True)

    fd, tmp_path = tempfile.mkstemp(
        prefix=".tmp_autoi18n_",
        suffix=".json",
        dir=directory,
    )
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2, sort_keys=True)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp_path, path)
    finally:
        if os.path.exists(tmp_path):
            try:
                os.remove(tmp_path)
            except OSError:
                pass


def extract_json(text: str):
    text = text.strip()
    if not text:
        raise ValueError("Empty model response")

    try:
        return json.loads(text)
    except Exception:
        pass

    start_obj = text.find("{")
    end_obj = text.rfind("}")
    if start_obj != -1 and end_obj != -1 and end_obj > start_obj:
        candidate = text[start_obj:end_obj + 1]
        try:
            return json.loads(candidate)
        except Exception:
            pass

    start_arr = text.find("[")
    end_arr = text.rfind("]")
    if start_arr != -1 and end_arr != -1 and end_arr > start_arr:
        candidate = text[start_arr:end_arr + 1]
        return json.loads(candidate)

    raise ValueError("JSON not found in model response")


def deep_copy_json_like(value: Any) -> Any:
    return json.loads(json.dumps(value, ensure_ascii=False))


def compose_ui_storage_key(page_name: str, dict_name: str, leaf_key: str) -> str:
    safe_page = str(page_name or "page").strip() or "page"
    safe_dict = str(dict_name or "ui").strip() or "ui"
    safe_leaf = str(leaf_key or "root").strip() or "root"
    return f"{UI_KEY_PREFIX}{safe_page}::{safe_dict}::{safe_leaf}"


def join_leaf_path(parts: List[str]) -> str:
    return ".".join(parts) if parts else "root"