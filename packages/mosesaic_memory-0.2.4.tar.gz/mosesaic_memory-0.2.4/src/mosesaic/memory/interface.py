from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any


@dataclass
class MemoryEntry:
    """A single item in short-term (conversation) memory."""
    role: str    # "system" | "user" | "assistant"
    content: str
    timestamp: datetime = field(default_factory=lambda: datetime.now(timezone.utc))


@dataclass
class SearchResult:
    """A single result from long-term memory semantic search."""
    content: str
    score: float          # similarity score 0–1
    metadata: dict = field(default_factory=dict)


class ShortTermMemory(ABC):
    """Conversation window — recent messages for the LLM context."""

    @abstractmethod
    def add(self, role: str, content: str) -> None:
        """Append a message to the conversation window."""

    @abstractmethod
    def messages(self) -> list[MemoryEntry]:
        """Return all messages in the current window (oldest first)."""

    @abstractmethod
    def clear(self) -> None:
        """Clear all messages."""

    @abstractmethod
    def token_count(self) -> int:
        """Approximate token count of the current window."""


class LongTermMemory(ABC):
    """Semantic vector store — search by meaning, not exact match."""

    @abstractmethod
    async def store(self, content: str, metadata: dict | None = None) -> str:
        """Store content and return its ID."""

    @abstractmethod
    async def search(self, query: str, top_k: int = 5) -> list[SearchResult]:
        """Return top_k most semantically similar stored items."""

    @abstractmethod
    async def delete(self, item_id: str) -> None:
        """Remove an item by ID."""


class WorkingMemory(ABC):
    """Key-value store — task state, locks, counters, short-lived data."""

    @abstractmethod
    async def set(self, key: str, value: Any, ttl: int | None = None) -> None:
        """Set a key. ttl in seconds; None = no expiry."""

    @abstractmethod
    async def get(self, key: str) -> Any | None:
        """Get a key's value. Returns None if not found or expired."""

    @abstractmethod
    async def delete(self, key: str) -> None:
        """Delete a key."""

    @abstractmethod
    async def cas(self, key: str, expected: Any, new_value: Any) -> bool:
        """Compare-and-swap. Returns True if swap succeeded."""

    @abstractmethod
    async def increment(self, key: str, delta: int = 1) -> int:
        """Atomically increment a numeric key. Returns new value."""
