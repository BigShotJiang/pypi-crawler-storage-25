from __future__ import annotations

from uuid import uuid4

from mosesaic.memory.interface import LongTermMemory, SearchResult


class InMemoryLongTermMemory(LongTermMemory):
    """In-process long-term memory with naive keyword similarity. Zero dependencies.

    Uses simple token overlap (Jaccard similarity) instead of real embeddings.
    Suitable for local dev and tests. For production, use QdrantLongTermMemory.

    Usage:
        mem = InMemoryLongTermMemory()
        await mem.store("Quantum computing uses qubits", metadata={"source": "wiki"})
        results = await mem.search("quantum qubits", top_k=3)
    """

    def __init__(self) -> None:
        # id → (content, metadata)
        self._store: dict[str, tuple[str, dict]] = {}

    @staticmethod
    def _tokenize(text: str) -> set[str]:
        return set(text.lower().split())

    @staticmethod
    def _jaccard(a: set[str], b: set[str]) -> float:
        if not a and not b:
            return 1.0
        intersection = len(a & b)
        union = len(a | b)
        return intersection / union if union else 0.0

    async def store(self, content: str, metadata: dict | None = None) -> str:
        item_id = str(uuid4())
        self._store[item_id] = (content, metadata or {})
        return item_id

    async def search(self, query: str, top_k: int = 5) -> list[SearchResult]:
        query_tokens = self._tokenize(query)
        scored = []
        for item_id, (content, meta) in self._store.items():
            score = self._jaccard(query_tokens, self._tokenize(content))
            scored.append(SearchResult(content=content, score=score, metadata=meta))
        scored.sort(key=lambda r: r.score, reverse=True)
        return scored[:top_k]

    async def delete(self, item_id: str) -> None:
        self._store.pop(item_id, None)
