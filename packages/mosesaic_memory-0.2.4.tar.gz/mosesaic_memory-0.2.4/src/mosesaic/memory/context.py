from __future__ import annotations

from mosesaic.memory.interface import LongTermMemory, ShortTermMemory, WorkingMemory


class MemoryContext:
    """The ``ctx.memory`` interface available to agents.

    Provides three-tier memory with a single unified interface.
    Agent code never imports DB drivers or memory adapters directly.

    Usage (inside an agent):
        # Short-term: conversation window
        ctx.memory.short.add("user", "What is 2+2?")
        messages = ctx.memory.short.messages()

        # Working: task state, counters, locks
        await ctx.memory.working.set("step", 1, ttl=3600)
        step = await ctx.memory.working.get("step")
        swapped = await ctx.memory.working.cas("lock", expected=None, new_value="agent-a")

        # Long-term: semantic recall
        await ctx.memory.long.store("Quantum computers use qubits", {"source": "wiki"})
        results = await ctx.memory.long.search("quantum computing", top_k=5)
    """

    def __init__(
        self,
        short: ShortTermMemory,
        working: WorkingMemory,
        long: LongTermMemory,
    ) -> None:
        self.short = short
        self.working = working
        self.long = long
