from __future__ import annotations

import time
from typing import Any

from mosesaic.memory.interface import WorkingMemory


class InMemoryWorkingMemory(WorkingMemory):
    """In-process KV store with TTL and CAS. Zero dependencies.

    Suitable for local development and single-process agents.
    For multi-process/distributed use, swap with ValkeyWorkingMemory.

    Usage:
        mem = InMemoryWorkingMemory()
        await mem.set("task_state", {"step": 1}, ttl=3600)
        state = await mem.get("task_state")
        swapped = await mem.cas("counter", expected=0, new_value=1)
    """

    def __init__(self) -> None:
        # key → (value, expires_at or None)
        self._store: dict[str, tuple[Any, float | None]] = {}

    def _is_expired(self, expires_at: float | None) -> bool:
        return expires_at is not None and time.monotonic() > expires_at

    async def set(self, key: str, value: Any, ttl: int | None = None) -> None:
        expires_at = (time.monotonic() + ttl) if ttl is not None else None
        self._store[key] = (value, expires_at)

    async def get(self, key: str) -> Any | None:
        entry = self._store.get(key)
        if entry is None:
            return None
        value, expires_at = entry
        if self._is_expired(expires_at):
            del self._store[key]
            return None
        return value

    async def delete(self, key: str) -> None:
        self._store.pop(key, None)

    async def cas(self, key: str, expected: Any, new_value: Any) -> bool:
        """Atomic compare-and-swap. Returns True if the swap succeeded."""
        current = await self.get(key)
        if current != expected:
            return False
        # Preserve existing TTL on swap
        existing = self._store.get(key)
        expires_at = existing[1] if existing else None
        self._store[key] = (new_value, expires_at)
        return True

    async def increment(self, key: str, delta: int = 1) -> int:
        current = await self.get(key) or 0
        new_val = int(current) + delta
        existing = self._store.get(key)
        expires_at = existing[1] if existing else None
        self._store[key] = (new_val, expires_at)
        return new_val
