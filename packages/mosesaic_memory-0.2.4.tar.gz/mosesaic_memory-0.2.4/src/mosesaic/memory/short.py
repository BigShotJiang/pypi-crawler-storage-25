from __future__ import annotations

from collections import deque

from mosesaic.memory.interface import MemoryEntry, ShortTermMemory

# Rough token estimate: 4 chars ≈ 1 token
_CHARS_PER_TOKEN = 4


class InProcessShortTermMemory(ShortTermMemory):
    """In-process conversation window backed by a deque.

    Automatically evicts oldest messages when the token limit is exceeded.
    Zero dependencies — works everywhere.

    Usage:
        mem = InProcessShortTermMemory(max_tokens=4000)
        mem.add("user", "What is quantum computing?")
        mem.add("assistant", "It's a type of computing that...")
        messages = mem.messages()  # → [MemoryEntry, MemoryEntry]
    """

    def __init__(self, max_tokens: int = 4000) -> None:
        self._max_tokens = max_tokens
        self._entries: deque[MemoryEntry] = deque()
        self._total_chars: int = 0

    def add(self, role: str, content: str) -> None:
        """Add a message, evicting oldest if over the token limit."""
        entry = MemoryEntry(role=role, content=content)
        chars = len(content)
        self._entries.append(entry)
        self._total_chars += chars
        # Evict from the front until we're under limit
        while self._total_chars > self._max_tokens * _CHARS_PER_TOKEN and len(self._entries) > 1:
            evicted = self._entries.popleft()
            self._total_chars -= len(evicted.content)

    def messages(self) -> list[MemoryEntry]:
        return list(self._entries)

    def clear(self) -> None:
        self._entries.clear()
        self._total_chars = 0

    def token_count(self) -> int:
        return self._total_chars // _CHARS_PER_TOKEN
