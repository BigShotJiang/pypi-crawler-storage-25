"""Tests for InMemoryLongTermMemory."""
import pytest

from mosesaic.memory.long import InMemoryLongTermMemory


@pytest.mark.anyio
async def test_store_and_search():
    mem = InMemoryLongTermMemory()
    await mem.store("Quantum computing uses qubits and superposition")
    await mem.store("Classical computers use binary bits")
    results = await mem.search("quantum qubits", top_k=2)
    assert len(results) == 2
    assert results[0].content.startswith("Quantum")  # most relevant first


@pytest.mark.anyio
async def test_search_returns_scores():
    mem = InMemoryLongTermMemory()
    await mem.store("cats and dogs are pets")
    results = await mem.search("cats dogs")
    assert results[0].score > 0


@pytest.mark.anyio
async def test_search_respects_top_k():
    mem = InMemoryLongTermMemory()
    for i in range(10):
        await mem.store(f"document {i} about topic")
    results = await mem.search("topic", top_k=3)
    assert len(results) == 3


@pytest.mark.anyio
async def test_delete():
    mem = InMemoryLongTermMemory()
    item_id = await mem.store("to be deleted")
    await mem.delete(item_id)
    results = await mem.search("deleted")
    assert all(r.content != "to be deleted" for r in results)


@pytest.mark.anyio
async def test_store_with_metadata():
    mem = InMemoryLongTermMemory()
    await mem.store("research paper about AI", metadata={"source": "arxiv", "year": 2026})
    results = await mem.search("AI research")
    assert results[0].metadata["source"] == "arxiv"


@pytest.mark.anyio
async def test_empty_store_returns_empty():
    mem = InMemoryLongTermMemory()
    results = await mem.search("anything")
    assert results == []
