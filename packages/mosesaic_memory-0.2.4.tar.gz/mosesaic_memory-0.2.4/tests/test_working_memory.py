"""Tests for InMemoryWorkingMemory."""
import asyncio
import pytest

from mosesaic.memory.working import InMemoryWorkingMemory


@pytest.mark.anyio
async def test_set_and_get():
    mem = InMemoryWorkingMemory()
    await mem.set("key", "value")
    assert await mem.get("key") == "value"


@pytest.mark.anyio
async def test_get_missing_returns_none():
    mem = InMemoryWorkingMemory()
    assert await mem.get("nonexistent") is None


@pytest.mark.anyio
async def test_delete():
    mem = InMemoryWorkingMemory()
    await mem.set("k", "v")
    await mem.delete("k")
    assert await mem.get("k") is None


@pytest.mark.anyio
async def test_ttl_expiry(monkeypatch):
    import time as time_module
    mem = InMemoryWorkingMemory()
    await mem.set("k", "v", ttl=1)
    # Monkeypatch monotonic to simulate expiry
    original = time_module.monotonic
    monkeypatch.setattr(time_module, "monotonic", lambda: original() + 2)
    assert await mem.get("k") is None


@pytest.mark.anyio
async def test_cas_success():
    mem = InMemoryWorkingMemory()
    await mem.set("counter", 0)
    swapped = await mem.cas("counter", expected=0, new_value=1)
    assert swapped is True
    assert await mem.get("counter") == 1


@pytest.mark.anyio
async def test_cas_failure_wrong_expected():
    mem = InMemoryWorkingMemory()
    await mem.set("counter", 5)
    swapped = await mem.cas("counter", expected=0, new_value=1)
    assert swapped is False
    assert await mem.get("counter") == 5


@pytest.mark.anyio
async def test_increment():
    mem = InMemoryWorkingMemory()
    v1 = await mem.increment("hits")
    v2 = await mem.increment("hits")
    v3 = await mem.increment("hits", delta=10)
    assert v1 == 1
    assert v2 == 2
    assert v3 == 12


@pytest.mark.anyio
async def test_set_any_type():
    mem = InMemoryWorkingMemory()
    await mem.set("data", {"nested": [1, 2, 3]})
    assert await mem.get("data") == {"nested": [1, 2, 3]}
