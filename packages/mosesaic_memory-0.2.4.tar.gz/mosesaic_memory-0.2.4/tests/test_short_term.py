"""Tests for InProcessShortTermMemory."""
from mosesaic.memory.short import InProcessShortTermMemory


def test_add_and_retrieve():
    mem = InProcessShortTermMemory()
    mem.add("user", "Hello")
    mem.add("assistant", "Hi there")
    msgs = mem.messages()
    assert len(msgs) == 2
    assert msgs[0].role == "user"
    assert msgs[0].content == "Hello"
    assert msgs[1].role == "assistant"


def test_clear():
    mem = InProcessShortTermMemory()
    mem.add("user", "x")
    mem.clear()
    assert mem.messages() == []
    assert mem.token_count() == 0


def test_token_count_approximate():
    mem = InProcessShortTermMemory()
    mem.add("user", "a" * 400)  # ~100 tokens
    assert mem.token_count() == 100


def test_evicts_oldest_when_over_limit():
    # max_tokens=10 → max ~40 chars
    mem = InProcessShortTermMemory(max_tokens=10)
    mem.add("user", "a" * 20)   # 20 chars — fits
    mem.add("user", "b" * 20)   # 40 chars total — fits at limit
    mem.add("user", "c" * 20)   # 60 chars — must evict first
    messages = mem.messages()
    # First message should be evicted
    contents = [m.content for m in messages]
    assert "a" * 20 not in contents
    assert "c" * 20 in contents


def test_always_keeps_at_least_one_message():
    """Even a single massive message should not be evicted below 1."""
    mem = InProcessShortTermMemory(max_tokens=1)
    mem.add("user", "x" * 10000)
    assert len(mem.messages()) == 1
