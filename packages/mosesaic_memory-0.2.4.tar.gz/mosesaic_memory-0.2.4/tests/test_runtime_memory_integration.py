"""Integration: AgentRuntime with memory wired through ctx.memory."""
import anyio
import pytest

from mosesaic.core.agent import agent
from mosesaic.core.context import AgentContext
from mosesaic.core.runtime import AgentRuntime
from mosesaic.memory.context import MemoryContext
from mosesaic.memory.long import InMemoryLongTermMemory
from mosesaic.memory.short import InProcessShortTermMemory
from mosesaic.memory.working import InMemoryWorkingMemory


def make_memory() -> MemoryContext:
    return MemoryContext(
        short=InProcessShortTermMemory(),
        working=InMemoryWorkingMemory(),
        long=InMemoryLongTermMemory(),
    )


@pytest.mark.anyio
async def test_agent_uses_short_term_memory():
    stored = []

    @agent(name="mem-agent")
    async def mem_agent(ctx: AgentContext) -> None:
        msg = await ctx.receive()
        ctx.memory.short.add("user", msg.payload)
        ctx.memory.short.add("assistant", "acknowledged")
        stored.extend(ctx.memory.short.messages())

    runtime = AgentRuntime(memory=make_memory())
    runtime.register(mem_agent)

    async with runtime.run():
        await runtime.send("mem-agent", payload="hello memory")
        await anyio.sleep(0.1)

    assert len(stored) == 2
    assert stored[0].content == "hello memory"


@pytest.mark.anyio
async def test_agent_uses_working_memory():
    results = []

    @agent(name="kv-agent")
    async def kv_agent(ctx: AgentContext) -> None:
        await ctx.receive()
        await ctx.memory.working.set("step", 42)
        val = await ctx.memory.working.get("step")
        results.append(val)

    runtime = AgentRuntime(memory=make_memory())
    runtime.register(kv_agent)

    async with runtime.run():
        await runtime.send("kv-agent", payload="go")
        await anyio.sleep(0.1)

    assert results == [42]


@pytest.mark.anyio
async def test_agent_uses_long_term_memory():
    results = []

    @agent(name="search-agent")
    async def search_agent(ctx: AgentContext) -> None:
        await ctx.receive()
        await ctx.memory.long.store("Python is a programming language")
        hits = await ctx.memory.long.search("Python programming", top_k=1)
        results.extend(hits)

    runtime = AgentRuntime(memory=make_memory())
    runtime.register(search_agent)

    async with runtime.run():
        await runtime.send("search-agent", payload="go")
        await anyio.sleep(0.1)

    assert len(results) == 1
    assert "Python" in results[0].content


@pytest.mark.anyio
async def test_ctx_memory_raises_without_registry():
    accessed = []

    @agent(name="no-memory")
    async def no_memory(ctx: AgentContext) -> None:
        await ctx.receive()
        try:
            _ = ctx.memory
        except RuntimeError as e:
            accessed.append(str(e))

    runtime = AgentRuntime()  # no memory
    runtime.register(no_memory)

    async with runtime.run():
        await runtime.send("no-memory", payload="go")
        await anyio.sleep(0.1)

    assert any("No memory" in msg for msg in accessed)
