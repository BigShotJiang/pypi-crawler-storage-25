from setuptools import setup, find_packages

setup(
    name='zyz_utils_yuzhuzhou',
    version='0.1.0',
    packages=find_packages(),
    description='A collection of utility functions by Yuzhu Zhou',
    long_description=open('README.md', encoding='utf-8').read(),
    long_description_content_type='text/markdown',
    author='Yuzhu Zhou',
    author_email='yuzhuzhou@example.com',
    install_requires=[
        'numpy',
    ],
    classifiers=[
        'Programming Language :: Python :: 3',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
    ],
    python_requires='>=3.6',
)
