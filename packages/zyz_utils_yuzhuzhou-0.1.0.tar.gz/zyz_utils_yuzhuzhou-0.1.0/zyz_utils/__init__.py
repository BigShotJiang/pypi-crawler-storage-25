from .function import getAllFiles

__all__ = ['getAllFiles']
