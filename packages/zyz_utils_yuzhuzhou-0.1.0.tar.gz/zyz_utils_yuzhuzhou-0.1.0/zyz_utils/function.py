import numpy as np
import os


'''-------------------------------
@func	: getAllFiles
@Time	: 2023/07/11 08:48:43
@Author : Yuzhu Zhou
@explain : Obtain all files in the current directory
@input : targetDir：Path directory
@output : listFiles： File list
-------------------------------'''
def getAllFiles(targetDir):
    listFiles = os.listdir(targetDir)
    return listFiles

