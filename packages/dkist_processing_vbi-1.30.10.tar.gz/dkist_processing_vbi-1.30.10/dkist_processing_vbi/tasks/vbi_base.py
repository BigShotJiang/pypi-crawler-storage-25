"""VBI base task."""

from abc import ABC

from dkist_processing_common.codecs.basemodel import basemodel_encoder
from dkist_processing_common.models.metric_code import MetricCode
from dkist_processing_common.models.quality import TaskCount
from dkist_processing_common.tasks import WorkflowTaskBase

from dkist_processing_vbi.models.constants import VbiConstants
from dkist_processing_vbi.models.tags import VbiTag


class VbiTaskBase(WorkflowTaskBase, ABC):
    """
    Task class for base VBI tasks.

    Parameters
    ----------
    recipe_run_id : int
        id of the recipe run used to identify the workflow run this task is part of
    workflow_name : str
        name of the workflow to which this instance of the task belongs
    workflow_version : str
        version of the workflow to which this instance of the task belongs

    """

    # So tab completion shows all the ViSP constants
    constants: VbiConstants

    @property
    def constants_model_class(self):
        """Provide VBI constants access."""
        return VbiConstants

    def quality_write_intermediate_task_type_counts(
        self, task_type: str, total_frames: int, frames_not_used: int = 0
    ):
        """
        Write intermediate task type data.

        Parameters
        ----------
        task_type:
        task type as listed in the headers
        total_frames:
        total number of frames supplied of the given task type
        frames_not_used:
        if some frames aren't used, how many
        """
        task_count = TaskCount(
            task_type=task_type,
            total_frames=total_frames,
            frames_not_used=frames_not_used,
        )
        self.write(
            task_count, tags=VbiTag.quality(MetricCode.task_types), encoder=basemodel_encoder
        )
