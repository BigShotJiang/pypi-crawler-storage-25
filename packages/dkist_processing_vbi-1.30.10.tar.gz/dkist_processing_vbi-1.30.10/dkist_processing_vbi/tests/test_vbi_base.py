import pytest
from dkist_processing_common.codecs.basemodel import basemodel_decoder
from dkist_processing_common.models.quality import TaskCount

from dkist_processing_vbi.tasks.vbi_base import VbiTaskBase


@pytest.fixture
def expected_constants_dict():
    # Just make up a super simple db
    return {"NUM_SPATIAL_STEPS": 4, "OBS_IP_START_TIME": "2022-11-28T13:54:00"}


@pytest.fixture(scope="function")
def vbi_science_task(recipe_run_id, expected_constants_dict):
    class DummyTask(VbiTaskBase):
        def run(self):
            pass

    task = DummyTask(
        recipe_run_id=recipe_run_id,
        workflow_name="vbi_dummy_task",
        workflow_version="VX.Y",
    )

    task.constants._update(expected_constants_dict)
    yield task
    task._purge()


@pytest.fixture(scope="function")
def vbi_base_task(recipe_run_id):
    class DummyTask(VbiTaskBase):
        def run(self):
            pass

    task = DummyTask(
        recipe_run_id=recipe_run_id,
        workflow_name="vbi_dummy_task",
        workflow_version="VX.Y",
    )

    yield task
    task._purge()


def test_constants_init(vbi_science_task, expected_constants_dict):
    """
    Given: A VbiTaskBase with a populated backend ConstantsDb
    When: Initializing the task
    Then: The .constants attribute is loaded correctly
    """
    constants_obj = vbi_science_task.constants
    for k, v in expected_constants_dict.items():
        assert getattr(constants_obj, k.lower()) == v


@pytest.mark.parametrize(
    "task_type, total_frames, frames_not_used",
    [
        pytest.param("one", 1, 1, id="simple"),
        pytest.param("two", 2, 0, id="not_used_zero"),
        pytest.param("three", 3, None, id="not_used_none"),
    ],
)
def test_quality_write_intermediate_task_type_counts(
    task_type: str, total_frames: int, frames_not_used: int | None, vbi_base_task
):
    """
    Given: Valid intermediate task type count input
    When: Running VbiTaskBase quality_write_intermediate_task_type_counts()
    Then: A single TaskCount file gets created
    """
    # Given
    task = vbi_base_task

    # When
    if frames_not_used is not None:
        task.quality_write_intermediate_task_type_counts(task_type, total_frames, frames_not_used)
    else:
        task.quality_write_intermediate_task_type_counts(task_type, total_frames)

    # Then
    task_counts: list[TaskCount] = list(
        task.read(tags="QUALITY_TASK_TYPES", decoder=basemodel_decoder, model=TaskCount)
    )
    assert isinstance(task_counts, list)
    assert len(task_counts) == 1
    task_count = task_counts[0]
    assert task_count.task_type == str(task_type).upper()
    assert task_count.total_frames == total_frames
    if frames_not_used is not None:
        assert task_count.frames_not_used == frames_not_used
    else:
        assert task_count.frames_not_used == 0
