# coding = utf-8
# Arch   = manyArch
#
# @File name:       pycstructdataparser_lib.py
# @brief:           Entry module for pycstructdataparser-lib package.
#                   Re-exports public API from cstruct_parser.
# @attention:       None
# @Author:          NGC13009
# @History:         2026-05-07		Create

from cstruct_parser import CStructParser, pack, unpack

__version__ = "v1.0.0"
__compiler_date__ = "2026-05-07"

__all__ = [
    "CStructParser",
    "pack",
    "unpack",
]