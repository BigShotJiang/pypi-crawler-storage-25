# coding = utf-8
# Arch   = manyArch
#
# @File name:       cstruct_parser.py
# @brief:           C/C++ header struct parser, supports ctypes dynamic class generation.
#                   Provides CStructParser for parsing C header files and dynamically creating
#                   ctypes.Structure subclasses, along with binary serialization/deserialization
#                   pack/unpack functions.
# @attention:       None
# @Author:          NGC13009
# @History:         2026-05-07		Create

import re
import ctypes
from typing import Any, Dict, List, Optional, Tuple

from ctype_map_def import TYPE_MAP


# Recursive conversion helper (dict ↔ ctypes.Structure)
def _struct_to_dict(obj: Any) -> Any:
    """Recursively convert a ctypes Structure / Array into a plain Python
    dict / list, converting ctypes simple types to their Python equivalents."""
    if isinstance(obj, ctypes.Structure):
        result: Dict[str, Any] = {}
        for f in obj._fields_:
            field_name = f[0]
            value = getattr(obj, field_name)
            result[field_name] = _struct_to_dict(value)
        return result
    elif isinstance(obj, ctypes.Array):
        return [_struct_to_dict(obj[i]) for i in range(len(obj))]
    else:
        # ctypes simple type (c_ubyte, c_int, c_float …) → Python int/float
        if hasattr(obj, 'value'):
            return obj.value
        return obj


def _dict_to_struct(obj: ctypes.Structure, data: Dict[str, Any], strict: bool = True) -> None:
    """Recursively fill a ctypes Structure from a plain Python dict.

    When *strict* is True, a ``ValueError`` is raised if *data* is missing
    a **non-bitfield** key. Bitfield fields are always optional (default to 0).
    When *strict* is False, all missing keys silently default to 0.
    """
    # Pre-compute bitfield names so strict mode can exclude them
    bitfield_names: set = set()
    for f in obj._fields_:
        if len(f) == 3: # (name, type, width)
            bitfield_names.add(f[0])

    for f in obj._fields_:
        field_name = f[0]
        is_bitfield = len(f) == 3

        if field_name in data:
            value = data[field_name]
            target = getattr(obj, field_name)

            if isinstance(target, ctypes.Structure):
                _dict_to_struct(target, value, strict)
            elif isinstance(target, ctypes.Array):
                for i, item in enumerate(value):
                    elem = target[i]
                    if isinstance(elem, ctypes.Structure):
                        _dict_to_struct(elem, item, strict)
                    else:
                        target[i] = item
            else:
                setattr(obj, field_name, value)

        elif strict and not is_bitfield:
            raise ValueError(f"Missing required field '{field_name}' in data dictionary")
        # Otherwise: non-strict mode or bitfield → keep default value (0)


# C struct parser


class CStructParser:
    """Parse C/C++ header file content and dynamically generate
    :class:`ctypes.Structure` subclasses.

    Typical usage::

        parser = CStructParser()
        parser.parse(header_string)
        cls = parser.get_struct_class('BBBtype')
        obj = cls.from_buffer_copy(raw_bytes)
    """

    def __init__(self) -> None:
        self._struct_classes: Dict[str, type] = {}
        self._parsed: bool = False

    # User-facing API
    @property
    def struct_classes(self) -> Dict[str, type]:
        """Return a shallow copy of all registered struct classes."""
        return dict(self._struct_classes)

    def parse(self, header_content: str) -> None:
        """Parse *header_content* and create all discovered struct classes.

        The parser supports:

        * C-style comments (``//`` and ``/* … */``)
        * ``#pragma pack(push, n)`` / ``#pragma pack(pop)``
        * ``typedef struct { … } Name;`` blocks
        * Basic types, arrays, bitfields, and nested (named) structs

        Args:
            header_content: The complete C/C++ header file content string.

        Raises:
            ValueError: If an unknown type is referenced.
        """
        # 1.  Remove comments
        content = self._remove_comments(header_content)

        # 2.  Extract struct bodies and their pack alignment values
        definitions = self._extract_definitions(content)

        # 3.  First pass — create empty class *shells*, so forward references
        #     (struct A used by struct B) resolve correctly.
        for name in definitions:
            self._struct_classes[name] = type(name, (ctypes.Structure, ), {})

        # 4.  Second pass — populate ``_pack_`` and ``_fields_`` for each class.
        for name, (body, pack_val) in definitions.items():
            fields = self._parse_fields(body)
            cls = self._struct_classes[name]
            cls._pack_ = pack_val # must be set before _fields_
            cls._fields_ = fields

        self._parsed = True

    def get_struct_class(self, name: str) -> type:
        """Return the :class:`ctypes.Structure` subclass corresponding to *name*.

        Args:
            name: The struct type name (e.g. ``'BBBtype'``).

        Returns:
            A :class:`ctypes.Structure` subclass.

        Raises:
            ValueError: If *name* is not a known struct.
        """
        if name not in self._struct_classes:
            raise ValueError(f"Unknown struct: '{name}'. Known: {list(self._struct_classes.keys())}")
        return self._struct_classes[name]

    # Internal helpers

    @staticmethod
    def _remove_comments(content: str) -> str:
        """Remove C-style block comments and line comments."""
        # Block comments: /* … */  (non-greedy, DOTALL for multi-line)
        content = re.sub(r'/\*.*?\*/', '', content, flags=re.DOTALL)
        # Line comments: // … to end of line
        content = re.sub(r'//[^\n]*', '', content)
        return content

    @staticmethod
    def _extract_definitions(content: str) -> Dict[str, Tuple[str, int]]:
        """Scan *content* sequentially for ``#pragma pack`` directives and
        ``typedef struct { … } Name;`` blocks.

        Returns:
            ``{struct_name: (body_text, pack_value)}``
        """
        definitions: Dict[str, Tuple[str, int]] = {}
        pack_stack: List[int] = [8] # default alignment

        pragma_push_re = re.compile(r'#pragma\s+pack\s*\(\s*push\s*,\s*(\d+)\s*\)')
        pragma_pop_re = re.compile(r'#pragma\s+pack\s*\(\s*pop\s*\)')
        typedef_start_re = re.compile(r'typedef\s+struct(?:\s+\w+)?\s*\{')

        i = 0
        n = len(content)

        while i < n:
            # --- #pragma pack(push, N) ---
            m = pragma_push_re.match(content, i)
            if m:
                pack_stack.append(int(m.group(1)))
                i = m.end()
                continue

            # --- #pragma pack(pop) ---
            m = pragma_pop_re.match(content, i)
            if m:
                if len(pack_stack) > 1:
                    pack_stack.pop()
                i = m.end()
                continue

            # --- typedef struct { ---
            m = typedef_start_re.match(content, i)
            if m:
                # m.end() is right after '{' — start counting braces from here
                body_start = m.end()
                brace_count = 1
                j = body_start
                while j < n and brace_count > 0:
                    if content[j] == '{':
                        brace_count += 1
                    elif content[j] == '}':
                        brace_count -= 1
                    j += 1
                # j-1 is the position of the closing '}'
                body = content[body_start:j - 1]

                # Extract struct name:  } Name ;
                name_match = re.match(r'\s*(\w+)\s*;', content[j:])
                if name_match:
                    name = name_match.group(1)
                    definitions[name] = (body, pack_stack[-1])
                    i = j + name_match.end()
                else:
                    i = j
                continue

            i += 1

        return definitions

    def _parse_fields(self, body: str) -> List[Tuple]:
        """Parse field declarations inside a struct body.

        Returns a list of tuples suitable for ``_fields_``:

        * ``(name, ctype)`` — simple field
        * ``(name, ctype, width)`` — bitfield
        * ``(name, ctype * count)`` — array
        """
        fields: List[Tuple] = []

        # Split by semicolon; each piece is one declaration
        declarations = [d.strip() for d in body.split(';') if d.strip()]

        for decl in declarations:
            # Collapse all whitespace (including newlines) into single spaces
            normalized = ' '.join(decl.split())
            field = self._parse_single_field(normalized)
            if field is not None:
                fields.append(field)

        return fields

    def _parse_single_field(self, decl: str) -> Optional[Tuple]:
        """Parse a single **normalized** field declaration.

        Attempts to match in order: bitfield → array → simple field.
        Returns ``None`` for unnamed/unsupported declarations.
        """
        # 1) Bitfield:   type name : width
        m = re.match(r'^(.+?)\s+(\w+)\s*:\s*(\d+)$', decl)
        if m:
            type_name = m.group(1).strip()
            field_name = m.group(2)
            width = int(m.group(3))
            return (field_name, self._resolve_type(type_name), width)

        # 2) Array:   type name [ count ]
        m = re.match(r'^(.+?)\s+(\w+)\s*\[\s*(\d+)\s*\]$', decl)
        if m:
            type_name = m.group(1).strip()
            field_name = m.group(2)
            count = int(m.group(3))
            elem_type = self._resolve_type(type_name)
            return (field_name, elem_type * count)

        # 3) Simple:    type name
        m = re.match(r'^(.+?)\s+(\w+)$', decl)
        if m:
            type_name = m.group(1).strip()
            field_name = m.group(2)
            return (field_name, self._resolve_type(type_name))

        # Unnamed bitfield, padding, etc. — skip
        return None

    def _resolve_type(self, type_name: str) -> Any:
        """Map a C type name (string) to a ctypes type or struct class."""
        type_name = type_name.strip()

        # 1.  Built-in C types
        if type_name in TYPE_MAP:
            return TYPE_MAP[type_name]

        # 2.  Previously parsed / forward-declared struct
        if type_name in self._struct_classes:
            return self._struct_classes[type_name]

        raise ValueError(f"Unknown type: '{type_name}'")


# pack / unpack API


def unpack(parser: CStructParser, struct_name: str, data: bytes) -> Dict[str, Any]:
    """Deserialize *data* into a dictionary using the struct registered in *parser*.

    Args:
        parser: A :class:`CStructParser` that has had :meth:`parse` called.
        struct_name: The struct type name to use.
        data: Raw binary bytes.

    Returns:
        A nested dictionary representation of the deserialized data.
    """
    cls = parser.get_struct_class(struct_name)
    obj = cls.from_buffer_copy(data)
    return _struct_to_dict(obj)


def pack(parser: CStructParser, struct_name: str, data_dict: Dict[str, Any], strict: bool = True) -> bytes:
    """Serialize *data_dict* into raw bytes using the struct registered in *parser*.

    Args:
        parser: A :class:`CStructParser` that has had :meth:`parse` called.
        struct_name: The struct type name to use.
        data_dict: A dictionary whose keys correspond to struct field names.
        strict: If ``True`` (default), raises :class:`ValueError` when a
            **non-bitfield** key is missing. If ``False``, missing keys
            silently default to 0.

    Returns:
        Raw binary bytes.
    """
    cls = parser.get_struct_class(struct_name)
    obj = cls()
    _dict_to_struct(obj, data_dict, strict)
    return bytes(obj)
