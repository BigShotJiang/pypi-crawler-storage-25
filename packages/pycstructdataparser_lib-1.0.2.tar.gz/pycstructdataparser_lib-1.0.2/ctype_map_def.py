# coding = utf-8
# Arch   = manyArch
#
# @File name:       type_map_def.py
# @brief:           Type definition file for Python struct parser
# @attention:       None
# @Author:          NGC13009
# @History:         2026-05-07		Create

import ctypes
from typing import Any, Dict, List, Optional, Tuple

# Character types
_CHAR_TYPES = {
    'char': ctypes.c_byte,
    'signed char': ctypes.c_byte,
    'unsigned char': ctypes.c_ubyte,
}

# Integer types (short/int/long)
_INTEGER_TYPES = {
    'short': ctypes.c_short,
    'unsigned short': ctypes.c_ushort,
    'short int': ctypes.c_short,
    'unsigned short int': ctypes.c_ushort,
    'int': ctypes.c_int,
    'signed int': ctypes.c_int,
    'unsigned int': ctypes.c_uint,
    'long': ctypes.c_long,
    'unsigned long': ctypes.c_ulong,
    'long int': ctypes.c_long,
    'unsigned long int': ctypes.c_ulong,
    'long long': ctypes.c_longlong,
    'unsigned long long': ctypes.c_ulonglong,
    'long long int': ctypes.c_longlong,
    'unsigned long long int': ctypes.c_ulonglong,
}

# Floating-point types
_FLOAT_TYPES = {
    'float': ctypes.c_float,
    'double': ctypes.c_double,
    'long double': ctypes.c_longdouble,
}

# Fixed-width types (stdint.h)
_STDINT_TYPES = {
    'int8_t': ctypes.c_int8,
    'uint8_t': ctypes.c_uint8,
    'int16_t': ctypes.c_int16,
    'uint16_t': ctypes.c_uint16,
    'int32_t': ctypes.c_int32,
    'uint32_t': ctypes.c_uint32,
    'int64_t': ctypes.c_int64,
    'uint64_t': ctypes.c_uint64,
}

# Alias mapping
_ALIAS_TYPES = {
    'float32_t': ctypes.c_float,
    'float64_t': ctypes.c_double,
}

# Final aggregation
TYPE_MAP: Dict[str, Any] = {**_CHAR_TYPES, **_INTEGER_TYPES, **_FLOAT_TYPES, **_STDINT_TYPES, **_ALIAS_TYPES}
