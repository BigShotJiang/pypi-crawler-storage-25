# mnemo-cloud

Persistent memory for AI agents. Hosted at [mnemocloud.com](https://mnemocloud.com).

> **Status: 0.0.1 placeholder.** This release reserves the namespace.
> The first functional client release will land in version 0.1.0.
> Track progress at [github.com/verickwayne/agent-memory](https://github.com/verickwayne/agent-memory).
