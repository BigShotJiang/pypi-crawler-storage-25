"""mnemo-cloud — namespace placeholder. See https://mnemocloud.com."""

__version__ = "0.0.1"
