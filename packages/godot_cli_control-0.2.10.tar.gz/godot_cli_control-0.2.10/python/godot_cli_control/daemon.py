"""Daemon 进程管理 —— 移植自 addons/.../bin/run_cli_control.sh。

提供跨平台的 Godot 进程启停、端口探活、PID 校验、录制转码。
"""

from __future__ import annotations

import os
import shutil
import signal
import socket
import subprocess
import sys
import time
from pathlib import Path
from typing import Any

from . import registry as _registry


class DaemonError(RuntimeError):
    """Daemon 启停过程中可恢复的错误（用户应看到 message，不必看 traceback）。"""


class Daemon:
    """管理本地 Godot 实例的状态文件 + 进程。

    所有状态写到 ``project_root/.cli_control/``：``godot.pid`` ``port``
    ``movie_path``。文件名/语义与原 bash 版一致，使两者可互换。
    """

    def __init__(self, project_root: Path, control_dir: Path | None = None) -> None:
        self.project_root = Path(project_root).resolve()
        self.control_dir = control_dir or (self.project_root / ".cli_control")
        self.pid_file = self.control_dir / "godot.pid"
        self.port_file = self.control_dir / "port"
        self.movie_path_file = self.control_dir / "movie_path"
        # Godot 进程的 stdout+stderr。每次 start 时 truncate 重写，stop 后保留
        # 让用户回溯最近一次启动失败的根因（issue #38）。
        self.log_file = self.control_dir / "godot.log"
        # 启动失败时把 returncode 落盘，让 daemon status 能在 stopped 状态下
        # 直接报「last exit: <code>」，省下一轮回溯。stop / 新一轮 start 会
        # 清掉。issue #38。
        self.exit_code_file = self.control_dir / "last_exit_code"

    # ── 状态查询 ──

    def read_pid(self) -> int | None:
        if not self.pid_file.exists():
            return None
        try:
            return int(self.pid_file.read_text().strip())
        except (ValueError, OSError):
            return None

    def is_running(self) -> bool:
        pid = self.read_pid()
        return pid is not None and _process_alive(pid)

    def current_port(self) -> int | None:
        if not self.port_file.exists():
            return None
        try:
            return int(self.port_file.read_text().strip())
        except (ValueError, OSError):
            return None

    # ── 启动 ──

    def start(
        self,
        *,
        godot_bin: str | None = None,
        record: bool = False,
        movie_path: str | None = None,
        headless: bool = False,
        fps: int = 30,
        port: int = 0,  # 0 = OS 自动分配；显式 --port 9877 仍可固定
        wait_seconds: int = 30,
        idle_timeout: int = 0,
    ) -> int:
        """启动 Godot daemon，等端口就绪后返回 PID。"""
        # 项目根校验：拒绝在非 Godot 项目目录跑，避免 Godot 用 --path .
        # 静默创建假项目 + 30s port 探活 timeout 这种神秘失败。
        if not (self.project_root / "project.godot").is_file():
            raise DaemonError(
                f"{self.project_root} 不是 Godot 项目根（缺 project.godot）。"
                f" 请 cd 到 Godot 项目根后再跑，或先 `godot-cli-control init`。"
            )
        if self.is_running():
            raise DaemonError(
                f"Godot already running (PID {self.read_pid()}); stop first"
            )
        if record and not movie_path:
            raise DaemonError("--record requires --movie-path")

        bin_path = (
            godot_bin
            or self.read_godot_bin_pref()
            or find_godot_binary()
        )
        if not bin_path:
            raise DaemonError(
                "Godot binary not found. Set GODOT_BIN env var or run "
                "'godot-cli-control init' to detect & save it."
            )
        if not os.access(bin_path, os.X_OK):
            raise DaemonError(f"Godot binary not executable: {bin_path}")

        # spawn 前快速判定端口空闲。GameBridge 那头 listen 失败只 printerr 不
        # 退进程；daemon 这头探活又走 create_connection，会握手到占端口的进程上
        # 误报启动成功，后续 RPC 全打错。先 bind 一次让占用立刻可见。
        actual_port = _allocate_port(port)

        # 先确保 import 缓存就位（避免首次启动 GameBridge 来不及绑端口）
        _ensure_imported(self.project_root, bin_path)

        self.control_dir.mkdir(parents=True, exist_ok=True)
        # PID/port 仅本用户可读（Windows 上 chmod 是 no-op）
        try:
            os.chmod(self.control_dir, 0o700)
        except OSError:
            pass

        # 清掉上次崩溃残留的 movie_path —— 否则若用户上次 daemon 被 kill -9
        # 没走 stop，旧路径会留在文件里，本次 stop 流程触发针对错误文件的
        # ffmpeg 转码（多半失败但也可能转个旧 .avi 误导用户）。
        self.movie_path_file.unlink(missing_ok=True)
        # 上一轮 last_exit_code 在新一轮 start 时也作废 —— 否则 start 成功后
        # status 还会拿出陈旧的退出码骗用户。
        self.exit_code_file.unlink(missing_ok=True)

        self.port_file.write_text(str(actual_port))

        args: list[str] = [
            bin_path,
            "--path",
            str(self.project_root),
            "--cli-control",
            f"--game-bridge-port={actual_port}",
        ]
        if headless:
            args.append("--headless")
        if idle_timeout > 0:
            args.append(f"--game-bridge-idle-timeout={idle_timeout}")

        env = os.environ.copy()
        if record:
            args += ["--write-movie", movie_path, "--fixed-fps", str(fps)]
            env["GODOT_MOVIE_MAKER"] = "1"
            self.movie_path_file.write_text(movie_path)
            print(f"录制模式：{movie_path} ({fps}fps)", file=sys.stderr)

        # detach 子进程：避免 Ctrl+C 时 SIGINT 同时打到 Godot（父进程会先死，
        # finally 路径再 stop 已死的 PID 日志混乱）。POSIX 用新 session 隔离
        # signal group，Windows 用 CREATE_NEW_PROCESS_GROUP。
        popen_kwargs: dict[str, Any] = {"env": env}
        if sys.platform == "win32":
            popen_kwargs["creationflags"] = subprocess.CREATE_NEW_PROCESS_GROUP
        else:
            popen_kwargs["start_new_session"] = True

        # 把 Godot 的 stdout+stderr 落到 .cli_control/godot.log。truncate 重写
        # 让 log 始终对应最近一次启动；子进程 dup 之后这边的 fh 可以立即关闭，
        # daemon 不必长期持有 fd。issue #38。
        log_fh = open(self.log_file, "wb")
        try:
            popen_kwargs["stdout"] = log_fh
            popen_kwargs["stderr"] = subprocess.STDOUT
            proc = subprocess.Popen(args, **popen_kwargs)
        finally:
            log_fh.close()
        self.pid_file.write_text(str(proc.pid))

        # 启动后 1s 仍存活才认为 launch 成功（捕获 --cli-control 拒识/参数错误）
        time.sleep(1)
        if proc.poll() is not None:
            self._record_exit_code(proc.returncode)
            self._cleanup_state_files()
            raise DaemonError(
                f"Godot exited immediately after launch (returncode={proc.returncode}).\n"
                f"{self._format_log_tail()}"
            )

        print(f"等待 GameBridge 就绪 (port {actual_port})...", file=sys.stderr)
        if not _wait_port_ready(actual_port, wait_seconds, proc=proc):
            crashed_rc = proc.poll()
            if crashed_rc is not None:
                self._record_exit_code(crashed_rc)
            self._terminate(proc.pid)
            self._cleanup_state_files()
            if crashed_rc is not None:
                # 端口探活期间 Godot 自己挂了（autoload 报错 / scene load 失败 等）。
                # 这是 issue #38 报告的"daemon start 报成功后 RPC 全失败"主线场景。
                raise DaemonError(
                    f"Godot exited during launch (returncode={crashed_rc}).\n"
                    f"{self._format_log_tail()}"
                )
            raise DaemonError(
                f"GameBridge not ready on port {actual_port} within {wait_seconds}s.\n"
                f"{self._format_log_tail()}"
            )

        print(f"Godot 已启动 (PID {proc.pid})", file=sys.stderr)
        _registry.register(
            self.project_root,
            pid=proc.pid,
            port=actual_port,
            godot_bin=bin_path,
            log_path=str(self.log_file),
        )
        return proc.pid

    # ── 停止 ──

    def stop(self) -> int:
        """停止 daemon。返回 exit code（0 成功；2 转码失败但进程已停）。"""
        pid = self.read_pid()
        if pid is None:
            print("没有 PID 文件，无需停止", file=sys.stderr)
            return 0
        if not _process_alive(pid):
            print(f"Godot (PID {pid}) 已不在运行，清理 PID 文件", file=sys.stderr)
            self._cleanup_state_files()
            return 0
        if not _process_is_godot(pid):
            raise DaemonError(
                f"PID {pid} 进程名不像 Godot；拒绝 SIGTERM 以免误杀。"
                f" 如需清理，手动 kill 该 PID 并删 {self.pid_file}"
            )

        print(f"关闭 Godot (PID {pid})...", file=sys.stderr)
        self._terminate(pid)
        self._cleanup_state_files()
        print("Godot 已停止", file=sys.stderr)

        # 录制转码（即使失败也认为 stop 成功；返回非 0 让 CI 感知）
        if self.movie_path_file.exists():
            movie_path = Path(self.movie_path_file.read_text().strip())
            self.movie_path_file.unlink(missing_ok=True)
            if not _transcode_movie(movie_path, self.control_dir):
                return 2
        return 0

    # ── 内部 ──

    def _cleanup_state_files(self) -> None:
        """清理本 daemon 的所有持久化状态：本地 pid/port + 全局 registry 记录。

        三者同生同死 —— ``start()`` 成功后一并写入；任何 stop 路径（包括 start
        途中失败的回滚清理）必须把它们一并清掉，否则下次 ``daemon ls`` / 启动
        校验会误以为还有进程在跑。``movie_path`` 在 stop 流程中独立处理。
        """
        self.pid_file.unlink(missing_ok=True)
        self.port_file.unlink(missing_ok=True)
        # start 失败回滚路径还没 register 时，unregister 是 unlink(missing_ok=True)，
        # 行为一致；保持一处兜底比让所有 caller 记得手动 unregister 更不易遗漏。
        _registry.unregister(self.project_root)

    def read_godot_bin_pref(self) -> str | None:
        """读取 init 命令写入的 ``.cli_control/godot_bin`` 路径偏好。"""
        pref = self.control_dir / "godot_bin"
        if not pref.exists():
            return None
        try:
            value = pref.read_text().strip()
        except OSError:
            return None
        if value and Path(value).is_file() and os.access(value, os.X_OK):
            return value
        return None

    def read_last_exit_code(self) -> int | None:
        """读上一次启动失败的 Godot returncode；没有 / 解析失败返回 None。"""
        if not self.exit_code_file.exists():
            return None
        try:
            return int(self.exit_code_file.read_text().strip())
        except (ValueError, OSError) as e:
            # 静默吞掉会让 status 显示「stopped」而不带 last_exit，用户以为没崩过；
            # 起码 stderr 提示一句让人有线索。不抛 —— 上层 status 路径不该被
            # 一个诊断辅助文件读失败击穿。
            print(
                f"warning: failed to read {self.exit_code_file}: {e}",
                file=sys.stderr,
            )
            return None

    def _record_exit_code(self, rc: int | None) -> None:
        """落盘 last exit code。返回 None 时（理论上不该发生 —— poll 已确认死了）
        跳过写入，避免给 status 一个误导的 ``last_exit_code: None``。"""
        if rc is None:
            return
        try:
            self.exit_code_file.write_text(str(rc))
        except OSError as e:
            # 写不进去（磁盘满 / .cli_control 只读）会让后续 daemon status 报
            # 「stopped」而不带 last_exit_code，用户找不到 Godot 真正的退出码。
            # 至少 print 一句到 stderr，留下根因线索。
            print(
                f"warning: failed to record last exit code to {self.exit_code_file}: {e}",
                file=sys.stderr,
            )

    def _format_log_tail(self, n: int = 30) -> str:
        """渲染 godot.log 末尾若干行，给启动失败的 DaemonError 拼可读上下文。

        从文件末尾倒着 8KB 一块读，避免一次性 read_text() 把潜在的大日志整盘吞内存
        —— 启动失败路径目前日志都很小，但若将来 status 也调本函数，遇到长跑后崩溃
        的几百 MB 日志会爆。

        失败兜底成 ``(log unavailable)`` 而不是抛异常 —— 启动错误本身比 log
        读取错误更重要，不能让 IO 失败盖掉真正的根因。
        """
        header = f"Godot 日志（{self.log_file}）末尾 {n} 行："
        try:
            tail_bytes, total_size = _read_tail_bytes(self.log_file, n)
        except OSError:
            return f"(log unavailable: {self.log_file})"
        if total_size == 0:
            return f"{header}\n  (空 — Godot 进程未输出任何内容)"
        text = tail_bytes.decode("utf-8", errors="replace")
        lines = text.splitlines()
        if len(lines) <= n:
            body = text.rstrip()
        else:
            body = "...\n" + "\n".join(lines[-n:])
        return f"{header}\n{body}"

    def _terminate(self, pid: int, timeout: float = 10.0) -> None:
        """SIGTERM → wait → SIGKILL。

        探活用 ``_reap_if_dead`` 而非 ``_process_alive``：``run`` 自起的 daemon 中
        Godot 是本进程的子进程，SIGTERM 后会变 zombie，``os.kill(pid, 0)`` 对
        zombie 仍成功，必须 ``waitpid`` 回收才能正确判定其已退出 —— 否则空等满
        timeout 才放弃，每次 ``run`` 收尾都打印 "SIGTERM 超时" 噪音（#67）。
        """
        try:
            os.kill(pid, signal.SIGTERM)
        except (ProcessLookupError, OSError):
            return
        deadline = time.time() + timeout
        while time.time() < deadline:
            if _reap_if_dead(pid):
                return
            time.sleep(0.5)
        print("SIGTERM 超时，强制终止", file=sys.stderr)
        try:
            os.kill(pid, _force_kill_signal())
        except (ProcessLookupError, OSError):
            pass
        _reap_if_dead(pid)  # 回收被 SIGKILL 的 zombie 子进程（若它是本进程的孩子）


# ── Godot 二进制发现 ──


def find_godot_binary() -> str | None:
    """查找可用的 Godot 二进制。

    优先级：``GODOT_BIN`` env > macOS /Applications > PATH > Windows Program Files。
    """
    env_bin = os.environ.get("GODOT_BIN")
    if env_bin and Path(env_bin).is_file() and os.access(env_bin, os.X_OK):
        return env_bin

    if sys.platform == "darwin":
        # macOS 默认安装位置 + 同目录所有 Godot*.app
        for app in sorted(Path("/Applications").glob("Godot*.app")):
            candidate = app / "Contents" / "MacOS" / "Godot"
            if candidate.is_file() and os.access(candidate, os.X_OK):
                return str(candidate)

    for name in ("godot4", "godot", "Godot"):
        p = shutil.which(name)
        if p:
            return p

    if sys.platform == "win32":
        for base in (
            Path(os.environ.get("ProgramFiles", r"C:\Program Files")),
            Path(os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)")),
        ):
            if base.exists():
                for exe in base.glob("Godot*/Godot*.exe"):
                    return str(exe)
    return None


# ── 进程辅助 ──


def _process_alive(pid: int) -> bool:
    if pid <= 0:
        return False
    if sys.platform == "win32":  # pragma: no cover
        # Windows 上 os.kill(pid, 0) 把 0 当 signal.CTRL_C_EVENT（值就是 0），
        # 会向当前 console 发 Ctrl+C —— 自己把自己/pytest 中断了。所以走
        # OpenProcess + GetExitCodeProcess。
        # POSIX CI 进不到这里；Windows CI 上 fail-under 不跑，故整块跳过覆盖率统计。
        import ctypes
        from ctypes import wintypes

        PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
        STILL_ACTIVE = 259
        kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
        kernel32.OpenProcess.argtypes = (wintypes.DWORD, wintypes.BOOL, wintypes.DWORD)
        kernel32.OpenProcess.restype = wintypes.HANDLE
        kernel32.GetExitCodeProcess.argtypes = (wintypes.HANDLE, ctypes.POINTER(wintypes.DWORD))
        kernel32.GetExitCodeProcess.restype = wintypes.BOOL
        kernel32.CloseHandle.argtypes = (wintypes.HANDLE,)
        kernel32.CloseHandle.restype = wintypes.BOOL

        handle = kernel32.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, False, pid)
        if not handle:
            return False
        try:
            exit_code = wintypes.DWORD()
            if not kernel32.GetExitCodeProcess(handle, ctypes.byref(exit_code)):
                return False
            return exit_code.value == STILL_ACTIVE
        finally:
            kernel32.CloseHandle(handle)
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    except OSError:
        return False
    return True


def _reap_if_dead(pid: int) -> bool:
    """Return True when ``pid`` is no longer a *running* process.

    处理 ``_process_alive`` 单独搞不定的 zombie 场景：当 ``pid`` 是本进程已退出但
    尚未被 wait 的子进程时，它以 zombie 形式滞留进程表，``os.kill(pid, 0)`` 持续
    成功 —— ``_process_alive`` 会无限误报其存活。这正是 ``run`` 每次都打印
    "SIGTERM 超时" 的根因（#67）：``run`` 是 daemon 的父进程，它 SIGTERM 掉的
    Godot 变成无人回收的 zombie。

    ``os.waitpid(pid, WNOHANG)`` 会回收这种子进程并报告其退出。对于不是本进程
    子进程的 pid（如独立的 ``daemon stop``，其 Godot 已被 init 回收），waitpid 抛
    ChildProcessError，回落到通用探活。
    """
    if sys.platform != "win32":
        try:
            reaped_pid, _ = os.waitpid(pid, os.WNOHANG)
        except ChildProcessError:
            pass  # 不是本进程的子进程 —— 交给下面的通用探活
        except OSError:
            pass
        else:
            if reaped_pid == pid:
                return True  # 子进程已退出并被回收
            if reaped_pid == 0:
                return False  # 子进程仍在运行
    return not _process_alive(pid)


def _process_is_godot(pid: int) -> bool:
    """软校验：进程名包含 'godot'（防 PID 复用误杀）。

    无法检查（找不到 ps/tasklist）时**放行**，与原 bash 版宽松行为一致。
    """
    if sys.platform == "win32":
        try:
            out = subprocess.check_output(
                ["tasklist", "/fi", f"PID eq {pid}", "/nh"],
                stderr=subprocess.DEVNULL,
                text=True,
            )
        except (subprocess.SubprocessError, FileNotFoundError):
            return True
        return "godot" in out.lower()

    try:
        out = subprocess.check_output(
            ["ps", "-p", str(pid), "-o", "comm="],
            stderr=subprocess.DEVNULL,
            text=True,
        )
    except (subprocess.SubprocessError, FileNotFoundError):
        return True
    return "godot" in out.lower()


def _force_kill_signal() -> int:
    return getattr(signal, "SIGKILL", signal.SIGTERM)


def _read_tail_bytes(path: Path, target_lines: int, chunk: int = 8192) -> tuple[bytes, int]:
    """读取 path 末尾若干行（>= target_lines），返回 (字节串, 文件总大小)。

    倒着 8KB 一块往前读，遇到超过 target_lines 个 ``\\n`` 即停。空文件返回 (b'', 0)。
    """
    with open(path, "rb") as f:
        f.seek(0, os.SEEK_END)
        total_size = f.tell()
        if total_size == 0:
            return b"", 0
        end = total_size
        chunks: list[bytes] = []
        newlines = 0
        # target_lines 是"行数"；至少多读一段 newline 用于切分
        needed = target_lines + 1
        while end > 0 and newlines <= needed:
            start = max(0, end - chunk)
            f.seek(start)
            buf = f.read(end - start)
            chunks.append(buf)
            newlines += buf.count(b"\n")
            end = start
        chunks.reverse()
        return b"".join(chunks), total_size


def _allocate_port(requested: int) -> int:
    """返回可用端口。requested=0 → OS 分配；requested>0 → 校验未被占用后返回原值。

    Race window：bind→close→spawn→Godot listen 之间窗口达数秒（Godot 要 import
    项目+autoload+_ready 才 listen）。这段时间里其它进程仍可能抢走端口；当下
    Godot 端 listen 失败只 push_error+printerr，daemon 这边在日志 tail 里能看到，
    但不会被自动重试。**推荐用默认 --port 0** 让 OS 每次分配新端口，从根上回避。

    SO_REUSEADDR：避免上一轮 daemon 刚 stop、内核仍在 TIME_WAIT 时显式
    --port N 立刻起新 daemon 报 EADDRINUSE。Godot TCPServer 内部也开了
    SO_REUSEADDR，这里探测必须对齐，否则会出现"探测说占用、Godot 实际能 bind"
    的假阳性。
    """
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            sock.bind(("127.0.0.1", requested))
        except OSError as e:
            raise DaemonError(
                f"port {requested} already in use ({e}). 另一个进程正在占用该端口，"
                f"Godot 起不来。请 stop 旧 daemon 或换 --port（默认 --port 0 由 OS 分配最稳）。"
            ) from e
        return sock.getsockname()[1]
    finally:
        sock.close()


def _wait_port_ready(
    port: int,
    max_seconds: int,
    proc: subprocess.Popen[Any] | None = None,
) -> bool:
    """轮询直到端口可连接或超时。

    若传入 ``proc``，每轮先检查它是否已退出 —— Godot 在 GameBridge 起来前自己
    挂了（autoload 报错、--cli-control 接错……）就立刻返回 False，不让用户干等
    剩下的 wait_seconds。issue #38。
    """
    deadline = time.time() + max_seconds
    while time.time() < deadline:
        if proc is not None and proc.poll() is not None:
            return False
        try:
            with socket.create_connection(("127.0.0.1", port), timeout=0.5):
                return True
        except OSError:
            time.sleep(1)
    return False


_CLASS_CACHE_PATH = Path(".godot") / "global_script_class_cache.cfg"
# autoload 入口 class_name；只检它一个，新增内部 class 不必改这里
_REQUIRED_CLASS_MARKER = b'&"GameBridge"'


def reimport_project(project_root: Path, godot_bin: str) -> None:
    """跑一次 ``--headless --editor --quit`` 重建 ``.godot/`` 缓存。

    stderr 透传到当前进程而非吞掉：项目损坏 / Godot 版本不兼容时用户能看到
    Godot 自己的报错，比之后 GameBridge 30s 端口探活 timeout 容易诊断。
    """
    print("导入项目资源（--editor --quit）...", file=sys.stderr)
    proc = subprocess.run(
        [
            godot_bin,
            "--headless",
            "--editor",
            "--quit",
            "--path",
            str(project_root),
        ],
        stdout=subprocess.DEVNULL,
        check=False,
    )
    if proc.returncode != 0:
        print(
            f"警告：Godot 资源导入返回 {proc.returncode}，"
            f"daemon 启动可能因此失败（看上方 Godot 错误输出）",
            file=sys.stderr,
        )


def _ensure_imported(project_root: Path, godot_bin: str) -> None:
    """daemon 启动兜底：cache 不存在 **或** 不含 GameBridge 时重建。

    后者覆盖：用户没跑 init 直接复制 addon、init 之后又被外部工具改坏 cache、
    或将来 init 自身的重新导入步骤失败。只检 GameBridge 一个 class_name，
    它是 autoload 入口，缺它必挂；其它内部 class 不必感知。
    """
    cache = project_root / _CLASS_CACHE_PATH
    if cache.exists() and _REQUIRED_CLASS_MARKER in cache.read_bytes():
        return
    reimport_project(project_root, godot_bin)


def _transcode_movie(movie_path: Path, control_dir: Path) -> bool:
    """录制结束后把 Godot 输出（avi/png）转成 mp4。失败保留原文件。"""
    if not movie_path.exists():
        return True
    if not shutil.which("ffmpeg"):
        print(
            f"未找到 ffmpeg，保留原始文件：{movie_path}",
            file=sys.stderr,
        )
        return True
    mp4 = movie_path.with_suffix(".mp4")
    log = control_dir / "ffmpeg.log"
    print(f"正在转码：{movie_path} → {mp4} ...", file=sys.stderr)
    with open(log, "wb") as fh:
        proc = subprocess.run(
            [
                "ffmpeg",
                "-i",
                str(movie_path),
                "-c:v",
                "libx264",
                "-preset",
                "fast",
                "-crf",
                "23",
                "-pix_fmt",
                "yuv420p",
                "-y",
                str(mp4),
            ],
            stdout=fh,
            stderr=subprocess.STDOUT,
        )
    if proc.returncode == 0:
        movie_path.unlink(missing_ok=True)
        print(
            f"转码完成：{mp4} ({mp4.stat().st_size} bytes)",
            file=sys.stderr,
        )
        return True
    print(
        f"转码失败，保留原始文件：{movie_path}（日志：{log}）",
        file=sys.stderr,
    )
    return False
