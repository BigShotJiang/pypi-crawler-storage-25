# tests/test_init.py

"""Tests for ots_shared.init — shared init sub-app."""

from pathlib import Path
from unittest.mock import patch

import pytest

from ots_shared.init import app, init
from ots_shared.ssh.env import MARKER_FILENAME, load_marker


class TestInitCreatesFiles:
    """The init command should create marker, .gitignore, and .envrc."""

    def test_creates_marker_with_explicit_name(self, tmp_path):
        with pytest.raises(SystemExit) as exc_info:
            app(["myenv", "--directory", str(tmp_path)])
        assert exc_info.value.code is None or exc_info.value.code == 0
        marker = tmp_path / MARKER_FILENAME
        assert marker.exists()
        data = load_marker(marker)
        assert data["env_name"] == "myenv"

    def test_defaults_name_from_directory(self, tmp_path):
        target = tmp_path / "staging"
        target.mkdir()
        with pytest.raises(SystemExit) as exc_info:
            app(["--directory", str(target)])
        assert exc_info.value.code is None or exc_info.value.code == 0
        data = load_marker(target / MARKER_FILENAME)
        assert data["env_name"] == "staging"

    def test_creates_gitignore(self, tmp_path):
        with pytest.raises(SystemExit):
            app(["env1", "--directory", str(tmp_path)])
        assert (tmp_path / ".gitignore").exists()

    def test_creates_envrc(self, tmp_path):
        with pytest.raises(SystemExit):
            app(["env1", "--directory", str(tmp_path)])
        assert (tmp_path / ".envrc").exists()


class TestInitOverwriteBehavior:
    """Marker file overwrite and --force flag."""

    def test_existing_marker_without_force_is_preserved(self, tmp_path):
        """Spec §6 / AC #2: an existing marker is the re-run path, not a failure.
        The marker stays untouched but init() proceeds through the extension
        loop so trust material can be materialized incrementally.
        """
        marker = tmp_path / MARKER_FILENAME
        marker.write_text("existing\n")
        with pytest.raises(SystemExit) as exc_info:
            app(["eu2", "--directory", str(tmp_path)])
        assert exc_info.value.code is None or exc_info.value.code == 0
        assert marker.read_text() == "existing\n"

    def test_force_overwrites_marker(self, tmp_path):
        marker = tmp_path / MARKER_FILENAME
        marker.write_text("old\n")
        with pytest.raises(SystemExit):
            app(["eu2", "--directory", str(tmp_path), "--force"])
        data = load_marker(marker)
        assert data["env_name"] == "eu2"

    def test_force_overwrites_gitignore(self, tmp_path):
        gitignore = tmp_path / ".gitignore"
        gitignore.write_text("old content\n")
        with pytest.raises(SystemExit):
            app(["env1", "--directory", str(tmp_path), "--force"])
        assert gitignore.read_text() != "old content\n"

    def test_force_overwrites_envrc(self, tmp_path):
        envrc = tmp_path / ".envrc"
        envrc.write_text("old content\n")
        with pytest.raises(SystemExit):
            app(["env1", "--directory", str(tmp_path), "--force"])
        assert envrc.read_text() != "old content\n"


class TestInitErrorCases:
    """Error handling for invalid inputs."""

    def test_nonexistent_directory_exits_with_code_1(self, tmp_path):
        nonexistent = tmp_path / "does-not-exist"
        with pytest.raises(SystemExit) as exc_info:
            app(["env1", "--directory", str(nonexistent)])
        assert exc_info.value.code == 1

    def test_existing_nonempty_trust_dir_fails_fast(self, tmp_path):
        """Fail if .trust/ exists without a marker (orphan trust material)."""
        trust_dir = tmp_path / ".trust"
        trust_dir.mkdir()
        (trust_dir / "ca.crt").write_text("existing cert\n")
        with pytest.raises(SystemExit) as exc_info:
            app(["env1", "--directory", str(tmp_path)])
        assert exc_info.value.code == 1

    def test_existing_trust_with_marker_allows_rerun(self, tmp_path):
        """Re-running init with existing marker + .trust/ is allowed (incremental add)."""
        # First run creates everything
        with pytest.raises(SystemExit):
            app(["env1", "--directory", str(tmp_path)])
        # Second run should succeed (not blocked by existing .trust/)
        with pytest.raises(SystemExit) as exc_info:
            app(["env1", "--directory", str(tmp_path)])
        assert exc_info.value.code is None or exc_info.value.code == 0

    def test_existing_nonempty_trust_dir_with_force_succeeds(self, tmp_path):
        """--force allows overwriting existing .trust/."""
        trust_dir = tmp_path / ".trust"
        trust_dir.mkdir()
        (trust_dir / "ca.crt").write_text("existing cert\n")
        with pytest.raises(SystemExit) as exc_info:
            app(["env1", "--directory", str(tmp_path), "--force"])
        assert exc_info.value.code is None or exc_info.value.code == 0

    def test_existing_empty_trust_dir_succeeds(self, tmp_path):
        """Empty .trust/ directory does not block init."""
        trust_dir = tmp_path / ".trust"
        trust_dir.mkdir()
        with pytest.raises(SystemExit) as exc_info:
            app(["env1", "--directory", str(tmp_path)])
        assert exc_info.value.code is None or exc_info.value.code == 0

    def test_existing_scaffold_without_force_still_creates_marker(self, tmp_path):
        """When .gitignore/.envrc exist but marker does not, marker is created
        and warnings are emitted for the scaffold files."""
        (tmp_path / ".gitignore").write_text("old\n")
        (tmp_path / ".envrc").write_text("old\n")
        with pytest.raises(SystemExit) as exc_info:
            app(["env1", "--directory", str(tmp_path)])
        # Marker should succeed (exit 0 or None), scaffold warnings go to stderr
        assert exc_info.value.code is None or exc_info.value.code == 0
        assert (tmp_path / MARKER_FILENAME).exists()
        # Scaffold files should NOT have been overwritten
        assert (tmp_path / ".gitignore").read_text() == "old\n"
        assert (tmp_path / ".envrc").read_text() == "old\n"


class TestInitDefaultEnvironmentFallback:
    """Edge case: environment falls back to 'default' when directory name is empty."""

    @patch("ots_shared.init.create_peers_toml")
    @patch("ots_shared.init.create_ssh_config")
    @patch("ots_shared.init.create_trust_material")
    @patch("ots_shared.init.load_marker")
    @patch("ots_shared.init.create_envrc_template")
    @patch("ots_shared.init.create_gitignore")
    @patch("ots_shared.init.create_marker")
    def test_root_path_uses_default_as_environment_name(
        self,
        mock_create_marker,
        mock_create_gitignore,
        mock_create_envrc_template,
        mock_load_marker,
        mock_create_trust_material,
        mock_create_ssh_config,
        mock_create_peers_toml,
    ):
        """Path('/').resolve().name is '', so environment should fall back to 'default'."""
        mock_create_marker.return_value = Path("/otsinfra.yaml")
        mock_create_gitignore.return_value = Path("/.gitignore")
        mock_create_envrc_template.return_value = Path("/.envrc")
        mock_load_marker.return_value = {}
        mock_create_trust_material.return_value = Path("/.trust")
        mock_create_ssh_config.return_value = Path("/.ssh/config")
        mock_create_peers_toml.return_value = Path("/peers.toml")

        init(directory=Path("/"))

        mock_create_marker.assert_called_once()
        call_args = mock_create_marker.call_args
        assert call_args[0][1] == "default"
