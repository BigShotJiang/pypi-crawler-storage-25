"""Resume core logic."""

import json
import logging
import re
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

from village.config import Config, get_config
from village.contracts import ContractEnvelope, generate_contract
from village.errors import InterruptedResume
from village.event_log import log_task_error, log_task_start, log_task_success
from village.locks import Lock, parse_lock, write_lock
from village.probes.tmux import (
    panes,
    send_keys,
)
from village.probes.tools import SubprocessError, run_command
from village.ready import assess_readiness
from village.state_machine import TaskState, TaskStateMachine
from village.worktrees import create_worktree, get_worktree_info, reset_worktree

logger = logging.getLogger(__name__)

MAX_RETRIES = 3


@dataclass
class ResumeAction:
    """Action to take for resume."""

    action: str
    reason: str
    blocking: bool
    meta: dict[str, str]


@dataclass
class ResumeResult:
    """Result of resume operation."""

    success: bool
    task_id: str
    agent: str
    worktree_path: Path
    window_name: str
    pane_id: str
    error: Optional[str] = None
    html_output: Optional[str] = None


def plan_resume(
    task_id: Optional[str] = None,
    config: Optional[Config] = None,
) -> ResumeAction:
    """
    Plan resume action using ready engine.

    Args:
        task_id: Optional task ID for explicit resume
        config: Optional config (uses default if not provided)

    Returns:
        ResumeAction with action to take
    """
    if config is None:
        config = get_config()

    # Assess readiness using ready engine
    assessment = assess_readiness(config.tmux_session)

    # Plan based on readiness
    if assessment.error:
        return ResumeAction(
            action="error",
            reason=assessment.error,
            blocking=True,
            meta={"error": assessment.error},
        )

    if not assessment.environment_ready:
        return ResumeAction(
            action="up",
            reason="Village runtime not initialized",
            blocking=True,
            meta={"command": "village up"},
        )

    if not assessment.runtime_ready:
        return ResumeAction(
            action="up",
            reason="Tmux session not running",
            blocking=True,
            meta={"command": "village up"},
        )

    # Check for stale locks
    if assessment.stale_locks_count > 0:
        return ResumeAction(
            action="cleanup",
            reason=f"{assessment.stale_locks_count} stale lock(s) found",
            blocking=False,
            meta={"command": "village cleanup"},
        )

    # If task_id provided, verify it's not already active
    if task_id:
        lock_path = config.locks_dir / f"{task_id}.lock"
        if lock_path.exists():
            lock = parse_lock(lock_path)
            if lock:
                if is_active_lock(lock, config.tmux_session):
                    return ResumeAction(
                        action="status",
                        reason=f"Task {task_id} already has ACTIVE lock",
                        blocking=False,
                        meta={"command": "village status --workers"},
                    )

    # If no task_id provided, suggest queue or status
    if not task_id:
        if assessment.ready_tasks_count and assessment.ready_tasks_count > 0:
            return ResumeAction(
                action="queue",
                reason=f"{assessment.ready_tasks_count} ready task(s) available",
                blocking=False,
                meta={"command": "village queue"},
            )
        else:
            return ResumeAction(
                action="ready",
                reason="No specific task ID provided",
                blocking=False,
                meta={"command": "village ready"},
            )

    return ResumeAction(
        action="resume",
        reason=f"Ready to resume task {task_id}",
        blocking=False,
        meta={"task_id": task_id},
    )


def suggest_next_action(config: Optional[Config] = None) -> ResumeAction:
    """
    Suggest next action when no task_id provided (no-id planner).

    Args:
        config: Optional config (uses default if not provided)

    Returns:
        ResumeAction with suggested action
    """
    return plan_resume(task_id=None, config=config)


def execute_resume(
    task_id: str,
    agent: str,
    detached: bool = False,
    dry_run: bool = False,
    config: Optional[Config] = None,
) -> ResumeResult:
    """
    Execute resume operation.

    Creates worktree, window, lock, and starts OpenCode with contract injection.

    Args:
        task_id: Task ID (e.g., "bd-a3f8")
        agent: Agent name (e.g., "build", "frontend")
        detached: Run in detached mode (no tmux attach)
        dry_run: Preview mode without making changes
        config: Optional config (uses default if not provided)

    Returns:
        ResumeResult with operation details
    """
    if config is None:
        config = get_config()

    session_name = config.tmux_session
    base_task_id = task_id

    # Log task start
    log_task_start(task_id, "resume", config.village_dir)

    # Resource tracking for cleanup on interrupt
    created_resources: dict[str, object] = {
        "worktree_path": None,
        "window_name": None,
        "lock": None,
    }

    logger.info(f"Executing resume: task_id={task_id}, agent={agent}, detached={detached}")

    try:
        # Phase 1: Ensure worktree exists (with retry on collision)
        worktree_path, window_name, task_id = _ensure_worktree_exists(base_task_id, session_name, dry_run, config)
        created_resources["worktree_path"] = worktree_path

        if dry_run:
            logger.info("Dry run: would create worktree and window")
            return ResumeResult(
                success=True,
                task_id=task_id,
                agent=agent,
                worktree_path=worktree_path,
                window_name=window_name,
                pane_id="",
                error=None,
            )

        # Phase 2: Create tmux window
        pane_id = _create_resume_window(session_name, window_name, dry_run)
        created_resources["window_name"] = window_name

        if not pane_id:
            raise RuntimeError(f"Failed to create tmux window '{window_name}'")

        # Phase 3: Write lock file
        lock = Lock(
            task_id=task_id,
            pane_id=pane_id,
            window=window_name,
            agent=agent,
            claimed_at=datetime.now(),
        )
        write_lock(lock)
        created_resources["lock"] = lock

        # Phase 4: Generate and inject contract
        contract = generate_contract(task_id, agent, worktree_path, window_name, config)
        agent_type = config.agents[agent].type if agent in config.agents else "opencode"
        _inject_contract(session_name, pane_id, contract, dry_run, agent_type=agent_type, traces_dir=config.traces_dir)

        logger.info(f"Resume complete: task_id={task_id}, pane_id={pane_id}")

        # Log task success
        log_task_success(task_id, "resume", pane_id, config.village_dir)

        return ResumeResult(
            success=True,
            task_id=task_id,
            agent=agent,
            worktree_path=worktree_path,
            window_name=window_name,
            pane_id=pane_id,
        )

    except KeyboardInterrupt:
        logger.warning("Resume interrupted by user")
        logger.info(f"Resources remain for manual cleanup: {created_resources}")
        raise InterruptedResume()

    except Exception as e:
        logger.error(f"Resume failed: {e}")
        worktree_path = (
            created_resources["worktree_path"] if isinstance(created_resources["worktree_path"], Path) else Path("")
        )
        window_name = created_resources["window_name"] if isinstance(created_resources["window_name"], str) else ""

        # Rollback if enabled
        if config.safety.rollback_on_failure and worktree_path:
            try:
                logger.info(f"Rolling back worktree: {worktree_path}")
                reset_worktree(task_id, config)

                # Log rollback event
                event = {
                    "ts": datetime.now(timezone.utc).isoformat(),
                    "cmd": "rollback",
                    "task_id": task_id,
                    "result": "ok",
                    "error": str(e),
                }
                event_log_path = config.village_dir / "events.log"
                with open(event_log_path, "a", encoding="utf-8") as f:
                    f.write(json.dumps(event, sort_keys=True) + "\n")
                    f.flush()

                logger.info(f"Worktree rollback complete: {task_id}")
            except Exception as rollback_error:
                logger.error(f"Rollback failed for {task_id}: {rollback_error}")

        # Mark task as FAILED in state machine
        state_machine = TaskStateMachine(config)
        transition_result = state_machine.transition(
            task_id=task_id,
            new_state=TaskState.FAILED,
            context={"error": str(e), "window": window_name},
        )

        if not transition_result.success:
            logger.warning(f"Failed to transition task {task_id} to FAILED: {transition_result.message}")

        # Log task error
        log_task_error(task_id, "resume", str(e), config.village_dir)

        return ResumeResult(
            success=False,
            task_id=task_id,
            agent=agent,
            worktree_path=worktree_path,
            window_name=window_name,
            pane_id="",
            error=str(e),
        )


def _ensure_worktree_exists(
    base_task_id: str,
    session_name: str,
    dry_run: bool,
    config: Config,
) -> tuple[Path, str, str]:
    """
    Ensure worktree exists with retry on collision.

    Args:
        base_task_id: Original task ID (e.g., "bd-a3f8")
        session_name: Tmux session name
        dry_run: Preview mode
        config: Config object

    Returns:
        Tuple of (worktree_path, window_name, final_task_id)

    Raises:
        RuntimeError: If worktree creation fails after retries
    """
    task_id = base_task_id
    max_retries = MAX_RETRIES

    for attempt in range(max_retries):
        try:
            worktree_path = config.worktrees_dir / task_id

            # Check if worktree already exists
            if worktree_path.exists() or get_worktree_info(task_id, config) is not None:
                logger.debug(f"Worktree already exists: {worktree_path}")
                window_name = _generate_resume_window(task_id, session_name)
                return worktree_path, window_name, task_id

            # Create worktree
            logger.debug(f"Creating worktree attempt {attempt + 1}/{max_retries}: {task_id}")
            worktree_path, window_name = create_worktree(task_id, session_name, config)
            logger.debug(f"Worktree created: {worktree_path}")
            return worktree_path, window_name, task_id

        except SubprocessError as e:
            error_msg = str(e).lower()

            # Check if error is collision-ish (name/path already exists)
            if any(
                keyword in error_msg
                for keyword in [
                    "already exists",
                    "path exists",
                    "worktree already exists",
                ]
            ):
                if attempt < max_retries:
                    # Increment worker number and retry
                    task_id = f"{base_task_id}-{attempt + 2}"
                    logger.debug(f"Worktree collision detected, retrying as: {task_id}")
                    continue
                else:
                    raise RuntimeError(f"Worktree creation failed after {max_retries} attempts: {str(e)}")
            else:
                # Non-collision error - abort immediately
                raise RuntimeError(f"Worktree creation failed: {e}")

    # This should never be reached, but needed for type checker
    raise RuntimeError(f"Worktree creation failed after {max_retries} attempts")


def _generate_resume_window(task_id: str, session_name: str) -> str:
    """
    Generate resume window name with agent prefix.

    Pattern: <agent>-<worker_num>-<task_id>
    Example: build-1-bd-a3f8

    For initial creation, uses "worker" as agent placeholder.
    Caller can update based on task metadata.

    Args:
        task_id: Task ID (e.g., "bd-a3f8")
        session_name: Tmux session name (not used in pattern)

    Returns:
        Window name
    """
    worker_num = 1
    base = task_id

    # Check if task_id has suffix (e.g., bd-a3f8-2)
    match = re.match(r"^(bd-[a-f0-9]+)(?:-(\d+))?$", task_id)
    if match:
        base = match.group(1)
        suffix = match.group(2)
        if suffix:
            worker_num = int(suffix)

    # Default to "worker" as agent placeholder
    # Caller should update based on actual agent from task metadata
    return f"worker-{worker_num}-{base}"


def _create_resume_window(
    session_name: str,
    window_name: str,
    dry_run: bool,
) -> str:
    """
    Create tmux window for resume operation.

    Args:
        session_name: Tmux session name
        window_name: Window name (e.g., "worker-1-bd-a3f8")
        dry_run: Preview mode

    Returns:
        Pane ID (e.g., "%12") or empty string if dry_run

    Raises:
        RuntimeError: If window creation fails
    """
    from village.probes.tools import run_command_output

    if dry_run:
        logger.info(f"Dry run: would create window '{window_name}'")
        return ""

    # Create window with empty command (pane stays open)
    cmd = ["tmux", "new-window", "-t", session_name, "-n", window_name, "-d"]
    try:
        run_command(cmd, capture=True)
        logger.debug(f"Created window '{window_name}'")
    except SubprocessError as e:
        raise RuntimeError(f"Failed to create tmux window '{window_name}': {e}")

    # Get pane ID for the specific window we just created
    # Query by window name to get the exact pane
    try:
        pane_cmd = [
            "tmux",
            "list-panes",
            "-t",
            f"{session_name}:{window_name}",
            "-F",
            "#{pane_id}",
        ]
        output = run_command_output(pane_cmd)
        pane_ids = [line.strip() for line in output.splitlines() if line.strip()]
        if not pane_ids:
            raise RuntimeError(f"No panes found in window '{window_name}'")
        return pane_ids[0]
    except SubprocessError as e:
        raise RuntimeError(f"Failed to get pane ID for window '{window_name}': {e}")


def _inject_contract(
    session_name: str,
    pane_id: str,
    contract: ContractEnvelope,
    dry_run: bool,
    agent_type: str = "opencode",
    traces_dir: Path | None = None,
) -> None:
    if dry_run:
        logger.info(f"Dry run: would inject contract to pane {pane_id}")
        return

    if contract.warnings:
        for warning in contract.warnings:
            logger.warning(f"Contract warning: {warning}")

    contract_json = contract.to_json()

    if agent_type == "pi":
        trace_redirect = ""
        if traces_dir is not None:
            trace_file = traces_dir.resolve() / f"{contract.task_id}-agent.jsonl"
            trace_redirect = f" 2>&1 | tee {trace_file}"
        command = (
            f"pi --no-session --mode json <<'VILLAGE_CONTRACT_EOF'{trace_redirect}"
            f"\n{contract_json}\nVILLAGE_CONTRACT_EOF"
        )
    else:
        command = f"opencode <<'VILLAGE_CONTRACT_EOF'\n{contract_json}\nVILLAGE_CONTRACT_EOF"

    send_keys(session_name, pane_id, command)
    send_keys(session_name, pane_id, "Enter")

    logger.debug(f"Injected contract to pane {pane_id} via {agent_type}")


def is_active_lock(lock: Lock, session_name: str, force_refresh: bool = False) -> bool:
    """
    Check if lock is ACTIVE (pane exists).

    Args:
        lock: Lock object to check
        session_name: Tmux session name
        force_refresh: Force fresh pane check

    Returns:
        True if ACTIVE, False if STALE
    """
    all_panes = panes(session_name, force_refresh=force_refresh)
    return lock.pane_id in all_panes


def check_agent_done(task_id: str, agent_type: str, config: Config) -> bool | None:
    """Check if agent has positively completed.

    Returns True if completed, False if still running, None if unknown (not a pi agent).
    """
    if agent_type != "pi":
        return None

    from village.agent_events import check_agent_completion

    result = check_agent_completion(task_id, config.traces_dir)
    if result is None:
        return None
    return result.completed


def _get_agent_from_task_id(
    task_id: str,
    default_agent: str | None = None,
) -> str:
    """
    Auto-detect agent from task metadata.

    Args:
        task_id: Task ID (e.g., "bd-a3f8")
        default_agent: Fallback agent if task store unavailable

    Returns:
        Agent name (e.g., "build", "frontend")
    """
    try:
        from village.tasks import get_task_store

        store = get_task_store()
        if store.is_available():
            task = store.get_task(task_id)
            if task and task.labels:
                from village.config import get_config
                from village.queue import extract_agent_from_labels

                config = get_config()
                agent = extract_agent_from_labels(task.labels, config)
                if agent:
                    return agent
    except Exception:
        logger.debug("Task store unavailable for agent detection")

    # Use default agent or fallback to "worker"
    return default_agent if default_agent else "worker"
