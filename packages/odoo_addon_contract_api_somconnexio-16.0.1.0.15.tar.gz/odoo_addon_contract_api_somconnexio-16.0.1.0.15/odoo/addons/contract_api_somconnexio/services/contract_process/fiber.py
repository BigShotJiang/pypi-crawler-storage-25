from odoo import _
from odoo.exceptions import UserError

from .ba import BAContractProcess


class FiberContractProcess(BAContractProcess):
    _name = "fiber.contract.process"
    _inherit = "ba.contract.process"
    _description = """
        Fiber Contract creation
    """

    @staticmethod
    def validate_service_technology_deps(params):
        errors = []
        if "service_address" not in params:
            errors.append('Fiber needs "service_address"')
        fiber_suppliers = [
            "Asociatel VDF",
            "Vodafone",
            "Orange",
            "MásMóvil",
            "XOLN",
        ]
        if params["service_supplier"] not in fiber_suppliers:
            errors.append("Fiber needs {} suppliers".format(", ".join(fiber_suppliers)))
        else:
            if params["service_supplier"] in ["Asociatel VDF", "Vodafone"]:
                if "vodafone_fiber_contract_service_info" not in params:
                    errors.append(
                        "Vodafone Fiber needs vodafone_fiber_contract_service_info"
                    )
                if params.get("fiber_signal_type") == "fibraIndirecta":
                    errors.append(
                        'Fiber signal "Fibra Indirecta" needs MásMóvil supplier'
                    )
            elif params["service_supplier"] == "MásMóvil":
                if "mm_fiber_contract_service_info" not in params:
                    errors.append("MásMóvil Fiber needs mm_fiber_contract_service_info")
                if params.get("fiber_signal_type") in ("fibraCoaxial", "NEBAFTTH"):
                    errors.append(
                        'Fiber signal "{}" needs Vodafone supplier'.format(
                            params["fiber_signal_type"]
                        )
                    )
            elif params["service_supplier"] == "XOLN":
                if "xoln_fiber_contract_service_info" not in params:
                    errors.append("XOLN Fiber needs mm_fiber_contract_service_info")
            elif params["service_supplier"] == "Orange":
                if "orange_fiber_contract_service_info" not in params:
                    errors.append(
                        "Orange Fiber needs orange_fiber_contract_service_info"
                    )
        if errors:
            raise UserError("\n".join(errors))

    def _create_vodafone_fiber_contract_service_info(self, params):
        if not params:
            return False
        return (
            self.env["vodafone.fiber.service.contract.info"]
            .sudo()
            .create(
                {
                    "phone_number": params["phone_number"],
                    "vodafone_id": params["vodafone_id"],
                    "vodafone_offer_code": params["vodafone_offer_code"],
                }
            )
        )

    def _create_mm_fiber_contract_service_info(self, params):
        if not params:
            return False
        return (
            self.env["mm.fiber.service.contract.info"]
            .sudo()
            .create(
                {
                    "phone_number": params["phone_number"],
                    "mm_id": params["mm_id"],
                }
            )
        )

    def _create_orange_fiber_contract_service_info(self, params):
        if not params:
            return False
        return (
            self.env["orange.fiber.service.contract.info"]
            .sudo()
            .create(
                {
                    "suma_id": params["suma_id"],
                }
            )
        )

    def _create_xoln_fiber_contract_service_info(self, params):
        if not params:
            return False
        router_product = self._get_router_product_id(params["router_product_id"])
        router_lot_id = self._create_router_lot_id(
            params["router_serial_number"],
            router_product,
        )
        project_id = self._get_project_xoln_id_by_code(params["project"])

        return (
            self.env["xoln.fiber.service.contract.info"]
            .sudo()
            .create(
                {
                    "phone_number": params["phone_number"],
                    "external_id": params["external_id"],
                    "id_order": params["id_order"],
                    "project_id": project_id,
                    "router_product_id": router_product.id,
                    "router_lot_id": router_lot_id.id,
                }
            )
        )

    def create(self, **params):
        contract_dict = super().create(**params)
        if params.get("mobile_pack_contracts"):
            self._relate_with_CU_former_mobile_contracts(
                contract_dict["id"], params.get("mobile_pack_contracts")
            )
        else:
            self._relate_new_fiber_with_existing_mobile_contracts(contract_dict)
        return contract_dict

    def _relate_with_CU_former_mobile_contracts(self, _id, mobile_pack_contracts):
        """
        When we create a contract from an address change petition (CU),
        we need to relate the mobile contracts linked with the
        former fiber contract with the new one
        """
        if mobile_pack_contracts:
            mobile_contracts = (
                self.env["contract.contract"]
                .sudo()
                .search([("code", "in", mobile_pack_contracts.split(","))])
            )
            for contract in mobile_contracts:
                contract.parent_pack_contract_id = _id

    def _get_related_crm_lead_line(self, contract_dict):
        # To be implemented in the OTRS module
        return self.env["crm.lead.line"]

    def _change_related_mobile_contract_tariff(
        self, mbl_pack_product, mbl_contract_id, fiber_contract_id
    ):
        # To be implemented in the OTRS module
        pass

    def _relate_new_fiber_with_existing_mobile_contracts(self, contract_dict):
        """
        Link new fiber to an existing mobile contract, except:
          - New fiber contract comes from location_change
          - Within the fiber CRMLead there is a mobile with
            pack product (the fiber contract is needed to be
            packed with that mobile).
          - No existing mobile contract is found with appropiate
            mobile tariffs to be packed.
        """

        # Check that fiber contract does not come from a location change
        if contract_dict["create_reason"] == "location_change":
            return

        # Check if fiber CRMLead has mobile with pack product
        crm_lead_line = self._get_related_crm_lead_line(contract_dict)
        mobile_lines = crm_lead_line.lead_id.lead_line_ids.filtered(
            "is_mobile"
        ).filtered("is_from_pack")
        if mobile_lines:
            return

        # Check existing mobile contracts
        partner_id = contract_dict["partner_id"]
        mobile_products_appropiate_to_pack = self._mobile_products_appropiate_to_pack()
        mobile_contracts = self._get_mobile_contracts_to_pack(
            partner_id, mobile_products_appropiate_to_pack
        )

        if not mobile_contracts:
            return

        # pinya pack notification
        is_company = self.env["res.partner"].browse(partner_id).is_company
        pack_mobile_product_id = self._get_mobile_pinya_pack_product(
            len(mobile_contracts), is_company
        )
        product_ctx = self._get_product_ctx(pack_mobile_product_id)

        should_link_automatically = len(mobile_contracts) == 1 or (
            self._is_fiber_300(contract_dict["current_tariff_product"])
            and len(mobile_contracts) in (2, 3)
        )
        if should_link_automatically:
            template = self.env.ref(
                "somconnexio.mobile_linked_with_fiber_email_template"
            )
            for mbl_contract in mobile_contracts:
                # Change mobile tariffs to pack
                self._change_related_mobile_contract_tariff(
                    pack_mobile_product_id, mbl_contract.id, contract_dict["id"]
                )
                # Send mail to notify that this mobile contract has been linked
                # with the new fiber contract
                template.with_context(product_ctx).sudo().send_mail(mbl_contract.id)
        else:
            # Send mail to notify the user that they can link some of their mobiles
            # with the new fiber contract
            template = self.env.ref(
                "somconnexio.mobile_to_link_with_fiber_email_template"
            )
            template.with_context(product_ctx).sudo().send_mail(partner_id)

    def _mobile_products_appropiate_to_pack(self):
        """
        Return mobile products that have the same or less data
        (those without any data not included) than the pinya to be packed,
        but with a higher price
        """

        return [
            self.env.ref("somconnexio.TrucadesIllimitades30GB").id,
            self.env.ref("somconnexio.TrucadesIllimitades20GB").id,
            self.env.ref("somconnexio.TrucadesIllimitades17GB").id,
            self.env.ref("somconnexio.TrucadesIllimitades12GB").id,
            self.env.ref("somconnexio.TrucadesIllimitades5GB").id,
        ]

    def _get_product_ctx(self, pack_mobile_product):
        pack_mobile_product_price = self._product_price(pack_mobile_product)
        pack_mobile_product_data = pack_mobile_product.get_catalog_name("Data")
        return {
            "mobile_price": pack_mobile_product_price,
            "mobile_data": int(pack_mobile_product_data) // 1024,  # To GB
        }

    def _product_price(self, product):
        pricelist = self.env["product.pricelist"].search([("code", "=", "21IVA")])
        return pricelist._get_product_price(product, 1)

    def _get_mobile_contracts_to_pack(
        self, partner_id, mobile_products_appropiate_to_pack
    ):
        mobile_tech_id = self.env.ref("somconnexio.service_technology_mobile").id
        mobile_contracts = (
            self.env["contract.contract"]
            .sudo()
            .search(
                [
                    ("partner_id", "=", partner_id),
                    ("service_technology_id", "=", mobile_tech_id),
                    ("date_end", "=", False),
                    ("parent_pack_contract_id", "=", False),
                    (
                        "current_tariff_product",
                        "in",
                        mobile_products_appropiate_to_pack,
                    ),
                ]
            )
        )
        return mobile_contracts

    def _get_mobile_pinya_pack_product(self, num_mobiles, is_company):
        """
        Return the pack product according to the number of mobiles to pack
        """

        pack_attr = self.env.ref("somconnexio.IsInPack")
        pack_2_mbl = self.env.ref("somconnexio.Pack2Mobiles")
        pack_3_mbl = self.env.ref("somconnexio.Pack3Mobiles")

        attr_to_include = pack_attr
        if is_company:
            attr_to_exclude = self.env.ref("somconnexio.ParticularExclusive")
        else:
            attr_to_exclude = self.env.ref("somconnexio.CompanyExclusive")

        if num_mobiles == 1:
            attr_to_exclude |= pack_2_mbl | pack_3_mbl
        elif num_mobiles == 2:
            attr_to_include |= pack_2_mbl
            attr_to_exclude |= pack_3_mbl
        elif num_mobiles == 3:
            attr_to_include |= pack_3_mbl
            attr_to_exclude |= pack_2_mbl

        mbl_product_template = self.env.ref("somconnexio.Mobile_product_template")
        mbl_products = self.env["product.product"].search(
            [
                ("product_tmpl_id", "=", mbl_product_template.id),
                ("has_sharing_data_bond", "=", False),
            ]
        )
        mbl_products = mbl_products.filtered(
            lambda p: all(
                attr
                in p.product_template_attribute_value_ids.product_attribute_value_id
                for attr in attr_to_include
            )
            and not any(
                attr
                in p.product_template_attribute_value_ids.product_attribute_value_id
                for attr in attr_to_exclude
            )
        )
        if not mbl_products:
            raise UserError(
                _("No mobile pack product found for the number of mobiles to pack")
            )

        return mbl_products[-1]

    def _is_fiber_300(self, fiber_product_code):
        fiber_product = self.env["product.product"].search(
            [("default_code", "=", fiber_product_code)]
        )
        fiber_300_attr = self.env.ref("somconnexio.300Mb")
        return bool(
            fiber_300_attr
            in fiber_product.product_template_attribute_value_ids.product_attribute_value_id  # noqa E501
        )
