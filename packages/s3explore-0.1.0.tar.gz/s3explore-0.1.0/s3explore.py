"""
s3explore — lightweight S3 data exploration via SQL (chDB/ClickHouse).

Usage as a CLI:
    python s3explore.py [--profile PROFILE] [--format table|json|csv] COMMAND S3_PATH

Usage as a library:
    import s3explore
    creds = s3explore.get_credentials(profile="my-profile")
    print(s3explore.get_schema("s3://bucket/path/*.parquet", creds))
"""

from __future__ import annotations

import sys
import json
import urllib.parse
from pathlib import PurePosixPath

import boto3
import botocore.exceptions
import botocore.config
import click

UNSIGNED = botocore.config.Config(signature_version=botocore.UNSIGNED)

try:
    import chdb
except ImportError:
    chdb = None  # deferred error at query time

__all__ = [
    "get_credentials",
    "detect_format",
    "build_s3_expr",
    "run_query",
    "get_schema",
    "sample_rows",
    "count_per_file",
    "run_user_query",
    "list_files",
]

# ---------------------------------------------------------------------------
# Format detection
# ---------------------------------------------------------------------------

_FORMAT_MAP: dict[str, str] = {
    ".parquet": "Parquet",
    ".csv":     "CSVWithNames",
    ".json":    "JSONEachRow",
    ".jsonl":   "JSONEachRow",
    ".ndjson":  "JSONEachRow",
    ".tsv":     "TabSeparatedWithNames",
}

_GZ_FORMAT_MAP: dict[str, str] = {
    ".json":   "JSONEachRow",
    ".jsonl":  "JSONEachRow",
    ".ndjson": "JSONEachRow",
    ".csv":    "CSVWithNames",
    ".tsv":    "TabSeparatedWithNames",
}


def detect_format(s3_path: str) -> str:
    """Infer the ClickHouse format name from the file extension in an S3 path.

    Handles wildcards (e.g. s3://bucket/data/*.parquet) and compound
    extensions like .json.gz.

    Raises ValueError if the format cannot be determined.
    """
    parsed = urllib.parse.urlparse(s3_path)
    segment = parsed.path.rstrip("/").split("/")[-1]
    suffixes = PurePosixPath(segment).suffixes

    if not suffixes:
        raise ValueError(
            f"Cannot detect file format from path: {s3_path!r}. "
            "Use --fmt to specify the format explicitly."
        )

    last = suffixes[-1].lower()

    if last == ".gz":
        if len(suffixes) >= 2:
            inner = suffixes[-2].lower()
            fmt = _GZ_FORMAT_MAP.get(inner)
            if fmt:
                return fmt
        # Bare .gz (e.g. Kinesis Firehose output) — best-effort default
        print(
            "Warning: cannot determine inner format of .gz file from extension alone. "
            "Assuming JSONEachRow. Use --fmt to override.",
            file=sys.stderr,
        )
        return "JSONEachRow"

    fmt = _FORMAT_MAP.get(last)
    if fmt:
        return fmt

    raise ValueError(
        f"Unrecognised file extension {last!r} in path: {s3_path!r}. "
        "Use --fmt to specify: Parquet, JSONEachRow, CSVWithNames, etc."
    )


# ---------------------------------------------------------------------------
# Credential resolution
# ---------------------------------------------------------------------------

def get_credentials(profile: str | None = None) -> dict:
    """Resolve AWS credentials via boto3.

    Supports SSO named profiles, environment variables, and instance profiles.
    Returns a dict with keys: access_key, secret_key, session_token.
    session_token is None for long-term IAM keys.

    Raises RuntimeError with a helpful message on failure.
    """
    try:
        session = boto3.Session(profile_name=profile)
        frozen = session.get_credentials().get_frozen_credentials()
        return {
            "access_key":    frozen.access_key,
            "secret_key":    frozen.secret_key,
            "session_token": frozen.token,
        }
    except botocore.exceptions.ProfileNotFound:
        raise RuntimeError(
            f"AWS profile {profile!r} not found. "
            "Check your ~/.aws/config or run: aws configure sso"
        )
    except botocore.exceptions.NoCredentialsError:
        hint = f"aws sso login --profile {profile}" if profile else "aws configure"
        raise RuntimeError(
            f"No AWS credentials found. Run: {hint}"
        )
    except Exception as exc:
        hint = f"aws sso login --profile {profile}" if profile else "aws configure"
        raise RuntimeError(
            f"Failed to load credentials: {exc}. Try: {hint}"
        ) from exc


# ---------------------------------------------------------------------------
# S3 expression builder
# ---------------------------------------------------------------------------

def build_s3_expr(
    s3_path: str,
    creds: dict | None,
    fmt: str | None = None,
    structure: str | None = None,
) -> str:
    """Build the chDB s3() table-function expression.

    Credential forms:
      - With session token:  s3('path', 'AK', 'SK', 'ST', 'Format')
      - Without token:       s3('path', 'AK', 'SK', 'Format')
      - No creds (public):   s3('path', 'Format')

    If structure is given (e.g. '_j JSON' for raw JSON object mode),
    it is appended as the final argument.
    """
    resolved_fmt = fmt or detect_format(s3_path)

    def q(s: str) -> str:
        return "'" + s.replace("'", "\\'") + "'"

    if not creds or (not creds.get("access_key") and not creds.get("secret_key")):
        # Public bucket — no credentials
        parts = [q(s3_path), q(resolved_fmt)]
    elif creds.get("session_token"):
        parts = [
            q(s3_path),
            q(creds["access_key"]),
            q(creds["secret_key"]),
            q(creds["session_token"]),
            q(resolved_fmt),
        ]
    else:
        parts = [
            q(s3_path),
            q(creds["access_key"]),
            q(creds["secret_key"]),
            q(resolved_fmt),
        ]

    if structure:
        parts.append(q(structure))

    return f"s3({', '.join(parts)})"


# ---------------------------------------------------------------------------
# Query execution
# ---------------------------------------------------------------------------

def run_query(sql: str, output_format: str = "PrettyCompact") -> str:
    """Execute SQL against chDB and return the result as a string.

    output_format is a chDB/ClickHouse output format name:
      PrettyCompact, JSON, JSONEachRow, CSV, CSVWithNames, etc.
    """
    if chdb is None:
        raise RuntimeError(
            "chdb is not installed. Run: pip install 'chdb>=2.0.2'"
        )
    result = chdb.query(sql, output_format)
    return result.bytes().decode("utf-8")


# ---------------------------------------------------------------------------
# High-level operations
# ---------------------------------------------------------------------------

def get_schema(
    s3_path: str,
    creds: dict | None,
    fmt: str | None = None,
    output_format: str = "PrettyCompact",
) -> str:
    """Return the schema (column names and types) for files at s3_path."""
    s3_expr = build_s3_expr(s3_path, creds, fmt)
    sql = f"DESCRIBE {s3_expr} SETTINGS describe_compact_output=1"
    return run_query(sql, output_format)


def sample_rows(
    s3_path: str,
    creds: dict | None,
    n: int = 10,
    fmt: str | None = None,
    output_format: str = "PrettyCompact",
) -> str:
    """Return n sample rows from files at s3_path."""
    s3_expr = build_s3_expr(s3_path, creds, fmt)
    sql = f"SELECT * FROM {s3_expr} LIMIT {int(n)}"
    return run_query(sql, output_format)


def count_per_file(
    s3_path: str,
    creds: dict | None,
    fmt: str | None = None,
    output_format: str = "PrettyCompact",
) -> str:
    """Return row counts per file at s3_path, ordered descending."""
    s3_expr = build_s3_expr(s3_path, creds, fmt)
    sql = (
        f"SELECT _file, count() AS count, "
        f"formatReadableQuantity(count) AS readable_count "
        f"FROM {s3_expr} "
        f"GROUP BY _file "
        f"ORDER BY count DESC "
        f"SETTINGS output_format_pretty_row_numbers=0"
    )
    return run_query(sql, output_format)


def run_user_query(
    sql_template: str,
    s3_path: str,
    creds: dict | None,
    fmt: str | None = None,
    output_format: str = "PrettyCompact",
) -> str:
    """Run user-supplied SQL against files at s3_path.

    Use {table} in your SQL as the placeholder for the s3() expression.
    Escape literal curly braces in SQL as {{ and }}.

    Example:
        run_user_query(
            "SELECT col1, count() AS n FROM {table} GROUP BY col1",
            "s3://bucket/data/*.parquet",
            creds,
        )
    """
    s3_expr = build_s3_expr(s3_path, creds, fmt)
    try:
        sql = sql_template.format_map({"table": s3_expr})
    except KeyError as exc:
        raise ValueError(
            f"Unknown placeholder {exc} in SQL template. "
            "Use only {table} as a placeholder. "
            "Escape literal braces as {{ and }}."
        ) from exc
    return run_query(sql, output_format)


def list_files(
    s3_path: str,
    profile: str | None = None,
) -> list[dict]:
    """List files at an S3 prefix using boto3.

    Returns a list of dicts with keys: key, size_bytes, last_modified.
    Automatically falls back to anonymous/unsigned access for public buckets
    when no profile is provided and no credentials are found.
    Does not use chDB — pure boto3.
    """
    parsed = urllib.parse.urlparse(s3_path)
    bucket = parsed.netloc
    prefix = parsed.path.lstrip("/")
    if "*" in prefix:
        prefix = prefix[: prefix.index("*")]

    def _paginate(s3_client) -> list[dict]:
        paginator = s3_client.get_paginator("list_objects_v2")
        files = []
        for page in paginator.paginate(Bucket=bucket, Prefix=prefix):
            for obj in page.get("Contents", []):
                files.append(
                    {
                        "key":           obj["Key"],
                        "size_bytes":    obj["Size"],
                        "last_modified": obj["LastModified"].isoformat(),
                    }
                )
        return files

    session = boto3.Session(profile_name=profile)
    try:
        return _paginate(session.client("s3"))
    except botocore.exceptions.NoCredentialsError:
        if profile is not None:
            raise RuntimeError(
                f"No credentials found for profile {profile!r}. "
                f"Run: aws sso login --profile {profile}"
            )
        # No profile specified — retry with unsigned (public bucket)
        print("No credentials found — trying anonymous access.", file=sys.stderr)
        return _paginate(boto3.client("s3", config=UNSIGNED))
    except botocore.exceptions.ClientError as exc:
        code = exc.response.get("Error", {}).get("Code", "")
        if code in ("AccessDenied", "403"):
            raise RuntimeError(
                f"Access denied to {s3_path!r}. "
                "Provide --profile to authenticate."
            ) from exc
        raise


# ---------------------------------------------------------------------------
# Output format helpers
# ---------------------------------------------------------------------------

def _chdb_output_format(fmt: str) -> str:
    """Map CLI --format flag to chDB output format name."""
    return {"table": "PrettyCompact", "json": "JSONEachRow", "csv": "CSVWithNames"}[fmt]


def _resolve_creds(profile: str | None) -> dict | None:
    """Resolve credentials for CLI commands.

    When profile is None and no credentials are available, returns None so
    that queries run against public S3 buckets without authentication.
    """
    try:
        return get_credentials(profile)
    except RuntimeError:
        if profile is not None:
            raise
        print(
            "No credentials found — querying as public/anonymous.",
            file=sys.stderr,
        )
        return None


def _print_ls_output(files: list[dict], fmt: str) -> None:
    if fmt == "json":
        for f in files:
            click.echo(json.dumps(f))
    elif fmt == "csv":
        click.echo("key,size_bytes,last_modified")
        for f in files:
            click.echo(f"{f['key']},{f['size_bytes']},{f['last_modified']}")
    else:
        if not files:
            click.echo("(no files found)")
            return
        max_key = max(len(f["key"]) for f in files)
        header = f"{'key':<{max_key}}  {'size_bytes':>12}  last_modified"
        click.echo(header)
        click.echo("-" * len(header))
        for f in files:
            click.echo(
                f"{f['key']:<{max_key}}  {f['size_bytes']:>12,}  {f['last_modified']}"
            )


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

@click.group()
@click.option(
    "--profile", "-p",
    default=None,
    envvar="AWS_PROFILE",
    help="AWS named profile (SSO or standard). Falls back to AWS_PROFILE env var.",
)
@click.option(
    "--format", "-f", "output_format",
    type=click.Choice(["table", "json", "csv"]),
    default="table",
    show_default=True,
    help="Output format. Use 'json' for LLM/pipe consumption.",
)
@click.pass_context
def cli(ctx: click.Context, profile: str | None, output_format: str) -> None:
    """s3explore — query S3 files directly with SQL, no infrastructure needed.

    Powered by chDB (ClickHouse embedded) + boto3.

    \b
    Recommended workflow:
      1. ls      — confirm files exist
      2. schema  — understand column names and types
      3. count   — see row distribution across files
      4. sample  — inspect representative rows
      5. query   — run targeted SQL
    """
    ctx.ensure_object(dict)
    ctx.obj["profile"] = profile
    ctx.obj["output_format"] = output_format


@cli.command()
@click.argument("s3_path")
@click.pass_context
def ls(ctx: click.Context, s3_path: str) -> None:
    """List files at S3_PATH using boto3.

    \b
    Example:
      python s3explore.py ls s3://my-bucket/data/year=2025/
    """
    profile = ctx.obj["profile"]
    fmt = ctx.obj["output_format"]
    try:
        files = list_files(s3_path, profile=profile)
        _print_ls_output(files, fmt)
    except Exception as exc:
        raise click.ClickException(str(exc))


@cli.command()
@click.argument("s3_path")
@click.option("--fmt", default=None, help="Override auto-detected file format (e.g. Parquet, JSONEachRow).")
@click.pass_context
def schema(ctx: click.Context, s3_path: str, fmt: str | None) -> None:
    """Show column names and types for files at S3_PATH.

    \b
    Example:
      python s3explore.py schema s3://my-bucket/data/*.parquet
      python s3explore.py --format json schema s3://my-bucket/data/*.parquet
    """
    profile = ctx.obj["profile"]
    out_fmt = _chdb_output_format(ctx.obj["output_format"])
    try:
        creds = _resolve_creds(profile)
        result = get_schema(s3_path, creds, fmt=fmt, output_format=out_fmt)
        click.echo(result, nl=False)
    except (RuntimeError, ValueError) as exc:
        raise click.ClickException(str(exc))


@cli.command()
@click.argument("s3_path")
@click.option("-n", "--rows", default=10, show_default=True, help="Number of rows to return.")
@click.option("--fmt", default=None, help="Override auto-detected file format.")
@click.pass_context
def sample(ctx: click.Context, s3_path: str, rows: int, fmt: str | None) -> None:
    """Show N sample rows from files at S3_PATH.

    \b
    Example:
      python s3explore.py sample s3://my-bucket/data/*.parquet
      python s3explore.py sample --rows 50 s3://my-bucket/data/*.parquet
    """
    profile = ctx.obj["profile"]
    out_fmt = _chdb_output_format(ctx.obj["output_format"])
    try:
        creds = _resolve_creds(profile)
        result = sample_rows(s3_path, creds, n=rows, fmt=fmt, output_format=out_fmt)
        click.echo(result, nl=False)
    except (RuntimeError, ValueError) as exc:
        raise click.ClickException(str(exc))


@cli.command()
@click.argument("s3_path")
@click.option("--fmt", default=None, help="Override auto-detected file format.")
@click.pass_context
def count(ctx: click.Context, s3_path: str, fmt: str | None) -> None:
    """Count rows per file at S3_PATH.

    Uses the ClickHouse _file meta-column to group by filename.

    \b
    Example:
      python s3explore.py count s3://my-bucket/data/*.parquet
    """
    profile = ctx.obj["profile"]
    out_fmt = _chdb_output_format(ctx.obj["output_format"])
    try:
        creds = _resolve_creds(profile)
        result = count_per_file(s3_path, creds, fmt=fmt, output_format=out_fmt)
        click.echo(result, nl=False)
    except (RuntimeError, ValueError) as exc:
        raise click.ClickException(str(exc))


@cli.command()
@click.argument("s3_path")
@click.option(
    "--sql", "-q",
    required=True,
    help=(
        "SQL to run. Use {table} where the s3(...) expression goes. "
        "Escape literal braces as {{ and }}. "
        'Example: --sql "SELECT col, count() FROM {table} GROUP BY col"'
    ),
)
@click.option("--fmt", default=None, help="Override auto-detected file format.")
@click.pass_context
def query(ctx: click.Context, s3_path: str, sql: str, fmt: str | None) -> None:
    """Run custom SQL against files at S3_PATH.

    Write your SELECT using {table} as the placeholder for the s3() call.
    Escape any literal { or } in your SQL as {{ or }}.

    \b
    Example:
      s3explore query s3://my-bucket/data/*.parquet \\
        --sql "SELECT col1, count() AS n FROM {table} GROUP BY col1 ORDER BY n DESC"
    """
    profile = ctx.obj["profile"]
    out_fmt = _chdb_output_format(ctx.obj["output_format"])
    try:
        creds = _resolve_creds(profile)
        result = run_user_query(sql, s3_path, creds, fmt=fmt, output_format=out_fmt)
        click.echo(result, nl=False)
    except (RuntimeError, ValueError) as exc:
        raise click.ClickException(str(exc))


if __name__ == "__main__":
    cli()
