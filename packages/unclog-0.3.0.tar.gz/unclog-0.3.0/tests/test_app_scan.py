from __future__ import annotations

import json
from pathlib import Path

import pytest

from unclog.app import run_scan
from unclog.util.paths import claude_home


@pytest.fixture(autouse=True)
def _clear_cache() -> None:
    claude_home.cache_clear()


def _build_minimal_home(tmp_path: Path) -> Path:
    home = tmp_path / ".claude"
    home.mkdir()
    (home / ".claude.json").write_text(
        json.dumps(
            {
                "mcpServers": {
                    "github": {"command": "npx", "args": ["-y", "x"]},
                    "notion": {"command": "notion-mcp"},
                },
                "projects": {
                    "/Users/tom/draper": {"lastSessionId": "abc"},
                },
                "numStartups": 17,
            }
        ),
        encoding="utf-8",
    )
    skills = home / "skills" / "code-reviewer"
    skills.mkdir(parents=True)
    (skills / "SKILL.md").write_text(
        "---\nname: code-reviewer\ndescription: Reviews PRs.\n---\nbody\n",
        encoding="utf-8",
    )

    agents = home / "agents"
    agents.mkdir()
    (agents / "planner.md").write_text(
        "---\nname: planner\ndescription: plans work\n---\n", encoding="utf-8"
    )

    commands = home / "commands"
    commands.mkdir()
    (commands / "ship.md").write_text(
        "---\nname: ship\ndescription: Ship the current branch\n---\nbody\n",
        encoding="utf-8",
    )

    return home


def test_run_scan_builds_state_from_fixture(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    home = _build_minimal_home(tmp_path)
    monkeypatch.setenv("CLAUDE_CONFIG_DIR", str(home))

    state = run_scan()
    assert state.claude_home == home.resolve()
    assert len(state.skills) == 1
    assert len(state.agents) == 1
    assert len(state.commands) == 1
    assert state.commands[0].slug == "ship"
    assert state.commands[0].description == "Ship the current branch"
    assert state.config is not None
    assert set(state.config.mcp_servers) == {"github", "notion"}


def test_run_scan_warns_when_home_missing(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    nowhere = tmp_path / "does-not-exist"
    monkeypatch.setenv("CLAUDE_CONFIG_DIR", str(nowhere))
    state = run_scan()
    assert any("does not exist" in w for w in state.warnings)
    assert state.agents == ()
    assert state.skills == ()


def test_run_scan_degrades_on_malformed_claude_json(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    home = tmp_path / ".claude"
    home.mkdir()
    (home / ".claude.json").write_text("{ not valid", encoding="utf-8")
    monkeypatch.setenv("CLAUDE_CONFIG_DIR", str(home))

    state = run_scan()
    # Config parse error is captured as a warning, not raised — the rest
    # of the scan still runs.
    assert state.config is None
    assert any("Could not parse" in w for w in state.warnings)


def test_run_scan_attributes_mcp_tokens_from_latest_session(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    home = _build_minimal_home(tmp_path)
    session_dir = home / "projects" / "-Users-tom-draper"
    session_dir.mkdir(parents=True)
    (session_dir / "abc.jsonl").write_text(
        json.dumps({"type": "system", "content": "You are Claude Code."})
        + "\n"
        + json.dumps(
            {
                "type": "user",
                "tools": [
                    {
                        "name": "mcp__github__list_repos",
                        "description": "list repos",
                        "input_schema": {"type": "object"},
                    },
                    {
                        "name": "Read",
                        "description": "builtin",
                        "input_schema": {"type": "object"},
                    },
                ],
            }
        )
        + "\n",
        encoding="utf-8",
    )
    monkeypatch.setenv("CLAUDE_CONFIG_DIR", str(home))

    state = run_scan()
    assert "github" in state.mcp_session_tokens
    assert state.mcp_session_tokens["github"] > 0
    # Built-in tools (no mcp__ prefix) are skipped.
    assert "Read" not in state.mcp_session_tokens


def test_run_scan_does_not_perform_invocation_walk(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    """run_scan stays fast: the 30-day MCP-invocation walk is now
    launched on a background thread by the CLI. State leaves
    mcp_invocation_counts empty until the walker completes."""
    home = _build_minimal_home(tmp_path)
    monkeypatch.setenv("CLAUDE_CONFIG_DIR", str(home))

    state = run_scan()
    assert dict(state.mcp_invocation_counts) == {}
