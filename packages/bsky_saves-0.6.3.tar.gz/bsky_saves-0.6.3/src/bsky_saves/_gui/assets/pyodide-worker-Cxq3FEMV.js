(function(){"use strict";const f=self;let s=null,o=!1;const i=t=>f.postMessage(t),r=t=>i({type:"log",line:t}),a="/home/pyodide/saves_inventory.json";async function p(t){if(s)return;r("Loading Pyodide…");const e=`https://cdn.jsdelivr.net/pyodide/v${t}/full/`;s=await(await import(`${e}pyodide.mjs`)).loadPyodide({indexURL:e}),s.globals.set("_log_emit",_=>r(_)),await s.runPythonAsync(`
import sys
class _LineWriter:
    def __init__(self, fn):
        self._fn = fn
        self._buf = ''
    def write(self, s):
        self._buf += s
        while '\\n' in self._buf:
            line, self._buf = self._buf.split('\\n', 1)
            line = line.rstrip()
            if line:
                self._fn(line)
        return len(s)
    def flush(self):
        line = self._buf.rstrip()
        self._buf = ''
        if line:
            self._fn(line)
    def isatty(self):
        return False
    def writable(self):
        return True
    def readable(self):
        return False
    def fileno(self):
        raise OSError('LineWriter has no fileno')
sys.stdout = _LineWriter(_log_emit)
sys.stderr = _LineWriter(_log_emit)
`),r("Installing native packages…"),await s.loadPackage(["micropip","ssl"]),r("Installing bsky-saves…"),await s.runPythonAsync(`
import micropip
await micropip.install('pyodide-http')
import pyodide_http
pyodide_http.patch_all()
await micropip.install('httpx')
await micropip.install('bsky-saves==0.4.3', deps=False)

# pyodide-http patches urllib/urllib3/requests but NOT httpx, which uses
# httpcore that tries raw sockets. Replace the httpx surface bsky-saves
# touches with a urllib-backed shim so its requests go through the patched
# fetch pipe.
import httpx as _httpx
import urllib.request as _ureq
import urllib.error as _uerr
from urllib.parse import urlencode as _urlencode
import json as _json

class _ShimResponse:
    def __init__(self, status_code, headers, content):
        self.status_code = status_code
        self.headers = headers
        self.content = content
        self.text = content.decode('utf-8', errors='replace') if content else ''
    def json(self):
        return _json.loads(self.text)
    def raise_for_status(self):
        if not (200 <= self.status_code < 400):
            raise _httpx.HTTPStatusError(
                f'HTTP {self.status_code}', request=None, response=self
            )

def _shim_request(method, url, *, json=None, data=None, headers=None, params=None, **_):
    h = dict(headers) if headers else {}
    body = None
    if json is not None:
        body = _json.dumps(json).encode('utf-8')
        h.setdefault('content-type', 'application/json')
    elif data is not None:
        if isinstance(data, (bytes, bytearray)):
            body = bytes(data)
        elif isinstance(data, str):
            body = data.encode('utf-8')
        else:
            body = _urlencode(data).encode('utf-8')
            h.setdefault('content-type', 'application/x-www-form-urlencoded')
    if params:
        url = url + ('&' if '?' in url else '?') + _urlencode(params)
    req = _ureq.Request(url, data=body, headers=h, method=method)
    try:
        r = _ureq.urlopen(req)
        return _ShimResponse(r.status, dict(r.headers), r.read())
    except _uerr.HTTPError as e:
        return _ShimResponse(e.code, dict(e.headers), e.read())

_httpx.post = lambda url, **kw: _shim_request('POST', url, **kw)
_httpx.get  = lambda url, **kw: _shim_request('GET', url, **kw)
_httpx.put  = lambda url, **kw: _shim_request('PUT', url, **kw)
_httpx.delete = lambda url, **kw: _shim_request('DELETE', url, **kw)

class _ShimClient:
    def __init__(self, *args, **kw):
        self._headers = dict(kw.get('headers') or {})
    def __enter__(self):
        return self
    def __exit__(self, *_):
        return False
    def close(self):
        pass
    def request(self, method, url, **kw):
        kw['headers'] = {**self._headers, **(kw.get('headers') or {})}
        return _shim_request(method, url, **kw)
    def get(self, url, **kw):
        return self.request('GET', url, **kw)
    def post(self, url, **kw):
        return self.request('POST', url, **kw)
    def put(self, url, **kw):
        return self.request('PUT', url, **kw)
    def delete(self, url, **kw):
        return self.request('DELETE', url, **kw)

_httpx.Client = _ShimClient

import os
os.makedirs('/home/pyodide', exist_ok=True)
os.chdir('/home/pyodide')
`)}async function u(t){if(!t)return;if(!s)throw new Error("Worker not initialised");const e=JSON.stringify(t);await s.runPythonAsync(`
import bsky_saves.auth as _bsky_auth
import bsky_saves.fetch as _bsky_fetch
import json as _json
_preauth = _json.loads(${JSON.stringify(e)})
def _patched_create_session(pds_base, handle, app_password):
    return _preauth
_bsky_auth.create_session = _patched_create_session
_bsky_fetch.create_session = _patched_create_session
print('reusing pre-authenticated session from main thread')
`)}async function h(t,e,n){if(!s)throw new Error("Worker not initialised");await s.runPythonAsync(`
import os
os.environ['BSKY_HANDLE'] = ${JSON.stringify(t)}
os.environ['BSKY_APP_PASSWORD'] = ${JSON.stringify(e)}
os.environ['BSKY_PDS'] = ${JSON.stringify(n)}
`)}function l(){if(!s)throw new Error("Worker not initialised");const t=s.FS.readFile(a,{encoding:"utf8"});return JSON.parse(t)}async function y(t){if(!s)throw new Error("Worker not initialised");await u(t.preauthSession),await h(t.handle,t.appPassword,t.pds),r("Fetching saves…"),await s.runPythonAsync(`
from pathlib import Path
import bsky_saves.fetch as _bsky_fetch
import os
_bsky_fetch.fetch_to_inventory(
    Path('${a}'),
    handle=os.environ['BSKY_HANDLE'],
    app_password=os.environ['BSKY_APP_PASSWORD'],
    pds_base=os.environ['BSKY_PDS'],
)
`),r("Reading inventory…");const e=l();return r("Done."),e}async function m(t){if(!s)throw new Error("Worker not initialised");const e=JSON.stringify(t.inventory);await s.runPythonAsync(`
with open('${a}', 'w') as _f:
    _f.write(${JSON.stringify(e)})
`),r("Enriching…"),await s.runPythonAsync(`
from pathlib import Path
import bsky_saves.enrich as _bsky_enrich
_bsky_enrich.enrich_inventory(Path('${a}'))
`),r("Reading inventory…");const n=l();return r("Done."),n}const w=3;async function b(t){if(!s)throw new Error("Worker not initialised");await u(t.preauthSession),await h(t.handle,t.appPassword,t.pds);const e=JSON.stringify(t.inventory);await s.runPythonAsync(`
with open('${a}', 'w') as _f:
    _f.write(${JSON.stringify(e)})
`),r("Hydrating threads…"),o=!1,await s.runPythonAsync(`
from pathlib import Path
import bsky_saves.threads as _bsky_threads
import json as _bsj
_inv_path = Path('${a}')
`);let n=0,d=0;for(;!o;){const k=await s.runPythonAsync(`_bsj.dumps(list(_bsky_threads.hydrate_threads(_inv_path, limit=${w})))`),[g,P,c]=JSON.parse(k);if(n+=g,d+=P,i({type:"progress",succeeded:n,failed:d,remaining:c}),c===0)break;await new Promise(S=>setTimeout(S,0))}r("Reading inventory…");const _=l();return r("Done."),_}f.addEventListener("message",async t=>{try{const e=t.data;if(e.type==="cancel-hydration"){o=!0;return}if(e.type==="init")await p(e.pyodideVersion),i({type:"init-ready"});else if(e.type==="fetchOnly"){const n=await y(e.input);i({type:"result",payload:n})}else if(e.type==="enrichOnly"){const n=await m(e.input);i({type:"result",payload:n})}else if(e.type==="threadsOnly"){const n=await b(e.input);i({type:"result",payload:n})}}catch(e){i({type:"error",message:e instanceof Error?e.message:String(e),name:e instanceof Error?e.name:"Error"})}})})();
//# sourceMappingURL=pyodide-worker-Cxq3FEMV.js.map
