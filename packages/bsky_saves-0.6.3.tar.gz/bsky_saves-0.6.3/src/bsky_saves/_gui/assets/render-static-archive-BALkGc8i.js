import{f as x,a as k,b as w,c as q}from"./bsky-permalink-B26b4C1a.js";import{ag as v,O as P,aw as B}from"./main-BxPAh2Aj.js";function l(t){return t.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#39;")}const m=l;function L(t){const e=t.trim();if(!e)return[];const a=e.split(/\n\s*\n/).map(r=>r.trim()).filter(Boolean);return a.length>1?a:e.split(/\n/).map(r=>r.trim()).filter(Boolean)}function S(t){const e=new Map;for(const a of t)e.set(a.url,`images/${a.filename}`);return e}function W(t,e){return t?e.get(t)??null:null}function H(t,e,a=""){return t.length===0?"":`<div class="post-body__images">
${t.map(o=>{const s=e.get(o.url),n=s?`${a}${s}`:o.url;return`<img src="${m(n)}" alt="${m(o.alt)}" loading="lazy">`}).join(`
`)}
</div>`}function h(t,...e){if(t===null||typeof t!="object")return null;const a=t;for(const r of e){const o=a[r];if(typeof o=="string"&&o.length>0)return o}return null}function I(t){if(t===null||typeof t!="object")return[];const e=t,a=[];if(Array.isArray(e.images)){for(const s of e.images){const n=h(s,"url","fullsize","thumb");if(!n)continue;const i=h(s,"alt")??"";a.push({url:n,alt:i})}if(a.length>0)return a}const r=e.embed;if(r&&typeof r=="object"){const s=r.images;if(Array.isArray(s))for(const n of s){const i=h(n,"fullsize","thumb","url");if(!i)continue;const c=h(n,"alt")??"";a.push({url:i,alt:c})}}const o=e.local_images;if(a.length===0&&Array.isArray(o))for(const s of o){const n=h(s,"path","url");n&&a.push({url:n,alt:""})}return a}function j(t,e,a=""){const r=h(t,"text","post_text")??"",o=h(t,"created_at","post_created_at")??"",s=h(typeof t=="object"&&t!==null?t.author:null,"handle"),n=o.slice(0,10),i=I(t);if(!r&&!s&&i.length===0)return"";const c=s?`<span class="quoted-post__handle">@${l(s)}</span>`:"",d=n?`<time class="quoted-post__time" datetime="${m(o)}">${l(n)}</time>`:"",p=r?`<p class="quoted-post__text">${l(r)}</p>`:"",g=H(i,e,a);return`<blockquote class="quoted-post">
<header class="quoted-post__header">${c}${d}</header>
${p}
${g}
</blockquote>`}function A(t){const e=P(t);return e.length===0?"":`<div class="lifecycle-badges">
${e.map(r=>`<span class="lifecycle-badge lifecycle-badge--${r}">${l(B(r))}</span>`).join(`
`)}
</div>`}function E(t){var a;return(a=t.article)!=null&&a.text?`<details class="post-body__article">
<summary>View backed-up article text</summary>
${L(t.article.text).map(r=>`<p>${l(r)}</p>`).join(`
`)}
</details>`:""}function U(t){const e=t.embed;if(!e||typeof e.url!="string"||!/^https?:\/\//.test(e.url))return"";const a=typeof e.title=="string"&&e.title.length>0?e.title:e.url;return`<p class="post-body__embed-link"><a href="${m(e.url)}" target="_blank" rel="noopener noreferrer">${l(a)}</a></p>`}function D(t,e,a=""){const r=t.record.text,o=r?`<p class="post-body__text">${l(r)}</p>`:"",s=(t.local_images??[]).map(u=>({url:u.path,alt:""})),n=(()=>{const u=t.embed;return Array.isArray(u==null?void 0:u.images)?u.images.map(f=>({url:f.fullsize??f.thumb??"",alt:f.alt??""})).filter(f=>f.url):[]})(),i=(()=>{const u=t.images;return Array.isArray(u)?u.map(f=>{const y=f;return{url:y.url??"",alt:y.alt??""}}).filter(f=>f.url):[]})(),c=s.length>0?s:n.length>0?n:i,d=H(c,e,a),p=t.quoted_post??null,g=p?j(p,e,a):"",b=U(t),_=E(t);return`<div class="post-body">
${o}
${d}
${g}
${b}
${_}
</div>`}function F(t,e,a=""){return!t||t.length===0?"":`<section class="post-focus__thread">
<h3>Thread</h3>
<ol>
${t.map(o=>{const s=o.record.createdAt?`<time datetime="${m(o.record.createdAt)}">${l(w(o.record.createdAt))}</time>`:"",n=o.record.text?`<p class="post-focus__thread-text">${l(o.record.text)}</p>`:"",i=(o.images??[]).map(d=>({url:d.url,alt:d.alt??""})),c=i.length>0?`<div class="post-focus__thread-images">
${i.map(d=>{const p=e.get(d.url),g=p?`${a}${p}`:d.url;return`<img src="${m(g)}" alt="${m(d.alt)}" loading="lazy">`}).join(`
`)}
</div>`:"";return`<li><header>${s}</header>${n}${c}</li>`}).join(`
`)}
</ol>
</section>`}function z(t,e,a=""){const r=l(x(t.author)),o=l(k(t.author.handle)),s=t.record.createdAt,n=`<time class="post-focus__time" datetime="${m(s)}">${l(w(s))}</time>`,i=q(t),c=D(t,e,a),d=F(t.thread,e,a),p=A(t);return`<article class="post-focus${p?" post-focus--flagged":""}">
${p}
<header class="post-focus__header">
<span class="post-focus__author">${r}</span>
<span class="post-focus__handle">${o}</span>
${n}
</header>
${c}
<p class="post-focus__link"><a href="${m(i)}" target="_blank" rel="noopener noreferrer">View on bsky.app</a></p>
${d}
</article>`}function M(t,e,a){const r=v(t.uri),o=x(t.author),s=k(t.author.handle),n=t.record.createdAt,i=t.record.text??"",c=m(`${i} ${o} ${s}`.toLowerCase()),d=l(o),p=l(s),g=`<time class="post-card__time" datetime="${m(n)}">${l(w(n))}</time>`,b=i.length>200?i.slice(0,200)+"…":i,_=`<p class="post-card__snippet">${l(b)}</p>`,u=a===""?"":`${a}${r}.html`,f=u?`<a class="post-card__view-link" href="${m(u)}">View post →</a>`:"",y=A(t);return`<article class="post-card${y?" post-card--flagged":""}" id="post-${m(r)}" data-searchable="${c}">
${y}
<header class="post-card__header">
<span class="post-card__author">${d}</span>
<span class="post-card__handle">${p}</span>
${g}
</header>
${_}
${f}
</article>`}const O=`<input id="search" type="search" placeholder="Search saves…" class="search-input">
<script>
  document.getElementById('search').addEventListener('input', (e) => {
    const q = e.target.value.trim().toLowerCase();
    document.querySelectorAll('[data-searchable]').forEach((el) => {
      el.hidden = q && !el.dataset.searchable.includes(q);
    });
  });
<\/script>`,T=`
/* === Reset & base === */
*, *::before, *::after { box-sizing: border-box; }
html { color-scheme: light dark; }
body {
  margin: 0;
  font-family: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
  font-size: 1rem;
  line-height: 1.5;
  background: Canvas;
  color: CanvasText;
}
a { color: inherit; }
img { display: block; max-width: 100%; }

/* === Layout === */
.archive-header {
  padding: 1.5rem 1.5rem 0.5rem;
  border-bottom: 1px solid color-mix(in oklab, CanvasText 12%, transparent);
  margin-bottom: 1.5rem;
}
.archive-header h1 {
  margin: 0 0 0.25rem;
  font-size: 1.5rem;
}
.archive-header p { margin: 0; opacity: 0.7; font-size: 0.9rem; }
.archive-main { padding: 0 1.5rem 3rem; max-width: 48rem; margin: 0 auto; }

/* === Search === */
.search-input {
  display: block;
  width: 100%;
  padding: 0.5rem 0.75rem;
  font: inherit;
  font-size: 1rem;
  border: 1px solid color-mix(in oklab, CanvasText 25%, transparent);
  border-radius: 6px;
  background: Canvas;
  color: CanvasText;
  margin-bottom: 1.25rem;
}
.search-input:focus { outline: 2px solid color-mix(in oklab, CanvasText 40%, Canvas); outline-offset: 1px; }

/* === Post card (index) === */
.post-card {
  border: 1px solid color-mix(in oklab, CanvasText 12%, transparent);
  border-radius: 8px;
  padding: 1rem;
  margin-bottom: 0.75rem;
}
.post-card__header {
  display: flex;
  flex-wrap: wrap;
  gap: 0.5rem;
  align-items: baseline;
  margin-bottom: 0.5rem;
  font-size: 0.875rem;
}
.post-card__author { font-weight: 600; }
.post-card__handle { opacity: 0.7; }
.post-card__time { margin-left: auto; opacity: 0.7; font-variant-numeric: tabular-nums; }
.post-card__snippet { margin: 0 0 0.5rem; white-space: pre-wrap; word-wrap: break-word; }
.post-card__view-link {
  display: inline-block;
  font-size: 0.875rem;
  text-decoration: none;
  opacity: 0.75;
}
.post-card__view-link:hover { opacity: 1; text-decoration: underline; }

/* === Lifecycle badges (v0.6.0 retain-flag) === */
/* A flagged post gets a faint warm tint, distinct from the cool grey tint
   used for quoted posts, plus Deleted/Blocked/Unsaved badges at the top. */
.post-card--flagged,
.post-focus--flagged {
  background: color-mix(in oklab, #b8860b 7%, Canvas);
}
.lifecycle-badges {
  display: flex;
  flex-wrap: wrap;
  gap: 0.35rem;
  margin-bottom: 0.5rem;
}
.lifecycle-badge {
  font-size: 0.7rem;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 0.05em;
  padding: 0.15rem 0.45rem;
  border-radius: 4px;
  border: 1px solid currentColor;
}
.lifecycle-badge--deleted,
.lifecycle-badge--blocked {
  color: color-mix(in oklab, #c0392b 80%, CanvasText);
  background: color-mix(in oklab, #c0392b 12%, Canvas);
}
.lifecycle-badge--unsaved {
  color: color-mix(in oklab, #b8860b 80%, CanvasText);
  background: color-mix(in oklab, #b8860b 12%, Canvas);
}

/* === Post focus (detail page) === */
.post-focus {
  border: 1px solid color-mix(in oklab, CanvasText 12%, transparent);
  border-radius: 8px;
  padding: 1rem;
  max-width: 44rem;
  margin: 0 auto;
}
.post-focus__header {
  display: flex;
  flex-wrap: wrap;
  gap: 0.5rem;
  align-items: baseline;
  margin-bottom: 0.5rem;
  font-size: 0.875rem;
}
.post-focus__author { font-weight: 600; }
.post-focus__handle { opacity: 0.7; }
.post-focus__time { margin-left: auto; opacity: 0.7; font-variant-numeric: tabular-nums; }
.post-focus__link { margin-top: 1rem; font-size: 0.9em; }
.post-focus__thread {
  margin-top: 1.5rem;
  border-top: 1px solid color-mix(in oklab, CanvasText 12%, transparent);
  padding-top: 1rem;
}
.post-focus__thread h3 {
  margin: 0 0 0.5rem;
  font-size: 0.875rem;
  text-transform: uppercase;
  letter-spacing: 0.05em;
  opacity: 0.7;
}
.post-focus__thread ol { list-style: none; padding: 0; margin: 0; }
.post-focus__thread li {
  border-left: 3px solid color-mix(in oklab, CanvasText 15%, transparent);
  padding: 0.5rem 0 0.5rem 0.75rem;
  margin-bottom: 0.75rem;
}
.post-focus__thread header { display: flex; flex-wrap: wrap; gap: 0.5rem; align-items: baseline; font-size: 0.875rem; }
.post-focus__thread time { margin-left: auto; opacity: 0.7; }
.post-focus__thread-text { margin: 0.25rem 0 0; white-space: pre-wrap; }
.post-focus__thread-images {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(160px, 1fr));
  gap: 0.5rem;
  margin-top: 0.5rem;
}
.post-focus__thread-images img { width: 100%; border-radius: 6px; object-fit: cover; }

/* === Post body === */
.post-body__text { margin: 0; white-space: pre-wrap; word-wrap: break-word; }
.post-body__images {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 0.5rem;
  margin-top: 0.75rem;
}
.post-body__images img { width: 100%; border-radius: 6px; object-fit: cover; }
.post-body__embed-link { margin-top: 0.5rem; font-size: 0.9rem; }
.post-body__embed-link a { color: inherit; text-decoration: underline; word-break: break-word; opacity: 0.85; }
.post-body__embed-link a:hover { opacity: 1; }
.post-body__article {
  margin-top: 0.75rem;
  padding: 0.5rem 0.75rem;
  background: color-mix(in oklab, CanvasText 5%, Canvas);
  border-radius: 6px;
  font-size: 0.9em;
}
.post-body__article summary { cursor: pointer; font-weight: 500; }
.post-body__article p { margin: 0.5rem 0 0; white-space: pre-wrap; }
.post-body__article p + p { margin-top: 0.85rem; }

/* === Quoted post === */
.quoted-post {
  margin: 0.75rem 0 0;
  padding: 0.75rem;
  border: 1px solid color-mix(in oklab, CanvasText 12%, transparent);
  border-radius: 6px;
  background: color-mix(in oklab, CanvasText 4%, Canvas);
  font-size: 0.95em;
}
.quoted-post__header {
  display: flex;
  flex-wrap: wrap;
  gap: 0.5rem;
  align-items: baseline;
  font-size: 0.875rem;
  margin-bottom: 0.4rem;
}
.quoted-post__handle { font-weight: 500; opacity: 0.8; }
.quoted-post__time { margin-left: auto; opacity: 0.65; font-variant-numeric: tabular-nums; }
.quoted-post__text { margin: 0; white-space: pre-wrap; word-wrap: break-word; }
.quoted-post__images {
  margin-top: 0.5rem;
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(160px, 1fr));
  gap: 0.4rem;
}
.quoted-post__images img { width: 100%; border-radius: 4px; object-fit: cover; }

/* === Post page nav === */
.post-page-back {
  display: inline-block;
  margin-bottom: 1rem;
  opacity: 0.8;
  text-decoration: none;
  font-size: 0.9rem;
}
.post-page-back:hover { opacity: 1; text-decoration: underline; }
`;function $(t,e,a){const r=e!=null?`<style>
${e}
</style>`:a!=null?`<link rel="stylesheet" href="${m(a)}">`:"";return`<!doctype html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="color-scheme" content="light dark">
<title>${l(t)}</title>
${r}
</head>`}function C(t,e,a){const r="Bluesky Saves Archive",o=t.length,s=a==="multi"?"posts/":"",n=t.map(c=>{if(a==="single"){const d=v(c.uri),p=c.record.text??"",g=x(c.author),b=k(c.author.handle),_=m(`${p} ${g} ${b}`.toLowerCase()),u=z(c,e,"");return`<div class="post-card__detail" id="post-${m(d)}" data-searchable="${_}">
${u}
</div>`}return M(c,e,s)}).join(`
`);return`${a==="single"?$(r,T,null):$(r,null,"styles.css")}
<body>
<header class="archive-header">
<h1>${l(r)}</h1>
<p>${o} saved post${o===1?"":"s"}</p>
</header>
<main class="archive-main">
${O}
${n}
</main>
</body>
</html>`}function V(t,e){const r=`${x(t.author)} — Bluesky Saves Archive`,o=z(t,e,"../");return`${$(r,null,"../styles.css")}
<body>
<main class="archive-main">
<a class="post-page-back" href="../index.html">← Back to library</a>
${o}
</main>
</body>
</html>`}function Y(t){const{inventory:e,imageFiles:a}=t,r=S(a);if(a.length===0)return{kind:"html",html:C(e.saves,r,"single")};const o=new Map;o.set("index.html",C(e.saves,r,"multi")),o.set("styles.css",T);for(const s of e.saves){let n;try{n=v(s.uri)}catch{continue}o.set(`posts/${n}.html`,V(s,r))}return{kind:"files",files:o}}export{T as STYLES,m as escapeAttr,l as escapeHtml,E as renderArticleDetails,U as renderEmbedLink,H as renderImages,C as renderIndex,A as renderLifecycleBadges,D as renderPostBody,M as renderPostCardSummary,z as renderPostFocusContent,V as renderPostPage,j as renderQuotedPost,Y as renderStaticArchive,F as renderThread,L as splitParagraphs,W as urlToLocalPath};
//# sourceMappingURL=render-static-archive-BALkGc8i.js.map
