BASE_URL = "https://anikai.to"
ALT_URLS = [
    "https://animekai.to",
    "https://animekai.fi",
    "https://animekai.fo",
    "https://animekai.gs",
    "https://animekai.la",
    "https://animekai.bz",
]

ENCODE_URL = "https://enc-dec.app/api/enc-kai"
DECODE_KAI_URL = "https://enc-dec.app/api/dec-kai"
DECODE_MEGA_URL = "https://enc-dec.app/api/dec-mega"

DEFAULT_USER_AGENT = (
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36"
)

STREAM_TYPES = {
    "sub": "Subtitled (Sub)",
    "dub": "Dubbed (Dub)",
    "softsub": "Soft-subbed (SoftSub)",
}

DEFAULT_DOWNLOAD_DIR = "."
