"""
Config manager for animekai-dl-tmux.
Reads/writes ~/.config/animekai-dl/config.ini
"""

import configparser
import os
from pathlib import Path

CONFIG_DIR = Path.home() / ".config" / "animekai-dl"
CONFIG_FILE = CONFIG_DIR / "config.ini"
CACHE_DIR = Path.home() / ".cache" / "animekai-dl"

DEFAULTS = {
    "site": {
        "base_url": "https://anikai.to",
    },
    "download": {
        "directory": str(Path.home() / "Downloads" / "Anime"),
        "threads": "4",
        "quality": "best",
    },
    "stream": {
        "type": "",
        "player": "mpv",
        "auto_server": "1",
        "server_retries": "3",
    },
    "behavior": {
        "interactive": "true",
        "verbose": "false",
    },
}

_COMMENTS = {
    ("site", "base_url"): (
        "AnimeKAI domain — update here if the site moves to a new URL\n"
        "# Alternatives: https://animekai.to, https://animekai.fi, "
        "https://animekai.fo, https://animekai.gs"
    ),
    ("download", "directory"): "Where to save downloaded episodes",
    ("download", "threads"): "Parallel threads for browse/preload (1-16)",
    ("download", "quality"): "Preferred quality: best, 1080p, 720p, 480p, 360p",
    ("stream", "type"): "Preferred stream type: sub, dub, softsub (blank = ask each time)",
    ("stream", "player"): "Media player for --play mode (mpv recommended on Termux)",
    ("stream", "auto_server"): "Auto-select server index (1 = first server)",
    ("stream", "server_retries"): "How many servers to try before giving up on an episode",
    ("behavior", "interactive"): "Show interactive prompts (true/false)",
    ("behavior", "verbose"): "Enable debug output (true/false)",
}


def _ensure_config() -> configparser.ConfigParser:
    cfg = configparser.ConfigParser()
    for section, values in DEFAULTS.items():
        cfg[section] = values
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    if CONFIG_FILE.exists():
        cfg.read(CONFIG_FILE)
    else:
        _write_config(cfg)
    return cfg


def _write_config(cfg: configparser.ConfigParser):
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    with open(CONFIG_FILE, "w") as f:
        f.write("# animekai-dl-tmux configuration\n")
        f.write("# Edit with: animekai --config edit\n\n")
        for section in cfg.sections():
            f.write(f"[{section}]\n")
            for key in cfg[section]:
                comment = _COMMENTS.get((section, key))
                if comment:
                    for line in comment.split("\n"):
                        f.write(f"# {line}\n")
                f.write(f"{key} = {cfg[section][key]}\n")
            f.write("\n")


def load_config() -> configparser.ConfigParser:
    return _ensure_config()


def get(section: str, key: str, fallback=None):
    cfg = _ensure_config()
    return cfg.get(section, key, fallback=fallback)


def get_base_url() -> str:
    return get("site", "base_url", fallback="https://anikai.to").rstrip("/")


def get_download_dir() -> str:
    val = get("download", "directory", fallback=str(Path.home() / "Downloads" / "Anime"))
    return os.path.expanduser(val)


def get_threads() -> int:
    try:
        return max(1, min(16, int(get("download", "threads", fallback="4"))))
    except (ValueError, TypeError):
        return 4


def get_quality() -> str:
    return get("download", "quality", fallback="best")


def get_stream_type():
    val = get("stream", "type", fallback="")
    return val.strip() if val and val.strip() else None


def get_player() -> str:
    return get("stream", "player", fallback="mpv")


def get_auto_server() -> int:
    try:
        return int(get("stream", "auto_server", fallback="1"))
    except (ValueError, TypeError):
        return 1


def get_server_retries() -> int:
    try:
        return max(1, int(get("stream", "server_retries", fallback="3")))
    except (ValueError, TypeError):
        return 3


def cmd_show_config():
    from rich.console import Console
    from rich.syntax import Syntax
    console = Console()
    _ensure_config()
    console.print(f"\n[bold cyan]Config file:[/bold cyan] {CONFIG_FILE}\n")
    if CONFIG_FILE.exists():
        content = CONFIG_FILE.read_text()
        console.print(Syntax(content, "ini", theme="monokai", line_numbers=True))
    else:
        console.print("[yellow]No config file found, showing defaults.[/yellow]")


def cmd_edit_config():
    import subprocess
    import shutil
    _ensure_config()
    editor = os.environ.get("EDITOR", "")
    for candidate in [editor, "nano", "vi", "vim"]:
        if candidate and shutil.which(candidate):
            subprocess.run([candidate, str(CONFIG_FILE)])
            return
    from rich.console import Console
    Console().print(f"[yellow]No editor found. Edit manually:[/yellow] {CONFIG_FILE}")
