import re
import os


def sanitize_filename(name: str) -> str:
    name = re.sub(r'[\\/*?:"<>|]', "", name)
    name = re.sub(r"\s+", " ", name).strip()
    return name


def get_anime_dir(anime_title: str, download_dir: str) -> str:
    return os.path.join(download_dir, sanitize_filename(anime_title))


def get_episode_path(anime_title: str, ep_num: str, ext: str, download_dir: str) -> str:
    ep_safe = ep_num.replace(".", "_")
    filename = f"{sanitize_filename(anime_title)} Episode {ep_safe}.{ext}"
    return os.path.join(get_anime_dir(anime_title, download_dir), filename)


def format_episode_label(ep: dict) -> str:
    num = ep.get("num", "?")
    title = ep.get("title", "")
    langs = ep.get("langs", "")
    tag = {"3": "[Sub+Dub]", "2": "[Sub+Dub]", "1": "[Sub]"}.get(langs, "")
    filler = " [FILLER]" if ep.get("filler") else ""
    if title:
        return f"Episode {num}: {title}{filler} {tag}".strip()
    return f"Episode {num}{filler} {tag}".strip()
