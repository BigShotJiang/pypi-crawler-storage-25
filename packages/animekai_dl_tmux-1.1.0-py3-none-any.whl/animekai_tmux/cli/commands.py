"""
Main CLI commands for animekai-dl-tmux.
"""

import os
import sys
from typing import List, Optional

from loguru import logger
from rich.console import Console
from rich.table import Table

from ..api import AnimeKAIClient, download_hls, stream_hls, check_ffmpeg
from ..api import fetch_all_anime, get_cache_info
from ..utils.constants import STREAM_TYPES
from ..utils.helpers import get_episode_path
from . import interactive

console = Console()


def _require_ffmpeg():
    if not check_ffmpeg():
        logger.error("ffmpeg is required but not found. Install: pkg install ffmpeg")
        sys.exit(1)


def cmd_search(
    query: str,
    base_url: str,
    download_dir: str,
    stream_type: Optional[str],
    preferred_server: Optional[str],
    quality: Optional[str],
    play: bool,
    player: str,
    auto_server: int,
    server_retries: int,
    episode_range: Optional[str],
    non_interactive: bool,
):
    """Search → select anime → download."""
    client = AnimeKAIClient(base_url=base_url)

    console.print(f"\n[bold cyan]Searching AnimeKAI for:[/bold cyan] {query}")
    results = client.search(query)
    if not results:
        logger.error("No results found.")
        return

    _print_search_results(results)

    if non_interactive:
        anime = results[0]
        console.print(f"[dim]Auto-selecting:[/dim] {anime['title']}")
    else:
        anime = interactive.pick_search_result(results)
        if not anime:
            return

    console.print(f"\n[bold green]Selected:[/bold green] {anime['title']}")
    _episode_flow(
        client=client, anime=anime,
        download_dir=download_dir, stream_type=stream_type,
        preferred_server=preferred_server, quality=quality,
        play=play, player=player,
        auto_server=auto_server, server_retries=server_retries,
        episode_range=episode_range, non_interactive=non_interactive,
    )


def cmd_browse(
    base_url: str,
    download_dir: str,
    stream_type: Optional[str],
    preferred_server: Optional[str],
    quality: Optional[str],
    play: bool,
    player: str,
    auto_server: int,
    server_retries: int,
    episode_range: Optional[str],
    non_interactive: bool,
    threads: int,
    force_refresh: bool = False,
):
    """Preload full anime list → local fzf search → download."""
    client = AnimeKAIClient(base_url=base_url)

    info = get_cache_info()
    if info["exists"]:
        age = info["age_hours"]
        status = "fresh" if info["fresh"] else "stale — refreshing now"
        console.print(f"[dim]Cache: {info['titles']} titles, {age}h old ({status})[/dim]")

    anime_list = fetch_all_anime(base_url=base_url, threads=threads, force_refresh=force_refresh)
    if not anime_list:
        logger.error("Could not load anime list.")
        return

    anime = interactive.pick_from_browse(anime_list)
    if not anime:
        return

    console.print(f"\n[bold green]Selected:[/bold green] {anime['title']}")
    _episode_flow(
        client=client, anime=anime,
        download_dir=download_dir, stream_type=stream_type,
        preferred_server=preferred_server, quality=quality,
        play=play, player=player,
        auto_server=auto_server, server_retries=server_retries,
        episode_range=episode_range, non_interactive=non_interactive,
    )


def _episode_flow(
    client: AnimeKAIClient,
    anime: dict,
    download_dir: str,
    stream_type: Optional[str],
    preferred_server: Optional[str],
    quality: Optional[str],
    play: bool,
    player: str,
    auto_server: int,
    server_retries: int,
    episode_range: Optional[str],
    non_interactive: bool,
):
    console.print("[dim]Fetching episode list...[/dim]")
    episodes = client.get_episodes(anime["path"])
    if not episodes:
        logger.error("No episodes found.")
        return

    console.print(f"[bold]Found {len(episodes)} episode(s)[/bold]")

    if episode_range:
        selected = _parse_episode_range(episodes, episode_range)
        if not selected:
            logger.error(f"No episodes matched range: {episode_range}")
            return
    elif non_interactive:
        selected = [episodes[0]]
    else:
        selected = interactive.pick_episodes(episodes)

    if not selected:
        logger.warning("No episodes selected.")
        return

    for ep in selected:
        _download_episode(
            client=client, anime=anime, ep=ep,
            download_dir=download_dir, stream_type=stream_type,
            preferred_server=preferred_server, quality=quality,
            play=play, player=player,
            auto_server=auto_server, server_retries=server_retries,
            non_interactive=non_interactive,
        )


def _download_episode(
    client: AnimeKAIClient,
    anime: dict,
    ep: dict,
    download_dir: str,
    stream_type: Optional[str],
    preferred_server: Optional[str],
    quality: Optional[str],
    play: bool,
    player: str,
    auto_server: int,
    server_retries: int,
    non_interactive: bool,
):
    ep_label = f"Episode {ep['num']}" + (f": {ep['title']}" if ep.get("title") else "")
    console.rule(f"[bold]{ep_label}[/bold]")

    # --- Fetch servers ---
    console.print("[dim]Fetching servers...[/dim]")
    try:
        servers_by_type = client.get_servers(ep["token"], anime["path"])
    except Exception as e:
        logger.error(f"Could not fetch servers: {e}")
        return

    if not servers_by_type:
        logger.error("No servers available for this episode.")
        return

    avail_types = list(servers_by_type.keys())

    # --- Pick stream type (sub/dub/softsub) ---
    if stream_type and stream_type in avail_types:
        chosen_type = stream_type
    elif non_interactive:
        chosen_type = avail_types[0]
    else:
        chosen_type = interactive.pick_stream_type(avail_types)
    if not chosen_type:
        return

    servers = servers_by_type.get(chosen_type, [])
    if not servers:
        logger.error(f"No servers of type '{chosen_type}'.")
        return

    # --- Build server order: user choice first, rest follow for failover ---
    if preferred_server:
        # CLI flag --server: put matching server first
        match = next((s for s in servers if preferred_server.lower() in s["name"].lower()), None)
        ordered = ([match] + [s for s in servers if s != match]) if match else servers
    elif non_interactive:
        # --no-interactive: use --auto-server index
        idx = max(0, min(auto_server - 1, len(servers) - 1))
        ordered = servers[idx:] + servers[:idx]
    else:
        # Interactive: user picks preferred server; others auto-tried if it fails
        if len(servers) == 1:
            ordered = servers
            console.print(f"[dim]Only one server available: {servers[0]['name']}[/dim]")
        else:
            picked = interactive.pick_server(servers)
            if picked is None:
                return
            ordered = [picked] + [s for s in servers if s != picked]

    # --- Try servers in order, failover automatically ---
    max_tries = min(server_retries, len(ordered))
    for attempt, srv in enumerate(ordered[:max_tries], start=1):
        if attempt > 1:
            console.print(
                f"[yellow]  → Trying next server ({attempt}/{max_tries}): {srv['name']}[/yellow]"
            )
        else:
            console.print(f"[dim]Server:[/dim] [bold]{chosen_type.upper()}[/bold] / {srv['name']}")

        try:
            console.print("[dim]Resolving embed URL...[/dim]")
            source = client.get_source(srv["lid"], anime["path"])
            embed_url = source.get("url", "")
            if not embed_url:
                logger.warning(f"'{srv['name']}' returned no embed URL.")
                continue

            console.print("[dim]Fetching stream variants...[/dim]")
            variants = client.get_m3u8_variants(embed_url)
            if not variants:
                logger.warning(f"'{srv['name']}' returned no stream variants.")
                continue

            # --- Pick quality ---
            if quality and quality.lower() != "best":
                variant = next(
                    (v for v in variants if quality.lower() in v["quality"].lower()),
                    variants[0],
                )
            elif non_interactive:
                variant = variants[0]
            else:
                variant = interactive.pick_quality(variants)
            if not variant:
                continue

            console.print(f"[bold green]Quality:[/bold green] {variant['quality']}  |  Server: {srv['name']}")

            # --- Stream or Download ---
            if play:
                stream_hls(variant["url"], player=player, referer=embed_url)
            else:
                _require_ffmpeg()
                out_path = get_episode_path(anime["title"], ep.get("num", "0"), "mp4", download_dir)
                console.print(f"[bold]Saving to:[/bold] {out_path}")
                ok = download_hls(variant["url"], out_path, referer=embed_url)
                if ok:
                    size_mb = os.path.getsize(out_path) // 1024 // 1024 if os.path.exists(out_path) else 0
                    console.print(f"[bold green]Done![/bold green] ({size_mb} MB)")
            return  # success — stop trying other servers

        except KeyboardInterrupt:
            raise
        except Exception as e:
            logger.warning(f"Server '{srv['name']}' failed: {e}")
            if attempt < max_tries:
                console.print("[dim]Trying next server automatically...[/dim]")

    logger.error(
        f"All {max_tries} server(s) tried for {ep_label} — none worked. "
        "Try a different stream type or check the site."
    )


def _parse_episode_range(episodes: list, range_str: str) -> list:
    nums = set()
    for part in range_str.split(","):
        part = part.strip()
        if "-" in part:
            a, b = part.split("-", 1)
            try:
                for i in range(int(a), int(b) + 1):
                    nums.add(str(i))
            except ValueError:
                pass
        else:
            nums.add(part)
    return [ep for ep in episodes if ep.get("num") in nums]


def _print_search_results(results: list):
    table = Table(title="Search Results", show_header=True, header_style="bold magenta")
    table.add_column("#", style="dim", width=4)
    table.add_column("Title", style="bold")
    table.add_column("Path", style="dim")
    for i, r in enumerate(results[:20], 1):
        table.add_row(str(i), r["title"], r["path"])
    console.print(table)
