"""
Interactive selection helpers using fzf (pyfzf) with questionary fallback.
"""

from typing import Dict, List, Optional

import questionary
from loguru import logger


def _fzf_available() -> bool:
    import shutil
    return shutil.which("fzf") is not None


def pick_one(prompt: str, choices: List[str]) -> Optional[str]:
    """Pick exactly one item. Uses fzf if available, else questionary."""
    if not choices:
        return None

    if _fzf_available():
        try:
            from pyfzf.pyfzf import FzfPrompt
            fzf = FzfPrompt()
            result = fzf.prompt(choices, f"--prompt='{prompt} > '")
            return result[0] if result else None
        except Exception as e:
            logger.debug(f"fzf error: {e}, falling back to questionary")

    return questionary.select(prompt, choices=choices).ask()


def pick_many(prompt: str, choices: List[str]) -> List[str]:
    """Pick multiple items. Uses fzf -m if available."""
    if not choices:
        return []

    if _fzf_available():
        try:
            from pyfzf.pyfzf import FzfPrompt
            fzf = FzfPrompt()
            result = fzf.prompt(choices, f"--multi --prompt='{prompt} > '")
            return result if result else []
        except Exception as e:
            logger.debug(f"fzf error: {e}, falling back to questionary")

    return questionary.checkbox(prompt, choices=choices).ask() or []


def pick_search_result(results: List[Dict]) -> Optional[Dict]:
    """Show search results and let user pick one."""
    if not results:
        logger.warning("No results found.")
        return None
    labels = [f"{r['title']}  ({r['path']})" for r in results]
    choice = pick_one("Select anime", labels)
    if choice is None:
        return None
    return results[labels.index(choice)]


def pick_from_browse(anime_list: List[Dict]) -> Optional[Dict]:
    """
    Browse the full anime list. Optimised for fzf type-to-filter.
    Falls back to questionary fuzzy select if fzf is unavailable.
    """
    if not anime_list:
        logger.warning("Anime list is empty.")
        return None

    labels = [f"{a['title']}" for a in anime_list]

    if _fzf_available():
        try:
            from pyfzf.pyfzf import FzfPrompt
            fzf = FzfPrompt()
            result = fzf.prompt(
                labels,
                "--prompt='Search anime > ' --preview='' --layout=reverse --info=inline",
            )
            if not result:
                return None
            chosen_label = result[0]
            for a in anime_list:
                if a["title"] == chosen_label:
                    return a
            return None
        except Exception as e:
            logger.debug(f"fzf browse error: {e}, falling back")

    # questionary fallback — autocomplete
    chosen = questionary.autocomplete(
        "Search anime (type to filter)",
        choices=labels,
        validate=lambda v: v in labels or "Select from list",
    ).ask()
    if not chosen:
        return None
    for a in anime_list:
        if a["title"] == chosen:
            return a
    return None


def pick_episodes(episodes: List[Dict]) -> List[Dict]:
    """Show episode list and let user pick one or more (fzf multi-select)."""
    from ..utils.helpers import format_episode_label
    if not episodes:
        logger.warning("No episodes found.")
        return []
    labels = [format_episode_label(ep) for ep in episodes]

    if _fzf_available():
        try:
            from pyfzf.pyfzf import FzfPrompt
            fzf = FzfPrompt()
            chosen = fzf.prompt(labels, "--multi --prompt='Select episodes (TAB=multi) > '")
        except Exception:
            chosen = []
    else:
        chosen = questionary.checkbox("Select episodes", choices=labels).ask() or []

    if not chosen:
        return []
    idx_map = {label: ep for label, ep in zip(labels, episodes)}
    return [idx_map[c] for c in chosen if c in idx_map]


def pick_stream_type(available_types: List[str]) -> Optional[str]:
    """Pick sub / dub / softsub."""
    from ..utils.constants import STREAM_TYPES
    choices = [f"{STREAM_TYPES.get(t, t.upper())} [{t}]" for t in available_types]
    if not choices:
        return None
    selected = pick_one("Select stream type", choices)
    if selected is None:
        return None
    for t in available_types:
        if f"[{t}]" in selected:
            return t
    return available_types[0]


def pick_server(servers: List[Dict]) -> Optional[Dict]:
    """
    Let the user pick a server from the full list.
    Shows index numbers so users know the order.
    If this server fails during download, the remaining servers are tried automatically.
    """
    if not servers:
        return None
    if len(servers) == 1:
        return servers[0]

    choices = [f"[{i+1}] {s['name']}" for i, s in enumerate(servers)]
    chosen = pick_one(
        "Select server  (others auto-tried if this fails)",
        choices,
    )
    if chosen is None:
        return None
    idx = choices.index(chosen)
    return servers[idx]


def pick_quality(variants: List[Dict]) -> Optional[Dict]:
    """Pick video quality from HLS variants."""
    if not variants:
        return None
    if len(variants) == 1:
        return variants[0]
    choices = [v["quality"] for v in variants]
    chosen = pick_one("Select quality", choices)
    if chosen is None:
        return None
    for v in variants:
        if v["quality"] == chosen:
            return v
    return variants[0]


def confirm(message: str, default: bool = True) -> bool:
    return questionary.confirm(message, default=default).ask() or False
