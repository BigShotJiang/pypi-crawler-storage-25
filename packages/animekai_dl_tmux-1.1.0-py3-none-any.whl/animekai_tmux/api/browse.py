"""
Browse all anime on AnimeKAI site.
Fetches all az-list pages with threading and caches results locally.
"""

import json
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import List, Dict, Optional

import requests
from bs4 import BeautifulSoup
from loguru import logger
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, BarColumn, TextColumn, TimeElapsedColumn

from ..utils.constants import BASE_URL, DEFAULT_USER_AGENT
from ..utils.config import CACHE_DIR

CACHE_FILE = CACHE_DIR / "anime-list.json"
CACHE_TTL_HOURS = 24

console = Console()


def _cache_is_fresh() -> bool:
    if not CACHE_FILE.exists():
        return False
    age_hours = (time.time() - CACHE_FILE.stat().st_mtime) / 3600
    return age_hours < CACHE_TTL_HOURS


def _load_cache() -> Optional[List[Dict]]:
    try:
        data = json.loads(CACHE_FILE.read_text())
        if isinstance(data, list) and data:
            return data
    except Exception:
        pass
    return None


def _save_cache(anime_list: List[Dict]):
    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    CACHE_FILE.write_text(json.dumps(anime_list, ensure_ascii=False))


def _get_last_page(session: requests.Session, base_url: str = BASE_URL) -> int:
    try:
        r = session.get(f"{base_url}/az-list", timeout=15)
        soup = BeautifulSoup(r.text, "html.parser")
        import re
        page_links = soup.select("a[href*='az-list?page=']")
        pages = []
        for a in page_links:
            m = re.search(r"page=(\d+)", a.get("href", ""))
            if m:
                pages.append(int(m.group(1)))
        return max(pages) if pages else 1
    except Exception as e:
        logger.debug(f"Could not get last page: {e}")
        return 1


def _fetch_page(session: requests.Session, page: int, base_url: str) -> List[Dict]:
    url = f"{base_url}/az-list?page={page}"
    try:
        r = session.get(url, timeout=15)
        soup = BeautifulSoup(r.text, "html.parser")
        results = []
        for a in soup.select("a[href*='/watch/']"):
            href = a.get("href", "")
            title = a.get_text(strip=True)
            if href and title and "/watch/" in href:
                path = href if href.startswith("/") else "/" + href.split("/watch/", 1)[-1]
                path = "/watch/" + href.split("/watch/", 1)[-1] if "/watch/" in href else href
                results.append({"title": title, "path": path})
        return results
    except Exception as e:
        logger.debug(f"Page {page} failed: {e}")
        return []


def fetch_all_anime(
    base_url: str = BASE_URL,
    threads: int = 4,
    force_refresh: bool = False,
) -> List[Dict]:
    """
    Fetch the complete anime list from AnimeKAI.
    Uses local cache (24h TTL). First run takes ~30s with threading.
    """
    if not force_refresh and _cache_is_fresh():
        cached = _load_cache()
        if cached:
            logger.debug(f"Using cached list ({len(cached)} titles)")
            return cached

    session = requests.Session()
    session.headers.update({
        "User-Agent": DEFAULT_USER_AGENT,
        "Referer": base_url,
    })

    console.print("[dim]Fetching anime list from AnimeKAI...[/dim]")
    last_page = _get_last_page(session, base_url)
    console.print(f"[dim]Found {last_page} pages (~{last_page * 30} titles). Fetching with {threads} threads...[/dim]")

    all_anime: List[Dict] = []
    seen = set()

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        BarColumn(),
        TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
        TextColumn("({task.completed}/{task.total})"),
        TimeElapsedColumn(),
        console=console,
    ) as progress:
        task = progress.add_task("Loading anime list", total=last_page)

        with ThreadPoolExecutor(max_workers=threads) as executor:
            futures = {
                executor.submit(_fetch_page, session, page, base_url): page
                for page in range(1, last_page + 1)
            }
            for future in as_completed(futures):
                entries = future.result()
                for entry in entries:
                    key = entry["path"]
                    if key not in seen:
                        seen.add(key)
                        all_anime.append(entry)
                progress.advance(task)

    all_anime.sort(key=lambda x: x["title"].lower())
    _save_cache(all_anime)
    console.print(f"[green]Loaded {len(all_anime)} titles[/green] — cached to [dim]{CACHE_FILE}[/dim]")
    return all_anime


def get_cache_info() -> dict:
    if not CACHE_FILE.exists():
        return {"exists": False}
    age_hours = (time.time() - CACHE_FILE.stat().st_mtime) / 3600
    data = _load_cache()
    return {
        "exists": True,
        "path": str(CACHE_FILE),
        "titles": len(data) if data else 0,
        "age_hours": round(age_hours, 1),
        "fresh": age_hours < CACHE_TTL_HOURS,
    }
