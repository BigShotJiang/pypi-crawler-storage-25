"""
AnimeKAI API client.

Flow:
  search() → get_episodes() → get_servers() → get_source() → get_stream_urls()
"""

import json
import re
import requests
from bs4 import BeautifulSoup
from loguru import logger
from typing import Any, Dict, List, Optional

from ..utils.constants import (
    BASE_URL, ALT_URLS,
    ENCODE_URL, DECODE_KAI_URL, DECODE_MEGA_URL,
    DEFAULT_USER_AGENT,
)


class AnimeKAIClient:
    def __init__(self, base_url: str = BASE_URL):
        self.base_url = base_url.rstrip("/")
        self.session = requests.Session()
        self.session.headers.update({"User-Agent": DEFAULT_USER_AGENT})

    def _get(self, url: str, **kwargs) -> requests.Response:
        r = self.session.get(url, timeout=20, **kwargs)
        r.raise_for_status()
        return r

    def _post(self, url: str, **kwargs) -> requests.Response:
        r = self.session.post(url, timeout=20, **kwargs)
        r.raise_for_status()
        return r

    def _encode(self, text: str) -> str:
        r = self._get(ENCODE_URL, params={"text": text})
        data = r.json()
        if data.get("status") != 200:
            raise RuntimeError(f"encode_token failed for '{text}': {data}")
        return data["result"]

    def _decode_kai(self, text: str) -> Any:
        r = self._get(DECODE_KAI_URL, params={"text": text})
        data = r.json()
        result = data.get("result")
        if isinstance(result, str):
            return json.loads(result)
        return result

    def _decode_mega(self, text: str) -> dict:
        r = self._post(DECODE_MEGA_URL, json={"text": text, "agent": DEFAULT_USER_AGENT})
        data = r.json()
        result = data.get("result")
        if isinstance(result, str):
            return json.loads(result)
        if isinstance(result, dict):
            return result
        raise RuntimeError(f"decode_mega returned unexpected type: {type(result)}")

    def search(self, query: str) -> List[Dict]:
        """Search for anime. Returns list of {'title', 'path', 'poster'}."""
        r = self._get(
            f"{self.base_url}/ajax/anime/search",
            params={"keyword": query},
        )
        data = r.json()
        html = data.get("result", {}).get("html", "")
        soup = BeautifulSoup(html, "html.parser")
        results = []
        for item in soup.select("a.aitem"):
            title_node = item.select_one(".title")
            href = item.get("href", "")
            poster_node = item.select_one(".poster img") or item.select_one("img")
            if title_node and href:
                results.append({
                    "title": title_node.get_text(strip=True),
                    "path": href,
                    "id": href.replace("/watch/", ""),
                    "poster": poster_node.get("src", "") if poster_node else "",
                })
        return results

    def get_anime_id(self, anime_path: str) -> str:
        """Fetch the watch page and extract the internal anime ID."""
        r = self._get(
            f"{self.base_url}{anime_path}",
            headers={"Referer": self.base_url},
        )
        soup = BeautifulSoup(r.text, "html.parser")
        rate_box = soup.select_one("div.rate-box[data-id]")
        if rate_box:
            return rate_box.get("data-id", "").strip()
        script_tag = soup.select_one("script#syncData")
        if script_tag:
            try:
                data = json.loads(script_tag.string)
                return data.get("anime_id", "")
            except Exception:
                pass
        raise RuntimeError(f"Could not find anime_id on page: {anime_path}")

    def get_episodes(self, anime_path: str) -> List[Dict]:
        """
        Get episode list for an anime.
        Returns list of {'num', 'slug', 'token', 'title', 'filler', 'langs'}.
        """
        anime_id = self.get_anime_id(anime_path)
        token = self._encode(anime_id)
        r = self._get(
            f"{self.base_url}/ajax/episodes/list",
            params={"ani_id": anime_id, "_": token},
            headers={"Referer": f"{self.base_url}{anime_path}"},
        )
        data = r.json()
        html = data.get("result", "")
        soup = BeautifulSoup(html, "html.parser")
        episodes = []
        for a in soup.select("div.eplist.titles ul.range li > a[num][slug][token]"):
            title_node = a.select_one("span[data-jp], span")
            episodes.append({
                "num": a.get("num", ""),
                "slug": a.get("slug", ""),
                "token": a.get("token", ""),
                "langs": a.get("langs", ""),
                "filler": "filler" in a.get("class", []),
                "title": title_node.get_text(strip=True) if title_node else "",
            })
        return list(reversed(episodes))

    def get_servers(self, episode_token: str, anime_path: str) -> Dict[str, List[Dict]]:
        """
        Get available streaming servers for an episode.
        Returns {'sub': [...], 'dub': [...], 'softsub': [...]}
        Each server: {'name', 'lid'}
        """
        sec_token = self._encode(episode_token)
        r = self._get(
            f"{self.base_url}/ajax/links/list",
            params={"token": episode_token, "_": sec_token},
            headers={"Referer": f"{self.base_url}{anime_path}"},
        )
        data = r.json()
        html = data.get("result", "")
        soup = BeautifulSoup(html, "html.parser")
        servers: Dict[str, List[Dict]] = {}
        for group in soup.select("div.server-items"):
            stype = group.get("data-id", "unknown")
            servers[stype] = []
            for node in group.select("span.server[data-lid]"):
                servers[stype].append({
                    "name": node.get_text(strip=True),
                    "lid": node.get("data-lid", ""),
                })
        return servers

    def get_source(self, lid: str, anime_path: str) -> Dict:
        """
        Get decoded source info for a server link.
        Returns {'url': 'https://megaup.nl/e/...', 'skip': {...}}
        """
        st = self._encode(lid)
        r = self._get(
            f"{self.base_url}/ajax/links/view",
            params={"id": lid, "_": st},
            headers={"Referer": f"{self.base_url}{anime_path}"},
        )
        data = r.json()
        encrypted = data.get("result", "")
        return self._decode_kai(encrypted)

    def get_stream_urls(self, embed_url: str) -> Dict:
        """
        Resolve final HLS .m3u8 URLs from a MegaUp embed URL.
        Returns {'sources': [...], 'tracks': [...], 'download': '...'}
        """
        from urllib.parse import urlparse
        parsed = urlparse(embed_url)
        path_parts = [p for p in parsed.path.split("/") if p]
        token = path_parts[-1].split("?")[0]
        mega_base = f"{parsed.scheme}://{parsed.netloc}"

        r = self._get(
            f"{mega_base}/media/{token}",
            headers={"Referer": embed_url},
        )
        enc_media = r.json()["result"]
        return self._decode_mega(enc_media)

    def get_m3u8_variants(self, embed_url: str) -> List[Dict]:
        """
        Returns list of {'quality', 'url', 'height'} from the master playlist.
        """
        payload = self.get_stream_urls(embed_url)
        sources = payload.get("sources", [])
        master_url = None
        for src in sources:
            u = src.get("file", "")
            if u.endswith(".m3u8"):
                master_url = u
                break
        if not master_url and sources:
            master_url = sources[0].get("file")
        if not master_url:
            return []

        # Fetch master playlist and parse variants
        r = self.session.get(master_url, timeout=15)
        r.raise_for_status()
        content = r.text

        if "#EXT-X-STREAM-INF" not in content:
            return [{"quality": "best", "url": master_url, "height": 9999}]

        variants = []
        lines = content.splitlines()
        for i, line in enumerate(lines):
            if not line.startswith("#EXT-X-STREAM-INF"):
                continue
            height = None
            for part in line.split(","):
                if "RESOLUTION=" in part:
                    res = part.split("RESOLUTION=", 1)[1]
                    if "x" in res:
                        try:
                            height = int(res.split("x", 1)[1])
                        except ValueError:
                            pass
            variant_url = lines[i + 1].strip() if i + 1 < len(lines) else ""
            if not variant_url:
                continue
            if not variant_url.startswith("http"):
                from urllib.parse import urljoin
                variant_url = urljoin(master_url, variant_url)
            variants.append({
                "quality": f"{height}p" if height else "unknown",
                "url": variant_url,
                "height": height or 0,
            })

        return sorted(variants, key=lambda v: v["height"], reverse=True)
