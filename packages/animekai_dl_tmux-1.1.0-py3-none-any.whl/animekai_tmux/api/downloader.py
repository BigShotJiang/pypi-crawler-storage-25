"""
HLS/m3u8 downloader using ffmpeg (standard on Termux).
"""

import os
import shutil
import subprocess
import sys
from loguru import logger
from typing import Optional


def check_ffmpeg() -> bool:
    return shutil.which("ffmpeg") is not None


def download_hls(
    m3u8_url: str,
    output_path: str,
    user_agent: str = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/135.0.0.0 Safari/537.36",
    referer: str = "https://megaup.nl/",
    show_progress: bool = True,
) -> bool:
    """
    Download an HLS stream to output_path using ffmpeg.
    Returns True on success, False on failure.
    """
    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)

    cmd = [
        "ffmpeg",
        "-y",
        "-headers", f"User-Agent: {user_agent}\r\nReferer: {referer}\r\n",
        "-i", m3u8_url,
        "-c", "copy",
        "-bsf:a", "aac_adtstoasc",
        output_path,
    ]

    if not show_progress:
        cmd.extend(["-loglevel", "quiet"])
    else:
        cmd.extend(["-loglevel", "error", "-stats"])

    logger.info(f"Starting download → {output_path}")
    try:
        result = subprocess.run(cmd, check=False)
        if result.returncode == 0:
            logger.success(f"Download complete: {output_path}")
            return True
        else:
            logger.error(f"ffmpeg exited with code {result.returncode}")
            return False
    except KeyboardInterrupt:
        logger.warning("Download interrupted by user.")
        return False
    except FileNotFoundError:
        logger.error("ffmpeg not found! Install with: pkg install ffmpeg")
        return False


def stream_hls(
    m3u8_url: str,
    player: str = "mpv",
    user_agent: str = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/135.0.0.0 Safari/537.36",
    referer: str = "https://megaup.nl/",
) -> bool:
    """Stream HLS directly using mpv or another player."""
    if not shutil.which(player):
        logger.error(f"Player '{player}' not found. Install with: pkg install {player}")
        return False

    if player == "mpv":
        cmd = [
            "mpv",
            f"--user-agent={user_agent}",
            f"--referrer={referer}",
            m3u8_url,
        ]
    else:
        cmd = [player, m3u8_url]

    logger.info(f"Streaming with {player}...")
    try:
        subprocess.run(cmd, check=False)
        return True
    except KeyboardInterrupt:
        return True
    except FileNotFoundError:
        logger.error(f"Player '{player}' not found.")
        return False
