# BikeScout - Tactical Intelligence for Cyclists
# Copyright (C) 2026 hifly81 (https://github.com/hifly81/bikescout)
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as
# published by the Free Software Foundation, either version 3 of the
# License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU Affero General Public License for more details.
#
# You should have received a copy of the GNU Affero General Public License
# along with this program. If not, see <https://www.gnu.org/licenses/>.

import requests
import uuid
import time
from pathlib import Path
from typing import Literal
from bikescout.tools.maps import save_local_tactical_map
from bikescout.tools.weather import get_weather_forecast
from bikescout.tools.surface import get_surface_analyzer
from bikescout.tools.poi import get_poi_scout
from bikescout.tools.mud import get_mud_risk_analysis
from bikescout.tools.altimetry import get_elevation_profile_image
from bikescout.tools.nutrition import get_nutrition_plan
from bikescout.schemas import RiderProfile, BikeSetup, MissionConstraints, RouteGeometry

OVERPASS_URL = "https://overpass-api.de/api/interpreter"
ORS_BASE_URL = "https://api.openrouteservice.org/v2/directions"

def calculate_detailed_difficulty(dist_km: float, ascent_m: float) -> str:
    """
    Categorizes the route difficulty based on distance, ascent, and average gradient.
    """
    if dist_km == 0:
        return "Unknown"

    # Calculate average gradient
    # Formula: (ascent / (distance * 1000)) * 100
    avg_gradient = (ascent_m / (dist_km * 1000)) * 100

    # 1. EXPERT: High distance, high climbing, or very steep
    if dist_km > 50 or ascent_m > 1000 or avg_gradient > 7:
        return "🔴 Expert (Challenging distance or very steep climbs)"

    # 2. ADVANCED: Significant climbing or moderate distance
    if dist_km > 30 or ascent_m > 600 or avg_gradient > 4:
        return "🟠 Advanced (Requires good fitness and stamina)"

    # 3. MODERATE: Accessible but with some effort
    if dist_km > 15 or ascent_m > 300:
        return "🟡 Moderate (Accessible for regular cyclists)"

    # 4. BEGINNER: Short and flat
    return "🟢 Beginner (Short and relatively flat, ideal for everyone)"

def generate_tactical_gpx(filename_part, geojson_data, amenities=[]):
    """
    Generates a GPX file with tactical waypoints and optimized track segments.
    Includes an Elevation Healing layer to fix SRTM data gaps (0.0 values).
    Output is saved to ~/.bikescout/gpx/ to avoid Context Window overflow.

    Features:
    - Data Integrity: Heals missing elevation points (prevents 0.0 altitude drops).
    - Climbing 'WALL' detection: Identify segments >10% but <45% (filters out glitches).
    - Automatic Summit detection.
    - Point Decimation: Max 1500 points for GPS device compatibility.
    - Automatic cleanup of files older than 14 days.
    """
    try:
        # 1. STORAGE CONFIGURATION & AUTO-CLEANUP
        home_dir = Path.home() / ".bikescout" / "gpx"
        home_dir.mkdir(parents=True, exist_ok=True)

        # Cleanup: Remove GPX files older than 14 days to save disk space
        now = time.time()
        for f in home_dir.glob("*.gpx"):
            if f.is_file() and (now - f.stat().st_mtime) > (14 * 86400):
                try:
                    f.unlink()
                except:
                    pass

                    # 2. ROBUST DATA EXTRACTION
        if hasattr(geojson_data, 'coordinates'):
            coords = geojson_data.coordinates
        elif isinstance(geojson_data, dict) and 'features' in geojson_data:
            feature = geojson_data['features'][0]
            coords = feature['geometry']['coordinates']
        else:
            coords = geojson_data

        # 3. ELEVATION HEALING LAYER
        # Detects and fixes 0.0 elevation points or impossible jumps by carrying over
        # the previous known altitude. This prevents "climbing walls" glitches.
        healed_coords = []
        for i in range(len(coords)):
            lon, lat, ele = coords[i]

            # If current elevation is 0 or shows an impossible jump (>200m), fix it
            if (ele <= 0 or (i > 0 and abs(ele - coords[i-1][2]) > 200)) and i > 0:
                ele = coords[i-1][2]

            healed_coords.append([lon, lat, ele])

        coords = healed_coords

        # 4. OPTIMIZATION: POINT DECIMATION
        # Targets max 1500 points to ensure compatibility with devices like Garmin/Wahoo
        MAX_TRACK_POINTS = 1500
        step = max(1, len(coords) // MAX_TRACK_POINTS)
        optimized_coords = coords[::step]

        # 5. XML HEADER CONSTRUCTION
        gpx_xml = '<?xml version="1.0" encoding="UTF-8"?>\n'
        gpx_xml += '<gpx version="1.1" creator="BikeScout" xmlns="http://www.topografix.com/GPX/1/1">\n'

        waypoints = ""

        # --- A. WAYPOINT: CYCLING AMENITIES ---
        for poi in amenities:
            name = poi.get('name', 'Cycling POI')
            loc = poi.get('location', {})
            p_lat, p_lon = loc.get('lat'), loc.get('lon')

            if p_lat and p_lon:
                waypoints += f'  <wpt lat="{p_lat}" lon="{p_lon}">\n'
                waypoints += f'    <name>{name}</name>\n'
                waypoints += f'    <sym>Watering Hole</sym>\n'
                waypoints += f'  </wpt>\n'

        # --- B. WAYPOINT: SUMMIT DETECTION ---
        if coords and len(coords[0]) > 2:
            peak = max(coords, key=lambda x: x[2])
            waypoints += f'  <wpt lat="{peak[1]}" lon="{peak[0]}">\n'
            waypoints += f'    <name>SUMMIT: {int(peak[2])}m</name>\n'
            waypoints += f'    <sym>Summit</sym>\n'
            waypoints += f'  </wpt>\n'

        # --- C. WAYPOINT: STEEP CLIMBS (GRADE LIMITER) ---
        # Detects sections over 10% grade. Filters out unrealistic jumps >45%.
        last_wall_index = -50
        for i in range(5, len(coords) - 10, 10):
            if i < last_wall_index + 40:
                continue

            p1, p2 = coords[i], coords[i+10]

            # Fast distance approximation (Meters)
            d_lat = (p2[1] - p1[1]) * 111139
            d_lon = (p2[0] - p1[0]) * 111139 * 0.7
            dist = (d_lat**2 + d_lon**2)**0.5

            if dist > 60:
                grade = ((p2[2] - p1[2]) / dist) * 100
                # Only mark if the grade is between 10% and 45% (realistic climbing range)
                if 10 < grade < 45:
                    waypoints += f'  <wpt lat="{p1[1]}" lon="{p1[0]}">\n'
                    waypoints += f'    <name>WALL: {int(grade)}%</name>\n'
                    waypoints += f'    <sym>Danger Area</sym>\n'
                    waypoints += f'  </wpt>\n'
                    last_wall_index = i

        # --- D. TRACK CONSTRUCTION ---
        track = '  <trk>\n    <name>BikeScout Tactical Route</name>\n    <trkseg>\n'
        for lon, lat, ele in optimized_coords:
            track += f'      <trkpt lat="{lat}" lon="{lon}"><ele>{ele}</ele></trkpt>\n'
        track += '    </trkseg>\n  </trk>\n'

        # 6. FILE PERSISTENCE
        full_content = gpx_xml + waypoints + track + '</gpx>'
        filename = f"tactical_route_{filename_part}.gpx"
        file_path = home_dir / filename

        with open(file_path, "w", encoding="utf-8") as f:
            f.write(full_content)

        return {
            "status": "Success",
            "message": "Tactical GPX file successfully exported and cleaned.",
            "file_location": str(file_path),
            "tactical_stats": {
                "total_points": len(coords),
                "healed_points": len(coords),
                "waypoints_count": waypoints.count('<wpt')
            }
        }

    except Exception as e:
        return {
            "status": "Error",
            "message": f"GPX Generation failed: {str(e)}"
        }

def get_complete_trail_scout(
        api_key,
        lat: float,
        lon: float,
        rider: RiderProfile,
        bike: BikeSetup,
        mission: MissionConstraints,
        include_gpx: bool = True,
        include_map: bool = False,
        output_level: Literal["summary", "standard", "full"] = "standard",
        target_date: str = None
):
    """
    The Master Orchestrator: Synchronized Technical Briefing.
    Integrates Surface Analysis, Weather-Driven Nutrition, Mud Risk,
    and Artifact Generation (GPX/Altimetry) using SMA-Sanitized data.
    """
    # --- 1. CONFIGURATION ---
    headers = {
        'Accept': 'application/json, application/geo+json',
        'Authorization': api_key,
        'Content-Type': 'application/json'
    }

    routing_payload = {
        "coordinates": [[lon, lat]],
        "options": {"round_trip": {"length": mission.radius_km * 1000, "seed": mission.seed}},
        "elevation": "true",
        "extra_info": ["surface", "steepness"]
    }

    try:
        # --- 2. EXECUTE PRIMARY ROUTING ---
        endpoint = f"{ORS_BASE_URL}/{mission.profile}/geojson"
        headers = {'Authorization': api_key, 'Content-Type': 'application/json'}

        # ORS Request Body
        response = requests.post(endpoint, json=routing_payload, headers=headers, timeout=15)
        response.raise_for_status()
        data = response.json()

        feature = data['features'][0]
        props = feature['properties']

        # Geometry baseline for all subsequent tools
        route_geo = RouteGeometry(coordinates=feature['geometry']['coordinates'])

        # --- 3. CALL: SURFACE ANALYZER (The Source of Truth) ---
        # Crucial: Cleans elevation and recalculates real geodesic distance
        surface_report = {}
        if output_level != "summary":
            try:
                surface_report = get_surface_analyzer(api_key, lat, lon, rider, bike, mission, target_date)
            except Exception as e:
                surface_report = {"status": "Error", "message": f"Surface Analysis failed: {str(e)}"}

        # --- 4. DATA SYNCHRONIZATION ---
        # Align all stats to the "Tactical" version (SMA filtered)
        if surface_report.get("status") == "Success":
            t_brief = surface_report.get("tactical_briefing", {})
            dist_km = t_brief.get("distance_km")
            ascent_m = t_brief.get("elevation_gain_m")
            dominant_surface = surface_report.get("mechanical_setup", {}).get("surface_detected", "Unknown")
        else:
            summary = props.get('summary', {})
            dist_km = round(summary.get('distance', 0) / 1000, 2)
            ascent_m = round(props.get('ascent', 0), 0)
            dominant_surface = "Unknown"

        # --- 5. CALL: WEATHER & MUD ---
        weather_report = get_weather_forecast(lat, lon, target_date)
        mud_analysis = get_mud_risk_analysis(lat, lon, dominant_surface, target_date)

        max_temp = 20.0

        if weather_report.get('status') == 'Success':
            # OPTION A: Use the pre-calculated reference temperature (Fastest)
            # This uses the specific hour matched by the engine
            max_temp = weather_report.get('reference_conditions', {}).get('temp_actual', 20.0)

            # OPTION B: Extract max from the tactical forecast list (More precise for long rides)
            # We look at 'tactical_forecast' instead of 'next_4_hours'
            forecast = weather_report.get('tactical_forecast', [])
            if forecast:
                try:
                    # We use a robust list comprehension to clean the "°C" strings
                    # and convert them to floats for comparison
                    temps = [
                        float(h["temp"].replace("°C", "").strip())
                        for h in forecast
                        if "temp" in h
                    ]
                    if temps:
                        max_temp = max(temps)
                except (ValueError, KeyError, TypeError):
                    # Fallback already set to reference_conditions or 20.0
                    pass

        # Calculate intensity and estimated duration using synchronized stats
        # Formula: dist/speed + vertical_penalty
        estimated_hours = (dist_km / 16.0) + (ascent_m / 700.0)
        intensity_score = 3 if (ascent_m > 1200 or dist_km > 60) else 2

        nutrition_plan = get_nutrition_plan(estimated_hours, max_temp, intensity_score)

        # --- 7. CALL: POI SCOUT ---
        amenities = []
        if output_level == "full":
            try:
                poi_res = get_poi_scout(api_key, lat, lon, mission.radius_km)
                amenities = poi_res.get('amenities', []) if poi_res.get('status') == "Success" else []
            except:
                amenities = []

        # --- 8. FINAL PAYLOAD CONSTRUCTION ---
        response_payload = {
            "payload_version": "1.3",
            "status": "Success",
            "info": {
                "distance_km": dist_km,
                "ascent_m": ascent_m,
                "difficulty": calculate_detailed_difficulty(dist_km, ascent_m),
                "surface_analysis": surface_report if output_level != "summary" else "Skipped"
            },
            "conditions": {
                "weather": forecast,
                "mud_risk": mud_analysis,
                "max_temp_detected": f"{max_temp}°C",
                "safety_advice": weather_report.get('safety_advice', "")
            },
            "logistics": {
                "nutrition_plan": nutrition_plan,
                "nearby_amenities": amenities[:5] if amenities else "Available in Full report"
            }
        }

        filename_part = uuid.uuid4().hex[:6]

        # --- 9. ARTIFACTS: MAP, GPX, ALTIMETRY ---
        if include_map:
            response_payload["map_image_url"] = save_local_tactical_map(filename_part, data)

        if include_gpx:
            try:
                gpx_report = generate_tactical_gpx(filename_part, geojson_data=route_geo, amenities=amenities)
                if gpx_report["status"] == "Success":
                    response_payload["gpx_export_path"] = gpx_report["file_location"]
                    response_payload["gpx_stats"] = gpx_report.get("tactical_stats")
            except Exception as e:
                response_payload["gpx_error"] = f"GPX failed: {str(e)}"

        if output_level != "summary":
            try:
                altimetry_report = get_elevation_profile_image(geometry=route_geo, uuid_input=filename_part, style="filled")
                if altimetry_report["status"] == "Success":
                    response_payload["elevation_profile_path"] = altimetry_report["file_location"]
                    response_payload["elevation_summary"] = altimetry_report.get("summary")
            except Exception as e:
                response_payload["elevation_error"] = f"Altimetry failed: {str(e)}"

        return response_payload

    except Exception as e:
        return {"status": "Error", "message": f"Master Orchestrator failed: {str(e)}"}

def _map_surface_id(s_id):
    """Internal helper to convert ORS surface IDs to strings for Mud Analysis."""
    mapping = {1: "asphalt", 2: "unpaved", 5: "gravel", 10: "dirt", 11: "grass", 12: "compact"}
    return mapping.get(s_id, "dirt")
