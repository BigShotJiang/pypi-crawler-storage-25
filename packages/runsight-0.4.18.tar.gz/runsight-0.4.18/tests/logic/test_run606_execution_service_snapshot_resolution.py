from __future__ import annotations

import asyncio
import subprocess
from pathlib import Path
from textwrap import dedent
from types import SimpleNamespace
from unittest.mock import AsyncMock, Mock, patch

import pytest
import yaml

from runsight_api.logic.services.execution_service import PreparedRunInputs
from runsight_core.redaction import RunRedactor


def _with_workflow_identity(workflow_id: str, yaml_text: str) -> str:
    """Prepend id and kind identity fields to a workflow YAML string."""
    return f"id: {workflow_id}\nkind: workflow\n" + dedent(yaml_text).strip() + "\n"


def _init_git_repo_with_workflow_files(tmp_path: Path, *, workflow_files: dict[str, str]) -> Path:
    repo = tmp_path / "repo"
    workflows_dir = repo / "custom" / "workflows"
    workflows_dir.mkdir(parents=True, exist_ok=True)
    for filename, yaml_text in workflow_files.items():
        stem = Path(filename).stem
        (workflows_dir / filename).write_text(
            _with_workflow_identity(stem, yaml_text), encoding="utf-8"
        )

    subprocess.run(["git", "init", "-b", "main"], cwd=repo, check=True, capture_output=True)
    subprocess.run(
        ["git", "config", "user.email", "test@runsight.dev"],
        cwd=repo,
        check=True,
        capture_output=True,
    )
    subprocess.run(
        ["git", "config", "user.name", "Runsight Tests"],
        cwd=repo,
        check=True,
        capture_output=True,
    )
    subprocess.run(["git", "add", "."], cwd=repo, check=True, capture_output=True)
    subprocess.run(
        ["git", "commit", "-m", "initial workflow snapshot"],
        cwd=repo,
        check=True,
        capture_output=True,
    )
    return repo


def _init_git_repo_with_nested_workflows(
    tmp_path: Path,
    *,
    parent_yaml: str,
    child_yaml: str,
) -> Path:
    return _init_git_repo_with_workflow_files(
        tmp_path,
        workflow_files={"parent.yaml": parent_yaml, "child.yaml": child_yaml},
    )


def _prepared_inputs(inputs):
    return PreparedRunInputs(
        normalized_inputs=inputs,
        input_redactor=RunRedactor(),
    )


def _run_record():
    return SimpleNamespace(
        status="pending",
        error=None,
        branch=None,
        commit_sha=None,
        updated_at=None,
    )


class _SnapshotGitService:
    def __init__(self, *, snapshot_root: Path, snapshot_files: dict[str, str]) -> None:
        self.snapshot_root = snapshot_root
        self._snapshot_files = dict(snapshot_files)
        self.read_calls: list[tuple[str, str]] = []

    def list_files(self, ref: str, path_prefix: str) -> list[str]:
        del ref
        return sorted(
            path for path in self._snapshot_files if path.startswith(path_prefix.rstrip("/") + "/")
        )

    def read_file(self, path: str, ref: str) -> str:
        self.read_calls.append((path, ref))
        candidate = Path(path)
        if candidate.is_absolute():
            candidate = candidate.relative_to(self.snapshot_root)
        return self._snapshot_files[candidate.as_posix()]

    def get_sha(self, branch: str, path: str) -> str:
        return "8" * 40


@pytest.mark.asyncio
async def test_launch_execution_resolves_child_workflow_from_snapshot_files_without_repo_path(
    tmp_path: Path,
) -> None:
    from runsight_api.data.filesystem.workflow_repo import WorkflowRepository
    from runsight_api.logic.services.execution_service import ExecutionService

    parent_yaml = """
    version: "1.0"
    inputs:
      instruction:
        type: string
        required: true
    blocks:
      call_child:
        type: workflow
        workflow_ref: child
        inputs:
          topic: workflow.instruction
    workflow:
      name: Parent Workflow
      entry: call_child
      transitions:
        - from: call_child
          to: null
    config: {}
    """
    child_yaml = """
    version: "1.0"
    inputs:
      topic:
        type: string
        required: true
    blocks:
      finish:
        type: code
        inputs:
          topic:
            from: workflow.topic
        code: |
          def main(data):
              return {"summary": data["topic"]}
    workflow:
      name: Child Workflow
      entry: finish
      transitions:
        - from: finish
          to: null
    """

    snapshot_files = {
        "custom/workflows/parent.yaml": _with_workflow_identity("parent", parent_yaml),
        "custom/workflows/child.yaml": _with_workflow_identity("child", child_yaml),
    }
    git_service = _SnapshotGitService(
        snapshot_root=tmp_path,
        snapshot_files=snapshot_files,
    )
    assert git_service.list_files("main", "custom/workflows/") == [
        "custom/workflows/child.yaml",
        "custom/workflows/parent.yaml",
    ]

    run_repo = Mock()
    run_repo.get_run.return_value = _run_record()
    run_repo.get_run.return_value = _run_record()
    provider_repo = Mock()
    provider_repo.list_all.return_value = [
        Mock(id="openai", type="openai", is_active=True, models=["gpt-4o"], api_key=None)
    ]
    workflow_repo = WorkflowRepository(base_path=str(tmp_path))
    svc = ExecutionService(
        run_repo=run_repo,
        workflow_repo=workflow_repo,
        provider_repo=provider_repo,
        git_service=git_service,
    )
    svc._run_workflow = AsyncMock()

    def _assert_snapshot_registry(yaml_content, **kwargs):
        workflow_definition = yaml.safe_load(yaml_content)
        assert workflow_definition["workflow"]["name"] == "Parent Workflow"
        workflow_registry = kwargs.get("workflow_registry")
        assert workflow_registry is not None
        child_file = workflow_registry.get("child")
        assert child_file.workflow.name == "Child Workflow"
        assert child_file.inputs is not None
        assert list(child_file.inputs) == ["topic"]
        assert child_file.inputs["topic"].type == "string"
        return Mock(name="parsed_parent_workflow")

    with (
        patch.object(
            svc,
            "_prepare_runtime_workflow",
            side_effect=lambda *, yaml_content, api_keys: (yaml.safe_load(yaml_content), Mock()),
        ),
        patch("runsight_api.logic.services.execution_service.parse_workflow_yaml") as mock_parse,
    ):
        mock_parse.side_effect = _assert_snapshot_registry

        await svc.launch_execution(
            "run_snapshot_child",
            "parent",
            _prepared_inputs({"instruction": "execute nested workflow"}),
            branch="main",
        )
        await asyncio.sleep(0.05)

    run_repo.update_run.assert_called_once()
    updated = run_repo.update_run.call_args.args[0]
    assert updated.error is None
    assert updated.branch == "main"
    assert updated.commit_sha is not None
    assert svc._run_workflow.await_count == 1


@pytest.mark.asyncio
async def test_launch_execution_rejects_invalid_child_public_input_contract_from_snapshot(
    tmp_path: Path,
) -> None:
    from runsight_api.data.filesystem.workflow_repo import WorkflowRepository
    from runsight_api.logic.services.execution_service import ExecutionService
    from runsight_api.logic.services.git_service import GitService

    parent_yaml = """
    version: "1.0"
    inputs:
      instruction:
        type: string
        required: true
    blocks:
      call_child:
        type: workflow
        workflow_ref: child
        inputs:
          topic: workflow.instruction
    workflow:
      name: Parent Workflow
      entry: call_child
      transitions:
        - from: call_child
          to: null
    config: {}
    """
    committed_child_yaml = """
    version: "1.0"
    inputs:
      UserId:
        type: string
        required: true
    blocks:
      finish:
        type: code
        inputs:
          topic:
            from: workflow.topic
        code: |
          def main(data):
              return {"summary": data["topic"]}
    workflow:
      name: Child Workflow
      entry: finish
      transitions:
        - from: finish
          to: null
    """
    dirty_child_yaml = """
    version: "1.0"
    inputs:
      topic:
        type: string
        required: true
    blocks:
      finish:
        type: code
        inputs:
          topic:
            from: workflow.topic
        code: |
          def main(data):
              return {"summary": data["topic"]}
    workflow:
      name: Dirty Child Workflow
      entry: finish
      transitions:
        - from: finish
          to: null
    """

    repo = _init_git_repo_with_nested_workflows(
        tmp_path,
        parent_yaml=parent_yaml,
        child_yaml=committed_child_yaml,
    )
    (repo / "custom" / "workflows" / "child.yaml").write_text(
        _with_workflow_identity("child", dirty_child_yaml),
        encoding="utf-8",
    )

    run_record = _run_record()
    run_repo = Mock()
    run_repo.get_run.return_value = run_record
    provider_repo = Mock()
    provider_repo.list_all.return_value = [
        Mock(id="openai", type="openai", is_active=True, models=["gpt-4o"], api_key=None)
    ]
    workflow_repo = WorkflowRepository(base_path=str(repo))
    git_service = GitService(repo_path=repo)
    svc = ExecutionService(
        run_repo=run_repo,
        workflow_repo=workflow_repo,
        provider_repo=provider_repo,
        git_service=git_service,
    )
    svc._run_workflow = AsyncMock()

    with patch.object(
        svc,
        "_prepare_runtime_workflow",
        side_effect=lambda *, yaml_content, api_keys: (yaml.safe_load(yaml_content), Mock()),
    ):
        await svc.launch_execution(
            "run_invalid_child_contract",
            "parent",
            _prepared_inputs({"instruction": "execute nested workflow"}),
            branch="main",
        )
        await asyncio.sleep(0.05)

    run_repo.update_run.assert_called_once()
    updated = run_repo.update_run.call_args.args[0]
    assert updated.error is not None
    assert "workflow contract name" in updated.error.lower()
    assert "userid" in updated.error.lower()
    assert svc._run_workflow.await_count == 0


@pytest.mark.asyncio
async def test_missing_child_ref_fails_at_save_and_launch_with_same_resolution_error(
    tmp_path: Path,
) -> None:
    from runsight_api.data.filesystem.workflow_repo import WorkflowRepository
    from runsight_api.logic.services.execution_service import ExecutionService
    from runsight_api.logic.services.git_service import GitService

    parent_yaml = """
    version: "1.0"
    inputs:
      instruction:
        type: string
        required: true
    blocks:
      call_child:
        type: workflow
        workflow_ref: renamed-child
        inputs:
          topic: workflow.instruction
    workflow:
      name: Parent Workflow
      entry: call_child
      transitions:
        - from: call_child
          to: null
    config: {}
    """

    repo = _init_git_repo_with_workflow_files(
        tmp_path,
        workflow_files={"parent.yaml": parent_yaml},
    )
    workflow_repo = WorkflowRepository(base_path=str(repo))

    saved = workflow_repo.update("parent", {"yaml": _with_workflow_identity("parent", parent_yaml)})

    assert saved.valid is False
    assert saved.validation_error is not None
    assert "renamed-child" in saved.validation_error
    assert "resolve ref" in saved.validation_error.lower()

    run_record = _run_record()
    run_repo = Mock()
    run_repo.get_run.return_value = run_record
    provider_repo = Mock()
    provider_repo.list_all.return_value = [
        Mock(id="openai", type="openai", is_active=True, models=["gpt-4o"], api_key=None)
    ]
    git_service = GitService(repo_path=repo)
    svc = ExecutionService(
        run_repo=run_repo,
        workflow_repo=workflow_repo,
        provider_repo=provider_repo,
        git_service=git_service,
    )
    svc._run_workflow = AsyncMock()

    with patch.object(
        svc,
        "_prepare_runtime_workflow",
        side_effect=lambda *, yaml_content, api_keys: (yaml.safe_load(yaml_content), Mock()),
    ):
        await svc.launch_execution(
            "run_missing_child",
            "parent",
            _prepared_inputs({"instruction": "execute nested workflow"}),
            branch="main",
        )
        await asyncio.sleep(0.05)

    run_repo.update_run.assert_called_once()
    updated = run_repo.update_run.call_args.args[0]
    assert updated.error is not None
    assert "renamed-child" in updated.error
    assert "resolve ref" in updated.error.lower()
    assert svc._run_workflow.await_count == 0


@pytest.mark.asyncio
async def test_launch_execution_rejects_reserved_child_public_input_contract_from_snapshot(
    tmp_path: Path,
) -> None:
    from runsight_api.data.filesystem.workflow_repo import WorkflowRepository
    from runsight_api.logic.services.execution_service import ExecutionService
    from runsight_api.logic.services.git_service import GitService

    parent_yaml = """
    version: "1.0"
    inputs:
      instruction:
        type: string
        required: true
    blocks:
      call_child:
        type: workflow
        workflow_ref: child
        inputs:
          topic: workflow.instruction
    workflow:
      name: Parent Workflow
      entry: call_child
      transitions:
        - from: call_child
          to: null
    config: {}
    """
    child_yaml = """
    version: "1.0"
    inputs:
      workflow:
        type: string
        required: true
    blocks:
      finish:
        type: code
        inputs:
          topic:
            from: workflow.topic
        code: |
          def main(data):
              return {"summary": data["topic"]}
    workflow:
      name: Child Workflow
      entry: finish
      transitions:
        - from: finish
          to: null
    """

    repo = _init_git_repo_with_nested_workflows(
        tmp_path,
        parent_yaml=parent_yaml,
        child_yaml=child_yaml,
    )

    run_record = _run_record()
    run_repo = Mock()
    run_repo.get_run.return_value = run_record
    provider_repo = Mock()
    provider_repo.list_all.return_value = [
        Mock(id="openai", type="openai", is_active=True, models=["gpt-4o"], api_key=None)
    ]
    workflow_repo = WorkflowRepository(base_path=str(repo))
    git_service = GitService(repo_path=repo)
    svc = ExecutionService(
        run_repo=run_repo,
        workflow_repo=workflow_repo,
        provider_repo=provider_repo,
        git_service=git_service,
    )
    svc._run_workflow = AsyncMock()

    with patch.object(
        svc,
        "_prepare_runtime_workflow",
        side_effect=lambda *, yaml_content, api_keys: (yaml.safe_load(yaml_content), Mock()),
    ):
        await svc.launch_execution(
            "run_reserved_child_contract",
            "parent",
            _prepared_inputs({"instruction": "execute nested workflow"}),
            branch="main",
        )
        await asyncio.sleep(0.05)

    run_repo.update_run.assert_called_once()
    updated = run_repo.update_run.call_args.args[0]
    assert updated.error is not None
    assert "reserved" in updated.error.lower()
    assert "workflow" in updated.error.lower()
    assert "child" in updated.error.lower()
    assert svc._run_workflow.await_count == 0


# ---------------------------------------------------------------------------
# Item 3b: Branch-scoped snapshot resolution — embedded-id child refs
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_launch_execution_resolves_embedded_id_child_from_branch_snapshot(
    tmp_path: Path,
) -> None:
    """Branch snapshot resolution discovers children by embedded workflow id."""
    from runsight_api.data.filesystem.workflow_repo import WorkflowRepository
    from runsight_api.logic.services.execution_service import ExecutionService
    from runsight_api.logic.services.git_service import GitService

    parent_yaml = """
    version: "1.0"
    inputs:
      instruction:
        type: string
        required: true
    blocks:
      call_child:
        type: workflow
        workflow_ref: child-impl
        inputs:
          topic: workflow.instruction
    workflow:
      name: Parent Workflow
      entry: call_child
      transitions:
        - from: call_child
          to: null
    config: {}
    """

    child_yaml = """
    version: "1.0"
    inputs:
      topic:
        type: string
        required: true
    blocks:
      finish:
        type: code
        inputs:
          topic:
            from: workflow.topic
        code: |
          def main(data):
              return {"summary": data["topic"]}
    workflow:
      name: My Special Child
      entry: finish
      transitions:
        - from: finish
          to: null
    """

    # Set up git repo with both parent and child on feature-a.
    repo = tmp_path / "repo"
    workflows_dir = repo / "custom" / "workflows"
    workflows_dir.mkdir(parents=True, exist_ok=True)

    (workflows_dir / "parent.yaml").write_text(
        _with_workflow_identity("parent", parent_yaml), encoding="utf-8"
    )
    (workflows_dir / "child-impl.yaml").write_text(
        _with_workflow_identity("child-impl", child_yaml), encoding="utf-8"
    )

    subprocess.run(["git", "init", "-b", "main"], cwd=repo, check=True, capture_output=True)
    subprocess.run(
        ["git", "config", "user.email", "test@runsight.dev"],
        cwd=repo,
        check=True,
        capture_output=True,
    )
    subprocess.run(
        ["git", "config", "user.name", "Runsight Tests"],
        cwd=repo,
        check=True,
        capture_output=True,
    )
    # Commit parent only on main
    subprocess.run(
        ["git", "add", "custom/workflows/parent.yaml"],
        cwd=repo,
        check=True,
        capture_output=True,
    )
    subprocess.run(
        ["git", "commit", "-m", "parent only on main"],
        cwd=repo,
        check=True,
        capture_output=True,
    )

    # Create feature-a with both parent and child
    subprocess.run(
        ["git", "checkout", "-b", "feature-a"],
        cwd=repo,
        check=True,
        capture_output=True,
    )
    subprocess.run(["git", "add", "."], cwd=repo, check=True, capture_output=True)
    subprocess.run(
        ["git", "commit", "-m", "add child-impl on feature-a"],
        cwd=repo,
        check=True,
        capture_output=True,
    )
    subprocess.run(
        ["git", "checkout", "main"],
        cwd=repo,
        check=True,
        capture_output=True,
    )
    # After checkout main, child-impl.yaml should not exist in working tree
    # (it was only committed on feature-a). Remove it if it lingers.
    child_impl_path = workflows_dir / "child-impl.yaml"
    if child_impl_path.exists():
        child_impl_path.unlink()

    run_repo = Mock()
    run_repo.get_run.return_value = _run_record()
    provider_repo = Mock()
    provider_repo.list_all.return_value = [
        Mock(id="openai", type="openai", is_active=True, models=["gpt-4o"], api_key=None)
    ]
    workflow_repo = WorkflowRepository(base_path=str(repo))
    git_service = GitService(repo_path=repo)

    svc = ExecutionService(
        run_repo=run_repo,
        workflow_repo=workflow_repo,
        provider_repo=provider_repo,
        git_service=git_service,
    )
    svc._run_workflow = AsyncMock()

    with (
        patch.object(
            svc,
            "_prepare_runtime_workflow",
            side_effect=lambda *, yaml_content, api_keys: (yaml.safe_load(yaml_content), Mock()),
        ),
        patch("runsight_api.logic.services.execution_service.parse_workflow_yaml") as mock_parse,
    ):
        mock_parse.return_value = Mock(name="parsed_workflow")

        await svc.launch_execution(
            "run_embedded_id_branch",
            "parent",
            _prepared_inputs({"instruction": "execute with embedded-id child"}),
            branch="feature-a",
        )
        await asyncio.sleep(0.05)

    # Embedded-id resolution from branch snapshot should succeed.
    error_calls = [
        c
        for c in run_repo.update_run.call_args_list
        if hasattr(c.args[0], "error") and c.args[0].error is not None
    ]
    assert len(error_calls) == 0, (
        f"Expected no error when resolving child by embedded id from branch snapshot. "
        f"Got: {error_calls[0].args[0].error if error_calls else 'N/A'}"
    )
    assert svc._run_workflow.await_count == 1
