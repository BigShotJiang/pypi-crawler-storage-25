import logging
import subprocess
from typing import TYPE_CHECKING, Any, Dict, List, Optional

import yaml as yaml_mod
from pydantic import ValidationError as PydanticValidationError
from runsight_core.identity import EntityKind, EntityRef
from runsight_core.yaml.schema import RunsightWorkflowFile

from ...data.filesystem.workflow_repo import WorkflowRepository
from ...data.repositories.run_repo import RunRepository
from ...domain.errors import GitError, InputValidationError, WorkflowNotFound
from ...domain.value_objects import WorkflowEntity

logger = logging.getLogger(__name__)
_CANVAS_BYTES_UNAVAILABLE = object()

if TYPE_CHECKING:
    from ...data.repositories.run_read_model import RunReadModel


def _workflow_ref(workflow_id: str) -> str:
    return str(EntityRef(EntityKind.WORKFLOW, workflow_id))


def _read_canvas_sidecar_bytes(workflow_repo: Any, workflow_id: str) -> bytes | None | object:
    reader = getattr(type(workflow_repo), "_read_canvas_sidecar_bytes", None)
    if not callable(reader):
        return _CANVAS_BYTES_UNAVAILABLE
    return workflow_repo._read_canvas_sidecar_bytes(workflow_id)


def _workflow_input_schema(raw_yaml: str | None) -> dict[str, dict[str, Any]] | None:
    if not raw_yaml:
        return None
    try:
        from runsight_core.workflow_input_schema import effective_workflow_input_schema
        from runsight_core.yaml.schema import RunsightWorkflowFile as WorkflowFileModel

        data = yaml_mod.safe_load(raw_yaml)
        if not isinstance(data, dict):
            return None
        file_def = WorkflowFileModel.model_validate(data)
    except (yaml_mod.YAMLError, PydanticValidationError, ValueError):
        return None

    try:
        inputs = effective_workflow_input_schema(file_def)
    except ValueError:
        return None
    if not inputs:
        return None

    return {name: input_def.model_dump() for name, input_def in inputs.items()}


def _workflow_input_schema_for_simulation(
    file_def: RunsightWorkflowFile,
    *,
    workflow_id: str,
) -> dict[str, dict[str, Any]]:
    try:
        from runsight_core.workflow_input_schema import effective_workflow_input_schema

        inputs = effective_workflow_input_schema(file_def)
    except ValueError as exc:
        _raise_workflow_input_validation(
            workflow_id,
            [_schema_field_error()],
            exc,
        )
    if not inputs:
        return {}
    return {name: input_def.model_dump() for name, input_def in inputs.items()}


def _input_schema_field_errors(error: PydanticValidationError) -> list[dict[str, Any]]:
    fields: list[dict[str, Any]] = []
    for item in error.errors():
        loc = item.get("loc", ())
        if len(loc) < 2 or loc[0] != "inputs":
            continue

        field = str(loc[1])
        invalid_input = item.get("input")
        expected_type = "string" if len(loc) > 2 and loc[2] == "type" else None
        actual_type = (
            str(invalid_input)
            if expected_type is not None and isinstance(invalid_input, str | int | float | bool)
            else None
        )
        fields.append(
            {
                "field": field,
                "code": "invalid",
                "message": f"Input '{field}' is invalid.",
                "input_path": ["inputs", field],
                "expected_type": expected_type,
                "actual_type": actual_type,
            }
        )
    return fields


def _schema_field_error(message: str = "Workflow input references are invalid.") -> dict[str, Any]:
    return {
        "field": "__schema__",
        "code": "invalid",
        "message": message,
        "input_path": ["inputs"],
        "expected_type": None,
        "actual_type": None,
    }


def _raise_workflow_input_validation(
    workflow_id: str,
    fields: list[dict[str, Any]],
    error: Exception,
) -> None:
    raise InputValidationError(
        "Workflow input validation failed",
        error_code="WORKFLOW_INPUT_VALIDATION_ERROR",
        status_code=422,
        details={
            "kind": "workflow_input_validation",
            "workflow_id": workflow_id,
            "fields": fields,
        },
    ) from error


class WorkflowService:
    def __init__(
        self,
        workflow_repo: WorkflowRepository,
        run_repo: RunRepository,
        git_service=None,
        run_read_model: "RunReadModel | None" = None,
    ):
        self.workflow_repo = workflow_repo
        self.run_repo = run_repo
        self.git_service = git_service
        self.run_read_model = run_read_model

    def list_workflows(self, query: Optional[str] = None) -> List[WorkflowEntity]:
        workflows = self.workflow_repo.list_all()
        if query:
            query = query.lower()
            workflows = [
                w
                for w in workflows
                if query in w.id.lower() or (getattr(w, "name", "") and query in w.name.lower())
            ]

        if workflows and self.run_read_model is None:
            raise RuntimeError(
                "WorkflowService requires a run read model for workflow health queries"
            )
        health_by_workflow = (
            self.run_read_model.get_workflow_health_metrics([w.id for w in workflows])
            if self.run_read_model is not None
            else {}
        )
        enriched_workflows: list[WorkflowEntity] = []

        for workflow in workflows:
            yaml_path = f"custom/workflows/{workflow.id}.yaml"
            enriched_workflows.append(
                workflow.model_copy(
                    update={
                        "block_count": self.workflow_repo.get_block_count(workflow.id),
                        "modified_at": self.workflow_repo.get_file_mtime(workflow.id),
                        "enabled": bool(getattr(workflow, "enabled", False)),
                        "commit_sha": self._get_workflow_commit_sha(yaml_path),
                        "input_schema": _workflow_input_schema(workflow.yaml),
                        "health": health_by_workflow.get(
                            workflow.id,
                            {
                                "run_count": 0,
                                "eval_pass_pct": None,
                                "eval_health": None,
                                "total_cost_usd": 0.0,
                                "regression_count": 0,
                            },
                        ),
                    }
                )
            )

        return enriched_workflows

    def get_workflow(self, id: str) -> Optional[WorkflowEntity]:
        return self.workflow_repo.get_by_id(id)

    def get_workflow_detail(self, id: str) -> Optional[WorkflowEntity]:
        workflow = self.workflow_repo.get_by_id(id)
        if workflow is None:
            return None

        yaml_path = f"custom/workflows/{workflow.id}.yaml"
        return workflow.model_copy(
            update={
                "commit_sha": self._get_workflow_commit_sha_on_main(yaml_path),
                "input_schema": _workflow_input_schema(workflow.yaml),
            }
        )

    def create_workflow(self, data: Dict[str, Any], *, commit: bool = True) -> WorkflowEntity:
        try:
            result = self.workflow_repo.create(data)
        except ValueError as exc:
            raise InputValidationError(str(exc)) from exc
        if commit:
            self._auto_commit(
                f"Create workflow: {result.name}",
                [f"custom/workflows/{result.id}.yaml"],
            )
        return result

    def update_workflow(self, id: str, data: Dict[str, Any]) -> WorkflowEntity:
        try:
            return self.workflow_repo.update(id, data)
        except ValueError as exc:
            raise InputValidationError(str(exc)) from exc

    def commit_workflow(
        self,
        workflow_id: str,
        draft: Dict[str, Any],
        message: str,
    ) -> Dict[str, str]:
        if self.git_service is None:
            raise RuntimeError("Git service not configured")

        previous = self.workflow_repo.get_by_id(workflow_id)
        previous_canvas_bytes = (
            _read_canvas_sidecar_bytes(self.workflow_repo, workflow_id)
            if previous is not None
            else _CANVAS_BYTES_UNAVAILABLE
        )
        try:
            self.update_workflow(workflow_id, draft)
        except InputValidationError:
            raise

        files = [f"custom/workflows/{workflow_id}.yaml"]
        if draft.get("canvas_state") is not None:
            files.append(f"custom/workflows/.canvas/{workflow_id}.canvas.json")

        try:
            commit_hash = self.git_service.commit_to_branch("main", files, message)
        except Exception:
            if previous is not None:
                if previous_canvas_bytes is not _CANVAS_BYTES_UNAVAILABLE:
                    self.workflow_repo.update(workflow_id, {"yaml": previous.yaml})
                    self.workflow_repo._restore_canvas_sidecar(workflow_id, previous_canvas_bytes)
                else:
                    previous_canvas_state = getattr(previous, "canvas_state", None)
                    rollback = {"yaml": previous.yaml}
                    if previous_canvas_state is not None:
                        if hasattr(previous_canvas_state, "model_dump"):
                            rollback["canvas_state"] = previous_canvas_state.model_dump()
                        else:
                            rollback["canvas_state"] = previous_canvas_state
                    self.workflow_repo.update(workflow_id, rollback)
                    if previous_canvas_state is None:
                        self.workflow_repo._restore_canvas_sidecar(workflow_id, None)
            raise
        return {"hash": commit_hash, "message": message}

    def create_simulation(self, workflow_id: str, yaml: str) -> Dict[str, Any]:
        if self.git_service is None:
            raise GitError("Simulation runs require a git repository")

        workflow_file = self._validate_simulation_yaml_identity(workflow_id, yaml)
        input_schema = _workflow_input_schema_for_simulation(
            workflow_file,
            workflow_id=workflow_id,
        )

        yaml_path = f"custom/workflows/{workflow_id}.yaml"
        try:
            result = self.git_service.create_sim_branch(
                workflow_slug=workflow_id,
                yaml_content=yaml,
                yaml_path=yaml_path,
            )
        except subprocess.CalledProcessError as exc:
            detail = (exc.stderr or "").strip()
            if "not a git repository" in detail.lower():
                raise GitError("Simulation runs require a git repository") from exc
            raise GitError(detail or "Failed to create simulation branch") from exc
        return {"branch": result.branch, "commit_sha": result.sha, "input_schema": input_schema}

    def _validate_simulation_yaml_identity(
        self, workflow_id: str, raw_yaml: str
    ) -> RunsightWorkflowFile:
        try:
            data = yaml_mod.safe_load(raw_yaml)
        except yaml_mod.YAMLError as exc:
            raise InputValidationError("Malformed YAML") from exc
        if not isinstance(data, dict):
            raise InputValidationError("YAML content is not a mapping")
        embedded_id = data.get("id")
        if embedded_id is not None and embedded_id != workflow_id:
            raise InputValidationError(
                f"embedded workflow id '{embedded_id}' does not match requested "
                f"{_workflow_ref(workflow_id)}"
            )
        try:
            workflow_file = RunsightWorkflowFile.model_validate(data)
        except PydanticValidationError as exc:
            fields = _input_schema_field_errors(exc)
            if fields:
                _raise_workflow_input_validation(workflow_id, fields, exc)
            _raise_workflow_input_validation(
                workflow_id,
                [_schema_field_error("Workflow schema is invalid.")],
                exc,
            )
        if workflow_file.id != workflow_id:
            raise InputValidationError(
                f"embedded workflow id '{workflow_file.id}' does not match requested "
                f"{_workflow_ref(workflow_id)}"
            )
        return workflow_file

    def _auto_commit(self, message: str, files: list) -> None:
        if not self.git_service:
            return
        if self.git_service.is_clean():
            return  # nothing changed, skip empty commit
        try:
            self.git_service.commit_to_branch("main", files, message)
        except Exception:
            # Creating a workflow should still succeed even when local git state
            # prevents the convenience auto-commit from completing.
            logger.warning("Skipping workflow auto-commit after create", exc_info=True)

    def _get_workflow_commit_sha(self, path: str) -> str | None:
        if self.git_service is None:
            return None
        try:
            branch = self.git_service.current_branch()
        except Exception:
            return None
        if not isinstance(branch, str):
            return None
        branch = branch.strip()
        if not branch or branch == "HEAD":
            return None
        return self.git_service.get_sha(branch, path)

    def _get_workflow_commit_sha_on_main(self, path: str) -> str | None:
        if self.git_service is None:
            return None
        return self.git_service.get_sha("main", path)

    def set_enabled(self, workflow_id: str, enabled: bool) -> WorkflowEntity:
        """Toggle the enabled field for a workflow."""
        return self.workflow_repo.patch_yaml_field(workflow_id, "enabled", enabled)

    def delete_workflow(self, id: str, force: bool = False) -> dict[str, Any]:
        workflow = self.workflow_repo.get_by_id(id)
        if workflow is None:
            raise WorkflowNotFound(f"Workflow {_workflow_ref(id)} not found")

        runs_deleted = self.run_repo.delete_runs_for_workflow(id, force=force)
        success = self.workflow_repo.delete(id)
        if not success:
            raise WorkflowNotFound(f"Workflow {_workflow_ref(id)} not found")
        self._auto_commit(
            f"Delete workflow: {workflow.name if workflow and workflow.name else id}",
            [
                f"custom/workflows/{id}.yaml",
                f"custom/workflows/.canvas/{id}.canvas.json",
            ],
        )
        return {"id": id, "deleted": True, "runs_deleted": runs_deleted}
