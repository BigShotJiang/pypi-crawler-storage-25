# actionlayer-mcp

MCP server for [ActionLayer](https://action-layer.dev) — give Claude Code (and any MCP host) access to ActionLayer's typed action catalog: 30+ actions across Gmail, Calendar, Drive, Slack, Notion, GitHub, Stripe, Linear, Resy, Partiful, USPS, and more.

## Install

Get an API key at https://action-layer.dev/join, then:

```bash
claude mcp add --scope user actionlayer "uvx" "actionlayer-mcp" \
  --env ACTIONLAYER_API_KEY="ak_…" \
  --env ACTIONLAYER_API_URL="https://api.action-layer.dev"
```

Restart Claude Code and try:

```
Summarize my 3 most recent unread emails.
```

## How it works

This package is a thin shim. The actual execution lives on ActionLayer's
service. The MCP server here exposes one tool — `actionlayer_invoke_action` —
plus helpers to list the catalog, create jobs, and manage the cyborg loop.
Auth is via your bearer API key; the server proxies calls and surfaces
the typed response back to your agent host.

## Usage from other MCP hosts

```bash
# stdio transport (default)
actionlayer-mcp

# also works with Cursor, Cody, Codex, etc. — any MCP host
```

Env vars:
- `ACTIONLAYER_API_KEY` — required, your bearer key
- `ACTIONLAYER_API_URL` — defaults to `https://api.action-layer.dev`

## License

MIT
