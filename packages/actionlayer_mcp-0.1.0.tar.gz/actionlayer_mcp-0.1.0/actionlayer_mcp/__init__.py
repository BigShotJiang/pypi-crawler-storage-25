"""ActionLayer MCP server.

A thin Model Context Protocol shim that translates MCP tool calls into
ActionLayer REST API calls. Runs on the user's machine (or wherever
their agent host runs); reads ACTIONLAYER_API_KEY + ACTIONLAYER_API_URL
from the environment.

Distributed via PyPI as `actionlayer-mcp`. The console_scripts entry
point lets agent hosts run it as `uvx actionlayer-mcp` or
`pipx run actionlayer-mcp` with no clone needed.
"""

from actionlayer_mcp.client import ActionLayerClient, ApiError

__version__ = "0.1.0"

__all__ = ["ActionLayerClient", "ApiError", "__version__"]
