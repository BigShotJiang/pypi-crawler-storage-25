# ChatModelTask

Smart model routing layer for LangChain + OpenRouter.

## Installation

```bash
pip install chatmodeltask
```
```python
from chatModelTask import ChatModelTask

llm = ChatModelTask(task_description="summarization")
print(llm.invoke("Hello world"))
```

## Environment Variables

OPENROUTER_API_KEY=...
REDIS_HOST=localhost
MODEL_SCORE_ENGINE_BASE_URL=...
MODEL_SCORE_ENGINE_API_KEY=...