import hashlib
import json


def hash_string(text: str) -> str:

    hash_value = hashlib.sha256(
        text.strip().lower().encode()
    ).hexdigest()

    return hash_value


def hash_dict(obj: dict) -> str:

    text = json.dumps(
        obj,
        sort_keys=True,
        separators=(",", ":")
    )

    return hash_string(text)