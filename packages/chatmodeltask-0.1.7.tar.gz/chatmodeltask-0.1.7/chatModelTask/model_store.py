import redis
import json
import hashlib
import time
from typing import List, Optional
import os 
 

r = redis.Redis(
    host=os.getenv('REDIS_HOST'),
    port=6379,
    decode_responses=True
)


class ModelCache:

    # 30 days
    IDLE_EXPIRE_SECONDS = 60 * 60 * 24 * 30

    def __init__(self):
        self.r = r

    # -----------------------------
    # key generator
    # -----------------------------
    def make_key(self, task_description: str) -> str:
        hash_value = hashlib.sha256(
            task_description.strip().lower().encode()
        ).hexdigest()

        return f"model_cache:{hash_value}"

    # -----------------------------
    # SET
    # -----------------------------
    def set_models(
        self,
        text: str,
        models: List[str],
        weights: dict,
        hashFilter: str = ''
    ):

        key = self.make_key(text)

        value = {
            "models": models,
            "weights": weights,
            "updated_at": time.time(),
            "hashFilter": hashFilter
        }

        # set with TTL
        self.r.set(
            key,
            json.dumps(value),
            ex=self.IDLE_EXPIRE_SECONDS
        )

    # -----------------------------
    # CHECK IF EXPIRED
    # -----------------------------
    def is_expired(self, data: dict, exp_seconds: int) -> bool:
        return (time.time() - data["updated_at"]) > exp_seconds

    # -----------------------------
    # GET
    # -----------------------------
    def get_models(
        self,
        text: str,
        exp_seconds: int = 3600,
        refresh_func=None,
        hashFilter: Optional[str] = '',
    ) -> Optional[dict]:

        key = self.make_key(text)

        data = self.r.get(key)

        # -----------------
        # cache miss
        # -----------------
        if not data:
            if refresh_func:
                new_data = refresh_func()

                self.set_models(
                    text,
                    new_data["models"],
                    new_data["weights"],
                    new_data["hashFilter"]
                )

                return [{"id": m} for m in new_data['models']]

            return None

        # refresh idle TTL on access
        self.r.expire(key, self.IDLE_EXPIRE_SECONDS)

        data = json.loads(data)

        hashed_filter = data['hashFilter']

        # -----------------
        # fresh cache
        # -----------------
        if (
            not self.is_expired(data, exp_seconds)
            and hashed_filter == hashFilter
        ):
            return [{"id": m} for m in data['models']]

        # -----------------
        # expired → refresh
        # -----------------
        if refresh_func:
            new_data = refresh_func(data['weights'])

            self.set_models(
                text,
                new_data["models"],
                new_data["weights"],
                new_data["hashFilter"]
            )

            return [{"id": m} for m in new_data['models']]

        return [{"id": m} for m in data['models']]