from contextlib import contextmanager
from langchain_core.callbacks import get_usage_metadata_callback 
from .client import ChatModelTaskClient
from .config import settings

def compute_cost(usage_metadata: dict):
    base_url = settings.MODEL_SCORE_ENGINE_BASE_URL
    api_key = settings.MODEL_SCORE_ENGINE_API_KEY

    client = ChatModelTaskClient(base_url, api_key, 300)

    pricings = client.post_sync(
        '/rank/pricing',
        {'models_id': list(usage_metadata.keys())}
    )

    pricing_map = {
        p["model_id"]: {
            "pricing":p["pricing"],
            'origin_id':p['origin_id']}
        for p in pricings
        if p.get("model_id")
    }
    
    for model_id, usage in usage_metadata.items():
        usage.setdefault("billing", {})
       
        input_tokens = usage.get("input_tokens", 0)
        output_tokens = usage.get("output_tokens", 0)

        pricing = pricing_map.get(model_id).get('pricing')
        origin_id = pricing_map.get(model_id).get('origin_id')
        
        if not pricing: continue

        # FIX: Convert pricing strings explicitly to floats before doing math
        prompt_rate = float(pricing.get("prompt", 0))
        completion_rate = float(pricing.get("completion", 0))

        usage["billing"] = {
            "prompt": prompt_rate * input_tokens,
            "output": completion_rate * output_tokens,
            "total_cost": (prompt_rate * input_tokens) + (completion_rate * output_tokens),
            "origin_id":origin_id
        }

@contextmanager
def get_usage_billing_metadata_callback():
    with get_usage_metadata_callback() as cb:
        yield cb  

        # This runs AFTER the user exits their 'with' block
        compute_cost(cb.usage_metadata) 
        
        # Safe fallback: attach the fully computed dict directly to cb 
        # in case cb.usage_metadata prevents inline updates
        cb.billing_results = cb.usage_metadata