from chatModeltask.type import CustomWeights
from langchain_core.prompts import ChatPromptTemplate


weight_data = {
    "popularity": 0.0,
    "reasoning": 0.4,
    "tools": 0.0,
    "reliability": 0.3,
    "cache": 0.0,
    "programming": 0.2,
    "science": 0.0,
    "technology": 0.1,
    "finance": 0.0,
    "marketing": 0.0,
    "translation": 0.0,
    "legal": 0.0,
    "health": 0.0,
    "roleplay": 0.0,
    "academia": 0.0,
    "marketing_seo": 0.0
}


system_instruction = """
You are an expert AI Systems Architect specializing in LLM routing and evaluation. 
Your job is to translate a user's natural language request into a precise dictionary of feature weights for a recommendation engine.

Available features you can assign weights to:
- popularity (Overall consumption)
- reasoning (Complex logic, math, chain-of-thought)
- tools (Function calling/API execution)
- reliability (Low error rates in production)
- cache (Cost optimization/prompt caching)
- programming (Coding, debugging, script generation)
- science (Hard sciences, chemistry, physics)
- technology (IT systems, hardware, generic engineering)
- finance (Economic analysis, numbers, spreadsheets)
- marketing (Content creation, ad copywriting)
- translation (Language accuracy)
- legal (Law, compliance, text dense evaluation)
- health (Medicine, wellness data)
- roleplay (Chat personas, fiction writing)
- academia (Research papers, thesis styling)
- marketing/seo (SEO metadata, web positioning)

CRITICAL RULES:
1. Identify the core intent of the user request and allocate weights only to the most relevant features.
2. The SUM of all weights you assign MUST equal exactly 1.0 (or 100%).
3. If a feature is completely irrelevant to the user's task, leave it as 0.0.
4. Distribute the 1.0 budget intelligently based on the priorities implicit in the user text.
"""

def generateTaskWeights(task_description: str) -> CustomWeights:
    from chatModel4task.chatModel4Task import ChatModelTask,ModelFilter
    
    filter = ModelFilter(max_1m_input_tokens_price=0.1,
                         max_1m_output_tokens_price=0.5,
                         require_structured=True,
                         exclude_free_models=True)
    
    
    llm = ChatModelTask(  task_weights=weight_data,
                          filter=filter,
                          base_url="http://localhost:8000",
                          api_key="123456789",
                          temperature=0.0)
    
    prompt = ChatPromptTemplate.from_messages([
        ("system", system_instruction),
        ("human", "Analyze this request and generate the weights: '{task_description}'")
    ])

    # Bind the Pydantic schema to force structured JSON output
    structured_llm = llm.with_structured_output(CustomWeights)

    # Combine into a runnable chain
    weight_generation_chain = prompt | structured_llm
    
    weights = weight_generation_chain.invoke({"task_description":task_description})
    
    return weights.model_dump() if weights else None