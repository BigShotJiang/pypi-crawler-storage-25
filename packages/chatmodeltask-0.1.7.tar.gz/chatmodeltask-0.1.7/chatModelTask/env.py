import os
from pathlib import Path

def init_env(path: str = ".env"):
    """
    Create .env file from bundled example
    """
    example_path = Path(__file__).parent / ".env.example"

    if not example_path.exists():
        raise FileNotFoundError("Missing .env.example in package")

    if Path(path).exists():
        print(f"{path} already exists")
        return

    content = example_path.read_text()
    Path(path).write_text(content)

    print(f"{path} created from template")
    
def load_env():
    from dotenv import load_dotenv
    load_dotenv()