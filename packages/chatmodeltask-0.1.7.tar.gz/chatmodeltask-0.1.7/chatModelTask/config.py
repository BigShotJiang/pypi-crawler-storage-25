import os

class Settings:
    OPENROUTER_API_KEY = os.getenv("OPENROUTER_API_KEY")
    REDIS_HOST = os.getenv("REDIS_HOST", "localhost")
    MODEL_SCORE_ENGINE_BASE_URL = os.getenv("MODEL_SCORE_ENGINE_BASE_URL")
    MODEL_SCORE_ENGINE_API_KEY = os.getenv("MODEL_SCORE_ENGINE_API_KEY")

settings = Settings()