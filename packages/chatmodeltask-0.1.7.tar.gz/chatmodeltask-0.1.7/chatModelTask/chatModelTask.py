from typing import Optional, List, Dict, Any, get_args
from .model_store import ModelCache

from langchain_openrouter import ChatOpenRouter
from .type import  ModelFilter, TASK_TYPE
from .client import ChatModelTaskClient
from .model_weight import generateTaskWeights
from .utils import hash_dict
from .config import settings

#def secret_from_env(key: str) -> Optional[str]:
#    return os.getenv(key)

class ChatModel4Task(ChatOpenRouter):
    
    def __init__(
        self,
        task: Optional[TASK_TYPE] = None,
        task_description: Optional[str] = None,
        task_weights: Optional[dict] = None,
        model: Optional[str] = None,
        filter: Optional[ModelFilter] = None,
        top_k: Optional[int] = 10,
        name: Optional[str] = None,
        base_url: Optional[str] = None,
        api_key: Optional[str] = None,
        openRouter_api_key: Optional[str] = None,
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
        max_completion_tokens: Optional[int] = None,
        timeout: int = 300,
        max_retries: int = 2,
        streaming: bool = False,
        stream_usage: bool = True,
        tags: Optional[List[str]] = None,
        metadata: Optional[Dict[str, Any]] = None,
         
        **kwargs: Any
    ):
        """
        Custom ChatModelTask SDK for OpenRouter.

        Environment Variables Required (if not passed explicitly):
        MODEL_SCORE_ENGINE_BASE_URL: The base URL for the model score engine API.
        MODEL_SCORE_ENGINE_API_KEY: The API secret key for authentication.
        OPENROUTER_API_KEY: the API key for openrouter
            
        """
        
        
        base_url = base_url or settings.MODEL_SCORE_ENGINE_BASE_URL
        api_key = api_key or settings.MODEL_SCORE_ENGINE_API_KEY
        openRouter_api_key = openRouter_api_key or settings.OPENROUTER_API_KEY
        
        
        if not base_url:
            raise ValueError("MODEL_TASK_BASE_URL is required")
        if not api_key:
            raise ValueError("MODEL_TASK_API_KEY is required")
        
        task_description = task if not task_description else task_description
        
        payload = {
            "task": task,
            "weights": task_weights if task_weights else None,
            "filter": filter.model_dump() if filter else None,
            "top_k": top_k
        }
        
        models = None
        if(task_description and not model and not task_weights):
             
            model_cache = ModelCache() if task_description else None
            hashFilter = hash_dict(filter.model_dump()) if filter else ''
            
            models = model_cache.get_models(
                task_description,
                exp_seconds=3600,
                refresh_func=lambda weights=None:self._refresh_models(weights,task_description,hashFilter,payload,base_url,api_key,timeout),
                hashFilter=hashFilter)
        
        
        if not models:
            if not model:
                client = ChatModelTaskClient(base_url, api_key, timeout)
                models = client.post_sync("/rank/models", payload) 
            else:
                models = [{"id": model}]
         
         
        super().__init__(
            model=models[0].get('id'),
            temperature=temperature,
            max_tokens=max_tokens,
            max_completion_tokens=max_completion_tokens,
            api_key=openRouter_api_key,
            max_retries=max_retries,
            streaming=streaming,
            tags=tags,
            metadata=metadata,
            stream_usage=stream_usage,
            name=name,
            **kwargs
        )
        
        
        # FIXED: Use object.__setattr__ to bypass Pydantic validation rules safely
        object.__setattr__(self, 'models', models)
        # Store openRouter_api_key internally so fallbacks can access it if needed
        object.__setattr__(self, '_openrouter_api_key', openRouter_api_key)
        
        
    
    def _refresh_models(self,weights,task_description,hashFilter,payload,base_url, api_key, timeout):
        
        isTaskType = task_description in get_args(TASK_TYPE)
          
        weights = generateTaskWeights(task_description) if not weights and not isTaskType else weights 
        payload['weights'] = weights or {}
        
        client = ChatModelTaskClient(base_url, api_key, timeout)
        models = client.post_sync("/rank/models", payload) 
        
        return {
            "models":[m.get('id') for m in models],
            "weights":weights,
            "hashFilter":hashFilter
        }
         
        
    def with_fallbacks(self, fallbacks: Optional[List[str]] = None, **kwargs: Any):
        fallbacks = fallbacks if fallbacks else [m.get('id') for i, m in enumerate(self.models) if i > 0]
        
        # Extract the saved key to ensure fallback instances can authenticate properly
        api_key = getattr(self, '_openrouter_api_key', None)
        
        return super().with_fallbacks(
            [
                ChatOpenRouter(
                    model=modelID, 
                    api_key=api_key,
                    **kwargs
                ) for modelID in fallbacks
            ]
        )
     
         
        

 