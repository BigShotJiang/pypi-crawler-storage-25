from .env import init_env

def main():
    import sys

    if len(sys.argv) > 1 and sys.argv[1] == "init":
        init_env()
    else:
        print("Usage: chatmodeltask init")