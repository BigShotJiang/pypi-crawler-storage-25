"""
Generic search tools — list and get any of the 61 entity types.

Instead of 61 individual list/get tools, two generic tools handle all entity types
via a type parameter. The LLM tool surface stays small while covering everything.
The backend handles authorization — 403 responses tell the user to upgrade their tier.

Entity type → API path mapping derived from router.py.
"""

from typing import Literal

from fastmcp import Context

from ..server import mcp
from ..client import get_client

# All 61 entity types available in the platform (snake_case).
# Used as a Literal type so FastMCP exposes a strict JSON Schema enum to the LLM —
# Claude will never hallucinate an invalid entity type.
# IMPORTANT: When adding a new entity to the backend (model + subrouter + schema),
# you MUST add it here too. Otherwise the AI agent will be blind to that entity.
EntityType = Literal[
    # Standardization
    "ontology_term", "unit_of_measure", "external_reference",
    # Omics Registry
    "organism", "gene", "transcript", "exon", "protein",
    "protein_domain", "variant", "peptide_fragment",
    # Clinical & Phenotypic
    "indication", "phenotype", "biomarker", "pathway", "dosage_protocol",
    # Asset Management
    "therapeutic_asset", "small_molecule", "biologic",
    "therapeutic_peptide", "oligonucleotide",
    # R&D Engineering
    "candidate", "design_mutation", "construct",
    # LIMS & Empirical Data
    "subject", "biospecimen", "assay_protocol", "assay_run", "assay_readout",
    # User & Personalization
    "user_profile", "data_source", "genomic_file", "user_variant",
    "user_biomarker_reading", "user_treatment_log", "pathway_score", "recommendation",
    # Knowledge Graph
    "drug_target_mechanism", "bio_activity", "therapeutic_efficacy",
    "drug_interaction", "biomarker_association", "genomic_association",
    "variant_phenotype", "pathway_membership", "biological_relationship",
    "source", "evidence_assertion", "context_attribute",
    # Commercial Intelligence
    "market_organization", "patent", "patent_claim", "patent_assignee",
    "asset_ownership", "transaction", "licensing_agreement",
    "development_pipeline", "regulatory_approval", "technology_platform",
    "asset_technology_platform", "organization_technology_platform",
]

# Data ownership scope for list endpoints.
Scope = Literal["all", "curated", "own"]

# Complete mapping of entity_type (snake_case) → API path prefix
# Derived from /nexotype/server/apps/nexotype/router.py
ENTITY_ROUTES = {
    # Standardization
    "ontology_term": "/nexotype/ontology-terms",
    "unit_of_measure": "/nexotype/units-of-measure",
    "external_reference": "/nexotype/external-references",
    # Omics Registry
    "organism": "/nexotype/organisms",
    "gene": "/nexotype/genes",
    "transcript": "/nexotype/transcripts",
    "exon": "/nexotype/exons",
    "protein": "/nexotype/proteins",
    "protein_domain": "/nexotype/protein-domains",
    "variant": "/nexotype/variants",
    "peptide_fragment": "/nexotype/peptide-fragments",
    # Clinical & Phenotypic
    "indication": "/nexotype/indications",
    "phenotype": "/nexotype/phenotypes",
    "biomarker": "/nexotype/biomarkers",
    "pathway": "/nexotype/pathways",
    "dosage_protocol": "/nexotype/dosage-protocols",
    # Asset Management
    "therapeutic_asset": "/nexotype/therapeutic-assets",
    "small_molecule": "/nexotype/small-molecules",
    "biologic": "/nexotype/biologics",
    "therapeutic_peptide": "/nexotype/therapeutic-peptides",
    "oligonucleotide": "/nexotype/oligonucleotides",
    # R&D Engineering
    "candidate": "/nexotype/candidates",
    "design_mutation": "/nexotype/design-mutations",
    "construct": "/nexotype/constructs",
    # LIMS & Empirical Data
    "subject": "/nexotype/subjects",
    "biospecimen": "/nexotype/biospecimens",
    "assay_protocol": "/nexotype/assay-protocols",
    "assay_run": "/nexotype/assay-runs",
    "assay_readout": "/nexotype/assay-readouts",
    # User & Personalization
    "user_profile": "/nexotype/user-profiles",
    "data_source": "/nexotype/data-sources",
    "genomic_file": "/nexotype/genomic-files",
    "user_variant": "/nexotype/user-variants",
    "user_biomarker_reading": "/nexotype/user-biomarker-readings",
    "user_treatment_log": "/nexotype/user-treatment-logs",
    "pathway_score": "/nexotype/pathway-scores",
    "recommendation": "/nexotype/recommendations",
    # Knowledge Graph
    "drug_target_mechanism": "/nexotype/drug-target-mechanisms",
    "bio_activity": "/nexotype/bioactivities",
    "therapeutic_efficacy": "/nexotype/therapeutic-efficacies",
    "drug_interaction": "/nexotype/drug-interactions",
    "biomarker_association": "/nexotype/biomarker-associations",
    "genomic_association": "/nexotype/genomic-associations",
    "variant_phenotype": "/nexotype/variant-phenotypes",
    "pathway_membership": "/nexotype/pathway-memberships",
    "biological_relationship": "/nexotype/biological-relationships",
    "source": "/nexotype/sources",
    "evidence_assertion": "/nexotype/evidence-assertions",
    "context_attribute": "/nexotype/context-attributes",
    # Commercial Intelligence
    "market_organization": "/nexotype/market-organizations",
    "patent": "/nexotype/patents",
    "patent_claim": "/nexotype/patent-claims",
    "patent_assignee": "/nexotype/patent-assignees",
    "asset_ownership": "/nexotype/asset-ownerships",
    "transaction": "/nexotype/transactions",
    "licensing_agreement": "/nexotype/licensing-agreements",
    "development_pipeline": "/nexotype/development-pipelines",
    "regulatory_approval": "/nexotype/regulatory-approvals",
    "technology_platform": "/nexotype/technology-platforms",
    "asset_technology_platform": "/nexotype/asset-technology-platforms",
    "organization_technology_platform": "/nexotype/organization-technology-platforms",
}

# Key fields to display for common entity types (for compact list output)
# Falls back to showing all fields if type not in this map
DISPLAY_FIELDS = {
    "gene": ["hgnc_symbol", "chromosome", "ensembl_gene_id"],
    "protein": ["uniprot_accession", "description"],
    "variant": ["db_snp_id", "chromosome", "position", "hgvs_p"],
    "indication": ["name", "icd_10_code"],
    "phenotype": ["name", "hpo_id"],
    "biomarker": ["name", "loinc_code"],
    "pathway": ["name", "kegg_id", "longevity_tier"],
    "therapeutic_asset": ["name", "uid", "asset_type", "category"],
    "small_molecule": ["name", "uid", "inchi_key"],
    "therapeutic_peptide": ["name", "uid", "purity_grade"],
    "market_organization": ["legal_name", "ticker_symbol", "org_type", "status"],
    "patent": ["patent_number", "jurisdiction", "title", "status"],
    "development_pipeline": ["asset_id", "indication_id", "phase", "status", "nct_number"],
    "regulatory_approval": ["asset_id", "indication_id", "agency", "approval_type", "status"],
    "licensing_agreement": ["licensor_id", "licensee_id", "agreement_type", "territory", "status"],
    "transaction": ["buyer_id", "seller_id", "transaction_type", "value_usd", "announced_date"],
    "technology_platform": ["name", "category", "readiness_level"],
    "drug_target_mechanism": ["asset_id", "protein_id", "mechanism", "affinity_value"],
    "bio_activity": ["asset_id", "pathway_id", "activity_type"],
    "therapeutic_efficacy": ["asset_id", "indication_id", "phenotype_id", "direction", "magnitude"],
    "subject": ["subject_identifier", "organism_id", "sex", "cohort_name"],
    "source": ["source_type", "external_id", "title"],
    "dosage_protocol": ["asset_id", "route", "dose_value", "frequency", "goal"],
}


def _format_item_compact(item: dict, entity_type: str) -> str:
    """Format a single entity as a compact one-line string."""
    item_id = item.get("id", "?")
    fields = DISPLAY_FIELDS.get(entity_type)

    if fields:
        parts = [f"id={item_id}"]
        for field in fields:
            val = item.get(field)
            if val is not None:
                val_str = str(val)
                if len(val_str) > 50:
                    val_str = val_str[:47] + "..."
                parts.append(f"{field}={val_str}")
        return ", ".join(parts)
    else:
        # Generic: show first 5 non-internal fields
        skip = {"id", "created_at", "updated_at", "deleted_at", "deleted_by",
                "created_by", "updated_by", "is_curated", "organization_id"}
        parts = [f"id={item_id}"]
        count = 0
        for key, val in item.items():
            if key in skip or val is None:
                continue
            val_str = str(val)
            if len(val_str) > 50:
                val_str = val_str[:47] + "..."
            parts.append(f"{key}={val_str}")
            count += 1
            if count >= 5:
                break
        return ", ".join(parts)


def _format_item_detail(item: dict) -> str:
    """Format a single entity with all fields."""
    skip = {"deleted_at", "deleted_by"}
    lines = []
    for key, val in item.items():
        if key in skip:
            continue
        if val is None:
            continue
        val_str = str(val)
        if len(val_str) > 200:
            val_str = val_str[:197] + "..."
        lines.append(f"  {key}: {val_str}")
    return "\n".join(lines)


@mcp.tool(annotations={"readOnlyHint": True})
async def search_entities(
    entity_type: EntityType,
    query: str | None = None,
    limit: int = 20,
    offset: int = 0,
    scope: Scope = "all",
    ctx: Context = None,
) -> str:
    """Search and list entities of any type. Supports all 61 entity types in the platform.

    entity_type: snake_case name (e.g. gene, protein, therapeutic_asset, market_organization, patent, etc.)
    query: optional text search (e.g. "APOE", "rapamycin", "Pfizer") — filters by the entity's primary field
    scope: "all" (curated + org), "curated" (platform data only), "own" (your org only)
    limit/offset: for pagination

    Common entity types by domain:
      Omics: gene, protein, variant, organism, transcript
      Clinical: indication, phenotype, biomarker, pathway, dosage_protocol
      Assets: therapeutic_asset, small_molecule, biologic, therapeutic_peptide, oligonucleotide
      LIMS: subject, biospecimen, assay_protocol, assay_run, assay_readout
      User: user_variant, user_biomarker_reading, user_treatment_log, pathway_score, recommendation
      Knowledge Graph: drug_target_mechanism, bio_activity, therapeutic_efficacy, drug_interaction, genomic_association
      Commercial: market_organization, patent, development_pipeline, regulatory_approval, licensing_agreement, transaction"""
    route = ENTITY_ROUTES.get(entity_type)
    if not route:
        valid = ", ".join(sorted(ENTITY_ROUTES.keys()))
        return f"Error: Unknown entity type '{entity_type}'. Valid types:\n{valid}"

    client = await get_client(ctx)
    params: dict = {"limit": limit, "offset": offset}
    if scope != "all":
        params["scope"] = scope
    if query:
        params["search"] = query

    result = await client.get(f"{route}/", params=params)
    items = result.get("data", [])

    if not items:
        return f"No {entity_type} entities found (scope={scope})."

    lines = [f"{entity_type} ({len(items)} results, offset={offset}):"]
    for item in items:
        lines.append(f"  - {_format_item_compact(item, entity_type)}")

    return "\n".join(lines)


@mcp.tool(annotations={"readOnlyHint": True})
async def get_entity(entity_type: EntityType, entity_id: int, ctx: Context = None) -> str:
    """Get full details of a specific entity by type and ID.

    entity_type: snake_case name (e.g. gene, protein, therapeutic_asset, market_organization)
    entity_id: the integer ID of the entity

    Returns all fields for the entity."""
    route = ENTITY_ROUTES.get(entity_type)
    if not route:
        valid = ", ".join(sorted(ENTITY_ROUTES.keys()))
        return f"Error: Unknown entity type '{entity_type}'. Valid types:\n{valid}"

    client = await get_client(ctx)
    result = await client.get(f"{route}/{entity_id}")
    data = result.get("data", result)

    if not data:
        return f"No {entity_type} found with id={entity_id}."

    lines = [f"{entity_type} (id={entity_id}):"]
    lines.append(_format_item_detail(data))

    return "\n".join(lines)


@mcp.tool(annotations={"readOnlyHint": True})
async def search_graph(
    query: str,
    entity_type: EntityType | None = None,
    limit: int = 10,
    ctx: Context = None,
) -> str:
    """Search across the entire biomedical knowledge graph by name/identifier.
    Returns matching entities ranked across all entity types in a single call.
    Use this to quickly find entity IDs before calling explore_network() or get_entity().

    query: search term (e.g. "APOE", "rapamycin", "Pfizer", "Alzheimer")
    entity_type: optional — limit search to one type (e.g. "gene", "protein")
    limit: max results (default 10)

    Examples:
      search_graph("APOE") → gene APOE + protein APOE + variant rs429358
      search_graph("rapamycin") → drug Rapamycin + protein mTOR + pathway mTOR Signaling
      search_graph("Pfizer", entity_type="market_organization") → Pfizer Inc."""
    client = await get_client(ctx)
    params: dict = {"q": query, "limit": limit}
    if entity_type:
        params["entity_type"] = entity_type

    result = await client.get("/nexotype/search/", params=params)
    items = result.get("data", [])

    if not items:
        return f"No results found for '{query}'."

    lines = [f"Search results for '{query}' ({len(items)} matches):"]
    for item in items:
        etype = item.get("type", "?")
        eid = item.get("id", "?")
        label = item.get("label", "?")
        lines.append(f"  - {etype}:{eid} — {label}")

    return "\n".join(lines)
