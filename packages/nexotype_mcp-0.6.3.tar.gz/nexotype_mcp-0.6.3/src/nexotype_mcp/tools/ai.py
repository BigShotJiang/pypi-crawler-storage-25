"""
AI query tool — natural language questions against the knowledge graph.

Uses the backend's GraphRAG agent (pydantic-ai) which traverses SurrealDB
to generate grounded answers with source attribution.
"""

from fastmcp import Context

from ..server import mcp
from ..client import get_client


@mcp.tool(annotations={"readOnlyHint": True})
async def ask_knowledge_graph(question: str, max_depth: int = 10, ctx: Context = None) -> str:
    """Ask a natural language question about the biomedical knowledge graph.
    The AI agent searches the graph, traverses relationships, and generates
    a grounded answer citing specific entities. No hallucination — every claim
    is traced to graph data.

    Examples:
      - "What drugs target EGFR and are in Phase III?"
      - "Which companies work on mTOR inhibitors?"
      - "What does Rapamycin target?"
      - "What variants are associated with Alzheimer's risk?"
      - "Compare GLP-1 receptor agonists across companies"

    max_depth controls how deep the graph traversal goes (default 10)."""
    client = await get_client(ctx)
    result = await client.post(
        "/nexotype/ai/query",
        data={"question": question, "max_depth": max_depth},
    )

    # Check for error
    error = result.get("error")
    if error:
        return f"Error: {error}"

    # Format response
    answer = result.get("answer", "No answer generated.")
    sources = result.get("sources", [])
    nodes_used = result.get("graph_nodes_used", 0)
    model = result.get("model", "unknown")

    lines = [f"Question: {result.get('question', question)}\n"]
    lines.append(f"Answer: {answer}\n")

    if sources:
        lines.append(f"Sources ({len(sources)}):")
        for src in sources:
            src_type = src.get("type", "?")
            src_id = src.get("id", 0)
            src_label = src.get("label", "?")
            relevance = src.get("relevance", "")
            rel_str = f" — {relevance}" if relevance else ""
            lines.append(f"  - {src_label} ({src_type}, id={src_id}){rel_str}")

    lines.append(f"\nGraph nodes traversed: {nodes_used}")
    lines.append(f"Model: {model}")

    return "\n".join(lines)
