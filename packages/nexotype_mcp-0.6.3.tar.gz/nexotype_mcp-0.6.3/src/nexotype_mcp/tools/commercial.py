"""
Commercial intelligence tools — Enterprise tier.

Dedicated tools for market organizations, patents, development pipelines,
regulatory approvals, and licensing agreements. All read-only.
These are separate from search_entities() for domain-specific formatting
and to signal premium Enterprise features to the LLM.
"""

from fastmcp import Context

from ..server import mcp
from ..client import get_client


@mcp.tool(annotations={"readOnlyHint": True})
async def list_market_organizations(limit: int = 20, offset: int = 0, ctx: Context = None) -> str:
    """List pharma/biotech companies, universities, and market organizations.
    Enterprise tier required. Shows: legal name, ticker, exchange, type, status, HQ.

    Use company_deep_dive() for full portfolio of a specific company."""
    client = await get_client(ctx)
    result = await client.get(
        "/nexotype/market-organizations/",
        params={"limit": limit, "offset": offset},
    )
    items = result.get("data", [])

    if not items:
        return "No market organizations found."

    lines = [f"Market Organizations ({len(items)}):"]
    for org in items:
        name = org.get("legal_name", "?")
        ticker = org.get("ticker_symbol", "")
        exchange = org.get("primary_exchange", "")
        org_type = org.get("org_type", "—")
        status = org.get("status", "—")
        hq = org.get("headquarters", "—")

        ticker_str = f" [{ticker} / {exchange}]" if ticker else ""
        lines.append(f"  - {name}{ticker_str} (id={org['id']}, type={org_type}, status={status}, HQ: {hq})")

    return "\n".join(lines)


@mcp.tool(annotations={"readOnlyHint": True})
async def get_market_organization(org_id: int, ctx: Context = None) -> str:
    """Get full details of a specific market organization.
    Enterprise tier required. Shows all fields including ISIN, financials, and founding date.

    For full portfolio (assets, patents, pipelines), use company_deep_dive() instead."""
    client = await get_client(ctx)
    result = await client.get(f"/nexotype/market-organizations/{org_id}")
    data = result.get("data", result)

    if not data:
        return f"No market organization found with id={org_id}."

    lines = [f"Market Organization (id={org_id}):"]
    fields = [
        ("legal_name", "Legal Name"),
        ("isin", "ISIN"),
        ("ticker_symbol", "Ticker"),
        ("primary_exchange", "Exchange"),
        ("org_type", "Type"),
        ("status", "Status"),
        ("founded", "Founded"),
        ("headquarters", "Headquarters"),
        ("website", "Website"),
        ("employee_count", "Employees"),
        ("revenue_usd", "Revenue (USD)"),
    ]
    for key, label in fields:
        val = data.get(key)
        if val is not None:
            if key == "employee_count" and isinstance(val, (int, float)):
                val = f"{int(val):,}"
            elif key == "revenue_usd" and isinstance(val, (int, float)):
                val = f"${val:,.0f}"
            lines.append(f"  {label}: {val}")

    return "\n".join(lines)


@mcp.tool(annotations={"readOnlyHint": True})
async def list_patents(limit: int = 20, offset: int = 0, ctx: Context = None) -> str:
    """List patents with jurisdiction, number, title, status, and dates.
    Enterprise tier required.

    For patent claims and assignees, use search_entities() with patent_claim or patent_assignee."""
    client = await get_client(ctx)
    result = await client.get(
        "/nexotype/patents/",
        params={"limit": limit, "offset": offset},
    )
    items = result.get("data", [])

    if not items:
        return "No patents found."

    lines = [f"Patents ({len(items)}):"]
    for p in items:
        jurisdiction = p.get("jurisdiction", "?")
        number = p.get("patent_number", "?")
        title = p.get("title", "—")
        status = p.get("status", "—")
        filing = p.get("filing_date", "—")
        expiry = p.get("expiry_date", "—")

        if title and len(title) > 60:
            title = title[:57] + "..."

        lines.append(
            f"  - {jurisdiction} {number} | {status} | filed={filing}, expires={expiry} (id={p['id']})\n"
            f"    {title}"
        )

    return "\n".join(lines)


@mcp.tool(annotations={"readOnlyHint": True})
async def list_development_pipelines(limit: int = 20, offset: int = 0, ctx: Context = None) -> str:
    """List drug development pipeline entries — clinical trial phases per indication.
    Enterprise tier required. Shows: asset, indication, phase, status, NCT number.

    For full company pipeline view, use company_deep_dive()."""
    client = await get_client(ctx)
    result = await client.get(
        "/nexotype/development-pipelines/",
        params={"limit": limit, "offset": offset},
    )
    items = result.get("data", [])

    if not items:
        return "No development pipeline entries found."

    lines = [f"Development Pipelines ({len(items)}):"]
    for p in items:
        asset_id = p.get("asset_id", "?")
        indication_id = p.get("indication_id", "?")
        phase = p.get("phase", "?")
        status = p.get("status", "?")
        nct = p.get("nct_number", "")

        nct_str = f" | NCT: {nct}" if nct else ""
        lines.append(
            f"  - {phase} | {status} | asset={asset_id}, indication={indication_id}{nct_str} (id={p['id']})"
        )

    return "\n".join(lines)


@mcp.tool(annotations={"readOnlyHint": True})
async def list_regulatory_approvals(limit: int = 20, offset: int = 0, ctx: Context = None) -> str:
    """List regulatory approvals (FDA, EMA, PMDA, etc.) for therapeutic assets.
    Enterprise tier required. Shows: asset, indication, agency, approval type, date, status."""
    client = await get_client(ctx)
    result = await client.get(
        "/nexotype/regulatory-approvals/",
        params={"limit": limit, "offset": offset},
    )
    items = result.get("data", [])

    if not items:
        return "No regulatory approvals found."

    lines = [f"Regulatory Approvals ({len(items)}):"]
    for a in items:
        asset_id = a.get("asset_id", "?")
        indication_id = a.get("indication_id", "?")
        agency = a.get("agency", "?")
        approval_type = a.get("approval_type", "?")
        approval_date = a.get("approval_date", "?")
        status = a.get("status", "?")

        lines.append(
            f"  - {agency} {approval_type} | {status} | date={approval_date} | "
            f"asset={asset_id}, indication={indication_id} (id={a['id']})"
        )

    return "\n".join(lines)


@mcp.tool(annotations={"readOnlyHint": True})
async def list_licensing_agreements(limit: int = 20, offset: int = 0, ctx: Context = None) -> str:
    """List licensing agreements between market organizations.
    Enterprise tier required. Shows: licensor, licensee, type, territory, value, dates, status."""
    client = await get_client(ctx)
    result = await client.get(
        "/nexotype/licensing-agreements/",
        params={"limit": limit, "offset": offset},
    )
    items = result.get("data", [])

    if not items:
        return "No licensing agreements found."

    lines = [f"Licensing Agreements ({len(items)}):"]
    for a in items:
        licensor = a.get("licensor_id", "?")
        licensee = a.get("licensee_id", "?")
        agreement_type = a.get("agreement_type", "?")
        territory = a.get("territory", "—")
        value = a.get("value_usd")
        start = a.get("start_date", "?")
        end = a.get("end_date", "ongoing")
        status = a.get("status", "?")

        value_str = f"${value:,.0f}" if value else "—"
        lines.append(
            f"  - {agreement_type} | {status} | licensor={licensor} → licensee={licensee} | "
            f"territory={territory} | value={value_str} | {start} to {end} (id={a['id']})"
        )

    return "\n".join(lines)
