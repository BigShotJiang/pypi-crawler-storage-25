"""
Nexotype MCP Server — OAuth Provider

Bridges FastMCP's OAuth flow with Nexotype's real OAuth authorization server.
Makes HTTP requests to server.nexotype.com/accounts/mcp-oauth/* endpoints.

Runs as standalone process (not mounted on FastAPI) — no mount/sub-path issues.
FastMCP handles well-known, register, authorize, token routing at root automatically.

Complete OAuth 2.0 + PKCE flow:
1. Claude calls POST /register → we proxy to server /accounts/mcp-oauth/register (saves client in DB)
2. Claude calls GET /authorize → we return URL to server /accounts/mcp-oauth/authorize
3. Server redirects to client.nexotype.com/mcp-authorize (consent page)
4. User clicks Allow → frontend POSTs to server /accounts/mcp-oauth/approve → generates auth code
5. Browser redirects to http://localhost:PORT/callback?code=AUTH_CODE → Claude receives code
6. Claude calls POST /token → FastMCP validates PKCE internally, then calls our exchange_authorization_code()
7. We proxy to server /accounts/mcp-oauth/token → server generates JWT → returned to Claude
8. Claude: Connected ✓

Why standalone (not mounted on FastAPI):
    Mounting FastMCP as sub-app on FastAPI caused well-known path routing issues,
    lifespan initialization failures, and Traefik networking problems on Coolify.
    Standalone deployment on mcp.nexotype.com eliminates all mount issues.

Why HTTP proxy (not direct DB):
    MCP runs as separate container on Coolify — no access to server's PostgreSQL.
    Auth endpoints on server handle DB operations, MCP proxies via HTTP.
"""

import time
import logging
from dataclasses import dataclass
from urllib.parse import quote

import httpx
from mcp.server.auth.provider import AuthorizationParams, RefreshToken
from mcp.shared.auth import OAuthClientInformationFull, OAuthToken
from fastmcp.server.auth import OAuthProvider, AccessToken
from mcp.server.auth.settings import ClientRegistrationOptions

from .config import API_BASE_URL, REQUEST_TIMEOUT

logger = logging.getLogger(__name__)


@dataclass
class StoredAuthorizationCode:
    """Authorization code object returned by load_authorization_code().

    FastMCP token handler (mcp/server/auth/handlers/token.py) expects these attributes:
    - client_id: must match token_request.client_id (line 41)
    - expires_at: unix timestamp, checked against time.time() (line 52)
    - redirect_uri: must match token_request.redirect_uri exactly (line 73)
    - redirect_uri_provided_explicitly: controls redirect_uri validation (line 62)
    - code_challenge: compared against SHA256(code_verifier) for PKCE (line 85)
    """
    code: str
    client_id: str
    redirect_uri: str
    redirect_uri_provided_explicitly: bool
    code_challenge: str
    expires_at: float = 0.0  # Unix timestamp — FastMCP checks auth_code.expires_at < time.time()


class NexotypeOAuthProvider(OAuthProvider):
    """OAuth provider that proxies to Nexotype server's OAuth endpoints via HTTP.

    In-memory state (lost on container restart — users re-authenticate):
    - _clients: registered clients (FastMCP UUID → OAuthClientInformationFull)
    - _access_tokens: JWT cache for verify_token() (avoids hitting server on every tool call)
    """

    def __init__(self, base_url: str) -> None:
        super().__init__(
            base_url=base_url,
            # Enable dynamic client registration — Claude registers itself on first connect
            client_registration_options=ClientRegistrationOptions(enabled=True),
        )
        self._access_tokens: dict[str, AccessToken] = {}
        self._clients: dict[str, OAuthClientInformationFull] = {}

    # ==========================================
    # Client Registration (RFC 7591)
    # ==========================================
    # FastMCP generates a UUID client_id at /register handler (RegistrationHandler).
    # We forward that UUID to our server so /approve can verify client exists in DB.

    async def register_client(self, client_info: OAuthClientInformationFull) -> None:
        """Proxy registration to server DB and cache locally for get_client()."""
        async with httpx.AsyncClient(timeout=REQUEST_TIMEOUT) as http:
            r = await http.post(
                f"{API_BASE_URL}/accounts/mcp-oauth/register",
                json={
                    # Forward FastMCP's UUID so server stores the same client_id
                    "client_id": client_info.client_id,
                    "client_name": client_info.client_name,
                    "redirect_uris": [str(u) for u in client_info.redirect_uris] if client_info.redirect_uris else None,
                    "grant_types": client_info.grant_types,
                    "token_endpoint_auth_method": client_info.token_endpoint_auth_method,
                },
            )
            if r.status_code in (200, 201):
                logger.info(f"Client registered on server: {client_info.client_id}")
        # Cache so get_client() returns redirect_uris (needed for redirect_uri validation)
        if client_info.client_id:
            self._clients[client_info.client_id] = client_info

    async def get_client(self, client_id: str) -> OAuthClientInformationFull | None:
        """Return cached client info. Called by FastMCP before authorize and token exchange."""
        return self._clients.get(client_id)

    # ==========================================
    # Authorization
    # ==========================================
    # FastMCP's AuthorizationHandler calls authorize() and redirects browser to returned URL.
    # We redirect to our server's GET /accounts/mcp-oauth/authorize which then redirects
    # to the frontend consent page (client.nexotype.com/mcp-authorize).

    async def authorize(
        self, client: OAuthClientInformationFull, params: AuthorizationParams
    ) -> str:
        """Return URL to server's authorize endpoint → redirects to frontend consent page."""
        # URL-encode params to prevent parsing issues with special characters
        authorize_url = (
            f"{API_BASE_URL}/accounts/mcp-oauth/authorize"
            f"?client_id={quote(str(client.client_id or ''))}"
            f"&redirect_uri={quote(str(params.redirect_uri))}"
            f"&code_challenge={quote(str(params.code_challenge))}"
            f"&code_challenge_method=S256"
            f"&response_type=code"
        )
        if params.state:
            authorize_url += f"&state={quote(str(params.state))}"
        if params.scopes:
            authorize_url += f"&scope={'+'.join(params.scopes)}"

        return authorize_url

    # ==========================================
    # Token Exchange
    # ==========================================
    # After user clicks Allow on consent page:
    # 1. Server generates auth code in DB → browser redirects to localhost:PORT/callback?code=...
    # 2. Claude sends POST /token with code + code_verifier
    # 3. FastMCP calls load_authorization_code() → we fetch from server DB
    # 4. FastMCP validates PKCE (SHA256(code_verifier) == code_challenge) internally
    # 5. FastMCP calls exchange_authorization_code() → we proxy to server /token → get JWT
    # 6. FastMCP returns JWT to Claude → Connected

    async def load_authorization_code(
        self, client: OAuthClientInformationFull, authorization_code: str
    ) -> StoredAuthorizationCode | None:
        """Fetch auth code details from server DB (code_challenge needed for PKCE)."""
        try:
            async with httpx.AsyncClient(timeout=REQUEST_TIMEOUT) as http:
                r = await http.get(
                    f"{API_BASE_URL}/accounts/mcp-oauth/code/{authorization_code}",
                )
                if r.status_code != 200:
                    logger.warning(f"Auth code not found on server: {authorization_code[:10]}...")
                    return None
                data = r.json()
                return StoredAuthorizationCode(
                    code=data["code"],
                    client_id=data["client_id"],
                    redirect_uri=data["redirect_uri"],
                    redirect_uri_provided_explicitly=True,
                    code_challenge=data["code_challenge"],
                    expires_at=time.time() + 300,  # 5 min window (server also checks expiry)
                )
        except Exception as e:
            logger.warning(f"Failed to load auth code from server: {e}")
            return None

    async def exchange_authorization_code(
        self, client: OAuthClientInformationFull, authorization_code: StoredAuthorizationCode
    ) -> OAuthToken:
        """Proxy token exchange to server. Called AFTER FastMCP validates PKCE internally.
        Server /token does NOT re-validate PKCE (already done by FastMCP)."""
        async with httpx.AsyncClient(timeout=REQUEST_TIMEOUT) as http:
            r = await http.post(
                f"{API_BASE_URL}/accounts/mcp-oauth/token",
                data={
                    "grant_type": "authorization_code",
                    "code": authorization_code.code,
                    "client_id": client.client_id,
                    "client_secret": client.client_secret or "",
                    "redirect_uri": authorization_code.redirect_uri,
                },
                headers={"Content-Type": "application/x-www-form-urlencoded"},
            )

            if r.status_code != 200:
                data = r.json()
                raise ValueError(data.get("error_description", "Token exchange failed"))

            data = r.json()
            access_token = data["access_token"]
            refresh_token = data.get("refresh_token")

            # Cache JWT so verify_token() doesn't hit server on every tool call
            self._access_tokens[access_token] = AccessToken(
                token=access_token,
                client_id=client.client_id or "",
                scopes=["all"],
                expires_at=int(time.time()) + data.get("expires_in", 1800),
            )

            return OAuthToken(
                access_token=access_token,
                token_type="Bearer",
                expires_in=data.get("expires_in", 1800),
                refresh_token=refresh_token,
            )

    async def exchange_refresh_token(
        self, client: OAuthClientInformationFull, refresh_token: RefreshToken, scopes: list[str]
    ) -> OAuthToken:
        """Proxy refresh token exchange to server for new JWT pair.
        FastMCP passes a RefreshToken object here (result of load_refresh_token),
        not a raw string — we send refresh_token.token to the server.
        """
        async with httpx.AsyncClient(timeout=REQUEST_TIMEOUT) as http:
            r = await http.post(
                f"{API_BASE_URL}/accounts/mcp-oauth/token",
                data={
                    "grant_type": "refresh_token",
                    "refresh_token": refresh_token.token,
                    "client_id": client.client_id,
                    "client_secret": client.client_secret or "",
                },
                headers={"Content-Type": "application/x-www-form-urlencoded"},
            )

            if r.status_code != 200:
                raise ValueError("Refresh token expired or invalid")

            data = r.json()
            new_access = data["access_token"]

            self._access_tokens[new_access] = AccessToken(
                token=new_access,
                client_id=client.client_id or "",
                scopes=["all"],
                expires_at=int(time.time()) + data.get("expires_in", 1800),
            )

            return OAuthToken(
                access_token=new_access,
                token_type="Bearer",
                expires_in=data.get("expires_in", 1800),
                refresh_token=data.get("refresh_token"),
            )

    # ==========================================
    # Token Validation (called on every tool call)
    # ==========================================

    async def load_access_token(self, token: str) -> AccessToken | None:
        """Load JWT from in-memory cache. Fast path — avoids HTTP call to server."""
        return self._access_tokens.get(token)

    async def verify_token(self, token: str) -> AccessToken | None:
        """Verify JWT by calling server's /accounts/auth/me endpoint.
        Fallback when token not in cache (e.g., after MCP container restart)."""
        try:
            async with httpx.AsyncClient(timeout=10.0) as http:
                r = await http.get(
                    f"{API_BASE_URL}/accounts/auth/me",
                    headers={"Authorization": f"Bearer {token}"},
                )
                if r.status_code == 200:
                    if token not in self._access_tokens:
                        self._access_tokens[token] = AccessToken(
                            token=token,
                            client_id="",
                            scopes=["all"],
                            expires_at=int(time.time()) + 1800,
                        )
                    return self._access_tokens[token]
        except httpx.HTTPError as e:
            logger.warning(f"Token verification failed: {e}")
        return None

    async def load_refresh_token(
        self, client: OAuthClientInformationFull, refresh_token: str
    ) -> RefreshToken | None:
        """Accept any refresh token — server validates on actual exchange.
        Must return a RefreshToken object (not raw string) — FastMCP's token
        handler accesses .client_id on the result. Returning a string crashed
        with AttributeError on every refresh after access token expiry (~30 min).
        Same fix as V7capital v0.9.4.
        """
        return RefreshToken(
            token=refresh_token,
            client_id=client.client_id,
            scopes=["all"],
        )

    # ==========================================
    # Revocation
    # ==========================================

    async def revoke_token(self, token) -> None:
        """Remove from in-memory cache. Server token remains valid until expiry."""
        self._access_tokens.pop(str(token), None)
