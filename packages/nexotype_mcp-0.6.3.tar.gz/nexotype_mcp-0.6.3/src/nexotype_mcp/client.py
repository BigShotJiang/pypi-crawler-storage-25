"""
Nexotype MCP Server — HTTP Client

Async httpx wrapper that handles:
- JWT authentication (from ~/.nexotype/credentials.json or OAuth token)
- Subject context (for personalization tools)
- Automatic token refresh on 401 responses
- Multipart file upload for VCF files

Two modes:
- Local (stdio): token read from ~/.nexotype/credentials.json (token=None)
- Remote (HTTP): token passed from OAuth flow via get_client(ctx)

Key difference from Finpy: Nexotype backend resolves organization from JWT,
so no organization_id query param is needed.
"""

import httpx
from fastmcp import Context
from fastmcp.server.dependencies import get_access_token

from .config import API_BASE_URL, REQUEST_TIMEOUT, UPLOAD_TIMEOUT
from .credentials import load_credentials, save_credentials


class NexotypeClient:
    """HTTP client for Nexotype API with JWT auth and subject context.

    Two modes:
    - Local (stdio): token read from ~/.nexotype/credentials.json (token=None)
    - Remote (HTTP): token passed from OAuth flow (token="eyJ...")
    """

    def __init__(self, token: str | None = None) -> None:
        self.base_url = API_BASE_URL
        # Subject context — set via set_subject() tool for personalization queries
        self.subject_id: int | None = None
        self._token = token  # Remote mode: JWT from OAuth header

    def _get_credentials(self) -> dict:
        """Load credentials or raise descriptive error."""
        creds = load_credentials()
        if not creds or not creds.get("access_token"):
            raise RuntimeError(
                "Not authenticated. Please run 'nexotype-cli login' in your terminal first."
            )
        return creds

    @property
    def _headers(self) -> dict:
        """Auth headers — from OAuth token (remote) or stored credentials (local)."""
        if self._token:
            return {"Authorization": f"Bearer {self._token}"}
        creds = self._get_credentials()
        return {"Authorization": f"Bearer {creds['access_token']}"}

    async def _refresh_token(self) -> bool:
        """Attempt to refresh JWT using refresh_token. Returns True if successful.
        Remote mode: no local refresh — OAuth provider handles refresh via FastMCP."""
        if self._token:
            return False

        creds = load_credentials()
        if not creds or not creds.get("refresh_token"):
            return False

        try:
            async with httpx.AsyncClient(timeout=REQUEST_TIMEOUT) as http:
                r = await http.post(
                    f"{self.base_url}/accounts/auth/refresh-token",
                    json={"refresh_token": creds["refresh_token"]},
                )
                if r.status_code == 200:
                    data = r.json()
                    creds["access_token"] = data["token"]["access_token"]
                    creds["refresh_token"] = data["token"]["refresh_token"]
                    save_credentials(creds)
                    return True
        except httpx.HTTPError:
            pass
        return False

    async def _request(self, method: str, path: str, **kwargs) -> dict:
        """Make HTTP request with auto-refresh on 401."""
        async with httpx.AsyncClient(timeout=REQUEST_TIMEOUT) as http:
            r = await http.request(
                method,
                f"{self.base_url}{path}",
                headers=self._headers,
                **kwargs,
            )

            # Auto-refresh on 401
            if r.status_code == 401:
                refreshed = await self._refresh_token()
                if refreshed:
                    r = await http.request(
                        method,
                        f"{self.base_url}{path}",
                        headers=self._headers,
                        **kwargs,
                    )
                else:
                    if self._token:
                        raise RuntimeError("Session expired. Please re-authenticate via /mcp → Authenticate.")
                    raise RuntimeError("Session expired. Please run 'nexotype-cli login' again.")

            r.raise_for_status()
            return r.json()

    async def get(self, path: str, **kwargs) -> dict:
        """GET request to Nexotype API."""
        return await self._request("GET", path, **kwargs)

    async def post(self, path: str, data: dict) -> dict:
        """POST request to Nexotype API."""
        return await self._request("POST", path, json=data)

    async def put(self, path: str, data: dict) -> dict:
        """PUT request to Nexotype API."""
        return await self._request("PUT", path, json=data)

    async def post_file(self, path: str, file_path: str, form_data: dict) -> dict:
        """
        POST multipart file upload to Nexotype API.
        Used for VCF/23andMe genomic file uploads.
        Longer timeout (120s) for large files.
        """
        async with httpx.AsyncClient(timeout=UPLOAD_TIMEOUT) as http:
            with open(file_path, "rb") as f:
                files = {"file": (file_path.split("/")[-1], f)}
                r = await http.post(
                    f"{self.base_url}{path}",
                    headers=self._headers,
                    files=files,
                    data=form_data,
                )

            # Auto-refresh on 401
            if r.status_code == 401:
                refreshed = await self._refresh_token()
                if refreshed:
                    with open(file_path, "rb") as f:
                        files = {"file": (file_path.split("/")[-1], f)}
                        r = await http.post(
                            f"{self.base_url}{path}",
                            headers=self._headers,
                            files=files,
                            data=form_data,
                        )
                else:
                    if self._token:
                        raise RuntimeError("Session expired. Please re-authenticate via /mcp → Authenticate.")
                    raise RuntimeError("Session expired. Please run 'nexotype-cli login' again.")

            r.raise_for_status()
            return r.json()


# Singleton instance — used in local/stdio mode (single user)
nexotype = NexotypeClient()


async def get_client(ctx: Context) -> NexotypeClient:
    """Get a NexotypeClient for the current request.
    Local mode (no auth token): returns singleton.
    Remote mode (auth token present): creates per-request client with session state."""
    token_obj = get_access_token()
    if not token_obj:
        # Local mode — use singleton
        return nexotype

    # Remote mode — per-request client with user's JWT
    client = NexotypeClient(token=token_obj.token)

    # Restore subject_id from session state (set by set_subject tool)
    client.subject_id = await ctx.get_state("subject_id")

    return client
