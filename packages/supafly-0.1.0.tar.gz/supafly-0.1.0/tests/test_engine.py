from __future__ import annotations

import os
import tempfile
import unittest
from pathlib import Path

from supafly.engine import diff_workspace, init_workspace, sync_workspace, validate_workspace


CONFIG = """version: 1
targets:
  - claude
  - codex
  - cursor
include_context:
  references: true
  current_focus: true
  decisions: true
  sessions: false
ignore:
  - ".env"
output_paths:
  claude: "CLAUDE.md"
  codex: "AGENTS.md"
  cursor: ".cursor/rules/"
commit_generated:
  claude: true
  codex: true
  cursor: true
"""

PROJECT = """---
kind: instruction
title: Project Context
description: Core repo guidance
priority: high
targets:
  - claude
  - codex
  - cursor
---
Use Python 3.14.
"""

DECISION = """---
kind: decision
title: Language Choice
priority: medium
targets:
  - claude
  - codex
  - cursor
---
Python for Phase 1.
"""

SCOPED_RULE = """---
kind: instruction
title: Frontend Rules
description: Rules for frontend code
priority: high
scopes:
  - "src/**/*.ts"
  - "src/**/*.tsx"
targets:
  - claude
  - codex
  - cursor
---
Use functional components. No class components.
"""

IDENTITY = """---
kind: instruction
title: Identity
description: Team identity
priority: high
targets:
  - claude
  - codex
  - cursor
---
We are the Supafly team.
"""

FEEDBACK = """---
kind: instruction
title: Feedback
description: Agent preferences
priority: high
targets:
  - claude
  - codex
  - cursor
---
Keep responses concise.
"""

LOCAL_NOTE = """---
kind: note
title: Personal Scratch
priority: low
targets:
  - codex
---
Do not include this in generated output.
"""


class EngineTests(unittest.TestCase):
    def test_init_creates_workspace_templates(self) -> None:
        with tempfile.TemporaryDirectory() as tmp_dir:
            project_root = Path(tmp_dir)
            init_result = init_workspace(project_root)
            self.assertEqual(project_root / ".supafly", init_result.workspace_path)
            self.assertTrue((project_root / ".supafly" / "config.yaml").exists())
            self.assertTrue((project_root / ".supafly" / ".gitignore").exists())
            self.assertTrue((project_root / ".supafly" / "identity.md").exists())
            self.assertTrue((project_root / ".supafly" / "project.md").exists())
            self.assertTrue((project_root / ".supafly" / "rule-general.md").exists())
            self.assertTrue((project_root / ".supafly" / "feedback.md").exists())
            self.assertTrue((project_root / ".supafly" / "references.md").exists())

    def test_init_gitignore_ignores_local(self) -> None:
        with tempfile.TemporaryDirectory() as tmp_dir:
            project_root = Path(tmp_dir)
            init_workspace(project_root)
            gitignore = (project_root / ".supafly" / ".gitignore").read_text(encoding="utf-8")
            self.assertIn("local/", gitignore)

    def test_validate_reports_success_for_valid_workspace(self) -> None:
        with tempfile.TemporaryDirectory() as tmp_dir:
            project_root = Path(tmp_dir)
            self._write_workspace(project_root)
            report = validate_workspace(project_root)
            self.assertEqual([], report.errors)
            self.assertEqual([], report.warnings)

    def test_diff_detects_rendered_agents_output(self) -> None:
        with tempfile.TemporaryDirectory() as tmp_dir:
            project_root = Path(tmp_dir)
            self._write_workspace(project_root)
            report, diff_result = diff_workspace(project_root)
            self.assertEqual([], report.errors)
            assert diff_result is not None
            codex_outputs = [o for o in diff_result.changed_outputs if o.target == "codex"]
            self.assertEqual(1, len(codex_outputs))
            rendered = codex_outputs[0].content
            self.assertIn("<!-- Supafly: auto-generated -->", rendered)
            self.assertIn("## Project Context", rendered)
            self.assertIn("## Language Choice", rendered)
            self.assertNotIn("Personal Scratch", rendered)

    def test_diff_renders_claude_md(self) -> None:
        with tempfile.TemporaryDirectory() as tmp_dir:
            project_root = Path(tmp_dir)
            self._write_workspace(project_root)
            report, diff_result = diff_workspace(project_root)
            self.assertEqual([], report.errors)
            assert diff_result is not None
            claude_outputs = [o for o in diff_result.changed_outputs if o.target == "claude"]
            main_outputs = [o for o in claude_outputs if o.path.name == "CLAUDE.md"]
            self.assertEqual(1, len(main_outputs))
            rendered = main_outputs[0].content
            self.assertIn("<!-- Supafly: auto-generated -->", rendered)
            self.assertIn("# CLAUDE.md", rendered)
            self.assertIn("## Project Context", rendered)
            self.assertIn("## Language Choice", rendered)
            self.assertNotIn("Personal Scratch", rendered)

    def test_diff_renders_claude_scoped_rules(self) -> None:
        with tempfile.TemporaryDirectory() as tmp_dir:
            project_root = Path(tmp_dir)
            self._write_workspace(project_root, include_scoped=True)
            report, diff_result = diff_workspace(project_root)
            self.assertEqual([], report.errors)
            assert diff_result is not None
            claude_rule_outputs = [
                o for o in diff_result.changed_outputs
                if o.target == "claude" and ".claude/rules" in str(o.path)
            ]
            self.assertEqual(1, len(claude_rule_outputs))
            rule = claude_rule_outputs[0]
            self.assertIn("Frontend Rules", rule.content)
            self.assertIn("`src/**/*.ts`", rule.content)

    def test_diff_renders_cursor_rules(self) -> None:
        with tempfile.TemporaryDirectory() as tmp_dir:
            project_root = Path(tmp_dir)
            self._write_workspace(project_root)
            report, diff_result = diff_workspace(project_root)
            self.assertEqual([], report.errors)
            assert diff_result is not None
            cursor_outputs = [o for o in diff_result.changed_outputs if o.target == "cursor"]
            self.assertTrue(len(cursor_outputs) > 0)
            filenames = [o.path.name for o in cursor_outputs]
            self.assertTrue(any(f.endswith(".mdc") for f in filenames))
            for output in cursor_outputs:
                self.assertIn("<!-- Supafly: auto-generated -->", output.content)

    def test_cursor_merges_identity_and_feedback(self) -> None:
        with tempfile.TemporaryDirectory() as tmp_dir:
            project_root = Path(tmp_dir)
            self._write_workspace(project_root, include_identity_feedback=True)
            report, diff_result = diff_workspace(project_root)
            self.assertEqual([], report.errors)
            assert diff_result is not None
            cursor_outputs = [o for o in diff_result.changed_outputs if o.target == "cursor"]
            prefs = [o for o in cursor_outputs if o.path.name == "preferences.mdc"]
            self.assertEqual(1, len(prefs))
            content = prefs[0].content
            self.assertIn("## Identity", content)
            self.assertIn("## Feedback", content)
            self.assertIn("description: User preferences and identity", content)

    def test_cursor_scoped_rule_has_globs(self) -> None:
        with tempfile.TemporaryDirectory() as tmp_dir:
            project_root = Path(tmp_dir)
            self._write_workspace(project_root, include_scoped=True)
            report, diff_result = diff_workspace(project_root)
            self.assertEqual([], report.errors)
            assert diff_result is not None
            cursor_outputs = [o for o in diff_result.changed_outputs if o.target == "cursor"]
            scoped = [o for o in cursor_outputs if o.path.name == "frontend-rules.mdc"]
            self.assertEqual(1, len(scoped))
            content = scoped[0].content
            self.assertIn('globs: ["src/**/*.ts", "src/**/*.tsx"]', content)

    def test_sync_writes_all_targets(self) -> None:
        with tempfile.TemporaryDirectory() as tmp_dir:
            project_root = Path(tmp_dir)
            self._write_workspace(project_root)
            report, diff_result = sync_workspace(project_root)
            self.assertEqual([], report.errors)
            assert diff_result is not None
            self.assertTrue((project_root / "AGENTS.md").exists())
            self.assertTrue((project_root / "CLAUDE.md").exists())
            cursor_dir = project_root / ".cursor" / "rules"
            self.assertTrue(cursor_dir.exists())
            mdc_files = list(cursor_dir.glob("*.mdc"))
            self.assertTrue(len(mdc_files) > 0)

    def test_sync_check_detects_stale_outputs(self) -> None:
        with tempfile.TemporaryDirectory() as tmp_dir:
            project_root = Path(tmp_dir)
            self._write_workspace(project_root)
            sync_workspace(project_root)
            (project_root / "AGENTS.md").write_text("stale content", encoding="utf-8")
            report, diff_result = sync_workspace(project_root, check=True)
            self.assertEqual([], report.errors)
            assert diff_result is not None
            self.assertTrue(len(diff_result.changed_outputs) > 0)
            contents = (project_root / "AGENTS.md").read_text(encoding="utf-8")
            self.assertEqual("stale content", contents)

    def test_sync_writes_agents_md(self) -> None:
        with tempfile.TemporaryDirectory() as tmp_dir:
            project_root = Path(tmp_dir)
            self._write_workspace(project_root)
            report, diff_result = sync_workspace(project_root)
            self.assertEqual([], report.errors)
            assert diff_result is not None
            agents_path = project_root / "AGENTS.md"
            self.assertTrue(agents_path.exists())
            contents = agents_path.read_text(encoding="utf-8")
            self.assertIn("Generated by Supafly from `.supafly/`.", contents)

    def test_validate_fails_when_config_missing(self) -> None:
        with tempfile.TemporaryDirectory() as tmp_dir:
            report = validate_workspace(Path(tmp_dir))
            self.assertTrue(report.errors)

    def test_init_hook_creates_precommit(self) -> None:
        with tempfile.TemporaryDirectory() as tmp_dir:
            project_root = Path(tmp_dir)
            (project_root / ".git").mkdir()
            result = init_workspace(project_root, hook=True)
            self.assertIsNotNone(result.hook_path)
            hook_content = result.hook_path.read_text(encoding="utf-8")
            self.assertIn("supafly sync --check", hook_content)
            self.assertTrue(os.access(result.hook_path, os.X_OK))

    def test_init_hook_skipped_without_git(self) -> None:
        with tempfile.TemporaryDirectory() as tmp_dir:
            project_root = Path(tmp_dir)
            result = init_workspace(project_root, hook=True)
            self.assertIsNone(result.hook_path)

    def test_init_hook_appends_to_existing(self) -> None:
        with tempfile.TemporaryDirectory() as tmp_dir:
            project_root = Path(tmp_dir)
            hooks_dir = project_root / ".git" / "hooks"
            hooks_dir.mkdir(parents=True)
            existing_hook = hooks_dir / "pre-commit"
            existing_hook.write_text("#!/bin/sh\nprettier --check .\n", encoding="utf-8")
            existing_hook.chmod(0o755)
            result = init_workspace(project_root, hook=True)
            self.assertIsNotNone(result.hook_path)
            hook_content = result.hook_path.read_text(encoding="utf-8")
            self.assertIn("prettier --check", hook_content)
            self.assertIn("supafly sync --check", hook_content)

    def _write_workspace(
        self,
        project_root: Path,
        *,
        include_scoped: bool = False,
        include_identity_feedback: bool = False,
    ) -> None:
        workspace_path = project_root / ".supafly"
        local_path = workspace_path / "local"
        local_path.mkdir(parents=True)
        (workspace_path / "config.yaml").write_text(CONFIG, encoding="utf-8")
        (workspace_path / "project.md").write_text(PROJECT, encoding="utf-8")
        (workspace_path / "decision.md").write_text(DECISION, encoding="utf-8")
        (local_path / "scratch.md").write_text(LOCAL_NOTE, encoding="utf-8")
        if include_scoped:
            (workspace_path / "frontend-rules.md").write_text(SCOPED_RULE, encoding="utf-8")
        if include_identity_feedback:
            (workspace_path / "identity.md").write_text(IDENTITY, encoding="utf-8")
            (workspace_path / "feedback.md").write_text(FEEDBACK, encoding="utf-8")


if __name__ == "__main__":
    unittest.main()
