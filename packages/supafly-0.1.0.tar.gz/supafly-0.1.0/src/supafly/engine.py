"""Core workspace loading, validation, diff, and sync logic."""

from __future__ import annotations

from dataclasses import dataclass
from difflib import unified_diff
from pathlib import Path
from typing import Any

from .documents import SourceDocument, load_documents
from .errors import ParseError, SupaflyError
from .renderers.claude import render_claude_md, render_claude_rules
from .renderers.codex import render_agents
from .renderers.cursor import render_cursor_rules
from .yamlish import parse_yamlish

SUPPORTED_TARGETS = {"codex", "claude", "cursor"}
SUPPORTED_KINDS = {"instruction", "reference", "decision", "session", "note", "memory"}
SUPPORTED_PRIORITIES = {"high", "medium", "low"}


@dataclass(slots=True)
class Config:
    targets: list[str]
    include_context: dict[str, object]
    ignore: list[str]
    output_paths: dict[str, str]
    commit_generated: dict[str, bool]


@dataclass(slots=True)
class ValidationReport:
    errors: list[str]
    warnings: list[str]
    config: Config | None = None
    documents: list[SourceDocument] | None = None

    @property
    def is_valid(self) -> bool:
        return not self.errors


@dataclass(slots=True)
class OutputFile:
    target: str
    path: Path
    content: str
    existing_content: str

    @property
    def changed(self) -> bool:
        return self.content != self.existing_content


@dataclass(slots=True)
class DiffResult:
    outputs: list[OutputFile]

    @property
    def changed_outputs(self) -> list[OutputFile]:
        return [output for output in self.outputs if output.changed]


@dataclass(slots=True)
class InitResult:
    workspace_path: Path
    created_paths: list[Path]
    hook_path: Path | None = None


def validate_workspace(project_root: Path, *, targets: list[str] | None = None) -> ValidationReport:
    errors: list[str] = []
    warnings: list[str] = []
    workspace_path = project_root / ".supafly"
    config: Config | None = None
    documents: list[SourceDocument] | None = None

    if not workspace_path.exists():
        errors.append(f"Missing workspace directory: {workspace_path}")
        return ValidationReport(errors=errors, warnings=warnings)

    try:
        config = load_config(workspace_path / "config.yaml")
    except (OSError, ParseError, SupaflyError) as exc:
        errors.append(str(exc))
        return ValidationReport(errors=errors, warnings=warnings)

    requested_targets = _resolve_requested_targets(config, targets, errors)
    if errors:
        return ValidationReport(errors=errors, warnings=warnings, config=config)

    unsupported_config_targets = [target for target in config.targets if target not in SUPPORTED_TARGETS]
    if unsupported_config_targets:
        warnings.append(
            f"Configured but unimplemented targets: {', '.join(sorted(unsupported_config_targets))}"
        )

    try:
        documents = load_documents(workspace_path)
    except (OSError, ParseError) as exc:
        errors.append(str(exc))
        return ValidationReport(errors=errors, warnings=warnings, config=config)

    if not documents:
        warnings.append("No canonical markdown documents found in .supafly/")

    for document in documents:
        if document.path.name == "config.yaml":
            continue
        if document.kind not in SUPPORTED_KINDS:
            errors.append(f"{document.path}: unsupported kind '{document.kind}'")
        if document.priority not in SUPPORTED_PRIORITIES:
            errors.append(f"{document.path}: unsupported priority '{document.priority}'")
        if document.targets:
            unknown_document_targets = [target for target in document.targets if target not in config.targets]
            if unknown_document_targets:
                errors.append(
                    f"{document.path}: targets not declared in config.yaml: {', '.join(sorted(unknown_document_targets))}"
                )
        for target in document.targets or []:
            if target not in requested_targets and targets is not None:
                continue
            if target not in SUPPORTED_TARGETS:
                warnings.append(f"{document.path}: target '{target}' is declared but not implemented")

    return ValidationReport(errors=errors, warnings=warnings, config=config, documents=documents)


def init_workspace(project_root: Path, *, hook: bool = False) -> InitResult:
    workspace_path = project_root / ".supafly"
    if workspace_path.exists():
        raise SupaflyError(f"Workspace already exists: {workspace_path}")

    local_path = workspace_path / "local"
    local_path.mkdir(parents=True, exist_ok=True)

    templates = {
        workspace_path / "config.yaml": _default_config(),
        workspace_path / ".gitignore": _default_gitignore(),
        workspace_path / "identity.md": _default_identity(),
        workspace_path / "project.md": _default_project(),
        workspace_path / "rule-general.md": _default_general_rule(),
        workspace_path / "feedback.md": _default_feedback(),
        workspace_path / "references.md": _default_references(),
    }
    created_paths = [local_path]
    for path, content in templates.items():
        path.write_text(content, encoding="utf-8")
        created_paths.append(path)

    hook_path = _install_hook(project_root) if hook else None

    return InitResult(workspace_path=workspace_path, created_paths=created_paths, hook_path=hook_path)


def diff_workspace(project_root: Path, *, targets: list[str] | None = None) -> tuple[ValidationReport, DiffResult | None]:
    report = validate_workspace(project_root, targets=targets)
    if not report.is_valid or report.config is None or report.documents is None:
        return report, None
    outputs = _render_outputs(project_root, report.config, report.documents, targets)
    return report, DiffResult(outputs=outputs)


def sync_workspace(
    project_root: Path,
    *,
    targets: list[str] | None = None,
    check: bool = False,
) -> tuple[ValidationReport, DiffResult | None]:
    report, diff_result = diff_workspace(project_root, targets=targets)
    if not report.is_valid or diff_result is None:
        return report, None
    if not check:
        for output in diff_result.changed_outputs:
            output.path.parent.mkdir(parents=True, exist_ok=True)
            output.path.write_text(output.content, encoding="utf-8")
    return report, diff_result


def format_validation(report: ValidationReport) -> str:
    lines: list[str] = []
    if report.errors:
        lines.append("Errors:")
        lines.extend(f"- {error}" for error in report.errors)
    if report.warnings:
        lines.append("Warnings:")
        lines.extend(f"- {warning}" for warning in report.warnings)
    if not lines:
        lines.append("Validation passed.")
    return "\n".join(lines)


def format_diff(diff_result: DiffResult) -> str:
    if not diff_result.changed_outputs:
        return "No changes."
    chunks: list[str] = []
    for output in diff_result.changed_outputs:
        existing_lines = output.existing_content.splitlines(keepends=True)
        content_lines = output.content.splitlines(keepends=True)
        diff_lines = unified_diff(
            existing_lines,
            content_lines,
            fromfile=str(output.path),
            tofile=str(output.path),
        )
        chunks.append("".join(diff_lines).rstrip())
    return "\n\n".join(chunk for chunk in chunks if chunk).strip() or "No changes."


def format_sync_result(diff_result: DiffResult, *, check: bool) -> str:
    changed = diff_result.changed_outputs
    if check:
        return "Outputs are stale." if changed else "Outputs are current."
    if not changed:
        return "No files changed."
    lines = ["Updated outputs:"]
    lines.extend(f"- {output.path}" for output in changed)
    return "\n".join(lines)


def format_init_result(init_result: InitResult) -> str:
    lines = [f"Initialized workspace at {init_result.workspace_path}"]
    lines.extend(f"- {path}" for path in init_result.created_paths[1:])
    if init_result.hook_path:
        lines.append(f"Installed pre-commit hook at {init_result.hook_path}")
    return "\n".join(lines)


def load_config(config_path: Path) -> Config:
    if not config_path.exists():
        raise SupaflyError(f"Missing config file: {config_path}")
    raw_text = config_path.read_text(encoding="utf-8")
    data = parse_yamlish(raw_text, source=str(config_path))
    required_keys = {"targets", "include_context", "ignore", "output_paths", "commit_generated"}
    missing_keys = sorted(required_keys - set(data))
    if missing_keys:
        raise SupaflyError(f"{config_path}: missing required keys: {', '.join(missing_keys)}")

    targets = _ensure_text_list(data["targets"], "targets", config_path)
    for target in targets:
        if target not in {"codex", "claude", "cursor", "windsurf", "copilot", "aider"}:
            raise SupaflyError(f"{config_path}: unknown target '{target}'")

    output_paths = _ensure_text_mapping(data["output_paths"], "output_paths", config_path)
    commit_generated = _ensure_bool_mapping(data["commit_generated"], "commit_generated", config_path)
    include_context = _ensure_mapping(data["include_context"], "include_context", config_path)
    ignore = _ensure_text_list(data["ignore"], "ignore", config_path)

    return Config(
        targets=targets,
        include_context=include_context,
        ignore=ignore,
        output_paths=output_paths,
        commit_generated=commit_generated,
    )


def _render_outputs(
    project_root: Path,
    config: Config,
    documents: list[SourceDocument],
    targets: list[str] | None,
) -> list[OutputFile]:
    requested_targets = _resolve_targets_for_render(config, targets)
    outputs: list[OutputFile] = []
    for target in requested_targets:
        filtered = _filter_documents(documents, target, include_context=config.include_context)

        if target == "codex":
            path = project_root / config.output_paths.get(target, "AGENTS.md")
            content = render_agents(filtered)
            existing = path.read_text(encoding="utf-8") if path.exists() else ""
            outputs.append(OutputFile(target=target, path=path, content=content, existing_content=existing))

        elif target == "claude":
            path = project_root / config.output_paths.get(target, "CLAUDE.md")
            content = render_claude_md(filtered)
            existing = path.read_text(encoding="utf-8") if path.exists() else ""
            outputs.append(OutputFile(target=target, path=path, content=content, existing_content=existing))
            rules = render_claude_rules(filtered)
            rules_dir = project_root / ".claude" / "rules"
            for filename, rule_content in rules.items():
                rule_path = rules_dir / filename
                rule_existing = rule_path.read_text(encoding="utf-8") if rule_path.exists() else ""
                outputs.append(OutputFile(target=target, path=rule_path, content=rule_content, existing_content=rule_existing))

        elif target == "cursor":
            rules_dir = project_root / config.output_paths.get(target, ".cursor/rules/")
            rules = render_cursor_rules(filtered)
            for filename, rule_content in rules.items():
                rule_path = rules_dir / filename
                rule_existing = rule_path.read_text(encoding="utf-8") if rule_path.exists() else ""
                outputs.append(OutputFile(target=target, path=rule_path, content=rule_content, existing_content=rule_existing))

    return outputs


def _filter_documents(
    documents: list[SourceDocument],
    target: str,
    *,
    include_context: dict[str, object],
) -> list[SourceDocument]:
    filtered: list[SourceDocument] = []
    allowed_context = {
        "reference": bool(include_context.get("references", True)),
        "decision": bool(include_context.get("decisions", True)),
        "session": bool(include_context.get("sessions", False)),
    }
    for document in documents:
        if document.local_only:
            continue
        if document.path.name == "config.yaml":
            continue
        if document.kind == "memory":
            continue
        if document.targets and target not in document.targets:
            continue
        if document.kind in allowed_context and not allowed_context[document.kind]:
            continue
        filtered.append(document)
    return filtered


def _resolve_requested_targets(config: Config, targets: list[str] | None, errors: list[str]) -> list[str]:
    if not targets:
        return list(config.targets)
    requested_targets = list(dict.fromkeys(targets))
    unknown_requested = [target for target in requested_targets if target not in config.targets]
    if unknown_requested:
        errors.append(f"Requested targets are not configured: {', '.join(sorted(unknown_requested))}")
    return requested_targets


def _resolve_targets_for_render(config: Config, targets: list[str] | None) -> list[str]:
    return list(dict.fromkeys(targets or config.targets))


def _ensure_mapping(value: Any, field_name: str, config_path: Path) -> dict[str, object]:
    if not isinstance(value, dict):
        raise SupaflyError(f"{config_path}: '{field_name}' must be a mapping")
    return {str(key): item for key, item in value.items()}


def _ensure_text_mapping(value: Any, field_name: str, config_path: Path) -> dict[str, str]:
    mapping = _ensure_mapping(value, field_name, config_path)
    return {key: str(item) for key, item in mapping.items()}


def _ensure_bool_mapping(value: Any, field_name: str, config_path: Path) -> dict[str, bool]:
    mapping = _ensure_mapping(value, field_name, config_path)
    normalized: dict[str, bool] = {}
    for key, item in mapping.items():
        if not isinstance(item, bool):
            raise SupaflyError(f"{config_path}: '{field_name}.{key}' must be true or false")
        normalized[key] = item
    return normalized


def _ensure_text_list(value: Any, field_name: str, config_path: Path) -> list[str]:
    if not isinstance(value, list):
        raise SupaflyError(f"{config_path}: '{field_name}' must be a list")
    return [str(item) for item in value]


def _default_config() -> str:
    return """version: 1
targets:
  - claude
  - codex
  - cursor
include_context:
  references: true
  current_focus: true
  decisions: true
  sessions: false
ignore:
  - ".env"
output_paths:
  claude: "CLAUDE.md"
  codex: "AGENTS.md"
  cursor: ".cursor/rules/"
commit_generated:
  claude: true
  codex: true
  cursor: true
"""


def _default_gitignore() -> str:
    return """# Supafly local files — user-specific, not committed
local/
"""


def _default_identity() -> str:
    return """---
kind: instruction
title: Identity
description: Team and product identity for this repository
priority: high
targets:
  - claude
  - codex
  - cursor
---
This repository uses Supafly as the canonical source of agent context.

Prefer reading `.supafly/` and generated outputs before making assumptions.
"""


def _default_project() -> str:
    return """---
kind: instruction
title: Project Context
description: Product goals, stack, and current focus
priority: high
targets:
  - claude
  - codex
  - cursor
---
Document the current project purpose, architecture, and active priorities here.
"""


def _default_general_rule() -> str:
    return """---
kind: instruction
title: General Rules
description: Shared repo rules for AI agents
priority: high
targets:
  - claude
  - codex
  - cursor
---
Add repository-specific engineering rules, workflows, and constraints here.
"""


def _default_feedback() -> str:
    return """---
kind: instruction
title: Feedback
description: Working preferences and behavioral guidance for agents
priority: high
targets:
  - claude
  - codex
  - cursor
---
Record agent behavior corrections, confirmed approaches, and working preferences here.
"""


def _default_references() -> str:
    return """---
kind: reference
title: References
description: Commands, paths, and external references
priority: medium
targets:
  - claude
  - codex
  - cursor
---
Add useful commands, directories, and links that agents should keep in view.
"""


def _install_hook(project_root: Path) -> Path | None:
    git_dir = project_root / ".git"
    if not git_dir.exists():
        return None
    hooks_dir = git_dir / "hooks"
    hooks_dir.mkdir(exist_ok=True)
    hook_path = hooks_dir / "pre-commit"
    hook_content = "#!/bin/sh\nsupafly sync --check\n"
    if hook_path.exists():
        existing = hook_path.read_text(encoding="utf-8")
        if "supafly" in existing:
            return None
        hook_path.write_text(existing.rstrip() + "\n\n# Supafly sync check\nsupafly sync --check\n", encoding="utf-8")
    else:
        hook_path.write_text(hook_content, encoding="utf-8")
    hook_path.chmod(0o755)
    return hook_path
