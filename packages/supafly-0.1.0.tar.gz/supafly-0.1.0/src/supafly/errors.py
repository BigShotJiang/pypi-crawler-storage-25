"""Shared exceptions for Supafly."""


class SupaflyError(Exception):
    """Base exception for Supafly runtime failures."""


class ParseError(SupaflyError):
    """Raised when config or frontmatter cannot be parsed."""

