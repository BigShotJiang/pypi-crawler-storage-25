"""Workspace document loading for Supafly."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any

from .errors import ParseError
from .yamlish import parse_yamlish


@dataclass(slots=True)
class SourceDocument:
    path: Path
    kind: str
    title: str
    description: str | None
    scopes: list[str]
    priority: str
    targets: list[str] | None
    body: str
    local_only: bool
    has_frontmatter: bool


def load_documents(workspace_path: Path) -> list[SourceDocument]:
    documents: list[SourceDocument] = []
    for path in sorted(workspace_path.rglob("*.md")):
        relative = path.relative_to(workspace_path)
        local_only = "local" in relative.parts
        raw_text = path.read_text(encoding="utf-8")
        frontmatter, body, has_frontmatter = split_frontmatter(raw_text, source=str(relative))
        data = _normalize_frontmatter(frontmatter, relative)
        documents.append(
            SourceDocument(
                path=relative,
                kind=str(data.get("kind", "instruction")),
                title=str(data.get("title", relative.stem.replace("-", " ").title())),
                description=_optional_text(data.get("description")),
                scopes=_list_of_text(data.get("scopes")),
                priority=str(data.get("priority", "medium")),
                targets=_optional_targets(data.get("targets")),
                body=body.strip(),
                local_only=local_only,
                has_frontmatter=has_frontmatter,
            )
        )
    return documents


def split_frontmatter(text: str, *, source: str) -> tuple[dict[str, Any], str, bool]:
    if not text.startswith("---\n"):
        return {}, text, False
    end_marker = "\n---\n"
    end_index = text.find(end_marker, 4)
    if end_index == -1:
        raise ParseError(f"{source}: missing closing frontmatter delimiter")
    raw_frontmatter = text[4:end_index]
    body = text[end_index + len(end_marker) :]
    frontmatter = parse_yamlish(raw_frontmatter, source=f"{source} frontmatter")
    return frontmatter, body, True


def _normalize_frontmatter(frontmatter: dict[str, Any], source: Path) -> dict[str, Any]:
    allowed_keys = {"kind", "title", "description", "scopes", "priority", "targets"}
    unknown_keys = sorted(set(frontmatter) - allowed_keys)
    if unknown_keys:
        raise ParseError(f"{source}: unknown frontmatter keys: {', '.join(unknown_keys)}")
    return frontmatter


def _list_of_text(value: Any) -> list[str]:
    if value is None:
        return []
    if not isinstance(value, list):
        raise ParseError("Expected a list value")
    return [str(item) for item in value]


def _optional_targets(value: Any) -> list[str] | None:
    if value is None:
        return None
    if not isinstance(value, list):
        raise ParseError("Expected targets to be a list")
    return [str(item) for item in value]


def _optional_text(value: Any) -> str | None:
    if value is None:
        return None
    return str(value)

