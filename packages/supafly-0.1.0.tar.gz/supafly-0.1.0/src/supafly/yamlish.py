"""Restricted YAML-like parser for Supafly v1."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from .errors import ParseError


@dataclass(slots=True)
class _Line:
    indent: int
    content: str
    number: int


def parse_yamlish(text: str, *, source: str = "<input>") -> dict[str, Any]:
    """Parse a restricted YAML subset used by config and frontmatter."""
    lines = _prepare_lines(text)
    if not lines:
        return {}
    value, index = _parse_block(lines, 0, lines[0].indent, source)
    if index != len(lines):
        raise ParseError(f"{source}: unexpected trailing content on line {lines[index].number}")
    if not isinstance(value, dict):
        raise ParseError(f"{source}: top-level value must be a mapping")
    return value


def _prepare_lines(text: str) -> list[_Line]:
    prepared: list[_Line] = []
    for number, raw_line in enumerate(text.splitlines(), start=1):
        stripped = raw_line.strip()
        if not stripped or stripped.startswith("#"):
            continue
        indent = len(raw_line) - len(raw_line.lstrip(" "))
        if indent and indent % 2 != 0:
            raise ParseError(f"Invalid indentation on line {number}; use multiples of 2 spaces")
        prepared.append(_Line(indent=indent, content=raw_line[indent:], number=number))
    return prepared


def _parse_block(lines: list[_Line], index: int, indent: int, source: str) -> tuple[Any, int]:
    if index >= len(lines):
        return {}, index
    line = lines[index]
    if line.indent != indent:
        raise ParseError(f"{source}: unexpected indentation on line {line.number}")
    if line.content.startswith("- "):
        return _parse_list(lines, index, indent, source)
    return _parse_mapping(lines, index, indent, source)


def _parse_mapping(lines: list[_Line], index: int, indent: int, source: str) -> tuple[dict[str, Any], int]:
    result: dict[str, Any] = {}
    while index < len(lines):
        line = lines[index]
        if line.indent < indent:
            break
        if line.indent > indent:
            raise ParseError(f"{source}: unexpected indentation on line {line.number}")
        if line.content.startswith("- "):
            raise ParseError(f"{source}: list item not allowed here on line {line.number}")
        if ":" not in line.content:
            raise ParseError(f"{source}: expected key/value pair on line {line.number}")
        key, raw_value = line.content.split(":", 1)
        key = key.strip()
        raw_value = raw_value.strip()
        if not key:
            raise ParseError(f"{source}: empty key on line {line.number}")
        index += 1
        if raw_value:
            result[key] = _parse_scalar(raw_value)
            continue
        if index < len(lines) and lines[index].indent > indent:
            nested, index = _parse_block(lines, index, indent + 2, source)
            result[key] = nested
        else:
            result[key] = {}
    return result, index


def _parse_list(lines: list[_Line], index: int, indent: int, source: str) -> tuple[list[Any], int]:
    result: list[Any] = []
    while index < len(lines):
        line = lines[index]
        if line.indent < indent:
            break
        if line.indent > indent:
            raise ParseError(f"{source}: unexpected indentation on line {line.number}")
        if not line.content.startswith("- "):
            break
        raw_value = line.content[2:].strip()
        index += 1
        if raw_value:
            result.append(_parse_scalar(raw_value))
            continue
        if index < len(lines) and lines[index].indent > indent:
            nested, index = _parse_block(lines, index, indent + 2, source)
            result.append(nested)
        else:
            result.append("")
    return result, index


def _parse_scalar(raw_value: str) -> Any:
    if raw_value in {"true", "false"}:
        return raw_value == "true"
    if raw_value.isdigit():
        return int(raw_value)
    if (raw_value.startswith('"') and raw_value.endswith('"')) or (
        raw_value.startswith("'") and raw_value.endswith("'")
    ):
        return raw_value[1:-1]
    return raw_value

