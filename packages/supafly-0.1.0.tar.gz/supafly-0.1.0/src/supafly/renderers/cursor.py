"""Cursor renderer for Supafly."""

from __future__ import annotations

from ..documents import SourceDocument

AUTO_GENERATED_HEADER = "<!-- Supafly: auto-generated -->"
PRIORITY_ORDER = {"high": 0, "medium": 1, "low": 2}

# Documents with these stems get merged into preferences.mdc
_PREFERENCE_STEMS = {"identity", "feedback"}


def render_cursor_rules(documents: list[SourceDocument]) -> dict[str, str]:
    """Render .cursor/rules/*.mdc files.

    Returns a mapping of filename to content.
    Identity and feedback documents are merged into preferences.mdc.
    """
    rules: dict[str, str] = {}
    preference_docs: list[SourceDocument] = []
    regular_docs: list[SourceDocument] = []

    for doc in sorted(documents, key=_sort_key):
        if doc.path.stem in _PREFERENCE_STEMS:
            preference_docs.append(doc)
        else:
            regular_docs.append(doc)

    if preference_docs:
        rules["preferences.mdc"] = _render_preferences(preference_docs)

    for doc in regular_docs:
        filename = doc.path.stem + ".mdc"
        rules[filename] = _render_rule(doc)

    return rules


def _render_preferences(documents: list[SourceDocument]) -> str:
    """Merge identity and feedback docs into a single preferences.mdc."""
    all_globs: list[str] = []
    for doc in documents:
        all_globs.extend(doc.scopes)

    lines = [AUTO_GENERATED_HEADER]
    lines.append("---")
    lines.append("description: User preferences and identity")
    if all_globs:
        lines.append(f"globs: {_format_globs(all_globs)}")
    lines.append("---")
    lines.append("")

    for doc in documents:
        lines.append(f"## {doc.title}")
        lines.append("")
        if doc.description:
            lines.append(doc.description)
            lines.append("")
        if doc.body:
            lines.append(doc.body)
            lines.append("")

    return "\n".join(lines).rstrip() + "\n"


def _render_rule(document: SourceDocument) -> str:
    """Render a single .mdc rule file."""
    lines = [AUTO_GENERATED_HEADER]
    lines.append("---")
    lines.append(f"description: {document.description or document.title}")
    if document.scopes:
        lines.append(f"globs: {_format_globs(document.scopes)}")
    lines.append("---")
    lines.append("")
    lines.append(f"## {document.title}")
    lines.append("")
    if document.body:
        lines.append(document.body)
        lines.append("")
    else:
        lines.append("_No body content._")
        lines.append("")
    return "\n".join(lines).rstrip() + "\n"


def _format_globs(globs: list[str]) -> str:
    """Format globs for Cursor .mdc frontmatter."""
    if not globs:
        return "[]"
    items = ", ".join(f'"{g}"' for g in globs)
    return f"[{items}]"


def _sort_key(document: SourceDocument) -> tuple[int, str, str]:
    priority_rank = PRIORITY_ORDER.get(document.priority, PRIORITY_ORDER["medium"])
    return (priority_rank, document.title.lower(), str(document.path))
