"""Command-line interface for Supafly."""

from __future__ import annotations

import argparse
from pathlib import Path
from typing import NoReturn

from .engine import (
    diff_workspace,
    format_diff,
    format_init_result,
    format_sync_result,
    format_validation,
    init_workspace,
    sync_workspace,
    validate_workspace,
)
from .errors import SupaflyError


def main(argv: list[str] | None = None) -> int:
    parser = _build_parser()
    args = parser.parse_args(argv)
    project_root = Path(args.root).resolve()

    if args.command in (None, "ui"):
        return _handle_ui(project_root)
    if args.command == "init":
        return _handle_init(project_root, hook=args.hook)
    if args.command == "validate":
        return _handle_validate(project_root, strict=args.strict, targets=args.targets)
    if args.command == "diff":
        return _handle_diff(project_root, targets=args.targets)
    if args.command == "sync":
        return _handle_sync(project_root, targets=args.targets, check=args.check)
    if args.command == "remember":
        return _handle_remember()

    _fail(f"Unknown command: {args.command}")


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="supafly",
        description="Portable context for AI agents.",
    )
    _add_root_argument(parser)

    subparsers = parser.add_subparsers(dest="command")
    subparsers.required = False
    ui_parser = subparsers.add_parser(
        "ui",
        help="Launch the Supafly Textual app.",
    )
    _add_root_argument(ui_parser)
    init_parser = subparsers.add_parser(
        "init",
        help="Create a starter .supafly workspace.",
    )
    _add_root_argument(init_parser)
    init_parser.add_argument(
        "--hook",
        action="store_true",
        help="Install a git pre-commit hook that runs supafly sync --check.",
    )
    validate_parser = subparsers.add_parser(
        "validate",
        help="Validate .supafly config and markdown documents.",
    )
    _add_root_argument(validate_parser)
    validate_parser.add_argument(
        "--strict",
        action="store_true",
        help="Treat warnings as failures.",
    )
    validate_parser.add_argument(
        "--target",
        action="append",
        dest="targets",
        help="Limit validation to specific configured targets.",
    )
    diff_parser = subparsers.add_parser(
        "diff",
        help="Show output diffs without writing files.",
    )
    _add_root_argument(diff_parser)
    diff_parser.add_argument(
        "--target",
        action="append",
        dest="targets",
        help="Limit diff to specific configured targets.",
    )
    subparsers.add_parser("remember")
    sync_parser = subparsers.add_parser(
        "sync",
        help="Render target files from .supafly/.",
    )
    _add_root_argument(sync_parser)
    sync_parser.add_argument(
        "--check",
        action="store_true",
        help="Exit non-zero if rendered outputs differ from committed files.",
    )
    sync_parser.add_argument(
        "--target",
        action="append",
        dest="targets",
        help="Limit sync to specific configured targets.",
    )

    return parser


def _add_root_argument(parser: argparse.ArgumentParser) -> None:
    parser.add_argument(
        "--root",
        default=".",
        help="Project root that contains the .supafly workspace (default: current directory).",
    )


def _handle_ui(project_root: Path) -> int:
    try:
        from .app import SupaflyApp
    except ModuleNotFoundError as exc:
        if exc.name == "textual":
            print("Textual is not installed. Install dependencies first, then rerun Supafly.")
            return 1
        raise

    app = SupaflyApp(project_root=project_root)
    app.run()
    return 0


def _handle_init(project_root: Path, *, hook: bool = False) -> int:
    try:
        result = init_workspace(project_root, hook=hook)
    except SupaflyError as exc:
        print(str(exc))
        return 1
    print(format_init_result(result))
    return 0


def _handle_validate(project_root: Path, *, strict: bool, targets: list[str] | None) -> int:
    report = validate_workspace(project_root, targets=targets)
    print(format_validation(report))
    if report.errors:
        return 1
    if strict and report.warnings:
        return 1
    return 0


def _handle_diff(project_root: Path, *, targets: list[str] | None) -> int:
    report, diff_result = diff_workspace(project_root, targets=targets)
    validation_output = format_validation(report)
    if validation_output != "Validation passed.":
        print(validation_output)
    if report.errors or diff_result is None:
        return 1
    print(format_diff(diff_result))
    return 0


def _handle_sync(project_root: Path, *, targets: list[str] | None, check: bool) -> int:
    report, diff_result = sync_workspace(project_root, targets=targets, check=check)
    validation_output = format_validation(report)
    if validation_output != "Validation passed.":
        print(validation_output)
    if report.errors or diff_result is None:
        return 1
    print(format_sync_result(diff_result, check=check))
    if check and diff_result.changed_outputs:
        return 1
    return 0


def _handle_remember() -> int:
    print(
        "\n"
        "Supafly — BYOM\n"
        "\n"
        "Context is portable. Memory is next.\n"
        "\n"
        "When agents remember decisions, sessions, and preferences\n"
        "across tools and time — that's v2.\n"
        "\n"
        "You're early. Stay tuned.\n"
    )
    return 0


def _fail(message: str) -> NoReturn:
    raise SystemExit(message)
