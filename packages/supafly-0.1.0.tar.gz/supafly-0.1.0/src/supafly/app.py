"""Textual app shell for Supafly."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from textual.app import App, ComposeResult
from textual.containers import Horizontal, Vertical
from textual.reactive import reactive
from textual.widgets import Button, Footer, Header, Label, ListItem, ListView, Markdown, Static, TabbedContent, TabPane

from .engine import (
    diff_workspace,
    format_diff,
    format_init_result,
    format_sync_result,
    format_validation,
    init_workspace,
    sync_workspace,
    validate_workspace,
)
from .errors import SupaflyError


@dataclass(slots=True)
class ProjectSnapshot:
    project_root: Path
    workspace_path: Path
    workspace_exists: bool
    documents: list[Path]
    local_documents: list[Path]
    generated_outputs: list[str]


def build_snapshot(project_root: Path) -> ProjectSnapshot:
    workspace_path = project_root / ".supafly"
    workspace_exists = workspace_path.exists()
    documents: list[Path] = []
    local_documents: list[Path] = []
    if workspace_exists:
        for path in sorted(workspace_path.rglob("*.md")):
            relative = path.relative_to(workspace_path)
            if "local" in relative.parts:
                local_documents.append(relative)
            else:
                documents.append(relative)

    generated_outputs = [
        path.name
        for path in sorted(project_root.iterdir())
        if path.is_file() and path.name in {"AGENTS.md", "CLAUDE.md"}
    ]

    return ProjectSnapshot(
        project_root=project_root,
        workspace_path=workspace_path,
        workspace_exists=workspace_exists,
        documents=documents,
        local_documents=local_documents,
        generated_outputs=generated_outputs,
    )


class SupaflyApp(App[None]):
    """Phase 1 Textual shell for Supafly."""

    CSS = """
    Screen {
        layout: vertical;
    }

    #body {
        layout: horizontal;
        height: 1fr;
    }

    #sidebar {
        width: 28;
        min-width: 24;
        padding: 1;
        border: round $panel;
    }

    #main {
        width: 1fr;
        padding: 1;
    }

    #actions {
        height: auto;
        padding-bottom: 1;
    }

    .panel {
        border: round $panel;
        padding: 1;
        margin-bottom: 1;
    }

    .title {
        text-style: bold;
        color: $accent;
    }

    ListView {
        height: 1fr;
    }
    """

    BINDINGS = [
        ("i", "init", "Init"),
        ("q", "quit", "Quit"),
        ("r", "refresh", "Refresh"),
        ("v", "validate", "Validate"),
        ("s", "sync", "Sync"),
        ("d", "diff", "Diff"),
    ]

    snapshot: reactive[ProjectSnapshot | None] = reactive(None)

    def __init__(self, project_root: Path) -> None:
        super().__init__()
        self.project_root = project_root
        self.activity_lines: list[str] = []

    def compose(self) -> ComposeResult:
        yield Header(show_clock=True)
        with Horizontal(id="body"):
            with Vertical(id="sidebar"):
                yield Static("Supafly", classes="title")
                yield Static("", id="project-summary", classes="panel")
                yield Static("Documents", classes="title")
                yield ListView(id="doc-list")
                yield Static("Generated Outputs", classes="title")
                yield ListView(id="output-list")
            with Vertical(id="main"):
                with Horizontal(id="actions"):
                    yield Button("Init", id="init")
                    yield Button("Refresh", id="refresh")
                    yield Button("Validate", id="validate")
                    yield Button("Sync", id="sync")
                    yield Button("Diff", id="diff")
                with TabbedContent():
                    with TabPane("Overview", id="overview-tab"):
                        yield Markdown("", id="overview-markdown")
                    with TabPane("Workspace", id="workspace-tab"):
                        yield Markdown("", id="workspace-markdown")
                    with TabPane("Activity", id="activity-tab"):
                        yield Static("", id="activity-log", classes="panel")
        yield Footer()

    def on_mount(self) -> None:
        self.refresh_snapshot()

    def refresh_snapshot(self) -> None:
        self.snapshot = build_snapshot(self.project_root)
        self._render_snapshot()
        self._append_log("Refreshed project snapshot.")

    def _render_snapshot(self) -> None:
        assert self.snapshot is not None
        project_summary = self.query_one("#project-summary", Static)
        project_summary.update(
            "\n".join(
                [
                    f"Root: {self.snapshot.project_root}",
                    f"Workspace: {self.snapshot.workspace_path}",
                    f"Present: {'yes' if self.snapshot.workspace_exists else 'no'}",
                    f"Docs: {len(self.snapshot.documents)}",
                    f"Local docs: {len(self.snapshot.local_documents)}",
                ]
            )
        )

        doc_list = self.query_one("#doc-list", ListView)
        doc_list.clear()
        if self.snapshot.documents:
            for document in self.snapshot.documents:
                doc_list.append(ListItem(Label(str(document))))
        else:
            doc_list.append(ListItem(Label("No canonical docs found")))

        output_list = self.query_one("#output-list", ListView)
        output_list.clear()
        if self.snapshot.generated_outputs:
            for output in self.snapshot.generated_outputs:
                output_list.append(ListItem(Label(output)))
        else:
            output_list.append(ListItem(Label("No generated outputs yet")))

        overview = self.query_one("#overview-markdown", Markdown)
        overview.update(
            "\n".join(
                [
                    "# Supafly Overview",
                    "",
                    f"- Project root: `{self.snapshot.project_root}`",
                    f"- Canonical workspace: `{self.snapshot.workspace_path}`",
                    f"- Workspace exists: `{self.snapshot.workspace_exists}`",
                    f"- Canonical docs: `{len(self.snapshot.documents)}`",
                    f"- Local docs: `{len(self.snapshot.local_documents)}`",
                    f"- Generated outputs: `{len(self.snapshot.generated_outputs)}`",
                    "",
                    "Primary actions:",
                    "",
                    "- `Init` bootstraps `.supafly/` when the workspace is missing",
                    "- `Validate` checks schema and target declarations",
                    "- `Diff` previews rendered output changes",
                    "- `Sync` writes generated target files",
                    "",
                    "Phase 1 focus:",
                    "",
                    "- inspect `.supafly/`",
                    "- validate workspace structure",
                    "- preview sync/diff actions",
                    "- provide a terminal-native project cockpit",
                ]
            )
        )

        workspace = self.query_one("#workspace-markdown", Markdown)
        workspace.update(
            "\n".join(
                [
                    "# Workspace Status",
                    "",
                    *(
                        [
                            "No `.supafly/` workspace found yet.",
                            "",
                            "Use the `Init` action to create starter files before validating or syncing.",
                            "",
                        ]
                        if not self.snapshot.workspace_exists
                        else []
                    ),
                    "## Canonical Docs",
                    *([f"- `{path}`" for path in self.snapshot.documents] or ["- None"]),
                    "",
                    "## Local Docs",
                    *([f"- `{path}`" for path in self.snapshot.local_documents] or ["- None"]),
                    "",
                    "## Next Engine Steps",
                    "- wire config parsing",
                    "- wire frontmatter parsing",
                    "- wire validation",
                    "- wire renderers behind the UI actions",
                ]
            )
        )

    def _append_log(self, message: str) -> None:
        log = self.query_one("#activity-log", Static)
        self.activity_lines.append(message)
        log.update("\n".join(self.activity_lines[-12:]))

    def action_refresh(self) -> None:
        self.refresh_snapshot()

    def action_init(self) -> None:
        try:
            init_result = init_workspace(self.project_root)
        except SupaflyError as exc:
            self._append_log(str(exc))
            self.notify(str(exc), severity="error")
            return
        self._append_multiline(format_init_result(init_result))
        self.refresh_snapshot()
        self.notify("Workspace initialized.")

    def action_validate(self) -> None:
        report = validate_workspace(self.project_root)
        summary = format_validation(report)
        self._append_multiline(summary)
        if report.errors:
            self.notify("Validation failed.", severity="error")
        elif report.warnings:
            self.notify("Validation passed with warnings.")
        else:
            self.notify("Validation passed.")

    def action_sync(self) -> None:
        report, diff_result = sync_workspace(self.project_root)
        self._append_multiline(format_validation(report))
        if report.errors or diff_result is None:
            self.notify("Sync failed.", severity="error")
            return
        message = format_sync_result(diff_result, check=False)
        self._append_multiline(message)
        self.refresh_snapshot()
        self.notify(message)

    def action_diff(self) -> None:
        report, diff_result = diff_workspace(self.project_root)
        self._append_multiline(format_validation(report))
        if report.errors or diff_result is None:
            self.notify("Diff failed.", severity="error")
            return
        message = format_diff(diff_result)
        self._append_multiline(message)
        self.notify("Diff complete.")

    def on_button_pressed(self, event: Button.Pressed) -> None:
        button_id = event.button.id
        if button_id == "init":
            self.action_init()
        elif button_id == "refresh":
            self.action_refresh()
        elif button_id == "validate":
            self.action_validate()
        elif button_id == "sync":
            self.action_sync()
        elif button_id == "diff":
            self.action_diff()

    def _append_multiline(self, text: str) -> None:
        for line in text.splitlines():
            self._append_log(line)
