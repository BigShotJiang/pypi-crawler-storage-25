import datetime
from collections.abc import Iterable as _Iterable
from collections.abc import Mapping as _Mapping
from typing import ClassVar as _ClassVar
from typing import Optional as _Optional
from typing import Union as _Union

from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from google.protobuf import timestamp_pb2 as _timestamp_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper

from tensorlake.function_executor.proto import status_pb2 as _status_pb2

DESCRIPTOR: _descriptor.FileDescriptor

class SerializedObjectEncoding(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    SERIALIZED_OBJECT_ENCODING_UNKNOWN: _ClassVar[SerializedObjectEncoding]
    SERIALIZED_OBJECT_ENCODING_UTF8_JSON: _ClassVar[SerializedObjectEncoding]
    SERIALIZED_OBJECT_ENCODING_UTF8_TEXT: _ClassVar[SerializedObjectEncoding]
    SERIALIZED_OBJECT_ENCODING_BINARY_PICKLE: _ClassVar[SerializedObjectEncoding]
    SERIALIZED_OBJECT_ENCODING_BINARY_ZIP: _ClassVar[SerializedObjectEncoding]
    SERIALIZED_OBJECT_ENCODING_RAW: _ClassVar[SerializedObjectEncoding]

class InitializationOutcomeCode(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    INITIALIZATION_OUTCOME_CODE_UNKNOWN: _ClassVar[InitializationOutcomeCode]
    INITIALIZATION_OUTCOME_CODE_SUCCESS: _ClassVar[InitializationOutcomeCode]
    INITIALIZATION_OUTCOME_CODE_FAILURE: _ClassVar[InitializationOutcomeCode]

class InitializationFailureReason(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    INITIALIZATION_FAILURE_REASON_UNKNOWN: _ClassVar[InitializationFailureReason]
    INITIALIZATION_FAILURE_REASON_INTERNAL_ERROR: _ClassVar[InitializationFailureReason]
    INITIALIZATION_FAILURE_REASON_FUNCTION_ERROR: _ClassVar[InitializationFailureReason]

class AllocationOutcomeCode(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    ALLOCATION_OUTCOME_CODE_UNKNOWN: _ClassVar[AllocationOutcomeCode]
    ALLOCATION_OUTCOME_CODE_SUCCESS: _ClassVar[AllocationOutcomeCode]
    ALLOCATION_OUTCOME_CODE_FAILURE: _ClassVar[AllocationOutcomeCode]

class AllocationFailureReason(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    ALLOCATION_FAILURE_REASON_UNKNOWN: _ClassVar[AllocationFailureReason]
    ALLOCATION_FAILURE_REASON_INTERNAL_ERROR: _ClassVar[AllocationFailureReason]
    ALLOCATION_FAILURE_REASON_FUNCTION_ERROR: _ClassVar[AllocationFailureReason]
    ALLOCATION_FAILURE_REASON_REQUEST_ERROR: _ClassVar[AllocationFailureReason]
    ALLOCATION_FAILURE_REASON_REPLAY_EVENT_HISTORY_MISMATCH: _ClassVar[
        AllocationFailureReason
    ]

class ReplayMode(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    REPLAY_MODE_NONE: _ClassVar[ReplayMode]
    REPLAY_MODE_STRICT: _ClassVar[ReplayMode]
    REPLAY_MODE_ADAPTIVE: _ClassVar[ReplayMode]

class FunctionCallWatcherStatus(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    FUNCTION_CALL_WATCHER_STATUS_UNKNOWN: _ClassVar[FunctionCallWatcherStatus]
    FUNCTION_CALL_WATCHER_STATUS_COMPLETED: _ClassVar[FunctionCallWatcherStatus]
    FUNCTION_CALL_WATCHER_STATUS_TIMEDOUT: _ClassVar[FunctionCallWatcherStatus]

SERIALIZED_OBJECT_ENCODING_UNKNOWN: SerializedObjectEncoding
SERIALIZED_OBJECT_ENCODING_UTF8_JSON: SerializedObjectEncoding
SERIALIZED_OBJECT_ENCODING_UTF8_TEXT: SerializedObjectEncoding
SERIALIZED_OBJECT_ENCODING_BINARY_PICKLE: SerializedObjectEncoding
SERIALIZED_OBJECT_ENCODING_BINARY_ZIP: SerializedObjectEncoding
SERIALIZED_OBJECT_ENCODING_RAW: SerializedObjectEncoding
INITIALIZATION_OUTCOME_CODE_UNKNOWN: InitializationOutcomeCode
INITIALIZATION_OUTCOME_CODE_SUCCESS: InitializationOutcomeCode
INITIALIZATION_OUTCOME_CODE_FAILURE: InitializationOutcomeCode
INITIALIZATION_FAILURE_REASON_UNKNOWN: InitializationFailureReason
INITIALIZATION_FAILURE_REASON_INTERNAL_ERROR: InitializationFailureReason
INITIALIZATION_FAILURE_REASON_FUNCTION_ERROR: InitializationFailureReason
ALLOCATION_OUTCOME_CODE_UNKNOWN: AllocationOutcomeCode
ALLOCATION_OUTCOME_CODE_SUCCESS: AllocationOutcomeCode
ALLOCATION_OUTCOME_CODE_FAILURE: AllocationOutcomeCode
ALLOCATION_FAILURE_REASON_UNKNOWN: AllocationFailureReason
ALLOCATION_FAILURE_REASON_INTERNAL_ERROR: AllocationFailureReason
ALLOCATION_FAILURE_REASON_FUNCTION_ERROR: AllocationFailureReason
ALLOCATION_FAILURE_REASON_REQUEST_ERROR: AllocationFailureReason
ALLOCATION_FAILURE_REASON_REPLAY_EVENT_HISTORY_MISMATCH: AllocationFailureReason
REPLAY_MODE_NONE: ReplayMode
REPLAY_MODE_STRICT: ReplayMode
REPLAY_MODE_ADAPTIVE: ReplayMode
FUNCTION_CALL_WATCHER_STATUS_UNKNOWN: FunctionCallWatcherStatus
FUNCTION_CALL_WATCHER_STATUS_COMPLETED: FunctionCallWatcherStatus
FUNCTION_CALL_WATCHER_STATUS_TIMEDOUT: FunctionCallWatcherStatus

class Empty(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class SerializedObjectManifest(_message.Message):
    __slots__ = (
        "encoding",
        "encoding_version",
        "size",
        "metadata_size",
        "sha256_hash",
        "content_type",
        "source_function_call_id",
    )
    ENCODING_FIELD_NUMBER: _ClassVar[int]
    ENCODING_VERSION_FIELD_NUMBER: _ClassVar[int]
    SIZE_FIELD_NUMBER: _ClassVar[int]
    METADATA_SIZE_FIELD_NUMBER: _ClassVar[int]
    SHA256_HASH_FIELD_NUMBER: _ClassVar[int]
    CONTENT_TYPE_FIELD_NUMBER: _ClassVar[int]
    SOURCE_FUNCTION_CALL_ID_FIELD_NUMBER: _ClassVar[int]
    encoding: SerializedObjectEncoding
    encoding_version: int
    size: int
    metadata_size: int
    sha256_hash: str
    content_type: str
    source_function_call_id: str
    def __init__(
        self,
        encoding: _Optional[_Union[SerializedObjectEncoding, str]] = ...,
        encoding_version: _Optional[int] = ...,
        size: _Optional[int] = ...,
        metadata_size: _Optional[int] = ...,
        sha256_hash: _Optional[str] = ...,
        content_type: _Optional[str] = ...,
        source_function_call_id: _Optional[str] = ...,
    ) -> None: ...

class SerializedObject(_message.Message):
    __slots__ = ("manifest", "data")
    MANIFEST_FIELD_NUMBER: _ClassVar[int]
    DATA_FIELD_NUMBER: _ClassVar[int]
    manifest: SerializedObjectManifest
    data: bytes
    def __init__(
        self,
        manifest: _Optional[_Union[SerializedObjectManifest, _Mapping]] = ...,
        data: _Optional[bytes] = ...,
    ) -> None: ...

class BLOBChunk(_message.Message):
    __slots__ = ("uri", "size", "etag")
    URI_FIELD_NUMBER: _ClassVar[int]
    SIZE_FIELD_NUMBER: _ClassVar[int]
    ETAG_FIELD_NUMBER: _ClassVar[int]
    uri: str
    size: int
    etag: str
    def __init__(
        self,
        uri: _Optional[str] = ...,
        size: _Optional[int] = ...,
        etag: _Optional[str] = ...,
    ) -> None: ...

class BLOB(_message.Message):
    __slots__ = ("id", "chunks")
    ID_FIELD_NUMBER: _ClassVar[int]
    CHUNKS_FIELD_NUMBER: _ClassVar[int]
    id: str
    chunks: _containers.RepeatedCompositeFieldContainer[BLOBChunk]
    def __init__(
        self,
        id: _Optional[str] = ...,
        chunks: _Optional[_Iterable[_Union[BLOBChunk, _Mapping]]] = ...,
    ) -> None: ...

class SerializedObjectInsideBLOB(_message.Message):
    __slots__ = ("manifest", "offset")
    MANIFEST_FIELD_NUMBER: _ClassVar[int]
    OFFSET_FIELD_NUMBER: _ClassVar[int]
    manifest: SerializedObjectManifest
    offset: int
    def __init__(
        self,
        manifest: _Optional[_Union[SerializedObjectManifest, _Mapping]] = ...,
        offset: _Optional[int] = ...,
    ) -> None: ...

class FunctionRef(_message.Message):
    __slots__ = (
        "namespace",
        "application_name",
        "function_name",
        "application_version",
    )
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    APPLICATION_NAME_FIELD_NUMBER: _ClassVar[int]
    FUNCTION_NAME_FIELD_NUMBER: _ClassVar[int]
    APPLICATION_VERSION_FIELD_NUMBER: _ClassVar[int]
    namespace: str
    application_name: str
    function_name: str
    application_version: str
    def __init__(
        self,
        namespace: _Optional[str] = ...,
        application_name: _Optional[str] = ...,
        function_name: _Optional[str] = ...,
        application_version: _Optional[str] = ...,
    ) -> None: ...

class InitializeRequest(_message.Message):
    __slots__ = ("function", "application_code")
    FUNCTION_FIELD_NUMBER: _ClassVar[int]
    APPLICATION_CODE_FIELD_NUMBER: _ClassVar[int]
    function: FunctionRef
    application_code: SerializedObject
    def __init__(
        self,
        function: _Optional[_Union[FunctionRef, _Mapping]] = ...,
        application_code: _Optional[_Union[SerializedObject, _Mapping]] = ...,
    ) -> None: ...

class InitializeResponse(_message.Message):
    __slots__ = ("outcome_code", "failure_reason")
    OUTCOME_CODE_FIELD_NUMBER: _ClassVar[int]
    FAILURE_REASON_FIELD_NUMBER: _ClassVar[int]
    outcome_code: InitializationOutcomeCode
    failure_reason: InitializationFailureReason
    def __init__(
        self,
        outcome_code: _Optional[_Union[InitializationOutcomeCode, str]] = ...,
        failure_reason: _Optional[_Union[InitializationFailureReason, str]] = ...,
    ) -> None: ...

class ListAllocationsRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ListAllocationsResponse(_message.Message):
    __slots__ = ("allocations",)
    ALLOCATIONS_FIELD_NUMBER: _ClassVar[int]
    allocations: _containers.RepeatedCompositeFieldContainer[Allocation]
    def __init__(
        self, allocations: _Optional[_Iterable[_Union[Allocation, _Mapping]]] = ...
    ) -> None: ...

class Metrics(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class AllocationProgress(_message.Message):
    __slots__ = ("current", "total")
    CURRENT_FIELD_NUMBER: _ClassVar[int]
    TOTAL_FIELD_NUMBER: _ClassVar[int]
    current: float
    total: float
    def __init__(
        self, current: _Optional[float] = ..., total: _Optional[float] = ...
    ) -> None: ...

class AllocationOutputBLOBRequest(_message.Message):
    __slots__ = ("id", "size")
    ID_FIELD_NUMBER: _ClassVar[int]
    SIZE_FIELD_NUMBER: _ClassVar[int]
    id: str
    size: int
    def __init__(
        self, id: _Optional[str] = ..., size: _Optional[int] = ...
    ) -> None: ...

class AllocationRequestStatePrepareReadOperation(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class AllocationRequestStatePrepareWriteOperation(_message.Message):
    __slots__ = ("size",)
    SIZE_FIELD_NUMBER: _ClassVar[int]
    size: int
    def __init__(self, size: _Optional[int] = ...) -> None: ...

class AllocationRequestStateCommitWriteOperation(_message.Message):
    __slots__ = ("blob",)
    BLOB_FIELD_NUMBER: _ClassVar[int]
    blob: BLOB
    def __init__(self, blob: _Optional[_Union[BLOB, _Mapping]] = ...) -> None: ...

class AllocationRequestStateOperation(_message.Message):
    __slots__ = (
        "operation_id",
        "state_key",
        "prepare_read",
        "prepare_write",
        "commit_write",
    )
    OPERATION_ID_FIELD_NUMBER: _ClassVar[int]
    STATE_KEY_FIELD_NUMBER: _ClassVar[int]
    PREPARE_READ_FIELD_NUMBER: _ClassVar[int]
    PREPARE_WRITE_FIELD_NUMBER: _ClassVar[int]
    COMMIT_WRITE_FIELD_NUMBER: _ClassVar[int]
    operation_id: str
    state_key: str
    prepare_read: AllocationRequestStatePrepareReadOperation
    prepare_write: AllocationRequestStatePrepareWriteOperation
    commit_write: AllocationRequestStateCommitWriteOperation
    def __init__(
        self,
        operation_id: _Optional[str] = ...,
        state_key: _Optional[str] = ...,
        prepare_read: _Optional[
            _Union[AllocationRequestStatePrepareReadOperation, _Mapping]
        ] = ...,
        prepare_write: _Optional[
            _Union[AllocationRequestStatePrepareWriteOperation, _Mapping]
        ] = ...,
        commit_write: _Optional[
            _Union[AllocationRequestStateCommitWriteOperation, _Mapping]
        ] = ...,
    ) -> None: ...

class AllocationState(_message.Message):
    __slots__ = (
        "progress",
        "output_blob_requests",
        "request_state_operations",
        "sha256_hash",
    )
    PROGRESS_FIELD_NUMBER: _ClassVar[int]
    OUTPUT_BLOB_REQUESTS_FIELD_NUMBER: _ClassVar[int]
    REQUEST_STATE_OPERATIONS_FIELD_NUMBER: _ClassVar[int]
    SHA256_HASH_FIELD_NUMBER: _ClassVar[int]
    progress: AllocationProgress
    output_blob_requests: _containers.RepeatedCompositeFieldContainer[
        AllocationOutputBLOBRequest
    ]
    request_state_operations: _containers.RepeatedCompositeFieldContainer[
        AllocationRequestStateOperation
    ]
    sha256_hash: str
    def __init__(
        self,
        progress: _Optional[_Union[AllocationProgress, _Mapping]] = ...,
        output_blob_requests: _Optional[
            _Iterable[_Union[AllocationOutputBLOBRequest, _Mapping]]
        ] = ...,
        request_state_operations: _Optional[
            _Iterable[_Union[AllocationRequestStateOperation, _Mapping]]
        ] = ...,
        sha256_hash: _Optional[str] = ...,
    ) -> None: ...

class FunctionInputs(_message.Message):
    __slots__ = ("args", "arg_blobs", "request_error_blob", "function_call_metadata")
    ARGS_FIELD_NUMBER: _ClassVar[int]
    ARG_BLOBS_FIELD_NUMBER: _ClassVar[int]
    REQUEST_ERROR_BLOB_FIELD_NUMBER: _ClassVar[int]
    FUNCTION_CALL_METADATA_FIELD_NUMBER: _ClassVar[int]
    args: _containers.RepeatedCompositeFieldContainer[SerializedObjectInsideBLOB]
    arg_blobs: _containers.RepeatedCompositeFieldContainer[BLOB]
    request_error_blob: BLOB
    function_call_metadata: bytes
    def __init__(
        self,
        args: _Optional[_Iterable[_Union[SerializedObjectInsideBLOB, _Mapping]]] = ...,
        arg_blobs: _Optional[_Iterable[_Union[BLOB, _Mapping]]] = ...,
        request_error_blob: _Optional[_Union[BLOB, _Mapping]] = ...,
        function_call_metadata: _Optional[bytes] = ...,
    ) -> None: ...

class FunctionArg(_message.Message):
    __slots__ = ("function_call_id", "value")
    FUNCTION_CALL_ID_FIELD_NUMBER: _ClassVar[int]
    VALUE_FIELD_NUMBER: _ClassVar[int]
    function_call_id: str
    value: SerializedObjectInsideBLOB
    def __init__(
        self,
        function_call_id: _Optional[str] = ...,
        value: _Optional[_Union[SerializedObjectInsideBLOB, _Mapping]] = ...,
    ) -> None: ...

class FunctionCall(_message.Message):
    __slots__ = ("id", "target", "args", "call_metadata")
    ID_FIELD_NUMBER: _ClassVar[int]
    TARGET_FIELD_NUMBER: _ClassVar[int]
    ARGS_FIELD_NUMBER: _ClassVar[int]
    CALL_METADATA_FIELD_NUMBER: _ClassVar[int]
    id: str
    target: FunctionRef
    args: _containers.RepeatedCompositeFieldContainer[FunctionArg]
    call_metadata: bytes
    def __init__(
        self,
        id: _Optional[str] = ...,
        target: _Optional[_Union[FunctionRef, _Mapping]] = ...,
        args: _Optional[_Iterable[_Union[FunctionArg, _Mapping]]] = ...,
        call_metadata: _Optional[bytes] = ...,
    ) -> None: ...

class ExecutionPlanUpdate(_message.Message):
    __slots__ = ("function_call",)
    FUNCTION_CALL_FIELD_NUMBER: _ClassVar[int]
    function_call: FunctionCall
    def __init__(
        self, function_call: _Optional[_Union[FunctionCall, _Mapping]] = ...
    ) -> None: ...

class ExecutionPlanUpdates(_message.Message):
    __slots__ = ("updates", "root_function_call_id", "start_at")
    UPDATES_FIELD_NUMBER: _ClassVar[int]
    ROOT_FUNCTION_CALL_ID_FIELD_NUMBER: _ClassVar[int]
    START_AT_FIELD_NUMBER: _ClassVar[int]
    updates: _containers.RepeatedCompositeFieldContainer[ExecutionPlanUpdate]
    root_function_call_id: str
    start_at: _timestamp_pb2.Timestamp
    def __init__(
        self,
        updates: _Optional[_Iterable[_Union[ExecutionPlanUpdate, _Mapping]]] = ...,
        root_function_call_id: _Optional[str] = ...,
        start_at: _Optional[
            _Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]
        ] = ...,
    ) -> None: ...

class Allocation(_message.Message):
    __slots__ = (
        "request_id",
        "function_call_id",
        "allocation_id",
        "inputs",
        "replay_mode",
    )
    REQUEST_ID_FIELD_NUMBER: _ClassVar[int]
    FUNCTION_CALL_ID_FIELD_NUMBER: _ClassVar[int]
    ALLOCATION_ID_FIELD_NUMBER: _ClassVar[int]
    INPUTS_FIELD_NUMBER: _ClassVar[int]
    REPLAY_MODE_FIELD_NUMBER: _ClassVar[int]
    request_id: str
    function_call_id: str
    allocation_id: str
    inputs: FunctionInputs
    replay_mode: ReplayMode
    def __init__(
        self,
        request_id: _Optional[str] = ...,
        function_call_id: _Optional[str] = ...,
        allocation_id: _Optional[str] = ...,
        inputs: _Optional[_Union[FunctionInputs, _Mapping]] = ...,
        replay_mode: _Optional[_Union[ReplayMode, str]] = ...,
    ) -> None: ...

class CreateAllocationRequest(_message.Message):
    __slots__ = ("allocation",)
    ALLOCATION_FIELD_NUMBER: _ClassVar[int]
    allocation: Allocation
    def __init__(
        self, allocation: _Optional[_Union[Allocation, _Mapping]] = ...
    ) -> None: ...

class WatchAllocationStateRequest(_message.Message):
    __slots__ = ("allocation_id",)
    ALLOCATION_ID_FIELD_NUMBER: _ClassVar[int]
    allocation_id: str
    def __init__(self, allocation_id: _Optional[str] = ...) -> None: ...

class DeleteAllocationRequest(_message.Message):
    __slots__ = ("allocation_id",)
    ALLOCATION_ID_FIELD_NUMBER: _ClassVar[int]
    allocation_id: str
    def __init__(self, allocation_id: _Optional[str] = ...) -> None: ...

class AllocationOutputBLOB(_message.Message):
    __slots__ = ("status", "blob")
    STATUS_FIELD_NUMBER: _ClassVar[int]
    BLOB_FIELD_NUMBER: _ClassVar[int]
    status: _status_pb2.Status
    blob: BLOB
    def __init__(
        self,
        status: _Optional[_Union[_status_pb2.Status, _Mapping]] = ...,
        blob: _Optional[_Union[BLOB, _Mapping]] = ...,
    ) -> None: ...

class AllocationRequestStatePrepareReadOperationResult(_message.Message):
    __slots__ = ("blob",)
    BLOB_FIELD_NUMBER: _ClassVar[int]
    blob: BLOB
    def __init__(self, blob: _Optional[_Union[BLOB, _Mapping]] = ...) -> None: ...

class AllocationRequestStatePrepareWriteOperationResult(_message.Message):
    __slots__ = ("blob",)
    BLOB_FIELD_NUMBER: _ClassVar[int]
    blob: BLOB
    def __init__(self, blob: _Optional[_Union[BLOB, _Mapping]] = ...) -> None: ...

class AllocationRequestStateCommitWriteOperationResult(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class AllocationRequestStateOperationResult(_message.Message):
    __slots__ = (
        "operation_id",
        "status",
        "prepare_read",
        "prepare_write",
        "commit_write",
    )
    OPERATION_ID_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    PREPARE_READ_FIELD_NUMBER: _ClassVar[int]
    PREPARE_WRITE_FIELD_NUMBER: _ClassVar[int]
    COMMIT_WRITE_FIELD_NUMBER: _ClassVar[int]
    operation_id: str
    status: _status_pb2.Status
    prepare_read: AllocationRequestStatePrepareReadOperationResult
    prepare_write: AllocationRequestStatePrepareWriteOperationResult
    commit_write: AllocationRequestStateCommitWriteOperationResult
    def __init__(
        self,
        operation_id: _Optional[str] = ...,
        status: _Optional[_Union[_status_pb2.Status, _Mapping]] = ...,
        prepare_read: _Optional[
            _Union[AllocationRequestStatePrepareReadOperationResult, _Mapping]
        ] = ...,
        prepare_write: _Optional[
            _Union[AllocationRequestStatePrepareWriteOperationResult, _Mapping]
        ] = ...,
        commit_write: _Optional[
            _Union[AllocationRequestStateCommitWriteOperationResult, _Mapping]
        ] = ...,
    ) -> None: ...

class AllocationUpdate(_message.Message):
    __slots__ = ("allocation_id", "output_blob", "request_state_operation_result")
    ALLOCATION_ID_FIELD_NUMBER: _ClassVar[int]
    OUTPUT_BLOB_FIELD_NUMBER: _ClassVar[int]
    REQUEST_STATE_OPERATION_RESULT_FIELD_NUMBER: _ClassVar[int]
    allocation_id: str
    output_blob: AllocationOutputBLOB
    request_state_operation_result: AllocationRequestStateOperationResult
    def __init__(
        self,
        allocation_id: _Optional[str] = ...,
        output_blob: _Optional[_Union[AllocationOutputBLOB, _Mapping]] = ...,
        request_state_operation_result: _Optional[
            _Union[AllocationRequestStateOperationResult, _Mapping]
        ] = ...,
    ) -> None: ...

class AllocationExecutionEventCreateFunctionCall(_message.Message):
    __slots__ = ("updates", "args_blob")
    UPDATES_FIELD_NUMBER: _ClassVar[int]
    ARGS_BLOB_FIELD_NUMBER: _ClassVar[int]
    updates: ExecutionPlanUpdates
    args_blob: BLOB
    def __init__(
        self,
        updates: _Optional[_Union[ExecutionPlanUpdates, _Mapping]] = ...,
        args_blob: _Optional[_Union[BLOB, _Mapping]] = ...,
    ) -> None: ...

class AllocationExecutionEventFunctionCallCreationFailed(_message.Message):
    __slots__ = ("function_call_id", "metadata")
    FUNCTION_CALL_ID_FIELD_NUMBER: _ClassVar[int]
    METADATA_FIELD_NUMBER: _ClassVar[int]
    function_call_id: str
    metadata: bytes
    def __init__(
        self, function_call_id: _Optional[str] = ..., metadata: _Optional[bytes] = ...
    ) -> None: ...

class AllocationExecutionEventCreateFunctionCallWatcher(_message.Message):
    __slots__ = ("function_call_id", "deadline")
    FUNCTION_CALL_ID_FIELD_NUMBER: _ClassVar[int]
    DEADLINE_FIELD_NUMBER: _ClassVar[int]
    function_call_id: str
    deadline: _timestamp_pb2.Timestamp
    def __init__(
        self,
        function_call_id: _Optional[str] = ...,
        deadline: _Optional[
            _Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]
        ] = ...,
    ) -> None: ...

class AllocationExecutionEventFinishAllocation(_message.Message):
    __slots__ = (
        "outcome_code",
        "failure_reason",
        "value",
        "tail_call_durable_id",
        "uploaded_function_outputs_blob",
        "request_error_output",
        "uploaded_request_error_blob",
    )
    OUTCOME_CODE_FIELD_NUMBER: _ClassVar[int]
    FAILURE_REASON_FIELD_NUMBER: _ClassVar[int]
    VALUE_FIELD_NUMBER: _ClassVar[int]
    TAIL_CALL_DURABLE_ID_FIELD_NUMBER: _ClassVar[int]
    UPLOADED_FUNCTION_OUTPUTS_BLOB_FIELD_NUMBER: _ClassVar[int]
    REQUEST_ERROR_OUTPUT_FIELD_NUMBER: _ClassVar[int]
    UPLOADED_REQUEST_ERROR_BLOB_FIELD_NUMBER: _ClassVar[int]
    outcome_code: AllocationOutcomeCode
    failure_reason: AllocationFailureReason
    value: SerializedObjectInsideBLOB
    tail_call_durable_id: str
    uploaded_function_outputs_blob: BLOB
    request_error_output: SerializedObjectInsideBLOB
    uploaded_request_error_blob: BLOB
    def __init__(
        self,
        outcome_code: _Optional[_Union[AllocationOutcomeCode, str]] = ...,
        failure_reason: _Optional[_Union[AllocationFailureReason, str]] = ...,
        value: _Optional[_Union[SerializedObjectInsideBLOB, _Mapping]] = ...,
        tail_call_durable_id: _Optional[str] = ...,
        uploaded_function_outputs_blob: _Optional[_Union[BLOB, _Mapping]] = ...,
        request_error_output: _Optional[
            _Union[SerializedObjectInsideBLOB, _Mapping]
        ] = ...,
        uploaded_request_error_blob: _Optional[_Union[BLOB, _Mapping]] = ...,
    ) -> None: ...

class AllocationExecutionEvent(_message.Message):
    __slots__ = (
        "create_function_call",
        "function_call_creation_failed",
        "create_function_call_watcher",
        "finish_allocation",
    )
    CREATE_FUNCTION_CALL_FIELD_NUMBER: _ClassVar[int]
    FUNCTION_CALL_CREATION_FAILED_FIELD_NUMBER: _ClassVar[int]
    CREATE_FUNCTION_CALL_WATCHER_FIELD_NUMBER: _ClassVar[int]
    FINISH_ALLOCATION_FIELD_NUMBER: _ClassVar[int]
    create_function_call: AllocationExecutionEventCreateFunctionCall
    function_call_creation_failed: AllocationExecutionEventFunctionCallCreationFailed
    create_function_call_watcher: AllocationExecutionEventCreateFunctionCallWatcher
    finish_allocation: AllocationExecutionEventFinishAllocation
    def __init__(
        self,
        create_function_call: _Optional[
            _Union[AllocationExecutionEventCreateFunctionCall, _Mapping]
        ] = ...,
        function_call_creation_failed: _Optional[
            _Union[AllocationExecutionEventFunctionCallCreationFailed, _Mapping]
        ] = ...,
        create_function_call_watcher: _Optional[
            _Union[AllocationExecutionEventCreateFunctionCallWatcher, _Mapping]
        ] = ...,
        finish_allocation: _Optional[
            _Union[AllocationExecutionEventFinishAllocation, _Mapping]
        ] = ...,
    ) -> None: ...

class GetAllocationExecutionLogBatchRequest(_message.Message):
    __slots__ = ("allocation_id",)
    ALLOCATION_ID_FIELD_NUMBER: _ClassVar[int]
    allocation_id: str
    def __init__(self, allocation_id: _Optional[str] = ...) -> None: ...

class GetAllocationExecutionLogBatchResponse(_message.Message):
    __slots__ = ("events",)
    EVENTS_FIELD_NUMBER: _ClassVar[int]
    events: _containers.RepeatedCompositeFieldContainer[AllocationExecutionEvent]
    def __init__(
        self,
        events: _Optional[_Iterable[_Union[AllocationExecutionEvent, _Mapping]]] = ...,
    ) -> None: ...

class AdvanceAllocationExecutionLogBatchRequest(_message.Message):
    __slots__ = ("allocation_id",)
    ALLOCATION_ID_FIELD_NUMBER: _ClassVar[int]
    allocation_id: str
    def __init__(self, allocation_id: _Optional[str] = ...) -> None: ...

class AllocationEventFunctionCallCreated(_message.Message):
    __slots__ = ("function_call_id", "status", "metadata")
    FUNCTION_CALL_ID_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    METADATA_FIELD_NUMBER: _ClassVar[int]
    function_call_id: str
    status: _status_pb2.Status
    metadata: bytes
    def __init__(
        self,
        function_call_id: _Optional[str] = ...,
        status: _Optional[_Union[_status_pb2.Status, _Mapping]] = ...,
        metadata: _Optional[bytes] = ...,
    ) -> None: ...

class AllocationEventFunctionCallWatcherCreated(_message.Message):
    __slots__ = ("function_call_id", "status")
    FUNCTION_CALL_ID_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    function_call_id: str
    status: _status_pb2.Status
    def __init__(
        self,
        function_call_id: _Optional[str] = ...,
        status: _Optional[_Union[_status_pb2.Status, _Mapping]] = ...,
    ) -> None: ...

class AllocationEventFunctionCallWatcherResult(_message.Message):
    __slots__ = (
        "function_call_id",
        "outcome_code",
        "watcher_status",
        "value_output",
        "value_blob",
        "request_error_output",
        "request_error_blob",
    )
    FUNCTION_CALL_ID_FIELD_NUMBER: _ClassVar[int]
    OUTCOME_CODE_FIELD_NUMBER: _ClassVar[int]
    WATCHER_STATUS_FIELD_NUMBER: _ClassVar[int]
    VALUE_OUTPUT_FIELD_NUMBER: _ClassVar[int]
    VALUE_BLOB_FIELD_NUMBER: _ClassVar[int]
    REQUEST_ERROR_OUTPUT_FIELD_NUMBER: _ClassVar[int]
    REQUEST_ERROR_BLOB_FIELD_NUMBER: _ClassVar[int]
    function_call_id: str
    outcome_code: AllocationOutcomeCode
    watcher_status: FunctionCallWatcherStatus
    value_output: SerializedObjectInsideBLOB
    value_blob: BLOB
    request_error_output: SerializedObjectInsideBLOB
    request_error_blob: BLOB
    def __init__(
        self,
        function_call_id: _Optional[str] = ...,
        outcome_code: _Optional[_Union[AllocationOutcomeCode, str]] = ...,
        watcher_status: _Optional[_Union[FunctionCallWatcherStatus, str]] = ...,
        value_output: _Optional[_Union[SerializedObjectInsideBLOB, _Mapping]] = ...,
        value_blob: _Optional[_Union[BLOB, _Mapping]] = ...,
        request_error_output: _Optional[
            _Union[SerializedObjectInsideBLOB, _Mapping]
        ] = ...,
        request_error_blob: _Optional[_Union[BLOB, _Mapping]] = ...,
    ) -> None: ...

class AllocationEvent(_message.Message):
    __slots__ = (
        "clock",
        "function_call_created",
        "function_call_watcher_created",
        "function_call_watcher_result",
    )
    CLOCK_FIELD_NUMBER: _ClassVar[int]
    FUNCTION_CALL_CREATED_FIELD_NUMBER: _ClassVar[int]
    FUNCTION_CALL_WATCHER_CREATED_FIELD_NUMBER: _ClassVar[int]
    FUNCTION_CALL_WATCHER_RESULT_FIELD_NUMBER: _ClassVar[int]
    clock: int
    function_call_created: AllocationEventFunctionCallCreated
    function_call_watcher_created: AllocationEventFunctionCallWatcherCreated
    function_call_watcher_result: AllocationEventFunctionCallWatcherResult
    def __init__(
        self,
        clock: _Optional[int] = ...,
        function_call_created: _Optional[
            _Union[AllocationEventFunctionCallCreated, _Mapping]
        ] = ...,
        function_call_watcher_created: _Optional[
            _Union[AllocationEventFunctionCallWatcherCreated, _Mapping]
        ] = ...,
        function_call_watcher_result: _Optional[
            _Union[AllocationEventFunctionCallWatcherResult, _Mapping]
        ] = ...,
    ) -> None: ...

class ReadAllocationEventLogRequest(_message.Message):
    __slots__ = ("allocation_id", "after_clock", "max_entries")
    ALLOCATION_ID_FIELD_NUMBER: _ClassVar[int]
    AFTER_CLOCK_FIELD_NUMBER: _ClassVar[int]
    MAX_ENTRIES_FIELD_NUMBER: _ClassVar[int]
    allocation_id: str
    after_clock: int
    max_entries: int
    def __init__(
        self,
        allocation_id: _Optional[str] = ...,
        after_clock: _Optional[int] = ...,
        max_entries: _Optional[int] = ...,
    ) -> None: ...

class ReadAllocationEventLogResponse(_message.Message):
    __slots__ = ("allocation_id", "entries", "last_clock", "has_more")
    ALLOCATION_ID_FIELD_NUMBER: _ClassVar[int]
    ENTRIES_FIELD_NUMBER: _ClassVar[int]
    LAST_CLOCK_FIELD_NUMBER: _ClassVar[int]
    HAS_MORE_FIELD_NUMBER: _ClassVar[int]
    allocation_id: str
    entries: _containers.RepeatedCompositeFieldContainer[AllocationEvent]
    last_clock: int
    has_more: bool
    def __init__(
        self,
        allocation_id: _Optional[str] = ...,
        entries: _Optional[_Iterable[_Union[AllocationEvent, _Mapping]]] = ...,
        last_clock: _Optional[int] = ...,
        has_more: bool = ...,
    ) -> None: ...

class WatchAllocationEventLogReads(_message.Message):
    __slots__ = ("allocation_id",)
    ALLOCATION_ID_FIELD_NUMBER: _ClassVar[int]
    allocation_id: str
    def __init__(self, allocation_id: _Optional[str] = ...) -> None: ...

class HealthCheckRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class HealthCheckResponse(_message.Message):
    __slots__ = ("healthy", "status_message")
    HEALTHY_FIELD_NUMBER: _ClassVar[int]
    STATUS_MESSAGE_FIELD_NUMBER: _ClassVar[int]
    healthy: bool
    status_message: str
    def __init__(
        self, healthy: bool = ..., status_message: _Optional[str] = ...
    ) -> None: ...

class InfoRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class InfoResponse(_message.Message):
    __slots__ = ("version", "sdk_version", "sdk_language", "sdk_language_version")
    VERSION_FIELD_NUMBER: _ClassVar[int]
    SDK_VERSION_FIELD_NUMBER: _ClassVar[int]
    SDK_LANGUAGE_FIELD_NUMBER: _ClassVar[int]
    SDK_LANGUAGE_VERSION_FIELD_NUMBER: _ClassVar[int]
    version: str
    sdk_version: str
    sdk_language: str
    sdk_language_version: str
    def __init__(
        self,
        version: _Optional[str] = ...,
        sdk_version: _Optional[str] = ...,
        sdk_language: _Optional[str] = ...,
        sdk_language_version: _Optional[str] = ...,
    ) -> None: ...
