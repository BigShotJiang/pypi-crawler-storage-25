"""Tests for RCA module."""
