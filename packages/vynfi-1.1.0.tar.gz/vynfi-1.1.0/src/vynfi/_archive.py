"""Job archive extraction utilities."""

from __future__ import annotations

import io
import json
import zipfile
from pathlib import Path
from typing import Any


class JobArchive:
    """Wrapper around a downloaded job archive (zip) for easy file access.

    Usage::

        archive = client.jobs.download_archive(job_id)

        # List all files
        print(archive.files())

        # Read a specific JSON file
        entries = archive.json("journal_entries.json")

        # Read CSV content
        csv_text = archive.text("chart_of_accounts.csv")

        # Extract everything to disk
        archive.extract_to("./output")

        # Find files by pattern
        banking_files = archive.find("banking/*")
    """

    def __init__(self, data: bytes) -> None:
        self._data = data
        self._zip = zipfile.ZipFile(io.BytesIO(data))

    def files(self) -> list[str]:
        """List all file paths in the archive."""
        return self._zip.namelist()

    def find(self, pattern: str) -> list[str]:
        """Find files matching a glob-like pattern.

        Supports simple prefix matching with ``*`` wildcard.
        Examples: ``"banking/*"``, ``"*.csv"``, ``"esg/*"``.
        """
        import fnmatch

        return fnmatch.filter(self._zip.namelist(), pattern)

    def categories(self) -> list[str]:
        """List top-level directories (categories) in the archive."""
        dirs: set[str] = set()
        for name in self._zip.namelist():
            if "/" in name:
                dirs.add(name.split("/")[0])
        return sorted(dirs)

    def read(self, path: str) -> bytes:
        """Read a file from the archive as raw bytes.

        Args:
            path: File path within the archive. If an exact match isn't found,
                  searches for the filename anywhere in the archive.
        """
        if path in self._zip.namelist():
            return self._zip.read(path)
        # Fuzzy match: search by filename
        basename = path.rsplit("/", 1)[-1]
        for name in self._zip.namelist():
            if name.endswith("/" + basename) or name == basename:
                return self._zip.read(name)
        raise KeyError(f"File not found in archive: {path}")

    def text(self, path: str, encoding: str = "utf-8") -> str:
        """Read a file from the archive as a string."""
        return self.read(path).decode(encoding)

    def json(self, path: str) -> Any:
        """Read and parse a JSON file from the archive."""
        return json.loads(self.read(path))

    def extract_to(self, directory: str | Path) -> Path:
        """Extract all files to a directory.

        Args:
            directory: Target directory (created if it doesn't exist)

        Returns:
            Path to the extraction directory
        """
        out = Path(directory)
        out.mkdir(parents=True, exist_ok=True)
        self._zip.extractall(out)
        return out

    def size(self, path: str) -> int:
        """Get the uncompressed size of a file in bytes."""
        info = self._zip.getinfo(path)
        return info.file_size

    def summary(self) -> dict[str, Any]:
        """Get a summary of the archive contents.

        Returns a dict with categories, file counts, and total size.
        """
        cats: dict[str, list[str]] = {}
        total_size = 0
        for info in self._zip.infolist():
            total_size += info.file_size
            parts = info.filename.split("/")
            cat = parts[0] if len(parts) > 1 else "(root)"
            cats.setdefault(cat, []).append(info.filename)
        return {
            "total_files": len(self._zip.infolist()),
            "total_size_bytes": total_size,
            "categories": {k: len(v) for k, v in sorted(cats.items())},
        }

    def __repr__(self) -> str:
        s = self.summary()
        return f"JobArchive({s['total_files']} files, {s['total_size_bytes'] / 1024 / 1024:.1f} MB)"

    def __enter__(self) -> JobArchive:
        return self

    def __exit__(self, *args: Any) -> None:
        self._zip.close()

    def close(self) -> None:
        """Close the underlying zip file."""
        self._zip.close()
