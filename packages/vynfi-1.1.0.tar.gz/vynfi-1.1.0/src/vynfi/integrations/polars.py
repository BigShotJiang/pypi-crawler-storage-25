"""Polars integration for VynFi SDK.

Requires ``pip install vynfi[polars]``.

Usage::

    from vynfi import VynFi
    from vynfi.integrations.polars import job_to_frame, download_frame

    client = VynFi(api_key="vf_live_...")

    # Submit and wait
    job = client.jobs.generate(tables=[{"name": "journal_entries", "rows": 1000}])
    completed = client.jobs.wait(job.id)

    # Download a specific artifact as a Polars DataFrame
    df = download_frame(client, completed.id, "journal_entries.json")
"""

from __future__ import annotations

import json
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from .. import VynFi

try:
    import polars as pl
except ImportError as e:
    raise ImportError(
        "polars is required for this integration. Install it with: pip install vynfi[polars]"
    ) from e


def job_to_frame(data: bytes, **kwargs: Any) -> pl.DataFrame:
    """Convert raw JSON bytes from a job artifact into a Polars DataFrame.

    Handles both JSON arrays and newline-delimited JSON.

    Args:
        data: Raw bytes from ``client.jobs.download_file(...)``
        **kwargs: Additional arguments passed to ``pl.DataFrame``
    """
    text = data.decode("utf-8")
    try:
        parsed = json.loads(text)
    except json.JSONDecodeError:
        # Try newline-delimited JSON
        lines = [json.loads(line) for line in text.strip().split("\n") if line.strip()]
        return pl.DataFrame(lines, **kwargs)

    if isinstance(parsed, list):
        return pl.DataFrame(parsed, **kwargs)
    if isinstance(parsed, dict):
        if "data" in parsed and isinstance(parsed["data"], list):
            return pl.DataFrame(parsed["data"], **kwargs)
        return pl.DataFrame([parsed], **kwargs)
    return pl.DataFrame(parsed, **kwargs)


def download_frame(
    client: VynFi,
    job_id: str,
    file: str,
    **kwargs: Any,
) -> pl.DataFrame:
    """Download a specific artifact file and return as a Polars DataFrame.

    Args:
        client: VynFi client instance
        job_id: Completed job ID
        file: Artifact path (e.g. "journal_entries.json")
        **kwargs: Additional arguments passed to DataFrame construction
    """
    raw = client.jobs.download_file(job_id, file)
    return job_to_frame(raw, **kwargs)


def usage_to_frame(client: VynFi, *, days: int | None = None) -> pl.DataFrame:
    """Fetch daily usage and return as a Polars DataFrame.

    Args:
        client: VynFi client instance
        days: Number of days to look back
    """
    kwargs_api: dict[str, Any] = {}
    if days is not None:
        kwargs_api["days"] = days
    resp = client.usage.daily(**kwargs_api)
    records = [{"date": str(d.date), "credits": d.credits} for d in resp.daily]
    if not records:
        return pl.DataFrame(schema={"date": pl.Date, "credits": pl.Int64})
    df = pl.DataFrame(records)
    df = df.with_columns(pl.col("date").str.to_date())
    return df


def quality_to_frame(client: VynFi) -> pl.DataFrame:
    """Fetch quality scores and return as a Polars DataFrame.

    Args:
        client: VynFi client instance
    """
    scores = client.quality.scores()
    return pl.DataFrame([s.model_dump() for s in scores])
