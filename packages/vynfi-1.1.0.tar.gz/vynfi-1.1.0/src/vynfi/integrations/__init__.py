"""Optional ecosystem integrations (pandas, polars)."""
