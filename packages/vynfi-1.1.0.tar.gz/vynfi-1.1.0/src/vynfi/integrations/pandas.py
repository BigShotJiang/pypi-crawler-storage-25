"""Pandas integration for VynFi SDK.

Requires ``pip install vynfi[pandas]``.

Usage::

    from vynfi import VynFi
    from vynfi.integrations.pandas import job_to_dataframe, archive_to_dataframes

    client = VynFi(api_key="vf_live_...")

    # Submit and wait
    job = client.jobs.generate(tables=[{"name": "journal_entries", "rows": 1000}])
    completed = client.jobs.wait(job.id)

    # Download archive and convert to DataFrames
    archive = client.jobs.download_archive(completed.id)
    df = job_to_dataframe(archive.read("journal_entries.json"))

    # Or get all JSON files as a dict of DataFrames
    frames = archive_to_dataframes(archive)
"""

from __future__ import annotations

import io
import json
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from .. import VynFi
    from .._archive import JobArchive

try:
    import pandas as pd
except ImportError as e:
    raise ImportError(
        "pandas is required for this integration. Install it with: pip install vynfi[pandas]"
    ) from e


def job_to_dataframe(data: bytes, **kwargs: Any) -> pd.DataFrame:
    """Convert raw JSON bytes from a job artifact into a pandas DataFrame.

    Handles both JSON arrays and newline-delimited JSON.

    Args:
        data: Raw bytes from ``client.jobs.download_file(...)``
        **kwargs: Additional arguments passed to ``pd.DataFrame`` or ``pd.read_json``
    """
    text = data.decode("utf-8")
    try:
        parsed = json.loads(text)
    except json.JSONDecodeError:
        # Try newline-delimited JSON
        return pd.read_json(io.StringIO(text), lines=True, **kwargs)

    if isinstance(parsed, list):
        return pd.DataFrame(parsed, **kwargs)
    if isinstance(parsed, dict):
        # Single object or wrapped response
        if "data" in parsed and isinstance(parsed["data"], list):
            return pd.DataFrame(parsed["data"], **kwargs)
        return pd.DataFrame([parsed], **kwargs)
    return pd.DataFrame(parsed, **kwargs)


def download_dataframe(
    client: VynFi,
    job_id: str,
    file: str,
    **kwargs: Any,
) -> pd.DataFrame:
    """Download a specific artifact file and return as a pandas DataFrame.

    Args:
        client: VynFi client instance
        job_id: Completed job ID
        file: Artifact path (e.g. "journal_entries.json")
        **kwargs: Additional arguments passed to DataFrame construction
    """
    raw = client.jobs.download_file(job_id, file)
    return job_to_dataframe(raw, **kwargs)


def usage_to_dataframe(client: VynFi, *, days: int | None = None) -> pd.DataFrame:
    """Fetch daily usage and return as a pandas DataFrame with a date index.

    Args:
        client: VynFi client instance
        days: Number of days to look back
    """
    kwargs: dict[str, Any] = {}
    if days is not None:
        kwargs["days"] = days
    resp = client.usage.daily(**kwargs)
    records = [{"date": d.date, "credits": d.credits} for d in resp.daily]
    df = pd.DataFrame(records)
    if not df.empty:
        df["date"] = pd.to_datetime(df["date"])
        df = df.set_index("date")
    return df


def quality_to_dataframe(client: VynFi) -> pd.DataFrame:
    """Fetch quality scores and return as a pandas DataFrame.

    Args:
        client: VynFi client instance
    """
    scores = client.quality.scores()
    return pd.DataFrame([s.model_dump() for s in scores])


def archive_to_dataframes(
    archive: JobArchive,
    *,
    include: list[str] | None = None,
    exclude: list[str] | None = None,
    flatten_nested: bool = True,
) -> dict[str, pd.DataFrame]:
    """Convert all JSON files in an archive to a dict of DataFrames.

    Args:
        archive: A :class:`~vynfi.JobArchive` from ``client.jobs.download_archive(...)``
        include: Only convert files matching these patterns (e.g. ``["banking/*"]``)
        exclude: Skip files matching these patterns
        flatten_nested: If True, flatten header/lines structure in journal entries

    Returns:
        Dict mapping file paths to DataFrames
    """
    import fnmatch

    frames: dict[str, pd.DataFrame] = {}
    for path in archive.files():
        if not path.endswith(".json"):
            continue
        if include and not any(fnmatch.fnmatch(path, p) for p in include):
            continue
        if exclude and any(fnmatch.fnmatch(path, p) for p in exclude):
            continue
        try:
            data = archive.read(path)
            parsed = json.loads(data)
            if not isinstance(parsed, list) or not parsed:
                continue
            # Handle header/lines journal entry format
            if flatten_nested and isinstance(parsed[0], dict) and "lines" in parsed[0]:
                rows = []
                for entry in parsed:
                    header = {k: v for k, v in entry.items() if k != "lines"}
                    if "header" in header and isinstance(header["header"], dict):
                        header_data = header.pop("header")
                        header.update(header_data)
                    for line in entry.get("lines", []):
                        rows.append({**header, **line})
                if rows:
                    frames[path] = pd.DataFrame(rows)
            else:
                frames[path] = pd.DataFrame(parsed)
        except (json.JSONDecodeError, ValueError, KeyError):
            continue
    return frames
