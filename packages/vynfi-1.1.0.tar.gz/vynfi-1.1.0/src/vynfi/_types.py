"""Pydantic models for VynFi API responses."""

from __future__ import annotations

from datetime import date, datetime
from typing import Any

from pydantic import BaseModel, ConfigDict, Field


def _to_camel(name: str) -> str:
    parts = name.split("_")
    return parts[0] + "".join(w.capitalize() for w in parts[1:])


class _CamelModel(BaseModel):
    """Base for models where the API returns camelCase keys."""

    model_config = ConfigDict(alias_generator=_to_camel, populate_by_name=True)


# ── Jobs ──────────────────────────────────────────────────────────────────────


class JobLinks(BaseModel):
    self_link: str = Field(default="", alias="self")
    stream: str = ""
    cancel: str = ""

    model_config = ConfigDict(populate_by_name=True)


class Job(BaseModel):
    id: str
    owner_id: str | None = None
    status: str
    config: Any = None
    progress: Any = None
    credits_reserved: int = 0
    credits_used: int | None = None
    artifacts: Any = None
    error_detail: str | None = None
    started_at: datetime | None = None
    completed_at: datetime | None = None
    created_at: datetime | None = None


class SubmitJobResponse(BaseModel):
    id: str
    status: str
    credits_reserved: int = 0
    estimated_duration_seconds: int = 0
    links: JobLinks | None = None


class QuickJobResponse(BaseModel):
    id: str
    status: str
    credits_used: int = 0
    rows_generated: int = 0
    download_url: str | None = None


class CancelJobResponse(BaseModel):
    id: str
    status: str
    credits_reserved: int = 0
    credits_used: int = 0
    credits_refunded: int = 0
    rows_generated: int = 0
    rows_total: int = 0


class JobList(BaseModel):
    data: list[Job] = Field(default_factory=list)


class SseEvent(BaseModel):
    event: str = ""
    data: Any = None


# ── Catalog / Sectors ─────────────────────────────────────────────────────────


class Column(BaseModel):
    name: str
    data_type: str = ""
    description: str = ""
    nullable: bool = False
    example_values: list[str] | None = None


class TableDef(BaseModel):
    id: str | None = None
    slug: str | None = None
    name: str
    description: str = ""
    base_rate: float = 1.0
    columns: list[Column] = Field(default_factory=list)


class Sector(BaseModel):
    id: str | None = None
    slug: str
    name: str
    description: str = ""
    icon: str = ""
    multiplier: float = 1.0
    quality_score: int = 0
    popularity: int = 0
    tables: list[TableDef] = Field(default_factory=list)


class SectorSummary(BaseModel):
    id: str | None = None
    slug: str
    name: str
    description: str = ""
    icon: str = ""
    multiplier: float = 1.0
    quality_score: int = 0
    popularity: int = 0
    table_count: int = 0


class CatalogItem(BaseModel):
    id: str | None = None
    slug: str = ""
    name: str = ""
    description: str = ""
    icon: str = ""
    multiplier: float = 1.0
    quality_score: int = 0
    popularity: int = 0
    table_count: int = 0


class Fingerprint(BaseModel):
    sector: Any = None
    table: TableDef | None = None


class Template(_CamelModel):
    id: str
    slug: str
    name: str
    description: str = ""
    sector: str = ""
    country: str = ""
    framework: str = ""
    config: Any = None
    min_tier: str = ""
    sort_order: int = 0


# ── Usage ─────────────────────────────────────────────────────────────────────


class UsageSummary(BaseModel):
    balance: int = 0
    total_used: int = 0
    total_reserved: int = 0
    total_refunded: int = 0
    period_days: int = 30
    burn_rate: int = 0


class DailyUsage(BaseModel):
    date: date
    credits: int = 0


class TableUsage(BaseModel):
    table_name: str = ""
    credits: int = 0
    job_count: int = 0


class DailyUsageResponse(BaseModel):
    daily: list[DailyUsage] = Field(default_factory=list)
    by_table: list[TableUsage] = Field(default_factory=list)


# ── API Keys ──────────────────────────────────────────────────────────────────


class ApiKey(BaseModel):
    id: str
    name: str
    prefix: str = ""
    environment: str = ""
    status: str = "active"
    last_used_at: datetime | None = None
    created_at: datetime | None = None


class ApiKeyCreated(BaseModel):
    id: str
    name: str
    prefix: str = ""
    key: str = ""
    environment: str = ""
    created_at: datetime | None = None


class RevokeKeyResponse(BaseModel):
    id: str
    status: str = ""
    revoked_at: datetime | None = None


# ── Quality ───────────────────────────────────────────────────────────────────


class QualityScore(BaseModel):
    id: str
    job_id: str
    table_type: str = ""
    rows: int = 0
    overall_score: float = 0.0
    benford_score: float = 0.0
    correlation_score: float = 0.0
    distribution_score: float = 0.0
    created_at: datetime | None = None


class DailyQuality(BaseModel):
    date: date
    score: float = 0.0


# ── Webhooks ──────────────────────────────────────────────────────────────────


class Webhook(BaseModel):
    id: str
    url: str
    events: list[str] = Field(default_factory=list)
    status: str = "active"
    created_at: datetime | None = None


class WebhookCreated(BaseModel):
    id: str
    url: str
    events: list[str] = Field(default_factory=list)
    secret: str = ""
    status: str = "active"
    created_at: datetime | None = None


class WebhookDelivery(BaseModel):
    id: str
    webhook_id: str = ""
    event_type: str = ""
    payload: Any = None
    status_code: int | None = None
    response_body: str | None = None
    attempt: int = 0
    succeeded: bool = False
    created_at: datetime | None = None


class WebhookDetail(BaseModel):
    id: str
    url: str
    events: list[str] = Field(default_factory=list)
    secret: str | None = None
    status: str = ""
    created_at: datetime | None = None
    deliveries: list[WebhookDelivery] = Field(default_factory=list)


# ── Billing ───────────────────────────────────────────────────────────────────


class Subscription(BaseModel):
    tier: str = ""
    status: str = ""
    stripe_price_id: str | None = None
    current_period_end: datetime | None = None


class CheckoutResponse(BaseModel):
    checkout_url: str


class PortalResponse(BaseModel):
    portal_url: str


class Invoice(BaseModel):
    id: str = ""
    number: str | None = None
    amount_due: int = 0
    amount_paid: int = 0
    status: str = ""
    created: int = 0
    due_date: int | None = None
    hosted_invoice_url: str | None = None
    pdf: str | None = None


# ── Configs ───────────────────────────────────────────────────────────────────


class SavedConfig(_CamelModel):
    id: str
    owner_id: str = ""
    name: str = ""
    description: str = ""
    config: Any = None
    source_template_id: str | None = None
    version: int = 0
    visibility: str = ""
    tags: list[str] = Field(default_factory=list)
    last_used_at: datetime | None = None
    created_at: datetime | None = None
    updated_at: datetime | None = None
    schema_version: int | None = None


class DeletedResponse(BaseModel):
    deleted: bool = False


class ValidationFix(BaseModel):
    field: str = ""
    action: str = ""
    value: Any = None


class ValidationIssue(BaseModel):
    field: str = ""
    code: str = ""
    message: str = ""
    fix: ValidationFix | None = None


class ValidateConfigResponse(BaseModel):
    valid: bool = False
    errors: list[ValidationIssue] = Field(default_factory=list)
    warnings: list[ValidationIssue] = Field(default_factory=list)


class MultiplierEntry(BaseModel):
    source: str = ""
    factor: float = 0.0
    label: str = ""


class BalanceInfo(_CamelModel):
    current: int = 0
    after_job: int = 0
    status: str = ""


class EstimateCostResponse(_CamelModel):
    base_credits: int = 0
    multipliers: list[MultiplierEntry] = Field(default_factory=list)
    total_credits: int = 0
    capped_at: float | None = None
    balance: BalanceInfo | None = None


class ComposeConfigResponse(BaseModel):
    config: Any = None
    yaml: str = ""
    layers: list[Any] = Field(default_factory=list)


# ── Credits ───────────────────────────────────────────────────────────────────


class PurchaseCreditsResponse(BaseModel):
    checkout_url: str = ""


class PrepaidBatch(_CamelModel):
    id: str
    owner_id: str = ""
    pack: str = ""
    credits_purchased: int = 0
    credits_remaining: int = 0
    credits_forfeited: int = 0
    status: str = ""
    purchased_at: datetime | None = None
    expires_at: datetime | None = None
    created_at: datetime | None = None


class PrepaidBalanceResponse(BaseModel):
    total_prepaid_credits: int = 0
    batches: list[PrepaidBatch] = Field(default_factory=list)


class PrepaidHistoryResponse(BaseModel):
    batches: list[PrepaidBatch] = Field(default_factory=list)


# ── Sessions ──────────────────────────────────────────────────────────────────


class GenerationSession(_CamelModel):
    id: str
    name: str = ""
    status: str = ""
    fiscal_year_start: str = ""
    period_length_months: int = 0
    periods_total: int = 0
    periods_generated: int = 0
    periods: Any = None
    balance_snapshot: Any = None
    generation_config: Any = None
    created_at: datetime | None = None
    updated_at: datetime | None = None


class GenerateSessionResponse(_CamelModel):
    id: str
    name: str = ""
    status: str = ""
    fiscal_year_start: str = ""
    period_length_months: int = 0
    periods_total: int = 0
    periods_generated: int = 0
    periods: Any = None
    balance_snapshot: Any = None
    generation_config: Any = None
    created_at: datetime | None = None
    updated_at: datetime | None = None
    job_id: str = ""
    period_index: int = 0
    credits_reserved: int = 0
    period_start: str = ""
    period_end: str = ""


# ── Scenarios ─────────────────────────────────────────────────────────────────


class Scenario(_CamelModel):
    id: str
    name: str = ""
    template_id: str = ""
    status: str = ""
    interventions: Any = None
    generation_config: Any = None
    baseline_job_id: str | None = None
    counterfactual_job_id: str | None = None
    diff: Any = None
    created_at: datetime | None = None
    updated_at: datetime | None = None


class ScenarioTemplateNode(BaseModel):
    id: str
    label: str = ""
    x: int = 0
    y: int = 0


class ScenarioTemplateEdge(BaseModel):
    source: str = ""
    target: str = ""


class ScenarioTemplate(_CamelModel):
    id: str
    name: str = ""
    description: str = ""
    node_count: int = 0
    nodes: list[ScenarioTemplateNode] = Field(default_factory=list)
    edges: list[ScenarioTemplateEdge] = Field(default_factory=list)
    intervention_types: list[str] = Field(default_factory=list)


# ── Notifications ─────────────────────────────────────────────────────────────


class Notification(BaseModel):
    id: str
    user_id: str = ""
    type: str = Field(default="", alias="type")
    title: str = ""
    message: str = ""
    link: str | None = None
    read: bool = False
    created_at: datetime | None = None

    model_config = ConfigDict(populate_by_name=True)
