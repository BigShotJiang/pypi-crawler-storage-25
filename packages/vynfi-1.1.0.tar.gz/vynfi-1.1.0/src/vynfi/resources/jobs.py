"""Jobs and data generation resource."""

from __future__ import annotations

import time
from collections.abc import Iterator
from pathlib import Path
from typing import Any

from .._archive import JobArchive
from .._client import SyncClient
from .._types import (
    CancelJobResponse,
    Job,
    JobList,
    QuickJobResponse,
    SubmitJobResponse,
)


class Jobs:
    """Manage generation jobs."""

    def __init__(self, client: SyncClient) -> None:
        self._client = client

    def generate(
        self,
        *,
        tables: list[dict[str, Any]],
        format: str | None = None,
        sector_slug: str | None = None,
        options: dict[str, Any] | None = None,
    ) -> SubmitJobResponse:
        """Submit an async generation job using the legacy tables format.

        Args:
            tables: List of table specs, e.g. [{"name": "journal_entries", "rows": 5000}]
            format: Output format — "json", "csv", or "parquet"
            sector_slug: Sector to generate from
            options: Additional generation options
        """
        body: dict[str, Any] = {"tables": tables}
        if format is not None:
            body["format"] = format
        if sector_slug is not None:
            body["sector_slug"] = sector_slug
        if options is not None:
            body["options"] = options
        data = self._client.request("POST", "/v1/generate", json=body)
        return SubmitJobResponse.model_validate(data)

    def generate_config(
        self,
        *,
        config: dict[str, Any],
        config_id: str | None = None,
    ) -> SubmitJobResponse:
        """Submit an async generation job using a config object.

        Args:
            config: Full generation config dict
            config_id: Optional saved config ID to use as base
        """
        body: dict[str, Any] = {"config": config}
        if config_id is not None:
            body["config_id"] = config_id
        data = self._client.request("POST", "/v1/generate", json=body)
        return SubmitJobResponse.model_validate(data)

    def generate_quick(
        self,
        *,
        tables: list[dict[str, Any]],
        format: str | None = None,
        sector_slug: str | None = None,
        options: dict[str, Any] | None = None,
    ) -> QuickJobResponse:
        """Submit a synchronous (quick) generation job.

        Returns the completed job directly. Max 10,000 rows, 30s timeout.
        """
        body: dict[str, Any] = {"tables": tables}
        if format is not None:
            body["format"] = format
        if sector_slug is not None:
            body["sector_slug"] = sector_slug
        if options is not None:
            body["options"] = options
        data = self._client.request("POST", "/v1/generate/quick", json=body)
        return QuickJobResponse.model_validate(data)

    def list(
        self,
        *,
        status: str | None = None,
        limit: int | None = None,
        offset: int | None = None,
    ) -> JobList:
        """List jobs with optional filtering and pagination.

        Args:
            status: Filter by status (e.g. "completed", "running")
            limit: Max jobs to return (default 20, max 100)
            offset: Pagination offset (default 0)
        """
        params: dict[str, Any] = {}
        if status is not None:
            params["status"] = status
        if limit is not None:
            params["limit"] = limit
        if offset is not None:
            params["offset"] = offset
        data = self._client.request("GET", "/v1/jobs", params=params)
        if isinstance(data, list):
            return JobList(data=[Job.model_validate(j) for j in data])
        items = data.get("data") or []
        return JobList(data=[Job.model_validate(j) for j in items])

    def get(self, job_id: str) -> Job:
        """Get a single job by ID."""
        data = self._client.request("GET", f"/v1/jobs/{job_id}")
        return Job.model_validate(data)

    def cancel(self, job_id: str) -> CancelJobResponse:
        """Cancel a queued or running job."""
        data = self._client.request("DELETE", f"/v1/jobs/{job_id}")
        return CancelJobResponse.model_validate(data)

    def stream(self, job_id: str) -> Iterator[dict[str, Any]]:
        """Stream SSE progress events for a job.

        Yields dicts with 'event' and 'data' keys.
        Events: progress, complete, error.
        """
        yield from self._client.stream_sse(f"/v1/jobs/{job_id}/stream")

    def download(self, job_id: str) -> bytes:
        """Download the output archive for a completed job as raw bytes."""
        resp = self._client.request_raw("GET", f"/v1/jobs/{job_id}/download")
        return resp.content

    def download_archive(self, job_id: str) -> JobArchive:
        """Download the output archive and return a :class:`JobArchive` for easy access.

        Usage::

            archive = client.jobs.download_archive(job_id)
            entries = archive.json("journal_entries.json")
            print(archive.files())
        """
        return JobArchive(self.download(job_id))

    def download_file(self, job_id: str, file: str) -> bytes:
        """Download a specific file from a job's output.

        Args:
            job_id: The job ID
            file: Artifact path, e.g. "journal_entries.json"
        """
        resp = self._client.request_raw("GET", f"/v1/jobs/{job_id}/download/{file}")
        return resp.content

    def download_to(self, job_id: str, path: str | Path) -> Path:
        """Download job output archive to a local file.

        Args:
            job_id: The job ID
            path: Local file path to write to

        Returns:
            The Path where the file was saved
        """
        data = self.download(job_id)
        out = Path(path)
        out.write_bytes(data)
        return out

    def wait(
        self,
        job_id: str,
        *,
        poll_interval: float = 2.0,
        timeout: float = 300.0,
    ) -> Job:
        """Poll until a job reaches a terminal state.

        Args:
            job_id: The job ID to wait on
            poll_interval: Seconds between polls (default 2)
            timeout: Max seconds to wait (default 300)

        Returns:
            The completed (or failed/cancelled) Job
        """
        deadline = time.monotonic() + timeout
        while True:
            job = self.get(job_id)
            if job.status in ("completed", "failed", "cancelled"):
                return job
            if time.monotonic() >= deadline:
                return job
            time.sleep(poll_interval)
