"""API key management resource."""

from __future__ import annotations

from typing import Any, List, Optional

from .._client import SyncClient
from .._types import ApiKey, ApiKeyCreated, RevokeKeyResponse


class ApiKeys:
    """Manage API keys."""

    def __init__(self, client: SyncClient) -> None:
        self._client = client

    def create(
        self,
        *,
        name: str,
        environment: Optional[str] = None,
    ) -> ApiKeyCreated:
        """Create a new API key.

        The full key is only returned once in the response.

        Args:
            name: Display name for the key
            environment: "live" or "test"
        """
        body: dict[str, Any] = {"name": name}
        if environment is not None:
            body["environment"] = environment
        data = self._client.request("POST", "/v1/api-keys", json=body)
        return ApiKeyCreated.model_validate(data)

    def list(self) -> List[ApiKey]:
        """List all API keys for the current account."""
        data = self._client.request("GET", "/v1/api-keys")
        if isinstance(data, dict):
            data = data.get("data") or []
        return [ApiKey.model_validate(k) for k in data]

    def get(self, key_id: str) -> ApiKey:
        """Get a single API key by ID."""
        data = self._client.request("GET", f"/v1/api-keys/{key_id}")
        return ApiKey.model_validate(data)

    def update(
        self,
        key_id: str,
        *,
        name: Optional[str] = None,
        scopes: Optional[Any] = None,
    ) -> ApiKey:
        """Update an API key's name or scopes."""
        body: dict[str, Any] = {}
        if name is not None:
            body["name"] = name
        if scopes is not None:
            body["scopes"] = scopes
        data = self._client.request("PATCH", f"/v1/api-keys/{key_id}", json=body)
        return ApiKey.model_validate(data)

    def revoke(self, key_id: str) -> RevokeKeyResponse:
        """Revoke (delete) an API key. This is irreversible."""
        data = self._client.request("DELETE", f"/v1/api-keys/{key_id}")
        return RevokeKeyResponse.model_validate(data)
