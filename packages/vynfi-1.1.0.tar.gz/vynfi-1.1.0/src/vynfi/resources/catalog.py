"""Catalog and sectors resource."""

from __future__ import annotations

from typing import Any, List, Optional

from .._client import SyncClient
from .._types import CatalogItem, Fingerprint, Sector, SectorSummary, Template


class Catalog:
    """Browse sector catalog, fingerprints, and templates."""

    def __init__(self, client: SyncClient) -> None:
        self._client = client

    def list_sectors(self) -> List[SectorSummary]:
        """List all available sectors without full table definitions."""
        data = self._client.request("GET", "/v1/sectors")
        if isinstance(data, dict):
            data = data.get("data") or []
        return [SectorSummary.model_validate(s) for s in data]

    def get_sector(self, slug: str) -> Sector:
        """Get a single sector by slug, including full table definitions."""
        data = self._client.request("GET", f"/v1/sectors/{slug}")
        return Sector.model_validate(data)

    def list(
        self,
        *,
        sector: Optional[str] = None,
        search: Optional[str] = None,
    ) -> List[CatalogItem]:
        """List catalog items, optionally filtered by sector or search term."""
        params: dict[str, Any] = {}
        if sector is not None:
            params["sector"] = sector
        if search is not None:
            params["search"] = search
        data = self._client.request("GET", "/v1/catalog", params=params)
        if isinstance(data, dict):
            data = data.get("data") or []
        return [CatalogItem.model_validate(item) for item in data]

    def get_fingerprint(self, sector: str, profile: str) -> Fingerprint:
        """Get fingerprint profile for a specific sector and profile slug."""
        data = self._client.request("GET", f"/v1/catalog/{sector}/{profile}")
        return Fingerprint.model_validate(data)

    def list_templates(self, *, sector: Optional[str] = None) -> List[Template]:
        """List system templates, optionally filtered by sector."""
        params: dict[str, Any] = {}
        if sector is not None:
            params["sector"] = sector
        data = self._client.request("GET", "/v1/templates", params=params)
        if isinstance(data, dict):
            data = data.get("templates") or data.get("data") or []
        return [Template.model_validate(t) for t in data]
