"""Multi-period generation sessions resource."""

from __future__ import annotations

from typing import Any

from .._client import SyncClient
from .._types import GenerateSessionResponse, GenerationSession


class Sessions:
    """Manage multi-period generation sessions."""

    def __init__(self, client: SyncClient) -> None:
        self._client = client

    def list(self) -> list[GenerationSession]:
        """List all generation sessions."""
        data = self._client.request("GET", "/v1/sessions")
        if isinstance(data, dict):
            data = data.get("data") or []
        return [GenerationSession.model_validate(s) for s in data]

    def create(
        self,
        *,
        name: str,
        fiscal_year_start: str,
        period_length_months: int,
        periods: int,
        generation_config: dict[str, Any],
    ) -> GenerationSession:
        """Create a new multi-period generation session.

        Args:
            name: Session display name
            fiscal_year_start: Start date, e.g. "2026-01-01"
            period_length_months: Length of each period in months
            periods: Number of periods to generate
            generation_config: Base generation config for each period
        """
        body: dict[str, Any] = {
            "name": name,
            "fiscalYearStart": fiscal_year_start,
            "periodLengthMonths": period_length_months,
            "periods": periods,
            "generationConfig": generation_config,
        }
        data = self._client.request("POST", "/v1/sessions", json=body)
        return GenerationSession.model_validate(data)

    def extend(
        self,
        session_id: str,
        *,
        additional_periods: int,
    ) -> GenerationSession:
        """Add more periods to an existing session.

        Args:
            session_id: The session ID
            additional_periods: Number of periods to add
        """
        data = self._client.request(
            "POST",
            f"/v1/sessions/{session_id}/extend",
            json={"additionalPeriods": additional_periods},
        )
        return GenerationSession.model_validate(data)

    def generate_next(self, session_id: str) -> GenerateSessionResponse:
        """Generate the next period of a session.

        Returns session state plus the new job details.
        """
        data = self._client.request("POST", f"/v1/sessions/{session_id}/generate")
        return GenerateSessionResponse.model_validate(data)
