"""Quality scores resource."""

from __future__ import annotations

from typing import Any

from .._client import SyncClient
from .._types import DailyQuality, QualityScore


class Quality:
    """Quality metrics for generated data."""

    def __init__(self, client: SyncClient) -> None:
        self._client = client

    def scores(self) -> list[QualityScore]:
        """Get quality scores for recent generation jobs."""
        data = self._client.request("GET", "/v1/quality/scores")
        if isinstance(data, dict):
            data = data.get("data") or []
        return [QualityScore.model_validate(s) for s in data]

    def timeline(self, *, days: int | None = None) -> list[DailyQuality]:
        """Get daily aggregate quality scores over time.

        Args:
            days: Number of days to look back (default 30, max 365)
        """
        params: dict[str, Any] = {}
        if days is not None:
            params["days"] = days
        data = self._client.request("GET", "/v1/quality/timeline", params=params)
        if isinstance(data, dict):
            data = data.get("data") or []
        return [DailyQuality.model_validate(d) for d in data]
