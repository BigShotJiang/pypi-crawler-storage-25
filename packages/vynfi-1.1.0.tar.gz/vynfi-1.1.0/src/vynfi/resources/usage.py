"""Usage analytics resource."""

from __future__ import annotations

from typing import Any

from .._client import SyncClient
from .._types import DailyUsageResponse, UsageSummary


class Usage:
    """Credit usage analytics."""

    def __init__(self, client: SyncClient) -> None:
        self._client = client

    def summary(self, *, days: int | None = None) -> UsageSummary:
        """Get current credit usage summary (balance, totals, burn rate).

        Args:
            days: Number of days to look back (server default if omitted)
        """
        params: dict[str, Any] = {}
        if days is not None:
            params["days"] = days
        data = self._client.request("GET", "/v1/usage/summary", params=params)
        return UsageSummary.model_validate(data)

    def daily(self, *, days: int | None = None) -> DailyUsageResponse:
        """Get daily credit usage breakdown.

        Args:
            days: Number of days to look back (server default if omitted)
        """
        params: dict[str, Any] = {}
        if days is not None:
            params["days"] = days
        data = self._client.request("GET", "/v1/usage/daily", params=params)
        return DailyUsageResponse.model_validate(data)
