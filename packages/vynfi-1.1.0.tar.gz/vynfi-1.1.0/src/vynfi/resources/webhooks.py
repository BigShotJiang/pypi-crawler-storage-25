"""Webhook management resource."""

from __future__ import annotations

from typing import Any, List, Optional

from .._client import SyncClient
from .._types import Webhook, WebhookCreated, WebhookDetail


class Webhooks:
    """Manage webhooks."""

    def __init__(self, client: SyncClient) -> None:
        self._client = client

    def create(self, *, url: str, events: List[str]) -> WebhookCreated:
        """Create a new webhook. The signing secret is only returned once.

        Args:
            url: HTTPS endpoint URL
            events: Event types to subscribe to
        """
        data = self._client.request("POST", "/v1/webhooks", json={"url": url, "events": events})
        return WebhookCreated.model_validate(data)

    def list(self) -> List[Webhook]:
        """List all webhooks for the current account."""
        data = self._client.request("GET", "/v1/webhooks")
        if isinstance(data, dict):
            data = data.get("data") or []
        return [Webhook.model_validate(w) for w in data]

    def get(self, webhook_id: str) -> WebhookDetail:
        """Get a single webhook by ID, including recent delivery history."""
        data = self._client.request("GET", f"/v1/webhooks/{webhook_id}")
        return WebhookDetail.model_validate(data)

    def update(
        self,
        webhook_id: str,
        *,
        url: Optional[str] = None,
        events: Optional[List[str]] = None,
        status: Optional[str] = None,
    ) -> Webhook:
        """Update a webhook's URL, events, or status."""
        body: dict[str, Any] = {}
        if url is not None:
            body["url"] = url
        if events is not None:
            body["events"] = events
        if status is not None:
            body["status"] = status
        data = self._client.request("PATCH", f"/v1/webhooks/{webhook_id}", json=body)
        return Webhook.model_validate(data)

    def delete(self, webhook_id: str) -> None:
        """Delete a webhook. This is irreversible."""
        self._client.request("DELETE", f"/v1/webhooks/{webhook_id}")

    def test(self, webhook_id: str) -> Any:
        """Send a test event to a webhook."""
        return self._client.request("POST", f"/v1/webhooks/{webhook_id}/test")
