"""What-if scenarios resource."""

from __future__ import annotations

from typing import Any, List

from .._client import SyncClient
from .._types import Scenario, ScenarioTemplate


class Scenarios:
    """Manage what-if scenarios."""

    def __init__(self, client: SyncClient) -> None:
        self._client = client

    def list(self) -> List[Scenario]:
        """List all scenarios."""
        data = self._client.request("GET", "/v1/scenarios")
        if isinstance(data, dict):
            data = data.get("data") or []
        return [Scenario.model_validate(s) for s in data]

    def create(
        self,
        *,
        name: str,
        template_id: str,
        interventions: dict[str, Any],
        generation_config: dict[str, Any],
    ) -> Scenario:
        """Create a new what-if scenario.

        Args:
            name: Scenario display name
            template_id: Causal graph template ID
            interventions: Intervention parameters (e.g. {"fraudRate": 0.05})
            generation_config: Base generation config
        """
        body: dict[str, Any] = {
            "name": name,
            "templateId": template_id,
            "interventions": interventions,
            "generationConfig": generation_config,
        }
        data = self._client.request("POST", "/v1/scenarios", json=body)
        return Scenario.model_validate(data)

    def run(self, scenario_id: str) -> Scenario:
        """Run a scenario, creating baseline and counterfactual generation jobs."""
        data = self._client.request("POST", f"/v1/scenarios/{scenario_id}/run")
        return Scenario.model_validate(data)

    def diff(self, scenario_id: str) -> Scenario:
        """Get diff analysis between baseline and counterfactual results."""
        data = self._client.request("GET", f"/v1/scenarios/{scenario_id}/diff")
        return Scenario.model_validate(data)

    def templates(self) -> List[ScenarioTemplate]:
        """List available scenario templates (causal graphs)."""
        data = self._client.request("GET", "/v1/scenarios/templates")
        if isinstance(data, dict):
            data = data.get("data") or []
        return [ScenarioTemplate.model_validate(t) for t in data]
