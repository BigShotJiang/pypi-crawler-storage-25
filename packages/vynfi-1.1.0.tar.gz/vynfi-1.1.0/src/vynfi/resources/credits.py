"""Prepaid credits resource."""

from __future__ import annotations

from .._client import SyncClient
from .._types import PrepaidBalanceResponse, PrepaidHistoryResponse, PurchaseCreditsResponse


class Credits:
    """Manage prepaid credit packs."""

    def __init__(self, client: SyncClient) -> None:
        self._client = client

    def purchase(self, *, pack: str) -> PurchaseCreditsResponse:
        """Purchase a prepaid credit pack.

        Args:
            pack: Pack size — "10k", "50k", "100k", "500k", or "1m"
        """
        data = self._client.request("POST", "/v1/credits/purchase", json={"pack": pack})
        return PurchaseCreditsResponse.model_validate(data)

    def balance(self) -> PrepaidBalanceResponse:
        """Get current prepaid credit balance and active batches."""
        data = self._client.request("GET", "/v1/credits/balance")
        return PrepaidBalanceResponse.model_validate(data)

    def history(self) -> PrepaidHistoryResponse:
        """Get full prepaid credit history including expired batches."""
        data = self._client.request("GET", "/v1/credits/history")
        return PrepaidHistoryResponse.model_validate(data)
