"""Notifications resource."""

from __future__ import annotations

from typing import Any, List, Optional

from .._client import SyncClient
from .._types import Notification


class Notifications:
    """Manage user notifications."""

    def __init__(self, client: SyncClient) -> None:
        self._client = client

    def list(
        self,
        *,
        unread: bool | None = None,
        limit: int | None = None,
    ) -> List[Notification]:
        """List notifications with optional filtering.

        Args:
            unread: If True, only return unread notifications
            limit: Max notifications to return
        """
        params: dict[str, Any] = {}
        if unread is not None:
            params["unread"] = unread
        if limit is not None:
            params["limit"] = limit
        data = self._client.request("GET", "/v1/notifications", params=params)
        if isinstance(data, dict):
            data = data.get("data") or []
        return [Notification.model_validate(n) for n in data]

    def mark_read(
        self,
        *,
        ids: Optional[List[str]] = None,
        all: Optional[bool] = None,
    ) -> None:
        """Mark notifications as read.

        Args:
            ids: Specific notification IDs to mark as read
            all: If True, mark all notifications as read
        """
        body: dict[str, Any] = {}
        if ids is not None:
            body["ids"] = ids
        if all is not None:
            body["all"] = all
        self._client.request("POST", "/v1/notifications/mark-read", json=body)
