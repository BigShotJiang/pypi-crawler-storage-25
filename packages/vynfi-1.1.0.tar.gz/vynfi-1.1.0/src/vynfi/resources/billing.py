"""Billing resource."""

from __future__ import annotations

from typing import Any

from .._client import SyncClient
from .._types import CheckoutResponse, Invoice, PortalResponse, Subscription


class Billing:
    """Billing, subscription, and invoices."""

    def __init__(self, client: SyncClient) -> None:
        self._client = client

    def subscription(self) -> Subscription:
        """Get current subscription details (tier, status, period end)."""
        data = self._client.request("GET", "/v1/billing/subscription")
        return Subscription.model_validate(data)

    def checkout(self, *, price_id: str) -> CheckoutResponse:
        """Create a Stripe checkout session to subscribe to a plan.

        Args:
            price_id: Stripe price ID for the plan
        """
        data = self._client.request("POST", "/v1/billing/checkout", json={"price_id": price_id})
        return CheckoutResponse.model_validate(data)

    def portal(self) -> PortalResponse:
        """Create a Stripe billing portal session for managing payment methods and invoices."""
        data = self._client.request("POST", "/v1/billing/portal")
        return PortalResponse.model_validate(data)

    def invoices(self) -> list[Invoice]:
        """List all invoices for the current account."""
        data = self._client.request("GET", "/v1/billing/invoices")
        if isinstance(data, dict):
            data = data.get("data") or []
        return [Invoice.model_validate(i) for i in data]

    def payment_method(self) -> Any:
        """Get payment method on file."""
        return self._client.request("GET", "/v1/billing/payment-method")
