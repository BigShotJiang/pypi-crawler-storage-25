# Changelog

All notable changes to the VynFi Python SDK are documented here.

## [1.1.0] - 2026-04-11

### Added

- **`JobArchive` class** -- wraps downloaded zip archives for easy file access: `archive.json()`, `archive.files()`, `archive.categories()`, `archive.find()`, `archive.summary()`, `archive.extract_to()`
- **`Jobs.download_archive()`** -- returns a `JobArchive` instead of raw bytes
- **`archive_to_dataframes()`** in pandas integration -- converts all JSON files in an archive to a dict of DataFrames in one call, with automatic header/lines flattening for journal entries
- **7 Jupyter notebooks** -- quickstart, audit analytics, fraud detection, document flow audit trail, process mining, ESG reporting, AML compliance testing
- **7 standalone scripts** -- quickstart, streaming progress, pandas workflow, config management, multi-period sessions, what-if scenarios, quality monitoring
- **Examples README** with sample output figures and key metrics from live testing

### Fixed

- **Config endpoints** used wrong URL path: `/v1/configs/validate` -> `/v1/config/validate`, `/v1/configs/estimate-cost` -> `/v1/config/estimate-cost`, `/v1/configs/compose` -> `/v1/config/compose` (singular, matching Rust SDK reference)
- **Sessions `generate_next()`** used wrong URL path: `/v1/sessions/{id}/generate-next` -> `/v1/sessions/{id}/generate` (matching Rust SDK reference)

## [1.0.0] - 2026-04-10

First stable release. Full API parity with the VynFi Rust SDK reference implementation.

### Added

- **Configs resource** — save, list, get, update, delete generation configs; validate configs, estimate cost, and compose from layers
- **Credits resource** — purchase prepaid credit packs, check balance, view history
- **Sessions resource** — create multi-period generation sessions, extend, and generate each period sequentially
- **Scenarios resource** — create what-if scenarios with causal graph templates, run baseline vs counterfactual, get diff analysis
- **Notifications resource** — list and mark-read user notifications
- **Catalog templates** — `catalog.list_templates()` for browsing system generation templates
- **Billing checkout & portal** — `billing.checkout()` and `billing.portal()` for Stripe integration
- **Jobs enhancements** — `generate_config()` for config-based generation, `download_file()` for specific artifacts, `wait()` for polling convenience, `download()` returns bytes directly
- **ForbiddenError** (403) exception type
- **QuickJobResponse** and **CancelJobResponse** dedicated return types
- **WebhookDetail** with delivery history
- **RevokeKeyResponse** return type for API key revocation
- **pandas integration** (`vynfi.integrations.pandas`) — `download_dataframe()`, `job_to_dataframe()`, `usage_to_dataframe()`, `quality_to_dataframe()`
- **polars integration** (`vynfi.integrations.polars`) — `download_frame()`, `job_to_frame()`, `usage_to_frame()`, `quality_to_frame()`
- Optional dependency groups: `pip install vynfi[pandas]`, `vynfi[polars]`, `vynfi[all]`

### Changed

- **Version bumped to 1.0.0** (production-stable)
- **Job model** updated to match live API: `owner_id`, `config`, `artifacts`, `error_detail` fields; removed legacy `tables`, `format`, `sector_slug`, `output_path`, `error` fields
- **JobList** uses `data` field (was `jobs`) to match API response shape
- **Sector/SectorSummary/CatalogItem** now include `id`, `multiplier`, `quality_score` (int), `popularity` fields
- **Column** now includes `example_values`
- **TableDef** now includes `id`, `slug`
- **Fingerprint** model restructured: `sector` (value) + `table` (TableDef)
- **ApiKey/ApiKeyCreated** use `environment` field (was `scopes`/`expires_in_days`)
- **UsageSummary.burn_rate** is `int` (was `float`)
- **DailyUsageResponse.by_table** is `list[TableUsage]` (was `dict`)
- **Invoice** fields updated to match Stripe format (`amount_due`, `amount_paid`, `number`, `created`, `hosted_invoice_url`, `pdf`)
- **Subscription** now includes `stripe_price_id`
- **Billing.payment_method()** returns raw JSON (was `PaymentMethod` model)
- **Jobs.download()** returns `bytes` (was file-path based); use `download_to()` for file output
- Development status classifier: Alpha → Production/Stable

### Removed

- `PaymentMethod` model (API returns raw JSON)
- Legacy `JobProgress` model (job progress is now untyped `Any` matching API)

## [0.1.0] - 2026-04-09

Initial alpha release with 7 resource modules: jobs, catalog, usage, api_keys, quality, webhooks, billing.
