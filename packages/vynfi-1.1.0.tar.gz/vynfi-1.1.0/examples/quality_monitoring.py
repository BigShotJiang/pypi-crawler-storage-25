"""VynFi Quality — monitor data quality scores across generation jobs."""

import os

import vynfi

client = vynfi.VynFi(api_key=os.environ["VYNFI_API_KEY"])

# ── Quality scores for recent jobs ──────────────────────────────────────────
#
# VynFi computes quality scores for each generation job:
# - overall_score: Composite quality metric (0-100)
# - benford_score: How well leading digit distribution matches Benford's Law
# - correlation_score: Statistical correlation quality between related fields
# - distribution_score: How realistic the data distributions are

print("=== Quality Scores ===")
scores = client.quality.scores()
if scores:
    for s in scores:
        print(f"  Job {s.job_id}:")
        print(f"    Overall: {s.overall_score}")
        print(f"    Benford: {s.benford_score}")
        print(f"    Correlation: {s.correlation_score}")
        print(f"    Distribution: {s.distribution_score}")
        print(f"    Table: {s.table_type}, Rows: {s.rows}")
        print()
else:
    print("  No quality scores yet — generate some data first!")

# ── Quality timeline ────────────────────────────────────────────────────────
#
# Track quality trends over time (useful for regression testing).

print("=== Quality Timeline (30 days) ===")
timeline = client.quality.timeline(days=30)
if timeline:
    for day in timeline:
        bar = "#" * int(day.score / 5) if day.score else ""
        print(f"  {day.date}: {day.score:5.1f} {bar}")
else:
    print("  No timeline data yet.")

# ── Quality as DataFrame ────────────────────────────────────────────────────

try:
    from vynfi.integrations.pandas import quality_to_dataframe

    df = quality_to_dataframe(client)
    if not df.empty:
        print(f"\n=== Quality DataFrame ===")
        print(f"  Shape: {df.shape}")
        print(f"  Mean overall score: {df['overall_score'].mean():.1f}")
        print(f"  Min overall score: {df['overall_score'].min():.1f}")
except ImportError:
    print("\n  (Install pandas for DataFrame support: pip install vynfi[pandas])")

# ── Inline quality check from archive ────────────────────────────────────────
#
# Each archive also includes data_quality_stats.json and balance_validation.json

print("\n=== Inline Quality from Latest Job ===")
jobs = client.jobs.list(status="completed", limit=1)
if jobs.data:
    archive = client.jobs.download_archive(jobs.data[0].id)

    # Data quality stats embedded in the archive
    try:
        stats = archive.json("data_quality_stats.json")
        print(f"  Data quality stats: {stats}")
    except KeyError:
        print("  No data_quality_stats.json in archive")

    # Balance validation
    try:
        validation = archive.json("balance_validation.json")
        print(f"  Balance validation: {validation}")
    except KeyError:
        print("  No balance_validation.json in archive")
