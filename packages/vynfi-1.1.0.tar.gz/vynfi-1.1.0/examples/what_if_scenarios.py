"""VynFi Scenarios — what-if analysis with causal counterfactuals."""

import json
import os

import vynfi

client = vynfi.VynFi(api_key=os.environ["VYNFI_API_KEY"])

# ── Browse scenario templates ────────────────────────────────────────────────
#
# Scenario templates define causal DAGs — directed acyclic graphs that model
# how financial variables interact. You intervene on specific nodes to see
# how changes propagate through the system.

print("=== Scenario Templates ===")
templates = client.scenarios.templates()
for t in templates:
    print(f"  {t.name} ({t.node_count} nodes)")
    if t.description:
        print(f"    {t.description[:100]}")
    if t.intervention_types:
        print(f"    Intervention types: {t.intervention_types}")
    print()

# ── Create a what-if scenario ────────────────────────────────────────────────
#
# Example: "What if we increase transaction volume by 30%?"
# The scenario engine generates:
#   1. A baseline dataset (current state)
#   2. A counterfactual dataset (with the intervention applied)
# Then computes the diff between them.

if templates:
    template = templates[0]
    print(f"Creating scenario using template: {template.name}")

    scenario = client.scenarios.create(
        name="Volume Spike +30%",
        template_id=template.id,
        interventions=[
            {
                "node": "transaction_volume",
                "type": "multiply",
                "value": 1.3,
            }
        ],
        generation_config={
            "sector": "retail",
            "country": "US",
            "accountingFramework": "us_gaap",
            "rows": 1000,
            "companies": 5,
            "periods": 3,
            "periodLength": "monthly",
            "processModels": ["o2c", "p2p"],
            "exportFormat": "json",
        },
    )
    print(f"  Scenario: {scenario.id}")
    print(f"  Status: {scenario.status}")
    print()

    # ── Run the scenario ─────────────────────────────────────────────────────

    print("Running scenario (generates baseline + counterfactual)...")
    running = client.scenarios.run(scenario.id)
    print(f"  Baseline job: {running.baseline_job_id}")
    print(f"  Counterfactual job: {running.counterfactual_job_id}")

    # Wait for both jobs
    if running.baseline_job_id:
        print("  Waiting for baseline...")
        client.jobs.wait(running.baseline_job_id)
    if running.counterfactual_job_id:
        print("  Waiting for counterfactual...")
        client.jobs.wait(running.counterfactual_job_id)

    # ── Get the diff ─────────────────────────────────────────────────────────

    print("\nFetching scenario diff...")
    diffed = client.scenarios.diff(scenario.id)
    if diffed.diff:
        print(f"  Diff analysis:")
        print(f"  {json.dumps(diffed.diff, indent=2)}")

# ── List all scenarios ───────────────────────────────────────────────────────

print("\n=== All Scenarios ===")
scenarios = client.scenarios.list()
for s in scenarios:
    print(f"  {s.name} ({s.status})")
