"""VynFi Sessions — generate coherent multi-period financial data."""

import os

import vynfi

client = vynfi.VynFi(api_key=os.environ["VYNFI_API_KEY"])

# ── Create a multi-period session ────────────────────────────────────────────
#
# Sessions ensure data continuity across periods:
# - Opening balances carry forward from the previous period
# - Entity IDs remain consistent
# - Trends evolve naturally over time

print("Creating quarterly reporting session...")
session = client.sessions.create(
    name="FY2024 Quarterly Reports",
    fiscal_year_start="2024-01-01",
    period_length_months=3,
    periods=4,
    generation_config={
        "sector": "retail",
        "country": "US",
        "accountingFramework": "us_gaap",
        "rows": 1000,
        "companies": 5,
        "processModels": ["o2c", "p2p"],
        "exportFormat": "json",
        "fraudPacks": [],
        "fraudRate": 0.0,
    },
)
print(f"Session: {session.id}")
print(f"  Name: {session.name}")
print(f"  Status: {session.status}")
print(f"  Periods: {session.periods_generated}/{session.periods_total}")

# ── Generate periods one at a time ───────────────────────────────────────────
#
# Each call to generate_next() produces the next period in sequence.
# The API ensures continuity with the previous period's closing balances.

for i in range(min(2, session.periods_total)):  # Generate first 2 quarters
    print(f"\nGenerating Q{i + 1} 2024...")
    result = client.sessions.generate_next(session.id)
    print(f"  Job: {result.job_id}")
    print(f"  Period: {result.period_start} to {result.period_end}")
    print(f"  Credits reserved: {result.credits_reserved}")

    # Wait for the job to complete
    job = client.jobs.wait(result.job_id)
    print(f"  Status: {job.status}")

    if job.status == "completed":
        archive = client.jobs.download_archive(job.id)
        print(f"  Archive: {archive}")

# ── Check session status ─────────────────────────────────────────────────────

print("\n=== Session Status ===")
sessions = client.sessions.list()
for s in sessions:
    print(f"  {s.name}: {s.periods_generated}/{s.periods_total} periods ({s.status})")

# ── Extend a session ─────────────────────────────────────────────────────────
#
# Need more periods? Extend the session without starting over.

print(f"\nExtending session by 2 additional periods...")
extended = client.sessions.extend(session.id, additional_periods=2)
print(f"  New total: {extended.periods_total} periods")
