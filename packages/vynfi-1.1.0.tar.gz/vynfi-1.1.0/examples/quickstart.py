"""VynFi Quickstart — generate synthetic financial data in 10 lines of code."""

import os

import vynfi

# Initialize client
client = vynfi.VynFi(api_key=os.environ["VYNFI_API_KEY"])

# Browse available sectors
sectors = client.catalog.list_sectors()
for s in sectors:
    print(f"  {s.slug}: {s.name} ({s.table_count} tables, quality: {s.quality_score})")

# Generate a small retail dataset (synchronous — max 10k rows)
result = client.generate_quick(
    tables=[{"name": "journal-entries", "rows": 100}],
    sector_slug="retail",
    format="json",
)
print(f"\nJob {result.id}: {result.status} ({result.credits_used} credits)")

# Download and explore the archive
archive = client.jobs.download_archive(result.id)
print(f"\nArchive: {archive}")
print(f"Categories: {archive.categories()}")

# Read journal entries
entries = archive.json("journal_entries.json")
print(f"\n{len(entries)} journal entries generated")
print(f"First entry document type: {entries[0]['header']['document_type']}")
print(f"First entry has {len(entries[0]['lines'])} line items")

# Check credit balance
usage = client.usage.summary()
print(f"\nCredit balance: {usage.balance} (burn rate: {usage.burn_rate}/day)")
