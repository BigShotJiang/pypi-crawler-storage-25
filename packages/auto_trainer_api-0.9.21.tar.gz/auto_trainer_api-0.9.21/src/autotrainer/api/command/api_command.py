from enum import IntEnum


class ApiCommand(IntEnum):
    """
    A command value is required for all command requests.
    """
    NONE = 0
    """No command.  Can be used to verify connection or that the receiver is configured to receive commands."""

    START_ACQUISITION = 50
    """ Obsolete"""

    STOP_ACQUISITION = 55
    """ Obsolete"""

    SET_APPLICATION_MODE = 120
    """
    Payload: {mode: ApiApplicationMode}
    The response is application mode after attempting to set.  Typically the same as the payload, but if for some reason
    the mode is invalid in the current context, it should return the actual mode.
    Response Payload: {mode: ApiApplicationMode}
    """

    SET_TRAINING_MODE = 130
    """
    Payload: {mode: ApiTrainingMode}
    The response is training mode after attempting to set.  Typically the same as the payload, but if for some reason
    the mode is invalid in the current context, it should return the actual mode.
    Response Payload: {mode: ApiTrainingMode}
    """

    EMERGENCY_STOP = 200
    """Response Payload: None"""

    EMERGENCY_RESUME = 210
    """Response Payload: None"""

    GET_CONFIGURATION = 300
    """Response Payload: ApiSystemConfiguration"""

    GET_STATUS = 400
    """Response Payload: ApiSystemStatus"""

    GET_ANIMALS = 500
    """Response Payload: List[ApiAnimalStatus]"""

    USER_DEFINED = 99999
    """A custom command defined between a particular commander and receiver.  Additional information can be 
    defined in the `data` field."""

    @classmethod
    def is_member(cls, value):
        return value in cls._value2member_map_
