"""
Create an instance of an Api Service implementation to received published messages and send command requests.
"""
import datetime
import logging
import math
import time
from dataclasses import asdict, replace
from pathlib import Path
from threading import Timer
from typing import Optional, Mapping, Any

from autotrainer.api import create_api_service, create_default_api_options, ApiCommandRequest, ApiCommandRequestResult, \
    ApiCommandRequestResponse
from autotrainer.api import ApiCommand
from autotrainer.api import ApiEventKind
from autotrainer.api import ApiTrainingMode, ApiApplicationMode, ApiTunnelDeviceStatus, ApiPelletDeviceStatus, \
    ApiSystemConfiguration, ApiSystemStatus, ApiDetectorStatus, ApiDetectorKind, ApiAlarmStatus, ApiAlarmKind
from autotrainer.api.api_event import ApiEventDict
from autotrainer.api.api_system_status import ApiProjectStatus, ApiBehaviorStatus, ApiReachStatus
from autotrainer.api.util import resolve_enum


def create_event_dict(kind: ApiEventKind, data: Optional[Mapping[str, Any]]) -> ApiEventDict:
    return {"kind": kind, "when": datetime.datetime.now(), "index": time.perf_counter_ns(), "context": data}


class ClientApplication:
    """
    Acts as a proxy or example for applications like the acquisition app that posts events and responds to remote rpc
    commands.
    """
    STATUS_INTERVAL = 30

    def __init__(self, root_location: Path):
        self._version = "2.0.1"
        self._identifier = "agx999"
        self._update_root_location(root_location)

        self._configuration = ApiSystemConfiguration(self._version, self._identifier, str(self._configuration_location),
                                                     str(self._data_location), str(self._animals_location),
                                                     str(self._logs_location), str(self._inference_model_location)
                                                     )

        self._status = ApiSystemStatus(application_mode=ApiApplicationMode.IDLE, training_mode=ApiTrainingMode.MANUAL,
                                       animal=None, alarms=[],
                                       detectors=[ApiDetectorStatus(ApiDetectorKind.frontDoor, False, True)],
                                       tunnel_device=ApiTunnelDeviceStatus(0.0, True),
                                       pellet_device=ApiPelletDeviceStatus(math.nan, 1.0, 2.3, 3, 4, 5, 50, 100),
                                       behavior=ApiBehaviorStatus(20.5, ApiReachStatus(1, 2, 3, 4)),
                                       project=ApiProjectStatus("day_path", 1)
                                       )

        self._service = None
        self._status_timer = None
        self._running = False

    def _update_root_location(self, location: Path):
        self._root_location = location
        self._configuration_location = Path.joinpath(self._root_location, "Autotrainer")
        self._data_location = Path.joinpath(self._root_location, "Documents")
        self._animals_location = Path.joinpath(self._configuration_location, "animals")
        self._logs_location = Path.joinpath(self._root_location, "Documents", "logs")
        self._inference_model_location = Path.joinpath(self._configuration_location, "inference_model")

    def _respond_to_command_request(self, request: ApiCommandRequest) -> ApiCommandRequestResponse:
        logger.debug("Received command request: %s", request.command)

        if request.command == ApiCommand.GET_CONFIGURATION:
            return ApiCommandRequestResponse(result=ApiCommandRequestResult.SUCCESS, data=self._configuration)
        elif request.command == ApiCommand.GET_STATUS:
            return ApiCommandRequestResponse(result=ApiCommandRequestResult.SUCCESS, data=self._status,
                                             error_message="This is an error message")

        return ApiCommandRequestResponse(result=ApiCommandRequestResult.SUCCESS, data={"seen": True})

    def _send_status(self):
        if self._service is not None and self._running:
            self._service.send_event_dict(
                create_event_dict(ApiEventKind.systemStatus, asdict(self._status))
            )
            self._queue_status_timer()

    def _queue_status_timer(self):
        if self._running:
            self._status_timer = Timer(self.STATUS_INTERVAL, self._send_status)
            self._status_timer.daemon = True
            self._status_timer.start()

    def _cancel_status_timer(self):
        if self._status_timer is not None:
            self._status_timer.cancel()
            self._status_timer = None

    def _update_status_list(self, item, id_attr: str, list_attr: str, event_kind: ApiEventKind):
        current_list = getattr(self._status, list_attr)
        item_id = getattr(item, id_attr)
        updated = [x for x in current_list if getattr(x, id_attr) != item_id]
        updated.append(item)
        self._status = replace(self._status, **{list_attr: updated})
        self._service.send_event_dict(create_event_dict(event_kind, asdict(item)))
        logger.info("Updated %s: %s", list_attr, item)

    def run(self):
        options = create_default_api_options()

        self._service = create_api_service(options)

        if self._service is None:
            logger.error("failed to create API service")
            return

        self._service.command_request_delegate = self._respond_to_command_request
        self._service.start()
        self._running = True

        self._queue_status_timer()

        last_command = ""

        while True:
            line = ""
            while len(line) == 0:
                line = input(f"Enter event (?=help, enter='{last_command}'): ")
                if len(line) == 0 and len(last_command) != 0:
                    break

            if len(line) == 0:
                line = last_command
            else:
                last_command = line

            argv = line.split()

            if len(argv) == 0:
                print("empty event, please type a event or ?")
                continue

            cmd = argv[0]
            params = argv[1:]

            try:
                if cmd == "?":
                    print("No help available")

                elif cmd == "q" or cmd == "quit":
                    break

                elif cmd == "app_launch":
                    self._service.send_event_dict(create_event_dict(ApiEventKind.applicationLaunched, None))

                elif cmd == "e_stop":
                    self._service.send_event_dict(create_event_dict(ApiEventKind.emergencyStop, {"reason": "user"}))

                elif cmd == "e_resume":
                    self._service.send_event_dict(create_event_dict(ApiEventKind.emergencyResume, {"reason": "user"}))

                elif cmd == "d" or cmd == "detector":
                    if len(params) != 2:
                        print("Usage: detector <detector_id> <is_active>")
                        continue

                    detector = ApiDetectorStatus(
                        detector_id=resolve_enum(ApiDetectorKind, params[0]),
                        is_active=params[1].lower() == "true",
                        is_enabled=True
                    )
                    self._update_status_list(detector, "detector_id", "detectors", ApiEventKind.detectorChanged)

                elif cmd == "a" or cmd == "alarm":
                    if len(params) != 3:
                        print("Usage: alarm <alarm_id> <is_active> <is_enabled>")
                        continue

                    alarm = ApiAlarmStatus(
                        alarm_id=resolve_enum(ApiAlarmKind, params[0]),
                        is_active=params[1].lower() == "true",
                        is_enabled=params[2].lower() == "true"
                    )
                    self._update_status_list(alarm, "alarm_id", "alarms", ApiEventKind.alarmChanged)

                elif cmd == "magnet":
                    if len(params) != 1:
                        print("Usage: magnet <intensity 0.0-100.0>")
                        continue

                    value = float(params[0])
                    if not 0.0 <= value <= 100.0:
                        print("Value must be between 0.0 and 100.0")
                        continue

                    self._status = replace(self._status,
                                           tunnel_device=replace(self._status.tunnel_device, magnet_intensity=value))
                    logger.info("Updated magnet_intensity: %s", value)

                elif cmd == "baseline":
                    if len(params) != 1:
                        print("Usage: baseline <intensity 0.0-100.0>")
                        continue

                    value = float(params[0])
                    if not 0.0 <= value <= 100.0:
                        print("Value must be between 0.0 and 100.0")
                        continue

                    self._status = replace(self._status,
                                           behavior=replace(self._status.behavior, baseline_magnet_intensity=value))
                    self._service.send_event_dict(
                        create_event_dict(ApiEventKind.headfixBaselineChanged, {"baseline": value})
                    )
                    logger.info("Updated baseline_magnet_intensity: %s", value)

                else:
                    logger.warning("Unknown event: %s", cmd)

            except Exception as err:
                logger.exception("Error: %s", err)

        self._running = False
        self._cancel_status_timer()
        self._service.stop()


if __name__ == '__main__':
    logging.basicConfig(level=logging.DEBUG, format="%(asctime)s %(levelname)s\t [%(name)s] %(message)s")
    logging.getLogger('autotrainer').setLevel(logging.DEBUG)
    logging.getLogger('tools').setLevel(logging.DEBUG)

    logger = logging.getLogger(__name__)

    ClientApplication(Path("/home/autotrainer")).run()
