import json

from autotrainer.api import create_api_service, create_default_api_options, ApiCommand, ApiCommandRequest, \
    ApiCommandRequestResult
from autotrainer.api.api_options import ApiOptions, RpcOptions
from autotrainer.api.rpc_service import (
    ApiCommandRequestErrorKind,
    _ApiCommandRequestServiceResponse,
)


class TestCreateAndRunService:
    """Verify the service can be created, started, and stopped without errors."""

    def test_create_service_with_defaults(self):
        options = create_default_api_options()
        service = create_api_service(options)
        assert service is not None

    def test_create_service_disabled(self):
        options = ApiOptions(rpc=RpcOptions(enable=False))
        service = create_api_service(options)
        assert service is None

    def test_start_and_stop_service(self):
        options = ApiOptions(rpc=RpcOptions(enable=True, subscriber_port=15556, command_port=15557))
        service = create_api_service(options)
        assert service is not None
        service.start()
        service.stop()


class TestApiCommandRequestServiceResponseAsBytes:
    """Verify _ApiCommandRequestServiceResponse.as_bytes() produces valid camelized JSON bytes."""

    def test_as_bytes_basic(self):
        response = _ApiCommandRequestServiceResponse(
            nonce=1,
            command=ApiCommand.GET_STATUS,
            result=ApiCommandRequestResult.SUCCESS,
        )
        raw = response.as_bytes()
        assert isinstance(raw, bytes)

        parsed = json.loads(raw.decode("utf8"))
        assert parsed["nonce"] == 1
        assert parsed["command"] == ApiCommand.GET_STATUS
        assert parsed["result"] == ApiCommandRequestResult.SUCCESS

    def test_as_bytes_with_data(self):
        response = _ApiCommandRequestServiceResponse(
            nonce=42,
            command=ApiCommand.GET_CONFIGURATION,
            result=ApiCommandRequestResult.SUCCESS,
            data={"some_key": "some_value"},
        )
        raw = response.as_bytes()
        parsed = json.loads(raw.decode("utf8"))
        assert parsed["nonce"] == 42
        assert parsed["data"] is not None

    def test_as_bytes_keys_are_camelized(self):
        response = _ApiCommandRequestServiceResponse(
            nonce=1,
            command=ApiCommand.NONE,
            error_kind=ApiCommandRequestErrorKind.COMMAND_ERROR,
            error_code=123,
            error_message="something broke",
        )
        raw = response.as_bytes()
        parsed = json.loads(raw.decode("utf8"))
        assert "errorKind" in parsed
        assert "errorCode" in parsed
        assert "errorMessage" in parsed

    def test_for_exception(self):
        response = _ApiCommandRequestServiceResponse.for_exception(
            command=ApiCommand.EMERGENCY_STOP,
            nonce=7,
            ex=ValueError("test error"),
        )
        assert response.result == ApiCommandRequestResult.EXCEPTION
        assert response.error_message == "test error"

        raw = response.as_bytes()
        assert isinstance(raw, bytes)


class TestApiCommandEnumMembers:
    """Verify all ApiCommand enum members exist and have expected values."""

    def test_set_application_mode(self):
        assert ApiCommand.SET_APPLICATION_MODE == 120
        assert ApiCommand.is_member(120)

    def test_set_training_mode(self):
        assert ApiCommand.SET_TRAINING_MODE == 130
        assert ApiCommand.is_member(130)

    def test_get_animals(self):
        assert ApiCommand.GET_ANIMALS == 500
        assert ApiCommand.is_member(500)

    def test_obsolete_acquisition_values_not_members(self):
        assert not ApiCommand.is_member(100)
        assert not ApiCommand.is_member(110)


class TestApiCommandRequestParseObject:
    """Verify ApiCommandRequest.parse_object() parses dicts correctly."""

    def test_parse_known_command(self):
        obj = {"command": ApiCommand.GET_STATUS, "nonce": 5}
        result = ApiCommandRequest.parse_object(obj)
        assert result is not None
        assert result.command == ApiCommand.GET_STATUS
        assert result.nonce == 5
        assert result.custom_command == -1
        assert result.data is None

    def test_parse_with_data(self):
        obj = {"command": ApiCommand.SET_APPLICATION_MODE, "nonce": 1, "data": {"key": "value"}}
        result = ApiCommandRequest.parse_object(obj)
        assert result is not None
        assert result.data == {"key": "value"}

    def test_parse_unknown_command_falls_back_to_user_defined(self):
        obj = {"command": 77777, "nonce": 3}
        result = ApiCommandRequest.parse_object(obj)
        assert result is not None
        assert result.command == ApiCommand.USER_DEFINED

    def test_parse_missing_command_returns_none(self):
        obj = {"nonce": 1, "data": {}}
        result = ApiCommandRequest.parse_object(obj)
        assert result is None

    def test_parse_defaults_nonce_to_zero(self):
        obj = {"command": ApiCommand.NONE}
        result = ApiCommandRequest.parse_object(obj)
        assert result is not None
        assert result.nonce == 0

    def test_parse_bytes_round_trip(self):
        original = {"command": ApiCommand.GET_STATUS, "nonce": 10, "customCommand": 42}
        message = json.dumps(original).encode("utf8")
        result = ApiCommandRequest.parse_bytes(message)
        assert result is not None
        assert result.command == ApiCommand.GET_STATUS
        assert result.nonce == 10
        assert result.custom_command == 42
