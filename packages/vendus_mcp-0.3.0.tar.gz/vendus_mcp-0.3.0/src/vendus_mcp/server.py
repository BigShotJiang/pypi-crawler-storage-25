"""Vendus MCP server — exposes the Vendus public REST API as MCP tools.

Tools mirror `/api/v1/*` endpoints and require a valid `VENDUS_API_KEY`
issued from the Vendus dashboard (Settings > API Keys).
"""

from __future__ import annotations

import json
from typing import Any

from mcp.server.fastmcp import FastMCP

from .client import VendusAPIError, VendusConfigError, api_get

mcp = FastMCP("vendus")


def _dump(payload: Any) -> str:
    return json.dumps(payload, ensure_ascii=False, default=str)


async def _call(path: str, params: dict[str, Any] | None = None) -> str:
    try:
        return _dump(await api_get(path, params))
    except VendusConfigError as exc:
        return _dump({"error": {"code": "not_configured", "message": str(exc)}})
    except VendusAPIError as exc:
        return _dump({"error": {"code": exc.code, "message": exc.message, "status": exc.status}})


# ---- leads ----------------------------------------------------------------


@mcp.tool()
async def list_leads(
    status: str | None = None,
    qualified: str | None = None,
    search: str | None = None,
    created_after: str | None = None,
    created_before: str | None = None,
    cursor: str | None = None,
    limit: int = 50,
) -> str:
    """List leads with optional filters and cursor-based pagination.

    `status` filters by lead type (e.g. inbound), `qualified` accepts yes/no/maybe,
    `created_after` / `created_before` accept ISO 8601 datetimes.
    """
    return await _call(
        "/leads",
        {
            "status": status,
            "qualified": qualified,
            "search": search,
            "created_after": created_after,
            "created_before": created_before,
            "cursor": cursor,
            "limit": limit,
        },
    )


@mcp.tool()
async def get_lead(lead_id: str) -> str:
    """Get the public profile of a lead by ID."""
    return await _call(f"/leads/{lead_id}")


@mcp.tool()
async def get_conversations(lead_id: str, limit: int = 100) -> str:
    """Get conversation messages for a lead, ordered chronologically."""
    return await _call(f"/leads/{lead_id}/conversations", {"limit": limit})


# ---- agents ---------------------------------------------------------------


@mcp.tool()
async def list_agents() -> str:
    """List all AI agents configured for the tenant."""
    return await _call("/agents")


@mcp.tool()
async def get_agent(agent_id: str) -> str:
    """Get the public profile of an AI agent by ID."""
    return await _call(f"/agents/{agent_id}")


# ---- metrics --------------------------------------------------------------


@mcp.tool()
async def get_metrics_summary(since: str | None = None) -> str:
    """Aggregate funnel counters (leads, qualified, meetings, sales).

    `since` is an ISO 8601 datetime (e.g. `2026-01-01T00:00:00Z`).
    Defaults to the start of the tenant's history when omitted.
    """
    return await _call("/metrics/summary", {"since": since})


@mcp.tool()
async def get_metrics_funnel(since: str | None = None) -> str:
    """Conversion funnel breakdown with per-stage percentages.

    `since` is an ISO 8601 datetime (e.g. `2026-01-01T00:00:00Z`).
    """
    return await _call("/metrics/funnel", {"since": since})


# ---- knowledge ------------------------------------------------------------


@mcp.tool()
async def list_knowledge_documents(
    status: str | None = None,
    cursor: str | None = None,
    limit: int = 50,
) -> str:
    """List knowledge base documents (paginated by `created_at`)."""
    return await _call(
        "/knowledge",
        {"status": status, "cursor": cursor, "limit": limit},
    )


@mcp.tool()
async def get_knowledge_document(document_id: str) -> str:
    """Get a knowledge base document's metadata by ID."""
    return await _call(f"/knowledge/{document_id}")


def main() -> None:
    """Entry point used by the `vendus-mcp` console script."""
    mcp.run()


if __name__ == "__main__":
    main()
