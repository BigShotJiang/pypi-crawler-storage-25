"""Streamable-HTTP MCP server for hosted connectors (Claude.ai, ChatGPT).

Runs as its own process (e.g. `vendus-mcp-http --host 0.0.0.0 --port 8080`)
and speaks MCP over streamable HTTP. Credentials flow per-request through
the `Authorization: Bearer <api_key>` (or `X-Vendus-Api-Key`) header, so a
single deployment safely serves many Vendus tenants.

OAuth 2.1 + Dynamic Client Registration layers on top without changing the
tool surface — see `docs/superpowers/specs/2026-04-17-mcp-connector-directory.md`.
"""

from __future__ import annotations

import argparse
import json
import logging
import os
from typing import Any

import httpx
from mcp.server.fastmcp import Context, FastMCP

from .client import DEFAULT_BASE_URL

logger = logging.getLogger(__name__)

mcp = FastMCP("vendus-http")

_USER_AGENT = "vendus-mcp-http/0.3.0"


def _vendus_base_url() -> str:
    return os.environ.get("VENDUS_BASE_URL", DEFAULT_BASE_URL).rstrip("/")


def _extract_api_key(ctx: Context) -> str | None:
    """Read the per-request API key from `Authorization: Bearer` or `X-Vendus-Api-Key`."""
    try:
        request = ctx.request_context.request
    except Exception:
        return None
    if request is None:
        return None
    headers = getattr(request, "headers", None)
    if headers is None:
        return None
    get = headers.get if hasattr(headers, "get") else lambda _k, _d=None: None
    raw = get("x-vendus-api-key") or get("X-Vendus-Api-Key")
    if raw:
        return raw.strip()
    auth = get("authorization") or get("Authorization")
    if auth and auth.lower().startswith("bearer "):
        return auth[len("Bearer ") :].strip()
    return None


def _error(code: str, message: str, status: int | None = None) -> str:
    payload: dict[str, Any] = {"error": {"code": code, "message": message}}
    if status is not None:
        payload["error"]["status"] = status
    return json.dumps(payload, ensure_ascii=False)


async def _call(ctx: Context, path: str, params: dict[str, Any] | None = None) -> str:
    key = _extract_api_key(ctx)
    if not key:
        return _error(
            "missing_api_key",
            "Provide Authorization: Bearer <api_key> or X-Vendus-Api-Key.",
        )

    clean = {k: v for k, v in (params or {}).items() if v is not None}
    url = f"{_vendus_base_url()}/api/v1{path}"
    headers = {
        "X-Vendus-Api-Key": key,
        "User-Agent": _USER_AGENT,
        "Accept": "application/json",
    }
    timeout = httpx.Timeout(30.0, connect=10.0)

    try:
        async with httpx.AsyncClient(timeout=timeout) as client:
            resp = await client.get(url, headers=headers, params=clean)
    except Exception as exc:
        logger.warning("vendus_api_unreachable path=%s err=%s", path, exc)
        return _error("upstream_error", "Vendus API unreachable")

    if 200 <= resp.status_code < 300:
        return resp.text

    code = "http_error"
    message = resp.text[:500] or resp.reason_phrase
    try:
        body = resp.json()
        if isinstance(body, dict):
            err = body.get("error")
            if isinstance(err, dict):
                code = err.get("code", code)
                message = err.get("message", message)
            elif "detail" in body:
                message = str(body["detail"])
    except Exception:
        pass
    return _error(code, message, status=resp.status_code)


# ---- tool registrations (identical surface to the stdio server) -----------


@mcp.tool()
async def list_leads(
    ctx: Context,
    status: str | None = None,
    qualified: str | None = None,
    search: str | None = None,
    created_after: str | None = None,
    created_before: str | None = None,
    cursor: str | None = None,
    limit: int = 50,
) -> str:
    """List leads with optional filters and cursor pagination."""
    return await _call(
        ctx,
        "/leads",
        {
            "status": status,
            "qualified": qualified,
            "search": search,
            "created_after": created_after,
            "created_before": created_before,
            "cursor": cursor,
            "limit": limit,
        },
    )


@mcp.tool()
async def get_lead(ctx: Context, lead_id: str) -> str:
    """Get the public profile of a lead by ID."""
    return await _call(ctx, f"/leads/{lead_id}")


@mcp.tool()
async def get_conversations(ctx: Context, lead_id: str, limit: int = 100) -> str:
    """Get conversation messages for a lead, chronological."""
    return await _call(ctx, f"/leads/{lead_id}/conversations", {"limit": limit})


@mcp.tool()
async def list_agents(ctx: Context) -> str:
    """List all AI agents configured for the tenant."""
    return await _call(ctx, "/agents")


@mcp.tool()
async def get_agent(ctx: Context, agent_id: str) -> str:
    """Get an AI agent's public profile by ID."""
    return await _call(ctx, f"/agents/{agent_id}")


@mcp.tool()
async def get_metrics_summary(ctx: Context, since: str | None = None) -> str:
    """Funnel counters (leads, qualified, meetings, sales). `since` is ISO 8601."""
    return await _call(ctx, "/metrics/summary", {"since": since})


@mcp.tool()
async def get_metrics_funnel(ctx: Context, since: str | None = None) -> str:
    """Conversion funnel breakdown. `since` is ISO 8601."""
    return await _call(ctx, "/metrics/funnel", {"since": since})


@mcp.tool()
async def list_knowledge_documents(
    ctx: Context,
    status: str | None = None,
    cursor: str | None = None,
    limit: int = 50,
) -> str:
    """List knowledge base documents for the tenant."""
    return await _call(
        ctx,
        "/knowledge",
        {"status": status, "cursor": cursor, "limit": limit},
    )


@mcp.tool()
async def get_knowledge_document(ctx: Context, document_id: str) -> str:
    """Get a knowledge base document by ID."""
    return await _call(ctx, f"/knowledge/{document_id}")


# ---- entrypoint -----------------------------------------------------------


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="vendus-mcp-http")
    parser.add_argument(
        "--host",
        default=os.environ.get("MCP_HTTP_HOST", "0.0.0.0"),
        help="Bind address (default: 0.0.0.0 or $MCP_HTTP_HOST).",
    )
    parser.add_argument(
        "--port",
        type=int,
        default=int(os.environ.get("MCP_HTTP_PORT", "8080")),
        help="Bind port (default: 8080 or $MCP_HTTP_PORT).",
    )
    parser.add_argument(
        "--mount-path",
        default=os.environ.get("MCP_HTTP_MOUNT_PATH", "/mcp"),
        help="URL path where the MCP endpoint is mounted (default: /mcp).",
    )
    return parser


def main(argv: list[str] | None = None) -> None:
    """Console entrypoint — `vendus-mcp-http --host ... --port ...`."""
    args = _build_parser().parse_args(argv)

    mcp.settings.host = args.host
    mcp.settings.port = args.port
    mcp.settings.streamable_http_path = args.mount_path

    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s — %(message)s")
    logger.info("vendus-mcp-http listening on http://%s:%d%s", args.host, args.port, args.mount_path)

    mcp.run(transport="streamable-http")


if __name__ == "__main__":
    main()
