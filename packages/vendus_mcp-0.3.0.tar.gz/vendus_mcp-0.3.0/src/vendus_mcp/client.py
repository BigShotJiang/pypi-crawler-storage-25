"""Vendus REST API client used by the MCP server tools."""

from __future__ import annotations

import os
from typing import Any

import httpx

DEFAULT_BASE_URL = "https://semory-dashboard-backend.fly.dev"
USER_AGENT = "vendus-mcp/0.2.0 (+https://pypi.org/project/vendus-mcp/)"


class VendusConfigError(RuntimeError):
    """Raised when the MCP server is not configured correctly."""


class VendusAPIError(RuntimeError):
    """Raised when the Vendus REST API returns a non-2xx response."""

    def __init__(self, status: int, code: str, message: str) -> None:
        super().__init__(f"{status} {code}: {message}")
        self.status = status
        self.code = code
        self.message = message


def _base_url() -> str:
    raw = os.environ.get("VENDUS_BASE_URL", DEFAULT_BASE_URL).strip()
    return raw.rstrip("/")


def _api_key() -> str:
    key = os.environ.get("VENDUS_API_KEY", "").strip()
    if not key:
        raise VendusConfigError(
            "VENDUS_API_KEY is not set. Create one in the Vendus dashboard "
            "(Settings > API Keys) and pass it via the MCP server env."
        )
    return key


def _headers() -> dict[str, str]:
    return {
        "X-Vendus-Api-Key": _api_key(),
        "User-Agent": USER_AGENT,
        "Accept": "application/json",
    }


def _drop_none(params: dict[str, Any] | None) -> dict[str, Any]:
    if not params:
        return {}
    return {k: v for k, v in params.items() if v is not None}


async def api_get(path: str, params: dict[str, Any] | None = None) -> dict[str, Any]:
    """GET /api/v1{path} on the configured Vendus instance."""
    url = f"{_base_url()}/api/v1{path}"
    timeout = httpx.Timeout(30.0, connect=10.0)
    async with httpx.AsyncClient(timeout=timeout) as client:
        resp = await client.get(url, headers=_headers(), params=_drop_none(params))

    if 200 <= resp.status_code < 300:
        return resp.json()

    code = "http_error"
    message = resp.text[:500] or resp.reason_phrase
    try:
        body = resp.json()
        err = body.get("error") if isinstance(body, dict) else None
        if isinstance(err, dict):
            code = err.get("code", code)
            message = err.get("message", message)
        elif isinstance(body, dict) and "detail" in body:
            message = str(body["detail"])
    except Exception:
        pass
    raise VendusAPIError(resp.status_code, code, message)
