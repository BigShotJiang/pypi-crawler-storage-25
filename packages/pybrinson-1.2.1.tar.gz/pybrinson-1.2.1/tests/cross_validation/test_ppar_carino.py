"""Cross-validation: pybrinson._carino_k vs ppar's carino_linking_coefficient.

Consumes the JSON fixture produced by ``scripts/capture_ppar_carino.py``
and asserts pybrinson's implementation matches ppar to ≤ 1e-9.

The fixture filename includes the ppar commit short hash (3fcf0a9) so
that staleness is visible. If the file is missing, the test is skipped
rather than failing — regenerate with ``uv run python scripts/capture_ppar_carino.py``.

Source: https://github.com/JohnDReynolds/portfolio-performance-analytics
"""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from pybrinson.linking.carino import _carino_k

FIXTURE = Path(__file__).parent / "ppar_carino_3fcf0a9.json"


@pytest.mark.skipif(not FIXTURE.exists(), reason="ppar fixture not generated")
def test_carino_k_matches_ppar():
    data = json.loads(FIXTURE.read_text())
    for entry in data:
        r_p = entry["r_p"]
        r_b = entry["r_b"]
        expected = entry["ppar_k"]
        actual = _carino_k(r_p, r_b)
        assert actual == pytest.approx(expected, abs=1e-9), (
            f"_carino_k({r_p}, {r_b}) = {actual}, ppar = {expected}"
        )
