"""Edge-case hardening tests (T1.5).

Each test pins a failure mode that broke a competing Python attribution
library. See ``docs/implementation-v1.1.md`` §T1.5 for the table of
failure modes and the rationale.
"""

from __future__ import annotations

import pytest

from pybrinson import (
    AttributionError,
    Segment,
    bhb,
    fachler,
)

# ---------------------------------------------------------------------------
# Empty / zero-member segments — the open R `pa` issue from 2019.
# ---------------------------------------------------------------------------


def test_empty_segments_raises_bhb():
    """A segment with zero portfolio AND zero benchmark weight is rejected.

    The contribution is mathematically zero so v1.0 silently accepted it,
    but the per-segment returns are then meaningless and almost always
    indicate an upstream classification bug. The R ``pa`` package has
    carried an open issue on exactly this since 2019
    (https://github.com/yl2/pa/issues/1)."""
    segs = [
        Segment("Equities", 0.7, 0.6, 0.10, 0.08),
        Segment("Cash", 0.3, 0.4, 0.01, 0.01),
        Segment("Crypto", 0.0, 0.0, 0.0, 0.0),  # zero-member
    ]
    with pytest.raises(AttributionError, match="Crypto"):
        bhb(segs)


def test_empty_segments_raises_fachler():
    segs = [
        Segment("Equities", 0.7, 0.6, 0.10, 0.08),
        Segment("Cash", 0.3, 0.4, 0.01, 0.01),
        Segment("Crypto", 0.0, 0.0, 0.0, 0.0),
    ]
    with pytest.raises(AttributionError, match="Crypto"):
        fachler(segs)


# ---------------------------------------------------------------------------
# Brinson-Fachler with R_b = 0 — allocation degenerates to BHB equivalent.
# ---------------------------------------------------------------------------


def test_fachler_zero_total_benchmark_return():
    """When ``R_b = 0`` the BF allocation term ``(w_p − w_b)·(R_b,i − R_b)``
    collapses to ``(w_p − w_b)·R_b,i`` — i.e. the BHB form. The function
    must still close the identity exactly. Pinned per
    docs/implementation-v1.1.md T1.5.
    """
    # Hand-balanced so that w_b · R_b = 0.5·0.10 + 0.5·(-0.10) = 0.
    segs = [
        Segment("Up", 0.6, 0.5, 0.12, 0.10),
        Segment("Down", 0.4, 0.5, -0.05, -0.10),
    ]
    bf = fachler(segs)
    bh = bhb(segs)

    assert bf.benchmark_return == pytest.approx(0.0, abs=1e-12)
    # Allocation totals coincide (always true; here both per-segment
    # contributions also coincide because R_b = 0 makes (R_b,i − R_b) ≡ R_b,i).
    assert bf.allocation == pytest.approx(bh.allocation, abs=1e-12)
    assert bf.selection == pytest.approx(bh.selection, abs=1e-12)
    assert bf.interaction == pytest.approx(bh.interaction, abs=1e-12)
    # Identity must still close.
    total = bf.allocation + bf.selection + bf.interaction
    assert total == pytest.approx(bf.excess_return, abs=1e-12)
