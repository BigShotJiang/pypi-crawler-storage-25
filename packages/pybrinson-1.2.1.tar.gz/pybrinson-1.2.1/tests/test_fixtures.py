"""Verifies the public ``pybrinson.fixtures`` submodule.

The fixtures back both the public API (downstream users can validate
their own implementations against them) and the in-repo test suite
(single source of truth). This file is the authoritative round-trip
check that ``pybrinson`` reproduces every fixture's expected numbers.
"""

from __future__ import annotations

import pytest

from pybrinson import bhb, fachler, link_carino, link_frongello, link_menchero
from pybrinson.fixtures import (
    bacon_2008_ch5_bhb,
    bacon_2008_ch5_fachler,
    frongello_2002_table1_identical,
    frongello_2002_table3,
    two_period_linking_example,
)


def test_bacon_2008_ch5_bhb_matches_pybrinson():
    segments, expected = bacon_2008_ch5_bhb()
    res = bhb(segments)
    assert res.portfolio_return == pytest.approx(
        expected["portfolio_return"], abs=1e-12
    )
    assert res.benchmark_return == pytest.approx(
        expected["benchmark_return"], abs=1e-12
    )
    assert res.excess_return == pytest.approx(expected["excess_return"], abs=1e-12)
    assert res.allocation == pytest.approx(expected["allocation"], abs=1e-12)
    assert res.selection == pytest.approx(expected["selection"], abs=1e-12)
    assert res.interaction == pytest.approx(expected["interaction"], abs=1e-12)

    by_name = {s.name: s for s in res.by_segment}
    for name, exp in expected["by_segment"].items():  # type: ignore[union-attr]
        seg = by_name[name]
        assert seg.allocation == pytest.approx(exp["allocation"], abs=1e-12)
        assert seg.selection == pytest.approx(exp["selection"], abs=1e-12)
        assert seg.interaction == pytest.approx(exp["interaction"], abs=1e-12)


def test_bacon_2008_ch5_fachler_matches_pybrinson():
    segments, expected = bacon_2008_ch5_fachler()
    res = fachler(segments)
    assert res.portfolio_return == pytest.approx(
        expected["portfolio_return"], abs=1e-12
    )
    assert res.benchmark_return == pytest.approx(
        expected["benchmark_return"], abs=1e-12
    )
    assert res.excess_return == pytest.approx(expected["excess_return"], abs=1e-12)
    assert res.allocation == pytest.approx(expected["allocation"], abs=1e-12)
    assert res.selection == pytest.approx(expected["selection"], abs=1e-12)
    assert res.interaction == pytest.approx(expected["interaction"], abs=1e-12)

    by_name = {s.name: s for s in res.by_segment}
    for name, exp in expected["by_segment"].items():  # type: ignore[union-attr]
        seg = by_name[name]
        assert seg.allocation == pytest.approx(exp["allocation"], abs=1e-12)
        assert seg.selection == pytest.approx(exp["selection"], abs=1e-12)
        assert seg.interaction == pytest.approx(exp["interaction"], abs=1e-12)


def test_two_period_linking_example_per_period_totals():
    periods, expected = two_period_linking_example()
    p1_label, p1_segs = periods[0]
    p2_label, p2_segs = periods[1]

    p1 = bhb(p1_segs, period=p1_label)
    p2 = bhb(p2_segs, period=p2_label)
    assert p1.excess_return == pytest.approx(expected["p1_excess"], abs=1e-12)
    assert p2.excess_return == pytest.approx(expected["p2_excess"], abs=1e-12)

    compounded_p = (1 + p1.portfolio_return) * (1 + p2.portfolio_return) - 1
    compounded_b = (1 + p1.benchmark_return) * (1 + p2.benchmark_return) - 1
    assert compounded_p == pytest.approx(
        expected["compounded_portfolio_return"], abs=1e-12
    )
    assert compounded_b == pytest.approx(
        expected["compounded_benchmark_return"], abs=1e-12
    )
    assert compounded_p - compounded_b == pytest.approx(
        expected["arithmetic_excess"], abs=1e-12
    )
    assert (1 + compounded_p) / (1 + compounded_b) - 1 == pytest.approx(
        expected["geometric_excess"], abs=1e-12
    )


def test_frongello_2002_table3_linked_allocation():
    """Pin Frongello-linked allocation against Frongello (2002), pp. 11-12."""
    periods, expected = frongello_2002_table3()
    period_attrs = [bhb(segs, period=label) for label, segs in periods]

    # Verify per-period portfolio/benchmark returns match the paper.
    assert period_attrs[0].portfolio_return == pytest.approx(
        expected["p1_portfolio_return"], abs=1e-12
    )
    assert period_attrs[0].benchmark_return == pytest.approx(
        expected["p1_benchmark_return"], abs=1e-12
    )

    linked = link_frongello(period_attrs)
    assert linked.allocation == pytest.approx(
        expected["frongello_linked_allocation"], abs=1e-12
    )
    assert linked.excess_return == pytest.approx(
        expected["arithmetic_excess"], abs=1e-12
    )


def test_frongello_2002_table1_identical_proportions():
    """Pin allocation/selection proportions against Frongello (2002), Table 2.

    For 3 identical periods, Frongello, Cariño, and Menchero all produce
    the same result: 37.50% allocation, 62.50% selection, 0% interaction.
    """
    periods, expected = frongello_2002_table1_identical()
    period_attrs = [bhb(segs, period=label) for label, segs in periods]

    for linker in (link_frongello, link_carino, link_menchero):
        linked = linker(period_attrs)
        excess = linked.excess_return
        assert linked.allocation / excess == pytest.approx(
            expected["allocation_fraction"], abs=1e-6
        )
        assert linked.selection / excess == pytest.approx(
            expected["selection_fraction"], abs=1e-6
        )
        assert linked.interaction / excess == pytest.approx(
            expected["interaction_fraction"], abs=1e-6
        )


def test_fixtures_are_importable_from_top_level_namespace():
    """The plan-specified import path must work end-to-end."""
    from pybrinson.fixtures import bacon_2008_ch5_bhb as f

    segments, expected = f()
    assert isinstance(segments, tuple)
    assert "excess_return" in expected
