"""Tests for plain-text formatting / __repr__."""

from __future__ import annotations

from pybrinson import (
    Segment,
    bhb,
    link_carino,
    linked_to_table,
    period_to_table,
)


def _example():
    return [
        Segment("UK", 0.40, 0.40, 0.20, 0.10),
        Segment("Japan", 0.30, 0.20, -0.05, -0.04),
        Segment("US", 0.30, 0.40, 0.06, 0.08),
    ]


def test_period_table_contains_segments_and_totals():
    res = bhb(_example(), period="2024-Q1")
    table = period_to_table(res)
    assert "BHB" in table
    assert "2024-Q1" in table
    for name in ("UK", "Japan", "US", "Total"):
        assert name in table
    assert "Allocation" in table
    assert "Selection" in table
    assert "Interaction" in table
    # Excess line at 1.9% — formatted as 1.9000%
    assert "1.9000%" in table


def test_period_repr_uses_table():
    res = bhb(_example())
    assert repr(res) == period_to_table(res)


def test_linked_table_renders():
    p1 = bhb(_example(), period="P1")
    p2 = bhb(_example(), period="P2")
    linked = link_carino([p1, p2])
    table = linked_to_table(linked)
    assert "Cariño" in table
    assert "Total" in table
    assert "2 periods" in table
    assert repr(linked) == table


def test_period_table_unlabelled_period():
    res = bhb(_example())
    table = period_to_table(res)
    assert "(unlabelled)" in table
