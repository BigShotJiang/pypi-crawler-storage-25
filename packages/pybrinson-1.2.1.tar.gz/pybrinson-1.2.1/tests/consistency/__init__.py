"""Cross-method consistency tests (v1.1, T1.3 layer (b)).

These tests hold by construction across every linking method and every
single-period model. They are the second line of defence behind the
literature-pinned numerical tests in
``tests/single_period/`` and ``tests/linking/``.
"""
