"""Input-validation tests for pybrinson._math helpers."""

from __future__ import annotations

import math

import pytest

from pybrinson import AttributionError, Segment, bhb
from pybrinson._math import (
    aggregate_return,
    reject_non_finite,
    validate_weights,
)


def test_validate_weights_accepts_unit_sum():
    validate_weights([0.4, 0.6], name="portfolio")


def test_validate_weights_rejects_unnormalised():
    with pytest.raises(AttributionError, match="must sum to 1"):
        validate_weights([0.4, 0.7], name="portfolio")


def test_validate_weights_rejects_nan():
    with pytest.raises(AttributionError, match="non-finite"):
        validate_weights([0.5, float("nan")], name="portfolio")


def test_reject_non_finite_inf():
    with pytest.raises(AttributionError, match="non-finite"):
        reject_non_finite([1.0, math.inf], name="returns")


def test_aggregate_return_basic():
    assert aggregate_return([0.5, 0.5], [0.10, 0.20]) == pytest.approx(0.15)


def test_bhb_rejects_empty_segments():
    with pytest.raises(AttributionError, match="at least one Segment"):
        bhb([])


def test_bhb_rejects_unnormalised_portfolio():
    segs = [
        Segment("A", 0.6, 0.5, 0.10, 0.05),
        Segment("B", 0.3, 0.5, 0.05, 0.10),  # w_p sums to 0.9
    ]
    with pytest.raises(AttributionError, match="portfolio weights must sum"):
        bhb(segs)
