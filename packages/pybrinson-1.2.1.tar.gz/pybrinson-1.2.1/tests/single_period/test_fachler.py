"""Tests for Brinson-Fachler single-period attribution.

Uses the same 3-sector example as ``test_bhb`` so the BHB-vs-BF
allocation difference is directly observable in one place.
"""

from __future__ import annotations

import random

import pytest

from pybrinson import Segment, bhb, fachler

EXAMPLE_SEGMENTS = [
    Segment("UK Equity", 0.40, 0.40, 0.20, 0.10),
    Segment("Japan Equity", 0.30, 0.20, -0.05, -0.04),
    Segment("US Equity", 0.30, 0.40, 0.06, 0.08),
]
EXAMPLE_R_B = 0.064  # see test_bhb


def test_fachler_method_label():
    res = fachler(EXAMPLE_SEGMENTS, period="2024")
    assert res.method == "Brinson-Fachler"
    assert res.period == "2024"


def test_fachler_per_segment_pinned_values():
    res = fachler(EXAMPLE_SEGMENTS)
    by_name = {s.name: s for s in res.by_segment}

    # UK: zero active weight ⇒ allocation zero regardless of formulation
    uk = by_name["UK Equity"]
    assert uk.allocation == pytest.approx(0.0, abs=1e-12)
    assert uk.selection == pytest.approx(0.40 * (0.20 - 0.10), abs=1e-12)

    # Japan: overweight 0.30 vs 0.20, segment R_b = -4%, total R_b = 6.4%
    jp = by_name["Japan Equity"]
    assert jp.allocation == pytest.approx(
        (0.30 - 0.20) * (-0.04 - EXAMPLE_R_B), abs=1e-12
    )

    # US: underweight 0.30 vs 0.40, segment R_b = 8% > total benchmark
    us = by_name["US Equity"]
    assert us.allocation == pytest.approx(
        (0.30 - 0.40) * (0.08 - EXAMPLE_R_B), abs=1e-12
    )


def test_fachler_identity_holds():
    res = fachler(EXAMPLE_SEGMENTS)
    total = res.allocation + res.selection + res.interaction
    assert total == pytest.approx(res.excess_return, abs=1e-12)


def test_fachler_alloc_total_equals_bhb_alloc_total():
    """For any inputs, BHB and BF allocation totals are identical.

    Per-segment differs (BF subtracts the total benchmark), but the
    weighted sum collapses because :math:`\\sum_i (w_{p,i} - w_{b,i}) = 0`
    when both weight vectors sum to 1.
    """
    bhb_res = bhb(EXAMPLE_SEGMENTS)
    bf_res = fachler(EXAMPLE_SEGMENTS)
    assert bf_res.allocation == pytest.approx(bhb_res.allocation, abs=1e-12)
    assert bf_res.selection == pytest.approx(bhb_res.selection, abs=1e-12)
    assert bf_res.interaction == pytest.approx(bhb_res.interaction, abs=1e-12)


def test_fachler_two_effect_collapse():
    res = fachler(EXAMPLE_SEGMENTS)
    selection_2eff = res.selection + res.interaction
    # 2-effect view should still close the identity with allocation
    assert res.allocation + selection_2eff == pytest.approx(
        res.excess_return, abs=1e-12
    )


def test_fachler_alloc_sign_intuition():
    """Overweighting an outperforming sector ⇒ allocation > 0 in BF."""
    segs = [
        Segment("Outperformer", 0.60, 0.40, 0.10, 0.15),  # benchmark 15%
        Segment("Laggard", 0.40, 0.60, 0.02, 0.03),  # benchmark 3%
    ]
    res = fachler(segs)
    by_name = {s.name: s for s in res.by_segment}
    # Total benchmark = 0.4*0.15 + 0.6*0.03 = 0.06 + 0.018 = 0.078
    # Outperformer benchmark return 0.15 > total 0.078 → relative > 0
    # Overweight (0.60 - 0.40 = 0.20 > 0) → allocation > 0
    assert by_name["Outperformer"].allocation > 0
    # Laggard underweight in an underperforming sector → allocation > 0 too
    assert by_name["Laggard"].allocation > 0


def test_fachler_identity_random_inputs():
    rng = random.Random(20260412)
    for _ in range(50):
        n = rng.randint(2, 8)
        w_p = [rng.random() for _ in range(n)]
        w_b = [rng.random() for _ in range(n)]
        s_p, s_b = sum(w_p), sum(w_b)
        w_p = [w / s_p for w in w_p]
        w_b = [w / s_b for w in w_b]
        segs = [
            Segment(
                f"S{i}",
                w_p[i],
                w_b[i],
                rng.uniform(-0.5, 0.5),
                rng.uniform(-0.5, 0.5),
            )
            for i in range(n)
        ]
        res = fachler(segs)
        total = res.allocation + res.selection + res.interaction
        assert total == pytest.approx(res.excess_return, abs=1e-9)
