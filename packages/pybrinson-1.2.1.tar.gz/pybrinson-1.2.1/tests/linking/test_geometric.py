"""Geometric multi-period linking tests.

The identity here is multiplicative:
``(1 + alloc) · (1 + sel) − 1 == excess_return``
where ``excess_return = (1 + R_p) / (1 + R_b) − 1`` is the geometric
excess of compounded returns. ``interaction`` is always ``0`` because
Bacon's geometric form folds it into selection.
"""

from __future__ import annotations

import random

import pytest

from pybrinson import AttributionError, Segment, bhb, link_geometric


def _two_period_example():
    p1 = bhb(
        [
            Segment("A", 0.6, 0.5, 0.10, 0.05),
            Segment("B", 0.4, 0.5, 0.05, 0.10),
        ],
        period="P1",
    )
    p2 = bhb(
        [
            Segment("A", 0.5, 0.5, 0.20, 0.10),
            Segment("B", 0.5, 0.5, 0.05, 0.10),
        ],
        period="P2",
    )
    return p1, p2


def test_geometric_method_label_and_zero_interaction():
    p1, p2 = _two_period_example()
    linked = link_geometric([p1, p2])
    assert linked.method == "geometric"
    assert linked.interaction == 0.0


def test_geometric_multiplicative_identity():
    p1, p2 = _two_period_example()
    linked = link_geometric([p1, p2])
    lhs = (1.0 + linked.allocation) * (1.0 + linked.selection) - 1.0
    assert lhs == pytest.approx(linked.excess_return, abs=1e-12)


def test_geometric_excess_is_geometric_form():
    p1, p2 = _two_period_example()
    linked = link_geometric([p1, p2])
    expected_excess = (1.0 + linked.portfolio_return) / (
        1.0 + linked.benchmark_return
    ) - 1.0
    assert linked.excess_return == pytest.approx(expected_excess, abs=1e-12)


def test_geometric_pinned_two_period_values():
    """Bacon (2008) chap. 6 form: A_t^geom = A_t/(1+R_b,t),
    S_t^geom = (S_t+I_t)/(1+R_b,t+A_t).
    """
    p1, p2 = _two_period_example()
    linked = link_geometric([p1, p2])

    a1 = -0.005 / 1.075
    s1 = (0.0 + 0.010) / (1.075 + -0.005)
    a2 = 0.0 / 1.10
    s2 = (0.025 + 0.0) / (1.10 + 0.0)
    expected_alloc = (1 + a1) * (1 + a2) - 1
    expected_sel = (1 + s1) * (1 + s2) - 1

    assert linked.allocation == pytest.approx(expected_alloc, abs=1e-12)
    assert linked.selection == pytest.approx(expected_sel, abs=1e-12)


def test_geometric_single_period_raises():
    """v1.1: linking on a single period is rejected.
    Pinned per docs/implementation-v1.1.md T1.5."""
    p1, _ = _two_period_example()
    with pytest.raises(AttributionError, match="≥ 2 periods"):
        link_geometric([p1])


def test_geometric_identity_random_multi_period():
    rng = random.Random(20260415)
    for _ in range(20):
        n_periods = rng.randint(2, 6)
        period_attrs = []
        for t in range(n_periods):
            n = rng.randint(2, 5)
            w_p = [rng.random() for _ in range(n)]
            w_b = [rng.random() for _ in range(n)]
            s_p, s_b = sum(w_p), sum(w_b)
            w_p = [w / s_p for w in w_p]
            w_b = [w / s_b for w in w_b]
            segs = [
                Segment(
                    f"S{i}",
                    w_p[i],
                    w_b[i],
                    rng.uniform(-0.2, 0.2),
                    rng.uniform(-0.2, 0.2),
                )
                for i in range(n)
            ]
            period_attrs.append(bhb(segs, period=f"P{t}"))
        linked = link_geometric(period_attrs)
        lhs = (1.0 + linked.allocation) * (1.0 + linked.selection) - 1.0
        assert lhs == pytest.approx(linked.excess_return, abs=1e-9)
