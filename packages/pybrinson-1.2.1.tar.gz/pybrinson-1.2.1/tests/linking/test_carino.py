"""Cariño multi-period linking tests."""

from __future__ import annotations

import math
import random

import pytest

from pybrinson import (
    AttributionError,
    PeriodAttribution,
    Segment,
    bhb,
    link_carino,
)


def _two_period_example() -> tuple[PeriodAttribution, PeriodAttribution]:
    p1 = bhb(
        [
            Segment("A", 0.6, 0.5, 0.10, 0.05),
            Segment("B", 0.4, 0.5, 0.05, 0.10),
        ],
        period="P1",
    )
    p2 = bhb(
        [
            Segment("A", 0.5, 0.5, 0.20, 0.10),
            Segment("B", 0.5, 0.5, 0.05, 0.10),
        ],
        period="P2",
    )
    return p1, p2


def test_carino_identity_two_periods():
    p1, p2 = _two_period_example()
    linked = link_carino([p1, p2])
    assert linked.method == "Cariño"
    total = linked.allocation + linked.selection + linked.interaction
    assert total == pytest.approx(linked.excess_return, abs=1e-12)


def test_carino_compounded_returns():
    p1, p2 = _two_period_example()
    linked = link_carino([p1, p2])
    expected_p = (1 + p1.portfolio_return) * (1 + p2.portfolio_return) - 1
    expected_b = (1 + p1.benchmark_return) * (1 + p2.benchmark_return) - 1
    assert linked.portfolio_return == pytest.approx(expected_p, abs=1e-12)
    assert linked.benchmark_return == pytest.approx(expected_b, abs=1e-12)
    assert linked.excess_return == pytest.approx(expected_p - expected_b, abs=1e-12)


def test_carino_pinned_two_period_values():
    """Hand-computed Cariño values for the two-period example.

    P1: A=-0.005, S=0, I=0.010, excess=0.005
    P2: A=0,      S=0.025, I=0, excess=0.025
    Compounded: R_p=0.215, R_b=0.1825, excess=0.0325
    k1 = (ln1.08 - ln1.075)/0.005, k2 = (ln1.125 - ln1.10)/0.025
    K  = (ln1.215 - ln1.1825)/0.0325
    """
    p1, p2 = _two_period_example()
    linked = link_carino([p1, p2])

    k1 = (math.log1p(0.08) - math.log1p(0.075)) / 0.005
    k2 = (math.log1p(0.125) - math.log1p(0.10)) / 0.025
    big_k = (math.log1p(0.215) - math.log1p(0.1825)) / 0.0325

    expected_alloc = -0.005 * (k1 / big_k) + 0.0 * (k2 / big_k)
    expected_sel = 0.0 * (k1 / big_k) + 0.025 * (k2 / big_k)
    expected_inter = 0.010 * (k1 / big_k) + 0.0 * (k2 / big_k)

    assert linked.allocation == pytest.approx(expected_alloc, abs=1e-12)
    assert linked.selection == pytest.approx(expected_sel, abs=1e-12)
    assert linked.interaction == pytest.approx(expected_inter, abs=1e-12)


def test_linking_single_period_raises():
    """v1.1: linking on a single period is rejected (use the PeriodAttribution
    directly). Pinned per docs/implementation-v1.1.md T1.5."""
    p1, _ = _two_period_example()
    with pytest.raises(AttributionError, match="≥ 2 periods"):
        link_carino([p1])


def test_carino_equal_returns_uses_limit():
    """When R_p,t == R_b,t the smoothing coefficient falls back to its limit."""
    p = bhb(
        [
            Segment("A", 0.5, 0.5, 0.10, 0.10),
            Segment("B", 0.5, 0.5, 0.05, 0.05),
        ],
        period="flat",
    )
    linked = link_carino([p, p])
    assert linked.excess_return == pytest.approx(0.0, abs=1e-12)
    assert linked.allocation == pytest.approx(0.0, abs=1e-12)


def test_carino_undefined_log_raises():
    """``R ≤ -1`` is undefined for ``log(1+R)``; pin the guard.
    Pinned per docs/implementation-v1.1.md T1.5."""
    p_ok = bhb(
        [Segment("A", 1.0, 1.0, 0.05, 0.04)],
        period="ok",
    )
    p_bad = bhb(
        [Segment("A", 1.0, 1.0, -1.0, -0.5)],
        period="bad",
    )
    with pytest.raises(AttributionError, match="returns > -1"):
        link_carino([p_ok, p_bad])


def test_carino_rejects_empty():
    with pytest.raises(AttributionError, match="≥ 2 periods"):
        link_carino([])


def test_carino_limit_branch_continuity():
    """Cariño's k_t falls back to ``1/(1+R_b)`` when ``|R_p − R_b| < 1e-12``.

    The fallback must agree with the analytic formula in the limit; this
    test perturbs ``R_p`` away from ``R_b`` by a sequence of shrinking
    deltas and asserts the linked allocation effect converges smoothly
    to the limit-branch value (no jump). Pinned per
    docs/implementation-v1.1.md T1.5.
    """
    base = bhb(
        [Segment("A", 0.6, 0.5, 0.05, 0.05), Segment("B", 0.4, 0.5, 0.05, 0.05)],
        period="P1",
    )
    # Limit branch (R_p == R_b within tolerance) — both periods identical.
    limit_linked = link_carino([base, base])
    prior = None
    for delta in (1e-3, 1e-5, 1e-7, 1e-9, 1e-11):
        perturbed = bhb(
            [
                Segment("A", 0.6, 0.5, 0.05 + delta, 0.05),
                Segment("B", 0.4, 0.5, 0.05 + delta, 0.05),
            ],
            period="P1",
        )
        linked = link_carino([perturbed, base])
        # The decomposition should remain finite and tend toward the limit
        # branch value as delta → 0.
        assert math.isfinite(linked.allocation)
        assert math.isfinite(linked.selection)
        if prior is not None:
            # Strictly closer to the limit each step (monotone convergence).
            assert (
                abs(linked.selection - limit_linked.selection)
                <= abs(prior - limit_linked.selection) + 1e-15
            )
        prior = linked.selection


def test_carino_rejects_mixed_methods():
    from pybrinson import fachler

    p1 = bhb([Segment("A", 1.0, 1.0, 0.05, 0.04)])
    p2 = fachler([Segment("A", 1.0, 1.0, 0.05, 0.04)])
    with pytest.raises(AttributionError, match="single attribution method"):
        link_carino([p1, p2])


def test_carino_identity_random_multi_period():
    rng = random.Random(20260413)
    for _ in range(20):
        n_periods = rng.randint(2, 8)
        period_attrs = []
        for t in range(n_periods):
            n = rng.randint(2, 5)
            w_p = [rng.random() for _ in range(n)]
            w_b = [rng.random() for _ in range(n)]
            s_p, s_b = sum(w_p), sum(w_b)
            w_p = [w / s_p for w in w_p]
            w_b = [w / s_b for w in w_b]
            segs = [
                Segment(
                    f"S{i}",
                    w_p[i],
                    w_b[i],
                    rng.uniform(-0.2, 0.2),
                    rng.uniform(-0.2, 0.2),
                )
                for i in range(n)
            ]
            period_attrs.append(bhb(segs, period=f"P{t}"))
        linked = link_carino(period_attrs)
        total = linked.allocation + linked.selection + linked.interaction
        assert total == pytest.approx(linked.excess_return, abs=1e-9)
