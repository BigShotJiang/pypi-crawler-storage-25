"""GRAP multi-period linking tests."""

from __future__ import annotations

import random

import pytest

from pybrinson import AttributionError, Segment, bhb, link_grap


def _two_period_example():
    p1 = bhb(
        [
            Segment("A", 0.6, 0.5, 0.10, 0.05),
            Segment("B", 0.4, 0.5, 0.05, 0.10),
        ],
        period="P1",
    )
    p2 = bhb(
        [
            Segment("A", 0.5, 0.5, 0.20, 0.10),
            Segment("B", 0.5, 0.5, 0.05, 0.10),
        ],
        period="P2",
    )
    return p1, p2


def test_grap_identity_two_periods():
    p1, p2 = _two_period_example()
    linked = link_grap([p1, p2])
    assert linked.method == "GRAP"
    total = linked.allocation + linked.selection + linked.interaction
    assert total == pytest.approx(linked.excess_return, abs=1e-12)


def test_grap_pinned_two_period_values():
    """Hand-computed GRAP factors for the two-period example.

    f_1 = (1 + R_b,2) = 1.10
    f_2 = (1 + R_p,1) = 1.08
    """
    p1, p2 = _two_period_example()
    linked = link_grap([p1, p2])

    f1 = 1.10
    f2 = 1.08
    expected_alloc = -0.005 * f1 + 0.0 * f2
    expected_sel = 0.0 * f1 + 0.025 * f2
    expected_inter = 0.010 * f1 + 0.0 * f2

    assert linked.allocation == pytest.approx(expected_alloc, abs=1e-12)
    assert linked.selection == pytest.approx(expected_sel, abs=1e-12)
    assert linked.interaction == pytest.approx(expected_inter, abs=1e-12)
    # And the additive identity must hold:
    expected_excess = 1.08 * 1.125 - 1.075 * 1.10
    assert linked.excess_return == pytest.approx(expected_excess, abs=1e-12)


def test_grap_single_period_raises():
    """v1.1: linking on a single period is rejected.
    Pinned per docs/implementation-v1.1.md T1.5."""
    p1, _ = _two_period_example()
    with pytest.raises(AttributionError, match="≥ 2 periods"):
        link_grap([p1])


def test_grap_identity_random_multi_period():
    rng = random.Random(20260414)
    for _ in range(20):
        n_periods = rng.randint(2, 8)
        period_attrs = []
        for t in range(n_periods):
            n = rng.randint(2, 5)
            w_p = [rng.random() for _ in range(n)]
            w_b = [rng.random() for _ in range(n)]
            s_p, s_b = sum(w_p), sum(w_b)
            w_p = [w / s_p for w in w_p]
            w_b = [w / s_b for w in w_b]
            segs = [
                Segment(
                    f"S{i}",
                    w_p[i],
                    w_b[i],
                    rng.uniform(-0.2, 0.2),
                    rng.uniform(-0.2, 0.2),
                )
                for i in range(n)
            ]
            period_attrs.append(bhb(segs, period=f"P{t}"))
        linked = link_grap(period_attrs)
        total = linked.allocation + linked.selection + linked.interaction
        assert total == pytest.approx(linked.excess_return, abs=1e-9)
