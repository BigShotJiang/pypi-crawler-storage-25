"""Frongello recursive linking tests.

Pinned values come from the worked examples in Frongello (2002),
"Attribution Linking: Proofed and Clarified", *The Journal of
Performance Measurement*, 7(1), Fall 2002, pp. 54-67. Open-access PDF:
https://frongello.com/support/Works/JPMFall2002.pdf
"""

from __future__ import annotations

import random

import pytest

from pybrinson import (
    AttributionError,
    PeriodAttribution,
    Segment,
    SegmentAttribution,
    bhb,
    fachler,
    link_frongello,
    link_grap,
)
from pybrinson.fixtures import two_period_linking_example


def _synthetic_period(
    label: str,
    r_p: float,
    r_b: float,
    alloc: float,
    sel: float,
    inter: float = 0.0,
    method: str = "BHB",
) -> PeriodAttribution:
    """Build a PeriodAttribution from per-period totals (no segment math)."""
    return PeriodAttribution(
        period=label,
        portfolio_return=r_p,
        benchmark_return=r_b,
        excess_return=r_p - r_b,
        allocation=alloc,
        selection=sel,
        interaction=inter,
        by_segment=(
            SegmentAttribution(
                name="total",
                allocation=alloc,
                selection=sel,
                interaction=inter,
            ),
        ),
        method=method,
    )


def _two_period_attrs() -> tuple[PeriodAttribution, PeriodAttribution]:
    periods, _ = two_period_linking_example()
    p1 = bhb(periods[0][1], period=periods[0][0])
    p2 = bhb(periods[1][1], period=periods[1][0])
    return p1, p2


# ---------------------------------------------------------------------------
# Pinned worked examples taken DIRECTLY from Frongello (2002).
# ---------------------------------------------------------------------------


def test_frongello_paper_two_period_pinned():
    """Frongello (2002), p. 6, "Cumulative Relative Attribution and Order
    Dependence" — the worked 2-period example.

    P1: R_p=20%, R_b=10%, allocation=5%, selection=5%
    P2: R_p=10%, R_b=5%,  allocation=2%, selection=3%

    Frongello-linked totals derived in the paper:
        Allocation = 5% + 2%(1+20%) + 5%·5%  = 7.65%
        Selection  = 5% + 3%(1+20%) + 5%·5%  = 8.85%
        Total      = 16.5% = (1.20·1.10) − (1.10·1.05)
    """
    p1 = _synthetic_period("P1", 0.20, 0.10, alloc=0.05, sel=0.05)
    p2 = _synthetic_period("P2", 0.10, 0.05, alloc=0.02, sel=0.03)
    linked = link_frongello([p1, p2])

    assert linked.allocation == pytest.approx(0.0765, abs=1e-12)
    assert linked.selection == pytest.approx(0.0885, abs=1e-12)
    assert linked.interaction == pytest.approx(0.0, abs=1e-12)
    assert linked.excess_return == pytest.approx(0.165, abs=1e-12)
    assert linked.portfolio_return == pytest.approx(1.20 * 1.10 - 1.0, abs=1e-12)
    assert linked.benchmark_return == pytest.approx(1.10 * 1.05 - 1.0, abs=1e-12)


def test_frongello_paper_two_period_reversed_order():
    """Frongello (2002), p. 6 — same example with the period order reversed.

    Frongello explicitly demonstrates that his linking is order-dependent:
        Allocation = 2% + 5%(1+10%) + 2%·10% = 7.7%
        Selection  = 3% + 5%(1+10%) + 3%·10% = 8.8%
    """
    p1 = _synthetic_period("P1", 0.10, 0.05, alloc=0.02, sel=0.03)
    p2 = _synthetic_period("P2", 0.20, 0.10, alloc=0.05, sel=0.05)
    linked = link_frongello([p1, p2])

    assert linked.allocation == pytest.approx(0.077, abs=1e-12)
    assert linked.selection == pytest.approx(0.088, abs=1e-12)
    assert linked.excess_return == pytest.approx(0.165, abs=1e-12)


def test_frongello_paper_table3_three_period_allocation():
    """Frongello (2002), Table 3 / "Challenge" section, p. 11.

    The paper challenges the reader: "If asset allocation subtracted
    value from the fund in the first two periods, and added 34% in
    Period 3, how can one possibly justify the conclusion that asset
    allocation added substantially more than 34% over all three
    periods?" Frongello derives, step by step, **57.39475%** for the
    cumulative allocation effect:

        −4% + (−0.665% + −0.76%) + (63.308% + −0.48825%)
          = −4% + −1.425% + 62.819750% = 57.39475%

    The portfolio return is 99.2340% and the benchmark 10.2535%, for a
    cumulative excess of 88.9805%.

    Single-period sector-aggregate inputs from Frongello's Table 3
    (Brinson-Fachler 2-effect form, no interaction, totals only):
        P1: R_p= 33%,  R_b=−15%, alloc=−4%,  sel=52%
        P2: R_p= 40%,  R_b= 19%, alloc=−0.50%, sel=21.50%
        P3: R_p=  7%,  R_b=  9%, alloc= 34%,  sel=−36%
    """
    p1 = _synthetic_period("P1", 0.33, -0.15, alloc=-0.04, sel=0.52)
    p2 = _synthetic_period("P2", 0.40, 0.19, alloc=-0.005, sel=0.215)
    p3 = _synthetic_period("P3", 0.07, 0.09, alloc=0.34, sel=-0.36)
    linked = link_frongello([p1, p2, p3])

    # Pinned to the paper's hand-derivation, not to a number we recomputed.
    assert linked.allocation == pytest.approx(0.5739475, abs=1e-12)
    # Excess return: 99.2340% − 10.2535% = 88.9805% per Frongello, p. 10.
    expected_excess = (1.33 * 1.40 * 1.07) - (0.85 * 1.19 * 1.09)
    assert linked.excess_return == pytest.approx(expected_excess, abs=1e-12)
    assert linked.excess_return == pytest.approx(0.889805, abs=1e-6)
    # Identity holds (alloc + sel = excess, since interaction = 0).
    assert linked.allocation + linked.selection == pytest.approx(
        linked.excess_return, abs=1e-12
    )


# ---------------------------------------------------------------------------
# Numerical equivalence with the GRAP closed-form.
# ---------------------------------------------------------------------------


def test_frongello_grap_numerical_equivalence_paper_example():
    """Frongello's recursion and the GRAP closed-form are algebraically
    identical (both expand to f_t = Π_{s<t}(1+R_p,s) · Π_{s>t}(1+R_b,s)).
    Pin the equivalence on Frongello's own Table 3 example.
    """
    p1 = _synthetic_period("P1", 0.33, -0.15, alloc=-0.04, sel=0.52)
    p2 = _synthetic_period("P2", 0.40, 0.19, alloc=-0.005, sel=0.215)
    p3 = _synthetic_period("P3", 0.07, 0.09, alloc=0.34, sel=-0.36)
    fr = link_frongello([p1, p2, p3])
    gr = link_grap([p1, p2, p3])
    assert fr.allocation == pytest.approx(gr.allocation, abs=1e-12)
    assert fr.selection == pytest.approx(gr.selection, abs=1e-12)
    assert fr.interaction == pytest.approx(gr.interaction, abs=1e-12)


def test_frongello_grap_numerical_equivalence_random():
    """The Frongello/GRAP equivalence must hold pointwise for any input."""
    rng = random.Random(20260430)
    for _ in range(50):
        n_periods = rng.randint(2, 8)
        period_attrs: list[PeriodAttribution] = []
        for t in range(n_periods):
            n = rng.randint(2, 5)
            w_p = [rng.random() for _ in range(n)]
            w_b = [rng.random() for _ in range(n)]
            sp, sb = sum(w_p), sum(w_b)
            w_p = [w / sp for w in w_p]
            w_b = [w / sb for w in w_b]
            segs = [
                Segment(
                    f"S{i}",
                    w_p[i],
                    w_b[i],
                    rng.uniform(-0.2, 0.2),
                    rng.uniform(-0.2, 0.2),
                )
                for i in range(n)
            ]
            period_attrs.append(bhb(segs, period=f"P{t}"))
        fr = link_frongello(period_attrs)
        gr = link_grap(period_attrs)
        assert fr.allocation == pytest.approx(gr.allocation, abs=1e-12)
        assert fr.selection == pytest.approx(gr.selection, abs=1e-12)
        assert fr.interaction == pytest.approx(gr.interaction, abs=1e-12)


# ---------------------------------------------------------------------------
# Identity, recursion-from-closed-form, and guard tests.
# ---------------------------------------------------------------------------


def test_frongello_method_label_and_identity():
    p1, p2 = _two_period_attrs()
    linked = link_frongello([p1, p2])
    assert linked.method == "Frongello"
    total = linked.allocation + linked.selection + linked.interaction
    assert total == pytest.approx(linked.excess_return, abs=1e-12)


def test_frongello_compounded_returns_match_other_linkers():
    """All linking methods agree on R_p^cum and R_b^cum (consistency)."""
    from pybrinson import link_carino, link_geometric, link_grap

    p1, p2 = _two_period_attrs()
    fr = link_frongello([p1, p2])
    ca = link_carino([p1, p2])
    gr = link_grap([p1, p2])
    ge = link_geometric([p1, p2])
    for other in (ca, gr, ge):
        assert fr.portfolio_return == pytest.approx(other.portfolio_return, abs=1e-12)
        assert fr.benchmark_return == pytest.approx(other.benchmark_return, abs=1e-12)


def test_frongello_single_period_raises():
    p1, _ = _two_period_attrs()
    with pytest.raises(AttributionError, match="≥ 2 periods"):
        link_frongello([p1])


def test_frongello_rejects_mixed_methods():
    p1 = bhb([Segment("A", 1.0, 1.0, 0.05, 0.04)])
    p2 = fachler([Segment("A", 1.0, 1.0, 0.05, 0.04)])
    with pytest.raises(AttributionError, match="single attribution method"):
        link_frongello([p1, p2])


def test_frongello_identity_random_multi_period():
    rng = random.Random(20260427)
    for _ in range(20):
        n_periods = rng.randint(2, 8)
        period_attrs: list[PeriodAttribution] = []
        for t in range(n_periods):
            n = rng.randint(2, 5)
            w_p = [rng.random() for _ in range(n)]
            w_b = [rng.random() for _ in range(n)]
            sp, sb = sum(w_p), sum(w_b)
            w_p = [w / sp for w in w_p]
            w_b = [w / sb for w in w_b]
            segs = [
                Segment(
                    f"S{i}",
                    w_p[i],
                    w_b[i],
                    rng.uniform(-0.2, 0.2),
                    rng.uniform(-0.2, 0.2),
                )
                for i in range(n)
            ]
            period_attrs.append(bhb(segs, period=f"P{t}"))
        linked = link_frongello(period_attrs)
        total = linked.allocation + linked.selection + linked.interaction
        assert total == pytest.approx(linked.excess_return, abs=1e-9)


def test_frongello_recursive_form_matches_implementation():
    """Verify the recursion F_t = G_t·prefix_p[t] + R_b,t·Σ_{s<t}F_s on a
    4-period synthetic input by hand-stepping the allocation channel.
    """
    rng = random.Random(20260428)
    period_attrs: list[PeriodAttribution] = []
    for t in range(4):
        segs = [
            Segment("A", 0.55, 0.50, rng.uniform(-0.1, 0.1), rng.uniform(-0.1, 0.1)),
            Segment("B", 0.45, 0.50, rng.uniform(-0.1, 0.1), rng.uniform(-0.1, 0.1)),
        ]
        period_attrs.append(bhb(segs, period=f"P{t}"))

    L_alloc = 0.0
    for t in range(len(period_attrs)):
        prefix_p = 1.0
        for s in range(t):
            prefix_p *= 1.0 + period_attrs[s].portfolio_return
        F_t = (
            period_attrs[t].allocation * prefix_p
            + period_attrs[t].benchmark_return * L_alloc
        )
        L_alloc += F_t

    linked = link_frongello(period_attrs)
    assert linked.allocation == pytest.approx(L_alloc, abs=1e-12)
