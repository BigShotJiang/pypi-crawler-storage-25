"""Menchero optimised multi-period linking tests.

The pinned values come from applying the Menchero (2000) formula — as
reproduced in Bacon (2008) chap. 6, pp. 194-196 and in the R
``PortfolioAttribution`` reference implementation — to the public
``two_period_linking_example`` fixture.
"""

from __future__ import annotations

import math
import random

import pytest

from pybrinson import (
    AttributionError,
    PeriodAttribution,
    Segment,
    bhb,
    fachler,
    link_menchero,
)
from pybrinson.fixtures import two_period_linking_example


def _two_period_attrs() -> tuple[PeriodAttribution, PeriodAttribution]:
    periods, _ = two_period_linking_example()
    p1 = bhb(periods[0][1], period=periods[0][0])
    p2 = bhb(periods[1][1], period=periods[1][0])
    return p1, p2


def test_menchero_method_label_and_identity():
    p1, p2 = _two_period_attrs()
    linked = link_menchero([p1, p2])
    assert linked.method == "Menchero"
    total = linked.allocation + linked.selection + linked.interaction
    assert total == pytest.approx(linked.excess_return, abs=1e-12)


def test_menchero_pinned_two_period_values():
    """Hand-computed Menchero coefficients for the two-period example.

    Per-period BHB effects from the fixture:
        P1: A = -0.005, S = 0,     I = 0.010, g_1 = 0.005
        P2: A =  0,     S = 0.025, I = 0,     g_2 = 0.025

    Compounded: R_p^cum = 0.215, R_b^cum = 0.1825, Δ = 0.0325, T = 2.

    Menchero (2000) / Bacon (2008) ch. 6:
        M = (Δ/T) / ((1+R_p^cum)^(1/T) - (1+R_b^cum)^(1/T))
        α_t = (Δ - M·Σg) · g_t / Σg²
    """
    p1, p2 = _two_period_attrs()
    linked = link_menchero([p1, p2])

    delta = 0.0325
    t = 2
    big_m = (delta / t) / (math.sqrt(1.215) - math.sqrt(1.1825))
    g = (0.005, 0.025)
    sum_g = g[0] + g[1]
    sum_g2 = g[0] ** 2 + g[1] ** 2
    numerator = delta - big_m * sum_g
    alpha = tuple(numerator * gi / sum_g2 for gi in g)
    scale_1 = big_m + alpha[0]
    scale_2 = big_m + alpha[1]

    expected_alloc = -0.005 * scale_1 + 0.0 * scale_2
    expected_sel = 0.0 * scale_1 + 0.025 * scale_2
    expected_inter = 0.010 * scale_1 + 0.0 * scale_2

    assert linked.allocation == pytest.approx(expected_alloc, abs=1e-12)
    assert linked.selection == pytest.approx(expected_sel, abs=1e-12)
    assert linked.interaction == pytest.approx(expected_inter, abs=1e-12)
    assert linked.excess_return == pytest.approx(delta, abs=1e-12)


def test_menchero_compounded_returns_match_other_linkers():
    from pybrinson import link_carino, link_frongello, link_geometric, link_grap

    p1, p2 = _two_period_attrs()
    men = link_menchero([p1, p2])
    for other in (
        link_carino([p1, p2]),
        link_grap([p1, p2]),
        link_frongello([p1, p2]),
        link_geometric([p1, p2]),
    ):
        assert men.portfolio_return == pytest.approx(other.portfolio_return, abs=1e-12)
        assert men.benchmark_return == pytest.approx(other.benchmark_return, abs=1e-12)


def test_menchero_single_period_raises():
    p1, _ = _two_period_attrs()
    with pytest.raises(AttributionError, match="≥ 2 periods"):
        link_menchero([p1])


def test_menchero_rejects_mixed_methods():
    p1 = bhb([Segment("A", 1.0, 1.0, 0.05, 0.04)])
    p2 = fachler([Segment("A", 1.0, 1.0, 0.05, 0.04)])
    with pytest.raises(AttributionError, match="single attribution method"):
        link_menchero([p1, p2])


def test_menchero_rejects_total_wipe_out():
    p1 = bhb([Segment("A", 1.0, 1.0, -1.0, 0.0)], period="P1")
    p2 = bhb([Segment("A", 1.0, 1.0, 0.10, 0.05)], period="P2")
    with pytest.raises(AttributionError, match="returns > -1"):
        link_menchero([p1, p2])


def test_menchero_zero_excess_limit_branch():
    """When R_p^cum == R_b^cum, M = (1 + R_b^cum)^((T-1)/T) and α_t = 0.

    We build two periods whose compounded returns coincide. Each BHB
    effect is zero because the portfolio and benchmark are identical in
    every period, so every linked effect collapses to zero — but the
    code path is the one that is otherwise unreachable.
    """
    p1 = bhb(
        [Segment("A", 0.5, 0.5, 0.05, 0.05), Segment("B", 0.5, 0.5, 0.04, 0.04)],
        period="P1",
    )
    p2 = bhb(
        [Segment("A", 0.5, 0.5, 0.03, 0.03), Segment("B", 0.5, 0.5, 0.02, 0.02)],
        period="P2",
    )
    linked = link_menchero([p1, p2])
    assert linked.excess_return == pytest.approx(0.0, abs=1e-12)
    assert linked.allocation == pytest.approx(0.0, abs=1e-12)
    assert linked.selection == pytest.approx(0.0, abs=1e-12)
    assert linked.interaction == pytest.approx(0.0, abs=1e-12)


def test_menchero_identity_random_multi_period():
    rng = random.Random(20260429)
    for _ in range(20):
        n_periods = rng.randint(2, 8)
        period_attrs: list[PeriodAttribution] = []
        for t in range(n_periods):
            n = rng.randint(2, 5)
            w_p = [rng.random() for _ in range(n)]
            w_b = [rng.random() for _ in range(n)]
            sp, sb = sum(w_p), sum(w_b)
            w_p = [w / sp for w in w_p]
            w_b = [w / sb for w in w_b]
            segs = [
                Segment(
                    f"S{i}",
                    w_p[i],
                    w_b[i],
                    rng.uniform(-0.2, 0.2),
                    rng.uniform(-0.2, 0.2),
                )
                for i in range(n)
            ]
            period_attrs.append(bhb(segs, period=f"P{t}"))
        linked = link_menchero(period_attrs)
        total = linked.allocation + linked.selection + linked.interaction
        assert total == pytest.approx(linked.excess_return, abs=1e-9)
