import pybrinson


def test_version_exposed():
    assert isinstance(pybrinson.__version__, str)
    assert pybrinson.__version__
