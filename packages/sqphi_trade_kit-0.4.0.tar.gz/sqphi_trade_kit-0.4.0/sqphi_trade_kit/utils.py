from typing import Any

import pandas as pd


def print_markdown(message: Any) -> None:
    if isinstance(message, pd.DataFrame):
        print(message.to_markdown(index=False))
    else:
        print(message)


def time_logger(func):
    def wrapper(*args, **kwargs):
        start_time = pd.Timestamp.now(tz="UTC")
        result = func(*args, **kwargs)
        end_time = pd.Timestamp.now(tz="UTC")
        elapsed_time = end_time - start_time
        print(f"{end_time}: Function {func.__name__} executed in {elapsed_time}.")
        return result

    return wrapper
