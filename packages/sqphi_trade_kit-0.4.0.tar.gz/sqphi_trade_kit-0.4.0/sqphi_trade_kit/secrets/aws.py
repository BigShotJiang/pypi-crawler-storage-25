"""AWS Secrets Manager utilities."""

import json

import boto3
from botocore.exceptions import ClientError


def get_aws_secrets(secret_name: str) -> dict[str, str]:
    """Load a JSON secret from AWS Secrets Manager."""
    try:
        sm = boto3.client("secretsmanager")
        response = sm.get_secret_value(SecretId=secret_name)
        return json.loads(response["SecretString"])
    except ClientError as e:
        raise RuntimeError(f"Failed to load secrets from {secret_name}: {e}")
