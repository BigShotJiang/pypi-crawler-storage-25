"""Sync .env secrets to AWS Secrets Manager.

Creates a single JSON secret at /{app}/{env}/secrets with all key-value pairs.

Usage as CLI:
    python -m sqphi_trade_kit.secrets.sync --app my-app --env prod --keys KEY1,KEY2,KEY3

Usage as library:
    from sqphi_trade_kit.secrets.sync import sync_secrets
    sync_secrets("my-app", "prod", ["KEY1", "KEY2"], env_file=".env")
"""

import argparse
import json

import boto3
from botocore.exceptions import ClientError
from dotenv import dotenv_values


def sync_secrets(
    app: str,
    env: str,
    keys: list[str],
    env_file: str = ".env",
    dry_run: bool = False,
) -> dict[str, str]:
    """Sync secrets from a .env file to AWS Secrets Manager.

    Args:
        app: Application name (used in secret path: /{app}/{env}/secrets).
        env: Target environment (e.g. "dev", "prod").
        keys: List of .env keys to sync.
        env_file: Path to .env file.
        dry_run: If True, print what would happen without writing.

    Returns:
        Dict of synced key-value pairs.
    """
    env_vars = dotenv_values(env_file)
    if env == "prod":
        env_vars["ENV"] = "prod"

    secrets_dict = {}
    missing_keys = []

    for key in keys:
        value = env_vars.get(key)
        if not value:
            missing_keys.append(key)
            continue
        secrets_dict[key] = value

    if missing_keys:
        print(f"Warning: Missing keys in .env: {', '.join(missing_keys)}")

    secret_name = f"/{app}/{env}/secrets"
    secret_json = json.dumps(secrets_dict, indent=2)

    if dry_run:
        print(f"Would create/update: {secret_name}")
        print(f"With {len(secrets_dict)} keys: {', '.join(secrets_dict.keys())}")
        return secrets_dict

    sm = boto3.client("secretsmanager")
    tags = [
        {"Key": "application", "Value": app},
        {"Key": "environment", "Value": env},
    ]

    try:
        sm.create_secret(
            Name=secret_name,
            SecretString=secret_json,
            Tags=tags,
        )
        print(f"Created {secret_name} with {len(secrets_dict)} keys")
    except ClientError as e:
        if e.response["Error"]["Code"] == "ResourceExistsException":
            sm.update_secret(SecretId=secret_name, SecretString=secret_json)
            print(f"Updated {secret_name} with {len(secrets_dict)} keys")
        else:
            raise

    print(f"Keys synced: {', '.join(secrets_dict.keys())}")
    return secrets_dict


def main():
    parser = argparse.ArgumentParser(
        description="Sync .env to AWS Secrets Manager (single JSON secret)"
    )
    parser.add_argument("--app", required=True, help="Application name")
    parser.add_argument("--env", default="dev", help="Target environment (default: dev)")
    parser.add_argument("--keys", required=True, help="Comma-separated list of .env keys to sync")
    parser.add_argument("--env-file", default=".env", help="Path to .env file")
    parser.add_argument("--dry-run", action="store_true", help="Print without writing")
    args = parser.parse_args()

    sync_secrets(
        app=args.app,
        env=args.env,
        keys=[k.strip() for k in args.keys.split(",")],
        env_file=args.env_file,
        dry_run=args.dry_run,
    )


if __name__ == "__main__":
    main()
