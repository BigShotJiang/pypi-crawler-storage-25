import os

import requests


def send_telegram_message(
    message: str,
    telegram_message_thread_id: int,
    telegram_bot_token: str = os.getenv("TELEGRAM_BOT_TOKEN"),
    telegram_chat_id: str = os.getenv("TELEGRAM_CHAT_ID"),
) -> dict:
    """Send notifications to Telegram."""
    telegram_api_url = f"https://api.telegram.org/bot{telegram_bot_token}/sendMessage"
    params = {
        "chat_id": telegram_chat_id,
        "text": message,
        "message_thread_id": telegram_message_thread_id,
    }
    response = requests.get(telegram_api_url, params=params)
    return response.json()
