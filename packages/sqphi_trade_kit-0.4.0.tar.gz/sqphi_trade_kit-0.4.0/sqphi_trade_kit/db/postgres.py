"""PostgreSQL connection utilities."""

import os
from functools import lru_cache

import sqlalchemy as sa

from sqphi_trade_kit.secrets.aws import get_aws_secrets


@lru_cache(maxsize=1)
def get_database_url() -> str:
    """Get database URL from environment variables or AWS Secrets Manager.

    Local dev: Uses DATABASE_URL from .env
    AWS ECS: Constructs URL from DB_ENDPOINT env var + Secrets Manager credentials
    """
    db_url = os.environ.get("DATABASE_URL")
    if db_url:
        return db_url.replace("postgres://", "postgresql://")

    env = os.environ.get("ENV", "prod")
    endpoint = os.environ.get("DB_ENDPOINT")
    if not endpoint:
        raise RuntimeError("DB_ENDPOINT environment variable is required when DATABASE_URL is not set")
    database_credentials = get_aws_secrets(f"trading-systems-{env}-db-credentials")
    username = database_credentials.get("username")
    password = database_credentials.get("password")

    if all([username, password]):
        return f"postgresql://{username}:{password}@{endpoint}:5432/postgres?sslmode=require"

    raise RuntimeError(
        f"Missing database credentials for env '{env}'.\n"
        f"DB_ENDPOINT={endpoint!r}, username={'set' if username else 'missing'}"
    )


_engine = None


def get_engine() -> sa.Engine:
    """Lazily create a shared SQLAlchemy engine."""
    global _engine
    if _engine is None:
        _engine = sa.create_engine(get_database_url(), future=True)
    return _engine
