"""ArcticDB read helpers for market data.

Reads from market-hub's ArcticDB storage. Requires ARCTIC_URI env var.
Symbol format: {exchange}__{base}__USDT-USDT (matches market-hub convention).
"""

import os
from functools import lru_cache

import arcticdb as adb
import pandas as pd


@lru_cache(maxsize=1)
def get_arctic() -> adb.Arctic:
    """Connect to ArcticDB using ARCTIC_URI environment variable."""
    uri = os.environ["ARCTIC_URI"]
    return adb.Arctic(uri)


def get_library(name: str) -> adb.library.Library:
    """Return an ArcticDB library by name."""
    return get_arctic().get_library(name, create_if_missing=False)


def make_symbol(exchange: str, base: str) -> str:
    """Build ArcticDB symbol key for a USDT perpetual.

    Example: ("binance", "BTC") -> "binance__BTC__USDT-USDT"
    """
    return f"{exchange}__{base}__USDT-USDT"


def read_symbol(
    lib: adb.library.Library,
    symbol: str,
    date_range: tuple[pd.Timestamp | None, pd.Timestamp | None] | None = None,
) -> pd.DataFrame:
    """Read a symbol and restore timestamp as a regular column.

    If the latest segments are missing (active writer race condition),
    retries with the end time backed off by increasing intervals.
    """
    backoff_minutes = [0, 5, 30, 60]
    last_err = None
    for minutes in backoff_minutes:
        try:
            dr = date_range
            if minutes and dr:
                backed_off_end = pd.Timestamp.now("UTC") - pd.Timedelta(minutes=minutes)
                dr = (dr[0], min(dr[1], backed_off_end) if dr[1] else backed_off_end)
            elif minutes:
                dr = (None, pd.Timestamp.now("UTC") - pd.Timedelta(minutes=minutes))
            item = lib.read(symbol, date_range=dr) if dr else lib.read(symbol)
            df: pd.DataFrame = item.data
            if isinstance(df.index, pd.DatetimeIndex):
                df = df.reset_index()
            return df
        except Exception as e:
            if "Not found" not in str(e) and "No response body" not in str(e):
                raise
            last_err = e
    raise last_err


def get_ohlcv(
    start_date: pd.Timestamp,
    end_date: pd.Timestamp | None = None,
    bases: list[str] | None = None,
    exchange: str | None = None,
) -> pd.DataFrame:
    """Fetch 1-minute OHLCV data from ArcticDB for the given bases and date range.

    Args:
        start_date: Start of date range (inclusive).
        end_date: End of date range (inclusive). None for open-ended.
        bases: List of base assets (e.g. ["BTC", "ETH"]). Required.
        exchange: Exchange name (default: OHLCV_EXCHANGE env var or "binance").

    Returns:
        DataFrame with columns: symbol, timestamp, close, volume.
    """
    if bases is None:
        raise ValueError("bases must be provided")
    if exchange is None:
        exchange = os.getenv("OHLCV_EXCHANGE", "binance")

    lib = get_library("ohlcv")
    frames = []
    for base in bases:
        arctic_sym = make_symbol(exchange, base)
        if not lib.has_symbol(arctic_sym):
            continue
        date_range = (start_date, end_date) if end_date else (start_date, None)
        df = read_symbol(lib, arctic_sym, date_range=date_range)
        df["symbol"] = base
        frames.append(df[["symbol", "timestamp", "close", "volume"]])

    if not frames:
        return pd.DataFrame(columns=["symbol", "timestamp", "close", "volume"])
    return pd.concat(frames, ignore_index=True)


def get_ohlcv_resampled(
    start_date: pd.Timestamp,
    end_date: pd.Timestamp | None = None,
    bases: list[str] | None = None,
    freq: str = "1h",
    exchange: str | None = None,
) -> pd.DataFrame:
    """Fetch OHLCV data from ArcticDB resampled to a target frequency.

    Reads 1-minute data and resamples in pandas.
    Supported frequencies: "1h", "1d".

    Returns:
        DataFrame with columns: symbol, timestamp, close, volume.
    """
    if freq not in ("1h", "1d"):
        raise ValueError(f"Unsupported freq {freq!r}. Supported: ['1h', '1d']")

    raw = get_ohlcv(start_date, end_date, bases=bases, exchange=exchange)
    if raw.empty:
        return raw

    return (
        raw.set_index("timestamp")
        .groupby("symbol", observed=True)
        .resample(freq)
        .agg(close=("close", "last"), volume=("volume", "sum"))
        .dropna(subset=["close"])
        .reset_index()
    )
