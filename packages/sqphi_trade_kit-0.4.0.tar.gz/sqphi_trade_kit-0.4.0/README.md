# sqphi-trade-kit

Shared Python utilities for crypto trading systems. Provides database connectors (PostgreSQL, ArcticDB), Telegram notifications, AWS Secrets Manager access, and common helpers.

## Installation

```bash
pip install sqphi-trade-kit
# or
uv add sqphi-trade-kit
```

## Modules

### Top-level imports

```python
from sqphi_trade_kit import send_telegram_message, print_markdown, time_logger
```

| Function | Description |
|---|---|
| `send_telegram_message(message, thread_id)` | Send a notification to Telegram |
| `print_markdown(message)` | Print a DataFrame as markdown table, or plain `print()` otherwise |
| `time_logger` | Decorator that logs function execution time |

### `sqphi_trade_kit.db` — Database connectors

```python
from sqphi_trade_kit.db import get_engine, get_database_url
from sqphi_trade_kit.db import get_ohlcv, get_ohlcv_resampled, get_arctic, get_library
```

**PostgreSQL** (`sqphi_trade_kit.db.postgres`):
- `get_database_url()` — Resolves DB URL from `DATABASE_URL` env var (local) or AWS Secrets Manager + `DB_ENDPOINT` (ECS)
- `get_engine()` — Lazily-created shared SQLAlchemy engine

**ArcticDB** (`sqphi_trade_kit.db.arctic`):
- `get_arctic()` — Connect via `ARCTIC_URI` env var
- `get_library(name)` — Return a named ArcticDB library
- `get_ohlcv(start_date, end_date, bases, exchange)` — Fetch 1-minute OHLCV candles. Symbol format: `{exchange}__{base}__USDT-USDT`
- `get_ohlcv_resampled(start_date, end_date, bases, freq, exchange)` — Fetch and resample to `1h` or `1d`

### `sqphi_trade_kit.notifications` — Telegram

```python
from sqphi_trade_kit.notifications import send_telegram_message
```

Requires `TELEGRAM_BOT_TOKEN` and `TELEGRAM_CHAT_ID` env vars.

### `sqphi_trade_kit.secrets` — AWS Secrets Manager

```python
from sqphi_trade_kit.secrets import get_aws_secrets

creds = get_aws_secrets("trading-systems-prod-db-credentials")
```

### CLI: `sqphi-sync-secrets`

Sync `.env` keys to AWS Secrets Manager:

```bash
sqphi-sync-secrets --app my-app --env prod --keys KEY1,KEY2,KEY3
```

## Environment variables

| Variable | Required by | Description |
|---|---|---|
| `DATABASE_URL` | `db.postgres` | PostgreSQL connection string (local dev) |
| `DB_ENDPOINT` | `db.postgres` | RDS endpoint (AWS ECS — required when `DATABASE_URL` is not set) |
| `ENV` | `db.postgres` | `prod` or `demo` (default: `prod`) |
| `ARCTIC_URI` | `db.arctic` | ArcticDB connection URI (e.g. `lmdb:///path` or `s3://bucket/path`) |
| `OHLCV_EXCHANGE` | `db.arctic` | Exchange name for OHLCV symbols (default: `binance`) |
| `TELEGRAM_BOT_TOKEN` | `notifications` | Telegram bot API token |
| `TELEGRAM_CHAT_ID` | `notifications` | Telegram chat/group ID |

## Dependencies

- `arcticdb`, `boto3`, `pandas`, `requests`, `psycopg2`, `sqlalchemy`, `tabulate`
- Python >= 3.12

## License

MIT
