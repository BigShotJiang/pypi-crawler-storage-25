"""FastAPI generators for kiln."""
