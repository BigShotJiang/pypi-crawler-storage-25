import enum
import logging
from typing import Optional

logger = logging.getLogger('kumoai')


class ComputeType(str, enum.Enum):
    """Compute backend type for a :class:`Session`.

    Determines what kind of shared cluster session is created.
    """
    DATABRICKS_JOB_CLUSTER = "databricks_job_cluster"
    """Reuse a Databricks job cluster across SDK operations."""


class Session:
    """Context manager that groups SDK operations to share a compute cluster.

    When ``compute`` is ``None`` (the default), the session is a no-op
    passthrough — SDK operations run normally without cluster sharing.

    When ``compute`` is set, multiple SDK operations executed within the
    session will all use the same ``data_backend_session_id``, allowing
    them to reuse the same cluster instead of each creating a new one.

    On entry (with a real compute type), a ``SessionOwnerWorkflow`` is
    started on the server side to hold the cluster session open.  On exit,
    the workflow is signalled to release the cluster (or it auto-expires
    after 24 h as a safety net).

    Args:
        compute: The type of compute cluster to share.  ``None`` (default)
            for a no-op session, or
            :attr:`ComputeType.DATABRICKS_JOB_CLUSTER` to share a
            Databricks job cluster.

    Usage::

        import kumoai

        # No-op session (default) — works everywhere:
        with kumoai.Session():
            trainer.fit(graph, tt)

        # Real session — shares a Databricks job cluster:
        with kumoai.Session(compute=kumoai.ComputeType.DATABRICKS_JOB_CLUSTER):
            trainer.fit(graph, tt)
            trainer.predict(...)
    """
    def __init__(self, compute: Optional[ComputeType] = None):
        self.compute = ComputeType(compute) if compute is not None else None
        self.session_id = None
        self.workflow_id = None

    def __enter__(self):
        if self.compute is None:
            return self

        from kumoai import global_state

        existing = getattr(global_state.thread_local,
                           'data_backend_session_id', None)
        if existing:
            raise RuntimeError('Nested kumoai.Session() is not supported')

        try:
            response = global_state.client._post(
                '/sessions', json={
                    'compute_type': self.compute.value,
                })
            response.raise_for_status()
        except Exception as e:
            raise RuntimeError(
                f'Failed to create session: {e}. '
                'Please check that the Kumo deployment is running and '
                'the requested compute type is available.') from e
        result = response.json()
        self.session_id = result['session_id']
        self.workflow_id = result['workflow_id']
        global_state.thread_local.data_backend_session_id = self.session_id
        return self

    def __exit__(self, *args):
        if self.compute is None:
            return False

        from kumoai import global_state

        global_state.thread_local.data_backend_session_id = None
        if self.workflow_id:
            try:
                resp = global_state.client._post(
                    f'/sessions/{self.workflow_id}/release', json={})
                resp.raise_for_status()
            except Exception:
                logger.warning(
                    'Failed to release session %s, will auto-expire',
                    self.workflow_id,
                    exc_info=True,
                )
        return False
