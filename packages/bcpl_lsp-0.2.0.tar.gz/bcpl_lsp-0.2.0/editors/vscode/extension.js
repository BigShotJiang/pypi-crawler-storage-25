const { workspace, window, commands, languages, StatusBarAlignment } = require("vscode");
const { LanguageClient, TransportKind } = require("vscode-languageclient/node");
const path = require("path");
const fs = require("fs");

const VERSION = "0.2.0";

// Regex matching BCPL constructs in the first few KB of a file
const BCPL_SNIFF_RE = /(?:^\s*(?:GET\s+"|SECTION\s+"|LET\s+\w|AND\s+\w|MANIFEST\s*$|GLOBAL\s*$)|\$\(|\$\))/m;

let client;
let statusBarItem;

function findUv() {
  const candidates = [
    path.join(process.env.HOME || "", ".local/bin/uv"),
    path.join(process.env.HOME || "", ".cargo/bin/uv"),
    "/usr/local/bin/uv",
    "/usr/bin/uv",
    "uv",
  ];
  for (const p of candidates) {
    if (p === "uv" || fs.existsSync(p)) return p;
  }
  return "uv";
}

function looksLikeBcpl(text) {
  // Sniff the first 4KB for BCPL constructs
  return BCPL_SNIFF_RE.test(text.slice(0, 4096));
}

function createStatusBar() {
  statusBarItem = window.createStatusBarItem(StatusBarAlignment.Right, 100);
  statusBarItem.command = "bcpl-lsp.menu";
  statusBarItem.tooltip = "BCPL LSP — click for options";
  updateStatus("starting");
  statusBarItem.show();
  return statusBarItem;
}

function updateStatus(state) {
  if (!statusBarItem) return;
  switch (state) {
    case "running":
      statusBarItem.text = `$(check) BCPL LSP v${VERSION}`;
      break;
    case "starting":
      statusBarItem.text = `$(sync~spin) BCPL LSP v${VERSION}`;
      break;
    case "stopped":
      statusBarItem.text = `$(error) BCPL LSP v${VERSION}`;
      break;
  }
}

function currentLogLevel() {
  return workspace.getConfiguration("bcpl").get("logLevel", "info");
}

async function setLogLevel(level) {
  await workspace.getConfiguration("bcpl").update("logLevel", level, true);
  if (client) {
    await client.sendNotification("workspace/didChangeConfiguration", {
      settings: { bcpl: { logLevel: level } },
    });
  }
  window.showInformationMessage(`BCPL LSP log level set to '${level}'`);
}

/** Auto-detect extensionless BCPL files and set their language mode. */
async function detectBcplLanguage(doc) {
  // Skip files that already have a language set (by extension or user choice)
  if (doc.languageId !== "plaintext") return;
  // Only sniff extensionless files
  if (path.extname(doc.fileName)) return;
  // Check if the content looks like BCPL
  const text = doc.getText();
  if (looksLikeBcpl(text)) {
    await languages.setTextDocumentLanguage(doc, "bcpl");
  }
}

async function startClient(context) {
  const config = workspace.getConfiguration("bcpl");
  const serverDir = config.get("server.path");

  let serverOptions;
  if (serverDir) {
    // Development mode: run from a local project directory
    serverOptions = {
      command: findUv(),
      args: ["run", "--directory", serverDir, "bcpl-lsp", "--stdio"],
      transport: TransportKind.stdio,
    };
  } else {
    // Installed mode: expect bcpl-lsp on PATH (e.g. via uv tool install)
    serverOptions = {
      command: "bcpl-lsp",
      args: ["--stdio"],
      transport: TransportKind.stdio,
    };
  }

  const clientOptions = {
    documentSelector: [{ scheme: "file", language: "bcpl" }],
  };

  client = new LanguageClient("bcpl-lsp", "BCPL Language Server", serverOptions, clientOptions);

  client.onDidChangeState(({ newState }) => {
    // 1=Stopped, 2=Starting, 3=Running
    if (newState === 3) {
      updateStatus("running");
      const level = currentLogLevel();
      client.sendNotification("workspace/didChangeConfiguration", {
        settings: { bcpl: { logLevel: level } },
      });
    } else if (newState === 2) {
      updateStatus("starting");
    } else {
      updateStatus("stopped");
    }
  });

  await client.start();
  // Fallback: if onDidChangeState didn't fire, mark as running now
  updateStatus("running");
}

function activate(context) {
  createStatusBar();
  context.subscriptions.push(statusBarItem);

  // Auto-detect BCPL for extensionless files already open
  for (const doc of workspace.textDocuments) {
    detectBcplLanguage(doc);
  }
  // Auto-detect BCPL when new files are opened
  context.subscriptions.push(
    workspace.onDidOpenTextDocument((doc) => detectBcplLanguage(doc))
  );

  // Register the status bar menu command
  const menuCmd = commands.registerCommand("bcpl-lsp.menu", async () => {
    const level = currentLogLevel();
    const items = [
      { label: "$(debug-restart) Restart Language Server", id: "restart" },
      { label: `$(settings-gear) Log Level: ${level}`, description: "Change logging verbosity", id: "logLevel" },
      { label: "$(info) Show Version", id: "version" },
    ];

    const picked = await window.showQuickPick(items, {
      placeHolder: `BCPL LSP v${VERSION}`,
    });
    if (!picked) return;

    switch (picked.id) {
      case "restart":
        await commands.executeCommand("bcpl-lsp.restart");
        break;
      case "logLevel":
        await commands.executeCommand("bcpl-lsp.setLogLevel");
        break;
      case "version":
        await commands.executeCommand("bcpl-lsp.version");
        break;
    }
  });
  context.subscriptions.push(menuCmd);

  // Register restart command
  const restartCmd = commands.registerCommand("bcpl-lsp.restart", async () => {
    updateStatus("starting");
    if (client) {
      await client.stop();
    }
    await startClient(context);
    window.showInformationMessage(`BCPL LSP v${VERSION} restarted`);
  });
  context.subscriptions.push(restartCmd);

  // Register log level picker command
  const logLevelCmd = commands.registerCommand("bcpl-lsp.setLogLevel", async () => {
    const current = currentLogLevel();
    const levels = ["debug", "info", "warning", "error"];
    const items = levels.map((l) => ({
      label: l === current ? `$(check) ${l}` : `     ${l}`,
      id: l,
      picked: l === current,
    }));

    const picked = await window.showQuickPick(items, {
      placeHolder: "Select log level",
    });
    if (picked) {
      await setLogLevel(picked.id);
    }
  });
  context.subscriptions.push(logLevelCmd);

  // Register show version command
  const versionCmd = commands.registerCommand("bcpl-lsp.version", () => {
    window.showInformationMessage(`BCPL LSP v${VERSION}`);
  });
  context.subscriptions.push(versionCmd);

  // Sync log level when user edits settings.json directly
  context.subscriptions.push(
    workspace.onDidChangeConfiguration((e) => {
      if (e.affectsConfiguration("bcpl.logLevel")) {
        const level = currentLogLevel();
        if (client) {
          client.sendNotification("workspace/didChangeConfiguration", {
            settings: { bcpl: { logLevel: level } },
          });
        }
      }
    })
  );

  startClient(context);
}

function deactivate() {
  if (statusBarItem) statusBarItem.dispose();
  if (client) return client.stop();
}

module.exports = { activate, deactivate };
