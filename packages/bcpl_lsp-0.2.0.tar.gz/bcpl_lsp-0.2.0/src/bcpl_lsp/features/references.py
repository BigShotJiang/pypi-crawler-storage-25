"""textDocument/references handler for BCPL."""

from __future__ import annotations
import logging


from lsprotocol import types
from pygls.lsp.server import LanguageServer
from pygls.uris import from_fs_path, to_fs_path


from bcpl_lsp.analysis.scope_resolver import ScopeResolver
from bcpl_lsp.analysis.symbols import SymbolKind
from bcpl_lsp.workspace.indexer import WorkspaceIndex


log = logging.getLogger("bcpl-lsp")

def _find_references(
    scope_resolver: ScopeResolver,
    workspace_index: WorkspaceIndex,
    path: str,
    line: int,
    col: int,
    include_declaration: bool,
) -> list[types.Location]:
    """Find all references to the symbol at (line, col) in path."""
    # Resolve at cursor to find what symbol we're looking for
    rr = scope_resolver.resolve_at(path, line, col)
    if rr is None:
        return []

    target_name = rr.reference.name
    target_sym = rr.symbol

    # For GLOBALs, match by slot number across files
    match_global_slot: int | None = None
    if target_sym is not None and target_sym.kind == SymbolKind.GLOBAL:
        match_global_slot = target_sym.global_number

    locations: list[types.Location] = []

    # Include declaration if requested and we have a resolved symbol
    if include_declaration and target_sym is not None:
        r = target_sym.range
        uri = target_sym.uri or from_fs_path(path)
        if not uri.startswith("file://"):
            uri = from_fs_path(uri)
        locations.append(types.Location(
            uri=uri,
            range=types.Range(
                start=types.Position(line=r.start_line, character=r.start_col),
                end=types.Position(line=r.end_line, character=r.end_col),
            ),
        ))

    # Search all workspace files for references
    for file_path in workspace_index.files():
        resolved_file = scope_resolver.resolve(file_path)

        for ref_resolved in resolved_file.resolved_refs:
            ref = ref_resolved.reference
            sym = ref_resolved.symbol

            # Match by name
            if ref.name != target_name:
                continue

            # For GLOBALs, also verify slot number matches
            if match_global_slot is not None and sym is not None:
                if sym.kind == SymbolKind.GLOBAL and sym.global_number != match_global_slot:
                    continue

            r = ref.range
            uri = ref.uri
            if not uri.startswith("file://"):
                uri = from_fs_path(uri)
            locations.append(types.Location(
                uri=uri,
                range=types.Range(
                    start=types.Position(line=r.start_line, character=r.start_col),
                    end=types.Position(line=r.end_line, character=r.end_col),
                ),
            ))

        # Also check unresolved refs that match by name
        for ref in resolved_file.unresolved_refs:
            if ref.name != target_name:
                continue
            r = ref.range
            uri = ref.uri
            if not uri.startswith("file://"):
                uri = from_fs_path(uri)
            locations.append(types.Location(
                uri=uri,
                range=types.Range(
                    start=types.Position(line=r.start_line, character=r.start_col),
                    end=types.Position(line=r.end_line, character=r.end_col),
                ),
            ))

    return locations


def register(server: LanguageServer) -> None:
    @server.feature(types.TEXT_DOCUMENT_REFERENCES)
    def references(ls: LanguageServer, params: types.ReferenceParams) -> list[types.Location]:
        try:
            from bcpl_lsp.server import _scope_resolver, _workspace_index

            if _scope_resolver is None or _workspace_index is None:
                return []

            path = to_fs_path(params.text_document.uri)
            if path is None:
                return []
            line = params.position.line
            col = params.position.character
            include_decl = params.context.include_declaration

            results = _find_references(
                _scope_resolver, _workspace_index, path, line, col, include_decl
            )
            log.debug("References: %s:%d:%d → %d locations", params.text_document.uri.rsplit("/", 1)[-1], line, col, len(results))
            return results
        except Exception:
            log.debug("references failed", exc_info=True)
            return []
