"""LSP call hierarchy (prepare, incoming, outgoing)."""

from __future__ import annotations
import logging


from lsprotocol import types
from pygls.lsp.server import LanguageServer
from pygls.uris import from_fs_path, to_fs_path


from bcpl_lsp.analysis.call_graph import CallGraph, CallSite
from bcpl_lsp.analysis.symbols import Symbol, SymbolKind


log = logging.getLogger("bcpl-lsp")

def _symbol_to_call_item(sym: Symbol) -> types.CallHierarchyItem:
    """Convert a Symbol to a CallHierarchyItem."""
    uri = sym.uri
    if not uri.startswith("file://"):
        uri = from_fs_path(uri)
    r = sym.range
    lsp_range = types.Range(
        start=types.Position(line=r.start_line, character=r.start_col),
        end=types.Position(line=r.end_line, character=r.end_col),
    )
    kind_map = {
        SymbolKind.FUNCTION: types.SymbolKind.Function,
        SymbolKind.GLOBAL: types.SymbolKind.Variable,
        SymbolKind.VARIABLE: types.SymbolKind.Variable,
        SymbolKind.CONSTANT: types.SymbolKind.Constant,
    }
    return types.CallHierarchyItem(
        name=sym.name,
        kind=kind_map.get(sym.kind, types.SymbolKind.Function),
        uri=uri,
        range=lsp_range,
        selection_range=lsp_range,
    )


def _call_site_range(site: CallSite) -> types.Range:
    r = site.range
    return types.Range(
        start=types.Position(line=r.start_line, character=r.start_col),
        end=types.Position(line=r.end_line, character=r.end_col),
    )


def _find_symbol_by_name(name: str, scope_resolver, index) -> Symbol | None:
    """Find a function/global symbol by name across all workspace files."""
    for file_path in index.files():
        resolved = scope_resolver.resolve(file_path)
        for sym in resolved.symbols:
            if sym.name == name and sym.kind in (
                SymbolKind.FUNCTION, SymbolKind.GLOBAL, SymbolKind.VARIABLE,
            ):
                return sym
    return None


_cached_graph: CallGraph | None = None


def invalidate_call_graph() -> None:
    """Mark the cached call graph as stale."""
    global _cached_graph
    if _cached_graph is not None:
        _cached_graph.invalidate()


def register(server: LanguageServer) -> None:
    """Register call hierarchy handlers on *server*."""

    def _get_graph(scope_resolver, workspace_index) -> CallGraph:
        """Return a cached CallGraph, creating one if needed."""
        global _cached_graph
        if _cached_graph is None:
            _cached_graph = CallGraph(scope_resolver, workspace_index)
        return _cached_graph

    @server.feature(types.TEXT_DOCUMENT_PREPARE_CALL_HIERARCHY)
    def prepare_call_hierarchy(
        ls: LanguageServer, params: types.CallHierarchyPrepareParams,
    ) -> list[types.CallHierarchyItem] | None:
        try:
            from bcpl_lsp.server import _scope_resolver, _workspace_index

            if _scope_resolver is None or _workspace_index is None:
                return None

            uri = params.text_document.uri
            path = to_fs_path(uri)
            if path is None:
                return None
            line = params.position.line
            col = params.position.character

            resolved_ref = _scope_resolver.resolve_at(path, line, col)
            if resolved_ref is None:
                return None

            # If the reference resolved to a symbol, use that
            sym = resolved_ref.symbol
            if sym is None:
                # Try to find by name in workspace
                sym = _find_symbol_by_name(
                    resolved_ref.reference.name, _scope_resolver, _workspace_index,
                )
            if sym is None:
                return None

            if sym.kind not in (SymbolKind.FUNCTION, SymbolKind.GLOBAL, SymbolKind.VARIABLE):
                return None

            log.debug("PrepareCallHierarchy: %s:%d:%d → %s", uri.rsplit("/", 1)[-1], line, col, sym.name)
            return [_symbol_to_call_item(sym)]
        except Exception:
            log.debug("prepare_call_hierarchy failed", exc_info=True)
            return None

    @server.feature(types.CALL_HIERARCHY_INCOMING_CALLS)
    def incoming_calls(
        ls: LanguageServer, params: types.CallHierarchyIncomingCallsParams,
    ) -> list[types.CallHierarchyIncomingCall] | None:
        try:
            from bcpl_lsp.server import _scope_resolver, _workspace_index

            if _scope_resolver is None or _workspace_index is None:
                return None

            item = params.item
            graph = _get_graph(_scope_resolver, _workspace_index)
            callers = graph.callers_of(item.name)

            results: list[types.CallHierarchyIncomingCall] = []
            seen: dict[str, types.CallHierarchyIncomingCall] = {}

            for site in callers:
                caller_sym = _find_symbol_by_name(
                    site.caller_name, _scope_resolver, _workspace_index,
                )
                if caller_sym is None:
                    continue

                key = f"{caller_sym.uri}:{caller_sym.name}"
                if key in seen:
                    seen[key].from_ranges.append(_call_site_range(site))
                else:
                    call = types.CallHierarchyIncomingCall(
                        from_=_symbol_to_call_item(caller_sym),
                        from_ranges=[_call_site_range(site)],
                    )
                    seen[key] = call
                    results.append(call)

            log.debug("IncomingCalls: %s → %d callers", item.name, len(results))
            return results
        except Exception:
            log.debug("incoming_calls failed", exc_info=True)
            return []

    @server.feature(types.CALL_HIERARCHY_OUTGOING_CALLS)
    def outgoing_calls(
        ls: LanguageServer, params: types.CallHierarchyOutgoingCallsParams,
    ) -> list[types.CallHierarchyOutgoingCall] | None:
        try:
            from bcpl_lsp.server import _scope_resolver, _workspace_index

            if _scope_resolver is None or _workspace_index is None:
                return None

            item = params.item
            graph = _get_graph(_scope_resolver, _workspace_index)
            callees = graph.callees_of(item.name)

            results: list[types.CallHierarchyOutgoingCall] = []
            seen: dict[str, types.CallHierarchyOutgoingCall] = {}

            for site in callees:
                callee_sym = _find_symbol_by_name(
                    site.callee_name, _scope_resolver, _workspace_index,
                )
                if callee_sym is None:
                    continue

                key = f"{callee_sym.uri}:{callee_sym.name}"
                if key in seen:
                    seen[key].from_ranges.append(_call_site_range(site))
                else:
                    call = types.CallHierarchyOutgoingCall(
                        to=_symbol_to_call_item(callee_sym),
                        from_ranges=[_call_site_range(site)],
                    )
                    seen[key] = call
                    results.append(call)

            log.debug("OutgoingCalls: %s → %d callees", item.name, len(results))
            return results
        except Exception:
            log.debug("outgoing_calls failed", exc_info=True)
            return []
