# Copyright (c) ZhangYundi.
# Licensed under the MIT License.
# Created on 2025/12/28 15:54
# Description:

"""
因子报告可视化模块

职责：
- 提供因子分析图表的可视化函数
- 所有函数接受已计算的 DataFrame，返回 Plotly Figure
- 不包含任何数据计算逻辑

数据计算请使用 tears 模块
"""
from pathlib import Path
from typing import Sequence, Literal

import mlflow
import pandas as pd
import plotly.graph_objects as go
import polars as pl
from plotly.subplots import make_subplots

from silars.plot.graph import ScatterGraph, BarGraph, HeatmapGraph
from .tears import (
    get_summary_report,
    compute_ic,
    compute_monthly_ic,
    compute_autocorr,
    compute_turnover,
)
from .utils import get_forward_returns_columns
from ..plot import table as Table
from ..plot.utils import guess_plotly_rangebreaks
from ..plot.theme import LAYOUT, AXIS, merge_layout


def title(factor_name: str):
    _title = dict(text=f"""
                    Factor Report<br><sub>{factor_name}</sub>
                    """,
                  x=0.05,
                  y=0.98,
                  yanchor="top",
                  xanchor="left",
                  font=dict(
                      family="Courier New, monospace",
                      size=25,
                      variant="small-caps",
                      weight="bold",
                  ))
    return _title


def plot_group_return(pred_label: pl.DataFrame, N: int = 5, **kwargs) -> tuple:
    """
    绘制分组收益图表

    Parameters
    ----------
    pred_label : pl.DataFrame
        包含 quantile, label 列
    N : int
        分位数数量

    Returns
    -------
    tuple
        (分组收益柱状图, 累计收益曲线图)
    """
    pred_label_drop = pred_label.drop_nulls(subset=["score"])
    grouper = ["date", "time"]

    # demean
    pred_label_demeaned = pred_label.with_columns(
        (pl.col("label") - pl.col("label").mean().over(grouper)).alias("label"))

    t_df = (pred_label_drop
            .select("date", "time", "quantile", "label")
            .group_by("date", "time", "quantile")
            .mean()
            .drop("time")
            .group_by("date", "quantile")
            .sum()
            .sort(by=["date", "quantile"]))

    # 分组平均收益
    group_mean = t_df.group_by("quantile").mean().drop("date")
    group_mean = group_mean.with_columns((pl.col("label") * 1e4).round(2))
    group_mean = group_mean.to_pandas().set_index("quantile", drop=True)

    group_bar_figure = BarGraph(
        group_mean,
        graph_kwargs=dict(marker_color='rgb(255,182,193)',
                          marker_line_color='rgb(255,20,147)',
                          marker_line_width=1.5,
                          opacity=0.8),
    ).figure

    # 累计收益
    long_demeaned = pred_label_demeaned.filter(pl.col("quantile") == str(N))
    long_demeaned = (long_demeaned
                     .select("date", "time", pl.col("label").alias("long-average"))
                     .group_by("date", "time")
                     .mean()
                     .drop("time")
                     .group_by("date")
                     .sum()
                     .sort(by="date"))
    t_df = t_df.pivot(on="quantile", index="date", values="label").join(long_demeaned, on="date", how="left")
    t_df = t_df.with_columns(
        (pl.col(str(N)) - pl.col("1")).alias("long-short"),
    ).to_pandas().set_index("date", drop=True)
    t_df.rename(columns={str(i): f"G{i}" for i in range(1, N + 1)}, inplace=True)
    t_df.index = pd.to_datetime(t_df.index)
    t_df = t_df.dropna(how="all")

    cum_df = (t_df.fillna(0.0) + 1).cumprod() - 1
    group_scatter_figure = ScatterGraph(
        cum_df.loc[:, :"long-average"],
        graph_kwargs=dict(hovertemplate='%{fullData.name}:%{y:.2%}<extra></extra>', ),
    ).figure
    group_scatter_figure.add_trace(
        go.Scatter(
            x=cum_df.index,
            y=cum_df["long-short"],
            mode='lines',
            name="long-short",
            hovertemplate='%{fullData.name}:%{y:.2%}<extra></extra>',
            visible='legendonly'
        )
    )
    return group_bar_figure, group_scatter_figure


def plot_ic(ic_df: pd.DataFrame, show_nature_day: bool = True, **kwargs) -> go.Figure:
    """绘制 IC 柱状图"""
    if show_nature_day:
        date_index = pd.date_range(ic_df.index.min(), ic_df.index.max())
        ic_df = ic_df.reindex(date_index)
    return BarGraph(
        ic_df,
        graph_kwargs=dict(hovertemplate='%{fullData.name}:%{y:.2}<extra></extra>', ),
    ).figure


def plot_ic_analysis(pred_label: pl.DataFrame, show_nature_day: bool = True, **kwargs) -> tuple:
    """
    绘制 IC 相关分析图

    Returns
    -------
    tuple
        (IC柱状图, 月度IC热力图)
    """
    ic_df = compute_ic(pred_label)
    ic_bar_figure = plot_ic(ic_df, show_nature_day)

    # 月度 IC 热力图
    ic_series = ic_df.iloc[:, 0]
    monthly_ic = compute_monthly_ic(ic_series)
    month_ic_max = max(abs(monthly_ic.min().min()), abs(monthly_ic.max().max()))

    ic_heatmap_figure = HeatmapGraph(
        monthly_ic,
        graph_kwargs=dict(xtype="array",
                          ytype="array",
                          showscale=False,
                          colorscale=[
                              [0, 'green'],
                              [0.5, 'white'],
                              [1, 'red']
                          ],
                          zmin=-month_ic_max,
                          zmax=month_ic_max,
                          texttemplate="%{z:.3}",
                          hovertemplate='%{y}-%{x}:%{z:.4}<extra></extra>'),
    ).figure

    return ic_bar_figure, ic_heatmap_figure


def plot_autocorr(pred_label: pl.DataFrame, lag: int = 1, **kwargs) -> go.Figure:
    """绘制因子自相关图"""
    _df = compute_autocorr(pred_label, lag)
    return ScatterGraph(
        _df,
        graph_kwargs=dict(hovertemplate='%{fullData.name}:%{y:.2}<extra></extra>', ),
    ).figure


def plot_turnover(pred_label: pl.DataFrame, N: int = 5, lag: int = 1, **kwargs) -> go.Figure:
    """绘制换手率图"""
    r_df = compute_turnover(pred_label, N, lag)
    return ScatterGraph(
        r_df,
        graph_kwargs=dict(hovertemplate='%{fullData.name}:%{y:.2}<extra></extra>', ),
    ).figure


def get_report(
        factor_data: pl.DataFrame,
        factor_name: str = "",
        demean: bool = False,
        lag: int = 1,
        N: int = 5,
        show_nature_day: bool = False,
        period: str = "",
        **kwargs, ):
    """生成完整因子报告 HTML（使用 MLflow）"""
    exp = mlflow.set_experiment("alphalens")
    params = {"lag": lag, "N": N, "period": period}

    with mlflow.start_run(experiment_id=exp.experiment_id, run_name=factor_name):
        summary_tb = get_summary_report(factor_data, long_short=demean, group_neutral=False, by_time=True)
        metrics = {"ic": f"{summary_tb['ic'].sum():.3f}",
                   "bottom_bps": f"{summary_tb['bottom_bps'].sum():.2f}",
                   "top_bps": f"{summary_tb['top_bps'].sum():.2f}",
                   "spread_bps": f"{summary_tb['spread_bps'].sum():.2f}"}
        mlflow.log_metrics(metrics)

        table = Table(summary_tb.to_pandas(), highlight_cols=["ic", "top_bps", "bottom_bps", "spread_bps"])

        if not period:
            periods = get_forward_returns_columns(factor_data.columns)
            period = periods[0]
        params["period"] = period
        mlflow.log_params(params)

        pred_label = factor_data.select("date", "time", "asset",
                                        pl.col("factor").alias("score"),
                                        pl.col(period).alias("label"),
                                        pl.col("factor_quantile").alias("quantile"))

        # 生成图表
        group_bar, group_scatter = plot_group_return(pred_label, N, **kwargs)
        ic_bar, ic_heatmap = plot_ic_analysis(pred_label, show_nature_day, **kwargs)
        ac_fig = plot_autocorr(pred_label, lag, **kwargs)
        turnover_fig = plot_turnover(pred_label, N, lag, **kwargs)

        # 组合图表
        fig = _make_report_figure(
            table, group_bar, group_scatter, ic_bar, ic_heatmap, ac_fig, turnover_fig, factor_name
        )

        report_name = f"factor_report.html" if not factor_name else f"factor_report({factor_name}).html"
        report_name = Path("alphalens_output") / exp.name / report_name
        report_name.parent.mkdir(parents=True, exist_ok=True)
        fig.write_html(report_name)
        mlflow.log_artifact(report_name)
    return fig


def report_without_mlflow(
        factor_data: pl.DataFrame,
        demean: bool = False,
        factor_name: str = "",
        lag: int = 1,
        N: int = 5,
        show_nature_day: bool = False,
        period: str = "",
        **kwargs, ):
    """生成因子报告（不使用 MLflow）"""
    params = {"lag": lag, "N": N, "period": period}

    summary_tb = get_summary_report(factor_data, long_short=demean, group_neutral=False, by_time=True)
    metrics = {"ic": f"{summary_tb['ic'].sum():.3f}",
               "bottom_bps": f"{summary_tb['bottom_bps'].sum():.2f}",
               "top_bps": f"{summary_tb['top_bps'].sum():.2f}",
               "spread_bps": f"{summary_tb['spread_bps'].sum():.2f}"}

    table = Table(summary_tb.to_pandas(), highlight_cols=["ic", "top_bps", "bottom_bps", "spread_bps"])

    if not period:
        periods = get_forward_returns_columns(factor_data.columns)
        period = periods[0]
    params["period"] = period

    pred_label = factor_data.select("date", "time", "asset",
                                    pl.col("factor").alias("score"),
                                    pl.col(period).alias("label"),
                                    pl.col("factor_quantile").alias("quantile"))

    # 生成图表
    group_bar, group_scatter = plot_group_return(pred_label, N, **kwargs)
    ic_bar, ic_heatmap = plot_ic_analysis(pred_label, show_nature_day, **kwargs)
    ac_fig = plot_autocorr(pred_label, lag, **kwargs)
    turnover_fig = plot_turnover(pred_label, N, lag, **kwargs)

    # 组合图表
    fig = _make_report_figure(
        table, group_bar, group_scatter, ic_bar, ic_heatmap, ac_fig, turnover_fig, factor_name
    )

    return fig, metrics


def _make_report_figure(table, group_bar, group_scatter, ic_bar, ic_heatmap, ac_fig, turnover_fig, factor_name):
    """组装报告图表"""
    specs = [
        [{"type": "table", "colspan": 2}, None],
        [{"type": "bar", "colspan": 2}, None],
        [{"type": "scatter", "colspan": 2}, None],
        [{"type": "bar", "colspan": 2}, None],
        [{"type": "xy", "colspan": 2}, None],
        [{"type": "scatter", "colspan": 2}, None],
        [{"type": "scatter", "colspan": 2}, None],
    ]
    row_heights = [2, 2, 2, 2, 2, 2, 2]
    rows = len(specs)
    cols = len(specs[0])

    fig = make_subplots(
        rows=rows, cols=cols, specs=specs,
        vertical_spacing=0.03,
        row_heights=[item / sum(row_heights) for item in row_heights],
        subplot_titles=["Summary(demeaned)", "Group Mean Return", "Cumulative Return",
                        "Information Coefficient (IC)", "Monthly IC",
                        "Auto Correlation", "Top-Bottom Turnover"]
    )

    grid = [
        [table, None],
        [group_bar, None],
        [group_scatter, None],
        [ic_bar, None],
        [ic_heatmap, None],
        [ac_fig, None],
        [turnover_fig, None],
    ]

    for row_id, row_figs in enumerate(grid):
        for col_id, col_fig in enumerate(row_figs):
            if col_fig is None:
                continue
            for k in range(len(col_fig.data)):
                fig.add_trace(col_fig.data[k], row=row_id + 1, col=col_id + 1)
                fig.update_xaxes(**AXIS["xaxis"], row=row_id + 1, col=col_id + 1)
                fig.update_yaxes(**AXIS["yaxis"], row=row_id + 1, col=col_id + 1)

    _title = title(factor_name)
    fig.update_layout(**merge_layout(height=rows * 350, title=_title))
    return fig
