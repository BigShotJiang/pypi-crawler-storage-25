# Copyright (c) ZhangYundi.
# Licensed under the MIT License. 
# Created on 2025/12/23 15:41
# Description:
import math
from typing import Sequence, Literal

import polars as pl
from ..transformer import as_transformer
import numpy as np
import logair
import cvxpy as cp
import polars.selectors as cs
from tqdm.auto import tqdm

@as_transformer
def qcut(score_df: pl.DataFrame, N: int = 10, grouper: Sequence[str] | None = None) -> pl.DataFrame:
    grouper = ["date", "time"] if not grouper else ["date", "time", *grouper]
    labels = [str(i) for i in range(1, N + 1)]
    cat = pl.Enum(labels)
    return (
        score_df
        .drop_nulls(grouper)
        .with_columns(
            pl.col("score")
            .qcut(N,
                  labels=labels,
                  allow_duplicates=True)
            .over(grouper)
            .cast(cat)
            .alias("quantile"))
        .cast({pl.Categorical: pl.Utf8})
        .filter(quantile=str(N))
        .drop("quantile")
        .with_columns(target_weight=(1/pl.col("asset").n_unique()).over("date", "time"))
    )

@as_transformer
def top_k(score_df: pl.DataFrame, num: int = 500, grouper: Sequence[str] | None = None) -> pl.DataFrame:
    """选择 top num 数量"""
    grouper = ["date", "time"] if not grouper else ["date", "time", *grouper]
    return (
        score_df
        .drop_nulls(grouper)
        .group_by(grouper, maintain_order=True)
        .agg(pl.all().top_k_by(k=num, by="score"))
        .explode(pl.all().exclude(grouper))
        .with_columns(target_weight=(1/pl.col("asset").n_unique()).over("date", "time"))
    )

from .mfe import mfe_optimized

@as_transformer
def MFE(score_df: pl.DataFrame,
        weight_bias: float = -1.0,
        indust_bias: float = -1.0,
        style_bias: dict[str, float] | None | float = -1.0,
        weight_limit: float = -1.0,
        to_limit: float = -1.0,
        components_ratio: float = -1.0,
        tc_rate: float = 20e-4,
        bm_w_name: str = "bm_w",
        filtering_ratio: float = 0.2) -> pl.DataFrame:
    """
    最大因子暴露组合:
        - bm_w: 基准个股权重
        - 风格因子: 以 Barra 结尾
        - group: 所属行业

    Parameters
    ----------
    score_df: polars.DataFrame
    weight_bias: float
        最大权重偏离, 偏离绝对值，| weight - bm_w | <= max_weight_bias, 小于0则不做约束
    weight_limit: float
        个股最大权重约束, 小于0则不做约束, 默认不约束
    to_limit: float
        换手约束, 小于0则不做约束，默认不约束
    components_ratio: float
        成分股权重约束, 小于0则不做约束,默认不约束
    indust_bias: float
        行业偏离百分比, 小于0则不做约束, 默认不约束
    style_bias: dict[str, float] | None | float
        风格约束: float 表示所有风格做同样的约束，默认不约束
    tc_rate: float
        交易成本
    bm_w_name: str
        基准个股权重列名
    filtering_ratio: float
        非成分股筛选比例（0-1），默认0.2

    Returns
    -------
    polars.DataFrame

    """
    index = {"date", "time", "asset"} & set(score_df.columns)
    index = list(index)
    score_df = score_df.drop_nulls([*index, "score", "group"]).drop_nans("score")
    check_nan_cols = [*index, "score", bm_w_name]
    bm_w = pl.col(bm_w_name)
    score_df = score_df.with_columns((bm_w.fill_null(0.0).fill_nan(0.0)).alias(bm_w_name))

    if isinstance(style_bias, (float, int)):
        if style_bias < 0:
            style_bias = None
        else:
            style_names = score_df.select(cs.ends_with("Barra")).columns
            style_bias = {style_name: style_bias for style_name in style_names}
    if style_bias is not None:
        check_nan_cols.extend(style_bias.keys())
    if indust_bias >= 0:
        check_nan_cols.append("group")
    # if to_limit >= 0:
    check_nan_cols.append("prev_weight")
    results = list()
    prev_w: pl.DataFrame | None = None
    pbar = tqdm(total=score_df["date"].n_unique(), desc="MFE", ascii="⣀⣄⣤⣦⣶⣷⣿",)
    for i, ((date, ), score_df_) in enumerate(score_df.group_by("date", maintain_order=True)):
        pbar.set_postfix_str(date)
        if prev_w is not None:
            score_df_ = score_df_.join(prev_w.drop("date").rename({"target_weight": "prev_weight"}),
                                       on="asset",
                                       how="left").with_columns(pl.col("prev_weight").fill_null(0.0))
        
        # 准备优化版本参数
        prev_w_assets_set = None
        if prev_w is not None:
            prev_w_assets_set = set(prev_w['asset'].to_list())
        is_first_day = (i == 0)
        
        mfe_params = dict(
            score_df=score_df_,
            weight_bias=weight_bias,
            weight_limit=weight_limit,
            to_limit=to_limit,
            indust_bias=indust_bias,
            components_ratio=components_ratio,
            style_bias=style_bias,
            index=index,
            check_nan_cols=check_nan_cols,
            bm_w_name=bm_w_name,
            tc_rate=tc_rate,
            filtering_ratio=filtering_ratio,
            prev_w_assets=prev_w_assets_set,
            is_first_day=is_first_day,
        )
        w_df = mfe_optimized(**mfe_params)

        # 如果失败，尝试降级处理
        if w_df is None:
            mfe_params["score_df"] = score_df_.drop("prev_weight", strict=False)
            mfe_params["prev_w_assets"] = None
            mfe_params["is_first_day"] = True
            w_df = mfe_optimized(**mfe_params)
            
            if w_df is None:
                w_df = prev_w
        
        w_df: pl.DataFrame = w_df.with_columns(date=pl.lit(date)).drop_nulls()
        results.append(w_df)
        prev_w = w_df
        pbar.update()
    return pl.concat(results)