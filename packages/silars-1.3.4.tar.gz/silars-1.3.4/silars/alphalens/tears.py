# -*- coding: utf-8 -*-
"""
---------------------------------------------
Created on 2024/11/24 下午4:50
@author: ZhangYundi
@email: yundi.xxii@outlook.com
---------------------------------------------

职责：
- 提供因子绩效分析的统计计算函数
- 所有函数返回 DataFrame，不涉及可视化
"""
from itertools import chain

import pandas as pd
import polars as pl

from . import perf
from . import utils

DECIMAL_TO_BPS = 10000


def compute_ic(
        pred_label: pl.DataFrame,
        methods: tuple[str, ...] = ("IC", "Rank IC"),
) -> pd.DataFrame:
    """
    计算 IC (Information Coefficient) 时间序列。

    IC 衡量因子预测值与实际收益之间的相关性，IC 越高说明因子预测能力越强。

    Parameters
    ----------
    pred_label : pl.DataFrame
        包含预测值和实际收益的 DataFrame，必须包含以下列：

        - ``score`` : float
            因子预测值（分数）
        - ``label`` : float
            实际收益/标签
        - ``date`` : date
            交易日期
        - ``time`` : str, optional
            交易时间段（如盘中/盘后），如有则用于更细粒度计算

    methods : tuple[str, ...], optional
        要计算的 IC 方法，默认为 (``"IC"``, ``"Rank IC"``)。
        支持的方法：

        - ``"IC"`` : Pearson 相关系数，衡量线性相关性
        - ``"Rank IC"`` : Spearman 秩相关系数，衡量单调相关性，对异常值更稳健

    Returns
    -------
    pd.DataFrame
        IC 时间序列，index 为日期（``pd.DatetimeIndex``），columns 为方法名。

        ====================  ===============================================
        Index                 日期
        IC 列（如 "IC"）       当日 Pearson IC 均值
        Rank IC 列（如 "Rank IC"） 当日 Spearman IC 均值
        ====================  ===============================================

    See Also
    --------
    compute_monthly_ic : 将日频 IC 聚合为月度 IC。
    perf.factor_information_coefficient : 底层的 IC 计算函数（支持分组中性）。

    Notes
    -----
    - 若存在多个 ``time`` 段，先按 ``(date, time)`` 分组计算，再按 ``date`` 平均
    - 空值行（``score`` 或 ``label`` 为 null）会被自动剔除
    - 返回的 DataFrame 适用于绘制 IC 时序图和计算月度 IC

    Examples
    --------
    >>> ic_df = compute_ic(pred_label)
    >>> ic_df.tail()
                    IC   Rank IC
    date
    2024-01-03  0.045   0.062
    2024-01-04  0.031   0.041
    """
    _methods_mapping = {"IC": "pearson", "Rank IC": "spearman"}
    grouper = ["date", "time"]

    ic_df = (pred_label
             .drop_nulls(subset=grouper)
             .group_by(grouper)
             .agg(pl.corr("score", "label", method=_methods_mapping[m]).alias(m) for m in methods)
             .drop("time")
             .group_by("date")
             .mean().sort(by="date"))
    ic_df = ic_df.to_pandas().set_index("date", drop=True)
    ic_df.index = pd.to_datetime(ic_df.index)
    return ic_df


def compute_monthly_ic(ic_series: pd.Series) -> pd.DataFrame:
    """
    将日频 IC 时间序列聚合为月度 IC 透视表。

    按 ``(year, month)`` 分组计算均值，并自动补齐缺失月份（填充为 NaN），
    输出宽格式 DataFrame（columns = 月份 01~12，index = 年份）。

    Parameters
    ----------
    ic_series : pd.Series
        日频 IC 时间序列，必须满足以下条件：

        - index 为日期（``pd.DatetimeIndex`` 或可转换为日期的字符串）
        - values 为 IC 值（float）

        通常由 ``compute_ic()`` 返回。

    Returns
    -------
    pd.DataFrame
        月度 IC 透视表：

        - index : 年份（字符串），如 ``"2024"``
        - columns : 月份（字符串，补零至两位），如 ``"01"``, ``"02"``, ..., ``"12"``
        - values : 对应年月 IC 的均值

        若某月无数据则该单元格为 NaN。

    See Also
    --------
    compute_ic : 生成日频 IC 时间序列。
    plot_ic_analysis : 绘制月度 IC 热力图。

    Notes
    -----
    - 月份索引基于 IC 时间序列覆盖的年份范围
    - 只补齐该年范围内的月份，不跨年份补全

    Examples
    --------
    >>> ic_df = compute_ic(pred_label)
    >>> monthly_ic = compute_monthly_ic(ic_df["Rank IC"])
    >>> monthly_ic
            01     02     03  ...  12
    2024  0.045  0.031  0.052 ...  NaN
    2025  0.038  0.041  0.033 ...  0.044
    """
    _index = ic_series.index.get_level_values(0).astype("str").str.replace("-", "").str.slice(0, 6)
    _monthly_ic = ic_series.groupby(_index).mean()
    _monthly_ic.index = pd.MultiIndex.from_arrays(
        [_monthly_ic.index.str.slice(0, 4), _monthly_ic.index.str.slice(4, 6)],
        names=["year", "month"],
    )

    # fill month
    _month_list = pd.date_range(
        start=pd.Timestamp(f"{_index.min()[:4]}0101"),
        end=pd.Timestamp(f"{_index.max()[:4]}1231"),
        freq="1ME",
    )
    _years = []
    _month = []
    for _date in _month_list:
        _date = _date.strftime("%Y%m%d")
        _years.append(_date[:4])
        _month.append(_date[4:6])

    fill_index = pd.MultiIndex.from_arrays([_years, _month], names=["year", "month"])
    return _monthly_ic.reindex(fill_index).unstack()


def compute_autocorr(
        pred_label: pl.DataFrame,
        lag: int = 1,
) -> pd.DataFrame:
    """
    计算因子自相关系数时间序列。

    衡量因子在时间维度上的持续性/惯性。自相关高说明因子信号较稳定，
    但也可能预示着换手率低、容易被套利等特征。

    Parameters
    ----------
    pred_label : pl.DataFrame
        包含因子分数的 DataFrame，必须包含以下列：

        - ``asset`` : str
            资产标识符（如股票代码）
        - ``date`` : date
            交易日期
        - ``time`` : str, optional
            交易时间段
        - ``score`` : float
            因子分数

    lag : int, optional
        滞后期数，表示用前第 ``lag`` 天的因子值与当天值做相关性。
        默认为 1（即前后相邻交易日）。设为 0 则无滞后。

    Returns
    -------
    pd.DataFrame
        自相关系数时间序列：

        - index : 日期（``pd.DatetimeIndex``）
        - columns : ``["autocorr"]``
        - values : 当日截面 Spearman 自相关系数均值

    See Also
    --------
    compute_turnover : 因子换手率，用于评估因子稳定性。

    Notes
    -----
    - 使用 Spearman 秩相关计算自相关，对极端值更稳健
    - 先在同一资产内按 ``lag`` 平移因子分数，再按日期聚合计算截面均值
    - 空值（因 lag 导致缺失或原始缺失）会被自动剔除

    Examples
    --------
    >>> ac_df = compute_autocorr(pred_label, lag=1)
    >>> ac_df.tail()
                    autocorr
    date
    2024-01-03     0.82
    2024-01-04     0.79
    """
    df = pred_label.with_columns(
        pl.col("score").shift(lag).over("asset", order_by=["date", "time"]).alias("score_lag")
    )
    _df = df.drop_nulls(["score", "score_lag"]).group_by("date").agg(
        autocorr=pl.corr("score", "score_lag", method="spearman")).sort("date")
    _df = _df.to_pandas().set_index("date", drop=True)
    _df.index = pd.to_datetime(_df.index)
    return _df


def compute_turnover(
        pred_label: pl.DataFrame,
        N: int = 5,
        lag: int = 1,
) -> pd.DataFrame:
    """
    计算分组组合的换手率时间序列。

    换手率衡量因子分组（如五分位数组合）在相邻时期间的持仓变化比例。
    高换手率意味着因子信号不稳定，交易成本可能较高。

    Parameters
    ----------
    pred_label : pl.DataFrame
        包含分组信息的 DataFrame，必须包含以下列：

        - ``quantile`` : str
            分组标签，通常为 ``"1"``（最差组）到 ``str(N)``（最优组）
        - ``asset`` : str
            资产标识符
        - ``date`` : date
            交易日期
        - ``time`` : str
            交易时间段

    N : int, optional
        分位数数量（即总分群数），默认为 5（五分位数组合）。
        用于标识最高组和最低组。

    lag : int, optional
        滞后期数，默认为 1（相邻交易日）。

    Returns
    -------
    pd.DataFrame
        换手率时间序列：

        - index : 日期（``pd.DatetimeIndex``）
        - columns :

          - ``"to:G1"`` : 最差组（quantile="1"）的换手率
          - ``"to:GN"`` : 最优组（quantile=str(N)）的换手率

        - values : 换手率，范围 [0, 1]

        换手率计算公式：已调出的资产数 / 上期持仓总数

    See Also
    --------
    compute_autocorr : 因子自相关，与换手率共同反映因子稳定性。

    Notes
    -----
    - 只计算最低组（G1）和最高组（GN，即 quantile=str(N)）的换手率
    - 换手率 = |当期持仓 - 上期持仓| 的资产数量 / 上期持仓数量
    - 若某期上期无持仓（lag 导致），换手率可能偏高

    Examples
    --------
    >>> turnover_df = compute_turnover(pred_label, N=5, lag=1)
    >>> turnover_df.tail()
                    to:G1   to:G5
    date
    2024-01-03     0.15    0.22
    2024-01-04     0.18    0.19
    """
    pred_label = pred_label.drop_nulls(subset="quantile").filter(
        ((pl.col("quantile") == "1") | (pl.col("quantile") == str(N))))
    grouper = ["quantile", "date", "time"]
    cur_asset_set = pred_label.group_by(grouper).agg(
        pl.col("asset").unique()
    ).sort(by=grouper)
    shift_grouper = ["quantile", "time"]
    prev_asset_set = cur_asset_set.select(
        *grouper,
        pl.col("asset").shift(lag).over(shift_grouper)
    )
    r_df = cur_asset_set.join(
        prev_asset_set, on=grouper, how="left", suffix="_prev"
    ).with_columns(
        pl.col("asset").list.set_difference("asset_prev").alias("asset_diff").list.len().alias("diff_count"),
        pl.col("asset").list.len().alias("cur_count"),
    ).select(
        "quantile", "date", "time",
        (pl.col("diff_count") / pl.col("cur_count")).alias("turnover")
    )
    r_df = r_df.group_by("quantile", "date").mean().drop("time").sort(by="date")
    r_df = r_df.pivot(on="quantile", index="date", values="turnover").to_pandas().set_index("date", drop=True)
    r_df.rename(columns={"1": "to:G1", str(N): f"to:G{N}"}, inplace=True)
    r_df.index = pd.to_datetime(r_df.index)
    return r_df


def get_summary_report(
        factor_data: pl.DataFrame,
        long_short: bool = True,
        group_neutral: bool = True,
        by_time: bool = True,
) -> pl.DataFrame:
    """
    生成因子绩效综合报告。

    报告包含 IC 类指标（IC、IC_IR、IC_t统计量）和收益类指标
    （分组收益、Alpha、Beta、spread 收益等），按不同持有期限展开。

    Parameters
    ----------
    factor_data : pl.DataFrame
        因子分析基础数据，必须包含以下列：

        - ``factor`` : float
            因子暴露值
        - ``factor_quantile`` : int 或 str
            因子分位数分组编号或标签
        - ``date`` : date
            交易日期
        - ``time`` : str, optional
            交易时间段
        - ``group`` : str, optional
            资产所属行业/组别（用于行业中性化）
        - 前向收益列 : 如 ``"1D"``, ``"5D"``, ``"20D"``
            各持有期限的前向收益

    long_short : bool, optional
        是否在多空组合上进行收益计算，默认为 ``True``。

        - ``True`` : 收益按日期/时间段去均值（构建零成本组合）
        - ``False`` : 使用原始收益

    group_neutral : bool, optional
        是否进行行业中性化调整，默认为 ``True``。

        - ``True`` : 按行业分组去均值，消除行业偏差
        - ``False`` : 不做行业中性化

    by_time : bool, optional
        是否在时间维度上分组统计，默认为 ``True``。

        - ``True`` : 同时按日期和时间段分组，返回更细粒度结果
        - ``False`` : 仅按日期聚合

    Returns
    -------
    pl.DataFrame
        综合绩效报告，列为各指标，行按 ``(period, time)`` 展开（``by_time=True`` 时）：

        ============  ===========================================================
        列名           含义
        ============  ===========================================================
        period        持有期限（如 "1D", "5D", "20D"）
        time          时间段（仅 ``by_time=True`` 时存在）
        ic            IC 均值
        icir          IC 均值 / IC 标准差（IC Information Ratio）
        ic_tstat      IC 的 t 统计量（用于显著性检验）
        bottom_bps    最差组（因子最低）收益，单位 basis point
        bottom_tstat  最差组收益的 t 统计量
        top_bps       最优组（因子最高）收益，单位 basis point
        top_tstat     最优组收益的 t 统计量
        spread_bps    多空 spread 收益，单位 basis point
        spread_tstat  spread 收益的 t 统计量
        ann_alpha     年化 Alpha（基于 CAPM 回归）
        alpha_tstat   Alpha 的 t 统计量
        beta          组合 Beta
        ============  ===========================================================

    See Also
    --------
    get_ic_report : 独立的 IC 报告（不含收益指标）。
    report.plot_ic_analysis : IC 指标的可视化。
    report.plot_group_return : 分组收益的可视化。

    Notes
    -----
    - 收益类指标默认乘以 10000 转换为 basis point（bps）
    - IC_tstat = IC 均值 / (IC 标准差 / sqrt(IC 数量))，用于检验 IC 是否显著非零
    - alpha/beta 来自因子收益与市场收益的横截面回归

    Examples
    --------
    >>> report = get_summary_report(factor_data, long_short=True, group_neutral=False)
    >>> report.head()
        period  time      ic   icir  ic_tstat  bottom_bps  top_bps  spread_bps
    0     1D     09:30  0.032  1.12     2.34      -8.50      12.30       20.80
    1     5D     09:30  0.041  1.35     2.89      -15.20     18.70       33.90
    """
    alpha_beta = perf.factor_alpha_beta(factor_data,
                                        demeaned=long_short,
                                        by_time=by_time,
                                        group_adjust=group_neutral,
                                        )
    mean_ret_quantile, std_err_ret, mean_ret_quantile_t_stat = perf.mean_return_by_quantile(factor_data,
                                                                                            by_time=by_time,
                                                                                            by_group=False,
                                                                                            demeaned=long_short,
                                                                                            group_adjust=group_neutral)
    mean_ret_spread_quantile, std_err_spread, mean_ret_spread_quantile_t_stat = perf.compute_mean_returns_spread(
        mean_ret_quantile,
        mean_ret_quantile[
            "factor_quantile"].max(),
        mean_ret_quantile[
            "factor_quantile"].min(),
        std_err=std_err_ret)
    periods = utils.get_forward_returns_columns(alpha_beta.columns)
    # 转换为透视表
    select_fields = ["time", "metric"] if by_time else ["metric"]
    select_fields.extend(periods)
    top_mean_ret = (
        mean_ret_quantile
        .filter(
            pl.col("factor_quantile") == pl.col("factor_quantile").max())
        .with_columns(
            pl.lit("top alpha (bps)").alias("metric"),
            *[pl.col(col) * DECIMAL_TO_BPS for col in periods])
    ).select(*select_fields)

    bottom_mean_ret = (
        mean_ret_quantile
        .filter(
            pl.col("factor_quantile") == pl.col("factor_quantile").min())
        .with_columns(
            pl.lit("bottom alpha (bps)").alias("metric"),
            *[pl.col(col) * DECIMAL_TO_BPS for col in periods])
    ).select(*select_fields)

    top_tstat = (
        mean_ret_quantile_t_stat
        .filter(
            pl.col("factor_quantile") == pl.col("factor_quantile").max())
        .with_columns(
            pl.lit("top alpha t-stat").alias("metric"))
    ).select(*select_fields)

    bottom_tstat = (
        mean_ret_quantile_t_stat
        .filter(
            pl.col("factor_quantile") == pl.col("factor_quantile").min())
        .with_columns(
            pl.lit("bottom alpha t-stat").alias("metric"))
    ).select(*select_fields)

    ret_spread = (
        mean_ret_spread_quantile
        .with_columns(
            pl.lit("spread alpha (bps)").alias("metric"),
            *[pl.col(col) * DECIMAL_TO_BPS for col in periods])
    ).select(*select_fields)

    spread_tstat = (
        mean_ret_spread_quantile_t_stat
        .with_columns(
            pl.lit("spread alpha t-stat").alias("metric"), )
        .select(*select_fields)
    )

    join_tb = pl.concat([
        alpha_beta,
        top_mean_ret,
        top_tstat,
        bottom_mean_ret,
        bottom_tstat,
        ret_spread,
        spread_tstat], how="vertical")

    cols_exclude_metric = pd.Index(join_tb.columns).difference(["time", "metric"] if by_time else ["metric"]).tolist()
    join_tb = join_tb.select(
        *["time", "metric"] if by_time else ["metric"],
        *[pl.col(col).round(3) for col in cols_exclude_metric]
    )

    join_tb = (
        join_tb
        .unpivot(on=periods, index=["time", "metric"] if by_time else "metric", variable_name="period", )
        .pivot(on="metric", values="value", index=["period", "time"] if by_time else "period")
        .select(
            *["period", "time"] if by_time else ["period"],
            pl.col("bottom alpha (bps)").alias("bottom_bps"),
            pl.col("bottom alpha t-stat").alias("bottom_tstat"),
            pl.col("top alpha (bps)").alias("top_bps"),
            pl.col("top alpha t-stat").alias("top_tstat"),
            pl.col("spread alpha (bps)").alias("spread_bps"),
            pl.col("spread alpha t-stat").alias("spread_tstat"),
            pl.col("ann.alpha").alias("ann_alpha"),
            pl.col("alpha t-stat").alias("alpha_tstat"),
            pl.col("beta")
        )
    )
    ic_tb = get_ic_report(factor_data, group_neutral=group_neutral, by_time=by_time, by_group=False)
    join_index = ["period", "time"] if by_time else ["period"]
    return ic_tb.join(join_tb, on=join_index, how="left").sort(by=join_index)


def get_ic_report(
        factor_data: pl.DataFrame,
        group_neutral: bool = True,
        by_time: bool = True,
        by_group: bool = False,
) -> pl.DataFrame:
    """
    生成 IC（Information Coefficient）指标报告。

    报告包含 IC 均值、IC_IR（IC 信息比率）、IC_tstat（显著性 t 统计量），
    按不同持有期限展开。可选按行业分组或时间分段查看。

    Parameters
    ----------
    factor_data : pl.DataFrame
        因子分析基础数据，必须包含以下列：

        - ``factor`` : float
            因子暴露值
        - ``factor_quantile`` : int 或 str
            因子分位数分组编号
        - ``date`` : date
            交易日期
        - ``time`` : str, optional
            交易时间段
        - ``group`` : str, optional
            资产所属行业/组别
        - 前向收益列 : 如 ``"1D"``, ``"5D"``, ``"20D"``

    group_neutral : bool, optional
        是否进行行业中性化计算 IC，默认为 ``True``。
        行业中性化可消除行业轮动对 IC 的影响。

    by_time : bool, optional
        是否在结果中保留时间维度，默认为 ``True``。

        - ``True`` : 返回 ``(period, time)`` 索引的 DataFrame
        - ``False`` : 返回以 ``period`` 为索引的 DataFrame（跨时间聚合）

    by_group : bool, optional
        是否按行业分组分别计算 IC，默认为 ``False``。

        - ``True`` : 结果包含 ``group`` 列，按行业展开
        - ``False`` : 不按行业分组

    Returns
    -------
    pl.DataFrame
        IC 指标报告，列为指标名，行为期限和时间维度：

        ============  ===========================================================
        列名           含义
        ============  ===========================================================
        period        持有期限（如 "1D", "5D", "20D"）
        time          时间段（仅 ``by_time=True`` 时存在）
        group         行业分组（仅 ``by_group=True`` 时存在）
        ic            IC 均值（各期限 IC 的平均值）
        icir          IC_IR = IC 均值 / IC 标准差（信息比率）
        ic_tstat      IC t 统计量 = IC 均值 / (IC 标准差 / sqrt(样本数))
        ============  ===========================================================

    See Also
    --------
    compute_ic : 计算日频 IC 时间序列。
    get_summary_report : 包含 IC 和收益的完整报告。

    Notes
    -----
    - IC 均值：衡量因子预测能力的方向和平均强度
    - IC_IR：信息比率，IC 均值与波动率之比，越高越稳定
    - IC_tstat：t 统计量，|t| > 2 通常认为 IC 显著非零
    - 所有数值列保留 4 位小数

    Examples
    --------
    >>> ic_report = get_ic_report(factor_data, group_neutral=True, by_time=True)
    >>> ic_report.head()
        period  time      ic    icir  ic_tstat
    0     1D     09:30  0.032  1.120   2.340
    1     1D     15:00  0.028  0.980   1.920
    2     5D     09:30  0.041  1.350   2.890
    """
    ic = perf.factor_information_coefficient(factor_data, group_adjust=group_neutral, by_group=by_group,
                                             by_time=by_time).fill_nan(None)
    cols = utils.get_forward_returns_columns(factor_data.columns)

    grouper = []
    if by_time:
        grouper.append("time")
    if by_group:
        grouper.append("group")

    _stat_exprs = list(chain.from_iterable(
        [[pl.col(col).mean().alias(f"{col}_mu"),
          pl.col(col).std().alias(f"{col}_sd"),
          pl.col(col).count().alias(f"{col}_n")] for col in cols]))

    if grouper:
        ic = ic.drop_nulls(subset=grouper)
        ic_stat = ic.group_by(grouper).agg(*_stat_exprs)
    else:
        ic_stat = ic.select(*_stat_exprs)
    tstat = ic_stat.select(
        *grouper,
        *[(pl.col(f"{col}_mu") / (pl.col(f"{col}_sd") / pl.col(f"{col}_n").sqrt())).alias(col) for col in cols],
    ).with_columns(pl.lit("ic_tstat").alias("metric"))
    icmean = ic_stat.select(
        *grouper,
        *[pl.col(f"{col}_mu").alias(col) for col in cols]
    ).with_columns(
        pl.lit("ic").alias("metric")
    )
    icir = ic_stat.select(
        *grouper,
        *[(pl.col(f"{col}_mu") / pl.col(f"{col}_sd")).alias(col) for col in cols]
    ).with_columns(
        pl.lit("icir").alias("metric")
    )
    result = pl.concat([icmean, icir, tstat], how="vertical").select(*grouper, "metric", *cols)
    result = (
        result
        .unpivot(on=cols, index=["time", "metric"] if by_time else "metric", variable_name="period")
        .pivot(on="metric", index=["period", "time"] if by_time else "period")
    )

    if len(grouper) > 0:
        result = result.sort(by=grouper)

    cols_exclude_metric = pd.Index(result.columns).difference(
        ["period", "time", "metric"] if by_time else ["period", "metric"]).tolist()

    return result.select(
        "period", *grouper,
        *[pl.col(col).round(4) for col in cols_exclude_metric],
    )
