"""
Marts: silver -> mart tables (scoreboard, trending lists).
"""

import json
import csv
import duckdb
import pandas as pd
import numpy as np
from pathlib import Path


def _safe_int(val):
    if val is None or str(val) in ("None", "<NA>", "nan", ""):
        return None
    try:
        return int(float(str(val)))
    except (ValueError, TypeError):
        return None


def _safe_int_series(s):
    """Vectorized _safe_int: Series -> nullable int Series."""
    numeric = pd.to_numeric(s, errors="coerce")
    return numeric.where(numeric.notna(), None)


def _clean_str(val):
    """Return val as string if valid, else None."""
    if val is None or pd.isna(val) or str(val) in ("None", "<NA>", "nan"):
        return None
    return str(val)


def _build_scoreboard(con) -> dict:
    """Build scoreboard mart using pivot-based vectorized approach."""
    donemler = [r[0] for r in con.execute(
        "SELECT DISTINCT donem FROM fact_periodic ORDER BY donem"
    ).fetchall()]

    if not donemler:
        print("    [WARN] No periods in fact_periodic")
        return {"meta": {}, "rows": []}

    son_donem = donemler[-1]

    risk_donemler = [r[0] for r in con.execute(
        "SELECT DISTINCT donem FROM fact_periodic WHERE kombine_risk IS NOT NULL ORDER BY donem"
    ).fetchall()]

    base_df = con.execute("""
        SELECT DISTINCT entity_id FROM fact_periodic
        WHERE ews_skor IS NOT NULL OR COALESCE(kombine_risk, 0) > 0
    """).fetchdf()

    entity_ids = [str(e) for e in base_df["entity_id"].tolist()]
    if not entity_ids:
        return {"meta": {"donemler": donemler, "son_donem": son_donem, "n_muta": 0}, "rows": []}

    # Static entity data
    # Depo kolonları var mı kontrol et
    _de_cols = {r[0] for r in con.execute("DESCRIBE dim_entity").fetchall()}
    _has_depo_cols = "son_izleme_kodu" in _de_cols
    _depo_select = ""
    if _has_depo_cols:
        _depo_select = """,
            de.son_izleme_kodu,
            de.risk_grup_kodu,
            de.pgy,
            de.finansman_konu,
            de.tahsis_onay_birimi"""

    _fp_cols = {r[0] for r in con.execute("DESCRIBE fact_periodic").fetchall()}
    _has_fp_depo = "depo_risk" in _fp_cols

    rows_data = con.execute(f"""
        SELECT
            de.entity_id,
            mi.unvan,
            de.segment,
            de.sube_kodu,
            sb.sube_adi,
            de.bolge_kodu,
            sb2.bolge_adi
            {_depo_select}
        FROM dim_entity de
        LEFT JOIN map_identity mi ON de.entity_id = mi.entity_id
        LEFT JOIN ref_sube_bolge sb ON de.sube_kodu = sb.sube_kodu
        LEFT JOIN (
            SELECT DISTINCT ON (bolge_kodu) bolge_kodu, bolge_adi
            FROM ref_sube_bolge ORDER BY bolge_kodu
        ) sb2 ON de.bolge_kodu = sb2.bolge_kodu
        WHERE de.entity_id = ANY($1)
    """, [entity_ids]).fetchdf()

    # Period data
    _fp_extra = ", depo_risk, nakit_risk, gnakit_risk" if _has_fp_depo else ""
    period_data = con.execute(f"""
        SELECT entity_id, donem, ews_skor, kombine_risk, risk_degisim{_fp_extra}
        FROM fact_periodic
        WHERE CAST(entity_id AS VARCHAR) = ANY($1)
    """, [entity_ids]).fetchdf()

    # Normalize entity_id → str ÖNCE (pivot index tipi tutarlı olsun)
    rows_data["entity_id"] = rows_data["entity_id"].astype(str)
    period_data["entity_id"] = period_data["entity_id"].astype(str)

    # ── Pivot period data into wide format (vectorized) ──
    pivots = {}
    for col, prefix in [("ews_skor", "ews"), ("kombine_risk", "r"),
                         ("risk_degisim", "rd")]:
        pv = period_data.pivot_table(
            index="entity_id", columns="donem", values=col, aggfunc="first"
        )
        for d in donemler:
            if d not in pv.columns:
                pv[d] = None
        pv = pv[donemler]
        pv.columns = [f"{prefix}{d}" for d in pv.columns]
        pivots[col] = pv

    # Merge static + pivoted period data
    merged = rows_data.set_index("entity_id").copy()
    for pv in pivots.values():
        merged = merged.join(pv, how="left")

    # ── son_risk (son donem kombine_risk) ──
    son_risk_col = f"r{son_donem}"
    if son_risk_col in merged.columns:
        merged["son_risk"] = _safe_int_series(merged[son_risk_col]).fillna(0).astype(int)
    else:
        merged["son_risk"] = 0

    # ── Son dönem depo risk kırılımı (varsa) ──
    if _has_fp_depo:
        for fp_col, out_col in [("depo_risk", "depo_risk"), ("nakit_risk", "nakit_risk"),
                                 ("gnakit_risk", "gnakit_risk")]:
            if fp_col in period_data.columns:
                last = period_data[period_data["donem"] == son_donem].set_index("entity_id")[fp_col]
                merged[out_col] = _safe_int_series(last.reindex(merged.index))
            else:
                merged[out_col] = None

    # ── Apply _safe_int to risk/rd columns, ews cleanup, df columns ──
    for d in donemler:
        # r{d} -> safe int
        r_col = f"r{d}"
        if r_col in merged.columns:
            merged[r_col] = _safe_int_series(merged[r_col])

        # rd{d} -> safe int
        rd_col = f"rd{d}"
        if rd_col in merged.columns:
            merged[rd_col] = _safe_int_series(merged[rd_col])

        # ews{d} -> "YI" or safe int or None
        ews_col = f"ews{d}"
        if ews_col in merged.columns:
            s = merged[ews_col]
            is_yi = s.astype(str) == "YI"
            is_valid = s.notna() & ~s.astype(str).isin(["None", "<NA>", "nan"])
            numeric = pd.to_numeric(s[~is_yi & is_valid], errors="coerce")
            new_col = pd.Series(None, index=merged.index, dtype=object)
            new_col[is_yi] = "YI"
            valid_num = numeric.dropna()
            if not valid_num.empty:
                new_col[valid_num.index] = valid_num.round().astype(int)
            merged[ews_col] = new_col

        # df{d} = son_risk - r{d}
        df_col = f"df{d}"
        if r_col in merged.columns:
            r_vals = merged[r_col]
            merged[df_col] = np.where(
                r_vals.notna(),
                merged["son_risk"] - r_vals.fillna(0).astype(float).astype(int),
                None
            )
        else:
            merged[df_col] = None


    # ── Clean static string columns ──
    for col in ["unvan", "segment", "sube_adi", "bolge_adi"]:
        if col in merged.columns:
            merged[col] = merged[col].apply(_clean_str)

    for col in ["sube_kodu", "bolge_kodu"]:
        if col in merged.columns:
            merged[col] = _safe_int_series(merged[col])

    # ── Sort by son_risk DESC ──
    merged = merged.sort_values("son_risk", ascending=False)

    # ── Convert to list of dicts ──
    merged = merged.reset_index()
    merged = merged.rename(columns={"entity_id": "muta"})
    rows = merged.to_dict("records")

    # Clean up NaN -> None in dicts (pandas to_dict leaves NaN as float)
    for row in rows:
        for k, v in row.items():
            if isinstance(v, float) and (np.isnan(v) or np.isinf(v)):
                row[k] = None

    bolge_list = sorted(set(r["bolge_adi"] for r in rows if r.get("bolge_adi")))
    sube_list = sorted(set(r["sube_adi"] for r in rows if r.get("sube_adi")))

    meta = {
        "donemler": donemler,
        "risk_donemler": risk_donemler,
        "son_donem": son_donem,
        "n_muta": len(rows),
        "bolge_listesi": bolge_list,
        "sube_listesi": sube_list,
        "pipeline_ts": "dummy_run",
        "notebook": "pipeline_runner",
    }

    # ── Diag index ──
    diag_index = _build_diag_index_slim(con)

    return {"meta": meta, "rows": rows, "diag_index": diag_index}


FLOW_BANDS = ["0-325", "325-500", "500-825", "825-1000", "YI"]


def _score_to_band(ews_val):
    """Map EWS score to band name."""
    if ews_val is None:
        return None
    if ews_val == "YI" or ews_val == -1:
        return "YI"
    try:
        s = int(float(str(ews_val)))
    except (ValueError, TypeError):
        return None
    if s < 325:
        return "0-325"
    elif s < 500:
        return "325-500"
    elif s < 825:
        return "500-825"
    else:
        return "825-1000"


def _score_to_band_vec(series):
    """Vectorized band assignment for a pandas Series."""
    result = pd.Series(None, index=series.index, dtype=object)
    if series.empty:
        return result

    str_s = series.astype(str)
    is_yi = str_s.isin(["YI", "-1"])
    result[is_yi] = "YI"

    mask = ~is_yi & series.notna() & ~str_s.isin(["None", "<NA>", "nan", ""])
    numeric = pd.to_numeric(series[mask], errors="coerce")
    valid = numeric.dropna()

    if not valid.empty:
        result.loc[valid[valid >= 825].index] = "825-1000"
        result.loc[valid[(valid >= 500) & (valid < 825)].index] = "500-825"
        result.loc[valid[(valid >= 325) & (valid < 500)].index] = "325-500"
        result.loc[valid[valid < 325].index] = "0-325"

    return result


def _build_flow_matrix(scoreboard: dict, max_periods: int = 6) -> dict:
    """Build risk flow matrix between consecutive periods (vectorized).

    Args:
        max_periods: Maximum number of periods to include (default 6, son 6 dönem).
    """
    rows = scoreboard.get("rows", [])
    donemler = scoreboard.get("meta", {}).get("donemler", [])
    if len(donemler) < 2 or not rows:
        return {"ALL": []}
    # Son N döneme sınırla
    if len(donemler) > max_periods:
        donemler = donemler[-max_periods:]

    df = pd.DataFrame(rows)
    segments = ["ALL", "KUR-TIC", "KOBI", "MIKRO", "ESKK"]
    result = {seg: [] for seg in segments}
    seg_col = df["segment"].fillna("")

    for i in range(len(donemler) - 1):
        d_from, d_to = donemler[i], donemler[i + 1]

        ews_from = df.get(f"ews{d_from}")
        ews_to = df.get(f"ews{d_to}")
        if ews_from is None or ews_to is None:
            for seg in segments:
                result[seg].append({"from": d_from, "to": d_to, "flows": []})
            continue

        b_from = _score_to_band_vec(ews_from)
        b_to = _score_to_band_vec(ews_to)
        risk = df.get(f"r{d_to}", pd.Series(0, index=df.index))
        risk = pd.to_numeric(risk, errors="coerce").fillna(0).abs()

        valid = b_from.notna() & b_to.notna()
        temp = pd.DataFrame({
            "b_from": b_from[valid],
            "b_to": b_to[valid],
            "risk": risk[valid],
            "segment": seg_col[valid],
        })

        for seg in segments:
            if seg == "ALL":
                seg_df = temp
            else:
                seg_df = temp[temp["segment"] == seg]

            if seg_df.empty:
                result[seg].append({"from": d_from, "to": d_to, "flows": []})
                continue

            agg = seg_df.groupby(["b_from", "b_to"], sort=True).agg(
                risk_tl=("risk", "sum"),
                count=("risk", "size"),
            ).reset_index()

            flows = []
            for _, r in agg.iterrows():
                flows.append({
                    "from_band": r["b_from"], "to_band": r["b_to"],
                    "risk_tl": int(r["risk_tl"]), "count": int(r["count"]),
                })
            result[seg].append({"from": d_from, "to": d_to, "flows": flows})

    return result


def _build_diag_index_slim(con) -> dict:
    """SQL'de aggregate — sadece grup listesi. 42M satır Python'a çekilmez.

    Çıktı: {muta_str: {donem_str: {"bulgular": [], "yeni_gruplar": [...]}}}
    """
    try:
        tables = [r[0] for r in con.execute(
            "SELECT table_name FROM information_schema.tables "
            "WHERE table_name='diag_eus_kapsam_diskalma'"
        ).fetchall()]
        if not tables:
            print("  [DIAG] Tablo yok, atlanıyor")
            return {}

        cols = {r[0] for r in con.execute(
            "SELECT column_name FROM information_schema.columns "
            "WHERE table_name='diag_eus_kapsam_diskalma'"
        ).fetchall()}

        if "grup" in cols and "yeni" in cols:
            # Yeni bulguların grupları — SQL aggregation
            df = con.execute("""
                SELECT CAST(muta AS VARCHAR) AS muta, CAST(donem AS VARCHAR) AS donem,
                       LIST(DISTINCT grup ORDER BY grup) AS gruplar
                FROM diag_eus_kapsam_diskalma
                WHERE yeni = 1 AND grup IS NOT NULL
                  AND CAST(grup AS VARCHAR) NOT IN ('', 'None', 'nan')
                GROUP BY muta, donem
            """).fetchdf()
        elif "katman" in cols:
            # grup yok — katman'dan türet
            df = con.execute("""
                SELECT CAST(muta AS VARCHAR) AS muta, CAST(donem AS VARCHAR) AS donem,
                       LIST(DISTINCT katman ORDER BY katman) AS gruplar
                FROM diag_eus_kapsam_diskalma
                GROUP BY muta, donem
            """).fetchdf()
        else:
            print("  [DIAG] Ne grup ne katman kolonu var")
            return {}

        if df.empty:
            # Yeni bulgu yoksa tüm bulguların grup/katman'ını al
            df = con.execute("""
                SELECT CAST(muta AS VARCHAR) AS muta, CAST(donem AS VARCHAR) AS donem,
                       LIST(DISTINCT COALESCE(grup, katman) ORDER BY COALESCE(grup, katman)) AS gruplar
                FROM diag_eus_kapsam_diskalma
                WHERE COALESCE(grup, katman) IS NOT NULL
                GROUP BY muta, donem
            """).fetchdf()

        if df.empty:
            print("  [DIAG] Bulgu yok")
            return {}

        index = {}
        for _, row in df.iterrows():
            m = str(row["muta"])
            d = str(row["donem"])
            gruplar = row["gruplar"]
            if gruplar is not None and len(gruplar) > 0:
                entry = index.setdefault(m, {}).setdefault(d, {"bulgular": [], "yeni_gruplar": []})
                entry["yeni_gruplar"] = list(gruplar)

        print(f"  [DIAG] slim: {len(index)} firma, {len(df)} firma×dönem")
        return index

    except Exception as e:
        import traceback
        print(f"  [DIAG] slim hata: {e}")
        traceback.print_exc()
        return {}


def _build_diag_index_full(con, entity_ids: list) -> dict:
    """Sadece belirtilen firmaların full diag detayını çek. Admin HTML için."""
    if not entity_ids:
        return {}
    try:
        tables = [r[0] for r in con.execute(
            "SELECT table_name FROM information_schema.tables "
            "WHERE table_name='diag_eus_kapsam_diskalma'"
        ).fetchall()]
        if not tables:
            return {}

        # Temp filtre tablosu
        con.execute("CREATE TEMP TABLE IF NOT EXISTS _diag_filter (muta VARCHAR)")
        con.execute("DELETE FROM _diag_filter")
        con.executemany("INSERT INTO _diag_filter VALUES (?)", [(str(e),) for e in entity_ids])

        # Sadece yeni=1 (delta) — tüm dönemler
        df = con.execute("""
            SELECT d.muta, d.donem, d.katman, d.kriter,
                   d.deger, d.onceki_deger, d.aciklama, d.grup, d.yeni
            FROM diag_eus_kapsam_diskalma d
            INNER JOIN _diag_filter f ON CAST(d.muta AS VARCHAR) = f.muta
            WHERE d.yeni = 1
            ORDER BY d.muta, d.donem, d.katman
        """).fetchdf()

        con.execute("DROP TABLE IF EXISTS _diag_filter")

        if df.empty:
            return {}

        index = {}
        for i in range(len(df)):
            muta = str(df.iloc[i]["muta"])
            donem_str = str(df.iloc[i]["donem"])
            f = {"katman": df.iloc[i]["katman"], "kriter": df.iloc[i]["kriter"]}
            aciklama = df.iloc[i].get("aciklama")
            if aciklama and str(aciklama) not in ("None", "nan", ""):
                f["aciklama"] = str(aciklama)
            v = df.iloc[i]["deger"]
            if v == v:
                f["deger"] = float(v)
            v2 = df.iloc[i]["onceki_deger"]
            if v2 == v2:
                f["onceki"] = float(v2)
            g = df.iloc[i].get("grup")
            if g and str(g) not in ("", "None", "nan"):
                f["grup"] = str(g)
            y = df.iloc[i].get("yeni")
            f["yeni"] = int(y) if y is not None and y == y else 0

            entry = index.setdefault(muta, {}).setdefault(donem_str, {"bulgular": [], "yeni_gruplar": []})
            entry["bulgular"].append(f)
            if f.get("yeni") == 1 and f.get("grup"):
                if f["grup"] not in entry["yeni_gruplar"]:
                    entry["yeni_gruplar"].append(f["grup"])

        print(f"  [DIAG] full: {len(index)} firma, {len(df)} bulgu")
        return index

    except Exception as e:
        import traceback
        print(f"  [DIAG] full hata: {e}")
        traceback.print_exc()
        return {}


def _build_diag_index(con) -> dict:
    """Legacy — slim'e yönlendir. Geriye uyumluluk için korunuyor."""
    return _build_diag_index_slim(con)


def _build_band_snapshot(scoreboard: dict) -> dict:
    """Build per-period risk and count by band (vectorized)."""
    rows = scoreboard.get("rows", [])
    donemler = scoreboard.get("meta", {}).get("donemler", [])
    if not donemler or not rows:
        return {"ALL": []}

    df = pd.DataFrame(rows)
    segments = ["ALL", "KUR-TIC", "KOBI", "MIKRO", "ESKK"]
    result = {seg: [] for seg in segments}
    seg_col = df["segment"].fillna("")

    for d in donemler:
        ews = df.get(f"ews{d}")
        if ews is None:
            for seg in segments:
                result[seg].append({"donem": d, "bands": {}})
            continue

        band = _score_to_band_vec(ews)
        risk = df.get(f"r{d}", pd.Series(0, index=df.index))
        risk = pd.to_numeric(risk, errors="coerce").fillna(0).abs()

        valid = band.notna()
        temp = pd.DataFrame({
            "band": band[valid],
            "risk": risk[valid],
            "segment": seg_col[valid],
        })

        for seg in segments:
            if seg == "ALL":
                seg_df = temp
            else:
                seg_df = temp[temp["segment"] == seg]

            if seg_df.empty:
                result[seg].append({"donem": d, "bands": {}})
                continue

            agg = seg_df.groupby("band").agg(
                risk_tl=("risk", "sum"),
                count=("risk", "size"),
            )
            bands_dict = {
                band_name: {"risk_tl": int(row["risk_tl"]), "count": int(row["count"])}
                for band_name, row in agg.iterrows()
            }
            result[seg].append({"donem": d, "bands": bands_dict})

    return result


def _build_trending_lists(con, scoreboard: dict) -> dict:
    """Build trending lists from scoreboard data (vectorized enrichment)."""
    rows = scoreboard.get("rows", [])
    donemler = scoreboard.get("meta", {}).get("donemler", [])

    empty = {"fastest_rising": [], "regime_change": [], "persistent_high": [],
             "low_but_rising": [], "caught_yi": [], "missed_yi": []}
    if len(donemler) < 2 or not rows:
        return empty

    son = donemler[-1]
    son_1 = donemler[-2] if len(donemler) >= 2 else None
    son_3 = donemler[-4] if len(donemler) >= 4 else donemler[0]

    # ── Vectorized enrichment using DataFrame ──
    df = pd.DataFrame(rows)

    def _ews_num_col(d):
        """Get numeric EWS for a period as Series."""
        col = df.get(f"ews{d}")
        if col is None:
            return pd.Series(np.nan, index=df.index)
        str_col = col.astype(str)
        vals = np.where(
            str_col.isin(["YI", "-1"]), 1000,
            pd.to_numeric(col, errors="coerce")
        ).astype(float)
        return pd.Series(vals, index=df.index)

    df["_score_last"] = _ews_num_col(son)
    df["_score_prev1"] = _ews_num_col(son_1) if son_1 else np.nan
    df["_score_prev3"] = _ews_num_col(son_3)

    df["_delta_1"] = df["_score_last"] - df["_score_prev1"]
    df["_delta_3"] = df["_score_last"] - df["_score_prev3"]

    # Consecutive rise (vectorized)
    # Build score columns for all periods
    period_scores = pd.DataFrame({
        d: _ews_num_col(d) for d in donemler
    }, index=df.index)

    consec = pd.Series(0, index=df.index, dtype=int)
    for i in range(len(donemler) - 1, 0, -1):
        curr = period_scores[donemler[i]]
        prev = period_scores[donemler[i - 1]]
        still_rising = curr.notna() & prev.notna() & (curr > prev) & (consec == (len(donemler) - 1 - i))
        consec = consec + still_rising.astype(int)
    df["_consec"] = consec

    # ── Helper: is YI in given period ──
    def _is_yi_col(d):
        col = df.get(f"ews{d}")
        if col is None:
            return pd.Series(False, index=df.index)
        str_col = col.astype(str)
        return str_col.isin(["YI", "-1"])

    # ── Current-period YI firms ──
    is_yi_son = _is_yi_col(son)
    yi_mutas = set(df.loc[is_yi_son, "muta"])

    # ── always YI ──
    always_yi = pd.Series(True, index=df.index)
    for d in donemler:
        always_yi = always_yi & _is_yi_col(d)

    # ── NEW YI: YI in son but NOT in son-1, not always-YI ──
    is_yi_son1 = _is_yi_col(son_1)
    new_yi_mask = is_yi_son & ~always_yi & ~is_yi_son1
    new_yi = df[new_yi_mask]

    # ── Caught / Missed YI ──
    caught_yi = []
    missed_yi = []
    for _, e in new_yi.iterrows():
        s_prev = e.get("_score_prev1")
        if pd.isna(s_prev):
            s_prev = None
        else:
            s_prev = int(s_prev)

        rapid_rise = False
        if len(donemler) >= 3:
            col_prev2 = f"ews{donemler[-3]}"
            s_prev2_raw = e.get(col_prev2)
            if s_prev2_raw is not None and str(s_prev2_raw) not in ("YI", "-1"):
                try:
                    s_prev2 = int(float(str(s_prev2_raw)))
                except (ValueError, TypeError):
                    s_prev2 = None
            else:
                s_prev2 = None

            if s_prev2 is not None and s_prev2 < 200 and s_prev is not None and s_prev >= 500:
                rapid_rise = True

        prev_high = s_prev is not None and s_prev >= 825

        entry = {
            "muta": e["muta"], "unvan": e.get("unvan"), "son_risk": e["son_risk"],
            "score_last": int(e["_score_last"]) if pd.notna(e["_score_last"]) else None,
        }

        if prev_high or rapid_rise:
            reason_parts = []
            if prev_high:
                reason_parts.append(f"Önceki dönem skor: {s_prev}")
            if rapid_rise:
                reason_parts.append(f"Hızlı yükseliş: {s_prev2}->{s_prev}")
            entry["reason"] = "Yakalandı: " + ", ".join(reason_parts)
            caught_yi.append(entry)
        else:
            prev_str = str(s_prev) if s_prev is not None else "?"
            entry["reason"] = f"Kaçırıldı: Önceki dönem skor {prev_str} (<825)"
            missed_yi.append(entry)

    caught_yi.sort(key=lambda x: x.get("son_risk", 0) or 0, reverse=True)
    missed_yi.sort(key=lambda x: x.get("son_risk", 0) or 0, reverse=True)

    # ── Non-YI firms for other trending lists ──
    non_yi_mask = ~df["muta"].isin(yi_mutas)
    non_yi = df[non_yi_mask]

    # ── Hizli Yukselenler: score >= 500, rising, meaningful delta ──
    fastest_mask = (
        non_yi["_score_last"].notna() & (non_yi["_score_last"] >= 500) &
        non_yi["_delta_3"].notna() & (non_yi["_delta_3"] > 0) &
        non_yi["_delta_1"].notna() & (non_yi["_delta_1"] > 0)
    )
    fastest = non_yi[fastest_mask].sort_values(
        "son_risk", ascending=False, na_position="last"
    )
    fastest_out = [{
        "muta": r["muta"], "unvan": r.get("unvan"), "son_risk": r["son_risk"],
        "score_last": int(r["_score_last"]),
        "delta_3": int(r["_delta_3"]),
        "reason": f"Son 3 dönemde +{int(r['_delta_3'])} puan artış (şu an {int(r['_score_last'])})"
    } for _, r in fastest.iterrows()]

    # ── Band Gecisi (vectorized) ──
    regime_candidates = non_yi[
        non_yi["_score_last"].notna() & (non_yi["_score_last"] >= 500) &
        non_yi["_score_prev1"].notna() & (non_yi["_score_prev1"] < 500)
    ]

    # Pre-compute early signal: first period with 325 <= score < 500
    rc_idx = regime_candidates.index
    early_signal_score = pd.Series(np.nan, index=rc_idx)
    for d in donemler[:-1]:
        scores_d = period_scores.loc[rc_idx, d]
        in_range = scores_d.notna() & (scores_d >= 325) & (scores_d < 500)
        # Only first hit: where not already found
        no_signal_yet = early_signal_score.isna()
        early_signal_score = early_signal_score.where(~(no_signal_yet & in_range), scores_d)

    had_early = early_signal_score.notna()

    # Pre-compute rapid jump: consecutive periods where early<100, mid>=325
    rapid_jump_score = pd.Series(np.nan, index=rc_idx)
    if len(donemler) >= 3:
        for i in range(len(donemler) - 2):
            s_early = period_scores.loc[rc_idx, donemler[i]]
            s_mid = period_scores.loc[rc_idx, donemler[i + 1]]
            is_jump = s_early.notna() & (s_early < 100) & s_mid.notna() & (s_mid >= 325)
            no_jump_yet = rapid_jump_score.isna()
            rapid_jump_score = rapid_jump_score.where(~(no_jump_yet & is_jump), s_mid)

    had_rapid = rapid_jump_score.notna() & ~had_early  # rapid only if no early signal

    # Build regime list
    qualified = regime_candidates[had_early | rapid_jump_score.notna()]
    regime = []
    for idx, e in qualified.iterrows():
        s_curr = int(e["_score_last"])
        if had_early.loc[idx]:
            sig = int(early_signal_score.loc[idx])
            reason = f"Band geçişi: Önceden {sig} skor verilmişti, şimdi {s_curr}"
        else:
            sig = int(rapid_jump_score.loc[idx])
            reason = f"Band geçişi: Hızlı sıçrama ({sig}), şimdi {s_curr}"
        regime.append({
            "muta": e["muta"], "unvan": e.get("unvan"), "son_risk": e["son_risk"],
            "score_last": s_curr, "reason": reason,
        })
    regime.sort(key=lambda x: x.get("score_last", 0), reverse=True)

    # ── Potansiyel YI: >= %75 of last N periods with score >= 825 ──
    n_check = min(6, len(donemler))
    check_periods = donemler[-n_check:]
    min_high_count = max(2, int(n_check * 0.75))

    # Vectorized high count
    high_counts = pd.Series(0, index=non_yi.index, dtype=int)
    for d in check_periods:
        scores = period_scores.loc[non_yi.index, d]
        high_counts = high_counts + (scores.fillna(0) >= 825).astype(int)

    persistent_mask = (high_counts >= min_high_count) & non_yi["son_risk"].notna() & (non_yi["son_risk"] > 0)
    persistent_df = non_yi[persistent_mask].sort_values("son_risk", ascending=False, na_position="last")
    persistent = [{
        "muta": r["muta"], "unvan": r.get("unvan"), "son_risk": r["son_risk"],
        "score_last": int(r["_score_last"]) if pd.notna(r["_score_last"]) else None,
        "reason": f"Son {n_check} dönemin {high_counts.loc[idx]} tanesinde skor >= 825"
    } for idx, r in persistent_df.iterrows()]

    # ── Erken Sinyal: 325 <= score < 825, delta_3 > 100, rising ──
    low_rising_mask = (
        non_yi["_score_last"].notna() &
        (non_yi["_score_last"] >= 325) & (non_yi["_score_last"] < 825) &
        non_yi["_delta_3"].notna() & (non_yi["_delta_3"] >= 100) &
        ~is_yi_son1.loc[non_yi.index] &
        non_yi["_delta_1"].notna() & (non_yi["_delta_1"] > 0)
    )
    low_rising = non_yi[low_rising_mask].sort_values(
        "son_risk", ascending=False, na_position="last"
    )
    low_rising_out = [{
        "muta": r["muta"], "unvan": r.get("unvan"), "son_risk": r["son_risk"],
        "score_last": int(r["_score_last"]),
        "delta_3": int(r["_delta_3"]),
        "reason": f"Erken sinyal: {int(r['_score_last'])} skor, +{int(r['_delta_3'])} artış"
    } for _, r in low_rising.iterrows()]

    # ── Trending limits (risk sıralı, en yüksek riskler önce) ──
    TRENDING_LIMIT = 500

    return {
        "fastest_rising": fastest_out[:TRENDING_LIMIT],
        "regime_change": regime[:TRENDING_LIMIT],
        "persistent_high": persistent[:TRENDING_LIMIT],
        "low_but_rising": low_rising_out[:TRENDING_LIMIT],
        "caught_yi": caught_yi[:TRENDING_LIMIT],
        "missed_yi": missed_yi[:TRENDING_LIMIT],
    }


def _export_sube_bolge_ref(con, output_dir: Path, file_suffix: str = ""):
    """Export ref_sube_bolge as CSV for HTML pipeline adaptor."""
    ref_path = output_dir / f"sube_bolge_ref{file_suffix}.csv"
    rows = con.execute("""
        SELECT sube_kodu, sube_adi, bolge_kodu, bolge_adi
        FROM ref_sube_bolge
        ORDER BY bolge_kodu, sube_kodu
    """).fetchall()
    with open(ref_path, "w", encoding="utf-8", newline="") as f:
        w = csv.writer(f)
        w.writerow(["sube_kodu", "sube_adi", "bolge_kodu", "bolge_adi"])
        w.writerows(rows)
    print(f"    sube_bolge_ref.csv: {len(rows)} rows -> {ref_path}")


def _strip_periods(scoreboard: dict, referans_tarih_list: list):
    """Strip non-reference periods from scoreboard output."""
    ref_set = set(str(d) for d in referans_tarih_list)
    all_donemler = scoreboard["meta"]["donemler"]
    remove_donemler = [d for d in all_donemler if d not in ref_set]

    if not remove_donemler:
        return  # nothing to strip

    for row in scoreboard["rows"]:
        for d in remove_donemler:
            for prefix in ["ews", "r", "rd", "df"]:
                row.pop(f"{prefix}{d}", None)

    kept = [d for d in all_donemler if d in ref_set]
    scoreboard["meta"]["donemler"] = kept
    scoreboard["meta"]["risk_donemler"] = [
        d for d in scoreboard["meta"].get("risk_donemler", []) if d in ref_set
    ]
    if kept:
        scoreboard["meta"]["son_donem"] = kept[-1]

    print(f"    dönem filtresi: {len(all_donemler)} -> {len(kept)} dönem")


def run_marts(db_path: Path, output_dir: Path = None, file_suffix: str = ""):
    """Run all mart builds.

    Args:
        file_suffix: Suffix for output files (e.g. "_test").
    """
    con = duckdb.connect(str(db_path))

    if output_dir is None:
        output_dir = Path(db_path).parent.parent / "outputs" / "json"
    output_dir.mkdir(parents=True, exist_ok=True)

    print("  Building scoreboard mart...")
    scoreboard = _build_scoreboard(con)
    n_rows = len(scoreboard.get("rows", []))
    n_periods = len(scoreboard.get("meta", {}).get("donemler", []))
    print(f"    scoreboard: {n_rows} entities, {n_periods} periods")

    print("  Exporting sube_bolge_ref.csv...")
    _export_sube_bolge_ref(con, output_dir, file_suffix)

    print("  Building trending lists...")
    trending = _build_trending_lists(con, scoreboard)
    for k, v in trending.items():
        print(f"    {k}: {len(v)} entities")

    trending_path = output_dir / f"sample_trending_lists{file_suffix}.json"
    with open(trending_path, "w", encoding="utf-8") as f:
        json.dump(trending, f, ensure_ascii=False, indent=2, default=str)
    print(f"    -> {trending_path}")

    # EUS kapsam dışı teşhis (diag_eus_kapsam_diskalma tablosu)
    diag_index = _build_diag_index(con)

    con.close()

    # Enrich scoreboard rows with trending flags + reasons
    _enrich_with_trending(scoreboard, trending)

    # ML predictions (if model exists)
    try:
        from ews_scoreboard.ml.predict import run_predictions
        print("  Running ML predictions...")
        scoreboard = run_predictions(db_path, scoreboard)
    except ImportError as e:
        print(f"  [ML] Skipping: {e}")
    except Exception as e:
        import traceback
        print(f"  [ML] Error: {e}")
        traceback.print_exc()

    # Flow matrix (band-to-band risk transitions)
    print("  Building flow matrix...")
    flow_matrix = _build_flow_matrix(scoreboard)
    scoreboard["flow_matrix"] = flow_matrix
    all_trans = flow_matrix.get("ALL", [])
    n_transitions = sum(len(t["flows"]) for t in all_trans)
    n_segs = len([s for s in flow_matrix if flow_matrix[s]])
    print(f"    {len(all_trans)} dönem çifti, {n_transitions} akış, {n_segs} segment")

    # Band snapshot (per-period risk distribution)
    band_snapshot = _build_band_snapshot(scoreboard)
    scoreboard["band_snapshot"] = band_snapshot

    # Diag index (ayrı JSON key — array encoding'e dahil değil)
    if diag_index:
        scoreboard["diag_index"] = diag_index

    # ── Strip HTML-only fields from JSON (sube_adi/bolge_adi → ref CSV'den gelir) ──
    for row in scoreboard["rows"]:
        row.pop("sube_adi", None)
        row.pop("bolge_adi", None)

    scoreboard_path = output_dir / f"sample_scoreboard{file_suffix}.json"
    with open(scoreboard_path, "w", encoding="utf-8") as f:
        json.dump(scoreboard, f, ensure_ascii=False, separators=(",", ":"), default=str)
    print(f"    -> {scoreboard_path}")

    print("  Rendering HTML dashboards...")
    from ews_scoreboard.pipeline.html_render import render_html
    ref_csv = output_dir / f"sube_bolge_ref{file_suffix}.csv"
    html_dir = output_dir.parent / "html"
    html_dir.mkdir(parents=True, exist_ok=True)

    # 1. Tum firmalar (dict geçir — sıfır JSON read)
    html_all = html_dir / f"ews_dashboard{file_suffix}.html"
    render_html(scoreboard, html_all, ref_csv, max_size_mb=12.5)

    # 2. Yonetici: KUR-TIC tamamı + KOBI ilk 10K (risk sıralı) + risk>50M herkes
    _rows = scoreboard.get("rows", [])
    _kobi = [r for r in _rows if r.get("segment") == "KOBI"]
    _kobi.sort(key=lambda r: r.get("son_risk") or 0, reverse=True)
    _kobi_top = {r["muta"] for r in _kobi[:10_000]}

    def _yonetici_filter(r):
        seg = r.get("segment", "")
        risk = r.get("son_risk") or 0
        if seg == "KUR-TIC":
            return True
        if seg == "KOBI" and r.get("muta") in _kobi_top:
            return True
        if risk > 50_000_000:
            return True
        return False

    html_yon = html_dir / f"ews_dashboard_yonetici{file_suffix}.html"
    render_html(scoreboard, html_yon, ref_csv,
                row_filter=_yonetici_filter, max_size_mb=12.5)

    # 3. Admin HTML: ML tahminleri + backtest özeti + full diag
    print("  Building admin data...")
    con_bt = duckdb.connect(str(db_path))
    backtest_summary = _build_backtest_summary(con_bt)
    backtest_firma = _build_backtest_firma_lists(con_bt)
    ml_predictions = _build_ml_predictions_list(scoreboard)
    # Admin firmaları için filtreleme
    admin_entity_ids = [str(r["muta"]) for r in _rows if _yonetici_filter(r)]
    admin_mutas = set(admin_entity_ids)

    # Full diag detail (slim yerine) — yeni=1 + son 4 dönem
    diag_index_full = _build_diag_index_full(con_bt, admin_entity_ids)
    con_bt.close()

    # backtest_firma: sadece admin firmaları
    bt_firma_filtered = {}
    for model, cats in backtest_firma.items():
        if cats is None:
            bt_firma_filtered[model] = None
            continue
        bt_firma_filtered[model] = {
            cat: [i for i in ids if str(i) in admin_mutas]
            for cat, ids in cats.items()
        }
    _bt_before = sum(len(v) for c in backtest_firma.values() if c for v in c.values())
    _bt_after = sum(len(v) for c in bt_firma_filtered.values() if c for v in c.values())
    print(f"  [ADMIN] backtest_firma: {_bt_before:,} → {_bt_after:,} ID (admin filtre)")

    # ml_predictions: sadece admin firmaları
    ml_pred_filtered = [
        p for p in ml_predictions
        if str(p.get("entity_id", p.get("muta", ""))) in admin_mutas
    ]
    print(f"  [ADMIN] ml_predictions: {len(ml_predictions):,} → {len(ml_pred_filtered):,} firma (admin filtre)")

    html_admin = html_dir / f"ews_dashboard_admin{file_suffix}.html"
    render_html(scoreboard, html_admin, ref_csv,
                row_filter=_yonetici_filter, max_size_mb=25,
                extra_data={
                    "backtest_summary": backtest_summary,
                    "backtest_firma": bt_firma_filtered,
                    "ml_predictions": ml_pred_filtered,
                    "diag_index_full": diag_index_full,
                    "page_mode": "admin",
                })

    return scoreboard, trending


def _build_backtest_summary(con) -> dict:
    """Backtest tablolarından özet istatistikler çek."""
    summary = {}

    for model in ["eus", "yis", "ml"]:
        table = f"backtest_{model}"
        try:
            tables = [r[0] for r in con.execute(
                f"SELECT table_name FROM information_schema.tables WHERE table_name='{table}'"
            ).fetchall()]
            if not tables:
                summary[model] = None
                continue

            df = con.execute(f"SELECT * FROM {table} ORDER BY 1").fetchdf()
            if df.empty:
                summary[model] = None
                continue

            if model == "ml":
                # ML fold yapısı farklı
                info = {
                    "fold_detay": df.to_dict("records"),
                    "toplam_fold": len(df),
                    "ort_auc": round(df["auc"].mean(), 4) if "auc" in df.columns else None,
                    "ort_precision": round(df["precision_val"].mean(), 4) if "precision_val" in df.columns else None,
                    "ort_recall": round(df["recall_val"].mean(), 4) if "recall_val" in df.columns else None,
                    "ort_f1": round(df["f1"].mean(), 4) if "f1" in df.columns else None,
                }
            else:
                info = {
                    "donem_metrikleri": df.to_dict("records"),
                    "toplam_donem": len(df),
                    "toplam_tp": int(df["tp"].sum()) if "tp" in df.columns else 0,
                    "toplam_fp": int(df["fp"].sum()) if "fp" in df.columns else 0,
                    "toplam_fn": int(df["fn"].sum()) if "fn" in df.columns else 0,
                    "toplam_tn": int(df["tn"].sum()) if "tn" in df.columns else 0,
                    "ort_precision": round(df["precision_val"].mean(), 4) if "precision_val" in df.columns else None,
                    "ort_recall": round(df["recall_val"].mean(), 4) if "recall_val" in df.columns else None,
                    "ort_f1": round(df["f1"].mean(), 4) if "f1" in df.columns else None,
                }
            summary[model] = info
        except Exception as e:
            import traceback
            print(f"  [BACKTEST] {model}: {e}")
            traceback.print_exc()
            summary[model] = None

    has_any = any(v is not None for v in summary.values())
    if has_any:
        print(f"  [BACKTEST] Özet: {', '.join(k for k, v in summary.items() if v)}")
    else:
        print(f"  [BACKTEST] Tablo yok, atlanıyor")
    return summary


def _build_ml_predictions_list(scoreboard: dict, prob_threshold: float = 0.3) -> list:
    """Scoreboard'dan yi_prob >= threshold olan firmaları çek."""
    preds = []
    for row in scoreboard.get("rows", []):
        prob = row.get("_ml_yi_prob")
        if prob is not None and prob >= prob_threshold:
            preds.append({
                "muta": row.get("muta"),
                "unvan": row.get("unvan"),
                "segment": row.get("segment"),
                "son_risk": row.get("son_risk"),
                "yi_prob": round(prob, 4),
                "neden": row.get("_ews_neden", ""),
            })
    preds.sort(key=lambda x: x.get("son_risk") or 0, reverse=True)
    print(f"  [ML] yi_prob >= {prob_threshold}: {len(preds)} firma")
    return preds


def _build_backtest_firma_lists(con) -> dict:
    """Backtest firma tablolarından TP/FP/FN listelerini çek."""
    lists = {}
    for model in ["eus", "yis", "ml"]:
        table = f"backtest_{model}_firma"
        try:
            tables = [r[0] for r in con.execute(
                f"SELECT table_name FROM information_schema.tables WHERE table_name='{table}'"
            ).fetchall()]
            if not tables:
                lists[model] = None
                continue
            df = con.execute(f"""
                SELECT DISTINCT CAST(entity_id AS VARCHAR) AS entity_id, kategori
                FROM {table}
                WHERE kategori IN ('TP','FP','FN')
            """).fetchdf()
            if df.empty:
                lists[model] = None
                continue
            lists[model] = {
                "tp": df.loc[df["kategori"] == "TP", "entity_id"].tolist(),
                "fp": df.loc[df["kategori"] == "FP", "entity_id"].tolist(),
                "fn": df.loc[df["kategori"] == "FN", "entity_id"].tolist(),
            }
        except Exception as e:
            import traceback
            print(f"  [BACKTEST] {model} firma: {e}")
            traceback.print_exc()
            lists[model] = None

    has_any = any(v is not None for v in lists.values())
    if has_any:
        for m, v in lists.items():
            if v:
                tp_n = len(v["tp"])
                fn_n = len(v["fn"])
                fp_n = len(v["fp"])
                print(f"  [BACKTEST] {m} firma: TP={tp_n}, FN={fn_n}, FP={fp_n}")
    return lists


def _enrich_with_trending(scoreboard: dict, trending: dict):
    """Add trending flags and reason text to scoreboard rows."""
    flag_map = {
        "fastest_rising": "_hizli_yukselen",
        "regime_change": "_rejim_degisimi",
        "persistent_high": "_potansiyel_yi",
        "low_but_rising": "_erken_sinyal",
        "caught_yi": "_yakalanan",
        "missed_yi": "_kacirilan",
    }
    # Build muta -> reasons mapping
    muta_flags = {}  # muta -> {flag: True, ...}
    muta_reasons = {}  # muta -> [reason1, reason2, ...]

    for list_key, flag_name in flag_map.items():
        for item in trending.get(list_key, []):
            m = str(item.get("muta", ""))
            if m not in muta_flags:
                muta_flags[m] = {}
                muta_reasons[m] = []
            muta_flags[m][flag_name] = 1
            reason = item.get("reason", "")
            if reason:
                muta_reasons[m].append(reason)

    # Apply to scoreboard rows
    for row in scoreboard.get("rows", []):
        m = str(row.get("muta", ""))
        flags = muta_flags.get(m, {})
        row["_hizli_yukselen"] = flags.get("_hizli_yukselen", 0)
        row["_rejim_degisimi"] = flags.get("_rejim_degisimi", 0)
        row["_potansiyel_yi"] = flags.get("_potansiyel_yi", 0)
        row["_erken_sinyal"] = flags.get("_erken_sinyal", 0)
        row["_yakalanan"] = flags.get("_yakalanan", 0)
        row["_kacirilan"] = flags.get("_kacirilan", 0)
        row["_ews_neden"] = " | ".join(muta_reasons.get(m, [])) if m in muta_reasons else ""

    # Stats
    n = sum(1 for r in scoreboard["rows"] if any(r.get(f, 0) for f in flag_map.values()))
    print(f"    trending flags: {n} entities enriched")
