"""Pipeline smoke test.

Her commit öncesi çalıştır: python -m pytest tests/test_pipeline_smoke.py -v
Herhangi biri FAIL ederse commit yapma.

Pipeline çalıştırmaya gerek yok — sadece yapısal kontroller.
"""

import json
import hashlib
from pathlib import Path
from collections import OrderedDict

import pytest

PKG_DIR = Path(__file__).parent.parent / "src" / "ews_scoreboard"
DATA_DIR = PKG_DIR / "data"


# ── Helpers ──

def _notebook_code_hash(nb_path):
    """Notebook sadece cell source hash'i."""
    nb = json.loads(Path(nb_path).read_text(encoding="utf-8"))
    h = hashlib.md5()
    for cell in nb.get("cells", []):
        src = "".join(cell.get("source", []))
        h.update(src.encode("utf-8"))
    return h.hexdigest()


def _get_notebook_params(nb_path):
    """Notebook parameters cell'indeki parametre adlarını döndür."""
    nb = json.loads(Path(nb_path).read_text(encoding="utf-8"))
    params = set()
    for cell in nb["cells"]:
        if "parameters" in cell.get("metadata", {}).get("tags", []):
            for line in "".join(cell.get("source", [])).split("\n"):
                line = line.strip()
                if "=" in line and not line.startswith("#"):
                    name = line.split("=")[0].strip()
                    if name.isidentifier():
                        params.add(name)
    return params


def _get_pipeline_header_adimlar():
    """Pipeline notebook header tablosundan adım kodlarını çıkar."""
    nb = json.loads((DATA_DIR / "ews_pipeline.ipynb").read_text(encoding="utf-8"))
    src = "".join(nb["cells"][0].get("source", []))
    import re
    return set(re.findall(r"`(\w+)`\s*\|", src))


# ── Tests ──

def test_motor_registry_notebook_var():
    """Motor registry'deki her notebook data/ altında olmalı."""
    from ews_scoreboard.motor import ADIM_REGISTRY
    for kod, info in ADIM_REGISTRY.items():
        nb = DATA_DIR / info["nb"]
        assert nb.exists(), f"{kod}: {info['nb']} bulunamadı → {nb}"


def test_ingest_notebook_source_dir_parametresi():
    """Her ingest notebook SOURCE_DIR veya SOURCE_DIRS parametresi kabul etmeli."""
    from ews_scoreboard.motor import ADIM_REGISTRY
    skip = {"ingest_ddl", "ingest_depo"}  # DDL parametre almaz, depo PARQUET_DIR kullanır
    for kod, info in ADIM_REGISTRY.items():
        if not kod.startswith("ingest_") or kod in skip:
            continue
        nb_path = DATA_DIR / info["nb"]
        params = _get_notebook_params(nb_path)
        has_source = "SOURCE_DIR" in params or "SOURCE_DIRS" in params
        assert has_source, f"{kod} ({info['nb']}): SOURCE_DIR parametresi yok — params: {params}"


def test_pipeline_header_tutarlilik():
    """Pipeline header tablosu Motor registry ile uyumlu olmalı."""
    from ews_scoreboard.motor import ADIM_REGISTRY
    header_codes = _get_pipeline_header_adimlar()
    registry_codes = set(ADIM_REGISTRY.keys())

    missing = registry_codes - header_codes
    extra = header_codes - registry_codes

    assert not missing, f"Registry'de var, header'da yok: {missing}"
    assert not extra, f"Header'da var, registry'de yok: {extra}"


def test_transform_fact_periodic_kolonlari():
    """fact_periodic DDL'deki kolonlar transform INSERT'teki kolonlarla eşleşmeli."""
    ddl = (PKG_DIR / "sql" / "ddl" / "create_tables.sql").read_text(encoding="utf-8")

    # DDL'den fact_periodic kolon adlarını çıkar
    import re
    m = re.search(r"CREATE TABLE IF NOT EXISTS fact_periodic\s*\((.*?)\)", ddl, re.DOTALL)
    assert m, "fact_periodic DDL bulunamadı"
    ddl_cols = []
    for line in m.group(1).split("\n"):
        line = line.strip().rstrip(",")
        if line and not line.startswith("PRIMARY") and not line.startswith("--"):
            col = line.split()[0]
            ddl_cols.append(col)

    # transform.py'den INSERT kolon listesini çıkar
    transform_src = (PKG_DIR / "pipeline" / "transform.py").read_text(encoding="utf-8")
    m2 = re.search(r"INSERT INTO fact_periodic\s*\((.*?)\)", transform_src, re.DOTALL)
    assert m2, "transform.py'de fact_periodic INSERT bulunamadı"
    insert_cols = [c.strip() for c in m2.group(1).replace("\n", " ").split(",")]

    assert set(ddl_cols) == set(insert_cols), (
        f"DDL vs INSERT farkı:\n"
        f"  DDL'de var, INSERT'te yok: {set(ddl_cols) - set(insert_cols)}\n"
        f"  INSERT'te var, DDL'de yok: {set(insert_cols) - set(ddl_cols)}"
    )


def test_notebook_code_hash_metadata_degismez():
    """Notebook metadata değişse bile code hash değişmemeli."""
    import tempfile

    nb1 = {"cells": [{"cell_type": "code", "source": ["x = 1"], "metadata": {},
                       "outputs": [], "execution_count": None}],
            "metadata": {"kernelspec": {"name": "python3"}}, "nbformat": 4, "nbformat_minor": 5}

    nb2 = {"cells": [{"cell_type": "code", "source": ["x = 1"], "metadata": {"tags": ["test"]},
                       "outputs": [{"text": "hello"}], "execution_count": 5}],
            "metadata": {"kernelspec": {"name": "python3", "display_name": "NEW"}},
            "nbformat": 4, "nbformat_minor": 5}

    with tempfile.NamedTemporaryFile(suffix=".ipynb", mode="w", delete=False) as f:
        json.dump(nb1, f)
        p1 = f.name
    with tempfile.NamedTemporaryFile(suffix=".ipynb", mode="w", delete=False) as f:
        json.dump(nb2, f)
        p2 = f.name

    h1 = _notebook_code_hash(p1)
    h2 = _notebook_code_hash(p2)

    Path(p1).unlink()
    Path(p2).unlink()

    assert h1 == h2, f"Aynı kod farklı hash: {h1} != {h2}"


def test_build_features_kolon_adlari():
    """build_features FEATURE_COLS ve DIAG_FEATURE_COLS tanımlı olmalı."""
    from ews_scoreboard.ml.features import FEATURE_COLS, DIAG_FEATURE_COLS

    assert len(FEATURE_COLS) > 20, f"FEATURE_COLS çok az: {len(FEATURE_COLS)}"
    assert "ews_score" in FEATURE_COLS
    assert "risk_current" in FEATURE_COLS
    assert "bolge_kodu" in FEATURE_COLS
    assert len(DIAG_FEATURE_COLS) > 5, f"DIAG_FEATURE_COLS çok az: {len(DIAG_FEATURE_COLS)}"


def test_diag_groups_yapisi():
    """DIAG_GROUPS 7 grup, her grupta icon/color/label olmalı."""
    from ews_scoreboard.diag_groups import DIAG_GROUPS

    assert len(DIAG_GROUPS) == 7, f"7 grup bekleniyor, {len(DIAG_GROUPS)} var"
    for grp, cfg in DIAG_GROUPS.items():
        assert "icon" in cfg, f"{grp}: icon yok"
        assert "color" in cfg, f"{grp}: color yok"
        assert "label" in cfg, f"{grp}: label yok"


def test_feature_info_fi_singleton():
    """FI singleton yüklenebilmeli, temel property'ler çalışmalı."""
    from ews_scoreboard.feature_info import FI

    # JSON yoksa bile fallback boş döner, hata vermez
    assert hasattr(FI, "kik_ciss_cols")
    assert hasattr(FI, "rkd_codes")
    assert hasattr(FI, "delta_exclude_cols")


# ── Stabilizasyon testleri (tekrar eden bug'ları yakalar) ──

def test_entity_id_cast_in_transform():
    """transform.py'de ham muta NOT IN dim_entity karşılaştırması olmamalı."""
    import re
    src = (PKG_DIR / "pipeline" / "transform.py").read_text(encoding="utf-8")

    # "WHERE muta NOT IN (SELECT entity_id ...)" — CAST'siz olmamalı
    dangerous = re.findall(r'WHERE muta NOT IN \(SELECT entity_id', src)
    assert not dangerous, f"CAST'siz muta NOT IN dim_entity: {len(dangerous)} yerde"


def test_entity_id_normalize_before_merge():
    """marts.py'de entity_id astype(str) normalize edilmiş olmalı."""
    src = (PKG_DIR / "pipeline" / "marts.py").read_text(encoding="utf-8")

    # _build_scoreboard'da rows_data ve period_data normalize olmalı
    assert 'rows_data["entity_id"] = rows_data["entity_id"].astype(str)' in src, (
        "rows_data entity_id astype(str) yok"
    )
    assert 'period_data["entity_id"] = period_data["entity_id"].astype(str)' in src, (
        "period_data entity_id astype(str) yok"
    )


def test_son_12_literal_eval():
    """transform.py string list parse ast.literal_eval kullanıyor."""
    src = (PKG_DIR / "pipeline" / "transform.py").read_text(encoding="utf-8")
    assert "literal_eval" in src, "transform.py'de ast.literal_eval yok"
    assert "son_12" in src, "transform.py'de son_12 handling yok"


def test_render_html_accepts_dict():
    """render_html dict parametre kabul ediyor."""
    src = (PKG_DIR / "pipeline" / "html_render.py").read_text(encoding="utf-8")
    assert "isinstance(scoreboard_or_path, dict)" in src, (
        "render_html dict/str ayrımı yapmıyor"
    )


def test_marts_notebook_render_dict():
    """nb_03_marts.ipynb render_html'e scoreboard dict geçiriyor (path değil)."""
    nb = json.loads((DATA_DIR / "nb_03_marts.ipynb").read_text(encoding="utf-8"))
    for cell in nb["cells"]:
        src = "".join(cell.get("source", []))
        if "render_html(" in src:
            # scoreboard_path ile çağrılmamalı
            assert "render_html(scoreboard_path" not in src, (
                "nb_03_marts hâlâ scoreboard_path geçiriyor — dict geçirmeli"
            )


def test_init_workspace_xlsx_cwd():
    """_convert_feature_info_xlsx çalışma dizinindeki xlsx'i de arıyor."""
    from ews_scoreboard import _convert_feature_info_xlsx
    import inspect
    src = inspect.getsource(_convert_feature_info_xlsx)
    # Path("feature_info.xlsx") — CWD arama
    assert 'Path("feature_info.xlsx")' in src, (
        "_convert_feature_info_xlsx CWD'de xlsx aramıyor"
    )


def test_build_scoreboard_has_diag_index():
    """_build_scoreboard çıktısında diag_index anahtarı olmalı."""
    import duckdb
    con = duckdb.connect(":memory:")
    # Minimal tablolar
    con.execute("CREATE TABLE dim_entity (entity_id VARCHAR, segment VARCHAR, bolge_kodu INTEGER, sube_kodu INTEGER, must_tip_kodu VARCHAR, grup_kodu VARCHAR, grup_tanimi VARCHAR, firma_otorize_kodu VARCHAR, aksiyon_sahibi VARCHAR, kri_bolum VARCHAR, son_izleme_kodu VARCHAR, risk_grup_kodu VARCHAR, pgy VARCHAR, finansman_konu VARCHAR, tahsis_onay_birimi VARCHAR)")
    con.execute("INSERT INTO dim_entity (entity_id, segment, bolge_kodu, sube_kodu) VALUES ('1','KOBI',1,100)")
    con.execute("CREATE TABLE fact_periodic (entity_id VARCHAR, donem VARCHAR, ews_skor VARCHAR, ews_kaynak VARCHAR, kombine_risk BIGINT, kredi_risk BIGINT, kik_risk BIGINT, depo_risk BIGINT, nakit_risk BIGINT, gnakit_risk BIGINT, risk_degisim BIGINT, ykn_izl_flag INTEGER, yis_skor INTEGER, yis_ihtimal DOUBLE, yis_label INTEGER, eus_skor DOUBLE, eus_ihtimal DOUBLE, eus_tahmin_label INTEGER, eus_kapsam INTEGER, eus_hedef INTEGER, tfrs_rating VARCHAR, rating_tarihi VARCHAR)")
    con.execute("INSERT INTO fact_periodic (entity_id,donem,ews_skor,ews_kaynak,kombine_risk) VALUES ('1','2601','350','eus',1000000)")
    con.execute("CREATE TABLE map_identity (entity_id VARCHAR, muta VARCHAR, unvan VARCHAR)")
    con.execute("INSERT INTO map_identity VALUES ('1','1','Test')")
    con.execute("CREATE TABLE ref_sube_bolge (sube_kodu INTEGER, sube_adi VARCHAR, bolge_kodu INTEGER, bolge_adi VARCHAR)")
    con.execute("INSERT INTO ref_sube_bolge VALUES (100,'S',1,'B')")

    from ews_scoreboard.pipeline.marts import _build_scoreboard
    sb = _build_scoreboard(con)
    con.close()

    assert "diag_index" in sb, "scoreboard'da diag_index anahtarı yok!"
    assert isinstance(sb["diag_index"], dict), "diag_index dict olmalı"
