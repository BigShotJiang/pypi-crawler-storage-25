# 🚀 Django Plugin Explorer

[![PyPI version](https://fury.io)](https://pypi.org)
[![License: MIT](https://shields.io)](https://opensource.org)
[![Framework: Django](https://shields.io)](https://djangoproject.com)

**Django Plugin Explorer** est une extension chic et minimaliste pour l'interface d'administration Django. Elle permet de visualiser instantanément tous les paquets Python installés dans votre environnement virtuel, directement depuis votre tableau de bord.

---

## ✨ Caractéristiques

- 🎨 **Interface Soft & Modern** : Un design épuré utilisant Tailwind CSS.
- 🛠️ **Audit Rapide** : Listez vos dépendances sans accès au terminal (`pip freeze` visuel).
- 📦 **Zéro Base de Données** : Utilise un modèle virtuel (Proxy), aucune migration SQL n'est requise.
- ⚡ **Léger & Performant** : Utilise les métadonnées natives de Python (`importlib.metadata`).

---

## 📸 Aperçu

L'interface propose une typographie soignée, des badges de version colorés et des effets de survol discrets pour une expérience utilisateur premium.

---

## 🚀 Installation

1. **Installez le package via pip :**

```bash
pip install django-plugin-explorer
