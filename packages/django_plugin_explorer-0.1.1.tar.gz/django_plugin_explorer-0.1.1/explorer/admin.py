from django.contrib import admin
from .models import PluginProxy
import importlib.metadata

@admin.register(PluginProxy)
class PluginExplorerAdmin(admin.ModelAdmin):
    change_list_template = "admin/explorer/list.html"

    # Désactiver les actions de modification (lecture seule)
    def has_add_permission(self, request): return False
    def has_delete_permission(self, request, obj=None): return False
    def has_change_permission(self, request, obj=None): return False

    def changelist_view(self, request, extra_context=None):
        # Récupération de tous les paquets installés via importlib
        pkgs = importlib.metadata.distributions()
        packages = sorted(
            [{"name": p.metadata['Name'], "version": p.version} for p in pkgs],
            key=lambda x: x['name'].lower()
        )
        
        extra_context = extra_context or {}
        extra_context['packages'] = packages
        extra_context['title'] = "Plugin Explorer"
        return super().changelist_view(request, extra_context=extra_context)
