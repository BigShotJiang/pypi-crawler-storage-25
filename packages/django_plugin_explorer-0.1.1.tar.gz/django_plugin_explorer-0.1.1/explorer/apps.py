from django.apps import AppConfig

class ExplorerConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'explorer'
    # C'est ce nom qui s'affichera dans le menu Admin
    verbose_name = 'Gestion des Dépendances' 
