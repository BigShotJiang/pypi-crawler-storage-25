# Ce fichier indique à Python que ce dossier est un package.
# On y définit souvent le chemin vers la configuration de l'App Django.

default_app_config = 'explorer.apps.Config'
