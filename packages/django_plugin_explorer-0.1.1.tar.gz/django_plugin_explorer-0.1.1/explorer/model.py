from django.db import models
from django.contrib.auth.models import User

class PluginProxy(User):  # On hérite de User pour satisfaire Django
    """
    Modèle virtuel (Proxy) pour l'affichage dans l'interface d'administration.
    Aucune table supplémentaire n'est créée en base de données.
    """
    class Meta:
        proxy = True  # Indique que c'est un proxy
        managed = False # Aucune modification de la DB
        verbose_name = "Plugin Installé"
        verbose_name_plural = "Explorateur de Plugins"

    def __str__(self):
        return "Liste des plugins"
