"""Install/uninstall the Cruise daemon as a system service."""

import logging
import platform
import shutil
import subprocess
import sys
from pathlib import Path

logger = logging.getLogger(__name__)

_LABEL = "sh.cruise.daemon"
_PLIST_DIR = Path.home() / "Library" / "LaunchAgents"
_PLIST_PATH = _PLIST_DIR / f"{_LABEL}.plist"
_SYSTEMD_DIR = Path.home() / ".config" / "systemd" / "user"
_SYSTEMD_PATH = _SYSTEMD_DIR / "cruise-daemon.service"
_LOG_DIR = Path.home() / ".cruise" / "logs"


def install() -> None:
    """Install the daemon as a background service and start it."""
    _LOG_DIR.mkdir(parents=True, exist_ok=True)
    cruise_bin = _find_cruise_bin()

    if platform.system() == "Darwin":
        _install_launchd(cruise_bin)
    elif platform.system() == "Linux":
        _install_systemd(cruise_bin)
    else:
        raise RuntimeError(f"Unsupported platform: {platform.system()}")


def uninstall() -> None:
    """Stop and remove the daemon service."""
    if platform.system() == "Darwin":
        _uninstall_launchd()
    elif platform.system() == "Linux":
        _uninstall_systemd()
    else:
        raise RuntimeError(f"Unsupported platform: {platform.system()}")


def start() -> None:
    """Start the daemon service."""
    if platform.system() == "Darwin":
        subprocess.run(["launchctl", "start", _LABEL], check=True)
    else:
        subprocess.run(["systemctl", "--user", "start", "cruise-daemon"], check=True)
    print("Cruise daemon started.")


def stop() -> None:
    """Stop the daemon service."""
    if platform.system() == "Darwin":
        subprocess.run(["launchctl", "stop", _LABEL], check=True)
    else:
        subprocess.run(["systemctl", "--user", "stop", "cruise-daemon"], check=True)
    print("Cruise daemon stopped.")


def status() -> dict:
    """Check if the daemon service is running. Returns status info dict."""
    if platform.system() == "Darwin":
        result = subprocess.run(
            ["launchctl", "list", _LABEL],
            capture_output=True, text=True,
        )
        running = result.returncode == 0
    else:
        result = subprocess.run(
            ["systemctl", "--user", "is-active", "cruise-daemon"],
            capture_output=True, text=True,
        )
        running = result.stdout.strip() == "active"

    return {"running": running, "platform": platform.system()}


# -- macOS launchd --

def _install_launchd(cruise_bin: str) -> None:
    plist = f"""\
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN"
  "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>Label</key>
  <string>{_LABEL}</string>
  <key>ProgramArguments</key>
  <array>
    <string>{cruise_bin}</string>
    <string>daemon</string>
  </array>
  <key>EnvironmentVariables</key>
  <dict>
    <key>PATH</key>
    <string>{_user_path()}</string>
  </dict>
  <key>RunAtLoad</key>
  <true/>
  <key>KeepAlive</key>
  <true/>
  <key>StandardOutPath</key>
  <string>{_LOG_DIR}/daemon.log</string>
  <key>StandardErrorPath</key>
  <string>{_LOG_DIR}/daemon.err</string>
</dict>
</plist>
"""
    _PLIST_DIR.mkdir(parents=True, exist_ok=True)
    _PLIST_PATH.write_text(plist)
    subprocess.run(["launchctl", "load", str(_PLIST_PATH)], check=True)
    print(f"Installed and started Cruise daemon (launchd: {_LABEL})")
    print(f"Logs: {_LOG_DIR}/daemon.log")


def _uninstall_launchd() -> None:
    subprocess.run(["launchctl", "unload", str(_PLIST_PATH)], check=False)
    if _PLIST_PATH.exists():
        _PLIST_PATH.unlink()
    print(f"Uninstalled Cruise daemon (removed {_PLIST_PATH})")


# -- Linux systemd --

def _install_systemd(cruise_bin: str) -> None:
    unit = f"""\
[Unit]
Description=Cruise daemon — local agent executor
After=network.target

[Service]
Environment=PATH={_user_path()}
ExecStart={cruise_bin} daemon
Restart=always
RestartSec=5
StandardOutput=append:{_LOG_DIR}/daemon.log
StandardError=append:{_LOG_DIR}/daemon.err

[Install]
WantedBy=default.target
"""
    _SYSTEMD_DIR.mkdir(parents=True, exist_ok=True)
    _SYSTEMD_PATH.write_text(unit)
    subprocess.run(["systemctl", "--user", "daemon-reload"], check=True)
    subprocess.run(["systemctl", "--user", "enable", "cruise-daemon"], check=True)
    subprocess.run(["systemctl", "--user", "start", "cruise-daemon"], check=True)
    print("Installed and started Cruise daemon (systemd: cruise-daemon)")
    print(f"Logs: {_LOG_DIR}/daemon.log")


def _uninstall_systemd() -> None:
    subprocess.run(["systemctl", "--user", "stop", "cruise-daemon"], check=False)
    subprocess.run(["systemctl", "--user", "disable", "cruise-daemon"], check=False)
    if _SYSTEMD_PATH.exists():
        _SYSTEMD_PATH.unlink()
    subprocess.run(["systemctl", "--user", "daemon-reload"], check=False)
    print(f"Uninstalled Cruise daemon (removed {_SYSTEMD_PATH})")


def _user_path() -> str:
    """Return the current PATH so launchd/systemd inherits it."""
    import os
    return os.environ.get("PATH", "/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin")


def _find_cruise_bin() -> str:
    """Find the cruise executable path."""
    path = shutil.which("cruise")
    if path:
        return path
    # Fallback: use the current Python interpreter's entry point
    return f"{sys.executable} -m cruise.cli"
