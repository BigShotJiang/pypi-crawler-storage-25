# Skills Consumer SDK

Python SDK：调用 Skill 网关（`POST /skill/{url_suffix}`），封装请求头 `bizType`、`bizToken`、请求体与响应解析。

当前发布包仅包含 `skills_sdk` 运行时代码与基础文档；`tests/`、`examples/` 不会打入 wheel / sdist。

## 依赖

运行时仅依赖 **`httpx`**；配置与请求/响应模型使用标准库 **`dataclasses`**。若希望 **自动读取当前目录 `.env`**，请额外安装：`pip install python-dotenv`（或 `pip install "sinohealth-skills-sdk[env]"`），SDK 会在 import 时尝试 `load_dotenv()`。

```bash
pip install sinohealth-skills-sdk
# 或本地开发
pip install -e .
pip install python-dotenv   # 可选，解决「只写 .env 未 export」读不到变量
```

## 对外文档

**接入方请阅读：[docs/SDK_USER_GUIDE.md](docs/SDK_USER_GUIDE.md)**（安装、环境变量、`call_skill` 示例）。

## 快速示例

```bash
export SKILLS_BIZ_TYPE=medmateclaw
export SKILLS_BIZ_TOKEN='你的令牌'
export SKILLS_GATEWAY_BASE_URL='https://higress.sinohealth.com'
```

```python
from skills_sdk import SkillsClient

client = SkillsClient()
r = client.call_skill(
    "ai-mdt/examination-indicators-interpretation",
    {"indicator": "甘油三酯(TG) 2.87mmol/L（参考≤2.30）"},
)
print(r.data)
client.close()
```

可运行脚本：`python examples/examination_indicators_client.py`

## 开发

```bash
pip install -r requirements-dev.txt
pytest
```

## 发布前检查

```bash
python3 -m pip install -U build twine
python3 -m build
python3 -m twine check dist/*
```

## 许可证

MIT
