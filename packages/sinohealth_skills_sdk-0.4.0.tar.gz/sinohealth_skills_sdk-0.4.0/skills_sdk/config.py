"""
配置管理

支持环境变量与构造参数覆盖（网关基址由 SDK 常量固定，不在此配置）。

若已安装可选依赖 ``python-dotenv``，会在首次加载本模块时尝试 ``load_dotenv()``，
把项目根目录下的 ``.env`` 注入进程环境（否则 ``os.getenv`` 读不到仅写在 ``.env`` 里的值）。
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field

from .constants import (
    DEFAULT_TIMEOUT,
    DEFAULT_MAX_RETRIES,
    DEFAULT_RETRY_DELAY,
    DEFAULT_LOG_LEVEL,
    DEFAULT_STREAM,
)


def _load_dotenv_if_available() -> None:
    try:
        from dotenv import load_dotenv
    except ImportError:
        return
    load_dotenv()


_load_dotenv_if_available()


def _env_bool(key: str, default: bool) -> bool:
    raw = os.getenv(key)
    if raw is None or raw.strip() == "":
        return default
    return raw.strip().lower() in ("1", "true", "yes", "on")


@dataclass
class SkillsConfig:
    """
    SDK 配置类

    必填：SKILLS_BIZ_TYPE、SKILLS_BIZ_TOKEN（或通过构造参数传入 biz_type、biz_token）。
    """

    biz_type: str = field(
        default_factory=lambda: os.getenv("SKILLS_BIZ_TYPE", "").strip(),
    )
    biz_token: str = field(
        default_factory=lambda: os.getenv("SKILLS_BIZ_TOKEN", "").strip(),
    )
    trace_identifier: str = field(
        default_factory=lambda: os.getenv("SKILLS_TRACE_IDENTIFIER", "").strip(),
    )
    timeout: float = field(
        default_factory=lambda: float(os.getenv("SKILLS_TIMEOUT", DEFAULT_TIMEOUT)),
    )
    max_retries: int = field(
        default_factory=lambda: int(os.getenv("SKILLS_MAX_RETRIES", DEFAULT_MAX_RETRIES)),
    )
    retry_delay: float = field(default=DEFAULT_RETRY_DELAY)
    enable_logging: bool = field(default=True)
    log_level: str = field(
        default_factory=lambda: os.getenv("SKILLS_LOG_LEVEL", DEFAULT_LOG_LEVEL),
    )
    verify_ssl: bool = field(default=True)
    stream: bool = field(
        default_factory=lambda: _env_bool("SKILLS_STREAM", DEFAULT_STREAM),
    )

    def validate_required(self) -> None:
        if not self.biz_type:
            raise ValueError(
                "bizType 不能为空，请设置环境变量 SKILLS_BIZ_TYPE（如 medmateclaw）或传入 SkillsClient(biz_type=...)"
            )
        if not self.biz_token:
            raise ValueError(
                "bizToken 不能为空，请设置环境变量 SKILLS_BIZ_TOKEN 或传入 SkillsClient(biz_token=...)"
            )
