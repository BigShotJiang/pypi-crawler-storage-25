"""
工具函数

提供辅助功能,如:
- URL 构建
- 日志配置
- 响应解析、流式解析等
"""

from __future__ import annotations

import json
import logging
import sys
from typing import Any, AsyncIterator, Dict, Iterator, Optional

import httpx

from .constants import (
    CONTENT_TYPE_JSON,
    HEADER_BIZ_TOKEN,
    HEADER_BIZ_TYPE,
    HEADER_CONTENT_TYPE,
    HEADER_TRACE_IDENTIFIER,
)
from .models import SkillResponse, StreamChunk


def setup_logger(log_level: str = "INFO", enable_logging: bool = True) -> None:
    """为 ``skills_sdk`` 配置标准库 logging，输出到 stderr。"""
    log = logging.getLogger("skills_sdk")
    log.handlers.clear()
    log.propagate = False
    if not enable_logging:
        log.addHandler(logging.NullHandler())
        log.setLevel(logging.CRITICAL + 1)
        return
    level = getattr(logging, log_level.upper(), logging.INFO)
    log.setLevel(level)
    h = logging.StreamHandler(sys.stderr)
    h.setFormatter(logging.Formatter("%(levelname)s %(name)s %(message)s"))
    log.addHandler(h)


def build_skill_url(gateway_url: str, url_suffix: str) -> str:
    """
    构建完整的 Skill API URL：{gateway}/skill/{url_suffix}

    调用方只传 url_suffix（即完整 URL 里 /skill/ 之后的部分），不要带 /skill/ 前缀。
    """
    base = gateway_url.rstrip("/")
    suffix = url_suffix.strip().lstrip("/")
    return f"{base}/skill/{suffix}"


def build_headers(
    biz_type: str,
    biz_token: str,
    trace_identifier: str = "",
    extra_headers: Optional[Dict[str, str]] = None,
) -> Dict[str, str]:
    headers: Dict[str, str] = {
        HEADER_BIZ_TYPE: biz_type.strip(),
        HEADER_BIZ_TOKEN: biz_token.strip(),
        HEADER_CONTENT_TYPE: CONTENT_TYPE_JSON,
    }
    if trace_identifier and trace_identifier.strip():
        headers[HEADER_TRACE_IDENTIFIER] = trace_identifier.strip()
    if extra_headers:
        headers.update(extra_headers)
    return headers


def parse_response(response_data: Any) -> Dict[str, Any]:
    """将任意结构尽量归一为 dict，便于下游处理。"""
    if isinstance(response_data, dict):
        return response_data
    if isinstance(response_data, str):
        try:
            parsed = json.loads(response_data)
            return parsed if isinstance(parsed, dict) else {"data": parsed}
        except json.JSONDecodeError:
            return {"data": response_data}
    return {"data": response_data}


def skill_response_from_http_response(response: httpx.Response) -> SkillResponse:
    """将已成功状态码下的 HTTP 响应体解析为 SkillResponse。"""
    meta: Dict[str, Any] = {"http_status": response.status_code}
    try:
        payload = response.json()
    except Exception:
        return SkillResponse(
            success=True,
            data=response.text,
            metadata=meta,
        )
    if isinstance(payload, dict) and "success" in payload:
        extra = {
            k: v
            for k, v in payload.items()
            if k not in ("success", "data", "error")
        }
        return SkillResponse(
            success=bool(payload.get("success")),
            data=payload.get("data"),
            error=payload.get("error"),
            metadata={**meta, **extra},
        )
    return SkillResponse(success=True, data=payload, metadata=meta)


def iter_stream_http_response(response: httpx.Response) -> Iterator[StreamChunk]:
    """
    消费流式 HTTP 响应，产出 StreamChunk。

    支持 text/event-stream（解析 data: 行）及按行 JSON / 纯文本行。
    """
    ctype = (response.headers.get("content-type") or "").lower()
    chunk_id = 0

    if "text/event-stream" in ctype:
        for line in response.iter_lines():
            if not line:
                continue
            if line.startswith(":"):
                continue
            if line.startswith("data:"):
                payload = line[5:].lstrip()
                if payload.strip() == "[DONE]":
                    yield StreamChunk(
                        chunk_id=chunk_id, data="", is_final=True, metadata={}
                    )
                    return
                text = _sse_payload_to_text(payload)
                yield StreamChunk(
                    chunk_id=chunk_id,
                    data=text,
                    is_final=False,
                    metadata={},
                )
                chunk_id += 1
            else:
                yield StreamChunk(
                    chunk_id=chunk_id,
                    data=line,
                    is_final=False,
                    metadata={},
                )
                chunk_id += 1
        return

    for line in response.iter_lines():
        if not line:
            continue
        text, is_final = _line_to_stream_payload(line)
        yield StreamChunk(
            chunk_id=chunk_id,
            data=text,
            is_final=is_final,
            metadata={},
        )
        chunk_id += 1
        if is_final:
            return

    if chunk_id == 0:
        raw = response.read().decode(errors="replace")
        if raw:
            yield StreamChunk(chunk_id=0, data=raw, is_final=True, metadata={})


async def aiter_stream_http_response(
    response: httpx.Response,
) -> AsyncIterator[StreamChunk]:
    """异步版流式解析。"""
    ctype = (response.headers.get("content-type") or "").lower()
    chunk_id = 0

    if "text/event-stream" in ctype:
        async for line in response.aiter_lines():
            if not line:
                continue
            if line.startswith(":"):
                continue
            if line.startswith("data:"):
                payload = line[5:].lstrip()
                if payload.strip() == "[DONE]":
                    yield StreamChunk(
                        chunk_id=chunk_id, data="", is_final=True, metadata={}
                    )
                    return
                text = _sse_payload_to_text(payload)
                yield StreamChunk(
                    chunk_id=chunk_id,
                    data=text,
                    is_final=False,
                    metadata={},
                )
                chunk_id += 1
            else:
                yield StreamChunk(
                    chunk_id=chunk_id,
                    data=line,
                    is_final=False,
                    metadata={},
                )
                chunk_id += 1
        return

    async for line in response.aiter_lines():
        if not line:
            continue
        text, is_final = _line_to_stream_payload(line)
        yield StreamChunk(
            chunk_id=chunk_id,
            data=text,
            is_final=is_final,
            metadata={},
        )
        chunk_id += 1
        if is_final:
            return

    if chunk_id == 0:
        raw = (await response.aread()).decode(errors="replace")
        if raw:
            yield StreamChunk(chunk_id=0, data=raw, is_final=True, metadata={})


def _sse_payload_to_text(payload: str) -> str:
    try:
        obj = json.loads(payload)
    except json.JSONDecodeError:
        return payload
    if isinstance(obj, dict):
        for key in ("text", "content", "delta", "data", "message"):
            if key in obj:
                inner = obj[key]
                if isinstance(inner, str):
                    return inner
                if isinstance(inner, dict) and "content" in inner:
                    return str(inner.get("content", ""))
        return json.dumps(obj, ensure_ascii=False)
    return str(obj)


def _line_to_stream_payload(line: str) -> tuple[str, bool]:
    try:
        obj = json.loads(line)
    except json.JSONDecodeError:
        return line, False
    if isinstance(obj, dict) and obj.get("done") is True:
        return "", True
    if isinstance(obj, dict):
        for key in ("text", "content", "delta", "data"):
            if key in obj and isinstance(obj[key], str):
                return obj[key], False
    return line, False
