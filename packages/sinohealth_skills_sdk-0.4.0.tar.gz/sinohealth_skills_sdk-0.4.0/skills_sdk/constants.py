"""常量定义。"""

from __future__ import annotations

import os

# HTTP 相关
DEFAULT_TIMEOUT = 30  # 默认超时时间(秒)
DEFAULT_MAX_RETRIES = 3  # 默认最大重试次数
DEFAULT_RETRY_DELAY = 1.0  # 默认重试延迟(秒)

# 日志相关
DEFAULT_LOG_LEVEL = "INFO"

# 请求体：是否流式（可由环境变量 SKILLS_STREAM 覆盖，单次调用仍可覆盖客户端默认值）
DEFAULT_STREAM = False

# 网关基址（不含尾部斜杠；实际请求为 {SKILLS_GATEWAY_BASE_URL}/skill/{url_suffix}）
DEFAULT_SKILLS_GATEWAY_BASE_URL = "https://higress.sinohealth.com"
SKILLS_GATEWAY_BASE_URL = os.getenv(
    "SKILLS_GATEWAY_BASE_URL",
    DEFAULT_SKILLS_GATEWAY_BASE_URL,
).strip().rstrip("/")

# API 路径（客户端只传 url_suffix）
SKILL_API_PREFIX = "/skill"

# 请求头：业务认证（值来自环境变量 SKILLS_BIZ_TYPE / SKILLS_BIZ_TOKEN）
HEADER_BIZ_TYPE = "bizType"
HEADER_BIZ_TOKEN = "bizToken"
HEADER_TRACE_IDENTIFIER = "traceIdentifier"
HEADER_CONTENT_TYPE = "Content-Type"
CONTENT_TYPE_JSON = "application/json"

# 响应状态
HTTP_STATUS_OK = 200
HTTP_STATUS_UNAUTHORIZED = 401
HTTP_STATUS_NOT_FOUND = 404
HTTP_STATUS_TIMEOUT = 408
HTTP_STATUS_SERVER_ERROR = 500

# 可自动重试的 HTTP 状态（在尚未读取 body 或已丢弃 body 后重试）
RETRYABLE_HTTP_STATUS = frozenset({408, 429, 502, 503, 504})
