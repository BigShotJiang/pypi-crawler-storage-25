"""
自定义异常定义
"""


class SkillsSDKException(Exception):
    """SDK 基础异常类"""
    
    def __init__(self, message: str, details: dict = None):
        super().__init__(message)
        self.message = message
        self.details = details or {}


class AuthenticationError(SkillsSDKException):
    """认证失败异常"""
    pass


class NetworkError(SkillsSDKException):
    """网络错误异常"""
    pass


class TimeoutError(SkillsSDKException):
    """超时异常"""
    pass


class SkillNotFoundError(SkillsSDKException):
    """Skill 不存在异常"""
    pass


class ValidationError(SkillsSDKException):
    """参数验证错误"""
    pass


class ServerError(SkillsSDKException):
    """服务器错误"""
    pass
