"""
核心客户端实现

提供与 Skills 网关交互的主要接口
"""

from __future__ import annotations

import asyncio
import logging
import time
from dataclasses import asdict, replace
from typing import Any, AsyncIterator, Dict, Iterator, List, Optional

import httpx

from .config import SkillsConfig
from .constants import RETRYABLE_HTTP_STATUS, SKILLS_GATEWAY_BASE_URL
from .exceptions import (
    AuthenticationError,
    NetworkError,
    ServerError,
    SkillNotFoundError,
    SkillsSDKException,
    TimeoutError,
    ValidationError,
)
from .models import SkillRequest, SkillResponse, StreamChunk
from .utils import (
    aiter_stream_http_response,
    build_headers,
    build_skill_url,
    iter_stream_http_response,
    setup_logger,
    skill_response_from_http_response,
)

_logger = logging.getLogger("skills_sdk")


def _merge_config(
    biz_type: Optional[str],
    biz_token: Optional[str],
    trace_identifier: Optional[str],
    timeout: Optional[float],
    max_retries: Optional[int],
    retry_delay: Optional[float],
    enable_logging: Optional[bool],
    log_level: Optional[str],
    verify_ssl: Optional[bool],
    stream: Optional[bool],
    extra_headers: Optional[Dict[str, str]],
) -> tuple[SkillsConfig, Dict[str, str]]:
    cfg = SkillsConfig()
    updates: Dict[str, Any] = {}
    if biz_type is not None:
        updates["biz_type"] = biz_type
    if biz_token is not None:
        updates["biz_token"] = biz_token
    if trace_identifier is not None:
        updates["trace_identifier"] = trace_identifier
    if timeout is not None:
        updates["timeout"] = timeout
    if max_retries is not None:
        updates["max_retries"] = max_retries
    if retry_delay is not None:
        updates["retry_delay"] = retry_delay
    if enable_logging is not None:
        updates["enable_logging"] = enable_logging
    if log_level is not None:
        updates["log_level"] = log_level
    if verify_ssl is not None:
        updates["verify_ssl"] = verify_ssl
    if stream is not None:
        updates["stream"] = stream
    if updates:
        cfg = replace(cfg, **updates)
    cfg.validate_required()
    merged_extra = dict(extra_headers) if extra_headers else {}
    return cfg, merged_extra


def _error_snippet(response: httpx.Response) -> str:
    try:
        return response.text[:2000]
    except Exception:
        return ""


def _raise_for_status(response: httpx.Response) -> None:
    if response.status_code < 400:
        return
    body = _error_snippet(response)
    details = {"status": response.status_code, "body": body}
    if response.status_code == 401:
        raise AuthenticationError(
            "认证失败，请检查 bizType / bizToken（SKILLS_BIZ_TYPE、SKILLS_BIZ_TOKEN）",
            details=details,
        )
    if response.status_code == 404:
        raise SkillNotFoundError("Skill 不存在或路径错误", details=details)
    if response.status_code >= 500:
        raise ServerError("网关或上游服务错误", details=details)
    raise SkillsSDKException(
        f"请求失败 HTTP {response.status_code}",
        details=details,
    )


class SkillsClient:
    """
    Skills SDK 核心客户端

    提供同步、异步、流式调用 Skills 网关的能力

    使用示例:
        >>> # 需配置环境变量 SKILLS_BIZ_TYPE、SKILLS_BIZ_TOKEN
        >>> client = SkillsClient(stream=False)
        >>> response = client.call_skill(
        ...     "ai-doctor/evidence-based/drug",
        ...     {"prompt": "..."},
        ... )
    """

    def __init__(
        self,
        biz_type: Optional[str] = None,
        biz_token: Optional[str] = None,
        timeout: Optional[float] = None,
        max_retries: Optional[int] = None,
        retry_delay: Optional[float] = None,
        enable_logging: Optional[bool] = None,
        log_level: Optional[str] = None,
        verify_ssl: Optional[bool] = None,
        stream: Optional[bool] = None,
        trace_identifier: Optional[str] = None,
        extra_headers: Optional[Dict[str, str]] = None,
    ):
        """
        初始化 Skills 客户端

        网关基址由 SDK 内置常量 ``SKILLS_GATEWAY_BASE_URL`` 决定，调用方不可配置。

        Args:
            biz_type: 请求头 bizType；None 时使用环境变量 SKILLS_BIZ_TYPE（必填，如 medmateclaw）
            biz_token: 请求头 bizToken；None 时使用环境变量 SKILLS_BIZ_TOKEN
            timeout: 请求超时时间(秒)
            max_retries: 最大重试次数（含首次请求共 max_retries+1 次）
            retry_delay: 重试间隔(秒)
            enable_logging: 是否输出日志；None 表示沿用环境/默认
            log_level: 日志级别；None 表示沿用环境/默认
            verify_ssl: 是否校验 TLS 证书；None 表示 True
            stream: 默认请求体 stream 字段；None 表示沿用环境变量 SKILLS_STREAM
            trace_identifier: 可选请求头 traceIdentifier；None 时用 SKILLS_TRACE_IDENTIFIER；传空字符串则不发送
            extra_headers: 额外请求头（如 User-Agent），会与默认头合并，同名时覆盖
        """
        self._config, self._extra_headers = _merge_config(
            biz_type,
            biz_token,
            trace_identifier,
            timeout,
            max_retries,
            retry_delay,
            enable_logging,
            log_level,
            verify_ssl,
            stream,
            extra_headers,
        )
        setup_logger(self._config.log_level, self._config.enable_logging)
        self._sync_client: Optional[httpx.Client] = None
        self._async_client: Optional[httpx.AsyncClient] = None

    def _get_sync_client(self) -> httpx.Client:
        if self._sync_client is None:
            self._sync_client = httpx.Client(
                verify=self._config.verify_ssl,
                timeout=httpx.Timeout(self._config.timeout),
            )
        return self._sync_client

    @property
    def config(self) -> SkillsConfig:
        """当前生效配置（只读用途）。"""
        return self._config

    def _effective_stream(self, override: Optional[bool]) -> bool:
        if override is not None:
            return override
        return self._config.stream

    def _validate_url_suffix(self, url_suffix: str) -> None:
        if not url_suffix or not str(url_suffix).strip():
            raise ValidationError("url_suffix 不能为空")

    def _request_headers(self) -> Dict[str, str]:
        return build_headers(
            self._config.biz_type,
            self._config.biz_token,
            trace_identifier=self._config.trace_identifier,
            extra_headers=self._extra_headers,
        )

    def _post_with_retry(
        self,
        url: str,
        json_body: Dict[str, Any],
        *,
        timeout: Optional[float],
    ) -> httpx.Response:
        t = timeout if timeout is not None else self._config.timeout
        headers = self._request_headers()
        delay = self._config.retry_delay
        last_exc: Optional[BaseException] = None

        for attempt in range(self._config.max_retries + 1):
            try:
                resp = self._get_sync_client().post(
                    url,
                    json=json_body,
                    headers=headers,
                    timeout=t,
                )
                if (
                    resp.status_code in RETRYABLE_HTTP_STATUS
                    and attempt < self._config.max_retries
                ):
                    resp.read()
                    _logger.warning(
                        "技能网关返回可重试状态 %s，第 %s 次重试",
                        resp.status_code,
                        attempt + 1,
                    )
                    time.sleep(delay)
                    continue
                return resp
            except httpx.TimeoutException as e:
                last_exc = e
                if attempt < self._config.max_retries:
                    _logger.warning("请求超时，第 %s 次重试: %s", attempt + 1, e)
                    time.sleep(delay)
                    continue
                raise TimeoutError(str(e), details={"attempt": attempt + 1}) from e
            except httpx.RequestError as e:
                last_exc = e
                if attempt < self._config.max_retries:
                    _logger.warning("网络错误，第 %s 次重试: %s", attempt + 1, e)
                    time.sleep(delay)
                    continue
                raise NetworkError(str(e), details={"attempt": attempt + 1}) from e

        if last_exc:
            raise NetworkError(str(last_exc))
        raise SkillsSDKException("请求失败")

    async def _apost_with_retry(
        self,
        url: str,
        json_body: Dict[str, Any],
        *,
        timeout: Optional[float],
    ) -> httpx.Response:
        t = timeout if timeout is not None else self._config.timeout
        headers = self._request_headers()
        delay = self._config.retry_delay
        client = self._ensure_async_client()
        last_exc: Optional[BaseException] = None

        for attempt in range(self._config.max_retries + 1):
            try:
                resp = await client.post(
                    url,
                    json=json_body,
                    headers=headers,
                    timeout=t,
                )
                if (
                    resp.status_code in RETRYABLE_HTTP_STATUS
                    and attempt < self._config.max_retries
                ):
                    await resp.aread()
                    _logger.warning(
                        "技能网关返回可重试状态 %s，第 %s 次重试",
                        resp.status_code,
                        attempt + 1,
                    )
                    await asyncio.sleep(delay)
                    continue
                return resp
            except httpx.TimeoutException as e:
                last_exc = e
                if attempt < self._config.max_retries:
                    _logger.warning("请求超时，第 %s 次重试: %s", attempt + 1, e)
                    await asyncio.sleep(delay)
                    continue
                raise TimeoutError(str(e), details={"attempt": attempt + 1}) from e
            except httpx.RequestError as e:
                last_exc = e
                if attempt < self._config.max_retries:
                    _logger.warning("网络错误，第 %s 次重试: %s", attempt + 1, e)
                    await asyncio.sleep(delay)
                    continue
                raise NetworkError(str(e), details={"attempt": attempt + 1}) from e

        if last_exc:
            raise NetworkError(str(last_exc))
        raise SkillsSDKException("请求失败")

    def _ensure_async_client(self) -> httpx.AsyncClient:
        if self._async_client is None:
            self._async_client = httpx.AsyncClient(
                verify=self._config.verify_ssl,
                timeout=httpx.Timeout(self._config.timeout),
            )
        return self._async_client

    def call_skill(
        self,
        url_suffix: str,
        custom_params: Dict[str, Any],
        stream: Optional[bool] = None,
        timeout: Optional[float] = None,
    ) -> SkillResponse:
        self._validate_url_suffix(url_suffix)
        use_stream = self._effective_stream(stream)
        body = asdict(
            SkillRequest(
                stream=use_stream,
                custom_params=custom_params,
            )
        )
        url = build_skill_url(SKILLS_GATEWAY_BASE_URL, url_suffix)
        resp = self._post_with_retry(url, body, timeout=timeout)
        _raise_for_status(resp)
        return skill_response_from_http_response(resp)

    def call_skill_stream(
        self,
        url_suffix: str,
        custom_params: Dict[str, Any],
        timeout: Optional[float] = None,
    ) -> Iterator[StreamChunk]:
        self._validate_url_suffix(url_suffix)
        body = asdict(
            SkillRequest(
                stream=True,
                custom_params=custom_params,
            )
        )
        url = build_skill_url(SKILLS_GATEWAY_BASE_URL, url_suffix)
        t = timeout if timeout is not None else self._config.timeout
        headers = self._request_headers()

        def _gen() -> Iterator[StreamChunk]:
            try:
                with self._get_sync_client().stream(
                    "POST",
                    url,
                    json=body,
                    headers=headers,
                    timeout=t,
                ) as resp:
                    _raise_for_status(resp)
                    yield from iter_stream_http_response(resp)
            except httpx.TimeoutException as e:
                raise TimeoutError(str(e)) from e
            except httpx.RequestError as e:
                raise NetworkError(str(e)) from e

        return _gen()

    async def async_call_skill(
        self,
        url_suffix: str,
        custom_params: Dict[str, Any],
        stream: Optional[bool] = None,
        timeout: Optional[float] = None,
    ) -> SkillResponse:
        self._validate_url_suffix(url_suffix)
        use_stream = self._effective_stream(stream)
        body = asdict(
            SkillRequest(
                stream=use_stream,
                custom_params=custom_params,
            )
        )
        url = build_skill_url(SKILLS_GATEWAY_BASE_URL, url_suffix)
        resp = await self._apost_with_retry(url, body, timeout=timeout)
        _raise_for_status(resp)
        return skill_response_from_http_response(resp)

    async def async_call_skill_stream(
        self,
        url_suffix: str,
        custom_params: Dict[str, Any],
        timeout: Optional[float] = None,
    ) -> AsyncIterator[StreamChunk]:
        self._validate_url_suffix(url_suffix)
        body = asdict(
            SkillRequest(
                stream=True,
                custom_params=custom_params,
            )
        )
        url = build_skill_url(SKILLS_GATEWAY_BASE_URL, url_suffix)
        t = timeout if timeout is not None else self._config.timeout
        headers = self._request_headers()
        client = self._ensure_async_client()
        try:
            async with client.stream(
                "POST",
                url,
                json=body,
                headers=headers,
                timeout=t,
            ) as resp:
                _raise_for_status(resp)
                async for chunk in aiter_stream_http_response(resp):
                    yield chunk
        except httpx.TimeoutException as e:
            raise TimeoutError(str(e)) from e
        except httpx.RequestError as e:
            raise NetworkError(str(e)) from e

    def batch_call_skills(
        self,
        requests: List[Dict[str, Any]],
        timeout: Optional[float] = None,
    ) -> List[SkillResponse]:
        out: List[SkillResponse] = []
        for idx, item in enumerate(requests):
            if "url_suffix" not in item or "custom_params" not in item:
                raise ValidationError(
                    f"批量请求第 {idx} 项须包含 url_suffix 与 custom_params",
                    details={"item": item},
                )
            out.append(
                self.call_skill(
                    item["url_suffix"],
                    item["custom_params"],
                    stream=item.get("stream"),
                    timeout=timeout,
                )
            )
        return out

    def close(self) -> None:
        """关闭同步 HTTP 客户端。"""
        if self._sync_client is not None:
            self._sync_client.close()
            self._sync_client = None

    async def aclose(self) -> None:
        """关闭异步与同步 HTTP 客户端。"""
        if self._async_client is not None:
            await self._async_client.aclose()
            self._async_client = None
        self.close()

    def __enter__(self) -> "SkillsClient":
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        self.close()

    async def __aenter__(self) -> "SkillsClient":
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb) -> None:
        await self.aclose()
