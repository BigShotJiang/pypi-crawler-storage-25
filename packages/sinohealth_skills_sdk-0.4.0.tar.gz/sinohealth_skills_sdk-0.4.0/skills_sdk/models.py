"""
数据模型定义

使用标准库 dataclass 描述请求与响应结构，便于类型标注与序列化。
"""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any, Dict, Optional


@dataclass
class SkillRequest:
    """
    Skill 请求模型（与网关请求体一致）

    stream 由 SDK 根据客户端默认或单次调用覆盖写入；业务侧只提供 custom_params 即可。
    """

    stream: bool = False
    custom_params: Dict[str, Any] = field(default_factory=dict)


@dataclass
class SkillResponse:
    """Skill 响应模型，统一封装网关返回的数据。"""

    success: bool
    data: Any = None
    error: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)

    def model_dump(self) -> Dict[str, Any]:
        """与旧版 API 兼容，便于 ``json.dumps(..., default=str)`` 等序列化。"""
        return asdict(self)


@dataclass
class StreamChunk:
    """流式响应数据块（用于 stream=true 时的分块数据）。"""

    chunk_id: int
    data: str
    is_final: bool = False
    metadata: Dict[str, Any] = field(default_factory=dict)
