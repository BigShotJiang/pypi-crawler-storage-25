"""
Skills Consumer SDK
~~~~~~~~~~~~~~~~~~~

Python SDK for Skills Gateway Consumer.

基础用法:
    >>> # 配置 SKILLS_BIZ_TYPE、SKILLS_BIZ_TOKEN 后：
    >>> from skills_sdk import SkillsClient
    >>> client = SkillsClient(stream=False)
    >>> response = client.call_skill("ai-doctor/evidence-based/drug", {"prompt": "..."})
    >>> print(response.data)
"""

from .client import SkillsClient
from .config import SkillsConfig
from .exceptions import (
    AuthenticationError,
    NetworkError,
    ServerError,
    SkillNotFoundError,
    SkillsSDKException,
    TimeoutError,
    ValidationError,
)
from .models import SkillRequest, SkillResponse, StreamChunk

__version__ = "0.4.0"

__all__ = [
    "__version__",
    "SkillsClient",
    "SkillsConfig",
    "SkillRequest",
    "SkillResponse",
    "StreamChunk",
    "SkillsSDKException",
    "AuthenticationError",
    "NetworkError",
    "TimeoutError",
    "SkillNotFoundError",
    "ValidationError",
    "ServerError",
]
