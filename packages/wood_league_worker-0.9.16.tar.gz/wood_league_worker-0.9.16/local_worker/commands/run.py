"""
Title: run.py — ``wood-league-worker run`` analysis loop command
Description:
    Drives the long-running analysis loop: prompts for engine selection,
    max_jobs cap, and time limit if those flags were omitted, then attaches
    the live Rich display callbacks (built in
    :mod:`local_worker.commands._run_callbacks`) to :func:`run_batch`.

Changelog:
    2026-05-12: Extracted from cli.py (issue #43 follow-up).
    2026-05-12: Callbacks split into ``_run_callbacks.py`` to satisfy
        the Halstead-effort gate.
    2026-05-14: Wire RunPod self-stop hook after queue drain (#81).
    2026-05-14: Auto-upload ``worker.log`` at graceful session end (#85).
    2026-05-16: Replace --batch-size with --max-jobs; one-at-a-time checkout
        refactor (E-T2).
"""
from __future__ import annotations

import logging
import sys
import threading
from typing import Optional

import questionary
import typer

from local_worker._log_upload_meta import SESSION_END
from local_worker._shared import console
from local_worker.commands._run_callbacks import make_display_callbacks
from local_worker.config import Settings, load_settings
from local_worker.consent import get_consent
from local_worker.display import worker_display
from local_worker.log_upload import upload_log
from local_worker.logging_setup import is_debug_logging
from local_worker.loop import WorkerStats, run_batch
from local_worker.runpod_lifecycle import resolve_pod_id, stop_self

logger = logging.getLogger(__name__)


def _prompt_optional_int(question: str) -> Optional[int]:
    """Ask an interactive question and parse an optional integer answer.

    Args:
        question: Prompt text shown to the user.

    Returns:
        The parsed integer, or ``None`` when the answer is blank or
        non-numeric (the documented "until queue empty" sentinel).
    """
    raw = questionary.text(question).ask()
    return int(raw) if raw and raw.strip().isdigit() else None


def _resolve_engine(engine: Optional[str], interactive: bool) -> str:
    """Return the engine selection, prompting only when interactive.

    Args:
        engine: Engine from the CLI, or ``None``.
        interactive: ``True`` when stdin is a TTY.

    Returns:
        The chosen engine string ("stockfish" | "lc0" | "both").

    Raises:
        typer.Exit: code 1 if ``engine`` is ``None`` and non-interactive
            — a clear error instead of a cryptic questionary abort (#152).
    """
    if engine is not None:
        return engine
    if not interactive:
        console.print(
            "[red]--engine is required in non-interactive mode "
            "(no TTY to prompt). Pass --engine stockfish|lc0|both."
        )
        raise typer.Exit(1)
    return questionary.select(
        "Which engines should this worker process?",
        choices=["stockfish", "lc0", "both"],
    ).ask()


def _resolve_run_options(
    engine: Optional[str],
    max_jobs: Optional[int],
    batch_time: Optional[int],
) -> tuple[list[str], Optional[int], Optional[int]]:
    """Resolve run command options, prompting interactively if needed.

    In a non-interactive context (no TTY — e.g. the vast.ai headless
    onstart), prompting is impossible: questionary aborts the process
    ("Aborted.") before any job is claimed. So when stdin is not a TTY
    we never prompt — a missing ``max_jobs``/``batch_time`` falls back
    to ``None`` (run until the queue empties), and a missing ``engine``
    is a clear, explicit error rather than a cryptic abort (#152).

    Args:
        engine: Engine choice from CLI, or ``None``. Required when
            non-interactive (no TTY to prompt).
        max_jobs: Job cap from CLI, or ``None`` (prompt if a TTY, else
            run until queue empty).
        batch_time: Batch-time minutes from CLI, or ``None`` (prompt if
            a TTY, else run until queue empty).

    Returns:
        Tuple of (engines list, max_jobs, batch_time_minutes).

    Raises:
        typer.Exit: code 1 if non-interactive and ``engine`` is unset.
    """
    interactive = sys.stdin.isatty()
    engine = _resolve_engine(engine, interactive)

    if max_jobs is None and interactive:
        max_jobs = _prompt_optional_int(
            "Max jobs this run? (blank = until queue empty):"
        )

    if batch_time is None and interactive:
        batch_time = _prompt_optional_int(
            "Run for how many minutes? (leave blank to run until queue empty):"
        )

    engines = ["stockfish", "lc0"] if engine == "both" else [engine]
    return engines, max_jobs, batch_time


def _validate_engine_paths(engines: list[str], settings: Settings) -> None:
    """Ensure each requested engine has a configured binary path.

    Args:
        engines: List of engine names selected for this run.
        settings: Persisted worker settings to consult.

    Raises:
        typer.Exit: With code 1 if any requested engine is missing a path.
    """
    if "stockfish" in engines and not settings.stockfish_path:
        console.print("[red]Stockfish path not configured. Run setup.")
        raise typer.Exit(1)
    if "lc0" in engines and not settings.lc0_path:
        console.print("[red]Lc0 path not configured. Run setup.")
        raise typer.Exit(1)


def _print_session_summary(final: WorkerStats) -> None:
    """Print the post-session totals line group.

    Args:
        final: Stats object populated by :func:`run_batch`.
    """
    console.rule("[bold green]Session complete")
    console.print(f"Games processed: [cyan]{final.games_processed}")
    console.print(f"Stockfish: {final.stockfish_count}  Lc0: {final.lc0_count}")
    console.print(f"Avg time/game: {final.avg_seconds_per_game():.1f}s")
    console.print(f"Errors: {final.errors}")


def _maybe_stop_runpod(settings: Settings) -> None:
    """If self-stop is enabled and creds/pod-id resolved, ask RunPod to stop this pod.

    Args:
        settings: Loaded worker settings carrying the self-stop flag and creds.

    Returns:
        None. Logs at INFO on attempt and at WARNING when prerequisites are
        missing; never raises.
    """
    if not settings.runpod_self_stop_enabled:
        return
    if not settings.runpod_api_key:
        logger.warning("runpod self-stop enabled but WLW_RUNPOD_API_KEY is empty; skipping")
        return
    pod_id = resolve_pod_id(settings)
    if not pod_id:
        logger.warning("runpod self-stop enabled but no pod id resolvable; skipping")
        return
    stop_self(pod_id, settings.runpod_api_key)


def _maybe_upload_log(settings: Settings) -> None:
    """Upload the current ``worker.log`` to the server at graceful exit.

    No-op when the worker is unconfigured or the operator has not granted
    log-upload consent. The upload itself is best-effort: any exception
    raised by ``upload_log`` is caught and logged so it can never break
    the calling ``finally`` chain.

    Args:
        settings: Loaded worker settings.

    Returns:
        None. Logs the resulting upload id at INFO, or a single WARNING
        line on failure; never raises.
    """
    if not settings.is_configured():
        return
    if get_consent() is not True:
        return
    try:
        upload_id = upload_log(reason=SESSION_END)
    except Exception as exc:  # noqa: BLE001 — best-effort upload, never re-raised.
        logger.warning("session_end log upload raised: %s", exc)
        return
    if upload_id > 0:
        logger.info("session_end log upload succeeded (id=%d)", upload_id)
    else:
        logger.warning("session_end log upload failed (returned %d)", upload_id)


def run(
    engine: Optional[str] = typer.Option(
        None, help="Force engine: stockfish, lc0, or both"
    ),
    max_jobs: Optional[int] = typer.Option(
        None, help="Stop after this many completed jobs (blank = until queue empty)"
    ),
    batch_time: Optional[int] = typer.Option(
        None, help="Run for this many minutes then stop"
    ),
) -> None:
    """Start the analysis worker loop (interactive if options omitted)."""
    settings = load_settings()
    if not settings.is_configured():
        console.print("[red]Not configured. Run `wood-league-worker setup` first.")
        raise typer.Exit(1)

    engines, max_jobs, batch_time = _resolve_run_options(engine, max_jobs, batch_time)
    _validate_engine_paths(engines, settings)

    console.rule(f"[bold cyan]Starting worker — engines: {', '.join(engines)}")
    stop_event = threading.Event()
    stats = WorkerStats()
    result_stats: Optional[WorkerStats] = None

    try:
        try:
            with worker_display(stats, debug=is_debug_logging()) as display:
                callbacks = make_display_callbacks(display, stats)
                result_stats = run_batch(
                    settings=settings,
                    engines=engines,
                    max_jobs=max_jobs if max_jobs is not None else settings.max_jobs,
                    batch_time_minutes=batch_time,
                    stop_event=stop_event,
                    **callbacks,
                )
        except KeyboardInterrupt:
            stop_event.set()

        _print_session_summary(result_stats or stats)
    finally:
        # Upload the log first — pod must still be running for HTTP to
        # work — then ask RunPod to stop the pod. Both calls are
        # best-effort and swallow their own exceptions.
        _maybe_upload_log(settings)
        _maybe_stop_runpod(settings)
