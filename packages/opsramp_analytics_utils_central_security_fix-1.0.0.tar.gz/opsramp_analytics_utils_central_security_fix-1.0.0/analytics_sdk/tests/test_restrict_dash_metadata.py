"""
Tests for restrict_dash_metadata before_request hook (ITOM-116535).

Validates that /_dash-layout and /_dash-dependencies require JWT auth
at the SDK level, covering:
- Unauthenticated → 401
- Authenticated → 200
- No permission → 403
- Unprotected endpoints → not intercepted
- Fail-closed on exception → 401
- DispatcherMiddleware integration
- Coexistence with app-level hooks
"""

import os
import sys

# Environment setup BEFORE any SDK imports
os.environ.setdefault('BASE_API_URL', 'https://test.opsramp.net')
os.environ.setdefault('ANALYTICS_ENV', 'test')
os.environ.setdefault('TESTING', 'true')
os.environ.setdefault('STORAGE_NAME', 's3')
os.environ.setdefault('APP_ID', 'TEST-116535')
os.environ.setdefault('LOG_LEVEL', 'ERROR')

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..'))

import pytest
from unittest.mock import patch
import flask
from dash import html

from analytics_sdk.oap_dash import OAPDash


@pytest.fixture
def dash_app():
    """Create an OAPDash instance with test client."""
    app = OAPDash(name=__name__, route='test-app')
    app.layout = html.Div(children=[html.Div("test")])
    return app


@pytest.fixture
def client(dash_app):
    """Flask test client for the Dash app's inner server."""
    return dash_app.server.test_client()


class TestRestrictDashMetadata:
    """Tests for the SDK-level auth hook on Dash metadata endpoints."""

    @patch('analytics_sdk.oap_dash.is_authenticated', return_value=False)
    def test_dash_layout_unauthenticated_redirects_to_login(self, mock_auth, client):
        """GET /_dash-layout without JWT should redirect to login."""
        response = client.get('/_dash-layout')
        assert response.status_code == 302
        assert '/tenancy/web/login' in response.headers['Location']

    @patch('analytics_sdk.oap_dash.is_authenticated', return_value=False)
    def test_dash_dependencies_unauthenticated_redirects_to_login(self, mock_auth, client):
        """GET /_dash-dependencies without JWT should redirect to login."""
        response = client.get('/_dash-dependencies')
        assert response.status_code == 302
        assert '/tenancy/web/login' in response.headers['Location']

    @patch('analytics_sdk.oap_dash.is_authenticated', return_value=True)
    def test_dash_layout_authenticated_returns_200(self, mock_auth, client):
        """GET /_dash-layout with valid JWT should return 200."""
        response = client.get('/_dash-layout')
        assert response.status_code == 200

    @patch('analytics_sdk.oap_dash.is_authenticated', return_value='no_reports_view_permission')
    def test_dash_layout_no_permission_returns_403(self, mock_auth, client):
        """GET /_dash-layout with JWT but no Reports_View permission should return 403."""
        response = client.get('/_dash-layout')
        assert response.status_code == 403
        assert response.data == b'Forbidden'

    @patch('analytics_sdk.oap_dash.is_authenticated')
    def test_dash_update_component_not_intercepted(self, mock_auth, client):
        """POST /_dash-update-component should NOT trigger the metadata auth hook."""
        response = client.post('/_dash-update-component',
                               data='{}',
                               content_type='application/json')
        # The hook should not call is_authenticated for this endpoint
        mock_auth.assert_not_called()

    @patch('analytics_sdk.oap_dash.is_authenticated')
    def test_dash_component_suites_not_intercepted(self, mock_auth, client):
        """GET /_dash-component-suites should NOT trigger the metadata auth hook."""
        response = client.get('/_dash-component-suites/dash/dash.min.js')
        # The hook should not call is_authenticated for this endpoint
        mock_auth.assert_not_called()

    @patch('analytics_sdk.oap_dash.is_authenticated', side_effect=Exception("auth service unavailable"))
    def test_auth_exception_redirects_to_login_fail_closed(self, mock_auth, client):
        """If is_authenticated() raises, hook should fail-closed with redirect."""
        response = client.get('/_dash-layout')
        assert response.status_code == 302
        assert '/tenancy/web/login' in response.headers['Location']


class TestDispatcherMiddlewareIntegration:
    """Integration tests validating auth hook via DispatcherMiddleware."""

    @patch('analytics_sdk.oap_dash.is_authenticated', return_value=False)
    def test_dispatcher_middleware_routes_blocked(self, mock_auth):
        """Unauthenticated _dash-layout via DispatcherMiddleware redirects to login."""
        from werkzeug.middleware.dispatcher import DispatcherMiddleware
        from werkzeug.test import Client
        from werkzeug.wrappers import Response as WerkzeugResponse

        outer = flask.Flask("outer")
        dash_app = OAPDash(name=__name__, route='test-report')
        dash_app.layout = html.Div(children=[html.Div("test")])

        app = DispatcherMiddleware(
            outer.wsgi_app,
            {"/test-report": dash_app.server}
        )
        client = Client(app, response_wrapper=WerkzeugResponse)
        response = client.get("/test-report/_dash-layout")
        assert response.status_code == 302
        assert '/tenancy/web/login' in response.headers['Location']

    @patch('analytics_sdk.oap_dash.is_authenticated', return_value=True)
    def test_dispatcher_middleware_routes_allowed_when_auth(self, mock_auth):
        """Authenticated _dash-layout via DispatcherMiddleware returns 200."""
        from werkzeug.middleware.dispatcher import DispatcherMiddleware
        from werkzeug.test import Client
        from werkzeug.wrappers import Response as WerkzeugResponse

        outer = flask.Flask("outer")
        dash_app = OAPDash(name=__name__, route='test-report')
        dash_app.layout = html.Div(children=[html.Div("test")])

        app = DispatcherMiddleware(
            outer.wsgi_app,
            {"/test-report": dash_app.server}
        )
        client = Client(app, response_wrapper=WerkzeugResponse)
        response = client.get("/test-report/_dash-layout")
        assert response.status_code == 200

    @patch('analytics_sdk.oap_dash.is_authenticated', return_value=False)
    def test_coexistence_with_app_level_hook(self, mock_auth):
        """SDK hook + app-level restrict_dash_internal coexist without conflict."""
        dash_app = OAPDash(name=__name__, route='test-app')
        dash_app.layout = html.Div(children=[html.Div("test")])

        # Simulate app-level restrict_dash_internal (registered AFTER SDK hook)
        app_level_called = []

        @dash_app.server.before_request
        def app_restrict_dash():
            app_level_called.append(True)
            return flask.Response('App-level blocked', status=401)

        client = dash_app.server.test_client()
        response = client.get('/_dash-layout')

        # SDK hook fires first, redirects — app-level hook never reached
        assert response.status_code == 302
        assert '/tenancy/web/login' in response.headers['Location']
        assert len(app_level_called) == 0
