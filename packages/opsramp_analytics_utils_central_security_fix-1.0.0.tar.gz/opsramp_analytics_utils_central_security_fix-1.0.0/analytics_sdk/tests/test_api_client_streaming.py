"""
Test suite for get_paginated_api_results_streaming() in ApiClient.
Ticket: ITOM-117062 — CPU and Memory Optimisation: user-details (xlsx)

Tests verify that the streaming generator method:
- Yields individual records (not lists of lists)
- Handles multi-page, single-page, and empty responses
- Raises on API errors after retries
- Preserves record ordering across pages
"""

import json
import os
import sys
import logging
import pytest
from unittest.mock import Mock, patch, MagicMock

# Environment setup BEFORE any SDK imports
os.environ.setdefault('BASE_API_URL', 'https://test.opsramp.net')
os.environ.setdefault('ANALYTICS_ENV', 'test')
os.environ.setdefault('TESTING', 'true')
os.environ.setdefault('STORAGE_NAME', 's3')
os.environ.setdefault('APP_ID', 'STREAMING-TEST')
os.environ.setdefault('LOG_LEVEL', 'ERROR')

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..'))

from analytics_sdk.api.api_client import ApiClient


def _make_api_response(results, next_page=False, status_code=200):
    """Create a mock API response with results and nextPage."""
    resp = Mock()
    resp.status_code = status_code
    resp.ok = (200 <= status_code < 400)
    resp.text = 'mock response'
    resp.json.return_value = {
        'results': results,
        'nextPage': next_page
    }
    return resp


def _make_error_response(status_code=500):
    """Create a mock error response."""
    resp = Mock()
    resp.status_code = status_code
    resp.ok = False
    resp.text = f'error {status_code}'
    resp.json.return_value = {'error': 'Internal Server Error'}
    return resp


def _create_client():
    """Create an ApiClient with mocked session."""
    session = Mock()
    client = ApiClient('test-user', 'test-run-id', session=session, app_id='TEST-APP')
    client.jwt_access_header = {'Authorization': 'Bearer test-token', 'Content-Type': 'application/json', 'Accept': 'application/json'}
    return client


def _setup_get_responses(client, responses):
    """Mock get_response to return a sequence of responses for GET calls."""
    client.get_response = Mock(side_effect=responses)


def _setup_post_responses(client, responses):
    """Mock get_post_request_results to return a sequence of responses for POST calls."""
    client.get_post_request_results = Mock(side_effect=responses)


# =============================================================================
# Section 1: Multi-page response
# =============================================================================

class TestMultiPageStreaming:
    """Test streaming across multiple API pages."""

    def test_yields_all_records_from_3_pages(self):
        client = _create_client()
        page1 = [{'id': i, 'name': f'user-{i}'} for i in range(1, 4)]
        page2 = [{'id': i, 'name': f'user-{i}'} for i in range(4, 7)]
        page3 = [{'id': i, 'name': f'user-{i}'} for i in range(7, 10)]

        _setup_get_responses(client, [
            _make_api_response(page1, next_page=True),
            _make_api_response(page2, next_page=True),
            _make_api_response(page3, next_page=False),
        ])

        records = list(client.get_paginated_api_results_streaming(
            'GET', 'https://test.opsramp.net/api/v2/tenants/t1/users/search',
            json.dumps({}), 'Users streaming test'
        ))

        assert len(records) == 9
        assert records[0] == {'id': 1, 'name': 'user-1'}
        assert records[8] == {'id': 9, 'name': 'user-9'}

    def test_preserves_ordering_across_pages(self):
        client = _create_client()
        page1 = [{'id': 1}, {'id': 2}]
        page2 = [{'id': 3}, {'id': 4}]

        _setup_get_responses(client, [
            _make_api_response(page1, next_page=True),
            _make_api_response(page2, next_page=False),
        ])

        records = list(client.get_paginated_api_results_streaming(
            'GET', 'https://test.opsramp.net/api/v2/test',
            json.dumps({}), 'Ordering test'
        ))

        ids = [r['id'] for r in records]
        assert ids == [1, 2, 3, 4]

    def test_yields_same_data_as_non_streaming(self):
        """Streaming method should yield same records as list-based method."""
        client_stream = _create_client()
        client_list = _create_client()

        page1 = [{'id': 1, 'name': 'alice'}, {'id': 2, 'name': 'bob'}]
        page2 = [{'id': 3, 'name': 'charlie'}]

        # Same responses for both
        _setup_get_responses(client_stream, [
            _make_api_response(page1, next_page=True),
            _make_api_response(page2, next_page=False),
        ])
        _setup_get_responses(client_list, [
            _make_api_response(page1, next_page=True),
            _make_api_response(page2, next_page=False),
        ])

        streaming_records = list(client_stream.get_paginated_api_results_streaming(
            'GET', 'https://test.opsramp.net/api/test',
            json.dumps({}), 'Compare test'
        ))
        list_records = client_list.get_paginated_api_results(
            'GET', 'https://test.opsramp.net/api/test',
            json.dumps({}), 'Compare test'
        )

        assert streaming_records == list_records


# =============================================================================
# Section 2: Single-page response
# =============================================================================

class TestSinglePageStreaming:
    """Test streaming with a single API page."""

    def test_single_page_yields_all_records(self):
        client = _create_client()
        records_data = [{'id': i} for i in range(5)]

        _setup_get_responses(client, [
            _make_api_response(records_data, next_page=False),
        ])

        records = list(client.get_paginated_api_results_streaming(
            'GET', 'https://test.opsramp.net/api/test',
            json.dumps({}), 'Single page test'
        ))

        assert len(records) == 5
        assert records == records_data


# =============================================================================
# Section 3: Empty response
# =============================================================================

class TestEmptyStreaming:
    """Test streaming with empty API responses."""

    def test_empty_results_yields_nothing(self):
        client = _create_client()

        _setup_get_responses(client, [
            _make_api_response([], next_page=False),
        ])

        records = list(client.get_paginated_api_results_streaming(
            'GET', 'https://test.opsramp.net/api/test',
            json.dumps({}), 'Empty test'
        ))

        assert len(records) == 0


# =============================================================================
# Section 4: Error handling
# =============================================================================

class TestStreamingErrors:
    """Test error handling in streaming method."""

    @patch('analytics_sdk.api.api_client.API_RETRY', 1)
    def test_api_error_returns_empty_after_retries(self):
        """When all retries exhausted, streaming returns empty (like original returns None)."""
        client = _create_client()

        # All retries return errors
        _setup_get_responses(client, [
            _make_error_response(500),
            _make_error_response(500),
            _make_error_response(500),
            _make_error_response(500),
        ])

        records = list(client.get_paginated_api_results_streaming(
            'GET', 'https://test.opsramp.net/api/test',
            json.dumps({}), 'Error test'
        ))
        assert len(records) == 0

    def test_error_on_second_page_raises(self):
        """Error mid-pagination should raise, not silently stop."""
        client = _create_client()

        page1 = [{'id': 1}, {'id': 2}]
        _setup_get_responses(client, [
            _make_api_response(page1, next_page=True),
            _make_error_response(500),
            _make_error_response(500),
            _make_error_response(500),
            _make_error_response(500),
        ])

        with pytest.raises(Exception):
            list(client.get_paginated_api_results_streaming(
                'GET', 'https://test.opsramp.net/api/test',
                json.dumps({}), 'Mid-page error test'
            ))


# =============================================================================
# Section 5: Generator protocol
# =============================================================================

class TestGeneratorProtocol:
    """Verify the method returns a generator, not a materialized list."""

    def test_returns_generator(self):
        import types
        client = _create_client()

        _setup_get_responses(client, [
            _make_api_response([{'id': 1}], next_page=False),
        ])

        result = client.get_paginated_api_results_streaming(
            'GET', 'https://test.opsramp.net/api/test',
            json.dumps({}), 'Generator test'
        )

        assert isinstance(result, types.GeneratorType)

    def test_lazy_evaluation_does_not_call_api_until_iterated(self):
        client = _create_client()

        _setup_get_responses(client, [
            _make_api_response([{'id': 1}], next_page=False),
        ])

        # Create generator but don't iterate
        gen = client.get_paginated_api_results_streaming(
            'GET', 'https://test.opsramp.net/api/test',
            json.dumps({}), 'Lazy test'
        )

        # API should not have been called yet
        assert client.get_response.call_count == 0

        # Now iterate
        records = list(gen)
        assert len(records) == 1
        assert client.get_response.call_count == 1


# =============================================================================
# Section 6: POST method support
# =============================================================================

class TestStreamingPostMethod:
    """Test streaming with POST requests."""

    def test_post_method_yields_records(self):
        client = _create_client()
        records_data = [{'id': 1}, {'id': 2}]

        _setup_post_responses(client, [
            _make_api_response(records_data, next_page=False),
        ])

        records = list(client.get_paginated_api_results_streaming(
            'POST', 'https://test.opsramp.net/api/test',
            json.dumps({'queryString': 'test'}), 'POST test'
        ))

        assert len(records) == 2
        assert records == records_data
