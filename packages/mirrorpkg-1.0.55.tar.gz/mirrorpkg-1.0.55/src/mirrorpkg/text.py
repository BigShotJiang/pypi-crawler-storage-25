def reverse(text: str) -> str:
    return text[::-1]


def word_count(text: str) -> int:
    return len(text.split()) if text.strip() else 0


def truncate(text: str, max_length: int, suffix: str = "...") -> str:
    if max_length < len(suffix):
        raise ValueError(
            f"max_length ({max_length}) must be >= len(suffix) ({len(suffix)})"
        )
    if len(text) <= max_length:
        return text
    return text[: max_length - len(suffix)] + suffix


def is_palindrome(text: str) -> bool:
    normalized = text.lower().replace(" ", "")
    return normalized == normalized[::-1]
