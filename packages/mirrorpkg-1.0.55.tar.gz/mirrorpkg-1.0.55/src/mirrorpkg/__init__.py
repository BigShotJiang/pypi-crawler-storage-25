from mirrorpkg.text import is_palindrome, reverse, truncate, word_count

__all__ = ["is_palindrome", "reverse", "truncate", "word_count"]
