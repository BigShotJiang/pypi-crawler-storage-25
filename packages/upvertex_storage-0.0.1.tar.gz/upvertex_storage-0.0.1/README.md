# upvertex-storage

Namespace reservation for UpVertex Inc. (www.upvertex.com)