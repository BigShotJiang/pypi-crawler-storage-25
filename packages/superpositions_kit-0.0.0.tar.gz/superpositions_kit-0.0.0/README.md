# superpositions-kit

[![PyPI](https://img.shields.io/pypi/v/superpositions-kit)](https://pypi.org/project/superpositions-kit/)
[![Python](https://img.shields.io/pypi/pyversions/superpositions-kit)](https://pypi.org/project/superpositions-kit/)
[![License](https://img.shields.io/pypi/l/superpositions-kit)](LICENSE)
[![Docs](https://img.shields.io/badge/docs-superpositions--studio.github.io-blue)](https://superpositions-studio.github.io/superpositions-kit)

**superpositions-kit** is a hardware-agnostic Python library for building variational quantum circuits (VQCs) targeting PennyLane, Qiskit, and Amazon Braket backends with the same code.

> **Public scaffolding.** The full implementation is being prepared for release. Track progress on the [GitHub repository](https://github.com/superpositions-studio/superpositions-kit).

## Installation

```bash
pip install --pre superpositions-kit
```

The `--pre` flag is required while the library is on a pre-release placeholder. Once the full implementation lands as `0.1.0`, plain `pip install superpositions-kit` will work.

## Contributing

We welcome contributions! See [CONTRIBUTING.md](CONTRIBUTING.md) for development setup, testing, and commit conventions. Please also read our [Code of Conduct](CODE_OF_CONDUCT.md).

## Reporting security issues

Do not file public issues for security vulnerabilities. Report them privately as described in [SECURITY.md](SECURITY.md).

## License

`superpositions-kit` is released under the [Apache License 2.0](LICENSE).
