# Changelog

All notable changes to `superpositions-kit` are documented here.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).
Releases are produced automatically by
[python-semantic-release](https://python-semantic-release.readthedocs.io/) from
[Conventional Commits](https://www.conventionalcommits.org/).

<!-- version list -->

## v0.0.0 (2026-05-03)

- Initial Release

## v0.0.0 (2026-05-03)

- Initial Release
