"""superpositions-kit — public scaffolding placeholder.

The full implementation is being prepared for release. See
https://github.com/superpositions-studio/superpositions-kit for status.
"""

from importlib.metadata import PackageNotFoundError, version


try:
    __version__ = version("superpositions-kit")
except PackageNotFoundError:
    __version__ = "0.0.1.dev0"
__all__ = ["__version__"]
