"""Layer I: Hierarchical memory and summarization.

For longer videos, builds multi-level summaries:
- Atomic: individual timeline events (already exist)
- Scene: 60-second window summaries
- Chapter: 5-minute window summaries (for videos >30min)
- Global: overall video summary

In skill mode, summaries are text-based (no API calls).
In API mode, Claude generates them.
"""

from __future__ import annotations

import logging

from .models import TimelineEvent
from .util import ms_to_hhmmss

logger = logging.getLogger("vidclaude")


def build_summaries(
    timeline: list[TimelineEvent],
    duration_sec: float,
    mode: str = "standard",
) -> dict:
    """Build hierarchical summaries from timeline events.

    Returns dict with keys: scene_summaries, chapter_summaries, global_summary.
    For skill mode, these are text-based aggregations (no API calls).
    """
    result = {
        "scene_summaries": [],
        "chapter_summaries": [],
        "global_summary": "",
    }

    # Quick mode: no summaries
    if mode == "quick":
        return result

    # Short videos (<5min in standard mode): skip hierarchical summaries
    if mode == "standard" and duration_sec < 300:
        result["global_summary"] = _build_global_from_events(timeline)
        return result

    # Build scene summaries (60-second windows)
    scene_summaries = _build_window_summaries(timeline, window_ms=60000)
    result["scene_summaries"] = scene_summaries

    # For long videos (>30min) or deep mode: add chapter summaries (5-min windows)
    if duration_sec > 1800 or mode == "deep":
        chapter_summaries = _build_window_summaries(timeline, window_ms=300000)
        result["chapter_summaries"] = chapter_summaries

    # Global summary from scene summaries
    result["global_summary"] = _build_global_from_scenes(scene_summaries, duration_sec)

    logger.info(
        "Built summaries: %d scene, %d chapter",
        len(result["scene_summaries"]),
        len(result["chapter_summaries"]),
    )

    return result


def _build_window_summaries(
    events: list[TimelineEvent],
    window_ms: int,
) -> list[str]:
    """Group events into time windows and summarize each."""
    if not events:
        return []

    max_ms = max(e.start_ms for e in events)
    summaries = []
    window_start = 0

    while window_start <= max_ms:
        window_end = window_start + window_ms
        window_events = [
            e for e in events
            if window_start <= e.start_ms < window_end
        ]

        if window_events:
            summary = _summarize_window(window_start, window_end, window_events)
            summaries.append(summary)

        window_start = window_end

    return summaries


def _summarize_window(
    start_ms: int,
    end_ms: int,
    events: list[TimelineEvent],
) -> str:
    """Create a text summary of events in a time window."""
    ts_start = ms_to_hhmmss(start_ms)
    ts_end = ms_to_hhmmss(end_ms)

    parts = [f"[{ts_start} - {ts_end}]"]

    # Group by modality
    speech = [e for e in events if e.modality == "speech"]
    ocr = [e for e in events if e.modality == "ocr"]
    scene_changes = [e for e in events if e.modality == "scene_change"]

    if scene_changes:
        parts.append(f"  {len(scene_changes)} scene change(s)")

    if speech:
        # Concatenate speech text
        speech_text = " ".join(e.summary for e in speech)
        if len(speech_text) > 300:
            speech_text = speech_text[:297] + "..."
        parts.append(f"  Speech: {speech_text}")

    if ocr:
        ocr_texts = "; ".join(e.summary for e in ocr)
        if len(ocr_texts) > 200:
            ocr_texts = ocr_texts[:197] + "..."
        parts.append(f"  {ocr_texts}")

    return "\n".join(parts)


def _build_global_from_events(events: list[TimelineEvent]) -> str:
    """Build a simple global summary directly from events."""
    if not events:
        return "No events detected in video."

    modality_counts = {}
    for e in events:
        modality_counts[e.modality] = modality_counts.get(e.modality, 0) + 1

    parts = ["Video contains:"]
    for mod, count in sorted(modality_counts.items()):
        parts.append(f"  - {count} {mod} event(s)")

    # Include first few speech segments as overview
    speech = [e for e in events if e.modality == "speech"]
    if speech:
        preview = " ".join(e.summary for e in speech[:5])
        if len(preview) > 500:
            preview = preview[:497] + "..."
        parts.append(f"\nSpeech preview: {preview}")

    return "\n".join(parts)


def _build_global_from_scenes(scene_summaries: list[str], duration_sec: float) -> str:
    """Build global summary from scene-level summaries."""
    if not scene_summaries:
        return "No content detected."

    duration_str = ms_to_hhmmss(int(duration_sec * 1000))
    parts = [
        f"Video duration: {duration_str}",
        f"Total scenes: {len(scene_summaries)}",
        "",
        "Scene overview:",
    ]

    for i, summary in enumerate(scene_summaries):
        # Just include the first line of each scene summary
        first_line = summary.split("\n")[0]
        parts.append(f"  {i+1}. {first_line}")

    return "\n".join(parts)
