"""Layer G: Temporal event graph (simplified as sorted event list).

Merges evidence from all modalities into a unified, time-sorted event list
that gives Claude explicit temporal ordering for reasoning.
"""

from __future__ import annotations

import logging

from .models import Shot, Frame, TranscriptChunk, OCRResult, TimelineEvent

logger = logging.getLogger("vidclaude")


def build_timeline(
    shots: list[Shot],
    frames: list[Frame],
    transcript: list[TranscriptChunk],
    ocr_results: list[OCRResult],
) -> list[TimelineEvent]:
    """Build a unified timeline from all modality outputs.

    Merges shot boundaries, frame observations, transcript chunks,
    and OCR results into a single sorted event list.
    """
    events: list[TimelineEvent] = []
    event_counter = 0

    # Shot boundaries as scene change events
    for i, shot in enumerate(shots):
        if i == 0:
            continue  # skip first (video start, not a transition)
        events.append(TimelineEvent(
            event_id=f"te_{event_counter:04d}",
            start_ms=shot.start_ms,
            end_ms=None,
            modality="scene_change",
            summary=f"Scene change (confidence: {shot.score:.2f})",
            source_ids=[shot.shot_id],
        ))
        event_counter += 1

    # Transcript chunks as speech events
    for chunk in transcript:
        events.append(TimelineEvent(
            event_id=f"te_{event_counter:04d}",
            start_ms=chunk.start_ms,
            end_ms=chunk.end_ms,
            modality="speech",
            summary=chunk.text,
            source_ids=[chunk.chunk_id],
        ))
        event_counter += 1

    # OCR results as text-on-screen events
    for ocr in ocr_results:
        events.append(TimelineEvent(
            event_id=f"te_{event_counter:04d}",
            start_ms=ocr.timestamp_ms,
            end_ms=None,
            modality="ocr",
            summary=f"On-screen text: {ocr.text}",
            source_ids=[ocr.frame_id],
        ))
        event_counter += 1

    # Frame extractions as visual observation markers
    # Only include shot_boundary frames to avoid flooding the timeline
    for frame in frames:
        if "shot_boundary" in frame.sampling_reason:
            events.append(TimelineEvent(
                event_id=f"te_{event_counter:04d}",
                start_ms=frame.timestamp_ms,
                end_ms=None,
                modality="visual",
                summary=f"Keyframe captured ({', '.join(frame.sampling_reason)})",
                source_ids=[frame.frame_id],
            ))
            event_counter += 1

    # Sort by start time, then by modality priority for same-time events
    modality_order = {"scene_change": 0, "visual": 1, "speech": 2, "ocr": 3}
    events.sort(key=lambda e: (e.start_ms, modality_order.get(e.modality, 9)))

    logger.info(
        "Built timeline with %d events: %d speech, %d ocr, %d scene_change, %d visual",
        len(events),
        sum(1 for e in events if e.modality == "speech"),
        sum(1 for e in events if e.modality == "ocr"),
        sum(1 for e in events if e.modality == "scene_change"),
        sum(1 for e in events if e.modality == "visual"),
    )

    return events
