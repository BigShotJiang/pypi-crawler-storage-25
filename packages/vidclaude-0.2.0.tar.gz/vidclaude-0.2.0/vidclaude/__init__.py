"""vidclaude — Multimodal video understanding powered by Claude."""

__version__ = "0.2.0"
