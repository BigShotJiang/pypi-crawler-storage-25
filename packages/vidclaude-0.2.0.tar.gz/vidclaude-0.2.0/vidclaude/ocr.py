"""Layer E: OCR extraction from video frames using pytesseract."""

from __future__ import annotations

import logging
from pathlib import Path

from .models import Frame, OCRResult

logger = logging.getLogger("vidclaude")


def extract_ocr(
    frames: list[Frame],
    no_ocr: bool = False,
    mode: str = "standard",
) -> list[OCRResult]:
    """Extract text from frames using pytesseract.

    Args:
        frames: List of extracted frames.
        no_ocr: If True, skip OCR entirely.
        mode: Processing mode — "quick" skips OCR, "standard" does keyframes,
              "deep" does all frames.

    Returns list of OCRResult for frames where text was detected.
    """
    if no_ocr:
        logger.info("OCR skipped (--no-ocr)")
        return []

    if mode == "quick":
        logger.info("OCR skipped in quick mode")
        return []

    # Try to import pytesseract
    try:
        import pytesseract
        from PIL import Image
    except ImportError:
        logger.warning(
            "pytesseract not installed. Skipping OCR. "
            "Install with: pip install pytesseract "
            "(also requires Tesseract system binary)"
        )
        return []

    # In standard mode, only process keyframes (shot boundaries + every Nth frame)
    if mode == "standard":
        selected = _select_keyframes(frames)
    else:
        selected = frames

    logger.info("Running OCR on %d frame(s)...", len(selected))

    results: list[OCRResult] = []
    for frame in selected:
        if not Path(frame.image_path).exists():
            continue

        try:
            img = Image.open(frame.image_path)
            data = pytesseract.image_to_data(img, output_type=pytesseract.Output.DICT)

            # Collect text blocks with confidence > 60
            texts = []
            for i, conf in enumerate(data["conf"]):
                try:
                    conf_val = int(conf)
                except (ValueError, TypeError):
                    continue
                if conf_val > 60 and data["text"][i].strip():
                    texts.append(data["text"][i].strip())

            if texts:
                combined = " ".join(texts)
                avg_conf = sum(
                    int(c) for c in data["conf"]
                    if str(c).strip() and int(c) > 60
                ) / max(1, len(texts))

                results.append(OCRResult(
                    frame_id=frame.frame_id,
                    timestamp_ms=frame.timestamp_ms,
                    text=combined,
                    confidence=avg_conf / 100.0,
                ))
        except Exception as e:
            logger.debug("OCR failed on %s: %s", frame.frame_id, e)
            continue

    logger.info("OCR found text in %d frame(s)", len(results))
    return results


def _select_keyframes(frames: list[Frame]) -> list[Frame]:
    """Select keyframes for OCR in standard mode.

    Picks: shot boundary frames + every 5th base frame.
    """
    selected = []
    base_count = 0
    for frame in frames:
        if "shot_boundary" in frame.sampling_reason:
            selected.append(frame)
        elif "base" in frame.sampling_reason:
            if base_count % 5 == 0:
                selected.append(frame)
            base_count += 1
    return selected if selected else frames[:5]
