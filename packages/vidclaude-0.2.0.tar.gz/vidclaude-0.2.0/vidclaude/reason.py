"""Layer J: Evidence assembly and output generation.

Two modes:
1. Skill mode (--extract): Generates evidence.md for Claude Code to read + reason over.
2. API mode (--api): Builds Anthropic API message with base64 frames + evidence.
"""

from __future__ import annotations

import logging
from pathlib import Path

from .models import (
    Evidence, VideoMeta, Frame, TranscriptChunk, OCRResult, TimelineEvent,
    save_json,
)
from .util import ms_to_hhmmss, image_to_base64

logger = logging.getLogger("vidclaude")

# Maximum frames to include in evidence.md frame listing
MAX_EVIDENCE_FRAMES = 20


def generate_evidence_md(evidence: Evidence, cache_dir: Path) -> str:
    """Generate evidence.md — a structured report for Claude Code skill mode.

    This file is read by Claude in the conversation to reason over the video.
    Frame images are referenced by path so Claude Code can read them directly.
    """
    lines: list[str] = []

    # Header
    lines.append("# Video Analysis Evidence Report")
    lines.append("")

    # Video metadata
    meta = evidence.video_meta
    lines.append("## Video Information")
    lines.append(f"- **File**: `{meta.path}`")
    lines.append(f"- **Duration**: {ms_to_hhmmss(int(meta.duration_sec * 1000))}")
    lines.append(f"- **Resolution**: {meta.resolution[0]}x{meta.resolution[1]}")
    lines.append(f"- **FPS**: {meta.fps:.1f}")
    lines.append(f"- **Audio tracks**: {meta.audio_tracks}")
    lines.append(f"- **Format**: {meta.format}")
    lines.append("")

    # Question and intent
    if evidence.question:
        lines.append("## Question")
        lines.append(evidence.question)
        lines.append(f"- **Detected intent**: {evidence.intent}")
        lines.append("")

    # Global summary
    if evidence.global_summary:
        lines.append("## Global Summary")
        lines.append(evidence.global_summary)
        lines.append("")

    # Scene summaries
    if evidence.scene_summaries:
        lines.append("## Scene Summaries")
        for summary in evidence.scene_summaries:
            lines.append(summary)
            lines.append("")

    # Extracted frames listing
    lines.append("## Extracted Frames")
    lines.append(f"Total frames: {len(evidence.frames)}")
    lines.append("")

    # Select frames to list (cap at MAX_EVIDENCE_FRAMES for readability)
    display_frames = _select_display_frames(evidence.frames, MAX_EVIDENCE_FRAMES)
    for frame in display_frames:
        ts = ms_to_hhmmss(frame.timestamp_ms)
        reasons = ", ".join(frame.sampling_reason)
        lines.append(f"- **{frame.frame_id}** @ {ts} [{reasons}]: `{frame.image_path}`")
    lines.append("")

    # Transcript
    if evidence.transcript_chunks:
        lines.append("## Audio Transcript")
        for chunk in evidence.transcript_chunks:
            ts_start = ms_to_hhmmss(chunk.start_ms)
            ts_end = ms_to_hhmmss(chunk.end_ms)
            speaker = f"[{chunk.speaker}] " if chunk.speaker else ""
            lines.append(f"- [{ts_start} → {ts_end}] {speaker}{chunk.text}")
        lines.append("")

    # OCR results
    if evidence.ocr_results:
        lines.append("## On-Screen Text (OCR)")
        for ocr in evidence.ocr_results:
            ts = ms_to_hhmmss(ocr.timestamp_ms)
            lines.append(f"- [{ts}] (conf: {ocr.confidence:.0%}) {ocr.text}")
        lines.append("")

    # Timeline
    if evidence.timeline_events:
        lines.append("## Timeline")
        for event in evidence.timeline_events:
            ts = ms_to_hhmmss(event.start_ms)
            end = f" → {ms_to_hhmmss(event.end_ms)}" if event.end_ms else ""
            lines.append(f"- [{ts}{end}] **{event.modality}**: {event.summary}")
        lines.append("")

    # Frame paths for Claude Code to read
    lines.append("## Frame Paths (for visual analysis)")
    lines.append("The following frame images can be viewed for visual analysis:")
    lines.append("")
    for frame in display_frames:
        lines.append(f"- `{frame.image_path}`")
    lines.append("")

    content = "\n".join(lines)

    # Write to cache
    evidence_path = cache_dir / "evidence.md"
    evidence_path.write_text(content, encoding="utf-8")
    logger.info("Evidence report written to %s", evidence_path)

    return content


def build_api_message(evidence: Evidence) -> dict:
    """Build the Anthropic API message for standalone mode.

    Returns dict with 'system' and 'messages' for the API call.
    """
    system_prompt = (
        "You are analyzing a video. You will be shown frames extracted from the video "
        "at regular intervals, along with an audio transcript and other evidence if available. "
        "Analyze the visual and audio content to answer the user's question.\n\n"
        "Guidelines:\n"
        "- Ground every claim in timestamps\n"
        "- Distinguish observation from inference\n"
        "- If evidence is insufficient or ambiguous, say so clearly\n"
        "- Rate your confidence as high/medium/low"
    )

    content: list[dict] = []

    # Video info header
    meta = evidence.video_meta
    content.append({
        "type": "text",
        "text": (
            f"Video: {meta.duration_sec:.1f}s, {meta.resolution[0]}x{meta.resolution[1]}, "
            f"{meta.audio_tracks} audio track(s)\n"
            f"Sharing {len(evidence.frames)} frames. Intent: {evidence.intent}"
        ),
    })

    # Global summary
    if evidence.global_summary:
        content.append({
            "type": "text",
            "text": f"<global_summary>\n{evidence.global_summary}\n</global_summary>",
        })

    # Frames as base64 images
    display_frames = _select_display_frames(evidence.frames, MAX_EVIDENCE_FRAMES)
    for frame in display_frames:
        ts = ms_to_hhmmss(frame.timestamp_ms)
        content.append({
            "type": "text",
            "text": f"Frame {frame.frame_id} @ {ts}:",
        })
        try:
            b64 = image_to_base64(frame.image_path)
            content.append({
                "type": "image",
                "source": {
                    "type": "base64",
                    "media_type": "image/jpeg",
                    "data": b64,
                },
            })
        except Exception as e:
            logger.warning("Could not encode frame %s: %s", frame.frame_id, e)

    # Timeline
    if evidence.timeline_events:
        timeline_text = "\n".join(
            f"[{ms_to_hhmmss(e.start_ms)}] {e.modality}: {e.summary}"
            for e in evidence.timeline_events
        )
        content.append({
            "type": "text",
            "text": f"<timeline>\n{timeline_text}\n</timeline>",
        })

    # Transcript
    if evidence.transcript_chunks:
        transcript_text = "\n".join(
            f"[{ms_to_hhmmss(c.start_ms)} → {ms_to_hhmmss(c.end_ms)}] {c.text}"
            for c in evidence.transcript_chunks
        )
        content.append({
            "type": "text",
            "text": f"<transcript>\n{transcript_text}\n</transcript>",
        })

    # OCR
    if evidence.ocr_results:
        ocr_text = "\n".join(
            f"[{ms_to_hhmmss(o.timestamp_ms)}] {o.text}"
            for o in evidence.ocr_results
        )
        content.append({
            "type": "text",
            "text": f"<ocr>\n{ocr_text}\n</ocr>",
        })

    # Question
    question = evidence.question or "Describe what's happening in this video in detail."
    content.append({
        "type": "text",
        "text": question,
    })

    return {
        "system": system_prompt,
        "messages": [{"role": "user", "content": content}],
    }


def call_claude_api(evidence: Evidence) -> str:
    """Make the Claude API call for standalone mode. Requires ANTHROPIC_API_KEY."""
    try:
        import anthropic
    except ImportError:
        raise RuntimeError(
            "anthropic package not installed. Install with: pip install anthropic\n"
            "Or use skill mode (--extract) which doesn't need the API."
        )

    import os
    if not os.environ.get("ANTHROPIC_API_KEY"):
        raise RuntimeError(
            "ANTHROPIC_API_KEY not set. Set it with:\n"
            "  export ANTHROPIC_API_KEY=sk-...\n"
            "Or use skill mode (--extract) which doesn't need the API."
        )

    msg = build_api_message(evidence)
    client = anthropic.Anthropic()

    logger.info("Calling Claude API (model=claude-sonnet-4-20250514)...")
    response = client.messages.create(
        model="claude-sonnet-4-20250514",
        max_tokens=4096,
        system=msg["system"],
        messages=msg["messages"],
    )

    return response.content[0].text


def _select_display_frames(frames: list[Frame], max_count: int) -> list[Frame]:
    """Select the most representative frames for display.

    Prioritizes shot boundary frames, then evenly spaces base frames.
    """
    if len(frames) <= max_count:
        return frames

    # Separate boundary and base frames
    boundary = [f for f in frames if "shot_boundary" in f.sampling_reason]
    base = [f for f in frames if "shot_boundary" not in f.sampling_reason]

    # Keep all boundary frames up to half the budget
    max_boundary = min(len(boundary), max_count // 2)
    selected = boundary[:max_boundary]

    # Fill remaining with evenly spaced base frames
    remaining = max_count - len(selected)
    if remaining > 0 and base:
        step = max(1, len(base) // remaining)
        selected.extend(base[::step][:remaining])

    # Sort by timestamp
    selected.sort(key=lambda f: f.timestamp_ms)
    return selected
