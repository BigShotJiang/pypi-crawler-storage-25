"""Layer A: Video ingestion — validate format, extract metadata via ffprobe."""

from __future__ import annotations

import logging
from pathlib import Path

from .models import VideoMeta
from .util import run_ffprobe, VIDEO_EXTENSIONS

logger = logging.getLogger("vidclaude")


def ingest(video_path: str) -> VideoMeta:
    """Validate video file and extract metadata.

    Returns VideoMeta with duration, fps, resolution, audio track info.
    Raises on invalid file or ffprobe failure.
    """
    p = Path(video_path).resolve()

    if not p.exists():
        raise FileNotFoundError(f"Video not found: {video_path}")
    if not p.is_file():
        raise ValueError(f"Not a file: {video_path}")
    if p.suffix.lower() not in VIDEO_EXTENSIONS:
        raise ValueError(
            f"Unsupported format '{p.suffix}'. "
            f"Supported: {', '.join(sorted(VIDEO_EXTENSIONS))}"
        )

    probe = run_ffprobe(str(p))

    # Extract format info
    fmt = probe.get("format", {})
    duration = float(fmt.get("duration", 0))
    file_size = int(fmt.get("size", 0))
    format_name = fmt.get("format_name", "unknown")

    # Find video stream
    video_stream = None
    audio_count = 0
    for stream in probe.get("streams", []):
        if stream.get("codec_type") == "video" and video_stream is None:
            video_stream = stream
        elif stream.get("codec_type") == "audio":
            audio_count += 1

    if video_stream is None:
        raise ValueError(f"No video stream found in {video_path}")

    # Parse fps from r_frame_rate (e.g. "30000/1001" or "30/1")
    fps_str = video_stream.get("r_frame_rate", "30/1")
    try:
        num, den = fps_str.split("/")
        fps = float(num) / float(den)
    except (ValueError, ZeroDivisionError):
        fps = 30.0

    width = int(video_stream.get("width", 0))
    height = int(video_stream.get("height", 0))

    meta = VideoMeta(
        path=str(p),
        duration_sec=duration,
        fps=fps,
        resolution=(width, height),
        audio_tracks=audio_count,
        format=format_name,
        file_size_bytes=file_size,
    )

    logger.info(
        "Ingested: %.1fs, %.1ffps, %dx%d, %d audio track(s), %s",
        meta.duration_sec, meta.fps,
        width, height,
        audio_count, format_name,
    )

    return meta
