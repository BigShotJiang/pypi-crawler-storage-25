"""Layer D: Audio understanding — extract audio, transcribe with faster-whisper.

Uses faster-whisper (CTranslate2) with large-v3 by default for strong
multilingual support including Hindi, Urdu, etc.
Falls back to openai-whisper if faster-whisper is not installed.
"""

from __future__ import annotations

import logging
from pathlib import Path

from .models import VideoMeta, TranscriptChunk
from .util import run_ffmpeg

logger = logging.getLogger("vidclaude")

# Model selection per processing mode
MODE_MODELS = {
    "quick": "base",
    "standard": "large-v3",
    "deep": "large-v3",
}


def has_audio_stream(meta: VideoMeta) -> bool:
    """Check if video has at least one audio track."""
    return meta.audio_tracks > 0


def extract_audio(meta: VideoMeta, cache_dir: Path) -> str | None:
    """Extract audio from video as 16kHz mono WAV.

    Returns path to WAV file, or None if no audio stream.
    """
    if not has_audio_stream(meta):
        logger.info("No audio stream detected, skipping audio extraction")
        return None

    audio_path = str(cache_dir / "audio.wav")
    logger.info("Extracting audio...")

    result = run_ffmpeg([
        "-i", meta.path,
        "-vn",                    # no video
        "-acodec", "pcm_s16le",   # raw PCM
        "-ar", "16000",           # 16kHz sample rate
        "-ac", "1",               # mono
        "-y",
        audio_path,
    ])

    if result.returncode != 0:
        logger.warning("Audio extraction failed: %s", result.stderr[:200])
        return None

    if not Path(audio_path).exists():
        return None

    logger.info("Audio extracted to %s", audio_path)
    return audio_path


def transcribe(
    meta: VideoMeta,
    cache_dir: Path,
    no_audio: bool = False,
    model_name: str | None = None,
    mode: str = "standard",
) -> list[TranscriptChunk]:
    """Transcribe video audio using faster-whisper (preferred) or openai-whisper.

    Args:
        meta: Video metadata.
        cache_dir: Directory for intermediate files.
        no_audio: If True, skip transcription entirely.
        model_name: Whisper model override. If None, selected by mode.
        mode: Processing mode (quick/standard/deep).

    Returns list of TranscriptChunk with timestamps.
    """
    if no_audio:
        logger.info("Audio transcription skipped (--no-audio)")
        return []

    # Extract audio first
    audio_path = extract_audio(meta, cache_dir)
    if audio_path is None:
        return []

    # Select model by mode if not overridden
    if model_name is None:
        model_name = MODE_MODELS.get(mode, "large-v3")

    # Try faster-whisper first (preferred)
    chunks = _transcribe_faster_whisper(audio_path, model_name)
    if chunks is not None:
        return chunks

    # Fall back to openai-whisper
    chunks = _transcribe_openai_whisper(audio_path, model_name)
    if chunks is not None:
        return chunks

    logger.warning(
        "No whisper implementation found. Skipping transcription.\n"
        "Install with: pip install faster-whisper (recommended)\n"
        "         or:  pip install openai-whisper"
    )
    return []


def _transcribe_faster_whisper(
    audio_path: str, model_name: str,
) -> list[TranscriptChunk] | None:
    """Transcribe using faster-whisper (CTranslate2 backend)."""
    try:
        from faster_whisper import WhisperModel
    except ImportError:
        return None

    logger.info("Transcribing with faster-whisper (model=%s)...", model_name)

    model = WhisperModel(model_name, device="auto", compute_type="auto")
    segments, info = model.transcribe(
        audio_path,
        word_timestamps=True,
        vad_filter=True,  # filter out non-speech
    )

    logger.info(
        "Detected language: %s (probability: %.2f)",
        info.language, info.language_probability,
    )

    chunks: list[TranscriptChunk] = []
    for i, segment in enumerate(segments):
        text = segment.text.strip()
        if not text:
            continue

        start_ms = int(segment.start * 1000)
        end_ms = int(segment.end * 1000)

        chunks.append(TranscriptChunk(
            chunk_id=f"tc_{i:04d}",
            start_ms=start_ms,
            end_ms=end_ms,
            text=text,
        ))

    logger.info("Transcribed %d segment(s), total %d chars",
                len(chunks), sum(len(c.text) for c in chunks))
    return chunks


def _transcribe_openai_whisper(
    audio_path: str, model_name: str,
) -> list[TranscriptChunk] | None:
    """Transcribe using openai-whisper (fallback)."""
    try:
        import whisper
    except ImportError:
        return None

    # openai-whisper doesn't support "large-v3" name, map it
    ow_model = model_name
    if model_name == "large-v3":
        ow_model = "large"

    logger.info("Transcribing with openai-whisper (model=%s)...", ow_model)
    model = whisper.load_model(ow_model)
    result = model.transcribe(audio_path, word_timestamps=True)

    chunks: list[TranscriptChunk] = []
    for i, segment in enumerate(result.get("segments", [])):
        text = segment.get("text", "").strip()
        if not text:
            continue

        start_ms = int(segment["start"] * 1000)
        end_ms = int(segment["end"] * 1000)

        chunks.append(TranscriptChunk(
            chunk_id=f"tc_{i:04d}",
            start_ms=start_ms,
            end_ms=end_ms,
            text=text,
        ))

    logger.info("Transcribed %d segment(s), total %d chars",
                len(chunks), sum(len(c.text) for c in chunks))
    return chunks
