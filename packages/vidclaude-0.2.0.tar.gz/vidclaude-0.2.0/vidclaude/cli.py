"""CLI orchestration: argparse, pipeline execution, caching, batch processing."""

from __future__ import annotations

import argparse
import logging
import shutil
import sys
from pathlib import Path

from .models import Evidence, save_json, load_json
from .util import (
    setup_logging, check_ffmpeg, get_cache_dir, is_cached, find_videos,
)
from .ingest import ingest
from .segment import detect_shots, extract_frames
from .audio import transcribe
from .ocr import extract_ocr
from .intent import classify_intent
from .timeline import build_timeline
from .memory import build_summaries
from .reason import generate_evidence_md, call_claude_api

logger = logging.getLogger("vidclaude")

# Bundled SKILL.md path (inside the package)
SKILL_MD_SOURCE = Path(__file__).parent / "SKILL.md"


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="vidclaude",
        description="Multimodal video understanding powered by Claude.",
        epilog=(
            "Quick start:\n"
            "  vidclaude video.mp4                     # extract + analyze\n"
            "  vidclaude video.mp4 --mode quick        # fast mode\n"
            "  vidclaude ./videos/                     # batch folder\n"
            "  vidclaude --install-skill               # set up Claude Code skill\n"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )

    parser.add_argument(
        "input", nargs="?", default=None,
        help="Video file or folder of videos",
    )
    parser.add_argument(
        "--install-skill", action="store_true",
        help="Copy SKILL.md to current directory for Claude Code integration",
    )
    parser.add_argument(
        "--extract", action="store_true",
        help="Extract evidence only (for Claude Code skill mode). "
             "Outputs cache path for Claude to read.",
    )
    parser.add_argument(
        "-q", "--question", default=None,
        help="Question to answer about the video",
    )
    parser.add_argument(
        "-f", "--fps", type=float, default=None,
        help="Frames per second to extract (overrides mode default)",
    )
    parser.add_argument(
        "-m", "--max-frames", type=int, default=None,
        help="Maximum number of frames to extract (overrides mode default)",
    )
    parser.add_argument(
        "--no-audio", action="store_true",
        help="Skip audio transcription",
    )
    parser.add_argument(
        "--no-ocr", action="store_true",
        help="Skip OCR extraction",
    )
    parser.add_argument(
        "-o", "--output", default=None,
        help="Write output to file instead of stdout",
    )
    parser.add_argument(
        "--verbose", action="store_true",
        help="Print detailed progress information",
    )
    parser.add_argument(
        "--mode", choices=["quick", "standard", "deep"], default="standard",
        help="Processing mode (default: standard)",
    )
    parser.add_argument(
        "--batch-summary", action="store_true",
        help="Generate a cross-video summary when processing a folder",
    )
    parser.add_argument(
        "--no-cache", action="store_true",
        help="Force re-extraction even if cache exists",
    )
    parser.add_argument(
        "--api", action="store_true",
        help="Use Anthropic API for reasoning (standalone mode, needs API key)",
    )

    return parser


def install_skill() -> None:
    """Copy SKILL.md to the current directory for Claude Code integration."""
    dest = Path.cwd() / "SKILL.md"

    if SKILL_MD_SOURCE.exists():
        source = SKILL_MD_SOURCE
    else:
        # Fallback: look relative to the package root
        source = Path(__file__).parent.parent / "SKILL.md"

    if not source.exists():
        print("Error: SKILL.md not found in package.", file=sys.stderr)
        sys.exit(1)

    if dest.exists():
        print(f"SKILL.md already exists at {dest}")
        response = input("Overwrite? [y/N] ").strip().lower()
        if response != "y":
            print("Skipped.")
            return

    shutil.copy2(source, dest)
    print(f"Installed SKILL.md to {dest}")
    print()
    print("You're all set! In Claude Code, just say:")
    print('  "analyze the video at path/to/video.mp4"')
    print()
    print("Or from the command line:")
    print("  vidclaude video.mp4 --mode standard --verbose")


def process_video(
    video_path: str,
    args: argparse.Namespace,
) -> tuple[str, Evidence | None]:
    """Process a single video through the extraction pipeline.

    Returns (cache_dir_path, evidence_object).
    """
    # Ingest
    meta = ingest(video_path)

    # Get or create cache directory
    cache_dir = get_cache_dir(video_path)

    # Check cache
    if not args.no_cache and is_cached(cache_dir):
        logger.info("Using cached extraction from %s", cache_dir)
        return str(cache_dir), _load_cached_evidence(cache_dir, args.question)

    # Classify intent from question
    intent = classify_intent(args.question)
    logger.info("Intent: %s", intent)

    # Detect shots
    shots = detect_shots(meta)
    save_json([s.to_dict() for s in shots], cache_dir / "shots.json")

    # Extract frames (adaptive sampling)
    frames = extract_frames(
        meta, shots, args.mode, cache_dir,
        fps_override=args.fps,
        max_frames_override=args.max_frames,
    )

    # Transcribe audio (model selected by mode: quick=base, standard/deep=large-v3)
    transcript = transcribe(
        meta, cache_dir,
        no_audio=args.no_audio,
        mode=args.mode,
    )
    save_json([t.to_dict() for t in transcript], cache_dir / "transcript.json")

    # OCR
    ocr_results = extract_ocr(frames, no_ocr=args.no_ocr, mode=args.mode)
    save_json([o.to_dict() for o in ocr_results], cache_dir / "ocr.json")

    # Build timeline
    timeline = build_timeline(shots, frames, transcript, ocr_results)
    save_json([e.to_dict() for e in timeline], cache_dir / "timeline.json")

    # Build summaries
    summaries = build_summaries(timeline, meta.duration_sec, mode=args.mode)
    save_json(summaries, cache_dir / "summaries.json")

    # Save metadata
    save_json(meta.to_dict(), cache_dir / "meta.json")

    # Build evidence object
    evidence = Evidence(
        video_meta=meta,
        question=args.question or "",
        intent=intent,
        frames=frames,
        transcript_chunks=transcript,
        ocr_results=ocr_results,
        timeline_events=timeline,
        scene_summaries=summaries.get("scene_summaries", []),
        global_summary=summaries.get("global_summary", ""),
        cache_dir=str(cache_dir),
    )

    # Generate evidence.md (always, for skill mode)
    generate_evidence_md(evidence, cache_dir)

    return str(cache_dir), evidence


def _load_cached_evidence(cache_dir: Path, question: str | None) -> Evidence:
    """Load evidence from cached files."""
    from .models import (
        VideoMeta, Frame, TranscriptChunk, OCRResult, TimelineEvent,
    )

    meta = VideoMeta.from_dict(load_json(cache_dir / "meta.json"))

    # Load frames from the frames directory
    frames_dir = cache_dir / "frames"
    frames = []
    if frames_dir.exists():
        for img_path in sorted(frames_dir.glob("frame_*.jpg")):
            parts = img_path.stem.split("_")
            # frame_NNNN_TTTTTTTT.jpg
            if len(parts) >= 3:
                seq = int(parts[1])
                ts_ms = int(parts[2])
                frames.append(Frame(
                    frame_id=f"f_{seq:04d}",
                    timestamp_ms=ts_ms,
                    shot_id="",
                    sampling_reason=["cached"],
                    image_path=str(img_path),
                ))

    transcript = [
        TranscriptChunk.from_dict(d)
        for d in load_json(cache_dir / "transcript.json")
    ] if (cache_dir / "transcript.json").exists() else []

    ocr_results = [
        OCRResult.from_dict(d)
        for d in load_json(cache_dir / "ocr.json")
    ] if (cache_dir / "ocr.json").exists() else []

    timeline = [
        TimelineEvent.from_dict(d)
        for d in load_json(cache_dir / "timeline.json")
    ] if (cache_dir / "timeline.json").exists() else []

    summaries = load_json(cache_dir / "summaries.json") if (
        cache_dir / "summaries.json"
    ).exists() else {}

    intent = classify_intent(question)

    return Evidence(
        video_meta=meta,
        question=question or "",
        intent=intent,
        frames=frames,
        transcript_chunks=transcript,
        ocr_results=ocr_results,
        timeline_events=timeline,
        scene_summaries=summaries.get("scene_summaries", []),
        global_summary=summaries.get("global_summary", ""),
        cache_dir=str(cache_dir),
    )


def main() -> None:
    """Main entry point for the CLI."""
    parser = build_parser()
    args = parser.parse_args()

    # Handle --install-skill before anything else
    if args.install_skill:
        install_skill()
        return

    # Require input for all other operations
    if args.input is None:
        parser.print_help()
        sys.exit(1)

    setup_logging(args.verbose)

    # Preflight checks
    if not check_ffmpeg():
        print(
            "Error: ffmpeg not found on PATH.\n"
            "Install from https://ffmpeg.org or via your package manager.\n"
            "  Windows: winget install ffmpeg\n"
            "  macOS:   brew install ffmpeg\n"
            "  Linux:   sudo apt install ffmpeg",
            file=sys.stderr,
        )
        sys.exit(1)

    # Find videos to process
    try:
        video_paths = find_videos(args.input)
    except (FileNotFoundError, ValueError) as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)

    logger.info("Found %d video(s) to process", len(video_paths))

    results: list[tuple[str, str, Evidence | None]] = []  # (path, cache_dir, evidence)

    for i, video_path in enumerate(video_paths):
        if len(video_paths) > 1:
            print(f"\n--- Processing [{i+1}/{len(video_paths)}]: {video_path} ---",
                  file=sys.stderr)

        try:
            cache_dir, evidence = process_video(video_path, args)
            results.append((video_path, cache_dir, evidence))
        except KeyboardInterrupt:
            print("\nInterrupted.", file=sys.stderr)
            sys.exit(130)
        except Exception as e:
            logger.error("Failed to process %s: %s", video_path, e)
            if args.verbose:
                import traceback
                traceback.print_exc()
            continue

    if not results:
        print("No videos were successfully processed.", file=sys.stderr)
        sys.exit(1)

    # Output
    output_text = ""

    if args.extract:
        # Skill mode: print cache paths and summary
        for video_path, cache_dir, evidence in results:
            print(f"Extracted: {video_path}")
            print(f"  Cache: {cache_dir}")
            if evidence:
                print(f"  Frames: {len(evidence.frames)}")
                print(f"  Transcript chunks: {len(evidence.transcript_chunks)}")
                print(f"  OCR results: {len(evidence.ocr_results)}")
                print(f"  Timeline events: {len(evidence.timeline_events)}")
                print(f"  Evidence report: {cache_dir}/evidence.md")

    elif args.api:
        # Standalone API mode
        for video_path, cache_dir, evidence in results:
            if evidence:
                try:
                    answer = call_claude_api(evidence)
                    output_text += f"## {video_path}\n\n{answer}\n\n"
                except Exception as e:
                    logger.error("API call failed for %s: %s", video_path, e)
                    output_text += f"## {video_path}\n\nError: {e}\n\n"

    else:
        # Default: extract mode behavior (most useful)
        for video_path, cache_dir, evidence in results:
            print(f"Extracted: {video_path}")
            print(f"  Cache: {cache_dir}")
            if evidence:
                print(f"  Frames: {len(evidence.frames)}")
                print(f"  Transcript chunks: {len(evidence.transcript_chunks)}")
                print(f"  Timeline events: {len(evidence.timeline_events)}")
                print(f"  Evidence report: {cache_dir}/evidence.md")

    # Batch summary
    if args.batch_summary and len(results) > 1:
        output_text += "\n## Batch Summary\n\n"
        for video_path, cache_dir, evidence in results:
            if evidence:
                output_text += f"- **{Path(video_path).name}**: "
                output_text += f"{len(evidence.frames)} frames, "
                output_text += f"{len(evidence.transcript_chunks)} transcript segments, "
                output_text += f"{len(evidence.timeline_events)} timeline events\n"

    # Write output
    if output_text:
        if args.output:
            Path(args.output).write_text(output_text, encoding="utf-8")
            print(f"Output written to {args.output}", file=sys.stderr)
        else:
            print(output_text)
