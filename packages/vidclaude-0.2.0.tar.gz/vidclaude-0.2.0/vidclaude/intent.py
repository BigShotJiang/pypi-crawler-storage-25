"""Intent classification for query-conditioned processing.

Classifies user questions into intent categories and returns
processing configuration that adjusts pipeline behavior.
"""

from __future__ import annotations

import re


# Intent class definitions
INTENT_DESCRIBE = "describe"
INTENT_MOMENT = "moment_retrieval"
INTENT_TEMPORAL = "temporal_ordering"
INTENT_COUNTING = "counting"
INTENT_OCR = "ocr_extraction"
INTENT_SPEECH = "speech_understanding"
INTENT_GENERAL = "general_qa"

# Pattern-based classification rules (checked in order, first match wins)
_INTENT_PATTERNS: list[tuple[str, list[str]]] = [
    (INTENT_COUNTING, [
        r"\bhow many\b", r"\bcount\b", r"\bhow often\b",
        r"\bnumber of\b", r"\bfrequency\b",
    ]),
    (INTENT_TEMPORAL, [
        r"\bbefore\b.*\bafter\b", r"\bafter\b.*\bbefore\b",
        r"\bfirst\b.*\bthen\b", r"\border\b", r"\bsequence\b",
        r"\bbefore or after\b", r"\bwhich came first\b",
        r"\bchronolog", r"\btimeline\b",
    ]),
    (INTENT_MOMENT, [
        r"\bwhen\b", r"\bat what point\b", r"\bat what time\b",
        r"\bwhat time\b", r"\btimestamp\b", r"\bmoment\b",
        r"\bfind the part\b", r"\bshow me where\b",
    ]),
    (INTENT_OCR, [
        r"\btext\b", r"\bread\b", r"\bsign\b", r"\bslide\b",
        r"\bwritten\b", r"\bscreen\b", r"\bdisplay\b",
        r"\btitle\b", r"\bcaption\b", r"\bsubtitle\b",
        r"\bwhat does it say\b", r"\bwhat is written\b",
    ]),
    (INTENT_SPEECH, [
        r"\bsay\b", r"\bsaid\b", r"\bmention\b", r"\bspeak\b",
        r"\bspoke\b", r"\btalk\b", r"\bword\b", r"\bdiscuss\b",
        r"\bconversat", r"\bdialog",
    ]),
    (INTENT_DESCRIBE, [
        r"\bdescribe\b", r"\bsummar", r"\bwhat happens\b",
        r"\bwhat is happening\b", r"\boverview\b", r"\bwhat.s going on\b",
    ]),
]


def classify_intent(question: str | None) -> str:
    """Classify a user question into an intent category.

    Returns one of the INTENT_* constants.
    """
    if not question:
        return INTENT_DESCRIBE

    q = question.lower().strip()

    for intent, patterns in _INTENT_PATTERNS:
        for pattern in patterns:
            if re.search(pattern, q):
                return intent

    return INTENT_GENERAL


# Processing config per intent — adjusts pipeline behavior
_INTENT_CONFIGS: dict[str, dict] = {
    INTENT_DESCRIBE: {
        "prioritize_ocr": False,
        "prioritize_transcript": False,
        "dense_sampling": False,
    },
    INTENT_MOMENT: {
        "prioritize_ocr": False,
        "prioritize_transcript": True,
        "dense_sampling": False,
    },
    INTENT_TEMPORAL: {
        "prioritize_ocr": False,
        "prioritize_transcript": True,
        "dense_sampling": False,
    },
    INTENT_COUNTING: {
        "prioritize_ocr": False,
        "prioritize_transcript": False,
        "dense_sampling": True,
    },
    INTENT_OCR: {
        "prioritize_ocr": True,
        "prioritize_transcript": False,
        "dense_sampling": False,
    },
    INTENT_SPEECH: {
        "prioritize_ocr": False,
        "prioritize_transcript": True,
        "dense_sampling": False,
    },
    INTENT_GENERAL: {
        "prioritize_ocr": False,
        "prioritize_transcript": False,
        "dense_sampling": False,
    },
}


def get_processing_config(intent: str) -> dict:
    """Get processing configuration for an intent class."""
    return dict(_INTENT_CONFIGS.get(intent, _INTENT_CONFIGS[INTENT_GENERAL]))
