---
name: video-understand
description: >
  Analyze video files using multimodal extraction (frames, audio transcript,
  OCR, timeline) and Claude's reasoning. Use when the user asks to analyze,
  understand, describe, or answer questions about a video file or folder of
  videos. Triggers on: "analyze this video", "what happens in this video",
  "describe the video", "video question", any path ending in
  .mp4/.mov/.mkv/.webm followed by a question about it.
tools: ["Bash", "Read", "Glob"]
---

# Video Understanding Skill

Analyze videos by extracting visual frames, audio transcripts, OCR text, and
temporal timelines, then reasoning over the combined evidence.

## How It Works

This skill uses a Python extraction pipeline (`video_understand.py`) that:
1. Ingests the video and extracts metadata via ffprobe
2. Detects shot boundaries using ffmpeg scene change detection
3. Adaptively samples frames (more frames at scene transitions)
4. Transcribes audio using OpenAI Whisper (if installed)
5. Extracts on-screen text via OCR (if pytesseract installed)
6. Builds a unified temporal timeline of all events
7. Generates an `evidence.md` report + cached artifacts

You (Claude) then read the evidence and frame images to reason over the video.

## Step-by-Step Usage

### Step 1: Extract evidence from the video

Run the extraction pipeline:

```bash
python D:/ai_creative_stuff/claudevid/video_understand.py "<video_path>" --extract --mode standard --verbose
```

For quick analysis (fewer frames, faster):
```bash
python D:/ai_creative_stuff/claudevid/video_understand.py "<video_path>" --extract --mode quick --verbose
```

For deep analysis (more frames, OCR on all frames):
```bash
python D:/ai_creative_stuff/claudevid/video_understand.py "<video_path>" --extract --mode deep --verbose
```

### Step 2: Read the evidence report

The script outputs a cache directory path. Read the evidence report:

```bash
# The cache path is printed by the script, e.g.:
#   Cache: /path/to/.vidcache/a3f7b2c1
# Read the evidence:
cat /path/to/.vidcache/<hash>/evidence.md
```

Use the Read tool to read `evidence.md` from the cache directory.

### Step 3: View key frames

Read the frame images listed in evidence.md to see what's in the video.
Select 5-10 representative frames spread across the video's duration.
Use the Read tool on the frame image paths.

### Step 4: Answer the question

Reason over the combined evidence (timeline, transcript, OCR, frames) to
answer the user's question. Ground claims in timestamps. Note uncertainties.

### Follow-up Questions

For follow-up questions about the same video, the cache already exists.
Re-read the evidence.md and relevant frames — no need to re-extract.

To force re-extraction: add `--no-cache` flag.

## Batch Processing

Process a folder of videos:
```bash
python D:/ai_creative_stuff/claudevid/video_understand.py "<folder_path>" --extract --mode standard --verbose
```

## CLI Reference

| Flag | Default | Description |
|------|---------|-------------|
| `input` | required | Video file or folder path |
| `--extract` | off | Extract only (skill mode, no API key needed) |
| `-q "..."` | none | Question (for API standalone mode) |
| `-f N` | mode default | Frames per second override |
| `-m N` | mode default | Max frames override |
| `--no-audio` | off | Skip audio transcription |
| `--no-ocr` | off | Skip OCR extraction |
| `--mode` | standard | quick / standard / deep |
| `--verbose` | off | Detailed progress output |
| `--no-cache` | off | Force re-extraction |
| `--api` | off | Standalone mode (needs ANTHROPIC_API_KEY) |
| `-o file` | stdout | Write output to file |

## Modes Comparison

| Aspect | quick | standard | deep |
|--------|-------|----------|------|
| Frame sampling | 0.2fps, max 20 | 0.5fps + shot boundaries, max 60 | 1.0fps + burst, max 150 |
| Audio | whisper base | whisper base | whisper small |
| OCR | skip | keyframes only | all frames |
| Summaries | skip | for videos > 5min | always |

## Prerequisites

1. **Python 3.10+**
2. **ffmpeg** on PATH — `winget install ffmpeg` or download from https://ffmpeg.org
3. **Pillow**: `pip install Pillow`
4. **Whisper** (optional): `pip install openai-whisper` (requires PyTorch)
5. **Tesseract** (optional): Install Tesseract OCR + `pip install pytesseract`

## Troubleshooting

- **"ffmpeg not found"**: Ensure ffmpeg is on your PATH. Run `ffmpeg -version` to verify.
- **"openai-whisper not installed"**: Audio will be skipped. Install with `pip install openai-whisper`.
- **Slow frame extraction**: Use `--mode quick` or reduce with `-m 10`.
- **Large cache**: Delete `.vidcache/` folders to free space.
- **Re-analyze same video**: Use `--no-cache` to force fresh extraction.

## Extension Ideas

- **OmniVision offline footage review**: Process security/dashcam footage folders,
  generate timeline reports, flag anomalous events
- **Meeting summarization**: Extract slides (OCR) + transcript, generate meeting notes
- **Content moderation**: Scan video batches for policy violations
- **Sports analysis**: Dense frame extraction for play-by-play breakdown
- **Accessibility**: Generate audio descriptions from visual content
