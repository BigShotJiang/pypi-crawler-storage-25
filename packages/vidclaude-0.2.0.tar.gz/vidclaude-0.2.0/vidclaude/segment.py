"""Layers B+C: Shot boundary detection and adaptive visual sampling.

Shot detection uses ffmpeg's scene change filter.
Adaptive sampling adjusts frame rate based on content and mode.
"""

from __future__ import annotations

import logging
import re
from pathlib import Path

from .models import VideoMeta, Shot, Frame
from .util import run_ffmpeg

logger = logging.getLogger("vidclaude")

# Mode-specific sampling parameters
MODE_CONFIG = {
    "quick": {
        "base_fps": 0.2,
        "max_frames": 20,
        "burst_frames": 0,      # no extra frames at transitions
    },
    "standard": {
        "base_fps": 0.5,
        "max_frames": 60,
        "burst_frames": 2,      # +2 frames around each shot boundary
    },
    "deep": {
        "base_fps": 1.0,
        "max_frames": 150,
        "burst_frames": 4,      # +4 frames around transitions
    },
}


def detect_shots(meta: VideoMeta, threshold: float = 0.3) -> list[Shot]:
    """Detect shot boundaries using ffmpeg scene change filter.

    Returns a list of Shot objects representing contiguous segments.
    """
    logger.info("Detecting shots (threshold=%.2f)...", threshold)

    # Use select filter with scene detection + showinfo to get timestamps
    result = run_ffmpeg([
        "-i", meta.path,
        "-vf", f"select='gt(scene,{threshold})',showinfo",
        "-vsync", "vfr",
        "-f", "null",
        "-",
    ])

    # Parse showinfo output from stderr for timestamps
    # Pattern: [Parsed_showinfo...] n:... pts:... pts_time:12.345 ...
    boundary_times: list[float] = [0.0]  # video always starts at 0
    for line in result.stderr.split("\n"):
        match = re.search(r"pts_time:\s*([\d.]+)", line)
        if match:
            t = float(match.group(1))
            if t > 0:
                boundary_times.append(t)

    # Also get scene scores where available
    scores: list[float] = []
    for line in result.stderr.split("\n"):
        match = re.search(r"scene_score=\s*([\d.]+)", line)
        if match:
            scores.append(float(match.group(1)))

    # Add video end as final boundary
    boundary_times.append(meta.duration_sec)

    # Remove duplicates and sort
    boundary_times = sorted(set(boundary_times))

    # Build shots from consecutive boundary pairs
    shots: list[Shot] = []
    for i in range(len(boundary_times) - 1):
        start_ms = int(boundary_times[i] * 1000)
        end_ms = int(boundary_times[i + 1] * 1000)
        if end_ms <= start_ms:
            continue
        score = scores[i] if i < len(scores) else threshold
        shots.append(Shot(
            shot_id=f"s_{i:04d}",
            start_ms=start_ms,
            end_ms=end_ms,
            score=score,
        ))

    # If no shots detected (no scene changes), treat entire video as one shot
    if not shots:
        shots = [Shot(
            shot_id="s_0000",
            start_ms=0,
            end_ms=int(meta.duration_sec * 1000),
            score=0.0,
        )]

    logger.info("Detected %d shot(s)", len(shots))
    return shots


def compute_sample_timestamps(
    meta: VideoMeta,
    shots: list[Shot],
    mode: str,
    fps_override: float | None = None,
    max_frames_override: int | None = None,
) -> list[tuple[int, list[str]]]:
    """Compute which timestamps to sample frames at.

    Returns list of (timestamp_ms, [sampling_reasons]).
    """
    config = MODE_CONFIG[mode]
    base_fps = fps_override if fps_override is not None else config["base_fps"]
    max_frames = max_frames_override if max_frames_override is not None else config["max_frames"]
    burst = config["burst_frames"]

    duration_ms = int(meta.duration_sec * 1000)

    # Smart frame budget: reduce fps if we'd exceed max_frames
    total_base = int(meta.duration_sec * base_fps)
    if total_base > max_frames:
        base_fps = max_frames / meta.duration_sec
        logger.info("Auto-reduced fps to %.3f to stay under %d frames", base_fps, max_frames)

    # Step 1: Base sampling at uniform intervals
    samples: dict[int, list[str]] = {}  # timestamp_ms -> reasons
    if base_fps > 0 and meta.duration_sec > 0:
        interval_ms = int(1000 / base_fps)
        t = 0
        while t < duration_ms:
            samples[t] = ["base"]
            t += interval_ms

    # Ensure at least one frame
    if not samples:
        samples[0] = ["base"]

    # Step 2: Burst frames around shot boundaries
    if burst > 0 and len(shots) > 1:
        for shot in shots[1:]:  # skip first boundary (t=0)
            boundary_ms = shot.start_ms
            # Add frames before and after the boundary
            for offset in range(-burst // 2, burst // 2 + 1):
                t = boundary_ms + offset * 200  # 200ms spacing for burst frames
                if 0 <= t < duration_ms:
                    if t in samples:
                        if "shot_boundary" not in samples[t]:
                            samples[t].append("shot_boundary")
                    else:
                        samples[t] = ["shot_boundary"]

    # Step 3: Enforce max_frames budget
    sorted_samples = sorted(samples.items(), key=lambda x: x[0])
    if len(sorted_samples) > max_frames:
        # Prioritize: shot_boundary frames first, then evenly spaced base frames
        boundary_frames = [(t, r) for t, r in sorted_samples if "shot_boundary" in r]
        base_frames = [(t, r) for t, r in sorted_samples if "shot_boundary" not in r]

        # Keep all boundary frames up to half the budget
        max_boundary = min(len(boundary_frames), max_frames // 2)
        kept_boundary = boundary_frames[:max_boundary]

        # Fill remaining budget with evenly spaced base frames
        remaining = max_frames - len(kept_boundary)
        if remaining > 0 and base_frames:
            step = max(1, len(base_frames) // remaining)
            kept_base = base_frames[::step][:remaining]
        else:
            kept_base = []

        sorted_samples = sorted(kept_boundary + kept_base, key=lambda x: x[0])

    logger.debug("Computed %d sample timestamps", len(sorted_samples))
    return sorted_samples


def extract_frames(
    meta: VideoMeta,
    shots: list[Shot],
    mode: str,
    cache_dir: Path,
    fps_override: float | None = None,
    max_frames_override: int | None = None,
) -> list[Frame]:
    """Extract frames from video based on adaptive sampling.

    Saves frames as JPEG to cache_dir/frames/ and returns Frame objects.
    """
    frames_dir = cache_dir / "frames"
    frames_dir.mkdir(exist_ok=True)

    timestamps = compute_sample_timestamps(
        meta, shots, mode, fps_override, max_frames_override
    )

    logger.info("Extracting %d frames...", len(timestamps))

    frames: list[Frame] = []
    shot_index = 0

    for seq, (ts_ms, reasons) in enumerate(timestamps):
        # Find which shot this timestamp belongs to
        while shot_index < len(shots) - 1 and ts_ms >= shots[shot_index].end_ms:
            shot_index += 1
        shot_id = shots[shot_index].shot_id if shot_index < len(shots) else "s_unknown"

        # Output filename: frame_NNNN_TTTTTTTT.jpg
        fname = f"frame_{seq:04d}_{ts_ms:08d}.jpg"
        out_path = frames_dir / fname

        # Extract single frame at this timestamp
        ts_sec = ts_ms / 1000.0
        result = run_ffmpeg([
            "-ss", f"{ts_sec:.3f}",
            "-i", meta.path,
            "-frames:v", "1",
            "-q:v", "2",
            "-y",
            str(out_path),
        ])

        if result.returncode != 0 or not out_path.exists():
            logger.warning("Failed to extract frame at %.3fs", ts_sec)
            continue

        frames.append(Frame(
            frame_id=f"f_{seq:04d}",
            timestamp_ms=ts_ms,
            shot_id=shot_id,
            sampling_reason=reasons,
            image_path=str(out_path),
        ))

    logger.info("Extracted %d frames successfully", len(frames))
    return frames
