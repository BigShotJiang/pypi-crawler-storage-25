"""Data models for video understanding pipeline.

All types are time-grounded with timestamp_ms or start_ms/end_ms fields.
Includes JSON serialization for caching.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Any


@dataclass
class VideoMeta:
    """Layer A output: validated video metadata."""
    path: str
    duration_sec: float
    fps: float
    resolution: tuple[int, int]
    audio_tracks: int
    format: str
    file_size_bytes: int = 0

    def to_dict(self) -> dict[str, Any]:
        d = asdict(self)
        d["resolution"] = list(d["resolution"])
        return d

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> VideoMeta:
        d = dict(d)
        d["resolution"] = tuple(d["resolution"])
        return cls(**d)


@dataclass
class Shot:
    """Layer B output: a detected shot boundary segment."""
    shot_id: str
    start_ms: int
    end_ms: int
    score: float  # scene change confidence at the boundary

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> Shot:
        return cls(**d)


@dataclass
class Frame:
    """Layer C output: an extracted frame with metadata."""
    frame_id: str
    timestamp_ms: int
    shot_id: str
    sampling_reason: list[str]  # e.g. ["base", "shot_boundary", "high_motion"]
    image_path: str

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> Frame:
        return cls(**d)


@dataclass
class TranscriptChunk:
    """Layer D output: a timestamped speech segment."""
    chunk_id: str
    start_ms: int
    end_ms: int
    text: str
    speaker: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> TranscriptChunk:
        return cls(**d)


@dataclass
class OCRResult:
    """Layer E output: text extracted from a frame."""
    frame_id: str
    timestamp_ms: int
    text: str
    confidence: float

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> OCRResult:
        return cls(**d)


@dataclass
class TimelineEvent:
    """Layer G output: a unified event from any modality."""
    event_id: str
    start_ms: int
    end_ms: int | None
    modality: str  # "visual" | "speech" | "ocr" | "scene_change"
    summary: str
    source_ids: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> TimelineEvent:
        return cls(**d)


@dataclass
class Evidence:
    """Layer J input: the assembled context pack for Claude reasoning."""
    video_meta: VideoMeta
    question: str
    intent: str
    frames: list[Frame]
    transcript_chunks: list[TranscriptChunk]
    ocr_results: list[OCRResult]
    timeline_events: list[TimelineEvent]
    scene_summaries: list[str] = field(default_factory=list)
    global_summary: str = ""
    cache_dir: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {
            "video_meta": self.video_meta.to_dict(),
            "question": self.question,
            "intent": self.intent,
            "frames": [f.to_dict() for f in self.frames],
            "transcript_chunks": [t.to_dict() for t in self.transcript_chunks],
            "ocr_results": [o.to_dict() for o in self.ocr_results],
            "timeline_events": [e.to_dict() for e in self.timeline_events],
            "scene_summaries": self.scene_summaries,
            "global_summary": self.global_summary,
            "cache_dir": self.cache_dir,
        }


# --- JSON file helpers ---

def save_json(data: list[dict] | dict, path: str | Path) -> None:
    """Save data to a JSON file."""
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)


def load_json(path: str | Path) -> Any:
    """Load data from a JSON file."""
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)
