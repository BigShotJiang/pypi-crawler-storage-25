# Mission Brief — {{name}}

## Task Description
<!-- REQUIRED: What should the model do? Be specific. -->

## Tools / Functions Available
<!-- What tools/functions/commands can the model call? List them all with schemas. -->

## Constraints
<!-- Hard rules the model must follow. Safety constraints, forbidden outputs, etc. -->

## Why This Model Exists
<!-- What problem does this solve? What's the use case? Who uses it? -->

## Input Format
<!-- Exactly how inputs are structured. Show the full format with examples. -->

## Output Format
<!-- Exactly how outputs should look. Show the schema. -->

## Edge Cases
<!-- Known tricky inputs the model must handle correctly. -->

## Quality Definition
<!-- What does "correct" mean for this task? How is it scored? -->
