# Background — {{name}}

<!-- ============================================================
     BACKGROUND.md — Static domain knowledge for Claude datagen.

     This file is your "prompt engineering" for synthetic data
     generation. It is ALWAYS included in full (never truncated)
     in every Claude augmentation call.

     Write this once and keep it accurate. The better this file,
     the more realistic and diverse your generated training data.

     DO NOT put iteration logs or run history here — that belongs
     in AGENT_CONTEXT.md (auto-managed by forge flywheel).
     ============================================================ -->

## Task

<!-- What does this model do? Be specific about the exact task.
     Example: "Route incoming user messages to one of 5 drone
     commands, returning a structured JSON object." -->


## Output Format

<!-- Exactly how the assistant output must be structured.
     Show the full JSON schema or format with a real example.

     Example:
     Output must always be valid JSON matching this schema:
     {
       "cmd": "<command_name>",
       "args": { ... },
       "confidence": <0.0–1.0>
     }

     Concrete example:
     Input:  "Go to the waypoint at grid B4"
     Output: {"cmd": "goto_waypoint", "args": {"grid": "B4"}, "confidence": 0.97}
-->


## Edge Cases

<!-- Inputs that look ambiguous or tricky but have a correct answer.
     List them explicitly so Claude generates targeted coverage.

     Example:
     - "Land now" vs "Land at base" → different cmd values
     - Coordinates can be grid refs ("B4") or lat/lon floats
     - "Return home" = cmd:rtl, NOT cmd:goto_waypoint
     - Empty input → cmd:unknown, confidence:0.0
     - Multiple commands in one sentence → pick the primary intent
-->


## Common Failure Patterns

<!-- What has the model historically gotten wrong?
     Update this section as you discover patterns from eval failures.

     Example:
     - Confuses "hover" with "loiter" — they are different commands
     - Drops "args" key entirely when no args are needed (must include empty {})
     - Outputs plain text instead of JSON when input contains a question mark
     - Hallucinated command names: "ascend_fast" (invalid) vs "ascend" (valid)
-->


## What Good Examples Look Like

<!-- Describe the ideal training example: input phrasing variety,
     output correctness criteria, difficulty range.

     Example:
     Good inputs vary in:
     - Formality: "go to B4" / "please proceed to grid B4" / "move to waypoint B4"
     - Length: single words to full sentences
     - Ambiguity: some require inference, most are clear

     Good outputs:
     - Always valid JSON, no trailing text
     - cmd value is from the exact allowed list (no synonyms)
     - args keys match the command's schema exactly
     - confidence is honest (0.6–0.8 for ambiguous, 0.9–1.0 for clear)

     Avoid:
     - Trivially easy examples (all the same phrasing)
     - Impossible/trick inputs that have no valid answer
     - Outputs with extra prose before/after the JSON
-->
