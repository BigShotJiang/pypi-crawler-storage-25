"""forge CLI entry point."""
import click
from rich.console import Console
from forge import __version__

console = Console()

@click.group()
@click.version_option(version=__version__, prog_name="forge")
def main():
    """forge — self-improving SLM flywheel.

    Turn any directory into a fine-tuning project that trains,
    evaluates, promotes, and augments itself toward a target accuracy.
    """
    pass


# ── Sub-command imports (lazy to keep startup fast) ──────────────────────────

from forge.commands.init     import init
from forge.commands.train    import train
from forge.commands.eval     import evaluate
from forge.commands.flywheel import flywheel
from forge.commands.status   import status
from forge.commands.augment  import augment
from forge.commands.patch    import patch
from forge.commands.promote  import promote
from forge.commands.push     import push
from forge.commands.clean    import clean
from forge.commands.generate  import generate
from forge.commands.audit     import audit
from forge.commands.pretrain    import pretrain
from forge.commands.probe_cmd   import probe
from forge.commands.cloud_train    import cloud_train
from forge.commands.batch_generate import batch_generate

main.add_command(init)
main.add_command(train)
main.add_command(evaluate, name="eval")
main.add_command(flywheel)
main.add_command(status)
main.add_command(augment)
main.add_command(patch)
main.add_command(promote)
main.add_command(push)
main.add_command(clean)
main.add_command(generate)
main.add_command(audit)
main.add_command(pretrain)
main.add_command(probe)
main.add_command(cloud_train, name="cloud-train")
main.add_command(batch_generate, name="batch-generate")
