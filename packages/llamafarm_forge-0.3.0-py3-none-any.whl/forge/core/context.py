"""AGENT_CONTEXT.md — living memory for the flywheel agent.

Two-file context system
-----------------------
BACKGROUND.md    — Static, human-authored domain knowledge (output format, edge cases,
                   good example patterns, common failure modes). Written once by the
                   project author; NEVER auto-modified. Always included in full in
                   every Claude datagen prompt.

AGENT_CONTEXT.md — Auto-updated iteration log. Appended by the flywheel each round
                   with accuracy, loss, failure breakdown, and diffs vs prior round.
                   Truncated to ~5000 chars (most recent content kept) when fed to
                   Claude so it stays within context budget.
"""
from __future__ import annotations
import json
from datetime import datetime
from pathlib import Path
from typing import Optional


CONTEXT_FILE = "AGENT_CONTEXT.md"
MAX_TOKENS = 5000   # approx chars to feed into Claude prompts


def load(project_dir: Path) -> str:
    """Return the last MAX_TOKENS chars of AGENT_CONTEXT.md, or empty string."""
    p = project_dir / CONTEXT_FILE
    if not p.exists():
        return ""
    text = p.read_text()
    # Truncate from the top if too long (keep recent history)
    if len(text) > MAX_TOKENS * 4:
        text = "...[truncated]...\n" + text[-(MAX_TOKENS * 4):]
    return text


def update(
    project_dir: Path,
    iteration: int,
    accuracy: float,
    failures: list[dict],
    train_file: str,
    loss: float,
    prev_failures: Optional[list[dict]] = None,
):
    """Append a new iteration record to AGENT_CONTEXT.md."""
    p = project_dir / CONTEXT_FILE
    ts = datetime.now().strftime("%Y-%m-%d %H:%M CDT")

    # Diff failures vs previous to find new/resolved/persistent
    curr_cmds = _failure_counts(failures)
    prev_cmds = _failure_counts(prev_failures or [])

    new_failures = {k: v for k, v in curr_cmds.items() if k not in prev_cmds}
    resolved = {k: v for k, v in prev_cmds.items() if k not in curr_cmds}
    persistent = {k: v for k, v in curr_cmds.items() if k in prev_cmds}

    # Build entry
    entry = f"""
### Iteration {iteration} — {ts}
- **Accuracy**: {accuracy*100:.1f}% ({int(accuracy*267)}/267) | Loss: {loss:.4f}
- **Train file**: {Path(train_file).name}
- **Total failures**: {len(failures)}

**Failure breakdown**: {json.dumps(dict(sorted(curr_cmds.items(), key=lambda x: -x[1])), indent=None)}
"""
    if resolved:
        entry += f"**Resolved this iter**: {list(resolved.keys())}\n"
    if new_failures:
        entry += f"**New failures**: {new_failures}\n"
    if persistent:
        top = sorted(persistent.items(), key=lambda x: -x[1])[:5]
        entry += f"**Persistent** (need more attention): {dict(top)}\n"

    # Append to file (create if missing)
    if not p.exists():
        p.write_text(_header())
    with open(p, "a") as f:
        f.write(entry)


def _failure_counts(failures: list[dict]) -> dict:
    counts: dict[str, int] = {}
    for f in failures:
        cmd = f.get("gold_cmd", "?")
        counts[cmd] = counts.get(cmd, 0) + 1
    return counts


def _header() -> str:
    return f"""# Agent Context — llamadrone-mission-router
*Auto-updated by forge flywheel*

This file is fed into every augmentation/datagen Claude call.
Keep it as a concise record of what has been tried and what persists.

## Score History

| Iter | Accuracy | Failures | Train file | Notes |
|------|----------|----------|------------|-------|

## Iteration Log
"""
