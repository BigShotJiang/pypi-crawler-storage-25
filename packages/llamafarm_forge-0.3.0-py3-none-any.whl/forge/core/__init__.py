"""forge.core — config, context, dataset, and planner modules."""
