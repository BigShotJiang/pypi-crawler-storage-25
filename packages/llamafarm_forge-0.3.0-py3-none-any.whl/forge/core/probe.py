"""forge/core/probe.py — knowledge probe runner (pre/post pretrain scoring)."""
from __future__ import annotations

import json
import time
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

JUDGE_MODEL = "claude-sonnet-4-6"

JUDGE_PROMPT = """\
You are evaluating whether a language model correctly answered a domain knowledge question.

Question: {question}
Ideal answer: {ideal}
Model answer: {model_answer}

Score the model answer on a 0–3 scale:
3 = Correct and complete
2 = Mostly correct, minor gaps or imprecision
1 = Partially correct, significant gaps
0 = Wrong, irrelevant, or refused to answer

Respond with JSON only, no other text: {{"score": <0-3>, "reasoning": "<one sentence>"}}"""


def load_probe_questions(probe_path: Path) -> List[Dict[str, str]]:
    """Load probe.jsonl — each line: {"question": "...", "ideal": "..."}"""
    if not probe_path.exists():
        raise FileNotFoundError(
            f"Probe file not found: {probe_path}\n"
            "Create dataset/probe.jsonl with lines: "
            '{"question": "...", "ideal": "..."}'
        )
    questions = []
    with open(probe_path, encoding="utf-8") as f:
        for i, line in enumerate(f, 1):
            line = line.strip()
            if not line:
                continue
            obj = json.loads(line)
            if "question" not in obj or "ideal" not in obj:
                raise ValueError(f"probe.jsonl line {i}: must have 'question' and 'ideal' fields")
            questions.append(obj)
    return questions


def run_model_inference(questions: List[Dict], model, tokenizer, max_new_tokens: int = 256) -> List[str]:
    """Run each question through the model and return a list of answers."""
    import torch
    answers = []
    for q in questions:
        prompt = q["question"]
        inputs = tokenizer(prompt, return_tensors="pt").to(model.device)
        with torch.no_grad():
            out = model.generate(
                **inputs,
                max_new_tokens=max_new_tokens,
                do_sample=False,
                pad_token_id=tokenizer.eos_token_id,
            )
        # decode only new tokens
        new_tokens = out[0][inputs["input_ids"].shape[1]:]
        answer = tokenizer.decode(new_tokens, skip_special_tokens=True).strip()
        answers.append(answer)
    return answers


def judge_answer(client, question: str, ideal: str, model_answer: str) -> Dict[str, Any]:
    """Call Claude to judge a single answer. Returns {"score": 0-3, "reasoning": str}."""
    prompt = JUDGE_PROMPT.format(
        question=question,
        ideal=ideal,
        model_answer=model_answer if model_answer else "(no output)",
    )
    msg = client.messages.create(
        model=JUDGE_MODEL,
        max_tokens=200,
        messages=[{"role": "user", "content": prompt}],
    )
    raw = msg.content[0].text.strip()
    # strip markdown code fences if present
    if raw.startswith("```"):
        raw = raw.split("```")[1]
        if raw.startswith("json"):
            raw = raw[4:]
        raw = raw.strip()
    return json.loads(raw)


def run_probe(
    project_dir: Path,
    cfg: dict,
    tag: str = "probe",
    adapter_path: Optional[Path] = None,
    max_new_tokens: int = 256,
) -> Dict[str, Any]:
    """
    Full probe run: load model → infer → judge → save results.
    Returns the results dict.
    """
    import anthropic

    probe_path = project_dir / "dataset" / "probe.jsonl"
    output_dir = project_dir / "output"
    output_dir.mkdir(exist_ok=True)

    questions = load_probe_questions(probe_path)
    print(f"\n[probe] {len(questions)} questions | tag={tag}")

    # ── Load model ────────────────────────────────────────────────────────────
    model_id = cfg["model"]["base"]
    max_seq_len = cfg["model"].get("max_seq_len", 2048)
    load_in_4bit = cfg["model"].get("load_in_4bit", True)

    print(f"[probe] Loading model: {model_id}")
    from unsloth import FastLanguageModel  # type: ignore
    model, tokenizer = FastLanguageModel.from_pretrained(
        model_name=str(adapter_path) if adapter_path else model_id,
        max_seq_length=max_seq_len,
        load_in_4bit=load_in_4bit,
    )
    FastLanguageModel.for_inference(model)

    # ── Inference ─────────────────────────────────────────────────────────────
    print("[probe] Running inference...")
    start = time.time()
    answers = run_model_inference(questions, model, tokenizer, max_new_tokens=max_new_tokens)

    # ── Judge ─────────────────────────────────────────────────────────────────
    print("[probe] Judging with Claude...")
    client = anthropic.Anthropic()
    results_per_q = []
    total_score = 0

    for q, answer in zip(questions, answers):
        judgment = judge_answer(client, q["question"], q["ideal"], answer)
        score = int(judgment.get("score", 0))
        total_score += score
        results_per_q.append({
            "question": q["question"],
            "ideal": q["ideal"],
            "model_answer": answer,
            "score": score,
            "judge_reasoning": judgment.get("reasoning", ""),
        })

    n = len(questions)
    mean_score = round(total_score / n, 3) if n else 0.0
    pct_correct = round(sum(1 for r in results_per_q if r["score"] == 3) / n, 3) if n else 0.0
    elapsed = round((time.time() - start) / 60, 1)

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    results = {
        "tag": tag,
        "timestamp": timestamp,
        "model": model_id,
        "adapter": str(adapter_path) if adapter_path else None,
        "total": n,
        "mean_score": mean_score,
        "max_score": 3,
        "pct_correct": pct_correct,
        "elapsed_min": elapsed,
        "results": results_per_q,
    }

    out_path = output_dir / f"probe_{tag}_{timestamp}.json"
    out_path.write_text(json.dumps(results, indent=2))
    print(f"[probe] Results saved to {out_path}")

    return results


def load_probe_results(output_dir: Path, tag: str) -> Optional[Dict]:
    """Load the most recent probe results for a given tag."""
    files = sorted(output_dir.glob(f"probe_{tag}_*.json"), key=lambda p: p.stat().st_mtime)
    if not files:
        return None
    return json.loads(files[-1].read_text())


def compare_probes(pre: Dict, post: Dict) -> List[Dict]:
    """Return a list of per-question diffs between pre and post probe results."""
    diffs = []
    pre_map = {r["question"]: r for r in pre.get("results", [])}
    for post_r in post.get("results", []):
        q = post_r["question"]
        pre_r = pre_map.get(q, {})
        diffs.append({
            "question": q,
            "pre_score": pre_r.get("score", "—"),
            "post_score": post_r["score"],
            "delta": post_r["score"] - pre_r.get("score", 0) if isinstance(pre_r.get("score"), int) else "—",
            "pre_answer": pre_r.get("model_answer", "—"),
            "post_answer": post_r["model_answer"],
        })
    return diffs
