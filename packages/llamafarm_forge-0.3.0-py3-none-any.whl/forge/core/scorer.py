import json
import importlib.util
from pathlib import Path


def _coerce_equal(a, b) -> bool:
    """Compare two values with numeric type coercion.

    Handles cases where the model outputs "42" (string) vs 42 (int/float)
    or vice versa. Both directions are tried so scorer robustly handles
    model outputs that stringify numbers.
    """
    if a == b:
        return True
    # Try coercing both to string for loose numeric comparison
    try:
        return str(a).strip() == str(b).strip()
    except Exception:
        return False


def exact_scorer(expected: dict, actual: str) -> dict:
    """Built-in exact JSON matcher.

    Parses actual as JSON and compares field-by-field with type coercion
    for numeric values (e.g. {"answer": 42} matches {"answer": "42"}).
    Extra keys in actual are IGNORED — only expected keys are checked.
    """
    try:
        actual_json = json.loads(actual.strip())
    except json.JSONDecodeError:
        return {"correct": False, "error": "invalid_json"}

    for k, v in expected.items():
        actual_val = actual_json.get(k)
        if not _coerce_equal(actual_val, v):
            return {"correct": False, "error": f"mismatch_{k}"}

    return {"correct": True, "error": None}


def json_cmd_scorer(expected: dict, actual: str) -> dict:
    """Built-in JSON cmd scorer.

    Checks that:
    - The "cmd" field matches exactly.
    - All other expected fields match (with numeric type coercion).
    - Extra keys in actual are ignored.
    - Handles whitespace around the JSON string.
    - Handles int vs string coercion (e.g. {"answer": 42} == {"answer": "42"}).
    """
    try:
        actual_json = json.loads(actual.strip())
    except json.JSONDecodeError:
        return {"correct": False, "error": "invalid_json"}

    if actual_json.get("cmd") != expected.get("cmd"):
        return {"correct": False, "error": "wrong_cmd"}

    # Check all expected fields are present and match (with coercion)
    for k, v in expected.items():
        actual_val = actual_json.get(k)
        if not _coerce_equal(actual_val, v):
            return {"correct": False, "error": f"mismatch_{k}"}

    return {"correct": True, "error": None}


def load_scorer(project_dir: Path, scorer_name: str):
    """Load a scorer function based on name or project plugin."""
    if scorer_name == "exact":
        return exact_scorer
    elif scorer_name == "json_cmd":
        return json_cmd_scorer

    # Attempt to load custom scorer.py
    scorer_path = project_dir / "scorer.py"
    if scorer_path.exists():
        spec = importlib.util.spec_from_file_location("project_scorer", str(scorer_path))
        if spec and spec.loader:
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)
            if hasattr(module, "score"):
                return getattr(module, "score")

    raise ValueError(f"Unknown scorer: {scorer_name} and no valid score() function found in scorer.py")
