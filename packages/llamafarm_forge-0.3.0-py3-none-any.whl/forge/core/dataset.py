"""forge.core.dataset — dataset management, versioning, and hygiene.

Key lessons from llamadrone-mission-router development:
- Never let the flywheel augment from wrong/stale failures files
- Always use the most recent eval's failures, not the most recent FILE by mtime
- Archive old datasets so the orchestrator only sees canonical + gold + current augmented
- Audited variants (_audited.jsonl) should be transient, not permanent
"""
from __future__ import annotations
import json
import shutil
from pathlib import Path
from datetime import datetime
from typing import Optional


def get_canonical(project_dir: Path) -> Path:
    """Return the current canonical training dataset path from forge.yaml."""
    from forge.core.config import load
    cfg = load(project_dir)
    return Path(cfg["dataset"]["canonical"])


def get_gold(project_dir: Path) -> Path:
    """Return the locked eval gold set path."""
    from forge.core.config import load
    cfg = load(project_dir)
    return Path(cfg["dataset"]["gold"])


def get_latest_failures(project_dir: Path, min_accuracy: float = 0.0) -> Optional[Path]:
    """
    Return the failures file from the BEST eval run, not just the most recent file.

    Critical bug in original pipeline: augment_from_failures() used
    sorted(glob("failures_*.json"), reverse=True)[0] — most recent by filename/mtime.
    If a regression run happened to be more recent, it would augment from WRONG failures.

    This function returns failures from the highest-accuracy eval run.
    """
    output_dir = project_dir / "output"
    best_acc = min_accuracy
    best_file = None

    for f in output_dir.glob("failures_*.json"):
        try:
            data = json.loads(f.read_text())
            acc = data.get("accuracy", 0.0)
            if acc > best_acc:
                best_acc = acc
                best_file = f
        except Exception:
            continue

    return best_file


def _resolve_dataset_dir(project_dir: Path, cfg: dict) -> Path:
    """Return dataset dir, preferring the parent of the configured canonical path."""
    canonical = cfg.get("dataset", {}).get("canonical", "")
    if canonical:
        p = Path(canonical)
        if not p.is_absolute():
            p = project_dir / p
        if p.parent.is_dir():
            return p.parent
    for candidate in ["src/dataset", "dataset"]:
        d = project_dir / candidate
        if d.is_dir():
            return d
    return project_dir / "dataset"


def archive_stale_datasets(project_dir: Path, keep: list[str] = None):
    """
    Move stale/generated dataset variants to <dataset_dir>/archive/.

    Keeps only:
    - canonical.jsonl (or canonical_vN.jsonl — the active one)
    - gold.jsonl
    - Any files in the explicit keep list

    Everything else (_audited, _reviewed, _clean, augmented_*, old versions) goes to archive/.

    Handles both dataset/ and src/dataset/ layouts.
    """
    from forge.core.config import load
    cfg = load(project_dir)
    ds_dir = _resolve_dataset_dir(project_dir, cfg)
    archive_dir = ds_dir / "archive"
    archive_dir.mkdir(exist_ok=True)

    if keep is None:
        canonical = Path(cfg["dataset"]["canonical"]).name
        gold = Path(cfg["dataset"]["gold"]).name
        keep = [canonical, gold]

    moved = []
    for f in ds_dir.glob("*.jsonl"):
        if f.name not in keep:
            dest = archive_dir / f.name
            if dest.exists():
                dest = archive_dir / f"{f.stem}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.jsonl"
            shutil.move(str(f), str(dest))
            moved.append(f.name)

    return moved


def version_dataset(src: Path, tag: str = None) -> Path:
    """
    Copy a dataset to a versioned archive copy before modifying it.
    Returns the archive path.
    """
    if tag is None:
        tag = datetime.now().strftime("%Y%m%d_%H%M")
    archive_dir = src.parent / "archive"
    archive_dir.mkdir(exist_ok=True)
    dest = archive_dir / f"{src.stem}_{tag}{src.suffix}"
    shutil.copy2(str(src), str(dest))
    return dest


def merge_datasets(*paths: Path, output: Path) -> int:
    """Merge multiple JSONL files into one, deduplicating by content hash."""
    seen = set()
    count = 0
    with open(output, "w") as out:
        for p in paths:
            if not p.exists():
                continue
            for line in p.read_text().splitlines():
                line = line.strip()
                if not line:
                    continue
                h = hash(line)
                if h not in seen:
                    seen.add(h)
                    out.write(line + "\n")
                    count += 1
    return count
