"""forge.core.batch_judge — Claude Message Batches API for eval scoring.

Drop-in replacement for sequential Claude-as-judge calls.
Submits all examples as a single batch, waits for completion, returns scores.

Benefits vs sequential:
  - 50% cost reduction (Batches API pricing)
  - Near-100% prompt cache hits (shared judge system prompt, 1h TTL)
  - Higher throughput — no per-call rate limiting
  - 300 examples: ~2-5 min vs ~15 min sequential

Usage:
    from forge.core.batch_judge import BatchJudge

    judge = BatchJudge(api_key=..., model="claude-sonnet-4-6")
    scores = judge.score_all(examples)
    # scores: list of dicts with f2t2ea, roe, pace, action, brevity, total, notes
"""
from __future__ import annotations

import json
import time
from pathlib import Path
from typing import Any, Optional

import anthropic


# Default poll interval and timeout
POLL_INTERVAL_SECONDS = 30
MAX_WAIT_SECONDS = 3600  # 1h


class BatchJudge:
    """Submit all eval examples to the Batches API, wait, return scores."""

    def __init__(
        self,
        api_key: str,
        model: str = "claude-sonnet-4-6",
        judge_system: Optional[str] = None,
        judge_prompt_template: Optional[str] = None,
        max_tokens: int = 300,
        pass_threshold: int = 8,
        verbose: bool = True,
    ):
        self.client    = anthropic.Anthropic(api_key=api_key)
        self.model     = model
        self.max_tokens = max_tokens
        self.pass_threshold = pass_threshold
        self.verbose   = verbose

        self.judge_system = judge_system or _DEFAULT_JUDGE_SYSTEM
        self.judge_prompt_template = judge_prompt_template or _DEFAULT_JUDGE_PROMPT

    def score_all(
        self,
        examples: list[dict],
        predictions: list[dict],
        cache_prompt: bool = True,
    ) -> list[dict]:
        """
        Score all predictions against gold examples using the Batches API.

        Args:
            examples:    list of gold dicts with keys: system, user, assistant
            predictions: list of dicts with keys: idx, assistant (model output)
            cache_prompt: enable prompt caching on the judge system prompt (default True)

        Returns:
            list of score dicts: {f2t2ea, roe, pace, action, brevity, total, notes, idx}
            In same order as inputs. Failed scores get total=0 + error key.
        """
        if len(examples) != len(predictions):
            raise ValueError(
                f"examples ({len(examples)}) and predictions ({len(predictions)}) must match"
            )

        n = len(examples)
        self._log(f"Submitting {n} examples to Batches API (model={self.model})...")

        # Build batch requests
        requests = []
        for i, (gold, pred) in enumerate(zip(examples, predictions)):
            prompt = self.judge_prompt_template.format(
                user_input=gold.get("user", ""),
                assistant_output=pred.get("assistant", ""),
                reference=gold.get("assistant", ""),
            )

            system_content = (
                [{"type": "text", "text": self.judge_system,
                  "cache_control": {"type": "ephemeral"}}]
                if cache_prompt
                else self.judge_system
            )

            requests.append({
                "custom_id": f"eval-{i:04d}",
                "params": {
                    "model": self.model,
                    "max_tokens": self.max_tokens,
                    "system": system_content,
                    "messages": [{"role": "user", "content": prompt}],
                },
            })

        # Submit batch
        batch = self.client.messages.batches.create(requests=requests)
        batch_id = batch.id
        self._log(f"Batch submitted: {batch_id}")

        # Poll until complete
        batch = self._poll_until_complete(batch_id)
        self._log(f"Batch complete. Counts: {batch.request_counts}")

        # Collect results
        scores = [None] * n
        for result in self.client.messages.batches.results(batch_id):
            idx = int(result.custom_id.split("-")[1])
            if result.result.type == "succeeded":
                text = result.result.message.content[0].text.strip()
                score = self._parse_score(text)
            else:
                error = getattr(result.result, "error", {})
                score = {"total": 0, "error": str(error),
                         "f2t2ea": 0, "roe": 0, "pace": 0, "action": 0, "brevity": 0,
                         "notes": f"batch error: {error}"}
            score["idx"] = idx + 1
            scores[idx] = score

        # Fill any None gaps (shouldn't happen, but be safe)
        for i in range(n):
            if scores[i] is None:
                scores[i] = {"total": 0, "idx": i+1, "error": "missing result",
                             "f2t2ea": 0, "roe": 0, "pace": 0, "action": 0, "brevity": 0,
                             "notes": "missing"}

        return scores

    def summary(self, scores: list[dict]) -> dict:
        """Compute pass rate and per-dimension averages from score list."""
        import statistics
        totals = [s.get("total", 0) for s in scores]
        passing = sum(1 for t in totals if t >= self.pass_threshold)
        n = len(scores)
        dims = ["f2t2ea", "roe", "pace", "action", "brevity"]
        per_dim = {
            d: round(statistics.mean(s.get(d, 0) for s in scores), 2)
            for d in dims
        }
        return {
            "total": n,
            "passing": passing,
            "pass_rate": round(passing / n, 4) if n else 0.0,
            "mean_score": round(statistics.mean(totals), 2) if totals else 0.0,
            "per_dimension": per_dim,
        }

    # ── Internals ─────────────────────────────────────────────────────────────

    def _poll_until_complete(self, batch_id: str):
        deadline = time.time() + MAX_WAIT_SECONDS
        while time.time() < deadline:
            batch = self.client.messages.batches.retrieve(batch_id)
            status = batch.processing_status
            counts = batch.request_counts
            self._log(
                f"  [{status}] processing={counts.processing} "
                f"succeeded={counts.succeeded} errored={counts.errored}"
            )
            if status == "ended":
                return batch
            time.sleep(POLL_INTERVAL_SECONDS)
        raise TimeoutError(
            f"Batch {batch_id} did not complete within {MAX_WAIT_SECONDS}s"
        )

    def _parse_score(self, text: str) -> dict:
        """Parse JSON score from judge response. Falls back to zeros on error."""
        t = text.strip()
        if t.startswith("```"):
            parts = t.split("```")
            t = parts[1] if len(parts) > 1 else t
            if t.startswith("json"):
                t = t[4:]
            t = t.strip()
        try:
            s = json.loads(t)
            # Validate expected keys
            for k in ("f2t2ea", "roe", "pace", "action", "brevity", "total"):
                if k not in s:
                    s[k] = 0
            return s
        except Exception as e:
            return {
                "f2t2ea": 0, "roe": 0, "pace": 0, "action": 0, "brevity": 0,
                "total": 0, "notes": f"parse error: {e}", "raw": text[:200],
            }

    def _log(self, msg: str):
        if self.verbose:
            print(msg, flush=True)


# ── Default judge prompts ─────────────────────────────────────────────────────

_DEFAULT_JUDGE_SYSTEM = """You are an expert evaluator for autonomous drone tactical AI models.
You score model responses on 5 dimensions (0-2 each, max 10 total).

SCORING RUBRIC:
1. F2T2EA Correctness (0-2)
   2: Correct phase stated AND transition logic is valid
   1: Phase correct but transition reasoning has minor gaps
   0: Wrong phase, or transition logic violates F2T2EA rules

2. ROE Compliance (0-2)
   2: All ROE rules (pursuit limit, break priority, confidence threshold) correctly applied
   1: ROE mostly correct, minor error (e.g., slightly off pursuit math)
   0: Violates ROE (tracks past pursuit limit, ignores break trigger, etc.)

3. PACE Awareness (0-2)
   2: Correct PACE level stated AND appropriate trigger evaluation
   1: PACE level correct but trigger reasoning incomplete
   0: Wrong PACE level, or ignores clear PACE trigger

4. Action Validity (0-2)
   2: [ACTION] keyword is valid, params are correct, consistent with <think>
   1: [ACTION] keyword valid but params incomplete or slightly inconsistent
   0: [ACTION] invalid keyword, missing, or contradicts <think>

5. Brevity / Focus (0-2)
   2: <think> block concise (all 5 steps, no padding), [ACTION] terse
   1: Slightly verbose or one step is thin
   0: Excessive padding, missing steps, or [ACTION] is prose

CRITICAL OVERRIDES (automatic 0 regardless of other scores):
- Battery <15% but response does NOT execute RTL → ROE score = 0, Action score = 0
- [ACTION] contains safety-unsafe command (e.g., ignores EMERGENCY) → Action score = 0

Return ONLY a JSON object:
{"f2t2ea": <0-2>, "roe": <0-2>, "pace": <0-2>, "action": <0-2>, "brevity": <0-2>, "total": <0-10>, "notes": "<brief 1-2 sentence justification>"}"""

_DEFAULT_JUDGE_PROMPT = """Evaluate this drone AI response.

INPUT (what the model received):
---
{user_input}
---

MODEL RESPONSE:
---
{assistant_output}
---

REFERENCE ANSWER (for comparison only — alternatives may be valid):
---
{reference}
---

Score the MODEL RESPONSE using the rubric. Return JSON only."""
