"""forge/core/corpus.py — load and chunk raw-text corpora for pretraining."""
from __future__ import annotations

import json
from pathlib import Path
from typing import List

try:
    from datasets import Dataset  # type: ignore  # GPU/train dep
except ImportError:
    Dataset = None  # type: ignore

SUPPORTED_EXTENSIONS = {".txt", ".md", ".jsonl"}


def load_corpus(corpus_dir: Path) -> List[str]:
    """
    Recursively load all .txt, .md, and .jsonl files from corpus_dir.

    .txt / .md  → entire file content is one document
    .jsonl      → each line must have a "text" field

    Returns a list of raw text strings (documents).
    """
    corpus_dir = Path(corpus_dir)
    if not corpus_dir.exists():
        raise FileNotFoundError(f"Corpus directory not found: {corpus_dir}")

    docs: List[str] = []
    files = sorted(corpus_dir.rglob("*"))
    for path in files:
        if not path.is_file() or path.suffix.lower() not in SUPPORTED_EXTENSIONS:
            continue
        if path.suffix.lower() == ".jsonl":
            with open(path, encoding="utf-8") as f:
                for i, line in enumerate(f, 1):
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        obj = json.loads(line)
                    except json.JSONDecodeError as e:
                        raise ValueError(f"{path}:{i} — invalid JSON: {e}")
                    if "text" not in obj:
                        raise ValueError(f"{path}:{i} — missing 'text' field")
                    text = obj["text"].strip()
                    if text:
                        docs.append(text)
        else:
            text = path.read_text(encoding="utf-8").strip()
            if text:
                docs.append(text)

    return docs


def chunk_documents(
    docs: List[str],
    tokenizer,
    max_seq_len: int = 2048,
    overlap: float = 0.1,
) -> List[str]:
    """
    Chunk a list of documents into token windows of at most max_seq_len tokens.

    overlap: fraction of max_seq_len to overlap between consecutive chunks (default 10%).
    Returns a list of text strings (one per chunk).
    """
    stride = max(1, int(max_seq_len * (1 - overlap)))
    chunks: List[str] = []

    for doc in docs:
        token_ids = tokenizer.encode(doc, add_special_tokens=False)
        if len(token_ids) <= max_seq_len:
            chunks.append(doc)
        else:
            for start in range(0, len(token_ids), stride):
                window = token_ids[start : start + max_seq_len]
                if len(window) < 32:          # skip tiny trailing chunks
                    break
                chunks.append(tokenizer.decode(window, skip_special_tokens=True))

    return chunks


def build_corpus_dataset(corpus_dir: Path, tokenizer, max_seq_len: int = 2048):
    """
    Load corpus, chunk, and return a HuggingFace Dataset with a single 'text' column.
    Deduplicates chunks by exact string match.
    """
    _Dataset = Dataset
    if _Dataset is None:
        try:
            from datasets import Dataset as _Dataset  # type: ignore
        except ImportError:
            raise ImportError("datasets package required: pip install slm-forge[train]")

    docs = load_corpus(corpus_dir)
    if not docs:
        raise ValueError(f"No usable documents found in {corpus_dir}")

    chunks = chunk_documents(docs, tokenizer, max_seq_len=max_seq_len)

    # deduplicate
    seen: set = set()
    unique: List[str] = []
    for c in chunks:
        key = c.strip()
        if key not in seen:
            seen.add(key)
            unique.append(c)

    print(f"Corpus: {len(docs)} docs → {len(chunks)} chunks → {len(unique)} unique")
    return _Dataset.from_dict({"text": unique})
