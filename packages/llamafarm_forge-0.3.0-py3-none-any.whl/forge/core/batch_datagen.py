"""forge.core.batch_datagen — Batch API dataset generation.

Generates training examples using the Batches API instead of sequential/parallel calls.

Design:
  1. Submit N generation requests as a single batch (one API call)
  2. Wait for batch to complete (~1h for large batches, <5min for 500)
  3. Validate all results against schema
  4. Collect failures → retry in a second batch (up to max_retries passes)
  5. Write canonical JSONL

Why batch vs parallel workers:
  - 50% cheaper (batch pricing)
  - Prompt cache hits on shared system/context (1h TTL)
  - No rate-limit juggling — Anthropic handles scheduling
  - Clean retry loop: validate first, then batch-retry only failures
  - Seed examples as few-shot context in every request (consistent style)

Usage:
    from forge.core.batch_datagen import BatchDatagen, GenerationSpec

    spec = GenerationSpec(
        category="scan_routine",
        description="Routine scan, nothing found...",
        n=500,
        seed_examples=[...],        # 3-5 hand-crafted gold examples
        system_context="...",       # full system prompt / domain context
        generation_system="...",    # instructions to the generator LLM
    )

    gen = BatchDatagen(api_key=..., model="claude-sonnet-4-6")
    examples = gen.generate(spec, validator=my_validate_fn)
    # examples: list of validated dicts, len ~= spec.n
"""
from __future__ import annotations

import json
import time
import uuid
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Optional

import anthropic

POLL_INTERVAL = 30
MAX_WAIT = 7200   # 2h absolute ceiling


@dataclass
class GenerationSpec:
    """Everything needed to generate a batch of training examples."""
    category: str
    description: str                    # category description / what to vary
    n: int                              # number of examples to generate
    generation_system: str              # system prompt for the GENERATOR LLM
    system_context: str = ""            # domain context injected into every user prompt
                                        # (e.g., full taccommander system prompt verbatim)
    seed_examples: list[dict] = field(default_factory=list)
                                        # 3-5 hand-crafted gold examples shown as few-shot
    seed_display_keys: list[str] = field(default_factory=lambda: ["user", "assistant"])
                                        # which keys to show from seed examples
    extra_instructions: str = ""        # any additional per-batch instructions
    max_retries: int = 2                # validation retry passes
    seed_state_fn: Optional[Callable] = None
                                        # optional fn() → dict of random state vars


@dataclass
class BatchDatagenResult:
    generated: list[dict]               # validated examples
    failed: list[dict]                  # examples that never passed validation
    n_requested: int
    n_generated: int
    n_failed: int
    passes: int                         # how many retry passes were needed
    batch_ids: list[str]                # Batches API IDs for audit trail


class BatchDatagen:
    """Generate training examples via the Batches API with automatic retry."""

    def __init__(
        self,
        api_key: str,
        model: str = "claude-sonnet-4-6",
        max_tokens: int = 4000,
        verbose: bool = True,
    ):
        self.client    = anthropic.Anthropic(api_key=api_key)
        self.model     = model
        self.max_tokens = max_tokens
        self.verbose   = verbose

    def generate(
        self,
        spec: GenerationSpec,
        validator: Optional[Callable[[dict], list[str]]] = None,
        output_path: Optional[Path] = None,
    ) -> BatchDatagenResult:
        """
        Generate spec.n examples, retrying failures up to spec.max_retries times.

        Args:
            spec:        GenerationSpec describing what to generate
            validator:   fn(example_dict) -> list[str] of errors. [] = valid.
                         If None, all non-parse-error results are accepted.
            output_path: if set, append valid examples to this JSONL file in real-time

        Returns:
            BatchDatagenResult with generated examples and stats
        """
        validated: list[dict] = []
        all_failed: list[dict] = []
        batch_ids: list[str] = []
        passes = 0

        # How many we still need
        remaining = spec.n

        for attempt in range(spec.max_retries + 1):
            if remaining <= 0:
                break

            passes += 1
            self._log(f"\n[pass {attempt+1}] Requesting {remaining} examples "
                      f"(category={spec.category})")

            # Build and submit batch
            requests = self._build_requests(spec, remaining, attempt)
            batch_id = self._submit_batch(requests)
            batch_ids.append(batch_id)
            self._log(f"  Batch submitted: {batch_id}")

            # Wait for completion
            batch = self._poll(batch_id)
            self._log(f"  Complete. succeeded={batch.request_counts.succeeded} "
                      f"errored={batch.request_counts.errored}")

            # Collect + validate results
            pass_valid = []
            pass_failed = []
            for result in self.client.messages.batches.results(batch_id):
                if result.result.type != "succeeded":
                    pass_failed.append({
                        "_error": f"batch api error: {result.result}",
                        "_custom_id": result.custom_id,
                    })
                    continue

                raw = result.result.message.content[0].text
                example, errors = self._parse(raw)

                if example and validator:
                    errors = validator(example)

                if not errors and example:
                    pass_valid.append(example)
                else:
                    pass_failed.append({
                        "_errors": errors,
                        "_raw": raw[:500],
                        "_custom_id": result.custom_id,
                    })

            # Write valid examples to output
            if output_path:
                with open(output_path, "a") as f:
                    for ex in pass_valid:
                        f.write(json.dumps(ex) + "\n")

            validated.extend(pass_valid)
            all_failed = pass_failed   # only last pass failures matter
            remaining = spec.n - len(validated)

            self._log(f"  Pass {attempt+1}: {len(pass_valid)} valid, "
                      f"{len(pass_failed)} failed. Total: {len(validated)}/{spec.n}")

            if remaining <= 0:
                break

            if attempt < spec.max_retries and pass_failed:
                self._log(f"  Retrying {min(remaining, len(pass_failed))} failures...")

        return BatchDatagenResult(
            generated=validated,
            failed=all_failed,
            n_requested=spec.n,
            n_generated=len(validated),
            n_failed=len(all_failed),
            passes=passes,
            batch_ids=batch_ids,
        )

    def generate_multi(
        self,
        specs: list[GenerationSpec],
        validator: Optional[Callable[[dict], list[str]]] = None,
        output_path: Optional[Path] = None,
    ) -> dict[str, BatchDatagenResult]:
        """
        Generate examples for multiple categories, submitting all as ONE batch.

        This is the most efficient path — all categories in a single API call,
        Anthropic schedules them together, prompt cache shared across all.

        Returns dict mapping category → BatchDatagenResult.
        """
        all_results: dict[str, BatchDatagenResult] = {}

        # First pass: submit everything as one combined batch
        all_requests = []
        spec_by_prefix: dict[str, GenerationSpec] = {}

        for spec in specs:
            prefix = f"{spec.category}-p0"
            spec_by_prefix[prefix] = spec
            requests = self._build_requests(spec, spec.n, 0, id_prefix=prefix)
            all_requests.extend(requests)

        self._log(f"\n[multi-batch] Submitting {len(all_requests)} requests "
                  f"across {len(specs)} categories...")
        batch_id = self._submit_batch(all_requests)
        self._log(f"  Batch: {batch_id}")

        batch = self._poll(batch_id)
        self._log(f"  Complete. succeeded={batch.request_counts.succeeded}")

        # Collect results, route by category prefix
        by_category: dict[str, list] = {s.category: [] for s in specs}
        by_category_failed: dict[str, list] = {s.category: [] for s in specs}

        for result in self.client.messages.batches.results(batch_id):
            # custom_id format: "<category>-p0-<idx>"
            cat = result.custom_id.rsplit("-p0-", 1)[0]
            if cat not in by_category:
                continue

            if result.result.type != "succeeded":
                by_category_failed[cat].append({"_error": str(result.result)})
                continue

            raw = result.result.message.content[0].text
            example, errors = self._parse(raw)
            spec = next(s for s in specs if s.category == cat)

            if example and validator:
                errors = validator(example)

            if not errors and example:
                by_category[cat].append(example)
                if output_path:
                    with open(output_path, "a") as f:
                        f.write(json.dumps(example) + "\n")
            else:
                by_category_failed[cat].append({"_errors": errors, "_raw": raw[:300]})

        # Retry pass for each category that's short
        for spec in specs:
            cat = spec.category
            validated = by_category[cat]
            failed    = by_category_failed[cat]
            remaining = spec.n - len(validated)
            passes    = 1
            retry_batch_ids = [batch_id]

            if remaining > 0 and spec.max_retries > 0:
                self._log(f"  [{cat}] {len(validated)}/{spec.n} — retrying {remaining}...")
                retry_spec = GenerationSpec(
                    **{**spec.__dict__, "n": remaining, "max_retries": spec.max_retries - 1}
                )
                retry_result = self.generate(retry_spec, validator, output_path)
                validated.extend(retry_result.generated)
                failed = retry_result.failed
                passes += retry_result.passes
                retry_batch_ids.extend(retry_result.batch_ids)

            all_results[cat] = BatchDatagenResult(
                generated=validated,
                failed=failed,
                n_requested=spec.n,
                n_generated=len(validated),
                n_failed=len(failed),
                passes=passes,
                batch_ids=retry_batch_ids,
            )
            self._log(f"  [{cat}] final: {len(validated)}/{spec.n} valid")

        return all_results

    # ── Prompt building ────────────────────────────────────────────────────────

    def _build_requests(
        self,
        spec: GenerationSpec,
        n: int,
        attempt: int,
        id_prefix: Optional[str] = None,
    ) -> list[dict]:
        prefix = id_prefix or f"{spec.category}-p{attempt}"
        requests = []
        for i in range(n):
            custom_id = f"{prefix}-{i:04d}"
            prompt = self._build_prompt(spec, attempt, i)
            requests.append({
                "custom_id": custom_id,
                "params": {
                    "model": self.model,
                    "max_tokens": self.max_tokens,
                    "system": [
                        {
                            "type": "text",
                            "text": spec.generation_system,
                            "cache_control": {"type": "ephemeral"},  # 1h cache
                        }
                    ],
                    "messages": [{"role": "user", "content": prompt}],
                },
            })
        return requests

    def _build_prompt(self, spec: GenerationSpec, attempt: int, idx: int) -> str:
        parts = []

        parts.append(f"Generate one SFT training example for category: **{spec.category}**")
        parts.append(f"\nCATEGORY DESCRIPTION:\n{spec.description}")

        if spec.system_context:
            parts.append(
                f"\nUse this system prompt VERBATIM in the \"system\" field:\n"
                f"---\n{spec.system_context}\n---"
            )

        if spec.seed_examples:
            parts.append(f"\nFEW-SHOT EXAMPLES (vary from these, do NOT copy them):")
            shown = spec.seed_examples[:5]  # cap at 5 to stay within context
            for j, ex in enumerate(shown):
                ex_str = "\n".join(
                    f'  "{k}": {json.dumps(ex[k])[:400]}...' if len(json.dumps(ex.get(k,""))) > 400
                    else f'  "{k}": {json.dumps(ex[k])}'
                    for k in spec.seed_display_keys if k in ex
                )
                parts.append(f"\nExample {j+1}:\n{{\n{ex_str}\n}}")

        if spec.seed_state_fn:
            state = spec.seed_state_fn()
            state_str = " ".join(f"{k}={v}" for k, v in state.items())
            parts.append(f"\nSeed state (vary realistically): {state_str}")

        if spec.extra_instructions:
            parts.append(f"\nADDITIONAL INSTRUCTIONS:\n{spec.extra_instructions}")

        if attempt > 0:
            parts.append(
                f"\n[Retry pass {attempt+1}] Previous attempt failed validation. "
                f"Ensure strict format compliance: <think> with 5 numbered steps, "
                f"[ACTION] as key=val only (no JSON braces), valid keyword."
            )

        # Vary by index to get diverse examples
        parts.append(
            f"\nVariation hint: example #{idx+1} of {spec.n} — "
            f"vary the scenario, state values, and edge cases from other examples."
        )

        parts.append(
            f"\nReturn ONLY a JSON object: "
            f'{{\"system\": \"...\", \"user\": \"...\", \"assistant\": \"...\"}}\n'
            f"No markdown. No explanation. JSON only."
        )

        return "\n".join(parts)

    # ── Batch API plumbing ────────────────────────────────────────────────────

    def _submit_batch(self, requests: list[dict]) -> str:
        batch = self.client.messages.batches.create(requests=requests)
        return batch.id

    def _poll(self, batch_id: str):
        deadline = time.time() + MAX_WAIT
        while time.time() < deadline:
            batch = self.client.messages.batches.retrieve(batch_id)
            if batch.processing_status == "ended":
                return batch
            counts = batch.request_counts
            self._log(
                f"  [{batch.processing_status}] "
                f"processing={counts.processing} "
                f"succeeded={counts.succeeded} "
                f"errored={counts.errored}",
                end="\r",
            )
            time.sleep(POLL_INTERVAL)
        raise TimeoutError(f"Batch {batch_id} did not complete in {MAX_WAIT}s")

    def _parse(self, raw: str) -> tuple[Optional[dict], list[str]]:
        text = raw.strip()
        if text.startswith("```"):
            parts = text.split("```")
            text = parts[1] if len(parts) > 1 else text
            if text.startswith("json"):
                text = text[4:]
            text = text.strip()
        last = text.rfind("}")
        if last != -1:
            text = text[:last+1]
        try:
            ex = json.loads(text)
            return ex, []
        except json.JSONDecodeError as e:
            return None, [f"JSON parse error: {e}"]

    def _log(self, msg: str, end: str = "\n"):
        if self.verbose:
            print(msg, end=end, flush=True)
