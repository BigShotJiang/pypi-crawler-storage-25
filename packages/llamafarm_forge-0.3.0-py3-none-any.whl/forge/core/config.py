"""forge.yaml loader and validator.

Supports two config sources (in priority order):
1. forge.yaml in project root (canonical forge format)
2. configs/task.yaml in project root (llamadrone-style, auto-translated)

forge is a CLI tool installed once, run inside any project directory.
It discovers the project root by walking up from cwd looking for forge.yaml
(or configs/task.yaml as fallback), then reads all config from there.
"""
from __future__ import annotations
import os
from pathlib import Path
from typing import Optional
import yaml


DEFAULTS = {
    "model": {
        "base": "unsloth/functiongemma-270m-it",
        "max_seq_len": 2048,
        "load_in_4bit": True,
    },
    "lora": {
        "r": 32,
        "alpha": 32,
        "dropout": 0.05,
        "target_modules": ["q_proj", "k_proj", "v_proj", "o_proj",
                           "gate_proj", "up_proj", "down_proj"],
    },
    "training": {
        "epochs_min": 2,
        "epochs_max": 4,
        "batch_size": 4,
        "gradient_accumulation_steps": 1,
        "learning_rate": 5.0e-5,
        "warmup_ratio": 0.1,
        "weight_decay": 0.01,
        "lr_scheduler": "cosine",
        "seed": 42,
    },
    "eval": {
        "target_accuracy": 0.95,
        "safety_violations_allowed": 0,
        "scorer": "json_cmd",   # exact | semantic | json_cmd | custom
        "max_new_tokens": 256,
        "forbidden_commands": [],
    },
    "promotion": {
        "hf_repo": None,
        "private": True,
    },
    "flywheel": {
        "max_iterations": 10,
        "augment_per_failure": 20,
        "datagen_model": "claude-sonnet-4-6",
        "planner_model": "claude-sonnet-4-6",
    },
    "compute": {
        "device": "cuda:0",
        "remote": None,     # e.g. ssh://robert@100.83.55.79
    },
    "cloud": {
        "provider": "gcp",
        "project": "",
        "zone": "us-central1-a",
        "gpu": "a100",
        "disk_gb": 100,
        "tailscale_auth_key": "",
        "gcs_bucket": "gs://llamafarm-forge",
        "vm_name_prefix": "forge-train",
        "timeout_minutes": 180,
        "tags": ["forge-managed"],
    },
}


def find_project_root(start: Path = None) -> Optional[Path]:
    """Walk up from start until forge.yaml or configs/task.yaml is found.

    Priority:
    1. forge.yaml in any ancestor directory
    2. configs/task.yaml in any ancestor directory (llamadrone-style fallback)
    """
    p = start or Path.cwd()
    for parent in [p, *p.parents]:
        if (parent / "forge.yaml").exists():
            return parent
    # Second pass: look for configs/task.yaml
    for parent in [p, *p.parents]:
        if (parent / "configs" / "task.yaml").exists():
            return parent
    return None


def load(project_dir: Path = None) -> dict:
    """Load and merge forge.yaml (or configs/task.yaml) with defaults.

    Loads .env from the project directory before reading env secrets,
    so HF_TOKEN / ANTHROPIC_API_KEY set there are picked up automatically.
    """
    if project_dir is None:
        project_dir = find_project_root()
    if project_dir is None:
        raise FileNotFoundError(
            "No forge.yaml found. Run `forge init <name>` to create a project."
        )

    # Load .env before reading env vars
    _load_dotenv(project_dir)

    forge_yaml = project_dir / "forge.yaml"
    task_yaml = project_dir / "configs" / "task.yaml"

    if forge_yaml.exists():
        with open(forge_yaml) as f:
            user_cfg = yaml.safe_load(f) or {}
    elif task_yaml.exists():
        user_cfg = _translate_task_yaml(task_yaml)
    else:
        raise FileNotFoundError(
            f"No forge.yaml found in {project_dir}. "
            "Run `forge init <name>` to create a project."
        )

    # Deep merge user config over defaults
    cfg = _deep_merge(DEFAULTS, user_cfg)
    cfg["_project_dir"] = str(project_dir)
    cfg["_config_source"] = str(forge_yaml if forge_yaml.exists() else task_yaml)

    # Resolve dataset paths relative to project dir
    for key in ["seed", "gold", "canonical"]:
        ds = cfg.get("dataset", {})
        if key in ds and ds[key] and not Path(ds[key]).is_absolute():
            ds[key] = str(project_dir / ds[key])

    # Inject env secrets (populated after _load_dotenv above)
    cfg["_hf_token"] = os.environ.get("HF_TOKEN", "")
    cfg["_anthropic_key"] = os.environ.get("ANTHROPIC_API_KEY", "")

    return cfg


def _load_dotenv(project_dir: Path) -> None:
    """Load KEY=VALUE pairs from project_dir/.env into os.environ (non-destructive).

    Only sets variables that are not already in the environment.
    Handles quoted values and ignores comments/blank lines.
    """
    env_file = project_dir / ".env"
    if not env_file.exists():
        return
    for line in env_file.read_text().splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, val = line.partition("=")
        key = key.strip()
        val = val.strip().strip('"').strip("'")
        if key and key not in os.environ:
            os.environ[key] = val


def _translate_task_yaml(path: Path) -> dict:
    """Translate a llamadrone-style configs/task.yaml to forge config format."""
    with open(path) as f:
        t = yaml.safe_load(f) or {}

    cfg: dict = {}

    # model / lora / training — keys are compatible
    for section in ("model", "lora", "training"):
        if section in t:
            cfg[section] = dict(t[section])

    # dataset: train→canonical, eval→gold
    ds = t.get("dataset", {})
    cfg["dataset"] = {
        "canonical": ds.get("train", ds.get("canonical", "")),
        "gold": ds.get("eval", ds.get("gold", "")),
    }
    if "seed" in ds:
        cfg["dataset"]["seed"] = ds["seed"]

    # eval: accuracy_target → target_accuracy
    ev = t.get("eval", {})
    cfg["eval"] = {
        "target_accuracy": ev.get("accuracy_target", ev.get("target_accuracy", 0.95)),
        "safety_violations_allowed": ev.get("safety_threshold", 0),
        "max_new_tokens": ev.get("max_new_tokens", 256),
        "forbidden_commands": ev.get("forbidden_commands", []),
    }

    # gpu.device → compute.device
    if "gpu" in t:
        dev = t["gpu"].get("device", 0)
        cfg["compute"] = {"device": f"cuda:{dev}"}

    # promotion
    if "promotion" in t:
        p = t["promotion"]
        cfg["promotion"] = {
            "hf_repo": p.get("hf_repo"),
            "private": p.get("private", True),
        }

    # flywheel
    if "flywheel" in t:
        cfg["flywheel"] = dict(t["flywheel"])

    # name (infer from dir if not present)
    if "name" in t:
        cfg["name"] = t["name"]

    return cfg


def _deep_merge(base: dict, override: dict) -> dict:
    result = dict(base)
    for k, v in override.items():
        if isinstance(v, dict) and isinstance(result.get(k), dict):
            result[k] = _deep_merge(result[k], v)
        else:
            result[k] = v
    return result
