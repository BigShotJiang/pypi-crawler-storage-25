"""forge.core.planner — autonomous agent planning and strategy system.

The planner maintains two living documents inside the project:

1. AGENT_CONTEXT.md — history of what happened (scores, failures, hypotheses tried)
   Updated automatically after every eval.

2. PLAN.md — the agent's strategy for reaching the target
   Updated by the agent after analyzing failures.
   Contains: current hypothesis, what to try next, what has worked/failed.

These files are fed into every Claude augmentation/datagen call so the agent
has full context for generating useful training data.

The agent prompt for augmentation looks like:

    [MISSION]
    {mission.md — full task description, tools, constraints, WHY}
    
    [SYSTEM PROMPT]
    {system_prompt.md — exact prompt used in training}
    
    [PLAN]
    {PLAN.md — current strategy, hypotheses, next steps}
    
    [AGENT CONTEXT]
    {AGENT_CONTEXT.md — score history, failure taxonomy, what's been tried}
    
    [CURRENT FAILURES]
    {failures from latest eval — exact inputs, expected, got, reason}
    
    Based on all the above, generate targeted training examples.
    - Prioritize persistent failures
    - Do NOT repeat approaches that already failed
    - Focus on the root cause, not symptoms
"""
from __future__ import annotations
import json
from datetime import datetime
from pathlib import Path
from typing import Optional

PLAN_FILE = "PLAN.md"
CONTEXT_FILE = "AGENT_CONTEXT.md"
MAX_CONTEXT_CHARS = 5000


def init_plan(project_dir: Path, name: str = ""):
    """Create initial PLAN.md for a new project."""
    p = project_dir / PLAN_FILE
    if p.exists():
        return
    p.write_text(f"""# Training Plan — {name}

*Auto-maintained by forge. Updated after every eval.*

## Current Strategy
No training runs completed yet. Will establish baseline on seed data.

## Hypotheses Queue
1. [ ] Train on seed data → establish baseline accuracy
2. [ ] Analyze failures → identify top error categories
3. [ ] Generate targeted examples for top 3 failure categories
4. [ ] Retrain and evaluate

## What Has Worked
(nothing yet)

## What Has Failed
(nothing yet)

## Configuration Notes
- Starting config in forge.yaml
- Will adjust LR, epochs, LoRA rank based on results

## Next Action
Run initial training: `forge train` then `forge eval`
""")


def update_plan(
    project_dir: Path,
    iteration: int,
    accuracy: float,
    failures: list[dict],
    prev_accuracy: Optional[float] = None,
    hypothesis: str = "",
    result: str = "",
):
    """Update PLAN.md with latest iteration results and next strategy."""
    p = project_dir / PLAN_FILE
    ts = datetime.now().strftime("%Y-%m-%d %H:%M")

    # Group failures
    from collections import Counter
    cats = Counter(f.get('gold_cmd', f.get('category', '?')) for f in failures)
    top_3 = cats.most_common(3)

    delta = ""
    if prev_accuracy is not None:
        diff = accuracy - prev_accuracy
        delta = f" ({'+'if diff>=0 else ''}{diff*100:.1f}pp)"

    entry = f"""
### Iteration {iteration} — {ts}
- Accuracy: {accuracy*100:.1f}%{delta}
- Failures: {len(failures)} total
- Top failure categories: {', '.join(f'{cmd}({n})' for cmd, n in top_3)}
"""
    if hypothesis:
        entry += f"- Hypothesis: {hypothesis}\n"
    if result:
        entry += f"- Result: {result}\n"

    if not p.exists():
        init_plan(project_dir)

    content = p.read_text()

    # Append to "What Has Worked" or "What Has Failed"
    if prev_accuracy is not None:
        if accuracy > prev_accuracy:
            section = "## What Has Worked"
            note = f"- Iter {iteration}: {hypothesis or 'unknown change'} → +{(accuracy-prev_accuracy)*100:.1f}pp\n"
        else:
            section = "## What Has Failed"
            note = f"- Iter {iteration}: {hypothesis or 'unknown change'} → {(accuracy-prev_accuracy)*100:.1f}pp\n"

        if section in content:
            content = content.replace(section, section + "\n" + note, 1)

    # Update current strategy based on top failures
    new_strategy = f"""## Current Strategy
*Updated: {ts} — Accuracy: {accuracy*100:.1f}%*

Top failures: {', '.join(f'{cmd}({n})' for cmd, n in top_3)}

Priority actions:
"""
    for i, (cmd, n) in enumerate(top_3, 1):
        new_strategy += f"{i}. Fix {cmd} ({n} failures) — generate targeted examples\n"

    content = content.split("## Current Strategy")[0] + new_strategy + "\n" + \
              "## Hypotheses Queue" + content.split("## Hypotheses Queue")[1] if "## Hypotheses Queue" in content else content

    # Append iteration entry
    if "## Iteration Log" not in content:
        content += "\n## Iteration Log\n"
    content += entry

    p.write_text(content)


def load_augment_context(project_dir: Path) -> str:
    """Build the full context string for Claude augmentation calls.

    Returns a structured prompt with:
    - Mission brief
    - System prompt
    - Training plan
    - Agent context (score history, failure taxonomy)

    Truncated to MAX_CONTEXT_CHARS from the bottom (most recent history).
    """
    parts = []

    # Mission
    mission = project_dir / "mission.md"
    if mission.exists():
        parts.append(f"[MISSION]\n{mission.read_text().strip()}")

    # System prompt
    sys_prompt = project_dir / "system_prompt.md"
    if sys_prompt.exists():
        parts.append(f"[SYSTEM PROMPT]\n{sys_prompt.read_text().strip()}")

    # Plan
    plan = project_dir / PLAN_FILE
    if plan.exists():
        parts.append(f"[PLAN]\n{plan.read_text().strip()}")

    # Agent context
    from forge.core.context import load as load_context
    ctx = load_context(project_dir)
    if ctx:
        parts.append(f"[AGENT CONTEXT]\n{ctx}")

    full = "\n\n---\n\n".join(parts)

    # Truncate if too long (keep end — most recent history)
    if len(full) > MAX_CONTEXT_CHARS * 4:
        full = "...[truncated]...\n" + full[-(MAX_CONTEXT_CHARS * 4):]

    return full
