"""forge.core.augmentor — Claude-powered synthetic data generator for the flywheel.

Two-file context system
-----------------------
BACKGROUND.md  — Static, human-authored domain knowledge: output format, edge cases,
                 what good examples look like, common failure patterns.
                 ALWAYS included in full — never truncated.

AGENT_CONTEXT.md — Auto-updated iteration log written by the flywheel each round.
                   Truncated to ~5000 chars (most recent content kept) if very long.
"""
from __future__ import annotations

import json
from collections import defaultdict
from pathlib import Path
from typing import Optional


DATAGEN_PROMPT = """You are generating training data for a fine-tuned language model.

TASK:
{mission}

SYSTEM PROMPT (injected at inference time):
{system_prompt}

DOMAIN KNOWLEDGE (background, output format, edge cases, good example patterns):
{background}

RECENT HISTORY:
{agent_context}

FAILURES TO ADDRESS:
{failure_summary}

AUGMENTATION FOCUS (from experiment planner):
{augment_focus}

Generate {n} training examples as a JSON array.
Each element: {{"user": "<input text>", "assistant": "<valid JSON output>"}}
Focus on the exact failure patterns and augmentation focus above. Vary phrasing and values.
Return ONLY the JSON array. No markdown, no prose."""


def run(
    project_dir: Path,
    cfg: dict,
    failures: list[dict],
    per_failure: Optional[int] = None,
    augment_focus: str = "",
) -> int:
    """Generate synthetic training data from eval failures using Claude.

    Args:
        project_dir: Root path of the forge project.
        cfg: Parsed forge.yaml config dict.
        failures: List of failure dicts from eval_runner.
        per_failure: Examples to generate per failure category (overrides cfg).
        augment_focus: Optional experiment-planner instruction that overrides
                       the generic failure summary as the primary focus.

    Returns:
        int: Number of valid examples appended to dataset/canonical.jsonl.
    """
    if not failures:
        return 0

    flywheel_cfg = cfg.get("flywheel", {})
    per_failure = per_failure or flywheel_cfg.get("augment_per_failure", 5)
    model_id = flywheel_cfg.get("datagen_model", "claude-sonnet-4-6")

    # Load context files
    mission = _read_file(project_dir / "mission.md", "(no mission.md found)")
    system_prompt = _read_file(project_dir / "system_prompt.md", "(no system_prompt.md found)")

    # BACKGROUND.md — static domain knowledge, always included in full
    background = _read_file(project_dir / "BACKGROUND.md", "(no BACKGROUND.md — add one for better datagen quality)")

    # AGENT_CONTEXT.md — auto-updated iteration log, truncated if long
    agent_context_raw = _read_file(project_dir / "AGENT_CONTEXT.md", "(no history yet)")
    max_context_chars = 5000 * 4  # ~5000 tokens
    if len(agent_context_raw) > max_context_chars:
        agent_context = "...[truncated]...\n" + agent_context_raw[-max_context_chars:]
    else:
        agent_context = agent_context_raw

    # Group failures by category
    by_category: dict[str, list[dict]] = defaultdict(list)
    for f in failures:
        cat = f.get("category", "general")
        by_category[cat].append(f)

    # Build failure summary
    failure_summary = _build_failure_summary(by_category)
    n_examples = max(per_failure * len(by_category), per_failure)

    prompt = DATAGEN_PROMPT.format(
        mission=mission,
        system_prompt=system_prompt,
        background=background,
        agent_context=agent_context,
        failure_summary=failure_summary,
        augment_focus=augment_focus if augment_focus else "(use failure summary above)",
        n=n_examples,
    )

    # Call Claude
    import anthropic
    client = anthropic.Anthropic()
    response = client.messages.create(
        model=model_id,
        max_tokens=4096,
        messages=[{"role": "user", "content": prompt}],
    )
    raw_text = response.content[0].text.strip()

    # Parse response
    examples = _parse_response(raw_text)

    # Validate and append to canonical.jsonl
    canonical_rel = cfg.get("dataset", {}).get("canonical", "dataset/canonical.jsonl")
    canonical_path = Path(canonical_rel)
    if not canonical_path.is_absolute():
        canonical_path = project_dir / canonical_path

    canonical_path.parent.mkdir(parents=True, exist_ok=True)

    # Ensure file ends with a newline before appending (handles files written without trailing \n)
    if canonical_path.exists() and canonical_path.stat().st_size > 0:
        with open(canonical_path, "rb") as f:
            f.seek(-1, 2)
            last_byte = f.read(1)
        if last_byte != b"\n":
            with open(canonical_path, "a") as f:
                f.write("\n")

    valid_count = 0
    with open(canonical_path, "a") as f:
        for ex in examples:
            user_text = ex.get("user", "")
            assistant_text = ex.get("assistant", "")

            # Validate
            if not isinstance(user_text, str) or not user_text.strip():
                continue
            try:
                json.loads(assistant_text)
            except (json.JSONDecodeError, TypeError):
                continue

            record = {
                "messages": [
                    {"role": "user", "content": user_text},
                    {"role": "assistant", "content": assistant_text},
                ]
            }
            f.write(json.dumps(record) + "\n")
            valid_count += 1

    return valid_count


def _read_file(path: Path, default: str = "") -> str:
    """Read a file, returning default if missing."""
    if path.exists():
        return path.read_text().strip()
    return default


def _build_failure_summary(by_category: dict[str, list[dict]]) -> str:
    """Build a concise failure summary string for the prompt."""
    lines = []
    for cat, failures in by_category.items():
        lines.append(f"\nCategory: {cat} ({len(failures)} failures)")
        for f in failures[:3]:  # Show up to 3 examples per category
            lines.append(f"  Input:    {f.get('input', '')[:120]}")
            lines.append(f"  Expected: {f.get('expected', '')[:120]}")
            lines.append(f"  Actual:   {f.get('actual', '')[:120]}")
            if f.get("error"):
                lines.append(f"  Error:    {f.get('error')}")
    return "\n".join(lines)


def _parse_response(raw_text: str) -> list[dict]:
    """Parse Claude's JSON array response, stripping any markdown fences."""
    text = raw_text.strip()

    # Strip markdown code fences if present
    if text.startswith("```"):
        lines = text.split("\n")
        # Remove first line (```json or ```) and last line (```)
        inner_lines = lines[1:]
        if inner_lines and inner_lines[-1].strip() == "```":
            inner_lines = inner_lines[:-1]
        text = "\n".join(inner_lines).strip()

    try:
        parsed = json.loads(text)
        if isinstance(parsed, list):
            return parsed
        return []
    except json.JSONDecodeError:
        return []
