"""forge.core.trainer — built-in training runner driven entirely by forge.yaml.

Used by `forge train` when the project has no src/train.py.
Supports Unsloth + QLoRA on CUDA, falls back to standard HF SFT on CPU.
"""
from __future__ import annotations

import json
import os
import sys
import time
from pathlib import Path
from datetime import datetime


def run(project_dir: Path, cfg: dict, epochs_override: int | None = None) -> dict:
    """Train a QLoRA adapter using forge.yaml config.

    Returns:
        dict with keys: adapter_dir, final_loss, epochs_run, elapsed_min, train_examples
    """
    start = time.time()

    # ── Resolve paths ─────────────────────────────────────────────────────────
    output_dir = project_dir / "output"
    output_dir.mkdir(exist_ok=True)
    adapter_dir = output_dir / "adapter"

    canonical_rel = cfg.get("dataset", {}).get("canonical", "dataset/canonical.jsonl")
    canonical_path = Path(canonical_rel)
    if not canonical_path.is_absolute():
        canonical_path = project_dir / canonical_path

    system_prompt_path = project_dir / "system_prompt.md"
    system_prompt = system_prompt_path.read_text().strip() if system_prompt_path.exists() else ""

    # ── Training hyperparams ──────────────────────────────────────────────────
    model_id       = cfg["model"]["base"]
    max_seq_len    = cfg["model"].get("max_seq_len", 1024)
    load_in_4bit   = cfg["model"].get("load_in_4bit", True)

    lora_r         = cfg["lora"]["r"]
    lora_alpha     = cfg["lora"]["alpha"]
    lora_dropout   = cfg["lora"].get("dropout", 0.05)
    target_modules = cfg["lora"]["target_modules"]

    epochs_min     = cfg["training"].get("epochs_min", 2)
    epochs_max     = cfg["training"].get("epochs_max", 3)
    batch_size     = cfg["training"].get("batch_size", 4)
    grad_accum     = cfg["training"].get("gradient_accumulation_steps", 1)
    lr             = cfg["training"].get("learning_rate", 5e-5)
    warmup_ratio   = cfg["training"].get("warmup_ratio", 0.1)
    weight_decay   = cfg["training"].get("weight_decay", 0.01)
    seed           = cfg["training"].get("seed", 42)
    epochs         = epochs_override or epochs_min

    device_cfg     = cfg.get("compute", {}).get("device", "cuda:0")

    print(f"\n{'='*60}")
    print(f"forge built-in trainer")
    print(f"Started: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"Model: {model_id}")
    print(f"Epochs: {epochs}  (min={epochs_min}, max={epochs_max})")
    print(f"Dataset: {canonical_path}")
    print(f"{'='*60}\n")

    # ── Load dataset ──────────────────────────────────────────────────────────
    if not canonical_path.exists():
        raise FileNotFoundError(f"Canonical dataset not found: {canonical_path}")

    raw = []
    with open(canonical_path) as f:
        for line in f:
            line = line.strip()
            if line:
                raw.append(json.loads(line))
    print(f"Loaded {len(raw)} training examples")

    # ── Load model ────────────────────────────────────────────────────────────
    import torch
    print(f"PyTorch: {torch.__version__}")
    print(f"CUDA: {torch.cuda.is_available()}")
    if torch.cuda.is_available():
        print(f"GPU: {torch.cuda.get_device_name(0)}")

    try:
        from unsloth import FastModel
        print("Using Unsloth fast path")
        model, tokenizer = FastModel.from_pretrained(
            model_name=model_id,
            max_seq_length=max_seq_len,
            load_in_4bit=load_in_4bit,
            dtype=None,
        )
        model = FastModel.get_peft_model(
            model,
            r=lora_r,
            lora_alpha=lora_alpha,
            lora_dropout=lora_dropout,
            target_modules=target_modules,
            bias="none",
            use_gradient_checkpointing="unsloth",
            random_state=seed,
        )
    except ImportError:
        print("Unsloth not available — using standard PEFT path")
        from transformers import AutoModelForCausalLM, AutoTokenizer
        from peft import LoraConfig, get_peft_model

        tokenizer = AutoTokenizer.from_pretrained(model_id)
        model = AutoModelForCausalLM.from_pretrained(
            model_id,
            torch_dtype=torch.float16 if torch.cuda.is_available() else torch.float32,
            device_map="auto" if torch.cuda.is_available() else None,
        )
        peft_config = LoraConfig(
            r=lora_r,
            lora_alpha=lora_alpha,
            lora_dropout=lora_dropout,
            target_modules=target_modules,
            bias="none",
            task_type="CAUSAL_LM",
        )
        model = get_peft_model(model, peft_config)

    print("Model loaded with QLoRA adapters.")

    # ── Format examples ───────────────────────────────────────────────────────
    def format_example(ex: dict) -> dict:
        msgs = ex.get("messages", [])
        # Strip existing system, inject forge system_prompt.md
        msgs = [m for m in msgs if m["role"] != "system"]
        if system_prompt:
            msgs = [{"role": "system", "content": system_prompt}] + msgs
        text = tokenizer.apply_chat_template(
            msgs, tokenize=False, add_generation_prompt=False
        )
        return {"text": text}

    from datasets import Dataset
    formatted = [format_example(ex) for ex in raw]
    dataset = Dataset.from_list(formatted)
    print(f"Dataset ready: {len(dataset)} examples")

    # ── Trainer ───────────────────────────────────────────────────────────────
    from trl import SFTTrainer, SFTConfig
    from transformers import TrainerCallback

    epoch_losses: list[float] = []

    class EpochLossCallback(TrainerCallback):
        def on_epoch_end(self, args, state, control, **kwargs):
            for entry in reversed(state.log_history):
                if "loss" in entry:
                    epoch_losses.append(entry["loss"])
                    print(f"  Epoch {len(epoch_losses)} loss: {entry['loss']:.4f}")
                    break

    training_args = SFTConfig(
        output_dir=str(adapter_dir),
        num_train_epochs=epochs,
        per_device_train_batch_size=batch_size,
        gradient_accumulation_steps=grad_accum,
        learning_rate=lr,
        warmup_ratio=warmup_ratio,
        weight_decay=weight_decay,
        lr_scheduler_type="cosine",
        fp16=not torch.cuda.is_bf16_supported() if torch.cuda.is_available() else False,
        bf16=torch.cuda.is_bf16_supported() if torch.cuda.is_available() else False,
        logging_steps=10,
        save_strategy="epoch",
        save_total_limit=2,
        dataset_text_field="text",
        max_seq_length=max_seq_len,
        packing=True,
        report_to="none",
        seed=seed,
    )

    trainer = SFTTrainer(
        model=model,
        tokenizer=tokenizer,
        train_dataset=dataset,
        args=training_args,
        callbacks=[EpochLossCallback()],
    )

    print(f"\nStarting training: {epochs} epochs, "
          f"batch={batch_size}×{grad_accum}={batch_size*grad_accum} effective")
    trainer.train()

    final_loss = epoch_losses[-1] if epoch_losses else 0.0
    elapsed = (time.time() - start) / 60
    print(f"\n✅ Training complete: {epochs} epochs in {elapsed:.1f} min")
    print(f"   Final loss: {final_loss:.4f}")

    # ── Save adapter only (skip merged — avoids Gemma3 embedding compat issues) ─
    print(f"Saving adapter to {adapter_dir}")
    model.save_pretrained(str(adapter_dir))
    tokenizer.save_pretrained(str(adapter_dir))

    result = {
        "adapter_dir": str(adapter_dir),
        "final_loss": final_loss,
        "epochs_run": epochs,
        "elapsed_min": round(elapsed, 1),
        "train_examples": len(raw),
    }
    print(json.dumps(result, indent=2))
    return result
