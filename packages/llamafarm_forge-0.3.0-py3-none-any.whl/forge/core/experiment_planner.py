"""forge.core.experiment_planner — autonomous ML experiment planning via Claude.

Each flywheel iteration, this module asks Claude to act as an ML experiment
planner: given current accuracy, failures, and experiment history, it returns
an ExperimentPlan that drives config patches, augmentation focus, and strategy.
"""
from __future__ import annotations
import os
import re

import json
from collections import defaultdict
from pathlib import Path
from typing import TypedDict


class ExperimentPlan(TypedDict, total=False):
    hypothesis: str
    rationale: str
    config_patches: dict
    forge_yaml_patches: dict
    background_additions: str
    augment_focus: str
    augment_n: int
    expected_improvement_pp: float


PLANNER_PROMPT = """You are an ML experiment planner for a self-improving SLM training loop.
Goal: reach {target:.0f}% accuracy. Current: {current:.1f}%. Iters remaining: {remaining}.

{augment_context}
BACKGROUND:
{background}

CURRENT FAILURES ({n_failures} total):
{failure_summary}

EXPERIMENT HISTORY (last 5):
{experiment_history}

You have PERSISTENT write access to:
- forge.yaml (via forge_yaml_patches): use to permanently change training config
- BACKGROUND.md (via background_additions): use to record new domain insights

Use forge_yaml_patches when:
- Loss has stalled for 2+ iterations → lower learning_rate by 50%
- Accuracy plateau → try r=128 or different epochs
- Overfitting detected (loss low, accuracy low) → add weight_decay

Use background_additions when:
- You discover a recurring failure pattern not yet documented
- You find a phrasing that confuses the model consistently
- You want to guide future datagen toward specific edge cases

Decide what to change next: config adjustments, augmentation focus, and your hypothesis.
Respond ONLY with a JSON object matching this schema:
{{
  "hypothesis": "<what you are testing this iteration>",
  "rationale": "<why you think this will improve accuracy>",
  "config_patches": {{}},
  "forge_yaml_patches": {{}},
  "background_additions": "<new markdown section to append to BACKGROUND.md, or omit if nothing new>",
  "augment_focus": "<specific instruction for data augmentation — overrides generic failure summary>",
  "augment_n": <int — number of synthetic examples to generate>,
  "expected_improvement_pp": <float — expected accuracy gain in percentage points>
}}
config_patches: applied only for this iteration (not persisted).
forge_yaml_patches: deep-merged into forge.yaml and SAVED permanently — use to lock in config changes.
background_additions: appended to BACKGROUND.md permanently — use to grow domain knowledge.
Omit forge_yaml_patches or background_additions (or use null/empty) if no persistent changes needed.
Return ONLY the JSON object. No markdown, no prose."""


def plan(
    project_dir: Path,
    cfg: dict,
    current_accuracy: float,
    failures: list[dict],
    experiment_history: list[dict],
) -> dict:
    """Ask Claude to plan the next experiment iteration.

    Args:
        project_dir: Root path of the forge project.
        cfg: Parsed forge.yaml config dict.
        current_accuracy: Latest eval accuracy (0.0–1.0).
        failures: List of failure dicts from eval_runner.
        experiment_history: List of past experiment dicts from experiments.jsonl.

    Returns:
        ExperimentPlan dict with keys: hypothesis, rationale, config_patches,
        forge_yaml_patches, background_additions, augment_focus, augment_n,
        expected_improvement_pp.
    """
    from forge.core.planner import load_augment_context

    flywheel_cfg = cfg.get("flywheel", {})
    model_id = flywheel_cfg.get(
        "planner_model",
        flywheel_cfg.get("datagen_model", "claude-sonnet-4-6"),
    )
    target_accuracy = cfg["eval"].get("target_accuracy", 0.95)
    max_iters = flywheel_cfg.get("max_iterations", 10)

    # Context bundle: mission + system_prompt + PLAN.md + AGENT_CONTEXT.md
    augment_context = load_augment_context(project_dir)

    # BACKGROUND.md — always in full, never truncated
    background_path = project_dir / "BACKGROUND.md"
    background = (
        background_path.read_text().strip()
        if background_path.exists()
        else "(no BACKGROUND.md — add one for richer datagen)"
    )

    # Group failures by category, show up to 3 examples each
    by_category: dict[str, list[dict]] = defaultdict(list)
    for f in failures:
        cat = f.get("category", "general")
        by_category[cat].append(f)

    failure_lines: list[str] = []
    for cat, cat_failures in by_category.items():
        failure_lines.append(f"\nCategory: {cat} ({len(cat_failures)} failures)")
        for f in cat_failures[:3]:
            failure_lines.append(f"  Input:    {f.get('input', '')[:100]}")
            failure_lines.append(f"  Expected: {f.get('expected', '')[:100]}")
            failure_lines.append(f"  Actual:   {f.get('actual', '')[:100]}")
    failure_summary = "\n".join(failure_lines) if failure_lines else "(no failures)"

    completed = len(experiment_history)
    remaining = max(max_iters - completed, 1)

    prompt = PLANNER_PROMPT.format(
        target=target_accuracy * 100,
        current=current_accuracy * 100,
        remaining=remaining,
        augment_context=augment_context,
        background=background,
        n_failures=len(failures),
        failure_summary=failure_summary,
        experiment_history=json.dumps(experiment_history[-5:], indent=2) if experiment_history else "[]",
    )

    import anthropic
    api_key = cfg.get("_anthropic_key") or os.environ.get("ANTHROPIC_API_KEY", "")
    if not api_key:
        print("[planner] WARNING: ANTHROPIC_API_KEY not set — using fallback plan")
        return _parse_plan("")
    client = anthropic.Anthropic(api_key=api_key)
    try:
        response = client.messages.create(
            model=model_id,
            max_tokens=1024,
            messages=[{"role": "user", "content": prompt}],
        )
        raw_text = response.content[0].text.strip()
    except Exception as e:
        print(f"[planner] API error: {e} — using fallback plan")
        return _parse_plan("")

    parsed = _parse_plan(raw_text)
    if parsed["hypothesis"].startswith("Augment from failures"):
        print(f"[planner] WARNING: could not parse plan. Raw response:\n{raw_text[:500]}")
        # Log to debug file for post-hoc inspection
        debug_path = project_dir / "output" / "planner_debug.jsonl"
        debug_path.parent.mkdir(parents=True, exist_ok=True)
        with open(debug_path, "a") as f:
            import time
            json.dump({"timestamp": time.time(), "raw_response": raw_text}, f)
            f.write("\n")
    return parsed


def _parse_plan(raw_text: str) -> dict:
    """Parse Claude's JSON ExperimentPlan response robustly.

    Tries three strategies in order:
    1. Direct json.loads on the stripped text.
    2. Strip ```json ... ``` or ``` ... ``` markdown fences, then parse.
    3. Regex-extract the first {...} object anywhere in the text (handles
       prose before/after the JSON block).

    Returns a validated ExperimentPlan dict, or a fallback if all strategies fail.
    """
    text = raw_text.strip()

    def _try_parse(s: str) -> dict | None:
        try:
            parsed = json.loads(s)
            if isinstance(parsed, dict) and "hypothesis" in parsed:
                return {
                    "hypothesis": str(parsed.get("hypothesis", "")),
                    "rationale": str(parsed.get("rationale", "")),
                    "config_patches": parsed.get("config_patches") or {},
                    "forge_yaml_patches": parsed.get("forge_yaml_patches") or {},
                    "background_additions": parsed.get("background_additions") or "",
                    "augment_focus": str(parsed.get("augment_focus", "")),
                    "augment_n": int(parsed.get("augment_n", 10)),
                    "expected_improvement_pp": float(parsed.get("expected_improvement_pp", 0.0)),
                }
        except (json.JSONDecodeError, ValueError, TypeError):
            pass
        return None

    # 1. Direct parse
    result = _try_parse(text)
    if result:
        return result

    # 2. Strip markdown fences (```json ... ``` or ``` ... ```)
    fence_match = re.search(r"```(?:json)?\s*\n(.*?)```", text, re.DOTALL)
    if fence_match:
        result = _try_parse(fence_match.group(1).strip())
        if result:
            return result

    # 3. Extract first JSON object anywhere in text (handles prose before/after)
    brace_match = re.search(r'\{.*\}', text, re.DOTALL)
    if brace_match:
        result = _try_parse(brace_match.group(0))
        if result:
            return result

    # All strategies failed — return fallback
    return {
        "hypothesis": "Augment from failures (planner response unparseable)",
        "rationale": "",
        "config_patches": {},
        "forge_yaml_patches": {},
        "background_additions": "",
        "augment_focus": "",
        "augment_n": 10,
        "expected_improvement_pp": 0.0,
    }
