"""forge.core.eval_runner — built-in eval engine driven by forge.yaml + scorer plugin.

Used by `forge eval` when the project has no src/eval.py.
Loads the adapter, runs gold.jsonl through the model, scores via
the configured scorer (built-in or scorer.py plugin), writes
output/eval_results.json, and returns a results dict.
"""
from __future__ import annotations

import json
import sys
import time
from pathlib import Path

from forge.core.scorer import load_scorer


def run(project_dir: Path, cfg: dict, adapter_path: Path) -> dict:
    """Run evaluation against gold.jsonl.

    Returns:
        dict with keys: accuracy, correct, total, safety_violations,
                        passed, per_category, failures
    """
    start = time.time()

    # ── Paths ─────────────────────────────────────────────────────────────────
    output_dir = project_dir / "output"
    output_dir.mkdir(exist_ok=True)

    gold_rel = cfg.get("dataset", {}).get("gold", "dataset/gold.jsonl")
    gold_path = Path(gold_rel)
    if not gold_path.is_absolute():
        gold_path = project_dir / gold_path

    system_prompt_path = project_dir / "system_prompt.md"
    system_prompt = system_prompt_path.read_text().strip() if system_prompt_path.exists() else ""

    target_acc        = cfg["eval"].get("target_accuracy", 0.95)
    scorer_name       = cfg["eval"].get("scorer", "exact")
    max_new_tokens    = cfg["eval"].get("max_new_tokens", 64)
    forbidden_cmds    = cfg["eval"].get("forbidden_commands", [])

    # ── Load gold set ─────────────────────────────────────────────────────────
    if not gold_path.exists():
        raise FileNotFoundError(f"Gold eval set not found: {gold_path}")

    gold = []
    with open(gold_path) as f:
        for line in f:
            line = line.strip()
            if line:
                gold.append(json.loads(line))
    print(f"Gold set: {len(gold)} examples")

    # ── Load model + adapter ──────────────────────────────────────────────────
    import torch

    try:
        from unsloth import FastModel
        print(f"Loading model + adapter (Unsloth): {adapter_path}")
        model, tokenizer = FastModel.from_pretrained(
            model_name=str(adapter_path),
            max_seq_length=cfg["model"].get("max_seq_len", 1024),
            load_in_4bit=cfg["model"].get("load_in_4bit", True),
            dtype=None,
        )
        # NOTE: do NOT call FastModel.for_inference() — it patches generate()
        # to require a BatchEncoding dict, breaking plain tensor input_ids.
        # Standard eval mode is sufficient.
        model.eval()
        _use_unsloth = True
    except ImportError:
        _use_unsloth = False
        from transformers import AutoModelForCausalLM, AutoTokenizer
        from peft import PeftModel
        base_id = cfg["model"]["base"]
        print(f"Loading model + adapter (HF): base={base_id}, adapter={adapter_path}")
        tokenizer = AutoTokenizer.from_pretrained(str(adapter_path))
        base_model = AutoModelForCausalLM.from_pretrained(
            base_id,
            torch_dtype=torch.float16 if torch.cuda.is_available() else torch.float32,
            device_map="auto" if torch.cuda.is_available() else None,
        )
        model = PeftModel.from_pretrained(base_model, str(adapter_path))
        model.eval()

    device = "cuda" if torch.cuda.is_available() else "cpu"
    scorer = load_scorer(project_dir, scorer_name)
    print(f"Scorer: {scorer_name} | Device: {device}")

    # ── Run eval ──────────────────────────────────────────────────────────────
    correct = 0
    total = len(gold)
    safety_violations = 0
    failures = []
    per_category: dict[str, dict] = {}

    for i, example in enumerate(gold):
        msgs = example.get("messages", [])
        # Strip system, inject system_prompt.md
        msgs = [m for m in msgs if m["role"] != "system"]
        if system_prompt:
            msgs = [{"role": "system", "content": system_prompt}] + msgs

        # Last assistant message is the expected answer
        expected_raw = ""
        input_msgs = []
        for m in msgs:
            if m["role"] == "assistant":
                expected_raw = m["content"]
            else:
                input_msgs.append(m)

        # Build expected dict for scorer
        try:
            expected = json.loads(expected_raw)
        except Exception:
            expected = {"answer": expected_raw}

        # Get category (first non-system user message, or "general")
        category = example.get("category", "general")

        # Run inference
        # ALIGNMENT NOTE: trainer.py formats examples as:
        #   apply_chat_template(msgs_with_answer, tokenize=False, add_generation_prompt=False)
        # Eval mirrors this but without the answer (input_msgs only), with
        # add_generation_prompt=True so the model generates the assistant turn.
        # system_prompt.md injection is identical in both: strip existing system,
        # prepend {"role": "system", "content": system_prompt}.
        # Any divergence here would cause low-loss / low-accuracy symptoms.
        #
        # apply_chat_template with tokenize=True returns a raw tensor (not BatchEncoding).
        # Unsloth's patched generate requires a plain torch.Tensor passed as input_ids kwarg.
        # We encode via tokenizer() on the rendered text to get full BatchEncoding,
        # then extract input_ids to guarantee correct type and device placement.
        chat_text = tokenizer.apply_chat_template(
            input_msgs,
            tokenize=False,
            add_generation_prompt=True,
        )
        encoded = tokenizer(chat_text, return_tensors="pt").to(device)
        input_ids = encoded["input_ids"]

        with torch.no_grad():
            outputs = model.generate(
                input_ids=input_ids,
                max_new_tokens=max_new_tokens,
                do_sample=False,
                pad_token_id=tokenizer.eos_token_id,
            )

        new_tokens = outputs[0][input_ids.shape[1]:]
        actual = tokenizer.decode(new_tokens, skip_special_tokens=True).strip()

        # Safety check
        try:
            actual_obj = json.loads(actual)
            if isinstance(actual_obj, dict):
                cmd = actual_obj.get("cmd", "")
                if cmd in forbidden_cmds:
                    safety_violations += 1
        except Exception:
            pass

        # Score
        result = scorer(expected, actual)
        is_correct = result.get("correct", False)

        if is_correct:
            correct += 1
        else:
            failures.append({
                "index": i,
                "category": category,
                "input": input_msgs[-1]["content"] if input_msgs else "",
                "expected": expected_raw,
                "actual": actual,
                "error": result.get("error"),
            })

        # Per-category stats
        if category not in per_category:
            per_category[category] = {"correct": 0, "total": 0}
        per_category[category]["total"] += 1
        if is_correct:
            per_category[category]["correct"] += 1

        # Live progress
        running_acc = correct / (i + 1)
        print(f"  [{i+1}/{total}] running accuracy: {running_acc*100:.1f}%", end="\r")

    print()  # newline after progress line

    accuracy = correct / total if total > 0 else 0.0
    passed = accuracy >= target_acc and safety_violations == 0
    elapsed = (time.time() - start) / 60

    print(f"\n{'='*50}")
    print(f"RESULTS: {correct}/{total} = {accuracy*100:.1f}%  (target {target_acc*100:.0f}%)")
    print(f"Safety violations: {safety_violations}")
    print(f"Passed: {'✅ YES' if passed else '❌ NO'}")
    print(f"Elapsed: {elapsed:.1f} min")
    print(f"{'='*50}\n")

    results = {
        "accuracy": round(accuracy, 4),
        "correct": correct,
        "total": total,
        "safety_violations": safety_violations,
        "passed": passed,
        "per_category": per_category,
        "failures": failures,
        "elapsed_min": round(elapsed, 1),
    }

    # Write eval_results.json
    results_file = output_dir / "eval_results.json"
    results_file.write_text(json.dumps(results, indent=2))

    # Write timestamped failures
    if failures:
        from datetime import datetime
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        failures_file = output_dir / f"failures_{ts}.json"
        failures_file.write_text(json.dumps({"failures": failures}, indent=2))
        print(f"Failures saved: {failures_file.name}")

    return results
