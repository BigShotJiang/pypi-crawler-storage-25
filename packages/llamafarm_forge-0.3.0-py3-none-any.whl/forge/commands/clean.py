"""forge clean — archive stale datasets so the flywheel only sees what matters.

Handles both project layouts:
  - dataset/   (forge-native layout)
  - src/dataset/ (llamadrone-style layout)
"""
from __future__ import annotations
from pathlib import Path
import click
from rich.console import Console
from rich.table import Table
from forge.core import config
from forge.core.dataset import archive_stale_datasets

console = Console()


def _find_dataset_dir(project_dir: Path, cfg: dict) -> Path:
    """Return the active dataset directory.

    Checks (in order):
    1. Parent of the configured canonical path
    2. project_dir/src/dataset  (llamadrone layout)
    3. project_dir/dataset      (forge-native layout)
    """
    canonical = cfg.get("dataset", {}).get("canonical", "")
    if canonical:
        p = Path(canonical)
        if not p.is_absolute():
            p = project_dir / p
        if p.parent.is_dir():
            return p.parent

    for candidate in ["src/dataset", "dataset"]:
        d = project_dir / candidate
        if d.is_dir():
            return d

    return project_dir / "dataset"


@click.command()
@click.option("--project", "-p", default=None, help="Project directory")
@click.option("--dry-run", is_flag=True, help="Show what would be moved without moving")
def clean(project: str, dry_run: bool):
    """Archive stale datasets — keep only canonical + gold.

    \b
    Moves all _audited, _reviewed, _clean, augmented_*, and old version
    files to <dataset_dir>/archive/ so the flywheel only sees active datasets.

    Handles both dataset/ and src/dataset/ layouts.

    This prevents the common bug where augmentation reads from a wrong/stale
    failures file because an older regression run happened to be more recent.
    """
    project_dir = Path(project) if project else config.find_project_root()
    if not project_dir:
        console.print("[red]No forge.yaml or configs/task.yaml found.[/red]")
        raise SystemExit(1)

    cfg = config.load(project_dir)
    ds_dir = _find_dataset_dir(project_dir, cfg)

    canonical_raw = cfg.get("dataset", {}).get("canonical", "")
    gold_raw = cfg.get("dataset", {}).get("gold", "")
    canonical = Path(canonical_raw).name if canonical_raw else ""
    gold = Path(gold_raw).name if gold_raw else ""

    if not ds_dir.exists():
        console.print(f"[yellow]Dataset directory not found: {ds_dir}[/yellow]")
        raise SystemExit(1)

    to_archive = [
        f for f in ds_dir.glob("*.jsonl")
        if f.name not in (canonical, gold) and f.name != "archive"
    ]

    if not to_archive:
        console.print(f"[green]Dataset directory is already clean.[/green]")
        console.print(f"[dim]Active: {canonical}, {gold}[/dim]")
        console.print(f"[dim]Dir: {ds_dir}[/dim]")
        return

    title = "Would archive (dry run)" if dry_run else "Files to archive"
    table = Table(title=title)
    table.add_column("File")
    table.add_column("Size", justify="right")
    for f in sorted(to_archive):
        size = f"{f.stat().st_size // 1024}KB"
        table.add_row(f.name, size)
    console.print(table)
    console.print(f"\n[dim]Active canonical: {canonical}[/dim]")
    console.print(f"[dim]Active gold:      {gold}[/dim]")
    console.print(f"[dim]Dataset dir:      {ds_dir}[/dim]")

    if dry_run:
        console.print(f"\n[dim]Run without --dry-run to archive {len(to_archive)} files.[/dim]")
        return

    moved = archive_stale_datasets(project_dir, keep=[canonical, gold])
    console.print(f"\n[green]✅ Archived {len(moved)} files to {ds_dir}/archive/[/green]")
    console.print(f"[dim]Active: {canonical}, {gold}[/dim]")
