"""forge flywheel — full agentic train → eval → promote → augment loop."""
from __future__ import annotations

import json
import shutil
import subprocess
from datetime import datetime
from pathlib import Path
from typing import Optional

import click
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from forge.core import config

console = Console()


@click.command()
@click.option("--iters", default=None, type=int, help="Max iterations (overrides forge.yaml)")
@click.option("--skip-train", is_flag=True, help="Skip training on first iteration (eval only)")
@click.option("--project", "-p", default=None, help="Project directory")
def flywheel(iters: int, skip_train: bool, project: str):
    """Run the full self-improving flywheel loop.

    \b
    Loop: plan → train → eval → promote (if better) → augment → repeat

    Claude acts as ML experiment planner each iteration, deciding config
    changes and augmentation focus. Stops when target_accuracy is reached
    or max_iterations exhausted.

    On each new best: snapshots adapter to output/best_adapter_<acc>/.
    Heartbeat written to output/flywheel_heartbeat.json each iteration.
    Git commit written after each iteration for full auditability.
    """
    project_dir = Path(project) if project else config.find_project_root()
    if not project_dir:
        console.print("[red]No forge.yaml found. Run forge init first.[/red]")
        raise SystemExit(1)

    cfg = config.load(project_dir)
    _run_flywheel(project_dir, cfg, max_iters=iters, skip_train=skip_train)


def _deep_merge(base: dict, override: dict) -> dict:
    """Recursively merge override into base, returning a new dict."""
    result = dict(base)
    for k, v in override.items():
        if isinstance(v, dict) and isinstance(result.get(k), dict):
            result[k] = _deep_merge(result[k], v)
        else:
            result[k] = v
    return result


def _write_heartbeat(output_dir: Path, iteration: int, status: str,
                     accuracy: Optional[float] = None, error: Optional[str] = None):
    """Write a heartbeat JSON for watchdog/cron monitoring."""
    payload: dict = {
        "iteration": iteration,
        "status": status,
        "timestamp": datetime.utcnow().isoformat() + "Z",
    }
    if accuracy is not None:
        payload["accuracy"] = accuracy
    if error is not None:
        payload["error"] = error
    heartbeat_path = output_dir / "flywheel_heartbeat.json"
    heartbeat_path.write_text(json.dumps(payload, indent=2))


def _git_commit_iteration(project_dir: Path, iteration: int, accuracy: float, hypothesis: str):
    """Commit all changes after an iteration (best-effort, silently skips if not a git repo)."""
    # Only commit if we're in a git repo
    result = subprocess.run(
        ["git", "rev-parse", "--git-dir"],
        cwd=project_dir,
        capture_output=True,
    )
    if result.returncode != 0:
        return  # not a git repo, skip silently

    subprocess.run(["git", "add", "-A"], cwd=project_dir, capture_output=True)
    msg = f"forge iter {iteration}: {accuracy * 100:.1f}% — {hypothesis[:60]}"
    subprocess.run(
        ["git", "commit", "--allow-empty", "-m", msg],
        cwd=project_dir,
        capture_output=True,
    )


def _apply_forge_yaml_patches(project_dir: Path, patches: dict) -> None:
    """Deep-merge patches into forge.yaml and write it back (best-effort)."""
    if not patches:
        return

    forge_yaml_path = project_dir / "forge.yaml"
    if not forge_yaml_path.exists():
        return

    try:
        # Prefer ruamel.yaml for comment preservation; fall back to pyyaml
        try:
            from ruamel.yaml import YAML
            ryaml = YAML()
            ryaml.preserve_quotes = True
            with open(forge_yaml_path) as f:
                current = ryaml.load(f)
            merged = _deep_merge(dict(current), patches)
            # ruamel doesn't deep-merge in-place so we re-load as plain dict then dump
            import io
            out = io.StringIO()
            ryaml.dump(merged, out)
            forge_yaml_path.write_text(out.getvalue())
        except ImportError:
            import yaml
            with open(forge_yaml_path) as f:
                current = yaml.safe_load(f) or {}
            merged = _deep_merge(current, patches)
            with open(forge_yaml_path, "w") as f:
                yaml.dump(merged, f, default_flow_style=False)
    except Exception:
        pass  # best-effort; never crash flywheel over a config write failure


def _append_to_background(project_dir: Path, additions: str) -> None:
    """Append agent-discovered patterns to BACKGROUND.md (best-effort)."""
    if not additions or not additions.strip():
        return

    background_path = project_dir / "BACKGROUND.md"
    try:
        existing = background_path.read_text() if background_path.exists() else ""

        # Ensure we have the section header once
        section_header = "## Agent-Discovered Patterns"
        if section_header not in existing:
            existing = existing.rstrip() + f"\n\n{section_header}\n"
        else:
            existing = existing.rstrip() + "\n"

        existing += "\n" + additions.strip() + "\n"
        background_path.write_text(existing)
    except Exception:
        pass  # best-effort


def _run_flywheel(
    project_dir: Path,
    cfg: dict,
    max_iters: Optional[int] = None,
    skip_train: bool = False,
) -> dict:
    """Core flywheel loop. Returns summary dict with final accuracy and iterations run.

    Separated from the Click command so it can be called programmatically in tests.
    """
    from forge.core import trainer, eval_runner, context
    from forge.core import augmentor, experiment_planner
    from forge.core.planner import update_plan

    flywheel_cfg = cfg.get("flywheel", {})
    max_iters = max_iters or flywheel_cfg.get("max_iterations", 5)
    target_accuracy = cfg["eval"].get("target_accuracy", 0.95)

    output_dir = project_dir / "output"
    output_dir.mkdir(exist_ok=True)

    experiments_file = output_dir / "experiments.jsonl"
    best_score_file = output_dir / "best_score.json"

    # Load existing best score
    best_accuracy = 0.0
    if best_score_file.exists():
        try:
            best_accuracy = json.loads(best_score_file.read_text()).get("accuracy", 0.0)
        except Exception:
            best_accuracy = 0.0

    epochs_min = cfg["training"].get("epochs_min", 2)
    epochs_max = cfg["training"].get("epochs_max", 3)
    current_epochs = epochs_min

    prev_loss: Optional[float] = None
    no_improve_streak = 0
    prev_failures: list[dict] = []
    prev_accuracy: Optional[float] = None
    experiment_history: list[dict] = []

    # Load prior experiment history from jsonl if it exists
    if experiments_file.exists():
        for line in experiments_file.read_text().splitlines():
            line = line.strip()
            if line:
                try:
                    experiment_history.append(json.loads(line))
                except Exception:
                    pass

    project_name = cfg.get("name", project_dir.name)

    console.print(Panel(
        f"[bold green]forge flywheel[/bold green] — {project_name}\n"
        f"Target: [cyan]{target_accuracy * 100:.0f}%[/cyan] | "
        f"Max iters: [cyan]{max_iters}[/cyan] | "
        f"skip-train iter-1: [cyan]{skip_train}[/cyan]",
        title="🔄 Flywheel Start",
        border_style="green",
    ))

    final_accuracy = 0.0
    train_result: dict = {}
    current_plan: dict = {}
    iteration = 0

    try:
        for iteration in range(1, max_iters + 1):
            ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            console.print(f"\n[bold]── Iteration {iteration}/{max_iters}[/bold]  [{ts}]")

            # Write heartbeat: status=running
            _write_heartbeat(output_dir, iteration, "running")

            # ── 1. Plan via Claude ─────────────────────────────────────────────
            console.print("  [dim]Planning experiment…[/dim]")
            try:
                current_plan = experiment_planner.plan(
                    project_dir=project_dir,
                    cfg=cfg,
                    current_accuracy=prev_accuracy if prev_accuracy is not None else 0.0,
                    failures=prev_failures,
                    experiment_history=experiment_history,
                )
                console.print(f"  [cyan]Hypothesis: {current_plan.get('hypothesis', '')}[/cyan]")
            except Exception as e:
                console.print(f"  [yellow]Planner failed ({e}), using defaults[/yellow]")
                current_plan = {
                    "hypothesis": "Augment from failures (planner unavailable)",
                    "rationale": "",
                    "config_patches": {},
                    "forge_yaml_patches": {},
                    "background_additions": "",
                    "augment_focus": "",
                    "augment_n": flywheel_cfg.get("augment_per_failure", 10),
                    "expected_improvement_pp": 0.0,
                }

            # ── 2. Apply config patches ────────────────────────────────────────
            config_patches = current_plan.get("config_patches") or {}
            effective_cfg = _deep_merge(cfg, config_patches) if config_patches else cfg

            # Epoch override: use cfg's current_epochs logic, respect patches
            epoch_override = effective_cfg["training"].get("epochs_min", current_epochs)
            if config_patches.get("training", {}).get("epochs_min"):
                epoch_override = config_patches["training"]["epochs_min"]
            else:
                epoch_override = current_epochs

            # ── 3. Train ───────────────────────────────────────────────────────
            adapter_path = output_dir / "adapter"
            do_train = not (skip_train and iteration == 1)

            if do_train:
                console.print(f"  [dim]Training (epochs={epoch_override})…[/dim]")
                train_result = trainer.run(project_dir, effective_cfg, epochs_override=epoch_override)
                adapter_path = Path(train_result["adapter_dir"])
                current_loss = train_result.get("final_loss", 0.0)

                # Track loss improvement for epoch bumping
                if prev_loss is not None and current_loss >= prev_loss:
                    no_improve_streak += 1
                else:
                    no_improve_streak = 0
                prev_loss = current_loss
            else:
                console.print("  [dim]Skipping training (--skip-train, iter 1)[/dim]")
                current_loss = 0.0

            # ── 4. Eval ────────────────────────────────────────────────────────
            console.print("  [dim]Evaluating…[/dim]")
            eval_result = eval_runner.run(project_dir, cfg, adapter_path)

            accuracy = eval_result.get("accuracy", 0.0)
            failures = eval_result.get("failures", [])
            correct = eval_result.get("correct", 0)
            total = eval_result.get("total", 0)
            final_accuracy = accuracy

            # ── 5. Promote if new best ─────────────────────────────────────────
            is_new_best = accuracy > best_accuracy
            if is_new_best:
                acc_str = f"{accuracy:.4f}".replace(".", "_")
                best_dir = output_dir / f"best_adapter_{acc_str}"
                if adapter_path.exists():
                    if best_dir.exists():
                        shutil.rmtree(best_dir)
                    shutil.copytree(adapter_path, best_dir)
                best_accuracy = accuracy
                best_score_file.write_text(json.dumps({
                    "accuracy": accuracy,
                    "iteration": iteration,
                    "timestamp": ts,
                    "adapter_dir": str(best_dir),
                }, indent=2))
                console.print(f"  [green]✓ New best: {accuracy*100:.1f}% → saved to {best_dir.name}[/green]")

            # ── 6. Update PLAN.md + AGENT_CONTEXT.md ──────────────────────────
            train_file = cfg.get("dataset", {}).get("canonical", "dataset/canonical.jsonl")

            # PLAN.md update
            try:
                update_plan(
                    project_dir=project_dir,
                    iteration=iteration,
                    accuracy=accuracy,
                    failures=failures,
                    prev_accuracy=prev_accuracy,
                    hypothesis=current_plan.get("hypothesis", ""),
                    result="improvement" if is_new_best else "no improvement",
                )
            except Exception as e:
                console.print(f"  [dim yellow]PLAN.md update failed: {e}[/dim yellow]")

            # AGENT_CONTEXT.md update
            context.update(
                project_dir=project_dir,
                iteration=iteration,
                accuracy=accuracy,
                failures=failures,
                train_file=train_file,
                loss=current_loss,
                prev_failures=prev_failures,
            )

            # ── 7. Log to experiments.jsonl ────────────────────────────────────
            experiment_entry = {
                "iteration": iteration,
                "timestamp": ts,
                "accuracy": accuracy,
                "correct": correct,
                "total": total,
                "loss": current_loss,
                "epochs": epoch_override,
                "failures_count": len(failures),
                "is_new_best": is_new_best,
                "train_examples": train_result.get("train_examples", 0),
                "hypothesis": current_plan.get("hypothesis", ""),
                "config_patches": config_patches,
                "expected_improvement_pp": current_plan.get("expected_improvement_pp", 0.0),
                "outcome": "improvement" if is_new_best else "no_improvement",
            }
            with open(experiments_file, "a") as f:
                f.write(json.dumps(experiment_entry) + "\n")
            experiment_history.append(experiment_entry)

            # ── 8. Heartbeat: status=completed ────────────────────────────────
            _write_heartbeat(output_dir, iteration, "completed", accuracy=accuracy)

            # ── Rich progress panel ────────────────────────────────────────────
            table = Table(show_header=False, box=None, padding=(0, 1))
            table.add_row("Accuracy", f"{accuracy*100:.1f}% ({correct}/{total})")
            table.add_row("Loss", f"{current_loss:.4f}")
            table.add_row("Failures", str(len(failures)))
            table.add_row("New best", "✓" if is_new_best else "—")
            table.add_row("Hypothesis", current_plan.get("hypothesis", "")[:60])
            console.print(Panel(table, title=f"Iter {iteration} Results", border_style="blue"))

            # ── 9. Check target ────────────────────────────────────────────────
            if accuracy >= target_accuracy:
                console.print(Panel(
                    f"[bold green]🎯 Target reached![/bold green]\n"
                    f"Accuracy: {accuracy*100:.1f}% ≥ {target_accuracy*100:.0f}%  "
                    f"(iteration {iteration}/{max_iters})",
                    border_style="green",
                ))
                # Still apply persistent changes and commit before break
                _apply_forge_yaml_patches(project_dir, current_plan.get("forge_yaml_patches") or {})
                _append_to_background(project_dir, current_plan.get("background_additions") or "")
                _git_commit_iteration(
                    project_dir, iteration, accuracy,
                    current_plan.get("hypothesis", "target reached"),
                )
                break

            # ── 10. Augment using plan's focus + n ─────────────────────────────
            if failures:
                augment_n = current_plan.get("augment_n") or flywheel_cfg.get("augment_per_failure", 10)
                augment_focus = current_plan.get("augment_focus", "")
                console.print(f"  [dim]Augmenting ({augment_n} examples, "
                               f"focus: {augment_focus[:50] or 'general failures'})…[/dim]")
                try:
                    added = augmentor.run(
                        project_dir=project_dir,
                        cfg=cfg,
                        failures=failures,
                        per_failure=augment_n,
                        augment_focus=augment_focus,
                    )
                    console.print(f"  [cyan]+ {added} synthetic examples added[/cyan]")
                except Exception as e:
                    console.print(f"  [yellow]Augmentation failed: {e}[/yellow]")

            # ── 11. Apply forge.yaml patches (persistent config changes) ───────
            forge_yaml_patches = current_plan.get("forge_yaml_patches") or {}
            if forge_yaml_patches:
                console.print(f"  [dim]Applying forge.yaml patches: {list(forge_yaml_patches.keys())}…[/dim]")
                _apply_forge_yaml_patches(project_dir, forge_yaml_patches)
                # Reload cfg so next iteration uses new values
                try:
                    cfg = config.load(project_dir)
                    console.print("  [dim]forge.yaml reloaded[/dim]")
                except Exception as e:
                    console.print(f"  [yellow]forge.yaml reload failed: {e}[/yellow]")

            # ── 12. Append to BACKGROUND.md (persistent domain knowledge) ──────
            background_additions = current_plan.get("background_additions") or ""
            if background_additions.strip():
                console.print("  [dim]Appending new insight to BACKGROUND.md…[/dim]")
                _append_to_background(project_dir, background_additions)

            # ── 13. Git commit (snapshot of this iteration) ────────────────────
            _git_commit_iteration(
                project_dir, iteration, accuracy,
                current_plan.get("hypothesis", ""),
            )

            # ── Optionally bump epochs if loss stalled ─────────────────────────
            if no_improve_streak >= 2 and current_epochs < epochs_max:
                current_epochs += 1
                no_improve_streak = 0
                console.print(f"  [yellow]↑ Bumping epochs to {current_epochs} (loss stalled)[/yellow]")

            prev_failures = failures
            prev_accuracy = accuracy

        else:
            console.print(Panel(
                f"[yellow]Max iterations ({max_iters}) exhausted.[/yellow]\n"
                f"Final accuracy: {final_accuracy*100:.1f}%  "
                f"(target was {target_accuracy*100:.0f}%)",
                border_style="yellow",
            ))

    except Exception as e:
        _write_heartbeat(output_dir, iteration, "error", error=str(e))
        raise

    return {
        "final_accuracy": final_accuracy,
        "best_accuracy": best_accuracy,
        "iterations_run": min(iteration, max_iters),
        "target_reached": final_accuracy >= target_accuracy,
    }
