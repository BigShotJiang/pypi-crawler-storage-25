"""forge init — scaffold a new project or migrate an existing one."""
from __future__ import annotations
import shutil
from pathlib import Path
import click
from rich.console import Console
from rich.panel import Panel

# Path to the bundled llm.txt template
_TEMPLATES_DIR = Path(__file__).parent.parent / "templates"

console = Console()

FORGE_YAML_TEMPLATE = """\
name: {name}

model:
  base: unsloth/functiongemma-270m-it
  max_seq_len: 2048
  load_in_4bit: true

lora:
  r: 32
  alpha: 32
  dropout: 0.05

training:
  epochs_min: 2
  epochs_max: 4
  batch_size: 4
  learning_rate: 5.0e-5

eval:
  target_accuracy: 0.95
  scorer: json_cmd   # exact | semantic | json_cmd | custom

dataset:
  seed: dataset/seed.jsonl
  gold: dataset/gold.jsonl
  canonical: dataset/canonical.jsonl

promotion:
  hf_repo: null    # e.g. my-org/my-model
  private: true

flywheel:
  max_iterations: 10
  augment_per_failure: 20
  datagen_model: claude-sonnet-4-6

# ── Pretraining (optional — domain knowledge acquisition) ─────────────────
# Run: forge pretrain   then   forge probe --compare
# After pretraining, set model.base to output/pretrain_merged/ and run forge flywheel
pretrain:
  corpus_dir: dataset/corpus      # .txt, .md, or .jsonl (field: "text")
  epochs: 1
  learning_rate: 2.0e-5           # lower than fine-tune LR
  batch_size: 4
  gradient_accumulation_steps: 4
  max_seq_len: 2048
  output_adapter: output/pretrain_adapter   # raw LoRA (auto-merged to pretrain_merged/)
"""

MISSION_TEMPLATE = """\
# Mission Brief — {name}

## Task Description
Describe what the model should do. This is fed to Claude when generating
augmentation data and when analyzing failures.

## Input Format
What does the user/system send to the model?

## Output Format
What should the model output? (commands, JSON, natural language, etc.)

## Safety Rules
List any hard constraints (e.g. never output X, always validate Y).

## Edge Cases
Known tricky inputs the model must handle correctly.
"""

SYSTEM_PROMPT_TEMPLATE = """\
# System Prompt — {name}

Replace this with your model's system prompt.
This file is the single source of truth — train.py, eval.py, and datagen.py
all load from here at runtime.
"""

BACKGROUND_TEMPLATE = """\
# Background — {name}

<!-- ============================================================
     BACKGROUND.md — Static domain knowledge for Claude datagen.

     This file is your "prompt engineering" for synthetic data
     generation. It is ALWAYS included in full (never truncated)
     in every Claude augmentation call.

     Write this once and keep it accurate. The better this file,
     the more realistic and diverse your generated training data.

     DO NOT put iteration logs or run history here — that belongs
     in AGENT_CONTEXT.md (auto-managed by forge flywheel).
     ============================================================ -->

## Task

<!-- What does this model do? Be specific about the exact task. -->


## Output Format

<!-- Exactly how the assistant output must be structured.
     Show the full JSON schema with a concrete example. -->


## Edge Cases

<!-- Inputs that look ambiguous or tricky but have a correct answer.
     List them explicitly so Claude generates targeted coverage. -->


## Common Failure Patterns

<!-- What has the model historically gotten wrong?
     Update this as you discover patterns from eval failures. -->


## What Good Examples Look Like

<!-- Input phrasing variety, output correctness criteria, difficulty range. -->
"""


@click.command()
@click.argument("name")
@click.option("--from", "from_dir", default=None,
              help="Migrate existing project directory")
@click.option("--dir", "out_dir", default=None,
              help="Output directory (default: ./<name>)")
def init(name: str, from_dir: str, out_dir: str):
    """Scaffold a new forge project.

    \b
    Examples:
      forge init my-router
      forge init my-router --from /path/to/existing-project
    """
    target = Path(out_dir or name)

    if from_dir:
        _migrate(name, Path(from_dir), target)
    else:
        _scaffold(name, target)


def _scaffold(name: str, target: Path):
    if target.exists():
        console.print(f"[red]Directory {target} already exists.[/red]")
        raise SystemExit(1)

    target.mkdir(parents=True)
    (target / "dataset").mkdir()
    (target / "output").mkdir()

    (target / "forge.yaml").write_text(FORGE_YAML_TEMPLATE.format(name=name))
    (target / "mission.md").write_text(MISSION_TEMPLATE.format(name=name))
    (target / "system_prompt.md").write_text(SYSTEM_PROMPT_TEMPLATE.format(name=name))
    (target / "BACKGROUND.md").write_text(BACKGROUND_TEMPLATE.format(name=name))

    # llm.txt — explains the project to any LLM starting fresh
    llm_txt_template = _TEMPLATES_DIR / "llm.txt"
    if llm_txt_template.exists():
        (target / "llm.txt").write_text(
            llm_txt_template.read_text().replace("{project_name}", name)
        )

    # Gitignore
    (target / ".gitignore").write_text(
        "output/\n!output/best_adapter/\n!output/best_score.json\n"
        "*.pyc\n__pycache__/\n.venv/\n"
    )

    # Empty dataset stubs
    (target / "dataset" / "seed.jsonl").write_text("")
    (target / "dataset" / "gold.jsonl").write_text("")
    (target / "dataset" / "canonical.jsonl").write_text("")

    # Pretrain corpus directory
    corpus_dir = target / "dataset" / "corpus"
    corpus_dir.mkdir()
    (corpus_dir / ".gitkeep").write_text("")

    # Probe questions stub (3 examples to guide the user)
    probe_stub = (
        '{"question": "What is the primary purpose of X?", "ideal": "The primary purpose of X is ..."}\n'
        '{"question": "How does Y work?", "ideal": "Y works by ..."}\n'
        '{"question": "What are the key properties of Z?", "ideal": "Z has the following properties: ..."}\n'
    )
    (target / "dataset" / "probe.jsonl").write_text(probe_stub)

    console.print(Panel(
        f"[green]✅ Project created:[/green] {target}\n\n"
        f"Next steps:\n"
        f"  1. Edit [bold]mission.md[/bold] — describe your task\n"
        f"  2. Edit [bold]system_prompt.md[/bold] — your model's system prompt\n"
        f"  3. Add seed examples to [bold]dataset/seed.jsonl[/bold]\n"
        f"  4. Add eval examples to [bold]dataset/gold.jsonl[/bold] (lock these!)\n"
        f"  5. [dim](Optional)[/dim] Add domain docs to [bold]dataset/corpus/[/bold] and edit [bold]dataset/probe.jsonl[/bold]\n"
        f"     then: [bold]forge probe --tag pre[/bold] → [bold]forge pretrain[/bold] → [bold]forge probe --tag post[/bold]\n"
        f"  6. Run [bold]forge flywheel[/bold]",
        title=f"forge init — {name}",
    ))


def _migrate(name: str, source: Path, target: Path):
    """Best-effort migration from an existing pipeline project."""
    console.print(f"[yellow]Migrating from {source} → {target}[/yellow]")
    target.mkdir(parents=True, exist_ok=True)
    (target / "dataset").mkdir(exist_ok=True)
    (target / "output").mkdir(exist_ok=True)

    # Copy source code
    src_dir = source / "src"
    if src_dir.exists():
        shutil.copytree(src_dir, target / "src", dirs_exist_ok=True)

    # Migrate task.yaml → forge.yaml
    task_yaml = source / "configs" / "task.yaml"
    if task_yaml.exists():
        import yaml
        with open(task_yaml) as f:
            old = yaml.safe_load(f)
        console.print("  [dim]Found task.yaml — converting to forge.yaml[/dim]")
        # Basic field mapping
        forge_cfg = {
            "name": name,
            "model": old.get("model", {}),
            "lora": old.get("lora", {}),
            "training": old.get("training", {}),
            "eval": old.get("eval", {}),
            "dataset": {
                "canonical": old.get("dataset", {}).get("train", "dataset/canonical.jsonl"),
                "gold": old.get("dataset", {}).get("eval", "dataset/gold.jsonl"),
            },
            "promotion": old.get("promotion", {}),
            "flywheel": old.get("flywheel", {}),
        }
        with open(target / "forge.yaml", "w") as f:
            yaml.dump(forge_cfg, f, default_flow_style=False)

    # Extract system prompt from train.py if present
    train_py = source / "src" / "train.py"
    if train_py.exists():
        text = train_py.read_text()
        import re
        m = re.search(r'SYSTEM_PROMPT\s*=\s*"""(.*?)"""', text, re.DOTALL)
        if m:
            (target / "system_prompt.md").write_text(m.group(1).strip())
            console.print("  [dim]Extracted system_prompt.md from train.py[/dim]")

    # Copy datasets
    for fname in ["canonical_v5.jsonl", "canonical_v4.jsonl", "canonical_v3_final.jsonl",
                  "gold_v5.jsonl", "gold_v4.jsonl"]:
        src_f = source / "src" / "dataset" / fname
        if src_f.exists():
            dest_name = "canonical.jsonl" if "canonical" in fname else "gold.jsonl"
            shutil.copy(src_f, target / "dataset" / dest_name)
            console.print(f"  [dim]Copied {fname} → dataset/{dest_name}[/dim]")
            break

    (target / "mission.md").write_text(MISSION_TEMPLATE.format(name=name))

    console.print(f"\n[green]✅ Migration complete → {target}[/green]")
    console.print("  Review forge.yaml and mission.md before running forge flywheel")
