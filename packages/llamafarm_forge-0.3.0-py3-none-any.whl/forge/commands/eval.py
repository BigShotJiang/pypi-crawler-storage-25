"""forge eval — evaluate adapter against dataset/gold.jsonl.

Runs the project's own src/eval.py using the project's .venv python
(so Unsloth / torch are available), streams output in real-time,
then renders a rich summary table from output/eval_results.json.
"""
from __future__ import annotations

import json
import subprocess
import sys
import time
from pathlib import Path

import click
from rich import box
from rich.console import Console
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn, TimeElapsedColumn
from rich.table import Table

from forge.core import config

console = Console()


def _resolve_python(project_dir: Path) -> str:
    """Return the python binary to use for running eval/train.

    Priority:
    1. project_dir/.venv/bin/python  — the project's own venv with Unsloth
    2. sys.executable                — the forge venv (fallback)
    """
    venv_python = project_dir / ".venv" / "bin" / "python"
    if venv_python.exists():
        return str(venv_python)
    return sys.executable


@click.command()
@click.option("--adapter", default=None,
              help="Path to adapter directory (default: output/adapter)")
@click.option("--project", "-p", default=None,
              help="Project directory (default: auto-discover from forge.yaml / cwd)")
def evaluate(adapter: str | None, project: str | None):
    """Evaluate the trained adapter against the gold eval set.

    \b
    Runs src/eval.py using the project's .venv python (for Unsloth/torch),
    streams output live, then shows a per-command accuracy table.

    Output is saved to output/eval_results.json by eval.py.

    Examples:
      forge eval
      forge eval --adapter output/best_adapter
      forge eval --project /path/to/project
    """
    project_dir = Path(project) if project else config.find_project_root()
    if not project_dir:
        console.print("[red]No forge.yaml found. Run `forge init` first, or cd into a project.[/red]")
        raise SystemExit(1)

    cfg = config.load(project_dir)
    name = cfg.get("name", project_dir.name)

    eval_script = project_dir / "src" / "eval.py"
    use_builtin = not eval_script.exists()

    # Resolve adapter path
    output_dir = project_dir / "output"
    if adapter:
        adapter_path = Path(adapter)
        if not adapter_path.is_absolute():
            adapter_path = project_dir / adapter_path
    else:
        adapter_path = output_dir / "adapter"

    if not adapter_path.exists():
        console.print(f"[red]Adapter not found at {adapter_path}[/red]")
        console.print("[dim]Run `forge train` first, or pass --adapter <path>[/dim]")
        raise SystemExit(1)

    # Resolve gold eval set path (for display only — eval.py reads its own config)
    gold_raw = cfg.get("dataset", {}).get("gold", "")
    gold_name = Path(gold_raw).name if gold_raw else "gold.jsonl"
    target_acc = cfg["eval"]["target_accuracy"]

    python_bin = _resolve_python(project_dir)
    using_venv = python_bin != sys.executable

    adapter_display = adapter_path.relative_to(project_dir) if adapter_path.is_relative_to(project_dir) else adapter_path
    runner_label = "forge built-in eval_runner" if use_builtin else f"project .venv ✅ ({python_bin})"

    console.print()
    console.print(Panel(
        f"[bold]{name}[/bold]\n"
        f"Adapter: [cyan]{adapter_display}[/cyan]\n"
        f"Gold set: [dim]{gold_name}[/dim]\n"
        f"Target accuracy: [yellow]{target_acc*100:.0f}%[/yellow]\n"
        f"Runner: [dim]{runner_label}[/dim]",
        title="forge eval",
        border_style="blue",
    ))

    start = time.time()
    results: dict = {}
    return_code = 0

    if use_builtin:
        console.print("[dim]No src/eval.py found — using forge built-in eval_runner[/dim]\n")
        try:
            from forge.core import eval_runner as _eval_runner
            results = _eval_runner.run(project_dir, cfg, adapter_path)
        except Exception as e:
            console.print(f"[red]❌ Eval failed: {e}[/red]")
            raise SystemExit(1)
    else:
        cmd = [python_bin, str(eval_script)]
        if adapter:
            cmd.append(str(adapter_path))

        console.print(f"[dim]$ {' '.join(cmd)}[/dim]\n")

        progress = Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            TimeElapsedColumn(),
            console=console,
            transient=False,
        )
        task = progress.add_task("Evaluating…", total=None)

        with progress:
            proc = subprocess.Popen(
                cmd,
                cwd=project_dir,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                bufsize=1,
            )
            assert proc.stdout is not None
            for line in proc.stdout:
                line = line.rstrip()
                if any(kw in line for kw in (
                    "accuracy", "Accuracy", "Correct", "RESULTS", "Running",
                    "Loading", "adapter", "Example", "%|", "it/s",
                )):
                    progress.update(task, description=line[:80])
                console.print(f"[dim]{line}[/dim]")
            proc.wait()
            return_code = proc.returncode

        if return_code != 0:
            console.print(f"[red]❌ Eval failed (exit {return_code})[/red]")
            raise SystemExit(return_code)

        results_file = output_dir / "eval_results.json"
        if results_file.exists():
            try:
                results = json.loads(results_file.read_text())
            except Exception:
                pass

    elapsed = (time.time() - start) / 60

    if results:
        _render_results_table(results, target_acc, elapsed)

    if results.get("safety_violations", 0) > 0:
        console.print("[red]🚨 Safety violations detected — adapter blocked from promotion[/red]")
        raise SystemExit(2)


def _render_results_table(results: dict, target_acc: float, elapsed: float) -> None:
    """Render a rich per-command accuracy table from eval_results.json."""
    accuracy = results.get("accuracy", 0.0)
    correct = results.get("correct", 0)
    total = results.get("total", 0)
    safety = results.get("safety_violations", 0)
    passed = results.get("passed", accuracy >= target_acc)
    per_cmd = results.get("per_cmd", {})

    if per_cmd:
        table = Table(title="Per-Command Accuracy", box=box.SIMPLE_HEAVY)
        table.add_column("Command", style="cyan")
        table.add_column("Correct", justify="right")
        table.add_column("Total", justify="right")
        table.add_column("Accuracy", justify="right")
        table.add_column("", width=20)

        for cmd in sorted(per_cmd.keys()):
            c = per_cmd[cmd].get("correct", 0)
            t = per_cmd[cmd].get("total", 0)
            pct = c / t if t > 0 else 0.0
            bar = "█" * int(pct * 20) + "░" * (20 - int(pct * 20))
            color = "green" if pct >= 0.9 else ("yellow" if pct >= 0.7 else "red")
            table.add_row(
                cmd,
                str(c),
                str(t),
                f"[{color}]{pct*100:.0f}%[/{color}]",
                f"[{color}]{bar}[/{color}]",
            )
        console.print()
        console.print(table)

    # Summary panel
    status_color = "green" if passed else "red"
    status_icon = "✅ PASSED" if passed else "❌ FAILED"
    acc_color = "green" if accuracy >= target_acc else "yellow"

    summary = (
        f"[bold]Accuracy:[/bold] [{acc_color}]{accuracy*100:.1f}%[/{acc_color}]  "
        f"(target {target_acc*100:.0f}%,  gap {(target_acc - accuracy)*100:.1f}pp)\n"
        f"[bold]Correct:[/bold] {correct}/{total}\n"
        f"[bold]Safety violations:[/bold] "
        f"{'[red]' + str(safety) + '[/red]' if safety else '[green]0[/green]'}\n"
        f"[bold]Elapsed:[/bold] {elapsed:.1f} min"
    )
    console.print(Panel(
        summary,
        title=f"[{status_color}]{status_icon}[/{status_color}]",
        border_style=status_color,
    ))
