"""forge patch — one-shot Claude call for a described failure pattern."""
from __future__ import annotations

import json
import os
import re
import sys
from datetime import datetime
from pathlib import Path

import click
from rich.console import Console
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn, TimeElapsedColumn

from forge.core import config

console = Console()


@click.command()
@click.argument("description")
@click.option("--n", default=20, show_default=True,
              help="Number of examples to generate")
@click.option("--project", "-p", default=None,
              help="Project directory (default: auto-discover from forge.yaml)")
def patch(description: str, n: int, project: str | None):
    """Generate targeted examples for a described failure pattern.

    \b
    Makes a one-shot Claude call asking it to generate N examples that
    specifically address the described failure. Writes results to
    dataset/patch_<timestamp>.jsonl (does NOT auto-append to canonical).

    Examples:
      forge patch "arm motors being confused with disarm"
      forge patch "set-yaw called with wrong heading math" --n 30
      forge patch "grounded takeoff requests not refusing correctly"
    """
    project_dir = Path(project) if project else config.find_project_root()
    if not project_dir:
        console.print("[red]No forge.yaml found. Run `forge init` first.[/red]")
        raise SystemExit(1)

    cfg = config.load(project_dir)
    name = cfg.get("name", project_dir.name)
    datagen_model = cfg["flywheel"]["datagen_model"]

    api_key = cfg.get("_anthropic_key") or os.environ.get("ANTHROPIC_API_KEY", "")
    if not api_key:
        console.print("[red]ANTHROPIC_API_KEY not set.[/red]")
        raise SystemExit(1)

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    dataset_dir = project_dir / "dataset"
    dataset_dir.mkdir(exist_ok=True)
    out_file = dataset_dir / f"patch_{timestamp}.jsonl"

    console.print()
    console.print(Panel(
        f"[bold]{name}[/bold]\n"
        f"Failure pattern: [cyan]{description}[/cyan]\n"
        f"Examples: [yellow]{n}[/yellow]\n"
        f"Model: [dim]{datagen_model}[/dim]\n"
        f"Output: [dim]{out_file.name}[/dim]",
        title="forge patch",
        border_style="blue",
    ))

    # Import datagen utilities from src/
    src_dir = project_dir / "src"
    if str(src_dir) not in sys.path:
        sys.path.insert(0, str(src_dir))

    try:
        import anthropic as _anthropic
        import datagen as _datagen
    except ImportError as e:
        console.print(f"[red]Import error: {e}[/red]")
        console.print("[dim]Ensure anthropic is installed: uv pip install anthropic[/dim]")
        raise SystemExit(1)

    client = _anthropic.Anthropic(api_key=api_key)

    focus_hint = f"""

PATCH REQUEST — targeted examples for this specific failure pattern:
"{description}"

Generate {n} examples that directly address this failure. 
Rules:
- Focus ONLY on examples that would correct the described confusion
- Include contrast pairs where appropriate (e.g. arm vs disarm examples together)
- Vary phrasing, state, and parameters
- Use "cmd" (NOT "command") as the JSON key
- Return a JSON array of {n} objects with "user", "assistant", and "state" fields
"""

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        TimeElapsedColumn(),
        console=console,
    ) as progress:
        task = progress.add_task("Calling Claude…", total=None)
        try:
            raw_examples = _datagen.call_claude(client, n, focus_hint=focus_hint)
            valid = [e for e in raw_examples if _datagen.validate_example(e)]
            progress.update(task, description=f"Got {len(raw_examples)} raw, {len(valid)} valid")
        except Exception as e:
            console.print(f"[red]Claude error: {e}[/red]")
            raise SystemExit(1)

    if not valid:
        console.print("[yellow]No valid examples generated.[/yellow]")
        raise SystemExit(1)

    # Write to patch file
    written = 0
    with open(out_file, "w") as f:
        for ex in valid:
            fmt = _datagen.format_example(ex)
            if fmt is not None:
                f.write(json.dumps(fmt) + "\n")
                written += 1

    console.print(Panel(
        f"[green]✅ Patch generated[/green]\n"
        f"Valid examples: [bold]{written}[/bold] / {n} requested\n"
        f"File: [cyan]{out_file}[/cyan]\n\n"
        f"[dim]To apply: append to dataset/canonical.jsonl then run `forge train`[/dim]",
        border_style="green",
    ))
