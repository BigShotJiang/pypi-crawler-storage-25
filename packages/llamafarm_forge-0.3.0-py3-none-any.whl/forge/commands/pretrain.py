"""forge pretrain — continued pretraining on a raw-text corpus."""
from __future__ import annotations

import json
import time
from datetime import datetime
from pathlib import Path

import click
from rich.console import Console
from rich.panel import Panel
from forge.core.corpus import build_corpus_dataset

console = Console()


@click.command("pretrain")
@click.option("--corpus", "corpus_dir", default=None, type=click.Path(),
              help="Path to corpus directory (overrides forge.yaml pretrain.corpus_dir).")
@click.option("--epochs", default=None, type=int,
              help="Number of pretraining epochs (overrides forge.yaml pretrain.epochs).")
@click.option("--output-adapter", "output_adapter", default=None, type=click.Path(),
              help="Where to save pretrain adapter (default: output/pretrain_adapter).")
@click.option("--merge/--no-merge", "do_merge", default=True,
              help="Merge LoRA into base weights after training (default: True). "
                   "Produces output/pretrain_merged/ ready for use as a fine-tune base.")
@click.option("--project", "-p", "project_path", default=".", type=click.Path(),
              help="Path to forge project directory.")
def pretrain(corpus_dir, epochs, output_adapter, do_merge, project_path):
    """Pretrain on raw-text corpus for domain knowledge acquisition.

    Trains a fresh LoRA adapter using causal LM loss (no chat template) on .txt,
    .md, or .jsonl files in the corpus directory. Optionally merges the adapter
    into base weights to produce a new base model for subsequent fine-tuning.

    \b
    Typical workflow:
        forge probe --tag pre              # baseline knowledge score
        forge pretrain                     # train on corpus, merge to pretrain_merged/
        forge probe --tag post \\
            --adapter output/pretrain_merged  # post-pretrain score
        forge probe --compare              # show delta

    Then update forge.yaml model.base to output/pretrain_merged/ and run forge flywheel.
    """
    from forge.core import config as _config
    project_dir = Path(project_path).resolve()
    cfg = _config.load(project_dir)

    pretrain_cfg = cfg.get("pretrain", {})

    # Resolve corpus dir
    resolved_corpus = Path(corpus_dir) if corpus_dir else \
        project_dir / pretrain_cfg.get("corpus_dir", "dataset/corpus")
    resolved_corpus = resolved_corpus if resolved_corpus.is_absolute() else \
        project_dir / resolved_corpus

    # Resolve output adapter path
    resolved_adapter = Path(output_adapter) if output_adapter else \
        project_dir / pretrain_cfg.get("output_adapter", "output/pretrain_adapter")

    # Training hyperparams (pretrain defaults differ from finetune)
    pt_epochs     = epochs or pretrain_cfg.get("epochs", 1)
    pt_lr         = pretrain_cfg.get("learning_rate", 2e-5)
    pt_batch      = pretrain_cfg.get("batch_size", cfg.get("training", {}).get("batch_size", 4))
    pt_grad_accum = pretrain_cfg.get("gradient_accumulation_steps",
                                     cfg.get("training", {}).get("gradient_accumulation_steps", 4))
    pt_max_seq    = pretrain_cfg.get("max_seq_len", cfg["model"].get("max_seq_len", 2048))
    model_id      = cfg["model"]["base"]
    load_in_4bit  = cfg["model"].get("load_in_4bit", True)
    lora_r        = cfg["lora"]["r"]
    lora_alpha    = cfg["lora"]["alpha"]
    lora_dropout  = cfg["lora"].get("dropout", 0.05)
    target_mods   = cfg["lora"]["target_modules"]
    seed          = cfg.get("training", {}).get("seed", 42)

    console.rule("[bold cyan]forge pretrain[/bold cyan]")
    console.print(f"  Model:      {model_id}")
    console.print(f"  Corpus dir: {resolved_corpus}")
    console.print(f"  Epochs:     {pt_epochs}")
    console.print(f"  LR:         {pt_lr}  (lower than fine-tune default)")
    console.print(f"  Output:     {resolved_adapter}")
    console.print(f"  Merge:      {'yes → output/pretrain_merged/' if do_merge else 'no'}")
    console.print()

    try:
        import torch
        from unsloth import FastLanguageModel  # type: ignore
        from trl import SFTConfig, SFTTrainer  # type: ignore
    except ImportError as e:
        raise click.ClickException(
            f"Training dependencies not installed: {e}\n"
            "Run: pip install slm-forge[train]"
        )

    start = time.time()

    # ── Load model (cold-start, never LoRA-on-LoRA) ───────────────────────────
    console.print("[cyan]Loading base model (cold-start)...[/cyan]")
    model, tokenizer = FastLanguageModel.from_pretrained(
        model_name=model_id,
        max_seq_length=pt_max_seq,
        load_in_4bit=load_in_4bit,
    )
    model = FastLanguageModel.get_peft_model(
        model,
        r=lora_r,
        target_modules=target_mods,
        lora_alpha=lora_alpha,
        lora_dropout=lora_dropout,
        bias="none",
        use_gradient_checkpointing="unsloth",
        random_state=seed,
    )

    # ── Build corpus dataset ──────────────────────────────────────────────────
    console.print("[cyan]Loading corpus...[/cyan]")
    dataset = build_corpus_dataset(resolved_corpus, tokenizer, max_seq_len=pt_max_seq)
    console.print(f"  {len(dataset)} chunks ready for training")

    # ── Train (causal LM — raw text, no chat template) ───────────────────────
    resolved_adapter.mkdir(parents=True, exist_ok=True)

    training_args = SFTConfig(
        output_dir=str(resolved_adapter),
        num_train_epochs=pt_epochs,
        per_device_train_batch_size=pt_batch,
        gradient_accumulation_steps=pt_grad_accum,
        learning_rate=pt_lr,
        warmup_ratio=0.05,
        weight_decay=0.01,
        lr_scheduler_type="cosine",
        fp16=not torch.cuda.is_bf16_supported() if torch.cuda.is_available() else False,
        bf16=torch.cuda.is_bf16_supported() if torch.cuda.is_available() else False,
        logging_steps=10,
        save_strategy="epoch",
        save_total_limit=1,
        dataset_text_field="text",
        max_seq_length=pt_max_seq,
        packing=True,
        report_to="none",
        seed=seed,
    )

    trainer = SFTTrainer(
        model=model,
        tokenizer=tokenizer,
        train_dataset=dataset,
        args=training_args,
    )

    console.print(f"[cyan]Training: {pt_epochs} epoch(s), "
                  f"batch={pt_batch}×{pt_grad_accum}={pt_batch*pt_grad_accum} effective[/cyan]")
    trainer.train()

    # Get final loss
    final_loss = 0.0
    if trainer.state.log_history:
        for entry in reversed(trainer.state.log_history):
            if "loss" in entry:
                final_loss = entry["loss"]
                break

    elapsed = round((time.time() - start) / 60, 1)
    console.print(f"\n✅ Pretraining complete: {pt_epochs} epoch(s) in {elapsed:.1f} min")
    console.print(f"   Final loss: {final_loss:.4f}")

    # ── Save adapter ──────────────────────────────────────────────────────────
    console.print(f"[cyan]Saving pretrain adapter to {resolved_adapter}[/cyan]")
    model.save_pretrained(str(resolved_adapter))
    tokenizer.save_pretrained(str(resolved_adapter))

    # ── Merge (recommended) ───────────────────────────────────────────────────
    merged_path = None
    if do_merge:
        merged_path = project_dir / "output" / "pretrain_merged"
        merged_path.mkdir(parents=True, exist_ok=True)
        console.print(f"[cyan]Merging LoRA into base weights → {merged_path}[/cyan]")
        console.print("  (Uses Unsloth save_pretrained_merged to avoid tokenizer breakage)")
        model.save_pretrained_merged(
            str(merged_path),
            tokenizer,
            save_method="merged_16bit",
        )
        console.print(f"  ✅ Merged model saved to {merged_path}")
        console.print()
        console.print(Panel(
            f"[bold]Next steps:[/bold]\n\n"
            f"1. Run post-pretrain probe:\n"
            f"   [cyan]forge probe --tag post --adapter {merged_path}[/cyan]\n\n"
            f"2. Compare pre/post knowledge:\n"
            f"   [cyan]forge probe --compare[/cyan]\n\n"
            f"3. Update forge.yaml to use merged model as new fine-tune base:\n"
            f"   [cyan]model:\\n  base: {merged_path}[/cyan]\n\n"
            f"4. Run task fine-tuning:\n"
            f"   [cyan]forge flywheel[/cyan]",
            title="Pretrain complete",
            border_style="green",
        ))

    # ── Write results ─────────────────────────────────────────────────────────
    corpus_files = [str(p) for p in sorted(Path(resolved_corpus).rglob("*"))
                    if p.is_file()]
    results = {
        "timestamp": datetime.now().strftime("%Y%m%d_%H%M%S"),
        "model": model_id,
        "corpus_dir": str(resolved_corpus),
        "corpus_files": corpus_files,
        "corpus_chunks": len(dataset),
        "epochs": pt_epochs,
        "learning_rate": pt_lr,
        "final_loss": round(final_loss, 4),
        "elapsed_min": elapsed,
        "adapter_path": str(resolved_adapter),
        "merged_path": str(merged_path) if merged_path else None,
    }
    results_path = project_dir / "output" / "pretrain_results.json"
    results_path.write_text(json.dumps(results, indent=2))
    console.print(f"Results saved to {results_path}")
    return results
