"""forge generate — powerful synthetic dataset generation via batched Claude calls."""
from __future__ import annotations

import asyncio
import json
import os
import time
from pathlib import Path
from typing import Any

import click
from rich.console import Console
from rich.panel import Panel
from rich.progress import (
    BarColumn,
    MofNCompleteColumn,
    Progress,
    SpinnerColumn,
    TaskProgressColumn,
    TextColumn,
    TimeElapsedColumn,
)

from forge.core import config

console = Console()


# ---------------------------------------------------------------------------
# Prompt builder
# ---------------------------------------------------------------------------

def _build_prompt(
    batch_size: int,
    batch_num: int,
    total_batches: int,
    background: str,
    system_prompt: str,
    mission: str,
    agent_context_tail: str,
) -> str:
    return f"""You are generating diverse, high-quality training data for a fine-tuned language model.

[BACKGROUND — read carefully, this defines what correct output looks like]
{background}

[SYSTEM PROMPT — exactly what the model sees at inference]
{system_prompt}

[TASK DESCRIPTION]
{mission}

[RECENT TRAINING HISTORY]
{agent_context_tail}

Generate {batch_size} training examples as a JSON array.
Each element: {{"user": "<input>", "assistant": "<valid output>"}}

Requirements:
- Cover ALL categories and difficulty levels described in BACKGROUND.md
- Vary phrasing heavily (formal, informal, abbreviated, verbose)
- Include edge cases explicitly listed in BACKGROUND.md
- Assistant output must be valid JSON matching the exact format in BACKGROUND.md
- Do NOT repeat examples from previous batches
- Return ONLY the JSON array, no prose, no markdown fences

Batch {batch_num} of {total_batches} — focus on variety, not seen in earlier batches."""


# ---------------------------------------------------------------------------
# Async batch generator
# ---------------------------------------------------------------------------

async def _generate_batch(
    client: Any,
    model: str,
    batch_size: int,
    batch_num: int,
    total_batches: int,
    background: str,
    system_prompt: str,
    mission: str,
    agent_context_tail: str,
) -> list[dict]:
    """Fire a single async Claude call and return raw parsed examples."""
    prompt = _build_prompt(
        batch_size=batch_size,
        batch_num=batch_num,
        total_batches=total_batches,
        background=background,
        system_prompt=system_prompt,
        mission=mission,
        agent_context_tail=agent_context_tail,
    )

    response = await client.messages.create(
        model=model,
        max_tokens=8192,
        messages=[{"role": "user", "content": prompt}],
    )

    text = response.content[0].text.strip()
    # Strip optional markdown fences
    if text.startswith("```"):
        text = text.split("\n", 1)[1] if "\n" in text else text[3:]
        if text.endswith("```"):
            text = text[:-3]
        text = text.strip()

    try:
        parsed = json.loads(text)
    except json.JSONDecodeError:
        return []

    if not isinstance(parsed, list):
        return []
    return parsed


# ---------------------------------------------------------------------------
# Core generation logic (testable)
# ---------------------------------------------------------------------------

async def run_generate(
    project_dir: Path,
    cfg: dict,
    n: int,
    batch_size: int,
    output_path: Path,
) -> dict:
    """Run the full generation pipeline. Returns stats dict."""
    import anthropic as _anthropic

    api_key = cfg.get("_anthropic_key") or os.environ.get("ANTHROPIC_API_KEY", "")
    model = cfg["flywheel"]["datagen_model"]

    # Load context files
    background = _read_file(project_dir / "BACKGROUND.md", default="No BACKGROUND.md found.")
    system_prompt = _read_file(project_dir / "system_prompt.md", default="")
    mission = _read_file(project_dir / "mission.md", default="")
    agent_ctx_full = _read_file(project_dir / "AGENT_CONTEXT.md", default="")
    agent_context_tail = agent_ctx_full[-3000:] if len(agent_ctx_full) > 3000 else agent_ctx_full

    # Load existing user strings for dedup
    seen_users: set[str] = set()
    if output_path.exists():
        for line in output_path.read_text().splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                ex = json.loads(line)
                msgs = ex.get("messages", [])
                for m in msgs:
                    if m.get("role") == "user":
                        seen_users.add(m["content"])
            except (json.JSONDecodeError, AttributeError):
                pass

    total_batches = max(1, (n + batch_size - 1) // batch_size)

    client = _anthropic.AsyncAnthropic(api_key=api_key)

    stats = {
        "n_requested": n,
        "n_generated": 0,
        "n_valid": 0,
        "n_dupes": 0,
        "n_appended": 0,
        "model": model,
    }

    output_path.parent.mkdir(parents=True, exist_ok=True)

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        BarColumn(),
        MofNCompleteColumn(),
        TaskProgressColumn(),
        TimeElapsedColumn(),
        console=console,
        transient=False,
    ) as progress:
        batch_task = progress.add_task("Batches", total=total_batches)
        valid_task = progress.add_task("[green]Valid", total=n)
        dupe_task = progress.add_task("[yellow]Dupes", total=None)

        for batch_num in range(1, total_batches + 1):
            remaining = n - stats["n_appended"]
            current_batch_size = min(batch_size, remaining) if remaining > 0 else batch_size

            raw_examples = await _generate_batch(
                client=client,
                model=model,
                batch_size=current_batch_size,
                batch_num=batch_num,
                total_batches=total_batches,
                background=background,
                system_prompt=system_prompt,
                mission=mission,
                agent_context_tail=agent_context_tail,
            )

            stats["n_generated"] += len(raw_examples)

            # Validate + dedup + append
            appended_this_batch = 0
            with open(output_path, "a") as f:
                for ex in raw_examples:
                    user = ex.get("user", "")
                    assistant = ex.get("assistant", "")

                    # Validate: user must be non-empty string
                    if not isinstance(user, str) or not user.strip():
                        continue

                    # Validate: assistant must be valid JSON
                    if not isinstance(assistant, str):
                        continue
                    try:
                        json.loads(assistant)
                    except (json.JSONDecodeError, ValueError):
                        continue

                    # Dedup
                    if user in seen_users:
                        stats["n_dupes"] += 1
                        progress.advance(dupe_task)
                        continue

                    seen_users.add(user)
                    stats["n_valid"] += 1

                    # Write in messages format
                    record = {
                        "messages": [
                            {"role": "user", "content": user},
                            {"role": "assistant", "content": assistant},
                        ]
                    }
                    f.write(json.dumps(record) + "\n")
                    appended_this_batch += 1
                    stats["n_appended"] += 1
                    progress.advance(valid_task)

            progress.advance(batch_task)
            progress.update(
                batch_task,
                description=f"Batches ({stats['n_appended']} appended, {stats['n_dupes']} dupes)",
            )

            # Stop early if we have enough
            if stats["n_appended"] >= n:
                break

    return stats


# ---------------------------------------------------------------------------
# CLI command
# ---------------------------------------------------------------------------

@click.command()
@click.option("--n", default=500, show_default=True, help="Total examples to generate")
@click.option("--batch-size", default=50, show_default=True, help="Examples per Claude API call")
@click.option("--output", default=None, help="Output JSONL file (default: dataset/canonical.jsonl)")
@click.option("--project", "-p", default=None, help="Project directory (default: auto-discover)")
def generate(n: int, batch_size: int, output: str | None, project: str | None):
    """Generate synthetic training data via batched Claude calls.

    \b
    Fires N/batch_size parallel async API calls, validates each example
    (assistant must be valid JSON, user must be non-empty), deduplicates
    against existing canonical.jsonl, then appends valid examples.

    Examples:
      forge generate
      forge generate --n 200 --batch-size 25
      forge generate --n 1000 --output dataset/my_data.jsonl
    """
    project_dir = Path(project) if project else config.find_project_root()
    if not project_dir:
        console.print("[red]No forge.yaml found. Run `forge init` first.[/red]")
        raise SystemExit(1)

    cfg = config.load(project_dir)
    name = cfg.get("name", project_dir.name)

    api_key = cfg.get("_anthropic_key") or os.environ.get("ANTHROPIC_API_KEY", "")
    if not api_key:
        console.print("[red]ANTHROPIC_API_KEY not set.[/red]")
        raise SystemExit(1)

    output_path = Path(output) if output else None
    if output_path is None:
        canonical_rel = cfg.get("dataset", {}).get("canonical", "dataset/canonical.jsonl")
        output_path = project_dir / canonical_rel
    elif not output_path.is_absolute():
        output_path = project_dir / output_path

    model = cfg["flywheel"]["datagen_model"]
    total_batches = max(1, (n + batch_size - 1) // batch_size)

    console.print()
    console.print(Panel(
        f"[bold]{name}[/bold]\n"
        f"Generating: [yellow]{n}[/yellow] examples  "
        f"(batch_size=[cyan]{batch_size}[/cyan], {total_batches} batches)\n"
        f"Model: [dim]{model}[/dim]\n"
        f"Output: [dim]{output_path}[/dim]",
        title="forge generate",
        border_style="blue",
    ))

    t0 = time.time()
    stats = asyncio.run(
        run_generate(
            project_dir=project_dir,
            cfg=cfg,
            n=n,
            batch_size=batch_size,
            output_path=output_path,
        )
    )
    elapsed = time.time() - t0

    console.print()
    console.print(Panel(
        f"[green]✅ Generation complete[/green]\n\n"
        f"Requested:  [bold]{stats['n_requested']}[/bold]\n"
        f"Generated:  [bold]{stats['n_generated']}[/bold]\n"
        f"Valid:      [green bold]{stats['n_valid']}[/green bold]\n"
        f"Dupes:      [yellow]{stats['n_dupes']}[/yellow]\n"
        f"Appended:   [green bold]{stats['n_appended']}[/green bold]\n"
        f"Model:      [dim]{stats['model']}[/dim]\n"
        f"Elapsed:    [dim]{elapsed:.1f}s[/dim]",
        title="Results",
        border_style="green",
    ))


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _read_file(path: Path, default: str = "") -> str:
    if path.exists():
        return path.read_text()
    return default
