"""forge batch-generate — generate training examples via the Batches API.

50% cheaper than sequential. Submits all N requests at once, waits for
completion (~1h for large batches, <5min for 500), validates, retries failures.

Key use case:
  "I have 5 gold seed examples. Generate 500 variations that follow the same
   schema and style, but cover different scenarios and edge cases."

The seed examples provide few-shot context in every generation request,
ensuring stylistic consistency while the variation hint drives diversity.
"""
from __future__ import annotations

import json
import os
import sys
from pathlib import Path

import click
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from forge.core import config

console = Console()


@click.command()
@click.option("--category", "-c", required=True,
              help="Category name (used as label in output + retry tracking)")
@click.option("--description", "-d", default="",
              help="Category description for the generator (what to vary, rules, etc.)")
@click.option("--n", default=500, show_default=True,
              help="Number of examples to generate")
@click.option("--seeds", default=None,
              help="Path to JSONL file of seed examples (3-5 hand-crafted gold examples)")
@click.option("--out", required=True,
              help="Output JSONL path (appended to if exists)")
@click.option("--model", default="claude-sonnet-4-6", show_default=True,
              help="Generator model")
@click.option("--retries", default=2, show_default=True,
              help="Max validation retry passes")
@click.option("--system-context", default=None,
              help="Path to system context file (e.g., SYSTEM_PROMPT.txt) — injected into every prompt")
@click.option("--extra", default="",
              help="Extra instructions appended to every generation prompt")
@click.option("--validator", default=None,
              help="Python module path for custom validator fn, e.g. scripts.validate:validate_example")
@click.option("--dry-run", is_flag=True,
              help="Show plan + sample prompt without submitting")
@click.option("--project", "-p", default=None,
              help="Project directory (default: auto-discover from forge.yaml)")
def batch_generate(
    category: str,
    description: str,
    n: int,
    seeds: str | None,
    out: str,
    model: str,
    retries: int,
    system_context: str | None,
    extra: str,
    validator: str | None,
    dry_run: bool,
    project: str | None,
):
    """Generate N training examples via the Batches API.

    \b
    Key features:
      - 50% cost vs sequential (batch pricing)
      - Prompt caching on generation system + context (1h TTL)
      - Seed examples as few-shot context for consistent style
      - Automatic retry loop: validate → batch-retry only failures
      - Clean for targeted augmentation: "500 more scan_routine examples"

    \b
    Examples:
      forge batch-generate \\
        --category scan_routine \\
        --description "Routine scan, CONTINUE_TASK, 5 numbered think steps" \\
        --n 500 \\
        --seeds examples/seed_scan.jsonl \\
        --system-context docs/SYSTEM_PROMPT.txt \\
        --out data/raw/batch_scan.jsonl

      forge batch-generate -c engage_terminal_hold -n 200 --out data/raw/engage.jsonl

      forge batch-generate -c scan_routine -n 500 --dry-run  # preview prompt
    """
    project_dir = Path(project) if project else config.find_project_root()
    cfg = config.load(project_dir) if project_dir else {}

    # ── Resolve API key ───────────────────────────────────────────────────────
    api_key = os.environ.get("ANTHROPIC_API_KEY", "")
    if not api_key and project_dir:
        env_path = project_dir / ".env"
        if not env_path.exists():
            env_path = Path("/mnt/nvmera/home/robert/llamadrone-mission-router/.env")
        if env_path.exists():
            for line in env_path.read_text().splitlines():
                if line.startswith("ANTHROPIC_API_KEY="):
                    api_key = line.split("=", 1)[1].strip()
    if not api_key and not dry_run:
        console.print("[red]ANTHROPIC_API_KEY not found.[/red]")
        raise SystemExit(1)

    # ── Load seed examples ────────────────────────────────────────────────────
    seed_examples = []
    if seeds:
        seeds_path = Path(seeds)
        if not seeds_path.is_absolute() and project_dir:
            seeds_path = project_dir / seeds_path
        if seeds_path.exists():
            seed_examples = [
                json.loads(l) for l in seeds_path.read_text().splitlines() if l.strip()
            ]
            console.print(f"  Seed examples: {len(seed_examples)} from {seeds_path}")
        else:
            console.print(f"[yellow]Seeds file not found: {seeds_path}[/yellow]")

    # ── Load system context ───────────────────────────────────────────────────
    system_ctx = ""
    if system_context:
        ctx_path = Path(system_context)
        if not ctx_path.is_absolute() and project_dir:
            ctx_path = project_dir / ctx_path
        if ctx_path.exists():
            system_ctx = ctx_path.read_text().strip()
            console.print(f"  System context: {len(system_ctx)} chars from {ctx_path}")

    # ── Load generation system prompt ─────────────────────────────────────────
    # Try project's generation_system.md, then fall back to generic
    gen_system = _load_generation_system(project_dir, cfg)

    # ── Load validator ────────────────────────────────────────────────────────
    validate_fn = None
    if validator:
        try:
            module_path, fn_name = validator.rsplit(":", 1)
            import importlib.util
            spec_mod = importlib.util.spec_from_file_location(
                "validator_mod",
                project_dir / module_path.replace(".", "/").replace("/py", ".py")
                if project_dir else Path(module_path),
            )
            mod = importlib.util.module_from_spec(spec_mod)
            spec_mod.loader.exec_module(mod)
            validate_fn = getattr(mod, fn_name)
            console.print(f"  Validator: {validator}")
        except Exception as e:
            console.print(f"[yellow]Could not load validator '{validator}': {e}[/yellow]")

    # ── Build spec ────────────────────────────────────────────────────────────
    from forge.core.batch_datagen import BatchDatagen, GenerationSpec

    spec = GenerationSpec(
        category=category,
        description=description or f"Generate diverse {category} training examples",
        n=n,
        generation_system=gen_system,
        system_context=system_ctx,
        seed_examples=seed_examples,
        extra_instructions=extra,
        max_retries=retries,
    )

    # ── Dry run ───────────────────────────────────────────────────────────────
    if dry_run:
        gen = BatchDatagen(api_key="dry-run", model=model, verbose=False)
        sample_prompt = gen._build_prompt(spec, attempt=0, idx=0)

        # Cost estimate
        est_prompt_tokens  = len(gen_system.split()) * 1.3 + len(sample_prompt.split()) * 1.3
        est_output_tokens  = 350  # typical example
        est_total_input    = est_prompt_tokens * n
        est_cache_savings  = len(gen_system.split()) * 1.3 * (n - 1)  # hits after first
        est_cost_no_cache  = (est_total_input / 1e6) * 1.50   # sonnet batch price
        est_cost_cached    = ((est_total_input - est_cache_savings) / 1e6) * 1.50
        est_output_cost    = (est_output_tokens * n / 1e6) * 7.50

        console.print(Panel(
            f"[bold yellow]DRY RUN — nothing submitted[/bold yellow]\n\n"
            f"Category:    [cyan]{category}[/cyan]\n"
            f"Requested:   [cyan]{n}[/cyan] examples\n"
            f"Model:       [cyan]{model}[/cyan]\n"
            f"Seeds:       [cyan]{len(seed_examples)}[/cyan]\n"
            f"Retries:     [cyan]{retries}[/cyan] passes\n"
            f"Output:      [dim]{out}[/dim]\n\n"
            f"[bold]Cost estimate (Batches API, 50% discount):[/bold]\n"
            f"  Input (no cache):  ${est_cost_no_cache:.3f}\n"
            f"  Input (cached):    ${est_cost_cached:.3f}  ← after 1st request\n"
            f"  Output:            ${est_output_cost:.3f}\n"
            f"  Total (cached):    [green]${est_cost_cached + est_output_cost:.3f}[/green]\n\n"
            f"[bold]Sample prompt (first 600 chars):[/bold]\n"
            f"[dim]{sample_prompt[:600]}...[/dim]",
            title="forge batch-generate --dry-run",
            border_style="yellow",
        ))
        return

    # ── Run ───────────────────────────────────────────────────────────────────
    out_path = Path(out)
    if not out_path.is_absolute() and project_dir:
        out_path = project_dir / out_path
    out_path.parent.mkdir(parents=True, exist_ok=True)

    gen = BatchDatagen(api_key=api_key, model=model)

    console.print(Panel(
        f"[bold]forge batch-generate[/bold]\n"
        f"Category:  [cyan]{category}[/cyan]\n"
        f"Requested: [cyan]{n}[/cyan] examples\n"
        f"Model:     [cyan]{model}[/cyan]\n"
        f"Seeds:     [cyan]{len(seed_examples)}[/cyan]\n"
        f"Output:    [dim]{out_path}[/dim]",
        border_style="blue",
    ))

    result = gen.generate(spec, validator=validate_fn, output_path=out_path)

    # ── Report ────────────────────────────────────────────────────────────────
    table = Table(title="Results")
    table.add_column("Metric", style="bold")
    table.add_column("Value")
    table.add_row("Requested",  str(result.n_requested))
    table.add_row("Generated",  f"[green]{result.n_generated}[/green]")
    table.add_row("Failed",     f"[{'red' if result.n_failed else 'dim'}]{result.n_failed}[/]")
    table.add_row("Passes",     str(result.passes))
    table.add_row("Batch IDs",  ", ".join(result.batch_ids))
    table.add_row("Output",     str(out_path))
    console.print(table)

    if result.n_failed > 0:
        console.print(
            f"[yellow]{result.n_failed} examples failed after {retries} retries.[/yellow]\n"
            f"[dim]Check batch IDs above in Anthropic console for details.[/dim]"
        )

    fill_rate = result.n_generated / result.n_requested * 100 if result.n_requested else 0
    if fill_rate < 90:
        console.print(
            f"[yellow]Fill rate {fill_rate:.0f}% < 90% — consider increasing --retries "
            f"or improving --description.[/yellow]"
        )
    else:
        console.print(f"[green]✅ Fill rate: {fill_rate:.1f}%[/green]")


def _load_generation_system(project_dir: Path | None, cfg: dict) -> str:
    """Load generation system prompt. Priority:
    1. project_dir/generation_system.md
    2. project_dir/BACKGROUND.md (generic forge layout)
    3. Built-in generic prompt
    """
    if project_dir:
        for fname in ("generation_system.md", "generation_system.txt",
                      "docs/generation_system.md", "BACKGROUND.md"):
            p = project_dir / fname
            if p.exists():
                return p.read_text().strip()

    return _GENERIC_GENERATION_SYSTEM


_GENERIC_GENERATION_SYSTEM = """\
You are an expert SFT dataset author.

Your job is to generate high-quality, diverse training examples for a fine-tuned language model.

RULES:
1. Each example must strictly follow the requested schema
2. Vary the scenario, state values, and edge cases — do NOT copy seed examples
3. The "system" field must be the domain system prompt VERBATIM (if provided)
4. Keep responses concise and factually correct for the domain
5. Return ONLY a JSON object with keys: system, user, assistant
   No markdown, no explanation, no code fences. Just: {"system":"...","user":"...","assistant":"..."}
"""
