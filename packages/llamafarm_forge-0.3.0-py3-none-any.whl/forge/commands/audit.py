"""forge audit — dataset quality auditing via Claude Sonnet."""
from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any

import click
from rich.console import Console
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn, TimeElapsedColumn
from rich.table import Table

from forge.core import config

console = Console()

AUDIT_BATCH_SIZE = 20


# ---------------------------------------------------------------------------
# Prompt builders
# ---------------------------------------------------------------------------

def _build_audit_prompt(
    examples: list[dict],
    background: str,
    system_prompt: str,
) -> str:
    examples_json = json.dumps(
        [{"index": ex["index"], "user": ex["user"], "assistant": ex["assistant"]} for ex in examples],
        indent=2,
    )
    n = len(examples)
    return f"""You are auditing training data for a fine-tuned language model.

[BACKGROUND — the ground truth for what correct output looks like]
{background}

[SYSTEM PROMPT]
{system_prompt}

Audit these {n} training examples. For each:
1. FORMAT: does the assistant output match the required JSON format exactly?
2. CORRECT: is the answer factually/mathematically correct?
3. CONSISTENT: is the question reasonable given the system prompt context?
4. QUALITY: is the user input realistic and natural?

Examples to audit:
{examples_json}

Return a JSON array with one object per example:
[{{"index": N, "format_ok": bool, "correct": bool, "consistent": bool, \
"quality": "good|ok|poor", "issue": "description or null", \
"severity": "error|warning|info|ok", "suggested_fix": "corrected assistant output or null"}}]

Return ONLY the JSON array."""


# ---------------------------------------------------------------------------
# Core audit logic (testable)
# ---------------------------------------------------------------------------

def _load_examples(file_path: Path) -> list[dict]:
    """Load JSONL examples into flat {index, user, assistant} dicts."""
    examples = []
    for i, line in enumerate(file_path.read_text().splitlines()):
        line = line.strip()
        if not line:
            continue
        try:
            record = json.loads(line)
        except json.JSONDecodeError:
            continue
        msgs = record.get("messages", [])
        user = next((m["content"] for m in msgs if m.get("role") == "user"), "")
        assistant = next((m["content"] for m in msgs if m.get("role") == "assistant"), "")
        examples.append({"index": i, "user": user, "assistant": assistant})
    return examples


def _call_audit_batch(
    client: Any,
    model: str,
    examples: list[dict],
    background: str,
    system_prompt: str,
) -> list[dict]:
    """Send one audit batch to Claude; return parsed results."""
    prompt = _build_audit_prompt(examples, background, system_prompt)
    response = client.messages.create(
        model=model,
        max_tokens=4096,
        messages=[{"role": "user", "content": prompt}],
    )
    text = response.content[0].text.strip()
    # Strip markdown fences
    if text.startswith("```"):
        text = text.split("\n", 1)[1] if "\n" in text else text[3:]
        if text.endswith("```"):
            text = text[:-3]
        text = text.strip()
    try:
        results = json.loads(text)
    except json.JSONDecodeError:
        # Fallback: mark all as info
        results = [
            {
                "index": ex["index"],
                "format_ok": True,
                "correct": True,
                "consistent": True,
                "quality": "ok",
                "issue": "Claude response unparseable",
                "severity": "info",
                "suggested_fix": None,
            }
            for ex in examples
        ]
    if not isinstance(results, list):
        results = []
    return results


def _fix_example(
    client: Any,
    model: str,
    example: dict,
    result: dict,
    background: str,
    system_prompt: str,
) -> str | None:
    """Ask Claude to regenerate a single broken example. Returns fixed assistant output."""
    prompt = (
        f"Fix this training example so the assistant output is correct.\n\n"
        f"[BACKGROUND]\n{background}\n\n"
        f"[SYSTEM PROMPT]\n{system_prompt}\n\n"
        f"User input: {example['user']}\n"
        f"Current assistant output: {example['assistant']}\n"
        f"Issue: {result.get('issue', '')}\n\n"
        f"Return ONLY the corrected assistant output (valid JSON string), nothing else."
    )
    response = client.messages.create(
        model=model,
        max_tokens=512,
        messages=[{"role": "user", "content": prompt}],
    )
    return response.content[0].text.strip()


def run_audit(
    project_dir: Path,
    cfg: dict,
    file_path: Path,
    fix: bool = False,
    output_report: Path | None = None,
) -> dict:
    """Run the full audit pipeline. Returns stats + results list."""
    import anthropic as _anthropic

    api_key = cfg.get("_anthropic_key") or os.environ.get("ANTHROPIC_API_KEY", "")
    model = cfg["flywheel"]["datagen_model"]

    background_path = project_dir / "BACKGROUND.md"
    if background_path.exists():
        background = background_path.read_text()
    else:
        background = "(No BACKGROUND.md found — format/correctness rules unavailable)"

    system_prompt = _read_file(project_dir / "system_prompt.md")

    examples = _load_examples(file_path)
    client = _anthropic.Anthropic(api_key=api_key)

    all_results: list[dict] = []

    total_batches = max(1, (len(examples) + AUDIT_BATCH_SIZE - 1) // AUDIT_BATCH_SIZE)

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        TimeElapsedColumn(),
        console=console,
        transient=True,
    ) as progress:
        task = progress.add_task(f"Auditing {len(examples)} examples…", total=total_batches)

        for batch_start in range(0, len(examples), AUDIT_BATCH_SIZE):
            batch = examples[batch_start : batch_start + AUDIT_BATCH_SIZE]
            results = _call_audit_batch(client, model, batch, background, system_prompt)
            all_results.extend(results)
            progress.advance(task)

    # Build index → result map for quick lookup
    result_map = {r["index"]: r for r in all_results}

    # --fix: replace error examples with suggested_fix or re-ask Claude
    if fix:
        # Load raw lines for in-place replacement
        lines = [l for l in file_path.read_text().splitlines() if l.strip()]
        modified = False

        for ex in examples:
            r = result_map.get(ex["index"])
            if r is None:
                continue
            if r.get("severity") != "error":
                continue

            fixed_output = r.get("suggested_fix")
            if not fixed_output:
                fixed_output = _fix_example(client, model, ex, r, background, system_prompt)

            if fixed_output:
                # Validate the fix is JSON
                try:
                    json.loads(fixed_output)
                except (json.JSONDecodeError, ValueError):
                    continue

                # Replace the line
                record = {
                    "messages": [
                        {"role": "user", "content": ex["user"]},
                        {"role": "assistant", "content": fixed_output},
                    ]
                }
                if ex["index"] < len(lines):
                    lines[ex["index"]] = json.dumps(record)
                    r["fixed"] = True
                    r["fixed_output"] = fixed_output
                    modified = True

        if modified:
            file_path.write_text("\n".join(lines) + "\n")

    # Stats
    errors = sum(1 for r in all_results if r.get("severity") == "error")
    warnings = sum(1 for r in all_results if r.get("severity") == "warning")
    total = len(examples)
    passed = sum(1 for r in all_results if r.get("severity") in ("ok", "info"))
    pass_rate = passed / total if total > 0 else 0.0

    stats = {
        "total": total,
        "errors": errors,
        "warnings": warnings,
        "passed": passed,
        "pass_rate": pass_rate,
        "model": model,
        "file": str(file_path),
    }

    # Rich table
    _render_table(all_results, examples)

    # Summary panel
    color = "green" if errors == 0 else ("yellow" if errors < total * 0.1 else "red")
    console.print()
    console.print(Panel(
        f"Total examples:  [bold]{total}[/bold]\n"
        f"Errors:          [{color}]{errors}[/{color}]\n"
        f"Warnings:        [yellow]{warnings}[/yellow]\n"
        f"Pass rate:       [bold]{pass_rate*100:.1f}%[/bold]",
        title="Audit Summary",
        border_style=color,
    ))

    # Write report
    report = {"stats": stats, "results": all_results}
    if output_report:
        output_report.parent.mkdir(parents=True, exist_ok=True)
        output_report.write_text(json.dumps(report, indent=2))
        console.print(f"[dim]Report saved to {output_report}[/dim]")

    return report


def _render_table(results: list[dict], examples: list[dict]) -> None:
    """Print a Rich table of per-example audit results."""
    ex_map = {ex["index"]: ex for ex in examples}

    table = Table(show_header=True, header_style="bold", box=None, padding=(0, 1))
    table.add_column("#", style="dim", width=5)
    table.add_column("Fmt", width=4)
    table.add_column("OK", width=4)
    table.add_column("Con", width=4)
    table.add_column("Qual", width=6)
    table.add_column("Sev", width=8)
    table.add_column("Issue", overflow="fold")

    for r in results:
        sev = r.get("severity", "ok")
        row_style = ""
        if sev == "error":
            row_style = "red"
        elif sev == "warning":
            row_style = "yellow"
        else:
            row_style = "green"

        table.add_row(
            str(r.get("index", "?")),
            "✓" if r.get("format_ok") else "✗",
            "✓" if r.get("correct") else "✗",
            "✓" if r.get("consistent") else "✗",
            r.get("quality", "?"),
            f"[{row_style}]{sev}[/{row_style}]",
            r.get("issue") or "",
        )

    console.print(table)


# ---------------------------------------------------------------------------
# CLI command
# ---------------------------------------------------------------------------

@click.command()
@click.option("--file", "file_opt", default=None,
              help="Dataset file to audit (default: dataset/canonical.jsonl)")
@click.option("--gold", is_flag=True, default=False,
              help="Audit the gold.jsonl dataset instead")
@click.option("--fix", is_flag=True, default=False,
              help="Auto-fix error-severity examples with Claude")
@click.option("--output", default=None,
              help="Save full audit report as JSON (e.g. audit_report.json)")
@click.option("--project", "-p", default=None,
              help="Project directory (default: auto-discover)")
def audit(
    file_opt: str | None,
    gold: bool,
    fix: bool,
    output: str | None,
    project: str | None,
):
    """Audit a training dataset for format, correctness, and quality.

    \b
    Sends examples in batches of 20 to Claude Sonnet, which checks:
    - FORMAT: does assistant output match the expected format?
    - CORRECTNESS: is the answer actually correct?
    - CONSISTENCY: is the question answerable from system_prompt context?
    - QUALITY: is the user turn realistic and natural?

    Examples:
      forge audit
      forge audit --gold
      forge audit --fix --output audit_report.json
      forge audit --file dataset/extra.jsonl
    """
    project_dir = Path(project) if project else config.find_project_root()
    if not project_dir:
        console.print("[red]No forge.yaml found. Run `forge init` first.[/red]")
        raise SystemExit(1)

    cfg = config.load(project_dir)

    api_key = cfg.get("_anthropic_key") or os.environ.get("ANTHROPIC_API_KEY", "")
    if not api_key:
        console.print("[red]ANTHROPIC_API_KEY not set.[/red]")
        raise SystemExit(1)

    # Resolve file path
    if file_opt:
        file_path = Path(file_opt)
        if not file_path.is_absolute():
            file_path = project_dir / file_path
    elif gold:
        gold_rel = cfg.get("dataset", {}).get("gold", "dataset/gold.jsonl")
        file_path = project_dir / gold_rel
    else:
        canonical_rel = cfg.get("dataset", {}).get("canonical", "dataset/canonical.jsonl")
        file_path = project_dir / canonical_rel

    if not file_path.exists():
        console.print(f"[red]Dataset file not found: {file_path}[/red]")
        raise SystemExit(1)

    output_path = None
    if output:
        p = Path(output)
        output_path = p if p.is_absolute() else project_dir / p

    console.print()
    console.print(Panel(
        f"File: [dim]{file_path}[/dim]\n"
        f"Fix errors: [{'green' if fix else 'dim'}]{fix}[/{'green' if fix else 'dim'}]\n"
        f"Report: [dim]{output_path or 'none'}[/dim]",
        title="forge audit",
        border_style="blue",
    ))

    run_audit(
        project_dir=project_dir,
        cfg=cfg,
        file_path=file_path,
        fix=fix,
        output_report=output_path,
    )


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _read_file(path: Path, default: str = "") -> str:
    if path.exists():
        return path.read_text()
    return default
