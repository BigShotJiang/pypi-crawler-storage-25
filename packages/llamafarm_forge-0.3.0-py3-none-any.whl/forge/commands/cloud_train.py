"""forge cloud-train — spawn a cloud GPU VM, train, pull artifacts, shut it down."""
from __future__ import annotations

from pathlib import Path

import click
from rich.console import Console

from forge.core import config

console = Console()


@click.command()
@click.option("--provider", default=None, type=click.Choice(["gcp", "aws", "lambda", "runpod"]),
              help="Cloud provider (default: forge.yaml cloud.provider, fallback: gcp)")
@click.option("--gpu", default=None, type=click.Choice(["a100", "l4", "h100", "none"]),
              help="GPU type (default: forge.yaml cloud.gpu, fallback: a100)")
@click.option("--zone", default=None,
              help="Provider zone/region override (e.g. us-central1-a)")
@click.option("--dry-run", is_flag=True,
              help="Show plan and exact gcloud commands — create nothing")
@click.option("--keep-vm", is_flag=True,
              help="Skip VM deletion after training (for debugging)")
@click.option("--skip-inference", is_flag=True,
              help="Skip model inference step on VM (use if predictions.jsonl already exists)")
@click.option("--project", "-p", default=None,
              help="Project directory (default: auto-discover from forge.yaml)")
def cloud_train(
    provider: str | None,
    gpu: str | None,
    zone: str | None,
    dry_run: bool,
    keep_vm: bool,
    skip_inference: bool,
    project: str | None,
):
    """Spawn a cloud GPU VM, run forge train + inference, pull artifacts, shut down.

    \b
    Full pipeline (automated):
      1. Upload dataset + forge.yaml → GCS bucket
      2. Create GPU VM (startup: Tailscale join + install deps + pull data)
      3. Wait for VM to appear on Tailscale (~2-3 min)
      4. SSH: forge train  (GPU)
      5. SSH: run model inference → predictions.jsonl  (GPU)
      6. SSH: gsutil upload all artifacts → GCS  (BEFORE shutdown)
      7. Delete VM  (billing stops)
      8. Download artifacts locally
      9. forge eval  (Claude-as-judge, runs locally — no GPU cost)
      10. forge promote (if eval passes)

    \b
    Cloud config goes in forge.yaml under the `cloud:` key:

      cloud:
        provider: gcp
        project: llamafarm-pastures
        zone: us-central1-a
        gpu: a100
        gcs_bucket: gs://llamafarm-forge
        tailscale_auth_key: tskey-auth-...
        timeout_minutes: 180

    \b
    Examples:
      forge cloud-train --dry-run
      forge cloud-train --gpu l4              # cheaper, ~45min
      forge cloud-train --gpu a100            # faster, ~20min
      forge cloud-train --keep-vm             # debug: don't delete VM
      forge cloud-train --skip-inference      # if predictions.jsonl already in output/
    """
    project_dir = Path(project) if project else config.find_project_root()
    if not project_dir:
        console.print("[red]No forge.yaml found. Run `forge init` first.[/red]")
        raise SystemExit(1)

    cfg = config.load(project_dir)

    cloud_cfg = cfg.get("cloud", {})
    if not cloud_cfg and not dry_run:
        console.print(
            "[red]No `cloud:` block in forge.yaml.[/red]\n"
            "[dim]Add a cloud: section with provider, project, gcs_bucket, tailscale_auth_key.[/dim]"
        )
        raise SystemExit(1)

    # Validate Tailscale key presence (unless dry-run)
    ts_key = cloud_cfg.get("tailscale_auth_key", "")
    import os
    ts_key = ts_key or os.environ.get("TAILSCALE_AUTH_KEY", "")
    if not ts_key and not dry_run:
        console.print(
            "[red]Tailscale auth key not found.[/red]\n"
            "[dim]Set cloud.tailscale_auth_key in forge.yaml or TAILSCALE_AUTH_KEY env var.[/dim]"
        )
        raise SystemExit(1)

    from forge.cloud.manager import CloudTrainManager

    manager = CloudTrainManager(
        project_dir=project_dir,
        cfg=cfg,
        dry_run=dry_run,
        keep_vm=keep_vm,
        skip_inference=skip_inference,
        gpu_override=gpu,
        zone_override=zone,
        provider_override=provider,
    )

    exit_code = manager.run()
    raise SystemExit(exit_code)
