"""forge status — show score history, current best, gap to target, service health."""
from __future__ import annotations

import json
import shutil
import subprocess
from pathlib import Path

import click
from rich import box
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from forge.core import config

console = Console()


@click.command()
@click.option("--project", "-p", default=None, help="Project directory (default: cwd)")
def status(project: str):
    """Show current flywheel status and score history.

    \b
    Reads from the project directory (forge.yaml or configs/task.yaml):
      - output/best_score.json        — current best eval score
      - output/flywheel_manifest.jsonl — iteration history
      - output/adapter* directories   — versioned adapter count
      - src/dataset/ or dataset/      — active datasets
      - systemd service status        — is the flywheel running?
    """
    project_dir = Path(project) if project else config.find_project_root()
    if not project_dir:
        console.print("[red]No forge.yaml or configs/task.yaml found.[/red]")
        console.print("[dim]Run `forge init <name>` to create a project, or cd into an existing one.[/dim]")
        raise SystemExit(1)

    cfg = config.load(project_dir)
    output_dir = project_dir / "output"
    name = cfg.get("name", project_dir.name)
    config_source = Path(cfg.get("_config_source", "forge.yaml")).name

    # ── Header ───────────────────────────────────────────────────────────────
    console.print()
    console.print(Panel(
        f"[bold cyan]{name}[/bold cyan]\n"
        f"[dim]Project: {project_dir}[/dim]\n"
        f"[dim]Config:  {config_source}[/dim]",
        title="forge status",
        border_style="cyan",
    ))

    # ── Best score ───────────────────────────────────────────────────────────
    best_file = output_dir / "best_score.json"
    if best_file.exists():
        best = json.loads(best_file.read_text())
        acc = best.get("accuracy", 0)
        target = cfg["eval"]["target_accuracy"]
        gap = target - acc
        gap_color = "green" if acc >= target else ("yellow" if gap < 0.05 else "red")
        acc_color = "green" if acc >= target else "yellow"

        score_table = Table(show_header=False, box=None, padding=(0, 1))
        score_table.add_column("key", style="bold")
        score_table.add_column("val")
        score_table.add_row("Best accuracy",
                            f"[{acc_color}]{acc*100:.1f}%[/{acc_color}]  "
                            f"(target {target*100:.0f}%,  "
                            f"gap [{gap_color}]{gap*100:.1f}pp[/{gap_color}])")
        score_table.add_row("Correct",
                            f"{best.get('correct', '?')}/{best.get('total', '?')}")
        score_table.add_row("Safety violations",
                            f"[red]{best.get('safety_violations', 0)}[/red]"
                            if best.get("safety_violations", 0)
                            else "[green]0[/green]")
        score_table.add_row("Timestamp", str(best.get("timestamp", "?")))
        console.print(score_table)
    else:
        console.print("[dim]  No eval results yet.[/dim]")

    # ── Active datasets ──────────────────────────────────────────────────────
    console.print()
    ds_cfg = cfg.get("dataset", {})
    canonical_raw = ds_cfg.get("canonical", "")
    gold_raw = ds_cfg.get("gold", "")

    canonical_path = Path(canonical_raw) if canonical_raw else None
    gold_path = Path(gold_raw) if gold_raw else None

    ds_table = Table(title="Active Datasets", box=box.SIMPLE, show_header=True)
    ds_table.add_column("Role")
    ds_table.add_column("File")
    ds_table.add_column("Examples", justify="right")

    for role, path in [("canonical", canonical_path), ("gold", gold_path)]:
        if path and path.exists():
            count = sum(1 for l in path.read_text().splitlines() if l.strip())
            ds_table.add_row(role, path.name,
                             f"[green]{count}[/green]")
        elif path:
            ds_table.add_row(role, path.name, "[red]not found[/red]")
        else:
            ds_table.add_row(role, "[dim]not configured[/dim]", "—")
    console.print(ds_table)

    # ── Versioned adapters ───────────────────────────────────────────────────
    adapters = sorted(output_dir.glob("adapter_iter*"), reverse=True)
    best_adapters = sorted(output_dir.glob("best_adapter_iter*"), reverse=True)
    if adapters or best_adapters:
        console.print(
            f"[dim]  Versioned adapters: {len(adapters)} training snapshots, "
            f"{len(best_adapters)} best-adapter snapshots[/dim]"
        )
        if adapters:
            console.print(f"[dim]  Latest: {adapters[0].name}[/dim]")

    # ── Iteration history ────────────────────────────────────────────────────
    manifest = output_dir / "flywheel_manifest.jsonl"
    if manifest.exists():
        lines = [json.loads(l) for l in manifest.read_text().strip().splitlines() if l]
        if lines:
            console.print()
            table = Table(title=f"Iteration History (last 10 of {len(lines)})",
                          box=box.SIMPLE)
            table.add_column("Iter", style="dim")
            table.add_column("Dataset")
            table.add_column("Examples", justify="right")
            table.add_column("Loss", justify="right")
            table.add_column("Epochs", justify="right")
            table.add_column("Time")
            for row in lines[-10:]:
                fname = Path(row.get("train_file", "?")).name
                table.add_row(
                    str(row.get("iteration", "?")),
                    fname[:40],
                    str(row.get("train_examples", "?")),
                    f"{row.get('loss', 0):.4f}",
                    str(row.get("epochs", "?")),
                    f"{row.get('train_min', 0):.0f}m",
                )
            console.print(table)

    # ── Flywheel service status ──────────────────────────────────────────────
    _show_service_status()


def _show_service_status() -> None:
    """Show systemd llamadrone-flywheel.service status if systemctl is available."""
    if not shutil.which("systemctl"):
        return

    SERVICE = "llamadrone-flywheel.service"
    try:
        result = subprocess.run(
            ["systemctl", "is-active", SERVICE],
            capture_output=True, text=True, timeout=3,
        )
        active = result.stdout.strip()
    except Exception:
        return

    # Get main PID and memory for running service
    extra = ""
    if active == "active":
        try:
            show = subprocess.run(
                ["systemctl", "show", SERVICE,
                 "--property=MainPID,MemoryCurrent,ActiveEnterTimestamp"],
                capture_output=True, text=True, timeout=3,
            )
            props = dict(line.split("=", 1) for line in show.stdout.strip().splitlines() if "=" in line)
            pid = props.get("MainPID", "?")
            mem_bytes = int(props.get("MemoryCurrent", "0") or 0)
            mem_gb = mem_bytes / (1024 ** 3)
            since = props.get("ActiveEnterTimestamp", "?")
            extra = f"  PID {pid}  |  {mem_gb:.1f}GB RAM  |  since {since}"
        except Exception:
            pass

    color = {"active": "green", "inactive": "dim", "failed": "red"}.get(active, "yellow")
    icon = {"active": "●", "inactive": "○", "failed": "✗"}.get(active, "?")
    console.print()
    console.print(
        f"  [{color}]{icon} {SERVICE}: {active}[/{color}]"
        + (f"\n  [dim]{extra.strip()}[/dim]" if extra else "")
    )
