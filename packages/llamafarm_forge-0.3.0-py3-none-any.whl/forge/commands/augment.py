"""forge augment — generate targeted training data from latest failures."""
from __future__ import annotations

import json
import os
import re
import sys
from pathlib import Path

import click
from rich.console import Console
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn, TimeElapsedColumn

from forge.core import config, context

console = Console()


@click.command()
@click.option("--n", default=None, type=int,
              help="Examples per failure category (default: forge.yaml flywheel.augment_per_failure)")
@click.option("--project", "-p", default=None,
              help="Project directory (default: auto-discover from forge.yaml)")
def augment(n: int | None, project: str | None):
    """Generate targeted training data from the latest eval failures.

    \b
    Loads AGENT_CONTEXT.md + mission.md + latest failures file, prepends
    context (max ~5000 chars) to the Claude datagen prompt, then calls the
    failure-driven datagen logic and appends results to dataset/canonical.jsonl.

    Examples:
      forge augment
      forge augment --n 30
      forge augment --project ~/my-router
    """
    project_dir = Path(project) if project else config.find_project_root()
    if not project_dir:
        console.print("[red]No forge.yaml found. Run `forge init` first.[/red]")
        raise SystemExit(1)

    cfg = config.load(project_dir)
    name = cfg.get("name", project_dir.name)

    api_key = cfg.get("_anthropic_key") or os.environ.get("ANTHROPIC_API_KEY", "")
    if not api_key:
        console.print("[red]ANTHROPIC_API_KEY not set.[/red]")
        raise SystemExit(1)

    per_failure = n or cfg["flywheel"]["augment_per_failure"]
    datagen_model = cfg["flywheel"]["datagen_model"]

    # Resolve canonical dataset path
    canonical_path = _resolve_dataset(cfg, project_dir, "canonical", "dataset/canonical.jsonl")

    # Find latest failures file
    output_dir = project_dir / "output"
    failures_file = _find_latest_failures(output_dir)
    if not failures_file:
        console.print("[yellow]No failures file found in output/. Run `forge eval` first.[/yellow]")
        raise SystemExit(1)

    # Load failures
    with open(failures_file) as f:
        failures_data = json.load(f)
    failures = failures_data.get("failures", [])

    if not failures:
        console.print("[green]No failures found — nothing to augment.[/green]")
        return

    # Load context: AGENT_CONTEXT.md + mission.md
    agent_ctx = context.load(project_dir)
    mission = _load_mission(project_dir)

    console.print()
    console.print(Panel(
        f"[bold]{name}[/bold]\n"
        f"Failures file: [cyan]{failures_file.name}[/cyan]  ({len(failures)} failures)\n"
        f"Per-category: [yellow]{per_failure}[/yellow]\n"
        f"Datagen model: [dim]{datagen_model}[/dim]\n"
        f"Appending to: [dim]{canonical_path.name}[/dim]",
        title="forge augment",
        border_style="blue",
    ))

    # Import datagen logic from src/
    src_dir = project_dir / "src"
    if str(src_dir) not in sys.path:
        sys.path.insert(0, str(src_dir))

    try:
        import anthropic as _anthropic
        import datagen as _datagen
    except ImportError as e:
        console.print(f"[red]Import error: {e}[/red]")
        console.print("[dim]Ensure anthropic is installed: uv pip install anthropic[/dim]")
        raise SystemExit(1)

    client = _anthropic.Anthropic(api_key=api_key)

    # Patch datagen's DATAGEN_SYSTEM to prepend context
    context_prefix = _build_context_prefix(mission, agent_ctx)
    original_system = _datagen.DATAGEN_SYSTEM
    if context_prefix:
        _datagen.DATAGEN_SYSTEM = context_prefix + "\n\n" + original_system

    # Generate to a temp patch file then append to canonical
    import tempfile
    from datetime import datetime

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    patch_file = output_dir / f"augment_{timestamp}.jsonl"
    output_dir.mkdir(exist_ok=True)

    console.print(f"\n[dim]Generating examples → {patch_file.name}[/dim]")

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        TimeElapsedColumn(),
        console=console,
    ) as progress:
        task = progress.add_task("Calling Claude…", total=None)

        try:
            examples = _datagen.generate_from_failures(
                client, failures, per_failure, patch_file
            )
            progress.update(task, description=f"Generated {len(examples)} examples")
        except Exception as e:
            console.print(f"[red]Datagen error: {e}[/red]")
            raise SystemExit(1)
        finally:
            # Restore original system prompt
            _datagen.DATAGEN_SYSTEM = original_system

    # Count new examples
    new_count = sum(1 for _ in open(patch_file)) if patch_file.exists() else 0

    if new_count == 0:
        console.print("[yellow]No valid examples generated.[/yellow]")
        return

    # Append to canonical.jsonl
    canonical_path.parent.mkdir(parents=True, exist_ok=True)
    with open(canonical_path, "a") as out_f, open(patch_file) as in_f:
        out_f.write(in_f.read())

    # Count total canonical
    total_canonical = sum(1 for _ in open(canonical_path))

    console.print(Panel(
        f"[green]✅ Augmentation complete[/green]\n"
        f"New examples: [bold]{new_count}[/bold]\n"
        f"Canonical total: [bold]{total_canonical}[/bold]\n"
        f"Patch saved to: [dim]{patch_file.name}[/dim]",
        border_style="green",
    ))


def _find_latest_failures(output_dir: Path) -> Path | None:
    """Return the most recent failures_*.json file."""
    if not output_dir.exists():
        return None
    candidates = sorted(output_dir.glob("failures_*.json"), reverse=True)
    return candidates[0] if candidates else None


def _resolve_dataset(cfg: dict, project_dir: Path, key: str, default: str) -> Path:
    rel = cfg.get("dataset", {}).get(key, default)
    p = Path(rel)
    return p if p.is_absolute() else project_dir / p


def _load_mission(project_dir: Path) -> str:
    for name in ("mission.md", "MISSION.md"):
        p = project_dir / name
        if p.exists():
            return p.read_text()
    return ""


def _build_context_prefix(mission: str, agent_ctx: str) -> str:
    """Build a context block (max ~5000 chars) to prepend to the datagen system prompt."""
    parts: list[str] = []
    if mission:
        parts.append(f"[MISSION]\n{mission.strip()}")
    if agent_ctx:
        parts.append(f"[AGENT CONTEXT — recent history]\n{agent_ctx.strip()}")
    if not parts:
        return ""

    combined = "\n\n".join(parts)
    if len(combined) > 5000:
        combined = combined[:5000] + "\n...[context truncated]"
    return combined
