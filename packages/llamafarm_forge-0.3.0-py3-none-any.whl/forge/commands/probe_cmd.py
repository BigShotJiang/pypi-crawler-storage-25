"""forge probe — pre/post knowledge probe with LLM-as-judge scoring."""
from __future__ import annotations

from pathlib import Path

import click
from rich import box
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

console = Console()


@click.command("probe")
@click.option("--tag", default=None,
              help="Label for this run: 'pre', 'post', or any string. "
                   "Auto-detected if omitted (pre if no prior probe exists, else timestamp).")
@click.option("--adapter", "adapter_path", default=None, type=click.Path(),
              help="Path to adapter or merged model to load on top of base. "
                   "If omitted, runs against the base model only.")
@click.option("--compare", is_flag=True, default=False,
              help="Show a diff table between the most recent 'pre' and 'post' probes. "
                   "Does not run inference — only displays saved results.")
@click.option("--max-new-tokens", default=256, type=int, show_default=True)
@click.option("--project", "-p", "project_path", default=".", type=click.Path())
def probe(tag, adapter_path, compare, max_new_tokens, project_path):
    """Run a knowledge probe (30 Q&A) before and after pretraining.

    Scores each question 0–3 using Claude as judge. Run --tag pre before
    pretraining and --tag post after to measure domain knowledge gain.

    \b
    Probe file format (dataset/probe.jsonl):
        {"question": "What is ...", "ideal": "The answer is ..."}
        {"question": "...", "ideal": "..."}

    \b
    Examples:
        forge probe --tag pre
        forge probe --tag post --adapter output/pretrain_merged
        forge probe --compare
    """
    from forge.core import config as _config
    from forge.core.probe import (
        load_probe_results,
        run_probe,
        compare_probes,
    )

    project_dir = Path(project_path).resolve()
    output_dir = project_dir / "output"

    # ── Compare mode — no inference needed ───────────────────────────────────
    if compare:
        pre = load_probe_results(output_dir, "pre")
        post = load_probe_results(output_dir, "post")
        if not pre:
            raise click.ClickException("No 'pre' probe results found in output/. Run: forge probe --tag pre")
        if not post:
            raise click.ClickException("No 'post' probe results found in output/. Run: forge probe --tag post")
        _print_compare(pre, post)
        return

    # ── Determine tag ─────────────────────────────────────────────────────────
    if tag is None:
        pre_exists = bool(list(output_dir.glob("probe_pre_*.json"))) if output_dir.exists() else False
        tag = "post" if pre_exists else "pre"
        console.print(f"[dim]Auto-detected tag: {tag}[/dim]")

    cfg = _config.load(project_dir)
    resolved_adapter = Path(adapter_path) if adapter_path else None

    # ── Run probe ─────────────────────────────────────────────────────────────
    results = run_probe(
        project_dir=project_dir,
        cfg=cfg,
        tag=tag,
        adapter_path=resolved_adapter,
        max_new_tokens=max_new_tokens,
    )

    _print_results(results)


def _print_results(results: dict) -> None:
    """Print a rich table of probe results."""
    tag = results["tag"]
    n = results["total"]
    mean = results["mean_score"]
    pct = results["pct_correct"]

    table = Table(
        title=f"Probe results — tag={tag}",
        box=box.SIMPLE_HEAVY,
        show_lines=True,
    )
    table.add_column("#", style="dim", width=3)
    table.add_column("Question", max_width=40)
    table.add_column("Model answer", max_width=35)
    table.add_column("Score", justify="center", width=7)
    table.add_column("Reasoning", max_width=35)

    for i, r in enumerate(results["results"], 1):
        score = r["score"]
        color = "green" if score == 3 else ("yellow" if score >= 1 else "red")
        icon = "✅" if score == 3 else ("⚠️" if score >= 1 else "❌")
        table.add_row(
            str(i),
            r["question"][:80],
            r["model_answer"][:80] if r["model_answer"] else "[dim](no output)[/dim]",
            f"[{color}]{icon} {score}/3[/{color}]",
            r["judge_reasoning"][:80],
        )

    console.print()
    console.print(table)

    summary_color = "green" if pct >= 0.7 else ("yellow" if pct >= 0.4 else "red")
    console.print(Panel(
        f"[bold]Tag:[/bold]          {tag}\n"
        f"[bold]Questions:[/bold]    {n}\n"
        f"[bold]Mean score:[/bold]   [{summary_color}]{mean:.2f} / 3[/{summary_color}]\n"
        f"[bold]Fully correct:[/bold] [{summary_color}]{pct*100:.1f}% ({int(pct*n)}/{n})[/{summary_color}]\n"
        f"[bold]Elapsed:[/bold]      {results.get('elapsed_min', '?')} min",
        title=f"[bold]Knowledge Probe — {tag}[/bold]",
        border_style=summary_color,
    ))


def _print_compare(pre: dict, post: dict) -> None:
    """Print a side-by-side comparison table."""
    from forge.core.probe import compare_probes

    diffs = compare_probes(pre, post)

    pre_mean = pre.get("mean_score", 0)
    post_mean = post.get("mean_score", 0)
    delta_mean = post_mean - pre_mean
    pre_pct = pre.get("pct_correct", 0)
    post_pct = post.get("pct_correct", 0)

    table = Table(
        title="Pre vs Post Probe Comparison",
        box=box.SIMPLE_HEAVY,
        show_lines=True,
    )
    table.add_column("#", style="dim", width=3)
    table.add_column("Question", max_width=45)
    table.add_column("Pre", justify="center", width=6)
    table.add_column("Post", justify="center", width=6)
    table.add_column("Δ", justify="center", width=5)

    for i, d in enumerate(diffs, 1):
        pre_s = d["pre_score"]
        post_s = d["post_score"]
        delta = d["delta"]

        if isinstance(delta, int):
            if delta > 0:
                delta_str = f"[green]+{delta}[/green]"
            elif delta < 0:
                delta_str = f"[red]{delta}[/red]"
            else:
                delta_str = "[dim]0[/dim]"
        else:
            delta_str = "[dim]—[/dim]"

        pre_color = "green" if pre_s == 3 else ("yellow" if isinstance(pre_s, int) and pre_s >= 1 else "red")
        post_color = "green" if post_s == 3 else ("yellow" if post_s >= 1 else "red")

        table.add_row(
            str(i),
            d["question"][:80],
            f"[{pre_color}]{pre_s}[/{pre_color}]",
            f"[{post_color}]{post_s}[/{post_color}]",
            delta_str,
        )

    console.print()
    console.print(table)

    delta_color = "green" if delta_mean > 0 else ("red" if delta_mean < 0 else "dim")
    console.print(Panel(
        f"[bold]Pre  mean score:[/bold]  {pre_mean:.2f}/3  ({pre_pct*100:.1f}% fully correct)\n"
        f"[bold]Post mean score:[/bold]  {post_mean:.2f}/3  ({post_pct*100:.1f}% fully correct)\n"
        f"[bold]Delta:[/bold]           [{delta_color}]{delta_mean:+.2f} points[/{delta_color}]",
        title="[bold]Knowledge Gain Summary[/bold]",
        border_style=delta_color if delta_color != "dim" else "white",
    ))
