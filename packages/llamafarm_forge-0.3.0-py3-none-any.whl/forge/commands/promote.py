"""forge promote — snapshot current adapter as best and git-commit."""
from __future__ import annotations

import json
import shutil
import subprocess
from datetime import datetime
from pathlib import Path

import click
from rich.console import Console
from rich.panel import Panel

from forge.core import config

console = Console()


@click.command()
@click.option("--project", "-p", default=None,
              help="Project directory (default: auto-discover from forge.yaml)")
def promote(project: str | None):
    """Promote the current adapter to output/best_adapter and git-commit.

    \b
    Steps:
      1. Reads output/eval_results.json for the current score
      2. Compares against output/best_score.json (if present)
      3. Copies output/adapter → output/best_adapter_iterN_<timestamp>/
      4. Updates output/best_score.json
      5. Git commits: "promoted: iterN X.X%"

    Safety violations in eval_results.json will block promotion.

    Examples:
      forge promote
      forge promote --project ~/my-router
    """
    project_dir = Path(project) if project else config.find_project_root()
    if not project_dir:
        console.print("[red]No forge.yaml found. Run `forge init` first.[/red]")
        raise SystemExit(1)

    cfg = config.load(project_dir)
    name = cfg.get("name", project_dir.name)
    output_dir = project_dir / "output"
    output_dir.mkdir(exist_ok=True)

    # Load current eval results
    results_file = output_dir / "eval_results.json"
    if not results_file.exists():
        console.print("[red]No eval_results.json found. Run `forge eval` first.[/red]")
        raise SystemExit(1)

    results: dict = json.loads(results_file.read_text())
    accuracy = results.get("accuracy", 0.0)
    safety_violations = results.get("safety_violations", 0)
    correct = results.get("correct", 0)
    total = results.get("total", 0)
    timestamp_eval = results.get("timestamp", datetime.now().strftime("%Y%m%d_%H%M%S"))

    # Block on safety violations
    if safety_violations > 0:
        console.print(Panel(
            f"[red]🚨 Promotion blocked[/red]\n"
            f"Safety violations: [red]{safety_violations}[/red]\n"
            f"Fix all safety issues before promoting.",
            border_style="red",
        ))
        raise SystemExit(1)

    # Load previous best (if any)
    best_file = output_dir / "best_score.json"
    prev_best: dict = {}
    if best_file.exists():
        try:
            prev_best = json.loads(best_file.read_text())
        except Exception:
            pass

    prev_accuracy = prev_best.get("accuracy", 0.0)
    prev_iter = prev_best.get("iteration", 0)
    new_iter = prev_iter + 1

    # Determine if this is actually better
    if prev_best and accuracy < prev_accuracy:
        console.print(Panel(
            f"[yellow]⚠️  New score {accuracy*100:.1f}% < previous best {prev_accuracy*100:.1f}%[/yellow]\n"
            f"Proceeding anyway (forced promote). Pass --force to skip this check in future.",
            border_style="yellow",
        ))

    # Copy adapter
    adapter_src = output_dir / "adapter"
    if not adapter_src.exists():
        console.print(f"[red]Adapter not found at {adapter_src}[/red]")
        raise SystemExit(1)

    timestamp_now = datetime.now().strftime("%Y%m%d_%H%M%S")
    snapshot_name = f"best_adapter_iter{new_iter}_{timestamp_now}"
    snapshot_dir = output_dir / snapshot_name

    console.print(f"\n[dim]Copying {adapter_src} → {snapshot_dir}[/dim]")
    if snapshot_dir.exists():
        shutil.rmtree(snapshot_dir)
    shutil.copytree(adapter_src, snapshot_dir)

    # Update output/best_adapter symlink (or copy)
    best_adapter_dir = output_dir / "best_adapter"
    if best_adapter_dir.exists() or best_adapter_dir.is_symlink():
        if best_adapter_dir.is_symlink():
            best_adapter_dir.unlink()
        else:
            shutil.rmtree(best_adapter_dir)
    shutil.copytree(adapter_src, best_adapter_dir)

    # Update best_score.json
    new_best = {
        "iteration": new_iter,
        "accuracy": accuracy,
        "correct": correct,
        "total": total,
        "safety_violations": 0,
        "snapshot": snapshot_name,
        "timestamp": timestamp_now,
        "eval_timestamp": timestamp_eval,
        "delta": round(accuracy - prev_accuracy, 4),
    }
    best_file.write_text(json.dumps(new_best, indent=2))

    # Git commit
    delta_str = (
        f"+{(accuracy - prev_accuracy)*100:.1f}pp" if prev_best else "initial"
    )
    commit_msg = f"promoted: iter{new_iter} {accuracy*100:.1f}% ({delta_str})"

    git_result = subprocess.run(
        ["git", "add",
         str(best_file.relative_to(project_dir)),
         str(best_adapter_dir.relative_to(project_dir)) if best_adapter_dir.exists() else ".",
         ],
        cwd=project_dir,
        capture_output=True,
        text=True,
    )
    if git_result.returncode != 0:
        console.print(f"[yellow]git add warning: {git_result.stderr.strip()}[/yellow]")

    # Also add any new dataset files and the score file
    subprocess.run(["git", "add", "dataset/", "output/best_score.json"],
                   cwd=project_dir, capture_output=True)

    commit_result = subprocess.run(
        ["git", "commit", "-m", commit_msg, "--allow-empty"],
        cwd=project_dir,
        capture_output=True,
        text=True,
    )
    git_ok = commit_result.returncode == 0

    # Git push (best-effort; don't fail on push errors)
    push_ok = False
    push_msg = ""
    if git_ok:
        push_result = subprocess.run(
            ["git", "push"],
            cwd=project_dir,
            capture_output=True,
            text=True,
        )
        push_ok = push_result.returncode == 0
        if not push_ok:
            push_msg = push_result.stderr.strip()[:120]

    # Display results
    delta_color = "green" if accuracy >= prev_accuracy else "yellow"
    git_line = ""
    if git_ok:
        git_line = f"\nGit: [green]{commit_msg}[/green]"
        git_line += "  [green]pushed ✓[/green]" if push_ok else f"  [yellow]push failed: {push_msg}[/yellow]"
    else:
        git_line = "\nGit: [yellow]skipped (git error)[/yellow]"

    console.print(Panel(
        f"[green]✅ Promoted to iter {new_iter}[/green]\n\n"
        f"Accuracy: [{delta_color}]{accuracy*100:.1f}%[/{delta_color}]  "
        f"({correct}/{total})\n"
        f"Delta vs prev best: [{delta_color}]{delta_str}[/{delta_color}]\n"
        f"Snapshot: [dim]{snapshot_name}[/dim]"
        f"{git_line}",
        title=f"forge promote — {name}",
        border_style="green",
    ))

    if not git_ok:
        console.print(f"[dim]git stderr: {commit_result.stderr.strip()}[/dim]")
