"""forge train — fine-tune on canonical.jsonl, wrapping src/train.py."""
from __future__ import annotations

import json
import subprocess
import sys
import time
from pathlib import Path

import click
from rich.console import Console
from rich.live import Live
from rich.panel import Panel
from rich.progress import (
    BarColumn,
    Progress,
    SpinnerColumn,
    TextColumn,
    TimeElapsedColumn,
)
from rich.table import Table

from forge.core import config

console = Console()


@click.command()
@click.option("--epochs", default=None, type=int,
              help="Override training epochs (default: from forge.yaml training.epochs_min)")
@click.option("--project", "-p", default=None,
              help="Project directory (default: auto-discover from forge.yaml)")
def train(epochs: int | None, project: str | None):
    """Train the model on dataset/canonical.jsonl.

    \b
    Reads all config from forge.yaml. Delegates to src/train.py on the
    project's compute target. Streams log output with Rich progress.

    Examples:
      forge train
      forge train --epochs 3
      forge train --project ~/my-router
    """
    project_dir = Path(project) if project else config.find_project_root()
    if not project_dir:
        console.print("[red]No forge.yaml found. Run `forge init` first.[/red]")
        raise SystemExit(1)

    cfg = config.load(project_dir)
    name = cfg.get("name", project_dir.name)

    # Resolve training script — fall back to built-in trainer if no src/train.py
    train_script = project_dir / "src" / "train.py"
    use_builtin = not train_script.exists()

    # Resolve canonical dataset
    canonical = Path(cfg.get("dataset", {}).get("canonical",
                     str(project_dir / "dataset" / "canonical.jsonl")))
    if not canonical.is_absolute():
        canonical = project_dir / canonical
    if not canonical.exists():
        console.print(f"[yellow]Warning: canonical dataset not found at {canonical}[/yellow]")

    # Epoch resolution
    effective_epochs = epochs or cfg["training"]["epochs_min"]

    console.print()
    console.print(Panel(
        f"[bold]{name}[/bold]\n"
        f"Model: [cyan]{cfg['model']['base']}[/cyan]\n"
        f"Epochs: [yellow]{effective_epochs}[/yellow]  "
        f"(min={cfg['training']['epochs_min']}, max={cfg['training']['epochs_max']})\n"
        f"Dataset: [dim]{canonical.name}[/dim]\n"
        f"Device: [dim]{cfg['compute']['device']}[/dim]",
        title="forge train",
        border_style="blue",
    ))

    start = time.time()
    result_json: dict = {}
    return_code = 0

    if use_builtin:
        console.print("[dim]No src/train.py found — using forge built-in trainer[/dim]\n")
        try:
            from forge.core import trainer as _trainer
            result_json = _trainer.run(project_dir, cfg, epochs_override=effective_epochs)
        except Exception as e:
            console.print(f"[red]❌ Training failed: {e}[/red]")
            raise SystemExit(1)
    else:
        cmd = [sys.executable, str(train_script)]
        if epochs:
            cmd.append(str(epochs))

        console.print(f"[dim]$ {' '.join(cmd)}[/dim]\n")

        progress = Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            BarColumn(),
            TimeElapsedColumn(),
            console=console,
            transient=False,
        )

        task = progress.add_task("Training…", total=None)
        result_lines: list[str] = []

        with progress:
            proc = subprocess.Popen(
                cmd,
                cwd=project_dir,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
            )
            assert proc.stdout is not None
            for line in proc.stdout:
                line = line.rstrip()
                result_lines.append(line)
                if any(kw in line for kw in ("Epoch", "loss:", "VRAM", "Dataset", "✅")):
                    progress.update(task, description=line[:80])
                console.print(f"[dim]{line}[/dim]")
            proc.wait()
            return_code = proc.returncode

        if return_code != 0:
            console.print(f"\n[red]❌ Training failed (exit {return_code})[/red]")
            raise SystemExit(return_code)

        for line in reversed(result_lines):
            line = line.strip()
            if line.startswith("{"):
                try:
                    result_json = json.loads(line)
                    break
                except json.JSONDecodeError:
                    pass

    elapsed = (time.time() - start) / 60
    table = Table(show_header=False, box=None)
    table.add_column("Key", style="bold")
    table.add_column("Value")
    table.add_row("Status", "[green]✅ Complete[/green]")
    table.add_row("Elapsed", f"{elapsed:.1f} min")
    if result_json:
        table.add_row("Epochs run", str(result_json.get("epochs_run", "?")))
        table.add_row("Final loss", f"{result_json.get('final_loss', 0):.4f}")
        table.add_row("Train examples", str(result_json.get("train_examples", "?")))
        table.add_row("Adapter", str(result_json.get("adapter_dir", "output/adapter")))

    console.print(Panel(table, title="Train Results", border_style="green"))
