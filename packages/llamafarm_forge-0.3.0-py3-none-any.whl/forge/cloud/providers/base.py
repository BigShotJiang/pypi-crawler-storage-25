"""forge cloud — abstract base provider.

All cloud providers implement this interface. New providers (AWS, Lambda,
RunPod, etc.) only need to subclass BaseProvider and implement the abstract
methods — the CloudTrainManager orchestration layer is provider-agnostic.
"""
from __future__ import annotations

import abc
from dataclasses import dataclass, field
from typing import Any


@dataclass
class VMSpec:
    """Requested VM configuration — provider-agnostic."""
    name: str
    gpu: str                        # "a100" | "l4" | "h100" | "none"
    disk_gb: int = 100
    region: str = ""                # provider-specific region/zone
    image: str = ""                 # provider-specific image (empty = sensible default)
    tags: list[str] = field(default_factory=lambda: ["forge-managed"])
    tailscale_auth_key: str = ""
    startup_env: dict[str, str] = field(default_factory=dict)


@dataclass
class VMInfo:
    """Running VM descriptor returned by create_vm / list_vms."""
    name: str
    provider: str
    status: str                     # "running" | "stopped" | "terminated"
    region: str
    tailscale_hostname: str = ""    # populated once VM joins Tailscale
    external_ip: str = ""
    metadata: dict[str, Any] = field(default_factory=dict)


class BaseProvider(abc.ABC):
    """Abstract cloud provider. Subclass and implement all abstract methods."""

    name: str = "base"              # override in subclass: "gcp" | "aws" | "runpod"

    def __init__(self, cfg: dict):
        """
        cfg is the forge.yaml `cloud:` block, provider-filtered.
        Providers should extract their own keys and validate here.
        """
        self.cfg = cfg

    # ── Lifecycle ────────────────────────────────────────────────────────────

    @abc.abstractmethod
    def create_vm(self, spec: VMSpec) -> VMInfo:
        """Provision a new VM. Returns VMInfo with at least name + status."""
        ...

    @abc.abstractmethod
    def wait_ready(self, vm: VMInfo, timeout_seconds: int = 300) -> VMInfo:
        """
        Block until the VM's startup script completes and Tailscale joins.
        Returns updated VMInfo with tailscale_hostname populated.
        Should poll /tmp/forge-ready via SSH or equivalent signal.
        """
        ...

    @abc.abstractmethod
    def delete_vm(self, vm: VMInfo) -> None:
        """
        Permanently delete the VM. MUST check that vm has the 'forge-managed'
        tag before deletion — raise RuntimeError if tag is absent.
        """
        ...

    @abc.abstractmethod
    def list_vms(self, tag: str = "forge-managed") -> list[VMInfo]:
        """List all VMs with the given tag. Used for leak detection."""
        ...

    # ── Remote execution ─────────────────────────────────────────────────────

    @abc.abstractmethod
    def run_ssh(
        self,
        vm: VMInfo,
        command: str,
        capture: bool = False,
        timeout: int = 3600,
    ) -> tuple[int, str]:
        """
        Run a shell command on the VM via SSH (Tailscale hostname).
        Returns (exit_code, combined stdout+stderr).
        If capture=False, streams output live to stdout.
        """
        ...

    # ── Artifact store ───────────────────────────────────────────────────────

    @abc.abstractmethod
    def upload_to_store(self, local_path: str, remote_path: str) -> None:
        """Upload local file/directory to the provider artifact store (GCS/S3/etc)."""
        ...

    @abc.abstractmethod
    def download_from_store(self, remote_path: str, local_path: str) -> None:
        """Download from artifact store to local path."""
        ...

    @abc.abstractmethod
    def store_exists(self, remote_path: str) -> bool:
        """Check if a path exists in the artifact store."""
        ...

    # ── Helpers ───────────────────────────────────────────────────────────────

    def _require_forge_managed(self, vm: VMInfo) -> None:
        """Safety check — raise if VM is not tagged forge-managed."""
        tags = vm.metadata.get("tags", [])
        if "forge-managed" not in tags:
            raise RuntimeError(
                f"[SAFETY] Refusing to delete VM '{vm.name}' — "
                f"'forge-managed' tag not found. Tags: {tags}\n"
                f"Only VMs created by forge cloud-train may be deleted automatically."
            )
