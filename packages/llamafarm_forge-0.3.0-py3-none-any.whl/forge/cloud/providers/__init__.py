"""forge cloud providers."""
from forge.cloud.providers.base import BaseProvider, VMInfo, VMSpec
from forge.cloud.providers.gcp  import GCPProvider

PROVIDERS: dict[str, type[BaseProvider]] = {
    "gcp": GCPProvider,
    # Future:
    # "aws":    AWSProvider,
    # "lambda": LambdaProvider,
    # "runpod": RunPodProvider,
}


def get_provider(name: str, cfg: dict) -> BaseProvider:
    """Instantiate a provider by name."""
    cls = PROVIDERS.get(name.lower())
    if cls is None:
        available = list(PROVIDERS.keys())
        raise ValueError(f"Unknown provider '{name}'. Available: {available}")
    return cls(cfg)
