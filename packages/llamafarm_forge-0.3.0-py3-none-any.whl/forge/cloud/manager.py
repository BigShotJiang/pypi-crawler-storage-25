"""forge cloud — CloudTrainManager.

Orchestrates the full cloud training lifecycle:
  upload datasets → create VM → wait ready → train → inference →
  upload artifacts → delete VM → download artifacts → eval → promote
"""
from __future__ import annotations

import json
import os
import signal
import sys
import time
from datetime import datetime
from pathlib import Path
from typing import Optional

from rich.console import Console
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn, TimeElapsedColumn

from forge.cloud.providers import get_provider
from forge.cloud.providers.base import BaseProvider, VMInfo, VMSpec

console = Console()


class CloudTrainManager:
    def __init__(
        self,
        project_dir: Path,
        cfg: dict,
        dry_run: bool = False,
        keep_vm: bool = False,
        skip_inference: bool = False,
        gpu_override: Optional[str] = None,
        zone_override: Optional[str] = None,
        provider_override: Optional[str] = None,
    ):
        self.project_dir     = project_dir
        self.cfg             = cfg
        self.dry_run         = dry_run
        self.keep_vm         = keep_vm
        self.skip_inference  = skip_inference

        cloud_cfg = cfg.get("cloud", {})

        # Provider
        provider_name = provider_override or cloud_cfg.get("provider", "gcp")
        self.provider: BaseProvider = get_provider(provider_name, cloud_cfg)

        # GPU / zone overrides
        self.gpu  = gpu_override  or cloud_cfg.get("gpu", "a100")
        self.zone = zone_override or cloud_cfg.get("zone", "")

        # GCS bucket
        self.bucket = cloud_cfg.get("gcs_bucket", "gs://llamafarm-forge")

        # Tailscale auth key
        self.ts_key = cloud_cfg.get("tailscale_auth_key", "") or os.environ.get("TAILSCALE_AUTH_KEY", "")

        # VM naming
        ts = datetime.utcnow().strftime("%m%d-%H%M")
        prefix = cloud_cfg.get("vm_name_prefix", "forge-train")
        self.vm_name = f"{prefix}-{ts}"

        # Timeout
        self.timeout_minutes = cloud_cfg.get("timeout_minutes", 180)

        # Will be set once VM is created
        self._vm: Optional[VMInfo] = None

        # Artifact store paths
        self.run_id       = f"run-{ts}"
        self.gcs_run_path = f"{self.bucket}/{self.run_id}"
        self.gcs_datasets = f"{self.bucket}/datasets"

    # ── Main entry point ──────────────────────────────────────────────────────

    def run(self) -> int:
        """Execute full pipeline. Returns 0 on success, 1 on failure."""
        if self.dry_run:
            self._show_dry_run_plan()
            return 0

        # Register SIGINT handler — upload artifacts then clean up on Ctrl-C
        signal.signal(signal.SIGINT, self._handle_interrupt)

        try:
            self._step("Upload datasets to GCS",       self._upload_datasets)
            self._step("Create GPU VM",                self._create_vm)
            self._step("Wait for VM ready",            self._wait_vm_ready)
            self._step("Run forge train on VM",        self._run_training)
            if not self.skip_inference:
                self._step("Run inference on VM (GPU)", self._run_inference)
            self._step("Upload artifacts to GCS",      self._upload_artifacts)   # BEFORE delete
            self._step("Delete VM",                    self._delete_vm)
            self._step("Download artifacts locally",   self._download_artifacts)
            self._step("Run forge eval (local)",       self._run_eval)
            self._step("forge promote (if pass)",      self._maybe_promote)
        except Exception as e:
            console.print(f"\n[red]✗ Cloud train failed: {e}[/red]")
            self._emergency_cleanup()
            return 1

        console.print(Panel(
            "[green]✅ Cloud training pipeline complete.[/green]\n"
            f"Run ID: [cyan]{self.run_id}[/cyan]\n"
            f"Artifacts: [dim]{self.gcs_run_path}[/dim]",
            border_style="green",
        ))
        return 0

    # ── Steps ──────────────────────────────────────────────────────────────────

    def _upload_datasets(self):
        """Push canonical dataset + forge.yaml to GCS so VM can pull them."""
        cloud_cfg = self.cfg.get("cloud", {})
        dataset_cfg = self.cfg.get("dataset", {})
        canonical = self.project_dir / dataset_cfg.get("canonical", "data/canonical/taccommander_v1.jsonl")
        gold      = self.project_dir / dataset_cfg.get("gold", "eval/gold_eval_set.jsonl")
        forge_yaml = self.project_dir / "forge.yaml"

        if canonical.exists():
            self.provider.upload_to_store(str(canonical), f"{self.gcs_datasets}/")
            console.print(f"  [dim]Uploaded canonical: {canonical.name}[/dim]")
        else:
            console.print(f"  [yellow]⚠ Canonical dataset not found at {canonical}[/yellow]")

        if gold.exists():
            self.provider.upload_to_store(str(gold), f"{self.gcs_datasets}/")
            console.print(f"  [dim]Uploaded gold eval: {gold.name}[/dim]")

        if forge_yaml.exists():
            self.provider.upload_to_store(str(forge_yaml), f"{self.bucket}/forge.yaml")

    def _create_vm(self):
        spec = VMSpec(
            name=self.vm_name,
            gpu=self.gpu,
            disk_gb=self.cfg.get("cloud", {}).get("disk_gb", 100),
            region=self.zone,
            tags=self.cfg.get("cloud", {}).get("tags", ["forge-managed"]),
            tailscale_auth_key=self.ts_key,
            startup_env={
                "ANTHROPIC_API_KEY": os.environ.get("ANTHROPIC_API_KEY", ""),
                "GCS_BUCKET": self.bucket,
                "FORGE_RUN_ID": self.run_id,
            },
        )
        self._vm = self.provider.create_vm(spec)
        console.print(f"  [dim]VM created: {self._vm.name} ({self._vm.region})[/dim]")

    def _wait_vm_ready(self):
        timeout = self.timeout_minutes * 60 // 2  # half total timeout for startup
        self._vm = self.provider.wait_ready(self._vm, timeout_seconds=min(timeout, 600))
        console.print(f"  [dim]Tailscale hostname: {self._vm.tailscale_hostname}[/dim]")

    def _run_training(self):
        cmd = (
            f"cd /workspace && "
            f"CUDA_VISIBLE_DEVICES=0 forge train 2>&1 | tee /tmp/forge-train.log"
        )
        rc, _ = self.provider.run_ssh(self._vm, cmd, capture=False,
                                       timeout=self.timeout_minutes * 60)
        if rc != 0:
            raise RuntimeError("forge train failed on VM. Check /tmp/forge-train.log")

    def _run_inference(self):
        """Run model inference on GPU VM to generate predictions for eval."""
        cmd = (
            "cd /workspace && "
            "CUDA_VISIBLE_DEVICES=0 python3 -c \""
            "import json, yaml, torch; "
            "from pathlib import Path; "
            "cfg = yaml.safe_load(Path('forge.yaml').read_text()); "
            "gold = [json.loads(l) for l in Path(cfg['dataset']['gold']).read_text().splitlines() if l.strip()]; "
            "from unsloth import FastLanguageModel; "
            "model, tok = FastLanguageModel.from_pretrained('output/adapter', "
            "max_seq_length=cfg['model']['max_seq_len'], dtype=None, load_in_4bit=False); "
            "FastLanguageModel.for_inference(model); "
            "preds = []; "
            "[preds.append({'idx': i+1, 'assistant': tok.decode("
            "model.generate(tok.apply_chat_template([{'role':'system','content':ex['system']},"
            "{'role':'user','content':ex['user']}], tokenize=True, add_generation_prompt=True, return_tensors='pt').to('cuda'),"
            "attention_mask=torch.ones(1,1).to('cuda'),"
            "max_new_tokens=512, do_sample=False)[0][1:], skip_special_tokens=True)}) "
            "for i, ex in enumerate(gold)]; "
            "open('eval/predictions.jsonl','w').write('\\n'.join(json.dumps(p) for p in preds))"
            "\" 2>&1 | tee /tmp/forge-inference.log"
        )
        rc, _ = self.provider.run_ssh(self._vm, cmd, capture=False, timeout=3600)
        if rc != 0:
            console.print("[yellow]⚠ Inference had errors — eval may be incomplete[/yellow]")

    def _upload_artifacts(self):
        """Upload all outputs from VM to GCS. MUST succeed before VM deletion."""
        # Upload via VM → GCS directly (faster, avoids double-transfer)
        cmd = (
            f"cd /workspace && "
            f"gsutil -m cp -r output/ {self.gcs_run_path}/output/ && "
            f"gsutil -m cp -r eval/ {self.gcs_run_path}/eval/ && "
            f"gsutil cp /tmp/forge-train.log {self.gcs_run_path}/logs/train.log && "
            f"gsutil cp /tmp/forge-inference.log {self.gcs_run_path}/logs/inference.log 2>/dev/null || true && "
            f"echo 'artifacts-complete' > /tmp/forge-artifacts-done && "
            f"gsutil cp /tmp/forge-artifacts-done {self.gcs_run_path}/artifacts-complete"
        )
        rc, out = self.provider.run_ssh(self._vm, cmd, capture=True, timeout=600)
        if rc != 0:
            raise RuntimeError(
                f"Artifact upload to GCS failed!\n{out}\n"
                "VM NOT deleted. Fix gsutil access and re-run with --skip-inference --keep-vm."
            )

        # Verify the sentinel file exists before proceeding
        if not self.provider.store_exists(f"{self.gcs_run_path}/artifacts-complete"):
            raise RuntimeError(
                "Artifact upload sentinel not found in GCS. "
                "VM NOT deleted — verify manually."
            )
        console.print(f"  [dim]Artifacts at: {self.gcs_run_path}[/dim]")

    def _delete_vm(self):
        if self.keep_vm:
            console.print(f"  [yellow]--keep-vm set — skipping deletion of {self.vm_name}[/yellow]")
            return
        self.provider.delete_vm(self._vm)
        console.print(f"  [dim]VM deleted: {self.vm_name}[/dim]")
        self._vm = None

    def _download_artifacts(self):
        """Pull outputs from GCS to local project dir."""
        local_out = self.project_dir / "output"
        local_eval = self.project_dir / "eval"
        local_out.mkdir(parents=True, exist_ok=True)
        local_eval.mkdir(parents=True, exist_ok=True)

        self.provider.download_from_store(f"{self.gcs_run_path}/output/", str(local_out))
        self.provider.download_from_store(f"{self.gcs_run_path}/eval/", str(local_eval))
        console.print(f"  [dim]Artifacts downloaded to {local_out}[/dim]")

    def _run_eval(self):
        """Run forge eval locally — Claude-as-judge, no GPU needed."""
        import subprocess
        result = subprocess.run(
            ["forge", "eval"],
            cwd=self.project_dir,
        )
        if result.returncode != 0:
            console.print("[yellow]⚠ Eval did not pass 90% target — consider forge flywheel[/yellow]")

    def _maybe_promote(self):
        """Run forge promote if eval results show pass."""
        eval_results = self.project_dir / "output" / "eval_results.json"
        if not eval_results.exists():
            console.print("  [dim]No eval results — skipping promote[/dim]")
            return
        try:
            r = json.loads(eval_results.read_text())
            acc = r.get("accuracy", 0.0)
            target = self.cfg.get("eval", {}).get("target_accuracy", 0.90)
            if acc >= target:
                import subprocess
                subprocess.run(["forge", "promote"], cwd=self.project_dir, check=True)
            else:
                console.print(f"  [yellow]Accuracy {acc*100:.1f}% < target {target*100:.0f}% — not promoting[/yellow]")
        except Exception as e:
            console.print(f"  [yellow]Could not auto-promote: {e}[/yellow]")

    # ── Dry run ────────────────────────────────────────────────────────────────

    def _show_dry_run_plan(self):
        cloud_cfg = self.cfg.get("cloud", {})
        from forge.cloud.providers.gcp import GPU_MACHINE_TYPES
        machine_type, accel_type, accel_count, default_zone = GPU_MACHINE_TYPES.get(
            self.gpu, ("?", "?", 0, "?"))
        zone = self.zone or default_zone

        console.print(Panel(
            f"[bold yellow]DRY RUN — no resources will be created[/bold yellow]\n\n"
            f"[bold]Provider:[/bold]   {self.provider.name}\n"
            f"[bold]Project:[/bold]    {getattr(self.provider, 'project', '?')}\n"
            f"[bold]VM name:[/bold]    {self.vm_name}\n"
            f"[bold]GPU:[/bold]        {self.gpu} → {machine_type} ({accel_type})\n"
            f"[bold]Zone:[/bold]       {zone}\n"
            f"[bold]Disk:[/bold]       {cloud_cfg.get('disk_gb', 100)}GB SSD\n"
            f"[bold]GCS bucket:[/bold] {self.bucket}\n"
            f"[bold]Run path:[/bold]   {self.gcs_run_path}\n"
            f"[bold]Timeout:[/bold]    {self.timeout_minutes}min\n"
            f"[bold]Inference:[/bold]  {'skip' if self.skip_inference else 'on VM (GPU)'}\n"
            f"[bold]Eval:[/bold]       local (Claude-as-judge, no GPU cost)\n\n"
            f"[bold]gcloud command:[/bold]\n"
            f"[dim]gcloud compute instances create {self.vm_name} \\\\\n"
            f"  --project={getattr(self.provider, 'project', '?')} \\\\\n"
            f"  --zone={zone} \\\\\n"
            f"  --machine-type={machine_type} \\\\\n"
            f"  --accelerator=type={accel_type},count={accel_count} \\\\\n"
            f"  --image-family=pytorch-latest-gpu \\\\\n"
            f"  --image-project=deeplearning-platform-release \\\\\n"
            f"  --boot-disk-size={cloud_cfg.get('disk_gb', 100)}GB \\\\\n"
            f"  --labels=forge-managed=true,forge-run={self.vm_name} \\\\\n"
            f"  --maintenance-policy=TERMINATE[/dim]\n\n"
            f"[bold]Safety:[/bold] VM will only be deleted if label forge-managed=true is present",
            title="forge cloud-train --dry-run",
            border_style="yellow",
        ))

    # ── Interrupt / emergency cleanup ──────────────────────────────────────────

    def _handle_interrupt(self, signum, frame):
        console.print("\n[yellow]⚠ Interrupted — attempting artifact upload before cleanup...[/yellow]")
        self._emergency_cleanup()
        sys.exit(1)

    def _emergency_cleanup(self):
        if self._vm is None:
            return
        try:
            console.print("[yellow]Attempting emergency artifact upload...[/yellow]")
            self._upload_artifacts()
            console.print("[green]Artifacts saved to GCS.[/green]")
        except Exception as e:
            console.print(f"[red]Emergency upload failed: {e}[/red]")
            console.print(f"[red]VM '{self.vm_name}' NOT deleted — delete manually:[/red]")
            console.print(f"[dim]gcloud compute instances delete {self.vm_name} --quiet[/dim]")
            return

        if not self.keep_vm:
            try:
                self._delete_vm()
            except Exception as e:
                console.print(f"[red]VM deletion failed: {e}[/red]")
                console.print(f"[red]Delete manually: gcloud compute instances delete {self.vm_name} --quiet[/red]")

    # ── Utility ────────────────────────────────────────────────────────────────

    def _step(self, label: str, fn):
        with Progress(
            SpinnerColumn(),
            TextColumn(f"[bold]{label}[/bold]"),
            TimeElapsedColumn(),
            console=console,
            transient=True,
        ) as prog:
            prog.add_task(label, total=None)
            fn()
        console.print(f"  [green]✓[/green] {label}")
