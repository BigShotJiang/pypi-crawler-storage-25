"""forge — self-improving SLM training platform."""
__version__ = "0.3.0"
__all__ = ["__version__"]
