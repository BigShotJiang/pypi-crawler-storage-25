from __future__ import annotations

import json

from aicd.agent.chat_serialize import extract_fallback_tool_calls_from_content


def test_extract_fallback_tool_calls_from_xml_invoke_parameters() -> None:
    content = """
<think>internal reasoning</think>
<function_calls>
  <invoke name="pkg_file">
    <parameter name="python_packages">pytest,requests</parameter>
    <parameter name="pkg_file">requirements.txt</parameter>
  </invoke>
</function_calls>
"""
    calls = extract_fallback_tool_calls_from_content(content)
    assert len(calls) == 1
    fn = calls[0]["function"]
    assert fn["name"] == "pkg_file"
    args = json.loads(fn["arguments"])
    assert args["python_packages"] == "pytest,requests"
    assert args["pkg_file"] == "requirements.txt"


def test_extract_fallback_tool_calls_from_json_fence() -> None:
    content = """
```json
{
  "tool_calls": [
    {
      "id": "abc",
      "type": "function",
      "function": {
        "name": "task_list",
            "arguments": {"scope":"session"}
      }
    }
  ]
}
```
"""
    calls = extract_fallback_tool_calls_from_content(content)
    assert len(calls) == 1
    assert calls[0]["id"] == "abc"
    assert calls[0]["function"]["name"] == "task_list"


def test_extract_fallback_tool_calls_returns_empty_on_plain_text() -> None:
    content = "这是普通回答，不包含工具调用协议。"
    assert extract_fallback_tool_calls_from_content(content) == []
