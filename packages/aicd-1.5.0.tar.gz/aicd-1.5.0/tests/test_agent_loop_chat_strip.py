"""AgentLoop 新会话后消息链与裁剪逻辑。"""

from __future__ import annotations

from types import SimpleNamespace

from aicd.agent.loop import (
    _assistant_tool_calls,
    _tool_call_id_value,
    _trim_chat_messages_to_last_user_turn,
)


def test_trim_keeps_suffix_from_last_user() -> None:
    msgs = [
        {"role": "user", "content": "old"},
        {"role": "assistant", "content": "a"},
        {"role": "user", "content": "新会话"},
        {"role": "assistant", "content": "", "tool_calls": []},
        {"role": "tool", "tool_call_id": "x", "content": "{}"},
    ]
    _trim_chat_messages_to_last_user_turn(msgs)
    assert len(msgs) == 3
    assert msgs[0]["content"] == "新会话"


def test_trim_noop_when_only_one_user_at_start() -> None:
    msgs = [
        {"role": "user", "content": "hi"},
        {"role": "assistant", "content": "", "tool_calls": []},
    ]
    _trim_chat_messages_to_last_user_turn(msgs)
    assert len(msgs) == 2


def test_assistant_tool_calls_fallback_from_content() -> None:
    msg = SimpleNamespace(
        content=(
            "<function_calls>"
            '<invoke name="task_list"><parameter name="scope">session</parameter></invoke>'
            "</function_calls>"
        ),
        tool_calls=[],
    )
    calls = _assistant_tool_calls(msg)
    assert len(calls) == 1
    assert calls[0]["function"]["name"] == "task_list"


def test_tool_call_id_value_accepts_dict() -> None:
    assert _tool_call_id_value({"id": "abc"}) == "abc"
