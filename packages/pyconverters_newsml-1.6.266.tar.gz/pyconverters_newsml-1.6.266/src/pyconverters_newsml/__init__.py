"""NewsML converter (AFP news)"""

__version__ = "1.6.266"
