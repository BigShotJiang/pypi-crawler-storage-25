# Remote Desktop Dashboard

Browser-based dashboard to **monitor** and **connect** to ATC1–ATC10 machines. Replaces the legacy Remote Desktop Connection workflow with live status, machine locking, and one-click access via the [Microsoft Windows App](https://apps.microsoft.com/detail/9N1F85V9T8BN) — **no `.rdp` file download**.

## Features

- Live machine status (online/offline, users, MobaXterm, ETGui, cameras, COM tools)
- **Agentless monitoring** — one Windows server polls all benches (no install on each ATC PC)
- **Connect** opens Windows App via local launcher (`msrdc.exe` + temp `.rdp`)
- **Machine lock**: when you connect, the machine is reserved under your name; **Release** or auto-timeout frees it
- WebSocket live dashboard updates
- Manage machines in the browser (add / edit / delete)

## Architecture

```
Browser  ──Connect──►  Local launcher (127.0.0.1)  ──►  Windows App  ──RDP──►  ATC machine
   │
   └── REST + WebSocket ◄──►  Dashboard server (Windows)
                                    │
                                    └── remote poll: query user/session, tasklist
                                        (domain admin or RDD_MONITOR_* credentials)
```

| Command | Purpose |
|---------|---------|
| `remote-desktop-dashboard` | Start server + poller |
| `remote-desktop-dashboard-seed` | Add/update machines in DB |
| `rdd-agent` | *(optional)* legacy per-machine agent — not needed at scale |

## Quick start

```powershell
pip install -e .
remote-desktop-dashboard-seed --file data\machines.example.json
remote-desktop-dashboard
```

Open **http://127.0.0.1:8080/**

1. Enter **Your name** (used for locking).
2. Optionally enter **Windows login** (`DOMAIN\user`) — password is entered in Windows App.
3. Click **Connect** on a machine.

### Windows App setup

1. Install [Windows App from Microsoft Store](https://apps.microsoft.com/detail/9N1F85V9T8BN).
2. Set it as the default app for Remote Desktop / `rdp://` links (Windows Settings → Apps → Default apps).
3. When the browser asks to open a link, choose **Windows App** and allow the protocol.

## Machine locking

| Action | Behavior |
|--------|----------|
| **Connect** | Locks machine under your name, opens Windows App |
| **Release** | Frees the machine for others |
| **Heartbeat** | Sent every 60s while you hold the lock |
| **Auto-release** | After ~7 min without heartbeat (`RDD_LOCK_TIMEOUT_SECONDS` + grace) |
| **Leave page** | Sends release beacon for your locks |

If someone else holds the lock, Connect is disabled and you see **In use: *name***.

## Configuration

| Variable | Default | Description |
|----------|---------|-------------|
| `RDD_DATABASE_URL` | `sqlite:///./remote_desktop_dashboard.db` | Database |
| `RDD_HOST` / `RDD_PORT` | `0.0.0.0` / `8080` | Server bind |
| `RDD_LOCK_TIMEOUT_SECONDS` | `300` | Lock idle timeout |
| `RDD_USE_WINDOWS_APP` | `true` | Prefer `ms-rd:` over `rdp://` |
| `RDD_RDP_PORT` | `3389` | RDP port |
| `RDD_RDP_DEFAULT_DOMAIN` | *(empty)* | Prepended to username |
| `RDD_POLLER_ENABLED` | `true` | Server-side remote polling |
| `RDD_POLL_INTERVAL_SECONDS` | `45` | Seconds between poll cycles |
| `RDD_POLL_MAX_WORKERS` | `40` | Parallel remote probes per cycle |
| `RDD_POLL_TIMEOUT_SECONDS` | `8` | Per-host command timeout |
| `RDD_POLL_PREFER_IP` | `true` | Poll by IP instead of hostname |
| `RDD_MONITOR_DOMAIN` / `RDD_MONITOR_USERNAME` / `RDD_MONITOR_PASSWORD` | *(empty)* | Credentials for `query` / `tasklist` on remote hosts |

Copy `.env.example` and adjust for your domain. For **100–1000 benches**, increase interval and workers (e.g. `RDD_POLL_INTERVAL_SECONDS=90`, `RDD_POLL_MAX_WORKERS=80`).

### Agentless requirements

- Dashboard server must run on **Windows** (domain-joined recommended).
- Service account or `RDD_MONITOR_*` user needs rights to run remote `query user`, `query session`, and `tasklist` on each bench.
- Firewall: RPC, File and Printer Sharing, and RDP (3389) as needed.

## Insert machines (ATC1–ATC10)

```powershell
copy data\machines.example.json data\machines.json
# edit hostnames and IPs
remote-desktop-dashboard-seed --file data\machines.json
```

## Optional legacy agent

If remote polling is blocked on some hosts, you can still run `rdd-agent` on that PC — most deployments should use agentless polling only.

## API (connect & lock)

```http
POST /api/v1/machines/ATC1/connect
{"operator": "Alice", "rdp_username": "DOMAIN\\alice", "use_hostname": true}

POST /api/v1/machines/ATC1/lock/heartbeat
{"operator": "Alice"}

POST /api/v1/machines/ATC1/lock/release
{"operator": "Alice"}
```

Response includes `launch_uri` (Windows App) and `fallback_uri` (`rdp://`).

## Publish to PyPI

```powershell
pip install build twine
python -m build
python -m twine upload dist/*
pip install remote-desktop-dashboard
remote-desktop-dashboard
```

## License

MIT
