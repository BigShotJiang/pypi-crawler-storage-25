"""Machine lock CRUD for dashboard remote sessions."""

from datetime import datetime, timedelta, timezone

from sqlalchemy.orm import Session

from remote_desktop_dashboard.config import get_settings
from remote_desktop_dashboard.models.machine import Machine

settings = get_settings()


class LockError(Exception):
    def __init__(self, message: str, locked_by: str | None = None) -> None:
        super().__init__(message)
        self.locked_by = locked_by


def _now() -> datetime:
    return datetime.now(timezone.utc)


def _aware(dt: datetime | None) -> datetime | None:
    if dt is None:
        return None
    if dt.tzinfo is None:
        return dt.replace(tzinfo=timezone.utc)
    return dt


def is_lock_expired(machine: Machine) -> bool:
    if not machine.locked_by:
        return True
    hb = _aware(machine.lock_heartbeat_at) or _aware(machine.locked_at)
    if hb is None:
        return True
    grace = settings.lock_timeout_seconds + settings.lock_heartbeat_grace_seconds
    return (_now() - hb).total_seconds() > grace


def clear_lock(machine: Machine) -> None:
    machine.locked_by = None
    machine.locked_at = None
    machine.lock_heartbeat_at = None
    machine.lock_rdp_username = None


def refresh_expired_locks(db: Session) -> list[Machine]:
    from remote_desktop_dashboard.crud.machine import list_machines

    released: list[Machine] = []
    for machine in list_machines(db):
        if machine.locked_by and is_lock_expired(machine):
            clear_lock(machine)
            released.append(machine)
    if released:
        db.commit()
    return released


def acquire_lock(
    db: Session,
    machine: Machine,
    operator: str,
    rdp_username: str | None = None,
    force: bool = False,
) -> Machine:
    operator = operator.strip()
    if not operator:
        raise LockError("Operator name is required")

    refresh_expired_locks(db)
    db.refresh(machine)

    if machine.locked_by and machine.locked_by != operator and not is_lock_expired(machine):
        if not force:
            raise LockError(
                f"Machine is in use by {machine.locked_by}",
                locked_by=machine.locked_by,
            )

    now = _now()
    machine.locked_by = operator
    machine.locked_at = now
    machine.lock_heartbeat_at = now
    if rdp_username:
        machine.lock_rdp_username = rdp_username.strip()
    db.commit()
    db.refresh(machine)
    return machine


def heartbeat_lock(db: Session, machine: Machine, operator: str) -> Machine:
    if not machine.locked_by:
        raise LockError("Machine is not locked")
    if machine.locked_by != operator:
        raise LockError(
            f"Machine is locked by {machine.locked_by}",
            locked_by=machine.locked_by,
        )
    machine.lock_heartbeat_at = _now()
    db.commit()
    db.refresh(machine)
    return machine


def release_lock(db: Session, machine: Machine, operator: str) -> Machine:
    if not machine.locked_by:
        return machine
    if machine.locked_by != operator:
        raise LockError(
            f"Only {machine.locked_by} can release this lock",
            locked_by=machine.locked_by,
        )
    clear_lock(machine)
    db.commit()
    db.refresh(machine)
    return machine
