(function () {
  "use strict";

  const STORAGE_OPERATOR = "rdd_operator";
  const STORAGE_RDP_USER = "rdd_rdp_username";
  const HEARTBEAT_MS = 60000;

  const wsStatus = document.getElementById("ws-status");
  const lastUpdate = document.getElementById("last-update");
  const summary = document.getElementById("summary");
  const grid = document.getElementById("machine-grid");
  const machineCount = document.getElementById("machine-count");
  const operatorInput = document.getElementById("operator-name");
  const rdpUserInput = document.getElementById("rdp-username");
  const toastEl = document.getElementById("toast");

  let machines = [];
  let heartbeatTimers = {};

  operatorInput.value = localStorage.getItem(STORAGE_OPERATOR) || "";
  rdpUserInput.value = localStorage.getItem(STORAGE_RDP_USER) || "";
  operatorInput.addEventListener("change", savePrefs);
  rdpUserInput.addEventListener("change", savePrefs);

  function savePrefs() {
    localStorage.setItem(STORAGE_OPERATOR, operatorInput.value.trim());
    localStorage.setItem(STORAGE_RDP_USER, rdpUserInput.value.trim());
  }

  function getOperator() {
    return operatorInput.value.trim();
  }

  function getRdpUsername() {
    const v = rdpUserInput.value.trim();
    return v || null;
  }

  function wsUrl() {
    const proto = location.protocol === "https:" ? "wss:" : "ws:";
    return proto + "//" + location.host + "/ws/dashboard";
  }

  function showToast(msg, isError) {
    toastEl.textContent = msg;
    toastEl.className = "toast" + (isError ? " toast-error" : "");
    setTimeout(function () {
      toastEl.className = "toast hidden";
    }, 5000);
  }

  const launchModal = document.getElementById("launch-modal");
  const launchTarget = document.getElementById("launch-target");
  const launchHint = document.getElementById("launch-hint");
  const launchRdpLink = document.getElementById("launch-rdp-link");
  const launchTryLocal = document.getElementById("launch-try-local");
  const launchCopyMstsc = document.getElementById("launch-copy-mstsc");
  const launchDownloadRdp = document.getElementById("launch-download-rdp");
  const launchClose = document.getElementById("launch-close");
  const launchBackdrop = document.getElementById("launch-backdrop");
  const useIpCheckbox = document.getElementById("use-ip");

  let lastLaunchData = null;

  function hideLaunchModal() {
    launchModal.className = "modal hidden";
    lastLaunchData = null;
  }

  function showLaunchModal(data) {
    lastLaunchData = data;
    launchTarget.textContent = data.machine_name + " (" + data.target_host + ")";
    launchHint.textContent =
      data.message ||
      "Launch on this PC, or download .rdp (uses each PC's own Windows App / msrdc).";
    launchRdpLink.href = data.launch_uri || data.rdp_uri || "#";
    if (launchDownloadRdp && data.rdp_download_url) {
      launchDownloadRdp.href = data.rdp_download_url;
      launchDownloadRdp.classList.remove("hidden");
    } else if (launchDownloadRdp) {
      launchDownloadRdp.classList.add("hidden");
    }
    launchModal.className = "modal";
  }

  function mergeMachineUpdate(updated) {
    if (!updated || !updated.name) return;
    const idx = machines.findIndex(function (m) {
      return m.name === updated.name;
    });
    if (idx >= 0) {
      machines[idx] = updated;
    } else {
      machines.push(updated);
    }
    render(machines);
  }

  async function tryLocalLaunch(url) {
    if (!url) return null;
    try {
      const r = await fetch(url, { method: "GET", mode: "cors" });
      if (!r.ok) return null;
      return r.json().catch(function () {
        return { ok: true, client: "unknown" };
      });
    } catch (e) {
      return null;
    }
  }

  function launchToast(client, target) {
    const dest = target ? " to " + target : "";
    if (client === "windows_app" || client === "windows365" || client === "msrdc") {
      showToast("Connecting directly" + dest + " via Windows App…", false);
    } else if (client === "mstsc") {
      showToast("Opening legacy Remote Desktop (mstsc). Install Windows App or set RDD_MSRDC_PATH.", true);
    } else {
      showToast("Opening remote session…", false);
    }
  }

  async function launchRemoteSession(data) {
    if (data.local_launch_url) {
      const result = await tryLocalLaunch(data.local_launch_url);
      if (result && result.ok !== false) {
        launchToast(result.client || data.client, data.target_host);
        return true;
      }
    }
    showLaunchModal(data);
    showToast(data.message || "Click Launch Windows App in the dialog.", false);
    return false;
  }

  function on(el, event, fn) {
    if (el) el.addEventListener(event, fn);
  }

  on(launchTryLocal, "click", async function () {
    if (!lastLaunchData) return;
    if (lastLaunchData.local_launch_url) {
      const result = await tryLocalLaunch(lastLaunchData.local_launch_url);
      if (result && result.ok !== false) {
        launchToast(result.client || lastLaunchData.client, lastLaunchData.target_host);
        hideLaunchModal();
        return;
      }
    }
    showToast(
      "Could not launch via Windows App. Set RDD_MSRDC_PATH in .env to msrdc.exe on this PC.",
      true
    );
  });

  on(launchCopyMstsc, "click", function () {
    if (!lastLaunchData || !lastLaunchData.mstsc_command) return;
    navigator.clipboard.writeText(lastLaunchData.mstsc_command).then(function () {
      showToast("Copied: " + lastLaunchData.mstsc_command, false);
    });
  });

  on(launchClose, "click", hideLaunchModal);
  on(launchBackdrop, "click", hideLaunchModal);

  function fmt(value, fallback) {
    if (value === null || value === undefined || value === "") {
      return fallback || "\u2014";
    }
    if (Array.isArray(value)) {
      return value.length ? value.join(", ") : fallback || "\u2014";
    }
    return String(value);
  }

  function escapeHtml(s) {
    const d = document.createElement("div");
    d.textContent = s;
    return d.innerHTML;
  }

  function renderSummary(list) {
    const online = list.filter(function (m) {
      return m.is_online;
    }).length;
    const locked = list.filter(function (m) {
      return m.is_locked;
    }).length;
    summary.innerHTML = [
      statCard(online, "Online"),
      statCard(list.length - online, "Offline"),
      statCard(locked, "In use"),
      statCard(list.length, "Total"),
    ].join("");
    machineCount.textContent = list.length + " machine(s)";
  }

  function statCard(value, label) {
    return (
      '<div class="stat-card"><div class="value">' +
      value +
      '</div><div class="label">' +
      label +
      "</div></div>"
    );
  }

  function row(label, value, active) {
    const display = fmt(value, "\u2014");
    const cls =
      "row-value" + (display === "\u2014" ? " empty" : active ? " active" : "");
    return (
      '<div class="row"><span class="row-label">' +
      escapeHtml(label) +
      '</span><span class="' +
      cls +
      '">' +
      escapeHtml(display) +
      "</span></div>"
    );
  }

  function lockBadge(m) {
    if (!m.is_locked || !m.locked_by) return "";
    const mine = getOperator() && m.locked_by === getOperator();
    return (
      '<div class="lock-badge' +
      (mine ? " lock-mine" : "") +
      '">In use: <strong>' +
      escapeHtml(m.locked_by) +
      "</strong></div>"
    );
  }

  function actionButtons(m) {
    const op = getOperator();
    const mine = m.is_locked && m.locked_by === op;
    const canConnect = m.lock_available && op;

    let html = '<div class="card-actions">';
    if (canConnect) {
      html +=
        '<button type="button" class="btn btn-primary" data-action="connect" data-name="' +
        escapeHtml(m.name) +
        '">Connect</button>';
    } else if (mine) {
      html +=
        '<button type="button" class="btn btn-primary" data-action="connect" data-name="' +
        escapeHtml(m.name) +
        '">Reconnect</button>';
      html +=
        '<button type="button" class="btn btn-secondary" data-action="release" data-name="' +
        escapeHtml(m.name) +
        '">Release</button>';
    } else if (m.is_locked) {
      html += '<button type="button" class="btn btn-disabled" disabled>Locked</button>';
    } else {
      html +=
        '<button type="button" class="btn btn-disabled" disabled title="Enter your name above">Connect</button>';
    }
    html += "</div>";
    return html;
  }

  function statusDotClass(label) {
    if (label === "in_use") return "in_use";
    if (label === "online" || label === "reachable") return "online";
    if (label === "unknown") return "unknown";
    return "offline";
  }

  function renderMachine(m) {
    const label = m.status_label || (m.is_online ? "online" : "offline");
    const display = m.status_display || (m.is_online ? "Online" : "Offline");
    const up =
      m.is_online ||
      label === "online" ||
      label === "reachable" ||
      label === "in_use";
    const cardClass =
      "machine-card" +
      (up ? "" : " offline") +
      (m.is_locked ? " locked in-use" : "") +
      (label === "in_use" ? " in-use" : "");

    const lockRows = [];
    if (m.is_locked && m.locked_by) {
      lockRows.push(row("In use by", m.locked_by, true));
    }
    if (m.lock_rdp_username) {
      lockRows.push(row("RDP login", m.lock_rdp_username, true));
    }

    const sessionRows = [
      row("Local user", m.local_user, !!m.local_user),
      row("RDP users", fmt(m.rdp_users), m.rdp_users && m.rdp_users.length),
      row(
        "Windows App",
        fmt(m.windows_app_users),
        m.windows_app_users && m.windows_app_users.length
      ),
      row("MobaXterm", m.mobaxterm_user, !!m.mobaxterm_user),
      row("COM / serial", m.com_port_user, !!m.com_port_user),
      row("ETGui.exe", m.etgui_user, !!m.etgui_user),
      row("Camera user", m.camera_user, !!m.camera_user),
      row(
        "Camera tools",
        fmt(m.camera_tools),
        m.camera_tools && m.camera_tools.length
      ),
    ].join("");

    let sessionHint = "";
    if (m.session_message) {
      sessionHint =
        '<p class="session-hint">' + escapeHtml(m.session_message) + "</p>";
    } else if (!m.has_session_data && !m.agent_has_data && (m.is_reachable || m.is_online)) {
      sessionHint =
        '<p class="session-hint">Online — click <strong>Refresh session</strong> to load user/tool details.</p>';
    }

    let lockBlock = "";
    if (lockRows.length) {
      lockBlock =
        '<div class="rows-block"><div class="rows-title">Dashboard lock</div>' +
        lockRows.join("") +
        "</motion-wrap>";
      lockBlock = lockBlock.replace("</motion-wrap>", "</div>");
    }
    const sessionBody =
      '<div class="rows-block"><div class="rows-title">Session on bench</div>' +
      sessionHint +
      sessionRows +
      "</div>";

    return (
      '<article class="' +
      cardClass +
      '" data-name="' +
      escapeHtml(m.name) +
      '">' +
      '<div class="card-header">' +
      "<div>" +
      '<div class="machine-name">' +
      escapeHtml(m.name) +
      "</div>" +
      lockBadge(m) +
      '<div class="machine-host">' +
      escapeHtml(m.hostname) +
      " \u00b7 " +
      escapeHtml(m.ip_address) +
      "</div></div>" +
      "<div>" +
      '<span class="status-dot ' +
      statusDotClass(label) +
      '"></span>' +
      '<span class="status-label' +
      (label === "in_use" ? " in-use" : "") +
      '">' +
      escapeHtml(display) +
      "</span>" +
      (m.last_seen_relative
        ? '<div class="muted small">' +
          escapeHtml(m.last_seen_relative) +
          "</div>"
        : "") +
      "</div></div>" +
      actionButtons(m) +
      '<div class="card-admin">' +
      '<button type="button" class="btn btn-secondary btn-sm" data-action="poll" data-name="' +
      escapeHtml(m.name) +
      '">Refresh session</button>' +
      '<button type="button" class="btn btn-secondary btn-sm" data-action="edit" data-id="' +
      m.id +
      '" data-name="' +
      escapeHtml(m.name) +
      '">Edit</button>' +
      '<button type="button" class="btn btn-secondary btn-sm" data-action="delete" data-name="' +
      escapeHtml(m.name) +
      '">Delete</button>' +
      "</div>" +
      lockBlock +
      sessionBody +
      "</article>"
    );
  }

  function render(list) {
    machines = list;
    list.sort(function (a, b) {
      return a.name.localeCompare(b.name, undefined, { numeric: true });
    });
    renderSummary(list);
    grid.innerHTML = list.map(renderMachine).join("");
    lastUpdate.textContent = "Updated " + new Date().toLocaleTimeString();
  }

  function setWsStatus(state, text) {
    wsStatus.className = "badge badge-" + state;
    wsStatus.textContent = text;
  }

  function startHeartbeat(name) {
    stopHeartbeat(name);
    heartbeatTimers[name] = setInterval(function () {
      const op = getOperator();
      if (!op) return;
      fetch("/api/v1/machines/" + encodeURIComponent(name) + "/lock/heartbeat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ operator: op }),
      }).catch(function () {});
    }, HEARTBEAT_MS);
  }

  function stopHeartbeat(name) {
    if (heartbeatTimers[name]) {
      clearInterval(heartbeatTimers[name]);
      delete heartbeatTimers[name];
    }
  }

  function stopAllHeartbeats() {
    Object.keys(heartbeatTimers).forEach(stopHeartbeat);
  }

  async function connectMachine(name) {
    const op = getOperator();
    if (!op) {
      showToast("Enter your name before connecting.", true);
      operatorInput.focus();
      return;
    }
    savePrefs();
    try {
      const res = await fetch(
        "/api/v1/machines/" + encodeURIComponent(name) + "/connect",
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            operator: op,
            rdp_username: getRdpUsername(),
            use_hostname: !useIpCheckbox || !useIpCheckbox.checked,
          }),
        }
      );
      const data = await res.json();
      if (!res.ok) {
        showToast(data.detail || "Cannot connect", true);
        return;
      }
      if (data.machine) mergeMachineUpdate(data.machine);
      else loadDashboard();
      startHeartbeat(name);
      await launchRemoteSession(data);
      loadDashboard();
      setTimeout(function () {
        pollMachine(name);
      }, 1500);
      setTimeout(loadDashboard, 5000);
    } catch (e) {
      showToast("Connection failed: " + e.message, true);
    }
  }

  async function pollMachine(name) {
    const op = getOperator();
    const q = op ? "?operator=" + encodeURIComponent(op) : "";
    showToast("Refreshing session for " + name + "…", false);
    try {
      const res = await fetch(
        "/api/v1/machines/" + encodeURIComponent(name) + "/poll-now" + q,
        { method: "POST" }
      );
      const data = await res.json();
      if (!res.ok) {
        showToast(data.detail || "Poll failed", true);
        return;
      }
      if (data.machine) mergeMachineUpdate(data.machine);
      if (data.ok) showToast("Session updated for " + name, false);
      else showToast(data.error || "Poll failed — check server credentials", true);
      loadDashboard();
    } catch (e) {
      showToast("Poll failed: " + e.message, true);
    }
  }

  async function releaseMachine(name) {
    const op = getOperator();
    if (!op) return;
    try {
      const res = await fetch(
        "/api/v1/machines/" + encodeURIComponent(name) + "/lock/release",
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ operator: op }),
        }
      );
      if (!res.ok) {
        const data = await res.json();
        showToast(data.detail || "Release failed", true);
        return;
      }
      stopHeartbeat(name);
      showToast("Released " + name, false);
      loadDashboard();
    } catch (e) {
      showToast("Release failed", true);
    }
  }

  function loadDashboard() {
    const op = getOperator();
    const q = op ? "?operator=" + encodeURIComponent(op) : "";
    const ctrl = new AbortController();
    const timer = setTimeout(function () {
      ctrl.abort();
    }, 20000);
    return fetch("/api/v1/dashboard" + q, { signal: ctrl.signal })
      .then(function (r) {
        clearTimeout(timer);
        if (!r.ok) throw new Error("HTTP " + r.status);
        return r.json();
      })
      .then(function (data) {
        if (data.machines) {
          render(data.machines);
          setWsStatus("ok", "Ready");
        }
      })
      .catch(function (err) {
        clearTimeout(timer);
        if (err.name === "AbortError") {
          setWsStatus("err", "Server slow");
          grid.innerHTML =
            '<p class="muted">Dashboard timed out. Stop any old server, then run:<br><code>remote-desktop-dashboard --no-poller --no-reachability</code></p>';
        } else {
          setWsStatus("err", "Offline");
          grid.innerHTML =
            '<p class="muted">Could not load dashboard. Is the server running?</p>';
        }
      });
  }

  const toggleManage = document.getElementById("toggle-manage");
  const manageBox = document.getElementById("manage-box");
  const machineForm = document.getElementById("machine-form");
  const editMachineId = document.getElementById("edit-machine-id");
  const mfName = document.getElementById("mf-name");
  const mfHostname = document.getElementById("mf-hostname");
  const mfIp = document.getElementById("mf-ip");
  const mfCancel = document.getElementById("mf-cancel");

  toggleManage.addEventListener("click", function () {
    manageBox.classList.toggle("hidden");
  });

  function resetMachineForm() {
    editMachineId.value = "";
    mfName.value = "";
    mfName.disabled = false;
    mfHostname.value = "";
    mfIp.value = "";
  }

  function fillMachineForm(m) {
    editMachineId.value = String(m.id);
    mfName.value = m.name;
    mfName.disabled = true;
    mfHostname.value = m.hostname;
    mfIp.value = m.ip_address;
    manageBox.classList.remove("hidden");
    mfHostname.focus();
  }

  mfCancel.addEventListener("click", resetMachineForm);

  machineForm.addEventListener("submit", async function (ev) {
    ev.preventDefault();
    const payload = {
      name: mfName.value.trim().toUpperCase(),
      hostname: mfHostname.value.trim(),
      ip_address: mfIp.value.trim(),
    };
    const id = editMachineId.value;
    try {
      let res;
      if (id) {
        res = await fetch("/api/v1/machines/" + id, {
          method: "PATCH",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ hostname: payload.hostname, ip_address: payload.ip_address }),
        });
      } else {
        res = await fetch("/api/v1/machines", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
        });
      }
      const data = await res.json().catch(function () {
        return {};
      });
      if (!res.ok) {
        showToast(data.detail || "Save failed", true);
        return;
      }
      showToast(id ? "Updated " + payload.name : "Created " + payload.name, false);
      resetMachineForm();
      loadDashboard();
    } catch (e) {
      showToast("Save failed", true);
    }
  });

  async function deleteMachineByName(name) {
    if (!confirm("Delete machine " + name + " from the dashboard?")) return;
    try {
      const res = await fetch(
        "/api/v1/machines/by-name/" + encodeURIComponent(name),
        { method: "DELETE" }
      );
      if (!res.ok) {
        const data = await res.json().catch(function () {
          return {};
        });
        showToast(data.detail || "Delete failed", true);
        return;
      }
      showToast("Deleted " + name, false);
      loadDashboard();
    } catch (e) {
      showToast("Delete failed", true);
    }
  }

  grid.addEventListener("click", function (ev) {
    const btn = ev.target.closest("button[data-action]");
    if (!btn) return;
    const name = btn.getAttribute("data-name");
    const action = btn.getAttribute("data-action");
    if (action === "connect") connectMachine(name);
    if (action === "poll") pollMachine(name);
    if (action === "release") releaseMachine(name);
    if (action === "delete") deleteMachineByName(name);
    if (action === "edit") {
      const m = machines.find(function (x) {
        return x.name === name;
      });
      if (m) fillMachineForm(m);
    }
  });

  window.addEventListener("beforeunload", function () {
    const op = getOperator();
    machines.forEach(function (m) {
      if (m.locked_by === op) {
        navigator.sendBeacon(
          "/api/v1/machines/" +
            encodeURIComponent(m.name) +
            "/lock/release",
          new Blob([JSON.stringify({ operator: op })], {
            type: "application/json",
          })
        );
      }
    });
    stopAllHeartbeats();
  });

  function connect() {
    const socket = new WebSocket(wsUrl());
    socket.onopen = function () {
      setWsStatus("ok", "Live");
    };
    socket.onmessage = function (event) {
      try {
        const data = JSON.parse(event.data);
        if (data.type === "machines_update" && Array.isArray(data.machines)) {
          render(data.machines);
          setWsStatus("ok", "Live");
        }
      } catch (e) {
        console.warn("WS parse error", e);
      }
    };
    socket.onclose = function () {
      setWsStatus("warn", "Reconnecting…");
      setTimeout(connect, 3000);
    };
    socket.onerror = function () {
      setWsStatus("warn", "WS error — using REST");
    };
    setInterval(function () {
      if (socket.readyState === WebSocket.OPEN) socket.send("ping");
    }, 25000);
  }

  function refreshIntervalMs() {
    const op = getOperator();
    const mine = machines.some(function (m) {
      return m.is_locked && m.locked_by === op;
    });
    return mine ? 8000 : 20000;
  }

  let refreshTimer = null;
  function scheduleRefresh() {
    if (refreshTimer) clearInterval(refreshTimer);
    refreshTimer = setInterval(function () {
      loadDashboard();
      scheduleRefresh();
    }, refreshIntervalMs());
  }

  grid.innerHTML = '<p class="muted">Loading machines…</p>';
  setWsStatus("warn", "Loading…");
  loadDashboard().finally(function () {
    setTimeout(connect, 1500);
    scheduleRefresh();
  });
})();
