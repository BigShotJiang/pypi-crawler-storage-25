from remote_desktop_dashboard.models.machine import Machine

__all__ = ["Machine"]
