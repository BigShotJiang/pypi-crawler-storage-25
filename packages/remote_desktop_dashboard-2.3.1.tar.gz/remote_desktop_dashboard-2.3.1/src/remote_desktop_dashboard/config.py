"""Application configuration."""

from functools import lru_cache
from pathlib import Path

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_prefix="RDD_",
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )

    database_url: str = "sqlite:///./remote_desktop_dashboard.db"
    host: str = "0.0.0.0"
    port: int = 8080
    reload: bool = False
    offline_threshold_seconds: int = 90
    reachability_check: bool = True
    reachability_on_api: bool = True
    reachability_background: bool = True
    reachability_cache_seconds: int = 30
    reachability_timeout_seconds: float = 1.5
    reachability_max_workers: int = 8
    agent_api_key: str = ""
    static_dir: Path | None = None
    open_browser: bool = True
    auto_seed: bool = True

    # Machine lock (dashboard operator owns a machine while connected)
    lock_timeout_seconds: int = 300
    lock_heartbeat_grace_seconds: int = 120

    # Remote Desktop / Windows App connection
    rdp_port: int = 3389
    rdp_default_domain: str = ""
    # Local mstsc launcher (http://127.0.0.1:PORT/connect) — reliable credential prompt on Windows
    local_launcher_enabled: bool = True
    local_launcher_port: int = 9876
    # windows_app = msrdc.exe (Store Windows App), mstsc = legacy client, auto = msrdc if installed
    preferred_rdp_client: str = "windows_app"
    msrdc_path: str = ""
    # True = show credential prompt; False = use saved Windows creds only (prompt for credentials:i:0)
    rdp_prompt_credentials: bool = True

    # Agentless remote polling (no rdd-agent on benches)
    poller_enabled: bool = True
    poll_interval_seconds: int = 120
    poll_startup_delay_seconds: int = 30
    poll_max_workers: int = 1
    poll_timeout_seconds: float = 120.0
    poll_ping_timeout_seconds: float = 3.0
    poll_skip_unreachable: bool = False
    poll_prefer_ip: bool = True
    # Optional domain credentials (leave empty to use logged-on server account)
    monitor_username: str = ""
    monitor_password: str = ""
    monitor_domain: str = ""

    @property
    def resolved_static_dir(self) -> Path:
        if self.static_dir:
            return self.static_dir
        return Path(__file__).parent / "static"


@lru_cache
def get_settings() -> Settings:
    return Settings()
