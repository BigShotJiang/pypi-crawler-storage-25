"""Resolve Windows system utilities with full paths (works when System32 is not on PATH)."""

from __future__ import annotations

import os
import subprocess
from pathlib import Path

CREATE_NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)


def system32_dir() -> Path:
    root = os.environ.get("SystemRoot") or os.environ.get("WINDIR") or r"C:\Windows"
    return Path(root) / "System32"


def system32_exe(*candidates: str) -> str:
    """Return the first existing executable under System32."""
    folder = system32_dir()
    for name in candidates:
        path = folder / name
        if path.is_file():
            return str(path)
    tried = ", ".join(candidates)
    raise FileNotFoundError(
        f"None of [{tried}] found in {folder}. "
        "Remote polling needs quser.exe/qwinsta.exe or query.exe, or falls back to tasklist only."
    )


def run_cmd(args: list[str], timeout: float) -> str:
    """Run a command; return stdout. Raises on total failure."""
    if args and not Path(args[0]).is_file() and "\\" not in args[0] and "/" not in args[0]:
        # Bare name like "net" — still try; caller should pass system32_exe when possible.
        pass
    result = subprocess.run(
        args,
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
        timeout=timeout,
        creationflags=CREATE_NO_WINDOW,
        shell=False,
    )
    out = (result.stdout or "").strip()
    err = (result.stderr or "").strip()
    if result.returncode != 0 and not out:
        raise RuntimeError(err or f"Command failed (exit {result.returncode}): {' '.join(args)}")
    return result.stdout
