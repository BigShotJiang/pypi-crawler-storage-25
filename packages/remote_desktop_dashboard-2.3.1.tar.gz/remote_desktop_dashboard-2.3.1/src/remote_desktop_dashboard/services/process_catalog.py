"""Shared process/session analysis for local and remote monitoring."""

from __future__ import annotations

from dataclasses import dataclass

ETGUI_NAMES = {"etgui.exe"}
MOBAXTERM_NAMES = {"mobaxterm.exe", "mobaxterm personal edition.exe"}
WINDOWS_APP_NAMES = {"msrdc.exe", "msrdcw.exe", "windowsterminal.exe"}
RDP_PROCESS_HINTS = {"rdpclip.exe", "rdpinput.exe", "mstsc.exe"}
CAMERA_PROCESS_NAMES = {
    "windowscamera.exe",
    "camera.exe",
    "webcam.exe",
    "obs64.exe",
    "obs32.exe",
    "manycam.exe",
    "yawcam.exe",
}
CAMERA_PYTHON_HINTS = ("opencv", "cv2", "pyqt5", "pyside2", "picamera")
COM_PORT_PROCESS_NAMES = {
    "putty.exe",
    "teraterm.exe",
    "ttermpro.exe",
    "securecrt.exe",
    "hyperterminal.exe",
    "realterm.exe",
    "docklight.exe",
    "hercules.exe",
    "com0com.exe",
}
COM_PORT_CMDLINE_HINTS = ("com", "serial", "\\\\.\\com")


@dataclass
class ProcessInfo:
    name: str
    username: str | None
    pid: int
    cmdline: str
    session: str | None = None


def normalize_user(username: str | None) -> str | None:
    if not username:
        return None
    if "\\" in username:
        return username.split("\\", 1)[-1]
    return username


def analyze_sessions_and_processes(
    sessions: list[dict[str, str]],
    session_types: dict[str, str],
    processes: list[ProcessInfo],
) -> dict:
    active_users = [
        s["username"]
        for s in sessions
        if s.get("state", "").lower() in ("active", "running", "connected")
        and s.get("username")
    ]

    local_user = active_users[0] if active_users else None

    rdp_users: set[str] = set()
    windows_app_users: set[str] = set()

    for s in sessions:
        user = s.get("username")
        if not user:
            continue
        sess = (s.get("session") or "").lower()
        stype = session_types.get(user, session_types.get(s.get("session", ""), ""))
        if "rdp" in sess or "rdp-tcp" in sess or stype in ("10", "rdp"):
            rdp_users.add(user)
        if any(p.name in WINDOWS_APP_NAMES for p in processes if p.username == user):
            windows_app_users.add(user)

    for proc in processes:
        if proc.name in RDP_PROCESS_HINTS and proc.username:
            rdp_users.add(proc.username)
        if proc.name in WINDOWS_APP_NAMES and proc.username:
            windows_app_users.add(proc.username)

    camera_user, camera_tools = _detect_camera(processes)

    return {
        "local_user": local_user,
        "rdp_users": sorted(rdp_users),
        "windows_app_users": sorted(windows_app_users),
        "mobaxterm_user": _owner_for_processes(processes, MOBAXTERM_NAMES),
        "com_port_user": _detect_com_port_user(processes),
        "etgui_user": _owner_for_processes(processes, ETGUI_NAMES),
        "camera_user": camera_user,
        "camera_tools": camera_tools,
    }


def _owner_for_processes(processes: list[ProcessInfo], names: set[str]) -> str | None:
    for proc in processes:
        if proc.name in names and proc.username:
            return proc.username
    return None


def _detect_com_port_user(processes: list[ProcessInfo]) -> str | None:
    for proc in processes:
        if proc.name in COM_PORT_PROCESS_NAMES and proc.username:
            return proc.username
        if proc.username and any(h in proc.cmdline for h in COM_PORT_CMDLINE_HINTS):
            if proc.name in MOBAXTERM_NAMES:
                continue
            return proc.username
    return None


def _detect_camera(processes: list[ProcessInfo]) -> tuple[str | None, list[str]]:
    tools: list[str] = []
    user: str | None = None
    for proc in processes:
        matched = False
        if proc.name in CAMERA_PROCESS_NAMES:
            tools.append(proc.name)
            matched = True
        elif proc.name.startswith("python") and any(h in proc.cmdline for h in CAMERA_PYTHON_HINTS):
            tools.append(f"python-camera ({proc.pid})")
            matched = True
        if matched and proc.username:
            user = proc.username
    return user, sorted(set(tools))
