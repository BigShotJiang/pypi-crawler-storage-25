"""Dashboard presentation helpers."""

import json
from datetime import datetime, timezone

from remote_desktop_dashboard.crud.lock import is_lock_expired
from remote_desktop_dashboard.models.machine import Machine
from remote_desktop_dashboard.schemas.machine import DashboardMachine, MachineRead


def _relative_time(dt: datetime | None) -> str | None:
    if dt is None:
        return None
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    now = datetime.now(timezone.utc)
    seconds = int((now - dt).total_seconds())
    if seconds < 60:
        return f"{seconds}s ago"
    if seconds < 3600:
        return f"{seconds // 60}m ago"
    return f"{seconds // 3600}h ago"


def _poll_error(machine: Machine) -> str | None:
    if not machine.raw_report:
        return None
    try:
        data = json.loads(machine.raw_report)
        if isinstance(data, dict) and data.get("error"):
            return str(data["error"])
    except json.JSONDecodeError:
        pass
    return None


def _session_message(
    machine: Machine, is_reachable: bool, has_data: bool
) -> str | None:
    if has_data:
        return None
    err = _poll_error(machine)
    if err:
        return f"Session poll failed: {err}"
    if is_reachable:
        return (
            "Host is online (RDP port open). Click Refresh session or enable "
            "poller with RDD_MONITOR_* credentials on the server."
        )
    return "Host offline — no session data."


def _has_monitor_data(machine: Machine) -> bool:
    if machine.last_seen is None:
        return False
    if machine.local_user:
        return True
    for field in (machine.rdp_users, machine.windows_app_users, machine.camera_tools):
        if field and field not in ("[]", ""):
            return True
    return bool(
        machine.mobaxterm_user
        or machine.etgui_user
        or machine.com_port_user
        or machine.camera_user
    )


def _compute_status(
    machine: Machine,
    is_reachable: bool,
    current_operator: str | None = None,
) -> tuple[str, str, bool]:
    locked = bool(machine.locked_by) and not is_lock_expired(machine)
    if locked:
        if current_operator and machine.locked_by == current_operator:
            return "in_use", "In use by you", True
        return "in_use", f"In use: {machine.locked_by}", True

    polled = machine.last_seen is not None and machine.is_online
    has_data = _has_monitor_data(machine)

    if is_reachable:
        if polled and has_data:
            return "online", "Online", True
        return "online", "Online", True

    if polled and has_data:
        return "offline", "Offline (stale data)", False

    return "offline", "Offline", False


def to_dashboard_machine(
    machine: Machine,
    current_operator: str | None = None,
    is_reachable: bool = False,
) -> DashboardMachine:
    base = MachineRead.model_validate(machine)
    status_label, status_display, show_as_up = _compute_status(
        machine, is_reachable, current_operator
    )
    locked = bool(machine.locked_by) and not is_lock_expired(machine)
    lock_available = not locked or (
        current_operator is not None and machine.locked_by == current_operator
    )
    polled = machine.last_seen is not None
    has_data = _has_monitor_data(machine)

    data = base.model_dump()
    data.update(
        {
            "is_online": show_as_up,
            "status_label": status_label,
            "status_display": status_display,
            "is_reachable": is_reachable,
            "agent_online": polled and machine.is_online,
            "agent_reporting": polled,
            "agent_has_data": has_data,
            "has_session_data": has_data,
            "poll_error": _poll_error(machine),
            "session_message": _session_message(machine, is_reachable, has_data),
            "last_seen_relative": _relative_time(machine.last_seen),
            "is_locked": locked,
            "lock_available": lock_available,
        }
    )
    return DashboardMachine(**data)


def machines_payload(
    machines: list[Machine],
    current_operator: str | None = None,
    reachability: dict[str, bool] | None = None,
) -> dict:
    reachability = reachability or {}
    rows = [
        to_dashboard_machine(
            m, current_operator, reachability.get(m.name, False)
        ).model_dump(mode="json")
        for m in machines
    ]
    return {"type": "machines_update", "machines": rows}
