"""
Agentless remote monitoring from the dashboard server (Windows).

Uses remote tasklist and optionally quser/qwinsta. Skips slow tasklist when host is down.
"""

from __future__ import annotations

import csv
import io
import logging
import re
import sys
import threading
from contextlib import contextmanager
from typing import Any

from remote_desktop_dashboard.agent.monitor import MonitorSnapshot
from remote_desktop_dashboard.config import get_settings
from remote_desktop_dashboard.services.process_catalog import (
    ProcessInfo,
    analyze_sessions_and_processes,
    normalize_user,
)
from remote_desktop_dashboard.services.reachability import check_host_reachable
from remote_desktop_dashboard.services.windows_cmd import run_cmd, system32_exe

logger = logging.getLogger(__name__)

_net_use_lock = threading.Lock()


def _parse_query_user(text: str) -> list[dict[str, str]]:
    sessions: list[dict[str, str]] = []
    for line in text.splitlines()[1:]:
        line = line.strip()
        if not line:
            continue
        if line.startswith(">"):
            line = line[1:].strip()
        parts = re.split(r"\s{2,}|\s+", line)
        if len(parts) < 4:
            continue
        username = parts[0].lstrip(">")
        sessions.append(
            {
                "username": normalize_user(username) or username,
                "session": parts[1] if len(parts) > 1 else "",
                "state": parts[3] if len(parts) > 3 else "",
            }
        )
    return sessions


def _parse_query_session(text: str) -> dict[str, str]:
    mapping: dict[str, str] = {}
    for line in text.splitlines()[1:]:
        parts = line.split()
        if len(parts) < 4:
            continue
        session_name = parts[0].lstrip(">")
        username = parts[1] if parts[1] != "." else ""
        session_type = parts[2] if len(parts) > 2 else ""
        if username and username != "services":
            mapping[normalize_user(username) or username] = session_type
        if session_name:
            mapping[session_name.lower()] = session_type
    return mapping


def _monitor_user() -> str | None:
    settings = get_settings()
    if not settings.monitor_username:
        return None
    user = settings.monitor_username
    if settings.monitor_domain and "\\" not in user:
        return f"{settings.monitor_domain}\\{user}"
    return user


@contextmanager
def _remote_auth(host: str, timeout: float):
    settings = get_settings()
    user = _monitor_user()
    if not user or not settings.monitor_password:
        yield
        return

    unc = f"\\\\{host}\\IPC$"
    net_exe: str | None = None
    with _net_use_lock:
        try:
            net_exe = system32_exe("net.exe")
            run_cmd(
                [net_exe, "use", unc, settings.monitor_password, f"/user:{user}"],
                timeout,
            )
            yield
        finally:
            if net_exe:
                try:
                    run_cmd([net_exe, "use", unc, "/delete", "/y"], timeout)
                except Exception:
                    pass


def _remote_query_user(host: str, timeout: float) -> list[dict[str, str]]:
    try:
        quser = system32_exe("quser.exe")
        out = run_cmd([quser, f"/server:{host}"], timeout)
        return _parse_query_user(out)
    except FileNotFoundError:
        pass
    query = system32_exe("query.exe")
    out = run_cmd([query, "user", f"/server:{host}"], timeout)
    return _parse_query_user(out)


def _remote_query_session(host: str, timeout: float) -> dict[str, str]:
    try:
        qwinsta = system32_exe("qwinsta.exe")
        out = run_cmd([qwinsta, f"/server:{host}"], timeout)
        return _parse_query_session(out)
    except FileNotFoundError:
        pass
    query = system32_exe("query.exe")
    out = run_cmd([query, "session", f"/server:{host}"], timeout)
    return _parse_query_session(out)


def _session_user_map(sessions: list[dict[str, str]]) -> dict[str, str]:
    mapping: dict[str, str] = {}
    for s in sessions:
        user = s.get("username")
        sess = (s.get("session") or "").strip()
        if not user:
            continue
        mapping[sess.lower()] = user
        if sess.isdigit():
            mapping[sess] = user
        mapping[sess.split("#")[0].lower()] = user
    return mapping


def _sessions_from_processes(processes: list[ProcessInfo]) -> list[dict[str, str]]:
    seen: set[str] = set()
    sessions: list[dict[str, str]] = []
    for proc in processes:
        user = proc.username
        if not user or user in seen:
            continue
        seen.add(user)
        sessions.append(
            {"username": user, "session": proc.session or "", "state": "active"}
        )
    return sessions


def _parse_tasklist_username(row: list[str]) -> str | None:
    if len(row) <= 6:
        return None
    raw = (row[6] or "").strip().strip('"')
    if not raw or raw.upper() in ("N/A", "UNKNOWN"):
        return None
    if raw.upper().endswith("$"):
        return None
    return normalize_user(raw) or raw


def _remote_tasklist(
    host: str,
    timeout: float,
    session_users: dict[str, str],
) -> list[ProcessInfo]:
    settings = get_settings()
    tasklist = system32_exe("tasklist.exe")
    args = [tasklist, "/S", host, "/FO", "CSV", "/NH", "/V"]
    user = _monitor_user()
    if user:
        args.extend(["/U", user])
        if settings.monitor_password:
            args.extend(["/P", settings.monitor_password])

    out = run_cmd(args, timeout)
    processes: list[ProcessInfo] = []
    reader = csv.reader(io.StringIO(out))
    for row in reader:
        if len(row) < 5:
            continue
        name = (row[0] or "").strip().lower().strip('"')
        if not name or name == "image name":
            continue
        try:
            pid = int(row[1].strip().replace('"', ""))
        except ValueError:
            pid = 0
        session_name = row[2].strip().replace('"', "").lower() if len(row) > 2 else ""
        username = _parse_tasklist_username(row)
        if not username:
            username = session_users.get(session_name)
            if not username and session_name:
                for key, u in session_users.items():
                    if key in session_name or session_name in key:
                        username = u
                        break
        cmdline = row[-1].lower().strip('"') if len(row) > 6 else ""
        processes.append(
            ProcessInfo(
                name=name,
                username=normalize_user(username),
                pid=pid,
                cmdline=cmdline,
                session=session_name,
            )
        )
    return processes


def probe_remote_machine(host: str) -> MonitorSnapshot:
    if sys.platform != "win32":
        raise OSError("Remote probing requires the dashboard server to run on Windows")

    settings = get_settings()
    target = host.strip()

    if settings.poll_skip_unreachable:
        ping_timeout = settings.poll_ping_timeout_seconds
        if not check_host_reachable(target, settings.rdp_port, ping_timeout):
            raise RuntimeError(
                f"host unreachable on port {settings.rdp_port} "
                f"(skipped slow tasklist; check IP/firewall)"
            )

    timeout = settings.poll_timeout_seconds

    with _remote_auth(target, min(timeout, 5.0)):
        sessions: list[dict[str, str]] = []
        session_types: dict[str, str] = {}
        session_error: str | None = None

        try:
            sessions = _remote_query_user(target, timeout)
            session_types = _remote_query_session(target, timeout)
        except FileNotFoundError as exc:
            session_error = str(exc)
        except Exception as exc:
            session_error = str(exc)

        session_users = _session_user_map(sessions)
        processes = _remote_tasklist(target, timeout, session_users)

        if not processes:
            raise RuntimeError(
                session_error
                or f"tasklist returned no data for {target} "
                "(needs admin: RDD_MONITOR_USERNAME/PASSWORD or domain admin)"
            )

        if not sessions:
            sessions = _sessions_from_processes(processes)

        analyzed = analyze_sessions_and_processes(sessions, session_types, processes)
        raw: dict[str, Any] = {
            "source": "remote_poller",
            "target": target,
            "sessions": sessions,
            "session_types": session_types,
            "process_count": len(processes),
            "session_error": session_error,
        }

        return MonitorSnapshot(
            local_user=analyzed["local_user"],
            rdp_users=analyzed["rdp_users"],
            windows_app_users=analyzed["windows_app_users"],
            mobaxterm_user=analyzed["mobaxterm_user"],
            com_port_user=analyzed["com_port_user"],
            etgui_user=analyzed["etgui_user"],
            camera_user=analyzed["camera_user"],
            camera_tools=analyzed["camera_tools"],
            raw=raw,
        )
