"""API dependencies."""

from fastapi import Header, HTTPException, status

from remote_desktop_dashboard.config import get_settings


def verify_agent_key(x_api_key: str | None = Header(default=None)) -> None:
    settings = get_settings()
    if not settings.agent_api_key:
        return
    if x_api_key != settings.agent_api_key:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid or missing X-API-Key",
        )
