"""REST API routes."""

import sys
import threading

from fastapi import APIRouter, Depends, HTTPException, Query, status
from fastapi.responses import Response
from sqlalchemy.orm import Session

from remote_desktop_dashboard.api.deps import verify_agent_key
from remote_desktop_dashboard.crud.lock import (
    LockError,
    acquire_lock,
    heartbeat_lock,
    refresh_expired_locks,
    release_lock,
)
from remote_desktop_dashboard.crud.machine import (
    apply_status_report,
    create_machine,
    delete_machine,
    get_machine,
    get_machine_by_name,
    list_machines,
    refresh_online_flags,
    update_machine,
)
from remote_desktop_dashboard.database import get_db
from remote_desktop_dashboard.schemas.machine import (
    ConnectRequest,
    ConnectResponse,
    LockHeartbeatRequest,
    MachineCreate,
    MachineRead,
    MachineStatusReport,
    MachineUpdate,
)
from remote_desktop_dashboard.services.connection_manager import manager
from remote_desktop_dashboard.services.dashboard import machines_payload, to_dashboard_machine
from remote_desktop_dashboard.services.rdp_launch import (
    build_launch_uris,
    build_rdp_file_content,
    local_launch_url,
)
from remote_desktop_dashboard.config import get_settings
from remote_desktop_dashboard.services.reachability_cache import get_cached_reachability

router = APIRouter(prefix="/api/v1")


def _machine_or_404(db: Session, machine_name: str):
    machine = get_machine_by_name(db, machine_name)
    if machine is None:
        raise HTTPException(status_code=404, detail="Machine not found")
    return machine


def _prepare_machines(db: Session, *, check_reachability: bool | None = None):
    refresh_online_flags(db)
    refresh_expired_locks(db)
    machines = list_machines(db)
    settings = get_settings()
    do_check = (
        settings.reachability_on_api if check_reachability is None else check_reachability
    )
    if do_check and settings.reachability_check:
        reachability = get_cached_reachability(machines, allow_refresh=True)
    else:
        reachability = get_cached_reachability(machines, allow_refresh=False)
    return machines, reachability


@router.get("/machines", response_model=list[MachineRead])
def api_list_machines(db: Session = Depends(get_db)) -> list[MachineRead]:
    machines, _ = _prepare_machines(db)
    return [MachineRead.model_validate(m) for m in machines]


@router.get("/machines/{machine_id}", response_model=MachineRead)
def api_get_machine(machine_id: int, db: Session = Depends(get_db)) -> MachineRead:
    machine = get_machine(db, machine_id)
    if machine is None:
        raise HTTPException(status_code=404, detail="Machine not found")
    return MachineRead.model_validate(machine)


@router.post("/machines", response_model=MachineRead, status_code=status.HTTP_201_CREATED)
async def api_create_machine(data: MachineCreate, db: Session = Depends(get_db)) -> MachineRead:
    existing = get_machine_by_name(db, data.name)
    if existing:
        raise HTTPException(status_code=409, detail="Machine name already exists")
    machine = create_machine(db, data)
    machines, reachability = _prepare_machines(db)
    await manager.broadcast(machines_payload(machines, reachability=reachability))
    return MachineRead.model_validate(machine)


@router.patch("/machines/{machine_id}", response_model=MachineRead)
async def api_update_machine(
    machine_id: int, data: MachineUpdate, db: Session = Depends(get_db)
) -> MachineRead:
    machine = get_machine(db, machine_id)
    if machine is None:
        raise HTTPException(status_code=404, detail="Machine not found")
    machine = update_machine(db, machine, data)
    machines, reachability = _prepare_machines(db)
    await manager.broadcast(machines_payload(machines, reachability=reachability))
    return MachineRead.model_validate(machine)


@router.delete("/machines/{machine_id}", status_code=status.HTTP_204_NO_CONTENT)
async def api_delete_machine(machine_id: int, db: Session = Depends(get_db)) -> None:
    machine = get_machine(db, machine_id)
    if machine is None:
        raise HTTPException(status_code=404, detail="Machine not found")
    delete_machine(db, machine)
    machines, reachability = _prepare_machines(db)
    await manager.broadcast(machines_payload(machines, reachability=reachability))


@router.delete("/machines/by-name/{machine_name}", status_code=status.HTTP_204_NO_CONTENT)
async def api_delete_machine_by_name(machine_name: str, db: Session = Depends(get_db)) -> None:
    machine = _machine_or_404(db, machine_name)
    delete_machine(db, machine)
    machines, reachability = _prepare_machines(db)
    await manager.broadcast(machines_payload(machines, reachability=reachability))


@router.post(
    "/machines/{machine_name}/status",
    response_model=MachineRead,
    dependencies=[Depends(verify_agent_key)],
)
async def api_post_status(
    machine_name: str,
    report: MachineStatusReport,
    db: Session = Depends(get_db),
) -> MachineRead:
    report.machine_name = machine_name.upper()
    try:
        machine = apply_status_report(db, report)
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc

    machines, reachability = _prepare_machines(db)
    await manager.broadcast(machines_payload(machines, reachability=reachability))
    return MachineRead.model_validate(machine)


@router.get("/dashboard/fast")
def api_dashboard_fast(
    operator: str | None = None,
    db: Session = Depends(get_db),
) -> dict:
    """Dashboard with cached online/offline (no lock refresh)."""
    refresh_online_flags(db)
    machines = list_machines(db)
    reach = get_cached_reachability(machines, allow_refresh=True)
    return {
        "machines": [
            to_dashboard_machine(m, operator, reach.get(m.name, False)).model_dump(mode="json")
            for m in machines
        ],
    }


@router.get("/dashboard")
def api_dashboard(
    operator: str | None = None,
    db: Session = Depends(get_db),
) -> dict:
    machines, reachability = _prepare_machines(db)
    return {
        "machines": [
            to_dashboard_machine(m, operator, reachability.get(m.name, False)).model_dump(
                mode="json"
            )
            for m in machines
        ],
    }


@router.post("/machines/{machine_name}/connect", response_model=ConnectResponse)
async def api_connect(
    machine_name: str,
    body: ConnectRequest,
    db: Session = Depends(get_db),
) -> ConnectResponse:
    machine = _machine_or_404(db, machine_name)
    try:
        acquire_lock(db, machine, body.operator, body.rdp_username)
    except LockError as exc:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=str(exc),
        ) from exc

    target = machine.hostname if body.use_hostname else machine.ip_address
    domain = None
    username = body.rdp_username
    if username and "\\" in username:
        domain, _, username = username.partition("\\")

    uris = build_launch_uris(target, username=username, domain=domain)
    launch_url = local_launch_url(target, username=username, domain=domain)

    db.refresh(machine)
    machines, reachability = _prepare_machines(db)
    row = to_dashboard_machine(
        machine, body.operator, reachability.get(machine.name, False)
    )
    payload = machines_payload(machines, body.operator, reachability)
    await manager.broadcast(payload)

    if get_settings().poller_enabled and sys.platform == "win32":
        from remote_desktop_dashboard.services.poller import poll_single_machine

        threading.Thread(
            target=poll_single_machine,
            args=(machine.name,),
            daemon=True,
            name=f"poll-{machine.name}",
        ).start()

    client = uris["client"]
    if client in ("windows_app", "windows365", "msrdc"):
        msg = f"Connecting directly to {target} via Windows App (msrdc)…"
    elif not uris["msrdc_found"]:
        msg = (
            "Windows App not found on this PC — use Download .rdp below, "
            "or set RDD_MSRDC_PATH on the server."
        )
    else:
        msg = "Opening remote session — sign in when prompted."

    rdp_dl = f"/api/v1/machines/{machine.name}/session.rdp"
    if body.rdp_username:
        rdp_dl += f"?operator={body.operator}"

    return ConnectResponse(
        machine_name=machine.name,
        locked_by=body.operator,
        launch_uri=uris["primary_uri"],
        fallback_uri=uris["fallback_uri"],
        windows_app_uri=uris["rdp_uri"],
        rdp_uri=uris["rdp_uri"],
        mstsc_command=uris["mstsc_command"],
        powershell_command=uris["powershell_command"],
        local_launch_url=launch_url,
        rdp_download_url=rdp_dl,
        client=client,
        target_host=target,
        message=msg,
        machine=row.model_dump(mode="json"),
    )


@router.get("/machines/{machine_name}/session.rdp")
def download_session_rdp(
    machine_name: str,
    operator: str | None = Query(None),
    use_hostname: bool = Query(True),
    rdp_username: str | None = Query(None),
    db: Session = Depends(get_db),
) -> Response:
    """Download .rdp file — works from any PC (uses that PC's default RDP client)."""
    machine = _machine_or_404(db, machine_name)
    target = machine.hostname if use_hostname else machine.ip_address
    domain = None
    username = rdp_username or machine.lock_rdp_username
    if username and "\\" in username:
        domain, _, username = username.partition("\\")
    content = build_rdp_file_content(target, username=username, domain=domain)
    filename = f"{machine.name}.rdp"
    return Response(
        content=content,
        media_type="application/rdp",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )


@router.post("/machines/{machine_name}/poll-now")
async def api_poll_now(
    machine_name: str,
    operator: str | None = Query(None),
    db: Session = Depends(get_db),
) -> dict:
    """Poll one machine now for local user / RDP / tools (requires poller + admin creds)."""
    machine = _machine_or_404(db, machine_name)
    if not get_settings().poller_enabled:
        raise HTTPException(
            status_code=400,
            detail="Poller is disabled. Start server without --no-poller.",
        )
    if sys.platform != "win32":
        raise HTTPException(status_code=400, detail="Polling requires a Windows server.")

    from remote_desktop_dashboard.services.poller import poll_single_machine

    ok, err = poll_single_machine(machine.name)
    db.refresh(machine)
    machines, reachability = _prepare_machines(db)
    row = to_dashboard_machine(
        machine, operator, reachability.get(machine.name, False)
    )
    await manager.broadcast(machines_payload(machines, operator, reachability))
    return {
        "ok": ok,
        "error": err,
        "machine": row.model_dump(mode="json"),
    }


@router.post("/machines/{machine_name}/lock/heartbeat", response_model=MachineRead)
async def api_lock_heartbeat(
    machine_name: str,
    body: LockHeartbeatRequest,
    db: Session = Depends(get_db),
) -> MachineRead:
    machine = _machine_or_404(db, machine_name)
    try:
        machine = heartbeat_lock(db, machine, body.operator)
    except LockError as exc:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=str(exc)) from exc
    machines, reachability = _prepare_machines(db)
    await manager.broadcast(machines_payload(machines, body.operator, reachability))
    return MachineRead.model_validate(machine)


@router.post("/machines/{machine_name}/lock/release", response_model=MachineRead)
async def api_lock_release(
    machine_name: str,
    body: LockHeartbeatRequest,
    db: Session = Depends(get_db),
) -> MachineRead:
    machine = _machine_or_404(db, machine_name)
    try:
        machine = release_lock(db, machine, body.operator)
    except LockError as exc:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=str(exc)) from exc
    machines, reachability = _prepare_machines(db)
    await manager.broadcast(machines_payload(machines, reachability=reachability))
    return MachineRead.model_validate(machine)
