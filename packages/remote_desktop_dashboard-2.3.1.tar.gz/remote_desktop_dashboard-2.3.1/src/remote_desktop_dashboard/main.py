"""FastAPI application factory."""

import asyncio
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

from remote_desktop_dashboard import __version__
from remote_desktop_dashboard.api.routes import router as api_router
from remote_desktop_dashboard.api.websocket import router as ws_router
from remote_desktop_dashboard.config import get_settings
from remote_desktop_dashboard.database import init_db
from remote_desktop_dashboard.services.local_launcher import start_local_launcher, stop_local_launcher
from remote_desktop_dashboard.services.poller import set_event_loop, start_poller, stop_poller
from remote_desktop_dashboard.services.reachability_cache import (
    start_reachability_refresher,
    stop_reachability_refresher,
)


@asynccontextmanager
async def lifespan(_app: FastAPI):
    init_db()
    set_event_loop(asyncio.get_running_loop())
    start_local_launcher()
    start_reachability_refresher()
    start_poller()
    yield
    stop_poller()
    stop_reachability_refresher()
    stop_local_launcher()


def create_app() -> FastAPI:
    settings = get_settings()
    static_dir = settings.resolved_static_dir

    app = FastAPI(
        title="Remote Desktop Dashboard",
        description=(
            "Agentless bench monitoring from one Windows server — "
            "no per-machine agents required"
        ),
        version=__version__,
        lifespan=lifespan,
    )

    app.include_router(api_router)
    app.include_router(ws_router)

    if static_dir.is_dir():
        app.mount("/static", StaticFiles(directory=str(static_dir)), name="static")

        @app.get("/")
        async def index() -> FileResponse:
            return FileResponse(static_dir / "index.html")

    @app.get("/health")
    async def health() -> dict:
        from remote_desktop_dashboard.services.poller import get_poller_stats

        s = get_settings()
        from remote_desktop_dashboard.services.rdp_launch import find_msrdc_exe

        msrdc = find_msrdc_exe()
        return {
            "status": "ok",
            "version": __version__,
            "poller": get_poller_stats(),
            "poller_enabled": s.poller_enabled,
            "reachability_check": s.reachability_check,
            "msrdc_on_server": str(msrdc) if msrdc else None,
            "agentless": True,
        }

    return app


app = create_app()
