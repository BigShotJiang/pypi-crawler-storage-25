from unittest.mock import MagicMock, patch

from primitive.hardware.actions import Hardware


class TestCheckInHttpFallback:
    def _make_hardware(self):
        hw = Hardware.__new__(Hardware)
        hw.primitive = MagicMock()
        return hw

    def test_check_in_uses_messaging_when_ready(self):
        """check_in sends via messaging when ready and not forced to HTTP."""
        hw = self._make_hardware()
        hw.primitive.messaging.ready = True

        with patch.object(hw, "check_in_http") as mock_http:
            hw.check_in(is_online=True)
            hw.primitive.messaging.send_message.assert_called_once()
            mock_http.assert_not_called()

    def test_check_in_falls_back_to_http_on_messaging_failure(self):
        """check_in falls back to HTTP when messaging raises."""
        hw = self._make_hardware()
        hw.primitive.messaging.ready = True
        hw.primitive.messaging.send_message.side_effect = ConnectionRefusedError(
            "refused"
        )

        with patch.object(hw, "check_in_http") as mock_http:
            hw.check_in(is_online=True, is_healthy=True)
            mock_http.assert_called_once_with(
                is_healthy=True,
                is_quarantined=False,
                is_available=False,
                is_online=True,
                stopping_agent=False,
            )

    def test_check_in_uses_http_when_messaging_not_ready(self):
        """check_in goes straight to HTTP when messaging is not ready."""
        hw = self._make_hardware()
        hw.primitive.messaging.ready = False

        with patch.object(hw, "check_in_http") as mock_http:
            hw.check_in(is_online=True)
            mock_http.assert_called_once()

    def test_check_in_uses_http_when_http_flag_set(self):
        """check_in uses HTTP when http=True regardless of messaging state."""
        hw = self._make_hardware()
        hw.primitive.messaging.ready = True

        with patch.object(hw, "check_in_http") as mock_http:
            hw.check_in(is_online=True, http=True)
            mock_http.assert_called_once()
            hw.primitive.messaging.send_message.assert_not_called()
