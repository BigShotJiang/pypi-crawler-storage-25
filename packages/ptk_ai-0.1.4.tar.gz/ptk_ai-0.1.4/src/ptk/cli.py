import typer
from rich.console import Console

from ptk.analytics.cc_economics import cc_economics_app
from ptk.analytics.gain import gain_app
from ptk.analytics.session import session_app
from ptk.cmds.cargo_cmd import cargo_app
from ptk.cmds.cloud_cmd import aws_app, docker_app, gh_app, kubectl_app, psql_app
from ptk.cmds.git import git_app
from ptk.cmds.go_cmd import go_app
from ptk.cmds.js import npm_app, npx_app, pnpm_app
from ptk.cmds.json_cmd import json_app
from ptk.cmds.network_cmd import curl_app, wget_app
from ptk.cmds.proxy import proxy_app
from ptk.cmds.python_cmds import mypy_app, pip_app, pytest_app, ruff_app, uv_app
from ptk.cmds.run_cmd import cmd_run
from ptk.cmds.search_list_cmd import find_app, grep_app, ls_app, rg_app
from ptk.cmds.system_cmd import diff_app, env_app, tree_app
from ptk.cmds.trust_cli import cmd_trust, cmd_untrust
from ptk.cmds.verify_cmd import cmd_verify
from ptk.cmds.wc_cmd import wc_app
from ptk.discover.discover import discover_app
from ptk.hooks.init import cmd_hook_gemini, cmd_init, cmd_rewrite, hook_app
from ptk.learn.learn import learn_app

app = typer.Typer(
    name="ptk",
    help="Python Token Killer — minimize LLM token consumption",
    no_args_is_help=True,
    pretty_exceptions_enable=False,  # raw tracebacks in --verbose mode
)
console = Console()

# Global state passed via typer context or module-level vars
verbose_flag: int = 0
ultra_compact_flag: bool = False


@app.callback()
def main(
    verbose: int = typer.Option(0, "--verbose", "-v", count=True),
    ultra_compact: bool = typer.Option(False, "--ultra-compact", "-u"),
    skip_env: bool = typer.Option(False, "--skip-env"),
) -> None:
    global verbose_flag, ultra_compact_flag
    verbose_flag = verbose
    ultra_compact_flag = ultra_compact


# Register subcommands
app.add_typer(git_app, name="git")
app.add_typer(npm_app, name="npm")
app.add_typer(pnpm_app, name="pnpm")
app.add_typer(npx_app, name="npx")
app.add_typer(pytest_app, name="pytest")
app.add_typer(ruff_app, name="ruff")
app.add_typer(mypy_app, name="mypy")
app.add_typer(pip_app, name="pip")
app.add_typer(uv_app, name="uv")
app.add_typer(cargo_app, name="cargo")
app.add_typer(gh_app, name="gh")
app.add_typer(docker_app, name="docker")
app.add_typer(kubectl_app, name="kubectl")
app.add_typer(aws_app, name="aws")
app.add_typer(psql_app, name="psql")
app.add_typer(curl_app, name="curl")
app.add_typer(wget_app, name="wget")
app.add_typer(rg_app, name="rg")
app.add_typer(grep_app, name="grep")
app.add_typer(ls_app, name="ls")
app.add_typer(find_app, name="find")
app.add_typer(env_app, name="env")
app.add_typer(tree_app, name="tree")
app.add_typer(diff_app, name="diff")
app.add_typer(json_app, name="json")
app.add_typer(wc_app, name="wc")
app.add_typer(go_app, name="go")

# Phase 5 Commands
app.add_typer(gain_app, name="gain")
app.add_typer(discover_app, name="discover")
app.add_typer(learn_app, name="learn")

app.command("init", help="Install ptk hooks in supported AI agents.")(cmd_init)
app.add_typer(hook_app, name="hook")
app.command("hook-gemini", help="Gemini CLI BeforeTool hook (stdin JSON).")(cmd_hook_gemini)
app.command("rewrite", help="Rewrite a raw command to its ptk equivalent.")(cmd_rewrite)

app.command("trust", help="Trust the nearest .ptk.toml (SHA256 lockfile).")(cmd_trust)
app.command("untrust", help="Remove trust for the project with the nearest .ptk.toml.")(cmd_untrust)
app.command("verify", help="Run [[test]] blocks from .ptk.toml against filters.")(cmd_verify)

app.command(
    "run",
    help="Run any command; apply a matching trusted .ptk.toml filter when available.",
)(cmd_run)

app.add_typer(proxy_app, name="proxy")
app.add_typer(session_app, name="session")
app.add_typer(cc_economics_app, name="cc-economics")

if __name__ == "__main__":
    app()
