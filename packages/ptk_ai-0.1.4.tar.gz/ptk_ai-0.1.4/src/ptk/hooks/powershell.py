"""Helpers for building PowerShell-aware hook commands."""

from __future__ import annotations

import shutil
from pathlib import Path
from typing import Iterable

POWERSHELL_CANDIDATES: list[str] = ["pwsh", "powershell"]


def find_powershell_executable(candidates: Iterable[str] | None = None) -> str | None:
    """Return the first PowerShell executable found on PATH."""
    for candidate in candidates or POWERSHELL_CANDIDATES:
        if shutil.which(candidate):
            return candidate
    return None


def build_powershell_hook_command(
    *,
    shell: str | None = None,
    command_env_var: str = "CMD",
) -> str:
    """Return a PowerShell snippet that rewrites ``$ENV:CMD`` via ``ptk rewrite``."""
    shell_cmd = shell or find_powershell_executable()
    if not shell_cmd:
        shell_cmd = "pwsh"

    script_segments = [
        f"$cmd = $Env:{command_env_var}",
        '$rewritten = & ptk rewrite -- "$cmd" 2>$null',
        "if ($LASTEXITCODE -eq 0 -and -not [string]::IsNullOrEmpty($rewritten))",
        "{",
        "    Write-Output $rewritten",
        "}",
        "else",
        "{",
        "    Write-Output $cmd",
        "}",
    ]
    script = "; ".join(script_segments)
    return f"{shell_cmd} -NoLogo -NoProfile -Command '{script}'"


def shared_hook_directory() -> Path:
    """Directory that stores shared PTK PowerShell hook scripts."""
    path = Path.home() / ".ptk" / "hooks"
    path.mkdir(parents=True, exist_ok=True)
    return path


def rewrite_script_path() -> Path:
    """Path to the shared PowerShell rewrite script."""
    return shared_hook_directory() / "ptk-rewrite.ps1"


def ensure_shared_rewrite_script() -> Path:
    """Write the PowerShell helper script that proxies commands through `ptk rewrite`."""
    path = rewrite_script_path()
    script = """param([Parameter(ValueFromRemainingArguments = $true)][string[]]$CommandParts)
$cmd = if ($CommandParts) { $CommandParts -join ' ' } else { '' }
if (-not $cmd) { return }
$rewritten = & ptk rewrite -- $cmd 2>$null
if ($LASTEXITCODE -eq 0 -and -not [string]::IsNullOrEmpty($rewritten)) {
    Write-Output $rewritten
} else {
    Write-Output $cmd
}
"""
    path.write_text(script, encoding="utf-8")
    return path
