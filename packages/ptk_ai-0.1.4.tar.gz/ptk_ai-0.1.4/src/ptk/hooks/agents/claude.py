import json
import os
from pathlib import Path
from typing import Literal

from rich.console import Console

from ptk.hooks.agents import powershell as powershell_agent

console = Console()


def claude_settings_path() -> Path:
    return Path(os.path.expanduser("~/.claude/settings.json"))


DEFAULT_HOOK_COMMAND = 'REWRITTEN=$(ptk rewrite "$CMD") && echo $REWRITTEN || echo $CMD'


def install(
    global_: bool = False,
    *,
    shell: Literal["bash", "powershell"] = "bash",
    verbose: int = 0,
) -> None:
    path = claude_settings_path()
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        if shell == "powershell":
            powershell_agent.install(path)
        else:
            if path.exists():
                with open(path, encoding="utf-8") as f:
                    settings = json.load(f)
            else:
                settings = {}

            settings["hookCommand"] = DEFAULT_HOOK_COMMAND

            with open(path, "w", encoding="utf-8") as f:
                json.dump(settings, f, indent=2)

        console.print("[green]✓ Claude Code hook installed.[/green]")
    except Exception as e:
        console.print(f"[red]Failed to install Claude hook: {e}[/red]")
