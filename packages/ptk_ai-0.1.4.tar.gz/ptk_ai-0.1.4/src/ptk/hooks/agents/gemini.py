"""Gemini CLI hook installation (PowerShell BeforeTool)."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from rich.console import Console

from ptk.hooks.agents import utils as hook_utils
from ptk.hooks.powershell import find_powershell_executable

# Parity with rtk `GEMINI_HOOK_FILE` name; PowerShell implementation.
GEMINI_SCRIPT_NAME = "ptk-hook-gemini.ps1"
GEMINI_BASH_NAME = "ptk-hook-gemini.sh"
PTK_HOOK_MARKER = "ptk-hook-gemini"

# Delegates to `ptk hook-gemini` so rewrite rules stay in one place (Python).
GEMINI_BEFORETOOL_PS1 = r"""
# ptk Gemini BeforeTool hook — JSON stdin -> JSON stdout (see rtk `hook gemini`).
$raw = [Console]::In.ReadToEnd()
if ($null -eq $raw) { $raw = '' }
$raw | & ptk hook-gemini
""".strip()

GEMINI_BEFORETOOL_BASH = r"""
#!/bin/bash
# ptk Gemini BeforeTool hook (Bash)
cat | ptk hook-gemini 2>/dev/null
""".strip()


def _command_line_for_script(script_path: Path, shell_exe: str) -> str:
    resolved = script_path.resolve()
    return f'{shell_exe} -NoLogo -NoProfile -ExecutionPolicy Bypass -File "{resolved}"'


def _settings_reference_ptk(settings: dict[str, Any]) -> bool:
    hooks_block = settings.get("hooks")
    if not isinstance(hooks_block, dict):
        return False
    before = hooks_block.get("BeforeTool")
    if not isinstance(before, list):
        return False
    for entry in before:
        if not isinstance(entry, dict):
            continue
        inner = entry.get("hooks")
        if not isinstance(inner, list):
            continue
        for h in inner:
            if not isinstance(h, dict):
                continue
            cmd = h.get("command", "")
            if isinstance(cmd, str) and PTK_HOOK_MARKER in cmd:
                return True
    return False


def install_powershell(*, home: Path | None = None, console: Console | None = None) -> None:
    """Install ~/.gemini/hooks/ptk-hook-gemini.ps1 and patch ~/.gemini/settings.json."""
    c = console or Console()
    root = home if home is not None else Path.home()
    gemini_dir = root / ".gemini"
    hooks_dir = gemini_dir / "hooks"
    hook_utils.ensure_parent(hooks_dir / ".keep")
    script_path = hooks_dir / GEMINI_SCRIPT_NAME
    script_path.write_text(GEMINI_BEFORETOOL_PS1 + "\n", encoding="utf-8")

    shell_exe = find_powershell_executable() or "pwsh"
    hook_command = _command_line_for_script(script_path, shell_exe)

    settings_path = gemini_dir / "settings.json"
    data = hook_utils.read_json(settings_path)
    if not data:
        data = {}

    if _settings_reference_ptk(data):
        c.print(f"[dim]Gemini settings.json already references {GEMINI_SCRIPT_NAME}; skipped patch.[/dim]")
    else:
        hooks_block = data.get("hooks")
        if not isinstance(hooks_block, dict):
            hooks_block = {}
            data["hooks"] = hooks_block

        before = hooks_block.get("BeforeTool")
        if not isinstance(before, list):
            before = []
            hooks_block["BeforeTool"] = before

        hook_entry = {
            "matcher": "run_shell_command",
            "hooks": [{"type": "command", "command": hook_command}],
        }
        before.append(hook_entry)
        hook_utils.write_json(settings_path, data, console=c)

    c.print("[green]✓ Gemini CLI PowerShell hook installed.[/green]")


def install_bash(*, home: Path | None = None, console: Console | None = None) -> None:
    """Install ~/.gemini/hooks/ptk-hook-gemini.sh and patch ~/.gemini/settings.json."""
    c = console or Console()
    root = home if home is not None else Path.home()
    gemini_dir = root / ".gemini"
    hooks_dir = gemini_dir / "hooks"
    hook_utils.ensure_parent(hooks_dir / ".keep")
    script_path = hooks_dir / GEMINI_BASH_NAME
    script_path.write_text(GEMINI_BEFORETOOL_BASH + "\n", encoding="utf-8")
    script_path.chmod(0o755)

    hook_command = str(script_path.resolve())

    settings_path = gemini_dir / "settings.json"
    data = hook_utils.read_json(settings_path)
    if not data:
        data = {}

    if _settings_reference_ptk(data):
        c.print(f"[dim]Gemini settings.json already references {GEMINI_BASH_NAME}; skipped patch.[/dim]")
    else:
        hooks_block = data.get("hooks")
        if not isinstance(hooks_block, dict):
            hooks_block = {}
            data["hooks"] = hooks_block

        before = hooks_block.get("BeforeTool")
        if not isinstance(before, list):
            before = []
            hooks_block["BeforeTool"] = before

        hook_entry = {
            "matcher": "run_shell_command",
            "hooks": [{"type": "command", "command": hook_command}],
        }
        before.append(hook_entry)
        hook_utils.write_json(settings_path, data, console=c)

    c.print("[green]✓ Gemini CLI Bash hook installed.[/green]")
