"""Cursor IDE hook installation (PowerShell preToolUse)."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from rich.console import Console

from ptk.hooks.agents import utils as hook_utils
from ptk.hooks.powershell import find_powershell_executable

CURSOR_SCRIPT_NAME = "ptk-rewrite.ps1"
CURSOR_BASH_NAME = "ptk-rewrite.sh"
CURSOR_RULES_FILE = ".cursorrules"

PTK_HOOK_MARKER = "ptk-rewrite" # Shared substring for both .ps1 and .sh

# Mirrors hooks/cursor/rtk-rewrite.sh from maravedi/ptk: JSON on stdin, JSON on stdout.
CURSOR_PRETOOL_PS1 = r"""
# ptk Cursor preToolUse hook — JSON stdin -> JSON stdout (see rtk hooks/cursor/rtk-rewrite.sh).
$raw = [Console]::In.ReadToEnd()
if ([string]::IsNullOrWhiteSpace($raw)) { Write-Output '{}'; exit 0 }
try {
    $obj = $raw | ConvertFrom-Json
} catch {
    Write-Output '{}'
    exit 0
}
$cmd = $obj.tool_input.command
if ([string]::IsNullOrWhiteSpace($cmd)) { Write-Output '{}'; exit 0 }
if ($cmd -match '<<') { Write-Output '{}'; exit 0 }
$rewritten = & ptk rewrite -- $cmd 2>$null
if ($LASTEXITCODE -ne 0) { Write-Output '{}'; exit 0 }
if ($cmd -eq $rewritten) { Write-Output '{}'; exit 0 }
$output = [ordered]@{
    permission = 'allow'
    updated_input = [ordered]@{ command = $rewritten }
}
Write-Output ($output | ConvertTo-Json -Compress -Depth 5)
exit 0
""".strip()

CURSOR_RULES_CONTENT = r"""
# PTK Cursor Rules
# Minimize token consumption by using the 'ptk' CLI proxy.

# Instructions for Cursor:
# 1. When you need to read a file, use `ptk read <file>` instead of `cat`.
# 2. When you need to list directories, use `ptk ls <path>` instead of `ls`.
# 3. For any git command (status, diff, log, add, commit), prefix with `ptk`.
# 4. For test runners (pytest, cargo test, npm test), use `ptk <command>`.

# This ensures 60-90% token savings during your session.
""".strip()

CURSOR_BASH_HOOK_CONTENT = r"""
#!/bin/bash
# ptk Cursor preToolUse hook (Bash)
raw=$(cat)
if [ -z "$raw" ]; then echo "{}"; exit 0; fi
if command -v jq >/dev/null 2>&1; then
    cmd=$(echo "$raw" | jq -r '.tool_input.command // empty')
else
    cmd=$(echo "$raw" | grep -oP '"command"\s*:\s*"\K[^"]+')
fi
if [ -z "$cmd" ] || [[ "$cmd" == *'<<'* ]]; then echo "{}"; exit 0; fi
rewritten=$(ptk rewrite -- "$cmd" 2>/dev/null)
if [ $? -ne 0 ] || [ -z "$rewritten" ] || [ "$cmd" = "$rewritten" ]; then
    echo "{}"
    exit 0
fi
escaped=$(echo "$rewritten" | sed 's/"/\\"/g')
echo "{\"permission\":\"allow\",\"updated_input\":{\"command\":\"$escaped\"}}"
exit 0
""".strip()


def _command_line_for_script(script_path: Path, shell_exe: str) -> str:
    resolved = script_path.resolve()
    return f'{shell_exe} -NoLogo -NoProfile -ExecutionPolicy Bypass -File "{resolved}"'


def _hooks_reference_ptk(data: dict[str, Any]) -> bool:
    hooks_block = data.get("hooks")
    if not isinstance(hooks_block, dict):
        return False
    entries = hooks_block.get("preToolUse")
    if not isinstance(entries, list):
        return False
    for entry in entries:
        if not isinstance(entry, dict):
            continue
        cmd = entry.get("command", "")
        if isinstance(cmd, str) and PTK_HOOK_MARKER in cmd:
            return True
    return False


def install_powershell(*, home: Path | None = None, console: Console | None = None) -> None:
    """Install ~/.cursor/hooks/ptk-rewrite.ps1 and register it in ~/.cursor/hooks.json."""
    c = console or Console()
    root = home if home is not None else Path.home()
    hooks_dir = root / ".cursor" / "hooks"
    hook_utils.ensure_parent(hooks_dir / ".keep")
    script_path = hooks_dir / CURSOR_SCRIPT_NAME
    script_path.write_text(CURSOR_PRETOOL_PS1 + "\n", encoding="utf-8")

    shell_exe = find_powershell_executable() or "pwsh"
    hook_command = _command_line_for_script(script_path, shell_exe)

    hooks_json = root / ".cursor" / "hooks.json"
    data = hook_utils.read_json(hooks_json)
    if not data:
        data = {"version": 1, "hooks": {}}

    if "hooks" not in data or not isinstance(data["hooks"], dict):
        data["hooks"] = {}
    if "version" not in data:
        data["version"] = 1

    pre = data["hooks"].get("preToolUse")
    if not isinstance(pre, list):
        pre = []
        data["hooks"]["preToolUse"] = pre

    if _hooks_reference_ptk(data):
        c.print(f"[dim]Cursor hooks.json already lists {CURSOR_SCRIPT_NAME}; skipped update.[/dim]")
    else:
        pre.append({"command": hook_command})
        hook_utils.write_json(hooks_json, data, console=c)

    c.print("[green]✓ Cursor PowerShell hook installed.[/green]")
    install_rules(console=c)


def install_bash(*, home: Path | None = None, console: Console | None = None) -> None:
    """Install ~/.cursor/hooks/ptk-rewrite.sh and register it in ~/.cursor/hooks.json."""
    c = console or Console()
    root = home if home is not None else Path.home()
    hooks_dir = root / ".cursor" / "hooks"
    hook_utils.ensure_parent(hooks_dir / ".keep")
    script_path = hooks_dir / CURSOR_BASH_NAME
    script_path.write_text(CURSOR_BASH_HOOK_CONTENT + "\n", encoding="utf-8")
    script_path.chmod(0o755)

    hook_command = str(script_path.resolve())

    hooks_json = root / ".cursor" / "hooks.json"
    data = hook_utils.read_json(hooks_json)
    if not data:
        data = {"version": 1, "hooks": {}}

    if "hooks" not in data or not isinstance(data["hooks"], dict):
        data["hooks"] = {}
    if "version" not in data:
        data["version"] = 1

    pre = data["hooks"].get("preToolUse")
    if not isinstance(pre, list):
        pre = []
        data["hooks"]["preToolUse"] = pre

    if _hooks_reference_ptk(data):
        c.print(f"[dim]Cursor hooks.json already lists {CURSOR_BASH_NAME}; skipped update.[/dim]")
    else:
        pre.append({"command": hook_command})
        hook_utils.write_json(hooks_json, data, console=c)

    c.print("[green]✓ Cursor Bash hook installed.[/green]")
    install_rules(console=c)


def install_rules(*, console: Console | None = None) -> None:
    """Generate .cursorrules in the current directory."""
    c = console or Console()
    rules_path = Path(CURSOR_RULES_FILE)
    rules_path.write_text(CURSOR_RULES_CONTENT + "\n", encoding="utf-8")
    c.print(f"[green]✓ {CURSOR_RULES_FILE} generated for Cursor.[/green]")
