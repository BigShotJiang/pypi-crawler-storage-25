"""Windsurf agent support."""

from __future__ import annotations

from pathlib import Path

from rich.console import Console

WINDSURF_RULES_FILE = ".windsurfrules"

WINDSURF_RULES_CONTENT = r"""
# PTK Windsurf Rules
# Minimize token consumption by using the 'ptk' CLI proxy.

# Instructions for Windsurf:
# 1. When you need to read a file, use `ptk read <file>` instead of `cat`.
# 2. When you need to list directories, use `ptk ls <path>` instead of `ls`.
# 3. For any git command (status, diff, log, add, commit), prefix with `ptk`.
# 4. For test runners (pytest, cargo test, npm test), use `ptk <command>`.

# This ensures 60-90% token savings during your session.
""".strip()


def install(*, console: Console | None = None) -> None:
    """Generate .windsurfrules in the current directory."""
    c = console or Console()
    rules_path = Path(WINDSURF_RULES_FILE)
    rules_path.write_text(WINDSURF_RULES_CONTENT + "\n", encoding="utf-8")
    c.print(f"[green]✓ {WINDSURF_RULES_FILE} generated for Windsurf.[/green]")
