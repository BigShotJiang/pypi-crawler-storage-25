"""`ptk rg`, `ptk grep`, `ptk ls`, `ptk find` — search and directory listings."""

from __future__ import annotations

import re
import shutil
import sys

import typer

from ptk.core.emit import emit_filtered_output
from ptk.core.filter import FilterStrategy
from ptk.core.tracking import TimedExecution
from ptk.core.utils import run_capturing


def _rg_match_path_prefix(line: str) -> str | None:
    """Infer file path from a ripgrep-style `path:line:…` row (best-effort on Windows)."""
    if len(line) > 2 and line[0].isalpha() and line[1] == ":":
        rest = line[2:]
        m = re.search(r":(\d+):(\d+):", rest)
        if m:
            return line[: 2 + m.start()]
        m2 = re.search(r":(\d+):", rest)
        if m2:
            return line[: 2 + m2.start()]
        return None
    m = re.search(r":(\d+):(\d+):", line)
    if m:
        return line[: m.start()]
    m2 = re.search(r":(\d+):", line)
    if m2:
        return line[: m2.start()]
    return None


def _filter_rg_output(raw: str) -> str:
    """Group rg matches under file path headers."""
    buckets: dict[str, list[str]] = {}
    order: list[str] = []
    meta: list[str] = []
    for ln in raw.splitlines():
        if not ln.strip():
            continue
        key = _rg_match_path_prefix(ln)
        if key is None:
            meta.append(ln)
        else:
            if key not in buckets:
                order.append(key)
                buckets[key] = []
            buckets[key].append(ln)
    out: list[str] = []
    out.extend(meta[:20])
    for path in order:
        out.append(f"=== {path} ===")
        chunk = buckets[path]
        out.extend(chunk[:50])
        if len(chunk) > 50:
            out.append(f"... {len(chunk) - 50} more matches")
    return "\n".join(out) if out else raw


def _filter_ls_output(raw: str) -> str:
    """Deduplicate and truncate long ls lines."""
    lines = raw.splitlines()
    if not lines:
        return raw
    return "\n".join(FilterStrategy.truncate(FilterStrategy.deduplicate(lines), max_len=200))


def _filter_path_lines_output(raw: str, *, tail: int = 800, max_len: int = 240) -> str:
    """Deduplicate and truncate; keep the tail (find output, grep without -n)."""
    lines = raw.splitlines()
    if len(lines) > tail:
        extra = len(lines) - tail
        lines = lines[-tail:]
        suffix = f"\n... [{extra} lines truncated]"
    else:
        suffix = ""
    body = "\n".join(FilterStrategy.truncate(FilterStrategy.deduplicate(lines), max_len=max_len))
    return body + suffix


def _find_gnu_binary() -> str | None:
    """Resolve GNU find; avoid Windows host `find.exe` (string search, not directory walk)."""
    which = shutil.which("find")
    if not which:
        return None
    if sys.platform == "win32":
        low = which.replace("/", "\\").lower()
        if low.endswith(r"\system32\find.exe"):
            return None
    return which


rg_app = typer.Typer(
    help="ripgrep (rg) with matches grouped by file",
    add_completion=False,
    invoke_without_command=True,
    context_settings={"allow_extra_args": True, "ignore_unknown_options": True},
)

ls_app = typer.Typer(
    help="ls with deduplicated, width-capped lines",
    add_completion=False,
    invoke_without_command=True,
    context_settings={"allow_extra_args": True, "ignore_unknown_options": True},
)

grep_app = typer.Typer(
    help="grep with grouped -n/-H output when line numbers are present",
    add_completion=False,
    invoke_without_command=True,
    context_settings={"allow_extra_args": True, "ignore_unknown_options": True},
)

find_app = typer.Typer(
    help="find(1) with deduplicated, width-capped paths",
    add_completion=False,
    invoke_without_command=True,
    context_settings={"allow_extra_args": True, "ignore_unknown_options": True},
)


@rg_app.callback(invoke_without_command=True)
def rg_cmd(
    ctx: typer.Context,
    args: list[str] = typer.Argument(  # noqa: B008
        default_factory=list,
        help="Arguments forwarded to rg",
    ),
) -> None:
    """Run ripgrep; group plain-text hits by path (skip regrouping for JSON lines)."""
    if not args:
        typer.echo(ctx.get_help())
        raise typer.Exit(0)

    timer = TimedExecution.start()
    label = "rg " + " ".join(args)
    raw, err, code = run_capturing(["rg", *args])
    merged = raw + (f"\n{err}" if err.strip() else "")
    joined = " ".join(args)
    filtered = merged if "--json" in joined else _filter_rg_output(merged)
    emit_filtered_output(merged, filtered)
    timer.track(label, f"ptk {label}", merged, filtered)
    if code != 0:
        raise typer.Exit(code)


@grep_app.callback(invoke_without_command=True)
def grep_cmd(
    ctx: typer.Context,
    args: list[str] = typer.Argument(  # noqa: B008
        default_factory=list,
        help="Arguments forwarded to grep",
    ),
) -> None:
    """Run grep; group `file:line:` rows when -n/--line-number is used."""
    if not args:
        typer.echo(ctx.get_help())
        raise typer.Exit(0)

    grep_bin = shutil.which("grep")
    if not grep_bin:
        typer.echo("ptk grep: `grep` not found on PATH.", err=True)
        raise typer.Exit(127)

    timer = TimedExecution.start()
    label = "grep " + " ".join(args)
    raw, err, code = run_capturing([grep_bin, *args])
    merged = raw + (f"\n{err}" if err.strip() else "")
    joined = " ".join(args)
    grouped = "-n" in joined or "--line-number" in joined
    filtered = _filter_rg_output(merged) if grouped else _filter_path_lines_output(merged)
    emit_filtered_output(merged, filtered)
    timer.track(label, f"ptk {label}", merged, filtered)
    if code != 0:
        raise typer.Exit(code)


@ls_app.callback(invoke_without_command=True)
def ls_cmd(
    ctx: typer.Context,
    args: list[str] = typer.Argument(  # noqa: B008
        default_factory=list,
        help="Arguments forwarded to ls",
    ),
) -> None:
    """Run ls with long lines truncated."""
    if not args:
        typer.echo(ctx.get_help())
        raise typer.Exit(0)

    timer = TimedExecution.start()
    label = "ls " + " ".join(args)
    raw, err, code = run_capturing(["ls", *args])
    merged = raw + (f"\n{err}" if err.strip() else "")
    filtered = _filter_ls_output(merged)
    emit_filtered_output(merged, filtered)
    timer.track(label, f"ptk {label}", merged, filtered)
    if code != 0:
        raise typer.Exit(code)


@find_app.callback(invoke_without_command=True)
def find_cmd(
    ctx: typer.Context,
    args: list[str] = typer.Argument(  # noqa: B008
        default_factory=list,
        help="Arguments forwarded to find",
    ),
) -> None:
    """Run GNU find; compact path output (skips Windows host find.exe)."""
    if not args:
        typer.echo(ctx.get_help())
        raise typer.Exit(0)

    find_bin = _find_gnu_binary()
    if not find_bin:
        typer.echo(
            "ptk find: GNU `find` not on PATH (Windows find.exe is unsupported).",
            err=True,
        )
        raise typer.Exit(127)

    timer = TimedExecution.start()
    label = "find " + " ".join(args)
    raw, err, code = run_capturing([find_bin, *args])
    merged = raw + (f"\n{err}" if err.strip() else "")
    filtered = _filter_path_lines_output(merged, tail=1200, max_len=260)
    emit_filtered_output(merged, filtered)
    timer.track(label, f"ptk {label}", merged, filtered)
    if code != 0:
        raise typer.Exit(code)
