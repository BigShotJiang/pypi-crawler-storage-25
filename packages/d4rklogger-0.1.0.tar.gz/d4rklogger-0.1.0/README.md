# d4rklogger

Lightweight timezone-aware logger setup with:

- rotating daily log files
- optional colored console output
- configurable timezone offset through `TIME_ZONE`

## Install

```bash
pip install d4rklogger
```

Optional color support:

```bash
pip install ".[colors]"
```

## Usage

```python
from log import setup_logger

log = setup_logger("app")
log.info("hello")
```

Set the timezone offset with an environment variable such as `TIME_ZONE=05:30` or `TIME_ZONE=-04:00`.
