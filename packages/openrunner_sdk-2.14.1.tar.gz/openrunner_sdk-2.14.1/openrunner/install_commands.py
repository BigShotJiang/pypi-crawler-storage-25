"""Install OpenRunner slash commands for AI coding tools.

Supports:
- Claude Code: ~/.claude/commands/openrunner/
- Codex (OpenAI): ~/.codex/commands/ or AGENTS.md instructions
- Qwen Code: ~/.qwen-code/commands/
- OpenCode: ~/.opencode/commands/

Usage:
    openrunner install          # auto-detect and install all
    openrunner install claude   # Claude Code only
    openrunner install codex    # Codex only
    openrunner install qwen     # Qwen Code only
    openrunner install opencode # OpenCode only
"""

from __future__ import annotations

import os
from pathlib import Path

# ---------------------------------------------------------------------------
# Command templates
# ---------------------------------------------------------------------------

SYNC_SESSION_CMD = """---
name: {prefix}sync-session
description: Sync current coding session to OpenRunner as a research log
argument-hint: "[org/project]"
allowed-tools:
  - Bash
  - Read
  - AskUserQuestion
---

Sync the current Claude Code session to OpenRunner.

## Process

### Step 1: Check configuration

Run this to check if session config exists:

```bash
python3 -c "
import json
from pathlib import Path
config_file = Path.home() / '.openrunner' / 'session_config.json'
if config_file.exists():
    config = json.loads(config_file.read_text())
    if config.get('api_key') and config.get('project'):
        print('CONFIGURED')
        print(f'project={{config[\"project\"]}}')
    else:
        print('INCOMPLETE')
else:
    print('NOT_CONFIGURED')
"
```

### Step 2a: If NOT_CONFIGURED or INCOMPLETE

Ask the user for their OpenRunner API key and base URL. Then list projects and ask them to pick one. Save to ~/.openrunner/session_config.json.

### Step 2b: If CONFIGURED (or after setup)

Sync the current session. Use $ARGUMENTS as project override if provided:

```bash
python3 -c "
import sys, os
from pathlib import Path
for p in [os.path.expanduser(f'~/.local/lib/python3.{{v}}/site-packages') for v in (12,11,10)]:
    if os.path.isdir(p): sys.path.insert(0, p)
from openrunner.session import parse_claude_session, sync_session_to_openrunner, get_session_config

cwd = Path.cwd()
cwd_key = '-' + str(cwd).replace('/', '-').lstrip('-')
project_dir = Path.home() / '.claude' / 'projects' / cwd_key
if not project_dir.exists():
    for d in (Path.home() / '.claude' / 'projects').iterdir():
        if d.is_dir() and cwd_key in d.name:
            project_dir = d
            break

sessions = sorted(
    [f for f in project_dir.rglob('*.jsonl') if f.stat().st_size > 100 and '.meta.' not in f.name],
    key=lambda f: f.stat().st_mtime, reverse=True,
) if project_dir.exists() else []

if not sessions:
    print('No session files found.')
    sys.exit(1)

latest = sessions[0]
print(f'Syncing: {{latest.name}} ({{latest.stat().st_size // 1024}} KB)')
parsed = parse_claude_session(latest)
print(f'  Messages: {{parsed[\"message_count\"]}} ({{parsed[\"user_message_count\"]}} user)')
print(f'  Tokens: {{parsed.get(\"total_tokens\", 0):,}}')

project_override = '$ARGUMENTS'.strip() or None
run_id = sync_session_to_openrunner(parsed, project=project_override)
if run_id:
    config = get_session_config()
    base = config.get('base_url', '')
    print(f'Synced -> {{base}}/runs/{{run_id}}')
else:
    print('Sync failed. Run: openrunner session setup')
"
```

### Step 3: Report the run URL and stats to the user.
"""

LOG_NOTE_CMD = """---
name: {prefix}log-note
description: Log a research note to OpenRunner
---

Log the user's note text to OpenRunner as a quick research entry. Run:

```bash
python3 -c "
import os, sys, json
from pathlib import Path

for p in [os.path.expanduser('~/.local/lib/python3.12/site-packages'),
          os.path.expanduser('~/.local/lib/python3.11/site-packages')]:
    if os.path.isdir(p):
        sys.path.insert(0, p)

from openrunner.api_client import APIClient

settings_file = Path.home() / '.openrunner' / 'settings.json'
settings = json.loads(settings_file.read_text()) if settings_file.exists() else {{}}
api_key = os.environ.get('OPENRUNNER_API_KEY') or settings.get('api_key')
base_url = os.environ.get('OPENRUNNER_BASE_URL') or settings.get('base_url', config.get('base_url', ''))
project = os.environ.get('OPENRUNNER_SESSION_PROJECT', 'research-sessions')

note = '''$ARGUMENTS'''

client = APIClient(base_url=base_url, api_key=api_key)
result = client.create_run({{
    'project': project,
    'display_name': f'note: {{note[:50]}}',
    'notes': note,
    'tags': ['note', 'quick'],
    'state': 'finished',
}})
if result:
    print(f'Note logged: run {{result[\"id\"]}}')
else:
    print('Failed. Run: openrunner login')
client.close()
"
```
"""

# ---------------------------------------------------------------------------
# Installers per tool
# ---------------------------------------------------------------------------


SETUP_CMD = """---
name: {prefix}setup
description: Configure OpenRunner API key and project for this workspace
allowed-tools:
  - Bash
  - AskUserQuestion
---

Interactive setup for OpenRunner session sync in this workspace.

## Process

1. Check if global config exists (`~/.openrunner/session_config.json`). If no API key, ask user for it. Save globally.

2. If no local project config, list available projects:

```bash
python3 -c "
import sys, os, json
from pathlib import Path
for p in [os.path.expanduser(f'~/.local/lib/python3.{{v}}/site-packages') for v in (12,11,10)]:
    if os.path.isdir(p): sys.path.insert(0, p)
from openrunner.api_client import APIClient
config = json.loads((Path.home() / '.openrunner' / 'session_config.json').read_text())
client = APIClient(base_url=config['base_url'], api_key=config['api_key'])
for i, p in enumerate(client.list_projects(), 1):
    print(f'  [{{i}}] {{p.get(\"org_name\",\"?\") }}/{{p.get(\"name\",\"?\")}}')
client.close()
"
```

3. Ask user to pick a project number. Save to `.openrunner/session.json` in CWD.
"""

LIST_SESSIONS_CMD = """---
name: {prefix}list-sessions
description: List AI sessions logged to the current project in OpenRunner
allowed-tools:
  - Bash
---

List recent AI sessions. Run:

```bash
python3 -c "
import sys, os, json
from pathlib import Path
for p in [os.path.expanduser(f'~/.local/lib/python3.{{v}}/site-packages') for v in (12,11,10)]:
    if os.path.isdir(p): sys.path.insert(0, p)
from openrunner.session import get_session_config
from openrunner.api_client import APIClient
config = get_session_config()
if not config.get('api_key'): print('Not configured. Run /openrunner:setup'); sys.exit(1)
client = APIClient(base_url=config['base_url'], api_key=config['api_key'])
project_name = config.get('project', '')
project_id = None
for p in client.list_projects():
    if f'{{p.get(\"org_name\",\"\")}}/{{p.get(\"name\",\"\")}}' == project_name or p.get('name') == project_name:
        project_id = p.get('id'); break
if not project_id: print(f'Project not found'); sys.exit(1)
resp = client._request('get', f'/projects/{{project_id}}/ai-sessions?limit=20')
data = resp.json()
for s in data.get('sessions', []):
    src = s.get('source','?')[:12]
    title = (s.get('title') or 'untitled')[:40]
    msgs = s.get('message_count',0)
    tokens = s.get('total_tokens',0)
    tok = f'{{tokens//1000}}K' if tokens>1000 else str(tokens)
    print(f'  {{src:<12}} {{title:<40}} {{msgs:>4}} msgs  {{tok:>6}} tok')
client.close()
"
```

Show results to user.
"""

CHAT_CMD = """---
name: {prefix}chat
description: Chat with the most recent AI session logged to OpenRunner
argument-hint: "<question>"
allowed-tools:
  - Bash
---

Ask about the latest AI session:

```bash
python3 -c "
import sys, os, json
from pathlib import Path
for p in [os.path.expanduser(f'~/.local/lib/python3.{{v}}/site-packages') for v in (12,11,10)]:
    if os.path.isdir(p): sys.path.insert(0, p)
from openrunner.session import get_session_config
from openrunner.api_client import APIClient
config = get_session_config()
if not config.get('api_key'): print('Not configured.'); sys.exit(1)
client = APIClient(base_url=config['base_url'], api_key=config['api_key'])
project_name = config.get('project', '')
project_id = None
for p in client.list_projects():
    if f'{{p.get(\"org_name\",\"\")}}/{{p.get(\"name\",\"\")}}' == project_name or p.get('name') == project_name:
        project_id = p.get('id'); break
if not project_id: print('Project not found'); sys.exit(1)
resp = client._request('get', f'/projects/{{project_id}}/ai-sessions?limit=1')
sessions = resp.json().get('sessions', [])
if not sessions: print('No sessions. Sync first.'); sys.exit(1)
session_id = sessions[0]['id']
question = '''$ARGUMENTS'''
if not question.strip(): print(f'Latest: {{sessions[0].get(\"title\")}}'); sys.exit(0)
resp = client._request('post', f'/projects/{{project_id}}/ai-sessions/{{session_id}}/chat', json={{'message': question, 'history': []}})
if resp.status_code == 200: print(resp.json().get('message',''))
else: print(f'Error: {{resp.status_code}}')
client.close()
"
```

Show the response to the user.
"""


LOGIN_CMD = """---
name: {prefix}login
description: Authenticate OpenRunner CLI via browser
allowed-tools:
  - Bash
---

Run the OpenRunner browser-based login:

```bash
python3 -c "
import sys, os, subprocess
for p in [os.path.expanduser(f'~/.local/lib/python3.{{v}}/site-packages') for v in (12,11,10)]:
    if os.path.isdir(p): sys.path.insert(0, p)
subprocess.run([sys.executable, '-m', 'openrunner.cli', 'login'])
" || echo 'Run: pip install openrunner-sdk && openrunner login'
```

If browser doesn't open, copy the URL shown and open it manually.
After approval, the CLI gets its token automatically.
"""

CODE_UPLOAD_CMD = """---
name: {prefix}code-upload
description: Upload current directory code to OpenRunner as artifact (redacted)
allowed-tools:
  - Bash
  - AskUserQuestion
---

Upload redacted source code from CWD to OpenRunner as artifact:

```bash
python3 -c "
import sys, os
from pathlib import Path
for p in [os.path.expanduser(f'~/.local/lib/python3.{{v}}/site-packages') for v in (12,11,10)]:
    if os.path.isdir(p): sys.path.insert(0, p)

from openrunner.session import get_session_config
from openrunner.api_client import APIClient
from openrunner.redact import redact_text
import tempfile, shutil

config = get_session_config()
if not config.get('api_key'):
    print('Not configured. Run /openrunner:setup first.')
    sys.exit(1)

project_name = config.get('project', '')
CODE_EXTENSIONS = ('.py', '.yaml', '.yml', '.toml', '.cfg', '.sh', '.json', 'Dockerfile', 'Makefile', 'requirements.txt', 'pyproject.toml')
SKIP_DIRS = {{'.git', '__pycache__', 'node_modules', 'venv', '.venv', 'dist', 'build', '.openrunner'}}

cwd = Path.cwd()
files_collected = []
for fpath in sorted(cwd.rglob('*')):
    if not fpath.is_file(): continue
    rel = str(fpath.relative_to(cwd))
    parts = Path(rel).parts
    if any(p.startswith('.') or p in SKIP_DIRS for p in parts): continue
    if not any(rel.endswith(ext) or rel == ext for ext in CODE_EXTENSIONS): continue
    if fpath.stat().st_size > 1_000_000: continue
    files_collected.append((rel, fpath))

print(f'Found {{len(files_collected)}} source files')
if not files_collected:
    print('No source files found.')
    sys.exit(1)

tmp_dir = Path(tempfile.mkdtemp(prefix='or-code-'))
redacted_count = 0
for rel, fpath in files_collected:
    content = fpath.read_text(errors='replace')
    result = redact_text(content, mode='regex')
    redacted_count += result.redacted_count
    dest = tmp_dir / rel
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_text(result.text)

if redacted_count > 0:
    print(f'Redacted {{redacted_count}} secrets')

import openrunner
os.environ['OPENRUNNER_API_KEY'] = config['api_key']
os.environ['OPENRUNNER_BASE_URL'] = config.get('base_url', '')
run = openrunner.init(project=project_name, name='code-upload', save_code=False)
artifact = openrunner.Artifact('source-code', type='code')
artifact.add_dir(str(tmp_dir))
result = run.log_artifact(artifact)
run.finish()
shutil.rmtree(tmp_dir, ignore_errors=True)

if result:
    print(f'Uploaded source-code artifact (v{{result.get(\"version\", \"?\")}}) — {{len(files_collected)}} files, {{redacted_count}} secrets redacted')
else:
    print('Upload failed.')
"
```

Report result to user.
"""


UPDATE_CMD = """---
name: {prefix}update
description: Update OpenRunner SDK and reinstall all commands
allowed-tools:
  - Bash
---

Upgrade openrunner-sdk and reinstall slash commands:

```bash
pip install --upgrade openrunner-sdk 2>&1 | tail -3 && python3 -c "
import sys, os
from pathlib import Path
for p in [os.path.expanduser(f'~/.local/lib/python3.{{v}}/site-packages') for v in (12,11,10)]:
    if os.path.isdir(p): sys.path.insert(0, p)
marker = Path.home() / '.openrunner' / '.commands_version'
if marker.exists(): marker.unlink()
import importlib, openrunner
importlib.reload(openrunner)
print(f'OpenRunner SDK {{openrunner.__version__}}')
cmd_dir = Path.home() / '.claude' / 'commands' / 'openrunner'
if cmd_dir.exists():
    print('Commands installed:')
    for f in sorted(cmd_dir.glob('*.md')):
        print(f'  /openrunner:{{f.stem}}')
"
```

Report version and installed commands to user.
"""


def install_claude_code() -> list[str]:
    """Install commands in ~/.claude/commands/openrunner/."""
    cmd_dir = Path.home() / ".claude" / "commands" / "openrunner"
    cmd_dir.mkdir(parents=True, exist_ok=True)

    commands = {
        "sync-session.md": SYNC_SESSION_CMD,
        "log-note.md": LOG_NOTE_CMD,
        "setup.md": SETUP_CMD,
        "list-sessions.md": LIST_SESSIONS_CMD,
        "chat.md": CHAT_CMD,
        "login.md": LOGIN_CMD,
        "code-upload.md": CODE_UPLOAD_CMD,
        "update.md": UPDATE_CMD,
    }

    files = []
    for filename, template in commands.items():
        path = cmd_dir / filename
        path.write_text(template.format(prefix="openrunner:"))
        files.append(str(path))

    return files


def _install_all_commands_to_dir(cmd_dir: Path, prefix: str = "openrunner:") -> list[str]:
    """Install all commands to a given directory."""
    cmd_dir.mkdir(parents=True, exist_ok=True)

    commands = {
        "sync-session.md": SYNC_SESSION_CMD,
        "log-note.md": LOG_NOTE_CMD,
        "setup.md": SETUP_CMD,
        "list-sessions.md": LIST_SESSIONS_CMD,
        "chat.md": CHAT_CMD,
        "login.md": LOGIN_CMD,
        "code-upload.md": CODE_UPLOAD_CMD,
        "update.md": UPDATE_CMD,
    }

    files = []
    for filename, template in commands.items():
        path = cmd_dir / filename
        path.write_text(template.format(prefix=prefix))
        files.append(str(path))

    return files


def install_codex() -> list[str]:
    """Install commands for Codex CLI.

    Codex uses ~/.codex/prompts/ for custom slash commands (Markdown).
    Also adds instructions to AGENTS.md for implicit context.
    Ref: https://developers.openai.com/codex/custom-prompts
    """
    # Codex custom prompts directory
    files = _install_all_commands_to_dir(Path.home() / ".codex" / "prompts")

    # Also add to AGENTS.md for implicit context
    agents_file = Path.home() / ".codex" / "AGENTS.md"
    instruction = "\n\n## OpenRunner Integration\nUse `/prompts:openrunner:sync-session` to log this session.\nUse `/prompts:openrunner:setup` to configure.\nUse `/prompts:openrunner:chat <question>` to ask about sessions.\nUse `/prompts:openrunner:login` to authenticate.\n"
    if agents_file.exists():
        content = agents_file.read_text()
        if "openrunner" not in content.lower():
            agents_file.write_text(content + instruction)
            files.append(str(agents_file))
    else:
        agents_file.write_text("# Codex Agent Instructions" + instruction)
        files.append(str(agents_file))

    return files


def install_qwen_code() -> list[str]:
    """Install commands for Qwen Code.

    Qwen Code uses .qwen-code/commands/ in project root or ~/.qwen-code/commands/ globally.
    Supports Markdown format with YAML frontmatter.
    Ref: https://github.com/QwenLM/qwen-code/blob/main/docs/users/features/commands.md
    """
    return _install_all_commands_to_dir(Path.home() / ".qwen-code" / "commands")


def install_opencode() -> list[str]:
    """Install commands for OpenCode.

    OpenCode uses ~/.config/opencode/commands/ for global user commands.
    Each .md file becomes a user:filename command.
    Ref: https://opencode.ai/docs/commands/
    """
    return _install_all_commands_to_dir(Path.home() / ".config" / "opencode" / "commands")


# ---------------------------------------------------------------------------
# Main installer
# ---------------------------------------------------------------------------

TOOLS = {
    "claude": ("Claude Code", install_claude_code),
    "codex": ("Codex", install_codex),
    "qwen": ("Qwen Code", install_qwen_code),
    "opencode": ("OpenCode", install_opencode),
}


def install_all(targets: list[str] | None = None) -> dict[str, list[str]]:
    """Install commands for specified tools (or all if None).

    Returns dict of tool_name -> list of installed file paths.
    """
    results = {}

    if targets:
        to_install = [(k, v) for k, v in TOOLS.items() if k in targets]
    else:
        # Auto-detect: install for all tools
        to_install = list(TOOLS.items())

    for key, (name, installer) in to_install:
        files = installer()
        results[name] = files

    return results
