"""OpenRunner CLI - ML experiment tracking command-line interface.

Commands:
  login    - Authenticate and store API key
  sync     - Upload offline training runs to server
  ls       - List projects and runs
  sweep    - Hyperparameter sweep commands (create, agent)
  init     - Initialize OpenRunner config in current directory
  status   - Show current configuration
  verify   - Health check against self-hosted instance
  pull     - Download all files associated with a run
  online   - Set SDK to online mode
  offline  - Set SDK to offline mode
  enabled  - Enable the SDK
  disabled - Disable the SDK
"""

from __future__ import annotations

import fnmatch
import json
import logging
import os
import shutil
import time
from pathlib import Path
from typing import Any

import click

from openrunner.api_client import APIClient
from openrunner.offline import OfflineStorage, OfflineSync

logger = logging.getLogger("openrunner")


# ---------------------------------------------------------------------------
# Auto-install commands
# ---------------------------------------------------------------------------


def _auto_install_commands() -> None:
    """Auto-install/update slash commands for all AI tools if outdated."""
    try:
        from openrunner import __version__
        marker = Path.home() / ".openrunner" / ".commands_version"
        if marker.exists() and marker.read_text().strip() == __version__:
            return  # already up to date
        # Install for all detected tools silently
        from openrunner.install_commands import install_all
        install_all()
        marker.parent.mkdir(parents=True, exist_ok=True)
        marker.write_text(__version__)
    except Exception:
        pass  # never crash on auto-install


# ---------------------------------------------------------------------------
# Settings helpers
# ---------------------------------------------------------------------------


def _settings_dir() -> Path:
    """Return the OpenRunner settings directory (~/.openrunner)."""
    return Path.home() / ".openrunner"


def _load_settings() -> dict[str, Any]:
    """Load settings from ~/.openrunner/settings.json."""
    settings_file = _settings_dir() / "settings.json"
    if not settings_file.exists():
        return {}
    try:
        return json.loads(settings_file.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return {}


def _save_settings(settings: dict[str, Any]) -> None:
    """Save settings to ~/.openrunner/settings.json."""
    d = _settings_dir()
    d.mkdir(parents=True, exist_ok=True)
    (d / "settings.json").write_text(
        json.dumps(settings, indent=2), encoding="utf-8"
    )


# ---------------------------------------------------------------------------
# CLI group
# ---------------------------------------------------------------------------


@click.group(invoke_without_command=True)
@click.pass_context
def main(ctx) -> None:
    """OpenRunner CLI - ML experiment tracking."""
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())
    # Auto-install/update Claude Code commands on any CLI invocation
    _auto_install_commands()


# ---------------------------------------------------------------------------
# login command
# ---------------------------------------------------------------------------


@main.command()
@click.option("--host", default=None, help="Server URL")
@click.option("--expiry", default=90, type=int, help="Token expiry in days (default: 90)")
@click.option("--manual", is_flag=True, help="Skip browser flow and paste API key manually")
def login(host: str | None, expiry: int, manual: bool) -> None:
    """Authenticate via browser (like claude login).

    Opens your browser to the OpenRunner web app where you approve
    the CLI session. An API key is created automatically and stored
    in ~/.openrunner/settings.json.

    Use --manual to skip the browser flow and paste an API key directly.
    """
    settings = _load_settings()
    if host:
        base_url = host
    elif settings.get("base_url"):
        base_url = settings["base_url"]
    elif sys.stdin.isatty():
        base_url = click.prompt("Server URL")
    else:
        click.echo("Error: No server URL configured. Run with --host or set base_url in ~/.openrunner/settings.json")
        return

    if manual:
        # Legacy manual flow
        api_key = click.prompt("API Key", hide_input=True)
        settings["api_key"] = api_key
        settings["base_url"] = base_url
        _save_settings(settings)
        settings_path = _settings_dir() / "settings.json"
        click.echo(f"Login successful. API key stored at {settings_path}")
        return

    # Browser-based login flow
    try:
        import httpx
    except ImportError:
        click.echo("Error: httpx is required. Install with: pip install httpx", err=True)
        raise SystemExit(1)

    # Initiate CLI auth session
    try:
        resp = httpx.post(
            f"{base_url.rstrip('/')}/api/v1/auth/cli/initiate",
            json={"expiry_days": expiry},
            timeout=15.0,
        )
        if resp.status_code != 200:
            click.echo(f"Error: Server returned {resp.status_code}. Is the server URL correct?", err=True)
            click.echo(f"  URL: {base_url}", err=True)
            raise SystemExit(1)
        data = resp.json()
    except httpx.ConnectError:
        click.echo(f"Error: Could not connect to {base_url}", err=True)
        click.echo("Check the server URL and try again.", err=True)
        raise SystemExit(1)
    except Exception as e:
        click.echo(f"Error initiating login: {e}", err=True)
        raise SystemExit(1)

    code = data["code"]
    auth_url = data["url"]

    click.echo(f"Opening browser for authentication...")
    click.echo(f"If browser doesn't open, visit: {auth_url}")
    click.echo()

    # Try to open browser
    import webbrowser
    webbrowser.open(auth_url)

    # Poll for approval
    click.echo("Waiting for approval...", nl=False)
    for i in range(120):  # 4 min timeout (120 * 2s)
        time.sleep(2)
        try:
            poll_resp = httpx.get(
                f"{base_url.rstrip('/')}/api/v1/auth/cli/poll/{code}",
                timeout=10.0,
            )
            poll_data = poll_resp.json()
        except Exception:
            click.echo(".", nl=False)
            continue

        if poll_data["status"] == "approved":
            click.echo()
            api_key = poll_data["api_key"]
            email = poll_data.get("email", "")
            settings["api_key"] = api_key
            settings["base_url"] = base_url
            _save_settings(settings)
            click.echo(f"Authenticated as {email}")
            settings_path = _settings_dir() / "settings.json"
            click.echo(f"API key saved to {settings_path} (expires in {expiry} days)")
            return
        elif poll_data["status"] == "expired":
            click.echo()
            click.echo("Session expired. Please try again.")
            return
        else:
            # Still pending
            if i % 5 == 0:
                click.echo(".", nl=False)

    # Timeout -- offer manual paste
    click.echo()
    click.echo("Browser auth timed out.")
    manual_key = click.prompt(
        "Paste API key manually (from Settings > API Keys page)",
        default="",
        show_default=False,
    )
    if manual_key.strip():
        settings["api_key"] = manual_key.strip()
        settings["base_url"] = base_url
        _save_settings(settings)
        click.echo("API key saved.")


# ---------------------------------------------------------------------------
# init command
# ---------------------------------------------------------------------------


@main.command()
@click.option("--project", "-p", default=None, help="Default project name")
@click.option("--entity", "-e", default=None, help="Default entity/team name")
def init(project: str | None, entity: str | None) -> None:
    """Initialize OpenRunner configuration in the current directory.

    Creates a .openrunner/ directory with a settings.json file
    containing default project configuration.

    Examples:

        openrunner init

        openrunner init --project my-ml-project --entity my-team
    """
    local_dir = Path.cwd() / ".openrunner"
    settings_file = local_dir / "settings.json"

    if settings_file.exists():
        click.echo(f"OpenRunner already initialized in {local_dir}")
        existing = {}
        try:
            existing = json.loads(settings_file.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            pass
        if project or entity:
            if project:
                existing["project"] = project
            if entity:
                existing["entity"] = entity
            settings_file.write_text(
                json.dumps(existing, indent=2), encoding="utf-8"
            )
            click.echo("Updated configuration.")
        return

    local_dir.mkdir(parents=True, exist_ok=True)

    settings: dict[str, Any] = {}

    # Copy API key and base_url from global settings if available
    global_settings = _load_settings()
    if global_settings.get("api_key"):
        settings["api_key"] = global_settings["api_key"]
    if global_settings.get("base_url"):
        settings["base_url"] = global_settings["base_url"]

    if project:
        settings["project"] = project
    if entity:
        settings["entity"] = entity

    settings_file.write_text(
        json.dumps(settings, indent=2), encoding="utf-8"
    )

    click.echo(f"Initialized OpenRunner in {local_dir}/")
    click.echo(f"  Settings: {settings_file}")
    if project:
        click.echo(f"  Project:  {project}")
    if entity:
        click.echo(f"  Entity:   {entity}")
    if not global_settings.get("api_key"):
        click.echo("")
        click.echo("Run 'openrunner login' to authenticate.")


# ---------------------------------------------------------------------------
# sync command
# ---------------------------------------------------------------------------


@main.command()
@click.argument("path", required=False)
@click.option("--all", "sync_all", is_flag=True, help="Sync all offline runs")
@click.option(
    "--include-globs", default=None,
    help="Comma-separated glob patterns for files to include",
)
@click.option(
    "--exclude-globs", default=None,
    help="Comma-separated glob patterns for files to exclude",
)
@click.option("--clean", is_flag=True, help="Remove synced offline files after upload")
@click.option(
    "--clean-old-hours", type=float, default=None,
    help="Remove offline files older than N hours",
)
@click.option("--append", is_flag=True, help="Append to existing run instead of creating new")
@click.option(
    "--sync-tensorboard", is_flag=True,
    help="Parse TensorBoard event files from PATH and upload as OpenRunner metrics",
)
@click.option(
    "--tensorboard-project", default=None,
    help="Project name for TensorBoard import (default: tensorboard-import)",
)
def sync(
    path: str | None,
    sync_all: bool,
    include_globs: str | None,
    exclude_globs: str | None,
    clean: bool,
    clean_old_hours: float | None,
    append: bool,
    sync_tensorboard: bool,
    tensorboard_project: str | None,
) -> None:
    """Upload offline training runs to the server.

    Provide a PATH to sync a specific run directory, or use --all to
    discover and sync all offline runs.

    Advanced options:

        --include-globs '*.json,*.jsonl'  Only sync files matching patterns

        --exclude-globs '*.tmp,*.log'     Skip files matching patterns

        --clean                           Remove synced offline data after upload

        --clean-old-hours 48              Remove offline runs older than 48 hours

        --append                          Append metrics to existing server run

        --sync-tensorboard                Import TensorBoard event files as metrics
    """
    settings = _load_settings()
    api_key = settings.get("api_key")
    base_url = settings.get("base_url", "http://localhost:8000")

    if not api_key:
        click.echo("Error: Not logged in. Run 'openrunner login' first.", err=True)
        raise SystemExit(1)

    # --- TensorBoard sync mode ---
    if sync_tensorboard:
        if not path:
            click.echo("Error: PATH is required with --sync-tensorboard.", err=True)
            raise SystemExit(1)
        _sync_tensorboard_events(
            logdir=path,
            api_key=api_key,
            base_url=base_url,
            project=tensorboard_project,
        )
        return

    client = APIClient(base_url=base_url, api_key=api_key)

    # Parse glob patterns
    include_patterns = [p.strip() for p in include_globs.split(",")] if include_globs else None
    exclude_patterns = [p.strip() for p in exclude_globs.split(",")] if exclude_globs else None

    run_dirs: list[Path] = []

    if clean_old_hours is not None:
        # Clean old offline runs
        all_runs = OfflineStorage.list_offline_runs()
        cutoff = time.time() - (clean_old_hours * 3600)
        removed = 0
        for run_dir in all_runs:
            try:
                mtime = run_dir.stat().st_mtime
                if mtime < cutoff:
                    shutil.rmtree(str(run_dir), ignore_errors=True)
                    click.echo(f"Cleaned old run: {run_dir.name}")
                    removed += 1
            except OSError:
                pass
        click.echo(f"Removed {removed} old offline run(s).")
        if not sync_all and not path:
            client.close()
            return

    if sync_all:
        run_dirs = OfflineStorage.list_offline_runs()
    elif path:
        run_dirs = [Path(path)]
    else:
        click.echo("Error: Provide a path or use --all.", err=True)
        raise SystemExit(1)

    # Filter run dirs by glob patterns if specified
    if include_patterns or exclude_patterns:
        filtered: list[Path] = []
        for run_dir in run_dirs:
            files_in_dir = [f.name for f in run_dir.iterdir() if f.is_file()]
            matched_files = files_in_dir

            if include_patterns:
                matched_files = [
                    f for f in matched_files
                    if any(fnmatch.fnmatch(f, pat) for pat in include_patterns)
                ]

            if exclude_patterns:
                matched_files = [
                    f for f in matched_files
                    if not any(fnmatch.fnmatch(f, pat) for pat in exclude_patterns)
                ]

            if matched_files:
                filtered.append(run_dir)

        run_dirs = filtered

    if not run_dirs:
        click.echo("No offline runs found.")
        client.close()
        return

    total = len(run_dirs)
    synced = 0

    for run_dir in run_dirs:
        run_id = run_dir.name
        click.echo(f"Syncing run {run_id}... ", nl=False)
        try:
            syncer = OfflineSync(run_dir, client)
            if append:
                # In append mode, skip run creation and go straight to metrics
                syncer._append_mode = True
            if syncer.sync():
                click.echo("done")
                synced += 1
                if clean:
                    shutil.rmtree(str(run_dir), ignore_errors=True)
                    click.echo(f"  Cleaned {run_dir.name}")
            else:
                click.echo("failed")
        except Exception as e:
            click.echo(f"failed: {e}")

    click.echo(f"Synced {synced}/{total} runs.")

    client.close()


# ---------------------------------------------------------------------------
# ls command
# ---------------------------------------------------------------------------


@main.command()
@click.option("--project", "-p", default=None, help="List runs in a project")
def ls(project: str | None) -> None:
    """List projects or runs.

    Without --project, lists all projects. With --project, lists runs
    in the specified project.
    """
    settings = _load_settings()
    api_key = settings.get("api_key")
    base_url = settings.get("base_url", "http://localhost:8000")

    if not api_key:
        click.echo("Error: Not logged in. Run 'openrunner login' first.", err=True)
        raise SystemExit(1)

    client = APIClient(base_url=base_url, api_key=api_key)

    if project is None:
        # List projects
        projects = client.list_projects()
        if not projects:
            click.echo("No projects found.")
        else:
            click.echo(f"{'NAME':<30} {'ID'}")
            click.echo("-" * 60)
            for p in projects:
                name = p.get("name", p.get("slug", "unknown"))
                pid = p.get("id", "")
                click.echo(f"{name:<30} {pid}")
    else:
        # List runs in a project
        # First resolve project name to ID
        projects = client.list_projects()
        project_id = None
        for p in projects:
            pname = p.get("name", p.get("slug", ""))
            if pname == project:
                project_id = p.get("id")
                break

        if project_id is None:
            click.echo(f"Project '{project}' not found.")
            client.close()
            return

        runs = client.list_runs(project_id)
        if not runs:
            click.echo(f"No runs found in project '{project}'.")
        else:
            click.echo(f"{'ID':<12} {'NAME':<25} {'STATE':<12}")
            click.echo("-" * 50)
            for r in runs:
                rid = r.get("id", "")
                name = r.get("display_name", "") or ""
                state = r.get("state", "")
                click.echo(f"{rid:<12} {name:<25} {state:<12}")

    client.close()


# ---------------------------------------------------------------------------
# artifact command group
# ---------------------------------------------------------------------------


def _get_client() -> "APIClient":
    """Create an APIClient from stored settings. Exits on auth failure."""
    import os

    settings = _load_settings()
    api_key = os.environ.get("OPENRUNNER_API_KEY") or settings.get("api_key")
    base_url = os.environ.get("OPENRUNNER_BASE_URL") or settings.get(
        "base_url", "http://localhost:8000"
    )

    if not api_key:
        click.echo(
            "Error: Not logged in. Run 'openrunner login' first "
            "or set OPENRUNNER_API_KEY.",
            err=True,
        )
        raise SystemExit(1)

    return APIClient(base_url=base_url, api_key=api_key)


def _resolve_project_id(client: "APIClient", project_name: str | None) -> str | None:
    """Resolve a project name to its UUID. Returns None if not found."""
    if project_name is None:
        return None
    # If it looks like a UUID already, use it directly
    if len(project_name) == 36 and project_name.count("-") == 4:
        return project_name
    projects = client.list_projects()
    for p in projects:
        pname = p.get("name", p.get("slug", ""))
        if pname == project_name:
            return p.get("id")
    return None


def _format_size(size_bytes: int) -> str:
    """Format bytes into human-readable size."""
    if size_bytes < 1024:
        return f"{size_bytes} B"
    if size_bytes < 1024 * 1024:
        return f"{size_bytes / 1024:.1f} KB"
    if size_bytes < 1024 * 1024 * 1024:
        return f"{size_bytes / (1024 * 1024):.1f} MB"
    return f"{size_bytes / (1024 * 1024 * 1024):.2f} GB"


@main.group()
def artifact() -> None:
    """Artifact management commands."""
    pass


@artifact.command("list")
@click.argument("project", required=False)
@click.option("--project", "-p", "project_opt", default=None, help="Project name")
def artifact_list(project: str | None, project_opt: str | None) -> None:
    """List artifacts in a project.

    PROJECT can be given as positional arg or via --project/-p.
    """
    project_name = project or project_opt
    if not project_name:
        click.echo("Error: Project name required. Use: openrunner artifact list <project>", err=True)
        raise SystemExit(1)

    client = _get_client()

    project_id = _resolve_project_id(client, project_name)
    if project_id is None:
        click.echo(f"Project '{project_name}' not found.")
        client.close()
        return

    artifacts = client.list_artifacts(project_id)
    if not artifacts:
        click.echo(f"No artifacts in project '{project_name}'.")
        client.close()
        return

    click.echo(f"{'NAME':<30} {'TYPE':<12} {'VERSION':<10} {'CREATED'}")
    click.echo("-" * 75)
    for art in artifacts:
        name = art.get("name", "")[:30]
        atype = art.get("type", "")[:12]
        ver = art.get("latest_version")
        ver_str = f"v{ver}" if ver is not None else "---"
        created = art.get("created_at", "")[:10]
        click.echo(f"{name:<30} {atype:<12} {ver_str:<10} {created}")

    client.close()


@artifact.command("get")
@click.argument("name")
@click.option("--root", "-r", default=".", help="Download directory (default: .)")
def artifact_get(name: str, root: str) -> None:
    """Download an artifact to a local directory.

    NAME can use colon syntax: my-dataset:latest or my-model:v3.
    If no version/alias is given, downloads the latest version.
    """
    client = _get_client()

    # Parse name:alias_or_version syntax
    alias: str | None = None
    version: int | None = None
    artifact_name = name

    if ":" in name:
        artifact_name, ref = name.rsplit(":", 1)
        if ref.startswith("v") and ref[1:].isdigit():
            version = int(ref[1:])
        elif ref.isdigit():
            version = int(ref)
        else:
            alias = ref

    # Find artifact by listing all accessible projects
    projects = client.list_projects()
    artifact_detail = None
    target_version_id = None

    for proj in projects:
        pid = proj.get("id", "")
        arts = client.list_artifacts(pid)
        for art in arts:
            if art.get("name") == artifact_name:
                artifact_detail = client.get_artifact_detail(str(art["id"]))
                break
        if artifact_detail:
            break

    if artifact_detail is None:
        click.echo(f"Artifact '{artifact_name}' not found.")
        client.close()
        return

    versions = artifact_detail.get("versions", [])
    if not versions:
        click.echo(f"No versions found for artifact '{artifact_name}'.")
        client.close()
        return

    # Resolve the target version
    if version is not None:
        for v in versions:
            if v.get("version") == version and v.get("state") == "confirmed":
                target_version_id = v["id"]
                break
        if target_version_id is None:
            click.echo(f"Version v{version} not found for '{artifact_name}'.")
            client.close()
            return
    elif alias is not None:
        # Check aliases
        aliases = client.list_aliases(str(artifact_detail["id"]))
        for a in aliases:
            if a.get("alias_name") == alias:
                target_version_id = a["version_id"]
                break
        if target_version_id is None:
            click.echo(f"Alias '{alias}' not found for '{artifact_name}'.")
            client.close()
            return
    else:
        # Latest confirmed version
        confirmed = [v for v in versions if v.get("state") == "confirmed"]
        if confirmed:
            confirmed.sort(key=lambda v: v.get("version", 0), reverse=True)
            target_version_id = confirmed[0]["id"]
        else:
            click.echo(f"No confirmed versions for '{artifact_name}'.")
            client.close()
            return

    # Get download URLs
    download_info = client.get_artifact_download_urls(target_version_id)
    if download_info is None or not download_info.get("files"):
        click.echo("No files to download.")
        client.close()
        return

    # Download each file
    dest_dir = Path(root) / artifact_name
    dest_dir.mkdir(parents=True, exist_ok=True)

    files = download_info["files"]
    total = len(files)

    click.echo(f"Downloading {total} file(s) to {dest_dir}/")

    downloaded = 0
    for file_entry in files:
        fpath = file_entry.get("path", "unknown")
        is_ref = file_entry.get("is_reference", False)

        if is_ref:
            ref_uri = file_entry.get("reference_uri", "")
            click.echo(f"  [ref] {fpath} -> {ref_uri}")
            # Write a .ref file with the URI
            ref_file = dest_dir / f"{fpath}.ref"
            ref_file.parent.mkdir(parents=True, exist_ok=True)
            ref_file.write_text(ref_uri, encoding="utf-8")
            downloaded += 1
            continue

        url = file_entry.get("presigned_url", "")
        if not url:
            click.echo(f"  [skip] {fpath} -- no URL")
            continue

        data = client.download_file_from_presigned_url(url)
        if data is None:
            click.echo(f"  [fail] {fpath}")
            continue

        out_path = dest_dir / fpath
        out_path.parent.mkdir(parents=True, exist_ok=True)
        out_path.write_bytes(data)
        click.echo(f"  {fpath} ({_format_size(len(data))})")
        downloaded += 1

    click.echo(f"Downloaded {downloaded}/{total} files.")
    client.close()


@artifact.command("info")
@click.argument("name")
def artifact_info(name: str) -> None:
    """Show artifact details, versions, and aliases.

    NAME is the artifact name to look up across accessible projects.
    """
    client = _get_client()

    # Find artifact by name across all projects
    projects = client.list_projects()
    artifact_detail = None

    for proj in projects:
        pid = proj.get("id", "")
        arts = client.list_artifacts(pid)
        for art in arts:
            if art.get("name") == name:
                artifact_detail = client.get_artifact_detail(str(art["id"]))
                break
        if artifact_detail:
            break

    if artifact_detail is None:
        click.echo(f"Artifact '{name}' not found.")
        client.close()
        return

    # Header
    click.echo(f"Artifact: {artifact_detail.get('name', name)}")
    click.echo(f"Type:     {artifact_detail.get('type', '---')}")
    desc = artifact_detail.get("description")
    if desc:
        click.echo(f"Desc:     {desc}")
    click.echo(f"Created:  {artifact_detail.get('created_at', '---')[:19]}")
    click.echo()

    # Aliases
    artifact_id = str(artifact_detail["id"])
    aliases = client.list_aliases(artifact_id)
    if aliases:
        click.echo("Aliases:")
        for a in aliases:
            click.echo(f"  {a.get('alias_name', '---')} -> version {a.get('version_id', '---')[:8]}")
        click.echo()

    # Versions table
    versions = artifact_detail.get("versions", [])
    if versions:
        click.echo(f"{'VERSION':<10} {'STATE':<12} {'STAGE':<14} {'SIZE':<12} {'CREATED'}")
        click.echo("-" * 65)
        for v in versions:
            ver = f"v{v.get('version', '?')}"
            state = v.get("state", "---")
            stage = v.get("stage", "development")
            size = v.get("size_bytes")
            size_str = _format_size(size) if size else "---"
            created = v.get("created_at", "---")[:10]
            click.echo(f"{ver:<10} {state:<12} {stage:<14} {size_str:<12} {created}")
    else:
        click.echo("No versions.")

    client.close()


@artifact.group("cache")
def artifact_cache() -> None:
    """Artifact cache management."""
    pass


@artifact_cache.command("cleanup")
@click.option("--max-size", type=float, default=None, help="Max cache size in GB")
def cache_cleanup(max_size: float | None) -> None:
    """Clean up the local artifact cache.

    Without --max-size, removes all cached artifacts.
    With --max-size, evicts oldest files until the cache is under the limit.
    """
    from openrunner.cache import ArtifactCache

    cache = ArtifactCache()
    cache_dir = cache._dir

    if not cache_dir.exists():
        click.echo("No artifact cache found.")
        return

    # Calculate current cache size
    total_size = 0
    file_count = 0
    files_with_atime: list[tuple[Path, float, int]] = []

    for f in cache_dir.rglob("*"):
        if f.is_file():
            stat = f.stat()
            total_size += stat.st_size
            file_count += 1
            files_with_atime.append((f, stat.st_atime, stat.st_size))

    click.echo(
        f"Cache: {_format_size(total_size)} in {file_count} files at {cache_dir}"
    )

    if max_size is not None:
        max_bytes = int(max_size * 1024 * 1024 * 1024)
        if total_size <= max_bytes:
            click.echo(
                f"Cache ({_format_size(total_size)}) is within limit "
                f"({_format_size(max_bytes)}). No cleanup needed."
            )
            return

        # Sort by access time (oldest first) and evict
        files_with_atime.sort(key=lambda x: x[1])
        removed = 0
        freed = 0
        for fpath, _, fsize in files_with_atime:
            if total_size - freed <= max_bytes:
                break
            fpath.unlink(missing_ok=True)
            freed += fsize
            removed += 1

        click.echo(f"Removed {removed} files, freed {_format_size(freed)}.")
    else:
        # Remove everything
        import shutil

        shutil.rmtree(str(cache_dir), ignore_errors=True)
        click.echo(f"Removed all cached artifacts ({_format_size(total_size)}).")


# ---------------------------------------------------------------------------
# sweep command group
# ---------------------------------------------------------------------------


@main.group()
def sweep() -> None:
    """Hyperparameter sweep commands."""
    pass


@sweep.command("create")
@click.argument("config_file")
@click.option("--project", "-p", default=None, help="Project name")
def sweep_create(config_file: str, project: str | None) -> None:
    """Create a new hyperparameter sweep from a YAML or JSON config file.

    CONFIG_FILE should be a path to a YAML or JSON file containing the
    sweep configuration (method, metric, parameters, early_terminate).
    """
    import json as json_module

    config_path = Path(config_file)

    if not config_path.exists():
        click.echo(f"Error: Config file '{config_file}' not found.", err=True)
        raise SystemExit(1)

    content = config_path.read_text(encoding="utf-8")

    # Try YAML first, then JSON
    config = None
    if config_path.suffix in (".yaml", ".yml"):
        try:
            import yaml

            config = yaml.safe_load(content)
        except ImportError:
            click.echo(
                "Error: PyYAML is required for YAML config files. "
                "Install with: pip install pyyaml",
                err=True,
            )
            raise SystemExit(1)
        except Exception as e:
            click.echo(f"Error parsing YAML: {e}", err=True)
            raise SystemExit(1)

    if config is None:
        try:
            config = json_module.loads(content)
        except json_module.JSONDecodeError as e:
            click.echo(f"Error parsing config file: {e}", err=True)
            raise SystemExit(1)

    # Use the SDK sweep function
    from openrunner.sweep import sweep as create_sweep_fn

    sweep_id = create_sweep_fn(config, project=project)
    if sweep_id:
        click.echo(f"Created sweep: {sweep_id}")
    else:
        click.echo("Failed to create sweep.", err=True)
        raise SystemExit(1)


# ---------------------------------------------------------------------------
# launch command
# ---------------------------------------------------------------------------


@main.command()
@click.argument("image")
@click.argument("command")
@click.option("--project", "-p", default=None, help="Project name or ID")
@click.option("--name", "-n", default=None, help="Job name")
@click.option("--env", "-e", multiple=True, help="Env var as KEY=VALUE (repeatable)")
@click.option("--gpu", type=int, default=None, help="Number of GPUs")
@click.option("--wait", "do_wait", is_flag=True, help="Wait for job to finish")
def launch(
    image: str,
    command: str,
    project: str | None,
    name: str | None,
    env: tuple[str, ...],
    gpu: int | None,
    do_wait: bool,
) -> None:
    """Launch a remote execution job.

    IMAGE is the Docker image to run. COMMAND is the entrypoint command.

    Examples:

        openrunner launch pytorch/pytorch:latest "python train.py"

        openrunner launch -p my-project -e LR=0.001 nvidia/cuda "python train.py"
    """
    from openrunner.launch import launch as launch_fn

    settings = _load_settings()
    api_key = settings.get("api_key")
    if not api_key:
        click.echo("Error: Not logged in. Run 'openrunner login' first.", err=True)
        raise SystemExit(1)

    # Set env vars for SDK settings
    import os
    os.environ.setdefault("OPENRUNNER_API_KEY", api_key)
    base_url = settings.get("base_url", "http://localhost:8000")
    os.environ.setdefault("OPENRUNNER_BASE_URL", base_url)

    resolved_project = project
    if resolved_project is None:
        click.echo("Error: --project is required for launch.", err=True)
        raise SystemExit(1)

    # Parse env vars
    env_dict: dict[str, str] | None = None
    if env:
        env_dict = {}
        for e_str in env:
            if "=" in e_str:
                k, v = e_str.split("=", 1)
                env_dict[k] = v
            else:
                click.echo(f"Warning: ignoring malformed env var '{e_str}' (expected KEY=VALUE)")

    # Resource config
    resources: dict[str, int] | None = None
    if gpu is not None:
        resources = {"gpu_count": gpu}

    job = launch_fn(
        project=resolved_project,
        image=image,
        command=command,
        name=name,
        env=env_dict,
        resources=resources,
    )
    if job is None:
        click.echo("Failed to create job.", err=True)
        raise SystemExit(1)

    click.echo(f"Job created: {job.id}")
    click.echo(f"  Name:  {job.name}")
    click.echo(f"  Image: {job.image}")
    click.echo(f"  State: {job.state}")

    if do_wait:
        click.echo("Waiting for job to complete...")
        final_state = job.wait()
        click.echo(f"Job finished with state: {final_state}")


# ---------------------------------------------------------------------------
# jobs command
# ---------------------------------------------------------------------------


@main.command()
@click.option("--project", "-p", required=True, help="Project name or ID")
@click.option("--state", "-s", default=None, help="Filter by state")
def jobs(project: str, state: str | None) -> None:
    """List jobs for a project."""
    settings = _load_settings()
    api_key = settings.get("api_key")
    base_url = settings.get("base_url", "http://localhost:8000")

    if not api_key:
        click.echo("Error: Not logged in. Run 'openrunner login' first.", err=True)
        raise SystemExit(1)

    client = APIClient(base_url=base_url, api_key=api_key)

    # Resolve project name to ID
    project_id = project
    if len(project) != 36 or project.count("-") != 4:
        projects = client.list_projects()
        for p in projects:
            pname = p.get("name", p.get("slug", ""))
            if pname == project:
                project_id = p.get("id", project)
                break

    job_list = client.list_jobs(project_id)
    if not job_list:
        click.echo("No jobs found.")
        client.close()
        return

    click.echo(f"{'ID':<38} {'NAME':<20} {'STATE':<12} {'IMAGE':<30}")
    click.echo("-" * 100)
    for j in job_list:
        jid = str(j.get("id", ""))
        jname = (j.get("name", "") or "")[:20]
        jstate = j.get("state", "")
        jimage = (j.get("image", "") or "")[:30]
        click.echo(f"{jid:<38} {jname:<20} {jstate:<12} {jimage:<30}")

    client.close()


# ---------------------------------------------------------------------------
# job logs command (placeholder)
# ---------------------------------------------------------------------------


@main.group("job")
def job_group() -> None:
    """Job management commands."""
    pass


@job_group.command("logs")
@click.argument("job_id")
def job_logs(job_id: str) -> None:
    """Get job logs (placeholder).

    JOB_ID is the UUID of the job.
    """
    settings = _load_settings()
    api_key = settings.get("api_key")
    base_url = settings.get("base_url", "http://localhost:8000")

    if not api_key:
        click.echo("Error: Not logged in. Run 'openrunner login' first.", err=True)
        raise SystemExit(1)

    client = APIClient(base_url=base_url, api_key=api_key)

    job_data = client.get_job(job_id)
    if job_data is None:
        click.echo(f"Job '{job_id}' not found.")
        client.close()
        return

    logs_url = job_data.get("logs_url")
    if logs_url:
        click.echo(f"Logs URL: {logs_url}")
    else:
        click.echo(f"Job {job_id} (state: {job_data.get('state', 'unknown')})")
        click.echo("No logs URL available yet.")
        click.echo("Logs will be available after the job starts running.")

    client.close()


# ---------------------------------------------------------------------------
# status command
# ---------------------------------------------------------------------------


@main.command()
def status() -> None:
    """Show current SDK configuration and status.

    Displays API URL, authentication status, current project,
    SDK mode (online/offline), and local directory configuration.
    Reads from environment variables, global settings, and local
    project settings.
    """
    from openrunner.settings import SDKSettings

    settings = SDKSettings()
    stored = _load_settings()

    # Check local project settings
    local_settings_file = Path.cwd() / ".openrunner" / "settings.json"
    local_settings: dict[str, Any] = {}
    if local_settings_file.exists():
        try:
            local_settings = json.loads(local_settings_file.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            pass

    click.echo("OpenRunner Status")
    click.echo("=" * 40)

    # API URL
    click.echo(f"API URL:       {settings.base_url}")

    # Auth status
    api_key = os.environ.get("OPENRUNNER_API_KEY") or stored.get("api_key")
    if api_key:
        # Mask the key for display
        masked = api_key[:4] + "..." + api_key[-4:] if len(api_key) > 8 else "****"
        click.echo(f"API Key:       {masked}")

        # Try to get logged-in user info
        try:
            client = APIClient(
                base_url=settings.base_url,
                api_key=api_key,
            )
            response = client._request("get", "/auth/me")
            if response.status_code == 200:
                user_data = response.json()
                username = user_data.get("username") or user_data.get("email") or "authenticated"
                click.echo(f"Logged in as:  {username}")
            else:
                click.echo(f"Logged in as:  (could not verify)")
            client.close()
        except Exception:
            click.echo(f"Logged in as:  (could not reach server)")
    else:
        click.echo(f"API Key:       not set")
        click.echo(f"Logged in as:  not logged in")

    click.echo(f"Project:       {local_settings.get('project') or settings.project or 'not set'}")
    click.echo(f"Entity:        {local_settings.get('entity') or settings.entity or 'not set'}")

    # Mode
    disabled_val = os.environ.get("OPENRUNNER_DISABLED", "").lower()
    if disabled_val in ("true", "1", "yes"):
        click.echo(f"Mode:          disabled")
    else:
        click.echo(f"Mode:          {settings.mode}")

    click.echo(f"Silent:        {settings.silent}")
    click.echo(f"Quiet:         {settings.quiet}")
    click.echo(f"Offline dir:   {settings.offline_dir}")

    # Local config
    if local_settings:
        click.echo(f"Local config:  {local_settings_file}")
    else:
        click.echo(f"Local config:  none (run 'openrunner init' to create)")


# ---------------------------------------------------------------------------
# verify command
# ---------------------------------------------------------------------------


@main.command()
@click.option("--host", default=None, help="Server URL to verify (overrides settings)")
def verify(host: str | None) -> None:
    """Health check against OpenRunner instance.

    Runs a series of checks against the server:

    1. API connectivity (health endpoint)

    2. Authentication (API key validation)

    3. Project access (list projects)

    4. File operations (upload/download test)

    Examples:

        openrunner verify

        openrunner verify --host https://openrunner.example.com
    """
    stored = _load_settings()
    api_key = os.environ.get("OPENRUNNER_API_KEY") or stored.get("api_key")
    base_url = host or (
        os.environ.get("OPENRUNNER_BASE_URL")
        or stored.get("base_url", "http://localhost:8000")
    )

    click.echo(f"Verifying OpenRunner at {base_url}")
    click.echo("=" * 50)

    all_passed = True

    # Check 1: API connectivity
    click.echo("1. API connectivity... ", nl=False)
    try:
        import httpx
        resp = httpx.get(f"{base_url.rstrip('/')}/api/v1/health", timeout=10.0)
        if resp.status_code == 200:
            click.echo("PASS")
        else:
            click.echo(f"FAIL (HTTP {resp.status_code})")
            all_passed = False
    except Exception as e:
        click.echo(f"FAIL ({e})")
        all_passed = False

    # Check 2: Authentication
    click.echo("2. Authentication... ", nl=False)
    if not api_key:
        click.echo("SKIP (no API key configured)")
        click.echo("")
        click.echo("Set OPENRUNNER_API_KEY or run 'openrunner login'.")
        return
    try:
        client = APIClient(base_url=base_url, api_key=api_key)
        resp = client._request("get", "/auth/me")
        if resp.status_code == 200:
            user = resp.json()
            username = user.get("username") or user.get("email") or "OK"
            click.echo(f"PASS ({username})")
        elif resp.status_code == 401:
            click.echo("FAIL (invalid API key)")
            all_passed = False
        else:
            click.echo(f"FAIL (HTTP {resp.status_code})")
            all_passed = False
    except Exception as e:
        click.echo(f"FAIL ({e})")
        all_passed = False

    # Check 3: Project access
    click.echo("3. Project access... ", nl=False)
    try:
        projects = client.list_projects()
        click.echo(f"PASS ({len(projects)} project(s))")
    except Exception as e:
        click.echo(f"FAIL ({e})")
        all_passed = False

    # Check 4: File operations (test via runs endpoint)
    click.echo("4. File operations... ", nl=False)
    try:
        resp = client._request("get", "/health")
        if resp.status_code == 200:
            click.echo("PASS")
        else:
            click.echo(f"WARN (HTTP {resp.status_code})")
    except Exception as e:
        click.echo(f"WARN ({e})")

    click.echo("")
    if all_passed:
        click.echo("All checks passed.")
    else:
        click.echo("Some checks failed. Review output above.")

    try:
        client.close()
    except Exception:
        pass


# ---------------------------------------------------------------------------
# pull command
# ---------------------------------------------------------------------------


@main.command()
@click.argument("run_path")
@click.option("--dir", "output_dir", default=None, help="Output directory (default: ./<run_id>)")
def pull(run_path: str, output_dir: str | None) -> None:
    """Download all files associated with a run.

    RUN_PATH is a run ID or path like 'entity/project/runs/run_id'.

    Examples:

        openrunner pull abc123

        openrunner pull team/project/runs/abc123 --dir ./my-run-data
    """
    client = _get_client()

    # Resolve run
    run = client.get_run(run_path)
    if run is None:
        result = client.from_path(run_path)
        if isinstance(result, dict) and result.get("id"):
            run = result
        else:
            click.echo(f"Run '{run_path}' not found.", err=True)
            client.close()
            raise SystemExit(1)

    run_id = run.get("id", run_path)
    run_name = run.get("display_name", run_id)
    click.echo(f"Pulling run: {run_name} [{run.get('state', 'unknown')}]")

    # Determine output directory
    dest = Path(output_dir) if output_dir else Path(run_id)
    dest.mkdir(parents=True, exist_ok=True)

    # Save run metadata
    meta_path = dest / "run_metadata.json"
    meta_path.write_text(json.dumps(run, indent=2, default=str), encoding="utf-8")
    click.echo(f"  run_metadata.json")

    # Save config if present
    config = run.get("config")
    if config:
        config_path = dest / "config.json"
        config_path.write_text(json.dumps(config, indent=2, default=str), encoding="utf-8")
        click.echo(f"  config.json")

    # Save summary if present
    summary = run.get("summary")
    if summary:
        summary_path = dest / "summary.json"
        summary_path.write_text(json.dumps(summary, indent=2, default=str), encoding="utf-8")
        click.echo(f"  summary.json")

    # Fetch and download run files
    files = client.list_run_files(run_id)
    downloaded = 0
    total = len(files)

    if total > 0:
        click.echo(f"Downloading {total} file(s)...")
        for f in files:
            fname = f.get("path") or f.get("name") or f.get("storage_key", "unknown")
            url = f.get("presigned_url") or f.get("url", "")
            size = f.get("size_bytes")

            if not url:
                click.echo(f"  [skip] {fname} -- no download URL")
                continue

            data = client.download_file_from_presigned_url(url)
            if data is None:
                click.echo(f"  [fail] {fname}")
                continue

            out_path = dest / fname
            out_path.parent.mkdir(parents=True, exist_ok=True)
            out_path.write_bytes(data)
            size_str = _format_size(len(data))
            click.echo(f"  {fname} ({size_str})")
            downloaded += 1

        click.echo(f"Downloaded {downloaded}/{total} files.")
    else:
        click.echo("No remote files found for this run.")

    # Also fetch logged artifacts summary
    artifacts = client.get_run_logged_artifacts(run_id)
    if artifacts:
        art_path = dest / "artifacts.json"
        art_path.write_text(json.dumps(artifacts, indent=2, default=str), encoding="utf-8")
        click.echo(f"  artifacts.json ({len(artifacts)} artifact(s) listed)")

    click.echo(f"Run data saved to {dest}/")
    client.close()


# ---------------------------------------------------------------------------
# online / offline commands
# ---------------------------------------------------------------------------


def _write_mode_setting(key: str, value: str) -> Path:
    """Write a mode setting to the local or global settings file.

    Prefers .openrunner/settings.json in CWD if it exists,
    otherwise falls back to ~/.openrunner/settings.json.

    Returns the path of the settings file written to.
    """
    local_file = Path.cwd() / ".openrunner" / "settings.json"
    if local_file.exists():
        settings_file = local_file
    else:
        settings_file = _settings_dir() / "settings.json"

    settings: dict[str, Any] = {}
    if settings_file.exists():
        try:
            settings = json.loads(settings_file.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            pass

    settings[key] = value
    settings_file.parent.mkdir(parents=True, exist_ok=True)
    settings_file.write_text(json.dumps(settings, indent=2), encoding="utf-8")
    return settings_file


@main.command()
def online() -> None:
    """Set SDK to online mode.

    Writes mode=online to the local or global settings file.
    Also sets OPENRUNNER_MODE=online for the current process.
    """
    settings_file = _write_mode_setting("mode", "online")
    os.environ["OPENRUNNER_MODE"] = "online"
    click.echo("SDK set to online mode.")
    click.echo(f"  Written to: {settings_file}")


@main.command()
def offline() -> None:
    """Set SDK to offline mode.

    Writes mode=offline to the local or global settings file.
    Runs will be stored locally and can be synced later.
    """
    settings_file = _write_mode_setting("mode", "offline")
    os.environ["OPENRUNNER_MODE"] = "offline"
    click.echo("SDK set to offline mode.")
    click.echo(f"  Written to: {settings_file}")
    click.echo("  Runs will be saved locally. Use 'openrunner sync --all' to upload.")


@main.command()
def enabled() -> None:
    """Enable the OpenRunner SDK.

    Writes disabled=false to the local or global settings file.
    """
    settings_file = _write_mode_setting("disabled", "false")
    os.environ.pop("OPENRUNNER_DISABLED", None)
    click.echo("SDK enabled.")
    click.echo(f"  Written to: {settings_file}")


@main.command()
def disabled() -> None:
    """Disable the OpenRunner SDK.

    Writes disabled=true to the local or global settings file.
    When disabled, init() returns a no-op run that discards all calls.
    """
    settings_file = _write_mode_setting("disabled", "true")
    os.environ["OPENRUNNER_DISABLED"] = "true"
    click.echo("SDK disabled.")
    click.echo(f"  Written to: {settings_file}")
    click.echo("  All SDK calls will be silently ignored.")


# ---------------------------------------------------------------------------
# sweep command group (continued)
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# migrate command
# ---------------------------------------------------------------------------


@main.command()
@click.option("--from-wandb", is_flag=True, help="Import from Weights & Biases")
@click.option("--entity", required=True, help="W&B entity (team/user)")
@click.option("--project", required=True, help="W&B project name")
@click.option("--target-project", default=None, help="OpenRunner target project")
@click.option("--limit", type=int, default=None, help="Max runs to import")
@click.option("--include-artifacts", is_flag=True, help="Import artifacts")
@click.option("--include-media", is_flag=True, help="Import media files")
@click.option("--dry-run", is_flag=True, help="Preview without importing")
def migrate(
    from_wandb: bool,
    entity: str,
    project: str,
    target_project: str | None,
    limit: int | None,
    include_artifacts: bool,
    include_media: bool,
    dry_run: bool,
) -> None:
    """Migrate runs from another platform into OpenRunner.

    Currently supports importing from Weights & Biases (--from-wandb).

    Examples:

        openrunner migrate --from-wandb --entity myteam --project myproject

        openrunner migrate --from-wandb --entity myteam --project myproject --limit 50

        openrunner migrate --from-wandb --entity myteam --project myproject --dry-run
    """
    if from_wandb:
        from openrunner.migrate import migrate_from_wandb

        migrate_from_wandb(
            entity=entity,
            project=project,
            target_project=target_project,
            limit=limit,
            include_artifacts=include_artifacts,
            include_media=include_media,
            dry_run=dry_run,
        )
    else:
        click.echo("Currently only --from-wandb is supported.")
        click.echo("Usage: openrunner migrate --from-wandb --entity <entity> --project <project>")


@sweep.command("agent")
@click.argument("sweep_id")
@click.option("--count", "-n", type=int, default=None, help="Maximum number of runs")
@click.option(
    "--function",
    "-f",
    default=None,
    help="Python function path (module:function)",
)
def sweep_agent(
    sweep_id: str, count: int | None, function: str | None
) -> None:
    """Run a sweep agent for the given SWEEP_ID.

    The agent will repeatedly request parameter suggestions from the server
    and execute the training function. If --function is provided, it should
    be a Python dotted path like 'my_module:train_fn'.

    Without --function, a placeholder agent is started that prints
    suggested parameters without executing anything.
    """
    import json as json_module

    from openrunner.sweep import agent as agent_fn

    if function:
        # Import the function from the provided path
        try:
            module_path, func_name = function.rsplit(":", 1)
            import importlib

            mod = importlib.import_module(module_path)
            train_fn = getattr(mod, func_name)
        except (ValueError, ImportError, AttributeError) as e:
            click.echo(f"Error loading function '{function}': {e}", err=True)
            raise SystemExit(1)
    else:
        # Placeholder: just print params
        def train_fn(params: dict) -> None:
            click.echo(f"Suggested params: {json_module.dumps(params, indent=2)}")
            return None

    click.echo(f"Starting sweep agent for {sweep_id}...")
    agent_fn(sweep_id, function=train_fn, count=count)
    click.echo("Sweep agent finished.")


# ---------------------------------------------------------------------------
# docker command (Gap #41)
# ---------------------------------------------------------------------------


@main.command(
    context_settings={"ignore_unknown_options": True, "allow_extra_args": True},
)
@click.argument("image")
@click.option("--no-gpu", is_flag=True, help="Skip GPU detection and do not pass --gpus all")
@click.option("--jupyter", is_flag=True, help="Start Jupyter notebook server inside the container")
@click.pass_context
def docker(
    ctx: click.Context,
    image: str,
    no_gpu: bool,
    jupyter: bool,
) -> None:
    """Run a Docker container with OpenRunner environment injected.

    IMAGE is the Docker image to run. Extra arguments are passed
    through to ``docker run``.

    Automatically injects the OPENRUNNER_API_KEY environment variable.
    Detects NVIDIA GPU runtime if available (pass --no-gpu to skip).
    Use --jupyter to start a Jupyter notebook server inside the container.

    Examples:

        openrunner docker pytorch/pytorch:latest -- python train.py

        openrunner docker --jupyter tensorflow/tensorflow:latest-gpu

        openrunner docker --no-gpu ubuntu:22.04 -- bash
    """
    import subprocess

    settings = _load_settings()
    api_key = os.environ.get("OPENRUNNER_API_KEY") or settings.get("api_key")
    base_url = os.environ.get("OPENRUNNER_BASE_URL") or settings.get(
        "base_url", "http://localhost:8000"
    )

    if not api_key:
        click.echo("Error: Not logged in. Run 'openrunner login' first.", err=True)
        raise SystemExit(1)

    # Build docker run command
    cmd: list[str] = ["docker", "run", "-it", "--rm"]

    # Inject OpenRunner env vars
    cmd.extend(["-e", f"OPENRUNNER_API_KEY={api_key}"])
    cmd.extend(["-e", f"OPENRUNNER_BASE_URL={base_url}"])

    # GPU detection
    if not no_gpu:
        has_nvidia = _detect_nvidia_runtime()
        if has_nvidia:
            cmd.extend(["--gpus", "all"])
            click.echo("Detected NVIDIA runtime, adding --gpus all")

    # Jupyter support
    if jupyter:
        cmd.extend(["-p", "8888:8888"])

    # Pass through extra args from the context
    extra_args: list[str] = list(ctx.args)

    # Add the image
    cmd.append(image)

    # If --jupyter, override the entrypoint to start Jupyter
    if jupyter:
        # Append jupyter command after image
        cmd.extend([
            "jupyter", "notebook",
            "--ip=0.0.0.0",
            "--port=8888",
            "--no-browser",
            "--allow-root",
            "--NotebookApp.token=''",
        ])
    elif extra_args:
        cmd.extend(extra_args)

    click.echo(f"Running: {' '.join(cmd)}")

    try:
        result = subprocess.run(cmd)
        raise SystemExit(result.returncode)
    except FileNotFoundError:
        click.echo("Error: Docker is not installed or not in PATH.", err=True)
        raise SystemExit(1)
    except KeyboardInterrupt:
        click.echo("\nContainer stopped.")


def _detect_nvidia_runtime() -> bool:
    """Check whether the NVIDIA container runtime is available.

    Runs ``nvidia-smi`` to detect the presence of an NVIDIA GPU.
    Returns True if the command succeeds, False otherwise.
    """
    import subprocess

    try:
        result = subprocess.run(
            ["nvidia-smi"],
            capture_output=True,
            timeout=5,
        )
        return result.returncode == 0
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return False


def _sync_tensorboard_events(
    logdir: str,
    api_key: str,
    base_url: str,
    project: str | None = None,
) -> None:
    """Parse TensorBoard event files and upload as OpenRunner metrics.

    Supports reading TF event files (tfevents format) from a single
    directory or recursively from subdirectories. Uses the low-level
    struct-based reader as a fallback when the TensorBoard library
    is not available.

    Args:
        logdir: Path to TensorBoard log directory.
        api_key: OpenRunner API key.
        base_url: OpenRunner server URL.
        project: Project name (default: tensorboard-import).
    """
    import struct
    import glob as glob_mod

    log_path = Path(logdir)
    if not log_path.exists():
        click.echo(f"Error: Directory '{logdir}' not found.", err=True)
        raise SystemExit(1)

    # Find all tfevents files
    event_files: list[Path] = []
    for pattern in ["**/events.out.tfevents.*", "**/tfevents.*"]:
        event_files.extend(log_path.glob(pattern))

    # Deduplicate
    event_files = list(set(event_files))
    event_files.sort(key=lambda p: str(p))

    if not event_files:
        click.echo(f"No TensorBoard event files found in '{logdir}'.")
        return

    click.echo(f"Found {len(event_files)} event file(s) in {logdir}")

    # Try to use TensorBoard EventAccumulator for proper parsing
    use_native = False
    try:
        from tensorboard.backend.event_processing.event_accumulator import EventAccumulator
        use_native = True
    except ImportError:
        click.echo("Note: tensorboard not installed, using built-in event reader.")

    # Set up API client and create a run
    client = APIClient(base_url=base_url, api_key=api_key)
    resolved_project = project or "tensorboard-import"

    # Create a run for the import
    run_data = client.create_run({
        "project": resolved_project,
        "display_name": f"tb-import-{log_path.name}",
        "config": {"source": "tensorboard", "logdir": str(log_path)},
    })

    if run_data is None:
        click.echo("Error: Failed to create run for TensorBoard import.", err=True)
        client.close()
        raise SystemExit(1)

    run_id = run_data.get("id", "")
    click.echo(f"Created run: {run_id}")

    total_metrics = 0

    if use_native:
        # Use TensorBoard's native EventAccumulator
        ea = EventAccumulator(str(log_path))
        ea.Reload()

        scalar_tags = ea.Tags().get("scalars", [])
        click.echo(f"Found {len(scalar_tags)} scalar tag(s)")

        for tag in scalar_tags:
            events = ea.Scalars(tag)
            batch: list[dict[str, Any]] = []
            for event in events:
                batch.append({
                    "key": tag,
                    "value": event.value,
                    "step": event.step,
                    "wall_time": event.wall_time,
                })
                if len(batch) >= 500:
                    posted = client.post_metrics(run_id, batch)
                    total_metrics += posted
                    batch = []
            if batch:
                posted = client.post_metrics(run_id, batch)
                total_metrics += posted
            click.echo(f"  {tag}: {len(events)} points")
    else:
        # Fallback: parse event files with struct-based reader
        for event_file in event_files:
            click.echo(f"  Parsing {event_file.name}...")
            metrics = _parse_tfevents_file(event_file)
            if metrics:
                # Upload in batches
                batch_size = 500
                for i in range(0, len(metrics), batch_size):
                    batch = metrics[i:i + batch_size]
                    posted = client.post_metrics(run_id, batch)
                    total_metrics += posted
                click.echo(f"    {len(metrics)} metric points extracted")
            else:
                click.echo(f"    No scalar metrics found")

    # Finish the run
    client.update_run(run_id, {"state": "finished"})

    click.echo(f"\nTensorBoard sync complete: {total_metrics} metrics uploaded to run {run_id}")
    client.close()


def _parse_tfevents_file(filepath: Path) -> list[dict[str, Any]]:
    """Parse a TensorBoard event file and extract scalar metrics.

    Uses a minimal struct-based reader to parse the TF record format
    without requiring the TensorFlow or TensorBoard libraries.

    The TF record format is:
        - 8 bytes: length (uint64 little-endian)
        - 4 bytes: masked CRC of length
        - N bytes: data (serialized Event proto)
        - 4 bytes: masked CRC of data

    Returns a list of metric dicts with key, value, step, wall_time.
    """
    import struct

    metrics: list[dict[str, Any]] = []

    try:
        with open(filepath, "rb") as f:
            while True:
                # Read length
                length_bytes = f.read(8)
                if len(length_bytes) < 8:
                    break
                length = struct.unpack("<Q", length_bytes)[0]

                # Skip masked CRC of length
                f.read(4)

                # Read data
                data = f.read(length)
                if len(data) < length:
                    break

                # Skip masked CRC of data
                f.read(4)

                # Try to parse the Event protobuf minimally
                # Event proto fields:
                #   1: wall_time (double)
                #   2: step (int64)
                #   5: summary (Summary message)
                #     Summary.value:
                #       1: tag (string)
                #       2: simple_value (float)
                parsed = _parse_event_proto(data)
                if parsed:
                    metrics.extend(parsed)

    except (OSError, struct.error) as e:
        logger.warning("Failed to parse event file %s: %s", filepath, e)

    return metrics


def _parse_event_proto(data: bytes) -> list[dict[str, Any]] | None:
    """Minimally parse a TensorFlow Event protobuf to extract scalar metrics.

    This is a lightweight protobuf parser that only extracts the fields
    we care about: wall_time, step, and summary scalar values.
    """
    import struct

    results: list[dict[str, Any]] = []
    wall_time = 0.0
    step = 0
    pos = 0

    try:
        while pos < len(data):
            if pos >= len(data):
                break
            # Read field tag
            tag_byte = data[pos]
            pos += 1
            field_number = tag_byte >> 3
            wire_type = tag_byte & 0x07

            if field_number == 1 and wire_type == 1:
                # wall_time: fixed64 (double)
                wall_time = struct.unpack_from("<d", data, pos)[0]
                pos += 8
            elif field_number == 2 and wire_type == 0:
                # step: varint
                step, pos = _read_varint(data, pos)
            elif field_number == 5 and wire_type == 2:
                # summary: length-delimited
                length, pos = _read_varint(data, pos)
                summary_data = data[pos:pos + length]
                pos += length
                # Parse Summary message
                scalars = _parse_summary_proto(summary_data)
                for tag_name, value in scalars:
                    results.append({
                        "key": tag_name,
                        "value": value,
                        "step": step,
                        "wall_time": wall_time,
                    })
            elif wire_type == 0:
                # varint -- skip
                _, pos = _read_varint(data, pos)
            elif wire_type == 1:
                # 64-bit -- skip
                pos += 8
            elif wire_type == 2:
                # length-delimited -- skip
                length, pos = _read_varint(data, pos)
                pos += length
            elif wire_type == 5:
                # 32-bit -- skip
                pos += 4
            else:
                break
    except (IndexError, struct.error):
        pass

    return results if results else None


def _parse_summary_proto(data: bytes) -> list[tuple[str, float]]:
    """Parse a TensorFlow Summary protobuf to extract tag/value pairs."""
    import struct

    results: list[tuple[str, float]] = []
    pos = 0

    try:
        while pos < len(data):
            tag_byte = data[pos]
            pos += 1
            field_number = tag_byte >> 3
            wire_type = tag_byte & 0x07

            if field_number == 1 and wire_type == 2:
                # Value message (repeated)
                length, pos = _read_varint(data, pos)
                value_data = data[pos:pos + length]
                pos += length

                tag_name, scalar_val = _parse_summary_value(value_data)
                if tag_name and scalar_val is not None:
                    results.append((tag_name, scalar_val))
            elif wire_type == 0:
                _, pos = _read_varint(data, pos)
            elif wire_type == 1:
                pos += 8
            elif wire_type == 2:
                length, pos = _read_varint(data, pos)
                pos += length
            elif wire_type == 5:
                pos += 4
            else:
                break
    except (IndexError, struct.error):
        pass

    return results


def _parse_summary_value(data: bytes) -> tuple[str | None, float | None]:
    """Parse a Summary.Value protobuf message."""
    import struct

    tag_name: str | None = None
    simple_value: float | None = None
    pos = 0

    try:
        while pos < len(data):
            tag_byte = data[pos]
            pos += 1
            field_number = tag_byte >> 3
            wire_type = tag_byte & 0x07

            if field_number == 1 and wire_type == 2:
                # tag: string
                length, pos = _read_varint(data, pos)
                tag_name = data[pos:pos + length].decode("utf-8", errors="replace")
                pos += length
            elif field_number == 2 and wire_type == 5:
                # simple_value: float (fixed32)
                simple_value = struct.unpack_from("<f", data, pos)[0]
                pos += 4
            elif wire_type == 0:
                _, pos = _read_varint(data, pos)
            elif wire_type == 1:
                pos += 8
            elif wire_type == 2:
                length, pos = _read_varint(data, pos)
                pos += length
            elif wire_type == 5:
                pos += 4
            else:
                break
    except (IndexError, struct.error):
        pass

    return tag_name, simple_value


def _read_varint(data: bytes, pos: int) -> tuple[int, int]:
    """Read a protobuf varint from data at the given position."""
    result = 0
    shift = 0
    while pos < len(data):
        byte = data[pos]
        pos += 1
        result |= (byte & 0x7F) << shift
        if not (byte & 0x80):
            break
        shift += 7
    return result, pos


# ---------------------------------------------------------------------------
# restore command (Gap #42)
# ---------------------------------------------------------------------------


@main.command()
@click.argument("run_path")
@click.option("--dir", "output_dir", default=None, help="Output directory (default: ./restore-<run_id>)")
def restore(run_path: str, output_dir: str | None) -> None:
    """Restore a run's code and environment for reproducibility.

    RUN_PATH is a run ID or path like 'entity/project/runs/run_id'.

    Attempts to restore the exact code state from the run:

    1. If the run has saved code: download and extract it.

    2. If the run has git info: checkout the commit and apply any diff patch.

    3. Prints environment reproduction instructions (pip, conda, etc.).

    Examples:

        openrunner restore abc123

        openrunner restore team/project/runs/abc123 --dir ./my-restore
    """
    import subprocess

    client = _get_client()

    # Resolve run
    run = client.get_run(run_path)
    if run is None:
        result = client.from_path(run_path)
        if isinstance(result, dict) and result.get("id"):
            run = result
        else:
            click.echo(f"Run '{run_path}' not found.", err=True)
            client.close()
            raise SystemExit(1)

    run_id = run.get("id", run_path)
    run_name = run.get("display_name", run_id)
    click.echo(f"Restoring run: {run_name} [{run.get('state', 'unknown')}]")

    # Determine output directory
    short_id = run_id[:8] if len(run_id) > 8 else run_id
    dest = Path(output_dir) if output_dir else Path(f"restore-{short_id}")
    dest.mkdir(parents=True, exist_ok=True)

    restored_code = False
    restored_git = False

    # --- Step 1: Download saved code if available ---
    files = client.list_run_files(run_id)
    code_files = [
        f for f in files
        if (f.get("path", "") or f.get("name", "")).startswith("code/")
        or (f.get("path", "") or f.get("name", "")).endswith(".py")
    ]

    if code_files:
        click.echo(f"Downloading {len(code_files)} saved code file(s)...")
        code_dir = dest / "code"
        code_dir.mkdir(parents=True, exist_ok=True)
        for f in code_files:
            fname = f.get("path") or f.get("name") or f.get("storage_key", "unknown")
            url = f.get("presigned_url") or f.get("url", "")
            if not url:
                continue
            data = client.download_file_from_presigned_url(url)
            if data is None:
                click.echo(f"  [fail] {fname}")
                continue
            out_path = code_dir / fname
            out_path.parent.mkdir(parents=True, exist_ok=True)
            out_path.write_bytes(data)
            click.echo(f"  {fname} ({_format_size(len(data))})")
        restored_code = True

    # --- Step 2: Git info -- checkout commit and apply diff ---
    git_info = run.get("git") or run.get("git_info")
    if git_info and isinstance(git_info, dict):
        sha = git_info.get("sha") or git_info.get("commit")
        branch = git_info.get("branch")
        remote_url = git_info.get("remote_url") or git_info.get("remote")
        diff_patch = git_info.get("diff")

        if sha:
            click.echo(f"\nGit info found:")
            click.echo(f"  Commit:  {sha}")
            if branch:
                click.echo(f"  Branch:  {branch}")
            if remote_url:
                click.echo(f"  Remote:  {remote_url}")

            # Write git restore script
            script_lines = ["#!/bin/bash", "set -e", ""]
            if remote_url:
                script_lines.append(f'echo "Cloning {remote_url}..."')
                script_lines.append(f"git clone {remote_url} restored-repo")
                script_lines.append("cd restored-repo")
            script_lines.append(f"git checkout {sha}")
            if diff_patch:
                script_lines.append('echo "Applying uncommitted changes..."')
                script_lines.append("git apply restore-diff.patch")
            script_lines.append('echo "Code restored successfully."')

            script_path = dest / "restore-git.sh"
            script_path.write_text("\n".join(script_lines) + "\n", encoding="utf-8")
            script_path.chmod(0o755)
            click.echo(f"  Wrote restore script: {script_path}")

            # Write diff patch if available
            if diff_patch:
                patch_path = dest / "restore-diff.patch"
                patch_path.write_text(diff_patch, encoding="utf-8")
                click.echo(f"  Wrote diff patch: {patch_path}")

            # Try to checkout locally if inside a git repo
            try:
                subprocess.run(
                    ["git", "rev-parse", "--git-dir"],
                    capture_output=True,
                    check=True,
                    timeout=5,
                )
                click.echo(f"\nTo restore this exact commit locally:")
                click.echo(f"  git checkout {sha}")
                if diff_patch:
                    click.echo(f"  git apply {patch_path}")
            except (subprocess.CalledProcessError, FileNotFoundError, subprocess.TimeoutExpired):
                if remote_url:
                    click.echo(f"\nTo restore this exact commit:")
                    click.echo(f"  git clone {remote_url}")
                    click.echo(f"  git checkout {sha}")
                    if diff_patch:
                        click.echo(f"  git apply {patch_path}")

            restored_git = True

    # --- Step 3: Save run metadata and config for environment reproduction ---
    meta_path = dest / "run_metadata.json"
    meta_path.write_text(json.dumps(run, indent=2, default=str), encoding="utf-8")

    config = run.get("config")
    if config:
        config_path = dest / "config.json"
        config_path.write_text(json.dumps(config, indent=2, default=str), encoding="utf-8")

    # --- Step 4: Print environment reproduction instructions ---
    click.echo(f"\n{'=' * 50}")
    click.echo("Environment Reproduction Instructions")
    click.echo("=" * 50)

    # Check for pip requirements in config
    pip_deps = None
    if config:
        pip_deps = config.get("requirements") or config.get("pip") or config.get("dependencies")
    if pip_deps:
        if isinstance(pip_deps, list):
            req_path = dest / "requirements.txt"
            req_path.write_text("\n".join(pip_deps) + "\n", encoding="utf-8")
            click.echo(f"  pip install -r {req_path}")
        elif isinstance(pip_deps, str):
            req_path = dest / "requirements.txt"
            req_path.write_text(pip_deps, encoding="utf-8")
            click.echo(f"  pip install -r {req_path}")

    # Check for Python version
    python_version = None
    if config:
        python_version = config.get("python_version") or config.get("_python_version")
    if python_version:
        click.echo(f"  Python version: {python_version}")

    # Check for conda env
    conda_env = None
    if config:
        conda_env = config.get("conda_env") or config.get("conda")
    if conda_env:
        click.echo(f"  Conda env: {conda_env}")

    if not pip_deps and not conda_env:
        click.echo("  No dependency info found in run config.")
        click.echo("  Check run_metadata.json and config.json for environment details.")

    click.echo(f"\nRestored data saved to: {dest}/")

    if not restored_code and not restored_git:
        click.echo("\nNote: No saved code or git info found for this run.")
        click.echo("Only run metadata and config have been saved.")

    client.close()


# ---------------------------------------------------------------------------
# controller command (Gap #47)
# ---------------------------------------------------------------------------


@main.command()
@click.argument("sweep_id")
@click.option(
    "--script", "-s", default=None,
    help="Python controller script path (module:function or file.py:function)",
)
@click.option("--poll-interval", type=float, default=10.0, help="Seconds between polls (default: 10)")
@click.option("--max-runs", type=int, default=None, help="Maximum number of parameter suggestions")
def controller(
    sweep_id: str,
    script: str | None,
    poll_interval: float,
    max_runs: int | None,
) -> None:
    """Start a local sweep controller for custom parameter search logic.

    SWEEP_ID is the sweep to control. The controller polls the sweep
    config from the server and suggests next parameters based on the
    chosen strategy.

    With --script, you can provide a custom Python function that receives
    the sweep config and completed run results, and returns the next set
    of parameters to try. The function signature should be:

        def my_controller(config: dict, results: list[dict]) -> dict | None

    Without --script, uses a built-in strategy based on the sweep method
    (random, grid, or bayes).

    Examples:

        openrunner controller abc123

        openrunner controller abc123 --script my_search:custom_controller

        openrunner controller abc123 --poll-interval 30 --max-runs 50
    """
    import importlib
    import time as time_mod

    client = _get_client()

    # Load custom controller function if provided
    controller_fn = None
    if script:
        try:
            if ":" in script:
                module_path, func_name = script.rsplit(":", 1)
            else:
                click.echo("Error: --script must be module:function format.", err=True)
                client.close()
                raise SystemExit(1)

            # Support file paths by adding parent dir to sys path
            import sys
            if module_path.endswith(".py"):
                module_file = Path(module_path)
                if module_file.exists():
                    sys.path.insert(0, str(module_file.parent))
                    module_path = module_file.stem

            mod = importlib.import_module(module_path)
            controller_fn = getattr(mod, func_name)
            click.echo(f"Loaded custom controller: {script}")
        except (ImportError, AttributeError) as e:
            click.echo(f"Error loading controller script '{script}': {e}", err=True)
            client.close()
            raise SystemExit(1)

    # Fetch sweep config
    sweep_data = client.get_sweep(sweep_id)
    if sweep_data is None:
        click.echo(f"Sweep '{sweep_id}' not found.", err=True)
        client.close()
        raise SystemExit(1)

    sweep_config = sweep_data.get("config") or sweep_data
    method = sweep_config.get("method", "random")
    parameters = sweep_config.get("parameters", {})

    click.echo(f"Starting controller for sweep {sweep_id}")
    click.echo(f"  Method:     {method}")
    click.echo(f"  Parameters: {', '.join(parameters.keys())}")
    click.echo(f"  Poll interval: {poll_interval}s")
    if max_runs:
        click.echo(f"  Max runs:   {max_runs}")
    click.echo("")

    suggestions_made = 0
    completed_results: list[dict[str, Any]] = []

    try:
        while True:
            if max_runs is not None and suggestions_made >= max_runs:
                click.echo(f"Reached max runs limit ({max_runs}).")
                break

            # Generate next parameters
            if controller_fn:
                try:
                    next_params = controller_fn(sweep_config, completed_results)
                except Exception as e:
                    click.echo(f"Controller function error: {e}", err=True)
                    break
            else:
                next_params = _builtin_suggest(method, parameters, suggestions_made)

            if next_params is None:
                click.echo("Controller returned None -- sweep finished.")
                break

            suggestions_made += 1
            click.echo(f"[{suggestions_made}] Suggested params: {json.dumps(next_params)}")

            # Report suggestion to server
            try:
                resp_data = client._request(
                    "post",
                    f"/sweeps/{sweep_id}/report",
                    json={
                        "run_id": f"controller-{sweep_id[:8]}-{suggestions_made}",
                        "params": next_params,
                        "state": "suggested",
                    },
                )
                if resp_data.status_code < 400:
                    result = resp_data.json()
                    completed_results.append(
                        {"params": next_params, "response": result}
                    )
                    if result.get("early_stop", False):
                        click.echo("Early stop triggered by server.")
                        break
            except Exception as e:
                click.echo(f"Warning: failed to report suggestion: {e}")
                completed_results.append({"params": next_params, "response": None})

            # Wait before next poll
            time_mod.sleep(poll_interval)

    except KeyboardInterrupt:
        click.echo("\nController stopped by user.")

    click.echo(f"\nController finished. Total suggestions: {suggestions_made}")
    client.close()


def _builtin_suggest(
    method: str,
    parameters: dict[str, Any],
    iteration: int,
) -> dict[str, Any] | None:
    """Generate the next parameter suggestion using a built-in strategy.

    Supports random, grid (round-robin), and bayes (random with shrinking).

    Args:
        method: Sweep method (random, grid, bayes).
        parameters: Parameter specification dict.
        iteration: Current iteration number (0-indexed).

    Returns:
        A dict of parameter names to values, or None if grid is exhausted.
    """
    import random as random_mod

    result: dict[str, Any] = {}

    for name, spec in parameters.items():
        if isinstance(spec, dict):
            # Fixed value
            if "value" in spec:
                result[name] = spec["value"]
                continue

            # Discrete values
            if "values" in spec:
                values = spec["values"]
                if method == "grid":
                    # Round-robin through values
                    result[name] = values[iteration % len(values)]
                else:
                    result[name] = random_mod.choice(values)
                continue

            # Continuous range
            min_val = spec.get("min", 0)
            max_val = spec.get("max", 1)
            distribution = spec.get("distribution", "uniform")

            if distribution in ("log_uniform", "log_uniform_values"):
                import math
                log_min = math.log(max(min_val, 1e-10))
                log_max = math.log(max(max_val, 1e-10))
                result[name] = math.exp(random_mod.uniform(log_min, log_max))
            elif distribution == "int_uniform":
                result[name] = random_mod.randint(int(min_val), int(max_val))
            else:
                result[name] = random_mod.uniform(min_val, max_val)
        else:
            # Simple value
            result[name] = spec

    return result if result else None


# ---------------------------------------------------------------------------
# session commands — AI session capture
# ---------------------------------------------------------------------------


@main.group()
def session() -> None:
    """Capture and log AI coding sessions (Claude Code, ChatGPT, Codex, Qwen)."""
    pass


@session.command("setup")
def session_setup() -> None:
    """Interactive setup: configure API key and target project for session sync."""
    from openrunner.session import interactive_setup
    config = interactive_setup()
    if config:
        click.echo("Setup complete.")
    else:
        click.echo("Setup cancelled.")


@session.command("sync")
@click.argument("directory", required=False, type=click.Path(exists=True))
@click.option("--hours", "-h", default=24.0, help="Look back N hours (default: 24)")
@click.option("--project", "-p", default=None, help="Target project (default: from config)")
@click.option("--dry-run", is_flag=True, help="Show what would be synced without uploading")
@click.option("--redact/--no-redact", default=None, help="Force redaction on/off (default: use config)")
@click.option("--redact-mode", type=click.Choice(["regex", "ner"]), default=None, help="Redaction mode")
@click.option("--public", "visibility", flag_value="public", help="Make session public")
@click.option("--private", "visibility", flag_value="private", default=True, help="Keep session private (default)")
def session_sync(directory: str | None, hours: float, project: str | None, dry_run: bool, redact: bool | None, redact_mode: str | None, visibility: str) -> None:
    """Sync AI sessions to OpenRunner.

    If DIRECTORY is given, scan that path for .jsonl/.json session files.
    Otherwise, scan default locations (~/.claude, ~/.codex, ~/.qwen-code).

    On first run, prompts for API key and project selection.
    Redaction strips API keys, tokens, emails, passwords before upload.
    """
    from pathlib import Path
    from openrunner.session import discover_all_sessions, discover_in_directory, sync_all, get_session_config, interactive_setup

    # Check if configured — run setup if not
    config = get_session_config()
    if not config.get("api_key"):
        click.echo("No API key configured. Running first-time setup...")
        config = interactive_setup()
        if not config:
            return

    if directory:
        sessions = discover_in_directory(Path(directory), since_hours=hours)
    else:
        sessions = discover_all_sessions(hours)

    if dry_run or not sessions:
        if not sessions:
            click.echo("No sessions found.")
            return
        click.echo(f"Found {len(sessions)} session(s):")
        for s in sessions:
            ts = time.strftime("%Y-%m-%d %H:%M", time.localtime(s["mtime"]))
            size = s["size"] / 1024
            click.echo(f"  [{s['source']}] {ts} ({size:.0f} KB) {s['path'].name}")
        if dry_run:
            return

    synced = sync_all(since_hours=hours, project=project, directory=Path(directory) if directory else None, redact=redact, redact_mode=redact_mode, visibility=visibility)
    if synced:
        click.echo(f"Synced {len(synced)} session(s) to OpenRunner.")
        for run_id in synced:
            click.echo(f"  -> run {run_id}")
    else:
        click.echo("No new sessions to sync.")


@session.command("watch")
@click.option("--interval", "-i", default=60, help="Check interval in seconds (default: 60)")
@click.option("--project", "-p", default=None, help="Target project")
def session_watch(interval: int, project: str | None) -> None:
    """Watch for new sessions and sync them continuously (daemon mode)."""
    from openrunner.session import watch
    click.echo(f"Watching for AI sessions (every {interval}s). Ctrl+C to stop.")
    try:
        watch(interval=interval, project=project)
    except KeyboardInterrupt:
        click.echo("\nStopped.")


@session.command("list")
@click.option("--hours", "-h", default=24.0, help="Look back N hours")
def session_list(hours: float) -> None:
    """List discovered AI sessions."""
    from openrunner.session import discover_all_sessions, _load_sync_state

    sessions = discover_all_sessions(hours)
    state = _load_sync_state()

    if not sessions:
        click.echo("No sessions found.")
        return

    click.echo(f"{'SOURCE':<14} {'TIME':<18} {'SIZE':<10} {'STATUS'}")
    click.echo("-" * 60)
    for s in sessions:
        from openrunner.session import _session_hash
        ts = time.strftime("%Y-%m-%d %H:%M", time.localtime(s["mtime"]))
        size = f"{s['size'] / 1024:.0f} KB"
        h = _session_hash(s["path"])
        synced_info = state.get("synced", {}).get(h)
        status = f"synced ({synced_info['run_id']})" if synced_info else "new"
        click.echo(f"  {s['source']:<12} {ts:<18} {size:<10} {status}")


@main.command("install")
@click.argument("tools", nargs=-1, type=click.Choice(["claude", "codex", "qwen", "opencode"]))
def install_commands(tools: tuple) -> None:
    """Install /openrunner slash commands for AI coding tools.

    Without arguments, installs for all tools (Claude Code, Codex, Qwen, OpenCode).
    Specify tool names to install selectively.
    """
    from openrunner.install_commands import install_all

    targets = list(tools) if tools else None
    results = install_all(targets)

    for tool_name, files in results.items():
        if files:
            click.echo(f"  {tool_name}: {len(files)} file(s) installed")
            for f in files:
                click.echo(f"    {f}")
        else:
            click.echo(f"  {tool_name}: already up to date")

    click.echo("")
    click.echo("Commands available:")
    click.echo("  /openrunner:sync-session  — log current session to OpenRunner")
    click.echo("  /openrunner:log-note      — save a quick research note")


@session.command("hook")
@click.argument("action", type=click.Choice(["install", "uninstall"]))
def session_hook(action: str) -> None:
    """Install/uninstall Claude Code auto-capture hook."""
    if action == "install":
        from openrunner.session import install_claude_hook
        path = install_claude_hook()
        click.echo(f"Claude Code hook installed.")
        click.echo(f"  Config: {path}")
        click.echo("  Sessions will be auto-logged on exit.")
    else:
        from pathlib import Path
        hooks_file = Path.home() / ".claude" / "hooks.json"
        if hooks_file.exists():
            import json as json_mod
            hooks = json_mod.loads(hooks_file.read_text())
            stop_hooks = hooks.get("hooks", {}).get("Stop", [])
            hooks["hooks"]["Stop"] = [h for h in stop_hooks if "openrunner" not in str(h)]
            hooks_file.write_text(json_mod.dumps(hooks, indent=2))
            click.echo("Claude Code hook removed.")
        else:
            click.echo("No hooks.json found.")
