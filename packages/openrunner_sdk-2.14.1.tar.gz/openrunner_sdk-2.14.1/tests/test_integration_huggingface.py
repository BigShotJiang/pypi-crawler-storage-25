"""Tests for the HuggingFace Transformers integration (OpenRunnerCallback)."""

from __future__ import annotations

import sys
import types
from unittest.mock import MagicMock, patch

import pytest


# ---------------------------------------------------------------------------
# Mock transformers before importing the integration module
# ---------------------------------------------------------------------------

@pytest.fixture(autouse=True)
def _mock_transformers(monkeypatch):
    """Inject fake transformers module so huggingface.py imports cleanly."""
    # Create mock transformers module hierarchy
    transformers = types.ModuleType("transformers")

    class _TrainerCallback:
        """Fake base class."""
        pass

    class _TrainerState:
        def __init__(self, global_step=0):
            self.global_step = global_step

    class _TrainerControl:
        pass

    class _TrainingArguments:
        def __init__(self, output_dir="output", **kw):
            self.output_dir = output_dir
            self._kw = kw

        def to_dict(self):
            return {"output_dir": self.output_dir, **self._kw}

    transformers.TrainerCallback = _TrainerCallback
    transformers.TrainerState = _TrainerState
    transformers.TrainerControl = _TrainerControl
    transformers.TrainingArguments = _TrainingArguments

    monkeypatch.setitem(sys.modules, "transformers", transformers)
    yield transformers
    # Clean up cached module
    sys.modules.pop("openrunner.integration.huggingface", None)


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

class TestOpenRunnerCallback:
    """Tests for OpenRunnerCallback."""

    def test_on_train_begin_calls_init(self, monkeypatch, _mock_transformers):
        """Test 5: on_train_begin calls openrunner.init() with config from TrainingArguments."""
        from openrunner.integration.huggingface import OpenRunnerCallback
        import openrunner

        mock_init = MagicMock(return_value=MagicMock())
        monkeypatch.setattr("openrunner.init", mock_init)
        monkeypatch.setattr("openrunner._active_run", None)

        cb = OpenRunnerCallback()
        args = _mock_transformers.TrainingArguments(output_dir="my-project", lr=0.001)
        state = _mock_transformers.TrainerState()
        control = _mock_transformers.TrainerControl()

        cb.on_train_begin(args, state, control)

        mock_init.assert_called_once()
        call_kwargs = mock_init.call_args
        # After refactor, on_train_begin passes config (from args.to_dict()) but not project
        assert "config" in call_kwargs[1]

    def test_on_log_calls_log_with_numeric_metrics(self, monkeypatch, _mock_transformers):
        """Test 6: on_log calls openrunner.log() with numeric-only metrics at global_step."""
        from openrunner.integration.huggingface import OpenRunnerCallback
        import openrunner

        mock_log = MagicMock()
        monkeypatch.setattr("openrunner.log", mock_log)
        monkeypatch.setattr("openrunner._active_run", MagicMock())

        cb = OpenRunnerCallback()
        args = _mock_transformers.TrainingArguments()
        state = _mock_transformers.TrainerState(global_step=42)
        control = _mock_transformers.TrainerControl()

        logs = {"loss": 0.5, "learning_rate": 1e-4, "epoch": 2}
        cb.on_log(args, state, control, logs=logs)

        mock_log.assert_called_once()
        logged_data = mock_log.call_args[0][0]
        assert logged_data == {"loss": 0.5, "learning_rate": 1e-4, "epoch": 2}
        assert mock_log.call_args[1]["step"] == 42

    def test_on_log_filters_non_numeric(self, monkeypatch, _mock_transformers):
        """Test 7: on_log filters out non-numeric values (strings, None)."""
        from openrunner.integration.huggingface import OpenRunnerCallback
        import openrunner

        mock_log = MagicMock()
        monkeypatch.setattr("openrunner.log", mock_log)
        monkeypatch.setattr("openrunner._active_run", MagicMock())

        cb = OpenRunnerCallback()
        args = _mock_transformers.TrainingArguments()
        state = _mock_transformers.TrainerState(global_step=10)
        control = _mock_transformers.TrainerControl()

        logs = {"loss": 0.3, "status": "training", "nothing": None, "step": 10}
        cb.on_log(args, state, control, logs=logs)

        logged_data = mock_log.call_args[0][0]
        assert "status" not in logged_data
        assert "nothing" not in logged_data
        assert "loss" in logged_data
        assert "step" in logged_data

    def test_on_train_end_calls_finish(self, monkeypatch, _mock_transformers):
        """Test 8: on_train_end calls openrunner.finish()."""
        from openrunner.integration.huggingface import OpenRunnerCallback
        import openrunner

        mock_finish = MagicMock()
        monkeypatch.setattr("openrunner.finish", mock_finish)

        cb = OpenRunnerCallback()
        args = _mock_transformers.TrainingArguments()
        state = _mock_transformers.TrainerState()
        control = _mock_transformers.TrainerControl()

        cb.on_train_end(args, state, control)

        mock_finish.assert_called_once()

    def test_on_log_noop_if_no_active_run(self, monkeypatch, _mock_transformers):
        """Test 9: on_log is a no-op if no active run."""
        from openrunner.integration.huggingface import OpenRunnerCallback
        import openrunner

        mock_log = MagicMock()
        monkeypatch.setattr("openrunner.log", mock_log)
        monkeypatch.setattr("openrunner._active_run", None)

        cb = OpenRunnerCallback()
        args = _mock_transformers.TrainingArguments()
        state = _mock_transformers.TrainerState()
        control = _mock_transformers.TrainerControl()

        cb.on_log(args, state, control, logs={"loss": 0.5})

        mock_log.assert_not_called()


class TestHuggingFaceImportError:
    """Test 10: clear ImportError when transformers is missing."""

    def test_import_error_when_transformers_missing(self, monkeypatch):
        monkeypatch.delitem(sys.modules, "transformers", raising=False)
        sys.modules.pop("openrunner.integration.huggingface", None)

        with pytest.raises(ImportError, match="pip install openrunner"):
            import openrunner.integration.huggingface  # noqa: F401
