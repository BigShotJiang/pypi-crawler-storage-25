"""Tests for the scikit-learn integration (utility functions)."""

from __future__ import annotations

import sys
import types
from unittest.mock import MagicMock, patch, call

import pytest


# ---------------------------------------------------------------------------
# Mock sklearn before importing the integration module
# ---------------------------------------------------------------------------

@pytest.fixture(autouse=True)
def _mock_sklearn(monkeypatch):
    """Inject a fake sklearn module so sklearn.py imports cleanly."""
    sklearn = types.ModuleType("sklearn")
    sklearn_metrics = types.ModuleType("sklearn.metrics")

    def _classification_report(y_true, y_pred, labels=None, target_names=None, output_dict=False):
        """Fake classification_report returning a dict."""
        return {
            "class_0": {"precision": 0.9, "recall": 0.85, "f1-score": 0.87, "support": 100},
            "class_1": {"precision": 0.8, "recall": 0.9, "f1-score": 0.85, "support": 80},
            "accuracy": 0.86,
            "macro avg": {"precision": 0.85, "recall": 0.875, "f1-score": 0.86, "support": 180},
        }

    def _confusion_matrix(y_true, y_pred, labels=None):
        """Fake confusion_matrix returning a 2x2 array-like."""
        return [[85, 15], [8, 72]]

    sklearn_metrics.classification_report = _classification_report
    sklearn_metrics.confusion_matrix = _confusion_matrix
    sklearn.metrics = sklearn_metrics

    monkeypatch.setitem(sys.modules, "sklearn", sklearn)
    monkeypatch.setitem(sys.modules, "sklearn.metrics", sklearn_metrics)
    yield
    sys.modules.pop("openrunner.integration.sklearn", None)


# ---------------------------------------------------------------------------
# Helper: fake model
# ---------------------------------------------------------------------------

def _make_model(params=None, feature_importances=None):
    """Create a fake sklearn estimator."""
    model = MagicMock()
    model.get_params.return_value = params or {"n_estimators": 100, "max_depth": 5}
    if feature_importances is not None:
        model.feature_importances_ = feature_importances
    else:
        # Remove the attribute entirely
        del model.feature_importances_
    return model


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

class TestLogModel:
    """Tests for log_model()."""

    def test_logs_model_params(self, monkeypatch):
        """log_model logs model hyperparameters with model/ prefix."""
        from openrunner.integration.sklearn import log_model
        import openrunner

        mock_config = MagicMock()
        monkeypatch.setattr("openrunner.config", mock_config)
        monkeypatch.setattr("openrunner._active_run", MagicMock())

        model = _make_model(params={"n_estimators": 100, "max_depth": 5, "random_state": 42})
        log_model(model)

        mock_config.update.assert_called_once()
        logged = mock_config.update.call_args[0][0]
        assert logged["model/n_estimators"] == 100
        assert logged["model/max_depth"] == 5
        assert logged["model/random_state"] == 42

    def test_noop_if_no_active_run(self, monkeypatch):
        """log_model is a no-op if no active run."""
        from openrunner.integration.sklearn import log_model
        import openrunner

        mock_config = MagicMock()
        monkeypatch.setattr("openrunner.config", mock_config)
        monkeypatch.setattr("openrunner._active_run", None)

        log_model(_make_model())
        mock_config.update.assert_not_called()


class TestLogClassificationReport:
    """Tests for log_classification_report()."""

    def test_logs_classification_report_as_table(self, monkeypatch):
        """log_classification_report creates a Table and logs it."""
        from openrunner.integration.sklearn import log_classification_report
        import openrunner

        mock_log = MagicMock()
        mock_table_cls = MagicMock()
        monkeypatch.setattr("openrunner.log", mock_log)
        monkeypatch.setattr("openrunner.Table", mock_table_cls)
        monkeypatch.setattr("openrunner._active_run", MagicMock())

        log_classification_report([0, 1, 0], [0, 1, 1])

        mock_table_cls.assert_called_once()
        call_kwargs = mock_table_cls.call_args[1]
        assert "class" in call_kwargs["columns"]
        assert "precision" in call_kwargs["columns"]
        # Data should have rows for class_0, class_1, accuracy, macro avg
        assert len(call_kwargs["data"]) == 4
        mock_log.assert_called_once()

    def test_noop_if_no_active_run(self, monkeypatch):
        """log_classification_report is a no-op if no active run."""
        from openrunner.integration.sklearn import log_classification_report
        import openrunner

        mock_log = MagicMock()
        monkeypatch.setattr("openrunner.log", mock_log)
        monkeypatch.setattr("openrunner._active_run", None)

        log_classification_report([0, 1], [0, 1])
        mock_log.assert_not_called()


class TestLogConfusionMatrix:
    """Tests for log_confusion_matrix()."""

    def test_logs_confusion_matrix_as_image(self, monkeypatch):
        """log_confusion_matrix creates a heatmap Image and logs it."""
        import openrunner

        mock_log = MagicMock()
        mock_image_cls = MagicMock()
        monkeypatch.setattr("openrunner.log", mock_log)
        monkeypatch.setattr("openrunner.Image", mock_image_cls)
        monkeypatch.setattr("openrunner._active_run", MagicMock())

        # Mock matplotlib so the test works without it installed
        mock_fig = MagicMock()
        mock_ax = MagicMock()
        mock_im = MagicMock()
        mock_ax.imshow.return_value = mock_im

        mock_plt = MagicMock()
        mock_plt.subplots.return_value = (mock_fig, mock_ax)

        mock_matplotlib = types.ModuleType("matplotlib")
        mock_matplotlib.use = MagicMock()
        mock_matplotlib_pyplot = mock_plt

        monkeypatch.setitem(sys.modules, "matplotlib", mock_matplotlib)
        monkeypatch.setitem(sys.modules, "matplotlib.pyplot", mock_matplotlib_pyplot)

        # Must reimport to pick up the mocked modules
        sys.modules.pop("openrunner.integration.sklearn", None)
        from openrunner.integration.sklearn import log_confusion_matrix

        log_confusion_matrix([0, 1, 0, 1], [0, 1, 1, 1], class_names=["cat", "dog"])

        mock_image_cls.assert_called_once_with(mock_fig)
        mock_log.assert_called_once()
        logged = mock_log.call_args[0][0]
        assert "confusion_matrix" in logged
        mock_plt.close.assert_called_once_with(mock_fig)

    def test_noop_if_no_active_run(self, monkeypatch):
        """log_confusion_matrix is a no-op if no active run."""
        from openrunner.integration.sklearn import log_confusion_matrix
        import openrunner

        mock_log = MagicMock()
        monkeypatch.setattr("openrunner.log", mock_log)
        monkeypatch.setattr("openrunner._active_run", None)

        log_confusion_matrix([0, 1], [0, 1])
        mock_log.assert_not_called()


class TestLogFeatureImportance:
    """Tests for log_feature_importance()."""

    def test_logs_feature_importance_as_table(self, monkeypatch):
        """log_feature_importance creates a sorted Table and logs it."""
        from openrunner.integration.sklearn import log_feature_importance
        import openrunner

        mock_log = MagicMock()
        mock_table_cls = MagicMock()
        monkeypatch.setattr("openrunner.log", mock_log)
        monkeypatch.setattr("openrunner.Table", mock_table_cls)
        monkeypatch.setattr("openrunner._active_run", MagicMock())

        model = _make_model(feature_importances=[0.1, 0.7, 0.2])
        log_feature_importance(model, feature_names=["f1", "f2", "f3"])

        mock_table_cls.assert_called_once()
        call_kwargs = mock_table_cls.call_args[1]
        assert call_kwargs["columns"] == ["feature", "importance"]
        # Should be sorted by importance descending: f2, f3, f1
        data = call_kwargs["data"]
        assert data[0][0] == "f2"
        assert data[1][0] == "f3"
        assert data[2][0] == "f1"

    def test_generates_default_feature_names(self, monkeypatch):
        """log_feature_importance generates feature_N names if not provided."""
        from openrunner.integration.sklearn import log_feature_importance
        import openrunner

        mock_log = MagicMock()
        mock_table_cls = MagicMock()
        monkeypatch.setattr("openrunner.log", mock_log)
        monkeypatch.setattr("openrunner.Table", mock_table_cls)
        monkeypatch.setattr("openrunner._active_run", MagicMock())

        model = _make_model(feature_importances=[0.5, 0.5])
        log_feature_importance(model)

        data = mock_table_cls.call_args[1]["data"]
        feature_names = [row[0] for row in data]
        assert "feature_0" in feature_names
        assert "feature_1" in feature_names

    def test_noop_if_no_feature_importances(self, monkeypatch):
        """log_feature_importance does nothing if model has no feature_importances_."""
        from openrunner.integration.sklearn import log_feature_importance
        import openrunner

        mock_log = MagicMock()
        monkeypatch.setattr("openrunner.log", mock_log)
        monkeypatch.setattr("openrunner._active_run", MagicMock())

        model = _make_model()  # no feature_importances
        log_feature_importance(model)

        mock_log.assert_not_called()


class TestSklearnImportError:
    """ImportError when sklearn is missing."""

    def test_import_error_when_sklearn_missing(self, monkeypatch):
        monkeypatch.delitem(sys.modules, "sklearn", raising=False)
        monkeypatch.delitem(sys.modules, "sklearn.metrics", raising=False)
        sys.modules.pop("openrunner.integration.sklearn", None)

        with pytest.raises(ImportError, match="pip install openrunner"):
            import openrunner.integration.sklearn  # noqa: F401
