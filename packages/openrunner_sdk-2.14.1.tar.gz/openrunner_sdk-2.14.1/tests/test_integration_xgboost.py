"""Tests for the XGBoost integration (OpenRunnerCallback)."""

from __future__ import annotations

import sys
import types
from unittest.mock import MagicMock

import pytest


# ---------------------------------------------------------------------------
# Mock xgboost before importing the integration module
# ---------------------------------------------------------------------------

@pytest.fixture(autouse=True)
def _mock_xgboost(monkeypatch):
    """Inject a fake xgboost module so xgboost.py imports cleanly."""
    xgboost = types.ModuleType("xgboost")
    xgboost_callback = types.ModuleType("xgboost.callback")

    class _TrainingCallback:
        """Fake base TrainingCallback class."""
        pass

    xgboost_callback.TrainingCallback = _TrainingCallback
    xgboost.callback = xgboost_callback

    monkeypatch.setitem(sys.modules, "xgboost", xgboost)
    monkeypatch.setitem(sys.modules, "xgboost.callback", xgboost_callback)
    yield
    sys.modules.pop("openrunner.integration.xgboost", None)


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

class TestOpenRunnerXGBoostCallback:
    """Tests for the XGBoost OpenRunnerCallback."""

    def test_before_training_calls_init(self, monkeypatch):
        """before_training calls openrunner.init() when no active run."""
        from openrunner.integration.xgboost import OpenRunnerCallback
        import openrunner

        mock_init = MagicMock(return_value=MagicMock())
        monkeypatch.setattr("openrunner.init", mock_init)
        monkeypatch.setattr("openrunner._active_run", None)

        cb = OpenRunnerCallback(project="xgb-project", config={"max_depth": 6})
        model = MagicMock()
        result = cb.before_training(model)

        mock_init.assert_called_once_with(project="xgb-project", config={"max_depth": 6})
        assert result is model

    def test_before_training_skips_if_active_run(self, monkeypatch):
        """before_training does not call init() if a run is already active."""
        from openrunner.integration.xgboost import OpenRunnerCallback
        import openrunner

        mock_init = MagicMock()
        monkeypatch.setattr("openrunner.init", mock_init)
        monkeypatch.setattr("openrunner._active_run", MagicMock())

        cb = OpenRunnerCallback()
        cb.before_training(MagicMock())

        mock_init.assert_not_called()

    def test_after_iteration_logs_eval_metrics(self, monkeypatch):
        """after_iteration logs evaluation metrics from evals_log."""
        from openrunner.integration.xgboost import OpenRunnerCallback
        import openrunner

        mock_log = MagicMock()
        monkeypatch.setattr("openrunner.log", mock_log)
        monkeypatch.setattr("openrunner._active_run", MagicMock())

        cb = OpenRunnerCallback()
        evals_log = {
            "train": {"rmse": [0.5, 0.4, 0.3]},
            "test": {"rmse": [0.6, 0.55, 0.5]},
        }
        result = cb.after_iteration(MagicMock(), epoch=2, evals_log=evals_log)

        assert result is False  # continue training
        mock_log.assert_called_once()
        logged = mock_log.call_args[0][0]
        assert logged["train/rmse"] == 0.3
        assert logged["test/rmse"] == 0.5
        assert mock_log.call_args[1]["step"] == 2

    def test_after_iteration_noop_if_no_active_run(self, monkeypatch):
        """after_iteration is a no-op if no active run."""
        from openrunner.integration.xgboost import OpenRunnerCallback
        import openrunner

        mock_log = MagicMock()
        monkeypatch.setattr("openrunner.log", mock_log)
        monkeypatch.setattr("openrunner._active_run", None)

        cb = OpenRunnerCallback()
        cb.after_iteration(MagicMock(), epoch=0, evals_log={"test": {"rmse": [0.5]}})

        mock_log.assert_not_called()

    def test_after_training_logs_best_and_finishes(self, monkeypatch):
        """after_training logs best_iteration, best_score and calls finish()."""
        from openrunner.integration.xgboost import OpenRunnerCallback
        import openrunner

        mock_log = MagicMock()
        mock_finish = MagicMock()
        monkeypatch.setattr("openrunner.log", mock_log)
        monkeypatch.setattr("openrunner.finish", mock_finish)
        monkeypatch.setattr("openrunner._active_run", MagicMock())

        model = MagicMock()
        model.best_iteration = 42
        model.best_score = 0.95

        cb = OpenRunnerCallback()
        result = cb.after_training(model)

        mock_log.assert_called_once()
        logged = mock_log.call_args[0][0]
        assert logged["best_iteration"] == 42
        assert logged["best_score"] == 0.95
        mock_finish.assert_called_once()
        assert result is model

    def test_after_training_no_finish_if_disabled(self, monkeypatch):
        """after_training does not call finish() if finish_on_end=False."""
        from openrunner.integration.xgboost import OpenRunnerCallback
        import openrunner

        mock_finish = MagicMock()
        monkeypatch.setattr("openrunner.log", MagicMock())
        monkeypatch.setattr("openrunner.finish", mock_finish)
        monkeypatch.setattr("openrunner._active_run", MagicMock())

        model = MagicMock()
        model.best_iteration = 10
        model.best_score = 0.9

        cb = OpenRunnerCallback(finish_on_end=False)
        cb.after_training(model)

        mock_finish.assert_not_called()

    def test_after_iteration_returns_false(self, monkeypatch):
        """after_iteration always returns False (continue training)."""
        from openrunner.integration.xgboost import OpenRunnerCallback
        import openrunner

        monkeypatch.setattr("openrunner.log", MagicMock())
        monkeypatch.setattr("openrunner._active_run", MagicMock())

        cb = OpenRunnerCallback()
        result = cb.after_iteration(MagicMock(), epoch=0, evals_log={})

        assert result is False


class TestXGBoostImportError:
    """ImportError when xgboost is missing."""

    def test_import_error_when_xgboost_missing(self, monkeypatch):
        monkeypatch.delitem(sys.modules, "xgboost", raising=False)
        monkeypatch.delitem(sys.modules, "xgboost.callback", raising=False)
        sys.modules.pop("openrunner.integration.xgboost", None)

        with pytest.raises(ImportError, match="pip install openrunner"):
            import openrunner.integration.xgboost  # noqa: F401
