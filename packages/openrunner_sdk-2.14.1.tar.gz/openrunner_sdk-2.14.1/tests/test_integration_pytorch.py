"""Tests for the PyTorch integration (log_gradients utility)."""

from __future__ import annotations

import sys
import types
from unittest.mock import MagicMock, patch, call

import pytest


# ---------------------------------------------------------------------------
# Mock torch before importing the integration module
# ---------------------------------------------------------------------------

@pytest.fixture(autouse=True)
def _mock_torch(monkeypatch):
    """Inject a fake 'torch' module into sys.modules so pytorch.py imports cleanly."""
    fake_torch = types.ModuleType("torch")
    fake_torch.nn = types.ModuleType("torch.nn")

    class _FakeModule:
        pass

    fake_torch.nn.Module = _FakeModule
    monkeypatch.setitem(sys.modules, "torch", fake_torch)
    monkeypatch.setitem(sys.modules, "torch.nn", fake_torch.nn)
    yield
    # Remove cached integration module so next test reimports fresh
    sys.modules.pop("openrunner.integration.pytorch", None)


# ---------------------------------------------------------------------------
# Helper: fake model
# ---------------------------------------------------------------------------

def _make_model(params: list[tuple[str, bool]]) -> MagicMock:
    """Create a fake model with named_parameters.

    Each entry in *params* is (name, has_grad).  If has_grad is True, a mock
    gradient with a deterministic norm is attached.
    """
    named = []
    for i, (name, has_grad) in enumerate(params):
        p = MagicMock()
        if has_grad:
            p.grad = MagicMock()
            p.grad.norm.return_value.item.return_value = float(i + 1)
        else:
            p.grad = None
        named.append((name, p))

    model = MagicMock()
    model.named_parameters.return_value = named
    return model


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

class TestLogGradients:
    """Tests for pytorch.log_gradients()."""

    def test_logs_gradient_norms(self, monkeypatch):
        """Test 1: logs gradient norms for each named parameter."""
        from openrunner.integration.pytorch import log_gradients

        mock_log = MagicMock()
        monkeypatch.setattr("openrunner.log", mock_log)

        model = _make_model([("layer1.weight", True), ("layer2.bias", True)])
        log_gradients(model, step=5)

        # Should have per-param log calls (commit=False) plus a final commit call
        assert mock_log.call_count == 3
        mock_log.assert_any_call({"gradients/layer1.weight": 1.0}, step=5, commit=False)
        mock_log.assert_any_call({"gradients/layer2.bias": 2.0}, step=5, commit=False)
        # Final commit
        mock_log.assert_any_call({}, step=5, commit=True)

    def test_skips_params_with_no_grad(self, monkeypatch):
        """Test 2: skips parameters with no gradient."""
        from openrunner.integration.pytorch import log_gradients

        mock_log = MagicMock()
        monkeypatch.setattr("openrunner.log", mock_log)

        model = _make_model([("w1", True), ("w2", False), ("w3", True)])
        log_gradients(model)

        # Should log w1 and w3 but not w2, plus final commit = 3 calls
        logged_keys = []
        for c in mock_log.call_args_list:
            data = c[0][0] if c[0] else c[1].get("data", {})
            logged_keys.extend(data.keys())
        assert "gradients/w2" not in logged_keys

    def test_no_crash_on_empty_model(self, monkeypatch):
        """Test 3: does not crash if model has no parameters."""
        from openrunner.integration.pytorch import log_gradients

        mock_log = MagicMock()
        monkeypatch.setattr("openrunner.log", mock_log)

        model = _make_model([])
        log_gradients(model)

        # Should still call the final commit
        mock_log.assert_called_once_with({}, step=None, commit=True)


class TestPyTorchImportError:
    """Test 4: clear ImportError when torch is missing."""

    def test_import_error_when_torch_missing(self, monkeypatch):
        # Remove the mock torch to simulate missing install
        monkeypatch.delitem(sys.modules, "torch", raising=False)
        monkeypatch.delitem(sys.modules, "torch.nn", raising=False)
        sys.modules.pop("openrunner.integration.pytorch", None)

        with pytest.raises(ImportError, match="pip install openrunner"):
            import openrunner.integration.pytorch  # noqa: F401
