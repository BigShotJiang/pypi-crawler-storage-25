from dominus import (
    BrowserNamespace,
    DeployerNamespace,
    RecipesNamespace,
    WardenNamespace,
    gateway_circuit_breaker,
    mint_selected_scope_jwt,
)


def test_top_level_exports_drop_delegate_alias():
    assert callable(mint_selected_scope_jwt)
    assert gateway_circuit_breaker is not None
    try:
        from dominus import delegate_jwt  # type: ignore[attr-defined]
    except ImportError:
        delegate_jwt = None

    assert delegate_jwt is None
    try:
        from dominus import orchestrator_circuit_breaker  # type: ignore[attr-defined]
    except ImportError:
        orchestrator_circuit_breaker = None

    assert orchestrator_circuit_breaker is None
    try:
        from dominus import OpenNamespace  # type: ignore[attr-defined]
    except ImportError:
        OpenNamespace = None

    assert OpenNamespace is None
    assert DeployerNamespace is not None
    assert WardenNamespace is not None
    assert BrowserNamespace is not None
    assert RecipesNamespace is not None


def test_singleton_exposes_browser_namespace():
    from dominus import dominus

    assert callable(dominus.browser.get_health)
    assert callable(dominus.recipes.list_types)
