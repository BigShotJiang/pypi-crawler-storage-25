import pytest

import dominus.start as start_module


@pytest.fixture()
def sdk(monkeypatch):
    monkeypatch.setattr(start_module, "_VALIDATION_ERROR", None)
    monkeypatch.setattr(start_module, "_TOKEN", "a" * 64)
    monkeypatch.setattr(start_module, "_VALIDATED", False)
    monkeypatch.setattr(start_module, "_BASE_URL", "https://gateway.example")
    monkeypatch.setattr(start_module, "_GATEWAY_URL", "https://gateway.example")
    return start_module.Dominus()


@pytest.mark.asyncio
async def test_recipes_namespace_maps_deprecate_to_gateway_route(monkeypatch, sdk):
    calls = []

    async def fake_request(**kwargs):
        calls.append(kwargs)
        return {"ok": True, "recipe": {"deprecated": True}}

    monkeypatch.setattr(sdk, "_request", fake_request)

    result = await sdk.recipes.deprecate(
        type="browser-recipe",
        tier="project",
        name="cms-login",
        version=3,
        reason="superseded",
    )

    assert result["recipe"]["deprecated"] is True
    assert calls == [
        {
            "endpoint": "/api/recipe/recipes/deprecate",
            "method": "POST",
            "body": {
                "type": "browser-recipe",
                "tier": "project",
                "name": "cms-login",
                "version": 3,
                "reason": "superseded",
            },
            "use_gateway": True,
            "timeout": 30.0,
        }
    ]
