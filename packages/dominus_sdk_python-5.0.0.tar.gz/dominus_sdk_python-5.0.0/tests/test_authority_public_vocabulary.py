import base64
import inspect
import json

import pytest

from dominus.helpers import core as core_helpers
from dominus.config import endpoints as endpoint_config
from dominus.namespaces.authority import AuthorityNamespace


class FakeClient:
    def __init__(self):
        self.calls = []

    async def _request(
        self,
        endpoint,
        method="POST",
        body=None,
        user_token=None,
        use_gateway=False,
        timeout=30.0,
        actor=None,
        **kwargs,
    ):
        self.calls.append(
            {
                "endpoint": endpoint,
                "method": method,
                "body": body,
                "user_token": user_token,
                "use_gateway": use_gateway,
                "timeout": timeout,
                "actor": actor,
            }
        )
        return {"ok": True}


class FakeMintResponse:
    def __init__(self, text: str):
        self.text = text

    def raise_for_status(self):
        return None


class FakeMintClient:
    instances = []

    def __init__(self, *, base_url, headers, timeout, proxy):
        self.base_url = base_url
        self.headers = headers
        self.timeout = timeout
        self.proxy = proxy
        self.posts = []
        FakeMintClient.instances.append(self)

    async def __aenter__(self):
        return self

    async def __aexit__(self, exc_type, exc, tb):
        return False

    async def post(self, path, content=None):
        self.posts.append({"path": path, "content": content})
        payload = base64.b64encode(
            json.dumps({"success": True, "data": {"token": "jwt-123"}}).encode("utf-8")
        ).decode("utf-8")
        return FakeMintResponse(payload)


def test_authority_scope_signatures_use_new_public_vocabulary():
    ensure_sig = inspect.signature(AuthorityNamespace.ensure_run)
    bootstrap_sig = inspect.signature(AuthorityNamespace.bootstrap_provisioning_target)
    release_sig = inspect.signature(AuthorityNamespace.publish_client_release)
    context_sig = inspect.signature(AuthorityNamespace.context_resolve)
    timeline_sig = inspect.signature(AuthorityNamespace.get_run_timeline)
    query_timelines_sig = inspect.signature(AuthorityNamespace.query_timelines)
    archive_status_sig = inspect.signature(AuthorityNamespace.get_timeline_archive_status)
    archive_run_sig = inspect.signature(AuthorityNamespace.archive_timelines)
    archive_repair_sig = inspect.signature(AuthorityNamespace.repair_timeline_archive_manifests)
    archive_verify_sig = inspect.signature(AuthorityNamespace.verify_timeline_archive_manifests)
    archive_prune_sig = inspect.signature(AuthorityNamespace.prune_timeline_archive_retention)
    schedule_create_sig = inspect.signature(AuthorityNamespace.create_schedule)
    mint_sig = inspect.signature(core_helpers.mint_selected_scope_jwt)

    for name in ("app_slug", "env", "target_org_id", "target_env", "run_kind", "target_app_slug", "bootstrap_profile_ref", "provisioning_target_slug"):
        assert name in ensure_sig.parameters
    old_profile_key = "bootstrap" + "_profile"
    for legacy in ("project_slug", "environment", "target_project_id", "target_environment", old_profile_key):
        assert legacy not in ensure_sig.parameters

    for name in ("shared_app_slug", "target_app_slug", "target_env", "bootstrap_profile_ref"):
        assert name in bootstrap_sig.parameters
    old_target_key = "company" + "_slug"
    for legacy in ("shared_project_slug", old_profile_key, old_target_key):
        assert legacy not in bootstrap_sig.parameters

    for name in ("storage_app_slug", "storage_env", "app_slug", "env"):
        assert name in release_sig.parameters
    for legacy in ("storage_project_slug", "storage_environment"):
        assert legacy not in release_sig.parameters

    for name in ("org_id", "app_slug", "target_org_id", "target_app_slug", "target_env", "env"):
        assert name in context_sig.parameters
    for legacy in ("org", "app", "project", "project_id", "project_slug", "environment", "target_project_id", "target_environment"):
        assert legacy not in context_sig.parameters

    for name in ("since", "until", "window_hours", "limit"):
        assert name in timeline_sig.parameters
        assert name in query_timelines_sig.parameters
    assert "all_scopes" in archive_status_sig.parameters
    for name in ("max_hours", "max_runtime_ms"):
        assert name in archive_run_sig.parameters
    for name in ("since", "until"):
        assert name in archive_repair_sig.parameters
        assert name in archive_verify_sig.parameters
        assert name in archive_prune_sig.parameters
    for name in ("retention_days", "dry_run", "confirm"):
        assert name in archive_prune_sig.parameters
    for name in ("gateway_route", "target_url", "frequency_kind", "max_runtime_ms", "app_slug", "env"):
        assert name in schedule_create_sig.parameters

    for name in ("target_org_id", "target_app_slug", "target_env"):
        assert name in mint_sig.parameters
    for legacy in ("target_project_id", "target_project_slug", "target_environment", "use_shared"):
        assert legacy not in mint_sig.parameters


@pytest.mark.asyncio
async def test_authority_scope_methods_use_canonical_context_wire_names():
    client = FakeClient()
    namespace = AuthorityNamespace(client)

    await namespace.ensure_run(
        workflow_id="wf-123",
        app_slug="carebridge",
        env="production",
        target_org_id="org-123",
        target_env="production",
    )
    await namespace.bootstrap_provisioning_target(
        "summit-radiology",
        shared_app_slug="shared-core",
        app_slug="carebridge",
        env="production",
        target_app_slug="carebridge",
        target_env="production",
        bootstrap_profile_ref="recipe://bootstrap-profile-v1/default@head",
    )
    await namespace.publish_client_release(
        variant_slug="desktop",
        version="1.2.3",
        manifest_path="manifest.json",
        storage_app_slug="storage-core",
        storage_env="production",
        app_slug="carebridge",
        env="production",
    )
    await namespace.context_resolve(
        org_id="org-123",
        app_slug="carebridge",
        target_org_id="target-org-1",
        target_app_slug="shared-core",
        target_env="production",
        env="production",
    )
    await namespace.get_run_timeline(
        "run-1",
        since="2026-04-11T08:33:00Z",
        until="2026-04-11T09:33:00Z",
        window_hours=24,
        limit=150,
    )
    await namespace.get_run_dossier(
        "run-1",
        since="2026-04-11T08:33:00Z",
        until="2026-04-11T09:33:00Z",
        window_hours=24,
        limit=150,
    )
    await namespace.get_provisioning_target_dossier(
        "summit-radiology",
        app_slug="carebridge",
        env="production",
        target_org_id="target-org-1",
        target_env="production",
        since="2026-04-11T08:33:00Z",
        until="2026-04-11T09:33:00Z",
        window_hours=24,
        limit=150,
    )
    await namespace.get_deploy_dossier(
        "deploy-1",
        since="2026-04-11T08:33:00Z",
        until="2026-04-11T09:33:00Z",
        window_hours=24,
        limit=150,
    )
    await namespace.query_timelines(
        subject="PCM47474562",
        company="summit-radiology",
        run_id="run-1",
        since="2026-04-11T08:33:00Z",
        until="2026-04-11T09:33:00Z",
        window_hours=24,
        limit=150,
    )
    await namespace.get_timeline_archive_status(
        all_scopes=True,
        app_slug="carebridge",
        env="production",
        limit=5,
    )
    await namespace.archive_timelines(
        max_hours=24,
        max_runtime_ms=600000,
    )
    await namespace.repair_timeline_archive_manifests(
        since="2026-04-01T00:00:00Z",
        until="2026-04-02T00:00:00Z",
    )
    await namespace.verify_timeline_archive_manifests(
        since="2026-04-01T00:00:00Z",
        until="2026-04-02T00:00:00Z",
    )
    await namespace.prune_timeline_archive_retention(
        since="2026-01-01T00:00:00Z",
        until="2026-01-02T00:00:00Z",
        retention_days=365,
        dry_run=False,
        confirm="DELETE_EXPIRED_ARCHIVE_OBJECTS",
    )
    await namespace.create_schedule(
        schedule_key="demo.hourly",
        app_slug="carebridge",
        env="production",
        target_url="https://demo.example/api/hourly",
        frequency_kind="hourly",
        max_runtime_ms=600000,
    )
    await namespace.update_schedule(
        "demo.hourly",
        enabled=False,
        next_due_at="2026-04-19T00:00:00Z",
    )
    await namespace.claim_due_schedules(limit=5, lock_seconds=900)
    await namespace.complete_schedule_run("demo.hourly", "run-1", result={"ok": True})
    await namespace.fail_schedule_run("demo.hourly", "run-2", error="boom", result={"ok": False})

    ensure_body = client.calls[0]["body"]
    assert ensure_body["app_slug"] == "carebridge"
    assert ensure_body["env"] == "production"
    assert ensure_body["target_org_id"] == "org-123"
    assert ensure_body["target_env"] == "production"
    assert "bootstrap_profile_ref" not in ensure_body

    bootstrap_body = client.calls[1]["body"]
    assert bootstrap_body["shared_app_slug"] == "shared-core"
    assert bootstrap_body["app_slug"] == "carebridge"
    assert bootstrap_body["target_app_slug"] == "carebridge"
    assert bootstrap_body["target_env"] == "production"
    assert bootstrap_body["bootstrap_profile_ref"] == "recipe://bootstrap-profile-v1/default@head"

    release_body = client.calls[2]["body"]
    assert release_body["storage_app_slug"] == "storage-core"
    assert release_body["storage_env"] == "production"
    assert release_body["app_slug"] == "carebridge"

    context_body = client.calls[3]["body"]
    assert context_body["org_id"] == "org-123"
    assert context_body["app_slug"] == "carebridge"
    assert context_body["target_org_id"] == "target-org-1"
    assert context_body["target_app_slug"] == "shared-core"
    assert context_body["target_env"] == "production"
    assert context_body["env"] == "production"

    assert client.calls[4]["endpoint"] == (
        "/api/authority/runs/run-1/timeline?"
        "since=2026-04-11T08%3A33%3A00Z&until=2026-04-11T09%3A33%3A00Z&window_hours=24&limit=150"
    )
    assert client.calls[5]["endpoint"] == (
        "/api/authority/dossiers/run/run-1?"
        "since=2026-04-11T08%3A33%3A00Z&until=2026-04-11T09%3A33%3A00Z&window_hours=24&limit=150"
    )
    assert client.calls[6]["endpoint"] == (
        "/api/authority/dossiers/provisioning-target/summit-radiology?"
        "app_slug=carebridge&env=production&target_org_id=target-org-1&target_env=production"
        "&since=2026-04-11T08%3A33%3A00Z&until=2026-04-11T09%3A33%3A00Z&window_hours=24&limit=150"
    )
    assert client.calls[7]["endpoint"] == (
        "/api/authority/dossiers/deploy/deploy-1?"
        "since=2026-04-11T08%3A33%3A00Z&until=2026-04-11T09%3A33%3A00Z&window_hours=24&limit=150"
    )
    assert client.calls[8]["body"] == {
        "subject": "PCM47474562",
        "company": "summit-radiology",
        "run_id": "run-1",
        "since": "2026-04-11T08:33:00Z",
        "until": "2026-04-11T09:33:00Z",
        "window_hours": 24,
        "limit": 150,
    }
    assert client.calls[9]["endpoint"] == (
        "/api/authority/timelines/archive-status?"
        "all_scopes=true&app_slug=carebridge&env=production&limit=5"
    )
    assert client.calls[10]["endpoint"] == "/api/authority/timelines/archive"
    assert client.calls[10]["method"] == "POST"
    assert client.calls[10]["body"] == {
        "max_hours": 24,
        "max_runtime_ms": 600000,
    }
    assert client.calls[11]["endpoint"] == "/api/authority/timelines/archive-repair"
    assert client.calls[11]["method"] == "POST"
    assert client.calls[11]["body"] == {
        "since": "2026-04-01T00:00:00Z",
        "until": "2026-04-02T00:00:00Z",
    }
    assert client.calls[12]["endpoint"] == "/api/authority/timelines/archive-verify"
    assert client.calls[12]["body"] == {
        "since": "2026-04-01T00:00:00Z",
        "until": "2026-04-02T00:00:00Z",
    }
    assert client.calls[13]["endpoint"] == "/api/authority/timelines/archive-prune"
    assert client.calls[13]["body"] == {
        "since": "2026-01-01T00:00:00Z",
        "until": "2026-01-02T00:00:00Z",
        "retention_days": 365,
        "dry_run": False,
        "confirm": "DELETE_EXPIRED_ARCHIVE_OBJECTS",
    }
    assert client.calls[14]["endpoint"] == "/api/authority/schedules"
    assert client.calls[14]["body"] == {
        "schedule_key": "demo.hourly",
        "owner_app_slug": "carebridge",
        "owner_env": "production",
        "target_url": "https://demo.example/api/hourly",
        "frequency_kind": "hourly",
        "max_runtime_ms": 600000,
    }
    assert client.calls[15]["endpoint"] == "/api/authority/schedules/demo.hourly"
    assert client.calls[15]["method"] == "PATCH"
    assert client.calls[15]["body"] == {
        "enabled": False,
        "next_due_at": "2026-04-19T00:00:00Z",
    }
    assert client.calls[16]["endpoint"] == "/api/authority/schedules/claim-due"
    assert client.calls[16]["body"] == {"limit": 5, "lock_seconds": 900}
    assert client.calls[17]["endpoint"] == "/api/authority/schedules/demo.hourly/runs/run-1/complete"
    assert client.calls[18]["endpoint"] == "/api/authority/schedules/demo.hourly/runs/run-2/fail"


@pytest.mark.asyncio
async def test_authority_provisioning_target_helpers_use_final_routes_and_payload_keys():
    client = FakeClient()
    namespace = AuthorityNamespace(client)

    await namespace.create_provisioning_target(
        provisioning_target_slug="summit-radiology",
        app_slug="carebridge",
        env="production",
        target_app_slug="carebridge",
        target_env="production",
        shared_app_slug="carebridge-platform",
    )
    await namespace.get_provisioning_target(
        "summit-radiology",
        app_slug="carebridge",
        env="production",
    )
    await namespace.list_provisioning_targets(app_slug="carebridge", env="production", limit=25)
    await namespace.bootstrap_provisioning_target(
        "summit-radiology",
        action="start",
        bootstrap_profile_ref="recipe://bootstrap-profile-v1/default@head",
        execution_mode="async",
    )
    await namespace.get_provisioning_target_bootstrap(
        "summit-radiology",
        run_id="provisioning-run::run-1",
    )

    assert client.calls[0]["endpoint"] == "/api/authority/provisioning-targets"
    assert client.calls[0]["body"]["provisioning_target_slug"] == "summit-radiology"
    assert client.calls[0]["body"]["target_app_slug"] == "carebridge"
    assert client.calls[1]["endpoint"] == "/api/authority/provisioning-targets/summit-radiology?app_slug=carebridge&env=production"
    assert client.calls[2]["endpoint"] == "/api/authority/provisioning-targets?app_slug=carebridge&env=production&limit=25&offset=0"
    assert client.calls[3]["endpoint"] == "/api/authority/provisioning-targets/summit-radiology/bootstrap"
    assert client.calls[3]["body"]["bootstrap_profile_ref"] == "recipe://bootstrap-profile-v1/default@head"
    assert client.calls[4]["endpoint"] == "/api/authority/provisioning-targets/summit-radiology/bootstrap?run_id=provisioning-run%3A%3Arun-1"


@pytest.mark.asyncio
async def test_selected_scope_mint_helper_uses_new_public_names_and_route_canonical_mint_payload(monkeypatch):
    FakeMintClient.instances.clear()
    monkeypatch.setattr(core_helpers.httpx, "AsyncClient", FakeMintClient)
    monkeypatch.setattr(endpoint_config, "get_gateway_url", lambda: "https://gateway.example")
    monkeypatch.setattr(endpoint_config, "get_proxy_config", lambda: None)

    token = await core_helpers.mint_selected_scope_jwt(
        "psk-token",
        target_org_id="org-123",
        target_app_slug="carebridge",
        target_env="production",
    )

    assert token == "jwt-123"
    assert FakeMintClient.instances[0].base_url == "https://gateway.example"
    sent = json.loads(
        base64.b64decode(FakeMintClient.instances[0].posts[0]["content"]).decode("utf-8")
    )
    assert sent == {
        "target_org_id": "org-123",
        "target_env": "production",
    }


@pytest.mark.asyncio
async def test_list_runs_drops_target_query_when_matching_gateway_scope():
    client = FakeClient()
    client._gateway_org_id = "a73627b4-071f-4d27-b964-d220464deb6e"
    client._gateway_env = "production"
    ns = AuthorityNamespace(client)
    await ns.list_runs(
        app_slug="dominus-authority",
        env="production",
        target_org_id="a73627b4-071f-4d27-b964-d220464deb6e",
        target_env="production",
        limit=5,
        offset=0,
    )
    ep = client.calls[0]["endpoint"]
    assert "target_org_id" not in ep
    assert "target_env" not in ep
    assert "app_slug=dominus-authority" in ep


@pytest.mark.asyncio
async def test_list_runs_keeps_target_query_when_org_differs_from_gateway():
    client = FakeClient()
    client._gateway_org_id = "aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa"
    client._gateway_env = "production"
    ns = AuthorityNamespace(client)
    await ns.list_runs(
        app_slug="dominus-authority",
        env="production",
        target_org_id="bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb",
        target_env="production",
        limit=3,
    )
    ep = client.calls[0]["endpoint"]
    assert "target_org_id=bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb" in ep


@pytest.mark.asyncio
async def test_authority_ensure_run_provisioning_bootstrap_omits_workflow_mode():
    client = FakeClient()
    namespace = AuthorityNamespace(client)
    await namespace.ensure_run(
        run_kind="provisioning.bootstrap",
        provisioning_target_slug="acme-corp",
        app_slug="carebridge",
        env="production",
        target_org_id="org-1",
        execution_mode="async",
        shared_app_slug="shared-core",
        bootstrap_profile_ref="recipe://bootstrap-profile-v1/default@head",
    )
    body = client.calls[0]["body"]
    assert body["run_kind"] == "provisioning.bootstrap"
    assert body["provisioning_target_slug"] == "acme-corp"
    assert body["execution_mode"] == "async"
    assert body["shared_app_slug"] == "shared-core"
    assert body["bootstrap_profile_ref"] == "recipe://bootstrap-profile-v1/default@head"
    assert "mode" not in body


@pytest.mark.asyncio
async def test_authority_ensure_run_bootstrap_requires_provisioning_target_slug():
    client = FakeClient()
    namespace = AuthorityNamespace(client)
    with pytest.raises(ValueError, match="provisioning_target_slug"):
        await namespace.ensure_run(
            run_kind="provisioning.bootstrap",
            app_slug="carebridge",
            env="production",
        )
    assert client.calls == []
