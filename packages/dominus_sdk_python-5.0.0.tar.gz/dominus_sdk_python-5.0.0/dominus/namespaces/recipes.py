"""
Recipes Namespace - kernel-tier recipe protocol.

Routes through ``/svc/recipe/*`` on the Dominus gateway. The recipe worker
owns the type registry, JSON-Schema-based publish validation, three-tier
resolution (project -> group -> platform), and B2-backed durable storage.

Recipe types currently registered:
  - browser-recipe (owned by dominus-browser-worker; body version is browser-recipe-v1)

Refs follow ``recipe://{type}/{name}[@v{N}][?tier={tier}]``.
"""
from __future__ import annotations

from typing import Any, Dict, List, Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from ..start import Dominus


def _compact(payload: Dict[str, Any]) -> Dict[str, Any]:
    return {k: v for k, v in payload.items() if v is not None and v != ""}


class RecipesNamespace:
    """
    Recipe worker namespace.

    Usage::

        types = await dominus.recipes.list_types()
        await dominus.recipes.publish(
            type="browser-recipe",
            tier="platform",
            name="health-check",
            body="version: browser-recipe-v1\\nsteps:\\n  - kind: goto\\n    url: https://x/\\n",
        )
        recipe = await dominus.recipes.get(type="browser-recipe", name="health-check")
    """

    def __init__(self, client: "Dominus"):
        self._client = client

    async def _post(self, endpoint: str, body: Optional[Dict[str, Any]] = None, *, timeout: float = 30.0) -> Dict[str, Any]:
        return await self._client._request(
            endpoint=endpoint,
            method="POST",
            body=body or {},
            use_gateway=True,
            timeout=timeout,
        )

    async def _get(self, endpoint: str, *, timeout: float = 30.0) -> Dict[str, Any]:
        return await self._client._request(
            endpoint=endpoint,
            method="GET",
            use_gateway=True,
            timeout=timeout,
        )

    async def list_types(self, *, owning_worker: Optional[str] = None, timeout: float = 15.0) -> Dict[str, Any]:
        """List registered recipe types. ``GET /api/recipe/types``."""
        query = f"?owning_worker={owning_worker}" if owning_worker else ""
        return await self._get(f"/api/recipe/types{query}", timeout=timeout)

    async def get_type(self, name: str, *, timeout: float = 15.0) -> Dict[str, Any]:
        """Fetch a registered recipe type's schema. ``GET /api/recipe/types/{name}``."""
        return await self._get(f"/api/recipe/types/{name}", timeout=timeout)

    async def publish(
        self,
        *,
        type: str,
        tier: str,
        name: str,
        body: str,
        description: Optional[str] = None,
        timeout: float = 30.0,
    ) -> Dict[str, Any]:
        """Publish a recipe. ``POST /api/recipe/recipes/publish``."""
        return await self._post(
            "/api/recipe/recipes/publish",
            _compact({
                "type": type,
                "tier": tier,
                "name": name,
                "body": body,
                "description": description,
            }),
            timeout=timeout,
        )

    async def validate(
        self,
        *,
        type: str,
        body: str,
        timeout: float = 15.0,
    ) -> Dict[str, Any]:
        """Validate a recipe body against its type schema. ``POST /api/recipe/recipes/validate``."""
        return await self._post(
            "/api/recipe/recipes/validate",
            {"type": type, "body": body},
            timeout=timeout,
        )

    async def deprecate(
        self,
        *,
        type: str,
        tier: str,
        name: str,
        version: int,
        reason: Optional[str] = None,
        timeout: float = 30.0,
    ) -> Dict[str, Any]:
        """Mark the current head recipe version deprecated. ``POST /api/recipe/recipes/deprecate``."""
        return await self._post(
            "/api/recipe/recipes/deprecate",
            _compact({
                "type": type,
                "tier": tier,
                "name": name,
                "version": version,
                "reason": reason,
            }),
            timeout=timeout,
        )

    async def list(
        self,
        *,
        type: Optional[str] = None,
        tier: Optional[str] = None,
        name_prefix: Optional[str] = None,
        timeout: float = 15.0,
    ) -> Dict[str, Any]:
        """List recipes filtered by type/tier/name. ``GET /api/recipe/recipes/list``."""
        params: List[str] = []
        if type:
            params.append(f"type={type}")
        if tier:
            params.append(f"tier={tier}")
        if name_prefix:
            params.append(f"name_prefix={name_prefix}")
        query = ("?" + "&".join(params)) if params else ""
        return await self._get(f"/api/recipe/recipes/list{query}", timeout=timeout)

    async def get(
        self,
        *,
        type: str,
        name: str,
        version: Optional[int] = None,
        tier: Optional[str] = None,
        timeout: float = 15.0,
    ) -> Dict[str, Any]:
        """Resolve a recipe through the three-tier chain. ``GET /api/recipe/recipes/{type}/{name}[@v{N}]``."""
        path = f"/api/recipe/recipes/{type}/{name}"
        if version is not None:
            path += f"@v{version}"
        if tier:
            path += f"?tier={tier}"
        return await self._get(path, timeout=timeout)

    async def register_type(
        self,
        *,
        name: str,
        owning_worker: str,
        schema_version: int,
        json_schema: Dict[str, Any],
        timeout: float = 15.0,
    ) -> Dict[str, Any]:
        """Register a recipe type. ``POST /api/recipe/types/register``.

        Owning workers do this on cold start. Normal callers should not need it.
        """
        return await self._post(
            "/api/recipe/types/register",
            {
                "name": name,
                "owning_worker": owning_worker,
                "schema_version": schema_version,
                "json_schema": json_schema,
            },
            timeout=timeout,
        )
