"""
Gateway-first Dominus SDK.

Setup:
    export DOMINUS_TOKEN="your_token"

Preferred usage is namespace-based:
    from dominus import dominus, SecureAccessContext

    value = await dominus.secrets.get("DB_URL")
    tables = await dominus.db.tables(schema="public")
    status = await dominus.health.check()

    context = SecureAccessContext(
        reason="Reviewing patient chart",
        actor="user:123",
    )
    patients = await dominus.secure.query("patients", context)

Flat root shortcuts remain for common secrets and DB operations:
    value = await dominus.get("DB_URL")
    await dominus.upsert("KEY", "value")
    rows = await dominus.query_table("users")

Supported string commands are limited to the same gateway-backed shortcuts:
    result = await dominus("secrets.get", key="DB_URL")
    tables = await dominus("sql.app.list_tables", schema="public")
"""
import os
import httpx
import base64
import json
from typing import Optional, Any, Dict, List

from .errors import ConnectionError as DominusConnectionError
from .errors import DominusError, TimeoutError as DominusTimeoutError, raise_for_status

# Module-level state
_VALIDATED = False
_TOKEN: Optional[str] = None
_BASE_URL: Optional[str] = None
_GATEWAY_URL: Optional[str] = None
_VALIDATION_ERROR: Optional[str] = None


# === MODULE-LEVEL INITIALIZATION ===
from .helpers.auth import _resolve_token
from .config.endpoints import BASE_URL, GATEWAY_URL

_TOKEN = _resolve_token()
_BASE_URL = BASE_URL
_GATEWAY_URL = GATEWAY_URL

# Initialize cache encryption
from .helpers.cache import dominus_cache
if _TOKEN:
    dominus_cache.set_encryption_key(_TOKEN)

# Validate token presence
if not _TOKEN:
    _VALIDATION_ERROR = (
        "DOMINUS_TOKEN not found.\n\n"
        "Set the environment variable:\n"
        "  export DOMINUS_TOKEN=your_token\n\n"
        "Or in production, set it via your deployment platform.\n"
    )


class Dominus:
    """
    Main SDK entry point with namespace-first APIs.

    Optional gateway context (MCP / user JWT): pass ``gateway_user_token`` plus
    ``gateway_org_id`` / ``gateway_app_slug`` / ``gateway_env`` so
    ``_request(..., use_gateway=True)``
    uses the session JWT and scope headers instead of the service PSK flow.

    Root shortcuts remain for common secrets and DB operations:
    - dominus.get(), dominus.upsert() - secrets
    - dominus.query_table(), dominus.insert_row() - SQL (public schema)
    - dominus.add_table(), dominus.add_column() - DDL (public schema)

    Namespaces for specific use cases:
    - dominus.secure.* - secure schema operations
    - dominus.auth.* - Guardian auth and RBAC operations
    - dominus.health.check() - health checks
    """

    def __init__(
        self,
        *,
        gateway_user_token: Optional[str] = None,
        gateway_org_id: Optional[str] = None,
        gateway_app_slug: Optional[str] = None,
        gateway_env: Optional[str] = None,
    ):
        """Initialize Dominus with flat API and minimal namespaces."""
        self._gateway_user_token = gateway_user_token
        self._gateway_org_id = gateway_org_id
        self._gateway_app_slug = gateway_app_slug
        self._gateway_env = gateway_env

        # Create internal execute function that handles validation
        async def _execute_command(command: str, **kwargs) -> Any:
            """Internal flat-command dispatcher."""
            await self._ensure_ready()
            return await self._dispatch_flat_command(command, **kwargs)

        self._execute = _execute_command

        # Initialize portal namespace (needs client reference for _request)
        from .namespaces.portal import PortalNamespace
        self.portal = PortalNamespace(self)

        # Initialize FastAPI namespace (decorators for route auth)
        from .namespaces.fastapi import FastAPINamespace
        self.fastapi = FastAPINamespace(self)

        # Initialize all namespaces (matching Node.js SDK pattern)
        from .namespaces.db import DbNamespace
        from .namespaces.auth import AuthNamespace
        from .namespaces.ddl import DdlNamespace
        from .namespaces.files import FilesNamespace
        from .namespaces.admin import AdminNamespace
        from .namespaces.secure import SecureNamespace as SecureNS
        from .namespaces.secrets import SecretsNamespace
        from .namespaces.redis import RedisNamespace
        from .namespaces.logs import LogsNamespace
        from .namespaces.courier import CourierNamespace
        from .namespaces.health import HealthNamespace
        # Core namespaces
        self.db = DbNamespace(self)
        self.auth = AuthNamespace(self)
        self.ddl = DdlNamespace(self)
        self.files = FilesNamespace(self)
        self.admin = AdminNamespace(self)

        # Additional namespaces (Node.js SDK parity)
        self.secrets = SecretsNamespace(self)
        self.redis = RedisNamespace(self)
        self.logs = LogsNamespace(self)
        self.courier = CourierNamespace(self)
        self.health = HealthNamespace(self)
        # Secure namespace with audit context support
        self.secure = SecureNS(self)

        # AI namespace (agent-runtime unified API; batch STT at ai.stt -> /api/agent/stt)
        from .namespaces.ai import AiNamespace
        self.ai = AiNamespace(self)

        # Workflow namespace (workflow-manager service)
        from .namespaces.workflow import WorkflowNamespace
        self.workflow = WorkflowNamespace(self)

        # Artifact storage (artifact-worker, auto-tiered Redis/B2)
        from .namespaces.artifacts import ArtifactsNamespace
        self.artifacts = ArtifactsNamespace(self)

        # Job queue (job-worker)
        from .namespaces.jobs import JobsNamespace
        self.jobs = JobsNamespace(self)

        # Job processor (processor Cloud Run)
        from .namespaces.processor import ProcessorNamespace
        self.processor = ProcessorNamespace(self)

        # KV sync (sync-worker)
        from .namespaces.sync import SyncNamespace
        self.sync = SyncNamespace(self)

        # Authority service (runs, provisioning targets, deploys, managed clients, dossiers)
        from .namespaces.authority import AuthorityNamespace
        self.authority = AuthorityNamespace(self)

        # Browser automation primitive (Cloudflare Browser Run default)
        from .namespaces.browser import BrowserNamespace
        self.browser = BrowserNamespace(self)

        # Thin operator control-plane namespaces (Mothership / MCP parity)
        from .namespaces.deployer import DeployerNamespace
        from .namespaces.warden import WardenNamespace
        self.deployer = DeployerNamespace(self)
        self.warden = WardenNamespace(self)

        # Stash worker (per-scope durable items: credentials + configs)
        from .namespaces.stash import StashNamespace
        self.stash = StashNamespace(self)

        # Recipe worker (kernel-tier; hosts browser-recipe today, workflow + envoy + others later)
        from .namespaces.recipes import RecipesNamespace
        self.recipes = RecipesNamespace(self)

        # Cache for JWT public key
        self._public_key_cache = None

        # Auto-activate console capture (opt-out with DOMINUS_CAPTURE_CONSOLE=false)
        if os.environ.get("DOMINUS_CAPTURE_CONSOLE", "true").lower() != "false":
            from .helpers.console_capture import install_console_capture
            install_console_capture(self.logs)

    def capture_console(self) -> None:
        """Start capturing print() and logging.* and forwarding to Dominus Logs Worker.
        Original output is preserved (original functions still called)."""
        from .helpers.console_capture import install_console_capture
        install_console_capture(self.logs)

    def release_console(self) -> None:
        """Stop capturing console output. Restores original print() and removes log handler."""
        from .helpers.console_capture import uninstall_console_capture
        uninstall_console_capture()

    @property
    def is_capturing_console(self) -> bool:
        """Check if console capture is currently active."""
        from .helpers.console_capture import is_console_capture_active
        return is_console_capture_active()

    async def _ensure_ready(self) -> None:
        """Validate token presence and format once without a startup health gate."""
        global _VALIDATED

        if _VALIDATION_ERROR:
            raise RuntimeError(_VALIDATION_ERROR)

        if not _VALIDATED:
            from .helpers.core import verify_token_format

            verify_token_format(_TOKEN)
            _VALIDATED = True

    @staticmethod
    def _normalize_flat_schema(schema: Optional[str]) -> str:
        """Map legacy flat schema names onto the live gateway contract."""
        if not schema or schema == "app":
            return "public"
        return schema

    async def _dispatch_flat_command(self, command: str, **kwargs) -> Any:
        """Route the supported flat shortcut surface onto the namespace APIs."""
        from .helpers.core import _ensure_valid_jwt

        schema = self._normalize_flat_schema(kwargs.get("schema"))

        if command == "health.check":
            return await self.health.check()
        if command == "auth.self":
            jwt = await _ensure_valid_jwt(_TOKEN, _BASE_URL)
            return {"access_token": jwt, "token_type": "bearer"}
        if command == "auth.jwks":
            return await self.auth.get_jwks()
        if command == "secrets.get":
            return await self.secrets.get(kwargs["key"])
        if command == "secrets.upsert":
            return await self.secrets.upsert(
                kwargs["key"],
                kwargs["value"],
                kwargs.get("comment"),
            )
        if command == "sql.app.list_tables":
            return await self.db.tables(schema=schema)
        if command == "sql.app.query_table":
            return await self.db.query(
                kwargs["table_name"],
                schema=schema,
                filters=kwargs.get("filters"),
                sort_by=kwargs.get("sort_by"),
                sort_order=kwargs.get("sort_order", "ASC"),
                limit=kwargs.get("limit", 100),
                offset=kwargs.get("offset", 0),
            )
        if command == "sql.app.insert_row":
            return await self.db.insert(kwargs["table_name"], kwargs["data"], schema=schema)
        if command == "sql.app.update_rows":
            return await self.db.update(
                kwargs["table_name"],
                kwargs["data"],
                kwargs["filters"],
                schema=schema,
            )
        if command == "sql.app.delete_rows":
            return await self.db.delete(
                kwargs["table_name"],
                kwargs["filters"],
                schema=schema,
            )
        if command == "sql.app.list_columns":
            return await self.db.columns(kwargs["table_name"], schema=schema)
        if command == "sql.app.get_table_size":
            table_name = str(kwargs["table_name"])
            escaped_schema = schema.replace('"', '""')
            escaped_table = table_name.replace('"', '""')
            result = await self.db.raw(
                f"SELECT pg_total_relation_size('\"{escaped_schema}\".\"{escaped_table}\"') AS total_bytes",
                schema=schema,
            )
            rows = result.get("rows", [])
            return {
                "schema": schema,
                "table_name": table_name,
                "total_bytes": rows[0].get("total_bytes") if rows else None,
            }
        if command == "schema.list_tables":
            return await self.db.tables(schema=schema)
        if command == "schema.list_columns":
            return await self.db.columns(kwargs["table_name"], schema=schema)
        if command == "schema.add_table":
            return await self.ddl.create_table(schema, kwargs["table_name"], kwargs["columns"])
        if command == "schema.delete_table":
            return await self.ddl.drop_table(schema, kwargs["table_name"])
        if command == "schema.add_column":
            constraints = [str(item).upper() for item in (kwargs.get("constraints") or [])]
            nullable = "NOT NULL" not in constraints
            return await self.ddl.add_column(
                schema,
                kwargs["table_name"],
                kwargs["column_name"],
                kwargs["column_type"],
                nullable=nullable,
                default=kwargs.get("default"),
            )
        if command == "schema.delete_column":
            return await self.ddl.drop_column(schema, kwargs["table_name"], kwargs["column_name"])

        raise RuntimeError(
            f"Legacy flat command '{command}' was removed in the hard cutover. "
            "Use namespace APIs such as dominus.db.*, dominus.secrets.*, dominus.auth.*, "
            "dominus.secure.*, dominus.workflow.*, or dominus.authority.*."
        )

    # ========================================
    # INTERNAL REQUEST METHOD (for user JWT)
    # ========================================

    async def _request(
        self,
        endpoint: str,
        method: str = "POST",
        body: Optional[Dict[str, Any]] = None,
        user_token: Optional[str] = None,
        use_gateway: bool = True,
        timeout: float = 30.0,
        actor: Optional[Dict[str, str]] = None,
        extra_headers: Optional[Dict[str, str]] = None,
    ) -> Dict[str, Any]:
        """
        Make an HTTP request to the Dominus service plane.

        If user_token is provided, uses that JWT directly (for user-authenticated requests).
        Otherwise, uses the service token flow (PSK -> JWT).

        Args:
            endpoint: API endpoint path (e.g., "/api/portal/auth/me")
            method: HTTP method (GET, POST, PUT, DELETE)
            body: Request body (will be base64-encoded)
            user_token: Optional user JWT for user-authenticated requests
            use_gateway: If True, route through gateway (/api/* -> /svc/*)
            timeout: Request timeout in seconds (default 30.0)
            extra_headers: Merged after scope headers; use for per-call X-App / X-Env overrides.

        Returns:
            Response data dict
        """
        # Base64 helpers
        def _b64_encode(d: dict) -> str:
            return base64.b64encode(json.dumps(d).encode()).decode()

        # Transform endpoint for gateway routing
        if use_gateway and endpoint.startswith("/api/"):
            endpoint = "/svc/" + endpoint[5:]  # /api/llm/complete -> /svc/llm/complete

        # Determine which JWT to use (per-call user_token wins over MCP/session client defaults)
        effective_user_token = user_token or getattr(self, "_gateway_user_token", None)
        if effective_user_token:
            # Use the provided user JWT directly; downstream services validate it.
            jwt = effective_user_token
        else:
            await self._ensure_ready()
            # Get service JWT
            from .helpers.core import _ensure_valid_jwt
            jwt = await _ensure_valid_jwt(_TOKEN, _BASE_URL)

        # Prepare request
        from .helpers.trace import get_current_trace_id, get_current_span_id
        headers = {
            "Authorization": f"Bearer {jwt}",
            "Content-Type": "text/plain",
            "X-Trace-Id": get_current_trace_id(),
            "X-Parent-Span-Id": get_current_span_id(),
        }
        org_id = getattr(self, "_gateway_org_id", None)
        app_slug = getattr(self, "_gateway_app_slug", None)
        environment = getattr(self, "_gateway_env", None)
        if org_id:
            headers["X-Org"] = str(org_id)
        if app_slug:
            headers["X-App"] = str(app_slug)
        if environment:
            headers["X-Env"] = str(environment)
        if extra_headers:
            headers.update(extra_headers)
        # Compliance actor headers (Phase 0.5 hard cutover). Explicit actor
        # takes precedence; auto-derive from user JWT claims when available.
        effective_actor = actor
        if not effective_actor and effective_user_token:
            try:
                payload_b64 = effective_user_token.split(".")[1]
                payload_b64 += "=" * (4 - len(payload_b64) % 4)
                payload = json.loads(base64.b64decode(payload_b64))
                uid = str(payload.get("user_id", "")).strip()
                if uid:
                    effective_actor = {"type": "user", "id": uid}
            except Exception:
                pass
        if effective_actor and effective_actor.get("type") and effective_actor.get("id"):
            headers["X-Actor-Type"] = str(effective_actor["type"])
            headers["X-Actor-Id"] = str(effective_actor["id"])

        # Prepare body
        body_b64 = _b64_encode(body or {})

        # Select base URL
        base_url = _GATEWAY_URL if use_gateway else _BASE_URL

        try:
            async with httpx.AsyncClient(base_url=base_url, headers=headers, timeout=timeout) as client:
                if method == "GET":
                    response = await client.get(endpoint)
                elif method == "DELETE":
                    # Kernel wire format: same base64 JSON body as POST (Node SDK parity).
                    response = await client.delete(endpoint, content=body_b64)
                elif method == "PUT":
                    response = await client.put(endpoint, content=body_b64)
                else:
                    response = await client.post(endpoint, content=body_b64)
        except httpx.TimeoutException as exc:
            raise DominusTimeoutError("Request timed out", endpoint=endpoint) from exc
        except httpx.NetworkError as exc:
            raise DominusConnectionError(f"Request failed: {exc}", endpoint=endpoint) from exc

        def _decode_error_payload(text: str) -> Dict[str, Any]:
            if not text:
                return {}
            try:
                from .helpers.core import _decode_json_or_b64_json

                decoded = _decode_json_or_b64_json(text)
                return decoded if isinstance(decoded, dict) else {"detail": decoded}
            except Exception:
                return {"detail": text}

        if response.is_error:
            error_payload = _decode_error_payload(response.text)
            nested = error_payload.get("error")
            nested_err: Dict[str, Any] = (
                nested if isinstance(nested, dict) else {}
            )
            error_message = (
                error_payload.get("message")
                or (nested_err.get("message") if nested_err else None)
                or (isinstance(nested, str) and nested)
                or error_payload.get("error")
                or error_payload.get("detail")
                or f"HTTP {response.status_code}"
            )
            error_details = error_payload.get("details")
            if not isinstance(error_details, dict):
                error_details = {}
            for src in (error_payload, nested_err):
                for key in ("code", "category", "retryable", "trace_id", "request_id"):
                    if key in src and key not in error_details:
                        error_details[key] = src[key]
            raise_for_status(
                response.status_code,
                str(error_message),
                error_details,
                endpoint,
            )

        content_type = str(response.headers.get("content-type", "")).lower()
        if "text/event-stream" in content_type:
            from .helpers.sse import parse_sse_text

            return parse_sse_text(response.text)

        from .helpers.core import _decode_json_or_b64_json

        result = _decode_json_or_b64_json(response.text)

        if not isinstance(result, dict):
            return {"result": result}

        # Kernel routes historically returned {success,data}; some modern
        # Warden control-plane routes return a decoded domain object directly.
        if result.get("success") is False:
            error_msg = result.get("error") or result.get("message") or "Unknown error"
            error_details = result.get("details")
            if not isinstance(error_details, dict):
                error_details = {}
            for key in ("code", "category", "retryable", "trace_id", "request_id"):
                if key in result:
                    error_details[key] = result[key]
            raise DominusError(str(error_msg), details=error_details, endpoint=endpoint)

        if result.get("success") is True:
            return result.get("data", {})
        if "data" in result and len(result) <= 3:
            return result.get("data", {})
        return result

    async def gateway_fetch(
        self,
        path: str,
        *,
        method: str = "GET",
        body: Optional[Dict[str, Any]] = None,
        headers: Optional[Dict[str, str]] = None,
        timeout: float = 30.0,
    ) -> Any:
        """Gateway `/svc/*` fetch with mixed JSON/base64 wire handling.

        Mirrors the Node SDK `DominusClient.gatewayFetch()` contract so Python
        callers can use the same remaining operator control-plane surfaces.
        """
        await self._ensure_ready()
        from .helpers.core import _ensure_valid_jwt
        jwt = await _ensure_valid_jwt(_TOKEN, _BASE_URL)

        path = path.strip()
        if not path.startswith("/"):
            path = f"/{path}"

        is_base64 = (
            "/svc/warden/secrets" in path
            or "/svc/secrets/" in path
            or "/svc/admin/" in path
        )
        decode_base64 = (
            is_base64
            or "/svc/database/" in path
            or "/svc/sync/" in path
            or "/svc/authority/" in path
        )
        is_get = method.upper() in {"GET", "HEAD"}

        from .helpers.trace import get_current_trace_id, get_current_span_id

        req_headers = {
            "Authorization": f"Bearer {jwt}",
            "X-Trace-Id": get_current_trace_id(),
            "X-Parent-Span-Id": get_current_span_id(),
        }
        if headers:
            req_headers.update(headers)

        request_content = None
        request_json = None
        if not is_get and body is not None:
            if is_base64:
                req_headers["Content-Type"] = "text/plain"
                request_content = base64.b64encode(json.dumps(body).encode()).decode()
            else:
                req_headers["Content-Type"] = "application/json"
                request_json = body

        try:
            async with httpx.AsyncClient(base_url=_GATEWAY_URL, headers=req_headers, timeout=timeout) as client:
                response = await client.request(
                    method.upper(),
                    path,
                    content=request_content,
                    json=request_json,
                )
        except httpx.TimeoutException as exc:
            raise DominusTimeoutError("Request timed out", endpoint=path) from exc
        except httpx.NetworkError as exc:
            raise DominusConnectionError(f"Request failed: {exc}", endpoint=path) from exc

        def _decode_error_payload(text: str) -> Dict[str, Any]:
            if not text:
                return {}
            try:
                from .helpers.core import _decode_json_or_b64_json

                decoded = _decode_json_or_b64_json(text)
                return decoded if isinstance(decoded, dict) else {"detail": decoded}
            except Exception:
                return {"detail": text}

        if response.is_error:
            error_payload = _decode_error_payload(response.text)
            nested = error_payload.get("error")
            nested_err: Dict[str, Any] = nested if isinstance(nested, dict) else {}
            error_message = (
                error_payload.get("message")
                or (nested_err.get("message") if nested_err else None)
                or (nested if isinstance(nested, str) else None)
                or error_payload.get("error")
                or error_payload.get("detail")
                or f"HTTP {response.status_code}"
            )
            error_details = error_payload.get("details")
            if not isinstance(error_details, dict):
                error_details = {}
            for src in (error_payload, nested_err):
                for key in ("code", "category", "retryable", "trace_id", "request_id"):
                    if key in src and key not in error_details:
                        error_details[key] = src[key]
            raise_for_status(response.status_code, str(error_message), error_details, path)

        text = response.text.strip()
        if not text:
            return {}

        if decode_base64:
            decoded = base64.b64decode(text.encode("utf-8")).decode("utf-8")
            result = json.loads(decoded)
        else:
            try:
                result = json.loads(text)
            except json.JSONDecodeError:
                return text

        if isinstance(result, dict) and result.get("success") is False:
            error_msg = result.get("error") or result.get("message") or "Unknown error"
            error_details = result.get("details")
            if not isinstance(error_details, dict):
                error_details = {}
            for key in ("code", "category", "retryable", "trace_id", "request_id"):
                if key in result:
                    error_details[key] = result[key]
            raise DominusError(str(error_msg), details=error_details, endpoint=path)

        return result

    async def _stream_request(
        self,
        endpoint: str,
        body: Optional[Dict[str, Any]] = None,
        on_chunk: Optional[Any] = None,
        timeout: float = 300.0,
        use_gateway: bool = True
    ):
        """
        Make an SSE streaming request to the Dominus service plane.

        Args:
            endpoint: API endpoint path (e.g., "/api/agent/stream")
            body: Request body (will be base64-encoded)
            on_chunk: Optional callback for each chunk
            timeout: Request timeout in seconds (default: 300s for long operations)
            use_gateway: If True, route through gateway (/api/* -> /svc/*)

        Yields:
            Parsed JSON chunks from SSE stream
        """
        # Base64 helpers
        def _b64_encode(d: dict) -> str:
            return base64.b64encode(json.dumps(d).encode()).decode()

        # Transform endpoint for gateway routing
        if use_gateway and endpoint.startswith("/api/"):
            endpoint = "/svc/" + endpoint[5:]

        # Validate and get JWT
        await self._ensure_ready()
        from .helpers.core import _ensure_valid_jwt
        jwt = await _ensure_valid_jwt(_TOKEN, _BASE_URL)

        from .helpers.trace import get_current_trace_id, get_current_span_id
        headers = {
            "Authorization": f"Bearer {jwt}",
            "Content-Type": "text/plain",
            "Accept": "text/event-stream",
            "X-Trace-Id": get_current_trace_id(),
            "X-Parent-Span-Id": get_current_span_id(),
        }

        body_b64 = _b64_encode(body or {})

        from .helpers.sse import stream_sse

        base_url = _GATEWAY_URL if use_gateway else _BASE_URL
        async with httpx.AsyncClient(base_url=base_url, timeout=timeout) as client:
            async with client.stream("POST", endpoint, content=body_b64, headers=headers) as response:
                response.raise_for_status()
                async for chunk in stream_sse(response, on_chunk):
                    yield chunk

    async def _binary_upload(
        self,
        endpoint: str,
        file_bytes: bytes,
        filename: str,
        content_type: str = "application/octet-stream",
        additional_fields: Optional[Dict[str, str]] = None,
        timeout: float = 60.0,
        use_gateway: bool = True
    ) -> Dict[str, Any]:
        """
        Upload binary file via multipart/form-data (no base64 encoding).

        Used for audio uploads (STT) and other binary file uploads.

        Args:
            endpoint: API endpoint path (e.g., "/api/agent/stt")
            file_bytes: Raw binary file content
            filename: Filename for the upload
            content_type: MIME type (default: application/octet-stream)
            additional_fields: Optional additional form fields
            timeout: Request timeout in seconds
            use_gateway: If True, route through gateway (/api/* -> /svc/*)

        Returns:
            Response data dict
        """
        # Transform endpoint for gateway routing
        if use_gateway and endpoint.startswith("/api/"):
            endpoint = "/svc/" + endpoint[5:]

        await self._ensure_ready()
        from .helpers.core import _ensure_valid_jwt
        jwt = await _ensure_valid_jwt(_TOKEN, _BASE_URL)

        from .helpers.trace import get_current_trace_id, get_current_span_id
        headers = {
            "Authorization": f"Bearer {jwt}",
            "X-Trace-Id": get_current_trace_id(),
            "X-Parent-Span-Id": get_current_span_id(),
        }

        # Build multipart form data
        files = {"file": (filename, file_bytes, content_type)}
        data = additional_fields or {}

        base_url = _GATEWAY_URL if use_gateway else _BASE_URL
        async with httpx.AsyncClient(base_url=base_url, headers=headers, timeout=timeout) as client:
            response = await client.post(endpoint, files=files, data=data)

        response.raise_for_status()

        from .helpers.core import _decode_json_or_b64_json

        result = _decode_json_or_b64_json(response.text)

        if isinstance(result, dict) and not result.get("success", True):
            error_msg = result.get("error", "Unknown error")
            raise RuntimeError(f"Upload error: {error_msg}")

        return result.get("data", result) if isinstance(result, dict) else result

    async def _binary_download(
        self,
        endpoint: str,
        body: Optional[Dict[str, Any]] = None,
        timeout: float = 60.0,
        use_gateway: bool = True
    ) -> bytes:
        """
        Download binary content (no base64 encoding in response).

        Used for TTS audio responses and other binary downloads.

        Args:
            endpoint: API endpoint path (e.g., "/api/agent/tts")
            body: Request body (will be base64-encoded for auth)
            timeout: Request timeout in seconds
            use_gateway: If True, route through gateway (/api/* -> /svc/*)

        Returns:
            Raw binary bytes
        """
        def _b64_encode(d: dict) -> str:
            return base64.b64encode(json.dumps(d).encode()).decode()

        # Transform endpoint for gateway routing
        if use_gateway and endpoint.startswith("/api/"):
            endpoint = "/svc/" + endpoint[5:]

        await self._ensure_ready()
        from .helpers.core import _ensure_valid_jwt
        jwt = await _ensure_valid_jwt(_TOKEN, _BASE_URL)

        from .helpers.trace import get_current_trace_id, get_current_span_id
        headers = {
            "Authorization": f"Bearer {jwt}",
            "Content-Type": "text/plain",
            "Accept": "audio/*",
            "X-Trace-Id": get_current_trace_id(),
            "X-Parent-Span-Id": get_current_span_id(),
        }

        body_b64 = _b64_encode(body or {})

        base_url = _GATEWAY_URL if use_gateway else _BASE_URL
        async with httpx.AsyncClient(base_url=base_url, headers=headers, timeout=timeout) as client:
            response = await client.post(endpoint, content=body_b64)

        response.raise_for_status()

        # Return raw binary content
        return response.content

    # ========================================
    # SECRETS (root level)
    # ========================================

    async def get(self, key: str) -> Any:
        """
        Get a secret value.

        Args:
            key: Secret key name

        Returns:
            Secret value
        """
        return await self._execute("secrets.get", key=key)

    async def upsert(self, key: str, value: str) -> Dict[str, Any]:
        """
        Create or update a secret.

        Args:
            key: Secret key name
            value: Secret value

        Returns:
            Operation result
        """
        return await self._execute("secrets.upsert", key=key, value=value)

    # ========================================
    # SQL DATA - APP SCHEMA (root level)
    # ========================================

    async def list_tables(self, schema: str = "app") -> List[Dict[str, Any]]:
        """List tables in the app schema (or specified schema)."""
        return await self._execute("sql.app.list_tables", schema=schema)

    async def query_table(
        self,
        table_name: str,
        schema: str = "app",
        filters: Optional[Dict[str, Any]] = None,
        sort_by: Optional[str] = None,
        sort_order: str = "ASC",
        limit: int = 100,
        offset: int = 0
    ) -> Dict[str, Any]:
        """Query table data from the app schema (default)."""
        return await self._execute(
            "sql.app.query_table",
            table_name=table_name,
            schema=schema,
            filters=filters,
            sort_by=sort_by,
            sort_order=sort_order,
            limit=limit,
            offset=offset
        )

    async def insert_row(
        self,
        table_name: str,
        data: Dict[str, Any],
        schema: str = "app"
    ) -> Dict[str, Any]:
        """Insert a row into a table in the app schema (default)."""
        return await self._execute(
            "sql.app.insert_row",
            table_name=table_name,
            data=data,
            schema=schema
        )

    async def update_rows(
        self,
        table_name: str,
        data: Dict[str, Any],
        filters: Dict[str, Any],
        schema: str = "app"
    ) -> Dict[str, Any]:
        """Update rows in a table in the app schema (default)."""
        return await self._execute(
            "sql.app.update_rows",
            table_name=table_name,
            data=data,
            filters=filters,
            schema=schema
        )

    async def delete_rows(
        self,
        table_name: str,
        filters: Dict[str, Any],
        schema: str = "app"
    ) -> Dict[str, Any]:
        """Delete rows from a table in the app schema (default)."""
        return await self._execute(
            "sql.app.delete_rows",
            table_name=table_name,
            filters=filters,
            schema=schema
        )

    async def list_columns(
        self,
        table_name: str,
        schema: str = "app"
    ) -> List[Dict[str, Any]]:
        """List columns in a table."""
        return await self._execute(
            "sql.app.list_columns",
            table_name=table_name,
            schema=schema
        )

    async def get_table_size(
        self,
        table_name: str,
        schema: str = "app"
    ) -> Dict[str, Any]:
        """Get table size information."""
        return await self._execute(
            "sql.app.get_table_size",
            table_name=table_name,
            schema=schema
        )

    # ========================================
    # SCHEMA DDL - APP SCHEMA (root level)
    # ========================================

    async def add_table(
        self,
        table_name: str,
        columns: List[Dict[str, Any]]
    ) -> Dict[str, Any]:
        """
        Create a new table in the app schema.

        Args:
            table_name: Name of table to create
            columns: List of column definitions
                [{"name": "id", "type": "UUID", "constraints": ["PRIMARY KEY"]}]
        """
        return await self._execute(
            "schema.add_table",
            table_name=table_name,
            columns=columns
        )

    async def delete_table(self, table_name: str) -> Dict[str, Any]:
        """Drop a table from the app schema."""
        return await self._execute(
            "schema.delete_table",
            table_name=table_name
        )

    async def ddl_list_tables(self) -> List[Dict[str, Any]]:
        """List all tables in the app schema (DDL view)."""
        return await self._execute("schema.list_tables")

    async def ddl_list_columns(self, table_name: str) -> List[Dict[str, Any]]:
        """List columns in a table (DDL view)."""
        return await self._execute(
            "schema.list_columns",
            table_name=table_name
        )

    async def add_column(
        self,
        table_name: str,
        column_name: str,
        column_type: str,
        constraints: Optional[List[str]] = None,
        default: Optional[str] = None
    ) -> Dict[str, Any]:
        """Add a column to a table in the app schema."""
        return await self._execute(
            "schema.add_column",
            table_name=table_name,
            column_name=column_name,
            column_type=column_type,
            constraints=constraints,
            default=default
        )

    async def delete_column(
        self,
        table_name: str,
        column_name: str
    ) -> Dict[str, Any]:
        """Drop a column from a table in the app schema."""
        return await self._execute(
            "schema.delete_column",
            table_name=table_name,
            column_name=column_name
        )

    # ========================================
    # AUTH - SCOPES (root level)
    # ========================================

    async def add_scope(
        self,
        slug: str,
        display_name: str,
        tenant_category_id: int,
        description: Optional[str] = None
    ) -> Dict[str, Any]:
        """Add a new scope."""
        return await self._execute(
            "auth.add_scope",
            slug=slug,
            display_name=display_name,
            tenant_category_id=tenant_category_id,
            description=description
        )

    async def delete_scope(self, scope_id: str) -> Dict[str, Any]:
        """Delete a scope by ID."""
        return await self._execute("auth.delete_scope", scope_id=scope_id)

    async def list_scopes(
        self,
        tenant_category_id: Optional[int] = None
    ) -> List[Dict[str, Any]]:
        """List all scopes, optionally filtered by category."""
        return await self._execute(
            "auth.list_scopes",
            tenant_category_id=tenant_category_id
        )

    async def get_scope(
        self,
        scope_id: Optional[str] = None,
        slug: Optional[str] = None
    ) -> Dict[str, Any]:
        """Get a scope by ID or slug."""
        return await self._execute(
            "auth.get_scope",
            scope_id=scope_id,
            slug=slug
        )

    # ========================================
    # AUTH - ROLES (root level)
    # ========================================

    async def add_role(
        self,
        name: str,
        scope_slugs: Optional[List[str]] = None,
        description: Optional[str] = None,
        role_type: str = "user"
    ) -> Dict[str, Any]:
        """Add a new role."""
        return await self._execute(
            "auth.add_role",
            name=name,
            scope_slugs=scope_slugs or [],
            description=description,
            role_type=role_type
        )

    async def delete_role(self, role_id: str) -> Dict[str, Any]:
        """Delete a role by ID."""
        return await self._execute("auth.delete_role", role_id=role_id)

    async def list_roles(self) -> List[Dict[str, Any]]:
        """List all roles for the tenant."""
        return await self._execute("auth.list_roles")

    async def get_role(
        self,
        role_id: Optional[str] = None,
        name: Optional[str] = None
    ) -> Dict[str, Any]:
        """Get a role by ID or name."""
        return await self._execute(
            "auth.get_role",
            role_id=role_id,
            name=name
        )

    async def update_role_scopes(
        self,
        role_id: str,
        scope_slugs: List[str]
    ) -> Dict[str, Any]:
        """Update the scopes assigned to a role."""
        return await self._execute(
            "auth.update_role_scopes",
            role_id=role_id,
            scope_slugs=scope_slugs
        )

    # ========================================
    # AUTH - USERS (root level)
    # ========================================

    async def add_user(
        self,
        username: str,
        password: str,
        role_id: str,
        email: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Add a new user.

        Password is hashed client-side before sending to Architect.
        """
        from .helpers.crypto import hash_password
        password_hash = hash_password(password)
        return await self._execute(
            "auth.add_user",
            username=username,
            password_hash=password_hash,
            role_id=role_id,
            email=email
        )

    async def delete_user(self, user_id: str) -> Dict[str, Any]:
        """Delete a user by ID."""
        return await self._execute("auth.delete_user", user_id=user_id)

    async def list_users(self) -> List[Dict[str, Any]]:
        """List all users for the tenant."""
        return await self._execute("auth.list_users")

    async def get_user(
        self,
        user_id: Optional[str] = None,
        username: Optional[str] = None
    ) -> Dict[str, Any]:
        """Get a user by ID or username."""
        return await self._execute(
            "auth.get_user",
            user_id=user_id,
            username=username
        )

    async def update_user_status(
        self,
        user_id: str,
        status: str
    ) -> Dict[str, Any]:
        """Update a user's status (active, inactive, suspended)."""
        return await self._execute(
            "auth.update_user_status",
            user_id=user_id,
            status=status
        )

    async def update_user_role(
        self,
        user_id: str,
        role_id: str
    ) -> Dict[str, Any]:
        """Update a user's assigned role."""
        return await self._execute(
            "auth.update_user_role",
            user_id=user_id,
            role_id=role_id
        )

    async def verify_user_password(
        self,
        username: str,
        password: str
    ) -> Dict[str, Any]:
        """
        Verify a user's password.

        Raw password is sent to Architect which does bcrypt comparison.
        """
        return await self._execute(
            "auth.verify_user_password",
            username=username,
            password=password
        )

    # ========================================
    # AUTH - CLIENTS / PSK (root level)
    # ========================================

    async def add_client(
        self,
        label: str,
        role_id: str
    ) -> Dict[str, Any]:
        """
        Add a new service client with PSK.

        Returns {"client": {...}, "psk": "raw-psk-one-time-visible"}
        """
        from .helpers.crypto import hash_psk, generate_psk_local
        raw_psk = generate_psk_local()
        psk_hash = hash_psk(raw_psk)
        client_result = await self._execute(
            "auth.add_client",
            label=label,
            role_id=role_id,
            psk_hash=psk_hash
        )
        return {
            "client": client_result,
            "psk": raw_psk  # One-time visible
        }

    async def delete_client(self, client_id: str) -> Dict[str, Any]:
        """Delete a client by ID."""
        return await self._execute("auth.delete_client", client_id=client_id)

    async def list_clients(self) -> List[Dict[str, Any]]:
        """List all clients for the tenant."""
        return await self._execute("auth.list_clients")

    async def get_client(self, client_id: str) -> Dict[str, Any]:
        """Get a client by ID."""
        return await self._execute("auth.get_client", client_id=client_id)

    async def regenerate_client_psk(self, client_id: str) -> Dict[str, Any]:
        """
        Regenerate a client's PSK.

        Returns {"client": {...}, "psk": "new-raw-psk-one-time-visible"}
        """
        from .helpers.crypto import hash_psk, generate_psk_local
        raw_psk = generate_psk_local()
        psk_hash = hash_psk(raw_psk)
        client_result = await self._execute(
            "auth.regenerate_client_psk",
            client_id=client_id,
            psk_hash=psk_hash
        )
        return {
            "client": client_result,
            "psk": raw_psk
        }

    async def verify_client_psk(
        self,
        client_id: str,
        psk: str
    ) -> Dict[str, Any]:
        """
        Verify a client's PSK.

        Raw PSK is sent to Architect which does bcrypt comparison.
        """
        return await self._execute(
            "auth.verify_client_psk",
            client_id=client_id,
            psk=psk
        )

    # ========================================
    # AUTH - REFRESH TOKENS (root level)
    # ========================================

    async def add_refresh_token(
        self,
        user_id: Optional[str] = None,
        client_psk_id: Optional[str] = None,
        expires_in_seconds: int = 86400 * 30  # 30 days
    ) -> Dict[str, Any]:
        """
        Create a new refresh token.

        Either user_id or client_psk_id must be provided.
        Returns {"token_id": "...", "token": "raw-token-one-time-visible"}
        """
        from .helpers.crypto import hash_token, generate_token
        raw_token = generate_token()
        token_hash = hash_token(raw_token)

        result = await self._execute(
            "auth.add_refresh_token",
            user_id=user_id,
            client_psk_id=client_psk_id,
            token_hash=token_hash,
            expires_in_seconds=expires_in_seconds
        )
        return {
            "token_id": result.get("id"),
            "token": raw_token,
            "expires_at": result.get("expires_at")
        }

    async def delete_refresh_token(self, token_id: str) -> Dict[str, Any]:
        """Delete/revoke a refresh token."""
        return await self._execute(
            "auth.delete_refresh_token",
            token_id=token_id
        )

    async def list_refresh_tokens(
        self,
        user_id: Optional[str] = None,
        client_psk_id: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        """List refresh tokens, optionally filtered by user or client."""
        return await self._execute(
            "auth.list_refresh_tokens",
            user_id=user_id,
            client_psk_id=client_psk_id
        )

    # ========================================
    # AUTH - JWT OPERATIONS (root level)
    # ========================================

    async def mint_jwt(
        self,
        user_id: str,
        scope: Optional[List[str]] = None,
        expires_in: int = 900,
        system: str = "user"
    ) -> Dict[str, Any]:
        """
        Mint a JWT for a subsidiary user.

        Returns {"access_token": "...", "token_type": "Bearer", "expires_in": ...}
        """
        return await self._execute(
            "auth.mint",
            user_id=user_id,
            scope=scope,
            system=system
        )

    async def get_public_key(self) -> Dict[str, Any]:
        """Get gateway JWKS for JWT validation (cached)."""
        if self._public_key_cache:
            return self._public_key_cache

        result = await self._execute("auth.jwks")
        self._public_key_cache = result
        return self._public_key_cache

    async def validate_jwt(self, token: str) -> Dict[str, Any]:
        """
        Validate a JWT and return its claims.

        Decodes the JWT payload and checks expiration.
        Matches JS SDK behavior (decode + expiration check).

        Raises ValueError if token is invalid or expired.
        """
        import base64
        import json
        import time

        # Decode JWT without cryptographic verification (matches JS SDK)
        parts = token.split('.')
        if len(parts) != 3:
            raise ValueError("Invalid JWT format")

        try:
            # Decode payload (base64url)
            payload_b64 = parts[1]
            # Add padding if needed
            padding = 4 - len(payload_b64) % 4
            if padding != 4:
                payload_b64 += '=' * padding
            # Replace URL-safe characters
            payload_b64 = payload_b64.replace('-', '+').replace('_', '/')
            payload_bytes = base64.b64decode(payload_b64)
            claims = json.loads(payload_bytes.decode('utf-8'))

            # Check expiration
            exp = claims.get("exp")
            if exp and exp < int(time.time()):
                raise ValueError("Token has expired")

            return claims
        except ValueError:
            raise
        except Exception as e:
            raise ValueError(f"Invalid token: {e}")

    # ========================================
    # STRING-BASED API (backward compatible)
    # ========================================

    async def __call__(self, command: str, **kwargs) -> Any:
        """
        String-based command execution for the supported flat shortcuts.

        Examples:
            await dominus("health.check")
            await dominus("secrets.get", key="DATABASE_URL")
            await dominus("sql.app.list_tables", schema="public")
        """
        await self._ensure_ready()
        return await self._dispatch_flat_command(command, **kwargs)


# Create singleton instance
dominus = Dominus()
