"""CLI entry point for daylily-tapdb."""

import importlib.util
import inspect
import json
import os
import secrets
import shutil
import signal
import socket
import subprocess
import sys
import time
from pathlib import Path
from typing import Optional

from cli_core_yo import ccyo_out
from cli_core_yo.app import create_app

from daylily_tapdb.cli._registry_v2 import help_text, policy_for_command
from daylily_tapdb.cli.context import (
    TapdbContext,
    active_context_overrides,
    clear_cli_context,
    resolve_context,
    set_cli_context,
)
from daylily_tapdb.cli.db_config import validate_postgres_identifier_component
from daylily_tapdb.cli.output import print_renderable
from daylily_tapdb.cli.spec import spec
from daylily_tapdb.governance import normalize_owner_repo_name

DEFAULT_UI_PORT = 8911
DEFAULT_UI_HOST = "localhost"
DEFAULT_UI_SCHEME = "https"
# UI runtime paths are derived from the active TapDB namespace context.
PID_FILE = Path.home() / ".tapdb" / "ui.pid"
LOG_FILE = Path.home() / ".tapdb" / "ui.log"


def _require_context() -> TapdbContext:
    return resolve_context(require_keys=True)


def _ui_runtime_paths() -> tuple[Path, Path, Path]:
    ctx = _require_context()
    ui_dir = ctx.ui_dir()
    return (
        ui_dir / "ui.pid",
        ui_dir / "ui.log",
        ui_dir / "certs",
    )


def _resolve_tls_paths(
    *,
    cert_file: Optional[Path] = None,
    key_file: Optional[Path] = None,
) -> tuple[Path, Path]:
    """Resolve TLS cert/key paths from CLI overrides, config, or runtime defaults."""
    from daylily_tapdb.cli.db_config import get_admin_settings

    pid_file, _, certs_dir = _ui_runtime_paths()
    _ = pid_file  # path access validates context + env
    default_cert = certs_dir / "localhost.crt"
    default_key = certs_dir / "localhost.key"
    admin_settings = get_admin_settings()
    if cert_file is not None:
        cert = cert_file.expanduser()
    elif admin_settings.get("tls_cert_path"):
        cert = Path(str(admin_settings["tls_cert_path"])).expanduser()
    else:
        cert = default_cert

    if key_file is not None:
        key = key_file.expanduser()
    elif admin_settings.get("tls_key_path"):
        key = Path(str(admin_settings["tls_key_path"])).expanduser()
    else:
        key = default_key
    return cert, key


def _ensure_tls_certificates(
    host: str,
    *,
    cert_file: Optional[Path] = None,
    key_file: Optional[Path] = None,
) -> tuple[Path, Path]:
    """Ensure TLS cert/key exist for HTTPS UI startup."""
    cert_path, key_path = _resolve_tls_paths(
        cert_file=cert_file,
        key_file=key_file,
    )
    if cert_path.exists() and key_path.exists():
        return cert_path, key_path

    cert_path.parent.mkdir(parents=True, exist_ok=True)
    key_path.parent.mkdir(parents=True, exist_ok=True)
    openssl = shutil.which("openssl")
    if not openssl:
        raise RuntimeError(
            "openssl is required to start the UI over HTTPS. "
            "Install openssl or set admin.ui.tls.cert_path/admin.ui.tls.key_path."
        )

    san = "DNS:localhost"
    if host and host != "localhost":
        san = f"{san},DNS:{host}"
    cmd = [
        openssl,
        "req",
        "-x509",
        "-newkey",
        "rsa:2048",
        "-sha256",
        "-days",
        "3650",
        "-nodes",
        "-subj",
        "/CN=localhost",
        "-addext",
        f"subjectAltName={san}",
        "-keyout",
        str(key_path),
        "-out",
        str(cert_path),
    ]
    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode != 0:
        msg = (result.stderr or result.stdout or "").strip()
        raise RuntimeError(f"Failed to generate TLS certificate with openssl: {msg}")

    try:
        os.chmod(key_path, 0o600)
    except OSError:
        pass
    return cert_path, key_path


def _get_pid(pid_file: Path) -> Optional[int]:
    """Get the running UI server PID if exists."""
    if pid_file.exists():
        try:
            pid = int(pid_file.read_text().strip())
            # Check if process is running
            os.kill(pid, 0)
            return pid
        except (ValueError, ProcessLookupError, PermissionError):
            pid_file.unlink(missing_ok=True)
    return None


def _port_is_available(host: str, port: int) -> bool:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.settimeout(0.5)
        return sock.connect_ex((host, port)) != 0


def _port_conflict_details(port: int) -> str:
    try:
        proc = subprocess.run(
            ["lsof", "-nP", f"-iTCP:{port}", "-sTCP:LISTEN"],
            capture_output=True,
            text=True,
            timeout=2,
        )
    except Exception:
        return "port is already in use by another process"
    if proc.returncode != 0 or not (proc.stdout or "").strip():
        return "port is already in use by another process"
    lines = [ln.strip() for ln in proc.stdout.splitlines() if ln.strip()]
    if len(lines) < 2:
        return "port is already in use by another process"
    first = lines[1]
    return f"port {port} is in use ({first})"


def _find_admin_module() -> str:
    """Find the admin module path."""
    cwd_admin = Path.cwd() / "admin"
    if cwd_admin.exists() and (cwd_admin / "main.py").exists():
        return "admin.main:app"

    pkg_admin = Path(__file__).parent.parent.parent / "admin"
    if pkg_admin.exists() and (pkg_admin / "main.py").exists():
        return "admin.main:app"

    raise ValueError(
        "Cannot find admin module. Run from the daylily-tapdb"
        " repo root, or ensure admin/ is installed."
    )


def _require_admin_extras() -> None:
    """Fail fast with a clear message if Admin UI extras aren't installed."""
    # Fail early with a clear, actionable list.
    # Note: python-multipart installs module name `multipart`.
    required = ["fastapi", "uvicorn", "jinja2", "multipart", "itsdangerous", "passlib"]
    missing = [m for m in required if importlib.util.find_spec(m) is None]
    if missing:
        print("Admin UI dependencies are not installed.", file=sys.stderr)
        print(f"Missing modules: {', '.join(missing)}", file=sys.stderr)
        print("Install with: pip install 'daylily-tapdb[admin]'", file=sys.stderr)
        raise SystemExit(1)


def build_app():
    """Build the Typer app.

    Lazy-imports CLI deps so core installs can import daylily_tapdb.
    """
    import typer
    from rich.table import Table

    # Import subcommand modules (require Typer/Rich)
    from daylily_tapdb.cli.cognito import cognito_app
    from daylily_tapdb.cli.db import (
        Environment as DbEnvironment,
    )
    from daylily_tapdb.cli.db import (
        _create_default_admin,
        apply_schema,
        create_database,
        db_app,
        run_migrations,
        seed_templates,
    )
    from daylily_tapdb.cli.pg import pg_app, pg_init, pg_start_local
    from daylily_tapdb.cli.user import user_app

    app = typer.Typer(
        name="tapdb",
        help="TAPDB - Templated Abstract Polymorphic Database CLI",
        add_completion=True,
    )

    @app.callback()
    def _root_callback(
        ctx: typer.Context,
        client_id: Optional[str] = typer.Option(
            None,
            "--client-id",
            help="Namespace metadata key for config init/migration flows.",
        ),
        database_name: Optional[str] = typer.Option(
            None,
            "--database-name",
            help="Namespace metadata key for config init/migration flows.",
        ),
        config_path: Optional[Path] = typer.Option(
            None,
            "--config",
            exists=False,
            file_okay=True,
            dir_okay=False,
            readable=False,
            help="Explicit TapDB config file path for this invocation.",
        ),
    ):
        """Prepare explicit invocation context for tests and embedding."""
        if ctx.resilient_parsing:
            return
        try:
            from cli_core_yo.runtime import _reset

            _reset()
        except Exception:
            pass
        prior_context = active_context_overrides()
        set_cli_context(
            client_id=(
                client_id if client_id is not None else prior_context.get("client_id")
            ),
            database_name=(
                database_name
                if database_name is not None
                else prior_context.get("database_name")
            ),
            config_path=(
                config_path
                if config_path is not None
                else prior_context.get("config_path")
            ),
        )

    bootstrap_app = typer.Typer(help="One-command environment bootstrap")
    ui_app = typer.Typer(help="Admin UI server management commands")
    config_root_app = typer.Typer(help="TAPDB config namespace commands")
    app.add_typer(bootstrap_app, name="bootstrap")
    app.add_typer(ui_app, name="ui")
    app.add_typer(config_root_app, name="config")
    app.add_typer(db_app, name="db")
    app.add_typer(pg_app, name="pg")
    app.add_typer(user_app, name="users")
    app.add_typer(cognito_app, name="cognito")

    # Aurora subcommand — always visible, but requires boto3
    _has_boto3 = False
    try:
        import importlib.util as _ilu

        _has_boto3 = _ilu.find_spec("boto3") is not None
    except Exception:
        pass

    if _has_boto3:
        from daylily_tapdb.cli.aurora import aurora_app

        app.add_typer(aurora_app, name="aurora")
    else:
        aurora_stub = typer.Typer(
            help="Aurora PostgreSQL management (requires boto3)",
        )

        @aurora_stub.callback(invoke_without_command=True)
        def _aurora_missing(ctx: typer.Context):
            ccyo_out.error("boto3 is required for Aurora commands.")
            ccyo_out.print_text(
                "  Install with: [cyan]pip install 'daylily-tapdb[aurora]'[/cyan]"
            )
            raise typer.Exit(1)

        app.add_typer(aurora_stub, name="aurora")

    @ui_app.command("start")
    def ui_start(
        port: Optional[int] = typer.Option(
            None,
            "--port",
            "-p",
            help="Port to run the server on (defaults to target.ui_port)",
        ),
        host: str = typer.Option(
            DEFAULT_UI_HOST, "--host", "-h", help="Host to bind to"
        ),
        reload: bool = typer.Option(False, "--reload", "-r", help="Enable auto-reload"),
        background: bool = typer.Option(
            True, "--background/--foreground", "-b/-f", help="Run in background"
        ),
        ssl_certfile: Optional[Path] = typer.Option(
            None,
            "--ssl-certfile",
            help="Explicit TLS certificate path for this invocation",
        ),
        ssl_keyfile: Optional[Path] = typer.Option(
            None,
            "--ssl-keyfile",
            help="Explicit TLS private key path for this invocation",
        ),
    ):
        """Start the TAPDB Admin UI server."""
        from daylily_tapdb.cli.db_config import get_config_path, get_db_config

        pid_file, log_file, _ = _ui_runtime_paths()
        pid_file.parent.mkdir(parents=True, exist_ok=True)
        log_file.parent.mkdir(parents=True, exist_ok=True)

        cfg = get_db_config()
        configured_port = int(str(cfg.get("ui_port") or DEFAULT_UI_PORT))
        if port is None:
            port = configured_port
        elif port != configured_port:
            ccyo_out.error("UI port override is not allowed in strict mode.")
            ccyo_out.print_text(
                f"  Configured target.ui_port: [cyan]{configured_port}[/cyan]"
            )
            raise typer.Exit(1)

        try:
            _require_admin_extras()
        except SystemExit:
            ccyo_out.error("Admin UI dependencies are not installed.")
            ccyo_out.print_text(
                "  Install with: [cyan]pip install 'daylily-tapdb[admin]'[/cyan]"
            )
            raise typer.Exit(1)

        pid = _get_pid(pid_file)
        if pid:
            ccyo_out.warning(f"UI server already running (PID {pid})")
            ccyo_out.print_text(
                f"   URL: [cyan]{DEFAULT_UI_SCHEME}://{host}:{port}[/cyan]"
            )
            ccyo_out.print_text(f"   PID file: [dim]{pid_file}[/dim]")
            return

        if not _port_is_available(host, port):
            ccyo_out.error(f"{_port_conflict_details(port)}")
            ns = _require_context().namespace_slug()
            ccyo_out.print_text(f"  Namespace: [dim]{ns}[/dim]")
            ccyo_out.print_text(
                "  Update target.ui_port in the namespaced config to a free port."
            )
            raise typer.Exit(1)

        try:
            cert_path, key_path = _ensure_tls_certificates(
                host,
                cert_file=ssl_certfile,
                key_file=ssl_keyfile,
            )
        except RuntimeError as e:
            ccyo_out.error(f"{e}")
            raise typer.Exit(1)

        effective_config_path = get_config_path()
        cmd = [
            sys.executable,
            "-m",
            "daylily_tapdb.cli.admin_server",
            "--config",
            str(effective_config_path),
            "--host",
            host,
            "--port",
            str(port),
            "--ssl-keyfile",
            str(key_path),
            "--ssl-certfile",
            str(cert_path),
        ]
        if reload:
            cmd.append("--reload")

        if background:
            with open(log_file, "w") as log_f:
                proc = subprocess.Popen(
                    cmd,
                    stdout=log_f,
                    stderr=subprocess.STDOUT,
                    start_new_session=True,
                )

            time.sleep(1)
            if proc.poll() is not None:
                ccyo_out.error("Server failed to start. Check logs:")
                ccyo_out.print_text(f"   [dim]{log_file}[/dim]")
                raise typer.Exit(1)

            pid_file.write_text(str(proc.pid))
            ccyo_out.success(f"UI server started (PID {proc.pid})")
            ccyo_out.print_text(
                f"   URL: [cyan]{DEFAULT_UI_SCHEME}://{host}:{port}[/cyan]"
            )
            ccyo_out.print_text(f"   Logs: [dim]{log_file}[/dim]")
            ccyo_out.print_text(f"   PID:  [dim]{pid_file}[/dim]")
        else:
            ccyo_out.success(
                f"Starting UI server on {DEFAULT_UI_SCHEME}://{host}:{port}"
            )
            ccyo_out.print_text("   Press Ctrl+C to stop\n")
            try:
                subprocess.run(cmd)
            except KeyboardInterrupt:
                ccyo_out.warning("\nServer stopped")

    @ui_app.command("mkcert")
    def ui_mkcert(
        cert_file: Optional[Path] = typer.Option(
            None,
            "--cert-file",
            help="Path to write mkcert-generated TLS certificate",
        ),
        key_file: Optional[Path] = typer.Option(
            None,
            "--key-file",
            help="Path to write mkcert-generated TLS private key",
        ),
    ):
        """Install mkcert local CA and generate localhost TLS certs for the UI."""
        mkcert = shutil.which("mkcert")
        if not mkcert:
            ccyo_out.error("mkcert is required for trusted local HTTPS certs.")
            ccyo_out.print_text(
                "  Install mkcert first, then rerun [cyan]tapdb ui mkcert[/cyan]."
            )
            raise typer.Exit(1)

        default_cert, default_key = _resolve_tls_paths()
        cert_path = (cert_file or default_cert).expanduser()
        key_path = (key_file or default_key).expanduser()
        cert_path.parent.mkdir(parents=True, exist_ok=True)
        key_path.parent.mkdir(parents=True, exist_ok=True)

        install_cmd = [mkcert, "-install"]
        install_result = subprocess.run(install_cmd, capture_output=True, text=True)
        if install_result.returncode != 0:
            msg = (install_result.stderr or install_result.stdout or "").strip()
            ccyo_out.error("Failed to install mkcert local CA.")
            if msg:
                ccyo_out.print_text(f"  [dim]{msg}[/dim]")
            raise typer.Exit(1)

        generate_cmd = [
            mkcert,
            "-cert-file",
            str(cert_path),
            "-key-file",
            str(key_path),
            "localhost",
        ]
        generate_result = subprocess.run(generate_cmd, capture_output=True, text=True)
        if generate_result.returncode != 0:
            msg = (generate_result.stderr or generate_result.stdout or "").strip()
            ccyo_out.error("Failed to generate mkcert TLS files.")
            if msg:
                ccyo_out.print_text(f"  [dim]{msg}[/dim]")
            raise typer.Exit(1)

        try:
            os.chmod(key_path, 0o600)
        except OSError:
            pass

        ccyo_out.success("mkcert certificate ready for TAPDB UI HTTPS")
        ccyo_out.print_text(f"   Cert: [dim]{cert_path}[/dim]")
        ccyo_out.print_text(f"   Key:  [dim]{key_path}[/dim]")
        ccyo_out.print_text(
            "   Restart UI: [cyan]tapdb --config <path> ui restart[/cyan]"
        )

    @ui_app.command("stop")
    def ui_stop():
        """Stop the TAPDB Admin UI server."""
        pid_file, _, _ = _ui_runtime_paths()
        pid = _get_pid(pid_file)
        if not pid:
            ccyo_out.warning("No UI server running")
            return

        try:
            os.kill(pid, signal.SIGTERM)
            for _ in range(10):
                time.sleep(0.5)
                try:
                    os.kill(pid, 0)
                except ProcessLookupError:
                    break
            else:
                os.kill(pid, signal.SIGKILL)

            pid_file.unlink(missing_ok=True)
            ccyo_out.success(f"UI server stopped (was PID {pid})")
        except ProcessLookupError:
            pid_file.unlink(missing_ok=True)
            ccyo_out.warning("Server was not running")
        except PermissionError:
            ccyo_out.error(f"Permission denied stopping PID {pid}")
            raise typer.Exit(1)

    @ui_app.command("status")
    def ui_status():
        """Check the status of the TAPDB Admin UI server."""
        pid_file, log_file, _ = _ui_runtime_paths()
        pid = _get_pid(pid_file)
        if pid:
            ccyo_out.success(f"UI server is running (PID {pid})")
            ccyo_out.print_text(f"   Logs: [dim]{log_file}[/dim]")
            ccyo_out.print_text(f"   PID:  [dim]{pid_file}[/dim]")
        else:
            ccyo_out.print_text("UI server is [dim]not running[/dim]")

    @ui_app.command("logs")
    def ui_logs(
        follow: bool = typer.Option(
            True,
            "--follow/--no-follow",
            "-f/-F",
            help="Follow log output (default: true)",
        ),
        lines: int = typer.Option(50, "--lines", "-n", help="Number of lines to show"),
    ):
        """View TAPDB Admin UI server logs (tails by default, Ctrl+C to stop)."""
        _, log_file, _ = _ui_runtime_paths()
        if not log_file.exists():
            ccyo_out.warning("No log file found. Start the server first.")
            return

        if follow:
            ccyo_out.print_text(f"[dim]Following {log_file} (Ctrl+C to stop)[/dim]\n")
            try:
                subprocess.run(["tail", "-f", "-n", str(lines), str(log_file)])
            except KeyboardInterrupt:
                ccyo_out.print_text("\n[dim]Stopped.[/dim]")
        else:
            try:
                with open(log_file, "r") as f:
                    all_lines = f.readlines()
                    for line in all_lines[-lines:]:
                        ccyo_out.print_text(line.rstrip())
            except Exception as e:
                ccyo_out.error(f"Error reading logs: {e}")

    @ui_app.command("restart")
    def ui_restart(
        port: Optional[int] = typer.Option(
            None, "--port", "-p", help="Port to run the server on"
        ),
        host: str = typer.Option(
            DEFAULT_UI_HOST, "--host", "-h", help="Host to bind to"
        ),
    ):
        """Restart the TAPDB Admin UI server."""
        ui_stop()
        time.sleep(1)
        ui_start(
            port=port,
            host=host,
            reload=False,
            background=True,
            ssl_certfile=None,
            ssl_keyfile=None,
        )

    def _resolve_bootstrap_env() -> DbEnvironment:
        return DbEnvironment.target

    def _maybe_start_ui_after_bootstrap(no_gui: bool) -> None:
        from daylily_tapdb.cli.db_config import get_db_config

        if no_gui:
            ccyo_out.print_text("  UI start skipped (--no-gui)")
            return
        cfg = get_db_config()
        ui_port = int(str(cfg.get("ui_port") or DEFAULT_UI_PORT))
        try:
            ui_start(
                port=ui_port,
                host=DEFAULT_UI_HOST,
                reload=False,
                background=True,
                ssl_certfile=None,
                ssl_keyfile=None,
            )
        except Exception as e:
            ccyo_out.error(f"DB is ready, but UI start failed: {e}")
            ccyo_out.print_text(
                "  Recover with: "
                f"[cyan]tapdb --config <path> ui start --background --port {ui_port}[/cyan]"
            )

    @bootstrap_app.command("local")
    def bootstrap_local(
        no_gui: bool = typer.Option(
            False, "--no-gui", help="Skip starting TAPDB Admin UI"
        ),
        include_workflow: bool = typer.Option(
            False,
            "--include-workflow",
            "-w",
            help="Include optional non-core templates if present in config",
        ),
        insecure_dev_defaults: bool = typer.Option(
            False,
            "--insecure-dev-defaults",
            help="LOCAL/SHARED ONLY: create default admin user (tapdb_admin/passw0rd)",
        ),
    ):
        """Bootstrap local TAPDB runtime, database, schema, and seed data."""
        from daylily_tapdb.cli.db_config import get_db_config

        env = _resolve_bootstrap_env()
        cfg = get_db_config()
        if cfg.get("engine_type") == "aurora":
            ccyo_out.error("Active target is Aurora; use bootstrap aurora")
            raise typer.Exit(1)

        ccyo_out.print_text(
            "\n[bold cyan]━━━ Bootstrap Local (explicit target) ━━━[/bold cyan]"
        )

        ccyo_out.print_text("\n[bold]Step 1/6: Ensure local PostgreSQL runtime[/bold]")
        pg_init(force=False)
        pg_start_local(port=None)

        ccyo_out.print_text("\n[bold]Step 2/6: Ensure database exists[/bold]")
        create_database(env=env, owner=None)

        ccyo_out.print_text("\n[bold]Step 3/6: Apply schema[/bold]")
        apply_schema(env=env, reinitialize=False)

        ccyo_out.print_text("\n[bold]Step 4/6: Run migrations[/bold]")
        run_migrations(env=env, dry_run=False)

        ccyo_out.print_text("\n[bold]Step 5/6: Seed templates[/bold]")
        seed_templates(
            env=env,
            config_path=None,
            include_workflow=include_workflow,
            skip_existing=True,
            dry_run=False,
        )

        ccyo_out.print_text("\n[bold]Step 6/6: Ensure admin user[/bold]")
        _create_default_admin(env=env, insecure_dev_defaults=insecure_dev_defaults)

        ccyo_out.print_text("\n[bold]UI startup[/bold]")
        _maybe_start_ui_after_bootstrap(no_gui=no_gui)

        ccyo_out.success("\n✓ Local bootstrap complete")

    @bootstrap_app.command("aurora")
    def bootstrap_aurora(
        cluster: str = typer.Option(
            ...,
            "--cluster",
            help="Aurora cluster identifier to provision/reuse",
        ),
        region: str = typer.Option("us-west-2", "--region", "-r", help="AWS region"),
        vpc_id: str = typer.Option("", "--vpc-id", help="VPC ID to deploy into"),
        cidr: Optional[str] = typer.Option(
            None,
            "--cidr",
            help=(
                "Ingress CIDR for Aurora security group. Defaults to the current "
                "public IP (/32) when --publicly-accessible is set, otherwise "
                "10.0.0.0/8."
            ),
        ),
        publicly_accessible: bool = typer.Option(
            False,
            "--publicly-accessible/--no-publicly-accessible",
            help="Whether the Aurora writer instance is publicly accessible",
        ),
        no_gui: bool = typer.Option(
            False, "--no-gui", help="Skip starting TAPDB Admin UI"
        ),
        include_workflow: bool = typer.Option(
            False,
            "--include-workflow",
            "-w",
            help="Include optional non-core templates if present in config",
        ),
        insecure_dev_defaults: bool = typer.Option(
            False,
            "--insecure-dev-defaults",
            help="LOCAL/SHARED ONLY: create default admin user (tapdb_admin/passw0rd)",
        ),
    ):
        """Bootstrap Aurora TAPDB stack (infra + DB + schema + seed + optional UI)."""
        from daylily_tapdb.aurora.config import AuroraConfig
        from daylily_tapdb.aurora.stack_manager import AuroraStackManager
        from daylily_tapdb.cli.aurora import _ensure_boto3, _resolve_ingress_cidr

        _ensure_boto3()
        env = _resolve_bootstrap_env()
        stack_name = cluster

        ccyo_out.print_text(
            f"\n[bold cyan]━━━ Bootstrap Aurora (explicit target -> {cluster})"
            " ━━━[/bold cyan]"
        )

        ccyo_out.print_text("\n[bold]Step 1/8: Verify explicit TapDB config[/bold]")
        config_path = _ensure_bootstrap_config_for_aurora()
        ccyo_out.success(f"  Config ready: {config_path}")

        ccyo_out.print_text("\n[bold]Step 2/8: Ensure Aurora cluster[/bold]")
        try:
            resolved_cidr = _resolve_ingress_cidr(cidr, publicly_accessible)
        except RuntimeError as exc:
            ccyo_out.error(str(exc))
            raise typer.Exit(1)
        ccyo_out.print_text(f"  Ingress CIDR: {resolved_cidr}")
        desired_stack = AuroraConfig(
            region=region,
            cluster_identifier=cluster,
            instance_class="db.r6g.large",
            engine_version="16.6",
            vpc_id=vpc_id,
            cidr=resolved_cidr,
            iam_auth=True,
            publicly_accessible=publicly_accessible,
            deletion_protection=True,
            tags={
                "lsmc-cost-center": "global",
                "lsmc-project": f"tapdb-{region}",
            },
        )
        mgr = AuroraStackManager(region=region)
        try:
            mgr.get_stack_status(stack_name)
            info = mgr.update_stack(desired_stack)
            ccyo_out.success(f"  Reconciled existing stack {stack_name}")
        except RuntimeError as exc:
            if "not found" not in str(exc).lower():
                ccyo_out.error(f"Aurora stack reconciliation failed: {exc}")
                raise typer.Exit(1)
            info = mgr.create_stack(desired_stack)
            ccyo_out.success(f"  Created Aurora stack {stack_name}")

        outputs = info.get("outputs", {})
        endpoint = outputs.get("ClusterEndpoint", "")
        port = str(outputs.get("ClusterPort", "5432"))
        if not endpoint:
            info = mgr.get_stack_status(stack_name)
            outputs = info.get("outputs", {})
            endpoint = outputs.get("ClusterEndpoint", "")
            port = str(outputs.get("ClusterPort", "5432"))
        if not endpoint:
            ccyo_out.error(f"Aurora endpoint not available for {stack_name}")
            raise typer.Exit(1)

        ccyo_out.print_text("\n[bold]Step 3/8: TAPDB target config[/bold]")
        config_update(
            engine_type="aurora",
            host=endpoint,
            port=int(port),
            ui_port=None,
            user=None,
            password=None,
            database=None,
            schema_name=None,
            cognito_user_pool_id=None,
            cognito_app_client_id=None,
            cognito_app_client_secret=None,
            cognito_client_name=None,
            cognito_region=None,
            cognito_domain=None,
            cognito_callback_url=None,
            cognito_logout_url=None,
            domain_code=None,
            owner_repo_name=None,
            domain_registry_path=None,
            prefix_ownership_registry_path=None,
            support_email=None,
            admin_repo_url=None,
            admin_session_secret=None,
            admin_auth_mode=None,
            admin_disabled_user_email=None,
            admin_disabled_user_role=None,
            admin_shared_host_session_secret=None,
            admin_shared_host_session_cookie=None,
            admin_shared_host_session_max_age_seconds=None,
            admin_allowed_origin=[],
            admin_tls_cert_path=None,
            admin_tls_key_path=None,
            admin_metrics_enabled=None,
            admin_metrics_queue_max=None,
            admin_metrics_flush_seconds=None,
            clear=[],
            safety_tier="production",
            destructive_operations="blocked",
        )

        ccyo_out.print_text("\n[bold]Step 4/8: Ensure database exists[/bold]")
        create_database(env=env, owner=None)

        ccyo_out.print_text("\n[bold]Step 5/8: Apply schema[/bold]")
        apply_schema(env=env, reinitialize=False)

        ccyo_out.print_text("\n[bold]Step 6/8: Run migrations[/bold]")
        run_migrations(env=env, dry_run=False)

        ccyo_out.print_text("\n[bold]Step 7/8: Seed templates[/bold]")
        seed_templates(
            env=env,
            config_path=None,
            include_workflow=include_workflow,
            skip_existing=True,
            dry_run=False,
        )

        ccyo_out.print_text("\n[bold]Step 8/8: Ensure admin user[/bold]")
        _create_default_admin(env=env, insecure_dev_defaults=insecure_dev_defaults)

        ccyo_out.print_text("\n[bold]UI startup[/bold]")
        _maybe_start_ui_after_bootstrap(no_gui=no_gui)

        ccyo_out.success("\n✓ Aurora bootstrap complete")

    def _read_yaml_or_json_file(path: Path, *, allow_create: bool = False) -> dict:
        if not path.exists():
            if allow_create:
                return {}
            raise RuntimeError(f"TapDB config file is required: {path}")
        raw = path.read_text(encoding="utf-8")
        import yaml  # type: ignore

        loaded = yaml.safe_load(raw)
        if not isinstance(loaded, dict):
            raise RuntimeError(f"TapDB config file must be a YAML mapping: {path}")
        return loaded

    def _write_yaml_or_json_file(path: Path, payload: dict) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        try:
            import yaml  # type: ignore

            path.write_text(
                yaml.dump(payload, default_flow_style=False, sort_keys=False),
                encoding="utf-8",
            )
        except ModuleNotFoundError:
            path.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
        os.chmod(path, 0o600)

    def _require_explicit_config_flag() -> Path:
        config_path = active_context_overrides().get("config_path")
        if not config_path:
            raise RuntimeError(
                "TapDB config commands require --config. "
                "Example: tapdb --config ~/.config/tapdb/atlas/app/tapdb-config.yaml "
                "config init --client-id atlas --database-name app "
                "--owner-repo-name lsmc-atlas --domain-code Z "
                "--engine-type local --host localhost --port 5533 --ui-port 8911 "
                "--database tapdb_atlas --schema-name tapdb_atlas"
            )
        return Path(config_path)

    def _default_admin_config() -> dict:
        return {
            "footer": {
                "repo_url": "https://github.com/Daylily-Informatics/daylily-tapdb",
            },
            "session": {
                "secret": secrets.token_hex(32),
            },
            "auth": {
                "mode": "tapdb",
                "disabled_user": {
                    "email": "tapdb-admin@localhost",
                    "role": "admin",
                },
                "shared_host": {
                    "session_secret": "",
                    "session_cookie": "session",
                    "session_max_age_seconds": 1209600,
                },
            },
            "cors": {
                "allowed_origins": [],
            },
            "ui": {
                "tls": {
                    "cert_path": "",
                    "key_path": "",
                },
            },
            "metrics": {
                "enabled": True,
                "queue_max": 20000,
                "flush_seconds": 1.0,
            },
            "db_pool_size": 5,
            "db_max_overflow": 10,
            "db_pool_timeout": 30,
            "db_pool_recycle": 1800,
        }

    def _initialize_namespaced_config(
        *,
        client_id: str,
        database_name: str,
        owner_repo_name: str,
        domain_code: str,
        domain_registry_path: str,
        prefix_ownership_registry_path: str,
        engine_type: str,
        host: str,
        port: int,
        ui_port: int,
        user: str,
        password: str,
        database: str,
        schema_name: str,
        safety_tier: str,
        destructive_operations: str,
        force: bool,
    ) -> tuple[Path, dict]:
        current = active_context_overrides()
        set_cli_context(
            client_id=client_id,
            database_name=database_name,
            config_path=current["config_path"],
        )
        config_path = _require_explicit_config_flag()

        normalized_owner_repo_name = normalize_owner_repo_name(owner_repo_name)

        existing = _read_yaml_or_json_file(config_path, allow_create=True)
        existing_meta = existing.get("meta") if isinstance(existing, dict) else None
        if isinstance(existing_meta, dict) and not force:
            if (
                str(existing_meta.get("client_id") or "") != client_id
                or str(existing_meta.get("database_name") or "") != database_name
            ):
                raise RuntimeError(
                    f"Config already exists for a different namespace: {config_path}. "
                    "Use --force to overwrite."
                )

        normalized_engine_type = str(engine_type or "").strip().lower()
        if normalized_engine_type not in {"local", "aurora"}:
            raise RuntimeError("--engine-type must be local or aurora")
        normalized_safety_tier = str(safety_tier or "").strip().lower()
        if normalized_safety_tier not in {"local", "shared", "production"}:
            raise RuntimeError("--safety-tier must be local, shared, or production")
        normalized_destructive_operations = (
            str(destructive_operations or "").strip().lower()
        )
        if normalized_destructive_operations not in {
            "blocked",
            "confirm_required",
            "allowed",
        }:
            raise RuntimeError(
                "--destructive-operations must be blocked, confirm_required, or allowed"
            )
        normalized_schema_name = validate_postgres_identifier_component(
            schema_name, field_name="target.schema_name"
        )
        normalized_database = validate_postgres_identifier_component(
            database, field_name="target.database"
        )
        normalized_domain_code = str(domain_code or "").strip().upper()
        if not normalized_domain_code:
            raise RuntimeError("--domain-code is required")

        root = existing if isinstance(existing, dict) else {}
        root["meta"] = {
            "config_version": 4,
            "client_id": client_id,
            "database_name": database_name,
            "owner_repo_name": normalized_owner_repo_name,
            "domain_registry_path": str(Path(domain_registry_path).expanduser()),
            "prefix_ownership_registry_path": str(
                Path(prefix_ownership_registry_path).expanduser()
            ),
        }
        admin_root = root.get("admin")
        if not isinstance(admin_root, dict) or force:
            root["admin"] = _default_admin_config()
        else:
            merged_admin = _default_admin_config()
            for key, value in admin_root.items():
                if key in {
                    "footer",
                    "session",
                    "auth",
                    "cors",
                    "ui",
                    "metrics",
                } and isinstance(value, dict):
                    merged_admin[key].update(value)
                else:
                    merged_admin[key] = value
            root["admin"] = merged_admin

        prior_target = (
            root.get("target") if isinstance(root.get("target"), dict) else {}
        )
        root["target"] = {
            **prior_target,
            "engine_type": normalized_engine_type,
            "host": str(host).strip(),
            "port": str(port),
            "ui_port": str(ui_port),
            "domain_code": normalized_domain_code,
            "user": str(user).strip(),
            "password": str(password),
            "database": normalized_database,
            "schema_name": normalized_schema_name,
            "cognito_user_pool_id": str(prior_target.get("cognito_user_pool_id") or ""),
            "support_email": str(prior_target.get("support_email") or ""),
        }
        root["safety"] = {
            "safety_tier": normalized_safety_tier,
            "destructive_operations": normalized_destructive_operations,
        }
        root.pop("environments", None)

        _write_yaml_or_json_file(config_path, root)
        return config_path, root

    def _ensure_bootstrap_config_for_aurora() -> Path:
        config_path = _require_explicit_config_flag()
        root = _read_yaml_or_json_file(config_path)
        target = root.get("target") if isinstance(root, dict) else None
        if config_path.exists() and isinstance(target, dict) and target:
            return config_path
        raise RuntimeError(
            "Aurora bootstrap requires an explicit TapDB v4 config with a target "
            "section. Run `tapdb --config <path> config init ...` first."
        )

    @config_root_app.command("init")
    def config_init(
        client_id: str = typer.Option(..., "--client-id", help="Client namespace key"),
        database_name: str = typer.Option(
            ..., "--database-name", help="Database namespace key"
        ),
        owner_repo_name: str = typer.Option(
            ...,
            "--owner-repo-name",
            help="Repo-name token used for Meridian prefix ownership validation",
        ),
        domain_code: str = typer.Option(
            ...,
            "--domain-code",
            help="Meridian domain code for this TapDB target",
        ),
        domain_registry_path: str = typer.Option(
            ...,
            "--domain-registry-path",
            help="Path to the shared Meridian domain registry JSON",
        ),
        prefix_ownership_registry_path: str = typer.Option(
            ...,
            "--prefix-ownership-registry-path",
            help="Path to the shared Meridian prefix ownership registry JSON",
        ),
        engine_type: str = typer.Option(
            ...,
            "--engine-type",
            help="Physical database backend: local or aurora",
        ),
        host: str = typer.Option(..., "--host", help="Physical database host"),
        port: int = typer.Option(..., "--port", help="Physical database port"),
        ui_port: int = typer.Option(..., "--ui-port", help="TapDB UI port"),
        user: str = typer.Option(..., "--user", help="Database user"),
        password: str = typer.Option(
            "",
            "--password",
            help="Database password. Use an empty string for passwordless local auth.",
        ),
        database: str = typer.Option(
            ...,
            "--database",
            help="Physical PostgreSQL database name",
        ),
        schema_name: str = typer.Option(
            ...,
            "--schema-name",
            help="PostgreSQL schema name for this service namespace",
        ),
        safety_tier: str = typer.Option(
            "local",
            "--safety-tier",
            help="Safety tier: local, shared, or production",
        ),
        destructive_operations: str = typer.Option(
            "confirm_required",
            "--destructive-operations",
            help="Destructive operation policy: blocked, confirm_required, or allowed",
        ),
        force: bool = typer.Option(
            False, "--force", help="Overwrite existing config metadata if needed"
        ),
    ) -> None:
        """Initialize a single-target TAPDB v4 config."""
        config_path, root = _initialize_namespaced_config(
            client_id=client_id,
            database_name=database_name,
            owner_repo_name=owner_repo_name,
            domain_code=domain_code,
            domain_registry_path=domain_registry_path,
            prefix_ownership_registry_path=prefix_ownership_registry_path,
            engine_type=engine_type,
            host=host,
            port=port,
            ui_port=ui_port,
            user=user,
            password=password,
            database=database,
            schema_name=schema_name,
            safety_tier=safety_tier,
            destructive_operations=destructive_operations,
            force=force,
        )
        ccyo_out.success("TAPDB explicit-target config initialized")
        ccyo_out.print_text(f"  Namespace: [bold]{client_id}/{database_name}[/bold]")
        ccyo_out.print_text(f"  Path:      [dim]{config_path}[/dim]")
        target_cfg = root["target"]
        ccyo_out.print_text(
            f"  target:    engine={target_cfg['engine_type']} "
            f"database={target_cfg['database']} schema={target_cfg['schema_name']}"
        )

    @config_root_app.command("update")
    def config_update(
        engine_type: Optional[str] = typer.Option(
            None, "--engine-type", help="Database engine type for this target"
        ),
        host: Optional[str] = typer.Option(None, "--host", help="Database host"),
        port: Optional[int] = typer.Option(None, "--port", help="Database port"),
        ui_port: Optional[int] = typer.Option(None, "--ui-port", help="TapDB UI port"),
        user: Optional[str] = typer.Option(None, "--user", help="Database user"),
        password: Optional[str] = typer.Option(
            None, "--password", help="Database password"
        ),
        database: Optional[str] = typer.Option(
            None, "--database", help="Database name"
        ),
        schema_name: Optional[str] = typer.Option(
            None, "--schema-name", help="PostgreSQL schema name"
        ),
        cognito_user_pool_id: Optional[str] = typer.Option(
            None, "--cognito-user-pool-id", help="Bound Cognito user pool ID"
        ),
        cognito_app_client_id: Optional[str] = typer.Option(
            None, "--cognito-app-client-id", help="Bound Cognito app client ID"
        ),
        cognito_app_client_secret: Optional[str] = typer.Option(
            None, "--cognito-app-client-secret", help="Bound Cognito app client secret"
        ),
        cognito_client_name: Optional[str] = typer.Option(
            None, "--cognito-client-name", help="Bound Cognito app client name"
        ),
        cognito_region: Optional[str] = typer.Option(
            None, "--cognito-region", help="Bound Cognito region"
        ),
        cognito_domain: Optional[str] = typer.Option(
            None, "--cognito-domain", help="Bound Cognito hosted UI domain"
        ),
        cognito_callback_url: Optional[str] = typer.Option(
            None, "--cognito-callback-url", help="Bound Cognito callback URL"
        ),
        cognito_logout_url: Optional[str] = typer.Option(
            None, "--cognito-logout-url", help="Bound Cognito logout URL"
        ),
        domain_code: Optional[str] = typer.Option(
            None, "--domain-code", help="Meridian domain code for this target"
        ),
        owner_repo_name: Optional[str] = typer.Option(
            None,
            "--owner-repo-name",
            help="Repo-name token used for Meridian prefix ownership validation",
        ),
        domain_registry_path: Optional[str] = typer.Option(
            None, "--domain-registry-path", help="Shared Meridian domain registry path"
        ),
        prefix_ownership_registry_path: Optional[str] = typer.Option(
            None,
            "--prefix-ownership-registry-path",
            help="Shared Meridian prefix ownership registry path",
        ),
        support_email: Optional[str] = typer.Option(
            None, "--support-email", help="Support email address"
        ),
        admin_repo_url: Optional[str] = typer.Option(
            None, "--admin-repo-url", help="Admin footer repository URL"
        ),
        admin_session_secret: Optional[str] = typer.Option(
            None, "--admin-session-secret", help="Admin session signing secret"
        ),
        admin_auth_mode: Optional[str] = typer.Option(
            None,
            "--admin-auth-mode",
            help="Admin auth mode: tapdb, shared_host, or disabled",
        ),
        admin_disabled_user_email: Optional[str] = typer.Option(
            None,
            "--admin-disabled-user-email",
            help="Synthetic disabled-auth admin email",
        ),
        admin_disabled_user_role: Optional[str] = typer.Option(
            None,
            "--admin-disabled-user-role",
            help="Synthetic disabled-auth admin role",
        ),
        admin_shared_host_session_secret: Optional[str] = typer.Option(
            None,
            "--admin-shared-host-session-secret",
            help="Shared-host session signing secret",
        ),
        admin_shared_host_session_cookie: Optional[str] = typer.Option(
            None,
            "--admin-shared-host-session-cookie",
            help="Shared-host session cookie name",
        ),
        admin_shared_host_session_max_age_seconds: Optional[int] = typer.Option(
            None,
            "--admin-shared-host-session-max-age-seconds",
            help="Shared-host session max age in seconds",
        ),
        admin_allowed_origin: list[str] = typer.Option(
            [],
            "--admin-allowed-origin",
            help="Allowed admin CORS origin (repeatable)",
        ),
        admin_tls_cert_path: Optional[str] = typer.Option(
            None, "--admin-tls-cert-path", help="Configured admin TLS certificate path"
        ),
        admin_tls_key_path: Optional[str] = typer.Option(
            None, "--admin-tls-key-path", help="Configured admin TLS private key path"
        ),
        admin_metrics_enabled: Optional[bool] = typer.Option(
            None,
            "--admin-metrics-enabled/--no-admin-metrics-enabled",
            help="Enable admin DB metrics",
        ),
        admin_metrics_queue_max: Optional[int] = typer.Option(
            None, "--admin-metrics-queue-max", help="Admin DB metrics queue size"
        ),
        admin_metrics_flush_seconds: Optional[float] = typer.Option(
            None,
            "--admin-metrics-flush-seconds",
            help="Admin DB metrics flush interval",
        ),
        clear: list[str] = typer.Option(
            [],
            "--clear",
            help="Target field to clear (repeatable)",
        ),
        safety_tier: Optional[str] = typer.Option(
            None,
            "--safety-tier",
            help="Safety tier: local, shared, or production",
        ),
        destructive_operations: Optional[str] = typer.Option(
            None,
            "--destructive-operations",
            help="Destructive operation policy: blocked, confirm_required, or allowed",
        ),
    ) -> None:
        """Update fields inside a single-target TAPDB v4 config."""
        from daylily_tapdb.cli.db_config import get_config_path

        ctx = _require_context()
        allowed_fields = {
            "engine_type",
            "host",
            "port",
            "ui_port",
            "user",
            "password",
            "database",
            "schema_name",
            "cognito_user_pool_id",
            "cognito_app_client_id",
            "cognito_app_client_secret",
            "cognito_client_name",
            "cognito_region",
            "cognito_domain",
            "cognito_callback_url",
            "cognito_logout_url",
            "domain_code",
            "support_email",
        }
        clear_fields = {str(item).strip() for item in clear if str(item).strip()}
        invalid_fields = sorted(clear_fields - allowed_fields)
        if invalid_fields:
            raise RuntimeError(
                "Unknown target field(s) for --clear: " + ", ".join(invalid_fields)
            )

        config_path = get_config_path()
        root = _read_yaml_or_json_file(config_path)
        if not root:
            raise RuntimeError(
                f"No TAPDB config found at {config_path}. "
                "Run: tapdb config init --client-id <id> --database-name <name>"
            )

        meta = root.get("meta") if isinstance(root, dict) else None
        if not isinstance(meta, dict):
            raise RuntimeError(
                "Config metadata is required. "
                f"Run: tapdb config init --client-id {ctx.client_id} --database-name {ctx.database_name}"
            )

        def _required_mapping(
            parent: dict[str, object], key: str, label: str
        ) -> dict[str, object]:
            value = parent.get(key)
            if not isinstance(value, dict):
                raise RuntimeError(
                    f"Config {label}.{key} section must be an explicit mapping."
                )
            return value

        target_cfg = _required_mapping(root, "target", "root")
        admin_root = _required_mapping(root, "admin", "root")
        footer = _required_mapping(admin_root, "footer", "admin")
        session = _required_mapping(admin_root, "session", "admin")
        auth = _required_mapping(admin_root, "auth", "admin")
        disabled_user = _required_mapping(auth, "disabled_user", "admin.auth")
        shared_host = _required_mapping(auth, "shared_host", "admin.auth")
        cors = _required_mapping(admin_root, "cors", "admin")
        ui_root = _required_mapping(admin_root, "ui", "admin")
        tls = _required_mapping(ui_root, "tls", "admin.ui")
        metrics = _required_mapping(admin_root, "metrics", "admin")

        updates: dict[str, str] = {}
        if engine_type is not None:
            updates["engine_type"] = str(engine_type).strip().lower()
        if host is not None:
            updates["host"] = str(host).strip()
        if port is not None:
            updates["port"] = str(port)
        if ui_port is not None:
            updates["ui_port"] = str(ui_port)
        if user is not None:
            updates["user"] = str(user).strip()
        if password is not None:
            updates["password"] = str(password)
        if database is not None:
            updates["database"] = str(database).strip()
        if schema_name is not None:
            updates["schema_name"] = validate_postgres_identifier_component(
                schema_name,
                field_name="schema_name",
            )
        if cognito_user_pool_id is not None:
            updates["cognito_user_pool_id"] = str(cognito_user_pool_id).strip()
        if cognito_app_client_id is not None:
            updates["cognito_app_client_id"] = str(cognito_app_client_id).strip()
        if cognito_app_client_secret is not None:
            updates["cognito_app_client_secret"] = str(cognito_app_client_secret)
        if cognito_client_name is not None:
            updates["cognito_client_name"] = str(cognito_client_name).strip()
        if cognito_region is not None:
            updates["cognito_region"] = str(cognito_region).strip()
        if cognito_domain is not None:
            updates["cognito_domain"] = str(cognito_domain).strip()
        if cognito_callback_url is not None:
            updates["cognito_callback_url"] = str(cognito_callback_url).strip()
        if cognito_logout_url is not None:
            updates["cognito_logout_url"] = str(cognito_logout_url).strip()
        if domain_code is not None:
            updates["domain_code"] = str(domain_code).strip()
        if support_email is not None:
            updates["support_email"] = str(support_email).strip()
        if owner_repo_name is not None:
            meta["owner_repo_name"] = normalize_owner_repo_name(owner_repo_name)
        if domain_registry_path is not None:
            meta["domain_registry_path"] = str(Path(domain_registry_path).expanduser())
        if prefix_ownership_registry_path is not None:
            meta["prefix_ownership_registry_path"] = str(
                Path(prefix_ownership_registry_path).expanduser()
            )

        admin_changed = False
        if admin_repo_url is not None:
            footer["repo_url"] = str(admin_repo_url).strip()
            admin_changed = True
        if admin_session_secret is not None:
            session["secret"] = str(admin_session_secret)
            admin_changed = True
        if admin_auth_mode is not None:
            auth["mode"] = str(admin_auth_mode).strip().lower()
            admin_changed = True
        if admin_disabled_user_email is not None:
            disabled_user["email"] = str(admin_disabled_user_email).strip().lower()
            admin_changed = True
        if admin_disabled_user_role is not None:
            disabled_user["role"] = str(admin_disabled_user_role).strip().lower()
            admin_changed = True
        if admin_shared_host_session_secret is not None:
            shared_host["session_secret"] = str(admin_shared_host_session_secret)
            admin_changed = True
        if admin_shared_host_session_cookie is not None:
            shared_host["session_cookie"] = str(
                admin_shared_host_session_cookie
            ).strip()
            admin_changed = True
        if admin_shared_host_session_max_age_seconds is not None:
            shared_host["session_max_age_seconds"] = int(
                admin_shared_host_session_max_age_seconds
            )
            admin_changed = True
        if admin_allowed_origin:
            cors["allowed_origins"] = [
                str(item).strip() for item in admin_allowed_origin if str(item).strip()
            ]
            admin_changed = True
        if admin_tls_cert_path is not None:
            tls["cert_path"] = str(admin_tls_cert_path).strip()
            admin_changed = True
        if admin_tls_key_path is not None:
            tls["key_path"] = str(admin_tls_key_path).strip()
            admin_changed = True
        if admin_metrics_enabled is not None:
            metrics["enabled"] = bool(admin_metrics_enabled)
            admin_changed = True
        if admin_metrics_queue_max is not None:
            metrics["queue_max"] = int(admin_metrics_queue_max)
            admin_changed = True
        if admin_metrics_flush_seconds is not None:
            metrics["flush_seconds"] = float(admin_metrics_flush_seconds)
            admin_changed = True
        safety_changed = False
        safety_root = _required_mapping(root, "safety", "root")
        if safety_tier is not None:
            normalized = str(safety_tier).strip().lower()
            if normalized not in {"local", "shared", "production"}:
                raise RuntimeError("--safety-tier must be local, shared, or production")
            safety_root["safety_tier"] = normalized
            safety_changed = True
        if destructive_operations is not None:
            normalized = str(destructive_operations).strip().lower()
            if normalized not in {"blocked", "confirm_required", "allowed"}:
                raise RuntimeError(
                    "--destructive-operations must be blocked, confirm_required, or allowed"
                )
            safety_root["destructive_operations"] = normalized
            safety_changed = True

        if (
            not updates
            and not clear_fields
            and not admin_changed
            and not safety_changed
        ):
            raise RuntimeError("No config changes requested.")

        for field_name in clear_fields:
            target_cfg[field_name] = ""
        target_cfg.update(updates)
        root.pop("environments", None)

        _write_yaml_or_json_file(config_path, root)
        ccyo_out.success("TAPDB explicit-target config updated")
        ccyo_out.print_text(f"  Namespace: [bold]{ctx.namespace_slug()}[/bold]")
        ccyo_out.print_text(f"  Path:      [dim]{config_path}[/dim]")
        for field_name in sorted(clear_fields):
            ccyo_out.print_text(f"  cleared:   {field_name}")
        for field_name in sorted(updates.keys()):
            ccyo_out.print_text(f"  set:       {field_name}={target_cfg[field_name]}")

    @app.command("version")
    def version():
        """Show TAPDB version."""
        from daylily_tapdb import __version__

        ccyo_out.print_text(f"daylily-tapdb [cyan]{__version__}[/cyan]")

    @app.command("info")
    def info(
        as_json: bool = typer.Option(
            False, "--json", help="Emit machine-readable JSON (no tables)."
        ),
    ):
        """Show TAPDB explicit-target configuration and status."""
        import json
        import shutil
        from datetime import UTC, datetime

        from daylily_tapdb import __version__
        from daylily_tapdb.cli.db_config import get_config_path, get_db_config

        def _psql_query(cfg: dict[str, str], sql: str) -> tuple[bool, str]:
            psql = shutil.which("psql")
            if not psql:
                return False, "psql not found"
            env_vars = os.environ.copy()
            env_vars["PGCONNECT_TIMEOUT"] = "3"
            if cfg.get("password"):
                env_vars["PGPASSWORD"] = cfg["password"]
            cmd = [
                psql,
                "-X",
                "-q",
                "-t",
                "-A",
                "-w",
                "-v",
                "ON_ERROR_STOP=1",
                "-h",
                cfg["host"],
                "-p",
                cfg["port"],
                "-U",
                cfg["user"],
                "-d",
                cfg["database"],
                "-c",
                sql,
            ]
            try:
                result = subprocess.run(
                    cmd,
                    capture_output=True,
                    text=True,
                    env=env_vars,
                    timeout=5,
                )
            except Exception as e:
                return False, str(e)
            if result.returncode != 0:
                return False, (
                    result.stderr or ""
                ).strip() or f"psql exit={result.returncode}"
            return True, (result.stdout or "").strip()

        def _human_duration(seconds: int | None) -> str:
            if seconds is None:
                return "-"
            if seconds < 0:
                return "0s"
            days, rem = divmod(seconds, 86400)
            hours, rem = divmod(rem, 3600)
            minutes, secs = divmod(rem, 60)
            parts: list[str] = []
            if days:
                parts.append(f"{days}d")
            if hours:
                parts.append(f"{hours}h")
            if minutes:
                parts.append(f"{minutes}m")
            parts.append(f"{secs}s")
            return " ".join(parts)

        def _ui_process_times(pid: int) -> dict[str, object]:
            result: dict[str, object] = {
                "pid": pid,
                "running": True,
                "start_time": None,
                "uptime_seconds": None,
                "uptime_human": None,
                "error": None,
            }
            try:
                ps = shutil.which("ps") or "ps"
                r = subprocess.run(
                    [ps, "-p", str(pid), "-o", "lstart="],
                    capture_output=True,
                    text=True,
                    timeout=2,
                )
                if r.returncode != 0:
                    result["error"] = (
                        r.stderr or ""
                    ).strip() or f"ps exit={r.returncode}"
                    return result
                raw = (r.stdout or "").strip()
                if not raw:
                    result["error"] = "ps returned empty start time"
                    return result
                start_dt = datetime.strptime(raw, "%a %b %d %H:%M:%S %Y").replace(
                    tzinfo=UTC
                )
                result["start_time"] = start_dt.isoformat(sep=" ")
                up_s = int((datetime.now(UTC) - start_dt).total_seconds())
                result["uptime_seconds"] = up_s
                result["uptime_human"] = _human_duration(up_s)
                return result
            except Exception as e:
                result["error"] = str(e)
                return result

        ctx = _require_context()
        cfg = get_db_config()
        effective_config_path = get_config_path()
        ui_pid_file, ui_log_file, _ = _ui_runtime_paths()
        runtime_root = ctx.runtime_dir()

        template_config_dir: str | None = None
        template_config_error: str | None = None
        try:
            from daylily_tapdb.cli.db import _find_config_dir  # type: ignore

            template_config_dir = str(_find_config_dir())
        except Exception as e:
            template_config_error = str(e)

        ui_pid = _get_pid(ui_pid_file)
        ui_times: dict[str, object] | None = (
            _ui_process_times(ui_pid) if ui_pid else None
        )
        url = (
            f"postgresql://{cfg['user']}@{cfg['host']}:{cfg['port']}/{cfg['database']}"
        )
        ok, msg = _psql_query(cfg, "select 1;")
        uptime = None
        if ok:
            ok_u, msg_u = _psql_query(cfg, "select now() - pg_postmaster_start_time();")
            uptime = msg_u if ok_u else f"error: {msg_u}"
        postgres = {
            "target": "explicit",
            "url": url,
            "schema_name": cfg.get("schema_name"),
            "password_set": bool(cfg.get("password")),
            "status": "ok" if ok else "error",
            "error": None if ok else msg,
            "uptime": uptime,
        }

        if as_json:
            payload: dict[str, object] = {
                "version": __version__,
                "python": sys.version.split()[0],
                "target": "explicit",
                "client_id": ctx.client_id,
                "database_name": ctx.database_name,
                "schema_name": cfg.get("schema_name"),
                "paths": {
                    "ui_pid_file": str(ui_pid_file),
                    "ui_log_file": str(ui_log_file),
                    "effective_config": {
                        "path": str(effective_config_path),
                        "exists": effective_config_path.exists(),
                    },
                    "config_dir": str(effective_config_path.parent),
                    "runtime_root": str(runtime_root),
                    "db_log_dir": str(runtime_root / "logs"),
                    "template_config_dir": template_config_dir,
                    "template_config_error": template_config_error,
                },
                "ui": {
                    "running": bool(ui_pid),
                    "pid": ui_pid,
                    "process": ui_times,
                },
                "postgres": postgres,
            }
            sys.stdout.write(json.dumps(payload, indent=2, sort_keys=True) + "\n")
            return

        general = Table(title="TAPDB Info", show_header=True)
        general.add_column("Property", style="cyan")
        general.add_column("Value")
        general.add_row("Version", __version__)
        general.add_row("Python", sys.version.split()[0])
        general.add_row("Target", "explicit")
        general.add_row("Client ID", ctx.client_id)
        general.add_row("Database Name", ctx.database_name)
        general.add_row("Schema Name", str(cfg.get("schema_name") or ""))
        general.add_row("Namespace", ctx.namespace_slug())
        general.add_row("UI Server", f"Running (PID {ui_pid})" if ui_pid else "Stopped")
        if ui_times and ui_times.get("start_time"):
            general.add_row("UI Start Time", str(ui_times.get("start_time")))
            general.add_row("UI Uptime", str(ui_times.get("uptime_human") or "-"))
        general.add_row("UI PID File", str(ui_pid_file))
        general.add_row("UI Log File", str(ui_log_file))
        print_renderable(general)

        config_table = Table(title="Config", show_header=True)
        config_table.add_column("Property", style="cyan")
        config_table.add_column("Value")
        exists_label = "exists" if effective_config_path.exists() else "missing"
        config_table.add_row(
            "Effective config",
            f"{effective_config_path} ({exists_label})",
        )
        config_table.add_row("Config dir", str(effective_config_path.parent))
        config_table.add_row("Runtime root", str(runtime_root))
        config_table.add_row("DB log dir", str(runtime_root / "logs"))
        if template_config_dir:
            config_table.add_row("Template config dir", template_config_dir)
        else:
            config_table.add_row(
                "Template config dir", f"(not found) {template_config_error}"
            )
        print_renderable(config_table)

        pg_table = Table(title="PostgreSQL", show_header=True)
        pg_table.add_column("Target", style="cyan")
        pg_table.add_column("URL")
        pg_table.add_column("Schema")
        pg_table.add_column("Password")
        pg_table.add_column("Status")
        pg_table.add_column("Uptime")
        status = str(postgres.get("status") or "-")
        if status == "error" and postgres.get("error"):
            status = f"error: {postgres.get('error')}"
        pg_table.add_row(
            "explicit",
            f"[dim]{url}[/dim]",
            str(cfg.get("schema_name") or ""),
            "set" if postgres.get("password_set") else "(not set)",
            status,
            str(postgres.get("uptime") or "-"),
        )
        print_renderable(pg_table)

    return app


# Expose a module-level Typer app for tests and embedding.
#
# Keep this guarded so imports don't explode in partially-provisioned
# environments (e.g., importing the package without console scripts).
try:
    if (
        importlib.util.find_spec("typer") is not None
        and importlib.util.find_spec("rich") is not None
    ):
        app = build_app()
    else:
        app = None
except Exception:
    app = None


def _registry_add_command(
    *, registry, group_path, name, callback, help_text: str
) -> None:
    kwargs = {
        "group_path": group_path,
        "name": name,
        "callback": callback,
        "help_text": help_text,
    }
    try:
        add_command_params = inspect.signature(registry.add_command).parameters
    except (TypeError, ValueError):
        add_command_params = {}
    if "policy" in add_command_params:
        kwargs["policy"] = policy_for_command(group_path, name)
    registry.add_command(**kwargs)


def _register_typer_group(registry, group, *, parent_path: str | None = None) -> None:
    group_name = group.name or group.typer_instance.info.name
    if parent_path is None and group_name == "config":
        group_name = "db-config"
    group_help = group.help or group.typer_instance.info.help or ""
    group_path = group_name if parent_path is None else f"{parent_path}/{group_name}"

    if parent_path is None and hasattr(registry, "add_group"):
        registry.add_group(group_name, help_text=group_help)

    for cmd in getattr(group.typer_instance, "registered_commands", []):
        cmd_name = cmd.name or cmd.callback.__name__.replace("_", "-")
        _registry_add_command(
            registry=registry,
            group_path=group_path,
            name=cmd_name,
            callback=cmd.callback,
            help_text=cmd.help or "",
        )

    for nested_group in getattr(group.typer_instance, "registered_groups", []):
        _register_typer_group(registry, nested_group, parent_path=group_path)


def register(registry, spec) -> None:
    cli_app = app or build_app()
    for cmd in getattr(cli_app, "registered_commands", []):
        cmd_name = cmd.name or cmd.callback.__name__.replace("_", "-")
        if cmd_name in ("version", "info", "config"):
            continue
        _registry_add_command(
            registry=registry,
            group_path=None,
            name=cmd_name,
            callback=cmd.callback,
            help_text=help_text(cmd.callback),
        )
    for group in getattr(cli_app, "registered_groups", []):
        _register_typer_group(registry, group)


def main():
    """Main CLI entry point."""
    import sys

    from cli_core_yo.app import run

    clear_cli_context()
    sys.exit(run(spec, sys.argv[1:]))


try:
    framework_app = create_app(spec)
except Exception:
    framework_app = None

cli = framework_app


if __name__ == "__main__":
    raise SystemExit(main())
