"""TAPDB Database Connection Manager.

Moonshot Phase 2 policy:
- No surprise commits inside the library
- Callers control transaction boundaries
- Audit username is set per-transaction using `SET LOCAL session.current_username`
- Domain code is set per-session using `session.current_domain_code`
- Repo ownership is set per-session using `session.current_owner_repo_name`

Recommended usage:

    with TAPDBConnection() as conn:
        with conn.session_scope(commit=False) as session:
            rows = session.query(...).all()

For write operations:

    with TAPDBConnection() as conn:
        with conn.session_scope(commit=True) as session:
            session.add(obj)
"""

import logging
from contextlib import contextmanager
from typing import Generator, Optional

from sqlalchemy import MetaData, create_engine, text
from sqlalchemy.ext.automap import automap_base
from sqlalchemy.orm import Session, sessionmaker

logger = logging.getLogger(__name__)


class TAPDBConnection:
    """
    TAPDB Database Connection Manager.

    Usage (Phase 2 moonshot):
        # Read-only / query usage
        with TAPDBConnection() as conn:
            with conn.session_scope(commit=False) as session:
                rows = session.query(...).all()

        # Write usage (explicit opt-in commit)
        with TAPDBConnection() as conn:
            with conn.session_scope(commit=True) as session:
                session.add(obj)
                # commits on success, rolls back on exception
    """

    def __init__(
        self,
        db_url: Optional[str] = None,
        db_url_prefix: str = "postgresql://",
        db_hostname: Optional[str] = None,
        db_pass: Optional[str] = None,
        db_user: Optional[str] = None,
        db_name: str = "tapdb",
        app_username: Optional[str] = None,
        echo_sql: Optional[bool] = None,
        pool_size: int = 5,
        max_overflow: int = 10,
        pool_timeout: int = 30,
        pool_recycle: int = 1800,
        engine_type: Optional[str] = None,
        region: str = "us-west-2",
        iam_auth: bool = True,
        secret_arn: Optional[str] = None,
        domain_code: Optional[str] = None,
        owner_repo_name: Optional[str] = None,
        schema_name: Optional[str] = None,
    ):
        """
        Initialize database connection.

        Args:
            db_url: Full database URL (overrides other db_* params)
            db_url_prefix: Database URL prefix. Required when db_url is not supplied.
            db_hostname: Database host:port. Required when db_url is not supplied.
            db_pass: Database password
            db_user: Database user. Required when db_url is not supplied.
            db_name: Database name. Required when db_url is not supplied.
            app_username: Username for audit logging. Required.
            echo_sql: Log SQL statements.
            pool_size: Connection pool size
            max_overflow: Max connections above pool_size
            pool_timeout: Seconds to wait for connection
            pool_recycle: Seconds before connection recycled
            engine_type: Connection type — "local" for local PG,
                "aurora" for Aurora PostgreSQL with SSL + IAM auth.
            region: AWS region (only used when engine_type="aurora").
            iam_auth: Use IAM database authentication (Aurora only).
            secret_arn: Secrets Manager ARN for Aurora password retrieval.
            domain_code: Domain code for session scoping (1-4 chars). Required.
            owner_repo_name: Repo-name for session ownership scoping. Required.
            schema_name: PostgreSQL schema to use as this session's search_path.
        """
        self.logger = logging.getLogger(__name__ + ".TAPDBConnection")

        if not db_user:
            raise ValueError("db_user is required")
        if not app_username:
            raise ValueError("app_username is required")
        self.app_username = app_username
        self.domain_code = domain_code
        self.owner_repo_name = owner_repo_name
        self.schema_name = (schema_name or "").strip() or None
        if not self.domain_code:
            raise ValueError("domain_code is required")
        if not self.owner_repo_name:
            raise ValueError("owner_repo_name is required")

        if echo_sql is None:
            raise ValueError("echo_sql is required")
        if engine_type not in {"local", "aurora"}:
            raise ValueError("engine_type must be 'local' or 'aurora'")

        # Build database URL
        if db_url:
            self._db_url = db_url
        elif engine_type == "aurora":
            from daylily_tapdb.aurora.connection import AuroraConnectionBuilder

            # For Aurora, db_hostname must be the cluster endpoint (host:port
            # or just host).
            if not db_hostname:
                raise ValueError(
                    "db_hostname (Aurora cluster endpoint) is required "
                    "when engine_type='aurora'."
                )
            if ":" not in db_hostname:
                raise ValueError("db_hostname must include an explicit port for Aurora")
            host, port_str = db_hostname.rsplit(":", 1)
            port = int(port_str)

            self._db_url = AuroraConnectionBuilder.build_connection_url(
                host=host,
                port=port,
                database=db_name,
                user=db_user,
                region=region,
                iam_auth=iam_auth,
                secret_arn=secret_arn,
                password=db_pass,
            )
        elif engine_type == "local":
            if not db_hostname:
                raise ValueError("db_hostname is required when engine_type='local'")
            if db_pass is None:
                raise ValueError("db_pass is required when engine_type='local'")
            if not db_user:
                raise ValueError("db_user is required when engine_type='local'")
            if not db_name:
                raise ValueError("db_name is required when engine_type='local'")
            self._db_url = f"{db_url_prefix}{db_user}:{db_pass}@{db_hostname}/{db_name}"

        # Create engine with connection pooling
        self.engine = create_engine(
            self._db_url,
            echo=echo_sql,
            pool_size=pool_size,
            max_overflow=max_overflow,
            pool_timeout=pool_timeout,
            pool_recycle=pool_recycle,
            pool_pre_ping=True,
        )

        # Create session factory
        self._Session = sessionmaker(bind=self.engine)

        # Create metadata and automap base for reflected tables
        metadata = MetaData()
        self.AutomapBase = automap_base(metadata=metadata)

    @staticmethod
    def _is_postgresql_session(session: Session) -> bool:
        bind = getattr(session, "bind", None)
        dialect = getattr(bind, "dialect", None)
        dialect_name = str(getattr(dialect, "name", "") or "").strip().lower()
        return dialect_name == "postgresql"

    def _execute_session_setting(
        self,
        session: Session,
        statement: str,
        params: Optional[dict[str, object]] = None,
        *,
        use_savepoint: bool,
        warning: str,
    ) -> bool:
        """Execute best-effort session setup SQL without poisoning the outer transaction."""
        nested = None
        try:
            if use_savepoint:
                nested = session.begin_nested()
            session.execute(text(statement), params or {})
            if nested is not None:
                nested.commit()
            return True
        except Exception as e:
            if nested is not None:
                try:
                    nested.rollback()
                except Exception as rollback_error:
                    self.logger.warning(
                        f"Could not roll back session setup savepoint: {rollback_error}"
                    )
            else:
                try:
                    session.rollback()
                except Exception as rollback_error:
                    self.logger.warning(
                        f"Could not roll back session after setup failure: {rollback_error}"
                    )
            self.logger.warning(f"{warning}: {e}")
            return False

    def _set_session_timezone_utc(self, session: Session, *, local: bool) -> None:
        """Intentionally leave the session timezone unchanged.

        TAPDB timestamps are DB-managed `TIMESTAMP WITH TIME ZONE` values backed by
        `CURRENT_TIMESTAMP`/`NOW()` defaults and triggers, so mutating the session
        TimeZone is not required for storage correctness and breaks some
        PostgreSQL-compatible backends.
        """
        return

    def _set_session_username(self, session: Session) -> None:
        """Set the per-transaction username for audit logging (no commit)."""
        self._execute_session_setting(
            session,
            "SET LOCAL session.current_username = :username",
            {"username": self.app_username},
            use_savepoint=True,
            warning="Could not set session username",
        )

    def _set_session_domain_code(self, session: Session, *, local: bool) -> None:
        """Set the domain code and owner repo name seen by SQL triggers."""
        if not self._is_postgresql_session(session):
            return
        dc_stmt = (
            "SET LOCAL session.current_domain_code = :code"
            if local
            else "SET session.current_domain_code = :code"
        )
        owner_stmt = (
            "SET LOCAL session.current_owner_repo_name = :code"
            if local
            else "SET session.current_owner_repo_name = :code"
        )
        self._execute_session_setting(
            session,
            dc_stmt,
            {"code": self.domain_code or ""},
            use_savepoint=local,
            warning="Could not set session domain code",
        )
        self._execute_session_setting(
            session,
            owner_stmt,
            {"code": self.owner_repo_name or ""},
            use_savepoint=local,
            warning="Could not set session owner repo name",
        )

    def _set_session_search_path(self, session: Session, *, local: bool) -> None:
        """Set the PostgreSQL search_path for TAPDB runtime queries."""
        if not self._is_postgresql_session(session):
            return
        if not self.schema_name:
            raise ValueError("schema_name is required for PostgreSQL TAPDB sessions.")
        self._execute_session_setting(
            session,
            "SELECT set_config('search_path', :schema_name, :is_local)",
            {"schema_name": self.schema_name, "is_local": local},
            use_savepoint=local,
            warning="Could not set session search_path",
        )

    def get_session(self) -> Session:
        """
        Get a new session.

        Note: this does NOT set the audit username because Phase 2 requires
        `SET LOCAL`, which is per-transaction. Prefer `session_scope()`.

        Returns:
            New SQLAlchemy Session (caller must close)
        """
        session = self._Session()
        self._set_session_timezone_utc(session, local=False)
        self._set_session_search_path(session, local=False)
        self._set_session_domain_code(session, local=False)
        return session

    @contextmanager
    def session_scope(self, commit: bool = False) -> Generator[Session, None, None]:
        """
        Context manager for scoped session operations.

        Args:
            commit: If True, commit on success. If False, caller manages transaction.

        Yields:
            SQLAlchemy Session

        Example:
            with conn.session_scope(commit=True) as session:
                session.add(obj)
                # Auto-commits on success, rolls back on exception
        """
        session = self._Session()
        trans = session.begin()
        try:
            # Must happen inside a transaction for SET LOCAL.
            self._set_session_timezone_utc(session, local=True)
            self._set_session_search_path(session, local=True)
            self._set_session_domain_code(session, local=True)
            self._set_session_username(session)
            yield session
            if commit:
                trans.commit()
            else:
                trans.rollback()
        except Exception:
            trans.rollback()
            raise
        finally:
            session.close()

    def reflect_tables(self) -> None:
        """Reflect database tables into AutomapBase."""
        self.AutomapBase.prepare(autoload_with=self.engine)

    def __enter__(self) -> "TAPDBConnection":
        """Context manager entry."""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> bool:
        """Context manager exit - cleanup resources."""
        if exc_type is not None:
            self.logger.warning(f"Exception in context: {exc_type.__name__}: {exc_val}")
        self.close()
        return False

    def close(self) -> None:
        """Dispose engine resources."""
        if self.engine:
            try:
                self.engine.dispose()
            except Exception as e:
                self.logger.warning(f"Error disposing engine: {e}")
