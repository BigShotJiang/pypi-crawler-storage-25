import numpy as np
import pandas as pd
from null_handling import replace_nulls

#Detect Outliers Method IQR(inter-quantile Range)
names=["id","datetime","date","timestamp"]
def iqr(df):
    df = df.copy()
    missing = {}
    order = []

    # filter columns
    for col in df.columns:
        col_lower = col.lower()

        if not any(name in col_lower for name in names):
            order.append(col)

    # process only valid columns
    for col in order:

        # numeric columns
        if df[col].dtype in ["float64", "int64"]:

            q1 = df[col].quantile(0.25)
            q3 = df[col].quantile(0.75)
            iqr = q3 - q1

            lower = q1 - 1.5 * iqr
            upper = q3 + 1.5 * iqr

            outlier = df[(df[col] < lower) | (df[col] > upper)]

            if len(outlier) > 0:
                missing[col] = "median"
            else:
                missing[col] = "mean"

        # categorical
        else:
            missing[col] = "mode"

    return {"iqr":missing}


#Z Scorce Detection
def zscore(df, config):
    df = df.copy()

    if "zscore" not in config:
        return df

    mask = pd.Series(True, index=df.index)

    for col, rules in config["zscore"].items():

        if col not in df.columns:
            continue

        threshold = rules.get("threshold", 3)

        mean = df[col].mean()
        std = df[col].std()

        if std == 0:
            continue

        z = (df[col] - mean) / std
        outliers = np.abs(z) > threshold

        action = rules.get("action", "cap")

        if action == "remove":
            mask &= ~outliers

        elif action == "cap":
            upper = mean + threshold * std
            lower = mean - threshold * std
            df[col] = np.where(df[col] > upper, upper, df[col])
            df[col] = np.where(df[col] < lower, lower, df[col])

        elif action == "nan":
            df.loc[outliers, col] = np.nan

        else:
            raise ValueError(f"Invalid action: {action}")


    df = df[mask]

    return df

#Standard Scaler Purpose for Train ML models
def standard_scaler(df, config):
    df = df.copy()

    if "scaling" not in config:
        return df

    for col, method in config["scaling"].items():

        if col not in df.columns:
            print(f"{col} not found")
            continue

        # ensure numeric
        df[col] = pd.to_numeric(df[col], errors="coerce")

        #Lower Case Conversion
        method=method.lower()

        if method == "standard":
            mean = df[col].mean()
            std = df[col].std()

            if std == 0:
                print(f"{col} std is 0, skipped")
                continue

            df[col] = (df[col] - mean) / std

        else:
            raise ValueError(f"Invalid scaling method: {method}")

    return df

from sklearn.ensemble import IsolationForest

def isolation_forest_outliers(df, config):
    df = df.copy()

    if "isolation_forest" not in config:
        return df

    rules = config["isolation_forest"]

    cols = rules.get("columns", [])
    contamination = rules.get("contamination", 0.1)
    action = rules.get("action", "remove")

    # ensure numeric
    X = df[cols].apply(pd.to_numeric, errors="coerce")

    model = IsolationForest(contamination=contamination, random_state=42)
    preds = model.fit_predict(X)

    # -1 = outlier
    outliers = preds == -1

    if action == "remove":
        df = df[~outliers]

    elif action == "nan":
        df.loc[outliers, cols] = None

    elif action == "flag":
        df["is_outlier"] = outliers

    else:
        raise ValueError("Invalid action")

    return df

