import pandas as pd

def encode(df, config):
    df = df.copy()

    if "encoding" not in config:
        return df

    for col, method in config["encoding"].items():

        if col not in df.columns:
            continue

        if method == "label":
            df[col] = df[col].astype("category").cat.codes

        elif method == "onehot":
            dummies = pd.get_dummies(df[col], prefix=col)
            df = pd.concat([df, dummies], axis=1)
            df.drop(columns=[col], inplace=True)

        else:
            raise ValueError(f"Invalid encoding method: {method}")

    return df