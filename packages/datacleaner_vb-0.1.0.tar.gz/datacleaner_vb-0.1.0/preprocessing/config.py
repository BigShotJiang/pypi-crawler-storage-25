def structure():
    config="""config = {

    #1. Validation
    "fixes": {
        "Unit_Price": {
            "method": "clip",
            "min": 0,
            "max": 10000
        },
        "Payment_Mode": {
            "method": "replace",
            "values": {"Crypto": "Cash"}
        }
    },

    #2. MISSING
    "missing": {
        "Unit_Price": "median",
        "Quantity": "mean",
        "Payment_Mode": "mode"
    },

    # 3. OUTLIERS (Z-score)
    "zscore": {
        "Unit_Price": {"threshold": 2.5, "action": "cap"},
        "Quantity": {"threshold": 2, "action": "remove"}
    },

    # 4 Isolation Forest 
    "isolation_forest": {
        "columns": ["Unit_Price", "Quantity"],
        "contamination": 0.1,
        "action": "remove"   # remove / nan / flag
    },

    # 5. SCALING (StandardScaler)
    "scaling": {
        "Unit_Price": "standard",
        },
        {
        "Quantity": "standard"
        }
    },

    # 6. ENCODING
    "encoding": {
        "Payment_Mode": "onehot",
        "Customer_Feedback": "label"
    }
}
    } """

    print("Validation → Fixes → Missing → Outliers → Scaling → Encoding")
    print(config)

def functionName():
    print("""
from preprocessing.outliers_handling import zscore, iqr, isolation_forest_outliers, standard_scaler
from preprocessing.null_handling import replace_nulls
from preprocessing.validation import validate
from preprocessing.encoding import encode
from preprocessing.datatype import dtypeconversion """)
