import numpy as np
def replace_nulls(df, config):
    df = df.copy()

    # fix fake nulls
    df = df.replace(["", "NA", "null"], np.nan)

    if "iqr" in config:
        for col, method in config["iqr"].items():

            print(f"{col} nulls before:", df[col].isnull().sum())

            method = method.lower()

            if method == "mean":
                df[col] = df[col].fillna(df[col].mean())

            elif method == "median":
                df[col] = df[col].fillna(df[col].median())

            elif method == "mode":
                df[col] = df[col].fillna(df[col].mode()[0])

            else:
                raise ValueError("Invalid method")

            print(f"{col} nulls after:", df[col].isnull().sum())

    return df