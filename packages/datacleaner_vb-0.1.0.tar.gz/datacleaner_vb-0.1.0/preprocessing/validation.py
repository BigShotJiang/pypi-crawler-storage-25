def validate(df, config):
    df = df.copy()

    if "fixes" not in config:
        return df

    for col, rules in config["fixes"].items():

        if col not in df.columns:
            continue

        method = rules.get("method")

        #  CLIP
        if method == "clip":
            min_val = rules.get("min", None)
            max_val = rules.get("max", None)

            df[col] = df[col].clip(lower=min_val, upper=max_val)

        #  REPLACE
        elif method == "replace":
            mapping = rules.get("values", {})
            df[col] = df[col].replace(mapping)

        else:
            raise ValueError(f"Invalid method: {method}")

    return df