import pandas as pd

def dtypeconversion(df):
    df = df.copy()

    for col in df.columns:
        non_null = df[col].dropna()

        # skip empty columns
        if len(non_null) == 0:
            continue

        col_lower = col.lower()

        # skip id-like columns
        if any(x in col_lower for x in ["id"]):
            continue

        # numeric check
        num = pd.to_numeric(non_null, errors="coerce")
        if num.notna().mean() > 0.9:
            df[col] = pd.to_numeric(df[col], errors="coerce")
            continue

        # datetime check (FIXED warning)
        dt = pd.to_datetime(non_null, errors="coerce", format="mixed")
        if dt.notna().mean() > 0.9:
            df[col] = pd.to_datetime(df[col], errors="coerce", format="mixed")
            continue

        #  category
        if df[col].nunique() < 50:
            df[col] = df[col].astype("category")

    return df