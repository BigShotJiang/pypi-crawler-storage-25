from setuptools import setup, find_packages

setup(
    name="datacleaner-vb",
    version="0.1.0",
    packages=find_packages(),
    install_requires=[
        "pandas",
        "numpy",
        "scikit-learn"
    ],
    author="Bharathan",
    description="Custom data preprocessing library",
)