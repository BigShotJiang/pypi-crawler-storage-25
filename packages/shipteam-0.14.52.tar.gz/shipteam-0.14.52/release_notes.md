# Release Notes

## Unreleased — Wheel-audit CI gate for PyPI publish safety (ADR-020)

### Why

`pyproject.toml` uses `force-include` to copy `.claude/` framework content into the built wheel. Pre-build lints (`tests/test_bundle_drift.py`, bright-line check) verify the repo tree is clean before the build boundary — but cannot catch what `hatchling` emits after that boundary. A wheel uploaded to PyPI with a `.pyc` in `__pycache__/` or an ADR-007 pattern in its `METADATA` would violate both the bytecode-cleanliness and content-policy invariants without any existing gate catching it.

### What changed

- **`scripts/wheel_audit.py`** (NEW): Post-build artifact inspector. Checks `.whl` for PYC_CHECK (`.pyc`/`.pyo`), PYCACHE_CHECK (`__pycache__/`), and BRIGHT_LINE (ADR-007 content patterns, NFKC-normalized against compiled regex). Checks `.tar.gz` sdist for PYC/PYCACHE only — sdist is the full repo tree, already covered by `validate-no-bright-line.sh` with correct file-level exemptions; applying BRIGHT_LINE to sdist produces false positives on ADR-007, CHANGELOG, test fixtures, and the scanner itself. `_TEXT_BASENAMES` frozenset (`METADATA`, `LICENSE`, `NOTICE`, `README`, `AUTHORS`, `PKG-INFO`, `WHEEL`, `RECORD`) ensures no-extension wheel members are scanned — METADATA carries the rendered README and is the primary leak surface. Fail-open defense: empty `dist/` exits 2, not 0.

- **`.github/workflows/wheel-audit.yml`** (NEW): `pull_request` trigger (no secrets). Builds artifacts from the PR branch via `python -m build`, runs the audit gate. Catches violations before merge. SHA-pinned: `actions/checkout@de0fac2e... # v6.0.2`, `actions/setup-python@a309ff8... # v6.2.0`.

- **`.github/workflows/pypi-publish.yml`** (NEW): `release: published` trigger (operator creates a GitHub Release manually from the auto-bump tag). Job graph: `build-and-audit` → `publish`. The `publish` job declares `needs: [build-and-audit]` — publish is structurally skipped if audit fails. Uses OIDC Trusted Publishing (`id-token: write`, GitHub Environment `release`, `attestations: false` per `pypa/gh-action-pypi-publish#283`). No long-lived API token stored as a secret. `actions/download-artifact@v4` and `pypa/gh-action-pypi-publish@release/v1` have TODO comments to SHA-pin before first publish.

- **`docs/85-SAFETY-LIMITS.md`** (MODIFIED): Added "PyPI publish safety gate (wheel-audit)" section with coverage table, known bypass surface (Cyrillic confusables, ZWC, base64), and TOCTOU design note. References ADR-020.

- **`docs/20-DEPLOYMENT.md`** (MODIFIED): Added "PyPI Release Process" section with one-time Trusted Publisher setup steps, per-release checklist, and troubleshooting table.

- **`docs/adr/020-wheel-audit-pypi-gate.md`** (NEW): Extracts the architecture decision — Release-event trigger vs tag-push automatic, BRIGHT_LINE coverage asymmetry, fail-closed `needs:` dependency, OIDC Trusted Publishing rationale, and bypass surface documentation.

- **`pyproject.toml`** (MODIFIED): Added `integration` pytest marker (suppresses unknown-mark warning for `@pytest.mark.integration`).

### Tests

- **`tests/test_wheel_audit.py`** (NEW): 51 tests across 7 classes.
  - `TestArchiveBuilderOracles` (5) — meta-oracle that the in-memory fixture builder works.
  - `TestPhase1Detection` (16) — PYC_CHECK, PYCACHE_CHECK, clean-pass for both artifact types.
  - `TestAuditDistDir` (4) — multi-artifact directory scan aggregation.
  - `TestPhase2BrightLine` (9) — BRIGHT_LINE regex (10 pattern families), NFKC normalization test, sdist-skip confirmation.
  - `TestPhase3CLI` (7) — CLI exit codes (0/1/2), stdout format.
  - `TestPhase3Integration` (1, `@pytest.mark.integration`) — real `python -m build`; both artifacts pass.
  - `TestForensicsGapFixes` (8, NEW) — METADATA scanning, empty-dist exit-2, case-variant PYC (`.PYC`, `.Pyc`), bare `__pycache__` without trailing slash, case-variant `__PYCACHE__`.

### Deferred

- SHA pinning for `actions/download-artifact@v4` and `pypa/gh-action-pypi-publish@release/v1` — TODO comments in `pypi-publish.yml`; requires network access to resolve before first publish.
- Phase 5g SDK CVE deferrals from the task pack work are unchanged.

### Insight

- The post-build artifact boundary is orthogonal to the pre-build lint boundary. `tests/test_bundle_drift.py` proves the repo tree is clean; the wheel audit proves the artifact tree is clean. Both are needed: `hatchling` has edge-case bytecode emission paths and the `force-include` directive means the build boundary is non-trivial. Neither gate is a substitute for the other.
- Five forensics-review findings in the final gate all traced to the same root: the initial implementation had no coverage for no-extension wheel members (`METADATA`) and no coverage for case variants or alternative path separators. The `_TEXT_BASENAMES` frozenset and the centralized `name_lower` pattern are the structural fixes — both also have tests in `TestForensicsGapFixes`.

---

## Unreleased — Task Pack v1 (URL Shortener): runnable benchmark across three drivers

### Why

ADR-017 established the v1 benchmark harness skeleton — Docker containers, `Driver` protocol over three adapters, append-only JSONL, N=10+median+IQR, denylist-gated dashboard. The harness skeleton could run cells, but had no concrete task pack to run them against. `task_packs/` was a stubbed registry with no manifest format, no scoring split, no first-party content, and no driver actually wired to a real SDK or CLI. Phase 5 (sub-phases 5a → 5e, three Sherlock cycles, ~5,400 lines of plan, /deep-r at Steps 3 and 4.5, fw-author-test-strategy across all sub-phases, 8 Critical and 23 High closures across per-phase + final-gate reviews) is the work that turned the stub into a runnable v1.

### What changed

- **`task_packs/url_shortener/`** (NEW): the first first-party task pack on disk. Directory-per-pack convention with `pack.yaml` manifest, `workspace_seed/` (driver R/W mount target), `frozen_tests/` (post-drive RO scoring suite), `injected_bugs/` (10 numbered variant files), `prompt.md` (the spec handed to the driver verbatim), and `Dockerfile` pinned by `@sha256:` digest.

- **`task_packs/loader.py`**: `pack.yaml` validates into a typed `TaskPack` dataclass at load time via `__post_init__`. The existing `task_manifest: dict` Driver protocol contract is satisfied by `TaskPack.to_manifest_dict()`. `resolve_pack(task: str) -> TaskPack` is the single entry point that maps a task name string to a fully-resolved dataclass — `harness/runner.py::run_cell` calls this once at entry and threads the resulting `TaskPack` down to `run_container_for_seed` and `score_workspace`.

- **Sandboxed scoring split** (departs from 3-of-4 surveyed benchmarks): `frozen_tests/` lives outside the workspace and is RO-mounted into the container. SWE-bench, HumanEval, and MBPP all ship tests inline in the workspace; only Aider/Exercism uses per-task directories. The departure is justified by the Cognition Devin failure mode (Cognition's SWE-bench technical report documents Devin reading the exact assertion string and hardcoding the expected error). For agent benchmarks where the agent CAN read tests it sees on disk, physical separation is the cheapest tamper resistance. AC-13 enforces a layered isolation: Layer 1 host-side bidirectional ancestor check (catches symlinks), Layer 2 host-side `_collect_inodes` overlap check via `lstat` (catches hardlinks/bind-mounts), Layer 3 container RO mount + `--cap-drop=ALL` (catches in-container kernel tampering).

- **Salted system-prompt cache defeat** (`drivers/claude_code.py`): claude-agent-sdk 0.1.68 has no `disable_prompt_cache` API (Anthropic Issue #626, open feature request); the bundled `claude` CLI has no `--no-cache` flag (only `--exclude-dynamic-system-prompt-sections`, which improves cache hit rate — wrong direction). The driver therefore appends a per-seed unique salt suffix (`f"\n\n<run_salt>{uuid.uuid5(uuid.NAMESPACE_DNS, str(seed))}</run_salt>"`) to the system prompt, invalidating Anthropic's cache key. Salt overhead measured empirically via `messages.count_tokens` against `claude-sonnet-4-5` at 33–38 tokens (mean 36.2) across 6 seeds — both the original "~20 tokens" estimate and the Step 4.5 "≤30 tokens" tightened bound were wrong. Bound set to ≤40 tokens/call with 5-token headroom for cross-model tokenizer drift within Claude 4.X family. Cost impact at $3/M input × 38 tokens = $0.0001/call. The harness records `usage["cache_read_input_tokens"]` per call as the verification signal; the driver fails closed (`aborted=true, abort_reason="cache_leak_detected"`) on `cache_read_input_tokens > 0` for a salted run. Salt is appended AFTER any SDK-injected `cache_control` marker, with a defensive `_check_salt_placement` scan that raises `RuntimeError` if the construction-site invariant is violated.

- **Three-driver protocol with `cost_source` polymorphism + abort-spine factory**: `Driver.execute()` returns a `DriverResult` whose `cost_source` field is `"computed"` (Claude Code: tokens × pinned rate sheet — SDK's `total_cost_usd` is a local estimate per Issue #487 and MUST NOT be authoritative) or `"scraped"` (Aider/Droid: cost parsed from CLI stdout). AC-15 enforces the distinction: `cost_source="computed"` drivers MUST abort on missing token counts (`abort_reason="missing_token_counts"`); `cost_source="scraped"` drivers MAY return `input_tokens=None`/`output_tokens=None` legitimately (Aider does not emit token counts natively). All abort paths flow through a single `make_aborted_result(elapsed_ms, AbortReason, cost_source, cache_strategy, driver_metadata, **kwargs)` factory in `drivers/_subprocess_helpers.py` — inline `DriverResult` construction in error paths is the abort-spine drift bug class that fw-review-code reliably catches at the next phase. AC-17 enforces a fresh `ClaudeSDKClient` per `execute()` call (defends against SDK Issue #560 session leakage across context boundaries).

- **Cognitive isolation via three module-level patch points** (`run_agent_sdk`, `ClaudeSDKClient`, `_check_salt_placement`): test code rebinds without touching the real SDK; the production stub raises `NotImplementedError` so the driver cannot accidentally hit the network in tests. This is the production-stub-with-test-rebind pattern preferred over `unittest.mock.patch.object` — testable by construction, not by introspection.

- **Defense-in-depth UNION regex on Aider/Droid stdout** (`drivers/aider.py` + `drivers/droid.py`): both CLIs route through litellm under the hood; rate limits, connection errors, context-length-exceeded, and `litellm.exceptions.*` text surfaces in stdout under upstream failures and would otherwise pass through as `aborted=false` with a misleading `acceptance_pct=0.0` row. Shared regex: `(rate.?limit|API.?error|connection.?error|context.?length.?exceeded|litellm\.exceptions)`; Droid additionally matches `factorydroid:\s*error` for CLI-specific errors. A regex match precedes the returncode check, so an exit-zero process whose stdout reports a rate limit is still aborted with `abort_reason.category="api_error_text"` and `driver_metadata["matched_pattern"]` populated for operator debugging.

- **Phase 5e final-gate review caught Droid regex divergence from AC-19 (HIGH-1)**: production was narrower than the test docstring contract claimed (`tests/drivers/test_droid_error_scan.py:12` stated "shared AC-19 regex"; production was Droid-only). Broadened to UNION (above). Three new tests pin litellm/connection/context-length patterns trigger Droid abort. Independent convergence on the finding from both fw-review-code (H1) and fw-review-forensics (HIGH-1) strengthened confidence.

- **Phase 5e CVE deferrals (Phase 5g)**: 4 SDK CVEs deferred — DEPS-CRIT-1 (CVE-2026-35022 CVSS 9.3 Auth Helpers), DEPS-CRIT-2 (CVE-2026-35021 CVSS 8.4 Prompt Editor), DEPS-HIGH-2 (0.1.68 vs 0.1.69 audit), CONCURRENCY-RACE-2 (id() tautology). All CVE attack surfaces are unreachable in Phase 5e because `run_agent_sdk` is a `NotImplementedError` stub; the SDK is wired but not invoked end-to-end until Phase 5g.

### Tests

- **374/374 green** across drivers/scoring/task_packs/aggregation/harness/integration/dashboard. +7 new tests in Phase 5e (4 for AC-14 salted-cache contract rewrite, 3 for AC-19 defense-in-depth on Droid stdout).

### Insight

ADR-016 (empirical CLI probe before TDD) fired four times across Phase 5: salt overhead estimate (Step 3 "~20" → Step 4.5 "≤30" → Phase 5e probe "33–38"), lstat-vs-stat semantics for symlink defense (Phase 5b reviewer narrative was inverted; forensics caught it), Aider stdout regex authored from real CLI output not source-reading, Droid `_VENDOR_ERROR_RE` narrowed-by-comment-then-broadened by final-gate review. The pattern is: a documentation-derived TDD spec lets RED and GREEN agree on a hallucination — only the empirical probe surfaces real numbers and real string shapes. ADR-016 remains the load-bearing rule; Phase 5 was its test bench.

The other architectural insight: **abort-spine consistency is a factory invariant, not a discipline**. Every error path (timeout, FileNotFoundError, vendor-text match, returncode-non-zero, missing tokens, cache leak, unrecognized model) flows through `make_aborted_result`. Inline `DriverResult` construction in error paths is forbidden by convention and caught reliably by per-phase + final-gate code review — but the convention is enforceable only because the factory exists. Without it, three drivers with three different cost-extraction shapes would each grow their own abort dialect. The factory turns a discipline into a type.

### ADR

ADR-019 extracts the Phase 5 architectural rationale: directory-per-pack convention, sandboxed scoring split, salted cache defeat, three-driver protocol with `cost_source` polymorphism + abort-spine factory + cognitive isolation, defense-in-depth vendor-error scanning. Rejected the `entry_points`/JSON Schema route as overengineering at N=1 pack; accepted the SWE-bench-style "tests in workspace" tradeoff cost in exchange for tamper resistance at v1 scale. v1.1 backlog: salt-format-shrink option (`\n\n<s>{seed}</s>` ≈ 5 tokens) for sweep volumes >10K cells; third-party pack support gated on prompt-content review (OWASP LLM01:2025 indirect-injection vector).

---

## 0.14.49 — Safety-infra rule no longer false-positives on read-only ops or commit messages

### Why

Follow-up to the previous "hook commands resolve hook script paths from git root" fix. While committing that fix, the auto-approve safety rule blocked the `git commit -m "..."` call because the commit message body contained the literal path `.claude/settings.json` AND a `<project>` placeholder (which has `>`). The old rule was:

```python
writes_to_safety = re.search(r'\.claude/hooks/|\.claude/rules/|\.claude/settings\.json', command) \
    and re.search(r'>{1,2}|\btee\b|\bcp\b|\bmv\b|\bln\b', command)
```

Both halves matched independently against the whole command text — the `>` in `<project>` and the path `.claude/settings.json` in the message body were enough to trigger a hard block, even though no actual write to safety infra was happening. Same false positive blocked `git show HASH -- .claude/settings.json`, `git diff -- .claude/hooks/foo.py`, `cat .claude/settings.json | jq`, and `cp .claude/settings.json /tmp/backup.json` (safety path as SOURCE, not destination).

### What changed

- **`.claude/hooks/auto_approve_base.py`** + bundle copy at `src/shipteam/framework/hooks/auto_approve_base.py`: rewrote the safety-infra block to require operator + path adjacency. Five precise patterns replace the broad disjunction:

    1. `>>?\s*[\'"]?<safety_path>` — output redirection TO safety path
    2. `\btee\b(?:\s+-flags)*\s+[\'"]?<safety_path>` — tee TO safety path
    3. `\b(?:cp|mv)\b(?:\s+-flags)*\s+(?:\S+\s+)+[\'"]?<safety_path>` — cp/mv where safety path is the destination (last positional arg)
    4. `\bln\b(?:\s+-flags)*\s+(?:\S+\s+)+[\'"]?<safety_path>` — ln where safety path is the destination
    5. `\bsed\b\s+-i\b[^|;&]*?<safety_path>` — sed in-place edit on safety path

  Note: `>>?` is used instead of `>{1,2}` because Python f-strings interpret `{1,2}` as a tuple expression. This was caught by the test harness on the first run — added a comment to prevent re-introduction.

- **`test/safety_gate.bats`**: 7 new negative test cases for read-only / VCS / placeholder scenarios that the old rule false-positived on. All 5 existing positive cases (echo redirect, tee, cp, mv, ln, sed -i) continue to hard-block. Inline test harness validated 19/19 cases (10 must-block, 9 must-pass) before commit.

### Insight

The bug was a *coincidental conjunction*: `re.search(A) and re.search(B)` matches both A and B anywhere in the string, with no requirement that they relate to each other. Static regex can't tell apart "operator applied to path" from "operator and path appearing in the same command for unrelated reasons." When a rule produces a false positive, the symptom is "harmless command blocked" — but the root cause is "the rule was checking the wrong thing." The fix isn't to add exemption clauses ("`git` is OK", "commit messages are OK"); it's to write the original predicate to actually express "operator targets path", which is what the rule meant all along.



### Why

The bug: `.claude/settings.json` invoked hooks with CWD-relative commands (`python3 .claude/hooks/auto-approve.py`). Claude Code resolves hook commands against the live shell CWD. The moment Claude ran `cd frontend` mid-session, every hook resolved to `frontend/.claude/hooks/...` which doesn't exist — hook errored with `[Errno 2] No such file or directory`, every subsequent tool call and UserPromptSubmit blocked, and the user could not even `cd ..` to escape (that bash invocation also goes through the same broken hook). Session was wedged. Only fix was to restart.

This was originally cured in commit 85fc5f0 (2026-03-23) with `python3 "$(git rev-parse --show-toplevel 2>/dev/null || pwd)/.claude/hooks/foo.py"` — the shell resolves `git rev-parse --show-toplevel` BEFORE invoking python3, returning the worktree root regardless of CWD. PRs #70/#71/#77/#83 added new hook entries (lifecycle hooks, methodology-enforcer, Agent Teams hooks) using the OLD relative-path style without anyone noticing the regression. By the time PR #83 landed, all 16 hook commands were back to broken.

Six subsequent PRs (#95, #98, #105, #125, #131, #160) targeted adjacent failure modes (worktree provisioning, supply-chain rules, push-policy hardening) without touching the `command:` strings. The bug was undetectable in CI because no test exercised hook resolution from a non-root CWD.

### What changed

- **`.claude/settings.json`** — all 16 hook commands across PreToolUse / UserPromptSubmit / PostToolUse / SubagentStart / SessionStart / PreCompact / PostCompact / TaskCreated / TaskCompleted / TeammateIdle now use the `git rev-parse --show-toplevel` resolution pattern. Templated to consumer projects via `fw-sync.sh` (already declared in `config/fw-manifest.yaml` as `policy: template`).

- **`test/hook_cwd_resolution.bats`** — new regression test with three checks: (a) no hook command starts with the broken `python3 .claude/hooks/` pattern, (b) every hook command that invokes a Python script from `.claude/hooks/` contains `git rev-parse --show-toplevel`, (c) end-to-end check that extracts a real command and executes it from a project subdirectory, asserting the shell does NOT emit "can't open file" or "No such file or directory". This makes the relative-path regression undeployable in CI.

### Migration

Existing consumer projects running an older synced framework will continue to fail until they receive the fix. After this PR merges:
```
./fw-sync.sh <project-name>
```
will pull the corrected `settings.json` (its `policy: template` entry merges hook-block changes while preserving project-local matchers).

For projects that need an immediate unblock without waiting for fw-sync, a one-liner sed substitution against `.claude/settings.json` works. See the PR description for the patch.

### Insight

When two known-bad options are visible — `$CLAUDE_PROJECT_DIR` (sometimes empty per upstream bugs #33815, #45820) and bare CWD-relative paths (break on `cd`) — a "false dichotomy" failure mode kicks in: pick the less-bad of the two and ship it. The cure was a third option (`git rev-parse --show-toplevel`) that had already shipped once. The associated memory entry has been corrected to flag this third option, and to record that bare-relative is itself broken (the prior memory said the opposite). Memory entries that prescribe an answer are higher-leverage than memory entries that describe a fact — they're load-bearing during routing decisions, so when they're wrong, they're persistently wrong.



### Why

The global `~/.claude/CLAUDE.md` defines a project-wide `/private/` convention: a top-level directory at the repo root, gitignored as a single line, used as the in-repo location for drafts, scratch notes, strategic content, hackathon ground-truth, copyrighted screenshots, transcripts, and demo takes — anything that must NOT ship to a public repo.

The dev-framework adopted the convention itself in the prior PR (`/private/` added to its own `.gitignore`), but did NOT propagate it to projects scaffolded via `uvx shipteam init`. Consumer projects got ADR-007 sanitization pressure (certain content categories barred from the committed tree) without a documented escape hatch — working content ended up scattered across ad-hoc patterns or dropped entirely.

### What changed

Two files in the installer surface, plus tests:

- **`src/shipteam/scaffold.py`** — `REQUIRED_GITIGNORE_ENTRIES` extends from 4 to 5 entries; `/private/` joins the existing `.claude/state/`, `.context/`, `.qa-reports/`, `.shipteam-init.yaml`. The leading slash anchors the pattern to the repo root (does not match nested `private/` inside e.g. `node_modules/`). The append is idempotent (existing AC-14 tests already cover this).

- **`src/shipteam/framework/templates/CLAUDE.md.jinja`** — new managed region `<!-- SHIPTEAM:BEGIN:private_content_convention -->` between the TDD Workflow and Project-Specific Notes sections. Explains the convention, points to `.gitignore` for the actual exclude line, and cross-references the Workspace Hygiene rule in `sherlock-methodology.md` for the orthogonal "is this in git?" vs. "will this filesystem be there next week?" framing.

- **`tests/test_scaffold.py`** — fixture updated to mirror the production list. The existing AC-14 test loops (`for entry in REQUIRED_GITIGNORE_ENTRIES`) automatically extend coverage to `/private/` — no new test bodies needed. One stale comment ("only 2 of the 4 required entries") corrected to be entry-count-agnostic.

### Insight

Two distinct framings cohabit cleanly:

- **ADR-007 (this repo)**: bright-line sanitization for the framework-development repository — restricted content lives in a maintainer-local out-of-tree directory, never committed anywhere.
- **`/private/` convention (consumer projects)**: in-repo escape hatch at `private/`, gitignored as a single line, accessible to all contributors on a project.

Different audiences, different tools. The framework now ships both — ADR-007's *what* (which content categories cannot be in the committed tree) plus this PR's *where* (consumer projects use `/private/`).

### Migration

Existing scaffolded projects that re-run `uvx shipteam init --refresh` get the new line appended (idempotent — running twice doesn't duplicate). Projects that have already established their own `/private/` convention are unaffected (the line is already there).

### Follows

- Companion to PR for repo hygiene where the dev-framework adopted `/private/` itself.
- Companion to the Workspace Hygiene rule (`.claude/rules/sherlock-methodology.md`) — same orthogonal-axes framing.
- ADR-007 is unchanged in this PR; the `/private/` convention does not contradict ADR-007 (which is about the framework repo specifically) and does not require an ADR amendment.

## Unreleased — Repo hygiene: `/private/` convention + hook runtime state in .gitignore

### Why

Two gitignore gaps surfaced during the v0.14.x worktree-cleanup work:

1. **No in-repo `/private/` escape hatch in this repo**. The global `~/.claude/CLAUDE.md` instructs Claude to put private working content (drafts, scratch, hackathon ground-truth, copyrighted screenshots) in a top-level `/private/` directory gitignored as a single line. The dev-framework repo had ADR-007 sanitization pressure to keep certain content categories out of the committed tree — but no documented place to *put* that content. Working docs ended up scattered (e.g., `COMPARISON.md` at repo root) or in maintainer-local paths that aren't visible to other contributors.
2. **`.claude/expected-branch.txt` was untracked and surfaced as new in `git status` on every session**. The file is runtime state read by `branch-check.py:88` and `branch-tracker.py:49`, not source. It belonged in `.gitignore` next to `.claude/state/*` but had been missed.

### What changed

- `.gitignore` adds two sections:
  - `/private/` — single-line directory exclude for in-repo private/IP content per the global convention. Anything under `private/` is invisible to git; the directory exists only on the maintainer's local filesystem.
  - `/.claude/expected-branch.txt` — runtime state file, joins the existing `.claude/state/*` exclusion pattern.
- `COMPARISON.md` (a 22KB strategic mapping doc that had been sitting at the repo root, untracked) is moved to `private/COMPARISON.md` on the maintainer's local FS. Because `/private/` is gitignored, the file no longer appears in `git status`. It was never committed to git history, so the move is invisible to git — the working-tree relocation is a maintainer-local cleanup only.

### Insight

`.gitignore` is exposure control, not persistence control. The two questions — "is this in git?" and "will the filesystem this lives on be there next week?" — are orthogonal. The `/private/` convention answers the first ("no") with a stable answer to the second ("yes, in the main checkout") — which is exactly the shape strategic working content needs.

### Follows

- Companion to the Workspace Hygiene rule (below) — same orthogonal-axes framing, applied at the repo-layout layer rather than the workflow layer.
- ADR-007 sanitization (which content categories cannot be in the committed tree) is the *what*; this is the *where*.
- A follow-up PR will document the `/private/` convention in the framework templates so projects scaffolded via `uvx shipteam init` get the convention by default.

## Unreleased — Demote `fw-review-concurrency` and `fw-review-dependencies` to Sonnet

### Why

Identified via `/deep-r` analysis of 7-day token spend: these two reviewer agents were running on Opus 4.7 but doing rule-driven work that doesn't earn Opus-tier judgment.

- **`fw-review-dependencies`** — CVE reachability, license compatibility, maintenance health, typosquatting checks. Pattern-matching plus enumeration over deterministic data. Sonnet 4.6 handles this equivalently.
- **`fw-review-concurrency`** — async/await race patterns, deadlock heuristics, shared-state detection. Rule-driven detection on well-bounded patterns. Sonnet 4.6 handles this equivalently.

The narrow reviewers that benefit from Opus judgment (architecture, security threat modeling, performance optimization, ambiguous correctness) keep Opus. This is selective demotion, not blanket downgrade.

### What changed

Two frontmatter changes, one line each:

- `.claude/agents/fw-review-concurrency.md`: `model: opus` → `model: sonnet`
- `.claude/agents/fw-review-dependencies.md`: `model: opus` → `model: sonnet`

### Insight

Cost optimization in agent fleets is best driven by telemetry, not intuition. The 7d token-spend lens surfaced these two as Opus-cost-for-Sonnet-equivalent-work; the rest of the fleet remained on its current tier because telemetry didn't flag it. Sherlock-style "audit the whole fleet" approaches tend to over-rotate; targeted /deep-r on actual spend is leaner.

### Follows

- Cherry-picked from a session branch (`session/claude-20260420-212737`) where the change was originally identified during the cost-routing telemetry work.
- Companion to the future MCP governance Pro tier work (cost tracking is one of three governance pillars). This PR is fleet-internal only — no consumer-facing changes.

## Unreleased — Workspace Hygiene rule for ephemeral worktrees

### Why

A real incident: during a hackathon session, a Claude Code agent wrote a devpost submission draft to `private/` inside an ephemeral session-worktree. `private/` is gitignored, so the draft never showed up in `git diff`. When the worktree was cleaned up, the file was lost — despite being on disk seconds earlier.

`.gitignore` answers "is this in git?" — it does NOT answer "will this filesystem still exist next week?" Those are orthogonal. A file that gets "no" to git AND "no" to filesystem-persistence is the failure mode this rule prevents. A file that gets "no" to git AND "yes" to filesystem (e.g., `private/` in the main checkout) is a perfectly valid working draft.

### What changed

**Adds `## Workspace Hygiene — Durable Writes in Ephemeral Workspaces` section to `.claude/rules/sherlock-methodology.md`**:

- **The rule**: Before writing durable working content (drafts the next session expects to read — submission copy, contractor briefs, design notes, plan artifacts, scratch reasoning intended to outlive the session) to a gitignored path inside an ephemeral workspace, redirect the write to the main checkout (or to a path outside the repo entirely). The rule does NOT apply to artifacts that are *expected* to be re-derived: build caches, `node_modules/`, language compile outputs, `actions/cache` paths, devcontainer tool installs.
- **Two orthogonal questions** framing: every file has two independent properties — `.gitignore`-vs-not is exposure control, and filesystem-vs-ephemeral is persistence control. The rule fires on the second, not the first.
- **Detection snippet**:
  ```bash
  common_dir="$(git rev-parse --git-common-dir 2>/dev/null)"
  git_dir="$(git rev-parse --git-dir 2>/dev/null)"
  [ "$common_dir" != "$git_dir" ] && echo "session worktree"
  ```
  with three documented edge cases: submodules (false negative — cross-check via `git rev-parse --show-superproject-working-tree`), `GIT_DIR` env override (abstain on env/CWD mismatch), git ≤ 2.1.4 returning the literal flag string (pre-commit issue #831 — require git ≥ 2.11 or abstain).
- **Recovery steps**: copy to main checkout, `git check-ignore -v` to verify destination ignore coverage, `md5` both copies for byte-identity, optional third copy outside the repo.
- **Generalization**: applies wherever a workspace can vanish without a commit — `git worktree add` (any user, not just Claude), devcontainers when their lifecycle does not survive what you wrote, GitHub Codespaces ("lifecycle-tied storage" outside `/workspaces`), Docker volumes that aren't bind-mounted, CI/CD runners.

**Cross-reference prompts at three workflow gates**:
- Hudson Step 4 (pre-commit)
- Sherlock Lite Step 6 (post-commit, pre-PR)
- Full Sherlock Step 8 (post-commit, pre-PR — last reliable catch-point)

Each prompt uses conversation-context recall + `git status --ignored --short` (gitignored files are untracked and never appear in `git diff` — fixed by the per-phase fw-review-code pass before commit).

### Insight

The rule body is honest about its compliance ceiling: prompt-based instruction-following accuracy drops to ~68% at high instruction density (IFScale, arXiv 2507.11538) and degrades for instructions placed mid-context (lost-in-the-middle, arXiv 2307.03172). `CLAUDE.md` and `.claude/rules/*.md` are delivered as user-context, not system prompt — compliance is probabilistic. A deterministic PreToolUse hook in `.claude/hooks/auto_approve_base.py` is the durable fix. Per Rule of Three (Beck/Fowler), build the hook at N=3 incidents — at N=1, the rule is the deferred-cost option that catches some incidents without absorbing the engineering cost upfront.

The strategy was audited end-to-end via `/deep-r`, which caught two factual errors in the original proposal: (1) `policy: template` *does* propagate updates to existing projects via manual-merge prompts (was claimed not to), and (2) a new `.claude/rules/*.md` file does NOT auto-load without an explicit `CLAUDE.md` cross-reference (there is no auto-load registry). The single-file embed approach in `sherlock-methodology.md` (already `policy: replace`, already referenced from `CLAUDE.md`) avoids both bugs.

### Migration

`fw-sync` will propagate the rule to downstream projects on next sync — no manual action required. Projects already on the framework get the new section in their next pull of `.claude/rules/sherlock-methodology.md`.

### Files Changed

- `.claude/rules/sherlock-methodology.md` (+63 insertions) — rule section + three workflow cross-references

---

## Unreleased — Git push policy in `auto_approve_base.py` (CWE-551 inversion principle)

### Why

Git push is the most consequential operation a Claude Code session performs — it is the moment local AI work becomes shared state. The previous safety gate caught only `git push --force` and `--force-with-lease`. Everything else — `--no-verify` to skip pre-push hooks, `--tags` / `--mirror` / `--all` to push refs the developer didn't intend, refspec attacks (`feat/foo:main` to push a feature branch over main), namespace tricks (`refs/notes/`, `refs/replace/`), wildcard refspecs (`*:*`), legacy delete syntax (`origin :main`), HEAD-relative refs, bare semver tags — all silently fell through to the user prompt. A user who reflexively says "yes" to a `git push` they expected to be safe could destroy main with a single character of obfuscation.

This release closes those gaps **framework-wide** via `policy: replace` in `config/fw-manifest.yaml` — projects cannot drift from the new policy.

### What changed

**Hard denies (exit 2) added to `auto_approve_base.py`**:

- Flags: `--no-verify`, `--tags`, `--mirror`, `--all`
- Direct push to protected branches: `main`, `master`, `develop`, `release/*`, `hotfix/*` (already covered for refspec form; now extended to env-prefix and absolute-path-prefix forms)
- Refspec-to-protected: `git push origin feat/foo:main`, `refs/heads/feat/foo:refs/heads/main`, `HEAD:main`, `HEAD~3:main`
- Namespace tricks: `refs/notes/`, `refs/replace/`, `refs/tags/` destinations
- Wildcards: `*:*`, `+refs/heads/*:refs/heads/*`
- Bare semver tag pushes: `v1.0`, `V1.2.3` (case-insensitive)
- Legacy delete syntax to protected: `git push origin :main` (already covered; now hardened against env-prefix obfuscation)

**Auto-approves (exit 0 with `permissionDecision: "allow"`)**:

- Push to safe-prefix branches with `-u` / `--set-upstream` or no flag: `session/*`, `feat/*`, `fix/*`, `docs/*`, `chore/*`, `refactor/*`, `test/*`
- Gated by four independent refuse paths before `approve()` fires:
  1. `ENV_PREFIX_PATTERN.match(command)` — refuses any env-prefix on the ORIGINAL command (RCE vectors: `GIT_SSH_COMMAND`, `LD_PRELOAD`, `PATH`, `GIT_EXTERNAL_DIFF`, `DYLD_INSERT_LIBRARIES`)
  2. `has_shell_operators` — refuses `$()`, backticks, `;`, `&&`, `|`, `>`, `*`, etc. (CWE-551)
  3. Unknown flags — only `-u` and `--set-upstream` are whitelisted
  4. Delete refspec (`:branch`, `+:branch`) — refuses to silently destroy remote branches via auto-approve

**The architectural principle (CWE-551 inversion)**:

The block path canonicalizes `cmds_to_check = {original, inner_command, effective_command}` and uses paranoid-OR ("any variant matches → block"). The allow path does the opposite: it guards on the ORIGINAL command and uses paranoid-AND ("command itself was already canonical → allow"). An obfuscated dangerous command (env-prefix, subshell, cd-prefix) still hard-denies because it matches via canonicalization. An obfuscated *safe* command falls through to the user prompt because canonicalization on the allow side is a *gift to the attacker*, not a defense. This asymmetry is the load-bearing safety property.

### Removed

- `.claude/settings.local.json.template` (was byte-identical to shipped `.claude/settings.json`, zero runtime consumers, four live doc references that told contributors to copy a file the framework had stopped using)
- `test/settings_template.bats` (entire file was about the dead template)

### Files Changed

- `.claude/hooks/auto_approve_base.py` — adds push policy + 5 helpers (`_normalize_ref`, `_parse_push_targets`, `_command_has_wildcard_refspec`, `_command_has_disallowed_namespace`, `_command_has_delete_refspec`); extends `ENV_PREFIX_PATTERN` to absorb shell-builtin shifts (`command`, `exec`, `nice`, `nohup`, `time`, `setsid`, `unshare`)
- `test/safety_gate.bats` — adds 27 push-policy tests covering all 21 ACs + Phase 2 security review fixes (5 RCE env vars, 3 delete-refspec variants) + Phase 4 defense-in-depth (3 shell-builtin shifted env-prefix forms)
- `CLAUDE.md` — rewrites "Automatic Protections" into structured `HARD BLOCKS` / `AUTO-APPROVES` / `FALLS THROUGH` / `OTHER HOOKS` subsections with honest accounting of what's gated vs. what falls through
- `SETUP.md`, `CONTRIBUTING.md` — remove `cp settings.local.json.template ...` instructions; explain that hooks register via shipped `.claude/settings.json`
- `test/template_instantiation.bats:134` — assertion updated from "template exists" to "settings.json exists"

### Insight

The most important architectural lesson from this PR — and what destines it for ADR-018 — is that **every allow-path guard must be auditable in isolation**. The Phase 4 final-gate security re-scan caught a Medium where `command env GIT_SSH_COMMAND=...` evaded `ENV_PREFIX_PATTERN` because shell builtins shift the env-prefix anchor right by one or more words. Today that form is rejected anyway because `push_regex` also doesn't accept it — but that's two regexes accidentally agreeing, not defense-in-depth. If `push_regex` is ever broadened, the env-guard silently regresses to allow LD_PRELOAD / GIT_SSH_COMMAND injection on auto-approved feature-branch pushes. Closing the gap now (extending the pattern to absorb the builtin shift) means the C-1 invariant — *"the env-guard catches every env-bearing form on its own"* — holds independently of `push_regex` future evolution. **Latent coupling between safety regexes is itself the regression vector.** The block path is paranoid-OR over canonicalized variants; the allow path must be paranoid-AND on the original command, *and* each guard in that AND-chain must be sufficient on its own.

### Migration

`fw-sync` will propagate to downstream projects as `policy: replace` on next sync — no manual action required. Per-project `.claude/settings.local.json` deny rules continue to layer on top: a hook `allow` cannot override a settings `deny`, but a hook `deny` is always honored (per Anthropic's documented hook precedence).

### Test count

`safety_gate.bats` 152 → 179 (+27 push-policy tests). Zero regressions on prior tests.

---

## Unreleased — Benchmark Harness Phase 3 Sub-phase A4: empty-denylist fail-closed + ADR-017 extraction (closes Phase 3 Sub-phase A)

### Why

A4 is the closing sub-phase of Phase 3 Sub-phase A. It ships the H-2 deferral the A3 reviewer named (fail-closed empty denylist), extracts the now-stable benchmark-harness architecture into ADR-017, and retires `.sherlock-plan.md` + `.test-matrix.md` per the Sherlock Step 8 protocol.

The A3 reviewer's deferred list named three items: H-1 (UTS #39 skeleton algorithm for Greek/Armenian/combining marks), H-2 (fail-closed empty-denylist policy), M-3 (DA-15 parametrize expansion). A threat-model honesty pass at the start of A4 produced a re-scope:

- **H-2 IS a real bug regardless of attacker model.** Fail-open-with-warning on a misconfigured denylist let a misconfigured deployment ship rendered output that bypassed every check. A config gate that does nothing on misconfig is a config gate that doesn't exist. **Ship it.**
- **H-1 + M-3 are security theater at the v1 threat model.** The "attacker" must control either a benchmark prompt or a driver's output — both are local-controlled paths in the v1 harness; no untrusted-input ingress exists. If they did control either, they have unboundedly many bypass vectors beyond Greek/Armenian (U+205F medium math space, tag chars U+E0000-U+E007F, full-width Latin, mixed scripts). Closing five of N vectors with a handwritten table is not security; closing them all needs a UTS #39 dependency that overshoots the threat model. The dashboard denylist is one of three ADR-007 gates (bright-line CI scan + git review + runtime denylist), and rendered HTML is not committed in this repo today. **Document as deliberately bounded coverage in ADR-017's `Consequences → Negative` with an explicit revisit trigger; do not ship the implementation.**

### What changed

- **MODIFIED `dashboard/render.py::_load_denylist`** (+11/-3 LOC) — `raise ValueError(...)` on empty (was: `sys.stderr.write(...) + return []`). Exception message includes the denylist path. Docstring updated to describe the new fail-closed policy and the rationale for `ValueError` vs `RuntimeError` (config-input error vs content-leak error).
- **MODIFIED `dashboard/render.py::render_dashboard`** (+8 LOC docstring only) — `Raises:` block enumerates `FileNotFoundError`, `ValueError`, `RuntimeError` so the public contract is self-documenting.
- **MODIFIED `tests/dashboard/test_render.py`** (+15/-12 LOC) — DA-11 oracle flipped to `pytest.raises(ValueError)` with full AC-15.A4.1 coverage (raises + path-in-message + no-output-file + silent-stdout/stderr). 12 unrelated tests that wrote empty denylist fixtures as no-op now write `_NO_MATCH_DENYLIST` (a non-matching sentinel). Module docstring DA-11 line + `_NO_MATCH_DENYLIST` comment updated.
- **CREATED `docs/adr/017-benchmark-harness-architecture.md`** (~140 lines) — Status: PROPOSED. Captures the five architectural choices (Docker + tmpfs + git sanitization, Driver protocol + cost shims, JSONL single source of truth, N=10 + median + IQR, denylist gate fail-closed before write), the MUST-HAVE acceptance-criteria invariants, and the H-1/M-3 deferral with revisit triggers.
- **MODIFIED `docs/adr/README.md`** — index row for ADR-017.
- **MODIFIED `CHANGELOG.md`** — Keep a Changelog entry for A4.
- **MODIFIED `CLAUDE.md`** — `Next Release` line cleared.
- **DELETED `.sherlock-plan.md`** — Step 8 protocol after ADR extraction; tests + ADR are the persisted record.
- **DELETED `.test-matrix.md`** — Step 8 protocol; the shipped tests themselves are the record of coverage.

### Test results

- 543 project tests passing (no net change; DA-11 inverted, 12 sibling tests unchanged in count, 1 capsys silence assertion added).
- 28 dashboard tests green (27 A3-vintage + 1 augmented DA-11).

### Known caveats

- **H-1 (UTS #39)** and **M-3 (DA-15 parametrize expansion)** documented in ADR-017's `Consequences → Negative` as deliberately bounded coverage. Revisit trigger: dashboard outputs become public-facing OR an untrusted-input-fed path lands in the harness.
- **`_NO_MATCH_DENYLIST` sentinel collision robustness** — fw-review-code flagged that a future fixture writer could include the sentinel substring in JSONL content and turn a "no-op denylist" test into a `RuntimeError`. Reviewer's own assessment: latent brittleness, not active bug. Deferred; not load-bearing.

---

## Unreleased — Benchmark Harness Phase 3 Sub-phase A3: denylist hardening (atomic write, missing/empty denylist, malformed rows, XSS, Unicode/ZWSP + hyphen)

### Why

Third and final Sub-phase of Phase 3 Sub-phase A. A1 landed the static renderer + ADR-007 denylist gate; A2 landed the partial-cell marker + mixed-metadata dual-surface warnings; A3 closes the AC-15 hardening edges the security reviewer flagged during A1/A2 as attacker-controllable. The failure modes A3 closes:

- **Non-atomic write on denylist violation** — a reader could previously observe a half-written output file if the renderer wrote before checking the denylist. A3 locks the invariant that the denylist gate runs before any write, so a denylist violation leaves no artifact on disk (DA-9, AC-15).
- **Missing denylist file** — previously would have raised a cryptic error downstream. A3 locks fail-fast behavior: `FileNotFoundError` with no output written (DA-10, AC-15). An empty denylist still renders but writes a visible `WARNING:` line to stderr so operators notice the likely misconfiguration (DA-11, AC-15).
- **Malformed rows** — previously would KeyError on a row missing the `driver` (or `task`) key. A3 filters malformed rows into a counted banner, so a single bad row does not take down a sweep (DA-12, AC-10).
- **XSS via attacker-controlled `driver_version`** — Jinja2 autoescape now enforced via `select_autoescape(["html"])` + `from_string` path; DA-13 locks the HTML-encoding oracle so a literal `<script>` tag inside a `driver_version` field cannot execute.
- **Unicode / zero-width-space denylist bypass** — `\bpricing\b` would previously miss `рricing` (Cyrillic `р`), `pri‍cing` (zero-width joiner), or `pri cing` (literal space). A3 adds an NFKC-normalized + Cyrillic-confusable-folded + zero-width-stripped + whitespace-collapsed normalization path with re-check (DA-15, AC-15). Greek/Armenian/combining-marks/other Cf chars are NOT covered — the UTS #39 skeleton algorithm upgrade is the explicit A4 follow-up.
- **Hyphenated-token lock-in** — `\b` treats hyphens as word boundaries, so `pricing-model` fires on `pricing` as intended. DA-16 locks this behavior as an explicit test so a future regex refactor cannot silently break it.

### What changed

- **MODIFIED `dashboard/render.py`** (+~60 LOC):
  - Added imports: `sys`, `unicodedata`.
  - Added `_CYRILLIC_CONFUSABLES = str.maketrans({...})` — 6-letter Cyrillic→Latin table (р, о, а, с, е, х).
  - Added `_ZERO_WIDTH_CHARS = frozenset(...)` — 4 invisible chars (ZWSP U+200B, ZWNJ U+200C, ZWJ U+200D, BOM U+FEFF).
  - Added `_normalize_for_denylist(text) -> str` — NFKC → Cyrillic fold → ZW strip → whitespace collapse. Docstring explicitly enumerates NOT-covered classes (Greek/Armenian/combining marks, U+2060, U+180E) so a future maintainer knows the boundary.
  - Added `_token_matches(html, token) -> bool` helper (REFACTOR pass); returns False on empty token.
  - `_check_denylist` now runs `_token_matches(html, token) or _token_matches(normalized_html, normalized_token)` — the second arm catches Unicode/ZWSP/whitespace bypass.
  - `_load_denylist` emits `sys.stderr.write("WARNING: empty denylist at <path>\n")` on empty tokens list (DA-11 fail-open-with-warning).
  - `render_dashboard` filters rows missing `driver` OR `task` (`malformed_count += 1; continue`) and passes `malformed_count` to the template.
  - Template adds a top-level `<div data-qa="malformed-rows-banner">` block outside per-cell sections, gated on `malformed_count > 0`.
  - Jinja2 `Environment` is constructed with `select_autoescape(["html"])` + `_ENV.from_string(...)` so autoescape applies to the inline template.
- **NEW `tests/dashboard/fixtures/malformed_row.jsonl`** — 10 rows, row 10 missing `driver` key (all other ResultRow fields valid).
- **NEW `tests/dashboard/fixtures/xss_row.jsonl`** — 1 row with `driver_version = "<script>alert(1)</script>"`.
- **MODIFIED `tests/dashboard/test_render.py`** (+~190 LOC, 6 new tests — one new absence-companion):
  - **DA-9** (P0, AC-15): denylist violation raises RuntimeError BEFORE any file is written; `output_path.exists()` is False after the raise.
  - **DA-10** (P0, AC-15): missing denylist file → FileNotFoundError; no output.
  - **DA-11** (P1, AC-15): empty denylist emits a stderr warning AND still renders. Includes a pre-assertion that `capsys` actually captured stderr output — pins the emission channel so a future impl switch to `logging.warning`/`warnings.warn` cannot silently pass the substring check vacuously (per-phase review fix).
  - **DA-12** (P1, AC-10): malformed rows (missing required keys) are filtered with a counted banner; valid rows still render.
  - **DA-12 companion** (P1, AC-10): clean fixture does NOT emit the malformed banner (absence oracle).
  - **DA-13** (P0, AC-10): XSS via attacker-controlled `driver_version` is neutralized — literal `<script>` tag never appears; HTML-encoded form does.
- **MODIFIED `tests/dashboard/test_denylist.py`** (+~90 LOC, 4 new tests):
  - **DA-15** (P0, AC-15) parametrized across 3 bypass classes (`cyrillic_lookalike`, `zero_width_space`, `literal_space`) + 1 absence companion (`repricing` compound must NOT raise).
  - **DA-16** (P1, AC-15): hyphenated-form `pricing-model` fires on denylist token `pricing` (lock-in on Python `\b` hyphen semantics).

### Verification

- 27/27 dashboard tests pass (11 A1 + 5 A2 + 11 A3 — 6 new DA-9/10/11/12/12c/13 + 4 new DA-15 parametrized + 1 DA-16).
- Per-phase review (fw-review-tests + fw-review-security): 0 Critical; 1 High + 1 Medium fixed inline (docstring accuracy — explicit enumeration of Unicode bypass classes NOT covered; DA-11 capsys channel-pinning pre-assertion). 1 High (UTS #39 upgrade), 1 High (fail-closed empty-denylist policy), 1 Medium (DA-15 parametrize expansion) deferred to A4 per reviewer's SHIP-AS-DELTA guidance.
- Final gate (fw-review-code + fw-review-docs + fw-review-forensics + fw-review-comments): 0 Critical; 1 High fixed inline (malformed-row guard missing symmetric `task`-key check — would KeyError on a row missing `task`); 1 Medium fixed inline (DA-9 `.tmp` assertion was vacuous against current impl — dropped); 2 Lows fixed inline (`7 letters` → `6 letters` to match the 6-entry Cyrillic table; stale `.sherlock-plan.md` back-references stripped from `render.py:155` and `test_denylist.py:8` — ADR-007 only).
- AC coverage check: AC-15 covered by DA-6/7/8 (A1) + DA-9/10/11 (A3, gate edges) + DA-15/16 (A3, Unicode/hyphen); AC-10 covered end-to-end by the DA-1–DA-5 + DA-12/12c + DA-13 + DA-14 set.

### Architectural decisions locked in

- **Defense-in-depth Unicode normalization, not UTS #39 skeleton** — A3 ships the minimal, auditable normalization that closes the specific bypass classes in the test suite (Cyrillic + zero-width + literal-space). UTS #39 skeleton is the clearly-better long-term answer but is a distinct body of work: it requires the Unicode confusables.txt data file and a more permissive matching semantics. ADR-007 is the right home for the upgrade; A4 is the right time to ship it.
- **Denylist re-check on normalized form, not replace** — the check runs on BOTH the original (preserves word-boundary semantics for ASCII input) AND the normalized form (catches bypass). A replace-only design would break DA-7 compound-word semantics (`repricing` would become a false positive if `pricing` were normalized to plain letters and then substring-matched).
- **Empty denylist is fail-open-with-warning, not fail-closed** — A3 decision recorded with explicit caveat that the fail-closed alternative (refuse to render) is a policy call for a follow-up. An empty denylist today almost always means "operator hasn't populated it yet"; fail-closed would block CI on day one. If the project later wants to enforce a populated-denylist invariant, that becomes H-2 in A4.
- **Malformed-row filter is lossy-but-counted, not lossy-silent** — a malformed row is dropped and the count is rendered in a banner. Silent drop would mean a sweep with a handful of malformed rows looks complete; fail-fast on any malformed row would mean a 1000-row sweep dies on one bad record. The banner is the compromise.

### Known follow-up

- **UTS #39 skeleton algorithm** (A4, H-1 from A3 per-phase review) — adds Greek/Armenian/combining-marks/wider Cf coverage. The current 6-letter Cyrillic table + 4-char zero-width set is a deliberate stopgap; the `_normalize_for_denylist` docstring explicitly names the bypass classes NOT covered.
- **Fail-closed empty denylist** (A4, H-2 from A3 per-phase review) — policy decision: should an empty denylist block rendering? Today: warn + render. A4 is the right time to decide.
- **DA-15 parametrize expansion** (A4, M-3 from A3 per-phase review) — add Greek letters, Armenian, combining diacritics, U+2060 word joiner, U+180E Mongolian vowel separator. Pairs with the UTS #39 upgrade (tests drive the data set).
- **ADR-011 extraction** — full Sub-phase A now lands with three PRs (A1 + A2 + A3). ADR-011 extracts the dashboard-rendering architecture (denylist gate + aggregator boundary + dual-surface warning convention + Unicode normalization policy) as one ADR, on the post-A3 merge.

## Released — Benchmark Harness Phase 3 Sub-phase A2: partial-cell marker + mixed-digest / mixed-sdk dual-surface warnings

### Why

Second of three Sub-phase PRs for Phase 3 Sub-phase A. A1 landed the static renderer + ADR-007 denylist gate; A2 lands the visible warning surfaces a reader needs when the numbers in a cell are *not straightforwardly comparable to a full clean run*. Two new warning classes:

- **Partial-cell marker** (AC-10 (b)) — fires when `aggregate_cell` reports an effective N below the threshold (7/10, inclusive), i.e. a sweep that landed sparse data per the Phase 2 Part 2 Sub-phase D aggregator. Locks the partial-cell signal the aggregator has been emitting into a reader-visible HTML marker.
- **Mixed-metadata dual-surface warning** (AC-10 (c)) — fires when rows inside a single `(driver, task)` cell disagree on `container_digest` or `sdk_version`. The warning has TWO surfaces: a top-of-page banner (primary signal — appears outside every `<section>` so a reader cannot miss it on scroll) and a per-cell badge (secondary signal — local to the affected cell so the reader can attribute the warning when they land on the row). The dual surface is load-bearing: a single-surface implementation either hides the warning (banner-only misses a reader who scrolls past without looking up) or de-emphasises it (badge-only loses the top-of-page-visibility invariant).

### What changed

- **MODIFIED `dashboard/render.py`** (+~50 LOC):
  - Added Jinja2 blocks for `mixed_digest_cells` and `mixed_sdk_cells` (driven by `selectattr` filters), each with `data-qa="digest-banner"` / `data-qa="sdk-banner"` markers. Banners render BEFORE any `<section>` (top-of-page invariant).
  - Added per-cell `<p data-qa="digest-badge" class="warning">` and `<p data-qa="sdk-badge" class="warning">` inside each `<section>` when the cell is mixed.
  - Added `data-qa="partial-cell"` attribute to the existing partial-cell marker (previously free-text only — now has a stable test hook).
  - Extracted `_detect_mixed_metadata(rows, field) -> bool` helper — pure function, returns True when the rows contain two or more distinct values for a given field. `None` counts as a distinct value (a row missing the metadata field is environment-unknown, which is warning-worthy — documented in the docstring).
- **NEW `tests/dashboard/fixtures/partial_cell.jsonl`** — 3-row partial fixture (same driver/task, uniform digest + sdk, no aborts).
- **NEW `tests/dashboard/fixtures/mixed_digest.jsonl`** — 10-row fixture, 5 rows `sha256:aaaa...` + 5 rows `sha256:bbbb...`, uniform sdk, no aborts.
- **NEW `tests/dashboard/fixtures/mixed_sdk.jsonl`** — 10-row fixture, 5 rows `sdk_version=0.1.15` + 5 rows `sdk_version=0.1.16`. `driver_version` held constant across all 10 rows (A2 per-phase review HIGH fix — prevents DA-5 silent pass if an impl reads `driver_version` instead of `sdk_version`).
- **NEW `tests/dashboard/fixtures/aborted_rows.jsonl`** — 10-row fixture, 7 non-aborted + 3 aborted with extreme values (wall_clock 999000/998000/997000, cost 0.999/0.998/0.997). Locks the aggregator's aborted-row-exclusion invariant at the render boundary.
- **MODIFIED `tests/dashboard/test_render.py`** (+~280 LOC, 5 new tests):
  - **DA-2** (P0): partial-cell fixture renders the `data-qa="partial-cell"` marker AND does not render any mixed-metadata markers (4-marker absence loop).
  - **DA-3** (P0): mixed-digest dual surface — banner outside any `<section>` (position check via `html.find("<section")` bound), badge inside the affected cell (position check via `rfind`/`find` pair), banner body contains the `(driver, task)` identifiers.
  - **DA-4** (P0): clean-digest + clean-sdk double negative oracle on `full_cell.jsonl` — asserts all four `data-qa="{digest,sdk}-{banner,badge}"` markers absent.
  - **DA-5** (P1): mixed-sdk dual surface, parallel structure to DA-3.
  - **DA-14** (P1): aborted-row-exclusion oracle — asserts medians over the 7 non-aborted rows match `aggregation/results.py::_percentile` linear-interpolation semantics (acceptance `[0.25, 0.4, 0.55]`; wall_clock `[25000, 40000, 55000]`; cost `[0.0025, 0.004, 0.0055]`); asserts partial-cell marker fires because effective n=7 < threshold 10; asserts all 3 aborted seeds' extreme values (wall_clock + cost) absent from the rendered HTML.
  - Tightened DA-1 (existing A1 test) to assert on `data-qa="partial-cell"` attribute rather than the free-text substring "partial" (oracle-stability improvement from A2 per-phase review).

### Verification

- 16/16 dashboard tests pass (11 A1 + 5 A2).
- Per-phase review (fw-review-tests + fw-review-security): 0 Critical, 1 High fixed inline (`mixed_sdk.jsonl` `driver_version` co-variation → fixed by holding `driver_version` constant across all rows), 2 Medium fixed inline (DA-2 stable marker + DA-14 absence-coverage completeness). 1 Medium deferred to follow-up (pre-existing denylist confusables bypass from A1 — reviewer explicitly said "ship A2 cleanly").
- Final gate (fw-review-code + fw-review-docs + fw-review-forensics + fw-review-comments): 0 Critical, 2 High fixed inline (TDD-phase vocabulary stripped from `render.py:2` and `:18`; plan-line back-references replaced with AC-10 (c) citations in `render.py:163/165` and `test_render.py:228`), 2 Medium fixed inline (DA-4 extended to assert sdk markers absent; DA-2 extended to assert 4-marker absence loop). fw-review-security not re-run at gate — per-phase run on identical scope returned Medium-only with ship-clean recommendation.
- AC coverage check: AC-10 (a) covered by DA-1; AC-10 (b) covered by DA-2 + DA-14; AC-10 (c) covered by DA-3 + DA-4 + DA-5. All P0 + P1 tests for A2 green.

### Architectural decisions locked in

- **Dual-surface warning for mixed metadata** — banner (primary) + badge (secondary). A single-surface design was rejected in the plan (line 743 before replacement) because banner-only misses a reader who scrolls past the top, and badge-only de-emphasises the warning to the same visual weight as an ordinary row.
- **`selectattr` for banner row filtering** — banners render only when at least one cell has the attribute set (no empty banner on clean sweeps). The Jinja2 filter is load-bearing and the REFACTOR commit consolidated the detection into `_detect_mixed_metadata` for parity between the banner and badge paths.
- **`data-qa="partial-cell"` stable attribute for the partial marker** — previously free-text; A2 review flagged that a template wording change would break DA-2's `"partial cell"` substring oracle. The attribute marker matches the DA-3/DA-4/DA-5 convention and decouples the oracle from rendered copy.
- **None counts as a distinct value in `_detect_mixed_metadata`** — a row missing the field is environment-unknown, not environment-matching. Documented inline because the alternative (ignore None) would silence the warning on a legitimately incomplete row.

### Known follow-up

- **A3** (next Sub-phase): Unicode normalization (NFKC + ZWSP strip) before the denylist regex + hyphenated-token word-boundary hardening — DA-15 (P0) + DA-16 (P1). Both added to `.test-matrix.md` during A1 review after fw-review-security flagged attacker-controllable `driver_version` as a real vector.
- **`_detect_mixed_metadata` vs aborted-row semantics** — currently runs on unfiltered rows, while `aggregate_cell` filters aborted rows. AC-10 (c) admits either interpretation. A follow-up PR will add a targeted fixture (aborted row with different digest than non-aborted rows) and lock a policy.
- **ADR-011 extraction** — queued for post-A3 landing when the full sub-phase is in. A2 does not extract its own ADR (aligns with the A1 decision: full Sub-phase A gets one ADR, not one per sub-phase).

---

## Unreleased — Benchmark Harness Phase 3 Sub-phase A1: dashboard static HTML + ADR-007 denylist gate

### Why

First of three Sub-phase PRs for Phase 3 Sub-phase A. Lands the minimum viable dashboard: `dashboard/render.py` reads a sweep's `results.jsonl`, groups rows by `(driver, task)`, computes median + IQR (p25/p75) per cell via `aggregation.results.aggregate_cell` from the Phase 2 Part 2 Sub-phase D code, and writes a single static HTML file — plus an **ADR-007 bright-line denylist gate** that runs against the rendered HTML BEFORE write, raising `RuntimeError` on any hit. This gate is the committed-tree enforcement of the bright-line-sanitization policy applied to an artifact that's especially risky: the dashboard is the primary artifact external reviewers see, and it's populated from attacker-influenceable JSONL fields (`driver_version` is a free-form string from the tool under test).

Shipping A1 alone (rather than A1+A2+A3 bundled) lets the denylist gate reach CI while A2 (partial-cell rendering for sparse sweeps) and A3 (Unicode normalization + hyphenated-token word-boundary hardening) still have open TDD work.

### What changed

- **NEW `dashboard/render.py`** (~100 LOC) — `render_dashboard(input_jsonl, output_html, denylist_path) -> None`:
  - Reads JSONL rows, groups by `(driver, task)`, calls `aggregate_cell` per cell to produce per-metric median + p25/p75.
  - Renders a single Jinja2 `from_string` template with `select_autoescape(["html"])` (`default_for_string=True` — autoescape is active on inline templates, verified empirically).
  - Pre-write denylist gate: `_load_denylist` reads tokens one per line; `_check_denylist` matches each token with `re.search(rf"\b{re.escape(token)}\b", html, re.IGNORECASE)`. Any hit raises `RuntimeError` BEFORE `output_html.write_text` runs — no partial-file on denylist failure.
  - Default `denylist_path=Path("release/denylist.txt")` for CI integration; callers can override.
  - `_fmt` uses `.10g` formatting to round IEEE 754 noise (e.g. `0.22499999999999998`) without distorting exact small decimals like `0.00325`.

- **NEW `tests/dashboard/test_render.py`** (~180 LOC, 4 tests) — DA-1 full-cell coverage for AC-10 (a):
  - Hand-computed median/p25/p75 against a 10-row fixture (seeds 0-9, single cell) for `acceptance_pct`, `wall_clock_ms`, `cost_usd`.
  - `_assert_metric_row` helper: bounded-segment DOTALL regex locks each metric label to its own row's percentile values, rejecting a render bug that emits the wrong percentile under a given label (the DOTALL bound stops `.*?` from bleeding across `</tr><tr>` into the next metric's values).
  - Negative-sample guard: full cell (n=10, no aborts) must not render any "partial" marker.

- **NEW `tests/dashboard/test_denylist.py`** (~260 LOC, 7 tests) — DA-6/7/8 for AC-15:
  - DA-6: denylist hit in a rendered cell raises `RuntimeError`; output file is NOT written (verified via `exists()==False`).
  - DA-7: case-insensitive matching (`re.IGNORECASE`) catches mixed-case variants of a denylist token.
  - DA-8: word-boundary enforcement — the denylist token fires only on full-word matches, not substrings of longer identifiers (prevents hairline false positives on prose that happens to contain the token as part of a longer word).

- **NEW `tests/dashboard/fixtures/full_cell.jsonl`** (10 rows) — deterministic fixture matching `ResultRow` shape. Seeds 0-9 produce `acceptance_pct ∈ [0.0..0.9]`, `wall_clock_ms ∈ [10000..100000]`, `cost_usd ∈ [0.001..0.010]` — every percentile is exactly hand-checkable against the linear-interpolation formula in `aggregation._percentile`.

- **MODIFIED `pyproject.toml`** — Jinja2 floor bumped `>=3.1.4,<4.0` → `>=3.1.6,<4.0`. This pulls in fixes for CVE-2024-56326 (`str.format` sandbox escape, fixed 3.1.5) and CVE-2025-27516 (`|attr` filter sandbox escape, fixed 3.1.6). Autoescape on rendered template output already mitigates the attack surface in `render.py` specifically, but the floor bump closes the ingested-dependency window for any future reuse of Jinja2 in this codebase. (CVE attribution flagged for external verification before downstream quoting — Jinja2 changelog is citation of record.)

### Verification

- 11/11 A1 tests pass (`pytest tests/dashboard/`). 4 DA-1 tests (full-cell render, label-anchored percentiles, negative partial-marker guard) + 7 DA-6/7/8 tests (denylist raise, IGNORECASE, word-boundary).
- Bright-line scanner passes on the rendered output path and on `.test-matrix.md` (allowlisted for meta-reference rationale).
- Per-phase review (fw-review-code + fw-review-tests + fw-review-security + fw-review-forensics): 0 Critical, all High applied. Final gate (fw-review-code + fw-review-docs + fw-review-security + fw-review-forensics + fw-review-comments) returned 0 Critical, 0 High after HIGH stale-comment removal and MEDIUM oracle bounded-segment fix.
- fw-review-security empirically confirmed Jinja2 `from_string` + `select_autoescape(["html"])` triggers autoescape via `default_for_string=True`.

### Architectural decisions locked in

- **Denylist gate fails before write** — not after. A denylist hit during post-render inspection is too late: the dashboard HTML would be on disk for any consumer to read. Pre-write `RuntimeError` is the only safe failure mode.
- **Word-boundary matching with case-insensitive re.search** — not substring. Substring matching produces false positives on task prose that happens to contain a denylist token as part of a longer word; word-boundary with `IGNORECASE` strikes the right balance for ASCII tokens. A3 adds Unicode/ZWSP bypass coverage.
- **`.10g` formatting for floats** — not fixed-decimal. Fixed-decimal formatting would drop precision on small cost values (`$0.00325`) or inflate cleanliness on noisy median values; `.10g` rounds IEEE 754 accumulated noise without distorting exact small decimals.
- **Bounded-segment DOTALL oracle** — the `_assert_metric_row` helper binds its regex search to the segment between this metric's label and the next metric's label, closing a cross-row bleed the initial version had (final-gate review M-1).

### Known follow-up

- **A2** (next Sub-phase): partial-cell rendering when `aggregate_cell` returns cell-invalid or partial-cell WARN states — AC-10 (a) partial (rendering) + AC-10 (b) (partial-cell indicator UI). DA-2 through DA-5.
- **A3**: Unicode normalization (NFKC + ZWSP strip before regex) and hyphenated-token word-boundary hardening (DA-15 Unicode/ZWSP bypass, DA-16 hyphen lock-in — both promoted to `.test-matrix.md` during A1 review after fw-review-security flagged attacker-controllable `driver_version` as a real vector).
- **ADR-011 extraction** — Phase 3 Sub-phase A completes a renderer architecturally; ADR extraction queued for post-A3 landing when the full sub-phase is in.

---

## Unreleased — Benchmark Harness Phase 2 Part 2 Sub-phase D: aggregate_cell median/IQR (completes Phase 2 Part 2)

### Why

Fourth and final Sub-phase PR for Phase 2 Part 2. Completes `aggregation/results.py::aggregate_cell` — the stub that's been there since Part 1 — with AC-21 None-handling policy. This is the function that produces the publishable median + IQR numbers per (driver, task) cell; shipping it without explicit None-handling would mean every benchmark report silently mixes "tool ran, killed nothing" (score=0.0) with "no scorable mutants present" (score=None) into the same median, producing numbers that aren't what they appear to be.

**Completes Phase 2 Part 2**: all four scorers (acceptance from Part 1, injected_bugs from Sub-phase A, mutation from Sub-phase B, semgrep from Sub-phase C) can now feed into a lifecycle-aware aggregator. Phase 2 Part 3 (top-level CLI + budget/wall-clock/SDK gate + runner integration + task packs) is the next batch.

### What changed

- **MODIFIED `aggregation/results.py`** (+95 LOC) — `aggregate_cell` and extended `CellSummary`:
  - **AC-21 per-metric None-handling**: `median_per_metric`, `p25_per_metric`, `p75_per_metric` dicts. Each metric's effective N is computed independently (a row with `None` in metric X doesn't affect metric Y's sample). `sample_size_per_metric` reports the effective N per metric for caller debuggability.
  - **Partial-cell WARN threshold**: fires when a metric's effective N ≤ 0.7 × `row_count_valid` (inclusive — 7/10 fires, 8/10 does not). Floating-point safe because `0.7 × 10 == 7.0` exactly in IEEE 754.
  - **Cell-invalid ERROR**: when a metric's effective N < 3, median/p25/p75 return None and an error is recorded. Partial-cell WARN is SUPPRESSED on ERROR (per-phase review M-2 — dual-fire produced redundant signals for the same root cause).
  - **Degenerate inputs**: `aggregate_cell([])` and `aggregate_cell([all_aborted_rows])` return a CellSummary with per-metric errors populated, no exceptions raised. T-74 + T-75 lock this in.
  - **8 metrics aggregated** (`wall_clock_ms`, `input_tokens`, `output_tokens`, `cost_usd`, `acceptance_pct`, `semgrep_high`, `semgrep_critical`, `injected_bug_detections`). Mutation scores are a nested dict per-language (`MutationResult.per_language["python"].score`); flattening to `mutation_python_score` / etc. is Phase 2 Part 3 runner-integration scope (ResultRow schema extension). aggregate_cell's per-metric None-handling supports the extension additively.
  - `_vals` cached once per metric (used for both AC-21 dicts AND legacy `MetricStats` named fields) — eliminates redundant work and the architectural-seam risk of independent recomputation.

- **NEW `tests/aggregation/test_aggregate_cell.py`** (619 LOC, 17 tests across 6 classes):
  - T-19 (×5): median/p25/p75 computed correctly for deterministic [100..190] distribution (median=145, p25=122.5, p75=167.5 per pure-Python linear-interp percentile).
  - T-20 (×3): aborted rows excluded from stats; row_count_valid reflects the exclusion.
  - T-71 (×2): None per-metric exclusion is independent across metrics (different metrics can have different effective N in the same CellSummary); median value is computed from the correct subset (M-3 value-level assertion, not just count-level).
  - T-72 (×2): partial-cell WARN threshold boundary at 7/10 (inclusive) and 8/10 (not fired).
  - T-73 (×3): cell-invalid ERROR at effective N < 3; median/p25/p75 return None for that metric; OTHER metrics unaffected.
  - T-74 + T-75: empty-rows + all-aborted edge cases (fw-review-code L-1 fix).

### Verification

- 41/41 aggregation tests pass (`pytest tests/aggregation/`). The 24 existing `test_results.py` tests (ResultRow schema + append_result_row from Part 1) are untouched.
- Per-phase review: fw-review-code + fw-review-tests. 1 Critical T-59 (nested-metric flattening, explicitly deferred with docstring + rationale) + 2 High + 4 Medium + 2 Low — all applied or documented.

### Architectural decisions locked in

- **Partial-cell WARN suppressed when cell-invalid ERROR fires** (same root cause; dual-fire was noisy for downstream dashboards).
- **Degenerate inputs produce per-metric ERRORs, not exceptions** — aggregate_cell is safe to call on any row list, including empty/all-aborted. Runner integration in Phase 2 Part 3 benefits.
- **Nested-metric flattening deferred to Phase 2 Part 3** — ResultRow extension is the natural home; aggregate_cell's per-metric None-handling supports it additively when `_AGGREGATE_METRICS` expands.

### Known follow-up

- **Phase 2 Part 3** (the next meaningful batch): top-level `shipteam bench` CLI, `harness/budget.py`, `harness/wall_clock.py`, `harness/sdk_version_gate.py`, `aggregation/result_row.schema.json` + cross-driver validation (T-22), contamination tests (T-18, T-33, T-42), `result_row` schema extension with scorer outputs → enables T-59 mutation-score flattening in `aggregate_cell`, empirical Droid `usage` sub-object capture (resolves Part 1's TODO), two pinned task packs (url_shortener, stripe_metered_billing), Docker container orchestration.
- **ADR-011 extraction** — Phase 2 Parts 2+3 both now required; Sub-phase D completes Part 2, so ADR-011 extraction is queued for post-Part-3 landing.

---

## Unreleased — Benchmark Harness Phase 2 Part 2 Sub-phase C: Semgrep Scorer (+ SSRF/LFI Defense)

### Why

Third of four Sub-phase PRs for Phase 2 Part 2. Lands **AC-20 P0** (40-char hex SHA validator on ruleset URLs — rejects mutable refs like `main`/`HEAD`/`v1.2` that would silently violate AC-6 reproducibility), **AC-21 P0** (SemgrepCache sweep-lifetime with sweep_id self-invalidation, mitigating Semgrep issue #3147's 5-year-open no-cache problem), **AC-2** 9-severity `by_severity` dict with `unknown_severities` overflow (per /deep-r Step 3 Tier A ATD source read), and **AC-17** fail-closed across missing-tool / timeout / malformed-JSON / nonzero-exit / ruleset-fetch-failed paths.

Per-phase review pass caught a real **SSRF/LFI security bug** that the GREEN impl would have shipped: Python's default `urllib.request.HTTPRedirectHandler` follows 3xx redirects into ANY scheme (`file://`, `ftp://`, `data://`), so an attacker-controlled task-pack manifest URL on the allowlisted host that responds with `302 Location: file:///etc/passwd` would have caused urllib to fetch and cache that local file content as a "ruleset." The initial `startswith(("http://", "https://"))` guard only validated the FIRST URL, not post-redirect targets. Mitigated via `_StrictHTTPSRedirectHandler` that refuses non-https-scheme and non-allowlisted-host redirects.

### What changed

- **NEW `scoring/semgrep.py`** (306 LOC) — Semgrep scorer:
  - **AC-20 SHA validator**: `_validate_ruleset_ref` enforces `https://` + `raw.githubusercontent.com` host + 40-char hex SHA ref. Runs BEFORE any I/O or subprocess. Raises `RulesetRefError(ref, url)` with structured attributes for diagnostics. Rejects `http://` entirely (TOFU hardening) and non-allowlisted hosts.
  - **AC-21 SemgrepCache**: `__init__(cache_dir, sweep_id)` writes a `.sweep_id` sentinel. Cross-sweep construction (sweep_id mismatch) calls `invalidate()` which deletes all `*` entries in `cache_dir`. Single-process only (documented).
  - **AC-21 `fetch_or_reuse`**: local paths returned as-is (no caching). HTTPS URLs hashed via `hashlib.sha256().hexdigest()` (full 64-char, not 16 — closes birthday-collision attack surface) and cached at `<hash>.yml`. Download uses custom `_build_opener()` with `_StrictHTTPSRedirectHandler`; URL/network errors wrapped as `RulesetFetchError(url, cause)`.
  - **R4 tempfile output**: `semgrep scan --json --output <tempfile>`. Scorer reads tempfile, NEVER stdout. Mitigation for issue #4676 (stdout warning interleave breaks JSON parsers).
  - **AC-17 fail-closed**: five error keys (`tool_missing`, `semgrep_timeout`, `semgrep_output_malformed`, `semgrep_failed`, `ruleset_fetch_failed`) mapped via `SemgrepErrorKey` Literal. Nonzero exit code distinguished from malformed JSON (fw-review-code finding). All paths return structured `SemgrepResult`, never raise.
  - **`SemgrepResult`** is `frozen=True`; `error: SemgrepErrorKey | None` and `tool_name: Literal["semgrep"] | None` are properly Literal-typed (types HIGH findings from review).
  - **9-severity `by_severity` dict + `unknown_severities` overflow** per /deep-r Tier A ATD source read (Semgrep 1.72.0+ emits Critical/High/Medium/Low/Info in addition to legacy Error/Warning/Experiment/Inventory; Info/Experiment/Inventory deprecated per ATD doc).
- **NEW `tests/scoring/test_semgrep.py`** (788 LOC, 27 tests across 10 classes):
  - T-49 (tool-missing), T-62 (SHA validator happy path), T-63 (×7 parametrized mutable-ref rejection), T-64 (same-sweep cache reuse), T-58 (cross-sweep invalidation with explicit deletion assertion — H-1 fix), T-60 (×2: argv includes --output + scorer doesn't read stdout), T-61 (×4: 9-severity round-trip + high/critical aggregates + unknown overflow), T-65 (malformed JSON), T-66 (timeout), T-67 (×2: URL-fetch-failed + typed exception), T-68 (nonzero exit = semgrep_failed, distinct from output_malformed), T-69 (×3: cross-scheme redirect refused + cross-host redirect refused + within-host redirect delegates), T-70 (http:// rejected before fetch).

### Verification

- 27/27 tests passing (`pytest tests/scoring/test_semgrep.py -v`). Sub-phases A/B tests untouched.
- Per-phase review: 4 reviewers in parallel (fw-review-code / fw-review-tests / fw-review-types / fw-review-security). 1 security HIGH (cross-scheme redirect SSRF/LFI) + 2 tests HIGH (T-58 deletion assertion vacuous; T-67 assert_not_called missing) + 2 types HIGH (SemgrepErrorKey + Literal["semgrep"] not applied to result fields) + 4 Medium — all applied.
- /simplify REFACTOR pass before per-phase review caught 1 Critical (fetch_or_reuse silent-swallow of all network errors — AC-17 fail-open footgun) + 2 High (subprocess returncode not checked → silent `semgrep_output_malformed` instead of distinguished `semgrep_failed`; PYTHONHASHSEED-randomized `str(hash(url))` breaks cross-process cache reuse) + 1 Medium.

### Architectural decisions locked in

- **`_StrictHTTPSRedirectHandler` subclass of `urllib.request.HTTPRedirectHandler`** overrides `redirect_request` to refuse non-https schemes and non-allowlisted hosts. Installed via `_build_opener()` and used in `SemgrepCache.fetch_or_reuse` (not the stdlib `urllib.request.urlopen` which uses default handlers).
- **HTTPS + `raw.githubusercontent.com`-only allowlist** for remote ruleset URLs. Local paths are unaffected (used for pre-fetched/pre-pinned task packs).
- **Full 64-char SHA-256 digest** for cache file naming. Truncation attack surface closed.
- **SemgrepCache.invalidate() called implicitly from __init__** on sweep_id mismatch. Documented as "construction is a mutating operation." Caller can also force-flush via the public method.
- **Error-key distinction**: `semgrep_failed` (tool ran, returned nonzero) vs `semgrep_output_malformed` (tool succeeded, wrote garbage) vs `ruleset_fetch_failed` (never got to the tool). Semantically distinct so debugging is possible.

### Known follow-up

- **Sub-phase D** (next and final PR in this cycle): `aggregation/results.py::aggregate_cell` median/IQR with AC-21 None-handling policy.
- **ADR-011 extraction** still deferred until all of Phase 2 completes (Parts 2+3 done).

---

## Unreleased — Benchmark Harness Phase 2 Part 2 Sub-phase B: Mutation Scorer

### Why

Sub-phase A (PR #146) shipped the AC-9 corpus gate + injected-bug scorer. Sub-phase B lands the **AC-19 MUST-HAVE** silent-corruption mitigation for mutmut (`.mutmut-cache` SQLite is on-by-default; cross-run pollution would silently produce wrong scores against new workspaces) plus Stryker SIGTERM/SIGKILL process-group cleanup (Stryker issue #2519: SIGTERM doesn't dispose child runners on Linux). AC-17 fail-closed enforcement on missing tools, timeouts, and malformed JSON.

### What changed

- **NEW `scoring/mutation.py`** (279 LOC) — mutmut + Stryker dual-language scorer:
  - **AC-19 multi-signal mutmut detection**: full `mutants/` directory cleanup pre-run via `shutil.rmtree` (raises `workspace_cleanup_failed` on permission errors — fail-loud, not silent); subprocess invocation with `subprocess.TimeoutExpired` caught and mapped to `mutmut_timeout`; `OSError` caught alongside `JSONDecodeError`; internal-consistency arithmetic (total > 0, total == sum-of-8 counters, check_was_interrupted ≠ total).
  - **AC-19 Stryker process cleanup**: `Popen(start_new_session=True)` (CPython gh-114220 thread-safe equivalent of deprecated `preexec_fn=os.setsid`); pgid captured immediately after Popen to eliminate PID-recycle TOCTOU; `os.killpg(SIGTERM)` on `TimeoutExpired`; zombie reap via `proc.wait(timeout=5)` with SIGKILL escalation.
  - **AC-17 fail-closed on tool-missing**: `FileNotFoundError` on PATH lookup → `per_language[lang] = None` + `per_language_error[lang] = "tool_missing"`; other-language scorers continue running for polyglot tasks.
  - **AC-6 reproducibility hardening**: `npx --no-install stryker` forbids registry auto-fetch; Stryker must already exist in `node_modules/.bin`.
  - **Score formulas** (harness conventions, AC-18-documented as such): mutmut = `killed/(killed+survived+suspicious+timeout)`; Stryker = `(killed+timeout)/(killed+survived+timeout+no_coverage)`. **`score=None` on empty denominator** so consumers can distinguish "ran, killed nothing" from "no scorable mutants present."
  - **New Literal types**: `ToolName = Literal["mutmut", "stryker"]`; `LangErrorKey = Literal["tool_missing", "mutmut_baseline_failed", "mutmut_timeout", "stryker_crashed", "workspace_cleanup_failed"]`. Replaces stringly-typed fields with compile-time-checked enums.
  - **`LanguageMutationScore` is `frozen=True`** (matches `InjectedBugResult` + `DriverResult` peer convention; type carries cross-field integrity invariant).
- **NEW `tests/scoring/test_mutation.py`** (924 LOC, 15 tests across 8 classes) — covers T-15 (Python score shape + range), T-16 (JS score + no cross-language average), T-47/T-48 (tool-missing fail-closed for both tools + polyglot continuation), T-51 (golden mutmut JSON internal-consistency), T-52 (sum mismatch → baseline_failed), T-53 (mutants/ wiped before mutmut runs — cache cross-run guard), T-54a (Popen uses `start_new_session=True`), T-54b (`os.killpg` called with exact pgid + SIGTERM), T-55 (mutmut TimeoutExpired → mutmut_timeout), T-56a (total=0 → baseline_failed), T-56b (all check_was_interrupted → baseline_failed), T-57 (denom=0 → score=None for both Python and Stryker).

### Verification

- 15 tests passing (`pytest tests/scoring/test_mutation.py -v`). Sub-phase A's 14 + Part 1's 144 untouched.
- Per-phase review: 5 reviewers in parallel (fw-review-code, fw-review-tests, fw-review-types, fw-review-forensics for >500 LOC, fw-review-error-handling for try/except surface, fw-review-concurrency for Popen+killpg). 8 Critical/High + 5 Medium findings — all applied or explicitly deferred with reason.
- /simplify pass caught a real correctness bug: GREEN impl had a dead `subprocess.run` call running Stryker ONCE before the timeout-managed Popen path — production would have invoked Stryker twice per cell (the first call had no timeout and could hang the harness for the full mutation duration). Tests passed because they mocked subprocess.run; prod would have hung. Fixed by switching T-16 mock to Popen-only.
- Final gate: fw-review-security (APPROVE — `--no-install` finding applied), fw-review-docs (this entry + CHANGELOG + CLAUDE.md identified), fw-review-comments (APPROVE — 1 minor TRIM applied).

### Architectural decisions locked in

- **AC-19 cache cleanup is whole-`mutants/`-dir, not just stats file** (per Step 4.5 red-team Q10): mutmut's `.mutmut-cache` SQLite reuses prior-workspace mutant artifacts unless the entire dir is wiped. Half-cleaning is silent corruption.
- **`start_new_session=True` over `preexec_fn=os.setsid`**: CPython gh-114220 deprecated `preexec_fn` for fork-safety in multi-threaded parents. Same POSIX semantics; thread-safe.
- **Polyglot JS variant lands under `"javascript"` key regardless of TS** — documented as a module-docstring caveat. Consumers needing TypeScript-specific attribution must set `language="typescript"` explicitly. Decided against an extra manifest field (overhead > value at v1).
- **Score=None semantic for empty denominator**: distinguishes "scorable count was 0" from "killed=0." Caught by /deep-r-aware code review; would have been silent corruption otherwise.

### Known follow-up

- **Sub-phase C** (next PR): `scoring/semgrep.py` — `SemgrepCache` sweep-lifetime with `sweep_id` self-invalidation (AC-21), 40-char hex SHA validator on `--config <URL>` (AC-20, prevents `main`/`HEAD` mutable-ref AC-6 violation), 9-severity `by_severity` dict + `unknown_severities` overflow (R1 from /deep-r Step 3).
- **Sub-phase D** (PR after C): `aggregation/results.py::aggregate_cell` median/IQR with explicit None-handling policy (AC-21).
- **Polyglot parallel execution** (v2): `_score_python` and `_score_js` currently run sequentially; both are subprocess-bound and could run concurrently for ~2x wall-clock improvement on polyglot tasks. Deferred — workspace race surface needs a per-scorer subdirectory before parallelizing.
- **ADR-011 extraction**: still deferred until Phase 2 Parts 2+3 both complete.

---

## Unreleased — Benchmark Harness Phase 2 Part 2 Sub-phase A: Injected-Bug Scorer

### Why

Phase 2 Part 1 (PR #135) shipped the three driver adapters (Claude Code / Aider / Droid). Phase 2 Part 2 ships the four scorers + aggregation glue that consume `DriverResult`. Sub-phase A is the first of four sub-phase PRs and lands the **AC-9 MUST-HAVE** corpus-gate (≥20 bugs required for a benchmark sweep to start) plus the injected-bug correlation scorer that produces detection-sensitivity numbers per task pack.

Sub-phase B (mutation), C (semgrep), D (aggregation median/IQR) follow as separate PRs. Slicing by AC-completion rather than by module-coupling lets each PR own one P0/MUST-HAVE outcome and keeps per-PR review surface small.

### What changed

- **NEW `scoring/injected_bugs.py`** (137 LOC) — `Corpus` + `InjectedBugEntry` + `InjectedBugResult` dataclasses (frozen with tuple fields, `Literal[1]` schema_version); `CorpusError` + `CorpusSchemaError` + structured `CorpusSecurityError(bug_id, attempted_path, resolved_path)` exception hierarchy; `load_corpus()` with path-traversal + symlink-escape defense via `Path.resolve()` + `is_relative_to()`; `validate_corpus()` AC-9 sweep-start gate (default min_bugs=20); `score_injected_bugs()` correlation-only scorer that reads pre-computed `output_dir/test_results.json` and writes per-bug sidecar `output_dir/injected_bugs_detail.jsonl`.
- **NEW `tests/scoring/test_injected_bugs.py`** (14 tests, ~540 LOC) — covers T-14 (P0 detection + sidecar), T-23 (P0 corpus gate + Q1a caller-responsibility contract), T-43–T-45 (P1 schema parsing + forward-compat), T-46 (P0 path-traversal: dotdot + symlink), AC-17 (P1 fail-closed on missing/malformed `test_results.json`).
- **MODIFIED `.sherlock-plan.md`** — restored from PR #135 (procedurally deleted by PR #140); Phase 2 Part 2 Scope Delta section added with /deep-r R1–R6 + Step 4.5 red-team Q1–Q10 fixes; Decision Digest entry for Sub-phase A review; Pivot Log entry documenting the restore.
- **MODIFIED `.test-matrix.md`** — same restore + extended with T-43..T-61 Part 2 test entries + 7 new regression-guard pitfalls (mutmut cache, mutmut #349, Stryker #2519, Semgrep #3147, #4676, severity taxonomy, ruleset-pin SHA bypass, aggregate_cell None policy).

### Verification

- 14 tests passing (`pytest tests/scoring/test_injected_bugs.py -v`). All other Part 1 tests untouched.
- Per-phase review: fw-review-code (1 Critical AC-17 gap → fixed), fw-review-tests (1 High tautological test → rewritten), fw-review-types (2 High `list`-in-frozen-dataclass + `Literal[1]` → fixed), fw-review-forensics (APPROVE: deps verified, Python 3.10+ APIs OK, no AI tells affecting correctness).
- Final gate: fw-review-security (APPROVE — 0 Critical/High/Medium; PyYAML 6.0.3 `safe_load` clean against current advisories; trust boundary correctly drawn), fw-review-docs (identified the doc updates landing in this commit), fw-review-comments (APPROVE — 2 Medium label-trim findings applied).
- /deep-r Step 3 research (~81 calls, topic hash `7918d06f9de7`): Tier A source reads on mutmut 3.5.0, Stryker 9.6.1, Semgrep 1.160.0; Q1 forward-compat finding caught Semgrep's 9-severity enum vs original plan's 3-value assumption.
- /deep-r Step 4.5 red-team: 4 High + 6 Medium plan gaps surfaced; Q10 (mutmut workspace cache cross-run pollution) made AC-19 explicit for Sub-phase B.

### Architectural decision (locks in via this PR)

**Q1a clarifying answer**: AC-9 corpus-gate is **caller-responsibility** — the runner calls `validate_corpus()` at sweep start; `score_injected_bugs()` does NOT re-validate per-run. Test `test_ac9_t23_gate_is_caller_responsibility_not_inside_scorer` locks this contract in code so future maintainers don't accidentally fold the gate into the scorer (which would obscure the architectural separation between sweep-start fail-fast and per-run correlation).

### Known follow-up

- **Sub-phase B** (next PR): `scoring/mutation.py` — mutmut multi-signal success detection (AC-19 silent-corruption mitigation: full `mutants/` dir cleanup pre-run, not just stats file) + Stryker `Popen(preexec_fn=os.setsid)` + `os.killpg` for SIGTERM orphan cleanup (Stryker issue #2519).
- **Sub-phase C** (PR after B): `scoring/semgrep.py` — `SemgrepCache` sweep-lifetime with `sweep_id` self-invalidation (AC-21), 40-char hex SHA validator on `--config <URL>` (AC-20, prevents `main`/`HEAD` mutable-ref AC-6 silent violation), 9-severity `by_severity` dict + `unknown_severities` overflow bucket (R1 Q1).
- **Sub-phase D** (PR after C): `aggregation/results.py` — `aggregate_cell()` median/IQR with explicit None-handling policy (AC-21: `sample_size_per_metric`, partial-cell WARN at <0.7×N, cell-invalid ERROR at <3 samples).
- **ADR-011** (extracts after Phase 2 Parts 2+3 complete, not now per Sub-phase A scope) — benchmark harness architecture decision record.

---

## Unreleased — claude-session.sh env-scrub at the claude boundary (close the contamination origin)

### Why

[PR #143](https://github.com/cdjgroup/dev-framework/pull/143) added a downstream guard that detects and self-corrects when `FW_PROJECT_ROOT` is inherited cross-worktree. The follow-up investigation (REC 3 from the /deep-r) traced where the contaminated env actually originated in the first place: the `claude-<project>` shell alias generated by `scripts/generate-shell-alias.sh` is a shell FUNCTION (not a fork-exec alias), so its body runs in the current shell. Its body:

```
cd "$PROJECT_ROOT"          # main-repo path, hardcoded at alias-gen time
./scripts/claude-session.sh $branch
```

`claude-session.sh:22` sources `_framework.sh` from the main repo's `scripts/` dir → `_fw_find_root` walks to the main-repo root → `:121` `export FW_PROJECT_ROOT=/path/to/main-repo`. At `:644` the session script invokes `claude` as a child process. Claude inherits the exported env; the zsh claude launches inherits from claude. Every framework script the user runs inside that claude session reads the inherited main-repo path from env instead of auto-detecting the worktree.

Verified this session: `FW_RED/GREEN/BLUE/YELLOW/NC` color env vars were set in the investigator's shell — these are exported *only* at `_framework.sh:161-165`, so their presence is unambiguous evidence that `_framework.sh` was sourced somewhere in the ancestor process chain.

### What changed

- **`scripts/claude-session.sh:644`**: replaced `claude` with `env -u FW_PROJECT_ROOT -u FW_CONFIG -u FW_FW_DIR -u FW_ROOT_OVERRIDE -u FW_SKIP_PREREQ_CHECK claude`. Strips framework identity + override env vars at the claude-launch boundary so claude's subshell starts with a clean env. Scripts invoked inside the claude session now auto-detect `FW_PROJECT_ROOT` from their own source location (the worktree's `scripts/`), as originally intended.
- Cosmetic color vars (`FW_RED`, `FW_GREEN`, `FW_YELLOW`, `FW_BLUE`, `FW_NC`) are intentionally NOT scrubbed — they're harmless and occasionally useful inside the session.
- Inline comment names the WHY (cross-worktree contamination origin), the defense-in-depth relationship with PR #143's guard, and the reason for `env -u` over `unset` (preserves the launcher's own env for the EXIT cleanup trap).

### Effect on PR #143's guard

- **Before this PR**: the guard fires a warning on EVERY framework script invocation inside a claude session launched via the alias. Functionally correct (self-corrects to the right tree) but noisy.
- **After this PR**: the env is clean at session start; auto-detection runs normally; guard only fires if the user manually pre-sets `FW_PROJECT_ROOT` after the session starts. Guard remains as defense-in-depth.

### Why not also fix at `generate-shell-alias.sh`

Considered: bake `unset FW_*` into the generated function body. Rejected because that only helps users who re-run `--install`; existing `.zshrc` entries stay contaminated. Fixing at `claude-session.sh` covers the alias path AND every other call path (direct `./scripts/claude-session.sh` invocation, CI, scripts that `exec claude` from a framework subprocess). One fix, universal coverage.

### Verification

- `shellcheck scripts/claude-session.sh`: no new warnings (only the pre-existing SC1091 about `_framework.sh` sourcing).
- `env -u FW_PROJECT_ROOT bash -c 'echo "${FW_PROJECT_ROOT:-CLEAN}"'` → `CLEAN`. Confirms `env -u` strips as designed on this system.
- No new bats test: the launch-point is behind enough session-bootstrap complexity that a useful test would require extensive PATH stubbing of `claude`. PR #143's 11 regression tests already catch any reintroduction of the contamination downstream.

### Known follow-up

- `generate-shell-alias.sh`-generated functions deployed in user shells before this PR will still contaminate until they trigger a new claude launch. Self-healing once claude-session.sh runs, which is immediate.

---

## Unreleased — `_framework.sh` cross-worktree env-var contamination guard

### Why

Running framework scripts from a worktree inherited `FW_PROJECT_ROOT` from a prior invocation in a different worktree (via `_framework.sh:95` `export`), causing validators (`validate-no-bright-line.sh`, `validate-no-public-secrets.sh`) and git-mutating scripts (`sync-with-main.sh`, `merge-to-main.sh`, `branch-recovery.sh`) to silently operate on the wrong repository tree. Reproduced in this investigation: `FW_PROJECT_ROOT` pre-set in shell env to the main-repo path, `./scripts/validate-no-bright-line.sh` invoked from a different worktree → scanner scanned the main-repo tree instead of the worktree. Silent wrong-answer, not visible to the caller.

Investigation via `/deep-r` (cache hash `8c3d37bf6e8c`) compared three fix shapes; Option A (in-place guard in `_framework.sh`) won on blast radius (1 file + 6 test-site bypasses) vs Option B (18 entry-point edits, fragile completeness) vs Option C (git-rev-parse consistency, documented edge cases in submodules + non-git CWD + deliberate-override intent — all surfaced by adversarial upstream search against git-lfs#1613, lazygit#3175, lint-staged#886 and anthropics/claude-code #1985 #28801 #27343 #36360 #27994).

### What changed

- **New guard block in `scripts/_framework.sh`** — after the pre-set branch's validity checks, compare `FW_PROJECT_ROOT` against the `$BASH_SOURCE`-derived root (same walk logic as auto-detect). If they disagree and `FW_ROOT_OVERRIDE` is unset, emit a warning to stderr and overwrite `FW_PROJECT_ROOT` with the script-derived value. Defensive `${BASH_SOURCE[0]:-}` check makes the block skip cleanly on non-bash invocation.
- **Warning format** (stable contract for tests and downstream consumers): `_framework.sh: warning: FW_PROJECT_ROOT env (=<X>) disagrees with script location (=<Y>); preferring script location. Set FW_ROOT_OVERRIDE=1 to force env value.` Emitted to stderr only; stdout unaffected.
- **New opt-in env var `FW_ROOT_OVERRIDE=1`** — set on test fixtures that deliberately point `FW_PROJECT_ROOT` at a path distinct from the script location (6 call sites updated: 1 helper in `test/framework_config.bats` + 5 AC-2 tests + 1 `test/worktree_bootstrap.bats` setup).
- **New regression test `test/framework_worktree_env.bats`** — 9 cases covering all 6 ACs plus edge cases. Most importantly AC-6a/b create a real `git worktree add`-based worktree and verify the guard fires (or is honored under `FW_ROOT_OVERRIDE=1`).
- **Doc update**: `docs/50-TESTING.md` documents the `FW_ROOT_OVERRIDE=1` requirement for fixture reads.

### Why this shape wins over the alternatives

- **Option B** (clear the env in session-entry scripts) would require touching 18 scripts that source `_framework.sh` (CoVe grep; initial audit estimated ~6-8, off by ~3×). Completeness is fragile because any future script added to `scripts/` that forgets to `unset FW_PROJECT_ROOT FW_CONFIG` re-opens the hole.
- **Option C** (use `git rev-parse --show-toplevel` for consistency check) has three named failure modes: (1) silent wrong-answer inside a submodule [git-lfs#1613]; (2) fail-closed when CWD is outside any git repo; (3) indistinguishable from "deliberate cross-tree audit" without the same FW_ROOT_OVERRIDE bypass anyway. Net complexity equal to Option A with a new external-primitive dependency.
- **Option A** scopes the fix to one code block in one file, preserves the existing pre-set trust path behind an explicit opt-in, and treats the env var as the test-only escape hatch it actually is (every existing pre-set is in test fixtures — fit-for-purpose lens fires green).

### Compatibility

- Production invocations: behavior unchanged when `FW_PROJECT_ROOT` is unset (99% of cases).
- Session bootstrap via `claude-session.sh` / `generate-shell-alias.sh`: unaffected — these don't pre-set `FW_PROJECT_ROOT` in a path-mismatching way.
- CI: unaffected — `actions/checkout@v6` never pre-sets `FW_PROJECT_ROOT`.
- Test-suite users: any NEW test that pre-sets `FW_PROJECT_ROOT` to a non-matching path must add `FW_ROOT_OVERRIDE=1`, otherwise the guard rewrites the value. Documented in `docs/50-TESTING.md`.

### Follow-up (not in this PR)

- Origin of the contaminating `FW_PROJECT_ROOT` in the investigator's shell session was not identified (not in profiles, not in `.envrc`). The most plausible source is that an earlier in-session script run `export`ed it from a different worktree. The guard mitigates regardless of origin; tracing the specific export chain is a follow-up investigation.

---

## Unreleased — Lead-Level MATH-VERIFY-FLAG Gate Before Commit

### Why

ADR-013/014 installed agent-side Math Verification instructions: each math-touching agent (now six: `fw-review-security`, `fw-advisor-architecture`, `fw-review-performance`, `fw-review-tests`, `fw-author-migration`, `fw-advisor-release`) is expected to invoke `/verify-math` when it makes a numeric claim, or emit `MATH-VERIFY-FLAG: [expression]` if it does not. That puts the skill at the right hand — the agent that made the claim. But a Sherlock/Holmes final gate runs multiple parallel reviewers and only the lead sees the consolidated claim stream. A claim that slips past an agent's own trigger examples (agent without a Math Verification section, unusual phrasing, numeric value dropped mid-prose without the flag) is only catchable by a lead pass.

### What changed

- **`.claude/rules/sherlock-review-gate.md`** — new `MATH-VERIFY-FLAG Protocol` subsection placed adjacent to the existing `RESEARCH_NEEDED Flag Protocol`. Four numbered behaviors for the lead: collect flags; for Critical/High findings invoke `/verify-math` and record in Decision Digest; Medium/Low = log but don't block; `MATH-VERIFY-UNAVAILABLE` = agent already downgraded, lead confirms the downgrade.
- **`.claude/rules/sherlock-review-gate.md`** — updated `Commit Criteria` with a fourth bullet: zero unresolved `MATH-VERIFY-FLAG` attached to Critical/High (verified, downgraded to qualitative, or deferred with documented reason). Mirrors the existing "zero unaddressed High" standard.
- **`.claude/rules/sherlock-methodology.md`** — one-line MATH-VERIFY-FLAG check wired into Sherlock Lite Step 5 Final Gate (above "Only commit after no Critical issues").
- **`.claude/rules/sherlock-methodology.md`** — one-line MATH-VERIFY-FLAG check wired into Full Sherlock Step 7 Final Review Gate (above "Only commit after no Critical issues and no unaddressed High issues"). Both references point at the new protocol section for the full lead-side behavior.

### Design rationale

- **Parity with RESEARCH_NEEDED** — the idiom is: agents emit structured flags, lead collects at final gate, Critical/High flags block commit unless resolved. Mirroring that structure means a single lead mental model covers both, and a future flag class (e.g., `TIME-ESTIMATE-FLAG`) can follow the same pattern without more rule prose.
- **Why a commit-gate, not just advisory** — Math Verification is specifically about the class of claim where a confidently-wrong number is worse than no number at all (users size maintenance windows, tune KDF parameters, set error budgets from these numbers). The gate is the enforcement point; per-agent instructions are the primary signal.
- **Budget** — `/verify-math` is local sympy + numpy, ~0.5–2 seconds per expression, no network cost. No measurable latency hit on the gate even when invoked on multiple findings.

### Known follow-up

- The fleet list in the protocol body (six agents) will need extension if/when Math Verification sections are added to more agents. Flagged as a maintenance touchpoint but low priority — the gate works regardless of which specific agents emit `MATH-VERIFY-FLAG`.
- `fw-stats` and the framework metrics dashboard could surface MATH-VERIFY-FLAG invocation rate and verification-vs-downgrade ratio. Deferred — collect the signal first via the existing event log before building the view.

---

## Unreleased — Extend Math Verification to Tests, Migration, and Release Advisors

### Why

`/verify-math` (ADR-013/014, shipped in v0.14.20) installed Math Verification instructions in three agents — `fw-review-security`, `fw-advisor-architecture`, `fw-review-performance`. The skill is the right defense for LLM multi-step arithmetic (GSM-Symbolic, arXiv 2410.05229: frontier models drop up to 65% accuracy on numeric reasoning), but three more agents routinely emit numbers in reviews without any guardrail — and those numbers are often load-bearing (users size maintenance windows from migration duration estimates; error budgets and canary sample sizes from release guidance; quality gates from test coverage targets).

### What changed

- **`fw-review-tests`** — Math Verification section covering coverage percentages, mutation scores, statistical sample sizes for flake detection, confidence intervals, branch-coverage deltas. Cites NIST SEMATECH e-Handbook (statistics, sample-size derivation) and IEEE 754 (floating-point coverage arithmetic). Severity-downgrade rule: drop to qualitative ("coverage is insufficient" without a specific %) when the verifier is unavailable.
- **`fw-author-migration`** — Math Verification section covering estimated row-count impact, index size projections, migration duration estimates, lock-hold window math, batch size tuning, vacuum cost projections. Explicit rationale in the section body that wrong duration estimates are dangerous because users plan maintenance windows from them. Cites NIST SEMATECH for sampling/projections, IEEE 754 for arithmetic, PostgreSQL planner/docs where relevant.
- **`fw-advisor-release`** — Math Verification section covering rollout percentages, SLO error-budget math, blast-radius estimates, canary sample size, deployment-window timing, rollback-time estimates, traffic-split ratios. Cites SRE/Google SRE workbook conventions for error-budget derivation, NIST SEMATECH for statistical sampling.

### Idiom parity

All three sections share the same GSM-Symbolic citation, the same `MATH-VERIFY-UNAVAILABLE`-triggered downgrade-to-qualitative rule, and the same `MATH-VERIFY-FLAG: [expression]` emission so a future lead-level gate (see companion PR on lead-side MATH-VERIFY-FLAG protocol) can collect flags uniformly across the fleet. Near-identical section text across all six math-touching agents is intentional — short enough that drift is cheap to fix and wide enough that the lead mental model is one idiom, not six.

### Known follow-up

- Additional agent extension candidates considered and deferred: `fw-review-forensics` (counts are measured, not calculated), `fw-review-dependencies` (CVSS is cited, not derived), `fw-review-concurrency` / `fw-review-code` (mostly qualitative — adoption would spam flags without proportionate signal). Revisit if a specific domain starts emitting numeric claims in practice.
- A companion PR adds a lead-level MATH-VERIFY-FLAG collection gate to `sherlock-review-gate.md` and the Sherlock methodology final-gate steps. That gate is the catch-all for claims that slipped past an agent's own triggers; the per-agent instructions here are the primary signal.

---

## Unreleased — Auto-Bump Description Freshness + TDD Commit Auto-Push

### Why

Two small but recurring friction points surfaced in the release workflow:

1. **`CLAUDE.md` version description drifted stale across auto-bumps.** The `auto-version-bump.yml` workflow increments the version number on every merge to `main` but its `bump-version.sh` sed is digit-only — it preserves the ` - <description>` tail from the last feature PR. After several auto-bumps, the description describes a PR shipped five versions earlier. Last seen: v0.14.13's "Auto-Approve CWE-551 Fix" description was still on `Current Version:` after patch bumps to v0.14.14..v0.14.20.

2. **Worktree-prune hazard fires on stale in-memory trap bodies** (v0.14.8 documented this: a shell that sourced `claude-session.sh` before `fw-sync.sh` rewrote the file still executes the pre-fix EXIT trap). In the last incident, unsaved work survived only because the branch had been `git push -u origin`ed early. Making "push after the first commit" a default behavior closes the gap the stale-trap bypass leaves open.

### What changed

- **New `scripts/clear-version-description.sh`** — helper that rewrites the `## Current Version: X.Y.Z - <anything>` line in CLAUDE.md to `## Current Version: X.Y.Z - (pending release notes)`. Extracted to a file so it is testable via bats (11 tests covering idempotence, multi-digit versions, em-dash/parens boundaries, hyphen-in-description negative-sample, and fail-loud on missing heading / CRLF no-match). Idempotent across successive auto-bumps — the suffix never compounds. `bump-version.sh` is unchanged; manual feature-PR bumps still preserve the author-written description.
- **`.github/workflows/auto-version-bump.yml`** — new `Clear version description to pending placeholder` step runs after `bump-version.sh` and before the commit, invoking the helper. Gated on `steps.version.outputs.skip != 'true'` like every other conditional step in the job. `CLAUDE.md` added to `paths-ignore` so a human-edited version description in a feature PR doesn't retrigger the auto-bump and get wiped. The `${{ steps.version.outputs.next }}` argument is now quoted everywhere it is interpolated.
- **`scripts/tdd-commit.sh`** — new auto-push block runs after the `git commit` succeeds. If the current branch is non-`session/*` and has no upstream tracking ref, runs `git push -u origin HEAD`. Fails open: a push error prints a WARNING to stderr (including the first line of git's stderr so secret-scanning push-protection diagnostics aren't hidden) but does not block the commit. `session/*` branches are exempt (disposable by design). Branches with upstream already set are skipped (user's normal cadence). Detached HEAD is exempt (empty `git branch --show-current` → nothing to push).
- **14 new bats tests for tdd-commit** (happy push, session exemption, slug-variant session exemption, upstream-set skip, commit-preserved fail-open, stderr-not-stdout discipline, hash-stability on push failure, detached-HEAD coverage). Isolated fixtures via `BATS_TEST_TMPDIR` + bare `git init --bare` remotes — no network touch.

### Security notes

- Workflow version-string interpolation is properly quoted and regex-validated by the script (`^[0-9]+\.[0-9]+\.[0-9]+$`) before any sed or filesystem mutation. SEd pattern uses `|` delimiter with only digits/dots interpolated — no injection surface.
- Auto-push captures git's stderr first line and surfaces it in the WARNING. This is specifically so GitHub push-protection rejections (GH001/GH002, secret-scanning) are visible to the developer rather than silently swallowed — a concern raised by fw-review-security.

### Known follow-up (non-blocking)

- **Auto-push opt-out env var** was raised by fw-review-security on the premise that RED-phase commits to a public remote could contain sensitive AC names. The user's request was specifically "make early push a post-commit habit" (belt-and-suspenders against the stale-trap hazard); adding opt-out is a behavioral-policy expansion that should be a separate decision. File if desired: an `FW_TDD_AUTO_PUSH=0` env var to disable the block while keeping it default-on for the documented repair.
- **CODEOWNERS on auto-version-bump.yml / scripts/** was flagged as a pre-existing supply-chain concern — out of scope for this PR.

---

## Unreleased — `/verify-math` Follow-Up: Soundness Guards + PyPI Bundle + Wolfram Opt-In + SAFE AST Additions

### Why

PR #133 shipped `/verify-math` (ADR-013) with sympy + numpy as test-only deps and Wolfram + AST whitelist expansion deferred. A follow-up `/deep-r` investigation (`plans/5031d8fa65ae.md`) audited the shipped state and surfaced four gaps: silent unevaluated returns from SymPy were treated as successful results; `e`/`E` resolved as free symbols instead of Euler's number; downstream `uvx shipteam init` users got the agent-body Math Verification sections but NOT the skill itself (`verify-math` was absent from `src/shipteam/framework/skills/` and `config/fw-manifest.yaml`); and the AST whitelist blocked algorithm/code-related math. The same `/deep-r` confirmed Wolfram's 2026 free-tier as 2,000 non-commercial calls/month with the vendor reserving the right to adjust at discretion (FAQ verbatim) — feasible as opt-in backup, never as load-bearing.

### What changed

- **REC 1 (soundness — fixes silent corruption)**: post-parse guard detects `sympy.Sum`, `Integral`, `Limit`, `Order` in the parsed expression (or any subexpression via `.has()`) and emits `MATH-VERIFY-FLAG: result contains unevaluated symbolic forms — SymPy could not produce a closed form` with `ok=False`. Backed by SymPy issues #21651 (Sum.doit ignores floor/ceil), #15767 (double Sum silently unevaluated), #17982/#19630/#15751 (rsolve wrong/None/hangs), #4441 (series hangs), #14567 (gamma pole repr bug) — silent unevaluated returns are SymPy's most dangerous failure mode.
- **REC 2 (soundness — fixes contract drift)**: bound `local_dict["e"] = sympy.E` and `local_dict["E"] = sympy.E`. Before this fix `e**(I*pi)` silently treated `e` as a free symbol; now resolves correctly to Euler's number.
- **REC 3 (PyPI bundle + extras)**: copied skill to `src/shipteam/framework/skills/verify-math/` (byte-identical to source); registered 3 entries in `config/fw-manifest.yaml` under `config_gate: "skills.verify_math"`; added `[project.optional-dependencies] verify = ["sympy>=1.14,<2", "numpy>=2.0,<3"]` to `pyproject.toml` (install via `uv pip install 'shipteam[verify]'`). NEW: `tests/test_uvx_extras_verify.py` creates an isolated `uv venv`, installs `shipteam[verify]`, and asserts importability + skill invocability — citing `astral-sh/uv #4762/#14558` if upstream extras bugs ever bite. NEW: `tests/test_bundle_drift.py` asserts byte-identical SHA-256 between `.claude/` source and `src/shipteam/framework/` bundle, with a meta-oracle proving the comparison itself catches drift.
- **REC 4 (Wolfram as opt-in backup)**: stdlib `urllib.request` only — no new HTTP dep. Gated entirely on `os.environ.get("WOLFRAM_APP_ID")`; without env var the Wolfram code path is dead. New CLI value `--source=wolfram`; `--source=all` extended to also include Wolfram when env var is set. Every failure (URLError, HTTP non-200, unknown exception) emits `WOLFRAM-UNAVAILABLE: <reason>` as visible caveat — never silent. Local call counter at `<cwd>/.context/metrics/wolfram_calls.json` (project-local, gitignored, sandboxable in CI); warn at `>1600/2000` calls. SKILL.md documents the 2,000 non-commercial quota AND the vendor-reserves-right-to-adjust caveat.
- **REC 5a (SAFE AST name additions)**: added `gamma, erf, floor, ceil, Min, Max` to both `_ALLOWED_NAMES` and `local_dict` (`ceil` maps to `sympy.ceiling`). Zero new AST node types — sentinel test asserts `_ALLOWED_AST_NODES` is unchanged. `factorial` deliberately deferred to a future Stage 5b (NEEDS-GUARD per /deep-r A1 verdict — requires arg cap).
- **Test infrastructure**: 3 `test_verify_math*.py` files moved from `scripts/tests/` (where pytest's `testpaths = ["tests"]` wasn't discovering them) to `tests/`. Path-walk in each adjusted from `.parent.parent.parent` to `.parent.parent`.
- **Final-gate review fixes applied pre-merge**: counter no longer resets to 1 on read OSError (silent data loss closed); `--source=wolfram` with local SymPy parse failure now emits `MATH-VERIFY-FLAG: local SymPy parse failed; Wolfram result is sole source — cross-check unavailable` so users seeing `ok=True` know the cross-check was absent; `--source=all` with no env var emits `Wolfram skipped: WOLFRAM_APP_ID not set` for observability; pre-existing `contextlib.suppress()`-no-op false-positive test from PR #133 was rewritten to actually assert non-propagation; counter race condition (no `fcntl.flock`) acknowledged in docstring as acceptable for warn purposes, not for billing.

### Test results

88 passed, 4 skipped (1 deliberate `I` whitelist test + 3 `uvx`-not-on-PATH skip-with-reason). All 6 `TestSandboxEscape` regression guards still green — REC 1+2+4+5a add no new sandbox-escape surface.

### Known follow-up

- **REC 5b** (`factorial` with arg cap of ~200) and **REC 5c** (comparison + logical ops with extras AST guards) deferred until 30 days of `category: math-verify` invocation telemetry justifies the more-complex guards.
- **`Sum`/`Product`/`Matrix`** AST whitelist additions remain explicitly out-of-scope (per /deep-r A1 verdict — UNSAFE without separate matrix-mode path / require `ast.Tuple` plus bound-check pass).
- **MCP math-server alternatives** (`mcp-server-calculator`, `Garoth/wolframalpha-llm-mcp`, etc.) remain immature in 2026 (top-star MCP math server: 148 stars, no production deployments cited per /deep-r Axis 3). Re-evaluate when MCP catalog matures.

---

## Unreleased — Retire Phase 0 Private-Repo Sentinel

### Why

The `.github/PRIVATE_REPO_MARKER` file and its enforcement infrastructure were introduced in v0.13.9 as Phase 0 of a two-repo-export plan: dev-framework was going to export to a public `cdjgroup/shipteam` template repo, and the marker gated framework self-tests so they'd skip on consumer forks. The hard sunset date `2026-07-01` was intended to force a Phase 5 cleanup on a fixed schedule.

That plan was superseded on 2026-04-13 by PyPI distribution (PR #105, `uvx shipteam init` / `npm create shipteam`). There is no second git repo to migrate to and no "consumer forks" that would run framework self-tests — consumers `uvx shipteam init` into their own projects and never clone dev-framework. The sentinel infrastructure is guarding a plan that no longer exists, and the July sunset is a deadline for a migration that will never happen.

This change retires the sentinel now instead of waiting another ~73 days.

### What changed

- **Deleted** `.github/PRIVATE_REPO_MARKER` (the content-signed marker file)
- **Deleted** `.github/workflows/sentinel-sunset.yml` (the daily scheduled overdue-check that PR #134 just fixed — fixing a workflow file on its way to deletion is not wasted work; the fix let us verify the retirement removes a previously-parsing, previously-green workflow)
- **Deleted** the `sentinel-check` job in `.github/workflows/ci-cd.yml` (lines 67-104 of the pre-retirement file)
- **Simplified** `framework-tests`: removed `needs: sentinel-check` and the `is_private == 'true'` clause. Job now runs unconditionally on every push/PR (still gated by `!inputs.fast_deploy` for hotfix bypass).
- **Simplified** `framework-tests-macos`: removed `needs: sentinel-check` and the `is_private == 'true'` clause. Job still gated by `github.event_name == 'pull_request'` (unchanged).
- **Deleted** the "TEMPORARY: Framework-Tests Sentinel Gate" section in `docs/20-DEPLOYMENT.md` (11 lines documenting the mechanism + Phase 5 checklist that is now executed).

### Why this is safe

- The marker was referenced ONLY by the two workflow files being deleted and the docs section being deleted. Zero references in `scripts/`, `test/`, `scripts/tests/`, `.claude/hooks/`, `.claude/rules/`, `pyproject.toml`, or `CLAUDE.md` (grep-verified before the retirement).
- Removing the skip mechanism is the correct post-PyPI behavior — framework tests should run on every PR in this repo, and there are no consumer forks to protect.
- `quality-gate` still `needs: framework-tests` and still fails on `framework-tests.result == 'failure'`. Required-check semantics unchanged.
- `actionlint` clean on the modified workflow.

### Insight

The `PRIVATE_REPO_MARKER` line 4 referenced `.sherlock-plan-two-repo-export.md` as its "REMOVED_IN" anchor. That plan file was deleted earlier in this release cycle — so the sentinel was holding a reference to a document that no longer existed. When a safety gate points at a ghost, that's the clearest possible signal it should come down. PR #134 fixed the parse bug in `sentinel-sunset.yml` specifically so this retirement could verify-before-delete: a green run on the fixed workflow confirmed we're retiring working infrastructure, not buried-broken infrastructure.

---

## Unreleased — Meaningful Session Branch Names (`-m/--memo` flag)

### Why

`claude-session.sh` auto-generated session branch names as `session/claude-YYYYMMDD-HHMMSS`. Timestamps are opaque — after ~40 accumulated sessions, finding the branch associated with a specific piece of work is a scan-every-line exercise. The explicit-branch-name path has always existed, but user-driven discipline is a weak forcing function.

### What changed

- New `-m SLUG` / `--memo SLUG` flag on `scripts/claude-session.sh` appends a short purpose slug to the auto-generated branch name:
  ```
  ./claude-session.sh -m sentinel-fix
  → session/claude-20260419-024913-sentinel-fix
  ```
- Slug validation is a strict allowlist: `^[a-z0-9]([a-z0-9-]{0,38}[a-z0-9])?$`. Lowercase alphanumeric + hyphens only, 1-40 chars, no leading or trailing hyphen. Rejects shell metacharacters, path separators, uppercase, and values that look like flags. Fails fast before any side-effecting git/worktree operation.
- Rationale: the slug ends up in a git branch name, a worktree directory path, and branch-ref operations. The project's auto-approve hook was hardened for exactly this CWE-551 class of concern in v0.14.13, so the new surface follows the same canonicalize-before-authorize discipline.
- Mutual exclusion with an explicit branch-name argument (e.g. `./claude-session.sh feature/x`) — memo only customizes the auto-generated name.
- New `--print-branch-name` testability flag computes the branch name and exits without creating a worktree. Used by the new bats test file.
- 15 bats tests in `test/session_memo_flag.bats` cover happy path (short + long flag), fallback, validation (uppercase / shell-metachars / path-separators / leading+trailing hyphens / length), boundary (40-char slug), and mutual-exclusion with explicit branch.

### Backward compatibility

- Zero-argument invocation still produces the historical `session/claude-YYYYMMDD-HHMMSS` form.
- Explicit-branch-name invocation (`./claude-session.sh feature/x`) unchanged.
- No change to worktree lifecycle (disposable for auto-generated, preserve for explicit — memo slugs follow the auto-generated lifecycle).

---

## Unreleased — Benchmark Harness v1 Phase 2 Part 1: Drivers

### Why

ShipTeam Benchmark Harness v1 aims to run identical coding tasks through multiple AI coding agents (Claude Code, Aider, Factory Droid) and produce apples-to-apples measurement. Phase 2 Part 1 builds the driver layer: three adapters that each expose a uniform `DriverResult` so downstream scorers (Phase 2 Part 2) and harness guards (Phase 2 Part 3) can treat all three tools interchangeably. This PR ships only the drivers — no scorers, no top-level CLI yet — but the contract surface is stable.

### What changed

- **Three drivers at `drivers/`**: `ClaudeCodeDriver` (via Claude Agent SDK — native cost), `AiderDriver` (subprocess + stdout regex — scraped cost), `DroidDriver` (subprocess + `-o json` single-object parsing — scraped cost). All three conform to a shared `Driver` Protocol defined in `drivers/_protocol.py` and return a uniform `DriverResult` dataclass with nullable `input_tokens`/`output_tokens`/`cost_usd` plus mandatory `cost_source` / `cache_strategy` / `cli_version` metadata.
- **Shared helper** `drivers/_subprocess_helpers.py::make_aborted_result()` consolidates the `subprocess.TimeoutExpired` / `FileNotFoundError` abort path that Aider and Droid share.
- **Cost extraction** at `drivers/_cost_extraction.py` — `extract_aider_cost` (regex on real-captured stdout format, stable since Aider v0.52+) + `extract_droid_json_cost` (single-object JSON parser with documented Phase 2 Part 1 ASSUMPTION marker pending empirical verification in Part 2).
- **144 tests** covering driver contracts (T-7/T-8 P0 protocol tests), cost extraction, cache-disable behavior, and abort paths. Two full `/deep-r`-backed review cycles caught 8 Critical findings including a data-corruption bug where `proc.returncode != 0 + non-JSON stdout` would have produced silent false-success results on every Droid subprocess crash.
- **Research-driven corrections**: `/deep-r` validated external-tool assumptions against Tier A/B sources (Aider source code at multiple tags + HISTORY.md; Factory docs + changelog; pypi.org). Outcome: Aider PyPI name is `aider-chat` (not `aider` — silent-install footgun); Aider format has been stable since v0.52+ (not the speculative v0.61/v0.64/v0.83 pins); Droid task arg is positional-or-`-f <file>` (not a flag); Droid `-o json` mode is preferred over `-o stream-json` for measurement use cases (simpler schema, avoids known stdout-buffering bug class).
- **Design discipline**: `drivers/droid.py` + `drivers/_cost_extraction.py` carry `TODO(phase-2-part-2)` markers for the Droid `usage` sub-object shape assumption. The marker lives in CODE (not just in `.sherlock-plan.md`'s Pivot Log) because plan artifacts are deleted at Sherlock Step 8 while code persists.
- **Optional dependencies**: `pyproject.toml` gains `[project.optional-dependencies]` entries `benchmark-aider` and `benchmark-claude` so the harness's external-tool dependencies are declared and installable via `pip install shipteam[benchmark-aider]` — surfaces the `aider-chat`-vs-`aider` footgun at install time.
- **Test infrastructure**: `tests/drivers/conftest.py` autouse fixture mocks `importlib.metadata.version` so tests can run without `aider-chat` / `claude-agent-sdk` installed locally. Docstring warns future test authors about the semantic trap (assertions on `driver_metadata["cli_version"]` need their own patch).
- **Insight #27** added to `docs/70-INSIGHTS.md` — captures the mid-stream-telemetry-vs-correctness trade-off.

### Known follow-up (Phase 2 Parts 2 & 3)

- **Phase 2 Part 2**: scorers (`mutation.py`, `injected_bugs.py`, `semgrep.py`) + empirical-capture verification of the Droid `-o json` usage shape (resolves the `TODO(phase-2-part-2)` markers).
- **Phase 2 Part 3**: harness guards (`budget.py`, `wall_clock.py`, `sdk_version_gate.py`) + top-level CLI that wires the drivers to tasks.
- **Deferred non-blocking cleanups**: ~20 pre-existing Droid tests still use `return_value=proc` subprocess mocking instead of dispatch-based; stderr diagnostic surfacing in `driver_metadata` when subprocess returns non-zero; `ClaudeCodeDriver.sdk_version()` could cache its `importlib.metadata.version` lookup.

### Not shipped in this PR

- No CLI entry point yet — drivers are called from tests only. Top-level `shipteam bench` command lands in Phase 2 Part 3.
- No empirical capture of real `droid exec -o json` output — that requires a FACTORY_API_KEY + Phase 2 Part 2 container infrastructure. The current `usage`-sub-object shape is a documented assumption pending verification.
- No ADR extraction — per Sherlock methodology Step 8, ADR-011 (benchmark harness architecture) extracts when Phase 2 completes (Parts 2 + 3 done), not mid-phase.

---

## [v0.14.14] — `/verify-math` Skill + Agent Math-Verification Sections

### Why

A `/deep-r` investigation found the framework handles discrete classification math (LOC bands, CC counts, cost-per-agent tables) but lacks any mechanism for continuous quantitative reasoning — Argon2 parameter derivations in `fw-review-security`, cost/latency projections in `fw-advisor-architecture`, P50/P95/P99 budgets in `fw-review-performance` were all unchecked LLM arithmetic. Published benchmarks (GSM-Symbolic, arXiv 2410.05229) show frontier models drop up to 65% accuracy on multi-step numerical reasoning, which is load-bearing for review recommendations the team acts on.

### What changed

- **New `/verify-math` skill** at `.claude/skills/verify-math/` — symbolic (`sympy`) + numeric (`numpy` via `lambdify`) cross-verification with authoritative source citation (NIST DLMF, SEMATECH e-Handbook, IEEE 754). CLI entry: `python3 .claude/skills/verify-math/verify.py "<expression>" [--source=sympy|numpy|all] [--domain=...]`. Exit codes: 0 verified, 2 MATH-VERIFY-UNAVAILABLE (missing deps), 3 FAIL (parse rejection or disagreement).
- **Math Verification section** appended to `fw-review-security.md`, `fw-advisor-architecture.md`, `fw-review-performance.md` — each instructs the agent to invoke `/verify-math` for domain-specific numeric claims and emit `MATH-VERIFY-FLAG` rather than confident unchecked arithmetic. Near-identical section text across all three is intentional (short enough that drift is cheap to fix).
- **Event logging** — successful skill invocations append `{"event": "math_verify", "category": "math-verify", "data": {...}}` to `.context/metrics/events-YYYY-MM.jsonl` so invocation frequency can inform a future decision to promote the skill to a dedicated agent.
- **Security hardening (caught at final gate, all fixed before merge)**: the initial implementation used `eval()` with a `{"__builtins__": {}}` sandbox + whitelisted NumPy namespace — a **known-broken Python sandbox** that a reviewer reproduced as RCE via `sqrt.__class__.__mro__[-1].__subclasses__()` reaching `BuiltinImporter` → `os.system`. Separately, SymPy's `parse_expr` internally invokes `eval` with `__builtins__` accessible — `__import__('os').system('echo pwned')` printed `pwned` during testing. The fix:
  - Removed the raw `eval()` path entirely; numeric evaluation now uses `sympy.lambdify(parsed_expr, modules="numpy")` on the AST produced by `parse_expr` (no user string reaches eval).
  - Added `_prevalidate_expression()` — an `ast.parse`-based pre-filter that walks the raw string and rejects any node outside a strict whitelist (`BinOp, UnaryOp, Constant, Name, Call, Pow, Mult, Div, Add, Sub, Mod, USub, UAdd, FloorDiv, Load`) or any name outside `{sqrt, pi, exp, log, sin, cos, tan, integrate, x, y, z, n, e, E}`. This blocks attribute access, subscripts, starred args, string literals, and unknown identifiers BEFORE the input reaches parse_expr.
  - Added DoS cap: int-constant literals over 10,000 rejected (blocks `2**99999` from locking the parser for minutes computing a 30k-digit integer).
  - Wrapped parse/evaluation in broad exception catches (`ValueError`, `OverflowError`, `MemoryError`, `RecursionError`, `ArithmeticError`, `TypeError`) so pathological inputs produce `ok=False` with a caveat rather than propagating uncaught exceptions.
  - Six regression tests in `TestSandboxEscape` guard the boundary.
- **Dependency delta** — `sympy>=1.14,<2` + `numpy>=2.0,<3` added to `requirements.in` as **test-only deps** (production code remains stdlib-only; the shipped skill fail-closes with `MATH-VERIFY-UNAVAILABLE` if end-users don't have them installed). Lockfile regenerated via `pip-compile --generate-hashes`. All three packages (including transitive `mpmath==1.3.0`) are BSD-3, MIT-compatible, 0 CVEs at pinned versions.

### Known follow-up

- The skill is lead-invoked only — Claude Code issues #29441 / #38719 prevent `skills:` frontmatter from attaching a skill to a subagent, so the three math-touching agents carry inline instructions rather than a skill reference. Revisit when upstream is fixed.
- Per `/deep-r` REC 3: collect 30 days of invocation signal via the JSONL events before deciding whether to promote this to a dedicated agent.
- Wolfram Alpha integration intentionally NOT added (the "2000/month free tier" claim is unverified and the official pricing page did not render during Phase 3 research); SymPy/NumPy locally are the primary verifier. If a user wants Wolfram corroboration later, add it as an optional third source.

---

## [v0.14.13] — Auto-Approve CWE-551 Fix (Canonicalize-First)

### Why

PR #125 (v0.14.2, "branch-deletion three-tier policy") added a prefix-matching auto-approve path for `session/claude-*` and `dependabot/*` branch deletions. The prefix match used `re.match(auto_ok, branch_name)` which anchors to the start of the string but does not require a full match — any shell metacharacter embedded in the branch name passes the authorization check. The compound-command guard that was meant to catch this class of bypass ran AFTER the approve decision, not before.

Final-review security scan (fw-review-security, domain authority for safety infra) empirically verified seven bypass variants of the same CWE-551 class still auto-approved on `main` as of v0.14.12. Representative examples:

- `git branch -d session/claude-$(curl${IFS}evil)` — auto-approved
- `git branch -d session/claude-ok&&payload` — auto-approved
- `rm -rf /tmp/safe$(evil)` — auto-approved (same class, different approve path)
- `git branch -d session/claude-${X:-evil}` — auto-approved (parameter expansion variant)
- `git branch -d session/claude-$FOO` — auto-approved (bare variable variant)
- `git branch -d session/claude-*` — auto-approved (glob expansion variant)

Any project that ran `fw-sync.sh` since v0.14.2 has the vulnerable hook.

### What changed

- **Canonicalize-first restructure** (`.claude/hooks/auto_approve_base.py`). `has_shell_operators` is now computed early (after env-prefix strip, before the dangerous-commands stack). The rm-rf safe-path approve and the branch-delete session-prefix approve each carry an inline CWE-551 guard that falls through to user prompt when shell metacharacters are present. A final compound-guard fall-through at the original position preserves the "dangerous-cmd-wins" invariant — compound commands containing hard-block-worthy rm-rf or DROP still hard-block.
- **Compound-guard regex extended**. Added `\$` (catches `$()`, `${var}`, `$VAR`, `$'...'`, `$"..."`), `&` (backgrounding, `&&` chaining), `<` (input redirection, `<<` heredoc), `*` (glob that breaks authorize-equals-execute invariant), and `\\\n` (backslash line continuation).
- **`duration_ms` instrumentation** on approve/block event-log entries (monotonic clock, fire-and-forget). Fall-through paths remain unlogged — deferred to a separate PR so the core fix stays focused.
- **22 new bats tests** covering F1/F2/F3 original bypasses, `${var}`/`$VAR`/`$'...'` parameter-expansion variants, `*` glob, backslash line continuation, and three regression guards that lock in legitimate session-branch / safe-rm-rf / protected-branch behavior. Total safety_gate.bats suite: 105 -> 127 tests.

### UX regression (accepted)

- Curl GETs with multi-parameter query strings (`curl ...?a=1&b=2`) now fall through to user prompt because `&` is in the compound-guard regex. Single-parameter `?q=hello` still auto-approves. Workaround: approve at the prompt, or switch to `-G --data-urlencode` for parameter construction.
- Glob `?` (single-character match) is intentionally NOT in the compound-guard regex because it collides with URL query syntax. The `?` glob exploit is narrower than `*` (requires matching files in cwd) — deferred to a follow-up if it surfaces.

### Known follow-up

- `cmds_to_check` set is defined in the early compound-guard block but consumed much later downstream. Currently safe but latent reordering hazard — noted in review digest, not blocking.
- `_HOOK_START_TIME` global naming could be `_hook_start_time` per PEP-8 for mutable module state. Style only; not a regression.
- Fall-through path event-log instrumentation (beyond approve/block) was intentionally out of scope. Track as separate Sherlock if the missing signal is load-bearing.
- Downstream remediation: `.claude/hooks/auto_approve_base.py` is on replace policy in `config/fw-manifest.yaml`. Projects that ran `fw-sync.sh` since v0.14.2 carry the vulnerable version. Re-sync after this ships.

---

## [v0.14.11] — Conformance Scorer v2 + Insights Drill-Down

### Why

A `/deep-r` investigation on 2026-04-17 found the existing `scripts/fw_conformance.py` had four silent-pass bugs (`_compute_review_gate` always returned 1.0; `_compute_hook_compliance` / `_check_scope_creep` returned 1.0 on empty signals; `_check_ac_coverage` self-matched the plan file at repo root via rglob with no filename filter), pinning composite >= 0.85 for any fresh project regardless of actual behavior. Separately, the scorer's output shape (nested `scores.composite`) did not match the dashboard's reader (top-level `composite_score`) — the integration had never worked end-to-end. Multi-project drill-down was asked for but missing.

### What changed

- **Inconclusive sentinel** — `_compute_hook_compliance`, `_compute_review_gate`, `_check_scope_creep`, `_check_ac_coverage` return `None` on absent signal. `_compute_composite` returns `(composite, coverage_ratio)` tuple and excludes `None` from BOTH numerator and denominator (OpenSSF Scorecard pattern). All-`None` input yields `(None, 0.0)` — never `ZeroDivisionError`.
- **Scorecard schema v2** — `save_scorecard` writes top-level `schema_version=2`, `timestamp`, `composite_score`, `components` (preserving `None` as JSON `null`), `session_id`, `plan_hash` (sha256 first 12 hex), `git_sha`, `base_ref`, `sherlock_tier`, `branch`, `project_root`.
- **AC coverage self-match fixed** — `_check_ac_coverage(acs, test_dir, plan_path=...)` excludes the plan file and filters rglob to test-file patterns (`test_*.py`, `*_test.py`, `*spec*.py`, `*.test.ts`, `*_test.go`, etc.). Zero matches → `None` (inconclusive). 2-arg legacy callers keep scan-all for backward compat.
- **Dashboard v1/v2 partition** — `aggregate_conformance` excludes `schema_version != 2` scorecards from aggregates; surfaces them in `legacy_count`/`legacy_files` (basenames only — path-leakage property enforced). `load_scorecards` attaches `_source_file`. Dashboard renders a visible "N legacy scorecard(s) detected — re-score required" warning.
- **Drill-down via native `<details>`** — `renderFrameworkStats` wraps each project row in a `<details>`/`<summary>` Detail column showing per-project scorecard breakdown, legacy warning, and component averages. Zero new dependencies.
- **Session ID column** — session table adds a `Session ID` column (first 8 chars as `<code>`; full SID on hover) so future click-to-plan-diff drill-down has a user-visible anchor.
- **Skipped-project visibility** — new `discover_fw_projects_with_skipped()` returns `{found, skipped}` where `skipped` carries a reason per corrupt `framework.yaml` (previously silently dropped).
- **Measurement-only disclaimer** — both dashboards now carry the literal sentence "Measurement only — do not gate merges or deployments on this aggregate."
- **ADR-011** — pins the scope boundary between Phase A (this PR) and the queued Phase B benchmark harness work, so schema v2 forward-extends instead of getting rewritten.

### Known follow-up

- `project_root` absolute path sanitization deferred to Phase B (TODO comment in `_compute_schema_version_2_enrichment`); `.context/metrics/` is gitignored so the current surface is low-risk.
- 2-arg legacy `_check_ac_coverage` callers remain exposed to the self-match bug by design — migration happens gradually.
- Phase B (cross-agent benchmark harness) is a separate queued plan; schema v2 is the substrate it will extend.

---

## [v0.14.7] — Safety Limits Doc + ADR-007 Bright-Line CI Enforcement

### Why

ADR-007 (public-repo bright-line sanitization) has been policy-only since v0.13.0 — the categories it bars (see the ADR for the exact enumeration) were forbidden in the committed tree, but nothing automated the gate. The "Wheel content audit gap" left PyPI releases one careless commit away from leaking policy-barred content. Separately, the CONTRIBUTING.md overlay rule framed the base safety gate as a singular enforcement boundary, which overstates what client-side Claude Code hooks can guarantee in the presence of the many upstream bypass vectors documented in `docs/85-SAFETY-LIMITS.md`. Both gaps combine into a credibility risk when external reviewers look closely before v1.

### What changed

- **New `docs/85-SAFETY-LIMITS.md`** — honest accounting of what the framework's hooks and rules enforce, what they don't, known Claude Code bypass vectors (with upstream issue citations), layers enabled by default vs. user-owned opt-in hardening, and documented escape hatches. Linked from `CLAUDE.md`, `docs/00-README.md`, and `docs/35-SECURITY.md`.
- **ADR-007 flipped to ACCEPTED** with an enforcement section naming the new CI + pre-commit machinery.
- **New `scripts/validate-no-bright-line.sh`** — regex-based scanner for bright-line patterns (pricing with period suffix, round-size signalling, valuation/revenue comparables, GTM keywords, private-path references). Supports self-exempt list for policy-defining files, `config/bright-line-allowlist.txt` for whole-file exemptions, and inline `<!-- bright-line:allow reason="..." -->` suppress comments.
- **New `.github/workflows/bright-line-check.yml`** — standalone workflow with the `bright-line-guard` job, fail-closed on finding. Kept out of `ci-cd.yml` on purpose: `ci-cd.yml` on main currently fails to parse (pre-existing `hashFiles()` used in a job-level `if:` at the sentinel-check job, caught by actionlint), so any new job added there would never execute. Separating also means an unrelated future regression in `ci-cd.yml` cannot silently disable the policy gate.
- **New `.pre-commit-config.yaml`** wiring both `validate-no-bright-line.sh` and the existing `validate-no-public-secrets.sh` for sub-second local feedback.
- **New `docs/20-DEPLOYMENT.md` section** on enabling branch protection with `gh api`, including the `bright-line-guard` context.

### Known follow-up

- `.sherlock-plan-two-repo-export.md` is a stale Sherlock plan artifact (ADR-007 already extracted from it). Per Sherlock methodology, it should have been deleted at extraction time. Currently allowlisted as a TEMPORARY exemption in `config/bright-line-allowlist.txt`; queue a cleanup commit to delete the file.
- Branches `feature/enterprise-positioning` and `research/competitive-landscape` are stale (last real content from v0.5.0 era). Queue for deletion.
- Upstream Claude Code [PR #33390](https://github.com/anthropics/claude-code/pull/33390) ("hook-integrity-guard security plugin") is OPEN and covers the same pattern that would have motivated a ShipTeam-side integrity check. Deferring any local hook-integrity work pending that PR.

---

## [v0.14.3] — Branch Deletion Hook: Three-Tier Policy Alignment

### Problem

`auto_approve_base.py` hard-blocked ALL branch deletion unconditionally (lines 202-209). The global CLAUDE.md policy was updated 2026-04-15 to specify a three-tier model (Auto-OK / Always ASK / Always REFUSE), but the hook still enforced the old blanket block. Result: Claude couldn't help with routine branch cleanup that the policy now permits.

### Fix

Rewrote the branch-deletion section of `auto_approve_base.py` to implement the three-tier policy:
- **Always REFUSE** (hard block): protected branches (`main`, `master`, `develop`, `release/*`, `hotfix/*`)
- **Auto-OK** (auto-approve): `session/claude-*` and `dependabot/*` branches via safe delete (`-d`)
- **Always ASK** (fall through to user prompt): everything else, including `-D` force-delete on non-protected branches

Also fixed four security issues found during review: `$`-anchored protected regex, argument-order-independent push-delete checking, quote-stripping, and flag-scoped force-delete detection.

### Files Changed

- `.claude/hooks/auto_approve_base.py` — branch deletion logic (lines 202-233)
- `test/safety_gate.bats` — 6 → 18 branch deletion tests (105 total pass)

### Migration

fw-sync will propagate to downstream projects on next sync. The change is behavioral: commands that were previously hard-blocked now either auto-approve (session/dependabot) or fall through to user prompt (non-protected). Protected branches remain hard-blocked.

---

## [v0.14.1] — Reasoning Lenses + /deep-r Adversarial Upgrades + /deep-r-audit Sibling

### Problem

Retrospective on a hook-path-resolution deadlock (Claude Code cwd drift blocking PreToolUse hook load) surfaced three latent weaknesses in `/deep-r`:

1. **Docs-as-truth bias** — `/deep-r` validates against official docs, which describe intended behavior but never document empirical failure modes. The upstream Claude Code docs recommend `$CLAUDE_PROJECT_DIR`; anthropics/claude-code#33815 documents it's empty in PreToolUse on v2.1.74+. Prior /deep-r sessions searched by feature name (found docs) not by failure mode (would have found #33815).
2. **Forward-looking-only scope** — `/deep-r` evaluates design choices at planning time. It never loops back on already-running configuration. Latent defects in existing `.claude/settings.json`, hooks, and scripts stayed invisible.
3. **Missing runtime-failure reasoning for safety infra** — hooks, middleware, auth gates have runtime states (cwd drift, missing env vars, race conditions) that docs don't flag. `/deep-r` inherited the blind spot.

Concurrently, four reasoning patterns emerged during trade-off discussion (bash vs. Python for a hook shim): *hot-path latency*, *failure-domain isolation*, *fit-for-purpose*, *explicit trade-off*. These were broadly reusable across framework decisions but had no durable home.

### Fix

Three coordinated additions:

1. **`/deep-r` SKILL.md gains three MANDATORY sections** — Adversarial Search Pass (issue-filtered + failure-keyword + version-filtered upstream search), Pre-Mortem for Safety Infrastructure (≥3 runtime failure modes with trigger/behavior/recovery/classification), Lens Consultation (enumerate which lenses applied).
2. **New sibling skill `/deep-r-audit`** — reverse-direction audit of current project config against known upstream issues, filtered by installed version and patterns actually in use. Run manually before releases, monthly on mature projects, after Claude Code upgrades.
3. **New `.claude/lenses/` directory** — 4 advisory reasoning lenses (distinct from `.claude/rules/` which are mandatory). Each lens has a fixed structure, admission bar (cited past failure required), and retirement policy. Cap ~8 total to prevent bloat.

### Files Changed

- `.claude/skills/deep-r/SKILL.md` — CREATE (framework-level; upgrades user-level version)
- `.claude/skills/deep-r-audit/SKILL.md` — CREATE
- `.claude/lenses/README.md` — CREATE
- `.claude/lenses/hot-path-latency.md` — CREATE
- `.claude/lenses/failure-domain-isolation.md` — CREATE
- `.claude/lenses/fit-for-purpose.md` — CREATE
- `.claude/lenses/explicit-tradeoff.md` — CREATE
- `config/fw-manifest.yaml` — register new content
- `CLAUDE.md` — Quick Reference + version description
- `docs/adr/010-reasoning-lenses-and-deep-r-adversarial-upgrades.md` — CREATE
- `docs/adr/README.md` — index entry
- `test/test_framework_content.sh` — CREATE (regression test for lens/skill structure)

### Migration

fw-sync will propagate to downstream projects as `policy: replace` on next sync. No manual action required. The `/deep-r` invocation pattern is unchanged — same command, expanded output. `/deep-r-audit` is new; invoke manually when desired.

### Insight

Forward-looking design validation and retrospective configuration audit are distinct modes, not variants of the same skill. Conflating them was the silent assumption that let #33815-class bugs persist. Shipping them as separate skills makes the distinction tool-level, not discipline-level — you can't forget to run the audit because the skill exists and has cadence guidance.

## [v0.14.8] — Worktree cleanup guard

### Problem

The explicit-branch-preserves fix (v0.13.17) protects the common case but two gaps remained:

1. **Auto-generated `session/*` branches still destroy on exit.** If the user accidentally did real work on one, exiting silently loses it.
2. **Stale in-memory trap bodies.** A shell that sourced the old `claude-session.sh` before `fw-sync` still runs the old destroy logic on exit, regardless of the updated file on disk. Surfaced today: a findstuff session launched at 18:17 (pre-fix) ran its pre-fix EXIT trap six hours later and wiped its worktree — the on-disk fix was irrelevant because bash had already cached the old function.

### Fix

Harden the `cleanup()` trap with a value-preserving guard:

- Uncommitted changes → preserve, print recovery command, exit.
- Non-`session/*` branch with unpushed commits (or no upstream) → preserve, print recovery command, exit.
- `session/*` branches with clean trees → destroy (unchanged).

Preserves *loudly* rather than prompting. EXIT traps run under SIGTERM, parent-shell close, and crashes where `read` hangs or auto-answers silently. Force destruction via `cleanup-worktree.sh`.

### Why a guard, not a default flip

Flipping the default to always-preserve was the first instinct but would cause steady worktree accumulation (~40 orphaned already visible on this machine). The guard targets the actual failure mode — unsaved work loss — without bloating the disposable-session workflow.

### Files Changed

- `scripts/claude-session.sh` — `PRESERVE_REASON` guard in `cleanup()`

---

## [v0.13.11] — Session vs Workspace: Explicit-Branch Worktrees Preserve by Default

### Problem

`claude-session.sh` destroyed the worktree directory on exit regardless of how it was invoked. For auto-generated session branches (`session/claude-<timestamp>`) this was correct — disposable sessions. For explicit branches (e.g. `./claude-session.sh feature/work`), it reliably produced a stale-CWD bug: any shell `cd`'d into the worktree held the unlinked inode, the next invocation recreated the path with a new inode, and Claude inherited the dead CWD ("Working directory no longer exists").

### Fix

Discriminate by branch-name origin:
- **Auto-generated branch** (no CLI arg): destroy on exit (unchanged — disposable session)
- **Explicit branch name**: preserve on exit (resumable workspace, no inode churn)

New `--clean` flag forces destruction; existing `--keep` unchanged. Entry-path resume logic was already implemented; this change stops destroying the thing resume already handled.

### Files Changed

- `scripts/claude-session.sh` — arg parsing, `--clean` flag, lifecycle default, help text

### Industry Alignment

Matches the persistent-worktree convention used by git-town, jj, gh-wt, worktreewise, and Worktrunk. See Insight #25.

## [v0.13.9] — Two-Repo Export: Phase 0 Tactical Unblock

### Summary
Phase 0 of the two-repo-export plan (see `.sherlock-plan-two-repo-export.md`). Unblocks internal users whose CI was failing on `framework-tests` because the tests hardcoded dev-framework's own stack values (python/8000, typescript/3003). Two durable engineering improvements plus one tactical CI gate that will be removed in Phase 5.

### What's new
- **Fixture-based `framework_config.bats`** — tests 4–7 now assert the reader returns whatever is in a fixture `framework.yaml`, not hardcoded values. Consumer repos with different stacks no longer fail these tests.
- **`_framework.sh` env-var override** — `FW_PROJECT_ROOT` and `FW_CONFIG` are now honored if pre-set, with realpath + containment validation (fail-closed against path traversal). Used for test isolation; also enables future tooling that needs to point `_framework.sh` at non-default locations.
- **Sentinel-gated framework-tests CI** (tactical) — `.github/PRIVATE_REPO_MARKER` content-verified check prevents framework self-tests from running in consumer forks. Gate is fail-closed on content mismatch and has a hard sunset date of 2026-07-01, enforced by a new scheduled `sentinel-sunset.yml` workflow.

### Security
- Realpath + containment check in `_framework.sh` rejects `FW_CONFIG` resolving outside `FW_PROJECT_ROOT` (catches symlink escapes). Pattern `"$ROOT"/*` requires literal `/` separator.
- Sentinel CI gate fails-closed on content mismatch rather than silently skipping tests.

### What's temporary
- `.github/PRIVATE_REPO_MARKER` + `sentinel-check` CI job + `sentinel-sunset.yml` workflow are all Phase 0 tactical. Phase 5 deletes them once internal users migrate to the planned public `cdjgroup/shipteam` template repo.

### Tests
258 bats tests pass (was 253; +5 new). Shellcheck clean. YAML valid.

### Refs
- Filed issue: framework-tests run in consumer projects and hardcode dev-framework's own stack config
- Plan: `.sherlock-plan-two-repo-export.md` (Phase 0 ACs: AC-1, AC-2, AC-3, AC-23)

---

## [v0.13.7] — `uvx shipteam init` Zero-Friction Installer (All 6 Phases)

### Summary
Replaces the 534-line `scripts/init-project.sh` bash wizard with a Python CLI distributed via PyPI (`uvx shipteam init`) and npm (`npm create shipteam`). Produces a fully-populated `CLAUDE.md` (zero CUSTOMIZE markers), scaffolds `.claude/` (23 agents, profile-filtered rules, 10 skills, 18 hooks), writes config and state, and appends `.gitignore` entries — all in ~30 seconds. Idempotent re-render via `uvx shipteam init --refresh` preserves user edits outside (and inside) managed regions by default.

### What's new
- **Python package** `src/shipteam/` — CLI (Click 8) + 8 core modules: detect, config, security, state, render, regions, source, scaffold
- **Bundled framework** — all framework content (`src/shipteam/framework/`) ships inside the wheel as package_data; no clone required
- **Managed regions** — `<!-- SHIPTEAM:BEGIN:name -->` / `<!-- SHIPTEAM:END:name -->` pattern across `CLAUDE.md.jinja` enables framework updates without overwriting user customizations
- **Preservation-default refresh** — `--refresh` preserves user-edited managed regions (warns); `--force` overrides (warns)
- **Version handshake** — `min_cli_version` + `schema_version` in `framework-meta.yaml` (forward-compatible: CLI `>=` schema accepts older sources)
- **npm shim** — `create-shipteam` Node package detects Python runtime (`uvx > pipx > python3 -m shipteam`) and delegates via `spawnSync(shell:false)`
- **Security hardening**: Jinja2 `ImmutableSandboxedEnvironment` blocks SSTI; symlink-refused source trees and destinations; `--repo` regex validation blocks marker-injection; atomic state writes (`os.replace`); typed exit codes (0/1/2/3/4) with all errors routed to stderr
- **133 passing tests** + 1 documented xfail (CliRunner cannot simulate `isatty()=True` with `input=` — covered by manual TTY QA)

### BREAKING
- `scripts/init-project.sh` deleted. Use `uvx shipteam init` instead. Documentation across SETUP.md, QUICKSTART.md, README.md, CONTRIBUTING.md, docs/ADOPTION.md updated.
- `config/framework.yaml` now has a top-level `schema_version: 1` field (required for the version handshake).

### Review
Per-phase Sherlock review pipeline ran for every phase (fw-review-code, fw-review-security, fw-review-tests, fw-review-forensics on 500+ LOC phases). Every HIGH finding across Phases 2-6 was fixed inline before commit. Zero Critical, zero unaddressed High. Medium/Low findings are tracked in commit messages for follow-up PRs.

### Documentation cleanup (bundled)
- Fixed stale version refs across `README.md`, `CLAUDE.md`, `docs/index.md` (audit revealed `0.13.1` badge, `v0.1-v0.6` feature range, `Last Deploy: 2026-03-30 v0.9.0` marker all stale against current `VERSION=0.13.4`)
- Consolidated `CLAUDE.md` Quick Reference: removed 12 rows duplicating `docs/00-README.md` Document Structure table, added single pointer. Retained Rules/Skills/Agents/Scripts/Hooks/Config rows (genuine shortcuts, not covered by 00-README)
- Net: -35 lines from CLAUDE.md Quick Ref, zero broken links (fw-review-docs verified)
- Archived v0.1.0–v0.12.0 release notes to `docs/archives/ARCHIVE_RELEASES_v0.1-v0.12.md`; `release_notes.md` trimmed 684 → 83 lines. Keeps current Unreleased + v0.13.0 + template in the active file. (Note: also swept up an orphaned duplicate "Unreleased - Session Lock at Startup" header from the v0.10 era.)

---

## [v0.13.8] — Enhanced Lead Orchestrator: Artifacts-Over-Reasoning (Insight #24)

### Summary
Adds a new agent (`fw-author-test-strategy`), two new plan-artifact sections (`Lead Judgment`, `Decision Digest`), and a Step 0 user-preference lens. Evidence-backed via a Full Sherlock /deep-r that found the highest-leverage innovation for this framework is **persisted artifacts**, not thicker synthesis. Rejected devil's-advocate and debate-layer patterns as evidence-negative. Ships behind Full Sherlock: all 8 steps completed including Step 4.5 plan red-teaming.

### What's new
- **New agent**: `fw-author-test-strategy` — proactive test matrix author. Produces `.test-matrix.md` with risk-tiered tests (P0/P1/P2), oracle hints for non-obvious ACs, and phase mapping. Invoked ONCE per plan (Sherlock Lite Step 1 / Full Sherlock Step 4.5 post-validation); exempt from Hudson and doc-only changes.
- **Plan format**: `.sherlock-plan.md` gains `## Lead Judgment` (Priority Stack + Risk Watch — externalized priority, anti-snacking gate per Larson/Fournier) and `## Decision Digest` (append-only review outcomes; always written — even zero findings is a signal).
- **Step 0 User-Preference Lens**: classification output now begins with a single-line `User context: [up to 3 memory entry titles]` citation derived from auto-loaded MEMORY.md. Hard bounds: ≤3 titles, ≤200 chars, single line. Lets memory-learned preferences inform workflow routing without re-asking.
- **ADR 009** captures the architectural decision and alternatives considered (devil's-advocate/debate/synthesis approaches rejected with citations).

### Changed
- `fw-review-tests` now consumes `.test-matrix.md` at every per-phase review: missing P0 = Critical, P1 = High, P2 = Medium. Malformed matrix → Medium with fallback to standard behavior (no pipeline block).
- `sherlock-methodology.md` Step 0 prepends the user-preference lens; Steps 1, 4.5, 6, 8 wire in the test-strategy invocation, Decision Digest appends, and matrix deletion on cleanup.
- `sherlock-review-gate.md` adds test-strategy to the Agent Selection Guide and adds file-type skip rules for doc-only plans.

### Security (CRITICAL — ADR-007 bright-line sanitization)
- No-persist rule for MEMORY.md content enforced in FOUR locations (methodology Step 0, spec-format Lead Judgment, spec-format Decision Digest, test-strategy agent Scope Constraints).
- The `User context:` line lives in live conversation only — NEVER in `.sherlock-plan.md`, `.test-matrix.md`, Decision Digest, Pivot Log, Lead Judgment, `.claude/state/*`, or any Write/Edit tool content.
- MEMORY.md body content forbidden everywhere, including conversation output (titles only). Applies because MEMORY.md titles themselves can encode strategy (pricing, revenue, platform risk per the live memory store).

### Research basis (primary sources cited in ADR 009)
- Anthropic "How we built our multi-agent research system" (2025) — thick planning + thin execution, file-based artifact passing
- Cognition "Don't Build Multi-Agents" — coding is tightly interdependent; multi-agent is the wrong shape
- "When Agents Disagree" (arXiv 2603.20324) — selection > synthesis
- Self-Refine / debate literature (Nature npj AI, arXiv 2511.07784) — self-critique underperforms
- Larson / Fournier — effective leads produce written artifacts (plan, ADR, priority list)

### Review
Full Sherlock executed: /deep-r at Step 3 (3 parallel research agents), Step 4.5 red-team on written plan (4 Critical/High caught before coding). Final review gate: fw-review-code (0 Critical, 0 High, 2 Medium, 2 Low — all addressed in situ), fw-review-docs (identified doc updates, applied), fw-review-security (1 Critical + 2 High on memory-leak vectors — all fixed before commit), fw-review-forensics (APPROVE — no AI tells, no hallucinated refs, no safety-guard removals). Zero unaddressed findings.

### Compatibility
- Additive. Projects without the new agent synced will keep working (fw-review-tests falls back to standard behavior when `.test-matrix.md` is absent).
- Downstream `fw-sync.sh` adoption delivers the new agent and methodology updates on next sync.

---

## v0.13.0 — Remove Feature Tier Gating (BREAKING)

### Summary
The `feature_tier` config section has been removed from `config/framework.yaml` and tier-conditional branches have been stripped from `.claude/rules/sherlock-methodology.md` and `.claude/rules/sherlock-review-gate.md`. All 22 agents, all 4 workflow modes, and the full multi-agent parallel review pipeline are available to every user unconditionally. Decision rationale is captured in `docs/adr/006-remove-feature-tier-gating.md`.

### BREAKING
- Projects that carry a local `feature_tier:` section in their own `framework.yaml` should delete that section. No Python or shell code reads `feature_tier`, so the change is documentation/rules-level and will not fail at runtime, but strict YAML schema validators may flag an unknown key if one is preserved. Run `uvx shipteam init --refresh` if your project was scaffolded from an earlier version.

### Removed
- `feature_tier:` section from `config/framework.yaml` (agent lists and capability keys — no replacement)
- "Feature Tier Gate" section from `.claude/rules/sherlock-review-gate.md`
- Per-tier conditional branches from `.claude/rules/sherlock-methodology.md` Steps 4, 5, 6, 7
- Five historical entries from `docs/70-INSIGHTS.md` that documented the earlier gating rationale

### Added
- `docs/adr/006-remove-feature-tier-gating.md` — decision record for the gating removal
- `docs/adr/007-public-repo-bright-line-sanitization.md` — decision record capturing the bright-line policy that governs what commits may enter the tree ahead of the eventual public-repo export

### Changed
- `docs/60-FEATURES.md` — `Tiers` row removed from Workflow Coverage table; the legacy Feature Tiers subsection is replaced with a new "Remove Feature Tier Gating — All Agents Available" entry
- `docs/ADOPTION.md` — "Feature Tiers vs Complexity Profiles" section removed; "Complexity Profiles" section is now the sole licensing-orthogonal control
- `QUICKSTART.md` — setup prompt and "What Just Happened?" table no longer reference a tier at setup time; Week 2+ row reframed around `profile: full`
- `README.md` version badge — catches up from 0.11.0 to 0.13.0 (the 0.12.0 bump missed the badge update)

### Version Bump
- `VERSION`: 0.12.0 → 0.13.0
- `CLAUDE.md` Current Version line updated
- `README.md` badge updated

---

## Older Releases (v0.1.0 – v0.12.0)

Archived to [`docs/archives/ARCHIVE_RELEASES_v0.1-v0.12.md`](docs/archives/ARCHIVE_RELEASES_v0.1-v0.12.md) to keep this file focused on recent versions. Full PR-level detail preserved there for auditing.

---

<!-- Template for future releases:

## vX.Y.Z - Title (Insight #N)

### Summary
Brief description of what changed.

### Changes
- Change 1
- Change 2

### Breaking Changes
- None

### Migration Steps
- None required
-->
