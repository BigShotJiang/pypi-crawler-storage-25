# First-Time Setup Guide

This guide walks through setting up ShipTeam for a new project.

## Fastest Path: Let Claude Set It Up

If you already have Claude Code installed, it can handle the entire setup:

```bash
gh repo create my-project --template cdjgroup/dev-framework --private
cd my-project
claude
```

Then tell Claude something like:

> Set up this project for me. My repo is `myorg/my-project`. I'm building a
> Python/FastAPI backend on port 8000 and a Next.js frontend on port 3000.
> Start with the minimal profile.

Claude reads `SETUP.md` and `CLAUDE.md` automatically and will:
1. Edit `config/framework.yaml` with your project details
2. Run `uvx shipteam init` (installer — renders CLAUDE.md, scaffolds `.claude/`, writes state)
3. Copy the hooks template (`settings.local.json`)
4. Verify everything works with `./scripts/preflight.sh`

You can then follow up with:
- "Enable the standard profile" — when you're ready for Sherlock + skills
- "Set up GitHub secrets" — Claude will tell you exactly what to configure
- "Start a session on feature/my-first-feature" — begins an isolated worktree session

If you prefer to set things up manually, or need to troubleshoot, continue below.

---

## Prerequisites

- Git 2.17+ (for worktree support)
- Bash 3.2+ (macOS default is fine)
- Python 3.9+ (for Claude hooks)
- Node.js 18+ (for Claude Code CLI)
- Claude Code CLI installed (`npm install -g @anthropic-ai/claude-code`)

## Platform Setup

### macOS

```bash
brew install git python node gh
```

### Linux (Ubuntu/Debian)

```bash
sudo apt update && sudo apt install -y git bash python3 python3-pip
```

For Node.js LTS, use [NodeSource](https://github.com/nodesource/distributions):
```bash
curl -fsSL https://deb.nodesource.com/setup_lts.x | sudo -E bash -
sudo apt install -y nodejs
```

Install GitHub CLI: `sudo apt install gh` or see [cli.github.com](https://cli.github.com/).

### Windows

**Recommended: Use the DevContainer.** The included `.devcontainer/devcontainer.json` provides a pre-configured Linux environment with Bash 5.x, Python 3.12, Node.js, and Claude Code — no manual setup required. Open the repo in VS Code and select "Reopen in Container" (requires [Docker Desktop](https://www.docker.com/products/docker-desktop/)).

**Alternative: WSL (Windows Subsystem for Linux).** If you prefer working outside a container:

1. Install WSL: `wsl --install` (Windows 10 2004+ / Windows 11) — installs Ubuntu with Bash 5.x
2. Inside WSL, follow the Linux setup above
3. Install Claude Code CLI: `npm install -g @anthropic-ai/claude-code`
4. Clone the repo inside the WSL filesystem (not `/mnt/c/`) for best performance

> **Note**: Git Bash (bundled with Git for Windows) lacks the full Linux environment the hooks require. WSL or DevContainer is strongly recommended.

## Step 1: Edit Configuration & Rules

### 1a. Core Configuration

```bash
vim config/framework.yaml
```

Update these required fields:
- `project.name`: Your project name (used in worktree directory names)
- `project.repo`: GitHub repo slug (e.g., `myorg/my-project`)
- `stack.backend.*`: Your backend language, version, test command, port
- `stack.frontend.*`: Your frontend config (or remove the section if backend-only)
- `versioning.primary_source`: File to read current version from
- `versioning.locations`: All files that contain version strings

**Important — CI contract**: The CI pipeline reads `stack.backend.test_command` and `stack.frontend.test_command` from `framework.yaml`, but it only runs them if the corresponding dependency file exists:

| Stack | Dependency file | What CI does |
|-------|----------------|--------------|
| Python backend | `requirements.txt` or `backend/requirements.txt` | `pip install -r` then runs `test_command` |
| Node frontend | `package.json` or `frontend/package.json` | `npm ci` then runs `test_command` |

The setup wizard (Step 4) scaffolds these files automatically. If you remove a stack section from `framework.yaml`, CI gracefully skips that test job.

### 1b. Configure Rules and Skills

In `config/framework.yaml`, review the `rules:` and `skills:` sections:
- Set `rules.database_migrations: false` if your project has no database
- Set `skills.schema_check: false` if your project has no database
- All rules and skills are enabled by default

## Step 2: Configure GitHub Repository

### Secrets (Settings > Secrets and variables > Actions)
| Secret | Required | Purpose |
|--------|----------|---------|
| `AUTO_BUMP_TOKEN` | Yes | Fine-grained PAT with Contents: Read/Write |
| `ANTHROPIC_API_KEY` | Optional | For Claude Code GitHub Action |
| `NOTIFICATION_WEBHOOK_URL` | Optional | Discord/Slack webhook for alerts |

### Variables (Settings > Secrets and variables > Actions > Variables)
| Variable | Default | Purpose |
|----------|---------|---------|
| `PYTHON_VERSION` | 3.12 | Python version for CI |
| `NODE_VERSION` | 22 | Node.js version for CI |
| `VERSION_SOURCE` | package.json | File to read version from |

### Branch Protection (Settings > Branches)
- Protect `main` branch
- Require pull request reviews
- Require status checks: `quality-gate`

## Step 3: Install Claude Hooks

Hooks are registered in `.claude/settings.json`, which ships with the framework — no per-project copy step is needed. The full set (auto-approve, branch-check, merge-conflict-resolver, worktree-enforcer, branch-tracker, pre-compact) is active out of the box, along with deny patterns for secret files. See `.claude/settings-guide.md` for detailed permission documentation.

If you want per-developer overrides that should not be committed (custom permissions, local-only allows), create `.claude/settings.local.json` by hand — it is gitignored and merged on top of `settings.json` by Claude Code.

## Step 4: Run the Installer

```bash
chmod +x scripts/*.sh
uvx shipteam init
```

This will:
- Render `CLAUDE.md` from the bundled template (zero CUSTOMIZE markers)
- Scaffold `.claude/` (agents, rules, skills, hooks) matching your profile
- Write `config/framework.yaml` with auto-detected stack
- Append required `.gitignore` entries
- Record state in `.shipteam-init.yaml` so `uvx shipteam init --refresh` can later
  update the framework-owned parts while preserving your custom edits

If `uvx` is unavailable, `pipx run shipteam init` or `python3 -m shipteam init`
also work. `npm create shipteam` is available for Node-native workflows.

## Step 5: Verify

```bash
./scripts/preflight.sh
```

You should see:
- Current branch displayed
- Server status (not running yet - that's OK)
- No corrupted merge state

---

## Daily Workflow: Session Isolation

**This is the most important concept in the framework.** Never run `claude` directly in your main repo checkout. Always use the session launcher — it creates an isolated git worktree so each Claude session gets its own copy of the code, its own branch, and its own lock file. Two sessions can never collide.

### Starting a Session

```bash
# From your main repo clone (not a worktree):
./scripts/claude-session.sh feature/my-feature
```

This single command does everything:

| Step | What happens |
|------|-------------|
| 1 | Creates `~/worktrees/{project}-feature-my-feature/` |
| 2 | Sets up a git worktree with branch `feature/my-feature` |
| 3 | Symlinks `.claude/settings.local.json` from main repo (shared hook config) |
| 4 | Creates per-worktree `.claude/state/` directory (session locks are isolated) |
| 5 | Symlinks `.env` files from main repo (single source of truth) |
| 6 | Installs dependencies (Python venv, npm install) |
| 7 | Starts a frontend dev server on a unique port |
| 8 | Auto-syncs with `origin/main` (fast-forward or merge) |
| 9 | Launches `claude` inside the worktree |
| 10 | Cleans up on exit (server stopped, worktree removed) |

The worktree location is configured in `framework.yaml`:

```yaml
paths:
  worktree_base: "${HOME}/worktrees"   # Each session gets a subdirectory here
```

### What the directory structure looks like

```
~/my-project/                          # Your main repo clone
  config/framework.yaml
  .claude/settings.local.json          # Original — worktrees symlink to this
  .claude/state/session-lock.json      # Main repo's own lock (if running here)

~/worktrees/                           # Worktree base (from framework.yaml)
  my-project-feature-auth/             # Session 1 (isolated copy)
    .git                               # File pointing to main repo's .git
    .claude/settings.local.json → ~/my-project/.claude/settings.local.json
    .claude/state/                     # OWN directory (not symlinked — see below)
      session-lock.json                # This session's lock (created on start)
    backend/.env → ~/my-project/backend/.env
    ...all your project files...

  my-project-feature-payments/         # Session 2 (parallel, isolated)
    .git
    .claude/settings.local.json → ~/my-project/.claude/settings.local.json
    .claude/state/                     # Its own state directory
      session-lock.json                # Different lock, different session
    ...
```

### Session options

```bash
./scripts/claude-session.sh                          # Auto-named: session/claude-20260330-091500
./scripts/claude-session.sh feature/my-feature       # Named branch
./scripts/claude-session.sh --keep feature/auth      # Don't cleanup on exit
./scripts/claude-session.sh --no-servers feature/api # Skip dev server startup
./scripts/claude-session.sh --no-sync feature/test   # Skip auto-sync with main
```

### Parallel sessions

You can run multiple sessions at the same time on different features:

```bash
# Terminal 1
./scripts/claude-session.sh feature/auth       # Gets port 3003

# Terminal 2
./scripts/claude-session.sh feature/payments   # Gets port 3004 (auto-incremented)
```

Each session gets its own frontend port (auto-assigned from `stack.frontend.port` upward). The backend is shared — start it once in the main repo.

### What protects you

Three hooks enforce session isolation:

| Hook | What it prevents |
|------|-----------------|
| `checkout-guard.py` | Blocks `git checkout` / `git switch` if another session is active on the same worktree |
| `branch-check.py` | Blocks operations if Claude is on the wrong branch (e.g., after context compaction) |
| `worktree-enforcer.py` | Blocks operations that try to escape the worktree |

If a session crashes, the lock file becomes stale. The next session detects this (checks if the PID is still alive) and reclaims the lock automatically.

### Resuming a session

If you used `--keep` or the cleanup was skipped:

```bash
cd ~/worktrees/my-project-feature-auth
claude    # Resume directly in the worktree
```

### Cleaning up manually

```bash
# Remove a specific worktree
./scripts/cleanup-worktree.sh ~/worktrees/my-project-feature-auth

# Remove worktree AND delete the branch (asks for confirmation)
./scripts/cleanup-worktree.sh ~/worktrees/my-project-feature-auth --delete-branch

# List all active worktrees
git worktree list
```

### Shell alias (optional)

For faster launching, generate a shell function:

```bash
./scripts/generate-shell-alias.sh
```

This outputs something like:

```bash
# Add to ~/.zshrc or ~/.bashrc:
claude-my-project() {
    local branch="${1:-feature/work}"
    cd "/path/to/my-project" && ./scripts/claude-session.sh "$branch"
}
```

Then you can start sessions from anywhere:

```bash
claude-my-project feature/auth
claude-my-project    # Default: feature/work
```

### Why not just run `claude` directly?

| Without session launcher | With session launcher |
|---|---|
| Work directly on main — one bad commit affects everyone | Each session is an isolated branch |
| Two sessions edit the same files — merge conflicts, lost work | Lock files prevent collision |
| Context compaction forgets your branch | `branch-check.py` catches mismatches |
| Manual `git checkout -b` + `cd` + setup | One command handles everything |
| `.env` files copied (diverge over time) | `.env` files symlinked (single source of truth) |
| Dependencies may be stale | Fresh `pip install` / `npm install` per session |

---

## Worktree Architecture: End-to-End Flow

This section explains the full lifecycle of an isolated session — what happens at each stage, what's shared vs. isolated, and how the safety hooks fit together. If you're adopting the framework for a new project, read this to understand the design before your first session.

### The problem worktrees solve

Without isolation, two Claude sessions in the same repo will edit the same files on the same branch. One session's `git checkout` silently changes the other session's working directory. Context compaction can make Claude forget which branch it was on. The result: merge conflicts, lost work, and commits landing on the wrong branch.

Git worktrees give each session a physically separate copy of the repo with its own branch, its own working directory, and its own state files — while sharing a single `.git` object store so branches, commits, and history stay in sync.

### What's shared vs. what's isolated

| Resource | Shared or isolated? | Why |
|----------|---------------------|-----|
| `.claude/settings.local.json` | **Shared** (symlinked) | Hook config should be identical across sessions — one source of truth |
| `.env` / `backend/.env` / `frontend/.env.local` | **Shared** (symlinked) | API keys and secrets shouldn't diverge between worktrees |
| `.claude/state/` directory | **Isolated** (own copy) | Session locks must be per-worktree so two sessions don't overwrite each other's lock. Also, symlinking `state/` causes "beyond a symbolic link" errors with `git stash` because `.gitkeep` is tracked inside it. |
| `.claude/hooks/`, `.claude/rules/`, `.claude/agents/` | **Isolated** (git-tracked) | Each worktree gets its own checkout of these files from git — they're tracked, not gitignored |
| `node_modules/`, `venv/` | **Isolated** (fresh install) | Dependencies are installed fresh per worktree to avoid cross-contamination |
| Frontend dev server | **Isolated** (unique port) | Each session gets an auto-assigned port (3003, 3004, ...) |
| Backend dev server | **Shared** (single instance) | Start the backend once in the main repo; all worktrees connect to it |
| Git branches and history | **Shared** (single `.git` store) | Worktrees share the same object database — `git log`, `git fetch`, and branch operations see the same data |

### Full lifecycle: what happens when you run `claude-session.sh`

```
Terminal                           Disk                              Hooks
───────                           ────                              ─────
./scripts/claude-session.sh
  feature/my-feature
        │
        ▼
  1. Read config/framework.yaml
     (project name, ports, paths)
        │
        ▼
  2. git worktree add -b ──────► ~/worktrees/my-project-feature-my-feature/
     feature/my-feature            ├── .git (file → main repo's .git/worktrees/...)
                                   ├── all source files (separate copy)
                                   └── .claude/ (git-tracked hooks, rules, etc.)
        │
        ▼
  3. Bootstrap dependencies
     • python3 -m venv venv ───► venv/ created in worktree
     • npm install ────────────► node_modules/ created in worktree/frontend
        │
        ▼
  4. Symlink shared config
     • settings.local.json ────► symlink → main repo
     • .env files ─────────────► symlinks → main repo
     • .claude/state/ ─────────► mkdir (own directory, NOT symlinked)
        │
        ▼
  5. Auto-sync with origin/main
     • git fetch origin
     • If behind: stash → merge → pop stash
     • If conflict: write merge-conflict.json ──────► merge-conflict-resolver.py
                                                       will instruct Claude to fix it
        │
        ▼
  6. Start frontend dev server
     • Find available port (3003, 3004, ...) ──────► .claude-port file written
     • npm run dev -- --port $PORT
        │
        ▼
  7. Launch claude ─────────────────────────────────► SessionStart hook fires:
     (inside the worktree)                             • session-lifecycle.py creates
                                                         session-lock.json
                                                       • Logs session_start event
        │
        ▼
  8. Claude session running ────────────────────────► On every prompt:
     (user works normally)                             • branch-check.py verifies branch
                                                       • worktree-enforcer.py checks
                                                         for parallel session conflicts
                                                      On git checkout/switch:
                                                       • checkout-guard.py blocks if
                                                         another session is active
                                                       • branch-tracker.py updates lock
        │
        ▼
  9. Claude exits (or user Ctrl-C)
     • Stop frontend server
     • If --keep: preserve worktree
     • If no --keep: check for uncommitted changes
       → prompt user if changes exist
       → git worktree remove --force
       → git worktree prune
```

### Hook integration timeline

Understanding *when* each hook fires helps debug issues:

| Lifecycle moment | Hook | What it does |
|------------------|------|-------------|
| Session starts | `session-lifecycle.py` | Creates `session-lock.json` with PID, branch, timestamp. This is what makes concurrent-session detection work from the first prompt. |
| Every user prompt | `branch-check.py` | Compares current branch to `expected-branch.txt`. Catches branch drift after context compaction. |
| Every user prompt | `worktree-enforcer.py` | If running in main repo (not a worktree), checks for conflicting sessions via lock file. Warns with rate limiting (every 4 hours). |
| Before `git checkout` | `checkout-guard.py` | Blocks branch switches if another active session (live PID) holds a lock in the same worktree. Prevents cross-session interference. |
| After `git checkout` | `branch-tracker.py` | Updates `expected-branch.txt` and `session-lock.json` to reflect the new branch. Keeps branch-check in sync. |
| Before context compaction | `pre-compact.py` | Saves branch, PR title, diff stats, and plan state to `pre-compact-handoff.json`. Claude reads this after compaction to recover context. |

### Stale lock recovery

If a session crashes (kill -9, terminal closed, machine restart), the lock file remains but the PID is dead. The framework handles this automatically:

1. Next session start: `session-lifecycle.py` checks if the existing lock's PID is alive via `os.kill(pid, 0)`
2. If the process is dead: the lock is stale — it gets overwritten with the new session's info
3. If the process is alive: the lock is valid — the new session leaves it alone (you'll get a warning from `worktree-enforcer.py`)

You never need to manually delete lock files unless something is truly broken. If you do need to:

```bash
rm ~/worktrees/my-project-feature-auth/.claude/state/session-lock.json
```

### Common adoption questions

**Q: Do I need to run the session launcher every time?**
Yes. Running bare `claude` in the main repo skips worktree isolation, dependency bootstrapping, auto-sync, and port management. The `worktree-enforcer.py` hook will warn you if it detects this.

**Q: Can I have multiple sessions at the same time?**
Yes — that's the whole point. Each gets its own worktree, branch, port, and lock file. Open a new terminal and run `claude-session.sh` with a different branch name.

**Q: What if I want to keep the worktree after the session?**
Use `--keep`. The worktree stays on disk, and you can resume with `cd ~/worktrees/my-project-feature-auth && claude`. The lock file will be stale (old PID), so the next `claude` invocation reclaims it automatically.

**Q: What if auto-sync has a merge conflict?**
The script writes a `merge-conflict.json` state file. When Claude starts, the `merge-conflict-resolver.py` hook detects it and instructs Claude to resolve the conflict before proceeding.

**Q: How much disk space do worktrees use?**
Much less than a full clone. Git shares the object store, so a worktree is mostly just the working directory files. Dependencies (`node_modules/`, `venv/`) add the most space. Without `--keep`, everything is cleaned up on exit.

**Q: My project doesn't have a frontend. Do I need port management?**
No. If there's no `frontend/package.json`, the server startup step is skipped entirely. You can also use `--no-servers` to skip it explicitly.

---

## Optional Enhancements

### Run Framework Tests

```bash
bash test/test_framework_config.sh
```

All tests should pass, confirming the config system works.

### Configure Notifications

In `config/framework.yaml`, set:
```yaml
notifications:
  provider: "discord"  # or "slack"
  webhook_env: "NOTIFICATION_WEBHOOK_URL"
```

Then add the webhook URL to your GitHub repo secrets and local environment.

### Configure Prompt Versioning

If your project uses LLM prompts, enable versioning in `config/framework.yaml`:
```yaml
prompts:
  versioning: true
  snapshot_dir: "prompt_snapshots"
```

See [docs/15-PROMPT_VERSIONING.md](docs/15-PROMPT_VERSIONING.md) for the full protocol.

## Next Steps

- Start a Claude session: `./scripts/claude-session.sh feature/first-feature`
- Read [CLAUDE.md](CLAUDE.md) for the full methodology
- Read [docs/00-README.md](docs/00-README.md) for documentation guide
