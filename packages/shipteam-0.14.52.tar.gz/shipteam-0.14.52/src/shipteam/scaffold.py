"""
shipteam.scaffold — .claude/ directory scaffolding and .gitignore management.
"""
from __future__ import annotations

import shutil
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import List, Optional

from shipteam.security import safe_load_yaml


REQUIRED_GITIGNORE_ENTRIES = [
    ".claude/state/",
    ".context/",
    ".qa-reports/",
    ".shipteam-init.yaml",
    "/private/",
]

# Directories that are always copied in full (no profile filtering)
_ALWAYS_COPY_DIRS = {"agents", "hooks"}

# Directories subject to file-level profile filtering (each entry in
# framework-meta.yaml profile_filters[name] is a filename to include).
_FILE_FILTERED_DIRS = {"rules"}

# Directories subject to subdir-level profile filtering. Each entry in
# framework-meta.yaml profile_filters[name] is a *directory name* under the
# top-level dir, and ALL files inside that subdir are copied. Skills are the
# canonical case: skills/deploy/SKILL.md, skills/deploy/checklist.txt etc.
_DIR_FILTERED_DIRS = {"skills"}

# Union — used wherever the distinction doesn't matter (e.g., is-this-filtered checks).
_FILTERED_DIRS = _FILE_FILTERED_DIRS | _DIR_FILTERED_DIRS

# Top-level directories used by the installer itself (templates render
# CLAUDE.md at init time, not for the user). Match ONLY at parts[0] — a
# skill is allowed to have its own templates/ subdirectory.
_TOP_LEVEL_INTERNAL_DIRS = {"templates"}

# Python packaging artifacts that can appear anywhere in the tree.
_NESTED_INTERNAL_DIRS = {"__pycache__"}

# Filenames in the framework source that are Python packaging artifacts.
_INTERNAL_ONLY_FILES = {"__init__.py"}

_VALID_PROFILES = {"minimal", "standard", "full"}


class ConflictError(Exception):
    """Raised when .claude/ exists but lacks a .shipteam-init.yaml state file."""


@dataclass
class ScaffoldResult:
    """Result of a scaffold_claude_dir operation."""
    files_written: List[Path] = field(default_factory=list)
    files_skipped: List[Path] = field(default_factory=list)
    backup_path: Optional[Path] = None


def _load_meta(source_dir: Path) -> dict:
    """Load framework-meta.yaml from source_dir; raises ValueError on YAML errors."""
    return safe_load_yaml(source_dir / "framework-meta.yaml")


def _get_allowed_files(meta: dict, category: str, profile: str) -> Optional[List[str]]:
    """Return list of allowed filenames for category+profile, or None if wildcard."""
    filters = meta.get("profile_filters", {}).get(category, {})
    allowed = filters.get(profile, [])
    if allowed == ["*"] or allowed == "*":
        return None  # wildcard — copy all
    # Validate entries are bare filenames: reject non-strings, path separators, traversal, null bytes
    validated: List[str] = []
    for entry in allowed:
        if not isinstance(entry, str):
            raise ValueError(f"profile_filters[{category}][{profile}] contains non-string entry: {entry!r}")
        if "/" in entry or "\\" in entry or ".." in entry or "\x00" in entry:
            raise ValueError(f"profile_filters[{category}][{profile}] entry {entry!r} must be a bare filename")
        validated.append(entry)
    return validated


def scaffold_claude_dir(
    project_dir: Path,
    source_dir: Path,
    profile: str = "standard",
    force: bool = False,
    dry_run: bool = False,
) -> ScaffoldResult:
    """Scaffold .claude/ directory from source_dir into project_dir.

    Raises:
        ConflictError: if .claude/ exists without .shipteam-init.yaml and force=False.
    """
    if profile not in _VALID_PROFILES:
        raise ValueError(f"Unknown profile {profile!r}. Expected one of: {sorted(_VALID_PROFILES)}")

    result = ScaffoldResult()
    claude_dir = project_dir / ".claude"
    state_file = project_dir / ".shipteam-init.yaml"
    has_state = state_file.exists()

    meta = _load_meta(source_dir)

    # Validate dir-filtered allowlists against the actual source tree. A typo
    # in framework-meta.yaml (e.g., `tdd_commit` vs `tdd-commit`) would
    # otherwise silently drop a skill from the install with no signal.
    # Accepts either subdirectory names (the real layout) or filenames (legacy
    # flat layout) to keep backward-compat for old framework bundles.
    for category in _DIR_FILTERED_DIRS:
        allowed = _get_allowed_files(meta, category, profile)
        if allowed is None:
            continue  # wildcard — nothing to validate
        category_root = source_dir / category
        if not category_root.exists():
            continue  # category dir missing entirely — separate concern
        present = {p.name for p in category_root.iterdir()}
        unknown = [name for name in allowed if name not in present]
        if unknown:
            raise ValueError(
                f"profile_filters[{category}][{profile}] references unknown "
                f"entries not present in source: {unknown!r}"
            )

    # Conflict detection
    if claude_dir.exists() and not has_state:
        # Refuse if .claude/ is a symlink — avoid writing into (or backing up) an arbitrary target
        if claude_dir.is_symlink():
            raise ConflictError(
                f".claude/ in {project_dir} is a symlink; refusing to scaffold. "
                "Remove the symlink and retry."
            )
        if not force:
            if not dry_run:
                raise ConflictError(
                    f".claude/ already exists in {project_dir} without a .shipteam-init.yaml. "
                    "Use --force to overwrite, or resolve manually."
                )
            # dry_run with conflict: continue to show preview, no backup
        elif not dry_run:
            # force=True + real run: back up existing .claude/ (preserve symlinks inside)
            backup_base = project_dir / ".claude.bak"
            if backup_base.exists():
                ts = datetime.now().strftime("%Y%m%d-%H%M%S")
                backup_base = project_dir / f".claude.bak.{ts}"
            shutil.copytree(str(claude_dir), str(backup_base), symlinks=True)
            result.backup_path = backup_base

    # Collect all source files to copy
    # Build a mapping of (relative_path -> source_file)
    files_to_copy: list[tuple[Path, Path]] = []  # (rel_path, src_path)

    for item in source_dir.rglob("*"):
        # Refuse symlinks anywhere in the source tree — prevents exfiltration via
        # attacker-controlled --framework-dir that points symlinks at user secrets.
        if item.is_symlink():
            raise ValueError(f"source_dir {source_dir} contains symlink {item} — refusing to copy")
        if not item.is_file():
            continue
        rel = item.relative_to(source_dir)
        parts = rel.parts

        # Skip framework-meta.yaml itself
        if rel.name == "framework-meta.yaml" and len(parts) == 1:
            continue

        # Skip installer-internal top-level dirs (only at parts[0]) and
        # Python packaging artifacts (anywhere in the tree).
        if parts[0] in _TOP_LEVEL_INTERNAL_DIRS:
            continue
        if any(p in _NESTED_INTERNAL_DIRS for p in parts):
            continue
        if rel.name in _INTERNAL_ONLY_FILES:
            continue

        # Determine if this file should be copied based on profile filtering
        if len(parts) >= 2:
            top_dir = parts[0]
            filename = parts[-1]

            if top_dir in _ALWAYS_COPY_DIRS:
                files_to_copy.append((rel, item))
            elif top_dir in _FILE_FILTERED_DIRS:
                # Filename-level filter (e.g. rules: anti-patterns.md vs security.md)
                allowed = _get_allowed_files(meta, top_dir, profile)
                if allowed is None:
                    files_to_copy.append((rel, item))
                elif filename in allowed:
                    files_to_copy.append((rel, item))
                # else: not allowed for this profile — skip
            elif top_dir in _DIR_FILTERED_DIRS:
                # Subdir-level filter (e.g. skills: deploy vs health). Compare
                # the immediate child directory name (parts[1]) — every file
                # inside an allowed subdir is included regardless of nesting.
                # The outer block already enforced len(parts) >= 2.
                allowed = _get_allowed_files(meta, top_dir, profile)
                if allowed is None or parts[1] in allowed:
                    files_to_copy.append((rel, item))
                # else: subdir not allowed for this profile — skip
            else:
                files_to_copy.append((rel, item))
        else:
            # Top-level file (not in a subdir)
            files_to_copy.append((rel, item))

    if dry_run:
        # Just populate files_written with what would be written
        for rel, _ in files_to_copy:
            result.files_written.append(claude_dir / rel)
        return result

    # Actual write pass
    # Collect existing user files (files not from framework manifest)
    existing_user_files: set[Path] = set()
    if claude_dir.exists() and has_state:
        framework_rels = {rel for rel, _ in files_to_copy}
        for existing in claude_dir.rglob("*"):
            if existing.is_file():
                try:
                    rel = existing.relative_to(claude_dir)
                    if rel not in framework_rels:
                        existing_user_files.add(existing)
                except ValueError:
                    pass

    # Create and write framework files
    for rel, src_path in files_to_copy:
        dest = claude_dir / rel
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(str(src_path), str(dest), follow_symlinks=False)
        result.files_written.append(dest)

    # Track skipped user files
    for user_file in existing_user_files:
        result.files_skipped.append(user_file)

    return result


def scaffold_gitignore(project_dir: Path) -> bool:
    """Ensure .gitignore contains all required ShipTeam entries.

    Returns True if the file was created or modified, False if it was already complete.
    """
    gitignore = project_dir / ".gitignore"

    if gitignore.exists():
        content = gitignore.read_text(encoding="utf-8")
    else:
        content = ""

    # Determine which entries are missing — compare against stripped lines to
    # tolerate trailing whitespace left by other tooling (keeps append idempotent).
    stripped_lines = {line.strip() for line in content.splitlines()}
    missing = [e for e in REQUIRED_GITIGNORE_ENTRIES if e not in stripped_lines]

    if not missing:
        return False

    # Append missing entries
    # Ensure we start on a new line
    if content and not content.endswith("\n"):
        content += "\n"

    content += "\n".join(missing) + "\n"
    gitignore.write_text(content, encoding="utf-8")
    return True
