from pathlib import Path
from typing import Any, Union

import yaml

_MAX_YAML_BYTES = 256 * 1024  # framework.yaml should be well under 10KB in practice


def validate_path_safety(path: Union[str, Path, None], project_root: Path) -> bool:
    """True if path resolves within project_root; False if it escapes or is invalid."""
    if not isinstance(path, (str, Path)):
        return False
    path_str = str(path)
    if "\x00" in path_str:
        return False
    if not path_str:
        return True  # empty path resolves to project_root itself
    resolved_root = project_root.resolve()
    try:
        p = Path(path_str)
        resolved_path = p.resolve() if p.is_absolute() else (resolved_root / p).resolve()
    except (ValueError, OSError):
        return False
    try:
        return resolved_path == resolved_root or resolved_path.is_relative_to(resolved_root)
    except ValueError:
        return False


def safe_load_yaml(path: Path) -> dict[str, Any]:
    """Load YAML using yaml.safe_load ONLY. Bounded size, utf-8 enforced, None coerced to {}."""
    if path.stat().st_size > _MAX_YAML_BYTES:
        raise ValueError(f"{path} exceeds maximum size of {_MAX_YAML_BYTES} bytes")
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = yaml.safe_load(f)
    except yaml.YAMLError as e:
        raise ValueError(f"Malformed YAML in {path}: {e}") from e
    return data or {}
