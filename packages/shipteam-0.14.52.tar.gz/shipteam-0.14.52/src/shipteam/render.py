"""
Jinja2 rendering and managed-region refresh for CLAUDE.md files.
"""
from __future__ import annotations

import hashlib
import unicodedata
from dataclasses import dataclass
from typing import Optional

import jinja2
from jinja2.sandbox import ImmutableSandboxedEnvironment

from shipteam.detect import DetectedStack
from shipteam.regions import MARKER_BEGIN, MARKER_END, _parse_begin, _parse_end
from shipteam.state import InitState

# String fields flowing into the Jinja-rendered CLAUDE.md must not carry
# HTML-comment delimiters or control characters — otherwise a crafted
# pyproject.toml name / git remote slug could inject managed-region markers.
# The comment-delimiter check is a substring match (intentional — any subsequence
# containing '<!--' or '-->' is refused, even inside an otherwise benign value
# like a repo description, to keep the marker-system invariant absolute).
_INJECTION_FRAGMENTS = ("<!--", "-->")

# Bidi + zero-width controls that can reorder or hide text in log/diff output.
_BIDI_HAZARD_CHARS = (
    "\u202a", "\u202b", "\u202c", "\u202d", "\u202e",  # LRE/RLE/PDF/LRO/RLO
    "\u2066", "\u2067", "\u2068", "\u2069",            # LRI/RLI/FSI/PDI
    "\u200b", "\u200c", "\u200d", "\ufeff",            # zero-width set
)


def _assert_safe_string(value: str, field_name: str) -> None:
    """Raise ValueError if *value* contains marker-injection or display hazards."""
    if any(frag in value for frag in _INJECTION_FRAGMENTS):
        raise ValueError(f"{field_name} must not contain HTML comment delimiters")
    # Reject all C0/C1 control characters (unicodedata category 'Cc'); covers
    # \t \n \r \x00 plus the full Cc block without enumerating each.
    if any(unicodedata.category(ch) == "Cc" for ch in value):
        raise ValueError(f"{field_name} must not contain control characters")
    if any(ch in value for ch in _BIDI_HAZARD_CHARS):
        raise ValueError(f"{field_name} must not contain bidi/zero-width characters")


@dataclass
class RenderContext:
    project_name: str
    project_repo: str
    stack: DetectedStack
    profile: str
    deployment_method: Optional[str]
    health_url: Optional[str]
    worktree_enabled: bool
    schema_version: int
    cli_version: str

    def __post_init__(self) -> None:
        # Defense-in-depth: CLI already regex-validates --repo, but project_name
        # is derived from directory basename and repo can arrive from auto-detect,
        # so every RenderContext construction gets the boundary check.
        _assert_safe_string(self.project_name, "project_name")
        _assert_safe_string(self.project_repo, "project_repo")
        if self.deployment_method is not None:
            _assert_safe_string(self.deployment_method, "deployment_method")
        if self.health_url is not None:
            _assert_safe_string(self.health_url, "health_url")


def render_claude_md(template: str, ctx: RenderContext) -> str:
    """Render a Jinja2 template string with the given RenderContext."""
    env = ImmutableSandboxedEnvironment(
        trim_blocks=True,
        lstrip_blocks=True,
        autoescape=False,
        undefined=jinja2.StrictUndefined,
    )
    tmpl = env.from_string(template)
    variables = {
        "project_name": ctx.project_name,
        "project_repo": ctx.project_repo,
        "stack": ctx.stack,
        "profile": ctx.profile,
        "deployment_method": ctx.deployment_method,
        "health_url": ctx.health_url,
        "worktree_enabled": ctx.worktree_enabled,
        "schema_version": ctx.schema_version,
        "cli_version": ctx.cli_version,
    }
    return tmpl.render(**variables)


def refresh_managed_regions(
    existing: str,
    new_rendered: str,
    state: InitState,
    force: bool = False,
) -> tuple[str, list[str]]:
    """Merge new rendered regions into existing CLAUDE.md content.

    Uses a lenient scanner for the existing content (warn-and-skip on unbalanced).
    Returns (merged_content, warnings).
    """
    warnings: list[str] = []

    # Parse new_rendered to get region bodies by name. Surface any mismatched-END
    # warnings too — those would signal a bug in the shipped template, not the
    # user's existing file, and are worth flagging loud.
    new_regions, _new_unbalanced, new_mismatched_ends = _lenient_scan(
        new_rendered, warn_on_unbalanced=False
    )
    for name in new_mismatched_ends:
        warnings.append(f"Template produced mismatched END marker (template bug): {name!r}")

    # Scan existing content leniently
    existing_regions, existing_unbalanced, existing_mismatched_ends = _lenient_scan(
        existing, warn_on_unbalanced=True
    )

    for name in existing_unbalanced:
        warnings.append(f"Unbalanced region marker in existing content: {name!r}")
    for name in existing_mismatched_ends:
        warnings.append(f"mismatched END marker in existing content: {name!r}")

    # Build merged content: walk existing and replace region bodies
    result = existing

    # For each region in new_rendered, attempt to replace in existing
    for name, new_body in new_regions.items():
        if name not in existing_regions:
            warnings.append(f"Region {name!r} not found in existing content — skipped")
            continue

        existing_body = existing_regions[name]
        stored_checksum = state.region_checksums.get(name)
        current_checksum = _sha(existing_body)

        if stored_checksum is not None and current_checksum != stored_checksum:
            # User has edited this region
            if force:
                warnings.append(
                    f"Region {name!r}: user edit detected — overwritten (force=True)"
                )
                result = _replace_region_lenient(result, name, new_body)
            else:
                warnings.append(
                    f"Region {name!r}: user edit detected — preserved (force=False)"
                )
                # Leave existing content in place
        else:
            # No user edit or no stored checksum — replace
            result = _replace_region_lenient(result, name, new_body)

    return result, warnings


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _sha(text: str) -> str:
    return hashlib.sha256(text.encode()).hexdigest()


def _lenient_scan(
    content: str,
    warn_on_unbalanced: bool,
) -> tuple[dict[str, str], list[str], list[str]]:
    """Walk content line-by-line and return (regions_dict, unbalanced_names, mismatched_ends).

    regions_dict maps region name -> body text (content between markers, excluding marker lines).
    unbalanced_names lists names with orphan BEGIN markers (no matching END).
    mismatched_ends lists names on END markers that don't match the currently-open BEGIN.
    """
    lines = content.split("\n")
    regions: dict[str, str] = {}
    unbalanced: list[str] = []
    mismatched_ends: list[str] = []

    open_name: Optional[str] = None
    body_lines: list[str] = []

    for i, line in enumerate(lines):
        stripped = line.strip()
        begin_name = _parse_begin(stripped)
        end_name = _parse_end(stripped)

        if begin_name is not None:
            if open_name is not None:
                # Previous region was never closed
                unbalanced.append(open_name)
            open_name = begin_name
            body_lines = []
        elif end_name is not None:
            if open_name == end_name:
                regions[open_name] = "\n".join(body_lines)
                open_name = None
                body_lines = []
            else:
                # Surface mismatched END for operator visibility; do not abort
                # (lenient) — the region-merge pass will handle what it can.
                mismatched_ends.append(end_name)
        else:
            if open_name is not None:
                body_lines.append(line)

    if open_name is not None:
        unbalanced.append(open_name)

    return regions, unbalanced, mismatched_ends


def _replace_region_lenient(content: str, name: str, new_body: str) -> str:
    """Replace the body of a named region. Lenient — if region not found, returns content unchanged.

    Limitation: indented markers are not indent-aware. If the BEGIN marker line has leading
    whitespace, new_body lines are injected at column 0 (no indent applied). Use flush-left
    markers in managed CLAUDE.md regions.
    """
    begin_marker = MARKER_BEGIN.format(name=name)
    end_marker = MARKER_END.format(name=name)

    lines = content.split("\n")
    result_lines: list[str] = []
    in_region = False
    region_found = False

    for line in lines:
        stripped = line.strip()
        if stripped == begin_marker:
            in_region = True
            region_found = True
            result_lines.append(line)
            # Insert new body lines
            if new_body:
                result_lines.extend(new_body.split("\n"))
        elif stripped == end_marker and in_region:
            in_region = False
            result_lines.append(line)
        elif not in_region:
            result_lines.append(line)
        # Skip old body lines while in_region

    result = "\n".join(result_lines)
    if content.endswith("\n") and not result.endswith("\n"):
        result += "\n"
    return result
