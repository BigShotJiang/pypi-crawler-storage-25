"""
Managed region extraction and replacement for CLAUDE.md files.
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Optional

MARKER_BEGIN = "<!-- SHIPTEAM:BEGIN:{name} -->"
MARKER_END = "<!-- SHIPTEAM:END:{name} -->"

# Region names must be bare identifiers. Forbidding `/`, whitespace, control
# chars, and non-ASCII protects against path-injection (if names are ever used
# as filenames) and ensures markers are visually unambiguous in diffs.
_REGION_NAME_RE = re.compile(r"^[A-Za-z0-9_-]{1,64}$")


@dataclass
class ManagedRegion:
    name: str
    content: str       # text between BEGIN and END markers (excluding marker lines)
    start_line: int    # 0-indexed line number of the BEGIN marker
    end_line: int      # 0-indexed line number of the END marker


def extract_regions(content: str) -> list[ManagedRegion]:
    """Parse managed regions from content string.

    Raises ValueError on duplicate names or unbalanced markers.
    Returns empty list when no regions found.
    """
    lines = content.split("\n")
    regions: list[ManagedRegion] = []
    seen_names: set[str] = set()
    open_stack: list[tuple[str, int]] = []  # (name, start_line)

    for i, line in enumerate(lines):
        stripped = line.strip()
        begin_name = _parse_begin(stripped)
        end_name = _parse_end(stripped)

        if begin_name is not None:
            open_stack.append((begin_name, i))
        elif end_name is not None:
            if not open_stack:
                raise ValueError(f"Unmatched END marker for {end_name!r} at line {i}")
            open_name, open_line = open_stack[-1]
            if open_name != end_name:
                raise ValueError(
                    f"Mismatched END marker: expected {open_name!r}, got {end_name!r} at line {i}"
                )
            open_stack.pop()
            if end_name in seen_names:
                raise ValueError(f"Duplicate region name: {end_name!r}")
            seen_names.add(end_name)
            body_lines = lines[open_line + 1 : i]
            regions.append(ManagedRegion(
                name=end_name,
                content="\n".join(body_lines),
                start_line=open_line,
                end_line=i,
            ))

    if open_stack:
        orphan_name = open_stack[-1][0]
        raise ValueError(f"Unbalanced BEGIN marker for {orphan_name!r} — no matching END")

    return regions


def replace_region(content: str, name: str, new_content: str) -> str:
    """Replace the body of a named region in content.

    Raises KeyError if region not found or ValueError if unbalanced.
    """
    regions = extract_regions(content)
    region_map = {r.name: r for r in regions}
    if name not in region_map:
        raise KeyError(f"Region {name!r} not found in content")

    region = region_map[name]
    lines = content.split("\n")
    begin_marker = lines[region.start_line]
    end_marker = lines[region.end_line]

    before = lines[: region.start_line + 1]
    after = lines[region.end_line :]

    # new_content goes between markers
    new_body_lines = new_content.split("\n") if new_content else []
    rebuilt = before + new_body_lines + after

    result = "\n".join(rebuilt)
    # Preserve trailing newline if original had it
    if content.endswith("\n") and not result.endswith("\n"):
        result += "\n"
    return result


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

_BEGIN_PREFIX = "<!-- SHIPTEAM:BEGIN:"
_END_PREFIX = "<!-- SHIPTEAM:END:"
_MARKER_SUFFIX = " -->"


def _parse_begin(line: str) -> Optional[str]:
    """Return region name if line is a BEGIN marker with a valid name, else None."""
    if line.startswith(_BEGIN_PREFIX) and line.endswith(_MARKER_SUFFIX):
        name = line[len(_BEGIN_PREFIX) : -len(_MARKER_SUFFIX)]
        if name and _REGION_NAME_RE.match(name):
            return name
    return None


def _parse_end(line: str) -> Optional[str]:
    """Return region name if line is an END marker with a valid name, else None."""
    if line.startswith(_END_PREFIX) and line.endswith(_MARKER_SUFFIX):
        name = line[len(_END_PREFIX) : -len(_MARKER_SUFFIX)]
        if name and _REGION_NAME_RE.match(name):
            return name
    return None
