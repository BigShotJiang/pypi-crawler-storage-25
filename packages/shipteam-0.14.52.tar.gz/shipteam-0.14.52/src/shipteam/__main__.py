"""Allow `python -m shipteam` invocation."""
from shipteam.cli import main

if __name__ == "__main__":
    main()
