import re
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Literal, Optional

import yaml

STATE_FILENAME = ".shipteam-init.yaml"

Profile = Literal["minimal", "standard", "full"]
_SHA256_RE = re.compile(r"^[0-9a-f]{64}$")
_REQUIRED_FIELDS = ("cli_version", "framework_version", "schema_version", "rendered_at", "template_hash")


@dataclass
class InitState:
    cli_version: str
    framework_version: str
    schema_version: int
    rendered_at: str               # ISO 8601
    template_hash: str             # SHA256 of CLAUDE.md.jinja
    region_checksums: dict[str, str] = field(default_factory=dict)  # region_name -> SHA256
    profile: str = "standard"      # Profile literal

    def __post_init__(self) -> None:
        try:
            datetime.fromisoformat(self.rendered_at.replace("Z", "+00:00"))
        except (ValueError, AttributeError) as e:
            raise ValueError(f"rendered_at must be ISO 8601, got: {self.rendered_at!r}") from e
        if not _SHA256_RE.match(self.template_hash):
            raise ValueError(f"template_hash must be 64-char lowercase hex SHA-256, got: {self.template_hash!r}")
        for region, checksum in self.region_checksums.items():
            if not _SHA256_RE.match(checksum):
                raise ValueError(f"region_checksums[{region!r}] must be 64-char hex SHA-256, got: {checksum!r}")
        if self.profile not in ("minimal", "standard", "full"):
            raise ValueError(f"profile must be one of minimal/standard/full, got: {self.profile!r}")


def load_state(project_dir: Path) -> Optional[InitState]:
    """Load .shipteam-init.yaml. Returns None if file not found; raises ValueError if corrupt."""
    state_file = project_dir / STATE_FILENAME
    if not state_file.exists():
        return None
    try:
        data = yaml.safe_load(state_file.read_text(encoding="utf-8"))
    except yaml.YAMLError as e:
        raise ValueError(f"Malformed YAML in {state_file}: {e}") from e
    if not isinstance(data, dict):
        raise ValueError(f"State file {state_file} is empty or not a YAML mapping")
    missing = [k for k in _REQUIRED_FIELDS if k not in data]
    if missing:
        raise ValueError(f"State file {state_file} missing required fields: {missing}")
    return InitState(
        cli_version=data["cli_version"],
        framework_version=data["framework_version"],
        schema_version=data["schema_version"],
        rendered_at=data["rendered_at"],
        template_hash=data["template_hash"],
        region_checksums=data.get("region_checksums") or {},
        profile=data.get("profile", "standard"),
    )


def save_state(state: InitState, project_dir: Path) -> None:
    """Write .shipteam-init.yaml preserving field order. Atomic via os.replace."""
    import os  # local import keeps module-level surface unchanged
    state_file = project_dir / STATE_FILENAME
    data = {
        "cli_version": state.cli_version,
        "framework_version": state.framework_version,
        "schema_version": state.schema_version,
        "rendered_at": state.rendered_at,
        "template_hash": state.template_hash,
        "region_checksums": state.region_checksums,
        "profile": state.profile,
    }
    tmp_file = state_file.with_suffix(state_file.suffix + ".tmp")
    tmp_file.write_text(yaml.safe_dump(data, sort_keys=False), encoding="utf-8")
    os.replace(tmp_file, state_file)
