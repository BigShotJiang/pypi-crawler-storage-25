import json
from dataclasses import dataclass
from pathlib import Path
from typing import Literal, Optional

_GIT_PATH = ".git"
_GITDIR_PREFIX = "gitdir:"
_MAX_GIT_FILE_BYTES = 4096  # real gitdir: pointer files are < 200 bytes
_MAX_PACKAGE_JSON_BYTES = 1024 * 1024  # 1MB is generous; real files are < 10KB
BackendLanguage = Literal["python", "node", "go", "rust"]


@dataclass
class BackendStack:
    language: str          # "python", "node", "go", "rust"
    root: str              # ".", "backend", etc.
    test_command: Optional[str] = None
    version: Optional[str] = None


@dataclass
class FrontendStack:
    language: str          # "typescript", "javascript", "react", etc.
    root: str
    test_command: Optional[str] = None
    version: Optional[str] = None


@dataclass
class DetectedStack:
    backend: Optional[BackendStack]
    frontend: Optional[FrontendStack]
    repo_slug: Optional[str]        # "org/name" from git remote, else None
    is_git_repo: bool
    git_type: Literal["directory", "worktree_file", "none"]
    git_dir: Optional[str]          # resolved absolute path
    git_work_tree: Optional[str]    # resolved absolute path


def _detect_backend(search_dir: Path, root_label: str) -> Optional[BackendStack]:
    """Return a Python BackendStack if pyproject.toml or requirements.txt is present."""
    python_markers = ("pyproject.toml", "requirements.txt")
    if any((search_dir / marker).exists() for marker in python_markers):
        return BackendStack(language="python", root=root_label)
    return None


def _detect_frontend(search_dir: Path, root_label: str) -> Optional[FrontendStack]:
    pkg = search_dir / "package.json"
    if not pkg.exists():
        return None
    try:
        if pkg.stat().st_size > _MAX_PACKAGE_JSON_BYTES:
            return None
        data = json.loads(pkg.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError, UnicodeDecodeError):
        return None
    deps = {}
    deps.update(data.get("dependencies") or {})
    deps.update(data.get("devDependencies") or {})
    # Priority order: more-specific frameworks first (next uses react; svelte-kit uses svelte)
    for dep in ("next", "svelte", "vue", "react"):
        if dep in deps:
            return FrontendStack(language=dep, root=root_label)
    return None


def detect_stack(target_dir: Path) -> DetectedStack:
    """Auto-detect project stack from lockfiles and project files."""
    is_git_repo, git_type, git_dir, git_work_tree = detect_git(target_dir)

    backend: Optional[BackendStack] = None
    frontend: Optional[FrontendStack] = None

    # Check for monorepo layout first
    backend_dir = target_dir / "backend"
    frontend_dir = target_dir / "frontend"
    is_monorepo = backend_dir.is_dir() and frontend_dir.is_dir()

    if is_monorepo:
        backend = _detect_backend(backend_dir, "backend")
        frontend = _detect_frontend(frontend_dir, "frontend")
    else:
        backend = _detect_backend(target_dir, ".")
        frontend = _detect_frontend(target_dir, ".")

    return DetectedStack(
        backend=backend,
        frontend=frontend,
        repo_slug=None,
        is_git_repo=is_git_repo,
        git_type=git_type,
        git_dir=git_dir,
        git_work_tree=git_work_tree,
    )


def detect_git(target_dir: Path) -> tuple[bool, str, Optional[str], Optional[str]]:
    """Return (is_git_repo, git_type, git_dir, git_work_tree). Fails closed on malformed .git."""
    git_path = target_dir / _GIT_PATH
    if not git_path.exists():
        return (False, "none", None, None)

    if git_path.is_dir():
        return (True, "directory", str(git_path.resolve()), str(target_dir.resolve()))

    if git_path.is_file():
        try:
            if git_path.stat().st_size > _MAX_GIT_FILE_BYTES:
                return (False, "none", None, None)
            content = git_path.read_text(encoding="utf-8")
        except (OSError, UnicodeDecodeError):
            return (False, "none", None, None)
        # Take only the first non-empty line to avoid multi-line injection
        first_line = next((line.strip() for line in content.splitlines() if line.strip()), "")
        if not first_line.startswith(_GITDIR_PREFIX):
            return (False, "none", None, None)
        git_dir_str = first_line.removeprefix(_GITDIR_PREFIX).strip()
        if not git_dir_str or not Path(git_dir_str).is_absolute():
            return (False, "none", None, None)
        return (True, "worktree_file", git_dir_str, str(target_dir.resolve()))

    # Broken symlink or special file — fail closed
    return (False, "none", None, None)
