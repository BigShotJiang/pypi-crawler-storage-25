from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Literal, Optional

import yaml

from shipteam.security import validate_path_safety

Profile = Literal["minimal", "standard", "full"]
_VALID_PROFILES = ("minimal", "standard", "full")


@dataclass
class FrameworkConfig:
    project_name: str
    project_repo: str
    profile: str                    # Profile literal
    backend_language: Optional[str] = None
    frontend_language: Optional[str] = None
    schema_version: int = 1
    raw: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if not self.project_name:
            raise ValueError("project_name must not be empty")
        if self.profile not in _VALID_PROFILES:
            raise ValueError(f"profile must be one of {_VALID_PROFILES}, got: {self.profile!r}")


def load_config(path: Path) -> FrameworkConfig:
    """Load and validate framework.yaml using yaml.safe_load. Raises ValueError on invalid schema."""
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = yaml.safe_load(f)
    except yaml.YAMLError as e:
        raise ValueError(f"Malformed YAML in {path}: {e}") from e
    data = data or {}
    if not isinstance(data, dict):
        raise ValueError(f"Config file {path} is not a YAML mapping (got {type(data).__name__})")
    project = data.get("project") or {}
    project_name = project.get("name")
    if not project_name:
        raise ValueError(f"Missing required field in {path}: project.name")
    project_repo = project.get("repo", "")
    profile = data.get("profile", "standard")
    schema_version = data.get("schema_version", 1)
    stack = data.get("stack") or {}
    backend = stack.get("backend") or {}
    frontend = stack.get("frontend") or {}
    backend_language = backend.get("language")
    frontend_language = frontend.get("language")
    return FrameworkConfig(
        project_name=project_name,
        project_repo=project_repo,
        profile=profile,
        backend_language=backend_language,
        frontend_language=frontend_language,
        schema_version=schema_version,
        raw=data,
    )


def write_config(config: FrameworkConfig, path: Path) -> None:
    """Write framework.yaml preserving raw dict contents + applying top-level field changes."""
    data = dict(config.raw)
    if "project" not in data:
        data["project"] = {}
    data["project"]["name"] = config.project_name
    data["project"]["repo"] = config.project_repo
    data["profile"] = config.profile
    data["schema_version"] = config.schema_version
    path.write_text(yaml.safe_dump(data, sort_keys=False), encoding="utf-8")


def validate_paths(config: FrameworkConfig, project_root: Path) -> list[str]:
    """Return list of path-safety violations. Empty list = all paths safe."""
    violations = []
    stack = config.raw.get("stack") or {}
    for stack_key, stack_section in stack.items():
        if not isinstance(stack_section, dict):
            continue
        root_val = stack_section.get("root")
        if root_val and isinstance(root_val, str):
            key = f"stack.{stack_key}.root"
            if not validate_path_safety(root_val, project_root):
                violations.append(f"{key}: '{root_val}' escapes project root")
    return violations
