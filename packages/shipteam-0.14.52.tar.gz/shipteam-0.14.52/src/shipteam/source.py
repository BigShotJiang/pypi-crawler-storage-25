"""
shipteam.source — framework source resolution + version handshake.
"""
from __future__ import annotations

from importlib.resources import files
from pathlib import Path
from typing import Optional

import yaml
from packaging.version import Version


class VersionMismatchError(Exception):
    """Raised when CLI version or schema version is incompatible with the framework source."""


def get_bundled_source() -> Path:
    """Return the Path to the bundled framework source (shipped inside the package).

    Raises FileNotFoundError in dev mode where bundled files don't exist yet.
    """
    try:
        pkg = files("shipteam.framework")
        # Attempt to get a concrete path from the package resource
        path = Path(str(pkg))
        if not path.exists():
            raise FileNotFoundError("Bundled framework source not available in this environment.")
        return path
    except (ModuleNotFoundError, TypeError, FileNotFoundError) as exc:
        raise FileNotFoundError(
            "Bundled framework source not available in this environment."
        ) from exc


def resolve_source(
    framework_dir: Optional[Path] = None,
    env_var_value: Optional[str] = None,
    cli_version: Optional[str] = None,
    supported_schema: Optional[int] = None,
) -> Path:
    """Resolve the framework source directory using priority: framework_dir > env_var_value > bundled.

    Validates framework-meta.yaml for version compatibility.

    Raises:
        FileNotFoundError: if the resolved directory has no framework-meta.yaml.
        VersionMismatchError: if cli_version < min_cli_version or schema mismatch.
    """
    if framework_dir is not None:
        source_path = framework_dir
    elif env_var_value is not None:
        source_path = Path(env_var_value)
    else:
        source_path = get_bundled_source()

    meta_file = source_path / "framework-meta.yaml"
    if not meta_file.exists():
        raise FileNotFoundError(
            f"framework-meta.yaml not found in {source_path}. "
            "Ensure the framework directory is correct."
        )

    with open(meta_file, "r", encoding="utf-8") as f:
        meta = yaml.safe_load(f) or {}

    min_cli_version_str = meta.get("min_cli_version", "0.0.0")
    schema_version = meta.get("schema_version", 1)

    if cli_version is not None:
        if Version(cli_version) < Version(min_cli_version_str):
            raise VersionMismatchError(
                f"This framework requires shipteam >= {min_cli_version_str}. "
                f"Your CLI version is {cli_version}. "
                "Upgrade with: uv tool upgrade shipteam"
            )

    if supported_schema is not None and schema_version > supported_schema:
        raise VersionMismatchError(
            f"Framework schema version {schema_version} is newer than this CLI supports "
            f"(max schema: {supported_schema}). "
            "Upgrade shipteam with: uv tool upgrade shipteam"
        )

    return source_path
