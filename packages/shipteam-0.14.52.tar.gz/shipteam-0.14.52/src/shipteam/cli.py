"""
shipteam.cli — Click CLI wiring for the shipteam installer.
"""
from __future__ import annotations

import hashlib
import re
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

import click
import jinja2

from shipteam import __version__
from shipteam.config import FrameworkConfig, write_config
from shipteam.detect import detect_stack
from shipteam.render import RenderContext, refresh_managed_regions, render_claude_md
from shipteam.scaffold import ConflictError, scaffold_claude_dir, scaffold_gitignore
from shipteam.source import VersionMismatchError, resolve_source
from shipteam.state import InitState, load_state, save_state

# --repo must match "org/name" with safe characters. Rejecting control chars
# and HTML-comment delimiters defends against marker injection into managed
# regions of rendered CLAUDE.md (the marker format uses "<!-- ... -->").
_REPO_RE = re.compile(r"^[A-Za-z0-9._-]+/[A-Za-z0-9._-]+$")
_MARKER_FRAGMENTS = ("<!--", "-->")


def _validate_repo(repo: str) -> Optional[str]:
    """Return an error message if repo is unsafe, else None."""
    if not _REPO_RE.match(repo):
        return "--repo must match 'org/name' using [A-Za-z0-9._-]"
    if any(frag in repo for frag in _MARKER_FRAGMENTS):
        return "--repo must not contain HTML comment delimiters"
    return None


def _project_name_from_dir(project_dir: Path) -> str:
    return project_dir.resolve().name


def _template_hash(template_text: str) -> str:
    return hashlib.sha256(template_text.encode()).hexdigest()


@click.group()
def main() -> None:
    """ShipTeam: Zero-friction Claude Code framework installer."""


@main.command("init")
@click.argument("project_dir", type=click.Path(file_okay=False), default=".")
@click.option("--repo", default=None, help="GitHub repo slug (org/name).")
@click.option(
    "--profile",
    type=click.Choice(["minimal", "standard", "full"]),
    default="standard",
    show_default=True,
    help="Framework profile.",
)
@click.option("--framework-dir", type=click.Path(exists=True, file_okay=False), default=None)
@click.option("--non-interactive", is_flag=True, default=False)
@click.option("--dry-run", is_flag=True, default=False)
@click.option("--force", is_flag=True, default=False)
@click.option("--refresh", is_flag=True, default=False)
@click.pass_context
def init_cmd(
    ctx: click.Context,
    project_dir: str,
    repo: Optional[str],
    profile: str,
    framework_dir: Optional[str],
    non_interactive: bool,
    dry_run: bool,
    force: bool,
    refresh: bool,
) -> None:
    """Initialise (or refresh) a project with the ShipTeam framework."""

    # Non-TTY auto-enables non-interactive mode
    if not sys.stdin.isatty():
        non_interactive = True

    # Refuse symlinked project_dir: destination symlinks could redirect writes
    # outside the intended workspace (e.g., .claude/ → ~/.ssh/).
    raw_project = Path(project_dir)
    if raw_project.exists() and raw_project.is_symlink():
        click.echo(f"Error: project_dir {project_dir} is a symlink — refusing to write", err=True)
        ctx.exit(2)
        return
    project_path = raw_project.resolve()

    # Refuse symlinked --framework-dir at the CLI boundary (scaffold.py already
    # refuses symlinks *inside* the source tree; this covers the root itself).
    fw_dir = Path(framework_dir) if framework_dir else None
    if fw_dir is not None and fw_dir.is_symlink():
        click.echo(f"Error: --framework-dir {framework_dir} is a symlink — refusing", err=True)
        ctx.exit(2)
        return

    # Resolve source + version check
    try:
        source_dir = resolve_source(
            framework_dir=fw_dir,
            cli_version=__version__,
        )
    except VersionMismatchError as exc:
        click.echo(f"Error: version mismatch — {exc}", err=True)
        ctx.exit(4)
        return
    except FileNotFoundError as exc:
        click.echo(f"Error: {exc}", err=True)
        ctx.exit(2)
        return

    # Require --repo in non-interactive mode
    if repo is None:
        if non_interactive:
            click.echo("Error: --repo is required in non-interactive mode (missing required flag: --repo)", err=True)
            ctx.exit(2)
            return
        else:
            repo = click.prompt("GitHub repo slug (org/name)")

    repo_err = _validate_repo(repo)
    if repo_err is not None:
        click.echo(f"Error: {repo_err}", err=True)
        ctx.exit(2)
        return

    if refresh:
        _do_refresh(ctx, project_path, source_dir, repo, profile, force, dry_run)
        return

    _do_init(ctx, project_path, source_dir, repo, profile, force, dry_run)


def _do_init(
    ctx: click.Context,
    project_path: Path,
    source_dir: Path,
    repo: str,
    profile: str,
    force: bool,
    dry_run: bool,
) -> None:
    """Run first-time init."""
    stack = detect_stack(project_path)
    project_name = _project_name_from_dir(project_path)

    # Load + render template
    template_file = source_dir / "templates" / "CLAUDE.md.jinja"
    try:
        template_text = template_file.read_text(encoding="utf-8")
    except FileNotFoundError:
        click.echo(f"Error: template not found at {template_file}", err=True)
        ctx.exit(2)
        return

    render_ctx = RenderContext(
        project_name=project_name,
        project_repo=repo,
        stack=stack,
        profile=profile,
        deployment_method=None,
        health_url=None,
        worktree_enabled=False,
        schema_version=1,
        cli_version=__version__,
    )
    try:
        rendered = render_claude_md(template_text, render_ctx)
    except jinja2.TemplateError as exc:
        click.echo(f"Error: template rendering failed — {exc}", err=True)
        ctx.exit(3)
        return

    # Remove any CUSTOMIZE placeholders (none expected from our template, but be safe)
    rendered = rendered.replace("<!-- CUSTOMIZE:", "<!-- ")

    # dry-run: show summary only
    if dry_run:
        click.echo("Dry run — would create:")
        click.echo(f"  {project_path / 'CLAUDE.md'}")
        click.echo(f"  {project_path / 'config' / 'framework.yaml'}")
        click.echo(f"  {project_path / '.claude'}/")
        click.echo(f"  {project_path / '.shipteam-init.yaml'}")
        # Show detected stack
        parts = []
        if stack.backend:
            parts.append(stack.backend.language)
        if stack.frontend:
            parts.append(stack.frontend.language)
        stack_str = ", ".join(parts) if parts else "unknown"
        click.echo(f"Detected stack: {stack_str}")
        ctx.exit(0)
        return

    # Conflict detection via scaffold_claude_dir
    try:
        scaffold_claude_dir(
            project_dir=project_path,
            source_dir=source_dir,
            profile=profile,
            force=force,
            dry_run=False,
        )
    except ConflictError as exc:
        click.echo(f"Error: {exc}", err=True)
        ctx.exit(1)
        return

    # Write CLAUDE.md
    claude_md_path = project_path / "CLAUDE.md"
    claude_md_path.write_text(rendered, encoding="utf-8")

    # Write config/framework.yaml
    config_dir = project_path / "config"
    config_dir.mkdir(parents=True, exist_ok=True)
    fw_yaml_path = config_dir / "framework.yaml"

    stack_data: dict = {}
    if stack.backend:
        stack_data["backend"] = {"language": stack.backend.language, "root": stack.backend.root}
    if stack.frontend:
        stack_data["frontend"] = {"language": stack.frontend.language, "root": stack.frontend.root}

    config = FrameworkConfig(
        project_name=project_name,
        project_repo=repo,
        profile=profile,
        backend_language=stack.backend.language if stack.backend else None,
        frontend_language=stack.frontend.language if stack.frontend else None,
        schema_version=1,
        raw={
            "project": {"name": project_name, "repo": repo},
            "profile": profile,
            "schema_version": 1,
            "stack": stack_data,
        },
    )
    write_config(config, fw_yaml_path)

    # .gitignore
    scaffold_gitignore(project_path)

    # Save state
    th = _template_hash(template_text)
    state = InitState(
        cli_version=__version__,
        framework_version=__version__,
        schema_version=1,
        rendered_at=datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
        template_hash=th,
        region_checksums={},
        profile=profile,
    )
    save_state(state, project_path)

    click.echo("ShipTeam init complete.")
    ctx.exit(0)


def _do_refresh(
    ctx: click.Context,
    project_path: Path,
    source_dir: Path,
    repo: str,
    profile: str,
    force: bool,
    dry_run: bool,
) -> None:
    """Run refresh over existing init."""
    try:
        state = load_state(project_path)
    except ValueError as exc:
        click.echo(f"Error: corrupt state file — {exc}", err=True)
        ctx.exit(2)
        return
    if state is None:
        click.echo(
            "Error: project is not initialized — no .shipteam-init.yaml state file found. "
            "Run `shipteam init` first.",
            err=True,
        )
        ctx.exit(2)
        return

    project_name = _project_name_from_dir(project_path)
    stack = detect_stack(project_path)

    template_file = source_dir / "templates" / "CLAUDE.md.jinja"
    try:
        template_text = template_file.read_text(encoding="utf-8")
    except FileNotFoundError:
        click.echo(f"Error: template not found at {template_file}", err=True)
        ctx.exit(2)
        return

    render_ctx = RenderContext(
        project_name=project_name,
        project_repo=repo,
        stack=stack,
        profile=profile,
        deployment_method=None,
        health_url=None,
        worktree_enabled=False,
        schema_version=1,
        cli_version=__version__,
    )
    try:
        new_rendered = render_claude_md(template_text, render_ctx)
    except jinja2.TemplateError as exc:
        click.echo(f"Error: template rendering failed — {exc}", err=True)
        ctx.exit(3)
        return

    claude_md_path = project_path / "CLAUDE.md"
    existing = claude_md_path.read_text(encoding="utf-8") if claude_md_path.exists() else ""

    merged, warnings = refresh_managed_regions(existing, new_rendered, state, force=force)

    for w in warnings:
        click.echo(f"Warning: {w}")

    if not dry_run:
        claude_md_path.write_text(merged, encoding="utf-8")

        # Update state
        th = _template_hash(template_text)
        new_state = InitState(
            cli_version=__version__,
            framework_version=__version__,
            schema_version=1,
            rendered_at=datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
            template_hash=th,
            region_checksums=state.region_checksums,
            profile=profile,
        )
        save_state(new_state, project_path)

    click.echo("ShipTeam refresh complete.")
    ctx.exit(0)
