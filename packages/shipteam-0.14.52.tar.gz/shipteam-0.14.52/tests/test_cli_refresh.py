"""
Tests for `shipteam init --refresh` behaviour (CLI Phase 4 — RED).

Covers:
  - User-edited regions are preserved when --force is NOT passed
  - --force override replaces user-edited content
  - Refresh without a .shipteam-init.yaml state file exits with an error
  - Refresh on an unmodified project succeeds cleanly
"""
import textwrap
from pathlib import Path

import pytest
from click.testing import CliRunner

from shipteam.cli import main


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_framework_source(tmp_path_factory) -> Path:
    """Minimal synthetic framework source."""
    source = tmp_path_factory.mktemp("fw_source_refresh")

    (source / "framework-meta.yaml").write_text(
        textwrap.dedent("""\
            min_cli_version: "0.1.0"
            schema_version: 1
            profile_filters:
              rules:
                minimal: [anti-patterns.md]
                standard: [anti-patterns.md, security.md]
                full: ["*"]
              skills:
                minimal: []
                standard: [deploy.md]
                full: ["*"]
        """)
    )

    (source / "agents").mkdir()
    (source / "agents" / "a.md").write_text("# agent a")

    (source / "rules").mkdir()
    (source / "rules" / "anti-patterns.md").write_text("# Anti-patterns")
    (source / "rules" / "security.md").write_text("# Security")

    (source / "skills").mkdir()
    (source / "skills" / "deploy.md").write_text("# Deploy skill")

    (source / "hooks").mkdir()
    (source / "hooks" / "h.py").write_text("# hook")

    (source / "templates").mkdir()
    (source / "templates" / "CLAUDE.md.jinja").write_text(
        "# {{ project_name }} — Claude Docs\n"
    )

    return source


def _write_state(project_dir: Path) -> None:
    """Write a minimal .shipteam-init.yaml to mark the project as already initialised."""
    (project_dir / ".shipteam-init.yaml").write_text(
        textwrap.dedent("""\
            cli_version: "0.1.0"
            framework_version: "0.1.0"
            schema_version: 1
            rendered_at: "2026-04-12T00:00:00Z"
            template_hash: "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
            region_checksums: {}
            profile: "standard"
        """)
    )


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture(scope="module")
def framework_source(tmp_path_factory) -> Path:
    return _make_framework_source(tmp_path_factory)


@pytest.fixture()
def initialised_python_dir(tmp_path: Path) -> Path:
    """Python project already initialised with a state file and a CLAUDE.md."""
    (tmp_path / "pyproject.toml").write_text(
        textwrap.dedent("""\
            [project]
            name = "myapp"
        """)
    )
    (tmp_path / ".git").mkdir()
    _write_state(tmp_path)

    claude_md = tmp_path / "CLAUDE.md"
    claude_md.write_text(
        textwrap.dedent("""\
            # myapp — Claude Docs
            <!-- SHIPTEAM:MANAGED:session_start -->
            Session guidance managed by ShipTeam.
            <!-- /SHIPTEAM:MANAGED:session_start -->
            <!-- SHIPTEAM:USER:custom -->
            My custom section that must be preserved.
            <!-- /SHIPTEAM:USER:custom -->
        """)
    )
    return tmp_path


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

class TestRefreshUserEditPreservation:
    """User-edited regions must survive a refresh without --force."""

    def test_user_edited_region_preserved_without_force(
        self, initialised_python_dir: Path, framework_source: Path
    ) -> None:
        """Refresh without --force keeps user-edited content intact."""
        runner = CliRunner()
        original_custom = "My custom section that must be preserved."

        result = runner.invoke(
            main,
            [
                "init",
                str(initialised_python_dir),
                "--repo", "myorg/myapp",
                "--non-interactive",
                "--refresh",
                "--framework-dir", str(framework_source),
            ],
        )

        assert result.exit_code == 0, result.output
        claude_text = (initialised_python_dir / "CLAUDE.md").read_text()
        assert original_custom in claude_text

    def test_state_file_updated_after_refresh(
        self, initialised_python_dir: Path, framework_source: Path
    ) -> None:
        """Refresh rewrites the .shipteam-init.yaml with a new rendered_at timestamp."""
        runner = CliRunner()

        runner.invoke(
            main,
            [
                "init",
                str(initialised_python_dir),
                "--repo", "myorg/myapp",
                "--non-interactive",
                "--refresh",
                "--framework-dir", str(framework_source),
            ],
        )

        state_text = (initialised_python_dir / ".shipteam-init.yaml").read_text()
        # rendered_at must have been updated — original was 2026-04-12T00:00:00Z
        # The new value should be present; any valid ISO timestamp confirms the write
        assert "rendered_at:" in state_text


class TestRefreshForceOverride:
    """--force makes refresh replace managed regions unconditionally."""

    def test_force_refresh_exits_zero(
        self, initialised_python_dir: Path, framework_source: Path
    ) -> None:
        """--force refresh succeeds even when managed regions were modified."""
        runner = CliRunner()

        # Simulate a local modification in a managed region
        claude_md = initialised_python_dir / "CLAUDE.md"
        original = claude_md.read_text()
        claude_md.write_text(
            original.replace(
                "Session guidance managed by ShipTeam.",
                "Session guidance managed by ShipTeam. USER MODIFIED.",
            )
        )

        result = runner.invoke(
            main,
            [
                "init",
                str(initialised_python_dir),
                "--repo", "myorg/myapp",
                "--non-interactive",
                "--refresh",
                "--force",
                "--framework-dir", str(framework_source),
            ],
        )

        assert result.exit_code == 0, result.output


class TestRefreshNoStateFile:
    """Refresh without a .shipteam-init.yaml must fail with a clear error."""

    def test_refresh_without_state_file_fails(
        self, tmp_path: Path, framework_source: Path
    ) -> None:
        """Invoking --refresh on an un-initialised directory exits non-zero."""
        # Arrange — project with no state file
        (tmp_path / "pyproject.toml").write_text("[project]\nname = \"fresh\"\n")
        (tmp_path / ".git").mkdir()

        runner = CliRunner()

        result = runner.invoke(
            main,
            [
                "init",
                str(tmp_path),
                "--repo", "myorg/fresh",
                "--non-interactive",
                "--refresh",
                "--framework-dir", str(framework_source),
            ],
        )

        assert result.exit_code != 0
        # Error message must mention the missing state / un-initialised state
        output_lower = result.output.lower()
        assert "not initialized" in output_lower or "state" in output_lower or "init" in output_lower
