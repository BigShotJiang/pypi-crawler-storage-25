"""
Tests for aggregation/results.py — T-17, T-19, T-20, T-21 (AC-3, AC-4, AC-6, Phase 1).

Covers required-field enforcement for ResultRow:
  T-17: Row missing any AC-6 required field raises SchemaViolationError;
        parametrized over each of the seven required pinning fields.
  T-21: Row missing sdk_version or sdk_release_date raises SchemaViolationError
        with an error message naming the missing field explicitly.
  T-19: Cell of 10 complete rows produces median + IQR (p25, p75) for all
        required metrics; no mean-only output from the public API.
  T-20: Partial cell (< 10 rows, some aborted=true) emits a partial-cell
        warning and excludes aborted rows from aggregation statistics.

Oracle (AC-6 schema-violation):
  Absence of any required pinning field must raise an explicit SchemaViolationError
  (not silently include the row, not raise a generic KeyError/AttributeError).
"""
from dataclasses import asdict
from typing import Any

import pytest

from aggregation.results import (
    ResultRow,
    append_result_row,
    aggregate_cell,
    CellSummary,
    SchemaViolationError,
)


# ---------------------------------------------------------------------------
# Helpers — valid ResultRow factory
# ---------------------------------------------------------------------------

def _valid_row(**overrides: Any) -> dict:
    """
    Return a dict of fields for a fully valid ResultRow.
    Pass keyword overrides to replace or delete specific fields.
    Use _MISSING sentinel to delete a field entirely.
    """
    base: dict[str, Any] = {
        # Identity & pinning (AC-6, AC-11 MUST-HAVE)
        "driver": "claude_code",
        "driver_version": "0.1.15",
        "task": "url_shortener",
        "task_pack_revision": "abc1234def5678",
        "seed": 1,
        "container_digest": "sha256:deadbeef" + "0" * 56,
        "harness_version": "0.1.0",
        "sdk_version": "0.1.15",
        "sdk_release_date": "2024-09-01",
        "timestamp_utc": "2024-09-15T12:00:00Z",
        # Primary measurements
        "wall_clock_ms": 45000,
        "input_tokens": 500,
        "output_tokens": 250,
        "cost_usd": 0.0075,
        "cost_source": "native",
        # Scorer outputs
        "acceptance_pct": 0.8,
        "mutation_score": {"python": {"killed": 8, "survived": 2, "timeout": 0, "score": 0.8}},
        "semgrep_high": 0,
        "semgrep_critical": 0,
        "injected_bug_detections": 3,
        # Abort accounting
        "aborted": False,
        "abort_reason": None,
        "rate_limited_during_run": False,
        # Cache strategy (Phase 5e narrowing: literal {"salted","native"})
        "cache_strategy": "salted",
        # Driver-specific metadata (nested)
        "driver_metadata": {"cache_strategy": "salted", "cache_read_input_tokens": 0},
    }
    base.update(overrides)
    return base


_SENTINEL = object()  # used to signal field deletion


def _row_without(field: str) -> dict:
    """Return a valid row dict with the named field removed entirely."""
    row = _valid_row()
    del row[field]
    return row


# ---------------------------------------------------------------------------
# T-17 + T-21: Per-field SchemaViolationError — parametrized
# ---------------------------------------------------------------------------

# The seven required pinning fields from AC-6 + AC-11
_REQUIRED_PINNING_FIELDS = [
    "container_digest",
    "driver_version",
    "task_pack_revision",
    "harness_version",
    "sdk_version",
    "sdk_release_date",
    "timestamp_utc",
]


class TestRequiredFieldEnforcement:
    """
    T-17 / T-21: Missing any AC-6 required field raises SchemaViolationError.

    Parametrized so that each required field is tested independently.
    """

    @pytest.mark.parametrize("missing_field", _REQUIRED_PINNING_FIELDS)
    def test_missing_required_field_raises_schema_violation(
        self, missing_field: str, tmp_path
    ) -> None:
        """
        Given a ResultRow dict where one required pinning field is absent,
        When append_result_row is called,
        Then SchemaViolationError is raised (not silently written to JSONL).

        AC-6: 'missing any required field causes the aggregator to reject
        the row with an explicit schema-violation error rather than silently
        include it.'
        """
        # Arrange
        incomplete_row = _row_without(missing_field)
        output_jsonl = tmp_path / "results.jsonl"

        # Act + Assert
        with pytest.raises(SchemaViolationError):
            append_result_row(incomplete_row, output_jsonl)

    @pytest.mark.parametrize("missing_field", _REQUIRED_PINNING_FIELDS)
    def test_missing_required_field_does_not_write_jsonl(
        self, missing_field: str, tmp_path
    ) -> None:
        """
        Given a ResultRow dict missing a required pinning field,
        When append_result_row is called and raises SchemaViolationError,
        Then the output JSONL file is NOT modified (no partial row written).
        """
        # Arrange
        incomplete_row = _row_without(missing_field)
        output_jsonl = tmp_path / "results.jsonl"
        output_jsonl.write_text("")  # start empty

        # Act
        with pytest.raises(SchemaViolationError):
            append_result_row(incomplete_row, output_jsonl)

        # Assert — file stays empty; no partial row written
        assert output_jsonl.read_text() == ""

    @pytest.mark.parametrize("missing_sdk_field", ["sdk_version", "sdk_release_date"])
    def test_missing_sdk_field_error_message_names_field(
        self, missing_sdk_field: str, tmp_path
    ) -> None:
        """
        T-21: Row missing sdk_version or sdk_release_date raises SchemaViolationError
        with an error message that explicitly names the missing field.

        AC-6: 'missing any required field causes the aggregator to reject the row
        with an explicit schema-violation error' — the field name must appear in
        the exception message for debuggability.
        """
        # Arrange
        incomplete_row = _row_without(missing_sdk_field)
        output_jsonl = tmp_path / "results.jsonl"

        # Act + Assert
        with pytest.raises(SchemaViolationError) as exc_info:
            append_result_row(incomplete_row, output_jsonl)

        # The error message must name the missing field
        assert missing_sdk_field in str(exc_info.value), (
            f"SchemaViolationError message must mention '{missing_sdk_field}'; "
            f"got: {exc_info.value!r}"
        )

    def test_valid_row_does_not_raise(self, tmp_path) -> None:
        """
        Given a fully valid ResultRow dict with all required fields,
        When append_result_row is called,
        Then no exception is raised and exactly one line is written to JSONL.
        """
        # Arrange
        valid_row = _valid_row()
        output_jsonl = tmp_path / "results.jsonl"

        # Act
        append_result_row(valid_row, output_jsonl)

        # Assert — exactly one non-empty line written
        lines = [ln for ln in output_jsonl.read_text().splitlines() if ln.strip()]
        assert len(lines) == 1

    def test_empty_string_required_field_raises_schema_violation(self, tmp_path) -> None:
        """
        Given a ResultRow dict where container_digest is an empty string,
        When append_result_row is called,
        Then SchemaViolationError is raised.

        The required fields must be non-empty strings, not just present keys.
        """
        # Arrange
        row_with_empty_digest = _valid_row(container_digest="")
        output_jsonl = tmp_path / "results.jsonl"

        # Act + Assert
        with pytest.raises(SchemaViolationError):
            append_result_row(row_with_empty_digest, output_jsonl)


# ---------------------------------------------------------------------------
# T-19: Median + IQR aggregation over 10 complete rows
# ---------------------------------------------------------------------------

class TestMedianIQRAggregation:
    """
    T-19: Cell of 10 complete rows produces median + IQR for all required metrics.

    AC-4: 'per-metric median and IQR (25th, 75th percentile) are produced ...
    point estimates (mean alone) are never produced by the public API.'
    """

    def _build_cell(self, n: int = 10, aborted: bool = False) -> list[dict]:
        """Build N result rows for the same (driver, task) cell."""
        rows = []
        for i in range(n):
            row = _valid_row(
                seed=i,
                wall_clock_ms=40000 + i * 1000,    # 40000..49000
                input_tokens=500 + i * 10,           # 500..590
                output_tokens=250 + i * 5,            # 250..295
                cost_usd=0.007 + i * 0.0001,          # 0.007..0.0079
                acceptance_pct=0.7 + i * 0.01,        # 0.70..0.79
                semgrep_high=i % 3,
                semgrep_critical=0,
                injected_bug_detections=i % 5,
                aborted=aborted,
                abort_reason="wall_clock_exceeded" if aborted else None,
            )
            rows.append(row)
        return rows

    def test_cell_summary_has_median_and_iqr_for_wall_clock_ms(self) -> None:
        """
        Given 10 complete (non-aborted) result rows,
        When aggregate_cell is called,
        Then CellSummary includes median and p25/p75 for wall_clock_ms.
        """
        # Arrange
        rows = self._build_cell(n=10)

        # Act
        summary: CellSummary = aggregate_cell(rows)

        # Assert — median and IQR keys present
        assert hasattr(summary, "wall_clock_ms") or "wall_clock_ms" in summary.__dict__ or hasattr(summary.wall_clock_ms, "median"), (
            "CellSummary must expose wall_clock_ms statistics"
        )
        stats = summary.wall_clock_ms
        assert hasattr(stats, "median"), "CellSummary.wall_clock_ms must have .median"
        assert hasattr(stats, "p25"), "CellSummary.wall_clock_ms must have .p25"
        assert hasattr(stats, "p75"), "CellSummary.wall_clock_ms must have .p75"

    def test_cell_summary_has_all_required_metric_stats(self) -> None:
        """
        Given 10 complete result rows,
        When aggregate_cell is called,
        Then CellSummary exposes median + IQR for all 9 AC-4 metrics:
        wall_clock_ms, input_tokens, output_tokens, cost_usd, acceptance_pct,
        mutation_score, semgrep_high, semgrep_critical, injected_bug_detections.

        AC-4: 'per-metric median and IQR ... are produced for wall_clock_ms,
        input_tokens, output_tokens, cost_usd, acceptance_pct, mutation_score,
        semgrep_high, semgrep_critical, and injected_bug_detections.'
        """
        # Arrange
        rows = self._build_cell(n=10)

        # Act
        summary: CellSummary = aggregate_cell(rows)

        # Assert — all AC-4 scalar metrics must have median + IQR
        scalar_metrics = [
            "wall_clock_ms",
            "input_tokens",
            "output_tokens",
            "cost_usd",
            "acceptance_pct",
            "semgrep_high",
            "semgrep_critical",
            "injected_bug_detections",
        ]
        for metric in scalar_metrics:
            stats = getattr(summary, metric, None)
            assert stats is not None, (
                f"CellSummary missing metric: {metric}"
            )
            assert hasattr(stats, "median"), f"{metric}.median missing"
            assert hasattr(stats, "p25"), f"{metric}.p25 missing"
            assert hasattr(stats, "p75"), f"{metric}.p75 missing"

    def test_mean_alone_is_not_the_public_api(self) -> None:
        """
        Given 10 complete result rows,
        When aggregate_cell is called,
        Then CellSummary does NOT expose a 'mean' attribute as the primary
        statistic for any metric (median + IQR is required, not mean).

        AC-4: 'point estimates (mean alone) are never produced by the public API.'
        """
        # Arrange
        rows = self._build_cell(n=10)

        # Act
        summary: CellSummary = aggregate_cell(rows)

        # Assert — CellSummary must not be mean-only (must have median)
        stats = summary.wall_clock_ms
        assert hasattr(stats, "median"), (
            "CellSummary must report median, not mean-only"
        )

    def test_median_value_is_correct_for_known_distribution(self) -> None:
        """
        Given 10 rows with wall_clock_ms values 40000, 41000, ..., 49000,
        When aggregate_cell is called,
        Then wall_clock_ms.median == 44500 (median of 10 values).
        """
        # Arrange
        rows = self._build_cell(n=10)

        # Act
        summary: CellSummary = aggregate_cell(rows)

        # Assert — median of [40000, 41000, ..., 49000] = (44000 + 45000) / 2 = 44500
        assert abs(summary.wall_clock_ms.median - 44500.0) < 1.0, (
            f"Expected median=44500, got {summary.wall_clock_ms.median}"
        )


# ---------------------------------------------------------------------------
# T-20: Partial cell handling — aborted rows excluded from stats
# ---------------------------------------------------------------------------

class TestPartialCellAggregation:
    """
    T-20: Partial cell emits warning; aborted rows excluded from statistics.

    AC-4: 'Partial cell (< 10 rows, some aborted=true): aggregator emits
    partial-cell warning; excludes aborted rows from stats.'
    """

    def test_partial_cell_emits_warning(self) -> None:
        """
        Given 6 rows (< 10), 2 of which are aborted=True,
        When aggregate_cell is called,
        Then CellSummary signals a partial-cell warning.
        """
        # Arrange
        complete_rows = []
        for i in range(4):
            complete_rows.append(_valid_row(seed=i, wall_clock_ms=40000 + i * 500))

        aborted_rows = []
        for i in range(2):
            aborted_rows.append(_valid_row(
                seed=10 + i,
                aborted=True,
                abort_reason="budget_exceeded",
                wall_clock_ms=5000,
            ))

        rows = complete_rows + aborted_rows

        # Act
        summary: CellSummary = aggregate_cell(rows)

        # Assert — CellSummary reports partial cell
        assert summary.is_partial is True, (
            "CellSummary.is_partial must be True when fewer than 10 complete rows"
        )

    def test_aborted_rows_excluded_from_statistics(self) -> None:
        """
        Given 5 complete rows with wall_clock_ms=40000 and 3 aborted rows
        with wall_clock_ms=999,
        When aggregate_cell is called,
        Then wall_clock_ms statistics are computed over the 5 complete rows only
        (median ~= 40000, not influenced by the aborted-row value of 999).
        """
        # Arrange
        complete_rows = [
            _valid_row(seed=i, wall_clock_ms=40000) for i in range(5)
        ]
        aborted_rows = [
            _valid_row(
                seed=10 + i,
                wall_clock_ms=999,
                aborted=True,
                abort_reason="wall_clock_exceeded",
            )
            for i in range(3)
        ]
        rows = complete_rows + aborted_rows

        # Act
        summary: CellSummary = aggregate_cell(rows)

        # Assert — aborted rows must not influence the median
        assert summary.wall_clock_ms.median == 40000, (
            f"Aborted rows must be excluded; expected median=40000, "
            f"got {summary.wall_clock_ms.median}"
        )
