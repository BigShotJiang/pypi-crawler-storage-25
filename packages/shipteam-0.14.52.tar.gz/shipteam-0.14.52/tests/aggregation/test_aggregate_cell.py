"""
Tests for aggregation/results.py — aggregate_cell function.

Sub-phase D of Phase 2 Part 2 scorers — AC-21 None-handling policy.

Covers:
  T-19 (P1, AC-4):  Cell of 10 rows: median + p25 + p75 computed for each of
                    the required metrics; no mean-only output from public API.
  T-20 (P1, AC-4):  Partial cell (<10 rows, some aborted=True): partial-cell
                    warning emitted; aborted rows excluded from stats.
  T-71 (P0, AC-21): None values in per-metric scores excluded from median/IQR;
                    sample_size_per_metric reports effective N per metric.
  T-72 (P0, AC-21): Partial-cell WARN when any metric's effective N < 0.7 × N
                    total non-aborted (threshold inclusive: 7/10 = 0.7 fires).
  T-73 (P0, AC-21): Cell-invalid ERROR when any metric's effective N < 3;
                    those metrics return None for median/p25/p75.

Interface contract (CellSummary from .sherlock-plan.md §AC-21):
  - median_per_metric: dict[str, float | None]  — None means < 3 valid samples
  - p25_per_metric:    dict[str, float | None]
  - p75_per_metric:    dict[str, float | None]
  - sample_size_per_metric: dict[str, int]      — effective N after None-exclusion
  - row_count_total:   int                      — total rows (including aborted)
  - row_count_valid:   int                      — rows after aborted exclusion
  - warnings:          list[str]                — partial-cell / missing-metric
  - errors:            list[str]                — cell-invalid (sample_size < 3)

Percentile convention:
  numpy.percentile linear interpolation (the default).  For values
  [100, 110, 120, 130, 140, 150, 160, 170, 180, 190] (n=10):
    median = 145.0   (mean of 140 and 150)
    p25    = 122.5   (index 2.25 → 120 + 0.25 × 10)
    p75    = 167.5   (index 6.75 → 160 + 0.75 × 10)

Metrics aggregated (subset available in ResultRow prior to Phase 2 Part 3
integration of scorer outputs; per-language mutation extracted separately):
  wall_clock_ms, input_tokens, output_tokens, cost_usd, acceptance_pct,
  semgrep_high, semgrep_critical, injected_bug_detections
"""
from __future__ import annotations

from typing import Any

import pytest

from aggregation.results import (
    ResultRow,
    aggregate_cell,
    CellSummary,
)


# ---------------------------------------------------------------------------
# Helpers — factory for valid row dicts
# ---------------------------------------------------------------------------

def _valid_row(**overrides: Any) -> dict:
    """Return a dict for a fully valid ResultRow. Override any field via kwargs."""
    base: dict[str, Any] = {
        "driver": "claude_code",
        "driver_version": "0.1.15",
        "task": "url_shortener",
        "task_pack_revision": "abc1234def5678",
        "seed": 1,
        "container_digest": "sha256:deadbeef" + "0" * 56,
        "harness_version": "0.1.0",
        "sdk_version": "0.1.15",
        "sdk_release_date": "2024-09-01",
        "timestamp_utc": "2024-09-15T12:00:00Z",
        "wall_clock_ms": 45_000,
        "input_tokens": 500,
        "output_tokens": 250,
        "cost_usd": 0.0075,
        "cost_source": "native",
        "acceptance_pct": 0.8,
        "mutation_score": {"python": {"killed": 8, "survived": 2, "timeout": 0, "score": 0.8}},
        "semgrep_high": 0,
        "semgrep_critical": 0,
        "injected_bug_detections": 3,
        "aborted": False,
        "abort_reason": None,
        "rate_limited_during_run": False,
        "cache_strategy": "salted",
        "driver_metadata": {"cache_read_input_tokens": 0},
    }
    base.update(overrides)
    return base


# Metrics expected in CellSummary outputs (AC-4 subset available pre-Part-3)
_REQUIRED_METRICS = [
    "wall_clock_ms",
    "input_tokens",
    "output_tokens",
    "cost_usd",
    "acceptance_pct",
    "semgrep_high",
    "semgrep_critical",
    "injected_bug_detections",
]


# ---------------------------------------------------------------------------
# T-19: Median + IQR aggregation over 10 complete rows
# ---------------------------------------------------------------------------

class TestMedianIQRAggregation:
    """
    T-19 (P1, AC-4): 10 complete rows → correct median + IQR for all metrics.

    The new CellSummary interface uses dict-keyed stats rather than attribute
    objects, per the AC-21 interface contract.
    """

    def _ten_rows(self) -> list[dict]:
        """
        10 rows with wall_clock_ms = [100, 110, ..., 190].

        Expected percentiles (numpy linear):
          median = 145.0, p25 = 122.5, p75 = 167.5
        """
        return [
            _valid_row(seed=i, wall_clock_ms=100 + i * 10)
            for i in range(10)
        ]

    def test_t19_median_per_metric_present_for_all_required_metrics(self) -> None:
        """
        Given 10 complete non-aborted rows,
        When aggregate_cell is called,
        Then CellSummary.median_per_metric contains a key for each required metric.

        AC-4: per-metric median must be produced for all 8 scalar metrics.
        """
        # Arrange
        rows = self._ten_rows()

        # Act
        summary: CellSummary = aggregate_cell(rows)

        # Assert
        for metric in _REQUIRED_METRICS:
            assert metric in summary.median_per_metric, (
                f"median_per_metric must contain key '{metric}'"
            )

    def test_t19_p25_and_p75_per_metric_present(self) -> None:
        """
        Given 10 complete rows,
        When aggregate_cell is called,
        Then p25_per_metric and p75_per_metric each contain all required metrics.

        AC-4: IQR (p25 + p75) is required — not just median.
        """
        # Arrange
        rows = self._ten_rows()

        # Act
        summary: CellSummary = aggregate_cell(rows)

        # Assert
        for metric in _REQUIRED_METRICS:
            assert metric in summary.p25_per_metric, (
                f"p25_per_metric must contain key '{metric}'"
            )
            assert metric in summary.p75_per_metric, (
                f"p75_per_metric must contain key '{metric}'"
            )

    def test_t19_median_value_correct_for_known_distribution(self) -> None:
        """
        Given wall_clock_ms = [100, 110, 120, 130, 140, 150, 160, 170, 180, 190],
        When aggregate_cell is called,
        Then median_per_metric["wall_clock_ms"] == 145.0
             p25_per_metric["wall_clock_ms"]    == 122.5
             p75_per_metric["wall_clock_ms"]    == 167.5

        Using numpy.percentile with linear interpolation (default).
        """
        # Arrange
        rows = self._ten_rows()

        # Act
        summary: CellSummary = aggregate_cell(rows)

        # Assert
        assert abs(summary.median_per_metric["wall_clock_ms"] - 145.0) < 0.01, (
            f"Expected median=145.0, got {summary.median_per_metric['wall_clock_ms']}"
        )
        assert abs(summary.p25_per_metric["wall_clock_ms"] - 122.5) < 0.01, (
            f"Expected p25=122.5, got {summary.p25_per_metric['wall_clock_ms']}"
        )
        assert abs(summary.p75_per_metric["wall_clock_ms"] - 167.5) < 0.01, (
            f"Expected p75=167.5, got {summary.p75_per_metric['wall_clock_ms']}"
        )

    def test_t19_no_mean_only_output(self) -> None:
        """
        Given 10 complete rows,
        When aggregate_cell is called,
        Then CellSummary does NOT expose a top-level 'mean_per_metric' as the
        sole statistic — it must have median_per_metric.

        AC-4: 'point estimates (mean alone) are never produced by the public API.'
        """
        # Arrange
        rows = self._ten_rows()

        # Act
        summary: CellSummary = aggregate_cell(rows)

        # Assert — median must be present (mean-only is forbidden)
        assert hasattr(summary, "median_per_metric"), (
            "CellSummary must have median_per_metric (not mean-only)"
        )
        assert summary.median_per_metric.get("wall_clock_ms") is not None, (
            "median_per_metric['wall_clock_ms'] must not be None for 10 complete rows"
        )

    def test_t19_row_counts_correct(self) -> None:
        """
        Given 10 complete non-aborted rows,
        When aggregate_cell is called,
        Then row_count_total == 10 and row_count_valid == 10.
        """
        # Arrange
        rows = self._ten_rows()

        # Act
        summary: CellSummary = aggregate_cell(rows)

        # Assert
        assert summary.row_count_total == 10
        assert summary.row_count_valid == 10


# ---------------------------------------------------------------------------
# T-20: Partial cell — aborted rows excluded from stats, warning emitted
# ---------------------------------------------------------------------------

class TestPartialCellAggregation:
    """
    T-20 (P1, AC-4): Partial cell emits warning; aborted rows excluded from stats.
    """

    def test_t20_partial_cell_warning_emitted(self) -> None:
        """
        Given 10 rows of which 3 are aborted=True (7 valid),
        When aggregate_cell is called,
        Then CellSummary.warnings contains at least one partial-cell warning.

        AC-4: 'Partial cell emits partial-cell warning.'
        """
        # Arrange
        valid_rows = [_valid_row(seed=i, wall_clock_ms=40_000 + i * 1000) for i in range(7)]
        aborted_rows = [
            _valid_row(seed=20 + i, aborted=True, abort_reason="wall_clock_exceeded")
            for i in range(3)
        ]
        rows = valid_rows + aborted_rows

        # Act
        summary: CellSummary = aggregate_cell(rows)

        # Assert
        assert len(summary.warnings) > 0, (
            "CellSummary.warnings must be non-empty for a partial cell"
        )
        # At least one warning should mention 'partial'
        partial_warns = [w for w in summary.warnings if "partial" in w.lower()]
        assert len(partial_warns) > 0, (
            f"Expected a 'partial' warning; got: {summary.warnings}"
        )

    def test_t20_aborted_rows_excluded_from_statistics(self) -> None:
        """
        Given 7 valid rows (wall_clock_ms=40_000) and 3 aborted rows
        (wall_clock_ms=999),
        When aggregate_cell is called,
        Then median_per_metric["wall_clock_ms"] == 40_000.0 (aborted rows excluded).
        """
        # Arrange
        valid_rows = [_valid_row(seed=i, wall_clock_ms=40_000) for i in range(7)]
        aborted_rows = [
            _valid_row(
                seed=10 + i,
                wall_clock_ms=999,
                aborted=True,
                abort_reason="budget_exceeded",
            )
            for i in range(3)
        ]
        rows = valid_rows + aborted_rows

        # Act
        summary: CellSummary = aggregate_cell(rows)

        # Assert
        assert summary.median_per_metric["wall_clock_ms"] == 40_000.0, (
            f"Aborted rows must not influence median; "
            f"got {summary.median_per_metric['wall_clock_ms']}"
        )

    def test_t20_row_counts_reflect_aborted_rows(self) -> None:
        """
        Given 7 valid rows and 3 aborted rows,
        When aggregate_cell is called,
        Then row_count_total == 10 and row_count_valid == 7.
        """
        # Arrange
        valid_rows = [_valid_row(seed=i) for i in range(7)]
        aborted_rows = [
            _valid_row(seed=10 + i, aborted=True, abort_reason="oom")
            for i in range(3)
        ]
        rows = valid_rows + aborted_rows

        # Act
        summary: CellSummary = aggregate_cell(rows)

        # Assert
        assert summary.row_count_total == 10
        assert summary.row_count_valid == 7


# ---------------------------------------------------------------------------
# T-71 (P0, AC-21): None values excluded per-metric; effective N reported
# ---------------------------------------------------------------------------

class TestNoneHandlingPolicy:
    """
    T-71 (P0, AC-21): None metric values are excluded from that metric's
    median/IQR computation; sample_size_per_metric reports effective N.

    AC-21: 'Within non-aborted rows, exclude rows whose metric value is None
    from THAT metric's stats (different metrics have different effective N).
    sample_size_per_metric reports the effective N for each metric after
    None exclusion.'
    """

    def test_t71_none_values_excluded_from_metric_stats(self) -> None:
        """
        Given 10 non-aborted rows where 3 rows have wall_clock_ms=None,
        When aggregate_cell is called,
        Then:
          - sample_size_per_metric["wall_clock_ms"] == 7 (not 10)
          - median_per_metric["wall_clock_ms"] is not None (7 >= 3)
          - other metrics with no Nones still have sample_size == 10.

        AC-21: None values in per-metric scores excluded from median/IQR;
        effective N per metric is tracked independently.
        """
        # Arrange: rows 0–6 have wall_clock_ms values; rows 7–9 have None
        valid_rows = [
            _valid_row(seed=i, wall_clock_ms=100 + i * 10)  # 100..160
            for i in range(7)
        ]
        none_rows = [
            _valid_row(seed=7 + i, wall_clock_ms=None)
            for i in range(3)
        ]
        rows = valid_rows + none_rows

        # Act
        summary: CellSummary = aggregate_cell(rows)

        # Assert — effective N for wall_clock_ms is 7 (3 None rows excluded)
        assert summary.sample_size_per_metric["wall_clock_ms"] == 7, (
            f"Expected effective N=7 for wall_clock_ms, "
            f"got {summary.sample_size_per_metric['wall_clock_ms']}"
        )

        # median is still computable (7 >= 3)
        assert summary.median_per_metric["wall_clock_ms"] is not None, (
            "median_per_metric['wall_clock_ms'] must not be None when N=7"
        )

    def test_t71_none_exclusion_is_per_metric_independent(self) -> None:
        """
        Given 10 non-aborted rows where 3 have wall_clock_ms=None but
        all 10 have input_tokens set,
        When aggregate_cell is called,
        Then sample_size_per_metric["wall_clock_ms"] == 7
         AND sample_size_per_metric["input_tokens"]  == 10.

        AC-21: 'different metrics have different effective N.'
        """
        # Arrange
        rows = []
        for i in range(10):
            wc = None if i >= 7 else (100 + i * 10)
            rows.append(_valid_row(seed=i, wall_clock_ms=wc, input_tokens=500 + i))

        # Act
        summary: CellSummary = aggregate_cell(rows)

        # Assert — independent effective N per metric
        assert summary.sample_size_per_metric["wall_clock_ms"] == 7
        assert summary.sample_size_per_metric["input_tokens"] == 10

        # M-3 fix: also assert the median is computed from the correct subset.
        # A broken impl that tracked effective_n=7 but median-ed over all 10 rows
        # (treating None as 0) would pass the count-only assertion above but fail
        # this median check. 7 non-None wall_clock values: [100,110,120,130,140,150,160]
        # → median = 130.0.
        assert summary.median_per_metric["wall_clock_ms"] == 130.0


# ---------------------------------------------------------------------------
# T-72 (P0, AC-21): Partial-cell WARN at 0.7 threshold (inclusive)
# ---------------------------------------------------------------------------

class TestPartialCellThreshold:
    """
    T-72 (P0, AC-21): WARN fires when any metric's effective N < 0.7 × total
    non-aborted rows.  Threshold is inclusive: exactly 0.7 triggers WARN.

    AC-21: 'Partial-cell WARN fires when any metric's effective N < 0.7 ×
    total_non_aborted_rows (inclusive threshold: at 7/10 = 0.7 it fires,
    at 8/10 = 0.8 it doesn't).'
    """

    def test_t72_warn_fires_at_exact_threshold_boundary(self) -> None:
        """
        Given 10 non-aborted rows where exactly 3 have wall_clock_ms=None
        (effective N=7, ratio=0.7 exactly),
        When aggregate_cell is called,
        Then CellSummary.warnings contains a warning for wall_clock_ms.

        Boundary: 7/10 = 0.7 → WARN fires (inclusive).
        """
        # Arrange: 7 rows with value, 3 with None → ratio 7/10 = 0.70
        rows = []
        for i in range(10):
            wc = None if i >= 7 else (100 + i * 10)
            rows.append(_valid_row(seed=i, wall_clock_ms=wc))

        # Act
        summary: CellSummary = aggregate_cell(rows)

        # Assert — warning must fire
        assert len(summary.warnings) > 0, (
            "WARN must fire when effective N = 0.7 × total non-aborted (inclusive)"
        )
        warn_text = " ".join(summary.warnings).lower()
        assert "wall_clock_ms" in warn_text, (
            f"Warning must name the metric; got: {summary.warnings}"
        )

    def test_t72_no_warn_when_above_threshold(self) -> None:
        """
        Given 10 non-aborted rows where only 2 have wall_clock_ms=None
        (effective N=8, ratio=0.8),
        When aggregate_cell is called,
        Then CellSummary.warnings contains NO partial-cell warning for
        wall_clock_ms (8/10 = 0.8 > 0.7 → threshold not breached).
        """
        # Arrange: 8 rows with value, 2 with None → ratio 8/10 = 0.80
        rows = []
        for i in range(10):
            wc = None if i >= 8 else (100 + i * 10)
            rows.append(_valid_row(seed=i, wall_clock_ms=wc))

        # Act
        summary: CellSummary = aggregate_cell(rows)

        # Assert — no None-related partial-cell warning for wall_clock_ms
        warn_text = " ".join(summary.warnings).lower()
        # There should be no partial-cell warning referencing wall_clock_ms None-rate
        assert "wall_clock_ms" not in warn_text, (
            f"Should not warn when effective N=8/10=0.8 > 0.7; got: {summary.warnings}"
        )


# ---------------------------------------------------------------------------
# T-73 (P0, AC-21): Cell-invalid ERROR when effective N < 3
# ---------------------------------------------------------------------------

class TestCellInvalidError:
    """
    T-73 (P0, AC-21): ERROR fires when any metric's effective N < 3;
    those metrics return None for median/p25/p75.

    AC-21: 'Cell-invalid ERROR fires when any metric's effective N < 3
    (too few samples to median meaningfully). Those metrics'
    median/p25/p75 return None.'
    """

    def test_t73_error_fires_when_effective_n_below_3(self) -> None:
        """
        Given 10 non-aborted rows where 8 have wall_clock_ms=None
        (effective N=2, below the minimum of 3),
        When aggregate_cell is called,
        Then CellSummary.errors is non-empty and names wall_clock_ms.

        AC-21: 'Cell-invalid ERROR fires when any metric's effective N < 3.'
        """
        # Arrange: only 2 rows have wall_clock_ms set
        rows = []
        for i in range(10):
            wc = None if i >= 2 else (100 + i * 10)
            rows.append(_valid_row(seed=i, wall_clock_ms=wc))

        # Act
        summary: CellSummary = aggregate_cell(rows)

        # Assert
        assert len(summary.errors) > 0, (
            "CellSummary.errors must be non-empty when effective N < 3 for any metric"
        )
        error_text = " ".join(summary.errors).lower()
        assert "wall_clock_ms" in error_text, (
            f"Error must name the affected metric; got: {summary.errors}"
        )

    def test_t73_metric_stats_return_none_when_cell_invalid(self) -> None:
        """
        Given effective N=2 for wall_clock_ms,
        When aggregate_cell is called,
        Then median_per_metric["wall_clock_ms"] is None
         AND p25_per_metric["wall_clock_ms"] is None
         AND p75_per_metric["wall_clock_ms"] is None.

        AC-21: 'Those metrics' median/p25/p75 return None.'
        """
        # Arrange: 2 valid wall_clock_ms values out of 10 rows
        rows = []
        for i in range(10):
            wc = None if i >= 2 else (100 + i * 10)
            rows.append(_valid_row(seed=i, wall_clock_ms=wc))

        # Act
        summary: CellSummary = aggregate_cell(rows)

        # Assert — None returned for all three stats of the invalid metric
        assert summary.median_per_metric["wall_clock_ms"] is None, (
            "median must be None when effective N < 3"
        )
        assert summary.p25_per_metric["wall_clock_ms"] is None, (
            "p25 must be None when effective N < 3"
        )
        assert summary.p75_per_metric["wall_clock_ms"] is None, (
            "p75 must be None when effective N < 3"
        )

    def test_t73_other_metrics_unaffected_when_one_invalid(self) -> None:
        """
        Given effective N=2 for wall_clock_ms but N=10 for input_tokens,
        When aggregate_cell is called,
        Then input_tokens still has valid (non-None) median/p25/p75,
        confirming that cell-invalid is per-metric, not cell-wide.

        AC-21: None-exclusion policy is per-metric (different effective N).
        """
        # Arrange: wall_clock_ms has only 2 values; input_tokens has 10
        rows = []
        for i in range(10):
            wc = None if i >= 2 else (100 + i * 10)
            rows.append(_valid_row(seed=i, wall_clock_ms=wc, input_tokens=500 + i))

        # Act
        summary: CellSummary = aggregate_cell(rows)

        # Assert — input_tokens unaffected
        assert summary.median_per_metric["input_tokens"] is not None, (
            "input_tokens median must not be None (N=10)"
        )
        assert summary.p25_per_metric["input_tokens"] is not None
        assert summary.p75_per_metric["input_tokens"] is not None


# ---------------------------------------------------------------------------
# T-74/T-75: degenerate-input edge cases (empty cell, all aborted)
# ---------------------------------------------------------------------------

class TestDegenerateInputs:
    """
    T-74/T-75 (fw-review-code L-1 fix): exercise the empty-rows + all-aborted
    paths. Runner integration in Phase 2 Part 3 is likely to produce these
    on failed task categories; catching them here beats catching them there.
    """

    def test_t74_empty_rows_returns_errors_no_exceptions(self) -> None:
        """aggregate_cell([]) returns a CellSummary with errors populated, no raise."""
        summary = aggregate_cell([])

        assert summary.row_count_total == 0
        assert summary.row_count_valid == 0
        # Every metric hits cell-invalid (N=0 < 3) — each gets an ERROR entry
        assert len(summary.errors) == 8, (
            f"Expected one error per metric (8 metrics); got {len(summary.errors)}"
        )
        # And median/p25/p75 are None for every metric
        for metric, median in summary.median_per_metric.items():
            assert median is None, f"Expected {metric} median=None for empty cell"
        # No partial-cell WARN (row_count_valid == 0 short-circuits the row-level warning)
        assert summary.warnings == [], (
            f"Expected no warnings for empty cell; got: {summary.warnings}"
        )

    def test_t75_all_aborted_returns_errors_no_exceptions(self) -> None:
        """aggregate_cell of 10 all-aborted rows returns same shape as empty."""
        rows = [_valid_row(seed=i, aborted=True) for i in range(10)]

        summary = aggregate_cell(rows)

        assert summary.row_count_total == 10
        assert summary.row_count_valid == 0
        # All-aborted looks just like empty to the stats layer
        assert len(summary.errors) == 8
        assert summary.warnings == []
        assert all(v is None for v in summary.median_per_metric.values())


# ---------------------------------------------------------------------------
# DEFERRED to Phase 2 Part 3: T-59 mutation_score nested-metric flattening
# ---------------------------------------------------------------------------
# The .test-matrix.md T-59 oracle tests that sample_size_per_metric[
# "mutation_python_score"] reflects effective N over rows where
# mutation_score.per_language["python"] is None. The current ResultRow schema
# predates Sub-phases A/B/C and does NOT carry scorer outputs directly —
# those are consumed via side-file sidecars (injected_bugs_detail.jsonl)
# or scorer-level dataclasses (MutationResult.per_language dict). Nested-
# metric flattening requires extending ResultRow to carry scorer-output
# fields, which is Phase 2 Part 3 runner-integration scope. _AGGREGATE_METRICS
# will expand there; aggregate_cell already supports per-metric None
# handling, so the extension is additive (no impl-contract break).
