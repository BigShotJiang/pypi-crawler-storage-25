"""AC-8 + AC-9: PyPI bundle of /verify-math skill, plus hook bundle drift.

ShipTeam syncs the skill into downstream projects via fw-sync.sh, but the
PyPI wheel ships from src/shipteam/framework/. If the bundled copy drifts
from .claude/skills/verify-math/, downstream `uvx shipteam init` users
get a different version than the source — the exact gap that motivated
this PR.

These tests guard:
- AC-8: every shipped file is byte-identical between source and bundle
- AC-9: every bundled file is registered in config/fw-manifest.yaml under
  the skills: section with config_gate: "skills.verify_math"
- Hook drift: every manifest-registered policy:replace hook is present and
  byte-identical between .claude/hooks/ and the wheel bundle. Closes the
  gap that let auto_approve_base.py drift ~6 weeks behind canonical
  (see Insight #29 in docs/70-INSIGHTS.md).
"""

from __future__ import annotations

import hashlib
from pathlib import Path

import pytest
import yaml

_REPO_ROOT = Path(__file__).parent.parent
_SOURCE_DIR = _REPO_ROOT / ".claude" / "skills" / "verify-math"
_BUNDLE_DIR = _REPO_ROOT / "src" / "shipteam" / "framework" / "skills" / "verify-math"
_HOOKS_SOURCE_DIR = _REPO_ROOT / ".claude" / "hooks"
_HOOKS_BUNDLE_DIR = _REPO_ROOT / "src" / "shipteam" / "framework" / "hooks"
_MANIFEST = _REPO_ROOT / "config" / "fw-manifest.yaml"

#: Files the skill ships with. README.md is documentation; SKILL.md is
#: discovery; verify.py is the CLI entry. Add new files here when the skill
#: grows — the test fails if the listed files don't all exist in both trees.
_SHIPPED_FILES: tuple[str, ...] = ("SKILL.md", "verify.py", "README.md")


def _sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


class TestBundleDriftAC8:
    """AC-8: bundled skill is byte-identical to .claude/ source."""

    @pytest.mark.parametrize("filename", _SHIPPED_FILES)
    def test_shipped_file_exists_in_source(self, filename):
        path = _SOURCE_DIR / filename
        assert path.exists(), (
            f"Source skill is missing {filename}. "
            f"Either update _SHIPPED_FILES or add the file at {path}."
        )

    @pytest.mark.parametrize("filename", _SHIPPED_FILES)
    def test_shipped_file_exists_in_bundle(self, filename):
        path = _BUNDLE_DIR / filename
        assert path.exists(), (
            f"PyPI bundle is missing {filename} at {path}. "
            f"Run: cp .claude/skills/verify-math/{filename} {path}"
        )

    @pytest.mark.parametrize("filename", _SHIPPED_FILES)
    def test_bundled_file_byte_identical_to_source(self, filename):
        source = _SOURCE_DIR / filename
        bundle = _BUNDLE_DIR / filename
        if not source.exists() or not bundle.exists():
            pytest.skip(f"missing {filename} in source or bundle (covered by sibling tests)")
        src_hash = _sha256(source)
        bundle_hash = _sha256(bundle)
        assert src_hash == bundle_hash, (
            f"{filename} drift: source sha256={src_hash[:12]} != "
            f"bundle sha256={bundle_hash[:12]}. "
            f"Run: cp {source} {bundle}"
        )

    def test_source_and_bundle_are_distinct_paths(self):
        """Path-config guard: source and bundle must be DIFFERENT directories.

        Without this, a copy-paste typo could set both paths to the same dir
        and every byte-identical test would PASS by tautology. This test is
        the assertion that the comparison is meaningful.
        """
        assert _SOURCE_DIR != _BUNDLE_DIR, (
            f"_SOURCE_DIR and _BUNDLE_DIR are the same path ({_SOURCE_DIR}) — "
            "byte-identical tests would tautologically pass; comparison is meaningless"
        )
        assert _SOURCE_DIR.exists(), f"_SOURCE_DIR missing: {_SOURCE_DIR}"
        assert _BUNDLE_DIR.exists(), f"_BUNDLE_DIR missing: {_BUNDLE_DIR}"

    def test_drift_oracle_actually_detects_drift(self, tmp_path):
        """Meta-oracle: confirm the byte-comparison logic itself catches drift.

        Without this, the parametrized tests above could all PASS even if the
        comparison logic is broken (e.g., comparing a file to itself).
        """
        a = tmp_path / "a.txt"
        b = tmp_path / "b.txt"
        a.write_text("verify-math")
        b.write_text("verify-math\n")  # one-byte difference
        assert _sha256(a) != _sha256(b), (
            "drift oracle is broken: it claims two different files are identical"
        )


class TestManifestRegistrationAC9:
    """AC-9: every shipped skill file is registered in fw-manifest.yaml.

    Uses yaml.safe_load to traverse the parsed structure rather than text
    matching — text matching would false-positive on comments / description
    values that mention the same path string.
    """

    @pytest.fixture(scope="class")
    def manifest(self) -> dict:
        assert _MANIFEST.exists(), f"fw-manifest.yaml not found at {_MANIFEST}"
        return yaml.safe_load(_MANIFEST.read_text())

    def test_manifest_has_skills_section(self, manifest):
        assert "skills" in manifest, "fw-manifest.yaml has no 'skills:' top-level section"
        assert isinstance(manifest["skills"], dict), "'skills' must be a mapping"

    @pytest.mark.parametrize("filename", _SHIPPED_FILES)
    def test_each_shipped_file_registered(self, manifest, filename):
        skills = manifest.get("skills", {})
        expected_key = f".claude/skills/verify-math/{filename}"
        assert expected_key in skills, (
            f"{filename} not registered under skills: in fw-manifest.yaml. "
            f"Existing keys: {sorted(skills.keys())}"
        )
        entry = skills[expected_key]
        assert isinstance(entry, dict), (
            f"manifest entry for {filename} is not a mapping: {entry!r}"
        )
        assert entry.get("policy") == "replace", (
            f"manifest entry for {filename} must have policy: replace; got {entry.get('policy')!r}"
        )

    @pytest.mark.parametrize("filename", _SHIPPED_FILES)
    def test_verify_math_uses_consistent_config_gate(self, manifest, filename):
        """All verify-math entries share the same config_gate so users can
        toggle the skill on/off as a unit."""
        entry = manifest["skills"][f".claude/skills/verify-math/{filename}"]
        assert entry.get("config_gate") == "skills.verify_math", (
            f"{filename} entry has config_gate={entry.get('config_gate')!r}; "
            f"expected 'skills.verify_math'"
        )


def _replace_hooks_from_manifest() -> list[str]:
    """Return basenames of hooks: entries with policy: replace.

    Derived from manifest at module load. The manifest is the policy source
    of truth for what fw-sync.sh copies to downstream projects, so it is
    also the authority for what the wheel bundle must ship byte-identical.

    policy: template entries (e.g., auto-approve.py overlay) are excluded —
    those are intentionally allowed to differ between canonical and bundle.
    """
    manifest = yaml.safe_load(_MANIFEST.read_text())
    hooks = manifest.get("hooks", {})
    out: list[str] = []
    for key, entry in hooks.items():
        if not key.startswith(".claude/hooks/"):
            continue
        if not isinstance(entry, dict):
            continue
        if entry.get("policy") != "replace":
            continue
        out.append(key.split("/")[-1])
    return sorted(out)


_REPLACE_HOOKS: list[str] = _replace_hooks_from_manifest()


class TestHookBundleDrift:
    """Hook bundle drift guard.

    auto_approve_base.py silently drifted ~6 weeks behind canonical because
    safety-infra patches have three landing sites (canonical, sync target,
    wheel bundle) and the bundle is exercised only by uvx-installed users.
    These tests turn the bundle into a CI-enforced mirror so future drift
    fails the build instead of waiting for an audit.
    """

    def test_source_and_bundle_are_distinct_paths(self):
        assert _HOOKS_SOURCE_DIR != _HOOKS_BUNDLE_DIR, (
            f"_HOOKS_SOURCE_DIR and _HOOKS_BUNDLE_DIR are the same path "
            f"({_HOOKS_SOURCE_DIR}) — byte-identical tests would tautologically "
            "pass; comparison is meaningless"
        )
        assert _HOOKS_SOURCE_DIR.exists(), f"_HOOKS_SOURCE_DIR missing: {_HOOKS_SOURCE_DIR}"
        assert _HOOKS_BUNDLE_DIR.exists(), f"_HOOKS_BUNDLE_DIR missing: {_HOOKS_BUNDLE_DIR}"

    def test_manifest_lists_at_least_one_replace_hook(self):
        """Sanity guard: if the manifest parser returns an empty list, the
        parametrized tests below would silently pass with zero coverage."""
        assert _REPLACE_HOOKS, (
            "no policy:replace hook entries found in fw-manifest.yaml — "
            "either the manifest is empty or the parser is broken; "
            "the parametrized hook drift tests would silently skip"
        )

    @pytest.mark.parametrize("filename", _REPLACE_HOOKS)
    def test_replace_hook_exists_in_source(self, filename):
        path = _HOOKS_SOURCE_DIR / filename
        assert path.exists(), (
            f".claude/hooks/{filename} is registered in fw-manifest.yaml "
            f"as policy:replace but does not exist in canonical hooks dir."
        )

    @pytest.mark.parametrize("filename", _REPLACE_HOOKS)
    def test_replace_hook_exists_in_bundle(self, filename):
        path = _HOOKS_BUNDLE_DIR / filename
        assert path.exists(), (
            f"PyPI bundle is missing {filename} at {path}. "
            f"Mirror canonical: cp .claude/hooks/{filename} {path}"
        )

    @pytest.mark.parametrize("filename", _REPLACE_HOOKS)
    def test_replace_hook_byte_identical_to_source(self, filename):
        source = _HOOKS_SOURCE_DIR / filename
        bundle = _HOOKS_BUNDLE_DIR / filename
        if not source.exists() or not bundle.exists():
            pytest.skip(f"missing {filename} in source or bundle (covered by sibling tests)")
        src_hash = _sha256(source)
        bundle_hash = _sha256(bundle)
        assert src_hash == bundle_hash, (
            f"{filename} drift: canonical sha256={src_hash[:12]} != "
            f"bundle sha256={bundle_hash[:12]}. "
            f"Mirror canonical to bundle: cp {source} {bundle}"
        )

    def test_no_orphan_hook_in_bundle(self):
        """Every .py hook physically present in the bundle must be registered
        in fw-manifest.yaml. An unregistered hook ships to PyPI users but
        fw-sync.sh skips it, producing the inverse of bundle drift: PyPI
        users get a hook that downstream-synced users do not.
        """
        manifest = yaml.safe_load(_MANIFEST.read_text())
        registered = {
            key.split("/")[-1]
            for key in manifest.get("hooks", {})
            if key.startswith(".claude/hooks/")
        }
        bundled = {p.name for p in _HOOKS_BUNDLE_DIR.iterdir() if p.is_file() and p.suffix == ".py"}
        orphans = sorted(bundled - registered)
        assert not orphans, (
            f"hooks present in wheel bundle but not registered in fw-manifest.yaml: "
            f"{orphans}. Add each under hooks: in config/fw-manifest.yaml or "
            f"remove from src/shipteam/framework/hooks/."
        )
