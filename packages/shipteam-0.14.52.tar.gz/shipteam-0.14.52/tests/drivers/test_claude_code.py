"""
Tests for drivers/claude_code.py — T-37 (AC-1, AC-7, AC-14, Phase 1).

Covers the Agent SDK adapter's native cost path:
  - DriverResult.cost_source == "native"
  - input_tokens and output_tokens are integers (not None) on SDK success
  - cost_usd is a float on SDK success
  - cache_strategy is "omitted" when disable_prompt_cache=True
  - Nullable int types tolerated when the SDK returns None for token fields
"""
import pytest

pytest.skip(
    "Phase 5e: claude_code adapter rewritten on claude-agent-sdk 0.1.68 "
    "(ClaudeSDKClient + ClaudeAgentOptions + dict-access usage). The "
    "disable_prompt_cache=True API is removed; claude_code now ALWAYS injects "
    "a per-seed salt and reports cache_strategy='salted'. The cost path "
    "switches from cost_source='native' to 'computed' (Anthropic Agent SDK "
    "stopped emitting native cost). New behavioral coverage lives in "
    "tests/drivers/test_claude_code_real.py (27 tests covering AC-9, AC-14, "
    "AC-15) and tests/drivers/test_claude_code_session_isolation.py (3 tests "
    "covering AC-17 fresh-client-per-task). This module is preserved as a "
    "record of the removed Phase 5a contract.",
    allow_module_level=True,
)

from collections.abc import Mapping
from dataclasses import asdict
from pathlib import Path
from unittest.mock import MagicMock, patch, PropertyMock

from drivers.claude_code import ClaudeCodeDriver
from drivers._protocol import DriverResult


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

def _make_sdk_usage(
    input_tokens: int = 150,
    output_tokens: int = 75,
    cache_read_input_tokens: int = 0,
) -> MagicMock:
    """Return a mock SDK Usage object with token counts."""
    usage = MagicMock()
    usage.input_tokens = input_tokens
    usage.output_tokens = output_tokens
    usage.cache_read_input_tokens = cache_read_input_tokens
    return usage


def _make_sdk_result(
    total_cost_usd: float = 0.0042,
    usage: MagicMock | None = None,
) -> MagicMock:
    """Return a mock AgentSDK result object."""
    result = MagicMock()
    result.total_cost_usd = total_cost_usd
    result.usage = usage or _make_sdk_usage()
    result.is_error = False
    return result


# ---------------------------------------------------------------------------
# T-37: Native cost path — cost_source="native", typed fields
# ---------------------------------------------------------------------------

class TestClaudeCodeDriverNativeCost:
    """ClaudeCodeDriver.execute — T-37: Agent SDK native cost path."""

    def test_cost_source_is_native(self, tmp_path: Path) -> None:
        """
        Given a mocked Agent SDK that returns total_cost_usd natively,
        When ClaudeCodeDriver.execute completes,
        Then DriverResult.cost_source == 'native'.
        """
        # Arrange
        driver = ClaudeCodeDriver()
        sdk_result = _make_sdk_result()

        # Act
        with patch("drivers.claude_code.run_agent_sdk", return_value=sdk_result):
            result: DriverResult = driver.execute(
                workspace=tmp_path,
                task_manifest={"task_id": "url_shortener", "entry_point": "./README.md"},
                seed=1,
                budget_usd=10.0,
                wall_clock_budget_seconds=1800,
                disable_prompt_cache=True,
            )

        # Assert
        assert result.cost_source == "native"

    def test_input_tokens_is_integer(self, tmp_path: Path) -> None:
        """
        Given a mocked SDK that returns numeric usage.input_tokens,
        When execute completes,
        Then DriverResult.input_tokens is an integer.
        """
        # Arrange
        driver = ClaudeCodeDriver()
        sdk_result = _make_sdk_result(usage=_make_sdk_usage(input_tokens=200))

        # Act
        with patch("drivers.claude_code.run_agent_sdk", return_value=sdk_result):
            result = driver.execute(
                workspace=tmp_path,
                task_manifest={"task_id": "url_shortener", "entry_point": "./README.md"},
                seed=1,
                budget_usd=10.0,
                wall_clock_budget_seconds=1800,
                disable_prompt_cache=True,
            )

        # Assert
        assert isinstance(result.input_tokens, int)
        assert result.input_tokens == 200

    def test_output_tokens_is_integer(self, tmp_path: Path) -> None:
        """
        Given a mocked SDK that returns numeric usage.output_tokens,
        When execute completes,
        Then DriverResult.output_tokens is an integer.
        """
        # Arrange
        driver = ClaudeCodeDriver()
        sdk_result = _make_sdk_result(usage=_make_sdk_usage(output_tokens=88))

        # Act
        with patch("drivers.claude_code.run_agent_sdk", return_value=sdk_result):
            result = driver.execute(
                workspace=tmp_path,
                task_manifest={"task_id": "url_shortener", "entry_point": "./README.md"},
                seed=1,
                budget_usd=10.0,
                wall_clock_budget_seconds=1800,
                disable_prompt_cache=True,
            )

        # Assert
        assert isinstance(result.output_tokens, int)
        assert result.output_tokens == 88

    def test_cost_usd_is_float(self, tmp_path: Path) -> None:
        """
        Given a mocked SDK that returns total_cost_usd,
        When execute completes,
        Then DriverResult.cost_usd is a float.
        """
        # Arrange
        driver = ClaudeCodeDriver()
        sdk_result = _make_sdk_result(total_cost_usd=0.0099)

        # Act
        with patch("drivers.claude_code.run_agent_sdk", return_value=sdk_result):
            result = driver.execute(
                workspace=tmp_path,
                task_manifest={"task_id": "url_shortener", "entry_point": "./README.md"},
                seed=1,
                budget_usd=10.0,
                wall_clock_budget_seconds=1800,
                disable_prompt_cache=True,
            )

        # Assert
        assert isinstance(result.cost_usd, float)
        assert abs(result.cost_usd - 0.0099) < 1e-9


# ---------------------------------------------------------------------------
# Nullable SDK fields — SDK may return None for token counts
# ---------------------------------------------------------------------------

class TestClaudeCodeDriverNullableFields:
    """ClaudeCodeDriver.execute — nullable token tolerance (AC-7 R1)."""

    def test_none_input_tokens_tolerated(self, tmp_path: Path) -> None:
        """
        Given a mocked SDK that returns None for usage.input_tokens,
        When execute completes,
        Then DriverResult.input_tokens is None (not a ValueError or AttributeError).
        """
        # Arrange
        driver = ClaudeCodeDriver()
        sdk_result = _make_sdk_result(usage=_make_sdk_usage(input_tokens=None))

        # Act
        with patch("drivers.claude_code.run_agent_sdk", return_value=sdk_result):
            result = driver.execute(
                workspace=tmp_path,
                task_manifest={"task_id": "url_shortener", "entry_point": "./README.md"},
                seed=1,
                budget_usd=10.0,
                wall_clock_budget_seconds=1800,
                disable_prompt_cache=True,
            )

        # Assert — must not raise; result holds None
        assert result.input_tokens is None

    def test_none_output_tokens_tolerated(self, tmp_path: Path) -> None:
        """
        Given a mocked SDK that returns None for usage.output_tokens,
        When execute completes,
        Then DriverResult.output_tokens is None.
        """
        # Arrange
        driver = ClaudeCodeDriver()
        sdk_result = _make_sdk_result(usage=_make_sdk_usage(output_tokens=None))

        # Act
        with patch("drivers.claude_code.run_agent_sdk", return_value=sdk_result):
            result = driver.execute(
                workspace=tmp_path,
                task_manifest={"task_id": "url_shortener", "entry_point": "./README.md"},
                seed=1,
                budget_usd=10.0,
                wall_clock_budget_seconds=1800,
                disable_prompt_cache=True,
            )

        # Assert
        assert result.output_tokens is None


# ---------------------------------------------------------------------------
# AC-14: cache_strategy recorded in DriverResult
# ---------------------------------------------------------------------------

class TestClaudeCodeDriverCacheStrategy:
    """ClaudeCodeDriver.execute — cache_strategy field for AC-14."""

    def test_cache_strategy_omitted_when_cache_disabled(self, tmp_path: Path) -> None:
        """
        Given disable_prompt_cache=True,
        When execute completes,
        Then DriverResult.cache_strategy == 'omitted'.
        """
        # Arrange
        driver = ClaudeCodeDriver()
        sdk_result = _make_sdk_result()

        # Act
        with patch("drivers.claude_code.run_agent_sdk", return_value=sdk_result):
            result = driver.execute(
                workspace=tmp_path,
                task_manifest={"task_id": "url_shortener", "entry_point": "./README.md"},
                seed=1,
                budget_usd=10.0,
                wall_clock_budget_seconds=1800,
                disable_prompt_cache=True,
            )

        # Assert
        assert result.cache_strategy in ("omitted", "salted"), (
            f"cache_strategy must be 'omitted' or 'salted', got {result.cache_strategy!r}"
        )

    def test_driver_metadata_is_nested_not_top_level(self, tmp_path: Path) -> None:
        """
        Given any execute call,
        When the DriverResult is produced,
        Then driver_metadata is a nested dict and not flattened into top-level fields.
        """
        # Arrange
        driver = ClaudeCodeDriver()
        sdk_result = _make_sdk_result()

        # Act
        with patch("drivers.claude_code.run_agent_sdk", return_value=sdk_result):
            result = driver.execute(
                workspace=tmp_path,
                task_manifest={"task_id": "url_shortener", "entry_point": "./README.md"},
                seed=1,
                budget_usd=10.0,
                wall_clock_budget_seconds=1800,
                disable_prompt_cache=True,
            )

        # Assert
        assert isinstance(result.driver_metadata, Mapping)
        # The cache_strategy MUST appear in driver_metadata per the interface contract
        assert "cache_strategy" in result.driver_metadata


# ---------------------------------------------------------------------------
# R6-claude: cli_version populated from importlib.metadata for claude-agent-sdk
# ---------------------------------------------------------------------------

class TestClaudeCodeDriverCliVersion:
    """
    R6-claude: ClaudeCodeDriver.execute() must populate driver_metadata["cli_version"]
    from importlib.metadata.version("claude-agent-sdk").

    The sdk_version() method must also return this live-resolved version, not a
    hardcoded string. Both driver_metadata["cli_version"] and sdk_version() must
    reflect the importlib.metadata lookup.
    """

    def test_cli_version_populated_from_importlib_metadata_claude_agent_sdk(
        self, tmp_path: Path
    ) -> None:
        """
        Given importlib.metadata.version("claude-agent-sdk") returns "0.2.0",
        When ClaudeCodeDriver().execute(...) completes,
        Then result.driver_metadata["cli_version"] == "0.2.0"
        AND ClaudeCodeDriver().sdk_version() == "0.2.0".

        R6-claude: cli_version must come from the live importlib.metadata lookup,
        not a hardcoded constant like "0.1.15". This ensures the recorded
        benchmark metadata always reflects the actually-installed SDK version.
        """
        # Arrange
        driver = ClaudeCodeDriver()
        sdk_result = _make_sdk_result()

        # Act
        with patch("drivers.claude_code.run_agent_sdk", return_value=sdk_result), \
             patch("importlib.metadata.version", return_value="0.2.0") as mock_version:
            result = driver.execute(
                workspace=tmp_path,
                task_manifest={"task_id": "url_shortener", "entry_point": "./README.md"},
                seed=1,
                budget_usd=10.0,
                wall_clock_budget_seconds=1800,
                disable_prompt_cache=True,
            )
            # Also verify sdk_version() uses the same live lookup (not a hardcoded stub)
            sdk_ver = ClaudeCodeDriver().sdk_version()

        # Assert — cli_version in result metadata
        assert isinstance(result.driver_metadata, Mapping), (
            "driver_metadata must be a Mapping"
        )
        assert "cli_version" in result.driver_metadata, (
            f"driver_metadata must contain 'cli_version'; got keys: "
            f"{list(result.driver_metadata.keys())}"
        )
        assert result.driver_metadata["cli_version"] == "0.2.0", (
            f"cli_version must equal '0.2.0' (from importlib.metadata); "
            f"got {result.driver_metadata['cli_version']!r}"
        )

        # Assert — sdk_version() reflects the live lookup
        assert sdk_ver == "0.2.0", (
            f"sdk_version() must return '0.2.0' from importlib.metadata, "
            f"got {sdk_ver!r} — likely still using the hardcoded '0.1.15' stub"
        )
