"""
Tests for drivers/aider.py — T-38, R5, R6 (Phase 2 Part 1 / 5c RED).

Covers:
  T-38: Aider adapter implements the Driver Protocol:
    - driver.name == "aider"
    - subprocess invoked with --yes-always flag
    - DriverResult.cost_source == "scraped"
    - DriverResult.input_tokens is None (Aider does not emit natively)
    - DriverResult.output_tokens is None
    - DriverResult.cost_usd parsed from stdout via extract_aider_cost
    - DriverResult.cache_strategy == "omitted" when disable_prompt_cache=True
    - driver.version() returns a non-empty string
    - driver.sdk_version() returns a non-empty string
    - driver.sdk_version() == driver.version() (no separate SDK for Aider)
    - driver.release_date() returns an ISO 8601 string

  R5: AiderDriver.__init__ (or first call to execute()) must call
    importlib.metadata.version("aider-chat"). If PackageNotFoundError is raised,
    driver raises RuntimeError with a message distinguishing 'aider-chat' from 'aider'
    and including 'pip install aider-chat'.

  R6: Every successful execute() call populates
    result.driver_metadata["cli_version"] with the installed aider-chat version string
    as returned by importlib.metadata.version("aider-chat").

Interface Contract (from drivers/_protocol.py):
  class Driver(Protocol):
    name: str
    def version(self) -> str: ...
    def sdk_version(self) -> str: ...
    def release_date(self) -> str: ...
    def prepare(workspace, task_manifest) -> None: ...
    def execute(workspace, task_manifest, seed, budget_usd,
                wall_clock_budget_seconds, disable_prompt_cache) -> DriverResult: ...

Mocking strategy:
  - subprocess.run is patched to return a configurable CompletedProcess
  - importlib.metadata.version is patched for R5 + R6 tests
  - stdout includes a parseable cost line to exercise the full scrape path
"""

import pytest

pytest.skip(
    "Phase 5e: cache_strategy contract for aider narrowed from "
    "{'omitted','salted'} to {'salted','native'}; aider reports 'native' "
    "(no cache layer to bypass). The disable_prompt_cache=True API is "
    "removed from Driver.execute(). AC-19 stdout error-text scan adds "
    "abort_reason.category='api_error_text' coverage. New behavioral "
    "coverage lives in tests/drivers/test_aider_error_scan.py (AC-19). "
    "Phase 5g will add real aider CLI integration coverage. This module "
    "is preserved as a record of the removed Phase 5c contract.",
    allow_module_level=True,
)

import importlib.metadata
import subprocess
from collections.abc import Mapping
from pathlib import Path
from unittest.mock import MagicMock, patch

from drivers.aider import AiderDriver
from drivers._protocol import DriverResult, VALID_COST_SOURCES, VALID_CACHE_STRATEGIES


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_completed_process(
    returncode: int = 0,
    stdout: str = (
        "Aider v0.64.0\n"
        "Model: claude-3-5-sonnet-20241022\n"
        "Applied 2 edits to app.py\n"
        "Cost: $0.0097 message, $0.0023 session\n"
    ),
    stderr: str = "",
) -> MagicMock:
    """Return a mock subprocess.CompletedProcess for Aider execution."""
    proc = MagicMock(spec=subprocess.CompletedProcess)
    proc.returncode = returncode
    proc.stdout = stdout
    proc.stderr = stderr
    return proc


_TASK_MANIFEST: dict = {
    "task_id": "url_shortener",
    "entry_point": "./seed/README.md",
    "workspace": {"seed_repo": "./seed/"},
}


# ---------------------------------------------------------------------------
# Driver Protocol compliance: name, version, sdk_version, release_date
# ---------------------------------------------------------------------------

class TestAiderDriverIdentity:
    """AiderDriver implements the Driver Protocol identity methods."""

    def test_name_is_aider(self) -> None:
        """
        Given an AiderDriver instance,
        When driver.name is accessed,
        Then it equals 'aider'.
        """
        driver = AiderDriver()
        assert driver.name == "aider"

    def test_version_returns_nonempty_string(self) -> None:
        """
        Given an AiderDriver instance,
        When driver.version() is called,
        Then a non-empty string is returned.
        """
        driver = AiderDriver()
        v = driver.version()
        assert isinstance(v, str) and len(v) > 0, (
            f"version() must return a non-empty string, got {v!r}"
        )

    def test_sdk_version_returns_nonempty_string(self) -> None:
        """
        Given an AiderDriver instance,
        When driver.sdk_version() is called,
        Then a non-empty string is returned.

        Note: Aider has no separate SDK; sdk_version() == version().
        """
        driver = AiderDriver()
        sv = driver.sdk_version()
        assert isinstance(sv, str) and len(sv) > 0, (
            f"sdk_version() must return a non-empty string, got {sv!r}"
        )

    def test_sdk_version_equals_version(self) -> None:
        """
        Given an AiderDriver instance,
        When both driver.version() and driver.sdk_version() are called,
        Then they return the same value (no separate SDK for Aider).
        """
        driver = AiderDriver()
        assert driver.version() == driver.sdk_version(), (
            "Aider has no separate SDK; sdk_version() must equal version()"
        )

    def test_release_date_returns_iso8601_string(self) -> None:
        """
        Given an AiderDriver instance,
        When driver.release_date() is called,
        Then it returns a non-empty string in ISO 8601 format (YYYY-MM-DD).
        """
        driver = AiderDriver()
        rd = driver.release_date()
        assert isinstance(rd, str) and len(rd) >= 10, (
            f"release_date() must return an ISO 8601 string, got {rd!r}"
        )
        # Minimal structural check: YYYY-MM-DD prefix
        parts = rd[:10].split("-")
        assert len(parts) == 3, f"Expected YYYY-MM-DD, got {rd!r}"
        assert all(p.isdigit() for p in parts), f"Non-numeric date parts in {rd!r}"


# ---------------------------------------------------------------------------
# T-38: execute() — happy path with mocked subprocess
# ---------------------------------------------------------------------------

class TestAiderDriverExecute:
    """T-38: AiderDriver.execute — happy path mocked subprocess path."""

    def test_cost_source_is_scraped(self, tmp_path: Path) -> None:
        """
        Given a mocked subprocess returning Aider v0.64 stdout with a cost line,
        When AiderDriver.execute completes,
        Then DriverResult.cost_source == 'scraped'.

        AC-7: Aider uses stdout regex scraping, not native SDK fields.
        """
        driver = AiderDriver()
        proc = _make_completed_process()

        with patch("subprocess.run", return_value=proc):
            result: DriverResult = driver.execute(
                workspace=tmp_path,
                task_manifest=_TASK_MANIFEST,
                seed=1,
                budget_usd=10.0,
                wall_clock_budget_seconds=1800,
                disable_prompt_cache=True,
            )

        assert result.cost_source == "scraped", (
            f"Aider driver must use cost_source='scraped', got {result.cost_source!r}"
        )

    def test_input_tokens_is_none(self, tmp_path: Path) -> None:
        """
        Given a mocked subprocess returning standard Aider stdout,
        When execute completes,
        Then DriverResult.input_tokens is None.

        Aider does NOT emit token counts in non-interactive stdout mode.
        """
        driver = AiderDriver()
        proc = _make_completed_process()

        with patch("subprocess.run", return_value=proc):
            result = driver.execute(
                workspace=tmp_path,
                task_manifest=_TASK_MANIFEST,
                seed=1,
                budget_usd=10.0,
                wall_clock_budget_seconds=1800,
                disable_prompt_cache=True,
            )

        assert result.input_tokens is None, (
            "Aider does not emit input_tokens; must be None in DriverResult"
        )

    def test_output_tokens_is_none(self, tmp_path: Path) -> None:
        """
        Given a mocked subprocess returning standard Aider stdout,
        When execute completes,
        Then DriverResult.output_tokens is None.
        """
        driver = AiderDriver()
        proc = _make_completed_process()

        with patch("subprocess.run", return_value=proc):
            result = driver.execute(
                workspace=tmp_path,
                task_manifest=_TASK_MANIFEST,
                seed=1,
                budget_usd=10.0,
                wall_clock_budget_seconds=1800,
                disable_prompt_cache=True,
            )

        assert result.output_tokens is None, (
            "Aider does not emit output_tokens; must be None in DriverResult"
        )

    def test_cost_usd_parsed_from_stdout(self, tmp_path: Path) -> None:
        """
        Given Aider stdout 'Cost: $0.0097 message, $0.0023 session',
        When execute completes,
        Then DriverResult.cost_usd == 0.0023 (session total).
        """
        driver = AiderDriver()
        proc = _make_completed_process(
            stdout="Cost: $0.0097 message, $0.0023 session\n"
        )

        with patch("subprocess.run", return_value=proc):
            result = driver.execute(
                workspace=tmp_path,
                task_manifest=_TASK_MANIFEST,
                seed=1,
                budget_usd=10.0,
                wall_clock_budget_seconds=1800,
                disable_prompt_cache=True,
            )

        assert result.cost_usd is not None, (
            "cost_usd must be parsed from stdout when 'Cost: ... session' line present"
        )
        assert abs(result.cost_usd - 0.0023) < 1e-6, (
            f"Expected session cost 0.0023, got {result.cost_usd}"
        )

    def test_cost_usd_none_when_no_cost_line(self, tmp_path: Path) -> None:
        """
        Given Aider stdout with no 'Cost:' line,
        When execute completes,
        Then DriverResult.cost_usd is None (graceful fallback).
        """
        driver = AiderDriver()
        proc = _make_completed_process(
            stdout="Aider v0.64.0\nNo edits applied.\n"
        )

        with patch("subprocess.run", return_value=proc):
            result = driver.execute(
                workspace=tmp_path,
                task_manifest=_TASK_MANIFEST,
                seed=1,
                budget_usd=10.0,
                wall_clock_budget_seconds=1800,
                disable_prompt_cache=True,
            )

        assert result.cost_usd is None, (
            "No cost line in stdout: cost_usd must be None, not raise"
        )

    def test_subprocess_invoked_with_yes_always(self, tmp_path: Path) -> None:
        """
        Given AiderDriver.execute is called,
        When subprocess.run is inspected,
        Then the command includes '--yes-always' (non-interactive mode flag).

        AC-7: Aider must be run non-interactively for benchmark use.
        """
        driver = AiderDriver()
        proc = _make_completed_process()

        with patch("subprocess.run", return_value=proc) as mock_run:
            driver.execute(
                workspace=tmp_path,
                task_manifest=_TASK_MANIFEST,
                seed=1,
                budget_usd=10.0,
                wall_clock_budget_seconds=1800,
                disable_prompt_cache=True,
            )

        assert mock_run.called, "subprocess.run was not called"
        call_args = mock_run.call_args
        # The first positional arg is the command (list or string)
        cmd = call_args[0][0] if call_args[0] else call_args[1].get("args", [])
        cmd_str = " ".join(cmd) if isinstance(cmd, list) else str(cmd)
        assert "--yes-always" in cmd_str, (
            f"Aider must be invoked with --yes-always; got command: {cmd_str!r}"
        )

    def test_result_is_driver_result_instance(self, tmp_path: Path) -> None:
        """
        Given a mocked subprocess,
        When execute completes,
        Then the return value is a DriverResult instance.
        """
        driver = AiderDriver()
        proc = _make_completed_process()

        with patch("subprocess.run", return_value=proc):
            result = driver.execute(
                workspace=tmp_path,
                task_manifest=_TASK_MANIFEST,
                seed=1,
                budget_usd=10.0,
                wall_clock_budget_seconds=1800,
                disable_prompt_cache=True,
            )

        assert isinstance(result, DriverResult), (
            f"execute() must return DriverResult, got {type(result)}"
        )

    def test_wall_clock_ms_is_positive_int(self, tmp_path: Path) -> None:
        """
        Given a mocked subprocess that returns quickly,
        When execute completes,
        Then DriverResult.wall_clock_ms is a positive integer.
        """
        driver = AiderDriver()
        proc = _make_completed_process()

        with patch("subprocess.run", return_value=proc):
            result = driver.execute(
                workspace=tmp_path,
                task_manifest=_TASK_MANIFEST,
                seed=1,
                budget_usd=10.0,
                wall_clock_budget_seconds=1800,
                disable_prompt_cache=True,
            )

        assert isinstance(result.wall_clock_ms, int), (
            f"wall_clock_ms must be int, got {type(result.wall_clock_ms)}"
        )
        assert result.wall_clock_ms >= 0, (
            f"wall_clock_ms must be non-negative, got {result.wall_clock_ms}"
        )

    def test_driver_metadata_is_dict(self, tmp_path: Path) -> None:
        """
        Given a mocked subprocess,
        When execute completes,
        Then DriverResult.driver_metadata is a dict (not top-level fields).
        """
        driver = AiderDriver()
        proc = _make_completed_process()

        with patch("subprocess.run", return_value=proc):
            result = driver.execute(
                workspace=tmp_path,
                task_manifest=_TASK_MANIFEST,
                seed=1,
                budget_usd=10.0,
                wall_clock_budget_seconds=1800,
                disable_prompt_cache=True,
            )

        assert isinstance(result.driver_metadata, Mapping), (
            "driver_metadata must be a Mapping per AC-7 schema "
            "(MappingProxyType per drivers/_protocol.py:63-64)"
        )


# ---------------------------------------------------------------------------
# AC-14: cache_strategy == "omitted" when disable_prompt_cache=True
# ---------------------------------------------------------------------------

class TestAiderDriverCacheStrategy:
    """
    AC-14: Aider driver records cache_strategy in DriverResult when
    disable_prompt_cache=True.
    """

    def test_cache_strategy_omitted_when_cache_disabled(self, tmp_path: Path) -> None:
        """
        Given disable_prompt_cache=True,
        When AiderDriver.execute completes,
        Then DriverResult.cache_strategy == 'omitted'.

        AC-14: Aider does not use the Anthropic prompt cache API natively;
        cache_strategy is always 'omitted' since no cache_control is sent.
        """
        driver = AiderDriver()
        proc = _make_completed_process()

        with patch("subprocess.run", return_value=proc):
            result = driver.execute(
                workspace=tmp_path,
                task_manifest=_TASK_MANIFEST,
                seed=1,
                budget_usd=10.0,
                wall_clock_budget_seconds=1800,
                disable_prompt_cache=True,
            )

        assert result.cache_strategy == "omitted", (
            f"Aider driver must record cache_strategy='omitted', got {result.cache_strategy!r}"
        )

    def test_cache_strategy_in_valid_set(self, tmp_path: Path) -> None:
        """
        Given any execute call,
        When execute completes,
        Then DriverResult.cache_strategy is one of the valid values.
        """
        driver = AiderDriver()
        proc = _make_completed_process()

        with patch("subprocess.run", return_value=proc):
            result = driver.execute(
                workspace=tmp_path,
                task_manifest=_TASK_MANIFEST,
                seed=1,
                budget_usd=10.0,
                wall_clock_budget_seconds=1800,
                disable_prompt_cache=True,
            )

        assert result.cache_strategy in VALID_CACHE_STRATEGIES, (
            f"cache_strategy must be in {VALID_CACHE_STRATEGIES}, "
            f"got {result.cache_strategy!r}"
        )


# ---------------------------------------------------------------------------
# C1: subprocess error handling — TimeoutExpired and FileNotFoundError
# ---------------------------------------------------------------------------

class TestAiderDriverSubprocessErrors:
    """
    C1: AiderDriver.execute must not propagate subprocess exceptions.
    TimeoutExpired -> DriverResult(aborted=True, abort_reason="wall_clock_exceeded").
    FileNotFoundError -> DriverResult(aborted=True, abort_reason="driver_error").
    """

    def test_timeout_expired_returns_wall_clock_exceeded(self, tmp_path: Path) -> None:
        """
        Given subprocess.run raises subprocess.TimeoutExpired,
        When AiderDriver.execute is called,
        Then it returns DriverResult(aborted=True, abort_reason="wall_clock_exceeded")
        with a non-negative wall_clock_ms — and does NOT propagate the exception.

        AC-12 / C1: wall-clock budget exceeded must be caught and converted to a
        DriverResult; an uncaught TimeoutExpired breaks the type contract.
        """
        driver = AiderDriver()

        with patch(
            "subprocess.run",
            side_effect=subprocess.TimeoutExpired(cmd=["aider"], timeout=1800),
        ):
            result: DriverResult = driver.execute(
                workspace=tmp_path,
                task_manifest=_TASK_MANIFEST,
                seed=1,
                budget_usd=10.0,
                wall_clock_budget_seconds=1800,
                disable_prompt_cache=True,
            )

        assert result.aborted is True, "aborted must be True on TimeoutExpired"
        assert result.abort_reason == "wall_clock_exceeded", (
            f"abort_reason must be 'wall_clock_exceeded', got {result.abort_reason!r}"
        )
        assert isinstance(result.wall_clock_ms, int) and result.wall_clock_ms >= 0, (
            f"wall_clock_ms must be a non-negative int, got {result.wall_clock_ms!r}"
        )

    def test_file_not_found_returns_driver_error(self, tmp_path: Path) -> None:
        """
        Given subprocess.run raises FileNotFoundError (CLI not installed),
        When AiderDriver.execute is called,
        Then it returns DriverResult(aborted=True, abort_reason="driver_error")
        and does NOT propagate the exception.

        C1: A missing CLI binary must not crash the harness; it must produce
        an aborted DriverResult so the run can be recorded and skipped.
        """
        driver = AiderDriver()

        with patch(
            "subprocess.run",
            side_effect=FileNotFoundError("aider: command not found"),
        ):
            result: DriverResult = driver.execute(
                workspace=tmp_path,
                task_manifest=_TASK_MANIFEST,
                seed=1,
                budget_usd=10.0,
                wall_clock_budget_seconds=1800,
                disable_prompt_cache=True,
            )

        assert result.aborted is True, "aborted must be True when CLI binary not found"
        assert result.abort_reason == "driver_error", (
            f"abort_reason must be 'driver_error', got {result.abort_reason!r}"
        )


# ---------------------------------------------------------------------------
# R5: AiderDriver init-time check for the 'aider-chat' PyPI package
# ---------------------------------------------------------------------------

class TestAiderDriverPackageGuard:
    """
    R5: AiderDriver must check importlib.metadata.version("aider-chat") at init
    or first execute(). If PackageNotFoundError is raised, the driver raises
    RuntimeError with a message that:
      1. contains "aider-chat" (the correct package name)
      2. contains "aider" (the wrong package users often install by mistake)
      3. contains "pip install aider-chat" (actionable fix)

    This prevents silent failures when users run 'pip install aider' (a different
    package on PyPI) instead of 'pip install aider-chat'.
    """

    def test_raises_helpful_error_when_aider_chat_not_installed(self, tmp_path: Path) -> None:
        """
        Given importlib.metadata.version("aider-chat") raises PackageNotFoundError,
        When AiderDriver is instantiated or execute() is first called,
        Then RuntimeError is raised with a message containing:
          - "aider-chat" (the correct package name)
          - "aider" (the wrong package to distinguish from)
          - "pip install aider-chat" (actionable fix instruction)

        R5: Distinguishing 'aider' from 'aider-chat' is critical — they are
        different PyPI packages with completely different behaviour.
        """
        # Arrange — patch importlib.metadata.version to raise PackageNotFoundError
        # for the "aider-chat" lookup specifically
        with patch(
            "importlib.metadata.version",
            side_effect=importlib.metadata.PackageNotFoundError("aider-chat"),
        ):
            # Act + Assert — either at __init__ or first execute()
            with pytest.raises(RuntimeError) as exc_info:
                driver = AiderDriver()
                # If __init__ doesn't raise, try execute() to trigger the guard
                driver.execute(
                    workspace=tmp_path,
                    task_manifest=_TASK_MANIFEST,
                    seed=1,
                    budget_usd=10.0,
                    wall_clock_budget_seconds=1800,
                    disable_prompt_cache=True,
                )

        error_msg = str(exc_info.value)
        assert "aider-chat" in error_msg, (
            f"RuntimeError must mention 'aider-chat' (correct package); got: {error_msg!r}"
        )
        assert "aider" in error_msg, (
            f"RuntimeError must mention 'aider' (wrong package to distinguish from); "
            f"got: {error_msg!r}"
        )
        assert "pip install aider-chat" in error_msg, (
            f"RuntimeError must contain 'pip install aider-chat' (actionable fix); "
            f"got: {error_msg!r}"
        )


# ---------------------------------------------------------------------------
# R6: cli_version in DriverResult.driver_metadata for AiderDriver
# ---------------------------------------------------------------------------

class TestAiderDriverCliVersion:
    """
    R6: Every successful AiderDriver.execute() call must populate
    result.driver_metadata["cli_version"] with the version string returned by
    importlib.metadata.version("aider-chat").

    This enables version pinning in every JSONL row (AC-6) and makes
    driver_metadata["cli_version"] the canonical source for Aider's installed version.
    """

    def test_cli_version_populated_from_importlib_metadata(self, tmp_path: Path) -> None:
        """
        Given importlib.metadata.version("aider-chat") returns "0.86.2",
        When AiderDriver.execute() completes successfully,
        Then result.driver_metadata["cli_version"] == "0.86.2".

        R6 / AC-6: cli_version must be populated from the installed package metadata,
        not hardcoded or guessed.
        """
        # Arrange
        expected_version = "0.86.2"

        with patch(
            "importlib.metadata.version",
            return_value=expected_version,
        ):
            driver = AiderDriver()
            proc = _make_completed_process()

            with patch("subprocess.run", return_value=proc):
                # Act
                result: DriverResult = driver.execute(
                    workspace=tmp_path,
                    task_manifest=_TASK_MANIFEST,
                    seed=1,
                    budget_usd=10.0,
                    wall_clock_budget_seconds=1800,
                    disable_prompt_cache=True,
                )

        # Assert
        assert "cli_version" in result.driver_metadata, (
            "driver_metadata must contain 'cli_version' key"
        )
        assert result.driver_metadata["cli_version"] == expected_version, (
            f"cli_version must be {expected_version!r} (from importlib.metadata), "
            f"got {result.driver_metadata.get('cli_version')!r}"
        )
