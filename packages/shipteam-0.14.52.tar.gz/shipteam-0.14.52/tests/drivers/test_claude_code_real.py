"""
tests/drivers/test_claude_code_real.py — Phase 5e RED tests.

Covers AC-9, AC-14, AC-15 for drivers/claude_code.py SDK wiring.

Mock boundary: `claude_agent_sdk.query` is the async transport. All tests
mock at the `drivers.claude_code.run_agent_sdk` boundary (the internal
adapter that wraps the SDK call) using sync MagicMock since run_agent_sdk
is the synchronous interface returned by execute().

SDK usage shape (from AC-9 Risk Watch / plan Interface Contract):
    ResultMessage.usage is dict[str, Any] | None — NOT an object.
    Access pattern must be .get(), NOT getattr().

Rate sheet (CLAUDE_RATE_SHEET_2026_04 from task_packs/loader.py Interface Contract):
    claude-sonnet-4-6: input $3.00/Mtok, output $15.00/Mtok, cache_read $0.30/Mtok

Salt format (AC-14):
    f"\n\n<run_salt>{uuid.uuid5(uuid.NAMESPACE_DNS, str(seed))}</run_salt>"
"""

from __future__ import annotations

import uuid
from collections.abc import Mapping
from pathlib import Path
from types import MappingProxyType
from typing import Any
from unittest.mock import MagicMock, patch

import pytest

from drivers.claude_code import ClaudeCodeDriver
from drivers._protocol import DriverResult, AbortReason


# ---------------------------------------------------------------------------
# Salt construction helper — must match the spec exactly (AC-14).
# The driver's implementation is required to produce the identical string.
# ---------------------------------------------------------------------------

def _make_salt(seed: int) -> str:
    """Construct the deterministic salt suffix per AC-14 spec."""
    return f"\n\n<run_salt>{uuid.uuid5(uuid.NAMESPACE_DNS, str(seed))}</run_salt>"


# ---------------------------------------------------------------------------
# SDK result fixture helpers.
# Usage is a dict per the plan's Risk Watch (ResultMessage.usage is dict|None).
# ---------------------------------------------------------------------------

def _make_usage_dict(
    input_tokens: int = 150,
    output_tokens: int = 75,
    cache_read_input_tokens: int = 0,
) -> dict[str, Any]:
    """Return a usage dict with the shape SDK returns (dict, not object)."""
    return {
        "input_tokens": input_tokens,
        "output_tokens": output_tokens,
        "cache_read_input_tokens": cache_read_input_tokens,
    }


def _make_sdk_result(
    total_cost_usd: float = 0.0042,
    usage: dict[str, Any] | None = None,
    is_error: bool = False,
    result_text: str = "Task completed.",
) -> MagicMock:
    """Return a mock ResultMessage with dict-typed usage (AC-9 spec)."""
    result = MagicMock()
    result.total_cost_usd = total_cost_usd
    result.usage = usage if usage is not None else _make_usage_dict()
    result.is_error = is_error
    result.result = result_text
    return result


_TASK_MANIFEST: dict = {
    "task_id": "url_shortener",
    "entry_point": "shortener.py",
    "test_command": "pytest",
    "language": "python",
}


# ---------------------------------------------------------------------------
# AC-14: Salt construction — determinism, cross-seed uniqueness, format
# ---------------------------------------------------------------------------

class TestAC14SaltConstruction:
    """
    AC-14: System prompt MUST contain a deterministic per-seed salt suffix.

    Same seed → same salt. Different seeds → different salts.
    Salt format: \\n\\n<run_salt>{uuid5(NAMESPACE_DNS, str(seed))}</run_salt>
    """

    def test_AC14_same_seed_produces_same_salt(self, tmp_path: Path) -> None:
        """
        Given seed=42 is used twice in separate execute() calls,
        When the driver constructs the system prompt for each call,
        Then both calls produce the identical salt suffix.

        AC-14: 'same seed → same salt (deterministic)'
        """
        # Arrange
        driver = ClaudeCodeDriver()
        sdk_result = _make_sdk_result()
        captured_system_prompts: list[str] = []

        def capture_system(**kwargs: Any) -> MagicMock:
            sys_prompt = kwargs.get("system_prompt") or kwargs.get("system") or ""
            captured_system_prompts.append(str(sys_prompt))
            return sdk_result

        # Act — two calls at identical seed=42
        with patch("drivers.claude_code.run_agent_sdk", side_effect=capture_system):
            driver.execute(
                workspace=tmp_path,
                task_manifest=_TASK_MANIFEST,
                seed=42,
                budget_usd=2.0,
                wall_clock_budget_seconds=180,
                cache_strategy="salted",
            )
        with patch("drivers.claude_code.run_agent_sdk", side_effect=capture_system):
            driver.execute(
                workspace=tmp_path,
                task_manifest=_TASK_MANIFEST,
                seed=42,
                budget_usd=2.0,
                wall_clock_budget_seconds=180,
                cache_strategy="salted",
            )

        # Assert — both system prompts contain the same salt
        assert len(captured_system_prompts) >= 2, "Expected at least two captured prompts"
        expected_salt = _make_salt(42)
        for i, prompt in enumerate(captured_system_prompts):
            assert expected_salt in prompt, (
                f"AC-14: system prompt {i} must contain salt for seed=42; "
                f"expected substring: {expected_salt!r}"
            )

    def test_AC14_different_seeds_produce_different_salts(self, tmp_path: Path) -> None:
        """
        Given seed=42 and seed=99 are used in separate execute() calls,
        When the driver constructs the system prompt for each,
        Then the two system prompts contain different salt suffixes.

        AC-14: 'different seeds → different salts'
        """
        # Arrange
        driver = ClaudeCodeDriver()
        sdk_result = _make_sdk_result()
        prompts_by_seed: dict[int, str] = {}

        def capture_factory(seed_key: int):
            def capture(**kwargs: Any) -> MagicMock:
                sys_prompt = kwargs.get("system_prompt") or kwargs.get("system") or ""
                prompts_by_seed[seed_key] = str(sys_prompt)
                return sdk_result
            return capture

        # Act
        with patch("drivers.claude_code.run_agent_sdk", side_effect=capture_factory(42)):
            driver.execute(
                workspace=tmp_path,
                task_manifest=_TASK_MANIFEST,
                seed=42,
                budget_usd=2.0,
                wall_clock_budget_seconds=180,
                cache_strategy="salted",
            )
        with patch("drivers.claude_code.run_agent_sdk", side_effect=capture_factory(99)):
            driver.execute(
                workspace=tmp_path,
                task_manifest=_TASK_MANIFEST,
                seed=99,
                budget_usd=2.0,
                wall_clock_budget_seconds=180,
                cache_strategy="salted",
            )

        # Assert — salt portions differ
        assert prompts_by_seed.get(42) != prompts_by_seed.get(99), (
            "AC-14: system prompts for seed=42 and seed=99 must differ "
            "(different seeds → different salts)"
        )

    def test_AC14_salt_is_uuid5_of_seed(self, tmp_path: Path) -> None:
        """
        Given seed=42,
        When the driver constructs the system prompt,
        Then the salt suffix is exactly f"\\n\\n<run_salt>{uuid5(NAMESPACE_DNS, '42')}</run_salt>".

        AC-14: salt format is deterministic uuid5(NAMESPACE_DNS, str(seed)).
        """
        # Arrange
        driver = ClaudeCodeDriver()
        sdk_result = _make_sdk_result()
        captured: list[str] = []

        def capture(**kwargs: Any) -> MagicMock:
            sys_prompt = kwargs.get("system_prompt") or kwargs.get("system") or ""
            captured.append(str(sys_prompt))
            return sdk_result

        # Act
        with patch("drivers.claude_code.run_agent_sdk", side_effect=capture):
            driver.execute(
                workspace=tmp_path,
                task_manifest=_TASK_MANIFEST,
                seed=42,
                budget_usd=2.0,
                wall_clock_budget_seconds=180,
                cache_strategy="salted",
            )

        # Assert
        expected_salt = _make_salt(42)
        assert captured, "Expected at least one captured system prompt"
        assert expected_salt in captured[0], (
            f"AC-14: system prompt must contain salt {expected_salt!r}; "
            f"got prompt ending: {captured[0][-200:]!r}"
        )

    def test_AC14_salt_length_bounded_at_80_chars(self) -> None:
        """
        Given the salt construction formula,
        When salt strings are computed for several seeds,
        Then each salt is ≤ 80 characters.

        AC-14 R19: empirical bound ≤ 40 tokens; a salt ≤ 80 chars tokenizes to ≤ 40
        tokens for any Claude 4.X family model (BPE with ~2 chars/token worst case).
        This is an offline heuristic — exact token count requires the count_tokens API
        (captured in probe2_count_tokens.py).
        """
        # Arrange + Act
        seeds = [1, 7, 42, 100, 999, 12345]
        for seed in seeds:
            salt = _make_salt(seed)
            # Assert
            assert len(salt) <= 80, (
                f"AC-14 R19: salt for seed={seed} is {len(salt)} chars, exceeds 80 char bound; "
                f"salt: {salt!r}"
            )


# ---------------------------------------------------------------------------
# AC-14: cache_strategy="salted" propagated to DriverResult
# ---------------------------------------------------------------------------

class TestAC14CacheStrategyPropagated:
    """AC-14: DriverResult.cache_strategy must equal 'salted' when called with cache_strategy='salted'."""

    def test_AC14_cache_strategy_salted_in_result(self, tmp_path: Path) -> None:
        """
        Given execute() is called with cache_strategy='salted',
        When the driver returns a DriverResult,
        Then result.cache_strategy == 'salted'.
        """
        # Arrange
        driver = ClaudeCodeDriver()
        sdk_result = _make_sdk_result(usage=_make_usage_dict(cache_read_input_tokens=0))

        # Act
        with patch("drivers.claude_code.run_agent_sdk", return_value=sdk_result):
            result: DriverResult = driver.execute(
                workspace=tmp_path,
                task_manifest=_TASK_MANIFEST,
                seed=42,
                budget_usd=2.0,
                wall_clock_budget_seconds=180,
                cache_strategy="salted",
            )

        # Assert
        assert result.cache_strategy == "salted", (
            f"AC-14: DriverResult.cache_strategy must be 'salted', got {result.cache_strategy!r}"
        )

    def test_AC14_omitted_is_not_accepted_by_protocol(self) -> None:
        """
        Given the new contract: cache_strategy ∈ {'salted', 'native'},
        When a DriverResult is constructed with cache_strategy='omitted',
        Then ValueError is raised.

        AC-14: 'cache_strategy="omitted" is REMOVED from the allowed set; replaced with
        cache_strategy ∈ {"salted", "native"}.'
        """
        # Act + Assert
        with pytest.raises(ValueError, match="cache_strategy"):
            DriverResult(
                wall_clock_ms=100,
                input_tokens=100,
                output_tokens=50,
                cost_usd=0.001,
                cost_source="computed",
                aborted=False,
                abort_reason=None,
                cache_strategy="omitted",  # type: ignore[arg-type]
            )

    def test_AC14_native_is_accepted_by_protocol(self) -> None:
        """
        Given the new contract: cache_strategy ∈ {'salted', 'native'},
        When a DriverResult is constructed with cache_strategy='native',
        Then no ValueError is raised.

        AC-14: 'native' is the reserved value for drivers that do not control caching.
        """
        # Act + Assert — must not raise
        result = DriverResult(
            wall_clock_ms=100,
            input_tokens=None,
            output_tokens=None,
            cost_usd=None,
            cost_source="scraped",
            aborted=False,
            abort_reason=None,
            cache_strategy="native",
        )
        assert result.cache_strategy == "native", (
            "AC-14: 'native' must be accepted as a valid cache_strategy"
        )


# ---------------------------------------------------------------------------
# AC-14: Fail-closed on cache_read_input_tokens > 0
# ---------------------------------------------------------------------------

class TestAC14FailClosed:
    """
    AC-14: If cache_read_input_tokens > 0 on a salted run, driver must set
    aborted=True with abort_reason.category == 'cache_leak_detected'.
    """

    def test_AC14_cache_read_zero_returns_not_aborted(self, tmp_path: Path) -> None:
        """
        Given mock SDK returns cache_read_input_tokens=0,
        When execute() completes with cache_strategy='salted',
        Then aborted=False (cold-start verified).

        AC-14: 'cache_read_input_tokens==0 (verifies cold-start)'.
        """
        # Arrange
        driver = ClaudeCodeDriver()
        sdk_result = _make_sdk_result(usage=_make_usage_dict(cache_read_input_tokens=0))

        # Act
        with patch("drivers.claude_code.run_agent_sdk", return_value=sdk_result):
            result: DriverResult = driver.execute(
                workspace=tmp_path,
                task_manifest=_TASK_MANIFEST,
                seed=42,
                budget_usd=2.0,
                wall_clock_budget_seconds=180,
                cache_strategy="salted",
            )

        # Assert
        assert result.aborted is False, (
            "AC-14: cache_read_input_tokens==0 on salted run must NOT abort; "
            f"got aborted={result.aborted!r}"
        )

    def test_AC14_cache_read_positive_triggers_abort(self, tmp_path: Path) -> None:
        """
        Given mock SDK returns cache_read_input_tokens=500 (cache hit on salted run),
        When execute() completes,
        Then aborted=True with abort_reason.category=='cache_leak_detected'.

        AC-14: 'if cache_read_input_tokens > 0 on a salted run, driver sets
        aborted=true, abort_reason="cache_leak_detected"'.
        """
        # Arrange
        driver = ClaudeCodeDriver()
        sdk_result = _make_sdk_result(usage=_make_usage_dict(cache_read_input_tokens=500))

        # Act
        with patch("drivers.claude_code.run_agent_sdk", return_value=sdk_result):
            result: DriverResult = driver.execute(
                workspace=tmp_path,
                task_manifest=_TASK_MANIFEST,
                seed=42,
                budget_usd=2.0,
                wall_clock_budget_seconds=180,
                cache_strategy="salted",
            )

        # Assert
        assert result.aborted is True, (
            "AC-14: cache_read_input_tokens>0 on salted run must set aborted=True; "
            f"expected fail-closed on cache_read>0"
        )
        assert result.abort_reason is not None, (
            "AC-14: abort_reason must be set when aborted=True"
        )
        assert result.abort_reason.category == "cache_leak_detected", (
            f"AC-14: abort_reason.category must be 'cache_leak_detected', "
            f"got {result.abort_reason.category!r}"
        )

    @pytest.mark.parametrize("cache_read", [1, 100, 9999])
    def test_AC14_any_positive_cache_read_triggers_abort(
        self, tmp_path: Path, cache_read: int
    ) -> None:
        """
        Given mock SDK returns various cache_read_input_tokens > 0,
        When execute() completes,
        Then aborted=True in all cases.

        Parametric oracle: any cache read > 0 is fail-closed.
        """
        # Arrange
        driver = ClaudeCodeDriver()
        sdk_result = _make_sdk_result(
            usage=_make_usage_dict(cache_read_input_tokens=cache_read)
        )

        # Act
        with patch("drivers.claude_code.run_agent_sdk", return_value=sdk_result):
            result: DriverResult = driver.execute(
                workspace=tmp_path,
                task_manifest=_TASK_MANIFEST,
                seed=42,
                budget_usd=2.0,
                wall_clock_budget_seconds=180,
                cache_strategy="salted",
            )

        # Assert
        assert result.aborted is True, (
            f"AC-14: cache_read_input_tokens={cache_read} must trigger abort; "
            "expected fail-closed on cache_read>0"
        )
        assert result.abort_reason is not None
        assert result.abort_reason.category == "cache_leak_detected", (
            f"abort_reason.category must be 'cache_leak_detected' for cache_read={cache_read}"
        )


# ---------------------------------------------------------------------------
# AC-14: Salt placement — salt offset must be AFTER all cache_control markers
# ---------------------------------------------------------------------------

class TestAC14SaltPlacement:
    """
    AC-14 R14: The salt suffix MUST be placed AFTER any cache_control markers
    in the system prompt. If any cache_control marker offset > salt offset,
    `_check_salt_placement` MUST raise RuntimeError('salt placement violates
    cache_control hierarchy').

    Two-layer coverage (post-review-fix):
      1. Direct unit test of _check_salt_placement with a synthetic violation
         input — proves the FUNCTION detects the violation. This is the real
         test of the salt-placement contract.
      2. Integration test that asserts execute() CALLS _check_salt_placement
         using a spy (no side_effect replacement) — proves the driver invokes
         the check during normal operation, so a future regression that
         removes the call site is caught.

    Replaces a prior tautological test that patched _check_salt_placement
    with side_effect=RuntimeError() and asserted pytest.raises caught the
    injected error — that test would have passed even if the driver never
    called _check_salt_placement at all.
    """

    def test_AC14_check_salt_placement_raises_when_cache_control_after_salt(
        self,
    ) -> None:
        """
        Direct unit test: _check_salt_placement(prompt, salt) must raise
        RuntimeError when any 'cache_control' substring appears at an offset
        STRICTLY GREATER than the salt's offset within the prompt.

        AC-14 R14: 'If any marker offset > salt offset → RuntimeError'.
        """
        from drivers.claude_code import _check_salt_placement

        salt = "<run_salt>SALT123</run_salt>"
        # Construct an adversarial prompt where salt is at offset 0 and a
        # cache_control marker is appended after — violates R14.
        adversarial_prompt = salt + "\n\nsome cache_control marker here"

        with pytest.raises(
            RuntimeError, match="salt placement violates cache_control hierarchy"
        ):
            _check_salt_placement(adversarial_prompt, salt)

    def test_AC14_check_salt_placement_does_not_raise_when_cache_control_before_salt(
        self,
    ) -> None:
        """
        Direct unit test: _check_salt_placement must NOT raise when all
        'cache_control' markers appear BEFORE the salt offset (the normal
        construction-site invariant: salt is appended last).
        """
        from drivers.claude_code import _check_salt_placement

        salt = "<run_salt>SALT123</run_salt>"
        # Normal construction: cache_control marker comes first, salt last.
        well_formed_prompt = "system prompt with cache_control marker\n\n" + salt

        # No exception expected.
        _check_salt_placement(well_formed_prompt, salt)

    def test_AC14_check_salt_placement_does_not_raise_when_no_cache_control(
        self,
    ) -> None:
        """
        Direct unit test: when the prompt contains no 'cache_control'
        substring at all, _check_salt_placement is a no-op.
        """
        from drivers.claude_code import _check_salt_placement

        salt = "<run_salt>SALT123</run_salt>"
        clean_prompt = "system prompt with no markers\n\n" + salt

        _check_salt_placement(clean_prompt, salt)

    def test_AC14_execute_invokes_check_salt_placement(
        self, tmp_path: Path
    ) -> None:
        """
        Integration test: execute() MUST call _check_salt_placement during a
        normal salted run. This is a SPY (wraps the real function) — no
        side_effect replacement — so the test catches a regression where the
        call site is removed without forcing a tautology.
        """
        driver = ClaudeCodeDriver()

        with patch(
            "drivers.claude_code._check_salt_placement",
            wraps=__import__("drivers.claude_code", fromlist=["_check_salt_placement"])._check_salt_placement,
        ) as spy_check:
            with patch(
                "drivers.claude_code.run_agent_sdk",
                return_value=_make_sdk_result(),
            ):
                driver.execute(
                    workspace=tmp_path,
                    task_manifest=_TASK_MANIFEST,
                    seed=42,
                    budget_usd=2.0,
                    wall_clock_budget_seconds=180,
                    cache_strategy="salted",
                )

        # The driver must have called _check_salt_placement at least once.
        assert spy_check.call_count >= 1, (
            "execute() did not invoke _check_salt_placement — AC-14 R14 "
            "guard is unreachable without it."
        )


# ---------------------------------------------------------------------------
# AC-9: Usage dict access pattern — .get() not getattr
# ---------------------------------------------------------------------------

class TestAC9UsageDictAccess:
    """
    AC-9: ResultMessage.usage is dict[str, Any] | None (SDK source confirmed).
    The driver MUST use .get() access, NOT getattr().

    If getattr is used and usage is a plain dict, every field returns None
    silently — data corruption (plan Risk Watch).
    """

    def test_AC9_usage_dict_access_not_getattr(self, tmp_path: Path) -> None:
        """
        Given usage is a plain dict (NOT a MagicMock with .input_tokens attribute),
        When execute() processes the SDK result,
        Then input_tokens and output_tokens are correctly extracted from the dict.

        If getattr were used, dict.input_tokens would raise AttributeError (or return
        the dict's attr if MagicMock). Providing a plain dict exposes the bug.
        """
        # Arrange — usage is a REAL dict, not a MagicMock. getattr would fail here.
        plain_usage: dict[str, Any] = {
            "input_tokens": 200,
            "output_tokens": 80,
            "cache_read_input_tokens": 0,
        }
        sdk_result = _make_sdk_result(usage=plain_usage)
        driver = ClaudeCodeDriver()

        # Act
        with patch("drivers.claude_code.run_agent_sdk", return_value=sdk_result):
            result: DriverResult = driver.execute(
                workspace=tmp_path,
                task_manifest=_TASK_MANIFEST,
                seed=42,
                budget_usd=2.0,
                wall_clock_budget_seconds=180,
                cache_strategy="salted",
            )

        # Assert — tokens correctly extracted from dict
        assert result.input_tokens == 200, (
            f"AC-9: input_tokens must be 200 from dict usage; "
            f"got {result.input_tokens!r}. "
            f"If getattr were used on a plain dict, this would silently return None."
        )
        assert result.output_tokens == 80, (
            f"AC-9: output_tokens must be 80 from dict usage; got {result.output_tokens!r}"
        )

    def test_AC9_usage_none_does_not_crash(self, tmp_path: Path) -> None:
        """
        Given usage is None (SDK may return None per type: dict | None),
        When execute() processes the SDK result,
        Then the driver handles it gracefully — either aborts or uses defaults.

        AC-9: 'usage = result.usage or {}' — None is handled via the or-default pattern.
        """
        # Arrange
        sdk_result = _make_sdk_result(usage=None)
        driver = ClaudeCodeDriver()

        # Act — must not raise AttributeError or KeyError
        with patch("drivers.claude_code.run_agent_sdk", return_value=sdk_result):
            result: DriverResult = driver.execute(
                workspace=tmp_path,
                task_manifest=_TASK_MANIFEST,
                seed=42,
                budget_usd=2.0,
                wall_clock_budget_seconds=180,
                cache_strategy="salted",
            )

        # Assert — result exists (aborted or not is impl detail; must not crash)
        assert isinstance(result, DriverResult), (
            "AC-9: execute() must return DriverResult even when usage is None"
        )


# ---------------------------------------------------------------------------
# AC-15: Token counts non-None on completed non-aborted runs
# ---------------------------------------------------------------------------

class TestAC15TokenCountsNonNone:
    """
    AC-15: On completed (aborted=False) runs for token-reporting drivers,
    input_tokens and output_tokens MUST be int >= 0, never None.
    """

    def test_AC15_non_aborted_result_has_integer_tokens(self, tmp_path: Path) -> None:
        """
        Given mock SDK returns valid integer usage,
        When execute() returns with aborted=False,
        Then input_tokens is int >= 0 and output_tokens is int >= 0.

        AC-15: 'input_tokens and output_tokens are both int and both >= 0 (NEVER None)'
        """
        # Arrange
        driver = ClaudeCodeDriver()
        sdk_result = _make_sdk_result(
            usage=_make_usage_dict(input_tokens=300, output_tokens=120, cache_read_input_tokens=0)
        )

        # Act
        with patch("drivers.claude_code.run_agent_sdk", return_value=sdk_result):
            result: DriverResult = driver.execute(
                workspace=tmp_path,
                task_manifest=_TASK_MANIFEST,
                seed=42,
                budget_usd=2.0,
                wall_clock_budget_seconds=180,
                cache_strategy="salted",
            )

        # Assert
        assert result.aborted is False, "precondition: result must not be aborted"
        assert isinstance(result.input_tokens, int), (
            f"AC-15: input_tokens must be int on completed run, got {type(result.input_tokens)}"
        )
        assert result.input_tokens >= 0, (
            f"AC-15: input_tokens must be >= 0, got {result.input_tokens}"
        )
        assert isinstance(result.output_tokens, int), (
            f"AC-15: output_tokens must be int on completed run, got {type(result.output_tokens)}"
        )
        assert result.output_tokens >= 0, (
            f"AC-15: output_tokens must be >= 0, got {result.output_tokens}"
        )

    def test_AC15_missing_input_tokens_triggers_abort(self, tmp_path: Path) -> None:
        """
        Given mock SDK returns usage dict with input_tokens absent (None after .get()),
        When execute() processes the result,
        Then aborted=True with abort_reason.category=='missing_token_counts'.

        AC-15: 'if SDK did not return token counts → set aborted=true with
        abort_reason="missing_token_counts" rather than record None.'
        """
        # Arrange — usage dict has no input_tokens key
        usage_no_input: dict[str, Any] = {
            "output_tokens": 80,
            "cache_read_input_tokens": 0,
            # input_tokens deliberately absent → .get("input_tokens") returns None
        }
        driver = ClaudeCodeDriver()
        sdk_result = _make_sdk_result(usage=usage_no_input)

        # Act
        with patch("drivers.claude_code.run_agent_sdk", return_value=sdk_result):
            result: DriverResult = driver.execute(
                workspace=tmp_path,
                task_manifest=_TASK_MANIFEST,
                seed=42,
                budget_usd=2.0,
                wall_clock_budget_seconds=180,
                cache_strategy="salted",
            )

        # Assert
        assert result.aborted is True, (
            "AC-15: missing input_tokens must set aborted=True with missing_token_counts"
        )
        assert result.abort_reason is not None
        assert result.abort_reason.category == "missing_token_counts", (
            f"AC-15: abort_reason.category must be 'missing_token_counts', "
            f"got {result.abort_reason.category!r}"
        )

    def test_AC15_missing_output_tokens_triggers_abort(self, tmp_path: Path) -> None:
        """
        Given mock SDK returns usage dict with output_tokens absent,
        When execute() processes the result,
        Then aborted=True with abort_reason.category=='missing_token_counts'.
        """
        # Arrange
        usage_no_output: dict[str, Any] = {
            "input_tokens": 150,
            "cache_read_input_tokens": 0,
            # output_tokens deliberately absent
        }
        driver = ClaudeCodeDriver()
        sdk_result = _make_sdk_result(usage=usage_no_output)

        # Act
        with patch("drivers.claude_code.run_agent_sdk", return_value=sdk_result):
            result: DriverResult = driver.execute(
                workspace=tmp_path,
                task_manifest=_TASK_MANIFEST,
                seed=42,
                budget_usd=2.0,
                wall_clock_budget_seconds=180,
                cache_strategy="salted",
            )

        # Assert
        assert result.aborted is True, (
            "AC-15: missing output_tokens must set aborted=True with missing_token_counts"
        )
        assert result.abort_reason is not None
        assert result.abort_reason.category == "missing_token_counts", (
            f"AC-15: abort_reason.category must be 'missing_token_counts', "
            f"got {result.abort_reason.category!r}"
        )


# ---------------------------------------------------------------------------
# AC-9: Cost computation from CLAUDE_RATE_SHEET_2026_04
# ---------------------------------------------------------------------------

class TestAC9CostComputation:
    """
    AC-9: cost_usd is DERIVED from token counts × rate sheet, not from
    total_cost_usd in the SDK result (SDK Issue #487 — local estimate, ≤3× off).

    Rate sheet (CLAUDE_RATE_SHEET_2026_04):
        claude-sonnet-4-6: input $3.00/Mtok, output $15.00/Mtok
    """

    def test_AC9_cost_source_is_computed(self, tmp_path: Path) -> None:
        """
        Given execute() with SDK-provided usage,
        When the driver derives cost_usd,
        Then DriverResult.cost_source == 'computed'.

        AC-9: 'cost_source="computed" since SDK estimate is non-authoritative per Issue #487'
        """
        # Arrange
        driver = ClaudeCodeDriver()
        sdk_result = _make_sdk_result(
            total_cost_usd=99.0,  # SDK estimate — should NOT be used
            usage=_make_usage_dict(input_tokens=1_000_000, output_tokens=100_000),
        )

        # Act
        with patch("drivers.claude_code.run_agent_sdk", return_value=sdk_result):
            result: DriverResult = driver.execute(
                workspace=tmp_path,
                task_manifest=_TASK_MANIFEST,
                seed=42,
                budget_usd=2.0,
                wall_clock_budget_seconds=180,
                cache_strategy="salted",
            )

        # Assert
        assert result.cost_source == "computed", (
            f"AC-9: cost_source must be 'computed' (not 'native'), "
            f"got {result.cost_source!r}"
        )

    def test_AC9_cost_derived_from_rate_sheet_not_sdk(self, tmp_path: Path) -> None:
        """
        Given 1M input tokens + 100K output tokens at sonnet-4-6 rates,
        When execute() derives cost_usd from CLAUDE_RATE_SHEET_2026_04,
        Then cost_usd ≈ 1M×$3/M + 100K×$15/M = $3.00 + $1.50 = $4.50 (not SDK's $99).

        Rate sheet: input $3.00/Mtok, output $15.00/Mtok.
        The SDK returned total_cost_usd=99.0 — that MUST NOT be used.
        """
        # Arrange
        driver = ClaudeCodeDriver()
        sdk_result = _make_sdk_result(
            total_cost_usd=99.0,  # must be ignored
            usage=_make_usage_dict(
                input_tokens=1_000_000,
                output_tokens=100_000,
                cache_read_input_tokens=0,
            ),
        )

        # Act
        with patch("drivers.claude_code.run_agent_sdk", return_value=sdk_result):
            result: DriverResult = driver.execute(
                workspace=tmp_path,
                task_manifest=_TASK_MANIFEST,
                seed=42,
                budget_usd=2.0,
                wall_clock_budget_seconds=180,
                cache_strategy="salted",
            )

        # Assert — cost must be derived from rate sheet
        expected_cost = 1_000_000 * (3.00 / 1_000_000) + 100_000 * (15.00 / 1_000_000)
        assert result.cost_usd is not None, "cost_usd must not be None on completed run"
        assert abs(result.cost_usd - expected_cost) < 0.001, (
            f"AC-9: cost_usd should be ~{expected_cost:.4f} (from rate sheet), "
            f"not 99.0 (from SDK estimate). Got: {result.cost_usd!r}"
        )


# ---------------------------------------------------------------------------
# AC-9: Error scan — is_error + text pattern detection
# ---------------------------------------------------------------------------

class TestAC9ErrorScan:
    """
    AC-9: Driver scans is_error AND result text for API error patterns.
    Pattern: /API request failed|rate_limit_error|server_error|overloaded_error/
    Any match → aborted=True, abort_reason.category='api_error_text'.

    Defends against SDK Issue #472: API errors returned as text, not exceptions.
    """

    @pytest.mark.parametrize("error_text,label", [
        ("API request failed: 500 Internal Server Error", "API_request_failed"),
        ("rate_limit_error: too many requests", "rate_limit_error"),
        ("server_error encountered during processing", "server_error"),
        ("overloaded_error: service temporarily unavailable", "overloaded_error"),
    ])
    def test_AC9_error_text_pattern_triggers_abort(
        self, tmp_path: Path, error_text: str, label: str
    ) -> None:
        """
        Given mock SDK returns result_text containing an error pattern,
        When execute() scans the result,
        Then aborted=True with abort_reason.category=='api_error_text'.

        AC-9: 'if is_error_flag or re.search(pattern, text_blob) → aborted=true'
        """
        # Arrange
        driver = ClaudeCodeDriver()
        sdk_result = _make_sdk_result(
            usage=_make_usage_dict(
                input_tokens=100,
                output_tokens=10,
                cache_read_input_tokens=0,
            ),
            is_error=False,
            result_text=error_text,
        )

        # Act
        with patch("drivers.claude_code.run_agent_sdk", return_value=sdk_result):
            result: DriverResult = driver.execute(
                workspace=tmp_path,
                task_manifest=_TASK_MANIFEST,
                seed=42,
                budget_usd=2.0,
                wall_clock_budget_seconds=180,
                cache_strategy="salted",
            )

        # Assert
        assert result.aborted is True, (
            f"AC-9 ({label}): error text '{error_text}' must trigger aborted=True"
        )
        assert result.abort_reason is not None, (
            f"AC-9 ({label}): abort_reason must be set"
        )
        assert result.abort_reason.category == "api_error_text", (
            f"AC-9 ({label}): abort_reason.category must be 'api_error_text', "
            f"got {result.abort_reason.category!r}"
        )

    def test_AC9_is_error_flag_triggers_abort(self, tmp_path: Path) -> None:
        """
        Given mock SDK sets is_error=True,
        When execute() processes the result,
        Then aborted=True.

        AC-9: 'is_error=True → aborted=true'
        """
        # Arrange
        driver = ClaudeCodeDriver()
        sdk_result = _make_sdk_result(
            usage=_make_usage_dict(
                input_tokens=100,
                output_tokens=10,
                cache_read_input_tokens=0,
            ),
            is_error=True,
            result_text="Task completed.",
        )

        # Act
        with patch("drivers.claude_code.run_agent_sdk", return_value=sdk_result):
            result: DriverResult = driver.execute(
                workspace=tmp_path,
                task_manifest=_TASK_MANIFEST,
                seed=42,
                budget_usd=2.0,
                wall_clock_budget_seconds=180,
                cache_strategy="salted",
            )

        # Assert
        assert result.aborted is True, (
            "AC-9: is_error=True must set aborted=True"
        )

    def test_AC9_clean_result_not_aborted(self, tmp_path: Path) -> None:
        """
        Given mock SDK returns clean result (is_error=False, no error text),
        When execute() processes the result,
        Then aborted=False.

        Companion test: the error scan must not false-positive on clean output.
        """
        # Arrange
        driver = ClaudeCodeDriver()
        sdk_result = _make_sdk_result(
            usage=_make_usage_dict(
                input_tokens=100,
                output_tokens=50,
                cache_read_input_tokens=0,
            ),
            is_error=False,
            result_text="Here is my implementation of the URL shortener...",
        )

        # Act
        with patch("drivers.claude_code.run_agent_sdk", return_value=sdk_result):
            result: DriverResult = driver.execute(
                workspace=tmp_path,
                task_manifest=_TASK_MANIFEST,
                seed=42,
                budget_usd=2.0,
                wall_clock_budget_seconds=180,
                cache_strategy="salted",
            )

        # Assert
        assert result.aborted is False, (
            f"AC-9: clean result (no error markers) must not be aborted; "
            f"got aborted={result.aborted!r}"
        )


# ---------------------------------------------------------------------------
# AC-9: Happy path — full DriverResult shape
# ---------------------------------------------------------------------------

class TestAC9HappyPath:
    """AC-9: execute() with cache_strategy='salted' returns a fully-populated DriverResult."""

    def test_AC9_happy_path_driver_result_shape(self, tmp_path: Path) -> None:
        """
        Given mock SDK returns a clean salted run result,
        When execute() completes,
        Then DriverResult has: cache_strategy='salted', cache_read_input_tokens=0,
        non-None token counts, cost_source='computed', aborted=False.

        AC-9: 'returns DriverResult with non-None input_tokens/output_tokens, cost_usd,
        cache_strategy="salted", cache_read_input_tokens=0, aborted=false'.
        """
        # Arrange
        driver = ClaudeCodeDriver()
        sdk_result = _make_sdk_result(
            usage=_make_usage_dict(
                input_tokens=500,
                output_tokens=200,
                cache_read_input_tokens=0,
            ),
            is_error=False,
            result_text="Here is my URL shortener implementation.",
        )

        # Act
        with patch("drivers.claude_code.run_agent_sdk", return_value=sdk_result):
            result: DriverResult = driver.execute(
                workspace=tmp_path,
                task_manifest=_TASK_MANIFEST,
                seed=42,
                budget_usd=2.0,
                wall_clock_budget_seconds=180,
                cache_strategy="salted",
            )

        # Assert — full shape
        assert result.aborted is False, f"expected aborted=False, got {result.aborted!r}"
        assert result.cache_strategy == "salted", (
            f"expected cache_strategy='salted', got {result.cache_strategy!r}"
        )
        assert result.cost_source == "computed", (
            f"expected cost_source='computed', got {result.cost_source!r}"
        )
        assert result.input_tokens is not None, "input_tokens must not be None"
        assert result.output_tokens is not None, "output_tokens must not be None"
        assert result.cost_usd is not None, "cost_usd must not be None"
        assert result.cost_usd > 0, f"cost_usd must be > 0, got {result.cost_usd!r}"
        assert isinstance(result.driver_metadata, Mapping), (
            "driver_metadata must be a Mapping"
        )
        # cache_read_input_tokens recorded in driver_metadata
        assert result.driver_metadata.get("cache_read_input_tokens") == 0, (
            "driver_metadata['cache_read_input_tokens'] must be 0 for cold-start"
        )
