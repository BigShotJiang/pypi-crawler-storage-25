"""
Tests for AC-20: Droid driver applies defense-in-depth error scan + records is_error_field_present.

Covers:
  AC-20: Droid driver:
    (1) keeps existing result_obj.get("is_error", False) check;
    (2) records driver_metadata['is_error_field_present']: bool = "is_error" in result_obj
        (presence test, NOT value test — records whether the undocumented field appeared at all);
    (3) ALSO scans proc.stdout for the same regex as AC-19 as a defense-in-depth fallback.

  Regex (case-insensitive, shared with AC-19):
    /rate.?limit|API.?error|connection.?error|context.?length.?exceeded|litellm\\.exceptions/

  Source: docs.factory.ai/reference/cli-reference (from Risk Watch R18)

Mocking strategy:
  - subprocess.run patched at 'drivers.droid.subprocess.run'
  - Stdout formatted as a single JSON object per the '-o json' contract
  - Interface derived from drivers/_protocol.py + .sherlock-plan.md AC-20

Naming convention: test_AC20_<behavior>
"""
import json
import subprocess
from collections.abc import Mapping
from pathlib import Path
from types import MappingProxyType
from unittest.mock import MagicMock, patch

import pytest

from drivers.droid import DroidDriver
from drivers._protocol import DriverResult

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_TASK_MANIFEST: dict = {
    "task_id": "url_shortener",
    "entry_point": "./seed/README.md",
    "workspace": {"seed_repo": "./seed/"},
}

_CLEAN_RESULT_TEXT = "Task completed successfully."


def _make_droid_proc(
    returncode: int = 0,
    is_error: bool = False,
    include_is_error_key: bool = True,
    result_text: str = _CLEAN_RESULT_TEXT,
    stdout_prefix: str = "",
    input_tokens: int = 120,
    output_tokens: int = 60,
    cost_usd: float = 0.0042,
) -> MagicMock:
    """
    Return a mock subprocess.CompletedProcess whose stdout is a single JSON object
    (per the '-o json' Droid CLI contract from docs.factory.ai/reference/cli-reference).

    stdout_prefix: arbitrary text prepended to the JSON (simulates error text printed
    before the JSON output — tests the defense-in-depth stdout scan).

    include_is_error_key: controls whether "is_error" appears at all in the JSON object
    (tests the is_error_field_present presence check regardless of value).
    """
    obj: dict = {
        "type": "result",
        "subtype": "success",
        "duration_ms": 9000,
        "num_turns": 3,
        "result": result_text,
        "session_id": "sess-abc123",
        "usage": {
            "input_tokens": input_tokens,
            "output_tokens": output_tokens,
            "cost_usd": cost_usd,
        },
    }
    if include_is_error_key:
        obj["is_error"] = is_error

    stdout_json = json.dumps(obj)
    stdout = (stdout_prefix + "\n" + stdout_json) if stdout_prefix else stdout_json

    proc = MagicMock(spec=subprocess.CompletedProcess)
    proc.returncode = returncode
    proc.stdout = stdout
    proc.stderr = ""
    return proc


def _make_workspace(tmp_path: Path) -> Path:
    """Create a minimal workspace with the seed/README.md entry point."""
    seed_dir = tmp_path / "seed"
    seed_dir.mkdir(parents=True, exist_ok=True)
    (seed_dir / "README.md").write_text(
        "Build a URL shortener in Python.", encoding="utf-8"
    )
    return tmp_path


# ---------------------------------------------------------------------------
# AC-20(3): Defense-in-depth stdout scan
# ---------------------------------------------------------------------------

class TestAC20StdoutErrorScan:
    """AC-20(3): Droid driver scans stdout for the AC-19 regex as defense-in-depth."""

    def test_AC20_stdout_error_pattern_aborts_even_if_is_error_false(
        self, tmp_path: Path
    ) -> None:
        """
        Given Droid stdout contains 'factorydroid: error in API call'
        AND the JSON result_obj has is_error=False,
        When the driver processes the result,
        Then DriverResult.aborted is True (defense-in-depth fires).

        AC-20(3): 'stdout has error pattern AND is_error=False → still aborted'
        """
        # Arrange
        workspace = _make_workspace(tmp_path)
        driver = DroidDriver()
        proc = _make_droid_proc(
            is_error=False,
            include_is_error_key=True,
            stdout_prefix="factorydroid: error in API call",
        )

        # Act
        with patch("drivers.droid.subprocess.run", return_value=proc):
            result: DriverResult = driver.execute(
                workspace=workspace,
                task_manifest=_TASK_MANIFEST,
                seed=42,
                budget_usd=2.0,
                wall_clock_budget_seconds=180,
            )

        # Assert
        assert result.aborted is True, (
            "Expected aborted=True when stdout matches error pattern, "
            f"even though is_error=False in JSON; got aborted={result.aborted!r}"
        )

    def test_AC20_stdout_error_abort_reason_category_is_api_error_text(
        self, tmp_path: Path
    ) -> None:
        """
        Given Droid stdout contains the error pattern 'factorydroid: error in API call',
        When driver.execute returns,
        Then abort_reason.category == 'api_error_text'.

        AC-20: 'abort_reason.category="api_error_text"'
        """
        # Arrange
        workspace = _make_workspace(tmp_path)
        driver = DroidDriver()
        proc = _make_droid_proc(
            is_error=False,
            stdout_prefix="factorydroid: error in API call",
        )

        # Act
        with patch("drivers.droid.subprocess.run", return_value=proc):
            result: DriverResult = driver.execute(
                workspace=workspace,
                task_manifest=_TASK_MANIFEST,
                seed=42,
                budget_usd=2.0,
                wall_clock_budget_seconds=180,
            )

        # Assert
        assert result.abort_reason is not None, "abort_reason must not be None"
        assert result.abort_reason.category == "api_error_text", (
            f"abort_reason.category must be 'api_error_text', "
            f"got {result.abort_reason.category!r}"
        )

    def test_AC20_rate_limit_in_stdout_aborts_case_insensitive(
        self, tmp_path: Path
    ) -> None:
        """
        Given Droid stdout contains 'rate limit exceeded' (lower-case),
        When the driver processes the result,
        Then DriverResult.aborted is True (case-insensitive regex matches).

        AC-20(3) shares the same regex as AC-19 (case-insensitive).
        """
        # Arrange
        workspace = _make_workspace(tmp_path)
        driver = DroidDriver()
        proc = _make_droid_proc(
            is_error=False,
            stdout_prefix="rate limit exceeded for this model",
        )

        # Act
        with patch("drivers.droid.subprocess.run", return_value=proc):
            result: DriverResult = driver.execute(
                workspace=workspace,
                task_manifest=_TASK_MANIFEST,
                seed=42,
                budget_usd=2.0,
                wall_clock_budget_seconds=180,
            )

        # Assert
        assert result.aborted is True, (
            "Expected aborted=True for 'rate limit exceeded' in stdout (case-insensitive)"
        )


# ---------------------------------------------------------------------------
# AC-20(2): is_error_field_present recorded regardless of value
# ---------------------------------------------------------------------------

class TestAC20IsErrorFieldPresent:
    """AC-20(2): driver_metadata['is_error_field_present'] records key presence, not value."""

    def test_AC20_is_error_field_present_true_when_is_error_false_in_result(
        self, tmp_path: Path
    ) -> None:
        """
        Given result_obj contains 'is_error: false' (key present, value False),
        When driver.execute processes the result with no error in stdout,
        Then driver_metadata['is_error_field_present'] is True.

        AC-20(2): 'is_error_field_present=True recorded when is_error: false IS in result_obj'
        (presence test, NOT value test)
        """
        # Arrange
        workspace = _make_workspace(tmp_path)
        driver = DroidDriver()
        proc = _make_droid_proc(
            is_error=False,
            include_is_error_key=True,
            stdout_prefix="",  # clean stdout — no error pattern
        )

        # Act
        with patch("drivers.droid.subprocess.run", return_value=proc):
            result: DriverResult = driver.execute(
                workspace=workspace,
                task_manifest=_TASK_MANIFEST,
                seed=42,
                budget_usd=2.0,
                wall_clock_budget_seconds=180,
            )

        # Assert
        assert "is_error_field_present" in result.driver_metadata, (
            "driver_metadata must contain 'is_error_field_present' key"
        )
        assert result.driver_metadata["is_error_field_present"] is True, (
            "is_error_field_present must be True when 'is_error' key is present in result_obj "
            "(even if its value is False); "
            f"got {result.driver_metadata['is_error_field_present']!r}"
        )

    def test_AC20_is_error_field_present_true_when_is_error_true_in_result(
        self, tmp_path: Path
    ) -> None:
        """
        Given result_obj contains 'is_error: true' (key present, value True),
        When driver.execute processes the result,
        Then driver_metadata['is_error_field_present'] is True.

        AC-20(2): both value-True and value-False cases record presence=True.
        """
        # Arrange
        workspace = _make_workspace(tmp_path)
        driver = DroidDriver()
        proc = _make_droid_proc(
            is_error=True,
            include_is_error_key=True,
        )

        # Act
        with patch("drivers.droid.subprocess.run", return_value=proc):
            result: DriverResult = driver.execute(
                workspace=workspace,
                task_manifest=_TASK_MANIFEST,
                seed=42,
                budget_usd=2.0,
                wall_clock_budget_seconds=180,
            )

        # Assert
        assert "is_error_field_present" in result.driver_metadata, (
            "driver_metadata must contain 'is_error_field_present' key"
        )
        assert result.driver_metadata["is_error_field_present"] is True, (
            "is_error_field_present must be True when 'is_error' key is present "
            f"(value=True); got {result.driver_metadata['is_error_field_present']!r}"
        )

    def test_AC20_is_error_field_present_false_when_is_error_absent(
        self, tmp_path: Path
    ) -> None:
        """
        Given result_obj does NOT contain the 'is_error' key at all,
        When driver.execute processes the result,
        Then driver_metadata['is_error_field_present'] is False.

        AC-20(2): 'is_error_field_present=False recorded when is_error key absent from result_obj'
        Operator can use this to detect when the undocumented field disappeared from Droid output.
        """
        # Arrange
        workspace = _make_workspace(tmp_path)
        driver = DroidDriver()
        proc = _make_droid_proc(
            include_is_error_key=False,  # key entirely absent from JSON
        )

        # Act
        with patch("drivers.droid.subprocess.run", return_value=proc):
            result: DriverResult = driver.execute(
                workspace=workspace,
                task_manifest=_TASK_MANIFEST,
                seed=42,
                budget_usd=2.0,
                wall_clock_budget_seconds=180,
            )

        # Assert
        assert "is_error_field_present" in result.driver_metadata, (
            "driver_metadata must contain 'is_error_field_present' key even when absent"
        )
        assert result.driver_metadata["is_error_field_present"] is False, (
            "is_error_field_present must be False when 'is_error' key is absent from result_obj; "
            f"got {result.driver_metadata['is_error_field_present']!r}"
        )


# ---------------------------------------------------------------------------
# AC-20(1): Existing is_error=True check still aborts
# ---------------------------------------------------------------------------

class TestAC20IsErrorValueCheck:
    """AC-20(1): Existing is_error=True in result_obj still triggers abort."""

    def test_AC20_is_error_true_in_result_obj_aborts(self, tmp_path: Path) -> None:
        """
        Given result_obj has is_error=True AND stdout is clean (no error pattern),
        When driver.execute processes the result,
        Then DriverResult.aborted is True.

        AC-20(1): 'keeps the existing result_obj.get("is_error", False) check'
        """
        # Arrange
        workspace = _make_workspace(tmp_path)
        driver = DroidDriver()
        proc = _make_droid_proc(
            is_error=True,
            include_is_error_key=True,
            stdout_prefix="",  # clean stdout
        )

        # Act
        with patch("drivers.droid.subprocess.run", return_value=proc):
            result: DriverResult = driver.execute(
                workspace=workspace,
                task_manifest=_TASK_MANIFEST,
                seed=42,
                budget_usd=2.0,
                wall_clock_budget_seconds=180,
            )

        # Assert
        assert result.aborted is True, (
            "Expected aborted=True when result_obj['is_error']=True; "
            f"got aborted={result.aborted!r}"
        )


# ---------------------------------------------------------------------------
# Clean path: no error in stdout AND is_error absent → NOT aborted
# ---------------------------------------------------------------------------

class TestAC20CleanPathNotAborted:
    """AC-20 negative path: no error conditions → not aborted."""

    def test_AC20_clean_stdout_and_is_error_absent_not_aborted(
        self, tmp_path: Path
    ) -> None:
        """
        Given clean stdout (no error pattern) AND 'is_error' key absent from result_obj,
        When driver.execute processes the result,
        Then DriverResult.aborted is False and is_error_field_present is False.

        AC-20: 'Clean stdout AND is_error absent → NOT aborted, is_error_field_present=False'
        """
        # Arrange
        workspace = _make_workspace(tmp_path)
        driver = DroidDriver()
        proc = _make_droid_proc(
            include_is_error_key=False,
            stdout_prefix="",
        )

        # Act
        with patch("drivers.droid.subprocess.run", return_value=proc):
            result: DriverResult = driver.execute(
                workspace=workspace,
                task_manifest=_TASK_MANIFEST,
                seed=42,
                budget_usd=2.0,
                wall_clock_budget_seconds=180,
            )

        # Assert
        assert result.aborted is False, (
            "Expected aborted=False for clean stdout and absent is_error key; "
            f"got aborted={result.aborted!r}"
        )
        assert result.driver_metadata.get("is_error_field_present") is False, (
            "is_error_field_present must be False for absent is_error key; "
            f"got {result.driver_metadata.get('is_error_field_present')!r}"
        )

    def test_AC20_driver_metadata_is_mapping_on_clean_path(
        self, tmp_path: Path
    ) -> None:
        """
        Given a clean Droid execution (no errors),
        When driver.execute returns,
        Then driver_metadata is a Mapping (frozen via MappingProxyType).

        Protocol invariant from drivers/_protocol.py:63-64.
        """
        # Arrange
        workspace = _make_workspace(tmp_path)
        driver = DroidDriver()
        proc = _make_droid_proc(include_is_error_key=False)

        # Act
        with patch("drivers.droid.subprocess.run", return_value=proc):
            result: DriverResult = driver.execute(
                workspace=workspace,
                task_manifest=_TASK_MANIFEST,
                seed=42,
                budget_usd=2.0,
                wall_clock_budget_seconds=180,
            )

        # Assert
        assert isinstance(result.driver_metadata, Mapping), (
            f"driver_metadata must be a Mapping, got {type(result.driver_metadata)}"
        )


# AC-20(3): Defense-in-depth covers AC-19 patterns (litellm-backed surface)
# Phase 5e final-gate addition (HIGH-1 from fw-review-code + fw-review-forensics):
# Factory Droid shells out through litellm; `litellm.exceptions.*` and
# `connection error` text surfaces in Droid stdout under upstream failures.
# Without these patterns in the regex, such errors would slip through as
# successful runs (or be miscategorized as generic driver_error tombstones).
# These tests pin the broadened-regex contract so a future commit that
# narrows the regex to factorydroid-only patterns is rejected by the suite.

class TestAC20DefenseInDepthCoversAC19Patterns:
    """AC-20(3): Droid stdout-scan regex covers all AC-19 patterns (litellm-backed)."""

    def test_AC20_litellm_exceptions_in_stdout_aborts(
        self, tmp_path: Path
    ) -> None:
        """
        Given Droid stdout contains 'litellm.exceptions.RateLimitError: ...',
        When the driver processes the result,
        Then DriverResult.aborted is True with abort_reason.category='api_error_text'.

        AC-20(3) defense-in-depth: litellm exception text surfaces in Droid
        stdout because Factory Droid is litellm-backed. The narrower
        factorydroid-only regex would have silently missed this — Phase 5e
        final-gate flagged the gap, regex broadened to UNION with AC-19's.
        """
        # Arrange
        workspace = _make_workspace(tmp_path)
        driver = DroidDriver()
        proc = _make_droid_proc(
            is_error=False,
            stdout_prefix="litellm.exceptions.RateLimitError: anthropic/sonnet rate limit hit",
        )

        # Act
        with patch("drivers.droid.subprocess.run", return_value=proc):
            result: DriverResult = driver.execute(
                workspace=workspace,
                task_manifest=_TASK_MANIFEST,
                seed=42,
                budget_usd=2.0,
                wall_clock_budget_seconds=180,
            )

        # Assert
        assert result.aborted is True, (
            "Expected aborted=True for 'litellm.exceptions.*' in Droid stdout"
        )
        assert result.abort_reason is not None
        assert result.abort_reason.category == "api_error_text", (
            f"Expected category='api_error_text', got {result.abort_reason.category!r}"
        )

    def test_AC20_connection_error_in_stdout_aborts(
        self, tmp_path: Path
    ) -> None:
        """
        Given Droid stdout contains 'connection error: ECONNREFUSED',
        When the driver processes the result,
        Then DriverResult.aborted is True (defense-in-depth fires).

        AC-20(3): the broadened regex catches `connection.?error` patterns
        that the prior factorydroid-only regex missed.
        """
        # Arrange
        workspace = _make_workspace(tmp_path)
        driver = DroidDriver()
        proc = _make_droid_proc(
            is_error=False,
            stdout_prefix="connection error: ECONNREFUSED to api.anthropic.com",
        )

        # Act
        with patch("drivers.droid.subprocess.run", return_value=proc):
            result: DriverResult = driver.execute(
                workspace=workspace,
                task_manifest=_TASK_MANIFEST,
                seed=42,
                budget_usd=2.0,
                wall_clock_budget_seconds=180,
            )

        # Assert
        assert result.aborted is True, (
            "Expected aborted=True for 'connection error' in Droid stdout"
        )

    def test_AC20_context_length_exceeded_in_stdout_aborts(
        self, tmp_path: Path
    ) -> None:
        """
        Given Droid stdout contains 'context length exceeded',
        When the driver processes the result,
        Then DriverResult.aborted is True (defense-in-depth fires).

        AC-20(3): the broadened regex catches `context.?length.?exceeded`
        per AC-19 contract.
        """
        # Arrange
        workspace = _make_workspace(tmp_path)
        driver = DroidDriver()
        proc = _make_droid_proc(
            is_error=False,
            stdout_prefix="context length exceeded for model claude-sonnet-4-5",
        )

        # Act
        with patch("drivers.droid.subprocess.run", return_value=proc):
            result: DriverResult = driver.execute(
                workspace=workspace,
                task_manifest=_TASK_MANIFEST,
                seed=42,
                budget_usd=2.0,
                wall_clock_budget_seconds=180,
            )

        # Assert
        assert result.aborted is True, (
            "Expected aborted=True for 'context length exceeded' in Droid stdout"
        )
