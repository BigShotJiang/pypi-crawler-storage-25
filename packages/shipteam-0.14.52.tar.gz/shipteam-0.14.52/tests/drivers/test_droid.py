"""
Tests for drivers/droid.py — Phase 2 Part 1 (5b RED phase).

Covers:
  R1: DroidDriver.execute() writes entry_point CONTENT to a tempfile and
      invokes 'droid exec --auto low -o json -f <tempfile>'.
  R3: DroidDriver switches from stream-json NDJSON parsing to single-object
      JSON parsing using '-o json'.

Identity (unchanged from 5a):
  - driver.name == "droid"
  - driver.version() returns a non-empty string
  - driver.sdk_version() == driver.version()
  - driver.release_date() returns ISO 8601 string
  - cache_strategy == "omitted" when disable_prompt_cache=True
  - DriverResult schema parity (nullable tokens/cost)

New subprocess contract (R1 + R3):
  - Command: ["droid", "exec", "--auto", "low", "-o", "json", "-f", <tempfile_path>]
  - Tempfile content: the resolved text of task_manifest["entry_point"] (read from workspace)
  - Fallback: if entry_point file does not exist, write the raw string as prompt
  - Tempfile cleaned up after execute() returns (success + failure paths)
  - stdout parsed as ONE JSON object (not NDJSON line-by-line)
  - is_error=True in JSON object → DriverResult(aborted=True, abort_reason="driver_error")
  - Cost extracted from JSON object via usage sub-object:
      {"usage": {"input_tokens": N, "output_tokens": N, "cost_usd": F}}

Error handling (unchanged from 5a):
  - TimeoutExpired → DriverResult(aborted=True, abort_reason="wall_clock_exceeded")
  - FileNotFoundError → DriverResult(aborted=True, abort_reason="driver_error")

Interface Contract (from drivers/_protocol.py):
  class Driver(Protocol):
    name: str
    def version(self) -> str: ...
    def sdk_version(self) -> str: ...
    def release_date(self) -> str: ...
    def prepare(workspace, task_manifest) -> None: ...
    def execute(workspace, task_manifest, seed, budget_usd,
                wall_clock_budget_seconds, disable_prompt_cache) -> DriverResult: ...

Mocking strategy:
  - subprocess.run is patched to return stdout as a serialised JSON object
  - Tempfile cleanup is verified via os.path.exists after execute() returns
  - entry_point file is created in tmp_path to test content-reading path
"""

import pytest

pytest.skip(
    "Phase 5e: cache_strategy contract for droid narrowed from "
    "{'omitted','salted'} to {'salted','native'}; droid reports 'native' "
    "(no cache layer to bypass). The disable_prompt_cache=True API is "
    "removed from Driver.execute(). AC-20 adds stdout error-text scan "
    "(defense-in-depth alongside is_error JSON field) plus "
    "driver_metadata['is_error_field_present']. New behavioral coverage "
    "lives in tests/drivers/test_droid_error_scan.py (AC-20). Phase 5g "
    "will add real droid CLI integration coverage. This module is "
    "preserved as a record of the removed Phase 5b contract.",
    allow_module_level=True,
)

import json
import os
import subprocess
from collections.abc import Mapping
from pathlib import Path
from unittest.mock import MagicMock, patch

from drivers.droid import DroidDriver
from drivers._protocol import DriverResult, VALID_COST_SOURCES, VALID_CACHE_STRATEGIES


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_json_result(
    returncode: int = 0,
    is_error: bool = False,
    result_text: str = "Task completed successfully.",
    input_tokens: int | None = None,
    output_tokens: int | None = None,
    cost_usd: float | None = None,
    num_turns: int = 3,
    duration_ms: int = 9000,
    session_id: str = "sess-abc123",
    usage_subobject: bool = True,
) -> MagicMock:
    """
    Return a mock subprocess.CompletedProcess whose stdout is a single JSON object,
    per the '-o json' contract documented at docs.factory.ai/reference/cli-reference.

    By default uses the usage sub-object shape (Anthropic-style):
      {"usage": {"input_tokens": N, "output_tokens": N, "cost_usd": F}}
    """
    obj: dict = {
        "type": "result",
        "subtype": "success",
        "is_error": is_error,
        "duration_ms": duration_ms,
        "num_turns": num_turns,
        "result": result_text,
        "session_id": session_id,
    }
    if usage_subobject:
        usage: dict = {}
        if input_tokens is not None:
            usage["input_tokens"] = input_tokens
        if output_tokens is not None:
            usage["output_tokens"] = output_tokens
        if cost_usd is not None:
            usage["cost_usd"] = cost_usd
        if usage:
            obj["usage"] = usage
    else:
        # Top-level flat shape (alternative — used by TestDroidDriverExecuteTopLevelCost)
        if input_tokens is not None:
            obj["input_tokens"] = input_tokens
        if output_tokens is not None:
            obj["output_tokens"] = output_tokens
        if cost_usd is not None:
            obj["cost_usd"] = cost_usd

    proc = MagicMock(spec=subprocess.CompletedProcess)
    proc.returncode = returncode
    proc.stdout = json.dumps(obj)
    proc.stderr = ""
    return proc


_TASK_MANIFEST: dict = {
    "task_id": "url_shortener",
    "entry_point": "./seed/README.md",
    "workspace": {"seed_repo": "./seed/"},
}

_TASK_PROMPT_TEXT = "Build a URL shortener in Python."


def _make_workspace_with_entry_point(tmp_path: Path, content: str = _TASK_PROMPT_TEXT) -> Path:
    """Create a workspace directory with the seed/README.md entry_point file."""
    seed_dir = tmp_path / "seed"
    seed_dir.mkdir(parents=True, exist_ok=True)
    readme = seed_dir / "README.md"
    readme.write_text(content, encoding="utf-8")
    return tmp_path


# ---------------------------------------------------------------------------
# Driver Protocol compliance: name, version, sdk_version, release_date
# ---------------------------------------------------------------------------

class TestDroidDriverIdentity:
    """DroidDriver implements the Driver Protocol identity methods."""

    def test_name_is_droid(self) -> None:
        """
        Given a DroidDriver instance,
        When driver.name is accessed,
        Then it equals 'droid'.
        """
        driver = DroidDriver()
        assert driver.name == "droid"

    def test_version_returns_nonempty_string(self) -> None:
        """
        Given a DroidDriver instance,
        When driver.version() is called,
        Then a non-empty string is returned.
        """
        driver = DroidDriver()
        v = driver.version()
        assert isinstance(v, str) and len(v) > 0, (
            f"version() must return a non-empty string, got {v!r}"
        )

    def test_sdk_version_returns_nonempty_string(self) -> None:
        """
        Given a DroidDriver instance,
        When driver.sdk_version() is called,
        Then a non-empty string is returned.

        Note: Droid has no separate SDK; sdk_version() == version().
        """
        driver = DroidDriver()
        sv = driver.sdk_version()
        assert isinstance(sv, str) and len(sv) > 0, (
            f"sdk_version() must return a non-empty string, got {sv!r}"
        )

    def test_sdk_version_equals_version(self) -> None:
        """
        Given a DroidDriver instance,
        When both driver.version() and driver.sdk_version() are called,
        Then they return the same value (no separate SDK for Droid).
        """
        driver = DroidDriver()
        assert driver.version() == driver.sdk_version(), (
            "Droid has no separate SDK; sdk_version() must equal version()"
        )

    def test_release_date_returns_iso8601_string(self) -> None:
        """
        Given a DroidDriver instance,
        When driver.release_date() is called,
        Then it returns a non-empty ISO 8601 date string (YYYY-MM-DD prefix).
        """
        driver = DroidDriver()
        rd = driver.release_date()
        assert isinstance(rd, str) and len(rd) >= 10, (
            f"release_date() must return an ISO 8601 string, got {rd!r}"
        )
        parts = rd[:10].split("-")
        assert len(parts) == 3, f"Expected YYYY-MM-DD, got {rd!r}"
        assert all(p.isdigit() for p in parts), f"Non-numeric date parts in {rd!r}"


# ---------------------------------------------------------------------------
# R1: Subprocess command format — ['droid', 'exec', '--auto', 'low', '-o', 'json', '-f', <tempfile>]
# ---------------------------------------------------------------------------

class TestDroidDriverCommandFormat:
    """
    R1: DroidDriver.execute() must use the new CLI invocation format.

    Per docs.factory.ai/reference/cli-reference:
      droid exec --auto low -o json -f <tempfile>
    The task prompt is written to a tempfile; -f passes the tempfile path.
    """

    def test_command_uses_minus_o_json_not_stream_json(self, tmp_path: Path) -> None:
        """
        Given DroidDriver.execute is called,
        When subprocess.run is inspected,
        Then the command contains '-o' 'json' and does NOT contain 'stream-json'
        or '--output-format'.

        R1 + R3: Switching from stream-json to single-object json mode.
        """
        workspace = _make_workspace_with_entry_point(tmp_path)
        driver = DroidDriver()
        proc = _make_json_result()

        with patch("subprocess.run", return_value=proc) as mock_run:
            driver.execute(
                workspace=workspace,
                task_manifest=_TASK_MANIFEST,
                seed=1,
                budget_usd=10.0,
                wall_clock_budget_seconds=1800,
                disable_prompt_cache=True,
            )

        assert mock_run.called, "subprocess.run was not called"
        cmd = mock_run.call_args[0][0]
        cmd_as_list = list(cmd) if not isinstance(cmd, list) else cmd
        cmd_str = " ".join(str(x) for x in cmd_as_list)

        assert "-o" in cmd_as_list, f"Command must include '-o' flag; got: {cmd_as_list!r}"
        assert "json" in cmd_as_list, f"Command must include 'json' output mode; got: {cmd_as_list!r}"
        assert "stream-json" not in cmd_str, (
            f"Command must NOT contain 'stream-json' (R3 removes it); got: {cmd_str!r}"
        )
        assert "--output-format" not in cmd_str, (
            f"Command must NOT contain '--output-format' (replaced by -o); got: {cmd_str!r}"
        )

    def test_command_includes_auto_low_flags(self, tmp_path: Path) -> None:
        """
        Given DroidDriver.execute is called,
        When subprocess.run is inspected,
        Then the command includes '--auto' 'low'.

        R1: '--auto low' is part of the new droid exec invocation.
        """
        workspace = _make_workspace_with_entry_point(tmp_path)
        driver = DroidDriver()
        proc = _make_json_result()

        with patch("subprocess.run", return_value=proc) as mock_run:
            driver.execute(
                workspace=workspace,
                task_manifest=_TASK_MANIFEST,
                seed=1,
                budget_usd=10.0,
                wall_clock_budget_seconds=1800,
                disable_prompt_cache=True,
            )

        cmd = mock_run.call_args[0][0]
        cmd_as_list = list(cmd) if not isinstance(cmd, list) else cmd
        assert "--auto" in cmd_as_list, f"Command must include '--auto'; got: {cmd_as_list!r}"
        # Find --auto and verify the next element is 'low'
        auto_idx = cmd_as_list.index("--auto")
        assert auto_idx + 1 < len(cmd_as_list), "--auto has no following argument"
        assert cmd_as_list[auto_idx + 1] == "low", (
            f"'--auto' must be followed by 'low', got {cmd_as_list[auto_idx + 1]!r}"
        )

    def test_command_includes_minus_f_with_tempfile_path(self, tmp_path: Path) -> None:
        """
        Given DroidDriver.execute is called,
        When subprocess.run is inspected,
        Then the command includes '-f' followed by a file path (tempfile).

        R1: The task prompt is written to a tempfile; '-f <path>' passes it to droid exec.
        """
        workspace = _make_workspace_with_entry_point(tmp_path)
        driver = DroidDriver()
        proc = _make_json_result()

        with patch("subprocess.run", return_value=proc) as mock_run:
            driver.execute(
                workspace=workspace,
                task_manifest=_TASK_MANIFEST,
                seed=1,
                budget_usd=10.0,
                wall_clock_budget_seconds=1800,
                disable_prompt_cache=True,
            )

        cmd = mock_run.call_args[0][0]
        cmd_as_list = list(cmd) if not isinstance(cmd, list) else cmd
        assert "-f" in cmd_as_list, f"Command must include '-f' flag; got: {cmd_as_list!r}"
        f_idx = cmd_as_list.index("-f")
        assert f_idx + 1 < len(cmd_as_list), "'-f' has no following argument (tempfile path)"
        tempfile_arg = cmd_as_list[f_idx + 1]
        assert isinstance(tempfile_arg, str) and len(tempfile_arg) > 0, (
            f"'-f' argument must be a non-empty file path, got {tempfile_arg!r}"
        )

    def test_command_starts_with_droid_exec(self, tmp_path: Path) -> None:
        """
        Given DroidDriver.execute is called,
        When subprocess.run is inspected,
        Then the command begins with ['droid', 'exec'].
        """
        workspace = _make_workspace_with_entry_point(tmp_path)
        driver = DroidDriver()
        proc = _make_json_result()

        with patch("subprocess.run", return_value=proc) as mock_run:
            driver.execute(
                workspace=workspace,
                task_manifest=_TASK_MANIFEST,
                seed=1,
                budget_usd=10.0,
                wall_clock_budget_seconds=1800,
                disable_prompt_cache=True,
            )

        cmd = mock_run.call_args[0][0]
        cmd_as_list = list(cmd) if not isinstance(cmd, list) else cmd
        assert cmd_as_list[0] == "droid", f"Command must start with 'droid'; got: {cmd_as_list!r}"
        assert cmd_as_list[1] == "exec", f"Command[1] must be 'exec'; got: {cmd_as_list!r}"


# ---------------------------------------------------------------------------
# R1: Tempfile content — entry_point file content (not path)
# ---------------------------------------------------------------------------

class TestDroidDriverTempfileContent:
    """
    R1: DroidDriver must write the CONTENT of the entry_point file into the tempfile,
    not the file path string.

    Per spec:
      task_manifest["entry_point"] is a path string like "./seed/README.md".
      The driver reads that file from workspace and writes its content to tempfile.
      Fallback: if the file does not exist, write the raw entry_point string as prompt.
    """

    def test_tempfile_receives_entry_point_file_content(self, tmp_path: Path) -> None:
        """
        Given a workspace containing seed/README.md with known content,
        When DroidDriver.execute is called,
        Then the tempfile passed to '-f' contains the README.md content,
        not the path string './seed/README.md'.

        R1: The prompt written to tempfile is the resolved task text, not a path.
        """
        prompt_text = "Build a URL shortener in Python with Flask."
        workspace = _make_workspace_with_entry_point(tmp_path, content=prompt_text)
        driver = DroidDriver()

        captured_tempfile_paths: list[str] = []

        def _capturing_run(cmd, **kwargs):
            # Capture the tempfile path from the '-f' argument
            cmd_list = list(cmd)
            if "-f" in cmd_list:
                f_idx = cmd_list.index("-f")
                if f_idx + 1 < len(cmd_list):
                    captured_tempfile_paths.append(cmd_list[f_idx + 1])
            return _make_json_result()

        with patch("subprocess.run", side_effect=_capturing_run):
            driver.execute(
                workspace=workspace,
                task_manifest=_TASK_MANIFEST,
                seed=1,
                budget_usd=10.0,
                wall_clock_budget_seconds=1800,
                disable_prompt_cache=True,
            )

        # The tempfile must have been passed; content must be the file content
        # NOTE: tempfile is deleted AFTER execute() returns, so we cannot read it here.
        # This test verifies the path was captured (tempfile existed during subprocess call).
        # The cleanup test (below) verifies the file is gone afterward.
        assert len(captured_tempfile_paths) == 1, (
            "Expected exactly one '-f <tempfile>' argument to be captured"
        )

    def test_tempfile_content_is_not_the_raw_path_string(self, tmp_path: Path) -> None:
        """
        Given a workspace containing seed/README.md with known content,
        When DroidDriver.execute calls subprocess.run,
        Then the tempfile written before the call does NOT contain the literal
        path string './seed/README.md' — it contains the resolved file content.

        R1: Passing the raw path would be wrong; Droid reads via -f, not via Python.
        """
        prompt_text = "This is the actual task prompt content."
        workspace = _make_workspace_with_entry_point(tmp_path, content=prompt_text)
        driver = DroidDriver()

        captured_tempfile_content: list[str] = []

        def _read_tempfile_during_run(cmd, **kwargs):
            cmd_list = list(cmd)
            if "-f" in cmd_list:
                f_idx = cmd_list.index("-f")
                if f_idx + 1 < len(cmd_list):
                    tf_path = cmd_list[f_idx + 1]
                    try:
                        captured_tempfile_content.append(
                            open(tf_path, encoding="utf-8").read()
                        )
                    except OSError:
                        captured_tempfile_content.append("<file not readable>")
            return _make_json_result()

        with patch("subprocess.run", side_effect=_read_tempfile_during_run):
            driver.execute(
                workspace=workspace,
                task_manifest=_TASK_MANIFEST,
                seed=1,
                budget_usd=10.0,
                wall_clock_budget_seconds=1800,
                disable_prompt_cache=True,
            )

        assert len(captured_tempfile_content) == 1, "subprocess.run was not called with -f"
        content = captured_tempfile_content[0]
        assert content == prompt_text, (
            f"Tempfile must contain the entry_point FILE CONTENT, not the path string.\n"
            f"  Expected: {prompt_text!r}\n"
            f"  Got:      {content!r}"
        )
        assert content != "./seed/README.md", (
            "Tempfile must NOT contain the raw entry_point path string './seed/README.md'"
        )

    def test_fallback_writes_raw_entry_point_string_when_file_missing(
        self, tmp_path: Path
    ) -> None:
        """
        Given a workspace where the entry_point file does NOT exist,
        When DroidDriver.execute calls subprocess.run,
        Then the tempfile contains the raw entry_point string (the path as prompt fallback).

        R1: When entry_point cannot be resolved, write it as-is.
        This matches what AiderDriver does with --message today.
        """
        # workspace does NOT have seed/README.md
        driver = DroidDriver()
        captured_content: list[str] = []

        def _read_tempfile(cmd, **kwargs):
            cmd_list = list(cmd)
            if "-f" in cmd_list:
                f_idx = cmd_list.index("-f")
                if f_idx + 1 < len(cmd_list):
                    try:
                        captured_content.append(
                            open(cmd_list[f_idx + 1], encoding="utf-8").read()
                        )
                    except OSError:
                        captured_content.append("<unreadable>")
            return _make_json_result()

        with patch("subprocess.run", side_effect=_read_tempfile):
            driver.execute(
                workspace=tmp_path,   # empty workspace — no seed/README.md
                task_manifest=_TASK_MANIFEST,
                seed=1,
                budget_usd=10.0,
                wall_clock_budget_seconds=1800,
                disable_prompt_cache=True,
            )

        assert len(captured_content) == 1
        # Fallback: raw entry_point string written to tempfile
        raw_entry_point = _TASK_MANIFEST["entry_point"]
        assert captured_content[0] == raw_entry_point, (
            f"Fallback: tempfile must contain raw entry_point string {raw_entry_point!r}, "
            f"got {captured_content[0]!r}"
        )


# ---------------------------------------------------------------------------
# R1: Tempfile cleanup — deleted after execute() returns (success + failure)
# ---------------------------------------------------------------------------

class TestDroidDriverTempfileCleanup:
    """
    R1: The tempfile created for the task prompt MUST be deleted after execute()
    returns, regardless of whether subprocess succeeded or failed.

    Implementation must use try/finally or NamedTemporaryFile context manager.
    """

    def test_tempfile_deleted_after_successful_run(self, tmp_path: Path) -> None:
        """
        Given a successful subprocess.run,
        When DroidDriver.execute returns,
        Then the tempfile used for '-f' no longer exists on disk.

        R1: No leaked temp files on the happy path.
        """
        workspace = _make_workspace_with_entry_point(tmp_path)
        driver = DroidDriver()
        captured_paths: list[str] = []

        def _capture_and_succeed(cmd, **kwargs):
            cmd_list = list(cmd)
            if "-f" in cmd_list:
                f_idx = cmd_list.index("-f")
                if f_idx + 1 < len(cmd_list):
                    captured_paths.append(cmd_list[f_idx + 1])
            return _make_json_result(returncode=0)

        with patch("subprocess.run", side_effect=_capture_and_succeed):
            driver.execute(
                workspace=workspace,
                task_manifest=_TASK_MANIFEST,
                seed=1,
                budget_usd=10.0,
                wall_clock_budget_seconds=1800,
                disable_prompt_cache=True,
            )

        assert len(captured_paths) == 1, "Expected one tempfile path to be captured"
        tf_path = captured_paths[0]
        assert not os.path.exists(tf_path), (
            f"Tempfile {tf_path!r} must be deleted after execute() returns (success path)"
        )

    def test_tempfile_deleted_after_failed_run(self, tmp_path: Path) -> None:
        """
        Given subprocess.run returns non-zero exit code (is_error=True),
        When DroidDriver.execute returns,
        Then the tempfile used for '-f' still does not exist.

        R1: Cleanup must happen on error path too (try/finally pattern).
        """
        workspace = _make_workspace_with_entry_point(tmp_path)
        driver = DroidDriver()
        captured_paths: list[str] = []

        def _capture_and_fail(cmd, **kwargs):
            cmd_list = list(cmd)
            if "-f" in cmd_list:
                f_idx = cmd_list.index("-f")
                if f_idx + 1 < len(cmd_list):
                    captured_paths.append(cmd_list[f_idx + 1])
            return _make_json_result(returncode=1, is_error=True)

        with patch("subprocess.run", side_effect=_capture_and_fail):
            driver.execute(
                workspace=workspace,
                task_manifest=_TASK_MANIFEST,
                seed=1,
                budget_usd=10.0,
                wall_clock_budget_seconds=1800,
                disable_prompt_cache=True,
            )

        assert len(captured_paths) == 1
        tf_path = captured_paths[0]
        assert not os.path.exists(tf_path), (
            f"Tempfile {tf_path!r} must be deleted after execute() returns (error path)"
        )

    def test_tempfile_deleted_after_timeout_expired(self, tmp_path: Path) -> None:
        """
        Given subprocess.run raises TimeoutExpired,
        When DroidDriver.execute returns,
        Then the tempfile is still cleaned up.

        R1: try/finally cleanup must fire even when TimeoutExpired is caught.
        """
        workspace = _make_workspace_with_entry_point(tmp_path)
        driver = DroidDriver()
        captured_paths: list[str] = []

        def _capture_and_timeout(cmd, **kwargs):
            cmd_list = list(cmd)
            if "-f" in cmd_list:
                f_idx = cmd_list.index("-f")
                if f_idx + 1 < len(cmd_list):
                    captured_paths.append(cmd_list[f_idx + 1])
            raise subprocess.TimeoutExpired(cmd=cmd_list, timeout=1800)

        with patch("subprocess.run", side_effect=_capture_and_timeout):
            driver.execute(
                workspace=workspace,
                task_manifest=_TASK_MANIFEST,
                seed=1,
                budget_usd=10.0,
                wall_clock_budget_seconds=1800,
                disable_prompt_cache=True,
            )

        if captured_paths:
            tf_path = captured_paths[0]
            assert not os.path.exists(tf_path), (
                f"Tempfile {tf_path!r} must be deleted after TimeoutExpired cleanup"
            )


# ---------------------------------------------------------------------------
# R3: execute() parses single JSON object (not NDJSON), happy paths
# ---------------------------------------------------------------------------

class TestDroidDriverExecuteJsonParsing:
    """
    R3: DroidDriver.execute() parses proc.stdout as ONE JSON object, not line-by-line.

    The '-o json' mode returns a single object with snake_case fields including
    'is_error', 'duration_ms', 'num_turns', 'result', 'session_id'.
    Cost/tokens come from a 'usage' sub-object (Anthropic-style convention).
    """

    def test_result_is_driver_result_instance(self, tmp_path: Path) -> None:
        """
        Given a mocked subprocess returning single-object JSON,
        When execute completes,
        Then the return value is a DriverResult instance.
        """
        workspace = _make_workspace_with_entry_point(tmp_path)
        driver = DroidDriver()
        proc = _make_json_result()

        with patch("subprocess.run", return_value=proc):
            result = driver.execute(
                workspace=workspace,
                task_manifest=_TASK_MANIFEST,
                seed=1,
                budget_usd=10.0,
                wall_clock_budget_seconds=1800,
                disable_prompt_cache=True,
            )

        assert isinstance(result, DriverResult), (
            f"execute() must return DriverResult, got {type(result)}"
        )

    def test_happy_path_with_usage_subobject_populates_tokens_and_cost(
        self, tmp_path: Path
    ) -> None:
        """
        Given single-object JSON with usage sub-object:
          {"usage": {"input_tokens": 1500, "output_tokens": 400, "cost_usd": 0.0095}}
        When execute completes,
        Then DriverResult has input_tokens=1500, output_tokens=400, cost_usd=0.0095.

        R3: Anthropic-style usage sub-object is the primary expected shape for
        Factory Droid (Phase 2 Part 1 assumption — verified by empirical capture
        in Phase 2 Part 2).
        """
        workspace = _make_workspace_with_entry_point(tmp_path)
        driver = DroidDriver()
        proc = _make_json_result(
            input_tokens=1500,
            output_tokens=400,
            cost_usd=0.0095,
            usage_subobject=True,
        )

        with patch("subprocess.run", return_value=proc):
            result = driver.execute(
                workspace=workspace,
                task_manifest=_TASK_MANIFEST,
                seed=1,
                budget_usd=10.0,
                wall_clock_budget_seconds=1800,
                disable_prompt_cache=True,
            )

        assert result.input_tokens == 1500, (
            f"input_tokens from usage.input_tokens must be 1500, got {result.input_tokens}"
        )
        assert result.output_tokens == 400, (
            f"output_tokens from usage.output_tokens must be 400, got {result.output_tokens}"
        )
        assert result.cost_usd is not None and abs(result.cost_usd - 0.0095) < 1e-9, (
            f"cost_usd from usage.cost_usd must be 0.0095, got {result.cost_usd}"
        )

    def test_happy_path_with_cost_absent_returns_none(self, tmp_path: Path) -> None:
        """
        Given single-object JSON with no usage sub-object (cost fields absent),
        When execute completes,
        Then DriverResult.cost_usd is None, tokens are None.

        R3: Absent cost/token fields must produce None, never raise KeyError.
        """
        workspace = _make_workspace_with_entry_point(tmp_path)
        driver = DroidDriver()
        # No usage sub-object, no top-level token fields
        proc = _make_json_result(usage_subobject=True)  # usage will be {} → omitted

        with patch("subprocess.run", return_value=proc):
            result = driver.execute(
                workspace=workspace,
                task_manifest=_TASK_MANIFEST,
                seed=1,
                budget_usd=10.0,
                wall_clock_budget_seconds=1800,
                disable_prompt_cache=True,
            )

        assert result.cost_usd is None, (
            "cost_usd must be None when cost fields absent from JSON result"
        )
        assert result.input_tokens is None, (
            "input_tokens must be None when absent from JSON result"
        )
        assert result.output_tokens is None, (
            "output_tokens must be None when absent from JSON result"
        )

    def test_is_error_true_in_json_returns_aborted_driver_error(self, tmp_path: Path) -> None:
        """
        Given single-object JSON where is_error=True,
        When execute completes,
        Then DriverResult(aborted=True, abort_reason="driver_error") is returned.

        R3: The is_error field in the JSON object maps to aborted + abort_reason.
        """
        workspace = _make_workspace_with_entry_point(tmp_path)
        driver = DroidDriver()
        proc = _make_json_result(is_error=True, returncode=0)
        # Note: returncode may be 0 but is_error=True in JSON still means aborted

        with patch("subprocess.run", return_value=proc):
            result = driver.execute(
                workspace=workspace,
                task_manifest=_TASK_MANIFEST,
                seed=1,
                budget_usd=10.0,
                wall_clock_budget_seconds=1800,
                disable_prompt_cache=True,
            )

        assert result.aborted is True, "is_error=True in JSON must set aborted=True"
        assert result.abort_reason == "driver_error", (
            f"abort_reason must be 'driver_error' for is_error=True; got {result.abort_reason!r}"
        )

    def test_is_error_false_in_json_returns_not_aborted(self, tmp_path: Path) -> None:
        """
        Given single-object JSON where is_error=False, returncode=0,
        When execute completes,
        Then DriverResult.aborted is False and abort_reason is None.
        """
        workspace = _make_workspace_with_entry_point(tmp_path)
        driver = DroidDriver()
        proc = _make_json_result(is_error=False, returncode=0)

        with patch("subprocess.run", return_value=proc):
            result = driver.execute(
                workspace=workspace,
                task_manifest=_TASK_MANIFEST,
                seed=1,
                budget_usd=10.0,
                wall_clock_budget_seconds=1800,
                disable_prompt_cache=True,
            )

        assert result.aborted is False, "is_error=False + returncode=0 must produce aborted=False"
        assert result.abort_reason is None

    def test_cost_source_is_scraped(self, tmp_path: Path) -> None:
        """
        Given a mocked subprocess returning single-object JSON,
        When execute completes,
        Then DriverResult.cost_source == 'scraped'.

        AC-7: Droid uses JSON scraping (no native SDK cost field).
        """
        workspace = _make_workspace_with_entry_point(tmp_path)
        driver = DroidDriver()
        proc = _make_json_result(input_tokens=100, output_tokens=50, cost_usd=0.001)

        with patch("subprocess.run", return_value=proc):
            result = driver.execute(
                workspace=workspace,
                task_manifest=_TASK_MANIFEST,
                seed=1,
                budget_usd=10.0,
                wall_clock_budget_seconds=1800,
                disable_prompt_cache=True,
            )

        assert result.cost_source == "scraped", (
            f"Droid driver must use cost_source='scraped', got {result.cost_source!r}"
        )

    def test_wall_clock_ms_is_nonnegative_int(self, tmp_path: Path) -> None:
        """
        Given a mocked subprocess,
        When execute completes,
        Then DriverResult.wall_clock_ms is a non-negative integer.
        """
        workspace = _make_workspace_with_entry_point(tmp_path)
        driver = DroidDriver()
        proc = _make_json_result()

        with patch("subprocess.run", return_value=proc):
            result = driver.execute(
                workspace=workspace,
                task_manifest=_TASK_MANIFEST,
                seed=1,
                budget_usd=10.0,
                wall_clock_budget_seconds=1800,
                disable_prompt_cache=True,
            )

        assert isinstance(result.wall_clock_ms, int)
        assert result.wall_clock_ms >= 0

    def test_driver_metadata_is_nested_dict(self, tmp_path: Path) -> None:
        """
        Given a mocked subprocess returning single-object JSON,
        When execute completes,
        Then DriverResult.driver_metadata is a dict.

        AC-7: Driver-specific metadata must remain nested under driver_metadata.
        """
        workspace = _make_workspace_with_entry_point(tmp_path)
        driver = DroidDriver()
        proc = _make_json_result()

        with patch("subprocess.run", return_value=proc):
            result = driver.execute(
                workspace=workspace,
                task_manifest=_TASK_MANIFEST,
                seed=1,
                budget_usd=10.0,
                wall_clock_budget_seconds=1800,
                disable_prompt_cache=True,
            )

        assert isinstance(result.driver_metadata, Mapping), (
            "driver_metadata must be a Mapping per AC-7 schema contract "
            "(MappingProxyType per drivers/_protocol.py:63-64)"
        )


# ---------------------------------------------------------------------------
# AC-14: cache_strategy == "omitted" when disable_prompt_cache=True
# ---------------------------------------------------------------------------

class TestDroidDriverCacheStrategy:
    """
    AC-14: Droid driver records cache_strategy in DriverResult.

    Droid calls the Anthropic API via its own SDK layer; we cannot intercept
    those requests directly. The driver MUST record cache compliance mode.
    """

    def test_cache_strategy_omitted_when_cache_disabled(self, tmp_path: Path) -> None:
        """
        Given disable_prompt_cache=True,
        When DroidDriver.execute completes,
        Then DriverResult.cache_strategy == 'omitted'.

        AC-14: Droid has no native cache_control API; 'omitted' is the correct
        cache_strategy since no cache_control headers are sent.
        """
        workspace = _make_workspace_with_entry_point(tmp_path)
        driver = DroidDriver()
        proc = _make_json_result()

        with patch("subprocess.run", return_value=proc):
            result = driver.execute(
                workspace=workspace,
                task_manifest=_TASK_MANIFEST,
                seed=1,
                budget_usd=10.0,
                wall_clock_budget_seconds=1800,
                disable_prompt_cache=True,
            )

        assert result.cache_strategy == "omitted", (
            f"Droid driver must record cache_strategy='omitted', got {result.cache_strategy!r}"
        )

    def test_cache_strategy_in_valid_set(self, tmp_path: Path) -> None:
        """
        Given any execute call,
        When execute completes,
        Then DriverResult.cache_strategy is one of the valid enum values.
        """
        workspace = _make_workspace_with_entry_point(tmp_path)
        driver = DroidDriver()
        proc = _make_json_result()

        with patch("subprocess.run", return_value=proc):
            result = driver.execute(
                workspace=workspace,
                task_manifest=_TASK_MANIFEST,
                seed=1,
                budget_usd=10.0,
                wall_clock_budget_seconds=1800,
                disable_prompt_cache=True,
            )

        assert result.cache_strategy in VALID_CACHE_STRATEGIES, (
            f"cache_strategy must be in {VALID_CACHE_STRATEGIES}, "
            f"got {result.cache_strategy!r}"
        )


# ---------------------------------------------------------------------------
# Nullable fields — schema parity (AC-7)
# ---------------------------------------------------------------------------

class TestDroidDriverNullableFields:
    """
    AC-7: Droid DriverResult must be schema-compatible with claude_code result.

    input_tokens, output_tokens, cost_usd are typed as int|None / float|None.
    None is explicitly valid for drivers that cannot report these natively.
    """

    def test_nullable_tokens_do_not_raise(self, tmp_path: Path) -> None:
        """
        Given JSON result with no usage sub-object,
        When execute completes,
        Then DriverResult with None tokens is produced without raising ValueError.
        """
        workspace = _make_workspace_with_entry_point(tmp_path)
        driver = DroidDriver()
        proc = _make_json_result(usage_subobject=True)  # empty usage → None

        with patch("subprocess.run", return_value=proc):
            result = driver.execute(
                workspace=workspace,
                task_manifest=_TASK_MANIFEST,
                seed=1,
                budget_usd=10.0,
                wall_clock_budget_seconds=1800,
                disable_prompt_cache=True,
            )

        assert result.input_tokens is None or isinstance(result.input_tokens, int)
        assert result.output_tokens is None or isinstance(result.output_tokens, int)
        assert result.cost_usd is None or isinstance(result.cost_usd, float)

    def test_cost_source_is_scraped_not_native(self, tmp_path: Path) -> None:
        """
        Given any Droid JSON output,
        When execute completes,
        Then cost_source is 'scraped', never 'native'.

        'native' is reserved for the claude_code driver using the Agent SDK.
        """
        workspace = _make_workspace_with_entry_point(tmp_path)
        driver = DroidDriver()
        proc = _make_json_result()

        with patch("subprocess.run", return_value=proc):
            result = driver.execute(
                workspace=workspace,
                task_manifest=_TASK_MANIFEST,
                seed=1,
                budget_usd=10.0,
                wall_clock_budget_seconds=1800,
                disable_prompt_cache=True,
            )

        assert result.cost_source != "native", (
            "Droid cost_source must not be 'native' — it uses stdout scraping"
        )
        assert result.cost_source in VALID_COST_SOURCES, (
            f"cost_source must be in {VALID_COST_SOURCES}, got {result.cost_source!r}"
        )


# ---------------------------------------------------------------------------
# C1: subprocess error handling — TimeoutExpired and FileNotFoundError (unchanged)
# ---------------------------------------------------------------------------

class TestDroidDriverSubprocessErrors:
    """
    C1: DroidDriver.execute must not propagate subprocess exceptions.
    TimeoutExpired -> DriverResult(aborted=True, abort_reason="wall_clock_exceeded").
    FileNotFoundError -> DriverResult(aborted=True, abort_reason="driver_error").
    """

    def test_timeout_expired_returns_wall_clock_exceeded(self, tmp_path: Path) -> None:
        """
        Given subprocess.run raises subprocess.TimeoutExpired,
        When DroidDriver.execute is called,
        Then it returns DriverResult(aborted=True, abort_reason="wall_clock_exceeded")
        with a non-negative wall_clock_ms — and does NOT propagate the exception.

        AC-12 / C1: wall-clock budget exceeded must be caught and converted to a
        DriverResult; an uncaught TimeoutExpired breaks the type contract.
        """
        workspace = _make_workspace_with_entry_point(tmp_path)
        driver = DroidDriver()

        with patch(
            "subprocess.run",
            side_effect=subprocess.TimeoutExpired(cmd=["droid"], timeout=1800),
        ):
            result: DriverResult = driver.execute(
                workspace=workspace,
                task_manifest=_TASK_MANIFEST,
                seed=1,
                budget_usd=10.0,
                wall_clock_budget_seconds=1800,
                disable_prompt_cache=True,
            )

        assert result.aborted is True, "aborted must be True on TimeoutExpired"
        assert result.abort_reason == "wall_clock_exceeded", (
            f"abort_reason must be 'wall_clock_exceeded', got {result.abort_reason!r}"
        )
        assert isinstance(result.wall_clock_ms, int) and result.wall_clock_ms >= 0, (
            f"wall_clock_ms must be a non-negative int, got {result.wall_clock_ms!r}"
        )

    def test_file_not_found_returns_driver_error(self, tmp_path: Path) -> None:
        """
        Given subprocess.run raises FileNotFoundError (CLI not installed),
        When DroidDriver.execute is called,
        Then it returns DriverResult(aborted=True, abort_reason="driver_error")
        and does NOT propagate the exception.

        C1: A missing CLI binary must not crash the harness; it must produce
        an aborted DriverResult so the run can be recorded and skipped.
        """
        workspace = _make_workspace_with_entry_point(tmp_path)
        driver = DroidDriver()

        with patch(
            "subprocess.run",
            side_effect=FileNotFoundError("droid: command not found"),
        ):
            result: DriverResult = driver.execute(
                workspace=workspace,
                task_manifest=_TASK_MANIFEST,
                seed=1,
                budget_usd=10.0,
                wall_clock_budget_seconds=1800,
                disable_prompt_cache=True,
            )

        assert result.aborted is True, "aborted must be True when CLI binary not found"
        assert result.abort_reason == "driver_error", (
            f"abort_reason must be 'driver_error', got {result.abort_reason!r}"
        )


# ---------------------------------------------------------------------------
# R6-droid: cli_version populated from subprocess --version call
# ---------------------------------------------------------------------------

class TestDroidDriverCliVersion:
    """
    R6-droid: DroidDriver.execute() must populate driver_metadata["cli_version"]
    by calling 'droid --version' as a subprocess and capturing its stdout.

    The --version call is a separate subprocess invocation from the main
    'droid exec ...' call. The cli_version value must appear in the result's
    driver_metadata dict so it can be recorded in the benchmark run output.
    """

    def test_cli_version_populated_from_droid_version_subprocess(
        self, tmp_path: Path
    ) -> None:
        """
        Given subprocess.run is dispatched to handle both 'droid --version'
        and 'droid exec --auto low -o json -f <tempfile>',
        When DroidDriver.execute completes,
        Then result.driver_metadata["cli_version"] contains "0.104.0".

        R6-droid: cli_version must be scraped from 'droid --version' stdout,
        not hardcoded. The value "0.104.0" must appear in the metadata string
        (use 'in' to tolerate full version lines like "droid 0.104.0").
        """
        workspace = _make_workspace_with_entry_point(tmp_path)
        driver = DroidDriver()

        def _make_version_proc() -> MagicMock:
            proc = MagicMock(spec=subprocess.CompletedProcess)
            proc.returncode = 0
            proc.stdout = "droid 0.104.0\n"
            proc.stderr = ""
            return proc

        def _subprocess_dispatch(cmd, **kwargs):
            cmd_list = list(cmd)
            if len(cmd_list) >= 2 and cmd_list[:2] == ["droid", "--version"]:
                return _make_version_proc()
            # Fall through to the normal happy-path JSON result for 'droid exec ...'
            return _make_json_result(
                input_tokens=100,
                output_tokens=50,
                cost_usd=0.001,
            )

        with patch("subprocess.run", side_effect=_subprocess_dispatch):
            result = driver.execute(
                workspace=workspace,
                task_manifest=_TASK_MANIFEST,
                seed=1,
                budget_usd=10.0,
                wall_clock_budget_seconds=1800,
                disable_prompt_cache=True,
            )

        assert isinstance(result.driver_metadata, Mapping), (
            "driver_metadata must be a Mapping"
        )
        assert "cli_version" in result.driver_metadata, (
            f"driver_metadata must contain 'cli_version'; got keys: "
            f"{list(result.driver_metadata.keys())}"
        )
        cli_version = result.driver_metadata["cli_version"]
        assert "0.104.0" in str(cli_version), (
            f"cli_version must contain '0.104.0'; got {cli_version!r}"
        )


# ---------------------------------------------------------------------------
# C5 regression: non-zero returncode + non-JSON stdout must not be reported
# as a successful run (final-gate CRIT-1)
# ---------------------------------------------------------------------------

class TestDroidDriverReturncodeSafety:
    """
    C5 regression (final-gate CRIT-1): DroidDriver must treat non-zero returncode
    with non-JSON stdout as a driver_error, never as a successful run.

    A process that exits with SIGSEGV (139) and prints a crash message to stdout
    must produce DriverResult(aborted=True, abort_reason="driver_error").
    Likewise, a zero-returncode process that prints invalid JSON must also abort
    because the result cannot be validated.
    """

    def test_nonzero_returncode_with_non_json_stdout_returns_driver_error(
        self, tmp_path: Path
    ) -> None:
        """
        Regression for final-gate CRIT-1: non-JSON stdout + non-zero returncode
        must NOT be reported as successful run.

        Given subprocess.run returns returncode=139 (SIGSEGV) with non-JSON stdout,
        When DroidDriver().execute() is called,
        Then result.aborted is True and result.abort_reason == 'driver_error'.
        """
        workspace = _make_workspace_with_entry_point(tmp_path)

        def _subprocess_dispatch(cmd, **kwargs):
            cmd_list = list(cmd)
            if len(cmd_list) >= 2 and cmd_list[:2] == ["droid", "--version"]:
                proc = MagicMock(spec=subprocess.CompletedProcess)
                proc.returncode = 0
                proc.stdout = "droid 0.104.0\n"
                proc.stderr = ""
                return proc
            # droid exec → SIGSEGV crash, non-JSON stdout
            proc = MagicMock(spec=subprocess.CompletedProcess)
            proc.returncode = 139
            proc.stdout = "segmentation fault (core dumped)\n"
            proc.stderr = ""
            return proc

        with patch("subprocess.run", side_effect=_subprocess_dispatch):
            result = DroidDriver().execute(
                workspace=workspace,
                task_manifest=_TASK_MANIFEST,
                seed=1,
                budget_usd=10.0,
                wall_clock_budget_seconds=1800,
                disable_prompt_cache=True,
            )

        assert result.aborted is True, (
            "CRIT-1: non-JSON stdout + returncode=139 must set aborted=True"
        )
        assert result.abort_reason == "driver_error", (
            f"CRIT-1: abort_reason must be 'driver_error', got {result.abort_reason!r}"
        )

    def test_zero_returncode_with_malformed_json_stdout_returns_driver_error(
        self, tmp_path: Path
    ) -> None:
        """
        Regression for final-gate CRIT-1: returncode=0 with non-JSON stdout must
        also produce a driver_error — a malformed result cannot be validated.

        Given subprocess.run returns returncode=0 with non-JSON stdout,
        When DroidDriver().execute() is called,
        Then result.aborted is True and result.abort_reason == 'driver_error'.
        """
        workspace = _make_workspace_with_entry_point(tmp_path)

        def _subprocess_dispatch(cmd, **kwargs):
            cmd_list = list(cmd)
            if len(cmd_list) >= 2 and cmd_list[:2] == ["droid", "--version"]:
                proc = MagicMock(spec=subprocess.CompletedProcess)
                proc.returncode = 0
                proc.stdout = "droid 0.104.0\n"
                proc.stderr = ""
                return proc
            # droid exec → zero exit but completely invalid JSON (json.loads will fail)
            proc = MagicMock(spec=subprocess.CompletedProcess)
            proc.returncode = 0
            proc.stdout = "this is not json"
            proc.stderr = ""
            return proc

        with patch("subprocess.run", side_effect=_subprocess_dispatch):
            result = DroidDriver().execute(
                workspace=workspace,
                task_manifest=_TASK_MANIFEST,
                seed=1,
                budget_usd=10.0,
                wall_clock_budget_seconds=1800,
                disable_prompt_cache=True,
            )

        assert result.aborted is True, (
            "CRIT-1: returncode=0 with malformed JSON stdout must set aborted=True"
        )
        assert result.abort_reason == "driver_error", (
            f"CRIT-1: abort_reason must be 'driver_error' for malformed JSON; "
            f"got {result.abort_reason!r}"
        )


# ---------------------------------------------------------------------------
# C6 regression: cli_version must be sentinel "unknown" on probe failure,
# not empty string (final-gate CRIT-3 + MED-1)
# ---------------------------------------------------------------------------

class TestDroidDriverCliVersionFallback:
    """
    C6 regression (final-gate CRIT-3): When the 'droid --version' probe fails
    (FileNotFoundError, TimeoutExpired, or any exception), cli_version must be
    set to the sentinel string "unknown" — NOT empty string.

    Empty string corrupts downstream analytics that key on this field.
    """

    def test_cli_version_is_unknown_not_empty_when_droid_not_installed(
        self, tmp_path: Path
    ) -> None:
        """
        Regression for final-gate CRIT-3: missing droid binary must yield
        cli_version='unknown' sentinel, not empty string — empty string corrupts
        downstream analytics.

        Given subprocess.run raises FileNotFoundError for 'droid --version'
          but returns a happy-path JSON result for 'droid exec ...',
        When DroidDriver() is constructed and execute() is called,
        Then DroidDriver() must NOT raise, and
          result.driver_metadata["cli_version"] == "unknown".
        """
        workspace = _make_workspace_with_entry_point(tmp_path)

        def _subprocess_dispatch(cmd, **kwargs):
            cmd_list = list(cmd)
            if len(cmd_list) >= 2 and cmd_list[:2] == ["droid", "--version"]:
                raise FileNotFoundError("No such file or directory: 'droid'")
            return _make_json_result(input_tokens=100, output_tokens=50, cost_usd=0.001)

        with patch("subprocess.run", side_effect=_subprocess_dispatch):
            # Must not raise — graceful degrade
            driver = DroidDriver()
            result = driver.execute(
                workspace=workspace,
                task_manifest=_TASK_MANIFEST,
                seed=1,
                budget_usd=10.0,
                wall_clock_budget_seconds=1800,
                disable_prompt_cache=True,
            )

        assert isinstance(result.driver_metadata, Mapping)
        assert "cli_version" in result.driver_metadata, (
            f"driver_metadata must contain 'cli_version'; got keys: "
            f"{list(result.driver_metadata.keys())}"
        )
        cli_version = result.driver_metadata["cli_version"]
        assert cli_version == "unknown", (
            f"CRIT-3: cli_version must be 'unknown' when droid binary is missing, "
            f"got {cli_version!r} — empty string corrupts downstream analytics"
        )

    def test_cli_version_probe_respects_timeout(self, tmp_path: Path) -> None:
        """
        Regression for final-gate CRIT-3 / MED-1: version-probe subprocess must
        be bounded (timeout=5); on timeout, cli_version degrades to 'unknown'.

        Given subprocess.run raises TimeoutExpired for 'droid --version'
          but returns a happy-path JSON result for 'droid exec ...',
        When DroidDriver() is constructed and execute() is called,
        Then result.driver_metadata["cli_version"] == "unknown".
        """
        workspace = _make_workspace_with_entry_point(tmp_path)

        def _subprocess_dispatch(cmd, **kwargs):
            cmd_list = list(cmd)
            if len(cmd_list) >= 2 and cmd_list[:2] == ["droid", "--version"]:
                raise subprocess.TimeoutExpired(cmd=["droid", "--version"], timeout=5)
            return _make_json_result(input_tokens=100, output_tokens=50, cost_usd=0.001)

        with patch("subprocess.run", side_effect=_subprocess_dispatch):
            driver = DroidDriver()
            result = driver.execute(
                workspace=workspace,
                task_manifest=_TASK_MANIFEST,
                seed=1,
                budget_usd=10.0,
                wall_clock_budget_seconds=1800,
                disable_prompt_cache=True,
            )

        assert isinstance(result.driver_metadata, Mapping)
        assert "cli_version" in result.driver_metadata, (
            f"driver_metadata must contain 'cli_version'; got keys: "
            f"{list(result.driver_metadata.keys())}"
        )
        cli_version = result.driver_metadata["cli_version"]
        assert cli_version == "unknown", (
            f"CRIT-3 / MED-1: cli_version must be 'unknown' on version-probe timeout, "
            f"got {cli_version!r}"
        )
