"""
tests/drivers/test_claude_code_session_isolation.py — Phase 5e RED tests.

Covers AC-17: Fresh ClaudeSDKClient per task — no cross-task context contamination.

From the spec (AC-17):
    'the SDK invocation uses a freshly-instantiated client (no session_id reuse,
    no shared ClaudeSDKClient across tasks); test asserts that introspectable
    client-internal state from task A's run is not visible to task B.'

Defends against SDK Issue #560: session leakage across context boundaries.

Strategy: mock the SDK client constructor at the import boundary and record
id() or call count of each client instantiated, then assert two execute() calls
create two distinct objects.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any
from unittest.mock import MagicMock, patch, call

import pytest

from drivers.claude_code import ClaudeCodeDriver
from drivers._protocol import DriverResult


# ---------------------------------------------------------------------------
# Shared fixtures
# ---------------------------------------------------------------------------

def _make_usage_dict(
    input_tokens: int = 150,
    output_tokens: int = 75,
    cache_read_input_tokens: int = 0,
) -> dict[str, Any]:
    return {
        "input_tokens": input_tokens,
        "output_tokens": output_tokens,
        "cache_read_input_tokens": cache_read_input_tokens,
    }


def _make_sdk_result(task_label: str = "task_A") -> MagicMock:
    """Return a mock ResultMessage representing a completed task."""
    result = MagicMock()
    result.total_cost_usd = 0.005
    result.usage = _make_usage_dict()
    result.is_error = False
    result.result = f"Completed {task_label} successfully."
    return result


_TASK_A_MANIFEST: dict = {
    "task_id": "url_shortener",
    "entry_point": "shortener.py",
    "test_command": "pytest",
    "language": "python",
}

_TASK_B_MANIFEST: dict = {
    "task_id": "rate_limiter",
    "entry_point": "rate_limiter.py",
    "test_command": "pytest",
    "language": "python",
}


# ---------------------------------------------------------------------------
# AC-17: Fresh SDK client per task
# ---------------------------------------------------------------------------

class TestAC17FreshClientPerTask:
    """
    AC-17: Two consecutive execute() calls on the same Driver instance must
    each instantiate a fresh SDK client — no reuse across tasks.
    """

    def test_AC17_two_execute_calls_create_two_clients(self, tmp_path: Path) -> None:
        """
        Given a ClaudeCodeDriver instance,
        When execute() is called twice (task A then task B),
        Then two distinct SDK client instances are created (separate id()s).

        AC-17: 'freshly-instantiated client ... never reuse across tasks (SDK Issue #560)'.

        Strategy: patch ClaudeSDKClient constructor; record id() of each created instance.
        """
        # Arrange
        driver = ClaudeCodeDriver()
        client_ids: list[int] = []

        class TrackingClient:
            def __init__(self, *args: Any, **kwargs: Any) -> None:
                client_ids.append(id(self))

        # Act — two runs; each must create a NEW client
        with patch("drivers.claude_code.run_agent_sdk",
                   side_effect=[_make_sdk_result("task_A"), _make_sdk_result("task_B")]), \
             patch("drivers.claude_code.ClaudeSDKClient", side_effect=TrackingClient):
            driver.execute(
                workspace=tmp_path,
                task_manifest=_TASK_A_MANIFEST,
                seed=1,
                budget_usd=2.0,
                wall_clock_budget_seconds=180,
                cache_strategy="salted",
            )
            driver.execute(
                workspace=tmp_path,
                task_manifest=_TASK_B_MANIFEST,
                seed=2,
                budget_usd=2.0,
                wall_clock_budget_seconds=180,
                cache_strategy="salted",
            )

        # Assert — two distinct client instances created
        assert len(client_ids) >= 2, (
            f"AC-17: expected at least 2 client instantiations, got {len(client_ids)}"
        )
        assert client_ids[0] != client_ids[1], (
            "AC-17: first and second execute() calls must create distinct SDK client "
            "instances (different id()s); got same id — client is being reused across tasks"
        )

    def test_AC17_task_b_prompt_does_not_contain_task_a_name(
        self, tmp_path: Path
    ) -> None:
        """
        Given task A has task_id='url_shortener' and task B has task_id='rate_limiter',
        When task B is executed after task A,
        Then the system prompt passed to the SDK for task B does NOT contain 'url_shortener'.

        AC-17: 'system prompt sent to task B does not contain task A's task name,
        prompt content, or tool-call history.'
        """
        # Arrange
        driver = ClaudeCodeDriver()
        sdk_results = [_make_sdk_result("task_A"), _make_sdk_result("task_B")]
        task_b_system_prompts: list[str] = []

        call_index = {"n": 0}

        def capture_on_second_call(**kwargs: Any) -> MagicMock:
            idx = call_index["n"]
            call_index["n"] += 1
            if idx == 1:  # second call = task B
                sys_prompt = kwargs.get("system_prompt") or kwargs.get("system") or ""
                task_b_system_prompts.append(str(sys_prompt))
            return sdk_results[idx]

        # Act
        with patch("drivers.claude_code.run_agent_sdk", side_effect=capture_on_second_call):
            driver.execute(
                workspace=tmp_path,
                task_manifest=_TASK_A_MANIFEST,
                seed=1,
                budget_usd=2.0,
                wall_clock_budget_seconds=180,
                cache_strategy="salted",
            )
            driver.execute(
                workspace=tmp_path,
                task_manifest=_TASK_B_MANIFEST,
                seed=2,
                budget_usd=2.0,
                wall_clock_budget_seconds=180,
                cache_strategy="salted",
            )

        # Assert — task B's system prompt must not leak task A's task identity
        for prompt in task_b_system_prompts:
            assert "url_shortener" not in prompt, (
                "AC-17: task B's system prompt must NOT contain task A's task_id "
                f"'url_shortener'. Got prompt: {prompt[:300]!r}"
            )

    def test_AC17_run_agent_sdk_called_once_per_execute(self, tmp_path: Path) -> None:
        """
        Given two separate execute() calls on the same driver instance,
        When both calls complete,
        Then run_agent_sdk was called exactly twice (once per task).

        This confirms each task triggers a fresh invocation, not a cached/reused result.
        """
        # Arrange
        driver = ClaudeCodeDriver()

        # Act
        with patch("drivers.claude_code.run_agent_sdk",
                   side_effect=[_make_sdk_result("A"), _make_sdk_result("B")]) as mock_sdk:
            driver.execute(
                workspace=tmp_path,
                task_manifest=_TASK_A_MANIFEST,
                seed=1,
                budget_usd=2.0,
                wall_clock_budget_seconds=180,
                cache_strategy="salted",
            )
            driver.execute(
                workspace=tmp_path,
                task_manifest=_TASK_B_MANIFEST,
                seed=2,
                budget_usd=2.0,
                wall_clock_budget_seconds=180,
                cache_strategy="salted",
            )

        # Assert
        assert mock_sdk.call_count == 2, (
            f"AC-17: run_agent_sdk must be called exactly once per execute(); "
            f"got {mock_sdk.call_count} calls"
        )
