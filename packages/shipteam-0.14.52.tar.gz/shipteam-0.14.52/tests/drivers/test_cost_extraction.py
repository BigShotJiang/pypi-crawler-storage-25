"""
Tests for drivers/_cost_extraction.py — T-9, T-10, T-36b (Phase 2 Part 1 / 5c RED).

Covers:
  T-9:  extract_aider_cost with real-capture fixtures (verified stable format since
        v0.52+); exact-value assertions, not isinstance(float) checks.
  T-10: extract_aider_cost on malformed / empty stdout returns (None, None, None);
        never raises AttributeError or ValueError.
  T-36b: extract_droid_json_cost on single-object JSON fixtures for usage sub-object,
         top-level fields, and missing fields.

Changes from 5b → 5c (R2):
  - DELETED: TestExtractAiderCostFormats — 3 separate classes for v0.61/v0.64/v0.83 pins.
    Those pins were speculative. Aider format has been stable since v0.52+.
  - ADDED: TestExtractAiderCost — single class with real-capture fixture from
    github.com/aider-ai/aider/issues/4438, exact-value assertions, two-line variant,
    and tokens-stay-None contract.

Aider real-capture format (stable since v0.52+, verified via issue #4438):
  Single-line:
    Tokens: 9.7k sent, 263 received. Cost: $0.01 message, $0.01 session.
  Two-line (cache_hit_tokens AND cache_write_tokens both truthy):
    Same fields, newline between Tokens... and Cost: $M message, $S session.
  Minimal (older / no session):
    Cost: $0.05 message

Interface Contract (unchanged):
  def extract_aider_cost(stdout: str) -> tuple[int | None, int | None, float | None]:
      ...
  def extract_droid_json_cost(result_obj: dict) -> tuple[int | None, int | None, float | None]:
      ...
  Both return (input_tokens_or_None, output_tokens_or_None, cost_usd_or_None).
  Aider does not natively emit token counts; input_tokens/output_tokens ALWAYS return None.

Regression-guards:
  RG-1 (Aider stdout format drift, pitfall #2): real-capture fixture from issue #4438
       must parse correctly; two-line variant must also parse.
"""

import pytest

from drivers._cost_extraction import extract_aider_cost, extract_droid_json_cost


# ---------------------------------------------------------------------------
# T-9: extract_aider_cost — real-capture fixtures, exact-value assertions (R2)
# ---------------------------------------------------------------------------

class TestExtractAiderCost:
    """
    T-9: extract_aider_cost — AC-7 cost extraction using real-capture fixtures.

    Aider stdout format has been stable since v0.52+. The format variants pinned
    to v0.61/v0.64/v0.83 were speculative; this class uses the verified real-capture
    fixture from github.com/aider-ai/aider/issues/4438 and the two-line cache variant.

    Aider does NOT natively emit token counts in non-interactive stdout mode.
    input_tokens and output_tokens MUST always be None; cost_usd must be parsed.
    """

    def test_single_line_real_capture_exact_values(self) -> None:
        """
        Given real-capture Aider stdout from github.com/aider-ai/aider/issues/4438:
          'Tokens: 9.7k sent, 263 received. Cost: $0.01 message, $0.01 session.'
        When extract_aider_cost is called,
        Then cost_usd == 0.01 exactly (not isinstance(float) check),
        and input_tokens, output_tokens are None.

        T-9 / RG-1: Real capture from Aider issue #4438 — the canonical regression fixture.
        """
        # Arrange — verbatim from issue #4438
        stdout = (
            "Tokens: 9.7k sent, 263 received. Cost: $0.01 message, $0.01 session.\n"
        )

        # Act
        input_tokens, output_tokens, cost_usd = extract_aider_cost(stdout)

        # Assert — exact value, not isinstance
        assert input_tokens is None, "Aider never provides input_tokens natively"
        assert output_tokens is None, "Aider never provides output_tokens natively"
        assert cost_usd == 0.01, (
            f"Real-capture fixture: expected cost_usd == 0.01 exactly, got {cost_usd!r}"
        )

    def test_message_only_no_session(self) -> None:
        """
        Given older minimal Aider stdout: 'Cost: $0.05 message' (no session total),
        When extract_aider_cost is called,
        Then cost_usd == 0.05 (parsed from message cost), tokens are None.

        T-9: Older / simpler output form — message cost only, no session accumulator.
        """
        # Arrange
        stdout = "Cost: $0.05 message\n"

        # Act
        input_tokens, output_tokens, cost_usd = extract_aider_cost(stdout)

        # Assert
        assert input_tokens is None
        assert output_tokens is None
        assert cost_usd == 0.05, (
            f"Message-only form: expected cost_usd == 0.05, got {cost_usd!r}"
        )

    def test_two_line_with_cache_tokens(self) -> None:
        """
        Given two-line Aider stdout (emitted when cache_hit_tokens AND cache_write_tokens
        are both truthy), with a newline between the Tokens line and the Cost line:
          'Tokens: 9.7k sent, 263 received, 1.2k cache write, 500 cache hit.\\nCost: $0.01 message, $0.01 session.'
        When extract_aider_cost is called,
        Then cost_usd is extracted (non-None) and tokens remain None.

        T-9 / RG-1: Two-line variant — newline separator between Tokens... and Cost:.
        """
        # Arrange — two-line format (cache tokens present → newline separator)
        stdout = (
            "Aider v0.86.0\n"
            "Tokens: 9.7k sent, 263 received, 1.2k cache write, 500 cache hit.\n"
            "Cost: $0.01 message, $0.01 session.\n"
        )

        # Act
        input_tokens, output_tokens, cost_usd = extract_aider_cost(stdout)

        # Assert
        assert input_tokens is None, "Two-line format: input_tokens must still be None"
        assert output_tokens is None, "Two-line format: output_tokens must still be None"
        assert cost_usd is not None, (
            "Two-line format: cost_usd must be extracted from 'Cost:' line"
        )

    def test_malformed_stdout_returns_none(self) -> None:
        """
        Given malformed stdout (empty string, garbage, no Cost: line),
        When extract_aider_cost is called,
        Then (None, None, None) is returned and no exception is raised.

        T-10 / RG-1: Parser must never raise, even on adversarial input.
        """
        for bad_input in ["", "\x00\xff\nCost$$$\n###\n", "random garbage\nno cost here\n"]:
            result = extract_aider_cost(bad_input)
            assert result == (None, None, None), (
                f"Malformed input {bad_input!r}: expected (None, None, None), got {result}"
            )

    def test_aider_tokens_are_not_extracted(self) -> None:
        """
        Given Aider stdout containing 'Tokens: X sent, Y received' on the same line as
        'Cost: $M message, $S session',
        When extract_aider_cost is called,
        Then input_tokens and output_tokens are BOTH None — not parsed from the Tokens line.

        Driver docstring explicitly states tokens not supported for Aider.
        cost_source='scraped' means only cost_usd is meaningful; token fields stay None.

        T-9: Confirms the tokens-not-extracted contract explicitly.
        """
        # Arrange — real-capture format; Tokens: line IS present
        stdout = "Tokens: 9.7k sent, 263 received. Cost: $0.01 message, $0.01 session.\n"

        # Act
        input_tokens, output_tokens, cost_usd = extract_aider_cost(stdout)

        # Assert — token fields are intentionally NOT parsed
        assert input_tokens is None, (
            "extract_aider_cost must return input_tokens=None even when "
            "'Tokens: X sent' is present in stdout — tokens not supported for Aider"
        )
        assert output_tokens is None, (
            "extract_aider_cost must return output_tokens=None even when "
            "'Y received' is present in stdout — tokens not supported for Aider"
        )
        # cost_usd IS expected to be parsed
        assert cost_usd is not None, "cost_usd must still be extracted from the Cost: line"


# ---------------------------------------------------------------------------
# T-10: extract_aider_cost — malformed / empty / no-cost stdout (Regression-guard RG-1)
# ---------------------------------------------------------------------------

class TestExtractAiderCostMalformed:
    """
    T-10: extract_aider_cost graceful fallback — never raises, returns (None, None, None).

    AC-7: cost extraction must be resilient; a parser error must NOT surface as
    an unhandled exception that aborts the run.
    """

    def test_empty_string_returns_all_none(self) -> None:
        """
        Given an empty stdout string,
        When extract_aider_cost is called,
        Then (None, None, None) is returned and no exception is raised.
        """
        result = extract_aider_cost("")
        assert result == (None, None, None), f"Expected (None, None, None), got {result}"

    def test_no_cost_line_returns_all_none(self) -> None:
        """
        Given Aider stdout that contains no 'Cost:' line,
        When extract_aider_cost is called,
        Then (None, None, None) is returned without raising.
        """
        stdout = (
            "Aider v0.99.0\n"
            "No files changed.\n"
            "Repo map: 0 tokens\n"
        )
        result = extract_aider_cost(stdout)
        assert result == (None, None, None)

    def test_malformed_cost_line_returns_all_none(self) -> None:
        """
        Given Aider stdout with a malformed 'Cost:' line (no dollar sign),
        When extract_aider_cost is called,
        Then (None, None, None) is returned without raising ValueError.
        """
        stdout = "Cost: not a number at all\n"
        # Must not raise
        result = extract_aider_cost(stdout)
        assert result == (None, None, None)

    def test_partial_cost_line_does_not_raise(self) -> None:
        """
        Given Aider stdout with 'Cost: $' (truncated line, no number),
        When extract_aider_cost is called,
        Then no exception is raised.
        """
        stdout = "Cost: $\n"
        # Must not raise AttributeError or ValueError
        result = extract_aider_cost(stdout)
        assert isinstance(result, tuple) and len(result) == 3

    def test_none_tokens_in_returned_tuple(self) -> None:
        """
        Given any Aider stdout (even one with a parseable cost),
        When extract_aider_cost is called,
        Then the first two elements (input_tokens, output_tokens) are always None.

        Aider's non-interactive mode does not emit reliable per-turn token counts.
        """
        stdout = "Cost: $0.0050 message\n"
        input_tokens, output_tokens, _ = extract_aider_cost(stdout)
        assert input_tokens is None, "Aider never provides input_tokens natively"
        assert output_tokens is None, "Aider never provides output_tokens natively"

    def test_random_garbage_does_not_raise(self) -> None:
        """
        Given Aider stdout containing random garbage / binary-like characters,
        When extract_aider_cost is called,
        Then no exception is raised and (None, None, None) is returned.
        """
        stdout = "\x00\xff\nCost$$$\n###\n"
        result = extract_aider_cost(stdout)
        assert isinstance(result, tuple) and len(result) == 3


# ---------------------------------------------------------------------------
# T-36b: extract_droid_json_cost — usage sub-object shape (PRIMARY assumed shape)
# ---------------------------------------------------------------------------
#
# Phase 2 Part 1 assumption: Factory Droid '-o json' returns cost/tokens under a
# 'usage' sub-object following Anthropic SDK convention:
#   {"usage": {"input_tokens": N, "output_tokens": N, "cost_usd": F}}
#
# This is the expected survivor after empirical capture in Phase 2 Part 2.
# If the shape differs, these tests will still be RED until the implementation
# conforms to this contract (or the contract is updated via a new RED phase).

class TestExtractDroidJsonCostWithUsageSubobject:
    """
    T-36b: extract_droid_json_cost — Anthropic-style usage sub-object shape.

    Assumes Factory Droid '-o json' output structure (to be verified):
      {
        "type": "result",
        "is_error": false,
        "result": "...",
        "usage": {
          "input_tokens": 1500,
          "output_tokens": 400,
          "cost_usd": 0.0095
        }
      }

    Phase 2 Part 1 assumption — will be verified by empirical capture in
    Phase 2 Part 2. If the shape differs, update test fixtures + implementation
    together in a new RED→GREEN→REFACTOR cycle.
    """

    def test_full_usage_subobject_returns_all_three_fields(self) -> None:
        """
        Given a result_obj with usage.input_tokens, usage.output_tokens, usage.cost_usd,
        When extract_droid_json_cost is called,
        Then returns (1500, 400, 0.0095).
        """
        result_obj = {
            "type": "result",
            "subtype": "success",
            "is_error": False,
            "duration_ms": 9000,
            "num_turns": 3,
            "result": "Done.",
            "session_id": "sess-abc123",
            "usage": {
                "input_tokens": 1500,
                "output_tokens": 400,
                "cost_usd": 0.0095,
            },
        }

        input_tokens, output_tokens, cost_usd = extract_droid_json_cost(result_obj)

        assert input_tokens == 1500, f"Expected 1500, got {input_tokens}"
        assert output_tokens == 400, f"Expected 400, got {output_tokens}"
        assert cost_usd is not None and abs(cost_usd - 0.0095) < 1e-9, (
            f"Expected 0.0095, got {cost_usd}"
        )

    def test_usage_subobject_partial_fields_returns_present_and_none(self) -> None:
        """
        Given a result_obj where usage has input_tokens but no cost_usd,
        When extract_droid_json_cost is called,
        Then input_tokens is populated, cost_usd is None.
        """
        result_obj = {
            "is_error": False,
            "result": "Done.",
            "usage": {
                "input_tokens": 2000,
                "output_tokens": 600,
                # cost_usd absent
            },
        }

        input_tokens, output_tokens, cost_usd = extract_droid_json_cost(result_obj)

        assert input_tokens == 2000
        assert output_tokens == 600
        assert cost_usd is None, f"cost_usd must be None when absent, got {cost_usd}"

    def test_usage_subobject_empty_dict_returns_all_none(self) -> None:
        """
        Given a result_obj with an empty usage sub-object,
        When extract_droid_json_cost is called,
        Then (None, None, None) is returned.
        """
        result_obj = {
            "is_error": False,
            "result": "Done.",
            "usage": {},
        }

        result = extract_droid_json_cost(result_obj)

        assert result == (None, None, None), f"Empty usage: expected (None, None, None), got {result}"

    def test_input_tokens_is_int(self) -> None:
        """
        Given usage.input_tokens is present,
        When extract_droid_json_cost is called,
        Then input_tokens is an int, not a string or float.
        """
        result_obj = {"usage": {"input_tokens": 100, "output_tokens": 50, "cost_usd": 0.001}}
        input_tokens, _, _ = extract_droid_json_cost(result_obj)
        assert isinstance(input_tokens, int), f"input_tokens must be int, got {type(input_tokens)}"

    def test_cost_usd_is_float(self) -> None:
        """
        Given usage.cost_usd is present as a float,
        When extract_droid_json_cost is called,
        Then cost_usd is a float.
        """
        result_obj = {"usage": {"input_tokens": 100, "output_tokens": 50, "cost_usd": 0.0042}}
        _, _, cost_usd = extract_droid_json_cost(result_obj)
        assert isinstance(cost_usd, float), f"cost_usd must be float, got {type(cost_usd)}"

    def test_result_tuple_has_three_elements(self) -> None:
        """
        Given any result_obj,
        When extract_droid_json_cost is called,
        Then the return value is always a 3-tuple.
        """
        result_obj = {"usage": {"input_tokens": 10, "output_tokens": 5, "cost_usd": 0.001}}
        result = extract_droid_json_cost(result_obj)
        assert len(result) == 3, f"Must return 3-tuple, got {len(result)}-tuple"


# ---------------------------------------------------------------------------
# T-36b: extract_droid_json_cost — missing / absent cost fields (Case C)
# ---------------------------------------------------------------------------

class TestExtractDroidJsonCostMissing:
    """
    T-36b: extract_droid_json_cost graceful fallback when cost fields are absent.

    AC-7: The scraping shim must never propagate a KeyError or AttributeError.
    Case C: fields absent entirely → return (None, None, None).
    """

    def test_no_usage_key_returns_all_none(self) -> None:
        """
        Given a result_obj with no 'usage' key,
        When extract_droid_json_cost is called,
        Then (None, None, None) is returned without raising KeyError.
        """
        result_obj = {
            "type": "result",
            "is_error": False,
            "result": "Done.",
        }

        result = extract_droid_json_cost(result_obj)

        assert result == (None, None, None), (
            f"No usage key: expected (None, None, None), got {result}"
        )

    def test_empty_dict_returns_all_none(self) -> None:
        """
        Given an empty result_obj dict,
        When extract_droid_json_cost is called,
        Then (None, None, None) is returned without raising.
        """
        result = extract_droid_json_cost({})

        assert result == (None, None, None), f"Empty dict: expected (None, None, None), got {result}"

    def test_does_not_raise_on_missing_usage(self) -> None:
        """
        Given a result_obj without any cost/token keys,
        When extract_droid_json_cost is called,
        Then no KeyError is raised.
        """
        result_obj = {"type": "result", "subtype": "success", "is_error": False}
        # Must not raise KeyError
        result = extract_droid_json_cost(result_obj)
        assert isinstance(result, tuple) and len(result) == 3

    def test_does_not_raise_on_non_dict_usage(self) -> None:
        """
        Given a result_obj where 'usage' is not a dict (unexpected shape),
        When extract_droid_json_cost is called,
        Then no AttributeError or TypeError is raised.
        """
        result_obj = {"usage": "not_a_dict"}
        # Must not raise
        result = extract_droid_json_cost(result_obj)
        assert isinstance(result, tuple) and len(result) == 3

    def test_none_input_returns_all_none_or_does_not_raise(self) -> None:
        """
        Given extract_droid_json_cost is called defensively with malformed input,
        When the function is called,
        Then it returns (None, None, None) without raising any exception.

        This guards against the harness accidentally passing a non-dict.
        """
        # Must not raise — graceful degradation
        try:
            result = extract_droid_json_cost({})  # minimal safe call
            assert isinstance(result, tuple) and len(result) == 3
        except Exception as exc:
            pytest.fail(f"extract_droid_json_cost raised on empty dict: {exc}")
