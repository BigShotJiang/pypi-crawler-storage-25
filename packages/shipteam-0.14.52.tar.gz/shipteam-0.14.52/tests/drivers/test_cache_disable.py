"""
Tests for AC-14 cache-disable enforcement — T-31, T-32, T-33 (Phase 1).

Covers:
  T-31: With disable_prompt_cache=True, no cache_control key appears in any
        API request message or tool definition constructed by the claude_code driver.
  T-32: DriverResult.driver_metadata.cache_strategy is "omitted" or "salted"
        when disable_prompt_cache=True.
  T-33: A result row where cache_read_input_tokens > 0 is rejected by the
        aggregator as evidence of prompt-cache contamination.

Interface Contract (AC-14):
  'either cache_control is explicitly omitted from every message AND every
  tool definition, OR each request injects a per-seed salt into the system-prompt
  prefix to guarantee cache miss. The driver records in
  driver_metadata.cache_strategy ∈ {"omitted", "salted"}; any run where
  cache_read_input_tokens > 0 is rejected by the aggregator as evidence of
  contamination.'

Oracle strategy (from .test-matrix.md AC-14 oracle):
  - Request-inspection oracle (T-31): intercept API requests; assert cache_control
    absent from every messages[] entry and every tool definition.
  - cache_strategy recorded oracle (T-32): DriverResult.driver_metadata.cache_strategy
    must be "omitted" or "salted" — never absent or None.
  - Contamination-detection oracle (T-33): feed a row with
    cache_read_input_tokens > 0 into the aggregator; assert rejection with a
    reason string containing "cache".
"""
import pytest

pytest.skip(
    "Phase 5e: cache_strategy contract narrowed from {'omitted','salted'} to "
    "{'salted','native'}. The disable_prompt_cache=True API is removed; "
    "claude_code now ALWAYS injects per-seed salt. AC-14 cache-leak detection "
    "is exercised by tests/drivers/test_claude_code_real.py "
    "(TestSaltedSystemPrompt, TestCacheStrategyPropagation, "
    "TestCacheReadInputTokensFailClosed). Aggregator-side rejection is moved "
    "to tests/aggregation/test_results.py. This module is preserved as a "
    "record of the removed contract.",
    allow_module_level=True,
)

from pathlib import Path
from typing import Any
from unittest.mock import MagicMock, patch, call

from drivers.claude_code import ClaudeCodeDriver
from drivers._protocol import DriverResult
from aggregation.results import (
    append_result_row,
    SchemaViolationError,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_sdk_usage(
    input_tokens: int = 150,
    output_tokens: int = 75,
    cache_read_input_tokens: int = 0,
) -> MagicMock:
    usage = MagicMock()
    usage.input_tokens = input_tokens
    usage.output_tokens = output_tokens
    usage.cache_read_input_tokens = cache_read_input_tokens
    return usage


def _make_sdk_result(
    total_cost_usd: float = 0.0042,
    usage: MagicMock | None = None,
) -> MagicMock:
    result = MagicMock()
    result.total_cost_usd = total_cost_usd
    result.usage = usage or _make_sdk_usage()
    result.is_error = False
    return result


def _valid_row_dict(**overrides: Any) -> dict:
    """Return a fully valid result row dict for aggregator tests."""
    base: dict[str, Any] = {
        "driver": "claude_code",
        "driver_version": "0.1.15",
        "task": "url_shortener",
        "task_pack_revision": "abc1234def5678",
        "seed": 1,
        "container_digest": "sha256:deadbeef" + "0" * 56,
        "harness_version": "0.1.0",
        "sdk_version": "0.1.15",
        "sdk_release_date": "2024-09-01",
        "timestamp_utc": "2024-09-15T12:00:00Z",
        "wall_clock_ms": 45000,
        "input_tokens": 500,
        "output_tokens": 250,
        "cost_usd": 0.0075,
        "cost_source": "native",
        "acceptance_pct": 0.8,
        "mutation_score": {"python": {"killed": 8, "survived": 2, "timeout": 0, "score": 0.8}},
        "semgrep_high": 0,
        "semgrep_critical": 0,
        "injected_bug_detections": 3,
        "aborted": False,
        "abort_reason": None,
        "rate_limited_during_run": False,
        "cache_strategy": "omitted",
        "driver_metadata": {
            "cache_strategy": "omitted",
            "cache_read_input_tokens": 0,
        },
    }
    base.update(overrides)
    return base


# ---------------------------------------------------------------------------
# T-31: cache_control absent from all API request messages and tool definitions
# ---------------------------------------------------------------------------

class TestCacheControlAbsent:
    """
    T-31: With disable_prompt_cache=True, no cache_control key appears in
    any API request message or tool definition.

    AC-14: 'cache_control is explicitly omitted from every message AND
    every tool definition.'
    """

    def test_no_cache_control_in_any_message(self, tmp_path: Path) -> None:
        """
        Given disable_prompt_cache=True,
        When ClaudeCodeDriver.execute constructs API request messages,
        Then no message dict in the constructed request contains 'cache_control'.
        """
        # Arrange
        driver = ClaudeCodeDriver()
        sdk_result = _make_sdk_result()
        captured_requests: list[dict] = []

        def capture_sdk_call(**kwargs: Any) -> MagicMock:
            # Capture any messages passed to the SDK so we can inspect them
            if "messages" in kwargs:
                captured_requests.extend(kwargs["messages"])
            return sdk_result

        # Act
        with patch("drivers.claude_code.run_agent_sdk", side_effect=capture_sdk_call):
            result: DriverResult = driver.execute(
                workspace=tmp_path,
                task_manifest={"task_id": "url_shortener", "entry_point": "./README.md"},
                seed=1,
                budget_usd=10.0,
                wall_clock_budget_seconds=1800,
                disable_prompt_cache=True,
            )

        # Assert — no cache_control in any message
        for i, msg in enumerate(captured_requests):
            assert "cache_control" not in msg, (
                f"Message {i} must not contain 'cache_control' when "
                f"disable_prompt_cache=True; got: {msg}"
            )

    def test_no_cache_control_in_system_prompt(self, tmp_path: Path) -> None:
        """
        Given disable_prompt_cache=True,
        When the driver constructs the system prompt passed to the SDK,
        Then the system prompt string or object does NOT include a cache_control
        key at the content-block level.

        This is the "either omit OR salt" AC-14 compliance check for the
        alternative salted path: a salted system prompt is a plain string, not
        an object with cache_control.
        """
        # Arrange
        driver = ClaudeCodeDriver()
        sdk_result = _make_sdk_result()
        captured_system: list[Any] = []

        def capture_sdk_call(**kwargs: Any) -> MagicMock:
            if "system" in kwargs:
                captured_system.append(kwargs["system"])
            return sdk_result

        # Act
        with patch("drivers.claude_code.run_agent_sdk", side_effect=capture_sdk_call):
            driver.execute(
                workspace=tmp_path,
                task_manifest={"task_id": "url_shortener", "entry_point": "./README.md"},
                seed=1,
                budget_usd=10.0,
                wall_clock_budget_seconds=1800,
                disable_prompt_cache=True,
            )

        # Assert — system prompt must not contain a cache_control key
        for system in captured_system:
            if isinstance(system, list):
                for block in system:
                    if isinstance(block, dict):
                        assert "cache_control" not in block, (
                            f"System prompt block must not contain 'cache_control'; "
                            f"got: {block}"
                        )
            elif isinstance(system, dict):
                assert "cache_control" not in system, (
                    f"System prompt must not contain 'cache_control'; got: {system}"
                )

    def test_no_cache_control_in_tool_definitions(self, tmp_path: Path) -> None:
        """
        Given disable_prompt_cache=True,
        When the driver constructs tool definitions passed to the SDK,
        Then no tool definition dict contains 'cache_control'.

        AC-14: 'cache_control is explicitly omitted from every message AND
        every tool definition.'
        """
        # Arrange
        driver = ClaudeCodeDriver()
        sdk_result = _make_sdk_result()
        captured_tools: list[dict] = []

        def capture_sdk_call(**kwargs: Any) -> MagicMock:
            if "tools" in kwargs:
                captured_tools.extend(kwargs["tools"])
            return sdk_result

        # Act
        with patch("drivers.claude_code.run_agent_sdk", side_effect=capture_sdk_call):
            driver.execute(
                workspace=tmp_path,
                task_manifest={"task_id": "url_shortener", "entry_point": "./README.md"},
                seed=1,
                budget_usd=10.0,
                wall_clock_budget_seconds=1800,
                disable_prompt_cache=True,
            )

        # Assert — no cache_control in any tool definition
        for i, tool in enumerate(captured_tools):
            assert "cache_control" not in tool, (
                f"Tool definition {i} must not contain 'cache_control'; got: {tool}"
            )


# ---------------------------------------------------------------------------
# T-32: cache_strategy recorded in DriverResult.driver_metadata
# ---------------------------------------------------------------------------

class TestCacheStrategyRecorded:
    """
    T-32: DriverResult.driver_metadata.cache_strategy is 'omitted' or 'salted'
    when disable_prompt_cache=True.

    AC-14: 'The driver records in driver_metadata.cache_strategy ∈
    {"omitted", "salted"}'
    """

    def test_cache_strategy_is_omitted_or_salted(self, tmp_path: Path) -> None:
        """
        Given disable_prompt_cache=True,
        When execute completes,
        Then DriverResult.driver_metadata['cache_strategy'] is 'omitted' or 'salted'.
        """
        # Arrange
        driver = ClaudeCodeDriver()
        sdk_result = _make_sdk_result()

        # Act
        with patch("drivers.claude_code.run_agent_sdk", return_value=sdk_result):
            result: DriverResult = driver.execute(
                workspace=tmp_path,
                task_manifest={"task_id": "url_shortener", "entry_point": "./README.md"},
                seed=1,
                budget_usd=10.0,
                wall_clock_budget_seconds=1800,
                disable_prompt_cache=True,
            )

        # Assert
        assert "cache_strategy" in result.driver_metadata, (
            "driver_metadata must contain 'cache_strategy'"
        )
        assert result.driver_metadata["cache_strategy"] in ("omitted", "salted"), (
            f"cache_strategy must be 'omitted' or 'salted', "
            f"got {result.driver_metadata['cache_strategy']!r}"
        )

    def test_cache_strategy_never_none(self, tmp_path: Path) -> None:
        """
        Given disable_prompt_cache=True,
        When execute completes,
        Then DriverResult.driver_metadata['cache_strategy'] is not None.

        A None value would mean the driver failed to record its compliance mode.
        """
        # Arrange
        driver = ClaudeCodeDriver()
        sdk_result = _make_sdk_result()

        # Act
        with patch("drivers.claude_code.run_agent_sdk", return_value=sdk_result):
            result: DriverResult = driver.execute(
                workspace=tmp_path,
                task_manifest={"task_id": "url_shortener", "entry_point": "./README.md"},
                seed=1,
                budget_usd=10.0,
                wall_clock_budget_seconds=1800,
                disable_prompt_cache=True,
            )

        # Assert
        strategy = result.driver_metadata.get("cache_strategy")
        assert strategy is not None, (
            "driver_metadata.cache_strategy must not be None when "
            "disable_prompt_cache=True"
        )

    def test_different_seeds_produce_different_salts_when_salted(self, tmp_path: Path) -> None:
        """
        Given disable_prompt_cache=True and cache_strategy='salted',
        When the driver constructs system prompts for seed=1 and seed=2,
        Then the two system prompt strings are different (the salt actually differs).

        AC-14 salted-alternative oracle: 'consecutive requests with the same content
        but different seeds produce different system-prompt hashes (confirming the
        salt actually differs per seed).'

        This test is only load-bearing if the driver chooses the 'salted' path.
        If the driver chooses 'omitted', this passes trivially (no salt needed).
        """
        # Arrange
        driver = ClaudeCodeDriver()
        sdk_result = _make_sdk_result()
        collected_system_prompts: list[Any] = []

        def capture_system(**kwargs: Any) -> MagicMock:
            if "system" in kwargs:
                collected_system_prompts.append(kwargs["system"])
            return sdk_result

        # Act — run twice with different seeds
        with patch("drivers.claude_code.run_agent_sdk", side_effect=capture_system):
            driver.execute(
                workspace=tmp_path,
                task_manifest={"task_id": "url_shortener", "entry_point": "./README.md"},
                seed=1,
                budget_usd=10.0,
                wall_clock_budget_seconds=1800,
                disable_prompt_cache=True,
            )

        with patch("drivers.claude_code.run_agent_sdk", side_effect=capture_system):
            driver.execute(
                workspace=tmp_path,
                task_manifest={"task_id": "url_shortener", "entry_point": "./README.md"},
                seed=2,
                budget_usd=10.0,
                wall_clock_budget_seconds=1800,
                disable_prompt_cache=True,
            )

        # Assert — only enforce if salted strategy was used
        # (if omitted strategy, there is no system prompt salt to compare)
        driver2 = ClaudeCodeDriver()
        sdk_result2 = _make_sdk_result()
        with patch("drivers.claude_code.run_agent_sdk", return_value=sdk_result2):
            result_seed1 = driver2.execute(
                workspace=tmp_path,
                task_manifest={"task_id": "url_shortener", "entry_point": "./README.md"},
                seed=1,
                budget_usd=10.0,
                wall_clock_budget_seconds=1800,
                disable_prompt_cache=True,
            )

        if result_seed1.driver_metadata.get("cache_strategy") == "salted":
            # Salted strategy: prompts for different seeds must differ
            assert len(collected_system_prompts) >= 2, (
                "Expected at least two captured system prompts for seed comparison"
            )
            assert collected_system_prompts[0] != collected_system_prompts[1], (
                "Salted strategy: system prompts for seed=1 and seed=2 must differ"
            )


# ---------------------------------------------------------------------------
# T-33: Aggregator rejects rows with cache_read_input_tokens > 0
# ---------------------------------------------------------------------------

class TestCacheContaminationRejection:
    """
    T-33: A result row where cache_read_input_tokens > 0 is rejected by the
    aggregator as evidence of prompt-cache contamination.

    AC-14: 'any run where cache_read_input_tokens > 0 is rejected by the
    aggregator as evidence of contamination.'

    Oracle (from .test-matrix.md T-33): 'fixture where a second call's response
    contains cache_read_input_tokens > 0 in usage; aggregator must reject the row
    — assert rejection reason string contains "cache".'
    """

    def test_row_with_cache_read_tokens_is_rejected(self, tmp_path: Path) -> None:
        """
        Given a result row where driver_metadata.cache_read_input_tokens == 500,
        When append_result_row is called,
        Then a SchemaViolationError (or equivalent rejection error) is raised
        because cache contamination is detected.
        """
        # Arrange
        contaminated_row = _valid_row_dict(
            driver_metadata={
                "cache_strategy": "omitted",
                "cache_read_input_tokens": 500,  # > 0 signals contamination
            }
        )
        output_jsonl = tmp_path / "results.jsonl"

        # Act + Assert
        with pytest.raises((SchemaViolationError, ValueError, RuntimeError)) as exc_info:
            append_result_row(contaminated_row, output_jsonl)

        # The rejection reason must reference cache contamination
        assert "cache" in str(exc_info.value).lower(), (
            f"Rejection error for cache contamination must mention 'cache'; "
            f"got: {exc_info.value!r}"
        )

    def test_contaminated_row_not_written_to_jsonl(self, tmp_path: Path) -> None:
        """
        Given a result row with cache_read_input_tokens > 0,
        When append_result_row raises due to cache contamination,
        Then the output JSONL is not modified.
        """
        # Arrange
        contaminated_row = _valid_row_dict(
            driver_metadata={
                "cache_strategy": "omitted",
                "cache_read_input_tokens": 100,
            }
        )
        output_jsonl = tmp_path / "results.jsonl"
        output_jsonl.write_text("")  # start empty

        # Act
        with pytest.raises(Exception):
            append_result_row(contaminated_row, output_jsonl)

        # Assert — file stays empty; no contaminated row written
        assert output_jsonl.read_text() == ""

    def test_zero_cache_read_tokens_is_accepted(self, tmp_path: Path) -> None:
        """
        Given a result row where cache_read_input_tokens == 0,
        When append_result_row is called,
        Then no error is raised (zero cache reads means no contamination).
        """
        # Arrange
        clean_row = _valid_row_dict(
            driver_metadata={
                "cache_strategy": "omitted",
                "cache_read_input_tokens": 0,
            }
        )
        output_jsonl = tmp_path / "results.jsonl"

        # Act — must not raise
        append_result_row(clean_row, output_jsonl)

        # Assert — row was written
        lines = [ln for ln in output_jsonl.read_text().splitlines() if ln.strip()]
        assert len(lines) == 1

    def test_row_without_cache_read_tokens_field_is_rejected(self, tmp_path: Path) -> None:
        """
        Given a result row where driver_metadata does not include
        cache_read_input_tokens at all (field absent),
        When append_result_row is called,
        Then SchemaViolationError is raised — absence of the field would
        silently default to 0 under the old .get(..., 0) check, bypassing
        the AC-14 contamination guard. The field MUST be explicit.
        """
        # Arrange
        row_no_cache_field = _valid_row_dict(
            driver_metadata={"cache_strategy": "omitted"}  # cache_read_input_tokens absent
        )
        output_jsonl = tmp_path / "results.jsonl"

        # Act + Assert
        with pytest.raises(SchemaViolationError, match="cache_read_input_tokens"):
            append_result_row(row_no_cache_field, output_jsonl)
