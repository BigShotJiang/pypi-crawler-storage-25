"""
tests/drivers/conftest.py — autouse fixtures for driver tests.

Provides mock version lookups so AiderDriver and ClaudeCodeDriver can be
instantiated without the real packages installed. Tests that need specific
version behavior (R5 guard, R6 cli_version) override via their own patch
context managers, which take precedence over the autouse fixture.
"""
import pytest
from unittest.mock import patch


@pytest.fixture(autouse=True)
def _mock_version_lookups():
    """
    Auto-mock importlib.metadata.version for all driver tests so that
    AiderDriver() and ClaudeCodeDriver() can be instantiated without the
    real packages installed.

    Tests that patch importlib.metadata.version themselves (e.g., R5 guard
    test and R6 cli_version tests) apply their patch INSIDE this fixture's
    context manager, so their inner patch takes precedence — pytest's
    LIFO mock stacking means the innermost patch wins within its scope.

    KNOWN SEMANTIC TRAP (final-gate HIGH-4):
    Tests that assert on `result.driver_metadata["cli_version"]` without
    patching importlib.metadata.version themselves will see the sentinel
    value 'test-version-0.0.0' — NOT a real version. If you write a new
    test that cares about cli_version content, you MUST add your own
    `with patch('importlib.metadata.version', return_value='...')` block;
    do not rely on the autouse fixture's sentinel.

    Implicit constraint: drivers MUST resolve versions lazily (at __init__
    or call time), never at module import time — module-level calls bypass
    this fixture because the import happens before the fixture applies.
    """
    with patch("importlib.metadata.version", return_value="test-version-0.0.0"):
        yield
