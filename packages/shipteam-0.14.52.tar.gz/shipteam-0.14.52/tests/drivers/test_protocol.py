"""
Tests for drivers/_protocol.py — T-7 and T-8 (Phase 2 Part 1 post-review).

Covers:
  T-7 (AC-7): All three DriverResult instances produced from mock adapters
    pass the result_row schema contract. Asserted via a field-presence helper
    that mirrors the required schema fields (simpler RED path than JSON-schema
    validation — implementation can add schema file later without changing these).

  T-8 (AC-7): Nullable-fields contract:
    - input_tokens=None and cost_usd=None are valid (accepted by __post_init__)
    - cost_source is always present and non-null (one of the Literal values)
    - cache_strategy is always present and non-null (one of the Literal values)

Design note (simplest RED interpretation):
  We instantiate DriverResult directly with per-driver representative values
  rather than importing the three driver classes. This keeps T-7 and T-8
  isolated to the protocol layer; driver-specific tests live in test_aider.py,
  test_droid.py, and test_claude_code.py.
"""

from __future__ import annotations

from collections.abc import Mapping

import pytest

from drivers._protocol import (
    DriverResult,
    VALID_COST_SOURCES,
    VALID_CACHE_STRATEGIES,
)


# ---------------------------------------------------------------------------
# Schema-contract helper (mirrors result_row.schema.json required fields)
# ---------------------------------------------------------------------------

_REQUIRED_FIELDS = frozenset(
    {
        "wall_clock_ms",
        "input_tokens",
        "output_tokens",
        "cost_usd",
        "cost_source",
        "aborted",
        "abort_reason",
        "cache_strategy",
        "driver_metadata",
    }
)


def _assert_schema_compliant(result: DriverResult, driver_label: str) -> None:
    """
    Assert that a DriverResult instance satisfies the result_row schema contract.

    This helper mirrors the required fields defined in aggregation/result_row.schema.json.
    It is intentionally kept to field-presence and type checks so that GREEN-phase
    implementation can introduce the JSON-schema file without breaking this test.
    """
    result_dict = result.__dict__

    # Every required field must be present
    missing = _REQUIRED_FIELDS - result_dict.keys()
    assert not missing, (
        f"{driver_label}: DriverResult is missing required schema fields: {missing}"
    )

    # cost_source must be one of the valid Literal values
    assert result.cost_source in VALID_COST_SOURCES, (
        f"{driver_label}: cost_source must be in {VALID_COST_SOURCES}, "
        f"got {result.cost_source!r}"
    )

    # cache_strategy must be one of the valid Literal values
    assert result.cache_strategy in VALID_CACHE_STRATEGIES, (
        f"{driver_label}: cache_strategy must be in {VALID_CACHE_STRATEGIES}, "
        f"got {result.cache_strategy!r}"
    )

    # driver_metadata must be a Mapping (nested, not top-level flattened).
    # Per drivers/_protocol.py:63-64, __post_init__ wraps it in MappingProxyType,
    # which is a Mapping but not a dict subclass — assert the abstract contract.
    assert isinstance(result.driver_metadata, Mapping), (
        f"{driver_label}: driver_metadata must be a Mapping, got {type(result.driver_metadata)}"
    )

    # wall_clock_ms must be a non-negative integer
    assert isinstance(result.wall_clock_ms, int) and result.wall_clock_ms >= 0, (
        f"{driver_label}: wall_clock_ms must be a non-negative int, "
        f"got {result.wall_clock_ms!r}"
    )


# ---------------------------------------------------------------------------
# Fixtures: one representative DriverResult per driver type
# ---------------------------------------------------------------------------

def _claude_code_result() -> DriverResult:
    """Representative DriverResult for the claude_code driver (computed cost; salted cache)."""
    return DriverResult(
        wall_clock_ms=5000,
        input_tokens=1200,
        output_tokens=450,
        cost_usd=0.0183,
        cost_source="computed",
        aborted=False,
        abort_reason=None,
        cache_strategy="salted",
        driver_metadata={"cache_strategy": "salted", "sdk_version": "0.1.68"},
    )


def _aider_result() -> DriverResult:
    """Representative DriverResult for the aider driver (scraped cost, no tokens)."""
    return DriverResult(
        wall_clock_ms=8200,
        input_tokens=None,
        output_tokens=None,
        cost_usd=0.0023,
        cost_source="scraped",
        aborted=False,
        abort_reason=None,
        cache_strategy="native",
        driver_metadata={"cache_strategy": "native"},
    )


def _droid_result() -> DriverResult:
    """Representative DriverResult for the droid driver (scraped, nullable fields)."""
    return DriverResult(
        wall_clock_ms=11000,
        input_tokens=None,
        output_tokens=None,
        cost_usd=None,
        cost_source="scraped",
        aborted=False,
        abort_reason=None,
        cache_strategy="native",
        driver_metadata={"cache_strategy": "native"},
    )


# ---------------------------------------------------------------------------
# T-7: All three driver DriverResult instances satisfy the schema contract
# ---------------------------------------------------------------------------

class TestDriverResultSchemaCompliance:
    """T-7 (AC-7): All three driver result shapes satisfy the result_row schema."""

    def test_claude_code_result_passes_schema(self) -> None:
        """
        Given a DriverResult constructed with claude_code-style fields
        (native cost, integer tokens),
        When validated against the result_row schema contract,
        Then all required fields are present with correct types.
        """
        result = _claude_code_result()
        _assert_schema_compliant(result, driver_label="claude_code")

    def test_aider_result_passes_schema(self) -> None:
        """
        Given a DriverResult constructed with aider-style fields
        (scraped cost, None tokens),
        When validated against the result_row schema contract,
        Then all required fields are present with correct types.
        """
        result = _aider_result()
        _assert_schema_compliant(result, driver_label="aider")

    def test_droid_result_passes_schema(self) -> None:
        """
        Given a DriverResult constructed with droid-style fields
        (scraped cost, all token/cost fields None),
        When validated against the result_row schema contract,
        Then all required fields are present with correct types.
        """
        result = _droid_result()
        _assert_schema_compliant(result, driver_label="droid")

    def test_driver_metadata_is_nested_not_top_level(self) -> None:
        """
        Given any DriverResult instance,
        When driver_metadata is inspected,
        Then it is a nested dict — confirming schema parity across all three drivers.

        AC-7 schema requirement: driver_metadata is nested, not top-level fields.
        """
        for result, label in [
            (_claude_code_result(), "claude_code"),
            (_aider_result(), "aider"),
            (_droid_result(), "droid"),
        ]:
            assert isinstance(result.driver_metadata, Mapping), (
                f"{label}: driver_metadata must be a nested Mapping"
            )


# ---------------------------------------------------------------------------
# T-8: Nullable-fields contract — input_tokens=None and cost_usd=None are valid
# ---------------------------------------------------------------------------

class TestDriverResultNullableFieldsContract:
    """
    T-8 (AC-7): Nullable fields accepted by DriverResult; cost_source and
    cache_strategy are always present and non-null.
    """

    def test_input_tokens_none_is_valid(self) -> None:
        """
        Given input_tokens=None,
        When DriverResult is constructed,
        Then no ValueError is raised (None is valid per schema).
        """
        # Must not raise
        result = DriverResult(
            wall_clock_ms=100,
            input_tokens=None,
            output_tokens=500,
            cost_usd=0.01,
            cost_source="scraped",
            aborted=False,
            abort_reason=None,
            cache_strategy="native",
        )
        assert result.input_tokens is None

    def test_cost_usd_none_is_valid(self) -> None:
        """
        Given cost_usd=None,
        When DriverResult is constructed,
        Then no ValueError is raised (None is explicitly valid).
        """
        result = DriverResult(
            wall_clock_ms=100,
            input_tokens=None,
            output_tokens=None,
            cost_usd=None,
            cost_source="scraped",
            aborted=False,
            abort_reason=None,
            cache_strategy="native",
        )
        assert result.cost_usd is None

    def test_cost_source_always_present_and_valid(self) -> None:
        """
        Given DriverResult instances for all three driver types,
        When cost_source is inspected,
        Then it is always a non-null string from the Literal set.
        """
        for result, label in [
            (_claude_code_result(), "claude_code"),
            (_aider_result(), "aider"),
            (_droid_result(), "droid"),
        ]:
            assert result.cost_source is not None, (
                f"{label}: cost_source must not be None"
            )
            assert result.cost_source in VALID_COST_SOURCES, (
                f"{label}: cost_source must be in {VALID_COST_SOURCES}, "
                f"got {result.cost_source!r}"
            )

    def test_cache_strategy_always_present_and_valid(self) -> None:
        """
        Given DriverResult instances for all three driver types,
        When cache_strategy is inspected,
        Then it is always a non-null string from the Literal set.
        """
        for result, label in [
            (_claude_code_result(), "claude_code"),
            (_aider_result(), "aider"),
            (_droid_result(), "droid"),
        ]:
            assert result.cache_strategy is not None, (
                f"{label}: cache_strategy must not be None"
            )
            assert result.cache_strategy in VALID_CACHE_STRATEGIES, (
                f"{label}: cache_strategy must be in {VALID_CACHE_STRATEGIES}, "
                f"got {result.cache_strategy!r}"
            )

    def test_invalid_cost_source_raises_value_error(self) -> None:
        """
        Given cost_source with a value outside the Literal set,
        When DriverResult is constructed,
        Then ValueError is raised (contract enforcement in __post_init__).

        This is the negative-path companion to the positive nullable tests above.
        """
        with pytest.raises(ValueError, match="cost_source"):
            DriverResult(
                wall_clock_ms=100,
                input_tokens=None,
                output_tokens=None,
                cost_usd=None,
                cost_source="unknown",  # type: ignore[arg-type]
                aborted=False,
                abort_reason=None,
                cache_strategy="salted",
            )


# ---------------------------------------------------------------------------
# Phase 5e: cache_strategy literal narrows from {"omitted", "salted"} →
# {"salted", "native"}. "omitted" is no longer accepted; cache defeat is
# achieved via salted system-prompt suffix (AC-14). "native" is for drivers
# (aider, droid) that do not control the model's caching.
# ---------------------------------------------------------------------------

class TestPhase5eCacheStrategyContractNarrows:
    """Phase 5e contract change: VALID_CACHE_STRATEGIES = ('salted', 'native')."""

    def test_valid_cache_strategies_is_salted_and_native_only(self) -> None:
        """The exported tuple of accepted cache strategies must be exactly the new set."""
        assert set(VALID_CACHE_STRATEGIES) == {"salted", "native"}, (
            f"Phase 5e narrowed VALID_CACHE_STRATEGIES to {{'salted', 'native'}}; "
            f"got {VALID_CACHE_STRATEGIES!r}"
        )

    def test_omitted_cache_strategy_is_rejected(self) -> None:
        """The Phase 5a 'omitted' literal is no longer accepted."""
        with pytest.raises(ValueError, match="cache_strategy"):
            DriverResult(
                wall_clock_ms=100,
                input_tokens=None,
                output_tokens=None,
                cost_usd=None,
                cost_source="scraped",
                aborted=False,
                abort_reason=None,
                cache_strategy="omitted",  # type: ignore[arg-type]
            )

    def test_salted_cache_strategy_is_accepted(self) -> None:
        result = DriverResult(
            wall_clock_ms=100,
            input_tokens=10,
            output_tokens=10,
            cost_usd=0.001,
            cost_source="computed",
            aborted=False,
            abort_reason=None,
            cache_strategy="salted",
        )
        assert result.cache_strategy == "salted"

    def test_native_cache_strategy_is_accepted(self) -> None:
        result = DriverResult(
            wall_clock_ms=100,
            input_tokens=None,
            output_tokens=None,
            cost_usd=None,
            cost_source="scraped",
            aborted=False,
            abort_reason=None,
            cache_strategy="native",
        )
        assert result.cache_strategy == "native"


# ---------------------------------------------------------------------------
# Phase 5e: AbortReason becomes a frozen dataclass with closed AbortCategory.
# Replaces the colon-encoded f-string hack at harness/runner.py:134.
# ---------------------------------------------------------------------------

class TestPhase5eAbortReasonDataclass:
    """AbortReason(category: AbortCategory, detail: str = '') with __str__ formatter."""

    _EXPECTED_CATEGORIES = frozenset({
        "budget_exceeded",
        "rate_limit_repeated",
        "server_error",
        "wall_clock_exceeded",
        "driver_error",
        "missing_token_counts",
        "pytest_collection_error",
        "docker_unavailable",
        "unrecognized_model_for_rate_sheet",
        "cache_leak_detected",
        "api_error_text",
    })

    def test_abort_reason_importable_from_protocol(self) -> None:
        """AbortReason must be exported from drivers._protocol."""
        from drivers._protocol import AbortReason  # noqa: F401  (import is the test)

    def test_abort_reason_is_frozen_dataclass(self) -> None:
        """Mutating an AbortReason instance must raise FrozenInstanceError."""
        from dataclasses import FrozenInstanceError
        from drivers._protocol import AbortReason

        reason = AbortReason(category="server_error", detail="HTTP 500")
        with pytest.raises(FrozenInstanceError):
            reason.detail = "tampered"  # type: ignore[misc]

    def test_abort_reason_default_detail_is_empty_string(self) -> None:
        from drivers._protocol import AbortReason

        reason = AbortReason(category="budget_exceeded")
        assert reason.detail == "", (
            f"AbortReason.detail must default to '', got {reason.detail!r}"
        )

    def test_abort_reason_str_without_detail_returns_category(self) -> None:
        from drivers._protocol import AbortReason

        assert str(AbortReason(category="docker_unavailable")) == "docker_unavailable"

    def test_abort_reason_str_with_detail_returns_category_colon_detail(self) -> None:
        from drivers._protocol import AbortReason

        reason = AbortReason(category="api_error_text", detail="rate_limit_error")
        assert str(reason) == "api_error_text: rate_limit_error", (
            f"AbortReason.__str__ must be 'category: detail', got {reason!s}"
        )

    @pytest.mark.parametrize("category", sorted(_EXPECTED_CATEGORIES))
    def test_each_expected_abort_category_constructs_successfully(
        self, category: str,
    ) -> None:
        """All 11 closed-Literal categories must be accepted by AbortReason."""
        from drivers._protocol import AbortReason

        reason = AbortReason(category=category)  # type: ignore[arg-type]
        assert reason.category == category

    def test_driver_result_accepts_abort_reason_instance(self) -> None:
        """DriverResult.abort_reason must accept an AbortReason instance (not just str)."""
        from drivers._protocol import AbortReason

        reason = AbortReason(category="missing_token_counts", detail="usage was None")
        result = DriverResult(
            wall_clock_ms=100,
            input_tokens=None,
            output_tokens=None,
            cost_usd=None,
            cost_source="computed",
            aborted=True,
            abort_reason=reason,
            cache_strategy="salted",
        )
        assert result.abort_reason is reason
        assert result.abort_reason.category == "missing_token_counts"


# ---------------------------------------------------------------------------
# Phase 5e: Driver.execute() signature drops disable_prompt_cache, adds
# cache_strategy: Literal["salted", "native"] = "salted".
# ---------------------------------------------------------------------------

class TestPhase5eDriverExecuteSignature:
    """Protocol-level introspection of Driver.execute() parameter list."""

    def test_driver_execute_has_cache_strategy_parameter(self) -> None:
        """Driver.execute must accept cache_strategy as a keyword param with default 'salted'."""
        import inspect
        from drivers._protocol import Driver

        sig = inspect.signature(Driver.execute)
        assert "cache_strategy" in sig.parameters, (
            "Driver.execute() must declare cache_strategy parameter (Phase 5e contract). "
            f"Got params: {list(sig.parameters)}"
        )
        param = sig.parameters["cache_strategy"]
        assert param.default == "salted", (
            f"cache_strategy default must be 'salted', got {param.default!r}"
        )

    def test_driver_execute_no_longer_has_disable_prompt_cache(self) -> None:
        """Phase 5a's disable_prompt_cache parameter must be removed."""
        import inspect
        from drivers._protocol import Driver

        sig = inspect.signature(Driver.execute)
        assert "disable_prompt_cache" not in sig.parameters, (
            "disable_prompt_cache parameter must be removed in Phase 5e — "
            "cache defeat now via salted system-prompt suffix (AC-14). "
            f"Got params: {list(sig.parameters)}"
        )
