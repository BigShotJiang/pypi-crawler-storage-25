"""
Tests for AC-19: Aider driver scans stdout for vendor-specific error patterns.

Covers:
  AC-19: Aider driver scans proc.stdout (case-insensitive) for the regex
    /rate.?limit|API.?error|connection.?error|context.?length.?exceeded|litellm\\.exceptions/
    and on match sets aborted=True, abort_reason.category="api_error_text" with
    driver_metadata['matched_pattern'] populated.

  Pattern source: aider.chat/docs/troubleshooting/token-limits.html (from Risk Watch R18)
  Closed AbortCategory Literal[11] includes "api_error_text".

Mocking strategy:
  - subprocess.run is patched to return a configurable CompletedProcess
  - Patch target is 'drivers.aider.subprocess.run' (the module-level import used by the driver)
  - No implementation files read (cognitive isolation)
  - Interface derived from drivers/_protocol.py + .sherlock-plan.md AC-19

Naming convention: test_AC19_<behavior>
"""
import re
import subprocess
from collections.abc import Mapping
from pathlib import Path
from types import MappingProxyType
from unittest.mock import MagicMock, patch

import pytest

from drivers.aider import AiderDriver
from drivers._protocol import AbortReason, DriverResult

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_TASK_MANIFEST: dict = {
    "task_id": "url_shortener",
    "entry_point": "./seed/README.md",
    "workspace": {"seed_repo": "./seed/"},
}

_CLEAN_STDOUT = (
    "Aider v0.64.0\n"
    "Model: claude-3-5-sonnet-20241022\n"
    "Applied 2 edits to app.py\n"
    "Cost: $0.0097 message, $0.0023 session\n"
)


def _make_proc(
    returncode: int = 0,
    stdout: str = _CLEAN_STDOUT,
    stderr: str = "",
) -> MagicMock:
    """Return a mock subprocess.CompletedProcess for Aider execution."""
    proc = MagicMock(spec=subprocess.CompletedProcess)
    proc.returncode = returncode
    proc.stdout = stdout
    proc.stderr = stderr
    return proc


# ---------------------------------------------------------------------------
# Parametrized: each error pattern in stdout → aborted + matched_pattern set
# ---------------------------------------------------------------------------

@pytest.mark.parametrize(
    "stdout_line,description",
    [
        (
            "litellm.exceptions.RateLimitError: Too many requests, try again in 60s",
            "litellm.exceptions prefix triggers on exact module path",
        ),
        (
            "aider: ERROR connection refused (connection.error pattern)",
            "connection.?error matches with separator",
        ),
        (
            "litellm.exceptions.APIError: Received API error 500 from provider",
            "litellm.exceptions with APIError subclass",
        ),
        (
            "Context length exceeded for model claude-3-5-sonnet",
            "context.?length.?exceeded pattern matches",
        ),
        (
            "RATE LIMIT exceeded — will retry in 30 seconds",
            "case-insensitive: RATE LIMIT in all caps",
        ),
    ],
)
class TestAC19ErrorPatternMatches:
    """AC-19: Error patterns in stdout set aborted=True with api_error_text category."""

    def test_AC19_aborted_true_on_error_pattern(
        self,
        tmp_path: Path,
        stdout_line: str,
        description: str,
    ) -> None:
        """
        Given Aider stdout containing a vendor error pattern (parametrized),
        When the driver processes the subprocess result,
        Then DriverResult.aborted is True.

        AC-19: 'on match sets aborted=true'
        """
        # Arrange
        driver = AiderDriver()
        proc = _make_proc(returncode=0, stdout=stdout_line + "\n" + _CLEAN_STDOUT)

        # Act
        with patch("drivers.aider.subprocess.run", return_value=proc):
            result: DriverResult = driver.execute(
                workspace=tmp_path,
                task_manifest=_TASK_MANIFEST,
                seed=42,
                budget_usd=2.0,
                wall_clock_budget_seconds=180,
            )

        # Assert
        assert result.aborted is True, (
            f"[{description}] Expected aborted=True when stdout contains error pattern; "
            f"got aborted={result.aborted!r}"
        )

    def test_AC19_abort_reason_category_is_api_error_text(
        self,
        tmp_path: Path,
        stdout_line: str,
        description: str,
    ) -> None:
        """
        Given Aider stdout containing a vendor error pattern,
        When the driver processes the subprocess result,
        Then abort_reason.category == 'api_error_text'.

        AC-19: 'abort_reason.category="api_error_text"' — uses closed AbortCategory Literal[11].
        """
        # Arrange
        driver = AiderDriver()
        proc = _make_proc(returncode=0, stdout=stdout_line)

        # Act
        with patch("drivers.aider.subprocess.run", return_value=proc):
            result: DriverResult = driver.execute(
                workspace=tmp_path,
                task_manifest=_TASK_MANIFEST,
                seed=42,
                budget_usd=2.0,
                wall_clock_budget_seconds=180,
            )

        # Assert
        assert result.abort_reason is not None, (
            f"[{description}] abort_reason must not be None when aborted=True"
        )
        assert result.abort_reason.category == "api_error_text", (
            f"[{description}] abort_reason.category must be 'api_error_text', "
            f"got {result.abort_reason.category!r}"
        )

    def test_AC19_driver_metadata_matched_pattern_populated(
        self,
        tmp_path: Path,
        stdout_line: str,
        description: str,
    ) -> None:
        """
        Given Aider stdout containing a vendor error pattern,
        When the driver processes the subprocess result,
        Then driver_metadata['matched_pattern'] is populated with the matched substring.

        AC-19: 'driver_metadata["matched_pattern"] set to the captured substring'
        """
        # Arrange
        driver = AiderDriver()
        proc = _make_proc(returncode=0, stdout=stdout_line)

        # Act
        with patch("drivers.aider.subprocess.run", return_value=proc):
            result: DriverResult = driver.execute(
                workspace=tmp_path,
                task_manifest=_TASK_MANIFEST,
                seed=42,
                budget_usd=2.0,
                wall_clock_budget_seconds=180,
            )

        # Assert
        assert "matched_pattern" in result.driver_metadata, (
            f"[{description}] driver_metadata must contain 'matched_pattern' key "
            f"when error pattern fires; got keys: {list(result.driver_metadata.keys())}"
        )
        matched = result.driver_metadata["matched_pattern"]
        assert matched is not None and matched != "", (
            f"[{description}] driver_metadata['matched_pattern'] must be a non-empty "
            f"string, got {matched!r}"
        )


# ---------------------------------------------------------------------------
# Clean stdout — driver completes normally, not aborted
# ---------------------------------------------------------------------------

class TestAC19CleanStdoutNotAborted:
    """AC-19 negative path: clean stdout does NOT trigger abort."""

    def test_AC19_clean_stdout_not_aborted(self, tmp_path: Path) -> None:
        """
        Given Aider stdout containing no error patterns (normal completion),
        When the driver processes the subprocess result,
        Then DriverResult.aborted is False and matched_pattern is absent.

        AC-19: 'Clean stdout (driver completed normally) → NOT aborted'
        """
        # Arrange
        driver = AiderDriver()
        proc = _make_proc(returncode=0, stdout=_CLEAN_STDOUT)

        # Act
        with patch("drivers.aider.subprocess.run", return_value=proc):
            result: DriverResult = driver.execute(
                workspace=tmp_path,
                task_manifest=_TASK_MANIFEST,
                seed=42,
                budget_usd=2.0,
                wall_clock_budget_seconds=180,
            )

        # Assert
        assert result.aborted is False, (
            f"Expected aborted=False for clean stdout; got aborted={result.aborted!r}"
        )
        assert "matched_pattern" not in result.driver_metadata, (
            "driver_metadata must NOT contain 'matched_pattern' when no error pattern fires; "
            f"got: {dict(result.driver_metadata)}"
        )

    def test_AC19_abort_reason_none_on_clean_stdout(self, tmp_path: Path) -> None:
        """
        Given clean Aider stdout,
        When driver.execute completes,
        Then abort_reason is None (no spurious error classification).
        """
        # Arrange
        driver = AiderDriver()
        proc = _make_proc(returncode=0, stdout=_CLEAN_STDOUT)

        # Act
        with patch("drivers.aider.subprocess.run", return_value=proc):
            result: DriverResult = driver.execute(
                workspace=tmp_path,
                task_manifest=_TASK_MANIFEST,
                seed=42,
                budget_usd=2.0,
                wall_clock_budget_seconds=180,
            )

        # Assert
        assert result.abort_reason is None, (
            f"abort_reason must be None on clean stdout; got {result.abort_reason!r}"
        )


# ---------------------------------------------------------------------------
# Protocol invariants: driver_metadata is a Mapping, AbortCategory is valid
# ---------------------------------------------------------------------------

class TestAC19ProtocolInvariants:
    """Protocol-level invariants for the error-scan path."""

    def test_AC19_driver_metadata_is_mapping(self, tmp_path: Path) -> None:
        """
        Given Aider stdout with an error pattern,
        When driver.execute returns,
        Then driver_metadata is a Mapping (frozen via MappingProxyType per _protocol.py:64).

        Interface Contract: DriverResult.driver_metadata is Mapping[str, object]
        and __post_init__ wraps it in MappingProxyType.
        """
        # Arrange
        driver = AiderDriver()
        proc = _make_proc(
            returncode=0,
            stdout="litellm.exceptions.RateLimitError: quota exceeded",
        )

        # Act
        with patch("drivers.aider.subprocess.run", return_value=proc):
            result: DriverResult = driver.execute(
                workspace=tmp_path,
                task_manifest=_TASK_MANIFEST,
                seed=42,
                budget_usd=2.0,
                wall_clock_budget_seconds=180,
            )

        # Assert
        assert isinstance(result.driver_metadata, Mapping), (
            f"driver_metadata must be a Mapping, got {type(result.driver_metadata)}"
        )
        assert isinstance(result.driver_metadata, MappingProxyType), (
            "driver_metadata must be frozen via MappingProxyType "
            "(DriverResult.__post_init__ guarantees this)"
        )

    def test_AC19_abort_reason_category_is_valid_abort_category(
        self, tmp_path: Path
    ) -> None:
        """
        Given Aider stdout with 'rate limit exceeded',
        When driver.execute sets abort_reason,
        Then abort_reason.category is one of the 11 valid AbortCategory literals.

        Validates that 'api_error_text' is in the closed Literal[11] set.
        """
        _VALID_ABORT_CATEGORIES = frozenset({
            "budget_exceeded",
            "rate_limit_repeated",
            "server_error",
            "wall_clock_exceeded",
            "driver_error",
            "missing_token_counts",
            "pytest_collection_error",
            "docker_unavailable",
            "unrecognized_model_for_rate_sheet",
            "cache_leak_detected",
            "api_error_text",
        })

        # Arrange
        driver = AiderDriver()
        proc = _make_proc(returncode=0, stdout="rate limit exceeded")

        # Act
        with patch("drivers.aider.subprocess.run", return_value=proc):
            result: DriverResult = driver.execute(
                workspace=tmp_path,
                task_manifest=_TASK_MANIFEST,
                seed=42,
                budget_usd=2.0,
                wall_clock_budget_seconds=180,
            )

        # Assert
        assert result.abort_reason is not None
        assert result.abort_reason.category in _VALID_ABORT_CATEGORIES, (
            f"abort_reason.category must be one of {_VALID_ABORT_CATEGORIES}; "
            f"got {result.abort_reason.category!r}"
        )


# ---------------------------------------------------------------------------
# AC-15 Aider exemption: token-count check MUST NOT fire for scraped-cost
# drivers. Aider does not emit input_tokens / output_tokens — every Aider
# DriverResult has them as None. If the AC-15 missing_token_counts abort
# applied uniformly, every successful Aider run would be incorrectly aborted.
# ---------------------------------------------------------------------------

class TestAC15AiderExemption:
    """
    AC-15 second P0: a DriverResult with input_tokens=None, cost_source='scraped'
    MUST NOT set aborted=True solely because tokens are absent. The AC-15
    missing-token-counts gate applies to drivers that own token reporting (the
    SDK driver), not to drivers that scrape cost from stdout.
    """

    def test_AC15_aider_clean_run_with_none_tokens_is_not_aborted(
        self, tmp_path: Path
    ) -> None:
        """
        Given a clean Aider stdout (no error patterns) and exit 0,
        When driver.execute completes,
        Then result.aborted is False AND input_tokens is None AND
             cost_source == 'scraped' — proving the missing-token-counts
             gate did not fire on this Aider result.
        """
        driver = AiderDriver()
        proc = _make_proc(returncode=0, stdout=_CLEAN_STDOUT)

        with patch("drivers.aider.subprocess.run", return_value=proc):
            result: DriverResult = driver.execute(
                workspace=tmp_path,
                task_manifest=_TASK_MANIFEST,
                seed=42,
                budget_usd=2.0,
                wall_clock_budget_seconds=180,
            )

        assert result.input_tokens is None, (
            "Aider does not emit input_tokens — the result MUST carry None"
        )
        assert result.output_tokens is None, (
            "Aider does not emit output_tokens — the result MUST carry None"
        )
        assert result.cost_source == "scraped", (
            "Aider's cost_source MUST be 'scraped' (parsed from stdout)"
        )
        assert result.aborted is False, (
            "AC-15 Aider exemption: missing-token-counts gate MUST NOT fire "
            "for scraped-cost drivers. A clean Aider run with None tokens is "
            "a successful, non-aborted result."
        )
        assert result.abort_reason is None, (
            "AC-15 Aider exemption: a non-aborted Aider result MUST have "
            "abort_reason=None even though input_tokens=None."
        )
