"""Tests for .claude/skills/verify-math/verify.py — math verification skill.

Covers symbolic verification via sympy, independent corroboration (via
lambdify, NOT raw eval), fail-closed behaviour on missing dependencies,
JSONL event logging, and a security regression guard against the eval()
sandbox-escape attack vector that was caught by the final-gate review.
"""

import importlib.util
import json
import os
import re
import subprocess
import sys
from pathlib import Path
from unittest.mock import patch

import pytest

# ---------------------------------------------------------------------------
# Module import (path-based — verify.py is not an installable package)
# ---------------------------------------------------------------------------

_MOD = (
    Path(__file__).parent.parent
    / ".claude"
    / "skills"
    / "verify-math"
    / "verify.py"
)

def _load_verify_math():
    """Load verify_math module lazily; raises FileNotFoundError if not yet implemented."""
    if not _MOD.exists():
        raise FileNotFoundError(
            f"verify.py not yet implemented at {_MOD}. "
            "This is expected in the RED phase."
        )
    spec = importlib.util.spec_from_file_location("verify_math", _MOD)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


# Attempt eager load so IDE gets types; tests use the lazy loader inside fixtures
try:
    _verify_math_mod = _load_verify_math()
    verify = _verify_math_mod.verify
    VerifyResult = _verify_math_mod.VerifyResult
except FileNotFoundError:
    verify = None  # type: ignore[assignment]
    VerifyResult = None  # type: ignore[assignment]




# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_framework_yaml(tmp_path: Path, enabled: bool = True) -> Path:
    """Write a minimal framework.yaml with metrics.enabled set."""
    config_dir = tmp_path / "config"
    config_dir.mkdir(parents=True, exist_ok=True)
    content = f"metrics:\n  enabled: {str(enabled).lower()}\n"
    yaml_path = config_dir / "framework.yaml"
    yaml_path.write_text(content)
    return yaml_path


def _run_verify_without_sympy(expression: str) -> subprocess.CompletedProcess:
    """Run verify.py in a subprocess where sympy/numpy imports raise ImportError.

    Setting ``sys.modules['sympy'] = None`` before loading verify.py causes any
    ``import sympy`` inside verify.py to raise ``ImportError`` — this is the
    standard Python idiom for simulating a missing dependency. PYTHONPATH alone
    cannot block a module already installed in site-packages.
    """
    wrapper = (
        "import sys, runpy\n"
        "sys.modules['sympy'] = None\n"
        "sys.modules['numpy'] = None\n"
        f"sys.argv = [{str(_MOD)!r}, {expression!r}]\n"
        f"runpy.run_path({str(_MOD)!r}, run_name='__main__')\n"
    )
    return subprocess.run(
        [sys.executable, "-c", wrapper],
        env={"PATH": os.environ["PATH"]},
        capture_output=True,
        text=True,
    )


# ---------------------------------------------------------------------------
# Regression guards for H1/H2 found in per-phase review
# ---------------------------------------------------------------------------

class TestSandboxEscape:
    """Security regression guard — RCE attack vectors MUST be rejected by the AST pre-filter.

    The original implementation used `eval(expression, {'__builtins__': {}}, safe_ns)`
    which is a known-broken Python sandbox. Also, SymPy's `parse_expr` internally
    calls `eval` with builtins accessible — it executed `__import__('os').system(...)`
    during testing. The current implementation AST-walks the input and rejects any
    attribute access, subscript, starred args, unknown name, or non-numeric constant
    BEFORE the string ever reaches parse_expr. These tests guard that boundary.
    """

    def test_rce_class_mro_attempt_is_rejected(self):
        """Attribute-chain exploit must be rejected with ok=False and a caveat."""
        result = verify(
            "sqrt.__class__.__mro__[-1].__subclasses__()", source="all"
        )
        assert result.ok is False
        assert any("rejected" in c or "disallowed" in c for c in result.caveats), (
            f"payload must be rejected with a disallowed/rejected caveat; got {result.caveats}"
        )
        assert result.symbolic_result is None

    def test_import_injection_is_rejected(self):
        """__import__ / os / system-style attempts must be rejected."""
        payloads = [
            "__import__('os').system('echo pwned')",
            "(sqrt).__class__",
            "().__class__.__bases__",
            "sqrt(2)[0]",  # subscript
            "sqrt(*[2])",  # starred
        ]
        for p in payloads:
            result = verify(p, source="all")
            assert result.ok is False, (
                f"payload {p!r} must reject with ok=False; got {result}"
            )
            assert result.symbolic_result is None, (
                f"payload {p!r} must not produce a symbolic result"
            )

    def test_string_literals_are_rejected(self):
        """String constants inside expressions are rejected (no stringy payloads)."""
        result = verify("sqrt('2')", source="sympy")
        assert result.ok is False
        assert any("constant" in c or "rejected" in c for c in result.caveats)

    def test_oversized_expression_capped(self):
        """Expressions beyond the input cap return early with a caveat."""
        huge = "x+" * 600 + "x"  # > 1024 chars
        result = verify(huge, source="sympy")
        assert result.ok is False
        assert any("exceeds" in c for c in result.caveats), (
            f"oversized input should add a size caveat; got {result.caveats}"
        )

    def test_large_integer_constant_rejected_to_block_pow_dos(self):
        """DoS guard: `2**99999` would lock the parser computing a 30k-digit int."""
        result = verify("2**99999", source="sympy")
        assert result.ok is False
        assert any(
            "integer constant exceeds cap" in c for c in result.caveats
        ), f"large int constant should be rejected; got {result.caveats}"

    def test_uncaught_exception_from_parser_converts_to_caveat(self):
        """DoS guard: parser errors on pathological input must NEVER propagate.

        Replaces a previous version of this test that used `contextlib.suppress()`
        with no args — which is a no-op context manager — so the test passed
        vacuously regardless of behavior. The fix asserts directly: verify()
        must always return a VerifyResult on valid-looking input, never raise.
        """
        # log(0) → SymPy returns zoo (complex infinity). verify() must catch
        # whatever happens and return a VerifyResult — exception propagation
        # would be a regression of the parse-time exception handling.
        result = verify("log(0)", source="sympy")
        assert isinstance(result, VerifyResult), (
            "verify() must return a VerifyResult, never raise"
        )


class TestSourceModeBranches:
    """Regression guards — source='numpy' ok=True, source='all' demotion on numpy-fail."""

    def test_numpy_only_source_sets_ok_true_on_success(self):
        """H1 guard: source='numpy' alone must set ok=True when eval succeeds."""
        result = verify("sqrt(2) * pi", source="numpy")
        assert result.ok is True, (
            "source='numpy' should report ok=True when numpy eval succeeds; "
            f"got ok={result.ok}, caveats={result.caveats}"
        )
        assert result.numeric_result is not None
        assert result.symbolic_result is None  # sympy path was skipped

    def test_source_all_free_symbols_marks_independent_check_na(self):
        """source='all' on a free-symbol expression must report N/A (not PASS/FAIL).

        `integrate(x**2, x)` → `x**3/3` has free symbol `x`, so no independent
        numeric cross-check is possible. The skill must be honest about that
        rather than silently claiming a check ran.
        """
        result = verify("integrate(x**2, x)", source="all")
        assert result.symbolic_result is not None, "sympy should parse this"
        # Sympy path succeeded; numpy path cannot run (free symbol). Being
        # explicit with N/A (rather than the old misleading PASS) is the fix.
        assert result.independent_check == "N/A", (
            f"expected 'N/A' for free-symbol expression; got {result.independent_check!r}"
        )
        assert result.numeric_result is None


# ---------------------------------------------------------------------------
# AC-1 — Symbolic verification (T-1, T-2, T-3)
# ---------------------------------------------------------------------------

class TestSymbolicVerification:
    """AC-1: verify() with source='sympy' returns symbolic result via sympy."""

    def test_t1_symbolic_result_contains_antiderivative(self):
        """T-1 (P0): AC-1 — symbolic_result contains x**3/3 for integrate(x**2, x)."""
        # Arrange
        expression = "integrate(x**2, x)"

        # Act
        result = verify(expression, source="sympy")

        # Assert
        assert result.symbolic_result is not None
        assert "x**3/3" in result.symbolic_result or "x**3" in result.symbolic_result

    def test_t1_ok_is_true_for_valid_integral(self):
        """T-1 (P0): AC-1 — result.ok is True for a successfully verified integral."""
        expression = "integrate(x**2, x)"

        result = verify(expression, source="sympy")

        assert result.ok is True

    def test_t2_numeric_result_set_for_sympy_source(self):
        """T-2 (P1): AC-1 — numeric_result is not None when source='sympy'."""
        expression = "integrate(x**2, x)"

        result = verify(expression, source="sympy")

        # sympy can produce a numeric result via lambdify or similar
        # (boundary check — may be None when not applicable; test the interface)
        assert isinstance(result, VerifyResult)
        # inputs field echoes the expression
        assert result.inputs == expression

    def test_t3_authoritative_reference_matches_trusted_sources(self):
        """T-3 (P1): AC-1 — authoritative_reference references NIST, IEEE, or SEMATECH."""
        expression = "integrate(x**2, x)"

        result = verify(expression, source="sympy")

        assert result.authoritative_reference is not None
        pattern = re.compile(r"NIST|IEEE|SEMATECH", re.IGNORECASE)
        assert pattern.search(result.authoritative_reference), (
            f"Expected NIST, IEEE, or SEMATECH in authoritative_reference, "
            f"got: {result.authoritative_reference!r}"
        )


# ---------------------------------------------------------------------------
# AC-2 — Independent corroboration (T-4, T-5)
# ---------------------------------------------------------------------------

class TestIndependentCorroboration:
    """AC-2: verify() with source='all' runs both sympy and numpy paths."""

    def test_t4_independent_check_passes_for_sqrt2_pi(self):
        """T-4 (P0): AC-2 — independent_check == 'PASS' for sqrt(2)*pi with source=all."""
        expression = "sqrt(2) * pi"

        result = verify(expression, source="all")

        assert result.symbolic_result is not None
        assert result.numeric_result is not None
        assert result.independent_check == "PASS"

    def test_t5_metamorphic_sympy_numeric_agreement_within_tolerance(self):
        """T-5 (P1): AC-2 — abs(float(symbolic) - numeric) < default tolerance (1e-9).

        symbolic_result is the symbolic string (e.g. "sqrt(2)*pi") per the contract;
        convert it back through sympy.sympify to get a comparable float.
        """
        import sympy as _sp
        expression = "sqrt(2) * pi"

        result = verify(expression, source="all")

        assert result.symbolic_result is not None
        assert result.numeric_result is not None

        symbolic_float = float(_sp.sympify(result.symbolic_result).evalf())
        numeric = result.numeric_result
        assert abs(symbolic_float - numeric) < 1e-9, (
            f"Sympy ({symbolic_float}) and numpy ({numeric}) disagree beyond tolerance"
        )


# ---------------------------------------------------------------------------
# AC-3 — Fail-closed on missing dependency (T-6, T-7, T-8)
# ---------------------------------------------------------------------------

class TestMissingDependency:
    """AC-3: CLI invocation without sympy exits 2 with MATH-VERIFY-UNAVAILABLE on stderr."""

    def test_t6_exit_code_2_when_sympy_unavailable(self):
        """T-6 (P0): AC-3 — subprocess exits with code 2 when sympy cannot be imported."""
        proc = _run_verify_without_sympy("integrate(x**2, x)")

        assert proc.returncode == 2, (
            f"Expected exit code 2, got {proc.returncode}. "
            f"stderr: {proc.stderr!r}"
        )

    def test_t7_stdout_contains_no_verification_result_when_unavailable(self):
        """T-7 (P0): AC-3 — stdout has no verification output when sympy is missing."""
        proc = _run_verify_without_sympy("integrate(x**2, x)")

        stdout = proc.stdout
        # No verification lines should appear
        assert "Independent Check" not in stdout
        assert "x**3/3" not in stdout
        assert "PASS" not in stdout

    def test_t8_stderr_contains_install_instruction(self):
        """T-8 (P1): AC-3 — stderr contains 'uv pip install sympy numpy' install hint."""
        proc = _run_verify_without_sympy("integrate(x**2, x)")

        assert "MATH-VERIFY-UNAVAILABLE" in proc.stderr, (
            f"Expected MATH-VERIFY-UNAVAILABLE in stderr, got: {proc.stderr!r}"
        )
        assert "uv pip install sympy numpy" in proc.stderr, (
            f"Expected install hint in stderr, got: {proc.stderr!r}"
        )


# ---------------------------------------------------------------------------
# AC-5 — Event logging (T-12, T-13, T-14)
# ---------------------------------------------------------------------------

class TestEventLogging:
    """AC-5: successful verify() appends a math_verify JSONL record when metrics enabled."""

    def _read_new_records(self, metrics_dir: Path, before_lines: int) -> list[dict]:
        """Read JSONL records appended after a known line count."""
        records = []
        for jsonl_file in sorted(metrics_dir.glob("events-*.jsonl")):
            lines = [l for l in jsonl_file.read_text().splitlines() if l.strip()]
            for line in lines[before_lines:]:
                try:
                    records.append(json.loads(line))
                except json.JSONDecodeError:
                    pass
        return records

    def _count_existing_lines(self, metrics_dir: Path) -> int:
        """Count total JSONL lines across all monthly event files."""
        total = 0
        if metrics_dir.exists():
            for jsonl_file in metrics_dir.glob("events-*.jsonl"):
                total += sum(
                    1 for l in jsonl_file.read_text().splitlines() if l.strip()
                )
        return total

    def test_t12_exactly_one_record_appended_on_success(self, tmp_path, monkeypatch):
        """T-12 (P0): AC-5 — exactly one JSONL record is appended per verify() call."""
        # Arrange
        _make_framework_yaml(tmp_path, enabled=True)
        monkeypatch.chdir(tmp_path)
        metrics_dir = tmp_path / ".context" / "metrics"
        metrics_dir.mkdir(parents=True, exist_ok=True)

        before = self._count_existing_lines(metrics_dir)

        # Act
        verify("sqrt(2) * pi", source="all")

        # Assert
        after = self._count_existing_lines(metrics_dir)
        assert after - before == 1, (
            f"Expected exactly 1 new JSONL record, got {after - before}"
        )

    def test_t12_record_has_correct_event_and_category(self, tmp_path, monkeypatch):
        """T-12 (P0): AC-5 — record event=='math_verify' and category=='math-verify'."""
        _make_framework_yaml(tmp_path, enabled=True)
        monkeypatch.chdir(tmp_path)
        metrics_dir = tmp_path / ".context" / "metrics"
        metrics_dir.mkdir(parents=True, exist_ok=True)

        before = self._count_existing_lines(metrics_dir)

        verify("sqrt(2) * pi", source="all")

        records = self._read_new_records(metrics_dir, before)
        assert len(records) == 1
        record = records[0]
        assert record["event"] == "math_verify"
        assert record["category"] == "math-verify"

    def test_t13_record_data_has_domain_and_sources_used(self, tmp_path, monkeypatch):
        """T-13 (P0): AC-5 — record data contains domain (str) and sources_used (list)."""
        _make_framework_yaml(tmp_path, enabled=True)
        monkeypatch.chdir(tmp_path)
        metrics_dir = tmp_path / ".context" / "metrics"
        metrics_dir.mkdir(parents=True, exist_ok=True)

        before = self._count_existing_lines(metrics_dir)

        verify("sqrt(2) * pi", domain="calculus", source="all")

        records = self._read_new_records(metrics_dir, before)
        assert len(records) == 1
        data = records[0].get("data", {})
        assert "domain" in data, f"Expected 'domain' key in data, got: {data}"
        assert isinstance(data["domain"], str), (
            f"Expected domain to be str, got {type(data['domain'])}"
        )
        assert "sources_used" in data, f"Expected 'sources_used' key in data, got: {data}"
        assert isinstance(data["sources_used"], list), (
            f"Expected sources_used to be list, got {type(data['sources_used'])}"
        )

    def test_t14_record_data_ok_matches_verifyresult_ok(self, tmp_path, monkeypatch):
        """T-14 (P1): AC-5 — record data.ok matches the VerifyResult.ok returned."""
        _make_framework_yaml(tmp_path, enabled=True)
        monkeypatch.chdir(tmp_path)
        metrics_dir = tmp_path / ".context" / "metrics"
        metrics_dir.mkdir(parents=True, exist_ok=True)

        before = self._count_existing_lines(metrics_dir)

        result = verify("sqrt(2) * pi", source="all")

        records = self._read_new_records(metrics_dir, before)
        assert len(records) == 1
        data = records[0].get("data", {})
        assert "ok" in data, f"Expected 'ok' key in data, got: {data}"
        assert data["ok"] == result.ok, (
            f"data.ok ({data['ok']}) does not match VerifyResult.ok ({result.ok})"
        )


# ---------------------------------------------------------------------------
# AC-1 (REC 1) — Unevaluated symbolic form guard
# ---------------------------------------------------------------------------

class TestUnevaluatedFormGuard:
    """AC-1 (REC 1): verify() must detect unevaluated SymPy forms and set ok=False.

    Since Sum/Integral/Limit/Order are NOT yet in _ALLOWED_NAMES, these tests
    use unittest.mock.patch to inject a pre-constructed unevaluated SymPy
    expression into the post-parse result — isolating the guard logic from
    the AST whitelist (which is tested separately in TestSandboxEscape).

    The _UNEVALUATED_TYPES contract (from Interface Contracts):
        _UNEVALUATED_TYPES = (sympy.Sum, sympy.Integral, sympy.Limit, sympy.Order)
    Each test covers one of the four types.

    The expected caveat prefix (from AC-1 spec and Interface Contracts):
        "MATH-VERIFY-FLAG: result contains unevaluated symbolic forms"
    """

    _FLAG_PREFIX = "MATH-VERIFY-FLAG: result contains unevaluated symbolic forms"

    def _make_patcher_for_unevaluated(self, unevaluated_expr):
        """Return a context-manager that patches the parsed expression to
        `unevaluated_expr` inside verify.py's parse step.

        Patch target is `verify_math.parse_expr` — verify.py does
        `from sympy.parsing.sympy_parser import parse_expr` so the local
        binding inside the loaded module is what verify() calls. Patching
        `sympy.parse_expr` does NOT affect that local binding.
        """
        return patch.object(
            _verify_math_mod,
            "parse_expr",
            return_value=unevaluated_expr,
        )

    # ------------------------------------------------------------------
    # Happy-path guard: sympy.Sum triggers the flag
    # ------------------------------------------------------------------

    def test_unevaluated_sum_triggers_flag_in_caveats(self):
        """AC-1: sympy.Sum unevaluated form → caveats contain the MATH-VERIFY-FLAG prefix."""
        import sympy as _sp

        n = _sp.Symbol("n")
        unevaluated_sum = _sp.Sum(1 / n**5, (n, 1, _sp.oo))
        # Confirm our fixture is actually unevaluated (doit() is needed to resolve it).
        # If SymPy auto-evaluates this, skip — means the guard is untestable via this route.
        if not isinstance(unevaluated_sum, _sp.Sum):
            pytest.skip("sympy auto-evaluated the Sum — fixture no longer unevaluated")

        with self._make_patcher_for_unevaluated(unevaluated_sum):
            result = verify("integrate(x**2, x)", source="sympy")

        assert any(
            c.startswith(self._FLAG_PREFIX) for c in result.caveats
        ), (
            f"Expected caveat starting with {self._FLAG_PREFIX!r}; "
            f"got caveats={result.caveats}"
        )
        assert result.ok is False, (
            f"Expected ok=False when Sum is unevaluated; got ok={result.ok}"
        )

    # (test_unevaluated_sum_triggers_ok_false removed: the main test above
    # already asserts result.ok is False — duplicating the fixture only
    # creates a future-maintenance trap.)

    # ------------------------------------------------------------------
    # sympy.Integral triggers the flag
    # ------------------------------------------------------------------

    def test_unevaluated_integral_triggers_flag_in_caveats(self):
        """AC-1: sympy.Integral unevaluated form → caveats contain the MATH-VERIFY-FLAG prefix."""
        import sympy as _sp

        x = _sp.Symbol("x")
        # verify.py calls Integral.doit() at parse time. Use an Integral over
        # an undefined Function — doit() returns the same Integral unchanged
        # because there's nothing to evaluate. This stays unevaluated through
        # the entire verify pipeline.
        f = _sp.Function("f")
        unevaluated_integral = _sp.Integral(f(x), (x, 0, 1))
        if not isinstance(unevaluated_integral.doit(), _sp.Integral):
            pytest.skip("sympy reduced the Integral via doit() — fixture broken")

        with self._make_patcher_for_unevaluated(unevaluated_integral):
            result = verify("integrate(x**2, x)", source="sympy")

        assert any(
            c.startswith(self._FLAG_PREFIX) for c in result.caveats
        ), (
            f"Expected caveat starting with {self._FLAG_PREFIX!r}; "
            f"got caveats={result.caveats}"
        )
        assert result.ok is False

    # ------------------------------------------------------------------
    # sympy.Limit triggers the flag
    # ------------------------------------------------------------------

    def test_unevaluated_limit_triggers_flag_in_caveats(self):
        """AC-1: sympy.Limit unevaluated form → caveats contain the MATH-VERIFY-FLAG prefix."""
        import sympy as _sp

        x = _sp.Symbol("x")
        # sympy.Limit() does not auto-evaluate when constructed directly —
        # only .doit() or sympy.limit() (lowercase) compute the value.
        unevaluated_limit = _sp.Limit(_sp.sin(x) / x, x, 0)
        if not isinstance(unevaluated_limit, _sp.Limit):
            pytest.skip("sympy auto-evaluated the Limit — fixture no longer unevaluated")

        with self._make_patcher_for_unevaluated(unevaluated_limit):
            result = verify("integrate(x**2, x)", source="sympy")

        assert any(
            c.startswith(self._FLAG_PREFIX) for c in result.caveats
        ), (
            f"Expected caveat starting with {self._FLAG_PREFIX!r}; "
            f"got caveats={result.caveats}"
        )
        assert result.ok is False

    # ------------------------------------------------------------------
    # sympy.Order triggers the flag
    # ------------------------------------------------------------------

    def test_unevaluated_order_triggers_flag_in_caveats(self):
        """AC-1: sympy.Order (big-O term) → caveats contain the MATH-VERIFY-FLAG prefix."""
        import sympy as _sp

        x = _sp.Symbol("x")
        unevaluated_order = _sp.Order(x**3, x)
        if not isinstance(unevaluated_order, _sp.Order):
            pytest.skip("sympy auto-evaluated the Order — fixture no longer unevaluated")

        with self._make_patcher_for_unevaluated(unevaluated_order):
            result = verify("integrate(x**2, x)", source="sympy")

        assert any(
            c.startswith(self._FLAG_PREFIX) for c in result.caveats
        ), (
            f"Expected caveat starting with {self._FLAG_PREFIX!r}; "
            f"got caveats={result.caveats}"
        )
        assert result.ok is False

    # ------------------------------------------------------------------
    # CLI subprocess exits with code 3
    # ------------------------------------------------------------------

    def test_cli_exits_3_when_unevaluated_sum_detected(self):
        """AC-1: CLI invocation exits with code 3 when the unevaluated-form guard fires.

        Uses a wrapper that patches sympy.parse_expr to return an unevaluated Sum,
        then runs verify.py as __main__.
        """
        import sympy as _sp

        n = _sp.Symbol("n")
        unevaluated_sum = _sp.Sum(1 / n**5, (n, 1, _sp.oo))
        if not isinstance(unevaluated_sum, _sp.Sum):
            pytest.skip("sympy auto-evaluated the Sum — fixture no longer testable")

        # Build a wrapper script that patches parse_expr at its source module
        # (sympy.parsing.sympy_parser) BEFORE runpy executes verify.py — so
        # verify.py's `from sympy.parsing.sympy_parser import parse_expr`
        # resolves to our patched function.
        wrapper = (
            "import sys, sympy, runpy\n"
            "import sympy.parsing.sympy_parser\n"
            "import sympy as _sp\n"
            "_n = _sp.Symbol('n')\n"
            "_unevaled = _sp.Sum(1/_n**5, (_n, 1, _sp.oo))\n"
            "def _patched_parse(expr_str, **kwargs):\n"
            "    return _unevaled\n"
            "sympy.parsing.sympy_parser.parse_expr = _patched_parse\n"
            f"sys.argv = [{str(_MOD)!r}, 'integrate(x**2, x)']\n"
            f"runpy.run_path({str(_MOD)!r}, run_name='__main__')\n"
        )
        proc = subprocess.run(
            [sys.executable, "-c", wrapper],
            env={"PATH": os.environ["PATH"]},
            capture_output=True,
            text=True,
        )
        assert proc.returncode == 3, (
            f"Expected exit code 3 for unevaluated-form guard; "
            f"got {proc.returncode}. stdout={proc.stdout!r} stderr={proc.stderr!r}"
        )

    # ------------------------------------------------------------------
    # Embedded-in-expr: guard fires for subexpression containing unevaluated form
    # ------------------------------------------------------------------

    def test_unevaluated_form_nested_in_add_triggers_flag(self):
        """AC-1: guard fires even when the unevaluated type is nested inside an Add."""
        import sympy as _sp

        n = _sp.Symbol("n")
        # 1 + Sum(...) — the outer expression is Add, not Sum, but Sum is a subexpression.
        unevaluated_nested = 1 + _sp.Sum(1 / n**5, (n, 1, _sp.oo))

        with self._make_patcher_for_unevaluated(unevaluated_nested):
            result = verify("integrate(x**2, x)", source="sympy")

        assert any(
            c.startswith(self._FLAG_PREFIX) for c in result.caveats
        ), (
            f"Guard should fire for nested unevaluated Sum; got caveats={result.caveats}"
        )
        assert result.ok is False


# ---------------------------------------------------------------------------
# AC-3 (REC 2) — e and E bind to Euler's number, not a free symbol
# ---------------------------------------------------------------------------

class TestEulerNumberBinding:
    """AC-3 (REC 2): e and E in expressions must resolve to sympy.E (Euler's number).

    Before the fix, `e` was not in local_dict, so SymPy treated it as a free
    Symbol named 'e'. After the fix, `local_dict["e"] = sympy.E` and
    `local_dict["E"] = sympy.E` so `e**0 == 1`, `log(e) == 1`, and
    `E**1 == e (≈ 2.71828...)`.

    Note: `I` (imaginary unit) may not yet be in _ALLOWED_NAMES, so tests using
    Euler's identity `e**(I*pi) == -1` fall back to a skip-or-reject pattern.
    We test the fix via expressions that require only real-number algebra.
    """

    # ------------------------------------------------------------------
    # e**0 == 1  (simplest possible — any symbol to the 0 is 1, so this
    # distinguishes e-as-Euler vs e-as-free-symbol only if the numeric check
    # is also asserted; we assert symbolic_result == "1")
    # ------------------------------------------------------------------

    # (test_e_to_the_zero_gives_symbolic_one removed: any symbol raised to 0
    # gives 1, including a free symbol named 'e' — so the test passes whether
    # or not the e/E binding fix is applied. Non-discriminating; the
    # log_of_e and free_symbol_in_symbolic_result tests below are the real
    # discriminators for the binding fix.)

    # ------------------------------------------------------------------
    # log(e) == 1  — would be log(free_symbol) ≠ 1 if e were free
    # ------------------------------------------------------------------

    def test_log_of_e_gives_one(self):
        """AC-3: verify('log(e)') → symbolic_result is '1' (natural log of Euler's number)."""
        result = verify("log(e)", source="sympy")

        assert result.symbolic_result is not None, (
            "symbolic_result must not be None for log(e)"
        )
        assert result.symbolic_result.strip() == "1", (
            f"log(e) should give '1'; got {result.symbolic_result!r}. "
            "If 'e' is a free symbol, log(e) stays unevaluated — fix required."
        )
        assert result.ok is True

    # ------------------------------------------------------------------
    # E**1 should evaluate to Euler's number numerically (≈ 2.71828...)
    # ------------------------------------------------------------------

    def test_uppercase_E_one_gives_euler_numerically(self):
        """AC-3: verify('E**1') → numeric_result ≈ 2.71828... (not rejected as unknown name)."""
        import math

        result = verify("E**1", source="all")

        assert result.ok is True, (
            f"verify('E**1') should succeed; got ok={result.ok}, caveats={result.caveats}. "
            "If E is not in _ALLOWED_NAMES, it will be rejected — add E to the dict."
        )
        assert result.numeric_result is not None, (
            "numeric_result must not be None for E**1 with source='all'"
        )
        assert abs(result.numeric_result - math.e) < 1e-6, (
            f"E**1 numeric result should be ≈ {math.e}; got {result.numeric_result}"
        )

    # ------------------------------------------------------------------
    # e and E are consistent: verify("e**1") ≈ verify("E**1") numerically
    # ------------------------------------------------------------------

    def test_lowercase_e_and_uppercase_E_are_numerically_equivalent(self):
        """AC-3: verify('e**1') and verify('E**1') produce the same numeric result."""
        import math

        result_e = verify("e**1", source="all")
        result_E = verify("E**1", source="all")

        assert result_e.ok is True, (
            f"verify('e**1') failed: ok={result_e.ok}, caveats={result_e.caveats}"
        )
        assert result_E.ok is True, (
            f"verify('E**1') failed: ok={result_E.ok}, caveats={result_E.caveats}"
        )

        assert result_e.numeric_result is not None, "e**1 numeric_result is None"
        assert result_E.numeric_result is not None, "E**1 numeric_result is None"

        assert abs(result_e.numeric_result - result_E.numeric_result) < 1e-9, (
            f"e**1 ({result_e.numeric_result}) and E**1 ({result_E.numeric_result}) "
            "should produce identical numeric results — both must map to sympy.E"
        )

    # ------------------------------------------------------------------
    # Euler's identity variant not using I (avoids _ALLOWED_NAMES gap)
    # exp(I*pi) test: attempt it; if I is rejected, assert exp form works
    # and document the gap as a skip rather than a false PASS
    # ------------------------------------------------------------------

    def test_exp_of_I_pi_equals_neg_one_or_I_not_yet_allowed(self):
        """AC-3 (informational): exp(I*pi) should give -1 once I is in _ALLOWED_NAMES.

        If I is not yet whitelisted, verify() should reject it — this test
        documents the expected final behavior and will flip to PASS once I
        is added. It must NOT accidentally PASS by returning ok=False for the
        wrong reason (e.g., e-as-free-symbol error instead of I rejection).
        """
        result_exp = verify("exp(I*pi)", source="sympy")

        if result_exp.ok is False:
            # Expected in RED phase: I is not yet in _ALLOWED_NAMES.
            # Confirm the rejection is about I (or the expression), not about e/E binding.
            # Specifically: if ok=False and caveats mention e-as-free-symbol, that's the bug.
            assert not any(
                "free symbol" in c and ("e" in c or "E" in c) for c in result_exp.caveats
            ), (
                f"ok=False for exp(I*pi) must NOT be caused by e/E free-symbol issue; "
                f"caveats={result_exp.caveats}"
            )
            pytest.skip(
                "I (imaginary unit) not yet in _ALLOWED_NAMES — "
                "verify() correctly rejects exp(I*pi). "
                "This test will activate once I is whitelisted."
            )
        else:
            # Once I is allowed: the symbolic result should equal -1.
            assert result_exp.symbolic_result is not None
            assert result_exp.symbolic_result.strip() in ("-1", "-1 + 0*I", "(-1)"), (
                f"exp(I*pi) should give -1; got {result_exp.symbolic_result!r}"
            )

    def test_e_binding_does_not_produce_free_symbol_in_symbolic_result(self):
        """AC-3: verify('e**2') symbolic_result must not contain 'e' as a free symbol.

        If e is a free symbol, sympy leaves it as `e**2` (unevaluated string).
        After the fix, it becomes `exp(2)` or the float approximation string —
        either way it must NOT look like `e**2` where `e` is unresolved.
        """
        import sympy as _sp

        result = verify("e**2", source="sympy")

        assert result.ok is True, (
            f"verify('e**2') should succeed; got ok={result.ok}, caveats={result.caveats}"
        )
        assert result.symbolic_result is not None

        # Parse the symbolic result back through sympy to check for free symbols.
        try:
            parsed_back = _sp.sympify(result.symbolic_result)
            free_syms = parsed_back.free_symbols
            assert _sp.Symbol("e") not in free_syms, (
                f"symbolic_result {result.symbolic_result!r} still contains 'e' as a free symbol; "
                "local_dict['e'] = sympy.E fix was not applied"
            )
        except Exception:
            # If sympify fails on the result string, it's a different issue — let it raise.
            raise


# ---------------------------------------------------------------------------
# AC-5 — Wolfram fully gated on WOLFRAM_APP_ID
# ---------------------------------------------------------------------------

class TestWolframGating:
    """AC-5: Wolfram integration must be entirely gated on WOLFRAM_APP_ID env var.

    Without WOLFRAM_APP_ID set, source='wolfram' must return ok=False with a
    WOLFRAM-UNAVAILABLE caveat and MUST NOT make any network call.
    """

    def test_ac5_wolfram_source_without_app_id_returns_ok_false(self, monkeypatch):
        """AC-5 (P0): verify() with source='wolfram' and no WOLFRAM_APP_ID → ok=False."""
        # Arrange
        monkeypatch.delenv("WOLFRAM_APP_ID", raising=False)

        # Act
        result = verify("1+1", source="wolfram")

        # Assert
        assert result.ok is False, (
            f"source='wolfram' without WOLFRAM_APP_ID must return ok=False; "
            f"got ok={result.ok}"
        )

    def test_ac5_wolfram_source_without_app_id_emits_unavailable_caveat(self, monkeypatch):
        """AC-5 (P0): WOLFRAM-UNAVAILABLE caveat must start with the expected prefix."""
        # Arrange
        monkeypatch.delenv("WOLFRAM_APP_ID", raising=False)

        # Act
        result = verify("1+1", source="wolfram")

        # Assert
        prefix = "WOLFRAM-UNAVAILABLE: WOLFRAM_APP_ID env var not set"
        assert any(c.startswith(prefix) for c in result.caveats), (
            f"Expected a caveat starting with {prefix!r}; got caveats={result.caveats}"
        )

    def test_ac5_wolfram_source_without_app_id_never_calls_network(self, monkeypatch):
        """AC-5 explicit no-network requirement: urlopen must never be called."""
        import unittest.mock as _mock

        # Arrange
        monkeypatch.delenv("WOLFRAM_APP_ID", raising=False)

        with _mock.patch.object(
            _verify_math_mod, "urllib", create=True
        ) as _mock_urllib, _mock.patch(
            "urllib.request.urlopen"
        ) as mock_urlopen:
            # Act
            verify("1+1", source="wolfram")

            # Assert: urlopen must not have been called via the module-local path
            # (we also assert via the stdlib patch as belt-and-suspenders)
            assert mock_urlopen.call_count == 0, (
                f"urllib.request.urlopen was called {mock_urlopen.call_count} time(s) "
                "even though WOLFRAM_APP_ID is not set"
            )

    def test_ac5_cli_subprocess_exit_code_3_without_app_id(self, monkeypatch):
        """AC-5: CLI invocation without WOLFRAM_APP_ID must exit with code 3
        AND print WOLFRAM-UNAVAILABLE in stdout or stderr."""
        # Arrange — build an env without WOLFRAM_APP_ID
        clean_env = {k: v for k, v in os.environ.items() if k != "WOLFRAM_APP_ID"}

        # Act
        proc = subprocess.run(
            [sys.executable, str(_MOD), "1+1", "--source", "wolfram"],
            env=clean_env,
            capture_output=True,
            text=True,
        )

        # Assert
        assert proc.returncode == 3, (
            f"Expected exit code 3 for wolfram without WOLFRAM_APP_ID; "
            f"got {proc.returncode}. stdout={proc.stdout!r} stderr={proc.stderr!r}"
        )
        combined = proc.stdout + proc.stderr
        assert "WOLFRAM-UNAVAILABLE" in combined, (
            f"Expected 'WOLFRAM-UNAVAILABLE' in output; "
            f"got stdout={proc.stdout!r} stderr={proc.stderr!r}"
        )


# ---------------------------------------------------------------------------
# AC-6 — Wolfram unreachable / non-200 emits WOLFRAM-UNAVAILABLE;
#         primary path (SymPy + NumPy) still completes successfully
# ---------------------------------------------------------------------------

class TestWolframUnreachable:
    """AC-6: Network failures or non-200 responses from Wolfram must not break
    the primary verification path. A visible WOLFRAM-UNAVAILABLE line must appear.
    """

    def test_ac6_url_error_emits_unavailable_caveat_primary_path_ok(self, monkeypatch):
        """AC-6 (P0): URLError from _wolfram_query → WOLFRAM-UNAVAILABLE caveat,
        primary path result.ok is True, symbolic_result is not None."""
        import unittest.mock as _mock

        # Arrange
        monkeypatch.setenv("WOLFRAM_APP_ID", "test-key-12345")
        url_error_msg = "URLError: <urlopen error fake network failure>"

        with _mock.patch.object(
            _verify_math_mod,
            "_wolfram_query",
            return_value=(None, url_error_msg),
        ):
            # Act
            result = verify("sqrt(2) * pi", source="all")

        # Assert — primary path completed
        assert result.ok is True, (
            f"Primary SymPy+NumPy path must succeed even when Wolfram fails; "
            f"got ok={result.ok}, caveats={result.caveats}"
        )
        assert result.symbolic_result is not None, (
            "symbolic_result must be populated by the SymPy path"
        )
        # Assert — Wolfram failure is visible
        assert any("WOLFRAM-UNAVAILABLE" in c for c in result.caveats), (
            f"Expected 'WOLFRAM-UNAVAILABLE' caveat; got caveats={result.caveats}"
        )
        assert any("URLError" in c for c in result.caveats), (
            f"Expected the URLError reason in a caveat; got caveats={result.caveats}"
        )

    def test_ac6_http_403_emits_unavailable_caveat_primary_path_ok(self, monkeypatch):
        """AC-6: HTTP 403 / invalid AppID response → WOLFRAM-UNAVAILABLE, ok=True."""
        import unittest.mock as _mock

        # Arrange
        monkeypatch.setenv("WOLFRAM_APP_ID", "test-key-12345")
        http_error_msg = "HTTP 403: invalid AppID"

        with _mock.patch.object(
            _verify_math_mod,
            "_wolfram_query",
            return_value=(None, http_error_msg),
        ):
            # Act
            result = verify("sqrt(2) * pi", source="all")

        # Assert — primary path completed
        assert result.ok is True, (
            f"Primary path must succeed even on HTTP 403 from Wolfram; "
            f"got ok={result.ok}, caveats={result.caveats}"
        )
        assert result.symbolic_result is not None
        # Assert — failure reason visible
        assert any("WOLFRAM-UNAVAILABLE" in c for c in result.caveats), (
            f"Expected 'WOLFRAM-UNAVAILABLE' caveat; got caveats={result.caveats}"
        )

    def test_ac6_cli_exit_0_when_wolfram_fails_but_primary_succeeds(self, monkeypatch):
        """AC-6: CLI exit code must be 0 when Wolfram is unreachable but SymPy+NumPy pass."""
        # Arrange — set env var but mock _wolfram_query to simulate failure
        # via a wrapper that patches the module-local function before runpy
        wrapper = (
            "import sys, importlib.util, unittest.mock\n"
            f"spec = importlib.util.spec_from_file_location('verify_math', {str(_MOD)!r})\n"
            "mod = importlib.util.module_from_spec(spec)\n"
            "spec.loader.exec_module(mod)\n"
            "mod._wolfram_query = lambda expr, app_id, timeout=5.0: "
            "(None, 'URLError: simulated failure')\n"
            f"sys.argv = [{str(_MOD)!r}, 'sqrt(2) * pi', '--source', 'all']\n"
            "import runpy\n"
            "runpy.run_path("
            f"{str(_MOD)!r}, run_name='__main__')\n"
        )
        env = dict(os.environ)
        env["WOLFRAM_APP_ID"] = "test-key-12345"

        proc = subprocess.run(
            [sys.executable, "-c", wrapper],
            env=env,
            capture_output=True,
            text=True,
        )

        # Assert
        assert proc.returncode == 0, (
            f"Expected exit code 0 when Wolfram fails but primary path succeeds; "
            f"got {proc.returncode}. stdout={proc.stdout!r} stderr={proc.stderr!r}"
        )

    def test_ac6_wolfram_unavailable_appears_in_independent_check_section(self, monkeypatch):
        """AC-6: The WOLFRAM-UNAVAILABLE message must appear in caveats (not silently dropped)."""
        import unittest.mock as _mock

        # Arrange
        monkeypatch.setenv("WOLFRAM_APP_ID", "test-key-12345")

        with _mock.patch.object(
            _verify_math_mod,
            "_wolfram_query",
            return_value=(None, "connection refused"),
        ):
            result = verify("1 + 1", source="all")

        # The caveat list (which feeds the Independent Check section) must surface it
        assert len(result.caveats) > 0, "Expected at least one caveat when Wolfram fails"
        wolfram_caveats = [c for c in result.caveats if "WOLFRAM-UNAVAILABLE" in c]
        assert wolfram_caveats, (
            f"No WOLFRAM-UNAVAILABLE caveat found; caveats={result.caveats}"
        )


# ---------------------------------------------------------------------------
# AC-7 — Wolfram local call counter persists and warns at threshold
# ---------------------------------------------------------------------------

class TestWolframCallCounter:
    """AC-7: The local call counter JSON must be incremented on every Wolfram call
    and must emit WOLFRAM-QUOTA-WARN on stderr once the count exceeds 1600.
    """

    def _counter_file(self, tmp_path: Path) -> Path:
        """Return the expected counter file path under tmp_path."""
        return tmp_path / ".context" / "metrics" / "wolfram_calls.json"

    def _current_month_key(self) -> str:
        """Return 'YYYY-MM' for the current month."""
        from datetime import datetime
        return datetime.now().strftime("%Y-%m")

    def test_ac7_call_counter_increments_from_existing_value(
        self, monkeypatch, tmp_path
    ):
        """AC-7 (P0): Counter at 1599 increments to 1600 after one Wolfram call."""
        import unittest.mock as _mock

        # Arrange
        monkeypatch.chdir(tmp_path)
        monkeypatch.setenv("WOLFRAM_APP_ID", "test-key-12345")

        month_key = self._current_month_key()
        counter_file = self._counter_file(tmp_path)
        counter_file.parent.mkdir(parents=True, exist_ok=True)
        counter_file.write_text(json.dumps({month_key: 1599}))

        with _mock.patch.object(
            _verify_math_mod,
            "_wolfram_query",
            return_value=("8", None),
        ):
            # Act
            verify("4+4", source="wolfram")

        # Assert — counter file updated
        updated = json.loads(counter_file.read_text())
        assert updated.get(month_key) == 1600, (
            f"Expected counter {month_key}=1600; got {updated}"
        )

    def test_ac7_no_quota_warn_at_exactly_1600_calls(
        self, monkeypatch, tmp_path, capsys
    ):
        """AC-7: No WOLFRAM-QUOTA-WARN emitted when counter reaches exactly 1600
        (threshold is > 1600, not >= 1600)."""
        import unittest.mock as _mock

        # Arrange
        monkeypatch.chdir(tmp_path)
        monkeypatch.setenv("WOLFRAM_APP_ID", "test-key-12345")

        month_key = self._current_month_key()
        counter_file = self._counter_file(tmp_path)
        counter_file.parent.mkdir(parents=True, exist_ok=True)
        counter_file.write_text(json.dumps({month_key: 1599}))

        with _mock.patch.object(
            _verify_math_mod,
            "_wolfram_query",
            return_value=("8", None),
        ):
            result = verify("4+4", source="wolfram")

        # Assert — no warn, still succeeds
        captured = capsys.readouterr()
        assert "WOLFRAM-QUOTA-WARN" not in captured.err, (
            f"Unexpected WOLFRAM-QUOTA-WARN at exactly 1600 calls; "
            f"stderr={captured.err!r}"
        )
        assert result.ok is True

    def test_ac7_quota_warn_emitted_on_stderr_above_1600(
        self, monkeypatch, tmp_path, capsys
    ):
        """AC-7 (P0): WOLFRAM-QUOTA-WARN must appear on stderr when count exceeds 1600."""
        import unittest.mock as _mock

        # Arrange: start at 1600 so the next call brings it to 1601
        monkeypatch.chdir(tmp_path)
        monkeypatch.setenv("WOLFRAM_APP_ID", "test-key-12345")

        month_key = self._current_month_key()
        counter_file = self._counter_file(tmp_path)
        counter_file.parent.mkdir(parents=True, exist_ok=True)
        counter_file.write_text(json.dumps({month_key: 1600}))

        with _mock.patch.object(
            _verify_math_mod,
            "_wolfram_query",
            return_value=("8", None),
        ):
            result = verify("4+4", source="wolfram")

        # Assert — warn present on stderr
        captured = capsys.readouterr()
        assert "WOLFRAM-QUOTA-WARN" in captured.err, (
            f"Expected 'WOLFRAM-QUOTA-WARN' on stderr after exceeding 1600; "
            f"got stderr={captured.err!r}"
        )
        assert "1601/2000" in captured.err, (
            f"Expected '1601/2000' in warn message; got stderr={captured.err!r}"
        )
        # Primary result still succeeds
        assert result.ok is True, (
            f"Quota warning must not fail the call; got ok={result.ok}"
        )

    def test_ac7_counter_file_created_fresh_when_not_present(
        self, monkeypatch, tmp_path
    ):
        """AC-7: If no counter file exists, it is created and starts at 1."""
        import unittest.mock as _mock

        # Arrange
        monkeypatch.chdir(tmp_path)
        monkeypatch.setenv("WOLFRAM_APP_ID", "test-key-12345")

        month_key = self._current_month_key()
        counter_file = self._counter_file(tmp_path)
        # Ensure it does NOT exist
        assert not counter_file.exists(), "Test precondition: counter file must not exist"

        with _mock.patch.object(
            _verify_math_mod,
            "_wolfram_query",
            return_value=("2", None),
        ):
            verify("1+1", source="wolfram")

        # Assert
        assert counter_file.exists(), (
            f"Counter file was not created at {counter_file}"
        )
        data = json.loads(counter_file.read_text())
        assert data.get(month_key) == 1, (
            f"Expected counter {month_key}=1 on first call; got {data}"
        )


# ---------------------------------------------------------------------------
# AC-11 — SKILL.md documents Wolfram opt-in with quota caveat
# ---------------------------------------------------------------------------

_SKILL_MD_PATHS = [
    Path(__file__).parent.parent / ".claude" / "skills" / "verify-math" / "SKILL.md",
    Path(__file__).parent.parent
    / "src"
    / "shipteam"
    / "framework"
    / "skills"
    / "verify-math"
    / "SKILL.md",
]


class TestSafeAstAdditionsAC4:
    """AC-4 (REC 5a): six SAFE name additions — gamma, erf, floor, ceil, Min, Max.

    Per /deep-r REC 5a + A1 verdict table, these are SAFE-tier additions that
    require NO new AST node types and NO additional guards beyond the existing
    name-allowlist + local_dict binding. Each test confirms (a) the name
    resolves to its sympy primitive, (b) verification succeeds with a
    numerically correct answer.

    AC-4 also requires the existing AST-node tuple to be unchanged — covered
    by the test_ast_nodes_unchanged_after_phase_4 sandbox-non-regression test.
    """

    @pytest.mark.parametrize("expr,expected_str", [
        ("gamma(5)", "24"),       # Γ(5) = 4! = 24
        ("erf(0)", "0"),          # erf(0) = 0
        ("floor(7/2)", "3"),      # floor(3.5) = 3
        ("ceil(7/2)", "4"),       # ceiling(3.5) = 4
        ("Min(1, 2, 3)", "1"),
        ("Max(1, 2, 3)", "3"),
    ])
    def test_ac4_safe_name_evaluates_to_expected(self, expr, expected_str):
        """AC-4 (P0/P1): each new name resolves to its sympy primitive and
        produces the expected exact symbolic result."""
        result = verify(expr, source="sympy")
        assert result.ok is True, (
            f"verify({expr!r}) should succeed; got ok={result.ok}, caveats={result.caveats}"
        )
        assert result.symbolic_result is not None
        assert result.symbolic_result.strip() == expected_str, (
            f"verify({expr!r}) symbolic_result={result.symbolic_result!r}, "
            f"expected {expected_str!r}"
        )

    def test_ac4_ast_nodes_unchanged_after_phase_4(self):
        """AC-4 (P0): adding NAMES must NOT widen _ALLOWED_AST_NODES.

        REC 5a's safety claim depends on no new AST node types — only new
        identifiers in the existing Name + Call surface. If a future change
        accidentally adds e.g. ast.Compare or ast.Tuple, this test fails.
        """
        from ast import (
            Add, BinOp, Call, Constant, Div, Expression, FloorDiv, Load,
            Mod, Mult, Name, Pow, Sub, UAdd, UnaryOp, USub,
        )
        expected = (
            Expression, BinOp, UnaryOp, Constant, Name, Call, Load,
            Add, Sub, Mult, Div, Pow, Mod, USub, UAdd, FloorDiv,
        )
        actual = _verify_math_mod._ALLOWED_AST_NODES
        assert set(actual) == set(expected), (
            f"_ALLOWED_AST_NODES drift in Phase 4: "
            f"unexpected={set(actual) - set(expected)}, "
            f"missing={set(expected) - set(actual)}"
        )

    def test_ac4_disallowed_name_still_rejected(self):
        """REC 5a regression: a name OUTSIDE the new whitelist still rejects.

        Confirms that adding gamma/erf/floor/ceil/Min/Max didn't accidentally
        loosen the name-allowlist check. `factorial` is a deliberate
        deferred-Stage-5b name — must still reject in Phase 4."""
        result = verify("factorial(5)", source="sympy")
        assert result.ok is False, (
            "factorial is deferred to Stage 5b — must still reject in Phase 4"
        )
        assert any("disallowed name" in c for c in result.caveats), (
            f"factorial rejection should include 'disallowed name'; got {result.caveats}"
        )


class TestWolframSkillMdDocs:
    """AC-11: Both SKILL.md files must document the Wolfram opt-in, env var,
    quota caveat, and the vendor-reserves / adjust contractual-not-stable note.
    """

    @pytest.mark.parametrize("skill_md", _SKILL_MD_PATHS, ids=["primary", "bundle-mirror"])
    def test_ac11_skill_md_contains_install_instruction(self, skill_md: Path):
        """AC-11: SKILL.md must reference 'shipteam[verify]' install string."""
        assert skill_md.exists(), (
            f"SKILL.md not found at {skill_md}. "
            "This is expected in RED phase — file exists but content not updated yet."
        )
        content = skill_md.read_text()
        assert "shipteam[verify]" in content, (
            f"Expected 'shipteam[verify]' install instruction in {skill_md}; "
            "this was 'sympy numpy' before the Wolfram phase."
        )

    @pytest.mark.parametrize("skill_md", _SKILL_MD_PATHS, ids=["primary", "bundle-mirror"])
    def test_ac11_skill_md_contains_wolfram_app_id_env_var(self, skill_md: Path):
        """AC-11: SKILL.md must document the WOLFRAM_APP_ID env var name."""
        assert skill_md.exists(), f"SKILL.md not found at {skill_md}"
        content = skill_md.read_text()
        assert "WOLFRAM_APP_ID" in content, (
            f"Expected 'WOLFRAM_APP_ID' in {skill_md}; "
            "the opt-in env var must be documented."
        )

    @pytest.mark.parametrize("skill_md", _SKILL_MD_PATHS, ids=["primary", "bundle-mirror"])
    def test_ac11_skill_md_contains_quota_caveat(self, skill_md: Path):
        """AC-11: SKILL.md must state the 2,000 non-commercial quota (or equivalent)."""
        assert skill_md.exists(), f"SKILL.md not found at {skill_md}"
        content = skill_md.read_text()
        # Accept either "2,000 non-commercial" or equivalent quota statement
        has_quota = "2,000 non-commercial" in content or "2000 non-commercial" in content
        assert has_quota, (
            f"Expected '2,000 non-commercial' (or '2000 non-commercial') quota "
            f"statement in {skill_md}. This caveat comes from /deep-r vendor docs."
        )

    @pytest.mark.parametrize("skill_md", _SKILL_MD_PATHS, ids=["primary", "bundle-mirror"])
    def test_ac11_skill_md_contains_vendor_reserves_caveat(self, skill_md: Path):
        """AC-11: SKILL.md must include the contractual-not-stable caveat
        ('vendor reserves' or 'adjust')."""
        assert skill_md.exists(), f"SKILL.md not found at {skill_md}"
        content = skill_md.read_text()
        has_caveat = "vendor reserves" in content or "adjust" in content
        assert has_caveat, (
            f"Expected 'vendor reserves' or 'adjust' in {skill_md}; "
            "the doc must warn that Wolfram may change limits."
        )
