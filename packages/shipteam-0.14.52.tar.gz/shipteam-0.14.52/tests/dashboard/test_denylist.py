"""
DA-6, DA-7, DA-8 (all P0, AC-15) — ADR-007 denylist gate behavior.

TDD Phase A1 RED — this test file will fail at import with:
    ModuleNotFoundError: No module named 'dashboard'
That is the expected RED-phase failure.

== Denylist gate contract (ADR-007) ==

render_dashboard(
    input_jsonl: Path,
    output_html: Path,
    denylist_path: Path = Path("release/denylist.txt"),
) -> None

Raises RuntimeError on denylist violation BEFORE writing the output file.

== Word-boundary design decision (documented for denylist maintainers) ==

The gate uses r'\b{token}\b' with re.IGNORECASE (re.escape applied to the
token before embedding). Python re's \b treats hyphens as word-boundary
characters, so "pricing-model" WOULD fire on token "pricing". This is the
intended behavior: compound hyphenated forms are not permitted either.

Only embedded forms where no word-boundary exists between the token and
adjacent characters are safe — e.g. "repricing" (the 're' prefix joins
directly with no \b between 're' and 'pricing').

== Multi-word token behavior ==

Denylist tokens with internal spaces are matched with re.escape (which
escapes the space to a literal space). Tests use single-word tokens only
in this phase — multi-word tokens are covered in later phases.
"""
from pathlib import Path

import pytest

from dashboard.render import render_dashboard  # noqa: E402

_FIXTURE_DIR = Path(__file__).parent / "fixtures"
_FULL_CELL_JSONL = _FIXTURE_DIR / "full_cell.jsonl"


def _write_denylist(path: Path, tokens: list[str]) -> None:
    """Write tokens to a denylist file, one per line."""
    path.write_text("\n".join(tokens) + "\n", encoding="utf-8")


def _write_injected_html_jsonl(path: Path, content: str) -> None:
    """Write a minimal single-row JSONL whose rendered output will contain
    `content` in a field visible to the template — driver_version is used
    because it is a string field the template is expected to display.

    The row is otherwise valid per ResultRow schema.
    """
    import json
    row = {
        "driver": "claude_code",
        "driver_version": content,  # injected field — will appear in rendered HTML
        "task": "url_shortener",
        "task_pack_revision": "abc1234def5678",
        "seed": 0,
        "container_digest": "sha256:deadbeef" + "0" * 56,
        "harness_version": "0.1.0",
        "sdk_version": "0.1.15",
        "sdk_release_date": "2024-09-01",
        "timestamp_utc": "2024-09-15T12:00:00Z",
        "wall_clock_ms": 45000,
        "input_tokens": 500,
        "output_tokens": 250,
        "cost_usd": 0.0075,
        "cost_source": "native",
        "acceptance_pct": 0.8,
        "mutation_score": {"python": {"killed": 8, "survived": 2, "timeout": 0, "score": 0.8}},
        "semgrep_high": 0,
        "semgrep_critical": 0,
        "injected_bug_detections": 3,
        "aborted": False,
        "abort_reason": None,
        "rate_limited_during_run": False,
        "cache_strategy": "omitted",
        "driver_metadata": {"cache_strategy": "omitted", "cache_read_input_tokens": 0},
    }
    path.write_text(json.dumps(row) + "\n", encoding="utf-8")


class TestDenylistGate:
    """DA-6: RuntimeError raised and output file absent when denylist token found."""

    def test_da6_denylist_token_present_raises_runtime_error(
        self, tmp_path: Path
    ) -> None:
        """DA-6 (P0, AC-15): When rendered HTML contains a denylist token,
        render_dashboard raises RuntimeError and does NOT write the output file.

        Oracle: gate fires → RuntimeError; output_path does not exist.
        """
        input_jsonl = tmp_path / "input.jsonl"
        # Inject "pricing" as a value that will appear verbatim in the template output.
        _write_injected_html_jsonl(input_jsonl, content="pricing")

        output_html = tmp_path / "dashboard.html"
        denylist_path = tmp_path / "denylist.txt"
        _write_denylist(denylist_path, ["pricing"])

        with pytest.raises(RuntimeError):
            render_dashboard(
                input_jsonl=input_jsonl,
                output_html=output_html,
                denylist_path=denylist_path,
            )

        assert not output_html.exists(), (
            "Output file must NOT be written when a denylist violation is detected "
            "(gate must fire before the file is persisted)"
        )

    def test_da6_clean_html_does_not_raise(self, tmp_path: Path) -> None:
        """DA-6 negative sample: clean content passes the gate without raising."""
        output_html = tmp_path / "dashboard.html"
        denylist_path = tmp_path / "denylist.txt"
        _write_denylist(denylist_path, ["pricing"])

        # full_cell.jsonl contains no denylist tokens — should render cleanly.
        render_dashboard(
            input_jsonl=_FULL_CELL_JSONL,
            output_html=output_html,
            denylist_path=denylist_path,
        )

        assert output_html.exists(), (
            "Output file must be written when no denylist token appears in the HTML"
        )


class TestDenylistWordBoundary:
    """DA-7: Word-boundary oracle — compound forms do not fire; standalone does."""

    def test_da7_compound_word_repricing_does_not_fire(
        self, tmp_path: Path
    ) -> None:
        """DA-7 (P0, AC-15) sub-case (a): The compound word 'repricing' must NOT
        trigger the denylist token 'pricing'.

        The 're' prefix is joined directly to 'pricing' with no word boundary
        between them, so \\bpricing\\b must not match inside 'repricing'.
        """
        input_jsonl = tmp_path / "input.jsonl"
        # Inject "repricing" — contains "pricing" as a substring but not a
        # standalone word; \bpricing\b must NOT match.
        _write_injected_html_jsonl(input_jsonl, content="repricing")

        output_html = tmp_path / "dashboard.html"
        denylist_path = tmp_path / "denylist.txt"
        _write_denylist(denylist_path, ["pricing"])

        # Must NOT raise — "repricing" is not a word-boundary match for "pricing".
        render_dashboard(
            input_jsonl=input_jsonl,
            output_html=output_html,
            denylist_path=denylist_path,
        )

        assert output_html.exists(), (
            "Output file must be written when only 'repricing' appears — "
            "'\\bpricing\\b' must not match inside a compound form"
        )

    def test_da7_standalone_pricing_fires(self, tmp_path: Path) -> None:
        """DA-7 (P0, AC-15) sub-case (b): The standalone word 'pricing' MUST
        trigger the denylist token 'pricing'.

        Both sub-cases (a) and (b) must hold simultaneously to confirm correct
        \\b word-boundary behavior.
        """
        input_jsonl = tmp_path / "input.jsonl"
        _write_injected_html_jsonl(input_jsonl, content="pricing")

        output_html = tmp_path / "dashboard.html"
        denylist_path = tmp_path / "denylist.txt"
        _write_denylist(denylist_path, ["pricing"])

        with pytest.raises(RuntimeError):
            render_dashboard(
                input_jsonl=input_jsonl,
                output_html=output_html,
                denylist_path=denylist_path,
            )


class TestDenylistCaseInsensitive:
    """DA-8: Case-insensitive oracle — mixed-case forms all fire; embedded does not."""

    def test_da8_lowercase_competitor_fires(self, tmp_path: Path) -> None:
        """DA-8 (P0, AC-15): Denylist contains 'Competitor' (mixed-case in file).
        HTML contains 'competitor' (lowercase). Gate must fire.
        """
        input_jsonl = tmp_path / "input.jsonl"
        _write_injected_html_jsonl(input_jsonl, content="competitor")

        output_html = tmp_path / "dashboard.html"
        denylist_path = tmp_path / "denylist.txt"
        _write_denylist(denylist_path, ["Competitor"])

        with pytest.raises(RuntimeError):
            render_dashboard(
                input_jsonl=input_jsonl,
                output_html=output_html,
                denylist_path=denylist_path,
            )

    def test_da8_uppercase_competitor_fires(self, tmp_path: Path) -> None:
        """DA-8 (P0, AC-15): HTML contains 'COMPETITOR' (uppercase). Gate must fire."""
        input_jsonl = tmp_path / "input.jsonl"
        _write_injected_html_jsonl(input_jsonl, content="COMPETITOR")

        output_html = tmp_path / "dashboard.html"
        denylist_path = tmp_path / "denylist.txt"
        _write_denylist(denylist_path, ["Competitor"])

        with pytest.raises(RuntimeError):
            render_dashboard(
                input_jsonl=input_jsonl,
                output_html=output_html,
                denylist_path=denylist_path,
            )

    def test_da8_embedded_subcompetitor_does_not_fire(
        self, tmp_path: Path
    ) -> None:
        """DA-8 (P0, AC-15): HTML contains 'subcompetitor' (token embedded inside
        a longer word). Word-boundary enforcement means this must NOT fire.

        The 'sub' prefix joins directly to 'competitor' — no \\b between them.
        """
        input_jsonl = tmp_path / "input.jsonl"
        _write_injected_html_jsonl(input_jsonl, content="subcompetitor")

        output_html = tmp_path / "dashboard.html"
        denylist_path = tmp_path / "denylist.txt"
        _write_denylist(denylist_path, ["Competitor"])

        # Must NOT raise — 'subcompetitor' has no word boundary before 'competitor'.
        render_dashboard(
            input_jsonl=input_jsonl,
            output_html=output_html,
            denylist_path=denylist_path,
        )

        assert output_html.exists(), (
            "Output file must be written when only 'subcompetitor' appears — "
            "'\\bCompetitor\\b' (case-insensitive) must not match inside a compound form"
        )


class TestDenylistUnicodeAndHyphen:
    """DA-15/DA-16: Unicode/ZWSP bypass attempts and hyphen word-boundary lock-in."""

    # ------------------------------------------------------------------
    # DA-15 (P0, AC-15, SECURITY-CRITICAL) — Unicode/ZWSP bypass attempts
    # ------------------------------------------------------------------
    @pytest.mark.parametrize(
        "bypass_version",
        [
            "рricing",   # (a) U+0440 CYRILLIC SMALL LETTER ER replaces Latin 'p'
            "pri​cing",  # (b) U+200B ZERO WIDTH SPACE between 'pri' and 'cing'
            "pri cing",       # (c) literal ASCII space between 'pri' and 'cing'
        ],
        ids=["cyrillic_lookalike", "zero_width_space", "literal_space"],
    )
    def test_da15_unicode_bypass_attempts_raise_runtime_error(
        self, tmp_path: Path, bypass_version: str
    ) -> None:
        """DA-15 (P0, AC-15, SECURITY-CRITICAL): Unicode lookalike, zero-width
        space, and ASCII space bypass attempts all raise RuntimeError when the
        denylist token is 'pricing', and the exception message contains 'pricing'.

        Normalization must canonicalize these forms before matching so that
        lookalike and invisible-character bypasses are blocked.
        """
        input_jsonl = tmp_path / "input.jsonl"
        _write_injected_html_jsonl(input_jsonl, content=bypass_version)

        output_html = tmp_path / "dashboard.html"
        denylist_path = tmp_path / "denylist.txt"
        _write_denylist(denylist_path, ["pricing"])

        with pytest.raises(RuntimeError) as exc_info:
            render_dashboard(
                input_jsonl=input_jsonl,
                output_html=output_html,
                denylist_path=denylist_path,
            )

        assert "pricing" in str(exc_info.value).lower(), (
            "RuntimeError message must contain 'pricing' so operators know which "
            "denylist token triggered the gate"
        )

    def test_da15_repricing_compound_does_not_raise(
        self, tmp_path: Path
    ) -> None:
        """DA-15 companion absence (P0, AC-15): 'repricing' (legitimate compound
        word with no word boundary between 're' and 'pricing') must NOT trigger
        the 'pricing' denylist token — proving normalization preserves
        word-boundary semantics and does not over-block compound words.
        """
        input_jsonl = tmp_path / "input.jsonl"
        _write_injected_html_jsonl(input_jsonl, content="repricing")

        output_html = tmp_path / "dashboard.html"
        denylist_path = tmp_path / "denylist.txt"
        _write_denylist(denylist_path, ["pricing"])

        # Must NOT raise — 'repricing' has no word boundary before 'pricing'.
        render_dashboard(
            input_jsonl=input_jsonl,
            output_html=output_html,
            denylist_path=denylist_path,
        )

        assert output_html.exists(), (
            "Output file must be written when only 'repricing' appears — "
            "normalization must not cause \\bpricing\\b to match inside a compound"
        )

    # ------------------------------------------------------------------
    # DA-16 (P1, AC-15) — Hyphen word-boundary lock-in
    # ------------------------------------------------------------------
    def test_da16_hyphenated_form_fires_on_denylist_token(
        self, tmp_path: Path
    ) -> None:
        """DA-16 (P1, AC-15): 'pricing-model' fires on the denylist token
        'pricing' because Python re treats '-' as a word-boundary character,
        so \\bpricing\\b matches 'pricing' inside 'pricing-model'.

        Locks intentional \\b behavior; swapping to PyPI 'regex' module or
        using \\W would silently regress this.
        """
        input_jsonl = tmp_path / "input.jsonl"
        _write_injected_html_jsonl(input_jsonl, content="pricing-model")

        output_html = tmp_path / "dashboard.html"
        denylist_path = tmp_path / "denylist.txt"
        _write_denylist(denylist_path, ["pricing"])

        with pytest.raises(RuntimeError) as exc_info:
            render_dashboard(
                input_jsonl=input_jsonl,
                output_html=output_html,
                denylist_path=denylist_path,
            )

        assert "pricing" in str(exc_info.value).lower(), (
            "RuntimeError message must contain 'pricing' — hyphenated compound "
            "forms must fire on the denylist token at the hyphen word-boundary"
        )
