"""
DA-1 (P0, AC-10 (a)) — Full-cell fixture renders median + IQR values.
DA-2 (P0, AC-10 (b)) — Partial-cell fixture produces a visible partial-cell warning marker.
DA-3 (P0, AC-10 (c)) — Mixed container_digest within one cell produces a dual-surface warning.
DA-4 (P0, AC-10 (c)) — Clean digest produces NO digest-mismatch warnings (absence oracle).
DA-5 (P1, AC-10 (c)) — Mixed sdk_version within one cell produces a dual-surface warning.
DA-14 (P1, AC-10 (b)) — Aborted rows excluded from median; partial-cell marker fires (n=7 < 10).
DA-9 (P0, AC-15) — Atomic write: denylist violation raises RuntimeError before any file is created.
DA-10 (P0, AC-15) — Missing denylist file raises FileNotFoundError; no output written (fail-closed).
DA-11 (P1, AC-15.A4.1) — Empty denylist raises ValueError (fail-closed); no output written.
DA-12 (P1, AC-10) — Malformed rows (missing 'driver' key) are filtered with a banner; valid rows render.
DA-13 (P0, AC-10) — Jinja2 autoescape encodes HTML-special chars; literal <script> tag never appears.

== Hand-computed expected values for full_cell.jsonl ==

The fixture contains 10 rows (seeds 0-9), all non-aborted, single cell
(driver="claude_code", task="url_shortener").

Percentile implementation: linear interpolation matching aggregation/_percentile.
For n=10 values sorted ascending, index = pct/100 * (n-1).

acceptance_pct values: [0.0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9]
  median (p50): idx = 0.50 * 9 = 4.5 → 0.4 + 0.5*(0.5-0.4) = 0.45
  p25:          idx = 0.25 * 9 = 2.25 → 0.2 + 0.25*(0.3-0.2) = 0.225
  p75:          idx = 0.75 * 9 = 6.75 → 0.6 + 0.75*(0.7-0.6) = 0.675

wall_clock_ms values: [10000, 20000, 30000, 40000, 50000, 60000, 70000, 80000, 90000, 100000]
  median (p50): idx = 4.5 → 50000 + 0.5*10000 = 55000.0
  p25:          idx = 2.25 → 30000 + 0.25*10000 = 32500.0
  p75:          idx = 6.75 → 70000 + 0.75*10000 = 77500.0

cost_usd values: [0.001, 0.002, 0.003, 0.004, 0.005, 0.006, 0.007, 0.008, 0.009, 0.010]
  median (p50): idx = 4.5 → 0.005 + 0.5*0.001 = 0.0055
  p25:          idx = 2.25 → 0.003 + 0.25*0.001 = 0.00325
  p75:          idx = 6.75 → 0.007 + 0.75*0.001 = 0.00775

All assertions use pytest.approx(abs=1e-9) to handle IEEE 754 float representation.
"""
import json
import re
from pathlib import Path

import pytest

from dashboard.render import render_dashboard  # noqa: E402


_METRICS_IN_ORDER = ("acceptance_pct", "wall_clock_ms", "cost_usd")


def _assert_metric_row(html: str, metric: str, p25: str, median: str, p75: str) -> None:
    """Assert that `metric` label appears in the HTML followed by p25/median/p75
    in that order, WITHIN the segment bounded by this metric's label and the
    next metric's label (or end of html). The segment bound prevents DOTALL
    `.*?` from bleeding across `</tr><tr>` and matching values that belong to
    a later metric row — that failure mode would let a render bug that emits
    the wrong percentile under a given label still pass the assertion.
    """
    start = html.find(metric)
    assert start != -1, f"HTML must contain metric label {metric!r}. Snippet: {html[:500]!r}"
    next_starts = [html.find(m, start + len(metric)) for m in _METRICS_IN_ORDER if m != metric]
    next_starts = [i for i in next_starts if i != -1]
    end = min(next_starts) if next_starts else len(html)
    segment = html[start:end]
    pattern = rf"{re.escape(p25)}.*?{re.escape(median)}.*?{re.escape(p75)}"
    assert re.search(pattern, segment, re.DOTALL), (
        f"HTML segment for '{metric}' must contain p25={p25}, median={median}, p75={p75} "
        f"in order. Segment: {segment!r}"
    )

_FIXTURE_DIR = Path(__file__).parent / "fixtures"
_FULL_CELL_JSONL = _FIXTURE_DIR / "full_cell.jsonl"
_PARTIAL_CELL_JSONL = _FIXTURE_DIR / "partial_cell.jsonl"
_MIXED_DIGEST_JSONL = _FIXTURE_DIR / "mixed_digest.jsonl"
_MIXED_SDK_JSONL = _FIXTURE_DIR / "mixed_sdk.jsonl"
_ABORTED_ROWS_JSONL = _FIXTURE_DIR / "aborted_rows.jsonl"

# Hand-computed constants (see module docstring above for derivation)
_ACCEPTANCE_PCT_MEDIAN = 0.45
_ACCEPTANCE_PCT_P25 = 0.225
_ACCEPTANCE_PCT_P75 = 0.675

_WALL_CLOCK_MS_MEDIAN = 55_000.0
_WALL_CLOCK_MS_P25 = 32_500.0
_WALL_CLOCK_MS_P75 = 77_500.0

_COST_USD_MEDIAN = 0.0055
_COST_USD_P25 = 0.00325
_COST_USD_P75 = 0.00775

#: Non-matching sentinel for tests where the denylist must be NON-EMPTY (per the
#: A4 fail-closed policy in dashboard.render._load_denylist) but should not
#: actually trigger any violation against the test fixtures' content. Two tests
#: do NOT use this constant: DA-11 writes a literal empty file (it tests the
#: empty-denylist ValueError path itself), and DA-9 writes a specific banned
#: token (it tests the violation path). All other tests in this module use this
#: sentinel as a no-op denylist that satisfies the gate without firing it.
_NO_MATCH_DENYLIST = "__test-sentinel-never-matches-real-content__\n"


class TestRenderDashboard:
    """DA-1: Full-cell fixture renders median + IQR for AC-10 (a) metrics."""

    def test_da1_full_cell_renders_acceptance_pct_median_and_iqr(
        self, tmp_path: Path
    ) -> None:
        """DA-1 (P0, AC-10 (a)): render_dashboard writes HTML containing the
        hand-computed median, p25, and p75 for acceptance_pct.

        The rendered HTML must contain the numeric values as strings to satisfy
        the 'renders per-cell median+IQR' requirement. We check formatted
        representation consistent with rounding to 3 decimal places.
        """
        output_html = tmp_path / "dashboard.html"
        denylist_path = tmp_path / "denylist.txt"
        # Non-matching sentinel — this test is about rendering, not the denylist
        # gate. Empty would trip the A4 fail-closed policy and raise ValueError.
        denylist_path.write_text(_NO_MATCH_DENYLIST, encoding="utf-8")

        render_dashboard(
            input_jsonl=_FULL_CELL_JSONL,
            output_html=output_html,
            denylist_path=denylist_path,
        )

        assert output_html.exists(), "render_dashboard must write the output file"
        html = output_html.read_text(encoding="utf-8")

        # The cell key must appear in the output to confirm grouping occurred.
        assert "claude_code" in html, (
            "Rendered HTML must name the driver to confirm (driver, task) grouping"
        )
        assert "url_shortener" in html, (
            "Rendered HTML must name the task to confirm (driver, task) grouping"
        )

        # acceptance_pct: p25=0.225, median=0.45, p75=0.675 — anchored to the
        # label to reject an implementation that emits values without the row.
        _assert_metric_row(html, "acceptance_pct", "0.225", "0.45", "0.675")

    def test_da1_full_cell_renders_wall_clock_ms_median_and_iqr(
        self, tmp_path: Path
    ) -> None:
        """DA-1 (P0, AC-10 (a)): wall_clock_ms median + IQR in rendered HTML."""
        output_html = tmp_path / "dashboard.html"
        denylist_path = tmp_path / "denylist.txt"
        denylist_path.write_text(_NO_MATCH_DENYLIST, encoding="utf-8")

        render_dashboard(
            input_jsonl=_FULL_CELL_JSONL,
            output_html=output_html,
            denylist_path=denylist_path,
        )

        assert output_html.exists(), "render_dashboard must write the output file"
        html = output_html.read_text(encoding="utf-8")

        # wall_clock_ms: p25=32500, median=55000, p75=77500 — anchored to label.
        _assert_metric_row(html, "wall_clock_ms", "32500", "55000", "77500")

    def test_da1_full_cell_renders_cost_usd_median_and_iqr(
        self, tmp_path: Path
    ) -> None:
        """DA-1 (P0, AC-10 (a)): cost_usd median + IQR in rendered HTML."""
        output_html = tmp_path / "dashboard.html"
        denylist_path = tmp_path / "denylist.txt"
        denylist_path.write_text(_NO_MATCH_DENYLIST, encoding="utf-8")

        render_dashboard(
            input_jsonl=_FULL_CELL_JSONL,
            output_html=output_html,
            denylist_path=denylist_path,
        )

        assert output_html.exists(), "render_dashboard must write the output file"
        html = output_html.read_text(encoding="utf-8")

        # cost_usd: p25=0.00325, median=0.0055, p75=0.00775 — anchored to label.
        _assert_metric_row(html, "cost_usd", "0.00325", "0.0055", "0.00775")

    def test_da1_full_cell_does_not_emit_partial_marker(
        self, tmp_path: Path
    ) -> None:
        """DA-1 (P0, AC-10 (a)): n=10 full cell must NOT emit any partial-cell
        warning marker. This is a negative-sample guard: the full-cell fixture
        must not accidentally trigger the partial-cell path.
        """
        output_html = tmp_path / "dashboard.html"
        denylist_path = tmp_path / "denylist.txt"
        denylist_path.write_text(_NO_MATCH_DENYLIST, encoding="utf-8")

        render_dashboard(
            input_jsonl=_FULL_CELL_JSONL,
            output_html=output_html,
            denylist_path=denylist_path,
        )

        html = output_html.read_text(encoding="utf-8")

        # Use the stable data-qa marker (matches DA-3/DA-4/DA-5 oracle pattern).
        assert 'data-qa="partial-cell"' not in html, (
            "Full-cell (n=10, no aborts) must not render any partial-cell marker"
        )

    # ------------------------------------------------------------------
    # DA-2 (P0, AC-10 (b)) — Partial-cell fixture emits partial marker
    # ------------------------------------------------------------------
    def test_da2_partial_cell_emits_partial_marker(
        self, tmp_path: Path
    ) -> None:
        """DA-2 (P0, AC-10 (b)): n=3 partial-cell fixture renders a visible
        partial-cell warning marker. Paired with
        test_da1_full_cell_does_not_emit_partial_marker as a differential
        absence/presence oracle — together they lock the contract that the
        partial marker fires if-and-only-if effective n < 10.
        """
        output_html = tmp_path / "dashboard.html"
        denylist_path = tmp_path / "denylist.txt"
        denylist_path.write_text(_NO_MATCH_DENYLIST, encoding="utf-8")

        render_dashboard(
            input_jsonl=_PARTIAL_CELL_JSONL,
            output_html=output_html,
            denylist_path=denylist_path,
        )

        html = output_html.read_text(encoding="utf-8")

        assert 'data-qa="partial-cell"' in html, (
            "Partial-cell fixture (n=3) must render a data-qa=\"partial-cell\" "
            "marker so readers can distinguish low-n cells from full cells"
        )
        # partial_cell.jsonl has uniform digest and uniform sdk — the only
        # marker that should fire is partial-cell. If a template bug coupled
        # the partial-cell branch to mixed-metadata detection, one of these
        # would fire and catch the regression.
        for marker in (
            'data-qa="digest-banner"',
            'data-qa="digest-badge"',
            'data-qa="sdk-banner"',
            'data-qa="sdk-badge"',
        ):
            assert marker not in html, (
                f"{marker} must NOT fire on a uniform-metadata partial-cell fixture"
            )

    # ------------------------------------------------------------------
    # DA-3 (P0, AC-10 (c)) — Mixed container_digest, dual-surface warning
    # ------------------------------------------------------------------
    def test_da3_mixed_container_digest_emits_banner_and_badge(
        self, tmp_path: Path
    ) -> None:
        """DA-3 (P0, AC-10 (c)): mixed_digest fixture (10 rows, two distinct
        container_digest values in the same cell) produces BOTH a top-of-page
        red banner AND a per-cell inline badge — the dual-surface contract
        specified by AC-10 (c) and the .test-matrix.md Oracle Strategy.

        Two surfaces must be asserted with position checks (banner outside
        any <section>, badge inside a <section>) so an implementation that
        emits only one surface, or both tags in the wrong location, fails.
        """
        output_html = tmp_path / "dashboard.html"
        denylist_path = tmp_path / "denylist.txt"
        denylist_path.write_text(_NO_MATCH_DENYLIST, encoding="utf-8")

        render_dashboard(
            input_jsonl=_MIXED_DIGEST_JSONL,
            output_html=output_html,
            denylist_path=denylist_path,
        )

        html = output_html.read_text(encoding="utf-8")

        # Top-of-page banner: must appear BEFORE the first <section>.
        banner_idx = html.find('data-qa="digest-banner"')
        assert banner_idx != -1, (
            "mixed_digest must emit data-qa=\"digest-banner\" at the top of "
            "the page; missing marker would hide the warning"
        )
        first_section_idx = html.find("<section")
        assert first_section_idx != -1, "Rendered HTML must contain at least one <section>"
        assert banner_idx < first_section_idx, (
            "digest-banner must appear OUTSIDE (above) any cell <section> so "
            "it is visible before the reader scrolls into cells"
        )

        # Banner must reference the cell key — the plan requires naming the
        # affected cell(s) so readers know which cell mixes digests.
        # Take a window around the banner tag (up to 400 chars) as its text body.
        banner_snippet = html[banner_idx : banner_idx + 400]
        assert "claude_code" in banner_snippet, (
            "digest-banner must name the affected driver (claude_code)"
        )
        assert "url_shortener" in banner_snippet, (
            "digest-banner must name the affected task (url_shortener)"
        )

        # Per-cell badge: must appear INSIDE a <section> (not just anywhere).
        badge_idx = html.find('data-qa="digest-badge"')
        assert badge_idx != -1, (
            "mixed_digest must emit data-qa=\"digest-badge\" inside the cell "
            "section — inline proof-at-point-of-reading"
        )
        section_open_before_badge = html.rfind("<section", 0, badge_idx)
        section_close_after_badge = html.find("</section>", badge_idx)
        assert section_open_before_badge != -1, (
            "digest-badge must be inside a <section>, but no <section> opens "
            "before the badge"
        )
        assert section_close_after_badge != -1, (
            "digest-badge must be inside a <section>, but no </section> closes "
            "after the badge"
        )
        assert section_open_before_badge < badge_idx < section_close_after_badge, (
            "digest-badge position is outside <section>...</section> — badge "
            "must render inline with the cell's own metrics"
        )

    # ------------------------------------------------------------------
    # DA-4 (P0, AC-10 (c)) — Clean digest: neither surface fires
    # ------------------------------------------------------------------
    def test_da4_clean_digest_emits_no_digest_warning(
        self, tmp_path: Path
    ) -> None:
        """DA-4 (P0, AC-10 (c)): full_cell fixture (all rows share one digest)
        must render NO digest-banner and NO digest-badge. Prevents the
        false-positive regression where a template edit accidentally embeds
        a warning on all cells.
        """
        output_html = tmp_path / "dashboard.html"
        denylist_path = tmp_path / "denylist.txt"
        denylist_path.write_text(_NO_MATCH_DENYLIST, encoding="utf-8")

        render_dashboard(
            input_jsonl=_FULL_CELL_JSONL,
            output_html=output_html,
            denylist_path=denylist_path,
        )

        html = output_html.read_text(encoding="utf-8")

        assert 'data-qa="digest-banner"' not in html, (
            "Clean-digest cell must NOT emit digest-banner — a fire here "
            "means the warning triggers spuriously on uniform-digest cells"
        )
        assert 'data-qa="digest-badge"' not in html, (
            "Clean-digest cell must NOT emit digest-badge — a fire here "
            "means the badge triggers spuriously on uniform-digest cells"
        )
        # full_cell.jsonl also has uniform sdk_version — the sdk surface must
        # likewise stay silent, otherwise a hardcoded mixed_sdk=True bug in
        # the template would slip past DA-4's digest-only oracle.
        assert 'data-qa="sdk-banner"' not in html, (
            "Clean-sdk cell must NOT emit sdk-banner — a fire here "
            "means the warning triggers spuriously on uniform-sdk cells"
        )
        assert 'data-qa="sdk-badge"' not in html, (
            "Clean-sdk cell must NOT emit sdk-badge — a fire here "
            "means the badge triggers spuriously on uniform-sdk cells"
        )

    # ------------------------------------------------------------------
    # DA-5 (P1, AC-10 (c)) — Mixed sdk_version, dual-surface warning
    # ------------------------------------------------------------------
    def test_da5_mixed_sdk_version_emits_banner_and_badge(
        self, tmp_path: Path
    ) -> None:
        """DA-5 (P1, AC-10 (c)): mixed_sdk fixture (10 rows, two distinct
        sdk_version values in the same cell) produces BOTH a top-of-page
        red banner AND a per-cell inline badge. Parallel structure to DA-3
        but on the sdk_version axis.
        """
        output_html = tmp_path / "dashboard.html"
        denylist_path = tmp_path / "denylist.txt"
        denylist_path.write_text(_NO_MATCH_DENYLIST, encoding="utf-8")

        render_dashboard(
            input_jsonl=_MIXED_SDK_JSONL,
            output_html=output_html,
            denylist_path=denylist_path,
        )

        html = output_html.read_text(encoding="utf-8")

        # Top-of-page sdk-banner before any <section>.
        banner_idx = html.find('data-qa="sdk-banner"')
        assert banner_idx != -1, (
            "mixed_sdk must emit data-qa=\"sdk-banner\" at top of page"
        )
        first_section_idx = html.find("<section")
        assert first_section_idx != -1, "Rendered HTML must contain at least one <section>"
        assert banner_idx < first_section_idx, (
            "sdk-banner must appear OUTSIDE (above) any cell <section>"
        )

        banner_snippet = html[banner_idx : banner_idx + 400]
        assert "claude_code" in banner_snippet, (
            "sdk-banner must name the affected driver (claude_code)"
        )
        assert "url_shortener" in banner_snippet, (
            "sdk-banner must name the affected task (url_shortener)"
        )

        # Per-cell sdk-badge inside a <section>.
        badge_idx = html.find('data-qa="sdk-badge"')
        assert badge_idx != -1, (
            "mixed_sdk must emit data-qa=\"sdk-badge\" inside the cell section"
        )
        section_open_before_badge = html.rfind("<section", 0, badge_idx)
        section_close_after_badge = html.find("</section>", badge_idx)
        assert section_open_before_badge != -1, (
            "sdk-badge must be inside a <section>, but no <section> opens before it"
        )
        assert section_close_after_badge != -1, (
            "sdk-badge must be inside a <section>, but no </section> closes after it"
        )
        assert section_open_before_badge < badge_idx < section_close_after_badge, (
            "sdk-badge position is outside <section>...</section>"
        )

    # ------------------------------------------------------------------
    # DA-14 (P1, AC-10 (b)) — Aborted rows excluded from median
    # ------------------------------------------------------------------
    def test_da14_aborted_rows_excluded_from_median_and_partial_fires(
        self, tmp_path: Path
    ) -> None:
        """DA-14 (P1, AC-10 (b)): aborted_rows fixture has 10 rows, 3 aborted
        and 7 non-aborted. The 3 aborted rows carry extreme values (acceptance
        ~0.99, wall_clock ~999s, cost ~$0.999). They MUST be excluded from
        aggregation — median/IQR computed over the 7 non-aborted rows only.

        Non-aborted acceptance_pct values: [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7]
          p25 = idx 25*(7-1)/100 = 1.5 → (0.2+0.3)/2 = 0.25
          p50 = idx 3.0 → 0.4
          p75 = idx 4.5 → (0.5+0.6)/2 = 0.55

        Non-aborted wall_clock_ms values: [10000, 20000, 30000, 40000, 50000, 60000, 70000]
          p25 = 25000, p50 = 40000, p75 = 55000

        Non-aborted cost_usd values: [0.001, 0.002, 0.003, 0.004, 0.005, 0.006, 0.007]
          p25 = 0.0025, p50 = 0.004, p75 = 0.0055

        Because effective n=7 < 10 (_PARTIAL_THRESHOLD), the partial-cell
        marker MUST also fire.
        """
        output_html = tmp_path / "dashboard.html"
        denylist_path = tmp_path / "denylist.txt"
        denylist_path.write_text(_NO_MATCH_DENYLIST, encoding="utf-8")

        render_dashboard(
            input_jsonl=_ABORTED_ROWS_JSONL,
            output_html=output_html,
            denylist_path=denylist_path,
        )

        assert output_html.exists(), "render_dashboard must write the output file"
        html = output_html.read_text(encoding="utf-8")

        # Medians over 7 non-aborted rows — aborted extremes MUST NOT leak in.
        _assert_metric_row(html, "acceptance_pct", "0.25", "0.4", "0.55")
        _assert_metric_row(html, "wall_clock_ms", "25000", "40000", "55000")
        _assert_metric_row(html, "cost_usd", "0.0025", "0.004", "0.0055")

        # Partial-cell marker must fire because effective n=7 < 10. If an
        # implementation wrongly counted aborted rows towards the partial
        # threshold (10 rows total), the marker would NOT fire — that
        # regression is what this assertion guards against.
        assert 'data-qa="partial-cell"' in html, (
            "Effective n=7 < 10 must trigger the partial-cell marker; missing "
            "marker means aborted rows are being double-counted toward the threshold"
        )

        # Negative assertions: the extreme values carried by each of the 3
        # aborted seeds (wall_clock {999000, 998000, 997000} and cost_usd
        # {0.999, 0.998, 0.997}) must NOT appear in the rendered output. If an
        # implementation filters out only one of the three aborted rows, a
        # single-value check would miss the leak — enumerate all three.
        for wall_clock in ("999000", "998000", "997000"):
            assert wall_clock not in html, (
                f"Aborted wall_clock_ms={wall_clock} leaked into rendered output — "
                "aggregate_cell must filter all aborted rows out"
            )
        for cost in ("0.999", "0.998", "0.997"):
            assert cost not in html, (
                f"Aborted cost_usd={cost} leaked into rendered output — "
                "aggregate_cell must filter all aborted rows out"
            )


# ---------------------------------------------------------------------------
# A3 Hardening tests (DA-9/10/11/12/13)
# ---------------------------------------------------------------------------

_MALFORMED_ROW_FIXTURE = Path(__file__).parent / "fixtures" / "malformed_row.jsonl"
_XSS_ROW_FIXTURE = Path(__file__).parent / "fixtures" / "xss_row.jsonl"

# Minimal valid ResultRow template used by inline fixtures below.
_BASE_ROW = {
    "driver": "claude_code",
    "driver_version": "0.1.15",
    "task": "url_shortener",
    "task_pack_revision": "abc1234def5678",
    "seed": 0,
    "container_digest": "sha256:deadbeef" + "0" * 56,
    "harness_version": "0.1.0",
    "sdk_version": "0.1.15",
    "sdk_release_date": "2024-09-01",
    "timestamp_utc": "2024-09-15T12:00:00Z",
    "wall_clock_ms": 45000,
    "input_tokens": 500,
    "output_tokens": 250,
    "cost_usd": 0.0075,
    "cost_source": "native",
    "acceptance_pct": 0.8,
    "mutation_score": {"python": {"killed": 8, "survived": 2, "timeout": 0, "score": 0.8}},
    "semgrep_high": 0,
    "semgrep_critical": 0,
    "injected_bug_detections": 3,
    "aborted": False,
    "abort_reason": None,
    "rate_limited_during_run": False,
    "cache_strategy": "omitted",
    "driver_metadata": {"cache_strategy": "omitted", "cache_read_input_tokens": 0},
}


def _make_row(**overrides: object) -> dict:
    """Return a copy of _BASE_ROW with the given fields overridden."""
    row = dict(_BASE_ROW)
    row.update(overrides)
    return row


class TestA3Hardening:
    """DA-9/10/11/12/13: atomic write, denylist edge cases, malformed rows, XSS."""

    # ------------------------------------------------------------------
    # DA-9 (P0, AC-15) — Atomic write: no partial file on denylist violation
    # ------------------------------------------------------------------
    def test_da9_atomic_write_no_file_on_denylist_violation(
        self, tmp_path: Path
    ) -> None:
        """DA-9 (P0, AC-15): denylist violation raises RuntimeError before any
        file is persisted — output_path must NOT exist after the raise. The
        implementation achieves this by running the denylist check before the
        single write_text call; no staging file is created either way.
        """
        input_jsonl = tmp_path / "input.jsonl"
        row = _make_row(driver_version="banned-sentinel-xyz")
        input_jsonl.write_text(json.dumps(row) + "\n", encoding="utf-8")

        denylist_path = tmp_path / "denylist.txt"
        denylist_path.write_text("banned-sentinel-xyz\n", encoding="utf-8")

        output_path = tmp_path / "dashboard.html"

        with pytest.raises(RuntimeError):
            render_dashboard(
                input_jsonl=input_jsonl,
                output_html=output_path,
                denylist_path=denylist_path,
            )

        assert not output_path.exists(), (
            "Output file must NOT exist after a denylist violation "
            "(the denylist check must run before any write)"
        )

    # ------------------------------------------------------------------
    # DA-10 (P0, AC-15) — Missing denylist → FileNotFoundError, no output
    # ------------------------------------------------------------------
    def test_da10_missing_denylist_raises_file_not_found(
        self, tmp_path: Path
    ) -> None:
        """DA-10 (P0, AC-15): when the denylist file does not exist,
        render_dashboard raises FileNotFoundError carrying the path, and writes
        no output file — the gate must fail-closed rather than silently skip.
        """
        output_path = tmp_path / "dashboard.html"
        denylist_path = tmp_path / "does-not-exist.txt"
        # Deliberately do NOT create denylist_path.

        with pytest.raises(FileNotFoundError) as exc_info:
            render_dashboard(
                input_jsonl=_FULL_CELL_JSONL,
                output_html=output_path,
                denylist_path=denylist_path,
            )

        exc_text = str(exc_info.value)
        assert "does-not-exist" in exc_text or str(denylist_path) in exc_text, (
            "FileNotFoundError must carry the missing denylist path so operators "
            "can diagnose which file is absent"
        )
        assert not output_path.exists(), (
            "Output file must NOT exist when the denylist file is unavailable "
            "(gate must be fail-closed — no output without a verified denylist)"
        )

    # ------------------------------------------------------------------
    # DA-11 (P1, AC-15.A4.1) — Empty denylist is fail-closed: ValueError
    # ------------------------------------------------------------------
    def test_da11_empty_denylist_raises_value_error(
        self, tmp_path: Path, capsys: pytest.CaptureFixture
    ) -> None:
        """DA-11 (P1, AC-15.A4.1): an empty denylist file raises ValueError.

        Policy flip from A3 → A4: an empty denylist is misconfiguration, not a
        legitimate operating state. Fail-open-with-warning let a misconfigured
        gate ship rendered output that bypassed every denylist check; A4 closes
        that hole. The exception message must reference the denylist path so
        operators can diagnose which file is empty without grepping logs.

        Also asserts the warning channel is silent — the A3 stderr write was
        intentionally retired with the policy flip; if a future change adds
        stderr noise back (e.g., via logging.warning before raise), this test
        catches the silent regression to fail-open-with-warning behavior.
        """
        output_path = tmp_path / "dashboard.html"
        denylist_path = tmp_path / "empty.txt"
        denylist_path.write_text("", encoding="utf-8")

        with pytest.raises(ValueError) as exc_info:
            render_dashboard(
                input_jsonl=_FULL_CELL_JSONL,
                output_html=output_path,
                denylist_path=denylist_path,
            )

        exc_text = str(exc_info.value)
        assert str(denylist_path) in exc_text, (
            "ValueError must carry the empty denylist path so operators "
            f"can diagnose which file is misconfigured (got: {exc_text!r})"
        )
        assert not output_path.exists(), (
            "Output file must NOT exist when the denylist is empty "
            "(gate must be fail-closed — no output without enforced denylist)"
        )
        captured = capsys.readouterr()
        assert captured.out == "" and captured.err == "", (
            "Warning channel must be silent on empty denylist — the A3 stderr "
            "write was retired with the policy flip. Found stdout="
            f"{captured.out!r}, stderr={captured.err!r}"
        )

    # ------------------------------------------------------------------
    # DA-12 (P1, AC-10) — Malformed rows filtered; banner + valid rows render
    # ------------------------------------------------------------------
    def test_da12_malformed_rows_filtered_with_banner(
        self, tmp_path: Path
    ) -> None:
        """DA-12 (P1, AC-10): malformed_row_fixture (9 valid + 1 row missing
        'driver') renders without KeyError; the output contains a
        data-qa="malformed-rows-banner" and the 9 valid rows' content.
        """
        output_path = tmp_path / "dashboard.html"
        denylist_path = tmp_path / "denylist.txt"
        denylist_path.write_text(_NO_MATCH_DENYLIST, encoding="utf-8")

        # Must not raise — malformed row must be silently filtered, not crash.
        render_dashboard(
            input_jsonl=_MALFORMED_ROW_FIXTURE,
            output_html=output_path,
            denylist_path=denylist_path,
        )

        assert output_path.exists(), "render_dashboard must write the output file"
        html = output_path.read_text(encoding="utf-8")

        assert 'data-qa="malformed-rows-banner"' in html, (
            "Malformed rows must cause a data-qa=\"malformed-rows-banner\" to appear "
            "at the top of the page so readers know some rows were skipped"
        )
        # The 9 valid rows belong to driver=claude_code / task=url_shortener.
        assert "claude_code" in html, (
            "Valid rows must still be rendered despite one malformed row"
        )
        assert "url_shortener" in html, (
            "Valid rows must still be rendered despite one malformed row"
        )

    def test_da12_clean_fixture_does_not_emit_malformed_banner(
        self, tmp_path: Path
    ) -> None:
        """DA-12 absence oracle (P1, AC-10): full_cell fixture (no malformed
        rows) must NOT emit the malformed-rows-banner — the banner must fire
        if-and-only-if malformed rows were actually encountered.
        """
        output_path = tmp_path / "dashboard.html"
        denylist_path = tmp_path / "denylist.txt"
        denylist_path.write_text(_NO_MATCH_DENYLIST, encoding="utf-8")

        render_dashboard(
            input_jsonl=_FULL_CELL_JSONL,
            output_html=output_path,
            denylist_path=denylist_path,
        )

        html = output_path.read_text(encoding="utf-8")
        assert 'data-qa="malformed-rows-banner"' not in html, (
            "Clean fixture must NOT emit the malformed-rows-banner — "
            "banner must fire only when malformed rows are actually skipped"
        )

    # ------------------------------------------------------------------
    # DA-13 (P0, AC-10) — Jinja2 autoescape: XSS payload encoded, never raw
    # ------------------------------------------------------------------
    def test_da13_jinja2_autoescape_encodes_script_tag(
        self, tmp_path: Path
    ) -> None:
        """DA-13 (P0, AC-10): xss_row_fixture (driver_version contains a raw
        <script> tag) must be HTML-escaped in the output — the escaped form
        &lt;script&gt; must appear and the literal form must not, proving
        Jinja2 autoescape is active on the template.
        """
        output_path = tmp_path / "dashboard.html"
        denylist_path = tmp_path / "denylist.txt"
        denylist_path.write_text(_NO_MATCH_DENYLIST, encoding="utf-8")

        render_dashboard(
            input_jsonl=_XSS_ROW_FIXTURE,
            output_html=output_path,
            denylist_path=denylist_path,
        )

        assert output_path.exists(), "render_dashboard must write the output file"
        html = output_path.read_text(encoding="utf-8")

        assert "&lt;script&gt;" in html, (
            "The escaped form '&lt;script&gt;' must appear in the HTML — "
            "Jinja2 autoescape must encode < and > to HTML entities"
        )
        assert "<script>alert(1)</script>" not in html, (
            "The literal '<script>alert(1)</script>' must NOT appear in the HTML — "
            "if this substring is present, autoescape is off and the page is XSS-exposed"
        )
