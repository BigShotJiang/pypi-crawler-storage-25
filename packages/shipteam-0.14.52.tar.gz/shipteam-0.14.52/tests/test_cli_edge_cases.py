"""
Tests for `shipteam init` edge cases and error paths (CLI Phase 4 — RED).

Covers:
  - AC-7: Non-TTY auto-enables non-interactive; missing required field → exit 2 + message
  - AC-1 (conflict branch): existing .claude/ without state → exit 1 without --force
  - AC-4: version mismatch between CLI and framework-meta.yaml → exit 4
  - --dry-run writes nothing (duplicate guard — structural variant)
  - Unknown / unsupported --profile value → exit 2 (click validation)
"""
import textwrap
from pathlib import Path

import pytest
from click.testing import CliRunner

from shipteam.cli import main


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_framework_source(tmp_path_factory, *, min_cli_version: str = "0.1.0") -> Path:
    """Synthetic framework source with configurable min_cli_version."""
    source = tmp_path_factory.mktemp("fw_source_edge")

    (source / "framework-meta.yaml").write_text(
        textwrap.dedent(f"""\
            min_cli_version: "{min_cli_version}"
            schema_version: 1
            profile_filters:
              rules:
                minimal: [anti-patterns.md]
                standard: [anti-patterns.md, security.md]
                full: ["*"]
              skills:
                minimal: []
                standard: [deploy.md]
                full: ["*"]
        """)
    )

    (source / "agents").mkdir()
    (source / "agents" / "a.md").write_text("# agent a")

    (source / "rules").mkdir()
    (source / "rules" / "anti-patterns.md").write_text("# Anti-patterns")
    (source / "rules" / "security.md").write_text("# Security")

    (source / "skills").mkdir()
    (source / "skills" / "deploy.md").write_text("# Deploy skill")

    (source / "hooks").mkdir()
    (source / "hooks" / "h.py").write_text("# hook")

    (source / "templates").mkdir()
    (source / "templates" / "CLAUDE.md.jinja").write_text(
        "# {{ project_name }} — Claude Docs\n"
    )

    return source


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture(scope="module")
def framework_source(tmp_path_factory) -> Path:
    return _make_framework_source(tmp_path_factory)


@pytest.fixture(scope="module")
def incompatible_framework_source(tmp_path_factory) -> Path:
    """Framework source that demands a far-future CLI version."""
    return _make_framework_source(tmp_path_factory, min_cli_version="99.0.0")


@pytest.fixture()
def bare_python_dir(tmp_path: Path) -> Path:
    """Python project with no pre-existing ShipTeam files."""
    (tmp_path / "pyproject.toml").write_text("[project]\nname = \"myapp\"\n")
    (tmp_path / ".git").mkdir()
    return tmp_path


@pytest.fixture()
def conflicting_dir(tmp_path: Path) -> Path:
    """Project with a .claude/ dir but NO .shipteam-init.yaml — foreign-owned conflict."""
    (tmp_path / "pyproject.toml").write_text("[project]\nname = \"myapp\"\n")
    (tmp_path / ".git").mkdir()
    claude_dir = tmp_path / ".claude"
    claude_dir.mkdir()
    (claude_dir / "some-user-file.md").write_text("# existing content")
    return tmp_path


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

class TestNonTTYAutoFlag:
    """AC-7: Non-TTY stdin auto-enables non-interactive mode."""

    def test_ac7_non_tty_treats_missing_repo_as_exit_2(
        self, bare_python_dir: Path, framework_source: Path, monkeypatch
    ) -> None:
        """AC-7: non-TTY + no --repo → exit 2 with message listing the missing flag."""
        # Arrange — simulate non-TTY stdin
        monkeypatch.setattr("sys.stdin.isatty", lambda: False)
        runner = CliRunner()

        # Act — omit --repo (required, non-detectable)
        result = runner.invoke(
            main,
            [
                "init",
                str(bare_python_dir),
                "--framework-dir", str(framework_source),
                # --repo intentionally omitted
            ],
        )

        # Assert
        assert result.exit_code == 2
        output_lower = result.output.lower()
        assert "repo" in output_lower or "missing" in output_lower or "required" in output_lower

    def test_ac7_non_tty_with_repo_succeeds(
        self, bare_python_dir: Path, framework_source: Path, monkeypatch
    ) -> None:
        """AC-7: non-TTY + all required flags supplied → exit 0."""
        monkeypatch.setattr("sys.stdin.isatty", lambda: False)
        runner = CliRunner()

        result = runner.invoke(
            main,
            [
                "init",
                str(bare_python_dir),
                "--repo", "myorg/foo",
                "--framework-dir", str(framework_source),
            ],
        )

        assert result.exit_code == 0, result.output


class TestConflictExitCode:
    """Existing .claude/ without a state file → exit 1 (conflict) without --force."""

    def test_conflict_exits_1_without_force(
        self, conflicting_dir: Path, framework_source: Path
    ) -> None:
        """Foreign-owned .claude/ directory causes exit 1 when --force is not set."""
        runner = CliRunner()

        result = runner.invoke(
            main,
            [
                "init",
                str(conflicting_dir),
                "--repo", "myorg/foo",
                "--non-interactive",
                "--framework-dir", str(framework_source),
            ],
        )

        assert result.exit_code == 1

    def test_conflict_force_overrides_and_exits_0(
        self, conflicting_dir: Path, framework_source: Path
    ) -> None:
        """--force allows init to proceed over a conflicting .claude/ directory."""
        runner = CliRunner()

        result = runner.invoke(
            main,
            [
                "init",
                str(conflicting_dir),
                "--repo", "myorg/foo",
                "--non-interactive",
                "--force",
                "--framework-dir", str(framework_source),
            ],
        )

        assert result.exit_code == 0, result.output


class TestVersionMismatch:
    """Framework min_cli_version > current CLI version → exit 4."""

    def test_ac4_version_mismatch_exits_4(
        self, bare_python_dir: Path, incompatible_framework_source: Path
    ) -> None:
        """AC-4: CLI version below framework's min_cli_version → exit 4."""
        runner = CliRunner()

        result = runner.invoke(
            main,
            [
                "init",
                str(bare_python_dir),
                "--repo", "myorg/foo",
                "--non-interactive",
                "--framework-dir", str(incompatible_framework_source),
            ],
        )

        assert result.exit_code == 4
        output_lower = result.output.lower()
        assert "version" in output_lower


class TestDryRunEdge:
    """--dry-run structural edge: no side-effects even on error-prone inputs."""

    def test_dry_run_on_conflict_dir_writes_nothing(
        self, conflicting_dir: Path, framework_source: Path
    ) -> None:
        """--dry-run on a conflicting directory still writes nothing."""
        runner = CliRunner()
        existing_files_before = set(conflicting_dir.rglob("*"))

        result = runner.invoke(
            main,
            [
                "init",
                str(conflicting_dir),
                "--repo", "myorg/foo",
                "--non-interactive",
                "--dry-run",
                "--framework-dir", str(framework_source),
            ],
        )

        existing_files_after = set(conflicting_dir.rglob("*"))
        # No new files must have been created
        new_files = existing_files_after - existing_files_before
        assert not new_files, f"dry-run created unexpected files: {new_files}"


class TestInvalidProfileChoice:
    """Unsupported --profile value → click exits 2 before any file I/O."""

    def test_invalid_profile_exits_2(
        self, bare_python_dir: Path, framework_source: Path
    ) -> None:
        """Passing an unknown --profile value produces a click usage error (exit 2)."""
        runner = CliRunner()

        result = runner.invoke(
            main,
            [
                "init",
                str(bare_python_dir),
                "--repo", "myorg/foo",
                "--non-interactive",
                "--profile", "enterprise",  # not in ["minimal","standard","full"]
                "--framework-dir", str(framework_source),
            ],
        )

        assert result.exit_code == 2
