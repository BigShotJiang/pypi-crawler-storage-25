"""
Tests for shipteam.source — framework source resolution + version handshake.

Covers:
  - AC-10: Version handshake (min_cli_version, schema_version)
  - resolve_source priority: framework_dir > env_var_value > bundled
  - VersionMismatchError raised with actionable messages
  - get_bundled_source() exists and is callable
"""
import textwrap
from pathlib import Path
from typing import Optional

import pytest

from shipteam.source import VersionMismatchError, get_bundled_source, resolve_source


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_framework_meta(
    source_dir: Path,
    min_cli_version: str = "0.13.0",
    schema_version: int = 1,
) -> None:
    """Write a minimal framework-meta.yaml into source_dir."""
    content = textwrap.dedent(f"""\
        min_cli_version: "{min_cli_version}"
        schema_version: {schema_version}
        profile_filters:
          rules:
            minimal: [anti-patterns.md]
            standard: [anti-patterns.md, security.md]
            full: ["*"]
          skills:
            minimal: []
            standard: [deploy.md]
            full: ["*"]
    """)
    (source_dir / "framework-meta.yaml").write_text(content)


# ---------------------------------------------------------------------------
# Tests: resolve_source — priority ordering
# ---------------------------------------------------------------------------

class TestResolveSourcePriority:
    """resolve_source uses framework_dir > env_var_value > bundled."""

    def test_ac10_explicit_framework_dir_takes_priority_over_env_var(self, tmp_path: Path) -> None:
        """AC-10: explicit framework_dir arg wins over env_var_value."""
        # Arrange
        source_dir = tmp_path / "fw"
        source_dir.mkdir()
        _make_framework_meta(source_dir)
        other_dir = tmp_path / "other"
        other_dir.mkdir()
        _make_framework_meta(other_dir)
        # Act
        result = resolve_source(framework_dir=source_dir, env_var_value=str(other_dir))
        # Assert: returned the explicit framework_dir, not the env var path
        assert result == source_dir

    def test_ac10_env_var_used_when_framework_dir_is_none(self, tmp_path: Path) -> None:
        """AC-10: env_var_value is used when framework_dir arg is None."""
        # Arrange
        source_dir = tmp_path / "fw"
        source_dir.mkdir()
        _make_framework_meta(source_dir)
        # Act
        result = resolve_source(framework_dir=None, env_var_value=str(source_dir))
        # Assert
        assert result == source_dir

    def test_ac10_valid_framework_dir_returns_path(self, tmp_path: Path) -> None:
        """AC-10: valid framework_dir with compatible versions returns that Path."""
        # Arrange
        source_dir = tmp_path / "fw"
        source_dir.mkdir()
        _make_framework_meta(source_dir, min_cli_version="0.1.0", schema_version=1)
        # Act
        result = resolve_source(
            framework_dir=source_dir,
            cli_version="1.0.0",
            supported_schema=1,
        )
        # Assert
        assert result == source_dir


# ---------------------------------------------------------------------------
# Tests: resolve_source — missing framework-meta.yaml
# ---------------------------------------------------------------------------

class TestResolveSourceMissingMeta:
    """resolve_source raises FileNotFoundError when framework-meta.yaml is absent."""

    def test_ac10_missing_framework_meta_raises_file_not_found(self, tmp_path: Path) -> None:
        """AC-10: directory exists but no framework-meta.yaml → FileNotFoundError."""
        # Arrange
        source_dir = tmp_path / "fw"
        source_dir.mkdir()
        # (intentionally no framework-meta.yaml)
        # Act / Assert
        with pytest.raises(FileNotFoundError):
            resolve_source(framework_dir=source_dir)

    def test_ac10_missing_meta_message_is_actionable(self, tmp_path: Path) -> None:
        """AC-10: FileNotFoundError message names the expected file."""
        source_dir = tmp_path / "fw"
        source_dir.mkdir()
        with pytest.raises(FileNotFoundError, match="framework-meta.yaml"):
            resolve_source(framework_dir=source_dir)

    def test_ac10_env_var_path_missing_meta_raises(self, tmp_path: Path) -> None:
        """AC-10: env_var_value points to dir without framework-meta.yaml → FileNotFoundError."""
        source_dir = tmp_path / "fw"
        source_dir.mkdir()
        with pytest.raises(FileNotFoundError):
            resolve_source(framework_dir=None, env_var_value=str(source_dir))


# ---------------------------------------------------------------------------
# Tests: AC-10 — min_cli_version mismatch
# ---------------------------------------------------------------------------

class TestVersionHandshakeCliVersion:
    """resolve_source raises VersionMismatchError when min_cli_version > cli_version."""

    def test_ac10_cli_version_too_old_raises_version_mismatch(self, tmp_path: Path) -> None:
        """AC-10: framework requires 99.0.0 but CLI is 1.0.0 → VersionMismatchError."""
        # Arrange
        source_dir = tmp_path / "fw"
        source_dir.mkdir()
        _make_framework_meta(source_dir, min_cli_version="99.0.0")
        # Act / Assert
        with pytest.raises(VersionMismatchError):
            resolve_source(framework_dir=source_dir, cli_version="1.0.0")

    def test_ac10_cli_version_too_old_message_contains_required_version(self, tmp_path: Path) -> None:
        """AC-10: VersionMismatchError message mentions 'shipteam >= 99.0.0'."""
        source_dir = tmp_path / "fw"
        source_dir.mkdir()
        _make_framework_meta(source_dir, min_cli_version="99.0.0")
        with pytest.raises(VersionMismatchError, match="99.0.0"):
            resolve_source(framework_dir=source_dir, cli_version="1.0.0")

    def test_ac10_cli_version_too_old_message_mentions_upgrade(self, tmp_path: Path) -> None:
        """AC-10: VersionMismatchError message contains upgrade hint."""
        source_dir = tmp_path / "fw"
        source_dir.mkdir()
        _make_framework_meta(source_dir, min_cli_version="99.0.0")
        with pytest.raises(VersionMismatchError, match="uv tool upgrade shipteam"):
            resolve_source(framework_dir=source_dir, cli_version="1.0.0")

    def test_ac10_cli_version_equal_to_min_is_accepted(self, tmp_path: Path) -> None:
        """AC-10: cli_version equal to min_cli_version is valid (not a mismatch)."""
        source_dir = tmp_path / "fw"
        source_dir.mkdir()
        _make_framework_meta(source_dir, min_cli_version="1.0.0")
        # Act — should not raise
        result = resolve_source(
            framework_dir=source_dir,
            cli_version="1.0.0",
            supported_schema=1,
        )
        assert result == source_dir

    def test_ac10_cli_version_newer_than_min_is_accepted(self, tmp_path: Path) -> None:
        """AC-10: cli_version > min_cli_version → valid, returns Path."""
        source_dir = tmp_path / "fw"
        source_dir.mkdir()
        _make_framework_meta(source_dir, min_cli_version="0.1.0")
        result = resolve_source(
            framework_dir=source_dir,
            cli_version="2.0.0",
            supported_schema=1,
        )
        assert result == source_dir


# ---------------------------------------------------------------------------
# Tests: AC-10 — schema_version mismatch
# ---------------------------------------------------------------------------

class TestVersionHandshakeSchemaVersion:
    """resolve_source raises VersionMismatchError when schema_version mismatches."""

    def test_ac10_schema_version_mismatch_raises(self, tmp_path: Path) -> None:
        """AC-10: framework schema_version=99, CLI supports 1 → VersionMismatchError."""
        # Arrange
        source_dir = tmp_path / "fw"
        source_dir.mkdir()
        _make_framework_meta(source_dir, schema_version=99)
        # Act / Assert
        with pytest.raises(VersionMismatchError):
            resolve_source(
                framework_dir=source_dir,
                cli_version="99.0.0",   # cli version high enough
                supported_schema=1,
            )

    def test_ac10_schema_mismatch_message_names_schema(self, tmp_path: Path) -> None:
        """AC-10: VersionMismatchError from schema mismatch mentions schema in message."""
        source_dir = tmp_path / "fw"
        source_dir.mkdir()
        _make_framework_meta(source_dir, schema_version=99)
        with pytest.raises(VersionMismatchError, match="schema"):
            resolve_source(
                framework_dir=source_dir,
                cli_version="99.0.0",
                supported_schema=1,
            )

    def test_ac10_schema_version_match_accepted(self, tmp_path: Path) -> None:
        """AC-10: matching schema_version and compatible cli_version → returns Path."""
        source_dir = tmp_path / "fw"
        source_dir.mkdir()
        _make_framework_meta(source_dir, min_cli_version="0.1.0", schema_version=1)
        result = resolve_source(
            framework_dir=source_dir,
            cli_version="1.0.0",
            supported_schema=1,
        )
        assert result == source_dir


# ---------------------------------------------------------------------------
# Tests: get_bundled_source — callable check
# ---------------------------------------------------------------------------

class TestGetBundledSource:
    """get_bundled_source() must exist and be callable; bundled files may not exist in dev."""

    def test_get_bundled_source_is_callable(self) -> None:
        """get_bundled_source import succeeds and the object is callable."""
        assert callable(get_bundled_source)

    def test_get_bundled_source_returns_path_or_raises_file_not_found(self) -> None:
        """get_bundled_source() returns a Path or raises FileNotFoundError (no bundled files yet)."""
        try:
            result = get_bundled_source()
            assert isinstance(result, Path)
        except FileNotFoundError:
            pass  # Acceptable — bundled files ship in Phase 5
        except Exception as exc:
            pytest.fail(f"get_bundled_source() raised unexpected {type(exc).__name__}: {exc}")
