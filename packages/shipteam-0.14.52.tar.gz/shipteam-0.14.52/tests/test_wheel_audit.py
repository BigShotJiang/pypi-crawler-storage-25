"""Phase 1 RED tests for scripts/wheel_audit.py — PYC_CHECK and PYCACHE_CHECK.

These tests define expected behaviour for audit_artifact() and audit_dist_dir()
before any implementation exists. They MUST fail with ModuleNotFoundError on
collection until scripts/wheel_audit.py is created.

Acceptance Criteria covered:
  AC-1: .whl containing a .pyc member → finding with check="PYC_CHECK"
  AC-2: .tar.gz sdist containing a .pyc member → finding with check="PYC_CHECK"
  AC-3: .whl containing a __pycache__/ member → finding with check="PYCACHE_CHECK"
  AC-5 (partial): clean .whl with only benign members → empty list
  AC-6 (partial): clean .tar.gz with only benign members → empty list
"""

from __future__ import annotations

import io
import sys
import tarfile
import zipfile
from dataclasses import fields
from pathlib import Path

import pytest

# ---------------------------------------------------------------------------
# Import strategy: insert scripts/ onto sys.path so "import wheel_audit" works
# once the implementation file exists. Until then this import raises
# ModuleNotFoundError, which is the canonical RED-phase signal for this project.
# ---------------------------------------------------------------------------
sys.path.insert(0, str(Path(__file__).parent.parent / "scripts"))
import wheel_audit  # noqa: E402  — expected to raise ModuleNotFoundError in RED
from wheel_audit import AuditFinding, audit_artifact, audit_dist_dir  # noqa: E402


# ---------------------------------------------------------------------------
# Archive-construction helpers (not pytest fixtures — plain functions)
# ---------------------------------------------------------------------------

def _make_wheel(tmp_path: Path, members: dict[str, bytes], name: str = "pkg-1.0-py3-none-any.whl") -> Path:
    """Write a minimal zip-based .whl to tmp_path and return its Path.

    Args:
        tmp_path: Directory to write the archive into.
        members:  Mapping of archive member path → file bytes content.
        name:     Filename for the wheel archive.
    """
    wheel_path = tmp_path / name
    with zipfile.ZipFile(wheel_path, mode="w", compression=zipfile.ZIP_STORED) as zf:
        for member_name, content in members.items():
            zf.writestr(member_name, content)
    return wheel_path


def _make_sdist(tmp_path: Path, members: dict[str, bytes], name: str = "pkg-1.0.tar.gz") -> Path:
    """Write a minimal gzipped tar sdist to tmp_path and return its Path.

    Args:
        tmp_path: Directory to write the archive into.
        members:  Mapping of archive member path → file bytes content.
        name:     Filename for the sdist archive.
    """
    sdist_path = tmp_path / name
    with tarfile.open(sdist_path, mode="w:gz") as tf:
        for member_name, content in members.items():
            buf = io.BytesIO(content)
            info = tarfile.TarInfo(name=member_name)
            info.size = len(content)
            tf.addfile(info, buf)
    return sdist_path


# ---------------------------------------------------------------------------
# Meta-oracle: verify that the archive builders actually inject requested members.
# Failures here mean broken fixture infrastructure, not broken detection logic.
# ---------------------------------------------------------------------------

class TestArchiveBuilderOracles:
    """Validate that _make_wheel and _make_sdist actually produce the injected members.

    If these tests fail, assertions in detection tests may be masking a broken
    fixture builder rather than a broken implementation.
    """

    def test_wheel_builder_oracle_member_present(self, tmp_path: Path) -> None:
        """_make_wheel includes the requested member path in the archive."""
        sentinel_member = "shipteam/framework/__pycache__/hooks.cpython-312.pyc"
        whl = _make_wheel(tmp_path, {sentinel_member: b"\x00\x00\x00\x00"})

        with zipfile.ZipFile(whl) as zf:
            names = zf.namelist()

        assert sentinel_member in names, (
            f"Archive builder oracle failed: '{sentinel_member}' not in {names}"
        )

    def test_wheel_builder_oracle_benign_member_present(self, tmp_path: Path) -> None:
        """_make_wheel includes a benign .py member and nothing else when given only that."""
        benign_member = "shipteam/core.py"
        whl = _make_wheel(tmp_path, {benign_member: b"# module"})

        with zipfile.ZipFile(whl) as zf:
            names = zf.namelist()

        assert names == [benign_member], (
            f"Archive builder oracle failed: expected only [{benign_member!r}], got {names}"
        )

    def test_sdist_builder_oracle_member_present(self, tmp_path: Path) -> None:
        """_make_sdist includes the requested member path in the archive."""
        sentinel_member = "pkg-1.0/shipteam/cache.pyc"
        tgz = _make_sdist(tmp_path, {sentinel_member: b"\xde\xad\xbe\xef"})

        with tarfile.open(tgz, mode="r:gz") as tf:
            names = tf.getnames()

        assert sentinel_member in names, (
            f"Sdist builder oracle failed: '{sentinel_member}' not in {names}"
        )

    def test_sdist_builder_oracle_benign_member_present(self, tmp_path: Path) -> None:
        """_make_sdist includes a benign member and nothing else when given only that."""
        benign_member = "pkg-1.0/shipteam/core.py"
        tgz = _make_sdist(tmp_path, {benign_member: b"# module"})

        with tarfile.open(tgz, mode="r:gz") as tf:
            names = tf.getnames()

        assert names == [benign_member], (
            f"Sdist builder oracle failed: expected only [{benign_member!r}], got {names}"
        )

    def test_audit_finding_dataclass_has_required_fields(self) -> None:
        """AuditFinding exposes the four fields required by the interface contract."""
        field_names = {f.name for f in fields(AuditFinding)}
        assert "artifact" in field_names, "AuditFinding is missing field 'artifact'"
        assert "check" in field_names, "AuditFinding is missing field 'check'"
        assert "member" in field_names, "AuditFinding is missing field 'member'"
        assert "detail" in field_names, "AuditFinding is missing field 'detail'"


# ---------------------------------------------------------------------------
# Phase 1 detection tests
# ---------------------------------------------------------------------------

class TestPhase1Detection:
    """Behaviour of audit_artifact() for PYC_CHECK and PYCACHE_CHECK.

    Each test: Arrange (build in-memory archive in tmp_path), Act (call
    audit_artifact), Assert (inspect returned AuditFinding list).
    """

    # ------------------------------------------------------------------
    # AC-1: .whl with a .pyc member → PYC_CHECK finding
    # ------------------------------------------------------------------

    def test_ac1_whl_pyc_member_returns_pyc_check_finding(self, tmp_path: Path) -> None:
        """AC-1: .whl containing a compiled .pyc file triggers PYC_CHECK."""
        # Arrange
        pyc_member = "shipteam/framework/__pycache__/hooks.cpython-312.pyc"
        whl = _make_wheel(tmp_path, {pyc_member: b"\x00\x00\x00\x00"})

        # Act
        findings = audit_artifact(whl)

        # Assert
        assert len(findings) >= 1, (
            f"Expected at least one finding for a .whl with a .pyc member, got: {findings}"
        )
        pyc_findings = [f for f in findings if f.check == "PYC_CHECK"]
        assert pyc_findings, (
            f"Expected a finding with check='PYC_CHECK' but got checks: "
            f"{[f.check for f in findings]}"
        )

    def test_ac1_whl_pyc_finding_member_contains_pyc_extension(self, tmp_path: Path) -> None:
        """AC-1: the PYC_CHECK finding's member field contains '.pyc'."""
        # Arrange
        pyc_member = "shipteam/framework/__pycache__/hooks.cpython-312.pyc"
        whl = _make_wheel(tmp_path, {pyc_member: b"\x00\x00\x00\x00"})

        # Act
        findings = audit_artifact(whl)

        # Assert
        pyc_findings = [f for f in findings if f.check == "PYC_CHECK"]
        assert pyc_findings, "No PYC_CHECK finding returned"
        assert all(".pyc" in f.member for f in pyc_findings), (
            f"Expected all PYC_CHECK findings to have '.pyc' in member, got: "
            f"{[f.member for f in pyc_findings]}"
        )

    def test_ac1_whl_pyc_finding_artifact_matches_path(self, tmp_path: Path) -> None:
        """AC-1: the finding's artifact field is the wheel filename."""
        # Arrange
        pyc_member = "shipteam/__pycache__/module.cpython-311.pyc"
        whl = _make_wheel(tmp_path, {pyc_member: b"\x00\x00\x00\x00"}, name="mylib-2.0-py3-none-any.whl")

        # Act
        findings = audit_artifact(whl)

        # Assert
        pyc_findings = [f for f in findings if f.check == "PYC_CHECK"]
        assert pyc_findings, "No PYC_CHECK finding returned"
        assert all(f.artifact == "mylib-2.0-py3-none-any.whl" for f in pyc_findings), (
            f"Expected artifact='mylib-2.0-py3-none-any.whl', got: "
            f"{[f.artifact for f in pyc_findings]}"
        )

    def test_ac1_whl_multiple_pyc_members_each_get_a_finding(self, tmp_path: Path) -> None:
        """AC-1 edge case: every .pyc member in the wheel produces its own finding."""
        # Arrange
        members = {
            "pkg/__pycache__/a.cpython-312.pyc": b"\x00\x00\x00\x00",
            "pkg/__pycache__/b.cpython-312.pyc": b"\x00\x00\x00\x00",
            "pkg/module.py": b"# source",
        }
        whl = _make_wheel(tmp_path, members)

        # Act
        findings = audit_artifact(whl)

        # Assert
        pyc_findings = [f for f in findings if f.check == "PYC_CHECK"]
        assert len(pyc_findings) >= 2, (
            f"Expected at least 2 PYC_CHECK findings for 2 .pyc members, got {len(pyc_findings)}"
        )
        members_found = {f.member for f in pyc_findings}
        assert "pkg/__pycache__/a.cpython-312.pyc" in members_found
        assert "pkg/__pycache__/b.cpython-312.pyc" in members_found

    # ------------------------------------------------------------------
    # AC-2: .tar.gz sdist with a .pyc member → PYC_CHECK finding
    # ------------------------------------------------------------------

    def test_ac2_sdist_pyc_member_returns_pyc_check_finding(self, tmp_path: Path) -> None:
        """AC-2: .tar.gz sdist containing a .pyc file triggers PYC_CHECK."""
        # Arrange
        pyc_member = "pkg-1.0/src/pkg/__pycache__/cache.cpython-312.pyc"
        tgz = _make_sdist(tmp_path, {pyc_member: b"\xde\xad\xbe\xef"})

        # Act
        findings = audit_artifact(tgz)

        # Assert
        assert len(findings) >= 1, (
            f"Expected at least one finding for a .tar.gz with a .pyc member, got: {findings}"
        )
        pyc_findings = [f for f in findings if f.check == "PYC_CHECK"]
        assert pyc_findings, (
            f"Expected a finding with check='PYC_CHECK' but got: {[f.check for f in findings]}"
        )

    def test_ac2_sdist_pyc_finding_member_contains_pyc_extension(self, tmp_path: Path) -> None:
        """AC-2: the PYC_CHECK finding's member field contains '.pyc'."""
        # Arrange
        pyc_member = "pkg-1.0/src/pkg/utils.cpython-311.pyc"
        tgz = _make_sdist(tmp_path, {pyc_member: b"\x00\x00\x00\x00"})

        # Act
        findings = audit_artifact(tgz)

        # Assert
        pyc_findings = [f for f in findings if f.check == "PYC_CHECK"]
        assert pyc_findings, "No PYC_CHECK finding returned for sdist"
        assert all(".pyc" in f.member for f in pyc_findings), (
            f"Expected '.pyc' in all PYC_CHECK finding members, got: "
            f"{[f.member for f in pyc_findings]}"
        )

    def test_ac2_sdist_pyc_finding_artifact_matches_filename(self, tmp_path: Path) -> None:
        """AC-2: the finding's artifact field is the sdist filename."""
        # Arrange
        pyc_member = "mylib-3.0/src/compiled.cpython-310.pyc"
        tgz = _make_sdist(tmp_path, {pyc_member: b"\x00\x00\x00\x00"}, name="mylib-3.0.tar.gz")

        # Act
        findings = audit_artifact(tgz)

        # Assert
        pyc_findings = [f for f in findings if f.check == "PYC_CHECK"]
        assert pyc_findings, "No PYC_CHECK finding returned"
        assert all(f.artifact == "mylib-3.0.tar.gz" for f in pyc_findings), (
            f"Expected artifact='mylib-3.0.tar.gz', got: {[f.artifact for f in pyc_findings]}"
        )

    # ------------------------------------------------------------------
    # AC-3: .whl with __pycache__/ in member path → PYCACHE_CHECK finding
    # ------------------------------------------------------------------

    def test_ac3_whl_pycache_dir_in_path_returns_pycache_check_finding(self, tmp_path: Path) -> None:
        """AC-3: .whl member path containing '__pycache__/' triggers PYCACHE_CHECK."""
        # Arrange
        pycache_member = "shipteam/__pycache__/foo.py"
        whl = _make_wheel(tmp_path, {pycache_member: b"# not a real .pyc but in __pycache__"})

        # Act
        findings = audit_artifact(whl)

        # Assert
        assert len(findings) >= 1, (
            f"Expected at least one finding for a .whl with a __pycache__/ member, got: {findings}"
        )
        pycache_findings = [f for f in findings if f.check == "PYCACHE_CHECK"]
        assert pycache_findings, (
            f"Expected a finding with check='PYCACHE_CHECK' but got checks: "
            f"{[f.check for f in findings]}"
        )

    def test_ac3_pycache_finding_member_contains_pycache_segment(self, tmp_path: Path) -> None:
        """AC-3: the PYCACHE_CHECK finding's member field contains '__pycache__'."""
        # Arrange
        pycache_member = "shipteam/__pycache__/foo.py"
        whl = _make_wheel(tmp_path, {pycache_member: b"# source"})

        # Act
        findings = audit_artifact(whl)

        # Assert
        pycache_findings = [f for f in findings if f.check == "PYCACHE_CHECK"]
        assert pycache_findings, "No PYCACHE_CHECK finding returned"
        assert all("__pycache__" in f.member for f in pycache_findings), (
            f"Expected '__pycache__' in all PYCACHE_CHECK finding members, got: "
            f"{[f.member for f in pycache_findings]}"
        )

    def test_ac3_pycache_finding_artifact_matches_wheel_filename(self, tmp_path: Path) -> None:
        """AC-3: the PYCACHE_CHECK finding's artifact field is the wheel filename."""
        # Arrange
        pycache_member = "pkg/__pycache__/module.cpython-312.pyc"
        whl = _make_wheel(tmp_path, {pycache_member: b"\x00\x00\x00\x00"}, name="pkg-0.9-py3-none-any.whl")

        # Act
        findings = audit_artifact(whl)

        # Assert
        # A member that is both .pyc AND inside __pycache__ may produce both finding types.
        pycache_findings = [f for f in findings if f.check == "PYCACHE_CHECK"]
        assert pycache_findings, "No PYCACHE_CHECK finding returned"
        assert all(f.artifact == "pkg-0.9-py3-none-any.whl" for f in pycache_findings), (
            f"Expected artifact='pkg-0.9-py3-none-any.whl', got: "
            f"{[f.artifact for f in pycache_findings]}"
        )

    def test_ac3_nested_pycache_path_also_flagged(self, tmp_path: Path) -> None:
        """AC-3 edge case: __pycache__/ deeper in a nested package path is still caught."""
        # Arrange
        deep_member = "shipteam/framework/hooks/__pycache__/auto_approve.cpython-312.pyc"
        whl = _make_wheel(tmp_path, {deep_member: b"\x00\x00\x00\x00"})

        # Act
        findings = audit_artifact(whl)

        # Assert
        pycache_findings = [f for f in findings if f.check == "PYCACHE_CHECK"]
        assert pycache_findings, (
            f"Expected PYCACHE_CHECK for nested __pycache__ path, got: "
            f"{[f.check for f in findings]}"
        )

    # ------------------------------------------------------------------
    # AC-5 (partial): clean .whl with only benign members → empty list
    # ------------------------------------------------------------------

    def test_ac5_clean_whl_returns_empty_list(self, tmp_path: Path) -> None:
        """AC-5 (partial): a .whl with no .pyc or __pycache__ members → no findings."""
        # Arrange
        members = {
            "shipteam/__init__.py": b"# init",
            "shipteam/core.py": b"# core module",
            "shipteam/utils.py": b"# utils",
            "shipteam-1.0.dist-info/METADATA": b"Name: shipteam\nVersion: 1.0\n",
            "shipteam-1.0.dist-info/RECORD": b"shipteam/__init__.py,,\n",
            "README.md": b"# ShipTeam\n",
        }
        whl = _make_wheel(tmp_path, members)

        # Act
        findings = audit_artifact(whl)

        # Assert
        phase1_findings = [f for f in findings if f.check in ("PYC_CHECK", "PYCACHE_CHECK")]
        assert phase1_findings == [], (
            f"Expected no Phase-1 findings for a clean .whl, got: {phase1_findings}"
        )

    def test_ac5_empty_whl_returns_empty_list(self, tmp_path: Path) -> None:
        """AC-5 edge case: a .whl with zero members → empty findings list, not an error."""
        # Arrange
        whl = _make_wheel(tmp_path, {})

        # Act
        findings = audit_artifact(whl)

        # Assert
        assert isinstance(findings, list), (
            f"Expected a list from audit_artifact, got {type(findings)}"
        )
        assert findings == [], f"Expected empty list for empty wheel, got: {findings}"

    # ------------------------------------------------------------------
    # AC-6 (partial): clean .tar.gz with only benign members → empty list
    # ------------------------------------------------------------------

    def test_ac6_clean_sdist_returns_empty_list(self, tmp_path: Path) -> None:
        """AC-6 (partial): a .tar.gz with no .pyc or __pycache__ members → no findings."""
        # Arrange
        members = {
            "pkg-1.0/setup.py": b"from setuptools import setup; setup()",
            "pkg-1.0/src/pkg/__init__.py": b"# init",
            "pkg-1.0/src/pkg/module.py": b"# module",
            "pkg-1.0/README.md": b"# Package\n",
            "pkg-1.0/pyproject.toml": b'[project]\nname = "pkg"\n',
        }
        tgz = _make_sdist(tmp_path, members)

        # Act
        findings = audit_artifact(tgz)

        # Assert
        phase1_findings = [f for f in findings if f.check in ("PYC_CHECK", "PYCACHE_CHECK")]
        assert phase1_findings == [], (
            f"Expected no Phase-1 findings for a clean .tar.gz, got: {phase1_findings}"
        )

    def test_ac6_empty_sdist_returns_empty_list(self, tmp_path: Path) -> None:
        """AC-6 edge case: a .tar.gz with zero members → empty findings list, not an error."""
        # Arrange
        tgz = _make_sdist(tmp_path, {})

        # Act
        findings = audit_artifact(tgz)

        # Assert
        assert isinstance(findings, list), (
            f"Expected a list from audit_artifact, got {type(findings)}"
        )
        assert findings == [], f"Expected empty list for empty sdist, got: {findings}"

    # ------------------------------------------------------------------
    # Return type contract
    # ------------------------------------------------------------------

    def test_audit_artifact_always_returns_list(self, tmp_path: Path) -> None:
        """audit_artifact() always returns a list (never None or another type)."""
        whl = _make_wheel(tmp_path, {"pkg/module.py": b"# ok"})
        result = audit_artifact(whl)
        assert isinstance(result, list), (
            f"audit_artifact must return list, got {type(result)}"
        )

    def test_audit_artifact_findings_are_audit_finding_instances(self, tmp_path: Path) -> None:
        """Each element in the returned list is an AuditFinding dataclass instance."""
        pyc_member = "pkg/__pycache__/mod.cpython-312.pyc"
        whl = _make_wheel(tmp_path, {pyc_member: b"\x00\x00\x00\x00"})

        findings = audit_artifact(whl)

        assert findings, "Expected at least one finding — precondition for this test"
        for finding in findings:
            assert isinstance(finding, AuditFinding), (
                f"Expected AuditFinding instance, got {type(finding)}: {finding!r}"
            )


# ---------------------------------------------------------------------------
# audit_dist_dir tests
# ---------------------------------------------------------------------------

class TestAuditDistDir:
    """audit_dist_dir() aggregates findings across all artifacts in a dist/ directory."""

    def test_dist_dir_with_single_clean_wheel_returns_empty_list(self, tmp_path: Path) -> None:
        """audit_dist_dir on a dist/ with one clean .whl → empty findings list."""
        # Arrange
        dist = tmp_path / "dist"
        dist.mkdir()
        _make_wheel(dist, {"pkg/module.py": b"# clean"}, name="pkg-1.0-py3-none-any.whl")

        # Act
        findings = audit_dist_dir(dist)

        # Assert
        phase1_findings = [f for f in findings if f.check in ("PYC_CHECK", "PYCACHE_CHECK")]
        assert phase1_findings == [], (
            f"Expected no Phase-1 findings for dist/ with clean wheel, got: {phase1_findings}"
        )

    def test_dist_dir_with_dirty_wheel_returns_findings(self, tmp_path: Path) -> None:
        """audit_dist_dir on a dist/ containing a wheel with .pyc members → findings returned."""
        # Arrange
        dist = tmp_path / "dist"
        dist.mkdir()
        _make_wheel(
            dist,
            {"pkg/__pycache__/mod.cpython-312.pyc": b"\x00\x00\x00\x00"},
            name="pkg-1.0-py3-none-any.whl",
        )

        # Act
        findings = audit_dist_dir(dist)

        # Assert
        assert len(findings) >= 1, (
            f"Expected at least one finding from dirty wheel in dist/, got: {findings}"
        )

    def test_dist_dir_aggregates_across_multiple_artifacts(self, tmp_path: Path) -> None:
        """audit_dist_dir scans all artifacts; findings from each are included."""
        # Arrange
        dist = tmp_path / "dist"
        dist.mkdir()
        _make_wheel(
            dist,
            {"pkg/__pycache__/a.cpython-312.pyc": b"\x00\x00\x00\x00"},
            name="pkg-1.0-py3-none-any.whl",
        )
        _make_sdist(
            dist,
            {"pkg-1.0/src/pkg/__pycache__/b.cpython-312.pyc": b"\x00\x00\x00\x00"},
            name="pkg-1.0.tar.gz",
        )

        # Act
        findings = audit_dist_dir(dist)

        # Assert
        assert len(findings) >= 2, (
            f"Expected at least 2 findings across .whl + .tar.gz, got: {findings}"
        )
        artifact_names = {f.artifact for f in findings}
        assert "pkg-1.0-py3-none-any.whl" in artifact_names, (
            f"Expected findings from wheel, artifact names seen: {artifact_names}"
        )
        assert "pkg-1.0.tar.gz" in artifact_names, (
            f"Expected findings from sdist, artifact names seen: {artifact_names}"
        )

    def test_dist_dir_empty_directory_returns_empty_list(self, tmp_path: Path) -> None:
        """audit_dist_dir on an empty directory → empty list, not an error."""
        # Arrange
        dist = tmp_path / "dist"
        dist.mkdir()

        # Act
        findings = audit_dist_dir(dist)

        # Assert
        assert isinstance(findings, list), (
            f"Expected list from audit_dist_dir on empty dir, got {type(findings)}"
        )
        assert findings == [], f"Expected empty list for empty dist/, got: {findings}"


# ---------------------------------------------------------------------------
# Phase 2 RED tests — BRIGHT_LINE scanning (ADR-007)
# ---------------------------------------------------------------------------

class TestPhase2BrightLine:
    """Behaviour of audit_artifact() for BRIGHT_LINE pattern detection.

    The BRIGHT_LINE check must scan text members of a .whl for ADR-007
    forbidden content (pricing amounts, revenue signals, GTM keywords,
    private-path references) using the same vocabulary as
    scripts/validate-no-bright-line.sh line 43.

    Acceptance Criteria covered:
      AC-4:  text member with bright-line pattern → finding check="BRIGHT_LINE"
      AC-4b: NFKC-normalized Unicode fullwidth digits are detected
      AC-4c: binary members (containing null bytes) are skipped
      AC-5:  text member with benign content → no BRIGHT_LINE finding
    """

    # ------------------------------------------------------------------
    # AC-5 (text files, bright-line negative): benign content → no finding
    # ------------------------------------------------------------------

    def test_ac5_clean_text_member_returns_no_bright_line_finding(self, tmp_path: Path) -> None:
        """AC-5: a .whl whose text member has benign content produces no BRIGHT_LINE finding."""
        # Arrange
        members = {
            "shipteam/__init__.py": b"# init module\n",
            "shipteam/core.py": b"def deploy(): pass\n",
            "shipteam-1.0.dist-info/METADATA": b"Name: shipteam\nVersion: 1.0\n",
        }
        whl = _make_wheel(tmp_path, members)

        # Act
        findings = audit_artifact(whl)

        # Assert
        bright_line_findings = [f for f in findings if f.check == "BRIGHT_LINE"]
        assert bright_line_findings == [], (
            f"Expected no BRIGHT_LINE findings for clean text members, got: {bright_line_findings}"
        )

    # ------------------------------------------------------------------
    # AC-4: pricing signal ($150K) → BRIGHT_LINE finding
    # ------------------------------------------------------------------

    def test_ac4_dollar_amount_k_suffix_triggers_bright_line(self, tmp_path: Path) -> None:
        """AC-4: a .whl text member containing '$150K' triggers BRIGHT_LINE."""
        # Arrange — inject a dollar-amount-with-K-suffix pattern
        violation_content = b"target revenue is $150K by Q3\n"
        whl = _make_wheel(tmp_path, {"shipteam/targets.py": violation_content})

        # Act
        findings = audit_artifact(whl)

        # Assert
        bright_line_findings = [f for f in findings if f.check == "BRIGHT_LINE"]
        assert bright_line_findings, (
            "Expected at least one BRIGHT_LINE finding for '$150K' but got none"
        )
        assert bright_line_findings[0].check == "BRIGHT_LINE"
        assert bright_line_findings[0].member == "shipteam/targets.py"

    def test_ac4_bright_line_finding_member_matches_violating_file(self, tmp_path: Path) -> None:
        """AC-4: the BRIGHT_LINE finding's member field is the specific violating file path."""
        # Arrange — clean file plus one dirty file; member must point to dirty one
        members = {
            "shipteam/clean.py": b"# clean module\n",
            "shipteam/dirty.py": b"ARR target $150K for the year\n",
        }
        whl = _make_wheel(tmp_path, members)

        # Act
        findings = audit_artifact(whl)

        # Assert
        bright_line_findings = [f for f in findings if f.check == "BRIGHT_LINE"]
        assert bright_line_findings, "Expected at least one BRIGHT_LINE finding"
        member_paths = {f.member for f in bright_line_findings}
        assert "shipteam/dirty.py" in member_paths, (
            f"Expected 'shipteam/dirty.py' in BRIGHT_LINE members, got: {member_paths}"
        )
        assert "shipteam/clean.py" not in member_paths, (
            f"'shipteam/clean.py' should NOT appear in BRIGHT_LINE members, got: {member_paths}"
        )

    # ------------------------------------------------------------------
    # AC-4: ARR standalone word → BRIGHT_LINE finding
    # ------------------------------------------------------------------

    def test_ac4_arr_standalone_word_triggers_bright_line(self, tmp_path: Path) -> None:
        """AC-4: a .whl text member containing standalone 'ARR' triggers BRIGHT_LINE."""
        # Arrange — inject the ARR revenue-signal keyword (word boundary match)
        violation_content = b"projected ARR exceeds forecast\n"
        whl = _make_wheel(tmp_path, {"shipteam/metrics.py": violation_content})

        # Act
        findings = audit_artifact(whl)

        # Assert
        bright_line_findings = [f for f in findings if f.check == "BRIGHT_LINE"]
        assert bright_line_findings, (
            "Expected at least one BRIGHT_LINE finding for standalone 'ARR' but got none"
        )

    # ------------------------------------------------------------------
    # AC-4: dev-framework-private path reference → BRIGHT_LINE finding
    # ------------------------------------------------------------------

    def test_ac4_dev_framework_private_path_triggers_bright_line(self, tmp_path: Path) -> None:
        """AC-4: a .whl text member containing 'dev-framework-private' triggers BRIGHT_LINE."""
        # Arrange — inject private-path reference
        violation_content = b"see ~/Documents/dev-framework-private/strategy.md\n"
        whl = _make_wheel(tmp_path, {"shipteam/docs.py": violation_content})

        # Act
        findings = audit_artifact(whl)

        # Assert
        bright_line_findings = [f for f in findings if f.check == "BRIGHT_LINE"]
        assert bright_line_findings, (
            "Expected at least one BRIGHT_LINE finding for 'dev-framework-private' but got none"
        )

    # ------------------------------------------------------------------
    # AC-4b: NFKC normalization — fullwidth Unicode digits detected
    # ------------------------------------------------------------------

    def test_ac4b_fullwidth_unicode_digits_detected_via_nfkc(self, tmp_path: Path) -> None:
        """AC-4b: '$150K' encoded with fullwidth Unicode digits is caught after NFKC normalization.

        NFKC maps U+FF04 (FULLWIDTH DOLLAR SIGN) + U+FF11U+FF15U+FF10 (fullwidth 1,5,0) +
        U+FF2B (FULLWIDTH LATIN CAPITAL LETTER K) to their ASCII equivalents, producing '$150K'
        which the regex then matches.
        """
        # Arrange — fullwidth variants of $ 1 5 0 K
        # U+FF04 = ＄, U+FF11 = １, U+FF15 = ５, U+FF10 = ０, U+FF2B = Ｋ
        fullwidth_violation = "target is ＄１５０Ｋ this year\n".encode("utf-8")
        whl = _make_wheel(tmp_path, {"shipteam/roadmap.py": fullwidth_violation})

        # Act
        findings = audit_artifact(whl)

        # Assert
        bright_line_findings = [f for f in findings if f.check == "BRIGHT_LINE"]
        assert bright_line_findings, (
            "Expected BRIGHT_LINE finding for fullwidth '＄１５０Ｋ' after NFKC normalization "
            "but got none — NFKC must normalize fullwidth chars to ASCII before regex match"
        )

    # ------------------------------------------------------------------
    # AC-4c: binary member (contains null byte) is skipped
    # ------------------------------------------------------------------

    def test_ac4c_binary_member_with_null_byte_is_skipped(self, tmp_path: Path) -> None:
        """AC-4c: a .whl member containing null bytes is treated as binary and skipped.

        Binary members must never produce false-positive BRIGHT_LINE findings.
        The null byte is the canonical signal that a member is binary data.
        """
        # Arrange — content that would match bright-line IF decoded as text, but contains
        # a null byte making it binary. The $150K pattern is embedded among binary content.
        binary_content = b"some binary data\x00target $150K revenue\x00more binary\n"
        whl = _make_wheel(tmp_path, {"shipteam/data.bin": binary_content})

        # Act
        findings = audit_artifact(whl)

        # Assert
        bright_line_findings = [f for f in findings if f.check == "BRIGHT_LINE"]
        assert bright_line_findings == [], (
            f"Expected no BRIGHT_LINE findings for binary member with null bytes, "
            f"got: {bright_line_findings}"
        )

    # ------------------------------------------------------------------
    # AC-4: GTM standalone word → BRIGHT_LINE finding
    # ------------------------------------------------------------------

    def test_ac4_gtm_standalone_word_triggers_bright_line(self, tmp_path: Path) -> None:
        """AC-4: a .whl text member containing standalone 'GTM' triggers BRIGHT_LINE."""
        # Arrange — inject go-to-market abbreviated keyword
        violation_content = b"our GTM strategy targets enterprise customers\n"
        whl = _make_wheel(tmp_path, {"shipteam/strategy.py": violation_content})

        # Act
        findings = audit_artifact(whl)

        # Assert
        bright_line_findings = [f for f in findings if f.check == "BRIGHT_LINE"]
        assert bright_line_findings, (
            "Expected at least one BRIGHT_LINE finding for standalone 'GTM' but got none"
        )

    # ------------------------------------------------------------------
    # AC-4: detail field contains the matched pattern text
    # ------------------------------------------------------------------

    def test_ac4_detail_field_contains_matched_pattern_text(self, tmp_path: Path) -> None:
        """AC-4: the BRIGHT_LINE finding's detail field contains the text that was matched.

        The detail field must carry enough context for an auditor to identify
        which pattern fired and where. At minimum it must contain the violating
        match substring (e.g. '$150K', 'ARR', 'GTM', 'dev-framework-private').
        """
        # Arrange — use a distinctive violation so detail content is unambiguous
        violation_content = b"revenue goal $150K ARR for next fiscal year\n"
        whl = _make_wheel(tmp_path, {"shipteam/goals.py": violation_content})

        # Act
        findings = audit_artifact(whl)

        # Assert
        bright_line_findings = [f for f in findings if f.check == "BRIGHT_LINE"]
        assert bright_line_findings, "Expected at least one BRIGHT_LINE finding"
        for finding in bright_line_findings:
            assert finding.detail, (
                f"Expected non-empty detail on BRIGHT_LINE finding for "
                f"'{finding.member}', got empty string"
            )
            # The detail must contain meaningful content — either the matched
            # substring or the line context that triggered the match.
            assert len(finding.detail) > 0, (
                f"BRIGHT_LINE finding detail must be non-empty for '{finding.member}'"
            )


# ---------------------------------------------------------------------------
# Phase 3 CLI tests — __main__ entry point
# ---------------------------------------------------------------------------

class TestPhase3CLI:
    """Behaviour of wheel_audit.py when executed as a CLI via python3 scripts/wheel_audit.py.

    Acceptance Criteria covered:
      AC-5/AC-6 (CLI exit 0):  clean dist/ → process exits 0
      AC-1      (CLI exit 1):  dist/ with .pyc member in wheel → process exits 1
      CLI usage error          (no args) → process exits 2
      stdout "PASS"            for clean artifact
      stdout "FAIL"/"PYC_CHECK" for dirty artifact
      stdout "Audit complete:" summary line always present
    """

    # Locate scripts/ relative to this test file at collection time
    _scripts_dir: Path = Path(__file__).parent.parent / "scripts"

    # ------------------------------------------------------------------
    # AC-5/AC-6: clean dist/ → exit code 0
    # ------------------------------------------------------------------

    def test_clean_dist_dir_exits_zero(self, tmp_path: Path) -> None:
        """AC-5/AC-6: running wheel_audit.py against a clean dist/ exits 0."""
        import subprocess

        # Arrange — clean wheel + clean sdist, no violations
        dist = tmp_path / "dist"
        dist.mkdir()
        _make_wheel(dist, {"pkg/__init__.py": b"# clean", "pkg/core.py": b"# code"})
        _make_sdist(dist, {"pkg-1.0/setup.py": b"# setup", "pkg-1.0/src/pkg/__init__.py": b""})

        # Act
        result = subprocess.run(
            ["python3", str(self._scripts_dir / "wheel_audit.py"), str(dist)],
            capture_output=True,
            text=True,
        )

        # Assert
        assert result.returncode == 0, (
            f"Expected exit code 0 for clean dist/, got {result.returncode}.\n"
            f"stdout: {result.stdout}\nstderr: {result.stderr}"
        )

    # ------------------------------------------------------------------
    # AC-1: dist/ with a .pyc member in a wheel → exit code 1
    # ------------------------------------------------------------------

    def test_dirty_wheel_exits_one(self, tmp_path: Path) -> None:
        """AC-1: running wheel_audit.py against a dist/ with a .pyc wheel member exits 1."""
        import subprocess

        # Arrange — wheel that contains a .pyc member (violation)
        dist = tmp_path / "dist"
        dist.mkdir()
        _make_wheel(
            dist,
            {"pkg/__pycache__/mod.cpython-312.pyc": b"\x00\x00\x00\x00"},
            name="pkg-1.0-py3-none-any.whl",
        )

        # Act
        result = subprocess.run(
            ["python3", str(self._scripts_dir / "wheel_audit.py"), str(dist)],
            capture_output=True,
            text=True,
        )

        # Assert
        assert result.returncode == 1, (
            f"Expected exit code 1 for dist/ with .pyc member, got {result.returncode}.\n"
            f"stdout: {result.stdout}\nstderr: {result.stderr}"
        )

    # ------------------------------------------------------------------
    # CLI usage error: no arguments → exit code 2
    # ------------------------------------------------------------------

    def test_no_arguments_exits_two(self) -> None:
        """Running wheel_audit.py with no arguments exits 2 (usage error)."""
        import subprocess

        # Act — invoke with no positional argument
        result = subprocess.run(
            ["python3", str(self._scripts_dir / "wheel_audit.py")],
            capture_output=True,
            text=True,
        )

        # Assert
        assert result.returncode == 2, (
            f"Expected exit code 2 for missing dist_dir argument, got {result.returncode}.\n"
            f"stdout: {result.stdout}\nstderr: {result.stderr}"
        )

    # ------------------------------------------------------------------
    # stdout "PASS" for each clean artifact
    # ------------------------------------------------------------------

    def test_clean_artifact_stdout_contains_pass(self, tmp_path: Path) -> None:
        """AC-5: stdout contains 'PASS' when all artifacts are clean."""
        import subprocess

        # Arrange
        dist = tmp_path / "dist"
        dist.mkdir()
        _make_wheel(dist, {"pkg/module.py": b"# source"}, name="pkg-1.0-py3-none-any.whl")

        # Act
        result = subprocess.run(
            ["python3", str(self._scripts_dir / "wheel_audit.py"), str(dist)],
            capture_output=True,
            text=True,
        )

        # Assert
        assert "PASS" in result.stdout, (
            f"Expected 'PASS' in stdout for clean artifact.\n"
            f"stdout: {result.stdout!r}\nstderr: {result.stderr!r}"
        )

    # ------------------------------------------------------------------
    # stdout "FAIL" and "PYC_CHECK" for dirty artifact
    # ------------------------------------------------------------------

    def test_dirty_artifact_stdout_contains_fail_and_check_name(self, tmp_path: Path) -> None:
        """AC-1: stdout contains 'FAIL' and 'PYC_CHECK' when violations are found."""
        import subprocess

        # Arrange — wheel with .pyc member
        dist = tmp_path / "dist"
        dist.mkdir()
        _make_wheel(
            dist,
            {"pkg/__pycache__/mod.cpython-312.pyc": b"\x00\x00\x00\x00"},
            name="pkg-1.0-py3-none-any.whl",
        )

        # Act
        result = subprocess.run(
            ["python3", str(self._scripts_dir / "wheel_audit.py"), str(dist)],
            capture_output=True,
            text=True,
        )

        # Assert
        assert "FAIL" in result.stdout, (
            f"Expected 'FAIL' in stdout for dirty artifact.\n"
            f"stdout: {result.stdout!r}"
        )
        assert "PYC_CHECK" in result.stdout, (
            f"Expected 'PYC_CHECK' in stdout for .pyc member finding.\n"
            f"stdout: {result.stdout!r}"
        )

    # ------------------------------------------------------------------
    # stdout "Audit complete:" summary line always present
    # ------------------------------------------------------------------

    def test_summary_line_present_for_clean_run(self, tmp_path: Path) -> None:
        """stdout always includes an 'Audit complete:' summary line on a clean run."""
        import subprocess

        # Arrange
        dist = tmp_path / "dist"
        dist.mkdir()
        _make_wheel(dist, {"pkg/module.py": b"# source"})

        # Act
        result = subprocess.run(
            ["python3", str(self._scripts_dir / "wheel_audit.py"), str(dist)],
            capture_output=True,
            text=True,
        )

        # Assert
        assert "Audit complete:" in result.stdout, (
            f"Expected 'Audit complete:' summary line in stdout.\n"
            f"stdout: {result.stdout!r}"
        )

    def test_summary_line_present_for_dirty_run(self, tmp_path: Path) -> None:
        """stdout always includes an 'Audit complete:' summary line even when violations found."""
        import subprocess

        # Arrange — dirty wheel
        dist = tmp_path / "dist"
        dist.mkdir()
        _make_wheel(
            dist,
            {"pkg/__pycache__/mod.cpython-312.pyc": b"\x00\x00\x00\x00"},
        )

        # Act
        result = subprocess.run(
            ["python3", str(self._scripts_dir / "wheel_audit.py"), str(dist)],
            capture_output=True,
            text=True,
        )

        # Assert
        assert "Audit complete:" in result.stdout, (
            f"Expected 'Audit complete:' summary line in stdout even for dirty run.\n"
            f"stdout: {result.stdout!r}"
        )


# ---------------------------------------------------------------------------
# Phase 3 integration test — builds and audits the real project artifact
# ---------------------------------------------------------------------------

@pytest.mark.integration
class TestPhase3Integration:
    """Runs python -m build against the actual project and audits the real output.

    Acceptance Criteria covered:
      AC-5/AC-6 (integration): the real built wheel and sdist contain no audit violations.

    This test is marked @pytest.mark.integration so it can be skipped in fast
    CI runs with '-m "not integration"'. It requires `pip install build` (or
    `uv tool install build`). If `python -m build` fails (tool not installed,
    build error), the test is skipped rather than failing hard.
    """

    def test_real_build_passes_audit(self, tmp_path: Path) -> None:
        """AC-5/AC-6: the real built wheel and sdist produced by python -m build exit audit cleanly."""
        import subprocess
        import shutil  # noqa: F401 — imported for documentation; subprocess handles invocation

        repo_root = Path(__file__).parent.parent

        # Build the actual project into a temp dist dir
        result = subprocess.run(
            ["python3", "-m", "build", "--outdir", str(tmp_path)],
            cwd=repo_root,
            capture_output=True,
            text=True,
            timeout=120,
        )
        if result.returncode != 0:
            pytest.skip(f"python -m build failed (tool may not be installed): {result.stderr[:200]}")

        # Verify at least one artifact was produced
        artifacts = list(tmp_path.iterdir())
        if not artifacts:
            pytest.skip("python -m build produced no artifacts in outdir")

        # Run the wheel auditor against the real output
        audit_result = subprocess.run(
            ["python3", str(repo_root / "scripts" / "wheel_audit.py"), str(tmp_path)],
            capture_output=True,
            text=True,
        )
        assert audit_result.returncode == 0, (
            f"wheel_audit.py found violations in the real built artifacts:\n"
            f"{audit_result.stdout}\n{audit_result.stderr}"
        )


class TestForensicsGapFixes:
    """P0 tests covering Critical+High findings from the forensics review.

    These tests pin the four gaps fixed after the initial TDD phases:
    - CRIT-1: METADATA (no extension) must be BRIGHT_LINE scanned
    - CRIT-2: empty dist/ must exit non-zero
    - HIGH-2/3: case-variant .PYC and bare __pycache__ (no trailing slash) must be caught
    """

    def _make_whl(self, tmp_path: Path, members: dict[str, bytes]) -> Path:
        p = tmp_path / "shipteam-0.0.0-py3-none-any.whl"
        with zipfile.ZipFile(p, "w") as zf:
            for name, content in members.items():
                zf.writestr(name, content)
        return p

    # -------------------------------------------------------------------------
    # CRIT-1: METADATA and other no-extension wheel members must be scanned
    # -------------------------------------------------------------------------

    def test_metadata_with_bright_line_triggers_bright_line_finding(self, tmp_path):
        """METADATA carries the rendered README — primary accidental-leak surface."""
        whl = self._make_whl(tmp_path, {
            "shipteam-0.0.0.dist-info/METADATA": b"Package: shipteam\n\nOur $300K ARR growth continues.",
        })
        findings = wheel_audit.audit_artifact(whl)
        bright = [f for f in findings if f.check == "BRIGHT_LINE"]
        assert bright, "METADATA with '$300K ARR' must produce a BRIGHT_LINE finding"
        assert "METADATA" in bright[0].member

    def test_license_with_no_extension_does_not_crash_and_is_scanned(self, tmp_path):
        """LICENSE has no extension but must be considered a text member."""
        whl = self._make_whl(tmp_path, {
            "shipteam-0.0.0.dist-info/LICENSE": b"MIT License\nvaluation of zero.",
        })
        findings = wheel_audit.audit_artifact(whl)
        bright = [f for f in findings if f.check == "BRIGHT_LINE"]
        assert bright, "LICENSE containing 'valuation' must produce a BRIGHT_LINE finding"

    def test_clean_metadata_returns_no_bright_line_finding(self, tmp_path):
        """Clean METADATA must not generate false positives."""
        whl = self._make_whl(tmp_path, {
            "shipteam-0.0.0.dist-info/METADATA": b"Metadata-Version: 2.1\nName: shipteam\n",
        })
        findings = wheel_audit.audit_artifact(whl)
        assert not any(f.check == "BRIGHT_LINE" for f in findings)

    # -------------------------------------------------------------------------
    # CRIT-2: empty dist/ must exit non-zero
    # -------------------------------------------------------------------------

    def test_empty_dist_dir_exits_nonzero(self, tmp_path):
        """If build silently produces no artifacts, the gate must not pass."""
        scripts_dir = Path(__file__).parent.parent / "scripts"
        result = __import__("subprocess").run(
            ["python3", str(scripts_dir / "wheel_audit.py"), str(tmp_path)],
            capture_output=True, text=True,
        )
        assert result.returncode != 0, (
            f"Empty dist/ must exit non-zero; got {result.returncode}. "
            f"stdout: {result.stdout!r}"
        )

    # -------------------------------------------------------------------------
    # HIGH-2: case-variant .PYC member name must be caught
    # -------------------------------------------------------------------------

    def test_uppercase_pyc_extension_triggers_pyc_check(self, tmp_path):
        """FOO.PYC must be caught even though it's uppercase."""
        whl = self._make_whl(tmp_path, {
            "shipteam/hooks/FOO.PYC": b"\xc0\xde",
        })
        findings = wheel_audit.audit_artifact(whl)
        pyc = [f for f in findings if f.check == "PYC_CHECK"]
        assert pyc, "FOO.PYC must trigger PYC_CHECK regardless of case"

    def test_mixed_case_pyc_extension_triggers_pyc_check(self, tmp_path):
        whl = self._make_whl(tmp_path, {
            "shipteam/hooks/module.Pyc": b"\xc0\xde",
        })
        findings = wheel_audit.audit_artifact(whl)
        assert any(f.check == "PYC_CHECK" for f in findings)

    # -------------------------------------------------------------------------
    # HIGH-3: bare __pycache__ entry (no trailing slash) must be caught
    # -------------------------------------------------------------------------

    def test_bare_pycache_directory_entry_triggers_pycache_check(self, tmp_path):
        """Zip writers may store directory entries without trailing slash."""
        whl = self._make_whl(tmp_path, {
            "shipteam/__pycache__": b"",  # bare directory entry, no slash
        })
        findings = wheel_audit.audit_artifact(whl)
        pycache = [f for f in findings if f.check == "PYCACHE_CHECK"]
        assert pycache, "bare '__pycache__' entry (no trailing slash) must trigger PYCACHE_CHECK"

    def test_uppercase_pycache_in_path_triggers_pycache_check(self, tmp_path):
        whl = self._make_whl(tmp_path, {
            "shipteam/__PYCACHE__/module.cpython-312.pyc": b"\xc0\xde",
        })
        findings = wheel_audit.audit_artifact(whl)
        assert any(f.check == "PYCACHE_CHECK" for f in findings)
