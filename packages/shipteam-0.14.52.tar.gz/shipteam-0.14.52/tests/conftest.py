"""
Shared pytest fixtures for shipteam installer tests.

Each fixture yields a pathlib.Path to a temporary directory configured
for a specific project topology scenario.
"""
import json
import textwrap
from pathlib import Path

import pytest


# ---------------------------------------------------------------------------
# CLI Phase 4 fixtures
# ---------------------------------------------------------------------------

@pytest.fixture(scope="session")
def synthetic_framework_source(tmp_path_factory) -> Path:
    """
    Minimal but structurally complete framework source tree for CLI integration tests.

    Layout:
        framework-meta.yaml          — min_cli_version + profile_filters
        agents/a.md
        rules/anti-patterns.md
        skills/deploy.md
        hooks/h.py
        templates/CLAUDE.md.jinja    — uses {{ project_name }} and {% if health_url %}
    """
    source = tmp_path_factory.mktemp("synthetic_fw")

    (source / "framework-meta.yaml").write_text(
        textwrap.dedent("""\
            min_cli_version: "0.1.0"
            schema_version: 1
            profile_filters:
              rules:
                minimal: [anti-patterns.md]
                standard: [anti-patterns.md, security.md]
                full: ["*"]
              skills:
                minimal: []
                standard: [deploy.md]
                full: ["*"]
        """)
    )

    agents_dir = source / "agents"
    agents_dir.mkdir()
    (agents_dir / "a.md").write_text("# agent a")

    rules_dir = source / "rules"
    rules_dir.mkdir()
    (rules_dir / "anti-patterns.md").write_text("# Anti-patterns")
    (rules_dir / "security.md").write_text("# Security")

    skills_dir = source / "skills"
    skills_dir.mkdir()
    (skills_dir / "deploy.md").write_text("# Deploy skill")

    hooks_dir = source / "hooks"
    hooks_dir.mkdir()
    (hooks_dir / "h.py").write_text("# hook")

    templates_dir = source / "templates"
    templates_dir.mkdir()
    (templates_dir / "CLAUDE.md.jinja").write_text(
        textwrap.dedent("""\
            # {{ project_name }} — Claude Docs
            {% if health_url %}
            Health URL: {{ health_url }}
            {% endif %}
        """)
    )

    return source


@pytest.fixture()
def python_react_project(tmp_path: Path) -> Path:
    """
    Synthetic Python + React project directory for CLI integration tests.

    Writes:
        pyproject.toml  — Python project marker
        package.json    — React dependency marker
        .git/           — git root marker
    """
    (tmp_path / "pyproject.toml").write_text(
        textwrap.dedent("""\
            [project]
            name = "myapp"
        """)
    )
    (tmp_path / "package.json").write_text(
        json.dumps({"name": "myapp", "dependencies": {"react": "^18"}})
    )
    (tmp_path / ".git").mkdir()
    return tmp_path


@pytest.fixture
def python_project_dir(tmp_path: Path) -> Path:
    """A Python-only project with pyproject.toml and a .git directory."""
    (tmp_path / "pyproject.toml").write_text(
        textwrap.dedent("""\
            [project]
            name = "myapp"
        """)
    )
    (tmp_path / ".git").mkdir()
    return tmp_path


@pytest.fixture
def react_project_dir(tmp_path: Path) -> Path:
    """A React frontend-only project with package.json and a .git directory."""
    (tmp_path / "package.json").write_text(
        json.dumps({"name": "app", "dependencies": {"react": "^18"}})
    )
    (tmp_path / ".git").mkdir()
    return tmp_path


@pytest.fixture
def monorepo_project_dir(tmp_path: Path) -> Path:
    """A monorepo with backend/ (Python) and frontend/ (React) subdirectories."""
    backend = tmp_path / "backend"
    backend.mkdir()
    (backend / "pyproject.toml").write_text(
        textwrap.dedent("""\
            [project]
            name = "api"
        """)
    )
    frontend = tmp_path / "frontend"
    frontend.mkdir()
    (frontend / "package.json").write_text(
        json.dumps({"name": "app", "dependencies": {"react": "^18"}})
    )
    (tmp_path / ".git").mkdir()
    return tmp_path


@pytest.fixture
def empty_dir(tmp_path: Path) -> Path:
    """An empty temporary directory — no project files, no .git."""
    return tmp_path


@pytest.fixture
def worktree_project_dir(tmp_path: Path) -> Path:
    """
    A git worktree project: .git is a FILE pointing to the main repo's worktree entry.

    Layout:
      tmp_path/
        main_repo/
          .git/
            worktrees/
              wt1/
        worktree/
          .git   <- file containing "gitdir: <abs>/main_repo/.git/worktrees/wt1"
          pyproject.toml
    """
    main_repo = tmp_path / "main_repo"
    worktree_entry = main_repo / ".git" / "worktrees" / "wt1"
    worktree_entry.mkdir(parents=True)

    project_dir = tmp_path / "worktree"
    project_dir.mkdir()

    gitdir_target = worktree_entry.resolve()
    (project_dir / ".git").write_text(f"gitdir: {gitdir_target}\n")
    (project_dir / "pyproject.toml").write_text(
        textwrap.dedent("""\
            [project]
            name = "worktree-app"
        """)
    )
    return project_dir


@pytest.fixture
def initialized_project_dir(tmp_path: Path) -> Path:
    """A project directory that already has a .shipteam-init.yaml state file."""
    state_yaml = textwrap.dedent("""\
        cli_version: "0.1.0"
        framework_version: "0.13.2"
        schema_version: 1
        rendered_at: "2026-04-12T12:00:00Z"
        template_hash: "a1b2c3d4e5f6789012345678901234567890abcdef0123456789abcdef012345"
        region_checksums:
          session_start: "1111111111111111111111111111111111111111111111111111111111111111"
          deployment: "2222222222222222222222222222222222222222222222222222222222222222"
        profile: "standard"
    """)
    (tmp_path / ".shipteam-init.yaml").write_text(state_yaml)
    return tmp_path


@pytest.fixture
def non_git_dir(tmp_path: Path) -> Path:
    """A directory with pyproject.toml but no .git — not a git repository."""
    (tmp_path / "pyproject.toml").write_text(
        textwrap.dedent("""\
            [project]
            name = "myapp"
        """)
    )
    return tmp_path


@pytest.fixture
def valid_framework_yaml(tmp_path: Path) -> Path:
    """Creates a valid framework.yaml and yields the Path to that file."""
    content = textwrap.dedent("""\
        project:
          name: "testproj"
          repo: "myorg/testproj"
        profile: "standard"
        stack:
          backend:
            language: "python"
        schema_version: 1
    """)
    yaml_path = tmp_path / "framework.yaml"
    yaml_path.write_text(content)
    return yaml_path


@pytest.fixture
def malicious_yaml(tmp_path: Path) -> Path:
    """Creates a YAML file with a PyYAML exploit payload — yields the Path."""
    yaml_path = tmp_path / "malicious.yaml"
    # Sentinel-based: payload attempts to write a file we can check for
    sentinel = tmp_path / "pwned"
    yaml_path.write_text(f'!!python/object/apply:os.system ["touch {sentinel}"]')
    return yaml_path
