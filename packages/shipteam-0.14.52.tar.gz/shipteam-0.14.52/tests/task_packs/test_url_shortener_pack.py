"""
AC-6 verifier for the URL shortener task pack.

AC-6 oracle (as reframed at Phase 5c — see Pivot Log entry "2026-04-27 |
Phase 5c authoring"): every bug variant in injected_bugs/bug_NN.py must
produce a non-empty failing-test-name set when run against the frozen
suite, and the sets must be pairwise distinct across the 10 bugs.

The original "(passed, failed) tuple distinctness" oracle is mathematically
infeasible at total=6, errors=0 (only 7 distinct count tuples exist; spec
requires 10 distinct bugs). The failing-test-name set has 2^6 - 1 = 63
non-empty values — comfortable headroom and faithful to the author's intent
("each bug exercises a distinct failure mode").

This test also smoke-checks that the pack.yaml loads cleanly, exercising
the full TaskPack contract end-to-end.
"""
from __future__ import annotations

import os
import shutil
import subprocess
import sys
import tempfile
import xml.etree.ElementTree as ET
from pathlib import Path

import pytest

from task_packs.loader import load_pack


PACK_DIR = Path(__file__).resolve().parents[2] / "task_packs" / "url_shortener"
FROZEN_TESTS_DIR = PACK_DIR / "frozen_tests"
INJECTED_BUGS_DIR = PACK_DIR / "injected_bugs"


# Inline reference implementation used as the AC-6 baseline. A workspace
# containing this source MUST pass all 6 frozen tests — if it doesn't, the
# frozen suite has a false-negative against a known-correct impl, and any
# bug-set distinctness numbers downstream are meaningless.
#
# Per Phase 5c review (HIGH-2 from fw-review-tests): without this baseline,
# a no-op bug variant (one that accidentally passes all 6 tests) would
# slip through `test_ac6_every_bug_killed_by_at_least_one_test` only by
# producing an empty failing set — but a bug variant that's *correct* in
# all the right ways would also be invisible. The baseline pins the
# "correct" anchor against which bug-failure is measured.
_REFERENCE_SHORTENER_SOURCE = '''\
"""Reference URL shortener — correctness baseline for the AC-6 verifier."""
import hashlib


class URLShortener:
    def __init__(self, base_url: str = "https://sh.rt/") -> None:
        self._base_url = base_url
        self._codes: dict[str, str] = {}
        self._urls: dict[str, str] = {}
        self._clicks: dict[str, int] = {}

    def _generate_code(self, long_url: str) -> str:
        return hashlib.sha256(long_url.encode("utf-8")).hexdigest()[:8]

    def _strip_prefix(self, short: str) -> str:
        if short.startswith(self._base_url):
            return short[len(self._base_url):]
        return short

    def shorten(self, long_url: str) -> str:
        if long_url in self._urls:
            return self._base_url + self._urls[long_url]
        code = self._generate_code(long_url)
        self._codes[code] = long_url
        self._urls[long_url] = code
        self._clicks[code] = 0
        return self._base_url + code

    def expand(self, short: str) -> str:
        code = self._strip_prefix(short)
        if code not in self._codes:
            raise KeyError(code)
        return self._codes[code]

    def visit(self, short: str) -> str:
        code = self._strip_prefix(short)
        if code not in self._codes:
            raise KeyError(code)
        self._clicks[code] += 1
        return self._codes[code]

    def stats(self) -> dict[str, int]:
        return {
            "total_urls": len(self._codes),
            "total_clicks": sum(self._clicks.values()),
        }
'''


def _bug_paths() -> list[Path]:
    """All bug_NN.py files, sorted by filename for stable test order."""
    return sorted(INJECTED_BUGS_DIR.glob("bug_*.py"))


def _run_frozen_suite_collecting_failing_names(workspace: Path) -> set[str]:
    """Run the frozen suite against `workspace/shortener.py` and return the
    set of failing test names (names of testcase elements with a <failure>
    or <error> child).

    Mirrors scoring.acceptance.run_pytest_on_frozen_suite's invocation
    (WORKSPACE env var, JUnit XML capture) but extracts test-name detail
    that the production scoring path discards.
    """
    with tempfile.NamedTemporaryFile(suffix=".xml", delete=False) as tmp:
        xml_path = tmp.name
    try:
        proc = subprocess.run(
            [
                sys.executable,
                "-m",
                "pytest",
                str(FROZEN_TESTS_DIR),
                f"--junitxml={xml_path}",
                "--tb=no",
                "-q",
            ],
            env={**os.environ, "WORKSPACE": str(workspace.resolve())},
            capture_output=True,
            timeout=120,
        )
        # Returncode 0=all pass, 1=tests failed (both expected here).
        # Anything else (2 INTERRUPTED, 3 INTERNAL_ERROR, 4 USAGE_ERROR,
        # 5 NO_TESTS_COLLECTED, negative=signal) means the bug variant
        # broke pytest itself — surface that loudly rather than treat as
        # a "failing-name set."
        if proc.returncode not in (0, 1):
            raise RuntimeError(
                f"pytest returncode={proc.returncode} for workspace={workspace}; "
                f"stderr: {proc.stderr.decode(errors='replace').strip()}"
            )
        tree = ET.parse(xml_path)
        failing: set[str] = set()
        for testcase in tree.getroot().iter("testcase"):
            classname = testcase.attrib.get("classname", "")
            name = testcase.attrib.get("name", "")
            if classname == "":
                # Collection-error placeholder — the bug broke import,
                # not a specific test. Represent as a single sentinel.
                failing.add("<collection-error>")
                continue
            if testcase.find("failure") is not None or testcase.find("error") is not None:
                failing.add(name)
        return failing
    finally:
        try:
            os.unlink(xml_path)
        except OSError:
            pass


@pytest.fixture(scope="module")
def bug_failing_sets() -> dict[str, frozenset[str]]:
    """Map bug filename → frozenset of failing test names.

    Module-scoped so we run pytest once per bug for the whole test module
    (10 invocations total, ~15-20s aggregate vs N×M re-runs per assertion).
    """
    result: dict[str, frozenset[str]] = {}
    for bug_path in _bug_paths():
        with tempfile.TemporaryDirectory() as tmpdir:
            workspace = Path(tmpdir)
            shutil.copy(bug_path, workspace / "shortener.py")
            failing = _run_frozen_suite_collecting_failing_names(workspace)
            result[bug_path.name] = frozenset(failing)
    return result


# ---------------------------------------------------------------------------
# AC-6: bug-set distinctness and detectability
# ---------------------------------------------------------------------------

class TestInjectedBugsDistinct:
    """AC-6: 10 bugs, each killable by ≥1 frozen test, all sets distinct."""

    def test_ac6_ten_bugs_present(self) -> None:
        """The pack must ship exactly 10 bug variants."""
        bugs = _bug_paths()
        assert len(bugs) == 10, (
            f"Expected exactly 10 injected_bugs/bug_NN.py files; "
            f"found {len(bugs)}: {[b.name for b in bugs]}"
        )

    def test_ac6_reference_impl_passes_all_six_frozen_tests(self) -> None:
        """Baseline anchor: the inline reference implementation MUST pass
        all six frozen tests. Without this, a bug-set distinctness check is
        meaningless — we'd be measuring "distinctness of failures" against
        a possibly-broken oracle (Phase 5c review HIGH-2)."""
        with tempfile.TemporaryDirectory() as tmpdir:
            workspace = Path(tmpdir)
            (workspace / "shortener.py").write_text(_REFERENCE_SHORTENER_SOURCE)
            failing = _run_frozen_suite_collecting_failing_names(workspace)
        assert failing == frozenset(), (
            f"Reference implementation failed frozen tests {sorted(failing)}; "
            f"the frozen suite has a false-negative against a known-correct impl."
        )

    def test_ac6_every_bug_killed_by_at_least_one_test(
        self, bug_failing_sets: dict[str, frozenset[str]]
    ) -> None:
        """Every bug must produce a non-empty failing-test-name set —
        a bug undetectable by the frozen suite is not a useful mutant."""
        undetected = [name for name, failing in bug_failing_sets.items() if not failing]
        assert not undetected, (
            f"These bug variants pass all frozen tests (no failures detected): "
            f"{undetected}. Each bug must be killable by at least one frozen test."
        )

    def test_ac6_no_bug_collapses_to_collection_error_sentinel(
        self, bug_failing_sets: dict[str, frozenset[str]]
    ) -> None:
        """No bug should crash on import (yielding the <collection-error>
        sentinel). Two import-broken bugs would produce identical sentinel
        sets, which the distinctness check would surface as a "collision"
        — but the underlying problem is broken bugs, not a distinctness
        failure. Surface that explicitly (Phase 5c review HIGH-1)."""
        sentinel = frozenset({"<collection-error>"})
        broken = [name for name, failing in bug_failing_sets.items() if failing == sentinel]
        assert not broken, (
            f"These bugs raised collection errors (broken import?): {broken}. "
            f"Each bug must be parseable Python that fails specific tests, "
            f"not a syntax/import error masquerading as a failure mode."
        )

    def test_ac6_failing_test_name_sets_pairwise_distinct(
        self, bug_failing_sets: dict[str, frozenset[str]]
    ) -> None:
        """All 10 failing-test-name sets must be pairwise distinct.

        This is the AC-6 oracle as reframed at Phase 5c: distinct failure
        modes (which tests fail), not distinct count tuples (which is
        mathematically infeasible with 6 tests + 0 errors)."""
        seen: dict[frozenset[str], list[str]] = {}
        for bug_name, failing in bug_failing_sets.items():
            seen.setdefault(failing, []).append(bug_name)
        collisions = {fs: bugs for fs, bugs in seen.items() if len(bugs) > 1}
        assert not collisions, (
            f"Bug variants share failing-test-name sets (AC-6 violation): "
            + ", ".join(
                f"{sorted(bugs)} all fail {sorted(fs)}"
                for fs, bugs in collisions.items()
            )
        )


# ---------------------------------------------------------------------------
# Pack manifest smoke check (cross-cutting against AC-1 / AC-3 contract)
# ---------------------------------------------------------------------------

class TestUrlShortenerPackManifest:
    """Smoke-test that pack.yaml loads cleanly and exposes the manifest fields
    harness.runner consumes downstream. Per-field behavior is covered by
    tests/task_packs/test_loader.py; this is a pack-level integration check."""

    def test_pack_yaml_loads(self) -> None:
        pack = load_pack(PACK_DIR)
        assert pack.name == "url_shortener"
        assert pack.language == "python"
        assert pack.entry_point == "shortener.py"

    def test_pack_manifest_has_required_keys(self) -> None:
        pack = load_pack(PACK_DIR)
        manifest = pack.to_manifest_dict()
        for key in ("entry_point", "test_command", "stryker_config_path", "language"):
            assert key in manifest, f"manifest missing required key {key!r}"

    def test_pack_image_is_structurally_pinned(self) -> None:
        """The container_image_pinned field must match the pinned-digest regex.
        At Phase 5c this is a sentinel all-zero digest (Phase 5d replaces it
        with the real digest of the built image — see Pivot Log)."""
        pack = load_pack(PACK_DIR)
        assert "@sha256:" in pack.container_image_pinned
        digest = pack.container_image_pinned.split("@sha256:", 1)[1]
        assert len(digest) == 64
        assert all(c in "0123456789abcdef" for c in digest)
