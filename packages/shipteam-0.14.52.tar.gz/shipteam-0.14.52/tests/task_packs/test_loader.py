"""
Tests for task_packs/loader.py — Phase 5a RED phase.

Covers:
  AC-1: load_pack() returns a populated TaskPack dataclass with a working
        to_manifest_dict() that includes the four required keys consumed by
        harness.runner downstream.

  AC-2: load_pack() raises KeyError whose message names BOTH the missing field
        AND the file path when a required field is absent from pack.yaml.

  AC-3: load_pack() raises ValueError when container_image_pinned is a bare tag
        (no @sha256:<digest> suffix). The error message must mention the format.

  AC-22: CLAUDE_RATE_SHEET_2026_04 is a dict keyed by Anthropic model ID strings.
         compute_cost() raises KeyError for unknown models, TypeError for non-string
         model_id, and returns a non-negative float for a known model.
"""

from __future__ import annotations

import textwrap
from pathlib import Path

import pytest
import yaml

from task_packs.loader import (
    CLAUDE_RATE_SHEET_2026_04,
    TaskPack,
    compute_cost,
    load_pack,
)


# ---------------------------------------------------------------------------
# Fixture helpers — inline pack.yaml construction via tmp_path
# ---------------------------------------------------------------------------

_VALID_PACK_YAML: dict = {
    "name": "url_shortener",
    "container_image_pinned": (
        "python:3.12-slim"
        "@sha256:"
        "a1b2c3d4e5f6789012345678901234567890abcdef01234567890abcdef01234"
    ),
    "entry_point": "task_packs/url_shortener/solution.py",
    "test_command": "pytest task_packs/url_shortener/tests/",
    "stryker_config_path": "task_packs/url_shortener/stryker.conf.json",
    "language": "python",
    "seed": 42,
}


def _write_pack_yaml(pack_dir: Path, content: dict) -> Path:
    """Write a pack.yaml file into pack_dir and return the file path."""
    pack_dir.mkdir(parents=True, exist_ok=True)
    pack_yaml = pack_dir / "pack.yaml"
    pack_yaml.write_text(yaml.safe_dump(content))
    return pack_yaml


def _write_pack_yaml_raw(pack_dir: Path, raw_text: str) -> Path:
    """Write raw YAML text into pack_dir/pack.yaml and return the file path."""
    pack_dir.mkdir(parents=True, exist_ok=True)
    pack_yaml = pack_dir / "pack.yaml"
    pack_yaml.write_text(raw_text)
    return pack_yaml


# ---------------------------------------------------------------------------
# AC-1: load_pack returns a populated TaskPack with working to_manifest_dict()
# ---------------------------------------------------------------------------

class TestLoadPackValidYaml:
    """AC-1: load_pack() returns a TaskPack dataclass with all fields populated."""

    def test_ac1_load_pack_returns_task_pack_instance(self, tmp_path: Path) -> None:
        """
        Given a valid pack.yaml with all required fields,
        When load_pack(pack_dir) is called,
        Then the return value is an instance of TaskPack.
        """
        # Arrange
        pack_dir = tmp_path / "url_shortener"
        _write_pack_yaml(pack_dir, _VALID_PACK_YAML)

        # Act
        result = load_pack(pack_dir)

        # Assert
        assert isinstance(result, TaskPack)

    def test_ac1_task_pack_fields_populated(self, tmp_path: Path) -> None:
        """
        Given a valid pack.yaml,
        When load_pack(pack_dir) is called,
        Then all required fields are populated with the values from pack.yaml.
        """
        # Arrange
        pack_dir = tmp_path / "url_shortener"
        _write_pack_yaml(pack_dir, _VALID_PACK_YAML)

        # Act
        result = load_pack(pack_dir)

        # Assert — each required field matches what was written
        assert result.name == "url_shortener"
        assert result.entry_point == "task_packs/url_shortener/solution.py"
        assert result.test_command == "pytest task_packs/url_shortener/tests/"
        assert result.stryker_config_path == "task_packs/url_shortener/stryker.conf.json"
        assert result.language == "python"
        assert result.seed == 42

    def test_ac1_task_pack_pack_dir_is_path(self, tmp_path: Path) -> None:
        """
        Given a valid pack.yaml loaded from pack_dir,
        When load_pack(pack_dir) is called,
        Then result.pack_dir is a Path equal to the directory that was passed.
        """
        # Arrange
        pack_dir = tmp_path / "url_shortener"
        _write_pack_yaml(pack_dir, _VALID_PACK_YAML)

        # Act
        result = load_pack(pack_dir)

        # Assert
        assert isinstance(result.pack_dir, Path)
        assert result.pack_dir == pack_dir

    def test_ac1_to_manifest_dict_returns_dict(self, tmp_path: Path) -> None:
        """
        Given a valid TaskPack loaded from pack.yaml,
        When to_manifest_dict() is called,
        Then the return value is a dict.
        """
        # Arrange
        pack_dir = tmp_path / "url_shortener"
        _write_pack_yaml(pack_dir, _VALID_PACK_YAML)

        # Act
        result = load_pack(pack_dir)
        manifest = result.to_manifest_dict()

        # Assert
        assert isinstance(manifest, dict)

    def test_ac1_to_manifest_dict_includes_required_keys(self, tmp_path: Path) -> None:
        """
        Given a valid TaskPack loaded from pack.yaml,
        When to_manifest_dict() is called,
        Then the returned dict includes all four keys consumed by harness.runner:
        entry_point, test_command, stryker_config_path, language.

        AC-1 contract: exact key set is the downstream contract.
        """
        # Arrange
        pack_dir = tmp_path / "url_shortener"
        _write_pack_yaml(pack_dir, _VALID_PACK_YAML)

        # Act
        result = load_pack(pack_dir)
        manifest = result.to_manifest_dict()

        # Assert — all four required keys must be present
        for required_key in ("entry_point", "test_command", "stryker_config_path", "language"):
            assert required_key in manifest, (
                f"to_manifest_dict() missing required key '{required_key}'; "
                f"got keys: {sorted(manifest.keys())}"
            )

    def test_ac1_to_manifest_dict_values_match_pack_fields(self, tmp_path: Path) -> None:
        """
        Given a valid TaskPack loaded from pack.yaml,
        When to_manifest_dict() is called,
        Then the dict values for the four required keys match the TaskPack fields.
        """
        # Arrange
        pack_dir = tmp_path / "url_shortener"
        _write_pack_yaml(pack_dir, _VALID_PACK_YAML)

        # Act
        result = load_pack(pack_dir)
        manifest = result.to_manifest_dict()

        # Assert
        assert manifest["entry_point"] == result.entry_point
        assert manifest["test_command"] == result.test_command
        assert manifest["stryker_config_path"] == result.stryker_config_path
        assert manifest["language"] == result.language

    def test_ac1_task_pack_is_frozen_dataclass(self, tmp_path: Path) -> None:
        """
        Given a valid TaskPack loaded from pack.yaml,
        When an attempt is made to mutate a field,
        Then FrozenInstanceError (or AttributeError) is raised — frozen=True contract.
        """
        # Arrange
        pack_dir = tmp_path / "url_shortener"
        _write_pack_yaml(pack_dir, _VALID_PACK_YAML)

        # Act
        result = load_pack(pack_dir)

        # Assert — frozen dataclass must reject mutation
        with pytest.raises((AttributeError, TypeError)):
            result.name = "hacked"  # type: ignore[misc]

    def test_ac1_load_pack_raises_file_not_found_when_pack_yaml_missing(
        self, tmp_path: Path
    ) -> None:
        """
        Given a pack_dir that exists but has no pack.yaml,
        When load_pack(pack_dir) is called,
        Then FileNotFoundError is raised (Interface Contract explicit guarantee).
        """
        # Arrange
        pack_dir = tmp_path / "missing_pack"
        pack_dir.mkdir()
        # No pack.yaml written

        # Act / Assert
        with pytest.raises(FileNotFoundError):
            load_pack(pack_dir)


# ---------------------------------------------------------------------------
# AC-2: load_pack raises KeyError naming missing field AND file path
# ---------------------------------------------------------------------------

class TestLoadPackMissingRequiredField:
    """AC-2: load_pack() raises a descriptive KeyError for missing required fields."""

    def test_ac2_missing_container_image_raises_key_error(self, tmp_path: Path) -> None:
        """
        Given a pack.yaml missing the 'container_image_pinned' key,
        When load_pack(pack_dir) is called,
        Then KeyError is raised.
        """
        # Arrange
        pack_dir = tmp_path / "bad_pack"
        incomplete = {k: v for k, v in _VALID_PACK_YAML.items() if k != "container_image_pinned"}
        _write_pack_yaml(pack_dir, incomplete)

        # Act / Assert
        with pytest.raises(KeyError):
            load_pack(pack_dir)

    def test_ac2_key_error_message_names_missing_field(self, tmp_path: Path) -> None:
        """
        Given a pack.yaml missing 'container_image_pinned',
        When load_pack(pack_dir) raises KeyError,
        Then the error message names the missing field 'container_image_pinned'.
        """
        # Arrange
        pack_dir = tmp_path / "bad_pack"
        incomplete = {k: v for k, v in _VALID_PACK_YAML.items() if k != "container_image_pinned"}
        _write_pack_yaml(pack_dir, incomplete)

        # Act / Assert
        with pytest.raises(KeyError) as exc_info:
            load_pack(pack_dir)

        error_text = str(exc_info.value)
        assert "container_image_pinned" in error_text, (
            f"KeyError message should name the missing field 'container_image_pinned'; "
            f"got: {error_text!r}"
        )

    def test_ac2_key_error_message_names_file_path(self, tmp_path: Path) -> None:
        """
        Given a pack.yaml missing 'container_image_pinned',
        When load_pack(pack_dir) raises KeyError,
        Then the error message names the file path being parsed.
        """
        # Arrange
        pack_dir = tmp_path / "bad_pack"
        incomplete = {k: v for k, v in _VALID_PACK_YAML.items() if k != "container_image_pinned"}
        _write_pack_yaml(pack_dir, incomplete)
        expected_path_fragment = str(pack_dir / "pack.yaml")

        # Act / Assert
        with pytest.raises(KeyError) as exc_info:
            load_pack(pack_dir)

        error_text = str(exc_info.value)
        assert expected_path_fragment in error_text or "pack.yaml" in error_text, (
            f"KeyError message should name the file path; "
            f"expected fragment '{expected_path_fragment}' in: {error_text!r}"
        )

    def test_ac2_key_error_names_both_field_and_path(self, tmp_path: Path) -> None:
        """
        Given a pack.yaml missing 'container_image_pinned',
        When load_pack(pack_dir) raises KeyError,
        Then the error message names BOTH the missing field AND the file path.

        This is the combined assertion for the AC-2 contract.
        """
        # Arrange
        pack_dir = tmp_path / "bad_pack_combined"
        incomplete = {k: v for k, v in _VALID_PACK_YAML.items() if k != "container_image_pinned"}
        _write_pack_yaml(pack_dir, incomplete)

        # Act / Assert
        with pytest.raises(KeyError) as exc_info:
            load_pack(pack_dir)

        error_text = str(exc_info.value)
        assert "container_image_pinned" in error_text, (
            f"Missing field name absent from error: {error_text!r}"
        )
        assert "pack.yaml" in error_text, (
            f"File path absent from error: {error_text!r}"
        )

    def test_ac2_no_partial_task_pack_constructed(self, tmp_path: Path) -> None:
        """
        Given a pack.yaml missing 'container_image_pinned',
        When load_pack(pack_dir) raises KeyError,
        Then no return value is produced (constructor never ran with missing data).

        The test verifies this by confirming the exception is raised before any
        TaskPack is returned.
        """
        # Arrange
        pack_dir = tmp_path / "no_partial_pack"
        incomplete = {k: v for k, v in _VALID_PACK_YAML.items() if k != "container_image_pinned"}
        _write_pack_yaml(pack_dir, incomplete)

        # Act / Assert — if a TaskPack were returned, this would not raise
        result = None
        try:
            result = load_pack(pack_dir)
        except KeyError:
            pass  # Expected

        assert result is None, (
            "load_pack() must not return a partial TaskPack when a required field is missing"
        )

    def test_ac2_missing_entry_point_raises_key_error_with_field_and_path(
        self, tmp_path: Path
    ) -> None:
        """
        Given a pack.yaml missing the 'entry_point' required field,
        When load_pack(pack_dir) raises KeyError,
        Then the error message names both 'entry_point' and the file path.

        Confirms the KeyError contract applies to any missing required field,
        not just container_image_pinned.
        """
        # Arrange
        pack_dir = tmp_path / "missing_entry_point"
        incomplete = {k: v for k, v in _VALID_PACK_YAML.items() if k != "entry_point"}
        _write_pack_yaml(pack_dir, incomplete)

        # Act / Assert
        with pytest.raises(KeyError) as exc_info:
            load_pack(pack_dir)

        error_text = str(exc_info.value)
        assert "entry_point" in error_text, (
            f"Error must name missing field 'entry_point'; got: {error_text!r}"
        )
        assert "pack.yaml" in error_text, (
            f"Error must name the file path; got: {error_text!r}"
        )


# ---------------------------------------------------------------------------
# AC-3: load_pack raises ValueError for unpinned container_image
# ---------------------------------------------------------------------------

class TestLoadPackUnpinnedContainerImage:
    """AC-3: load_pack() rejects container_image_pinned values without @sha256: digest."""

    def test_ac3_bare_tag_raises_value_error(self, tmp_path: Path) -> None:
        """
        Given a pack.yaml where container_image_pinned is 'python:3.12-slim' (no @sha256:),
        When load_pack(pack_dir) is called,
        Then ValueError is raised.
        """
        # Arrange
        pack_dir = tmp_path / "unpinned_pack"
        bad_content = dict(_VALID_PACK_YAML, container_image_pinned="python:3.12-slim")
        _write_pack_yaml(pack_dir, bad_content)

        # Act / Assert
        with pytest.raises(ValueError):
            load_pack(pack_dir)

    def test_ac3_error_message_mentions_sha256_format(self, tmp_path: Path) -> None:
        """
        Given a pack.yaml with a bare tag container_image_pinned = 'python:3.12-slim',
        When load_pack(pack_dir) raises ValueError,
        Then the error message mentions 'sha256', 'pinned', or '@sha256:' so the
        operator knows the format requirement.
        """
        # Arrange
        pack_dir = tmp_path / "unpinned_pack_message"
        bad_content = dict(_VALID_PACK_YAML, container_image_pinned="python:3.12-slim")
        _write_pack_yaml(pack_dir, bad_content)

        # Act / Assert
        with pytest.raises(ValueError) as exc_info:
            load_pack(pack_dir)

        error_text = str(exc_info.value).lower()
        assert any(keyword in error_text for keyword in ("sha256", "pinned", "@sha256:")), (
            f"ValueError message must mention sha256/pinned/@sha256: for operator guidance; "
            f"got: {str(exc_info.value)!r}"
        )

    def test_ac3_image_with_tag_only_no_digest_raises(self, tmp_path: Path) -> None:
        """
        Given container_image_pinned = 'ubuntu:22.04' (tag-only, no digest),
        When load_pack(pack_dir) is called,
        Then ValueError is raised.
        """
        # Arrange
        pack_dir = tmp_path / "tag_only_pack"
        bad_content = dict(_VALID_PACK_YAML, container_image_pinned="ubuntu:22.04")
        _write_pack_yaml(pack_dir, bad_content)

        # Act / Assert
        with pytest.raises(ValueError):
            load_pack(pack_dir)

    def test_ac3_image_with_latest_tag_raises(self, tmp_path: Path) -> None:
        """
        Given container_image_pinned = 'python:latest' (latest tag, no digest),
        When load_pack(pack_dir) is called,
        Then ValueError is raised.
        """
        # Arrange
        pack_dir = tmp_path / "latest_tag_pack"
        bad_content = dict(_VALID_PACK_YAML, container_image_pinned="python:latest")
        _write_pack_yaml(pack_dir, bad_content)

        # Act / Assert
        with pytest.raises(ValueError):
            load_pack(pack_dir)

    def test_ac3_valid_sha256_pinned_image_passes(self, tmp_path: Path) -> None:
        """
        Given container_image_pinned with a valid @sha256:<64-hex-chars> suffix,
        When load_pack(pack_dir) is called,
        Then no ValueError is raised and a TaskPack is returned.
        """
        # Arrange — 64 lowercase hex chars after @sha256:
        valid_digest = "a" * 64
        pack_dir = tmp_path / "pinned_pack"
        good_content = dict(
            _VALID_PACK_YAML,
            container_image_pinned=f"python:3.12-slim@sha256:{valid_digest}",
        )
        _write_pack_yaml(pack_dir, good_content)

        # Act
        result = load_pack(pack_dir)

        # Assert
        assert isinstance(result, TaskPack)
        assert f"@sha256:{valid_digest}" in result.container_image_pinned

    def test_ac3_short_digest_not_64_hex_chars_raises(self, tmp_path: Path) -> None:
        """
        Given container_image_pinned with @sha256: followed by fewer than 64 hex chars,
        When load_pack(pack_dir) is called,
        Then ValueError is raised (not a valid SHA-256 digest).
        """
        # Arrange — only 32 hex chars (too short for SHA-256)
        short_digest = "deadbeef" * 4  # 32 chars, not 64
        pack_dir = tmp_path / "short_digest_pack"
        bad_content = dict(
            _VALID_PACK_YAML,
            container_image_pinned=f"python:3.12-slim@sha256:{short_digest}",
        )
        _write_pack_yaml(pack_dir, bad_content)

        # Act / Assert
        with pytest.raises(ValueError):
            load_pack(pack_dir)


# ---------------------------------------------------------------------------
# AC-22: CLAUDE_RATE_SHEET_2026_04 and compute_cost contract
# ---------------------------------------------------------------------------

class TestClaudeRateSheet:
    """AC-22: CLAUDE_RATE_SHEET_2026_04 structure and compute_cost() error contract."""

    def test_ac22_rate_sheet_is_dict(self) -> None:
        """
        Given CLAUDE_RATE_SHEET_2026_04,
        When its type is inspected,
        Then it is a dict.
        """
        assert isinstance(CLAUDE_RATE_SHEET_2026_04, dict)

    def test_ac22_rate_sheet_has_string_keys(self) -> None:
        """
        Given CLAUDE_RATE_SHEET_2026_04 is populated,
        When its keys are inspected,
        Then all keys are strings (Anthropic model ID format).
        """
        # Rate sheet may be empty in RED phase but the type must be dict[str, ...]
        for key in CLAUDE_RATE_SHEET_2026_04:
            assert isinstance(key, str), (
                f"Rate sheet key must be str (model_id); got {type(key)}: {key!r}"
            )

    def test_ac22_rate_sheet_values_are_dicts(self) -> None:
        """
        Given CLAUDE_RATE_SHEET_2026_04 is populated,
        When its values are inspected,
        Then each value is a dict (pricing sub-dict per model).
        """
        for model_id, pricing in CLAUDE_RATE_SHEET_2026_04.items():
            assert isinstance(pricing, dict), (
                f"Rate sheet value for '{model_id}' must be a dict; got {type(pricing)}"
            )


class TestComputeCost:
    """AC-22: compute_cost() error contract — KeyError, TypeError, and happy path."""

    def test_ac22_unknown_model_raises_key_error(self) -> None:
        """
        Given model_id = 'claude-fictional-2099' (not in rate sheet),
        When compute_cost() is called,
        Then KeyError is raised.
        """
        # Act / Assert
        with pytest.raises(KeyError):
            compute_cost("claude-fictional-2099", 100, 100)

    def test_ac22_key_error_message_names_model_id(self) -> None:
        """
        Given model_id = 'claude-fictional-2099',
        When compute_cost() raises KeyError,
        Then the error message names the offending model_id.

        AC-22 contract: no silent fallback; operator must see which model failed.
        """
        # Act / Assert
        with pytest.raises(KeyError) as exc_info:
            compute_cost("claude-fictional-2099", 100, 100)

        error_text = str(exc_info.value)
        assert "claude-fictional-2099" in error_text, (
            f"KeyError message must name the model_id; got: {error_text!r}"
        )

    def test_ac22_non_string_model_id_raises_type_error(self) -> None:
        """
        Given model_id = 123 (not a string),
        When compute_cost() is called,
        Then TypeError is raised.

        AC-22 contract: type-safety before dict lookup; no accidental int key match.
        """
        # Act / Assert
        with pytest.raises(TypeError):
            compute_cost(123, 100, 100)  # type: ignore[arg-type]

    def test_ac22_none_model_id_raises_type_error(self) -> None:
        """
        Given model_id = None (not a string),
        When compute_cost() is called,
        Then TypeError is raised.
        """
        # Act / Assert
        with pytest.raises(TypeError):
            compute_cost(None, 100, 100)  # type: ignore[arg-type]

    def test_ac22_known_model_returns_non_negative_float(self) -> None:
        """
        Given model_id = 'claude-opus-4-7' (assumed valid key per spec),
        When compute_cost('claude-opus-4-7', 1_000_000, 500_000) is called,
        Then a non-negative float is returned.

        The exact value is left to GREEN (depends on rate sheet contents).
        AC-22 contract: the return type is float, and it is >= 0.0.
        """
        # Act
        result = compute_cost("claude-opus-4-7", 1_000_000, 500_000)

        # Assert
        assert isinstance(result, float), (
            f"compute_cost must return float; got {type(result)}"
        )
        assert result >= 0.0, (
            f"compute_cost must return non-negative value; got {result}"
        )

    def test_ac22_no_silent_fallback_to_default_rate(self) -> None:
        """
        Given two consecutive unknown model IDs,
        When compute_cost() is called with each,
        Then both raise KeyError (no fallback model is silently substituted).

        AC-22 contract: no silent fallback to a 'default' rate.
        """
        unknown_models = ["claude-fake-v1", "claude-imaginary-42"]
        for model_id in unknown_models:
            with pytest.raises(KeyError):
                compute_cost(model_id, 1000, 500)


# ---------------------------------------------------------------------------
# Phase-5{a,b,c}-followup HIGH-1: test_command must reject -x / --exitfirst
# ---------------------------------------------------------------------------

class TestLoadPackForbidsExitFirst:
    """
    AC-13 / Phase-5{a,b,c}-followup HIGH-1:

    Pytest's `-x` (alias `--exitfirst`) stops the suite on the first failure.
    A pack that ships `-x` would inflate acceptance_pct by short-circuiting
    after a single failure rather than counting the failures of all later
    cases, defeating the scoring oracle. The loader rejects this at parse
    time — earlier than runtime — so an operator gets a clear error before
    a benchmark run silently produces a misleading score.
    """

    @pytest.mark.parametrize(
        "bad_command",
        [
            "pytest task_packs/url_shortener/tests/ -x",
            "pytest task_packs/url_shortener/tests/ --exitfirst",
            "pytest -x task_packs/url_shortener/tests/",
            "pytest --exitfirst task_packs/url_shortener/tests/",
            "pytest task_packs/url_shortener/tests/ -v -x",
            "pytest task_packs/url_shortener/tests/ -x -v",
            "pytest --exitfirst -v task_packs/url_shortener/tests/",
        ],
    )
    def test_load_pack_rejects_exitfirst_in_test_command(
        self,
        tmp_path: Path,
        bad_command: str,
    ) -> None:
        """
        Given a pack.yaml whose test_command contains -x or --exitfirst,
        When load_pack(pack_dir) is called,
        Then ValueError is raised, and the message names the forbidden flag
        and explains why (acceptance_pct inflation).
        """
        # Arrange
        pack_dir = tmp_path / "url_shortener"
        bad_pack = dict(_VALID_PACK_YAML)
        bad_pack["test_command"] = bad_command
        _write_pack_yaml(pack_dir, bad_pack)

        # Act + Assert
        with pytest.raises(ValueError) as exc_info:
            load_pack(pack_dir)

        error_msg = str(exc_info.value)
        assert "-x" in error_msg or "--exitfirst" in error_msg, (
            f"ValueError message must name the forbidden flag. Got: {error_msg!r}"
        )
        assert "acceptance_pct" in error_msg or "inflate" in error_msg.lower() or "first failure" in error_msg.lower(), (
            f"ValueError message must explain why -x is forbidden. Got: {error_msg!r}"
        )

    @pytest.mark.parametrize(
        "ok_command",
        [
            # bare pytest invocation
            "pytest task_packs/url_shortener/tests/",
            # other flags allowed
            "pytest task_packs/url_shortener/tests/ -v",
            "pytest task_packs/url_shortener/tests/ --tb=short",
            # filenames or paths that happen to contain '-x' as a substring
            # are not rejected (the regex requires word boundaries / whitespace
            # so 'test-extra.py' or '--maxfail=3' are safe).
            "pytest task_packs/some-x-package/tests/",
            "pytest task_packs/url_shortener/tests/ --maxfail=3",
        ],
    )
    def test_load_pack_accepts_test_command_without_exitfirst(
        self,
        tmp_path: Path,
        ok_command: str,
    ) -> None:
        """
        Given a pack.yaml whose test_command does NOT contain -x or --exitfirst,
        When load_pack(pack_dir) is called,
        Then it returns successfully (no false-positive rejection of safe
        flags or substring matches like '-x' inside a filename).
        """
        # Arrange
        pack_dir = tmp_path / "url_shortener"
        ok_pack = dict(_VALID_PACK_YAML)
        ok_pack["test_command"] = ok_command
        _write_pack_yaml(pack_dir, ok_pack)

        # Act — must not raise
        result = load_pack(pack_dir)

        # Assert
        assert result.test_command == ok_command
