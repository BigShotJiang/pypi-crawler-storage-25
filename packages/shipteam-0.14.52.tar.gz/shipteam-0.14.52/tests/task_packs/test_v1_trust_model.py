"""
Tests for Task Pack v1 trust model — AC-21 (Phase 5{a,b,c}-followup C-1).

Covers two assertions on the v1 trust boundary:

  Part A — Documentation contract:
    `docs/60-FEATURES.md` must contain the four AC-21 trust-model statements
    so an operator reading the docs knows: (1) packs are first-party only,
    (2) third-party `prompt.md` is the indirect-injection vector per OWASP
    LLM01:2025, (3) v1.1 will add a prompt-content review gate, (4) until
    then, external packs are unsupported. This test parses the docs file
    rather than referring to a stable spec ID, because the docs ARE the spec
    for an operator who never opens `.sherlock-plan.md`.

  Part B — Loader API contract:
    The pack-loader must NOT expose any symbol named `external_pack_url` or
    accept a `--external-pack-url` flag. If a future commit reintroduces
    one without the v1.1 sandboxed review gate (ADR-019), this test fails
    loudly. This is a structural assertion — it inspects the public symbol
    table of `task_packs/loader.py`, not behavior — because the threat
    model is "any escape hatch defeats the boundary," and an unused
    function still counts as an escape hatch (someone will call it).

Why these two parts together:
  Docs without code enforcement is a sign that lies; code enforcement
  without docs leaves operators guessing. The combination is what makes
  AC-21 actually load-bearing: an external-pack request gets refused at
  the API surface, AND the operator has documentation explaining why.
"""

from __future__ import annotations

import inspect
from pathlib import Path

import pytest

from task_packs import loader as pack_loader


# ---------------------------------------------------------------------------
# Repo-root resolution
# ---------------------------------------------------------------------------

# tests/task_packs/test_v1_trust_model.py → repo root is two levels up
_REPO_ROOT = Path(__file__).resolve().parent.parent.parent
_FEATURES_DOC = _REPO_ROOT / "docs" / "60-FEATURES.md"


# ---------------------------------------------------------------------------
# Part A — Documentation contract (AC-21 statements 1-4)
# ---------------------------------------------------------------------------

class TestTrustModelDocumentation:
    """
    AC-21 documentation contract: docs/60-FEATURES.md must contain the four
    trust-model statements verbatim enough that an automated parse catches
    accidental removal. Each statement is keyed by a load-bearing phrase
    chosen from the docs, NOT a free-form synonym set — if the doc is
    edited, this test must be edited in lockstep.
    """

    def test_features_doc_exists(self) -> None:
        """The features doc must exist at the expected path so all
        downstream assertions have a target to parse."""
        assert _FEATURES_DOC.exists(), (
            f"AC-21 docs file not found at {_FEATURES_DOC}. "
            f"The trust-model section is required by AC-21."
        )

    def test_trust_model_section_header_present(self) -> None:
        """The Trust Model section must be discoverable by header."""
        text = _FEATURES_DOC.read_text(encoding="utf-8")
        assert "Trust Model — Task Pack v1" in text, (
            "AC-21 requires a 'Trust Model — Task Pack v1' section header "
            "in docs/60-FEATURES.md so operators can find the doc by ToC."
        )

    def test_statement_1_first_party_only(self) -> None:
        """
        AC-21 (a): v1 ships only first-party packs.

        Required phrase: 'First-party packs only.' (exact, with the period).
        Substring matches like 'first-party' or 'packs only' are too loose —
        a future doc edit could keep the words but lose the meaning.
        """
        text = _FEATURES_DOC.read_text(encoding="utf-8")
        assert "First-party packs only." in text, (
            "AC-21 (a) requires the literal phrase 'First-party packs only.' "
            "in docs/60-FEATURES.md (Trust Model section). If you've reworded "
            "the docs, update this assertion AND the .sherlock-plan.md AC-21 "
            "spec in lockstep."
        )

    def test_statement_2_owasp_llm01_indirect_injection(self) -> None:
        """
        AC-21 (b): third-party prompt.md is the indirect-injection vector
        per OWASP LLM01:2025.

        Required phrase: 'OWASP LLM01:2025' (the exact citation token).
        """
        text = _FEATURES_DOC.read_text(encoding="utf-8")
        assert "OWASP LLM01:2025" in text, (
            "AC-21 (b) requires the citation 'OWASP LLM01:2025' in "
            "docs/60-FEATURES.md so the threat-model assumption is "
            "traceable to the upstream taxonomy."
        )
        assert "indirect injection" in text.lower() or "indirect-injection" in text.lower(), (
            "AC-21 (b) requires the docs to name 'indirect injection' "
            "(or 'indirect-injection') as the attack class — the OWASP "
            "citation alone is not enough; operators must see the term."
        )

    def test_statement_3_v1_1_review_gate(self) -> None:
        """
        AC-21 (c): v1.1 will add a prompt-content review gate.
        """
        text = _FEATURES_DOC.read_text(encoding="utf-8")
        assert "v1.1" in text and "review gate" in text.lower(), (
            "AC-21 (c) requires the docs to commit to a v1.1 'review gate' "
            "for prompt content. If the version target shifts (e.g., to "
            "v1.2), update this assertion and the AC-21 spec in lockstep."
        )

    def test_statement_4_external_packs_unsupported(self) -> None:
        """
        AC-21 (d): until v1.1 ships, accepting external packs is unsupported.

        We accept either 'unsupported' or 'not supported' since the negation
        wording is reasonably stable; both phrasings carry the same operator
        meaning.
        """
        text = _FEATURES_DOC.read_text(encoding="utf-8").lower()
        has_external = "external pack" in text
        has_unsupported = "unsupported" in text or "not supported" in text
        assert has_external and has_unsupported, (
            "AC-21 (d) requires the docs to state explicitly that external "
            "packs are unsupported (or 'not supported') in v1. Both terms "
            "must appear in the Trust Model section."
        )


# ---------------------------------------------------------------------------
# Part B — Loader API contract (AC-21 escape-hatch absence)
# ---------------------------------------------------------------------------

class TestTrustModelLoaderApi:
    """
    AC-21 loader-API contract: the pack-loader must not expose any public
    symbol that lets a caller load a pack from an external URL. We assert
    on the symbol table because behavior tests can't enumerate "all the
    ways someone could call X" — the only way to prove the escape hatch
    isn't there is to show it doesn't exist as a name.
    """

    def test_loader_module_has_no_external_pack_url_symbol(self) -> None:
        """
        Given task_packs.loader,
        When its public symbol table is inspected,
        Then no name contains 'external_pack_url' (case-insensitive).

        This is a structural guard. If a future commit adds a function or
        constant by that name (or a near-miss like `_external_pack_url`,
        `EXTERNAL_PACK_URL`), this test fails. The check is intentionally
        broader than 'public only' — even a private helper is a vector if
        someone imports it via `from task_packs.loader import _foo`.
        """
        names = dir(pack_loader)
        offending = [n for n in names if "external_pack_url" in n.lower()]
        assert not offending, (
            f"AC-21 loader-API contract violated: task_packs.loader must "
            f"not expose any 'external_pack_url' symbol (the v1 trust "
            f"model rejects external packs). Found: {offending!r}. "
            f"If you intended to add v1.1 external-pack support, do it "
            f"behind the ADR-019 review-gate path, not as a bare loader "
            f"symbol."
        )

    def test_load_pack_signature_takes_only_pack_dir(self) -> None:
        """
        Given task_packs.loader.load_pack,
        When its signature is inspected,
        Then it accepts exactly one parameter (`pack_dir`), no kwargs that
        could route to an external URL.

        This catches the "added a kwarg that defaults to None" smell where
        the symbol-table check above passes (no name match) but the
        function silently grows an external-loading parameter.
        """
        sig = inspect.signature(pack_loader.load_pack)
        params = list(sig.parameters.keys())
        assert params == ["pack_dir"], (
            f"AC-21: load_pack() must take exactly one parameter "
            f"(`pack_dir`), no keyword arguments that could route to an "
            f"external URL. Got: {params!r}. If you need a new parameter, "
            f"justify it against AC-21 in the PR description first."
        )

    def test_resolve_pack_signature_takes_only_task_id(self) -> None:
        """
        Given task_packs.loader.resolve_pack,
        When its signature is inspected,
        Then it accepts exactly one parameter (`task_id`), no kwargs.

        resolve_pack is the public-facing entry point operators call; it
        must not grow an external-URL parameter without going through
        ADR-019.
        """
        sig = inspect.signature(pack_loader.resolve_pack)
        params = list(sig.parameters.keys())
        assert params == ["task_id"], (
            f"AC-21: resolve_pack() must take exactly one parameter "
            f"(`task_id`), no keyword arguments. Got: {params!r}."
        )
