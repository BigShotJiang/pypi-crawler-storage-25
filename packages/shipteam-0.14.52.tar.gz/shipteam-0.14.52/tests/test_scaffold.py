"""
Tests for shipteam.scaffold — .claude/ directory scaffolding and .gitignore management.

Covers:
  - AC-8:  Conflict detection (existing .claude/ with/without --force, user files preserved)
  - AC-9:  All agents installed regardless of --profile (no tier gating)
  - AC-14: .gitignore scaffolding (create, append, idempotent, partial)
"""
import textwrap
from pathlib import Path
from typing import Optional

import pytest

from shipteam.scaffold import ConflictError, ScaffoldResult, scaffold_claude_dir, scaffold_gitignore

# ---------------------------------------------------------------------------
# Required .gitignore entries (source of truth for AC-14 tests)
# ---------------------------------------------------------------------------
REQUIRED_GITIGNORE_ENTRIES = [
    ".claude/state/",
    ".context/",
    ".qa-reports/",
    ".shipteam-init.yaml",
    "/private/",
]

# ---------------------------------------------------------------------------
# Shared fixture: synthetic framework source directory
# ---------------------------------------------------------------------------

def _make_source_dir(tmp_path: Path) -> Path:
    """
    Build a synthetic framework source directory under tmp_path/source/.

    Layout:
        framework-meta.yaml
        agents/fw-review-code.md
        agents/fw-review-security.md
        rules/anti-patterns.md
        rules/security.md
        rules/sherlock-methodology.md
        skills/deploy.md
        skills/health.md
        hooks/auto-approve.py
        templates/CLAUDE.md.jinja
    """
    source_dir = tmp_path / "source"
    source_dir.mkdir()

    # framework-meta.yaml
    meta = textwrap.dedent("""\
        min_cli_version: "0.13.0"
        schema_version: 1
        profile_filters:
          rules:
            minimal: [anti-patterns.md]
            standard: [anti-patterns.md, security.md]
            full: ["*"]
          skills:
            minimal: []
            standard: [deploy.md]
            full: ["*"]
    """)
    (source_dir / "framework-meta.yaml").write_text(meta)

    # agents — always copied fully, no profile filtering
    agents_dir = source_dir / "agents"
    agents_dir.mkdir()
    (agents_dir / "fw-review-code.md").write_text("# fw-review-code agent")
    (agents_dir / "fw-review-security.md").write_text("# fw-review-security agent")

    # rules
    rules_dir = source_dir / "rules"
    rules_dir.mkdir()
    (rules_dir / "anti-patterns.md").write_text("# Anti-patterns")
    (rules_dir / "security.md").write_text("# Security")
    (rules_dir / "sherlock-methodology.md").write_text("# Sherlock")

    # skills
    skills_dir = source_dir / "skills"
    skills_dir.mkdir()
    (skills_dir / "deploy.md").write_text("# Deploy skill")
    (skills_dir / "health.md").write_text("# Health skill")

    # hooks
    hooks_dir = source_dir / "hooks"
    hooks_dir.mkdir()
    (hooks_dir / "auto-approve.py").write_text("# auto-approve hook")

    # templates
    templates_dir = source_dir / "templates"
    templates_dir.mkdir()
    (templates_dir / "CLAUDE.md.jinja").write_text("# {{ project_name }} — Claude Docs")

    return source_dir


def _write_state_file(project_dir: Path) -> None:
    """Write a minimal .shipteam-init.yaml so scaffold treats the project as already owned."""
    state = textwrap.dedent("""\
        cli_version: "0.13.0"
        framework_version: "0.13.3"
        schema_version: 1
        rendered_at: "2026-04-12T00:00:00Z"
        template_hash: "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
        region_checksums: {}
        profile: "standard"
    """)
    (project_dir / ".shipteam-init.yaml").write_text(state)


# ---------------------------------------------------------------------------
# Tests: AC-8 — Fresh project (no .claude/, no state file)
# ---------------------------------------------------------------------------

class TestScaffoldFreshProject:
    """scaffold_claude_dir on a clean project writes all framework files."""

    def test_ac8_fresh_project_writes_all_framework_files(self, tmp_path: Path) -> None:
        """AC-8: no .claude/ and no state file → all framework files written."""
        # Arrange
        source_dir = _make_source_dir(tmp_path)
        project_dir = tmp_path / "project"
        project_dir.mkdir()
        # Act
        result = scaffold_claude_dir(
            project_dir=project_dir,
            source_dir=source_dir,
            profile="full",
        )
        # Assert: .claude/agents/ directory exists with both agents
        assert (project_dir / ".claude" / "agents" / "fw-review-code.md").exists()
        assert (project_dir / ".claude" / "agents" / "fw-review-security.md").exists()
        assert isinstance(result, ScaffoldResult)
        assert len(result.files_written) > 0

    def test_ac8_fresh_project_result_has_no_backup(self, tmp_path: Path) -> None:
        """AC-8: fresh scaffold → backup_path is None (nothing to back up)."""
        source_dir = _make_source_dir(tmp_path)
        project_dir = tmp_path / "project"
        project_dir.mkdir()
        result = scaffold_claude_dir(
            project_dir=project_dir,
            source_dir=source_dir,
            profile="full",
        )
        assert result.backup_path is None


# ---------------------------------------------------------------------------
# Tests: AC-8 — Conflict detection (existing .claude/, no state file)
# ---------------------------------------------------------------------------

class TestScaffoldConflictDetection:
    """scaffold_claude_dir raises ConflictError when .claude/ exists without a state file."""

    def test_ac8_existing_claude_no_state_no_force_raises_conflict(self, tmp_path: Path) -> None:
        """AC-8: .claude/ exists, no .shipteam-init.yaml, force=False → ConflictError."""
        # Arrange
        source_dir = _make_source_dir(tmp_path)
        project_dir = tmp_path / "project"
        project_dir.mkdir()
        (project_dir / ".claude").mkdir()
        (project_dir / ".claude" / "existing-file.md").write_text("existing content")
        # Act / Assert
        with pytest.raises(ConflictError):
            scaffold_claude_dir(
                project_dir=project_dir,
                source_dir=source_dir,
                profile="standard",
                force=False,
            )

    def test_ac8_conflict_error_nothing_overwritten(self, tmp_path: Path) -> None:
        """AC-8: ConflictError stops scaffold — existing content unchanged."""
        source_dir = _make_source_dir(tmp_path)
        project_dir = tmp_path / "project"
        project_dir.mkdir()
        (project_dir / ".claude").mkdir()
        original_file = project_dir / ".claude" / "existing-file.md"
        original_file.write_text("DO NOT OVERWRITE")
        # Act
        with pytest.raises(ConflictError):
            scaffold_claude_dir(
                project_dir=project_dir,
                source_dir=source_dir,
                profile="standard",
                force=False,
            )
        # Assert: existing file untouched
        assert original_file.read_text() == "DO NOT OVERWRITE"

    def test_ac8_conflict_with_force_creates_backup(self, tmp_path: Path) -> None:
        """AC-8: force=True → existing .claude/ backed up before scaffold proceeds."""
        source_dir = _make_source_dir(tmp_path)
        project_dir = tmp_path / "project"
        project_dir.mkdir()
        claude_dir = project_dir / ".claude"
        claude_dir.mkdir()
        (claude_dir / "old-file.md").write_text("old content")
        # Act
        result = scaffold_claude_dir(
            project_dir=project_dir,
            source_dir=source_dir,
            profile="full",
            force=True,
        )
        # Assert: backup created
        assert result.backup_path is not None
        assert result.backup_path.exists()
        # Backup contains the old file
        backed_up = list(result.backup_path.rglob("old-file.md"))
        assert len(backed_up) == 1, "old-file.md should exist in backup"
        assert backed_up[0].read_text() == "old content"

    def test_ac8_conflict_with_force_scaffold_proceeds(self, tmp_path: Path) -> None:
        """AC-8: force=True → new framework files written after backup."""
        source_dir = _make_source_dir(tmp_path)
        project_dir = tmp_path / "project"
        project_dir.mkdir()
        (project_dir / ".claude").mkdir()
        (project_dir / ".claude" / "old.md").write_text("old")
        # Act
        result = scaffold_claude_dir(
            project_dir=project_dir,
            source_dir=source_dir,
            profile="full",
            force=True,
        )
        # Assert: new framework files exist
        assert (project_dir / ".claude" / "agents" / "fw-review-code.md").exists()
        assert len(result.files_written) > 0

    def test_ac8_force_with_existing_backup_uses_timestamp_suffix(self, tmp_path: Path) -> None:
        """AC-8: if .claude.bak/ already exists, backup gets .claude.bak.YYYYMMDD-HHMMSS/ name."""
        source_dir = _make_source_dir(tmp_path)
        project_dir = tmp_path / "project"
        project_dir.mkdir()
        # Existing .claude/ AND existing .claude.bak/
        (project_dir / ".claude").mkdir()
        (project_dir / ".claude" / "file.md").write_text("x")
        (project_dir / ".claude.bak").mkdir()  # simulate prior backup
        # Act
        result = scaffold_claude_dir(
            project_dir=project_dir,
            source_dir=source_dir,
            profile="full",
            force=True,
        )
        # Assert: backup name has timestamp pattern (not plain .claude.bak)
        backup_name = result.backup_path.name
        assert backup_name != ".claude.bak", (
            f"Expected timestamp-suffixed backup name, got: {backup_name!r}"
        )
        assert backup_name.startswith(".claude.bak.")


# ---------------------------------------------------------------------------
# Tests: AC-8 — Additive merge when .shipteam-init.yaml exists
# ---------------------------------------------------------------------------

class TestScaffoldAdditiveMerge:
    """When .shipteam-init.yaml exists, scaffold merges without conflict — user files preserved."""

    def test_ac8_existing_state_file_no_conflict_raised(self, tmp_path: Path) -> None:
        """AC-8: .claude/ + .shipteam-init.yaml → no ConflictError (additive merge)."""
        source_dir = _make_source_dir(tmp_path)
        project_dir = tmp_path / "project"
        project_dir.mkdir()
        _write_state_file(project_dir)
        claude_dir = project_dir / ".claude"
        claude_dir.mkdir()
        # Act — should NOT raise ConflictError
        result = scaffold_claude_dir(
            project_dir=project_dir,
            source_dir=source_dir,
            profile="standard",
            force=False,
        )
        assert isinstance(result, ScaffoldResult)

    def test_ac8_user_created_rule_preserved_during_merge(self, tmp_path: Path) -> None:
        """AC-8: user-created .claude/rules/my-custom.md is NOT overwritten or deleted."""
        source_dir = _make_source_dir(tmp_path)
        project_dir = tmp_path / "project"
        project_dir.mkdir()
        _write_state_file(project_dir)
        claude_dir = project_dir / ".claude"
        rules_dir = claude_dir / "rules"
        rules_dir.mkdir(parents=True)
        custom_rule = rules_dir / "my-custom.md"
        custom_rule.write_text("# My custom rule — DO NOT DELETE")
        # Act
        result = scaffold_claude_dir(
            project_dir=project_dir,
            source_dir=source_dir,
            profile="standard",
            force=False,
        )
        # Assert: custom file still exists with original content
        assert custom_rule.exists()
        assert custom_rule.read_text() == "# My custom rule — DO NOT DELETE"

    def test_ac8_user_file_appears_in_files_skipped(self, tmp_path: Path) -> None:
        """AC-8: user-owned file not in framework manifest → in result.files_skipped."""
        source_dir = _make_source_dir(tmp_path)
        project_dir = tmp_path / "project"
        project_dir.mkdir()
        _write_state_file(project_dir)
        claude_dir = project_dir / ".claude"
        rules_dir = claude_dir / "rules"
        rules_dir.mkdir(parents=True)
        custom_rule = rules_dir / "my-custom.md"
        custom_rule.write_text("user rule")
        # Act
        result = scaffold_claude_dir(
            project_dir=project_dir,
            source_dir=source_dir,
            profile="standard",
            force=False,
        )
        # Assert: custom rule is in files_skipped
        skipped_names = [p.name for p in result.files_skipped]
        assert "my-custom.md" in skipped_names, (
            f"Expected my-custom.md in files_skipped, got: {skipped_names}"
        )


# ---------------------------------------------------------------------------
# Tests: AC-9 — All agents installed, no tier gating
# ---------------------------------------------------------------------------

class TestScaffoldAllAgentsInstalled:
    """AC-9: agents/ is always copied in full regardless of profile."""

    def test_ac9_minimal_profile_copies_all_agents(self, tmp_path: Path) -> None:
        """AC-9: --profile minimal still copies ALL agent files."""
        source_dir = _make_source_dir(tmp_path)
        project_dir = tmp_path / "project"
        project_dir.mkdir()
        # Act
        scaffold_claude_dir(
            project_dir=project_dir,
            source_dir=source_dir,
            profile="minimal",
        )
        # Assert: both agents present
        assert (project_dir / ".claude" / "agents" / "fw-review-code.md").exists()
        assert (project_dir / ".claude" / "agents" / "fw-review-security.md").exists()

    def test_ac9_standard_profile_copies_all_agents(self, tmp_path: Path) -> None:
        """AC-9: --profile standard copies ALL agent files."""
        source_dir = _make_source_dir(tmp_path)
        project_dir = tmp_path / "project"
        project_dir.mkdir()
        scaffold_claude_dir(
            project_dir=project_dir,
            source_dir=source_dir,
            profile="standard",
        )
        assert (project_dir / ".claude" / "agents" / "fw-review-code.md").exists()
        assert (project_dir / ".claude" / "agents" / "fw-review-security.md").exists()

    def test_ac9_minimal_profile_filters_rules(self, tmp_path: Path) -> None:
        """AC-9: --profile minimal applies rule filtering (only anti-patterns.md in rules/)."""
        source_dir = _make_source_dir(tmp_path)
        project_dir = tmp_path / "project"
        project_dir.mkdir()
        scaffold_claude_dir(
            project_dir=project_dir,
            source_dir=source_dir,
            profile="minimal",
        )
        # anti-patterns.md is in minimal list
        assert (project_dir / ".claude" / "rules" / "anti-patterns.md").exists()
        # security.md and sherlock-methodology.md are NOT in minimal
        assert not (project_dir / ".claude" / "rules" / "security.md").exists()
        assert not (project_dir / ".claude" / "rules" / "sherlock-methodology.md").exists()

    def test_ac9_minimal_profile_skips_all_skills(self, tmp_path: Path) -> None:
        """AC-9: --profile minimal → skills list is empty, no skill files copied."""
        source_dir = _make_source_dir(tmp_path)
        project_dir = tmp_path / "project"
        project_dir.mkdir()
        scaffold_claude_dir(
            project_dir=project_dir,
            source_dir=source_dir,
            profile="minimal",
        )
        assert not (project_dir / ".claude" / "skills" / "deploy.md").exists()

    def test_ac9_full_profile_wildcard_copies_all_files(self, tmp_path: Path) -> None:
        """AC-9: --profile full (*) copies all rules and all skills."""
        source_dir = _make_source_dir(tmp_path)
        project_dir = tmp_path / "project"
        project_dir.mkdir()
        scaffold_claude_dir(
            project_dir=project_dir,
            source_dir=source_dir,
            profile="full",
        )
        assert (project_dir / ".claude" / "rules" / "security.md").exists()
        assert (project_dir / ".claude" / "rules" / "sherlock-methodology.md").exists()
        assert (project_dir / ".claude" / "skills" / "deploy.md").exists()
        assert (project_dir / ".claude" / "skills" / "health.md").exists()

    def test_ac9_no_feature_tier_field_in_any_written_file(self, tmp_path: Path) -> None:
        """AC-9: 'feature_tier' must not appear in any file written by scaffold."""
        source_dir = _make_source_dir(tmp_path)
        project_dir = tmp_path / "project"
        project_dir.mkdir()
        scaffold_claude_dir(
            project_dir=project_dir,
            source_dir=source_dir,
            profile="full",
        )
        claude_dir = project_dir / ".claude"
        for written_file in claude_dir.rglob("*"):
            if written_file.is_file():
                content = written_file.read_text(encoding="utf-8", errors="replace")
                assert "feature_tier" not in content, (
                    f"'feature_tier' found in {written_file.relative_to(project_dir)}"
                )


# ---------------------------------------------------------------------------
# Tests: dry_run mode
# ---------------------------------------------------------------------------

class TestScaffoldDryRun:
    """dry_run=True computes result without writing any files."""

    def test_dry_run_writes_no_files(self, tmp_path: Path) -> None:
        """dry_run=True → .claude/ directory is NOT created."""
        source_dir = _make_source_dir(tmp_path)
        project_dir = tmp_path / "project"
        project_dir.mkdir()
        # Act
        result = scaffold_claude_dir(
            project_dir=project_dir,
            source_dir=source_dir,
            profile="full",
            dry_run=True,
        )
        # Assert: nothing written
        assert not (project_dir / ".claude").exists()

    def test_dry_run_result_populated(self, tmp_path: Path) -> None:
        """dry_run=True → result.files_written lists what WOULD be written."""
        source_dir = _make_source_dir(tmp_path)
        project_dir = tmp_path / "project"
        project_dir.mkdir()
        result = scaffold_claude_dir(
            project_dir=project_dir,
            source_dir=source_dir,
            profile="full",
            dry_run=True,
        )
        # files_written should be non-empty even though nothing was written to disk
        assert len(result.files_written) > 0


# ---------------------------------------------------------------------------
# Tests: AC-14 — .gitignore scaffolding
# ---------------------------------------------------------------------------

class TestScaffoldGitignore:
    """scaffold_gitignore manages required ShipTeam entries in .gitignore."""

    def test_ac14_no_gitignore_creates_file_with_entries(self, tmp_path: Path) -> None:
        """AC-14: no .gitignore → new file created containing all required entries."""
        # Act
        modified = scaffold_gitignore(tmp_path)
        # Assert
        assert modified is True
        gitignore = tmp_path / ".gitignore"
        assert gitignore.exists()
        content = gitignore.read_text()
        for entry in REQUIRED_GITIGNORE_ENTRIES:
            assert entry in content, f"Missing required entry: {entry!r}"

    def test_ac14_existing_gitignore_missing_entries_appended(self, tmp_path: Path) -> None:
        """AC-14: existing .gitignore without entries → entries appended, original preserved."""
        # Arrange
        gitignore = tmp_path / ".gitignore"
        gitignore.write_text("node_modules/\n*.pyc\n")
        # Act
        modified = scaffold_gitignore(tmp_path)
        # Assert
        assert modified is True
        content = gitignore.read_text()
        # Original content preserved
        assert "node_modules/" in content
        assert "*.pyc" in content
        # Required entries added
        for entry in REQUIRED_GITIGNORE_ENTRIES:
            assert entry in content, f"Missing required entry: {entry!r}"

    def test_ac14_already_complete_gitignore_is_noop(self, tmp_path: Path) -> None:
        """AC-14: .gitignore already contains all required entries → no-op, returns False."""
        # Arrange: create gitignore with all required entries already present
        gitignore = tmp_path / ".gitignore"
        entries_block = "\n".join(REQUIRED_GITIGNORE_ENTRIES)
        gitignore.write_text(f"node_modules/\n{entries_block}\n")
        # Act
        modified = scaffold_gitignore(tmp_path)
        # Assert
        assert modified is False

    def test_ac14_complete_gitignore_not_duplicated(self, tmp_path: Path) -> None:
        """AC-14: idempotent — running twice doesn't duplicate entries."""
        gitignore = tmp_path / ".gitignore"
        gitignore.write_text("node_modules/\n")
        # First run adds entries
        scaffold_gitignore(tmp_path)
        content_after_first = gitignore.read_text()
        # Second run is a no-op
        scaffold_gitignore(tmp_path)
        content_after_second = gitignore.read_text()
        # Content unchanged after second run
        assert content_after_first == content_after_second

    def test_ac14_partial_entries_only_missing_appended(self, tmp_path: Path) -> None:
        """AC-14: .gitignore with some entries → only missing ones appended."""
        # Arrange: include 2 of the required entries; the rest must be appended
        gitignore = tmp_path / ".gitignore"
        gitignore.write_text(".claude/state/\n.context/\n")
        # Act
        modified = scaffold_gitignore(tmp_path)
        # Assert: modified because some entries were missing
        assert modified is True
        content = gitignore.read_text()
        # All required entries now present
        for entry in REQUIRED_GITIGNORE_ENTRIES:
            assert entry in content, f"Entry still missing: {entry!r}"
        # Original 2 entries not duplicated
        assert content.count(".claude/state/") == 1
        assert content.count(".context/") == 1

    def test_ac14_created_gitignore_returns_true(self, tmp_path: Path) -> None:
        """AC-14: returns True when file is newly created."""
        result = scaffold_gitignore(tmp_path)
        assert result is True


# ---------------------------------------------------------------------------
# Skill directory-level profile filtering
# ---------------------------------------------------------------------------

def _make_dir_skills_source(tmp_path: Path) -> Path:
    """Build a synthetic source dir using REAL skill layout (skills/<name>/SKILL.md)."""
    source_dir = tmp_path / "source-dir-skills"
    source_dir.mkdir()
    meta = textwrap.dedent("""\
        min_cli_version: "0.13.0"
        schema_version: 1
        profile_filters:
          rules:
            minimal: [anti-patterns.md]
            standard: ["*"]
            full: ["*"]
          skills:
            minimal: []
            standard: [deploy, health]
            full: ["*"]
    """)
    (source_dir / "framework-meta.yaml").write_text(meta)
    (source_dir / "agents").mkdir()
    (source_dir / "agents" / "fw-x.md").write_text("agent")
    (source_dir / "rules").mkdir()
    (source_dir / "rules" / "anti-patterns.md").write_text("rule")
    (source_dir / "hooks").mkdir()
    (source_dir / "hooks" / "h.py").write_text("hook")
    (source_dir / "templates").mkdir()
    (source_dir / "templates" / "CLAUDE.md.jinja").write_text("# {{ project_name }}")
    # Real skill layout: each skill is a directory containing SKILL.md
    skills_dir = source_dir / "skills"
    skills_dir.mkdir()
    for name in ("deploy", "health", "browse"):
        d = skills_dir / name
        d.mkdir()
        (d / "SKILL.md").write_text(f"# {name} skill")
    return source_dir


class TestSkillDirectoryFiltering:
    def test_standard_profile_includes_only_listed_skill_directories(self, tmp_path: Path) -> None:
        source = _make_dir_skills_source(tmp_path)
        project = tmp_path / "project"
        project.mkdir()
        scaffold_claude_dir(project_dir=project, source_dir=source, profile="standard")
        skills = project / ".claude" / "skills"
        assert (skills / "deploy" / "SKILL.md").exists()
        assert (skills / "health" / "SKILL.md").exists()
        # browse not in the standard list — must be excluded
        assert not (skills / "browse").exists()

    def test_minimal_profile_excludes_all_skill_directories(self, tmp_path: Path) -> None:
        source = _make_dir_skills_source(tmp_path)
        project = tmp_path / "project"
        project.mkdir()
        scaffold_claude_dir(project_dir=project, source_dir=source, profile="minimal")
        skills = project / ".claude" / "skills"
        # Empty list — no skill directories created
        for name in ("deploy", "health", "browse"):
            assert not (skills / name).exists(), f"{name} should not be installed at minimal"

    def test_full_profile_wildcard_includes_all_skill_directories(self, tmp_path: Path) -> None:
        source = _make_dir_skills_source(tmp_path)
        project = tmp_path / "project"
        project.mkdir()
        scaffold_claude_dir(project_dir=project, source_dir=source, profile="full")
        skills = project / ".claude" / "skills"
        for name in ("deploy", "health", "browse"):
            assert (skills / name / "SKILL.md").exists(), f"{name} missing at full"

    def test_skill_directory_with_multiple_files_all_included(self, tmp_path: Path) -> None:
        """A skill listed in the profile must include ALL files inside its dir, not just SKILL.md."""
        source = _make_dir_skills_source(tmp_path)
        # Add an auxiliary file inside the deploy skill
        (source / "skills" / "deploy" / "checklist.txt").write_text("step 1")
        project = tmp_path / "project"
        project.mkdir()
        scaffold_claude_dir(project_dir=project, source_dir=source, profile="standard")
        deploy = project / ".claude" / "skills" / "deploy"
        assert (deploy / "SKILL.md").exists()
        assert (deploy / "checklist.txt").exists()

    def test_skill_directory_deeply_nested_file_included(self, tmp_path: Path) -> None:
        """Files nested beyond one level inside an allowed skill dir are all copied."""
        source = _make_dir_skills_source(tmp_path)
        nested = source / "skills" / "deploy" / "templates"
        nested.mkdir()
        (nested / "foo.md").write_text("nested template")
        project = tmp_path / "project"
        project.mkdir()
        scaffold_claude_dir(project_dir=project, source_dir=source, profile="standard")
        assert (project / ".claude" / "skills" / "deploy" / "templates" / "foo.md").exists()

    def test_unknown_skill_in_profile_filter_raises(self, tmp_path: Path) -> None:
        """A typo in framework-meta.yaml (skill listed but absent from source) must raise loudly."""
        source = _make_dir_skills_source(tmp_path)
        bad_meta = textwrap.dedent("""\
            min_cli_version: "0.13.0"
            schema_version: 1
            profile_filters:
              rules:
                minimal: ["*"]
                standard: ["*"]
                full: ["*"]
              skills:
                minimal: []
                standard: [deploi]
                full: ["*"]
        """)
        (source / "framework-meta.yaml").write_text(bad_meta)
        project = tmp_path / "project"
        project.mkdir()
        with pytest.raises(ValueError, match="deploi"):
            scaffold_claude_dir(project_dir=project, source_dir=source, profile="standard")
