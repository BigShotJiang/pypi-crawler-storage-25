"""AC-4: Three target agents each contain a Math Verification section.

RED phase for Phase 2. These tests fail until the section is appended to each
of fw-review-security, fw-advisor-architecture, and fw-review-performance.
"""

from pathlib import Path

import pytest

_AGENTS = (
    Path(__file__).parent.parent
    / ".claude"
    / "agents"
)

_TARGETS = (
    "fw-review-security.md",
    "fw-advisor-architecture.md",
    "fw-review-performance.md",
)


@pytest.mark.parametrize("agent_file", _TARGETS)
class TestMathVerificationSection:
    """T-9, T-10, T-11: AC-4 — each target agent has a Math Verification section."""

    def _read(self, agent_file: str) -> str:
        return (_AGENTS / agent_file).read_text()

    def test_t9_section_appears_exactly_once(self, agent_file: str):
        """T-9 (P0): `## Math Verification` appears exactly once."""
        body = self._read(agent_file)
        count = body.count("## Math Verification")
        assert count == 1, (
            f"{agent_file}: expected exactly 1 '## Math Verification' header, "
            f"found {count}"
        )

    def test_t10_references_verify_math_skill(self, agent_file: str):
        """T-10 (P0): section references `/verify-math` skill name."""
        body = self._read(agent_file)
        assert "/verify-math" in body, (
            f"{agent_file}: Math Verification section must reference the "
            f"`/verify-math` skill"
        )

    def test_t11_instructs_math_verify_flag_emission(self, agent_file: str):
        """T-11 (P1): section instructs agent to emit `MATH-VERIFY-FLAG`."""
        body = self._read(agent_file)
        assert "MATH-VERIFY-FLAG" in body, (
            f"{agent_file}: Math Verification section must instruct agent to "
            f"emit `MATH-VERIFY-FLAG` on unchecked arithmetic"
        )
