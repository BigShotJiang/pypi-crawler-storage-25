"""
Tests for shipteam.state — InitState persistence (load/save .shipteam-init.yaml).
"""
import textwrap
from pathlib import Path

import pytest
import yaml

from shipteam.state import InitState, STATE_FILENAME, load_state, save_state


class TestLoadState:
    """load_state(project_dir) — deserialize .shipteam-init.yaml into InitState."""

    def test_load_state_roundtrip(self, initialized_project_dir: Path) -> None:
        # Arrange: initialized_project_dir already contains a valid .shipteam-init.yaml
        # Act
        state = load_state(initialized_project_dir)
        # Assert
        assert state is not None
        assert isinstance(state, InitState)
        assert state.cli_version == "0.1.0"
        assert state.framework_version == "0.13.2"
        assert state.template_hash == "a1b2c3d4e5f6789012345678901234567890abcdef0123456789abcdef012345"
        assert state.region_checksums == {
            "session_start": "1111111111111111111111111111111111111111111111111111111111111111",
            "deployment": "2222222222222222222222222222222222222222222222222222222222222222",
        }

    def test_load_state_missing(self, empty_dir: Path) -> None:
        """Returns None when .shipteam-init.yaml does not exist — must not raise."""
        # Act
        result = load_state(empty_dir)
        # Assert
        assert result is None

    def test_load_state_corrupt_missing_required(self, tmp_path: Path) -> None:
        """A state file present but missing required fields raises ValueError with context."""
        import pytest
        (tmp_path / STATE_FILENAME).write_text("cli_version: '0.1.0'\n")
        with pytest.raises(ValueError, match="missing required fields"):
            load_state(tmp_path)

    def test_load_state_empty_file(self, tmp_path: Path) -> None:
        """An empty state file raises ValueError (not KeyError/AttributeError)."""
        import pytest
        (tmp_path / STATE_FILENAME).write_text("")
        with pytest.raises(ValueError):
            load_state(tmp_path)

    def test_load_state_forward_compat(self, tmp_path: Path) -> None:
        """Unknown fields in the YAML are silently ignored; known fields still load."""
        # Arrange: add extra fields not in the InitState dataclass
        state_yaml = textwrap.dedent("""\
            cli_version: "0.2.0"
            framework_version: "0.14.0"
            schema_version: 1
            rendered_at: "2026-05-01T00:00:00Z"
            template_hash: "deadbeefdeadbeefdeadbeefdeadbeefdeadbeefdeadbeefdeadbeefdeadbeef"
            region_checksums: {}
            profile: "full"
            future_field_unknown: "some-value"
            another_future_key:
              nested: true
        """)
        (tmp_path / STATE_FILENAME).write_text(state_yaml)
        # Act
        state = load_state(tmp_path)
        # Assert: known fields present, no exception raised
        assert state is not None
        assert state.cli_version == "0.2.0"
        assert state.framework_version == "0.14.0"
        assert state.template_hash == "deadbeefdeadbeefdeadbeefdeadbeefdeadbeefdeadbeefdeadbeefdeadbeef"
        assert state.profile == "full"


class TestSaveState:
    """save_state(state, project_dir) — serialize InitState to .shipteam-init.yaml."""

    def test_save_state_creates_file(self, tmp_path: Path) -> None:
        """save_state creates the .shipteam-init.yaml file with valid YAML content."""
        # Arrange
        state = InitState(
            cli_version="0.1.0",
            framework_version="0.10.0",
            schema_version=1,
            rendered_at="2026-04-10T09:00:00Z",
            template_hash="cafebabecafebabecafebabecafebabecafebabecafebabecafebabecafebabe",
            region_checksums={
                "session_start": "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",
                "deployment": "bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb",
            },
            profile="standard",
        )
        # Act
        save_state(state, tmp_path)
        # Assert: file exists
        state_file = tmp_path / STATE_FILENAME
        assert state_file.exists(), f"{STATE_FILENAME} was not created by save_state"
        # Assert: content is valid YAML (parses without error)
        parsed = yaml.safe_load(state_file.read_text())
        assert isinstance(parsed, dict)
        # Key fields must appear in the serialized output
        assert parsed.get("cli_version") == "0.1.0"
        assert parsed.get("template_hash") == "cafebabecafebabecafebabecafebabecafebabecafebabecafebabecafebabe"
