"""
Tests for shipteam.detect — stack detection and git introspection.

AC-3: detect_stack() correctly identifies backend/frontend stacks from project files.
AC-6: detect_git() correctly classifies normal repos, worktrees, and non-git dirs.
"""
import json
import textwrap
from pathlib import Path

import pytest

from shipteam.detect import detect_stack, detect_git, DetectedStack


class TestDetectStack:
    """detect_stack(target_dir) — auto-detection from lockfiles and project files."""

    def test_ac3_detect_stack_python_only(self, python_project_dir: Path) -> None:
        # Arrange: python_project_dir has pyproject.toml + .git, no frontend files
        # Act
        stack: DetectedStack = detect_stack(python_project_dir)
        # Assert
        assert stack.backend is not None
        assert stack.backend.language == "python"
        assert stack.backend.root == "."
        assert stack.frontend is None

    def test_ac3_detect_stack_react_only(self, react_project_dir: Path) -> None:
        # Arrange: react_project_dir has package.json with react dep + .git
        # Act
        stack: DetectedStack = detect_stack(react_project_dir)
        # Assert
        assert stack.frontend is not None
        assert stack.frontend.language.lower() in ("react", "javascript", "typescript")
        assert stack.backend is None

    def test_ac3_detect_stack_monorepo(self, monorepo_project_dir: Path) -> None:
        # Arrange: monorepo has backend/ (python) and frontend/ (react)
        # Act
        stack: DetectedStack = detect_stack(monorepo_project_dir)
        # Assert: both stacks detected in their respective subdirs
        assert stack.backend is not None
        assert stack.backend.root == "backend"
        assert stack.frontend is not None
        assert stack.frontend.root == "frontend"

    def test_ac3_detect_stack_empty(self, empty_dir: Path) -> None:
        # Arrange: empty_dir has no project files at all
        # Act
        stack: DetectedStack = detect_stack(empty_dir)
        # Assert: neither stack detected
        assert stack.backend is None
        assert stack.frontend is None

    def test_ac3_detect_stack_root_polyglot(self, tmp_path: Path) -> None:
        """Both pyproject.toml AND package.json at root — both stacks detected with root='.'."""
        # Arrange
        (tmp_path / "pyproject.toml").write_text(
            textwrap.dedent("""\
                [project]
                name = "polyapp"
            """)
        )
        (tmp_path / "package.json").write_text(
            json.dumps({"name": "polyapp", "dependencies": {"react": "^18"}})
        )
        (tmp_path / ".git").mkdir()
        # Act
        stack: DetectedStack = detect_stack(tmp_path)
        # Assert
        assert stack.backend is not None
        assert stack.backend.root == "."
        assert stack.frontend is not None
        assert stack.frontend.root == "."


class TestDetectGit:
    """detect_git(target_dir) — git repository type classification."""

    def test_ac6_detect_git_normal_repo(self, python_project_dir: Path) -> None:
        # Arrange: python_project_dir has a .git directory (not a file)
        # Act
        is_git_repo, git_type, git_dir, git_work_tree = detect_git(python_project_dir)
        # Assert
        assert is_git_repo is True
        assert git_type == "directory"
        assert git_dir is not None
        assert git_dir.endswith(".git")
        assert git_work_tree == str(python_project_dir)

    def test_ac6_detect_git_worktree_file(self, worktree_project_dir: Path) -> None:
        # Arrange: worktree_project_dir has a .git FILE with a gitdir: pointer
        # Act
        is_git_repo, git_type, git_dir, git_work_tree = detect_git(worktree_project_dir)
        # Assert
        assert is_git_repo is True
        assert git_type == "worktree_file"
        assert git_dir is not None
        # git_dir must be an absolute path matching what was written in the .git file
        assert Path(git_dir).is_absolute()
        # The gitdir line written in conftest points to the worktree entry in main_repo
        git_file_content = (worktree_project_dir / ".git").read_text()
        expected_path = git_file_content.strip().removeprefix("gitdir:").strip()
        assert git_dir == expected_path

    def test_ac6_detect_git_missing(self, non_git_dir: Path) -> None:
        # Arrange: non_git_dir has pyproject.toml but no .git at all
        # Act
        is_git_repo, git_type, git_dir, git_work_tree = detect_git(non_git_dir)
        # Assert
        assert is_git_repo is False
        assert git_type == "none"
        assert git_dir is None
        assert git_work_tree is None

    def test_ac6_detect_git_symlink(self, tmp_path: Path) -> None:
        # Arrange: create a real .git directory elsewhere, then symlink to it
        real_git = tmp_path / "real_repo" / ".git"
        real_git.mkdir(parents=True)
        project = tmp_path / "project"
        project.mkdir()
        (project / ".git").symlink_to(real_git)
        # Act
        is_git_repo, git_type, git_dir, git_work_tree = detect_git(project)
        # Assert: symlink to .git dir resolves to directory type
        assert is_git_repo is True
        assert git_type == "directory"
        assert git_dir is not None and Path(git_dir).is_absolute()

    def test_ac6_detect_git_malformed_missing_prefix(self, tmp_path: Path) -> None:
        # Arrange: .git file without 'gitdir:' prefix (malformed / possibly adversarial)
        (tmp_path / ".git").write_text("/some/random/path\n")
        # Act
        is_git_repo, git_type, git_dir, git_work_tree = detect_git(tmp_path)
        # Assert: fail closed on malformed .git file
        assert is_git_repo is False
        assert git_type == "none"
        assert git_dir is None

    def test_ac6_detect_git_multiline_takes_first(self, tmp_path: Path) -> None:
        # Arrange: .git file with 'gitdir:' plus extra lines that should NOT leak into git_dir
        (tmp_path / ".git").write_text("gitdir: /valid/absolute/path\nextra\nlines\n")
        # Act
        is_git_repo, git_type, git_dir, git_work_tree = detect_git(tmp_path)
        # Assert: only first-line gitdir is used; no multi-line injection
        assert is_git_repo is True
        assert git_type == "worktree_file"
        assert git_dir == "/valid/absolute/path"
        assert "\n" not in git_dir and "extra" not in git_dir
