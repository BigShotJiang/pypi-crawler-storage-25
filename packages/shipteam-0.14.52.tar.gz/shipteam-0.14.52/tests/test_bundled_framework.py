"""
Tests for bundled framework source — Phase 5 package_data / AC-13 (bundled source).

Covers:
  - The framework-meta.yaml file exists at src/shipteam/framework/framework-meta.yaml
    (the file that will be bundled in the wheel via package_data).
  - get_bundled_source() returns a valid Path when bundled files are present.
  - get_bundled_source() raises FileNotFoundError when the framework package is absent
    (simulated via monkeypatching importlib.resources.files).
"""
from __future__ import annotations

from pathlib import Path
from unittest.mock import patch

import pytest

from shipteam.source import get_bundled_source

# ---------------------------------------------------------------------------
# Repo-relative path to the file that must exist before packaging.
# The test suite runs from the repo root — this path is deterministic.
# ---------------------------------------------------------------------------

_REPO_ROOT = Path(__file__).parent.parent
_BUNDLED_META = _REPO_ROOT / "src" / "shipteam" / "framework" / "framework-meta.yaml"


# ---------------------------------------------------------------------------
# Tests: bundled framework-meta.yaml exists in the source tree
# ---------------------------------------------------------------------------

class TestBundledFrameworkMetaExists:
    """The framework-meta.yaml must exist at the expected package_data path before the wheel is built."""

    def test_ac13_framework_meta_yaml_exists_in_source_tree(self) -> None:
        """AC-13: src/shipteam/framework/framework-meta.yaml must exist (package_data source)."""
        assert _BUNDLED_META.exists(), (
            f"framework-meta.yaml not found at {_BUNDLED_META}. "
            "This file must be created as part of Phase 5 (package_data bundling) "
            "before the wheel can ship the framework source."
        )

    def test_ac13_framework_meta_yaml_is_a_file_not_a_directory(self) -> None:
        """AC-13: the path must be a regular file, not a directory."""
        assert _BUNDLED_META.is_file(), (
            f"Expected a file at {_BUNDLED_META}, found a directory or symlink."
        )


# ---------------------------------------------------------------------------
# Tests: get_bundled_source() returns Path when framework package is importable
# ---------------------------------------------------------------------------

class TestGetBundledSourceHappyPath:
    """get_bundled_source() returns a Path when shipteam.framework is importable."""

    def test_ac13_get_bundled_source_returns_path_when_framework_present(self, tmp_path: Path) -> None:
        """AC-13: get_bundled_source() returns a Path object when the bundled dir exists."""
        # Arrange: fake a framework directory that importlib.resources would resolve
        fake_framework_dir = tmp_path / "framework"
        fake_framework_dir.mkdir()
        (fake_framework_dir / "framework-meta.yaml").write_text(
            'min_cli_version: "0.1.0"\nschema_version: 1\n'
        )

        # Patch importlib.resources.files to return a fake traversable backed by tmp_path
        with patch("shipteam.source.files") as mock_files:
            mock_files.return_value = fake_framework_dir
            # Act
            result = get_bundled_source()
        # Assert
        assert isinstance(result, Path)
        assert result.exists()


# ---------------------------------------------------------------------------
# Tests: get_bundled_source() raises FileNotFoundError when package absent
# ---------------------------------------------------------------------------

class TestGetBundledSourceMissingFramework:
    """get_bundled_source() must raise FileNotFoundError when the framework package is absent."""

    def test_ac13_get_bundled_source_raises_file_not_found_when_framework_missing(self) -> None:
        """AC-13: get_bundled_source() raises FileNotFoundError when shipteam.framework not importable."""
        # Arrange: simulate ModuleNotFoundError from importlib.resources.files
        with patch("shipteam.source.files", side_effect=ModuleNotFoundError("shipteam.framework")):
            # Act / Assert
            with pytest.raises(FileNotFoundError):
                get_bundled_source()

    def test_ac13_get_bundled_source_raises_when_resolved_path_does_not_exist(self, tmp_path: Path) -> None:
        """AC-13: get_bundled_source() raises FileNotFoundError when resolved path is absent."""
        # Arrange: return a path that points to a non-existent directory
        nonexistent = tmp_path / "does_not_exist"

        with patch("shipteam.source.files") as mock_files:
            mock_files.return_value = nonexistent
            # Act / Assert
            with pytest.raises(FileNotFoundError):
                get_bundled_source()

    def test_ac13_file_not_found_error_message_is_actionable(self) -> None:
        """AC-13: FileNotFoundError message helps the developer understand the issue."""
        with patch("shipteam.source.files", side_effect=ModuleNotFoundError("shipteam.framework")):
            with pytest.raises(FileNotFoundError, match="[Bb]undled"):
                get_bundled_source()
