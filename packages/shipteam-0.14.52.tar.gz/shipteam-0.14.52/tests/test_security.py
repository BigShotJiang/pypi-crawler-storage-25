"""
Tests for shipteam.security — path safety validation and safe YAML loading.
"""
from pathlib import Path

import pytest

from shipteam.security import validate_path_safety, safe_load_yaml


class TestValidatePathSafety:
    """validate_path_safety(path, project_root) — True if path stays within root."""

    def test_path_safety_relative_safe(self, tmp_path: Path) -> None:
        # Arrange: a simple relative path inside the project tree
        # Act
        result = validate_path_safety("backend/src", tmp_path)
        # Assert
        assert result is True

    def test_path_safety_traversal(self, tmp_path: Path) -> None:
        # Arrange: classic directory traversal attack string
        # Act
        result = validate_path_safety("../../etc/passwd", tmp_path)
        # Assert
        assert result is False

    def test_path_safety_absolute_inside(self, tmp_path: Path) -> None:
        # Arrange: absolute path that resolves inside project_root
        inside = str(tmp_path / "sub" / "file.txt")
        # Act
        result = validate_path_safety(inside, tmp_path)
        # Assert
        assert result is True

    def test_path_safety_absolute_outside(self, tmp_path: Path) -> None:
        # Arrange: absolute path that escapes project_root entirely
        # Act
        result = validate_path_safety("/etc/passwd", tmp_path)
        # Assert
        assert result is False

    def test_path_safety_dot_relative_safe(self, tmp_path: Path) -> None:
        # Arrange: "." refers to the root itself — must be considered safe
        # Act
        result = validate_path_safety(".", tmp_path)
        # Assert
        assert result is True

    def test_path_safety_sibling_traversal(self, tmp_path: Path) -> None:
        """backend/../../../etc style — resolves outside root."""
        # Act
        result = validate_path_safety("backend/../../../etc", tmp_path)
        # Assert
        assert result is False


class TestSafeLoadYaml:
    """safe_load_yaml(path) — YAML loader that never executes arbitrary Python."""

    def test_safe_load_yaml_valid(self, valid_framework_yaml: Path) -> None:
        # Arrange: valid_framework_yaml is a well-formed YAML file
        # Act
        result = safe_load_yaml(valid_framework_yaml)
        # Assert
        assert isinstance(result, dict)
        assert "project" in result

    def test_safe_load_yaml_rejects_unsafe(self, malicious_yaml: Path) -> None:
        """
        safe_load_yaml must never deserialize !!python/object/apply: payloads.

        Acceptable outcomes:
          1. Raises yaml.YAMLError / yaml.constructor.ConstructorError
          2. Returns a plain Python type (str, dict, list) with no callable content

        Unacceptable outcome:
          - Returns a non-plain type (callable, module, subprocess result)
          - Executes os.system or any OS command as a side effect
        """
        import yaml

        sentinel = malicious_yaml.parent / "pwned"
        try:
            result = safe_load_yaml(malicious_yaml)
        except (yaml.YAMLError, ValueError):
            # acceptable: safe_load rejected the unsafe tag (possibly wrapped in ValueError)
            # sentinel must NOT exist — proves os.system was never invoked
            assert not sentinel.exists(), "safe_load executed the unsafe payload"
            return
        # If returned without raising, sentinel must NOT exist AND result must be plain type
        assert not sentinel.exists(), "safe_load executed the unsafe payload"
        assert not callable(result), (
            "safe_load_yaml returned a callable — unsafe deserialization occurred"
        )
        assert isinstance(result, (dict, list, str, int, float, bool, type(None))), (
            f"safe_load_yaml returned an unexpected type: {type(result)}"
        )
