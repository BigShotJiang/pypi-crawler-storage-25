"""AC-6: SKILL.md frontmatter guard — regression for Claude Code issue #9817.

When SKILL.md's `description:` field gets line-wrapped (by a commit hook,
editor auto-format, or accidental newline), Claude Code silently fails to
discover the skill. This test guards against that.
"""

from pathlib import Path

import pytest
import yaml

_SKILL_MD = (
    Path(__file__).parent.parent
    / ".claude"
    / "skills"
    / "verify-math"
    / "SKILL.md"
)


def _parse_frontmatter(text: str) -> dict:
    """Extract YAML frontmatter between leading `---` fences."""
    lines = text.splitlines()
    assert lines[0] == "---", "SKILL.md must start with '---' frontmatter fence"
    end = None
    for i, line in enumerate(lines[1:], start=1):
        if line == "---":
            end = i
            break
    assert end is not None, "SKILL.md must close frontmatter with '---'"
    return yaml.safe_load("\n".join(lines[1:end]))


class TestSkillFrontmatter:
    """AC-6: description field is single-line."""

    def test_t15_description_is_single_line(self):
        """T-15 (P0): description contains no literal newline and len >= 30."""
        body = _SKILL_MD.read_text()
        fm = _parse_frontmatter(body)
        description = fm.get("description", "")

        assert isinstance(description, str), (
            f"description must be a string, got {type(description).__name__}"
        )
        assert "\n" not in description, (
            f"description must be single-line (Claude Code #9817 footgun). "
            f"Got: {description!r}"
        )
        assert len(description) >= 30, (
            f"description is too short ({len(description)} chars, need >=30)"
        )

    def test_t16_frontmatter_valid_yaml(self):
        """T-16 (P1): frontmatter is valid YAML and contains `description` key."""
        body = _SKILL_MD.read_text()
        fm = _parse_frontmatter(body)
        assert "description" in fm, "frontmatter must contain `description` key"
        assert "name" in fm, "frontmatter must contain `name` key"
