"""
Tests for shipteam.regions — ManagedRegion extraction and replacement.
"""
import hashlib
import textwrap

import pytest

from shipteam.regions import (
    MARKER_BEGIN,
    MARKER_END,
    ManagedRegion,
    extract_regions,
    replace_region,
)


def _begin(name: str) -> str:
    return MARKER_BEGIN.format(name=name)


def _end(name: str) -> str:
    return MARKER_END.format(name=name)


class TestExtractRegions:
    """extract_regions(content) — parse managed regions from a string."""

    def test_extracts_single_region(self) -> None:
        # Arrange
        content = textwrap.dedent(f"""\
            preamble
            {_begin("intro")}
            hello world
            {_end("intro")}
            postamble
        """)
        # Act
        regions = extract_regions(content)
        # Assert
        assert len(regions) == 1
        assert regions[0].name == "intro"
        assert regions[0].content.strip() == "hello world"

    def test_extracts_multiple_regions_in_order(self) -> None:
        # Arrange
        content = "\n".join([
            "top",
            _begin("alpha"),
            "content alpha",
            _end("alpha"),
            "middle",
            _begin("beta"),
            "content beta",
            _end("beta"),
            "bottom",
        ])
        # Act
        regions = extract_regions(content)
        # Assert
        assert len(regions) == 2
        assert regions[0].name == "alpha"
        assert "content alpha" in regions[0].content
        assert regions[1].name == "beta"
        assert "content beta" in regions[1].content

    def test_preserves_content_between_regions(self) -> None:
        """Text between managed regions is not captured in any region."""
        content = "\n".join([
            _begin("x"),
            "in x",
            _end("x"),
            "standalone line",
            _begin("y"),
            "in y",
            _end("y"),
        ])
        regions = extract_regions(content)
        names = {r.name for r in regions}
        assert "x" in names
        assert "y" in names
        # The standalone line must NOT appear in any region's content
        for r in regions:
            assert "standalone line" not in r.content

    def test_empty_region_body(self) -> None:
        """A region with BEGIN immediately followed by END has empty content."""
        content = "\n".join([
            _begin("empty"),
            _end("empty"),
        ])
        regions = extract_regions(content)
        assert len(regions) == 1
        assert regions[0].name == "empty"
        assert regions[0].content.strip() == ""

    def test_start_and_end_line_numbers_are_zero_indexed(self) -> None:
        # Arrange: BEGIN marker is on line 2 (0-indexed), END on line 4
        lines = [
            "line0",
            "line1",
            _begin("target"),
            "body",
            _end("target"),
            "line5",
        ]
        content = "\n".join(lines)
        # Act
        regions = extract_regions(content)
        # Assert
        r = regions[0]
        assert r.start_line == 2
        assert r.end_line == 4

    def test_duplicate_region_name_raises_value_error(self) -> None:
        """Two regions with the same name → ValueError."""
        content = "\n".join([
            _begin("dup"),
            "first",
            _end("dup"),
            _begin("dup"),
            "second",
            _end("dup"),
        ])
        with pytest.raises(ValueError, match="dup"):
            extract_regions(content)

    def test_unbalanced_begin_without_end_raises_value_error(self) -> None:
        """A BEGIN with no matching END is an extraction error."""
        content = "\n".join([
            _begin("orphan"),
            "some content",
        ])
        with pytest.raises(ValueError):
            extract_regions(content)

    def test_returns_empty_list_when_no_regions(self) -> None:
        content = "just plain text\nno markers here\n"
        assert extract_regions(content) == []

    def test_region_content_excludes_marker_lines(self) -> None:
        """Marker lines themselves are NOT part of the returned content."""
        content = "\n".join([
            _begin("sec"),
            "inner",
            _end("sec"),
        ])
        regions = extract_regions(content)
        assert _begin("sec") not in regions[0].content
        assert _end("sec") not in regions[0].content


class TestReplaceRegion:
    """replace_region(content, name, new_content) — update a region's body in place."""

    def test_replace_region_updates_body(self) -> None:
        # Arrange
        content = "\n".join([
            _begin("zone"),
            "old body",
            _end("zone"),
        ])
        # Act
        result = replace_region(content, "zone", "new body")
        # Assert
        assert "new body" in result
        assert "old body" not in result

    def test_replace_region_preserves_surrounding_content(self) -> None:
        # Arrange
        content = "\n".join([
            "header",
            _begin("zone"),
            "old",
            _end("zone"),
            "footer",
        ])
        # Act
        result = replace_region(content, "zone", "fresh")
        # Assert
        assert result.startswith("header")
        assert "footer" in result
        assert _begin("zone") in result
        assert _end("zone") in result

    def test_replace_region_preserves_markers_verbatim(self) -> None:
        """The BEGIN/END markers are kept in the output unchanged."""
        content = "\n".join([
            _begin("sec"),
            "body",
            _end("sec"),
        ])
        result = replace_region(content, "sec", "updated")
        assert _begin("sec") in result
        assert _end("sec") in result

    def test_replace_region_preserves_trailing_newline(self) -> None:
        content = "\n".join([
            _begin("sec"),
            "body",
            _end("sec"),
        ]) + "\n"
        result = replace_region(content, "sec", "new")
        assert result.endswith("\n")

    def test_replace_region_unknown_name_raises_key_error(self) -> None:
        content = "\n".join([
            _begin("known"),
            "body",
            _end("known"),
        ])
        with pytest.raises(KeyError):
            replace_region(content, "unknown", "value")

    def test_replace_region_unbalanced_marker_raises_key_error(self) -> None:
        """BEGIN present but END missing → unbalanced, treated as not found."""
        content = "\n".join([
            _begin("broken"),
            "body",
        ])
        with pytest.raises((KeyError, ValueError)):
            replace_region(content, "broken", "new body")

    def test_replace_region_does_not_modify_other_regions(self) -> None:
        content = "\n".join([
            _begin("a"),
            "body a",
            _end("a"),
            _begin("b"),
            "body b",
            _end("b"),
        ])
        result = replace_region(content, "a", "replaced a")
        # region b is untouched
        after_b_begin = result.split(_begin("b"))[1].split(_end("b"))[0]
        assert "body b" in after_b_begin


# ---------------------------------------------------------------------------
# AC-5: Region-name allowlist regex
# ---------------------------------------------------------------------------

class TestRegionNameAllowlist:
    def test_marker_with_path_traversal_name_is_not_recognized(self) -> None:
        """A marker like BEGIN:foo/../etc must NOT be parsed as a valid region."""
        content = "\n".join([
            "<!-- SHIPTEAM:BEGIN:foo/../etc -->",
            "body",
            "<!-- SHIPTEAM:END:foo/../etc -->",
        ])
        # Unsafe name rejected → parser returns an empty list (no regions found)
        assert extract_regions(content) == []

    def test_marker_with_null_byte_name_is_not_recognized(self) -> None:
        content = "\n".join([
            "<!-- SHIPTEAM:BEGIN:foo\x00bar -->",
            "body",
            "<!-- SHIPTEAM:END:foo\x00bar -->",
        ])
        assert extract_regions(content) == []

    def test_marker_with_whitespace_name_is_not_recognized(self) -> None:
        content = "\n".join([
            "<!-- SHIPTEAM:BEGIN:foo bar -->",
            "body",
            "<!-- SHIPTEAM:END:foo bar -->",
        ])
        assert extract_regions(content) == []

    def test_marker_with_safe_name_is_recognized(self) -> None:
        """Baseline: names matching the allowlist continue to work."""
        content = "\n".join([
            "<!-- SHIPTEAM:BEGIN:header_v2 -->",
            "body",
            "<!-- SHIPTEAM:END:header_v2 -->",
        ])
        regions = extract_regions(content)
        assert len(regions) == 1
        assert regions[0].name == "header_v2"
