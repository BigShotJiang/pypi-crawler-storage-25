"""
Tests for shipteam.render — render_claude_md and refresh_managed_regions.
"""
import hashlib
import textwrap

import pytest

from shipteam.detect import BackendStack, DetectedStack, FrontendStack
from shipteam.render import RenderContext, render_claude_md, refresh_managed_regions
from shipteam.regions import MARKER_BEGIN, MARKER_END
from shipteam.state import InitState


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _begin(name: str) -> str:
    return MARKER_BEGIN.format(name=name)


def _end(name: str) -> str:
    return MARKER_END.format(name=name)


def _sha(text: str) -> str:
    """Return SHA-256 hex digest of text encoded as UTF-8."""
    return hashlib.sha256(text.encode()).hexdigest()


def _minimal_stack() -> DetectedStack:
    return DetectedStack(
        backend=BackendStack(language="python", root="."),
        frontend=None,
        repo_slug="myorg/myapp",
        is_git_repo=True,
        git_type="directory",
        git_dir="/tmp/myapp/.git",
        git_work_tree="/tmp/myapp",
    )


def _minimal_context(**overrides) -> RenderContext:
    defaults = dict(
        project_name="myapp",
        project_repo="myorg/myapp",
        stack=_minimal_stack(),
        profile="standard",
        deployment_method=None,
        health_url=None,
        worktree_enabled=False,
        schema_version=1,
        cli_version="0.1.0",
    )
    defaults.update(overrides)
    return RenderContext(**defaults)


def _minimal_state(**overrides) -> InitState:
    defaults = dict(
        cli_version="0.1.0",
        framework_version="0.13.3",
        schema_version=1,
        rendered_at="2026-04-12T00:00:00Z",
        template_hash="a" * 64,
        region_checksums={},
        profile="standard",
    )
    defaults.update(overrides)
    return InitState(**defaults)


# ---------------------------------------------------------------------------
# render_claude_md
# ---------------------------------------------------------------------------

class TestRenderClaudeMd:
    """render_claude_md(template, context) — Jinja2 render producing a CLAUDE.md string."""

    def test_renders_simple_variable_substitution(self) -> None:
        # Arrange
        template = "Project: {{ project_name }}"
        ctx = _minimal_context()
        # Act
        result = render_claude_md(template, ctx)
        # Assert
        assert "myapp" in result
        assert "{{ project_name }}" not in result

    def test_conditional_block_present_when_health_url_set(self) -> None:
        # Arrange
        template = textwrap.dedent("""\
            preamble
            {% if health_url %}
            Health: {{ health_url }}
            {% endif %}
            postamble
        """)
        ctx = _minimal_context(health_url="https://myapp.com/health")
        # Act
        result = render_claude_md(template, ctx)
        # Assert
        assert "https://myapp.com/health" in result

    def test_conditional_block_absent_when_health_url_none(self) -> None:
        # AC-4: optional fields omit their sections when unset
        template = textwrap.dedent("""\
            preamble
            {% if health_url %}
            Health: {{ health_url }}
            {% endif %}
            postamble
        """)
        ctx = _minimal_context(health_url=None)
        # Act
        result = render_claude_md(template, ctx)
        # Assert
        assert "Health:" not in result
        assert "postamble" in result

    def test_ac4_no_customize_markers_in_rendered_output(self) -> None:
        # AC-4: rendered output must contain zero occurrences of the string CUSTOMIZE
        # Template uses Jinja comment syntax so the marker never appears in output.
        template = textwrap.dedent("""\
            {# This template intentionally does not contain literal CUSTOMIZE strings #}
            Project: {{ project_name }}
            Repo: {{ project_repo }}
        """)
        ctx = _minimal_context()
        result = render_claude_md(template, ctx)
        assert "CUSTOMIZE" not in result

    def test_rendered_output_is_string(self) -> None:
        template = "Hello {{ project_name }}"
        ctx = _minimal_context()
        result = render_claude_md(template, ctx)
        assert isinstance(result, str)

    def test_profile_variable_available_in_template(self) -> None:
        template = "Profile: {{ profile }}"
        ctx = _minimal_context(profile="full")
        result = render_claude_md(template, ctx)
        assert "full" in result

    def test_worktree_enabled_controls_conditional_block(self) -> None:
        template = textwrap.dedent("""\
            {% if worktree_enabled %}
            WORKTREE ACTIVE
            {% endif %}
        """)
        ctx_on = _minimal_context(worktree_enabled=True)
        ctx_off = _minimal_context(worktree_enabled=False)
        assert "WORKTREE ACTIVE" in render_claude_md(template, ctx_on)
        assert "WORKTREE ACTIVE" not in render_claude_md(template, ctx_off)


# ---------------------------------------------------------------------------
# refresh_managed_regions
# ---------------------------------------------------------------------------

class TestRefreshManagedRegions:
    """refresh_managed_regions — merge new rendered regions into existing CLAUDE.md content."""

    def test_happy_path_replaces_unchanged_region(self) -> None:
        # AC-5: region with no user edits is replaced; no warnings emitted
        # Arrange: existing file has region "deploy" with body "old body"
        body = "old body"
        existing = "\n".join([
            "# Header",
            _begin("deploy"),
            body,
            _end("deploy"),
            "# Footer",
        ])
        new_body = "new body"
        new_rendered = "\n".join([
            _begin("deploy"),
            new_body,
            _end("deploy"),
        ])
        checksum = _sha(body)
        state = _minimal_state(region_checksums={"deploy": checksum})

        # Act
        merged, warnings = refresh_managed_regions(existing, new_rendered, state, force=False)

        # Assert
        assert new_body in merged
        assert "old body" not in merged
        assert warnings == []

    def test_user_edit_force_false_skips_region_and_warns(self) -> None:
        # AC-5: checksum mismatch + force=False → skip, warn "preserved"
        original_body = "original body"
        user_edited_body = "user edited body"
        existing = "\n".join([
            _begin("section"),
            user_edited_body,
            _end("section"),
        ])
        new_rendered = "\n".join([
            _begin("section"),
            "new rendered body",
            _end("section"),
        ])
        # State checksum matches the ORIGINAL (pre-edit) body, not user's edit
        state = _minimal_state(region_checksums={"section": _sha(original_body)})

        merged, warnings = refresh_managed_regions(existing, new_rendered, state, force=False)

        # User's edit is preserved
        assert "user edited body" in merged
        # At least one warning mentions preservation
        assert any("preserved" in w.lower() or "user edit" in w.lower() for w in warnings)

    def test_user_edit_force_true_overwrites_and_warns(self) -> None:
        # AC-5: checksum mismatch + force=True → overwrite, warn "overwritten"
        original_body = "original body"
        user_edited_body = "user edited body"
        existing = "\n".join([
            _begin("section"),
            user_edited_body,
            _end("section"),
        ])
        new_rendered = "\n".join([
            _begin("section"),
            "fresh content",
            _end("section"),
        ])
        state = _minimal_state(region_checksums={"section": _sha(original_body)})

        merged, warnings = refresh_managed_regions(existing, new_rendered, state, force=True)

        assert "fresh content" in merged
        assert "user edited body" not in merged
        assert any("overwritten" in w.lower() or "user edit" in w.lower() for w in warnings)

    def test_missing_end_marker_in_existing_emits_unbalanced_warning(self) -> None:
        # AC-5: orphan BEGIN (no END) → unbalanced warning, no data loss for other regions
        existing = "\n".join([
            _begin("orphan"),
            "some content",
            "# no END marker here",
            _begin("clean"),
            "clean body",
            _end("clean"),
        ])
        new_rendered = "\n".join([
            _begin("orphan"),
            "updated orphan",
            _end("orphan"),
            _begin("clean"),
            "updated clean",
            _end("clean"),
        ])
        state = _minimal_state(region_checksums={
            "orphan": _sha("some content"),
            "clean": _sha("clean body"),
        })

        merged, warnings = refresh_managed_regions(existing, new_rendered, state, force=False)

        # Unbalanced warning must mention the orphan region name
        assert any("orphan" in w.lower() or "unbalanced" in w.lower() for w in warnings)
        # The clean region was successfully updated
        assert "updated clean" in merged

    def test_region_in_new_rendered_not_in_existing_emits_not_found_warning(self) -> None:
        # Existing has no managed regions at all; new_rendered introduces one
        existing = "# Plain file\nno managed regions here\n"
        new_rendered = "\n".join([
            _begin("newreg"),
            "some new content",
            _end("newreg"),
        ])
        state = _minimal_state(region_checksums={})

        merged, warnings = refresh_managed_regions(existing, new_rendered, state, force=False)

        assert any("not found" in w.lower() or "newreg" in w.lower() for w in warnings)
        # Existing content is unchanged
        assert "Plain file" in merged

    def test_content_outside_regions_preserved_byte_for_byte(self) -> None:
        # AC-5: outside-region content is untouched (including CRLF, trailing space)
        outside = "  leading spaces  \r\nwindows line endings\r\n"
        body = "region body"
        existing = outside + _begin("reg") + "\n" + body + "\n" + _end("reg") + "\n"
        new_rendered = _begin("reg") + "\n" + "new region content\n" + _end("reg") + "\n"
        state = _minimal_state(region_checksums={"reg": _sha(body)})

        merged, warnings = refresh_managed_regions(existing, new_rendered, state, force=False)

        # The byte sequence before the BEGIN marker must be identical
        outside_in_merged = merged[: merged.index(_begin("reg"))]
        assert outside_in_merged == outside

    def test_returns_tuple_of_str_and_list(self) -> None:
        existing = "plain content"
        new_rendered = "also plain"
        state = _minimal_state()
        result = refresh_managed_regions(existing, new_rendered, state)
        merged, warnings = result
        assert isinstance(merged, str)
        assert isinstance(warnings, list)


# ---------------------------------------------------------------------------
# AC-2: StrictUndefined fails loud on template typos
# ---------------------------------------------------------------------------

class TestStrictUndefined:
    def test_typo_in_template_raises_undefined_error(self) -> None:
        """Template referencing an undefined variable must raise, not silently render empty."""
        import jinja2
        template = "Project: {{ projct_name }}"  # typo: projct vs project
        ctx = _minimal_context()
        with pytest.raises(jinja2.UndefinedError):
            render_claude_md(template, ctx)

    def test_valid_template_still_renders(self) -> None:
        """Baseline: a template with only valid variables must still render."""
        template = "Project: {{ project_name }}"
        ctx = _minimal_context(project_name="ok")
        assert render_claude_md(template, ctx) == "Project: ok"


# ---------------------------------------------------------------------------
# AC-4: Mismatched END marker emits warning from refresh_managed_regions
# ---------------------------------------------------------------------------

class TestMismatchedEndWarning:
    def test_mismatched_end_in_existing_content_emits_warning(self) -> None:
        """An END marker whose name doesn't match the currently-open BEGIN must surface as a warning."""
        # Existing file: BEGIN:A ... END:B (stray) ... END:A (correct close)
        existing = "\n".join([
            _begin("A"),
            "body",
            _end("B"),
            "more",
            _end("A"),
        ])
        new_rendered = "\n".join([_begin("A"), "replaced", _end("A")])
        state = _minimal_state(region_checksums={"A": _sha("body\nmore")})
        _merged, warnings = refresh_managed_regions(existing, new_rendered, state, force=False)
        assert any("mismatched END" in w and "B" in w for w in warnings), (
            f"expected 'mismatched END' warning mentioning B; got: {warnings}"
        )

    def test_well_formed_regions_emit_no_mismatched_warning(self) -> None:
        """Baseline: properly paired markers must NOT emit spurious mismatched-END warnings."""
        existing = "\n".join([_begin("X"), "body", _end("X")])
        new_rendered = "\n".join([_begin("X"), "new body", _end("X")])
        state = _minimal_state(region_checksums={"X": _sha("body")})
        _merged, warnings = refresh_managed_regions(existing, new_rendered, state, force=False)
        assert not any("mismatched END" in w for w in warnings), (
            f"expected no 'mismatched END' warning; got: {warnings}"
        )


# ---------------------------------------------------------------------------
# AC-3: Marker-injection rejection at RenderContext construction
# ---------------------------------------------------------------------------

class TestRenderContextInjectionGuard:
    def test_project_name_with_html_comment_open_rejected(self) -> None:
        with pytest.raises(ValueError, match="project_name"):
            _minimal_context(project_name="evil<!--injected")

    def test_project_name_with_html_comment_close_rejected(self) -> None:
        with pytest.raises(ValueError, match="project_name"):
            _minimal_context(project_name="evil-->injected")

    def test_project_name_with_newline_rejected(self) -> None:
        with pytest.raises(ValueError, match="project_name"):
            _minimal_context(project_name="first\nsecond")

    def test_project_name_with_null_byte_rejected(self) -> None:
        with pytest.raises(ValueError, match="project_name"):
            _minimal_context(project_name="a\x00b")

    def test_project_repo_with_marker_rejected(self) -> None:
        with pytest.raises(ValueError, match="project_repo"):
            _minimal_context(project_repo="evil<!--injected")

    def test_normal_project_name_accepted(self) -> None:
        """Baseline: reasonable names must still construct cleanly."""
        ctx = _minimal_context(project_name="my-project_2026.v2")
        assert ctx.project_name == "my-project_2026.v2"

    def test_deployment_method_with_marker_rejected(self) -> None:
        with pytest.raises(ValueError, match="deployment_method"):
            _minimal_context(deployment_method="railway<!--injected")

    def test_health_url_with_null_byte_rejected(self) -> None:
        with pytest.raises(ValueError, match="health_url"):
            _minimal_context(health_url="https://app.com/health\x00")

    def test_tab_character_rejected(self) -> None:
        """Tab is a C0 control char and must be blocked by the Cc-category check."""
        with pytest.raises(ValueError, match="project_name"):
            _minimal_context(project_name="tab\there")

    def test_bidi_override_rejected(self) -> None:
        """Right-to-left override can reorder displayed text deceptively."""
        with pytest.raises(ValueError, match="project_name"):
            _minimal_context(project_name="benign\u202ereversed")
