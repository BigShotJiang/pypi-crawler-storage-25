"""
Tests for the npm create-shipteam Node.js shim — AC-13.

The shim lives at npm/create-shipteam/bin/create-shipteam.js (not yet created).
These tests exercise it as a subprocess, providing fake runtime scripts on PATH
to verify:
  - Priority ordering: uvx > pipx run > python3 -m shipteam
  - No Python runtime → exit 1 + install instructions
  - Args forwarded safely (execFile, not shell-string interpolation)
  - Shell metacharacters in args are not interpreted by a shell

Collection-time skip: the entire module is skipped when `node` is not on PATH.
"""
from __future__ import annotations

import os
import shutil
import stat
import subprocess
import textwrap
from pathlib import Path

import pytest

# ---------------------------------------------------------------------------
# Module-level skip: Node.js must be available for these tests to run.
# ---------------------------------------------------------------------------

if shutil.which("node") is None:
    pytest.skip("node not found on PATH — skipping npm shim tests", allow_module_level=True)

# Absolute path to the shim under test (does NOT exist yet — RED phase).
SHIM_PATH = Path(__file__).parent.parent / "npm" / "create-shipteam" / "bin" / "create-shipteam.js"


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _write_fake_runtime(bin_dir: Path, name: str, exit_code: int = 0) -> Path:
    """Write a fake shell script that echoes its name and all args, then exits.

    The echo format is: '<name>: <arg1> <arg2> ...'
    This lets tests assert both WHICH runtime ran and WHAT args it received.
    """
    script = bin_dir / name
    script.write_text(
        textwrap.dedent(f"""\
            #!/bin/sh
            echo "{name}: $@"
            exit {exit_code}
        """)
    )
    script.chmod(script.stat().st_mode | stat.S_IEXEC | stat.S_IXGRP | stat.S_IXOTH)
    return script


def _run_shim(extra_args: list[str], env: dict[str, str]) -> subprocess.CompletedProcess:
    """Run the shim with subprocess.run, capturing stdout and stderr."""
    return subprocess.run(
        ["node", str(SHIM_PATH)] + extra_args,
        capture_output=True,
        text=True,
        timeout=30,
        env=env,
    )


@pytest.fixture
def _isolated_node_dir(tmp_path_factory) -> Path:
    """Create an isolated directory containing only a symlink to `node`.

    node's real directory (e.g. /opt/homebrew/bin) typically also contains
    pipx/python3, so exposing it via PATH would leak those runtimes into
    tests that need a clean environment. Symlinking node into a dedicated
    dir lets us put ONLY node on PATH.
    """
    node_path = shutil.which("node")
    if node_path is None:
        pytest.skip("node not found on PATH")
    isolated = tmp_path_factory.mktemp("isolated_node_bin")
    (isolated / "node").symlink_to(node_path)
    return isolated


def _minimal_env(path_override: str, isolated_node: Path) -> dict[str, str]:
    """Return a minimal environment dict with a controlled PATH.

    PATH = path_override:isolated_node (node-only directory). System pipx /
    python3 / uvx are NOT reachable unless explicitly staged in path_override.
    """
    return {
        "PATH": f"{path_override}:{isolated_node}",
        "HOME": os.environ.get("HOME", "/tmp"),
    }


# ---------------------------------------------------------------------------
# AC-13: No Python runtime available → exit 1 + install instructions
# ---------------------------------------------------------------------------

class TestShimNoRuntime:
    """AC-13: When no Python runtime is available, shim exits 1 with install instructions."""

    def test_ac13_exits_1_when_no_python_runtime_on_path(self, _isolated_node_dir: Path) -> None:
        """AC-13: PATH with no uvx/pipx/python3 → exit code 1."""
        # Arrange
        env = _minimal_env("/nonexistent-dir", _isolated_node_dir)
        # Act
        result = _run_shim(["init", "my-project"], env=env)
        # Assert
        assert result.returncode == 1

    def test_ac13_stderr_mentions_python_when_runtime_missing(self, _isolated_node_dir: Path) -> None:
        """AC-13: install instructions mention 'python' so users know what to install."""
        # Arrange
        env = _minimal_env("/nonexistent-dir", _isolated_node_dir)
        # Act
        result = _run_shim(["init", "my-project"], env=env)
        # Assert
        combined_output = result.stdout + result.stderr
        assert "python" in combined_output.lower()

    def test_ac13_stderr_mentions_uvx_or_pipx_when_runtime_missing(self, _isolated_node_dir: Path) -> None:
        """AC-13: install instructions mention 'uvx' or 'pipx' as recommended installers."""
        # Arrange
        env = _minimal_env("/nonexistent-dir", _isolated_node_dir)
        # Act
        result = _run_shim(["init", "my-project"], env=env)
        # Assert
        combined_output = result.stdout + result.stderr
        assert "uvx" in combined_output or "pipx" in combined_output


# ---------------------------------------------------------------------------
# AC-13: uvx available → shim delegates to uvx
# ---------------------------------------------------------------------------

class TestShimWithUvx:
    """AC-13: When uvx is on PATH, shim invokes it with forwarded args."""

    def test_ac13_uvx_invoked_when_available(self, tmp_path: Path, _isolated_node_dir: Path) -> None:
        """AC-13: fake uvx on PATH → shim calls it, exit 0."""
        # Arrange
        bin_dir = tmp_path / "bin"
        bin_dir.mkdir()
        _write_fake_runtime(bin_dir, "uvx", exit_code=0)
        env = _minimal_env(str(bin_dir), _isolated_node_dir)
        # Act
        result = _run_shim(["init", "my-project"], env=env)
        # Assert
        assert result.returncode == 0

    def test_ac13_uvx_receives_forwarded_args(self, tmp_path: Path, _isolated_node_dir: Path) -> None:
        """AC-13: args passed to shim are forwarded to uvx unchanged."""
        # Arrange
        bin_dir = tmp_path / "bin"
        bin_dir.mkdir()
        _write_fake_runtime(bin_dir, "uvx", exit_code=0)
        env = _minimal_env(str(bin_dir), _isolated_node_dir)
        # Act
        result = _run_shim(["init", "my-project"], env=env)
        # Assert: fake uvx echoes its args; should include 'shipteam' and our args
        assert "init" in result.stdout
        assert "my-project" in result.stdout


# ---------------------------------------------------------------------------
# AC-13: Priority — uvx beats pipx when both are present
# ---------------------------------------------------------------------------

class TestShimPriorityUvxOverPipx:
    """AC-13: uvx takes priority over pipx when both runtimes are on PATH."""

    def test_ac13_uvx_wins_over_pipx_when_both_on_path(self, tmp_path: Path, _isolated_node_dir: Path) -> None:
        """AC-13: both fake-uvx and fake-pipx on PATH → only uvx output appears."""
        # Arrange
        bin_dir = tmp_path / "bin"
        bin_dir.mkdir()
        _write_fake_runtime(bin_dir, "uvx", exit_code=0)
        _write_fake_runtime(bin_dir, "pipx", exit_code=0)
        env = _minimal_env(str(bin_dir), _isolated_node_dir)
        # Act
        result = _run_shim(["init", "test"], env=env)
        # Assert: uvx echoed first; pipx was NOT invoked
        assert "uvx:" in result.stdout
        assert "pipx:" not in result.stdout


# ---------------------------------------------------------------------------
# AC-13: Shell injection safety — args with metacharacters are forwarded literally
# ---------------------------------------------------------------------------

class TestShimArgSafety:
    """AC-13: execFile (not shell string) ensures shell metacharacters are not interpreted."""

    def test_ac13_shell_metacharacter_in_arg_forwarded_literally(self, tmp_path: Path, _isolated_node_dir: Path) -> None:
        """AC-13: arg containing ';' is forwarded as one argument, not split by shell."""
        # Arrange: fake uvx echoes "$@" — each arg is space-separated in shell output
        # but semicolons should NOT split into separate tokens
        bin_dir = tmp_path / "bin"
        bin_dir.mkdir()

        # Write a fake uvx that prints each argument on its own line to distinguish splitting
        fake_uvx = bin_dir / "uvx"
        fake_uvx.write_text(
            textwrap.dedent("""\
                #!/bin/sh
                for arg in "$@"; do
                    echo "ARG:$arg"
                done
                exit 0
            """)
        )
        fake_uvx.chmod(fake_uvx.stat().st_mode | stat.S_IEXEC | stat.S_IXGRP | stat.S_IXOTH)

        env = _minimal_env(str(bin_dir), _isolated_node_dir)
        dangerous_arg = "--repo=foo;bar"
        # Act
        result = _run_shim([dangerous_arg], env=env)
        # Assert: the dangerous arg must appear as ONE argument token.
        # If the shim used shell=True with a string, ';' would split it into two commands
        # and 'bar' would be interpreted as a separate command — it would NOT appear as "ARG:--repo=foo;bar".
        assert f"ARG:{dangerous_arg}" in result.stdout
        # 'bar' must NOT appear as a standalone separate ARG line
        assert "ARG:bar" not in result.stdout
