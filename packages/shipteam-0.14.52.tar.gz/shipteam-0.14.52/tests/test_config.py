"""
Tests for shipteam.config — FrameworkConfig loading, writing, and path validation.
"""
import textwrap
from pathlib import Path

import pytest

from shipteam.config import FrameworkConfig, load_config, write_config, validate_paths


class TestLoadConfig:
    """load_config(path) — parse framework.yaml into FrameworkConfig."""

    def test_load_config_valid(self, valid_framework_yaml: Path) -> None:
        # Arrange: valid_framework_yaml fixture yields a well-formed framework.yaml
        # Act
        config = load_config(valid_framework_yaml)
        # Assert
        assert isinstance(config, FrameworkConfig)
        assert config.project_name == "testproj"
        assert config.project_repo == "myorg/testproj"
        assert config.profile == "standard"
        assert config.schema_version == 1

    def test_load_config_missing_required(self, tmp_path: Path) -> None:
        """YAML missing project.name must raise ValueError."""
        # Arrange: write a yaml without the required project.name field
        yaml_path = tmp_path / "framework.yaml"
        yaml_path.write_text(
            textwrap.dedent("""\
                project:
                  repo: "myorg/testproj"
                profile: "standard"
                schema_version: 1
            """)
        )
        # Act + Assert
        with pytest.raises(ValueError):
            load_config(yaml_path)

    def test_load_config_empty_yaml(self, tmp_path: Path) -> None:
        """An empty framework.yaml must raise ValueError (not AttributeError)."""
        yaml_path = tmp_path / "framework.yaml"
        yaml_path.write_text("")
        with pytest.raises(ValueError):
            load_config(yaml_path)

    def test_load_config_uses_safe_load(self, malicious_yaml: Path) -> None:
        """load_config must not execute arbitrary Python via YAML deserialization."""
        # Arrange: malicious_yaml fixture has !!python/object/apply exploit payload
        import os
        # Capture whether os.system was called by checking a side-effect sentinel
        # We do not mock it — we assert the call either raises safely or returns
        # a plain dict/scalar without executing the payload.
        # Act: load_config should either raise (safe_load rejects the tag) or
        # return without invoking os.system.
        import yaml
        sentinel = malicious_yaml.parent / "pwned"
        try:
            result = load_config(malicious_yaml)
        except (yaml.YAMLError, ValueError):
            # acceptable: safe_load rejected the tag OR schema validation rejected it
            # sentinel must NOT exist — proves os.system was never invoked
            assert not sentinel.exists(), "load_config executed the unsafe payload"
            return
        assert not sentinel.exists(), "load_config executed the unsafe payload"
        assert isinstance(result, FrameworkConfig), (
            f"load_config returned unexpected type: {type(result)}"
        )

    def test_write_config_roundtrip(self, tmp_path: Path) -> None:
        """write_config then load_config must reproduce identical field values."""
        # Arrange
        config = FrameworkConfig(
            project_name="roundtrip",
            project_repo="org/roundtrip",
            profile="minimal",
            backend_language="python",
            frontend_language=None,
            schema_version=1,
            raw={
                "project": {"name": "roundtrip", "repo": "org/roundtrip"},
                "profile": "minimal",
                "schema_version": 1,
            },
        )
        yaml_path = tmp_path / "framework.yaml"
        # Act
        write_config(config, yaml_path)
        loaded = load_config(yaml_path)
        # Assert
        assert loaded.project_name == config.project_name
        assert loaded.project_repo == config.project_repo
        assert loaded.profile == config.profile
        assert loaded.schema_version == config.schema_version


class TestValidatePaths:
    """validate_paths(config, project_root) — path safety verification."""

    def test_validate_paths_safe(self, tmp_path: Path) -> None:
        """Config with only safe relative paths returns an empty violations list."""
        # Arrange
        config = FrameworkConfig(
            project_name="safe",
            project_repo="org/safe",
            profile="standard",
            raw={"stack": {"backend": {"root": "backend"}}},
        )
        # Act
        violations = validate_paths(config, tmp_path)
        # Assert
        assert isinstance(violations, list)
        assert len(violations) == 0

    def test_validate_paths_unsafe(self, tmp_path: Path) -> None:
        """Config with a path-traversal root returns a non-empty violations list."""
        # Arrange
        config = FrameworkConfig(
            project_name="unsafe",
            project_repo="org/unsafe",
            profile="standard",
            raw={"stack": {"backend": {"root": "../../etc"}}},
        )
        # Act
        violations = validate_paths(config, tmp_path)
        # Assert
        assert isinstance(violations, list)
        assert len(violations) > 0
        # At least one violation message must reference the bad path
        combined = " ".join(violations)
        assert "../../etc" in combined or "etc" in combined
