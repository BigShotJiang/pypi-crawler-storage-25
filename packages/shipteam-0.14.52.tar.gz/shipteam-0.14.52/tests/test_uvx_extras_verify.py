"""AC-10: shipteam[verify] extras pattern is invokable end-to-end.

The /deep-r investigation flagged real astral-sh/uv issues with extras and
uvx (#4762, #14558; uvx ignores some uv-pip-namespace settings). This test
verifies sympy + numpy actually install when a user runs
`pip install '.[verify]'` against the source tree.

We use `pip install` (not `uvx`) because uvx is for ephemeral tool execution
and doesn't expose the resulting site-packages for inspection. The pip path
exercises the same `pyproject.toml [project.optional-dependencies]` resolution.

If this test fails when run on a fresh env, it's evidence the extras pattern
is broken in some way — the failure is the whole point of the test (per AC-10
brief: ship the test even if it fails initially so the gap is visible).
"""

from __future__ import annotations

import os
import shutil
import subprocess
from pathlib import Path

import pytest

#: Known uv extras bugs to cite when subprocess failures match their pattern.
#: The /deep-r investigation surfaced these as the most likely failure modes
#: for the shipteam[verify] extras path; T-25 requires citation in failures.
_UV_EXTRAS_BUGS = (
    "https://github.com/astral-sh/uv/issues/4762",
    "https://github.com/astral-sh/uv/issues/14558",
)


def _fail_with_uv_bug_citation(stage: str, returncode: int, stdout: str, stderr: str) -> None:
    """Emit a structured failure that names the known uv extras bugs.

    T-25 (P0): when the extras path breaks, the failure message must cite
    astral-sh/uv #4762/#14558 so an operator can quickly check whether a known
    upstream issue is the cause vs. a new regression.
    """
    pytest.fail(
        f"shipteam[verify] extras path failed at {stage} (returncode={returncode}). "
        f"Likely upstream bugs: {', '.join(_UV_EXTRAS_BUGS)}. "
        f"stdout:\n{stdout}\nstderr:\n{stderr}"
    )

_REPO_ROOT = Path(__file__).parent.parent


def _have_uv() -> bool:
    return shutil.which("uv") is not None


@pytest.fixture(scope="module")
def venv_with_extras(tmp_path_factory):
    """Create an isolated venv and install shipteam with [verify] extra.

    Module-scoped because venv setup is slow (~5-15s); all tests in this
    module share the same venv. Skips with a clear reason if `uv` is not
    installed in the test environment.
    """
    if not _have_uv():
        pytest.skip("`uv` not on PATH — cannot exercise extras install path")

    venv_dir = tmp_path_factory.mktemp("shipteam_venv")
    # `uv venv` creates a venv without needing pip.
    res = subprocess.run(
        ["uv", "venv", str(venv_dir)],
        capture_output=True,
        text=True,
    )
    if res.returncode != 0:
        pytest.skip(f"uv venv failed: {res.stderr}")

    # On Unix the python binary is at venv/bin/python; on Windows venv\Scripts\python.exe.
    python_exe = (
        venv_dir / "bin" / "python"
        if (venv_dir / "bin" / "python").exists()
        else venv_dir / "Scripts" / "python.exe"
    )
    if not python_exe.exists():
        pytest.skip(f"venv python not found at {python_exe}")

    # Install ShipTeam from source with the [verify] extra. This exercises
    # `[project.optional-dependencies] verify = [sympy, numpy]`.
    res = subprocess.run(
        [
            "uv", "pip", "install",
            "--python", str(python_exe),
            f"{_REPO_ROOT}[verify]",
        ],
        capture_output=True,
        text=True,
        env={**os.environ, "VIRTUAL_ENV": str(venv_dir)},
    )
    if res.returncode != 0:
        _fail_with_uv_bug_citation("uv pip install", res.returncode, res.stdout, res.stderr)

    return python_exe


class TestExtrasInstall:
    """AC-10: shipteam[verify] extras pattern works end-to-end."""

    def test_sympy_importable_in_extras_env(self, venv_with_extras):
        res = subprocess.run(
            [str(venv_with_extras), "-c", "import sympy; print(sympy.__version__)"],
            capture_output=True,
            text=True,
        )
        if res.returncode != 0:
            _fail_with_uv_bug_citation("import sympy", res.returncode, res.stdout, res.stderr)
        assert res.stdout.strip(), "sympy import returned no version string"

    def test_numpy_importable_in_extras_env(self, venv_with_extras):
        res = subprocess.run(
            [str(venv_with_extras), "-c", "import numpy; print(numpy.__version__)"],
            capture_output=True,
            text=True,
        )
        if res.returncode != 0:
            _fail_with_uv_bug_citation("import numpy", res.returncode, res.stdout, res.stderr)
        assert res.stdout.strip(), "numpy import returned no version string"

    def test_verify_math_invocable_from_extras_env(self, venv_with_extras):
        """End-to-end (matches matrix T-24): default `--source` (no flag), simple expression."""
        verify_py = _REPO_ROOT / ".claude" / "skills" / "verify-math" / "verify.py"
        if not verify_py.exists():
            pytest.skip(f"verify.py not at {verify_py}")
        # `2+2` and no `--source=all` per T-24 — keeps the test agnostic to
        # WOLFRAM_APP_ID being set in CI (which would otherwise route through
        # the optional Wolfram path and emit different output).
        res = subprocess.run(
            [str(venv_with_extras), str(verify_py), "2+2"],
            capture_output=True,
            text=True,
        )
        if res.returncode != 0:
            _fail_with_uv_bug_citation("verify.py invoke", res.returncode, res.stdout, res.stderr)
        assert "Symbolic Result" in res.stdout, (
            f"verify.py output missing expected section header: {res.stdout!r}"
        )
