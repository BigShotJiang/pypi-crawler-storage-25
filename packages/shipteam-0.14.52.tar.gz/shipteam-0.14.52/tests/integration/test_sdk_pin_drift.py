"""
Integration tests for scripts/check_sdk_version.py — Phase 5a RED phase.

Covers AC-18: pyproject.toml and requirements-benchmark.lock pin the SDK exactly.

The script exits with code 0 ONLY when:
  1. The installed claude-agent-sdk version equals "0.1.68" (via importlib.metadata.version).
  2. pyproject.toml's [project.optional-dependencies].benchmark-claude contains
     the exact string "claude-agent-sdk==0.1.68".
  3. requirements-benchmark.lock exists at the project root, contains a pinned
     "claude-agent-sdk==0.1.68" line AND a pinned "mcp==<some-version>" line
     (transitive pin guard — mcp is the SDK's primary declared transitive per
     PyPI metadata; the original plan named "anthropic" but anthropic is not a
     declared dep of claude-agent-sdk; corrected 2026-04-27 from per-phase review).

Exit codes for failures (suggested by AC-18 spec):
  1 — installed version mismatch
  2 — pyproject.toml benchmark-claude dependency missing or wrong
  3 — requirements-benchmark.lock missing or drifted

The script must accept a --check-only flag that performs validation without
executing any benchmark code.

ISOLATION NOTES:
  - We do NOT install or uninstall claude-agent-sdk in CI.
  - importlib.metadata.version is mocked via monkeypatch to control installed version.
  - pyproject.toml and requirements-benchmark.lock are written under tmp_path.
  - The script is invoked as a subprocess with PYTHONPATH and file paths passed
    via env/args so the script reads tmp_path files, not project-root files.
"""

from __future__ import annotations

import importlib.metadata
import subprocess
import sys
import textwrap
from pathlib import Path

import pytest


# ---------------------------------------------------------------------------
# Script path constant
# ---------------------------------------------------------------------------

_SCRIPTS_DIR = Path(__file__).parent.parent.parent / "scripts"
_CHECK_SDK_SCRIPT = _SCRIPTS_DIR / "check_sdk_version.py"

# Expected pin (spec-mandated constant)
_EXPECTED_SDK_VERSION = "0.1.68"
_EXPECTED_SDK_DEP = f"claude-agent-sdk=={_EXPECTED_SDK_VERSION}"


# ---------------------------------------------------------------------------
# Filesystem fixture helpers
# ---------------------------------------------------------------------------

def _write_valid_pyproject(root: Path) -> Path:
    """Write a pyproject.toml with the correct benchmark-claude pin."""
    content = textwrap.dedent(f"""\
        [project]
        name = "benchmark-harness"
        version = "0.1.0"

        [project.optional-dependencies]
        benchmark-claude = [
            "{_EXPECTED_SDK_DEP}",
        ]
    """)
    p = root / "pyproject.toml"
    p.write_text(content)
    return p


def _write_valid_lockfile(root: Path) -> Path:
    """Write a requirements-benchmark.lock with both required pins."""
    content = textwrap.dedent(f"""\
        # This file is generated — do not edit manually.
        {_EXPECTED_SDK_DEP}
        mcp==1.27.0
        httpx==0.28.1
    """)
    p = root / "requirements-benchmark.lock"
    p.write_text(content)
    return p


def _write_pyproject_without_sdk_pin(root: Path) -> Path:
    """Write a pyproject.toml missing the claude-agent-sdk pin in benchmark-claude."""
    content = textwrap.dedent("""\
        [project]
        name = "benchmark-harness"
        version = "0.1.0"

        [project.optional-dependencies]
        benchmark-claude = [
            "httpx>=0.27",
        ]
    """)
    p = root / "pyproject.toml"
    p.write_text(content)
    return p


def _write_pyproject_with_wrong_sdk_version(root: Path) -> Path:
    """Write a pyproject.toml with the wrong SDK version (0.1.67, not 0.1.68)."""
    content = textwrap.dedent("""\
        [project]
        name = "benchmark-harness"
        version = "0.1.0"

        [project.optional-dependencies]
        benchmark-claude = [
            "claude-agent-sdk==0.1.67",
        ]
    """)
    p = root / "pyproject.toml"
    p.write_text(content)
    return p


def _write_lockfile_without_mcp(root: Path) -> Path:
    """Write requirements-benchmark.lock missing the mcp transitive pin."""
    content = textwrap.dedent(f"""\
        # Missing mcp transitive pin — drift condition.
        {_EXPECTED_SDK_DEP}
        httpx==0.28.1
    """)
    p = root / "requirements-benchmark.lock"
    p.write_text(content)
    return p


def _write_lockfile_without_sdk_pin(root: Path) -> Path:
    """Write requirements-benchmark.lock missing the sdk pin entirely."""
    content = textwrap.dedent("""\
        # Missing sdk pin — drift condition.
        mcp==1.27.0
        httpx==0.28.1
    """)
    p = root / "requirements-benchmark.lock"
    p.write_text(content)
    return p


# ---------------------------------------------------------------------------
# Helper to run the check script as a subprocess
# ---------------------------------------------------------------------------

def _run_check_script(
    root: Path,
    *,
    mock_installed_version: str = _EXPECTED_SDK_VERSION,
    extra_args: list[str] | None = None,
) -> subprocess.CompletedProcess:
    """
    Run check_sdk_version.py as a subprocess.

    We pass a wrapper script that monkeypatches importlib.metadata.version
    before invoking the check script via runpy, so the installed SDK version
    can be controlled without actually installing/uninstalling packages.

    RED-phase guard: assert the script exists. Without this, RED tests that
    only assert `proc.returncode != 0` trivially pass when the script is
    absent (FileNotFoundError → exit 1). This guard makes RED-state failure
    unambiguous: ScriptNotYetImplementedError → not a coincidental exit code.
    """
    assert _CHECK_SDK_SCRIPT.exists(), (
        f"scripts/check_sdk_version.py not found at {_CHECK_SDK_SCRIPT}. "
        "GREEN phase has not implemented the script yet — this assertion "
        "is the correct RED state. Implement the script to satisfy AC-18."
    )

    args = extra_args or []

    # The wrapper overrides importlib.metadata.version, changes CWD to root,
    # then runs the check script via runpy.run_path.
    wrapper_code = textwrap.dedent(f"""\
        import importlib.metadata
        import os
        import runpy
        import sys

        # Override the version lookup to return our mock version
        _real_version = importlib.metadata.version
        def _mock_version(pkg_name):
            if pkg_name == "claude-agent-sdk":
                return {mock_installed_version!r}
            return _real_version(pkg_name)
        importlib.metadata.version = _mock_version

        # Change CWD to the tmp root so the script reads files from there
        os.chdir({str(root)!r})

        # Run the check script
        sys.argv = [{str(_CHECK_SDK_SCRIPT)!r}] + {args!r}
        runpy.run_path({str(_CHECK_SDK_SCRIPT)!r}, run_name="__main__")
    """)

    return subprocess.run(
        [sys.executable, "-c", wrapper_code],
        capture_output=True,
        text=True,
    )


# ---------------------------------------------------------------------------
# AC-18: Correct alignment — exit code 0
# ---------------------------------------------------------------------------

class TestSdkPinCheckSuccessPath:
    """AC-18: check_sdk_version.py exits 0 when all three conditions are met."""

    def test_ac18_exits_zero_when_all_conditions_aligned(self, tmp_path: Path) -> None:
        """
        Given installed version = "0.1.68",
          AND pyproject.toml benchmark-claude has "claude-agent-sdk==0.1.68",
          AND requirements-benchmark.lock has both required pins,
        When check_sdk_version.py is run,
        Then exit code is 0.
        """
        # Arrange
        _write_valid_pyproject(tmp_path)
        _write_valid_lockfile(tmp_path)

        # Act
        proc = _run_check_script(tmp_path, mock_installed_version=_EXPECTED_SDK_VERSION)

        # Assert
        assert proc.returncode == 0, (
            f"Expected exit 0 for fully aligned pins; got {proc.returncode}.\n"
            f"stdout: {proc.stdout!r}\nstderr: {proc.stderr!r}"
        )

    def test_ac18_check_only_flag_accepted(self, tmp_path: Path) -> None:
        """
        Given --check-only flag and all conditions aligned,
        When check_sdk_version.py --check-only is run,
        Then exit code is 0 (flag must be accepted without error).
        """
        # Arrange
        _write_valid_pyproject(tmp_path)
        _write_valid_lockfile(tmp_path)

        # Act
        proc = _run_check_script(
            tmp_path,
            mock_installed_version=_EXPECTED_SDK_VERSION,
            extra_args=["--check-only"],
        )

        # Assert
        assert proc.returncode == 0, (
            f"--check-only with aligned pins must exit 0; got {proc.returncode}.\n"
            f"stdout: {proc.stdout!r}\nstderr: {proc.stderr!r}"
        )


# ---------------------------------------------------------------------------
# AC-18: Installed version mismatch — exit non-zero
# ---------------------------------------------------------------------------

class TestSdkPinCheckVersionMismatch:
    """AC-18: check_sdk_version.py exits non-zero when installed version differs."""

    def test_ac18_wrong_installed_version_exits_nonzero(self, tmp_path: Path) -> None:
        """
        Given installed claude-agent-sdk version = "0.1.67" (wrong),
          AND pyproject.toml and lockfile are otherwise correct,
        When check_sdk_version.py is run,
        Then exit code is non-zero.

        AC-18 contract: all three conditions must hold; installed version mismatch alone
        is sufficient cause for non-zero exit.
        """
        # Arrange
        _write_valid_pyproject(tmp_path)
        _write_valid_lockfile(tmp_path)

        # Act — mock installed version is wrong
        proc = _run_check_script(tmp_path, mock_installed_version="0.1.67")

        # Assert
        assert proc.returncode != 0, (
            f"Expected non-zero exit for wrong installed version; got {proc.returncode}.\n"
            f"stdout: {proc.stdout!r}\nstderr: {proc.stderr!r}"
        )

    def test_ac18_wrong_installed_version_suggested_exit_code_1(
        self, tmp_path: Path
    ) -> None:
        """
        Given installed claude-agent-sdk version = "0.1.67" (wrong),
        When check_sdk_version.py is run,
        Then exit code is 1 (suggested code for version mismatch per AC-18 spec).
        """
        # Arrange
        _write_valid_pyproject(tmp_path)
        _write_valid_lockfile(tmp_path)

        # Act
        proc = _run_check_script(tmp_path, mock_installed_version="0.1.67")

        # Assert — spec says exit 1 for version mismatch
        assert proc.returncode == 1, (
            f"Expected exit 1 for installed version mismatch; got {proc.returncode}.\n"
            f"stdout: {proc.stdout!r}\nstderr: {proc.stderr!r}"
        )

    def test_ac18_future_version_also_exits_nonzero(self, tmp_path: Path) -> None:
        """
        Given installed claude-agent-sdk version = "0.2.0" (newer than pinned),
        When check_sdk_version.py is run,
        Then exit code is non-zero.

        Drift in EITHER direction (older or newer) must be caught.
        """
        # Arrange
        _write_valid_pyproject(tmp_path)
        _write_valid_lockfile(tmp_path)

        # Act
        proc = _run_check_script(tmp_path, mock_installed_version="0.2.0")

        # Assert
        assert proc.returncode != 0, (
            f"Newer installed version must also exit non-zero; got {proc.returncode}.\n"
            f"stdout: {proc.stdout!r}\nstderr: {proc.stderr!r}"
        )


# ---------------------------------------------------------------------------
# AC-18: pyproject.toml missing or wrong benchmark-claude pin — exit non-zero
# ---------------------------------------------------------------------------

class TestSdkPinCheckPyprojectDrift:
    """AC-18: check_sdk_version.py exits non-zero when pyproject.toml is drifted."""

    def test_ac18_pyproject_missing_sdk_pin_exits_nonzero(self, tmp_path: Path) -> None:
        """
        Given installed version = "0.1.68" and lockfile are correct,
          BUT pyproject.toml benchmark-claude does NOT contain "claude-agent-sdk==0.1.68",
        When check_sdk_version.py is run,
        Then exit code is non-zero.
        """
        # Arrange
        _write_pyproject_without_sdk_pin(tmp_path)
        _write_valid_lockfile(tmp_path)

        # Act
        proc = _run_check_script(tmp_path, mock_installed_version=_EXPECTED_SDK_VERSION)

        # Assert
        assert proc.returncode != 0, (
            f"Expected non-zero when pyproject.toml lacks sdk pin; got {proc.returncode}.\n"
            f"stdout: {proc.stdout!r}\nstderr: {proc.stderr!r}"
        )

    def test_ac18_pyproject_wrong_sdk_version_exits_nonzero(self, tmp_path: Path) -> None:
        """
        Given installed version = "0.1.68" and lockfile are correct,
          BUT pyproject.toml has "claude-agent-sdk==0.1.67" (wrong version),
        When check_sdk_version.py is run,
        Then exit code is non-zero.
        """
        # Arrange
        _write_pyproject_with_wrong_sdk_version(tmp_path)
        _write_valid_lockfile(tmp_path)

        # Act
        proc = _run_check_script(tmp_path, mock_installed_version=_EXPECTED_SDK_VERSION)

        # Assert
        assert proc.returncode != 0, (
            f"Wrong pyproject version must exit non-zero; got {proc.returncode}.\n"
            f"stdout: {proc.stdout!r}\nstderr: {proc.stderr!r}"
        )

    def test_ac18_pyproject_missing_exit_code_suggested_2(self, tmp_path: Path) -> None:
        """
        Given pyproject.toml is missing the SDK pin,
        When check_sdk_version.py is run,
        Then exit code is 2 (suggested code for pyproject mismatch per AC-18 spec).
        """
        # Arrange
        _write_pyproject_without_sdk_pin(tmp_path)
        _write_valid_lockfile(tmp_path)

        # Act
        proc = _run_check_script(tmp_path, mock_installed_version=_EXPECTED_SDK_VERSION)

        # Assert
        assert proc.returncode == 2, (
            f"Expected exit 2 for pyproject mismatch; got {proc.returncode}.\n"
            f"stdout: {proc.stdout!r}\nstderr: {proc.stderr!r}"
        )


# ---------------------------------------------------------------------------
# AC-18: requirements-benchmark.lock missing or drifted — exit non-zero
# ---------------------------------------------------------------------------

class TestSdkPinCheckLockfileDrift:
    """AC-18: check_sdk_version.py exits non-zero when lockfile is missing or drifted."""

    def test_ac18_lockfile_missing_exits_nonzero(self, tmp_path: Path) -> None:
        """
        Given installed version = "0.1.68" and pyproject.toml are correct,
          BUT requirements-benchmark.lock does NOT exist,
        When check_sdk_version.py is run,
        Then exit code is non-zero.
        """
        # Arrange — only pyproject, no lockfile
        _write_valid_pyproject(tmp_path)
        # Intentionally do NOT write requirements-benchmark.lock

        # Act
        proc = _run_check_script(tmp_path, mock_installed_version=_EXPECTED_SDK_VERSION)

        # Assert
        assert proc.returncode != 0, (
            f"Missing lockfile must exit non-zero; got {proc.returncode}.\n"
            f"stdout: {proc.stdout!r}\nstderr: {proc.stderr!r}"
        )

    def test_ac18_lockfile_missing_suggested_exit_code_3(self, tmp_path: Path) -> None:
        """
        Given requirements-benchmark.lock is missing,
        When check_sdk_version.py is run,
        Then exit code is 3 (suggested code for lockfile missing per AC-18 spec).
        """
        # Arrange
        _write_valid_pyproject(tmp_path)
        # No lockfile

        # Act
        proc = _run_check_script(tmp_path, mock_installed_version=_EXPECTED_SDK_VERSION)

        # Assert
        assert proc.returncode == 3, (
            f"Expected exit 3 for missing lockfile; got {proc.returncode}.\n"
            f"stdout: {proc.stdout!r}\nstderr: {proc.stderr!r}"
        )

    def test_ac18_lockfile_without_mcp_pin_exits_nonzero(
        self, tmp_path: Path
    ) -> None:
        """
        Given requirements-benchmark.lock exists and has the SDK pin,
          BUT is missing the transitive 'mcp==' pin,
        When check_sdk_version.py is run,
        Then exit code is non-zero.

        AC-18 contract: transitive pin guard — mcp (the SDK's primary declared
        transitive per PyPI metadata) must also be pinned.
        """
        # Arrange
        _write_valid_pyproject(tmp_path)
        _write_lockfile_without_mcp(tmp_path)

        # Act
        proc = _run_check_script(tmp_path, mock_installed_version=_EXPECTED_SDK_VERSION)

        # Assert
        assert proc.returncode != 0, (
            f"Missing mcp transitive pin must exit non-zero; got {proc.returncode}.\n"
            f"stdout: {proc.stdout!r}\nstderr: {proc.stderr!r}"
        )

    def test_ac18_lockfile_without_sdk_pin_exits_nonzero(self, tmp_path: Path) -> None:
        """
        Given requirements-benchmark.lock exists but is missing claude-agent-sdk pin,
        When check_sdk_version.py is run,
        Then exit code is non-zero (lockfile drift detected).
        """
        # Arrange
        _write_valid_pyproject(tmp_path)
        _write_lockfile_without_sdk_pin(tmp_path)

        # Act
        proc = _run_check_script(tmp_path, mock_installed_version=_EXPECTED_SDK_VERSION)

        # Assert
        assert proc.returncode != 0, (
            f"Lockfile without sdk pin must exit non-zero; got {proc.returncode}.\n"
            f"stdout: {proc.stdout!r}\nstderr: {proc.stderr!r}"
        )

    def test_ac18_lockfile_with_wrong_sdk_version_exits_nonzero(
        self, tmp_path: Path
    ) -> None:
        """
        Given requirements-benchmark.lock contains 'claude-agent-sdk==0.1.67' (wrong),
        When check_sdk_version.py is run,
        Then exit code is non-zero.
        """
        # Arrange
        _write_valid_pyproject(tmp_path)

        # Write lockfile with wrong sdk version
        wrong_lock = textwrap.dedent("""\
            claude-agent-sdk==0.1.67
            mcp==1.27.0
            httpx==0.28.1
        """)
        (tmp_path / "requirements-benchmark.lock").write_text(wrong_lock)

        # Act
        proc = _run_check_script(tmp_path, mock_installed_version=_EXPECTED_SDK_VERSION)

        # Assert
        assert proc.returncode != 0, (
            f"Lockfile with wrong sdk version must exit non-zero; got {proc.returncode}.\n"
            f"stdout: {proc.stdout!r}\nstderr: {proc.stderr!r}"
        )
