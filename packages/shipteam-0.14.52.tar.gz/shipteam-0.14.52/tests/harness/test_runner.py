"""
Tests for harness/runner.py — T-1, T-2 (AC-1 narrow, Phase 1 scope).

Covers:
  T-1: Happy-path single run against mock driver writes exactly one ResultRow
       to output JSONL with aborted=false and all required fields non-null.
  T-2: Mock driver DriverResult flows through runner; row records
       cost_source="native" and cache_strategy="salted" (Phase 5e narrowing
       replaced the legacy "omitted" with the salted-prompt-suffix mechanism).
"""
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any
from unittest.mock import MagicMock, patch

import pytest

from harness.runner import run_cell


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class _FakeDriverResult:
    """Minimal DriverResult-shaped object for mock injection."""
    wall_clock_ms: int = 1234
    input_tokens: int | None = 100
    output_tokens: int | None = 50
    cost_usd: float | None = 0.002
    cost_source: str = "native"
    aborted: bool = False
    abort_reason: str | None = None
    cache_strategy: str = "salted"
    driver_metadata: dict = None  # type: ignore[assignment]

    def __post_init__(self) -> None:
        if self.driver_metadata is None:
            object.__setattr__(
                self,
                "driver_metadata",
                {"cache_strategy": self.cache_strategy, "cache_read_input_tokens": 0},
            )


def _make_mock_driver(result: _FakeDriverResult) -> MagicMock:
    """Return a Driver mock that satisfies the Driver protocol."""
    driver = MagicMock()
    driver.name = "claude_code"
    driver.version.return_value = "0.1.0"
    driver.sdk_version.return_value = "0.1.15"
    driver.release_date.return_value = "2024-08-01"
    driver.prepare.return_value = None
    driver.execute.return_value = result
    return driver


# ---------------------------------------------------------------------------
# T-1: Happy-path single run — one valid JSONL row, aborted=false
# ---------------------------------------------------------------------------

class TestRunnerHappyPath:
    """run_cell — T-1: end-to-end single run writes one ResultRow."""

    def test_single_run_writes_one_jsonl_row(self, tmp_path: Path) -> None:
        """
        Given a pinned task pack url_shortener, driver claude_code, and seed 1,
        When run_cell is invoked with a mock driver,
        Then exactly one ResultRow is appended to output_jsonl with aborted=false
        and all required fields non-null.
        """
        # Arrange
        output_jsonl = tmp_path / "results.jsonl"
        fake_result = _FakeDriverResult()
        mock_driver = _make_mock_driver(fake_result)

        # Act — patch the driver registry so run_cell uses our mock
        with patch("harness.runner.load_driver", return_value=mock_driver), \
             patch("harness.runner.run_container_for_seed", return_value=fake_result), \
             patch("harness.runner.score_workspace", return_value={
                 "acceptance_pct": 0.8,
                 "mutation_score": {"python": {"killed": 4, "survived": 1, "timeout": 0, "score": 0.8}},
                 "semgrep_high": 0,
                 "semgrep_critical": 0,
                 "injected_bug_detections": 2,
             }):
            exit_code = run_cell(
                driver="claude_code",
                task="url_shortener",
                seeds=[1],
                budget_usd=10.0,
                max_wall_clock_minutes=30,
                output_jsonl=output_jsonl,
                container_image="ghcr.io/cdjgroup/shipteam-tasks-url-shortener@sha256:abc123",
                require_sdk_version_gate=False,
            )

        # Assert — exactly one row
        assert output_jsonl.exists(), "output_jsonl was never created"
        lines = [l for l in output_jsonl.read_text().splitlines() if l.strip()]
        assert len(lines) == 1, f"Expected 1 JSONL row, got {len(lines)}"

        row = json.loads(lines[0])
        assert row["aborted"] is False
        assert row["abort_reason"] is None

    def test_single_run_all_required_fields_populated(self, tmp_path: Path) -> None:
        """
        Given a mock driver that completes successfully,
        When run_cell writes the ResultRow,
        Then every AC-6 required field is present and non-null in the JSONL row.
        """
        # Arrange
        output_jsonl = tmp_path / "results.jsonl"
        required_fields = [
            "container_digest",
            "driver_version",
            "task_pack_revision",
            "harness_version",
            "sdk_version",
            "sdk_release_date",
            "timestamp_utc",
        ]
        fake_result = _FakeDriverResult()
        mock_driver = _make_mock_driver(fake_result)

        # Act
        with patch("harness.runner.load_driver", return_value=mock_driver), \
             patch("harness.runner.run_container_for_seed", return_value=fake_result), \
             patch("harness.runner.score_workspace", return_value={
                 "acceptance_pct": 1.0,
                 "mutation_score": {},
                 "semgrep_high": 0,
                 "semgrep_critical": 0,
                 "injected_bug_detections": 0,
             }):
            run_cell(
                driver="claude_code",
                task="url_shortener",
                seeds=[1],
                budget_usd=10.0,
                max_wall_clock_minutes=30,
                output_jsonl=output_jsonl,
                container_image="ghcr.io/cdjgroup/shipteam-tasks-url-shortener@sha256:abc123",
                require_sdk_version_gate=False,
            )

        # Assert
        lines = [l for l in output_jsonl.read_text().splitlines() if l.strip()]
        assert lines, "No JSONL rows written"
        row = json.loads(lines[0])
        for field in required_fields:
            assert field in row, f"Required field missing from row: {field}"
            assert row[field] is not None, f"Required field is null: {field}"


# ---------------------------------------------------------------------------
# T-2: DriverResult fields flow through to JSONL row intact
# ---------------------------------------------------------------------------

class TestRunnerFieldPassthrough:
    """run_cell — T-2: native cost path and cache_strategy propagate to row."""

    def test_cost_source_native_recorded(self, tmp_path: Path) -> None:
        """
        Given a mock driver that returns cost_source='native',
        When run_cell writes the result row,
        Then the row's cost_source field equals 'native'.
        """
        # Arrange
        output_jsonl = tmp_path / "results.jsonl"
        fake_result = _FakeDriverResult(cost_source="native")
        mock_driver = _make_mock_driver(fake_result)

        # Act
        with patch("harness.runner.load_driver", return_value=mock_driver), \
             patch("harness.runner.run_container_for_seed", return_value=fake_result), \
             patch("harness.runner.score_workspace", return_value={
                 "acceptance_pct": 0.5,
                 "mutation_score": {},
                 "semgrep_high": 0,
                 "semgrep_critical": 0,
                 "injected_bug_detections": 0,
             }):
            run_cell(
                driver="claude_code",
                task="url_shortener",
                seeds=[1],
                budget_usd=10.0,
                max_wall_clock_minutes=30,
                output_jsonl=output_jsonl,
                container_image="ghcr.io/cdjgroup/shipteam-tasks-url-shortener@sha256:abc123",
                require_sdk_version_gate=False,
            )

        # Assert
        row = json.loads(output_jsonl.read_text().splitlines()[0])
        assert row["cost_source"] == "native"

    def test_cache_strategy_salted_recorded(self, tmp_path: Path) -> None:
        """
        Given a mock driver that returns cache_strategy='salted',
        When run_cell writes the result row,
        Then the row's cache_strategy field equals 'salted'.

        Phase 5e narrowed the literal from {"omitted","salted"} →
        {"salted","native"}. The semantic — driver's cache_strategy flows
        through to the JSONL row unchanged — is what we still check.
        """
        # Arrange
        output_jsonl = tmp_path / "results.jsonl"
        fake_result = _FakeDriverResult(cache_strategy="salted")
        mock_driver = _make_mock_driver(fake_result)

        # Act
        with patch("harness.runner.load_driver", return_value=mock_driver), \
             patch("harness.runner.run_container_for_seed", return_value=fake_result), \
             patch("harness.runner.score_workspace", return_value={
                 "acceptance_pct": 0.5,
                 "mutation_score": {},
                 "semgrep_high": 0,
                 "semgrep_critical": 0,
                 "injected_bug_detections": 0,
             }):
            run_cell(
                driver="claude_code",
                task="url_shortener",
                seeds=[1],
                budget_usd=10.0,
                max_wall_clock_minutes=30,
                output_jsonl=output_jsonl,
                container_image="ghcr.io/cdjgroup/shipteam-tasks-url-shortener@sha256:abc123",
                require_sdk_version_gate=False,
            )

        # Assert
        row = json.loads(output_jsonl.read_text().splitlines()[0])
        assert row["cache_strategy"] == "salted"

    def test_exit_code_zero_on_success(self, tmp_path: Path) -> None:
        """
        Given a mock driver that completes without abort,
        When run_cell returns,
        Then it returns exit code 0.
        """
        # Arrange
        output_jsonl = tmp_path / "results.jsonl"
        fake_result = _FakeDriverResult()
        mock_driver = _make_mock_driver(fake_result)

        # Act
        with patch("harness.runner.load_driver", return_value=mock_driver), \
             patch("harness.runner.run_container_for_seed", return_value=fake_result), \
             patch("harness.runner.score_workspace", return_value={
                 "acceptance_pct": 1.0,
                 "mutation_score": {},
                 "semgrep_high": 0,
                 "semgrep_critical": 0,
                 "injected_bug_detections": 0,
             }):
            exit_code = run_cell(
                driver="claude_code",
                task="url_shortener",
                seeds=[1],
                budget_usd=10.0,
                max_wall_clock_minutes=30,
                output_jsonl=output_jsonl,
                container_image="ghcr.io/cdjgroup/shipteam-tasks-url-shortener@sha256:abc123",
                require_sdk_version_gate=False,
            )

        # Assert
        assert exit_code == 0


# ---------------------------------------------------------------------------
# Phase 5d — load_driver registry expansion
#
# Phase 5a shipped only the claude_code driver. Phase 5d wires aider and
# droid into the registry so Phase 5h's 3-driver smoke run can route
# `--driver=aider` / `--driver=droid` to the right adapter.
# ---------------------------------------------------------------------------


class TestLoadDriverRegistry:
    """
    load_driver(name) returns the corresponding Driver instance for each
    supported name; unknown names raise ValueError naming the bad input
    AND the supported set so the operator can self-correct without grepping.
    """

    def test_load_driver_claude_code_returns_claude_driver(self) -> None:
        from harness.runner import load_driver
        from drivers.claude_code import ClaudeCodeDriver

        instance = load_driver("claude_code")
        assert isinstance(instance, ClaudeCodeDriver), (
            f"load_driver('claude_code') must return ClaudeCodeDriver; "
            f"got {type(instance).__name__}"
        )

    def test_load_driver_aider_returns_aider_driver(self) -> None:
        # AiderDriver.__init__ probes importlib.metadata for the real
        # aider-chat package and fails fast if missing — that's correct
        # production behaviour, but we don't require the optional CLI dep
        # for unit tests. Patch the version probe to a stub.
        from harness.runner import load_driver
        from drivers.aider import AiderDriver

        with patch("drivers.aider.importlib.metadata.version", return_value="0.0.0-test"):
            instance = load_driver("aider")
        assert isinstance(instance, AiderDriver), (
            f"load_driver('aider') must return AiderDriver; "
            f"got {type(instance).__name__}"
        )

    def test_load_driver_droid_returns_droid_driver(self) -> None:
        from harness.runner import load_driver
        from drivers.droid import DroidDriver

        instance = load_driver("droid")
        assert isinstance(instance, DroidDriver), (
            f"load_driver('droid') must return DroidDriver; "
            f"got {type(instance).__name__}"
        )

    def test_load_driver_unknown_raises_value_error(self) -> None:
        from harness.runner import load_driver

        with pytest.raises(ValueError) as exc_info:
            load_driver("openhands")  # plausible-looking but unsupported
        msg = str(exc_info.value)
        assert "openhands" in msg, (
            f"ValueError must echo the unknown driver name verbatim so "
            f"the operator can spot the typo; got: {msg!r}"
        )
        # Operator self-correction: the supported set must be discoverable
        # from the error message, not from grepping the source.
        assert "claude_code" in msg or "aider" in msg or "droid" in msg, (
            f"ValueError must name the supported driver set; got: {msg!r}"
        )


# ---------------------------------------------------------------------------
# Phase 5d — score_workspace aggregator
#
# Replaces the Phase 5a stub with a real aggregator that delegates to
# scoring.acceptance.score_acceptance and scoring.mutation.score_mutation.
# Tests assert at the DELEGATION BOUNDARY (was the right scorer called
# with the right args) plus the OUTPUT SHAPE (keys consumers depend on).
# ---------------------------------------------------------------------------


class TestScoreWorkspaceAggregator:
    """
    score_workspace(workspace_dir, pack) → dict aggregates the two scoring
    subsystems for one cell. Must:
      (a) call score_acceptance with workspace + pack.pack_dir/frozen_tests
      (b) call score_mutation with workspace + pack.to_manifest_dict()
      (c) propagate RuntimeError from AC-13 inode guard upward (NOT swallow)
      (d) return a dict with keys consumed by run_cell row assembly:
          acceptance_pct, mutation_score, semgrep_high, semgrep_critical,
          injected_bug_detections
    """

    def _make_pack_for_score(self, tmp_path: Path):
        """Build a TaskPack with realistic frozen_tests/injected_bugs dirs."""
        from task_packs.loader import TaskPack

        pack_dir = tmp_path / "pack"
        (pack_dir / "frozen_tests").mkdir(parents=True)
        (pack_dir / "injected_bugs").mkdir(parents=True)
        return TaskPack(
            name="url_shortener",
            container_image_pinned=(
                "shipteam-url-shortener:test@sha256:"
                "0123456789abcdef0123456789abcdef"
                "0123456789abcdef0123456789abcdef"
            ),
            entry_point="shortener.py",
            test_command="pytest tests/",
            stryker_config_path="stryker.conf.json",
            language="python",
            seed=42,
            pack_dir=pack_dir,
        )

    def test_score_workspace_calls_score_acceptance_with_frozen_tests(
        self, tmp_path: Path
    ) -> None:
        """score_acceptance receives workspace_dir AND pack's frozen_tests/."""
        from harness.runner import score_workspace
        from scoring.acceptance import AcceptanceResult
        from scoring.mutation import MutationResult

        pack = self._make_pack_for_score(tmp_path)
        workspace = tmp_path / "ws"
        workspace.mkdir()
        expected_frozen = pack.pack_dir / "frozen_tests"

        with patch(
            "harness.runner.score_acceptance",
            return_value=AcceptanceResult(
                acceptance_pct=0.8, passed=4, failed=1, total=5, errors=0
            ),
        ) as mock_acc, patch(
            "harness.runner.score_mutation",
            return_value=MutationResult(
                per_language={}, error=None, tool_name=None
            ),
        ):
            score_workspace(workspace_dir=workspace, pack=pack)

        assert mock_acc.called, "score_acceptance must be called"
        # Accept positional or kwarg invocation; assert frozen_tests path.
        call = mock_acc.call_args
        all_args = list(call.args) + list(call.kwargs.values())
        assert expected_frozen in all_args, (
            f"score_acceptance must receive pack.pack_dir/frozen_tests "
            f"({expected_frozen!r}); got args={call.args!r} kwargs={call.kwargs!r}"
        )
        assert workspace in all_args, (
            f"score_acceptance must receive workspace_dir; got {call!r}"
        )

    def test_score_workspace_calls_score_mutation_with_manifest(
        self, tmp_path: Path
    ) -> None:
        """score_mutation receives workspace_dir AND pack.to_manifest_dict()."""
        from harness.runner import score_workspace
        from scoring.acceptance import AcceptanceResult
        from scoring.mutation import MutationResult

        pack = self._make_pack_for_score(tmp_path)
        workspace = tmp_path / "ws"
        workspace.mkdir()
        expected_manifest = pack.to_manifest_dict()

        with patch(
            "harness.runner.score_acceptance",
            return_value=AcceptanceResult(
                acceptance_pct=1.0, passed=5, failed=0, total=5, errors=0
            ),
        ), patch(
            "harness.runner.score_mutation",
            return_value=MutationResult(
                per_language={}, error=None, tool_name=None
            ),
        ) as mock_mut:
            score_workspace(workspace_dir=workspace, pack=pack)

        assert mock_mut.called, "score_mutation must be called"
        call = mock_mut.call_args
        all_args = list(call.args) + list(call.kwargs.values())
        assert workspace in all_args, (
            f"score_mutation must receive workspace_dir; got {call!r}"
        )
        assert expected_manifest in all_args, (
            f"score_mutation must receive pack.to_manifest_dict(); "
            f"got {call!r}"
        )

    def test_score_workspace_returns_dict_with_required_keys(
        self, tmp_path: Path
    ) -> None:
        """Output dict has the keys run_cell row-assembly depends on."""
        from harness.runner import score_workspace
        from scoring.acceptance import AcceptanceResult
        from scoring.mutation import MutationResult

        pack = self._make_pack_for_score(tmp_path)
        workspace = tmp_path / "ws"
        workspace.mkdir()

        with patch(
            "harness.runner.score_acceptance",
            return_value=AcceptanceResult(
                acceptance_pct=0.6, passed=3, failed=2, total=5, errors=0
            ),
        ), patch(
            "harness.runner.score_mutation",
            return_value=MutationResult(
                per_language={}, error=None, tool_name=None
            ),
        ):
            result = score_workspace(workspace_dir=workspace, pack=pack)

        assert isinstance(result, dict), f"expected dict, got {type(result)}"
        required_keys = {
            "acceptance_pct",
            "mutation_score",
            "semgrep_high",
            "semgrep_critical",
            "injected_bug_detections",
        }
        missing = required_keys - set(result.keys())
        assert not missing, (
            f"score_workspace dict missing keys consumed by run_cell row "
            f"assembly: {missing}; got keys: {sorted(result.keys())!r}"
        )
        assert result["acceptance_pct"] == 0.6, (
            f"acceptance_pct must propagate from score_acceptance; got {result!r}"
        )

    def test_score_workspace_propagates_acceptance_runtime_error(
        self, tmp_path: Path
    ) -> None:
        """
        AC-13 hardlink/inode guard: score_acceptance raises RuntimeError when
        workspace and frozen_tests share an inode (hardlink/bind-mount). This
        signal MUST NOT be swallowed — it indicates active tampering and the
        cell must abort, not silently record acceptance_pct=0.0 as a normal
        driver failure.
        """
        from harness.runner import score_workspace
        from scoring.mutation import MutationResult

        pack = self._make_pack_for_score(tmp_path)
        workspace = tmp_path / "ws"
        workspace.mkdir()

        tamper_error = RuntimeError(
            "Detected shared inode (hardlink or bind-mount) between workspace and frozen_test_suite"
        )
        with patch(
            "harness.runner.score_acceptance", side_effect=tamper_error
        ), patch(
            "harness.runner.score_mutation",
            return_value=MutationResult(
                per_language={}, error=None, tool_name=None
            ),
        ):
            with pytest.raises(RuntimeError) as exc_info:
                score_workspace(workspace_dir=workspace, pack=pack)
        assert "shared inode" in str(exc_info.value), (
            f"AC-13 RuntimeError must propagate verbatim, not be wrapped or "
            f"swallowed; got: {exc_info.value!r}"
        )
