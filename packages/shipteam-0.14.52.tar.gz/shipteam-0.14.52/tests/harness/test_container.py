"""
Tests for harness/container.py.

Phase 1 (sanitize_git_repo, AC-13):
  T-12: Fresh git clone sanitization — refs/heads/* removed except current branch;
        .git/logs/ absent after sanitization.
  T-13: Seed repo with future-dated commits — post-sanitization git log shows
        zero commits dated after the task-pack creation date.
  Regression guard: SWE-Bench#465 git-log solution leak (pitfall #5).

Phase 5d (run_container_for_seed, AC-8 + AC-13 + AC-16):
  - AC-16 daemon endpoint preflight: tcp:///ssh:// refusal + override env.
  - AC-16 docker-info preflight: two-part operator-actionable RuntimeError
    (platform hints + captured stderr).
  - AC-8 workspace-path preflight: $HOME-rooted requirement (Colima default
    mount-set constraint, verified empirically 2026-04-27).
  - AC-13 docker-run security flags: --read-only / --cap-drop=ALL /
    -u 1000:1000 / --tmpfs /tmp:rw,noexec,nosuid + workspace:rw +
    frozen_tests:ro + injected_bugs:ro mounts. Asserted at the
    SUBPROCESS BOUNDARY (what the kernel sees), not on Python helper internals.
"""
import os
import subprocess
import textwrap
from datetime import date, datetime, timezone
from pathlib import Path

import pytest

from harness.container import sanitize_git_repo


# ---------------------------------------------------------------------------
# Git repo fixtures
# ---------------------------------------------------------------------------

def _git_cmd(repo: Path, *args: str, env: dict | None = None) -> subprocess.CompletedProcess:
    """Run a git command inside repo, raise on failure."""
    import os
    cmd_env = {**os.environ, "GIT_AUTHOR_NAME": "test", "GIT_AUTHOR_EMAIL": "test@test.com",
               "GIT_COMMITTER_NAME": "test", "GIT_COMMITTER_EMAIL": "test@test.com"}
    if env:
        cmd_env.update(env)
    return subprocess.run(
        ["git", "-C", str(repo), *args],
        check=True,
        capture_output=True,
        text=True,
        env=cmd_env,
    )


def _make_seed_repo(tmp_path: Path) -> Path:
    """
    Build a synthetic seed git repo with:
      (a) multiple local branches beyond the current one
      (b) reflog entries (created by switching branches)
      (c) a future-dated commit on a separate branch

    Returns the path to the seed repo.
    """
    seed = tmp_path / "seed_repo"
    seed.mkdir()

    # Init on 'main'
    _git_cmd(seed, "init", "-b", "main")
    (seed / "README.md").write_text("# url-shortener seed\n")
    _git_cmd(seed, "add", "README.md")
    _git_cmd(seed, "commit", "-m", "Initial commit")

    # Create a second branch ('feature/branch-b')
    _git_cmd(seed, "checkout", "-b", "feature/branch-b")
    (seed / "extra.txt").write_text("extra\n")
    _git_cmd(seed, "add", "extra.txt")
    _git_cmd(seed, "commit", "-m", "Extra feature")

    # Create a third branch ('feature/branch-c')
    _git_cmd(seed, "checkout", "-b", "feature/branch-c")
    (seed / "third.txt").write_text("third\n")
    _git_cmd(seed, "add", "third.txt")
    _git_cmd(seed, "commit", "-m", "Third feature")

    # Create a future-dated commit on a dedicated branch
    _git_cmd(seed, "checkout", "-b", "future/solution-leak")
    (seed / "solution.py").write_text("# this is the solution\n")
    _git_cmd(seed, "add", "solution.py")
    _git_cmd(
        seed, "commit", "-m", "Future solution (should be stripped)",
        env={
            "GIT_AUTHOR_DATE": "2030-01-01T00:00:00+00:00",
            "GIT_COMMITTER_DATE": "2030-01-01T00:00:00+00:00",
        },
    )

    # Return to main so the current branch is 'main'
    _git_cmd(seed, "checkout", "main")

    return seed


# ---------------------------------------------------------------------------
# T-12: Branch sanitization — only current branch refs remain
# ---------------------------------------------------------------------------

class TestGitSanitizationBranchRefs:
    """sanitize_git_repo — T-12: refs/heads/* stripped except current branch."""

    def test_non_current_branches_removed(self, tmp_path: Path) -> None:
        """
        Given a seed repo with branches: main, feature/branch-b, feature/branch-c,
              future/solution-leak; current branch is main,
        When sanitize_git_repo is called with pack_revision_date set to today,
        Then only the 'main' branch ref remains under .git/refs/heads/.
        """
        # Arrange
        seed = _make_seed_repo(tmp_path)
        pack_revision_date = date.today().isoformat()

        # Act
        sanitize_git_repo(repo=seed, pack_revision_date=pack_revision_date)

        # Assert: only 'main' (current branch) survives. Use
        # `git for-each-ref refs/heads/` rather than filesystem iteration —
        # gc may have packed remaining refs into .git/packed-refs, in which
        # case .git/refs/heads/ is empty on disk but the refs still exist.
        result = _git_cmd(seed, "for-each-ref", "--format=%(refname:short)", "refs/heads/")
        remaining = [b for b in result.stdout.splitlines() if b.strip()]
        assert remaining == ["main"], (
            f"Expected only 'main' to survive; got {remaining!r}"
        )

    def test_git_logs_directory_removed(self, tmp_path: Path) -> None:
        """
        Given a seed repo with reflog entries (from branch switching),
        When sanitize_git_repo is called,
        Then .git/logs/ is absent (or empty) after sanitization.
        """
        # Arrange
        seed = _make_seed_repo(tmp_path)
        logs_dir = seed / ".git" / "logs"
        # Confirm reflogs exist before sanitization
        assert logs_dir.exists(), ".git/logs/ should exist before sanitization"

        pack_revision_date = date.today().isoformat()

        # Act
        sanitize_git_repo(repo=seed, pack_revision_date=pack_revision_date)

        # Assert: logs directory is gone or empty
        if logs_dir.exists():
            all_log_files = list(logs_dir.rglob("*"))
            non_dir_files = [f for f in all_log_files if f.is_file()]
            assert non_dir_files == [], (
                f".git/logs/ should be empty after sanitization, found: {non_dir_files}"
            )


# ---------------------------------------------------------------------------
# T-13: Future-dated commit stripping
# ---------------------------------------------------------------------------

class TestGitSanitizationFutureDatedCommits:
    """sanitize_git_repo — T-13: future-dated commits stripped."""

    def test_future_dated_commits_absent_after_sanitization(self, tmp_path: Path) -> None:
        """
        Given a seed repo containing a future-dated commit on a side branch,
        When sanitize_git_repo is called with pack_revision_date = today,
        Then no commit with author-date > pack_revision_date is reachable
        from any remaining ref AND the stripped commit's object is unreachable
        via `git cat-file -e` after gc (not just de-referenced by branch deletion).

        Note: `git log --after=<date>` is unreliable with future-dated commits
        so we inspect `%ai` directly. `git log --all` alone does not prove
        object removal — it only walks reachable refs. We add a
        `git cat-file -e <sha>` check to catch the case where the object
        still exists as a dangling commit (SWE-Bench#465 pattern).
        """
        # Arrange
        seed = _make_seed_repo(tmp_path)
        pack_revision_date = date.today().isoformat()

        def _future_commits(repo: Path) -> list[str]:
            result = _git_cmd(repo, "log", "--all", "--format=%H %ai")
            future = []
            for line in result.stdout.splitlines():
                if not line.strip():
                    continue
                sha, ai = line.split(" ", 1)
                if ai[:10] > pack_revision_date:
                    future.append(sha)
            return future

        pre = _future_commits(seed)
        assert pre, "Fixture must contain a future-dated commit before sanitization"
        leaked_shas = list(pre)

        # Act
        sanitize_git_repo(repo=seed, pack_revision_date=pack_revision_date)

        # Assert 1: no future-dated commits reachable via any ref.
        post = _future_commits(seed)
        assert post == [], (
            f"Future-dated commits still reachable after sanitization: {post!r}"
        )

        # Assert 2: the specific commit objects are gone (gc pruned them).
        # `git cat-file -e <sha>` exits 0 if the object exists, non-zero otherwise.
        for sha in leaked_shas:
            probe = subprocess.run(
                ["git", "-C", str(seed), "cat-file", "-e", sha],
                capture_output=True, text=True, check=False,
            )
            assert probe.returncode != 0, (
                f"Commit {sha} still exists as a dangling object after gc; "
                f"ref pruning alone is not sufficient for AC-13."
            )

    def test_future_dated_commit_on_current_branch_is_stripped(self, tmp_path: Path) -> None:
        """
        Given a seed repo whose current branch HEAD has a future-dated commit,
        When sanitize_git_repo is called with pack_revision_date = today,
        Then HEAD rewinds past the future commit and the commit object is
        unreachable. This is the direct SWE-Bench#465 pattern: solution on
        main, not on a side branch. Ref deletion alone would not fix this;
        only pack_revision_date filtering on HEAD can.
        """
        # Arrange: build a minimal main-branch-only repo with a future commit on top.
        seed = tmp_path / "seed_head"
        seed.mkdir()
        _git_cmd(seed, "init", "-b", "main")
        (seed / "README.md").write_text("# base\n")
        _git_cmd(seed, "add", "README.md")
        _git_cmd(seed, "commit", "-m", "base")
        # Future commit on HEAD of main
        (seed / "solution.py").write_text("# solution\n")
        _git_cmd(seed, "add", "solution.py")
        future_env = {
            "GIT_AUTHOR_DATE": "2030-06-15T00:00:00+00:00",
            "GIT_COMMITTER_DATE": "2030-06-15T00:00:00+00:00",
        }
        _git_cmd(seed, "commit", "-m", "Future solution on main", env=future_env)

        future_sha = _git_cmd(seed, "rev-parse", "HEAD").stdout.strip()
        pack_revision_date = date.today().isoformat()

        # Act
        sanitize_git_repo(repo=seed, pack_revision_date=pack_revision_date)

        # Assert 1: HEAD is no longer the future commit.
        new_head = _git_cmd(seed, "rev-parse", "HEAD").stdout.strip()
        assert new_head != future_sha, (
            "sanitize_git_repo did not rewind HEAD past the future-dated commit"
        )

        # Assert 2: the future commit object is unreachable post-gc.
        probe = subprocess.run(
            ["git", "-C", str(seed), "cat-file", "-e", future_sha],
            capture_output=True, text=True, check=False,
        )
        assert probe.returncode != 0, (
            f"Future commit {future_sha} still exists as a dangling object; "
            f"AC-13 HEAD-filtering + gc contract violated."
        )

    def test_pack_revision_date_commits_not_stripped(self, tmp_path: Path) -> None:
        """
        Given a seed repo whose initial commit is dated before today,
        When sanitize_git_repo is called,
        Then normal (non-future-dated) commits on the main branch are preserved.
        """
        # Arrange
        seed = _make_seed_repo(tmp_path)
        pack_revision_date = date.today().isoformat()

        # Act
        sanitize_git_repo(repo=seed, pack_revision_date=pack_revision_date)

        # Assert: main branch still has at least its initial commit
        result = _git_cmd(seed, "log", "HEAD", "--oneline")
        assert result.stdout.strip() != "", (
            "Main branch commits should survive sanitization"
        )


# ---------------------------------------------------------------------------
# Phase 5d — run_container_for_seed: AC-8, AC-13, AC-16
#
# The contract is SECURITY-CRITICAL and was redesigned twice during the
# Phase 5d empirical-probe protocol (ADR-016) — see .sherlock-plan.md
# Pivot Log 2026-04-27 entries. The tests below lock the redesigned
# behaviour:
#
#   AC-16 Docker preflight: refuses if `docker info` fails OR resolved
#         daemon endpoint scheme is `tcp://` or `ssh://` (unless
#         SHIPTEAM_ALLOW_REMOTE_DOCKER=1). Two-part RuntimeError template
#         names the platform-specific remediation AND echoes captured
#         `docker info` stderr.
#
#   AC-8  workspace path host-mountability: workspace MUST be under $HOME.
#         /tmp/* and /var/folders/* refuse on macOS — Colima default mount
#         set is $HOME only; bind-mounts to /tmp/* silently produce empty
#         host directories post-`--rm` (verified empirically 2026-04-27).
#
#   AC-13 docker run security flags: --read-only, --cap-drop=ALL,
#         -u 1000:1000, --tmpfs /tmp:rw,noexec,nosuid,size=64m, plus
#         workspace:rw / frozen_tests:ro / injected_bugs:ro mounts.
#
# These tests intentionally couple to the SUBPROCESS BOUNDARY (`docker`
# argv) rather than to Python helper internals — the threat model is
# "what does the kernel see at exec()", not "what does Python think it
# wired up." The tests mock subprocess.run so docker never actually runs.
# ---------------------------------------------------------------------------

# Imports required only by the Phase 5d test classes; placed here so the
# Phase 1 sanitize_git_repo tests above are unaffected.
from unittest.mock import MagicMock, patch  # noqa: E402

from drivers._protocol import DriverResult  # noqa: E402
from task_packs.loader import TaskPack  # noqa: E402

# Pinned digest sentinel that matches _PINNED_IMAGE_RE (64 hex chars).
_TEST_PINNED_IMAGE = (
    "shipteam-url-shortener:test@sha256:"
    "0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef"
)


def _make_test_pack(pack_dir: Path) -> TaskPack:
    """Construct a minimal valid TaskPack rooted at pack_dir.

    The directories `frozen_tests/` and `injected_bugs/` are created so the
    container preflight can resolve them as bind-mount sources.
    """
    (pack_dir / "frozen_tests").mkdir(parents=True, exist_ok=True)
    (pack_dir / "injected_bugs").mkdir(parents=True, exist_ok=True)
    return TaskPack(
        name="url_shortener",
        container_image_pinned=_TEST_PINNED_IMAGE,
        entry_point="shortener.py",
        test_command="pytest tests/",
        stryker_config_path="stryker.conf.json",
        language="python",
        seed=42,
        pack_dir=pack_dir,
    )


def _make_test_driver_result() -> DriverResult:
    """Construct a successful DriverResult that satisfies _protocol invariants."""
    return DriverResult(
        wall_clock_ms=1000,
        input_tokens=100,
        output_tokens=50,
        cost_usd=0.01,
        cost_source="computed",
        aborted=False,
        abort_reason=None,
        cache_strategy="salted",
        driver_metadata={"cache_read_input_tokens": 0},
    )


def _make_test_driver(result: DriverResult | None = None) -> MagicMock:
    """Return a Driver mock that satisfies the structural Protocol."""
    driver = MagicMock()
    driver.name = "claude_code"
    driver.version.return_value = "0.1.0"
    driver.sdk_version.return_value = "0.1.68"
    driver.release_date.return_value = "2024-08-01"
    driver.prepare.return_value = None
    driver.execute.return_value = result or _make_test_driver_result()
    return driver


def _completed_proc(returncode: int = 0, stdout: str = "", stderr: str = "") -> MagicMock:
    """subprocess.CompletedProcess-shaped mock for subprocess.run patching."""
    proc = MagicMock()
    proc.returncode = returncode
    proc.stdout = stdout
    proc.stderr = stderr
    return proc


def _docker_subprocess_dispatcher(
    *,
    endpoint: str = "unix:///var/run/docker.sock",
    docker_info_returncode: int = 0,
    docker_info_stderr: str = "",
):
    """
    Build a side_effect callable for subprocess.run that simulates a healthy
    docker daemon. Routes by the first argv token + first subcommand:

      - `docker context inspect ...` → endpoint stdout
      - `docker info`                 → exit code / stderr per kwargs
      - any other `docker ...`        → success
      - anything else                 → success (e.g., driver internal calls)

    Returning a non-default endpoint OR a non-zero docker info simulates
    the AC-16 failure modes.
    """
    def _side_effect(argv, *args, **kwargs):
        # Tolerate both list-form (preferred) and string-form invocations.
        if isinstance(argv, str):
            tokens = argv.split()
        else:
            tokens = list(argv)
        if not tokens:
            return _completed_proc()
        head = tokens[0]
        if head == "docker" and len(tokens) >= 2:
            sub = tokens[1]
            if sub == "context":
                return _completed_proc(stdout=endpoint + "\n")
            if sub == "info":
                return _completed_proc(
                    returncode=docker_info_returncode,
                    stderr=docker_info_stderr,
                )
            if sub == "run":
                # `docker run` invocations are inspected by tests via the
                # mock's call_args_list — we just need to return a
                # CompletedProcess shape so the caller proceeds.
                return _completed_proc()
        # Anything else (including non-docker subprocess.run calls — git,
        # python, etc.) is unexpected from the harness/container.py code path.
        # Returning a default success here would mask a regression where
        # container.py started shelling out to something we don't expect.
        pytest.fail(
            f"_docker_subprocess_dispatcher: unexpected subprocess.run "
            f"argv={tokens!r}; if this is a new code path, add an explicit "
            f"branch above."
        )

    return _side_effect


# Resolve $HOME once for all path-preflight tests; tmp_path under pytest
# lives under TMPDIR which is /var/folders/... on macOS — explicitly NOT
# under $HOME, which is exactly the AC-8 refusal case. To exercise the
# "allowed" path we synthesize a path under the real $HOME.


def _path_under_home(subdir: str) -> Path:
    """Synthesize a path under $HOME for AC-8 'allowed' tests.

    Returns a directory under ~/.cache/shipteam-test-workspaces/ that is
    created on demand. Callers are responsible for cleanup via the
    `_clean_path_under_home` fixture which scopes the parent to the test
    session — this avoids ~/.cache pollution across test runs (forensics
    Phase 5d HIGH-3).
    """
    home = Path.home()
    target = home / ".cache" / "shipteam-test-workspaces" / subdir
    target.mkdir(parents=True, exist_ok=True)
    return target


@pytest.fixture(autouse=True, scope="session")
def _clean_path_under_home():
    """Wipe the ~/.cache/shipteam-test-workspaces tree at session end.

    Per-test cleanup would race with parallel pytest workers (xdist). Session
    scope is the lowest-friction guarantee that we don't leave stale state
    behind across runs. The session is also when the user is most likely to
    notice if something is wrong.
    """
    yield
    workspaces_root = Path.home() / ".cache" / "shipteam-test-workspaces"
    if workspaces_root.exists():
        import shutil
        shutil.rmtree(workspaces_root, ignore_errors=True)


# ---------------------------------------------------------------------------
# AC-16: Daemon endpoint preflight (R15/R17 — Phase 5d empirical-probe redesign)
# ---------------------------------------------------------------------------


class TestRunContainerForSeedDaemonEndpoint:
    """
    AC-16 endpoint scheme: refuse `tcp://` and `ssh://` daemon endpoints
    (bind-mounts resolve on the daemon's host, not the client's — silent
    empty-workspace failure mode). Allow `unix://` variants (Colima,
    rootless, podman emulation, default Docker socket) without override.
    Override gate: SHIPTEAM_ALLOW_REMOTE_DOCKER=1.
    """

    def test_unix_socket_endpoint_allowed(self, tmp_path: Path) -> None:
        """unix:// endpoints (default, Colima, rootless) pass preflight.

        Positive assertion: under Option A (inline run-and-done), passing
        preflight means the implementation reaches the `docker run` call.
        Verified via the mock's call_args_list — without this, the test
        was vacuous (any RuntimeError that didn't match "remote"/"endpoint"
        in the lowercase message would pass).
        """
        from harness.container import run_container_for_seed

        pack = _make_test_pack(tmp_path / "pack")
        workspace = _path_under_home("test_unix_endpoint")
        driver = _make_test_driver()

        with patch(
            "harness.container.subprocess.run",
            side_effect=_docker_subprocess_dispatcher(
                endpoint="unix:///var/run/docker.sock"
            ),
        ) as mock_run:
            result = run_container_for_seed(
                driver=driver,
                task="url_shortener",
                seed=42,
                budget_usd=2.0,
                max_wall_clock_minutes=30,
                container_image=_TEST_PINNED_IMAGE,
                pack=pack,
                workspace_dir=workspace,
            )

        assert _captured_docker_run_argv(mock_run) is not None, (
            "Preflight must permit unix:// endpoints (passing preflight = "
            "reaching the docker run subprocess call)."
        )
        # Phase 5d placeholder: result.json doesn't exist, so the host-side
        # parser returns an aborted-row tombstone. That is the EXPECTED
        # behaviour pre-Phase-5e; the test asserts the lifecycle reached
        # the parse step at all.
        assert result.aborted is True
        assert result.abort_reason is not None
        assert result.abort_reason.category == "driver_error"

    def test_tcp_endpoint_refused(self, tmp_path: Path) -> None:
        """tcp:// endpoint raises RuntimeError naming the resolved endpoint."""
        from harness.container import run_container_for_seed

        pack = _make_test_pack(tmp_path / "pack")
        workspace = _path_under_home("test_tcp_endpoint")
        driver = _make_test_driver()
        bad_endpoint = "tcp://attacker.example.com:2375"

        with patch(
            "harness.container.subprocess.run",
            side_effect=_docker_subprocess_dispatcher(endpoint=bad_endpoint),
        ):
            with pytest.raises(RuntimeError) as exc_info:
                run_container_for_seed(
                    driver=driver,
                    task="url_shortener",
                    seed=42,
                    budget_usd=2.0,
                    max_wall_clock_minutes=30,
                    container_image=_TEST_PINNED_IMAGE,
                    pack=pack,
                    workspace_dir=workspace,
                )
        msg = str(exc_info.value)
        assert "tcp://attacker.example.com:2375" in msg, (
            f"AC-16 RuntimeError must echo the resolved endpoint URI for "
            f"operator triage; got: {msg!r}"
        )
        assert "SHIPTEAM_ALLOW_REMOTE_DOCKER" in msg, (
            "AC-16 RuntimeError must name the override env var so the "
            "operator can opt in if intentional."
        )

    def test_ssh_endpoint_refused(self, tmp_path: Path) -> None:
        """ssh:// endpoint raises — same threat model as tcp://."""
        from harness.container import run_container_for_seed

        pack = _make_test_pack(tmp_path / "pack")
        workspace = _path_under_home("test_ssh_endpoint")
        driver = _make_test_driver()

        with patch(
            "harness.container.subprocess.run",
            side_effect=_docker_subprocess_dispatcher(
                endpoint="ssh://user@remote-host"
            ),
        ):
            with pytest.raises(RuntimeError) as exc_info:
                run_container_for_seed(
                    driver=driver,
                    task="url_shortener",
                    seed=42,
                    budget_usd=2.0,
                    max_wall_clock_minutes=30,
                    container_image=_TEST_PINNED_IMAGE,
                    pack=pack,
                    workspace_dir=workspace,
                )
        assert "ssh://" in str(exc_info.value)

    def test_remote_endpoint_allowed_with_override_env(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """SHIPTEAM_ALLOW_REMOTE_DOCKER=1 lets tcp:// pass preflight."""
        from harness.container import run_container_for_seed

        monkeypatch.setenv("SHIPTEAM_ALLOW_REMOTE_DOCKER", "1")
        pack = _make_test_pack(tmp_path / "pack")
        workspace = _path_under_home("test_override_env")
        driver = _make_test_driver()

        with patch(
            "harness.container.subprocess.run",
            side_effect=_docker_subprocess_dispatcher(
                endpoint="tcp://remote.example.com:2375"
            ),
        ):
            try:
                run_container_for_seed(
                    driver=driver,
                    task="url_shortener",
                    seed=42,
                    budget_usd=2.0,
                    max_wall_clock_minutes=30,
                    container_image=_TEST_PINNED_IMAGE,
                    pack=pack,
                    workspace_dir=workspace,
                )
            except RuntimeError as exc:
                # Anything raised must NOT be the endpoint refusal; if
                # downstream stages raise, that's a separate failure
                # outside the scope of this preflight test.
                assert "SHIPTEAM_ALLOW_REMOTE_DOCKER" not in str(exc), (
                    f"override env should suppress the AC-16 endpoint "
                    f"refusal; got: {exc!r}"
                )


# ---------------------------------------------------------------------------
# AC-16: docker info preflight (R17 two-part error template)
# ---------------------------------------------------------------------------


class TestRunContainerForSeedDockerInfoPreflight:
    """
    AC-16 R17: when `docker info` fails, RuntimeError must be operator-actionable.
    Two-part template: platform-specific remediation hints + captured stderr.
    Without both, the operator has to web-search "is docker running" — exactly
    the failure mode R17 was added to close.
    """

    def test_docker_info_failure_raises_runtime_error(self, tmp_path: Path) -> None:
        from harness.container import run_container_for_seed

        pack = _make_test_pack(tmp_path / "pack")
        workspace = _path_under_home("test_docker_info_fail")
        driver = _make_test_driver()

        with patch(
            "harness.container.subprocess.run",
            side_effect=_docker_subprocess_dispatcher(
                docker_info_returncode=1,
                docker_info_stderr="Cannot connect to the Docker daemon at unix:///var/run/docker.sock. Is the docker daemon running?",
            ),
        ):
            with pytest.raises(RuntimeError):
                run_container_for_seed(
                    driver=driver,
                    task="url_shortener",
                    seed=42,
                    budget_usd=2.0,
                    max_wall_clock_minutes=30,
                    container_image=_TEST_PINNED_IMAGE,
                    pack=pack,
                    workspace_dir=workspace,
                )

    def test_docker_info_error_message_contains_platform_hints(
        self, tmp_path: Path
    ) -> None:
        """R17: error message names macOS Docker Desktop, Colima, AND Linux."""
        from harness.container import run_container_for_seed

        pack = _make_test_pack(tmp_path / "pack")
        workspace = _path_under_home("test_docker_info_hints")
        driver = _make_test_driver()

        with patch(
            "harness.container.subprocess.run",
            side_effect=_docker_subprocess_dispatcher(
                docker_info_returncode=1,
                docker_info_stderr="Cannot connect to the Docker daemon",
            ),
        ):
            with pytest.raises(RuntimeError) as exc_info:
                run_container_for_seed(
                    driver=driver,
                    task="url_shortener",
                    seed=42,
                    budget_usd=2.0,
                    max_wall_clock_minutes=30,
                    container_image=_TEST_PINNED_IMAGE,
                    pack=pack,
                    workspace_dir=workspace,
                )
        msg = str(exc_info.value)
        assert "Docker Desktop" in msg, "R17: macOS Docker Desktop hint required"
        assert "colima start" in msg, "R17: macOS Colima hint required"
        assert "systemctl start docker" in msg, "R17: Linux hint required"

    def test_docker_info_error_message_includes_underlying_stderr(
        self, tmp_path: Path
    ) -> None:
        """R17 second part: captured `docker info` stderr verbatim."""
        from harness.container import run_container_for_seed

        pack = _make_test_pack(tmp_path / "pack")
        workspace = _path_under_home("test_docker_info_stderr")
        driver = _make_test_driver()
        captured_stderr = "Cannot connect to the Docker daemon at unix:///var/run/docker.sock"

        with patch(
            "harness.container.subprocess.run",
            side_effect=_docker_subprocess_dispatcher(
                docker_info_returncode=1,
                docker_info_stderr=captured_stderr,
            ),
        ):
            with pytest.raises(RuntimeError) as exc_info:
                run_container_for_seed(
                    driver=driver,
                    task="url_shortener",
                    seed=42,
                    budget_usd=2.0,
                    max_wall_clock_minutes=30,
                    container_image=_TEST_PINNED_IMAGE,
                    pack=pack,
                    workspace_dir=workspace,
                )
        assert captured_stderr in str(exc_info.value), (
            "R17: captured docker info stderr must appear verbatim in the "
            "RuntimeError so operator sees the underlying daemon failure."
        )


# ---------------------------------------------------------------------------
# AC-8: Workspace path host-mountability constraint
# (Phase 5d empirical-probe finding — Colima default mount set is $HOME only)
# ---------------------------------------------------------------------------


class TestRunContainerForSeedWorkspacePathConstraint:
    """
    AC-8 workspace-path constraint: workspace MUST resolve under $HOME on
    macOS. /tmp/* and /var/folders/* (the macOS tempdir prefix that
    `tempfile.mkdtemp()` defaults to) are refused — Colima's default
    mount set excludes them, so the bind mount becomes a phantom: container
    sees writes, host sees an empty directory after `--rm`. Verified
    empirically 2026-04-27.

    The check is path-only (does not require docker daemon). Tests do not
    need to mock subprocess.run beyond the pre-flight ordering.
    """

    def test_workspace_under_tmp_refused(self, tmp_path: Path) -> None:
        from harness.container import run_container_for_seed

        pack = _make_test_pack(tmp_path / "pack")
        bad_workspace = Path("/tmp/shipteam-test-workspace-bad")
        bad_workspace.mkdir(exist_ok=True)
        driver = _make_test_driver()

        with patch(
            "harness.container.subprocess.run",
            side_effect=_docker_subprocess_dispatcher(),
        ):
            with pytest.raises(RuntimeError) as exc_info:
                run_container_for_seed(
                    driver=driver,
                    task="url_shortener",
                    seed=42,
                    budget_usd=2.0,
                    max_wall_clock_minutes=30,
                    container_image=_TEST_PINNED_IMAGE,
                    pack=pack,
                    workspace_dir=bad_workspace,
                )
        msg = str(exc_info.value)
        assert "$HOME" in msg or "HOME" in msg, (
            f"AC-8 RuntimeError must name the $HOME constraint so operator "
            f"knows the remediation; got: {msg!r}"
        )

    def test_workspace_under_var_folders_refused(self, tmp_path: Path) -> None:
        """tmp_path under pytest is /var/folders/... on macOS — exactly the
        case where `tempfile.mkdtemp()` would silently produce a phantom
        mount under Colima."""
        from harness.container import run_container_for_seed

        pack = _make_test_pack(tmp_path / "pack")
        # tmp_path itself is under /var/folders/... on macOS or /tmp on Linux.
        # On Linux this test is still meaningful: the constraint is that the
        # workspace must be under $HOME for portability across Colima/Docker
        # Desktop/rootless docker, regardless of host OS.
        driver = _make_test_driver()

        # Workspace under tmp_path is what would happen if a Phase 5g test
        # used tempfile.mkdtemp() without dir= — exactly the failure mode.
        bad_workspace = tmp_path / "ws_under_tmp"
        bad_workspace.mkdir()
        home = Path(os.path.expanduser("~")).resolve()
        if home in bad_workspace.resolve().parents or bad_workspace.resolve() == home:
            pytest.skip("tmp_path resolves under $HOME on this platform")

        with patch(
            "harness.container.subprocess.run",
            side_effect=_docker_subprocess_dispatcher(),
        ):
            with pytest.raises(RuntimeError):
                run_container_for_seed(
                    driver=driver,
                    task="url_shortener",
                    seed=42,
                    budget_usd=2.0,
                    max_wall_clock_minutes=30,
                    container_image=_TEST_PINNED_IMAGE,
                    pack=pack,
                    workspace_dir=bad_workspace,
                )

    def test_workspace_under_home_passes_path_preflight(self, tmp_path: Path) -> None:
        """Positive case: workspace under ~/.cache/... satisfies AC-8."""
        from harness.container import run_container_for_seed

        pack = _make_test_pack(tmp_path / "pack")
        workspace = _path_under_home("test_home_passes")
        driver = _make_test_driver()

        with patch(
            "harness.container.subprocess.run",
            side_effect=_docker_subprocess_dispatcher(),
        ):
            try:
                run_container_for_seed(
                    driver=driver,
                    task="url_shortener",
                    seed=42,
                    budget_usd=2.0,
                    max_wall_clock_minutes=30,
                    container_image=_TEST_PINNED_IMAGE,
                    pack=pack,
                    workspace_dir=workspace,
                )
            except RuntimeError as exc:
                # If anything raises, the AC-8 path message must not be the
                # cause. Other failures are out of scope for this preflight.
                assert "HOME" not in str(exc), (
                    f"workspace under $HOME must pass path preflight; got: {exc!r}"
                )


# ---------------------------------------------------------------------------
# AC-13: docker run security flags (capabilities, read-only FS, mounts)
# ---------------------------------------------------------------------------


def _captured_docker_run_argv(mock_subprocess_run) -> list[str] | None:
    """Find the `docker run` argv in a captured subprocess.run call list.

    Returns the first argv that starts with `["docker", "run", ...]`, or
    None if no such call was made (which itself is a failure for AC-13
    tests — without a docker run call, the security flags can't exist).
    """
    for call in mock_subprocess_run.call_args_list:
        argv = call.args[0] if call.args else call.kwargs.get("args")
        if isinstance(argv, str):
            tokens = argv.split()
        else:
            tokens = list(argv) if argv else []
        if len(tokens) >= 2 and tokens[0] == "docker" and tokens[1] == "run":
            return tokens
    return None


class TestRunContainerForSeedSecurityFlags:
    """
    AC-13 security flags MUST appear in the `docker run` argv. Each flag is
    its own test — partial implementations (drops 3 of 4 flags) must fail
    visibly. The flags assert at the SUBPROCESS BOUNDARY (what the kernel
    sees), not on Python helper internals.

    --read-only          → root FS is RO; SUT cannot mutate / outside mounts
    --cap-drop=ALL       → CapEff/CapBnd = 0 (verified empirically 2026-04-27)
    -u 1000:1000         → non-root SUT, host files appear as $USER:staff via
                           Lima/virtiofs uid mapping
    --tmpfs /tmp:rw,noexec,nosuid,size=64m
                         → SUT has writable /tmp but cannot exec from it
    """

    def _run_with_capture(
        self, tmp_path: Path
    ) -> tuple[list[str] | None, MagicMock]:
        """Helper: invoke run_container_for_seed and return captured argv."""
        from harness.container import run_container_for_seed

        pack = _make_test_pack(tmp_path / "pack")
        workspace = _path_under_home(f"test_flags_{tmp_path.name}")
        driver = _make_test_driver()

        # Build a side_effect that records every subprocess.run call.
        all_calls: list[list[str]] = []
        base_dispatcher = _docker_subprocess_dispatcher()

        def _record_and_dispatch(argv, *args, **kwargs):
            tokens = argv.split() if isinstance(argv, str) else list(argv)
            all_calls.append(tokens)
            return base_dispatcher(argv, *args, **kwargs)

        # Wipe any stale `.shipteam/result.json` left over from a prior test
        # session that crashed before the autouse session-cleanup fired.
        # Without this, _parse_container_result would read the stale file and
        # potentially raise — masking which test actually failed.
        stale_result = workspace / ".shipteam" / "result.json"
        if stale_result.exists():
            stale_result.unlink()

        with patch(
            "harness.container.subprocess.run",
            side_effect=_record_and_dispatch,
        ) as mock_run:
            # Under Option A, run_container_for_seed must NOT raise after
            # preflight passes — the placeholder branch returns a tombstone
            # DriverResult. A bare `except Exception` here would mask any
            # preflight surprise (e.g., a path-resolution edge case raising
            # RuntimeError from _check_workspace_under_home) and report the
            # test as "docker run not invoked" with no signal as to why.
            run_container_for_seed(
                driver=driver,
                task="url_shortener",
                seed=42,
                budget_usd=2.0,
                max_wall_clock_minutes=30,
                container_image=_TEST_PINNED_IMAGE,
                pack=pack,
                workspace_dir=workspace,
            )

        argv = _captured_docker_run_argv(mock_run)
        return argv, mock_run

    def test_docker_run_invoked(self, tmp_path: Path) -> None:
        """Sanity: a `docker run` invocation must occur after preflight passes."""
        argv, _ = self._run_with_capture(tmp_path)
        assert argv is not None, (
            "Expected `docker run` to be invoked via subprocess.run after "
            "preflight passed; no such call was captured. Either preflight "
            "wrongly raised, or implementation routes docker through a "
            "non-subprocess path (which AC-13 tests cannot verify)."
        )

    def test_docker_run_includes_read_only(self, tmp_path: Path) -> None:
        argv, _ = self._run_with_capture(tmp_path)
        assert argv is not None, "docker run not invoked — see test_docker_run_invoked"
        assert "--read-only" in argv, (
            f"AC-13: --read-only required to prevent SUT from mutating "
            f"the container root FS; argv={argv!r}"
        )

    def test_docker_run_includes_cap_drop_all(self, tmp_path: Path) -> None:
        argv, _ = self._run_with_capture(tmp_path)
        assert argv is not None, "docker run not invoked"
        # Canonical uppercase form only. Accepting "all" lowercase makes the
        # test pass even if a future edit drifted the implementation away
        # from the documented Docker convention. Either `--cap-drop=ALL`
        # (combined) or `--cap-drop ALL` (separated) is fine — both are
        # what `docker run` documents — but case is fixed.
        joined = " ".join(argv)
        assert (
            "--cap-drop=ALL" in argv
            or "--cap-drop ALL" in joined
        ), f"AC-13 R13: --cap-drop=ALL required (CapEff=0); argv={argv!r}"

    def test_docker_run_includes_non_root_uid(self, tmp_path: Path) -> None:
        argv, _ = self._run_with_capture(tmp_path)
        assert argv is not None, "docker run not invoked"
        joined = " ".join(argv)
        assert (
            "-u" in argv and "1000:1000" in argv
        ) or "-u 1000:1000" in joined or "--user 1000:1000" in joined or (
            "--user" in argv and "1000:1000" in argv
        ), f"AC-13: -u 1000:1000 required (non-root SUT); argv={argv!r}"

    def test_docker_run_includes_tmpfs_with_security_flags(
        self, tmp_path: Path
    ) -> None:
        """tmpfs /tmp must include noexec AND nosuid (defense-in-depth)."""
        argv, _ = self._run_with_capture(tmp_path)
        assert argv is not None, "docker run not invoked"
        joined = " ".join(argv)
        # Find the --tmpfs argument value.
        tmpfs_value = None
        for i, tok in enumerate(argv):
            if tok == "--tmpfs" and i + 1 < len(argv):
                tmpfs_value = argv[i + 1]
                break
            if tok.startswith("--tmpfs="):
                tmpfs_value = tok.split("=", 1)[1]
                break
        assert tmpfs_value is not None, (
            f"AC-13: --tmpfs /tmp:... required; argv={argv!r}"
        )
        assert "/tmp" in tmpfs_value, f"--tmpfs must target /tmp; got {tmpfs_value!r}"
        assert "noexec" in tmpfs_value, (
            f"AC-13: --tmpfs must include noexec (block exec from /tmp); "
            f"got {tmpfs_value!r}"
        )
        assert "nosuid" in tmpfs_value, (
            f"AC-13: --tmpfs must include nosuid (block setuid binaries); "
            f"got {tmpfs_value!r}"
        )

    def test_workspace_mounted_rw(self, tmp_path: Path) -> None:
        """Workspace bind mount must be writable for SUT to record progress."""
        argv, _ = self._run_with_capture(tmp_path)
        assert argv is not None, "docker run not invoked"
        joined = " ".join(argv)
        # Accept --volume host:/workspace:rw or --volume host:/workspace
        # (rw is docker's default for bind mounts), but reject :ro on /workspace.
        workspace_mount = [
            tok for tok in argv if "/workspace" in tok and ":" in tok
        ]
        assert workspace_mount, (
            f"AC-8: workspace bind mount to /workspace required; argv={argv!r}"
        )
        for mount in workspace_mount:
            assert ":ro" not in mount, (
                f"AC-8: /workspace must NOT be read-only; got {mount!r}"
            )

    def test_frozen_tests_mounted_ro(self, tmp_path: Path) -> None:
        """frozen_tests bind mount MUST be read-only — AC-13 boundary."""
        argv, _ = self._run_with_capture(tmp_path)
        assert argv is not None, "docker run not invoked"
        frozen_mount = [tok for tok in argv if "/frozen_tests" in tok and ":" in tok]
        assert frozen_mount, (
            f"AC-13: frozen_tests bind mount to /frozen_tests required; "
            f"argv={argv!r}"
        )
        for mount in frozen_mount:
            assert ":ro" in mount, (
                f"AC-13 (security boundary): /frozen_tests MUST be read-only "
                f"to prevent driver workspace from tampering with the test "
                f"oracle; got {mount!r}"
            )

    def test_injected_bugs_mounted_ro(self, tmp_path: Path) -> None:
        """injected_bugs bind mount MUST be read-only — AC-13 boundary."""
        argv, _ = self._run_with_capture(tmp_path)
        assert argv is not None, "docker run not invoked"
        bugs_mount = [tok for tok in argv if "/injected_bugs" in tok and ":" in tok]
        assert bugs_mount, (
            f"AC-13: injected_bugs bind mount to /injected_bugs required; "
            f"argv={argv!r}"
        )
        for mount in bugs_mount:
            assert ":ro" in mount, (
                f"AC-13: /injected_bugs MUST be read-only; got {mount!r}"
            )

    def test_pinned_image_used(self, tmp_path: Path) -> None:
        """The container_image pinned digest must appear in the docker run argv."""
        argv, _ = self._run_with_capture(tmp_path)
        assert argv is not None, "docker run not invoked"
        assert _TEST_PINNED_IMAGE in argv, (
            f"docker run argv must reference the pinned container_image "
            f"verbatim ({_TEST_PINNED_IMAGE!r}); argv={argv!r}"
        )


# ---------------------------------------------------------------------------
# Option A: container result handoff (`_parse_container_result` + timeout)
# ---------------------------------------------------------------------------


class TestParseContainerResult:
    """Direct unit tests for the result.json → DriverResult lift.

    Phase 5d's `run_container_for_seed` only ever exercises the absent-file
    branch (no test writes a result.json). The present-file branch is live
    code today: a malformed result.json from a Phase 5e per-driver runner
    would otherwise produce a silent tombstone in `run_cell`'s except clause
    with no visible signal as to which key was missing. These tests pin the
    schema contract so a Phase 5e runner that drifts from it fails loudly.
    """

    def test_parse_present_result_minimal_success(self, tmp_path: Path) -> None:
        """A flat dict with required DriverResult fields parses cleanly."""
        from harness.container import RESULT_RELATIVE_PATH, _parse_container_result

        workspace = tmp_path / "ws"
        result_path = workspace / RESULT_RELATIVE_PATH
        result_path.parent.mkdir(parents=True)
        result_path.write_text(
            '{'
            '"wall_clock_ms": 12345, '
            '"input_tokens": 100, '
            '"output_tokens": 50, '
            '"cost_usd": 0.0123, '
            '"cost_source": "native", '
            '"aborted": false, '
            '"abort_reason": null, '
            '"cache_strategy": "salted", '
            '"driver_metadata": {"cache_read_input_tokens": 0}'
            '}'
        )

        result = _parse_container_result(
            workspace_dir=workspace, returncode=0, stderr=""
        )

        assert result.wall_clock_ms == 12345
        assert result.input_tokens == 100
        assert result.output_tokens == 50
        assert result.cost_usd == 0.0123
        assert result.cost_source == "native"
        assert result.aborted is False
        assert result.abort_reason is None
        assert result.cache_strategy == "salted"
        assert result.driver_metadata["cache_read_input_tokens"] == 0

    def test_parse_present_result_with_abort_reason(self, tmp_path: Path) -> None:
        """abort_reason sub-dict lifts into AbortReason dataclass."""
        from harness.container import RESULT_RELATIVE_PATH, _parse_container_result

        workspace = tmp_path / "ws"
        result_path = workspace / RESULT_RELATIVE_PATH
        result_path.parent.mkdir(parents=True)
        result_path.write_text(
            '{'
            '"wall_clock_ms": 5000, '
            '"input_tokens": null, '
            '"output_tokens": null, '
            '"cost_usd": null, '
            '"cost_source": "computed", '
            '"aborted": true, '
            '"abort_reason": {"category": "budget_exceeded", "detail": "ran out at 80%"}, '
            '"cache_strategy": "salted", '
            '"driver_metadata": {}'
            '}'
        )

        result = _parse_container_result(
            workspace_dir=workspace, returncode=124, stderr="some stderr"
        )

        assert result.aborted is True
        assert result.abort_reason is not None
        assert result.abort_reason.category == "budget_exceeded"
        assert result.abort_reason.detail == "ran out at 80%"

    def test_parse_absent_result_returns_tombstone(self, tmp_path: Path) -> None:
        """Absent result.json produces the placeholder driver_error tombstone."""
        from harness.container import _parse_container_result

        workspace = tmp_path / "ws"
        workspace.mkdir()  # exists but no .shipteam/result.json inside

        result = _parse_container_result(
            workspace_dir=workspace,
            returncode=42,
            stderr="some long stderr output that will get truncated",
        )

        assert result.aborted is True
        assert result.abort_reason is not None
        assert result.abort_reason.category == "driver_error"
        # The returncode and stderr head must appear in the detail string so
        # operator triage from the JSONL row alone reveals what went wrong.
        assert "returncode=42" in result.abort_reason.detail
        assert "some long stderr" in result.abort_reason.detail


class TestRunContainerForSeedTimeout:
    """`subprocess.TimeoutExpired` ⇒ wall_clock_exceeded tombstone.

    The host-side timeout is `max_wall_clock_minutes * 60 + grace`. A future
    edit that accidentally swaps the unit (passes seconds vs ms, or drops
    the grace) would silently fire timeouts at a different threshold. Pin
    both the abort category and the wall_clock_ms reporting.
    """

    def test_subprocess_timeout_expired_returns_tombstone(self, tmp_path: Path) -> None:
        from harness.container import run_container_for_seed

        pack = _make_test_pack(tmp_path / "pack")
        workspace = _path_under_home("test_timeout")
        driver = _make_test_driver()

        # The dispatcher must succeed for endpoint + info preflight, then
        # raise TimeoutExpired for the `docker run` call. Route by argv head.
        def _dispatcher(argv, *args, **kwargs):
            tokens = argv if isinstance(argv, list) else list(argv)
            if len(tokens) >= 2 and tokens[0] == "docker" and tokens[1] == "run":
                raise subprocess.TimeoutExpired(cmd=tokens, timeout=kwargs.get("timeout", 0))
            # Reuse the standard healthy-daemon dispatcher for other calls.
            return _docker_subprocess_dispatcher()(argv, *args, **kwargs)

        with patch("harness.container.subprocess.run", side_effect=_dispatcher):
            result = run_container_for_seed(
                driver=driver,
                task="url_shortener",
                seed=42,
                budget_usd=2.0,
                max_wall_clock_minutes=2,  # 2 min × 60 = 120s + 30s grace = 150s
                container_image=_TEST_PINNED_IMAGE,
                pack=pack,
                workspace_dir=workspace,
            )

        assert result.aborted is True
        assert result.abort_reason is not None
        assert result.abort_reason.category == "wall_clock_exceeded"
        # 2 min × 60 + 30s grace = 150s = 150_000 ms. Pin the unit so a
        # future edit that drops the *1000 conversion fails loudly.
        assert result.wall_clock_ms == 150_000
        assert "150" in result.abort_reason.detail
