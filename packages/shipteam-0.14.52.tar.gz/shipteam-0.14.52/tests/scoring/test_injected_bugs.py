"""
Tests for scoring/injected_bugs.py — T-14, T-23, T-43, T-44, T-45, T-46, AC-17
(AC-2, AC-9, AC-16, AC-17)

Covers:
  T-14 (P0): score_injected_bugs correlates test-results against corpus;
             InjectedBugResult.detections == D; sidecar JSONL has N entries, D with detected=True.
  T-23 (P0): validate_corpus is the AC-9 sweep-start gate; raises CorpusError when B<20.
             Per Q1a (clarifying answer), the gate is caller-invoked (by the runner at
             sweep start) — NOT called inside score_injected_bugs. Tests invoke
             validate_corpus directly.
  T-43 (P1): load_corpus with schema_version=1 and valid entries returns populated Corpus.
  T-44 (P1): load_corpus with schema_version=2 raises CorpusSchemaError mentioning expected=1, actual=2.
  T-45 (P1): per-bug entry with unknown metadata key loads successfully (forward-compat).
  T-46 (P0): patch_file "../../../etc/passwd" raises CorpusSecurityError with bug_id +
             attempted_path in message. Symlink inside corpus pointing outside raises same error.
  AC-17 (P1): score_injected_bugs fail-closed on missing/malformed test_results.json —
              returns InjectedBugResult.error set, does NOT raise.

test_results.json contract (T-14 design decision):
  score_injected_bugs reads `output_dir / "test_results.json"` written by the caller (harness).
  Shape: {"failed_tests": ["test_id_a", "test_id_b", ...]}
  The scorer correlates corpus[i].detectable_by against failed_tests:
    detected=True  iff  any(t in failed_tests for t in bug.detectable_by)
  This is a correlation-only scorer — it does NOT apply patches or run tests itself.
  The frozen_test_suite parameter is reserved for future use (scorer reads pre-computed results).
"""

import json
import os
import textwrap
from pathlib import Path

import pytest
import yaml

from scoring.injected_bugs import (
    Corpus,
    CorpusError,
    CorpusSchemaError,
    CorpusSecurityError,
    InjectedBugEntry,
    InjectedBugResult,
    load_corpus,
    score_injected_bugs,
    validate_corpus,
)


# ---------------------------------------------------------------------------
# Fixture helpers
# ---------------------------------------------------------------------------

def _write_corpus(
    corpus_path: Path,
    bugs: list[dict],
    schema_version: int = 1,
) -> None:
    """Write a minimal corpus directory with manifest.yaml and stub patch files."""
    corpus_path.mkdir(parents=True, exist_ok=True)
    patches_dir = corpus_path / "patches"
    patches_dir.mkdir(exist_ok=True)
    manifest = {"schema_version": schema_version, "bugs": bugs}
    (corpus_path / "manifest.yaml").write_text(yaml.dump(manifest))
    for bug in bugs:
        patch_rel = bug.get("patch_file", f"patches/{bug['bug_id']}.patch")
        # Only create stubs for relative paths that don't escape corpus (for non-security tests)
        if not patch_rel.startswith(".."):
            patch_target = corpus_path / patch_rel
            patch_target.parent.mkdir(parents=True, exist_ok=True)
            if not patch_target.is_symlink() and not patch_target.exists():
                patch_target.write_text(
                    textwrap.dedent(f"""\
                        --- a/src/module.py
                        +++ b/src/module.py
                        @@ -1 +1 @@
                        -# bug: {bug['bug_id']}
                        +# fixed
                    """)
                )


def _make_bug(
    bug_id: str,
    detectable_by: list[str],
    *,
    severity: str = "medium",
    patch_file: str | None = None,
    extra: dict | None = None,
) -> dict:
    entry: dict = {
        "bug_id": bug_id,
        "description": f"Injected bug {bug_id}",
        "patch_file": patch_file if patch_file is not None else f"patches/{bug_id}.patch",
        "detectable_by": detectable_by,
        "severity": severity,
    }
    if extra:
        entry.update(extra)
    return entry


def _make_test_results(output_dir: Path, failed_tests: list[str]) -> Path:
    """Write the test_results.json that score_injected_bugs reads."""
    output_dir.mkdir(parents=True, exist_ok=True)
    results_file = output_dir / "test_results.json"
    results_file.write_text(json.dumps({"failed_tests": failed_tests}))
    return results_file


# ---------------------------------------------------------------------------
# T-14 (P0, AC-2 + AC-9): score_injected_bugs detection correlation
# ---------------------------------------------------------------------------

class TestScoreInjectedBugs:
    """T-14: Scorer correlates acceptance-suite failures against corpus.detectable_by."""

    def test_ac2_t14_detections_equal_three_of_five(self, tmp_path: Path) -> None:
        """
        T-14: Given a golden workspace with 5 injected bugs where 3 are detectable,
        and a test_results.json showing the 3 detectable test IDs as failed,
        When score_injected_bugs is called,
        Then InjectedBugResult.detections == 3 and corpus_size == 5.
        """
        # Arrange
        corpus_path = tmp_path / "corpus"
        bugs = [
            _make_bug("bug_001", detectable_by=["test_add", "test_subtract"]),
            _make_bug("bug_002", detectable_by=["test_multiply"]),
            _make_bug("bug_003", detectable_by=["test_divide"]),
            _make_bug("bug_004", detectable_by=["test_modulo"]),   # NOT detected
            _make_bug("bug_005", detectable_by=["test_power"]),    # NOT detected
        ]
        _write_corpus(corpus_path, bugs)
        workspace = tmp_path / "workspace"
        workspace.mkdir()
        frozen_test_suite = tmp_path / "frozen_tests"
        frozen_test_suite.mkdir()
        output_dir = tmp_path / "output"
        # test_results.json: 3 bugs' test IDs failed → bugs 001, 002, 003 detected
        _make_test_results(
            output_dir,
            failed_tests=["test_add", "test_multiply", "test_divide"],
        )

        # Act
        result = score_injected_bugs(workspace, frozen_test_suite, corpus_path, output_dir)

        # Assert
        assert result.corpus_size == 5
        assert result.detections == 3
        assert result.error is None

    def test_ac2_t14_sidecar_jsonl_has_five_entries_three_detected(self, tmp_path: Path) -> None:
        """
        T-14: sidecar injected_bugs_detail.jsonl contains exactly 5 entries,
        3 with detected=true and 2 with detected=false.
        """
        # Arrange
        corpus_path = tmp_path / "corpus"
        bugs = [
            _make_bug("bug_001", detectable_by=["test_add"]),
            _make_bug("bug_002", detectable_by=["test_multiply"]),
            _make_bug("bug_003", detectable_by=["test_divide"]),
            _make_bug("bug_004", detectable_by=["test_modulo"]),
            _make_bug("bug_005", detectable_by=["test_power"]),
        ]
        _write_corpus(corpus_path, bugs)
        workspace = tmp_path / "workspace"
        workspace.mkdir()
        frozen_test_suite = tmp_path / "frozen_tests"
        frozen_test_suite.mkdir()
        output_dir = tmp_path / "output"
        _make_test_results(
            output_dir,
            failed_tests=["test_add", "test_multiply", "test_divide"],
        )

        # Act
        result = score_injected_bugs(workspace, frozen_test_suite, corpus_path, output_dir)

        # Assert — sidecar JSONL
        assert result.detail_file.exists(), "sidecar injected_bugs_detail.jsonl must exist"
        lines = result.detail_file.read_text().splitlines()
        assert len(lines) == 5, f"Expected 5 JSONL entries, got {len(lines)}"
        entries = {json.loads(line)["bug_id"]: json.loads(line) for line in lines}

        # Verify failing_tests is the subset of bug.detectable_by that appears in failed_tests.
        assert entries["bug_001"]["detected"] is True
        assert entries["bug_001"]["failing_tests"] == ["test_add"]
        assert entries["bug_002"]["detected"] is True
        assert entries["bug_002"]["failing_tests"] == ["test_multiply"]
        assert entries["bug_003"]["detected"] is True
        assert entries["bug_003"]["failing_tests"] == ["test_divide"]
        assert entries["bug_004"]["detected"] is False
        assert entries["bug_004"]["failing_tests"] == []
        assert entries["bug_005"]["detected"] is False
        assert entries["bug_005"]["failing_tests"] == []


# ---------------------------------------------------------------------------
# T-23 (P0, AC-9 MUST-HAVE): validate_corpus minimum-bug gate
# ---------------------------------------------------------------------------

class TestValidateCorpus:
    """T-23: validate_corpus raises CorpusError before any run when corpus has < 20 bugs."""

    def test_ac9_t23_raises_corpus_error_when_below_minimum(self) -> None:
        """
        T-23: corpus with B<20 bugs raises CorpusError identifying actual vs. required count.
        """
        # Arrange
        bugs = [
            InjectedBugEntry(
                bug_id=f"bug_{i:03d}",
                description=f"Bug {i}",
                patch_file=f"patches/bug_{i:03d}.patch",
                detectable_by=["test_foo"],
                severity="medium",
            )
            for i in range(19)
        ]
        corpus = Corpus(schema_version=1, bugs=bugs)

        # Act / Assert
        with pytest.raises(CorpusError) as exc_info:
            validate_corpus(corpus, min_bugs=20)

        error_msg = str(exc_info.value)
        assert "19" in error_msg, f"Error message must mention actual count (19); got: {error_msg!r}"
        assert "20" in error_msg, f"Error message must mention required count (20); got: {error_msg!r}"

    def test_ac9_t23_does_not_raise_when_exactly_at_minimum(self) -> None:
        """
        T-23 boundary: corpus with exactly 20 bugs passes validate_corpus without raising.
        """
        # Arrange
        bugs = [
            InjectedBugEntry(
                bug_id=f"bug_{i:03d}",
                description=f"Bug {i}",
                patch_file=f"patches/bug_{i:03d}.patch",
                detectable_by=["test_foo"],
                severity="low",
            )
            for i in range(20)
        ]
        corpus = Corpus(schema_version=1, bugs=bugs)

        # Act / Assert — must NOT raise
        validate_corpus(corpus, min_bugs=20)

    def test_ac9_t23_gate_is_caller_responsibility_not_inside_scorer(
        self, tmp_path: Path
    ) -> None:
        """
        T-23 (clarifying answer Q1a): the AC-9 gate lives in validate_corpus and
        is called by the runner at sweep start — NOT inside score_injected_bugs.
        A too-small corpus passed through score_injected_bugs does NOT raise
        CorpusError from the scorer; it would silently produce a meaningless
        detection ratio. This test locks in the architectural contract so the
        runner's caller-responsibility for validate_corpus stays visible.
        """
        # Arrange — 5-bug corpus (below min_bugs=20), valid test_results.json present
        corpus_path = tmp_path / "corpus"
        bugs = [_make_bug(f"bug_{i:03d}", detectable_by=["test_x"]) for i in range(5)]
        _write_corpus(corpus_path, bugs)
        workspace = tmp_path / "workspace"
        workspace.mkdir()
        frozen_test_suite = tmp_path / "frozen_tests"
        frozen_test_suite.mkdir()
        _make_test_results(tmp_path / "output", failed_tests=[])

        # Act — scorer runs without error, producing a result over 5 bugs
        result = score_injected_bugs(
            workspace, frozen_test_suite, corpus_path, tmp_path / "output"
        )

        # Assert — scorer did NOT call validate_corpus; result has corpus_size=5
        assert result.corpus_size == 5
        assert result.error is None
        # The gate must be exercised externally
        with pytest.raises(CorpusError):
            validate_corpus(
                Corpus(
                    schema_version=1,
                    bugs=tuple(
                        InjectedBugEntry(
                            bug_id=f"bug_{i:03d}",
                            description="x",
                            patch_file=f"patches/bug_{i:03d}.patch",
                            detectable_by=("test_x",),
                            severity="low",
                        )
                        for i in range(5)
                    ),
                ),
                min_bugs=20,
            )


# ---------------------------------------------------------------------------
# T-43, T-44, T-45 (P1, AC-16): load_corpus format parsing
# ---------------------------------------------------------------------------

class TestLoadCorpus:
    """load_corpus parses manifest.yaml and enforces schema_version gate."""

    def test_ac16_t43_schema_v1_returns_populated_corpus(self, tmp_path: Path) -> None:
        """
        T-43: load_corpus with schema_version=1 and valid entries returns
        Corpus with all InjectedBugEntry fields populated.
        """
        # Arrange
        corpus_path = tmp_path / "corpus"
        bugs = [
            _make_bug(
                "bug_001",
                detectable_by=["test_check_boundary", "test_overflow"],
                severity="high",
            ),
            _make_bug("bug_002", detectable_by=["test_null_guard"], severity="critical"),
        ]
        _write_corpus(corpus_path, bugs, schema_version=1)

        # Act
        corpus = load_corpus(corpus_path)

        # Assert
        assert isinstance(corpus, Corpus)
        assert corpus.schema_version == 1
        assert len(corpus.bugs) == 2

        b0 = corpus.bugs[0]
        assert isinstance(b0, InjectedBugEntry)
        assert b0.bug_id == "bug_001"
        assert b0.description == "Injected bug bug_001"
        assert b0.patch_file == "patches/bug_001.patch"
        assert "test_check_boundary" in b0.detectable_by
        assert "test_overflow" in b0.detectable_by
        assert b0.severity == "high"

        b1 = corpus.bugs[1]
        assert b1.severity == "critical"
        assert b1.detectable_by == ("test_null_guard",)

    def test_ac16_t44_unknown_schema_version_raises_corpus_schema_error(
        self, tmp_path: Path
    ) -> None:
        """
        T-44: load_corpus with schema_version=2 raises CorpusSchemaError whose
        message contains both 'expected=1' and 'actual=2' (or equivalent phrasing).
        """
        # Arrange
        corpus_path = tmp_path / "corpus"
        bugs = [_make_bug("bug_001", detectable_by=["test_foo"])]
        _write_corpus(corpus_path, bugs, schema_version=2)

        # Act / Assert
        with pytest.raises(CorpusSchemaError) as exc_info:
            load_corpus(corpus_path)

        error_msg = str(exc_info.value)
        assert "expected" in error_msg.lower(), f"Error should name 'expected': {error_msg!r}"
        assert "actual" in error_msg.lower(), f"Error should name 'actual': {error_msg!r}"
        assert "=1" in error_msg, f"Expected version token '=1' in error: {error_msg!r}"
        assert "=2" in error_msg, f"Actual version token '=2' in error: {error_msg!r}"

    def test_ac16_t44_corpus_schema_error_is_subclass_of_corpus_error(
        self, tmp_path: Path
    ) -> None:
        """
        T-44 (subtype check): CorpusSchemaError must be catchable as CorpusError.
        """
        corpus_path = tmp_path / "corpus"
        _write_corpus(corpus_path, [_make_bug("bug_001", detectable_by=["t1"])], schema_version=99)

        with pytest.raises(CorpusError):
            load_corpus(corpus_path)

    def test_ac16_t45_extra_unknown_key_loads_successfully(self, tmp_path: Path) -> None:
        """
        T-45: per-bug entry with extra unknown 'metadata' key loads successfully
        (forward-compat — unrecognised keys are silently ignored).
        """
        # Arrange
        corpus_path = tmp_path / "corpus"
        bug_with_extra = _make_bug(
            "bug_001",
            detectable_by=["test_foo"],
            extra={"metadata": {"author": "alice", "introduced_in": "v2.3.0"}},
        )
        _write_corpus(corpus_path, [bug_with_extra], schema_version=1)

        # Act — must NOT raise
        corpus = load_corpus(corpus_path)

        # Assert
        assert len(corpus.bugs) == 1
        assert corpus.bugs[0].bug_id == "bug_001"


# ---------------------------------------------------------------------------
# T-46 (P0, AC-16): Path-traversal defense
# ---------------------------------------------------------------------------

class TestLoadCorpusPathTraversalDefense:
    """T-46: load_corpus rejects patch_file paths that escape the corpus root."""

    def test_ac16_t46_dotdot_patch_file_raises_corpus_security_error(
        self, tmp_path: Path
    ) -> None:
        """
        T-46: patch_file '../../../etc/passwd' escapes corpus root;
        load_corpus raises CorpusSecurityError(bug_id, attempted_path).
        """
        # Arrange — write manifest manually so the traversal path goes into YAML verbatim
        corpus_path = tmp_path / "corpus"
        corpus_path.mkdir()
        manifest = {
            "schema_version": 1,
            "bugs": [
                {
                    "bug_id": "bug_evil",
                    "description": "Traversal attempt",
                    "patch_file": "../../../etc/passwd",
                    "detectable_by": ["test_x"],
                    "severity": "low",
                }
            ],
        }
        (corpus_path / "manifest.yaml").write_text(yaml.dump(manifest))

        # Act / Assert
        with pytest.raises(CorpusSecurityError) as exc_info:
            load_corpus(corpus_path)

        err = exc_info.value
        # CorpusSecurityError carries bug_id, attempted_path, and resolved_path as structured fields.
        assert err.bug_id == "bug_evil"
        assert err.attempted_path == "../../../etc/passwd"
        assert err.resolved_path.endswith("/etc/passwd")
        err_str = str(err)
        assert "bug_evil" in err_str
        assert "../../../etc/passwd" in err_str, f"attempted_path missing from error: {err_str!r}"

    def test_ac16_t46_corpus_security_error_is_subclass_of_corpus_error(
        self, tmp_path: Path
    ) -> None:
        """T-46 (subtype check): CorpusSecurityError must be catchable as CorpusError."""
        corpus_path = tmp_path / "corpus"
        corpus_path.mkdir()
        manifest = {
            "schema_version": 1,
            "bugs": [
                {
                    "bug_id": "bug_x",
                    "description": "Traversal",
                    "patch_file": "../../outside.patch",
                    "detectable_by": ["test_y"],
                    "severity": "low",
                }
            ],
        }
        (corpus_path / "manifest.yaml").write_text(yaml.dump(manifest))

        with pytest.raises(CorpusError):
            load_corpus(corpus_path)

    @pytest.mark.skipif(os.name == "nt", reason="Symlink security is POSIX-only (AC-19 OUT-OF-SCOPE on Windows)")
    def test_ac16_t46_symlink_escaping_corpus_root_raises_corpus_security_error(
        self, tmp_path: Path
    ) -> None:
        """
        T-46 (symlink variant): a symlink inside corpus pointing outside corpus root
        raises CorpusSecurityError. Defense requires Path.resolve() before is_relative_to().
        """
        # Arrange
        corpus_path = tmp_path / "corpus"
        corpus_path.mkdir()
        patches_dir = corpus_path / "patches"
        patches_dir.mkdir()
        # Create a real target file OUTSIDE corpus root
        outside_file = tmp_path / "outside.patch"
        outside_file.write_text("--- a\n+++ b\n")
        # Create a symlink inside corpus that points to the outside file
        evil_link = patches_dir / "bug_symlink.patch"
        os.symlink(outside_file, evil_link)

        manifest = {
            "schema_version": 1,
            "bugs": [
                {
                    "bug_id": "bug_symlink",
                    "description": "Symlink escape attempt",
                    "patch_file": "patches/bug_symlink.patch",
                    "detectable_by": ["test_z"],
                    "severity": "medium",
                }
            ],
        }
        (corpus_path / "manifest.yaml").write_text(yaml.dump(manifest))

        # Act / Assert
        with pytest.raises(CorpusSecurityError) as exc_info:
            load_corpus(corpus_path)

        err_str = str(exc_info.value)
        assert "bug_symlink" in err_str, f"bug_id missing from symlink error: {err_str!r}"


# ---------------------------------------------------------------------------
# AC-17 (P1): score_injected_bugs fail-closed on missing/malformed test_results.json
# ---------------------------------------------------------------------------

class TestScoreInjectedBugsFailClosed:
    """AC-17: scorer returns InjectedBugResult with error set; does NOT raise."""

    def test_ac17_missing_test_results_returns_error_result(self, tmp_path: Path) -> None:
        """
        AC-17: test_results.json absent → InjectedBugResult(error="test_results_missing"),
        no exception raised. Models the driver-crashed-before-writing case.
        """
        corpus_path = tmp_path / "corpus"
        bugs = [_make_bug("bug_001", detectable_by=["test_foo"])]
        _write_corpus(corpus_path, bugs)
        workspace = tmp_path / "workspace"
        workspace.mkdir()
        frozen_test_suite = tmp_path / "frozen_tests"
        frozen_test_suite.mkdir()
        output_dir = tmp_path / "output"
        output_dir.mkdir()
        # Do NOT create test_results.json

        result = score_injected_bugs(workspace, frozen_test_suite, corpus_path, output_dir)

        assert result.error == "test_results_missing"
        assert result.detections == 0
        assert result.corpus_size == 1
        assert result.tool_name is None

    def test_ac17_malformed_test_results_returns_error_result(self, tmp_path: Path) -> None:
        """
        AC-17: test_results.json present but malformed JSON →
        InjectedBugResult(error="test_results_malformed"), no exception raised.
        """
        corpus_path = tmp_path / "corpus"
        bugs = [_make_bug("bug_001", detectable_by=["test_foo"])]
        _write_corpus(corpus_path, bugs)
        workspace = tmp_path / "workspace"
        workspace.mkdir()
        frozen_test_suite = tmp_path / "frozen_tests"
        frozen_test_suite.mkdir()
        output_dir = tmp_path / "output"
        output_dir.mkdir()
        (output_dir / "test_results.json").write_text("{not: valid json")

        result = score_injected_bugs(workspace, frozen_test_suite, corpus_path, output_dir)

        assert result.error == "test_results_malformed"
        assert result.detections == 0
        assert result.corpus_size == 1
