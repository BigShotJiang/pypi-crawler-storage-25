"""
Tests for scoring/mutation.py — T-15, T-16, T-47, T-48, T-51, T-52, T-53, T-54

Covers:
  T-15 (P1, AC-2+AC-8): Python task — MutationResult.per_language["python"] is a
        LanguageMutationScore with {killed, survived, timeout, score} populated;
        score is a float in 0.0..1.0.
  T-16 (P1, AC-2+AC-8): JS/TS task — MutationResult.per_language["javascript"] (or
        "typescript") populated; cross-language average NEVER present in any field.
  T-47 (P1, AC-17): mutmut not on PATH → per_language["python"] is None,
        per_language_error["python"] == "tool_missing", no exception raised,
        other-language scorers still run if applicable.
  T-48 (P1, AC-17): npx not on PATH → per_language["javascript"] is None, same pattern.
  T-51 (P0, AC-19): Golden mutmut JSON (9 fields, total == sum of 8 counters, positive
        counts) → score computed via harness formula killed / (killed + survived +
        suspicious + timeout), no error.
  T-52 (P0, AC-19): Internal-inconsistency fixture (total=100, 8 counters sum to 95) →
        per_language["python"] is None, per_language_error["python"] == "mutmut_baseline_failed".
  T-53 (P0, AC-19): Pre-existing mutants/ directory with stale .mutmut-cache files →
        scorer removes entire mutants/ directory BEFORE invoking mutmut. Assert via
        workspace-state snapshot at subprocess call time.
  T-54 (P0, AC-19): Stryker process-group cleanup — scorer launches Stryker via
        Popen(preexec_fn=os.setsid). On timeout/crash, os.killpg(pgid, SIGTERM) is
        called. POSIX-only (skip on Windows).

--- task_manifest shape (this scorer's design contract) ---

task_manifest = {
    "language": "python" | "javascript" | "typescript" | "polyglot",
    # For python: mutmut is invoked; test_command is passed to mutmut.
    "test_command": "pytest tests/",
    # For js/ts: stryker is invoked via npx.
    "stryker_config_path": "stryker.conf.json",  # optional
}
For "polyglot", both mutmut (python) and stryker (js/ts) are attempted.

--- mutmut stats JSON format (v3.5.0, mutmut export_cicd_stats) ---

9 keys: killed, survived, total, no_tests, skipped, suspicious, timeout,
        check_was_interrupted_by_user, segfault.
Internal consistency check (AC-19 cond iii):
  total == killed + survived + suspicious + timeout + no_tests + skipped +
           segfault + check_was_interrupted_by_user   (8 counters)
Note: JSON key is check_was_interrupted_by_user; dataclass field is check_was_interrupted.

Score formula (python, harness convention):
  killed / (killed + survived + suspicious + timeout)
  Excludes no_tests, skipped, segfault, check_was_interrupted from both numerator and denominator.

--- Stryker JSON format (v9.6.1, reports/mutation/mutation.json) ---

8 mutant states: Killed, Survived, NoCoverage, CompileError, RuntimeError, Timeout,
                 Ignored, Pending.
Required top-level keys: schemaVersion, thresholds, files.
Mutants live at files[<path>]["mutants"][<index>]["status"].

Score formula (js/ts, Stryker convention):
  (killed + timeout) / (killed + survived + timeout + no_coverage)
  Excludes CompileError, RuntimeError, Ignored, Pending.
"""

import json
import os
import signal
from pathlib import Path
from unittest.mock import MagicMock, call, patch

import pytest

from scoring.mutation import (
    LanguageMutationScore,
    MutationResult,
    score_mutation,
)


# ---------------------------------------------------------------------------
# Fixture helpers
# ---------------------------------------------------------------------------

def _make_mutmut_stats(
    *,
    killed: int,
    survived: int,
    suspicious: int = 0,
    timeout: int = 0,
    no_tests: int = 0,
    skipped: int = 0,
    segfault: int = 0,
    check_was_interrupted_by_user: int = 0,
    total: int | None = None,
) -> dict:
    """
    Build a mutmut-cicd-stats.json dict.  Pass total=None to auto-compute
    the correct sum (golden fixture), or pass an explicit value for
    inconsistency testing.
    """
    counters = (
        killed + survived + suspicious + timeout
        + no_tests + skipped + segfault + check_was_interrupted_by_user
    )
    return {
        "killed": killed,
        "survived": survived,
        "suspicious": suspicious,
        "timeout": timeout,
        "no_tests": no_tests,
        "skipped": skipped,
        "segfault": segfault,
        "check_was_interrupted_by_user": check_was_interrupted_by_user,
        "total": counters if total is None else total,
    }


def _write_mutmut_stats(workspace: Path, stats: dict) -> Path:
    """Write stats dict to workspace/mutants/mutmut-cicd-stats.json."""
    mutants_dir = workspace / "mutants"
    mutants_dir.mkdir(parents=True, exist_ok=True)
    stats_file = mutants_dir / "mutmut-cicd-stats.json"
    stats_file.write_text(json.dumps(stats))
    return stats_file


def _make_stryker_report(
    *,
    killed: int = 0,
    survived: int = 0,
    timeout: int = 0,
    no_coverage: int = 0,
    compile_error: int = 0,
    runtime_error: int = 0,
    ignored: int = 0,
    pending: int = 0,
) -> dict:
    """
    Build a minimal Stryker mutation.json with all 8 mutant states.
    Mutants are distributed as single entries under a synthetic file path.
    """
    mutants = []
    state_counts = {
        "Killed": killed,
        "Survived": survived,
        "Timeout": timeout,
        "NoCoverage": no_coverage,
        "CompileError": compile_error,
        "RuntimeError": runtime_error,
        "Ignored": ignored,
        "Pending": pending,
    }
    idx = 0
    for status, count in state_counts.items():
        for _ in range(count):
            mutants.append({
                "id": str(idx),
                "mutatorName": "ArithmeticOperator",
                "replacement": "+",
                "location": {"start": {"line": 1, "column": 1}, "end": {"line": 1, "column": 2}},
                "status": status,
                "static": False,
                "coveredBy": [],
                "killedBy": [],
                "description": f"Replaced - with + ({idx})",
            })
            idx += 1

    return {
        "schemaVersion": "1",
        "thresholds": {"high": 80, "low": 60},
        "projectRoot": "/workspace",
        "files": {
            "src/index.js": {
                "language": "javascript",
                "mutants": mutants,
            }
        },
        "testFiles": {},
    }


def _write_stryker_report(workspace: Path, report: dict) -> Path:
    """Write Stryker JSON to workspace/reports/mutation/mutation.json."""
    report_dir = workspace / "reports" / "mutation"
    report_dir.mkdir(parents=True, exist_ok=True)
    report_file = report_dir / "mutation.json"
    report_file.write_text(json.dumps(report))
    return report_file


# ---------------------------------------------------------------------------
# T-15 (P1, AC-2+AC-8): Python task — LanguageMutationScore shape + score range
# ---------------------------------------------------------------------------

class TestScoreMutationPython:
    """T-15: Python mutation run populates per_language['python'] with correct shape."""

    def test_t15_python_language_score_shape_and_score_in_range(
        self, tmp_path: Path
    ) -> None:
        """
        T-15 (AC-2+AC-8): Given a python task with golden mutmut stats
        (killed=8, survived=2, total=10, all others 0),
        When score_mutation is called,
        Then per_language["python"] is a LanguageMutationScore, score is float in 0.0..1.0,
        and killed/survived/timeout are populated correctly.

        Score formula: 8 / (8 + 2 + 0 + 0) = 0.8
        """
        # Arrange
        workspace = tmp_path / "workspace"
        workspace.mkdir()
        task_manifest = {
            "language": "python",
            "test_command": "pytest tests/",
        }
        stats = _make_mutmut_stats(killed=8, survived=2)

        # Mock subprocess so mutmut run + export both succeed; then write the fixture.
        def fake_run(cmd, *args, **kwargs):
            if "export_cicd_stats" in cmd or (isinstance(cmd, list) and "export_cicd_stats" in cmd):
                _write_mutmut_stats(workspace, stats)
            mock_result = MagicMock()
            mock_result.returncode = 0
            return mock_result

        with patch("subprocess.run", side_effect=fake_run):
            # Act
            result = score_mutation(workspace, task_manifest)

        # Assert
        assert isinstance(result, MutationResult)
        lang_score = result.per_language.get("python")
        assert isinstance(lang_score, LanguageMutationScore), (
            f"per_language['python'] must be LanguageMutationScore, got {type(lang_score)}"
        )
        assert lang_score.killed == 8
        assert lang_score.survived == 2
        assert lang_score.timeout == 0
        assert isinstance(lang_score.score, float), "score must be a float, not None"
        assert 0.0 <= lang_score.score <= 1.0, f"score must be in [0.0, 1.0], got {lang_score.score}"
        # Expected: 8 / (8 + 2 + 0 + 0) == 0.8
        assert abs(lang_score.score - 0.8) < 1e-9, f"Expected 0.8, got {lang_score.score}"
        assert result.error is None


# ---------------------------------------------------------------------------
# T-16 (P1, AC-2+AC-8): JS/TS task — populated + no cross-language average
# ---------------------------------------------------------------------------

class TestScoreMutationJavaScript:
    """T-16: JS/TS mutation run populates per_language; no cross-language average anywhere."""

    def test_t16_javascript_language_score_populated_and_no_average_field(
        self, tmp_path: Path
    ) -> None:
        """
        T-16 (AC-2+AC-8): Given a javascript task with a Stryker report
        (killed=7, survived=3, timeout=0, no_coverage=0, others 0),
        When score_mutation is called,
        Then per_language["javascript"] (or "typescript") is a LanguageMutationScore,
        score is float in 0.0..1.0, and NO field named "average" or "cross_language_average"
        exists on MutationResult.

        Stryker score formula: (7 + 0) / (7 + 3 + 0 + 0) = 0.7
        """
        # Arrange
        workspace = tmp_path / "workspace"
        workspace.mkdir()
        task_manifest = {
            "language": "javascript",
            "test_command": "npm test",
        }
        report = _make_stryker_report(killed=7, survived=3)

        mock_proc = MagicMock()
        mock_proc.pid = 12345
        mock_proc.returncode = 0
        mock_proc.wait.return_value = 0

        def fake_popen(cmd, *args, **kwargs):
            # Stryker writes the report atomically end-of-run (per JsonReporter).
            # Mock that side-effect at Popen-call time.
            _write_stryker_report(workspace, report)
            return mock_proc

        with patch("subprocess.Popen", side_effect=fake_popen):
            # Act
            result = score_mutation(workspace, task_manifest)

        # Assert — at least one of javascript or typescript key is populated
        lang_key = None
        for key in ("javascript", "typescript"):
            if result.per_language.get(key) is not None:
                lang_key = key
                break
        assert lang_key is not None, (
            f"Expected per_language['javascript'] or ['typescript'] to be set; "
            f"got keys: {list(result.per_language.keys())}"
        )

        lang_score = result.per_language[lang_key]
        assert isinstance(lang_score, LanguageMutationScore)
        assert isinstance(lang_score.score, float)
        assert 0.0 <= lang_score.score <= 1.0

        # No cross-language average must appear anywhere on MutationResult
        assert not hasattr(result, "average"), "MutationResult must NOT have 'average' field"
        assert not hasattr(result, "cross_language_average"), (
            "MutationResult must NOT have 'cross_language_average' field"
        )


# ---------------------------------------------------------------------------
# T-47 (P1, AC-17): mutmut not on PATH → fail-closed, no exception
# ---------------------------------------------------------------------------

class TestScoreMutationToolMissing:
    """T-47 / T-48: Missing tool → per_language[lang] is None, per_language_error set."""

    def test_t47_mutmut_missing_returns_none_not_raises(
        self, tmp_path: Path
    ) -> None:
        """
        T-47 (AC-17): mutmut not on PATH for a python task:
          - per_language["python"] is None
          - per_language_error["python"] == "tool_missing"
          - no exception raised
        """
        # Arrange
        workspace = tmp_path / "workspace"
        workspace.mkdir()
        task_manifest = {
            "language": "python",
            "test_command": "pytest tests/",
        }

        # Simulate FileNotFoundError as if 'mutmut' binary is absent
        def fake_run_no_mutmut(cmd, *args, **kwargs):
            cmd_str = cmd if isinstance(cmd, str) else " ".join(cmd)
            if "mutmut" in cmd_str:
                raise FileNotFoundError("No such file or directory: 'mutmut'")
            mock_result = MagicMock()
            mock_result.returncode = 0
            return mock_result

        with patch("subprocess.run", side_effect=fake_run_no_mutmut):
            # Act — must NOT raise
            result = score_mutation(workspace, task_manifest)

        # Assert
        assert result.per_language.get("python") is None
        assert result.per_language_error.get("python") == "tool_missing", (
            f"Expected 'tool_missing', got: {result.per_language_error.get('python')!r}"
        )

    def test_t48_npx_missing_returns_none_not_raises(
        self, tmp_path: Path
    ) -> None:
        """
        T-48 (AC-17): npx not on PATH for a javascript task:
          - per_language["javascript"] is None (or "typescript" if task declares that)
          - per_language_error[lang] == "tool_missing"
          - no exception raised
        """
        # Arrange
        workspace = tmp_path / "workspace"
        workspace.mkdir()
        task_manifest = {
            "language": "javascript",
            "test_command": "npm test",
        }

        def fake_run_no_npx(cmd, *args, **kwargs):
            cmd_str = cmd if isinstance(cmd, str) else " ".join(cmd)
            if "npx" in cmd_str or "stryker" in cmd_str:
                raise FileNotFoundError("No such file or directory: 'npx'")
            mock_result = MagicMock()
            mock_result.returncode = 0
            return mock_result

        def fake_popen_no_npx(cmd, *args, **kwargs):
            cmd_str = cmd if isinstance(cmd, str) else " ".join(cmd)
            if "npx" in cmd_str or "stryker" in cmd_str:
                raise FileNotFoundError("No such file or directory: 'npx'")
            raise AssertionError("Popen called with unexpected command")

        with patch("subprocess.run", side_effect=fake_run_no_npx), \
             patch("subprocess.Popen", side_effect=fake_popen_no_npx):
            # Act — must NOT raise
            result = score_mutation(workspace, task_manifest)

        # Assert
        lang_key = None
        for key in ("javascript", "typescript"):
            if key in result.per_language_error:
                lang_key = key
                break
        assert lang_key is not None, (
            f"Expected per_language_error['javascript'] or ['typescript'] to be set; "
            f"got: {result.per_language_error}"
        )
        assert result.per_language.get(lang_key) is None
        assert result.per_language_error[lang_key] == "tool_missing", (
            f"Expected 'tool_missing', got: {result.per_language_error.get(lang_key)!r}"
        )

    def test_t47_other_language_scorer_still_runs_when_python_tool_missing(
        self, tmp_path: Path
    ) -> None:
        """
        T-47 variant: polyglot task where mutmut is missing but npx/stryker is present.
        per_language["python"] is None with error "tool_missing",
        but per_language["javascript"] (or "typescript") is still scored.
        """
        # Arrange
        workspace = tmp_path / "workspace"
        workspace.mkdir()
        task_manifest = {
            "language": "polyglot",
            "test_command": "pytest tests/",
        }
        report = _make_stryker_report(killed=5, survived=5)

        call_tracker: list[str] = []

        def fake_run_selective(cmd, *args, **kwargs):
            # Only mutmut path uses subprocess.run; Stryker uses Popen exclusively.
            cmd_str = cmd if isinstance(cmd, str) else " ".join(cmd)
            call_tracker.append(cmd_str)
            if "mutmut" in cmd_str:
                raise FileNotFoundError("mutmut not found")
            mock_result = MagicMock()
            mock_result.returncode = 0
            return mock_result

        mock_proc = MagicMock()
        mock_proc.pid = 99999
        mock_proc.returncode = 0
        mock_proc.wait.return_value = 0

        def fake_popen(cmd, *args, **kwargs):
            cmd_str = cmd if isinstance(cmd, str) else " ".join(cmd)
            call_tracker.append(f"popen:{cmd_str}")
            _write_stryker_report(workspace, report)
            return mock_proc

        with patch("subprocess.run", side_effect=fake_run_selective), \
             patch("subprocess.Popen", side_effect=fake_popen):
            result = score_mutation(workspace, task_manifest)

        # python must fail, js/ts must succeed
        assert result.per_language.get("python") is None
        assert result.per_language_error.get("python") == "tool_missing"

        js_scored = any(
            result.per_language.get(k) is not None
            for k in ("javascript", "typescript")
        )
        assert js_scored, (
            "Stryker should still run when only mutmut is missing; "
            f"per_language = {result.per_language}"
        )


# ---------------------------------------------------------------------------
# T-51 (P0, AC-19): Golden mutmut stats → correct score formula
# ---------------------------------------------------------------------------

class TestScoreMutationGoldenMutmut:
    """T-51: Golden mutmut JSON (total == sum of 8 counters) → score computed correctly."""

    def test_t51_golden_mutmut_stats_score_formula(self, tmp_path: Path) -> None:
        """
        T-51 (AC-19): Given a golden mutmut-cicd-stats.json with
          killed=40, survived=10, suspicious=2, timeout=3,
          no_tests=1, skipped=0, segfault=0, check_was_interrupted_by_user=0,
          total=56 (== 40+10+2+3+1+0+0+0),
        When score_mutation reads this file (mock subprocess writes it),
        Then per_language["python"].score == 40 / (40 + 10 + 2 + 3) == 40/55 ~= 0.7273,
        error is None, and score is in 0.0..1.0.

        Score formula (harness convention):
          killed / (killed + survived + suspicious + timeout)
          Note: no_tests, skipped, segfault, check_was_interrupted EXCLUDED.
        """
        # Arrange
        workspace = tmp_path / "workspace"
        workspace.mkdir()
        task_manifest = {
            "language": "python",
            "test_command": "pytest tests/",
        }
        stats = _make_mutmut_stats(
            killed=40,
            survived=10,
            suspicious=2,
            timeout=3,
            no_tests=1,
        )
        # Verify fixture is internally consistent (total == sum of 8 counters)
        assert stats["total"] == 40 + 10 + 2 + 3 + 1 + 0 + 0 + 0, (
            "Fixture builder error: total mismatch"
        )

        def fake_run(cmd, *args, **kwargs):
            cmd_str = cmd if isinstance(cmd, str) else " ".join(cmd)
            if "export_cicd_stats" in cmd_str:
                _write_mutmut_stats(workspace, stats)
            mock_result = MagicMock()
            mock_result.returncode = 0
            return mock_result

        with patch("subprocess.run", side_effect=fake_run):
            result = score_mutation(workspace, task_manifest)

        # Assert
        lang_score = result.per_language.get("python")
        assert isinstance(lang_score, LanguageMutationScore)
        assert lang_score.killed == 40
        assert lang_score.survived == 10
        assert lang_score.suspicious == 2
        assert lang_score.timeout == 3
        assert lang_score.no_tests == 1

        expected_score = 40 / (40 + 10 + 2 + 3)  # == 40/55
        assert lang_score.score is not None
        assert abs(lang_score.score - expected_score) < 1e-9, (
            f"Expected {expected_score}, got {lang_score.score}"
        )
        assert 0.0 <= lang_score.score <= 1.0
        assert result.error is None
        assert result.per_language_error.get("python") is None


# ---------------------------------------------------------------------------
# T-52 (P0, AC-19): Internal inconsistency → per_language["python"] is None
# ---------------------------------------------------------------------------

class TestScoreMutationInconsistentMutmutStats:
    """T-52: Inconsistent mutmut total → scorer sets None + mutmut_baseline_failed."""

    def test_t52_inconsistent_total_yields_none_and_baseline_failed_error(
        self, tmp_path: Path
    ) -> None:
        """
        T-52 (AC-19): Given mutmut-cicd-stats.json where total=100 but
        8 counters sum to 95 (inconsistency of 5),
        When score_mutation reads this file,
        Then per_language["python"] is None and
        per_language_error["python"] == "mutmut_baseline_failed".

        AC-19 condition iii: total MUST equal killed + survived + suspicious + timeout
        + no_tests + skipped + segfault + check_was_interrupted_by_user.
        Mismatch → treat as a corrupt/incomplete run.
        """
        # Arrange
        workspace = tmp_path / "workspace"
        workspace.mkdir()
        task_manifest = {
            "language": "python",
            "test_command": "pytest tests/",
        }
        # Manually build inconsistent stats (counters sum to 95, total claims 100)
        stats = _make_mutmut_stats(
            killed=50,
            survived=30,
            suspicious=5,
            timeout=10,
            # 50+30+5+10 = 95; claim total=100
            total=100,
        )
        assert stats["total"] == 100
        counter_sum = (
            stats["killed"] + stats["survived"] + stats["suspicious"]
            + stats["timeout"] + stats["no_tests"] + stats["skipped"]
            + stats["segfault"] + stats["check_was_interrupted_by_user"]
        )
        assert counter_sum == 95, f"Fixture builder error: expected sum=95, got {counter_sum}"

        def fake_run(cmd, *args, **kwargs):
            cmd_str = cmd if isinstance(cmd, str) else " ".join(cmd)
            if "export_cicd_stats" in cmd_str:
                _write_mutmut_stats(workspace, stats)
            mock_result = MagicMock()
            mock_result.returncode = 0
            return mock_result

        with patch("subprocess.run", side_effect=fake_run):
            result = score_mutation(workspace, task_manifest)

        # Assert
        assert result.per_language.get("python") is None, (
            "Inconsistent total must yield per_language['python'] = None"
        )
        assert result.per_language_error.get("python") == "mutmut_baseline_failed", (
            f"Expected 'mutmut_baseline_failed', got: {result.per_language_error.get('python')!r}"
        )


# ---------------------------------------------------------------------------
# T-53 (P0, AC-19): Pre-existing mutants/ directory cleanup before mutmut
# ---------------------------------------------------------------------------

class TestScoreMutationCleanupMutantsDir:
    """T-53: Stale mutants/ directory is removed BEFORE invoking mutmut."""

    def test_t53_stale_mutants_dir_removed_before_subprocess_call(
        self, tmp_path: Path
    ) -> None:
        """
        T-53 (AC-19): Given a workspace with a pre-existing mutants/ directory
        containing a stale .mutmut-cache sentinel file,
        When score_mutation is called,
        Then the mutants/ directory (and sentinel file) no longer exists at the
        moment subprocess is invoked (scorer cleans up stale state first).

        Approach: record the state of workspace/mutants inside the subprocess.run
        side effect. If the directory is present at that point, the test fails.
        """
        # Arrange — pre-create stale mutants/ with sentinel content
        workspace = tmp_path / "workspace"
        workspace.mkdir()
        mutants_dir = workspace / "mutants"
        mutants_dir.mkdir()
        cache_file = mutants_dir / ".mutmut-cache"
        cache_file.write_text("STALE_SENTINEL_CONTENT")
        assert cache_file.exists(), "Pre-condition: stale cache file must exist"

        task_manifest = {
            "language": "python",
            "test_command": "pytest tests/",
        }

        workspace_state_at_call: list[bool] = []

        def fake_run_check_workspace(cmd, *args, **kwargs):
            cmd_str = cmd if isinstance(cmd, str) else " ".join(cmd)
            if "mutmut" in cmd_str and "export_cicd_stats" not in cmd_str:
                # This is the 'mutmut run' invocation — record whether stale dir still exists
                workspace_state_at_call.append(mutants_dir.exists())
            elif "export_cicd_stats" in cmd_str:
                # Write clean stats so scorer can complete
                clean_stats = _make_mutmut_stats(killed=5, survived=5)
                _write_mutmut_stats(workspace, clean_stats)
            mock_result = MagicMock()
            mock_result.returncode = 0
            return mock_result

        with patch("subprocess.run", side_effect=fake_run_check_workspace):
            score_mutation(workspace, task_manifest)

        # Assert — mutants_dir must NOT have existed when mutmut run was called
        assert len(workspace_state_at_call) >= 1, (
            "mutmut run was never called — test cannot assert cleanup timing"
        )
        assert not workspace_state_at_call[0], (
            "mutants/ directory must be DELETED before 'mutmut run' is invoked; "
            f"was present: {workspace_state_at_call}"
        )


# ---------------------------------------------------------------------------
# T-54 (P0, AC-19): Stryker process-group cleanup on timeout/crash
# ---------------------------------------------------------------------------

@pytest.mark.skipif(os.name == "nt", reason="Process group (setsid/killpg) is POSIX-only")
class TestScoreMutationStrykerProcessGroup:
    """T-54: Stryker is launched via Popen(preexec_fn=os.setsid); killpg called on timeout."""

    def test_t54_stryker_popen_uses_setsid_preexec_fn(
        self, tmp_path: Path
    ) -> None:
        """
        T-54a: scorer calls subprocess.Popen with preexec_fn=os.setsid when launching Stryker.
        Asserted by capturing the kwargs passed to Popen.
        """
        # Arrange
        workspace = tmp_path / "workspace"
        workspace.mkdir()
        task_manifest = {
            "language": "javascript",
            "test_command": "npm test",
        }
        report = _make_stryker_report(killed=3, survived=2)

        popen_kwargs_captured: list[dict] = []

        mock_proc = MagicMock()
        mock_proc.pid = 54321
        mock_proc.returncode = 0
        mock_proc.wait.return_value = 0

        def fake_popen(cmd, *args, **kwargs):
            popen_kwargs_captured.append(dict(kwargs))
            _write_stryker_report(workspace, report)
            return mock_proc

        with patch("subprocess.Popen", side_effect=fake_popen):
            score_mutation(workspace, task_manifest)

        # Assert — at least one Popen call used start_new_session=True (the
        # thread-safe equivalent of preexec_fn=os.setsid; CPython gh-114220).
        assert len(popen_kwargs_captured) >= 1, "Popen was never called for Stryker"
        new_sessions = [kw.get("start_new_session") for kw in popen_kwargs_captured]
        assert any(s is True for s in new_sessions), (
            f"Expected start_new_session=True in at least one Popen call; "
            f"got: {new_sessions}"
        )

    def test_t54_killpg_called_with_sigterm_on_stryker_timeout(
        self, tmp_path: Path
    ) -> None:
        """
        T-54b: On Stryker timeout, os.killpg(pgid, signal.SIGTERM) is called.
        Approach: Popen.wait() raises subprocess.TimeoutExpired; mock os.killpg
        to verify SIGTERM is sent to the process group.
        """
        import subprocess as _subprocess

        # Arrange
        workspace = tmp_path / "workspace"
        workspace.mkdir()
        task_manifest = {
            "language": "javascript",
            "test_command": "npm test",
            # Short timeout to trigger the kill path
        }

        mock_proc = MagicMock()
        mock_proc.pid = 77777

        def fake_wait(timeout=None):
            raise _subprocess.TimeoutExpired(cmd="npx stryker run", timeout=timeout)

        mock_proc.wait = fake_wait

        def fake_popen(cmd, *args, **kwargs):
            return mock_proc

        killpg_calls: list[tuple] = []

        def fake_killpg(pgid: int, sig: int) -> None:
            killpg_calls.append((pgid, sig))

        with patch("subprocess.Popen", side_effect=fake_popen), \
             patch("os.killpg", side_effect=fake_killpg), \
             patch("os.getpgid", return_value=77777):
            # Act — must not raise; timeout is handled gracefully
            result = score_mutation(workspace, task_manifest, timeout_seconds=1)

        # Assert — SIGTERM was sent to the EXACT pgid we captured (not a
        # recycled-PID's group). H-1 fix: assert pgid argument as well.
        assert len(killpg_calls) >= 1, (
            "os.killpg was never called; timeout cleanup path not exercised"
        )
        pgid_sent, sig_sent = killpg_calls[0]
        assert pgid_sent == 77777, (
            f"Expected killpg targeted pid 77777 (captured pgid); got {pgid_sent}"
        )
        assert sig_sent == signal.SIGTERM, (
            f"Expected SIGTERM ({signal.SIGTERM}), got signal {sig_sent}"
        )


# ---------------------------------------------------------------------------
# T-55 (P0, AC-19): mutmut TimeoutExpired fail-closed
# ---------------------------------------------------------------------------

class TestScoreMutationMutmutTimeout:
    """T-55: subprocess.TimeoutExpired in mutmut path returns mutmut_timeout."""

    def test_t55_mutmut_run_timeout_returns_timeout_error(self, tmp_path: Path) -> None:
        """
        T-55: When mutmut run exceeds timeout_seconds, subprocess.run raises
        TimeoutExpired. Scorer MUST catch and return per_language_error[
        "python"] == "mutmut_timeout" — does NOT propagate the exception
        (AC-17 fail-closed contract).
        """
        import subprocess as _subprocess
        workspace = tmp_path / "workspace"
        workspace.mkdir()
        task_manifest = {"language": "python", "test_command": "pytest tests/"}

        def fake_run_timeout(cmd, *args, **kwargs):
            raise _subprocess.TimeoutExpired(cmd=cmd, timeout=kwargs.get("timeout"))

        with patch("subprocess.run", side_effect=fake_run_timeout):
            # Act — must NOT raise
            result = score_mutation(workspace, task_manifest, timeout_seconds=1)

        assert result.per_language["python"] is None
        assert result.per_language_error["python"] == "mutmut_timeout"


# ---------------------------------------------------------------------------
# T-56 (P0, AC-19): expanded internal-consistency conditions
# ---------------------------------------------------------------------------

class TestScoreMutationAC19ExpandedChecks:
    """
    T-56: AC-19 internal consistency now also catches:
      - total <= 0 (empty stats run)
      - check_was_interrupted_by_user == total (all-Ctrl-C run)
    Sum-mismatch is covered by T-52; these are the additional guards.
    """

    def test_t56a_total_zero_yields_baseline_failed(self, tmp_path: Path) -> None:
        workspace = tmp_path / "workspace"
        workspace.mkdir()
        task_manifest = {"language": "python", "test_command": "pytest"}

        zero_stats = {
            "killed": 0, "survived": 0, "suspicious": 0, "timeout": 0,
            "no_tests": 0, "skipped": 0, "segfault": 0,
            "check_was_interrupted_by_user": 0, "total": 0,
        }

        def fake_run(cmd, *args, **kwargs):
            (workspace / "mutants").mkdir(exist_ok=True)
            (workspace / "mutants" / "mutmut-cicd-stats.json").write_text(json.dumps(zero_stats))
            return MagicMock(returncode=0)

        with patch("subprocess.run", side_effect=fake_run):
            result = score_mutation(workspace, task_manifest)

        assert result.per_language["python"] is None
        assert result.per_language_error["python"] == "mutmut_baseline_failed"

    def test_t56b_all_user_interrupted_yields_baseline_failed(self, tmp_path: Path) -> None:
        workspace = tmp_path / "workspace"
        workspace.mkdir()
        task_manifest = {"language": "python", "test_command": "pytest"}

        all_interrupted = {
            "killed": 0, "survived": 0, "suspicious": 0, "timeout": 0,
            "no_tests": 0, "skipped": 0, "segfault": 0,
            "check_was_interrupted_by_user": 10, "total": 10,
        }

        def fake_run(cmd, *args, **kwargs):
            (workspace / "mutants").mkdir(exist_ok=True)
            (workspace / "mutants" / "mutmut-cicd-stats.json").write_text(json.dumps(all_interrupted))
            return MagicMock(returncode=0)

        with patch("subprocess.run", side_effect=fake_run):
            result = score_mutation(workspace, task_manifest)

        assert result.per_language["python"] is None
        assert result.per_language_error["python"] == "mutmut_baseline_failed"


# ---------------------------------------------------------------------------
# T-57 (P0): denom=0 → score=None semantic (silent-corruption guard)
# ---------------------------------------------------------------------------

class TestScoreMutationEmptyDenominator:
    """
    T-57: When mutmut returns only no_tests/skipped/segfault/check_was_interrupted
    mutants (so killed+survived+suspicious+timeout=0), score MUST be None — NOT
    0.0. A consumer reading 0.0 cannot distinguish "ran, killed nothing" from
    "no scorable mutants present." Same semantic for Stryker (denom=0 → None).
    """

    def test_t57_mutmut_empty_scorable_denominator_yields_score_none(self, tmp_path: Path) -> None:
        workspace = tmp_path / "workspace"
        workspace.mkdir()
        task_manifest = {"language": "python", "test_command": "pytest"}

        # 5 mutants, all skipped/no_tests — internal consistency passes (sum = total)
        # but the scorable denominator is 0.
        empty_denom_stats = {
            "killed": 0, "survived": 0, "suspicious": 0, "timeout": 0,
            "no_tests": 3, "skipped": 2, "segfault": 0,
            "check_was_interrupted_by_user": 0, "total": 5,
        }

        def fake_run(cmd, *args, **kwargs):
            (workspace / "mutants").mkdir(exist_ok=True)
            (workspace / "mutants" / "mutmut-cicd-stats.json").write_text(json.dumps(empty_denom_stats))
            return MagicMock(returncode=0)

        with patch("subprocess.run", side_effect=fake_run):
            result = score_mutation(workspace, task_manifest)

        # Score is None, not 0.0 — distinguishes from real-zero-kill case
        assert result.per_language["python"] is not None  # the scorer SUCCEEDED
        assert result.per_language["python"].score is None
        assert result.per_language["python"].no_tests == 3
        assert result.per_language["python"].skipped == 2

    def test_t57_stryker_empty_scorable_denominator_yields_score_none(self, tmp_path: Path) -> None:
        workspace = tmp_path / "workspace"
        workspace.mkdir()
        task_manifest = {"language": "javascript", "test_command": "npm test"}

        # All mutants are CompileError — excluded from Stryker score denominator
        report = {
            "schemaVersion": "1.0",
            "thresholds": {"high": 80, "low": 60},
            "files": {
                "src/foo.js": {
                    "mutants": [
                        {"id": "1", "status": "CompileError"},
                        {"id": "2", "status": "CompileError"},
                        {"id": "3", "status": "Ignored"},
                    ]
                }
            },
        }

        mock_proc = MagicMock()
        mock_proc.pid = 11111
        mock_proc.wait.return_value = 0

        def fake_popen(cmd, *args, **kwargs):
            _write_stryker_report(workspace, report)
            return mock_proc

        with patch("subprocess.Popen", side_effect=fake_popen):
            result = score_mutation(workspace, task_manifest)

        assert result.per_language["javascript"] is not None
        assert result.per_language["javascript"].score is None
        assert result.per_language["javascript"].compile_error == 2
        assert result.per_language["javascript"].ignored == 1
