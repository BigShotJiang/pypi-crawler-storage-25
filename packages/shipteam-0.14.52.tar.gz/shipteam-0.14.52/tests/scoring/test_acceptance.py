"""
Tests for scoring/acceptance.py — T-11, T-40 (AC-2, AC-13, Phase 1).

Covers post-drive scoring isolation:
  T-11: Frozen test suite applied POST-DRIVE in isolated eval context;
        acceptance_pct == N/M for a known workspace.
  T-40: Acceptance tests are NOT present in the driver workspace during
        driver execution; scorer mounts them only in the eval phase.

Key oracle (AC-13 tamper-resistance):
  A driver that writes a passing stub into its workspace cannot inflate
  acceptance_pct because the scorer always uses the frozen test suite
  from outside the driver's workspace tree.

Phase 5b additions (AC-4, AC-5, AC-13 extended):
  AC-4: run_pytest_on_frozen_suite — real subprocess, JUnit XML parsing
  AC-5: pytest collection error (syntax error) → total=0, errors>=1, no ZeroDivisionError
  AC-13: ft-parent-of-ws, ws==ft, hardlink overlap — bidirectional + inode guard
"""
import json
import os
import sys
import textwrap
from pathlib import Path
from unittest.mock import patch

import pytest

from scoring.acceptance import score_acceptance, AcceptanceResult, RunOutcome
from scoring.acceptance import run_pytest_on_frozen_suite


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_workspace(tmp_path: Path, files: dict[str, str]) -> Path:
    """Write a minimal workspace tree; return its Path."""
    workspace = tmp_path / "workspace"
    workspace.mkdir()
    for rel, content in files.items():
        target = workspace / rel
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(content)
    return workspace


def _make_frozen_suite(tmp_path: Path, passing_count: int, total_count: int) -> Path:
    """
    Write a synthetic frozen test suite directory that can be inspected.
    Actual pytest execution is mocked; we just need the path to exist.
    """
    suite_dir = tmp_path / "frozen_tests"
    suite_dir.mkdir()
    # Write placeholder test files
    for i in range(total_count):
        (suite_dir / f"test_case_{i}.py").write_text(
            textwrap.dedent(f"""\
                def test_case_{i}():
                    pass
            """)
        )
    return suite_dir


# ---------------------------------------------------------------------------
# T-11: Post-drive scoring correctness
# ---------------------------------------------------------------------------

class TestAcceptanceScoring:
    """score_acceptance — T-11: deterministic scorer over golden workspace."""

    def test_acceptance_pct_matches_known_pass_rate(self, tmp_path: Path) -> None:
        """
        Given a workspace where 8 of 10 acceptance tests are expected to pass,
        When score_acceptance runs with a mocked pytest execution (8/10 passing),
        Then AcceptanceResult.acceptance_pct == 0.8.
        """
        # Arrange
        workspace = _make_workspace(tmp_path, {"main.py": "def hello(): return 'hello'"})
        frozen_suite = _make_frozen_suite(tmp_path, passing_count=8, total_count=10)

        mock_pytest_outcome = RunOutcome(passed=8, failed=2, total=10, errors=0)

        # Act
        with patch("scoring.acceptance.run_pytest_on_frozen_suite",
                   return_value=mock_pytest_outcome):
            result: AcceptanceResult = score_acceptance(
                workspace=workspace,
                frozen_test_suite=frozen_suite,
            )

        # Assert
        assert abs(result.acceptance_pct - 0.8) < 1e-9, (
            f"Expected acceptance_pct=0.8, got {result.acceptance_pct}"
        )

    def test_all_tests_pass_gives_pct_one(self, tmp_path: Path) -> None:
        """
        Given a workspace where all 5 acceptance tests pass,
        When score_acceptance runs,
        Then acceptance_pct == 1.0.
        """
        # Arrange
        workspace = _make_workspace(tmp_path, {"app.py": "# passing impl"})
        frozen_suite = _make_frozen_suite(tmp_path, passing_count=5, total_count=5)

        mock_outcome = RunOutcome(passed=5, failed=0, total=5, errors=0)

        # Act
        with patch("scoring.acceptance.run_pytest_on_frozen_suite",
                   return_value=mock_outcome):
            result = score_acceptance(
                workspace=workspace,
                frozen_test_suite=frozen_suite,
            )

        # Assert
        assert result.acceptance_pct == 1.0

    def test_zero_tests_pass_gives_pct_zero(self, tmp_path: Path) -> None:
        """
        Given a workspace where no acceptance tests pass,
        When score_acceptance runs,
        Then acceptance_pct == 0.0.
        """
        # Arrange
        workspace = _make_workspace(tmp_path, {"broken.py": "def nothing(): pass"})
        frozen_suite = _make_frozen_suite(tmp_path, passing_count=0, total_count=3)

        mock_outcome = RunOutcome(passed=0, failed=3, total=3, errors=0)

        # Act
        with patch("scoring.acceptance.run_pytest_on_frozen_suite",
                   return_value=mock_outcome):
            result = score_acceptance(
                workspace=workspace,
                frozen_test_suite=frozen_suite,
            )

        # Assert
        assert result.acceptance_pct == 0.0


# ---------------------------------------------------------------------------
# T-40: Frozen test suite isolation — suite absent from driver workspace
# ---------------------------------------------------------------------------

class TestAcceptanceSandboxIsolation:
    """score_acceptance — T-40: acceptance tests absent from driver workspace."""

    def test_frozen_suite_not_in_driver_workspace(self, tmp_path: Path) -> None:
        """
        Given a driver workspace and a frozen test suite at a separate path,
        When score_acceptance is called,
        Then no files from the frozen test suite are present inside the workspace.
        """
        # Arrange
        workspace = _make_workspace(tmp_path, {"impl.py": "# impl"})
        frozen_suite = _make_frozen_suite(tmp_path, passing_count=2, total_count=2)

        # The frozen_suite must NOT be a subdirectory of workspace
        assert not str(frozen_suite).startswith(str(workspace)), (
            "Frozen suite must not be nested under driver workspace"
        )

        mock_outcome = RunOutcome(passed=2, failed=0, total=2, errors=0)

        # Act
        with patch("scoring.acceptance.run_pytest_on_frozen_suite",
                   return_value=mock_outcome):
            result = score_acceptance(
                workspace=workspace,
                frozen_test_suite=frozen_suite,
            )

        # Assert — no test files leaked into driver workspace
        workspace_python_files = list(workspace.rglob("test_*.py"))
        assert workspace_python_files == [], (
            f"Acceptance test files leaked into driver workspace: {workspace_python_files}"
        )

    def test_tampered_workspace_test_does_not_inflate_score(self, tmp_path: Path) -> None:
        """
        Given a driver workspace that contains a stub 'test_tamper.py' that always passes,
        When score_acceptance runs with the frozen suite (which has 2 failing tests),
        Then acceptance_pct reflects only the frozen suite results (0/2 = 0.0),
        not the tampered workspace file.

        This is the tamper-resistance oracle from AC-13.
        """
        # Arrange — driver writes a passing stub into its own workspace
        workspace = _make_workspace(tmp_path, {
            "impl.py": "# impl",
            "test_tamper.py": "def test_always_passes(): assert True",
        })
        frozen_suite = _make_frozen_suite(tmp_path, passing_count=0, total_count=2)

        # Mock: the frozen suite runs, not the workspace tests
        mock_outcome = RunOutcome(passed=0, failed=2, total=2, errors=0)

        # Act — scorer must use frozen_test_suite, not workspace tests
        with patch("scoring.acceptance.run_pytest_on_frozen_suite",
                   return_value=mock_outcome) as patched_runner:
            result = score_acceptance(
                workspace=workspace,
                frozen_test_suite=frozen_suite,
            )

        # Assert — scorer must have invoked the runner exactly once with the
        # frozen suite path. The call site at scoring/acceptance.py:259 passes
        # the suite as the first positional arg; if that contract changes, this
        # assertion must change with it (don't paper over a contract drift with
        # a conditional). Per Phase-5{a,b,c}-followup H-2: no `if x is not None`
        # softening — a tamper test that silently no-ops on signature drift
        # gives false confidence.
        assert patched_runner.call_count == 1, (
            f"run_pytest_on_frozen_suite must be called exactly once; "
            f"got call_count={patched_runner.call_count}"
        )
        call_args = patched_runner.call_args
        called_suite_path = call_args.args[0]
        assert Path(called_suite_path).resolve() == frozen_suite.resolve(), (
            f"Scorer must run the frozen suite, not workspace files. "
            f"Called with: {called_suite_path!r}; expected: {frozen_suite!r}"
        )

        # Score must reflect frozen suite (0/2), not tampered workspace stub
        assert result.acceptance_pct == 0.0

    def test_scorer_raises_on_missing_frozen_suite(self, tmp_path: Path) -> None:
        """
        Given a frozen_test_suite path that does not exist,
        When score_acceptance is called,
        Then it raises an exception (not silently produces 0.0).
        """
        # Arrange
        workspace = _make_workspace(tmp_path, {"impl.py": ""})
        nonexistent_suite = tmp_path / "does_not_exist"

        # Act + Assert
        with pytest.raises(Exception):
            score_acceptance(
                workspace=workspace,
                frozen_test_suite=nonexistent_suite,
            )


# ---------------------------------------------------------------------------
# Helpers for Phase 5b real-subprocess tests
# ---------------------------------------------------------------------------

def _make_real_workspace(tmp_path: Path) -> Path:
    """
    Write a minimal workspace with a shortener module that satisfies 2 of 3
    frozen tests: shorten() works for a non-empty string but raises for empty.
    The third test (for very-long strings) will fail because truncation is absent.
    """
    ws = tmp_path / "workspace"
    ws.mkdir()
    (ws / "shortener.py").write_text(
        textwrap.dedent("""\
            def shorten(url: str) -> str:
                if not url:
                    raise ValueError("url must not be empty")
                # NOTE: no truncation — the 'long url' test will fail
                return "http://short.ly/" + url[:6]
        """)
    )
    return ws


def _make_real_frozen_suite(tmp_path: Path) -> Path:
    """
    Write a frozen test suite with exactly 3 tests:
      test_shorten_normal   — passes (normal URL)
      test_shorten_empty    — passes (empty raises ValueError)
      test_shorten_long     — FAILS (expects truncation the workspace impl omits)

    Tests import from WORKSPACE env var so they work regardless of cwd.
    """
    suite = tmp_path / "frozen_suite"
    suite.mkdir()
    (suite / "test_shortener.py").write_text(
        textwrap.dedent("""\
            import sys, os
            sys.path.insert(0, os.environ["WORKSPACE"])
            import shortener

            def test_shorten_normal():
                result = shortener.shorten("https://example.com/path")
                assert result.startswith("http://short.ly/")

            def test_shorten_empty():
                import pytest
                with pytest.raises(ValueError):
                    shortener.shorten("")

            def test_shorten_long():
                long_url = "x" * 200
                result = shortener.shorten(long_url)
                # Expects truncation to exactly 20 chars total — impl omits this
                assert len(result) <= 20, f"Expected truncation, got len={len(result)}"
        """)
    )
    return suite


def _make_syntax_error_workspace(tmp_path: Path) -> Path:
    """
    Workspace whose shortener.py has a syntax error so pytest cannot import it.
    """
    ws = tmp_path / "ws_broken"
    ws.mkdir()
    (ws / "shortener.py").write_text(
        "def shorten(:"  # intentional syntax error
    )
    return ws


def _make_collection_error_frozen_suite(tmp_path: Path) -> Path:
    """
    Frozen suite that imports from the workspace's shortener module.
    When the workspace has a syntax error, pytest fails at collection time.
    """
    suite = tmp_path / "suite_import_ws"
    suite.mkdir()
    (suite / "test_uses_workspace.py").write_text(
        textwrap.dedent("""\
            import sys, os
            sys.path.insert(0, os.environ["WORKSPACE"])
            import shortener  # will trigger SyntaxError at collection

            def test_shorten_something():
                assert shortener.shorten("x") == "http://short.ly/x"
        """)
    )
    return suite


# ---------------------------------------------------------------------------
# AC-4: run_pytest_on_frozen_suite real subprocess + JUnit XML parsing
# ---------------------------------------------------------------------------

class TestRunPytestOnFrozenSuiteIntegration:
    """
    AC-4 — run_pytest_on_frozen_suite invokes real pytest via subprocess,
    parses JUnit XML, and returns correct pass/fail/total counts.
    """

    def test_ac4_two_pass_one_fail_counts(self, tmp_path: Path) -> None:
        """
        AC-4: Given a workspace satisfying 2 of 3 frozen tests,
        When run_pytest_on_frozen_suite is called (real subprocess),
        Then the returned object has .passed=2 .failed=1 .total=3.

        Negative-assertion gate: assert .failed == 1, not just .total == 3.
        If all passed, .failed would be 0 — so this distinguishes AC enforced
        from a default/stub that always returns 3/3.
        """
        # Arrange — real workspace + real frozen suite (no mocking of pytest)
        workspace = _make_real_workspace(tmp_path)
        suite = _make_real_frozen_suite(tmp_path)

        # Act
        outcome = run_pytest_on_frozen_suite(
            suite_path=suite,
            workspace=workspace,
        )

        # Assert
        assert outcome.total == 3, (
            f"Expected total=3, got {outcome.total}"
        )
        assert outcome.passed == 2, (
            f"Expected passed=2, got {outcome.passed}"
        )
        assert outcome.failed == 1, (
            f"Expected failed=1, got {outcome.failed} — "
            "distinguishes partial pass from full pass or zero-pass"
        )

    def test_ac4_passed_plus_failed_equals_total(self, tmp_path: Path) -> None:
        """
        AC-4 invariant: passed + failed == total (no silent count leak).
        """
        # Arrange
        workspace = _make_real_workspace(tmp_path)
        suite = _make_real_frozen_suite(tmp_path)

        # Act
        outcome = run_pytest_on_frozen_suite(suite_path=suite, workspace=workspace)

        # Assert — structural invariant on the returned object
        assert outcome.passed + outcome.failed == outcome.total, (
            f"passed({outcome.passed}) + failed({outcome.failed}) != total({outcome.total})"
        )

    def test_ac4_workspace_env_var_is_resolved_path(self, tmp_path: Path) -> None:
        """
        AC-4: The WORKSPACE env var passed to pytest must point at workspace.resolve(),
        not a relative or non-canonical path. We verify this indirectly by confirming
        that the frozen tests can successfully import from the workspace (they rely on
        sys.path.insert(0, os.environ["WORKSPACE"])).
        """
        # Arrange
        workspace = _make_real_workspace(tmp_path)
        suite = _make_real_frozen_suite(tmp_path)

        # Act — if WORKSPACE is wrong, pytest would error on import, .errors would be > 0
        outcome = run_pytest_on_frozen_suite(suite_path=suite, workspace=workspace)

        # Assert — at least the passing tests ran, so import worked
        assert outcome.passed >= 1, (
            f"Expected at least 1 passing test (import worked), got passed={outcome.passed}. "
            "WORKSPACE env var may not resolve correctly."
        )


# ---------------------------------------------------------------------------
# AC-5: Collection error → total=0, errors>=1, no ZeroDivisionError
# ---------------------------------------------------------------------------

class TestRunPytestCollectionError:
    """
    AC-5 — when a workspace file has a syntax error and the frozen suite
    imports it, pytest fails at collection. The scorer must handle this
    gracefully: total=0, errors>=1, no ZeroDivisionError in score_acceptance.
    """

    def test_ac5_syntax_error_gives_zero_total_and_errors(self, tmp_path: Path) -> None:
        """
        AC-5: Given a workspace with a syntax-error shortener.py,
        When run_pytest_on_frozen_suite is called,
        Then returned object has .total=0 .passed=0 .failed=0 .errors>=1.

        Negative-assertion gate: assert .errors >= 1 (not just assert .total == 0).
        Without the errors field, a stub returning all-zeros would pass. The
        .errors >= 1 distinguishes "collection error properly reported" from
        "scorer returns zeros for any unhandled path".
        """
        # Arrange
        workspace = _make_syntax_error_workspace(tmp_path)
        suite = _make_collection_error_frozen_suite(tmp_path)

        # Act — real subprocess; pytest will fail to import shortener.py
        outcome = run_pytest_on_frozen_suite(suite_path=suite, workspace=workspace)

        # Assert
        assert outcome.total == 0, (
            f"Expected total=0 on collection error, got {outcome.total}"
        )
        assert outcome.passed == 0, (
            f"Expected passed=0 on collection error, got {outcome.passed}"
        )
        assert outcome.failed == 0, (
            f"Expected failed=0 on collection error, got {outcome.failed}"
        )
        assert outcome.errors >= 1, (
            f"Expected errors>=1 to signal collection failure, got {outcome.errors}. "
            "This is the negative-assertion gate: errors field must be populated."
        )

    def test_ac5_score_acceptance_returns_zero_pct_no_division_error(
        self, tmp_path: Path
    ) -> None:
        """
        AC-5: When a collection error propagates up to score_acceptance,
        the returned AcceptanceResult has acceptance_pct=0.0 (no ZeroDivisionError).

        Negative-assertion gate: check type(result) is AcceptanceResult, not Exception.
        The scorer must not crash — it must return a valid result with pct=0.0.
        """
        # Arrange
        workspace = _make_syntax_error_workspace(tmp_path)
        suite = _make_collection_error_frozen_suite(tmp_path)

        # Act — must not raise ZeroDivisionError or any other exception
        result = score_acceptance(workspace=workspace, frozen_test_suite=suite)

        # Assert
        assert isinstance(result, AcceptanceResult), (
            f"Expected AcceptanceResult, got {type(result)}"
        )
        assert result.acceptance_pct == 0.0, (
            f"Expected acceptance_pct=0.0 on collection error, got {result.acceptance_pct}. "
            "ZeroDivisionError guard: total=0 must not cause a crash."
        )
        # The errors field on AcceptanceResult must reflect the collection failure
        assert result.errors >= 1, (
            f"Expected AcceptanceResult.errors>=1 on collection error, got {result.errors}"
        )


# ---------------------------------------------------------------------------
# AC-13 extended: bidirectional ancestor guard + ws==ft + hardlink overlap
# ---------------------------------------------------------------------------

class TestAC13BidirectionalAndHardlink:
    """
    AC-13 Phase 5b — three new direction-tests plus a hardlink-tampering test.

    The baseline (ws-parent-of-ft) is already covered by
    test_frozen_suite_not_in_driver_workspace above — NOT duplicated here.
    """

    def test_ac13_ft_parent_of_ws_raises_value_error(self, tmp_path: Path) -> None:
        """
        AC-13 ft-parent-of-ws: frozen_test_suite is an ancestor of workspace.

        Given frozen_test_suite=tmp_path/"outer" and workspace=tmp_path/"outer"/"inner",
        When score_acceptance is called,
        Then it raises ValueError (not TypeError, not RuntimeError, not silent pass).

        Negative-assertion gate: assert exact type ValueError. A bare Exception catch
        would pass even if the scorer returns 0.0 silently.
        """
        # Arrange
        outer = tmp_path / "outer"
        inner = outer / "inner"
        outer.mkdir()
        inner.mkdir()
        (inner / "impl.py").write_text("# impl")

        # Create a minimal frozen_suite inside outer (not inner) to avoid ws-parent-of-ft
        suite_file = outer / "test_something.py"
        suite_file.write_text("def test_noop(): pass")

        # Act + Assert — must be specifically ValueError
        with pytest.raises(ValueError) as exc_info:
            score_acceptance(workspace=inner, frozen_test_suite=outer)

        # The error message must identify both paths (operator-readable)
        error_msg = str(exc_info.value)
        assert str(outer) in error_msg or "frozen" in error_msg.lower() or "ancestor" in error_msg.lower(), (
            f"ValueError message should name both paths or explain AC-13 isolation. Got: {error_msg!r}"
        )

    def test_ac13_ws_equals_ft_raises_value_error(self, tmp_path: Path) -> None:
        """
        AC-13 ws==ft: identical path passed for both workspace and frozen_test_suite.

        Given workspace == frozen_test_suite (same Path),
        When score_acceptance is called,
        Then it raises ValueError.

        Negative-assertion gate: assert ValueError, not any other exception type.
        An implementation that checks only path prefix might silently accept ws==ft.
        """
        # Arrange — single directory used as both workspace and suite
        shared = tmp_path / "shared"
        shared.mkdir()
        (shared / "impl.py").write_text("# impl")

        # Act + Assert — same path for both args
        with pytest.raises(ValueError):
            score_acceptance(workspace=shared, frozen_test_suite=shared)

    @pytest.mark.skipif(
        sys.platform == "win32",
        reason="hardlink test requires Linux/macOS — Windows skipped",
    )
    def test_ac13_hardlink_overlap_raises_runtime_error(self, tmp_path: Path) -> None:
        """
        AC-13 hardlink overlap: a file in frozen_test_suite shares an inode with
        a file in workspace (different path strings, same (st_dev, st_ino)).

        SCOPE: This test validates Layer 2 of the AC-13 layered defense — the
        host-side Python `_collect_inodes` pre-flight check in
        scoring/acceptance.py. It does NOT exercise Layer 3 (the Phase 5d
        container RO bind-mount with no CAP_DAC_OVERRIDE). That container
        layer has its own integration tests under tests/harness/ once the
        runtime is wired up; this unit test covers only the host pre-flight.

        Phase-5{a,b,c}-followup H-1 deviation: review recommended adding
        `skipif(shutil.which("docker") is None)` to gate this test on Docker
        presence. We declined — the test exercises a pure-Python guard that
        does not need a container runtime, and skipping it on dev machines
        without Docker would silently drop the only assertion that proves
        Layer 2 actually fires. The right cure for the underlying concern
        ("operator might think this proves Phase 5d also works") is the SCOPE
        block above, not skipping the test.

        Given a hardlink from frozen_test_suite/test_probe.py into workspace/test_probe.py,
        When score_acceptance is called,
        Then it raises RuntimeError (not ValueError — different failure class),
        AND the error message mentions "hardlink" or "shared inode" or equivalent,
        AND the error is raised BEFORE run_pytest_on_frozen_suite is invoked.

        Negative-assertion gate (two parts):
        1. assert RuntimeError, not ValueError — confirms the right error class
        2. assert run_pytest_on_frozen_suite was NOT called — confirms pre-flight check
        """
        # Arrange
        ws = tmp_path / "workspace"
        suite = tmp_path / "frozen_suite"
        ws.mkdir()
        suite.mkdir()
        (ws / "impl.py").write_text("# impl")

        # Create the file in the suite, then hardlink it into workspace
        suite_file = suite / "test_probe.py"
        suite_file.write_text("def test_noop(): pass")
        ws_file = ws / "test_probe.py"
        os.link(suite_file, ws_file)  # same inode, different path

        # Verify the hardlink exists (sanity check for the fixture itself)
        suite_stat = suite_file.stat()
        ws_stat = ws_file.stat()
        assert (suite_stat.st_dev, suite_stat.st_ino) == (ws_stat.st_dev, ws_stat.st_ino), (
            "Test fixture setup failed — hardlink not created properly"
        )

        # Act + Assert — RuntimeError, not ValueError
        with patch("scoring.acceptance.run_pytest_on_frozen_suite") as mock_runner:
            with pytest.raises(RuntimeError) as exc_info:
                score_acceptance(workspace=ws, frozen_test_suite=suite)

            # run_pytest_on_frozen_suite must NOT have been called (pre-flight check)
            assert mock_runner.call_count == 0, (
                f"run_pytest_on_frozen_suite must not be called when hardlink is detected. "
                f"Got call_count={mock_runner.call_count}"
            )

        # Error message must identify the hardlink situation
        error_msg = str(exc_info.value).lower()
        assert any(keyword in error_msg for keyword in ("hardlink", "shared inode", "inode", "link")), (
            f"RuntimeError message must mention hardlink/inode so operator knows what was caught. "
            f"Got: {exc_info.value!r}"
        )


class TestExitCodeGuards:
    """
    HIGH-2 forensics: pytest exit-code guards in run_pytest_on_frozen_suite.

    Per _pytest.config.ExitCode (pytest 9.0.2, empirically verified):
      0 OK, 1 TESTS_FAILED, 2 INTERRUPTED, 3 INTERNAL_ERROR,
      4 USAGE_ERROR, 5 NO_TESTS_COLLECTED.
    Negative returncode = process killed by signal (e.g. -9 SIGKILL on OOM).

    These tests verify the guard branches that are hard to trigger from a
    real pytest subprocess: the runtime cannot reliably produce internal
    errors / SIGKILL on demand, and a missing XML on a returncode==0 run
    requires a tampered subprocess. Mocking subprocess.run is the only
    practical oracle.
    """

    def _mk_suite(self, tmp_path: Path) -> Path:
        """Minimal valid frozen suite — content irrelevant since subprocess is mocked."""
        suite = tmp_path / "frozen"
        suite.mkdir()
        (suite / "test_smoke.py").write_text("def test_ok(): assert True\n")
        return suite

    def _mk_workspace(self, tmp_path: Path) -> Path:
        ws = tmp_path / "workspace"
        ws.mkdir()
        return ws

    def test_returncode_3_internal_error_raises_with_diagnostic(self, tmp_path):
        """Pytest INTERNAL_ERROR (3) — XML may be partial/missing, must not be trusted."""
        suite = self._mk_suite(tmp_path)
        ws = self._mk_workspace(tmp_path)

        from unittest.mock import MagicMock
        mock_proc = MagicMock()
        mock_proc.returncode = 3
        mock_proc.stderr = b"INTERNALERROR> pytest crashed"

        with patch("scoring.acceptance.subprocess.run", return_value=mock_proc):
            with pytest.raises(RuntimeError) as exc_info:
                run_pytest_on_frozen_suite(suite, ws)

        msg = str(exc_info.value).lower()
        assert "internal error" in msg, (
            f"returncode=3 must surface as 'internal error', not generic. Got: {exc_info.value!r}"
        )
        assert "3" in str(exc_info.value), "Code number must be in message for grep-ability"

    def test_returncode_4_usage_error_raises_with_diagnostic(self, tmp_path):
        """Pytest USAGE_ERROR (4) — invalid CLI args, XML unreliable."""
        suite = self._mk_suite(tmp_path)
        ws = self._mk_workspace(tmp_path)

        from unittest.mock import MagicMock
        mock_proc = MagicMock()
        mock_proc.returncode = 4
        mock_proc.stderr = b"ERROR: usage: pytest [options]"

        with patch("scoring.acceptance.subprocess.run", return_value=mock_proc):
            with pytest.raises(RuntimeError) as exc_info:
                run_pytest_on_frozen_suite(suite, ws)

        msg = str(exc_info.value).lower()
        assert "usage error" in msg, (
            f"returncode=4 must surface as 'usage error'. Got: {exc_info.value!r}"
        )
        assert "4" in str(exc_info.value)

    def test_returncode_5_no_tests_raises_with_diagnostic(self, tmp_path):
        """Pytest NO_TESTS_COLLECTED (5) — frozen suite is empty/misconfigured."""
        suite = self._mk_suite(tmp_path)
        ws = self._mk_workspace(tmp_path)

        from unittest.mock import MagicMock
        mock_proc = MagicMock()
        mock_proc.returncode = 5
        mock_proc.stderr = b""

        with patch("scoring.acceptance.subprocess.run", return_value=mock_proc):
            with pytest.raises(RuntimeError) as exc_info:
                run_pytest_on_frozen_suite(suite, ws)

        msg = str(exc_info.value).lower()
        assert "no tests" in msg or "collected" in msg, (
            f"returncode=5 must mention no-tests-collected. Got: {exc_info.value!r}"
        )
        assert "5" in str(exc_info.value)

    def test_negative_returncode_signal_death_raises_with_signal_name(self, tmp_path):
        """Negative returncode = killed by signal. Must surface signal name (e.g., SIGKILL on OOM)."""
        suite = self._mk_suite(tmp_path)
        ws = self._mk_workspace(tmp_path)

        from unittest.mock import MagicMock
        mock_proc = MagicMock()
        mock_proc.returncode = -9  # SIGKILL
        mock_proc.stderr = b""

        with patch("scoring.acceptance.subprocess.run", return_value=mock_proc):
            with pytest.raises(RuntimeError) as exc_info:
                run_pytest_on_frozen_suite(suite, ws)

        msg = str(exc_info.value)
        assert "SIGKILL" in msg, (
            f"-9 returncode must be diagnosed as SIGKILL so OOM is operator-visible. "
            f"Got: {exc_info.value!r}"
        )
        assert "-9" in msg, "returncode must be in message for grep-ability"

    def test_missing_xml_raises_runtime_error(self, tmp_path):
        """returncode==0 but no JUnit XML produced — pytest tampered or filesystem failure."""
        suite = self._mk_suite(tmp_path)
        ws = self._mk_workspace(tmp_path)

        from unittest.mock import MagicMock

        # Capture the xml_path the SUT passes to subprocess so we can ensure it's gone.
        original_run = None

        def fake_run(*args, **kwargs):
            # args[0] is the command list; --junitxml=PATH is in there.
            cmd = args[0]
            for token in cmd:
                if isinstance(token, str) and token.startswith("--junitxml="):
                    xml_path = token.split("=", 1)[1]
                    # Delete the XML pre-emptively so the SUT's existence check fails.
                    try:
                        os.unlink(xml_path)
                    except FileNotFoundError:
                        pass
                    break
            mock = MagicMock()
            mock.returncode = 0
            mock.stderr = b""
            return mock

        with patch("scoring.acceptance.subprocess.run", side_effect=fake_run):
            with pytest.raises(RuntimeError) as exc_info:
                run_pytest_on_frozen_suite(suite, ws)

        msg = str(exc_info.value).lower()
        assert "xml" in msg or "junit" in msg, (
            f"Missing XML must surface as XML/JUnit error. Got: {exc_info.value!r}"
        )
