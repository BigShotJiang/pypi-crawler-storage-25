"""
Tests for scoring/semgrep.py — Sub-phase C of TDD for ShipTeam Benchmark Harness Phase 2 Part 2.

Test ID Renumbering Note
------------------------
Sub-phase B (test_mutation.py) used T-55/T-56/T-57 for mutmut-timeout and AC-19 expanded
conditions.  Sub-phase C consumes the following IDs from the test matrix:

  T-49  (P1, AC-17)  — semgrep not on PATH → SemgrepResult.error == "tool_missing"
  T-58  (P0, AC-21)  — cross-sweep cache invalidation (stale sweep_id fires deletion)
  T-60  (P1, AC-2/R4) — --output tempfile in argv; scorer reads tempfile NOT stdout
  T-61  (P1, AC-2)   — 9 ATD severity round-trip + unknown_severities overflow bucket

Plus NEW IDs allocated in this sub-phase (extending the matrix past T-61):

  T-62  (P0, AC-20)  — SHA validator happy path: 40-char hex SHA accepted, no error
  T-63  (P0, AC-20)  — SHA validator rejects mutable refs (main, HEAD, v1.2, etc.)
  T-64  (P0, AC-21)  — cache reuse within same sweep_id (HTTP mock asserts 1 GET)
  T-65  (P1, AC-17)  — malformed JSON in tempfile → error == "semgrep_output_malformed"
  T-66  (P1, AC-17)  — subprocess.TimeoutExpired → error == "semgrep_timeout"

Semgrep JSON schema (ATD source: semgrep/semgrep-interfaces/semgrep_output_v1.atd):
  {"results": [{"check_id": "...", "extra": {"severity": "HIGH", ...}, ...}], "errors": [...]}
  Severity lives at results[i].extra.severity.
  Zero-findings emits {"results": [], "errors": []}.
  9 match_severity variants: CRITICAL, HIGH, MEDIUM, LOW, INFO, ERROR, WARNING, EXPERIMENT, INVENTORY
  Backward-compat semantics: ERROR→HIGH, WARNING→MEDIUM (but emitted as ERROR/WARNING in JSON).
"""

import json
import subprocess
import tempfile
import urllib.error
from pathlib import Path
from unittest.mock import MagicMock, call, patch

import pytest

from scoring.semgrep import (
    RulesetRefError,
    SemgrepCache,
    SemgrepResult,
    score_semgrep,
)

# ---------------------------------------------------------------------------
# Constants / fixture data
# ---------------------------------------------------------------------------

_SHA_40 = "a" * 40  # valid 40-char hex SHA
_RULESET_URL_VALID = (
    f"https://raw.githubusercontent.com/owner/repo/{_SHA_40}/rules.yml"
)

# Minimal semgrep JSON with zero findings
_ZERO_FINDINGS_JSON = json.dumps({"results": [], "errors": []})

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _semgrep_json(findings: list[dict]) -> str:
    """Build a minimal semgrep JSON output string from a list of severity dicts."""
    results = [
        {
            "check_id": f"rule.{i}",
            "path": "src/app.py",
            "start": {"line": i, "col": 1},
            "end": {"line": i, "col": 10},
            "extra": {"severity": sev, "message": f"finding {i}", "metadata": {}},
        }
        for i, sev in enumerate(findings)
    ]
    return json.dumps({"results": results, "errors": []})


def _make_cache(tmp_path: Path, sweep_id: str = "sweep-001") -> SemgrepCache:
    """Construct a SemgrepCache backed by a real tmp_path directory."""
    cache_dir = tmp_path / "semgrep_cache"
    cache_dir.mkdir(parents=True, exist_ok=True)
    return SemgrepCache(cache_dir=cache_dir, sweep_id=sweep_id)


def _precache_ruleset(cache: SemgrepCache, url: str, content: str = "rules: []\n") -> Path:
    """Pre-populate cache for a URL so fetch_or_reuse skips the network entirely.
    Uses the same hash computation as the impl (full sha256 hex digest).
    """
    import hashlib
    url_hash = hashlib.sha256(url.encode("utf-8")).hexdigest()
    cache_file = cache.cache_dir / f"{url_hash}.yml"
    cache_file.write_text(content)
    return cache_file


def _mock_opener(content: bytes = b"rules: []\n") -> MagicMock:
    """Build a MagicMock that satisfies the _build_opener + opener.open(url) contract.
    Returns an opener whose .open() returns a context manager whose .read() returns content.
    Use via: with patch("scoring.semgrep._build_opener", return_value=_mock_opener()).
    """
    mock_resp_cm = MagicMock()
    mock_resp_cm.__enter__ = MagicMock(
        return_value=MagicMock(read=MagicMock(return_value=content))
    )
    mock_resp_cm.__exit__ = MagicMock(return_value=False)
    opener = MagicMock()
    opener.open.return_value = mock_resp_cm
    return opener


def _mock_completed_process(returncode: int = 0) -> MagicMock:
    """Return a mock CompletedProcess with given returncode."""
    proc = MagicMock()
    proc.returncode = returncode
    proc.stdout = b""
    proc.stderr = b""
    return proc


# ---------------------------------------------------------------------------
# T-49 (P1, AC-17): semgrep not on PATH
# ---------------------------------------------------------------------------


class TestToolMissing:
    """T-49: When semgrep is not installed, score_semgrep returns a fail-closed result."""

    def test_t49_semgrep_not_on_path_returns_tool_missing(self, tmp_path: Path) -> None:
        """
        T-49 (P1, AC-17): FileNotFoundError from subprocess → error='tool_missing'.
        Uses a local ruleset path to bypass URL fetch (which has its own structured
        error key 'ruleset_fetch_failed', tested separately in T-67).
        """
        cache = _make_cache(tmp_path)
        local_ruleset = tmp_path / "rules.yml"
        local_ruleset.write_text("rules: []\n")

        with patch("subprocess.run", side_effect=FileNotFoundError("semgrep not found")):
            result = score_semgrep(
                workspace=tmp_path,
                ruleset=str(local_ruleset),
                cache=cache,
            )

        assert result.error == "tool_missing"
        assert result.tool_name == "semgrep"
        assert result.by_severity == {}


# ---------------------------------------------------------------------------
# T-62 (P0, AC-20): SHA validator happy path
# ---------------------------------------------------------------------------


class TestShaValidatorHappyPath:
    """T-62: A URL with a 40-char hex SHA is accepted; ruleset_commit is populated."""

    def test_t62_valid_40char_sha_sets_ruleset_commit(self, tmp_path: Path) -> None:
        """T-62 (P0, AC-20): 40-char lowercase hex SHA extracted into ruleset_commit."""
        cache = _make_cache(tmp_path)
        sha = "b" * 40
        url = f"https://raw.githubusercontent.com/org/repo/{sha}/semgrep.yml"

        # Patch urllib fetch so the cache returns a local file, and subprocess so semgrep "runs"
        local_rules = tmp_path / "rules.yml"
        local_rules.write_text("rules: []")

        proc = _mock_completed_process(returncode=0)

        with patch("scoring.semgrep._build_opener", return_value=_mock_opener()), \
             patch("subprocess.run", return_value=proc) as mock_run:
            # Make subprocess write an empty findings tempfile
            def _write_tempfile_side_effect(*args, **kwargs):
                argv = args[0] if args else kwargs.get("args", [])
                for i, arg in enumerate(argv):
                    if arg == "--output" and i + 1 < len(argv):
                        Path(argv[i + 1]).write_text(_ZERO_FINDINGS_JSON)
                        break
                return proc

            mock_run.side_effect = _write_tempfile_side_effect

            result = score_semgrep(workspace=tmp_path, ruleset=url, cache=cache)

        assert result.error is None
        assert result.ruleset_commit == sha


# ---------------------------------------------------------------------------
# T-63 (P0, AC-20): SHA validator rejects mutable refs
# ---------------------------------------------------------------------------


class TestShaValidatorRejectsMutableRefs:
    """T-63: Mutable or short refs in the URL raise RulesetRefError before any I/O."""

    @pytest.mark.parametrize("ref", [
        "main",
        "HEAD",
        "v1.2",
        "release/2024",
        "abc1234",      # short SHA (7 chars)
        "develop",
        "feature/my-branch",
    ])
    def test_t63_mutable_ref_raises_ruleset_ref_error(
        self, tmp_path: Path, ref: str
    ) -> None:
        """T-63 (P0, AC-20): Refs that are not 40-char hex SHA raise RulesetRefError."""
        cache = _make_cache(tmp_path)
        url = f"https://raw.githubusercontent.com/owner/repo/{ref}/rules.yml"

        with patch("subprocess.run") as mock_run, \
             patch("scoring.semgrep._build_opener") as mock_build_opener:
            with pytest.raises(RulesetRefError) as exc_info:
                score_semgrep(workspace=tmp_path, ruleset=url, cache=cache)

            # Validator fires BEFORE semgrep is invoked and BEFORE any HTTP opener built
            mock_run.assert_not_called()
            mock_build_opener.assert_not_called()

        exc = exc_info.value
        # ref attribute must contain the offending ref string
        assert exc.ref == ref

    def test_t63_ruleset_ref_error_carries_url(self, tmp_path: Path) -> None:
        """T-63 (P0, AC-20): RulesetRefError exposes the full URL for diagnostics."""
        cache = _make_cache(tmp_path)
        url = "https://raw.githubusercontent.com/owner/repo/main/rules.yml"

        with patch("subprocess.run"), patch("scoring.semgrep._build_opener"):
            with pytest.raises(RulesetRefError) as exc_info:
                score_semgrep(workspace=tmp_path, ruleset=url, cache=cache)

        exc = exc_info.value
        assert exc.url == url


# ---------------------------------------------------------------------------
# T-64 (P0, AC-21): cache reuse within same sweep
# ---------------------------------------------------------------------------


class TestCacheReuseWithinSweep:
    """T-64: Second call within same sweep_id reuses cached file; HTTP GET called once."""

    def test_t64_second_call_reuses_cache_no_extra_http(self, tmp_path: Path) -> None:
        """T-64 (P0, AC-21): HTTP fetch occurs once; second call returns cache_hit=True."""
        cache = _make_cache(tmp_path, sweep_id="S1")
        url = _RULESET_URL_VALID
        proc = _mock_completed_process(returncode=0)

        def _write_tempfile(argv_or_args, **kwargs):
            argv = argv_or_args if isinstance(argv_or_args, list) else list(argv_or_args)
            for i, arg in enumerate(argv):
                if arg == "--output" and i + 1 < len(argv):
                    Path(argv[i + 1]).write_text(_ZERO_FINDINGS_JSON)
                    break
            return proc

        mock_opener = _mock_opener()
        with patch("scoring.semgrep._build_opener", return_value=mock_opener), \
             patch("subprocess.run", side_effect=_write_tempfile):

            result1 = score_semgrep(workspace=tmp_path, ruleset=url, cache=cache)
            result2 = score_semgrep(workspace=tmp_path, ruleset=url, cache=cache)

        # HTTP fetch must have been called exactly once across both invocations
        assert mock_opener.open.call_count == 1

        # First call: cache miss (fresh download)
        assert result1.cache_hit is False

        # Second call: cache hit (reuse)
        assert result2.cache_hit is True


# ---------------------------------------------------------------------------
# T-58 (P0, AC-21): cross-sweep cache invalidation
# ---------------------------------------------------------------------------


class TestCrossSwepInvalidation:
    """T-58: Cache populated under sweep_id S1 is invalidated when sweep_id=S2 is used."""

    def test_t58_stale_sweep_deletes_cached_files_and_redownloads(
        self, tmp_path: Path
    ) -> None:
        """T-58 (P0, AC-21): Old sweep cache is cleared; fresh download occurs."""
        cache_dir = tmp_path / "semgrep_cache"
        cache_dir.mkdir()

        # Seed a cache directory as if sweep S1 ran before
        cache_s1 = SemgrepCache(cache_dir=cache_dir, sweep_id="S1")
        url = _RULESET_URL_VALID
        proc = _mock_completed_process(returncode=0)

        def _write_tempfile(argv_or_args, **kwargs):
            argv = argv_or_args if isinstance(argv_or_args, list) else list(argv_or_args)
            for i, arg in enumerate(argv):
                if arg == "--output" and i + 1 < len(argv):
                    Path(argv[i + 1]).write_text(_ZERO_FINDINGS_JSON)
                    break
            return proc

        with patch("scoring.semgrep._build_opener", return_value=_mock_opener()), \
             patch("subprocess.run", side_effect=_write_tempfile):
            score_semgrep(workspace=tmp_path, ruleset=url, cache=cache_s1)

        # After S1 run, cache_dir should contain at least one cached file
        cached_files_after_s1 = list(cache_dir.glob("*.yml"))
        assert len(cached_files_after_s1) >= 1, "S1 run must leave cached ruleset files"
        # H-1 fix: snapshot the S1 files so we can assert they're DELETED (not just
        # rewritten) after the S2 cross-sweep invalidation.
        s1_file_contents = {f: f.read_bytes() for f in cached_files_after_s1}

        # Now run with a new sweep_id=S2 using the SAME cache_dir.
        # Construction ITSELF must invalidate S1's files before S2 downloads.
        cache_s2 = SemgrepCache(cache_dir=cache_dir, sweep_id="S2")

        # Assert the S1 files are GONE (deleted, not overwritten) post-construction —
        # the sentinel mismatch triggered invalidate() which glob-unlinks all *.yml.
        for f, _ in s1_file_contents.items():
            assert not f.exists(), (
                f"Expected S1 cached file {f.name} to be deleted by cross-sweep "
                f"invalidation; it still exists (silent-overwrite impl would pass without this)"
            )

        mock_opener_s2 = _mock_opener()
        with patch("scoring.semgrep._build_opener", return_value=mock_opener_s2), \
             patch("subprocess.run", side_effect=_write_tempfile):
            result_s2 = score_semgrep(workspace=tmp_path, ruleset=url, cache=cache_s2)

        # S2 must re-download (not cache_hit on first use after invalidation)
        assert result_s2.cache_hit is False
        # HTTP fetch must have occurred for S2
        assert mock_opener_s2.open.call_count == 1


# ---------------------------------------------------------------------------
# T-60 (P1, AC-2 / R4): --output tempfile; scorer reads tempfile not stdout
# ---------------------------------------------------------------------------


class TestOutputTempfile:
    """T-60: Scorer passes --output <tempfile> to semgrep and reads that file, not stdout."""

    def test_t60_argv_contains_output_and_json_flags(self, tmp_path: Path) -> None:
        """T-60 (P1, AC-2/R4): subprocess argv includes --output and --json."""
        cache = _make_cache(tmp_path)
        captured_argv: list[list[str]] = []
        proc = _mock_completed_process(returncode=0)

        def _capture_and_write(argv_or_args, **kwargs):
            argv = list(argv_or_args)
            captured_argv.append(argv)
            # Write valid JSON to the tempfile path specified via --output
            for i, arg in enumerate(argv):
                if arg == "--output" and i + 1 < len(argv):
                    Path(argv[i + 1]).write_text(_ZERO_FINDINGS_JSON)
                    break
            return proc

        with patch("scoring.semgrep._build_opener", return_value=_mock_opener()), \
             patch("subprocess.run", side_effect=_capture_and_write):
            score_semgrep(workspace=tmp_path, ruleset=_RULESET_URL_VALID, cache=cache)

        assert len(captured_argv) == 1, "semgrep must be invoked exactly once"
        argv = captured_argv[0]

        assert "--json" in argv, "argv must contain --json"
        assert "--output" in argv, "argv must contain --output"

        # The value after --output must be a path (tempfile)
        output_idx = argv.index("--output")
        assert output_idx + 1 < len(argv), "--output must be followed by a path argument"
        output_path_str = argv[output_idx + 1]
        assert output_path_str, "--output path must not be empty"

    def test_t60_scorer_does_not_use_stdout_attribute(self, tmp_path: Path) -> None:
        """T-60 (P1, R4): mock_proc.stdout must NOT be accessed (R4 stdout-interleave defense)."""
        cache = _make_cache(tmp_path)
        proc = MagicMock()
        proc.returncode = 0
        # Mark stdout as a sentinel — if it is read, the test will catch it
        stdout_sentinel = MagicMock(name="stdout_sentinel")
        proc.stdout = stdout_sentinel

        def _write_tempfile(argv_or_args, **kwargs):
            argv = list(argv_or_args)
            for i, arg in enumerate(argv):
                if arg == "--output" and i + 1 < len(argv):
                    Path(argv[i + 1]).write_text(_ZERO_FINDINGS_JSON)
                    break
            return proc

        with patch("scoring.semgrep._build_opener", return_value=_mock_opener()), \
             patch("subprocess.run", side_effect=_write_tempfile):

            score_semgrep(workspace=tmp_path, ruleset=_RULESET_URL_VALID, cache=cache)

        # stdout sentinel must not have been read (decode, read, etc.)
        stdout_sentinel.decode.assert_not_called()
        stdout_sentinel.read.assert_not_called()


# ---------------------------------------------------------------------------
# T-61 (P1, AC-2): 9 ATD severity round-trip + unknown_severities overflow
# ---------------------------------------------------------------------------


class TestNineAtdSeverityRoundTrip:
    """T-61: All 9 ATD severity variants parsed; unknown severities overflow into dict."""

    def test_t61_all_nine_severities_counted(self, tmp_path: Path) -> None:
        """T-61 (P1, AC-2): by_severity has all 9 canonical keys with correct counts."""
        cache = _make_cache(tmp_path)

        # One finding per severity variant
        severities_input = [
            "CRITICAL",
            "HIGH",
            "MEDIUM",
            "LOW",
            "INFO",
            "ERROR",
            "WARNING",
            "EXPERIMENT",
            "INVENTORY",
        ]
        findings_json = _semgrep_json(severities_input)
        proc = _mock_completed_process(returncode=0)

        def _write_tempfile(argv_or_args, **kwargs):
            argv = list(argv_or_args)
            for i, arg in enumerate(argv):
                if arg == "--output" and i + 1 < len(argv):
                    Path(argv[i + 1]).write_text(findings_json)
                    break
            return proc

        with patch("scoring.semgrep._build_opener", return_value=_mock_opener()), \
             patch("subprocess.run", side_effect=_write_tempfile):

            result = score_semgrep(
                workspace=tmp_path,
                ruleset=_RULESET_URL_VALID,
                cache=cache,
            )

        assert result.error is None

        for sev in severities_input:
            assert result.by_severity.get(sev) == 1, (
                f"Expected by_severity['{sev}'] == 1, got {result.by_severity.get(sev)}"
            )

    def test_t61_high_aggregate_includes_error_severity(self, tmp_path: Path) -> None:
        """T-61 (P1, AC-2): high == by_severity['HIGH'] + by_severity['ERROR']."""
        cache = _make_cache(tmp_path)

        severities_input = ["HIGH", "HIGH", "ERROR", "ERROR", "ERROR"]
        findings_json = _semgrep_json(severities_input)
        proc = _mock_completed_process(returncode=0)

        def _write_tempfile(argv_or_args, **kwargs):
            argv = list(argv_or_args)
            for i, arg in enumerate(argv):
                if arg == "--output" and i + 1 < len(argv):
                    Path(argv[i + 1]).write_text(findings_json)
                    break
            return proc

        with patch("scoring.semgrep._build_opener", return_value=_mock_opener()), \
             patch("subprocess.run", side_effect=_write_tempfile):

            result = score_semgrep(
                workspace=tmp_path,
                ruleset=_RULESET_URL_VALID,
                cache=cache,
            )

        assert result.by_severity["HIGH"] == 2
        assert result.by_severity["ERROR"] == 3
        assert result.high == 2 + 3  # aggregate

    def test_t61_critical_aggregate_matches_by_severity(self, tmp_path: Path) -> None:
        """T-61 (P1, AC-2): critical == by_severity['CRITICAL']."""
        cache = _make_cache(tmp_path)

        severities_input = ["CRITICAL", "CRITICAL", "HIGH"]
        findings_json = _semgrep_json(severities_input)
        proc = _mock_completed_process(returncode=0)

        def _write_tempfile(argv_or_args, **kwargs):
            argv = list(argv_or_args)
            for i, arg in enumerate(argv):
                if arg == "--output" and i + 1 < len(argv):
                    Path(argv[i + 1]).write_text(findings_json)
                    break
            return proc

        with patch("scoring.semgrep._build_opener", return_value=_mock_opener()), \
             patch("subprocess.run", side_effect=_write_tempfile):

            result = score_semgrep(
                workspace=tmp_path,
                ruleset=_RULESET_URL_VALID,
                cache=cache,
            )

        assert result.critical == 2
        assert result.by_severity["CRITICAL"] == 2

    def test_t61_unknown_severity_lands_in_overflow_bucket(self, tmp_path: Path) -> None:
        """T-61 (P1, AC-2, Q1 forward-compat): 'FUTURE' severity in unknown_severities."""
        cache = _make_cache(tmp_path)

        # One unknown severity + one known
        severities_input = ["HIGH", "FUTURE", "FUTURE"]
        findings_json = _semgrep_json(severities_input)
        proc = _mock_completed_process(returncode=0)

        def _write_tempfile(argv_or_args, **kwargs):
            argv = list(argv_or_args)
            for i, arg in enumerate(argv):
                if arg == "--output" and i + 1 < len(argv):
                    Path(argv[i + 1]).write_text(findings_json)
                    break
            return proc

        with patch("scoring.semgrep._build_opener", return_value=_mock_opener()), \
             patch("subprocess.run", side_effect=_write_tempfile):

            result = score_semgrep(
                workspace=tmp_path,
                ruleset=_RULESET_URL_VALID,
                cache=cache,
            )

        assert result.unknown_severities == {"FUTURE": 2}
        assert result.by_severity.get("HIGH") == 1
        # FUTURE must NOT appear in by_severity
        assert "FUTURE" not in result.by_severity


# ---------------------------------------------------------------------------
# T-65 (P1, AC-17): malformed JSON in tempfile
# ---------------------------------------------------------------------------


class TestMalformedOutput:
    """T-65: Malformed JSON in the output tempfile → fail-closed error key, no raise."""

    def test_t65_malformed_json_returns_semgrep_output_malformed(
        self, tmp_path: Path
    ) -> None:
        """T-65 (P1, AC-17): Invalid JSON in tempfile → error='semgrep_output_malformed'."""
        cache = _make_cache(tmp_path)
        proc = _mock_completed_process(returncode=0)

        def _write_garbage(argv_or_args, **kwargs):
            argv = list(argv_or_args)
            for i, arg in enumerate(argv):
                if arg == "--output" and i + 1 < len(argv):
                    Path(argv[i + 1]).write_text("{{this is not json}}")
                    break
            return proc

        with patch("scoring.semgrep._build_opener", return_value=_mock_opener()), \
             patch("subprocess.run", side_effect=_write_garbage):

            result = score_semgrep(
                workspace=tmp_path,
                ruleset=_RULESET_URL_VALID,
                cache=cache,
            )

        assert result.error == "semgrep_output_malformed"
        # Must not raise; result should be a proper SemgrepResult object
        assert isinstance(result, SemgrepResult)


# ---------------------------------------------------------------------------
# T-66 (P1, AC-17): subprocess.TimeoutExpired
# ---------------------------------------------------------------------------


class TestSemgrepTimeout:
    """T-66: TimeoutExpired from semgrep subprocess → error='semgrep_timeout', no raise."""

    def test_t66_timeout_returns_semgrep_timeout_error(self, tmp_path: Path) -> None:
        """T-66 (P1, AC-17): subprocess.TimeoutExpired → error='semgrep_timeout'."""
        cache = _make_cache(tmp_path)

        def _raise_timeout(argv_or_args, **kwargs):
            raise subprocess.TimeoutExpired(cmd=list(argv_or_args), timeout=120)

        with patch("scoring.semgrep._build_opener", return_value=_mock_opener()), \
             patch("subprocess.run", side_effect=_raise_timeout):
            result = score_semgrep(
                workspace=tmp_path,
                ruleset=_RULESET_URL_VALID,
                cache=cache,
            )

        assert result.error == "semgrep_timeout"
        assert isinstance(result, SemgrepResult)


# ---------------------------------------------------------------------------
# T-67 (P0, AC-17): URL fetch failure surfaces as ruleset_fetch_failed
# ---------------------------------------------------------------------------


class TestRulesetFetchFailure:
    """
    T-67: When SemgrepCache.fetch_or_reuse fails to download a remote ruleset
    (network down, 404, SSL error, etc.), score_semgrep returns
    error='ruleset_fetch_failed' rather than silently passing a non-existent
    path to semgrep (which would surface as a confusing tool error).
    """

    def test_t67_urlopen_404_returns_ruleset_fetch_failed(self, tmp_path: Path) -> None:
        cache = _make_cache(tmp_path)

        # Opener's open() raises HTTPError (404). The scorer must translate to
        # ruleset_fetch_failed, NEVER invoke semgrep afterwards.
        failing_opener = MagicMock()
        failing_opener.open.side_effect = urllib.error.HTTPError(
            _RULESET_URL_VALID, 404, "Not Found", {}, None,
        )

        with patch("scoring.semgrep._build_opener", return_value=failing_opener), \
             patch("subprocess.run") as mock_run:
            result = score_semgrep(
                workspace=tmp_path,
                ruleset=_RULESET_URL_VALID,
                cache=cache,
            )

        assert result.error == "ruleset_fetch_failed"
        # H-2 fix: explicit assertion that subprocess.run was NEVER called
        # (fail-fast: fetch failure → semgrep is never invoked).
        mock_run.assert_not_called()
        assert result.ruleset_source_url == _RULESET_URL_VALID

    def test_t67_fetch_or_reuse_raises_ruleset_fetch_error_directly(
        self, tmp_path: Path
    ) -> None:
        """Cache method raises a typed exception; callers can catch it explicitly."""
        from scoring.semgrep import RulesetFetchError
        cache = _make_cache(tmp_path)

        failing_opener = MagicMock()
        failing_opener.open.side_effect = OSError("Network unreachable")

        with patch("scoring.semgrep._build_opener", return_value=failing_opener):
            with pytest.raises(RulesetFetchError) as exc_info:
                cache.fetch_or_reuse(_RULESET_URL_VALID)

        assert exc_info.value.url == _RULESET_URL_VALID


# ---------------------------------------------------------------------------
# T-68 (P0, AC-17): semgrep nonzero exit surfaces as semgrep_failed
# ---------------------------------------------------------------------------


class TestSemgrepNonzeroExit:
    """
    T-68: When semgrep exits non-zero (rule parse error, internal panic, missing
    config), error='semgrep_failed' — distinct from 'semgrep_output_malformed'
    (which means semgrep RAN cleanly but produced unparseable JSON).
    """

    def test_t68_nonzero_returncode_returns_semgrep_failed(self, tmp_path: Path) -> None:
        cache = _make_cache(tmp_path)
        local_ruleset = tmp_path / "rules.yml"
        local_ruleset.write_text("rules: []\n")

        def fake_run(cmd, *args, **kwargs):
            mock_result = MagicMock()
            mock_result.returncode = 2  # semgrep nonzero
            return mock_result

        with patch("subprocess.run", side_effect=fake_run):
            result = score_semgrep(
                workspace=tmp_path,
                ruleset=str(local_ruleset),
                cache=cache,
            )

        assert result.error == "semgrep_failed"
        assert result.tool_name is None  # tool was found, just failed


# ---------------------------------------------------------------------------
# T-69 (P0, SECURITY): cross-scheme redirect defense (SSRF/LFI)
# ---------------------------------------------------------------------------


class TestRedirectHandlerDefense:
    """
    T-69 — SECURITY: Python's default urllib.request.HTTPRedirectHandler follows 3xx
    redirects into ANY scheme (file://, ftp://, data://). Without a custom handler,
    an attacker-controlled manifest URL on the allowlisted host that responds with
    302 Location: file:///etc/passwd would cause urllib to fetch and cache that
    local file content as a "ruleset." The _StrictHTTPSRedirectHandler must reject
    cross-scheme and cross-host redirects.
    """

    def test_t69_redirect_to_file_scheme_is_refused(self) -> None:
        """302 redirect to file:// must raise URLError from our handler."""
        from scoring.semgrep import _StrictHTTPSRedirectHandler

        handler = _StrictHTTPSRedirectHandler()
        # redirect_request is the hook point — must refuse non-https schemes
        with pytest.raises(urllib.error.URLError) as exc_info:
            handler.redirect_request(
                req=MagicMock(),
                fp=MagicMock(),
                code=302,
                msg="Found",
                headers=MagicMock(),
                newurl="file:///etc/passwd",
            )
        assert "disallowed scheme" in str(exc_info.value).lower()
        assert "file" in str(exc_info.value)

    def test_t69_redirect_to_disallowed_host_is_refused(self) -> None:
        """Even over HTTPS, redirect to a non-allowlisted host must be refused."""
        from scoring.semgrep import _StrictHTTPSRedirectHandler

        handler = _StrictHTTPSRedirectHandler()
        with pytest.raises(urllib.error.URLError) as exc_info:
            handler.redirect_request(
                req=MagicMock(),
                fp=MagicMock(),
                code=302,
                msg="Found",
                headers=MagicMock(),
                newurl="https://attacker.example.com/payload.yml",
            )
        assert "disallowed host" in str(exc_info.value).lower()

    def test_t69_redirect_within_allowlisted_host_is_allowed(self) -> None:
        """A 302 redirect that stays on raw.githubusercontent.com is permitted.
        We verify the parent class IS invoked (our handler doesn't raise) by
        asserting via super().redirect_request mock."""
        from scoring.semgrep import _StrictHTTPSRedirectHandler
        from urllib.request import HTTPRedirectHandler

        handler = _StrictHTTPSRedirectHandler()
        with patch.object(HTTPRedirectHandler, "redirect_request", return_value="delegated") as mock_super:
            result = handler.redirect_request(
                req=MagicMock(),
                fp=MagicMock(),
                code=302,
                msg="Found",
                headers=MagicMock(),
                newurl="https://raw.githubusercontent.com/owner/repo/sha/new.yml",
            )
        # Delegation proves our guards passed and the super class was invoked
        assert result == "delegated"
        mock_super.assert_called_once()


# ---------------------------------------------------------------------------
# T-70: http:// URLs are not accepted (only https)
# ---------------------------------------------------------------------------


class TestHttpsOnlyPolicy:
    """T-70: http:// URLs to raw.githubusercontent.com must be rejected via
    RulesetRefError (TOFU hardening — attacker in transit could substitute bytes)."""

    def test_t70_http_url_rejected_before_fetch(self, tmp_path: Path) -> None:
        cache = _make_cache(tmp_path)
        http_url = f"http://raw.githubusercontent.com/owner/repo/{'a'*40}/rules.yml"

        with patch("subprocess.run") as mock_run, \
             patch("scoring.semgrep._build_opener") as mock_build_opener:
            with pytest.raises(RulesetRefError):
                score_semgrep(workspace=tmp_path, ruleset=http_url, cache=cache)

            mock_run.assert_not_called()
            mock_build_opener.assert_not_called()
