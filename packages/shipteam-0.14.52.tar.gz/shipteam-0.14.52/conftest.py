"""Root conftest.py — adds repo root to sys.path for benchmark harness packages."""
import sys
from pathlib import Path

# Add the repository root to sys.path so harness, drivers, scoring, aggregation
# packages are importable without installing them.
sys.path.insert(0, str(Path(__file__).parent))
