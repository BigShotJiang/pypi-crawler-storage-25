# Quickstart Guide

> **Goal**: From zero to a safety-gated, TDD-enabled Claude Code project in under 10 minutes.

This guide is the fastest path. If you want the full setup walkthrough with manual steps, troubleshooting, and platform-specific notes, see [SETUP.md](SETUP.md).

---

## Prerequisites

You need these installed. If you're missing anything, see [SETUP.md — Platform Setup](SETUP.md#platform-setup).

- **[Claude Code](https://docs.anthropic.com/en/docs/claude-code/overview)** — CLI, Desktop app, VS Code, or JetBrains extension
- **Git 2.17+** — for worktree support
- **Python 3.9+** — for the safety hooks
- **GitHub CLI (`gh`)** — for repo creation
- **Bash 3.2+** — macOS default is fine; Windows users should use [DevContainer or WSL](SETUP.md#windows)

Verify: `git --version && python3 --version && gh --version && claude --version`

---

## 1. Create Your Project (2 minutes)

Fork the framework as a template for your new project:

```bash
gh repo create my-project --template cdjgroup/dev-framework --private
cd my-project
```

You now have a full copy of the framework in a private repo you own. Every file is yours to modify — this is a template, not a dependency.

---

## 2. Let Claude Set It Up (3 minutes)

Start Claude Code in your new project directory:

```bash
claude
```

Then tell Claude to set up the project. Customize the details to match your stack:

> Set up this project for me. My repo is `myorg/my-project`. I'm building a Python/FastAPI backend on port 8000. Start with the **minimal profile**.

Claude reads `SETUP.md` and `CLAUDE.md` automatically and will:

1. Edit `config/framework.yaml` with your project details
2. Run `uvx shipteam init` (renders CLAUDE.md, scaffolds `.claude/`, writes state)
3. Install the hooks template (`settings.local.json`)
4. Verify everything works via `./scripts/preflight.sh`

**What you get at minimal profile:**
- All 18 safety hooks active (default-deny for `rm -rf`, `git push --force`, `DROP TABLE`, etc.)
- Hudson workflow mode (4-step quick fix methodology)
- Anti-pattern rules auto-loaded into Claude's context
- Branch isolation via git worktrees
- `fw-review-code` as the default reviewer

Everything else (Sherlock methodology, advanced reviewers, multi-agent pipeline) is off until you graduate.

---

## 3. Your First Safety-Gated Task (5 minutes)

Start a session and give Claude a small task using Hudson mode:

```bash
claude
```

> **hudson**: add a `/health` endpoint that returns `{"status": "ok"}`

Hudson is the simplest workflow mode — 4 steps, designed for quick fixes and small features:
1. **Explore** — Claude reads the relevant files
2. **Implement with tests** — test first, then implementation
3. **Quick review** — `fw-review-code` audits the change
4. **Commit** — follows your git conventions

When you're done, try something destructive to see the safety gate in action:

```bash
rm -rf /tmp/test  # Claude will propose this
# The hook blocks it with exit code 2 — you'll see the safety gate message
```

**That's it.** You have a safety-gated, workflow-enforced Claude Code project.

---

## What Just Happened?

| Component | What It Does |
|---|---|
| **Safety hooks** (`auto_approve_base.py`) | Hard-blocks destructive commands via exit code 2. Cannot be bypassed through auto-approval settings. |
| **Branch isolation** (`claude-session.sh`) | Each session runs in its own git worktree. Concurrent Claude sessions don't interfere with each other. |
| **Anti-pattern rules** (`.claude/rules/anti-patterns.md`) | 10 mandatory rules auto-loaded into Claude's context. Prevents common AI coding mistakes like presenting assumptions as facts. |
| **Hudson mode** (`.claude/rules/sherlock-methodology.md`) | 4-step workflow for quick tasks. Lightweight alternative to the full Sherlock methodology. |
| **Default reviewer** (`.claude/agents/fw-review-code.md`) | At `profile: minimal`, Hudson runs `fw-review-code` as the single-pass reviewer. Graduating to `standard` or `full` enables the multi-agent parallel pipeline described in `.claude/rules/sherlock-review-gate.md`. |

---

## When You're Ready for More

Graduate through the profiles as you get comfortable. You don't need to understand 75 components to get started — you can start simple and add capabilities incrementally.

```yaml
# config/framework.yaml

profile: minimal    # You are here — ~15 components
# profile: standard  # Add Sherlock methodology, TDD subagents, core skills (~40 components)
# profile: full      # Everything enabled — full review pipeline (~75 components)
```

After changing the profile, tell Claude: *"Switch to standard profile"* or run `uvx shipteam init --refresh`.

**A suggested learning path:**

| Day | Focus | Workflow Mode |
|---|---|---|
| **Day 1** | Safety gates + Hudson | Hudson (4 steps) for everything |
| **Day 2-3** | Sherlock Lite + TDD subagents | Let Claude classify tasks automatically |
| **Week 2** | Full Sherlock for complex features | Spec-driven development with `.sherlock-plan.md` |
| **Week 2+** | `profile: full` | Full multi-agent review pipeline with all relevant reviewers |

See [docs/ADOPTION.md — First Week Guide](docs/ADOPTION.md#first-week-guide) for the full day-by-day walkthrough.

---

## Next Steps

- **[The Build Team](README.md#the-build-team)** — Meet the specialized agents covering each workflow stage
- **[What Problems This Solves](README.md#what-problems-this-solves)** — Understand the "why" behind each component
- **[Complexity Profiles](docs/ADOPTION.md#complexity-profiles)** — Detailed breakdown of what each profile enables
- **[Full Setup Guide](SETUP.md)** — Manual setup, troubleshooting, platform-specific notes
- **[Contributing](CONTRIBUTING.md)** — How to help improve the framework

---

## Getting Help

- **Framework questions**: See [docs/00-README.md](docs/00-README.md) for the full documentation index
- **Troubleshooting**: See [docs/80-TROUBLESHOOTING.md](docs/80-TROUBLESHOOTING.md) for common issues
- **Claude Code questions**: [Official Claude Code docs](https://docs.anthropic.com/en/docs/claude-code/overview)
- **Bug reports**: [GitHub Issues](https://github.com/cdjgroup/dev-framework/issues)

---

*dev-framework turns Claude Code into a build team. The safety gates, workflow modes, and multi-agent review pipeline are opinionated defaults — every file is yours to customize.*
