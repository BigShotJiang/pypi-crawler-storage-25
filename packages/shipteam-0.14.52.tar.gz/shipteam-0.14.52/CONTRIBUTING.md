# Contributing to ShipTeam

Contributions are welcome! This guide covers everything you need to get started.

## Quick Setup

```bash
# 1. Fork and clone
gh repo fork cdjgroup/dev-framework --clone
cd dev-framework

# 2. Let Claude configure the environment (recommended)
claude
# Tell Claude: "Set up this project for contributing"
# It will handle framework.yaml, `uvx shipteam init`, and submodules.
# (Hooks are pre-registered in .claude/settings.json — no copy step needed.)

# 3. Verify everything works
make test
```

<details>
<summary>Manual setup (if you prefer)</summary>

```bash
vim config/framework.yaml    # Set your project details
uvx shipteam init
git submodule update --init --recursive
make test
```

Hooks register automatically via `.claude/settings.json`, which the framework ships and Claude Code reads on launch. If you need per-developer overrides, create `.claude/settings.local.json` by hand — it is gitignored.
</details>

## Running Tests

The test suite uses two frameworks: **bats-core** for bash scripts and **pytest** for Python hooks.

```bash
make test          # Run all tests (bats + pytest) — 386 tests
make test-bats     # Run only bats (bash) tests
make test-python   # Run only Python tests
make smoke         # Quick validation: syntax + compilation + core tests
make lint          # Shell syntax + Python compilation + shellcheck
make ci            # Full CI pipeline (lint + test)
```

### Test Structure

| Directory | Framework | What it tests |
|-----------|-----------|---------------|
| `test/*.bats` | bats-core | Bash scripts, hooks (JSON piping), fw-sync, template validation |
| `scripts/tests/test_*.py` | pytest | Python hook internals (branch-check, commit-trust, path-utils, cost-routing) |

### Prerequisites

- **bash** 4+ (`brew install bash` on macOS, which ships 3.x)
- **python3** 3.9+
- **bats-core** via git submodules: `git submodule update --init --recursive`

## Development Workflow

1. Create a feature branch: `git checkout -b feature/my-change`
2. Make your changes
3. Run tests: `make test`
4. Commit using conventional commits: `feat:`, `fix:`, `docs:`, `chore:`
5. Push and open a PR against `main`

### TDD Workflow (Optional)

If you're using Claude Code with the framework:

```bash
./scripts/tdd-commit.sh red "Add test for new safety pattern"
./scripts/tdd-commit.sh green "Implement new safety pattern"
./scripts/tdd-commit.sh refactor "Clean up pattern matching"
```

## What to Contribute

- **Safety gate patterns**: New destructive commands that should be blocked
- **Rules**: Improvements to anti-patterns, security, or database migration rules
- **Skills**: New invocable workflows or improvements to existing ones
- **Documentation**: Fixes, clarifications, or new guides
- **Bug fixes**: Especially in hooks or scripts

## Before Opening a PR

- [ ] Tests pass: `make test`
- [ ] New features include tests
- [ ] Commit messages follow conventional commit format
- [ ] No credentials, `.env` files, or secrets included

### Security-Sensitive Changes (Extra Requirements)

PRs that touch hooks (`.claude/hooks/`), rules (`.claude/rules/`), or CI workflows (`.github/workflows/`) require extra scrutiny:

- [ ] **Hooks**: Changes to `auto_approve_base.py` must not weaken existing blocks. New auto-approve patterns must justify why they are safe. Add bypass test cases for each new pattern.
- [ ] **Overlays**: Project overlays (`auto-approve.py`) should ONLY add restrictions, never remove them. The base safety gate is the foundational enforcement layer — overlays extend it, never weaken it. See [docs/85-SAFETY-LIMITS.md](docs/85-SAFETY-LIMITS.md) for the full layer model and what this gate does and does not protect against.
- [ ] **CI workflows**: No `|| true` on security-critical steps (Bandit, npm audit). No `eval` of unvalidated input. Pin new actions to full-length commit SHA with version comment.
- [ ] **Rules/Skills**: Security rule changes must cite authoritative sources (OWASP, NIST, CWE).

## Opening an Issue First

For non-trivial changes, please open an issue first to discuss the approach. This prevents wasted effort if the change doesn't align with the project direction.

## Code of Conduct

Please read and follow our [Code of Conduct](CODE_OF_CONDUCT.md). Be respectful, constructive, and welcoming. We're all here to make AI-assisted development safer and more productive.

## License

By contributing, you agree that your contributions will be licensed under the MIT License.
