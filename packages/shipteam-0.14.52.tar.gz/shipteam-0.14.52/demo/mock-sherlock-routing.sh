#!/bin/bash
# Mock Sherlock complexity routing output for VHS demo recording
# Simulates the build team staffing decision (Step 0)

TASK="$*"

case "$TASK" in
    *"OAuth"*|*"oauth"*|*"auth"*)
        echo ""
        echo -e "\033[1mBUILD TEAM STAFFING:\033[0m"
        echo ""
        echo -e "  Files affected:"
        echo -e "    \033[36mbackend/auth.py\033[0m       (auth logic)"
        echo -e "    \033[36mbackend/middleware.py\033[0m  (sessions)"
        echo -e "    \033[36mbackend/models.py\033[0m     (user model)"
        echo -e "    \033[36mfrontend/Login.tsx\033[0m    (login UI)"
        echo -e "    \033[36mtests/test_auth.py\033[0m    (tests)"
        echo ""
        echo -e "  Risk multipliers:"
        echo -e "    \033[1;33m⚠ Authentication logic\033[0m"
        echo -e "    \033[1;33m⚠ API contract change\033[0m"
        echo ""
        echo -e "  Team size:"
        echo -e "  \033[2m  🏠 Hudson  — 1 engineer  (4 steps)\033[0m"
        echo -e "  \033[2m  🔍 Lite    — small team   (6 steps)\033[0m"
        echo -e "  → 🔍 \033[1mFull Team  — spec + TDD + 14 reviewers (8 steps)\033[0m \033[1;32m[REC]\033[0m"
        echo ""
        echo -e "  \033[1mWhy:\033[0m 5 files + 2 risk multipliers."
        echo -e "  Full spec, architecture review,"
        echo -e "  cognitively-isolated TDD, and"
        echo -e "  multi-agent review pipeline."
        echo ""
        ;;
    *"typo"*|*"README"*|*"readme"*|*"fix"*)
        echo ""
        echo -e "\033[1mBUILD TEAM STAFFING:\033[0m"
        echo ""
        echo -e "  Files affected:"
        echo -e "    \033[36mREADME.md\033[0m  (docs update)"
        echo ""
        echo -e "  Risk multipliers: \033[32mnone\033[0m"
        echo ""
        echo -e "  Team size:"
        echo -e "  → 🏠 \033[1mHudson  — 1 engineer  (4 steps)\033[0m \033[1;32m[REC]\033[0m"
        echo -e "  \033[2m  🔍 Lite    — small team   (6 steps)\033[0m"
        echo -e "  \033[2m  🔍 Full    — full team    (8 steps)\033[0m"
        echo ""
        echo -e "  \033[1mWhy:\033[0m 1 file, no risk."
        echo -e "  Quick fix with Code Reviewer only."
        echo ""
        ;;
esac
