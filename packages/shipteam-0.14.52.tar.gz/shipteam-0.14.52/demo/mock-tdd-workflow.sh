#!/bin/bash
# Mock TDD workflow output for VHS demo recording
# Simulates the three TDD team roles in action

PHASE="$1"
shift
MSG="$*"

case "$PHASE" in
    red)
        echo ""
        echo -e "\033[1;33m━━━ TDD Phase: RED ━━━\033[0m"
        echo -e "  \033[2mRole: Test Designer (fw-tdd-red)\033[0m"
        echo -e ""
        echo -e "  Writing failing tests from spec..."
        echo -e "  Test: should authenticate valid user"
        echo -e "  Test: should reject invalid password"
        echo -e "  Test: should rate-limit login attempts"
        echo ""
        sleep 0.3
        echo -e "  Running tests..."
        sleep 0.4
        echo -e "  \033[33m✗ 3 tests failing\033[0m (expected)"
        echo ""
        sleep 0.2
        echo -e "  \033[32m✓\033[0m Committed: tdd(red): $MSG"
        echo -e "  \033[2mTest Designer never saw the implementation.\033[0m"
        echo ""
        ;;
    green)
        echo ""
        echo -e "\033[1;32m━━━ TDD Phase: GREEN ━━━\033[0m"
        echo -e "  \033[2mRole: Developer (fw-tdd-green)\033[0m"
        echo -e ""
        echo -e "  Writing minimal implementation..."
        echo ""
        sleep 0.3
        echo -e "  Running tests..."
        sleep 0.4
        echo -e "  \033[32m✓ 3 tests passing\033[0m"
        echo ""
        sleep 0.2
        echo -e "  \033[32m✓\033[0m Committed: tdd(green): $MSG"
        echo -e "  \033[2mDeveloper never saw the requirements.\033[0m"
        echo ""
        ;;
    refactor)
        echo ""
        echo -e "\033[1;36m━━━ TDD Phase: REFACTOR ━━━\033[0m"
        echo -e "  \033[2mRole: Refactoring Engineer (fw-tdd-refactor)\033[0m"
        echo -e ""
        echo -e "  Cleaning up implementation..."
        echo -e "  Extracted: auth_middleware.py"
        echo -e "  Simplified: login_handler()"
        echo ""
        sleep 0.3
        echo -e "  Running tests..."
        sleep 0.4
        echo -e "  \033[32m✓ 3 tests still passing\033[0m"
        echo ""
        sleep 0.2
        echo -e "  \033[32m✓\033[0m Committed: tdd(refactor): $MSG"
        echo ""
        ;;
    blocked)
        echo ""
        echo -e "\033[1;31m━━━ TDD Phase: GREEN — BLOCKED ━━━\033[0m"
        echo -e "  \033[2mRole: Developer (fw-tdd-green)\033[0m"
        echo -e ""
        echo -e "  Running tests..."
        sleep 0.4
        echo -e "  \033[31m✗ 1 test failing\033[0m"
        echo ""
        echo -e "  \033[1;31mCannot commit GREEN with failing tests.\033[0m"
        echo -e "  Implementation is incomplete."
        echo ""
        ;;
esac
