#!/bin/bash
# Mock init-project.sh wizard output for VHS demo recording
# Simulates assembling the build team with the 14-step wizard

echo ""
echo -e "\033[1m================================================\033[0m"
echo -e "\033[1m  Assembling Your Build Team\033[0m"
echo -e "\033[1m================================================\033[0m"
echo ""
echo -e "  Project: \033[36mmy-awesome-app\033[0m"
echo -e "  Profile: \033[36mstandard\033[0m"
echo ""
sleep 0.4
echo -e "  \033[32m[1/14]\033[0m  CLAUDE.md placeholders......  \033[32m✓\033[0m"
sleep 0.25
echo -e "  \033[32m[2/14]\033[0m  Rules (4 files).............  \033[32m✓\033[0m"
sleep 0.25
echo -e "  \033[32m[3/14]\033[0m  Skills (10 commands)........  \033[32m✓\033[0m"
sleep 0.25
echo -e "  \033[32m[4/14]\033[0m  Safety hooks (13 hooks).....  \033[32m✓\033[0m"
sleep 0.25
echo -e "  \033[32m[5/14]\033[0m  Review agents (22)..........  \033[32m✓\033[0m"
sleep 0.25
echo -e "  \033[32m[6/14]\033[0m  TDD agents (3).............  \033[32m✓\033[0m"
sleep 0.2
echo -e "  \033[32m[7/14]\033[0m  Stack dependencies.........  \033[32m✓\033[0m"
sleep 0.2
echo -e "  \033[32m[8/14]\033[0m  Scripts executable (23)....  \033[32m✓\033[0m"
sleep 0.2
echo -e "  \033[32m[9/14]\033[0m  Git repository.............  \033[32m✓\033[0m"
sleep 0.2
echo -e "  \033[32m[10/14]\033[0m Metrics directory...........  \033[32m✓\033[0m"
sleep 0.2
echo -e "  \033[32m[11/14]\033[0m Version: 0.1.0..............  \033[32m✓\033[0m"
sleep 0.15
echo -e "  \033[32m[12/14]\033[0m Prompt versioning...........  \033[2mskipped\033[0m"
sleep 0.15
echo -e "  \033[32m[13/14]\033[0m QA reports..................  \033[32m✓\033[0m"
sleep 0.15
echo -e "  \033[32m[14/14]\033[0m Retro storage...............  \033[32m✓\033[0m"
echo ""
echo -e "\033[1m================================================\033[0m"
echo -e "  \033[1;32m✓ Build team assembled!\033[0m"
echo -e "\033[1m================================================\033[0m"
echo ""
echo -e "  Your team:"
echo -e "  22 reviewers · 3 TDD engineers · 10 skills"
echo -e "  13 safety hooks · 23 scripts"
echo ""
echo -e "  Next: \033[36mclaude-session.sh feature/first\033[0m"
echo ""
