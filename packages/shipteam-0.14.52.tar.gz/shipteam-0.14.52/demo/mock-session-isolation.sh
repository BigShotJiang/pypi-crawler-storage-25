#!/bin/bash
# Mock session isolation output for VHS demo recording
# Simulates the DevOps engineer managing parallel build teams

CMD="$1"

case "$CMD" in
    launch)
        echo ""
        echo -e "\033[1m================================================\033[0m"
        echo -e "\033[1m  Build Team Session\033[0m"
        echo -e "\033[1m================================================\033[0m"
        echo ""
        echo -e "  Creating isolated worktree..."
        sleep 0.3
        echo -e "   Branch: \033[36mfeature/auth\033[0m"
        echo -e "   Path:   \033[36m~/worktrees/myapp-feature-auth/\033[0m"
        sleep 0.3
        echo -e "   Lock:   \033[33msession-lock.json\033[0m created"
        echo -e "   Sync:   Up to date with origin/main"
        echo ""
        echo -e "\033[1m================================================\033[0m"
        echo -e "  \033[1;32m✓ Build team ready!\033[0m Launching Claude..."
        echo -e "\033[1m================================================\033[0m"
        echo ""
        echo -e "  \033[2mYour main repo is untouched.\033[0m"
        echo -e "  \033[2mAll changes happen in the worktree.\033[0m"
        echo ""
        ;;
    second)
        echo ""
        echo -e "\033[1m================================================\033[0m"
        echo -e "\033[1m  Build Team Session\033[0m"
        echo -e "\033[1m================================================\033[0m"
        echo ""
        echo -e "  Creating isolated worktree..."
        sleep 0.3
        echo -e "   Branch: \033[36mfeature/billing\033[0m"
        echo -e "   Path:   \033[36m~/worktrees/myapp-feature-billing/\033[0m"
        sleep 0.3
        echo -e "   Lock:   \033[33msession-lock.json\033[0m created"
        echo -e "   Sync:   Up to date with origin/main"
        echo ""
        echo -e "\033[1m================================================\033[0m"
        echo -e "  \033[1;32m✓ Build team ready!\033[0m"
        echo -e "\033[1m================================================\033[0m"
        echo ""
        echo -e "  \033[2mTwo build teams, two features, zero conflicts.\033[0m"
        echo ""
        ;;
    block)
        echo ""
        echo -e "\033[1;33m✗ BLOCKED\033[0m — Session already active"
        echo ""
        echo -e "  \033[2mRole: DevOps Engineer\033[0m"
        echo -e "  Active branch: feature/auth"
        echo -e "  Lock file:     session-lock.json"
        echo -e "  Started:       2026-03-29 14:30:27"
        echo ""
        echo -e "  \033[33mOne build team per worktree.\033[0m"
        echo -e "  Use a different branch to start"
        echo -e "  a parallel team."
        echo ""
        exit 1
        ;;
esac
