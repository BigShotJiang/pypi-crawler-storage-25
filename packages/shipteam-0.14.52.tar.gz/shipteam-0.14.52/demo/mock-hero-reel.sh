#!/bin/bash
# Mock output for hero reel VHS demo
# Simulates the build team in action across 4 workflow stages

CMD="$*"

case "$CMD" in
    *"push --force"*)
        echo ""
        echo -e "\033[1;31m✗ HARD BLOCK\033[0m (exit code 2)"
        echo -e ""
        echo -e "  \033[2mRole: DevOps Engineer\033[0m"
        echo -e "  Pattern:  \033[33mgit push --force origin main\033[0m"
        echo -e "  Reason:   Force-pushes are prohibited."
        echo -e "             Cannot be bypassed, even with"
        echo -e "             auto-approve enabled."
        echo -e "  Action:   \033[1;31mCommand denied\033[0m"
        echo ""
        echo -e "  \033[2m36 test cases verify this gate.\033[0m"
        echo ""
        exit 2
        ;;
    *"tdd"*)
        echo ""
        echo -e "\033[1;33m● RED\033[0m  — \033[2mTest Designer\033[0m writes failing tests"
        echo -e "  (sees requirements only — never the implementation)"
        echo -e "  Running tests... \033[33m3 failing\033[0m (expected)"
        echo -e "  \033[32m✓\033[0m tdd(red): Add tests for user auth"
        echo ""
        sleep 0.4
        echo -e "\033[1;32m● GREEN\033[0m — \033[2mDeveloper\033[0m writes minimal code"
        echo -e "  (sees tests only — never the requirements)"
        echo -e "  Running tests... \033[32m3 passing\033[0m"
        echo -e "  \033[32m✓\033[0m tdd(green): Implement user auth"
        echo ""
        sleep 0.4
        echo -e "\033[1;36m● REFACTOR\033[0m — \033[2mRefactoring Engineer\033[0m cleans up"
        echo -e "  Running tests... \033[32m3 still passing\033[0m"
        echo -e "  \033[32m✓\033[0m tdd(refactor): Extract middleware"
        echo ""
        ;;
    *"cost"*)
        echo ""
        echo -e "\033[1;36m● Review Team Staffing\033[0m"
        echo ""
        echo -e "  \033[33mDocs PR\033[0m (45 LOC)"
        echo -e "    → 1 reviewer (Haiku)   \033[32m~\$0.02\033[0m"
        echo ""
        echo -e "  \033[33mFeature\033[0m (320 LOC)"
        echo -e "    → 3 reviewers (Sonnet) \033[33m~\$0.80\033[0m"
        echo ""
        echo -e "  \033[31mDB migration\033[0m (85 LOC)"
        echo -e "    → 3 reviewers (Opus)   \033[31m~\$3.00\033[0m"
        echo ""
        echo -e "  \033[2mRight specialists for each change.\033[0m"
        echo ""
        ;;
    *"stats"*)
        echo ""
        echo -e "\033[1;36m● Build Team Stats\033[0m (last 30d)"
        echo ""
        echo -e "  Safety:      \033[32m12 destructive ops blocked\033[0m"
        echo -e "  Cost saved:  \033[32m~\$12.50\033[0m (41 agents skipped)"
        echo ""
        echo -e "  Plan Conformance (8 sessions)"
        echo -e "    Composite: \033[1;32m91%\033[0m avg (target: 90%)"
        echo -e "    ├─ File coverage:   94%"
        echo -e "    ├─ AC coverage:     88%"
        echo -e "    └─ Scope creep:     85%"
        echo ""
        echo -e "  TDD Health"
        echo -e "    RED:GREEN:REFACTOR = 1.0:1.1:0.6"
        echo ""
        ;;
esac
