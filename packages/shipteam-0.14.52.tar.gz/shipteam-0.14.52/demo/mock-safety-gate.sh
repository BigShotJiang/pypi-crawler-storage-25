#!/bin/bash
# Mock safety gate output for VHS demo recording
# Simulates the DevOps engineer (auto_approve_base.py hook)

CMD="$*"

case "$CMD" in
    *"push --force"*|*"push -f "*)
        echo ""
        echo -e "\033[1;31m✗ HARD BLOCK\033[0m (exit code 2)"
        echo -e ""
        echo -e "  \033[2mRole: DevOps Engineer\033[0m"
        echo -e "  Pattern:  \033[33mgit push --force\033[0m"
        echo -e "  Reason:   Force-pushes are prohibited."
        echo -e "             Cannot be bypassed, even with"
        echo -e "             auto-approve enabled."
        echo -e "  Action:   \033[1;31mCommand denied\033[0m"
        echo ""
        exit 2
        ;;
    *"reset --hard"*)
        echo ""
        echo -e "\033[1;31m✗ HARD BLOCK\033[0m (exit code 2)"
        echo -e ""
        echo -e "  \033[2mRole: DevOps Engineer\033[0m"
        echo -e "  Pattern:  \033[33mgit reset --hard\033[0m"
        echo -e "  Reason:   Protects uncommitted work"
        echo -e "             from silent destruction."
        echo -e "  Action:   \033[1;31mCommand denied\033[0m"
        echo ""
        exit 2
        ;;
    *"DROP TABLE"*|*"drop table"*)
        echo ""
        echo -e "\033[1;31m✗ HARD BLOCK\033[0m (exit code 2)"
        echo -e ""
        echo -e "  \033[2mRole: DevOps Engineer\033[0m"
        echo -e "  Pattern:  \033[33mDROP TABLE\033[0m"
        echo -e "  Reason:   Destructive SQL blocked."
        echo -e "             No bypass available."
        echo -e "  Action:   \033[1;31mCommand denied\033[0m"
        echo ""
        exit 2
        ;;
    *"rm -rf"*)
        echo ""
        echo -e "\033[1;31m✗ HARD BLOCK\033[0m (exit code 2)"
        echo -e ""
        echo -e "  \033[2mRole: DevOps Engineer\033[0m"
        echo -e "  Pattern:  \033[33mrm -rf (unlisted path)\033[0m"
        echo -e "  Reason:   Default-deny. Only explicitly"
        echo -e "             safe paths are allowed."
        echo -e "  Action:   \033[1;31mCommand denied\033[0m"
        echo ""
        exit 2
        ;;
    *"push origin"*)
        echo ""
        echo -e "\033[1;32m✓ Allowed\033[0m"
        echo -e "  Normal push to feature branch."
        echo ""
        exit 0
        ;;
esac
