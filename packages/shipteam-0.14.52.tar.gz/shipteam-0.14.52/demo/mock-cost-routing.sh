#!/bin/bash
# Mock cost routing output for VHS demo recording
# Simulates the Engineering Manager staffing the review team

CHANGE_TYPE="$1"

case "$CHANGE_TYPE" in
    docs)
        echo ""
        echo -e "\033[1;36m● Review Team Staffing\033[0m"
        echo -e "  Change type: \033[33mdocs-only\033[0m (45 LOC)"
        echo -e "  Strategy:    \033[32mfast-path\033[0m"
        echo ""
        echo -e "  \033[1mTeam (1 of 14 reviewers):\033[0m"
        echo -e "    \033[36m→ Documentation Engineer\033[0m  (Haiku)"
        echo ""
        echo -e "  \033[2mBenched: Code Reviewer, Security Engineer,"
        echo -e "  Performance Engineer, Test Architect,"
        echo -e "  API Architect, and 8 more\033[0m"
        echo ""
        echo -e "  Est. cost: \033[1;32m~\$0.02\033[0m"
        echo -e "  \033[2mFull team would cost ~\$5.00\033[0m"
        echo ""
        ;;
    feature)
        echo ""
        echo -e "\033[1;36m● Review Team Staffing\033[0m"
        echo -e "  Change type: \033[33mmixed\033[0m (320 LOC)"
        echo -e "  Strategy:    \033[33mstandard\033[0m"
        echo ""
        echo -e "  \033[1mTeam (3 of 14 reviewers):\033[0m"
        echo -e "    \033[36m→ Code Reviewer\033[0m           (Sonnet)"
        echo -e "    \033[36m→ Performance Engineer\033[0m    (Sonnet)"
        echo -e "    \033[36m→ API Architect\033[0m           (Sonnet)"
        echo ""
        echo -e "  \033[2mBenched: Database Engineer, UX Engineer,"
        echo -e "  Test Architect, and 8 more\033[0m"
        echo ""
        echo -e "  Est. cost: \033[1;33m~\$0.80\033[0m"
        echo ""
        ;;
    migration)
        echo ""
        echo -e "\033[1;36m● Review Team Staffing\033[0m"
        echo -e "  Change type: \033[31mschema change\033[0m (85 LOC)"
        echo -e "  Strategy:    \033[31mdeep-review\033[0m"
        echo ""
        echo -e "  \033[1mTeam (3 of 14 reviewers):\033[0m"
        echo -e "    \033[36m→ Code Reviewer\033[0m           (Opus)"
        echo -e "    \033[36m→ Database Engineer\033[0m       (Opus)"
        echo -e "    \033[36m→ Security Engineer\033[0m       (Opus)"
        echo ""
        echo -e "  \033[1;33m⚠ RLS policies will be verified\033[0m"
        echo -e "  \033[1;33m⚠ Schema checked before migration\033[0m"
        echo ""
        echo -e "  Est. cost: \033[1;31m~\$3.00\033[0m"
        echo -e "  \033[2mSecurity is worth the tokens.\033[0m"
        echo ""
        ;;
esac
