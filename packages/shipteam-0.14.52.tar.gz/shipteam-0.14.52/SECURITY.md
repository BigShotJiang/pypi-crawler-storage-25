# Security Policy

## Supported Versions

| Version | Supported |
|---------|-----------|
| Latest release | Yes |
| Previous minor | Security fixes only |
| Older | No |

## Reporting a Vulnerability

If you discover a security vulnerability in ShipTeam, please report it responsibly.

**Do NOT open a public GitHub issue for security vulnerabilities.**

### How to Report

1. **GitHub Security Advisories** (preferred): Use the "Report a vulnerability" button on the Security tab of this repository
2. **Email**: security@cdjgroup.dev (or see repository maintainer's GitHub profile)

### What to Include

- Description of the vulnerability
- Steps to reproduce
- Affected versions
- Potential impact
- Suggested fix (if any)

### Response Timeline

- **Acknowledgment**: Within 48 hours
- **Initial assessment**: Within 7 days
- **Fix timeline**: Depends on severity
  - Critical: Patch within 7 days
  - High: Patch within 30 days
  - Medium/Low: Next scheduled release

### Scope

The following are in scope for security reports:

- **Hook system** (`auto_approve_base.py`, overlays) — command injection, bypass, privilege escalation
- **Session management** (`branch-check.py`, `claude-session.sh`) — session hijacking, lock bypass
- **Secret guard** (`validate-no-public-secrets.sh`) — pattern bypass, false negatives
- **CI/CD workflows** — supply chain, token exposure, privilege escalation
- **Framework scripts** — injection via config, unsafe file operations

The following are out of scope:

- Issues in projects that *use* ShipTeam (report to those projects directly)
- Social engineering attacks
- Denial of service against local development environments
- Issues requiring physical access to the developer's machine

## Security Design Principles

This framework follows these security principles:

1. **Default-deny**: The hook system blocks known dangerous commands and falls through to user prompt for unknown commands — never auto-approves unknowns
2. **Defense in depth**: Multiple layers (hooks, branch checks, CI gates, secret scanning)
3. **Least privilege**: Scripts request minimal permissions; CI tokens are scoped
4. **Audit trail**: All changes go through git; safety gate decisions are logged to stderr
5. **Secure defaults**: New projects start with restrictive settings; relaxation is opt-in

## Security-Relevant Files

| File | Purpose | Modification Risk |
|------|---------|-------------------|
| `.claude/hooks/auto_approve_base.py` | Command safety gate | Critical — weakening allows destructive commands |
| `.claude/hooks/auto-approve.py` | Project overlay (extends base) | High — should only add restrictions |
| `.claude/hooks/branch-check.py` | Session isolation | Medium — bypass allows concurrent sessions |
| `scripts/validate-no-public-secrets.sh` | Secret scanning | Medium — pattern gaps allow secret leaks |
| `.github/workflows/*.yml` | CI/CD pipelines | High — supply chain attack surface |
| `config/framework.yaml` | Project configuration | Low — no secrets, trusted input |
