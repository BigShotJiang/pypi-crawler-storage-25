# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

Security fixes are identified in release notes with CVE IDs when applicable.

## [Unreleased] - Wheel-audit CI gate for PyPI publish safety (ADR-020)

### Added
- `scripts/wheel_audit.py` — post-build artifact inspector. Checks `.whl` for PYC_CHECK (`.pyc`/`.pyo`), PYCACHE_CHECK (`__pycache__/`), and BRIGHT_LINE (ADR-007 regex, NFKC-normalized). Checks `.tar.gz` sdist for PYC/PYCACHE only (BRIGHT_LINE on sdist produces false positives — sdist = repo tree, covered by `validate-no-bright-line.sh`). `_TEXT_BASENAMES` frozenset covers no-extension wheel members (METADATA is the primary leak surface). Empty `dist/` exits 2, not 0.
- `.github/workflows/wheel-audit.yml` — PR-time audit, no secrets, `pull_request` trigger. SHA-pinned checkout and setup-python.
- `.github/workflows/pypi-publish.yml` — `release: published` trigger with fail-closed job graph (`publish` needs `build-and-audit`). OIDC Trusted Publishing, `attestations: false`.
- `tests/test_wheel_audit.py` — 51 tests (43 unit + 1 integration + 8 forensics gap fixes) across 7 test classes. Integration test runs real `python -m build`.
- `docs/adr/020-wheel-audit-pypi-gate.md` — architecture decision for Release-event trigger vs tag-push, BRIGHT_LINE coverage asymmetry, fail-closed design, OIDC rationale, bypass surface.

### Changed
- `docs/85-SAFETY-LIMITS.md` — added "PyPI publish safety gate (wheel-audit)" section with coverage table, bypass surface, and TOCTOU note.
- `docs/20-DEPLOYMENT.md` — added "PyPI Release Process" section: one-time Trusted Publisher setup, release checklist, troubleshooting.
- `pyproject.toml` — added `integration` pytest marker.

---

## [Unreleased] - Task Pack v1 (URL Shortener): runnable benchmark across three drivers

### Added
- `task_packs/url_shortener/` — first first-party task pack on disk. Directory-per-pack layout with `pack.yaml`, `workspace_seed/` (R/W mount), `frozen_tests/` (RO scoring suite mounted outside the workspace), `injected_bugs/` (10 numbered variants), `prompt.md` (verbatim driver spec), and `Dockerfile` pinned by `@sha256:` digest.
- `task_packs/loader.py` — `pack.yaml` validates into typed `TaskPack` dataclass at load time via `__post_init__`. `resolve_pack(task: str) -> TaskPack` is the single entry point; `TaskPack.to_manifest_dict()` satisfies the existing `task_manifest: dict` Driver protocol contract.
- `drivers/claude_code.py` — Claude Code driver with salted system-prompt cache defeat (`uuid5(NAMESPACE_DNS, str(seed))` suffix; salt-overhead empirically probed at 33–38 tokens/call against `claude-sonnet-4-5`). `cost_source="computed"` (tokens × pinned rate sheet — SDK's `total_cost_usd` is unreliable per Issue #487). Three module-level patch points (`run_agent_sdk`, `ClaudeSDKClient`, `_check_salt_placement`) for cognitive isolation; production stub raises `NotImplementedError` so the driver cannot accidentally hit the network in tests. AC-17 fresh `ClaudeSDKClient` per `execute()` call (defends against SDK Issue #560 session leakage).
- `drivers/aider.py` — Aider CLI driver with `cost_source="scraped"` (cost parsed from stdout regex; Aider does not emit token counts natively). AC-19 vendor-error stdout scan (`rate.?limit|API.?error|connection.?error|context.?length.?exceeded|litellm\.exceptions`).
- `drivers/droid.py` — Factory Droid CLI driver with `cost_source="scraped"` (cost/tokens parsed from `-o json` stdout). AC-20 defense-in-depth: stdout regex match precedes the returncode check, so an exit-zero process whose stdout reports a rate limit is still aborted.
- `drivers/_subprocess_helpers.py::make_aborted_result` — single factory funnel for all abort paths (timeout, FileNotFoundError, vendor-text match, returncode-non-zero, missing tokens, cache leak, unrecognized model). Inline `DriverResult` construction in error paths is forbidden by convention and caught by per-phase + final-gate code review.
- `docs/adr/019-task-pack-v1-architecture.md` — extracts Phase 5 architectural rationale: directory-per-pack convention, sandboxed scoring split, salted cache defeat, three-driver protocol with `cost_source` polymorphism + abort-spine factory + cognitive isolation, defense-in-depth vendor-error scanning.

### Changed
- `scoring/acceptance.py` — replaced `xml.etree.ElementTree` with `defusedxml.ElementTree` for parsing pytest JUnit XML output. The agent under test can influence assertion-message text that pytest serializes into the XML, so XXE-hardened parsing is the correct posture. `pyproject.toml` adds `defusedxml>=0.7,<1` to the `dev` extra. Drop-in: `defusedxml.ElementTree.parse()` and `ET.ParseError` re-export the stdlib API. Caught by Semgrep's `python.lang.security.use-defused-xml.use-defused-xml` rule on PR #172 CI.
- `drivers/droid.py::_VENDOR_ERROR_RE` — broadened from narrower factorydroid-only pattern to UNION with AC-19's regex (Phase 5e final-gate HIGH-1). Production was narrower than the test docstring contract claimed (`tests/drivers/test_droid_error_scan.py:12` stated "shared AC-19 regex"). Both Aider and Droid route through litellm under the hood; the narrower regex would have silently let litellm-shaped errors pass through with `aborted=false` and a misleading `acceptance_pct=0.0`. The `factorydroid:\s*error` alternative is preserved for CLI-specific errors that lack the API/litellm context. Defense-in-depth favors false positives over false negatives.

### Tests
- 374/374 green across drivers/scoring/task_packs/aggregation/harness/integration/dashboard. +7 new tests in Phase 5e (4 for AC-14 salted-cache contract rewrite, 3 for AC-19 defense-in-depth on Droid stdout patterns: `litellm.exceptions.RateLimitError`, `connection error`, `context length exceeded`).

### Deferred (Phase 5g)
- DEPS-CRIT-1 (CVE-2026-35022 CVSS 9.3 Auth Helpers), DEPS-CRIT-2 (CVE-2026-35021 CVSS 8.4 Prompt Editor), DEPS-HIGH-2 (claude-agent-sdk 0.1.68 vs 0.1.69 audit), CONCURRENCY-RACE-2 (id() tautology). All CVE attack surfaces are unreachable in Phase 5e because `run_agent_sdk` is a `NotImplementedError` stub; the SDK is wired but not invoked end-to-end until Phase 5g.

### Insight
- ADR-016 (empirical CLI probe before TDD) fired four times across Phase 5: salt overhead estimate (Step 3 "~20" → Step 4.5 "≤30" → Phase 5e probe "33–38"), lstat-vs-stat semantics for symlink defense, Aider stdout regex authored from real CLI output not source-reading, Droid `_VENDOR_ERROR_RE` narrowed-by-comment-then-broadened by final-gate review. A documentation-derived TDD spec lets RED and GREEN agree on a hallucination — only the empirical probe surfaces real numbers and real string shapes.
- Abort-spine consistency is a factory invariant, not a discipline. `make_aborted_result` makes the convention enforceable; without it, three drivers with three different cost-extraction shapes would each grow their own abort dialect. The factory turns a discipline into a type.

## [Unreleased] - Framework `/private/` convention: scaffold + CLAUDE.md template

### Added
- `src/shipteam/scaffold.py` — `REQUIRED_GITIGNORE_ENTRIES` extends from 4 to 5 entries; `/private/` joins `.claude/state/`, `.context/`, `.qa-reports/`, `.shipteam-init.yaml`. Leading slash anchors to repo root. Idempotent (existing AC-14 tests cover).
- `src/shipteam/framework/templates/CLAUDE.md.jinja` — new managed region `<!-- SHIPTEAM:BEGIN:private_content_convention -->` between TDD Workflow and Project-Specific Notes. Documents the convention and cross-references the Workspace Hygiene rule.

### Changed
- `tests/test_scaffold.py` — `REQUIRED_GITIGNORE_ENTRIES` fixture mirrors production list (5 entries). Existing parametrized AC-14 tests automatically extend coverage to `/private/`; no new test bodies needed. One stale comment count corrected.

### Insight
- Two distinct framings now cohabit: ADR-007 governs the framework-development repo (no strategic content in tree); the `/private/` convention governs consumer projects (in-repo escape hatch). Different audiences, different tools — the framework ships both.
- Migration: `uvx shipteam init --refresh` appends `/private/` to existing projects' gitignores idempotently. Projects already using `/private/` are unaffected.

## [Unreleased] - Repo hygiene: `/private/` convention + hook runtime state in .gitignore

### Added
- `.gitignore` — `/private/` line for in-repo private/IP content per the global `~/.claude/CLAUDE.md` convention (drafts, scratch, hackathon ground-truth, copyrighted screenshots, strategic mapping docs). Single-line exclude; anything under `private/` is invisible to git and lives only on the maintainer's local filesystem.
- `.gitignore` — `/.claude/expected-branch.txt` runtime-state exclude. The file is read by `branch-check.py:88` and `branch-tracker.py:49`; it joins the existing `.claude/state/*` pattern.

### Changed
- `COMPARISON.md` — relocated from repo root to `private/COMPARISON.md` on the maintainer's local filesystem. The file was never tracked in git history (always untracked at root), so the relocation does not appear in commit history. The move is maintainer-local cleanup that pairs with the new `/private/` convention.

### Insight
- `.gitignore` is exposure control, not persistence control. The `/private/` convention answers "is this in git?" (no) with a stable answer to "will the filesystem this lives on be there next week?" (yes, in the main checkout) — exactly the shape strategic working content needs. ADR-007 bright-line sanitization is the *what*; this is the *where*.

### Follows
- Companion to the Workspace Hygiene rule below — same orthogonal-axes framing, applied at the repo-layout layer rather than the workflow layer.
- A follow-up PR will document the `/private/` convention in the framework templates so projects scaffolded via `uvx shipteam init` get the convention by default.

## [Unreleased] - perf(agents): demote `fw-review-concurrency` and `fw-review-dependencies` to Sonnet

### Changed
- `.claude/agents/fw-review-concurrency.md` — `model: opus` → `model: sonnet`. The agent does rule-driven detection on well-bounded async patterns (race conditions, deadlock heuristics, shared-state) that Sonnet 4.6 handles equivalently.
- `.claude/agents/fw-review-dependencies.md` — `model: opus` → `model: sonnet`. The agent does pattern-matching and enumeration over deterministic data (CVE reachability, license compatibility, maintenance health, typosquat detection) — Sonnet 4.6 handles this equivalently.

### Insight
- Identified via `/deep-r` analysis of 7-day token spend: these two reviewers were running Opus-tier cost for work the telemetry showed Sonnet handles equivalently. Selective demotion driven by spend telemetry is leaner than periodic "audit the whole fleet" sweeps that tend to over-rotate.
- Narrow reviewers that DO benefit from Opus judgment (architecture, security threat modeling, performance optimization, ambiguous correctness) keep Opus. This is targeted, not blanket.

## [Unreleased] - Workspace Hygiene rule for ephemeral worktrees

### Added
- `.claude/rules/sherlock-methodology.md` — new `## Workspace Hygiene — Durable Writes in Ephemeral Workspaces` section codifying the failure mode where durable working content (drafts the next session expects to read) gets written to a gitignored path inside an ephemeral workspace and is then lost on cleanup. Includes detection snippet (`git rev-parse --git-common-dir` vs `--git-dir`) with three documented edge cases (submodules, `GIT_DIR` env override, git ≤ 2.1.4 returning the literal flag string per pre-commit #831), recovery steps, and generalization to worktrees / devcontainers / Codespaces / Docker volumes / CI runners.
- Cross-reference prompts at three workflow gates: Hudson Step 4 (pre-commit), Sherlock Lite Step 6 (post-commit pre-PR), Full Sherlock Step 8 (post-commit pre-PR). Each uses conversation-context recall + `git status --ignored --short` (gitignored files don't appear in `git diff`).

### Insight
- Rule body is explicit about its compliance ceiling: cites IFScale (arXiv 2507.11538) ~68% at high instruction density and lost-in-the-middle (arXiv 2307.03172). Deterministic PreToolUse hook deferred to N=3 incidents per Rule of Three (Beck/Fowler) — at N=1, the rule is the deferred-cost option.
- Lives in `policy: replace` so `fw-sync.sh` propagates to all framework-using projects without a separate auto-load step. New `.claude/rules/*.md` files do NOT auto-load without an explicit `CLAUDE.md` cross-reference (there is no auto-load registry) — embedding in the existing `sherlock-methodology.md` avoids that bug.

### Follows
- Strategy validated end-to-end via `/deep-r` audit before commit. The audit caught two factual errors in the original proposal about `fw-sync.sh` policy semantics; the single-file-embed shape avoids both.

## [Unreleased] - Git push policy in `auto_approve_base.py` (CWE-551 inversion principle)

### Added
- `auto_approve_base.py` framework-wide git push policy via `policy: replace` in `config/fw-manifest.yaml` — projects cannot drift. Five new helpers: `_normalize_ref`, `_parse_push_targets`, `_command_has_wildcard_refspec`, `_command_has_disallowed_namespace`, `_command_has_delete_refspec`.
- Hard denies for: `git push --no-verify` / `--tags` / `--mirror` / `--all`; refspec-to-protected (`feat/foo:main`, `refs/heads/feat/foo:refs/heads/main`, `HEAD:main`, `HEAD~3:main`); namespace tricks (`refs/notes/`, `refs/replace/`, `refs/tags/`); wildcard refspecs (`*:*`, `+refs/heads/*:refs/heads/*`); bare semver tag pushes (`v1.0`, `V1.2.3`, case-insensitive); legacy delete syntax to protected (`origin :main`, hardened against env-prefix obfuscation).
- Auto-approves for push to safe-prefix branches (`session/*`, `feat/*`, `fix/*`, `docs/*`, `chore/*`, `refactor/*`, `test/*`) with `-u` / `--set-upstream` or no flag. Gated by four independent refuse paths before `approve()` fires: (1) `ENV_PREFIX_PATTERN.match(command)` refuses any env-prefix on the ORIGINAL command; (2) `has_shell_operators` refuses CWE-551 shell metachars; (3) unknown-flag whitelist (only `-u` / `--set-upstream`); (4) delete-refspec guard refuses `:branch` / `+:branch`.
- 27 new tests in `test/safety_gate.bats` covering all 21 ACs + Phase 2 security review additions (5 RCE env vars, 3 delete-refspec variants) + Phase 4 defense-in-depth (3 shell-builtin shifted env-prefix forms: `command env GIT_SSH_COMMAND=...`, `exec LD_PRELOAD=...`, `nohup nice GIT_SSH_COMMAND=...`).

### Changed
- `ENV_PREFIX_PATTERN` extended to absorb shell-builtin shifts (`command`, `exec`, `nice`, `nohup`, `time`, `setsid`, `unshare`) — closes the latent coupling that would have allowed `command env GIT_SSH_COMMAND=evil git push origin feat/foo` to evade the env-guard if `push_regex` ever broadened. Today `push_regex` rejects the form anyway; defense-in-depth ensures the C-1 invariant ("env-guard catches every env-bearing form on its own") holds independently of regex evolution.
- `CLAUDE.md` "Automatic Protections" section rewritten into structured `HARD BLOCKS` / `AUTO-APPROVES` / `FALLS THROUGH` / `OTHER HOOKS` subsections with honest accounting of what's gated vs. what falls through to user prompt. Doc-vs-code drift fixed: `.claude/skills/` removed from the safety-write hard-deny list (Edit/Write tool calls fall through to user prompt; only shell-redirect/tee/cp/mv/ln to `.claude/hooks/`, `.claude/rules/`, `.claude/settings.json` are hard-denied).
- `SETUP.md`, `CONTRIBUTING.md` — drop instructions to copy `.claude/settings.local.json.template`; explain that hooks register via the shipped `.claude/settings.json`.
- `test/template_instantiation.bats:134` — assertion updated from "template exists" to "settings.json exists".

### Removed
- `.claude/settings.local.json.template` — was byte-identical to the shipped `.claude/settings.json` with zero runtime consumers and four live doc references that told contributors to copy a file the framework had stopped using.
- `test/settings_template.bats` — entire file was about the dead template.

### Security
- **CWE-551 inversion principle (architectural)** — block path canonicalizes `cmds_to_check = {original, inner_command, effective_command}` and uses paranoid-OR ("any variant matches → block"); allow path guards on the ORIGINAL command and uses paranoid-AND ("command itself was already canonical → allow"). An obfuscated dangerous command still hard-denies because canonicalization catches it; an obfuscated safe command falls through to user prompt because canonicalization on the allow side is a gift to the attacker, not a defense. This asymmetry is the load-bearing safety property.
- **Latent-coupling regression vector closed** — the Phase 4 final-gate security re-scan caught a Medium where shell builtins shifted the env-prefix anchor right by one or more words. Closing it now means the C-1 invariant holds independently of `push_regex` future evolution.

### Follows
- ADR-018 extraction queued post-merge — full Sherlock plan (`.sherlock-plan-push-policy.md`) captures the CWE-551 inversion principle + the latent-coupling rule + the four-refuse-paths auto-approve gate as the architecture decision of record.
- M2 flag-with-value parser deferred (low severity, no exploit path); AC-18 conformance scorer false-negative deferred (scorer regex collision unrelated to runtime safety).

## [Unreleased] - Benchmark Harness Phase 3 Sub-phase A4: empty-denylist fail-closed + ADR-017 extraction (closes Phase 3 Sub-phase A)

### Changed
- **`dashboard/render.py::_load_denylist`** — empty denylist (zero tokens after stripping comments and blank lines) now raises `ValueError` (was: stderr warning + return empty list). The exception message names the denylist path so operators can diagnose without grepping logs. Distinct exception class from `_check_denylist`'s `RuntimeError` so callers can distinguish "your config is wrong" from "your content leaked".
- **`tests/dashboard/test_render.py::TestA3Hardening::test_da11_empty_denylist_raises_value_error`** — DA-11 oracle flipped to `pytest.raises(ValueError)`; asserts path-in-message, no output file written, and silent stdout/stderr (the A3 warning channel was retired with the policy flip).
- **Test fixtures** — 12 sibling tests that wrote empty denylist files as no-op fixtures now write a non-matching sentinel constant (`_NO_MATCH_DENYLIST`) so they don't trip the new fail-closed path. The DA-9 violation test and DA-11 empty-path test are unaffected.

### Security
- **Empty-denylist fail-closed (closes A3 H-2)** — A3 shipped fail-open-with-warning intentionally; A4's threat-model honesty pass concluded that a misconfigured deployment ship-with-no-enforcement is the failure mode that matters. A loud break on misconfig is recoverable; a silent ship of leaked content is not.
- **DELIBERATELY DEFERRED** — H-1 (UTS #39 skeleton algorithm for Greek/Armenian/combining marks) and M-3 (DA-15 parametrize expansion) are out of scope for v1. ADR-017 documents the threat-model rationale: the v1 harness has no untrusted-input ingress; the dashboard denylist is one of three ADR-007 gates (bright-line CI scan + git review + runtime denylist). Trigger to revisit: dashboard outputs become public-facing OR an untrusted-input-fed path lands in the harness.

### Follows
- A4 closes Phase 3 Sub-phase A (A1 + A2 + A3 + A4). [`docs/adr/017-benchmark-harness-architecture.md`](docs/adr/017-benchmark-harness-architecture.md) extracts the architecture from the now-retired `.sherlock-plan.md` per the Sherlock methodology Step 8 protocol. The plan and `.test-matrix.md` are deleted in a follow-up commit on the same PR (revertible if reviewer asks).

---

## [Unreleased] - Benchmark Harness Phase 3 Sub-phase A3: denylist hardening (atomic write, fail-closed on missing denylist, malformed-row filter, XSS, Unicode/ZWSP + hyphen)

### Added
- `dashboard/render.py::_normalize_for_denylist(text) -> str` — NFKC normalization → 6-entry Cyrillic confusable fold → 4-char zero-width strip → whitespace collapse. Docstring enumerates bypass classes NOT covered (Greek, Armenian, combining diacritics, U+2060 word joiner, U+180E Mongolian vowel separator) so boundaries are legible to the next maintainer.
- `dashboard/render.py::_token_matches(html, token) -> bool` — word-boundary regex helper with empty-token guard; extracted from `_check_denylist` for readability.
- **Atomic write invariant (AC-15)** — denylist gate runs before any `write_text`; a denylist violation leaves no artifact on disk (DA-9).
- **Fail-fast on missing denylist (AC-15)** — missing denylist file raises `FileNotFoundError` with no output written (DA-10).
- **Empty-denylist stderr warning (AC-15)** — empty denylist emits `WARNING: empty denylist at <path>` to stderr and still renders (fail-open-with-warning; DA-11).
- **Malformed-row filter (AC-10)** — rows missing `driver` OR `task` are skipped and counted; template renders `<div data-qa="malformed-rows-banner">` when count > 0 (DA-12 + absence companion).
- **XSS lock (AC-10)** — Jinja2 autoescape via `select_autoescape(["html"])` + `_ENV.from_string(...)`; attacker-controlled `driver_version` containing `<script>` renders as HTML-encoded text (DA-13).
- **Unicode/ZWSP/whitespace denylist bypass defense (AC-15)** — `_check_denylist` re-checks the normalized form of HTML AND normalized form of the token; catches Cyrillic confusables (`рricing`), zero-width injections (`pri‍cing`), literal-space splits (`pri cing`). DA-15 parametrized across 3 bypass classes + 1 absence companion (`repricing` must not fire).
- **Hyphenated-form lock-in (AC-15)** — `pricing-model` fires on denylist token `pricing` (Python `\b` treats hyphens as word boundaries); DA-16 locks this behavior against future regex refactors.
- 2 new fixtures — `malformed_row.jsonl` (10 rows, row 10 missing `driver`) and `xss_row.jsonl` (single row with `<script>` payload in `driver_version`).

### Changed
- `dashboard/render.py::render_dashboard` malformed-row guard now checks BOTH `driver` and `task` keys (earlier version would have KeyError on a row missing `task`).
- Template uses `data-qa="partial-cell"` / `data-qa="malformed-rows-banner"` stable attributes rather than free-text substrings — matches the A2 dual-surface convention.

### Security
- **Defense-in-depth Unicode normalization** — closes the specific bypass classes enumerated in DA-15 (Cyrillic letters р/о/а/с/е/х, zero-width chars ZWSP/ZWNJ/ZWJ/BOM, ASCII whitespace splitters). Does NOT yet implement UTS #39 skeleton — deferred to A4 with explicit documentation of the gap in the `_normalize_for_denylist` docstring. fw-review-security ran per-phase and flagged the UTS #39 upgrade as H-1 to A4; A3 ships the stopgap that closes the test-suite bypass classes now.
- **Fail-fast on missing denylist** — prevents a silent render with an unpopulated denylist. Empty denylist is fail-open-with-warning (intentional; the fail-closed alternative is H-2 to A4).

### Follows
- A3 completes the AC-15 hardening edges for Phase 3 Sub-phase A. ADR-011 extraction queued for post-A3 landing — the full Sub-phase A (A1 + A2 + A3) gets one ADR capturing the dashboard-rendering architecture + Unicode normalization policy.

---

## [Unreleased] - Benchmark Harness Phase 3 Sub-phase A2: partial-cell marker + mixed-digest / mixed-sdk dual-surface warnings

### Added
- `dashboard/render.py::_detect_mixed_metadata(rows, field) -> bool` — pure helper returning True when rows contain two or more distinct values for a given field. `None` counts as a distinct value (missing-field row is environment-unknown, warning-worthy).
- **Partial-cell marker (AC-10 (b))** — `data-qa="partial-cell"` attribute on the existing partial-cell `<p>` tag. Fires when `aggregate_cell` reports effective N ≤ threshold (7/10 inclusive, per Phase 2 Part 2 Sub-phase D).
- **Mixed-metadata dual-surface warning (AC-10 (c))** — top-of-page banners with `data-qa="digest-banner"` / `data-qa="sdk-banner"` (rendered before any `<section>`, listing affected `(driver, task)` pairs in a `<ul>`) PLUS per-cell badges with `data-qa="digest-badge"` / `data-qa="sdk-badge"` inside the affected `<section>`. Fires when rows in a single cell disagree on `container_digest` or `sdk_version`.
- 5 new tests in `tests/dashboard/test_render.py` — DA-2 (partial-cell marker presence + 4-marker mixed-metadata absence), DA-3 (mixed-digest dual surface with banner-outside-section + badge-inside-section position checks), DA-4 (clean-digest + clean-sdk 4-marker absence oracle on `full_cell.jsonl`), DA-5 (mixed-sdk dual surface), DA-14 (aborted-row exclusion lock: medians over 7 non-aborted rows + partial marker fire + 3-seed absence of extreme values).
- 4 new fixtures — `partial_cell.jsonl` (n=3, uniform), `mixed_digest.jsonl` (n=10, 5/5 split on `container_digest`), `mixed_sdk.jsonl` (n=10, 5/5 split on `sdk_version` only; `driver_version` held constant to prevent DA-5 silent pass if an impl reads the wrong field), `aborted_rows.jsonl` (n=10, 7 non-aborted + 3 aborted with extreme values for aggregator-boundary regression guard).

### Changed
- `tests/dashboard/test_render.py::test_da1_full_cell_does_not_emit_partial_marker` — asserts on `data-qa="partial-cell"` attribute rather than the free-text substring "partial". Decouples the oracle from rendered copy; matches DA-3/DA-4/DA-5 convention.

### Security
- No new security changes. fw-review-security ran per-phase on the A2 diff and returned Medium-only (pre-existing A1 ADR-007 denylist confusables bypass — unicode/ZWSP/whitespace splitters defeat ASCII `\b`). Bypass is widened marginally by A2's two additional render sites for the same attacker-controlled `driver`/`task` strings; reviewer explicitly recommended "ship A2 cleanly, follow-up PR" for NFKC-normalize + ZWSP-strip hardening. A3 covers this (DA-15).

### Follows
- A2 completes AC-10 (b) + AC-10 (c) for Phase 3 Sub-phase A. A3 (DA-15 Unicode normalization + DA-16 hyphen lock-in) remains open. ADR-011 extraction queued for post-A3 landing (not per-sub-phase).

---

## [Unreleased] - Benchmark Harness Phase 3 Sub-phase A1: dashboard static HTML + ADR-007 denylist gate

### Added
- `dashboard/render.py::render_dashboard(input_jsonl, output_html, denylist_path)` — reads sweep JSONL, groups by `(driver, task)`, computes median + p25/p75 per cell via `aggregation.results.aggregate_cell`, renders single-file static HTML via Jinja2 (`select_autoescape(["html"])` + `from_string` with `default_for_string=True`). Pre-write denylist gate: `re.search(rf"\b{re.escape(token)}\b", html, re.IGNORECASE)` — any hit raises `RuntimeError` BEFORE `output_html.write_text`. `.10g` float formatting rounds IEEE 754 accumulated noise without distorting exact small decimals. ~100 LOC.
- `tests/dashboard/test_render.py` — 4 DA-1 tests for AC-10 (a). Hand-computed median/p25/p75 against a deterministic 10-row fixture for `acceptance_pct`, `wall_clock_ms`, `cost_usd`. `_assert_metric_row` uses a bounded-segment DOTALL regex (rejects cross-row bleeding between metric rows). Negative-sample guard: full cell must not render a "partial" marker.
- `tests/dashboard/test_denylist.py` — 7 DA-6/7/8 tests for AC-15. Denylist hit → `RuntimeError`, output file not written. Case-insensitive matching (DA-7). Word-boundary enforcement rejects substring-of-longer-word false positives (DA-8).
- `tests/dashboard/fixtures/full_cell.jsonl` — 10-row deterministic fixture, seeds 0-9, full `ResultRow` shape.

### Security
- **Jinja2 floor bumped `>=3.1.4,<4.0` → `>=3.1.6,<4.0`** — closes ingested-dependency window for CVE-2024-56326 (str.format sandbox escape, fixed 3.1.5) and CVE-2025-27516 (`|attr` filter sandbox escape, fixed 3.1.6). Autoescape on rendered output already mitigates the attack surface in `render.py`, but the floor bump hardens any future reuse of Jinja2 in this codebase. CVE attribution flagged `UNVERIFIED_CLAIM` for external verification before downstream quoting; Jinja2 changelog is citation of record.
- **ADR-007 denylist gate** now enforced on the dashboard artifact — the primary artifact external reviewers see, populated from attacker-influenceable JSONL fields (`driver_version` free-form string from the tool under test). Pre-write `RuntimeError` eliminates the partial-file-on-disk failure mode that post-render inspection would have.

### Follows
- A1 ships alone (not bundled with A2/A3). A2 (partial-cell rendering, DA-2 through DA-5) and A3 (Unicode normalization + hyphenated-token hardening, DA-15 + DA-16 added to `.test-matrix.md` during A1 review) remain open. ADR-011 extraction queued for post-A3 landing.

---

## [Unreleased] - Benchmark Harness Phase 2 Part 2 Sub-phase D: aggregate_cell median/IQR (completes Phase 2 Part 2)

### Added
- `aggregation/results.py::aggregate_cell` + extended `CellSummary` with AC-21 per-metric None-handling. Partial-cell WARN at effective_n ≤ 0.7 × row_count_valid; cell-invalid ERROR at effective_n < 3 (median/p25/p75 return None for that metric). WARN suppressed when ERROR fires (per-phase review M-2). Degenerate inputs (`[]` or all-aborted) return CellSummary with per-metric errors populated, no exceptions raised. +95 LOC.
- `tests/aggregation/test_aggregate_cell.py` — 17 tests across 6 classes covering T-19 / T-20 / T-71 / T-72 / T-73 / T-74 / T-75. All green.

### Completes
- Phase 2 Part 2 scoring pipeline: acceptance (Part 1) + injected_bugs (Sub-phase A, PR #146) + mutation (Sub-phase B, PR #147) + semgrep (Sub-phase C, PR #148) + aggregation (this PR). Phase 2 Part 3 (CLI + runner integration + task packs) is the next batch.

---

## [Unreleased] - Benchmark Harness Phase 2 Part 2 Sub-phase C: Semgrep Scorer (+ SSRF/LFI Defense)

### Added
- `scoring/semgrep.py` — Semgrep static-analysis scorer. AC-20 P0 40-char hex SHA validator (rejects mutable refs `main`/`HEAD`/etc on ruleset URLs). AC-21 P0 SemgrepCache sweep-lifetime with `.sweep_id` sentinel self-invalidation. AC-2 9-severity `by_severity` dict + `unknown_severities` overflow. AC-17 fail-closed across 5 error keys (`tool_missing`, `semgrep_timeout`, `semgrep_output_malformed`, `semgrep_failed`, `ruleset_fetch_failed`). R4 tempfile-output to avoid issue #4676 stdout interleave. 306 LOC. `frozen=True` SemgrepResult with Literal-typed `error` and `tool_name`.
- `tests/scoring/test_semgrep.py` — 27 tests across 10 classes covering T-49 / T-58 / T-60–T-70. All green.

### Security
- **SSRF/LFI defense**: `_StrictHTTPSRedirectHandler` subclass of `urllib.request.HTTPRedirectHandler` refuses 3xx redirects into non-https schemes (`file://`, `ftp://`, `data://`) and non-allowlisted hosts. Python's default handler would have followed these, letting an attacker-controlled manifest URL on the allowlisted host redirect to `file:///etc/passwd` and cache that content as a "ruleset." T-69 (×3) locks this defense in.
- **HTTPS-only** for remote rulesets (TOFU hardening; attacker in transit could substitute bytes over http://). T-70 tests rejection via RulesetRefError before any fetch.
- **`raw.githubusercontent.com` host allowlist** enforced in both initial URL validation AND redirect handler.
- **Full 64-char SHA-256 cache file naming** (closes birthday-collision surface against attacker-grindable manifest URLs).

---

## [Unreleased] - Benchmark Harness Phase 2 Part 2 Sub-phase B: Mutation Scorer

### Added
- `scoring/mutation.py` — mutmut (Python) + Stryker (JS/TS) mutation scorer. AC-19 MUST-HAVE multi-signal success detection: full `mutants/` cleanup pre-run via `shutil.rmtree` (fail-loud on permission errors); internal-consistency arithmetic check; `subprocess.TimeoutExpired` and `OSError` caught and mapped to structured error keys. Stryker process-group cleanup via `Popen(start_new_session=True)` (CPython gh-114220 thread-safe alternative to deprecated `preexec_fn=os.setsid`); pgid captured immediately after Popen (PID-recycle TOCTOU mitigation); `os.killpg(SIGTERM)` with `proc.wait(5)` reap + SIGKILL escalation. AC-17 fail-closed (tool-missing → per_language_error). AC-6 reproducibility: `npx --no-install` forbids registry auto-fetch. Score=None semantic for empty denominator. New `ToolName`/`LangErrorKey` Literal types. `LanguageMutationScore` is `frozen=True`. 279 LOC.
- `tests/scoring/test_mutation.py` — 15 tests across 8 classes covering T-15 / T-16 / T-47 / T-48 / T-51 / T-52 / T-53 / T-54a / T-54b / T-55 (mutmut timeout) / T-56a (total=0) / T-56b (all-Ctrl-C) / T-57 (denom=0 for both Python and Stryker). All green.

### Security
- AC-19 cache-cleanup is whole-`mutants/`-dir, not just the stats file. Half-cleaning would silently use prior-workspace cached mutants against new workspaces (silent corruption).
- `npx --no-install`: forbids registry auto-fetch of Stryker. Eliminates supply-chain typo-squat exposure and enforces AC-6 version pinning (Stryker version comes from pre-installed `node_modules/.bin`, not registry resolution at scorer-call-time).

---

## [Unreleased] - Benchmark Harness Phase 2 Part 2 Sub-phase A: Injected-Bug Scorer

### Added
- `scoring/injected_bugs.py` — corpus loader + injected-bug correlation scorer for the benchmark harness. AC-9 MUST-HAVE corpus gate (`validate_corpus`, default min_bugs=20); AC-16 corpus format with path-traversal + symlink-escape defense via `Path.resolve()` + `is_relative_to()`; AC-17 fail-closed on missing/malformed `test_results.json`. 137 LOC. Frozen dataclasses with tuple fields; `Literal[1]` `schema_version`; structured `CorpusSecurityError(bug_id, attempted_path, resolved_path)`.
- `tests/scoring/test_injected_bugs.py` — 14 tests covering T-14, T-23, T-43–T-46, AC-17. All green.
- `.sherlock-plan.md` Phase 2 Part 2 Scope Delta section with /deep-r R1–R6 + red-team Q1–Q10 plan fixes (Sub-phase A's commits land Sub-phase A's portion; Sub-phases B/C/D follow in subsequent PRs).
- `.test-matrix.md` Part 2 test entries T-43..T-61 with regression-guard pitfalls for mutmut/Stryker/Semgrep/aggregation gaps surfaced by /deep-r.

### Security
- Path-traversal defense in `load_corpus` rejects `patch_file` paths that escape corpus root (dotdot `..` and symlink-escape both tested). Trust boundary documented: corpus is first-party trusted, `output_dir`/`workspace` are harness-controlled.

---

## [Unreleased] - claude-session.sh env-scrub at the claude boundary

### Changed
- `scripts/claude-session.sh:644`: `claude` → `env -u FW_PROJECT_ROOT -u FW_CONFIG -u FW_FW_DIR -u FW_ROOT_OVERRIDE -u FW_SKIP_PREREQ_CHECK claude`. Strips framework identity + override env vars at the claude-launch boundary. Closes the contamination ORIGIN (PR #143 closed the downstream validator/git-script surface). Without this fix, the `claude-<project>` shell alias generated by `generate-shell-alias.sh` launches a session whose env carries `FW_PROJECT_ROOT=<main-repo path>` by virtue of the alias function body sourcing `_framework.sh` in the current shell before invoking `claude`. Cosmetic color vars (`FW_RED/GREEN/YELLOW/BLUE/NC`) intentionally preserved.

### Security
- **Before**: every framework script invocation inside a claude session triggered PR #143's guard warning because the env was inherited from the launcher.
- **After**: env is clean at session start; auto-detection runs normally; PR #143's guard remains as defense-in-depth for unusual paths (manual `export`, cross-tree audits, test fixtures).

---

## [Unreleased] - `_framework.sh` Cross-Worktree Env-Var Contamination Guard

### Added
- `scripts/_framework.sh`: new guard block that detects when a pre-set `FW_PROJECT_ROOT` disagrees with the script's `$BASH_SOURCE`-derived location. Emits a warning to stderr and overwrites `FW_PROJECT_ROOT` with the script-derived value unless `FW_ROOT_OVERRIDE=1` is set. Defensive `${BASH_SOURCE[0]:-}` guard skips the block cleanly under non-bash invocation. Closes the silent-wrong-answer path where validators and git-mutating scripts scan the wrong tree.
- `FW_ROOT_OVERRIDE=1`: new opt-in env var. Honors the pre-set `FW_PROJECT_ROOT` value without triggering the cross-worktree guard. Used by test fixtures that deliberately point at non-matching paths; also available for deliberate cross-tree audits.
- `test/framework_worktree_env.bats`: 11 regression tests covering AC-1..AC-6 including real `git worktree add`-based worktree cases. All green on this branch; 3 fail on `origin/main` (the guard isn't there yet — the expected RED state).

### Changed
- `test/framework_config.bats`: 6 fixture call sites now pass `FW_ROOT_OVERRIDE=1` (lines 53, 210, 224, 238, 252, 259) with an inline comment explaining why the override is required. Without it, the new guard rewrites `FW_PROJECT_ROOT` back to the real project root and defeats the fixture.
- `test/worktree_bootstrap.bats:40`: adds `export FW_ROOT_OVERRIDE=1` for the same reason.
- `docs/50-TESTING.md`: documents the `FW_ROOT_OVERRIDE=1` requirement for `_fixture_read`.

### Security
- Bug class: silent corruption (scanner scans wrong tree, returns wrong verdict, no visible error). The fix converts it to fail-closed-with-warning: user sees the mismatch immediately and can either fix the env or opt in explicitly.
- Upstream-issue amplification: Claude Code issues #1985, #28801, #27343, #36360 document the same class of cross-session env-var contamination. The guard mitigates against all of them without depending on upstream fixes landing.

---

## [Unreleased] - Lead-Level MATH-VERIFY-FLAG Gate Before Commit

### Added
- `.claude/rules/sherlock-review-gate.md` — new `MATH-VERIFY-FLAG Protocol` subsection (parallel to the existing `RESEARCH_NEEDED Flag Protocol`) defining four lead behaviors: collect flags; for Critical/High findings invoke `/verify-math` and record in Decision Digest; Medium/Low = log, don't block; `MATH-VERIFY-UNAVAILABLE` = confirm the agent's own downgrade, don't re-run the verifier.
- `.claude/rules/sherlock-review-gate.md` — fourth bullet in `Commit Criteria`: zero unresolved `MATH-VERIFY-FLAG` attached to Critical/High findings.
- `.claude/rules/sherlock-methodology.md` — MATH-VERIFY-FLAG check reference in Sherlock Lite Step 5 Final Gate.
- `.claude/rules/sherlock-methodology.md` — MATH-VERIFY-FLAG check reference in Full Sherlock Step 7 Final Review Gate.

### Changed
- Lead behavior on review output — a finding containing a `MATH-VERIFY-FLAG` attached to a Critical or High finding now blocks commit until verified, downgraded to qualitative, or deferred with documented reason.

---

## [Unreleased] - Extend Math Verification to Tests, Migration, and Release Advisors

### Changed
- `.claude/agents/fw-review-tests.md` — added Math Verification section covering coverage %, mutation scores, sample sizes, flakiness rates. Cites NIST SEMATECH e-Handbook, IEEE 754.
- `.claude/agents/fw-author-migration.md` — added Math Verification section covering row-count estimates, index size, migration duration, batch size tuning. Section body explicitly calls out that users plan maintenance windows from these numbers.
- `.claude/agents/fw-advisor-release.md` — added Math Verification section covering rollout %, SLO error budget, canary sample size, rollback duration, traffic split. Cites SRE workbook conventions.

All three sections follow the same GSM-Symbolic citation, `MATH-VERIFY-UNAVAILABLE`-triggered downgrade-to-qualitative rule, and `MATH-VERIFY-FLAG: [expression]` emission as the three agents that received the pattern in ADR-013/014.

---

## [Unreleased] - Auto-Bump Description Freshness + TDD Commit Auto-Push

### Added
- `scripts/clear-version-description.sh` — helper that rewrites CLAUDE.md's `## Current Version:` line to `X.Y.Z - (pending release notes)`. Idempotent across successive auto-bumps; fails loudly if the heading is missing or the sed pattern doesn't match (catches CRLF endings).
- `.github/workflows/auto-version-bump.yml` — new `Clear version description to pending placeholder` step after `bump-version.sh` so automated patch bumps stop inheriting the description from the last feature PR. `CLAUDE.md` added to the workflow's `paths-ignore`.
- `scripts/tdd-commit.sh` — auto-push on first commit of non-`session/*` branches. Runs `git push -u origin HEAD` after the commit succeeds; fails open with a WARNING to stderr (carrying git's first stderr line so secret-scanning rejections stay visible). `session/*` branches, branches with upstream set, and detached HEAD are exempt.
- `test/auto_bump_description.bats` — 13 tests covering AC-1..AC-3 + contract guards (idempotence count-invariant, em-dash/parens boundary, hyphen-in-description negative-sample, missing-heading loud-failure, manual `bump-version.sh --ci` non-regression).
- `test/tdd_commit.bats` — 8 new tests covering AC-4..AC-7 + detached-HEAD gap coverage (happy push, slug-variant session exemption, upstream-set skip, commit-preserved fail-open, stderr-not-stdout discipline, post-failure hash stability).

### Changed
- `.github/workflows/auto-version-bump.yml:168,177` — `${{ steps.version.outputs.next }}` now quoted at every interpolation point for defense-in-depth.

---

## [Unreleased] - Bright-line allowlist: `.sherlock-plan.md` (TEMPORARY, Phase-2-completion removal)

### Added
- `config/bright-line-allowlist.txt` — new TEMPORARY exemption entry for `.sherlock-plan.md`. The active multi-phase Sherlock plan for the Benchmark Harness v1 contains two meta-references to the bright-line policy itself (AC-15 describes a CI assertion that grep-fails rendered HTML for prohibited tokens, naming those tokens). Per Sherlock methodology Step 8, `.sherlock-plan.md` is deleted on plan completion + ADR-011 extraction. Entry includes a removal condition comment so it's not orphaned.

### Fixed
- `bright-line-guard` CI check now passes on `main` (was failing since PR #135 introduced `.sherlock-plan.md` on 2026-04-19). No PR could merge with a clean policy-gate until now.

---

## [Unreleased] - `/verify-math` Follow-Up: Soundness Guards + PyPI Bundle + Wolfram Opt-In + SAFE AST Additions

### Added
- `.claude/skills/verify-math/verify.py`: post-parse unevaluated-form guard (REC 1) — `sympy.Sum`/`Integral`/`Limit`/`Order` detected via `isinstance` + `.has(*_UNEVAL_TYPES)` produce `MATH-VERIFY-FLAG: result contains unevaluated symbolic forms` with `ok=False`. Closes the silent-corruption mode where SymPy returns unevaluated symbolic objects (#21651, #15767, #17982, etc.) but verify.py reported success.
- `.claude/skills/verify-math/verify.py`: `e` and `E` bound in `local_dict` to `sympy.E` (REC 2). Before this fix, `e**(I*pi)` silently resolved `e` as a free symbol.
- `.claude/skills/verify-math/verify.py`: opt-in Wolfram Alpha integration via stdlib `urllib.request` — gated on `WOLFRAM_APP_ID` env var (REC 4). New CLI value `--source=wolfram`; `--source=all` extended to also include Wolfram when env var set. New helpers: `_wolfram_query`, `_wolfram_increment_call_counter`, `_wolfram_call_counter_path` (project-local at `.context/metrics/wolfram_calls.json`).
- `.claude/skills/verify-math/verify.py`: 6 SAFE AST name additions (REC 5a) — `gamma, erf, floor, ceil, Min, Max` added to `_ALLOWED_NAMES` and `local_dict`. Zero new AST node types; sentinel test asserts `_ALLOWED_AST_NODES` is unchanged.
- `src/shipteam/framework/skills/verify-math/{SKILL.md, verify.py, README.md}`: new — PyPI bundle (REC 3) byte-identical to `.claude/skills/` source. Closes the broken-reference gap where PR #133 shipped agent-body Math Verification sections but the skill itself wasn't in the wheel.
- `config/fw-manifest.yaml`: 3 entries under `config_gate: "skills.verify_math"` for fw-sync registration.
- `pyproject.toml`: `[project.optional-dependencies] verify = ["sympy>=1.14,<2", "numpy>=2.0,<3"]` extras pattern (install via `uv pip install 'shipteam[verify]'`). Default `uvx shipteam init` install footprint unchanged.
- Both `SKILL.md` files: install instructions updated to `shipteam[verify]`; new `Optional: Wolfram Alpha corroboration (opt-in)` section documenting `WOLFRAM_APP_ID` setup, the 2,000 non-commercial calls/month free-tier quota, and the vendor-reserves-right-to-adjust caveat.
- `tests/test_bundle_drift.py`: 18 tests covering AC-8 (byte-identical bundle via SHA-256, parametrized over the 3 shipped files, with a `_drift_oracle_actually_detects_drift` meta-test and a `_source_and_bundle_are_distinct_paths` config guard) + AC-9 (manifest registration via `yaml.safe_load` traversal — robust against text-search false-positives on description/comment matches).
- `tests/test_uvx_extras_verify.py`: 3 tests + module-scoped fixture exercising `uv venv` + `uv pip install '<repo>[verify]'` + sympy/numpy importability + verify.py end-to-end invocation. Skip-with-reason if `uv` not on PATH; structured failure citing `astral-sh/uv #4762/#14558` if extras path breaks.
- `tests/test_verify_math.py`: 5 new test classes — `TestUnevaluatedFormGuard` (AC-1, 6 tests with `unittest.mock.patch.object` on the loaded module's `parse_expr`), `TestEulerNumberBinding` (AC-3, 5 tests), `TestWolframGating` (AC-5, 4 tests), `TestWolframUnreachable` (AC-6, 4 tests with mocked `_wolfram_query`), `TestWolframCallCounter` (AC-7, 4 tests with `monkeypatch.chdir(tmp_path)`), `TestWolframSkillMdDocs` (AC-11, 8 tests parametrized over both SKILL.md locations), `TestSafeAstAdditionsAC4` (AC-4, 8 tests including AST-node sentinel and factorial-still-rejected control).
- `docs/adr/014-math-verification-followup.md`: extends ADR-013 with the four-RECs implementation rationale and the deferral list.

### Changed
- `tests/test_verify_math.py`, `tests/test_verify_math_skill_md.py`, `tests/test_verify_math_agents.py`: moved from `scripts/tests/` to `tests/` so pytest's `testpaths = ["tests"]` discovers them. Path-walk in each adjusted from `.parent.parent.parent` to `.parent.parent`. Confirms 32 baseline tests still green after move.
- `.claude/skills/verify-math/verify.py`: `_UNEVAL_TYPES` lifted from inline tuple in `verify()` to module-scope constant under `_DEPS_AVAILABLE` guard for clarity.
- `.claude/skills/verify-math/verify.py`: CLI argparse `--source` now uses `choices=["sympy", "numpy", "wolfram", "all"]` for explicit validation.

### Fixed
- `.claude/skills/verify-math/verify.py`: counter file no longer resets to 1 on read OSError — closes silent-data-loss path where unreadable counter file would lose all month-to-date history (caught in final-gate review).
- `tests/test_verify_math.py::TestSandboxEscape::test_uncaught_exception_from_parser_converts_to_caveat`: rewrote — previous version used `contextlib.suppress()` with no args (no-op context manager) so the test passed vacuously. Now asserts directly that `verify("log(0)")` returns a `VerifyResult` instead of propagating.
- `release_notes.md` + `CHANGELOG.md`: renamed prior `Unreleased` section (PR #133 content) to `[v0.14.14]` to fix the staleness from the auto-bump that didn't rename it.

---

## [Unreleased] - Retire Phase 0 Private-Repo Sentinel

### Removed
- `.github/PRIVATE_REPO_MARKER` — the Phase 0 content-signed marker file (introduced v0.13.9) that gated framework self-tests to the private repo only. Obsolete since 2026-04-13 when PyPI distribution (PR #105) superseded the two-repo-export plan.
- `.github/workflows/sentinel-sunset.yml` — the daily scheduled overdue-check for the marker's `SUNSET_DATE`. Its underlying parse bug was fixed in PR #134 so this retirement could verify-before-delete with a green run.
- `sentinel-check` job in `.github/workflows/ci-cd.yml` — ~40 lines including the TACTICAL comment block and job body.

### Changed
- `framework-tests` and `framework-tests-macos` now run unconditionally on every PR and push (still gated by `!inputs.fast_deploy` / `pull_request`). Dropped `needs: sentinel-check` + `is_private == 'true'` gates. Post-PyPI, there are no consumer forks to protect, so skipping framework self-tests would only create blind spots.
- `docs/20-DEPLOYMENT.md` — removed the "TEMPORARY: Framework-Tests Sentinel Gate (sunset 2026-07-01)" section (11 lines documenting the mechanism + Phase 5 checklist, now executed).

### Security
- `quality-gate` still depends on `framework-tests` and fails on `framework-tests.result == 'failure'`. Required-check semantics are preserved. `actionlint` clean on the modified workflow.

---

## [Unreleased] - Meaningful Session Branch Names (`-m/--memo` flag)

### Added
- `scripts/claude-session.sh` — new `-m SLUG` / `--memo SLUG` flag appends a short purpose slug to the auto-generated `session/claude-YYYYMMDD-HHMMSS` branch name (e.g. `-m sentinel-fix` produces `session/claude-20260419-024913-sentinel-fix`). Slug validation uses a strict allowlist (`^[a-z0-9]([a-z0-9-]{0,38}[a-z0-9])?$`) applied before any worktree or git operation, following the CWE-551 canonicalize-before-authorize discipline introduced in v0.14.13.
- `scripts/claude-session.sh` — new `--print-branch-name` testability flag that exits after branch-name computation without creating a worktree (used by the new bats test file).
- `test/session_memo_flag.bats` — 15 regression tests covering happy path, fallback behavior, validation rejections (uppercase, shell metachars, path separators, leading/trailing hyphens, length overflow), boundary cases (single char, 40-char slug), and mutual-exclusion with an explicit branch argument.

### Security
- The memo slug is interpolated into a git branch name and worktree directory path. Validation runs before any side-effecting operation and rejects the same classes of shell metacharacters caught by `.claude/hooks/auto_approve_base.py`'s compound-guard regex. Regex is closed on both ends — leading and trailing hyphens are rejected to prevent flag-injection and avoid git-refname ambiguity.

---

## [Unreleased] - Benchmark Harness v1 Phase 2 Part 1: Drivers (Claude Code + Aider + Droid)

### Added
- `drivers/` — three driver adapters conforming to a shared `Driver` Protocol (`drivers/_protocol.py`), returning a uniform `DriverResult` dataclass: `ClaudeCodeDriver` (SDK-native cost, `cost_source="native"`), `AiderDriver` (subprocess + stdout regex, `cost_source="scraped"`), `DroidDriver` (subprocess + `-o json` single-object parsing, `cost_source="scraped"`). Each driver records installed `cli_version` in `driver_metadata`.
- `drivers/_cost_extraction.py` — `extract_aider_cost` (regex against real-captured Aider stdout format, stable v0.52+) and `extract_droid_json_cost` (single-object JSON parser, Phase 2 Part 1 ASSUMPTION marker for the `usage` sub-object shape).
- `drivers/_subprocess_helpers.py::make_aborted_result()` — shared factory consolidating the `TimeoutExpired` → `wall_clock_exceeded` and `FileNotFoundError` → `driver_error` abort paths.
- `tests/drivers/` — 144 tests covering driver contract (T-7/T-8 P0 protocol), cost extraction (T-9/T-10/T-11/T-36), cache-disable (T-31/T-32/T-33), subprocess abort paths, and a regression-test suite that caught the returncode-based false-success bug at final review gate.
- `tests/drivers/conftest.py` — autouse fixture mocking `importlib.metadata.version`; docstring warns of the semantic-trap for future test authors asserting on `driver_metadata["cli_version"]`.
- `pyproject.toml` — `[project.optional-dependencies]`: `benchmark-aider = ["aider-chat>=0.86.0"]` and `benchmark-claude = ["claude-agent-sdk"]`. Install via `pip install shipteam[benchmark-aider]` to surface the `aider-chat`-vs-`aider` PyPI footgun at install time.
- `docs/70-INSIGHTS.md` — Insight #27 "Mid-Stream Telemetry vs Correctness — Benchmark Driver Output-Mode Trade-off".

### Changed
- `AiderDriver.__init__` raises `RuntimeError` eagerly when `aider-chat` is not installed, recommending `pip install shipteam[benchmark-aider]` and distinguishing `aider-chat` from the unrelated `aider` package.
- `AiderDriver.sdk_version()` / `version()` return the installed `aider-chat` version (was hardcoded `"0.1.0"` stub).
- `ClaudeCodeDriver.sdk_version()` reads `importlib.metadata.version("claude-agent-sdk")` (was hardcoded `"0.1.15"` stub).
- `DroidDriver` invokes `droid exec --auto low -o json -f <tempfile>` (was `--output-format stream-json` with NO task argument — which would have given the agent no instructions on every run).
- `.test-matrix.md` — T-9/T-11/T-36/T-39 oracles updated for post-corrective function names / contracts; retired speculative Aider v0.61/v0.64/v0.83 version pins (format stable since v0.52+).
- `.sherlock-plan.md` — Pivot Log 2026-04-18 entry documents five corrections driven by `/deep-r` Tier A/B source validation.

### Fixed
- Critical: `DroidDriver.execute()` OR-guards `is_error` with `proc.returncode != 0` and a `json.JSONDecodeError` flag. Without this, any Droid subprocess crash with non-JSON stdout would have produced a silently-successful-looking `DriverResult` — corrupting every affected benchmark row.
- Critical: `DroidDriver._get_cli_version` narrows exception catch to `(FileNotFoundError, TimeoutExpired, SubprocessError, OSError)`; adds `timeout=5`; uses `"unknown"` sentinel instead of empty string.
- Critical: tempfile FD leak fixed — `NamedTemporaryFile` now wrapped in `with` block for the write, outer `try/finally` for `unlink`.

## [v0.14.14] - `/verify-math` Skill + Agent Math-Verification Sections

### Added
- `.claude/skills/verify-math/` — new skill with `SKILL.md`, `verify.py` (SymPy + NumPy cross-verifier with AST pre-filter), and `README.md` (reference ladder: NIST DLMF, IEEE 754, SEMATECH e-Handbook, NIST SP 800-63B).
- `## Math Verification` section appended to `.claude/agents/fw-review-security.md`, `fw-advisor-architecture.md`, and `fw-review-performance.md` — each instructs the agent to invoke `/verify-math` for domain-specific numeric claims and emit `MATH-VERIFY-FLAG` for unchecked arithmetic.
- Event logging integration: successful skill invocations append `{event: "math_verify", category: "math-verify"}` records to `.context/metrics/events-YYYY-MM.jsonl` via `fw_event_log.append_event`.
- 21 new tests under `scripts/tests/test_verify_math*.py` covering: symbolic/numeric happy paths, independent cross-check (SymPy `.evalf()` vs `lambdify`-NumPy within tolerance), fail-closed on missing deps (subprocess with `sys.modules['sympy']=None` + runpy), event logging (differential byte-count oracle), SKILL.md frontmatter single-line regression guard (Claude Code issue #9817), agent-body presence checks, and security regression guards for the RCE / DoS / uncaught-exception vectors caught at final gate.
- Dependency additions to `requirements.in` (test-only, comment explicit): `sympy>=1.14,<2`, `numpy>=2.0,<3`. Lockfile `requirements.txt` regenerated with `pip-compile --generate-hashes`.

### Fixed
- Security: pre-merge fixes for three findings surfaced by the final-gate review — Critical RCE via `eval()` sandbox escape + `parse_expr` attribute-evaluation (reviewer reproduced exploit locally), High DoS via large-exponent inputs (`2**99999` locked the parser for minutes), High uncaught `ValueError` propagation at the API boundary. The core fix replaces the `eval()` path with `sympy.lambdify` on the parsed AST (user strings never reach eval) and adds a strict AST whitelist pre-filter. See release notes for the full remediation list.

## [v0.14.13] - Auto-Approve CWE-551 Fix (Canonicalize-First)

### Security

- `.claude/hooks/auto_approve_base.py`: closed CWE-551 (authorization-before-parsing-and-canonicalization) bypasses in the auto-approve hook. Prefix-matching branch-delete approve path (shipped in PR #125, v0.14.2) and `rm -rf` safe-path approve both now canonicalize shell metacharacters before authorizing. Seven bypass variants (`$()`, `${var}`, `$VAR`, `&&` chaining, `*` glob, `$'...'`, backslash line continuation) confirmed closed by new tests. Affects projects that synced from v0.14.2 through v0.14.12 — re-run `fw-sync.sh` after upgrading.

### Added

- `.claude/hooks/auto_approve_base.py`: `_HOOK_START_TIME` module global and `_duration_ms()` helper. `approve()` and `block()` event-log entries now include `duration_ms` (monotonic clock, rounded to 3 decimals).
- `test/safety_gate.bats`: 22 new tests covering F1/F2/F3 bypasses, `${var}`/`$VAR`/`$'...'` parameter expansion, `*` glob, backslash line continuation, and three regression guards for the legitimate session-branch / safe-rm-rf / protected-branch paths. Suite grows from 105 to 127 tests.

### Changed

- `.claude/hooks/auto_approve_base.py`: compound-guard regex extended with `\$`, `&`, `<`, `*`, and `\\\n`. The bare-`$` pattern supersedes the previous `\$\([^)]+\)`. UX side effect: curl GETs with multi-parameter query strings (`?a=1&b=2`) now fall through to user prompt instead of auto-approving; single-parameter queries still auto-approve.

### Fixed

- Authorization path in `auto_approve_base.py` no longer trusts a partial-prefix regex match on branch names or a `shlex`-parsed path for rm-rf targets when the original command string contains shell metacharacters. Parse-then-authorize invariant enforced at both approve paths plus a final fall-through gate.

## [v0.14.11] - Conformance Scorer v2 + Insights Drill-Down

### Added
- `docs/adr/011-conformance-scorer-v2-scope-boundary.md` (PROPOSED) — documents the Phase A scorer/dashboard fix and its scope boundary vs the queued Phase B benchmark harness.
- Inconclusive sentinel (`None`) across `_compute_hook_compliance`, `_compute_review_gate`, `_check_scope_creep`, and `_check_ac_coverage` — signal-absent no longer masquerades as compliant.
- Scorecard `schema_version: 2` with top-level `timestamp`, `composite_score`, `components`, `session_id`, `plan_hash`, `git_sha`, `base_ref`, `sherlock_tier`, `branch`, `project_root`.
- `discover_fw_projects_with_skipped()` returning `{found, skipped}` with per-project parse-error reasons.
- `<details>`/`<summary>` drill-down column in `renderFrameworkStats` (insights dashboard); `Session ID` column in the session table.
- Measurement-only disclaimer in both the per-project dashboard and the cross-project insights dashboard Conformance sections.
- Dashboard legacy-scorecard warning surfacing `legacy_count` + `legacy_files` (basenames only).
- 32 new tests across `scripts/tests/test_fw_conformance.py`, `scripts/tests/test_generate_dashboard.py`, `scripts/tests/test_insights.py`.

### Changed
- `_compute_composite(scores)` returns `(composite, coverage_ratio)` tuple (was `float`). Callers that unpacked a float must adopt tuple unpacking — legacy tests updated; existing CLI pathway in `score_session` handles the change.
- `_check_ac_coverage` accepts a new `plan_path` keyword; when supplied, rglob excludes the plan file and filters to recognized test-file name patterns.
- `aggregate_conformance` partitions scorecards into v2 (aggregated) vs legacy (excluded + surfaced). Return dict now includes `legacy_count` and `legacy_files`.
- `load_scorecards` attaches `_source_file` = filename (basename only) to each loaded scorecard so the partitioner can name legacy files without path leakage.

### Fixed
- `_parse_sherlock_tier` no longer early-exits with `"unknown"` on the first non-matching `Tier:` line (review finding on d967d23).
- Silent 1.0-on-empty-signal defaults in `_compute_review_gate`, `_compute_hook_compliance`, `_check_scope_creep`.
- Silent 1.0-at-repo-root self-match in `_check_ac_coverage` (plan headers were counted as coverage of themselves).
- Silent scorer↔dashboard schema mismatch (scorer emitted nested `scores.composite`; dashboard read top-level `composite_score`). Dashboard now requires `schema_version: 2` explicitly.

## [v0.14.7] - Safety Limits Doc + ADR-007 Bright-Line CI Enforcement

### Added
- `docs/85-SAFETY-LIMITS.md` — honest accounting of what hooks/rules enforce vs. don't; known Claude Code bypass vectors with upstream issue citations; layers enabled by default vs. user-owned opt-in hardening; documented escape hatches; verification-gate note for agent-driven evidence.
- `scripts/validate-no-bright-line.sh` — regex scanner enforcing ADR-007 bright-line patterns (pricing with period suffix, round-size signalling, valuation/revenue comparables, GTM keywords, private-path refs). Self-exempt list for policy-defining files, `config/bright-line-allowlist.txt` for whole-file exemptions, inline `bright-line:allow` suppress-comment support.
- `config/bright-line-allowlist.txt` — full-file exemption list (temporary entry for stale Sherlock plan artifact).
- `.pre-commit-config.yaml` — wires `validate-no-bright-line.sh` and `validate-no-public-secrets.sh` for local-first, sub-second feedback.
- `.github/workflows/bright-line-check.yml` — standalone workflow with the `bright-line-guard` job, fail-closed on finding. Kept out of `ci-cd.yml` because that workflow currently fails to parse on main (pre-existing `hashFiles()` in a job-level `if:`), and to isolate the policy gate from unrelated future pipeline changes.
- `docs/20-DEPLOYMENT.md` branch-protection enablement section using `gh api`, including the `bright-line-guard` required status context.

### Changed
- `docs/adr/007-public-repo-bright-line-sanitization.md` — status PROPOSED → ACCEPTED (2026-04-17); enforcement section updated to name the new automated gate and its suppress/allowlist mechanisms.
- `docs/adr/README.md` — ADR-007 row updated to ACCEPTED.
- `docs/00-README.md` — added `85-SAFETY-LIMITS.md` to the doc index and the "Debugging?" pointer.
- `docs/35-SECURITY.md` — added scope-note link to `85-SAFETY-LIMITS.md`.
- `CLAUDE.md` — added Quick Reference row for the Safety Limits doc.
- `CONTRIBUTING.md` — overlay-rule prose softened from "the base safety gate is the security boundary" to "the base safety gate is the foundational enforcement layer"; references `docs/85-SAFETY-LIMITS.md` for the full layer model. Accurate claim; same operational meaning.
- `CHANGELOG.md` — legacy GTM-removal record now carries a `bright-line:allow` suppress comment (still documents the removal, does not introduce new commercial content).

## [v0.14.3] - Branch Deletion Hook: Three-Tier Policy Alignment

### Changed
- `.claude/hooks/auto_approve_base.py` — branch deletion logic rewritten from unconditional hard-block to three-tier policy: protected branches (main, develop, release/*, hotfix/*) hard-blocked; session/claude-* and dependabot/* auto-approved with safe delete; everything else falls through to user prompt
- `test/safety_gate.bats` — 6 old hard-block tests replaced with 18 tests covering all three tiers plus edge cases (origin/ prefix, argument reordering, false positive prevention). 105 total tests pass.

### Security
- Protected-branch regex uses `$` anchor to prevent false positives (e.g. branch named `maintenence` no longer blocked as `main`)
- `git push --delete` checks all non-flag tokens regardless of argument order (prevents bypass via `git push --delete origin main`)
- Quote-stripping on extracted branch names prevents quoted-name bypass
- `is_force` check scoped to flag tokens only (prevents branch names containing uppercase D from triggering force-delete detection)

## [v0.14.1] - Reasoning Lenses + /deep-r Adversarial Upgrades + /deep-r-audit Sibling

### Added
- `.claude/lenses/` — new directory for advisory reasoning patterns (distinct from `.claude/rules/` which are mandatory). Initial set: `hot-path-latency`, `failure-domain-isolation`, `fit-for-purpose`, `explicit-tradeoff`. Each lens has a fixed structure (When to apply / Core question / Worked example / Anti-patterns / Past failure), an admission bar (concrete past failure required), and a retirement policy. Cap ~8.
- `.claude/skills/deep-r/SKILL.md` — framework-level `/deep-r` skill with three new MANDATORY sections: **Adversarial Search Pass** (upstream issue search before finalizing recommendations), **Pre-Mortem for Safety Infrastructure** (≥3 runtime failure modes when touching hooks/auth/middleware), **Lens Consultation** (which lenses applied).
- `.claude/skills/deep-r-audit/SKILL.md` — new sibling skill that reverse-audits the current project config against known upstream issues, filtered by installed version and patterns actually in use. Cadence: manual before releases, monthly on mature projects, post-Claude-Code-upgrade.
- `docs/adr/010-reasoning-lenses-and-deep-r-adversarial-upgrades.md` — architectural capture for the above (PROPOSED).
- `test/test_framework_content.sh` — regression test asserting lens files have required sections, skill mandatory sections present, fw-manifest registers new content.

### Changed
- `config/fw-manifest.yaml` — new `lenses:` section registering the four lens files; `skills:` section gains `deep-r` and `deep-r-audit` entries (`policy: replace`).
- `docs/adr/README.md` — index entry for ADR-010.
- `CLAUDE.md` — Quick Reference table gains entries for `/deep-r`, `/deep-r-audit`, and `.claude/lenses/`; version description updated.

## [v0.13.11] - Session vs Workspace: Explicit-Branch Worktrees Preserve by Default

### Added
- `scripts/claude-session.sh` `--clean` flag to force worktree destruction on exit
- `EXPLICIT_BRANCH` tracking so CLI-provided branch names get preserve-by-default lifecycle

### Fixed
- Stale-CWD bug when relaunching `claude-session.sh <branch>` with an explicit branch — shells already `cd`'d into the worktree held an unlinked inode across the destroy+recreate cycle, causing "Working directory no longer exists" on next Claude launch. Explicit-branch worktrees now preserve by default, matching git-town/jj/worktreewise convention.

### Changed
- Help text in `claude-session.sh` documents the two lifecycle modes (auto-generated → destroy, explicit → preserve) and the `--clean` / `--keep` overrides
- `cleanup()` trap now refuses to destroy a worktree with uncommitted changes, or (on non-`session/*` branches) unpushed commits / no upstream. Preserves loudly with a one-line recovery command instead of prompting — EXIT-trap prompts are unreliable under SIGTERM, crashes, or non-interactive parents. Defense-in-depth against stale in-memory trap bodies from pre-update shells.

## [v0.13.9] - Two-Repo Export Phase 0: Tactical Unblock for Consumer-Fork framework-tests

### Added
- `scripts/_framework.sh` honors pre-set `FW_PROJECT_ROOT` and `FW_CONFIG` env vars with realpath + containment validation (fail-closed on path traversal)
- `test/framework_config.bats` AC-1 fixture-based tests and AC-2 path-traversal fail-closed tests
- `.github/PRIVATE_REPO_MARKER` sentinel file with content signature and sunset date
- `.github/workflows/ci-cd.yml` new `sentinel-check` job gating `framework-tests` + `framework-tests-macos` (fail-closed on content mismatch)
- `.github/workflows/sentinel-sunset.yml` scheduled workflow enforcing 2026-07-01 Phase 5 cleanup deadline
- `test/test_helper.bash` unsets `FW_PROJECT_ROOT` / `FW_CONFIG` per-test to prevent parent-shell env leakage

### Fixed
- `test/framework_config.bats` tests 4–7 no longer hardcode dev-framework's own stack values — internal users forking the template with a different stack will no longer hit spurious CI failures

### Security
- Realpath + containment check rejects `FW_CONFIG` resolving outside repo root (symlink escape defense)
- Sentinel CI gate fail-closed on content mismatch (prevents silent test-disable via marker corruption)

### Notes
- All sentinel-related artifacts (`PRIVATE_REPO_MARKER`, `sentinel-check` job, `sentinel-sunset.yml`) are tactical and will be removed in Phase 5 of the two-repo-export plan
- See `.sherlock-plan-two-repo-export.md` for full plan

## [v0.13.4] - Installer Phase 1: Detection + Config + Security + State (CHECKPOINT)

**Status**: Phase 1 of 6 for the `uvx shipteam init` installer. NOT end-user-usable yet — no CLI entry point, templates, or scaffolding exists. This is an additive foundation merge for the new `shipteam` Python package.

### Added
- New Python package `src/shipteam/` (foundation layer): `detect.py` (stack + git auto-detection), `config.py` (framework.yaml load/validate), `security.py` (path traversal + YAML safety), `state.py` (`.shipteam-init.yaml` state file with `__post_init__` validation for ISO 8601 timestamps and SHA-256 hashes)
- `pyproject.toml` with hatchling build backend, `pyyaml>=6.0,<7` dependency, `pytest>=8.0` in `[project.optional-dependencies.dev]`
- 32 passing tests covering AC-3 (stack detection — Python/React/monorepo/polyglot/empty), AC-6 (git introspection — directory/worktree-file/symlink/malformed), AC-10 (state round-trip, corrupt, empty, forward-compat), AC-12 (path traversal, YAML safety)
- Architecture follows V1 Minimal per `.sherlock-plan.md`: installer separate from `fw-sync.sh`, bundled framework source via `package_data` (not remote tarball)

### Security
- `validate_path_safety` uses `Path.is_relative_to` (not `commonpath` string compare) — fixes macOS `/tmp` vs `/private/tmp` symlink resolution edge case that would have been incorrect in worktree environments
- `safe_load_yaml` enforces 256KB size cap + utf-8 encoding + wraps `yaml.YAMLError` with file-path context
- `detect_git` `.git` file parsing hardened: 4KB size cap, `gitdir:` prefix validation, first-line-only (prevents multi-line injection), absolute-path validation, fails closed on malformed input
- Null-byte rejection in path safety checks; None/bytes input handled gracefully (previously raised `TypeError`)

### Review Pipeline
Per the 8-agent per-phase review pipeline: 9 HIGH findings were consolidated (applying severity + domain-authority resolution from `sherlock-review-gate.md`) and fixed before merge. Zero Critical, zero unaddressed High findings.

### Tooling
- `scripts/tdd-commit.sh` uses system `pytest` instead of `.venv/bin/pytest` — works around required for this commit. Fix tracked for separate Hudson task.

### Documentation
- Fixed stale version references: README.md badge bumped `0.13.1 → 0.13.4` to match `VERSION`; `docs/index.md` Features row updated `v0.1-v0.6 → v0.1-v0.13`
- Removed stale `Last Deploy: 2026-03-30 v0.9.0` marker from `CLAUDE.md` header
- Trimmed `CLAUDE.md` Quick Reference (~35 lines): replaced 12 doc-pointer rows duplicating `docs/00-README.md` with a single redirect line; retained Rules/Skills/Agents/Scripts/Hooks/Config shortcuts
- Archived `release_notes.md` v0.1.0–v0.12.0 sections into `docs/archives/ARCHIVE_RELEASES_v0.1-v0.12.md`; active file trimmed 684 → 83 lines. Also resolved an orphaned duplicate `## Unreleased` header from the v0.10 era

### Installer — All Phases Complete (Unreleased)
- Phase 2: Template rendering + managed regions (CLAUDE.md.jinja, regions.py) ✅
- Phase 3: Framework source resolution + .claude/ scaffolding ✅
- Phase 4: Click-based CLI entry point ✅
- Phase 5: `create-shipteam` npm shim + bundled framework package_data ✅
- Phase 6: Delete `scripts/init-project.sh` (534-line bash wizard); migrate all documentation to reference `uvx shipteam init` ✅

### Enhanced Lead Orchestrator — Artifacts-Over-Reasoning (Unreleased, separate feature)
**Added**
- New agent `fw-author-test-strategy` (Sonnet, 12 turns) — authors `.test-matrix.md` from `.sherlock-plan.md` ACs (P0/P1/P2 tiers, oracle hints, coverage targets, phase mapping). Invoked once per plan at Sherlock Lite Step 1 or Full Sherlock Step 4.5 post-validation. Skips doc-only changes; exempt from Hudson.
- `.claude/spec-format.md` gains two sections: `## Lead Judgment` (Priority Stack + Risk Watch — externalized priority/risk that survives compaction) and `## Decision Digest` (append-only per-phase review outcomes; always written, even on zero findings).
- Step 0 "User-Preference Lens" in `.claude/rules/sherlock-methodology.md` — title-only citations from auto-loaded MEMORY.md to enable memory-aware routing. Hard bounds: ≤3 titles, ≤200 chars, single line. Live-conversation only.
- ADR 009 captures the "artifacts-over-reasoning" architectural rationale from /deep-r (Anthropic multi-agent research, Cognition coding-specific warning, selection-over-synthesis literature, Larson/Fournier lead patterns).

**Changed**
- `fw-review-tests` now consumes `.test-matrix.md` at every per-phase review gate: missing P0 → Critical, missing P1 → High, missing P2 → Medium, malformed matrix → Medium fallback.
- Sherlock Lite Step 1 and Full Sherlock Step 4.5 invoke `fw-author-test-strategy` after plan finalization. Full Sherlock Step 8 deletes `.test-matrix.md` alongside `.sherlock-plan.md` post-ADR-extraction.
- Per-phase review sections append a `### Phase N Review — YYYY-MM-DD` block to `## Decision Digest` in the plan.

**Security (ADR-007 bright-line sanitization — no-persist rule)**
- The Step 0 `User context:` line must NOT be written into `.sherlock-plan.md`, `.test-matrix.md`, Pivot Log, Decision Digest, Lead Judgment, `.claude/state/*`, or any file in any Write/Edit tool call. MEMORY.md body content is forbidden everywhere; titles are permitted only in live conversation output (never in persisted artifacts).
- Rule restated in four locations: methodology.md Step 0, spec-format.md Lead Judgment guidelines, spec-format.md Decision Digest guidelines, and fw-author-test-strategy agent Scope Constraints.

**Why / research evidence**
Evidence-backed via /deep-r at Step 3 (three parallel research agents; Anthropic multi-agent system, Cognition "Don't Build Multi-Agents," "When Agents Disagree" arXiv 2603.20324, Self-Refine limits, Larson/Fournier) and Step 4.5 plan validation. Rejected approaches (devil's-advocate agent, formal MAD debate layer, thick execution-phase lead): evidence-negative. Approved approach: thin-at-execution + thick-at-planning-boundary + artifact persistence.

## [0.13.3] - 2026-04-12 - /deep-r Integration into Sherlock Methodology

### Added
- **Step 4.5 (Plan Validation)** to Full Sherlock methodology — `/deep-r` red-teams `.sherlock-plan.md` after architecture approval, before any code is written. Mandatory for Full Sherlock; optional for Sherlock Lite. Caught 3 critical gaps in first applied instance (installer plan).
- `/deep-r` integration at Steps 0, 3, 4, 8 of Sherlock methodology with trigger criteria (`docs/10-ARCHITECTURE.md` → Research Integration section)
- "Research-Enhanced Agents" section in `.claude/rules/sherlock-review-gate.md` — lists the 5 agents with embedded `WebSearch` + `WebFetch`: fw-advisor-architecture (already had tools), fw-review-security, fw-review-dependencies, fw-advisor-release, fw-author-spec
- "Research Validation Step" methodology sections in the 4 newly research-capable agents — `.claude/agents/fw-review-security.md`, `fw-review-dependencies.md`, `fw-advisor-release.md`, `fw-author-spec.md`; plus expanded methodology in `fw-advisor-architecture.md`
- "RESEARCH_NEEDED Flag Protocol" in `.claude/rules/sherlock-review-gate.md` — ALL agents escalate uncertainty via `RESEARCH_NEEDED:` and `UNVERIFIED_CLAIM:` flags in their output; lead dispatches `/deep-r` when flags affect Critical/High findings
- "Research Flag Protocol" appended to 17 agent files + `_AGENT_TEMPLATE.md` (the 5 research-capable agents have their own methodology sections)
- `config/framework.yaml` — `cost.research_capable` list, `cost.research_enabled` toggle, new `research:` section with auto-invoke flags and cost estimate
- `scripts/cost_routing.py` — `RESEARCH_CAPABLE_AGENTS` frozenset, `RESEARCH_SURCHARGE_USD`, `DEEP_R_COST_PER_INVOCATION_USD` constants
- `CLAUDE.md` Quick Reference — /deep-r and agent flag protocol entries
- `docs/70-INSIGHTS.md` entry documenting the decision-vs-execution phase boundary for research tooling

## [0.13.1] - 2026-04-12 - Worktree Bootstrap Layered Defense + Session Script Hardening

### Added
- `bootstrap_claude_dir()` and `cp_cow()` in `claude-session.sh` — copies hooks/, rules/, agents/, skills/, settings.json into worktrees (physical copies, not symlinks); symlinks only settings.local.json; creates per-worktree state/ directory
- `verify_claude_hooks()` in `session-lifecycle.py` — SessionStart hook verifies .claude/hooks/ exists and is non-empty; self-heals from main repo via `_find_main_repo_claude_dir()` + `_bootstrap_from_source()`; exits 2 (hard block) if still missing after self-heal so all hooks are active on restart
- Runtime guard in `claude-session.sh` for `worktree.enabled: false` — exits early with clear error instead of creating a worktree in a project that disabled the feature
- `trap cleanup EXIT` moved before worktree creation — failed `git worktree add` now triggers cleanup instead of leaving partial state
- Dangling `settings.local.json` symlink replacement on resume (previously silently persisted)
- 16 BATS regression tests in `test/worktree_bootstrap.bats` covering fresh bootstrap, resume gap-fill, no-clobber, symlink vs copy, edge cases

### Fixed
- Worktrees created by `claude-session.sh` now have fully populated .claude/ directories — previously empty when .claude/ is gitignored (regression from commit 54765d1 which migrated from whole-dir symlink to targeted symlinks)
- Merge conflict state now writes to worktree's .claude/state/ instead of main repo's (line 405)

### Removed
- WorktreeCreate hook from settings.json — upstream WorktreeCreate is a replacement hook (replaces `git worktree add` entirely) with multiple open bugs (anthropics/claude-code#41614 indefinite hang, #36205 Agent tool bypass); SessionStart verification (Layer 3) is the correct catch-all

### Security
- Sessions in worktrees with missing .claude/hooks/ are now hard-blocked (exit 2) instead of proceeding ungated — closes the silent safety regression where all 13 hook commands failed with exit 1 (non-blocking)

## [0.13.0] - 2026-04-11 - Remove Feature Tier Gating (BREAKING)

### Removed
- `feature_tier:` section from `config/framework.yaml` — no replacement; all 22 agents and the full multi-agent review pipeline are available unconditionally
- "Feature Tier Gate" section from `.claude/rules/sherlock-review-gate.md`
- Per-tier conditional branches from `.claude/rules/sherlock-methodology.md` (Sherlock Lite Steps 4-5 and Full Sherlock Steps 6-7)
- Five historical entries from `docs/70-INSIGHTS.md` that documented the earlier gating rationale
- "Feature Tiers vs Complexity Profiles" section from `docs/ADOPTION.md`
- Tier setup prompts and the "What Just Happened?" tier row in `QUICKSTART.md`
- `Tiers` row from the Workflow Coverage table in `docs/60-FEATURES.md`

### Added
- `docs/adr/006-remove-feature-tier-gating.md` — decision record for removing the gating machinery
- `docs/adr/007-public-repo-bright-line-sanitization.md` — decision record for the bright-line policy that governs what content may be committed to the tree ahead of the eventual public-repo export

### Changed
- **BREAKING**: removing `feature_tier:` from `config/framework.yaml` is a config-schema change. Projects carrying a local `feature_tier:` section should delete it — no Python or shell code reads it, so behavior is unchanged at runtime, but strict YAML schema validators may flag unknown keys.
- `docs/60-FEATURES.md` — legacy Feature Tiers subsection replaced with a new "Remove Feature Tier Gating — All Agents Available" entry pointing at ADR-006
- `README.md` — version badge catches up from 0.11.0 to 0.13.0 (the 0.12.0 bump missed the badge update)
- Version bumped from 0.12.0 to 0.13.0

## [0.12.0] - 2026-04-10 - Cross-Project Framework Stats in Insights Dashboard

### Added
- `scripts/generate_insights.py` — Phase 1.5 framework-stats discovery, caching, and cross-project aggregation
- `discover_fw_projects()` — walks `$HOME` (depth ≤ 3) for directories containing `config/framework.yaml`, with an explicit `followlinks=False` and a configurable skip-dir set (`node_modules`, `.git`, `.venv`, `Library`, `.pnpm-store`, `.yarn`, `bower_components`, etc.)
- `load_fw_projects_cache()` / `save_fw_projects_cache()` — JSON cache at `~/.claude/fw-project-paths.json` with stale-path pruning and tz-aware ISO-8601 timestamps
- `load_fw_project_metrics()` — reads events + conformance scorecards from a single project's `.context/metrics/`, reuses aggregators from `generate_dashboard.py`. Keeps projects that have scorecards but no events.
- `aggregate_fw_stats()` — groups per-project metrics by canonical name (worktree rollup via `canonicalize_project()`), re-aggregates the unioned events for accurate per-project and cross-project totals
- `--refresh-fw-projects` CLI flag — force a fresh filesystem scan and rewrite the cache
- `--no-fw-stats` CLI flag — skip framework metrics aggregation entirely
- "Framework Stats" section in the insights dashboard HTML (KPI cards + per-project comparison table)
- 17 new tests in `scripts/tests/test_insights.py` (TestFwDiscovery, TestFwAggregation, TestFwPayload, TestFwHtml, plus a symlink-loop safety test); 102 tests pass in the insights + dashboard suites

### Changed
- `build_payload()` — new optional `framework_stats` parameter; payload now includes `framework_stats` key (None when no projects discovered or `--no-fw-stats` is set)
- Dashboard aggregator imports hoisted to module top via dual-path try/except (matches the pattern `generate_dashboard.py` uses for `fw_event_log`)
- Version bumped from 0.11.0 to 0.12.0

## [0.11.0] - 2026-04-10 - Feature Tiers, Capability Tiers, Agent Teams, Supply Chain Hardening, Config-Driven Layout

This is an aggregate release that consolidates work merged to `main` between 0.10.2 and 0.11.0, including previously un-versioned entries for Agent Teams, Supply Chain Hardening, and Config-Driven Project Layout. Auto-version-bump was disabled on merge as part of this release to make version bumps intentional.

### Added — Provider-Agnostic Capability Tiers
- `feature_tier` section in `config/framework.yaml` (added in v0.11.0, removed in v0.13.0 — see ADR-006)
- `providers` section in `config/framework.yaml` — maps capability tiers to provider-specific model names (anthropic, openai, google) for future multi-provider support
- `QUICKSTART.md` — onboarding guide placeholder

### Added — Agent Teams Dual-Mode Orchestration
- `orchestration.mode` config in `framework.yaml` — toggle between `subagent` (default) and `agent-teams` orchestration modes
- `format_as_tasks()` function in `cost_routing.py` — converts agent lists to Agent Teams task definitions with `blockedBy` dependency chains
- `--mode agent-teams` and `--predecessor-task` CLI flags for `cost_routing.py`
- `task-quality-gate.py` hook — blocks reviewer task completion on Critical findings (exit 2)
- `TaskCreated`, `TaskCompleted`, `TeammateIdle` event handling in `metrics-tracker.py`
- Agent Teams Mode sections in `sherlock-methodology.md` and `sherlock-review-gate.md`
- Agent Teams fallback instructions in 11 agents with `skills: project-context`
- Agent Teams cognitive isolation sections in 3 TDD agents
- 30 new tests for dual-mode orchestration

### Added — Supply Chain & Safety Hardening
- Network recon/exfiltration tool blocking in `auto_approve_base.py` — hard-blocks `nc`, `ncat`, `nmap`, `socat`, `tcpdump` (including path-prefix and env-wrapper bypass vectors)
- Edit/Write tool guard for safety infrastructure paths (`.claude/hooks/`, `.claude/rules/`, `.claude/settings.json`) — falls through to user prompt
- `requirements.txt` with `--hash=sha256:` directives for supply chain integrity
- SBOM generation job in CI using `anchore/sbom-action` (SPDX JSON format)
- `scripts/tests/test_workflow_hardening.py` — 15 tests validating CI/CD YAML structure
- 21 new bats tests for safety infrastructure protection and network tool blocking

### Added — Config-Driven Project Layout + Insights Dashboard
- `scripts/generate_insights.py` — Claude Code qualitative insights dashboard with interactive filters, AI-powered narratives, and historical trends from stats-cache
- `scripts/tests/test_insights.py` — 28 unit tests covering JSON recovery, project canonicalization, KPI computation, insight generation, and HTML output
- `/claude-insights` skill — regenerate and open the insights dashboard
- `stack.frontend.root` config key — frontend directory relative to project root (replaces hardcoded `frontend/`)
- `stack.backend.root` config key — backend directory relative to project root (replaces hardcoded `backend/`)
- `stack.frontend.port_flag` config key — CLI flag for dev server port (e.g., `--port` for Vite, `-p` for Next.js)
- `worktree.enabled` config gate — controls whether `claude-session.sh` is synced to projects
- `init-project.sh` steps 15-17: auto-detect project layout, generate `.worktreeinclude`, interactive shell alias install
- `generate-shell-alias.sh --install` flag — auto-appends alias to `~/.zshrc` with idempotency check
- `.worktreeinclude` generation — Claude Code compatibility for `--worktree` env file copying

### Changed
- **BREAKING**: `cost.model_tiers` keys renamed from `opus/sonnet/haiku` to `high/standard/fast` — provider-agnostic capability tiers
- `cost_routing.py` — `COST_PER_AGENT_CALL` lookup keys updated to capability tiers (`fast`/`standard`/`high`)
- `cost_routing.py` — `code_reviewer_tier` return values use capability tiers
- `sherlock-review-gate.md` — routing table references "fast tier" and "high tier" instead of "Haiku" and "Opus"
- `test_insights.py` — replaced hardcoded personal project paths with generic `testuser`/`sample-project` examples
- `CLAUDE.md` — private directory path reference softened, version description updated
- `fw_conformance.py` — `_compute_review_gate()` counts both `agent_spawn` and `task_completed` events
- `settings.json` and `settings.local.json.template` — registered 3 new hook lifecycle events
- Shell writes to safety infrastructure escalated from user-prompt to hard-block (exit 2) — covers `>`, `tee`, `cp`, `mv`, `ln` operators
- `lint-shell` job added to quality-gate `needs` — ShellCheck failures now block merges
- ShellCheck `|| true` suppression removed — failures propagate
- `pip install pytest pyyaml` replaced with `pip install --require-hashes -r requirements.txt` in CI
- `bats-core/bats-action` pinned by SHA (was tag-only reference)
- `pages.yml` checkout SHA standardized to v4.2.2 matching all other workflows
- `claude-session.sh` — all hardcoded `frontend/` and `backend/` paths replaced with config-driven variables; backend health check conditional on config; `PORT` env var set as universal fallback for dev server port
- `fw-sync.sh` — template status display shows `[custom]` instead of false "Framework has updates" when cached base matches framework
- `init-project.sh` total steps: 14 → 17
- Auto-version-bump workflow disabled for push triggers — now `workflow_dispatch` only. Rationale: version bumps should be intentional release decisions, not automatic side effects of every merge.
- Version bumped from 0.10.14 to 0.11.0

### Removed
- `docs/launch-copy.md` — marketing content relocated to private docs <!-- bright-line:allow reason="CHANGELOG entry documenting a removal; no new commercial content" -->
- Launch-copy and demo-scripts references from `docs/00-README.md` index

### Security
- Added `permissions: contents: read` to `ci-cd.yml` and `security-scan.yml` (OWASP CICD-SEC-2/5)
- All GitHub Actions now SHA-pinned across all 6 workflow files (OWASP CICD-SEC-8)

## [0.10.2] - 2026-04-02 - Framework Adoption & Enforcement Improvements

### Added
- Platform Compatibility documentation in README.md and docs/ADOPTION.md — clarifies Claude Code works on all 5 surfaces (CLI, Desktop, VS Code, JetBrains, Web)
- `methodology-enforcer.py` PostToolUse hook — warns when 3+ file commits lack a Sherlock plan (never blocks, rate-limited)
- `/fw-stats` Step 8 profile graduation nudge — suggests upgrading minimal→standard→full based on current profile
- Mandatory Sherlock Step 0 instruction in CLAUDE.md (conditional on profile)
- Doc staleness gate documentation in CLAUDE.md deployment protocol section
- `hooks.doc_staleness_check` and `hooks.methodology_enforcer` config keys in framework.yaml
- 14 new BATS tests (9 methodology enforcer, 5 settings template)

### Fixed
- `settings.local.json.template` now includes full hooks section — previously had permissions only, meaning new projects got zero hook enforcement
- `init-project.sh` now auto-replaces org/repo, test_command, and health_url CUSTOMIZE markers in CLAUDE.md
- `init-project.sh` removes Sherlock section from CLAUDE.md on minimal profile (prevents broken references to deleted rule files)

### Changed
- Session Isolation section in README.md uncollapsed (was hidden in `<details>`) with link to SETUP.md full guide
- ADOPTION.md Evaluation Checklist updated to list all Claude Code surfaces
- ADOPTION.md FAQ expanded with 3 new platform compatibility entries

### Fixed
- `session-lifecycle.py` now creates `session-lock.json` at session start, closing a gap where concurrent-session protection (checkout-guard, worktree-enforcer) didn't activate until the first `git checkout`
- `SETUP.md` incorrectly documented `.claude/state/` as symlinked to main repo; it is actually created as a per-worktree directory (symlinking causes `git stash` errors because `.gitkeep` is tracked inside it)

### Added
- "Worktree Architecture: End-to-End Flow" section in `SETUP.md` — shared vs. isolated resource table, full lifecycle diagram, hook integration timeline, stale lock recovery, and adoption FAQ
- 6 new tests for session lock creation (stale reclaim, live preservation, corrupt overwrite, own-PID restart, missing state dir)

## [0.10.0] - 2026-03-31 - Defense-in-Depth Hardening

### Added
- `.claude/hooks/post-compact-restore.py` — PostCompact hook for Sherlock context restoration
- `.claude/hooks/session-lifecycle.py` — SessionStart hook for lifecycle event logging
- Event log levels in `fw_event_log.py` — `level` param (debug/info/warn/error) with backward-compatible filtering
- Error logging to `errors.jsonl` — captures failed event writes silently
- CI Unicode integrity check — detects invisible characters in `.claude/rules/` files
- Automated dashboard generation in CI — uploads as GitHub Actions artifact on merge to main
- Rule file integrity threat documentation in `docs/35-SECURITY.md`
- 29 new tests (13 event log, 16 PostCompact hook)

### Changed
- `.github/CODEOWNERS` — All `.claude/rules/` files now require maintainer review
- `auto_approve_base.py` — approve() logs at debug level, block() at warn level
- `fw_conformance.py` — hook_compliance and review_gate computed from real event data
- `.claude/settings.json` — Registers SessionStart and PostCompact hooks
- `config/framework.yaml` — Expanded metrics config (log_level, session_tracking, error_logging)

## [0.10.0-pre] - 2026-03-30 - Framework Metrics & Conformance System

### Added
- `scripts/fw_event_log.py` — JSONL event logger with fcntl locking, date-partitioned files, 50MB rotation
- `scripts/fw_conformance.py` — Plan adherence scorer (file coverage, AC coverage, scope creep, composite)
- `/fw-stats` skill — Aggregates metrics over time window (safety, cost, conformance, TDD health)
- `metrics:` config section in `framework.yaml` (enabled by default, local-only)
- Cost estimate lookup table in `cost_routing.py` with `est_cost_saved` output field
- `scripts/generate_dashboard.py` — Self-contained HTML dashboard with inline SVG charts (safety, cost routing, conformance trends, sessions, protocol)
- `.claude/hooks/metrics-tracker.py` — SubagentStart hook logs agent spawns as cost events (async, fire-and-forget)
- Conformance gate in `/ship` skill — auto-runs `fw_conformance.py` when `.sherlock-plan.md` exists
- 70 new tests for event logger and conformance scorer
- 39 new tests for dashboard generator
- 8 new tests for metrics tracker hook

### Changed
- `tdd-commit.sh` — Emits `tdd_phase` events to JSONL after successful commits
- `/fw-stats` skill — Reads agent_spawn and tdd_phase events from JSONL (falls back to git grep)
- `auto_approve_base.py` — Fire-and-forget event logging on approve/block
- `protocol-validator.py` — Event logging with trigger context on warn/block
- `sherlock-methodology.md` — DESIGN-SYNC runs conformance scorer
- `.gitignore` — Added `.context/metrics/`

## [0.9.0] - 2026-03-30 - Progressive Adoption: Complexity Profiles

### Added
- Complexity profiles in `framework.yaml`: `minimal`, `standard`, `full` — controls how much of the framework is active
- Profile-aware `init-project.sh` — applies profile defaults automatically during setup
- Adoption Guide rewritten with 4 new sections: "What You Can Safely Ignore", "Complexity Profiles", "First Week Guide", "Component Dependency Map"
- "First Week Guide" with day-by-day progressive learning path (Day 1: Hudson, Day 2-3: Sherlock Lite, Day 4-5: review pipeline, Week 2+: Full Sherlock)
- New FAQ entries on profile selection, learning time, and cost justification

### Fixed
- `init-project.sh` now handles `sherlock-methodology.md` (previously only `sherlock-review-gate.md` was toggled by `sherlock_review_gate` config)
- `init-project.sh` now handles `tdd-commit` and `ship` skills (previously missing from wizard despite being in `framework.yaml`)

### Changed
- README Quick Start updated to show profile selection with recommendation for new adopters
- README "Setup Wizard" section renamed to "Progressive Adoption" with profile descriptions
- GitHub repo description updated to mention progressive adoption
- GitHub topics: replaced `devops` with `progressive-adoption`

## [0.8.0] - 2026-03-29 - Professional Agent Naming + DRY Spec Format

### Added
- `.claude/spec-format.md` — single source of truth for `.sherlock-plan.md` template (extracted from methodology)
- 20 deprecated entries in `fw-manifest.yaml` for automatic old-file cleanup during sync

### Changed
- 20 agents renamed to consistent `fw-{verb}-{domain}` convention (see release notes for full map)
- All cross-references updated: rules, config, docs, scripts, demo files
- `sherlock-methodology.md` now references `spec-format.md` instead of inline template
- `config/framework.yaml` model tier mappings use new agent names

## [0.7.0] - 2026-03-29 - SDD Spec-Anchored Development + Agent Expansion + Doc Gates

### Added
- Spec-anchored development: Acceptance Criteria (Given/When/Then) and Interface Contracts in `.sherlock-plan.md`
- ADR extraction from Sherlock plans post-commit (Phase 8)
- Sherlock methodology as syncable rules file (`.claude/rules/sherlock-methodology.md`)
- `fw-review-dependencies` agent (supply chain security — CVEs, licenses, typosquatting)
- `fw-review-concurrency` agent (race conditions, deadlocks, shared state)
- `fw-author-spec` agent (generate structured specs for SDD workflow)
- *(removed in v0.10.1: `review-accessibility`, `advisor-compliance` — personal agents)*
- Doc staleness gate in `protocol-validator.py` (blocks PR creation when docs are stale)
- Explicit doc update checklist in Sherlock Lite Step 6 and Full Step 8

### Changed
- `fw-tdd-red` prefers structured Acceptance Criteria from `.sherlock-plan.md`
- `sherlock-review-gate.md` updated with new agents, skip rules, domain authority
- `fw-review-forensics` clarified boundary with `fw-review-dependencies` for supply chain scope
- `~/.claude/CLAUDE.md` slimmed to personal preferences (methodology moved to repo)
- Domain authority priority table re-sorted for correct numeric ordering

## [0.6.0] - 2026-03-27 - Agent Distribution + Dual Sync Profiles

### Added
- 15 pipeline agents migrated from global `~/.claude/agents/` into framework repo
- Dual sync profiles: `--personal` flag for personal-only advisory agents
- `config/fw-manifest-personal.yaml` additive manifest
- GitHub repo UX overhaul: YAML issue forms, CODEOWNERS, ADRs, copilot instructions
- Architecture Decision Records (ADRs) system in `docs/adr/`

### Changed
- `fw-sync.sh`: `--personal` flag, profile banner, `manifest_files()` helper
- Agent naming: `fw-review-*` convention for framework review agents

## [0.5.0] - 2026-03-15 - Agent Quality Bar + DevContainer + Cost Routing

### Added
- Multi-agent review pipeline with cost routing (`scripts/cost_routing.py`)
- Review agent selection by diff type and LOC thresholds
- Conflict resolution protocol for contradictory agent findings
- `ai-code-forensics` agent for AI code detection and improvement
- `silent-failure-hunter` agent for empty catch and swallowed error detection
- `type-design-analyzer` agent for type encapsulation scoring
- `comment-analyzer` agent for comment accuracy and staleness audit
- DevContainer support
- Pre-review routing (cost optimization) in sherlock-review-gate

### Changed
- Sherlock review gate now uses cost-routed agent selection
- File-type skip rules reduce unnecessary agent invocations

## [0.4.0] - 2026-02-28 - Framework Sync + Session Management

### Added
- `fw-sync.sh` for syncing framework updates to downstream projects
- `config/fw-manifest.yaml` for framework file sync policies
- `checkout-guard.py` hook to prevent branch switches during active sessions
- `commit-trust-check.py` hook for CI + health verification
- `pre-compact.py` hook for state preservation before context compaction
- Session lock system (`session-lock.json`)

## [0.3.0] - 2026-02-15 - Safety Gates + TDD Workflow

### Added
- 36 safety gate tests validating hook behavior
- TDD commit workflow (`scripts/tdd-commit.sh`)
- `auto-approve.py` safety gate with hard blocks
- `branch-check.py` for branch mismatch detection
- `protocol-validator.py` for deployment protocol reminders

## [0.2.0] - 2026-02-01 - Documentation + Skills

### Added
- Numbered documentation system (docs/00-80)
- Skills: deploy, health, release-notes, schema-check, browse, qa, retro
- Tiered deployment protocol (Tier 1/2/3)
- Auto version bump on merge to main

## [0.1.0] - 2026-01-15 - Initial Framework

### Added
- Config-driven architecture with `config/framework.yaml`
- Core hooks infrastructure
- Basic rules (anti-patterns, security)
- Git worktree session isolation
- CLAUDE.md project instructions
