# ShipTeam

**Turn Claude Code into a build team.**

One framework gives you a spec writer, TDD engineers, 14 code reviewers, a security auditor, a release manager, and a DevOps engineer — all working a structured workflow from specification to deployment. With safety gates that actually enforce the rules.

[![CI](https://github.com/cdjgroup/dev-framework/actions/workflows/ci-cd.yml/badge.svg)](https://github.com/cdjgroup/dev-framework/actions/workflows/ci-cd.yml)
[![Version](https://img.shields.io/github/v/tag/cdjgroup/dev-framework?label=version&color=green)](CHANGELOG.md)
[![Safety Tests](https://img.shields.io/badge/safety_tests-36-brightgreen.svg)](test/test_safety_gate.sh)
[![MIT License](https://img.shields.io/badge/license-MIT-blue.svg)](LICENSE)
[![GitHub stars](https://img.shields.io/github/stars/cdjgroup/dev-framework?style=social)](https://github.com/cdjgroup/dev-framework)
[![GitHub last commit](https://img.shields.io/github/last-commit/cdjgroup/dev-framework)](https://github.com/cdjgroup/dev-framework/commits/main)

**[What It Does](#what-it-does)** | **[The Build Team](#the-build-team)** | **[The Workflow](#the-workflow)** | **[Getting Started](#getting-started-3-commands-under-10-minutes)** | **[Profiles](#profiles-start-small-graduate-when-ready)** | **[What You Can Disable](#what-you-can-disable)** | **[Problems Solved](#what-problems-this-solves)** | **[Comparison](#how-it-compares)**

> **Requires [Claude Code](https://docs.anthropic.com/en/docs/claude-code/overview) — works on all surfaces: CLI, Desktop app, VS Code, JetBrains, and [claude.ai/code](https://claude.ai/code).** Does not work with Claude chat products (claude.ai chat, Claude Desktop chat app) or non-Anthropic AI IDEs (Cursor, Windsurf). See [Platform Compatibility](docs/ADOPTION.md#platform-compatibility).

---

## What It Does

Claude Code is a powerful coding agent — but it works alone. No plan, no tests-first discipline, no review process, no deployment gates. It can `rm -rf` your project, write tests that mirror the implementation (so they always pass), scope-creep into files you didn't ask about, and forget the plan after context compaction.

ShipTeam turns Claude Code into a **build team** that follows a real software development lifecycle:

```
Spec → Plan → TDD (RED/GREEN/REFACTOR) → Review → CI/CD → Deploy → Measure
```

Every stage has a specialized agent. Every transition has a gate. The workflow is enforced by hooks (not just instructions), measured by conformance scoring, and optimized by cost routing.

<p align="center">
  <img src="demo/hero-reel.gif" alt="ShipTeam build team in action: DevOps engineer blocking force-push, TDD engineers with cognitive isolation, review team staffing, conformance scoring" width="700">
</p>

---

## The Build Team

Each role in the team maps to one or more specialized agents that Claude invokes automatically based on the workflow stage:

### Spec & Planning

| Role | Agent | What It Does |
|---|---|---|
| **Product Manager** | `fw-author-spec` | Generates structured specifications — Acceptance Criteria (Given/When/Then) and Interface Contracts — from your requirements. Output feeds directly into TDD. |
| **Solutions Architect** | `fw-advisor-architecture` | Evaluates competing approaches (Minimal/Clean/Pragmatic), analyzes trade-offs across cost/performance/reliability, produces architecture decisions that persist as ADRs. |

You describe what you want. The framework writes the spec, plans the approach, and asks you to approve before a single line of code is written. The spec lives in `.sherlock-plan.md` and survives context compaction.

### Implementation (Cognitively-Isolated TDD)

| Role | Agent | What It Does |
|---|---|---|
| **Test Designer** | `fw-tdd-red` | Writes failing tests from the spec — never sees implementation code. This prevents the #1 AI testing failure: tests that mirror the implementation and always pass. |
| **Developer** | `fw-tdd-green` | Writes minimal code to make tests pass — never sees the original requirements. Sees only the test file and type signatures. |
| **Refactoring Engineer** | `fw-tdd-refactor` | Cleans up code while keeping tests green. Sees both tests and implementation. Applies DRY, improves naming, reduces complexity. |

The cognitive isolation is the key insight: when the test writer can't see the implementation, it writes tests that describe *behavior*, not tests that describe *how the code works*. This catches real bugs.

<img src="demo/tdd-workflow.gif" alt="TDD workflow: Test Designer writes failing tests, Developer implements, Refactoring Engineer cleans up" width="700">

### Code Review (14 Specialized Reviewers)

| Role | Agent | What It Does |
|---|---|---|
| **Code Reviewer** | `fw-review-code` | General code quality — correctness, readability, maintainability. Runs on every change. |
| **Security Engineer** | `fw-review-security` | OWASP Top 10, auth/RLS review, threat modeling, compliance (GDPR, SOC2, HIPAA). |
| **Performance Engineer** | `fw-review-performance` | N+1 queries, sync-in-async, missing indexes, React re-renders, bundle size. |
| **API Architect** | `fw-review-api-contracts` | Backward compatibility, response shape consistency, SSE contracts, frontend alignment. |
| **UX Engineer** | `fw-review-ux` | WCAG accessibility, interaction states (loading/empty/error), responsive design, cognitive load. |
| **Test Architect** | `fw-review-tests` | Test coverage, test quality, prompt injection defense, AI response validation. |
| **Database Engineer** | `fw-author-migration` | Schema verification, RLS policies, rollback scripts. Runs `/schema-check` first. |
| **Concurrency Engineer** | `fw-review-concurrency` | Race conditions, deadlocks, TOCTOU, stale closures across Python asyncio, Node.js, React, and database transactions. |
| **Supply Chain Auditor** | `fw-review-dependencies` | CVE reachability, license compatibility (GPL contamination), typosquatting, maintenance health. |
| **AI Code Auditor** | `fw-review-forensics` | Detects AI generation tells, hallucinated dependencies, safety guard removal, testing theater. |
| **Error Handling Reviewer** | `fw-review-error-handling` | Empty catch blocks, swallowed errors, fallback values that mask failures. |
| **Type System Reviewer** | `fw-review-types` | Anemic models, exposed mutability, missing construction validation. Scores 1-10. |
| **Maintainability Reviewer** | `fw-review-maintainability` | DRY, SOLID, coupling/cohesion, cyclomatic complexity, technical debt markers. |
| **Comment Reviewer** | `fw-review-comments` | Docstring/signature mismatches, stale TODOs, misleading safety claims, low-value comments. |

Not every reviewer runs on every change. **Cost routing** (`scripts/cost_routing.py`) classifies changes by type and size, then selects the minimum effective set — Haiku for docs, Sonnet for code, Opus only for security and architecture.

<img src="demo/cost-routing.gif" alt="Review team staffing: 1 reviewer for docs, 3 for features, 3 Opus-tier for schema changes" width="700">

### Release & Operations

| Role | Agent/Skill | What It Does |
|---|---|---|
| **Release Manager** | `fw-advisor-release` + `/ship` | Deployment readiness, versioning, tiered rollout (Tier 1: full, Tier 2: simplified, Tier 3: emergency). |
| **Documentation Engineer** | `fw-author-docs` + `fw-review-docs` | Detects which docs need updating from the code diff. Writes/updates them. Protocol gate blocks PR creation if docs are stale. |
| **DevOps Engineer** | Safety hooks + `/deploy` + `/health` | Default-deny destructive command blocking, CI trust gates, production health verification. |
| **Engineering Manager** | `/fw-stats` + conformance scoring | Tracks safety blocks, cost savings, plan adherence (file coverage, AC coverage, scope creep), TDD phase ratios. |

---

## The Workflow

When you say `sherlock` (or Claude classifies your task automatically), the build team activates:

**Step 0: Classify** — How complex is this? 1-2 files → Hudson (quick fix, 4 steps). 3-5 files → Sherlock Lite (6 steps). 6+ files or risk multipliers (DB, auth, payments) → Full Sherlock (8 steps).

<img src="demo/sherlock-routing.gif" alt="Build team staffing: Full Team recommended for OAuth2, Hudson for typo fix" width="700">

**Spec** — `fw-author-spec` writes Acceptance Criteria and Interface Contracts. You approve.

**Plan** — Architecture options evaluated. `.sherlock-plan.md` written with planned files, test strategy, and TDD phases. Survives context compaction.

**TDD** — `fw-tdd-red` writes failing tests from spec (never sees implementation). `fw-tdd-green` writes minimal code (never sees requirements). `fw-tdd-refactor` cleans up. Each phase is a separate commit.

**Review** — Relevant reviewers run in parallel after each phase. Cost routing selects the right agents. Conflict resolution protocol handles contradictory findings (security > correctness > performance).

**Conformance** — `fw_conformance.py` scores the session: Did you build what you planned? Are all acceptance criteria covered by tests? Any scope creep? Composite score targets 90%.

**Ship** — `/ship` creates branch, commits, pushes, opens PR. `/release-notes` generates the PR body. `protocol-validator.py` blocks PR creation if docs or changelog are stale.

**Deploy** — `/deploy` runs tiered checklist. `commit-trust-check.py` gates on CI pass. `/health` verifies production.

**Measure** — `/fw-stats` shows safety blocks, cost savings, conformance scores, and TDD health over time.

---

## Getting Started (3 commands, under 10 minutes)

```bash
gh repo create my-project --template cdjgroup/dev-framework --private
cd my-project
claude
```

Then tell Claude:

> Set up this project. My repo is `myorg/my-project`, I'm using a Python backend
> on port 8000 and a React frontend on port 3000. Start with the minimal profile.

That's it. Claude reads `SETUP.md` and `CLAUDE.md` automatically, edits `framework.yaml`, runs the 14-step setup wizard, installs hooks, and verifies everything works. You're ready to code.

**What just happened**: You now have safety gates (destructive commands are blocked), Hudson mode (quick-fix workflow), session isolation (worktree launcher), and the `/fw-stats` skill. That's the `minimal` profile — enough to be productive immediately.

<img src="demo/init-wizard.gif" alt="Build team assembled: 22 reviewers, 3 TDD engineers, 10 skills, 13 safety hooks" width="700">

**When you're ready for more**: Tell Claude "enable the standard profile" to activate the full build team (Sherlock methodology, TDD subagents, review pipeline, `/deploy`, `/ship`, and 6 more skills). Or jump straight to `full` for everything.

<details>
<summary><strong>Manual setup (if you prefer)</strong></summary>

```bash
gh repo create my-project --template cdjgroup/dev-framework --private
cd my-project
vim config/framework.yaml    # Set project name, repo, stack, profile
uvx shipteam init            # installer — renders CLAUDE.md, scaffolds .claude/ (~30s)
./scripts/claude-session.sh feature/my-first-feature
```

See [SETUP.md](SETUP.md) for GitHub secrets, branch protection, and optional features.

</details>

---

## Profiles: Start Small, Graduate When Ready

You don't have to use the whole framework. Three profiles control how much is active:

| Profile | What's Active | Components | Best For |
|---|---|---|---|
| **minimal** | Safety gates + Hudson mode + `/fw-stats` | ~15 | Getting started, evaluating the framework |
| **standard** | + Sherlock/Holmes + TDD subagents + `/deploy` `/ship` `/health` + review pipeline | ~40 | Daily development with the full build team |
| **full** | + `/qa` `/browse` `/retro` `/schema-check` + forensics + concurrency + supply chain review | ~75 | Complex projects, regulated environments |

Switch profiles any time: edit `profile:` in `framework.yaml` and run `uvx shipteam init --refresh`.

See the [Adoption Guide](docs/ADOPTION.md) for a day-by-day learning path (Day 1: Hudson, Day 2-3: Sherlock Lite, Day 4-5: review pipeline, Week 2+: Full Sherlock).

---

## What You Can Disable

Everything beyond the safety gates is optional. Here's what each toggle controls:

### Rules (auto-loaded `.md` files Claude follows)

| Config Key | Default | What It Controls | Safe to Disable? |
|---|---|---|---|
| `rules.anti_patterns` | `true` | 10 rules preventing scope creep, assumption-as-fact, skipped verification | Yes, but recommended to keep |
| `rules.security` | `true` | OWASP, PII, auth, LLM injection rules | Yes, but recommended to keep |
| `rules.database_migrations` | profile-dependent | Schema verification before SQL migrations | Yes, if no database |
| `rules.sherlock_review_gate` | profile-dependent | Multi-agent review pipeline + Sherlock/Holmes methodology | Yes — disables the full build team workflow, Hudson still works |

### Skills (slash commands)

| Config Key | Default | Command | Safe to Disable? |
|---|---|---|---|
| `skills.deploy` | standard+ | `/deploy` | Yes — use your own deploy process |
| `skills.health` | standard+ | `/health` | Yes — use your own health checks |
| `skills.release_notes` | standard+ | `/release-notes` | Yes — write PR descriptions manually |
| `skills.tdd_commit` | standard+ | `/tdd-commit` | Yes — use regular git commits |
| `skills.ship` | standard+ | `/ship` | Yes — create branches and PRs manually |
| `skills.schema_check` | full | `/schema-check` | Yes, if no database |
| `skills.browse` | full | `/browse` | Yes — requires Playwright MCP |
| `skills.qa` | full | `/qa` | Yes — requires Playwright MCP |
| `skills.retro` | full | `/retro` | Yes |
| `skills.fw_stats` | all | `/fw-stats` | Yes — metrics still collected, just no dashboard |

### Hooks (Python scripts enforcing behavior)

| Config Key | Default | What It Controls | Safe to Disable? |
|---|---|---|---|
| `hooks.deploy_gate` | `false` | Require CI pass before pushing to main | Yes — opt-in for strictness |

The 9 core hooks (safety gate, branch check, checkout guard, pre-compact, etc.) are always active. They're the foundation — removing them removes the safety guarantees.

### Metrics & Observability

| Config Key | Default | What It Controls | Safe to Disable? |
|---|---|---|---|
| `metrics.enabled` | `true` | Event logging (safety blocks, cost routing, conformance) | Yes — no data collected |
| `retro.track_tdd_phases` | `true` | TDD RED/GREEN/REFACTOR ratio tracking | Yes |
| `prompts.versioning` | `false` | LLM prompt snapshot exports | Yes — opt-in |

### Agents (not individually toggleable)

Review agents are selected automatically by `cost_routing.py` based on what files changed in the git diff. You don't configure them directly — they activate when relevant:

- Changed a database migration? → `fw-author-migration` runs
- Changed an API route? → `fw-review-api-contracts` runs
- Changed only docs? → Only `fw-review-docs` runs (Haiku tier, ~$0.02)
- Changed < 20 lines? → Only `fw-review-code` runs

To disable the entire review pipeline, set `rules.sherlock_review_gate: false`. Hudson mode (4-step quick fix) still works without it.

## What Problems This Solves

These are the [most-reported Claude Code frustrations](https://github.com/anthropics/claude-code/issues) — mapped to specific build team roles:

| Pain Point | Source | How the Build Team Handles It |
|---|---|---|
| Claude `rm -rf`'s your project | [GitHub #7972](https://github.com/anthropics/claude-code/issues/7972), [CVE-2025-59536](https://research.checkpoint.com/2026/rce-and-api-token-exfiltration-through-claude-code-project-files-cve-2025-59536/) | **DevOps engineer** — exit code 2 safety gate, default-deny, 36 test cases |
| Context compaction loses the plan | [HN thread](https://news.ycombinator.com/item?id=46426624) | **Product manager** — `.sherlock-plan.md` persists spec and plan to disk |
| Scope creep into unrelated files | [GitHub #7972](https://github.com/anthropics/claude-code/issues/7972) | **Engineering manager** — anti-pattern rules + conformance scoring catches drift |
| Ignores CLAUDE.md instructions | [GitHub #6120](https://github.com/anthropics/claude-code/issues/6120), [DEV Community](https://dev.to/minatoplanb/i-wrote-200-lines-of-rules-for-claude-code-it-ignored-them-all-4639) | **DevOps engineer** — hooks enforce what rules can't (CLAUDE.md = suggestions, hooks = enforcement) |
| Tests pass but miss real bugs | Community-wide complaint | **Test designer** — cognitively-isolated TDD; test writer never sees implementation |
| Token burn — $50/task | [WebProNews](https://www.webpronews.com/claude-codes-hidden-cost-problem-developers-sound-the-alarm-over-anthropics-opaque-token-billing/) | **Engineering manager** — cost routing skips unnecessary agents, routes to cheapest effective model |
| Quality varies between sessions | [GitHub #21431](https://github.com/anthropics/claude-code/issues/21431) | **Code review team** — 14 specialized reviewers with per-phase gates |
| Retry loops (same approach 5+ times) | Common pattern | **Sherlock methodology** — structured phases with pass/fail gates break the loop |
| Two sessions collide on same branch | Worktree-era problem | **DevOps engineer** — each session in its own git worktree with lock files |

<img src="demo/safety-gate.gif" alt="DevOps engineer blocking force-push, rm -rf, and DROP TABLE with exit code 2" width="700">

---

## How It Compares

| Capability | ShipTeam | [Everything-Claude-Code](https://github.com/affaan-m/everything-claude-code) | [GitHub Spec Kit](https://github.com/github/spec-kit) | [Guardrails repos](https://github.com/rulebricks/claude-code-guardrails) |
|---|---|---|---|---|
| **Spec generation** | Structured AC + Interface Contracts, feeds TDD | Via `/plan` command | Core focus (Specify/Plan/Tasks) | No |
| **TDD with cognitive isolation** | Yes — test writer never sees implementation | No | No | No |
| **Safety enforcement (exit code 2)** | 36 test cases, bypass-proof | Security scanning, rule-based | No | Hooks only, limited tests |
| **Multi-agent review pipeline** | 14 reviewers with cost routing + conflict resolution | 28 agents, broader scope | No | No |
| **Session isolation (worktrees)** | Built-in with lock files | No | No | No |
| **Conformance scoring** | Plan adherence measured (file/AC/scope/composite) | No | No | No |
| **Cost routing** | Haiku/Sonnet/Opus by change type + LOC | No | No | No |
| **Config-driven (one YAML)** | `framework.yaml` drives everything | JSON-based context | CLI templates | No |
| **Framework distribution** | `fw-sync.sh` with replace/template/merge | Manual copy | CLI install | Manual copy |
| **CI/CD + deploy gates** | 5 GitHub Actions + tiered deploy | Security scanning | GitHub Actions templates | No |
| **Progressive adoption** | 3 profiles (minimal/standard/full) | Selective language install | N/A | N/A |

**Key differentiator**: ShipTeam is the only solution that provides a **coherent end-to-end workflow** from specification through deployment with enforcement at every stage. Other tools provide collections of agents or safety hooks — ShipTeam provides a build team with a process.

---

<details>
<summary><strong>Safety Gates — Details</strong></summary>

The `auto_approve_base.py` hook enforces hard blocks (exit code 2) that **cannot be bypassed** through auto-approval settings or user permission overrides:

### Hard Blocks (Exit Code 2 — Always Blocked)

| Pattern | What's Prevented |
|---|---|
| `rm -rf` on unlisted paths | Default-deny: only explicitly safe paths are allowed |
| `git push --force` / `--force-with-lease` | Force-pushing to any branch |
| `DROP TABLE` / `TRUNCATE` / `DELETE` without `WHERE` | Destructive SQL (SQL comment bypass is prevented via normalization) |
| `git reset --hard` | Discarding uncommitted work |
| `git branch -d/-D` / `--delete-branch` | Branch deletion (flag-combo-aware) |
| `git push --delete` | Remote branch deletion |

### Fall-Through (User Prompted)

Operations like `gh pr merge` fall through to the normal permission system — Claude asks, you decide.

### 36 Test Cases

The safety gate is verified by `test/test_safety_gate.sh` with 36 test cases covering blocked patterns, allowed patterns, and bypass attempts.

</details>

<details>
<summary><strong>Conformance & Metrics</strong></summary>

The `/fw-stats` skill aggregates framework operational metrics over a time window:

```
Framework Stats (last 30d)
==================================================

Safety
  12 destructive ops blocked
     4 force-push  6 rm -rf  2 DROP without WHERE
  87 operations auto-approved

Cost Routing
  23 routing decisions
  41 agent invocations skipped
  Est. savings: ~$12.50

Plan Conformance (8 sessions scored)
  Composite: 91% avg (target: 90%)
  |-- File coverage:    94%
  |-- AC coverage:      88%
  |-- Scope creep:      85%
  |-- Hook compliance:  96%
  |-- Review gate:      100%

TDD Health
  RED:GREEN:REFACTOR = 24:26:14
  Ratio: 1.0 : 1.1 : 0.6 (target: 1:1:0.5)
```

Conformance scoring measures plan adherence across 5 dimensions:
- **File coverage** (25%): Did you modify the files you planned to?
- **AC coverage** (30%): Do tests reference all Acceptance Criteria from the spec?
- **Scope creep** (15%): How many lines changed in unplanned files?
- **Hook compliance** (15%): Did framework hooks execute without bypass?
- **Review gate** (15%): Were all mandatory reviews completed?

Events are logged to `.context/metrics/events-*.jsonl` via `fw_event_log.py` (fire-and-forget, fcntl-locked, date-partitioned, 50MB rotation).

</details>

<details>
<summary><strong>Cost Routing</strong></summary>

Multi-agent review pipelines route to the right model tier based on change type and LOC:

| Tier | Model | Agents | When |
|---|---|---|---|
| **Deep reasoning** | Opus | fw-advisor-architecture, fw-author-migration, fw-review-security, fw-review-forensics, fw-review-concurrency, fw-review-dependencies | Architectural decisions, security review, supply chain analysis |
| **Standard analysis** | Sonnet | fw-review-code, fw-review-performance, fw-review-api-contracts, fw-review-ux, fw-review-tests, fw-review-error-handling, fw-review-types | Most per-phase reviews |
| **Pattern matching** | Haiku | fw-review-docs, fw-review-maintainability, fw-review-comments | Low-complexity structural checks |

The `scripts/cost_routing.py` classifies changes and selects the minimal effective agent set:

| LOC Changed | Strategy | Typical Cost |
|---|---|---|
| < 20 | fw-review-code only (Sonnet) | ~$0.05 |
| 20-200 | Standard pipeline | ~$0.30-0.80 |
| 200-500 | + maintainability + forensics | ~$1.00-2.00 |
| > 500 | Full team, Opus for code reviewer | ~$3.00-5.00 |

Fast paths skip irrelevant agents: docs-only changes get one Haiku pass (~$0.02). Config-only changes get one Sonnet pass.

```bash
python3 scripts/cost_routing.py --base origin/main        # Per-phase routing
python3 scripts/cost_routing.py --final-gate --base origin/main  # Final gate
```

</details>

<details>
<summary><strong>Skills (10 Commands)</strong></summary>

Invocable commands that handle specific workflow stages:

| Skill | Command | Workflow Stage |
|---|---|---|
| **Ship** | `/ship [branch-name]` | Branch + commit + push + PR in one command |
| **Deploy** | `/deploy [tier1\|tier2\|tier3]` | Tiered deployment checklist |
| **Health** | `/health [frontend\|backend\|all]` | Production health verification |
| **Stats** | `/stats [7d\|30d\|all]` | Framework metrics (safety, cost, conformance, TDD) |
| **Release Notes** | `/release-notes <N> <title>` | Generate PR description + insight entry |
| **Schema Check** | `/schema-check <table>` | Verify DB schema before migrations |
| **QA** | `/qa [--full]` | Diff-aware visual QA testing |
| **Browse** | `/browse <url>` | Visual page inspection via Playwright MCP |
| **TDD Commit** | `/tdd-commit <red\|green\|refactor> [msg]` | Phase-specific TDD commits with AI messages |
| **Retro** | `/retro [7d\|14d\|30d]` | Engineering retrospective from git history |

</details>

<details>
<summary><strong>Rules System</strong></summary>

Rules are modular `.md` files in `.claude/rules/` that Claude auto-loads based on context:

| Rule | Purpose | Loading |
|---|---|---|
| `anti-patterns.md` | 10 rules preventing scope creep, assumption-as-fact, skipped verification | Always loaded |
| `security.md` | OWASP Top 10, PII protection, LLM injection defense, auth requirements | Always loaded |
| `sherlock-methodology.md` | Full build team workflow — Step 0 routing, Hudson/Lite/Full/Holmes modes | Always loaded |
| `sherlock-review-gate.md` | Multi-agent review pipeline, cost routing tables, conflict resolution | Always loaded |
| `database-migrations.md` | Schema verification, column name validation, PostgreSQL pitfalls | Path-specific |

</details>

<details>
<summary><strong>Configuration</strong></summary>

All framework behavior is driven by `config/framework.yaml`:

```yaml
# Complexity profile: minimal | standard | full
profile: minimal    # Start here — safety gates only

project:
  name: "my-project"
  repo: "myorg/my-project"

stack:
  backend:
    language: "python"
    test_command: "pytest"
  frontend:
    language: "typescript"
    test_command: "npm test"

versioning:
  primary_source: "FRAMEWORK_VERSION"
  locations:
    - file: "package.json"
    - file: "CLAUDE.md"

metrics:
  enabled: true       # Event logging + conformance scoring

skills:
  deploy: true
  health: true
  stats: true
  qa: true

hooks:
  deploy_gate: false   # Enable CI-must-pass before push
```

See [SETUP.md](SETUP.md) for the full configuration walkthrough.

</details>

### Session Isolation

Never run `claude` directly in your repo. The session launcher creates an isolated git worktree per session — each gets its own branch, its own copy of the code, and its own lock file. Run multiple sessions in parallel without conflicts.

```bash
./scripts/claude-session.sh feature/auth       # Terminal 1
./scripts/claude-session.sh feature/payments   # Terminal 2
```

One command handles worktree creation, dependency install, dev server startup, auto-sync with main, and cleanup on exit. The `checkout-guard.py` hook blocks branch switches when another Claude session is active.

See [SETUP.md — Daily Workflow: Session Isolation](SETUP.md#daily-workflow-session-isolation) for the full guide (directory structure, parallel sessions, cleanup, shell aliases).

<img src="demo/session-isolation.gif" alt="Two parallel build teams running in isolated worktrees, collision blocked by DevOps engineer" width="700">

<details>
<summary><strong>Repository Structure</strong></summary>

```
config/
  framework.yaml              # Central configuration (THE key file)
  fw-manifest.yaml             # File sync policies for framework updates

scripts/                       # 23+ automation scripts
  _framework.sh                # Shared bash library (sourced by all scripts)
  claude-session.sh            # Worktree session launcher + auto-sync
  tdd-commit.sh                # TDD phase commits (red/green/refactor)
  cost_routing.py              # Review agent selection by diff type + LOC
  fw_event_log.py              # JSONL event logging for hooks
  fw_conformance.py            # Plan adherence scoring
  fw-sync.sh                   # Pull upstream framework improvements
  bump-version.sh              # Multi-file version sync
  manage-servers.sh            # Dev server lifecycle management

.claude/
  hooks/                       # 13 Python hooks (safety, session, deployment)
    auto_approve_base.py       # Universal safety gate (exit 2 = hard block)
    auto-approve.py            # Project-specific overlay (imports base)
    branch-check.py            # Expected branch validation
    checkout-guard.py          # Concurrent session prevention
    commit-trust-check.py      # CI + health verification gate
    pre-compact.py             # Context compaction state saving
    protocol-validator.py      # Doc staleness gate + deployment warnings
  rules/                       # Auto-loaded rule files
    anti-patterns.md           # 10 mandatory rules
    security.md                # OWASP, PII, auth, LLM injection
    sherlock-methodology.md    # Full build team workflow
    sherlock-review-gate.md    # Review pipeline + cost routing
    database-migrations.md     # Schema verification protocol
  skills/                      # 10 invocable skill commands
    deploy/ health/ stats/ release-notes/ schema-check/
    browse/ qa/ retro/ tdd-commit/ ship/
  agents/                      # 22 specialized agents
    fw-author-spec.md          # Product Manager — spec generation
    fw-advisor-architecture.md # Solutions Architect
    fw-tdd-red.md              # Test Designer (isolated)
    fw-tdd-green.md            # Developer (isolated)
    fw-tdd-refactor.md         # Refactoring Engineer
    fw-review-code.md          # Code Reviewer (always runs)
    fw-review-security.md      # Security Engineer
    fw-review-performance.md   # Performance Engineer
    fw-review-api-contracts.md # API Architect
    fw-review-ux.md            # UX Engineer
    ...                        # + 12 more specialized reviewers
    AGENT_TEMPLATE.md          # Create your own
  spec-format.md               # Spec template (AC + Interface Contracts)

.github/workflows/             # 5 CI/CD pipelines
  ci-cd.yml                    # Stack-agnostic test + security + deploy
  auto-version-bump.yml        # Patch increment on merge to main
  semgrep.yml                  # Static security analysis
  security-scan.yml            # Dependency vulnerability scanning
  claude.yml                   # Claude Code GitHub Action

docs/                          # 15+ modular documentation files
test/                          # Safety gate tests (36 cases)
```

</details>

<details>
<summary><strong>Prerequisites</strong></summary>

| Requirement | Minimum |
|---|---|
| Git | 2.17+ (worktree support) |
| Bash | 4+ (macOS ships 3.x — see below) |
| Python | 3.9+ |
| Node.js | 18+ (for Claude Code CLI, not your project stack) |
| Claude Code CLI | Latest (`npm install -g @anthropic-ai/claude-code`) |
| Anthropic API key | [console.anthropic.com](https://console.anthropic.com) or Claude Pro/Max subscription |
| GitHub CLI | Latest |

**Install by platform:**

| | macOS | Ubuntu/Debian | Windows |
|---|---|---|---|
| All-in-one | `brew install git bash python node gh` | `sudo apt install git bash python3 nodejs gh` | Use the **DevContainer** (recommended) or **WSL** |
| Node.js note | -- | Use [NodeSource](https://github.com/nodesource/distributions) for current LTS | `wsl --install` then follow Linux steps |

**Windows users**: The included `.devcontainer/` provides a ready-to-go Linux environment with all prerequisites. Open in VS Code and select "Reopen in Container". See [SETUP.md](SETUP.md#platform-setup) for details.

Scripts validate prerequisites on first run and will tell you exactly what's missing.

</details>

<details>
<summary><strong>With and Without the Build Team</strong></summary>

| Scenario | Claude Code Alone | With ShipTeam |
|---|---|---|
| Complex feature request | Starts coding immediately, no spec | Writes spec with AC and Interface Contracts, gets approval first |
| Writing tests | Tests mirror implementation — always pass, catch nothing | Cognitively-isolated test writer never sees implementation |
| Claude runs `rm -rf /` | Your project is gone | Hard-blocked (exit code 2), cannot be bypassed |
| Context compacts mid-task | Starts over, forgets the plan | Plan file on disk anchors recovery |
| 40-file refactor | Chaos, scope creep | Phased TDD, per-phase review gates, conformance scoring |
| Code review | Hope for the best | 14 specialized reviewers, conflict resolution protocol |
| Token usage on a docs PR | Opus for everything (~$15) | Cost routing: Haiku, 1 agent (~$0.02) |
| Setting up a new project | Hours reading docs | Run `claude` and describe your stack — under 10 min |
| Deploying to production | No checklist, no gates | Tiered deploy + CI trust gate + health check |
| Measuring quality | No data | Safety blocks, cost savings, conformance scores, TDD ratios |

</details>

---

## Keeping Up to Date

```bash
./scripts/fw-sync.sh my-project --status     # Check what's changed upstream
./scripts/fw-sync.sh my-project --dry-run    # Preview changes without applying
./scripts/fw-sync.sh my-project              # Apply framework updates
```

`fw-sync.sh` uses three sync policies: **replace** (overwrite with upstream), **template** (show diff for manual review), and **merge** (three-way merge). Your project-specific customizations are preserved.

**Own your infrastructure.** Fork the template and make it yours. Every file is readable, modifiable, deletable. No lock-in, no black boxes, no surprise updates. Same instinct as [shadcn/ui](https://ui.shadcn.com/) — own what you depend on.

---

## Documentation

The `docs/` directory contains 15+ modular files covering architecture, deployment, auth, security, database, environment, testing, features, design insights, troubleshooting, and disaster recovery. Each is a template you customize.

See [docs/00-README.md](docs/00-README.md) for the full index.

## Architecture Decisions

Key design decisions are documented as [Architecture Decision Records](docs/adr/README.md) (ADRs). The Sherlock workflow auto-extracts ADRs from approved plans.

## Contributing

Contributions are welcome. Please open an issue first to discuss what you'd like to change.

See [CONTRIBUTING.md](CONTRIBUTING.md) for guidelines and [CODE_OF_CONDUCT.md](CODE_OF_CONDUCT.md) for community standards.

## License

MIT — see [LICENSE](LICENSE)
