"""
scoring/acceptance.py — Post-drive acceptance test scoring.

score_acceptance runs the frozen test suite (outside the driver workspace)
and returns an AcceptanceResult with acceptance_pct = passed / total.
"""
from __future__ import annotations

import errno
import os
import signal
import sys
import tempfile
import subprocess
import defusedxml.ElementTree as ET  # XXE-hardened drop-in for stdlib xml.etree.
from dataclasses import dataclass
from pathlib import Path


def _validate_counts(passed: int, failed: int, total: int, errors: int) -> None:
    for name, val in (("passed", passed), ("failed", failed), ("total", total), ("errors", errors)):
        if val < 0:
            raise ValueError(f"{name} must be >= 0, got {val}")
    if passed + failed > total:
        raise ValueError(
            f"passed({passed}) + failed({failed}) must not exceed total({total})"
        )


@dataclass(frozen=True)
class AcceptanceResult:
    acceptance_pct: float
    passed: int
    failed: int
    total: int
    errors: int = 0

    def __post_init__(self) -> None:
        if not (0.0 <= self.acceptance_pct <= 1.0):
            raise ValueError(
                f"acceptance_pct must be in [0.0, 1.0], got {self.acceptance_pct}"
            )
        _validate_counts(self.passed, self.failed, self.total, self.errors)


@dataclass(frozen=True)
class RunOutcome:
    passed: int
    failed: int
    total: int
    errors: int

    def __post_init__(self) -> None:
        _validate_counts(self.passed, self.failed, self.total, self.errors)


def run_pytest_on_frozen_suite(suite_path: Path, workspace: Path) -> RunOutcome:
    """
    Run pytest on suite_path with WORKSPACE env var set to workspace.resolve().
    Parses JUnit XML output and returns a RunOutcome with pass/fail/total/errors.
    """
    with tempfile.NamedTemporaryFile(suffix=".xml", delete=False) as tmp:
        xml_path = tmp.name

    try:
        try:
            proc = subprocess.run(
                [sys.executable, "-m", "pytest", str(suite_path),
                 f"--junitxml={xml_path}", "--tb=no", "-q"],
                env={**os.environ, "WORKSPACE": str(workspace.resolve())},
                capture_output=True,
                timeout=300,
            )
        except subprocess.TimeoutExpired:
            raise RuntimeError(
                f"pytest timed out after 300 seconds running suite: {suite_path}"
            )

        # Pytest exit codes (verified against _pytest.config.ExitCode 9.0.2):
        #   0 OK, 1 TESTS_FAILED, 2 INTERRUPTED (collection errors land here),
        #   3 INTERNAL_ERROR, 4 USAGE_ERROR, 5 NO_TESTS_COLLECTED.
        # 0/1/2 are expected outcomes whose JUnit XML we can trust.
        # 3 (internal) and 4 (usage) mean the run was incoherent — XML is unreliable.
        # 5 (no tests collected) is a configuration error in the frozen suite itself.
        # Negative returncode = process killed by signal (e.g., -9 SIGKILL on OOM).
        if proc.returncode < 0:
            sig_num = -proc.returncode
            try:
                sig_name = signal.Signals(sig_num).name
            except ValueError:
                sig_name = f"signal {sig_num}"
            raise RuntimeError(
                f"pytest killed by {sig_name} (returncode={proc.returncode}) "
                f"running suite: {suite_path}. "
                f"stderr: {proc.stderr.decode(errors='replace').strip()}"
            )
        if proc.returncode in (3, 4):
            kind = "internal error" if proc.returncode == 3 else "usage error"
            raise RuntimeError(
                f"pytest exited with {kind} (code {proc.returncode}) for suite: "
                f"{suite_path}. stderr: {proc.stderr.decode(errors='replace').strip()}"
            )
        if proc.returncode == 5:
            raise RuntimeError(
                f"pytest collected no tests in suite: {suite_path} (code 5). "
                f"This indicates the frozen suite is empty or misconfigured."
            )

        if not os.path.exists(xml_path):
            raise RuntimeError(
                f"pytest did not produce JUnit XML for suite: {suite_path} "
                f"(returncode={proc.returncode})"
            )

        try:
            tree = ET.parse(xml_path)
        except ET.ParseError as e:
            raise RuntimeError(
                f"Failed to parse JUnit XML for suite: {suite_path} "
                f"(returncode={proc.returncode}). ParseError: {e}"
            )
        root = tree.getroot()

        # Per-<testcase> iteration (replaces attribute arithmetic).
        # Why: pytest's <testsuite errors="N"> aggregates BOTH collection-time errors
        # (placeholder testcases with classname="") AND runtime/fixture errors
        # (real testcases with classname=<module>). The attribute-arithmetic form
        # `total = tests - errors` silently subtracts runtime errors from the
        # denominator, inflating acceptance_pct (a 1-pass/1-fail/1-fixture-error run
        # would report 1/2=0.5 instead of 1/3=0.333). Iterating <testcase> elements
        # and discriminating on empty classname avoids this. Verified against pytest
        # 9.0.2 empirical probe (Phase 5b review fix, 2026-04-27).
        total = 0
        passed = 0
        failures = 0
        errors = 0
        for testcase in root.iter("testcase"):
            classname = testcase.attrib.get("classname", "")
            has_error = testcase.find("error") is not None
            has_failure = testcase.find("failure") is not None
            has_skipped = testcase.find("skipped") is not None
            if classname == "" and has_error:
                # Collection-error placeholder (pytest could not import the test file).
                errors += 1
                continue
            if has_skipped:
                # Skipped tests are excluded from the denominator.
                continue
            total += 1
            if has_failure:
                failures += 1
            elif has_error:
                errors += 1
            else:
                passed += 1

    finally:
        try:
            os.unlink(xml_path)
        except OSError:
            pass

    return RunOutcome(
        passed=passed,
        failed=failures,
        total=total,
        errors=errors,
    )


def _collect_inodes(directory: Path) -> set[tuple[int, int]]:
    """Return set of (st_dev, st_ino) for all files under directory.

    Catches HARDLINKS and BIND-MOUNTS only. Symlink protection is *not* the
    job of this function — empirically (verified Phase-5{a,b,c}-followup),
    `lstat()` on a symlink returns the symlink's own inode, distinct from
    the target's, so a workspace symlink pointing at a frozen test would NOT
    appear in the inode-overlap set. That is intentional layering:

      Layer 1 (host, Python): bidirectional ancestor check at score_acceptance
              top-of-function — catches the symlink case via path resolution.
      Layer 2 (host, Python): this function — catches hardlinks (different
              paths, identical (st_dev, st_ino) under lstat).
      Layer 3 (container, Phase 5d): RO bind-mount of frozen_test_suite
              with no CAP_DAC_OVERRIDE — catches in-container bind-mount
              and hardlink attempts at the kernel mount level.

    Why lstat() not stat(): if the workspace contains a symlink pointing
    INTO the workspace at a frozen-test path that itself was hardlinked in,
    stat() would follow the symlink and double-count the hardlinked inode.
    lstat() keeps the inode set scoped to "files actually living in this
    tree" so the comparison stays semantically clean.

    OSError handling: ENOENT/ESTALE (file vanished mid-walk, e.g. concurrent
    cleanup) are swallowed; any other OSError (EACCES, ELOOP, etc.) propagates
    so a permission failure in the workspace cannot silently shrink the inode
    set and disable the tamper guard.
    """
    inodes: set[tuple[int, int]] = set()
    for dirpath, _, filenames in os.walk(directory):
        for filename in filenames:
            filepath = Path(dirpath) / filename
            try:
                st = filepath.lstat()
                inodes.add((st.st_dev, st.st_ino))
            except OSError as e:
                if e.errno in (errno.ENOENT, errno.ESTALE):
                    continue
                raise
    return inodes


def score_acceptance(
    workspace: Path,
    frozen_test_suite: Path,
) -> AcceptanceResult:
    """
    Score the workspace against the frozen test suite.

    The frozen_test_suite path must exist and must NOT be inside workspace,
    and workspace must NOT be inside frozen_test_suite, and they must not be equal.
    Tests are run from frozen_test_suite, not from workspace, preventing
    driver-written test stubs from inflating the score.

    Raises:
        FileNotFoundError: if frozen_test_suite does not exist.
        ValueError: if frozen_test_suite and workspace share an ancestor relationship.
        RuntimeError: if any file in both trees shares an inode (hardlink/bind-mount tampering).
    """
    if not frozen_test_suite.exists():
        raise FileNotFoundError(
            f"Frozen test suite not found: {frozen_test_suite}"
        )

    # AC-13 tamper-resistance: bidirectional ancestor guard + equality check
    try:
        ft_resolved = frozen_test_suite.resolve()
        ws_resolved = workspace.resolve()
    except OSError as e:
        raise ValueError(
            f"Could not resolve paths for AC-13 ancestor check (symlink cycle "
            f"or filesystem error?): workspace={workspace!r}, "
            f"frozen_test_suite={frozen_test_suite!r}. Underlying error: {e}"
        ) from e

    if ft_resolved == ws_resolved:
        raise ValueError(
            f"workspace and frozen_test_suite must not be the same path: {workspace}"
        )

    if ws_resolved in ft_resolved.parents:
        raise ValueError(
            f"frozen_test_suite ({frozen_test_suite}) must not be inside "
            f"workspace ({workspace}); AC-13 requires post-drive isolation."
        )

    if ft_resolved in ws_resolved.parents:
        raise ValueError(
            f"workspace ({workspace}) must not be inside frozen_test_suite "
            f"({frozen_test_suite}); AC-13 requires post-drive isolation."
        )

    # AC-13 hardlink/inode guard: detect bind-mount or hardlink tampering
    ws_inodes = _collect_inodes(ws_resolved)
    ft_inodes = _collect_inodes(ft_resolved)

    if ws_inodes and ft_inodes:
        shared = ws_inodes & ft_inodes
        if shared:
            raise RuntimeError(
                f"Detected shared inode (hardlink or bind-mount) between workspace "
                f"({workspace}) and frozen_test_suite ({frozen_test_suite}). "
                f"Shared inodes: {shared}. This may indicate tampering."
            )

    outcome = run_pytest_on_frozen_suite(frozen_test_suite, workspace)

    passed = outcome.passed
    failed = outcome.failed
    total = outcome.total
    errors = outcome.errors

    acceptance_pct = passed / total if total > 0 else 0.0

    return AcceptanceResult(
        acceptance_pct=acceptance_pct,
        passed=passed,
        failed=failed,
        total=total,
        errors=errors,
    )
