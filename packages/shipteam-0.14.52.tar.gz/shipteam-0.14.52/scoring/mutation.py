"""
scoring/mutation.py — Mutation testing scoring.

Invokes mutmut (Python) or Stryker via npx (JS/TS) and aggregates mutation
results into a MutationResult.

Threading caveat: this module uses POSIX process groups (start_new_session=True)
to manage subprocess lifecycle. Safe to call from a single-threaded parent;
not designed for concurrent invocation against the same workspace.

Polyglot caveat: when language="polyglot", JS results are stored under the
"javascript" key regardless of whether the task is JavaScript or TypeScript.
Specify language="typescript" explicitly for TS tasks if downstream consumers
key on language.

Measurement caveats (AC-18):
  - mutmut#349: mutants that crash the test-suite BEFORE any test runs are
    misclassified as `survived` (false-negative); cannot be detected
    scorer-side. The counter-sum/total internal-consistency check below
    catches gross corruption only.
  - mutmut 3.3.0 swapped parso → LibCST for AST manipulation (breaking-
    change boundary). Harness pins mutmut==3.5.0 to stay above that
    boundary so same-seed scores are comparable across runs.
  - Stryker #2519: SIGTERM does NOT cleanly dispose child runners on Linux.
    The os.killpg(SIGTERM)+SIGKILL escalation below mitigates the parent-
    process leak but inherits the upstream child-runner orphan bug.
  - Score formulas are harness conventions, not published tool invariants.
"""
from __future__ import annotations

import json
import os
import shutil
import signal
import subprocess
from dataclasses import dataclass, field
from pathlib import Path
from typing import Literal

ToolName = Literal["mutmut", "stryker"]
LangErrorKey = Literal[
    "tool_missing",
    "mutmut_baseline_failed",
    "mutmut_timeout",
    "stryker_crashed",
    "workspace_cleanup_failed",
]


@dataclass(frozen=True)
class LanguageMutationScore:
    killed: int
    survived: int
    timeout: int
    suspicious: int = 0
    no_tests: int = 0
    skipped: int = 0
    segfault: int = 0
    check_was_interrupted: int = 0
    no_coverage: int = 0
    compile_error: int = 0
    runtime_error: int = 0
    ignored: int = 0
    pending: int = 0
    score: float | None = None  # None when denominator is 0 (workspace had no scorable mutants)


@dataclass
class MutationResult:
    per_language: dict[str, LanguageMutationScore | None]
    error: str | None
    # Display-only: first missing tool encountered. NOT exhaustive — use
    # per_language_error to determine which languages failed.
    tool_name: ToolName | None
    per_language_error: dict[str, LangErrorKey] = field(default_factory=dict)


def _score_python(
    workspace: Path, task_manifest: dict, timeout_seconds: int
) -> tuple[LanguageMutationScore | None, LangErrorKey | None]:
    mutants_dir = workspace / "mutants"
    # AC-19: full mutants/ cleanup pre-run guards against cross-run cache pollution
    # (mutmut's .mutmut-cache SQLite is on-by-default). Fail-loud on permission errors
    # so a silently-failed cleanup doesn't ship cross-run-polluted scores.
    try:
        shutil.rmtree(mutants_dir)
    except FileNotFoundError:
        pass
    except OSError:
        return None, "workspace_cleanup_failed"

    test_command = task_manifest.get("test_command", "pytest")

    try:
        subprocess.run(
            ["mutmut", "run", "--test-command", test_command],
            cwd=workspace,
            timeout=timeout_seconds,
        )
        subprocess.run(
            ["mutmut", "export_cicd_stats"],
            cwd=workspace,
            timeout=timeout_seconds,
        )
    except FileNotFoundError:
        return None, "tool_missing"
    except subprocess.TimeoutExpired:
        return None, "mutmut_timeout"

    stats_file = workspace / "mutants" / "mutmut-cicd-stats.json"
    if not stats_file.exists():
        return None, "mutmut_baseline_failed"

    try:
        stats = json.loads(stats_file.read_text())
    except (json.JSONDecodeError, OSError):
        return None, "mutmut_baseline_failed"

    killed = stats.get("killed", 0)
    survived = stats.get("survived", 0)
    suspicious = stats.get("suspicious", 0)
    timeout = stats.get("timeout", 0)
    no_tests = stats.get("no_tests", 0)
    skipped = stats.get("skipped", 0)
    segfault = stats.get("segfault", 0)
    check_was_interrupted = stats.get("check_was_interrupted_by_user", 0)
    total = stats.get("total", 0)

    counter_sum = (
        killed + survived + suspicious + timeout + no_tests + skipped + segfault + check_was_interrupted
    )

    # AC-19 internal consistency: total positive, matches sum-of-8, not all-Ctrl-C.
    if total <= 0 or total != counter_sum or check_was_interrupted == total:
        return None, "mutmut_baseline_failed"

    denom = killed + survived + suspicious + timeout
    # score=None for empty-denominator (only no_tests/skipped/segfault landed) so consumers
    # can distinguish "ran, killed nothing" from "no scorable mutants present."
    score_val = killed / denom if denom != 0 else None

    return (
        LanguageMutationScore(
            killed=killed,
            survived=survived,
            timeout=timeout,
            suspicious=suspicious,
            no_tests=no_tests,
            skipped=skipped,
            segfault=segfault,
            check_was_interrupted=check_was_interrupted,
            score=score_val,
        ),
        None,
    )


def _score_js(
    workspace: Path, task_manifest: dict, timeout_seconds: int
) -> tuple[LanguageMutationScore | None, LangErrorKey | None]:
    # --no-install: forbid npx auto-fetching from registry. Stryker must already
    # exist in node_modules/.bin (locked at task-pack build time). Enforces
    # AC-6 reproducibility and prevents supply-chain typo-squat exposure.
    cmd = ["npx", "--no-install", "stryker", "run", "--reporters", "json"]
    config_path = task_manifest.get("stryker_config_path")
    if config_path:
        cmd += ["--configFile", config_path]

    # start_new_session=True is the thread-safe equivalent of preexec_fn=os.setsid
    # (CPython gh-114220 deprecated preexec_fn on 3.12+ for fork-safety reasons).
    try:
        proc = subprocess.Popen(cmd, cwd=workspace, start_new_session=True)
    except FileNotFoundError:
        return None, "tool_missing"

    # Capture pgid immediately to avoid PID-recycle TOCTOU on long sweeps:
    # by the time TimeoutExpired fires, proc.pid may have been reused by
    # an unrelated process and os.getpgid would target the wrong group.
    pgid = proc.pid  # start_new_session=True makes pid == pgid

    try:
        proc.wait(timeout=timeout_seconds)
    except subprocess.TimeoutExpired:
        try:
            os.killpg(pgid, signal.SIGTERM)
        except (ProcessLookupError, PermissionError):
            pass
        try:
            proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            try:
                os.killpg(pgid, signal.SIGKILL)
            except (ProcessLookupError, PermissionError):
                pass
        return None, "stryker_crashed"

    report_file = workspace / "reports" / "mutation" / "mutation.json"
    if not report_file.exists():
        return None, "stryker_crashed"

    try:
        report = json.loads(report_file.read_text())
    except (json.JSONDecodeError, OSError):
        return None, "stryker_crashed"

    counters = {
        "Killed": 0, "Survived": 0, "Timeout": 0, "NoCoverage": 0,
        "CompileError": 0, "RuntimeError": 0, "Ignored": 0, "Pending": 0,
    }
    for file_data in report.get("files", {}).values():
        for mutant in file_data.get("mutants", []):
            status = mutant.get("status", "")
            if status in counters:
                counters[status] += 1

    killed = counters["Killed"]
    survived = counters["Survived"]
    timeout = counters["Timeout"]
    no_coverage = counters["NoCoverage"]
    denom = killed + survived + timeout + no_coverage
    score_val = (killed + timeout) / denom if denom != 0 else None

    return (
        LanguageMutationScore(
            killed=killed,
            survived=survived,
            timeout=timeout,
            no_coverage=no_coverage,
            compile_error=counters["CompileError"],
            runtime_error=counters["RuntimeError"],
            ignored=counters["Ignored"],
            pending=counters["Pending"],
            score=score_val,
        ),
        None,
    )


def score_mutation(
    workspace: Path,
    task_manifest: dict,
    timeout_seconds: int = 300,
    js_timeout_seconds: int = 900,
) -> MutationResult:
    """
    Score mutation testing for the workspace.

    timeout_seconds: budget for the Python (mutmut) path. Default 300s.
    js_timeout_seconds: budget for the JS (Stryker) path; defaults to 900s
      because Stryker on a moderate JS project routinely takes 5-15 min
      (per-mutant npm boot + slower runner).
    """
    language = task_manifest.get("language", "python")
    per_language: dict[str, LanguageMutationScore | None] = {}
    per_language_error: dict[str, LangErrorKey] = {}
    tool_name: ToolName | None = None

    if language in ("python", "polyglot"):
        lang_score, error_key = _score_python(workspace, task_manifest, timeout_seconds)
        per_language["python"] = lang_score
        if error_key:
            per_language_error["python"] = error_key
            if tool_name is None and error_key == "tool_missing":
                tool_name = "mutmut"

    if language in ("javascript", "typescript", "polyglot"):
        lang_key = language if language in ("javascript", "typescript") else "javascript"
        lang_score, error_key = _score_js(workspace, task_manifest, js_timeout_seconds)
        per_language[lang_key] = lang_score
        if error_key:
            per_language_error[lang_key] = error_key
            if tool_name is None and error_key == "tool_missing":
                tool_name = "stryker"

    return MutationResult(
        per_language=per_language,
        error=None,
        tool_name=tool_name,
        per_language_error=per_language_error,
    )
