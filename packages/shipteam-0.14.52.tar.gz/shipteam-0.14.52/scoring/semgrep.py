"""
scoring/semgrep.py — Semgrep static-analysis scorer for ShipTeam Benchmark Harness.

AC-18 caveats:
- Semgrep severity taxonomy: 9 match_severity variants (CRITICAL, HIGH, MEDIUM, LOW, INFO,
  ERROR, WARNING, EXPERIMENT, INVENTORY). ERROR maps to HIGH semantics, WARNING to MEDIUM
  semantics (backward-compat per ATD doc), but are emitted as ERROR/WARNING in JSON.
  unknown_severities overflow bucket catches future variants Semgrep adds post-pin.
- Cache (#3147): SemgrepCache is a sweep-lifetime local cache; cross-sweep sentinel
  invalidation deletes stale files on sweep_id mismatch. Single-process only.
- Stdout interleave (#4676): semgrep may interleave non-JSON to stdout; scorer always
  uses --output <tempfile> and reads tempfile, never stdout, to avoid parse errors.

Security:
- HTTPS-only + host allowlist (raw.githubusercontent.com) + custom redirect handler that
  refuses non-http(s) schemes. Defends against SSRF/LFI via 3xx → file:// / ftp:// /
  data:// redirects (urllib default opener would otherwise follow them).
"""
from __future__ import annotations

import hashlib
import json
import re
import shutil
import subprocess
import tempfile
import urllib.error
import urllib.request
from dataclasses import dataclass
from pathlib import Path
from typing import Literal
from urllib.parse import urlparse

SemgrepSeverity = Literal[
    "CRITICAL", "HIGH", "MEDIUM", "LOW", "INFO",
    "ERROR", "WARNING",
    "EXPERIMENT", "INVENTORY",
]

SemgrepErrorKey = Literal[
    "tool_missing",
    "semgrep_timeout",
    "semgrep_output_malformed",
    "semgrep_failed",
    "ruleset_fetch_failed",
]

_SHA_PATTERN = re.compile(r"^[0-9a-f]{40}$")
# HTTPS-only + single-host allowlist. http:// dropped to prevent TOFU manipulation.
_RAW_GITHUB_URL_PATTERN = re.compile(
    r"^https://raw\.githubusercontent\.com/[^/]+/[^/]+/(.+)/[^/]+$"
)
_ALLOWED_RULESET_HOST = "raw.githubusercontent.com"
_ALLOWED_RULESET_SCHEMES = frozenset(["https"])
_VALID_SEVERITIES = frozenset(["CRITICAL", "HIGH", "MEDIUM", "LOW", "INFO",
                                "ERROR", "WARNING", "EXPERIMENT", "INVENTORY"])


class _StrictHTTPSRedirectHandler(urllib.request.HTTPRedirectHandler):
    """Follows 3xx redirects only when the target remains on an allowed HTTPS host.

    Defense against SSRF/LFI: Python's default redirect handler will follow 3xx
    responses into any scheme urllib.request supports (file://, ftp://, data://,
    etc.). An attacker-controlled URL on an allowed host can 302-redirect to
    file:///etc/passwd, and the downloaded bytes would be cached then handed to
    semgrep. Blocking non-https/non-allowlisted-host redirects closes that hole.
    """

    def redirect_request(self, req, fp, code, msg, headers, newurl):  # type: ignore[override]
        parsed = urlparse(newurl)
        if parsed.scheme not in _ALLOWED_RULESET_SCHEMES:
            raise urllib.error.URLError(
                f"Refused redirect to disallowed scheme {parsed.scheme!r}: {newurl!r}"
            )
        if parsed.hostname != _ALLOWED_RULESET_HOST:
            raise urllib.error.URLError(
                f"Refused redirect to disallowed host {parsed.hostname!r}: {newurl!r}"
            )
        return super().redirect_request(req, fp, code, msg, headers, newurl)


def _build_opener() -> urllib.request.OpenerDirector:
    # Replace default redirect handler; keep stdlib TLS verification defaults.
    return urllib.request.build_opener(_StrictHTTPSRedirectHandler())


class RulesetRefError(Exception):
    def __init__(self, ref: str, url: str | None = None):
        self.ref = ref
        self.url = url
        super().__init__(f"Ruleset URL ref must be a 40-char hex SHA, got: {ref!r}")


class RulesetFetchError(Exception):
    """Raised by SemgrepCache.fetch_or_reuse when remote ruleset cannot be downloaded."""
    def __init__(self, url: str, cause: BaseException | None = None):
        self.url = url
        self.cause = cause
        super().__init__(f"Failed to fetch ruleset from {url!r}: {cause!r}")


@dataclass(frozen=True)
class SemgrepResult:
    # by_severity keys are SemgrepSeverity values at runtime (enforced by the
    # producer); typed open-string because dict[Literal,...] can't be constructed
    # from str keys without a cast and the overflow bucket is in unknown_severities.
    by_severity: dict[str, int]
    unknown_severities: dict[str, int]
    high: int
    critical: int
    ruleset_commit: str | None
    ruleset_source_url: str | None
    cache_hit: bool
    error: SemgrepErrorKey | None
    tool_name: Literal["semgrep"] | None


class SemgrepCache:
    """
    Sweep-lifetime local cache of remote rulesets. Single-process only —
    concurrent SemgrepCache(cache_dir, sweep_id) constructors with different
    sweep_ids on the same cache_dir have undefined behavior.
    """

    def __init__(self, cache_dir: Path, sweep_id: str):
        self.cache_dir = cache_dir
        self.sweep_id = sweep_id
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        sentinel = self.cache_dir / ".sweep_id"
        existing = sentinel.read_text().strip() if sentinel.exists() else None
        if existing is not None and existing != sweep_id:
            self.invalidate()
        sentinel.write_text(sweep_id)

    def fetch_or_reuse(self, config_url_or_path: str) -> tuple[Path, bool]:
        """
        Returns (local_path, cache_hit). Local paths returned as-is with cache_hit=False.
        Remote URLs MUST be HTTPS + raw.githubusercontent.com host (enforced by
        _validate_ruleset_url). Raises RulesetFetchError on network failure —
        callers MUST catch and translate to a structured error key (AC-17 fail-closed).
        """
        if not config_url_or_path.startswith("https://"):
            return Path(config_url_or_path), False
        # Full 64-char digest closes the 16-char birthday-collision surface.
        url_hash = hashlib.sha256(config_url_or_path.encode("utf-8")).hexdigest()
        cache_file = self.cache_dir / f"{url_hash}.yml"
        if cache_file.exists():
            return cache_file, True
        try:
            opener = _build_opener()
            with opener.open(config_url_or_path) as resp:
                cache_file.write_bytes(resp.read())
        except (urllib.error.URLError, TimeoutError, OSError) as exc:
            raise RulesetFetchError(url=config_url_or_path, cause=exc) from exc
        return cache_file, False

    def invalidate(self) -> None:
        """Delete all cached files (preserves the cache_dir itself)."""
        for f in self.cache_dir.glob("*"):
            if f.is_file():
                f.unlink()
            elif f.is_dir():
                shutil.rmtree(f)


def _validate_ruleset_ref(url: str) -> None:
    """
    Enforce https + raw.githubusercontent.com + 40-char hex SHA ref.
    Non-allowlisted hosts raise RulesetRefError so downstream cannot silently
    record ruleset_commit=None for a mutable source (AC-6 reproducibility).
    """
    parsed = urlparse(url)
    if parsed.scheme != "https":
        raise RulesetRefError(ref=parsed.scheme or "<no-scheme>", url=url)
    if parsed.hostname != _ALLOWED_RULESET_HOST:
        raise RulesetRefError(ref=parsed.hostname or "<no-host>", url=url)
    m = _RAW_GITHUB_URL_PATTERN.match(url)
    if not m:
        raise RulesetRefError(ref="<unparseable>", url=url)
    ref = m.group(1)
    if not _SHA_PATTERN.match(ref):
        raise RulesetRefError(ref=ref, url=url)


def _extract_ruleset_commit(url: str) -> str | None:
    m = _RAW_GITHUB_URL_PATTERN.match(url)
    if m and _SHA_PATTERN.match(m.group(1)):
        return m.group(1)
    return None


def _empty_result(
    *, error: str | None = None, tool_name: str | None = None,
    cache_hit: bool = False, ruleset_commit: str | None = None,
    ruleset_source_url: str | None = None,
) -> SemgrepResult:
    return SemgrepResult(
        by_severity={},
        unknown_severities={},
        high=0,
        critical=0,
        ruleset_commit=ruleset_commit,
        ruleset_source_url=ruleset_source_url,
        cache_hit=cache_hit,
        error=error,
        tool_name=tool_name,
    )


def score_semgrep(
    workspace: Path,
    ruleset: str,
    cache: SemgrepCache,
    timeout_seconds: int = 120,
) -> SemgrepResult:
    """
    AC-20: validates ruleset URL refs are 40-char hex SHA via RulesetRefError.
    AC-21: SemgrepCache.fetch_or_reuse returns a local path; cache_hit=True if reused.
    R4: invokes semgrep with --json --output <tempfile>; reads tempfile, never stdout.
    Counts all 9 ATD severities; unknown variants land in unknown_severities.
    """
    # SHA validator runs FIRST (fail-fast before any I/O or subprocess).
    is_url = ruleset.startswith(("http://", "https://"))
    if is_url:
        _validate_ruleset_ref(ruleset)

    ruleset_source_url = ruleset if is_url else None
    ruleset_commit = _extract_ruleset_commit(ruleset) if ruleset_source_url else None

    try:
        local_path, cache_hit = cache.fetch_or_reuse(ruleset)
    except RulesetFetchError:
        return _empty_result(
            error="ruleset_fetch_failed", cache_hit=False,
            ruleset_commit=ruleset_commit, ruleset_source_url=ruleset_source_url,
        )

    # R4: write to tempfile, NEVER parse stdout
    with tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False) as tf:
        output_path = Path(tf.name)

    try:
        try:
            proc = subprocess.run(
                ["semgrep", "scan", "--json", "--output", str(output_path),
                 "--config", str(local_path)],
                cwd=workspace,
                timeout=timeout_seconds,
            )
        except FileNotFoundError:
            return _empty_result(
                error="tool_missing", tool_name="semgrep",
                cache_hit=cache_hit, ruleset_commit=ruleset_commit,
                ruleset_source_url=ruleset_source_url,
            )
        except subprocess.TimeoutExpired:
            return _empty_result(
                error="semgrep_timeout", cache_hit=cache_hit,
                ruleset_commit=ruleset_commit, ruleset_source_url=ruleset_source_url,
            )

        # Semgrep nonzero exit (rule parse error, internal panic, missing config)
        # surfaces as semgrep_failed — distinct from output_malformed (which means
        # semgrep RAN but produced unparseable JSON).
        if proc.returncode != 0:
            return _empty_result(
                error="semgrep_failed", cache_hit=cache_hit,
                ruleset_commit=ruleset_commit, ruleset_source_url=ruleset_source_url,
            )

        try:
            output = json.loads(output_path.read_text())
        except (json.JSONDecodeError, OSError):
            return _empty_result(
                error="semgrep_output_malformed", cache_hit=cache_hit,
                ruleset_commit=ruleset_commit, ruleset_source_url=ruleset_source_url,
            )
    finally:
        try:
            output_path.unlink()
        except OSError:
            pass

    by_severity: dict[str, int] = {}
    unknown_severities: dict[str, int] = {}
    for result in output.get("results", []):
        sev = result.get("extra", {}).get("severity", "")
        if sev in _VALID_SEVERITIES:
            by_severity[sev] = by_severity.get(sev, 0) + 1
        elif sev:
            unknown_severities[sev] = unknown_severities.get(sev, 0) + 1

    high = by_severity.get("HIGH", 0) + by_severity.get("ERROR", 0)
    critical = by_severity.get("CRITICAL", 0)

    return SemgrepResult(
        by_severity=by_severity,
        unknown_severities=unknown_severities,
        high=high,
        critical=critical,
        ruleset_commit=ruleset_commit,
        ruleset_source_url=ruleset_source_url,
        cache_hit=cache_hit,
        error=None,
        tool_name=None,
    )
