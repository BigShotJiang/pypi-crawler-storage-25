"""
scoring/injected_bugs.py — Injected-bug detection scoring.

Correlates pre-computed test results against a corpus of injected bugs
to produce a detection score. Does NOT apply patches or run tests itself.

Measurement caveats (AC-18):
  - Formula convention is harness-defined: detections / corpus_size; not
    a published invariant of any upstream tool.
"""
from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Literal

import yaml


@dataclass(frozen=True)
class InjectedBugEntry:
    bug_id: str
    description: str
    patch_file: str
    detectable_by: tuple[str, ...]
    severity: Literal["low", "medium", "high", "critical"]


@dataclass(frozen=True)
class Corpus:
    schema_version: Literal[1]
    bugs: tuple[InjectedBugEntry, ...]


class CorpusError(Exception): ...
class CorpusSchemaError(CorpusError): ...


@dataclass
class CorpusSecurityError(CorpusError):
    bug_id: str
    attempted_path: str
    resolved_path: str

    def __str__(self) -> str:
        return (
            f"patch_file for bug {self.bug_id!r} escapes corpus root: "
            f"attempted={self.attempted_path!r}, resolved={self.resolved_path!r}"
        )


def load_corpus(corpus_path: Path) -> Corpus:
    """Enforces schema_version==1 and rejects patch_file paths that escape corpus root."""
    manifest_file = corpus_path / "manifest.yaml"
    with manifest_file.open() as f:
        data = yaml.safe_load(f)

    schema_version = data.get("schema_version")
    if schema_version != 1:
        raise CorpusSchemaError(
            f"Unsupported schema version: expected=1, actual={schema_version}"
        )

    corpus_root = corpus_path.resolve()
    bugs: list[InjectedBugEntry] = []
    for bug_data in data.get("bugs", []):
        bug_id = bug_data["bug_id"]
        patch_file = bug_data["patch_file"]

        resolved = (corpus_path / patch_file).resolve()
        if not resolved.is_relative_to(corpus_root):
            raise CorpusSecurityError(
                bug_id=bug_id,
                attempted_path=patch_file,
                resolved_path=str(resolved),
            )

        bugs.append(InjectedBugEntry(
            bug_id=bug_id,
            description=bug_data["description"],
            patch_file=patch_file,
            detectable_by=tuple(bug_data["detectable_by"]),
            severity=bug_data["severity"],
        ))

    return Corpus(schema_version=1, bugs=tuple(bugs))


def validate_corpus(corpus: Corpus, min_bugs: int = 20) -> None:
    """AC-9 MUST-HAVE sweep-start gate. Default min_bugs=20 makes sensitivity scores meaningful."""
    actual = len(corpus.bugs)
    if actual < min_bugs:
        raise CorpusError(
            f"Corpus has {actual} bugs; minimum required is {min_bugs}"
        )


@dataclass(frozen=True)
class InjectedBugResult:
    corpus_size: int
    detections: int
    detail_file: Path
    # tool_name: None for this correlation-only scorer; retained for shape-symmetry
    # with MutationResult/SemgrepResult (AC-17 tool-missing uniformity).
    error: str | None
    tool_name: str | None


def score_injected_bugs(
    workspace: Path,
    frozen_test_suite: Path,  # reserved: future callers that run the suite in-scorer
    corpus_path: Path,
    output_dir: Path,
) -> InjectedBugResult:
    """
    Correlate pre-computed test results in output_dir/test_results.json
    against the corpus.

    AC-9 gate is caller-responsibility (Q1a): runner calls validate_corpus
    at sweep start for fail-fast; this scorer does NOT re-validate per run.
    If a caller skips validate_corpus, detection ratios over a tiny corpus
    will be meaningless — that's a caller contract, documented here loudly.

    Reads:  output_dir/test_results.json  {"failed_tests": [...]}
    Writes: output_dir/injected_bugs_detail.jsonl  (one JSON line per bug)
    AC-17 fail-closed: missing or malformed test_results.json returns an
    InjectedBugResult with error set, never raises to the caller.
    """
    corpus = load_corpus(corpus_path)
    detail_file = output_dir / "injected_bugs_detail.jsonl"

    results_file = output_dir / "test_results.json"
    try:
        test_results = json.loads(results_file.read_text())
    except FileNotFoundError:
        return InjectedBugResult(
            corpus_size=len(corpus.bugs),
            detections=0,
            detail_file=detail_file,
            error="test_results_missing",
            tool_name=None,
        )
    except json.JSONDecodeError:
        return InjectedBugResult(
            corpus_size=len(corpus.bugs),
            detections=0,
            detail_file=detail_file,
            error="test_results_malformed",
            tool_name=None,
        )

    failed_tests: set[str] = set(test_results.get("failed_tests", []))

    detail_lines: list[str] = []
    detections = 0
    for bug in corpus.bugs:
        # failing order preserves bug.detectable_by (corpus YAML order), not test execution order
        failing = [t for t in bug.detectable_by if t in failed_tests]
        detected = bool(failing)
        if detected:
            detections += 1
        detail_lines.append(json.dumps({
            "bug_id": bug.bug_id,
            "detected": detected,
            "failing_tests": failing,
        }))

    detail_file.write_text("".join(line + "\n" for line in detail_lines))

    return InjectedBugResult(
        corpus_size=len(corpus.bugs),
        detections=detections,
        detail_file=detail_file,
        error=None,
        tool_name=None,
    )
