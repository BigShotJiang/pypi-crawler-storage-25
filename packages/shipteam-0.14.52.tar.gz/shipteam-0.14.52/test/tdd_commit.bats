#!/usr/bin/env bats
# ============================================================================
# Tests for tdd-commit.sh
# ============================================================================

setup() {
    load 'test_helper'
    _common_setup
}

# Helper: create an isolated repo + bare remote pair.
# Exports WORKDIR (working repo), REMOTE (bare remote), both under BATS_TEST_TMPDIR.
_make_repo_with_remote() {
    REMOTE=$(mktemp -d "$BATS_TEST_TMPDIR/remote.XXXXXX")
    WORKDIR=$(mktemp -d "$BATS_TEST_TMPDIR/work.XXXXXX")
    git init --bare -q -b main "$REMOTE"

    cp -R "$PROJECT_ROOT"/scripts "$WORKDIR/"
    cp -R "$PROJECT_ROOT"/config "$WORKDIR/"

    (
        cd "$WORKDIR"
        git init -q -b main
        git config user.email "test@example.com"
        git config user.name "Test"
        git remote add origin "$REMOTE"
        echo "seed" > README.md
        git add README.md
        git commit -q -m "seed"
        git push -q -u origin main
    )
}

@test "shows help with no arguments" {
    run bash "$PROJECT_ROOT/scripts/tdd-commit.sh" 2>&1
    assert_output --partial "TDD Commit Helper"
}

@test "rejects invalid phase" {
    run bash "$PROJECT_ROOT/scripts/tdd-commit.sh" "invalid" "test message" 2>&1
    assert_output --partial "Invalid phase"
}

@test "accepts alias 'r' for red" {
    run bash "$PROJECT_ROOT/scripts/tdd-commit.sh" "r" "test" 2>&1
    assert_output --partial "TDD Commit:"
}

@test "accepts alias 'g' for green" {
    run bash "$PROJECT_ROOT/scripts/tdd-commit.sh" "g" "test" 2>&1
    assert_output --partial "TDD Commit:"
}

@test "accepts alias 'ref' for refactor" {
    run bash "$PROJECT_ROOT/scripts/tdd-commit.sh" "ref" "test" 2>&1
    assert_output --partial "TDD Commit:"
}

@test "red phase correctly identified" {
    run bash "$PROJECT_ROOT/scripts/tdd-commit.sh" "red" "my test message" 2>&1
    assert_output --partial "red phase"
}

# ---------------------------------------------------------------------------
# Auto-push on first commit of non-session branch without upstream
# Covers AC-4 (happy path), AC-5 (session skip), AC-6 (upstream-set skip),
# AC-7 (fail-open on push error). See `.sherlock-plan.md` / `.test-matrix.md`.
# ---------------------------------------------------------------------------

@test "AC-4 T-7: auto-push on first commit of non-session branch with no upstream (P0)" {
    _make_repo_with_remote
    cd "$WORKDIR"
    git checkout -q -b feature/auto-push-demo
    echo "change" > feature.txt
    git add feature.txt

    run bash "$WORKDIR/scripts/tdd-commit.sh" red "first commit on feature branch" 2>&1
    assert_success
    assert_output --partial "pushing to origin"

    # Upstream should now be set
    run git -C "$WORKDIR" rev-parse --abbrev-ref --symbolic-full-name '@{u}'
    assert_success
    assert_output "origin/feature/auto-push-demo"

    # Remote should have the branch
    run git -C "$REMOTE" branch --list feature/auto-push-demo
    assert_output --partial "feature/auto-push-demo"
}

@test "AC-4 T-8: confirmation output mentions both the push and the branch (P1)" {
    _make_repo_with_remote
    cd "$WORKDIR"
    git checkout -q -b fix/audit-output
    echo "change" > f.txt
    git add f.txt

    run bash "$WORKDIR/scripts/tdd-commit.sh" red "message" 2>&1
    assert_success
    # Both tokens must be present — "fix/audit-output" alone would pass even
    # without auto-push logic because tdd-commit echoes the current branch
    # in other places.
    assert_output --partial "pushing to origin"
    assert_output --partial "fix/audit-output"
}

@test "AC-5 T-9: session/* branch is exempt from auto-push (P0)" {
    _make_repo_with_remote
    cd "$WORKDIR"
    git checkout -q -b session/claude-20260419-120000
    echo "throwaway" > s.txt
    git add s.txt

    run bash "$WORKDIR/scripts/tdd-commit.sh" red "session throwaway" 2>&1
    assert_success
    refute_output --partial "pushing to origin"

    # Upstream must NOT have been set for disposable session branches
    run git -C "$WORKDIR" rev-parse --abbrev-ref --symbolic-full-name '@{u}'
    assert_failure

    # Remote must NOT have the branch
    run git -C "$REMOTE" branch --list "session/claude-20260419-120000"
    assert_output ""

    # And the commit itself was actually made (belt-and-suspenders — skipping
    # push must not come from skipping everything).
    run git -C "$WORKDIR" log --format=%s -n 1
    assert_output --partial "session throwaway"
}

@test "AC-5 T-10: session/claude-*-slug variant still exempt (P1)" {
    _make_repo_with_remote
    cd "$WORKDIR"
    git checkout -q -b session/claude-20260419-120000-sentinel-fix
    echo "x" > m.txt
    git add m.txt

    run bash "$WORKDIR/scripts/tdd-commit.sh" red "memo slug session" 2>&1
    assert_success
    refute_output --partial "pushing to origin"

    run git -C "$REMOTE" branch --list "session/claude-20260419-120000-sentinel-fix"
    assert_output ""
}

@test "AC-6 T-11: branch with upstream already set skips auto-push (P0)" {
    _make_repo_with_remote
    cd "$WORKDIR"
    # Create and push the feature branch once manually so upstream is set.
    git checkout -q -b feature/already-tracking
    echo "base" > a.txt
    git add a.txt
    git commit -q -m "base"
    git push -q -u origin feature/already-tracking

    # Now a new commit on the same branch — tdd-commit should NOT announce a push.
    echo "second" > b.txt
    git add b.txt

    run bash "$WORKDIR/scripts/tdd-commit.sh" red "second commit" 2>&1
    assert_success
    refute_output --partial "pushing to origin"
}

@test "AC-7 T-12: auto-push failure does not block the commit (P0)" {
    _make_repo_with_remote
    cd "$WORKDIR"
    # Point origin at a nonexistent path so the push fails
    git remote set-url origin "/this/path/does/not/exist/$(date +%s)"

    git checkout -q -b feature/fail-open-demo
    echo "safe" > f.txt
    git add f.txt

    run bash "$WORKDIR/scripts/tdd-commit.sh" red "should survive push failure" 2>&1
    assert_success
    assert_output --partial "WARNING"

    # Commit must exist locally even though push failed
    run git -C "$WORKDIR" log --format=%s -n 1
    assert_output --partial "should survive push failure"

    # Hash stability: capture HEAD now, re-stat after the assertion, assert no
    # drift. Catches a hypothetical buggy implementation that amends or resets
    # the commit on push failure — the message oracle alone cannot distinguish
    # "commit preserved" from "commit rolled back + re-created".
    post_hash=$(git -C "$WORKDIR" rev-parse HEAD)
    run git -C "$WORKDIR" rev-parse HEAD
    assert_output "$post_hash"
    # And the commit is reachable from HEAD (not orphaned by a reset)
    run git -C "$WORKDIR" log --format=%H -n 1
    assert_output "$post_hash"
}

@test "AC-7 T-13: push failure warning goes to stderr, not stdout (P1)" {
    _make_repo_with_remote
    cd "$WORKDIR"
    git remote set-url origin "/also/does/not/exist/$(date +%s)"

    git checkout -q -b feature/stderr-check
    echo "x" > f.txt
    git add f.txt

    # Capture stdout and stderr to separate files so we can assert both
    # presence on stderr AND absence on stdout.
    bash -c "bash '$WORKDIR/scripts/tdd-commit.sh' red 'msg' >'$BATS_TEST_TMPDIR/stdout.log' 2>'$BATS_TEST_TMPDIR/stderr.log'"
    run cat "$BATS_TEST_TMPDIR/stderr.log"
    assert_output --partial "WARNING"
    # WARNING must not bleed onto stdout
    run cat "$BATS_TEST_TMPDIR/stdout.log"
    refute_output --partial "WARNING"
}

@test "detached HEAD skips auto-push silently (gap coverage)" {
    # Review L-1: detached HEAD returns empty `git branch --show-current`;
    # the script's `[ -n "$_current_branch" ]` guard correctly short-circuits.
    # Lock in the behavior so it cannot regress if branch-name detection is
    # ever refactored to something that returns "HEAD" on detach.
    _make_repo_with_remote
    cd "$WORKDIR"
    _sha=$(git rev-parse HEAD)
    git checkout -q --detach "$_sha"
    echo "x" > d.txt
    git add d.txt

    run bash "$WORKDIR/scripts/tdd-commit.sh" red "detached head commit" 2>&1
    assert_success
    refute_output --partial "pushing to origin"
    refute_output --partial "WARNING"
}
