#!/usr/bin/env bash
# Regression test for framework content invariants (lenses + upgraded /deep-r + /deep-r-audit).
# Pure structural assertions — does not test prose quality.

set -euo pipefail

fail() { echo "FAIL: $*" >&2; exit 1; }
pass() { echo "PASS: $*"; }

ROOT="$(cd "$(dirname "$0")/.." && pwd)"

assert_file() {
  [[ -f "$ROOT/$1" ]] || fail "missing file: $1"
}

assert_section() {
  grep -q "$2" "$ROOT/$1" || fail "missing section '$2' in $1"
}

# --- Lenses exist and have the 5 required sections ---
LENSES=(hot-path-latency failure-domain-isolation fit-for-purpose explicit-tradeoff)
assert_file ".claude/lenses/README.md"
for l in "${LENSES[@]}"; do
  assert_file ".claude/lenses/${l}.md"
  for section in "When to apply" "Core question it forces" "Anti-patterns it catches" "Past failure it would have prevented"; do
    assert_section ".claude/lenses/${l}.md" "## ${section}"
  done
done
pass "lenses present with required sections"

# --- Lens count cap: no more than 8 non-README lens files ---
LENS_COUNT=$(find "$ROOT/.claude/lenses" -maxdepth 1 -name '*.md' ! -name 'README.md' | wc -l | tr -d ' ')
[[ "$LENS_COUNT" -le 8 ]] || fail "lens count ($LENS_COUNT) exceeds cap of 8 — retire unused lenses before adding more"
pass "lens count within cap ($LENS_COUNT/8)"

# --- Upgraded /deep-r has the three mandatory sections ---
assert_file ".claude/skills/deep-r/SKILL.md"
assert_section ".claude/skills/deep-r/SKILL.md" "MANDATORY Step: Adversarial Search Pass"
assert_section ".claude/skills/deep-r/SKILL.md" "MANDATORY Step: Pre-Mortem for Safety Infrastructure"
assert_section ".claude/skills/deep-r/SKILL.md" "MANDATORY Step: Lens Consultation"
pass "/deep-r has three mandatory sections"

# --- /deep-r-audit sibling exists with distinct description ---
assert_file ".claude/skills/deep-r-audit/SKILL.md"
assert_section ".claude/skills/deep-r-audit/SKILL.md" "Audit Protocol"
assert_section ".claude/skills/deep-r-audit/SKILL.md" "Enumerate Primitives In Use"
assert_section ".claude/skills/deep-r-audit/SKILL.md" "Adversarial Upstream Search"
pass "/deep-r-audit present with audit protocol"

# --- Frontmatter descriptions are distinct (not clones) ---
DEEP_R_DESC=$(sed -n 's/^description: //p' "$ROOT/.claude/skills/deep-r/SKILL.md" | head -1)
AUDIT_DESC=$(sed -n 's/^description: //p' "$ROOT/.claude/skills/deep-r-audit/SKILL.md" | head -1)
[[ "$DEEP_R_DESC" != "$AUDIT_DESC" ]] || fail "/deep-r and /deep-r-audit have identical descriptions"
pass "skill descriptions are distinct"

# --- fw-manifest registers the new files ---
MANIFEST="$ROOT/config/fw-manifest.yaml"
for needle in ".claude/lenses/README.md" ".claude/lenses/hot-path-latency.md" ".claude/skills/deep-r/SKILL.md" ".claude/skills/deep-r-audit/SKILL.md"; do
  grep -q "$needle" "$MANIFEST" || fail "fw-manifest missing entry: $needle"
done
pass "fw-manifest registers new content"

echo "ALL CHECKS PASSED"
