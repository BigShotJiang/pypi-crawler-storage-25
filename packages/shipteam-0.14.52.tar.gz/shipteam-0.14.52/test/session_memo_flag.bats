#!/usr/bin/env bats
# ============================================================================
# Tests for claude-session.sh -m/--memo flag (meaningful session branch names)
# ============================================================================
# Exercises arg-parsing, memo validation, and BRANCH_NAME computation using
# the --print-branch-name testability hook, which exits before any worktree
# or process side effects. Pairs with worktree_bootstrap.bats which covers
# the bootstrap functions downstream of this logic.
# ============================================================================

setup() {
    load 'test_helper'
    _common_setup
    SESSION_SCRIPT="$PROJECT_ROOT/scripts/claude-session.sh"
}

@test "memo short flag appends slug to auto-generated branch name" {
    run bash "$SESSION_SCRIPT" -m sentinel-fix --print-branch-name
    [ "$status" -eq 0 ]
    [[ "$output" =~ ^session/claude-[0-9]{8}-[0-9]{6}-sentinel-fix$ ]]
}

@test "memo long flag accepts --memo SLUG" {
    run bash "$SESSION_SCRIPT" --memo my-slug --print-branch-name
    [ "$status" -eq 0 ]
    [[ "$output" =~ ^session/claude-[0-9]{8}-[0-9]{6}-my-slug$ ]]
}

@test "no memo falls back to timestamp-only branch name" {
    run bash "$SESSION_SCRIPT" --print-branch-name
    [ "$status" -eq 0 ]
    [[ "$output" =~ ^session/claude-[0-9]{8}-[0-9]{6}$ ]]
}

@test "explicit branch name takes precedence and ignores memo shape" {
    run bash "$SESSION_SCRIPT" feature/x --print-branch-name
    [ "$status" -eq 0 ]
    [ "$output" = "feature/x" ]
}

@test "memo rejects uppercase characters" {
    run bash "$SESSION_SCRIPT" -m Evil --print-branch-name
    [ "$status" -eq 1 ]
    [[ "$output" =~ "lowercase alphanumeric" ]]
}

@test "memo rejects shell metacharacters" {
    run bash "$SESSION_SCRIPT" -m 'x$(evil)' --print-branch-name
    [ "$status" -eq 1 ]
    [[ "$output" =~ "lowercase alphanumeric" ]]
}

@test "memo rejects path separators" {
    run bash "$SESSION_SCRIPT" -m foo/bar --print-branch-name
    [ "$status" -eq 1 ]
    [[ "$output" =~ "lowercase alphanumeric" ]]
}

@test "memo rejects values longer than 40 characters" {
    local long_slug
    long_slug=$(printf 'a%.0s' {1..41})
    run bash "$SESSION_SCRIPT" -m "$long_slug" --print-branch-name
    [ "$status" -eq 1 ]
    [[ "$output" =~ "lowercase alphanumeric" ]]
}

@test "memo rejects trailing hyphen" {
    run bash "$SESSION_SCRIPT" -m abc- --print-branch-name
    [ "$status" -eq 1 ]
    [[ "$output" =~ "lowercase alphanumeric" ]]
}

@test "memo accepts internal hyphens" {
    run bash "$SESSION_SCRIPT" -m a-b-c --print-branch-name
    [ "$status" -eq 0 ]
    [[ "$output" =~ -a-b-c$ ]]
}

@test "memo accepts single-character slug" {
    run bash "$SESSION_SCRIPT" -m x --print-branch-name
    [ "$status" -eq 0 ]
    [[ "$output" =~ -x$ ]]
}

@test "memo accepts exactly 40-character slug at boundary" {
    local boundary_slug
    boundary_slug=$(printf 'a%.0s' {1..40})
    run bash "$SESSION_SCRIPT" -m "$boundary_slug" --print-branch-name
    [ "$status" -eq 0 ]
    [[ "$output" =~ -${boundary_slug}$ ]]
}

@test "memo flag without value errors with clear message" {
    run bash "$SESSION_SCRIPT" -m --print-branch-name
    [ "$status" -eq 1 ]
    [[ "$output" =~ "requires a slug argument" ]]
}

@test "memo combined with explicit branch name is a usage error" {
    run bash "$SESSION_SCRIPT" -m slug feature/x --print-branch-name
    [ "$status" -eq 1 ]
    [[ "$output" =~ "mutually exclusive" ]]
}

@test "help text documents the memo flag" {
    run bash "$SESSION_SCRIPT" --help
    [ "$status" -eq 0 ]
    [[ "$output" =~ "-m, --memo SLUG" ]]
}
