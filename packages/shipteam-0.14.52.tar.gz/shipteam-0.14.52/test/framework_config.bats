#!/usr/bin/env bats
# ============================================================================
# Tests for _framework.sh config parsing
# ============================================================================

setup() {
    load 'test_helper'
    _common_setup
    cd "$PROJECT_ROOT"
    source scripts/_framework.sh
}

# ── fw_get: simple values ──────────────────────────────────────────────────

@test "project.name is non-empty" {
    result=$(fw_get_nested "project.name")
    [ -n "$result" ]
}

@test "project.repo has org/repo format" {
    result=$(fw_get_nested "project.repo")
    [[ "$result" == */* ]]
}

@test "project.description is non-empty" {
    result=$(fw_get_nested "project.description")
    [ -n "$result" ]
}

# ── fw_get_nested: dotted paths (AC-1 fixture-based round-trip) ────────────
# Tests read values from an isolated fixture framework.yaml so the reader is
# proven correct regardless of the host repo's actual stack configuration.

_fixture_repo() {
    # $1 = root dir. Initializes as git repo with known-stack framework.yaml.
    local root="$1"
    mkdir -p "$root/config"
    git -c init.defaultBranch=main init -q "$root"
    cat > "$root/config/framework.yaml" <<'EOF'
stack:
  backend:
    language: ruby
    port: 4567
  frontend:
    language: rescript
    port: 7890
EOF
}

_fixture_read() {
    # $1 = fixture root, $2 = nested key. Reads via isolated subshell.
    # Key is passed as positional arg to avoid bash -c string-interpolation injection.
    # FW_ROOT_OVERRIDE=1: this fixture-read helper deliberately points at a
    # test-tmpdir fixture that differs from the script location. Without the
    # override, the cross-worktree guard in _framework.sh would rewrite
    # FW_PROJECT_ROOT back to the project root and defeat the test.
    FW_PROJECT_ROOT="$1" FW_ROOT_OVERRIDE=1 FW_SKIP_PREREQ_CHECK=1 FW_FW_DIR="$PROJECT_ROOT" \
        bash -c 'unset FW_CONFIG; source "$FW_FW_DIR/scripts/_framework.sh" && fw_get_nested "$1"' \
        -- "$2"
}

@test "AC-1: reads stack.backend.language from fixture (not hardcoded)" {
    _fixture_repo "$BATS_TEST_TMPDIR"
    result=$(_fixture_read "$BATS_TEST_TMPDIR" "stack.backend.language")
    [ "$result" = "ruby" ]
}

@test "AC-1: reads stack.backend.port from fixture (not hardcoded)" {
    _fixture_repo "$BATS_TEST_TMPDIR"
    result=$(_fixture_read "$BATS_TEST_TMPDIR" "stack.backend.port")
    [ "$result" = "4567" ]
}

@test "AC-1: reads stack.frontend.language from fixture (not hardcoded)" {
    _fixture_repo "$BATS_TEST_TMPDIR"
    result=$(_fixture_read "$BATS_TEST_TMPDIR" "stack.frontend.language")
    [ "$result" = "rescript" ]
}

@test "AC-1: reads stack.frontend.port from fixture (not hardcoded)" {
    _fixture_repo "$BATS_TEST_TMPDIR"
    result=$(_fixture_read "$BATS_TEST_TMPDIR" "stack.frontend.port")
    [ "$result" = "7890" ]
}

@test "reads notifications.provider" {
    result=$(fw_get_nested "notifications.provider")
    [ "$result" = "none" ]
}

@test "reads claude.session_timeout" {
    result=$(fw_get_nested "claude.session_timeout")
    [ "$result" = "1800" ]
}

# ── defaults for missing keys ──────────────────────────────────────────────

@test "missing key returns default" {
    result=$(fw_get_nested "nonexistent.key" "default_value")
    [ "$result" = "default_value" ]
}

@test "missing nested key returns default" {
    result=$(fw_get_nested "stack.backend.nonexistent" "fallback")
    [ "$result" = "fallback" ]
}

@test "fw_get missing returns default" {
    result=$(fw_get "totally_missing" "my_default")
    [ "$result" = "my_default" ]
}

# ── fw_resolve_path ────────────────────────────────────────────────────────

@test "expands \${HOME}" {
    result=$(fw_resolve_path '${HOME}/worktrees')
    [ "$result" = "$HOME/worktrees" ]
}

@test "expands \$HOME" {
    result=$(fw_resolve_path '$HOME/projects')
    [ "$result" = "$HOME/projects" ]
}

@test "expands ~/" {
    result=$(fw_resolve_path '~/code')
    [ "$result" = "$HOME/code" ]
}

@test "expands bare ~" {
    result=$(fw_resolve_path '~')
    [ "$result" = "$HOME" ]
}

@test "preserves absolute path" {
    result=$(fw_resolve_path '/absolute/path')
    [ "$result" = "/absolute/path" ]
}

# ── fw_require ─────────────────────────────────────────────────────────────

@test "fw_require succeeds for existing keys" {
    run bash -c "cd '$PROJECT_ROOT' && source scripts/_framework.sh && fw_require 'project.name' 'project.repo'"
    assert_success
}

@test "fw_require fails for missing key" {
    run bash -c "cd '$PROJECT_ROOT' && source scripts/_framework.sh && fw_require 'nonexistent.key' 2>/dev/null"
    assert_failure
}

# ── fw_get_list ────────────────────────────────────────────────────────────

@test "blocking_jobs contains backend-tests" {
    result=$(fw_get_list "ci.blocking_jobs")
    echo "$result" | grep -qF "backend-tests"
}

@test "blocking_jobs contains frontend-tests" {
    result=$(fw_get_list "ci.blocking_jobs")
    echo "$result" | grep -qF "frontend-tests"
}

@test "advisory_jobs contains docs-validation" {
    result=$(fw_get_list "ci.advisory_jobs")
    echo "$result" | grep -qF "docs-validation"
}

@test "protected_branches contains main" {
    result=$(fw_get_list "ci.protected_branches")
    echo "$result" | grep -qF "main"
}

# ── sedi (cross-platform sed) ──────────────────────────────────────────────

@test "sedi replaces in-place" {
    TMPFILE=$(mktemp)
    echo "version: 1.0.0" > "$TMPFILE"
    sedi 's/1.0.0/2.0.0/' "$TMPFILE"
    result=$(cat "$TMPFILE")
    rm -f "$TMPFILE"
    [ "$result" = "version: 2.0.0" ]
}

# ── FW_PROJECT_ROOT ────────────────────────────────────────────────────────

@test "FW_PROJECT_ROOT is set" {
    [ -n "$FW_PROJECT_ROOT" ]
}

@test "FW_PROJECT_ROOT matches project root" {
    [ "$FW_PROJECT_ROOT" = "$PROJECT_ROOT" ]
}

@test "framework.yaml exists at FW_PROJECT_ROOT" {
    assert_file_exists "$FW_PROJECT_ROOT/config/framework.yaml"
}

# ── Versioning config ─────────────────────────────────────────────────────

@test "versioning.primary_source is VERSION" {
    result=$(fw_get_nested "versioning.primary_source")
    [ "$result" = "VERSION" ]
}

# ── AC-2: env-var override safety (fail-closed against path traversal) ─────

@test "AC-2a: pre-set FW_PROJECT_ROOT (valid git repo) is preserved after source" {
    _fixture_repo "$BATS_TEST_TMPDIR"
    result=$(FW_PROJECT_ROOT="$BATS_TEST_TMPDIR" FW_ROOT_OVERRIDE=1 FW_SKIP_PREREQ_CHECK=1 \
        bash -c "unset FW_CONFIG; source '$PROJECT_ROOT/scripts/_framework.sh' && echo \"\$FW_PROJECT_ROOT\"")
    # realpath may canonicalize /var -> /private/var on macOS; use realpath of both sides
    expected=$(python3 -c "import os,sys; print(os.path.realpath(sys.argv[1]))" "$BATS_TEST_TMPDIR")
    [ "$result" = "$expected" ]
}

@test "AC-2b: FW_PROJECT_ROOT outside any git repo causes non-zero exit" {
    # Create a dir WITHOUT .git — must be rejected
    mkdir -p "$BATS_TEST_TMPDIR/no-git-here/config"
    cat > "$BATS_TEST_TMPDIR/no-git-here/config/framework.yaml" <<EOF
project:
  name: test
EOF
    run env FW_PROJECT_ROOT="$BATS_TEST_TMPDIR/no-git-here" FW_ROOT_OVERRIDE=1 FW_SKIP_PREREQ_CHECK=1 \
        bash -c "unset FW_CONFIG; source '$PROJECT_ROOT/scripts/_framework.sh'"
    assert_failure
    assert_output --partial "not a git repo root"
}

@test "AC-2c: FW_CONFIG pointing outside FW_PROJECT_ROOT causes non-zero exit" {
    # Use a sibling dir inside BATS_TEST_TMPDIR so bats auto-cleanup handles it.
    repo="$BATS_TEST_TMPDIR/repo"
    outside="$BATS_TEST_TMPDIR/outside"
    mkdir -p "$outside"
    _fixture_repo "$repo"
    outside_cfg="$outside/outside-framework.yaml"
    echo "project: {name: attacker}" > "$outside_cfg"
    run env FW_PROJECT_ROOT="$repo" FW_CONFIG="$outside_cfg" FW_ROOT_OVERRIDE=1 FW_SKIP_PREREQ_CHECK=1 \
        bash -c "source '$PROJECT_ROOT/scripts/_framework.sh'"
    assert_failure
    assert_output --partial "outside FW_PROJECT_ROOT"
}

@test "AC-2d: FW_CONFIG is a symlink escaping repo root causes non-zero exit" {
    repo="$BATS_TEST_TMPDIR/repo"
    external="$BATS_TEST_TMPDIR/external.yaml"
    _fixture_repo "$repo"
    echo "project: {name: external}" > "$external"
    # Overwrite the fixture yaml with a symlink escaping the repo
    rm -f "$repo/config/framework.yaml"
    ln -s "$external" "$repo/config/framework.yaml"
    run env FW_PROJECT_ROOT="$repo" FW_ROOT_OVERRIDE=1 FW_SKIP_PREREQ_CHECK=1 \
        bash -c "unset FW_CONFIG; source '$PROJECT_ROOT/scripts/_framework.sh'"
    assert_failure
    assert_output --partial "outside FW_PROJECT_ROOT"
}

@test "AC-2e: non-existent FW_PROJECT_ROOT causes non-zero exit" {
    run env FW_PROJECT_ROOT="$BATS_TEST_TMPDIR/does-not-exist" FW_ROOT_OVERRIDE=1 FW_SKIP_PREREQ_CHECK=1 \
        bash -c "unset FW_CONFIG; source '$PROJECT_ROOT/scripts/_framework.sh'"
    assert_failure
    assert_output --partial "does not resolve to an existing directory"
}
