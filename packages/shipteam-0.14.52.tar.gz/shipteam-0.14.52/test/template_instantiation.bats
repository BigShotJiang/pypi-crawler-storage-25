#!/usr/bin/env bats
# ============================================================================
# End-to-end template instantiation tests
# ============================================================================
# Validates the framework works as a template: scripts executable, syntax OK,
# hooks compile, no hardcoded paths, no project-specific refs, docs complete.
# ============================================================================

setup() {
    load 'test_helper'
    _common_setup
    cd "$PROJECT_ROOT"
}

# ── Script executability ───────────────────────────────────────────────────

@test "all scripts/*.sh are executable" {
    local non_exec=()
    for script in "$PROJECT_ROOT"/scripts/*.sh; do
        [ -x "$script" ] || non_exec+=("$(basename "$script")")
    done
    if [ ${#non_exec[@]} -gt 0 ]; then
        echo "Non-executable: ${non_exec[*]}" >&2
        return 1
    fi
}

# ── Shell syntax ───────────────────────────────────────────────────────────

@test "all scripts/*.sh pass syntax check" {
    local bad=()
    for script in "$PROJECT_ROOT"/scripts/*.sh; do
        bash -n "$script" 2>/dev/null || bad+=("$(basename "$script")")
    done
    if [ ${#bad[@]} -gt 0 ]; then
        echo "Syntax errors: ${bad[*]}" >&2
        return 1
    fi
}

# ── Python hooks compile ──────────────────────────────────────────────────

@test "all Python hooks compile" {
    local bad=()
    for hook in "$PROJECT_ROOT"/.claude/hooks/*.py; do
        python3 -m py_compile "$hook" 2>/dev/null || bad+=("$(basename "$hook")")
    done
    if [ ${#bad[@]} -gt 0 ]; then
        echo "Compile errors: ${bad[*]}" >&2
        return 1
    fi
}

# ── No hardcoded personal paths ────────────────────────────────────────────

@test "no /Users/ paths in source files" {
    local hits
    hits=$(grep -rn "/Users/" --include="*.sh" --include="*.py" --include="*.yaml" --include="*.yml" --include="*.json" --include="*.md" "$PROJECT_ROOT" 2>/dev/null \
        | grep -v ".git/" | grep -v "node_modules/" | grep -v "/test/" | grep -v "template_instantiation" | grep -v ".sherlock-plan" | grep -v ".claude/state/" || true)
    [ -z "$hits" ]
}

# ── No project-specific references ─────────────────────────────────────────

@test "no ai-ats-sim references" {
    local hits
    hits=$(grep -rn "ai-ats-sim" --include="*.sh" --include="*.py" --include="*.yaml" --include="*.yml" --include="*.json" --include="*.md" "$PROJECT_ROOT" 2>/dev/null \
        | grep -v ".git/" | grep -v "/test/" | grep -v "template_instantiation" | grep -v ".sherlock-plan" || true)
    [ -z "$hits" ]
}

@test "no Resume Boost references" {
    local hits
    hits=$(grep -rn "Resume Boost" --include="*.sh" --include="*.py" --include="*.yaml" --include="*.yml" --include="*.json" --include="*.md" "$PROJECT_ROOT" 2>/dev/null \
        | grep -v ".git/" | grep -v "/test/" | grep -v "template_instantiation" | grep -v ".sherlock-plan" || true)
    [ -z "$hits" ]
}

@test "no jasontofte references (except FUNDING.yml and .gitmodules)" {
    local hits
    hits=$(grep -rn "jasontofte" --include="*.sh" --include="*.py" --include="*.yaml" --include="*.yml" --include="*.json" --include="*.md" "$PROJECT_ROOT" 2>/dev/null \
        | grep -v ".git/" | grep -v "/test/" | grep -v "template_instantiation" | grep -v ".sherlock-plan" | grep -v "FUNDING.yml" | grep -v ".gitmodules" | grep -v ".claude/state/" || true)
    [ -z "$hits" ]
}

@test "no DeployKits references" {
    local hits
    hits=$(grep -rn "DeployKits" --include="*.sh" --include="*.py" --include="*.yaml" --include="*.yml" --include="*.json" --include="*.md" "$PROJECT_ROOT" 2>/dev/null \
        | grep -v ".git/" | grep -v "/test/" | grep -v "template_instantiation" | grep -v ".sherlock-plan" || true)
    [ -z "$hits" ]
}

@test "no threat model files in repo" {
    local hits
    hits=$(find "$PROJECT_ROOT" -name "*THREAT-MODEL*" -o -name "*threat-model*" 2>/dev/null | grep -v ".git/" | grep -v ".gitignore" || true)
    [ -z "$hits" ]
}

# ── Config parsing ─────────────────────────────────────────────────────────

@test "framework.yaml project.name is readable" {
    source "$PROJECT_ROOT/scripts/_framework.sh"
    result=$(fw_get_nested "project.name")
    [ -n "$result" ]
}

@test "framework.yaml project.repo is readable" {
    source "$PROJECT_ROOT/scripts/_framework.sh"
    result=$(fw_get_nested "project.repo")
    [ -n "$result" ]
}

# ── Documentation structure ────────────────────────────────────────────────

@test "CLAUDE.md exists" { assert_file_exists "$PROJECT_ROOT/CLAUDE.md"; }
@test "README.md exists" { assert_file_exists "$PROJECT_ROOT/README.md"; }
@test "SETUP.md exists" { assert_file_exists "$PROJECT_ROOT/SETUP.md"; }
@test "release_notes.md exists" { assert_file_exists "$PROJECT_ROOT/release_notes.md"; }
@test "docs/00-README.md exists" { assert_file_exists "$PROJECT_ROOT/docs/00-README.md"; }
@test "docs/10-ARCHITECTURE.md exists" { assert_file_exists "$PROJECT_ROOT/docs/10-ARCHITECTURE.md"; }
@test "docs/20-DEPLOYMENT.md exists" { assert_file_exists "$PROJECT_ROOT/docs/20-DEPLOYMENT.md"; }
@test "docs/35-SECURITY.md exists" { assert_file_exists "$PROJECT_ROOT/docs/35-SECURITY.md"; }
@test "docs/50-TESTING.md exists" { assert_file_exists "$PROJECT_ROOT/docs/50-TESTING.md"; }
@test "docs/60-FEATURES.md exists" { assert_file_exists "$PROJECT_ROOT/docs/60-FEATURES.md"; }
@test "docs/70-INSIGHTS.md exists" { assert_file_exists "$PROJECT_ROOT/docs/70-INSIGHTS.md"; }

# ── Required framework files ──────────────────────────────────────────────

@test "config/framework.yaml exists" { assert_file_exists "$PROJECT_ROOT/config/framework.yaml"; }
@test "config/secret-guard-allowlist.yaml exists" { assert_file_exists "$PROJECT_ROOT/config/secret-guard-allowlist.yaml"; }
@test "FRAMEWORK_VERSION exists" { assert_file_exists "$PROJECT_ROOT/FRAMEWORK_VERSION"; }
@test "LICENSE exists" { assert_file_exists "$PROJECT_ROOT/LICENSE"; }
@test ".gitignore exists" { assert_file_exists "$PROJECT_ROOT/.gitignore"; }
@test ".claude/settings.json exists" { assert_file_exists "$PROJECT_ROOT/.claude/settings.json"; }
