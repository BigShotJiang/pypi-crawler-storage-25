#!/usr/bin/env bats
# ============================================================================
# Tests for branch-tracker.py hook
# ============================================================================
# PostToolUse hook that updates expected-branch.txt after git checkout/switch.
# Always exits 0.
# ============================================================================

setup() {
    load 'test_helper'
    _common_setup
    HOOK="$PROJECT_ROOT/.claude/hooks/branch-tracker.py"
}

run_hook() {
    local command="$1"
    local tmpfile="$BATS_TEST_TMPDIR/hook_input.json"
    python3 -c "import json,sys; json.dump({'tool_name':'Bash','tool_input':{'command':sys.argv[1]}}, open(sys.argv[2],'w'))" "$command" "$tmpfile"
    run python3 "$HOOK" < "$tmpfile" 2>/dev/null
}

# ── Always exits 0 ────────────────────────────────────────────────────────

@test "exits 0 for non-checkout command" {
    run_hook "git status"
    assert_success
}

@test "exits 0 for checkout command" {
    run_hook "git checkout main"
    assert_success
}

@test "exits 0 for non-git command" {
    run_hook "ls -la"
    assert_success
}

# ── Outputs tracking info for checkout commands ───────────────────────────

@test "outputs tracking info for git checkout" {
    run_hook "git checkout main"
    assert_success
    assert_output --partial "branch_switch_tracked"
}

@test "outputs tracking info for git switch" {
    run_hook "git switch main"
    assert_success
    assert_output --partial "branch_switch_tracked"
}

@test "no output for non-checkout commands" {
    run_hook "git status"
    assert_success
    refute_output --partial "branch_switch_tracked"
}

# ── Edge cases ─────────────────────────────────────────────────────────────

@test "handles non-Bash tool" {
    local tmpfile="$BATS_TEST_TMPDIR/hook_input.json"
    echo '{"tool_name": "Read", "tool_input": {"file_path": "test.txt"}}' > "$tmpfile"
    run python3 "$HOOK" < "$tmpfile" 2>/dev/null
    assert_success
}

@test "handles malformed JSON" {
    run bash -c "echo 'not json' | python3 '$HOOK' 2>/dev/null"
    assert_success
}
