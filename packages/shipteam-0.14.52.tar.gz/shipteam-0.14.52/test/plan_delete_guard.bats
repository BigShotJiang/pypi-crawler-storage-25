#!/usr/bin/env bats
# Regression tests for scripts/validate-plan-delete-guard.sh
#
# Hazard (prompted this guard): PR #140 was a Sherlock Lite whose Step 8 cleanup
# deleted .sherlock-plan.md and .test-matrix.md even though the Lite produced
# no ADR (which means no "extraction" actually occurred). The plan at repo root
# belonged to a different concurrent Sherlock Full work stream (the v1 benchmark
# harness). This guard blocks that collision: deleting plan/matrix artifacts
# requires a new docs/adr/NNN-*.md added in the same commit.

setup() {
  export TMPDIR="${BATS_TEST_TMPDIR}/plan-guard"
  mkdir -p "$TMPDIR"
  cd "$TMPDIR"
  git init -q
  git config user.email "test@example.com"
  git config user.name "test"
  # Copy the guard script into the fixture so the repo can find it at the
  # expected path (scripts/validate-plan-delete-guard.sh). The real repo's
  # script is the one under test.
  mkdir -p scripts
  cp "${BATS_TEST_DIRNAME}/../scripts/validate-plan-delete-guard.sh" scripts/
  chmod +x scripts/validate-plan-delete-guard.sh
  git add scripts/validate-plan-delete-guard.sh
  git commit -q -m "seed: add guard script"
}

# ---------------------------------------------------------------------------
# T1: Deleting .sherlock-plan.md WITHOUT adding an ADR → exit 1
# ---------------------------------------------------------------------------

@test "T1: deleting .sherlock-plan.md alone is blocked" {
  echo "content" > .sherlock-plan.md
  git add .sherlock-plan.md
  git commit -q -m "seed: add plan"

  git rm -q .sherlock-plan.md
  run ./scripts/validate-plan-delete-guard.sh
  [ "$status" -eq 1 ]
  [[ "$output" == *"BLOCKED"* ]]
  [[ "$output" == *".sherlock-plan.md"* ]]
}

# ---------------------------------------------------------------------------
# T2: Deleting .test-matrix.md alone is also blocked
# ---------------------------------------------------------------------------

@test "T2: deleting .test-matrix.md alone is blocked" {
  echo "content" > .test-matrix.md
  git add .test-matrix.md
  git commit -q -m "seed: add matrix"

  git rm -q .test-matrix.md
  run ./scripts/validate-plan-delete-guard.sh
  [ "$status" -eq 1 ]
  [[ "$output" == *"BLOCKED"* ]]
  [[ "$output" == *".test-matrix.md"* ]]
}

# ---------------------------------------------------------------------------
# T3: Deleting BOTH plan + matrix together, still no ADR → blocked
# ---------------------------------------------------------------------------

@test "T3: deleting both plan AND matrix without ADR is blocked" {
  echo "plan" > .sherlock-plan.md
  echo "matrix" > .test-matrix.md
  git add .sherlock-plan.md .test-matrix.md
  git commit -q -m "seed"

  git rm -q .sherlock-plan.md .test-matrix.md
  run ./scripts/validate-plan-delete-guard.sh
  [ "$status" -eq 1 ]
  [[ "$output" == *"BLOCKED"* ]]
}

# ---------------------------------------------------------------------------
# T4: Deleting plan WITH a new ADR in the same commit → allowed (exit 0)
# ---------------------------------------------------------------------------

@test "T4: plan delete + ADR add is allowed (legitimate Step 8 extraction)" {
  echo "plan" > .sherlock-plan.md
  git add .sherlock-plan.md
  git commit -q -m "seed"

  git rm -q .sherlock-plan.md
  mkdir -p docs/adr
  echo "# ADR-012: Test decision" > docs/adr/012-test-extraction.md
  git add docs/adr/012-test-extraction.md

  run ./scripts/validate-plan-delete-guard.sh
  [ "$status" -eq 0 ]
}

# ---------------------------------------------------------------------------
# T5: Commits not touching plan files pass through unchanged
# ---------------------------------------------------------------------------

@test "T5: commits not touching plan files pass through" {
  echo "unrelated" > unrelated.txt
  git add unrelated.txt
  run ./scripts/validate-plan-delete-guard.sh
  [ "$status" -eq 0 ]
}

# ---------------------------------------------------------------------------
# T6: FW_ALLOW_PLAN_DELETE=1 bypass (for maintainer-vetted ADR-less deletes)
# ---------------------------------------------------------------------------

@test "T6: FW_ALLOW_PLAN_DELETE=1 bypasses the block" {
  echo "plan" > .sherlock-plan.md
  git add .sherlock-plan.md
  git commit -q -m "seed"

  git rm -q .sherlock-plan.md
  FW_ALLOW_PLAN_DELETE=1 run ./scripts/validate-plan-delete-guard.sh
  [ "$status" -eq 0 ]
}

# ---------------------------------------------------------------------------
# T7: ADR filename must match pattern docs/adr/NNN-*.md (3-digit prefix)
# A README or index-only change should not count as an extraction.
# ---------------------------------------------------------------------------

@test "T7: non-numbered docs/adr/ file does NOT satisfy the ADR check" {
  echo "plan" > .sherlock-plan.md
  git add .sherlock-plan.md
  git commit -q -m "seed"

  git rm -q .sherlock-plan.md
  mkdir -p docs/adr
  echo "# README" > docs/adr/README.md
  git add docs/adr/README.md

  run ./scripts/validate-plan-delete-guard.sh
  [ "$status" -eq 1 ]
  [[ "$output" == *"BLOCKED"* ]]
}

# ---------------------------------------------------------------------------
# T8: Deleting plan + MODIFYING (not adding) an existing ADR → blocked
# (A commit that only updates an existing ADR doesn't count as extraction.)
# ---------------------------------------------------------------------------

@test "T8: plan delete + ADR modify (no new ADR file) is blocked" {
  mkdir -p docs/adr
  echo "# existing ADR" > docs/adr/011-existing.md
  echo "plan" > .sherlock-plan.md
  git add docs/adr/011-existing.md .sherlock-plan.md
  git commit -q -m "seed"

  git rm -q .sherlock-plan.md
  echo "# existing ADR v2" > docs/adr/011-existing.md
  git add docs/adr/011-existing.md

  run ./scripts/validate-plan-delete-guard.sh
  [ "$status" -eq 1 ]
  [[ "$output" == *"BLOCKED"* ]]
}
