#!/usr/bin/env bats
# ============================================================================
# Integration tests for fw-sync.sh
# ============================================================================
# Tests CLI argument parsing, validation, and --status/--dry-run modes.
# Uses temp directories to simulate project targets.
# ============================================================================

setup() {
    load 'test_helper'
    _common_setup
    FW_SYNC="$PROJECT_ROOT/scripts/fw-sync.sh"

    # Create a minimal mock project directory
    MOCK_PROJECT="$BATS_TEST_TMPDIR/mock-project"
    mkdir -p "$MOCK_PROJECT/config"
    mkdir -p "$MOCK_PROJECT/.claude/hooks"
    mkdir -p "$MOCK_PROJECT/.claude/rules"
    mkdir -p "$MOCK_PROJECT/.claude/agents"

    # Create minimal framework.yaml so fw-sync recognizes it as a project
    cat > "$MOCK_PROJECT/config/framework.yaml" << 'YAML'
project:
  name: test-project
  repo: test-org/test-project
  description: Test project for fw-sync
stack:
  backend:
    language: python
skills:
  deploy: true
  health: true
hooks:
  deploy_gate: false
YAML
}

# ── CLI validation ─────────────────────────────────────────────────────────

@test "exits 1 with no arguments" {
    run bash "$FW_SYNC" 2>&1
    assert_failure
    assert_output --partial "Usage"
}

@test "exits 1 with unknown option" {
    run bash "$FW_SYNC" "$MOCK_PROJECT" --bogus 2>&1
    assert_failure
    assert_output --partial "Unknown option"
}

@test "exits 1 with nonexistent project dir" {
    run bash "$FW_SYNC" "/nonexistent/dir/xyz" 2>&1
    assert_failure
    assert_output --partial "not found"
}

@test "shows help with --help" {
    run bash "$FW_SYNC" --help 2>&1
    assert_success
    assert_output --partial "fw-sync.sh"
}

# ── Status mode ────────────────────────────────────────────────────────────

@test "--status runs without error on mock project" {
    run bash "$FW_SYNC" "$MOCK_PROJECT" --status --framework-dir "$PROJECT_ROOT" 2>&1
    assert_success
    assert_output --partial "fw-sync"
}

@test "--status shows file status" {
    run bash "$FW_SYNC" "$MOCK_PROJECT" --status --framework-dir "$PROJECT_ROOT" 2>&1
    assert_success
    # Should list files with status indicators
    assert_output --partial "Summary"
}

# ── Dry-run mode ───────────────────────────────────────────────────────────

@test "--dry-run runs without error" {
    run bash "$FW_SYNC" "$MOCK_PROJECT" --dry-run --framework-dir "$PROJECT_ROOT" 2>&1
    assert_success
    assert_output --partial "fw-sync"
}

@test "--dry-run does not create files" {
    # Count files before
    local before
    before=$(find "$MOCK_PROJECT" -type f | wc -l)

    bash "$FW_SYNC" "$MOCK_PROJECT" --dry-run --framework-dir "$PROJECT_ROOT" >/dev/null 2>&1

    # Count files after — should be the same
    local after
    after=$(find "$MOCK_PROJECT" -type f | wc -l)

    [ "$before" -eq "$after" ]
}

# ── Category filter ────────────────────────────────────────────────────────

@test "--category agents filters to agents only" {
    run bash "$FW_SYNC" "$MOCK_PROJECT" --status --category agents --framework-dir "$PROJECT_ROOT" 2>&1
    assert_success
    assert_output --partial "agents"
}

# ── Sync mode (actual sync to temp project) ────────────────────────────────

@test "sync copies new files to project" {
    bash "$FW_SYNC" "$MOCK_PROJECT" --framework-dir "$PROJECT_ROOT" >/dev/null 2>&1

    # After sync, project should have framework files
    [ -f "$MOCK_PROJECT/.claude/rules/anti-patterns.md" ] || \
    [ -f "$MOCK_PROJECT/.claude/rules/security.md" ] || \
    [ -d "$MOCK_PROJECT/.claude/agents" ]
}

@test "sync creates .framework-sync.yaml state file" {
    bash "$FW_SYNC" "$MOCK_PROJECT" --framework-dir "$PROJECT_ROOT" >/dev/null 2>&1
    [ -f "$MOCK_PROJECT/.framework-sync.yaml" ]
}

@test "sync shows summary with counts" {
    run bash "$FW_SYNC" "$MOCK_PROJECT" --framework-dir "$PROJECT_ROOT" 2>&1
    assert_success
    assert_output --partial "Summary"
}

# ── Idempotency ────────────────────────────────────────────────────────────

@test "second sync shows files as up to date" {
    # First sync
    bash "$FW_SYNC" "$MOCK_PROJECT" --framework-dir "$PROJECT_ROOT" >/dev/null 2>&1

    # Second sync should show most files as up to date
    run bash "$FW_SYNC" "$MOCK_PROJECT" --framework-dir "$PROJECT_ROOT" 2>&1
    assert_success
    assert_output --partial "Up to date"
}

# ── Edge cases ─────────────────────────────────────────────────────────────

@test "handles project without .framework-sync.yaml (first sync)" {
    [ ! -f "$MOCK_PROJECT/.framework-sync.yaml" ]
    run bash "$FW_SYNC" "$MOCK_PROJECT" --framework-dir "$PROJECT_ROOT" 2>&1
    assert_success
}
