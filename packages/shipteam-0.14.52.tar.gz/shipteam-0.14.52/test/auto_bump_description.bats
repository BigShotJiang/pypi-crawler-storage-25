#!/usr/bin/env bats
# ============================================================================
# Tests for scripts/clear-version-description.sh and its integration with
# scripts/bump-version.sh.
# ============================================================================
# Covers the auto-version-bump workflow's post-bump description-clear step.
# The workflow calls clear-version-description.sh after bump-version.sh so
# the `## Current Version: X.Y.Z - <description>` line in CLAUDE.md has its
# description tail replaced with "(pending release notes)" — otherwise the
# description drifts (last seen: description for v0.14.13 kept across the
# auto-bumps to v0.14.20, five versions stale).
#
# bump-version.sh itself MUST NOT clear the description — manual feature-PR
# bumps carry an author-written description that needs to survive.
# ============================================================================

setup() {
    load 'test_helper'
    _common_setup
    CLEAR_SCRIPT="$PROJECT_ROOT/scripts/clear-version-description.sh"
}

# Helper: create a minimal tempdir containing CLAUDE.md with a given
# `## Current Version:` line. Echoes the tempdir path.
_make_fixture_dir() {
    local version_line="$1"
    local d
    d=$(mktemp -d)
    printf '# Project\n\n%s\n## Status: STABLE\n' "$version_line" > "$d/CLAUDE.md"
    echo "$d"
}

# ---------------------------------------------------------------------------
# AC-1: Clear sed replaces version AND description
# ---------------------------------------------------------------------------

@test "AC-1 T-1: script replaces both version and description (P0)" {
    d=$(_make_fixture_dir "## Current Version: 0.14.20 - Benchmark Harness v1 Phase 2 Part 1 — Drivers")
    run bash -c "cd '$d' && bash '$CLEAR_SCRIPT' 0.14.21"
    assert_success
    run grep -E '^## Current Version:' "$d/CLAUDE.md"
    assert_output "## Current Version: 0.14.21 - (pending release notes)"
    rm -rf "$d"
}

@test "AC-1 T-2a: description with em-dash and parens is fully replaced (P1)" {
    # Matrix T-2 boundary: "description contains em-dash or parens — full tail still replaced".
    # Real-world example: `0.14.20 - Phase 2 Part 1 — Drivers (beta)`.
    d=$(_make_fixture_dir "## Current Version: 0.14.20 - Phase 2 Part 1 — Drivers (beta)")
    run bash -c "cd '$d' && bash '$CLEAR_SCRIPT' 0.14.21"
    assert_success
    run grep -E '^## Current Version:' "$d/CLAUDE.md"
    assert_output "## Current Version: 0.14.21 - (pending release notes)"
    rm -rf "$d"
}

@test "AC-1 T-2b: script handles multi-digit version segments (P1)" {
    d=$(_make_fixture_dir "## Current Version: 9.99.99 - Old description")
    run bash -c "cd '$d' && bash '$CLEAR_SCRIPT' 10.20.30"
    assert_success
    run grep -E '^## Current Version:' "$d/CLAUDE.md"
    assert_output "## Current Version: 10.20.30 - (pending release notes)"
    rm -rf "$d"
}

# ---------------------------------------------------------------------------
# AC-2: Idempotence — running the script N times produces the same output
# ---------------------------------------------------------------------------

# Helper: count occurrences of "(pending release notes)" on the Current Version
# line. Using `grep -o | wc -l` — a naive `grep -c` only counts matching LINES,
# which would silently pass a compounding "X - (pending...) - (pending...)" bug.
_count_pending_suffix_on_version_line() {
    local file="$1"
    grep '^## Current Version:' "$file" \
        | grep -oE '\(pending release notes\)' \
        | wc -l \
        | tr -d ' '
}

@test "AC-2 T-3: applying script twice produces same final line (P0)" {
    d=$(_make_fixture_dir "## Current Version: 0.14.21 - (pending release notes)")
    run bash -c "cd '$d' && bash '$CLEAR_SCRIPT' 0.14.22"
    assert_success
    run grep -E '^## Current Version:' "$d/CLAUDE.md"
    assert_output "## Current Version: 0.14.22 - (pending release notes)"
    # No compounding on the second application
    count=$(_count_pending_suffix_on_version_line "$d/CLAUDE.md")
    [ "$count" = "1" ]
    rm -rf "$d"
}

@test "AC-2 T-3b: description containing embedded hyphens does not compound (P0)" {
    # Negative-sample from the matrix Oracle Strategy. A naive sed that
    # matched on the first ` - ` separator would produce:
    #   `0.14.22 - (pending release notes) - hyphens - everywhere`
    # The anchored-to-end-of-line pattern prevents this; this test locks it.
    d=$(_make_fixture_dir "## Current Version: 0.14.21 - Fix with - hyphens - everywhere")
    run bash -c "cd '$d' && bash '$CLEAR_SCRIPT' 0.14.22"
    assert_success
    run grep -E '^## Current Version:' "$d/CLAUDE.md"
    assert_output "## Current Version: 0.14.22 - (pending release notes)"
    count=$(_count_pending_suffix_on_version_line "$d/CLAUDE.md")
    [ "$count" = "1" ]
    rm -rf "$d"
}

@test "AC-2 T-4: count invariant — after 5 applications, exactly one '(pending release notes)' suffix (P1)" {
    d=$(_make_fixture_dir "## Current Version: 0.14.20 - Benchmark Harness v1 Phase 2 Part 1 — Drivers")
    for v in 0.14.21 0.14.22 0.14.23 0.14.24 0.14.25; do
        run bash -c "cd '$d' && bash '$CLEAR_SCRIPT' $v"
        assert_success
    done
    # Count occurrences of the suffix (not lines) — catches compounding
    # like `0.14.25 - (pending release notes) - (pending release notes)`.
    count=$(_count_pending_suffix_on_version_line "$d/CLAUDE.md")
    [ "$count" = "1" ]
    # And the version digits are the last one applied.
    run grep -E '^## Current Version:' "$d/CLAUDE.md"
    assert_output "## Current Version: 0.14.25 - (pending release notes)"
    rm -rf "$d"
}

# ---------------------------------------------------------------------------
# AC-3: Manual bump-version.sh path preserves the description.
# The bump-version.sh script uses the digit-only sed pattern from
# config/framework.yaml and does NOT invoke clear-version-description.sh.
# These tests lock in that non-regression.
# ---------------------------------------------------------------------------

@test "AC-3 T-5: bump-version.sh --ci preserves author-written description (P0)" {
    # Copy the project into a tempdir so we can run bump-version.sh on it
    # without mutating the working tree.
    TMPDIR_TEST=$(mktemp -d)
    cp -R "$PROJECT_ROOT"/scripts "$TMPDIR_TEST/"
    cp -R "$PROJECT_ROOT"/config "$TMPDIR_TEST/"
    cp "$PROJECT_ROOT"/VERSION "$TMPDIR_TEST/"
    printf '# ShipTeam\n\n## Current Version: 0.14.20 - Some Author Feature Description\n## Status: STABLE\n' > "$TMPDIR_TEST/CLAUDE.md"

    run bash -c "cd '$TMPDIR_TEST' && bash scripts/bump-version.sh --ci 0.15.0 2>&1"
    assert_success

    run grep -E '^## Current Version:' "$TMPDIR_TEST/CLAUDE.md"
    assert_output "## Current Version: 0.15.0 - Some Author Feature Description"

    rm -rf "$TMPDIR_TEST"
}

@test "AC-3 T-6: bump-version.sh --ci does NOT inject '(pending release notes)' (P1)" {
    TMPDIR_TEST=$(mktemp -d)
    cp -R "$PROJECT_ROOT"/scripts "$TMPDIR_TEST/"
    cp -R "$PROJECT_ROOT"/config "$TMPDIR_TEST/"
    cp "$PROJECT_ROOT"/VERSION "$TMPDIR_TEST/"
    printf '# ShipTeam\n\n## Current Version: 0.14.20 - Real Description\n## Status: STABLE\n' > "$TMPDIR_TEST/CLAUDE.md"

    run bash -c "cd '$TMPDIR_TEST' && bash scripts/bump-version.sh --ci 0.15.0 2>&1"
    assert_success

    run grep -c '(pending release notes)' "$TMPDIR_TEST/CLAUDE.md"
    assert_output "0"

    rm -rf "$TMPDIR_TEST"
}

# ---------------------------------------------------------------------------
# Contract guards on the helper script itself
# ---------------------------------------------------------------------------

@test "clear script exits non-zero on missing version argument" {
    d=$(_make_fixture_dir "## Current Version: 0.14.20 - Whatever")
    run bash -c "cd '$d' && bash '$CLEAR_SCRIPT'"
    assert_failure
    rm -rf "$d"
}

@test "clear script exits non-zero on malformed version argument" {
    d=$(_make_fixture_dir "## Current Version: 0.14.20 - Whatever")
    run bash -c "cd '$d' && bash '$CLEAR_SCRIPT' not-a-version"
    assert_failure
    rm -rf "$d"
}

@test "clear script exits non-zero when CLAUDE.md is absent" {
    d=$(mktemp -d)
    run bash -c "cd '$d' && bash '$CLEAR_SCRIPT' 0.14.21"
    assert_failure
    rm -rf "$d"
}

@test "clear script fails loudly when '## Current Version:' heading is absent" {
    # Silent no-op guard (review M-1/L-2). If the heading shape drifts — e.g.,
    # someone renames it or a CRLF-encoded file slips in — the script MUST
    # fail instead of returning 0 with CLAUDE.md unchanged.
    d=$(mktemp -d)
    printf '# Project\n\n## Status: STABLE\n\nNo current-version heading here.\n' > "$d/CLAUDE.md"
    run bash -c "cd '$d' && bash '$CLEAR_SCRIPT' 0.14.21"
    assert_failure
    assert_output --partial "CLAUDE.md was not updated"
    rm -rf "$d"
}

@test "clear script does not touch unrelated '## Current Version:'-like prose" {
    # Belt-and-suspenders: the sed anchors on the canonical heading line.
    # A paragraph that mentions the phrase must not be rewritten.
    d=$(mktemp -d)
    cat > "$d/CLAUDE.md" <<'EOF'
# Project

## Current Version: 0.14.20 - Real Description

Some prose mentioning "Current Version: 0.14.20" inline should stay intact.
EOF
    run bash -c "cd '$d' && bash '$CLEAR_SCRIPT' 0.14.21"
    assert_success

    # Header line rewritten
    run grep -E '^## Current Version:' "$d/CLAUDE.md"
    assert_output "## Current Version: 0.14.21 - (pending release notes)"

    # Prose line preserved verbatim
    run grep 'Some prose' "$d/CLAUDE.md"
    assert_output --partial 'mentioning "Current Version: 0.14.20" inline should stay intact.'

    rm -rf "$d"
}
