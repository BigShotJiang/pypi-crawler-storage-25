#!/usr/bin/env bats
# ============================================================================
# Tests for pre-compact.py hook
# ============================================================================
# PreCompact hook that saves session state before context compaction.
# Always exits 0 (must never block compaction).
# ============================================================================

setup() {
    load 'test_helper'
    _common_setup
    HOOK="$PROJECT_ROOT/.claude/hooks/pre-compact.py"
}

# ── Always exits 0 ────────────────────────────────────────────────────────

@test "exits 0 with valid session input" {
    local tmpfile="$BATS_TEST_TMPDIR/hook_input.json"
    echo '{"session_id": "test-123", "transcript_path": "/tmp/test.jsonl", "trigger": "auto"}' > "$tmpfile"
    run python3 "$HOOK" < "$tmpfile" 2>/dev/null
    assert_success
}

@test "exits 0 with empty stdin" {
    run bash -c "echo '' | python3 '$HOOK' 2>/dev/null"
    assert_success
}

@test "exits 0 with malformed JSON" {
    run bash -c "echo 'not json' | python3 '$HOOK' 2>/dev/null"
    assert_success
}

# ── Outputs status ────────────────────────────────────────────────────────

@test "outputs success status" {
    local tmpfile="$BATS_TEST_TMPDIR/hook_input.json"
    echo '{"session_id": "test-456"}' > "$tmpfile"
    run python3 "$HOOK" < "$tmpfile" 2>/dev/null
    assert_success
    assert_output --partial "pre_compact_state_saved"
}

@test "outputs branch info" {
    local tmpfile="$BATS_TEST_TMPDIR/hook_input.json"
    echo '{"session_id": "test-789"}' > "$tmpfile"
    run python3 "$HOOK" < "$tmpfile" 2>/dev/null
    assert_success
    assert_output --partial "branch"
}
