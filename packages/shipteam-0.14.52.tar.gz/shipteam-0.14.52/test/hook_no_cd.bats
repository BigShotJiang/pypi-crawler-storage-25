#!/usr/bin/env bats
# ============================================================================
# Tests for no-cd-commands.py hook
# ============================================================================
# Blocks cd to absolute paths outside project root. Allows relative cd.
# ============================================================================

setup() {
    load 'test_helper'
    _common_setup
    HOOK="$PROJECT_ROOT/.claude/hooks/no-cd-commands.py"
}

run_hook() {
    local command="$1"
    local tmpfile="$BATS_TEST_TMPDIR/hook_input.json"
    python3 -c "import json,sys; json.dump({'tool_name':'Bash','tool_input':{'command':sys.argv[1]}}, open(sys.argv[2],'w'))" "$command" "$tmpfile"
    run python3 "$HOOK" < "$tmpfile" 2>/dev/null
}

# ── Allow: relative cd ────────────────────────────────────────────────────

@test "allows cd to relative path" {
    run_hook "cd src/"
    assert_success
}

@test "allows cd with no args" {
    run_hook "cd"
    assert_success
}

@test "allows cd .." {
    run_hook "cd .."
    assert_success
}

@test "allows non-cd commands" {
    run_hook "ls -la"
    assert_success
}

@test "allows empty command" {
    run_hook ""
    assert_success
}

# ── Deny: absolute cd outside project ─────────────────────────────────────

@test "denies cd to /tmp (outside project)" {
    run_hook "cd /tmp"
    assert_success  # exit 0, but output contains deny decision
    assert_output --partial "deny"
}

@test "denies cd to /etc" {
    run_hook "cd /etc"
    assert_success
    assert_output --partial "deny"
}

# ── Allow: absolute cd inside project ─────────────────────────────────────

@test "allows cd to project subdirectory (absolute)" {
    run_hook "cd $PROJECT_ROOT/scripts"
    assert_success
    refute_output --partial "deny"
}

# ── Edge cases ─────────────────────────────────────────────────────────────

@test "handles non-Bash tool input" {
    local tmpfile="$BATS_TEST_TMPDIR/hook_input.json"
    echo '{"tool_name": "Read", "tool_input": {"file_path": "/etc/passwd"}}' > "$tmpfile"
    run python3 "$HOOK" < "$tmpfile" 2>/dev/null
    assert_success
}

@test "handles malformed JSON gracefully" {
    run bash -c "echo 'not json' | python3 '$HOOK' 2>/dev/null"
    assert_success
}

@test "handles empty stdin gracefully" {
    run bash -c "echo '' | python3 '$HOOK' 2>/dev/null"
    assert_success
}
