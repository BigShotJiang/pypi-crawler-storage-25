#!/usr/bin/env bats
# ============================================================================
# Tests for worktree-enforcer.py hook
# ============================================================================
# UserPromptSubmit hook that warns when not in an isolated worktree.
# Always exits 0 (warning only, never blocks).
# ============================================================================

setup() {
    load 'test_helper'
    _common_setup
    HOOK="$PROJECT_ROOT/.claude/hooks/worktree-enforcer.py"
}

# ── Always exits 0 ────────────────────────────────────────────────────────

@test "exits 0 with user_prompt_submit type" {
    local tmpfile="$BATS_TEST_TMPDIR/hook_input.json"
    echo '{"type": "user_prompt_submit", "content": "hello"}' > "$tmpfile"
    run python3 "$HOOK" < "$tmpfile" 2>/dev/null
    assert_success
}

@test "exits 0 with non-matching type" {
    local tmpfile="$BATS_TEST_TMPDIR/hook_input.json"
    echo '{"type": "other_event"}' > "$tmpfile"
    run python3 "$HOOK" < "$tmpfile" 2>/dev/null
    assert_success
}

@test "exits 0 with empty JSON" {
    local tmpfile="$BATS_TEST_TMPDIR/hook_input.json"
    echo '{}' > "$tmpfile"
    run python3 "$HOOK" < "$tmpfile" 2>/dev/null
    assert_success
}

@test "exits 0 with malformed JSON" {
    run bash -c "echo 'bad' | python3 '$HOOK' 2>/dev/null"
    assert_success
}

# ── Only processes user_prompt_submit ──────────────────────────────────────

@test "ignores non-user_prompt_submit events" {
    local tmpfile="$BATS_TEST_TMPDIR/hook_input.json"
    echo '{"type": "tool_use"}' > "$tmpfile"
    run python3 "$HOOK" < "$tmpfile" 2>/dev/null
    assert_success
}
