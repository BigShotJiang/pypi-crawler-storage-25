#!/usr/bin/env bats
# ============================================================================
# Tests for checkout-guard.py hook
# ============================================================================
# Blocks branch switches when another session is active. Tests the command
# detection logic (is_checkout_command) and graceful handling of edge cases.
# ============================================================================

setup() {
    load 'test_helper'
    _common_setup
    HOOK="$PROJECT_ROOT/.claude/hooks/checkout-guard.py"
}

run_hook() {
    local command="$1"
    local tmpfile="$BATS_TEST_TMPDIR/hook_input.json"
    python3 -c "import json,sys; json.dump({'tool_name':'Bash','tool_input':{'command':sys.argv[1]}}, open(sys.argv[2],'w'))" "$command" "$tmpfile"
    run python3 "$HOOK" < "$tmpfile" 2>/dev/null
}

# ── Non-checkout commands pass through ────────────────────────────────────

@test "allows git status" {
    run_hook "git status"
    assert_success
}

@test "allows git log" {
    run_hook "git log --oneline"
    assert_success
}

@test "allows git commit" {
    run_hook "git commit -m 'test'"
    assert_success
}

@test "allows non-git commands" {
    run_hook "ls -la"
    assert_success
}

# ── File restore (not branch switch) passes through ───────────────────────

@test "allows git checkout -- file (file restore)" {
    run_hook "git checkout -- README.md"
    assert_success
}

@test "allows git checkout HEAD -- file" {
    run_hook "git checkout HEAD -- src/main.py"
    assert_success
}

# ── Checkout commands detected (no lock = allowed) ────────────────────────

@test "allows checkout when no session lock exists" {
    run_hook "git checkout feature/new"
    assert_success
}

@test "allows git switch when no session lock exists" {
    run_hook "git switch main"
    assert_success
}

@test "allows git checkout -b when no session lock exists" {
    run_hook "git checkout -b feature/new"
    assert_success
}

# ── Edge cases ─────────────────────────────────────────────────────────────

@test "handles non-Bash tool" {
    local tmpfile="$BATS_TEST_TMPDIR/hook_input.json"
    echo '{"tool_name": "Edit", "tool_input": {"file_path": "test.txt"}}' > "$tmpfile"
    run python3 "$HOOK" < "$tmpfile" 2>/dev/null
    assert_success
}

@test "handles malformed JSON" {
    run bash -c "echo 'not json' | python3 '$HOOK' 2>/dev/null"
    assert_success
}

@test "handles empty command" {
    run_hook ""
    assert_success
}
