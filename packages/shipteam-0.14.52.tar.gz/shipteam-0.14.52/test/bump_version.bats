#!/usr/bin/env bats
# ============================================================================
# Tests for bump-version.sh
# ============================================================================

setup() {
    load 'test_helper'
    _common_setup
}

@test "rejects missing version argument" {
    run bash "$PROJECT_ROOT/scripts/bump-version.sh" 2>/dev/null
    assert_failure
}

@test "rejects invalid version format 'abc'" {
    run bash "$PROJECT_ROOT/scripts/bump-version.sh" --ci "abc" 2>/dev/null
    assert_failure
}

@test "rejects incomplete version '1.2'" {
    run bash "$PROJECT_ROOT/scripts/bump-version.sh" --ci "1.2" 2>/dev/null
    assert_failure
}

@test "accepts valid version format in temp copy" {
    TMPDIR_TEST=$(mktemp -d)
    cp -r "$PROJECT_ROOT"/* "$PROJECT_ROOT"/.gitignore "$TMPDIR_TEST/" 2>/dev/null || true
    cp -r "$PROJECT_ROOT"/config "$TMPDIR_TEST/" 2>/dev/null || true
    cp -r "$PROJECT_ROOT"/scripts "$TMPDIR_TEST/" 2>/dev/null || true

    run bash -c "cd '$TMPDIR_TEST' && bash scripts/bump-version.sh --ci '1.2.3' 2>&1"
    rm -rf "$TMPDIR_TEST"

    assert_output --partial "Bumping version to 1.2.3"
}
