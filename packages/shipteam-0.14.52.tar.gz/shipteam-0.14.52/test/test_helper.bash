#!/usr/bin/env bash
# ============================================================================
# Shared test helper for bats-core tests
# ============================================================================
# Loads bats assertion libraries and provides common setup.
# Usage: In each .bats file, add to setup():
#   load 'test_helper'
#   _common_setup
# ============================================================================

_common_setup() {
    # Load assertion libraries
    load 'test_helper/bats-support/load'
    load 'test_helper/bats-assert/load'
    load 'test_helper/bats-file/load'

    # Project paths
    PROJECT_ROOT="$(cd "$BATS_TEST_DIRNAME/.." && pwd)"

    # Isolate from user environment
    export GIT_CONFIG_GLOBAL=/dev/null
    export GIT_CONFIG_SYSTEM=/dev/null

    # Skip prereq checks in tests — tests validate config parsing, not host setup
    export FW_SKIP_PREREQ_CHECK=1

    # Clear inherited framework vars so auto-detection runs per-test.
    # Tests that need overrides set them explicitly inside @test bodies.
    unset FW_PROJECT_ROOT FW_CONFIG
}
