#!/usr/bin/env bats
# ============================================================================
# Tests for protocol-validator.py hook
# ============================================================================
# PostToolUse warning hook. Never blocks (always exit 0). Outputs warnings
# to stderr when deployment-related actions are detected.
# ============================================================================

setup() {
    load 'test_helper'
    _common_setup
    HOOK="$PROJECT_ROOT/.claude/hooks/protocol-validator.py"
}

run_hook() {
    local command="$1"
    local tmpfile="$BATS_TEST_TMPDIR/hook_input.json"
    python3 -c "import json,sys; json.dump({'tool_name':'Bash','tool_input':{'command':sys.argv[1]}}, open(sys.argv[2],'w'))" "$command" "$tmpfile"
    # Capture stderr (where warnings go) into stdout for assertion
    run bash -c "python3 '$HOOK' < '$tmpfile' 2>&1"
}

# ── Always exits 0 ────────────────────────────────────────────────────────

@test "exits 0 for git push to main" {
    run_hook "git push origin main"
    assert_success
}

@test "exits 0 for gh pr create" {
    run_hook "gh pr create --title test"
    assert_success
}

@test "exits 0 for normal command" {
    run_hook "ls -la"
    assert_success
}

# ── Warning output ────────────────────────────────────────────────────────

@test "warns on git push to main" {
    run_hook "git push origin main"
    assert_output --partial "DEPLOYMENT REMINDER"
}

@test "warns on gh pr create" {
    run_hook "gh pr create --title test"
    assert_output --partial "USER APPROVAL REQUIRED"
}

@test "no warning for normal commands" {
    run_hook "git status"
    refute_output --partial "DEPLOYMENT"
    refute_output --partial "APPROVAL"
}

# ── Edge cases ─────────────────────────────────────────────────────────────

@test "handles non-Bash tool" {
    local tmpfile="$BATS_TEST_TMPDIR/hook_input.json"
    echo '{"tool_name": "Read", "tool_input": {"file_path": "test.txt"}}' > "$tmpfile"
    run bash -c "python3 '$HOOK' < '$tmpfile' 2>&1"
    assert_success
    refute_output --partial "DEPLOYMENT"
}

@test "handles empty command" {
    run_hook ""
    assert_success
}

@test "handles malformed JSON" {
    run bash -c "echo 'bad json' | python3 '$HOOK' 2>&1"
    assert_success
}
