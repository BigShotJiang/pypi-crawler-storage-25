#!/usr/bin/env bats
# ============================================================================
# Regression test: hook commands in .claude/settings.json must resolve hook
# script paths from the git repo root, not the current working directory.
# ============================================================================
# Failure mode this guards against:
#   - Claude `cd`s into a subdirectory (e.g. `frontend/`) during a session.
#   - Claude Code invokes hooks from settings.json with the live shell CWD.
#   - A command like `python3 .claude/hooks/foo.py` resolves to
#     `<subdir>/.claude/hooks/foo.py` (does not exist) → hook errors → every
#     subsequent tool call and UserPromptSubmit blocks → session is wedged
#     because even `cd ..` is gated by the same broken pipeline.
#
# Canonical fix: hook commands must use
#   python3 "$(git rev-parse --show-toplevel 2>/dev/null || pwd)/.claude/hooks/foo.py"
# so the shell resolves the absolute path before executing python3, regardless
# of the live CWD. The `|| pwd` fallback handles non-git contexts.
#
# This was originally fixed in commit 85fc5f0 (2026-03-23) and silently
# regressed across PRs #70/#71/#77/#83 when new hook entries were added using
# the old relative-path style. This test makes that regression undeployable.
# ============================================================================

setup() {
    load 'test_helper'
    _common_setup
    SETTINGS="$PROJECT_ROOT/.claude/settings.json"
}

@test "settings.json exists and is valid JSON" {
    [ -f "$SETTINGS" ]
    run python3 -c "import json; json.load(open('$SETTINGS'))"
    assert_success
}

@test "no hook command uses CWD-relative .claude/hooks/ path" {
    # Extract every hook command, fail if any starts with the broken pattern
    run python3 -c "
import json, sys
data = json.load(open('$SETTINGS'))
bad = []
for event, entries in data.get('hooks', {}).items():
    for entry in entries:
        for hook in entry.get('hooks', []):
            cmd = hook.get('command', '')
            # The broken pattern: 'python3 .claude/hooks/...' (no leading $(git ...))
            if cmd.startswith('python3 .claude/hooks/'):
                bad.append(f'{event}: {cmd}')
if bad:
    print('Found CWD-relative hook commands (will break when CWD drifts into a subdirectory):')
    for b in bad:
        print(f'  {b}')
    sys.exit(1)
print('OK: all hook commands are CWD-independent')
"
    assert_success
}

@test "every hook command resolves path via git rev-parse --show-toplevel" {
    # Stronger check: every command should contain the canonical resolution
    # pattern so a future contributor can't substitute a different broken form.
    run python3 -c "
import json, sys
data = json.load(open('$SETTINGS'))
missing = []
for event, entries in data.get('hooks', {}).items():
    for entry in entries:
        for hook in entry.get('hooks', []):
            cmd = hook.get('command', '')
            if cmd.startswith('python3 ') and '.claude/hooks/' in cmd:
                if 'git rev-parse --show-toplevel' not in cmd:
                    missing.append(f'{event}: {cmd}')
if missing:
    print('Hook commands missing git-root resolution:')
    for m in missing:
        print(f'  {m}')
    sys.exit(1)
"
    assert_success
}

@test "hook command actually resolves correctly when invoked from a subdirectory" {
    # End-to-end check: extract one real hook command, execute it from a
    # subdirectory of the project, and confirm the shell resolves the python
    # script path (the script can fail for any other reason — we just care
    # that it FOUND the file, i.e. did not exit with a "no such file" error).
    skip_if_no_jq
    local cmd
    cmd="$(jq -r '.hooks.PreToolUse[0].hooks[0].command' "$SETTINGS")"
    [ -n "$cmd" ]

    # Pick a subdirectory that exists in the project to simulate CWD drift
    local subdir="$PROJECT_ROOT/scripts"
    [ -d "$subdir" ]

    # Run the command from inside the subdir with empty stdin. We don't care
    # what the hook does — only that python3 doesn't error with [Errno 2].
    cd "$subdir"
    run bash -c "echo '{}' | $cmd 2>&1"
    # Acceptable: any exit code, ANY output. Fatal: 'No such file or directory'
    # in the shell's resolution of the python script path.
    refute_output --partial "can't open file"
    refute_output --partial "No such file or directory"
}

skip_if_no_jq() {
    if ! command -v jq >/dev/null 2>&1; then
        skip "jq not installed"
    fi
}
