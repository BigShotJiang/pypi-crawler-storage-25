#!/usr/bin/env bats
# ============================================================================
# Tests for worktree .claude/ bootstrap (layered defense fix)
# ============================================================================
# Regression tests for bootstrap_claude_dir() and cp_cow() in claude-session.sh.
# Verifies that worktrees get physical copies of hooks/rules/agents/skills,
# symlink for settings.local.json, and isolated state/ directory.
# Ref: commit 54765d1 regression — gitignored .claude/ left empty in worktrees.
# ============================================================================

setup() {
    load 'test_helper'
    _common_setup

    SESSION_SCRIPT="$PROJECT_ROOT/scripts/claude-session.sh"

    # Create a mock "main repo" .claude/ with representative content
    MOCK_MAIN="$BATS_TEST_TMPDIR/main-repo"
    mkdir -p "$MOCK_MAIN/.claude/hooks"
    mkdir -p "$MOCK_MAIN/.claude/rules"
    mkdir -p "$MOCK_MAIN/.claude/agents"
    mkdir -p "$MOCK_MAIN/.claude/skills"
    mkdir -p "$MOCK_MAIN/.claude/state"
    echo '{"hooks":{}}' > "$MOCK_MAIN/.claude/settings.json"
    echo '#!/usr/bin/env python3' > "$MOCK_MAIN/.claude/hooks/auto-approve.py"
    echo '#!/usr/bin/env python3' > "$MOCK_MAIN/.claude/hooks/branch-check.py"
    echo '# anti-patterns' > "$MOCK_MAIN/.claude/rules/anti-patterns.md"
    echo '# security' > "$MOCK_MAIN/.claude/rules/security.md"
    echo '# forensics agent' > "$MOCK_MAIN/.claude/agents/fw-review-forensics.md"
    echo '# deploy skill' > "$MOCK_MAIN/.claude/skills/deploy.md"
    echo '{"local":true}' > "$MOCK_MAIN/.claude/settings.local.json"

    # Mock worktree directory (empty .claude/)
    MOCK_WORKTREE="$BATS_TEST_TMPDIR/worktree"
    mkdir -p "$MOCK_WORKTREE/.claude"

    # Source the functions from claude-session.sh
    # We extract cp_cow and bootstrap_claude_dir without running the main script
    # by sourcing the _framework.sh stub first.
    # FW_ROOT_OVERRIDE=1: the mock path deliberately differs from the script
    # location; without the override, the cross-worktree guard rewrites
    # FW_PROJECT_ROOT back to the real project root and defeats the test.
    export FW_PROJECT_ROOT="$MOCK_MAIN"
    export FW_ROOT_OVERRIDE=1
}

# Helper: source just the functions from claude-session.sh
# Uses awk to extract function blocks between markers, avoiding full script execution
_source_functions() {
    eval "$(awk '/^cp_cow\(\)/,/^}/' "$SESSION_SCRIPT")"
    eval "$(awk '/^bootstrap_claude_dir\(\)/,/^}/' "$SESSION_SCRIPT")"
}

# ============================================================================
# AC-3: cp_cow uses platform-appropriate copy
# ============================================================================

@test "cp_cow copies files successfully" {
    _source_functions
    local src="$BATS_TEST_TMPDIR/cow-src"
    local dst="$BATS_TEST_TMPDIR/cow-dst"
    mkdir -p "$src/subdir"
    echo "content" > "$src/file.txt"
    echo "nested" > "$src/subdir/nested.txt"

    cp_cow "$src" "$dst"

    assert_file_exists "$dst/file.txt"
    assert_file_exists "$dst/subdir/nested.txt"
    run cat "$dst/file.txt"
    assert_output "content"
}

# ============================================================================
# AC-1: Fresh worktree gets all .claude/ content
# ============================================================================

@test "bootstrap copies hooks/ into worktree" {
    _source_functions
    bootstrap_claude_dir "$MOCK_MAIN/.claude" "$MOCK_WORKTREE"

    assert_file_exists "$MOCK_WORKTREE/.claude/hooks/auto-approve.py"
    assert_file_exists "$MOCK_WORKTREE/.claude/hooks/branch-check.py"
}

@test "bootstrap copies rules/ into worktree" {
    _source_functions
    bootstrap_claude_dir "$MOCK_MAIN/.claude" "$MOCK_WORKTREE"

    assert_file_exists "$MOCK_WORKTREE/.claude/rules/anti-patterns.md"
    assert_file_exists "$MOCK_WORKTREE/.claude/rules/security.md"
}

@test "bootstrap copies agents/ into worktree" {
    _source_functions
    bootstrap_claude_dir "$MOCK_MAIN/.claude" "$MOCK_WORKTREE"

    assert_file_exists "$MOCK_WORKTREE/.claude/agents/fw-review-forensics.md"
}

@test "bootstrap copies skills/ into worktree" {
    _source_functions
    bootstrap_claude_dir "$MOCK_MAIN/.claude" "$MOCK_WORKTREE"

    assert_file_exists "$MOCK_WORKTREE/.claude/skills/deploy.md"
}

@test "bootstrap copies settings.json into worktree" {
    _source_functions
    bootstrap_claude_dir "$MOCK_MAIN/.claude" "$MOCK_WORKTREE"

    assert_file_exists "$MOCK_WORKTREE/.claude/settings.json"
    run cat "$MOCK_WORKTREE/.claude/settings.json"
    assert_output '{"hooks":{}}'
}

@test "bootstrap symlinks settings.local.json" {
    _source_functions
    bootstrap_claude_dir "$MOCK_MAIN/.claude" "$MOCK_WORKTREE"

    assert_link_exists "$MOCK_WORKTREE/.claude/settings.local.json"
    run readlink "$MOCK_WORKTREE/.claude/settings.local.json"
    assert_output "$MOCK_MAIN/.claude/settings.local.json"
}

@test "bootstrap creates fresh state/ directory (not symlink)" {
    _source_functions
    bootstrap_claude_dir "$MOCK_MAIN/.claude" "$MOCK_WORKTREE"

    assert_dir_exists "$MOCK_WORKTREE/.claude/state"
    # Must NOT be a symlink
    run test -L "$MOCK_WORKTREE/.claude/state"
    assert_failure
}

@test "bootstrap does NOT symlink hooks/" {
    _source_functions
    bootstrap_claude_dir "$MOCK_MAIN/.claude" "$MOCK_WORKTREE"

    run test -L "$MOCK_WORKTREE/.claude/hooks"
    assert_failure
}

# ============================================================================
# AC-2: Resumed worktree gets missing .claude/ content
# ============================================================================

@test "bootstrap fills gaps in existing worktree .claude/" {
    # Simulate partial .claude/ — has settings.json but missing hooks/
    cp "$MOCK_MAIN/.claude/settings.json" "$MOCK_WORKTREE/.claude/settings.json"

    _source_functions
    bootstrap_claude_dir "$MOCK_MAIN/.claude" "$MOCK_WORKTREE"

    # hooks/ should now exist
    assert_file_exists "$MOCK_WORKTREE/.claude/hooks/auto-approve.py"
    # settings.json should still be the original (not clobbered)
    assert_file_exists "$MOCK_WORKTREE/.claude/settings.json"
}

# ============================================================================
# AC-9: Existing content is not overwritten
# ============================================================================

@test "bootstrap does not clobber existing hooks" {
    # Pre-populate worktree with a modified hook
    mkdir -p "$MOCK_WORKTREE/.claude/hooks"
    echo "MODIFIED" > "$MOCK_WORKTREE/.claude/hooks/auto-approve.py"

    _source_functions
    bootstrap_claude_dir "$MOCK_MAIN/.claude" "$MOCK_WORKTREE"

    run cat "$MOCK_WORKTREE/.claude/hooks/auto-approve.py"
    assert_output "MODIFIED"
}

@test "bootstrap does not clobber existing settings.json" {
    echo '{"modified":true}' > "$MOCK_WORKTREE/.claude/settings.json"

    _source_functions
    bootstrap_claude_dir "$MOCK_MAIN/.claude" "$MOCK_WORKTREE"

    run cat "$MOCK_WORKTREE/.claude/settings.json"
    assert_output '{"modified":true}'
}

# ============================================================================
# AC-7: Line 360 state-dir — validated by function structure
# ============================================================================

@test "bootstrap creates state/ in worktree not main repo" {
    _source_functions

    # Remove any pre-existing state in worktree
    rm -rf "$MOCK_WORKTREE/.claude/state"

    bootstrap_claude_dir "$MOCK_MAIN/.claude" "$MOCK_WORKTREE"

    assert_dir_exists "$MOCK_WORKTREE/.claude/state"
}

# ============================================================================
# Edge cases
# ============================================================================

@test "bootstrap handles missing source .claude/ gracefully" {
    _source_functions
    local empty_main="$BATS_TEST_TMPDIR/no-claude"
    mkdir -p "$empty_main"

    # Should not error
    run bootstrap_claude_dir "$empty_main/.claude" "$MOCK_WORKTREE"
    assert_success
}

@test "bootstrap replaces dangling settings.local.json symlink" {
    # Create a dangling symlink pointing to a non-existent file
    ln -s "/nonexistent/settings.local.json" "$MOCK_WORKTREE/.claude/settings.local.json"

    _source_functions
    bootstrap_claude_dir "$MOCK_MAIN/.claude" "$MOCK_WORKTREE"

    # Should now point to the real source
    assert_link_exists "$MOCK_WORKTREE/.claude/settings.local.json"
    run readlink "$MOCK_WORKTREE/.claude/settings.local.json"
    assert_output "$MOCK_MAIN/.claude/settings.local.json"
}

@test "bootstrap creates .claude/ dir if missing in worktree" {
    rm -rf "$MOCK_WORKTREE/.claude"

    _source_functions
    bootstrap_claude_dir "$MOCK_MAIN/.claude" "$MOCK_WORKTREE"

    assert_dir_exists "$MOCK_WORKTREE/.claude"
    assert_file_exists "$MOCK_WORKTREE/.claude/hooks/auto-approve.py"
}
