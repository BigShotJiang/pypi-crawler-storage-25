#!/usr/bin/env bats
# ============================================================================
# Tests for FW_PROJECT_ROOT cross-worktree guard in scripts/_framework.sh
# ============================================================================
# Covers: AC-1 through AC-6 from .sherlock-plan-framework-env.md
#
# AC-1: unset FW_PROJECT_ROOT → auto-detect via _fw_find_root walk (no change)
# AC-2: pre-set FW_PROJECT_ROOT mismatches script-derived root, FW_ROOT_OVERRIDE
#        unset → emit warning to stderr, overwrite with script-derived value
# AC-3: pre-set FW_PROJECT_ROOT + FW_ROOT_OVERRIDE=1 → honor pre-set, no warning
# AC-4: pre-set FW_PROJECT_ROOT equals script-derived root after realpath →
#        proceed silently (no warning)
# AC-5: BASH_SOURCE[0] unbound (non-bash invocation) → guard skipped, no error
# AC-6: real `git worktree add` tree with pre-set FW_PROJECT_ROOT →
#        warn+overwrite when override unset; honor when override=1
# ============================================================================

setup() {
    load 'test_helper'
    _common_setup
    cd "$PROJECT_ROOT"

    # Helper: create a minimal git repo with a config/framework.yaml so
    # _fw_find_root and validity checks pass.
    _make_git_repo() {
        local root="$1"
        mkdir -p "$root/config"
        git -C "$root" init -q -b main 2>/dev/null || git -C "$root" init -q
        cat > "$root/config/framework.yaml" <<'YAML'
project:
  name: test-repo
YAML
    }
}

teardown() {
    # Remove any worktrees that AC-6 tests may have created.
    if [[ -n "${AC6_WORKTREE:-}" && -d "$AC6_WORKTREE" ]]; then
        # Prune from the repo we created; errors are non-fatal
        git -C "$AC6_REPO" worktree remove --force "$AC6_WORKTREE" 2>/dev/null || true
    fi
}

# ── Helper: run _framework.sh in an isolated subshell ──────────────────────
#
# Usage: _source_framework <extra-env-assignments> [extra-bash-commands]
# Prints the value of $FW_PROJECT_ROOT on stdout.
# Separates stderr by redirecting 2>&1 only when the caller uses 'run'.
# All tests use:
#   run bash -c "..."
# and inspect $output / $stderr (bats-core >= 1.5 sets $stderr automatically
# when the process writes to fd 2 inside a 'run' subshell; for older bats we
# also collect 2>&1 in a combined-output variant where noted).

# ── AC-1: unset FW_PROJECT_ROOT — auto-detect, no behavioral change ─────────

@test "AC-1: unset FW_PROJECT_ROOT resolves to script-derived root" {
    # Run from the real project root; no FW_PROJECT_ROOT in env.
    # Expected: FW_PROJECT_ROOT ends up set to the realpath of PROJECT_ROOT.
    run bash -c "
        unset FW_PROJECT_ROOT FW_ROOT_OVERRIDE FW_CONFIG
        export FW_SKIP_PREREQ_CHECK=1
        source '$PROJECT_ROOT/scripts/_framework.sh'
        echo \"\$FW_PROJECT_ROOT\"
    "
    assert_success
    # The resulting value should be non-empty and should be a directory that exists.
    [ -n "$output" ]
    [ -d "$output" ]
}

@test "AC-1: unset FW_PROJECT_ROOT produces no cross-worktree warning" {
    run bash -c "
        unset FW_PROJECT_ROOT FW_ROOT_OVERRIDE FW_CONFIG
        export FW_SKIP_PREREQ_CHECK=1
        source '$PROJECT_ROOT/scripts/_framework.sh' 2>&1
        echo \"\$FW_PROJECT_ROOT\"
    "
    assert_success
    # The warning string must not appear when FW_PROJECT_ROOT was not pre-set.
    refute_output --partial "disagrees with script location"
}

# ── AC-2: mismatch + no override → warn + overwrite ─────────────────────────

@test "AC-2: mismatch without FW_ROOT_OVERRIDE emits warning to stderr" {
    local unrelated="$BATS_TEST_TMPDIR/unrelated-root"
    _make_git_repo "$unrelated"

    # Combine stderr into stdout so assert_output can check it.
    run bash -c "
        export FW_PROJECT_ROOT='$unrelated'
        export FW_SKIP_PREREQ_CHECK=1
        unset FW_ROOT_OVERRIDE FW_CONFIG
        source '$PROJECT_ROOT/scripts/_framework.sh' 2>&1
        echo \"\$FW_PROJECT_ROOT\"
    "
    # Warning must mention the key phrases from the Interface Contract.
    assert_output --partial "disagrees with script location"
    assert_output --partial "FW_ROOT_OVERRIDE=1"
}

@test "AC-2: mismatch without FW_ROOT_OVERRIDE overwrites FW_PROJECT_ROOT with script-derived value" {
    local unrelated="$BATS_TEST_TMPDIR/unrelated-root2"
    _make_git_repo "$unrelated"
    local unrelated_real
    unrelated_real=$(python3 -c "import os,sys; print(os.path.realpath(sys.argv[1]))" "$unrelated")
    local script_real
    script_real=$(python3 -c "import os,sys; print(os.path.realpath(sys.argv[1]))" "$PROJECT_ROOT")

    run bash -c "
        export FW_PROJECT_ROOT='$unrelated'
        export FW_SKIP_PREREQ_CHECK=1
        unset FW_ROOT_OVERRIDE FW_CONFIG
        source '$PROJECT_ROOT/scripts/_framework.sh' 2>/dev/null
        echo \"\$FW_PROJECT_ROOT\"
    "
    assert_success
    # After sourcing, FW_PROJECT_ROOT must equal the script-derived root,
    # NOT the unrelated pre-set value.
    assert_output "$script_real"
    refute_output "$unrelated_real"
}

# ── AC-3: pre-set + FW_ROOT_OVERRIDE=1 → honor pre-set, no warning ──────────

@test "AC-3: FW_ROOT_OVERRIDE=1 honors pre-set FW_PROJECT_ROOT without warning" {
    local override_repo="$BATS_TEST_TMPDIR/override-repo"
    _make_git_repo "$override_repo"
    local override_real
    override_real=$(python3 -c "import os,sys; print(os.path.realpath(sys.argv[1]))" "$override_repo")

    # Combine stderr to verify no warning appears.
    run bash -c "
        export FW_PROJECT_ROOT='$override_repo'
        export FW_ROOT_OVERRIDE=1
        export FW_SKIP_PREREQ_CHECK=1
        unset FW_CONFIG
        source '$PROJECT_ROOT/scripts/_framework.sh' 2>&1
        echo \"\$FW_PROJECT_ROOT\"
    "
    assert_success
    # No warning should appear.
    refute_output --partial "disagrees with script location"
    # The pre-set path (after realpath) should be preserved.
    assert_output --partial "$override_real"
}

# ── AC-3 tightening: only exact string "1" bypasses; other truthy-looking values still guard ─

@test "AC-3b: FW_ROOT_OVERRIDE=0 does NOT bypass (exact-match '1' required)" {
    local unrelated="$BATS_TEST_TMPDIR/ac3b-unrelated"
    _make_git_repo "$unrelated"

    run bash -c "
        export FW_PROJECT_ROOT='$unrelated'
        export FW_ROOT_OVERRIDE=0
        export FW_SKIP_PREREQ_CHECK=1
        unset FW_CONFIG
        source '$PROJECT_ROOT/scripts/_framework.sh' 2>&1
        echo \"\$FW_PROJECT_ROOT\"
    "
    # '0' is NOT '1', so the guard MUST fire: warning emitted + path overwritten.
    assert_output --partial "disagrees with script location"
}

@test "AC-3c: FW_ROOT_OVERRIDE=false does NOT bypass (exact-match '1' required)" {
    local unrelated="$BATS_TEST_TMPDIR/ac3c-unrelated"
    _make_git_repo "$unrelated"

    run bash -c "
        export FW_PROJECT_ROOT='$unrelated'
        export FW_ROOT_OVERRIDE=false
        export FW_SKIP_PREREQ_CHECK=1
        unset FW_CONFIG
        source '$PROJECT_ROOT/scripts/_framework.sh' 2>&1
        echo \"\$FW_PROJECT_ROOT\"
    "
    assert_output --partial "disagrees with script location"
}

# ── AC-4: pre-set equals script-derived root → silent, no warning ───────────

@test "AC-4: pre-set FW_PROJECT_ROOT matching script-derived root produces no warning" {
    # Set FW_PROJECT_ROOT to the same location _framework.sh would derive.
    local script_real
    script_real=$(python3 -c "import os,sys; print(os.path.realpath(sys.argv[1]))" "$PROJECT_ROOT")

    run bash -c "
        export FW_PROJECT_ROOT='$script_real'
        export FW_SKIP_PREREQ_CHECK=1
        unset FW_ROOT_OVERRIDE FW_CONFIG
        source '$PROJECT_ROOT/scripts/_framework.sh' 2>&1
        echo \"\$FW_PROJECT_ROOT\"
    "
    assert_success
    refute_output --partial "disagrees with script location"
    assert_output --partial "$script_real"
}

# ── AC-5: BASH_SOURCE unbound (sh / non-bash) → guard skipped, no false positive

@test "AC-5: sourcing via sh (BASH_SOURCE unbound) skips guard and does not error" {
    # POSIX sh does not set BASH_SOURCE. We cannot 'source' a bash-ism safely
    # from sh, so we invoke bash but simulate unbound BASH_SOURCE by wrapping
    # the source in a function where BASH_SOURCE might be absent for index > 0,
    # then explicitly unset the array to mimic the non-bash path.
    #
    # The intent: if BASH_SOURCE[0] is unbound, the guard must not fire
    # (no false-positive warning, no non-zero exit).
    run bash -c "
        export FW_SKIP_PREREQ_CHECK=1
        unset FW_PROJECT_ROOT FW_ROOT_OVERRIDE FW_CONFIG
        # Simulate BASH_SOURCE being unavailable by unsetting it, then sourcing.
        # Guard must check 'if [[ -n \"\${BASH_SOURCE[0]:-}\" ]]' or equivalent.
        unset BASH_SOURCE 2>/dev/null || true
        source '$PROJECT_ROOT/scripts/_framework.sh' 2>&1
        echo exit_ok
    "
    # Guard skipped → no warning about disagreement, exit must succeed.
    assert_output --partial "exit_ok"
    refute_output --partial "disagrees with script location"
}

# ── AC-6: real git worktree — the primary regression test ───────────────────

@test "AC-6a: real worktree with mismatched FW_PROJECT_ROOT warns and overwrites" {
    # Create a real secondary git worktree from the project repo.
    local wt_dir="$BATS_TEST_TMPDIR/real-worktree"
    export AC6_REPO="$PROJECT_ROOT"
    export AC6_WORKTREE="$wt_dir"

    # Create a temporary branch for the worktree (required by git worktree add).
    local wt_branch="test/fw-env-ac6-warn-$$"
    git -C "$PROJECT_ROOT" worktree add -q -b "$wt_branch" "$wt_dir" HEAD

    # Seed the worktree with the CURRENT (working-tree) _framework.sh so the
    # test exercises the code we intend to ship, not whatever was at HEAD when
    # `git worktree add` ran. Matters during TDD RED/GREEN on this exact file.
    cp "$PROJECT_ROOT/scripts/_framework.sh" "$wt_dir/scripts/_framework.sh"

    # Build a path that is definitely NOT the worktree root.
    local unrelated="$BATS_TEST_TMPDIR/unrelated-ac6"
    _make_git_repo "$unrelated"

    # Run _framework.sh from inside the new worktree with FW_PROJECT_ROOT
    # pointing at the unrelated repo (the mismatch scenario).
    run bash -c "
        export FW_PROJECT_ROOT='$unrelated'
        export FW_SKIP_PREREQ_CHECK=1
        unset FW_ROOT_OVERRIDE FW_CONFIG
        source '$wt_dir/scripts/_framework.sh' 2>&1
        echo \"\$FW_PROJECT_ROOT\"
    "

    # Clean up worktree + branch immediately (teardown also guards).
    git -C "$PROJECT_ROOT" worktree remove --force "$wt_dir" 2>/dev/null || true
    git -C "$PROJECT_ROOT" branch -d "$wt_branch" 2>/dev/null || true
    unset AC6_WORKTREE

    # Assertions: warning emitted, FW_PROJECT_ROOT overwritten to worktree root.
    assert_output --partial "disagrees with script location"
    assert_output --partial "FW_ROOT_OVERRIDE=1"
    # Final line (stdout echo) must NOT equal the unrelated path.
    local final_line
    final_line=$(echo "$output" | tail -1)
    local unrelated_real
    unrelated_real=$(python3 -c "import os,sys; print(os.path.realpath(sys.argv[1]))" "$unrelated")
    [ "$final_line" != "$unrelated_real" ]
}

@test "AC-6b: real worktree with FW_ROOT_OVERRIDE=1 honors pre-set path, no warning" {
    local wt_dir="$BATS_TEST_TMPDIR/real-worktree-override"
    export AC6_REPO="$PROJECT_ROOT"
    export AC6_WORKTREE="$wt_dir"

    local wt_branch="test/fw-env-ac6-override-$$"
    git -C "$PROJECT_ROOT" worktree add -q -b "$wt_branch" "$wt_dir" HEAD

    # Seed the worktree with the CURRENT _framework.sh (see AC-6a comment).
    cp "$PROJECT_ROOT/scripts/_framework.sh" "$wt_dir/scripts/_framework.sh"

    local unrelated="$BATS_TEST_TMPDIR/unrelated-ac6b"
    _make_git_repo "$unrelated"
    local unrelated_real
    unrelated_real=$(python3 -c "import os,sys; print(os.path.realpath(sys.argv[1]))" "$unrelated")

    run bash -c "
        export FW_PROJECT_ROOT='$unrelated'
        export FW_ROOT_OVERRIDE=1
        export FW_SKIP_PREREQ_CHECK=1
        unset FW_CONFIG
        source '$wt_dir/scripts/_framework.sh' 2>&1
        echo \"\$FW_PROJECT_ROOT\"
    "

    git -C "$PROJECT_ROOT" worktree remove --force "$wt_dir" 2>/dev/null || true
    git -C "$PROJECT_ROOT" branch -d "$wt_branch" 2>/dev/null || true
    unset AC6_WORKTREE

    assert_success
    refute_output --partial "disagrees with script location"
    # Final echoed FW_PROJECT_ROOT should be the pre-set (unrelated) path.
    local final_line
    final_line=$(echo "$output" | tail -1)
    [ "$final_line" = "$unrelated_real" ]
}
