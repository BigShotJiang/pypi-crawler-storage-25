#!/usr/bin/env bats
# ============================================================================
# Tests for methodology-enforcer.py hook
# ============================================================================
# PostToolUse warn-only hook. Warns when git commit touches 3+ files without
# a .sherlock-plan.md. Never blocks (PostToolUse cannot block per Claude Code
# docs). Rate-limited via flag file.
# ============================================================================

setup() {
    load 'test_helper'
    _common_setup
    HOOK="$PROJECT_ROOT/.claude/hooks/methodology-enforcer.py"

    # Create isolated temp project for each test
    TEST_PROJECT="$BATS_TEST_TMPDIR/test-project"
    mkdir -p "$TEST_PROJECT/config" "$TEST_PROJECT/.claude/state"

    # Minimal framework.yaml with sherlock enabled
    cat > "$TEST_PROJECT/config/framework.yaml" <<'YAML'
rules:
  sherlock_review_gate: true
hooks:
  methodology_enforcer: true
YAML

    # CLAUDE.md needed for get_project_root() to find this directory
    echo "# Test Project" > "$TEST_PROJECT/CLAUDE.md"

    # Init git repo with an initial commit
    cd "$TEST_PROJECT"
    git init -q
    git config user.email "test@test.com"
    git config user.name "Test"
    echo "init" > file1.txt
    git add -A && git commit -q -m "init"
}

teardown() {
    cd "$BATS_TEST_DIRNAME"
}

run_hook() {
    local command="$1"
    local tmpfile="$BATS_TEST_TMPDIR/hook_input.json"
    python3 -c "
import json, sys
json.dump({
    'tool_name': 'Bash',
    'tool_input': {'command': sys.argv[1]},
    'tool_response': {},
    'hook_event_name': 'PostToolUse'
}, open(sys.argv[2], 'w'))
" "$command" "$tmpfile"
    cd "$TEST_PROJECT"
    run bash -c "python3 '$HOOK' < '$tmpfile' 2>&1"
}

# ── AC-8: Warns on large unplanned commits ──────────────────────────────

@test "warns when commit touches 3+ files without sherlock plan" {
    # Create and commit 4 files
    for i in 2 3 4 5; do echo "content" > "file${i}.txt"; done
    git add -A && git commit -q -m "big change"

    run_hook "git commit -m 'big change'"
    assert_success
    assert_output --partial "Sherlock"
}

# ── AC-9: Silent for small commits ──────────────────────────────────────

@test "silent when commit touches 1-2 files" {
    echo "change" > file1.txt
    echo "new" > file2.txt
    git add -A && git commit -q -m "small change"

    run_hook "git commit -m 'small change'"
    assert_success
    refute_output --partial "Sherlock"
}

@test "silent for non-commit commands" {
    run_hook "git status"
    assert_success
    refute_output --partial "Sherlock"
}

# ── AC-10: Error handling ───────────────────────────────────────────────

@test "exits 0 when git diff fails (no commits)" {
    # Create a repo with only one commit — HEAD~1 doesn't exist
    local empty_repo="$BATS_TEST_TMPDIR/empty-repo"
    mkdir -p "$empty_repo/config" "$empty_repo/.claude/state"
    cat > "$empty_repo/config/framework.yaml" <<'YAML'
rules:
  sherlock_review_gate: true
hooks:
  methodology_enforcer: true
YAML
    echo "# Test" > "$empty_repo/CLAUDE.md"
    cd "$empty_repo"
    git init -q
    git config user.email "test@test.com"
    git config user.name "Test"
    echo "first" > f.txt
    git add -A && git commit -q -m "first"

    local tmpfile="$BATS_TEST_TMPDIR/hook_input.json"
    python3 -c "
import json
json.dump({
    'tool_name': 'Bash',
    'tool_input': {'command': 'git commit -m first'},
    'tool_response': {},
    'hook_event_name': 'PostToolUse'
}, open('$tmpfile', 'w'))
"
    run bash -c "python3 '$HOOK' < '$tmpfile' 2>&1"
    assert_success
}

@test "exits 0 for non-Bash tool" {
    local tmpfile="$BATS_TEST_TMPDIR/hook_input.json"
    echo '{"tool_name":"Read","tool_input":{"file_path":"/tmp/x"}}' > "$tmpfile"
    run bash -c "python3 '$HOOK' < '$tmpfile' 2>&1"
    assert_success
    refute_output --partial "Sherlock"
}

@test "exits 0 when sherlock is disabled" {
    cat > "$TEST_PROJECT/config/framework.yaml" <<'YAML'
rules:
  sherlock_review_gate: false
hooks:
  methodology_enforcer: true
YAML
    for i in 2 3 4 5; do echo "content" > "file${i}.txt"; done
    git add -A && git commit -q -m "big change"

    run_hook "git commit -m 'big change'"
    assert_success
    refute_output --partial "Sherlock"
}

@test "exits 0 when methodology_enforcer is disabled" {
    cat > "$TEST_PROJECT/config/framework.yaml" <<'YAML'
rules:
  sherlock_review_gate: true
hooks:
  methodology_enforcer: false
YAML
    for i in 2 3 4 5; do echo "content" > "file${i}.txt"; done
    git add -A && git commit -q -m "big change"

    run_hook "git commit -m 'big change'"
    assert_success
    refute_output --partial "Sherlock"
}

# ── Plan exists → no warning ────────────────────────────────────────────

@test "silent when .sherlock-plan.md exists" {
    echo "# Plan" > "$TEST_PROJECT/.sherlock-plan.md"
    for i in 2 3 4 5; do echo "content" > "file${i}.txt"; done
    git add -A && git commit -q -m "big planned change"

    run_hook "git commit -m 'big planned change'"
    assert_success
    refute_output --partial "Sherlock"
}

# ── Rate limiting ───────────────────────────────────────────────────────

@test "warns only once per session (rate-limited)" {
    for i in 2 3 4 5; do echo "content" > "file${i}.txt"; done
    git add -A && git commit -q -m "big change 1"
    run_hook "git commit -m 'big change 1'"
    assert_output --partial "Sherlock"

    # Second commit — should be silent due to rate limit
    for i in 6 7 8 9; do echo "content" > "file${i}.txt"; done
    git add -A && git commit -q -m "big change 2"
    run_hook "git commit -m 'big change 2'"
    refute_output --partial "Sherlock"
}
