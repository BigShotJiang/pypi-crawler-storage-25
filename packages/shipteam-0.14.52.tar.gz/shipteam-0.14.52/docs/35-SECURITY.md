# Security Guidelines

**Purpose**: Establish security standards and prevention measures for the entire codebase. Every developer and AI assistant must follow these rules.

**When to update**: When adding new attack surface (endpoints, file uploads, external integrations), after security incidents, or when adopting new security tooling.

> **Scope note**: This doc covers OWASP/PII/auth rules for code you write using the framework. For an honest accounting of what the framework's own Claude Code hooks and rules enforce — and what they don't — see [85-SAFETY-LIMITS.md](85-SAFETY-LIMITS.md).

---

## Threat Modeling

Threat model documents (STRIDE analysis, risk registers, posture assessments) are kept private and not committed to the repository. They contain security posture details that should not be publicly accessible. Contact the project maintainer for access.

---

## OWASP Prevention

| Threat | Prevention Rule |
|--------|-----------------|
| SQL Injection | ALWAYS use parameterized queries. NEVER concatenate user input into SQL. ORMs parameterize by default but raw query escape hatches bypass protection — audit all raw SQL. For dynamic table/column names (cannot be parameterized), use strict allowlist validation mapping to known-safe identifiers. |
| XSS | Primary: use output encoding (context-aware escaping for HTML, JS, CSS, URL). Use framework auto-escaping (React JSX, Angular templates). For rich text requiring HTML, sanitize with DOMPurify (keep patched). Prefer `textContent`/`innerText` over `innerHTML`. Deploy CSP as defense-in-depth. |
| Broken Access Control | Every new table must have row-level security. Every endpoint must verify authorization. |
| Security Misconfiguration | No wildcard CORS origins for credentialed endpoints (public non-credentialed APIs may use wildcard per OWASP). No debug mode in production. No default credentials. Never dynamically reflect the Origin header without strict validation. |
| Vulnerable Components | Integrate SCA into CI/CD — block PRs with HIGH+ CVEs. Scan every PR, not just after dependency changes. Track transitive dependencies — maintain SBOM. Enable automated monitoring for new CVEs (Dependabot, Snyk, Renovate). |
| Injection (LLM/AI) | No single defense prevents prompt injection. Use layered defense: (1) constrain model role/task/output in system prompt, (2) separate untrusted content with delimiters, (3) validate and filter outputs for disallowed content, (4) enforce least-privilege on LLM tool access, (5) human-in-the-loop for privileged ops, (6) defend against indirect injection from external data (documents, URLs, DB content). Regular red-teaming required. See OWASP LLM01:2025. |

## Input Validation

- Validate all inputs at the API boundary (type, length, format)
- File uploads: whitelist extensions, validate MIME types, enforce size limits
- Reject unexpected fields (strict schema validation)
- Sanitize before storage, escape before rendering

### File Upload Rules
1. Allowed extensions: define an explicit whitelist
2. Validate MIME type AND magic bytes (do not trust Content-Type header alone)
3. Enforce maximum file size
4. Rename files to random names on storage (prevent direct access and filter evasion)
5. Store uploads outside web root on a separate domain/host
6. Re-encode images to strip polyglot payloads
7. Sanitize filenames (strip null bytes, path separators, special characters)
8. Scan uploads with antivirus for malicious patterns
9. Use safe XML parsing libraries to prevent XXE attacks

## Authentication

- See [30-AUTH.md](30-AUTH.md) for full auth documentation
- Never create endpoints without authentication (except `/health` and public pages)
- Rate limit authentication endpoints
- Use generic error messages for failed auth (do not leak user existence)

## Data Protection

- Never log PII (emails, names, phone numbers, addresses)
- Log only anonymized identifiers (user IDs, request IDs)
- Encrypt sensitive data at rest when required by compliance
- Use HTTPS for all external communication
- Never hardcode secrets, API keys, or connection strings in source code
- Never commit `.env` files, credentials, or private keys

## Logging

- Log security-relevant events: login attempts, permission denials, rate limit hits
- Redact PII from all log output
- Error responses must not leak: stack traces, SQL errors, file paths, dependency versions
- External alerting (e.g., webhooks) must contain system status only, no user-identifying information

## Incident Response

1. **Detect**: Monitor error rates, health checks, and security alerts
2. **Contain**: Disable affected endpoints or features if necessary
3. **Investigate**: Review logs, identify root cause, assess data exposure
4. **Fix**: Apply patch via Tier 3 emergency deployment (see [20-DEPLOYMENT.md](20-DEPLOYMENT.md))
5. **Document**: Record the incident in [70-INSIGHTS.md](70-INSIGHTS.md) with root cause and prevention measures
6. **Review**: Conduct post-incident review within 48 hours

## AI Configuration File Integrity

AI coding assistants (Claude Code, Cursor, GitHub Copilot) load instruction files (`.claude/rules/*.md`, `CLAUDE.md`, `.cursorrules`) into their context window. These files are a supply chain attack vector: invisible Unicode characters can embed hidden instructions that silently affect all future AI-generated code.

**Threat**: Pillar Security (March 2025) demonstrated that zero-width Unicode characters in rule files can inject instructions invisible to human reviewers but parsed by AI models. A malicious contributor could embed "ignore security rules" in invisible characters within a PR that appears to make only formatting changes.

**Attack surface**: `.claude/rules/`, `CLAUDE.md`, `.claude/agents/`, `.claude/skills/`

**Mitigations in this framework**:
1. **CODEOWNERS**: All files in `.claude/rules/` require maintainer review
2. **CI integrity check**: The `lint-shell` job scans rule files for control characters and zero-width Unicode (fails the build if detected)
3. **Hook compound guard**: `auto_approve_base.py` blocks Claude from writing to `.claude/hooks/` or `.claude/rules/` directories via shell operators
4. **fw-sync SHA tracking**: Framework sync tracks file hashes to detect drift

**Reference**: [Pillar Security — Rules File Backdoor](https://www.pillar.security/blog/new-vulnerability-in-github-copilot-and-cursor-how-hackers-can-weaponize-code-agents)

## Security Anti-Patterns (Do Not)

- Never use `eval()`, `exec()`, or shell execution with user input
- Never disable SSL verification
- Never suppress security warnings without documented justification
- Never create unauthenticated admin or debug endpoints
- Never store plaintext passwords or tokens
- Use Argon2id for password hashing (preferred: memory 19 MiB, iterations 2, parallelism 1). Alternatives: scrypt, bcrypt (work factor 10+, 72-byte limit — legacy only), PBKDF2-HMAC-SHA256 (600k+ iterations — FIPS only). Never MD5, SHA1, or plain SHA256.
