# Authentication and Authorization

> **Stack-Conditional**: Skip this doc if using an external auth provider with no custom auth code. Document the provider choice in `docs/10-ARCHITECTURE.md` instead.

**Purpose**: Document the authentication flow, role-based access control, session management, and security considerations for the auth system.

**When to update**: When changing auth providers, adding new roles or permissions, modifying token handling, or updating session policies.

---

## Overview

The application uses [auth provider/strategy, e.g., "JWT-based authentication with OAuth2 social login"] for user identity. Authorization is enforced via [RBAC/ABAC/custom] at the API layer.

Key principles:
- Authentication is verified on every request (except explicitly public endpoints)
- Authorization checks are applied at the endpoint level, not the client level
- Tokens are never stored in server-side sessions or cookies (stateless design)

## Authentication Flow

```
1. User submits credentials (or initiates OAuth)
2. Auth provider validates and returns access token + refresh token
3. Client stores tokens securely (memory or secure storage)
4. Client includes access token in Authorization header for API calls
5. Backend middleware validates token on every request
6. Token refresh occurs transparently when access token expires
```

### Public Endpoints (No Auth Required)

| Endpoint | Purpose |
|----------|---------|
| `GET /health` | Health check |
| `POST /auth/login` | Login |
| `POST /auth/register` | Registration |

## Authorization (RBAC)

| Role | Permissions | Description |
|------|------------|-------------|
| `user` | Read/write own data | Default role for authenticated users |
| `admin` | Full access | Administrative operations, user management |

### Enforcement Pattern

Every protected endpoint must include auth dependency injection:

```python
# Example (FastAPI)
@router.get("/protected")
async def protected_route(user = Depends(get_current_user)):
    # user is guaranteed to be authenticated here
    pass

@router.get("/admin-only")
async def admin_route(user = Depends(require_permission("admin:*"))):
    pass
```

## Session Management

- **Access token lifetime**: [e.g., 1 hour]
- **Refresh token lifetime**: [e.g., 7 days]
- **Token rotation**: Refresh tokens are rotated on each use (one-time use)
- **Logout**: Client discards tokens; server-side revocation for refresh tokens

## Security Considerations

- Never log tokens, passwords, or auth headers
- Rate limit login attempts (e.g., 5 attempts per minute per IP)
- Use HTTPS for all auth-related endpoints
- Validate JWT signature and expiration on every request
- Admin endpoints require elevated permissions, not just authentication
- Failed auth attempts should return generic error messages (do not reveal whether the user exists)
