# Environment Variables

**Purpose**: Reference for all environment variables used by the application, organized by required/optional and environment.

**When to update**: When adding a new environment variable, changing defaults, or modifying secret management practices.

---

## Required Variables

These must be set in every environment. The application will fail to start without them.

| Variable | Description | Example |
|----------|-------------|---------|
| `DATABASE_URL` | PostgreSQL connection string | `postgresql://user:pass@host:5432/dbname` |
| `API_SECRET_KEY` | Secret key for signing tokens | `[generated-secret]` |
| `NODE_ENV` / `ENVIRONMENT` | Runtime environment | `development`, `staging`, `production` |

## Optional Variables

These have sensible defaults but can be overridden.

| Variable | Description | Default |
|----------|-------------|---------|
| `PORT` | Server port | `8000` |
| `LOG_LEVEL` | Logging verbosity | `info` |
| `CORS_ORIGINS` | Allowed CORS origins (comma-separated) | `http://localhost:3000` |
| `RATE_LIMIT_PER_MINUTE` | API rate limit per user | `60` |

## Development vs Production

| Setting | Development | Production |
|---------|------------|------------|
| `DEBUG` | `true` | `false` |
| `LOG_LEVEL` | `debug` | `info` |
| `CORS_ORIGINS` | `http://localhost:*` | Explicit origin list |
| `DATABASE_URL` | Local database | Managed database with SSL |

### Local Development Setup

1. Copy the example env file: `cp .env.example .env.local`
2. Fill in required variables
3. Never commit `.env.local` (it should be in `.gitignore`)

### CI Environment

CI pipelines use repository secrets. When adding a new required variable:
1. Add it to the CI workflow as a secret reference
2. Add it to the hosting platform's environment configuration
3. Document it in this file

## Secret Management

- **Never** hardcode secrets in source code
- **Never** commit `.env` files or credentials to version control
- Store secrets in your hosting platform's secret manager or CI secrets
- Rotate API keys and secrets on a regular schedule (at minimum quarterly)
- Use different secrets for each environment (dev, staging, production)
- When a secret is compromised, rotate immediately and audit access logs

### Secret Rotation Checklist

1. Generate new secret value
2. Update the secret in the hosting platform / secret manager
3. Deploy the application to pick up the new value
4. Verify the application is healthy with the new secret
5. Revoke the old secret value
6. Document the rotation date
