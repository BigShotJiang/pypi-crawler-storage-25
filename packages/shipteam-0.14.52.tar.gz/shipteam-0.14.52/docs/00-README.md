# Documentation Guide

**Purpose**: Central index for all project documentation. Start here to find what you need.

**When to update**: When adding, renaming, or removing any documentation file.

---

## Document Structure

| File | Topic | Description |
|------|-------|-------------|
| [10-ARCHITECTURE.md](10-ARCHITECTURE.md) | Architecture | Tech stack, repository structure, key patterns |
| [20-DEPLOYMENT.md](20-DEPLOYMENT.md) | Deployment | CI/CD pipeline, deployment tiers, rollback |
| [30-AUTH.md](30-AUTH.md) | Authentication | Auth flow, RBAC, session management |
| [35-SECURITY.md](35-SECURITY.md) | Security | OWASP prevention, input validation, data protection |
| Threat Models | Threat Modeling | Private — not in repo (security posture docs) |
| [40-DATABASE.md](40-DATABASE.md) | Database | Schema overview, migration protocol, backups |
| [45-ENVIRONMENT.md](45-ENVIRONMENT.md) | Environment | Required/optional variables, secret management |
| [50-TESTING.md](50-TESTING.md) | Testing | TDD workflow, testing pyramid, CI integration |
| [60-FEATURES.md](60-FEATURES.md) | Features | Current features, planned work, feature flags |
| [70-INSIGHTS.md](70-INSIGHTS.md) | Insights | Design decisions, lessons learned |
| [80-TROUBLESHOOTING.md](80-TROUBLESHOOTING.md) | Troubleshooting | Common issues, debugging checklist |
| [85-SAFETY-LIMITS.md](85-SAFETY-LIMITS.md) | Safety Limits | What hooks do/don't enforce, known bypass vectors, opt-in hardening |
| [90-DISASTER-RECOVERY.md](90-DISASTER-RECOVERY.md) | Disaster Recovery | Recovery procedures, incident playbook |
| [15-PROMPT_VERSIONING.md](15-PROMPT_VERSIONING.md) | Prompt Versioning | LLM prompt versioning, migration, rollback |
| [ADOPTION.md](ADOPTION.md) | Team Adoption | Evaluation checklist, 3-phase rollout, customization guide, FAQ |
| [adr/](adr/README.md) | Architecture Decisions | ADRs for significant design choices (context, decision, consequences) |
| [archives/](archives/) | Archives | Historical version notes and changelogs |

## Conventions

- **Numbering**: Files are numbered in increments of 10 to allow insertion without renaming.
- **Format**: Each file includes a purpose statement, "When to update" guidance, and practical content.
- **Archives**: Old version histories move to `archives/` with the naming pattern `ARCHIVE_vX.Y-vX.Y.md`.
- **Insights**: Each design decision gets a numbered entry in `70-INSIGHTS.md` for traceability.

## Stack-Conditional Docs

Not all docs apply to every project. Check `config/framework.yaml` to see which stack components are configured:

| Doc | Applies When |
|-----|-------------|
| [30-AUTH.md](30-AUTH.md) | Project has custom auth (not just an external provider) |
| [40-DATABASE.md](40-DATABASE.md) | Project has a backend database (`stack.backend` configured) |
| [15-PROMPT_VERSIONING.md](15-PROMPT_VERSIONING.md) | Project uses LLM prompts (`prompts.versioning: true`) |

Docs marked with a "Stack-Conditional" banner at the top include guidance on when to skip them.

## How to Use This Documentation

1. **Setting up for the first time?** Run `claude` in the repo root — it reads [SETUP.md](../SETUP.md) and handles configuration automatically. Or follow SETUP.md manually.
2. **New to the project?** Read `10-ARCHITECTURE.md` first, then `45-ENVIRONMENT.md` to get set up.
3. **Deploying?** Follow `20-DEPLOYMENT.md` step by step.
4. **Writing code?** Check `50-TESTING.md` for TDD workflow, `35-SECURITY.md` for guardrails.
5. **Assessing threats?** Threat models are kept private (not in repo). See `35-SECURITY.md` for security policy.
6. **Debugging?** Start with `80-TROUBLESHOOTING.md`. For the honest accounting of what the safety layers enforce and their known limits, see `85-SAFETY-LIMITS.md`.
7. **Making a design decision?** Record the insight in `70-INSIGHTS.md`. For significant architectural choices, create an ADR in `adr/`.
8. **Adopting for a team?** Follow the rollout strategy in `ADOPTION.md`.
