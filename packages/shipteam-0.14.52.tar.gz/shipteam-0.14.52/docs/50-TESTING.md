# Testing Strategy

**Purpose**: Define the testing approach, TDD workflow, and CI integration for maintaining code quality and preventing regressions.

**When to update**: When changing the test framework, modifying CI test stages, or adding a new category of tests.

---

## Testing Pyramid

```
        /  E2E  \          Few, slow, high confidence
       /----------\
      / Integration \      Moderate count, moderate speed
     /----------------\
    /    Unit Tests     \  Many, fast, focused
   /--------------------\
```

- **Unit tests**: Test individual functions and classes in isolation. Fast, no I/O.
- **Integration tests**: Test interactions between components (API routes, database queries).
- **E2E tests**: Test full user workflows through the UI. Slow but high confidence.

## TDD Workflow

Follow the RED / GREEN / REFACTOR cycle for all new features and bug fixes.

### Phase 1: RED
- Write a failing test that defines the expected behavior
- Run the test to confirm it fails for the right reason
- Commit: `./scripts/tdd-commit.sh red "describe the expected behavior"`

### Phase 2: GREEN
- Write the minimum code to make the test pass
- Do not optimize or clean up yet
- Commit: `./scripts/tdd-commit.sh green "implement the behavior"`

### Phase 3: REFACTOR
- Improve code quality while keeping all tests green
- Remove duplication, improve naming, simplify logic
- Commit: `./scripts/tdd-commit.sh refactor "clean up implementation"`

## Unit Tests

- Location: `backend/tests/unit/`, `frontend/src/**/*.test.*`
- Framework: [e.g., pytest, jest]
- Run: `pytest backend/tests/unit/` or `npm test`
- Coverage target: [e.g., 80%+]
- Mock external dependencies (databases, APIs, file system)

### Fixture-Based Configuration Testing (bats)

Framework-level tests that exercise config readers MUST be fixture-based, not value-hardcoded. Rationale: a test asserting `fw_get_nested "stack.backend.port" == 8000` is testing dev-framework's own config, not the reader's correctness. Consumer forks with a different stack fail spuriously.

Pattern (from `test/framework_config.bats`):

```bash
_fixture_repo "$BATS_TEST_TMPDIR"                      # writes fixture framework.yaml
result=$(_fixture_read "$BATS_TEST_TMPDIR" "stack.backend.port")
[ "$result" = "4567" ]                                  # assert round-trip
```

`_fixture_read` invokes `_framework.sh` in an isolated subshell via `FW_PROJECT_ROOT="$fixture" FW_ROOT_OVERRIDE=1 bash -c 'source ... && fw_get_nested "$1"' -- "$key"`. The key is passed as a positional argument (not string-interpolated into `bash -c`) to avoid injection fragility. `FW_ROOT_OVERRIDE=1` is required for any fixture that deliberately points at a path different from the script location — without it, `_framework.sh`'s cross-worktree contamination guard rewrites `FW_PROJECT_ROOT` back to the real project root and defeats the fixture.

`test/test_helper.bash`'s `_common_setup` unsets `FW_PROJECT_ROOT` and `FW_CONFIG` per-test so parent-shell env leakage does not pollute auto-detection.

See [`docs/10-ARCHITECTURE.md`](10-ARCHITECTURE.md) for the env-var contract these tests rely on.

## Integration Tests

- Location: `backend/tests/integration/`
- Framework: [e.g., pytest with test database]
- Run: `pytest backend/tests/integration/`
- Use a dedicated test database (not production)
- Test actual database queries, API routes, and service interactions

## E2E Tests

- Location: `frontend/tests/e2e/` or `e2e/`
- Framework: [e.g., Playwright, Cypress]
- Run: `npx playwright test`
- Rules:
  - Use semantic selectors: `getByRole()` > `getByText()` > `data-testid` > CSS
  - Never use `waitForTimeout()` -- use event-driven waits instead
  - Never use CSS class selectors (they break when styling changes)
  - Tests must be deterministic (no flaky tests in CI)

## CI Integration

Tests run automatically on every push and pull request:

```
Push --> Lint --> Unit Tests --> Integration Tests --> E2E Tests --> Build
```

- All tests must pass before merge is allowed
- Flaky tests must be fixed or explicitly skipped with `test.skip()` and a tracking issue
- Never leave failing tests in the main branch as "reminders"
