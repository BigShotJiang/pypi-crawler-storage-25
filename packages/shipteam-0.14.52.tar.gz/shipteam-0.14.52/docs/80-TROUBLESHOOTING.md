# Troubleshooting

**Purpose**: Provide solutions for common issues, a systematic debugging checklist, and documentation of known limitations.

**When to update**: When resolving a non-obvious issue, discovering a new limitation, or adding a new debugging technique.

---

## Common Issues

### Application fails to start

**Symptoms**: Server exits immediately, "missing environment variable" error.
**Cause**: Required environment variables are not set.
**Fix**: Check [45-ENVIRONMENT.md](45-ENVIRONMENT.md) for required variables. Copy `.env.example` to `.env.local` and fill in values.

### Database connection refused

**Symptoms**: `ConnectionRefusedError`, `could not connect to server`.
**Cause**: Database is not running, or `DATABASE_URL` is incorrect.
**Fix**:
1. Verify the database is running: `pg_isready -h localhost -p 5432`
2. Check `DATABASE_URL` in your environment
3. Verify network/firewall rules if connecting to a remote database

### Port already in use

**Symptoms**: `EADDRINUSE` or `Address already in use`.
**Cause**: Another process is using the port.
**Fix**:
1. Find the process: `lsof -i :PORT_NUMBER`
2. Stop the conflicting process, or change the port in your configuration

### "Python 3.9+ required" error

**Symptoms**: Scripts exit immediately with a version error when sourcing `_framework.sh`.
**Cause**: Your system Python version is too old. Some Linux distros ship older Python.
**Fix**:
- **macOS**: `brew install python`
- **Linux**: `sudo apt install python3.12` (or equivalent for your distro)
- **Windows**: Use the DevContainer (`.devcontainer/`) or WSL (`wsl --install`)
- **CI/tests**: Set `FW_SKIP_PREREQ_CHECK=1` to bypass (only if your environment doesn't need hooks)

### Tests fail locally but pass in CI (or vice versa)

**Symptoms**: Inconsistent test results between environments.
**Cause**: Environment differences (Node version, database state, env vars, timezone).
**Fix**:
1. Compare environment variables between local and CI
2. Check database state (migrations may differ)
3. Verify dependency versions match (`package-lock.json`, `requirements.txt`)

### Migration fails with "column already exists"

**Symptoms**: SQL error during migration.
**Cause**: Migration was partially applied or the column was added manually.
**Fix**: Use `IF NOT EXISTS` in migration SQL, or check current schema before applying.

### Worktree session won't start

**Symptoms**: `claude-session.sh` errors with "worktree already exists" or "branch already exists".
**Cause**: A previous session wasn't cleaned up (crash, `--keep` flag, or manual `Ctrl+C`).
**Fix**:
1. List active worktrees: `git worktree list`
2. Clean up the stale one: `./scripts/cleanup-worktree.sh ~/worktrees/project-feature-name`
3. Or prune all stale worktrees: `git worktree prune`

### Git commands fail in worktree with "not a git repository"

**Symptoms**: `git status` or other commands fail inside a worktree session.
**Cause**: `GIT_DIR` / `GIT_WORK_TREE` environment variables are not set or are stale.
**Fix**:
1. Source the helper: `source .git-env` (auto-generated in each worktree)
2. Or set manually: `export GIT_WORK_TREE=$(pwd)`
3. The `branch-check.py` hook detects this automatically during sessions

### Session lock is stale / "another session is active"

**Symptoms**: `checkout-guard.py` blocks you, but no other session is running.
**Cause**: Previous session crashed without releasing the lock.
**Fix**: The framework detects stale locks automatically by checking if the PID is alive. If it still blocks:
1. Check: `cat .claude/state/session-lock.json`
2. Verify the PID is dead: `kill -0 <pid>` (will error if dead)
3. Remove the lock: `rm .claude/state/session-lock.json`

## Debugging Checklist

When something is not working, follow this order:

1. **Read the error message** -- what does it actually say?
2. **Check logs** -- server logs, browser console, CI output
3. **Verify environment** -- correct branch, correct env vars, correct database
4. **Reproduce consistently** -- can you trigger it reliably?
5. **Isolate the change** -- what was the last thing that changed?
6. **Check recent commits** -- `git log --oneline -10`
7. **Search for known issues** -- check this file and project issue tracker
8. **Ask for help** -- share the error, what you tried, and what you found

### Hook Diagnostic Logging

Safety hooks emit warnings to stderr when recoverable errors occur. These help diagnose silent failures in session management and safety gates:

- Warnings appear with prefix `[hook-name] WARNING: [message]`
- Example: `[branch-check] WARNING: Could not read session lock: [Errno 13] Permission denied`
- Hooks still fail gracefully -- warnings are informational only and do not block operations
- If you see persistent warnings, check `.claude/state/` file permissions or disk space
- No warning means no error -- only failures are logged

## Known Limitations

<!-- Document limitations that are accepted trade-offs, not bugs. -->

| Limitation | Reason | Workaround |
|-----------|--------|------------|
| [Description] | [Why this exists] | [How to work around it] |

## Getting Help

- **Project issues**: File an issue in the repository issue tracker
- **Documentation**: Start with [00-README.md](00-README.md) for the full doc index
- **Architecture questions**: See [10-ARCHITECTURE.md](10-ARCHITECTURE.md)
- **Security concerns**: See [35-SECURITY.md](35-SECURITY.md) and follow incident response
