# Version History Archive: vX.Y -- vX.Y

**Purpose**: Store historical version notes when the main CLAUDE.md or release notes become too long. Each archive covers a version range.

**When to create a new archive**: When the recent releases section in the main documentation exceeds 50 entries, move older entries here.

---

## Naming Convention

Archive files follow the pattern: `ARCHIVE_vX.Y-vX.Y.md`

Example: `ARCHIVE_v0.60-v0.99.md` covers versions 0.60 through 0.99.

## Thresholds

Check `config/framework.yaml` under `archive:` for current thresholds. Defaults:
- `insights_threshold: 1500` -- lines in `docs/70-INSIGHTS.md`
- `version_history_threshold: 800` -- lines in `release_notes.md`

When a file exceeds its threshold, split older entries into an archive file here.

## Template

For each version entry, use this format:

### vX.Y.Z -- [Short Description] (Insight #N)
**Date**: YYYY-MM-DD
**Changes**:
- [Change 1]
- [Change 2]
**Breaking Changes**: [None / description of breaking changes]

## How to Split

1. Count lines: `wc -l docs/70-INSIGHTS.md`
2. If over threshold, identify a natural split point (version boundary)
3. Create archive: `ARCHIVE_INSIGHTS_1.md` (or increment number)
4. Cut older entries from source file into archive
5. Add link in source file: `See: [Earlier Insights](docs/archives/ARCHIVE_INSIGHTS_1.md)`
6. Verify `scripts/next-insight-number.sh` still finds the highest number

---

## Entries

<!-- Add archived version entries below, in reverse chronological order. -->

### v0.0.1 -- Initial Release (Insight #1)
**Date**: YYYY-MM-DD
**Changes**:
- Initial project setup
- Core infrastructure and authentication
**Breaking Changes**: None (initial release)
