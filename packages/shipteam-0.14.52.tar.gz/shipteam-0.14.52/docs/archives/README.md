# Archive Directory

**Purpose**: Store historical version notes, insights, and changelogs when main documentation files become too large.

## When to Archive

| Document | Threshold | Action |
|----------|-----------|--------|
| `docs/70-INSIGHTS.md` | > 1500 lines | Move older insights to `ARCHIVE_INSIGHTS_N.md` |
| `release_notes.md` | > 800 lines | Move older releases to `ARCHIVE_RELEASES_vX.Y-vX.Y.md` |
| CLAUDE.md "Recent Releases" | > 5 entries | Keep only last 5, note archive link |

These thresholds are also configured in `config/framework.yaml` under the `archive:` section.

## Naming Conventions

| Type | Pattern | Example |
|------|---------|---------|
| Version history | `ARCHIVE_vX.Y-vX.Y.md` | `ARCHIVE_v0.1-v0.5.md` |
| Insights | `ARCHIVE_INSIGHTS_N.md` | `ARCHIVE_INSIGHTS_1.md` |
| Releases | `ARCHIVE_RELEASES_vX.Y-vX.Y.md` | `ARCHIVE_RELEASES_v0.1-v0.5.md` |

## How to Archive

1. **Identify what to move**: Check line counts against thresholds
2. **Create archive file**: Use the naming convention above
3. **Move entries**: Cut older entries from the source file, paste into archive
4. **Add archive link**: In the source file, add a link to the archive (e.g., `See: [Earlier Insights](docs/archives/ARCHIVE_INSIGHTS_1.md)`)
5. **Update next-insight-number.sh**: The script already scans archives to prevent number collisions

## Important

- Archive files are append-only (never delete entries from archives)
- Always maintain reverse chronological order within archives
- Keep the source file's format template intact after archiving
- The `scripts/next-insight-number.sh` script scans both active and archived files for the highest insight number
