# Archive: Release Notes v0.1.0 through v0.12.0

**Purpose**: Historical release notes moved here to keep `release_notes.md` focused on recent versions. Preserves full PR-level detail for auditing and reference.

**Date archived**: 2026-04-12 (during v0.13.5 cleanup — see PR #104 for related doc hygiene work)

**Coverage**: v0.12.0 (Cross-Project Framework Stats) down through v0.1.0 (Initial Release), including one orphaned "Unreleased - Session Lock at Startup" entry from the v0.10 era that was never promoted to a version section.

**Source**: Extracted verbatim from `release_notes.md` lines 61-665 as of commit 526bb2b.

---

## v0.12.0 — Cross-Project Framework Stats in Insights Dashboard

### Summary
The Claude Code Insights dashboard (`scripts/generate_insights.py`) now aggregates framework operational metrics across every framework-managed project on the local machine. Worktrees of the same parent project roll up under one canonical name, so the dashboard shows true per-project totals rather than scattered per-worktree noise. Discovery is filesystem-based with a depth limit and a one-time cache, so subsequent runs are instant.

### New: Framework Stats Section
- Discovers all directories under `$HOME` (depth ≤ 3) that contain `config/framework.yaml`
- Reads each project's `.context/metrics/events-*.jsonl` and `.context/metrics/conformance/scorecard-*.json`
- Re-uses the existing aggregation helpers from `scripts/generate_dashboard.py` (safety, cost routing, conformance, protocol, sessions) — no duplicate logic
- Renders a "Framework Stats" panel in the dashboard with aggregate KPI cards (safety blocks, cost routes, est. savings, conformance avg, protocol warnings, sessions) and a per-project comparison table
- Worktree paths like `dev-framework-session-claude-20260410-005743` canonicalize to their parent project name (`dev-framework`) before aggregation, so cross-project totals are accurate even when most work happens in disposable worktrees

### New: Discovery Cache
- Discovered project paths cached at `~/.claude/fw-project-paths.json` after the first scan
- Subsequent runs read from cache and prune missing paths in memory (does not rewrite the file)
- `--refresh-fw-projects` forces a fresh filesystem scan and overwrites the cache
- Skip-list excludes heavy directories (`node_modules`, `.git`, `.venv`, `Library`, `dist`, `build`, `.pnpm-store`, `.yarn`, `bower_components`, etc.)
- `os.walk(home, followlinks=False)` is set explicitly so a future refactor cannot accidentally chase symlink loops

### New: CLI Flags
- `--refresh-fw-projects` — force a fresh filesystem scan, overwrite the cache
- `--no-fw-stats` — skip framework metrics aggregation entirely (insights-only dashboard)

### Tests
- 17 new tests in `scripts/tests/test_insights.py` covering discovery, caching, aggregation, payload integration, HTML rendering, worktree rollup, graceful degradation, and symlink-loop safety
- 102 tests pass across `test_insights.py` + `test_generate_dashboard.py`

### Notes
- The project-level `.claude/skills/fw-stats/SKILL.md` is unchanged and continues to provide single-project quick stats. The integration is purely additive — the global `claude-insights` skill now also surfaces framework metrics for any user who runs the script.
- A real-world smoke test during development discovered 25 framework project paths (most of them worktree clones), of which 5 had non-empty metrics directories. After canonical rollup these became 2 distinct projects (one contributing 4 worktrees, the other 1). See Insight #22 for the lesson on worktree-fragmented metrics.

---

## v0.11.0 — Provider-Agnostic Capability Tiers + Insights Dashboard

### Summary
Renames cost routing tiers from Anthropic-specific model names to provider-agnostic capability tiers (`high`/`standard`/`fast`), adds a `providers` config section as the foundation for multi-provider support, and includes the Claude Code qualitative Insights Dashboard. Also disables automatic version bumping on push — version increments are now manual-only via `workflow_dispatch`.

### Added and later removed: `feature_tier` config
- `feature_tier:` section was added in v0.11.0 and removed in v0.13.0 — see `docs/adr/006-remove-feature-tier-gating.md`.

### New: Providers Config Section
- `providers` section in `framework.yaml` maps capability tiers to provider-specific model names
- Currently supports anthropic (default), openai, google
- Foundation for Phase 1 multi-provider support (`generate-agents.py` in future release)

### Changed: Cost Tier Naming
- `cost.model_tiers` keys renamed: `opus`→`high`, `sonnet`→`standard`, `haiku`→`fast`
- `cost_routing.py` internal tier names updated throughout
- `COST_PER_AGENT_CALL` lookup uses capability tiers
- `sherlock-review-gate.md` routing table references updated
- Agent frontmatter (`model: opus/sonnet/haiku`) unchanged — Claude Code runtime values, addressed in Phase 1

### New: QUICKSTART.md
- Placeholder onboarding guide targeting "zero to working in under 10 minutes"

### Changed: Auto Version Bump Disabled
- `.github/workflows/auto-version-bump.yml` push trigger commented out — workflow is now `workflow_dispatch` only
- Version bumps must be triggered intentionally going forward

### Removed
- `docs/launch-copy.md` removed (GTM content relocated to private docs)
- Hardcoded personal project paths in `test_insights.py` replaced with generic examples
- Private directory path reference in `CLAUDE.md` softened

### New: Claude Code Insights Dashboard (`scripts/generate_insights.py`)
- **7-phase pipeline**: Load → Join → Compute KPIs → Algorithmic Insights → AI Narratives (opt-in) → Build HTML → Verify
- **3 data sources**: `~/.claude/usage-data/session-meta/` (per-session detail), `~/.claude/usage-data/facets/` (qualitative analysis), `~/.claude/stats-cache.json` (full historical aggregates)
- **Interactive dashboard**: Date filtering (7D/30D/90D/All), project multi-select with chips, URL state persistence, sortable session table
- **10 algorithmic insights**: Satisfaction trends, friction hotspots, project outliers, tool error correlation, coverage gaps, duration patterns, success streaks, friction-free rates, helpfulness ratios, peak hours
- **8 AI narrative sections** (`--narrative` flag): "At a Glance" executive summary, "What You Work On" project breakdown, "Impressive Things You Did" achievements, "Where Things Go Wrong" friction root causes, "Features to Try" CC feature recommendations, "New Ways to Use Claude Code" workflow patterns, "On the Horizon" copyable prompt recommendations, "How You Use Claude Code" behavioral profile
- **Chart library**: Chart.js 4.4.7 + Frappe Charts (heatmap), dark theme matching claude-code-stats
- **Historical trends**: Daily activity, tokens by model, and model usage from stats-cache going back to first session
- **Narrative caching**: SHA-256 hash of input data; skips LLM calls if data unchanged
- **Zero dependencies**: stdlib-only Python, runs on 3.8+
- **38 unit tests** in `scripts/tests/test_insights.py`
- **New `/claude-insights` skill**: `python3 scripts/generate_insights.py --narrative` → generates dashboard → opens in browser

---

## v0.10.9 - Agent Teams Dual-Mode Orchestration

### Summary
Adds dual-mode orchestration support so framework agents can run as Anthropic Agent Teams teammates (parallel worktrees, peer-to-peer messaging, dependency-tracked tasks) while preserving full backward compatibility with existing subagent mode via config toggle.

### New Features
- **Orchestration mode config** (`config/framework.yaml`): `orchestration.mode: subagent | agent-teams` controls how agents are invoked. Default `subagent` preserves all existing behavior. `agent-teams` enables parallel teammate execution.
- **Task dependency generation** (`scripts/cost_routing.py`): New `format_as_tasks()` function and `--mode agent-teams` flag convert the review agent list into Agent Teams task definitions with `blockedBy` dependency chains.
- **Task quality gate hook** (`.claude/hooks/task-quality-gate.py`): Fires on `TaskCompleted` events. Blocks (exit 2) when a reviewer teammate reports Critical issues. Warns on High issues. Ignores non-reviewer agents (TDD, advisors).
- **Agent Teams lifecycle metrics**: `metrics-tracker.py` extended to log `TaskCreated`, `TaskCompleted`, and `TeammateIdle` events (category: `"team"`) alongside existing `SubagentStart` events.

### Agent Definition Updates
- **11 agents** with `skills: project-context` gain runtime fallback instructions for Agent Teams mode (where `skills` frontmatter is ignored). CLAUDE.md auto-loads for all teammates, so no context loss in practice.
- **3 TDD agents** (`fw-tdd-red`, `fw-tdd-green`, `fw-tdd-refactor`) gain explicit `## Agent Teams Mode` sections enforcing cognitive isolation when running as teammates (no peer message reading, `blockedBy` chain enforcement).

### Orchestration Rule Updates
- `sherlock-methodology.md`: New `## Agent Teams Mode` section mapping Sherlock steps to Agent Teams tasks with dependency chains. TDD chain spec (RED blockedBy architecture, GREEN blockedBy RED, REFACTOR blockedBy GREEN).
- `sherlock-review-gate.md`: New `## Agent Teams Mode Adaptation` section with task generation guidance, quality gate hook documentation, and dual-mode differences.

### Infrastructure
- `settings.json` + `settings.local.json.template`: 3 new hook lifecycle events registered (`TaskCreated`, `TaskCompleted`, `TeammateIdle`)
- `fw_conformance.py`: `_compute_review_gate()` now counts both `agent_spawn` and `task_completed` events for dual-mode compatibility

### Test Coverage
- 30 new tests: 9 for `format_as_tasks()`, 3 for Agent Teams metrics events, 9 for task quality gate hook, 9 backward-compat assertions
- All 377 tests pass (1 pre-existing failure fixed: `backend-tests` trailing YAML comment)

### Design Decisions
- **Dual-mode over migration**: Both modes coexist rather than requiring all users to adopt Agent Teams. Config toggle (`orchestration.mode`) gates all new behavior.
- **Instructional isolation over worktree isolation**: TDD cognitive isolation preserved via agent body instructions and `blockedBy` chains, not worktree sparse checkout. Same approach as existing subagent mode — consistent and simple.
- **Runtime fallback over skill inlining**: Rather than duplicating 600 lines of `project-context` content across 11 agents, a 2-line fallback instruction leverages CLAUDE.md auto-loading. Empirically sufficient since CLAUDE.md carries the same conventions.

---

## v0.10.7 - Supply Chain & Safety Hardening

### Summary
Closes supply chain and safety gate gaps identified by evaluation against OWASP CI/CD Top 10, OpenSSF Best Practices, NVIDIA agent sandbox guidance, and AWS Well-Architected Framework. Hardens the safety gate, CI/CD workflows, and dependency management.

### Safety Gate Hardening
- **Shell writes to safety infrastructure now hard-blocked** (exit 2): Commands using `>`, `tee`, `cp`, `mv`, or `ln` targeting `.claude/hooks/`, `.claude/rules/`, or `.claude/settings.json` are now non-overridable blocks. Previously these fell through to user prompt.
- **Edit/Write tools to safety files prompt user**: Preserves user agency — Claude Code shows a diff preview, so user prompt is sufficient.
- **Network recon/exfiltration tools blocked**: `nc`, `ncat`, `nmap`, `socat`, `tcpdump` are hard-blocked. Handles path prefixes (`/usr/bin/nc`) and `env` wrappers. `ss` and `netstat` fall through to user prompt (diagnostic use).

### CI/CD Workflow Hardening
- **Least-privilege permissions**: Added `permissions: contents: read` to `ci-cd.yml` and `security-scan.yml`
- **bats-core/bats-action SHA-pinned**: Was the only tag-pinned action; now uses commit SHA
- **Checkout SHA standardized**: `pages.yml` aligned to v4.2.2 SHA used across all other workflows
- **ShellCheck made blocking**: Removed `|| true` suppression; `lint-shell` added to quality-gate `needs`

### Supply Chain
- **Hash-pinned dependencies**: Created `requirements.txt` with `--hash=sha256:` directives for pytest and pyyaml. CI uses `pip install --require-hashes`.
- **SBOM generation**: Added `anchore/sbom-action` (syft) producing SPDX JSON artifact per CI run

### Test Coverage
- 21 new bats tests (93→ total) covering safety infrastructure protection, network tool blocking, and bypass prevention (path prefixes, env wrappers, symlinks)
- 15 new pytest tests validating workflow YAML structure (SHA pinning, permissions, quality gate, SBOM, dependency hashing)

### Sources
Evaluated against: Google SRE PRR, AWS Well-Architected (6 pillars), OWASP CI/CD Top 10, OpenSSF Best Practices Badge, DORA metrics, Microsoft SDL, OWASP LLM Top 10 / Agentic Apps 2026, NVIDIA Sandbox Guidance, Anthropic Claude Code architecture

---

## v0.10.2 - Framework Adoption & Enforcement Improvements

### Summary
Ensures the framework is accessible to all Claude Code users, that the Sherlock methodology activates reliably, and that documentation protocols are enforced from first setup. Fixes a critical gap where `settings.local.json.template` had zero hooks — new projects initialized from the template got no safety enforcement.

### Platform Compatibility
- **README.md**: Added platform compatibility callout — Claude Code works on all 5 surfaces (CLI, Desktop app, VS Code, JetBrains, claude.ai/code)
- **docs/ADOPTION.md**: New Platform Compatibility section with support table distinguishing Claude Code surfaces from Claude chat products. Updated FAQ with three new entries. Updated Evaluation Checklist.

### Sherlock Methodology Enforcement (3-layer approach)
- **CLAUDE.md**: Added mandatory Step 0 instruction — "run complexity classification BEFORE writing code." Conditional on profile (removed by init-project.sh on minimal).
- **methodology-enforcer.py** (NEW): PostToolUse warn-only hook. Warns when `git commit` touches 3+ files without a `.sherlock-plan.md`. Rate-limited (1hr). Never blocks (PostToolUse cannot block per Claude Code docs). Config: `hooks.methodology_enforcer` in framework.yaml.
- **/fw-stats Step 8**: Profile graduation nudge — reads current profile and suggests upgrading (minimal→standard→full).

### Documentation Protocol
- **settings.local.json.template**: Added full hooks section (was permissions-only). New projects now get all 12 hooks registered including safety gates, branch checking, and protocol validation.
- **framework.yaml**: Added `hooks.doc_staleness_check` and `hooks.methodology_enforcer` config keys with comments.
- **CLAUDE.md**: Added doc staleness gate note explaining protocol-validator.py PostToolUse behavior.

### Setup Improvements
- **init-project.sh**: Auto-replaces `<!-- CUSTOMIZE: org/repo -->`, test_command, and health_url markers in CLAUDE.md. Warns about remaining manual markers with count. Removes Sherlock section on minimal profile (prevents broken references to deleted rule files).
- **README.md**: Uncollapsed Session Isolation section (key differentiator, was hidden in `<details>`). Added link to SETUP.md full guide.

### Infrastructure
- **fw-manifest.yaml**: Registered methodology-enforcer.py with `config_gate: hooks.methodology_enforcer`
- **settings.json**: Registered methodology-enforcer.py as PostToolUse hook

### Test Coverage
- 9 new BATS tests for methodology-enforcer.py (warns on 3+ files, silent on small commits, config gates, rate limiting, error handling)
- 5 new BATS tests for settings template completeness (hooks section, event types, command registration)
- All 86 tests pass (36 safety gate + 14 new + existing)

---

## Unreleased - Session Lock at Startup + Worktree Docs Rewrite

### Summary
Fixes a gap in the concurrent-session protection model where `session-lock.json` was only created on `git checkout` (via `branch-tracker.py`), not at session start. Also corrects a doc error in SETUP.md and adds a comprehensive worktree architecture guide for new adopters.

### Bug Fixes
- **Session lock created at startup**: `session-lifecycle.py` (SessionStart hook) now writes `session-lock.json` immediately so `checkout-guard.py` and `worktree-enforcer.py` can detect concurrent sessions from the first prompt. Handles stale locks (dead PID → reclaim), live locks (different PID alive → preserve), own-PID locks (restart → overwrite), and corrupt JSON (→ overwrite).
- **SETUP.md state/ symlink claim**: Documentation incorrectly stated `.claude/state/` is symlinked from main repo. The code explicitly creates a per-worktree directory because symlinking causes "beyond a symbolic link" errors with `git stash` (`.gitkeep` is tracked inside `state/`).

### New Documentation
- **"Worktree Architecture: End-to-End Flow"** section in SETUP.md covering:
  - What problem worktrees solve (context for new adopters)
  - Shared vs. isolated resource table with rationale for each
  - Full lifecycle diagram (ASCII art, 9 steps with hook callouts)
  - Hook integration timeline (when each of 5 session hooks fires)
  - Stale lock recovery explanation
  - 6 adoption FAQ entries

### Test Coverage
- 6 new tests in `scripts/tests/test_session_lifecycle.py`
- All 342 tests pass

---

## v0.10.0 - Defense-in-Depth Hardening

### Summary
Hardens the framework's defense-in-depth layers based on systematic analysis of hooks vs rules architecture, validated against industry best practices (Anthropic engineering blog, Pillar Security research, NIST IR 8596). Fills three identified gaps: rule file integrity (supply chain protection), post-compaction context loss (Sherlock workflow continuity), and audit noise (event log signal-to-noise ratio).

### New Features
- **PostCompact hook** (`.claude/hooks/post-compact-restore.py`) — Restores Sherlock workflow context after context compaction. Detects active plan, current TDD phase from git history, and outputs structured context to stderr for seamless session resumption.
- **SessionStart hook** (`.claude/hooks/session-lifecycle.py`) — Logs `session_start` events with branch and session metadata for lifecycle tracking.
- **Event log levels** (`scripts/fw_event_log.py`) — New `level` parameter (debug/info/warn/error) reduces audit noise. Routine auto-approvals log at `debug`; blocks at `warn`. Backward-compatible: old records without level treated as `info`.
- **Error logging** — Failed event writes now captured in `errors.jsonl` (fire-and-forget, never raises).
- **CI Unicode integrity check** — Detects invisible/zero-width Unicode characters in `.claude/rules/` files to prevent supply chain instruction injection (Pillar Security "Rules File Backdoor" vector).
- **Automated dashboard generation** — CI pipeline generates metrics dashboard on merge to main, uploaded as GitHub Actions artifact.
- **Real conformance metrics** — `hook_compliance` and `review_gate` scores now computed from actual event log data instead of hardcoded 1.0.

### Security Hardening
- **CODEOWNERS expanded** — All `.claude/rules/` files now require maintainer review (previously only `security.md`)
- **Rule file integrity documented** in `docs/35-SECURITY.md` with threat model, attack surface, and mitigations
- **Auto-approve log levels** — `approve()` logs at `debug`, `block()` logs at `warn` for better signal

### Changes
- `fw_event_log.py` — `append_event()` gains `level` param; `read_events()` gains `level` filter
- `fw_conformance.py` — `_compute_hook_compliance()` and `_compute_review_gate()` replace hardcoded 1.0
- `auto_approve_base.py` — approve/block use tiered log levels
- `.claude/settings.json` — Registers SessionStart, PostCompact hooks
- `config/framework.yaml` — Expanded `metrics:` section with log_level, session_tracking, error_logging
- `.github/workflows/ci-cd.yml` — Unicode check in lint-shell job, dashboard generation job

### Design Decisions
- **PostCompact over rules-only recovery**: Rules achieve ~60-90% compliance after compaction; a PostCompact hook deterministically re-injects context at 100%.
- **Log levels over separate log files**: Single JSONL with level field is simpler than multiple files and preserves chronological ordering.
- **CODEOWNERS + CI for rule integrity**: Defense-in-depth — CODEOWNERS catches human PRs, CI catches encoded attacks, hook compound guard catches Claude writes.

### Test Coverage
- 29 new tests (13 event log levels, 16 PostCompact hook)
- All 336 existing tests continue to pass

---

## v0.10.0-pre - Framework Metrics & Conformance System

### Summary
Adds local-only telemetry to measure framework effectiveness. Two layers: (1) JSONL event log capturing safety blocks, cost routing decisions, and protocol violations from hooks; (2) Conformance scorer measuring plan adherence during Sherlock/Holmes sessions (file coverage, AC coverage, scope creep). New `/fw-stats` skill aggregates metrics into an ROI-focused summary.

### New Features
- **Event logger** (`scripts/fw_event_log.py`) — Append-only JSONL with `fcntl.flock` file locking, date-partitioned files (`events-YYYY-MM.jsonl`), 50MB rotation cap. Fire-and-forget design: never interrupts hook execution.
- **Conformance scorer** (`scripts/fw_conformance.py`) — Parses `.sherlock-plan.md`, compares planned vs actual files, checks AC coverage in tests, measures scope creep. Produces weighted composite score.
- **`/fw-stats` skill** — Aggregates event log + conformance scores over configurable time window. Shows safety blocks, cost savings from agent routing, protocol violations caught, plan conformance rates, and TDD health.
- **Cost estimates** in `cost_routing.py` — Tier+LOC band lookup table estimates dollar savings from skipped agents.
- **Dashboard generator** (`scripts/generate_dashboard.py`) — Self-contained HTML dashboard with inline SVG charts. Aggregates safety blocks/approvals, cost routing savings, conformance score trends, session activity, and protocol violations. CLI: `python3 scripts/generate_dashboard.py [--since DATE] [--output PATH] [--open]`. Output: `.context/dashboard.html`.
- **Metrics tracker hook** (`.claude/hooks/metrics-tracker.py`) — SubagentStart hook captures agent spawns as `cost::agent_spawn` events. Async, fire-and-forget. Feeds agent frequency into `/fw-stats` and dashboard.
- **TDD phase events** in `tdd-commit.sh` — Emits `tdd::tdd_phase` events after successful commits. `/fw-stats` reads these from JSONL instead of fragile git log grep.
- **Conformance gate** in `/ship` skill — Auto-runs `fw_conformance.py --save` when `.sherlock-plan.md` exists before PR creation.

### Changes
- `tdd-commit.sh` — Emits `tdd_phase` events to event log after successful commits
- `/fw-stats` skill — Reads `agent_spawn` and `tdd_phase` events from JSONL (falls back to git grep for TDD)
- `/ship` skill — New Step 5 conformance gate when Sherlock plan exists
- `auto_approve_base.py` — Logs `approve`/`block` events (fire-and-forget)
- `protocol-validator.py` — Logs `warn`/`block` events with trigger context
- `cost_routing.py` — Adds `est_cost_saved` field to routing output
- `sherlock-methodology.md` — DESIGN-SYNC step now runs conformance scorer
- `config/framework.yaml` — New `metrics:` section (enabled by default, local-only)
- `.gitignore` — `.context/metrics/` excluded from version control

### Design Decisions
- **JSONL over SQLite**: Validated against Git trace2 reference architecture. Zero dependencies, append-only, grep-friendly.
- **fcntl.flock file locking**: Validated against Claude Code bug #20992 (concurrent JSONL corruption).
- **Date-partitioned rotation**: Simpler than numbered rotation, naturally time-bounded.
- **Fire-and-forget pattern**: All logging wrapped in try/except with no-op fallback. Hooks never break.

### Test Coverage
- 70 new tests (34 for event logger, 36 for conformance scorer)
- All 253 existing tests continue to pass

---

## v0.9.0 - Progressive Adoption: Complexity Profiles (Insight #11)

### Summary
Addresses adoption complexity by introducing complexity profiles (`minimal`/`standard`/`full`) and rewriting the Adoption Guide with progressive disclosure. The framework's 75 components are now organized into tiers that teams can adopt incrementally. Research-backed: progressive learning paths, Time-to-Hello-World targeting, and golden path patterns from Rails, Terraform, and Kubernetes.

### New Features
- **Complexity profiles**: `profile: minimal|standard|full` in `framework.yaml` controls how much of the framework is active. `minimal` enables ~15 components (safety gates + Hudson), `standard` enables ~40 (+ Sherlock + core skills), `full` enables all ~75.
- **Profile-aware setup wizard**: `init-project.sh` reads the profile and auto-sets all feature toggles, so adopters don't need to understand individual settings.
- **Adoption Guide rewrite**: 4 new sections — "What You Can Safely Ignore" (infrastructure vs. interactive component categorization), "Complexity Profiles" (with expandable details per profile), "First Week Guide" (day-by-day progressive learning path), "Component Dependency Map" (tiered dependency visualization).

### Bug Fixes
- `init-project.sh` now handles `sherlock-methodology.md` rule deletion when `sherlock_review_gate: false` (previously orphaned)
- `init-project.sh` now handles `tdd-commit` and `ship` skill toggle (previously missing)

### Changes
- `README.md`: Quick Start shows profile selection, "Setup Wizard" section renamed to "Progressive Adoption", new adopter callout
- GitHub repo description updated, `progressive-adoption` topic added (swapped for `devops`)
- New FAQ entries covering profile selection, learning timeline, and cost justification

### Migration Steps
- Run `fw-sync.sh <project>` to pull updated `framework.yaml`, `init-project.sh`, and `ADOPTION.md`
- Optionally set `profile: minimal` or `profile: standard` to reduce active components
- Re-run `./scripts/init-project.sh` after changing profile

---

## v0.8.0 - Professional Agent Naming + DRY Spec Format (Insight #10)

### Summary
Standardizes all 27 agents to a consistent 4-prefix naming convention (`fw-review-*`, `fw-author-*`, `fw-advisor-*`, `fw-tdd-*` for framework; `advisor-*`, `review-*` for personal). Extracts the `.sherlock-plan.md` format to a single-source-of-truth file (`.claude/spec-format.md`).

### New Features
- **Consistent agent naming**: 20 agents renamed to follow `fw-{verb}-{domain}` convention. The verb tells you what the agent does (review, author, advisor, tdd), the domain tells you what it knows about.
- **DRY spec format**: `.sherlock-plan.md` template extracted from `sherlock-methodology.md` into `.claude/spec-format.md` — single source of truth referenced by methodology, fw-tdd-red, and fw-author-spec.

### Changes
- 20 agent files renamed (see rename map below)
- All cross-references updated across rules, config, docs, scripts
- 20 deprecated entries added to `fw-manifest.yaml` + 3 to `fw-manifest-personal.yaml`
- `config/framework.yaml` model tier mappings updated
- `scripts/cost_routing.py` and tests updated
- Demo scripts updated

### Rename Map
| Old Name | New Name |
|----------|----------|
| code-reviewer | fw-review-code |
| ai-testing-expert | fw-review-tests |
| it-security-expert | fw-review-security |
| performance-reviewer | fw-review-performance |
| maintainability-reviewer | fw-review-maintainability |
| api-contract-reviewer | fw-review-api-contracts |
| ux-uxp-specialist | fw-review-ux |
| migration-author | fw-author-migration |
| documentation-reviewer | fw-review-docs |
| docs-efficiency-expert | fw-author-docs |
| fw-review-silent-failures | fw-review-error-handling |
| fw-review-type-design | fw-review-types |
| tdd-test-writer | fw-tdd-red |
| tdd-implementer | fw-tdd-green |
| tdd-refactorer | fw-tdd-refactor |
| ai-architect | fw-advisor-architecture |
| release-manager | fw-advisor-release |
| ai-venture-capitalist | *(removed)* |
| marketing-rhetoric-expert | *(removed)* |
| ai-product-expert | *(removed)* |

### Migration Steps
- Run `fw-sync.sh <project>` — old agent files will be automatically deleted (deprecated entries), new files synced
- For personal projects: use `fw-sync.sh <project> --personal`

---

## v0.7.0 - SDD Spec-Anchored Development + Agent Expansion + Doc Gates (Insight #8, #9)

### Summary
Integrates spec-driven development into the Sherlock/Holmes workflow, adds 5 new specialized agents, extracts the Sherlock methodology into a syncable rules file, and hardens the documentation update protocol with a blocking gate.

### New Features
- **Spec-anchored development (SDD)**: `.sherlock-plan.md` now includes structured Acceptance Criteria (Given/When/Then) and Interface Contracts that feed TDD agents directly. Architecture decisions are extracted as ADRs post-commit instead of being deleted.
- **Sherlock methodology as syncable rule**: Full workflow (Step 0 routing, Hudson/Lite/Full/Holmes modes) moved from personal `~/.claude/CLAUDE.md` to `.claude/rules/sherlock-methodology.md` — now ships to all projects via `fw-sync.sh`
- **3 new agents**: `fw-review-dependencies` (supply chain security, Opus), `fw-review-concurrency` (race conditions, Opus), `fw-author-spec` (spec generation for SDD)
- **Doc staleness gate**: `protocol-validator.py` now BLOCKS `gh pr create` when `release_notes.md` or `CHANGELOG.md` are not updated for the current version
- **Explicit doc update checklist**: Sherlock Lite Step 6 and Full Step 8 now list specific docs to update before PR creation

### Changes
- `.claude/rules/sherlock-methodology.md`: New file (extracted from global CLAUDE.md)
- `.claude/rules/sherlock-review-gate.md`: Added fw-review-dependencies, fw-review-concurrency to pipeline routing + domain authority table + skip rules
- `.claude/hooks/protocol-validator.py`: Added `check_doc_staleness()` — blocks PR creation when docs are stale
- `.claude/agents/fw-tdd-red.md`: Updated to prefer structured Acceptance Criteria from `.sherlock-plan.md`
- `config/fw-manifest.yaml`: 4 new entries (sherlock-methodology rule + 3 framework agents)
- `config/fw-manifest-personal.yaml`: *(removed in v0.10.1)*
- `docs/adr/README.md`: Added Sherlock-Extracted ADRs section
- `~/.claude/CLAUDE.md`: Slimmed to personal preferences only (~20 lines)
- Clarified boundary between `fw-review-dependencies` (real deps) and `fw-review-forensics` (hallucinated deps)

### Migration Steps
- Run `fw-sync.sh <project>` to pull sherlock-methodology rule + 3 new framework agents + hardened protocol-validator
- For personal projects: use `fw-sync.sh <project> --personal` to also get accessibility + compliance agents
- Review `~/.claude/CLAUDE.md` — methodology now lives in the repo, not in your global config

---

## v0.6.0 - Agent Distribution + Dual Sync Profiles
### Summary
Migrates all 18 pipeline and advisory agents from global `~/.claude/agents/` into the framework repo, closing the distribution gap where downstream projects got the Sherlock review pipeline rules but not the agents they reference. Adds `--personal` flag for separate customer vs personal sync profiles.

### New Features
- **Agent distribution**: 15 pipeline agents (code-reviewer, ai-testing-expert, it-security-expert, performance-reviewer, maintainability-reviewer, api-contract-reviewer, ux-uxp-specialist, migration-author, documentation-reviewer, docs-efficiency-expert, ai-architect, release-manager, tdd-test-writer, tdd-implementer, tdd-refactorer) now ship via `fw-sync.sh` to all projects
- **Dual sync profiles**: `--personal` flag adds 3 advisory agents (ai-venture-capitalist, marketing-rhetoric-expert, ai-product-expert) for personal projects only
- **Personal manifest**: `config/fw-manifest-personal.yaml` is additive — base manifest parsed first, personal appends entries

### Changes
- `config/fw-manifest.yaml`: 15 new agent entries with `replace` policy
- `config/fw-manifest-personal.yaml`: New additive manifest for personal-only agents
- `scripts/fw-sync.sh`: `--personal` flag, `manifest_files()` helper, profile banner line
- Insight #7 added: "Distribution Gaps Break the Whole Pipeline"

### Migration Steps
- Run `fw-sync.sh` to pull all 15 pipeline agents into your project
- For personal projects: use `fw-sync.sh <project> --personal` to also get advisory agents

---

## v0.5.1 - Security Hardening (Injection Fixes + Error Observability)
### Summary
Comprehensive security scan and remediation: closed 3 injection vectors (CI config, eval, source), added stderr observability to ~40 silent exception handlers in safety-gate hooks, fixed the last redirection regex bypass, and documented accepted risks.

### Security Fixes
- **CI config injection (R-021, PR #24)**: Test commands from `framework.yaml` now validated against full-string allowlist (anchored both ends, restricted character class) before `bash -c` execution
- **eval/source injection (R-022, PR #24)**: Replaced `eval "$CMD"` with allowlist-gated `bash -c` in `tdd-commit.sh`; replaced `source "$PORT_FILE"` with grep-based safe parsing in `claude-session.sh`
- **Redirection regex bypass (R-015, PR #27)**: Added `>\S` (no-space redirect) and `^>` (command-initial redirect) patterns to compound command guard
- **Silent error swallowing (R-023, PR #24)**: Added `[hook-name] WARNING:` stderr logging to ~40 silent `except: pass` blocks across 8 hooks. Narrowed broad `except Exception` to specific types where applicable.

### Changes
- **Threat model removed from public repo (PR #30)**: Security posture docs moved to private storage; `.gitignore` prevents re-creation
- **R-024 documented**: Broad `settings.json` allow patterns accepted as design decision (hooks are the security boundary)
- Architecture doc updated with hook observability note
- Troubleshooting doc updated with hook diagnostic logging section
- Insight #6 added: "Silent Failures Are the Biggest Threat to Safety Gates"

### Migration Steps
- Run `fw-sync.sh` to pull updated hooks and scripts
- No behavioral changes — hooks have identical exit codes and control flow

---

## v0.5.0 - Agent Quality Bar + DevContainer + Cost Routing
### Summary
Phase 1-3 milestone: production-quality agent definitions, container isolation with deny-by-default networking, automated cost routing for the review pipeline, and team adoption documentation.

### New Features
- **Agent Quality Bar (PR #4)**: All 4 custom agents upgraded to affaan-m pattern — tool scoping in frontmatter, 80% confidence threshold, bad-to-good code examples for every CRITICAL item, false positive awareness sections, APPROVE/WARNING/BLOCK approval criteria, verdict in output format. Template updated to guide future agent creation.
- **DevContainer (PR #5)**: Stack-agnostic container with deny-by-default firewall covering both IPv4 and IPv6. Non-root user, no Docker socket mount, no HOME mount. Explicit subdomain allowlist (no CDN wildcard gaps). `EXTRA_ALLOWED_HOSTS` array for project customization.
- **Cost Routing Script (PR #6)**: `scripts/cost_routing.py` classifies git changes by type (docs-only, config-only, deps-only, etc.) and LOC to select the minimal effective agent set. 30 unit tests. Auth files always trigger `it-security-expert`. JSON output for tool consumption.
- **Team Adoption Guide (PR #9)**: `docs/ADOPTION.md` with evaluation checklist, 3-phase rollout strategy, customization points table, API cost estimates, security model documentation, and FAQ.

### Bug Fixes
- Hook paths now resolve from git root, supporting subdirectory CWD in worktrees (commit 85fc5f0)

### Changes
- README updated with DevContainer and cost routing sections
- fw-manifest.yaml gains devcontainer and cost_routing entries
- Agent cross-references fixed (fw-review-forensics phase refs were inaccurate)

### Migration Steps
- Run `fw-sync.sh` to pull updated agents, new scripts, and manifest
- Optionally: copy `.devcontainer/` and customize `EXTRA_ALLOWED_HOSTS`

---

## v0.4.0 - Upstream Hooks + Config Loader + Checkout Guard

### Summary
Parameterized hooks with centralized config loading, new session safety mechanisms, and framework distribution improvements. Plus public OSS launch preparation (README rewrite, launch content, CONTRIBUTING.md).

### New Features
- **Config Loader (`path_utils.py`)**: Centralized `framework.yaml` reading with PyYAML → line-by-line parser fallback. All hooks can now read project config without duplicating parse logic.
- **Checkout Guard (`checkout-guard.py`)**: Blocks branch switches when another Claude session is active. Prevents concurrent session interference via session lock detection.
- **Commit Trust Check (`commit_trust_check.py`)**: Gated by `hooks.deploy_gate` config. Blocks pushes if CI failed. Checks `deployment.health_url` on main branch.
- **fw-sync.sh Enhancements**: Three-way merge support, merge editor UX, config-gated hook distribution, `--full-diff` and `--merge-editor` flags.
- **Auto-Approve Base/Overlay Split**: `auto_approve_base.py` (universal safety gate, replace policy) + `auto-approve.py` (project overlay, template policy). Projects customize the overlay without losing upstream safety updates.

### Security Hardening
- SQL comment bypass prevention strengthened per code review
- Branch deletion regex hardened for additional flag combinations
- `safe_targets` path traversal risk mitigated
- Dead code removed from hook files

### Documentation & OSS Prep
- README rewritten for public open-source audience ("The missing operating system for Claude Code")
- CONTRIBUTING.md added with setup guide, workflow, and contribution guidelines
- Launch content drafted (Show HN, Reddit, dev.to)
- Threat model templates created (kept private — not in repo)
- Note: `fw-review-forensics` (formerly `ai-code-forensics`), `fw-review-silent-failures` (formerly `silent-failure-hunter`), `fw-review-type-design` (formerly `type-design-analyzer`) agents and `/tdd-commit`, `/ship` skills were landed in the v0.3.x development cycle; see v0.3.0 entry.

### Bug Fixes
- Fixed invalid `local` keyword outside function in `fw-sync.sh`
- Fixed hook import patterns for consistency across 8+ hooks

---

## v0.3.0 - Security Hardening + Migration Script + Visual QA (Insight #3)

### Summary
Six enhancements (safety gates, cost management, conflict resolution, team scaling, visual QA, retro) plus post-implementation security hardening fixing 3 Critical, 5 High, and 8 Medium issues found by multi-agent review. Includes automated migration script for existing projects.

### New Features
- **E1: Safety Gate Enforcement**: `auto-approve.py` uses `block()` (exit code 2) for dangerous patterns. Hooks split into `settings.json` (shared/committed) and `settings.local.json` (personal/gitignored).
- **E2: Cost Management**: Pre-review routing classifies changes by type and diff size to skip unnecessary agents. Model tiers: Opus/Sonnet/Haiku.
- **E3: Conflict Resolution Protocol**: Domain authority hierarchy with severity-based resolution and max 2 rounds before human escalation.
- **E4: Team Scaling**: Agent and skill distribution from global `~/.claude/` to project-local `.claude/`.
- **E5: Visual QA Skills**: `/browse <url>` and `/qa [--full]` for diff-aware visual testing.
- **E6: Retro Skill**: `/retro [7d|14d|30d]` for engineering retrospectives from git history.

### Security Hardening (Post-Review)
- **C-1**: `rm -rf` default-deny -- unlisted paths now blocked instead of falling through
- **C-2**: SQL comment bypass prevented -- `DELETE FROM users -- WHERE id=1` now correctly detected as missing WHERE clause
- **C-3**: Branch deletion regex hardened -- catches flag combos (`-vd`, `-Dr`) and `git push --delete`
- **H-1**: Removed `PGPASSWORD`/`DATABASE_URL` from auto-approved env prefixes (credential exposure risk)
- **H-2**: Corrected hook JSON format docs (`hookSpecificOutput` not `{"decision":"allow"}`)
- **H-3**: `gh pr merge` always falls through to user approval (prevents auto-merge)
- **H-4**: Test harness uses `set -uo pipefail` instead of `set -e`
- **H-5**: Settings guide documents correct exit code semantics
- **M-1**: `--force-with-lease` blocked alongside `--force`
- **M-2**: `init-project.sh` refactored with `handle_item` helper and `TOTAL_STEPS` variable
- **M-3**: `_approve_if_matches` helper reduces repetitive loop patterns
- **M-4**: `cat/head/tail .env` falls through to user prompt instead of auto-approving
- **M-6**: `qa.route_map` example added to `framework.yaml`
- **M-7**: Retro `tail -1` stats replaced with accurate `numstat + awk` approach
- **M-8**: Browse skill documents that `/qa` should not delegate to `/browse`

### Migration Script
- New: `scripts/migrate-v0.3.0.sh <project-dir> [--dry-run]`
- Patches auto-approve.py (preserves project-specific patterns like worktree paths)
- Extracts hooks from settings.local.json to settings.json
- Copies new skills (browse, qa, retro) and test harness
- Appends missing config sections to framework.yaml
- Replaces sherlock-review-gate.md and settings-guide.md
- Creates backups before all modifications
- Runs safety gate tests after patching

### Changes
- `auto-approve.py`: 6 patterns converted to `block()`, 5 new security patterns, `_approve_if_matches` helper, SQL comment normalization, secrets-file shell check
- `sherlock-review-gate.md`: Pre-Review Routing, Conflict Resolution, `/qa` in Agent Selection Guide
- `init-project.sh`: `handle_item` helper, `TOTAL_STEPS` var, fixed defaults for browse/qa/retro
- `framework.yaml`: 4 new config sections, removed unused `claude.safety_gate`, added `qa.route_map` example
- `.gitignore`: removed duplicate `.DS_Store`
- `settings-guide.md`: corrected hook format, added exit code semantics
- `retro/SKILL.md`: fixed stats gathering command
- `browse/SKILL.md`: documented `/qa` interaction note
- New: `scripts/migrate-v0.3.0.sh`, `test/test_safety_gate.sh` (36 test cases)

### Test Coverage
- 36 safety gate tests: 24 blocked patterns, 12 safe/fall-through patterns
- Covers: SQL comment bypass, branch deletion flag combos, force-with-lease, default rm -rf deny, credential env vars, PR merge fall-through

### Breaking Changes
- `rm -rf` on unlisted paths now blocked (previously fell through)
- `PGPASSWORD`/`DATABASE_URL` no longer auto-approved as env prefixes
- `settings.local.json.template` no longer contains hooks

### Migration Steps
- Run `bash scripts/migrate-v0.3.0.sh <project-dir>` (or `--dry-run` first)
- Manually update project CLAUDE.md (Quick Reference, Automatic Protections, Framework Version)
- Run `bash test/test_safety_gate.sh` to verify

---

## v0.2.0 - Template Enhancement: Rules, Skills, Hooks, Prompt Versioning (Insight #2)

### Summary
Major template enhancement bringing proven patterns from 5+ mature projects back into the framework. Adds modular rules system, invocable skills, enhanced hooks, prompt versioning, agent templates, and notification integration.

### New Features
- **Rules System**: 4 auto-loaded rule files in `.claude/rules/` (anti-patterns, security, database-migrations, sherlock-review-gate) extracted from CLAUDE.md for maintainability
- **Skills System**: 4 invocable skills (`/deploy`, `/health`, `/release-notes`, `/schema-check`) with YAML frontmatter
- **Enhanced Hooks**: `protocol-validator.py` (PostToolUse deployment warnings), `no-cd-commands.py` (PreToolUse directory escape prevention)
- **Shell Alias Generator**: `generate-shell-alias.sh` creates shell functions for quick session launching
- **Prompt Versioning**: Opt-in LLM prompt version tracking with migration templates and snapshot export
- **Agent Templates**: `.claude/agents/AGENT_TEMPLATE.md` for creating project-specific agents
- **Notification Integration**: `notify.sh` supports Discord/Slack webhooks with success/failure/warning types
- **Archive Management**: Documented thresholds and rotation strategy for insights and version history
- **Session State**: `.claude/state/` directory with documented state files for context persistence
- **Stack-Conditional Docs**: Guidance banners on docs that only apply to certain stack configurations
- **Settings Guide**: Comprehensive companion doc for permission model (allow/deny patterns, hooks)

### Changes
- CLAUDE.md reduced from 218 to ~160 lines by extracting rules to modular files
- Quick Reference table expanded with rules, skills, and archive entries
- `framework.yaml` gains 5 new config sections: rules, skills, archive, prompts, deployment, agents
- `init-project.sh` expanded from 5 to 9 steps (rules, skills, state dir, prompt versioning)
- Settings template adds deny patterns for secret file protection
- Deployment gate sends notifications when configured
- CI/CD pipeline adds notify-success job
- `next-insight-number.sh` scans archives to prevent number collisions
- `.gitignore` updated for state directory and prompt snapshots

### Breaking Changes
- FRAMEWORK_VERSION changed from 1.0.0 to 0.2.0 (corrected versioning)
- CLAUDE.md inline anti-patterns and security rules moved to `.claude/rules/`

### Migration Steps
- Existing projects: copy `.claude/rules/` and `.claude/skills/` directories from v0.2.0
- Update `config/framework.yaml` with new sections (rules, skills, archive, prompts, deployment, agents)
- Re-run `./scripts/init-project.sh`

---

## v0.1.0 - Initial Release

### Summary
Initial release of dev-framework template repository.

### New Features
- Config-driven architecture via `framework.yaml`
- Claude Code hooks: auto-approve, branch-check, merge-conflict-resolver, worktree-enforcer, branch-tracker, pre-compact
- TDD commit workflow (RED/GREEN/REFACTOR)
- Auto version bumping on merge to main
- Worktree-based session isolation
- Modular documentation templates (10 files)
- CI/CD pipeline with quality gate
- Security scanning workflow
- Server management scripts

### Setup
See [SETUP.md](SETUP.md) for first-time setup instructions.

