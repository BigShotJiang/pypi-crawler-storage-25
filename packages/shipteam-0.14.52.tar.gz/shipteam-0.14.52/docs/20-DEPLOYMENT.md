# Deployment Protocol

**Purpose**: Define deployment procedures, CI/CD pipeline configuration, and rollback strategies for all environments.

**When to update**: When changing the deployment pipeline, adding new environment variables, or modifying health check endpoints.

---

## Deployment Tiers

### Tier 1: Full Deployment

Use for: New features, significant refactors, database migrations.

1. All tests pass (unit, integration, E2E)
2. Code review approved
3. Documentation updated (features, insights, release notes)
4. Migration tested against staging database
5. Deploy via CI/CD pipeline
6. Verify health checks post-deploy
7. Monitor error rates for 15 minutes

### Tier 2: Simplified Deployment

Use for: Bug fixes, minor UI changes, configuration updates.

1. Relevant tests pass
2. Code review approved
3. Deploy via CI/CD pipeline
4. Verify health checks post-deploy

### Tier 3: Emergency Deployment

Use for: Production outages, security patches, critical hotfixes.

1. Minimal testing (affected area only)
2. Deploy immediately via CI/CD pipeline (fast deploy if available)
3. Verify health checks post-deploy
4. Follow up with full test suite within 24 hours
5. Post-incident review required

### Fast Deploy (Tier 3)

For emergency hotfixes when tests have been verified locally:

```bash
gh workflow run "CI/CD Pipeline" -f fast_deploy=true
```

**When to use**:
- Hotfixes that have been tested locally
- Config/docs-only changes
- User has explicitly authorized skipping CI tests

**Requires justification**: Document why tests were skipped in the PR description.

**Mandatory post-deploy**: Run `/health` skill immediately after deploy completes. Monitor for `deployment.post_deploy_monitoring_minutes` (configured in `framework.yaml`, default 15 minutes).

**DO NOT use for**: New features, refactors, or untested changes.

## CI/CD Pipeline

```
Push to branch --> Run tests --> Build --> [Approval gate] --> Deploy --> Health check
```

- **Trigger**: Push to main branch or manual workflow dispatch
- **Stages**: Lint, Unit Tests, Integration Tests, E2E Tests, Build, Deploy
- **Fast deploy**: Skips test stages (Tier 3 only, requires justification)

### Branch Protection Enablement

Required status checks and required-review rules live in GitHub repository settings, not in this repo. To enable programmatically with `gh` CLI:

```bash
gh api -X PUT /repos/OWNER/REPO/branches/main/protection \
  -F required_status_checks.strict=true \
  -F required_status_checks.contexts[]=backend-tests \
  -F required_status_checks.contexts[]=frontend-tests \
  -F required_status_checks.contexts[]=env-secrets-guard \
  -F required_status_checks.contexts[]=bright-line-guard \
  -F enforce_admins=true \
  -F required_pull_request_reviews.required_approving_review_count=0 \
  -F restrictions=
```

Solo-maintainer note: set `required_approving_review_count=0` (already shown above) so you can merge your own PRs. Set `enforce_admins=true` so branch protection applies to you as well. Branch protection is free on public repos; private repos require GitHub Pro or higher. See [GitHub branch-protection REST API](https://docs.github.com/en/rest/branches/branch-protection) for the full option set.

The `bright-line-guard` context corresponds to the job added by ADR-007. It lives in its own workflow (`.github/workflows/bright-line-check.yml`) rather than inside `ci-cd.yml` so that unrelated issues in the larger pipeline cannot silently disable the policy gate. See `scripts/validate-no-bright-line.sh` for the scanner and `.pre-commit-config.yaml` for the local-first variant.

## Environment Variables

See [45-ENVIRONMENT.md](45-ENVIRONMENT.md) for the complete variable reference.

Before deploying, verify that all required environment variables are set in the target environment.

## Health Checks

| Endpoint | Expected | Timeout |
|----------|----------|---------|
| `GET /health` | `200 OK` | 5s |
| `GET /api/health` | `200 OK` with service status | 10s |

Post-deploy verification:
```bash
# Replace with your actual health check command
curl -f https://your-app.example.com/health || echo "HEALTH CHECK FAILED"
```

## Rollback

### Automatic Rollback
If the health check fails within the deployment pipeline, the previous version is restored automatically (if supported by the hosting platform).

### Manual Rollback
1. Identify the last known good commit: `git log --oneline -10`
2. Revert: `git revert <bad-commit>` (preferred over force-push)
3. Push the revert commit and let CI/CD redeploy
4. If database migrations were involved, run the corresponding down migration

### Version Management
- Version numbers auto-increment on merge to main (if configured)
- Manual override: `./scripts/bump-version.sh X.Y.Z` (only if auto-bump fails)
- Never manually edit version numbers in source when auto-bump is active

---

## PyPI Release Process (ADR-020)

ShipTeam publishes to PyPI via OIDC Trusted Publishing. Publishing is **not** automatic on every merge — it requires a conscious human action (creating a GitHub Release).

### One-Time Operator Setup (before first publish)

1. **Create a GitHub Environment** named `release` in this repo's Settings → Environments. Add required reviewers if desired (recommended: at least 1).

2. **Register a Trusted Publisher on PyPI.org** at https://pypi.org/manage/account/publishing/ with these fields:
   - PyPI project name: `shipteam`
   - GitHub owner: `<your-github-username-or-org>`
   - Repository name: `<this-repo-name>`
   - Workflow filename: `pypi-publish.yml`
   - Environment name: `release`

3. **No API token needed** — OIDC handles authentication. Do not create a `PYPI_API_TOKEN` secret.

4. **SHA-pin the third-party actions** before first publish (see TODO comments in `pypi-publish.yml`):
   ```bash
   # Pin actions/download-artifact
   gh api repos/actions/download-artifact/git/ref/refs/tags/v4 --jq '.object.sha'
   # Pin pypa/gh-action-pypi-publish
   gh api repos/pypa/gh-action-pypi-publish/git/ref/refs/heads/release/v1 --jq '.object.sha'
   ```
   Replace `@v4` and `@release/v1` with `@<sha> # v4` and `@<sha> # release/v1` respectively.

### Release Checklist (per release)

1. Verify all intended PRs have merged to `main`.
2. Confirm `wheel-audit` CI check is green on main.
3. Note the auto-bumped tag: `git tag --sort=-version:refname | head -1` (e.g., `v0.14.50`).
4. Create the GitHub Release:
   ```bash
   gh release create v0.14.50 --title "v0.14.50" --notes "See release_notes.md"
   ```
   Or navigate to Releases → "Draft a new release" → select the tag → Publish.
5. The `pypi-publish` workflow triggers automatically. Monitor it in Actions:
   - `build-and-audit` job: builds artifacts, runs `wheel_audit.py`, must exit 0.
   - `publish` job: downloads artifacts, publishes to PyPI via OIDC; only runs if `build-and-audit` succeeded.
6. Verify the release on PyPI: `pip install shipteam==<version>` in a fresh venv.

### Troubleshooting

| Symptom | Likely cause | Fix |
|---------|-------------|-----|
| `publish` job skipped | `build-and-audit` failed (audit violation or build error) | Check `build-and-audit` logs; fix the violation; re-publish by deleting and re-creating the Release |
| OIDC token error | Trusted Publisher not configured, wrong environment name, or wrong workflow filename | Verify PyPI Trusted Publisher fields match exactly |
| `attestations: false` needed | `pypa/gh-action-pypi-publish#283` — attestation generation fails in some CI contexts | Already set in `pypi-publish.yml`; no action needed |
| Wheel audit BRIGHT_LINE false positive | A doc or code file contains a pattern from the ADR-007 blocklist | Remove the pattern from the source file and rebuild |
