# ADR-017: Benchmark Harness Architecture (v1)

## Status

PROPOSED (becomes ACCEPTED when this ADR's PR merges)

## Context

The ShipTeam thesis pivot of 2026-04-14 (see project memory `project_thesis_pivot_2026_04_14.md`) reframed the product around conformance-measured AI code quality. The benchmark harness is the empirical instrument that makes that thesis testable: it runs candidate AI drivers (Claude Code, Aider, Droid) against pinned task packs in pinned containers, scores the resulting workspaces in a separate eval phase, aggregates median + IQR over N=10 runs per cell, and renders a static HTML dashboard subject to the ADR-007 bright-line sanitization gate.

Prior to this ADR the harness existed as a `.sherlock-plan.md`-anchored design across three Sherlock cycles (Phase 1, Phase 2 with two parts, Phase 3 with sub-phases A1/A2/A3/A4). That plan accreted ~1,100 lines of spec, three rounds of `/deep-r` validation, six or more rounds of fw-author-test-strategy + per-phase reviews, and a non-trivial Pivot Log. Per the Sherlock methodology Step 8 protocol, the plan's architectural rationale is now extracted to ADR form so the spec artifact can be retired. Without extraction, the architectural intent disappears the moment `.sherlock-plan.md` is deleted.

A4 (this sub-phase, the closing one) is the trigger for the extraction.

## Decision

The v1 harness is built around five architectural choices, each rooted in a specific failure mode that the alternative would have made silent.

**1. Docker containerization with tmpfs workspaces, fresh git clone per run, `.git` history sanitized.**
Reproducibility is the non-negotiable spine. Without `.git` sanitization a driver can `git log` into future fix commits — the SWE-Bench#465 leak class. Firecracker / microVM isolation was rejected as overkill: the threat model is measurement validity (the driver must not see the answer), not escape (the driver is not adversarial code).

**2. A shared `Driver` protocol over three process-exec adapters with per-driver cost-extraction shims (`drivers/_cost_extraction.py`).**
The Claude Code Agent SDK exposes `total_cost_usd` and `usage` natively; Aider has no JSON output and `/tokens` is an in-chat command; Droid's `--output-format json` omits tokens/cost. Hardcoding any one driver's cost shape into the runner would have made adding the second driver a runner refactor. The shim pattern moves the heterogeneity into one module that the rest of the codebase reads as uniform `DriverResult` rows.

**3. Append-only JSONL as the single source of truth.**
Every downstream view — aggregator, dashboard, future regressions analysis — reduces to "read JSONL, project fields." Rebuilding the dashboard never requires rerunning a driver. Schema evolves additively.

**4. N=10 runs per (driver, task, seed) cell with median + IQR aggregation; observed variance reported, not bounded.**
Claude has no seed parameter and `temperature=0` is not deterministic (Anthropic docs explicit on this). No peer-reviewed Claude-specific variance bound exists in the 2024-2026 literature, so the harness reports observed variance rather than asserting a synthetic one it cannot defend.

**5. Static HTML dashboard with a denylist gate that fails closed before any file write.**
The dashboard is the single public surface where measurement results meet the ADR-007 bright-line policy. The gate (`dashboard/render.py:_check_denylist`) runs against the rendered HTML — not the template source, since template-level labels are what end up in published output. As of A4 (this sub-phase), the empty-denylist case is also fail-closed: a denylist that parses zero tokens raises `ValueError`. A3's fail-open-with-warning was a misconfiguration-tolerant policy that, in retrospect, allowed a misconfigured deployment to ship rendered output that bypassed every check.

Additional MUST-HAVE invariants encoded as Acceptance Criteria in the (now-retired) plan:
- **AC-3** prompt cache disabled on benchmark API calls (Anthropic cache is org-scoped within a 5-minute TTL; cells would otherwise contaminate each other's billing and latency).
- **AC-9** corpus-gate (`scoring.injected_bugs.validate_corpus`) raises `CorpusError` at sweep start. A permissive corpus ships meaningless sensitivity numbers forever.
- **AC-11** SDK version gate. Prevents a re-occurrence of the silent-3× cost bug in `anthropics/claude-agent-sdk-python#487`.
- **AC-13** post-drive sandboxed scoring (the SWE-Bench pattern). Drivers never run their own acceptance tests.
- **AC-14** prompt cache disabled (covered above; called out separately because the failure is silent and load-bearing).
- **AC-15** denylist gate runs before file write, raises `RuntimeError` on token match (atomic-write semantics: no `.tmp` is ever materialized when the gate fires). A4 hardens the empty-denylist case to also fail-closed (`ValueError`).

## Consequences

### Positive

- **Reproducibility is structural, not procedural.** A leaked answer would require a Docker daemon bug or a git history reconstruction inside a tmpfs that has no parent — neither is reachable from a misconfigured driver.
- **Adding a new driver is local.** New drivers implement the `Driver` protocol and add a cost-extraction adapter; the runner, aggregator, scorers, and dashboard are untouched.
- **The dashboard cannot publish a denylist-leaked artifact.** Three independent gates (bright-line CI scan against `config/bright-line-allowlist.txt`, manual git review, runtime denylist) block the leak path. With A4's empty-denylist fail-closed flip, a misconfigured deployment can no longer silently bypass the runtime gate.
- **JSONL durability.** A v2 dashboard, a regression report, or a third-party consumer can read historical sweep data without rerunning.

### Negative

- **Variance is reported, not bounded.** A reader of a single `acceptance_pct` column cannot reason about whether a 5-point gap is significant without consulting the IQR column or the underlying distribution. This is honest given the lack of a published variance bound, but it raises the bar for a casual reader.
- **Per-driver cost-extraction shims are a maintenance surface.** Every driver upgrade is a potential schema break. The `drivers/_cost_extraction.py` module is the canary — any unhandled output shape there raises rather than silently zeros. Bus-factor risk on the shims; mitigation is hand-authored fixtures locking the contract.
- **A4-1 fail-closed empty-denylist policy makes a misconfigured CI loud.** The previous fail-open-with-warning behavior would render a dashboard with no enforcement — the new behavior raises `ValueError` and writes nothing. Operators with empty denylist files (intentionally or accidentally) will see CI break. The trade-off is: a loud break is recoverable; a silent ship of leaked content is not.
- **DELIBERATELY DEFERRED: H-1 — UTS #39 skeleton algorithm for cross-script confusable handling.** A3's reviewer flagged that `_normalize_for_denylist` covers only six Cyrillic→Latin lookalikes; Greek (`ρ`→`p`), Armenian (`ո`→`n`), combining diacritics, U+2060 word joiner, and U+180E Mongolian vowel separator are not covered. A4 chose not to ship the UTS #39 dependency. **Rationale**: closing five of N Unicode bypass classes by hand is theater at the v1 threat model. The "attacker" must control either a benchmark prompt or a driver's output — both are local-controlled paths in the v1 harness, with no untrusted-input ingress. If they did control either, they have unboundedly many bypass vectors beyond Greek/Armenian (U+205F medium math space, tag chars U+E0000-U+E007F, full-width Latin, mixed scripts). The dashboard denylist is the third of three ADR-007 gates and rendered HTML is not committed in this repo today. **Trigger to revisit**: dashboard outputs become public-facing OR an untrusted-input-fed path lands in the harness.
- **DELIBERATELY DEFERRED: M-3 — DA-15 parametrize expansion to combining diacritics, U+2060, U+180E, Greek, Armenian.** Pairs with H-1 above; tests drive the data set so adding the parametrize cases without first shipping UTS #39 would parametrize a bypass-detection oracle the implementation cannot satisfy. **Trigger to revisit**: same as H-1.

### Neutral

- **Sub-phase B+ research questions are catalogued, not committed to.** RQ-1 (RED-with-N-candidates + critic-select vs single-shot) and RQ-2 (parallel-lens vs single-lens `/deep-r` at Step 4.5) are recorded in the plan's "Open Research Questions" block. The harness is the instrument that will answer them; whether the answer becomes a feature is gated on Δ-detection ≥ 5pp at Δ-cost ≤ 3× for RQ-1 and on user judgment for RQ-2.
- **The `.sherlock-plan.md` artifact is retired alongside this ADR.** Execution-state details (Pivot Log, Decision Digest, planned-files tables, the test matrix) are not persisted — the shipped tests themselves are the record of coverage; this ADR captures rationale.
- **`.test-matrix.md` is also retired.** It served fw-review-tests during the active spec; its P0/P1/P2 attribution lives in the test docstrings (`DA-N (P-tier, AC-#)`) and is recoverable from those.

## References

- ADR-007 — Bright-line sanitization (the policy this harness's denylist gate enforces)
- ADR-011 — Conformance scorer v2 scope boundary
- ADR-016 — Empirical CLI probe before TDD against external tools (the lesson from Phase 2 Part 2)
- Project memory: `project_thesis_pivot_2026_04_14.md` (conformance-measured thesis), `project_benchmark_harness_plan.md` (this plan), `project_unverified_claims_log.md` (claims to validate before external citation)
- Anthropic docs: prompt cache TTL semantics; temperature=0 non-determinism statement
- SWE-Bench#465 — git history leak class
- `anthropics/claude-agent-sdk-python#487` — silent 3× cost regression
- mutmut #349 — silent false-negative on test-suite-crashing mutants
- Semgrep #3147 — `--config <URL>` no-cache (5yr open)
- Stryker #2519 — SIGTERM orphan children on Linux
