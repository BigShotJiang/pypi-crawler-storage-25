# ADR-009: Enhanced Lead Orchestrator — Artifacts Over Reasoning

## Status
PROPOSED

## Context

The Sherlock/Holmes methodology already ships a lead-orchestrator pattern: a Claude session decomposes tasks, spawns specialist subagents (22 of them as of v0.13.7), and applies mechanical conflict resolution via a severity+domain-authority table. Exploring "what would an enhanced lead look like?" surfaced a tempting direction: **make the lead smarter at runtime** — add cross-reviewer synthesis, user modeling, proactive risk flagging, adaptive routing, and possibly a devil's-advocate subagent for adversarial critique.

Before building, we invoked `/deep-r` (three parallel research agents) to validate the proposal against current literature and production patterns. The research returned a counter-result worth recording.

**Evidence summary**:
- Anthropic's published multi-agent research (2025): lead earns its keep through **decomposition and subagent briefing with objective/output-format/tool-guidance/boundaries**, not through synthesis. File-based artifact passing prevents "game of telephone." Multi-agent systems use ~15× the tokens of chat; **token usage alone explains 80% of performance variance** (BrowseComp). Anthropic explicitly flags **coding as poorly suited to multi-agent** because subtasks carry entangled implicit decisions.
- Cognition's "Don't Build Multi-Agents" (2025): parallel subagents in a coding domain produce incoherent outputs because "actions carry implicit decisions" sibling agents can't see. Recommendation: single-threaded agent with context compression.
- "When Agents Disagree" (arXiv 2603.20324): **selection beats synthesis**. Homogeneous teams with good selection rules outperform heterogeneous teams with deliberation layers. The existing domain-authority table is already the right shape.
- Debate / Self-Refine literature (arXiv 2511.07784, Nature npj AI s44387-025-00045-3): self-critique and formal debate patterns underperform in controlled 2025-2026 studies. Production shipping evidence thin. Each round adds N×R cost with diminishing returns past ~3 agents / 2 rounds.
- Human tech-lead literature (Will Larson staffeng.com, Camille Fournier "The Manager's Path," Lethain): effective leads externalize priorities into **written artifacts** (plan, ADR, priority list). They don't romanticize in-head synthesis.
- Simon Willison ("context plumbing"): every token the lead spends re-narrating subagent output is a token a specialist could spend on the real problem.

The signal is consistent across primary sources: **thick planning boundaries + thin execution + file-based artifact passing** is the defensible pattern. Thicker execution-phase leads and synthesis layers are evidence-negative.

## Decision

Adopt the **Artifacts-Over-Reasoning** pattern. Three concrete additions, aligned to Step 0/1/4.5/6/8 of the Sherlock methodology:

1. **One new specialist agent**: `fw-author-test-strategy` (Sonnet, 12 turns). Proactive test matrix authoring from `.sherlock-plan.md` Acceptance Criteria. Produces `.test-matrix.md` with risk-tiered tests (P0/P1/P2), type classification (unit/integration/e2e), and oracle hints (direct-assertion for obvious oracles; metamorphic/differential/property-based candidates for non-obvious ones). Invoked **once** per plan (Lite Step 1 or Full Step 4.5 post-validation) and consumed by `fw-review-tests` at every per-phase review gate. Skipped for Hudson and for doc-only plans.

2. **Two new durable plan-artifact sections** in `.claude/spec-format.md`:
   - `## Lead Judgment` — **Priority Stack** (3-5 bullets of what matters and why; the Larson anti-snacking gate) + **Risk Watch** (specific risks tied to THIS changeset, not generic). Written at plan creation; updated only on major pivots.
   - `## Decision Digest` — Append-only per-phase review outcomes. One block per phase (`Fired | Critical/High | Deferred | Inherited | Digest`). Always written — zero findings is itself a signal.

3. **One Step 0 enhancement**: User-Preference Lens that prepends a single-line `User context: [up to 3 MEMORY.md entry titles]` citation to the classification output. Hard bounds: ≤3 titles, ≤200 chars, single line. Live conversation only — forbidden in any persisted artifact (see Consequences / Security below).

## Consequences

### Positive
- **Lead sophistication survives compaction**: priorities and risks live in a file, not in-head. When context compacts, they're still there.
- **Test strategy becomes a first-class artifact**: coverage decisions (tier, type, oracle) are made once by a specialist and persisted. `fw-review-tests` becomes proactive (checks matrix compliance) rather than purely reactive. Mirrors the spec/code/review separation already established for production code (fw-author-spec / fw-tdd-red / fw-review-code).
- **Memory-aware routing without re-asking**: Step 0 lens surfaces relevant user preferences at classification time. Matches the intent of the auto-memory system.
- **Zero new reasoning layers**: the lead's job doesn't get harder at execution time. Token budget continues to favor specialists (the 80%-variance-from-workers finding).
- **Evidence-backed restraint**: explicit non-goals (no debate layer, no devil's-advocate agent, no thick execution synthesis) are documented with citations so future refactors don't re-litigate.

### Negative
- **Artifact discipline becomes load-bearing**: if the lead forgets to append to Decision Digest after a review gate, the audit trail is lost. Mitigated by restating the obligation in `sherlock-methodology.md` Steps 4 and 6, and in the Decision Digest template comment.
- **Test matrix timing coupled to Step 4.5**: test-strategy is invoked after plan validation incorporates findings; if a late-stage AC update happens during TDD, the matrix goes stale. Mitigated by an explicit "re-invoke on AC change" clause in methodology.
- **One additional agent in the ecosystem**: 23 agents instead of 22. Scope clearly distinct from fw-review-tests (reactive), fw-tdd-red (test code), and fw-author-spec (ACs) — enforced via the new agent's Scope Constraints.
- **Hudson stays simple by exemption**: the new capabilities do not apply to Hudson (1-2 file fixes). Adds a small asymmetry that must be remembered.

### Neutral
- **Step 0 user-preference lens adds a consult-memory step to every task** — but MEMORY.md is already auto-loaded into Claude's context, so the cost is marginal (a single line of output; no new file reads).
- **fw-review-tests bifurcates its behavior** (matrix vs. no-matrix path). The no-matrix fallback is identical to current behavior, so older projects that haven't synced remain unaffected.

### Security (CRITICAL — ADR-007 bright-line sanitization interaction)
The Step 0 lens reads auto-loaded MEMORY.md content. The live MEMORY.md in this repository contains business-strategy entries whose **titles alone** (e.g., "Pricing dead zone," "Revenue targets: conservative," "Platform risk: Anthropic absorption timeline") encode strategy. ADR-007 establishes the bright-line sanitization rule: no strategy content in the committed tree.

Mitigation — no-persist rule restated in FOUR locations:
1. `.claude/rules/sherlock-methodology.md` Step 0 (the rule's primary locus)
2. `.claude/spec-format.md` Lead Judgment guidelines
3. `.claude/spec-format.md` Decision Digest guidelines
4. `.claude/agents/fw-author-test-strategy.md` Scope Constraints

The rule: `User context:` line lives in live conversation only. Never written into `.sherlock-plan.md`, `.test-matrix.md`, Pivot Log, Decision Digest, Lead Judgment, `.claude/state/*`, or any Write/Edit tool content. MEMORY.md body content is forbidden everywhere; titles are permitted only in live conversation output (never in persisted artifacts).

Final-gate security review flagged this as Critical (C1) before commit; fix applied in-situ. Residual risk: future hooks (pre-compact.py, fw_event_log.py) could capture conversation output containing the User context line. Hook-side redaction remains a follow-up (tracked separately — not in this ADR's scope).

## Alternatives Considered

1. **Devil's-advocate / red-team subagent for cross-domain synthesis** — rejected. /deep-r at Step 4.5 already provides the adversarial function cheaply with citation hygiene. Controlled debate studies (arXiv 2511.07784) show limited gains; Self-Refine (arXiv 2303.17651) rarely flips wrong→right in controlled settings.

2. **Multi-agent debate (MAD) pattern** — rejected. Du et al.'s ~20% factuality gains don't generalize; follow-up studies find intrinsic reasoning strength + team diversity dominate over structural parameters. N×R cost blowup is real.

3. **Thick execution-phase lead synthesizing reviewer outputs** — rejected. Burns 15× token tax without parallelism payoff (Anthropic's own finding); every re-narration is a fresh hallucination surface (Willison).

4. **Terminal-based parallelism** (user's original proposal: spawn multiple interactive Claude sessions) — rejected jointly with the user. Merge-conflict surface is enormous for entangled coding work (Cognition). Agent Teams mode exists for task-based parallelism but doesn't give the user per-session interactive terminals.

5. **Persist `.test-matrix.md` as `docs/testing/NNN-*.md`** — rejected. Over-ceremony for an execution artifact whose value is phase-spanning, not historical. Shipped tests are the coverage record; the ADR captures rationale.

6. **Authoring-phase cost routing in `scripts/cost_routing.py`** — deferred. `cost_routing.py` is a review-phase router; adding an authoring-phase subsystem is out of this PR's scope. Test-strategy invocation lives in the methodology prompt with a doc-only skip rule.

## References

- [Anthropic — How we built our multi-agent research system](https://www.anthropic.com/engineering/multi-agent-research-system)
- [Cognition — Don't Build Multi-Agents (HN)](https://news.ycombinator.com/item?id=45096962)
- [When Agents Disagree — arXiv 2603.20324](https://arxiv.org/html/2603.20324)
- [Can LLM Agents Really Debate? — arXiv 2511.07784](https://arxiv.org/pdf/2511.07784)
- [Self-Refine limits — Nature npj AI s44387-025-00045-3](https://www.nature.com/articles/s44387-025-00045-3)
- [Will Larson — Manage technical quality](https://staffeng.com/guides/manage-technical-quality/)
- [Camille Fournier — The Manager's Path](https://www.oreilly.com/library/view/the-managers-path/9781491973882/)
- [Simon Willison — Context plumbing](https://simonwillison.net/2025/Nov/29/context-plumbing/)
- [Virtuoso — Agentic test planning](https://www.virtuosoqa.com/post/agentic-ai-test-planning-autonomous-test-strategies)
- [OpenObserve — Autonomous QA w/ Claude Code](https://openobserve.ai/blog/autonomous-qa-testing-ai-agents-claude-code/)
