# ADR-001: Config-Driven Framework Architecture

## Status
ACCEPTED

## Context
When building a development framework for AI-assisted coding, we needed to decide between hardcoding behavior into scripts vs. making the framework configurable. The framework needs to support multiple projects with different tech stacks, conventions, and safety requirements.

## Decision
Use a config-driven architecture where `config/framework.yaml` defines framework behavior, and hooks/scripts/rules/skills/agents all read from this configuration. The framework is a harness — not a monolith — that adapts to each project via configuration.

## Consequences

### Positive
- Projects can adopt the framework without forking it
- New safety gates, skills, and agents can be added without changing core code
- `fw-sync.sh` can propagate framework updates while respecting project-specific config
- Clear separation between framework behavior (config) and implementation (scripts)

### Negative
- More indirection — understanding behavior requires reading config + implementation
- Config schema must be maintained and documented
- Breaking config changes require migration support

### Neutral
- Teams need to learn the config schema to customize the framework
