# ADR-008: Zero-Friction Installer — Separate `shipteam init` from `fw-sync`

## Status
PROPOSED

## Context

Onboarding friction was the largest barrier to ShipTeam adoption. The legacy flow required a user to:

1. Clone the framework repo as a template (`gh repo create --template`)
2. Edit `config/framework.yaml` by hand
3. Run `scripts/init-project.sh` — a 534-line bash wizard with 17 interactive steps
4. Manually edit 11 `<!-- CUSTOMIZE -->` markers in `CLAUDE.md`
5. Install the hooks template, scaffold `.claude/`, and verify — each a separate step

The bash wizard had no tests, had accumulated ad-hoc logic across four minor releases, and served two partially-overlapping jobs: first-time bootstrap and subsequent framework updates. The update path (`fw-sync.sh`, 935 lines, battle-tested) already existed as a separate, working tool. Every comparable ecosystem that tried to merge bootstrap and update into a single tool (Yeoman) failed at updates; every ecosystem that kept them separate (`npm init`/`update`, `cargo init`/`update`, `create-next-app`/`next upgrade`, Copier `copy`/`update`, `pre-commit install`/`autoupdate`) succeeded.

We needed a modern installer that was:
- Zero-clone: users type one command and have a working project.
- Zero-hand-edit: no `CUSTOMIZE` markers for users to fix.
- Testable: every acceptance criterion encoded as a failing-first test.
- Distribution-native: PyPI via `uvx` and npm via `npm create` are the two ecosystems new users already live in.
- Idempotent: re-renderable as the framework evolves, without destroying user customizations.

## Decision

Introduce `uvx shipteam init` as a separate Python CLI distributed via PyPI, with a thin `npm create shipteam` shim for Node-native teams. `fw-sync.sh` remains untouched for framework update workflows. Two tools, two clear jobs, no overlap.

Architectural properties:

- **Bundled framework source**: the full framework tree (agents, rules, skills, hooks, templates) ships as `package_data` inside the Python wheel. No network fetch at install time.
- **Jinja2 `CLAUDE.md.jinja` template** renders a fully-populated `CLAUDE.md` with zero `CUSTOMIZE` markers. Rendered through `ImmutableSandboxedEnvironment` to block SSTI when a user supplies their own `--framework-dir`.
- **Managed regions** (`<!-- SHIPTEAM:BEGIN:name -->` / `<!-- SHIPTEAM:END:name -->`) let `uvx shipteam init --refresh` re-render the framework-owned parts of `CLAUDE.md` while preserving user edits outside (and, by default, inside) those regions. Preservation-default matches `rsync`/`git merge` conventions; `--force` overrides.
- **Version handshake**: `min_cli_version` + `schema_version` in `framework-meta.yaml`. CLI semver compare uses `packaging.version.Version`; schema uses `>` (forward-compatible — a newer CLI accepts older schemas).
- **Exit-code vocabulary**: 0 success, 1 conflict (no `--force`), 2 missing input, 3 template-rendering error, 4 version/config mismatch. All errors to stderr; no tracebacks leak to CI logs.
- **Security defaults**: symlink refusal on source trees, target dirs, and `--framework-dir`; `--repo` regex validation blocks marker-injection into managed regions; atomic state writes (`os.replace`); `yaml.safe_load` everywhere.

Implementation delivered in six TDD phases with per-phase Sherlock review pipelines:

1. Detection + config + security + state (26 tests)
2. Jinja rendering + managed regions (23 tests)
3. Framework source resolution + `.claude/` scaffolding (40 tests)
4. Click CLI + `python -m shipteam` entry (18 tests)
5. npm shim + bundled `package_data` (13 tests)
6. Delete `scripts/init-project.sh` + migrate 14 documentation files

Final test count: 133 passing, 1 documented xfail (CliRunner cannot simulate `isatty()=True` with `input=`; real-TTY prompting covered by manual QA).

## Consequences

### Positive
- **Adoption friction drops to one command.** New users type `uvx shipteam init` and have a working project in ~30 seconds.
- **Testability arrives.** 133 tests now cover what was previously 534 untested lines of bash. Every AC from the spec is a failing-first test.
- **Separation of concerns validated.** Bootstrap and update are separately designed, separately testable, separately releasable. `fw-sync.sh` stays untouched.
- **Security posture is measurably stronger.** Sandboxed Jinja, symlink refusal, typed exit codes, atomic writes, `--repo` validation — all fixes from parallel security review pipelines before merge.
- **Managed regions unlock sustainable framework evolution.** Future CLAUDE.md improvements ship via `--refresh` without requiring users to manually merge upstream changes.
- **Two distribution channels reach two communities.** PyPI for Python/ML-native teams (`uvx` is the modern standard); npm for JS/Node-native teams (`npm create shipteam` is the familiar pattern).

### Negative
- **Two tools to maintain.** `shipteam init` (Python) and `fw-sync.sh` (bash). The working `fw-sync` stays as-is, but a future change that affects both will require two parallel updates.
- **Bundled framework content duplicates `.claude/`.** `src/shipteam/framework/` ships the same content that exists at repo root. A small sync contract is needed (currently: manual copy at release time; future: a CI check that asserts parity).
- **Profile-level skill filtering is deferred.** Rules are properly file-filtered by profile; skills are copied wholesale (`*` at all profile levels) because skills are directories not files. Directory-level filtering lands in v1.1.
- **Interactive TTY tests are untestable under CliRunner.** AC-2 has one `xfail` test; real-TTY behavior is verified manually. Switching to `pexpect`/`ptyprocess` subprocess tests would close this gap at the cost of ~2x test runtime.
- **`feature_tier` migration is a breaking change** already shipped in v0.13.0; this ADR codifies the installer-side implication (`uvx shipteam init --refresh` is now the documented remediation path).

### Neutral
- The npm shim is delegation-only — it detects a Python runtime and invokes it. There is no separate Node implementation to maintain.
- `.shipteam-init.yaml` is a new state artifact in user projects. It is gitignored by default (AC-14).
- Phase 4's AC-2 xfail is documented in the test file itself and in release notes, so future maintainers encountering the xfail understand the tradeoff without git-archaeology.

## Alternatives Considered

- **(A) Fix the bash wizard in place.** Rejected — no test framework exists for bash at this complexity level, the wizard had already accumulated four releases of ad-hoc patches, and bundling and rendering are not bash's strong suits.
- **(B) Merge bootstrap and update into one tool.** Rejected with industry evidence — Yeoman tried this and failed at updates; every successful bootstrap-plus-update separation in Copier/Cargo/npm/pre-commit keeps the two jobs distinct.
- **(C) Remote tarball fetch at install time.** Rejected for v1 — bundled `package_data` works offline, has no CDN dependency, and pins the user to a specific framework version matched to their CLI. Tarball fetch is deferred to a future phase if/when offline installs become less common.
- **(D) Online license enforcement for Pro features.** Rejected — `feature_tier` was removed in v0.13.0 (ADR-006); all 22 agents now install unconditionally. Community/Pro split lives at the repo-publication layer, not the installer. Honor-system for v1.

## Related

- Supersedes: `scripts/init-project.sh` (deleted in this change)
- Related: ADR-006 (feature_tier removal — installer-side implication), ADR-007 (bright-line sanitization — framework content shipped in `src/shipteam/framework/` is public-safe)
- Sources for the separation argument: Copier docs, Cookiecutter+cruft drawbacks, Next.js upgrade docs, pre-commit docs
