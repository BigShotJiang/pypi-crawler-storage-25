# ADR-013: Math Verification as a Lead-Invoked Skill, Not a 23rd Agent

## Status
PROPOSED

## Context

Review agents — particularly `fw-review-security`, `fw-advisor-architecture`, and `fw-review-performance` — regularly produce numeric claims that drive action: Argon2id memory×iterations, rate-limit sizing, cost projections, P50/P95/P99 latency budgets, Big-O arguments, migration row-count estimates. These claims were unchecked LLM arithmetic. Published research (GSM-Symbolic, arXiv 2410.05229; PAL, NeurIPS 2023; "Dissecting Multiplication in Transformers", arXiv 2407.15360) shows frontier models lose up to 65% accuracy on multi-step numeric reasoning and fail multi-digit multiplication because transformer architecture cannot cache intermediate carryovers. External tool offload is the established remediation pattern (Anthropic's canonical tool-use example is a calculator function; the Claude API ships a `code_execution_20260120` tool for this).

The obvious design — "add a dedicated math subagent that reviewers can consult" — is structurally blocked by current Claude Code:

- **Issue #38719**: subagents cannot invoke the Skill tool.
- **Issue #29441 / #25834**: `skills:` frontmatter is silently ignored for teammates / plugin-deployed agents.
- **Issue #4182 / #19077 / #23506**: subagents cannot spawn subagents.

Every "reviewer-invokes-math-verifier" architecture fails against at least one of these.

## Decision

Deliver math verification as a **lead-invoked `/verify-math` skill** plus an inline `## Math Verification` section added to the three math-touching reviewer agents. The skill shells out to Python via `Bash` (a tool the reviewers already have) and cross-verifies expressions using SymPy (symbolic) and NumPy via `sympy.lambdify` (numeric). Results are cited against NIST DLMF, IEEE 754, or SEMATECH e-Handbook. Invocations are logged to `.context/metrics/events-YYYY-MM.jsonl` for 30 days of signal collection before deciding whether to promote to a dedicated agent.

Key implementation constraints chosen for security:

1. **No `eval()` on user input.** The initial implementation used `eval(expression, {"__builtins__": {}}, safe_ns)` — a known-broken Python sandbox that reviewers reproduced as RCE via `sqrt.__class__.__mro__[-1].__subclasses__()`. The final implementation uses `sympy.lambdify(parsed_expr, modules="numpy")` on the AST produced by `parse_expr`, so user strings never reach eval.
2. **AST pre-filter before `parse_expr`.** SymPy's `parse_expr` internally calls `eval` with `__builtins__` accessible — `__import__('os').system('echo pwned')` actually executed during testing. `_prevalidate_expression()` walks the raw string with `ast.parse(mode="eval")` and rejects any node outside a strict whitelist (`BinOp, UnaryOp, Constant, Name, Call, Pow, Mult, Div, Add, Sub, Mod, USub, UAdd, FloorDiv, Load`), any name outside `{sqrt, pi, exp, log, sin, cos, tan, integrate, x, y, z, n, e, E}`, and any non-numeric constant.
3. **DoS cap.** Int-literal constants over 10,000 are rejected at AST walk time — blocks `2**99999` from locking the parser for minutes computing a 30k-digit integer.
4. **Fail-closed at every boundary.** Missing SymPy/NumPy emits `MATH-VERIFY-UNAVAILABLE` on stderr with exit code 2. Parse rejection or cross-check FAIL returns `ok=False` with exit code 3. CLI exit codes are contract-pinned.
5. **Targeted agent-body edits, not broadcast.** Only the three agents where unchecked arithmetic most harms get the section — adding it to all 24 agents would be over-provisioning and noise.

Wolfram Alpha integration is explicitly **out of scope** for this version. The "2000/month free tier" claim is unverified and the official pricing page did not render during research.

## Consequences

### Positive
- Math-dependent review findings now have a verification path that doesn't rely on LLM arithmetic. Agents have explicit instructions to emit `MATH-VERIFY-FLAG` rather than silently asserting numbers they haven't checked.
- SymPy + NumPy are BSD-3 / MIT-compatible, well-maintained, with zero CVEs at pinned versions — no supply-chain tax.
- Invocation logging gives a 30-day data window to decide if the capability justifies dedicated-agent status (currently speculative).
- Sandbox-escape and DoS patterns are caught by regression tests in `TestSandboxEscape` — future regressions will flip red immediately.
- `CLI → Python → stdlib ast` is portable; no shell-only or OS-specific code.

### Negative
- Sympy + numpy add ~50 MB to the CI test environment (shipping to PyPI is unchanged; they are test-only deps, with the runtime skill fail-closing if they're missing in the user's env).
- The AST whitelist is restrictive. Users who want to verify an expression involving an uncommon function (e.g. `gamma`, `erf`) will get a "disallowed name" rejection until the whitelist is expanded. This is a deliberate safety-first trade-off.
- Math verification across 24 agents is not covered — if other agents (e.g. fw-review-tests, fw-review-api-contracts) also make numeric claims, they currently don't get the section. Expand case-by-case as evidence accumulates.
- The `/verify-math` skill must be invoked by the lead, not the subagent. Reviewers that "want" to verify math need the lead to run the skill and feed results back — more coordination overhead than a subagent consultation would have been.

### Neutral
- Wolfram Alpha remains an available follow-up if invocation data shows that two independent sources (SymPy + NumPy) are insufficient in practice.
- The structural blockers (#4182/#29441/#38719) may be fixed upstream — re-evaluate design when Claude Code ships a version where subagents can invoke skills.
- MCP math servers (community: githejie/mcp-server-calculator, EthanHenrickson/math-mcp, Garoth/wolframalpha-llm-mcp) could replace this skill once the framework's MCP adoption phase begins (v1.2+). The lead-invoked-skill shape is compatible with that future.
