# ADR-004: Defense-in-Depth Hardening (Hooks vs Rules Architecture)

## Status
PROPOSED

## Context
Systematic analysis of the framework's safety architecture revealed three gaps in the defense-in-depth model:

1. **Rule file integrity**: `.claude/rules/` files are context-injected into Claude's conversation. Pillar Security (March 2025) demonstrated that invisible Unicode characters can embed hidden instructions in such files — a supply chain attack vector. Only `security.md` was protected by CODEOWNERS; no CI validation existed.

2. **Post-compaction context loss**: After context compaction, Claude loses track of which Sherlock workflow step it's on. The `.sherlock-plan.md` file persists on disk, but the methodology rules (~16KB) degrade in Claude's compacted context. Rules achieve ~60-90% compliance; this drops further after compaction.

3. **Audit noise**: 100% of logged events in a typical session were mundane `safety:approve` records for read-only operations, drowning out actual security decisions. No log level system existed. Two conformance metrics (`hook_compliance`, `review_gate`) were hardcoded to 1.0.

## Decision
Apply the framework's own architectural principle — "hooks for enforcement, rules for guidance" — to close all three gaps:

- **Rule file integrity**: Expand CODEOWNERS to protect all `.claude/rules/` files. Add CI Unicode integrity check (grep -rP for control characters and zero-width Unicode). Document the threat model in `docs/35-SECURITY.md`.

- **Post-compaction recovery**: Add a PostCompact hook (`post-compact-restore.py`) that deterministically re-injects Sherlock context by reading the plan file, parsing git history for TDD phase, and outputting structured context to stderr. Add a SessionStart hook for lifecycle logging.

- **Audit noise reduction**: Add `level` parameter to `append_event()` (debug/info/warn/error). Route routine auto-approvals to `debug`, blocks to `warn`. Add `level` filter to `read_events()`. Replace hardcoded conformance metrics with real event log queries.

## Consequences

### Positive
- PostCompact hook provides 100% reliable context restoration vs ~60-90% from rules alone
- CODEOWNERS + CI close the supply chain vector for AI configuration file poisoning
- Log levels reduce audit noise, making security events discoverable
- Framework now uses 7 of 24 available Claude Code lifecycle events (up from 4)
- All changes are backward-compatible (log levels default to "info", old records work)

### Negative
- Three new hook files increase maintenance surface (mitigated by consistent patterns and shared `path_utils.py`)
- PostCompact hook adds ~100ms to post-compaction resume (acceptable for a non-blocking event)
- CI Unicode check uses `grep -rP` which is GNU grep specific (Ubuntu CI runners have this; macOS would need adaptation)

### Neutral
- The `errors.jsonl` file adds a new artifact to `.context/metrics/` that may accumulate if hooks frequently fail
- `_compute_hook_compliance()` and `_compute_review_gate()` will return 1.0 until enough events accumulate to provide meaningful data
