# Architecture Decision Records

This directory contains Architecture Decision Records (ADRs) for the ShipTeam project.

ADRs capture the context, decision, and consequences of significant architectural choices. They are immutable once accepted — if a decision is reversed, a new ADR supersedes the old one.

## Index

| ADR | Title | Status |
|-----|-------|--------|
| [000](000-template.md) | Template | N/A |
| [001](001-config-driven-architecture.md) | Config-Driven Framework Architecture | ACCEPTED |
| [002](002-worktree-session-isolation.md) | Git Worktree Session Isolation | ACCEPTED |
| [003](003-multi-agent-review-pipeline.md) | Multi-Agent Review Pipeline with Cost Routing | ACCEPTED |
| [004](004-defense-in-depth-hardening.md) | Defense-in-Depth Hardening (Hooks vs Rules) | PROPOSED |
| [005](005-agent-teams-dual-mode-orchestration.md) | Agent Teams Dual-Mode Orchestration | ACCEPTED |
| [006](006-remove-feature-tier-gating.md) | Remove Feature Tier Gating | PROPOSED |
| [007](007-public-repo-bright-line-sanitization.md) | Public-Repo Bright-Line Sanitization Policy | ACCEPTED |
| [008](008-zero-friction-installer.md) | Zero-Friction Installer — Separate `shipteam init` from `fw-sync` | PROPOSED |
| [009](009-enhanced-lead-orchestrator-artifacts-over-reasoning.md) | Enhanced Lead Orchestrator — Artifacts Over Reasoning | PROPOSED |
| [010](010-reasoning-lenses-and-deep-r-adversarial-upgrades.md) | Reasoning Lenses and /deep-r Adversarial Upgrades | PROPOSED |
| [011](011-conformance-scorer-v2-scope-boundary.md) | Conformance Scorer v2 — Schema + Scope Boundary vs Benchmark Harness | PROPOSED |
| [012](012-canonicalize-first-safety-hook.md) | Canonicalize-First in auto_approve_base.py (CWE-551 Fix) | PROPOSED |
| [013](013-math-verification-as-skill.md) | Math Verification as a Lead-Invoked Skill, Not a 23rd Agent | PROPOSED |
| [014](014-math-verification-followup.md) | Math Verification Follow-Up — Soundness Guards, PyPI Bundle, Wolfram Opt-In, SAFE AST Additions | PROPOSED |
| [015](015-framework-env-cross-worktree-contamination.md) | Framework Env-Var Cross-Worktree Contamination — Belt-and-Suspenders Fix | PROPOSED |
| [016](016-empirical-cli-probe-before-tdd.md) | Empirical CLI Probe Before TDD Against External Tools | PROPOSED |
| [017](017-benchmark-harness-architecture.md) | Benchmark Harness Architecture (v1) | PROPOSED |
| [018](018-cwe-551-inversion-principle.md) | CWE-551 Inversion Principle for Allow-Path Guards in auto_approve_base.py | PROPOSED |
| [019](019-task-pack-v1-architecture.md) | Task Pack v1 Architecture — Directory-per-Pack, Sandboxed Scoring, Salted Cache Defeat, Three-Driver Protocol | PROPOSED |
| [020](020-wheel-audit-pypi-gate.md) | Wheel-Audit PyPI Gate — Post-Build Artifact Inspector with Fail-Closed Publish | PROPOSED |

## Creating a New ADR

1. Copy `000-template.md` to `NNN-short-title.md`
2. Fill in Context, Decision, Consequences
3. Set Status to PROPOSED
4. Submit PR for team review
5. Update Status to ACCEPTED when merged

## Sherlock-Extracted ADRs

Full Sherlock Phase 8 (post-commit) automatically extracts ADRs from the `.sherlock-plan.md` architecture decision:

- **Context** ← from the plan's `Rationale` (why this decision was needed)
- **Decision** ← from the plan's `Approach chosen` + `Summary`
- **Consequences → Positive** ← benefits from the chosen approach
- **Consequences → Negative** ← trade-offs, limitations, rejected alternatives
- **Consequences → Neutral** ← side effects that are neither clearly positive nor negative

Auto-generated ADRs start as `PROPOSED` and become `ACCEPTED` when the PR merges. Sherlock Lite extracts an ADR only if a non-trivial architecture decision was made (single-approach, obvious plans are skipped).
