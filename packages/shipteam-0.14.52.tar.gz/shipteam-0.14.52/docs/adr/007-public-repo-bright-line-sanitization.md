# ADR-007: Public-Repo Bright-Line Sanitization Policy

## Status
ACCEPTED (2026-04-17)

## Context
The ShipTeam framework is developed in a private working repository and will be distributed to users through a separate public repository (`<TBD-public-repo>`). The public repo is intended to be a fresh-start export — new git history, new versioning lineage, no inherited blame or issue numbers — generated from the private tree by a future export script.

During the v0.13.0 refactor (see ADR-006) a sanitization sweep surfaced that the committed tree of the private repo contained several categories of content that were not appropriate for the public repository: pricing figures, revenue projections, commercial comparables with valuations and ARR numbers, go-to-market research, and references to private strategy files under the maintainer's local `~/Documents/dev-framework-private/` directory. Five entries in `docs/70-INSIGHTS.md` mixed legitimate technical rationale with this commercial material. Several release-note passages referenced deprecated commercial strategy by name.

Two broad design options were considered for keeping the public export clean:

1. **Sanitization markers.** Adopt an in-file convention (for example, `<!-- PRIVATE:BEGIN --> … <!-- PRIVATE:END -->`) that a future export script could strip. This would allow mixed files where some content is public-safe and some is not.
2. **Bright-line policy.** Declare that every file committed to the private repo is fully public-safe at every commit. All commercial content — business strategy, pricing, revenue targets, go-to-market framing, valuation comparables, private file references — lives outside the repo, in a separate maintainer-local directory. The export becomes a pure copy operation governed by a small exclude list rather than a content-aware filter.

Option 1 optimizes for flexibility. Option 2 optimizes for auditability: any spot-check of the committed tree, at any commit, produces a single answer to the question "is this file safe to publish?"

## Decision
Adopt Option 2. The committed tree of the private repo is fully public-safe at every commit.

Concretely:

- **What may enter the tree**: the framework code, rules, skills, hooks, tests, ADRs, user-facing documentation (CLAUDE.md, README.md, SETUP.md, QUICKSTART.md, CONTRIBUTING.md, CHANGELOG.md, release_notes.md, `docs/**`, `.claude/**`, `config/**`, `scripts/**`), and technical rationale that describes *what* the framework does and *why* the code looks the way it does.
- **What must not enter the tree**: pricing amounts, revenue targets (monthly, annual, projected), valuation comparables (Series B amounts, market caps, customer counts paired with revenue figures), go-to-market plans, commercial positioning research, buyer-persona segmentation, launch-copy marketing language, references to private maintainer-local file paths (e.g. `~/Documents/dev-framework-private/`), and named commercial strategy documents.
- **Where commercial content lives**: the maintainer's local `~/Documents/dev-framework-private/` directory, which is never committed anywhere.
- **Export mechanism**: a future export script will perform a pure filesystem copy from the private tree to a fresh public-repo checkout, governed by a small top-level exclude list (strategy docs, local test artifacts, `.context/metrics/`, `.sherlock-plan.md` if present, and any future private-only paths). The exclude list is explicit and reviewable in one place. There is no in-file marker convention, no content-aware sanitizer, and no runtime flag that gates what ships.
- **Enforcement**: automated CI gate (`scripts/validate-no-bright-line.sh`, wired to the `bright-line-guard` job in its own `.github/workflows/bright-line-check.yml` workflow and to `.pre-commit-config.yaml` for local checks) backs up maintainer spot-checks. The bright-line check runs in a standalone workflow so that unrelated issues in the larger `ci-cd.yml` pipeline cannot silently disable this policy gate. The scanner enforces pattern-level detection (pricing with period suffix, round-size signalling, valuation/revenue comparables, GTM keywords, private path references); line-level false positives are suppressed with an inline `bright-line:allow` comment including a stated reason, and legitimate whole-file meta-references go in `config/bright-line-allowlist.txt`. The bright-line is easier to enforce than a marker convention precisely because any file in the tree is either fully public-safe or it is a policy violation — there is no third "partially safe" category to reason about.

The first application of this policy is the v0.13.0 PR itself: it deletes five entries from `docs/70-INSIGHTS.md` that contained commercial material, sanitizes follow-on references in `release_notes.md` and `CHANGELOG.md`, and removes the "Feature Tiers vs Complexity Profiles" section from `docs/ADOPTION.md`.

## Consequences

### Positive
- Spot-checks of the committed tree produce binary answers. Any reviewer at any commit can ask "is this file public-safe?" and the expected answer is always yes.
- The export script becomes a ~20-line `rsync --exclude` operation. No content parsing, no marker stripping, no conditional regex, no per-file allowlists.
- No marker convention to teach future contributors or enforce with a linter.
- The policy itself is short enough to cite in a PR review comment: "pricing numbers don't go in the committed tree — see ADR-007."
- The decision to remove the feature-tier gating machinery (ADR-006) and the decision to delete the five commercial `docs/70-INSIGHTS.md` entries compose naturally. Neither requires the other, but together they establish a clean starting line for the public export.

### Negative
- Technical rationale that was previously entangled with commercial framing has to be separated. Five historical insights were deleted rather than rewritten — the technical portions of those insights are not preserved in the tree, only in git history and in the maintainer's local strategy files.
- The maintainer must self-police. There is no automated scanner; the policy is enforced by discipline during authoring and by spot-checks during review.
- Future commercial-adjacent decisions (for example, introducing a paid companion product that leverages some framework code) will have to be documented in two places: a technical ADR that lives in the committed tree and names the mechanism, and a separate strategy document that lives in the maintainer-local directory and covers the business rationale.

### Neutral
- The policy does not dictate the eventual public repo name, URL, or release version. The `<TBD-public-repo>` placeholder in this ADR will be resolved when the public repo is created.
- The policy does not preclude a future decision to move from Option 2 to Option 1 if the marker convention ever becomes necessary (for example, if the framework grows documentation that legitimately needs a public and a private variant of the same file). Until that need arises, the bright-line is the simpler design.
- The policy applies to the committed tree only. In-session artifacts like `.sherlock-plan.md` may reference private-doc filenames or commercial context during an active session; they are deleted after their ADRs are extracted, so they never reach a commit.
