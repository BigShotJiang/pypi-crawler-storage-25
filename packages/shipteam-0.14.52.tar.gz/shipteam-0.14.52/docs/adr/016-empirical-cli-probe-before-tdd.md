# ADR-016: Empirical CLI Probe Before TDD Against External Tools

## Status

PROPOSED (becomes ACCEPTED when this ADR's PR merges)

## Context

Sub-phase B of the ShipTeam Benchmark Harness Phase 2 Part 2 (`scoring/mutation.py` — mutmut + Stryker scorer) entered RED, GREEN, and REFACTOR with a Lead Judgment Priority Stack item that read:

> "External-tool schema verification complete (/deep-r topic hash `7918d06f9de7` — 2026-04-19) — Tier A source reads for mutmut 3.5.0 + Stryker 9.6.1 + Semgrep 1.160.0 completed BEFORE RED. Findings applied as R1–R6 in the Interface Contracts + Risk Watch."

That source-reading had been completed via `/deep-r` — six parallel research subagents reading mutmut's `__main__.py`, Stryker's `JsonReporter` source, and Semgrep's `config_resolver.py`, plus an adversarial upstream pass and a CoVe re-verify on a load-bearing claim. 81 research calls. Confidence was high.

The per-phase review pipeline ran 7 reviewers (code, tests, types, concurrency, error-handling, forensics, dependencies). Six returned BLOCK. The forensics review caught two Critical findings nobody else had:

1. **mutmut subcommand hallucinated** — the implementation invoked `["mutmut", "export_cicd_stats"]` (UNDERSCORE). Real mutmut 3.5.0 CLI is `mutmut export-cicd-stats` (HYPHEN). Every Python scoring run would have failed silently, returning `mutmut_baseline_failed` with no Python mutation data ever produced.
2. **Stryker JSON schema fabricated** — the implementation parsed `report["metrics"]["killed"]` etc. Real Stryker `mutation-report.json` (schemaVersion 1.0) has no top-level `metrics` field at all; counts come from per-mutant `status` aggregation across `data["files"][*]["mutants"]`. The RED tests passed against the same fabricated shape because the RED subagent fabricated the fixture and the GREEN subagent implemented to that fixture. **Two cognitively-isolated subagents agreed because they shared the same hallucination, not because they shared a verified ground truth.**

Both Criticals were verified empirically in under 3 minutes:

```bash
# Verifies CRIT-1 in 30 seconds
pip install mutmut==3.5.0
mutmut --help                         # subcommands listed; surface CONFIRMED
mutmut export-cicd-stats --help       # hyphen, not underscore

# Verifies HIGH-2 in 2 minutes
mkdir /tmp/stryker_probe && cd /tmp/stryker_probe
# minimal package.json with @stryker-mutator/core@9.6.1
# minimal src/calc.js + test/calc.test.js + stryker.conf.json
npm install
npx stryker run                       # writes reports/mutation/mutation.json
python3 -c "import json; print(sorted(json.load(open('reports/mutation/mutation.json')).keys()))"
# → ['config', 'files', 'framework', 'projectRoot', 'schemaVersion', 'thresholds']
# NO 'metrics' key at top level. Schema HALLUCINATED in plan.
```

The cost gap is striking. /deep-r spent ~$3-5 in research API calls reading source files for Tier-A schema verification. Empirical probing would have cost ~$0.10 in compute time and prevented two Criticals that survived through RED, GREEN, REFACTOR, and a 7-agent review pipeline. The forensics agent caught it only because it was specifically prompted to question external-API claims.

## Decision

Sherlock methodology Step 3 (`/deep-r` research) and Step 4 (Architecture) MUST require **empirical CLI probing** for any external tool the implementation will shell out to, in addition to source-file reading. The probe must produce a captured-output artifact that becomes the test fixture and parser oracle.

**Required probe steps** (added to Step-3 /deep-r protocol):

1. **Install** the pinned version of the external tool in an isolated environment (`pip install pkg==X.Y.Z`, `npx -p pkg@X.Y.Z`, etc.).
2. **Invoke** `--help` (and `<subcommand> --help` for each subcommand the implementation will use) — capture the actual flag/subcommand surface. Compare against the names appearing in `/deep-r` source-read findings; flag any divergence as a research-quality red flag.
3. **Run end-to-end** against a minimal toy workload — capture the real output file (JSON report, exit code, stdout). Sanitize for PII/paths and commit as `tests/<scope>/fixtures/<tool>.real.<ext>`.
4. **Cite the captured fixture** in the plan's Interface Contracts section. The fixture path becomes a load-bearing test input.
5. The Lead Judgment Priority Stack entry that asserts external-tool surface verification MUST cite both the source-read evidence AND the captured-fixture path. A claim of "Tier A source reads complete" is now insufficient on its own.

The corresponding test obligation (added to fw-tdd-red and fw-author-test-strategy):

- Any test that asserts behaviour on an external tool's output schema MUST consume the committed `*.real.*` fixture as at least one of its oracle paths. RED tests against fabricated fixtures alone are now a Critical finding (because RED + GREEN can agree on a shared hallucination).

## Consequences

### Positive

- Eliminates the "RED + GREEN agree because they share a hallucination" failure mode at the methodology level. The captured-fixture obligation makes hallucinated external APIs detectable at fixture-commit time, not at production-deploy time.
- Cheap. The probe budget (~$0.10 in compute) is more than an order of magnitude smaller than the /deep-r research budget (~$3-5) the methodology already accepts (35× ratio at the upper end).
- Captured fixtures double as regression-guards: future tool upgrades that change schema break the fixture-comparison test, surfacing breaking changes immediately.
- Establishes a reusable pattern. The same gate applies to Sub-phase C (`scoring/semgrep.py`), to future driver adapters (Aider, Droid CLI surface), and to any benchmark task pack that shells out to a checker.

### Negative

- Adds 5–15 minutes of pre-RED probe work per external tool. Acceptable cost given the fail mode it prevents.
- The probe environment may differ from production (architecture, OS, Node version). The fixture is a snapshot of one configuration's output; cross-environment drift is still possible but now visible (fixture + parser are in the same diff and reviewable together).
- Some tools (heavy SaaS, hardware-bound) cannot be locally probed. For those, the methodology falls back to source-read evidence + a `RESEARCH_NEEDED` flag that escalates to the user with explicit acknowledgement that the schema is unverified.

### Neutral

- The fw-author-spec and fw-tdd-red agents need a small instruction update (1–2 lines) requiring the captured-fixture path appear in Acceptance Criteria for any external-tool-output-shape AC.
- The plan's Lead Judgment Priority Stack format gains a "Captured fixture" line alongside "Source read" lines. No structural change to the spec.
- Does not affect tasks where the implementation is pure-Python or otherwise has no external CLI surface. Those continue to use the existing /deep-r + source-read flow unchanged.

## References

- Sub-phase B Decision Digest entry in `.sherlock-plan.md` — full per-phase review breakdown, all 5 Critical + 5 High findings the empirical probe would have caught at plan time.
- fw-review-forensics agent definition — currently the only review-pipeline agent that reliably catches external-API hallucinations. ADR-016 reduces dependence on it by moving the catch upstream to plan time.
- mutmut 3.5.0 release on PyPI (2026-01-15 era, exact date in CHANGELOG.md).
- Stryker mutation-testing-elements schemaVersion 1.0 reference (npm: `mutation-testing-elements`).
