# ADR-003: Multi-Agent Review Pipeline with Cost Routing

## Status
ACCEPTED

## Context
Single-pass code review misses domain-specific issues. Security experts catch vulnerabilities that general reviewers miss. Performance specialists spot N+1 queries. But running all reviewers on every change is expensive and slow.

## Decision
Implement a multi-agent review pipeline where specialized agents run based on what files changed. Cost routing (`scripts/cost_routing.py`) classifies changes by type and size, then selects only relevant reviewers. A conflict resolution protocol handles contradictory findings between agents.

## Consequences

### Positive
- Domain-specific issues caught by domain experts
- Cost-optimized: small docs-only changes skip expensive reviewers
- Parallel execution: independent reviewers run concurrently
- Clear authority hierarchy resolves conflicts without human intervention (most of the time)

### Negative
- Complex orchestration — many agents to coordinate
- Agent definitions must be maintained as standards evolve
- False positives from multiple agents can create noise
- Cost routing logic needs updating when new file types are added

### Neutral
- Developers see more review feedback per change (could be positive or negative depending on context)
