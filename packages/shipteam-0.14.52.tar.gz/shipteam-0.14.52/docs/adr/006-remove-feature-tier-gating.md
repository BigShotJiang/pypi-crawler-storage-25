# ADR-006: Remove Feature Tier Gating

## Status
PROPOSED

## Context
Earlier releases shipped a `feature_tier:` section in `config/framework.yaml` that nominally split the 22 framework agents into two lists (`community_agents` and `pro_agents`) and enumerated a set of `pro_capabilities` that were reserved to a paid tier. Two Sherlock rules files (`sherlock-methodology.md` and `sherlock-review-gate.md`) carried tier-conditional branches that described one review pipeline for the "community tier" reader and a different pipeline for the "pro tier" reader.

In practice this split did nothing that the framework could enforce or benefit from:

- **No runtime code read the key.** A repo-wide grep of `scripts/`, `.claude/hooks/`, `.github/workflows/`, and every `*.py` / `*.sh` file produced zero hits for `feature_tier`, `community_agents`, or `pro_agents`. The split existed only as prose in rules and docs.
- **The split complicated the rules without narrowing them.** Every step that described "run these reviewers" was forked into a Community branch and a Pro branch. Readers had to pick one mentally before they could find the relevant guidance.
- **The split advertised an inconsistency the framework could not back up.** A reader of `sherlock-review-gate.md` would see "Pro tier: full parallel pipeline" and reasonably expect some mechanism — a license check, a runtime switch, a conditional import — to make that real. There was none. The framework always ran whatever reviewers the Sherlock lead spawned, regardless of the `feature_tier.tier` value.
- **The split was hostile to the adoption story.** Teams evaluating the framework for the first time would read QUICKSTART.md, see "Start with the minimal profile and community tier," and immediately be asked to form an opinion about a licensing concept before they had written a single line of code.

## Decision
Delete the `feature_tier:` section from `config/framework.yaml` entirely. No replacement, no stub, no commented-out placeholder. Strip all tier-conditional branches from `.claude/rules/sherlock-methodology.md` (Sherlock Lite Steps 4–5 and Full Sherlock Steps 6–7) and from `.claude/rules/sherlock-review-gate.md` (the "Feature Tier Gate" section, the Per-Phase Reviews per-tier preamble, and the Final Review Gate per-tier branches). Collapse each conditional pair to the previous Pro-tier branch — the one that described the full relevant-reviewer pipeline based on file types and LOC. The existing tier-independent cost-routing tables, file-type skip rules, and diff-size routing in `sherlock-review-gate.md` stay intact because they were already tier-neutral.

All 22 agents, all 4 workflow modes, all 18 safety hooks, and the full multi-agent parallel review pipeline become available to every user of the framework unconditionally.

The change is captured in a single v0.13.0 release. The release notes and CHANGELOG entries mark the config-shape change as BREAKING for any project carrying a local `feature_tier:` section, and five historical entries from `docs/70-INSIGHTS.md` that documented the earlier rationale are deleted alongside the gating removal.

## Consequences

### Positive
- `config/framework.yaml` is ~50 lines shorter and contains one fewer concept for new users to understand before they can run the framework.
- The two Sherlock rules files no longer branch on a value that nothing enforced. Readers see one pipeline description instead of two.
- QUICKSTART.md and docs/ADOPTION.md drop the "licensing orthogonal to complexity profile" framing that forced new users to answer a question they hadn't asked.
- The cost routing tables, file-type skip rules, and diff-size routing in `sherlock-review-gate.md` become the single source of truth for which reviewers run when — there is no preceding tier check that could shadow them.
- Future rule edits touch one branch, not two.

### Negative
- This is a breaking change to the `framework.yaml` schema. Any project that carries a local `feature_tier:` section should delete it. No Python or shell code reads the key, so the change is documentation/rules-level and will not fail at runtime, but strict YAML schema validators may flag an unknown top-level key if one is preserved. Running `uvx shipteam init --refresh` on affected projects regenerates a clean config.
- Five historical `docs/70-INSIGHTS.md` entries are removed alongside this ADR. Readers looking for the reasoning behind earlier tier decisions will find only this ADR and the git history.
- Any project documentation that pointed at the removed "Feature Tiers vs Complexity Profiles" anchor in `docs/ADOPTION.md` becomes a dead link until it is updated.

### Neutral
- This ADR is silent on what, if anything, future companion offerings might look like. The removal of the gating machinery is not a commitment to any particular future direction — it is a statement that no gating existed in the shipped framework and none should be inferred from the config schema.
- Cost routing tiers (`high`/`standard`/`fast` in `cost.model_tiers`) are unchanged. They are a cost-management concept, not a feature-gating concept, and continue to govern which model each agent uses at invocation time.
