# ADR-012: Canonicalize-First in auto_approve_base.py (CWE-551 Fix)

## Status

PROPOSED (becomes ACCEPTED when PR #131 merges)

## Context

PR #125 (shipped in v0.14.2) introduced a prefix-matching auto-approve path for routine branch cleanup — `session/claude-*` and `dependabot/*` branches via `git branch -d`. The match was implemented with `re.match(r"^(origin/)?(session/claude-|dependabot/)", branch_name)` applied to every non-flag token. Python's `re.match` anchors at the start of the string but does **not** require a full match — any shell metacharacter embedded in the rest of the token passes the authorization check silently.

The compound-command guard that existed to catch shell-injection bypasses ran **after** the branch-delete approve decision (roughly 40 lines later in the function). By the time the guard could evaluate the command, `approve()` had already exited the hook with a `permissionDecision: allow` JSON blob.

A parallel vulnerability existed in the `rm -rf` safe-target approve path: `shlex.split` tokenized `/tmp/safe$(evil)` as a single argument starting with the `/tmp/` safe prefix, so `target_is_safe` evaluated `True` before the compound-guard ran. Shell expansion of `$(evil)` happened at execution time, after authorization.

Final-review security scan (fw-review-security, the domain authority for safety-infrastructure per `.claude/rules/sherlock-review-gate.md`) empirically confirmed **seven bypass variants** of the same class, auto-approving on `main` as of v0.14.12:

```
git branch -d session/claude-$(curl${IFS}evil)
git branch -d session/claude-ok&&payload
git branch -d session/claude-${X:-evil}
git branch -d session/claude-$FOO
git branch -d session/claude-*
rm -rf /tmp/safe$(evil)
cat $'\x72m -rf /'
```

This is the textbook expression of CWE-551 ("Incorrect Behavior Order: Authorization Before Parsing and Canonicalization"). The authorization decision was bound to a representation that omitted shell tokenization and expansion semantics.

Rationale for treating as a single architectural decision rather than a string of tactical patches:

- The enumeration `\$\([^)]+\)`, `;`, `\|` in the original compound-guard regex was incomplete by construction. Every missing metacharacter is a bypass. Patching one variant leaves the class open.
- A decision taken once at the structural level (canonicalize-before-authorize) propagates to every current and future `approve()` path at zero additional cost. A decision taken per-call-site (add a guard inside each approve check) has to be repeated and can be forgotten.
- The wider ecosystem has answered this exact question: Linux seccomp-bpf runs all filters and applies highest-precedence action; Kubernetes admission controllers mutate then validate before authorizing; sudo's `!NOPASSWD` class of historical bugs were closed with the same structural move.

## Decision

Adopt **canonicalize-first** as the structural invariant for `.claude/hooks/auto_approve_base.py`: compute the "does this command contain shell metacharacters?" check exactly once, early in `main()`, against the raw command string. Every `approve()` path that follows must either fall through when that check is true or be unreachable in the presence of shell metacharacters.

Concretely:

1. `has_shell_operators` is computed immediately after env-prefix stripping, before the dangerous-commands stack begins. `writes_to_safety` is computed at the same point and, if true, hard-blocks immediately.
2. The two previously-vulnerable approve paths (rm-rf safe target, branch-delete session/dependabot prefix) each carry an inline `if has_shell_operators: sys.exit(0)` guard immediately before their `approve()` call. The fall-through delegates authorization to the user prompt.
3. A final `if has_shell_operators: sys.exit(0)` gate runs before the downstream approval block (git commands, readonly, python, npm, curl, etc.), catching any compound command that didn't hit a hard-block above.
4. The compound-guard regex is broadened from metachar enumeration to deny-wins character classes: bare `\$` (supersedes `\$\(`), bare `&` (catches both `&&` chaining and `&` backgrounding), bare `<` (catches both `<<` heredoc and `<` input redirection), `*` (glob), `\\\n` (backslash line continuation). Glob `?` is deliberately omitted because it collides with URL query syntax and its exploit surface is narrower than `*`.
5. `approve()` and `block()` event-log entries carry a `duration_ms` field (monotonic clock, rounded to 3 decimals). Fall-through paths remain unlogged for now.

The existing hard-block stack (network-recon, rm-rf dangerous targets, force-push, SQL DROP/TRUNCATE, git reset --hard, protected-branch delete, remote protected-branch delete) runs **before** the final compound-guard fall-through. This preserves the dangerous-cmd-wins invariant — `ls; rm -rf /` hard-blocks on the rm-rf dangerous-targets check rather than falling through to a user prompt.

## Consequences

### Positive

- Closes the entire CWE-551 class for the two documented approve paths, verified by 22 new `test/safety_gate.bats` tests and by an independent empirical probe script that runs the hook end-to-end against all seven known bypass variants.
- Any `approve()` path added to the hook in the future inherits the canonicalize-first guarantee at zero additional design cost — the final fall-through gate catches it. The two inline guards document that approve paths immediately after hard-blocks must be individually protected (they exist before the final gate).
- The deny-wins character-class regex is more robust to attacker creativity than metachar enumeration. Future bypass research against `auto_approve_base.py` has to find a way to run arbitrary code without using `$`, `&`, `<`, `|`, `;`, `*`, backticks, redirection, fd manipulation, or backslash line continuation — a smaller and more defensible surface.
- The `duration_ms` field on approve/block events enables future latency monitoring of the hook path without waiting for external profiling infrastructure.
- The review-pipeline protocol (fw-review-security as domain authority with BLOCK verdict) paid for itself in a single cycle: the initial GREEN closed F1/F2/F3 but left four additional CWE-551 variants (${var}, $VAR, globs, $'...') exploitable. Without the security BLOCK, that partial fix would have shipped.

### Negative

- Curl GETs with multi-parameter query strings (`curl ...?a=1&b=2`) now fall through to user prompt because `&` is in the compound-guard regex. Single-parameter `?q=hello` still auto-approves. Mitigation: approve at the prompt once per usage, or use `-G --data-urlencode`. Documented in release notes.
- `shlex`-based strict canonicalization (reject any token containing non-allowlisted characters) was considered and deferred. It would be a more defensible long-term posture, but the immediate closure of the known bypasses outweighed the larger rewrite cost.
- `cmds_to_check` is defined early (in the compound-guard block) but consumed much later by approve-path checks. This is a latent reordering hazard — a future maintainer could move an approve path above the final compound-guard gate and reintroduce the bug class. Mitigated by comments; no code-level enforcement.
- Glob `?` is not in the regex because `?` is the URL query separator. The glob-`?` exploit requires matching filenames in cwd — narrower than `*` — but the hook cannot distinguish URL `?` from glob `?` purely by character context. A follow-up could add URL-context exemptions if the gap surfaces.
- Downstream projects that ran `fw-sync.sh` between v0.14.2 and v0.14.12 carry the vulnerable base hook. Re-syncing after this merges propagates the fix, but there is no automatic downstream push.

### Neutral

- The `_HOOK_START_TIME` module global (used for `duration_ms` instrumentation) uses ALL-CAPS naming. PEP 8 convention for mutable module state is lowercase; the existing file precedent is mixed (`_log_event`, `_approve_if_matches` are lowercase callables, no prior module-mutable-globals to compare). Not a regression.
- Two inline CWE-551 guards (rm-rf safe path, branch-delete session prefix) with differentiated explanatory comments. The duplication is legitimate defense-in-depth — the final fall-through gate would also catch these cases, but the inline guards make the intent visible at the call site and protect against future refactors that might place a hard-block between the inline approve and the final gate.
- Regex simplifications from the plan's precise lookbehind patterns (`(?<![&|])&(?!&)`, `(?<![<])<(?![<])`) to bare `&` and `<`: the lookbehinds would miss the `ok&evil` (no whitespace) exploit while accepting legitimate quoted ampersands. Bare patterns over-reject slightly in exchange for closing the bypass.
