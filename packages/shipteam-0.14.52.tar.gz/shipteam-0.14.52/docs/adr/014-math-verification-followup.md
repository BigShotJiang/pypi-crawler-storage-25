# ADR-014: Math Verification Follow-Up — Soundness Guards, PyPI Bundle, Wolfram Opt-In, SAFE AST Additions

## Status
PROPOSED

## Context

ADR-013 shipped `/verify-math` (PR #133) as a lead-invoked skill with sympy + numpy as test-only deps and an explicit deferral of Wolfram and AST whitelist expansion. A follow-up `/deep-r` investigation (`plans/5031d8fa65ae.md`) audited the shipped state and surfaced four gaps:

1. **Silent unevaluated returns**: `sympy.Sum`, `Integral`, `Limit`, `Order` can return unevaluated symbolic objects when SymPy gives up. The shipped verify.py stringified those and reported `ok=True` — silent corruption per the safety pre-mortem (Failure Mode State 3 in the /deep-r output). SymPy issue tracker confirmed the failure modes via #21651, #15767, #17982, #19630, #15751, #4441 and seven other open bugs.
2. **`e`/`E` contract drift**: `e` and `E` were in `_ALLOWED_NAMES` but not bound in `local_dict`. Expressions like `e**(I*pi)` or `log(e)` silently treated `e` as a free symbol instead of Euler's number.
3. **No PyPI bundle and no manifest registration**: agent-body Math Verification sections (added in PR #133) referenced `python3 .claude/skills/verify-math/verify.py`, but the skill itself shipped only via `.claude/skills/`. Downstream `uvx shipteam init` users got the agent edits with broken skill references. `verify-math` was absent from `config/fw-manifest.yaml`.
4. **Wolfram deferred entirely; AST whitelist tightly restricted**: the shipped whitelist of 14 names blocked algorithm/code-related math. `/deep-r` Phase 3 also produced an authoritative read of Wolfram's 2026 free-tier state — 2,000 non-commercial calls/month, vendor reserves the right to adjust at discretion (FAQ verbatim) — establishing that Wolfram is feasible as opt-in but never as a load-bearing path.

`/deep-r` Phase 5 lens checks confirmed the design fit:
- **hot-path-latency**: skill fires ≤2× per Sherlock review session — not a hot path.
- **failure-domain-isolation**: Wolfram's network failure must NOT collapse with the review pipeline's failure domain — opt-in fail-closed achieves this.
- **fit-for-purpose**: SymPy + NumPy cover crypto/cost/SLO + polynomial Big-O + standard summations + well-conditioned eigen problems. Wolfram's actual gap-case is narrow (heavy-tail integrals, complex special functions, integrals SymPy returns unevaluated) — not "all math everywhere."
- **explicit-tradeoff**: Wolfram trades simplicity (single stdlib stack) for narrow capability gain (≤5% of verifications) AND adds an external opt-in dep with vendor-adjustable quota.

## Decision

Implement REC 1+2+3+4+5a from `plans/5031d8fa65ae.md` in dependency order; defer REC 5b (`factorial` with arg cap) and REC 5c (comparison/logical ops) until 30-day invocation telemetry justifies the more-complex guards.

Specifically:

1. **REC 1 — Unevaluated-form guard.** Module-level `_UNEVAL_TYPES = (sympy.Sum, sympy.Integral, sympy.Limit, sympy.Order)` and a post-parse check `isinstance(parsed_expr, _UNEVAL_TYPES) or parsed_expr.has(*_UNEVAL_TYPES)` that emits `MATH-VERIFY-FLAG: result contains unevaluated symbolic forms — SymPy could not produce a closed form` and forces `ok=False`. Fixes State 3 silent-corruption mode.

2. **REC 2 — `e`/`E` binding.** Bind `local_dict["e"] = sympy.E` and `local_dict["E"] = sympy.E`. Closes the contract drift.

3. **REC 3 — PyPI bundle + extras pattern + uvx integration test.** Mirror the skill to `src/shipteam/framework/skills/verify-math/` (byte-identical to `.claude/skills/`); register 3 entries in `config/fw-manifest.yaml` under `config_gate: "skills.verify_math"`; add `[project.optional-dependencies] verify = ["sympy>=1.14,<2", "numpy>=2.0,<3"]` to `pyproject.toml` (NOT runtime-required — wheel size tax for ~5% of users is unjustified per /deep-r); ship `tests/test_uvx_extras_verify.py` that creates an isolated `uv venv`, runs `uv pip install '<repo>[verify]'`, and asserts importability + skill invocability (test fails clearly with `astral-sh/uv #4762/#14558` citation if the upstream bug ever bites); ship `tests/test_bundle_drift.py` that asserts byte-identical SHA-256 between source and bundle, with a meta-oracle proving the comparison logic itself catches drift.

4. **REC 4 — Wolfram as opt-in backup.** Stdlib `urllib.request` only (NO new HTTP dep — `requests`/`httpx` would add 600-800 KB for a single-endpoint GET). Gated entirely on `os.environ.get("WOLFRAM_APP_ID")` — without the env var, the Wolfram code path is dead. New CLI value `--source=wolfram`; `--source=all` semantics extended to also include Wolfram when the env var is set. Every failure (URLError, HTTP non-200, unknown exception) emits `WOLFRAM-UNAVAILABLE: <reason>` as a separate visible caveat — never silent. Local call counter at `<cwd>/.context/metrics/wolfram_calls.json` (project-local matches `fw_event_log.py` pattern, gitignored, sandboxable in CI); warn at `>1600/2000` calls per current month. SKILL.md documents the `2,000 non-commercial calls/month` quota and the vendor-reserves-right-to-adjust caveat.

5. **REC 5a — Six SAFE AST name additions.** Add `gamma, erf, floor, ceil, Min, Max` to both `_ALLOWED_NAMES` and `local_dict` (`ceil` maps to `sympy.ceiling`). NO new AST node types required — a sentinel test asserts `_ALLOWED_AST_NODES` is unchanged. `factorial` is deliberately NOT added in this PR (NEEDS-GUARD per /deep-r A1 verdict; deferred to a Stage 5b PR with the arg cap).

Final-gate review (fw-review-security: APPROVE; fw-review-code: 2 High + 3 Medium) was applied pre-merge — counter no longer resets on read OSError; `--source=wolfram` with local parse failure now emits a `MATH-VERIFY-FLAG: local SymPy parse failed; Wolfram result is sole source` caveat; `--source=all` with no env var emits a `Wolfram skipped: WOLFRAM_APP_ID not set` caveat for observability; the pre-existing `contextlib.suppress()`-no-op false-positive test from PR #133 was rewritten; counter race condition acknowledged in docstring (acceptable for warn purposes; not for billing).

## Consequences

### Positive
- Math verification now catches the most dangerous SymPy failure mode (silent unevaluated returns) — the highest-impact soundness gap from the shipped state.
- Downstream `uvx shipteam init` users get the skill that the agent-body Math Verification sections expect — broken-reference gap closed.
- Bundle drift is mechanically detected by `tests/test_bundle_drift.py` — a byte-identical regression in source-vs-bundle fails CI immediately rather than shipping silently to PyPI.
- Wolfram is available for the genuine gap-cases (heavy-tail integrals, complex special functions) without any cost to users who don't opt in. SymPy + NumPy primary path is unchanged for the 95%+ case.
- `pyproject.toml [verify]` extras pattern aligns with PyPA precedent (`pandas[excel]`, `httpx[http2]`); default `uvx shipteam init` install footprint is unchanged.
- 6 SAFE AST name additions cover combinatorial/special-function math (gamma, erf, factorial-via-future-Stage-5b) and basic comparison primitives (floor, ceil, Min, Max) — broadens algorithm-correctness coverage without widening the AST attack surface.

### Negative
- 88 tests now (up from 32 in PR #133) — substantial test surface to maintain.
- Wolfram opt-in adds a network code path with all the failure modes networks bring (timeout, partition, HTTP non-200, vendor downtime). Mitigated by fail-closed posture but adds to the support burden when something goes wrong.
- The `_wolfram_call_counter_path()` is non-atomic (no `fcntl.flock`); concurrent `verify.py` invocations can lose increments. Acceptable for warn purposes; explicitly documented; not suitable for billing.
- Counter file leaks Wolfram usage volume to anyone with read access to `.context/metrics/` — gitignored but local. Low sensitivity.
- AST whitelist now has 20 names — review surface for future expansion is larger, but each addition is still locally reasoned (per /deep-r A1 verdict table).

### Neutral
- REC 5b (`factorial` with arg cap), REC 5c (comparison + logical ops), and `Sum`/`Product`/`Matrix` whitelist additions remain deferred — revisit when invocation telemetry shows demand or when SymPy ships an upstream `safe_parse_expr` (issue #10805 still open since 2016 per /deep-r adversarial search).
- MCP math-server alternatives (`mcp-server-calculator`, `Garoth/wolframalpha-llm-mcp`, etc.) remain immature in 2026 (top-star MCP math server: 148 stars, no production deployments cited per /deep-r Axis 3). When MCP ecosystem matures, re-evaluate Wolfram-via-MCP as a replacement for the direct HTTP client.
- Wolfram quota stability is not contractually guaranteed (vendor FAQ verbatim) — a future quota cut by Wolfram would not break the skill (fail-closed) but would change the practical capability for users at the cap.
