# ADR-010: Reasoning Lenses and /deep-r Adversarial Upgrades

## Status
PROPOSED

## Context

The framework relies heavily on `/deep-r` for forward-looking design validation. In a 2026-04 session investigating a hook-path-resolution deadlock (Claude Code cwd drift blocking PreToolUse hook load), retrospective analysis surfaced three latent weaknesses in `/deep-r` as written:

1. **Docs-as-truth bias.** `/deep-r` validates candidate designs against authoritative sources — official docs, RFCs, OWASP, CNCF, etc. Official docs describe intended behavior, not empirical failure modes. Claude Code's official docs explicitly recommend `$CLAUDE_PROJECT_DIR` for hook path resolution; upstream issue anthropics/claude-code#33815 documents the variable is empty in PreToolUse hooks on v2.1.74+. A `/deep-r` that searches by feature name finds the docs; a `/deep-r` that searches by failure mode finds the bug. Prior `/deep-r` sessions used the first approach and missed the latter.

2. **Forward-looking-only scope.** `/deep-r` evaluates a specific design decision at planning time. It never loops back on existing running configuration to ask "is this still correct?" Latent defects in already-shipped infrastructure stay invisible. The hook-path bug existed in `.claude/settings.json` for many versions; no audit ever ran against it.

3. **Docs don't flag happy-path-only failure modes.** Safety infrastructure (hooks, auth gates, middleware) has runtime states that official docs don't discuss. "What happens when cwd drifts?" is not a question the docs answer, because the docs assume the happy path. `/deep-r` inherits the blind spot.

Concurrently, the session produced four reasoning patterns during architectural trade-off discussions (bash vs. Python for a hook shim): *hot-path latency budgeting*, *failure-domain isolation*, *fit-for-purpose*, and *explicit trade-off*. These patterns are broadly reusable across framework decisions but had no durable home.

## Decision

Three additions to the framework, scoped together because they address the same meta-problem (surfacing reasoning that would otherwise stay implicit):

1. **Three MANDATORY sections added to `/deep-r` SKILL.md:**
   - **Adversarial Search Pass** — for every upstream-provided primitive in a recommendation, run `site:github.com/<upstream-org>/<repo>/issues <primitive>` and failure-keyword searches. If any hit contradicts the happy-path recommendation, a `## Known Upstream Issues` section is required.
   - **Pre-Mortem for Safety Infrastructure** — when the investigation touches hooks/middleware/auth/permissions, require a `## Runtime Failure Modes` section listing ≥3 runtime states with trigger/behavior/recovery/mode-classification (fail-open vs. fail-closed vs. silent-corruption).
   - **Lens Consultation** — require a `## Lens Check` section enumerating which lenses (see below) were applied.

2. **New sibling skill `/deep-r-audit`** (`.claude/skills/deep-r-audit/SKILL.md`). Reverse-direction audit: enumerates primitives in current project config → runs adversarial upstream search per primitive filtered by installed version and project usage → produces ranked Critical/High/Medium/Low findings with cited upstream issues. Cadence guidance: before major releases, monthly on mature projects, immediately after Claude Code upgrades. Future work: register as fw-sync post-hook for continuous surfacing (deferred to v0.15+).

3. **New directory `.claude/lenses/`** for advisory reasoning patterns — distinct from `.claude/rules/` which are mandatory. Each lens is short (~60-120 lines) with five fixed sections: When to apply / Core question / Worked example / Anti-patterns / Past failure it would have prevented. Admission bar: must cite a concrete past failure, force exactly one question, resist a common default. Cap: ~8 lenses. Initial set:
   - `hot-path-latency` — `cost_per_call × calls_per_session` math
   - `failure-domain-isolation` — supervisor/supervised shared-failure check
   - `fit-for-purpose` — capability matching, task-to-tool
   - `explicit-tradeoff` — name the rejected alternative

## Consequences

### Positive

- **/deep-r stops missing version-specific upstream bugs.** Adversarial search would have caught #33815 in one query. The pattern generalizes to every framework primitive we depend on (hooks, env vars, SDK methods, CLI flags).
- **Safety infrastructure investigations gain runtime reasoning.** Pre-mortem forces fail-open-vs-fail-closed thinking at design time, before a production incident surfaces it.
- **Existing running configuration gets audited.** /deep-r-audit is the missing sibling — forward-looking and retrospective validation become a pair.
- **Reasoning patterns become durable and citable.** When an agent or skill applies a lens, it can cite the lens by name in its output, making the reasoning reviewable.
- **Lens set is self-limiting.** Admission bar (concrete past failure required) + cap (~8) + retirement policy (archive if uncited for 6 months) prevents bloat.

### Negative

- **/deep-r output is longer.** Three new mandatory sections add ~30% to typical output length. Mitigation: detail moves into lens files; SKILL.md cross-references rather than inlines.
- **Adversarial search adds latency + web-search cost.** Each primitive = 2-3 searches. For a typical /deep-r with 3-5 primitives, adds ~15-30s and ~$0.05-0.10 in search tokens. Acceptable — the class of bugs caught is high-severity.
- **Lens discipline requires enforcement.** A lens that agents don't actually consult is decoration. Mitigation: regression test asserts lens files exist and have required structure; review agents instructed to cite lenses by name.
- **One more abstraction in the framework to explain.** Rules vs. lenses is a distinction downstream maintainers must learn. Mitigation: `.claude/lenses/README.md` opens with the rules/lenses contrast.

### Neutral

- **Rejected alternatives**: (a) Merging /deep-r-audit into /deep-r as a flag — rejected because the input model and cadence differ (deep-r is ad-hoc per decision; audit is periodic over all config). (b) Expressing lenses as a sub-section of `.claude/rules/anti-patterns.md` — rejected because anti-patterns are mandatory-don't-do rules; lenses are advisory-how-to-think heuristics. Conflating them weakens both. (c) Writing the lenses as prose in `sherlock-methodology.md` — rejected because lenses need to be linkable and individually citable.

## Follow-ups

- v0.15+: Implement `/deep-r-audit` fw-sync post-hook for continuous surfacing
- v0.14.x: First audit run of this repo's own `.claude/` tree (self-audit; dogfood the skill)
- File upstream issue at anthropics/claude-code documenting the PreToolUse hook error-semantics mismatch surfaced during this work

## References

- anthropics/claude-code#33815 — `$CLAUDE_PROJECT_DIR` empty in PreToolUse hooks
- anthropics/claude-code#31250 — PreToolUse hook silent bypass
- This session's transcript (2026-04-14): reasoning-lens extraction during hook-shim design discussion
- ADR-009 — prior work on artifacts-over-reasoning; this ADR extends the pattern to reasoning-tool artifacts
