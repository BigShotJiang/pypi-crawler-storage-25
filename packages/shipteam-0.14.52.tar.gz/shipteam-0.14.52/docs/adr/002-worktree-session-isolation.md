# ADR-002: Git Worktree Session Isolation

## Status
ACCEPTED

## Context
Running multiple AI-assisted coding sessions concurrently on the same branch causes conflicts: race conditions on file writes, interleaved commits, and confused context. We needed a way to isolate sessions while sharing the same repository.

## Decision
Use git worktrees to give each Claude session its own working directory. Each worktree gets its own branch, and `checkout-guard.py` prevents branch switches when another session is active. Session locks (`session-lock.json`) prevent concurrent sessions in the same worktree.

## Consequences

### Positive
- Complete file-system isolation between sessions
- Sessions can work on different features simultaneously
- No risk of interleaved commits or file conflicts
- Each session has its own `.claude/state/` for independent state tracking

### Negative
- Git worktree mechanics add complexity (`.git` is a file, not a directory)
- All git commands need `GIT_DIR`/`GIT_WORK_TREE` environment variables
- `gh` CLI has workaround requirements (`--body-file`, `--repo` flags)
- Disk space grows linearly with concurrent sessions

### Neutral
- Developers need to use `claude-session.sh` instead of raw `git worktree` commands
