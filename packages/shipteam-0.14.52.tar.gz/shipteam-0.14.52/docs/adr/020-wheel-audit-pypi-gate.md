# ADR-020: Wheel-Audit PyPI Gate

## Status
PROPOSED

## Context

`pyproject.toml` uses `hatchling` with `packages = ["src/shipteam"]` and a `force-include` directive that copies `.claude/` framework content into `src/shipteam/framework/`. This means every built wheel and sdist contains the full framework tree — including the bright-line-sensitive docs, ADRs, and scripts that ADR-007 explicitly excludes from the public repo tree. Pre-build lints (CI bright-line check, `tests/test_bundle_drift.py`) verify the repo tree is clean before the build boundary is crossed; they cannot catch what the build system emits after that boundary. A wheel uploaded to PyPI with a `.pyc` file or an ADR-007 pattern in its METADATA would violate both the bytecode-cleanliness and content-policy invariants without any existing gate catching it.

Two orthogonal risks compound this:
1. **Compiled bytecode in artifacts**: hatchling may emit `.pyc` files or `__pycache__/` directories under certain edge-case conditions (namespace packages, post-install hooks, or operator misconfiguration). The 2024-07-08 PyPI incident documented a PAT leak via a `.pyc` file committed inside `__pycache__/`; the artifact boundary is where bytecode can silently appear.
2. **ADR-007 content in wheel METADATA**: The rendered README is embedded verbatim in the wheel's `METADATA` member. If the README ever contains a pricing, GTM, or private-path pattern, it ships globally and is indexed by PyPI search and mirror crawlers.

## Decision

Implement a post-build artifact inspector (`scripts/wheel_audit.py`) and two CI workflows:

- **`wheel-audit.yml`**: triggered on `pull_request` (no secrets). Builds artifacts from the PR branch, runs `wheel_audit.py`, fails the PR if any violation is found. Catches mistakes before merge; runs from the PR-head version of the script (by design — see Risk Watch in plan).
- **`pypi-publish.yml`**: triggered on `release: published` (operator creates a GitHub Release manually from the auto-bump tag). Runs the same audit from the tagged main-branch code, then publishes to PyPI using OIDC Trusted Publishing if and only if the audit passes. The `publish` job declares `needs: [build-and-audit]` — if `build-and-audit` fails, the publish job is skipped entirely. `attestations: false` avoids the indeterminate-state failure documented in `pypa/gh-action-pypi-publish#283` ("not planned" closure).

**Approach A (Release-event trigger) was chosen over Approach B (tag-push automatic)** because the `release: published` trigger requires a conscious human action — the operator navigates to Releases and clicks "Publish" — beyond the automated tag push. This separates PyPI publish cadence from the patch-bump cadence: the operator can batch patches, hold a release pending documentation, or publish a hotfix without triggering publish for every unreleased tag.

**Check coverage by artifact type:**
- `.whl` — PYC_CHECK, PYCACHE_CHECK, BRIGHT_LINE (full scan; this is the installed content)
- `.tar.gz` — PYC_CHECK, PYCACHE_CHECK only. BRIGHT_LINE is intentionally omitted from sdist: the sdist IS the full repo tree, and `validate-no-bright-line.sh` already covers it at the merge gate with the correct file-level exemption list. Applying the artifact scanner to sdist without those exemptions produces false positives on ADR-007 itself, CHANGELOG, test fixtures, and the scanner script.

**Text-file detection in BRIGHT_LINE scan:** `.py`, `.md`, `.txt`, `.toml`, `.yaml`, `.yml`, `.cfg`, `.ini`, `.rst`, `.json` by extension; `METADATA`, `LICENSE`, `NOTICE`, `README`, `AUTHORS`, `PKG-INFO`, `WHEEL`, `RECORD` by basename (no-extension wheel members that are the primary METADATA leak surface). Binary files (null byte present) skip the BRIGHT_LINE check but are still subject to PYC_CHECK.

**NFKC normalization** (`unicodedata.normalize('NFKC', text)`) is applied before regex scan. IGNORECASE is used (more defensive than the shell grep's no-`-i` flag) because the cost of a false positive at publish time (manual exception) is lower than the cost of a missed violation (content shipped to PyPI).

## Consequences

### Positive
- **Two independent checkpoints**: PR-time audit catches mistakes before merge; publish-time audit is the fail-closed gate that must pass before credentials are used. Neither checkpoint depends on the other — compromising one does not disable the other.
- **TOCTOU defense via trigger separation**: `pull_request` trigger fires in the unprivileged context; `release: published` fires in the privileged context. The publish job never runs from an unaudited artifact.
- **No credential exposure at PR time**: `wheel-audit.yml` uses no secrets. A malicious or accidental BRIGHT_LINE pattern in a PR cannot exfiltrate through this workflow.
- **Fail-closed property**: the `publish` job is structurally dependent on `build-and-audit` via `needs:`. There is no code path where a publish step runs if the audit step failed or was skipped.
- **OIDC Trusted Publishing**: no long-lived PyPI API token is stored as a GitHub Secret. The `id-token: write` permission is scoped to the `publish` job only.

### Negative
- **One-time operator setup required** before first publish: create a GitHub Environment named `release`, register a Trusted Publisher on PyPI.org (project name, owner, repo, workflow filename, environment). Documented as prerequisites in `pypi-publish.yml` comments; not automatable from the repo.
- **SHA pinning deferred**: `actions/download-artifact` uses `@v4` and `pypa/gh-action-pypi-publish` uses `@release/v1` with TODO comments to SHA-pin before first publish. Unpinned third-party actions are a supply-chain risk; this is the standard ShipTeam convention for actions that haven't yet been resolved to a SHA.
- **BRIGHT_LINE bypass surface**: the scanner does NOT detect Cyrillic-for-Latin confusables (U+0410 substituted for Latin A), zero-width character padding, base64-encoded content, or hex/decimal HTML entity encoding. Threat model is internal-author deterrence + accidental-leak prevention, not resistance to a determined adversary who reads the scanner source.
- **PR-time script mutability**: a PR author can modify `wheel_audit.py` in the same PR that introduces a violation, silently suppressing the PR-time audit. This is accepted: the PR-time audit catches accidents; the publish-time audit (from tagged main-branch code, requiring a merged PR) is the authoritative gate.

### Neutral
- sdist BRIGHT_LINE skip is a design decision, not a coverage gap. The sdist is the repo tree; coverage is already provided at the merge gate. Both facts are documented in `scripts/wheel_audit.py` module docstring and in `docs/85-SAFETY-LIMITS.md § PyPI publish safety gate`.
- `tests/test_wheel_audit.py` uses `zipfile`/`tarfile` to construct fixture artifacts programmatically — no real `python -m build` needed for unit tests. One `@pytest.mark.integration` test runs a real build to verify the actual artifacts pass the gate.
- The scanner's `IGNORECASE` flag is more defensive than the shell grep (no `-i`). Documented in the module docstring to prevent a future editor from removing it for "parity" with the shell variant.
