# ADR-018: CWE-551 Inversion Principle for Allow-Path Guards in auto_approve_base.py

## Status

PROPOSED (becomes ACCEPTED when the push-policy PR merges)

## Context

ADR-012 (v0.14.13) closed the CWE-551 class for the existing approve paths in `.claude/hooks/auto_approve_base.py` — branch-delete and `rm -rf` safe-target — by adopting **canonicalize-first** as the structural invariant: compute "does this command contain shell metacharacters?" once, early, against the raw command string, then gate every downstream `approve()` on that check. The fix worked because the surface was narrow: two specific approve paths, both for destructive operations the user had explicitly opted into via prefix matching.

The push-policy PR widens the auto-approve surface materially. Pushing to safe-prefix branches (`session/*`, `feat/*`, `fix/*`, `docs/*`, `chore/*`, `refactor/*`, `test/*`) is the most frequent shared-state-write a Claude Code session performs. Auto-approving that volume of pushes without a regression vector is the design problem this ADR resolves.

The block half of the hook is structurally analogous to the previous design — it hard-denies dangerous push forms (`--no-verify`, `--tags`, `--mirror`, `--all`, refspec-to-protected, namespace tricks, wildcard refspecs, bare semver tag pushes) by canonicalizing the command into a set of variants (`cmds_to_check = {original, inner_command, effective_command}`) and applying paranoid-OR ("any variant matches → block"). An obfuscated dangerous push (subshell wrapper, `cd /tmp/repo && git push --tags`, env-prefix attacker) still hard-denies because canonicalization catches at least one variant.

The allow half cannot use the same rule. Canonicalization on the allow path is a *gift to the attacker*, not a defense:

- An attacker who can prepend `cd /tmp/repo &&` to a `git push` of an attacker-chosen branch over `main` could canonicalize to `git push origin attacker:main` and have it match a "safe prefix" rule.
- An attacker who can prepend `GIT_SSH_COMMAND=/tmp/evil` could canonicalize to `git push origin feat/foo` and have it auto-approve, while the executed git binary inherits the malicious env (RCE class).
- An attacker who can wrap the command in `bash -c "git push origin :main"` (delete refspec) could canonicalize to a form that looks safe-prefix.

The Phase 4 final-gate security re-scan (fw-review-security, the domain authority for safety-infrastructure per `.claude/rules/sherlock-review-gate.md`) caught a Medium that crystallized the underlying rule: `command env GIT_SSH_COMMAND=evil git push origin feat/foo` evades `ENV_PREFIX_PATTERN` because shell builtins (`command`, `exec`, `nice`, `nohup`, `time`, `setsid`, `unshare`) shift the env-prefix anchor right by one or more words. The form was rejected anyway by `push_regex` not accepting it — but that was two regexes accidentally agreeing, not defense-in-depth. If `push_regex` is ever broadened in a future refactor (e.g., to accept new git flag forms), the env-guard silently regresses to allow LD_PRELOAD / GIT_SSH_COMMAND injection on auto-approved feature-branch pushes.

This is the structural pattern: **a multi-layer safety property where each layer's tightness depends on another layer's tightness is one refactor away from a CVE.** It is not the same bug class as CWE-551 (which is about authorization-before-canonicalization). It is a corollary that emerges specifically when a hook mixes block and allow decisions on the same command surface.

## Decision

Codify two complementary structural invariants for `.claude/hooks/auto_approve_base.py`:

### Invariant 1 — CWE-551 Inversion (asymmetric canonicalization)

The block path canonicalizes the command into `cmds_to_check = {original, inner_command, effective_command}` and uses **paranoid-OR**: any variant matches a deny rule → hard-deny.

The allow path **refuses canonicalization** and gates only on the ORIGINAL command string. It uses **paranoid-AND**: an auto-approve fires only when all of the following are simultaneously true on the ORIGINAL command:

1. `ENV_PREFIX_PATTERN.match(command)` is False — the command carries no env-prefix.
2. `has_shell_operators(command)` is False — no CWE-551 shell metachars.
3. Every flag in the command is in the approve-path's whitelist (only `-u` / `--set-upstream` for the push allow).
4. No delete-refspec (`:branch`, `+:branch`) is present in the parsed push targets.

The block path catches obfuscated dangerous commands by canonicalization. The allow path catches obfuscated safe-looking commands (which may have been laundered to *look* canonical) by refusing canonicalization — the original form must already be canonical to qualify.

### Invariant 2 — Latent-Coupling Rule (allow-path guard sufficiency)

Every guard in the allow path's paranoid-AND chain must be **sufficient in isolation**. That is: "this guard catches every X-bearing form" must hold without depending on any other guard's tightness. If the property holds today only because two regexes happen to agree, the latent coupling is itself the regression vector — close it before the next refactor reveals it.

Concretely, the implementation:

1. `ENV_PREFIX_PATTERN` is extended to absorb shell-builtin shifts:
   ```python
   ENV_PREFIX_PATTERN = re.compile(
       r"^\s*(?:(?:command|exec|nice|nohup|time|setsid|unshare)\s+)*"
       r"(?:env\s+)?\w+=\S+\s+"
   )
   ```
   The pattern matches `command env GIT_SSH_COMMAND=evil git push ...`, `exec LD_PRELOAD=/tmp/x git push ...`, and `nohup nice GIT_SSH_COMMAND=evil git push ...` independently of whether `push_regex` would accept the resulting inner command.
2. Five new helpers parse push targets (`_normalize_ref`, `_parse_push_targets`, `_command_has_wildcard_refspec`, `_command_has_disallowed_namespace`, `_command_has_delete_refspec`). Each is auditable in isolation against its own attack surface.
3. The push-policy block stack runs first (paranoid-OR over canonicalized variants); the safe-prefix push allow runs only after all block rules have failed and all four refuse paths above have failed.
4. Three RED tests in `test/safety_gate.bats` lock the C-1 invariant ("env-guard catches every env-bearing form on its own") for the three documented shell-builtin shifts. A fourth, `nohup nice` chained-builtin form, asserts the `*` quantifier on the builtin prefix.

## Consequences

### Positive

- The push-policy auto-approve gate is auditable in isolation. A future maintainer can read `_command_has_delete_refspec` (or any of the four refuse paths) and answer "does this guard close the X bypass class?" without reading the rest of the hook.
- The CWE-551 Inversion principle is now a documented architecture invariant. New approve paths added to the hook (e.g., a future "push to fork" allow) inherit the rule: gate on the ORIGINAL command, paranoid-AND across guards, every guard sufficient in isolation.
- The Latent-Coupling Rule turns a class of regressions into a maintainable one. Reviewers (human or AI) can ask of any allow-path PR: "is this guard sufficient if every other regex around it is loosened?" If not, close the gap.
- `safety_gate.bats` 152 → 179 tests, with 27 dedicated to the push-policy ACs and three specifically to the C-1 latent-coupling defense. The test suite now encodes the asymmetry as an executable specification.
- Removing `.claude/settings.local.json.template` (byte-identical to the shipped `.claude/settings.json`, four live doc references) eliminates a contributor-onboarding footgun without affecting the hook's behavior.

### Negative

- The auto-approve refuse paths are paranoid by design — pushes carrying any env-prefix (including legitimate ones like `GIT_SSH_COMMAND=ssh -p 2222`) fall through to the user prompt rather than auto-approve. This is the intended trade-off: false positives (prompt the user) are cheap; false negatives (silent RCE) are expensive. Documented in `CLAUDE.md` Automatic Protections.
- Pushes with shell metacharacters in branch names (rare but possible — e.g., `feat/foo*backup`) fall through. Same trade-off; documented.
- The four refuse paths are co-located in the safe-prefix push block but each must be maintained independently. If a fifth class of attack is discovered (e.g., a new form of refspec the parser misses), a fifth refuse path must be added — not a tightening of one of the existing four. Comments in `auto_approve_base.py` codify this.
- M2 from the Phase 4 review (flag-with-value parser — `--repo=foo` vs `--repo foo` parity) is deferred. It is a parser correctness issue, not a CWE class; no exploit path exists today. Tracked as a follow-up.
- AC-18 conformance scorer false-negative (the scorer regex collides with the helper-name `_normalize_ref` and double-counts) is deferred. It is a measurement artifact unrelated to runtime safety.

### Neutral

- Downstream projects that ran `fw-sync.sh` against the pre-merge `auto_approve_base.py` carry only the canonicalize-first fix from ADR-012 without the push-policy widening. Re-syncing after this merges propagates the fix.
- `cmds_to_check` (block path) and the original command (allow path) are computed and used in different sections of `main()`. The asymmetry is documented in comments at both call sites; no code-level enforcement of the "allow path uses original only" rule beyond review discipline.
- The shell-builtin list in `ENV_PREFIX_PATTERN` (`command`, `exec`, `nice`, `nohup`, `time`, `setsid`, `unshare`) is extensible. A future builtin not in the list would re-open the latent-coupling regression — mitigated by review checklist (any new env-prefix-relevant builtin requires updating the pattern + adding a defense-in-depth test) but not by static enforcement.
- The push-policy surface is large (21 ACs across hard-deny and auto-approve sides). The two invariants in this ADR are the architectural distillation; the per-AC enforcement lives in `safety_gate.bats` and survives plan-artifact deletion via test names that document the AC reference.

## Related ADRs

- **ADR-012** — Canonicalize-First in auto_approve_base.py (CWE-551 Fix). The block-path foundation this ADR builds on.
- **ADR-007** — Bright-line allowlist for committed strategic terms. Independent CI gate; this ADR strengthens runtime enforcement.

## References

- CWE-551: Incorrect Behavior Order: Authorization Before Parsing and Canonicalization
- The "OR-on-block, AND-on-allow" pattern echoes seccomp-bpf (deny if any filter denies, allow only if every filter allows) and Kubernetes admission-controller mutate-then-validate ordering.
