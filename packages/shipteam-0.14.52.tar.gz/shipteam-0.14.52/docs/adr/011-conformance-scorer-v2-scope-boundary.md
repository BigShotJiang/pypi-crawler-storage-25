# ADR-011: Conformance Scorer v2 — Schema + Scope Boundary vs Benchmark Harness

## Status
PROPOSED

## Context

The framework shipped a `scripts/fw_conformance.py` scorer that composed five sub-scores (file_coverage, ac_coverage, scope_creep, hook_compliance, review_gate) into a weighted composite to measure Sherlock plan adherence per session. Over time, four silent-pass defaults accumulated: sub-scores returned `1.0` when the underlying signal was absent (empty event log, empty diff, zero test files matching AC references, or a plan at repo root whose own headers self-matched the AC grep). The net effect was a composite pinned ≥ 0.85 for any fresh project regardless of actual behavior — worse than no score at all because the dashboard rendered false confidence.

A second, orthogonal failure: the scorer's output shape (`scores.composite` nested) did not match the dashboard's reader (`composite_score` at top level) — the `aggregate_conformance` integration had never worked end-to-end. No `.context/metrics/conformance/` directory existed in this worktree to exercise it.

A `/deep-r` investigation on 2026-04-17 confirmed both defects via direct source read (fw_conformance.py:182-248, generate_dashboard.py:137-147) and surfaced the authoritative industry pattern — OpenSSF Scorecard's inconclusive sentinel (`-1`, excluded from both numerator and denominator of the aggregate) and OpenSSF Best Practices Badge's Met/Unmet/N-A first-class states. HELM, BIG-bench, and Inspect AI converge on the same principle: a missing signal is not a pass.

Separately, the project's 2026-04-14 thesis positioning commits to a much larger cross-agent benchmark harness (Claude Code vs Aider vs Droid; 60% bug-injection + 30% PR-replay + 10% showcase; N≥10 per cell, median+IQR; k≥5 aggregate-only privacy floor). The current scorer is ~10–20% of that commitment. Shipping schema-v2 now without a scope boundary would either overlap with the queued harness work or get rewritten when it lands.

## Decision

**Phase A (this ADR)** — Ship `schema_version: 2` for per-session scorecards and a drill-down UX in the insights dashboard. Specifically:

1. **Inconclusive sentinel (`None`)** — `_compute_hook_compliance`, `_compute_review_gate`, `_check_scope_creep`, and `_check_ac_coverage` return `None` when their signal is genuinely absent (empty event log, empty diff, zero matching test files, etc.). `_compute_composite` excludes `None` sub-scores from both the numerator AND denominator (OpenSSF Scorecard `checker/check_result.go` pattern), returning `(composite, coverage_ratio)` as a tuple. `_compute_composite({all: None})` returns `(None, 0.0)` — never `0.0 / 0.0`.

2. **Scorecard schema v2** — `save_scorecard` writes top-level `schema_version=2`, `timestamp`, `composite_score`, `components` (preserving `None` as JSON `null`), `session_id`, `plan_hash` (sha256 first 12 hex chars of plan content), `git_sha`, `base_ref`, `sherlock_tier` (Hudson / Sherlock Lite / Full Sherlock), `branch`, and `project_root`. Legacy keys (`status`, `scores`, `details`) remain for backward compat.

3. **Filename-filtered AC coverage** — `_check_ac_coverage(acs, test_dir, plan_path=...)` gains an optional `plan_path` kwarg. When supplied, rglob excludes the plan file and filters to recognized test-file patterns (`test_*.py`, `*_test.py`, `*spec*.py`, `*.test.ts`, `*_test.go`, etc). Zero matches yields `score=None` (inconclusive). 2-arg legacy callers keep the old scan-all behavior for backward compat — explicitly documented in the docstring.

4. **Dashboard partition** — `aggregate_conformance` rejects `schema_version != 2` scorecards from aggregates and surfaces them in `legacy_count` + `legacy_files` (basenames only, never paths — path-leakage property test enforces `os.sep not in entry`). Downstream dashboard renderers display a visible "N legacy scorecards detected — re-score required" note.

5. **Drill-down + honest-signal UX** — `generate_insights.renderFrameworkStats` wraps each project row in a `<details>`/`<summary>` with a Detail column; session table gains a Session ID column (first 8 chars as `<code>`, full SID on hover). `discover_fw_projects_with_skipped` returns `{found, skipped}` so corrupt `framework.yaml` files are surfaced with a reason rather than silently dropped. Both the dashboard and insights Conformance sections carry the literal disclaimer "Measurement only — do not gate merges or deployments on this aggregate."

**Phase B (explicit non-scope)** — The cross-agent benchmark harness queued per the separate `Benchmark harness v1 plan` artifact is NOT delivered by this ADR. Phase B will extend `schema_version: 2` with fields such as `agent_under_test` and `trial_id` as a non-breaking extension — the same enrichment envelope designed in Phase A forward-extends. Phase B also adds the sampling layer (N≥10 per cell, median+IQR, k≥5 privacy floor) that is intentionally absent from Phase A.

## Consequences

### Positive
- **Honest signal** — composite scores now reflect observed behavior only; absent signals render as `?` / `null` rather than silent-pass `1.0`. Brand-new projects can no longer inflate their score by having no event log.
- **Integration repaired** — scorer and dashboard now agree on shape; `aggregate_conformance` produces non-zero averages for the first time.
- **Drill-down delivered without new dependencies** — native `<details>` + the existing `generate_insights.py` architecture avoids the adversarial-search-flagged bugs in Observable Framework (staleness #1148), Datasette Lite (Pyodide pinning #42, #56), and Evidence.dev / DuckDB `read_json_auto` (schema inference regressions #10823, #12861, #14259). Zero-server, zero-build-step.
- **Forward-compatible with Phase B** — the enrichment envelope (session_id, plan_hash, git_sha, sherlock_tier) is a superset of what the benchmark harness will need; Phase B extends, not rewrites.
- **Attack surface for test gaming is reduced** — `_check_ac_coverage` can no longer be fooled by putting AC-# headers in the plan (which it self-matched) or in non-test files (which it scanned indiscriminately).

### Negative
- **Schema v2 rollout is one-way** — any existing v1 scorecard is now classified as legacy and excluded from aggregates. Mitigation: no `.context/metrics/conformance/` existed in this worktree to migrate; dashboards visibly flag legacy count.
- **Composite may drop for some existing scored sessions** — a session that previously scored 0.85 (pinned) now scores lower if its underlying sub-scores were silent-pass. This is a correction, not a regression, but it will surface as a visible delta.
- **2-arg legacy `_check_ac_coverage` callers remain exposed to the self-match bug** by design — the docstring flags this as intentional backward-compat. Migration happens gradually as callers adopt the 3-arg form.
- **`project_root` absolute path ships in scorecard JSON** (see inline TODO in `_compute_schema_version_2_enrichment`). Sanitization is deferred to Phase B because cross-project aggregation is where the leak matters; the current `.context/metrics/` is gitignored.

### Neutral
- Phase A ≈ 10–20% of the thesis commitment (cross-agent benchmark harness). The delta is tracked as separately queued work; see `Benchmark harness v1 plan`.
- Rejected alternatives: (1) Observable Framework / Datasette Lite / Evidence.dev — rejected on adversarial-search hits + overkill at ~20-project scale. (2) HTMX-driven drill-down — rejected on zero-server constraint. (3) Default-to-zero for absent signals — rejected because it penalizes brand-new projects that legitimately have no data yet. (4) Custom numeric-and-tuple hybrid return from `_compute_composite` — rejected as over-engineered; updating the six legacy tests to unpack is cleaner.
- `_import_fw_event_log` dual-path import helper preserves both CLI (`scripts/` on sys.path) and pytest (`scripts` as package) contexts.
