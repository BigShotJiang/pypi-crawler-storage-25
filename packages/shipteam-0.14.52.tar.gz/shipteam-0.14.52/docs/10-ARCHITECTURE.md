# Architecture

**Purpose**: Describe the ShipTeam system architecture, component design, and key patterns so any developer or contributor can understand how the pieces fit together.

**When to update**: When adding new hooks, scripts, rules, skills, or agents, or when modifying the config system or session lifecycle.

---

## Overview

ShipTeam is a safety-first development framework for Claude Code. It provides default-deny guardrails, TDD workflows, session isolation, and a rules/skills/agents system that makes Claude's behavior consistent across sessions. It is a **template repository** — users fork it and customize for their projects. All behavior is driven by a single configuration file (`config/framework.yaml`).

## Tech Stack

| Layer | Technology | Purpose |
|-------|-----------|---------|
| Hooks | Python 3.9+ | Pre/post tool-use safety gates and session management |
| Scripts | Bash 3.2+ | Automation: session launcher, TDD commits, version bumping, framework sync |
| Config | YAML | Single source of truth (`framework.yaml`) + file sync manifest (`fw-manifest.yaml`) |
| Rules | Markdown | Auto-loaded guidelines for Claude (anti-patterns, security, DB, review pipeline) |
| Skills | Markdown | Invocable commands with structured workflows (`/deploy`, `/health`, `/qa`, etc.) |
| Agents | Markdown | Specialized review agents for Sherlock/Holmes pipeline |
| CI/CD | GitHub Actions | Stack-agnostic testing, security scanning, auto version bumping |
| Container | DevContainer | Optional deny-by-default firewall with network isolation |

## Repository Structure

```
dev-framework/
  config/
    framework.yaml           # THE key file — drives all behavior
    fw-manifest.yaml          # File sync policies for framework distribution
    secret-guard-allowlist.yaml
  scripts/
    _framework.sh             # Shared bash library (YAML parsing, git env setup)
    claude-session.sh          # Worktree session launcher + auto-sync
    tdd-commit.sh              # RED/GREEN/REFACTOR commit workflow
    bump-version.sh            # Multi-file version sync
    fw-sync.sh                 # Pull upstream framework improvements
    cost_routing.py            # Review agent selection by diff type + LOC
    preflight.sh               # Pre-session validation (installer is separate: `uvx shipteam init`)
    manage-servers.sh          # Dev server lifecycle
    ...                        # 21+ scripts total
  .claude/
    hooks/                     # 13 Python hooks (safety, session, deployment)
    rules/                     # 5 auto-loaded rule files (incl. sherlock-methodology)
    agents/                    # 25 agents (22 framework + 3 personal advisory) + template
    skills/                    # 9 invocable skill commands
    settings.json              # Shared hook config (committed)
    state/                     # Session state files (gitignored)
  .devcontainer/               # Optional container with firewall
  .github/workflows/           # 5 CI/CD pipelines
  docs/                        # 15+ modular documentation files
  test/                        # Safety gate + config + TDD tests
```

## Key Patterns

### Config-Driven Architecture

All scripts source `scripts/_framework.sh`, which reads `config/framework.yaml`. This creates a single source of truth:

```
framework.yaml → _framework.sh (YAML parser) → all 21+ scripts
                                              → all hooks (via path_utils.py)
```

The `_framework.sh` library provides:
- `fw_get <key>` / `fw_get_nested <section> <key>` — Read YAML values
- `fw_get_list <section>` — Read YAML arrays
- `fw_setup_git_env` — Set GIT_DIR/GIT_WORK_TREE for worktrees
- `fw_resolve_path <relative>` — Resolve paths relative to project root

Hooks use `path_utils.py` for the same config access in Python, with PyYAML fallback to line-by-line parsing.

#### Environment-variable overrides (`FW_PROJECT_ROOT`, `FW_CONFIG`)

`_framework.sh` honors two pre-set environment variables for test isolation and advanced tooling:

- **`FW_PROJECT_ROOT`** — If pre-set, must realpath-resolve to an existing directory containing `.git` (file or dir; supports worktrees). If unset, auto-detected by walking up from the script's directory until `config/framework.yaml` is found.
- **`FW_CONFIG`** — If pre-set, must realpath-resolve to a file inside `FW_PROJECT_ROOT`. If unset, defaults to `$FW_PROJECT_ROOT/config/framework.yaml`.

Both are realpath-resolved via Python (`os.path.realpath`), so macOS `/var → /private/var` symlinks are canonicalized consistently. The containment check uses a bash `case` pattern with a literal `/` separator (`"$ROOT"/*`), so `/foo/barbaz` does NOT match `/foo/bar`.

**Failure modes are fail-closed** with context-rich errors:
- Missing `python3` → explicit "is python3 available on PATH?" message
- Pre-set root outside a git repo → "not a git repo root (no .git)"
- Config realpath outside root (symlink escape or typo) → "resolves outside FW_PROJECT_ROOT"
- Non-existent pre-set path → "does not resolve to an existing directory"

The primary consumer is test isolation: `test/framework_config.bats` fixture tests override `FW_PROJECT_ROOT` to point at `BATS_TEST_TMPDIR` with a fixture `framework.yaml`, proving the reader works against any stack — not just dev-framework's own values. See [`docs/50-TESTING.md`](50-TESTING.md) for the test pattern.

### Research Integration (/deep-r)

The framework integrates structured web research at specific planning and verification points in the Sherlock workflow. Research is treated as a **decision-phase tool**, not an execution-phase tool.

**Two-layer research model:**

1. **Workflow-level research** — `/deep-r` is invoked by the Sherlock lead at defined steps:
   - **Step 3** (Research & Validate): Always for Full Sherlock — replaces ad-hoc web searches with citation-hygiene-enforced research
   - **Step 4.5** (Plan Validation): Always for Full Sherlock — red-teams `.sherlock-plan.md` before any code is written (the cheapest place to catch plan-level bugs)
   - **Steps 0, 2, 4, 8**: Optional/on-demand for complexity classification, clarifying questions, per-decision validation, and release readiness

2. **Agent-level research** — Five agents have embedded `WebSearch` + `WebFetch` tools for domain-specific validation:
   - `fw-advisor-architecture` — validates architectural patterns against current best practices
   - `fw-review-security` — CVE lookups, current threat intelligence
   - `fw-review-dependencies` — package advisories, maintainer health (its domain inherently requires current state)
   - `fw-advisor-release` — platform-specific deployment guidance
   - `fw-author-spec` — pattern validation for specs

All other agents use the `RESEARCH_NEEDED` / `UNVERIFIED_CLAIM` flag protocol to escalate uncertainty to the lead without embedded research tools. See `.claude/rules/sherlock-methodology.md` and `.claude/rules/sherlock-review-gate.md` for full integration details. Research cost estimates are tracked in `config/framework.yaml` → `research.estimated_cost_per_session`.

**Key principle**: `/deep-r` belongs in Steps 0–4.5 and Step 8. It does NOT belong in Steps 5–7 (TDD + reviews), where research is a context-switching antipattern — the plan is the plan; if you need research mid-implementation, the plan was incomplete (log it in Pivot Log and continue).

### Hook Architecture (Safety Layer)

Hooks intercept Claude Code tool invocations at four lifecycle points:

```
User Prompt → [UserPromptSubmit hooks] → Claude generates tool call
                                              ↓
                                       [PreToolUse hooks] → Tool executes
                                              ↓
                                       [PostToolUse hooks] → Result returned
                                              ↓
                                       [PreCompact hook] → Before context compression
```

**Safety gate design**: `auto_approve_base.py` (universal, replace policy) + `auto-approve.py` (project overlay, template policy). Exit codes: 0 = approve, 1 = deny (user prompted), 2 = hard block (cannot be bypassed).

**Observability**: Hooks emit diagnostic warnings to stderr (`[hook-name] WARNING: ...`) when recoverable errors occur (e.g., file read failures, JSON parse errors). These warnings aid debugging without affecting control flow -- hooks still fail gracefully according to their exit code semantics.

### Session Isolation (Worktree Architecture)

Each Claude session runs in its own git worktree:

```
~/worktrees/
  project-session-feature-auth/     # Session 1
    .git → project/.git/worktrees/session-1
    .claude/state/session-lock.json  # Lock file
  project-session-feature-pay/      # Session 2
    .git → project/.git/worktrees/session-2
    .claude/state/session-lock.json  # Lock file
```

**Lifecycle**: `claude-session.sh` creates worktree → auto-syncs with origin/main → sets session lock → launches Claude → on exit, lock is released.

**Protections**: `branch-check.py` (validates expected branch), `checkout-guard.py` (blocks concurrent session interference), `worktree-enforcer.py` (blocks operations outside worktree).

### Three-Tier Complexity Routing

Every task is classified by files affected and risk multipliers:

| Tier | Trigger | Workflow |
|------|---------|----------|
| Hudson | 1-2 files, no risk multipliers | 4 steps: explore → implement with tests → code review → commit |
| Sherlock Lite | 3-5 files, 0-1 risk multipliers | 6 steps: plan → clarify → TDD → targeted review → final gate → post-commit |
| Full Sherlock | 6+ files OR 2+ risk multipliers | 8 steps: plan → clarify → research → architecture → TDD → multi-agent review → final gate → post-commit |

Risk multipliers: DB migrations, auth/authz, payment code, RLS policies, breaking API changes, shared utilities (5+ consumers).

### Iterative Planning Methodology

Sherlock's planning uses a **spec-anchored** approach — structured specifications that evolve alongside code, with automated tests enforcing alignment:

- **Single-session context**: Sherlock reads source files, configs, and schemas before making any claims — plans are grounded in actual codebase state, not assumptions
- **Clarifying questions gate**: Ambiguities are surfaced and resolved before implementation begins, preventing wrong-direction work that static specs cannot catch
- **Research validation**: Approaches are validated against official docs and best practices before code is written — no "implement first, discover the pitfall later"
- **Competing architectures**: Users choose from 2-3 approaches (Minimal, Clean, Pragmatic) with explicit trade-offs — informed decisions, not guesswork
- **Promotion triggers**: If mid-implementation complexity exceeds the current tier, execution stops and promotes automatically (Hudson → Sherlock Lite → Full Sherlock)
- **Spec-anchored plan artifacts**: `.sherlock-plan.md` contains structured specs (Acceptance Criteria in Given/When/Then, Interface Contracts) that drive TDD. Post-commit, architecture decisions are extracted as ADRs in `docs/adr/`; execution artifacts (file lists, pivot log) are deleted
- **Live feedback loops**: Multi-agent review arrives per-phase during TDD, not just at the end — catching issues while context is fresh and fixes are cheap

### Multi-Agent Review Pipeline

The Sherlock/Holmes pipeline routes review agents based on what changed:

```
git diff → cost_routing.py → agent selection → parallel review → verdict
```

**Cost optimization**: Changes are classified by type (docs-only, config-only, etc.) and LOC to skip expensive agents. Model tiers route deep reasoning to Opus, standard analysis to Sonnet, and pattern matching to Haiku.

**Conflict resolution**: Domain authority hierarchy (security > correctness > performance > ...) with max 2 rounds before human escalation.

### Tool Portability (MCP Seam)

The framework treats Model Context Protocol (MCP) as the **tool-portability layer**, complementary to the model-portability work in the multi-provider abstraction plan. MCP is now governed by the Linux Foundation Agentic AI Foundation (co-founded by Anthropic, OpenAI, and Block, December 2025) and has first-class support in Claude Code, OpenAI Agents SDK, Google Gemini, and Microsoft Agent Framework — making it the de facto standard for agent-tool connectivity.

**What the framework will expose as MCP (v1.2+)**: Utility scripts with pure-function semantics — `cost_routing.py`, `fw_conformance.py`, and similar — become MCP tools so any MCP-compatible agent (not just Claude Code) can invoke framework orchestration logic. Event logging and framework configuration become MCP resource servers for cross-provider observability.

**What stays native**: Built-in tools (Read, Write, Bash, Edit, Grep, Glob), lifecycle hooks, agent definitions, skills, and the session launcher remain Claude Code native. Benchmarks show native tools are faster and roughly 40% more token-efficient than MCP equivalents, and hooks are lifecycle interceptors rather than callable tools. The review pipeline will adopt MCP via the "code API" pattern — a single `tools/run-review` endpoint with an agent-type parameter — to avoid the context-window consumption penalty that naive per-capability tool exposure would create (published research shows this can consume 40-72% of a 200K context window).

**Abstraction seam today**: An empty `.mcp.json` lives at the repo root as a placeholder. MCP migration is tracked as planned work (v1.2: utility tools and GitHub MCP consumption; v1.4: event-log and config resource servers; v2.0: review pipeline and governance features). MCP's security model (tool poisoning, prompt injection via resources, no standard ACLs) is itself an opportunity — the framework's existing safety hooks extended to cover MCP tool calls become the enterprise governance differentiator.

### Framework Distribution (fw-sync)

The `fw-sync.sh` script propagates upstream improvements to downstream projects using three sync policies:

| Policy | Behavior | Used For |
|--------|----------|----------|
| `replace` | Overwrite with upstream | Scripts, standard hooks, agents |
| `template` | Show diff for manual review | Rules, settings, CLAUDE.md |
| `merge` | Append new YAML sections | framework.yaml |

SHA tracking prevents re-syncing unchanged files. Config gates skip files for disabled features.

## Request Flow (Session Lifecycle)

```
Developer → claude-session.sh → git worktree created
                                      ↓
                              auto-sync with origin/main
                                      ↓
                              session lock acquired
                                      ↓
                              Claude Code launched
                                      ↓
                              [UserPromptSubmit: branch-check, worktree-enforcer]
                                      ↓
                              User gives task → Step 0 complexity routing
                                      ↓
                              [PreToolUse: auto-approve safety gate]
                                      ↓
                              Tool executes (or blocked)
                                      ↓
                              [PostToolUse: branch-tracker, protocol-validator]
                                      ↓
                              TDD cycle (red/green/refactor)
                                      ↓
                              Multi-agent review (if Sherlock/Holmes)
                                      ↓
                              Commit → PR → merge → auto version bump
```
