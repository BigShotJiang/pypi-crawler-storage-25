# Prompt Versioning Protocol

> **Stack-Conditional**: This doc applies only if your project uses LLM prompts. Enable in `config/framework.yaml`: `prompts.versioning: true`.

**Purpose**: Define how LLM prompts are versioned, migrated, and rolled back. Prevents accidental prompt regression and provides audit trail.

**When to update**: When changing prompt management strategy, adding new prompt types, or modifying migration procedures.

---

## Overview

Every LLM prompt in the system is versioned. Prompts are never modified in place -- instead, new versions are created while old versions are archived.

## Naming Convention

Prompt files follow the pattern:
```
prompts/prompt_v001_initial.txt
prompts/prompt_v002_add_context.txt
prompts/prompt_v003_reduce_tokens.txt
```

Format: `prompt_vNNN_short_description.txt`
- `NNN`: Zero-padded version number
- `short_description`: Snake_case description of the change

## Migration Strategy

### Creating a New Prompt Version

1. **Copy the migration template**:
   ```bash
   cp scripts/templates/prompt_migration_template.py scripts/run_migration_NNN.py
   ```

2. **Edit the migration script** with:
   - Source prompt path (old version)
   - Target prompt path (new version)
   - Transformation logic

3. **Run the migration**:
   ```bash
   python3 scripts/run_migration_NNN.py
   ```

4. **Export snapshots** (records current state for rollback):
   ```bash
   ./scripts/export-prompt-snapshots.sh
   ```

### Database-Stored Prompts

If prompts are stored in a database:
1. **NEVER** use raw SQL UPDATE on prompt tables
2. Always archive the current version first (to a history table)
3. Use the migration template or admin UI
4. Export snapshots after changes

## Rollback

To rollback a prompt:
1. Find the previous version in the snapshot directory
2. Copy it back to the active location
3. If database-stored: restore from the history table
4. Run health check to verify

## Snapshot Management

The `export-prompt-snapshots.sh` script:
- Reads `prompts.snapshot_dir` from `config/framework.yaml`
- Copies all current prompts to a timestamped snapshot
- Default snapshot directory: `prompt_snapshots/`

## Configuration

In `config/framework.yaml`:
```yaml
prompts:
  versioning: true
  snapshot_dir: "prompt_snapshots"
```
