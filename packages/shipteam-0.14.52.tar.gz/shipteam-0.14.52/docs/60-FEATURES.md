# Feature Tracking

**Purpose**: Track the build team's capabilities — what roles are staffed, what workflow stages are automated, and what is coming next.

**When to update**: When shipping a new feature, adding a feature flag, or updating the roadmap.

---

## Build Team Capabilities

The framework turns Claude Code into a build team that covers the full software development lifecycle. Features are organized by **workflow stage** and **team role**.

### Workflow Coverage

| Stage | Team Role | Components | Since |
|---|---|---|---|
| **Spec** | Product Manager | `fw-author-spec` agent, `.sherlock-plan.md`, Given/When/Then AC format | v0.7.0 |
| **Plan** | Solutions Architect | `fw-advisor-architecture` agent, complexity routing (Hudson/Lite/Full), risk multipliers | v0.3.0 |
| **TDD: RED** | Test Designer | `fw-tdd-red` agent (cognitively isolated — never sees implementation) | v0.3.0 |
| **TDD: GREEN** | Developer | `fw-tdd-green` agent (sees only tests and type signatures) | v0.3.0 |
| **TDD: REFACTOR** | Refactoring Engineer | `fw-tdd-refactor` agent (cleans up, keeps tests green) | v0.3.0 |
| **Review** | Code Review Team | 14 specialized reviewers with cost routing and conflict resolution | v0.3.0 |
| **CI/CD** | DevOps Engineer | 5 GitHub Actions workflows, safety gates, CI trust gate | v0.1.0 |
| **Ship** | Release Manager | `/ship` skill, `/release-notes`, `fw-advisor-release`, doc staleness gate | v0.2.0 |
| **Deploy** | Release Manager | `/deploy` tiered checklist, `commit-trust-check.py`, `/health` | v0.2.0 |
| **Measure** | Engineering Manager | `/fw-stats` skill, `fw_conformance.py`, `fw_event_log.py`, `/retro` | v0.10.0 |
| **Safety** | DevOps Engineer | `auto_approve_base.py` (exit code 2), session isolation, checkout guard | v0.1.0 |
| **Providers** | DevOps Engineer | Provider-agnostic capability tiers, `providers` config mapping | v0.11.0 |

---

## Trust Model — Task Pack v1 (URL Shortener)

**This subsection is the AC-21 source-of-truth.** The benchmark harness's
`tests/task_packs/test_v1_trust_model.py` parses these statements; if you
edit the wording, update the test fixture in lockstep.

The Task Pack v1 trust model defines what content the benchmark harness
will accept and run. The four load-bearing statements are:

1. **First-party packs only.** v1 ships only first-party packs (the URL
   shortener pack authored in-tree). The benchmark harness has no public
   API for loading task packs from external URLs, registries, or
   user-supplied paths. `task_packs/loader.py` resolves packs only from
   in-tree paths under `task_packs/`.
2. **Third-party `prompt.md` content is the indirect-injection vector
   per OWASP LLM01:2025.** A pack's `prompt.md` is delivered verbatim to
   the model under test. A malicious pack could exfiltrate API keys via
   the model's tool calls, or coerce the model into producing biased
   benchmark output — a class of attack OWASP LLM01:2025 (Prompt
   Injection) characterizes as "indirect injection from external data
   sources." Source: <https://genai.owasp.org/llmrisk/llm01-prompt-injection/>.
3. **v1.1 will add a prompt-content review gate.** External pack
   acceptance is gated on a `prompt.md` review pipeline (lint for
   credential-exfil patterns, jailbreak fragments, system-prompt-override
   markers) plus a sandboxed scoring path (no network egress, no host
   filesystem access outside the pack tree). The review gate's design
   lives in ADR-019; the implementation is deferred to v1.1.
4. **Until v1.1 ships, accepting external packs is unsupported.**
   Operators who run the harness against a pack they did not author
   themselves are outside the supported trust boundary. The CLI surface
   does not expose a flag for external pack loading; if a future patch
   re-introduces such a flag without the v1.1 review gate, that is a
   regression and the AC-21 test below will fail.

---

## Current Features

<!-- Add one entry per shipped feature. Keep in reverse chronological order. -->

### Benchmark Harness — Task Pack v1 (URL Shortener) + Three-Driver Protocol (Phase 5)
- **Version**: Unreleased (pending version bump)
- **Team Role**: Engineering Manager / Platform Ops
- **Description**: Turns ADR-017's harness skeleton into a runnable v1 benchmark across three drivers (Claude Code, Aider, Droid). **Directory-per-pack convention** (`task_packs/url_shortener/`) with `pack.yaml` manifest validating into a typed `TaskPack` dataclass at load time via `__post_init__`; `TaskPack.to_manifest_dict()` satisfies the existing `task_manifest: dict` Driver protocol. **Sandboxed scoring split**: `frozen_tests/` lives outside the workspace and is RO-mounted into the container — defends against the Cognition Devin failure mode (assertion-string extraction) that 3-of-4 surveyed benchmarks (SWE-bench, HumanEval, MBPP — all ship tests inline) are vulnerable to. AC-13 layered isolation: Layer 1 host-side bidirectional ancestor check (catches symlinks), Layer 2 host-side `_collect_inodes` overlap check via `lstat` (catches hardlinks/bind-mounts), Layer 3 container RO mount + `--cap-drop=ALL`. **Salted system-prompt cache defeat** (Claude Code driver): `f"\n\n<run_salt>{uuid.uuid5(uuid.NAMESPACE_DNS, str(seed))}</run_salt>"` invalidates Anthropic's cache key (claude-agent-sdk 0.1.68 has no `disable_prompt_cache` API per Issue #626; bundled `claude` CLI has no `--no-cache` flag). Salt overhead empirically probed at 33–38 tokens/call against `claude-sonnet-4-5` via `messages.count_tokens`; bound set to ≤40 tokens/call with 5-token headroom for Claude 4.X tokenizer drift. Driver fails closed (`aborted=true, abort_reason="cache_leak_detected"`) on `cache_read_input_tokens > 0` for a salted run; defensive `_check_salt_placement` scan raises `RuntimeError` if salt placement (after any SDK-injected `cache_control` marker) is violated. **Three-driver protocol with `cost_source` polymorphism**: `Driver.execute()` returns `DriverResult.cost_source` of `"computed"` (Claude Code: tokens × pinned rate sheet — SDK's `total_cost_usd` is unreliable per Issue #487 and MUST NOT be authoritative) or `"scraped"` (Aider/Droid: cost parsed from CLI stdout). AC-15: `"computed"` drivers MUST abort on missing token counts; `"scraped"` drivers MAY return `input_tokens=None`/`output_tokens=None` (Aider does not emit token counts natively). **Abort-spine factory** `make_aborted_result(elapsed_ms, AbortReason, cost_source, cache_strategy, driver_metadata, **kwargs)` in `drivers/_subprocess_helpers.py` funnels every error path (timeout, FileNotFoundError, vendor-text match, returncode-non-zero, missing tokens, cache leak, unrecognized model). **Cognitive isolation via three module-level patch points** (`run_agent_sdk`, `ClaudeSDKClient`, `_check_salt_placement`): production stub raises `NotImplementedError`; tests rebind without touching the real SDK. AC-17 enforces fresh `ClaudeSDKClient` per `execute()` call (defends against SDK Issue #560 session leakage). **Defense-in-depth UNION regex** on Aider/Droid stdout (`rate.?limit|API.?error|connection.?error|context.?length.?exceeded|litellm\.exceptions` + Droid-specific `factorydroid:\s*error`): both CLIs route through litellm, so litellm-shaped errors surface in stdout under upstream failures and would otherwise pass through as `aborted=false` with a misleading `acceptance_pct=0.0`. Regex match precedes returncode check, so an exit-zero process whose stdout reports a rate limit is still aborted with `abort_reason.category="api_error_text"` and `driver_metadata["matched_pattern"]` populated. **374/374 tests green**, +7 new in Phase 5e (4 AC-14 salted-cache contract, 3 AC-19 defense-in-depth on Droid). **Phase 5g deferrals**: 4 SDK CVEs (DEPS-CRIT-1 CVE-2026-35022 CVSS 9.3, DEPS-CRIT-2 CVE-2026-35021 CVSS 8.4, DEPS-HIGH-2, CONCURRENCY-RACE-2) — all attack surfaces unreachable in 5e because `run_agent_sdk` is a `NotImplementedError` stub.
- **Key files**: `task_packs/url_shortener/` (pack tree), `task_packs/loader.py` (typed dataclass binding), `drivers/claude_code.py` (salted cache defeat + cognitive isolation), `drivers/aider.py` (AC-19 vendor-error scan), `drivers/droid.py` (AC-20 defense-in-depth UNION regex), `drivers/_subprocess_helpers.py` (`make_aborted_result` factory), `drivers/_cost_extraction.py` (Aider/Droid stdout parsers), `drivers/_protocol.py` (`DriverResult`, `AbortReason`, `CacheStrategy`), `harness/runner.py` (mounts + `run_cell` integration), `tests/drivers/`, `tests/task_packs/test_v1_trust_model.py` (AC-21), `docs/adr/019-task-pack-v1-architecture.md` (NEW), `docs/adr/README.md` (index entry)

### Benchmark Harness Dashboard (Phase 3 A4) — Empty-Denylist Fail-Closed Policy + ADR-017 Extraction
- **Version**: Unreleased (pending version bump)
- **Team Role**: Engineering Manager / Platform Ops / Security Reviewer
- **Description**: Closes the misconfiguration path A3 left fail-open-with-warning. **Empty-denylist fail-closed (AC-15.A4.1)**: `_load_denylist` raises `ValueError` when zero tokens parse (was: stderr warning + render). The previous fail-open-with-warning behavior allowed a misconfigured deployment to ship rendered output that bypassed every denylist check — a loud break is recoverable, a silent ship of leaked content is not. The check runs before any `write_text`, preserving atomic-write semantics: no `.tmp` is materialized when the gate fires. The 12 sibling tests that previously wrote `""` as a no-op denylist fixture now use a `_NO_MATCH_DENYLIST` module sentinel constant so they continue to exercise the full gate path. **ADR-017 extracted**: architectural rationale (Docker+tmpfs+git sanitization, Driver protocol + cost-extraction shims, append-only JSONL, N=10 + median + IQR, fail-closed denylist gate) is captured as `docs/adr/017-benchmark-harness-architecture.md`; `.sherlock-plan.md` and `.test-matrix.md` retire per Step 8. **DELIBERATELY DEFERRED in A4**: H-1 (UTS #39 skeleton algorithm for cross-script confusables — Greek, Armenian, combining diacritics, U+2060, U+180E) and M-3 (DA-15 parametrize expansion) are documented in ADR-017 `Consequences → Negative` with revisit trigger "dashboard outputs become public-facing OR untrusted-input-fed path lands in the harness." Rationale: at the v1 threat model neither attacker controls a benchmark prompt nor a driver's output ingress; partial Unicode coverage is theater absent that ingress.
- **Key files**: `dashboard/render.py` (`_load_denylist` raises `ValueError`, `render_dashboard` docstring `Raises:` block), `tests/dashboard/test_render.py` (DA-11 oracle inversion + `_NO_MATCH_DENYLIST` sentinel migration), `docs/adr/017-benchmark-harness-architecture.md` (NEW), `docs/adr/README.md` (index entry), `docs/70-INSIGHTS.md` (Insight #31)

### Benchmark Harness Dashboard (Phase 3 A3) — Denylist Hardening (atomic write, fail-fast on missing denylist, malformed-row filter, XSS lock, Unicode/ZWSP + hyphen)
- **Version**: Unreleased (pending version bump)
- **Team Role**: Engineering Manager / Platform Ops / Security Reviewer
- **Description**: Closes the AC-15 hardening edges the A1/A2 security reviewer flagged as attacker-controllable. **Atomic write (AC-15)**: denylist gate runs before any `write_text`, so a violation leaves no artifact on disk (DA-9). **Fail-fast on missing denylist (AC-15)**: `FileNotFoundError` with no output. **Empty denylist behavior (A3)**: fail-open-with-warning (`WARNING: empty denylist at <path>` on stderr) — **superseded in A4 by fail-closed `ValueError`**; see the A4 entry above. **Malformed-row filter (AC-10)**: rows missing `driver` OR `task` are dropped and counted; `<div data-qa="malformed-rows-banner">` renders the count when > 0. **XSS lock (AC-10)**: attacker-controlled `driver_version` containing `<script>` is HTML-encoded via Jinja2 autoescape (DA-13). **Unicode/ZWSP/whitespace denylist bypass defense (AC-15)**: `_normalize_for_denylist` applies NFKC → 6-entry Cyrillic confusable fold (р/о/а/с/е/х → Latin) → 4-char zero-width strip (ZWSP/ZWNJ/ZWJ/BOM) → whitespace collapse; `_check_denylist` re-runs the word-boundary match on the normalized form so `рricing`, `pri‍cing`, and `pri cing` all raise (DA-15 parametrized). **Hyphenated-form lock-in (AC-15)**: `pricing-model` fires on denylist token `pricing` — Python `\b` treats hyphens as word boundaries; DA-16 locks this behavior against future regex refactors. Does NOT yet implement UTS #39 skeleton (deferred — the boundary is documented in `_normalize_for_denylist` docstring; A4 explicitly bounded this deferral against revisit trigger). 11 new tests (DA-9/10/11/12/12c/13 + DA-15 parametrized + DA-16), 2 new fixtures (`malformed_row.jsonl`, `xss_row.jsonl`).
- **Key files**: `dashboard/render.py` (`_normalize_for_denylist` + `_token_matches` + malformed-row guard + autoescape `from_string`), `tests/dashboard/test_render.py` (DA-9/10/11/12/12c/13), `tests/dashboard/test_denylist.py` (DA-15/16), `tests/dashboard/fixtures/{malformed_row,xss_row}.jsonl`

### Benchmark Harness Dashboard (Phase 3 A2) — Partial-Cell Marker + Mixed-Metadata Dual-Surface Warnings
- **Version**: Unreleased (pending version bump)
- **Team Role**: Engineering Manager / Platform Ops
- **Description**: Extends the Phase 3 A1 renderer with two visible warning surfaces for sweeps whose numbers are not straightforwardly comparable to a clean full run. **Partial-cell marker** (AC-10 (b)): `data-qa="partial-cell"` attribute on the existing `<p>` tag, fires when `aggregate_cell` reports effective N ≤ threshold (7/10 inclusive). **Mixed-metadata dual-surface warning** (AC-10 (c)): fires when rows inside a single `(driver, task)` cell disagree on `container_digest` or `sdk_version`, with BOTH a top-of-page banner (`data-qa="digest-banner"` / `data-qa="sdk-banner"` — rendered OUTSIDE every `<section>` so a reader cannot miss it on scroll) AND a per-cell badge (`data-qa="digest-badge"` / `data-qa="sdk-badge"` — inside the affected cell for attribution). The dual surface is load-bearing: banner-only misses readers who scroll past, badge-only de-emphasises the warning. `_detect_mixed_metadata(rows, field)` pure helper treats `None` as a distinct value (row missing metadata is environment-unknown, warning-worthy). 5 new tests (DA-2 through DA-5, DA-14) and 4 new fixtures. DA-14 locks the aggregator's aborted-row-exclusion invariant at the render boundary (medians over 7 non-aborted rows, partial marker fires at effective n=7<10, all 3 aborted seeds' extreme values absent from HTML).
- **Key files**: `dashboard/render.py` (template + `_detect_mixed_metadata`), `tests/dashboard/test_render.py` (5 new tests), `tests/dashboard/fixtures/{partial_cell,mixed_digest,mixed_sdk,aborted_rows}.jsonl`

### Benchmark Harness Dashboard (Phase 3 A1) — Static HTML + ADR-007 Denylist Gate
- **Version**: v0.14.33
- **Team Role**: Engineering Manager / Platform Ops
- **Description**: `dashboard/render.py::render_dashboard` reads a benchmark sweep's `results.jsonl`, groups rows by `(driver, task)`, computes median + IQR (p25/p75) per cell via `aggregation.results.aggregate_cell`, and writes a single-file static HTML report via Jinja2 (`select_autoescape(["html"])` with `default_for_string=True`). Before any write-to-disk, an **ADR-007 bright-line denylist gate** runs against the rendered HTML — any token match via `re.search(rf"\b{re.escape(token)}\b", html, re.IGNORECASE)` raises `RuntimeError` and no output file is produced. This is the committed-tree enforcement of the bright-line-sanitization policy on an artifact populated from attacker-influenceable JSONL fields (drivers emit `driver_version` as arbitrary LLM output). Jinja2 floor bumped `>=3.1.6,<4.0` to cover CVE-2024-56326 and CVE-2025-27516 (`UNVERIFIED_CLAIM` — Jinja2 changelog is citation of record before downstream quoting). A2 (partial-cell rendering) and A3 (Unicode normalization + hyphen hardening) are open follow-up sub-phases; ADR-011 extraction queued for post-A3.
- **Key files**: `dashboard/render.py`, `tests/dashboard/test_render.py`, `tests/dashboard/test_denylist.py`, `tests/dashboard/fixtures/full_cell.jsonl`, `pyproject.toml` (Jinja2 floor)

### Zero-Friction Installer — `uvx shipteam init`
- **Version**: Unreleased
- **Team Role**: Onboarding / DevOps Engineer
- **Description**: Replaces the 534-line `scripts/init-project.sh` bash wizard with a Python CLI distributed via PyPI (`uvx shipteam init`) and npm (`npm create shipteam`). Auto-detects stack (Python/Node mono- and polyrepo layouts), renders a fully-populated `CLAUDE.md` from a Jinja template (zero `CUSTOMIZE` markers), scaffolds `.claude/` (23 agents, profile-filtered rules, 10 skills, 18 hooks), writes `config/framework.yaml` + `.shipteam-init.yaml` state, and appends required `.gitignore` entries — all in ~30 seconds, no clone required. Subsequent `uvx shipteam init --refresh` re-renders framework-owned managed regions (`<!-- SHIPTEAM:BEGIN:name -->`) while preserving user edits by default. 133 passing tests, 1 documented TTY-prompt xfail. See `docs/adr/008-zero-friction-installer.md` for the decision rationale.
- **Key files**: `src/shipteam/*.py` (CLI + 8 modules), `src/shipteam/framework/` (bundled content via `package_data`), `src/shipteam/framework/templates/CLAUDE.md.jinja`, `npm/create-shipteam/`, `pyproject.toml`, `tests/test_*.py`

### Remove Feature Tier Gating — All Agents Available
- **Version**: v0.13.0
- **Team Role**: Onboarding / Engineering Manager
- **Description**: The `feature_tier` config section has been removed from `framework.yaml` and tier-conditional branches have been stripped from `.claude/rules/sherlock-methodology.md` and `.claude/rules/sherlock-review-gate.md`. All 22 agents, all workflow modes, and the full multi-agent parallel review pipeline are available to every user unconditionally. This is a BREAKING change for any project that had `feature_tier:` entries in its local `framework.yaml` — remove the section and run `uvx shipteam init --refresh` if needed. See `docs/adr/006-remove-feature-tier-gating.md` for the decision rationale.
- **Key files**: `config/framework.yaml` (feature_tier section deleted), `.claude/rules/sherlock-methodology.md`, `.claude/rules/sherlock-review-gate.md`, `docs/adr/006-remove-feature-tier-gating.md`

### Cross-Project Framework Stats in Insights Dashboard
- **Version**: v0.12.0
- **Team Role**: Engineering Manager / Measure stage
- **Description**: `scripts/generate_insights.py` now discovers every framework-managed project on the local machine and aggregates their `.context/metrics/` data into the Claude Code Insights dashboard. Discovery walks `$HOME` (depth ≤ 3) for `config/framework.yaml`, skips heavy directories (`node_modules`, `.git`, `.venv`, `Library`, `.pnpm-store`, `.yarn`, `bower_components`, etc.), uses `os.walk(followlinks=False)` for symlink-loop safety, and caches the results at `~/.claude/fw-project-paths.json` so subsequent runs are instant. Worktree clones (`dev-framework-session-claude-*`) roll up under their parent project name via the existing `canonicalize_project()` helper, so the cross-project comparison shows true per-project totals rather than per-session noise. The dashboard renders an aggregate KPI strip (safety blocks, cost routes, est. savings, conformance avg, protocol warnings, sessions) and a per-project comparison table. Two new CLI flags: `--refresh-fw-projects` forces a fresh filesystem scan, `--no-fw-stats` skips framework metrics entirely. The aggregation reuses `aggregate_safety` / `aggregate_cost_routing` / `aggregate_conformance` / `aggregate_protocol` / `aggregate_sessions` from `scripts/generate_dashboard.py` via a dual-path import, so there is no duplicate aggregation logic. The project-level `/fw-stats` skill at `.claude/skills/fw-stats/SKILL.md` is unchanged and still distributed to all projects via `fw-manifest.yaml`. See Insight #22 for the worktree-rollup lesson.
- **Key files**: `scripts/generate_insights.py`, `scripts/tests/test_insights.py`, `~/.claude/fw-project-paths.json` (runtime cache)

### Provider-Agnostic Capability Tiers
- **Version**: v0.11.0
- **Team Role**: DevOps Engineer
- **Description**: Cost routing tiers renamed from Anthropic-specific model names (`opus`/`sonnet`/`haiku`) to provider-agnostic capability tiers (`high`/`standard`/`fast`). New `providers` section in `framework.yaml` maps capability tiers to provider-specific model names (anthropic, openai, google). This is the foundation for Phase 1 multi-provider support — a future `generate-agents.py` script will read the providers config and generate `.claude/agents/` files with the correct provider-specific model names. Agent frontmatter (`model: opus`) is unchanged for now as those are Claude Code runtime values.
- **Key files**: `config/framework.yaml` (cost + providers sections), `scripts/cost_routing.py`, `scripts/tests/test_cost_routing.py`, `.claude/rules/sherlock-review-gate.md`

### Agent Teams Dual-Mode Orchestration
- **Version**: v0.10.9
- **Team Role**: DevOps Engineer / Solutions Architect
- **Description**: Framework agents can now run in two orchestration modes: `subagent` (existing, default) and `agent-teams` (opt-in). Agent Teams mode creates dependency-tracked tasks for Anthropic's Agent Teams feature, enabling parallel teammate execution in separate worktrees with peer-to-peer messaging. TDD phases use `blockedBy` chains (GREEN blocked by RED, REFACTOR blocked by GREEN). Review pipeline tasks are generated via `cost_routing.py --mode agent-teams`. New `task-quality-gate.py` hook blocks reviewer task completion on Critical findings. All 11 agents with `project-context` skill get runtime fallback instructions. 3 TDD agents get cognitive isolation enforcement for teammate mode. 30 new tests.
- **Key files**: `config/framework.yaml` (orchestration section), `scripts/cost_routing.py` (`format_as_tasks()`), `.claude/hooks/task-quality-gate.py`, `.claude/hooks/metrics-tracker.py`, `.claude/rules/sherlock-methodology.md`, `.claude/rules/sherlock-review-gate.md`

### Session Lock at Startup
- **Version**: v0.10.1+
- **Team Role**: DevOps Engineer
- **Description**: `session-lifecycle.py` (SessionStart hook) now creates `session-lock.json` immediately when a Claude session starts, closing a gap where concurrent-session guards (`checkout-guard.py`, `worktree-enforcer.py`) didn't activate until the first `git checkout`. Handles stale lock reclamation (dead PID), live lock preservation, and corrupt file recovery.
- **Key files**: `.claude/hooks/session-lifecycle.py`, `scripts/tests/test_session_lifecycle.py`

### Framework Metrics & Conformance System
- **Version**: v0.10.0
- **Team Role**: Engineering Manager
- **Description**: Quantitative measurement of build team effectiveness. `fw_event_log.py` logs safety blocks, cost routing decisions, and protocol violations as structured JSONL events (fire-and-forget, fcntl-locked, date-partitioned, 50MB rotation). `fw_conformance.py` scores Sherlock/Holmes sessions against `.sherlock-plan.md` across 5 dimensions: file coverage (25%), AC coverage (30%), scope creep (15%), hook compliance (15%), review gate (15%). `/fw-stats` skill aggregates metrics over time windows (7d/30d/all) with safety events, cost savings, conformance scores, and TDD health ratios. 70 new tests.
- **Key files**: `scripts/fw_event_log.py`, `scripts/fw_conformance.py`, `.claude/skills/fw-stats/SKILL.md`

### Progressive Adoption: Complexity Profiles
- **Version**: v0.9.0
- **Team Role**: Onboarding
- **Description**: Three complexity profiles (`minimal`/`standard`/`full`) in `framework.yaml` control how much of the build team is active. `minimal` gives safety gates only (~15 components). `standard` adds Sherlock + TDD + core skills (~40 components). `full` enables everything (~75 components). Profile-aware `init-project.sh` applies defaults automatically. First Week Guide provides day-by-day progressive learning path.
- **Key files**: `config/framework.yaml`, `scripts/init-project.sh`, `docs/ADOPTION.md`

### Professional Agent Naming Convention
- **Version**: v0.8.0
- **Description**: All 27 agents renamed to consistent `fw-{verb}-{domain}` convention. 4 verb categories: `fw-review-*` (evaluates code), `fw-author-*` (creates artifacts), `fw-advisor-*` (strategic guidance), `fw-tdd-*` (TDD phases). Personal agents use `advisor-*` and `review-*` without the `fw-` prefix. 20 deprecated entries enable automatic cleanup during `fw-sync.sh`.
- **Key files**: `config/fw-manifest.yaml`, all `.claude/agents/*.md` files

### DRY Spec Format Extraction
- **Version**: v0.8.0
- **Description**: The `.sherlock-plan.md` template (Acceptance Criteria, Interface Contracts, TDD phases) extracted from `sherlock-methodology.md` into `.claude/spec-format.md` as single source of truth. Eliminates duplication across methodology, fw-tdd-red, and fw-author-spec.
- **Key files**: `.claude/spec-format.md`, `.claude/rules/sherlock-methodology.md`

### Documentation Staleness Gate
- **Version**: v0.7.0
- **Description**: `protocol-validator.py` now BLOCKS `gh pr create` when `release_notes.md` or `CHANGELOG.md` are not updated for the current version. Ensures documentation stays current with code changes. Gated by `hooks.doc_staleness_check` config.
- **Key files**: `.claude/hooks/protocol-validator.py`

### Spec Author Agent
- **Version**: v0.7.0
- **Description**: `fw-author-spec` generates structured specifications (Acceptance Criteria in Given/When/Then, Interface Contracts with typed signatures) from requirements. Supports autonomous and interactive modes. Output feeds directly into `fw-tdd-red` for the RED phase.
- **Key files**: `.claude/agents/fw-author-spec.md`

### Test Strategy Author Agent (Enhanced Lead Orchestrator)
- **Version**: v0.13.8
- **Description**: `fw-author-test-strategy` authors a proactive test matrix (`.test-matrix.md`) from `.sherlock-plan.md` Acceptance Criteria. Risk-tiered tests (P0/P1/P2), type classification (unit/integration/e2e), and oracle hints — including metamorphic/differential/property-based candidates for non-obvious oracles. Invoked ONCE per plan (Sherlock Lite Step 1 or Full Sherlock Step 4.5 post-validation). `fw-review-tests` consumes the matrix at every per-phase review gate (missing P0 = Critical). Exempt from Hudson and doc-only changes. Ships with Lead Judgment (Priority Stack + Risk Watch) and Decision Digest sections in the plan format.
- **Key files**: `.claude/agents/fw-author-test-strategy.md`, `.claude/agents/fw-review-tests.md` (matrix-consumption section), `.claude/spec-format.md` (Lead Judgment + Decision Digest), `.claude/rules/sherlock-methodology.md` (Step 0 memory lens + invocation wiring), `docs/adr/009-enhanced-lead-orchestrator-artifacts-over-reasoning.md`

### Supply Chain Security Review
- **Version**: v0.7.0
- **Description**: `fw-review-dependencies` reviews dependency changes for CVE reachability, license compatibility (GPL contamination), maintenance health, typosquatting, and behavioral signals (install scripts, obfuscated code). Opus model for complex transitive chain analysis.
- **Key files**: `.claude/agents/fw-review-dependencies.md`

### Concurrency Review
- **Version**: v0.7.0
- **Description**: `fw-review-concurrency` detects race conditions, deadlocks, and shared state issues across Python asyncio, Node.js, React, and database transactions. Covers TOCTOU patterns, stale closures, and missing locks.
- **Key files**: `.claude/agents/fw-review-concurrency.md`

### Spec-Driven Development (SDD)
- **Version**: v0.7.0
- **Description**: Integrates spec-anchored development into the Sherlock/Holmes workflow. `.sherlock-plan.md` now includes structured Acceptance Criteria (Given/When/Then) and Interface Contracts. Architecture decisions are extracted as ADRs post-commit. TDD agents consume specs directly.
- **Key files**: `.claude/rules/sherlock-methodology.md`, `.claude/agents/fw-tdd-red.md`, `docs/adr/README.md`

### Sherlock Methodology as Syncable Rule
- **Version**: v0.7.0
- **Description**: Full Sherlock/Holmes/Hudson workflow (Step 0 complexity routing, all 4 modes, spec-anchored plan format) extracted from personal `~/.claude/CLAUDE.md` into `.claude/rules/sherlock-methodology.md`. Now syncs to all projects via `fw-sync.sh` with `replace` policy.
- **Key files**: `.claude/rules/sherlock-methodology.md`, `config/fw-manifest.yaml`

### Cost Routing for Review Pipeline
- **Version**: v0.5.0
- **Description**: Classifies code changes by type (docs-only, config-only, deps-only, style-only, test-only) and LOC to select the minimal effective set of review agents. Reduces multi-agent review costs by skipping unnecessary reviewers.
- **Key files**: `scripts/cost_routing.py`, `.claude/rules/sherlock-review-gate.md`, `scripts/tests/test_cost_routing.py`

### DevContainer with Deny-by-Default Firewall
- **Version**: v0.5.0
- **Description**: Containerized development environment with IPv4+IPv6 network-layer firewall that blocks all outbound traffic except explicitly allowlisted hosts. Provides API key protection and non-root execution.
- **Key files**: `.devcontainer/devcontainer.json`, `.devcontainer/init-firewall.sh`

### Bundled Review Agents (Quality Bar Upgrade)
- **Version**: v0.5.0
- **Description**: Four specialized review agents upgraded to production quality bar: AI code forensics (supply chain, AI tell detection), silent failure hunter (swallowed errors), type design analyzer (invariant scoring 1-10), comment analyzer (staleness, accuracy). Plus an agent template for creating custom agents.
- **Key files**: `.claude/agents/fw-review-forensics.md`, `.claude/agents/fw-review-error-handling.md`, `.claude/agents/fw-review-types.md`, `.claude/agents/fw-review-comments.md`, `.claude/agents/AGENT_TEMPLATE.md`

### Upstream Hooks + Config Loader
- **Version**: v0.4.0
- **Insight**: [#3](70-INSIGHTS.md)
- **Description**: Centralized config loading (`path_utils.py`) so all hooks read `framework.yaml` without duplicating parse logic. Base/overlay architecture for safety gate (`auto_approve_base.py` + `auto-approve.py`) allows upstream safety updates without losing project customizations.
- **Key files**: `.claude/hooks/path_utils.py`, `.claude/hooks/auto_approve_base.py`, `.claude/hooks/auto-approve.py`

### Checkout Guard
- **Version**: v0.4.0
- **Description**: Blocks branch switches when another Claude session is active, preventing concurrent session interference. Uses session lock file detection with 30-minute stale lock timeout.
- **Key files**: `.claude/hooks/checkout-guard.py`, `.claude/state/session-lock.json`

### Commit Trust Check
- **Version**: v0.4.0
- **Description**: Gated by `hooks.deploy_gate` config. Blocks pushes if CI failed. Checks `deployment.health_url` on main branch before allowing deployment actions.
- **Key files**: `.claude/hooks/commit_trust_check.py`, `.claude/hooks/commit-trust-check.py`

### Framework Distribution (fw-sync)
- **Version**: v0.4.0
- **Description**: Pull upstream framework improvements into projects with three sync policies: replace (overwrite), template (show diff for review), merge (three-way merge). SHA-tracked to avoid re-syncing unchanged files. Config-gated to skip disabled features.
- **Key files**: `scripts/fw-sync.sh`, `config/fw-manifest.yaml`

### Threat Modeling Templates
- **Version**: v0.4.0
- **Description**: STRIDE, OWASP Top 10, AI/LLM threats, and LINDDUN privacy threat modeling templates. Threat model documents are kept private (not in repo) as they contain security posture details.
- **Key files**: Private — not committed to repository

### Default-Deny Safety Gates
- **Version**: v0.3.0
- **Insight**: [#3](70-INSIGHTS.md)
- **Description**: Exit code 2 hard blocks that cannot be bypassed through auto-approval. Blocks `rm -rf` (default-deny), `git push --force`, destructive SQL (comment-bypass-aware), `git reset --hard`, branch deletion (flag-combo-aware), `git push --delete`. Verified by 61+ test cases (including bypass prevention tests).
- **Key files**: `.claude/hooks/auto_approve_base.py`, `.claude/hooks/auto-approve.py`, `test/test_safety_gate.sh`

### Multi-Agent Review Pipeline (Sherlock/Holmes)
- **Version**: v0.3.0
- **Description**: Three-tier complexity routing (Hudson/Sherlock Lite/Full Sherlock) with multi-agent review pipeline. Per-phase and final gate reviews with domain authority hierarchy, conflict resolution protocol, and cost-optimized agent selection.
- **Key files**: `.claude/rules/sherlock-review-gate.md`, `CLAUDE.md`

### Visual QA and Retrospective Skills
- **Version**: v0.3.0
- **Description**: `/browse <url>` for single-page visual inspection via Playwright MCP. `/qa [--full]` for diff-aware visual testing across changed routes. `/retro [7d|14d|30d]` for engineering retrospectives from git history.
- **Key files**: `.claude/skills/browse/SKILL.md`, `.claude/skills/qa/SKILL.md`, `.claude/skills/retro/SKILL.md`

### Rules System
- **Version**: v0.2.0
- **Description**: Modular `.md` files in `.claude/rules/` auto-loaded by Claude based on file paths. Four built-in rules: anti-patterns (10 mandatory rules), security (OWASP + PII), database migrations (schema verification), and Sherlock review gate (multi-agent pipeline).
- **Key files**: `.claude/rules/anti-patterns.md`, `.claude/rules/security.md`, `.claude/rules/database-migrations.md`, `.claude/rules/sherlock-review-gate.md`

### Skills System
- **Version**: v0.2.0
- **Description**: Nine invocable commands: `/deploy` (tiered checklist), `/health` (production verification), `/release-notes` (PR description + insight), `/schema-check` (DB verification), `/browse` (visual inspection), `/qa` (diff-aware testing), `/retro` (retrospective), `/tdd-commit` (TDD phase commits), `/ship` (branch + commit + push + PR).
- **Key files**: `.claude/skills/*/SKILL.md`

### TDD Commit Workflow
- **Version**: v0.1.0
- **Description**: RED/GREEN/REFACTOR commit scripts with phase-specific validation. Auto-generates commit messages with phase attribution. Optional strict mode via `TDD_MODE=1`.
- **Key files**: `scripts/tdd-commit.sh`, `.claude/skills/tdd-commit/SKILL.md`

### Session Isolation via Git Worktrees
- **Version**: v0.1.0
- **Description**: Each Claude session runs in its own git worktree with session locks, auto-sync with origin/main, drift detection, and merge conflict recovery. Concurrent sessions never interfere.
- **Key files**: `scripts/claude-session.sh`, `.claude/hooks/branch-check.py`, `.claude/hooks/checkout-guard.py`, `.claude/hooks/worktree-enforcer.py`

### Config-Driven Architecture
- **Version**: v0.1.0
- **Description**: Single `config/framework.yaml` drives all 21+ scripts. Covers project metadata, stack config, versioning, CI/CD, TDD settings, cost management, rules/skills activation, and deployment. Shared bash library (`_framework.sh`) provides YAML parsing and git environment setup.
- **Key files**: `config/framework.yaml`, `scripts/_framework.sh`

### Auto Version Bumping
- **Version**: v0.1.0
- **Description**: Patch version auto-increments on merge to main via GitHub Actions. Updates all files listed in `framework.yaml` versioning locations. Creates annotated git tags. Prevents loops by skipping bot commits.
- **Key files**: `.github/workflows/auto-version-bump.yml`, `scripts/bump-version.sh`

### CI/CD Pipeline
- **Version**: v0.1.0
- **Description**: Stack-agnostic GitHub Actions for version consistency, secrets guard, backend tests, frontend tests, security scanning (Semgrep), dependency vulnerability scanning. Fast deploy option for hotfixes.
- **Key files**: `.github/workflows/ci-cd.yml`, `.github/workflows/security-scan.yml`, `.github/workflows/semgrep.yml`

### Pre-Compact Context Persistence
- **Version**: v0.1.0
- **Description**: Saves enriched session state before Claude context compaction: branch, commit SHA, PR title, diff stats, active plan reference. Enables session resumption after compaction.
- **Key files**: `.claude/hooks/pre-compact.py`, `.claude/state/pre-compact-handoff.json`

## Planned Features

<!-- Features approved but not yet implemented. Remove from here when shipped. -->

| Feature | Priority | Status | Notes |
|---------|----------|--------|-------|
| ~~Demo GIF recordings~~ | ~~High~~ | Done | 7 VHS demos with build team language: hero-reel, safety-gate, tdd-workflow, session-isolation, cost-routing, sherlock-routing, init-wizard. All GIFs embedded in README. |
| ~~Migration script for v0.5.0~~ | ~~Medium~~ | Superseded | `fw-sync.sh` (v0.4.0+) handles version-to-version upgrades with replace/template/merge policies. Deprecated file cleanup automated via `fw-manifest.yaml` entries. |
| Automated GPG-signed release tags | Low | Not started | Add GPG key as GitHub secret + sign in auto-version-bump.yml. First release signed manually (R-002). |
| ~~Test coverage for critical hooks~~ | ~~High~~ | Done | 151 new tests: `path_utils.py` (56 tests), `commit_trust_check.py` (54 tests), `branch-check.py` (41 tests). All pass. |
| ~~Consolidate remaining hook duplication~~ | ~~Medium~~ | Done | All 7 hooks now import shared utilities from `path_utils.py`. `GIT_ENV`, `get_current_branch`, `read_session_lock`, `is_lock_stale`, `is_process_alive` consolidated. Fallbacks preserved for portability. |
| ~~Archive stale migration script~~ | ~~Low~~ | Done | Deleted `scripts/migrate-v0.3.0.sh` (832 lines, 2 versions behind). `fw-sync.sh` replaces per-version migration pattern. |
| ~~Shell error handling hardening~~ | ~~Low~~ | Done | `_framework.sh` upgraded to `set -euo pipefail` (propagates to 18 scripts). `fw_get()` rewritten for pipefail safety. Fixed bare `$1` in `tdd-commit.sh` and `sync-with-main.sh`. |

## Feature Flags

Feature flags are managed through `config/framework.yaml` sections:

| Flag (Config Key) | Default | Description |
|-------------------|---------|-------------|
| `rules.database_migrations` | `true` | Enable database migration rules auto-loading |
| `skills.schema_check` | `true` | Enable `/schema-check` skill |
| `skills.deploy` | `true` | Enable `/deploy` skill |
| `skills.health` | `true` | Enable `/health` skill |
| `skills.qa` | `true` | Enable `/qa` visual QA skill |
| `skills.retro` | `true` | Enable `/retro` retrospective skill |
| `skills.fw_stats` | `true` | Enable `/fw-stats` metrics + conformance skill |
| `metrics.enabled` | `true` | Enable event logging and conformance scoring |
| `hooks.deploy_gate` | `false` | Enable CI-must-pass before push (commit trust check) |
| `prompts.versioning` | `false` | Enable LLM prompt version tracking |

### Adding a New Feature Flag

1. Add the config key to `config/framework.yaml` under the appropriate section
2. Gate the feature in code/hooks using `path_utils.py` config loading
3. Document the flag in the table above
4. Add a `config_gate` entry in `config/fw-manifest.yaml` for fw-sync distribution
