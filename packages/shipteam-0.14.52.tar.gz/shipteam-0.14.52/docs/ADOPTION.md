# Adoption Guide

How to evaluate and roll out ShipTeam for your team.

---

## Platform Compatibility

ShipTeam requires **Claude Code** — Anthropic's agentic coding tool. Claude Code runs the same engine on all its surfaces, so the framework works everywhere Claude Code does:

| Platform | Support | Hooks | Skills | Rules | CLAUDE.md |
|----------|---------|-------|--------|-------|-----------|
| **Claude Code CLI** | Full | Yes | Yes | Yes | Yes |
| **Claude Code Desktop app** | Full | Yes | Yes | Yes | Yes |
| **Claude Code VS Code extension** | Full | Yes | Yes | Yes | Yes |
| **Claude Code JetBrains extension** | Full | Yes | Yes | Yes | Yes |
| **Claude Code on the Web** (claude.ai/code) | Full | Yes | Yes | Yes | Yes |
| claude.ai (chat) | Not supported | No | No | No | No |
| Claude Desktop (chat app) | Not supported | No | No | No | No |
| Cursor / Windsurf / other AI IDEs | Not supported | No | No | No | No |

**Why the distinction matters**: The framework's safety guarantees come from hooks (Python scripts that enforce rules at runtime). Hooks only run inside Claude Code. The `.claude/rules/` files and `CLAUDE.md` are Claude Code project features — they are not read by Claude chat products or non-Anthropic IDEs.

**If your team uses a mix**: Everyone on Claude Code (any surface) gets the full framework. Team members using other tools won't have safety gates, review pipelines, or workflow enforcement.

---

## Time to First Success: Under 10 Minutes

The framework ships with **complexity profiles** so you don't need to understand 75 components before writing your first line of code. Start with `minimal`, graduate to `standard`, then `full` when you're ready.

```bash
# 1. Fork the template
gh repo create my-project --template cdjgroup/dev-framework --private
cd my-project

# 2. Let Claude set it up
claude
# Tell Claude: "Set up this project. My repo is myorg/my-project,
# Python backend on port 8000, React frontend on port 3000. Use minimal profile."

# 3. Start coding with safety gates active
./scripts/claude-session.sh feature/my-first-feature
```

Claude reads `SETUP.md` and `CLAUDE.md` automatically — it will configure `framework.yaml`, run the setup wizard, install hooks, and verify everything. With `profile: minimal`, you get safety gates and Hudson mode — everything else is off.

<details>
<summary>Manual setup (if you prefer)</summary>

```bash
vim config/framework.yaml    # Set: project name, repo, stack, profile: minimal
uvx shipteam init            # installer: renders CLAUDE.md, scaffolds .claude/, writes state (~30s)
```
</details>

---

## Complexity Profiles

The `profile` key in `config/framework.yaml` controls how much of the framework is active:

| Profile | Active Components | What You Get | Best For |
|---------|-------------------|--------------|----------|
| **minimal** | ~15 | Safety gates, branch isolation, anti-pattern rules, Hudson workflow | First-time adopters, evaluation |
| **standard** | ~40 | Everything in minimal + Sherlock/Holmes methodology, TDD subagents, core skills (deploy, health, ship, tdd-commit, release-notes) | Most teams |
| **full** | ~75 | Everything enabled: all 27 agents, 9 skills, 5 rules, full review pipeline | Teams already comfortable with the framework |

### What Each Profile Enables

<details>
<summary><strong>Minimal Profile (~15 components)</strong></summary>

**Hooks (always active — these are the safety foundation):**
- `auto_approve_base.py` + `auto-approve.py` — default-deny destructive command blocking
- `branch-check.py` — enforces correct branch, prevents concurrent session interference
- `checkout-guard.py` — blocks branch switches during active sessions
- `worktree-enforcer.py` — warns if not in isolated worktree
- `branch-tracker.py` — tracks branch state changes
- `pre-compact.py` — saves context before compaction
- `merge-conflict-resolver.py` — detects conflicts, prompts resolution
- `no-cd-commands.py` — prevents directory escape
- `path_utils.py` — shared hook utilities

**Rules:**
- `anti-patterns.md` — 10 rules preventing common AI-assisted dev mistakes
- `security.md` — OWASP prevention, PII, auth rules

**Scripts:**
- `claude-session.sh` — worktree session launcher
- `_framework.sh` — shared config library

**Workflow:** Hudson mode only (4-step quick fix: Explore → Implement → Quick Review → Commit)

</details>

<details>
<summary><strong>Standard Profile (~40 components)</strong></summary>

Everything in minimal, plus:

**Rules:**
- `sherlock-methodology.md` — Hudson/Sherlock Lite/Full Sherlock/Holmes workflows
- `sherlock-review-gate.md` — multi-agent review pipeline with cost routing
- `database-migrations.md` — schema verification protocol

**Skills:**
- `/deploy` — deployment checklist (Tier 1/2/3)
- `/health` — production health verification
- `/release-notes` — PR description + insight generation
- `/tdd-commit` — TDD phase commit messages
- `/ship` — branch + commit + push + PR workflow

**Agents (invoked automatically by Sherlock pipeline):**
- `fw-review-code` — general code review (always runs)
- `fw-tdd-red`, `fw-tdd-green`, `fw-tdd-refactor` — cognitively-isolated TDD
- Plus conditional agents based on what files you change (tests, DB, API, UI, etc.)

**Scripts:**
- `tdd-commit.sh`, `cost_routing.py`, `bump-version.sh`, etc.

**Workflow:** Hudson + Sherlock Lite + Full Sherlock + Holmes

</details>

<details>
<summary><strong>Full Profile (~75 components)</strong></summary>

Everything in standard, plus:

**Additional skills:**
- `/browse` — visual page inspection via Playwright
- `/qa` — diff-aware visual QA testing
- `/retro` — engineering retrospective from git history
- `/schema-check` — database schema verification

**Additional agents (full review pipeline):**
- `fw-review-forensics` — AI code detection, supply chain verification
- `fw-review-error-handling` — empty catch blocks, swallowed errors
- `fw-review-types` — type encapsulation scoring
- `fw-review-comments` — comment accuracy audit
- `fw-review-dependencies` — supply chain security
- `fw-review-concurrency` — race conditions, deadlocks
- `fw-author-spec` — structured spec generation
- `fw-advisor-architecture` — AI system architecture guidance
- All other conditional review agents

</details>

### Changing Profiles

```yaml
# config/framework.yaml
profile: minimal    # Start here
# profile: standard  # Graduate when comfortable
# profile: full      # Enable everything
```

After changing, tell Claude "switch to standard profile" or run `uvx shipteam init --refresh` manually.

You can also override individual toggles after the profile is applied — profiles set defaults, they don't lock you in.

---

## What You Can Safely Ignore

Not everything in the framework is something you interact with. Most components are **infrastructure** — they run automatically and you never think about them.

### Infrastructure (Invisible — Just Works)

These components run behind the scenes. You don't invoke them, configure them, or need to understand them:

| Component | What It Does | You'll Notice It When... |
|-----------|-------------|------------------------|
| `branch-check.py` | Ensures you're on the right branch | It blocks a command on the wrong branch |
| `checkout-guard.py` | Prevents concurrent session interference | It blocks a branch switch |
| `worktree-enforcer.py` | Warns about non-isolated sessions | You see a warning in session output |
| `branch-tracker.py` | Tracks branch state | Never — it's silent |
| `pre-compact.py` | Saves state before context compaction | Never — it's silent |
| `merge-conflict-resolver.py` | Detects merge conflicts | Claude tells you there's a conflict to resolve |
| `no-cd-commands.py` | Prevents directory escape | It blocks a `cd` command |
| `path_utils.py` | Shared utilities for hooks | Never — internal library |
| `_framework.sh` | Config parser for scripts | Never — internal library |
| `protocol-validator.py` | Checks deployment protocol | It warns when you create a PR without updating docs |
| `cost_routing.py` | Selects which agents to run | Never — runs inside Sherlock pipeline |

### Things You Interact With

| Component | How You Use It | Profile |
|-----------|---------------|---------|
| `framework.yaml` | Edit once during setup | All |
| `auto-approve.py` | Add project-specific safe patterns | All |
| `claude-session.sh` | Run to start a session | All |
| Anti-pattern + security rules | Read once; Claude enforces them | All |
| Sherlock methodology | Type "hudson", "sherlock", or "holmes" | Standard+ |
| `/deploy`, `/health`, `/ship` | Type the command when needed | Standard+ |
| `/browse`, `/qa`, `/retro` | Type the command when needed | Full |
| Review agents | Invoked automatically by Sherlock | Standard+ |

---

## First Week Guide

A progressive learning path based on the [30-60-90 day onboarding pattern](https://www.docuwriter.ai/posts/developer-onboarding-best-practices). The research is clear: early wins drive continued adoption ([Instruqt TTFHW](https://instruqt.com/glossary/time-to-hello-world)).

### Day 1: Safety Gates + Hudson (profile: minimal)

**Goal:** Ship your first change with safety gates active.

1. Run `claude` and tell it: "Set up with minimal profile" (or manually: set `profile: minimal` in `framework.yaml` and run `uvx shipteam init`)
2. Start a session: `./scripts/claude-session.sh feature/day-1-test`
4. Make a small change (fix a typo, add a config value)
5. Type "hudson" to Claude — it runs 4 steps: explore, implement, review, commit
6. Test the safety gate: ask Claude to run `rm -rf src/` — watch it get blocked (temp directories like `/tmp/` are whitelisted, but project directories are default-deny)

**What you learn:** The safety gate catches destructive operations. Hudson is a lightweight 4-step workflow for quick fixes. `claude-session.sh` gives you an isolated worktree — your own branch, your own copy of the code, auto-synced with main. See [SETUP.md — Daily Workflow](../SETUP.md#daily-workflow-session-isolation) for the full session isolation guide.

### Day 2-3: Sherlock Lite (profile: standard)

**Goal:** Use the structured TDD workflow for a real feature.

1. Tell Claude "switch to standard profile" (or manually change `framework.yaml` and run `uvx shipteam init --refresh`)
2. Describe a medium-sized feature to Claude (3-5 files)
3. Watch Step 0 classify complexity and recommend Sherlock Lite
4. Follow the 6-step workflow: Plan → Clarify → TDD → Per-Phase Review → Final Gate → Commit
5. Try `/ship` to create a branch, commit, push, and open a PR in one command

**What you learn:** Sherlock Lite creates a plan before coding. TDD subagents write tests before implementation. Review agents catch issues automatically. `/ship` streamlines the PR workflow.

### Day 4-5: Review Pipeline + Cost Routing

**Goal:** Understand which agents run and why.

1. Look at the per-phase review output — notice which agents were selected
2. Check the cost routing: small changes get 1 agent, complex changes get 5+
3. Try a database migration — notice `fw-author-migration` activates automatically
4. Try an API endpoint change — notice `fw-review-api-contracts` activates
5. Look at the cost tiers in `framework.yaml` — Opus for architecture, Haiku for docs

**What you learn:** The review pipeline is smart about which agents to run. Cost routing prevents wasting API tokens. Agents are conditional — they only run when relevant files change.

### Week 2+: Full Sherlock + Holmes (profile: full)

**Goal:** Handle complex cross-cutting features.

1. Tell Claude "switch to full profile" (or manually change `framework.yaml` and run `uvx shipteam init --refresh`)
2. Describe a large feature (6+ files, architectural decision needed)
3. Type "sherlock" — watch the 8-step Full workflow with architecture options
4. Type "holmes" to execute the approved plan
5. Try `/qa` for visual testing, `/retro` for retrospectives
6. Explore the ADR extraction — architecture decisions become permanent records

**What you learn:** Full Sherlock handles complex features with research, architecture design, multi-phase TDD, and comprehensive review. Holmes is the "execute" signal.

---

## Component Dependency Map

Which components are needed at each tier. Higher tiers include everything from lower tiers.

### Tier 1: Safety Foundation (Always Active)

```
Hooks:  auto_approve_base.py → auto-approve.py (overlay)
        branch-check.py, checkout-guard.py, worktree-enforcer.py
        branch-tracker.py, pre-compact.py, merge-conflict-resolver.py
        no-cd-commands.py
        path_utils.py (shared utility — imported by multiple hooks)

Rules:  anti-patterns.md, security.md

Scripts: _framework.sh (config parser — dependency for ALL scripts)
         claude-session.sh (session launcher)
```

### Tier 2: Sherlock Workflow (profile: standard)

```
Rules:  sherlock-methodology.md → sherlock-review-gate.md
        database-migrations.md

Agents: fw-review-code (ALWAYS runs for any code change)
        fw-tdd-red → fw-tdd-green → fw-tdd-refactor (TDD pipeline)
        fw-review-tests (conditional: when tests change)
        fw-review-security (conditional: when auth/RLS touched)
        fw-review-performance (conditional: when DB/API/React touched)
        fw-author-migration (conditional: when DB migrations created)
        fw-review-api-contracts (conditional: when API endpoints touched)
        fw-review-ux (conditional: when UI components touched)
        fw-review-maintainability (conditional: when 3+ files change)
        fw-review-docs (final gate: always)
        fw-author-docs (invoked if fw-review-docs finds updates needed)
        fw-advisor-release (invoked for deployment guidance)

Skills: /deploy, /health, /release-notes, /tdd-commit, /ship

Scripts: tdd-commit.sh, cost_routing.py, bump-version.sh
         protocol-validator.py (blocks PR if docs stale)
         commit-trust-check.py (optional: CI gate)
```

### Tier 3: Full Pipeline (profile: full)

```
Agents: fw-review-forensics (AI tell detection — always runs in final gate)
        fw-review-error-handling (conditional: try/catch code)
        fw-review-types (conditional: new types/models)
        fw-review-comments (always in final gate)
        fw-review-dependencies (conditional: lockfile changes)
        fw-review-concurrency (conditional: async code)
        fw-author-spec (spec generation for Full Sherlock)
        fw-advisor-architecture (architecture evaluation)

Skills: /browse, /qa, /retro, /schema-check
```

---

## Evaluation Checklist

Before adopting, verify these prerequisites:

| Requirement | Why |
|---|---|
| Team uses Claude Code (CLI, Desktop app, VS Code, JetBrains, or claude.ai/code) | Framework is Claude Code-specific — see [Platform Compatibility](#platform-compatibility) |
| Projects use git + GitHub | Hooks, worktrees, and CI/CD are GitHub-native |
| Python 3.9+ and Bash 3.2+ available | Hooks require Python; scripts work with macOS default Bash (DevContainer and WSL satisfy this on Windows) |
| Team is comfortable with fork-and-own model | Not a dependency — you own every file |

## What This Replaces

| Before | After | Benefit |
|---|---|---|
| Ad-hoc Claude Code usage | Structured TDD + review pipeline | Consistent code quality across developers |
| No safety rails | Default-deny destructive command blocking | Prevents `rm -rf`, force-push, destructive SQL |
| Per-developer CLAUDE.md | Shared rules + skills + agents | Consistent AI behavior across sessions |
| Manual version management | Auto-bump on merge to main | Eliminates "forgot to bump" mistakes |
| Hope-based isolation | Worktree sessions + checkout guard | Concurrent Claude sessions never collide |

## How This Complements Your Existing Tools

The framework is a **pre-commit workflow layer**. It runs while code is being written, before it gets committed. This is a different surface than most AI code tools, which makes them complementary rather than competitive.

| Tool | Where It Runs | Relationship |
|---|---|---|
| **CodeRabbit** | On every pull request (post-commit) | **Complementary.** CodeRabbit reviews merged work; the framework reviews before commit. Running both gives you two independent review passes at different stages. |
| **GitHub Copilot Code Review** | On every pull request (post-commit) | **Complementary.** Same reasoning as CodeRabbit — different surface. Copilot reviews team-shared changes; the framework reviews individual commits. |
| **Cursor / Windsurf** | Inside the IDE (during editing) | **Complementary.** Cursor replaces your IDE; the framework configures your AI agent's behavior. You can run Cursor with the framework's methodology loaded. |
| **GitHub Copilot autocomplete** | Line-level suggestions in editor | **Complementary.** Autocomplete is tactical (next line); the framework is strategic (workflow, methodology, review). |
| **SAST/DAST tools** (Snyk, SonarQube) | Scan deployed or built code | **Complementary.** SAST/DAST scans compiled/deployed code; the framework's `fw-review-security` and `fw-review-forensics` agents catch AI-specific issues (hallucinated dependencies, silent auth bypasses, XSS patterns) in generated code before it's committed. |
| **Aider / Cline** | Terminal-first AI coding | **Alternative.** Aider and Cline are different philosophical approaches — they don't ship with a methodology framework. If you prefer a no-opinion tool, use them instead. |

### When the Framework Adds the Most Value

- You're running multiple Claude Code sessions in parallel and need session isolation
- You've had close calls with destructive commands (`rm -rf`, force push, destructive SQL)
- Your team wants consistent AI behavior across developers
- You want to enforce TDD discipline with AI-assisted code
- You want pre-commit review (not just post-commit PR review)
- You need an audit trail of what the AI did and why

### When the Framework Is Probably Overkill

- You're writing throwaway scripts or exploratory prototypes
- You're the only developer and have no compliance or consistency requirements
- You're already satisfied with stock Claude Code + a good system prompt
- Your project doesn't touch anything destructive (no DB, no prod deploys, no shared branches)

## Rollout Strategy

### Phase 1: Single Project Pilot (1-2 weeks)

1. **Fork the template**: `gh repo create my-project --template cdjgroup/dev-framework --private`
2. **Let Claude set it up**: `cd my-project && claude` — then tell Claude your repo name, stack, and ports. It reads `SETUP.md` automatically and runs `uvx shipteam init` (installer renders CLAUDE.md, scaffolds `.claude/`, writes state). Or run it yourself: set `profile: minimal` in `framework.yaml` and run `uvx shipteam init`.
3. **One developer uses it for a real feature**: Not a toy project — real code, real stakes
4. **Evaluate**: Did safety gates catch anything? Was Hudson mode natural? Did session isolation work?
5. **Graduate to `standard`** when the pilot developer is comfortable (typically end of week 1)

### Phase 2: Team Adoption (2-4 weeks)

1. **Share the pilot project** with the team
2. **Each developer runs `./scripts/claude-session.sh`** for their feature branches
3. **Customize rules**: Add stack-specific anti-patterns to `.claude/rules/anti-patterns.md`
4. **Customize agents**: Create project-specific review agents from `AGENT_TEMPLATE.md`
5. **Enable `hooks.deploy_gate`**: Require CI pass before push (optional)
6. **Graduate to `full`** when the team is comfortable with Sherlock Lite workflows

### Phase 3: Multi-Project Expansion

1. **Create new projects from the template** for each repo
2. **Use `fw-sync.sh`** to pull framework improvements across projects
3. **Standardize `framework.yaml` settings** across the org (use template policy files)
4. **Use the DevContainer** for consistent cross-platform environments (`.devcontainer/devcontainer.json`)

### Windows & Cross-Platform Teams

The framework requires Bash 3.2+ and Python 3.9+, which are not natively available on Windows. Two supported paths:

| Path | Best for | Setup |
|---|---|---|
| **DevContainer** (recommended) | Teams wanting identical environments | Open repo in VS Code, "Reopen in Container". Pre-configured with Bash 5.x, Python 3.12, Node.js LTS, Claude Code. Requires [Docker Desktop](https://www.docker.com/products/docker-desktop/). |
| **WSL** | Developers who prefer full Linux access | `wsl --install` (Windows 10 2004+/11), then follow Linux setup in [SETUP.md](../SETUP.md#platform-setup). |

The DevContainer also includes a deny-by-default firewall (`init-firewall.sh`) that protects API keys from exfiltration — an additional security benefit beyond cross-platform consistency.

Scripts validate prerequisites on first run (`_framework.sh` checks Bash and Python versions) and provide clear error messages with platform-specific install instructions.

## Customization Points

The framework is designed to be customized at specific extension points:

| What to Customize | File | Sync Policy |
|---|---|---|
| Project name, stack, ports, profile | `config/framework.yaml` | merge (preserves your values) |
| Safety gate overrides | `.claude/hooks/auto-approve.py` | template (you own it) |
| Anti-pattern rules | `.claude/rules/anti-patterns.md` | template (add stack-specific examples) |
| Security rules | `.claude/rules/security.md` | template (add auth/RLS patterns) |
| Session launcher | `scripts/claude-session.sh` | template (customize repo URLs) |
| DevContainer hosts | `.devcontainer/init-firewall.sh` | template (add allowed hosts) |
| Review agents | `.claude/agents/*.md` | replace (framework-managed) |
| Skills | `.claude/skills/*/SKILL.md` | replace (framework-managed) |

**Rule of thumb**: `template` files are yours to customize. `replace` files are framework-managed and will be overwritten on `fw-sync`.

## Cost Considerations

### API Costs

The multi-agent review pipeline (Sherlock/Holmes mode) spawns multiple Claude instances. Cost scales with:
- **Number of review agents**: Cost routing (`scripts/cost_routing.py`) minimizes this
- **Model tier**: Opus for deep reasoning, Sonnet for standard analysis, Haiku for pattern matching
- **Diff size**: Larger diffs = more tokens per agent

Typical costs per feature (rough estimates):
- Hudson (quick fix): 1 agent call ~ $0.05-0.10
- Sherlock Lite (medium): 3-5 agent calls ~ $0.30-0.80
- Full Sherlock (complex): 8-15 agent calls ~ $1.00-3.00

### Reducing Costs

1. **Start with `minimal` profile**: No review agents at all until you're ready
2. **Use cost routing**: The script skips irrelevant agents automatically
3. **Use Hudson for small changes**: Don't over-process a typo fix
4. **Disable unused skills**: Set `skills.qa: false` if you don't use visual testing
5. **Use Haiku-tier agents**: fw-review-comments already defaults to Haiku

## Security Model

### What's Protected

- **Destructive commands**: Hard-blocked by `auto_approve_base.py` (exit code 2)
- **Branch operations**: Checkout guard prevents concurrent session interference
- **API keys**: DevContainer firewall limits where keys can be exfiltrated to
- **Production access**: `commit-trust-check.py` gates on CI pass before push to main

### What's NOT Protected

- **Prompt injection**: Claude Code itself handles this; the framework adds no additional protection
- **Malicious code in dependencies**: Use `security-scan.yml` CI workflow + `fw-review-security` agent
- **Secrets in committed code**: Use `validate-no-public-secrets.sh` + GitHub secret scanning
- **Access control to the repo**: Use GitHub's native RBAC, not framework-level controls

## FAQ

**Q: Which Claude products does this work with?**
A: All Claude Code surfaces: CLI, Desktop app, VS Code extension, JetBrains extension, and claude.ai/code (web). These all run the same engine and support hooks, skills, rules, and CLAUDE.md. See [Platform Compatibility](#platform-compatibility).

**Q: Can I use this with Cursor/Windsurf/other AI IDEs?**
A: No. The hooks, skills, and agent system are Claude Code-specific. Non-Anthropic AI IDEs use different extension systems.

**Q: What about claude.ai (chat) or the Claude Desktop chat app?**
A: These are different products from Claude Code. They do not read `CLAUDE.md`, `.claude/rules/`, or execute hooks. The framework requires Claude Code specifically.

**Q: Does this work with Claude Code in GitHub Actions?**
A: Yes. The `claude.yml` workflow is included and the hooks work in CI. DevContainer provides isolation.

**Q: Can I use a subset of features?**
A: Yes. Set `profile: minimal` or `profile: standard` in `framework.yaml`. The safety gates (`auto_approve_base.py`) are the only thing that's always active. See [Complexity Profiles](#complexity-profiles) above.

**Q: How do I update when the upstream framework ships improvements?**
A: Run `./scripts/fw-sync.sh my-project`. It respects sync policies — your customizations are preserved.

**Q: What if a safety gate blocks something I need?**
A: The hook prompts you — you decide. For legitimate operations (like deleting a test database), approve the prompt. For recurring patterns, add them to your `auto-approve.py` overlay.

**Q: Is the full review pipeline worth the cost?**
A: For simple changes, no — use Hudson mode. For features touching 6+ files with risk multipliers (auth, DB, API contracts), the pipeline consistently catches issues that would be costly to find in production. Start with `standard` and evaluate.

**Q: How long does it take to learn the framework?**
A: With `minimal` profile, you can be productive in 30 minutes. The [First Week Guide](#first-week-guide) provides a day-by-day progression. Most teams are comfortable with the full pipeline within 2 weeks.
