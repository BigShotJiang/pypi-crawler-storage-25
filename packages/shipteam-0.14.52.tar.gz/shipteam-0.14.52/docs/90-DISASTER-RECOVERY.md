# Disaster Recovery

**Purpose**: Define recovery procedures, backup strategies, and incident playbooks for restoring service after outages or data loss.

**When to update**: After an incident, when changing backup infrastructure, or when adding new critical data stores.

---

## Recovery Procedures

### Priority Order

When multiple systems are affected, restore in this order:

1. **Database** -- restore data integrity first
2. **Backend API** -- restore service availability
3. **Frontend** -- restore user access
4. **Background jobs / cron** -- restore automated processes

### Database Recovery

1. Identify the failure: data corruption, accidental deletion, or infrastructure outage
2. Determine recovery point: what is the latest clean state?
3. Restore from backup:
   ```bash
   pg_restore -d dbname backup_file.dump
   ```
4. Verify data integrity: run sanity queries against key tables
5. Apply any migrations that were added after the backup was taken
6. Restart the application and verify health checks

### Application Recovery

1. Check deployment status on the hosting platform
2. If the latest deployment is broken, rollback (see [20-DEPLOYMENT.md](20-DEPLOYMENT.md))
3. If infrastructure is down, redeploy from the last known good commit
4. Verify health checks pass before declaring recovery complete

## Backup Strategy

| Data | Method | Frequency | Retention |
|------|--------|-----------|-----------|
| Database | [Automated provider backups / pg_dump] | [Daily] | [30 days] |
| File uploads | [Object storage replication] | [Continuous] | [90 days] |
| Configuration | [Version control] | [Every commit] | [Indefinite] |
| Secrets | [Secret manager audit log] | [On change] | [Per policy] |

### Backup Verification

- Restore a backup to a staging environment at least quarterly
- Verify data integrity after restore (row counts, key records, referential integrity)
- Document the verification date and result

## Incident Playbook

### Severity Levels

| Level | Definition | Response Time | Example |
|-------|-----------|---------------|---------|
| SEV-1 | Service completely down | Immediate | Database unreachable, API returning 500 for all users |
| SEV-2 | Major feature broken | Within 1 hour | Authentication failing, data not saving |
| SEV-3 | Minor feature broken | Within 1 business day | UI glitch, non-critical API error |

### Incident Response Steps

1. **Acknowledge**: Confirm the incident and assign a responder
2. **Assess severity**: Determine the impact and assign a severity level
3. **Communicate**: Notify stakeholders (status page, team channel)
4. **Contain**: Stop the bleeding (rollback, disable feature, scale up)
5. **Fix**: Apply a targeted fix via Tier 3 emergency deployment
6. **Verify**: Confirm the fix resolves the issue and does not introduce regressions
7. **Document**: Record the incident in [70-INSIGHTS.md](70-INSIGHTS.md)
8. **Review**: Conduct a blameless post-incident review within 48 hours

### Post-Incident Review Template

```
Incident: [Brief title]
Date: YYYY-MM-DD
Duration: [How long the outage lasted]
Severity: SEV-[1/2/3]
Impact: [What was affected, how many users]
Root Cause: [Technical explanation]
Fix Applied: [What was done to resolve it]
Prevention: [What changes will prevent recurrence]
Action Items: [Specific follow-up tasks with owners]
```
