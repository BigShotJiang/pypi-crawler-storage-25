# Safety Limits

**Purpose**: Honest accounting of what the framework's safety layers enforce, what they don't, and how to compose them with layers outside the framework for stronger properties.

**When to update**: When a new Claude Code bypass vector is published, when a layer is added or hardened, or when Anthropic changes the hook/permissions contract.

---

## What this doc is for

The framework's hooks and rules reduce the most common classes of mistake — running `rm -rf` in the wrong directory, pushing to `main`, committing when CI is red. They are good at what they do. They are not a security boundary.

This doc documents the gap between "this enforces workflow" and "this stops a determined adversary," so that:

1. You know which layers hold under which threat models.
2. You know where to add external controls (CI gates, sandbox, branch protection) if your threat model demands them.
3. A reviewer evaluating the framework's safety story finds an honest answer here instead of a credibility gap.

If you want the design rationale for how these layers were assembled, see [ADR-004 (Defense-in-Depth Hardening)](adr/004-defense-in-depth-hardening.md). If you want OWASP-level general security guidance for the code you write using the framework, see [35-SECURITY.md](35-SECURITY.md).

---

## What hooks enforce vs. what they don't

### What they do well

- **Workflow enforcement**: branch check, session lock, merge-conflict detection, doc-staleness gate, deployment protocol reminders.
- **Audit surface**: every tool call produces an event log entry. See `.context/metrics/` and `/fw-stats`.
- **Fast-path approval for safe operations**: `auto_approve_base.py` auto-approves read-only commands, common git operations, typical build/test commands — reducing prompt fatigue.
- **Blocking common destructive mistakes**: `rm -rf /`, force-push to protected branches, `DROP TABLE` without a WHERE, chained shell operators that would sneak destructive work past the allowlist.

### What they don't do

- **They are not a security boundary.** Anthropic's own [Claude Code security docs](https://code.claude.com/docs/en/security) do not list hooks under "Built-in protections." Hooks appear only as an audit/policy mechanism. The [Permission Modes doc](https://code.claude.com/docs/en/permission-modes) explicitly directs users to auto mode's server-side classifier, not hooks, "for background safety checks without prompts."
- **They do not resist a determined prompt-injection attack.** If a model decides to evade a blocklist, it can — see "Known Claude Code bypass vectors" below.
- **They do not block operations outside Claude Code.** A user running `git push --force` directly in a terminal bypasses the hook entirely.

---

## Known Claude Code bypass vectors that affect ShipTeam

These are upstream Claude Code issues. Each is a published GitHub issue in `anthropics/claude-code` that documents a real path around client-side hook enforcement.

| Category | Representative issue | ShipTeam exposure |
|---|---|---|
| Subagent / Task-tool hook skipping | [#21460](https://github.com/anthropics/claude-code/issues/21460) — PreToolUse hooks not enforced on subagent tool calls | Any `auto_approve_base.py` protection is bypassable by a subagent invoking the same tool. |
| Interpreter escape | [#40408](https://github.com/anthropics/claude-code/issues/40408) — Model bypasses PreToolUse write-protection via `perl -i -pe` | Blocklist-based Bash-argument patterns are categorically incomplete. Anthropic's own permissions docs warn that "Bash permission patterns that try to constrain command arguments are fragile." |
| Headless `-p` mode | [#33343](https://github.com/anthropics/claude-code/issues/33343) — PreToolUse hooks and `--allowedTools` not enforced in headless mode | Any CI-style `claude -p` run does not execute hooks. |
| Missing hook script | [#32990](https://github.com/anthropics/claude-code/issues/32990) — Hooks fail open when script file is missing | A session that deletes a hook script (real incident in #32990) silently disables the gate. Anthropic is tracking a fix as [PR #33390](https://github.com/anthropics/claude-code/pull/33390) — "hook-integrity-guard security plugin." |
| Project-controlled `settings.json` | [GHSA-mmgp-wc2j-qcv7](https://github.com/anthropics/claude-code/security/advisories/GHSA-mmgp-wc2j-qcv7) — Workspace trust dialog bypass via repo-controlled settings | Opening a malicious repo with a `.claude/settings.json` hook can run arbitrary code on first open. Anthropic has a partial fix in recent versions; follow Claude Code release notes. |

**How ShipTeam mitigates** (each item below adds an independent layer, not a replacement for hooks):

- **`permissions.deny` rules** in `~/.claude/settings.json` for path-scoped denies (`~/.ssh/**`, `.env*`). Pre-hook, hook-override-immune, applies to Read/Edit tools. See [30-AUTH.md](30-AUTH.md) and the Anthropic [permissions reference](https://code.claude.com/docs/en/permissions).
- **Claude Code native sandbox** (Seatbelt on macOS, bubblewrap on Linux/WSL2) via `settings.json → sandbox.*`. OS-level isolation for Bash subprocesses. Incompatible with `docker` and `watchman`. Not a ShipTeam default; recommended as opt-in hardening.
- **CI bright-line check** (ADR-007) runs at merge time, does not depend on hook execution.
- **GitHub branch protection + required status checks** on `main`, configured via `gh api` (see [20-DEPLOYMENT.md](20-DEPLOYMENT.md)).

---

## Layers ShipTeam enables by default

| Layer | Scope | Location |
|---|---|---|
| Auto-approve hook with destructive-command blocklist | Interactive Claude Code sessions | `.claude/hooks/auto_approve_base.py` |
| Git push policy (framework-wide via `policy: replace`) — hard denies on `--no-verify`, `--tags`, `--mirror`, `--all`, refspec-to-protected (`feat/foo:main`), namespace tricks (`refs/notes/`, `refs/replace/`, `refs/tags/`), wildcard refspecs (`*:*`), bare semver tag pushes; auto-approves to safe-prefix branches (`session/*`, `feat/*`, `fix/*`, `docs/*`, `chore/*`, `refactor/*`, `test/*`) gated by env-prefix RCE refuse + CWE-551 shell-metachar refuse + unknown-flag refuse + delete-refspec refuse | Interactive Claude Code sessions | `.claude/hooks/auto_approve_base.py` (see [CWE-551 inversion principle in ADR-018](adr/018-cwe-551-inversion-principle.md)) |
| Branch check + session lock | Interactive sessions | `.claude/hooks/branch-check.py`, `checkout-guard.py` |
| CI test gate | Merge time | `.github/workflows/ci-cd.yml` |
| Doc-staleness gate | After protected operations | `.claude/hooks/protocol-validator.py` |
| AI-config-file Unicode integrity check | CI | `lint-shell` job in `ci-cd.yml` (see [35-SECURITY.md](35-SECURITY.md#ai-configuration-file-integrity)) |
| Commit-trust gate | Per prompt (gated by `hooks.deploy_gate`) | `.claude/hooks/commit-trust-check.py` |

---

## Layers the user owns (optional hardening)

These are NOT framework defaults. Enable them if your threat model or compliance requirements warrant it.

### Claude Code native sandbox
Add a `sandbox` section to your user-scope `~/.claude/settings.json`:

```json
{
  "sandbox": {
    "filesystem": {
      "allowWrite": ["/path/to/project/**", "/tmp/**"],
      "denyWrite": ["//etc/**", "~/.ssh/**", "~/.aws/**"]
    },
    "network": {
      "allowedDomains": ["github.com", "pypi.org", "registry.npmjs.org"]
    }
  },
  "allowUnsandboxedCommands": false
}
```

See the Anthropic [sandboxing docs](https://code.claude.com/docs/en/sandboxing) for the full profile format. Known incompatibilities: `docker`, `watchman`, WSL1.

### Path-scoped `permissions.deny`
Add to user-scope settings:

```json
{
  "permissions": {
    "deny": [
      "Read(~/.ssh/**)",
      "Read(~/.gnupg/**)",
      "Read(~/.aws/**)",
      "Edit(//etc/**)",
      "Edit(~/.ssh/**)",
      "Edit(~/.aws/**)"
    ]
  }
}
```

These are pre-hook and hook-override-immune. They do NOT block Bash subprocesses (`cat .env`) — for that, enable the sandbox.

### Branch protection on `main`
```bash
gh api -X PUT /repos/OWNER/REPO/branches/main/protection \
  -f required_status_checks.strict=true \
  -F required_status_checks.contexts[]=backend-tests \
  -F required_status_checks.contexts[]=bright-line-check \
  -f enforce_admins=true
```

On a public repo, branch protection is free. On a private repo, it requires GitHub Pro or higher.

### OS-level hook immutability (advanced)
If you want defense against a session deleting its own hook scripts (the #32990 pattern), you can mark the framework's hooks immutable on macOS with `sudo chflags uchg .claude/hooks/*.py` or on Linux with `sudo chattr +i .claude/hooks/*.py`. This **breaks `fw-sync.sh` and `pip install`** until you remove the flag — so you must `chflags nouchg` (or `chattr -i`) before any framework update.

A better alternative is shipping upstream: Anthropic has [PR #33390 (hook-integrity-guard security plugin)](https://github.com/anthropics/claude-code/pull/33390) in flight. When it merges, enabling that plugin will give you the same property without the update-time churn.

---

## Escape hatches — documented, not hidden

These exist on purpose. Use them carefully; they bypass the corresponding gate.

| Mechanism | Gate bypassed | Scope |
|---|---|---|
| `CLAUDE_TRUST_BYPASS=1` env var | `commit-trust-check.py` CI/health gate | Session-local |
| `.claude/trust-bypass.flag` file (1-hour expiry) | `commit-trust-check.py` | Per flag lifetime |
| `claude --dangerously-skip-permissions` | All permission prompts + hook-decision parsing | Per invocation |
| `hooks.doc_staleness_check: false` in `framework.yaml` | Doc-staleness warning in `protocol-validator.py` | Persistent |
| `security.sandbox.enabled: false` in `framework.yaml` | (If sandbox is enabled) Sandbox isolation | Persistent |

Per Anthropic: `bypassPermissions` "offers no protection against prompt injection or unintended actions." Treat any session that runs under it as untrusted output pending review.

---

## When to use stronger controls

**Shipping a public product**: at minimum, enable `permissions.deny` for credential paths (above) and branch protection with required status checks. Consider enabling the native sandbox.

**Working with customer data or credentials**: enable the sandbox. The client-side hook layer is not sufficient.

**CI/CD automation using `claude -p`**: do NOT rely on hooks — they are documented as not firing in headless mode (#33343). Use `permissions.deny` (allow-list-style) and run inside a container.

**Regulated / compliance-sensitive work**: the client-side hook model is not a compliance boundary. Layer server-side policy (MCP OAuth 2.1 with audience-bound tokens per [MCP spec 2025-11-25](https://modelcontextprotocol.io/specification/2025-06-18/basic/authorization)), CI-side content gates, and an immutable audit trail. This is the domain of the planned MCP governance Pro product — not yet shipped.

---

## Verification gate for agent-driven evidence

When a subagent or AI-assisted analysis cites specific textual evidence — file paths, line numbers, exact strings — verify with a direct `grep` or `read` before acting on it.

This is not a rhetorical caution. During the 2026-04 safety-architecture investigation that produced this doc, an adversarial subagent fabricated a claim about a specific valuation figure in an ADR that did not exist in the file. The hallucination was caught by verification. In agent-driven workflows, this category of error is ambient; the verification step is the only reliable gate.

Practical rule: for any recommendation that depends on a specific string, path, or issue number, run the corresponding `grep`, `git log`, or `gh issue view` before committing to the action.

---

## PyPI publish safety gate (wheel-audit)

`scripts/wheel_audit.py` + `.github/workflows/wheel-audit.yml` + `.github/workflows/pypi-publish.yml` implement a post-build artifact inspector that runs before any PyPI publish (ADR-020).

### What the gate covers

| Check | `.whl` | `.tar.gz` |
|-------|--------|-----------|
| `PYC_CHECK` — compiled bytecode (`.pyc`, `.pyo`) | ✅ | ✅ |
| `PYCACHE_CHECK` — `__pycache__/` directory entries | ✅ | ✅ |
| `BRIGHT_LINE` — ADR-007 content patterns (NFKC-normalized) | ✅ | — |

The sdist `BRIGHT_LINE` check is intentionally omitted — the sdist is the full repo tree, and `validate-no-bright-line.sh` already covers it at the PR/merge level with the correct exemption list. Applying the artifact scanner to the sdist produces false positives on ADR-007, CHANGELOG, and test fixtures (all self-exempt in the repo scanner).

### Known bypass surface

The scanner does NOT detect:

- **Cyrillic-for-Latin confusables** (e.g., `А` U+0410 substituted for Latin `A`) — requires UTS #39 `skeleton(X)` NFD transform; `unicodedata.normalize('NFKC', ...)` does not apply it.
- **Zero-width character padding** (U+200B, U+200C, U+200D, U+FEFF inserted between pattern characters).
- **Base64-encoded content** or other encoding layers.
- **Hex / decimal HTML entity encoding**.

**Threat model**: internal-author deterrence + accidental-leak prevention. The gate catches mistakes and CI-enforced drift, not a determined adversary who reads `wheel_audit.py`. This is the right scope given that the publish gate is run against the main-branch version of the script at release time — an attacker would need write access to main, at which point the gate is the least of the security concerns.

### TOCTOU design note

The PR-time audit (`wheel-audit.yml`) runs from the PR-head version of `wheel_audit.py` — an author can modify the script in the same PR that introduces a violation. This is acceptable: the PR-time audit catches accidents, not malicious authors. The publish-time audit (`pypi-publish.yml`) runs from the tagged main-branch code and requires an explicit GitHub Release, providing the second independent checkpoint.

---

## References

- [ADR-004 (Defense-in-Depth Hardening)](adr/004-defense-in-depth-hardening.md) — design rationale for the layer stack.
- [ADR-007 (Bright-Line Sanitization Policy)](adr/007-public-repo-bright-line-sanitization.md) — content policy that the CI bright-line check enforces.
- [ADR-020 (Wheel-Audit PyPI Gate)](adr/020-wheel-audit-pypi-gate.md) — architecture decision for the publish gate.
- [35-SECURITY.md](35-SECURITY.md) — OWASP/PII/auth rules for framework users' own code.
- [Claude Code hook docs](https://code.claude.com/docs/en/hooks) — upstream contract.
- [Claude Code permissions docs](https://code.claude.com/docs/en/permissions) — `permissions.allow`/`deny` grammar.
- [Claude Code sandboxing docs](https://code.claude.com/docs/en/sandboxing) — Seatbelt/bubblewrap profile format.
- [MCP 2025-11-25 authorization spec](https://modelcontextprotocol.io/specification/2025-06-18/basic/authorization) — OAuth 2.1 primitives relevant to the Pro product.
