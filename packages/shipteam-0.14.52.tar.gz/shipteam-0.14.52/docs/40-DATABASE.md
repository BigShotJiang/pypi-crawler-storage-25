# Database

> **Stack-Conditional**: Skip this doc if your project has no backend database. Check `config/framework.yaml` `stack.backend` section. Set `rules.database_migrations: false` and `skills.schema_check: false` in framework.yaml to disable DB-related tooling.

**Purpose**: Document the database schema, migration protocol, connection management, and backup strategy.

**When to update**: When creating new tables, modifying schema, changing migration procedures, or updating connection configuration.

---

## Schema Overview

<!-- List major tables and their purpose. Update this when adding new tables. -->

| Table | Purpose | Key Columns |
|-------|---------|-------------|
| `users` | User accounts | `id`, `email`, `created_at` |
| `[table_name]` | [Description] | [Key columns] |

### Entity Relationships

```
users 1--* [child_table] : user_id (FK)
[parent] 1--* [child]    : parent_id (FK)
```

## Migration Protocol

**Rule**: Verify schema BEFORE writing any migration. Never guess column names or types.

### Step 1: Verify Current Schema

```bash
# Find table definition
grep -A50 "CREATE TABLE.*table_name" backend/database/migrations/*.sql

# Verify column exists in application code
grep -r "column_name" backend/app/ --include="*.py" | head -10
```

### Step 2: Document What You Found

```python
# Schema verification for 'table_name':
# - column_x: TEXT (not VARCHAR)
# - column_y: JSONB (not boolean)
# - NO column_z exists (contrary to assumption)
```

### Step 3: Write the Migration

```sql
-- Migration: NNN_description.sql
-- Purpose: [What this migration does]
-- Verified: [What schema you checked before writing this]

ALTER TABLE table_name ADD COLUMN new_column TEXT;
```

### Common Migration Pitfalls

| Mistake | Fix |
|---------|-----|
| `CREATE INDEX CONCURRENTLY` inside a transaction | Remove `CONCURRENTLY` keyword |
| Guessing column names | Always grep schema first |
| Assuming constraints are identical across tables | Verify constraints for each table separately |

## Connection Management

- **Pool size**: [e.g., min 2, max 10 connections]
- **Connection timeout**: [e.g., 30 seconds]
- **Idle timeout**: [e.g., 300 seconds]
- **Health check**: Connection pool validates connections before use

### Connection String

Defined via environment variable (see [45-ENVIRONMENT.md](45-ENVIRONMENT.md)):
```
DATABASE_URL=postgresql://user:password@host:port/dbname
```

## Backup and Recovery

- **Automated backups**: [Frequency, retention period, provider-managed or custom]
- **Point-in-time recovery**: [Available window, e.g., "last 7 days"]
- **Manual backup**: `pg_dump -Fc dbname > backup_$(date +%Y%m%d).dump`
- **Restore**: `pg_restore -d dbname backup_file.dump`
- **Testing**: Restore backups to a staging environment quarterly to verify integrity
