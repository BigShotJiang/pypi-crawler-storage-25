---
layout: default
title: Home
---

# ShipTeam Documentation

**Turn Claude Code into a build team.** Safety-first AI development with TDD workflows, session isolation, and default-deny guardrails.

## Documentation Index

| Doc | Topic |
|-----|-------|
| [Architecture](10-ARCHITECTURE.md) | Tech stack, patterns, project structure |
| [Prompt Versioning](15-PROMPT_VERSIONING.md) | LLM prompt version tracking |
| [Deployment](20-DEPLOYMENT.md) | CI/CD, tiered deployment, rollback |
| [Authentication](30-AUTH.md) | Auth flows, RBAC, sessions |
| [Security](35-SECURITY.md) | OWASP prevention, PII, data lifecycle |
| [Database](40-DATABASE.md) | Schema, migrations, backups |
| [Environment](45-ENVIRONMENT.md) | Environment variables, secrets |
| [Testing](50-TESTING.md) | TDD workflow, test pyramid, CI |
| [Features](60-FEATURES.md) | Feature history (v0.1-v0.13) |
| [Insights](70-INSIGHTS.md) | Design decisions and rationale |
| [Troubleshooting](80-TROUBLESHOOTING.md) | Common issues, debug checklist |
| [Disaster Recovery](90-DISASTER-RECOVERY.md) | Incident playbooks |

## Getting Started

- [Setup Guide](https://github.com/cdjgroup/dev-framework/blob/main/SETUP.md)
- [Adoption Guide](ADOPTION.md) — 3-phase team rollout strategy
- [Contributing](https://github.com/cdjgroup/dev-framework/blob/main/CONTRIBUTING.md)
- [Architecture Decision Records](adr/)

## Quick Links

- [GitHub Repository](https://github.com/cdjgroup/dev-framework)
- [Changelog](https://github.com/cdjgroup/dev-framework/blob/main/CHANGELOG.md)
- [Releases](https://github.com/cdjgroup/dev-framework/releases)
