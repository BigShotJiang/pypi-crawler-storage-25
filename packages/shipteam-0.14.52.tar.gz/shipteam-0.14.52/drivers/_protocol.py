"""
drivers/_protocol.py — DriverResult dataclass and Driver protocol.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from types import MappingProxyType
from typing import Literal, Mapping, Protocol

CostSource = Literal["native", "scraped", "computed"]
# Phase 5e: narrowed from {"omitted","salted"} to {"salted","native"}.
# "salted" — driver actively defeats prompt cache via per-seed salt suffix
# "native" — driver has no separate cache layer the harness controls (aider/droid)
CacheStrategy = Literal["salted", "native"]
AbortCategory = Literal[
    "budget_exceeded",
    "rate_limit_repeated",
    "server_error",
    "wall_clock_exceeded",
    "driver_error",
    "missing_token_counts",
    "pytest_collection_error",
    "docker_unavailable",
    "unrecognized_model_for_rate_sheet",
    "cache_leak_detected",
    "api_error_text",
]


@dataclass(frozen=True)
class AbortReason:
    category: AbortCategory
    detail: str = ""

    def __str__(self) -> str:
        if self.detail:
            return f"{self.category}: {self.detail}"
        return self.category


VALID_COST_SOURCES = ("native", "scraped", "computed")
VALID_CACHE_STRATEGIES = ("salted", "native")


@dataclass
class DriverResult:
    """Result returned by a driver's execute() method."""
    wall_clock_ms: int
    input_tokens: int | None
    output_tokens: int | None
    cost_usd: float | None
    cost_source: CostSource
    aborted: bool
    abort_reason: AbortReason | None
    cache_strategy: CacheStrategy
    driver_metadata: Mapping[str, object] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if self.cost_source not in VALID_COST_SOURCES:
            raise ValueError(
                f"cost_source must be one of {VALID_COST_SOURCES}, got {self.cost_source!r}"
            )
        if self.cache_strategy not in VALID_CACHE_STRATEGIES:
            raise ValueError(
                f"cache_strategy must be one of {VALID_CACHE_STRATEGIES}, got {self.cache_strategy!r}"
            )
        if not isinstance(self.driver_metadata, MappingProxyType):
            self.driver_metadata = MappingProxyType(dict(self.driver_metadata))


class Driver(Protocol):
    """Structural protocol every driver adapter must satisfy."""

    @property
    def name(self) -> str: ...
    def version(self) -> str: ...
    def sdk_version(self) -> str: ...
    def release_date(self) -> str: ...
    def prepare(self, workspace: Path, task_manifest: dict) -> None: ...
    def execute(
        self,
        workspace: Path,
        task_manifest: dict,
        seed: int,
        budget_usd: float,
        wall_clock_budget_seconds: int,
        cache_strategy: Literal["salted", "native"] = "salted",
    ) -> DriverResult: ...
