"""
drivers/aider.py — Aider CLI driver.

Wraps the `aider` CLI subprocess to produce a DriverResult with:
  - cost_source = "scraped"  (cost parsed from stdout via regex)
  - input_tokens = None      (Aider does not emit token counts natively)
  - output_tokens = None
  - cache_strategy = "native" (Aider does not control the upstream cache layer)

AC-19: stdout is scanned (case-insensitive) for vendor error patterns. On match
the run aborts with abort_reason.category="api_error_text" and
driver_metadata["matched_pattern"] populated. Source: aider.chat troubleshooting.
"""
from __future__ import annotations

import importlib.metadata
import re
import subprocess
import time
from pathlib import Path

from drivers._protocol import AbortReason, CacheStrategy, DriverResult
from drivers._cost_extraction import extract_aider_cost
from drivers._subprocess_helpers import make_aborted_result


_DRIVER_NAME = "aider"

# Shared with droid.py (AC-19 / AC-20 defense-in-depth). Case-insensitive.
_VENDOR_ERROR_RE = re.compile(
    r"(rate.?limit|API.?error|connection.?error|context.?length.?exceeded|litellm\.exceptions)",
    re.IGNORECASE,
)


class AiderDriver:
    """Driver that executes a task via the Aider CLI subprocess."""

    def __init__(self) -> None:
        try:
            self._cli_version: str = importlib.metadata.version("aider-chat")
        except importlib.metadata.PackageNotFoundError:
            raise RuntimeError(
                "The 'aider-chat' package is not installed. "
                "Note: 'aider' and 'aider-chat' are different PyPI packages — "
                "run 'pip install shipteam[benchmark-aider]' (preferred) "
                "or 'pip install aider-chat' directly to install the correct one."
            )

    @property
    def name(self) -> str:
        return _DRIVER_NAME

    def version(self) -> str:
        """Installed aider-chat package version."""
        return self._cli_version

    def sdk_version(self) -> str:
        """Installed aider-chat package version (no separate SDK for Aider)."""
        return self._cli_version

    def release_date(self) -> str:
        return "2024-08-01"

    def prepare(self, workspace: Path, task_manifest: dict) -> None:
        pass

    def execute(
        self,
        workspace: Path,
        task_manifest: dict,
        seed: int,
        budget_usd: float,
        wall_clock_budget_seconds: int,
        cache_strategy: CacheStrategy = "salted",
    ) -> DriverResult:
        """
        Run the task via the Aider CLI and return a DriverResult.

        Aider is invoked with --yes-always for non-interactive benchmark use.
        Cost is scraped from stdout using extract_aider_cost. Stdout is also
        scanned for vendor error patterns (AC-19); a match aborts the run.

        cache_strategy is fixed to "native" for aider regardless of input —
        the driver does not control the upstream model's cache layer.
        """
        result_cache_strategy: CacheStrategy = "native"

        cmd = [
            "aider",
            "--yes-always",
            "--message", task_manifest.get("entry_point", ""),
        ]

        start = time.monotonic()

        try:
            proc = subprocess.run(
                cmd,
                cwd=str(workspace),
                capture_output=True,
                text=True,
                timeout=wall_clock_budget_seconds,
            )
        except subprocess.TimeoutExpired:
            elapsed_ms = int((time.monotonic() - start) * 1000)
            return make_aborted_result(
                elapsed_ms,
                AbortReason(category="wall_clock_exceeded"),
                "scraped",
                result_cache_strategy,
                {"cli_version": self._cli_version},
            )
        except FileNotFoundError:
            elapsed_ms = int((time.monotonic() - start) * 1000)
            return make_aborted_result(
                elapsed_ms,
                AbortReason(category="driver_error"),
                "scraped",
                result_cache_strategy,
                {"cli_version": self._cli_version},
            )

        elapsed_ms = int((time.monotonic() - start) * 1000)
        stdout_text = proc.stdout or ""

        _, _, cost_usd = extract_aider_cost(stdout_text)

        # AC-19 vendor-error scan: precedes returncode check so that an
        # exit-zero process whose stdout reports a rate-limit is still aborted.
        match = _VENDOR_ERROR_RE.search(stdout_text)
        driver_metadata: dict = {"cli_version": self._cli_version}
        if match:
            driver_metadata["matched_pattern"] = match.group(0)
            return make_aborted_result(
                elapsed_ms,
                AbortReason(category="api_error_text", detail=match.group(0)),
                "scraped",
                result_cache_strategy,
                driver_metadata,
                cost_usd=cost_usd,
            )

        is_error = proc.returncode != 0
        abort_reason: AbortReason | None = (
            AbortReason(category="driver_error") if is_error else None
        )

        return DriverResult(
            wall_clock_ms=elapsed_ms,
            input_tokens=None,
            output_tokens=None,
            cost_usd=cost_usd,
            cost_source="scraped",
            aborted=is_error,
            abort_reason=abort_reason,
            cache_strategy=result_cache_strategy,
            driver_metadata=driver_metadata,
        )
