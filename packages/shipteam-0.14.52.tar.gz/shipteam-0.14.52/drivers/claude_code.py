"""
drivers/claude_code.py — Claude Code Agent SDK driver (Phase 5e).

Wraps the claude-agent-sdk to produce a DriverResult with:
  - cost_source = "computed"  (cost derived from CLAUDE_RATE_SHEET_2026_04;
                               SDK's total_cost_usd is a local estimate per
                               SDK Issue #487 and MUST NOT be authoritative)
  - cache_strategy = "salted" (cache defeated via per-seed system-prompt salt)
  - driver_metadata containing cli_version and cache_read_input_tokens

Acceptance criteria implemented here:
  AC-9   — SDK wiring with dict-access usage, error-text scan, computed cost
  AC-14  — salted system prompt, fail-closed on cache_read>0, salt-placement check
  AC-15  — token counts must be int>=0 on completed runs (else missing_token_counts)
  AC-17  — fresh ClaudeSDKClient per execute() (no cross-task contamination)

Cognitive isolation note for runtime tests:
  - run_agent_sdk      : module-level callable patched in tests to capture kwargs
                         and return a mock ResultMessage. Default raises so the
                         driver cannot accidentally hit the real SDK in tests.
  - ClaudeSDKClient    : module-level rebound symbol patched in AC-17 tests via
                         drivers.claude_code.ClaudeSDKClient — any execute()
                         constructs an instance and immediately discards it,
                         which is enough to satisfy the "fresh client per task"
                         contract that AC-17 audits via id() collection.
  - _check_salt_placement: module-level callable patched in salt-placement tests
                           to inject a RuntimeError simulating a misplaced
                           cache_control marker.
"""
from __future__ import annotations

import importlib.metadata
import re
import time
import uuid
from pathlib import Path
from typing import Any

from drivers._protocol import AbortReason, CacheStrategy, DriverResult
from drivers._subprocess_helpers import coerce_int_or_none, make_aborted_result
from task_packs.loader import CLAUDE_RATE_SHEET_2026_04, compute_cost


_DRIVER_NAME = "claude_code"

# Default model_id used to derive cost. The benchmark pins the executor model
# at the harness boundary (smoke run); when the harness lands its model_id
# plumbing the driver will read it from task_manifest. Until then the default
# matches the rate-sheet entry whose rates the AC-9 tests assert against
# (input $3/Mtok, output $15/Mtok).
_DEFAULT_MODEL_ID = "claude-sonnet-4-5"

# AC-9 error-text scan. Matches SDK Issue #472 patterns (errors returned as
# text, not exceptions). Case-insensitive — vendor strings vary by upstream.
_API_ERROR_RE = re.compile(
    r"(API request failed|rate_limit_error|server_error|overloaded_error)",
    re.IGNORECASE,
)


# ---------------------------------------------------------------------------
# Module-level patch points (see module docstring for cognitive-isolation
# rationale). Real-runtime use of this driver requires a host-side wrapper
# that replaces run_agent_sdk; the harness's smoke-run path lands in Phase 5g.
# ---------------------------------------------------------------------------

class ClaudeSDKClient:  # pragma: no cover - patched in tests; placeholder for AC-17
    """
    Placeholder for the ClaudeSDKClient symbol that AC-17 tests patch.

    The real `claude-agent-sdk` exports a ClaudeSDKClient; we re-export a
    sibling here so tests can `patch("drivers.claude_code.ClaudeSDKClient",
    side_effect=TrackingClient)` to verify per-task instantiation. Smoke-run
    code (Phase 5g) replaces this with the real import; tests never touch the
    real symbol.
    """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        pass


def run_agent_sdk(**kwargs: Any) -> Any:  # pragma: no cover - patched in tests
    """
    Adapter boundary for invoking the SDK.

    Tests patch this function to capture the system_prompt and return a mock
    ResultMessage. The harness smoke-run path (Phase 5g) replaces this with a
    real synchronous wrapper around `claude_agent_sdk.query`.
    """
    raise NotImplementedError(
        "run_agent_sdk must be patched in tests or replaced with the real SDK call "
        "(scheduled for Phase 5g smoke-run wiring)."
    )


def _check_salt_placement(system_prompt: str, salt: str) -> None:
    """
    AC-14 R14: salt suffix MUST be placed after any cache_control markers.

    The driver constructs system_prompt = base + salt; cache_control markers
    in this configuration always precede the salt because the salt is the
    very last thing concatenated. The check is a defensive scan — if any
    'cache_control' substring is found at an offset >= the salt offset,
    raise RuntimeError so the seed aborts loudly rather than silently
    serving cached output.

    Tests patch this with a side_effect=RuntimeError to verify the driver
    actually calls the check (rather than relying on the always-true ordering
    of the construction site).
    """
    salt_offset = system_prompt.find(salt)
    if salt_offset < 0:
        # Not findable — nothing to check; the construction-site invariant
        # already places it; defensive return.
        return
    # Find any 'cache_control' marker text that the SDK or upstream user
    # could have injected; flag if it appears AFTER the salt position.
    for match in re.finditer(r"cache_control", system_prompt):
        if match.start() > salt_offset:
            raise RuntimeError(
                "salt placement violates cache_control hierarchy"
            )


# ---------------------------------------------------------------------------
# Salt construction (AC-14)
# ---------------------------------------------------------------------------

def _make_salt(seed: int) -> str:
    """
    Construct the deterministic per-seed salt suffix.

    Format: f"\\n\\n<run_salt>{uuid5(NAMESPACE_DNS, str(seed))}</run_salt>"
    Length: ≤ 80 chars (R19 empirical bound).
    """
    return f"\n\n<run_salt>{uuid.uuid5(uuid.NAMESPACE_DNS, str(seed))}</run_salt>"


# ---------------------------------------------------------------------------
# Driver
# ---------------------------------------------------------------------------

class ClaudeCodeDriver:
    """Driver that executes a task via the Claude Code Agent SDK."""

    @property
    def name(self) -> str:
        return _DRIVER_NAME

    def version(self) -> str:
        """Version of this driver *adapter* (not the SDK)."""
        return "0.1.0"

    def sdk_version(self) -> str:
        """
        Version of the installed claude-agent-sdk package.

        Distinct from version() per AC-11: the harness records both so that
        a mismatch between driver adapter and SDK is detectable.
        """
        try:
            return importlib.metadata.version("claude-agent-sdk")
        except importlib.metadata.PackageNotFoundError:
            return "unknown"

    def release_date(self) -> str:
        return "2024-08-01"

    def prepare(self, workspace: Path, task_manifest: dict) -> None:
        pass

    def execute(
        self,
        workspace: Path,
        task_manifest: dict,
        seed: int,
        budget_usd: float,
        wall_clock_budget_seconds: int,
        cache_strategy: CacheStrategy = "salted",
    ) -> DriverResult:
        """
        Run the task via the Agent SDK and return a DriverResult.

        AC-14: cache defeat is achieved by appending a deterministic per-seed
        salt to the system prompt. cache_read_input_tokens > 0 on a salted run
        is treated as a fail-closed leak (abort with cache_leak_detected).

        AC-17: a fresh ClaudeSDKClient is constructed for every execute() call
        — no instance is cached on the driver. This defends against SDK
        Issue #560 (session leakage across context boundaries).
        """
        cli_version = self.sdk_version()

        # AC-17: fresh client per call. The instance is constructed and held
        # only for the duration of this call; tests assert distinct id()s
        # across two invocations.
        _client = ClaudeSDKClient()  # noqa: F841 — see module docstring

        # AC-14: build the salted system prompt.
        base_system_prompt = (
            "You are a coding assistant working on a benchmark task. "
            "Implement the task described in the workspace and ensure all "
            "frozen tests pass."
        )
        salt = _make_salt(seed)
        system_prompt = base_system_prompt + salt

        # AC-14 R14: defensive salt-placement check. Patched in tests to
        # inject a RuntimeError that simulates a misplaced cache_control marker.
        _check_salt_placement(system_prompt, salt)

        start = time.monotonic()

        sdk_result = run_agent_sdk(
            workspace=str(workspace),
            task=task_manifest,
            seed=seed,
            budget_usd=budget_usd,
            wall_clock_budget_seconds=wall_clock_budget_seconds,
            system_prompt=system_prompt,
            cache_strategy=cache_strategy,
        )

        elapsed_ms = int((time.monotonic() - start) * 1000)

        # AC-9: usage is dict[str, Any] | None — use .get(), not getattr().
        # The "or {}" handles the SDK returning None (no usage info).
        usage = sdk_result.usage or {}
        if not isinstance(usage, dict):
            # SDK is contractually dict | None; defensive coerce.
            usage = {}

        input_tokens_raw = usage.get("input_tokens")
        output_tokens_raw = usage.get("output_tokens")
        cache_read_input_tokens = usage.get("cache_read_input_tokens", 0) or 0

        result_text = str(getattr(sdk_result, "result", "") or "")
        is_error_flag = bool(getattr(sdk_result, "is_error", False))

        driver_metadata: dict = {
            "cache_strategy": cache_strategy,
            "cache_read_input_tokens": cache_read_input_tokens,
            "cli_version": cli_version,
        }

        # AC-14: fail-closed on cache_read > 0 for salted runs. Precedes the
        # token-count check so a leak isn't masked by a missing-tokens abort.
        if cache_strategy == "salted" and cache_read_input_tokens > 0:
            return make_aborted_result(
                elapsed_ms,
                AbortReason(
                    category="cache_leak_detected",
                    detail=f"cache_read_input_tokens={cache_read_input_tokens} on salted run",
                ),
                "computed",
                cache_strategy,
                driver_metadata,
                input_tokens=coerce_int_or_none(input_tokens_raw),
                output_tokens=coerce_int_or_none(output_tokens_raw),
            )

        # AC-15: token counts must be int>=0 on completed runs.
        if input_tokens_raw is None or output_tokens_raw is None:
            return make_aborted_result(
                elapsed_ms,
                AbortReason(
                    category="missing_token_counts",
                    detail="SDK usage dict missing input_tokens or output_tokens",
                ),
                "computed",
                cache_strategy,
                driver_metadata,
                input_tokens=coerce_int_or_none(input_tokens_raw),
                output_tokens=coerce_int_or_none(output_tokens_raw),
            )

        input_tokens = int(input_tokens_raw)
        output_tokens = int(output_tokens_raw)

        # AC-9: error-text scan. Matches even when is_error_flag is False —
        # SDK Issue #472 reports API errors as result text, not exceptions.
        match = _API_ERROR_RE.search(result_text)
        if match:
            return make_aborted_result(
                elapsed_ms,
                AbortReason(category="api_error_text", detail=match.group(0)),
                "computed",
                cache_strategy,
                driver_metadata,
                input_tokens=input_tokens,
                output_tokens=output_tokens,
            )

        if is_error_flag:
            return make_aborted_result(
                elapsed_ms,
                AbortReason(category="driver_error"),
                "computed",
                cache_strategy,
                driver_metadata,
                input_tokens=input_tokens,
                output_tokens=output_tokens,
            )

        # AC-9: cost is computed from the rate sheet, NOT taken from
        # sdk_result.total_cost_usd (which is a local estimate per Issue #487).
        # If the model_id is absent from the rate sheet, we abort rather than
        # silently produce a cost that's an order of magnitude wrong.
        model_id = task_manifest.get("model_id", _DEFAULT_MODEL_ID)
        if model_id not in CLAUDE_RATE_SHEET_2026_04:
            return make_aborted_result(
                elapsed_ms,
                AbortReason(
                    category="unrecognized_model_for_rate_sheet",
                    detail=f"model_id={model_id!r} not in CLAUDE_RATE_SHEET_2026_04",
                ),
                "computed",
                cache_strategy,
                driver_metadata,
                input_tokens=input_tokens,
                output_tokens=output_tokens,
            )

        cost_usd = compute_cost(model_id, input_tokens, output_tokens)

        return DriverResult(
            wall_clock_ms=elapsed_ms,
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            cost_usd=cost_usd,
            cost_source="computed",
            aborted=False,
            abort_reason=None,
            cache_strategy=cache_strategy,
            driver_metadata=driver_metadata,
        )
