"""
drivers/_subprocess_helpers.py — Shared helpers for subprocess-based drivers.
"""
from __future__ import annotations

from typing import Any

from drivers._protocol import (
    AbortCategory,
    AbortReason,
    CacheStrategy,
    CostSource,
    DriverResult,
)


def coerce_int_or_none(value: Any) -> int | None:
    """Cast *value* to int if it is not None; return None otherwise."""
    return int(value) if value is not None else None


def coerce_float_or_none(value: Any) -> float | None:
    """Cast *value* to float if it is not None; return None otherwise."""
    return float(value) if value is not None else None


def make_aborted_result(
    elapsed_ms: int,
    abort_reason: AbortReason | AbortCategory,
    cost_source: CostSource,
    cache_strategy: CacheStrategy,
    driver_metadata: dict,
    *,
    input_tokens: int | None = None,
    output_tokens: int | None = None,
    cost_usd: float | None = None,
) -> DriverResult:
    """
    Build a DriverResult representing an aborted run.

    Accepts either an AbortReason instance or a bare AbortCategory string for
    backward call-site compatibility — bare strings are wrapped into
    AbortReason(category=<str>, detail="").

    input_tokens / output_tokens / cost_usd default to None (typical for
    timeout / missing-binary aborts where no useful data was produced) but may
    be passed when partial data IS available — e.g. the Claude SDK's
    cache-leak abort still carries the tokens spent before the leak, and the
    Aider/Droid vendor-error scans abort with a scraped cost_usd.
    """
    if isinstance(abort_reason, str):
        reason: AbortReason = AbortReason(category=abort_reason)  # type: ignore[arg-type]
    else:
        reason = abort_reason
    return DriverResult(
        wall_clock_ms=elapsed_ms,
        input_tokens=input_tokens,
        output_tokens=output_tokens,
        cost_usd=cost_usd,
        cost_source=cost_source,
        aborted=True,
        abort_reason=reason,
        cache_strategy=cache_strategy,
        driver_metadata=driver_metadata,
    )
