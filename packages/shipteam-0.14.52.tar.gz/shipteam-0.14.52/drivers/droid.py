"""
drivers/droid.py — Factory Droid CLI driver.

Wraps the `droid exec` CLI subprocess to produce a DriverResult with:
  - cost_source = "scraped"  (cost/tokens parsed from '-o json' stdout)
  - cache_strategy = "native" (Droid does not control the upstream cache layer)

AC-20 (defense-in-depth):
  (1) keeps the existing result_obj.get("is_error", False) check;
  (2) records driver_metadata["is_error_field_present"] (key presence,
      not value — the 'is_error' field is an undocumented Droid extension
      and may disappear);
  (3) scans stdout for the AC-19 vendor-error regex as a fallback.
"""
from __future__ import annotations

import json
import os
import re
import subprocess
import tempfile
import time
from pathlib import Path

from drivers._protocol import AbortReason, CacheStrategy, DriverResult
from drivers._cost_extraction import extract_droid_json_cost
from drivers._subprocess_helpers import make_aborted_result


_DRIVER_NAME = "droid"

# AC-20(3) defense-in-depth regex — UNION of AC-19's Aider regex + the
# Droid-specific `factorydroid:` prefix. Factory Droid is litellm-backed,
# so `litellm.exceptions.*`, `connection error`, and `context length
# exceeded` text surfaces in Droid stdout under upstream failures — the
# narrower factorydroid-only regex would silently miss those patterns and
# mis-categorize them as `driver_error` (worse: with json_parse_failed=False
# they could slip through entirely). Per .sherlock-plan.md AC-20 body
# ("same regex as AC-19") and tests/drivers/test_droid_error_scan.py:12
# (test docstring states the shared-regex contract), broaden here. The
# `factorydroid:\s*error` alternative is preserved so AC-20-specific
# fixtures continue to assert (factorydroid prefix without API/litellm
# context). Defense-in-depth favors false positives over false negatives:
# a missed litellm-shaped error masquerading as success is the more
# expensive failure mode. Case-insensitive.
_VENDOR_ERROR_RE = re.compile(
    r"(rate.?limit|API.?error|connection.?error|context.?length.?exceeded"
    r"|litellm\.exceptions|factorydroid:\s*error)",
    re.IGNORECASE,
)


class DroidDriver:
    """Driver that executes a task via the Factory Droid CLI subprocess."""

    def __init__(self) -> None:
        self._cli_version: str | None = None

    @property
    def name(self) -> str:
        return _DRIVER_NAME

    def version(self) -> str:
        """Version of this driver adapter."""
        return "0.1.0"

    def sdk_version(self) -> str:
        """
        Droid has no separate SDK; returns the same value as version().
        """
        return self.version()

    def release_date(self) -> str:
        return "2024-08-01"

    def prepare(self, workspace: Path, task_manifest: dict) -> None:
        pass

    def _get_cli_version(self) -> str:
        """Retrieve the installed droid CLI version, cached per instance."""
        if self._cli_version is not None:
            return self._cli_version
        try:
            version_proc = subprocess.run(
                ["droid", "--version"],
                capture_output=True,
                text=True,
                timeout=5,
            )
            self._cli_version = version_proc.stdout.strip() or "unknown"
        except (FileNotFoundError, subprocess.TimeoutExpired, subprocess.SubprocessError, OSError):
            self._cli_version = "unknown"
        return self._cli_version

    def execute(
        self,
        workspace: Path,
        task_manifest: dict,
        seed: int,
        budget_usd: float,
        wall_clock_budget_seconds: int,
        cache_strategy: CacheStrategy = "salted",
    ) -> DriverResult:
        """
        Run the task via the Droid CLI and return a DriverResult.

        Writes the entry_point content to a tempfile, then invokes:
          droid exec --auto low -o json -f <tempfile_path>

        Cost and tokens are scraped from the single-object JSON stdout.

        cache_strategy is fixed to "native" for droid regardless of input —
        the driver does not control the upstream model's cache layer.
        """
        result_cache_strategy: CacheStrategy = "native"

        # Fetch cli_version before main subprocess call (cached per instance)
        cli_version = self._get_cli_version()

        # Resolve prompt content from entry_point
        entry_point: str = task_manifest.get("entry_point", "")
        entry_point_path = workspace / entry_point
        try:
            prompt_text = entry_point_path.read_text(encoding="utf-8")
        except (OSError, ValueError):
            prompt_text = entry_point

        # Write prompt to a tempfile for '-f' argument
        tmp_file = tempfile.NamedTemporaryFile(mode="w", suffix=".md", delete=False)
        tmp_path = tmp_file.name
        try:
            tmp_file.write(prompt_text)
            tmp_file.flush()
            tmp_file.close()

            cmd = [
                "droid",
                "exec",
                "--auto", "low",
                "-o", "json",
                "-f", tmp_path,
            ]

            start = time.monotonic()

            try:
                proc = subprocess.run(
                    cmd,
                    cwd=str(workspace),
                    capture_output=True,
                    text=True,
                    timeout=wall_clock_budget_seconds,
                )
            except subprocess.TimeoutExpired:
                elapsed_ms = int((time.monotonic() - start) * 1000)
                return make_aborted_result(
                    elapsed_ms,
                    AbortReason(category="wall_clock_exceeded"),
                    "scraped",
                    result_cache_strategy,
                    {"cli_version": cli_version},
                )
            except FileNotFoundError:
                elapsed_ms = int((time.monotonic() - start) * 1000)
                return make_aborted_result(
                    elapsed_ms,
                    AbortReason(category="driver_error"),
                    "scraped",
                    result_cache_strategy,
                    {"cli_version": cli_version},
                )

            elapsed_ms = int((time.monotonic() - start) * 1000)
            stdout_text = proc.stdout or ""

            # JSON parsing — droid's '-o json' contract. The actual JSON object
            # may be at the end of stdout if any leading text precedes it
            # (matched_pattern scan covers that case below).
            json_parse_failed = False
            result_obj: dict = {}
            try:
                # Try whole stdout first (clean path).
                result_obj = json.loads(stdout_text)
                if not isinstance(result_obj, dict):
                    result_obj = {}
                    json_parse_failed = True
            except (json.JSONDecodeError, TypeError):
                # Recovery: prefix text precedes the JSON object. Use
                # raw_decode from the FIRST '{' (not rfind — rfind finds
                # the deepest nested brace, e.g. `usage`'s opener, which
                # then fails with "Extra data" on the trailing `}}`).
                # raw_decode parses one balanced JSON value and tolerates
                # trailing text past the JSON's end_idx.
                decoder = json.JSONDecoder()
                obj_start = stdout_text.find("{")
                if obj_start >= 0:
                    try:
                        candidate, _ = decoder.raw_decode(stdout_text, obj_start)
                        if isinstance(candidate, dict):
                            result_obj = candidate
                        else:
                            json_parse_failed = True
                    except (json.JSONDecodeError, ValueError):
                        json_parse_failed = True
                else:
                    json_parse_failed = True

            input_tokens, output_tokens, cost_usd = extract_droid_json_cost(result_obj)

            # AC-20(2): is_error_field_present — record key presence, not value.
            is_error_field_present = "is_error" in result_obj
            driver_metadata: dict = {
                "cli_version": cli_version,
                "is_error_field_present": is_error_field_present,
            }

            # AC-20(3) defense-in-depth: scan stdout for vendor error patterns.
            # Fires even when result_obj.get("is_error") is False — handles the
            # case where a vendor-text error precedes the JSON object.
            match = _VENDOR_ERROR_RE.search(stdout_text)
            if match:
                driver_metadata["matched_pattern"] = match.group(0)
                return make_aborted_result(
                    elapsed_ms,
                    AbortReason(category="api_error_text", detail=match.group(0)),
                    "scraped",
                    result_cache_strategy,
                    driver_metadata,
                    input_tokens=input_tokens,
                    output_tokens=output_tokens,
                    cost_usd=cost_usd,
                )

            is_error = (
                proc.returncode != 0
                or bool(result_obj.get("is_error", False))
                or json_parse_failed
            )
            abort_reason: AbortReason | None = (
                AbortReason(category="driver_error") if is_error else None
            )

            return DriverResult(
                wall_clock_ms=elapsed_ms,
                input_tokens=input_tokens,
                output_tokens=output_tokens,
                cost_usd=cost_usd,
                cost_source="scraped",
                aborted=is_error,
                abort_reason=abort_reason,
                cache_strategy=result_cache_strategy,
                driver_metadata=driver_metadata,
            )
        finally:
            try:
                os.unlink(tmp_path)
            except OSError:
                pass
