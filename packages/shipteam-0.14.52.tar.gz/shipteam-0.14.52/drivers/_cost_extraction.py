"""
drivers/_cost_extraction.py — Cost extraction helpers for subprocess-based drivers.

Provides pure functions for scraping cost/token data from tool output:
  - extract_aider_cost: parse Aider stdout for cost lines
  - extract_droid_json_cost: parse Factory Droid '-o json' single-object result
"""
from __future__ import annotations

import re

from drivers._subprocess_helpers import coerce_float_or_none, coerce_int_or_none


def extract_aider_cost(stdout: str) -> tuple[int | None, int | None, float | None]:
    """
    Parse Aider stdout and return (input_tokens, output_tokens, cost_usd).

    Aider does not natively emit token counts in non-interactive mode.
    input_tokens and output_tokens are always None.

    Handles multiple known Aider output formats:
      v0.61: 'Cost: $0.0097 message'
      v0.64: 'Cost: $0.0097 message, $0.0023 session'
      v0.83: 'Tokens: 12,345 sent, 2,345 received. Cost: $0.0097 message, $0.0023 session'

    Returns (None, None, None) on any parse failure — never raises.
    """
    try:
        # Look for session cost first (preferred: cumulative metric)
        session_match = re.search(r"Cost:.*?\$[\d.,]+\s+message,\s*\$([\d.]+)\s+session", stdout)
        if session_match:
            return (None, None, float(session_match.group(1)))

        # Fall back to message-only cost
        message_match = re.search(r"Cost:\s*\$([\d.]+)\s+message", stdout)
        if message_match:
            return (None, None, float(message_match.group(1)))

        return (None, None, None)
    except Exception:
        return (None, None, None)


def extract_droid_json_cost(result_obj: dict) -> tuple[int | None, int | None, float | None]:
    """
    Parse a Factory Droid '-o json' single-object result and return
    (input_tokens, output_tokens, cost_usd).

    PHASE 2 PART 1 ASSUMPTION (unverified by empirical capture):
        Factory Droid's `-o json` output schema for usage/cost is NOT
        authoritatively documented (docs.factory.ai/cli/droid-exec/overview
        as of 2026-04-18 does not commit to a specific shape for cost/tokens).
        This parser assumes the Anthropic-style usage sub-object shape:
            {"usage": {"input_tokens": N, "output_tokens": N, "cost_usd": F}}

        TODO(phase-2-part-2): replace with empirically-captured fixture and
        regression-pin the exact schema. The Pivot Log in .sherlock-plan.md
        (2026-04-18 entry) documents the research source and rationale — this
        TODO is the migration tracer once that plan artifact is deleted at
        Step 8 per Sherlock methodology.

    Returns (None, None, None) when fields are absent or result_obj is malformed.
    Never raises KeyError, AttributeError, or TypeError.
    """
    try:
        usage = result_obj.get("usage")
        if not isinstance(usage, dict):
            return (None, None, None)

        raw_input = usage.get("input_tokens")
        raw_output = usage.get("output_tokens")
        raw_cost = usage.get("cost_usd")

        return (
            coerce_int_or_none(raw_input),
            coerce_int_or_none(raw_output),
            coerce_float_or_none(raw_cost),
        )
    except Exception:
        return (None, None, None)
