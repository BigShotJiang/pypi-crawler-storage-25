#!/bin/bash
# claude-session.sh - Automated worktree-isolated Claude Code session
#
# This script automatically:
# 1. Creates an isolated git worktree for the session
# 2. Bootstraps dependencies (Python venv, npm install)
# 3. Starts frontend dev server on unique port
# 4. Launches Claude Code in that worktree
# 5. Cleans up server and worktree when Claude exits
#
# Usage:
#   ./scripts/claude-session.sh                      # Auto-generates session branch
#   ./scripts/claude-session.sh feature/my-feature   # Uses specific branch name
#   ./scripts/claude-session.sh --keep               # Don't cleanup on exit
#   ./scripts/claude-session.sh --no-servers         # Skip dev server startup
#   ./scripts/claude-session.sh --no-sync            # Skip auto-sync with origin/main

set -e

# Source shared framework library
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/_framework.sh"

# Read configuration
PROJECT_NAME=$(fw_get_nested "project.name" "project")
PROJECT_REPO=$(fw_get_nested "project.repo" "")
WORKTREE_BASE=$(fw_resolve_path "$(fw_get_nested "paths.worktree_base" "${HOME}/worktrees")")
BACKEND_PORT=$(fw_get_nested "stack.backend.port" "8000")
BACKEND_ROOT=$(fw_get_nested "stack.backend.root" "")
BACKEND_LANG=$(fw_get_nested "stack.backend.language" "")
BACKEND_VERSION=$(fw_get_nested "stack.backend.version" "")
FRONTEND_PORT_START=$(fw_get_nested "stack.frontend.port" "3003")
FRONTEND_ROOT=$(fw_get_nested "stack.frontend.root" "")
FRONTEND_PORT_FLAG=$(fw_get_nested "stack.frontend.port_flag" "")
FRONTEND_START_CMD=$(fw_get_nested "stack.frontend.start_command" "npm run dev")
_NOTIFICATION_PROVIDER=$(fw_get_nested "notifications.provider" "none")
_NOTIFICATION_WEBHOOK_ENV=$(fw_get_nested "notifications.webhook_env" "")

# Guard: respect worktree.enabled config
WORKTREE_ENABLED=$(fw_get_nested "worktree.enabled" "true")
if [ "$WORKTREE_ENABLED" = "false" ]; then
    echo "ERROR: Worktree isolation is disabled (worktree.enabled: false in framework.yaml)"
    exit 1
fi

# Parse arguments
KEEP_WORKTREE=false
START_SERVERS=true
NO_SYNC=false
BRANCH_NAME=""
CLEAN_WORKTREE=false
EXPLICIT_BRANCH=false
MEMO=""
PRINT_BRANCH_NAME=false

while [[ $# -gt 0 ]]; do
    case $1 in
        --keep)
            KEEP_WORKTREE=true
            shift
            ;;
        --clean)
            CLEAN_WORKTREE=true
            shift
            ;;
        --no-servers)
            START_SERVERS=false
            shift
            ;;
        --no-sync)
            NO_SYNC=true
            shift
            ;;
        -m|--memo)
            if [ $# -lt 2 ] || [[ "$2" == -* ]]; then
                echo "ERROR: -m/--memo requires a slug argument" >&2
                exit 1
            fi
            MEMO="$2"
            shift 2
            ;;
        --print-branch-name)
            PRINT_BRANCH_NAME=true
            shift
            ;;
        --help|-h)
            echo "Usage: $0 [--keep|--clean] [--no-servers] [--no-sync] [-m SLUG] [branch-name]"
            echo ""
            echo "Launches Claude Code in an isolated git worktree with dev server."
            echo "Uses shared backend on port $BACKEND_PORT (ensure it's running)."
            echo ""
            echo "Worktree lifecycle:"
            echo "  Auto-generated branch (no arg): destroyed on exit (disposable session)"
            echo "  Explicit branch name:           preserved on exit (resumable)"
            echo ""
            echo "Options:"
            echo "  --keep         Force preserve worktree (overrides default destroy)"
            echo "  --clean        Force destroy worktree on exit (overrides default preserve)"
            echo "  --no-servers   Skip starting frontend server"
            echo "  --no-sync      Skip auto-sync with origin/main"
            echo "  -m, --memo SLUG  Append a short purpose slug to the auto-generated"
            echo "                   session branch name, e.g. -m sentinel-fix produces"
            echo "                   session/claude-YYYYMMDD-HHMMSS-sentinel-fix."
            echo "                   Slug must match ^[a-z0-9]([a-z0-9-]{0,38}[a-z0-9])?\$"
            echo "                   (lowercase alphanumeric + hyphens, 1-40 chars,"
            echo "                    no leading or trailing hyphen)."
            echo "                   Incompatible with an explicit branch-name argument."
            echo "  --help         Show this help message"
            exit 0
            ;;
        *)
            BRANCH_NAME="$1"
            EXPLICIT_BRANCH=true
            shift
            ;;
    esac
done

# Validate memo (if provided) before any side-effecting operations.
# The slug is interpolated into a git branch name and a worktree directory
# path, so reject anything outside a strict lowercase-alphanumeric-hyphen
# allowlist. This also rejects leading hyphens (to prevent the slug from
# being interpreted as a flag) and keeps branch names under git's tolerance
# for long refnames.
if [ -n "$MEMO" ]; then
    # First+last char must be alphanumeric; middle may include hyphens.
    # Length: 1 (first) + 0-38 (middle) + 1 (last) = 1..40. Single-char
    # slugs take the outer class only via the `()?` optional group.
    if ! [[ "$MEMO" =~ ^[a-z0-9]([a-z0-9-]{0,38}[a-z0-9])?$ ]]; then
        echo "ERROR: --memo must match ^[a-z0-9]([a-z0-9-]{0,38}[a-z0-9])?\$" >&2
        echo "       (lowercase alphanumeric + hyphens, 1-40 chars," >&2
        echo "        no leading or trailing hyphen)" >&2
        echo "       Got: '$MEMO'" >&2
        exit 1
    fi
    if [ "$EXPLICIT_BRANCH" = true ]; then
        echo "ERROR: -m/--memo and an explicit branch-name argument are mutually exclusive" >&2
        echo "       Memo only customizes the auto-generated session branch; pass one or the other." >&2
        exit 1
    fi
fi

# Generate branch name if not provided. Memo (if any) is appended after the
# timestamp so sort-order stays chronological and uniqueness is preserved
# across parallel sessions launched in the same second with the same memo.
if [ -z "$BRANCH_NAME" ]; then
    TIMESTAMP=$(date +%Y%m%d-%H%M%S)
    if [ -n "$MEMO" ]; then
        BRANCH_NAME="session/claude-${TIMESTAMP}-${MEMO}"
    else
        BRANCH_NAME="session/claude-${TIMESTAMP}"
    fi
fi

# Testability: print the computed branch name and exit. Used by the bats
# regression tests to exercise arg-parsing and name computation without
# creating a worktree or launching Claude.
if [ "$PRINT_BRANCH_NAME" = true ]; then
    echo "$BRANCH_NAME"
    exit 0
fi

# Default lifecycle: explicit branches preserve (resumable, avoids stale-inode bug
# when a shell is cd'd into the worktree). Auto-generated sessions stay disposable.
# --keep / --clean override.
if [ "$EXPLICIT_BRANCH" = true ] && [ "$CLEAN_WORKTREE" = false ]; then
    KEEP_WORKTREE=true
fi

# Create worktree directory name (replace / with -)
SAFE_BRANCH_NAME=$(echo "$BRANCH_NAME" | sed 's/\//-/g')
WORKTREE_DIR="$WORKTREE_BASE/$PROJECT_NAME-$SAFE_BRANCH_NAME"

# Port tracking file
PORT_FILE="$WORKTREE_DIR/.claude-port"

# Server PID tracking
FRONTEND_PID=""
ASSIGNED_FRONTEND_PORT=""

# ===================================================================
# Copy-on-Write & .claude/ Bootstrap Functions
# ===================================================================

# Copy-on-Write aware recursive copy.
# Uses APFS clonefile on macOS, reflink on Linux, plain cp fallback.
# Args: $1=source $2=destination
cp_cow() {
    local src="$1"
    local dst="$2"

    case "$(uname -s)" in
        Darwin)
            cp -Rc "$src" "$dst"
            ;;
        Linux)
            cp -r --reflink=auto "$src" "$dst"
            ;;
        *)
            cp -r "$src" "$dst"
            ;;
    esac
}

# Bootstrap .claude/ directory in a worktree from main repo.
# Copies hooks/, rules/, agents/, skills/, settings.json (physical copies, not symlinks).
# Symlinks settings.local.json (personal, gitignored).
# Creates fresh state/ directory (per-worktree, never shared).
# Skips files/dirs that already exist in target (no clobber).
# Args: $1=source_claude_dir (e.g. /path/to/main/.claude)
#       $2=target_worktree_dir (e.g. /path/to/worktree)
bootstrap_claude_dir() {
    local source_dir="$1"
    local target_worktree="$2"
    local target_claude="$target_worktree/.claude"

    # If source doesn't exist, nothing to bootstrap
    if [ ! -d "$source_dir" ]; then
        return 0
    fi

    # Ensure target .claude/ exists
    mkdir -p "$target_claude"

    # Copy content directories (hooks, rules, agents, skills) — no clobber
    for subdir in hooks rules agents skills; do
        if [ -d "$source_dir/$subdir" ] && [ ! -d "$target_claude/$subdir" ]; then
            cp_cow "$source_dir/$subdir" "$target_claude/$subdir"
        fi
    done

    # Copy settings.json — no clobber
    if [ -f "$source_dir/settings.json" ] && [ ! -f "$target_claude/settings.json" ]; then
        cp "$source_dir/settings.json" "$target_claude/settings.json"
    fi

    # Symlink settings.local.json (personal, gitignored) — replace dangling, no clobber valid
    local target_local="$target_claude/settings.local.json"
    if [ -L "$target_local" ] && [ ! -e "$target_local" ]; then
        # Dangling symlink (target moved/deleted) — remove so we can re-create
        rm -f "$target_local"
    fi
    if [ -f "$source_dir/settings.local.json" ] && \
       [ ! -e "$target_local" ] && [ ! -L "$target_local" ]; then
        ln -s "$source_dir/settings.local.json" "$target_local"
    fi

    # state/ — each worktree gets its OWN state (never symlinked)
    if [ -L "$target_claude/state" ]; then
        rm -f "$target_claude/state"
    fi
    if [ ! -d "$target_claude/state" ]; then
        mkdir -p "$target_claude/state"
        touch "$target_claude/state/.gitkeep"
    fi
}

# ===================================================================
# Port Management Functions
# ===================================================================

find_available_port() {
    local base_port=$1
    local port=$base_port

    while lsof -i :$port >/dev/null 2>&1; do
        port=$((port + 1))
        if [ $port -gt $((base_port + 100)) ]; then
            echo "ERROR: No available ports found in range $base_port-$port" >&2
            return 1
        fi
    done
    echo $port
}

start_frontend_server() {
    local port=$1
    local worktree=$2
    local fe_dir="$worktree/$FRONTEND_ROOT"

    echo "   Starting frontend on port $port..."

    if [ ! -d "$fe_dir" ]; then
        echo "   Frontend directory not found: $fe_dir"
        return 1
    fi

    cd "$fe_dir"
    local logfile="/tmp/frontend-$port.log"
    touch "$logfile" && chmod 600 "$logfile"
    # PORT env var is the universal fallback (Next.js reads it natively).
    # port_flag (e.g., "--port" for Vite, "-p" for Next.js) is additive for
    # frameworks that need an explicit CLI arg. Empty port_flag = PORT-only mode.
    if [ -n "$FRONTEND_PORT_FLAG" ]; then
        PORT=$port BROWSER=none $FRONTEND_START_CMD -- $FRONTEND_PORT_FLAG $port > "$logfile" 2>&1 &
    else
        PORT=$port BROWSER=none $FRONTEND_START_CMD > "$logfile" 2>&1 &
    fi
    FRONTEND_PID=$!

    sleep 3

    if kill -0 $FRONTEND_PID 2>/dev/null; then
        echo "   Frontend running: http://localhost:$port"
        return 0
    else
        echo "   Frontend failed to start (check /tmp/frontend-$port.log)"
        FRONTEND_PID=""
        return 1
    fi
}

# ===================================================================
# Main Script
# ===================================================================

echo "==================================================================="
echo "  Claude Code Isolated Session Launcher"
echo "==================================================================="
echo ""
echo "  Creating isolated worktree for parallel development..."
echo "   Branch: $BRANCH_NAME"
echo "   Location: $WORKTREE_DIR"
echo ""

# Cleanup function — defined early so trap catches failures during worktree setup
cleanup() {
    echo ""
    echo "  Claude exited. Cleaning up..."

    if [ -n "$FRONTEND_PID" ] && kill -0 $FRONTEND_PID 2>/dev/null; then
        echo "   Stopping frontend server (PID $FRONTEND_PID)..."
        kill $FRONTEND_PID 2>/dev/null || true
    fi

    rm -f "$PORT_FILE" 2>/dev/null || true

    if [ "$KEEP_WORKTREE" = true ]; then
        echo ""
        echo "==================================================================="
        echo "  Worktree preserved at: $WORKTREE_DIR"
        echo ""
        echo "To resume later:"
        echo "   cd $WORKTREE_DIR && claude"
        echo ""
        echo "To cleanup when done:"
        echo "   $FW_PROJECT_ROOT/scripts/cleanup-worktree.sh $WORKTREE_DIR"
        echo "==================================================================="
    else
        if [ -d "$WORKTREE_DIR" ]; then
            cd "$WORKTREE_DIR"

            # Safety guard: refuse to destroy worktrees with unsaved work.
            # EXIT-trap prompts are unreliable (non-interactive shells, crashes,
            # SIGTERM) so we preserve loudly instead of asking. session/* branches
            # are exempt — they are disposable by design.
            PRESERVE_REASON=""
            if [ -n "$(git status --porcelain 2>/dev/null)" ]; then
                PRESERVE_REASON="uncommitted changes"
            elif [[ "$BRANCH_NAME" != session/* ]]; then
                # Non-session branch: check for unpushed commits.
                # No upstream = never pushed = treat all commits as unpushed.
                if ! git rev-parse --abbrev-ref --symbolic-full-name '@{u}' >/dev/null 2>&1; then
                    if [ -n "$(git log --oneline 2>/dev/null | head -1)" ]; then
                        PRESERVE_REASON="branch has no upstream (commits would be lost)"
                    fi
                elif [ -n "$(git log '@{u}..' --oneline 2>/dev/null)" ]; then
                    PRESERVE_REASON="unpushed commits"
                fi
            fi

            if [ -n "$PRESERVE_REASON" ]; then
                echo ""
                echo "  Refusing to destroy worktree: $PRESERVE_REASON"
                echo "  Preserved at: $WORKTREE_DIR"
                echo "  Force cleanup with: $FW_PROJECT_ROOT/scripts/cleanup-worktree.sh $WORKTREE_DIR"
                exit 0
            fi

            cd "$FW_PROJECT_ROOT"
            export GIT_DIR="$FW_PROJECT_ROOT/.git"
            export GIT_WORK_TREE="$FW_PROJECT_ROOT"
            git worktree remove "$WORKTREE_DIR" --force 2>/dev/null || true
            git worktree prune
        fi

        echo "  Worktree and server cleaned up"
        echo ""
        echo "==================================================================="
        echo "Session complete!"
        echo "==================================================================="
    fi
}

trap cleanup EXIT

# Create base directory
mkdir -p "$WORKTREE_BASE"

# Change to project root
cd "$FW_PROJECT_ROOT"

# Set git environment for worktree creation
export GIT_DIR="$FW_PROJECT_ROOT/.git"
export GIT_WORK_TREE="$FW_PROJECT_ROOT"

# Check if worktree already exists
if [ -d "$WORKTREE_DIR" ]; then
    echo "  Worktree already exists at $WORKTREE_DIR"
    echo "   Resuming existing session..."

    # Migrate old whole-directory .claude symlink to physical copies
    if [ -L "$WORKTREE_DIR/.claude" ]; then
        echo "   Migrating .claude from whole-dir symlink to physical copies..."
        rm -f "$WORKTREE_DIR/.claude"
    fi

    # Bootstrap .claude/ — fills gaps (no clobber) on every resume
    if [ -d "$FW_PROJECT_ROOT/.claude" ]; then
        bootstrap_claude_dir "$FW_PROJECT_ROOT/.claude" "$WORKTREE_DIR"
        echo "   Configuration verified"
    fi

    if [ -f "$PORT_FILE" ]; then
        # Security: parse port file safely instead of sourcing (prevents code injection)
        ASSIGNED_FRONTEND_PORT=$(grep -oE '^ASSIGNED_FRONTEND_PORT=[0-9]+$' "$PORT_FILE" | cut -d= -f2)
        if [ -n "$ASSIGNED_FRONTEND_PORT" ]; then
            echo "   Previous frontend port: $ASSIGNED_FRONTEND_PORT"
        fi
    fi
else
    # Create the worktree
    if git show-ref --verify --quiet "refs/heads/$BRANCH_NAME"; then
        echo "   Note: Branch '$BRANCH_NAME' already exists, checking it out"
        git worktree add "$WORKTREE_DIR" "$BRANCH_NAME"
    else
        git worktree add -b "$BRANCH_NAME" "$WORKTREE_DIR"
    fi

    echo ""
    echo "  Setting up dependencies..."

    # Bootstrap backend dependencies
    if [ -n "$BACKEND_ROOT" ] && [ -d "$WORKTREE_DIR/$BACKEND_ROOT" ] && [ -f "$WORKTREE_DIR/$BACKEND_ROOT/requirements.txt" ]; then
        echo "   Setting up Python virtual environment..."
        cd "$WORKTREE_DIR"

        # Determine Python command from config
        PYTHON_CMD="python3"
        if [ -n "$BACKEND_VERSION" ] && [ "$BACKEND_LANG" = "python" ]; then
            VERSIONED_CMD="python${BACKEND_VERSION}"
            if command -v "$VERSIONED_CMD" &>/dev/null; then
                PYTHON_CMD="$VERSIONED_CMD"
            fi
        fi

        if $PYTHON_CMD -m venv venv; then
            ./venv/bin/pip install --quiet -r "$BACKEND_ROOT/requirements.txt" 2>/dev/null || true
            echo "   Backend dependencies installed"
        else
            echo "   Venv creation failed - Claude will still work"
        fi
    fi

    # Bootstrap frontend dependencies
    if [ -n "$FRONTEND_ROOT" ] && [ -f "$WORKTREE_DIR/$FRONTEND_ROOT/package.json" ]; then
        echo "   Installing frontend dependencies..."
        cd "$WORKTREE_DIR/$FRONTEND_ROOT"
        if HUSKY=0 npm install --silent 2>/dev/null; then
            echo "   Frontend dependencies installed"
        else
            echo "   Frontend dependencies failed - run 'npm install' manually"
        fi
    fi

    # Bootstrap .claude/ into worktree — copies hooks, rules, agents, skills,
    # settings.json (physical copies); symlinks settings.local.json; fresh state/.
    # .claude/ is gitignored in all consumer projects, so git worktree add
    # does NOT populate it — bootstrap_claude_dir fills the gap.
    if [ -d "$FW_PROJECT_ROOT/.claude" ]; then
        bootstrap_claude_dir "$FW_PROJECT_ROOT/.claude" "$WORKTREE_DIR"
        echo "   Configuration bootstrapped"
    fi

    # Symlink .env files from main repo (single source of truth)
    echo "   Linking environment files..."
    # Root-level .env files are always checked. Subdirectory .env files are only
    # added when root != "." to avoid duplicates (root/.env == ./.env).
    ENV_FILES=".env .env.local"
    [ -n "$BACKEND_ROOT" ] && [ "$BACKEND_ROOT" != "." ] && ENV_FILES="$ENV_FILES $BACKEND_ROOT/.env $BACKEND_ROOT/.env.local"
    [ -n "$FRONTEND_ROOT" ] && [ "$FRONTEND_ROOT" != "." ] && ENV_FILES="$ENV_FILES $FRONTEND_ROOT/.env.local"
    for env_file in $ENV_FILES; do
        if [ -f "$FW_PROJECT_ROOT/$env_file" ] && [ ! -e "$WORKTREE_DIR/$env_file" ]; then
            mkdir -p "$(dirname "$WORKTREE_DIR/$env_file")"
            ln -s "$FW_PROJECT_ROOT/$env_file" "$WORKTREE_DIR/$env_file"
            echo "   Linked $env_file"
        fi
    done

    # Configure git remote for gh CLI compatibility
    if [ -n "$PROJECT_REPO" ]; then
        cd "$WORKTREE_DIR"
        git remote set-url origin "https://github.com/${PROJECT_REPO}.git" 2>/dev/null || true
    fi
fi

# Reset git environment for worktree operations
unset GIT_DIR
unset GIT_WORK_TREE

# ===================================================================
# Auto-Sync with Main
# ===================================================================

echo ""
if [ "$NO_SYNC" = true ]; then
    echo "  Auto-sync disabled (--no-sync flag)"
else
    echo "  Auto-syncing with origin/main..."

    cd "$WORKTREE_DIR"

    COMMITS_BEHIND=$(git rev-list --count HEAD..origin/main 2>/dev/null || echo "0")

    if [ "$COMMITS_BEHIND" -eq 0 ]; then
        echo "   Already up to date with origin/main"
    else
        echo "   $COMMITS_BEHIND commits behind origin/main - syncing..."
        echo ""
        git log --oneline HEAD..origin/main 2>/dev/null | head -5 | sed 's/^/     /' || true
        echo ""

        # Check for uncommitted changes
        STASHED=0
        STASH_NAME=""

        if ! git diff --quiet 2>/dev/null || ! git diff --cached --quiet 2>/dev/null; then
            STASH_NAME="auto-stash-before-sync-$(date +%Y%m%d-%H%M%S)"
            echo "   Stashing uncommitted changes before sync..."
            git stash push -m "$STASH_NAME"
            STASHED=1
        fi

        # Try fast-forward first
        if git merge origin/main --ff-only 2>/dev/null; then
            echo "   Fast-forwarded to origin/main"
            if [ "$STASHED" = 1 ]; then
                git stash pop 2>/dev/null && echo "   Restored stashed changes" || echo "   Stash pop had issues"
            fi
        else
            echo "   Cannot fast-forward. Attempting merge..."
            if git merge origin/main --no-edit 2>/dev/null; then
                echo "   Merged origin/main successfully"
                if [ "$STASHED" = 1 ]; then
                    git stash pop 2>/dev/null && echo "   Restored stashed changes" || echo "   Stash pop had issues"
                fi
            else
                echo ""
                echo "   MERGE CONFLICT - Claude will resolve this automatically!"
                echo ""
                git diff --name-only --diff-filter=U 2>/dev/null | sed 's/^/     - /'
                echo ""

                # Create marker file for hook
                mkdir -p "$WORKTREE_DIR/.claude/state"
                CONFLICTED_FILES=$(git diff --name-only --diff-filter=U 2>/dev/null | tr '\n' ' ')
                cat > "$WORKTREE_DIR/.claude/state/merge-conflict.json" << CONFLICT_EOF
{
    "timestamp": "$(date -u +%Y-%m-%dT%H:%M:%SZ)",
    "behind_count": $COMMITS_BEHIND,
    "conflicted_files": "$(echo $CONFLICTED_FILES | sed 's/ $//')",
    "stashed": $STASHED,
    "stash_name": "$STASH_NAME"
}
CONFLICT_EOF

                echo "   The merge-conflict-resolver hook will instruct Claude to fix this."
            fi
        fi
    fi

    cd "$FW_PROJECT_ROOT"
fi

# ===================================================================
# Start Frontend Dev Server
# ===================================================================

if [ "$START_SERVERS" = true ]; then
    echo ""
    echo "  Starting frontend dev server..."

    # Check backend if configured
    if [ -n "$BACKEND_ROOT" ]; then
        echo "   Note: Uses shared backend on port $BACKEND_PORT (ensure it's running)"
        if ! lsof -i :"$BACKEND_PORT" >/dev/null 2>&1; then
            echo ""
            echo "   WARNING: Backend not running on port $BACKEND_PORT!"
            echo "   Start it with: cd $FW_PROJECT_ROOT && ./scripts/manage-servers.sh start"
            echo ""
        fi
    fi

    ASSIGNED_FRONTEND_PORT=$(find_available_port $FRONTEND_PORT_START)
    echo "   Assigned frontend port: $ASSIGNED_FRONTEND_PORT"
    echo "ASSIGNED_FRONTEND_PORT=$ASSIGNED_FRONTEND_PORT" > "$PORT_FILE"

    if [ -n "$FRONTEND_ROOT" ] && [ -f "$WORKTREE_DIR/$FRONTEND_ROOT/package.json" ]; then
        start_frontend_server $ASSIGNED_FRONTEND_PORT "$WORKTREE_DIR"
    elif [ -z "$FRONTEND_ROOT" ]; then
        echo "   No frontend configured (stack.frontend.root not set) - skipping"
    else
        echo "   Frontend package.json not found at $FRONTEND_ROOT/ - skipping"
    fi
fi

echo ""
echo "==================================================================="
echo "  Worktree ready! Launching Claude Code..."
if [ "$START_SERVERS" = true ] && { [ -n "$ASSIGNED_FRONTEND_PORT" ] || [ -n "$BACKEND_ROOT" ]; }; then
    echo ""
    echo "  TEST YOUR CHANGES AT:"
    [ -n "$ASSIGNED_FRONTEND_PORT" ] && echo "   Frontend: http://localhost:$ASSIGNED_FRONTEND_PORT"
    [ -n "$BACKEND_ROOT" ] && echo "   Backend:  http://localhost:$BACKEND_PORT (shared)"
fi
echo "==================================================================="
echo ""

# Change to worktree directory
cd "$WORKTREE_DIR"

# Ensure git environment is clean
unset GIT_DIR
unset GIT_WORK_TREE

# Create helper script for git env
cat > "$WORKTREE_DIR/.git-env" << EOF
# Git environment for this worktree (auto-generated by claude-session.sh)
# Source this file if git commands fail: source .git-env
export GIT_WORK_TREE="$WORKTREE_DIR"
EOF

# Launch Claude Code in a clean framework env so scripts inside claude's
# shell auto-detect FW_PROJECT_ROOT from their own source location instead
# of inheriting the launcher's (which resolves to the main-repo path, not
# the worktree). Strips identity + override vars; retains cosmetic color
# vars (FW_RED/GREEN/...) since they're harmless. Defense-in-depth for the
# guard in _framework.sh that PR #143 added: without this scrub, the guard
# warns on every framework script invocation inside claude's shell.
# `env -u` is preferred over `unset` so this script's own env remains
# intact for the EXIT cleanup trap that runs after claude exits.
env -u FW_PROJECT_ROOT -u FW_CONFIG -u FW_FW_DIR -u FW_ROOT_OVERRIDE -u FW_SKIP_PREREQ_CHECK claude

# Cleanup happens automatically via trap
