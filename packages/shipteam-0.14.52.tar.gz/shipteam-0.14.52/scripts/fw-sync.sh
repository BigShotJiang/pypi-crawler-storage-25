#!/bin/bash
# ============================================================================
# fw-sync.sh — Framework Update Distribution System
# ============================================================================
# Syncs framework files (agents, rules, skills, hooks, scripts, config) to
# projects that use dev-framework. Replaces version-specific migration scripts
# with a single, reusable, content-aware sync tool.
#
# Usage:
#   fw-sync.sh <project-dir> [OPTIONS]
#
# Options:
#   --status               Show sync status without changing anything
#   --dry-run              Preview what would change (no writes)
#   --category <cat>       Sync only: agents, rules, skills, hooks, scripts, config
#   --file <path>          Sync only a specific file (relative to project root)
#   --force                Replace even template-policy files (with backup)
#   --diff                 Show unified diffs for changed files
#   --full-diff            Show full diffs (no truncation)
#   --merge-editor, --edit Open merge editor for template conflicts
#   --merged <file>        Mark a template file as manually merged
#   --framework-dir <dir>  Override framework location (default: script's parent)
#   --init                 Initialize .framework-sync.yaml for existing project
#
# Sync policies (defined in config/fw-manifest.yaml):
#   replace  — Backup + overwrite (safe for non-customized files)
#   template — Show diff, never auto-overwrite (project customizes these)
#   merge    — Append new YAML sections without touching existing values
#
# Examples:
#   fw-sync.sh ~/my-project --status
#   fw-sync.sh ~/my-project --dry-run
#   fw-sync.sh ~/my-project
#   fw-sync.sh ~/my-project --category agents
#   fw-sync.sh ~/my-project --file .claude/agents/fw-review-forensics.md
# ============================================================================

set -o pipefail
# Note: NOT using set -e because diff returns exit code 1 when files differ,
# which is expected behavior in this script.

# ── Resolve framework root (where this script lives) ─────────────────────────
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DEFAULT_FRAMEWORK_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"

# ── Colors ────────────────────────────────────────────────────────────────────
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
BOLD='\033[1m'
NC='\033[0m'

# ── Cross-platform SHA256 ────────────────────────────────────────────────────
compute_sha() {
    local file="$1"
    if [ ! -f "$file" ]; then
        echo "MISSING"
        return
    fi
    if command -v shasum &>/dev/null; then
        shasum -a 256 "$file" | awk '{print $1}'
    elif command -v sha256sum &>/dev/null; then
        sha256sum "$file" | awk '{print $1}'
    else
        # Fallback: use openssl
        openssl dgst -sha256 "$file" | awk '{print $NF}'
    fi
}

# ── Smart diff display ───────────────────────────────────────────────────────
# Shows unified diff with smart truncation. Replaces hardcoded `head -N` calls.
show_diff() {
    local file_a="$1"  # project file (left)
    local file_b="$2"  # framework file (right)
    local diff_output
    diff_output=$(diff -u "$file_a" "$file_b" 2>/dev/null) || true

    if [ -z "$diff_output" ]; then
        return 0
    fi

    local line_count
    line_count=$(echo "$diff_output" | wc -l | tr -d ' ')

    if [ "$FULL_DIFF" = true ] || [ "$line_count" -le 200 ]; then
        echo "$diff_output"
    else
        echo "$diff_output" | head -100
        echo ""
        echo -e "    ${YELLOW}... showing 100 of $line_count lines. Use --full-diff for all${NC}"
    fi
    echo ""
}

# ── Three-way merge support ─────────────────────────────────────────────────
CACHE_DIR=""

init_cache_dir() {
    CACHE_DIR="$PROJECT_DIR/.fw-sync-cache"
    mkdir -p "$CACHE_DIR"
    # Ensure it's gitignored
    local gitignore="$PROJECT_DIR/.gitignore"
    if [ -f "$gitignore" ]; then
        if ! grep -qxF '.fw-sync-cache/' "$gitignore" 2>/dev/null; then
            echo '.fw-sync-cache/' >> "$gitignore"
        fi
    fi
}

cache_framework_file() {
    local filepath="$1"
    local fw_file="$2"
    [ -z "$CACHE_DIR" ] && init_cache_dir
    local cache_path="$CACHE_DIR/$filepath"
    mkdir -p "$(dirname "$cache_path")"
    cp "$fw_file" "$cache_path"
}

get_cached_base() {
    local filepath="$1"
    [ -z "$CACHE_DIR" ] && init_cache_dir
    local cache_path="$CACHE_DIR/$filepath"
    if [ -f "$cache_path" ]; then
        echo "$cache_path"
    fi
}

show_three_way_diff() {
    local proj_file="$1"
    local fw_file="$2"
    local filepath="$3"
    local base_file
    base_file=$(get_cached_base "$filepath")

    if [ -z "$base_file" ]; then
        # No cached base — fall back to two-way diff
        show_diff "$proj_file" "$fw_file"
        return 1
    fi

    echo -e "    ${CYAN}Three-way merge (base → framework vs project):${NC}"
    local merge_result
    merge_result=$(diff3 -m "$proj_file" "$base_file" "$fw_file" 2>/dev/null)
    local exit_code=$?

    if [ $exit_code -eq 0 ]; then
        # Clean merge possible
        echo -e "    ${GREEN}Clean merge available — no conflicts detected${NC}"
        return 0
    else
        # Conflicts exist — show merge with markers
        echo "$merge_result" | head -80
        local total_conflicts
        total_conflicts=$(echo "$merge_result" | grep -c '<<<<<<<' || true)
        echo ""
        echo -e "    ${YELLOW}$total_conflicts conflict(s) detected. Use --merge-editor to resolve.${NC}"
        return 1
    fi
}

# ── Merge editor ─────────────────────────────────────────────────────────────
open_merge_editor() {
    local proj_file="$1"
    local fw_file="$2"
    local filepath="$3"
    local base_file
    base_file=$(get_cached_base "$filepath")

    # Determine editor: env var > vscode > vimdiff > terminal diff
    local editor="${FW_MERGE_EDITOR:-auto}"

    if [ "$editor" = "auto" ]; then
        if command -v code &>/dev/null; then
            editor="vscode"
        elif command -v vimdiff &>/dev/null; then
            editor="vim"
        else
            editor="diff"
        fi
    fi

    case "$editor" in
        vscode)
            if [ -n "$base_file" ]; then
                echo -e "    ${BLUE}Opening VS Code three-way merge...${NC}"
                code --merge "$base_file" "$fw_file" "$proj_file" "$proj_file" --wait
            else
                echo -e "    ${BLUE}Opening VS Code diff...${NC}"
                code --diff "$proj_file" "$fw_file" --wait
            fi
            ;;
        vim|vimdiff)
            if [ -n "$base_file" ]; then
                echo -e "    ${BLUE}Opening vimdiff (3-way)...${NC}"
                vimdiff "$proj_file" "$base_file" "$fw_file"
            else
                echo -e "    ${BLUE}Opening vimdiff...${NC}"
                vimdiff "$proj_file" "$fw_file"
            fi
            ;;
        diff|*)
            echo -e "    ${YELLOW}No visual editor available. Showing diff:${NC}"
            show_diff "$proj_file" "$fw_file"
            echo -e "    ${YELLOW}Set FW_MERGE_EDITOR=vscode or install vimdiff for visual merge.${NC}"
            ;;
    esac
}

# ── Cross-platform date ──────────────────────────────────────────────────────
iso_date() {
    date -u +"%Y-%m-%dT%H:%M:%SZ"
}

# ── Parse arguments ──────────────────────────────────────────────────────────
PROJECT_DIR=""
FRAMEWORK_DIR="$DEFAULT_FRAMEWORK_DIR"
MODE="sync"          # sync | status | dry-run | init
FILTER_CATEGORY=""
FILTER_FILE=""
FORCE=false
SHOW_DIFF=false
FULL_DIFF=false
MERGE_EDITOR=false
MARK_MERGED=""

while [[ $# -gt 0 ]]; do
    case "$1" in
        --status)       MODE="status"; shift ;;
        --dry-run)      MODE="dry-run"; shift ;;
        --init)         MODE="init"; shift ;;
        --force)        FORCE=true; shift ;;
        --diff)         SHOW_DIFF=true; shift ;;
        --full-diff)    FULL_DIFF=true; SHOW_DIFF=true; shift ;;
        --merge-editor|--edit) MERGE_EDITOR=true; shift ;;
        --merged)       MARK_MERGED="$2"; shift 2 ;;
        --category)     FILTER_CATEGORY="$2"; shift 2 ;;
        --file)         FILTER_FILE="$2"; shift 2 ;;
        --framework-dir) FRAMEWORK_DIR="$2"; shift 2 ;;
        --help|-h)
            head -35 "${BASH_SOURCE[0]}" | tail -30
            exit 0
            ;;
        -*)
            echo -e "${RED}Unknown option: $1${NC}" >&2
            exit 1
            ;;
        *)
            if [ -z "$PROJECT_DIR" ]; then
                PROJECT_DIR="$1"
            else
                echo -e "${RED}Unexpected argument: $1${NC}" >&2
                exit 1
            fi
            shift
            ;;
    esac
done

# ── Validate inputs ─────────────────────────────────────────────────────────
if [ -z "$PROJECT_DIR" ]; then
    echo -e "${RED}Usage: fw-sync.sh <project-dir> [OPTIONS]${NC}" >&2
    echo "Run with --help for full usage." >&2
    exit 1
fi

# Resolve to absolute path
PROJECT_DIR="$(cd "$PROJECT_DIR" 2>/dev/null && pwd)" || {
    echo -e "${RED}Project directory not found: $PROJECT_DIR${NC}" >&2
    exit 1
}

FRAMEWORK_DIR="$(cd "$FRAMEWORK_DIR" 2>/dev/null && pwd)" || {
    echo -e "${RED}Framework directory not found: $FRAMEWORK_DIR${NC}" >&2
    exit 1
}

MANIFEST="$FRAMEWORK_DIR/config/fw-manifest.yaml"
SYNC_STATE="$PROJECT_DIR/.framework-sync.yaml"
FW_VERSION_FILE="$FRAMEWORK_DIR/FRAMEWORK_VERSION"

if [ ! -f "$MANIFEST" ]; then
    echo -e "${RED}Manifest not found: $MANIFEST${NC}" >&2
    echo "Is $FRAMEWORK_DIR a dev-framework installation?" >&2
    exit 1
fi

if [ ! -f "$PROJECT_DIR/config/framework.yaml" ]; then
    echo -e "${RED}Not a dev-framework project: $PROJECT_DIR${NC}" >&2
    echo "Missing config/framework.yaml" >&2
    exit 1
fi

FW_VERSION="unknown"
[ -f "$FW_VERSION_FILE" ] && FW_VERSION="$(cat "$FW_VERSION_FILE" | tr -d '[:space:]')"

# ── Record separator ─────────────────────────────────────────────────────────
# Use tab as field separator (portable across macOS/Linux bash versions)
# Descriptions in the manifest must not contain literal tabs
SEP=$'\t'

# ── Parse manifest ───────────────────────────────────────────────────────────
# Extract file entries from the manifest.
# Returns: filepath<SOH>policy<SOH>config_gate<SOH>description<SOH>category
parse_manifest() {
    awk -v sep="$SEP" '
    /^[a-z_-]+:/ {
        current_category = $0
        sub(/:.*/, "", current_category)
        next
    }
    /^  "/ {
        # File path line
        filepath = $0
        sub(/^  "/, "", filepath)
        sub(/".*/, "", filepath)
        current_file = filepath
        current_policy = ""
        current_gate = ""
        current_desc = ""
        next
    }
    /^[[:space:]]+policy:/ {
        val = $0
        sub(/.*policy:[ \t]*/, "", val)
        gsub(/[[:space:]]/, "", val)
        current_policy = val
    }
    /^[[:space:]]+config_gate:/ {
        val = $0
        sub(/.*config_gate:[ \t]*"?/, "", val)
        sub(/".*/, "", val)
        gsub(/[[:space:]]/, "", val)
        current_gate = val
    }
    /^[[:space:]]+description:/ {
        val = $0
        sub(/.*description:[ \t]*"/, "", val)
        sub(/".*/, "", val)
        current_desc = val
        # Emit complete record with SOH separator
        printf "%s%s%s%s%s%s%s%s%s\n", current_file, sep, current_policy, sep, current_gate, sep, current_desc, sep, current_category
    }
    ' "$(manifest_files)"
}

# ── Manifest file list ───────────────────────────────────────────────────────
# Returns the manifest file(s) to parse.
manifest_files() {
    echo "$MANIFEST"
}

# ── Parse sync state ────────────────────────────────────────────────────────
# Returns: filepath<SOH>framework_sha<SOH>project_sha<SOH>status<SOH>last_merged_fw_sha
parse_sync_state() {
    if [ ! -f "$SYNC_STATE" ]; then
        return
    fi
    awk -v sep="$SEP" '
    /^  "/ {
        filepath = $0
        sub(/^  "/, "", filepath)
        sub(/".*/, "", filepath)
        current_file = filepath
        fw_sha = ""
        proj_sha = ""
        status = ""
        merged_sha = ""
    }
    /framework_sha:/ {
        val = $0; sub(/.*framework_sha:[ \t]*"?/, "", val); sub(/".*/, "", val)
        gsub(/[[:space:]]/, "", val); fw_sha = val
    }
    /project_sha:/ {
        val = $0; sub(/.*project_sha:[ \t]*"?/, "", val); sub(/".*/, "", val)
        gsub(/[[:space:]]/, "", val); proj_sha = val
    }
    /last_merged_fw_sha:/ {
        val = $0; sub(/.*last_merged_fw_sha:[ \t]*"?/, "", val); sub(/".*/, "", val)
        gsub(/[[:space:]]/, "", val); merged_sha = val
    }
    /status:/ {
        val = $0; sub(/.*status:[ \t]*"?/, "", val); sub(/".*/, "", val)
        gsub(/[[:space:]]/, "", val); status = val
        printf "%s%s%s%s%s%s%s%s%s\n", current_file, sep, fw_sha, sep, proj_sha, sep, status, sep, merged_sha
    }
    ' "$SYNC_STATE"
}

# ── Check config gate ────────────────────────────────────────────────────────
# Returns 0 if the feature is enabled in the project's framework.yaml, 1 if disabled
check_config_gate() {
    local gate="$1"
    if [ -z "$gate" ]; then
        return 0  # No gate = always enabled
    fi

    local value
    local proj_config="$PROJECT_DIR/config/framework.yaml"

    # Pass the dotted gate string directly and split on "." inside awk
    value=$(awk -v gate="$gate" '
    BEGIN {
        n = split(gate, path, ".")
        current_part = 1
        target_depth = -1
    }
    /^[[:space:]]*#/ || /^[[:space:]]*$/ { next }
    {
        match($0, /^[[:space:]]*/)
        indent = RLENGTH
        if (target_depth >= 0 && indent <= target_depth && current_part > 1) exit
        regex = "^[[:space:]]*" path[current_part] ":"
        if ($0 ~ regex) {
            if (current_part == n) {
                sub(/^[^:]*:[[:space:]]*/, "")
                sub(/[[:space:]]*#.*/, "")
                gsub(/["'"'"']/, "")
                print
                exit
            } else {
                target_depth = indent
                current_part++
            }
        }
    }' "$proj_config" 2>/dev/null)

    if [ "$value" = "false" ]; then
        return 1
    fi
    return 0
}

# ── Lookup previous sync state for a file ────────────────────────────────────
get_prev_sync() {
    local filepath="$1"
    local field="$2"  # framework_sha, project_sha, status, last_merged_fw_sha
    local state_data="$3"

    echo "$state_data" | awk -F"$SEP" -v f="$filepath" -v field="$field" '
    $1 == f {
        if (field == "framework_sha") print $2
        else if (field == "project_sha") print $3
        else if (field == "status") print $4
        else if (field == "last_merged_fw_sha") print $5
    }'
}

# ── Create backup ────────────────────────────────────────────────────────────
create_backup() {
    local filepath="$1"
    local full_path="$PROJECT_DIR/$filepath"
    if [ ! -f "$full_path" ]; then
        return
    fi
    local backup_dir
    backup_dir="$PROJECT_DIR/.fw-sync-backups/$(date +%Y%m%d-%H%M%S)"
    local backup_path="$backup_dir/$filepath"
    mkdir -p "$(dirname "$backup_path")"
    cp "$full_path" "$backup_path"
}

# ── YAML merge: append new sections to project's framework.yaml ─────────────
# Finds top-level sections in framework that don't exist in project and appends them
merge_yaml() {
    local fw_file="$FRAMEWORK_DIR/config/framework.yaml"
    local proj_file="$PROJECT_DIR/config/framework.yaml"
    local dry_run="$1"

    # Extract top-level section names (lines starting with a word followed by colon, no indent)
    local fw_sections proj_sections
    fw_sections=$(grep -E '^[a-z_]+:' "$fw_file" | sed 's/:.*//' | sort)
    proj_sections=$(grep -E '^[a-z_]+:' "$proj_file" | sed 's/:.*//' | sort)

    local new_sections
    new_sections=$(comm -23 <(echo "$fw_sections") <(echo "$proj_sections"))

    if [ -z "$new_sections" ]; then
        return 0
    fi

    local count=0
    while IFS= read -r section; do
        [ -z "$section" ] && continue
        count=$((count + 1))

        if [ "$dry_run" = "true" ]; then
            echo -e "  ${CYAN}[merge]${NC} Would append section: ${BOLD}$section${NC}"
            continue
        fi

        # Extract the full section block from framework yaml
        local block
        block=$(awk -v sect="$section" '
        BEGIN { found = 0; collecting = 0 }
        {
            if ($0 ~ "^" sect ":") {
                found = 1
                collecting = 1
                print ""  # blank line separator
                print $0
                next
            }
            if (collecting) {
                if (/^[a-z_]+:/ || /^---/) {
                    collecting = 0
                    next
                }
                print $0
            }
        }' "$fw_file")

        if [ -n "$block" ]; then
            echo "$block" >> "$proj_file"
            echo -e "  ${GREEN}[merged]${NC} Appended section: ${BOLD}$section${NC}"
        fi
    done <<< "$new_sections"

    return 0
}

# ── Write sync state file ────────────────────────────────────────────────────
# Accumulates entries via global array, then writes at end
declare -a SYNC_ENTRIES=()

add_sync_entry() {
    local filepath="$1"
    local fw_sha="$2"
    local proj_sha="$3"
    local status="$4"
    local last_merged_fw_sha="${5:-}"
    local synced_at
    synced_at="$(iso_date)"
    local entry="  \"$filepath\":
    framework_sha: \"$fw_sha\"
    project_sha: \"$proj_sha\"
    synced_at: \"$synced_at\"
    status: \"$status\""
    if [ -n "$last_merged_fw_sha" ]; then
        entry="$entry
    last_merged_fw_sha: \"$last_merged_fw_sha\""
    fi
    SYNC_ENTRIES+=("$entry")
}

write_sync_state() {
    # Build a newline-separated list of filepaths we processed this run
    local processed_list=""
    if [ ${#SYNC_ENTRIES[@]} -gt 0 ]; then
        for entry in "${SYNC_ENTRIES[@]}"; do
            local fp
            fp=$(echo "$entry" | head -1 | sed 's/^  "//;s/".*//')
            processed_list="${processed_list}${fp}"$'\n'
        done
    fi

    # Collect preserved entries from previous state (files not processed this run)
    local preserved_entries=()
    if [ -n "$PREV_STATE" ]; then
        while IFS=$'\t' read -r pf pfw ppj pst pmerged; do
            [ -z "$pf" ] && continue
            # Check if this file was processed — grep the processed list
            if ! echo "$processed_list" | grep -qxF "$pf"; then
                # Not processed this run — carry forward from previous state
                local prev_synced
                prev_synced=$(iso_date)
                local preserved_entry="  \"$pf\":
    framework_sha: \"$pfw\"
    project_sha: \"$ppj\"
    synced_at: \"$prev_synced\"
    status: \"$pst\""
                if [ -n "$pmerged" ]; then
                    preserved_entry="$preserved_entry
    last_merged_fw_sha: \"$pmerged\""
                fi
                preserved_entries+=("$preserved_entry")
            fi
        done <<< "$PREV_STATE"
    fi

    cat > "$SYNC_STATE" << HEADER
# .framework-sync.yaml — auto-generated by fw-sync.sh
# Tracks framework file sync state. Commit this file to git.
last_sync: "$(iso_date)"
framework_version: "$FW_VERSION"

files:
HEADER
    if [ ${#SYNC_ENTRIES[@]} -gt 0 ]; then
        for entry in "${SYNC_ENTRIES[@]}"; do
            echo "$entry" >> "$SYNC_STATE"
            echo "" >> "$SYNC_STATE"
        done
    fi
    if [ ${#preserved_entries[@]} -gt 0 ]; then
        for entry in "${preserved_entries[@]}"; do
            echo "$entry" >> "$SYNC_STATE"
            echo "" >> "$SYNC_STATE"
        done
    fi
}

# ── Main sync logic ─────────────────────────────────────────────────────────

echo ""
echo -e "${BOLD}fw-sync${NC} — Framework Update Distribution"
echo -e "Framework: ${BLUE}$FRAMEWORK_DIR${NC} (v$FW_VERSION)"
echo -e "Project:   ${BLUE}$PROJECT_DIR${NC}"
echo -e "Mode:      ${YELLOW}$MODE${NC}"
[ -n "$FILTER_CATEGORY" ] && echo -e "Filter:    category=${CYAN}$FILTER_CATEGORY${NC}"
[ -n "$FILTER_FILE" ] && echo -e "Filter:    file=${CYAN}$FILTER_FILE${NC}"
echo ""

# Load previous sync state
PREV_STATE=""
[ -f "$SYNC_STATE" ] && PREV_STATE="$(parse_sync_state)"

# ── Handle --merged flag ─────────────────────────────────────────────────────
if [ -n "$MARK_MERGED" ]; then
    merged_fw_file="$FRAMEWORK_DIR/$MARK_MERGED"
    merged_proj_file="$PROJECT_DIR/$MARK_MERGED"
    if [ ! -f "$merged_proj_file" ]; then
        echo -e "${RED}File not found in project: $MARK_MERGED${NC}" >&2
        exit 1
    fi
    merged_fw_sha="$(compute_sha "$merged_fw_file")"
    merged_proj_sha="$(compute_sha "$merged_proj_file")"
    # Update sync state marking this file as merged at current framework SHA
    add_sync_entry "$MARK_MERGED" "$merged_fw_sha" "$merged_proj_sha" "customized" "$merged_fw_sha"
    # Cache the framework version as the new merge base
    cache_framework_file "$MARK_MERGED" "$merged_fw_file"
    write_sync_state
    echo -e "${GREEN}Marked as merged:${NC} $MARK_MERGED"
    echo -e "  Framework SHA: ${CYAN}${merged_fw_sha:0:12}${NC}"
    echo -e "  Future diffs will show only changes since this merge."
    echo ""
    exit 0
fi

# ── Clean up deprecated files ─────────────────────────────────────────────────
# Removes files listed in the deprecated section of fw-manifest.yaml.
# Creates backups before deletion. Runs before main sync loop.
DEPRECATED_CLEANED=0

cleanup_deprecated() {
    local mode="$1"  # sync | status | dry-run

    # Parse deprecated entries from manifest
    local deprecated_files
    deprecated_files=$(awk '
    /^deprecated:/ { in_dep = 1; next }
    /^[a-z_-]+:/ && !/^  / { in_dep = 0 }
    in_dep && /^  "/ {
        f = $0
        sub(/^  "/, "", f)
        sub(/".*/, "", f)
        print f
    }
    ' "$MANIFEST")

    [ -z "$deprecated_files" ] && return

    while IFS= read -r filepath; do
        [ -z "$filepath" ] && continue
        local proj_file="$PROJECT_DIR/$filepath"

        if [ ! -f "$proj_file" ]; then
            continue  # Already gone — nothing to do
        fi

        DEPRECATED_CLEANED=$((DEPRECATED_CLEANED + 1))

        if [ "$mode" = "status" ]; then
            echo -e "  ${YELLOW}[deprecated]${NC} $filepath  (will be removed on sync)"
        elif [ "$mode" = "dry-run" ]; then
            echo -e "  ${YELLOW}[deprecated]${NC} Would remove: $filepath"
        else
            create_backup "$filepath"
            rm "$proj_file"
            echo -e "  ${RED}[removed]${NC}  $filepath  (backup created)"
        fi
    done <<< "$deprecated_files"
}

cleanup_deprecated "$MODE"

# Counters
SYNCED=0
SKIPPED=0
NEW_FILES=0
CONFLICTS=0
TEMPLATE_DIFFS=0
GATED_SKIP=0
MERGED=0

# Process each manifest entry
while IFS=$'\t' read -r filepath policy config_gate _description category; do
    [ -z "$filepath" ] && continue

    # Apply filters
    if [ -n "$FILTER_CATEGORY" ] && [ "$category" != "$FILTER_CATEGORY" ]; then
        continue
    fi
    if [ -n "$FILTER_FILE" ] && [ "$filepath" != "$FILTER_FILE" ]; then
        continue
    fi

    # Check config gate
    if [ -n "$config_gate" ] && ! check_config_gate "$config_gate"; then
        GATED_SKIP=$((GATED_SKIP + 1))
        if [ "$MODE" = "status" ]; then
            echo -e "  ${YELLOW}[gated]${NC}   $filepath  (${config_gate}=false)"
        fi
        continue
    fi

    fw_file="$FRAMEWORK_DIR/$filepath"
    proj_file="$PROJECT_DIR/$filepath"

    # Compute current SHAs
    fw_sha="$(compute_sha "$fw_file")"
    proj_sha="$(compute_sha "$proj_file")"

    # Get previous sync state
    prev_fw_sha="$(get_prev_sync "$filepath" "framework_sha" "$PREV_STATE")"
    prev_proj_sha="$(get_prev_sync "$filepath" "project_sha" "$PREV_STATE")"

    # ── Classify the situation ────────────────────────────────────────────

    # Case 1: File doesn't exist in project
    if [ "$proj_sha" = "MISSING" ]; then
        NEW_FILES=$((NEW_FILES + 1))

        if [ "$MODE" = "status" ]; then
            echo -e "  ${GREEN}[new]${NC}     $filepath"
        elif [ "$MODE" = "dry-run" ]; then
            echo -e "  ${GREEN}[new]${NC}     Would copy: $filepath"
        else
            mkdir -p "$(dirname "$proj_file")"
            cp "$fw_file" "$proj_file"
            cache_framework_file "$filepath" "$fw_file"
            echo -e "  ${GREEN}[copied]${NC}  $filepath"
            proj_sha="$(compute_sha "$proj_file")"
        fi
        add_sync_entry "$filepath" "$fw_sha" "${proj_sha:-$fw_sha}" "synced"
        continue
    fi

    # Case 2: Files are identical
    if [ "$fw_sha" = "$proj_sha" ]; then
        SKIPPED=$((SKIPPED + 1))
        if [ "$MODE" = "status" ]; then
            echo -e "  ${GREEN}[ok]${NC}      $filepath"
        fi
        add_sync_entry "$filepath" "$fw_sha" "$proj_sha" "synced"
        continue
    fi

    # Case 3: Files differ — determine what changed
    fw_changed=false
    proj_changed=false

    _first_sync=false
    if [ -n "$prev_fw_sha" ]; then
        [ "$prev_fw_sha" != "$fw_sha" ] && fw_changed=true
        [ "$prev_proj_sha" != "$proj_sha" ] && proj_changed=true
    else
        # No prior sync record — first sync for this file
        _first_sync=true
        fw_changed=true
        # For replace-policy files on first sync, don't treat as conflict
        # The framework version is authoritative
        if [ "$policy" = "replace" ]; then
            proj_changed=false
        else
            proj_changed=true
        fi
    fi

    # Case 3a: Only project changed (project customization) — don't touch
    if [ "$proj_changed" = true ] && [ "$fw_changed" = false ]; then
        SKIPPED=$((SKIPPED + 1))
        if [ "$MODE" = "status" ]; then
            echo -e "  ${BLUE}[custom]${NC}  $filepath  (project customized, framework unchanged)"
        fi
        add_sync_entry "$filepath" "$fw_sha" "$proj_sha" "customized"
        continue
    fi

    # Case 3b: Only framework changed — apply per policy
    # Case 3d: Both changed — flag as conflict (unless force)

    if [ "$proj_changed" = true ] && [ "$fw_changed" = true ]; then
        is_conflict=true
    else
        is_conflict=false
    fi

    # ── Apply per policy ──────────────────────────────────────────────────

    case "$policy" in
        replace)
            if [ "$is_conflict" = true ] && [ "$FORCE" = false ]; then
                CONFLICTS=$((CONFLICTS + 1))
                echo -e "  ${RED}[conflict]${NC} $filepath  (both framework and project changed)"
                if [ "$SHOW_DIFF" = true ] || [ "$MODE" = "status" ]; then
                    echo -e "    ${YELLOW}Framework diff:${NC}"
                    show_diff "$proj_file" "$fw_file"
                fi
                echo -e "    Run with ${BOLD}--force${NC} to overwrite (backup will be created)"
                add_sync_entry "$filepath" "$fw_sha" "$proj_sha" "conflict"
            else
                if [ "$MODE" = "status" ]; then
                    echo -e "  ${YELLOW}[outdated]${NC} $filepath  (framework updated)"
                elif [ "$MODE" = "dry-run" ]; then
                    echo -e "  ${YELLOW}[replace]${NC} Would update: $filepath"
                    if [ "$SHOW_DIFF" = true ]; then
                        show_diff "$proj_file" "$fw_file"
                    fi
                else
                    create_backup "$filepath"
                    cp "$fw_file" "$proj_file"
                    cache_framework_file "$filepath" "$fw_file"
                    proj_sha="$(compute_sha "$proj_file")"
                    SYNCED=$((SYNCED + 1))
                    echo -e "  ${GREEN}[synced]${NC}  $filepath"
                fi
                add_sync_entry "$filepath" "$fw_sha" "${proj_sha:-$fw_sha}" "synced"
            fi
            ;;

        template)
            if [ "$FORCE" = true ]; then
                TEMPLATE_DIFFS=$((TEMPLATE_DIFFS + 1))
                if [ "$MODE" = "dry-run" ]; then
                    echo -e "  ${YELLOW}[force]${NC}  Would overwrite (template): $filepath"
                elif [ "$MODE" != "status" ]; then
                    create_backup "$filepath"
                    cp "$fw_file" "$proj_file"
                    cache_framework_file "$filepath" "$fw_file"
                    proj_sha="$(compute_sha "$proj_file")"
                    SYNCED=$((SYNCED + 1))
                    echo -e "  ${YELLOW}[forced]${NC} $filepath  (template overwritten, backup created)"
                fi
                add_sync_entry "$filepath" "$fw_sha" "${proj_sha:-$fw_sha}" "synced"
            else
                # Check if we have a last_merged_fw_sha to determine if this is new
                prev_merged_sha="$(get_prev_sync "$filepath" "last_merged_fw_sha" "$PREV_STATE")"

                # Also check if cached base matches current framework (meaning
                # framework hasn't changed since last merge, even if last_merged_fw_sha
                # wasn't recorded — e.g., first sync or manual merge)
                base_file="$(get_cached_base "$filepath")"
                base_matches_fw=false
                if [ -n "$base_file" ] && cmp -s "$base_file" "$fw_file"; then
                    base_matches_fw=true
                fi

                if [ -n "$prev_merged_sha" ] && [ "$prev_merged_sha" = "$fw_sha" ]; then
                    echo -e "  ${GREEN}[template]${NC} $filepath  (up to date since last merge)"
                    add_sync_entry "$filepath" "$fw_sha" "$proj_sha" "customized" "$prev_merged_sha"
                elif [ "$base_matches_fw" = true ]; then
                    # Cached base == framework: no framework updates since last merge
                    echo -e "  ${BLUE}[custom]${NC}  $filepath  (project customized, framework unchanged)"
                    add_sync_entry "$filepath" "$fw_sha" "$proj_sha" "customized" "$fw_sha"
                else
                    TEMPLATE_DIFFS=$((TEMPLATE_DIFFS + 1))
                    echo -e "  ${CYAN}[template]${NC} $filepath  (project customizes this file)"
                    echo -e "    ${YELLOW}Framework has updates. Review diff and merge manually:${NC}"

                    if [ "$MERGE_EDITOR" = true ] && [ "$MODE" = "sync" ]; then
                        open_merge_editor "$proj_file" "$fw_file" "$filepath"
                    elif [ "$SHOW_DIFF" = true ] || [ "$MODE" = "status" ] || [ "$MODE" = "dry-run" ]; then
                        # Try three-way diff if base is cached
                        show_three_way_diff "$proj_file" "$fw_file" "$filepath" 2>/dev/null || \
                            show_diff "$proj_file" "$fw_file"
                    else
                        echo -e "    Run with ${BOLD}--diff${NC} to see changes, ${BOLD}--merge-editor${NC} to merge, or ${BOLD}--force${NC} to overwrite"
                    fi
                    add_sync_entry "$filepath" "$fw_sha" "$proj_sha" "customized" "${prev_merged_sha:-}"
                fi
            fi
            ;;

        merge)
            if [ "$MODE" = "status" ]; then
                echo -e "  ${CYAN}[merge]${NC}   $filepath  (checking for new sections)"
                merge_yaml "true"
            elif [ "$MODE" = "dry-run" ]; then
                merge_yaml "true"
            else
                merge_yaml "false"
                proj_sha="$(compute_sha "$proj_file")"
                MERGED=$((MERGED + 1))
            fi
            add_sync_entry "$filepath" "$fw_sha" "$proj_sha" "merged"
            ;;
    esac

done < <(parse_manifest)

# ── Write sync state (unless status-only) ────────────────────────────────────
if [ "$MODE" != "status" ] && [ "$MODE" != "dry-run" ]; then
    write_sync_state
fi

# ── Summary ──────────────────────────────────────────────────────────────────
echo ""
echo -e "${BOLD}Summary${NC}"
echo "───────────────────────────────────"
[ $SYNCED -gt 0 ]         && echo -e "  ${GREEN}Synced:${NC}          $SYNCED files"
[ $NEW_FILES -gt 0 ]      && echo -e "  ${GREEN}New files:${NC}       $NEW_FILES copied"
[ $MERGED -gt 0 ]         && echo -e "  ${CYAN}Merged:${NC}          $MERGED config sections"
[ $SKIPPED -gt 0 ]        && echo -e "  ${BLUE}Up to date:${NC}      $SKIPPED files"
[ $TEMPLATE_DIFFS -gt 0 ] && echo -e "  ${CYAN}Template diffs:${NC}  $TEMPLATE_DIFFS (manual merge needed)"
[ $CONFLICTS -gt 0 ]      && echo -e "  ${RED}Conflicts:${NC}       $CONFLICTS (use --force or merge manually)"
[ $DEPRECATED_CLEANED -gt 0 ] && echo -e "  ${RED}Deprecated:${NC}      $DEPRECATED_CLEANED removed"
[ $GATED_SKIP -gt 0 ]     && echo -e "  ${YELLOW}Gated (off):${NC}   $GATED_SKIP (disabled in project config)"
echo ""

if [ $CONFLICTS -gt 0 ]; then
    echo -e "${YELLOW}Action needed:${NC} $CONFLICTS conflict(s) require manual resolution or --force"
fi
if [ $TEMPLATE_DIFFS -gt 0 ]; then
    echo -e "${CYAN}Review needed:${NC} $TEMPLATE_DIFFS template file(s) have framework updates"
    echo -e "  Run with ${BOLD}--diff${NC} to see changes"
fi

if [ "$MODE" = "sync" ] && { [ $SYNCED -gt 0 ] || [ $NEW_FILES -gt 0 ]; }; then
    echo -e "${GREEN}Sync state saved to:${NC} .framework-sync.yaml"
    echo -e "Backups in: .fw-sync-backups/"
fi

echo ""
