#!/usr/bin/env bash
#
# validate-plan-delete-guard.sh — Block accidental deletion of
# .sherlock-plan.md or .test-matrix.md at the repo root without a
# corresponding new ADR (docs/adr/NNN-*.md) added in the same commit.
#
# Hazard (prompted this guard): PR #140 was a Sherlock Lite whose Step 8
# cleanup deleted .sherlock-plan.md and .test-matrix.md even though the
# Lite produced no ADR (so no actual "extraction" occurred). The plan at
# repo root belonged to a concurrent Sherlock Full work stream (the v1
# benchmark harness plan) and was lost. Per Sherlock methodology, plan /
# matrix artifacts are deleted ONLY after ADR extraction.
#
# Bypass: export FW_ALLOW_PLAN_DELETE=1 for commits where the ADR was
# extracted in a prior commit (sequential extract → next-commit cleanup).
#
# Exit 0: no plan/matrix deletion, OR deletion paired with new ADR, OR
#         FW_ALLOW_PLAN_DELETE=1 set.
# Exit 1: plan/matrix deletion without an accompanying new ADR.

set -euo pipefail

# Explicit bypass for maintainers who know what they're doing.
if [[ "${FW_ALLOW_PLAN_DELETE:-0}" == "1" ]]; then
    exit 0
fi

# What files are being deleted in this commit (staged)?
deleted_plans=$(git diff --cached --name-only --diff-filter=D 2>/dev/null \
    | grep -E '^(\.sherlock-plan\.md|\.test-matrix\.md)$' || true)

if [[ -z "$deleted_plans" ]]; then
    exit 0
fi

# Any NEW ADR being added? Must match docs/adr/NNN-*.md (3-digit prefix).
# README.md or ADR modifications don't count — only a new numbered ADR.
new_adrs=$(git diff --cached --name-only --diff-filter=A 2>/dev/null \
    | grep -E '^docs/adr/[0-9]{3}-.+\.md$' || true)

if [[ -n "$new_adrs" ]]; then
    # Legitimate Step 8 extraction — plan delete + new ADR add.
    exit 0
fi

# Plan/matrix delete without ADR: block with an actionable message.
cat <<EOF

==========================================================================
BLOCKED: .sherlock-plan.md / .test-matrix.md deletion without ADR extraction
==========================================================================

Files being deleted:
$(echo "$deleted_plans" | sed 's/^/  - /')

This commit does NOT add a new docs/adr/NNN-*.md file.

Per Sherlock methodology Step 8, plan/matrix artifacts are deleted ONLY
AFTER ADR extraction. PR #140 post-mortem on 2026-04-19 documented the
failure mode this guard prevents: a Sherlock Lite's Step 8 cleanup
accidentally deleted a different concurrent work stream's plan file.

Options:
  1) If the ADR was extracted in a PRIOR commit (sequential workflow),
     bypass with:
         FW_ALLOW_PLAN_DELETE=1 git commit ...

  2) If this deletion is accidental (e.g., a Sherlock Lite with no
     architecture decision shouldn't delete a parent workflow's plan),
     unstage the .sherlock-plan.md / .test-matrix.md entries:
         git reset HEAD .sherlock-plan.md .test-matrix.md

  3) If the ADR is genuinely being created in this commit but the
     filename doesn't match 'docs/adr/NNN-*.md' (3-digit prefix),
     rename it to match the project convention.

==========================================================================
EOF

exit 1
