#!/bin/bash
# export-prompt-snapshots.sh - Export current prompts to versioned snapshot directory
#
# Reads prompts.snapshot_dir from framework.yaml and copies all current
# prompts to a timestamped snapshot for rollback purposes.
#
# Usage: ./scripts/export-prompt-snapshots.sh

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/_framework.sh"

cd "$FW_PROJECT_ROOT"

# Read config
SNAPSHOT_DIR=$(fw_get_nested "prompts.snapshot_dir" "prompt_snapshots")
VERSIONING=$(fw_get_nested "prompts.versioning" "false")

if [ "$VERSIONING" = "false" ]; then
    echo "Prompt versioning is disabled in framework.yaml"
    echo "Set prompts.versioning: true to enable"
    exit 0
fi

TIMESTAMP=$(date +%Y%m%d_%H%M%S)
TARGET_DIR="$SNAPSHOT_DIR/$TIMESTAMP"

echo ""
echo "================================================================"
echo "  Prompt Snapshot Export"
echo "================================================================"
echo ""

# Find prompt files
PROMPT_DIRS=("prompts" "backend/prompts" "src/prompts")
FOUND=0

for dir in "${PROMPT_DIRS[@]}"; do
    if [ -d "$dir" ]; then
        echo "  Found prompts in: $dir"
        mkdir -p "$TARGET_DIR"
        cp -r "$dir"/* "$TARGET_DIR/" 2>/dev/null || true
        FOUND=1
    fi
done

if [ "$FOUND" = "0" ]; then
    echo "  No prompt directories found (checked: ${PROMPT_DIRS[*]})"
    echo "  Create a 'prompts/' directory with your prompt files"
    exit 0
fi

# Count files
FILE_COUNT=$(find "$TARGET_DIR" -type f 2>/dev/null | wc -l | tr -d ' ')

echo ""
echo "  Snapshot saved: $TARGET_DIR ($FILE_COUNT files)"
echo "  Don't forget to commit this snapshot"
echo ""
