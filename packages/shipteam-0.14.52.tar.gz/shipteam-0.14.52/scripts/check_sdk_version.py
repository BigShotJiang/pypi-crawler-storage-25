#!/usr/bin/env python3
"""CI gate: verify claude-agent-sdk pin alignment.

Exit codes:
  0 — all three conditions aligned (installed version, pyproject benchmark-claude pin, lockfile)
  1 — installed claude-agent-sdk version != "0.1.68" (read via importlib.metadata.version)
  2 — pyproject.toml [project.optional-dependencies].benchmark-claude does not contain
      "claude-agent-sdk==0.1.68"
  3 — requirements-benchmark.lock missing OR lacks a pinned "claude-agent-sdk==0.1.68" line
      OR lacks an "mcp==..." line (mcp is the SDK's primary declared transitive per
      PyPI metadata for claude-agent-sdk==0.1.68 — the original plan named "anthropic"
      but anthropic is not a declared dep of claude-agent-sdk; corrected 2026-04-27).

Accepts --check-only flag (no-op — present for CI compatibility).

Reads pyproject.toml + requirements-benchmark.lock from CWD (not the script's location).
"""
from __future__ import annotations

import argparse
import importlib.metadata
import re
import sys
import tomllib
from pathlib import Path

_EXPECTED_VERSION = "0.1.68"
_EXPECTED_DEP = f"claude-agent-sdk=={_EXPECTED_VERSION}"
_TRANSITIVE_GUARD_RE = re.compile(r"^mcp==")


def _check_installed_version() -> bool:
    try:
        installed = importlib.metadata.version("claude-agent-sdk")
    except importlib.metadata.PackageNotFoundError:
        return False
    return installed == _EXPECTED_VERSION


def _check_pyproject(cwd: Path) -> bool:
    pyproject_path = cwd / "pyproject.toml"
    if not pyproject_path.exists():
        return False
    with pyproject_path.open("rb") as f:
        data = tomllib.load(f)
    optional_deps = (
        data.get("project", {})
        .get("optional-dependencies", {})
        .get("benchmark-claude", [])
    )
    return _EXPECTED_DEP in optional_deps


def _check_lockfile(cwd: Path) -> bool:
    lockfile_path = cwd / "requirements-benchmark.lock"
    if not lockfile_path.exists():
        return False
    content = lockfile_path.read_text()
    lines = [line.strip() for line in content.splitlines()]
    has_sdk_pin = _EXPECTED_DEP in lines
    has_transitive_pin = any(_TRANSITIVE_GUARD_RE.match(line) for line in lines)
    return has_sdk_pin and has_transitive_pin


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Verify claude-agent-sdk pin alignment.")
    parser.add_argument(
        "--check-only",
        action="store_true",
        help="Run validation only (default behavior; flag accepted for CI compatibility).",
    )
    parser.parse_args(argv)

    cwd = Path.cwd()

    if not _check_installed_version():
        print(
            f"ERROR: installed claude-agent-sdk version != {_EXPECTED_VERSION!r}",
            file=sys.stderr,
        )
        return 1

    if not _check_pyproject(cwd):
        print(
            f"ERROR: pyproject.toml [project.optional-dependencies].benchmark-claude "
            f"does not contain {_EXPECTED_DEP!r}",
            file=sys.stderr,
        )
        return 2

    if not _check_lockfile(cwd):
        print(
            "ERROR: requirements-benchmark.lock missing or lacks required pins "
            f"(claude-agent-sdk=={_EXPECTED_VERSION} and mcp==<version>)",
            file=sys.stderr,
        )
        return 3

    print(f"OK: claude-agent-sdk=={_EXPECTED_VERSION} aligned across all three sources.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
