#!/bin/bash
# validate-no-bright-line.sh — Enforce ADR-007 public-repo bright-line sanitization.
#
# Scans the committed tree for commercial/strategic content that ADR-007 bars:
# pricing amounts, revenue/valuation comparables, GTM keywords, references to
# the maintainer's private-doc directory. Exits 1 on any finding.
#
# Suppress a false positive by adding `bright-line:allow` to the line
# (e.g. `<!-- bright-line:allow reason="regex example" -->`). Files that
# describe the policy itself are hard-coded as self-exempt below. For
# entire-file exemptions (historical or legitimate meta-references), add
# the repo-relative path to config/bright-line-allowlist.txt.
#
# Usage: ./scripts/validate-no-bright-line.sh

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=_framework.sh
source "$SCRIPT_DIR/_framework.sh"

cd "$FW_PROJECT_ROOT"

ALLOWLIST="$FW_PROJECT_ROOT/config/bright-line-allowlist.txt"

SELF_EXEMPT=(
  "docs/adr/007-public-repo-bright-line-sanitization.md"
  "docs/85-SAFETY-LIMITS.md"
  "scripts/validate-no-bright-line.sh"
  "config/bright-line-allowlist.txt"
  ".gitignore"
  ".github/workflows/ci-cd.yml"
  ".github/workflows/bright-line-check.yml"
  ".pre-commit-config.yaml"
  "docs/20-DEPLOYMENT.md"
)

# Combined pattern (ERE). Word-boundaries where applicable.
# - Pricing WITH period suffix (avoids matching API cost estimates like $0.02)
# - Valuation / round-size signalling
# - Commercial keywords
# - Private path references
PATTERN='(\$[0-9]+(\.[0-9]+)?[[:space:]]*/(mo|month|yr|year))|(\$[0-9]+(\.[0-9]+)?[[:space:]]*(MRR|ARR))|(\$[0-9]+[KMB]\b)|(\bvaluation\b)|(\bSeries [A-Z]\b)|(\bmarket cap\b)|(\bARR\b)|(\bMRR\b)|(\bgo-to-market\b)|(\bGTM\b)|(\bbuyer[- ]persona\b)|(\blaunch copy\b)|(\bpricing strategy\b)|(dev-framework-private)'

SUPPRESS='bright-line:allow'

echo "Scanning for ADR-007 bright-line violations..."

raw=$(grep -rEn "$PATTERN" \
  --include='*.md' --include='*.yml' --include='*.yaml' \
  --include='*.py' --include='*.sh' --include='*.json' --include='*.toml' \
  --exclude-dir=.git --exclude-dir=node_modules --exclude-dir=archives \
  --exclude-dir=__pycache__ --exclude-dir=venv --exclude-dir=.venv \
  "$FW_PROJECT_ROOT" 2>/dev/null || true)

found=0
while IFS= read -r line; do
  [ -z "$line" ] && continue

  file="${line%%:*}"
  rel="${file#"$FW_PROJECT_ROOT/"}"

  # Self-exempt check
  skip=false
  for exempt in "${SELF_EXEMPT[@]}"; do
    if [ "$rel" = "$exempt" ]; then skip=true; break; fi
  done
  $skip && continue

  # Path allowlist (full-line match)
  if [ -f "$ALLOWLIST" ] && grep -qxF "$rel" "$ALLOWLIST" 2>/dev/null; then
    continue
  fi

  # Suppress-comment on the line
  if echo "$line" | grep -q "$SUPPRESS"; then continue; fi

  echo "  $line"
  found=$((found + 1))
done <<< "$raw"

if [ "$found" -eq 0 ]; then
  echo "No bright-line violations found."
  exit 0
fi

echo ""
echo "Found $found bright-line violation(s). ADR-007 forbids this content in the committed tree."
echo ""
echo "Fix options:"
echo "  1. Remove the content (preferred — move to ~/Documents/dev-framework-private/)."
echo "  2. Add a suppress-comment on the line: <!-- bright-line:allow reason=\"why this is not a violation\" -->"
echo "  3. If the file is a legitimate meta-reference, add its repo-relative path to config/bright-line-allowlist.txt."
echo ""
echo "See docs/adr/007-public-repo-bright-line-sanitization.md for the policy."
exit 1
