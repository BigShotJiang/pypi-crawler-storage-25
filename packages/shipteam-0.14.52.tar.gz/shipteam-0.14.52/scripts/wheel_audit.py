"""Post-build artifact inspector for ShipTeam PyPI publish safety gate.

Check coverage by artifact type:
  .whl  — PYC_CHECK, PYCACHE_CHECK, BRIGHT_LINE (installed content; full scan)
  .tar.gz — PYC_CHECK, PYCACHE_CHECK only (sdist is the repo tree; bright-line
             coverage is already provided by scripts/validate-no-bright-line.sh
             with its exemption list; applying BRIGHT_LINE here produces false
             positives on ADR-007, CHANGELOG, test fixtures, and the scanner
             script itself)

Bypass surface: regex on NFKC-normalized text does NOT detect Cyrillic-for-Latin
confusables, zero-width character padding, or base64-encoded content.
Threat model: internal-author deterrence + accidental-leak prevention.
"""

from __future__ import annotations

import re
import sys
import tarfile
import unicodedata
import zipfile
from dataclasses import dataclass
from pathlib import Path


# Ported from scripts/validate-no-bright-line.sh PATTERN (line 43).
# IGNORECASE is intentionally more defensive than the shell grep (no -i flag)
# — a wheel scanner should catch lowercase variants too. False positives are
# surfaced at publish time; the cost of a false positive (manual exception) is
# lower than the cost of a missed violation (content shipped to PyPI).
_BRIGHT_LINE_RE = re.compile(
    r'(\$[0-9]+(\.[0-9]+)?\s*/(?:mo|month|yr|year))'
    r'|(\$[0-9]+(\.[0-9]+)?\s*(?:MRR|ARR))'
    r'|(\$[0-9]+[KMB]\b)'
    r'|(\bvaluation\b)'
    r'|(\bSeries [A-Z]\b)'
    r'|(\bmarket cap\b)'
    r'|(\bARR\b)'
    r'|(\bMRR\b)'
    r'|(\bgo-to-market\b)'
    r'|(\bGTM\b)'
    r'|(\bbuyer[- ]persona\b)'
    r'|(\blaunch copy\b)'
    r'|(\bpricing strategy\b)'
    r'|(dev-framework-private)',
    re.IGNORECASE,
)

_TEXT_EXTENSIONS = frozenset({'.py', '.md', '.txt', '.toml', '.yaml', '.yml', '.cfg', '.ini', '.rst', '.json'})
# Wheel/sdist text members that have no file extension (METADATA, LICENSE, etc.).
# METADATA carries the rendered README — primary leak surface for the configured threat model.
_TEXT_BASENAMES = frozenset({'METADATA', 'LICENSE', 'NOTICE', 'README', 'AUTHORS', 'PKG-INFO', 'WHEEL', 'RECORD'})


@dataclass
class AuditFinding:
    artifact: str
    check: str
    member: str
    detail: str = ""


def audit_artifact(path: Path) -> list[AuditFinding]:
    artifact_name = path.name
    findings: list[AuditFinding] = []

    name_lower = path.name.lower()

    if name_lower.endswith(".whl"):  # whl is a zip
        with zipfile.ZipFile(path, mode="r") as zf:
            for member_name in zf.namelist():
                content = zf.read(member_name)
                findings.extend(_check_member(artifact_name, member_name, content, scan_bright_line=True))
    elif name_lower.endswith(".tar.gz"):
        with tarfile.open(path, mode="r:gz") as tf:
            for member in tf.getmembers():
                if member.isfile():
                    f = tf.extractfile(member)
                    content = f.read() if f is not None else b""
                else:
                    content = b""
                findings.extend(_check_member(artifact_name, member.name, content, scan_bright_line=False))

    return findings


def _check_member(
    artifact_name: str,
    member_name: str,
    content: bytes,
    scan_bright_line: bool,
) -> list[AuditFinding]:
    results: list[AuditFinding] = []
    name_lower = member_name.lower()
    # Use parts-based check (split on /) so both "pkg/__pycache__/x.pyc" and
    # "pkg/__pycache__" (bare directory entry, no trailing slash) are caught.
    parts = name_lower.replace("\\", "/").split("/")

    if name_lower.endswith(".pyc") or name_lower.endswith(".pyo"):
        results.append(AuditFinding(artifact=artifact_name, check="PYC_CHECK", member=member_name))

    if "__pycache__" in parts:
        results.append(AuditFinding(artifact=artifact_name, check="PYCACHE_CHECK", member=member_name))

    if scan_bright_line and content and b"\x00" not in content:
        p = Path(member_name)
        if p.suffix.lower() in _TEXT_EXTENSIONS or p.name in _TEXT_BASENAMES:
            text = content.decode("utf-8", errors="replace")
            normalized = unicodedata.normalize("NFKC", text)
            for line in normalized.splitlines():
                m = _BRIGHT_LINE_RE.search(line)
                if m:
                    results.append(AuditFinding(
                        artifact=artifact_name, check="BRIGHT_LINE",
                        member=member_name, detail=m.group(0),
                    ))

    return results


def _is_artifact(name: str) -> bool:
    n = name.lower()
    return n.endswith(".whl") or n.endswith(".tar.gz")


def audit_dist_dir(dist_dir: Path) -> list[AuditFinding]:
    findings: list[AuditFinding] = []
    for artifact_path in sorted(dist_dir.iterdir()):
        if _is_artifact(artifact_path.name):
            findings.extend(audit_artifact(artifact_path))
    return findings


if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: wheel_audit.py <dist_dir_or_artifact>", file=sys.stderr)
        sys.exit(2)

    target = Path(sys.argv[1])
    if not target.exists():
        print(f"Error: path not found: {target}", file=sys.stderr)
        sys.exit(2)

    if target.is_dir():
        artifacts = sorted(p for p in target.iterdir() if _is_artifact(p.name))
        if not artifacts:
            print(f"Error: no .whl or .tar.gz artifacts found in {target}", file=sys.stderr)
            sys.exit(2)
        all_findings = audit_dist_dir(target)
    else:
        artifacts = [target]
        all_findings = audit_artifact(target)

    # Build per-artifact finding sets for reporting
    findings_by_artifact: dict[str, list[AuditFinding]] = {}
    for artifact_path in artifacts:
        findings_by_artifact[artifact_path.name] = []
    for finding in all_findings:
        if finding.artifact not in findings_by_artifact:
            findings_by_artifact[finding.artifact] = []
        findings_by_artifact[finding.artifact].append(finding)

    violation_count = 0
    for artifact_path in artifacts:
        artifact_findings = findings_by_artifact.get(artifact_path.name, [])
        if artifact_findings:
            for f in artifact_findings:
                if f.detail:
                    print(f"FAIL {f.artifact} {f.check}: {f.member} ({f.detail})")
                else:
                    print(f"FAIL {f.artifact} {f.check}: {f.member}")
            violation_count += len(artifact_findings)
        else:
            print(f"PASS {artifact_path.name}")

    print(f"Audit complete: {len(artifacts)} artifact(s) checked, {violation_count} violation(s) found")

    sys.exit(1 if violation_count > 0 else 0)
