#!/usr/bin/env python3
"""
Prompt Migration Template

Copy this file and customize for your specific migration:
    cp scripts/templates/prompt_migration_template.py scripts/run_migration_NNN.py

Then edit the SOURCE_PROMPT, TARGET_PROMPT, and transform() function.
"""
import os
import sys
from datetime import datetime
from pathlib import Path


# ============================================================================
# CONFIGURE THESE FOR YOUR MIGRATION
# ============================================================================

# Path to the current (old) prompt
SOURCE_PROMPT = "prompts/prompt_v001_initial.txt"

# Path for the new prompt version
TARGET_PROMPT = "prompts/prompt_v002_description.txt"

# Description of what this migration changes
DESCRIPTION = "Describe what changed and why"


def transform(old_prompt: str) -> str:
    """
    Transform the old prompt into the new version.

    Args:
        old_prompt: The content of the source prompt

    Returns:
        The new prompt content
    """
    # Example transformations:
    # new_prompt = old_prompt.replace("old_text", "new_text")
    # new_prompt = old_prompt + "\n\nAdditional instructions..."
    # new_prompt = completely_new_content

    new_prompt = old_prompt  # Replace with your transformation
    return new_prompt


# ============================================================================
# MIGRATION RUNNER (do not edit below)
# ============================================================================

def main() -> None:
    project_root = Path(__file__).parent.parent.parent
    source = project_root / SOURCE_PROMPT
    target = project_root / TARGET_PROMPT

    if not source.exists():
        print(f"ERROR: Source prompt not found: {source}", file=sys.stderr)
        sys.exit(1)

    if target.exists():
        print(f"WARNING: Target already exists: {target}")
        response = input("Overwrite? [y/N]: ").strip().lower()
        if response != "y":
            print("Aborted.")
            sys.exit(0)

    # Read source
    old_content = source.read_text()
    print(f"Read source: {source} ({len(old_content)} chars)")

    # Transform
    new_content = transform(old_content)
    print(f"Transformed: {len(old_content)} -> {len(new_content)} chars")

    # Write target
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(new_content)
    print(f"Written: {target}")

    # Log the migration
    log_entry = (
        f"{datetime.now().isoformat()} | "
        f"{SOURCE_PROMPT} -> {TARGET_PROMPT} | "
        f"{DESCRIPTION}\n"
    )
    log_file = project_root / "prompt_snapshots" / "migration_log.txt"
    log_file.parent.mkdir(parents=True, exist_ok=True)
    with open(log_file, "a") as f:
        f.write(log_entry)
    print(f"Logged to: {log_file}")

    print("\nMigration complete. Don't forget to:")
    print("  1. Update any code referencing the old prompt path")
    print("  2. Run: ./scripts/export-prompt-snapshots.sh")
    print("  3. Commit both the new prompt and the snapshot")


if __name__ == "__main__":
    main()
