#!/bin/bash
# ============================================================================
# Clear the version description tail on CLAUDE.md's `## Current Version:` line
# to a stable "(pending release notes)" placeholder.
# ============================================================================
# Usage: clear-version-description.sh X.Y.Z
#
# The auto-version-bump workflow calls this AFTER scripts/bump-version.sh has
# updated the version digits. bump-version.sh's sed is digit-only (preserves
# the description — right behavior for manual feature-PR bumps); this script
# wipes the description — right behavior for automated patch bumps between
# feature PRs, where the description would otherwise drift stale.
#
# Idempotent: running with successive versions rewrites the line cleanly each
# time; the "(pending release notes)" suffix never compounds.
# ============================================================================

set -e

VERSION="${1:-}"

if [ -z "$VERSION" ]; then
    echo "ERROR: version argument required (X.Y.Z)" >&2
    echo "Usage: $0 X.Y.Z" >&2
    exit 1
fi

if [[ ! "$VERSION" =~ ^[0-9]+\.[0-9]+\.[0-9]+$ ]]; then
    echo "ERROR: invalid version format: '$VERSION' (expected X.Y.Z)" >&2
    exit 1
fi

if [ ! -f CLAUDE.md ]; then
    echo "ERROR: CLAUDE.md not found in current directory" >&2
    exit 1
fi

# Portable in-place sed (GNU on Linux CI runner, BSD on macOS developer laptop).
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=_framework.sh
source "$SCRIPT_DIR/_framework.sh"

# Anchored to line-start `## Current Version:` so inline prose mentioning the
# phrase stays untouched. The pattern consumes the whole line tail, replacing
# both the digits and any existing description with the canonical form —
# this is what gives us idempotence across repeated auto-bumps.
sedi "s|^## Current Version: [0-9]\\{1,\\}\\.[0-9]\\{1,\\}\\.[0-9]\\{1,\\}.*$|## Current Version: $VERSION - (pending release notes)|" CLAUDE.md

# sed "matched nothing" is not an error — so verify the expected line now
# exists. Catches CRLF endings, a missing `## Current Version:` heading, or
# any future drift in the heading shape before the silent no-op ships.
if ! grep -qFx "## Current Version: $VERSION - (pending release notes)" CLAUDE.md; then
    echo "ERROR: CLAUDE.md was not updated — no line matched the expected shape" >&2
    echo "       Check for CRLF line endings, or a missing/renamed '## Current Version:' heading." >&2
    exit 1
fi

echo "Cleared version description: CLAUDE.md -> $VERSION - (pending release notes)"
