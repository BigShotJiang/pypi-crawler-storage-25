"""Tests for generate_insights.py — Claude Code Insights Dashboard."""
import json
import os
import shutil
import tempfile
import time
import unittest
from pathlib import Path


class TestLoadJsonSafe(unittest.TestCase):
    """Tests for load_json_safe() — 3-tier JSON recovery."""

    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()

    def _write(self, filename, content):
        path = Path(self.tmpdir) / filename
        path.write_text(content)
        return path

    def test_valid_json(self):
        from scripts.generate_insights import load_json_safe
        path = self._write("valid.json", '{"session_id": "abc", "outcome": "fully_achieved"}')
        result = load_json_safe(path)
        self.assertIsNotNone(result)
        self.assertEqual(result["session_id"], "abc")

    def test_control_chars_recovery(self):
        from scripts.generate_insights import load_json_safe
        content = '{"session_id": "abc",\x00 "outcome": "ok"}'
        path = self._write("ctrl.json", content)
        result = load_json_safe(path)
        self.assertIsNotNone(result)
        self.assertEqual(result["session_id"], "abc")

    def test_truncated_extra_data(self):
        from scripts.generate_insights import load_json_safe
        content = '{"session_id": "abc"}some garbage after'
        path = self._write("trunc.json", content)
        result = load_json_safe(path)
        self.assertIsNotNone(result)
        self.assertEqual(result["session_id"], "abc")

    def test_garbage_returns_none(self):
        from scripts.generate_insights import load_json_safe
        path = self._write("garbage.json", "not json at all {{{")
        result = load_json_safe(path)
        self.assertIsNone(result)

    def test_empty_file_returns_none(self):
        from scripts.generate_insights import load_json_safe
        path = self._write("empty.json", "")
        result = load_json_safe(path)
        self.assertIsNone(result)


class TestCanonicalizeProject(unittest.TestCase):
    """Tests for canonicalize_project() — worktree path normalization."""

    def test_worktree_path(self):
        from scripts.generate_insights import canonicalize_project
        path = "/home/testuser/worktrees/sample-project-session-claude-20260405-195102"
        self.assertEqual(canonicalize_project(path), "sample-project")

    def test_worktree_nested(self):
        from scripts.generate_insights import canonicalize_project
        path = "/home/testuser/projects/my-org/sample-project-session-claude-20260403-234642"
        result = canonicalize_project(path)
        self.assertNotIn("session-claude", result)

    def test_direct_project_path(self):
        from scripts.generate_insights import canonicalize_project
        path = "/home/testuser/dev-framework"
        self.assertEqual(canonicalize_project(path), "dev-framework")

    def test_empty_path(self):
        from scripts.generate_insights import canonicalize_project
        self.assertEqual(canonicalize_project(""), "(no project)")

    def test_none_path(self):
        from scripts.generate_insights import canonicalize_project
        self.assertEqual(canonicalize_project(None), "(no project)")

    def test_home_dir_path(self):
        from scripts.generate_insights import canonicalize_project
        path = "/home/testuser"
        result = canonicalize_project(path)
        self.assertEqual(result, "testuser")

    def test_claude_worktree_path(self):
        from scripts.generate_insights import canonicalize_project
        path = "/home/testuser/dev-framework/.claude/worktrees/analytics-tools-setup"
        result = canonicalize_project(path)
        self.assertEqual(result, "dev-framework")


class TestJoinData(unittest.TestCase):
    """Tests for join_data() — session-meta + facets merge."""

    def test_matching_session(self):
        from scripts.generate_insights import join_data
        metas = [{"session_id": "abc", "project_path": "/x/proj", "start_time": "2026-04-01T00:00:00Z"}]
        facets = [{"session_id": "abc", "outcome": "fully_achieved", "friction_counts": {"buggy_code": 1}}]
        result = join_data(metas, facets)
        self.assertEqual(len(result), 1)
        self.assertTrue(result[0]["has_facets"])
        self.assertEqual(result[0]["outcome"], "fully_achieved")

    def test_no_matching_facet(self):
        from scripts.generate_insights import join_data
        metas = [{"session_id": "xyz", "project_path": "/x/proj", "start_time": "2026-04-01T00:00:00Z"}]
        facets = [{"session_id": "abc", "outcome": "fully_achieved"}]
        result = join_data(metas, facets)
        self.assertEqual(len(result), 1)
        self.assertFalse(result[0]["has_facets"])

    def test_sorted_by_start_time_desc(self):
        from scripts.generate_insights import join_data
        metas = [
            {"session_id": "a", "project_path": "/x", "start_time": "2026-04-01T00:00:00Z"},
            {"session_id": "b", "project_path": "/x", "start_time": "2026-04-05T00:00:00Z"},
        ]
        result = join_data(metas, [])
        self.assertEqual(result[0]["session_id"], "b")


class TestComputeKpis(unittest.TestCase):
    """Tests for compute_kpis() — aggregate metric computation."""

    def _make_session(self, has_facets=True, outcome="fully_achieved",
                      satisfaction=None, friction=None, duration=30,
                      helpfulness="very_helpful", tool_errors=0):
        s = {
            "session_id": "test",
            "has_facets": has_facets,
            "duration_minutes": duration,
            "tool_errors": tool_errors,
            "lines_added": 100,
            "lines_removed": 10,
            "user_message_count": 5,
            "git_commits": 2,
            "message_hours": [14, 15],
        }
        if has_facets:
            s["outcome"] = outcome
            s["user_satisfaction_counts"] = satisfaction or {"satisfied": 1}
            s["friction_counts"] = friction or {}
            s["claude_helpfulness"] = helpfulness
            s["goal_categories"] = {"bug_fix": 1}
            s["session_type"] = "single_task"
        return s

    def test_outcome_counts(self):
        from scripts.generate_insights import compute_kpis
        sessions = [
            self._make_session(outcome="fully_achieved"),
            self._make_session(outcome="fully_achieved"),
            self._make_session(outcome="partially_achieved"),
            self._make_session(has_facets=False),
        ]
        kpis = compute_kpis(sessions)
        self.assertEqual(kpis["total_sessions"], 4)
        self.assertEqual(kpis["analyzed_sessions"], 3)
        self.assertEqual(kpis["outcome_counts"]["fully_achieved"], 2)
        self.assertEqual(kpis["outcome_counts"]["partially_achieved"], 1)

    def test_satisfaction_net_score(self):
        from scripts.generate_insights import compute_kpis
        sessions = [
            self._make_session(satisfaction={"satisfied": 10, "frustrated": 2}),
            self._make_session(satisfaction={"happy": 5, "dissatisfied": 3}),
        ]
        kpis = compute_kpis(sessions)
        # positive = 10 + 5 = 15, negative = 2 + 3 = 5, total = 20
        # net = (15 - 5) / 20 * 100 = 50.0
        self.assertAlmostEqual(kpis["satisfaction_net_score"], 50.0, places=1)

    def test_friction_totals(self):
        from scripts.generate_insights import compute_kpis
        sessions = [
            self._make_session(friction={"buggy_code": 3, "wrong_approach": 2}),
            self._make_session(friction={"buggy_code": 1}),
        ]
        kpis = compute_kpis(sessions)
        self.assertEqual(kpis["friction_totals"]["buggy_code"], 4)
        self.assertEqual(kpis["friction_totals"]["wrong_approach"], 2)

    def test_no_facets_sessions(self):
        from scripts.generate_insights import compute_kpis
        sessions = [self._make_session(has_facets=False)]
        kpis = compute_kpis(sessions)
        self.assertEqual(kpis["analyzed_sessions"], 0)
        self.assertEqual(kpis["satisfaction_net_score"], 0)

    def test_satisfaction_likely_satisfied(self):
        from scripts.generate_insights import compute_kpis
        sessions = [
            self._make_session(satisfaction={"likely_satisfied": 8, "frustrated": 2}),
        ]
        kpis = compute_kpis(sessions)
        # positive = 8, negative = 2, total = 10
        # net = (8 - 2) / 10 * 100 = 60.0
        self.assertAlmostEqual(kpis["satisfaction_net_score"], 60.0, places=1)

    def test_wilson_ci_in_kpis(self):
        from scripts.generate_insights import compute_kpis
        sessions = [self._make_session() for _ in range(20)]
        kpis = compute_kpis(sessions)
        self.assertIn("wilson_ci_lower", kpis)
        self.assertIn("wilson_ci_upper", kpis)
        self.assertGreater(kpis["wilson_ci_upper"], kpis["wilson_ci_lower"])
        # 20/20 fully_achieved → CI should be high
        self.assertGreater(kpis["wilson_ci_lower"], 70)


class TestGoalNormalization(unittest.TestCase):
    """Tests for goal taxonomy normalization."""

    def test_bug_fix_variants(self):
        from scripts.generate_insights import normalize_goal
        for variant in ['bug_fixing', 'code_fix', 'debug_fix_bug', 'debugging',
                        'debugging_investigation']:
            self.assertEqual(normalize_goal(variant), 'bug_fix',
                             f"{variant} should normalize to bug_fix")

    def test_git_operations_variants(self):
        from scripts.generate_insights import normalize_goal
        for variant in ['merge_pr', 'branch_management', 'commit_and_pr']:
            self.assertEqual(normalize_goal(variant), 'git_operations')

    def test_canonical_passthrough(self):
        from scripts.generate_insights import normalize_goal
        self.assertEqual(normalize_goal('bug_fix'), 'bug_fix')
        self.assertEqual(normalize_goal('status_check'), 'status_check')

    def test_unknown_passthrough(self):
        from scripts.generate_insights import normalize_goal
        self.assertEqual(normalize_goal('some_new_category'), 'some_new_category')

    def test_normalization_in_join_data(self):
        from scripts.generate_insights import join_data
        metas = [{"session_id": "t1", "project_path": "/x/proj", "start_time": "2026-04-01T00:00:00Z"}]
        facets = [{"session_id": "t1", "outcome": "fully_achieved",
                   "goal_categories": {"debugging": 2, "bug_fix": 1},
                   "user_satisfaction_counts": {"satisfied": 1},
                   "friction_counts": {}, "claude_helpfulness": "very_helpful",
                   "session_type": "single_task"}]
        result = join_data(metas, facets)
        # debugging (2) + bug_fix (1) should merge to bug_fix (3)
        self.assertEqual(result[0]["goal_categories"].get("bug_fix", 0), 3)
        self.assertNotIn("debugging", result[0]["goal_categories"])


class TestGenerateInsights(unittest.TestCase):
    """Tests for generate_insights() — algorithmic micro-insight generation."""

    def test_at_least_five_insights(self):
        from scripts.generate_insights import generate_insights
        # Build realistic data — 20 analyzed + 10 unanalyzed to meet raised thresholds
        sessions = []
        for i in range(20):
            sessions.append({
                "session_id": f"s{i}",
                "has_facets": True,
                "outcome": "fully_achieved" if i < 14 else "not_achieved",
                "user_satisfaction_counts": {"satisfied": 1} if i < 14 else {"frustrated": 1},
                "friction_counts": {"wrong_approach": 1} if i % 3 == 0 else {},
                "claude_helpfulness": "very_helpful" if i < 14 else "slightly_helpful",
                "goal_categories": {"bug_fix": 1},
                "session_type": "single_task",
                "duration_minutes": 30 + i * 5,
                "tool_errors": i,
                "canonical_project": "test-project",
                "start_time": f"2026-04-{(i % 28) + 1:02d}T12:00:00Z",
                "message_hours": [14],
                "lines_added": 50,
                "lines_removed": 5,
                "user_message_count": 3,
                "git_commits": 1,
            })
        # Add unanalyzed sessions for coverage gap insight
        for i in range(10):
            sessions.append({
                "session_id": f"nf{i}",
                "has_facets": False,
                "duration_minutes": 10,
                "tool_errors": 0,
                "canonical_project": "test-project",
                "start_time": f"2026-04-{(i % 28) + 1:02d}T12:00:00Z",
                "message_hours": [10],
                "lines_added": 10,
                "lines_removed": 1,
                "user_message_count": 1,
                "git_commits": 0,
            })

        from scripts.generate_insights import compute_kpis, compute_trends, compute_project_breakdown
        kpis = compute_kpis(sessions)
        trends = compute_trends(sessions)
        projects = compute_project_breakdown(sessions)
        insights = generate_insights(kpis, trends, projects, sessions)

        self.assertGreaterEqual(len(insights), 5)
        for insight in insights:
            self.assertIn("category", insight)
            self.assertIn("text", insight)
            self.assertIn("priority", insight)
            self.assertIn("icon", insight)

    def test_friction_hotspot_fires(self):
        from scripts.generate_insights import _insight_friction_hotspot
        friction_totals = {"wrong_approach": 20, "buggy_code": 5, "other": 3}
        result = _insight_friction_hotspot(friction_totals)
        self.assertIsNotNone(result)
        self.assertIn("wrong_approach", result["text"])

    def test_friction_hotspot_none_when_even(self):
        from scripts.generate_insights import _insight_friction_hotspot
        friction_totals = {"a": 10, "b": 10, "c": 10}
        result = _insight_friction_hotspot(friction_totals)
        self.assertIsNone(result)


class TestBuildHtml(unittest.TestCase):
    """Tests for build_html() — HTML output structure."""

    def test_contains_doctype(self):
        from scripts.generate_insights import build_html
        html = build_html('{"test": true}')
        self.assertTrue(html.startswith("<!DOCTYPE html>"))

    def test_contains_data(self):
        from scripts.generate_insights import build_html
        html = build_html('{"test_marker": "hello_world"}')
        self.assertIn("hello_world", html)

    def test_contains_chart_js(self):
        from scripts.generate_insights import build_html
        html = build_html('{}')
        self.assertIn("chart.js", html.lower())

    def test_contains_frappe(self):
        from scripts.generate_insights import build_html
        html = build_html('{}')
        self.assertIn("frappe-charts", html)

    def test_contains_filter_controls(self):
        from scripts.generate_insights import build_html
        html = build_html('{}')
        self.assertIn("7D", html)
        self.assertIn("30D", html)
        self.assertIn("90D", html)


class TestEndToEnd(unittest.TestCase):
    """Smoke test against real data."""

    def test_full_pipeline(self):
        meta_dir = Path(os.path.expanduser("~/.claude/usage-data/session-meta"))
        facets_dir = Path(os.path.expanduser("~/.claude/usage-data/facets"))
        if not meta_dir.exists() or not facets_dir.exists():
            self.skipTest("Real data not available")

        from scripts.generate_insights import (
            load_session_metas, load_facets, load_stats_cache, join_data,
            compute_kpis, compute_trends, compute_project_breakdown,
            generate_insights, build_payload, build_html, STATS_CACHE
        )

        metas, meta_errors = load_session_metas(meta_dir)
        facets, facet_errors = load_facets(facets_dir)
        stats_cache = load_stats_cache(STATS_CACHE)

        self.assertGreaterEqual(len(metas), 100)
        self.assertGreaterEqual(len(facets), 40)

        sessions = join_data(metas, facets)
        self.assertGreater(len(sessions), 0)

        kpis = compute_kpis(sessions)
        self.assertIn("total_sessions", kpis)
        self.assertIn("satisfaction_net_score", kpis)

        trends = compute_trends(sessions)
        self.assertIn("dates", trends)

        projects = compute_project_breakdown(sessions)
        self.assertGreater(len(projects), 0)

        insights = generate_insights(kpis, trends, projects, sessions)
        self.assertGreaterEqual(len(insights), 5)

        meta = {"generated_at": "2026-04-08", "meta_errors": meta_errors, "facet_errors": facet_errors}
        payload = build_payload(sessions, kpis, trends, projects, insights, meta,
                                stats_cache=stats_cache)
        self.assertIn("data_coverage", payload)
        self.assertIn("stats_cache", payload)
        if stats_cache:
            self.assertTrue(payload["data_coverage"]["has_stats_cache"])
            self.assertGreater(payload["data_coverage"]["stats_cache_total_sessions"], 0)

        payload_json = json.dumps(payload, default=str)
        html = build_html(payload_json)

        self.assertTrue(html.startswith("<!DOCTYPE html>"))
        self.assertLess(len(html), 2 * 1024 * 1024)  # < 2MB
        # Verify historical section is referenced
        self.assertIn("historicalSection", html)
        self.assertIn("coverageBanner", html)


class TestComputeKpisAggregates(unittest.TestCase):
    """Tests for new tool/language/session-type aggregates in compute_kpis."""

    def _make_session(self, tool_counts=None, languages=None, session_type="single_task",
                      has_facets=True, primary_success=""):
        s = {
            "session_id": "test",
            "has_facets": has_facets,
            "duration_minutes": 30,
            "tool_errors": 0,
            "lines_added": 100,
            "lines_removed": 10,
            "user_message_count": 5,
            "git_commits": 2,
            "message_hours": [14],
            "tool_counts": tool_counts or {},
            "languages": languages or {},
        }
        if has_facets:
            s["outcome"] = "fully_achieved"
            s["user_satisfaction_counts"] = {"satisfied": 1}
            s["friction_counts"] = {}
            s["claude_helpfulness"] = "very_helpful"
            s["goal_categories"] = {"bug_fix": 1}
            s["session_type"] = session_type
            s["primary_success"] = primary_success
        return s

    def test_tool_totals_aggregated(self):
        from scripts.generate_insights import compute_kpis
        sessions = [
            self._make_session(tool_counts={"Bash": 50, "Read": 30}),
            self._make_session(tool_counts={"Bash": 20, "Edit": 10}),
        ]
        kpis = compute_kpis(sessions)
        self.assertIn("tool_totals", kpis)
        self.assertEqual(kpis["tool_totals"]["Bash"], 70)
        self.assertEqual(kpis["tool_totals"]["Read"], 30)
        self.assertEqual(kpis["tool_totals"]["Edit"], 10)

    def test_language_totals_aggregated(self):
        from scripts.generate_insights import compute_kpis
        sessions = [
            self._make_session(languages={"TypeScript": 200, "Python": 50}),
            self._make_session(languages={"TypeScript": 100, "Shell": 30}),
        ]
        kpis = compute_kpis(sessions)
        self.assertIn("language_totals", kpis)
        self.assertEqual(kpis["language_totals"]["TypeScript"], 300)
        self.assertEqual(kpis["language_totals"]["Python"], 50)

    def test_session_type_counts(self):
        from scripts.generate_insights import compute_kpis
        sessions = [
            self._make_session(session_type="multi_task"),
            self._make_session(session_type="multi_task"),
            self._make_session(session_type="single_task"),
        ]
        kpis = compute_kpis(sessions)
        self.assertIn("session_type_counts", kpis)
        self.assertEqual(kpis["session_type_counts"]["multi_task"], 2)
        self.assertEqual(kpis["session_type_counts"]["single_task"], 1)


class TestNewNarrativeSections(unittest.TestCase):
    """Tests that new narrative sections have well-formed prompts and schemas."""

    def _validate_schema(self, schema):
        """Assert a schema has required structure: type, properties, required, additionalProperties."""
        self.assertEqual(schema["type"], "object")
        self.assertIn("properties", schema)
        self.assertIn("required", schema)
        self.assertGreater(len(schema["required"]), 0)
        self.assertFalse(schema.get("additionalProperties", True))
        # All required keys must exist in properties
        for key in schema["required"]:
            self.assertIn(key, schema["properties"],
                          f"Required key '{key}' missing from properties")

    def test_what_you_work_on_schema(self):
        from scripts.generate_insights import NARRATIVE_PROMPTS
        self.assertIn("what_you_work_on", NARRATIVE_PROMPTS)
        config = NARRATIVE_PROMPTS["what_you_work_on"]
        self.assertIn("instruction", config)
        self._validate_schema(config["schema"])
        self.assertIn("projects", config["schema"]["properties"])

    def test_impressive_things_schema(self):
        from scripts.generate_insights import NARRATIVE_PROMPTS
        self.assertIn("impressive_things", NARRATIVE_PROMPTS)
        config = NARRATIVE_PROMPTS["impressive_things"]
        self.assertIn("instruction", config)
        self._validate_schema(config["schema"])
        self.assertIn("achievements", config["schema"]["properties"])
        self.assertIn("what_helped_most", config["schema"]["properties"])

    def test_features_to_try_schema(self):
        from scripts.generate_insights import NARRATIVE_PROMPTS
        self.assertIn("features_to_try", NARRATIVE_PROMPTS)
        config = NARRATIVE_PROMPTS["features_to_try"]
        self.assertIn("instruction", config)
        self._validate_schema(config["schema"])
        self.assertIn("features", config["schema"]["properties"])

    def test_new_usage_patterns_schema(self):
        from scripts.generate_insights import NARRATIVE_PROMPTS
        self.assertIn("new_usage_patterns", NARRATIVE_PROMPTS)
        config = NARRATIVE_PROMPTS["new_usage_patterns"]
        self.assertIn("instruction", config)
        self._validate_schema(config["schema"])
        self.assertIn("patterns", config["schema"]["properties"])

    def test_all_prompts_have_valid_schemas(self):
        from scripts.generate_insights import NARRATIVE_PROMPTS
        for name, config in NARRATIVE_PROMPTS.items():
            with self.subTest(section=name):
                self.assertIn("instruction", config, f"{name} missing instruction")
                self.assertIn("schema", config, f"{name} missing schema")
                self._validate_schema(config["schema"])


class TestNewHtmlSections(unittest.TestCase):
    """Tests that HTML output contains new narrative section containers."""

    def test_html_contains_new_section_divs(self):
        from scripts.generate_insights import build_html
        html = build_html('{}')
        self.assertIn("narrativeWorkOn", html)
        self.assertIn("narrativeImpressive", html)
        self.assertIn("narrativeFeatures", html)
        self.assertIn("narrativePatterns", html)

    def test_html_contains_new_section_render_code(self):
        from scripts.generate_insights import build_html
        html = build_html('{}')
        self.assertIn("what_you_work_on", html)
        self.assertIn("impressive_things", html)
        self.assertIn("features_to_try", html)
        self.assertIn("new_usage_patterns", html)


class TestDataSummaryEnriched(unittest.TestCase):
    """Tests that _build_data_summary includes tool/language/session data."""

    def test_summary_includes_tools_and_languages(self):
        from scripts.generate_insights import _build_data_summary
        kpis = {
            "total_sessions": 10, "analyzed_sessions": 8,
            "outcome_counts": {"fully_achieved": 6},
            "satisfaction_net_score": 50.0,
            "satisfaction_positive": 8, "satisfaction_negative": 2, "satisfaction_neutral": 0,
            "friction_totals": {}, "total_friction": 0,
            "helpfulness_counts": {"very_helpful": 5},
            "goal_totals": {"bug_fix": 3},
            "avg_duration": 30.0,
            "total_lines_added": 500, "total_lines_removed": 50, "total_commits": 10,
            "tool_totals": {"Bash": 100, "Read": 50, "Edit": 30},
            "language_totals": {"TypeScript": 300, "Python": 50},
            "session_type_counts": {"multi_task": 5, "single_task": 3},
        }
        trends = {"dates": ["2026-04-01", "2026-04-08"]}
        projects = {}
        sessions = []
        summary = _build_data_summary(kpis, trends, projects, sessions)
        self.assertIn("top_tools", summary)
        self.assertIn("Bash", summary)
        self.assertIn("languages", summary)
        self.assertIn("TypeScript", summary)
        self.assertIn("session_types", summary)


class TestFwDiscovery(unittest.TestCase):
    """Tests for framework project discovery + cache (AC-1, 2, 3, 7)."""

    def setUp(self):
        # Resolve to handle macOS /var → /private/var symlink (Path.resolve()
        # in discover_fw_projects would otherwise produce mismatched paths).
        self.tmpdir = Path(tempfile.mkdtemp()).resolve()
        self.fake_home = self.tmpdir / "home"
        self.fake_home.mkdir()
        self.cache_path = self.tmpdir / "fw-project-paths.json"

    def _make_fw_project(self, rel_path):
        """Create a fake framework project with config/framework.yaml."""
        proj = self.fake_home / rel_path
        (proj / "config").mkdir(parents=True)
        (proj / "config" / "framework.yaml").write_text("project:\n  name: test\n")
        return proj

    def test_first_run_writes_cache(self):
        from scripts.generate_insights import discover_fw_projects, save_fw_projects_cache
        proj1 = self._make_fw_project("dev-framework")
        proj2 = self._make_fw_project("templates-dev")

        discovered = discover_fw_projects(home=self.fake_home)
        save_fw_projects_cache(discovered, cache_path=self.cache_path)

        self.assertEqual(set(discovered), {proj1, proj2})
        self.assertTrue(self.cache_path.exists())
        cache_data = json.loads(self.cache_path.read_text())
        self.assertIn("paths", cache_data)
        self.assertIn("discovered_at", cache_data)
        self.assertEqual(set(cache_data["paths"]), {str(proj1), str(proj2)})

    def test_cache_load_skips_rescan(self):
        from scripts.generate_insights import load_fw_projects_cache
        proj1 = self._make_fw_project("dev-framework")
        proj2 = self._make_fw_project("templates-dev")
        cache_payload = {
            "discovered_at": "2026-04-10T00:00:00Z",
            "paths": [str(proj1), str(proj2)],
        }
        self.cache_path.write_text(json.dumps(cache_payload))

        loaded = load_fw_projects_cache(cache_path=self.cache_path)
        self.assertIsNotNone(loaded)
        self.assertEqual(set(loaded), {proj1, proj2})

    def test_cache_missing_returns_none(self):
        from scripts.generate_insights import load_fw_projects_cache
        loaded = load_fw_projects_cache(cache_path=self.cache_path)
        self.assertIsNone(loaded)

    def test_cache_malformed_returns_none(self):
        from scripts.generate_insights import load_fw_projects_cache
        self.cache_path.write_text("not json {{{")
        loaded = load_fw_projects_cache(cache_path=self.cache_path)
        self.assertIsNone(loaded)

    def test_stale_cache_paths_pruned(self):
        from scripts.generate_insights import load_fw_projects_cache
        proj1 = self._make_fw_project("dev-framework")
        gone = self.fake_home / "deleted-project"
        cache_payload = {
            "discovered_at": "2026-04-10T00:00:00Z",
            "paths": [str(proj1), str(gone)],
        }
        self.cache_path.write_text(json.dumps(cache_payload))
        original_mtime = self.cache_path.stat().st_mtime

        loaded = load_fw_projects_cache(cache_path=self.cache_path)
        self.assertEqual(loaded, [proj1])
        # Cache file is NOT rewritten (rewrite only happens on --refresh)
        self.assertEqual(self.cache_path.stat().st_mtime, original_mtime)

    def test_discovery_skips_heavy_dirs(self):
        from scripts.generate_insights import discover_fw_projects
        real_proj = self._make_fw_project("real-project")
        # Plant a fake framework.yaml inside every skip-listed dirname so
        # the test fails if any one of them is removed from the skip set.
        for skip in ("node_modules", ".git", ".venv", "__pycache__",
                     ".pnpm-store", ".yarn", "bower_components"):
            buried = self.fake_home / "noise" / skip / "fake-project"
            (buried / "config").mkdir(parents=True)
            (buried / "config" / "framework.yaml").write_text("ignored")

        discovered = discover_fw_projects(home=self.fake_home)
        self.assertEqual(discovered, [real_proj])

    def test_discovery_does_not_follow_symlinks(self):
        # A symlink that points back into the tree must not cause infinite
        # recursion or duplicate discovery (followlinks=False is explicit).
        from scripts.generate_insights import discover_fw_projects
        real_proj = self._make_fw_project("real-project")
        # Symlink real-project under a different path; followlinks=False
        # should mean discover_fw_projects ignores the symlinked entry.
        link_target = self.fake_home / "alias" / "real-project-link"
        link_target.parent.mkdir(parents=True)
        link_target.symlink_to(real_proj)

        discovered = discover_fw_projects(home=self.fake_home)
        self.assertEqual(discovered, [real_proj])

    def test_discovery_respects_max_depth(self):
        from scripts.generate_insights import discover_fw_projects
        shallow = self._make_fw_project("a/b/shallow")
        too_deep = self._make_fw_project("a/b/c/d/deep")

        discovered = discover_fw_projects(home=self.fake_home, max_depth=3)
        self.assertIn(shallow, discovered)
        self.assertNotIn(too_deep, discovered)

    # ------------------------------------------------------------------
    # AC-5: discover_fw_projects_with_skipped surfaces parse-failure
    # candidates rather than silently dropping them.
    # ------------------------------------------------------------------

    def test_ac5_happy_path_returns_found_and_empty_skipped(self):
        """AC-5: well-formed framework.yaml → found, skipped empty."""
        from scripts.generate_insights import discover_fw_projects_with_skipped
        proj = self._make_fw_project("ok-project")
        result = discover_fw_projects_with_skipped(home=self.fake_home)
        assert isinstance(result, dict)
        assert "found" in result and "skipped" in result
        assert proj in result["found"]
        assert result["skipped"] == []

    def test_ac5_corrupt_yaml_is_skipped_with_reason(self):
        """AC-5: a project whose framework.yaml is malformed appears
        under skipped with a reason, NOT silently dropped.
        """
        from scripts.generate_insights import discover_fw_projects_with_skipped
        # Create a project whose framework.yaml is corrupt
        bad_proj = self.fake_home / "bad-yaml-project"
        (bad_proj / "config").mkdir(parents=True)
        (bad_proj / "config" / "framework.yaml").write_text(
            "this: is: : : not valid\n\t@#$%^\n\n- unbalanced: [\n"
        )

        result = discover_fw_projects_with_skipped(home=self.fake_home)
        skipped_paths = [entry["path"] for entry in result["skipped"]]
        assert str(bad_proj) in skipped_paths, (
            f"Corrupt framework.yaml must surface under skipped; got "
            f"skipped={result['skipped']}"
        )
        # Reason must be a non-empty string
        entry = next(e for e in result["skipped"] if e["path"] == str(bad_proj))
        assert isinstance(entry["reason"], str)
        assert len(entry["reason"]) > 0


class TestFwAggregation(unittest.TestCase):
    """Tests for per-project loading + cross-project aggregation (AC-4, AC-6)."""

    def setUp(self):
        self.tmpdir = Path(tempfile.mkdtemp()).resolve()

    def _make_project_with_metrics(self, name, events, scorecards=None):
        """Create a fake project with .context/metrics/events.jsonl + scorecards."""
        proj = self.tmpdir / name
        metrics = proj / ".context" / "metrics"
        metrics.mkdir(parents=True)
        (proj / "config").mkdir()
        (proj / "config" / "framework.yaml").write_text("project:\n  name: " + name + "\n")
        events_file = metrics / "events-2026-04.jsonl"
        events_file.write_text("\n".join(json.dumps(e) for e in events))
        if scorecards:
            scorecard_dir = metrics / "conformance"
            scorecard_dir.mkdir()
            for i, sc in enumerate(scorecards):
                (scorecard_dir / f"scorecard-{i}.json").write_text(json.dumps(sc))
        return proj

    def _safety_block_event(self, reason="rm-rf"):
        return {"ts": "2026-04-10T12:00:00", "category": "safety",
                "event": "block", "data": {"reason": reason}, "sid": "s1"}

    def _safety_approve_event(self):
        return {"ts": "2026-04-10T12:01:00", "category": "safety",
                "event": "approve", "data": {}, "sid": "s1"}

    def test_load_project_metrics_returns_dict(self):
        from scripts.generate_insights import load_fw_project_metrics
        proj = self._make_project_with_metrics("dev-framework", [
            self._safety_block_event(), self._safety_approve_event(),
        ])
        result = load_fw_project_metrics(proj)
        self.assertIsNotNone(result)
        self.assertEqual(result["name"], "dev-framework")
        self.assertEqual(result["path"], str(proj))
        self.assertEqual(result["safety"]["total_blocks"], 1)
        self.assertEqual(result["safety"]["total_approvals"], 1)

    def test_load_project_metrics_missing_dir_returns_none(self):
        from scripts.generate_insights import load_fw_project_metrics
        proj = self.tmpdir / "empty-project"
        (proj / "config").mkdir(parents=True)
        (proj / "config" / "framework.yaml").write_text("x")
        self.assertIsNone(load_fw_project_metrics(proj))

    def test_aggregate_empty_returns_none(self):
        from scripts.generate_insights import aggregate_fw_stats
        self.assertIsNone(aggregate_fw_stats([]))

    def test_aggregate_groups_worktrees_by_canonical_name(self):
        # Worktree rollup: dev-framework + dev-framework-session-claude-* → "dev-framework"
        from scripts.generate_insights import load_fw_project_metrics, aggregate_fw_stats
        main_proj = self._make_project_with_metrics(
            "dev-framework", [self._safety_block_event()])
        worktree = self._make_project_with_metrics(
            "dev-framework-session-claude-20260410-005743",
            [self._safety_block_event(), self._safety_block_event()])
        other = self._make_project_with_metrics(
            "templates-dev", [self._safety_approve_event()])

        metrics = [
            load_fw_project_metrics(main_proj),
            load_fw_project_metrics(worktree),
            load_fw_project_metrics(other),
        ]
        result = aggregate_fw_stats(metrics)

        names = sorted(p["name"] for p in result["projects"])
        self.assertEqual(names, ["dev-framework", "templates-dev"])

        dev_fw = next(p for p in result["projects"] if p["name"] == "dev-framework")
        self.assertEqual(dev_fw["worktree_count"], 2)  # main + 1 worktree
        self.assertEqual(dev_fw["safety"]["total_blocks"], 3)  # 1 + 2

        templates = next(p for p in result["projects"] if p["name"] == "templates-dev")
        self.assertEqual(templates["worktree_count"], 1)
        self.assertEqual(templates["safety"]["total_approvals"], 1)

        self.assertEqual(result["aggregate"]["project_count"], 2)
        self.assertEqual(result["aggregate"]["worktree_count"], 3)
        self.assertEqual(result["aggregate"]["safety"]["total_blocks"], 3)
        self.assertEqual(result["aggregate"]["safety"]["total_approvals"], 1)

    def test_aggregate_includes_conformance_scorecards(self):
        from scripts.generate_insights import load_fw_project_metrics, aggregate_fw_stats
        proj = self._make_project_with_metrics(
            "dev-framework",
            [self._safety_approve_event()],
            scorecards=[
                {"schema_version": 2, "timestamp": "2026-04-09T00:00:00", "composite_score": 0.92,
                 "components": {"file_coverage": 1.0, "ac_coverage": 0.85}},
                {"schema_version": 2, "timestamp": "2026-04-10T00:00:00", "composite_score": 0.88,
                 "components": {"file_coverage": 0.9, "ac_coverage": 0.85}},
            ])
        result = aggregate_fw_stats([load_fw_project_metrics(proj)])
        dev = result["projects"][0]
        self.assertEqual(dev["conformance"]["count"], 2)
        self.assertAlmostEqual(dev["conformance"]["avg_composite"], 0.90, places=2)


class TestFwPayload(unittest.TestCase):
    """Tests for build_payload framework_stats integration (AC-4)."""

    def _minimal_kpis(self):
        return {
            "total_sessions": 0, "analyzed_sessions": 0,
            "outcome_counts": {}, "satisfaction_net_score": 0,
            "satisfaction_positive": 0, "satisfaction_negative": 0,
            "satisfaction_neutral": 0, "friction_totals": {}, "total_friction": 0,
            "helpfulness_counts": {}, "goal_totals": {}, "avg_duration": 0.0,
            "total_lines_added": 0, "total_lines_removed": 0, "total_commits": 0,
            "tool_totals": {}, "language_totals": {}, "session_type_counts": {},
        }

    def test_payload_includes_framework_stats_when_provided(self):
        from scripts.generate_insights import build_payload
        framework_stats = {
            "projects": [
                {"name": "dev-framework", "worktree_count": 5,
                 "safety": {"total_blocks": 3}, "cost_routing": {},
                 "conformance": {}, "protocol": {}, "sessions": {}}
            ],
            "aggregate": {
                "project_count": 1, "worktree_count": 5,
                "safety": {"total_blocks": 3}, "cost_routing": {},
                "conformance": {}, "protocol": {}, "sessions": {},
            },
        }
        payload = build_payload([], self._minimal_kpis(), {"dates": []},
                                 {}, [], {}, framework_stats=framework_stats)
        self.assertIn("framework_stats", payload)
        self.assertIsNotNone(payload["framework_stats"])
        self.assertEqual(payload["framework_stats"]["aggregate"]["project_count"], 1)
        self.assertEqual(len(payload["framework_stats"]["projects"]), 1)

    def test_payload_framework_stats_none_when_omitted(self):
        from scripts.generate_insights import build_payload
        payload = build_payload([], self._minimal_kpis(), {"dates": []},
                                 {}, [], {})
        self.assertIn("framework_stats", payload)
        self.assertIsNone(payload["framework_stats"])


class TestFwHtml(unittest.TestCase):
    """Tests for HTML rendering of the framework-stats section (AC-5)."""

    def test_html_contains_framework_stats_section(self):
        from scripts.generate_insights import build_html
        html = build_html('{}')
        # Server-side placeholder div + heading text
        self.assertIn('id="frameworkStats"', html)
        self.assertIn("Framework Stats", html)

    def test_html_contains_framework_stats_render_code(self):
        from scripts.generate_insights import build_html
        html = build_html('{}')
        # Client-side render function referenced
        self.assertIn("renderFrameworkStats", html)
        # Reads framework_stats from the payload
        self.assertIn("framework_stats", html)

    def test_ac6_sessions_table_has_session_id_column(self):
        """AC-6: Sessions table includes a Session ID column header."""
        from scripts.generate_insights import build_html
        html = build_html('{}')
        self.assertIn(">Session ID<", html, (
            "Sessions table must expose session_id as a visible column so "
            "users can drill from session row → plan/events detail."
        ))

    def test_ac6_framework_stats_uses_details_for_drilldown(self):
        """AC-6: renderFrameworkStats wraps each project row in a <details>
        element so the user can click-expand per-project detail.
        """
        from scripts.generate_insights import build_html
        html = build_html('{}')
        # The render function source must emit a <details> element for each
        # project. We assert the string pattern is emitted by the JS body.
        self.assertIn("<details", html, (
            "Project rows must use native <details>/<summary> for drill-down "
            "(see AC-6 in .sherlock-plan.md)."
        ))

    def test_ac7_insights_dashboard_disclaims_measurement_only(self):
        """AC-7: Conformance section disclaims 'measurement only — do not
        gate merges or deployments on this aggregate.'
        """
        from scripts.generate_insights import build_html
        html = build_html('{}')
        self.assertIn(
            "Measurement only \u2014 do not gate merges or deployments",
            html,
            (
                "Per AC-7, the insights conformance surface must render an "
                "explicit measurement-only disclaimer so operators do not "
                "treat the composite as a CI gate."
            ),
        )


class TestFwCacheAge(unittest.TestCase):
    """Tests for fw_projects_cache_age_days."""

    def setUp(self):
        self.tmpdir = Path(tempfile.mkdtemp())

    def tearDown(self):
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_returns_none_when_cache_missing(self):
        from scripts.generate_insights import fw_projects_cache_age_days
        missing = self.tmpdir / "no-such-cache.json"
        self.assertIsNone(fw_projects_cache_age_days(missing))

    def test_returns_age_in_days_for_known_cache(self):
        from scripts.generate_insights import fw_projects_cache_age_days
        from datetime import datetime, timezone, timedelta
        cache = self.tmpdir / "cache.json"
        five_days_ago = (datetime.now(timezone.utc) - timedelta(days=5)).isoformat()
        cache.write_text(json.dumps({
            "discovered_at": five_days_ago,
            "paths": ["/some/project"],
        }))
        age = fw_projects_cache_age_days(cache)
        self.assertIsNotNone(age)
        self.assertGreater(age, 4.5)
        self.assertLess(age, 5.5)

    def test_returns_none_on_malformed_timestamp(self):
        from scripts.generate_insights import fw_projects_cache_age_days
        cache = self.tmpdir / "cache.json"
        cache.write_text(json.dumps({"discovered_at": "not-a-date", "paths": []}))
        self.assertIsNone(fw_projects_cache_age_days(cache))


class TestSessionMetaFreshness(unittest.TestCase):
    """Tests for check_session_meta_freshness."""

    def setUp(self):
        self.tmpdir = Path(tempfile.mkdtemp())

    def tearDown(self):
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_missing_dir_is_stale(self):
        from scripts.generate_insights import check_session_meta_freshness
        missing = self.tmpdir / "does-not-exist"
        result = check_session_meta_freshness(missing)
        self.assertTrue(result["stale"])
        self.assertEqual(result["file_count"], 0)
        self.assertIsNone(result["latest_mtime"])

    def test_empty_dir_is_stale(self):
        from scripts.generate_insights import check_session_meta_freshness
        empty = self.tmpdir / "empty-meta"
        empty.mkdir()
        result = check_session_meta_freshness(empty)
        self.assertTrue(result["stale"])
        self.assertEqual(result["file_count"], 0)

    def test_recent_file_is_not_stale(self):
        from scripts.generate_insights import check_session_meta_freshness
        meta = self.tmpdir / "meta"
        meta.mkdir()
        (meta / "session.json").write_text("{}")
        result = check_session_meta_freshness(meta, stale_hours=24.0)
        self.assertFalse(result["stale"])
        self.assertGreaterEqual(result["file_count"], 1)
        self.assertIsNotNone(result["latest_mtime"])
        self.assertIsNotNone(result["age_hours"])
        self.assertLess(result["age_hours"], 1.0)

    def test_stale_file_is_flagged(self):
        """A file older than stale_hours triggers the stale flag."""
        import os
        from scripts.generate_insights import check_session_meta_freshness
        meta = self.tmpdir / "meta"
        meta.mkdir()
        f = meta / "old.json"
        f.write_text("{}")
        # Mark as 48h old
        two_days_ago = time.time() - 48 * 3600
        os.utime(f, (two_days_ago, two_days_ago))
        result = check_session_meta_freshness(meta, stale_hours=24.0)
        self.assertTrue(result["stale"])
        self.assertGreater(result["age_hours"], 24.0)


if __name__ == "__main__":
    unittest.main()
