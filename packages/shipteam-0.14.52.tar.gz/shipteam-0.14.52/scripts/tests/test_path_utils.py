"""Tests for the path_utils module (.claude/hooks/path_utils.py).

Covers path resolution, config reading, git helpers, and session lock helpers.
"""

import json
import os
import sys
import time
from datetime import datetime, timedelta
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent / ".claude" / "hooks"))

import path_utils
from path_utils import (
    STALE_TIMEOUT_SECONDS,
    GIT_ENV,
    detect_worktree,
    get_claude_dir,
    get_config,
    get_current_branch,
    get_project_root,
    get_state_dir,
    is_lock_stale,
    is_process_alive,
    read_session_lock,
    _parse_config_fallback,
    _parse_config_yaml,
)


def _reset_config_cache():
    """Reset module-level config cache between tests."""
    path_utils._config_cache = {}


# ---------------------------------------------------------------------------
# detect_worktree — uses Path.cwd(), so we monkeypatch chdir
# ---------------------------------------------------------------------------

class TestDetectWorktree:
    def test_git_is_directory_returns_false(self, tmp_path, monkeypatch):
        (tmp_path / ".git").mkdir()
        monkeypatch.chdir(tmp_path)
        assert detect_worktree() is False

    def test_git_is_file_with_gitdir_returns_true(self, tmp_path, monkeypatch):
        (tmp_path / ".git").write_text("gitdir: /some/path/.git/worktrees/mybranch\n")
        monkeypatch.chdir(tmp_path)
        assert detect_worktree() is True

    def test_git_does_not_exist_returns_false(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        assert detect_worktree() is False

    def test_git_file_without_gitdir_returns_false(self, tmp_path, monkeypatch):
        (tmp_path / ".git").write_text("not a gitdir pointer\n")
        monkeypatch.chdir(tmp_path)
        assert detect_worktree() is False


# ---------------------------------------------------------------------------
# get_project_root
# ---------------------------------------------------------------------------

class TestGetProjectRoot:
    def test_finds_git_in_current_dir(self, tmp_path, monkeypatch):
        (tmp_path / ".git").mkdir()
        monkeypatch.chdir(tmp_path)
        assert get_project_root() == tmp_path

    def test_finds_git_in_parent_dir(self, tmp_path, monkeypatch):
        (tmp_path / ".git").mkdir()
        child = tmp_path / "subdir"
        child.mkdir()
        monkeypatch.chdir(child)
        assert get_project_root() == tmp_path

    def test_falls_back_to_cwd_when_no_git(self, tmp_path, monkeypatch):
        isolated = tmp_path / "no_git"
        isolated.mkdir()
        monkeypatch.chdir(isolated)
        result = get_project_root()
        assert isinstance(result, Path)

    def test_finds_git_file_worktree(self, tmp_path, monkeypatch):
        (tmp_path / ".git").write_text("gitdir: /some/path\n")
        monkeypatch.chdir(tmp_path)
        assert get_project_root() == tmp_path


# ---------------------------------------------------------------------------
# get_claude_dir
# ---------------------------------------------------------------------------

class TestGetClaudeDir:
    def test_returns_claude_subdir(self, tmp_path, monkeypatch):
        (tmp_path / ".git").mkdir()
        monkeypatch.chdir(tmp_path)
        assert get_claude_dir() == tmp_path / ".claude"

    def test_returns_path_object(self, tmp_path, monkeypatch):
        (tmp_path / ".git").mkdir()
        monkeypatch.chdir(tmp_path)
        assert isinstance(get_claude_dir(), Path)


# ---------------------------------------------------------------------------
# get_state_dir
# ---------------------------------------------------------------------------

class TestGetStateDir:
    def test_creates_directory_when_missing(self, tmp_path, monkeypatch):
        (tmp_path / ".git").mkdir()
        monkeypatch.chdir(tmp_path)
        state_dir = get_state_dir()
        assert state_dir.exists()
        assert state_dir.is_dir()

    def test_returns_existing_directory(self, tmp_path, monkeypatch):
        (tmp_path / ".git").mkdir()
        state = tmp_path / ".claude" / "state"
        state.mkdir(parents=True)
        monkeypatch.chdir(tmp_path)
        assert get_state_dir() == state

    def test_path_ends_in_claude_state(self, tmp_path, monkeypatch):
        (tmp_path / ".git").mkdir()
        monkeypatch.chdir(tmp_path)
        result = get_state_dir()
        assert result.name == "state"
        assert result.parent.name == ".claude"


# ---------------------------------------------------------------------------
# _parse_config_yaml
# ---------------------------------------------------------------------------

class TestParseConfigYaml:
    def test_parses_flat_yaml(self, tmp_path):
        config = tmp_path / "framework.yaml"
        config.write_text("key: value\n")
        assert _parse_config_yaml(config) == {"key": "value"}

    def test_parses_nested_yaml(self, tmp_path):
        config = tmp_path / "framework.yaml"
        config.write_text("section:\n  key: value\n")
        assert _parse_config_yaml(config) == {"section": {"key": "value"}}

    def test_raises_on_missing_file(self, tmp_path):
        with pytest.raises(Exception):
            _parse_config_yaml(tmp_path / "nonexistent.yaml")

    def test_returns_empty_on_empty_file(self, tmp_path):
        config = tmp_path / "framework.yaml"
        config.write_text("")
        assert _parse_config_yaml(config) == {}


# ---------------------------------------------------------------------------
# _parse_config_fallback
# ---------------------------------------------------------------------------

class TestParseConfigFallback:
    def test_parses_section_and_key(self, tmp_path):
        config = tmp_path / "framework.yaml"
        config.write_text("section:\n  key: value\n")
        result = _parse_config_fallback(config)
        assert result["section"]["key"] == "value"

    def test_skips_comments(self, tmp_path):
        config = tmp_path / "framework.yaml"
        config.write_text("# comment\nsection:\n  key: value\n")
        assert "key" in _parse_config_fallback(config).get("section", {})

    def test_skips_blank_lines(self, tmp_path):
        config = tmp_path / "framework.yaml"
        config.write_text("\nsection:\n\n  key: value\n")
        assert _parse_config_fallback(config)["section"]["key"] == "value"

    def test_handles_double_quoted_values(self, tmp_path):
        config = tmp_path / "framework.yaml"
        config.write_text('section:\n  key: "quoted value"\n')
        assert _parse_config_fallback(config)["section"]["key"] == "quoted value"

    def test_handles_single_quoted_values(self, tmp_path):
        config = tmp_path / "framework.yaml"
        config.write_text("section:\n  key: 'single quoted'\n")
        assert _parse_config_fallback(config)["section"]["key"] == "single quoted"

    def test_handles_unquoted_values(self, tmp_path):
        config = tmp_path / "framework.yaml"
        config.write_text("section:\n  key: unquoted\n")
        assert _parse_config_fallback(config)["section"]["key"] == "unquoted"

    def test_raises_on_missing_file(self, tmp_path):
        with pytest.raises(Exception):
            _parse_config_fallback(tmp_path / "nonexistent.yaml")


# ---------------------------------------------------------------------------
# get_config
# ---------------------------------------------------------------------------

class TestGetConfig:
    def setup_method(self):
        _reset_config_cache()

    def teardown_method(self):
        _reset_config_cache()

    def test_reads_dotted_path(self, tmp_path, monkeypatch):
        (tmp_path / ".git").mkdir()
        config_dir = tmp_path / "config"
        config_dir.mkdir()
        (config_dir / "framework.yaml").write_text("hooks:\n  deploy_gate: true\n")
        monkeypatch.chdir(tmp_path)
        assert get_config("hooks.deploy_gate") in ("true", "True", True)

    def test_returns_default_when_key_missing(self, tmp_path, monkeypatch):
        (tmp_path / ".git").mkdir()
        config_dir = tmp_path / "config"
        config_dir.mkdir()
        (config_dir / "framework.yaml").write_text("section:\n  key: value\n")
        monkeypatch.chdir(tmp_path)
        assert get_config("missing.key", default="fallback") == "fallback"

    def test_returns_default_when_config_missing(self, tmp_path, monkeypatch):
        (tmp_path / ".git").mkdir()
        monkeypatch.chdir(tmp_path)
        assert get_config("any.key", default="default_val") == "default_val"

    def test_returns_empty_string_default(self, tmp_path, monkeypatch):
        (tmp_path / ".git").mkdir()
        monkeypatch.chdir(tmp_path)
        assert get_config("missing.key") == ""

    def test_handles_corrupted_config(self, tmp_path, monkeypatch):
        (tmp_path / ".git").mkdir()
        config_dir = tmp_path / "config"
        config_dir.mkdir()
        (config_dir / "framework.yaml").write_text(":::invalid yaml:::\n{{bad}}\n")
        monkeypatch.chdir(tmp_path)
        assert get_config("any.key", default="safe") == "safe"


# ---------------------------------------------------------------------------
# GIT_ENV
# ---------------------------------------------------------------------------

class TestGitEnv:
    def test_contains_git_dir(self):
        assert "GIT_DIR" in GIT_ENV

    def test_contains_git_work_tree(self):
        assert "GIT_WORK_TREE" in GIT_ENV

    def test_values_are_strings(self):
        assert isinstance(GIT_ENV["GIT_DIR"], str)
        assert isinstance(GIT_ENV["GIT_WORK_TREE"], str)

    def test_inherits_path_from_environ(self):
        assert "PATH" in GIT_ENV


# ---------------------------------------------------------------------------
# get_current_branch — takes no args, uses module-level GIT_ENV
# ---------------------------------------------------------------------------

class TestGetCurrentBranch:
    def test_returns_branch_name(self):
        mock_result = MagicMock()
        mock_result.returncode = 0
        mock_result.stdout = "main\n"
        with patch("path_utils.subprocess.run", return_value=mock_result):
            assert get_current_branch() == "main"

    def test_strips_whitespace(self):
        mock_result = MagicMock()
        mock_result.returncode = 0
        mock_result.stdout = "feature/my-branch\n"
        with patch("path_utils.subprocess.run", return_value=mock_result):
            assert get_current_branch() == "feature/my-branch"

    def test_returns_unknown_on_failure(self):
        mock_result = MagicMock()
        mock_result.returncode = 128
        mock_result.stdout = ""
        with patch("path_utils.subprocess.run", return_value=mock_result):
            assert get_current_branch() == "UNKNOWN"

    def test_returns_unknown_on_exception(self):
        with patch("path_utils.subprocess.run", side_effect=Exception("git not found")):
            assert get_current_branch() == "UNKNOWN"

    def test_returns_unknown_on_timeout(self):
        import subprocess
        with patch("path_utils.subprocess.run", side_effect=subprocess.TimeoutExpired("git", 5)):
            assert get_current_branch() == "UNKNOWN"


# ---------------------------------------------------------------------------
# STALE_TIMEOUT_SECONDS
# ---------------------------------------------------------------------------

class TestStaleTimeoutSeconds:
    def test_equals_1800(self):
        assert STALE_TIMEOUT_SECONDS == 1800

    def test_is_integer(self):
        assert isinstance(STALE_TIMEOUT_SECONDS, int)


# ---------------------------------------------------------------------------
# read_session_lock
# ---------------------------------------------------------------------------

class TestReadSessionLock:
    def test_returns_none_when_file_missing(self, tmp_path, monkeypatch):
        (tmp_path / ".git").mkdir()
        (tmp_path / ".claude" / "state").mkdir(parents=True)
        monkeypatch.chdir(tmp_path)
        assert read_session_lock() is None

    def test_returns_parsed_dict(self, tmp_path, monkeypatch):
        (tmp_path / ".git").mkdir()
        state_dir = tmp_path / ".claude" / "state"
        state_dir.mkdir(parents=True)
        lock_data = {"pid": 12345, "branch": "main", "last_heartbeat": datetime.now().isoformat()}
        (state_dir / "session-lock.json").write_text(json.dumps(lock_data))
        monkeypatch.chdir(tmp_path)
        result = read_session_lock()
        assert isinstance(result, dict)
        assert result["pid"] == 12345

    def test_returns_none_on_corrupt_json(self, tmp_path, monkeypatch):
        (tmp_path / ".git").mkdir()
        state_dir = tmp_path / ".claude" / "state"
        state_dir.mkdir(parents=True)
        (state_dir / "session-lock.json").write_text("{not valid json")
        monkeypatch.chdir(tmp_path)
        assert read_session_lock() is None

    def test_returns_none_on_empty_file(self, tmp_path, monkeypatch):
        (tmp_path / ".git").mkdir()
        state_dir = tmp_path / ".claude" / "state"
        state_dir.mkdir(parents=True)
        (state_dir / "session-lock.json").write_text("")
        monkeypatch.chdir(tmp_path)
        assert read_session_lock() is None


# ---------------------------------------------------------------------------
# is_lock_stale — expects ISO datetime strings in last_heartbeat
# ---------------------------------------------------------------------------

class TestIsLockStale:
    def test_returns_false_for_recent_heartbeat(self):
        recent = (datetime.now() - timedelta(seconds=60)).isoformat()
        assert is_lock_stale({"last_heartbeat": recent}) is False

    def test_returns_true_for_old_heartbeat(self):
        old = (datetime.now() - timedelta(seconds=3600)).isoformat()
        assert is_lock_stale({"last_heartbeat": old}) is True

    def test_returns_true_at_boundary(self):
        boundary = (datetime.now() - timedelta(seconds=STALE_TIMEOUT_SECONDS + 1)).isoformat()
        assert is_lock_stale({"last_heartbeat": boundary}) is True

    def test_returns_false_just_under_boundary(self):
        under = (datetime.now() - timedelta(seconds=STALE_TIMEOUT_SECONDS - 10)).isoformat()
        assert is_lock_stale({"last_heartbeat": under}) is False

    def test_returns_true_when_key_missing(self):
        assert is_lock_stale({}) is True

    def test_returns_true_when_value_is_none(self):
        assert is_lock_stale({"last_heartbeat": None}) is True

    def test_returns_true_on_malformed_data(self):
        assert is_lock_stale({"last_heartbeat": "not-a-timestamp"}) is True


# ---------------------------------------------------------------------------
# is_process_alive
# ---------------------------------------------------------------------------

class TestIsProcessAlive:
    def test_returns_false_for_none(self):
        assert is_process_alive(None) is False

    def test_returns_true_when_kill_succeeds(self):
        with patch("path_utils.os.kill", return_value=None):
            assert is_process_alive(12345) is True

    def test_returns_false_on_os_error(self):
        with patch("path_utils.os.kill", side_effect=OSError("no such process")):
            assert is_process_alive(12345) is False

    def test_returns_false_on_process_lookup_error(self):
        with patch("path_utils.os.kill", side_effect=ProcessLookupError("not found")):
            assert is_process_alive(99999) is False

    def test_handles_zero_pid(self):
        result = is_process_alive(0)
        assert isinstance(result, bool)
