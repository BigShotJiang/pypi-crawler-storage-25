"""Tests for CI/CD workflow hardening (AC-5 through AC-10).

Validates GitHub Actions workflows meet supply chain and least-privilege requirements:
- All actions pinned by SHA (not tag)
- Checkout SHAs consistent across workflows
- Quality gate includes lint-shell
- All workflows have permissions blocks
- Dependencies hash-pinned
- SBOM generation configured
"""
import re
from pathlib import Path

import pytest

WORKFLOWS_DIR = Path(__file__).resolve().parents[2] / ".github" / "workflows"
PROJECT_ROOT = Path(__file__).resolve().parents[2]

# Standard checkout SHA used across all workflows (v6.0.2)
CHECKOUT_SHA = "de0fac2e4500dabe0009e67214ff5f5447ce83dd"


class TestActionPinning:
    """AC-5: All GitHub Actions pinned by commit SHA, not tag."""

    def test_bats_action_sha_pinned(self):
        content = (WORKFLOWS_DIR / "ci-cd.yml").read_text()
        assert re.search(r"bats-core/bats-action@[0-9a-f]{40}", content), \
            "bats-core/bats-action must be pinned by SHA, not tag"

    def test_no_tag_only_actions(self):
        """Every uses: line must reference a 40-char hex SHA."""
        for wf in WORKFLOWS_DIR.glob("*.yml"):
            content = wf.read_text()
            for i, line in enumerate(content.splitlines(), 1):
                if "uses:" not in line:
                    continue
                # Skip docker:// and local ./ references
                ref = line.split("uses:")[-1].strip()
                if ref.startswith("docker://") or ref.startswith("./"):
                    continue
                assert re.search(r"@[0-9a-f]{40}", ref), \
                    f"{wf.name}:{i} action not SHA-pinned: {ref.strip()}"


class TestCheckoutConsistency:
    """AC-6: All workflows use the same checkout SHA."""

    def test_checkout_sha_consistent(self):
        for wf in WORKFLOWS_DIR.glob("*.yml"):
            content = wf.read_text()
            for match in re.finditer(r"actions/checkout@([0-9a-f]{40})", content):
                assert match.group(1) == CHECKOUT_SHA, \
                    f"{wf.name} uses checkout SHA {match.group(1)}, expected {CHECKOUT_SHA}"


class TestQualityGate:
    """AC-7: lint-shell is a blocking job in the quality gate."""

    def test_quality_gate_includes_lint_shell(self):
        content = (WORKFLOWS_DIR / "ci-cd.yml").read_text()
        # Find the quality-gate needs line
        match = re.search(r"quality-gate:.*?needs:\s*\[([^\]]+)\]", content, re.DOTALL)
        assert match, "quality-gate job with needs not found"
        needs = match.group(1)
        assert "lint-shell" in needs, \
            f"lint-shell not in quality-gate needs: {needs}"

    def test_shellcheck_not_suppressed(self):
        """ShellCheck must NOT have || true (failures must propagate)."""
        content = (WORKFLOWS_DIR / "ci-cd.yml").read_text()
        # Find shellcheck lines
        for i, line in enumerate(content.splitlines(), 1):
            if "shellcheck" in line.lower() and "|| true" in line:
                pytest.fail(f"ci-cd.yml:{i} ShellCheck has '|| true' — failures suppressed")


class TestWorkflowPermissions:
    """AC-8: All workflows have least-privilege permissions blocks."""

    @pytest.mark.parametrize("workflow", ["ci-cd.yml", "security-scan.yml"])
    def test_has_permissions_block(self, workflow):
        content = (WORKFLOWS_DIR / workflow).read_text()
        assert re.search(r"^permissions:", content, re.MULTILINE), \
            f"{workflow} missing top-level permissions: block"

    @pytest.mark.parametrize("workflow", ["ci-cd.yml", "security-scan.yml"])
    def test_permissions_contents_read(self, workflow):
        content = (WORKFLOWS_DIR / workflow).read_text()
        assert re.search(r"contents:\s*read", content), \
            f"{workflow} should have contents: read"


class TestDependencyPinning:
    """AC-9: Python dependencies hash-pinned in requirements.txt."""

    def test_requirements_file_exists(self):
        assert (PROJECT_ROOT / "requirements.txt").exists(), \
            "requirements.txt must exist"

    def test_requirements_has_hashes(self):
        content = (PROJECT_ROOT / "requirements.txt").read_text()
        pkg_lines = [
            line.strip() for line in content.splitlines()
            if line.strip() and not line.strip().startswith("#")
            and not line.strip().startswith("--")
        ]
        # At least one package should exist
        assert pkg_lines, "requirements.txt has no package lines"
        # Check the whole content has hash directives
        assert "--hash=sha256:" in content, \
            "requirements.txt must include --hash=sha256: directives"

    def test_ci_uses_require_hashes(self):
        content = (WORKFLOWS_DIR / "ci-cd.yml").read_text()
        assert "--require-hashes" in content, \
            "ci-cd.yml must use --require-hashes when installing deps"


class TestSBOM:
    """AC-10: SBOM generation configured in CI."""

    def test_sbom_job_exists(self):
        content = (WORKFLOWS_DIR / "ci-cd.yml").read_text()
        assert re.search(r"^\s+sbom:", content, re.MULTILINE), \
            "ci-cd.yml must have an sbom job"

    def test_sbom_uses_anchore(self):
        content = (WORKFLOWS_DIR / "ci-cd.yml").read_text()
        assert re.search(r"anchore/sbom-action@[0-9a-f]{40}", content), \
            "SBOM job must use anchore/sbom-action pinned by SHA"

    def test_sbom_produces_artifact(self):
        content = (WORKFLOWS_DIR / "ci-cd.yml").read_text()
        # Check that sbom job has an upload-artifact step
        sbom_section = re.search(r"sbom:.*?(?=\n\s{2}\w|\Z)", content, re.DOTALL)
        assert sbom_section, "sbom job section not found"
        assert "upload-artifact" in sbom_section.group(), \
            "sbom job must upload an artifact"
