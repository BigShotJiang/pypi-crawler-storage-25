"""Tests for scripts/generate_dashboard.py — static HTML dashboard generator.

Covers all three layers (data loading, aggregation, rendering) and the
orchestration entry point. AC-1 through AC-8 from .sherlock-plan.md.
"""

import json
from datetime import datetime, timezone
from pathlib import Path
from unittest.mock import patch, MagicMock

import pytest

from scripts.generate_dashboard import (
    load_events,
    load_scorecards,
    aggregate_safety,
    aggregate_cost_routing,
    aggregate_conformance,
    aggregate_sessions,
    aggregate_protocol,
    render_svg_bar_chart,
    render_svg_line_chart,
    render_dashboard,
    generate_dashboard,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_framework_yaml(tmp_path: Path, enabled: bool = True) -> Path:
    """Write a minimal framework.yaml with metrics.enabled set."""
    config_dir = tmp_path / "config"
    config_dir.mkdir(parents=True, exist_ok=True)
    content = f"metrics:\n  enabled: {str(enabled).lower()}\n"
    yaml_path = config_dir / "framework.yaml"
    yaml_path.write_text(content)
    return yaml_path


def _make_events_file(metrics_dir: Path, month: str, events: list) -> Path:
    """Write a list of event dicts as JSONL to a monthly events file."""
    metrics_dir.mkdir(parents=True, exist_ok=True)
    path = metrics_dir / f"events-{month}.jsonl"
    path.write_text("\n".join(json.dumps(e) for e in events) + "\n")
    return path


def _make_scorecard(conformance_dir: Path, ts: str, composite_score: float, components: dict) -> Path:
    """Write a scorecard JSON file to the conformance directory."""
    conformance_dir.mkdir(parents=True, exist_ok=True)
    safe_ts = ts.replace(":", "-").replace("+", "_")
    path = conformance_dir / f"scorecard-{safe_ts}.json"
    data = {
        "composite_score": composite_score,
        "components": components,
        "timestamp": ts,
    }
    path.write_text(json.dumps(data))
    return path


# Reusable component set for scorecard tests
_DEFAULT_COMPONENTS = {
    "file_coverage": 0.9,
    "ac_coverage": 0.8,
    "scope_creep": 0.95,
    "hook_compliance": 1.0,
    "review_gate": 1.0,
}


# ---------------------------------------------------------------------------
# TestLoadEvents — AC-1, AC-3, AC-5
# ---------------------------------------------------------------------------

class TestLoadEvents:
    """AC-1, AC-3, AC-5: load_events returns event records and supports filtering."""

    def test_returns_events_from_event_log(self, tmp_path, monkeypatch):
        """AC-1: load_events returns all events present in the metrics JSONL files."""
        _make_framework_yaml(tmp_path, enabled=True)
        metrics_dir = tmp_path / ".context" / "metrics"
        _make_events_file(metrics_dir, "2026-03", [
            {"sid": "s1", "ts": "2026-03-10T10:00:00Z", "event": "block", "category": "safety", "data": {}, "hook": "auto_approve_base"},
            {"sid": "s1", "ts": "2026-03-11T10:00:00Z", "event": "approve", "category": "safety", "data": {}, "hook": None},
        ])
        monkeypatch.chdir(tmp_path)

        results = load_events()

        assert len(results) == 2

    def test_passes_since_filter(self, tmp_path, monkeypatch):
        """AC-5: load_events(since=...) returns only events on or after that date."""
        _make_framework_yaml(tmp_path, enabled=True)
        metrics_dir = tmp_path / ".context" / "metrics"
        _make_events_file(metrics_dir, "2026-01", [
            {"sid": "s1", "ts": "2026-01-15T00:00:00Z", "event": "block", "category": "safety", "data": {}, "hook": None},
        ])
        _make_events_file(metrics_dir, "2026-03", [
            {"sid": "s2", "ts": "2026-03-05T00:00:00Z", "event": "approve", "category": "safety", "data": {}, "hook": None},
        ])
        monkeypatch.chdir(tmp_path)

        results = load_events(since="2026-03-01")

        assert len(results) == 1
        assert results[0]["ts"] >= "2026-03-01"

    def test_returns_empty_when_no_data(self, tmp_path, monkeypatch):
        """AC-3: load_events returns [] when no metrics files exist."""
        _make_framework_yaml(tmp_path, enabled=True)
        monkeypatch.chdir(tmp_path)

        results = load_events()

        assert results == []


# ---------------------------------------------------------------------------
# TestLoadScorecards — AC-2
# ---------------------------------------------------------------------------

class TestLoadScorecards:
    """AC-2: load_scorecards reads JSON scorecard files from the conformance dir."""

    def test_loads_all_scorecard_files_sorted(self, tmp_path):
        """AC-2: returns scorecards sorted chronologically by timestamp."""
        conformance_dir = tmp_path / ".context" / "metrics" / "conformance"
        _make_scorecard(conformance_dir, "2026-03-10T09:00:00", 0.80, _DEFAULT_COMPONENTS)
        _make_scorecard(conformance_dir, "2026-03-20T09:00:00", 0.90, _DEFAULT_COMPONENTS)
        _make_scorecard(conformance_dir, "2026-03-15T09:00:00", 0.85, _DEFAULT_COMPONENTS)

        results = load_scorecards(conformance_dir)

        assert len(results) == 3
        timestamps = [r["timestamp"] for r in results]
        assert timestamps == sorted(timestamps)

    def test_returns_empty_when_no_conformance_dir(self, tmp_path):
        """AC-3: returns [] when the conformance directory does not exist."""
        missing_dir = tmp_path / ".context" / "metrics" / "conformance"

        results = load_scorecards(missing_dir)

        assert results == []

    def test_skips_malformed_json(self, tmp_path):
        """load_scorecards skips files with invalid JSON without raising."""
        conformance_dir = tmp_path / ".context" / "metrics" / "conformance"
        conformance_dir.mkdir(parents=True)
        (conformance_dir / "scorecard-bad.json").write_text("not valid json{{{")
        _make_scorecard(conformance_dir, "2026-03-10T09:00:00", 0.80, _DEFAULT_COMPONENTS)

        results = load_scorecards(conformance_dir)

        assert len(results) == 1
        assert results[0]["composite_score"] == 0.80


# ---------------------------------------------------------------------------
# TestAggregateSafety — AC-1, AC-3
# ---------------------------------------------------------------------------

class TestAggregateSafety:
    """AC-1, AC-3: aggregate_safety counts approvals, blocks, and block reasons."""

    def test_counts_approvals_and_blocks(self):
        """AC-1: total_approvals and total_blocks are counted from events."""
        events = [
            {"event": "approve", "category": "safety", "data": {}},
            {"event": "block",   "category": "safety", "data": {"reason": "force push"}},
            {"event": "block",   "category": "safety", "data": {"reason": "rm -rf"}},
            {"event": "approve", "category": "safety", "data": {}},
        ]

        result = aggregate_safety(events)

        assert result["total_approvals"] == 2
        assert result["total_blocks"] == 2

    def test_block_rate_calculation(self):
        """AC-1: block_rate_pct = blocks / (blocks + approvals) * 100."""
        events = [
            {"event": "approve", "category": "safety", "data": {}},
            {"event": "block",   "category": "safety", "data": {"reason": "x"}},
            {"event": "block",   "category": "safety", "data": {"reason": "y"}},
            {"event": "block",   "category": "safety", "data": {"reason": "z"}},
        ]

        result = aggregate_safety(events)

        assert abs(result["block_rate_pct"] - 75.0) < 0.01

    def test_top_block_reasons(self):
        """AC-1: block_reasons maps reason strings to their occurrence counts."""
        events = [
            {"event": "block", "category": "safety", "data": {"reason": "force push"}},
            {"event": "block", "category": "safety", "data": {"reason": "force push"}},
            {"event": "block", "category": "safety", "data": {"reason": "rm -rf"}},
        ]

        result = aggregate_safety(events)

        assert result["block_reasons"]["force push"] == 2
        assert result["block_reasons"]["rm -rf"] == 1

    def test_empty_events_returns_zeros(self):
        """AC-3: empty input produces a valid dict with all-zero counts."""
        result = aggregate_safety([])

        assert result["total_approvals"] == 0
        assert result["total_blocks"] == 0
        assert result["block_rate_pct"] == 0
        assert result["block_reasons"] == {}
        assert result["warnings"] == 0


# ---------------------------------------------------------------------------
# TestAggregateCostRouting — AC-7
# ---------------------------------------------------------------------------

class TestAggregateCostRouting:
    """AC-7: aggregate_cost_routing tallies route events and estimates savings."""

    def test_agent_frequency_from_route_events(self):
        """AC-7: agent_frequency counts how often each agent appears in route events."""
        events = [
            {"event": "route", "category": "cost", "data": {"agent": "fw-review-code", "strategy": "standard", "est_cost_saved": 0.10}},
            {"event": "route", "category": "cost", "data": {"agent": "fw-review-code", "strategy": "standard", "est_cost_saved": 0.10}},
            {"event": "route", "category": "cost", "data": {"agent": "fw-review-security", "strategy": "skip", "est_cost_saved": 0.15}},
        ]

        result = aggregate_cost_routing(events)

        assert result["agent_frequency"]["fw-review-code"] == 2
        assert result["agent_frequency"]["fw-review-security"] == 1

    def test_strategy_distribution(self):
        """AC-7: strategy_distribution counts occurrences of each routing strategy."""
        events = [
            {"event": "route", "category": "cost", "data": {"agent": "a", "strategy": "standard", "est_cost_saved": 0.0}},
            {"event": "route", "category": "cost", "data": {"agent": "b", "strategy": "skip",     "est_cost_saved": 0.20}},
            {"event": "route", "category": "cost", "data": {"agent": "c", "strategy": "skip",     "est_cost_saved": 0.20}},
        ]

        result = aggregate_cost_routing(events)

        assert result["strategy_distribution"]["standard"] == 1
        assert result["strategy_distribution"]["skip"] == 2

    def test_total_estimated_savings(self):
        """AC-7: total_est_savings is the sum of all est_cost_saved values."""
        events = [
            {"event": "route", "category": "cost", "data": {"agent": "a", "strategy": "skip", "est_cost_saved": 0.20}},
            {"event": "route", "category": "cost", "data": {"agent": "b", "strategy": "skip", "est_cost_saved": 0.28}},
        ]

        result = aggregate_cost_routing(events)

        assert abs(result["total_est_savings"] - 0.48) < 0.001

    def test_empty_events_returns_zeros(self):
        """AC-3: empty input yields a valid dict with zero counts."""
        result = aggregate_cost_routing([])

        assert result["total_routes"] == 0
        assert result["agent_frequency"] == {}
        assert result["strategy_distribution"] == {}
        assert result["total_est_savings"] == 0
        assert result["skipped_agents_total"] == 0


# ---------------------------------------------------------------------------
# TestAggregateConformance — AC-2
# ---------------------------------------------------------------------------

class TestAggregateConformance:
    """AC-2: aggregate_conformance computes averages from scorecard data."""

    def test_averages_composite_scores(self):
        """AC-2: avg_composite is the mean of all schema v2 composite_score values."""
        scorecards = [
            {"schema_version": 2, "composite_score": 0.80, "components": _DEFAULT_COMPONENTS, "timestamp": "2026-03-10T09:00:00"},
            {"schema_version": 2, "composite_score": 0.90, "components": _DEFAULT_COMPONENTS, "timestamp": "2026-03-15T09:00:00"},
            {"schema_version": 2, "composite_score": 1.00, "components": _DEFAULT_COMPONENTS, "timestamp": "2026-03-20T09:00:00"},
        ]

        result = aggregate_conformance(scorecards)

        assert abs(result["avg_composite"] - (0.80 + 0.90 + 1.00) / 3) < 0.001

    def test_component_breakdown(self):
        """AC-2: avg_components maps each component key to its average value."""
        scorecards = [
            {"schema_version": 2, "composite_score": 0.80, "timestamp": "2026-03-10T09:00:00", "components": {"file_coverage": 0.8, "ac_coverage": 0.6}},
            {"schema_version": 2, "composite_score": 0.90, "timestamp": "2026-03-15T09:00:00", "components": {"file_coverage": 1.0, "ac_coverage": 0.8}},
        ]

        result = aggregate_conformance(scorecards)

        assert abs(result["avg_components"]["file_coverage"] - 0.9) < 0.001
        assert abs(result["avg_components"]["ac_coverage"] - 0.7) < 0.001

    def test_single_scorecard(self):
        """A single scorecard produces scores_over_time with one data point."""
        scorecards = [
            {"schema_version": 2, "composite_score": 0.85, "components": _DEFAULT_COMPONENTS, "timestamp": "2026-03-10T09:00:00"},
        ]

        result = aggregate_conformance(scorecards)

        assert result["count"] == 1
        assert len(result["scores_over_time"]) == 1
        assert result["scores_over_time"][0]["composite"] == 0.85

    def test_empty_scorecards(self):
        """AC-3: empty input returns a valid dict with count=0 and safe defaults."""
        result = aggregate_conformance([])

        assert result["count"] == 0
        assert result["avg_composite"] == 0
        assert result["scores_over_time"] == []
        assert result["avg_components"] == {}


# ---------------------------------------------------------------------------
# TestAggregateConformanceV2Partition — AC-4
# ---------------------------------------------------------------------------

class TestAggregateConformanceV2Partition:
    """AC-4: aggregate_conformance partitions v2 vs legacy scorecards.

    v1 (missing schema_version OR schema_version != 2) scorecards are
    excluded from aggregates and surfaced in legacy_count + legacy_files
    (filenames only — no path leakage).
    """

    def test_ac4_v1_scorecards_excluded_from_avg_composite(self):
        """Legacy scorecards (no schema_version) must not contribute to avg_composite."""
        scorecards = [
            {"schema_version": 2, "composite_score": 1.00, "components": _DEFAULT_COMPONENTS, "timestamp": "2026-03-20T09:00:00"},
            # Legacy — should be excluded:
            {"composite_score": 0.10, "components": _DEFAULT_COMPONENTS, "timestamp": "2026-03-10T09:00:00", "_source_file": "scorecard-legacy.json"},
        ]

        result = aggregate_conformance(scorecards)

        # avg must reflect only the v2 scorecard (1.00), not the blended average
        assert abs(result["avg_composite"] - 1.00) < 0.001
        assert result["count"] == 1, "count reports v2 only"

    def test_ac4_legacy_count_populated(self):
        """Number of legacy scorecards surfaced in legacy_count."""
        scorecards = [
            {"schema_version": 2, "composite_score": 0.9, "components": _DEFAULT_COMPONENTS, "timestamp": "2026-03-20T09:00:00"},
            {"composite_score": 0.5, "components": _DEFAULT_COMPONENTS, "timestamp": "2026-03-10T09:00:00", "_source_file": "scorecard-a.json"},
            {"schema_version": 1, "composite_score": 0.6, "components": _DEFAULT_COMPONENTS, "timestamp": "2026-03-11T09:00:00", "_source_file": "scorecard-b.json"},
        ]

        result = aggregate_conformance(scorecards)

        assert result["legacy_count"] == 2

    def test_ac4_legacy_files_contains_filenames_only(self):
        """legacy_files reports the filenames of excluded legacy scorecards."""
        scorecards = [
            {"schema_version": 2, "composite_score": 0.9, "components": _DEFAULT_COMPONENTS, "timestamp": "2026-03-20T09:00:00"},
            {"composite_score": 0.5, "components": _DEFAULT_COMPONENTS, "timestamp": "2026-03-10T09:00:00", "_source_file": "scorecard-a.json"},
        ]

        result = aggregate_conformance(scorecards)

        assert "scorecard-a.json" in result["legacy_files"]

    def test_ac4_legacy_files_path_leakage_property(self):
        """legacy_files entries must never contain OS path separators.

        Even if a scorecard's _source_file includes a directory, we report
        only the filename component — no path leakage via the dashboard.
        """
        import os
        scorecards = [
            {"schema_version": 2, "composite_score": 0.9, "components": _DEFAULT_COMPONENTS, "timestamp": "2026-03-20T09:00:00"},
            {"composite_score": 0.5, "components": _DEFAULT_COMPONENTS, "timestamp": "2026-03-10T09:00:00", "_source_file": "/home/dev/project/.context/metrics/conformance/scorecard-legacy.json"},
        ]

        result = aggregate_conformance(scorecards)

        for entry in result["legacy_files"]:
            assert os.sep not in entry, (
                f"legacy_files entry must be basename only — got {entry!r}"
            )
            assert "/" not in entry, (
                f"legacy_files entry must not contain '/' — got {entry!r}"
            )

    def test_ac4_zero_v2_but_legacy_present_returns_defaults_and_count(self):
        """All-legacy input: aggregates stay at defaults but legacy_count reports them."""
        scorecards = [
            {"composite_score": 0.5, "components": _DEFAULT_COMPONENTS, "timestamp": "2026-03-10T09:00:00", "_source_file": "scorecard-old.json"},
        ]

        result = aggregate_conformance(scorecards)

        assert result["count"] == 0
        assert result["avg_composite"] == 0
        assert result["legacy_count"] == 1
        assert result["legacy_files"] == ["scorecard-old.json"]

    def test_ac4_empty_input_has_zero_legacy_count(self):
        """Empty input: legacy_count=0 and legacy_files=[] at top level."""
        result = aggregate_conformance([])

        assert result["legacy_count"] == 0
        assert result["legacy_files"] == []


# ---------------------------------------------------------------------------
# TestAggregateSessions — AC-8
# ---------------------------------------------------------------------------

class TestAggregateSessions:
    """AC-8: aggregate_sessions groups events by session ID and computes durations."""

    def test_groups_by_session_id(self):
        """AC-8: session_count equals the number of distinct sid values."""
        events = [
            {"sid": "s1", "ts": "2026-03-10T10:00:00Z", "event": "block", "category": "safety", "data": {}},
            {"sid": "s1", "ts": "2026-03-10T10:05:00Z", "event": "approve", "category": "safety", "data": {}},
            {"sid": "s2", "ts": "2026-03-11T09:00:00Z", "event": "warn", "category": "protocol", "data": {}},
        ]

        result = aggregate_sessions(events)

        assert result["session_count"] == 2
        assert result["events_per_session"]["s1"] == 2
        assert result["events_per_session"]["s2"] == 1
        # s1 = 5 min, s2 = 0 min → avg = 2.5
        assert abs(result["avg_duration_min"] - 2.5) < 0.1

    def test_duration_from_timestamps(self):
        """AC-8: session_durations_min contains duration (max_ts - min_ts) in minutes."""
        events = [
            {"sid": "s1", "ts": "2026-03-10T10:00:00Z", "event": "block", "category": "safety", "data": {}},
            {"sid": "s1", "ts": "2026-03-10T10:30:00Z", "event": "approve", "category": "safety", "data": {}},
        ]

        result = aggregate_sessions(events)

        assert abs(result["session_durations_min"][0] - 30.0) < 0.1

    def test_single_event_zero_duration(self):
        """A session with only one event has a duration of 0 minutes."""
        events = [
            {"sid": "s1", "ts": "2026-03-10T10:00:00Z", "event": "block", "category": "safety", "data": {}},
        ]

        result = aggregate_sessions(events)

        assert result["session_durations_min"][0] == 0.0

    def test_empty_events(self):
        """AC-3: empty input returns a valid dict with zero sessions."""
        result = aggregate_sessions([])

        assert result["session_count"] == 0
        assert result["events_per_session"] == {}
        assert result["session_durations_min"] == []
        assert result["avg_duration_min"] == 0


# ---------------------------------------------------------------------------
# TestAggregateProtocol — AC-1
# ---------------------------------------------------------------------------

class TestAggregateProtocol:
    """AC-1: aggregate_protocol counts protocol warnings and blocks."""

    def test_counts_warnings_and_blocks(self):
        """AC-1: total_warnings and total_blocks are counted from protocol events."""
        events = [
            {"event": "warn",  "category": "protocol", "data": {"violation": "stale_docs"}},
            {"event": "warn",  "category": "protocol", "data": {"violation": "stale_docs"}},
            {"event": "block", "category": "protocol", "data": {"violation": "missing_changelog"}},
        ]

        result = aggregate_protocol(events)

        assert result["total_warnings"] == 2
        assert result["total_blocks"] == 1
        assert result["violation_types"]["stale_docs"] == 2
        assert result["violation_types"]["missing_changelog"] == 1

    def test_empty_events(self):
        """AC-3: empty input returns zeros."""
        result = aggregate_protocol([])

        assert result["total_warnings"] == 0
        assert result["total_blocks"] == 0
        assert result["violation_types"] == {}


# ---------------------------------------------------------------------------
# TestRenderSvgBarChart — AC-4
# ---------------------------------------------------------------------------

class TestRenderSvgBarChart:
    """AC-4: render_svg_bar_chart produces valid inline SVG."""

    def test_produces_valid_svg(self):
        """AC-4: output contains opening and closing SVG tags."""
        data = {"fw-review-code": 10.0, "fw-review-security": 5.0, "fw-review-tests": 3.0}

        result = render_svg_bar_chart(data, title="Agent Frequency")

        assert result.strip().startswith("<svg") or "<svg" in result
        assert "</svg>" in result

    def test_handles_empty_data(self):
        """AC-4: empty data dict returns a valid (possibly empty) SVG string without raising."""
        result = render_svg_bar_chart({}, title="Empty Chart")

        # Must not raise; must return a string
        assert isinstance(result, str)
        assert len(result) > 0

    def test_handles_single_bar(self):
        """A single-item dict produces an SVG with at least one bar element."""
        data = {"only-agent": 42.0}

        result = render_svg_bar_chart(data, title="Single Bar")

        assert isinstance(result, str)
        assert "svg" in result.lower()


# ---------------------------------------------------------------------------
# TestRenderSvgLineChart — AC-2, AC-4
# ---------------------------------------------------------------------------

class TestRenderSvgLineChart:
    """AC-2, AC-4: render_svg_line_chart produces valid inline SVG for trend lines."""

    def test_produces_valid_svg(self):
        """AC-2/AC-4: multi-point input returns valid SVG string."""
        points = [
            ("2026-03-10", 0.80),
            ("2026-03-15", 0.85),
            ("2026-03-20", 0.90),
        ]

        result = render_svg_line_chart(points, title="Conformance Over Time")

        assert "<svg" in result
        assert "</svg>" in result

    def test_handles_single_point(self):
        """A single data point renders without raising."""
        points = [("2026-03-10", 0.80)]

        result = render_svg_line_chart(points, title="Single Point")

        assert isinstance(result, str)
        assert "svg" in result.lower()

    def test_handles_empty_data(self):
        """AC-3: empty points list returns a valid SVG string without raising."""
        result = render_svg_line_chart([], title="Empty Line Chart")

        assert isinstance(result, str)
        assert len(result) > 0


# ---------------------------------------------------------------------------
# TestRenderDashboard — AC-1, AC-4
# ---------------------------------------------------------------------------

class TestRenderDashboard:
    """AC-1, AC-4: render_dashboard produces a complete, self-contained HTML page."""

    def _make_sections(self):
        return {
            "Safety": "<p>safety content</p>",
            "Cost Routing": "<p>cost content</p>",
            "Conformance": "<p>conformance content</p>",
            "Sessions": "<p>sessions content</p>",
            "Protocol": "<p>protocol content</p>",
        }

    def test_complete_html_document(self):
        """AC-1: output is a well-formed HTML document with <html>, <head>, <body>."""
        sections = self._make_sections()

        result = render_dashboard(sections, generated_at="2026-03-30T12:00:00Z")

        assert "<html" in result
        assert "<head" in result
        assert "<body" in result
        assert "</html>" in result

    def test_contains_all_sections(self):
        """AC-1: all five section headings appear in the rendered output."""
        sections = self._make_sections()

        result = render_dashboard(sections, generated_at="2026-03-30T12:00:00Z")

        for heading in ("Safety", "Cost Routing", "Conformance", "Sessions", "Protocol"):
            assert heading in result, f"Missing section heading: {heading}"

    def test_inline_css(self):
        """AC-4: output contains a <style> block (CSS is inline, not linked)."""
        sections = self._make_sections()

        result = render_dashboard(sections, generated_at="2026-03-30T12:00:00Z")

        assert "<style" in result

    def test_no_external_dependencies(self):
        """AC-4: no <link>, <script src=, or external url() references."""
        sections = self._make_sections()

        result = render_dashboard(sections, generated_at="2026-03-30T12:00:00Z")

        assert "<link" not in result.lower()
        assert 'script src=' not in result.lower()
        # External url() calls — simple heuristic: url(http
        assert "url(http" not in result.lower()


# ---------------------------------------------------------------------------
# TestGenerateDashboard — AC-1, AC-3, AC-5, AC-6
# ---------------------------------------------------------------------------

class TestGenerateDashboard:
    """AC-1, AC-3, AC-5, AC-6: generate_dashboard orchestrates end-to-end generation."""

    def test_writes_html_to_default_path(self, tmp_path, monkeypatch):
        """AC-1: without output_path, writes to .context/dashboard.html."""
        _make_framework_yaml(tmp_path, enabled=True)
        monkeypatch.chdir(tmp_path)

        result_path = generate_dashboard()

        expected = tmp_path / ".context" / "dashboard.html"
        assert result_path == expected
        assert expected.exists()

    def test_writes_to_custom_path(self, tmp_path, monkeypatch):
        """AC-1: output_path overrides the default file location."""
        _make_framework_yaml(tmp_path, enabled=True)
        monkeypatch.chdir(tmp_path)
        custom_path = tmp_path / "out" / "my-dashboard.html"
        custom_path.parent.mkdir(parents=True)

        result_path = generate_dashboard(output_path=custom_path)

        assert result_path == custom_path
        assert custom_path.exists()

    def test_graceful_with_no_data(self, tmp_path, monkeypatch):
        """AC-3: generates dashboard.html with no events/scorecards without raising."""
        _make_framework_yaml(tmp_path, enabled=True)
        monkeypatch.chdir(tmp_path)

        # Must not raise
        result_path = generate_dashboard()

        assert result_path.exists()
        content = result_path.read_text()
        assert "<html" in content

    def test_open_browser_flag(self, tmp_path, monkeypatch):
        """AC-6: when open_browser=True, webbrowser.open() is called with the output path."""
        _make_framework_yaml(tmp_path, enabled=True)
        monkeypatch.chdir(tmp_path)

        with patch("scripts.generate_dashboard.webbrowser.open") as mock_open:
            result_path = generate_dashboard(open_browser=True)

        mock_open.assert_called_once()
        call_arg = mock_open.call_args[0][0]
        assert call_arg == f"file://{result_path.resolve()}"

    def test_since_filter_passed_through(self, tmp_path, monkeypatch):
        """AC-5: since parameter is passed to the data loading layer."""
        _make_framework_yaml(tmp_path, enabled=True)
        metrics_dir = tmp_path / ".context" / "metrics"
        # January event — should be excluded
        _make_events_file(metrics_dir, "2026-01", [
            {"sid": "s1", "ts": "2026-01-10T10:00:00Z", "event": "block", "category": "safety", "data": {"reason": "x"}, "hook": None},
        ])
        # March event — should be included
        _make_events_file(metrics_dir, "2026-03", [
            {"sid": "s2", "ts": "2026-03-10T10:00:00Z", "event": "approve", "category": "safety", "data": {}, "hook": None},
        ])
        monkeypatch.chdir(tmp_path)

        result_path = generate_dashboard(since="2026-03-01")

        content = result_path.read_text()
        assert result_path.exists()
        assert "<html" in content
        # January block must be excluded — only the March approve should count
        assert "Blocks: 0" in content
