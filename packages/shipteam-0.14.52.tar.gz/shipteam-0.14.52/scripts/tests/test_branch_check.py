"""Tests for the branch-check hook (.claude/hooks/branch-check.py).

The module has a hyphenated filename so we import it via importlib.
Tests cover session management, branch validation, drift detection, and auto-sync.
"""

import importlib
import importlib.util
import json
import os
import sys
import time
from datetime import datetime, timedelta
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

# Import the hyphenated module via importlib
_hooks_dir = str(Path(__file__).resolve().parent.parent.parent / ".claude" / "hooks")
sys.path.insert(0, _hooks_dir)

_spec = importlib.util.spec_from_file_location("branch_check", os.path.join(_hooks_dir, "branch-check.py"))
branch_check = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(branch_check)


def _setup_module(tmp_path):
    """Redirect all module-level path constants to tmp_path for isolation."""
    state_dir = tmp_path / ".claude" / "state"
    state_dir.mkdir(parents=True, exist_ok=True)

    branch_check.PROJECT_ROOT = tmp_path
    branch_check.STATE_DIR = state_dir
    branch_check.EXPECTED_BRANCH_FILE = tmp_path / ".claude" / "expected-branch.txt"
    branch_check.SESSION_LOCK_FILE = state_dir / "session-lock.json"
    branch_check.HANDOFF_FILE = state_dir / "pre-compact-handoff.json"
    branch_check.SYNC_MARKER_FILE = state_dir / "last-auto-sync.json"
    branch_check.MERGE_CONFLICT_MARKER = state_dir / "merge-conflict.json"
    branch_check.DRIFT_LAST_CHECK_FILE = state_dir / "drift-last-check.json"


# ---------------------------------------------------------------------------
# get_or_create_session_id
# ---------------------------------------------------------------------------

class TestGetOrCreateSessionId:
    def test_returns_env_var_when_set(self, tmp_path, monkeypatch):
        _setup_module(tmp_path)
        monkeypatch.setenv("CLAUDE_SESSION_ID", "mysession")
        assert branch_check.get_or_create_session_id() == "mysession"

    def test_generates_id_when_not_set(self, tmp_path, monkeypatch):
        _setup_module(tmp_path)
        monkeypatch.delenv("CLAUDE_SESSION_ID", raising=False)
        result = branch_check.get_or_create_session_id()
        assert result is not None
        assert len(result) > 0

    def test_generated_id_is_8_chars(self, tmp_path, monkeypatch):
        _setup_module(tmp_path)
        monkeypatch.delenv("CLAUDE_SESSION_ID", raising=False)
        assert len(branch_check.get_or_create_session_id()) == 8


# ---------------------------------------------------------------------------
# get_expected_branch
# ---------------------------------------------------------------------------

class TestGetExpectedBranch:
    def test_returns_branch_from_file(self, tmp_path):
        _setup_module(tmp_path)
        branch_check.EXPECTED_BRANCH_FILE.parent.mkdir(parents=True, exist_ok=True)
        branch_check.EXPECTED_BRANCH_FILE.write_text("feature/my-feature\n")
        assert branch_check.get_expected_branch() == "feature/my-feature"

    def test_strips_whitespace(self, tmp_path):
        _setup_module(tmp_path)
        branch_check.EXPECTED_BRANCH_FILE.parent.mkdir(parents=True, exist_ok=True)
        branch_check.EXPECTED_BRANCH_FILE.write_text("  main  \n")
        assert branch_check.get_expected_branch() == "main"

    def test_returns_none_when_missing(self, tmp_path):
        _setup_module(tmp_path)
        assert branch_check.get_expected_branch() is None


# ---------------------------------------------------------------------------
# write_session_lock
# ---------------------------------------------------------------------------

class TestWriteSessionLock:
    def test_creates_lock_with_correct_fields(self, tmp_path):
        _setup_module(tmp_path)
        branch_check.write_session_lock("abc12345", "main")
        assert branch_check.SESSION_LOCK_FILE.exists()
        data = json.loads(branch_check.SESSION_LOCK_FILE.read_text())
        assert data["session_id"] == "abc12345"
        assert data["branch"] == "main"
        assert "pid" in data
        assert "started_at" in data
        assert "last_heartbeat" in data

    def test_creates_state_dir_if_missing(self, tmp_path):
        _setup_module(tmp_path)
        import shutil
        shutil.rmtree(branch_check.STATE_DIR)
        branch_check.write_session_lock("abc12345", "main")
        assert branch_check.SESSION_LOCK_FILE.exists()

    def test_pid_matches_current_process(self, tmp_path):
        _setup_module(tmp_path)
        branch_check.write_session_lock("abc12345", "main")
        data = json.loads(branch_check.SESSION_LOCK_FILE.read_text())
        assert data["pid"] == os.getpid()

    def test_overwrites_existing_lock(self, tmp_path):
        _setup_module(tmp_path)
        branch_check.write_session_lock("session1", "main")
        branch_check.write_session_lock("session2", "feature/new")
        data = json.loads(branch_check.SESSION_LOCK_FILE.read_text())
        assert data["session_id"] == "session2"


# ---------------------------------------------------------------------------
# update_heartbeat
# ---------------------------------------------------------------------------

class TestUpdateHeartbeat:
    def test_updates_for_same_session(self, tmp_path):
        _setup_module(tmp_path)
        branch_check.write_session_lock("abc12345", "main")
        original = json.loads(branch_check.SESSION_LOCK_FILE.read_text())["last_heartbeat"]
        time.sleep(0.01)
        branch_check.update_heartbeat("abc12345", "main")
        updated = json.loads(branch_check.SESSION_LOCK_FILE.read_text())["last_heartbeat"]
        assert updated >= original

    def test_does_not_update_for_different_session(self, tmp_path):
        _setup_module(tmp_path)
        branch_check.write_session_lock("abc12345", "main")
        original = json.loads(branch_check.SESSION_LOCK_FILE.read_text())["last_heartbeat"]
        branch_check.update_heartbeat("other999", "main")
        unchanged = json.loads(branch_check.SESSION_LOCK_FILE.read_text())["last_heartbeat"]
        assert unchanged == original

    def test_handles_missing_lock_gracefully(self, tmp_path):
        _setup_module(tmp_path)
        branch_check.update_heartbeat("abc12345", "main")  # should not raise


# ---------------------------------------------------------------------------
# check_session_conflict
# ---------------------------------------------------------------------------

class TestCheckSessionConflict:
    def test_no_lock_creates_lock_returns_none(self, tmp_path):
        _setup_module(tmp_path)
        # read_session_lock is imported from path_utils — patch it on the module
        with patch.object(branch_check, "read_session_lock", return_value=None):
            result = branch_check.check_session_conflict("abc12345", "main")
        assert result is None
        assert branch_check.SESSION_LOCK_FILE.exists()

    def test_same_session_returns_none(self, tmp_path):
        _setup_module(tmp_path)
        branch_check.write_session_lock("abc12345", "main")
        lock_data = json.loads(branch_check.SESSION_LOCK_FILE.read_text())
        with patch.object(branch_check, "read_session_lock", return_value=lock_data):
            assert branch_check.check_session_conflict("abc12345", "main") is None

    def test_stale_lock_returns_stale_lock_claimed(self, tmp_path):
        _setup_module(tmp_path)
        stale_hb = (datetime.now() - timedelta(hours=1)).isoformat()
        stale_data = {
            "session_id": "oldSession", "pid": 99999999,
            "branch": "main", "started_at": stale_hb, "last_heartbeat": stale_hb,
        }
        branch_check.SESSION_LOCK_FILE.write_text(json.dumps(stale_data))
        # is_lock_stale and is_process_alive are imported from path_utils
        with patch.object(branch_check, "is_lock_stale", return_value=True):
            result = branch_check.check_session_conflict("abc12345", "main")
        assert result is not None
        assert result["type"] == "stale_lock_claimed"

    def test_dead_process_returns_stale_lock_claimed(self, tmp_path):
        _setup_module(tmp_path)
        recent_hb = datetime.now().isoformat()
        dead_data = {
            "session_id": "deadSession", "pid": 99999999,
            "branch": "main", "started_at": recent_hb, "last_heartbeat": recent_hb,
        }
        branch_check.SESSION_LOCK_FILE.write_text(json.dumps(dead_data))
        with patch.object(branch_check, "is_lock_stale", return_value=False), \
             patch.object(branch_check, "is_process_alive", return_value=False):
            result = branch_check.check_session_conflict("abc12345", "main")
        assert result is not None
        assert result["type"] == "stale_lock_claimed"

    def test_active_concurrent_session_returns_warning(self, tmp_path):
        _setup_module(tmp_path)
        recent_hb = datetime.now().isoformat()
        active_data = {
            "session_id": "activeOther", "pid": os.getpid(),
            "branch": "main", "started_at": recent_hb, "last_heartbeat": recent_hb,
        }
        branch_check.SESSION_LOCK_FILE.write_text(json.dumps(active_data))
        with patch.object(branch_check, "is_lock_stale", return_value=False), \
             patch.object(branch_check, "is_process_alive", return_value=True):
            result = branch_check.check_session_conflict("abc12345", "main")
        assert result is not None
        assert result["type"] == "concurrent_session"


# ---------------------------------------------------------------------------
# should_check_drift
# ---------------------------------------------------------------------------

class TestShouldCheckDrift:
    def test_returns_true_when_no_file(self, tmp_path):
        _setup_module(tmp_path)
        assert branch_check.should_check_drift() is True

    def test_returns_true_when_old(self, tmp_path):
        _setup_module(tmp_path)
        old_ts = (datetime.now() - timedelta(minutes=10)).isoformat()
        branch_check.DRIFT_LAST_CHECK_FILE.write_text(json.dumps({"checked_at": old_ts}))
        assert branch_check.should_check_drift() is True

    def test_returns_false_when_recent(self, tmp_path):
        _setup_module(tmp_path)
        recent_ts = (datetime.now() - timedelta(seconds=30)).isoformat()
        branch_check.DRIFT_LAST_CHECK_FILE.write_text(json.dumps({"checked_at": recent_ts}))
        assert branch_check.should_check_drift() is False

    def test_returns_true_on_corrupt_file(self, tmp_path):
        _setup_module(tmp_path)
        branch_check.DRIFT_LAST_CHECK_FILE.write_text("not valid json")
        assert branch_check.should_check_drift() is True


# ---------------------------------------------------------------------------
# record_drift_check
# ---------------------------------------------------------------------------

class TestRecordDriftCheck:
    def test_creates_drift_file(self, tmp_path):
        _setup_module(tmp_path)
        branch_check.record_drift_check()
        assert branch_check.DRIFT_LAST_CHECK_FILE.exists()
        data = json.loads(branch_check.DRIFT_LAST_CHECK_FILE.read_text())
        assert "checked_at" in data

    def test_overwrites_existing(self, tmp_path):
        _setup_module(tmp_path)
        branch_check.DRIFT_LAST_CHECK_FILE.write_text(json.dumps({"checked_at": "2000-01-01"}))
        branch_check.record_drift_check()
        data = json.loads(branch_check.DRIFT_LAST_CHECK_FILE.read_text())
        assert data["checked_at"] != "2000-01-01"


# ---------------------------------------------------------------------------
# check_drift_from_main
# ---------------------------------------------------------------------------

class TestCheckDriftFromMain:
    def test_skips_when_should_check_false(self, tmp_path):
        _setup_module(tmp_path)
        with patch.object(branch_check, "should_check_drift", return_value=False):
            assert branch_check.check_drift_from_main() is None

    def test_returns_none_when_up_to_date(self, tmp_path):
        _setup_module(tmp_path)
        fetch_ok = MagicMock(returncode=0)
        rev_list_0 = MagicMock(returncode=0, stdout="0\n")
        with patch.object(branch_check, "should_check_drift", return_value=True), \
             patch("subprocess.run", side_effect=[fetch_ok, rev_list_0]):
            assert branch_check.check_drift_from_main() is None

    def test_returns_drift_info_when_behind(self, tmp_path):
        _setup_module(tmp_path)
        fetch_ok = MagicMock(returncode=0)
        rev_list_3 = MagicMock(returncode=0, stdout="3\n")
        log_result = MagicMock(returncode=0, stdout="abc Short msg\ndef Another\nghi Third\n")
        with patch.object(branch_check, "should_check_drift", return_value=True), \
             patch("subprocess.run", side_effect=[fetch_ok, rev_list_3, log_result]):
            result = branch_check.check_drift_from_main()
        assert result is not None
        assert result["commits_behind"] == 3

    def test_returns_none_on_fetch_failure(self, tmp_path):
        _setup_module(tmp_path)
        fetch_fail = MagicMock(returncode=1)
        with patch.object(branch_check, "should_check_drift", return_value=True), \
             patch("subprocess.run", return_value=fetch_fail):
            assert branch_check.check_drift_from_main() is None

    def test_returns_none_on_timeout(self, tmp_path):
        _setup_module(tmp_path)
        import subprocess
        with patch.object(branch_check, "should_check_drift", return_value=True), \
             patch("subprocess.run", side_effect=subprocess.TimeoutExpired("git", 10)):
            assert branch_check.check_drift_from_main() is None


# ---------------------------------------------------------------------------
# is_merge_in_progress
# ---------------------------------------------------------------------------

class TestIsMergeInProgress:
    def test_returns_true_when_merge_head_exists(self, tmp_path):
        _setup_module(tmp_path)
        git_dir = tmp_path / ".git"
        git_dir.mkdir()
        (git_dir / "MERGE_HEAD").write_text("abc123\n")
        assert branch_check.is_merge_in_progress() is True

    def test_returns_false_when_no_merge_head(self, tmp_path):
        _setup_module(tmp_path)
        git_dir = tmp_path / ".git"
        git_dir.mkdir()
        assert branch_check.is_merge_in_progress() is False

    def test_follows_gitdir_pointer_in_worktree(self, tmp_path):
        _setup_module(tmp_path)
        actual_git = tmp_path / "actual_git"
        actual_git.mkdir()
        (actual_git / "MERGE_HEAD").write_text("abc123\n")
        git_file = tmp_path / ".git"
        git_file.write_text(f"gitdir: {actual_git}\n")
        assert branch_check.is_merge_in_progress() is True


# ---------------------------------------------------------------------------
# auto_sync_with_main
# ---------------------------------------------------------------------------

class TestAutoSyncWithMain:
    def test_skips_when_should_auto_sync_false(self, tmp_path):
        _setup_module(tmp_path)
        with patch.object(branch_check, "should_auto_sync", return_value=False):
            assert branch_check.auto_sync_with_main("abc12345", 5) is None

    def test_skips_when_merge_in_progress(self, tmp_path):
        _setup_module(tmp_path)
        with patch.object(branch_check, "should_auto_sync", return_value=True), \
             patch.object(branch_check, "is_merge_in_progress", return_value=True):
            result = branch_check.auto_sync_with_main("abc12345", 5)
        assert result is not None
        assert result["status"] == "skipped"

    def test_fast_forward_success(self, tmp_path):
        _setup_module(tmp_path)
        # diff --quiet (no changes), diff --cached --quiet (no staged)
        diff_ok = MagicMock(returncode=0)
        ff_ok = MagicMock(returncode=0)
        with patch.object(branch_check, "should_auto_sync", return_value=True), \
             patch.object(branch_check, "is_merge_in_progress", return_value=False), \
             patch("subprocess.run", side_effect=[diff_ok, diff_ok, ff_ok]), \
             patch.object(branch_check, "record_sync_attempt"):
            result = branch_check.auto_sync_with_main("abc12345", 3)
        assert result["status"] == "synced"
        assert result["method"] == "fast_forward"

    def test_merge_after_ff_fails(self, tmp_path):
        _setup_module(tmp_path)
        diff_ok = MagicMock(returncode=0)
        ff_fail = MagicMock(returncode=1)
        merge_ok = MagicMock(returncode=0)
        with patch.object(branch_check, "should_auto_sync", return_value=True), \
             patch.object(branch_check, "is_merge_in_progress", return_value=False), \
             patch("subprocess.run", side_effect=[diff_ok, diff_ok, ff_fail, merge_ok]), \
             patch.object(branch_check, "record_sync_attempt"):
            result = branch_check.auto_sync_with_main("abc12345", 3)
        assert result["status"] == "synced"
        assert result["method"] == "merge"

    def test_merge_conflict_writes_marker(self, tmp_path):
        _setup_module(tmp_path)
        diff_ok = MagicMock(returncode=0)
        ff_fail = MagicMock(returncode=1)
        merge_fail = MagicMock(returncode=1)
        abort_ok = MagicMock(returncode=0)
        conflict_files = MagicMock(returncode=0, stdout="file1.py\nfile2.py\n")
        with patch.object(branch_check, "should_auto_sync", return_value=True), \
             patch.object(branch_check, "is_merge_in_progress", return_value=False), \
             patch("subprocess.run", side_effect=[diff_ok, diff_ok, ff_fail, merge_fail, abort_ok, conflict_files]), \
             patch.object(branch_check, "record_sync_attempt"):
            result = branch_check.auto_sync_with_main("abc12345", 3)
        assert result["status"] == "conflict_aborted"
        assert branch_check.MERGE_CONFLICT_MARKER.exists()


# ---------------------------------------------------------------------------
# main (integration-like)
# ---------------------------------------------------------------------------

class TestMain:
    def test_branch_match_exits_0(self, tmp_path, monkeypatch):
        _setup_module(tmp_path)
        monkeypatch.setenv("CLAUDE_SESSION_ID", "testsession")
        branch_check.EXPECTED_BRANCH_FILE.parent.mkdir(parents=True, exist_ok=True)
        branch_check.EXPECTED_BRANCH_FILE.write_text("main\n")
        with patch.object(branch_check, "get_current_branch", return_value="main"), \
             patch.object(branch_check, "check_session_conflict", return_value=None), \
             patch.object(branch_check, "check_drift_from_main", return_value=None), \
             patch.object(branch_check, "check_handoff_file", return_value=None), \
             pytest.raises(SystemExit) as exc_info:
            branch_check.main()
        assert exc_info.value.code == 0

    def test_branch_mismatch_exits_1(self, tmp_path, monkeypatch, capsys):
        _setup_module(tmp_path)
        monkeypatch.setenv("CLAUDE_SESSION_ID", "testsession")
        branch_check.EXPECTED_BRANCH_FILE.parent.mkdir(parents=True, exist_ok=True)
        branch_check.EXPECTED_BRANCH_FILE.write_text("feature/expected\n")
        with patch.object(branch_check, "get_current_branch", return_value="main"), \
             patch.object(branch_check, "check_session_conflict", return_value=None), \
             patch.object(branch_check, "check_drift_from_main", return_value=None), \
             patch.object(branch_check, "check_handoff_file", return_value=None), \
             pytest.raises(SystemExit) as exc_info:
            branch_check.main()
        assert exc_info.value.code == 1
        captured = capsys.readouterr()
        output = json.loads(captured.out)
        assert "BRANCH_MISMATCH" in output.get("error", "")

    def test_concurrent_session_exits_1(self, tmp_path, monkeypatch, capsys):
        _setup_module(tmp_path)
        monkeypatch.setenv("CLAUDE_SESSION_ID", "testsession")
        branch_check.EXPECTED_BRANCH_FILE.parent.mkdir(parents=True, exist_ok=True)
        branch_check.EXPECTED_BRANCH_FILE.write_text("main\n")
        conflict = {
            "type": "concurrent_session",
            "other_session": "otherSession",
            "other_branch": "main",
            "other_pid": 12345,
            "warning": "Another session active",
        }
        with patch.object(branch_check, "get_current_branch", return_value="main"), \
             patch.object(branch_check, "check_session_conflict", return_value=conflict), \
             patch.object(branch_check, "check_drift_from_main", return_value=None), \
             patch.object(branch_check, "check_handoff_file", return_value=None), \
             pytest.raises(SystemExit) as exc_info:
            branch_check.main()
        assert exc_info.value.code == 1

    def test_no_expected_branch_exits_0(self, tmp_path, monkeypatch):
        _setup_module(tmp_path)
        monkeypatch.setenv("CLAUDE_SESSION_ID", "testsession")
        # No expected branch file
        with patch.object(branch_check, "get_current_branch", return_value="main"), \
             patch.object(branch_check, "check_session_conflict", return_value=None), \
             patch.object(branch_check, "check_drift_from_main", return_value=None), \
             patch.object(branch_check, "check_handoff_file", return_value=None), \
             pytest.raises(SystemExit) as exc_info:
            branch_check.main()
        assert exc_info.value.code == 0
