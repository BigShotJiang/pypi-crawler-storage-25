"""Tests for the commit_trust_check hook.

Verifies CI status and production health before allowing work to proceed.
All subprocess calls are mocked — no real git or gh commands are executed.
"""

import json
import sys
import time
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent / ".claude" / "hooks"))

import commit_trust_check


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_subprocess_result(returncode=0, stdout="", stderr=""):
    result = MagicMock()
    result.returncode = returncode
    result.stdout = stdout
    result.stderr = stderr
    return result


def _reset_module_state():
    """Reset any module-level cache state between tests."""
    # commit_trust_check does not currently expose a module-level dict to reset,
    # but patching CACHE_FILE is done per-test via tmp_path.
    pass


# ---------------------------------------------------------------------------
# Cache Management
# ---------------------------------------------------------------------------

class TestLoadCache:
    """load_cache returns a usable dict under all file-system conditions."""

    def test_returns_default_when_file_missing(self, tmp_path):
        missing = tmp_path / "trust-cache.json"
        with patch.object(commit_trust_check, "CACHE_FILE", missing):
            result = commit_trust_check.load_cache()
        assert result == {"version": 1, "entries": {}}

    def test_returns_default_on_corrupt_json(self, tmp_path):
        cache_file = tmp_path / "trust-cache.json"
        cache_file.write_text("not valid json {{{")
        with patch.object(commit_trust_check, "CACHE_FILE", cache_file):
            result = commit_trust_check.load_cache()
        assert result == {"version": 1, "entries": {}}

    def test_returns_valid_cache_when_file_exists(self, tmp_path):
        cache_file = tmp_path / "trust-cache.json"
        payload = {"version": 1, "entries": {"abc1234_main": {"decision": "allow"}}}
        cache_file.write_text(json.dumps(payload))
        with patch.object(commit_trust_check, "CACHE_FILE", cache_file):
            result = commit_trust_check.load_cache()
        assert result["entries"]["abc1234_main"]["decision"] == "allow"


class TestSaveCache:
    """save_cache writes the dict to disk, creating parent dirs as needed."""

    def test_creates_parent_directories(self, tmp_path):
        cache_file = tmp_path / "nested" / "dir" / "trust-cache.json"
        with patch.object(commit_trust_check, "CACHE_FILE", cache_file):
            commit_trust_check.save_cache({"version": 1, "entries": {}})
        assert cache_file.exists()

    def test_persists_data(self, tmp_path):
        cache_file = tmp_path / "trust-cache.json"
        payload = {"version": 1, "entries": {"key": {"decision": "block"}}}
        with patch.object(commit_trust_check, "CACHE_FILE", cache_file):
            commit_trust_check.save_cache(payload)
            on_disk = json.loads(cache_file.read_text())
        assert on_disk["entries"]["key"]["decision"] == "block"


class TestGetCacheKey:
    """get_cache_key produces a predictable, filesystem-safe key."""

    def test_formats_sha_prefix_and_branch(self):
        key = commit_trust_check.get_cache_key("abc1234567890", "main")
        assert key == "abc1234_main"

    def test_replaces_slashes_in_branch_name(self):
        key = commit_trust_check.get_cache_key("abc1234567890", "feature/my-branch")
        assert key == "abc1234_feature-my-branch"

    def test_uses_first_seven_chars_of_sha(self):
        key = commit_trust_check.get_cache_key("deadbeefcafe", "dev")
        assert key.startswith("deadbee")


class TestInvalidateStaleBranchEntries:
    """invalidate_stale_branch_entries removes old entries for the same branch."""

    def test_removes_old_entries_for_same_branch(self, tmp_path):
        cache_file = tmp_path / "trust-cache.json"
        old_key = commit_trust_check.get_cache_key("oldshaold", "main")
        payload = {
            "version": 1,
            "entries": {
                old_key: {
                    "decision": "allow",
                    "timestamp": time.time() - 600,
                    "commit_sha": "oldshaold",
                    "branch": "main",
                },
            },
        }
        cache_file.write_text(json.dumps(payload))
        with patch.object(commit_trust_check, "CACHE_FILE", cache_file):
            removed = commit_trust_check.invalidate_stale_branch_entries("newsha1234", "main")
        assert removed >= 1

    def test_keeps_entries_for_different_branches(self, tmp_path):
        cache_file = tmp_path / "trust-cache.json"
        other_key = commit_trust_check.get_cache_key("abc1234567", "develop")
        payload = {
            "version": 1,
            "entries": {
                other_key: {"decision": "allow", "timestamp": time.time() - 600},
            },
        }
        cache_file.write_text(json.dumps(payload))
        with patch.object(commit_trust_check, "CACHE_FILE", cache_file):
            removed = commit_trust_check.invalidate_stale_branch_entries("newsha1234", "main")
        assert removed == 0


class TestGetCachedResult:
    """get_cached_result respects the TTL and returns None when expired."""

    def test_returns_none_when_no_entry_exists(self, tmp_path):
        cache_file = tmp_path / "trust-cache.json"
        cache_file.write_text(json.dumps({"version": 1, "entries": {}}))
        with patch.object(commit_trust_check, "CACHE_FILE", cache_file):
            result = commit_trust_check.get_cached_result("abc1234567", "main")
        assert result is None

    def test_returns_none_when_entry_is_expired(self, tmp_path):
        cache_file = tmp_path / "trust-cache.json"
        sha = "abc1234567"
        branch = "main"
        key = commit_trust_check.get_cache_key(sha, branch)
        expired_ts = time.time() - commit_trust_check.CACHE_TTL_SECONDS - 1
        payload = {
            "version": 1,
            "entries": {key: {"decision": "allow", "timestamp": expired_ts}},
        }
        cache_file.write_text(json.dumps(payload))
        with patch.object(commit_trust_check, "CACHE_FILE", cache_file):
            result = commit_trust_check.get_cached_result(sha, branch)
        assert result is None

    def test_returns_entry_when_within_ttl(self, tmp_path):
        cache_file = tmp_path / "trust-cache.json"
        sha = "abc1234567"
        branch = "main"
        key = commit_trust_check.get_cache_key(sha, branch)
        fresh_ts = time.time() - 10
        payload = {
            "version": 1,
            "entries": {key: {"decision": "allow", "timestamp": fresh_ts}},
        }
        cache_file.write_text(json.dumps(payload))
        with patch.object(commit_trust_check, "CACHE_FILE", cache_file):
            result = commit_trust_check.get_cached_result(sha, branch)
        assert result is not None
        assert result["decision"] == "allow"


class TestCacheResult:
    """cache_result stores a result that can be retrieved immediately."""

    def test_stores_and_retrieves_result(self, tmp_path):
        cache_file = tmp_path / "trust-cache.json"
        cache_file.write_text(json.dumps({"version": 1, "entries": {}}))
        sha = "abc1234567"
        branch = "main"
        entry = {"decision": "allow", "reason": "CI passed"}
        with patch.object(commit_trust_check, "CACHE_FILE", cache_file):
            commit_trust_check.cache_result(sha, branch, entry)
            retrieved = commit_trust_check.get_cached_result(sha, branch)
        assert retrieved is not None
        assert retrieved["decision"] == "allow"


# ---------------------------------------------------------------------------
# Git Operations
# ---------------------------------------------------------------------------

class TestGetCurrentCommit:
    """get_current_commit returns HEAD SHA or UNKNOWN on failure."""

    def test_returns_sha_on_success(self):
        mock = _make_subprocess_result(returncode=0, stdout="abc1234567890\n")
        with patch("commit_trust_check.subprocess.run", return_value=mock):
            result = commit_trust_check.get_current_commit()
        assert result == "abc1234567890"

    def test_returns_unknown_on_subprocess_failure(self):
        mock = _make_subprocess_result(returncode=1, stdout="")
        with patch("commit_trust_check.subprocess.run", return_value=mock):
            result = commit_trust_check.get_current_commit()
        assert result == "UNKNOWN"

    def test_returns_unknown_on_exception(self):
        with patch("commit_trust_check.subprocess.run", side_effect=FileNotFoundError):
            result = commit_trust_check.get_current_commit()
        assert result == "UNKNOWN"


class TestGetCommitAgeSeconds:
    """get_commit_age_seconds returns a positive int or -1 on failure."""

    def test_returns_positive_int_for_valid_commit(self):
        timestamp = int(time.time()) - 120
        mock = _make_subprocess_result(returncode=0, stdout=f"{timestamp}\n")
        with patch("commit_trust_check.subprocess.run", return_value=mock):
            age = commit_trust_check.get_commit_age_seconds("abc1234")
        assert age == 120

    def test_returns_negative_one_on_failure(self):
        mock = _make_subprocess_result(returncode=1, stdout="")
        with patch("commit_trust_check.subprocess.run", return_value=mock):
            age = commit_trust_check.get_commit_age_seconds("abc1234")
        assert age == -1

    def test_returns_negative_one_on_exception(self):
        with patch("commit_trust_check.subprocess.run", side_effect=Exception("fail")):
            age = commit_trust_check.get_commit_age_seconds("abc1234")
        assert age == -1


# ---------------------------------------------------------------------------
# CI Status
# ---------------------------------------------------------------------------

class TestCheckCiStatus:
    """check_ci_status parses gh run list output into structured results."""

    def _gh_json(self, conclusion="success", status="completed", name="CI"):
        runs = [{"conclusion": conclusion, "status": status, "name": name}]
        return json.dumps(runs)

    def test_success_conclusion_returns_passed_true(self):
        mock = _make_subprocess_result(returncode=0, stdout=self._gh_json("success"))
        with patch("commit_trust_check.subprocess.run", return_value=mock):
            result = commit_trust_check.check_ci_status("abc1234")
        assert result["passed"] is True
        assert result["status"] == "success"

    def test_failure_conclusion_returns_passed_false(self):
        mock = _make_subprocess_result(returncode=0, stdout=self._gh_json("failure"))
        with patch("commit_trust_check.subprocess.run", return_value=mock):
            result = commit_trust_check.check_ci_status("abc1234")
        assert result["passed"] is False
        assert result["status"] == "failure"

    def test_in_progress_returns_pending_and_not_graceful(self):
        mock = _make_subprocess_result(
            returncode=0, stdout=self._gh_json(conclusion="", status="in_progress")
        )
        with patch("commit_trust_check.subprocess.run", return_value=mock):
            result = commit_trust_check.check_ci_status("abc1234")
        assert result["status"] == "pending"
        assert result.get("graceful") is not True

    def test_empty_runs_returns_not_found(self):
        mock = _make_subprocess_result(returncode=0, stdout="[]")
        with patch("commit_trust_check.subprocess.run", return_value=mock):
            result = commit_trust_check.check_ci_status("abc1234")
        assert result["status"] == "not_found"

    def test_gh_not_found_rc127_is_graceful(self):
        mock = _make_subprocess_result(returncode=127, stdout="", stderr="gh: command not found")
        with patch("commit_trust_check.subprocess.run", return_value=mock):
            result = commit_trust_check.check_ci_status("abc1234")
        assert result.get("graceful") is True

    def test_rate_limit_error_is_graceful(self):
        mock = _make_subprocess_result(
            returncode=1, stdout="", stderr="API rate limit exceeded"
        )
        with patch("commit_trust_check.subprocess.run", return_value=mock):
            result = commit_trust_check.check_ci_status("abc1234")
        assert result.get("graceful") is True

    def test_timeout_is_graceful(self):
        import subprocess
        with patch(
            "commit_trust_check.subprocess.run",
            side_effect=subprocess.TimeoutExpired(cmd="gh", timeout=10),
        ):
            result = commit_trust_check.check_ci_status("abc1234")
        assert result.get("graceful") is True

    def test_invalid_json_is_graceful(self):
        mock = _make_subprocess_result(returncode=0, stdout="not-json")
        with patch("commit_trust_check.subprocess.run", return_value=mock):
            result = commit_trust_check.check_ci_status("abc1234")
        assert result.get("graceful") is True


# ---------------------------------------------------------------------------
# Production Health
# ---------------------------------------------------------------------------

class TestCheckProductionHealth:
    """check_production_health validates health endpoint responses."""

    def _patch_config(self, monkeypatch, health_url):
        monkeypatch.setattr(
            commit_trust_check,
            "get_config",
            lambda key, default=None: health_url if key == "deployment.health_url" else default,
        )

    def test_no_url_configured_returns_healthy_and_graceful(self, monkeypatch):
        self._patch_config(monkeypatch, None)
        result = commit_trust_check.check_production_health()
        assert result["healthy"] is True
        assert result.get("graceful") is True

    def test_invalid_scheme_returns_error(self, monkeypatch):
        self._patch_config(monkeypatch, "file:///etc/passwd")
        result = commit_trust_check.check_production_health()
        assert result["healthy"] is not True
        assert "error" in result

    def test_healthy_response_returns_healthy_true(self, monkeypatch):
        self._patch_config(monkeypatch, "https://example.com/health")
        health_body = json.dumps({"status": "ok", "version": "1.2.3"})
        mock = _make_subprocess_result(returncode=0, stdout=health_body)
        with patch("commit_trust_check.subprocess.run", return_value=mock):
            result = commit_trust_check.check_production_health()
        assert result["healthy"] is True

    def test_unhealthy_json_response_returns_healthy_false(self, monkeypatch):
        self._patch_config(monkeypatch, "https://example.com/health")
        health_body = json.dumps({"status": "error"})
        mock = _make_subprocess_result(returncode=0, stdout=health_body)
        with patch("commit_trust_check.subprocess.run", return_value=mock):
            result = commit_trust_check.check_production_health()
        assert result["healthy"] is False

    def test_curl_failure_returns_healthy_false(self, monkeypatch):
        self._patch_config(monkeypatch, "https://example.com/health")
        mock = _make_subprocess_result(returncode=1, stdout="", stderr="connection refused")
        with patch("commit_trust_check.subprocess.run", return_value=mock):
            result = commit_trust_check.check_production_health()
        assert result["healthy"] is False

    def test_non_json_response_is_graceful(self, monkeypatch):
        self._patch_config(monkeypatch, "https://example.com/health")
        mock = _make_subprocess_result(returncode=0, stdout="OK")
        with patch("commit_trust_check.subprocess.run", return_value=mock):
            result = commit_trust_check.check_production_health()
        assert result.get("graceful") is True

    def test_timeout_is_graceful(self, monkeypatch):
        import subprocess
        self._patch_config(monkeypatch, "https://example.com/health")
        with patch(
            "commit_trust_check.subprocess.run",
            side_effect=subprocess.TimeoutExpired(cmd="curl", timeout=10),
        ):
            result = commit_trust_check.check_production_health()
        assert result.get("graceful") is True


# ---------------------------------------------------------------------------
# Bypass
# ---------------------------------------------------------------------------

class TestCheckBypassFlag:
    """check_bypass_flag respects env var, fresh flag file, and stale flag file."""

    def test_env_var_set_returns_bypass_true_with_env_method(self, monkeypatch, tmp_path):
        monkeypatch.setenv("CLAUDE_TRUST_BYPASS", "1")
        flag_file = tmp_path / "bypass.flag"
        with patch.object(commit_trust_check, "BYPASS_FLAG_FILE", flag_file):
            result = commit_trust_check.check_bypass_flag()
        assert result["bypass"] is True
        assert result["method"] == "env"

    def test_fresh_flag_file_returns_bypass_true_with_file_method(self, monkeypatch, tmp_path):
        monkeypatch.delenv("CLAUDE_TRUST_BYPASS", raising=False)
        flag_file = tmp_path / "bypass.flag"
        flag_file.write_text("bypass")
        with patch.object(commit_trust_check, "BYPASS_FLAG_FILE", flag_file):
            result = commit_trust_check.check_bypass_flag()
        assert result["bypass"] is True
        assert result["method"] == "file"

    def test_stale_flag_file_returns_bypass_false_and_deletes_file(self, monkeypatch, tmp_path):
        monkeypatch.delenv("CLAUDE_TRUST_BYPASS", raising=False)
        flag_file = tmp_path / "bypass.flag"
        flag_file.write_text("bypass")
        # Back-date the file modification time beyond max age
        stale_mtime = time.time() - commit_trust_check.BYPASS_FLAG_MAX_AGE_SECONDS - 1
        import os
        os.utime(flag_file, (stale_mtime, stale_mtime))
        with patch.object(commit_trust_check, "BYPASS_FLAG_FILE", flag_file):
            result = commit_trust_check.check_bypass_flag()
        assert result["bypass"] is False
        assert not flag_file.exists()

    def test_nothing_set_returns_bypass_false(self, monkeypatch, tmp_path):
        monkeypatch.delenv("CLAUDE_TRUST_BYPASS", raising=False)
        flag_file = tmp_path / "bypass.flag"  # does not exist
        with patch.object(commit_trust_check, "BYPASS_FLAG_FILE", flag_file):
            result = commit_trust_check.check_bypass_flag()
        assert result["bypass"] is False


# ---------------------------------------------------------------------------
# verify_commit_trust — orchestration
# ---------------------------------------------------------------------------

class TestVerifyCommitTrust:
    """verify_commit_trust combines CI and health results into a final decision."""

    def _ci_result(self, passed=True, status="success", graceful=False, error=None):
        r = {"passed": passed, "status": status}
        if graceful:
            r["graceful"] = True
        if error:
            r["error"] = error
        return r

    def _health_result(self, healthy=True, graceful=False, error=None):
        r = {"healthy": healthy}
        if graceful:
            r["graceful"] = True
        if error:
            r["error"] = error
        return r

    def test_ci_graceful_error_returns_allow_with_warning(self, monkeypatch):
        ci = self._ci_result(passed=False, status="error", graceful=True, error="gh not found")
        with patch.object(commit_trust_check, "check_ci_status", return_value=ci):
            with patch.object(
                commit_trust_check, "check_production_health", return_value=self._health_result()
            ):
                result = commit_trust_check.verify_commit_trust("abc1234", "feature/x")
        assert result["decision"] == "allow"
        assert result.get("warning")

    def test_ci_not_found_returns_allow_with_warning(self, monkeypatch):
        ci = self._ci_result(passed=False, status="not_found")
        with patch.object(commit_trust_check, "check_ci_status", return_value=ci):
            with patch.object(
                commit_trust_check, "check_production_health", return_value=self._health_result()
            ):
                result = commit_trust_check.verify_commit_trust("abc1234", "feature/x")
        assert result["decision"] == "allow"
        assert result.get("warning")

    def test_ci_pending_returns_allow_with_warning(self, monkeypatch):
        ci = self._ci_result(passed=False, status="pending")
        with patch.object(commit_trust_check, "check_ci_status", return_value=ci):
            with patch.object(
                commit_trust_check, "check_production_health", return_value=self._health_result()
            ):
                result = commit_trust_check.verify_commit_trust("abc1234", "feature/x")
        assert result["decision"] == "allow"
        assert result.get("warning")

    def test_ci_failure_returns_block(self, monkeypatch):
        ci = self._ci_result(passed=False, status="failure")
        with patch.object(commit_trust_check, "check_ci_status", return_value=ci):
            with patch.object(
                commit_trust_check, "check_production_health", return_value=self._health_result()
            ):
                result = commit_trust_check.verify_commit_trust("abc1234", "feature/x")
        assert result["decision"] == "block"

    def test_ci_success_on_feature_branch_returns_allow(self, monkeypatch):
        ci = self._ci_result(passed=True, status="success")
        with patch.object(commit_trust_check, "check_ci_status", return_value=ci):
            with patch.object(
                commit_trust_check, "check_production_health", return_value=self._health_result()
            ):
                result = commit_trust_check.verify_commit_trust("abc1234", "feature/my-feature")
        assert result["decision"] == "allow"

    def test_ci_success_main_branch_health_ok_returns_allow(self, monkeypatch):
        ci = self._ci_result(passed=True, status="success")
        health = self._health_result(healthy=True)
        with patch.object(commit_trust_check, "check_ci_status", return_value=ci):
            with patch.object(commit_trust_check, "check_production_health", return_value=health):
                with patch.object(
                    commit_trust_check, "get_commit_age_seconds", return_value=60
                ):
                    result = commit_trust_check.verify_commit_trust("abc1234", "main")
        assert result["decision"] == "allow"

    def test_ci_success_main_branch_health_fail_returns_block(self, monkeypatch):
        ci = self._ci_result(passed=True, status="success")
        health = self._health_result(healthy=False, error="503")
        with patch.object(commit_trust_check, "check_ci_status", return_value=ci):
            with patch.object(commit_trust_check, "check_production_health", return_value=health):
                result = commit_trust_check.verify_commit_trust("abc1234", "main")
        assert result["decision"] == "block"

    def test_ci_success_main_branch_health_graceful_returns_allow_with_warning(self, monkeypatch):
        ci = self._ci_result(passed=True, status="success")
        health = self._health_result(healthy=False, graceful=True, error="timeout")
        with patch.object(commit_trust_check, "check_ci_status", return_value=ci):
            with patch.object(commit_trust_check, "check_production_health", return_value=health):
                with patch.object(
                    commit_trust_check, "get_commit_age_seconds", return_value=60
                ):
                    result = commit_trust_check.verify_commit_trust("abc1234", "main")
        assert result["decision"] == "allow"
        assert result.get("warning")

    def test_main_branch_young_commit_produces_age_warning(self, monkeypatch):
        ci = self._ci_result(passed=True, status="success")
        health = self._health_result(healthy=True)
        young_age = 30  # well under COMMIT_AGE_WARNING_SECONDS
        with patch.object(commit_trust_check, "check_ci_status", return_value=ci):
            with patch.object(commit_trust_check, "check_production_health", return_value=health):
                with patch.object(
                    commit_trust_check, "get_commit_age_seconds", return_value=young_age
                ):
                    result = commit_trust_check.verify_commit_trust("abc1234", "main")
        # Should still allow but include an age-related warning
        assert result["decision"] == "allow"
        assert result.get("warning")


# ---------------------------------------------------------------------------
# Main entry point
# ---------------------------------------------------------------------------

class TestMain:
    """main() exits with the correct code based on bypass, cache, and verification."""

    def _patch_common(self, monkeypatch, tmp_path):
        """Wire tmp_path cache file and clear bypass env."""
        cache_file = tmp_path / "trust-cache.json"
        cache_file.write_text(json.dumps({"version": 1, "entries": {}}))
        monkeypatch.setattr(commit_trust_check, "CACHE_FILE", cache_file)
        monkeypatch.setenv("CLAUDE_TRUST_BYPASS", "")
        flag_file = tmp_path / "bypass.flag"
        monkeypatch.setattr(commit_trust_check, "BYPASS_FLAG_FILE", flag_file)

    def test_bypass_set_exits_zero(self, monkeypatch, tmp_path):
        self._patch_common(monkeypatch, tmp_path)
        monkeypatch.setattr(
            commit_trust_check,
            "check_bypass_flag",
            lambda: {"bypass": True, "method": "env"},
        )
        with pytest.raises(SystemExit) as exc:
            commit_trust_check.main()
        assert exc.value.code == 0

    def test_unknown_git_state_exits_zero(self, monkeypatch, tmp_path):
        self._patch_common(monkeypatch, tmp_path)
        monkeypatch.setattr(
            commit_trust_check, "check_bypass_flag", lambda: {"bypass": False}
        )
        monkeypatch.setattr(commit_trust_check, "get_current_commit", lambda: "UNKNOWN")
        with pytest.raises(SystemExit) as exc:
            commit_trust_check.main()
        assert exc.value.code == 0

    def test_cached_allow_exits_zero(self, monkeypatch, tmp_path):
        cache_file = tmp_path / "trust-cache.json"
        sha = "abc1234567"
        branch = "main"
        key = commit_trust_check.get_cache_key(sha, branch)
        payload = {
            "version": 1,
            "entries": {key: {"decision": "allow", "timestamp": time.time() - 10}},
        }
        cache_file.write_text(json.dumps(payload))
        monkeypatch.setattr(commit_trust_check, "CACHE_FILE", cache_file)
        flag_file = tmp_path / "bypass.flag"
        monkeypatch.setattr(commit_trust_check, "BYPASS_FLAG_FILE", flag_file)
        monkeypatch.delenv("CLAUDE_TRUST_BYPASS", raising=False)
        monkeypatch.setattr(
            commit_trust_check, "check_bypass_flag", lambda: {"bypass": False}
        )
        monkeypatch.setattr(commit_trust_check, "get_current_commit", lambda: sha)
        monkeypatch.setattr(commit_trust_check, "get_current_branch", lambda: branch)
        with pytest.raises(SystemExit) as exc:
            commit_trust_check.main()
        assert exc.value.code == 0

    def test_cached_block_exits_one(self, monkeypatch, tmp_path):
        cache_file = tmp_path / "trust-cache.json"
        sha = "abc1234567"
        branch = "main"
        key = commit_trust_check.get_cache_key(sha, branch)
        payload = {
            "version": 1,
            "entries": {key: {"decision": "block", "timestamp": time.time() - 10}},
        }
        cache_file.write_text(json.dumps(payload))
        monkeypatch.setattr(commit_trust_check, "CACHE_FILE", cache_file)
        flag_file = tmp_path / "bypass.flag"
        monkeypatch.setattr(commit_trust_check, "BYPASS_FLAG_FILE", flag_file)
        monkeypatch.delenv("CLAUDE_TRUST_BYPASS", raising=False)
        monkeypatch.setattr(
            commit_trust_check, "check_bypass_flag", lambda: {"bypass": False}
        )
        monkeypatch.setattr(commit_trust_check, "get_current_commit", lambda: sha)
        monkeypatch.setattr(commit_trust_check, "get_current_branch", lambda: branch)
        with pytest.raises(SystemExit) as exc:
            commit_trust_check.main()
        assert exc.value.code == 1

    def test_fresh_verification_allow_exits_zero(self, monkeypatch, tmp_path):
        self._patch_common(monkeypatch, tmp_path)
        monkeypatch.setattr(
            commit_trust_check, "check_bypass_flag", lambda: {"bypass": False}
        )
        monkeypatch.setattr(commit_trust_check, "get_current_commit", lambda: "abc1234567")
        monkeypatch.setattr(commit_trust_check, "get_current_branch", lambda: "feature/x")
        monkeypatch.setattr(
            commit_trust_check,
            "verify_commit_trust",
            lambda sha, branch: {"decision": "allow", "reason": "CI passed"},
        )
        with pytest.raises(SystemExit) as exc:
            commit_trust_check.main()
        assert exc.value.code == 0

    def test_fresh_verification_block_exits_one(self, monkeypatch, tmp_path):
        self._patch_common(monkeypatch, tmp_path)
        monkeypatch.setattr(
            commit_trust_check, "check_bypass_flag", lambda: {"bypass": False}
        )
        monkeypatch.setattr(commit_trust_check, "get_current_commit", lambda: "abc1234567")
        monkeypatch.setattr(commit_trust_check, "get_current_branch", lambda: "feature/x")
        monkeypatch.setattr(
            commit_trust_check,
            "verify_commit_trust",
            lambda sha, branch: {"decision": "block", "reason": "CI failed"},
        )
        with pytest.raises(SystemExit) as exc:
            commit_trust_check.main()
        assert exc.value.code == 1
