"""Tests for the cost routing script.

Tests the classification logic that determines which review agents
to run based on changed files and diff size.
"""

import pytest
from scripts.cost_routing import classify_change_type, route_by_loc, get_review_agents, format_as_tasks


class TestClassifyChangeType:
    """Classify changes into type categories based on file patterns."""

    def test_docs_only(self):
        files = ["README.md", "docs/architecture.md", "CHANGELOG.txt"]
        assert classify_change_type(files) == "docs-only"

    def test_config_only(self):
        files = ["config/framework.yaml", "tsconfig.json", "pyproject.toml"]
        assert classify_change_type(files) == "config-only"

    def test_deps_only_lockfile(self):
        files = ["package-lock.json", "yarn.lock"]
        assert classify_change_type(files) == "deps-only"

    def test_deps_only_manifest(self):
        files = ["requirements.txt", "package.json"]
        assert classify_change_type(files) == "deps-only"

    def test_style_only(self):
        files = ["src/styles/main.css", "components/button.scss"]
        assert classify_change_type(files) == "style-only"

    def test_test_only(self):
        files = ["tests/test_auth.py", "src/components/Button.test.tsx"]
        assert classify_change_type(files) == "test-only"

    def test_test_only_spec(self):
        files = ["spec/auth_spec.rb", "tests/unit/user.spec.ts"]
        assert classify_change_type(files) == "test-only"

    def test_mixed_returns_mixed(self):
        files = ["src/auth.py", "README.md", "tests/test_auth.py"]
        assert classify_change_type(files) == "mixed"

    def test_code_only_returns_mixed(self):
        files = ["src/auth.py", "src/models/user.py"]
        assert classify_change_type(files) == "mixed"

    def test_empty_files(self):
        assert classify_change_type([]) == "mixed"

    def test_config_with_auth_file_is_not_config_only(self):
        """Auth-related config files should NOT be classified as config-only."""
        files = ["auth.json", ".env.example"]
        assert classify_change_type(files) != "config-only"


class TestRouteByLoc:
    """Route review strategy based on lines of code changed."""

    def test_tiny_diff(self):
        result = route_by_loc(10)
        assert result["strategy"] == "minimal"
        assert "fw-review-code" in result["agents"]
        assert len(result["agents"]) == 1

    def test_small_diff(self):
        result = route_by_loc(50)
        assert result["strategy"] == "standard"

    def test_medium_diff(self):
        result = route_by_loc(300)
        assert result["strategy"] == "extended"
        assert "fw-review-maintainability" in result["agents"]
        assert "fw-review-forensics" in result["agents"]

    def test_large_diff(self):
        result = route_by_loc(600)
        assert result["strategy"] == "full"
        assert "fw-review-forensics" in result["agents"]
        assert result["code_reviewer_tier"] == "high"

    def test_boundary_20(self):
        assert route_by_loc(19)["strategy"] == "minimal"
        assert route_by_loc(20)["strategy"] == "standard"

    def test_boundary_200(self):
        assert route_by_loc(200)["strategy"] == "standard"
        assert route_by_loc(201)["strategy"] == "extended"

    def test_boundary_500(self):
        assert route_by_loc(500)["strategy"] == "extended"
        assert route_by_loc(501)["strategy"] == "full"


class TestGetReviewAgents:
    """Integration: combine change type, LOC, and file patterns into agent list."""

    def test_docs_only_gets_documentation_reviewer(self):
        agents = get_review_agents(
            files=["README.md", "docs/guide.md"],
            loc_changed=30,
        )
        assert agents == ["fw-review-docs"]

    def test_deps_only_gets_dependencies(self):
        agents = get_review_agents(
            files=["package-lock.json"],
            loc_changed=100,
        )
        assert "fw-review-code" in agents
        assert "fw-review-dependencies" in agents

    def test_test_only_gets_testing_expert(self):
        agents = get_review_agents(
            files=["tests/test_auth.py"],
            loc_changed=50,
        )
        assert "fw-review-code" in agents
        assert "fw-review-tests" in agents

    def test_auth_files_get_security_expert(self):
        """Auth files in mixed diffs must trigger fw-review-security."""
        agents = get_review_agents(
            files=["src/auth_middleware.py", "src/models.py"],
            loc_changed=50,
        )
        assert "fw-review-security" in agents

    def test_tiny_mixed_gets_code_reviewer_only(self):
        agents = get_review_agents(
            files=["src/utils.py"],
            loc_changed=5,
        )
        assert agents == ["fw-review-code"]

    def test_large_diff_includes_fw_review_forensics(self):
        agents = get_review_agents(
            files=["src/auth.py", "src/models.py"],
            loc_changed=250,
        )
        assert "fw-review-forensics" in agents
        assert "fw-review-maintainability" in agents

    def test_migration_files_include_migration_author(self):
        agents = get_review_agents(
            files=["migrations/001_create_users.sql", "src/models.py"],
            loc_changed=50,
        )
        assert "fw-author-migration" in agents

    def test_api_route_files_include_api_reviewer(self):
        agents = get_review_agents(
            files=["src/routes/users.py", "src/api/auth.ts"],
            loc_changed=50,
        )
        assert "fw-review-api-contracts" in agents

    def test_ui_component_files_include_ux_specialist(self):
        agents = get_review_agents(
            files=["src/components/Dashboard.tsx", "src/pages/Home.vue"],
            loc_changed=50,
        )
        assert "fw-review-ux" in agents

    def test_error_handling_files_include_fw_review_silent_failures(self):
        agents = get_review_agents(
            files=["src/error_handler.py", "src/middleware.py"],
            loc_changed=50,
        )
        assert "fw-review-error-handling" in agents

    def test_type_definition_files_include_fw_review_type_design(self):
        agents = get_review_agents(
            files=["src/models/user.py", "src/schema.py"],
            loc_changed=50,
        )
        assert "fw-review-types" in agents

    def test_no_duplicates(self):
        agents = get_review_agents(
            files=["src/auth.py"],
            loc_changed=300,
        )
        assert len(agents) == len(set(agents))

    def test_code_reviewer_always_present_for_mixed(self):
        agents = get_review_agents(
            files=["src/auth.py"],
            loc_changed=50,
        )
        assert "fw-review-code" in agents

    def test_final_gate_mode(self):
        """Final gate always includes the mandatory set."""
        agents = get_review_agents(
            files=["src/auth.py"],
            loc_changed=50,
            final_gate=True,
        )
        assert "fw-review-code" in agents
        assert "fw-review-docs" in agents
        assert "fw-review-security" in agents
        assert "fw-review-forensics" in agents
        assert "fw-review-comments" in agents
        assert "fw-review-error-handling" in agents
        assert "fw-review-types" in agents


class TestFormatAsTasks:
    """AC-6: Convert agent list to Agent Teams task definitions with dependencies."""

    def test_returns_list_of_task_dicts(self):
        agents = ["fw-review-code", "fw-review-security"]
        tasks = format_as_tasks(agents)
        assert isinstance(tasks, list)
        assert len(tasks) == 2

    def test_each_task_has_required_fields(self):
        tasks = format_as_tasks(["fw-review-code"])
        task = tasks[0]
        assert "teammate_type" in task
        assert "task_subject" in task
        assert "blockedBy" in task

    def test_teammate_type_matches_agent_name(self):
        agents = ["fw-review-code", "fw-review-security", "fw-review-tests"]
        tasks = format_as_tasks(agents)
        types = [t["teammate_type"] for t in tasks]
        assert types == agents

    def test_no_predecessor_gives_empty_blocked_by(self):
        tasks = format_as_tasks(["fw-review-code"])
        assert tasks[0]["blockedBy"] == []

    def test_predecessor_populates_blocked_by(self):
        tasks = format_as_tasks(
            ["fw-review-code", "fw-review-security"],
            predecessor_task_id="tdd-refactor-42",
        )
        for task in tasks:
            assert "tdd-refactor-42" in task["blockedBy"]

    def test_task_subject_is_human_readable(self):
        tasks = format_as_tasks(["fw-review-code"])
        subject = tasks[0]["task_subject"]
        assert isinstance(subject, str)
        assert len(subject) > 5  # Not empty/trivial

    def test_empty_agent_list_returns_empty(self):
        assert format_as_tasks([]) == []

    def test_single_agent(self):
        tasks = format_as_tasks(["fw-author-migration"])
        assert len(tasks) == 1
        assert tasks[0]["teammate_type"] == "fw-author-migration"

    def test_backward_compat_get_review_agents_unchanged(self):
        """AC-1: Existing get_review_agents behavior is unaffected."""
        agents = get_review_agents(
            files=["src/auth.py"],
            loc_changed=50,
        )
        assert "fw-review-code" in agents
        assert isinstance(agents, list)
        assert all(isinstance(a, str) for a in agents)
