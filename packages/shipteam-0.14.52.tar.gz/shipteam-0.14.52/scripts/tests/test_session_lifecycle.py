"""Tests for the session-lifecycle hook (.claude/hooks/session-lifecycle.py).

Covers session lock creation, stale lock reclamation, and live lock preservation.
"""

import importlib
import importlib.util
import json
import os
import sys
from datetime import datetime
from pathlib import Path
from unittest.mock import patch

import pytest

# Import the hyphenated module via importlib
_hooks_dir = str(Path(__file__).resolve().parent.parent.parent / ".claude" / "hooks")
sys.path.insert(0, _hooks_dir)

_spec = importlib.util.spec_from_file_location(
    "session_lifecycle", os.path.join(_hooks_dir, "session-lifecycle.py")
)
session_lifecycle = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(session_lifecycle)


def _setup_module(tmp_path):
    """Redirect all module-level path constants to tmp_path for isolation."""
    state_dir = tmp_path / ".claude" / "state"
    state_dir.mkdir(parents=True, exist_ok=True)

    session_lifecycle.PROJECT_ROOT = tmp_path
    session_lifecycle.STATE_DIR = state_dir
    session_lifecycle.SESSION_LOCK_FILE = state_dir / "session-lock.json"


# ---------------------------------------------------------------------------
# create_session_lock
# ---------------------------------------------------------------------------


class TestCreateSessionLock:
    def test_creates_lock_when_none_exists(self, tmp_path):
        _setup_module(tmp_path)
        result = session_lifecycle.create_session_lock("abc123", "feature/test")

        assert result is True
        lock_file = tmp_path / ".claude" / "state" / "session-lock.json"
        assert lock_file.exists()
        data = json.loads(lock_file.read_text())
        assert data["session_id"] == "abc123"
        assert data["branch"] == "feature/test"
        assert data["pid"] == os.getpid()
        assert "started_at" in data
        assert "last_heartbeat" in data

    def test_overwrites_stale_lock(self, tmp_path):
        """A lock whose PID is dead should be reclaimed."""
        _setup_module(tmp_path)
        lock_file = tmp_path / ".claude" / "state" / "session-lock.json"

        # Write a lock with a PID that definitely doesn't exist
        stale_lock = {
            "session_id": "old",
            "pid": 99999999,
            "branch": "old-branch",
            "started_at": "2020-01-01T00:00:00",
            "last_heartbeat": "2020-01-01T00:00:00",
        }
        lock_file.write_text(json.dumps(stale_lock))

        with patch("os.kill", side_effect=ProcessLookupError):
            result = session_lifecycle.create_session_lock("new123", "feature/new")

        assert result is True
        data = json.loads(lock_file.read_text())
        assert data["session_id"] == "new123"
        assert data["branch"] == "feature/new"

    def test_preserves_live_lock(self, tmp_path):
        """A lock whose PID is alive should NOT be overwritten."""
        _setup_module(tmp_path)
        lock_file = tmp_path / ".claude" / "state" / "session-lock.json"

        live_lock = {
            "session_id": "live",
            "pid": 12345,
            "branch": "feature/active",
            "started_at": datetime.now().isoformat(),
            "last_heartbeat": datetime.now().isoformat(),
        }
        lock_file.write_text(json.dumps(live_lock))

        # os.kill(pid, 0) succeeds if process is alive (no exception)
        with patch("os.kill", return_value=None):
            result = session_lifecycle.create_session_lock("intruder", "feature/steal")

        assert result is False
        data = json.loads(lock_file.read_text())
        assert data["session_id"] == "live"  # Unchanged

    def test_overwrites_own_pid_lock(self, tmp_path):
        """A lock from our own PID should be overwritten (session restart)."""
        _setup_module(tmp_path)
        lock_file = tmp_path / ".claude" / "state" / "session-lock.json"

        own_lock = {
            "session_id": "old-self",
            "pid": os.getpid(),
            "branch": "old-branch",
            "started_at": "2020-01-01T00:00:00",
            "last_heartbeat": "2020-01-01T00:00:00",
        }
        lock_file.write_text(json.dumps(own_lock))

        result = session_lifecycle.create_session_lock("new-self", "feature/restart")

        assert result is True
        data = json.loads(lock_file.read_text())
        assert data["session_id"] == "new-self"

    def test_overwrites_corrupt_lock(self, tmp_path):
        """A corrupt lock file should be overwritten."""
        _setup_module(tmp_path)
        lock_file = tmp_path / ".claude" / "state" / "session-lock.json"
        lock_file.write_text("{not valid json")

        result = session_lifecycle.create_session_lock("fix", "main")

        assert result is True
        data = json.loads(lock_file.read_text())
        assert data["session_id"] == "fix"

    def test_creates_state_dir_if_missing(self, tmp_path):
        """Should create .claude/state/ if it doesn't exist yet."""
        _setup_module(tmp_path)
        # Remove the state dir that _setup_module created
        import shutil
        state_dir = tmp_path / ".claude" / "state"
        shutil.rmtree(state_dir)
        assert not state_dir.exists()

        result = session_lifecycle.create_session_lock("first", "main")

        assert result is True
        assert state_dir.exists()
