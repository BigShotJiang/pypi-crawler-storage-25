"""Tests for .claude/hooks/metrics-tracker.py — SubagentStart event logging.

Covers agent spawn event emission (AC-1), async non-blocking behavior (AC-2),
and graceful degradation when event log is unavailable (AC-4).
"""

import json
import subprocess
import sys
from pathlib import Path
from unittest.mock import patch, MagicMock

import pytest


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

HOOK_PATH = Path(__file__).resolve().parent.parent.parent / ".claude" / "hooks" / "metrics-tracker.py"


def _make_framework_yaml(tmp_path: Path, enabled: bool = True) -> Path:
    """Write a minimal framework.yaml with metrics.enabled set."""
    config_dir = tmp_path / "config"
    config_dir.mkdir(parents=True, exist_ok=True)
    content = f"metrics:\n  enabled: {str(enabled).lower()}\n"
    yaml_path = config_dir / "framework.yaml"
    yaml_path.write_text(content)
    return yaml_path


def _make_session_lock(tmp_path: Path, session_id: str = "test123") -> Path:
    """Write a minimal session-lock.json."""
    state_dir = tmp_path / ".claude" / "state"
    state_dir.mkdir(parents=True, exist_ok=True)
    lock_path = state_dir / "session-lock.json"
    lock_path.write_text(json.dumps({"session_id": session_id}))
    return lock_path


def _run_hook(tmp_path: Path, stdin_data: dict) -> subprocess.CompletedProcess:
    """Run the metrics-tracker hook with given stdin JSON in tmp_path as cwd."""
    return subprocess.run(
        [sys.executable, str(HOOK_PATH)],
        input=json.dumps(stdin_data),
        capture_output=True,
        text=True,
        cwd=str(tmp_path),
        timeout=5,
    )


# ---------------------------------------------------------------------------
# TestSubagentStartLogging — AC-1
# ---------------------------------------------------------------------------

class TestSubagentStartLogging:
    """AC-1: SubagentStart events are logged with agent_type."""

    def test_logs_agent_spawn_event(self, tmp_path):
        """AC-1: agent_spawn event is written to the event log."""
        _make_framework_yaml(tmp_path, enabled=True)
        _make_session_lock(tmp_path)
        # Create scripts dir with fw_event_log.py accessible
        scripts_dir = tmp_path / "scripts"
        scripts_dir.mkdir()
        # Copy fw_event_log.py to tmp_path
        real_event_log = Path(__file__).resolve().parent.parent / "fw_event_log.py"
        (scripts_dir / "fw_event_log.py").write_text(real_event_log.read_text())

        result = _run_hook(tmp_path, {
            "hook_event_name": "SubagentStart",
            "session_id": "sess-abc",
            "agent_type": "fw-review-code",
            "agent_id": "agent-123",
        })

        assert result.returncode == 0

        # Check event was logged
        metrics_dir = tmp_path / ".context" / "metrics"
        jsonl_files = list(metrics_dir.glob("events-*.jsonl"))
        assert len(jsonl_files) >= 1

        events = []
        for f in jsonl_files:
            for line in f.read_text().splitlines():
                if line.strip():
                    events.append(json.loads(line))

        spawn_events = [e for e in events if e.get("event") == "agent_spawn"]
        assert len(spawn_events) == 1
        assert spawn_events[0]["category"] == "cost"
        assert spawn_events[0]["data"]["agent_type"] == "fw-review-code"

    def test_logs_agent_id(self, tmp_path):
        """AC-1: agent_id is included in the event data."""
        _make_framework_yaml(tmp_path, enabled=True)
        _make_session_lock(tmp_path)
        scripts_dir = tmp_path / "scripts"
        scripts_dir.mkdir()
        real_event_log = Path(__file__).resolve().parent.parent / "fw_event_log.py"
        (scripts_dir / "fw_event_log.py").write_text(real_event_log.read_text())

        _run_hook(tmp_path, {
            "hook_event_name": "SubagentStart",
            "agent_type": "fw-review-security",
            "agent_id": "agent-456",
        })

        metrics_dir = tmp_path / ".context" / "metrics"
        events = []
        for f in metrics_dir.glob("events-*.jsonl"):
            for line in f.read_text().splitlines():
                if line.strip():
                    events.append(json.loads(line))

        spawn_events = [e for e in events if e.get("event") == "agent_spawn"]
        assert spawn_events[0]["data"]["agent_id"] == "agent-456"

    def test_ignores_non_subagent_events(self, tmp_path):
        """Hook exits cleanly for non-SubagentStart events."""
        _make_framework_yaml(tmp_path, enabled=True)
        _make_session_lock(tmp_path)

        result = _run_hook(tmp_path, {
            "hook_event_name": "PostToolUse",
            "tool_name": "Bash",
            "tool_input": {"command": "ls"},
        })

        assert result.returncode == 0
        # No events should be logged
        metrics_dir = tmp_path / ".context" / "metrics"
        if metrics_dir.exists():
            jsonl_files = list(metrics_dir.glob("events-*.jsonl"))
            if jsonl_files:
                content = jsonl_files[0].read_text().strip()
                assert content == "" or "agent_spawn" not in content


# ---------------------------------------------------------------------------
# TestHookPerformance — AC-2
# ---------------------------------------------------------------------------

class TestHookPerformance:
    """AC-2: hook is fast and non-blocking."""

    def test_completes_within_timeout(self, tmp_path):
        """AC-2: hook completes in well under 5 seconds."""
        _make_framework_yaml(tmp_path, enabled=True)
        _make_session_lock(tmp_path)
        scripts_dir = tmp_path / "scripts"
        scripts_dir.mkdir()
        real_event_log = Path(__file__).resolve().parent.parent / "fw_event_log.py"
        (scripts_dir / "fw_event_log.py").write_text(real_event_log.read_text())

        import time
        start = time.monotonic()
        result = _run_hook(tmp_path, {
            "hook_event_name": "SubagentStart",
            "agent_type": "fw-review-code",
            "agent_id": "agent-perf",
        })
        elapsed = time.monotonic() - start

        assert result.returncode == 0
        assert elapsed < 2.0  # Should be well under 100ms, 2s is generous


# ---------------------------------------------------------------------------
# TestGracefulDegradation — AC-4
# ---------------------------------------------------------------------------

class TestGracefulDegradation:
    """AC-4: hook succeeds even when event log infrastructure is missing."""

    def test_succeeds_without_framework_yaml(self, tmp_path):
        """AC-4: no config file → hook exits 0 without logging."""
        # No framework.yaml created
        result = _run_hook(tmp_path, {
            "hook_event_name": "SubagentStart",
            "agent_type": "fw-review-code",
            "agent_id": "agent-noconfig",
        })

        assert result.returncode == 0

    def test_succeeds_without_event_log_module(self, tmp_path):
        """AC-4: fw_event_log.py not importable → hook exits 0."""
        _make_framework_yaml(tmp_path, enabled=True)
        _make_session_lock(tmp_path)
        # Don't create scripts/fw_event_log.py

        result = _run_hook(tmp_path, {
            "hook_event_name": "SubagentStart",
            "agent_type": "fw-review-code",
            "agent_id": "agent-nolog",
        })

        assert result.returncode == 0

    def test_succeeds_with_malformed_stdin(self, tmp_path):
        """AC-4: invalid JSON stdin → hook exits 0."""
        result = subprocess.run(
            [sys.executable, str(HOOK_PATH)],
            input="not valid json{{{",
            capture_output=True,
            text=True,
            cwd=str(tmp_path),
            timeout=5,
        )

        assert result.returncode == 0

    def test_succeeds_with_empty_stdin(self, tmp_path):
        """AC-4: empty stdin → hook exits 0."""
        result = subprocess.run(
            [sys.executable, str(HOOK_PATH)],
            input="",
            capture_output=True,
            text=True,
            cwd=str(tmp_path),
            timeout=5,
        )

        assert result.returncode == 0


# ---------------------------------------------------------------------------
# TestAgentTeamsEvents — Agent Teams hook events
# ---------------------------------------------------------------------------

class TestAgentTeamsEvents:
    """Agent Teams: TaskCreated, TaskCompleted, TeammateIdle events are logged."""

    def test_logs_task_created_event(self, tmp_path):
        """TaskCreated events produce task_created log entries."""
        _make_framework_yaml(tmp_path, enabled=True)
        _make_session_lock(tmp_path)
        scripts_dir = tmp_path / "scripts"
        scripts_dir.mkdir()
        real_event_log = Path(__file__).resolve().parent.parent / "fw_event_log.py"
        (scripts_dir / "fw_event_log.py").write_text(real_event_log.read_text())

        result = _run_hook(tmp_path, {
            "hook_event_name": "TaskCreated",
            "task_id": "task-1",
            "teammate_type": "fw-review-code",
            "blocked_by": ["tdd-refactor-1"],
        })

        assert result.returncode == 0
        metrics_dir = tmp_path / ".context" / "metrics"
        events = []
        for f in metrics_dir.glob("events-*.jsonl"):
            for line in f.read_text().splitlines():
                if line.strip():
                    events.append(json.loads(line))
        created = [e for e in events if e.get("event") == "task_created"]
        assert len(created) == 1
        assert created[0]["category"] == "team"
        assert created[0]["data"]["teammate_type"] == "fw-review-code"

    def test_logs_task_completed_event(self, tmp_path):
        """TaskCompleted events produce task_completed log entries."""
        _make_framework_yaml(tmp_path, enabled=True)
        _make_session_lock(tmp_path)
        scripts_dir = tmp_path / "scripts"
        scripts_dir.mkdir()
        real_event_log = Path(__file__).resolve().parent.parent / "fw_event_log.py"
        (scripts_dir / "fw_event_log.py").write_text(real_event_log.read_text())

        result = _run_hook(tmp_path, {
            "hook_event_name": "TaskCompleted",
            "task_id": "task-2",
            "teammate_type": "fw-review-security",
            "duration_seconds": 45.2,
        })

        assert result.returncode == 0
        metrics_dir = tmp_path / ".context" / "metrics"
        events = []
        for f in metrics_dir.glob("events-*.jsonl"):
            for line in f.read_text().splitlines():
                if line.strip():
                    events.append(json.loads(line))
        completed = [e for e in events if e.get("event") == "task_completed"]
        assert len(completed) == 1
        assert completed[0]["category"] == "team"
        assert completed[0]["data"]["task_id"] == "task-2"

    def test_logs_teammate_idle_event(self, tmp_path):
        """TeammateIdle events produce teammate_idle log entries."""
        _make_framework_yaml(tmp_path, enabled=True)
        _make_session_lock(tmp_path)
        scripts_dir = tmp_path / "scripts"
        scripts_dir.mkdir()
        real_event_log = Path(__file__).resolve().parent.parent / "fw_event_log.py"
        (scripts_dir / "fw_event_log.py").write_text(real_event_log.read_text())

        result = _run_hook(tmp_path, {
            "hook_event_name": "TeammateIdle",
            "teammate_type": "fw-tdd-green",
        })

        assert result.returncode == 0
        metrics_dir = tmp_path / ".context" / "metrics"
        events = []
        for f in metrics_dir.glob("events-*.jsonl"):
            for line in f.read_text().splitlines():
                if line.strip():
                    events.append(json.loads(line))
        idle = [e for e in events if e.get("event") == "teammate_idle"]
        assert len(idle) == 1
        assert idle[0]["category"] == "team"
