"""Tests for .claude/hooks/task-quality-gate.py — TaskCompleted quality gate.

Validates that reviewer task completions are checked for Critical/High issues
and that the hook blocks on Critical findings.
"""

import json
import subprocess
import sys
from pathlib import Path

import pytest


HOOK_PATH = Path(__file__).resolve().parent.parent.parent / ".claude" / "hooks" / "task-quality-gate.py"


def _run_hook(stdin_data: dict) -> subprocess.CompletedProcess:
    return subprocess.run(
        [sys.executable, str(HOOK_PATH)],
        input=json.dumps(stdin_data),
        capture_output=True,
        text=True,
        timeout=5,
    )


class TestQualityGate:
    """Task quality gate blocks on Critical issues."""

    def test_allows_clean_review(self):
        result = _run_hook({
            "hook_event_name": "TaskCompleted",
            "teammate_type": "fw-review-code",
            "result": "All good. No issues found. APPROVE.",
        })
        assert result.returncode == 0
        output = json.loads(result.stdout)
        assert output["verdict"] == "APPROVE"
        assert output["critical_count"] == 0

    def test_blocks_on_critical(self):
        result = _run_hook({
            "hook_event_name": "TaskCompleted",
            "teammate_type": "fw-review-security",
            "result": "Critical: 2 issues found. SQL injection in auth handler. BLOCK.",
        })
        assert result.returncode == 2
        assert "Critical" in result.stderr

    def test_warns_on_high(self):
        result = _run_hook({
            "hook_event_name": "TaskCompleted",
            "teammate_type": "fw-review-code",
            "result": "High: 3 issues found. Missing error handling.",
        })
        assert result.returncode == 0
        output = json.loads(result.stdout)
        assert output["verdict"] == "WARNING"
        assert output["high_count"] == 3

    def test_ignores_non_reviewer_agents(self):
        result = _run_hook({
            "hook_event_name": "TaskCompleted",
            "teammate_type": "fw-tdd-green",
            "result": "Critical: 5 issues. BLOCK.",
        })
        # TDD agents are not review agents — should pass through
        assert result.returncode == 0

    def test_ignores_non_task_completed_events(self):
        result = _run_hook({
            "hook_event_name": "TaskCreated",
            "teammate_type": "fw-review-code",
        })
        assert result.returncode == 0

    def test_handles_empty_stdin(self):
        result = subprocess.run(
            [sys.executable, str(HOOK_PATH)],
            input="",
            capture_output=True,
            text=True,
            timeout=5,
        )
        assert result.returncode == 0

    def test_handles_malformed_json(self):
        result = subprocess.run(
            [sys.executable, str(HOOK_PATH)],
            input="not json{{{",
            capture_output=True,
            text=True,
            timeout=5,
        )
        assert result.returncode == 0

    def test_detects_block_verdict_keyword(self):
        result = _run_hook({
            "hook_event_name": "TaskCompleted",
            "teammate_type": "fw-review-code",
            "result": "Verdict: BLOCK. Unsafe pattern detected.",
        })
        assert result.returncode == 2

    def test_gates_fw_author_migration(self):
        """fw-author-migration is also a gated reviewer."""
        result = _run_hook({
            "hook_event_name": "TaskCompleted",
            "teammate_type": "fw-author-migration",
            "result": "Critical: 1 — missing rollback script.",
        })
        assert result.returncode == 2
