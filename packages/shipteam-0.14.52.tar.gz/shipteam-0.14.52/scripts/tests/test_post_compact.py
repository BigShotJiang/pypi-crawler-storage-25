"""Tests for .claude/hooks/post-compact-restore.py — PostCompact context restoration.

Covers plan-aware context restoration (AC-4) and graceful no-plan path (AC-5),
plus edge cases: missing handoff file and no TDD commits in git log.
"""

import importlib.util
import json
import subprocess
import sys
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest


# ---------------------------------------------------------------------------
# Module import (hyphenated filename requires importlib)
# ---------------------------------------------------------------------------

HOOK_PATH = (
    Path(__file__).resolve().parent.parent.parent
    / ".claude"
    / "hooks"
    / "post-compact-restore.py"
)


def _load_hook():
    """Load the post-compact-restore module via importlib."""
    spec = importlib.util.spec_from_file_location(
        "post_compact_restore", str(HOOK_PATH)
    )
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_sherlock_plan(tmp_path: Path, tier: str = "Sherlock Lite", status: str = "APPROVED") -> Path:
    """Write a minimal .sherlock-plan.md with the given tier and status."""
    plan_path = tmp_path / ".sherlock-plan.md"
    plan_path.write_text(
        f"# Sherlock Plan: Test Feature\n"
        f"Created: 2026-03-31\n"
        f"Tier: {tier}\n"
        f"Status: {status}\n"
        f"\n"
        f"## Acceptance Criteria\n"
        f"### AC-1: Some behavior\n"
        f"- Given something\n"
        f"- When something happens\n"
        f"- Then something results\n"
    )
    return plan_path


def _make_handoff_file(tmp_path: Path, branch: str = "feature/test", session_id: str = "abc12345") -> Path:
    """Write a minimal pre-compact-handoff.json in the expected state directory."""
    state_dir = tmp_path / ".claude" / "state"
    state_dir.mkdir(parents=True, exist_ok=True)
    handoff_path = state_dir / "pre-compact-handoff.json"
    handoff_path.write_text(json.dumps({
        "branch": branch,
        "session_id": session_id,
        "compacted_at": "2026-03-31T10:00:00",
        "pr_title": "feat: test feature",
    }))
    return handoff_path


def _run_hook(tmp_path: Path, stdin_data: dict | None = None) -> subprocess.CompletedProcess:
    """Run the post-compact-restore hook as a subprocess with tmp_path as cwd."""
    input_text = json.dumps(stdin_data) if stdin_data is not None else "{}"
    return subprocess.run(
        [sys.executable, str(HOOK_PATH)],
        input=input_text,
        capture_output=True,
        text=True,
        cwd=str(tmp_path),
        timeout=5,
    )


# ---------------------------------------------------------------------------
# TestPlanAwareRestoration — AC-4
# ---------------------------------------------------------------------------


class TestPlanAwareRestoration:
    """AC-4: When .sherlock-plan.md exists, stderr includes plan tier, status, and TDD phase."""

    def test_ac4_stderr_includes_plan_tier(self, tmp_path, monkeypatch):
        """AC-4: stderr output mentions the plan tier when plan file exists."""
        _make_sherlock_plan(tmp_path, tier="Sherlock Lite", status="APPROVED")
        _make_handoff_file(tmp_path)

        hook = _load_hook()
        hook.PROJECT_ROOT = tmp_path

        tdd_commit_line = "abc1234 tdd(green): implement event log levels"
        git_mock = MagicMock(returncode=0, stdout=tdd_commit_line + "\n")

        with patch("subprocess.run", return_value=git_mock):
            import io
            stderr_capture = io.StringIO()
            with patch("sys.stderr", stderr_capture):
                hook.main()

        output = stderr_capture.getvalue()
        assert "Sherlock Lite" in output

    def test_ac4_stderr_includes_plan_status(self, tmp_path):
        """AC-4: stderr output mentions the plan status when plan file exists."""
        _make_sherlock_plan(tmp_path, tier="Sherlock Lite", status="APPROVED")
        _make_handoff_file(tmp_path)

        hook = _load_hook()
        hook.PROJECT_ROOT = tmp_path

        git_mock = MagicMock(returncode=0, stdout="abc1234 tdd(green): implement levels\n")

        with patch("subprocess.run", return_value=git_mock):
            import io
            stderr_capture = io.StringIO()
            with patch("sys.stderr", stderr_capture):
                hook.main()

        output = stderr_capture.getvalue()
        assert "APPROVED" in output

    def test_ac4_stderr_includes_last_tdd_phase(self, tmp_path):
        """AC-4: stderr output includes the TDD phase extracted from the most recent tdd(...) commit."""
        _make_sherlock_plan(tmp_path, tier="Full Sherlock", status="APPROVED — Executing")
        _make_handoff_file(tmp_path)

        hook = _load_hook()
        hook.PROJECT_ROOT = tmp_path

        # git log returns a commit with tdd(refactor) as the most recent
        git_log_output = (
            "abc1234 tdd(refactor): clean up event log module\n"
            "def5678 tdd(green): implement event log levels\n"
            "ghi9012 tdd(red): write failing tests for levels\n"
        )
        git_mock = MagicMock(returncode=0, stdout=git_log_output)

        with patch("subprocess.run", return_value=git_mock):
            import io
            stderr_capture = io.StringIO()
            with patch("sys.stderr", stderr_capture):
                hook.main()

        output = stderr_capture.getvalue()
        assert "refactor" in output.lower()

    def test_ac4_subprocess_git_log_uses_correct_range(self, tmp_path):
        """AC-4: hook calls git log with HEAD~20..HEAD to find recent TDD commits."""
        _make_sherlock_plan(tmp_path, tier="Sherlock Lite", status="APPROVED")
        _make_handoff_file(tmp_path)

        hook = _load_hook()
        hook.PROJECT_ROOT = tmp_path

        git_mock = MagicMock(returncode=0, stdout="abc1234 tdd(green): implement\n")

        with patch("subprocess.run", return_value=git_mock) as mock_run:
            import io
            with patch("sys.stderr", io.StringIO()):
                hook.main()

        # Verify git was called with oneline and the expected range
        call_args = mock_run.call_args
        cmd = call_args[0][0] if call_args[0] else call_args.args[0]
        cmd_str = " ".join(cmd) if isinstance(cmd, list) else str(cmd)
        assert "HEAD~20..HEAD" in cmd_str
        assert "oneline" in cmd_str

    def test_ac4_exits_0_when_plan_exists(self, tmp_path):
        """AC-4: hook exits 0 even with a full plan context (non-blocking)."""
        _make_sherlock_plan(tmp_path, tier="Sherlock Lite", status="APPROVED")
        _make_handoff_file(tmp_path)

        git_mock = MagicMock(returncode=0, stdout="abc1234 tdd(green): implement\n")

        with patch("subprocess.run", return_value=git_mock):
            result = _run_hook(tmp_path)

        assert result.returncode == 0


# ---------------------------------------------------------------------------
# TestNoPlanPath — AC-5
# ---------------------------------------------------------------------------


class TestNoPlanPath:
    """AC-5: When no .sherlock-plan.md exists, stderr includes only branch context."""

    def test_ac5_stderr_includes_branch_when_no_plan(self, tmp_path):
        """AC-5: stderr output includes current branch even without a plan file."""
        # No plan file created
        _make_handoff_file(tmp_path, branch="feature/my-feature")

        hook = _load_hook()
        hook.PROJECT_ROOT = tmp_path

        git_branch_mock = MagicMock(returncode=0, stdout="feature/my-feature\n")

        with patch("subprocess.run", return_value=git_branch_mock):
            import io
            stderr_capture = io.StringIO()
            with patch("sys.stderr", stderr_capture):
                hook.main()

        output = stderr_capture.getvalue()
        assert "feature/my-feature" in output

    def test_ac5_no_plan_details_in_output_when_plan_missing(self, tmp_path):
        """AC-5: stderr does not mention plan tier or status when no plan exists."""
        # No plan file created — no tier/status should appear
        _make_handoff_file(tmp_path)

        hook = _load_hook()
        hook.PROJECT_ROOT = tmp_path

        git_mock = MagicMock(returncode=0, stdout="")

        with patch("subprocess.run", return_value=git_mock):
            import io
            stderr_capture = io.StringIO()
            with patch("sys.stderr", stderr_capture):
                hook.main()

        output = stderr_capture.getvalue()
        # These are plan-specific labels that should not appear when no plan exists
        assert "Tier:" not in output
        assert "Status:" not in output

    def test_ac5_no_errors_when_plan_missing(self, tmp_path):
        """AC-5: hook exits 0 cleanly with no plan file — non-blocking."""
        # No plan file created
        _make_handoff_file(tmp_path)

        result = _run_hook(tmp_path)

        assert result.returncode == 0
        # No Python tracebacks in stderr
        assert "Traceback" not in result.stderr
        assert "Error" not in result.stderr

    def test_ac5_exits_0_without_plan_or_handoff(self, tmp_path):
        """AC-5 + edge: hook exits 0 when neither plan nor handoff file exists."""
        # Neither plan nor handoff file
        result = _run_hook(tmp_path)

        assert result.returncode == 0


# ---------------------------------------------------------------------------
# TestMissingHandoffFile — edge case
# ---------------------------------------------------------------------------


class TestMissingHandoffFile:
    """Edge case: hook works gracefully when pre-compact-handoff.json is absent."""

    def test_succeeds_without_handoff_file_no_plan(self, tmp_path):
        """No handoff, no plan → hook exits 0 and writes something to stderr."""
        # Neither file exists
        result = _run_hook(tmp_path)

        assert result.returncode == 0
        assert "Traceback" not in result.stderr

    def test_succeeds_without_handoff_file_with_plan(self, tmp_path):
        """No handoff but plan exists → hook exits 0 and includes plan info in stderr."""
        _make_sherlock_plan(tmp_path, tier="Sherlock Lite", status="APPROVED")
        # No handoff file

        git_mock = MagicMock(returncode=0, stdout="abc1234 tdd(green): implement\n")

        with patch("subprocess.run", return_value=git_mock):
            result = _run_hook(tmp_path)

        assert result.returncode == 0

    def test_handoff_dir_missing_does_not_raise(self, tmp_path):
        """When .claude/state/ directory doesn't exist, hook still completes."""
        # No state dir created at all
        hook = _load_hook()
        hook.PROJECT_ROOT = tmp_path

        git_mock = MagicMock(returncode=0, stdout="")

        with patch("subprocess.run", return_value=git_mock):
            import io
            stderr_capture = io.StringIO()
            with patch("sys.stderr", stderr_capture):
                # Should not raise
                hook.main()


# ---------------------------------------------------------------------------
# TestNoTDDCommits — edge case
# ---------------------------------------------------------------------------


class TestNoTDDCommits:
    """Edge case: when git log contains no tdd(...) commits, output says so."""

    def test_output_indicates_no_tdd_commits_when_log_is_empty(self, tmp_path):
        """When git log returns no commits, stderr says 'No recent TDD commits'."""
        _make_sherlock_plan(tmp_path, tier="Sherlock Lite", status="APPROVED")
        _make_handoff_file(tmp_path)

        hook = _load_hook()
        hook.PROJECT_ROOT = tmp_path

        git_mock = MagicMock(returncode=0, stdout="")  # empty log output

        with patch("subprocess.run", return_value=git_mock):
            import io
            stderr_capture = io.StringIO()
            with patch("sys.stderr", stderr_capture):
                hook.main()

        output = stderr_capture.getvalue()
        assert "No recent TDD commits" in output

    def test_output_indicates_no_tdd_commits_when_none_match_pattern(self, tmp_path):
        """When git log has commits but none start with 'tdd(', stderr says so."""
        _make_sherlock_plan(tmp_path, tier="Sherlock Lite", status="APPROVED")
        _make_handoff_file(tmp_path)

        hook = _load_hook()
        hook.PROJECT_ROOT = tmp_path

        # Commits exist but are not tdd-phase commits
        git_log_output = (
            "abc1234 feat: add new feature\n"
            "def5678 fix: correct typo in readme\n"
            "ghi9012 chore: update dependencies\n"
        )
        git_mock = MagicMock(returncode=0, stdout=git_log_output)

        with patch("subprocess.run", return_value=git_mock):
            import io
            stderr_capture = io.StringIO()
            with patch("sys.stderr", stderr_capture):
                hook.main()

        output = stderr_capture.getvalue()
        assert "No recent TDD commits" in output

    def test_exits_0_when_no_tdd_commits(self, tmp_path):
        """Hook exits 0 even when no TDD commits exist — non-blocking."""
        _make_sherlock_plan(tmp_path, tier="Sherlock Lite", status="APPROVED")
        _make_handoff_file(tmp_path)

        git_mock = MagicMock(returncode=0, stdout="")

        with patch("subprocess.run", return_value=git_mock):
            result = _run_hook(tmp_path)

        assert result.returncode == 0

    def test_git_failure_does_not_crash_hook(self, tmp_path):
        """When git log fails (non-zero exit), hook still completes without raising."""
        _make_sherlock_plan(tmp_path, tier="Sherlock Lite", status="APPROVED")
        _make_handoff_file(tmp_path)

        hook = _load_hook()
        hook.PROJECT_ROOT = tmp_path

        git_fail_mock = MagicMock(returncode=128, stdout="", stderr="fatal: not a git repo\n")

        with patch("subprocess.run", return_value=git_fail_mock):
            import io
            stderr_capture = io.StringIO()
            with patch("sys.stderr", stderr_capture):
                hook.main()  # must not raise
