"""Tests for scripts/fw_event_log.py — framework event logging module.

Covers JSONL append, fire-and-forget error suppression, no-op when disabled,
date-partitioned rotation, session ID resolution, and event filtering.
"""

import json
import os
from datetime import datetime, timezone
from pathlib import Path
from unittest.mock import patch, MagicMock

import pytest

from scripts.fw_event_log import (
    append_event,
    read_events,
    get_session_id,
    _rotate_if_needed,
    _is_enabled,
    _get_metrics_dir,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_framework_yaml(tmp_path: Path, enabled: bool) -> Path:
    """Write a minimal framework.yaml with metrics.enabled set."""
    config_dir = tmp_path / "config"
    config_dir.mkdir(parents=True, exist_ok=True)
    content = f"metrics:\n  enabled: {str(enabled).lower()}\n"
    yaml_path = config_dir / "framework.yaml"
    yaml_path.write_text(content)
    return yaml_path


def _make_session_lock(tmp_path: Path, session_id: str = "abc12345") -> Path:
    """Write a minimal session-lock.json."""
    state_dir = tmp_path / ".claude" / "state"
    state_dir.mkdir(parents=True, exist_ok=True)
    lock_path = state_dir / "session-lock.json"
    lock_path.write_text(json.dumps({"session_id": session_id}))
    return lock_path


# ---------------------------------------------------------------------------
# _is_enabled
# ---------------------------------------------------------------------------

class TestIsEnabled:
    """_is_enabled reads metrics.enabled from framework.yaml."""

    def test_returns_true_when_enabled(self, tmp_path, monkeypatch):
        _make_framework_yaml(tmp_path, enabled=True)
        monkeypatch.chdir(tmp_path)
        assert _is_enabled() is True

    def test_returns_false_when_disabled(self, tmp_path, monkeypatch):
        _make_framework_yaml(tmp_path, enabled=False)
        monkeypatch.chdir(tmp_path)
        assert _is_enabled() is False

    def test_returns_false_when_yaml_missing(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        assert _is_enabled() is False

    def test_returns_false_when_metrics_key_absent(self, tmp_path, monkeypatch):
        config_dir = tmp_path / "config"
        config_dir.mkdir()
        (config_dir / "framework.yaml").write_text("other_key: value\n")
        monkeypatch.chdir(tmp_path)
        assert _is_enabled() is False


# ---------------------------------------------------------------------------
# _get_metrics_dir
# ---------------------------------------------------------------------------

class TestGetMetricsDir:
    """_get_metrics_dir returns and creates .context/metrics/ under project root."""

    def test_returns_correct_path(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        result = _get_metrics_dir()
        assert result == tmp_path / ".context" / "metrics"

    def test_creates_directory_if_absent(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        result = _get_metrics_dir()
        assert result.exists()
        assert result.is_dir()

    def test_is_idempotent_when_dir_exists(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        _get_metrics_dir()
        # Calling again must not raise
        result = _get_metrics_dir()
        assert result.is_dir()


# ---------------------------------------------------------------------------
# get_session_id
# ---------------------------------------------------------------------------

class TestGetSessionId:
    """get_session_id reads from session-lock.json or returns 'unknown'."""

    def test_returns_session_id_from_lock_file(self, tmp_path, monkeypatch):
        _make_session_lock(tmp_path, session_id="deadbeef")
        monkeypatch.chdir(tmp_path)
        assert get_session_id() == "deadbeef"

    def test_returns_unknown_when_lock_file_missing(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        assert get_session_id() == "unknown"

    def test_returns_unknown_when_lock_file_malformed(self, tmp_path, monkeypatch):
        state_dir = tmp_path / ".claude" / "state"
        state_dir.mkdir(parents=True)
        (state_dir / "session-lock.json").write_text("not valid json{{{")
        monkeypatch.chdir(tmp_path)
        assert get_session_id() == "unknown"

    def test_returns_unknown_when_session_id_key_absent(self, tmp_path, monkeypatch):
        state_dir = tmp_path / ".claude" / "state"
        state_dir.mkdir(parents=True)
        (state_dir / "session-lock.json").write_text(json.dumps({"branch": "main"}))
        monkeypatch.chdir(tmp_path)
        assert get_session_id() == "unknown"


# ---------------------------------------------------------------------------
# append_event — AC-1: writes valid JSONL with expected fields
# ---------------------------------------------------------------------------

class TestAppendEvent:
    """AC-1, AC-2, AC-3: append_event behaviour under various conditions."""

    def test_ac1_creates_jsonl_file_when_enabled(self, tmp_path, monkeypatch):
        """AC-1: appending an event creates the monthly JSONL file."""
        _make_framework_yaml(tmp_path, enabled=True)
        _make_session_lock(tmp_path)
        monkeypatch.chdir(tmp_path)

        append_event("block", "safety", {"reason": "Force push"}, hook="auto_approve_base")

        metrics_dir = tmp_path / ".context" / "metrics"
        jsonl_files = list(metrics_dir.glob("events-*.jsonl"))
        assert len(jsonl_files) == 1

    def test_ac1_written_line_is_valid_json(self, tmp_path, monkeypatch):
        """AC-1: every line appended must be parseable JSON."""
        _make_framework_yaml(tmp_path, enabled=True)
        _make_session_lock(tmp_path)
        monkeypatch.chdir(tmp_path)

        append_event("block", "safety", {"reason": "Force push"}, hook="auto_approve_base")

        jsonl_file = next((tmp_path / ".context" / "metrics").glob("events-*.jsonl"))
        line = jsonl_file.read_text().strip()
        record = json.loads(line)  # must not raise
        assert isinstance(record, dict)

    def test_ac1_record_contains_required_keys(self, tmp_path, monkeypatch):
        """AC-1: the JSON record must have sid, ts, event, category, data, hook."""
        _make_framework_yaml(tmp_path, enabled=True)
        _make_session_lock(tmp_path, session_id="mysession1")
        monkeypatch.chdir(tmp_path)

        append_event("block", "safety", {"reason": "Force push"}, hook="auto_approve_base")

        jsonl_file = next((tmp_path / ".context" / "metrics").glob("events-*.jsonl"))
        record = json.loads(jsonl_file.read_text().strip())
        for key in ("sid", "ts", "event", "category", "data", "hook"):
            assert key in record, f"Missing key: {key}"

    def test_ac1_record_field_values(self, tmp_path, monkeypatch):
        """AC-1: field values match arguments passed."""
        _make_framework_yaml(tmp_path, enabled=True)
        _make_session_lock(tmp_path, session_id="mysession1")
        monkeypatch.chdir(tmp_path)

        append_event("block", "safety", {"reason": "Force push"}, hook="auto_approve_base")

        jsonl_file = next((tmp_path / ".context" / "metrics").glob("events-*.jsonl"))
        record = json.loads(jsonl_file.read_text().strip())
        assert record["event"] == "block"
        assert record["category"] == "safety"
        assert record["data"] == {"reason": "Force push"}
        assert record["hook"] == "auto_approve_base"
        assert record["sid"] == "mysession1"

    def test_ac1_ts_is_iso8601(self, tmp_path, monkeypatch):
        """AC-1: ts field must be a valid ISO 8601 datetime string."""
        _make_framework_yaml(tmp_path, enabled=True)
        _make_session_lock(tmp_path)
        monkeypatch.chdir(tmp_path)

        append_event("approve", "safety", {})

        jsonl_file = next((tmp_path / ".context" / "metrics").glob("events-*.jsonl"))
        record = json.loads(jsonl_file.read_text().strip())
        # Must parse without error — fromisoformat covers ISO 8601
        parsed = datetime.fromisoformat(record["ts"])
        assert isinstance(parsed, datetime)

    def test_ac1_filename_contains_year_month(self, tmp_path, monkeypatch):
        """AC-1: JSONL file is named events-YYYY-MM.jsonl."""
        _make_framework_yaml(tmp_path, enabled=True)
        _make_session_lock(tmp_path)
        monkeypatch.chdir(tmp_path)

        append_event("warn", "protocol", {})

        metrics_dir = tmp_path / ".context" / "metrics"
        files = list(metrics_dir.glob("events-*.jsonl"))
        assert len(files) == 1
        # Verify name matches pattern events-YYYY-MM.jsonl
        name = files[0].name
        assert name.startswith("events-")
        assert name.endswith(".jsonl")
        # Extract YYYY-MM and verify it looks like a valid year-month
        year_month = name[len("events-"):-len(".jsonl")]
        year, month = year_month.split("-")
        assert len(year) == 4
        assert 1 <= int(month) <= 12

    def test_ac1_multiple_calls_produce_multiple_lines(self, tmp_path, monkeypatch):
        """Multiple append_event calls each write a separate line."""
        _make_framework_yaml(tmp_path, enabled=True)
        _make_session_lock(tmp_path)
        monkeypatch.chdir(tmp_path)

        append_event("block", "safety", {"reason": "reason1"})
        append_event("approve", "cost", {"agent": "fw-review-code"})
        append_event("warn", "protocol", {"msg": "stale docs"})

        jsonl_file = next((tmp_path / ".context" / "metrics").glob("events-*.jsonl"))
        lines = [l for l in jsonl_file.read_text().splitlines() if l.strip()]
        assert len(lines) == 3

    def test_ac1_hook_defaults_to_none(self, tmp_path, monkeypatch):
        """hook parameter is optional; omitting it stores None/null."""
        _make_framework_yaml(tmp_path, enabled=True)
        _make_session_lock(tmp_path)
        monkeypatch.chdir(tmp_path)

        append_event("route", "cost", {})

        jsonl_file = next((tmp_path / ".context" / "metrics").glob("events-*.jsonl"))
        record = json.loads(jsonl_file.read_text().strip())
        assert record["hook"] is None

    def test_ac2_no_file_created_when_disabled(self, tmp_path, monkeypatch):
        """AC-2: when metrics.enabled is false, no file is written."""
        _make_framework_yaml(tmp_path, enabled=False)
        monkeypatch.chdir(tmp_path)

        append_event("block", "safety", {"reason": "Force push"}, hook="auto_approve_base")

        metrics_dir = tmp_path / ".context" / "metrics"
        # Either dir doesn't exist or it has no JSONL files
        if metrics_dir.exists():
            assert list(metrics_dir.glob("events-*.jsonl")) == []

    def test_ac2_no_exception_when_disabled(self, tmp_path, monkeypatch):
        """AC-2: calling append_event when disabled must not raise."""
        _make_framework_yaml(tmp_path, enabled=False)
        monkeypatch.chdir(tmp_path)

        # Must not raise
        append_event("block", "safety", {})

    def test_ac3_suppresses_permission_error(self, tmp_path, monkeypatch):
        """AC-3: PermissionError during write must be silently swallowed."""
        _make_framework_yaml(tmp_path, enabled=True)
        _make_session_lock(tmp_path)
        monkeypatch.chdir(tmp_path)

        with patch("builtins.open", side_effect=PermissionError("read-only filesystem")):
            # Must not raise
            append_event("block", "safety", {"reason": "test"})

    def test_ac3_suppresses_os_error(self, tmp_path, monkeypatch):
        """AC-3: Any OSError during write must be silently swallowed."""
        _make_framework_yaml(tmp_path, enabled=True)
        _make_session_lock(tmp_path)
        monkeypatch.chdir(tmp_path)

        with patch("builtins.open", side_effect=OSError("disk full")):
            append_event("block", "safety", {})

    def test_ac3_suppresses_json_serialization_error(self, tmp_path, monkeypatch):
        """AC-3: Non-JSON-serializable data must not raise."""
        _make_framework_yaml(tmp_path, enabled=True)
        _make_session_lock(tmp_path)
        monkeypatch.chdir(tmp_path)

        # datetime is not JSON-serializable by default
        append_event("block", "safety", {"ts": datetime.now()})
        # Must not raise — no file written or partial is acceptable

    def test_ac1_acquires_exclusive_lock_during_write(self, tmp_path, monkeypatch):
        """AC-1: fcntl.flock must be called with LOCK_EX before writing."""
        import fcntl as fcntl_mod

        _make_framework_yaml(tmp_path, enabled=True)
        _make_session_lock(tmp_path)
        monkeypatch.chdir(tmp_path)

        with patch("scripts.fw_event_log.fcntl") as mock_fcntl:
            mock_fcntl.LOCK_EX = fcntl_mod.LOCK_EX
            mock_fcntl.LOCK_UN = fcntl_mod.LOCK_UN
            append_event("block", "safety", {"reason": "test"}, hook="auto_approve_base")

        lock_flags = [c.args[1] for c in mock_fcntl.flock.call_args_list]
        assert fcntl_mod.LOCK_EX in lock_flags, "Expected LOCK_EX during write"


# ---------------------------------------------------------------------------
# _rotate_if_needed — AC-6: prunes oldest files when over cap
# ---------------------------------------------------------------------------

class TestRotateIfNeeded:
    """AC-6: date-partitioned rotation deletes oldest monthly files over cap."""

    def _make_jsonl_file(self, metrics_dir: Path, name: str, size_bytes: int) -> Path:
        """Create a JSONL file with a given approximate size."""
        path = metrics_dir / name
        # Write enough data to reach size_bytes
        line = json.dumps({"event": "block", "ts": "2026-01-01T00:00:00Z"}) + "\n"
        content = (line * (size_bytes // len(line) + 1))[:size_bytes]
        path.write_text(content)
        return path

    def test_no_deletion_when_under_cap(self, tmp_path):
        """AC-6: files under cap are left untouched."""
        metrics_dir = tmp_path / ".context" / "metrics"
        metrics_dir.mkdir(parents=True)
        self._make_jsonl_file(metrics_dir, "events-2026-01.jsonl", 1024)
        self._make_jsonl_file(metrics_dir, "events-2026-02.jsonl", 1024)

        max_bytes = 50 * 1024 * 1024  # 50 MB
        _rotate_if_needed(metrics_dir, max_bytes)

        remaining = list(metrics_dir.glob("events-*.jsonl"))
        assert len(remaining) == 2

    def test_oldest_file_deleted_first(self, tmp_path):
        """AC-6: when pruning, the alphabetically-first (oldest) file is removed first."""
        metrics_dir = tmp_path / ".context" / "metrics"
        metrics_dir.mkdir(parents=True)

        # Three files that collectively exceed a small cap
        size = 200 * 1024  # 200 KB each
        self._make_jsonl_file(metrics_dir, "events-2025-10.jsonl", size)
        self._make_jsonl_file(metrics_dir, "events-2025-11.jsonl", size)
        self._make_jsonl_file(metrics_dir, "events-2025-12.jsonl", size)

        max_bytes = 400 * 1024  # 400 KB cap — one file must be pruned
        _rotate_if_needed(metrics_dir, max_bytes)

        remaining = sorted(f.name for f in metrics_dir.glob("events-*.jsonl"))
        assert "events-2025-10.jsonl" not in remaining
        assert "events-2025-11.jsonl" in remaining
        assert "events-2025-12.jsonl" in remaining

    def test_multiple_files_deleted_until_under_cap(self, tmp_path):
        """AC-6: continues deleting oldest files until total is below cap."""
        metrics_dir = tmp_path / ".context" / "metrics"
        metrics_dir.mkdir(parents=True)

        size = 200 * 1024
        self._make_jsonl_file(metrics_dir, "events-2025-10.jsonl", size)
        self._make_jsonl_file(metrics_dir, "events-2025-11.jsonl", size)
        self._make_jsonl_file(metrics_dir, "events-2025-12.jsonl", size)
        self._make_jsonl_file(metrics_dir, "events-2026-01.jsonl", size)

        max_bytes = 300 * 1024  # only one file fits; three must be deleted
        _rotate_if_needed(metrics_dir, max_bytes)

        remaining = list(metrics_dir.glob("events-*.jsonl"))
        total = sum(f.stat().st_size for f in remaining)
        assert total <= max_bytes

    def test_no_error_on_empty_metrics_dir(self, tmp_path):
        """_rotate_if_needed on an empty directory must not raise."""
        metrics_dir = tmp_path / ".context" / "metrics"
        metrics_dir.mkdir(parents=True)

        _rotate_if_needed(metrics_dir, 50 * 1024 * 1024)  # must not raise


# ---------------------------------------------------------------------------
# read_events — filtering by since, event_type, category
# ---------------------------------------------------------------------------

class TestReadEvents:
    """read_events reads JSONL files and applies optional filters."""

    def _write_events(self, metrics_dir: Path, month: str, events: list[dict]) -> Path:
        """Write a list of event dicts as JSONL to a monthly file."""
        path = metrics_dir / f"events-{month}.jsonl"
        path.write_text("\n".join(json.dumps(e) for e in events) + "\n")
        return path

    def test_returns_all_events_with_no_filters(self, tmp_path, monkeypatch):
        """Without filters, all events from all files are returned."""
        metrics_dir = tmp_path / ".context" / "metrics"
        metrics_dir.mkdir(parents=True)
        _make_framework_yaml(tmp_path, enabled=True)
        monkeypatch.chdir(tmp_path)

        self._write_events(metrics_dir, "2026-01", [
            {"sid": "s1", "ts": "2026-01-10T12:00:00Z", "event": "block", "category": "safety", "data": {}, "hook": None},
            {"sid": "s1", "ts": "2026-01-15T08:00:00Z", "event": "approve", "category": "cost", "data": {}, "hook": None},
        ])
        self._write_events(metrics_dir, "2026-02", [
            {"sid": "s2", "ts": "2026-02-01T09:00:00Z", "event": "warn", "category": "protocol", "data": {}, "hook": None},
        ])

        results = read_events()
        assert len(results) == 3

    def test_since_filter_excludes_older_files(self, tmp_path, monkeypatch):
        """since filter should skip monthly files entirely before the cutoff month."""
        metrics_dir = tmp_path / ".context" / "metrics"
        metrics_dir.mkdir(parents=True)
        _make_framework_yaml(tmp_path, enabled=True)
        monkeypatch.chdir(tmp_path)

        self._write_events(metrics_dir, "2025-11", [
            {"sid": "s1", "ts": "2025-11-20T00:00:00Z", "event": "block", "category": "safety", "data": {}, "hook": None},
        ])
        self._write_events(metrics_dir, "2026-01", [
            {"sid": "s1", "ts": "2026-01-05T00:00:00Z", "event": "approve", "category": "cost", "data": {}, "hook": None},
        ])

        results = read_events(since="2026-01-01")
        assert all(r["ts"] >= "2026-01-01" for r in results)
        assert all(r["event"] == "approve" for r in results)

    def test_event_type_filter_returns_only_matching(self, tmp_path, monkeypatch):
        """event_type filter returns only records where event == event_type."""
        metrics_dir = tmp_path / ".context" / "metrics"
        metrics_dir.mkdir(parents=True)
        _make_framework_yaml(tmp_path, enabled=True)
        monkeypatch.chdir(tmp_path)

        self._write_events(metrics_dir, "2026-01", [
            {"sid": "s1", "ts": "2026-01-10T00:00:00Z", "event": "block", "category": "safety", "data": {}, "hook": None},
            {"sid": "s1", "ts": "2026-01-11T00:00:00Z", "event": "approve", "category": "safety", "data": {}, "hook": None},
            {"sid": "s1", "ts": "2026-01-12T00:00:00Z", "event": "block", "category": "cost", "data": {}, "hook": None},
        ])

        results = read_events(event_type="block")
        assert len(results) == 2
        assert all(r["event"] == "block" for r in results)

    def test_category_filter_returns_only_matching(self, tmp_path, monkeypatch):
        """category filter returns only records where category matches."""
        metrics_dir = tmp_path / ".context" / "metrics"
        metrics_dir.mkdir(parents=True)
        _make_framework_yaml(tmp_path, enabled=True)
        monkeypatch.chdir(tmp_path)

        self._write_events(metrics_dir, "2026-01", [
            {"sid": "s1", "ts": "2026-01-10T00:00:00Z", "event": "block", "category": "safety", "data": {}, "hook": None},
            {"sid": "s1", "ts": "2026-01-11T00:00:00Z", "event": "warn", "category": "protocol", "data": {}, "hook": None},
        ])

        results = read_events(category="protocol")
        assert len(results) == 1
        assert results[0]["category"] == "protocol"

    def test_combined_filters_narrow_results(self, tmp_path, monkeypatch):
        """event_type and category filters can be combined."""
        metrics_dir = tmp_path / ".context" / "metrics"
        metrics_dir.mkdir(parents=True)
        _make_framework_yaml(tmp_path, enabled=True)
        monkeypatch.chdir(tmp_path)

        self._write_events(metrics_dir, "2026-01", [
            {"sid": "s1", "ts": "2026-01-01T00:00:00Z", "event": "block", "category": "safety", "data": {}, "hook": None},
            {"sid": "s1", "ts": "2026-01-02T00:00:00Z", "event": "block", "category": "cost", "data": {}, "hook": None},
            {"sid": "s1", "ts": "2026-01-03T00:00:00Z", "event": "approve", "category": "safety", "data": {}, "hook": None},
        ])

        results = read_events(event_type="block", category="safety")
        assert len(results) == 1
        assert results[0]["event"] == "block"
        assert results[0]["category"] == "safety"

    def test_returns_empty_list_when_no_files(self, tmp_path, monkeypatch):
        """read_events on a missing or empty metrics dir returns []."""
        _make_framework_yaml(tmp_path, enabled=True)
        monkeypatch.chdir(tmp_path)

        results = read_events()
        assert results == []

    def test_skips_malformed_json_lines(self, tmp_path, monkeypatch):
        """Lines that are not valid JSON are skipped without raising."""
        metrics_dir = tmp_path / ".context" / "metrics"
        metrics_dir.mkdir(parents=True)
        _make_framework_yaml(tmp_path, enabled=True)
        monkeypatch.chdir(tmp_path)

        path = metrics_dir / "events-2026-01.jsonl"
        path.write_text(
            json.dumps({"sid": "s1", "ts": "2026-01-01T00:00:00Z", "event": "block", "category": "safety", "data": {}, "hook": None}) + "\n"
            + "this is not json\n"
            + json.dumps({"sid": "s1", "ts": "2026-01-02T00:00:00Z", "event": "approve", "category": "cost", "data": {}, "hook": None}) + "\n"
        )

        results = read_events()
        assert len(results) == 2


# ---------------------------------------------------------------------------
# AC-1: Event log levels filter noise
# append_event writes level; read_events(level=) filters by minimum level
# Level hierarchy: debug < info < warn < error
# ---------------------------------------------------------------------------

class TestEventLogLevels:
    """AC-1: append_event accepts level parameter; read_events filters by minimum level."""

    def _write_events(self, metrics_dir: Path, month: str, events: list[dict]) -> Path:
        """Write a list of event dicts as JSONL to a monthly file."""
        path = metrics_dir / f"events-{month}.jsonl"
        path.write_text("\n".join(json.dumps(e) for e in events) + "\n")
        return path

    def test_ac1_append_event_writes_level_field(self, tmp_path, monkeypatch):
        """AC-1: append_event stores the level field in the written record."""
        _make_framework_yaml(tmp_path, enabled=True)
        _make_session_lock(tmp_path)
        monkeypatch.chdir(tmp_path)

        append_event("approve", "cost", {}, level="debug")

        jsonl_file = next((tmp_path / ".context" / "metrics").glob("events-*.jsonl"))
        record = json.loads(jsonl_file.read_text().strip())
        assert record["level"] == "debug"

    def test_ac1_default_level_is_info(self, tmp_path, monkeypatch):
        """AC-1: when level is not passed, the written record has level='info'."""
        _make_framework_yaml(tmp_path, enabled=True)
        _make_session_lock(tmp_path)
        monkeypatch.chdir(tmp_path)

        append_event("block", "safety", {"reason": "force push"}, hook="auto_approve_base")

        jsonl_file = next((tmp_path / ".context" / "metrics").glob("events-*.jsonl"))
        record = json.loads(jsonl_file.read_text().strip())
        assert record["level"] == "info"

    def test_ac1_debug_events_excluded_when_min_level_is_info(self, tmp_path, monkeypatch):
        """AC-1: read_events(level='info') excludes debug records."""
        metrics_dir = tmp_path / ".context" / "metrics"
        metrics_dir.mkdir(parents=True)
        _make_framework_yaml(tmp_path, enabled=True)
        monkeypatch.chdir(tmp_path)

        self._write_events(metrics_dir, "2026-01", [
            {"sid": "s1", "ts": "2026-01-01T00:00:00Z", "event": "approve", "category": "cost", "data": {}, "hook": None, "level": "debug"},
            {"sid": "s1", "ts": "2026-01-02T00:00:00Z", "event": "block", "category": "safety", "data": {}, "hook": None, "level": "info"},
            {"sid": "s1", "ts": "2026-01-03T00:00:00Z", "event": "warn", "category": "protocol", "data": {}, "hook": None, "level": "warn"},
        ])

        results = read_events(level="info")
        levels = [r["level"] for r in results]
        assert "debug" not in levels
        assert len(results) == 2

    def test_ac1_debug_events_excluded_when_min_level_is_warn(self, tmp_path, monkeypatch):
        """AC-1: read_events(level='warn') excludes debug and info records."""
        metrics_dir = tmp_path / ".context" / "metrics"
        metrics_dir.mkdir(parents=True)
        _make_framework_yaml(tmp_path, enabled=True)
        monkeypatch.chdir(tmp_path)

        self._write_events(metrics_dir, "2026-01", [
            {"sid": "s1", "ts": "2026-01-01T00:00:00Z", "event": "approve", "category": "cost", "data": {}, "hook": None, "level": "debug"},
            {"sid": "s1", "ts": "2026-01-02T00:00:00Z", "event": "block", "category": "safety", "data": {}, "hook": None, "level": "info"},
            {"sid": "s1", "ts": "2026-01-03T00:00:00Z", "event": "warn", "category": "protocol", "data": {}, "hook": None, "level": "warn"},
            {"sid": "s1", "ts": "2026-01-04T00:00:00Z", "event": "error", "category": "safety", "data": {}, "hook": None, "level": "error"},
        ])

        results = read_events(level="warn")
        levels = [r["level"] for r in results]
        assert "debug" not in levels
        assert "info" not in levels
        assert len(results) == 2

    def test_ac1_debug_level_returns_all_events(self, tmp_path, monkeypatch):
        """AC-1: read_events(level='debug') returns events of all severity levels."""
        metrics_dir = tmp_path / ".context" / "metrics"
        metrics_dir.mkdir(parents=True)
        _make_framework_yaml(tmp_path, enabled=True)
        monkeypatch.chdir(tmp_path)

        self._write_events(metrics_dir, "2026-01", [
            {"sid": "s1", "ts": "2026-01-01T00:00:00Z", "event": "a", "category": "cost", "data": {}, "hook": None, "level": "debug"},
            {"sid": "s1", "ts": "2026-01-02T00:00:00Z", "event": "b", "category": "safety", "data": {}, "hook": None, "level": "info"},
            {"sid": "s1", "ts": "2026-01-03T00:00:00Z", "event": "c", "category": "protocol", "data": {}, "hook": None, "level": "warn"},
            {"sid": "s1", "ts": "2026-01-04T00:00:00Z", "event": "d", "category": "safety", "data": {}, "hook": None, "level": "error"},
        ])

        results = read_events(level="debug")
        assert len(results) == 4

    def test_ac1_error_level_returns_only_error_events(self, tmp_path, monkeypatch):
        """AC-1: read_events(level='error') includes only error-level records."""
        metrics_dir = tmp_path / ".context" / "metrics"
        metrics_dir.mkdir(parents=True)
        _make_framework_yaml(tmp_path, enabled=True)
        monkeypatch.chdir(tmp_path)

        self._write_events(metrics_dir, "2026-01", [
            {"sid": "s1", "ts": "2026-01-01T00:00:00Z", "event": "a", "category": "cost", "data": {}, "hook": None, "level": "debug"},
            {"sid": "s1", "ts": "2026-01-02T00:00:00Z", "event": "b", "category": "safety", "data": {}, "hook": None, "level": "info"},
            {"sid": "s1", "ts": "2026-01-03T00:00:00Z", "event": "c", "category": "protocol", "data": {}, "hook": None, "level": "warn"},
            {"sid": "s1", "ts": "2026-01-04T00:00:00Z", "event": "d", "category": "safety", "data": {}, "hook": None, "level": "error"},
        ])

        results = read_events(level="error")
        assert len(results) == 1
        assert results[0]["level"] == "error"

    def test_ac1_level_filter_combines_with_event_type_filter(self, tmp_path, monkeypatch):
        """AC-1: level filter can be combined with event_type filter."""
        metrics_dir = tmp_path / ".context" / "metrics"
        metrics_dir.mkdir(parents=True)
        _make_framework_yaml(tmp_path, enabled=True)
        monkeypatch.chdir(tmp_path)

        self._write_events(metrics_dir, "2026-01", [
            {"sid": "s1", "ts": "2026-01-01T00:00:00Z", "event": "block", "category": "safety", "data": {}, "hook": None, "level": "debug"},
            {"sid": "s1", "ts": "2026-01-02T00:00:00Z", "event": "block", "category": "safety", "data": {}, "hook": None, "level": "warn"},
            {"sid": "s1", "ts": "2026-01-03T00:00:00Z", "event": "approve", "category": "cost", "data": {}, "hook": None, "level": "warn"},
        ])

        results = read_events(event_type="block", level="warn")
        assert len(results) == 1
        assert results[0]["event"] == "block"
        assert results[0]["level"] == "warn"

    def test_ac1_no_level_filter_returns_all_events_including_debug(self, tmp_path, monkeypatch):
        """AC-1: when level is not specified, all events are returned regardless of their level."""
        metrics_dir = tmp_path / ".context" / "metrics"
        metrics_dir.mkdir(parents=True)
        _make_framework_yaml(tmp_path, enabled=True)
        monkeypatch.chdir(tmp_path)

        self._write_events(metrics_dir, "2026-01", [
            {"sid": "s1", "ts": "2026-01-01T00:00:00Z", "event": "a", "category": "cost", "data": {}, "hook": None, "level": "debug"},
            {"sid": "s1", "ts": "2026-01-02T00:00:00Z", "event": "b", "category": "safety", "data": {}, "hook": None, "level": "warn"},
        ])

        results = read_events()
        assert len(results) == 2


# ---------------------------------------------------------------------------
# AC-2: Event log levels are backward-compatible
# Existing JSONL records without a level field are treated as level="info"
# ---------------------------------------------------------------------------

class TestEventLogLevelBackwardCompat:
    """AC-2: records without a level field are treated as level='info'."""

    def _write_events(self, metrics_dir: Path, month: str, events: list[dict]) -> Path:
        path = metrics_dir / f"events-{month}.jsonl"
        path.write_text("\n".join(json.dumps(e) for e in events) + "\n")
        return path

    def test_ac2_records_without_level_returned_by_default(self, tmp_path, monkeypatch):
        """AC-2: old records with no level field are included in read_events() with no filter."""
        metrics_dir = tmp_path / ".context" / "metrics"
        metrics_dir.mkdir(parents=True)
        _make_framework_yaml(tmp_path, enabled=True)
        monkeypatch.chdir(tmp_path)

        # Write a legacy-style record with no level field
        self._write_events(metrics_dir, "2026-01", [
            {"sid": "s1", "ts": "2026-01-10T00:00:00Z", "event": "block", "category": "safety", "data": {}, "hook": None},
        ])

        results = read_events()
        assert len(results) == 1

    def test_ac2_records_without_level_included_at_info_threshold(self, tmp_path, monkeypatch):
        """AC-2: old records with no level field appear when filtering at level='info'."""
        metrics_dir = tmp_path / ".context" / "metrics"
        metrics_dir.mkdir(parents=True)
        _make_framework_yaml(tmp_path, enabled=True)
        monkeypatch.chdir(tmp_path)

        self._write_events(metrics_dir, "2026-01", [
            {"sid": "s1", "ts": "2026-01-10T00:00:00Z", "event": "block", "category": "safety", "data": {}, "hook": None},
        ])

        results = read_events(level="info")
        assert len(results) == 1

    def test_ac2_records_without_level_excluded_at_warn_threshold(self, tmp_path, monkeypatch):
        """AC-2: old records (implicit info) are excluded when min level is warn."""
        metrics_dir = tmp_path / ".context" / "metrics"
        metrics_dir.mkdir(parents=True)
        _make_framework_yaml(tmp_path, enabled=True)
        monkeypatch.chdir(tmp_path)

        self._write_events(metrics_dir, "2026-01", [
            {"sid": "s1", "ts": "2026-01-10T00:00:00Z", "event": "block", "category": "safety", "data": {}, "hook": None},
        ])

        results = read_events(level="warn")
        assert len(results) == 0

    def test_ac2_mixed_records_handled_correctly(self, tmp_path, monkeypatch):
        """AC-2: a file containing both old (no level) and new (with level) records is handled correctly."""
        metrics_dir = tmp_path / ".context" / "metrics"
        metrics_dir.mkdir(parents=True)
        _make_framework_yaml(tmp_path, enabled=True)
        monkeypatch.chdir(tmp_path)

        self._write_events(metrics_dir, "2026-01", [
            # Legacy record — no level field (treated as info)
            {"sid": "s1", "ts": "2026-01-01T00:00:00Z", "event": "block", "category": "safety", "data": {}, "hook": None},
            # New record — explicit debug level
            {"sid": "s1", "ts": "2026-01-02T00:00:00Z", "event": "approve", "category": "cost", "data": {}, "hook": None, "level": "debug"},
            # New record — explicit warn level
            {"sid": "s1", "ts": "2026-01-03T00:00:00Z", "event": "warn", "category": "protocol", "data": {}, "hook": None, "level": "warn"},
        ])

        # level="info" should include legacy record (info) and warn but not debug
        results = read_events(level="info")
        assert len(results) == 2
        events = [r["event"] for r in results]
        assert "block" in events   # legacy record treated as info
        assert "warn" in events    # explicit warn >= info
        assert "approve" not in events  # explicit debug < info


# ---------------------------------------------------------------------------
# AC-3: Error logging captures failures silently
# When append_event fails, write to errors.jsonl; function must not raise
# ---------------------------------------------------------------------------

class TestErrorLogging:
    """AC-3: append_event writes failures to errors.jsonl without raising."""

    def test_ac3_errors_written_to_errors_jsonl_on_os_error(self, tmp_path, monkeypatch):
        """AC-3: when an OSError occurs during write, an entry appears in errors.jsonl."""
        _make_framework_yaml(tmp_path, enabled=True)
        _make_session_lock(tmp_path)
        monkeypatch.chdir(tmp_path)

        metrics_dir = tmp_path / ".context" / "metrics"
        metrics_dir.mkdir(parents=True)

        # Patch open to raise on the events file but allow errors.jsonl to be created
        original_open = open

        def selective_open(path, *args, **kwargs):
            if "events-" in str(path):
                raise OSError("disk full")
            return original_open(path, *args, **kwargs)

        monkeypatch.setattr("builtins.open", selective_open)

        append_event("block", "safety", {"reason": "force push"}, hook="auto_approve_base")

        errors_file = metrics_dir / "errors.jsonl"
        assert errors_file.exists(), "errors.jsonl should be created when append_event fails"

    def test_ac3_errors_jsonl_contains_valid_json_entry(self, tmp_path, monkeypatch):
        """AC-3: the entry in errors.jsonl is valid JSON with a ts and message field."""
        _make_framework_yaml(tmp_path, enabled=True)
        _make_session_lock(tmp_path)
        monkeypatch.chdir(tmp_path)

        metrics_dir = tmp_path / ".context" / "metrics"
        metrics_dir.mkdir(parents=True)

        original_open = open

        def selective_open(path, *args, **kwargs):
            if "events-" in str(path):
                raise OSError("disk full")
            return original_open(path, *args, **kwargs)

        monkeypatch.setattr("builtins.open", selective_open)

        append_event("block", "safety", {"reason": "force push"})

        errors_file = metrics_dir / "errors.jsonl"
        line = errors_file.read_text().strip()
        record = json.loads(line)  # must not raise
        assert "ts" in record
        assert "error" in record or "message" in record or "exception" in record

    def test_ac3_function_does_not_raise_on_os_error(self, tmp_path, monkeypatch):
        """AC-3: append_event must not propagate OSError to the caller."""
        _make_framework_yaml(tmp_path, enabled=True)
        _make_session_lock(tmp_path)
        monkeypatch.chdir(tmp_path)

        with patch("builtins.open", side_effect=OSError("no space left")):
            # Must not raise — fire-and-forget contract must hold
            append_event("block", "safety", {"reason": "test"})

    def test_ac3_function_does_not_raise_on_permission_error(self, tmp_path, monkeypatch):
        """AC-3: append_event must not propagate PermissionError to the caller."""
        _make_framework_yaml(tmp_path, enabled=True)
        _make_session_lock(tmp_path)
        monkeypatch.chdir(tmp_path)

        with patch("builtins.open", side_effect=PermissionError("read-only")):
            append_event("warn", "protocol", {})

    def test_ac3_multiple_failures_each_written_to_errors_jsonl(self, tmp_path, monkeypatch):
        """AC-3: each failing call appends a separate line to errors.jsonl."""
        _make_framework_yaml(tmp_path, enabled=True)
        _make_session_lock(tmp_path)
        monkeypatch.chdir(tmp_path)

        metrics_dir = tmp_path / ".context" / "metrics"
        metrics_dir.mkdir(parents=True)

        original_open = open
        call_count = {"n": 0}

        def selective_open(path, *args, **kwargs):
            if "events-" in str(path):
                call_count["n"] += 1
                raise OSError(f"failure #{call_count['n']}")
            return original_open(path, *args, **kwargs)

        monkeypatch.setattr("builtins.open", selective_open)

        append_event("block", "safety", {"reason": "first"})
        append_event("warn", "protocol", {"msg": "second"})

        errors_file = metrics_dir / "errors.jsonl"
        lines = [l for l in errors_file.read_text().splitlines() if l.strip()]
        assert len(lines) == 2
