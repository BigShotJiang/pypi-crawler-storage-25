"""Tests for the fw_conformance.py conformance scorer.

Scores plan adherence during Sherlock/Holmes sessions by comparing
a .sherlock-plan.md against the actual git diff. Covers file coverage,
AC coverage, scope creep, and composite scoring.

Phase 1 RED additions (AC-1, AC-2, AC-3):
- AC-1: Inconclusive sentinel propagates through _compute_composite (tuple return)
- AC-2: Scorecard schema v2 captures enrichment metadata
- AC-3: _check_ac_coverage does not self-match plan file
"""

import hashlib
import json
import pytest
from pathlib import Path
from unittest.mock import patch, MagicMock

from scripts.fw_conformance import (
    score_session,
    _parse_planned_files,
    _parse_acceptance_criteria,
    _check_file_coverage,
    _check_ac_coverage,
    _check_scope_creep,
    _compute_composite,
)
# AC-2 symbols (_compute_schema_version_2_enrichment, _parse_sherlock_tier, save_scorecard)
# are imported locally inside each test function/class so that a missing symbol causes
# an individual test failure (ImportError) rather than a collection-time error that
# prevents existing tests from running. This is intentional RED-phase isolation.


# ---------------------------------------------------------------------------
# Shared fixtures / helpers
# ---------------------------------------------------------------------------

PLAN_WITH_FILES_AND_ACS = """\
# Sherlock Plan

## Acceptance Criteria

### AC-1: Widget processes input
- **Given** valid input
- **When** process() called
- **Then** returns result

### AC-2: Widget handles errors
- **Given** invalid input
- **When** process() called
- **Then** raises ValueError

### AC-3: Widget logs output
- **Given** successful run
- **When** process() called
- **Then** log entry written

## Planned Files

| File | Action | Reason |
|------|--------|--------|
| src/widget.py | CREATE | Core logic |
| src/models.py | MODIFY | Add method |
| tests/test_widget.py | CREATE | Unit tests |
| src/logging_utils.py | MODIFY | Hook in log |
| config/settings.yaml | MODIFY | New flag |
"""

PLAN_NO_FILES_TABLE = """\
# Sherlock Plan

## Acceptance Criteria

### AC-1: Something
- **Given** x
- **When** y
- **Then** z
"""

PLAN_EMPTY_FILES_TABLE = """\
# Sherlock Plan

## Planned Files

| File | Action | Reason |
|------|--------|--------|
"""

PLAN_WHITESPACE_IN_CELLS = """\
# Sherlock Plan

## Planned Files

| File | Action | Reason |
|------|--------|--------|
|  src/widget.py  |  CREATE  |  Core logic  |
|  src/bar.py     |  MODIFY  |  Fix method  |
"""


def _make_plan_file(tmp_path: Path, content: str) -> Path:
    plan = tmp_path / ".sherlock-plan.md"
    plan.write_text(content)
    return plan


def _make_test_file(tmp_path: Path, name: str, content: str) -> Path:
    test_file = tmp_path / name
    test_file.write_text(content)
    return test_file


# ---------------------------------------------------------------------------
# _parse_planned_files
# ---------------------------------------------------------------------------

class TestParsePlannedFiles:
    """Extract rows from the Planned Files markdown table."""

    def test_returns_file_and_action_for_each_row(self):
        result = _parse_planned_files(PLAN_WITH_FILES_AND_ACS)
        assert len(result) == 5
        assert {"file": "src/widget.py", "action": "CREATE"} in result
        assert {"file": "src/models.py", "action": "MODIFY"} in result

    def test_empty_table_returns_empty_list(self):
        result = _parse_planned_files(PLAN_EMPTY_FILES_TABLE)
        assert result == []

    def test_no_planned_files_section_returns_empty_list(self):
        plan_md = "# Just a title\n\nSome prose with no table.\n"
        result = _parse_planned_files(plan_md)
        assert result == []

    def test_extra_whitespace_in_cells_is_stripped(self):
        result = _parse_planned_files(PLAN_WHITESPACE_IN_CELLS)
        assert len(result) == 2
        assert result[0]["file"] == "src/widget.py"
        assert result[0]["action"] == "CREATE"
        assert result[1]["file"] == "src/bar.py"
        assert result[1]["action"] == "MODIFY"

    def test_returns_list_of_dicts_with_file_and_action_keys(self):
        result = _parse_planned_files(PLAN_WITH_FILES_AND_ACS)
        for row in result:
            assert "file" in row
            assert "action" in row


# ---------------------------------------------------------------------------
# _parse_acceptance_criteria
# ---------------------------------------------------------------------------

class TestParseAcceptanceCriteria:
    """Extract AC-# identifiers from the Acceptance Criteria section."""

    def test_returns_ac_identifiers(self):
        result = _parse_acceptance_criteria(PLAN_WITH_FILES_AND_ACS)
        assert result == ["AC-1", "AC-2", "AC-3"]

    def test_no_ac_section_returns_empty_list(self):
        plan_md = "# Plan\n\n## Planned Files\n\n| File | Action |\n|---|---|\n"
        result = _parse_acceptance_criteria(plan_md)
        assert result == []

    def test_empty_string_returns_empty_list(self):
        result = _parse_acceptance_criteria("")
        assert result == []

    def test_handles_non_sequential_ac_numbers(self):
        plan_md = (
            "## Acceptance Criteria\n\n"
            "### AC-1: First\n- **Given** x\n\n"
            "### AC-3: Third (skip 2)\n- **Given** y\n\n"
            "### AC-10: Tenth\n- **Given** z\n"
        )
        result = _parse_acceptance_criteria(plan_md)
        assert "AC-1" in result
        assert "AC-3" in result
        assert "AC-10" in result
        assert "AC-2" not in result


# ---------------------------------------------------------------------------
# _check_file_coverage
# ---------------------------------------------------------------------------

class TestCheckFileCoverage:
    """Compare planned vs actual changed files."""

    def test_all_planned_files_present_score_is_1(self):
        planned = [
            {"file": "src/foo.py", "action": "CREATE"},
            {"file": "src/bar.py", "action": "MODIFY"},
        ]
        actual = ["src/foo.py", "src/bar.py"]
        result = _check_file_coverage(planned, actual)
        assert result["score"] == 1.0
        assert result["missing"] == []
        assert result["unplanned"] == []

    def test_partial_coverage_score_is_fraction(self):
        # AC-4: 4 of 5 planned + 1 unplanned → score = 0.80
        planned = [
            {"file": "src/widget.py", "action": "CREATE"},
            {"file": "src/models.py", "action": "MODIFY"},
            {"file": "tests/test_widget.py", "action": "CREATE"},
            {"file": "src/logging_utils.py", "action": "MODIFY"},
            {"file": "config/settings.yaml", "action": "MODIFY"},
        ]
        actual = [
            "src/widget.py",
            "src/models.py",
            "tests/test_widget.py",
            "src/logging_utils.py",
            "src/extra_unplanned.py",  # unplanned
            # config/settings.yaml is missing
        ]
        result = _check_file_coverage(planned, actual)
        assert result["score"] == pytest.approx(0.80)
        assert "config/settings.yaml" in result["missing"]
        assert "src/extra_unplanned.py" in result["unplanned"]

    def test_no_planned_files_score_is_zero(self):
        result = _check_file_coverage([], ["src/something.py"])
        assert result["score"] == 0.0

    def test_no_planned_files_all_actual_are_unplanned(self):
        result = _check_file_coverage([], ["src/something.py"])
        assert "src/something.py" in result["unplanned"]

    def test_matched_files_are_reported(self):
        planned = [
            {"file": "src/foo.py", "action": "CREATE"},
            {"file": "src/bar.py", "action": "MODIFY"},
        ]
        actual = ["src/foo.py", "src/baz.py"]
        result = _check_file_coverage(planned, actual)
        assert "src/foo.py" in result["matched"]
        assert "src/bar.py" in result["missing"]
        assert "src/baz.py" in result["unplanned"]


# ---------------------------------------------------------------------------
# _check_ac_coverage
# ---------------------------------------------------------------------------

class TestCheckAcCoverage:
    """Search test files for AC-# references to determine coverage."""

    def test_all_acs_referenced_score_is_1(self, tmp_path):
        test_content = (
            "# AC-1: widget processes input\n"
            "# AC-2: widget handles errors\n"
            "def test_something(): pass\n"
        )
        _make_test_file(tmp_path, "test_widget.py", test_content)
        result = _check_ac_coverage(["AC-1", "AC-2"], str(tmp_path))
        assert result["score"] == 1.0
        assert set(result["covered"]) == {"AC-1", "AC-2"}
        assert result["missing"] == []

    def test_no_acs_referenced_score_is_zero(self, tmp_path):
        test_content = "def test_something(): pass\n"
        _make_test_file(tmp_path, "test_widget.py", test_content)
        result = _check_ac_coverage(["AC-1", "AC-2"], str(tmp_path))
        assert result["score"] == 0.0
        assert result["covered"] == []
        assert set(result["missing"]) == {"AC-1", "AC-2"}

    def test_partial_ac_coverage_score_is_fraction(self, tmp_path):
        test_content = "# AC-1 covered here\ndef test_something(): pass\n"
        _make_test_file(tmp_path, "test_widget.py", test_content)
        result = _check_ac_coverage(["AC-1", "AC-2", "AC-3"], str(tmp_path))
        assert result["score"] == pytest.approx(1 / 3)
        assert "AC-1" in result["covered"]
        assert "AC-2" in result["missing"]
        assert "AC-3" in result["missing"]

    def test_empty_acs_list_returns_zero_score(self, tmp_path):
        result = _check_ac_coverage([], str(tmp_path))
        assert result["score"] == 0.0

    def test_nonexistent_test_dir_returns_zero_score(self, tmp_path):
        nonexistent = str(tmp_path / "does_not_exist")
        result = _check_ac_coverage(["AC-1"], nonexistent)
        assert result["score"] == 0.0

    def test_legacy_two_arg_call_scans_non_test_pattern_file(self, tmp_path):
        """Regression: 2-arg legacy call scans every file in test_dir,
        INCLUDING non-test-pattern files. Locks in the backward-compat
        docstring contract (reviewer's M-2 finding on ba52144).
        """
        # helpers.py does NOT match any test-name pattern but still
        # contains AC-1 — under legacy (2-arg) behaviour, it counts.
        (tmp_path / "helpers.py").write_text("# AC-1 referenced here\n")
        result = _check_ac_coverage(["AC-1"], str(tmp_path))  # no plan_path
        assert result["score"] == 1.0
        assert "AC-1" in result["covered"]


# ---------------------------------------------------------------------------
# _check_scope_creep
# ---------------------------------------------------------------------------

class TestCheckScopeCreep:
    """Partition lines changed into planned vs unplanned."""

    def test_all_changes_in_planned_files_score_is_1(self):
        planned = [
            {"file": "src/widget.py", "action": "CREATE"},
            {"file": "src/models.py", "action": "MODIFY"},
        ]
        # numstat format: added\tdeleted\tfilepath
        numstat = "10\t2\tsrc/widget.py\n5\t1\tsrc/models.py\n"
        result = _check_scope_creep(planned, numstat)
        assert result["score"] == 1.0
        assert result["unplanned_lines"] == 0

    def test_some_unplanned_lines_reduce_score(self):
        planned = [{"file": "src/widget.py", "action": "MODIFY"}]
        # 12 lines in planned file, 8 in unplanned → total 20, unplanned 8
        numstat = "10\t2\tsrc/widget.py\n6\t2\tsrc/unplanned.py\n"
        result = _check_scope_creep(planned, numstat)
        assert result["score"] == pytest.approx(12 / 20)
        assert result["unplanned_lines"] == 8
        assert result["planned_lines"] == 12

    def test_zero_total_lines_returns_none_score(self):
        """Empty diff → score=None (inconclusive signal, not silent-pass 1.0)."""
        result = _check_scope_creep([], "")
        assert result["score"] is None
        assert result["planned_lines"] == 0
        assert result["unplanned_lines"] == 0

    def test_all_unplanned_files_score_is_zero(self):
        planned = [{"file": "src/widget.py", "action": "MODIFY"}]
        numstat = "10\t2\tsrc/totally_different.py\n"
        result = _check_scope_creep(planned, numstat)
        assert result["score"] == 0.0
        assert result["planned_lines"] == 0

    def test_binary_files_in_numstat_are_silently_skipped(self):
        """Binary files reported as '-\\t-\\tfile' by --numstat must not raise."""
        planned = [{"file": "src/widget.py", "action": "MODIFY"}]
        numstat = "10\t2\tsrc/widget.py\n-\t-\tassets/logo.png\n"
        result = _check_scope_creep(planned, numstat)
        assert result["score"] == 1.0
        assert result["planned_lines"] == 12
        assert result["unplanned_lines"] == 0


# ---------------------------------------------------------------------------
# _compute_composite
# ---------------------------------------------------------------------------

class TestComputeComposite:
    """Weighted average composite score."""

    def test_all_perfect_scores_return_1(self):
        scores = {
            "file_coverage": 1.0,
            "ac_coverage": 1.0,
            "scope_creep": 1.0,
            "hook_compliance": 1.0,
            "review_gate": 1.0,
        }
        composite, coverage_ratio = _compute_composite(scores)
        assert composite == pytest.approx(1.0)
        assert coverage_ratio == pytest.approx(1.0)

    def test_all_zero_scores_return_0(self):
        scores = {
            "file_coverage": 0.0,
            "ac_coverage": 0.0,
            "scope_creep": 0.0,
            "hook_compliance": 0.0,
            "review_gate": 0.0,
        }
        composite, _ = _compute_composite(scores)
        assert composite == pytest.approx(0.0)

    def test_weights_sum_to_1(self):
        # Only ac_coverage is 1.0, others are 0.0 → weighted sum 0.30, denom 1.0 → 0.30
        scores = {
            "file_coverage": 0.0,
            "ac_coverage": 1.0,
            "scope_creep": 0.0,
            "hook_compliance": 0.0,
            "review_gate": 0.0,
        }
        composite, _ = _compute_composite(scores)
        assert composite == pytest.approx(0.30)

    def test_file_coverage_weight_is_0_25(self):
        scores = {
            "file_coverage": 1.0,
            "ac_coverage": 0.0,
            "scope_creep": 0.0,
            "hook_compliance": 0.0,
            "review_gate": 0.0,
        }
        composite, _ = _compute_composite(scores)
        assert composite == pytest.approx(0.25)

    def test_returns_tuple_of_float_and_float(self):
        """_compute_composite returns (composite, coverage_ratio) tuple."""
        scores = {
            "file_coverage": 0.8,
            "ac_coverage": 0.6,
            "scope_creep": 1.0,
            "hook_compliance": 1.0,
            "review_gate": 1.0,
        }
        result = _compute_composite(scores)
        assert isinstance(result, tuple)
        composite, coverage_ratio = result
        assert isinstance(composite, float)
        assert isinstance(coverage_ratio, float)


# ---------------------------------------------------------------------------
# score_session — integration
# ---------------------------------------------------------------------------

NUMSTAT_4_OF_5 = (
    "8\t2\tsrc/widget.py\n"
    "3\t1\tsrc/models.py\n"
    "12\t0\ttests/test_widget.py\n"
    "2\t1\tsrc/logging_utils.py\n"
    "5\t3\tsrc/extra_unplanned.py\n"
    # config/settings.yaml is absent — missing planned file
)

DIFF_NAMES_4_OF_5 = (
    "src/widget.py\n"
    "src/models.py\n"
    "tests/test_widget.py\n"
    "src/logging_utils.py\n"
    "src/extra_unplanned.py\n"
)


class TestScoreSession:
    """Top-level score_session integration: plan path → scorecard dict."""

    def test_ac4_file_coverage_080_with_one_unplanned(self, tmp_path, monkeypatch):
        """AC-4: 4 of 5 planned files present + 1 unplanned → file_coverage=0.80."""
        plan_path = _make_plan_file(tmp_path, PLAN_WITH_FILES_AND_ACS)

        def fake_run(cmd, **kwargs):
            class FakeResult:
                stdout = ""
                returncode = 0

            if "diff" in cmd and "--name-only" in cmd:
                FakeResult.stdout = DIFF_NAMES_4_OF_5
            elif "diff" in cmd and "--numstat" in cmd:
                FakeResult.stdout = NUMSTAT_4_OF_5
            return FakeResult()

        monkeypatch.setattr("subprocess.run", fake_run)

        result = score_session(str(plan_path))

        assert result["status"] == "ok"
        assert result["scores"]["file_coverage"] == pytest.approx(0.80)
        assert "config/settings.yaml" in result["details"]["missing_files"]
        assert "src/extra_unplanned.py" in result["details"]["unplanned_files"]

    def test_ac5_missing_plan_file_returns_error_scorecard(self, tmp_path):
        """AC-5: plan path does not exist → error scorecard."""
        missing_path = str(tmp_path / "nonexistent.sherlock-plan.md")
        result = score_session(missing_path)

        assert result["status"] == "error"
        assert isinstance(result["message"], str)
        assert len(result["message"]) > 0
        assert result["scores"]["file_coverage"] == 0.0
        assert result["scores"]["ac_coverage"] == 0.0
        assert result["scores"]["scope_creep"] == 0.0
        assert result["scores"]["hook_compliance"] == 0.0
        assert result["scores"]["composite"] == 0.0

    def test_ac5_plan_with_no_planned_files_table_returns_error(self, tmp_path):
        """AC-5: plan exists but has no Planned Files table → error scorecard."""
        plan_path = _make_plan_file(tmp_path, PLAN_NO_FILES_TABLE)
        result = score_session(str(plan_path))

        assert result["status"] == "error"
        assert isinstance(result["message"], str)
        assert result["scores"]["file_coverage"] == 0.0

    def test_scorecard_has_required_top_level_keys(self, tmp_path, monkeypatch):
        plan_path = _make_plan_file(tmp_path, PLAN_WITH_FILES_AND_ACS)

        def fake_run(cmd, **kwargs):
            class FakeResult:
                stdout = "src/widget.py\n"
                returncode = 0
            return FakeResult()

        monkeypatch.setattr("subprocess.run", fake_run)

        result = score_session(str(plan_path))

        assert "status" in result
        assert "scores" in result
        assert "details" in result

    def test_scorecard_scores_has_required_keys(self, tmp_path, monkeypatch):
        plan_path = _make_plan_file(tmp_path, PLAN_WITH_FILES_AND_ACS)

        def fake_run(cmd, **kwargs):
            class FakeResult:
                stdout = ""
                returncode = 0
            return FakeResult()

        monkeypatch.setattr("subprocess.run", fake_run)

        result = score_session(str(plan_path))
        scores = result["scores"]

        assert "file_coverage" in scores
        assert "ac_coverage" in scores
        assert "scope_creep" in scores
        assert "hook_compliance" in scores
        assert "composite" in scores

    def test_scorecard_details_has_required_keys(self, tmp_path, monkeypatch):
        plan_path = _make_plan_file(tmp_path, PLAN_WITH_FILES_AND_ACS)

        def fake_run(cmd, **kwargs):
            class FakeResult:
                stdout = ""
                returncode = 0
            return FakeResult()

        monkeypatch.setattr("subprocess.run", fake_run)

        result = score_session(str(plan_path))
        details = result["details"]

        assert "planned_files" in details
        assert "actual_files" in details
        assert "missing_files" in details
        assert "unplanned_files" in details
        assert "acs_total" in details
        assert "acs_covered" in details
        assert "acs_missing" in details

    def test_planned_files_in_details_matches_plan(self, tmp_path, monkeypatch):
        plan_path = _make_plan_file(tmp_path, PLAN_WITH_FILES_AND_ACS)

        def fake_run(cmd, **kwargs):
            class FakeResult:
                stdout = ""
                returncode = 0
            return FakeResult()

        monkeypatch.setattr("subprocess.run", fake_run)

        result = score_session(str(plan_path))
        planned = result["details"]["planned_files"]

        assert "src/widget.py" in planned
        assert "src/models.py" in planned
        assert "tests/test_widget.py" in planned
        assert "src/logging_utils.py" in planned
        assert "config/settings.yaml" in planned
        assert len(planned) == 5

    def test_error_scorecard_has_message_key(self, tmp_path):
        missing_path = str(tmp_path / "does_not_exist.md")
        result = score_session(missing_path)
        assert "message" in result


# ---------------------------------------------------------------------------
# AC-1: Inconclusive sentinel propagates through _compute_composite
#        (T-1, T-2, T-3, T-4 from .test-matrix.md)
# ---------------------------------------------------------------------------

# Sub-score weights as defined in the spec:
# file_coverage=0.25, ac_coverage=0.30, scope_creep=0.15,
# hook_compliance=0.15, review_gate=0.15  (sum=1.0)
_WEIGHTS = {
    "file_coverage": 0.25,
    "ac_coverage": 0.30,
    "scope_creep": 0.15,
    "hook_compliance": 0.15,
    "review_gate": 0.15,
}


class TestComputeCompositeV2:
    """AC-1: _compute_composite returns (composite, coverage_ratio) tuple;
    None sub-scores are excluded from BOTH numerator and denominator.
    """

    # T-1: hook_compliance=None, review_gate=None → both excluded from weighting
    def test_ac1_t1_none_scores_excluded_from_numerator_and_denominator(self):
        """AC-1 T-1: hook_compliance=None and review_gate=None are excluded.

        Observed weights sum = 0.25 + 0.30 + 0.15 = 0.70.
        Composite = weighted_sum / 0.70 (not / 1.0).
        """
        scores = {
            "file_coverage": 1.0,
            "ac_coverage": 1.0,
            "scope_creep": 1.0,
            "hook_compliance": None,
            "review_gate": None,
        }
        result = _compute_composite(scores)
        # Expect a tuple
        assert isinstance(result, tuple), (
            "_compute_composite must return a tuple (composite, coverage_ratio)"
        )
        composite, coverage_ratio = result
        # All three non-None scores are 1.0 → composite = 0.70 / 0.70 = 1.0
        assert composite == pytest.approx(1.0), (
            "Composite of three 1.0 scores (weights 0.25+0.30+0.15=0.70) "
            "over observed denominator 0.70 must be 1.0"
        )

    # T-2: coverage_ratio == 3/5 when 3 of 5 sub-scores are non-None
    def test_ac1_t2_coverage_ratio_is_three_fifths(self):
        """AC-1 T-2: coverage_ratio == 3/5 when 3 sub-scores observed."""
        scores = {
            "file_coverage": 0.8,
            "ac_coverage": 0.6,
            "scope_creep": 0.5,
            "hook_compliance": None,
            "review_gate": None,
        }
        result = _compute_composite(scores)
        assert isinstance(result, tuple)
        _, coverage_ratio = result
        assert coverage_ratio == pytest.approx(3 / 5)

    # T-3: all None → (None, 0.0) — not ZeroDivisionError, not (0.0, 0.0)
    def test_ac1_t3_all_none_returns_none_composite_and_zero_ratio(self):
        """AC-1 T-3: all sub-scores None → (None, 0.0)."""
        scores = {
            "file_coverage": None,
            "ac_coverage": None,
            "scope_creep": None,
            "hook_compliance": None,
            "review_gate": None,
        }
        result = _compute_composite(scores)
        assert isinstance(result, tuple)
        composite, coverage_ratio = result
        assert composite is None, "All-None input must yield composite=None not 0.0"
        assert coverage_ratio == pytest.approx(0.0)

    # T-4: all non-None → coverage_ratio == 1.0, composite == full weighted sum
    def test_ac1_t4_all_present_coverage_ratio_is_one(self):
        """AC-1 T-4: all 5 sub-scores present → coverage_ratio == 1.0."""
        scores = {
            "file_coverage": 0.8,
            "ac_coverage": 0.6,
            "scope_creep": 1.0,
            "hook_compliance": 0.5,
            "review_gate": 1.0,
        }
        result = _compute_composite(scores)
        assert isinstance(result, tuple)
        composite, coverage_ratio = result
        assert coverage_ratio == pytest.approx(1.0)
        # Verify arithmetic: sum(w_i * s_i) / sum(w_i) = sum(w_i * s_i) / 1.0
        expected = (
            0.25 * 0.8
            + 0.30 * 0.6
            + 0.15 * 1.0
            + 0.15 * 0.5
            + 0.15 * 1.0
        )
        assert composite == pytest.approx(expected)

    # Metamorphic: swapping which two scores are None preserves composite
    def test_ac1_metamorphic_swapping_none_slots_preserves_composite(self):
        """AC-1 oracle: swapping which 2 scores are None keeps composite unchanged
        (None slots contribute 0 to both numerator and denominator).
        """
        base_val = 0.7
        # Variant A: hook_compliance and review_gate are None
        scores_a = {
            "file_coverage": base_val,
            "ac_coverage": base_val,
            "scope_creep": base_val,
            "hook_compliance": None,
            "review_gate": None,
        }
        # Variant B: file_coverage and scope_creep are None
        scores_b = {
            "file_coverage": None,
            "ac_coverage": base_val,
            "scope_creep": None,
            "hook_compliance": base_val,
            "review_gate": base_val,
        }
        result_a = _compute_composite(scores_a)
        result_b = _compute_composite(scores_b)
        assert isinstance(result_a, tuple)
        assert isinstance(result_b, tuple)
        composite_a, _ = result_a
        composite_b, _ = result_b
        # Both have 3 non-None scores all equal to base_val → composite must be base_val
        assert composite_a == pytest.approx(base_val, abs=1e-6)
        assert composite_b == pytest.approx(base_val, abs=1e-6)

    # Property: no denominator creep — subset of 2^5 combinations
    def test_ac1_property_no_denominator_creep_spot_check(self):
        """AC-1 oracle: for any subset S of non-None scores, composite == 1.0
        when all non-None values are 1.0 (weights cancel).
        """
        import itertools
        keys = ["file_coverage", "ac_coverage", "scope_creep", "hook_compliance", "review_gate"]
        # Test a representative sample: single-element subsets + full set
        subsets_to_test = [{k} for k in keys]
        subsets_to_test.append(set(keys))  # all present
        subsets_to_test.append({"file_coverage", "ac_coverage"})

        for present in subsets_to_test:
            scores = {k: (1.0 if k in present else None) for k in keys}
            result = _compute_composite(scores)
            assert isinstance(result, tuple), f"Expected tuple for subset {present}"
            composite, ratio = result
            assert composite == pytest.approx(1.0, abs=1e-9), (
                f"With all non-None=1.0, composite must be 1.0 for subset {present}"
            )
            assert ratio == pytest.approx(len(present) / 5, abs=1e-9)


# ---------------------------------------------------------------------------
# AC-2: Scorecard schema v2 captures enrichment metadata
#        (T-5, T-6, T-7, T-8 from .test-matrix.md)
# ---------------------------------------------------------------------------

PLAN_LITE_TIER = """\
# Sherlock Plan

Tier: Sherlock Lite
Status: APPROVED

## Acceptance Criteria

### AC-1: Test sentinel propagation
- **Given** absent events
- **When** _compute_composite called
- **Then** None propagates

### AC-2: Schema v2
- **Given** a plan
- **When** save_scorecard called
- **Then** top-level keys present
"""


def _make_plan_file_v2(tmp_path: Path, content: str, name: str = ".sherlock-plan.md") -> Path:
    """Write a plan file and return its path."""
    plan = tmp_path / name
    plan.write_text(content, encoding="utf-8")
    return plan


def _make_session_lock_v2(tmp_path: Path, session_id: str = "testsession42") -> Path:
    """Write a minimal session-lock.json."""
    state_dir = tmp_path / ".claude" / "state"
    state_dir.mkdir(parents=True, exist_ok=True)
    lock_path = state_dir / "session-lock.json"
    lock_path.write_text(json.dumps({"session_id": session_id}))
    return lock_path


class TestParseSherlockTier:
    """AC-2 T-6: _parse_sherlock_tier maps 'Tier: X' lines to tier strings."""

    def test_ac2_t6_parses_sherlock_lite(self):
        """AC-2 T-6: 'Tier: Sherlock Lite' maps to 'Sherlock Lite'."""
        from scripts.fw_conformance import _parse_sherlock_tier
        result = _parse_sherlock_tier("# Plan\n\nTier: Sherlock Lite\nStatus: APPROVED\n")
        assert result == "Sherlock Lite"

    def test_ac2_t6_parses_full_sherlock(self):
        """AC-2 T-6: 'Tier: Full Sherlock' maps to 'Full Sherlock'."""
        from scripts.fw_conformance import _parse_sherlock_tier
        result = _parse_sherlock_tier("Tier: Full Sherlock\n")
        assert result == "Full Sherlock"

    def test_ac2_t6_parses_hudson(self):
        """AC-2 T-6: 'Tier: Hudson' maps to 'Hudson'."""
        from scripts.fw_conformance import _parse_sherlock_tier
        result = _parse_sherlock_tier("Tier: Hudson\nStatus: APPROVED\n")
        assert result == "Hudson"

    def test_ac2_t7_missing_tier_line_returns_unknown(self):
        """AC-2 T-7: plan with no 'Tier:' line returns 'unknown'."""
        from scripts.fw_conformance import _parse_sherlock_tier
        result = _parse_sherlock_tier("# Plan\n\n## Acceptance Criteria\n### AC-1: foo\n")
        assert result == "unknown"

    def test_ac2_t7_malformed_tier_value_returns_unknown(self):
        """AC-2 T-7: unrecognised tier value returns 'unknown'."""
        from scripts.fw_conformance import _parse_sherlock_tier
        result = _parse_sherlock_tier("Tier: FutureTier\n")
        assert result == "unknown"

    def test_ac2_t7_empty_string_returns_unknown(self):
        """AC-2 T-7: empty string returns 'unknown'."""
        from scripts.fw_conformance import _parse_sherlock_tier
        result = _parse_sherlock_tier("")
        assert result == "unknown"

    def test_ac2_t7_invalid_tier_before_valid_still_resolves(self):
        """Regression: a non-matching Tier: line before a valid one must
        NOT cause early-exit with 'unknown'. Locks in the post-review
        loop-exit fix.
        """
        from scripts.fw_conformance import _parse_sherlock_tier
        plan = "# Plan\n\nTier: APPROVED\nTier: Sherlock Lite\n"
        result = _parse_sherlock_tier(plan)
        assert result == "Sherlock Lite"


class TestSaveScorecard:
    """AC-2 T-5, T-8: save_scorecard writes schema v2 JSON with enrichment metadata."""

    def test_ac2_t5_top_level_keys_present(self, tmp_path, monkeypatch):
        """AC-2 T-5: saved JSON has all 11 required top-level keys."""
        from scripts.fw_conformance import save_scorecard
        monkeypatch.chdir(tmp_path)
        plan_path = _make_plan_file_v2(tmp_path, PLAN_LITE_TIER)
        _make_session_lock_v2(tmp_path, session_id="sess-abc123")

        # Minimal result dict representing what score_session returns
        result = {
            "plan_path": str(plan_path),
            "base_ref": "HEAD~1",
            "scores": {
                "file_coverage": 0.8,
                "ac_coverage": 0.5,
                "scope_creep": 1.0,
                "hook_compliance": None,
                "review_gate": None,
                "composite": 0.75,
            },
            "status": "ok",
        }

        with patch("subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(
                stdout="abc123def456full",
                returncode=0,
            )
            save_scorecard(result)

        # Find the written file
        conf_dir = tmp_path / ".context" / "metrics" / "conformance"
        assert conf_dir.exists(), "Conformance directory must be created by save_scorecard"
        json_files = list(conf_dir.glob("*.json"))
        assert len(json_files) == 1, "Exactly one scorecard JSON must be written"

        data = json.loads(json_files[0].read_text())

        required_keys = {
            "schema_version",
            "timestamp",
            "composite_score",
            "components",
            "session_id",
            "plan_hash",
            "git_sha",
            "base_ref",
            "sherlock_tier",
            "branch",
            "project_root",
        }
        missing = required_keys - set(data.keys())
        assert not missing, f"Missing top-level keys in schema v2 scorecard: {missing}"

    def test_ac2_t5_schema_version_is_2(self, tmp_path, monkeypatch):
        """AC-2 T-5: schema_version == 2 at top level."""
        from scripts.fw_conformance import save_scorecard
        monkeypatch.chdir(tmp_path)
        plan_path = _make_plan_file_v2(tmp_path, PLAN_LITE_TIER)
        _make_session_lock_v2(tmp_path)

        result = {
            "plan_path": str(plan_path),
            "base_ref": "main",
            "scores": {"file_coverage": 1.0, "ac_coverage": 1.0, "scope_creep": 1.0,
                       "hook_compliance": None, "review_gate": None, "composite": 1.0},
            "status": "ok",
        }
        with patch("subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(stdout="deadbeef1234", returncode=0)
            save_scorecard(result)

        conf_dir = tmp_path / ".context" / "metrics" / "conformance"
        data = json.loads(next(conf_dir.glob("*.json")).read_text())
        assert data["schema_version"] == 2

    def test_ac2_t5_composite_score_matches_scores_composite(self, tmp_path, monkeypatch):
        """AC-2 T-5: top-level composite_score equals scores['composite']."""
        from scripts.fw_conformance import save_scorecard
        monkeypatch.chdir(tmp_path)
        plan_path = _make_plan_file_v2(tmp_path, PLAN_LITE_TIER)
        _make_session_lock_v2(tmp_path)

        expected_composite = 0.73
        result = {
            "plan_path": str(plan_path),
            "base_ref": "HEAD~1",
            "scores": {"file_coverage": 0.9, "ac_coverage": 0.6, "scope_creep": 0.8,
                       "hook_compliance": None, "review_gate": None,
                       "composite": expected_composite},
            "status": "ok",
        }
        with patch("subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(stdout="cafebabe", returncode=0)
            save_scorecard(result)

        conf_dir = tmp_path / ".context" / "metrics" / "conformance"
        data = json.loads(next(conf_dir.glob("*.json")).read_text())
        assert data["composite_score"] == pytest.approx(expected_composite)

    def test_ac2_t5_components_preserves_none_as_null(self, tmp_path, monkeypatch):
        """AC-2 T-5: components dict preserves None sub-scores as JSON null."""
        from scripts.fw_conformance import save_scorecard
        monkeypatch.chdir(tmp_path)
        plan_path = _make_plan_file_v2(tmp_path, PLAN_LITE_TIER)
        _make_session_lock_v2(tmp_path)

        result = {
            "plan_path": str(plan_path),
            "base_ref": "HEAD~1",
            "scores": {"file_coverage": 0.5, "ac_coverage": None, "scope_creep": 1.0,
                       "hook_compliance": None, "review_gate": None, "composite": 0.5},
            "status": "ok",
        }
        with patch("subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(stdout="0011223344", returncode=0)
            save_scorecard(result)

        conf_dir = tmp_path / ".context" / "metrics" / "conformance"
        raw_text = next(conf_dir.glob("*.json")).read_text()
        data = json.loads(raw_text)

        components = data["components"]
        assert components["hook_compliance"] is None, "None must be preserved as JSON null"
        assert components["review_gate"] is None, "None must be preserved as JSON null"
        assert components["ac_coverage"] is None, "None must be preserved as JSON null"

    def test_ac2_t5_session_id_matches_lock_file(self, tmp_path, monkeypatch):
        """AC-2 T-5: session_id in scorecard matches session-lock.json."""
        from scripts.fw_conformance import save_scorecard
        monkeypatch.chdir(tmp_path)
        plan_path = _make_plan_file_v2(tmp_path, PLAN_LITE_TIER)
        _make_session_lock_v2(tmp_path, session_id="unique-session-xyz")

        result = {
            "plan_path": str(plan_path),
            "base_ref": "HEAD~1",
            "scores": {"file_coverage": 1.0, "ac_coverage": 1.0, "scope_creep": 1.0,
                       "hook_compliance": None, "review_gate": None, "composite": 1.0},
            "status": "ok",
        }
        with patch("subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(stdout="aabbccdd", returncode=0)
            save_scorecard(result)

        conf_dir = tmp_path / ".context" / "metrics" / "conformance"
        data = json.loads(next(conf_dir.glob("*.json")).read_text())
        assert data["session_id"] == "unique-session-xyz"

    def test_ac2_t8_plan_hash_is_12_char_hex(self, tmp_path, monkeypatch):
        """AC-2 T-8: plan_hash is exactly 12 chars and equals sha256(content)[:12]."""
        from scripts.fw_conformance import save_scorecard
        monkeypatch.chdir(tmp_path)
        plan_content = PLAN_LITE_TIER
        plan_path = _make_plan_file_v2(tmp_path, plan_content)
        _make_session_lock_v2(tmp_path)

        result = {
            "plan_path": str(plan_path),
            "base_ref": "HEAD~1",
            "scores": {"file_coverage": 1.0, "ac_coverage": 1.0, "scope_creep": 1.0,
                       "hook_compliance": None, "review_gate": None, "composite": 1.0},
            "status": "ok",
        }
        with patch("subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(stdout="1234567890ab", returncode=0)
            save_scorecard(result)

        conf_dir = tmp_path / ".context" / "metrics" / "conformance"
        data = json.loads(next(conf_dir.glob("*.json")).read_text())
        plan_hash = data["plan_hash"]

        assert len(plan_hash) == 12, f"plan_hash must be 12 chars, got {len(plan_hash)}"
        # Verify it equals the first 12 chars of sha256(plan bytes)
        expected_hash = hashlib.sha256(plan_content.encode()).hexdigest()[:12]
        assert plan_hash == expected_hash, (
            f"plan_hash mismatch: expected {expected_hash}, got {plan_hash}"
        )

    def test_ac2_t5_sherlock_tier_is_parsed_from_plan(self, tmp_path, monkeypatch):
        """AC-2 T-5: sherlock_tier reflects the Tier: line in the plan file."""
        from scripts.fw_conformance import save_scorecard
        monkeypatch.chdir(tmp_path)
        plan_path = _make_plan_file_v2(tmp_path, PLAN_LITE_TIER)
        _make_session_lock_v2(tmp_path)

        result = {
            "plan_path": str(plan_path),
            "base_ref": "HEAD~1",
            "scores": {"file_coverage": 1.0, "ac_coverage": 1.0, "scope_creep": 1.0,
                       "hook_compliance": None, "review_gate": None, "composite": 1.0},
            "status": "ok",
        }
        with patch("subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(stdout="feedfeed", returncode=0)
            save_scorecard(result)

        conf_dir = tmp_path / ".context" / "metrics" / "conformance"
        data = json.loads(next(conf_dir.glob("*.json")).read_text())
        assert data["sherlock_tier"] == "Sherlock Lite"

    def test_ac2_t5_timestamp_is_iso8601_utc(self, tmp_path, monkeypatch):
        """AC-2 T-5: timestamp is ISO 8601 UTC string."""
        from datetime import datetime
        from scripts.fw_conformance import save_scorecard
        monkeypatch.chdir(tmp_path)
        plan_path = _make_plan_file_v2(tmp_path, PLAN_LITE_TIER)
        _make_session_lock_v2(tmp_path)

        result = {
            "plan_path": str(plan_path),
            "base_ref": "HEAD~1",
            "scores": {"file_coverage": 1.0, "ac_coverage": 1.0, "scope_creep": 1.0,
                       "hook_compliance": None, "review_gate": None, "composite": 1.0},
            "status": "ok",
        }
        with patch("subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(stdout="abc000", returncode=0)
            save_scorecard(result)

        conf_dir = tmp_path / ".context" / "metrics" / "conformance"
        data = json.loads(next(conf_dir.glob("*.json")).read_text())
        ts = data["timestamp"]
        # Must parse without error
        parsed = datetime.fromisoformat(ts.replace("Z", "+00:00"))
        assert isinstance(parsed, datetime)

    def test_ac2_t5_project_root_is_absolute_path(self, tmp_path, monkeypatch):
        """AC-2 T-5: project_root is an absolute path string."""
        from scripts.fw_conformance import save_scorecard
        monkeypatch.chdir(tmp_path)
        plan_path = _make_plan_file_v2(tmp_path, PLAN_LITE_TIER)
        _make_session_lock_v2(tmp_path)

        result = {
            "plan_path": str(plan_path),
            "base_ref": "HEAD~1",
            "scores": {"file_coverage": 1.0, "ac_coverage": 1.0, "scope_creep": 1.0,
                       "hook_compliance": None, "review_gate": None, "composite": 1.0},
            "status": "ok",
        }
        with patch("subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(stdout="rootsha", returncode=0)
            save_scorecard(result)

        conf_dir = tmp_path / ".context" / "metrics" / "conformance"
        data = json.loads(next(conf_dir.glob("*.json")).read_text())
        import os
        assert os.path.isabs(data["project_root"]), (
            f"project_root must be absolute, got: {data['project_root']}"
        )


# ---------------------------------------------------------------------------
# AC-3: _check_ac_coverage does not self-match plan file
#        (T-9, T-10, T-11, T-12 from .test-matrix.md)
# ---------------------------------------------------------------------------

PLAN_WITH_AC1_AC2 = """\
# Sherlock Plan

## Acceptance Criteria

### AC-1: foo
- **Given** x
- **When** y
- **Then** z

### AC-2: bar
- **Given** a
- **When** b
- **Then** c
"""


class TestCheckAcCoverageV2:
    """AC-3: _check_ac_coverage(acs, test_dir, plan_path) excludes plan file
    from rglob and filters to test-name patterns only.
    """

    def test_ac3_t9_test_file_referencing_neither_ac_score_is_zero(self, tmp_path):
        """AC-3 T-9: one test file referencing neither AC-1 nor AC-2 → score=0.0."""
        # Write plan at repo root
        plan_path = _make_plan_file_v2(tmp_path, PLAN_WITH_AC1_AC2)
        # Write a test file that does NOT reference AC-1 or AC-2
        test_file = tmp_path / "test_widget.py"
        test_file.write_text(
            "def test_something():\n    assert 1 + 1 == 2\n",
            encoding="utf-8",
        )

        result = _check_ac_coverage(
            ["AC-1", "AC-2"],
            test_dir=str(tmp_path),
            plan_path=str(plan_path),
        )

        assert result["score"] == 0.0, (
            "Score must be 0.0 when test file references neither AC"
        )
        assert result["covered"] == []
        assert set(result["missing"]) == {"AC-1", "AC-2"}

    def test_ac3_t10_plan_file_excluded_from_rglob(self, tmp_path):
        """AC-3 T-10: plan file containing AC-1/AC-2 is NOT counted as coverage."""
        # The plan itself contains '### AC-1' and '### AC-2'
        plan_path = _make_plan_file_v2(tmp_path, PLAN_WITH_AC1_AC2)
        # Write a test file that does NOT reference AC-1 or AC-2
        test_file = tmp_path / "test_dummy.py"
        test_file.write_text("def test_pass(): pass\n", encoding="utf-8")

        result = _check_ac_coverage(
            ["AC-1", "AC-2"],
            test_dir=str(tmp_path),
            plan_path=str(plan_path),
        )

        # If plan file were scanned it would show covered=["AC-1","AC-2"]
        # Correct behaviour: plan file excluded → score == 0.0
        assert result["score"] == 0.0, (
            "Plan file must be excluded from AC coverage scan; "
            "it contains AC-1/AC-2 headers but is not a test file"
        )
        assert "AC-1" not in result["covered"]
        assert "AC-2" not in result["covered"]

    def test_ac3_t10_non_test_filename_containing_ac_does_not_count(self, tmp_path):
        """AC-3 T-10b: a non-test-pattern Python file containing AC-1 is excluded."""
        plan_path = _make_plan_file_v2(tmp_path, PLAN_WITH_AC1_AC2)
        # A file named 'helpers.py' (no test prefix/suffix) containing AC-1 reference
        non_test_file = tmp_path / "helpers.py"
        non_test_file.write_text(
            "# AC-1 is covered by this helper\ndef helper(): pass\n",
            encoding="utf-8",
        )
        # No actual test file present — zero test files matching patterns
        result = _check_ac_coverage(
            ["AC-1", "AC-2"],
            test_dir=str(tmp_path),
            plan_path=str(plan_path),
        )

        # With zero matching test files, score must be None (inconclusive)
        assert result["score"] is None, (
            "Zero matching test files must yield score=None (inconclusive), not 0.0"
        )

    def test_ac3_t11_zero_test_files_returns_none_score(self, tmp_path):
        """AC-3 T-11: no files matching test patterns → score=None (inconclusive)."""
        plan_path = _make_plan_file_v2(tmp_path, PLAN_WITH_AC1_AC2)
        # Only write a non-test file
        (tmp_path / "widget.py").write_text("class Widget: pass\n")

        result = _check_ac_coverage(
            ["AC-1", "AC-2"],
            test_dir=str(tmp_path),
            plan_path=str(plan_path),
        )

        assert result["score"] is None, (
            "score must be None when zero test-pattern files exist"
        )

    def test_ac3_t12_test_file_covering_only_ac1_gives_half_score(self, tmp_path):
        """AC-3 T-12: test file references AC-1 but not AC-2 → covered=['AC-1'],
        missing=['AC-2'], score==0.5.
        """
        plan_path = _make_plan_file_v2(tmp_path, PLAN_WITH_AC1_AC2)
        test_file = tmp_path / "test_widget.py"
        test_file.write_text(
            "# AC-1: this test covers AC-1\ndef test_ac1(): assert True\n",
            encoding="utf-8",
        )

        result = _check_ac_coverage(
            ["AC-1", "AC-2"],
            test_dir=str(tmp_path),
            plan_path=str(plan_path),
        )

        assert result["score"] == pytest.approx(0.5)
        assert "AC-1" in result["covered"]
        assert "AC-2" in result["missing"]
        assert "AC-2" not in result["covered"]

    def test_ac3_accepts_plan_path_as_new_parameter(self, tmp_path):
        """AC-3 regression: _check_ac_coverage must accept plan_path keyword arg."""
        plan_path = _make_plan_file_v2(tmp_path, PLAN_WITH_AC1_AC2)
        test_file = tmp_path / "test_widget.py"
        test_file.write_text("# AC-1\ndef test_x(): pass\n")

        # Must not raise TypeError for unexpected keyword argument
        result = _check_ac_coverage(
            ["AC-1"],
            test_dir=str(tmp_path),
            plan_path=str(plan_path),
        )
        assert isinstance(result, dict)
        assert "score" in result
