#!/usr/bin/env python3
"""Generate Claude Code Insights Dashboard — qualitative analysis with interactive filters.

Reads session-meta and facets data from ~/.claude/usage-data/,
computes KPIs, trends, micro-insights, and generates a self-contained HTML dashboard.

Zero external dependencies (stdlib only).
"""

import json
import os
import re
import sys
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path

# Dashboard aggregation helpers — dual-path import matches the pattern
# generate_dashboard itself uses for fw_event_log (works whether invoked
# as a module or directly).
try:
    from scripts.generate_dashboard import (
        aggregate_safety as _agg_safety,
        aggregate_cost_routing as _agg_cost_routing,
        aggregate_conformance as _agg_conformance,
        aggregate_protocol as _agg_protocol,
        aggregate_sessions as _agg_sessions,
        load_scorecards as _load_scorecards,
    )
except ImportError:
    from generate_dashboard import (
        aggregate_safety as _agg_safety,
        aggregate_cost_routing as _agg_cost_routing,
        aggregate_conformance as _agg_conformance,
        aggregate_protocol as _agg_protocol,
        aggregate_sessions as _agg_sessions,
        load_scorecards as _load_scorecards,
    )

# ── Paths ──────────────────────────────────────────────────────────────────

CLAUDE_DIR = Path(os.path.expanduser("~/.claude"))
USAGE_DIR = CLAUDE_DIR / "usage-data"
META_DIR = USAGE_DIR / "session-meta"
FACETS_DIR = USAGE_DIR / "facets"
STATS_CACHE = CLAUDE_DIR / "stats-cache.json"
SCRIPT_DIR = Path(__file__).parent
PROJECT_ROOT = SCRIPT_DIR.parent
OUTPUT_DIR = PROJECT_ROOT / ".context"
OUTPUT_FILE = OUTPUT_DIR / "insights.html"

# ── Framework Stats Discovery ──────────────────────────────────────────────

FW_PROJECTS_CACHE = CLAUDE_DIR / "fw-project-paths.json"
FW_DISCOVERY_MAX_DEPTH = 3
FW_DISCOVERY_SKIP_DIRS = frozenset({
    "node_modules", ".git", ".venv", "venv", "__pycache__",
    "Library", ".Trash", ".npm", ".cache", "dist", "build",
    ".next", ".nuxt", "target", ".cargo", "Pods", ".gradle",
    ".idea", ".vscode", "site-packages", ".tox", "coverage",
    ".pnpm-store", ".yarn", "bower_components",
})


# ══════════════════════════════════════════════════════════════════════════
# Phase 1: Load
# ══════════════════════════════════════════════════════════════════════════

def load_json_safe(path):
    """3-tier JSON recovery: parse → strip control chars → truncate to last }."""
    try:
        text = Path(path).read_text(encoding="utf-8", errors="replace")
    except (OSError, IOError):
        return None

    if not text.strip():
        return None

    # Tier 1: direct parse
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        pass

    # Tier 2: strip control chars (except newline, tab)
    cleaned = re.sub(r'[\x00-\x08\x0b\x0c\x0e-\x1f]', '', text)
    try:
        return json.loads(cleaned)
    except json.JSONDecodeError:
        pass

    # Tier 3: truncate to last closing brace
    last_brace = cleaned.rfind('}')
    if last_brace > 0:
        try:
            return json.loads(cleaned[:last_brace + 1])
        except json.JSONDecodeError:
            pass

    return None


def _load_json_dir(directory):
    """Load all JSON files with a session_id from a directory. Returns (list[dict], error_count)."""
    results = []
    errors = 0
    dir_path = Path(directory)
    if not dir_path.exists():
        return results, errors
    for f in dir_path.iterdir():
        if not f.name.endswith('.json'):
            continue
        data = load_json_safe(f)
        if data and isinstance(data, dict) and data.get('session_id'):
            results.append(data)
        else:
            errors += 1
    return results, errors


def load_session_metas(meta_dir):
    """Load all session-meta JSON files. Returns (list[dict], error_count)."""
    return _load_json_dir(meta_dir)


def load_facets(facets_dir):
    """Load all facets JSON files. Returns (list[dict], error_count)."""
    return _load_json_dir(facets_dir)


def load_stats_cache(cache_path):
    """Load stats-cache.json for historical aggregate data.

    Returns dict with keys:
      - daily_activity: list of {date, messageCount, sessionCount, toolCallCount}
      - daily_model_tokens: list of {date, tokensByModel: {model: count}}
      - model_usage: dict of {model: {inputTokens, outputTokens, ...}}
      - total_sessions, total_messages, first_session_date, hour_counts
    Returns None if file doesn't exist or is unparseable.
    """
    path = Path(cache_path)
    if not path.exists():
        return None
    data = load_json_safe(path)
    if not data:
        return None
    return {
        'daily_activity': data.get('dailyActivity', []),
        'daily_model_tokens': data.get('dailyModelTokens', []),
        'model_usage': data.get('modelUsage', {}),
        'total_sessions': data.get('totalSessions', 0),
        'total_messages': data.get('totalMessages', 0),
        'first_session_date': data.get('firstSessionDate', ''),
        'hour_counts': data.get('hourCounts', {}),
        'longest_session': data.get('longestSession', {}),
    }


# ══════════════════════════════════════════════════════════════════════════
# Phase 1.5: Framework Stats Discovery
# ══════════════════════════════════════════════════════════════════════════

def discover_fw_projects(home=None, skip_dirs=None, max_depth=FW_DISCOVERY_MAX_DEPTH):
    """Walk *home* for directories containing config/framework.yaml.

    Returns a list of project root Paths. Skips directories in *skip_dirs*
    (default: FW_DISCOVERY_SKIP_DIRS) and stops descending past *max_depth*
    relative to *home*. Stops descending into a project once one is found.
    """
    if home is None:
        home = Path.home()
    if skip_dirs is None:
        skip_dirs = FW_DISCOVERY_SKIP_DIRS
    home = Path(home).resolve()
    if not home.exists():
        return []

    home_depth = len(home.parts)
    results = []
    # followlinks=False is the os.walk default but we set it explicitly
    # so a future refactor cannot accidentally chase symlink loops (e.g.
    # macOS Library aliases) through framework projects.
    for dirpath, dirnames, _filenames in os.walk(home, followlinks=False):
        current = Path(dirpath)
        depth = len(current.parts) - home_depth

        # Prune skip dirs in-place so os.walk does not descend
        dirnames[:] = sorted(d for d in dirnames if d not in skip_dirs)

        if depth >= max_depth:
            dirnames[:] = []

        # Identify framework projects by config/framework.yaml
        if (current / "config" / "framework.yaml").exists():
            results.append(current)
            # Do not recurse into a discovered project
            dirnames[:] = []

    return results


def discover_fw_projects_with_skipped(
    home=None, skip_dirs=None, max_depth=FW_DISCOVERY_MAX_DEPTH
) -> dict:
    """Same walk as ``discover_fw_projects``, but categorises results into
    ``found`` (valid framework.yaml parses) and ``skipped`` (parse failed).

    Returns a dict with shape::

        {
            "found": list[Path],    # framework.yaml loaded + parsed OK
            "skipped": list[dict],  # each: {"path": str, "reason": str}
        }

    A project with a corrupt framework.yaml surfaces in ``skipped``
    with the parser's error message, NOT silently dropped. This powers
    the "skipped projects" visibility in the insights dashboard.
    """
    found: list[Path] = []
    skipped: list[dict] = []
    for project_root in discover_fw_projects(
        home=home, skip_dirs=skip_dirs, max_depth=max_depth
    ):
        yaml_path = project_root / "config" / "framework.yaml"
        try:
            text = yaml_path.read_text(encoding="utf-8")
        except OSError as exc:
            skipped.append({
                "path": str(project_root),
                "reason": f"framework.yaml read error: {exc}",
            })
            continue
        try:
            import yaml as _yaml
        except ImportError:
            # PyYAML unavailable — cannot discriminate; treat as found.
            found.append(project_root)
            continue
        try:
            _yaml.safe_load(text)
        except _yaml.YAMLError as exc:
            skipped.append({
                "path": str(project_root),
                "reason": f"framework.yaml parse error: {exc}",
            })
            continue
        except Exception as exc:  # noqa: BLE001 - pyyaml surface is wide
            skipped.append({
                "path": str(project_root),
                "reason": f"framework.yaml parse error: {exc}",
            })
            continue
        found.append(project_root)
    return {"found": found, "skipped": skipped}


def load_fw_projects_cache(cache_path=None):
    """Read cached discovered project paths.

    Filters out paths that no longer exist on disk. Does NOT rewrite the
    cache file when stale entries are pruned (rewrite happens only on
    --refresh-fw-projects). Returns None when the cache file is missing
    or malformed (signaling that a fresh scan should run).
    """
    if cache_path is None:
        cache_path = FW_PROJECTS_CACHE
    cache_path = Path(cache_path)
    if not cache_path.exists():
        return None
    try:
        data = json.loads(cache_path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError, UnicodeDecodeError):
        return None
    if not isinstance(data, dict) or "paths" not in data:
        return None
    return [Path(p) for p in data["paths"] if Path(p).exists()]


def save_fw_projects_cache(paths, cache_path=None):
    """Write discovered project paths and a discovery timestamp to *cache_path*."""
    if cache_path is None:
        cache_path = FW_PROJECTS_CACHE
    cache_path = Path(cache_path)
    cache_path.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "discovered_at": datetime.now(timezone.utc).isoformat(),
        "paths": [str(p) for p in paths],
    }
    cache_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")


def fw_projects_cache_age_days(cache_path=None):
    """Return age of the fw-projects cache in days (float).

    Returns ``None`` when the cache is missing or has no parseable
    ``discovered_at`` timestamp. Used by ``main()`` to decide whether
    to auto-refresh without the explicit ``--refresh-fw-projects`` flag.
    """
    if cache_path is None:
        cache_path = FW_PROJECTS_CACHE
    cache_path = Path(cache_path)
    if not cache_path.exists():
        return None
    try:
        data = json.loads(cache_path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError, UnicodeDecodeError):
        return None
    ts = data.get("discovered_at") if isinstance(data, dict) else None
    if not ts:
        return None
    try:
        when = datetime.fromisoformat(ts.replace("Z", "+00:00"))
    except (ValueError, AttributeError):
        return None
    now = datetime.now(timezone.utc)
    if when.tzinfo is None:
        when = when.replace(tzinfo=timezone.utc)
    return (now - when).total_seconds() / 86400.0


#: Default staleness threshold for the fw-projects cache, in days.
#: After this many days without a fresh scan, ``main()`` will auto-refresh.
FW_PROJECTS_CACHE_MAX_AGE_DAYS = 3.0

#: Default staleness threshold for session-meta freshness, in hours.
#: After this many hours without new data, the dashboard renders a warning.
SESSION_META_STALE_HOURS = 24.0


def check_session_meta_freshness(meta_dir, stale_hours=SESSION_META_STALE_HOURS):
    """Inspect the session-meta directory and report freshness.

    Returns a dict with ``latest_mtime`` (ISO 8601 UTC), ``age_hours``,
    ``stale`` (bool), ``file_count``, and ``meta_dir`` (path, for display).

    When the directory is missing or empty, returns
    ``{"latest_mtime": None, "age_hours": None, "stale": True, ...}`` —
    absent signal is treated as stale so the dashboard surfaces it
    rather than silently rendering nothing.
    """
    meta_path = Path(meta_dir)
    result = {
        "meta_dir": str(meta_path),
        "latest_mtime": None,
        "age_hours": None,
        "stale": True,
        "file_count": 0,
        "threshold_hours": stale_hours,
    }
    if not meta_path.exists():
        return result
    latest = 0.0
    count = 0
    for f in meta_path.iterdir():
        if not f.is_file():
            continue
        try:
            mtime = f.stat().st_mtime
        except OSError:
            continue
        count += 1
        if mtime > latest:
            latest = mtime
    result["file_count"] = count
    if count == 0 or latest == 0.0:
        return result
    latest_dt = datetime.fromtimestamp(latest, tz=timezone.utc)
    age_hours = (datetime.now(timezone.utc) - latest_dt).total_seconds() / 3600.0
    result["latest_mtime"] = latest_dt.isoformat()
    result["age_hours"] = age_hours
    result["stale"] = age_hours > stale_hours
    return result


def _read_events_from_dir(metrics_dir):
    """Read all JSONL event records from a project's metrics directory."""
    if not metrics_dir.exists():
        return []
    results = []
    for path in sorted(metrics_dir.glob("events-*.jsonl")):
        try:
            text = path.read_text(encoding="utf-8")
        except (OSError, UnicodeDecodeError):
            continue
        for line in text.splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                results.append(json.loads(line))
            except json.JSONDecodeError:
                continue
    return results


def _aggregate_one(events, scorecards):
    """Run all five aggregators against an events list + scorecard list."""
    return {
        "safety": _agg_safety(events),
        "cost_routing": _agg_cost_routing(events),
        "conformance": _agg_conformance(scorecards),
        "protocol": _agg_protocol(events),
        "sessions": _agg_sessions(events),
    }


def load_fw_project_metrics(project_root):
    """Read events + scorecards from a single framework project's metrics dir.

    Returns dict with keys: name, path, safety, cost_routing, conformance,
    protocol, sessions, plus internal _events / _scorecards used for
    cross-project re-aggregation. Returns None when the metrics dir is
    missing or contains no events.
    """
    project_root = Path(project_root)
    metrics_dir = project_root / ".context" / "metrics"
    if not metrics_dir.exists():
        return None

    events = _read_events_from_dir(metrics_dir)
    scorecards = _load_scorecards(metrics_dir / "conformance")
    # Skip projects whose metrics dir exists but is empty — neither events
    # nor conformance data. Otherwise we'd add a row of zeros for every
    # framework project that hasn't generated any telemetry yet.
    if not events and not scorecards:
        return None

    return {
        "name": project_root.name,
        "path": str(project_root),
        **_aggregate_one(events, scorecards),
        "_events": events,
        "_scorecards": scorecards,
    }


def aggregate_fw_stats(project_metrics):
    """Group per-project metrics by canonical name and compute totals.

    Worktrees of the same parent project (e.g. dev-framework + every
    dev-framework-session-claude-* clone) are rolled up under their
    canonical project name. The rolled-up dicts intentionally omit the
    private _events / _scorecards keys that the input dicts carry —
    those are only needed for re-aggregation, not for the JSON payload.
    Returns None when *project_metrics* is empty so the caller can omit
    the framework section entirely.
    """
    if not project_metrics:
        return None

    groups = defaultdict(list)
    for pm in project_metrics:
        canonical = canonicalize_project(pm["path"])
        groups[canonical].append(pm)

    def _union(group):
        events, scorecards = [], []
        for pm in group:
            events.extend(pm.get("_events", []))
            scorecards.extend(pm.get("_scorecards", []))
        return events, scorecards

    rolled = []
    for canonical_name in sorted(groups.keys()):
        group = groups[canonical_name]
        events, scorecards = _union(group)
        rolled.append({
            "name": canonical_name,
            "worktree_count": len(group),
            **_aggregate_one(events, scorecards),
        })

    union_events, union_scorecards = _union(project_metrics)
    aggregate = {
        "project_count": len(rolled),
        "worktree_count": sum(r["worktree_count"] for r in rolled),
        **_aggregate_one(union_events, union_scorecards),
    }

    return {"projects": rolled, "aggregate": aggregate}


# ══════════════════════════════════════════════════════════════════════════
# Phase 2: Join
# ══════════════════════════════════════════════════════════════════════════

def canonicalize_project(project_path):
    """Extract canonical project name from path, stripping worktree suffixes."""
    if not project_path:
        return "(no project)"

    parts = [p for p in project_path.rstrip('/').split('/') if p]
    if not parts:
        return "(no project)"

    # Handle .claude/worktrees/... paths — use the project root before .claude
    if '.claude' in parts:
        claude_idx = parts.index('.claude')
        if claude_idx > 0:
            name = parts[claude_idx - 1]
            # Strip worktree suffix from the project name too
            name = re.sub(r'-session-claude-\d{8}-\d{6}$', '', name)
            return name

    name = parts[-1]

    # Strip worktree session suffix: project-session-claude-YYYYMMDD-HHMMSS
    name = re.sub(r'-session-claude-\d{8}-\d{6}$', '', name)

    return name


def join_data(metas, facets):
    """Join session-meta with facets on session_id. Returns unified list."""
    facet_map = {}
    for f in facets:
        sid = f.get('session_id')
        if sid:
            facet_map[sid] = f

    sessions = []
    for m in metas:
        sid = m.get('session_id', '')
        session = {
            'session_id': sid,
            'project_path': m.get('project_path', ''),
            'canonical_project': canonicalize_project(m.get('project_path')),
            'start_time': m.get('start_time', ''),
            'duration_minutes': m.get('duration_minutes', 0),
            'user_message_count': m.get('user_message_count', 0),
            'assistant_message_count': m.get('assistant_message_count', 0),
            'tool_errors': m.get('tool_errors', 0),
            'lines_added': m.get('lines_added', 0),
            'lines_removed': m.get('lines_removed', 0),
            'git_commits': m.get('git_commits', 0),
            'first_prompt': m.get('first_prompt', ''),
            'message_hours': m.get('message_hours', []),
            'tool_counts': m.get('tool_counts', {}),
            'languages': m.get('languages', {}),
            'input_tokens': m.get('input_tokens', 0),
            'output_tokens': m.get('output_tokens', 0),
            'files_modified': m.get('files_modified', 0),
        }

        facet = facet_map.get(sid)
        if facet:
            session['has_facets'] = True
            session['outcome'] = facet.get('outcome', 'unknown')
            session['user_satisfaction_counts'] = facet.get('user_satisfaction_counts', {})
            session['friction_counts'] = facet.get('friction_counts', {})
            session['claude_helpfulness'] = facet.get('claude_helpfulness', 'unknown')
            raw_goals = facet.get('goal_categories', {})
            normalized_goals = {}
            for gk, gv in raw_goals.items():
                canon = normalize_goal(gk)
                normalized_goals[canon] = normalized_goals.get(canon, 0) + gv
            session['goal_categories'] = normalized_goals
            session['session_type'] = facet.get('session_type', 'unknown')
            session['brief_summary'] = facet.get('brief_summary', '')
            session['primary_success'] = facet.get('primary_success', '')
            session['friction_detail'] = facet.get('friction_detail', '')
            session['underlying_goal'] = facet.get('underlying_goal', '')
        else:
            session['has_facets'] = False

        sessions.append(session)

    # Sort by start_time descending (newest first)
    sessions.sort(key=lambda s: s.get('start_time', ''), reverse=True)
    return sessions


# ══════════════════════════════════════════════════════════════════════════
# Phase 3: Compute
# ══════════════════════════════════════════════════════════════════════════

POSITIVE_SATISFACTION = {'satisfied', 'happy', 'very_satisfied', 'delighted', 'likely_satisfied'}
NEGATIVE_SATISFACTION = {'frustrated', 'dissatisfied', 'very_frustrated', 'unhappy'}

# Goal taxonomy normalization — maps 101 freeform categories to ~10 canonical names
_GOAL_ALIASES = {
    'bug_fix': ['bug_fixing', 'code_fix', 'debug_fix_bug', 'debugging', 'debugging_investigation',
                'debugging_diagnosis', 'investigation_and_debugging', 'log_analysis_and_debugging',
                'troubleshooting', 'test_fix'],
    'git_operations': ['merge_pr', 'merge', 'commit_and_pr', 'git_sync_and_workflow',
                       'commit_and_merge', 'check_and_commit_local_changes', 'pr_creation_and_merge',
                       'code_review_and_pr', 'merge_to_main', 'git_merge', 'sync_check',
                       'verify_and_sync', 'git_repo_sync', 'git_branch_cleanup', 'branch_management',
                       'script_fixes_and_commit'],
    'ui_work': ['ui_polish', 'ui_iteration', 'ui_layout_fix', 'ui_design_research',
                'ui_improvements', 'ui_text_change', 'ui_ux_redesign', 'design_mockups',
                'design_question'],
    'research': ['research_and_analysis', 'research_and_strategy', 'strategic_analysis',
                 'investigation', 'architecture_analysis', 'web_research_validation',
                 'project_evaluation', 'brainstorming_strategy', 'feature_investigation',
                 'code_analysis', 'code_review_and_analysis', 'code_review_and_audit',
                 'codebase_exploration'],
    'documentation': ['documentation_update', 'documentation', 'documentation_updates',
                      'documentation_review_and_update', 'content_writing', 'content_editing',
                      'add_content_to_docs', 'code_and_doc_corrections'],
    'deployment': ['deploy_to_production', 'deployment_verification', 'production_health_check',
                   'code_change_and_deploy'],
    'configuration': ['setup_and_configuration', 'configuration_change', 'add_config',
                      'delete_files_and_config', 'file_management'],
    'refactoring': ['code_refactor', 'editing_and_refactoring', 'refactoring_rename',
                    'code_cleanup', 'repo_audit_and_cleanup', 'code_audit', 'feature_restructure',
                    'feature_addition', 'implementation_of_recommendations', 'implementation_planning'],
    'information': ['explanation_request', 'explanation', 'information_lookup', 'information_retrieval',
                    'information_query', 'information_request', 'capability_inquiry', 'quick_question',
                    'question_answer', 'how_to_disconnect', 'summarize_next_steps', 'memory_update'],
}
GOAL_NORMALIZATION = {}
for canonical, aliases in _GOAL_ALIASES.items():
    for alias in aliases:
        GOAL_NORMALIZATION[alias] = canonical


def normalize_goal(key):
    """Map freeform goal category to canonical name."""
    return GOAL_NORMALIZATION.get(key, key)


def compute_kpis(sessions):
    """Compute aggregate KPIs from joined session data."""
    analyzed = [s for s in sessions if s.get('has_facets')]
    total = len(sessions)
    n_analyzed = len(analyzed)

    # Outcome counts
    outcome_counts = Counter()
    for s in analyzed:
        outcome_counts[s.get('outcome', 'unknown')] += 1

    # Satisfaction net score
    total_positive = 0
    total_negative = 0
    total_neutral = 0
    for s in analyzed:
        sat = s.get('user_satisfaction_counts', {})
        for k, v in sat.items():
            k_lower = k.lower()
            if k_lower in POSITIVE_SATISFACTION:
                total_positive += v
            elif k_lower in NEGATIVE_SATISFACTION:
                total_negative += v
            else:
                total_neutral += v

    sat_total = total_positive + total_negative + total_neutral
    if sat_total > 0:
        satisfaction_net_score = (total_positive - total_negative) / sat_total * 100
    else:
        satisfaction_net_score = 0

    # Friction totals
    friction_totals = Counter()
    for s in analyzed:
        for k, v in s.get('friction_counts', {}).items():
            friction_totals[k] += v

    # Helpfulness counts
    helpfulness_counts = Counter()
    for s in analyzed:
        h = s.get('claude_helpfulness', 'unknown')
        helpfulness_counts[h] += 1

    # Goal category totals
    goal_totals = Counter()
    for s in analyzed:
        for k, v in s.get('goal_categories', {}).items():
            goal_totals[k] += v

    # Duration stats
    durations = [s.get('duration_minutes', 0) for s in sessions if s.get('duration_minutes')]
    avg_duration = sum(durations) / len(durations) if durations else 0

    # Total friction events
    total_friction = sum(friction_totals.values())

    # Total lines
    total_lines_added = sum(s.get('lines_added', 0) for s in sessions)
    total_lines_removed = sum(s.get('lines_removed', 0) for s in sessions)
    total_commits = sum(s.get('git_commits', 0) for s in sessions)

    # Tool usage totals (from session-meta, available for all sessions)
    tool_totals = Counter()
    for s in sessions:
        for k, v in s.get('tool_counts', {}).items():
            tool_totals[k] += v

    # Language totals (from session-meta)
    language_totals = Counter()
    for s in sessions:
        for k, v in s.get('languages', {}).items():
            language_totals[k] += v

    # Session type counts (from facets)
    session_type_counts = Counter()
    for s in analyzed:
        st = s.get('session_type', 'unknown')
        session_type_counts[st] += 1

    # Wilson 95% confidence interval for success rate
    import math
    n_success = outcome_counts.get('fully_achieved', 0)
    if n_analyzed > 0:
        p_hat = n_success / n_analyzed
        z = 1.96
        denom = 1 + z**2 / n_analyzed
        center = (p_hat + z**2 / (2 * n_analyzed)) / denom
        margin = z * math.sqrt((p_hat * (1 - p_hat) + z**2 / (4 * n_analyzed)) / n_analyzed) / denom
        wilson_ci_lower = max(0, round((center - margin) * 100))
        wilson_ci_upper = min(100, round((center + margin) * 100))
    else:
        wilson_ci_lower = 0
        wilson_ci_upper = 0

    return {
        'total_sessions': total,
        'analyzed_sessions': n_analyzed,
        'outcome_counts': dict(outcome_counts),
        'satisfaction_net_score': round(satisfaction_net_score, 1),
        'satisfaction_positive': total_positive,
        'satisfaction_negative': total_negative,
        'satisfaction_neutral': total_neutral,
        'friction_totals': dict(friction_totals),
        'total_friction': total_friction,
        'helpfulness_counts': dict(helpfulness_counts),
        'goal_totals': dict(goal_totals),
        'avg_duration': round(avg_duration, 1),
        'total_lines_added': total_lines_added,
        'total_lines_removed': total_lines_removed,
        'total_commits': total_commits,
        'tool_totals': dict(tool_totals),
        'language_totals': dict(language_totals),
        'session_type_counts': dict(session_type_counts),
        'wilson_ci_lower': wilson_ci_lower,
        'wilson_ci_upper': wilson_ci_upper,
    }


def compute_trends(sessions):
    """Compute daily time series for trend charts."""
    by_date = defaultdict(lambda: {
        'sessions': 0, 'analyzed': 0,
        'outcomes': Counter(), 'satisfaction': Counter(),
        'friction': 0, 'lines_added': 0, 'tool_errors': 0,
    })

    for s in sessions:
        st = s.get('start_time', '')
        if not st:
            continue
        date = st[:10]  # YYYY-MM-DD
        day = by_date[date]
        day['sessions'] += 1
        if s.get('has_facets'):
            day['analyzed'] += 1
            day['outcomes'][s.get('outcome', 'unknown')] += 1
            for k, v in s.get('user_satisfaction_counts', {}).items():
                day['satisfaction'][k] += v
            day['friction'] += sum(s.get('friction_counts', {}).values())
        day['lines_added'] += s.get('lines_added', 0)
        day['tool_errors'] += s.get('tool_errors', 0)

    dates = sorted(by_date.keys())
    trends = {
        'dates': dates,
        'sessions': [by_date[d]['sessions'] for d in dates],
        'analyzed': [by_date[d]['analyzed'] for d in dates],
        'friction': [by_date[d]['friction'] for d in dates],
        'lines_added': [by_date[d]['lines_added'] for d in dates],
        'tool_errors': [by_date[d]['tool_errors'] for d in dates],
        'outcomes_by_date': {},
        'satisfaction_by_date': {},
    }

    for d in dates:
        trends['outcomes_by_date'][d] = dict(by_date[d]['outcomes'])
        trends['satisfaction_by_date'][d] = dict(by_date[d]['satisfaction'])

    return trends


def compute_project_breakdown(sessions):
    """Compute per-project aggregates."""
    by_project = defaultdict(lambda: {
        'total': 0, 'analyzed': 0,
        'outcomes': Counter(), 'friction': Counter(),
        'satisfaction_pos': 0, 'satisfaction_neg': 0,
        'duration_total': 0, 'lines_added': 0,
        'helpfulness': Counter(), 'goals': Counter(),
    })

    for s in sessions:
        proj = s.get('canonical_project', '(no project)')
        p = by_project[proj]
        p['total'] += 1
        p['duration_total'] += s.get('duration_minutes', 0)
        p['lines_added'] += s.get('lines_added', 0)
        if s.get('has_facets'):
            p['analyzed'] += 1
            p['outcomes'][s.get('outcome', 'unknown')] += 1
            for k, v in s.get('friction_counts', {}).items():
                p['friction'][k] += v
            for k, v in s.get('user_satisfaction_counts', {}).items():
                if k.lower() in POSITIVE_SATISFACTION:
                    p['satisfaction_pos'] += v
                elif k.lower() in NEGATIVE_SATISFACTION:
                    p['satisfaction_neg'] += v
            p['helpfulness'][s.get('claude_helpfulness', 'unknown')] += 1
            for k, v in s.get('goal_categories', {}).items():
                p['goals'][k] += v

    result = {}
    for proj, p in by_project.items():
        achieved = p['outcomes'].get('fully_achieved', 0)
        success_rate = (achieved / p['analyzed'] * 100) if p['analyzed'] > 0 else 0
        result[proj] = {
            'total': p['total'],
            'analyzed': p['analyzed'],
            'outcomes': dict(p['outcomes']),
            'friction': dict(p['friction']),
            'success_rate': round(success_rate, 1),
            'avg_duration': round(p['duration_total'] / p['total'], 1) if p['total'] else 0,
            'lines_added': p['lines_added'],
            'helpfulness': dict(p['helpfulness']),
            'goals': dict(p['goals']),
        }

    return result


# ══════════════════════════════════════════════════════════════════════════
# Phase 4: Insights
# ══════════════════════════════════════════════════════════════════════════

def _insight_satisfaction_trend(trends):
    """Check if satisfaction is trending up or down in the last week."""
    dates = trends.get('dates', [])
    if len(dates) < 7:
        return None
    recent = dates[-7:]
    older = dates[-14:-7] if len(dates) >= 14 else dates[:len(dates)-7]
    if not older:
        return None

    def net_score(date_list):
        pos = neg = 0
        for d in date_list:
            sat = trends['satisfaction_by_date'].get(d, {})
            for k, v in sat.items():
                if k.lower() in POSITIVE_SATISFACTION:
                    pos += v
                elif k.lower() in NEGATIVE_SATISFACTION:
                    neg += v
        total = pos + neg
        return ((pos - neg) / total * 100) if total >= 10 else None

    recent_score = net_score(recent)
    older_score = net_score(older)
    if recent_score is None or older_score is None:
        return None

    delta = recent_score - older_score
    if abs(delta) < 5:
        return None

    direction = "up" if delta > 0 else "down"
    icon = "trending_up" if delta > 0 else "trending_down"
    return {
        'category': 'satisfaction',
        'text': f"Satisfaction trending {direction}: net score moved {delta:+.0f} points in the last 7 days (now {recent_score:.0f})",
        'priority': 1,
        'icon': icon,
    }


def _insight_friction_hotspot(friction_totals):
    """Flag any friction type that dominates (>35% of total)."""
    total = sum(friction_totals.values())
    if total < 3:
        return None
    for ftype, count in sorted(friction_totals.items(), key=lambda x: -x[1]):
        pct = count / total * 100
        if pct > 35:
            return {
                'category': 'friction',
                'text': f"Friction hotspot: \"{ftype}\" accounts for {pct:.0f}% of all friction events ({count}/{total})",
                'priority': 2,
                'icon': 'warning',
            }
    return None


def _insight_project_outlier(projects):
    """Find the project with lowest success rate (min 3 analyzed sessions)."""
    eligible = {k: v for k, v in projects.items()
                if v['analyzed'] >= 10 and k != '(no project)'}
    if not eligible:
        return None
    worst = min(eligible.items(), key=lambda x: x[1]['success_rate'])
    name, data = worst
    if data['success_rate'] >= 80:
        return None
    return {
        'category': 'project',
        'text': f"Project \"{name}\" has lowest success rate at {data['success_rate']:.0f}% ({data['outcomes'].get('fully_achieved', 0)}/{data['analyzed']} sessions)",
        'priority': 2,
        'icon': 'flag',
    }


def _insight_tool_error_impact(sessions):
    """Compare tool errors for good vs bad outcomes."""
    good_errors = []
    bad_errors = []
    for s in sessions:
        if not s.get('has_facets'):
            continue
        errors = s.get('tool_errors', 0)
        if s.get('outcome') == 'fully_achieved':
            good_errors.append(errors)
        elif s.get('outcome') == 'not_achieved':
            bad_errors.append(errors)
    if len(good_errors) < 10 or len(bad_errors) < 5:
        return None
    avg_good = sum(good_errors) / len(good_errors)
    avg_bad = sum(bad_errors) / len(bad_errors)
    if avg_bad <= avg_good * 1.5:
        return None
    return {
        'category': 'quality',
        'text': f"Tool errors correlate with failure: failed sessions average {avg_bad:.1f} errors vs {avg_good:.1f} for successful ones",
        'priority': 2,
        'icon': 'build',
    }


def _insight_coverage_gap(kpis):
    """Flag if analysis coverage is low."""
    total = kpis['total_sessions']
    analyzed = kpis['analyzed_sessions']
    if total == 0:
        return None
    pct = analyzed / total * 100
    if pct > 50:
        return None
    return {
        'category': 'coverage',
        'text': f"Only {pct:.0f}% of sessions ({analyzed}/{total}) have qualitative analysis — insights may not represent your full usage",
        'priority': 3,
        'icon': 'info',
    }


def _insight_duration_vs_outcome(sessions):
    """Compare duration for achieved vs not-achieved."""
    achieved_dur = []
    not_dur = []
    for s in sessions:
        if not s.get('has_facets') or not s.get('duration_minutes'):
            continue
        if s.get('outcome') == 'fully_achieved':
            achieved_dur.append(s['duration_minutes'])
        elif s.get('outcome') in ('not_achieved', 'partially_achieved'):
            not_dur.append(s['duration_minutes'])
    if len(achieved_dur) < 3 or len(not_dur) < 3:
        return None
    avg_good = sum(achieved_dur) / len(achieved_dur)
    avg_bad = sum(not_dur) / len(not_dur)
    diff_pct = abs(avg_good - avg_bad) / max(avg_good, avg_bad) * 100
    if diff_pct < 20:
        return None
    if avg_good < avg_bad:
        return {
            'category': 'efficiency',
            'text': f"Successful sessions are {diff_pct:.0f}% shorter on average ({avg_good:.0f} min vs {avg_bad:.0f} min for unsuccessful ones)",
            'priority': 3,
            'icon': 'timer',
        }
    else:
        return {
            'category': 'efficiency',
            'text': f"Successful sessions take {diff_pct:.0f}% longer ({avg_good:.0f} min vs {avg_bad:.0f} min) — complex wins need time",
            'priority': 3,
            'icon': 'timer',
        }


def _insight_success_streak(sessions):
    """Find longest consecutive days with at least one fully_achieved."""
    achieved_dates = set()
    for s in sessions:
        if s.get('has_facets') and s.get('outcome') == 'fully_achieved' and s.get('start_time'):
            achieved_dates.add(s['start_time'][:10])
    if not achieved_dates:
        return None
    sorted_dates = sorted(achieved_dates)
    max_streak = 1
    current_streak = 1
    for i in range(1, len(sorted_dates)):
        try:
            d1 = datetime.strptime(sorted_dates[i-1], '%Y-%m-%d')
            d2 = datetime.strptime(sorted_dates[i], '%Y-%m-%d')
            if (d2 - d1).days == 1:
                current_streak += 1
                max_streak = max(max_streak, current_streak)
            else:
                current_streak = 1
        except ValueError:
            current_streak = 1
    if max_streak < 3:
        return None
    return {
        'category': 'streak',
        'text': f"Longest success streak: {max_streak} consecutive days with at least one fully achieved session",
        'priority': 4,
        'icon': 'local_fire_department',
    }


def _insight_friction_free_rate(sessions):
    """Percentage of analyzed sessions with zero friction."""
    analyzed = [s for s in sessions if s.get('has_facets')]
    if len(analyzed) < 5:
        return None
    friction_free = sum(1 for s in analyzed if sum(s.get('friction_counts', {}).values()) == 0)
    pct = friction_free / len(analyzed) * 100
    return {
        'category': 'friction',
        'text': f"{pct:.0f}% of analyzed sessions ({friction_free}/{len(analyzed)}) had zero friction events",
        'priority': 4,
        'icon': 'check_circle',
    }


def _insight_helpfulness_ratio(kpis):
    """Percentage of sessions rated essential or very_helpful."""
    h = kpis.get('helpfulness_counts', {})
    total = sum(h.values())
    if total < 5:
        return None
    top = h.get('essential', 0) + h.get('very_helpful', 0)
    pct = top / total * 100
    return {
        'category': 'helpfulness',
        'text': f"Claude rated essential or very helpful in {pct:.0f}% of analyzed sessions ({top}/{total})",
        'priority': 4,
        'icon': 'thumb_up',
    }


def _insight_peak_hours(sessions):
    """Find the most active hours."""
    hour_counts = Counter()
    for s in sessions:
        for h in s.get('message_hours', []):
            hour_counts[h] += 1
    if not hour_counts:
        return None
    top3 = hour_counts.most_common(3)
    hours_str = ', '.join(f"{h}:00" for h, _ in top3)
    return {
        'category': 'patterns',
        'text': f"Peak coding hours: {hours_str} — schedule deep work sessions around your natural rhythm",
        'priority': 5,
        'icon': 'schedule',
    }


def generate_insights(kpis, trends, projects, sessions):
    """Run all insight generators and return sorted results."""
    generators = [
        lambda: _insight_satisfaction_trend(trends),
        lambda: _insight_friction_hotspot(kpis.get('friction_totals', {})),
        lambda: _insight_project_outlier(projects),
        lambda: _insight_tool_error_impact(sessions),
        lambda: _insight_coverage_gap(kpis),
        lambda: _insight_duration_vs_outcome(sessions),
        lambda: _insight_success_streak(sessions),
        lambda: _insight_friction_free_rate(sessions),
        lambda: _insight_helpfulness_ratio(kpis),
        lambda: _insight_peak_hours(sessions),
    ]

    results = []
    for gen in generators:
        try:
            insight = gen()
            if insight:
                results.append(insight)
        except Exception as e:
            print(f"  Warning: insight generator failed: {e}", file=sys.stderr)

    results.sort(key=lambda x: x.get('priority', 99))
    return results


# ══════════════════════════════════════════════════════════════════════════
# Phase 4b: Narrative Generation (LLM-powered, opt-in via --narrative)
# ══════════════════════════════════════════════════════════════════════════

import hashlib
import subprocess
from concurrent.futures import ThreadPoolExecutor, as_completed

NARRATIVE_CACHE_DIR = PROJECT_ROOT / ".context" / ".narrative-cache"


def _build_data_summary(kpis, trends, projects, sessions):
    """Build a compact data summary for LLM prompts (target: <500 tokens)."""
    analyzed = [s for s in sessions if s.get('has_facets')]

    # Top friction types
    ft = sorted(kpis.get('friction_totals', {}).items(), key=lambda x: -x[1])[:5]
    friction_lines = '\n'.join(f'  {k}: {v} events' for k, v in ft)

    # Project breakdown (top 6 by session count)
    proj_lines = []
    for name, data in sorted(projects.items(), key=lambda x: -x[1]['total'])[:6]:
        if name == '(no project)':
            continue
        proj_lines.append(
            f'  {name}: {data["total"]} sessions, '
            f'{data["success_rate"]}% success, '
            f'{sum(data["friction"].values())} friction events'
        )

    # Friction detail examples (from sessions with friction_detail)
    friction_examples = []
    for s in analyzed:
        detail = s.get('friction_detail', '')
        if detail and len(friction_examples) < 5:
            proj = s.get('canonical_project', 'unknown')
            friction_examples.append(f'  [{proj}] {detail[:200]}')

    # Goal distribution
    goals = sorted(kpis.get('goal_totals', {}).items(), key=lambda x: -x[1])[:6]
    goal_lines = '\n'.join(f'  {k}: {v}' for k, v in goals)

    # Top tools (from session-meta)
    tools = sorted(kpis.get('tool_totals', {}).items(), key=lambda x: -x[1])[:8]
    tool_lines = '\n'.join(f'  {k}: {v}' for k, v in tools)

    # Languages
    langs = sorted(kpis.get('language_totals', {}).items(), key=lambda x: -x[1])[:8]
    lang_lines = '\n'.join(f'  {k}: {v} lines' for k, v in langs)

    # Session types
    stypes = sorted(kpis.get('session_type_counts', {}).items(), key=lambda x: -x[1])
    stype_lines = '\n'.join(f'  {k}: {v}' for k, v in stypes)

    # Primary successes (for impressive things)
    success_examples = []
    for s in analyzed:
        success = s.get('primary_success', '')
        if success and len(success_examples) < 5:
            proj = s.get('canonical_project', 'unknown')
            success_examples.append(f'  [{proj}] {success[:200]}')

    # Date range
    dates = trends.get('dates', [])
    date_range = f'{dates[0]} to {dates[-1]}' if dates else 'unknown'

    return f"""<analytics_data>
period: {date_range}
total_sessions: {kpis['total_sessions']}
analyzed_sessions: {kpis['analyzed_sessions']} (with qualitative facets)
unanalyzed: {kpis['total_sessions'] - kpis['analyzed_sessions']} sessions lack facets data

outcomes:
  fully_achieved: {kpis['outcome_counts'].get('fully_achieved', 0)}
  mostly_achieved: {kpis['outcome_counts'].get('mostly_achieved', 0)}
  partially_achieved: {kpis['outcome_counts'].get('partially_achieved', 0)}
  not_achieved: {kpis['outcome_counts'].get('not_achieved', 0)}

satisfaction:
  net_score: {kpis['satisfaction_net_score']}%
  positive_signals: {kpis['satisfaction_positive']}
  negative_signals: {kpis['satisfaction_negative']}

friction_types (total {kpis['total_friction']} events):
{friction_lines}

friction_examples:
{chr(10).join(friction_examples) if friction_examples else '  (none available)'}

helpfulness:
{chr(10).join(f'  {k}: {v}' for k, v in sorted(kpis.get('helpfulness_counts', {}).items(), key=lambda x: -x[1]))}

goal_categories:
{goal_lines}

top_tools:
{tool_lines}

languages:
{lang_lines}

session_types:
{stype_lines}

primary_successes:
{chr(10).join(success_examples) if success_examples else '  (none available)'}

projects:
{chr(10).join(proj_lines)}

quantitative:
  avg_duration: {kpis['avg_duration']} min
  total_commits: {kpis['total_commits']}
  total_lines_added: {kpis['total_lines_added']}
  total_lines_removed: {kpis['total_lines_removed']}
</analytics_data>"""


# ── Prompt templates ──────────────────────────────────────────────────────

NARRATIVE_PROMPTS = {
    'at_a_glance': {
        'instruction': """Analyze this Claude Code usage data and write an "At a Glance" executive summary.

Write exactly 4 short paragraphs (2-3 sentences each):
1. "whats_working": What workflows and patterns are producing good outcomes
2. "whats_hindering": What friction patterns and failure modes are costing time
3. "quick_wins": Concrete, specific actions to try based on the data
4. "ambitious": Forward-looking workflows that could unlock more value

Rules:
- Use second person ("you")
- Reference specific numbers from the data (success rates, friction counts, project names)
- Be specific to THIS user's data, not generic advice
- Keep each paragraph to 2-3 sentences maximum""",
        'schema': {
            'type': 'object',
            'properties': {
                'whats_working': {'type': 'string'},
                'whats_hindering': {'type': 'string'},
                'quick_wins': {'type': 'string'},
                'ambitious': {'type': 'string'},
            },
            'required': ['whats_working', 'whats_hindering', 'quick_wins', 'ambitious'],
            'additionalProperties': False,
        },
    },
    'friction_analysis': {
        'instruction': """Analyze the friction data and write a "Where Things Go Wrong" analysis.

Identify exactly 3 friction categories from the data. For each category:
- "title": A descriptive name for the friction pattern
- "description": 2-3 sentences explaining what causes this friction and how to mitigate it
- "examples": Exactly 2 specific examples from the friction_examples in the data

Rules:
- Ground every claim in the data provided — cite specific friction types and counts
- Make descriptions actionable — tell the user what to change, not just what's wrong
- Use specific project names and friction types from the data, never invent PR numbers or session details
- If friction_examples are sparse, describe the pattern using only the friction_type counts and project names provided — do not invent specific incidents""",
        'schema': {
            'type': 'object',
            'properties': {
                'intro': {'type': 'string'},
                'categories': {
                    'type': 'array',
                    'items': {
                        'type': 'object',
                        'properties': {
                            'title': {'type': 'string'},
                            'description': {'type': 'string'},
                            'examples': {
                                'type': 'array',
                                'items': {'type': 'string'},
                            },
                        },
                        'required': ['title', 'description', 'examples'],
                        'additionalProperties': False,
                    },
                },
            },
            'required': ['intro', 'categories'],
            'additionalProperties': False,
        },
    },
    'on_the_horizon': {
        'instruction': """Based on this user's friction patterns and usage data, write an "On the Horizon" section
with 3 forward-looking workflow recommendations.

For each recommendation:
- "title": A descriptive name for the workflow opportunity
- "whats_possible": 2-3 sentences explaining what this workflow could achieve, tied to specific friction patterns in the data
- "how_to_try": 1-2 sentences with a concrete getting-started approach
- "copyable_prompt": A ready-to-paste prompt the user can give to Claude Code to try this workflow

Rules:
- Each recommendation must address a specific friction pattern or gap visible in the data
- The copyable_prompt must be immediately usable — not a template with placeholders
- Focus on autonomous workflows, test-gated fixes, parallel agents, or headless automation
- Reference specific friction types, project names, or goal categories from the data
- Use only project names and friction types from the data — do not invent file paths, test names, or PR numbers""",
        'schema': {
            'type': 'object',
            'properties': {
                'intro': {'type': 'string'},
                'opportunities': {
                    'type': 'array',
                    'items': {
                        'type': 'object',
                        'properties': {
                            'title': {'type': 'string'},
                            'whats_possible': {'type': 'string'},
                            'how_to_try': {'type': 'string'},
                            'copyable_prompt': {'type': 'string'},
                        },
                        'required': ['title', 'whats_possible', 'how_to_try', 'copyable_prompt'],
                        'additionalProperties': False,
                    },
                },
            },
            'required': ['intro', 'opportunities'],
            'additionalProperties': False,
        },
    },
    'behavioral_profile': {
        'instruction': """Analyze this Claude Code usage data and write a behavioral profile of this user.

Write:
- "narrative": 2-3 paragraphs describing how this person uses Claude Code — their patterns,
  strengths, interaction style, and working rhythm. Reference specific numbers (tool counts,
  session types, goal categories, satisfaction patterns).
- "key_pattern": A single sentence capturing their behavioral signature.

Rules:
- Use second person ("you")
- Be analytically specific — cite exact numbers from the data
- Identify patterns in the data (e.g., do they prefer multi-task sessions? what goals dominate?)
- Connect satisfaction and friction patterns to behavioral style
- Do not be sycophantic — be objective and analytical""",
        'schema': {
            'type': 'object',
            'properties': {
                'narrative': {'type': 'string'},
                'key_pattern': {'type': 'string'},
            },
            'required': ['narrative', 'key_pattern'],
            'additionalProperties': False,
        },
    },
    'what_you_work_on': {
        'instruction': """Analyze this Claude Code usage data and write a "What You Work On" section.

Write:
- "intro": 1-2 sentences summarizing the user's primary work areas
- "projects": Array of 3-5 project clusters. For each:
  - "name": Project or work area name (e.g., "DealFlow AI Application Development")
  - "session_count": Approximate number of sessions (use "~N sessions" format)
  - "description": 2-3 sentences describing what work was done in this area. Reference specific
    task types, technologies, and outcomes from the data.

Rules:
- Derive project clusters from the projects data and goal_categories — group related work
- Reference specific tools, languages, and goal types from the data
- If project names are generic, infer the work type from goal categories and friction patterns
- Use second person ("you")
- Be specific about what technologies and patterns were used""",
        'schema': {
            'type': 'object',
            'properties': {
                'intro': {'type': 'string'},
                'projects': {
                    'type': 'array',
                    'items': {
                        'type': 'object',
                        'properties': {
                            'name': {'type': 'string'},
                            'session_count': {'type': 'string'},
                            'description': {'type': 'string'},
                        },
                        'required': ['name', 'session_count', 'description'],
                        'additionalProperties': False,
                    },
                },
            },
            'required': ['intro', 'projects'],
            'additionalProperties': False,
        },
    },
    'impressive_things': {
        'instruction': """Analyze this Claude Code usage data and write an "Impressive Things You Did" section.

Write:
- "intro": 1-2 sentences summarizing the user's most notable accomplishments
- "achievements": Array of exactly 3 achievements. For each:
  - "title": A descriptive name for the achievement
  - "description": 2-3 sentences explaining what was accomplished and why it's notable.
    Reference specific numbers (commits, lines, sessions, success rates) from the data.
- "what_helped_most": Array of 3-5 items describing which Claude capabilities helped most. For each:
  - "capability": Name of the capability (e.g., "Multi-file Changes", "Good Debugging")
  - "count": Approximate count of sessions where this was the primary value driver

Rules:
- Ground achievements in the data — cite project names, session counts, lines changed, commits
- Focus on outcomes and impact, not just activity volume
- Use the primary_successes examples and project data to identify specific accomplishments
- Use second person ("you")
- For what_helped_most, infer from tool usage, goal types, and helpfulness data""",
        'schema': {
            'type': 'object',
            'properties': {
                'intro': {'type': 'string'},
                'achievements': {
                    'type': 'array',
                    'items': {
                        'type': 'object',
                        'properties': {
                            'title': {'type': 'string'},
                            'description': {'type': 'string'},
                        },
                        'required': ['title', 'description'],
                        'additionalProperties': False,
                    },
                },
                'what_helped_most': {
                    'type': 'array',
                    'items': {
                        'type': 'object',
                        'properties': {
                            'capability': {'type': 'string'},
                            'count': {'type': 'integer'},
                        },
                        'required': ['capability', 'count'],
                        'additionalProperties': False,
                    },
                },
            },
            'required': ['intro', 'achievements', 'what_helped_most'],
            'additionalProperties': False,
        },
    },
    'features_to_try': {
        'instruction': """Based on this user's friction patterns and usage data, write a "Features to Try" section
recommending existing Claude Code features they should adopt.

Write:
- "intro": 1-2 sentences explaining why these features are recommended for this user
- "features": Array of exactly 3 features. For each:
  - "name": Feature name (e.g., "Hooks", "Custom Skills", "Headless Mode", "CLAUDE.md Rules")
  - "why_for_you": 2-3 sentences explaining why this feature addresses their specific friction
  - "example_config": A ready-to-use code snippet or configuration the user can copy

Rules:
- Each recommendation must address a specific friction pattern visible in the data
- Only recommend real Claude Code features: Hooks, Custom Skills, CLAUDE.md instructions,
  Headless Mode, Agent Teams, MCP Servers, /compact, /init, permission modes
- The example_config must be immediately usable, not a template
- Reference specific friction types and counts from the data""",
        'schema': {
            'type': 'object',
            'properties': {
                'intro': {'type': 'string'},
                'features': {
                    'type': 'array',
                    'items': {
                        'type': 'object',
                        'properties': {
                            'name': {'type': 'string'},
                            'why_for_you': {'type': 'string'},
                            'example_config': {'type': 'string'},
                        },
                        'required': ['name', 'why_for_you', 'example_config'],
                        'additionalProperties': False,
                    },
                },
            },
            'required': ['intro', 'features'],
            'additionalProperties': False,
        },
    },
    'new_usage_patterns': {
        'instruction': """Based on this user's usage data, write a "New Ways to Use Claude Code" section
with concrete workflow patterns they haven't tried yet.

Write:
- "intro": 1-2 sentences framing these as new workflow patterns
- "patterns": Array of exactly 3 patterns. For each:
  - "title": A descriptive name for the workflow pattern
  - "description": 2-3 sentences explaining what this pattern achieves and how it relates
    to their current friction or goals
  - "copyable_prompt": A ready-to-paste prompt the user can give to Claude Code

Rules:
- Each pattern must address a gap or friction visible in the data
- Patterns should be distinct from the "On the Horizon" recommendations (which are forward-looking)
- These should be immediately actionable with current Claude Code capabilities
- The copyable_prompt must be complete and ready to use
- Reference specific friction types, goal categories, or project data""",
        'schema': {
            'type': 'object',
            'properties': {
                'intro': {'type': 'string'},
                'patterns': {
                    'type': 'array',
                    'items': {
                        'type': 'object',
                        'properties': {
                            'title': {'type': 'string'},
                            'description': {'type': 'string'},
                            'copyable_prompt': {'type': 'string'},
                        },
                        'required': ['title', 'description', 'copyable_prompt'],
                        'additionalProperties': False,
                    },
                },
            },
            'required': ['intro', 'patterns'],
            'additionalProperties': False,
        },
    },
}


def _call_claude_headless(section_name, data_summary, prompt_config):
    """Call claude -p with structured output for one narrative section."""
    prompt = f"""{data_summary}

{prompt_config['instruction']}"""

    schema_json = json.dumps(prompt_config['schema'])

    # Strip CLAUDECODE env var to avoid blocking when called from inside a session
    env = {k: v for k, v in os.environ.items() if k != 'CLAUDECODE'}

    cmd = [
        'claude', '-p', prompt,
        '--json-schema', schema_json,
        '--output-format', 'json',
        '--allowedTools', '',
        '--no-session-persistence',
        '--model', 'sonnet',
    ]

    try:
        result = subprocess.run(
            cmd, capture_output=True, text=True, env=env,
            timeout=120,
        )
        if result.returncode != 0:
            return section_name, None, f"Exit code {result.returncode}: {result.stderr[:200]}"

        events = json.loads(result.stdout)
        for event in events:
            if event.get('type') == 'result' and event.get('structured_output'):
                return section_name, event['structured_output'], None
        return section_name, None, "No structured_output in response"

    except subprocess.TimeoutExpired:
        return section_name, None, "Timeout (120s)"
    except Exception as e:
        return section_name, None, str(e)[:200]


def _compute_cache_key(data_summary):
    """Hash the data summary to detect when narratives need regeneration."""
    return hashlib.sha256(data_summary.encode()).hexdigest()[:16]


def _load_cached_narratives(cache_key):
    """Load cached narratives if they exist and match the current data."""
    cache_file = NARRATIVE_CACHE_DIR / f"{cache_key}.json"
    if cache_file.exists():
        try:
            return json.loads(cache_file.read_text())
        except (json.JSONDecodeError, OSError):
            pass
    return None


def _save_cached_narratives(cache_key, narratives):
    """Save narratives to cache."""
    NARRATIVE_CACHE_DIR.mkdir(parents=True, exist_ok=True)
    cache_file = NARRATIVE_CACHE_DIR / f"{cache_key}.json"
    cache_file.write_text(json.dumps(narratives, indent=2))


def generate_narratives(kpis, trends, projects, sessions):
    """Generate LLM-powered narrative sections via parallel headless Claude calls.

    Returns dict of {section_name: structured_output_dict} for successful sections,
    or empty dict if generation fails.
    """
    data_summary = _build_data_summary(kpis, trends, projects, sessions)

    # Check cache
    cache_key = _compute_cache_key(data_summary)
    cached = _load_cached_narratives(cache_key)
    if cached:
        print("  Using cached narratives (data unchanged)")
        return cached

    # Run all prompts in parallel
    narratives = {}
    errors = []

    with ThreadPoolExecutor(max_workers=8) as executor:
        futures = {
            executor.submit(_call_claude_headless, name, data_summary, config): name
            for name, config in NARRATIVE_PROMPTS.items()
        }
        for future in as_completed(futures):
            name, result, error = future.result()
            if result:
                narratives[name] = result
                print(f"    [{name}] OK")
            else:
                errors.append(f"[{name}] {error}")
                print(f"    [{name}] FAILED: {error}")

    if errors:
        print(f"  {len(errors)} section(s) failed — dashboard will render without them")

    # Cache successful results
    if narratives:
        _save_cached_narratives(cache_key, narratives)

    return narratives


# ══════════════════════════════════════════════════════════════════════════
# Phase 5: Output
# ══════════════════════════════════════════════════════════════════════════

def _strip_internal_keys(framework_stats):
    """Strip private _events / _scorecards keys before JSON serialization.

    load_fw_project_metrics attaches the raw events and scorecards to each
    per-project dict so aggregate_fw_stats can re-aggregate the unioned
    data per canonical project (averaging averages would be biased). The
    rolled-up dicts that come out of aggregate_fw_stats already omit those
    keys, but we strip defensively here in case a caller passes in
    unrolled per-project metrics. Returns None unchanged so the caller's
    "no framework projects" path stays simple.
    """
    if not framework_stats:
        return None
    cleaned_projects = []
    for p in framework_stats.get("projects", []):
        cleaned_projects.append({k: v for k, v in p.items() if not k.startswith("_")})
    return {
        "projects": cleaned_projects,
        "aggregate": framework_stats.get("aggregate", {}),
        "skipped": framework_stats.get("skipped", []),
    }


def build_payload(sessions, kpis, trends, projects, insights, meta,
                   stats_cache=None, narratives=None, framework_stats=None,
                   freshness=None):
    """Build the JSON payload to embed in HTML."""
    # Build per-session records for the table
    session_records = []
    for s in sessions:
        rec = {
            'session_id': s['session_id'],
            'canonical_project': s.get('canonical_project', ''),
            'start_time': s.get('start_time', ''),
            'duration_minutes': s.get('duration_minutes', 0),
            'user_message_count': s.get('user_message_count', 0),
            'tool_errors': s.get('tool_errors', 0),
            'lines_added': s.get('lines_added', 0),
            'lines_removed': s.get('lines_removed', 0),
            'git_commits': s.get('git_commits', 0),
            'first_prompt': (s.get('first_prompt', '') or '')[:120],
            'has_facets': s.get('has_facets', False),
            'files_modified': s.get('files_modified', 0),
        }
        if s.get('has_facets'):
            rec['outcome'] = s.get('outcome', '')
            rec['satisfaction'] = s.get('user_satisfaction_counts', {})
            rec['friction'] = s.get('friction_counts', {})
            rec['helpfulness'] = s.get('claude_helpfulness', '')
            rec['goal_categories'] = s.get('goal_categories', {})
            rec['session_type'] = s.get('session_type', '')
            rec['brief_summary'] = s.get('brief_summary', '')
        session_records.append(rec)

    # Unique projects for filter dropdown
    project_list = sorted(set(s.get('canonical_project', '') for s in sessions))

    # Determine data coverage boundaries
    meta_dates = sorted(s.get('start_time', '')[:10] for s in sessions if s.get('start_time'))
    meta_start = meta_dates[0] if meta_dates else None
    meta_end = meta_dates[-1] if meta_dates else None

    cache_start = None
    if stats_cache:
        da = stats_cache.get('daily_activity', [])
        if da:
            cache_dates = sorted(d['date'] for d in da if d.get('date'))
            cache_start = cache_dates[0] if cache_dates else None

    data_coverage = {
        'session_meta_start': meta_start,
        'session_meta_end': meta_end,
        'session_meta_count': len(sessions),
        'facets_count': sum(1 for s in sessions if s.get('has_facets')),
        'stats_cache_start': cache_start,
        'stats_cache_total_sessions': stats_cache['total_sessions'] if stats_cache else 0,
        'stats_cache_total_messages': stats_cache['total_messages'] if stats_cache else 0,
        'has_stats_cache': stats_cache is not None,
    }

    return {
        'meta': meta,
        'kpis': kpis,
        'trends': trends,
        'projects': projects,
        'insights': insights,
        'sessions': session_records,
        'project_list': project_list,
        'data_coverage': data_coverage,
        'stats_cache': {
            'daily_activity': stats_cache['daily_activity'] if stats_cache else [],
            'daily_model_tokens': stats_cache['daily_model_tokens'] if stats_cache else [],
            'model_usage': stats_cache['model_usage'] if stats_cache else {},
            'hour_counts': stats_cache['hour_counts'] if stats_cache else {},
        } if stats_cache else None,
        'narratives': narratives or {},
        'framework_stats': _strip_internal_keys(framework_stats),
        'freshness': freshness or {},
    }


def build_html(payload_json):
    """Build the self-contained HTML dashboard."""
    return f'''<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Claude Code Insights</title>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.7/dist/chart.umd.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chartjs-adapter-date-fns@3.0.0/dist/chartjs-adapter-date-fns.bundle.min.js"></script>
<link rel="stylesheet" href="https://unpkg.com/frappe-charts@1.6.2/dist/frappe-charts.min.css">
<script src="https://unpkg.com/frappe-charts@1.6.2/dist/frappe-charts.min.iife.js"></script>
<style>
:root {{
  --bg: #0f1117; --bg2: #1a1d27; --bg3: #242836; --border: #2d3348;
  --text: #e2e8f0; --text2: #94a3b8;
  --accent: #6366f1; --accent2: #818cf8;
  --green: #22c55e; --orange: #f59e0b; --red: #ef4444;
  --blue: #3b82f6; --purple: #a855f7; --cyan: #06b6d4; --pink: #ec4899;
}}
* {{ margin:0; padding:0; box-sizing:border-box; }}
body {{ background:var(--bg); color:var(--text); font-family:'Segoe UI',system-ui,-apple-system,sans-serif; font-size:14px; }}

/* Header / Filters */
.header {{ background:var(--bg2); border-bottom:1px solid var(--border); padding:16px 24px; position:sticky; top:0; z-index:100; }}
.header-top {{ display:flex; align-items:center; justify-content:space-between; margin-bottom:12px; }}
.header h1 {{ font-size:20px; font-weight:600; }}
.header h1 span {{ color:var(--accent2); }}
.header .meta {{ color:var(--text2); font-size:13px; }}
.filter-bar {{ display:flex; gap:12px; align-items:center; flex-wrap:wrap; }}
.time-filter {{ display:flex; gap:4px; }}
.time-filter button {{ background:var(--bg3); border:1px solid var(--border); color:var(--text2); padding:6px 14px; border-radius:6px; font-size:12px; font-weight:600; cursor:pointer; transition:all .2s; }}
.time-filter button:hover {{ color:var(--text); border-color:var(--accent); }}
.time-filter button.active {{ background:var(--accent); color:white; border-color:var(--accent); }}
.project-select {{ background:var(--bg3); border:1px solid var(--border); color:var(--text); padding:6px 12px; border-radius:6px; font-size:12px; min-width:200px; }}
.chips {{ display:flex; gap:6px; flex-wrap:wrap; }}
.chip {{ background:var(--accent); color:white; padding:3px 10px; border-radius:12px; font-size:11px; cursor:pointer; display:flex; align-items:center; gap:4px; }}
.chip:hover {{ background:var(--red); }}
.chip::after {{ content:"\\00d7"; font-size:14px; }}

.container {{ max-width:1400px; margin:0 auto; padding:20px; }}

/* KPI Cards */
.kpi-grid {{ display:grid; grid-template-columns:repeat(auto-fit,minmax(180px,1fr)); gap:16px; margin-bottom:24px; }}
.kpi-card {{ background:var(--bg2); border:1px solid var(--border); border-radius:12px; padding:20px; }}
.kpi-card .label {{ color:var(--text2); font-size:11px; text-transform:uppercase; letter-spacing:0.5px; margin-bottom:8px; }}
.kpi-card .value {{ font-size:28px; font-weight:700; }}
.kpi-card .sub {{ color:var(--text2); font-size:12px; margin-top:4px; }}

/* Insight Cards */
.insights-panel {{ margin-bottom:24px; }}
.insights-panel h2 {{ font-size:16px; font-weight:600; margin-bottom:12px; color:var(--accent2); }}
.insights-grid {{ display:grid; grid-template-columns:repeat(auto-fit,minmax(300px,1fr)); gap:12px; }}
.insight-card {{ background:var(--bg2); border:1px solid var(--border); border-radius:10px; padding:16px; display:flex; gap:12px; align-items:flex-start; }}
.insight-icon {{ width:36px; height:36px; border-radius:8px; display:flex; align-items:center; justify-content:center; font-size:18px; flex-shrink:0; }}
.insight-icon.warning {{ background:rgba(245,158,11,0.15); color:var(--orange); }}
.insight-icon.positive {{ background:rgba(34,197,94,0.15); color:var(--green); }}
.insight-icon.info {{ background:rgba(99,102,241,0.15); color:var(--accent2); }}
.insight-icon.negative {{ background:rgba(239,68,68,0.15); color:var(--red); }}
.insight-text {{ font-size:13px; line-height:1.5; }}
.insight-category {{ font-size:10px; text-transform:uppercase; letter-spacing:0.5px; color:var(--text2); margin-top:4px; }}

/* Charts */
.chart-grid {{ display:grid; grid-template-columns:1fr 1fr; gap:20px; margin-bottom:20px; }}
.chart-grid.full {{ grid-template-columns:1fr; }}
.chart-box {{ background:var(--bg2); border:1px solid var(--border); border-radius:12px; padding:20px; }}
.chart-box h3 {{ font-size:15px; font-weight:600; margin-bottom:16px; }}
.chart-box canvas {{ max-height:350px; }}

/* Heatmap */
.heatmap-container {{ background:var(--bg2); border:1px solid var(--border); border-radius:12px; padding:20px; margin-bottom:20px; }}
.heatmap-container h3 {{ font-size:15px; font-weight:600; margin-bottom:16px; }}

/* Table */
.data-table {{ width:100%; border-collapse:collapse; }}
.data-table th {{ text-align:left; padding:10px 12px; font-size:12px; color:var(--text2); text-transform:uppercase; letter-spacing:0.5px; border-bottom:2px solid var(--border); cursor:pointer; user-select:none; white-space:nowrap; }}
.data-table th:hover {{ color:var(--accent2); }}
.data-table th.sort-asc::after {{ content:" \\25B2"; font-size:10px; }}
.data-table th.sort-desc::after {{ content:" \\25BC"; font-size:10px; }}
.data-table td {{ padding:10px 12px; border-bottom:1px solid var(--border); font-size:13px; }}
.data-table tr:hover td {{ background:var(--bg3); }}
.data-table .num {{ text-align:right; font-variant-numeric:tabular-nums; }}
.outcome-badge {{ display:inline-block; padding:2px 8px; border-radius:4px; font-size:11px; font-weight:600; }}
.outcome-badge.fully_achieved {{ background:rgba(34,197,94,0.2); color:var(--green); }}
.outcome-badge.partially_achieved {{ background:rgba(245,158,11,0.2); color:var(--orange); }}
.outcome-badge.not_achieved {{ background:rgba(239,68,68,0.2); color:var(--red); }}
.pagination {{ display:flex; gap:8px; justify-content:center; margin-top:16px; align-items:center; }}
.pagination button {{ background:var(--bg3); border:1px solid var(--border); color:var(--text); padding:6px 14px; border-radius:6px; cursor:pointer; }}
.pagination button:hover {{ background:var(--accent); }}
.pagination .info {{ color:var(--text2); padding:6px 0; font-size:13px; }}

/* Data Coverage Banner */
.coverage-banner {{ background:var(--bg2); border:1px solid var(--border); border-radius:12px; padding:16px 20px; margin-bottom:24px; }}
.coverage-banner h3 {{ font-size:14px; font-weight:600; margin-bottom:12px; color:var(--accent2); }}
.coverage-bar {{ display:flex; align-items:center; gap:12px; margin-bottom:8px; }}
.coverage-bar .bar-track {{ flex:1; height:8px; background:var(--bg3); border-radius:4px; position:relative; overflow:visible; }}
.coverage-bar .bar-segment {{ height:100%; border-radius:4px; position:absolute; top:0; }}
.coverage-bar .label {{ font-size:11px; color:var(--text2); white-space:nowrap; min-width:90px; }}
.coverage-legend {{ display:flex; gap:16px; flex-wrap:wrap; margin-top:8px; }}
.coverage-legend .item {{ display:flex; align-items:center; gap:6px; font-size:11px; color:var(--text2); }}
.coverage-legend .dot {{ width:8px; height:8px; border-radius:50%; flex-shrink:0; }}
.coverage-note {{ font-size:11px; color:var(--text2); margin-top:8px; line-height:1.5; }}
.coverage-note strong {{ color:var(--orange); }}

/* Section Divider */
.section-divider {{ border-top:1px solid var(--border); margin:32px 0 24px; padding-top:24px; }}
.section-divider h2 {{ font-size:18px; font-weight:600; margin-bottom:4px; }}
.section-divider .subtitle {{ font-size:12px; color:var(--text2); }}

/* Narrative: At a Glance */
.at-a-glance {{ background:linear-gradient(135deg, rgba(245,158,11,0.12) 0%, rgba(251,191,36,0.08) 100%); border:1px solid rgba(245,158,11,0.3); border-radius:12px; padding:20px 24px; margin-bottom:24px; }}
.glance-title {{ font-size:16px; font-weight:700; color:var(--orange); margin-bottom:16px; }}
.glance-sections {{ display:flex; flex-direction:column; gap:14px; }}
.glance-section {{ font-size:13px; color:var(--text); line-height:1.7; }}
.glance-section strong {{ color:var(--orange); }}

/* Narrative: Friction Analysis */
.friction-categories {{ display:flex; flex-direction:column; gap:16px; margin-bottom:24px; }}
.friction-category {{ background:rgba(239,68,68,0.08); border:1px solid rgba(239,68,68,0.25); border-radius:10px; padding:16px; }}
.friction-cat-title {{ font-weight:600; font-size:15px; color:var(--red); margin-bottom:6px; }}
.friction-cat-desc {{ font-size:13px; color:var(--text); margin-bottom:10px; line-height:1.6; }}
.friction-cat-examples {{ margin:0 0 0 20px; font-size:13px; color:var(--text2); }}
.friction-cat-examples li {{ margin-bottom:4px; line-height:1.5; }}

/* Narrative: On the Horizon */
.horizon-section {{ display:flex; flex-direction:column; gap:16px; margin-bottom:24px; }}
.horizon-card {{ background:linear-gradient(135deg, rgba(168,85,247,0.1) 0%, rgba(139,92,246,0.06) 100%); border:1px solid rgba(168,85,247,0.25); border-radius:10px; padding:16px; }}
.horizon-title {{ font-weight:600; font-size:15px; color:var(--purple); margin-bottom:8px; }}
.horizon-possible {{ font-size:13px; color:var(--text); margin-bottom:10px; line-height:1.6; }}
.horizon-tip {{ font-size:13px; color:var(--accent2); background:rgba(255,255,255,0.04); padding:8px 12px; border-radius:6px; margin-bottom:10px; }}
.horizon-prompt {{ background:var(--bg3); padding:12px; border-radius:6px; border:1px solid var(--border); display:flex; align-items:flex-start; gap:8px; }}
.horizon-prompt code {{ flex:1; font-family:monospace; font-size:12px; color:var(--text); white-space:pre-wrap; line-height:1.5; }}
.horizon-prompt .copy-btn {{ background:var(--bg2); border:1px solid var(--border); color:var(--text2); padding:4px 10px; border-radius:4px; font-size:11px; cursor:pointer; flex-shrink:0; }}
.horizon-prompt .copy-btn:hover {{ background:var(--accent); color:white; }}

/* Narrative: Behavioral Profile */
.narrative-box {{ background:var(--bg2); border:1px solid var(--border); border-radius:12px; padding:20px; margin-bottom:24px; }}
.narrative-box p {{ margin-bottom:12px; font-size:13px; color:var(--text); line-height:1.7; }}
.key-pattern {{ background:rgba(34,197,94,0.1); border:1px solid rgba(34,197,94,0.25); border-radius:8px; padding:12px 16px; margin-top:12px; font-size:13px; color:var(--green); font-weight:500; }}

/* Narrative: What You Work On */
.work-on-section {{ display:flex; flex-direction:column; gap:14px; margin-bottom:24px; }}
.work-on-card {{ background:rgba(59,130,246,0.08); border:1px solid rgba(59,130,246,0.25); border-radius:10px; padding:16px; }}
.work-on-title {{ font-weight:600; font-size:15px; color:var(--blue); margin-bottom:2px; }}
.work-on-count {{ font-size:12px; color:var(--text2); margin-bottom:8px; }}
.work-on-desc {{ font-size:13px; color:var(--text); line-height:1.6; }}

/* Narrative: Impressive Things */
.impressive-section {{ display:flex; flex-direction:column; gap:14px; margin-bottom:24px; }}
.impressive-card {{ background:rgba(34,197,94,0.08); border:1px solid rgba(34,197,94,0.25); border-radius:10px; padding:16px; }}
.impressive-title {{ font-weight:600; font-size:15px; color:var(--green); margin-bottom:6px; }}
.impressive-desc {{ font-size:13px; color:var(--text); line-height:1.6; }}
.helped-most {{ display:flex; flex-wrap:wrap; gap:10px; margin-top:12px; }}
.helped-item {{ background:var(--bg3); border:1px solid var(--border); border-radius:8px; padding:8px 14px; font-size:13px; }}
.helped-item .count {{ color:var(--green); font-weight:600; margin-left:6px; }}

/* Narrative: Features to Try */
.features-section {{ display:flex; flex-direction:column; gap:16px; margin-bottom:24px; }}
.feature-card {{ background:rgba(6,182,212,0.08); border:1px solid rgba(6,182,212,0.25); border-radius:10px; padding:16px; }}
.feature-name {{ font-weight:600; font-size:15px; color:var(--cyan); margin-bottom:6px; }}
.feature-why {{ font-size:13px; color:var(--text); margin-bottom:10px; line-height:1.6; }}
.feature-config {{ background:var(--bg3); padding:12px; border-radius:6px; border:1px solid var(--border); display:flex; align-items:flex-start; gap:8px; }}
.feature-config code {{ flex:1; font-family:monospace; font-size:12px; color:var(--text); white-space:pre-wrap; line-height:1.5; }}
.feature-config .copy-btn {{ background:var(--bg2); border:1px solid var(--border); color:var(--text2); padding:4px 10px; border-radius:4px; font-size:11px; cursor:pointer; flex-shrink:0; }}
.feature-config .copy-btn:hover {{ background:var(--accent); color:white; }}

/* Narrative: New Usage Patterns */
.patterns-section {{ display:flex; flex-direction:column; gap:16px; margin-bottom:24px; }}
.pattern-card {{ background:rgba(236,72,153,0.08); border:1px solid rgba(236,72,153,0.25); border-radius:10px; padding:16px; }}
.pattern-title {{ font-weight:600; font-size:15px; color:var(--pink); margin-bottom:6px; }}
.pattern-desc {{ font-size:13px; color:var(--text); margin-bottom:10px; line-height:1.6; }}
.pattern-prompt {{ background:var(--bg3); padding:12px; border-radius:6px; border:1px solid var(--border); display:flex; align-items:flex-start; gap:8px; }}
.pattern-prompt code {{ flex:1; font-family:monospace; font-size:12px; color:var(--text); white-space:pre-wrap; line-height:1.5; }}
.pattern-prompt .copy-btn {{ background:var(--bg2); border:1px solid var(--border); color:var(--text2); padding:4px 10px; border-radius:4px; font-size:11px; cursor:pointer; flex-shrink:0; }}
.pattern-prompt .copy-btn:hover {{ background:var(--accent); color:white; }}

/* Narrative disclaimer */
.narrative-disclaimer {{ font-size:11px; color:var(--text2); margin-top:8px; font-style:italic; }}
.narrative-filter-banner {{ display:none; background:rgba(245,158,11,0.1); border:1px solid rgba(245,158,11,0.25); border-radius:8px; padding:10px 16px; margin-bottom:16px; font-size:12px; color:var(--orange); text-align:center; }}

/* Collapsible */
.collapsible-header {{ display:flex; align-items:center; gap:8px; cursor:pointer; padding:8px 0; }}
.collapsible-header h2 {{ margin:0; font-size:18px; font-weight:600; }}
.collapsible-header h3 {{ margin:0; font-size:15px; font-weight:600; }}
.collapsible-arrow {{ font-size:12px; color:var(--text2); transition:transform 0.2s; }}
.collapsible-content {{ display:none; padding-top:12px; }}
.collapsible-content.open {{ display:block; }}
.collapsible-header.open .collapsible-arrow {{ transform:rotate(90deg); }}

@media (max-width:768px) {{
  .chart-grid {{ grid-template-columns:1fr; }}
  .kpi-grid {{ grid-template-columns:repeat(2,1fr); }}
}}
</style>
</head>
<body>

<div class="header">
  <div class="header-top">
    <h1>Claude Code <span>Insights</span></h1>
    <div class="meta" id="metaInfo"></div>
  </div>
  <div class="filter-bar">
    <div class="time-filter" id="timeFilter">
      <button data-range="7">7D</button>
      <button data-range="30">30D</button>
      <button data-range="90">90D</button>
      <button data-range="0" class="active">All</button>
    </div>
    <select class="project-select" id="projectSelect" multiple>
      <option value="">All Projects</option>
    </select>
    <div class="chips" id="projectChips"></div>
  </div>
</div>

<div class="container">
  <!-- Data Freshness Banner (AC-Freshness) -->
  <div id="freshnessBanner"></div>

  <!-- Data Coverage Banner -->
  <div class="coverage-banner" id="coverageBanner"></div>

  <!-- KPI Cards -->
  <div class="kpi-grid" id="kpiGrid"></div>

  <!-- At a Glance (narrative) -->
  <div id="narrativeFilterBanner" class="narrative-filter-banner">Narratives reflect the full dataset. Filtered views apply to charts, KPIs, and table only.</div>
  <div id="narrativeGlance" style="display:none;"></div>

  <!-- What You Work On (narrative) -->
  <div id="narrativeWorkOn" style="display:none;"></div>

  <!-- Insights Panel -->
  <div class="insights-panel" id="insightsPanel">
    <h2>Algorithmic Insights</h2>
    <div class="insights-grid" id="insightsGrid"></div>
    <div style="color:var(--text2);font-size:11px;margin-top:8px;">Insights reflect the full dataset, not filtered views.</div>
  </div>

  <!-- Charts Row 1: Outcomes + Satisfaction -->
  <div class="chart-grid">
    <div class="chart-box"><h3>Outcomes</h3><canvas id="outcomeChart"></canvas></div>
    <div class="chart-box"><h3>Satisfaction (Diverging)</h3><canvas id="satisfactionChart"></canvas></div>
  </div>

  <!-- Impressive Things You Did (narrative) -->
  <div id="narrativeImpressive" style="display:none;"></div>

  <!-- Charts Row 2: Friction + Goals -->
  <div class="chart-grid">
    <div class="chart-box"><h3>Friction Types</h3><canvas id="frictionChart"></canvas></div>
    <div class="chart-box"><h3>Goal Categories</h3><canvas id="goalChart"></canvas></div>
  </div>

  <!-- Where Things Go Wrong (narrative) -->
  <div id="narrativeFriction" style="display:none;"></div>

  <!-- Features to Try (narrative) -->
  <div id="narrativeFeatures" style="display:none;"></div>

  <!-- Outcomes Trend (full width) -->
  <div class="chart-grid full">
    <div class="chart-box"><h3>Outcomes Over Time</h3><canvas id="outcomeTrendChart"></canvas></div>
  </div>

  <!-- New Usage Patterns (narrative) -->
  <div id="narrativePatterns" style="display:none;"></div>

  <!-- Activity Heatmap -->
  <div class="heatmap-container">
    <h3>Activity Heatmap</h3>
    <div id="heatmapChart"></div>
  </div>

  <!-- Sessions Over Time -->
  <div class="chart-grid full">
    <div class="chart-box"><h3>Sessions &amp; Friction Over Time</h3><canvas id="sessionTrendChart"></canvas></div>
  </div>

  <!-- On the Horizon (narrative) -->
  <div id="narrativeHorizon" style="display:none;"></div>

  <!-- Behavioral Profile (narrative, collapsible) -->
  <div id="narrativeProfile" style="display:none;"></div>

  <!-- Historical Trends (from stats-cache) -->
  <div class="section-divider" id="historicalSection" style="display:none;">
    <h2>Historical Trends</h2>
    <div class="subtitle">Aggregate data from stats-cache.json — covers your full Claude Code history</div>
  </div>
  <div id="historicalCharts" style="display:none;">
    <div class="chart-grid full">
      <div class="chart-box"><h3>Daily Activity (Full History)</h3><canvas id="historyActivityChart"></canvas></div>
    </div>
    <div class="chart-grid">
      <div class="chart-box"><h3>Daily Tokens by Model</h3><canvas id="historyTokenChart"></canvas></div>
      <div class="chart-box"><h3>Cumulative Model Usage</h3><canvas id="modelUsageChart"></canvas></div>
    </div>
  </div>

  <!-- Framework Stats (per-project + aggregate from .context/metrics/) -->
  <div id="frameworkStats" style="display:none;"></div>

  <!-- Session Table -->
  <div class="chart-box" style="margin-bottom:20px;">
    <h3>Session Details</h3>
    <table class="data-table" id="sessionTable">
      <thead>
        <tr>
          <th data-sort="start_time">Date</th>
          <th data-sort="canonical_project">Project</th>
          <th data-sort="outcome">Outcome</th>
          <th data-sort="duration_minutes" class="num">Duration</th>
          <th data-sort="user_message_count" class="num">Messages</th>
          <th data-sort="tool_errors" class="num">Errors</th>
          <th data-sort="lines_added" class="num">Lines+</th>
          <th>Session ID</th>
          <th>Prompt</th>
        </tr>
      </thead>
      <tbody id="sessionTableBody"></tbody>
    </table>
    <div class="pagination" id="pagination"></div>
  </div>
</div>

<script>
// ── Data ──
const DATA = {payload_json};

// ── State ──
let activeRange = 0; // 0 = all
let selectedProjects = new Set();
let sortCol = 'start_time';
let sortDir = 'desc';
let currentPage = 1;
const PAGE_SIZE = 25;

// ── Init ──
function init() {{
  loadUrlState();
  populateProjectDropdown();
  renderInsights();
  renderNarratives();
  renderCoverageBanner();
  renderFreshnessBanner();
  applyFilters();
  setupEventListeners();
  renderMetaInfo();
  renderHistoricalCharts();
  renderFrameworkStats();
}}

function renderFreshnessBanner() {{
  // Warn loudly when session-meta has not been updated in the last N hours.
  // Absent data is treated as stale so the dashboard never silently renders
  // blank instead of surfacing that the upstream writer has stopped.
  const el = document.getElementById('freshnessBanner');
  if (!el) return;
  const f = DATA.freshness || {{}};
  if (!f.stale) return;
  const ageText = f.age_hours === null || f.age_hours === undefined
    ? 'empty or missing'
    : `${{f.age_hours.toFixed(1)}}h old (threshold ${{(f.threshold_hours || 24).toFixed(0)}}h)`;
  el.innerHTML =
    '<div style="background:rgba(255,165,0,0.15);border:1px solid var(--orange);border-left:4px solid var(--orange);padding:10px 14px;margin-bottom:16px;border-radius:6px;font-size:13px;">' +
    '<strong>\u26A0 Stale session-meta:</strong> ' + ageText + '. ' +
    'The upstream extractor (claude-code-stats Stop-hook or equivalent) may have stopped writing. ' +
    'Per-session detail and qualitative facets shown below may be older than they appear.' +
    '</div>';
}}

function loadUrlState() {{
  const params = new URLSearchParams(window.location.search);
  if (params.has('range')) activeRange = parseInt(params.get('range')) || 0;
  if (params.has('projects')) {{
    params.getAll('projects').forEach(p => selectedProjects.add(p));
  }}
  // Highlight active time button
  document.querySelectorAll('.time-filter button').forEach(btn => {{
    btn.classList.toggle('active', parseInt(btn.dataset.range) === activeRange);
  }});
}}

function saveUrlState() {{
  const params = new URLSearchParams();
  if (activeRange) params.set('range', activeRange);
  selectedProjects.forEach(p => params.append('projects', p));
  const qs = params.toString();
  history.replaceState(null, '', qs ? '?' + qs : window.location.pathname);
}}

function renderMetaInfo() {{
  const m = DATA.meta;
  const dc = DATA.data_coverage;
  let info = `Generated ${{m.generated_at}}`;
  if (dc.has_stats_cache) {{
    info += ` · ${{dc.stats_cache_total_sessions.toLocaleString()}} total sessions (since ${{dc.stats_cache_start}})`;
  }}
  info += ` · ${{dc.session_meta_count}} with detail · ${{dc.facets_count}} analyzed`;
  document.getElementById('metaInfo').textContent = info;
}}

// ── Filtering ──
function getFilteredSessions() {{
  let sessions = DATA.sessions;
  if (activeRange > 0) {{
    const cutoff = new Date();
    cutoff.setDate(cutoff.getDate() - activeRange);
    const cutoffStr = cutoff.toISOString();
    sessions = sessions.filter(s => s.start_time >= cutoffStr);
  }}
  if (selectedProjects.size > 0) {{
    sessions = sessions.filter(s => selectedProjects.has(s.canonical_project));
  }}
  return sessions;
}}

function applyFilters() {{
  saveUrlState();
  const filtered = getFilteredSessions();
  renderKPIs(filtered);
  renderCharts(filtered);
  renderTable(filtered);
  renderChips();
  // Show/hide narrative filter warning
  const anyFilter = activeRange > 0 || selectedProjects.size > 0;
  document.getElementById('narrativeFilterBanner').style.display = anyFilter ? 'block' : 'none';
}}

// ── Project Dropdown ──
function populateProjectDropdown() {{
  const sel = document.getElementById('projectSelect');
  DATA.project_list.forEach(p => {{
    if (!p) return;
    const opt = document.createElement('option');
    opt.value = p;
    opt.textContent = p;
    opt.selected = selectedProjects.has(p);
    sel.appendChild(opt);
  }});
}}

function renderChips() {{
  const container = document.getElementById('projectChips');
  container.innerHTML = '';
  selectedProjects.forEach(p => {{
    const chip = document.createElement('span');
    chip.className = 'chip';
    chip.textContent = p;
    chip.onclick = () => {{ selectedProjects.delete(p); applyFilters(); }};
    container.appendChild(chip);
  }});
}}

// ── KPIs ──
function renderKPIs(sessions) {{
  const analyzed = sessions.filter(s => s.has_facets);
  const outcomes = {{}};
  let satPos = 0, satNeg = 0;
  let totalFriction = 0;
  const goals = {{}};
  const POSITIVE = new Set(['satisfied','happy','very_satisfied','delighted','likely_satisfied']);
  const NEGATIVE = new Set(['frustrated','dissatisfied','very_frustrated','unhappy']);

  analyzed.forEach(s => {{
    outcomes[s.outcome] = (outcomes[s.outcome] || 0) + 1;
    Object.entries(s.satisfaction || {{}}).forEach(([k,v]) => {{
      if (POSITIVE.has(k.toLowerCase())) satPos += v;
      else if (NEGATIVE.has(k.toLowerCase())) satNeg += v;
    }});
    Object.values(s.friction || {{}}).forEach(v => totalFriction += v);
    Object.entries(s.goal_categories || {{}}).forEach(([k,v]) => {{
      goals[k] = (goals[k] || 0) + v;
    }});
  }});

  const nSuccess = outcomes.fully_achieved || 0;
  const successRate = analyzed.length > 0
    ? ((nSuccess / analyzed.length) * 100).toFixed(0)
    : '—';
  // Wilson 95% CI
  function wilsonCI(k, n) {{
    if (n === 0) return [0, 0];
    const p = k / n, z = 1.96, d = 1 + z*z/n;
    const c = (p + z*z/(2*n)) / d;
    const m = z * Math.sqrt((p*(1-p) + z*z/(4*n)) / n) / d;
    return [Math.max(0, Math.round((c-m)*100)), Math.min(100, Math.round((c+m)*100))];
  }}
  const [ciLow, ciHigh] = wilsonCI(nSuccess, analyzed.length);
  const ciText = analyzed.length > 0 ? ` (${{ciLow}}-${{ciHigh}}%)` : '';

  const satTotal = satPos + satNeg;
  const netSat = satTotal > 0 ? ((satPos - satNeg) / satTotal * 100).toFixed(0) : '—';
  const topGoal = Object.entries(goals).sort((a,b) => b[1]-a[1])[0];

  const grid = document.getElementById('kpiGrid');
  grid.innerHTML = `
    <div class="kpi-card"><div class="label">Sessions</div><div class="value" style="color:var(--blue)">${{sessions.length}}</div><div class="sub">${{analyzed.length}} analyzed</div></div>
    <div class="kpi-card"><div class="label">Success Rate</div><div class="value" style="color:var(--green)">${{successRate}}%</div><div class="sub">${{nSuccess}} fully achieved${{ciText}}</div></div>
    <div class="kpi-card"><div class="label">Net Satisfaction</div><div class="value" style="color:${{parseInt(netSat)>=0?'var(--green)':'var(--red)'}}">${{netSat}}%</div><div class="sub">+${{satPos}} / -${{satNeg}}</div></div>
    <div class="kpi-card"><div class="label">Friction Events</div><div class="value" style="color:var(--orange)">${{totalFriction}}</div><div class="sub">${{analyzed.length > 0 ? (totalFriction/analyzed.length).toFixed(1) : 0}} per session</div></div>
    <div class="kpi-card"><div class="label">Top Goal</div><div class="value" style="color:var(--purple);font-size:18px">${{topGoal ? escHtml(topGoal[0].replace(/_/g,' ')) : '—'}}</div><div class="sub">${{topGoal ? topGoal[1]+' instances' : ''}}</div></div>
  `;
}}

// ── Insights ──
function renderInsights() {{
  const grid = document.getElementById('insightsGrid');
  const iconMap = {{
    'warning': ['!', 'warning'],
    'trending_up': ['\\u2191', 'positive'],
    'trending_down': ['\\u2193', 'negative'],
    'flag': ['\\u2691', 'warning'],
    'build': ['\\u2699', 'info'],
    'info': ['i', 'info'],
    'timer': ['\\u23F1', 'info'],
    'local_fire_department': ['\\uD83D\\uDD25', 'positive'],
    'check_circle': ['\\u2713', 'positive'],
    'thumb_up': ['\\uD83D\\uDC4D', 'positive'],
    'schedule': ['\\u23F0', 'info'],
  }};
  grid.innerHTML = DATA.insights.map(ins => {{
    const [icon, cls] = iconMap[ins.icon] || ['?', 'info'];
    return `<div class="insight-card">
      <div class="insight-icon ${{cls}}">${{icon}}</div>
      <div><div class="insight-text">${{escHtml(ins.text)}}</div><div class="insight-category">${{escHtml(ins.category)}}</div></div>
    </div>`;
  }}).join('');
}}

// ── Charts ──
let charts = {{}};

function destroyCharts() {{
  Object.values(charts).forEach(c => {{ if (c && c.destroy) c.destroy(); }});
  charts = {{}};
}}

function renderCharts(sessions) {{
  destroyCharts();
  const analyzed = sessions.filter(s => s.has_facets);

  // Outcomes horizontal bar (ordered by severity)
  const outcomes = {{}};
  analyzed.forEach(s => {{ outcomes[s.outcome] = (outcomes[s.outcome] || 0) + 1; }});
  const outcomeOrder = ['not_achieved','partially_achieved','mostly_achieved','fully_achieved'];
  const outcomeLabels = outcomeOrder.filter(o => outcomes[o]);
  const outcomeColors = {{
    'fully_achieved': '#22c55e', 'mostly_achieved': '#3b82f6',
    'partially_achieved': '#f59e0b', 'not_achieved': '#ef4444'
  }};
  charts.outcome = new Chart(document.getElementById('outcomeChart'), {{
    type: 'bar',
    data: {{
      labels: outcomeLabels.map(l => l.replace(/_/g,' ')),
      datasets: [{{ data: outcomeLabels.map(l => outcomes[l]),
        backgroundColor: outcomeLabels.map(l => outcomeColors[l] || '#94a3b8'),
        borderRadius: 4 }}]
    }},
    options: {{
      indexAxis: 'y', responsive: true,
      plugins: {{ legend: {{ display: false }} }},
      scales: {{
        x: {{ ticks: {{ color:'#94a3b8', stepSize:1 }}, grid: {{ color:'#2d3348' }} }},
        y: {{ ticks: {{ color:'#e2e8f0' }}, grid: {{ display:false }} }}
      }}
    }}
  }});

  // Satisfaction diverging bar
  const satAgg = {{}};
  analyzed.forEach(s => {{
    Object.entries(s.satisfaction || {{}}).forEach(([k,v]) => {{ satAgg[k] = (satAgg[k]||0) + v; }});
  }});
  const POSITIVE_SET = new Set(['satisfied','happy','very_satisfied','delighted','likely_satisfied']);
  const NEGATIVE_SET = new Set(['frustrated','dissatisfied','very_frustrated','unhappy']);
  const posLabels = Object.keys(satAgg).filter(k => POSITIVE_SET.has(k.toLowerCase())).sort();
  const negLabels = Object.keys(satAgg).filter(k => NEGATIVE_SET.has(k.toLowerCase())).sort();
  const allSatLabels = [...negLabels, ...posLabels];
  charts.satisfaction = new Chart(document.getElementById('satisfactionChart'), {{
    type: 'bar',
    data: {{
      labels: allSatLabels.map(l => l.replace(/_/g,' ')),
      datasets: [{{
        data: allSatLabels.map(l => NEGATIVE_SET.has(l.toLowerCase()) ? -satAgg[l] : satAgg[l]),
        backgroundColor: allSatLabels.map(l => NEGATIVE_SET.has(l.toLowerCase()) ? '#ef4444' : '#22c55e'),
      }}]
    }},
    options: {{
      indexAxis: 'y', responsive: true,
      plugins: {{ legend: {{ display: false }} }},
      scales: {{
        x: {{ ticks: {{ callback: v => Math.abs(v), color:'#94a3b8' }}, grid:{{ color:'#2d3348' }} }},
        y: {{ ticks: {{ color:'#e2e8f0' }}, grid:{{ display:false }} }}
      }}
    }}
  }});

  // Friction horizontal bar
  const frictionAgg = {{}};
  analyzed.forEach(s => {{
    Object.entries(s.friction || {{}}).forEach(([k,v]) => {{ frictionAgg[k] = (frictionAgg[k]||0) + v; }});
  }});
  const frictionSorted = Object.entries(frictionAgg).sort((a,b) => b[1]-a[1]);
  charts.friction = new Chart(document.getElementById('frictionChart'), {{
    type: 'bar',
    data: {{
      labels: frictionSorted.map(([k]) => k.replace(/_/g,' ')),
      datasets: [{{ data: frictionSorted.map(([,v]) => v),
        backgroundColor: '#f59e0b', borderRadius: 4 }}]
    }},
    options: {{
      indexAxis: 'y', responsive: true,
      plugins: {{ legend: {{ display: false }} }},
      scales: {{
        x: {{ ticks:{{ color:'#94a3b8' }}, grid:{{ color:'#2d3348' }} }},
        y: {{ ticks:{{ color:'#e2e8f0' }}, grid:{{ display:false }} }}
      }}
    }}
  }});

  // Goal categories donut
  const goalAgg = {{}};
  analyzed.forEach(s => {{
    Object.entries(s.goal_categories || {{}}).forEach(([k,v]) => {{ goalAgg[k] = (goalAgg[k]||0) + v; }});
  }});
  const goalLabels = Object.keys(goalAgg).sort((a,b) => goalAgg[b] - goalAgg[a]);
  const goalColors = ['#6366f1','#3b82f6','#06b6d4','#a855f7','#ec4899','#22c55e','#f59e0b','#ef4444'];
  charts.goals = new Chart(document.getElementById('goalChart'), {{
    type: 'doughnut',
    data: {{
      labels: goalLabels.map(l => l.replace(/_/g,' ')),
      datasets: [{{ data: goalLabels.map(l => goalAgg[l]),
        backgroundColor: goalLabels.map((_,i) => goalColors[i % goalColors.length]) }}]
    }},
    options: {{ responsive:true, plugins:{{ legend:{{ position:'bottom', labels:{{ color:'#e2e8f0' }} }} }} }}
  }});

  // Outcomes over time (stacked bar)
  renderOutcomeTrend(sessions);

  // Sessions + friction over time
  renderSessionTrend(sessions);

  // Activity heatmap
  renderHeatmap(sessions);
}}

function renderOutcomeTrend(sessions) {{
  const byDate = {{}};
  sessions.filter(s => s.has_facets && s.start_time).forEach(s => {{
    const d = s.start_time.slice(0,10);
    if (!byDate[d]) byDate[d] = {{ fully_achieved:0, partially_achieved:0, not_achieved:0 }};
    const o = s.outcome || 'unknown';
    if (byDate[d][o] !== undefined) byDate[d][o]++;
  }});
  const dates = Object.keys(byDate).sort();
  // 7-day rolling window
  const rolling = dates.map((d, i) => {{
    const window = dates.slice(Math.max(0, i - 6), i + 1);
    return {{
      fully: window.reduce((s, wd) => s + byDate[wd].fully_achieved, 0),
      partial: window.reduce((s, wd) => s + byDate[wd].partially_achieved, 0),
      not: window.reduce((s, wd) => s + byDate[wd].not_achieved, 0),
    }};
  }});
  charts.outcomeTrend = new Chart(document.getElementById('outcomeTrendChart'), {{
    type: 'bar',
    data: {{
      labels: dates,
      datasets: [
        {{ label:'Fully Achieved (7d)', data:rolling.map(r=>r.fully), backgroundColor:'#22c55e', stack:'s' }},
        {{ label:'Partially (7d)', data:rolling.map(r=>r.partial), backgroundColor:'#f59e0b', stack:'s' }},
        {{ label:'Not Achieved (7d)', data:rolling.map(r=>r.not), backgroundColor:'#ef4444', stack:'s' }},
      ]
    }},
    options: {{
      responsive:true, scales: {{
        x:{{ stacked:true, ticks:{{ color:'#94a3b8' }}, grid:{{ color:'#2d3348' }} }},
        y:{{ stacked:true, ticks:{{ color:'#94a3b8', stepSize:1 }}, grid:{{ color:'#2d3348' }} }}
      }},
      plugins:{{ legend:{{ labels:{{ color:'#e2e8f0' }} }} }}
    }}
  }});
}}

function renderSessionTrend(sessions) {{
  const byDate = {{}};
  sessions.filter(s => s.start_time).forEach(s => {{
    const d = s.start_time.slice(0,10);
    if (!byDate[d]) byDate[d] = {{ sessions:0, friction:0, errors:0 }};
    byDate[d].sessions++;
    Object.values(s.friction || {{}}).forEach(v => byDate[d].friction += v);
    byDate[d].errors += s.tool_errors || 0;
  }});
  const dates = Object.keys(byDate).sort();
  charts.sessionTrend = new Chart(document.getElementById('sessionTrendChart'), {{
    type: 'line',
    data: {{
      labels: dates,
      datasets: [
        {{ label:'Sessions', data:dates.map(d=>byDate[d].sessions), borderColor:'#3b82f6', backgroundColor:'rgba(59,130,246,0.1)', fill:true, tension:0.3 }},
        {{ label:'Friction', data:dates.map(d=>byDate[d].friction), borderColor:'#f59e0b', backgroundColor:'rgba(245,158,11,0.1)', fill:true, tension:0.3 }},
        {{ label:'Tool Errors', data:dates.map(d=>byDate[d].errors), borderColor:'#ef4444', backgroundColor:'rgba(239,68,68,0.1)', fill:true, tension:0.3 }},
      ]
    }},
    options: {{
      responsive:true,
      scales: {{
        x:{{ ticks:{{ color:'#94a3b8' }}, grid:{{ color:'#2d3348' }} }},
        y:{{ ticks:{{ color:'#94a3b8' }}, grid:{{ color:'#2d3348' }} }}
      }},
      plugins:{{ legend:{{ labels:{{ color:'#e2e8f0' }} }} }}
    }}
  }});
}}

function renderHeatmap(sessions) {{
  const container = document.getElementById('heatmapChart');
  container.innerHTML = '';
  const dataPoints = {{}};
  sessions.forEach(s => {{
    if (!s.start_time) return;
    const d = s.start_time.slice(0,10);
    const ts = new Date(d).getTime() / 1000;
    dataPoints[ts] = (dataPoints[ts] || 0) + 1;
  }});
  if (Object.keys(dataPoints).length === 0) {{
    container.innerHTML = '<div style="color:var(--text2);text-align:center;padding:40px;">No activity data</div>';
    return;
  }}
  try {{
    new frappe.Chart(container, {{
      type: 'heatmap',
      data: {{ dataPoints, start: new Date(Math.min(...Object.keys(dataPoints).map(Number)) * 1000), end: new Date() }},
      countLabel: 'sessions',
      discreteDomains: 1,
      colors: ['#1a1d27', '#3b3086', '#5b46c4', '#7c5ce7', '#a855f7'],
    }});
  }} catch(e) {{
    container.innerHTML = '<div style="color:var(--text2);text-align:center;padding:40px;">Heatmap requires online CDN access</div>';
  }}
}}

// ── Table ──
function renderTable(sessions) {{
  const tbody = document.getElementById('sessionTableBody');
  // Sort
  const sorted = [...sessions].sort((a,b) => {{
    let va = a[sortCol], vb = b[sortCol];
    if (typeof va === 'number') return sortDir === 'asc' ? va - vb : vb - va;
    va = (va || '').toString(); vb = (vb || '').toString();
    return sortDir === 'asc' ? va.localeCompare(vb) : vb.localeCompare(va);
  }});

  // Paginate
  const totalPages = Math.ceil(sorted.length / PAGE_SIZE) || 1;
  if (currentPage > totalPages) currentPage = totalPages;
  const start = (currentPage - 1) * PAGE_SIZE;
  const page = sorted.slice(start, start + PAGE_SIZE);

  tbody.innerHTML = page.map(s => {{
    const date = s.start_time ? new Date(s.start_time).toLocaleDateString() : '—';
    const outcomeClass = escHtml(s.outcome || '');
    const outcomeText = s.has_facets ? escHtml((s.outcome || '').replace(/_/g,' ')) : '—';
    const prompt = escHtml((s.first_prompt || '').slice(0, 80));
    const fullSid = s.session_id || '';
    const shortSid = fullSid ? escHtml(fullSid.slice(0, 8)) : '—';
    return `<tr>
      <td>${{date}}</td>
      <td>${{escHtml(s.canonical_project)}}</td>
      <td><span class="outcome-badge ${{outcomeClass}}">${{outcomeText}}</span></td>
      <td class="num">${{s.duration_minutes}}m</td>
      <td class="num">${{s.user_message_count}}</td>
      <td class="num">${{s.tool_errors}}</td>
      <td class="num">${{s.lines_added}}</td>
      <td title="${{escHtml(fullSid)}}"><code>${{shortSid}}</code></td>
      <td title="${{prompt}}">${{prompt}}${{(s.first_prompt || '').length >= 80 ? '...' : ''}}</td>
    </tr>`;
  }}).join('');

  // Pagination
  const pag = document.getElementById('pagination');
  pag.innerHTML = `
    <button onclick="changePage(-1)" ${{currentPage<=1?'disabled':''}}>Prev</button>
    <span class="info">Page ${{currentPage}} of ${{totalPages}} (${{sorted.length}} sessions)</span>
    <button onclick="changePage(1)" ${{currentPage>=totalPages?'disabled':''}}>Next</button>
  `;
}}

function changePage(delta) {{
  currentPage += delta;
  applyFilters();
}}

// ── Event Listeners ──
function setupEventListeners() {{
  // Time filter buttons
  document.querySelectorAll('.time-filter button').forEach(btn => {{
    btn.addEventListener('click', () => {{
      activeRange = parseInt(btn.dataset.range);
      document.querySelectorAll('.time-filter button').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      currentPage = 1;
      applyFilters();
    }});
  }});

  // Project dropdown
  document.getElementById('projectSelect').addEventListener('change', (e) => {{
    selectedProjects.clear();
    Array.from(e.target.selectedOptions).forEach(opt => {{
      if (opt.value) selectedProjects.add(opt.value);
    }});
    currentPage = 1;
    applyFilters();
  }});

  // Table sort
  document.querySelectorAll('.data-table th[data-sort]').forEach(th => {{
    th.addEventListener('click', () => {{
      const col = th.dataset.sort;
      if (sortCol === col) {{ sortDir = sortDir === 'asc' ? 'desc' : 'asc'; }}
      else {{ sortCol = col; sortDir = 'desc'; }}
      document.querySelectorAll('.data-table th').forEach(h => h.classList.remove('sort-asc','sort-desc'));
      th.classList.add(sortDir === 'asc' ? 'sort-asc' : 'sort-desc');
      currentPage = 1;
      applyFilters();
    }});
  }});
}}

// ── Narrative Sections ──
function renderNarratives() {{
  const n = DATA.narratives || {{}};

  // At a Glance
  if (n.at_a_glance) {{
    const g = n.at_a_glance;
    const el = document.getElementById('narrativeGlance');
    el.style.display = 'block';
    el.innerHTML = `
      <div class="at-a-glance">
        <div class="collapsible-header" onclick="this.classList.toggle('open');this.nextElementSibling.classList.toggle('open');">
          <span class="collapsible-arrow">&#9654;</span>
          <div class="glance-title" style="margin:0">At a Glance</div>
        </div>
        <div class="collapsible-content">
          <div class="glance-sections">
            <div class="glance-section"><strong>What's working:</strong> ${{escHtml(g.whats_working)}}</div>
            <div class="glance-section"><strong>What's hindering:</strong> ${{escHtml(g.whats_hindering)}}</div>
            <div class="glance-section"><strong>Quick wins:</strong> ${{escHtml(g.quick_wins)}}</div>
            <div class="glance-section"><strong>Ambitious workflows:</strong> ${{escHtml(g.ambitious)}}</div>
          </div>
          <div class="narrative-disclaimer">AI-generated narrative from full dataset. Filtered views affect charts and KPIs only.</div>
        </div>
      </div>`;
  }}

  // What You Work On
  if (n.what_you_work_on) {{
    const w = n.what_you_work_on;
    const el = document.getElementById('narrativeWorkOn');
    el.style.display = 'block';
    const cards = (w.projects || []).map(p => `
      <div class="work-on-card">
        <div class="work-on-title">${{escHtml(p.name)}}</div>
        <div class="work-on-count">${{escHtml(p.session_count)}}</div>
        <div class="work-on-desc">${{escHtml(p.description)}}</div>
      </div>`).join('');
    el.innerHTML = `
      <div class="section-divider">
        <div class="collapsible-header" onclick="this.classList.toggle('open');this.nextElementSibling.classList.toggle('open');">
          <span class="collapsible-arrow">&#9654;</span>
          <h2>What You Work On</h2>
        </div>
        <div class="collapsible-content">
          <div class="subtitle" style="margin-bottom:12px;">AI-generated project breakdown from session data</div>
          <p style="font-size:13px;color:var(--text2);margin-bottom:16px;">${{escHtml(w.intro || '')}}</p>
          <div class="work-on-section">${{cards}}</div>
          <div class="narrative-disclaimer">Project clusters inferred from ${{DATA.data_coverage.facets_count}} analyzed sessions.</div>
        </div>
      </div>`;
  }}

  // Impressive Things You Did
  if (n.impressive_things) {{
    const imp = n.impressive_things;
    const el = document.getElementById('narrativeImpressive');
    el.style.display = 'block';
    const achCards = (imp.achievements || []).map(a => `
      <div class="impressive-card">
        <div class="impressive-title">${{escHtml(a.title)}}</div>
        <div class="impressive-desc">${{escHtml(a.description)}}</div>
      </div>`).join('');
    const helpedItems = (imp.what_helped_most || []).map(h => `
      <div class="helped-item">${{escHtml(h.capability)}}<span class="count">${{h.count}}</span></div>`).join('');
    el.innerHTML = `
      <div class="section-divider">
        <div class="collapsible-header" onclick="this.classList.toggle('open');this.nextElementSibling.classList.toggle('open');">
          <span class="collapsible-arrow">&#9654;</span>
          <h2>Impressive Things You Did</h2>
        </div>
        <div class="collapsible-content">
          <div class="subtitle" style="margin-bottom:12px;">AI-identified achievements from your session data</div>
          <p style="font-size:13px;color:var(--text2);margin-bottom:16px;">${{escHtml(imp.intro || '')}}</p>
          <div class="impressive-section">${{achCards}}</div>
          ${{helpedItems ? '<h3 style="font-size:14px;margin-bottom:10px;color:var(--text2);">What Helped Most</h3><div class="helped-most">' + helpedItems + '</div>' : ''}}
          <div class="narrative-disclaimer">Achievements identified from ${{DATA.data_coverage.facets_count}} analyzed sessions.</div>
        </div>
      </div>`;
  }}

  // Where Things Go Wrong
  if (n.friction_analysis) {{
    const f = n.friction_analysis;
    const el = document.getElementById('narrativeFriction');
    el.style.display = 'block';
    const cats = (f.categories || []).map(c => `
      <div class="friction-category">
        <div class="friction-cat-title">${{escHtml(c.title)}}</div>
        <div class="friction-cat-desc">${{escHtml(c.description)}}</div>
        <ul class="friction-cat-examples">${{(c.examples || []).map(e => `<li>${{escHtml(e)}}</li>`).join('')}}</ul>
      </div>`).join('');
    el.innerHTML = `
      <div class="section-divider">
        <div class="collapsible-header" onclick="this.classList.toggle('open');this.nextElementSibling.classList.toggle('open');">
          <span class="collapsible-arrow">&#9654;</span>
          <h2>Where Things Go Wrong</h2>
        </div>
        <div class="collapsible-content">
          <div class="subtitle" style="margin-bottom:12px;">AI-generated root cause analysis from qualitative session data</div>
          <p style="font-size:13px;color:var(--text2);margin-bottom:16px;">${{escHtml(f.intro || '')}}</p>
          <div class="friction-categories">${{cats}}</div>
          <div class="narrative-disclaimer">Narrative generated from ${{DATA.data_coverage.facets_count}} analyzed sessions. Sample size is limited.</div>
        </div>
      </div>`;
  }}

  // Features to Try
  if (n.features_to_try) {{
    const ft = n.features_to_try;
    const el = document.getElementById('narrativeFeatures');
    el.style.display = 'block';
    const cards = (ft.features || []).map(f => `
      <div class="feature-card">
        <div class="feature-name">${{escHtml(f.name)}}</div>
        <div class="feature-why">${{escHtml(f.why_for_you)}}</div>
        <div class="feature-config">
          <code>${{escHtml(f.example_config)}}</code>
          <button class="copy-btn" onclick="copyNarrative(this)">Copy</button>
        </div>
      </div>`).join('');
    el.innerHTML = `
      <div class="section-divider">
        <div class="collapsible-header" onclick="this.classList.toggle('open');this.nextElementSibling.classList.toggle('open');">
          <span class="collapsible-arrow">&#9654;</span>
          <h2>Features to Try</h2>
        </div>
        <div class="collapsible-content">
          <div class="subtitle" style="margin-bottom:12px;">Existing Claude Code features recommended for your workflow</div>
          <p style="font-size:13px;color:var(--text2);margin-bottom:16px;">${{escHtml(ft.intro || '')}}</p>
          <div class="features-section">${{cards}}</div>
          <div class="narrative-disclaimer">Recommendations based on friction patterns from ${{DATA.data_coverage.facets_count}} analyzed sessions.</div>
        </div>
      </div>`;
  }}

  // New Usage Patterns
  if (n.new_usage_patterns) {{
    const up = n.new_usage_patterns;
    const el = document.getElementById('narrativePatterns');
    el.style.display = 'block';
    const cards = (up.patterns || []).map(p => `
      <div class="pattern-card">
        <div class="pattern-title">${{escHtml(p.title)}}</div>
        <div class="pattern-desc">${{escHtml(p.description)}}</div>
        <div class="pattern-prompt">
          <code>${{escHtml(p.copyable_prompt)}}</code>
          <button class="copy-btn" onclick="copyNarrative(this)">Copy</button>
        </div>
      </div>`).join('');
    el.innerHTML = `
      <div class="section-divider">
        <div class="collapsible-header" onclick="this.classList.toggle('open');this.nextElementSibling.classList.toggle('open');">
          <span class="collapsible-arrow">&#9654;</span>
          <h2>New Ways to Use Claude Code</h2>
        </div>
        <div class="collapsible-content">
          <div class="subtitle" style="margin-bottom:12px;">Actionable workflow patterns based on your usage data</div>
          <p style="font-size:13px;color:var(--text2);margin-bottom:16px;">${{escHtml(up.intro || '')}}</p>
          <div class="patterns-section">${{cards}}</div>
          <div class="narrative-disclaimer">Patterns derived from ${{DATA.data_coverage.facets_count}} analyzed sessions.</div>
        </div>
      </div>`;
  }}

  // On the Horizon
  if (n.on_the_horizon) {{
    const h = n.on_the_horizon;
    const el = document.getElementById('narrativeHorizon');
    el.style.display = 'block';
    const cards = (h.opportunities || []).map(o => `
      <div class="horizon-card">
        <div class="horizon-title">${{escHtml(o.title)}}</div>
        <div class="horizon-possible">${{escHtml(o.whats_possible)}}</div>
        <div class="horizon-tip"><strong>Getting started:</strong> ${{escHtml(o.how_to_try)}}</div>
        <div class="horizon-prompt">
          <code>${{escHtml(o.copyable_prompt)}}</code>
          <button class="copy-btn" onclick="copyNarrative(this)">Copy</button>
        </div>
      </div>`).join('');
    el.innerHTML = `
      <div class="section-divider">
        <div class="collapsible-header" onclick="this.classList.toggle('open');this.nextElementSibling.classList.toggle('open');">
          <span class="collapsible-arrow">&#9654;</span>
          <h2>On the Horizon</h2>
        </div>
        <div class="collapsible-content">
          <div class="subtitle" style="margin-bottom:12px;">AI-generated workflow recommendations based on your friction patterns</div>
          <p style="font-size:13px;color:var(--text2);margin-bottom:16px;">${{escHtml(h.intro || '')}}</p>
          <div class="horizon-section">${{cards}}</div>
          <div class="narrative-disclaimer">Recommendations derived from ${{DATA.data_coverage.facets_count}} analyzed sessions.</div>
        </div>
      </div>`;
  }}

  // Behavioral Profile
  if (n.behavioral_profile) {{
    const b = n.behavioral_profile;
    const el = document.getElementById('narrativeProfile');
    el.style.display = 'block';
    const paragraphs = escHtml(b.narrative).split('\\n\\n').filter(p => p.trim()).map(p => `<p>${{p}}</p>`).join('');
    el.innerHTML = `
      <div class="section-divider">
        <div class="collapsible-header" onclick="this.classList.toggle('open');this.nextElementSibling.classList.toggle('open');">
          <span class="collapsible-arrow">&#9654;</span>
          <h3>How You Use Claude Code</h3>
        </div>
        <div class="collapsible-content">
          <div class="narrative-box">
            ${{paragraphs}}
            <div class="key-pattern"><strong>Key pattern:</strong> ${{escHtml(b.key_pattern)}}</div>
          </div>
          <div class="narrative-disclaimer">AI-generated behavioral profile from ${{DATA.data_coverage.facets_count}} analyzed sessions.</div>
        </div>
      </div>`;
  }}
}}

function escHtml(s) {{
  if (!s) return '';
  return s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;');
}}

function copyNarrative(btn) {{
  const code = btn.previousElementSibling;
  navigator.clipboard.writeText(code.textContent).then(() => {{
    btn.textContent = 'Copied!';
    setTimeout(() => {{ btn.textContent = 'Copy'; }}, 2000);
  }});
}}

// ── Coverage Banner ──
function renderCoverageBanner() {{
  const dc = DATA.data_coverage;
  const banner = document.getElementById('coverageBanner');
  if (!dc.has_stats_cache) {{
    banner.innerHTML = `
      <h3>Data Coverage</h3>
      <div class="coverage-note">
        <strong>Limited data:</strong> Only session-meta files available (${{dc.session_meta_start}} to ${{dc.session_meta_end}}).
        Qualitative analysis (satisfaction, friction, outcomes) covers ${{dc.facets_count}} of ${{dc.session_meta_count}} sessions.
      </div>`;
    return;
  }}

  // Calculate timeline proportions
  const cacheStart = new Date(dc.stats_cache_start);
  const metaStart = new Date(dc.session_meta_start);
  const metaEnd = new Date(dc.session_meta_end);
  const totalSpan = metaEnd - cacheStart;
  const cacheOnlyPct = Math.max(0, (metaStart - cacheStart) / totalSpan * 100);
  const metaPct = Math.max(0, (metaEnd - metaStart) / totalSpan * 100);

  banner.innerHTML = `
    <h3>Data Coverage</h3>
    <div class="coverage-bar">
      <div class="label">${{dc.stats_cache_start}}</div>
      <div class="bar-track" style="overflow:visible;">
        <div class="bar-segment" style="left:0;width:${{cacheOnlyPct}}%;background:var(--blue);opacity:0.4;border-radius:4px 0 0 4px;"></div>
        <div class="bar-segment" style="left:${{cacheOnlyPct}}%;width:${{metaPct}}%;background:var(--blue);border-radius:0 4px 4px 0;"></div>
      </div>
      <div class="label" style="text-align:right">${{dc.session_meta_end}}</div>
    </div>
    <div class="coverage-legend">
      <div class="item"><div class="dot" style="background:var(--blue);opacity:0.4;"></div>Aggregate only (stats-cache) — ${{dc.stats_cache_total_sessions.toLocaleString()}} sessions, ${{dc.stats_cache_total_messages.toLocaleString()}} messages</div>
      <div class="item"><div class="dot" style="background:var(--blue);"></div>Per-session detail (session-meta) — ${{dc.session_meta_count}} sessions</div>
      <div class="item"><div class="dot" style="background:var(--green);"></div>Qualitative analysis (facets) — ${{dc.facets_count}} sessions</div>
    </div>
    <div class="coverage-note">
      <strong>What this means:</strong> Charts in the "Qualitative Analysis" sections above reflect only the ${{dc.facets_count}} sessions with facets data.
      The "Historical Trends" section below uses aggregate stats-cache data covering your full history since ${{dc.stats_cache_start}}.
      Filters (date/project) apply only to per-session detail — historical trend charts always show the full range.
    </div>`;
}}

// ── Historical Charts ──
function renderHistoricalCharts() {{
  const sc = DATA.stats_cache;
  if (!sc || !sc.daily_activity || sc.daily_activity.length === 0) return;

  // Show the section
  document.getElementById('historicalSection').style.display = 'block';
  document.getElementById('historicalCharts').style.display = 'block';

  const da = sc.daily_activity.sort((a,b) => a.date.localeCompare(b.date));
  const dates = da.map(d => d.date);

  // Daily Activity chart — sessions, messages (scaled), tool calls (scaled)
  const maxMsg = Math.max(...da.map(d => d.messageCount));
  const maxSess = Math.max(...da.map(d => d.sessionCount));
  charts.historyActivity = new Chart(document.getElementById('historyActivityChart'), {{
    type: 'bar',
    data: {{
      labels: dates,
      datasets: [
        {{ label: 'Sessions', data: da.map(d => d.sessionCount), backgroundColor: 'rgba(59,130,246,0.7)', yAxisID: 'y', order: 2 }},
        {{ label: 'Messages', data: da.map(d => d.messageCount), borderColor: '#22c55e', backgroundColor: 'rgba(34,197,94,0.1)', type: 'line', fill: true, tension: 0.3, yAxisID: 'y1', order: 1 }},
      ]
    }},
    options: {{
      responsive: true,
      interaction: {{ mode: 'index', intersect: false }},
      scales: {{
        x: {{ ticks: {{ color: '#94a3b8', maxTicksLimit: 20 }}, grid: {{ color: '#2d3348' }} }},
        y: {{ position: 'left', title: {{ display: true, text: 'Sessions', color: '#94a3b8' }}, ticks: {{ color: '#94a3b8' }}, grid: {{ color: '#2d3348' }} }},
        y1: {{ position: 'right', title: {{ display: true, text: 'Messages', color: '#94a3b8' }}, ticks: {{ color: '#94a3b8' }}, grid: {{ display: false }} }},
      }},
      plugins: {{ legend: {{ labels: {{ color: '#e2e8f0' }} }} }}
    }}
  }});

  // Daily tokens by model (stacked area)
  const dmt = (sc.daily_model_tokens || []).sort((a,b) => a.date.localeCompare(b.date));
  if (dmt.length > 0) {{
    const allModels = new Set();
    dmt.forEach(d => Object.keys(d.tokensByModel || {{}}).forEach(m => allModels.add(m)));
    const modelColors = {{
      'claude-opus-4-6': '#a855f7',
      'claude-opus-4-5-20251101': '#c084fc',
      'claude-sonnet-4-6': '#3b82f6',
      'claude-sonnet-4-5-20250929': '#60a5fa',
      'claude-haiku-4-5-20251001': '#22c55e',
    }};
    const defaultColors = ['#f59e0b', '#ec4899', '#06b6d4', '#ef4444'];
    let colorIdx = 0;
    const modelList = [...allModels].sort();
    const tokenDates = dmt.map(d => d.date);

    charts.historyTokens = new Chart(document.getElementById('historyTokenChart'), {{
      type: 'bar',
      data: {{
        labels: tokenDates,
        datasets: modelList.map(model => {{
          const color = modelColors[model] || defaultColors[colorIdx++ % defaultColors.length];
          const shortName = model.replace('claude-','').replace(/-\\d{{8}}$/, '');
          return {{
            label: shortName,
            data: dmt.map(d => ((d.tokensByModel || {{}})[model] || 0)),
            backgroundColor: color + '99',
            stack: 'tokens',
          }};
        }})
      }},
      options: {{
        responsive: true,
        scales: {{
          x: {{ stacked: true, ticks: {{ color: '#94a3b8', maxTicksLimit: 20 }}, grid: {{ color: '#2d3348' }} }},
          y: {{ stacked: true, ticks: {{ color: '#94a3b8', callback: v => (v/1000).toFixed(0)+'k' }}, grid: {{ color: '#2d3348' }} }},
        }},
        plugins: {{ legend: {{ labels: {{ color: '#e2e8f0' }} }} }}
      }}
    }});
  }}

  // Model usage pie
  const mu = sc.model_usage || {{}};
  const modelNames = Object.keys(mu);
  if (modelNames.length > 0) {{
    const muColors = {{
      'claude-opus-4-6': '#a855f7',
      'claude-opus-4-5-20251101': '#c084fc',
      'claude-sonnet-4-6': '#3b82f6',
      'claude-sonnet-4-5-20250929': '#60a5fa',
      'claude-haiku-4-5-20251001': '#22c55e',
    }};
    const muDefault = ['#f59e0b','#ec4899','#06b6d4','#ef4444'];
    let muIdx = 0;
    charts.modelUsage = new Chart(document.getElementById('modelUsageChart'), {{
      type: 'doughnut',
      data: {{
        labels: modelNames.map(m => m.replace('claude-','').replace(/-\\d{{8}}$/, '')),
        datasets: [{{
          data: modelNames.map(m => (mu[m].inputTokens || 0) + (mu[m].outputTokens || 0)),
          backgroundColor: modelNames.map(m => muColors[m] || muDefault[muIdx++ % muDefault.length]),
        }}]
      }},
      options: {{
        responsive: true,
        plugins: {{
          legend: {{ position: 'bottom', labels: {{ color: '#e2e8f0' }} }},
          tooltip: {{ callbacks: {{ label: ctx => {{
            const v = ctx.raw;
            return ctx.label + ': ' + (v > 1e9 ? (v/1e9).toFixed(1)+'B' : v > 1e6 ? (v/1e6).toFixed(1)+'M' : (v/1e3).toFixed(0)+'K') + ' tokens';
          }} }} }}
        }}
      }}
    }});
  }}
}}

function renderFrameworkStats() {{
  // Reads payload.framework_stats and populates the #frameworkStats section.
  // No-op when framework_stats is null (no fw projects discovered or --no-fw-stats).
  const fs = DATA.framework_stats;
  if (!fs) return;
  const section = document.getElementById('frameworkStats');
  if (!section) return;

  const agg = fs.aggregate || {{}};
  const projects = fs.projects || [];
  const safety = agg.safety || {{}};
  const cost = agg.cost_routing || {{}};
  const conf = agg.conformance || {{}};
  const sess = agg.sessions || {{}};
  const proto = agg.protocol || {{}};

  const fmtMoney = v => '$' + (Number(v) || 0).toFixed(2);
  const fmtScore = v => (Number(v) || 0).toFixed(2);
  const fmtNum = v => Number(v) || 0;

  let html = '<div class="section-divider"><h2>Framework Stats</h2>';
  html += '<div class="subtitle">Cross-project metrics aggregated from <code>.context/metrics/</code> across ';
  html += fmtNum(agg.project_count) + ' framework project(s), ' + fmtNum(agg.worktree_count) + ' worktree(s)</div></div>';

  html += '<div class="kpi-grid">';
  html += '<div class="kpi-card"><div class="label">Safety Blocks</div><div class="value" style="color:var(--red)">' + fmtNum(safety.total_blocks) + '</div><div class="sub">' + fmtNum(safety.total_approvals) + ' auto-approved</div></div>';
  html += '<div class="kpi-card"><div class="label">Cost Routes</div><div class="value" style="color:var(--blue)">' + fmtNum(cost.total_routes) + '</div><div class="sub">' + fmtNum(cost.skipped_agents_total) + ' agents skipped</div></div>';
  html += '<div class="kpi-card"><div class="label">Est. Saved</div><div class="value" style="color:var(--green)">' + fmtMoney(cost.total_est_savings) + '</div><div class="sub">via cost routing</div></div>';
  html += '<div class="kpi-card"><div class="label">Conformance</div><div class="value" style="color:var(--purple)">' + fmtScore(conf.avg_composite) + '</div><div class="sub">' + fmtNum(conf.count) + ' scorecard(s)</div></div>';
  html += '<div class="kpi-card"><div class="label">Protocol</div><div class="value" style="color:var(--orange)">' + fmtNum(proto.total_warnings) + '</div><div class="sub">' + fmtNum(proto.total_blocks) + ' blocked</div></div>';
  html += '<div class="kpi-card"><div class="label">Sessions</div><div class="value" style="color:var(--cyan)">' + fmtNum(sess.session_count) + '</div><div class="sub">' + (sess.avg_duration_min || 0).toFixed(0) + ' min avg</div></div>';
  html += '</div>';

  html += '<div class="chart-box" style="margin-top:16px;"><h3>Per-Project Comparison</h3>';
  html += '<p class="disclaimer" style="font-size:0.85em;color:var(--muted);margin-bottom:12px;">';
  html += 'Measurement only \u2014 do not gate merges or deployments on this aggregate. ';
  html += 'Click a project to drill into its conformance detail.</p>';
  html += '<table class="data-table"><thead><tr>';
  html += '<th>Project</th><th class="num">Worktrees</th><th class="num">Blocks</th><th class="num">Approvals</th>';
  html += '<th class="num">Routes</th><th class="num">Saved</th><th class="num">Conformance</th><th class="num">Sessions</th><th>Detail</th>';
  html += '</tr></thead><tbody>';
  for (const p of projects) {{
    const ps = p.safety || {{}}, pc = p.cost_routing || {{}}, pcf = p.conformance || {{}}, pss = p.sessions || {{}};
    html += '<tr>';
    html += '<td>' + escHtml(p.name || '') + '</td>';
    html += '<td class="num">' + fmtNum(p.worktree_count) + '</td>';
    html += '<td class="num">' + fmtNum(ps.total_blocks) + '</td>';
    html += '<td class="num">' + fmtNum(ps.total_approvals) + '</td>';
    html += '<td class="num">' + fmtNum(pc.total_routes) + '</td>';
    html += '<td class="num">' + fmtMoney(pc.total_est_savings) + '</td>';
    html += '<td class="num">' + fmtScore(pcf.avg_composite) + '</td>';
    html += '<td class="num">' + fmtNum(pss.session_count) + '</td>';
    // AC-6 drill-down: native <details> per project, no JS state required.
    // Explicit `|| 0` coerces undefined (pre-v2 framework_stats payloads) to 0.
    const legacy = fmtNum(pcf.legacy_count || 0);
    const avgComponents = pcf.avg_components || {{}};
    let drilldown = '<ul style="margin:4px 0;padding-left:16px;">';
    drilldown += '<li>Worktrees: ' + fmtNum(p.worktree_count) + '</li>';
    drilldown += '<li>Scorecards (v2): ' + fmtNum(pcf.count) + '</li>';
    if (legacy > 0) {{
      drilldown += '<li style="color:var(--orange)">Legacy scorecards (need re-score): ' + legacy + '</li>';
    }}
    for (const [k, v] of Object.entries(avgComponents)) {{
      drilldown += '<li>' + escHtml(k) + ': ' + fmtScore(v) + '</li>';
    }}
    drilldown += '</ul>';
    html += '<td><details><summary>expand</summary><div>' + drilldown + '</div></details></td>';
    html += '</tr>';
  }}
  html += '</tbody></table></div>';

  // AC-5 visibility: surface projects discovered but skipped during parse,
  // so silent drops do not hide from operators.
  const skipped = fs.skipped || [];
  if (skipped.length > 0) {{
    html += '<div class="chart-box" style="margin-top:16px;">';
    html += '<h3 style="color:var(--orange)">\u26A0 Skipped Projects (' + skipped.length + ')</h3>';
    html += '<p class="disclaimer" style="font-size:0.85em;color:var(--muted);margin-bottom:12px;">';
    html += 'Projects with a <code>config/framework.yaml</code> that failed to parse. ';
    html += 'Dashboard excludes them from aggregates until the YAML is fixed.</p>';
    html += '<ul style="margin:0;padding-left:20px;">';
    for (const entry of skipped) {{
      const shortPath = escHtml((entry.path || '').split('/').slice(-2).join('/'));
      const reason = escHtml(entry.reason || 'unknown');
      html += '<li><code>' + shortPath + '</code> — ' + reason + '</li>';
    }}
    html += '</ul></div>';
  }}

  section.innerHTML = html;
  section.style.display = 'block';
}}

init();
</script>
</body>
</html>'''


def main():
    """Main entry point — run the full pipeline."""
    import argparse
    parser = argparse.ArgumentParser(description="Claude Code Insights Dashboard Generator")
    parser.add_argument('--narrative', action='store_true',
                        help='Generate AI-powered narrative sections (requires claude CLI)')
    parser.add_argument('--no-cache', action='store_true',
                        help='Skip narrative cache, force regeneration')
    parser.add_argument('--quiet', action='store_true',
                        help='Suppress progress output')
    parser.add_argument('--refresh-fw-projects', action='store_true',
                        help='Force a fresh filesystem scan for framework projects')
    parser.add_argument('--no-fw-stats', action='store_true',
                        help='Skip framework metrics aggregation entirely')
    args = parser.parse_args()

    def log(msg):
        if not args.quiet:
            print(msg)

    log("Claude Code Insights Dashboard Generator")
    log("=" * 50)

    # Phase 1: Load
    log("\n[1/7] Loading session-meta...")
    metas, meta_errors = load_session_metas(META_DIR)
    log(f"  Loaded {len(metas)} sessions ({meta_errors} parse errors)")

    # Freshness check: loud warning if the upstream extractor stopped writing.
    freshness = check_session_meta_freshness(META_DIR)
    if freshness["stale"]:
        if freshness["age_hours"] is None:
            log(f"  \u26A0  session-meta dir empty or missing — dashboard will have no per-session detail")
        else:
            log(f"  \u26A0  session-meta is {freshness['age_hours']:.1f}h old "
                f"(threshold {freshness['threshold_hours']:.0f}h) — "
                "upstream extractor may have stopped")
    else:
        log(f"  session-meta freshness: {freshness['age_hours']:.1f}h old "
            f"({freshness['file_count']} files)")

    log("[1/7] Loading facets...")
    facets, facet_errors = load_facets(FACETS_DIR)
    log(f"  Loaded {len(facets)} facets ({facet_errors} parse errors)")

    log("[1/7] Loading stats-cache...")
    stats_cache = load_stats_cache(STATS_CACHE)
    if stats_cache:
        da = stats_cache['daily_activity']
        cache_dates = sorted(d['date'] for d in da if d.get('date'))
        log(f"  Stats-cache: {stats_cache['total_sessions']} total sessions, "
            f"{stats_cache['total_messages']} messages")
        log(f"  Date range: {cache_dates[0] if cache_dates else 'N/A'} to "
            f"{cache_dates[-1] if cache_dates else 'N/A'} ({len(da)} days)")
    else:
        log("  Stats-cache not found — historical trends will be limited")

    # Phase 1.5: Framework Stats (cross-project)
    framework_stats = None
    fw_skipped: list[dict] = []
    if not args.no_fw_stats:
        log("\n[1/7] Discovering framework projects...")
        # Auto-refresh when cache is missing, older than the max-age threshold,
        # or the user explicitly asked for a rescan.
        cache_age = fw_projects_cache_age_days()
        stale_cache = (
            cache_age is None or cache_age > FW_PROJECTS_CACHE_MAX_AGE_DAYS
        )
        if args.refresh_fw_projects or stale_cache:
            discovery = discover_fw_projects_with_skipped()
            fw_paths = discovery["found"]
            fw_skipped = discovery["skipped"]
            save_fw_projects_cache(fw_paths)
            reason = (
                "explicit --refresh-fw-projects"
                if args.refresh_fw_projects
                else (
                    f"cache missing" if cache_age is None
                    else f"cache stale ({cache_age:.1f}d > {FW_PROJECTS_CACHE_MAX_AGE_DAYS}d)"
                )
            )
            log(f"  Rescanned ({reason}): found {len(fw_paths)} project(s), "
                f"skipped {len(fw_skipped)} (parse errors)")
        else:
            fw_paths = load_fw_projects_cache()
            if fw_paths is None:
                # Cache became unreadable between age-check and load; rescan.
                discovery = discover_fw_projects_with_skipped()
                fw_paths = discovery["found"]
                fw_skipped = discovery["skipped"]
                save_fw_projects_cache(fw_paths)
                log(f"  Cache unreadable — rescanned: found {len(fw_paths)} project(s)")
            else:
                log(f"  Loaded {len(fw_paths)} project(s) from cache "
                    f"(age {cache_age:.1f}d; auto-refresh at "
                    f"{FW_PROJECTS_CACHE_MAX_AGE_DAYS}d)")

        if fw_paths:
            project_metrics = []
            for path in fw_paths:
                pm = load_fw_project_metrics(path)
                if pm:
                    project_metrics.append(pm)
            framework_stats = aggregate_fw_stats(project_metrics)
            if framework_stats:
                # Surface skipped candidates in the aggregate for dashboard rendering.
                framework_stats["skipped"] = fw_skipped
                ag = framework_stats["aggregate"]
                log(f"  Aggregated {ag['project_count']} project(s), "
                    f"{ag['worktree_count']} worktree(s)"
                    + (f", {len(fw_skipped)} skipped" if fw_skipped else ""))
            else:
                log("  No framework projects with metrics found")
    else:
        log("\n[1/7] Skipping framework stats (--no-fw-stats)")

    # Phase 2: Join
    log("\n[2/7] Joining data...")
    sessions = join_data(metas, facets)
    analyzed = sum(1 for s in sessions if s['has_facets'])
    projects = set(s['canonical_project'] for s in sessions)
    log(f"  {len(sessions)} sessions, {analyzed} with facets, {len(projects)} projects")

    # Phase 3: Compute
    log("\n[3/7] Computing KPIs...")
    kpis = compute_kpis(sessions)
    log(f"  Success rate: {kpis['outcome_counts'].get('fully_achieved',0)}/{kpis['analyzed_sessions']}")
    log(f"  Net satisfaction: {kpis['satisfaction_net_score']}%")
    log(f"  Total friction: {kpis['total_friction']} events")

    trends = compute_trends(sessions)
    log(f"  Date range: {trends['dates'][0] if trends['dates'] else 'N/A'} to {trends['dates'][-1] if trends['dates'] else 'N/A'}")

    project_breakdown = compute_project_breakdown(sessions)

    # Phase 4: Insights
    log("\n[4/7] Generating algorithmic insights...")
    insights = generate_insights(kpis, trends, project_breakdown, sessions)
    log(f"  Generated {len(insights)} insights")
    for ins in insights:
        log(f"    [{ins['priority']}] {ins['text'][:80]}...")

    # Phase 5: Narratives (opt-in)
    narratives = {}
    if args.narrative:
        if args.no_cache:
            # Clear cache to force regeneration
            import shutil
            if NARRATIVE_CACHE_DIR.exists():
                shutil.rmtree(NARRATIVE_CACHE_DIR)

        log("\n[5/7] Generating AI narratives (4 parallel calls)...")
        narratives = generate_narratives(kpis, trends, project_breakdown, sessions)
        log(f"  {len(narratives)}/{len(NARRATIVE_PROMPTS)} sections generated successfully")
    else:
        log("\n[5/7] Skipping narratives (use --narrative to enable)")

    # Phase 6: Output
    log("\n[6/7] Building dashboard...")
    meta = {
        'generated_at': datetime.now().strftime('%Y-%m-%d %H:%M'),
        'meta_errors': meta_errors,
        'facet_errors': facet_errors,
    }
    payload = build_payload(sessions, kpis, trends, project_breakdown, insights,
                            meta, stats_cache=stats_cache, narratives=narratives,
                            framework_stats=framework_stats,
                            freshness=freshness)
    payload_json = json.dumps(payload, default=str)
    html = build_html(payload_json)

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    OUTPUT_FILE.write_text(html, encoding='utf-8')

    size_kb = len(html) / 1024
    log(f"\n[7/7] Verifying output...")
    log(f"  Output: {OUTPUT_FILE}")
    log(f"  Size: {size_kb:.0f} KB")
    if narratives:
        log(f"  Narratives: {', '.join(narratives.keys())}")
    if stats_cache:
        log(f"\n  Data coverage:")
        log(f"    Historical trends: {cache_dates[0]} → {cache_dates[-1]} "
            f"({stats_cache['total_sessions']} sessions from stats-cache)")
        meta_dates = sorted(s.get('start_time', '')[:10] for s in sessions if s.get('start_time'))
        log(f"    Per-session detail: {meta_dates[0]} → {meta_dates[-1]} "
            f"({len(sessions)} sessions from session-meta)")
        log(f"    Qualitative analysis: {analyzed} sessions with facets")
    log(f"\nDone! Open the dashboard:")
    log(f"  open {OUTPUT_FILE}")


if __name__ == '__main__':
    main()
