#!/usr/bin/env python3
"""Generate a self-contained HTML dashboard from framework metrics.

Reads events from fw_event_log and scorecard JSON files, aggregates them,
and renders a single HTML file with inline SVG charts and CSS.
"""

from __future__ import annotations

import json
import webbrowser
from datetime import datetime, timezone
from pathlib import Path

try:
    from scripts.fw_event_log import read_events as _read_events
except ImportError:
    from fw_event_log import read_events as _read_events


# ---------------------------------------------------------------------------
# Data loading
# ---------------------------------------------------------------------------

def load_events(since: str | None = None) -> list[dict]:
    """Load all events from the metrics JSONL files.

    Wraps fw_event_log.read_events(), using the current working directory
    as the project root (required for monkeypatch.chdir isolation in tests).
    """
    return _read_events(since=since)


def load_scorecards(metrics_dir: Path) -> list[dict]:
    """Load all scorecard JSON files from *metrics_dir*, sorted by timestamp.

    Skips files that do not exist or contain malformed JSON.
    """
    if not metrics_dir.exists():
        return []

    scorecards: list[dict] = []
    for path in metrics_dir.glob("scorecard-*.json"):
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            # Attach filename (no path) for partitioning + legacy_files reporting.
            data["_source_file"] = path.name
            scorecards.append(data)
        except Exception:
            continue

    scorecards.sort(key=lambda s: s.get("timestamp", ""))
    return scorecards


# ---------------------------------------------------------------------------
# Aggregation
# ---------------------------------------------------------------------------

def aggregate_safety(events: list[dict]) -> dict:
    """Aggregate safety-category events into counts and reason tallies."""
    total_approvals = 0
    total_blocks = 0
    warnings = 0
    block_reasons: dict[str, int] = {}

    for e in events:
        if e.get("category") != "safety":
            continue
        ev = e.get("event")
        if ev == "approve":
            total_approvals += 1
        elif ev == "block":
            total_blocks += 1
            reason = e.get("data", {}).get("reason")
            if reason:
                block_reasons[reason] = block_reasons.get(reason, 0) + 1
        elif ev == "warn":
            warnings += 1

    total = total_approvals + total_blocks
    block_rate_pct = (total_blocks / total * 100) if total > 0 else 0.0

    return {
        "total_approvals": total_approvals,
        "total_blocks": total_blocks,
        "block_rate_pct": block_rate_pct,
        "block_reasons": block_reasons,
        "warnings": warnings,
    }


def aggregate_cost_routing(events: list[dict]) -> dict:
    """Aggregate cost-category route events into frequency and savings data."""
    total_routes = 0
    agent_frequency: dict[str, int] = {}
    strategy_distribution: dict[str, int] = {}
    total_est_savings = 0.0
    skipped_agents_total = 0

    for e in events:
        if e.get("category") != "cost" or e.get("event") != "route":
            continue
        total_routes += 1
        data = e.get("data", {})
        agent = data.get("agent")
        if agent:
            agent_frequency[agent] = agent_frequency.get(agent, 0) + 1
        strategy = data.get("strategy")
        if strategy:
            strategy_distribution[strategy] = strategy_distribution.get(strategy, 0) + 1
            if strategy == "skip":
                skipped_agents_total += 1
        try:
            total_est_savings += float(data.get("est_cost_saved", 0.0))
        except (TypeError, ValueError):
            pass

    return {
        "total_routes": total_routes,
        "agent_frequency": agent_frequency,
        "strategy_distribution": strategy_distribution,
        "total_est_savings": total_est_savings,
        "skipped_agents_total": skipped_agents_total,
    }


_SCHEMA_VERSION = 2


def aggregate_conformance(scorecards: list[dict]) -> dict:
    """Aggregate schema v2 scorecards into composite + per-component averages.

    Scorecards without ``schema_version == 2`` are treated as legacy: they
    are excluded from aggregates and their filenames are surfaced in
    ``legacy_count`` and ``legacy_files`` so the dashboard can render a
    visible "legacy scorecard detected" note. Filenames only — never
    paths (path-leakage property).

    None sub-score values in ``components`` are skipped (Scorecard
    sentinel pattern) so component averages reflect only observed
    signals.
    """
    v2_cards: list[dict] = []
    legacy_files: list[str] = []

    for card in scorecards:
        if card.get("schema_version") == _SCHEMA_VERSION:
            v2_cards.append(card)
            continue
        # Legacy — surface the basename of its source file (no path).
        source_file = card.get("_source_file") or ""
        # Defensive: even if _source_file includes a path, take basename only.
        basename = Path(source_file).name if source_file else ""
        if basename:
            legacy_files.append(basename)

    if not v2_cards:
        return {
            "count": 0,
            "avg_composite": 0,
            "scores_over_time": [],
            "avg_components": {},
            "legacy_count": len(legacy_files),
            "legacy_files": legacy_files,
        }

    count = len(v2_cards)
    scores_over_time = [
        {"ts": s.get("timestamp", ""), "composite": s.get("composite_score", 0.0)}
        for s in v2_cards
    ]
    avg_composite = sum(s.get("composite_score", 0.0) for s in v2_cards) / count

    component_sums: dict[str, float] = {}
    component_counts: dict[str, int] = {}
    for s in v2_cards:
        for k, v in s.get("components", {}).items():
            if v is None:
                continue
            try:
                component_sums[k] = component_sums.get(k, 0.0) + float(v)
            except (TypeError, ValueError):
                continue
            component_counts[k] = component_counts.get(k, 0) + 1

    avg_components = {
        k: component_sums[k] / component_counts[k]
        for k in component_sums
    }

    return {
        "count": count,
        "avg_composite": avg_composite,
        "scores_over_time": scores_over_time,
        "avg_components": avg_components,
        "legacy_count": len(legacy_files),
        "legacy_files": legacy_files,
    }


def aggregate_sessions(events: list[dict]) -> dict:
    """Group events by session ID and compute durations."""
    sessions: dict[str, list[str]] = {}

    for e in events:
        sid = e.get("sid")
        if not sid:
            continue
        ts = e.get("ts", "")
        sessions.setdefault(sid, []).append(ts)

    if not sessions:
        return {
            "session_count": 0,
            "events_per_session": {},
            "session_durations_min": [],
            "avg_duration_min": 0,
        }

    events_per_session: dict[str, int] = {}
    session_durations_min: list[float] = []

    for sid, timestamps in sessions.items():
        events_per_session[sid] = len(timestamps)
        valid_ts = []
        for ts in timestamps:
            try:
                valid_ts.append(datetime.fromisoformat(ts.replace("Z", "+00:00")))
            except Exception:
                pass
        if len(valid_ts) >= 2:
            duration = (max(valid_ts) - min(valid_ts)).total_seconds() / 60.0
        else:
            duration = 0.0
        session_durations_min.append(duration)

    avg_duration_min = (
        sum(session_durations_min) / len(session_durations_min)
        if session_durations_min else 0
    )

    return {
        "session_count": len(sessions),
        "events_per_session": events_per_session,
        "session_durations_min": session_durations_min,
        "avg_duration_min": avg_duration_min,
    }


def aggregate_protocol(events: list[dict]) -> dict:
    """Aggregate protocol-category events into warning and block counts."""
    total_warnings = 0
    total_blocks = 0
    violation_types: dict[str, int] = {}

    for e in events:
        if e.get("category") != "protocol":
            continue
        ev = e.get("event")
        data = e.get("data", {})
        violation = data.get("violation")
        if ev == "warn":
            total_warnings += 1
        elif ev == "block":
            total_blocks += 1
        if violation:
            violation_types[violation] = violation_types.get(violation, 0) + 1

    return {
        "total_warnings": total_warnings,
        "total_blocks": total_blocks,
        "violation_types": violation_types,
    }


# ---------------------------------------------------------------------------
# SVG chart rendering
# ---------------------------------------------------------------------------

def render_svg_bar_chart(
    data: dict[str, float],
    title: str,
    width: int = 400,
    height: int = 200,
) -> str:
    """Render a simple horizontal bar chart as an inline SVG string."""
    if not data:
        safe_title = title.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
        return (
            f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}">'
            f'<text x="10" y="20" font-size="12">{safe_title} — no data</text>'
            f"</svg>"
        )

    padding_left = 150
    padding_top = 30
    padding_bottom = 20
    bar_area_width = width - padding_left - 10
    max_val = max(data.values()) or 1.0
    bar_height = max(8, (height - padding_top - padding_bottom) // len(data) - 4)
    items = list(data.items())

    bars = []
    for i, (label, value) in enumerate(items):
        y = padding_top + i * (bar_height + 4)
        bar_w = int(value / max_val * bar_area_width)
        safe_label = label.replace("&", "&amp;").replace("<", "&lt;")
        bars.append(
            f'<text x="{padding_left - 5}" y="{y + bar_height - 2}" '
            f'text-anchor="end" font-size="11">{safe_label}</text>'
            f'<rect x="{padding_left}" y="{y}" width="{bar_w}" height="{bar_height}" fill="#4a90d9"/>'
            f'<text x="{padding_left + bar_w + 3}" y="{y + bar_height - 2}" font-size="10">{value:.0f}</text>'
        )

    safe_title = title.replace("&", "&amp;").replace("<", "&lt;")
    content = "\n".join(bars)
    return (
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}">'
        f'<text x="{width // 2}" y="18" text-anchor="middle" font-size="13" font-weight="bold">{safe_title}</text>'
        f"{content}"
        f"</svg>"
    )


def render_svg_line_chart(
    points: list[tuple[str, float]],
    title: str,
    width: int = 400,
    height: int = 200,
) -> str:
    """Render a line chart as an inline SVG string."""
    if not points:
        safe_title = title.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
        return (
            f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}">'
            f'<text x="10" y="20" font-size="12">{safe_title} — no data</text>'
            f"</svg>"
        )

    padding_left = 40
    padding_right = 20
    padding_top = 30
    padding_bottom = 30
    plot_w = width - padding_left - padding_right
    plot_h = height - padding_top - padding_bottom

    values = [v for _, v in points]
    min_v = min(values)
    max_v = max(values)
    v_range = max_v - min_v or 1.0

    n = len(points)
    coords = []
    for i, (label, val) in enumerate(points):
        x = padding_left + (i / max(n - 1, 1)) * plot_w
        y = padding_top + (1.0 - (val - min_v) / v_range) * plot_h
        coords.append((x, y, label, val))

    if len(coords) == 1:
        x, y, label, val = coords[0]
        safe_title = title.replace("&", "&amp;").replace("<", "&lt;")
        return (
            f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}">'
            f'<text x="{width // 2}" y="18" text-anchor="middle" font-size="13" font-weight="bold">{safe_title}</text>'
            f'<circle cx="{x:.1f}" cy="{y:.1f}" r="4" fill="#4a90d9"/>'
            f'<text x="{x:.1f}" y="{y - 6:.1f}" text-anchor="middle" font-size="10">{val:.2f}</text>'
            f"</svg>"
        )

    polyline_pts = " ".join(f"{x:.1f},{y:.1f}" for x, y, _, _ in coords)
    dots = "".join(
        f'<circle cx="{x:.1f}" cy="{y:.1f}" r="3" fill="#4a90d9"/>'
        for x, y, _, _ in coords
    )
    labels = "".join(
        f'<text x="{x:.1f}" y="{height - 5}" text-anchor="middle" font-size="9">'
        f'{label[:10].replace("&", "&amp;").replace("<", "&lt;")}</text>'
        for x, _, label, _ in coords
    )

    safe_title = title.replace("&", "&amp;").replace("<", "&lt;")
    return (
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}">'
        f'<text x="{width // 2}" y="18" text-anchor="middle" font-size="13" font-weight="bold">{safe_title}</text>'
        f'<polyline points="{polyline_pts}" fill="none" stroke="#4a90d9" stroke-width="2"/>'
        f"{dots}"
        f"{labels}"
        f"</svg>"
    )


# ---------------------------------------------------------------------------
# HTML rendering
# ---------------------------------------------------------------------------

_CSS = """
body { font-family: sans-serif; margin: 0; padding: 20px; background: #f5f5f5; color: #222; }
h1 { color: #333; }
h2 { color: #444; border-bottom: 2px solid #4a90d9; padding-bottom: 4px; }
.section { background: #fff; border-radius: 6px; padding: 16px; margin-bottom: 24px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); }
.meta { color: #888; font-size: 12px; margin-top: 8px; }
table { border-collapse: collapse; width: 100%; }
th, td { text-align: left; padding: 6px 10px; border-bottom: 1px solid #eee; }
th { background: #f0f4fa; }
"""


def render_dashboard(sections: dict[str, str], generated_at: str) -> str:
    """Render a complete self-contained HTML document from section fragments."""
    safe_ts = generated_at.replace("&", "&amp;").replace("<", "&lt;")
    body_parts = []
    for heading, content in sections.items():
        safe_heading = heading.replace("&", "&amp;").replace("<", "&lt;")
        body_parts.append(
            f'<div class="section"><h2>{safe_heading}</h2>{content}</div>'
        )

    body_html = "\n".join(body_parts)
    return (
        "<!DOCTYPE html>\n"
        "<html>\n"
        "<head>\n"
        "<meta charset=\"utf-8\">\n"
        "<title>Framework Dashboard</title>\n"
        f"<style>\n{_CSS}\n</style>\n"
        "</head>\n"
        "<body>\n"
        "<h1>Framework Dashboard</h1>\n"
        f'<p class="meta">Generated: {safe_ts}</p>\n'
        f"{body_html}\n"
        "</body>\n"
        "</html>"
    )


# ---------------------------------------------------------------------------
# Orchestration entry point
# ---------------------------------------------------------------------------

def generate_dashboard(
    since: str | None = None,
    output_path: Path | None = None,
    open_browser: bool = False,
) -> Path:
    """Generate the full dashboard HTML and write it to disk.

    Args:
        since: Optional ISO date string to filter events (YYYY-MM-DD).
        output_path: Where to write the HTML. Defaults to .context/dashboard.html.
        open_browser: If True, open the output file in the default browser.

    Returns:
        The Path to the written HTML file.
    """
    if output_path is None:
        output_path = Path.cwd() / ".context" / "dashboard.html"

    output_path.parent.mkdir(parents=True, exist_ok=True)

    events = load_events(since=since)

    conformance_dir = Path.cwd() / ".context" / "metrics" / "conformance"
    scorecards = load_scorecards(conformance_dir)

    safety = aggregate_safety(events)
    cost = aggregate_cost_routing(events)
    conformance = aggregate_conformance(scorecards)
    sessions = aggregate_sessions(events)
    protocol = aggregate_protocol(events)

    # Build section HTML fragments
    sections: dict[str, str] = {}

    # Safety section
    safety_html = (
        f"<p>Approvals: {safety['total_approvals']} | "
        f"Blocks: {safety['total_blocks']} | "
        f"Block rate: {safety['block_rate_pct']:.1f}% | "
        f"Warnings: {safety['warnings']}</p>"
    )
    if safety["block_reasons"]:
        chart = render_svg_bar_chart(
            {k: float(v) for k, v in safety["block_reasons"].items()},
            title="Block Reasons",
        )
        safety_html += chart
    sections["Safety"] = safety_html

    # Cost Routing section
    cost_html = (
        f"<p>Total routes: {cost['total_routes']} | "
        f"Estimated savings: ${cost['total_est_savings']:.2f} | "
        f"Skipped agents: {cost['skipped_agents_total']}</p>"
    )
    if cost["agent_frequency"]:
        chart = render_svg_bar_chart(
            {k: float(v) for k, v in cost["agent_frequency"].items()},
            title="Agent Frequency",
        )
        cost_html += chart
    sections["Cost Routing"] = cost_html

    # Conformance section
    conf_html = (
        "<p class=\"disclaimer\">Measurement only — do not gate merges "
        "or deployments on this aggregate. See per-project drill-down "
        "for evidence.</p>"
        f"<p>Scorecards: {conformance['count']} | "
        f"Avg composite: {conformance['avg_composite']:.2f}</p>"
    )
    legacy_count = conformance.get("legacy_count", 0)
    if legacy_count:
        conf_html += (
            f"<p class=\"warn\">&#9888; {legacy_count} legacy scorecard(s) "
            "detected — re-score required. Files: "
            f"{', '.join(conformance.get('legacy_files', []))}</p>"
        )
    if conformance["scores_over_time"]:
        points = [(s["ts"][:10], s["composite"]) for s in conformance["scores_over_time"]]
        chart = render_svg_line_chart(points, title="Conformance Over Time")
        conf_html += chart
    sections["Conformance"] = conf_html

    # Sessions section
    sess_html = (
        f"<p>Sessions: {sessions['session_count']} | "
        f"Avg duration: {sessions['avg_duration_min']:.1f} min</p>"
    )
    sections["Sessions"] = sess_html

    # Protocol section
    proto_html = (
        f"<p>Warnings: {protocol['total_warnings']} | "
        f"Blocks: {protocol['total_blocks']}</p>"
    )
    sections["Protocol"] = proto_html

    generated_at = datetime.now(timezone.utc).isoformat()
    html = render_dashboard(sections, generated_at=generated_at)
    output_path.write_text(html, encoding="utf-8")

    if open_browser:
        webbrowser.open(f"file://{output_path.resolve()}")

    return output_path


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Generate framework metrics dashboard")
    parser.add_argument("--since", default=None, help="Filter events since date (YYYY-MM-DD)")
    parser.add_argument("--output", default=None, help="Output HTML path")
    parser.add_argument("--open", action="store_true", help="Open in default browser")
    args = parser.parse_args()

    out = generate_dashboard(
        since=args.since,
        output_path=Path(args.output) if args.output else None,
        open_browser=args.open,
    )
    print(f"Dashboard written to: {out}")
