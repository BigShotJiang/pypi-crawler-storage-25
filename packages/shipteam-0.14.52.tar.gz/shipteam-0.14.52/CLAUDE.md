# ShipTeam — Claude Integration Documentation

> Turn Claude Code into a build team. See [docs/00-README.md](docs/00-README.md) for the documentation guide.

---

## STOP - READ BEFORE EVERY DEPLOYMENT

> Claude: You MUST complete this checklist before ANY push to main or deployment.

| # | Step | Command/Action |
|---|------|----------------|
| 1 | Update version description | Update CLAUDE.md + README.md version description line |
| 2 | Update release notes | Edit `release_notes.md` |
| 3 | Update relevant docs | features, database, architecture docs as needed |
| 4 | Add insight (minor/major) | Edit `docs/70-INSIGHTS.md` |
| 5 | If prompts changed | <!-- CUSTOMIZE: prompt export command --> + commit snapshots |
| 6 | Create PR | `gh pr create` |
| 7 | **WAIT FOR USER APPROVAL** | Do NOT merge without explicit "yes" |
| 8 | Deploy after merge | <!-- CUSTOMIZE: deployment method and wait time --> |
| 9 | Version auto-bumps | Automatic patch increment on merge to main |
| 10 | Verify health | <!-- CUSTOMIZE: health check command --> |

See: [docs/20-DEPLOYMENT.md](docs/20-DEPLOYMENT.md) for full protocol

---

## Current Version: 0.14.52 - (pending release notes)
## Next Release: Task Pack v1 (URL Shortener) — runnable benchmark across three drivers (Claude Code, Aider, Droid). Phase 5 sub-phases 5a/5b/5c/5d/5e turned ADR-017's harness skeleton into a v1 benchmark: directory-per-pack convention with `pack.yaml` + dataclass binding (no JSON Schema, no plugin discovery — overkill at N=1 pack); sandboxed scoring split where `frozen_tests/` lives outside the workspace and is RO-mounted into the container (defends against the Cognition Devin assertion-extraction failure mode that 3-of-4 surveyed benchmarks ship into); salted system-prompt cache defeat for the Claude Code driver (`uuid5(NAMESPACE_DNS, str(seed))` suffix; salt-overhead empirically probed at 33–38 tokens/call against `claude-sonnet-4-5` via `messages.count_tokens` — both the Step 3 "~20" and Step 4.5 "≤30" estimates were wrong, only the empirical probe surfaced the real number; ADR-016 fired again); three-driver protocol with `cost_source` polymorphism (`"computed"` for Claude Code SDK token×rate-sheet vs `"scraped"` for Aider/Droid stdout parsing — SDK's `total_cost_usd` is a local estimate per Issue #487 and MUST NOT be authoritative); abort-spine factory `make_aborted_result` enforces consistent abort shape across timeout/FileNotFoundError/vendor-text-match/returncode-nonzero/missing-tokens/cache-leak/unrecognized-model paths (inline `DriverResult` construction in error paths is the abort-spine drift bug class fw-review-code reliably catches at the next phase); module-level cognitive isolation via three patch points (`run_agent_sdk`, `ClaudeSDKClient`, `_check_salt_placement`) — production stub raises `NotImplementedError` so the driver cannot accidentally hit the network in tests; defense-in-depth UNION regex on Aider/Droid stdout (`rate.?limit|API.?error|connection.?error|context.?length.?exceeded|litellm\.exceptions` + Droid-specific `factorydroid:\s*error`) — both CLIs route through litellm under the hood, so litellm-shaped errors surface in stdout under upstream failures and would otherwise pass through as `aborted=false` with a misleading `acceptance_pct=0.0`. Phase 5e final-gate review caught Droid regex divergence from AC-19 (HIGH-1: production was narrower than the test docstring contract claimed) and 4 SDK CVEs (DEPS-CRIT-1 CVE-2026-35022 CVSS 9.3 Auth Helpers, DEPS-CRIT-2 CVE-2026-35021 CVSS 8.4 Prompt Editor, DEPS-HIGH-2 0.1.68 vs 0.1.69 audit, CONCURRENCY-RACE-2) deferred to Phase 5g — all CVE attack surfaces are unreachable in Phase 5e (`run_agent_sdk` is `NotImplementedError` stub). 374/374 tests green across drivers/scoring/task_packs/aggregation/harness/integration/dashboard. ADR-019 extracts the architectural rationale; rejected the `entry_points`/JSON Schema route as overengineering at N=1, accepted the SWE-bench-style "tests in workspace" tradeoff cost in exchange for tamper resistance. v1.1 backlog: salt-format-shrink option (`\n\n<s>{seed}</s>` ≈ 5 tokens) for sweep volumes >10K cells; third-party pack support gated on prompt-content review (OWASP LLM01:2025 indirect-injection vector). PRIOR RELEASE (0.14.49 shipped via PR #171): Safety-infra block rule no longer false-positives on read-only ops (`git show -- .claude/settings.json`, `cat .claude/hooks/foo.py`), commit messages mentioning safety paths, or `cp .claude/settings.json /tmp/backup.json` (safety path as SOURCE, not destination). Old rule did `re.search(path) and re.search(operator)` independently against whole command text — both halves matched even when unrelated (e.g., the `>` in a `<placeholder>` token plus the path elsewhere in a commit message body). New rule uses 5 precise adjacency patterns: `>>?\s*[\'"]?<path>`, `tee ... <path>`, `cp|mv flags? srcs+ <path>`, `ln flags? srcs+ <path>`, `sed -i ... <path>`. Bundle copy `src/shipteam/framework/hooks/auto_approve_base.py` synced (PR #169 already wired this). 7 new negative test cases in `test/safety_gate.bats` pin the corrected behavior; all 6 existing attack patterns (echo `>` / `>>`, tee, cp, mv, ln, sed -i) continue to hard-block. Caught Python f-string `{1,2}` tuple-expression pitfall on first test run — `>>?` used instead. PRIOR RELEASE (0.14.48 already shipped via PR #170): Hook commands resolve via `git rev-parse --show-toplevel` All 16 hook entries in `.claude/settings.json` switched from `python3 .claude/hooks/foo.py` (CWD-relative — broke when Claude `cd`d into a subdirectory mid-session, wedging every subsequent tool call until the user restarted) to `python3 "$(git rev-parse --show-toplevel 2>/dev/null || pwd)/.claude/hooks/foo.py"`. The shell resolves `git rev-parse --show-toplevel` BEFORE invoking python3, returning the worktree root regardless of CWD. This was originally fixed in commit 85fc5f0 (2026-03-23) and silently regressed across PRs #70/#71/#77/#83 when new hook entries were added using the old relative-path style. Adds `test/hook_cwd_resolution.bats` regression test (three checks: no relative-path commands, every command uses the canonical resolution pattern, end-to-end execution from a subdirectory does not emit "can't open file" / "No such file or directory") so the bug can't silently regress again. Templated via `fw-sync.sh` to consumer projects (existing `policy: template` entry in `config/fw-manifest.yaml`). Also corrects the misleading auto-memory entry that said "use CWD-relative paths" — the cure is `git rev-parse`, not relative paths and not `$CLAUDE_PROJECT_DIR` (which has its own upstream reliability bugs #33815, #45820). ALSO INCLUDED — Workspace Hygiene rule for ephemeral worktrees (`.claude/rules/sherlock-methodology.md`) — codifies the failure mode where durable working content (drafts the next session expects to read) gets written to a gitignored path inside an ephemeral workspace and is then lost on cleanup. Frames the orthogonality of `.gitignore` (exposure control) vs. workspace persistence (filesystem durability). Includes detection snippet (`git rev-parse --git-common-dir` vs `--git-dir`) with three documented edge cases (submodules, `GIT_DIR` env override, git ≤ 2.1.4 returning the literal flag string per pre-commit #831), recovery steps, and honest compliance ceiling (cites IFScale arXiv 2507.11538 ~68% at high instruction density and lost-in-the-middle arXiv 2307.03172). Defers the deterministic PreToolUse hook to N=3 incidents per Rule of Three. Cross-reference prompts added at Hudson Step 4 / Sherlock Lite Step 6 / Full Sherlock Step 8. Lives in `policy: replace` so `fw-sync.sh` propagates to all framework-using projects without a separate auto-load step. Generalizes to worktrees, devcontainers, Codespaces, Docker volumes, CI runners.
## Status: STABLE

---

## SESSION START / CONTEXT CONTINUATION - MANDATORY

**AFTER ANY context compaction or session start:**
1. **VERIFY BRANCH**: <!-- CUSTOMIZE: git branch check command with correct GIT_DIR/GIT_WORK_TREE paths -->
2. **TELL USER** what branch you are on, ask if correct
3. **WAIT** for confirmation before any actions

### Auto-Sync with Main

Session startup auto-syncs with `origin/main`. If behind: merges (fast-forward preferred). If conflict: leaves in progress for Claude to resolve. Uncommitted changes are stashed. Use `--no-sync` to skip: `./scripts/claude-session.sh --no-sync feature/branch`. Manual sync: `./scripts/sync-with-main.sh [--force]`.

### Automatic Protections

`auto-approve.py` is the framework-wide PreToolUse safety gate. The block rules canonicalize first (env-prefix stripped, subshell/`cd`-prefix stripped) and check every variant — so an obfuscation that hides a dangerous command in a wrapper still hard-denies. The auto-approve rules invert the asymmetry: they only fire when the original command is already canonical, so an env-prefix or `cd`-prefix forces the prompt to the user even when the inner command would have auto-approved.

**HARD BLOCKS (exit 2)**
- **Filesystem**: `rm -rf` (default-deny on unlisted paths), recursive removal of project/system paths
- **Git history**: `git push --force` / `--force-with-lease`, `git reset --hard`, deletion of protected branches (`main`, `master`, `develop`, `release/*`, `hotfix/*`) — including the legacy `git push origin :main` deletion form when the destination is protected
- **Git push policy** (framework-wide via `auto_approve_base.py`):
  - Flags: `--no-verify`, `--tags`, `--mirror`, `--all`
  - Refspec attacks: protected destination via `feat/foo:main`, `refs/heads/main`, `HEAD:main`, `HEAD~3:main`, wildcard `*:*`
  - Namespace tricks: `refs/notes/`, `refs/replace/`, `refs/tags/`
  - Bare semver tag pushes: `v1.0`, `V1.2.3`
- **Database**: `DROP`/`TRUNCATE`, `DELETE` without `WHERE` (SQL comment-aware)
- **Network recon/exfiltration**: `nc`, `ncat`, `nmap`, `socat`, `tcpdump`
- **Writes to safety infrastructure**: any shell redirect / `tee` / `cp` / `mv` / `ln` targeting `.claude/hooks/`, `.claude/rules/`, or `.claude/settings.json` is hard-denied. Edit/Write tool calls to those same paths fall through to user prompt (the diff preview is the audit). `.claude/skills/` and `.claude/agents/` are NOT in this gate — edits to those paths route through the normal user-prompt flow.

**AUTO-APPROVES**
- Branch deletion via `-d` for `session/claude-*` and `dependabot/*` (only when no shell metacharacters present in the branch name — CWE-551 guard)
- Git push to safe-prefix branches: `session/*`, `feat/*`, `fix/*`, `docs/*`, `chore/*`, `refactor/*`, `test/*` — only with `-u` / `--set-upstream` or no flag, no env-prefix on the original command, no delete-refspec (`:branch` / `+:branch`), no shell metacharacters
- Standard Claude Code workflow: known editor/test/build commands, project scripts, venv invocations, git/gh subcommands

**FALLS THROUGH (user prompted)**
- `gh pr merge` (with or without `--delete-branch`)
- Non-protected branch deletion that doesn't match an auto-approve prefix
- Push commands carrying an env-prefix (e.g. `GIT_SSH_COMMAND=...`, `LD_PRELOAD=...`, `PATH=...`) — refused even when the inner command would auto-approve, because the env attaches to the executed git binary
- Push commands with shell metacharacters (`$(...)`, backticks, `;`, `&&`, `|`, `>`, `*`, etc.) — CWE-551 guard defers to user judgment rather than risk a parser bug widening the trust boundary
- Anything not matched by an explicit allow or deny rule

**OTHER HOOKS**
- `branch-check.py` — BLOCKS on branch mismatch
- `checkout-guard.py` — BLOCKS branch switches when another Claude session is active (prevents concurrent session interference)
- `commit-trust-check.py` — BLOCKS if CI failed (gated by `hooks.deploy_gate` config; also checks `deployment.health_url` on main)
- `pre-compact.py` — Saves enriched state before context compaction (branch, PR title, diff stats, active plan, session metadata)
- `merge-conflict-resolver.py` — INSTRUCTS Claude to resolve merge conflicts
- `protocol-validator.py` — WARNS on deployment-related actions (push to main, PR creation, deploy scripts)
- `claude-session.sh` — AUTO-SYNCS with origin/main on startup

The push policy lives in `.claude/hooks/auto_approve_base.py` (framework-wide, `policy: replace` in `config/fw-manifest.yaml` — projects cannot drift from it). Per-project `.claude/settings.local.json` deny rules layer on top: a hook `allow` cannot override a settings `deny`, but a hook `deny` is always honored. See `docs/85-SAFETY-LIMITS.md` for the honest accounting of what the hooks enforce vs. don't, and known bypass vectors.

If blocked: Check `.claude/expected-branch.txt` or `rm` to clear it.

### Session State

State files in `.claude/state/` persist across context compactions:
- `session-lock.json` -- Active session lock (prevents concurrent sessions)
- `drift-last-check.json` -- Last drift check timestamp
- `merge-conflict.json` -- Active merge conflict state
- `pre-compact-handoff.json` -- Branch and task context saved before compaction
- `expected-branch.txt` -- Expected branch for branch-check validation

These files are gitignored (only `.gitkeep` is tracked).

### Multi-Session Workflow
```bash
./scripts/claude-session.sh feature/my-feature      # Creates worktree + auto-syncs + launches Claude
./scripts/claude-session.sh --no-sync feature/test   # Skip auto-sync
./scripts/generate-shell-alias.sh --install          # One-time: add claude-<project> alias to ~/.zshrc
```
Session script reads `stack.frontend.root` and `stack.backend.root` from `config/framework.yaml` for directory layout. Set these to `"."` for root-level projects or leave empty to skip.
Rule: Only ONE Claude session per worktree. Use `--repo <!-- CUSTOMIZE: org/repo -->` with `gh` commands in worktrees.

---

## DEPLOYMENT PROTOCOL

Version numbers auto-increment on merge to main (via `.github/workflows/auto-version-bump.yml`). Include version description + release notes + insight in your feature PR. Follow docs/20-DEPLOYMENT.md tiers: Tier 1 (Full), Tier 2 (Simplified), Tier 3 (Emergency). Manual override: `./scripts/bump-version.sh X.Y.Z` (only if auto-bump fails). DO NOT manually bump version numbers.

**Fast Deploy** (hotfixes only, skips tests): `gh workflow run "CI/CD Pipeline" -f fast_deploy=true`

**Doc Staleness Gate**: The `protocol-validator.py` PostToolUse hook warns Claude when `release_notes.md` or `CHANGELOG.md` do not mention the current version. If Claude creates a PR with stale docs, the hook feeds the warning back — Claude should then update docs and recreate the PR. Disable with `hooks.doc_staleness_check: false` in `framework.yaml`.

---

**Database/Migration Protocol**: See `.claude/rules/database-migrations.md` (auto-loaded for database paths)

---

## GIT WORKTREE CONFIGURATION

<!-- CUSTOMIZE: Remove this section entirely if not using worktrees. -->

This repo uses git worktree -- it is NOT a standalone git repo. The `.git` is a FILE pointing to: <!-- CUSTOMIZE: /path/to/main-repo/.git/worktrees/dev-worktree -->

All git commands MUST use environment variables:
```bash
GIT_DIR=<!-- CUSTOMIZE: /path/to/worktree/.git --> GIT_WORK_TREE=<!-- CUSTOMIZE: /path/to/worktree --> git <command>
```

DO NOT run bare `git` commands without these variables -- they will fail.

**gh CLI workaround**: `gh pr create` with heredoc `--body` silently fails in worktrees. Use `--body-file` with a temp file instead, and always pass `--repo <!-- CUSTOMIZE: org/repo -->`.

---

## TDD Commit Workflow
```bash
./scripts/tdd-commit.sh red|green|refactor "message"   # Phase-specific commits
export TDD_MODE=1                                       # Optional strict validation
```

## Server Management
```bash
./manage_servers.sh status|start|stop|restart|heal
# <!-- CUSTOMIZE: test runner command, e.g. pytest backend/tests/... -->
```

## Quick Reference

> **Full doc index**: See [docs/00-README.md](docs/00-README.md) for all numbered docs (architecture, deployment, auth, security, database, environment, testing, features, insights, troubleshooting, archives).

| Topic | Doc | Key Info |
|-------|-----|----------|
| Rules: Anti-Patterns | `.claude/rules/anti-patterns.md` | 10 mandatory rules (always loaded) |
| Rules: Security | `.claude/rules/security.md` | OWASP, PII, auth (always loaded) |
| Rules: Database | `.claude/rules/database-migrations.md` | Schema verification (path-specific) |
| Rules: Sherlock Methodology | `.claude/rules/sherlock-methodology.md` | Step 0 routing, Hudson/Lite/Full/Holmes modes, spec-anchored plans |
| Rules: Sherlock Gate | `.claude/rules/sherlock-review-gate.md` | Multi-agent review pipeline |
| Docs: Safety Limits | `docs/85-SAFETY-LIMITS.md` | Honest accounting of what hooks enforce vs. don't; known bypass vectors; opt-in hardening |
| Skills: Deploy | `/deploy [tier1\|tier2\|tier3]` | Deployment checklist |
| Skills: Health | `/health [frontend\|backend\|all]` | Production health check |
| Skills: Release Notes | `/release-notes <N> <title>` | Generate PR description + insight |
| Skills: Schema Check | `/schema-check <table>` | Verify DB schema before migrations |
| Skills: Browse | `/browse <url>` | Visual page inspection |
| Skills: QA | `/qa [--full]` | Diff-aware visual testing |
| Skills: Retro | `/retro [7d\|14d\|30d]` | Engineering retrospective |
| Skills: Stats | `/fw-stats [7d\|30d\|all]` | Framework metrics + conformance scores |
| Agents: Forensics | `.claude/agents/fw-review-forensics.md` | AI code detection + improvement |
| Agents: Silent Failures | `.claude/agents/fw-review-error-handling.md` | Empty catch, swallowed errors, fallback masking |
| Agents: Type Design | `.claude/agents/fw-review-types.md` | Type encapsulation + invariant scoring (1-10) |
| Agents: Comments | `.claude/agents/fw-review-comments.md` | Comment accuracy, staleness, value audit |
| Agents: Dependencies | `.claude/agents/fw-review-dependencies.md` | Supply chain security, CVEs, licenses, typosquatting |
| Agents: Concurrency | `.claude/agents/fw-review-concurrency.md` | Race conditions, deadlocks, shared state in async code |
| Agents: Spec Author | `.claude/agents/fw-author-spec.md` | Generate Acceptance Criteria + Interface Contracts |
| Agents: Test Strategy | `.claude/agents/fw-author-test-strategy.md` | Author proactive `.test-matrix.md` (P0/P1/P2 tiers + oracle hints) from ACs |
| Skills: TDD Commit | `/tdd-commit <red\|green\|refactor> [msg]` | AI-generated TDD commit messages |
| Skills: Ship | `/ship [branch-name]` | Branch + commit + push + PR workflow |
| Skills: /deep-r | `/deep-r <question>` | Web-validated investigation w/ adversarial upstream search + safety pre-mortem + lens check |
| Skills: /deep-r-audit | `/deep-r-audit [scope]` | Audit existing config against known upstream issues (reverse /deep-r) |
| Skills: /verify-math | `/verify-math "<expression>" [--source=sympy\|numpy\|all] [--domain=...]` | SymPy + NumPy cross-verifier w/ AST pre-filter, authoritative citations (NIST DLMF, IEEE 754, SEMATECH); invoked by fw-review-security, fw-advisor-architecture, fw-review-performance for unchecked arithmetic |
| Lenses: Reasoning heuristics | `.claude/lenses/` | Advisory reasoning patterns (hot-path-latency, failure-domain-isolation, fit-for-purpose, explicit-tradeoff); distinct from mandatory rules |
| Scripts: Cost Routing | `scripts/cost_routing.py` | Review agent selection by diff type + LOC + cost estimates |
| Scripts: Event Logger | `scripts/fw_event_log.py` | JSONL event logging for hooks (safety, cost, protocol) |
| Scripts: Conformance | `scripts/fw_conformance.py` | Sherlock plan adherence scoring |
| Scripts: Dashboard | `scripts/generate_dashboard.py` | HTML metrics dashboard (safety, cost, conformance, sessions) |
| Scripts: Insights | `scripts/generate_insights.py` | Qualitative insights dashboard (satisfaction, friction, outcomes, AI narratives) |
| Scripts: FW Sync | `fw-sync.sh <project> [--status\|--dry-run]` | Sync framework updates to projects |
| Scripts: FW Sync | `fw-sync.sh --full-diff\|--merge-editor\|--merged` | Full diffs, visual merge, mark resolved |
| Config: Manifest | `config/fw-manifest.yaml` | Framework file sync policies (20 agents) |
| Config: Stack Layout | `config/framework.yaml` | `stack.frontend.root`, `stack.backend.root`, `stack.frontend.port_flag` — directory layout for session bootstrap |
| Config: Worktree Gate | `config/framework.yaml` | `worktree.enabled: false` excludes `claude-session.sh` from fw-sync |
| Hooks: Safety Base | `.claude/hooks/auto_approve_base.py` | Universal safety gate (replace policy) |
| Hooks: Safety Overlay | `.claude/hooks/auto-approve.py` | Project overlay (template, imports base) |
| Hooks: Metrics Tracker | `.claude/hooks/metrics-tracker.py` | SubagentStart event logging for cost routing telemetry |
| Hooks: PostCompact Restore | `.claude/hooks/post-compact-restore.py` | Sherlock context restoration after compaction |
| Hooks: Session Lifecycle | `.claude/hooks/session-lifecycle.py` | SessionStart lifecycle event logging |
| Hooks: Checkout Guard | `.claude/hooks/checkout-guard.py` | Block branch switches during active sessions |
| Hooks: Commit Trust | `.claude/hooks/commit-trust-check.py` | CI + health verification (gated: `hooks.deploy_gate`) |
| Hooks: Protocol Validator | `.claude/hooks/protocol-validator.py` | Deployment protocol reminders |
| Research: /deep-r | `/deep-r <question>` | Structured research at Sherlock Steps 0/3/4/4.5/8 (see sherlock-methodology.md → "/deep-r Integration Summary") |
| Research: Agent Flags | `RESEARCH_NEEDED` / `UNVERIFIED_CLAIM` in agent outputs | See sherlock-review-gate.md → "RESEARCH_NEEDED Flag Protocol" |
| Auto Mode | `.claude/settings-guide.md` | Optional AI classifier permissions, hook interaction |
| CODEOWNERS | [.github/CODEOWNERS](.github/CODEOWNERS) | Auto-assign reviewers by path |
| Copilot Instructions | [.github/copilot-instructions.md](.github/copilot-instructions.md) | GitHub Copilot context |
| EditorConfig | [.editorconfig](.editorconfig) | Cross-editor formatting consistency |

## Developer Guidelines

<!-- CUSTOMIZE: Add project-specific notes (request routing, port management, alerting, etc.) -->

Claude-specific: Be systematic. Ask user to check logs before guessing. Do not adjust prompt masters without asking. Consider caching/cost savings when integrating new tech.

---

## Sherlock/Holmes/Hudson Methodology
<!-- PROFILE-CONDITIONAL: Remove this section if using minimal profile (sherlock rules are not installed) -->

**MANDATORY: On EVERY user task, run Step 0 complexity classification from `.claude/rules/sherlock-methodology.md` BEFORE writing any code.** Classify the task, present all three workflow options (Hudson/Sherlock Lite/Full Sherlock) with your recommendation, and WAIT for the user to choose before proceeding.

Full workflow (Step 0 complexity routing, Hudson/Lite/Full Sherlock/Holmes modes, spec-anchored `.sherlock-plan.md` format, Phase 8 ADR extraction): See `.claude/rules/sherlock-methodology.md` (auto-loaded)

**Review pipeline**: See `.claude/rules/sherlock-review-gate.md` (auto-loaded)

---

**Anti-Patterns**: See `.claude/rules/anti-patterns.md` (auto-loaded, 10 mandatory rules)

**Security & Privacy**: See `.claude/rules/security.md` (auto-loaded, OWASP + PII + auth rules)
