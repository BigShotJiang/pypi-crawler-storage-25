"""
aggregation/results.py — ResultRow schema enforcement and cell aggregation.

Provides:
  - SchemaViolationError: raised when a row fails required-field validation.
  - ResultRow: typed dataclass for a single benchmark run row.
  - append_result_row: validate and append a row dict to a JSONL file.
  - MetricStats: median + IQR (p25/p75) for a numeric metric.
  - CellSummary: aggregated statistics for a (driver, task) cell.
  - aggregate_cell: compute CellSummary from a list of row dicts.
"""
from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


# ---------------------------------------------------------------------------
# Errors
# ---------------------------------------------------------------------------

class SchemaViolationError(ValueError):
    """Raised when a result row is missing a required field or has invalid values."""


# ---------------------------------------------------------------------------
# Required fields (AC-6)
# ---------------------------------------------------------------------------

_REQUIRED_FIELDS = [
    "container_digest",
    "driver_version",
    "task_pack_revision",
    "harness_version",
    "sdk_version",
    "sdk_release_date",
    "timestamp_utc",
]

_VALID_CACHE_STRATEGIES = ("salted", "native")


# ---------------------------------------------------------------------------
# ResultRow dataclass (minimal — tests use plain dicts via append_result_row)
# ---------------------------------------------------------------------------

@dataclass
class ResultRow:
    driver: str
    driver_version: str
    task: str
    task_pack_revision: str
    seed: int
    container_digest: str
    harness_version: str
    sdk_version: str
    sdk_release_date: str
    timestamp_utc: str
    wall_clock_ms: int
    input_tokens: int | None
    output_tokens: int | None
    cost_usd: float | None
    cost_source: str
    acceptance_pct: float
    mutation_score: dict
    semgrep_high: int
    semgrep_critical: int
    injected_bug_detections: int
    aborted: bool
    abort_reason: str | None
    rate_limited_during_run: bool
    cache_strategy: str
    driver_metadata: dict = field(default_factory=dict)


# ---------------------------------------------------------------------------
# append_result_row — validate + write one row to JSONL
# ---------------------------------------------------------------------------

def _validate_row(row: dict) -> None:
    """Validate that all required fields are present and non-empty, and that
    AC-14 cache-integrity invariants hold."""
    for f in _REQUIRED_FIELDS:
        if f not in row:
            raise SchemaViolationError(
                f"Missing required field: {f}"
            )
        val = row[f]
        if val is None or val == "":
            raise SchemaViolationError(
                f"Required field '{f}' must be non-empty/non-null"
            )

    # container_digest must be a content-addressed sha256 reference (AC-3/AC-6).
    digest = row["container_digest"]
    if not isinstance(digest, str) or not digest.startswith("sha256:"):
        raise SchemaViolationError(
            f"container_digest must be a 'sha256:...' string, got {digest!r}"
        )

    # cache_strategy enum (AC-14)
    cache_strategy = row.get("cache_strategy")
    if cache_strategy not in _VALID_CACHE_STRATEGIES:
        raise SchemaViolationError(
            f"cache_strategy must be one of {_VALID_CACHE_STRATEGIES}, got {cache_strategy!r}"
        )

    # driver_metadata must be a dict containing an explicit cache_read_input_tokens;
    # defaulting to 0 on absence would silently bypass the AC-14 contamination guard.
    driver_metadata = row.get("driver_metadata")
    if not isinstance(driver_metadata, dict):
        raise SchemaViolationError(
            f"driver_metadata must be a dict, got {type(driver_metadata).__name__}"
        )
    if "cache_read_input_tokens" not in driver_metadata:
        raise SchemaViolationError(
            "driver_metadata.cache_read_input_tokens is required (AC-14 "
            "cache-integrity gate); absence would silently bypass the check."
        )
    cache_read_tokens = driver_metadata["cache_read_input_tokens"]
    if cache_read_tokens and cache_read_tokens > 0:
        raise SchemaViolationError(
            f"Cache contamination detected: cache_read_input_tokens={cache_read_tokens} > 0. "
            "Rows with prompt-cache reads are rejected to preserve benchmark integrity."
        )


def append_result_row(row: dict, output_jsonl: Path) -> None:
    """
    Validate row and append it as a JSON line to output_jsonl.

    Raises SchemaViolationError before writing if validation fails,
    ensuring the file is not modified on error.
    """
    _validate_row(row)
    with output_jsonl.open("a", encoding="utf-8") as fh:
        fh.write(json.dumps(row) + "\n")


# ---------------------------------------------------------------------------
# Aggregation — MetricStats + CellSummary + aggregate_cell
# ---------------------------------------------------------------------------

@dataclass
class MetricStats:
    """Median + IQR (p25, p75) for a numeric metric."""
    median: float
    p25: float
    p75: float


def _percentile(values: list[float], pct: float) -> float:
    """Simple linear-interpolation percentile (matches numpy default)."""
    if not values:
        return 0.0
    sorted_vals = sorted(values)
    n = len(sorted_vals)
    if n == 1:
        return sorted_vals[0]
    idx = pct / 100.0 * (n - 1)
    lo = int(idx)
    hi = lo + 1
    if hi >= n:
        return float(sorted_vals[-1])
    frac = idx - lo
    return sorted_vals[lo] + frac * (sorted_vals[hi] - sorted_vals[lo])


def _metric_stats(values: list[float]) -> MetricStats:
    return MetricStats(
        median=_percentile(values, 50),
        p25=_percentile(values, 25),
        p75=_percentile(values, 75),
    )


_AGGREGATE_METRICS = [
    "wall_clock_ms",
    "input_tokens",
    "output_tokens",
    "cost_usd",
    "acceptance_pct",
    "semgrep_high",
    "semgrep_critical",
    "injected_bug_detections",
]

_PARTIAL_THRESHOLD = 10  # fewer than this valid rows → partial cell


@dataclass
class CellSummary:
    """Aggregated statistics for a (driver, task) cell."""
    wall_clock_ms: MetricStats
    input_tokens: MetricStats
    output_tokens: MetricStats
    cost_usd: MetricStats
    acceptance_pct: MetricStats
    semgrep_high: MetricStats
    semgrep_critical: MetricStats
    injected_bug_detections: MetricStats
    is_partial: bool
    n_complete: int
    n_aborted: int
    # AC-21 fields
    median_per_metric: dict[str, float | None] = field(default_factory=dict)
    p25_per_metric: dict[str, float | None] = field(default_factory=dict)
    p75_per_metric: dict[str, float | None] = field(default_factory=dict)
    sample_size_per_metric: dict[str, int] = field(default_factory=dict)
    row_count_total: int = 0
    row_count_valid: int = 0
    warnings: list[str] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)


def aggregate_cell(rows: list[dict]) -> CellSummary:
    """
    Compute CellSummary from a list of row dicts.

    Aborted rows are excluded from metric statistics.
    is_partial is True when fewer than 10 complete rows are available.
    AC-21: per-metric None exclusion, partial-cell WARN, cell-invalid ERROR.
    """
    complete = [r for r in rows if not r.get("aborted", False)]
    aborted = [r for r in rows if r.get("aborted", False)]
    is_partial = len(complete) < _PARTIAL_THRESHOLD
    row_count_total = len(rows)
    row_count_valid = len(complete)

    def _vals(metric: str) -> list[float]:
        result = []
        for r in complete:
            v = r.get(metric)
            if v is not None:
                result.append(float(v))
        return result

    # Cache _vals per metric — used both for per-metric dicts AND legacy
    # MetricStats fields, so compute once per metric (fw-review-code M-1).
    vals_cache: dict[str, list[float]] = {m: _vals(m) for m in _AGGREGATE_METRICS}

    # Build AC-21 per-metric dicts
    median_per_metric: dict[str, float | None] = {}
    p25_per_metric: dict[str, float | None] = {}
    p75_per_metric: dict[str, float | None] = {}
    sample_size_per_metric: dict[str, int] = {}
    warnings: list[str] = []
    errors: list[str] = []

    # Partial-cell warning when fewer than 10 valid rows (row-level partial)
    if is_partial and row_count_valid > 0:
        warnings.append(
            f"partial cell: only {row_count_valid} valid rows (< {_PARTIAL_THRESHOLD})"
        )

    for metric in _AGGREGATE_METRICS:
        vals = vals_cache[metric]
        effective_n = len(vals)
        sample_size_per_metric[metric] = effective_n

        # Cell-invalid: effective N < 3 — stats return None + ERROR.
        # Partial-cell WARN is SUPPRESSED when the ERROR fires (fw-review-code M-2:
        # dual-fire produced redundant signals for the same root cause).
        if effective_n < 3:
            median_per_metric[metric] = None
            p25_per_metric[metric] = None
            p75_per_metric[metric] = None
            errors.append(
                f"cell-invalid: {metric} has only {effective_n} valid samples (< 3)"
            )
        else:
            median_per_metric[metric] = _percentile(vals, 50)
            p25_per_metric[metric] = _percentile(vals, 25)
            p75_per_metric[metric] = _percentile(vals, 75)

            # Per-metric partial-cell WARN: effective N <= 0.7 * row_count_valid
            # (inclusive; 7/10 fires, 8/10 does not). Only considered when stats
            # are valid — cell-invalid path above already records an ERROR.
            if row_count_valid > 0 and effective_n <= 0.7 * row_count_valid:
                warnings.append(
                    f"partial cell: {metric} has {effective_n}/{row_count_valid} valid samples"
                )

    return CellSummary(
        wall_clock_ms=_metric_stats(vals_cache["wall_clock_ms"]),
        input_tokens=_metric_stats(vals_cache["input_tokens"]),
        output_tokens=_metric_stats(vals_cache["output_tokens"]),
        cost_usd=_metric_stats(vals_cache["cost_usd"]),
        acceptance_pct=_metric_stats(vals_cache["acceptance_pct"]),
        semgrep_high=_metric_stats(vals_cache["semgrep_high"]),
        semgrep_critical=_metric_stats(vals_cache["semgrep_critical"]),
        injected_bug_detections=_metric_stats(vals_cache["injected_bug_detections"]),
        is_partial=is_partial,
        n_complete=len(complete),
        n_aborted=len(aborted),
        median_per_metric=median_per_metric,
        p25_per_metric=p25_per_metric,
        p75_per_metric=p75_per_metric,
        sample_size_per_metric=sample_size_per_metric,
        row_count_total=row_count_total,
        row_count_valid=row_count_valid,
        warnings=warnings,
        errors=errors,
    )
