# Sherlock/Holmes/Hudson Methodology — MANDATORY

> Tiered workflow for AI-assisted development. Classifies task complexity and routes to the appropriate process: Hudson (quick fix), Sherlock Lite (medium), Full Sherlock (complex), or Holmes (execution of an approved plan). Includes spec-anchored development with structured Acceptance Criteria and Interface Contracts.

## Complexity Routing — Step 0

When the user describes a task (or types "sherlock", "hudson", or "holmes"), FIRST classify its complexity before choosing a workflow. Do this silently unless the user typed a specific keyword.

### Classification Method

0. **User-Preference Lens** (memory-aware routing): Before classifying, scan the already-loaded auto-memory (MEMORY.md is injected by Claude Code's harness, not something you read from disk). If any memory entry is clearly relevant to THIS task (e.g., a feedback entry about bundled PRs when the task is a doc refactor), emit as the FIRST line of your Step 0 output:
   ```
   User context: [1-3 memory entry TITLES in brackets, e.g., "[Bundle entangled doc refactors]"]
   ```
   If no memory entry is obviously relevant, emit `User context: none applicable`.

   **HARD LIMITS on the User context line**:
   - Cite at most **3 titles**.
   - Total line length **≤200 characters**.
   - **Single line only** — never span lines.

   **NO-PERSIST RULE (security-critical — ADR-007 bright-line sanitization)**:
   - The `User context:` line lives ONLY in the live conversation response.
   - NEVER write it into `.sherlock-plan.md`, `.test-matrix.md`, Decision Digest, Pivot Log, Lead Judgment, or any file in `.claude/state/`.
   - NEVER include it in any `Write`/`Edit` tool call content.
   - NEVER transcribe, quote, paraphrase, or reference MEMORY.md BODY content anywhere — not in conversation, not in artifacts, not in tool outputs. Body content means anything beyond the bracketed entry title.
   - If you need to reason about a memory entry, do so internally; in output, cite only the title.
   - Many MEMORY.md titles themselves encode strategy (e.g., pricing, revenue targets, platform risk). Treating titles as non-sensitive is incorrect in persisted contexts — this is why title citation is restricted to the live conversation stream.

1. **Identify affected files**: Use Glob/Grep to trace what will change. List them.
2. **Count and categorize**: How many files? Any risk multipliers?
3. **Apply risk multipliers** (each bumps the tier UP by one):
   - Database migrations or schema changes
   - Authentication/authorization logic
   - Payment/billing code (Stripe)
   - RLS policies
   - API contract changes (breaking)
   - Shared utility used by 5+ consumers
4. **Route to tier**:

| Tier | Files | Steps | Keyword | When |
|------|-------|-------|---------|------|
| **Hudson** | 1-2, no risk multipliers | 4 | `hudson` | Quick fixes, typos, simple additions |
| **Sherlock Lite** | 3-5, 0-1 risk multipliers | 6 | `sherlock` (auto) | Medium features, refactors |
| **Full Sherlock** | 6+ OR 2+ risk multipliers | 8 | `sherlock` (auto) | Large features, cross-cutting changes |

5. **Present ALL THREE options** to user with a recommendation:
   ```
   COMPLEXITY ASSESSMENT:
   Files affected: [list with reasons]
   Risk multipliers: [list or "none"]

   Choose your workflow:
   → 🏠 Hudson (4 steps) — Quick fix, minimal review [RECOMMENDED if 1-2 files / or not]
   → 🔍 Sherlock Lite (6 steps) — Plan + TDD + targeted review [RECOMMENDED if 3-5 files / or not]
   → 🔍 Full Sherlock (8 steps) — Research + architecture + full review pipeline [RECOMMENDED if 6+ files / or not]

   My recommendation: [tier] because [1-2 sentences]
   ```
   Mark exactly ONE option as RECOMMENDED based on classification. Always show all three.

6. **Optional /deep-r at Step 0**: If the task involves unfamiliar technology, competitive positioning, or a strategic "should we even build this?" question, invoke `/deep-r` before classification to establish the problem space. Example: landscape analysis of competitor install flows, current state of an API or ecosystem. Skip for well-understood domains.

7. **Escape hatches** (mid-execution promotion):
   - Mid-Hudson discovers more files → STOP: "Promoting to Sherlock Lite — [evidence]"
   - Mid-Lite discovers 6+ files or 2+ multipliers → STOP: "Promoting to Full Sherlock — [evidence]"

---

## 🏠 HUDSON MODE (Quick Fix — 4 Steps)

When the user types "hudson" OR Step 0 classifies as Hudson:

1. **Explore & Confirm** — Read the 1-2 files. Confirm the change is contained. If it touches more, promote.
2. **Implement with Tests** — If the file is a testable implementation file:
   - Write/update test first (RED), then implement (GREEN). Inline — no subagents needed for simple changes.
   - If no test needed (config, docs, CSS, types), just implement.
3. **Quick Review** — Run **fw-review-code** agent only. Fix any Critical/High.
4. **Commit** — Ask: "Create a branch, or commit to current?" Follow standard git conventions. Run `/release-notes` if creating a PR.
   - **Workspace Hygiene check**: Before committing, recall whether this session used the `Write` or `Edit` tool on any path under a gitignored prefix (e.g., `private/`, `tmp/`, `scratch/`). Such files will NOT appear in `git diff` (they are untracked by design), so the check is conversation-context-driven, not git-driven. `git status --ignored --short` can list ignored files inside the worktree as a secondary cross-check. If durable working content is detected and the workspace is ephemeral, follow the recovery steps in `## Workspace Hygiene — Durable Writes in Ephemeral Workspaces` below.

**Hudson does NOT include:** plan mode, multi-agent review pipeline, architecture design, plan artifacts, research phase.

---

## 🔍 SHERLOCK LITE MODE (Medium — 6 Steps)

When Step 0 classifies as Sherlock Lite (3-5 files, 0-1 risk multipliers):

1. **Plan (Structured Spec Output)** — Use **Plan** agent. Explore affected files. Create implementation plan with file:line references, approach summary, test strategy. No multi-option architecture (use the obvious approach). If a risk multiplier is present, invoke the relevant domain agent (e.g., **fw-advisor-architecture** for architecture, **fw-author-migration** for DB). If the task involves architectural decisions, present them to the user for approval before proceeding.
   - **Write Lead Judgment**: Priority Stack (3-5 bullets with reasoning — anti-snacking gate) + Risk Watch (≥1 specific risk tied to THIS changeset). No MEMORY.md body content.
   - **Write Acceptance Criteria**: Given/When/Then scenarios for expected behaviors (minimum: 1 happy path, 1 edge case, 1 error case). These drive the RED phase directly.
   - **Write Interface Contracts**: Type signatures and API shapes for any new interfaces being introduced. Omit for doc/config-only changes.
   - **Write `.sherlock-plan.md`** as the output of this step (before proceeding to Clarify): Use the Spec-Anchored format (see `.claude/spec-format.md`). For Lite, the Architecture Decision section is brief (single approach, short rationale).
   - **Invoke fw-author-test-strategy** after the plan is written, UNLESS the Planned Files table contains only `*.md`/`*.txt`/`*.rst` files — in which case emit `Test strategy skipped: doc-only change`. The agent writes `.test-matrix.md` to the project root, which fw-review-tests consumes at every review gate.
2. **Clarify** — Ask about genuine ambiguities. WAIT. If none: "No ambiguities — proceeding."
3. **TDD Implementation** — Use TDD subagents for each logical unit:
   - Invoke **fw-tdd-red** for RED phase (cognitively isolated — sees only requirements)
   - Invoke **fw-tdd-green** for GREEN phase (sees only failing tests)
   - Invoke **fw-tdd-refactor** for REFACTOR phase (sees both, keeps tests green)
   - For single-function changes, subagents optional — inline TDD is fine.
   - Run `/simplify` on changed code after REFACTOR.
4. **Per-Phase Review** — Run **fw-review-code** (always) + ONE relevant domain reviewer:
   - Tests → **fw-review-tests** (consumes `.test-matrix.md` if present — flags missing P0 tests as Critical)
   - DB → **fw-author-migration** (after `/schema-check`)
   - API → **fw-review-api-contracts**
   - UI → **fw-review-ux**
   - 3+ files → **fw-review-maintainability**
   - Fix Critical/High before proceeding.
   - **Append Decision Digest**: After consolidating review outputs, append a `### Phase N Review — YYYY-MM-DD` block to `## Decision Digest` in `.sherlock-plan.md` (Fired/Critical+High/Deferred/Inherited/Digest). Always write an entry — even zero findings.
5. **Final Gate** — Run the full parallel pipeline (see `sherlock-review-gate.md`): fw-review-code, fw-review-comments, fw-review-docs, fw-review-security, plus any domain reviewers relevant to the changeset.
   - **AC coverage check**: Verify all Acceptance Criteria (AC-#) from `.sherlock-plan.md` are covered by tests.
   - **MATH-VERIFY-FLAG check**: For every `MATH-VERIFY-FLAG` emitted by a reviewer attached to a Critical or High finding, invoke `/verify-math` on the expression before commit, or downgrade the quantitative claim to qualitative (see `sherlock-review-gate.md` → "MATH-VERIFY-FLAG Protocol").
   - Only commit after no Critical issues.
6. **Post-Commit (Doc Update + PR)** — Before creating PR, update documentation:
   - **Workspace Hygiene check**: Recall whether this session wrote under any gitignored prefix (these files won't appear in `git diff`). Cross-check with `git status --ignored --short`. If durable working content is in an ephemeral workspace, follow the recovery steps in `## Workspace Hygiene — Durable Writes in Ephemeral Workspaces`.
   - Update `CLAUDE.md` version description if this is a version-worthy change
   - Update `release_notes.md` with change summary
   - Update `CHANGELOG.md` with Keep a Changelog entry
   - Update `docs/60-FEATURES.md` if new features added
   - Add insight to `docs/70-INSIGHTS.md` if a non-obvious design decision was made
   - Run `/release-notes` skill to generate PR body
   - `protocol-validator.py` will BLOCK PR creation if `release_notes.md` or `CHANGELOG.md` are stale

**Promotion trigger**: If you discover 6+ files or 2+ risk multipliers mid-Lite, STOP: "Promoting to Full Sherlock — [evidence]."

---

## 🔍 FULL SHERLOCK MODE (High Complexity — 8 Steps)

When the user types "sherlock" AND Step 0 classifies as Full (6+ files OR 2+ risk multipliers):

1. **Plan First (Structured Spec Output)** — Use the **Plan** agent to enter plan mode. Use the **Explore** agent to investigate thoroughly. Create a detailed plan. Do NOT make assumptions — verify every claim by reading source files, configs, and schemas.
   - **Structured exploration output required**: entry points with `file:line`, execution flow, key components, dependencies, and 5-10 essential files.
   - **Draft Acceptance Criteria**: Write Given/When/Then scenarios for the feature's expected behaviors. These become the spec that drives the RED phase.
   - **Draft Interface Contracts**: Define type signatures and API shapes for new interfaces being introduced.
   - If the task involves architectural decisions, present them to the user for approval before proceeding. Also invoke the **fw-advisor-architecture** agent.
2. **Clarifying Questions Gate** — Before proceeding, identify and ASK the user about: edge cases, integration points, design preferences, error handling strategy, and any ambiguities. WAIT for answers. Do not assume — ask.
3. **Research & Validate** — Invoke `/deep-r` to validate the approach against authoritative sources (official docs, RFCs, trusted engineering blogs). /deep-r spawns parallel research agents for independent topics, cross-references findings, and requires citations for all claims. This replaces ad-hoc web searches with structured, citation-hygiene-enforced research. Cite sources in the plan.
4. **Architecture Design** — Generate 2-3 competing approaches:
   - **Minimal**: smallest change, least risk
   - **Clean**: best design, may require more refactoring
   - **Pragmatic**: balanced trade-off (if distinct from the above)
   - Present trade-offs (complexity, risk, maintainability, performance) and form a recommendation.
   - If architectural decisions are involved, also invoke **fw-advisor-architecture** agent. Present architectural decisions to the user for approval before proceeding.
   - WAIT for user to choose an approach. Then update the plan.
   - **PLAN ARTIFACT**: After architecture is approved, write `.sherlock-plan.md` to the project root (see Spec-Anchored format below). Ensure Lead Judgment (Priority Stack + Risk Watch), Acceptance Criteria, and Interface Contracts sections are populated — these are the structured specs that drive TDD.
   - **OPTIONAL /deep-r**: For specific architectural decisions with ≥2 viable options and high reversal cost, invoke `/deep-r` on the specific decision point (not the whole architecture) to get evidence-backed validation. Example: "deep-r this licensing model" or "deep-r install vs update separation."
4.5. **Plan Validation** *(REQUIRED for Full Sherlock)* — After `.sherlock-plan.md` is written and architecture is approved, invoke `/deep-r` to red-team the plan. Specifically request: gap analysis, AC coverage review, missing edge cases, pattern validation against industry practice, security review. This is the cheapest place to catch plan-level bugs — before any code exists.
   - **What to ask**: "Validate this plan: [paste or reference .sherlock-plan.md]. Find missing edge cases, architectural risks, AC gaps, and security issues. Be adversarial."
   - **Optional parallel-lens variant** (for high-stakes plans — auth, payment, migrations, RLS, data-loss-prone paths): instead of one broad-scope `/deep-r`, run 2-3 in parallel, each scoped to a single lens. Example invocations: (a) "validate this plan with a security lens — threat-model only", (b) "validate this plan with a performance lens — hot-path and resource-cost only", (c) "validate this plan with a UX/operator lens — failure-mode visibility only". Each lens stays focused; correlated blind spots from a shared broad prompt are reduced. Total token cost is roughly the same as one broad pass; latency is lower (parallel). Adopt for plans where one missed dimension is expensive — skip when single-lens suffices. This is the strong-fit case for critique-select-style parallelism without the engineering cost of building a critic.
   - **Incorporate findings**: Update ACs, add edge cases, fix gaps in the plan before proceeding.
   - **For Sherlock Lite**: Optional but recommended when the plan touches patterns the team hasn't used before.
   - **Invoke fw-author-test-strategy** AFTER plan validation findings are incorporated (so the test matrix reflects the FINAL ACs, not pre-validation ones), UNLESS the Planned Files table contains only `*.md`/`*.txt`/`*.rst` files — in which case emit `Test strategy skipped: doc-only change`. The agent writes `.test-matrix.md` to the project root; fw-review-tests consumes it at every per-phase review gate. If Step 4.5 adds/changes ACs on a subsequent re-run, re-invoke fw-author-test-strategy to regenerate `.test-matrix.md` before Step 5.
   - **CONTEXT RELIEF**: Run `/compact` to free context before implementation begins.
5. **TDD Phases** — Implement using Test-Driven Development with cognitively isolated subagents:
   - **Phase 1 (RED)**: Invoke **fw-tdd-red** agent. It writes failing tests based ONLY on requirements and interfaces. For complex scenarios, also consult **fw-review-tests** for test design.
   - **Phase 2 (GREEN)**: Invoke **fw-tdd-green** agent. It sees ONLY failing tests and type signatures. Writes minimal implementation.
   - **Phase 3 (REFACTOR)**: Invoke **fw-tdd-refactor** agent. It sees code + tests, cleans up while keeping tests green. Run `/simplify` on changed code.
   - Break into logical phases (e.g., Phase 1: core logic, Phase 2: edge cases, Phase 3: integration) as appropriate.
   - **DESIGN-SYNC**: After each TDD sub-phase, compare `git diff --name-only` against `.sherlock-plan.md` planned files. Flag unplanned files or missing planned files. Also verify acceptance criteria coverage — each AC-# should map to at least one test. Log legitimate divergences in the Pivot Log. Run `python3 scripts/fw_conformance.py --plan .sherlock-plan.md --save` to generate and persist a conformance scorecard to `.context/metrics/conformance/`.
   - **CONTEXT RELIEF**: Run `/compact` after all TDD phases complete, before reviews.
6. **Multi-Agent Review Pipeline (Per Phase)** — Run RELEVANT reviewers in parallel based on what changed:
   - **fw-review-code** — ALWAYS run
   - **fw-review-tests** — when tests are written or modified (consumes `.test-matrix.md` if present — missing P0 tests = Critical, malformed matrix = Medium)
   - **fw-review-security** — when auth/RLS/secrets touched
   - **fw-review-performance** — when DB queries/React components/API endpoints changed
   - **fw-review-maintainability** — when refactoring or touching 3+ files
   - **fw-author-migration** — when database migrations created. ALWAYS run `/schema-check` skill BEFORE invoking fw-author-migration.
   - **fw-review-api-contracts** — when API endpoints added/modified
   - **fw-review-ux** — when UI components, layouts, forms, or data visualizations created/modified
   - **fw-review-error-handling** — when try/catch, error handling, or fallback logic touched
   - **fw-review-types** — when new types, classes, or models introduced
   - Fix all Critical/High issues before proceeding to next phase.
   - **Append Decision Digest**: After consolidating review outputs, append a `### Phase N Review — YYYY-MM-DD` block to `## Decision Digest` in `.sherlock-plan.md` (Fired/Critical+High/Deferred/Inherited/Digest). Always write an entry — even zero findings.
7. **Final Review Gate** — Run the full parallel review pipeline (see `sherlock-review-gate.md`):
   - **fw-review-code** (comprehensive final pass)
   - **fw-review-docs** (identify which docs need updating)
   - **fw-review-security** (final security scan)
   - **fw-review-comments** (comment accuracy, staleness, and value)
   - Plus any domain-specific reviewers relevant to the full changeset
   - If **fw-review-docs** identifies docs that need updating, invoke **fw-author-docs** to write/update those docs.
   - **DESIGN-SYNC (Final)**: Full comparison of `git diff --name-only` against `.sherlock-plan.md`. All planned files must be accounted for. All unplanned files must have Pivot Log entries. All Acceptance Criteria (AC-#) must be covered by tests. Report discrepancies to user.
   - **MATH-VERIFY-FLAG check**: For every `MATH-VERIFY-FLAG` emitted by a reviewer attached to a Critical or High finding (per-phase or final-gate), invoke `/verify-math` on the expression before commit, or downgrade the quantitative claim to qualitative (see `sherlock-review-gate.md` → "MATH-VERIFY-FLAG Protocol"). Record each verification in the Decision Digest.
   - Only commit after no Critical issues and no unaddressed High issues.
8. **Post-Commit (Doc Update + Spec Extraction)** — After committing, before creating PR:
   - **Workspace Hygiene check**: Recall whether this session wrote under any gitignored prefix (these files are untracked and won't appear in `git diff`). Cross-check with `git status --ignored --short` to enumerate them. If the workspace is ephemeral (use the detection snippet in `## Workspace Hygiene — Durable Writes in Ephemeral Workspaces`), follow the recovery steps before going further. This is the last reliable catch-point before the workspace is discarded.
   - **Update documentation** (protocol-validator.py will BLOCK PR creation if stale):
     - Update `CLAUDE.md` version description if this is a version-worthy change
     - Update `release_notes.md` with change summary
     - Update `CHANGELOG.md` with Keep a Changelog entry
     - Update `docs/60-FEATURES.md` if new features added
     - Add insight to `docs/70-INSIGHTS.md` if a non-obvious design decision was made
   - Run `/release-notes` skill to generate PR description from the git diff.
   - When creating a PR, include the generated release notes in the PR body.
   - **Extract ADR from `.sherlock-plan.md`** (if an Architecture Decision was made):
     1. Find the highest-numbered ADR in `docs/adr/`, increment by 1
     2. Create `docs/adr/NNN-short-title.md` using the standard template:
        - `Context` ← from plan's `Rationale` (why this decision was needed)
        - `Decision` ← from plan's `Approach chosen` + `Summary`
        - `Consequences → Positive` ← what becomes easier or better because of this approach (from `Architecture Decision → Summary`)
        - `Consequences → Negative` ← trade-offs, limitations, and what the rejected alternatives would have provided (from OUT OF SCOPE + non-chosen approaches)
        - `Consequences → Neutral` ← side effects that are neither clearly positive nor negative
     3. Set Status to `PROPOSED` (becomes `ACCEPTED` when PR merges)
     4. Add entry to `docs/adr/README.md` index table
     5. Create a follow-up commit to include the ADR (do NOT amend the previous commit)
   - **Delete `.sherlock-plan.md` AND `.test-matrix.md`** after extraction (execution artifacts like Pivot Log, Decision Digest, file lists, and the test matrix are not persisted — the shipped tests themselves are the record of coverage; the ADR captures rationale).
   - **Sherlock Lite**: ADR extraction is optional — only extract if the plan contained a non-trivial Architecture Decision (skip for single-approach, obvious plans).
   - **Optional /deep-r at Step 8**: For v1 launches, major version bumps, or public-facing changes, invoke `/deep-r` for release readiness validation (competitive positioning, deployment pattern review, missing documentation). Skip for minor patches and internal-only changes.

  **Key principles**: No assumptions (verify everything), no shortcuts (research before coding), no unreviewed code (multi-agent review every phase), no lost decisions (architecture decisions persist as ADRs).

### /deep-r Integration Summary

**/deep-r is a DECISION tool, not an EXECUTION tool.** It belongs in the planning/design phases (Steps 0–4.5) and at the verification boundary (Step 8). It does NOT belong in the implementation or review phases (Steps 5–7).

| Step | /deep-r Usage | Trigger |
|------|---------------|---------|
| **0** (Classification) | Optional | Unfamiliar tech, competitive positioning, strategic question |
| **2** (Clarifying Qs) | On-demand | User invokes `/deep-r <specific question>` mid-clarification |
| **3** (Research) | **Always** (Full Sherlock) | Automatic — this IS the research step |
| **4** (Architecture) | Conditional | ≥2 viable options with high reversal cost |
| **4.5** (Plan Validation) | **Always** (Full Sherlock) | After `.sherlock-plan.md` written, before coding |
| **5–7** (TDD + Reviews) | **Never** | Spec-driven + agent-driven; research here = context-switch antipattern |
| **8** (Post-Commit) | Optional | v1 launches, major versions, public-facing changes |

For Sherlock Lite: /deep-r at Steps 3 and 4.5 is optional but recommended when the plan touches unfamiliar patterns.

### Research-Enhanced Agents

Some review agents have embedded web research capability for domain-specific validation. See `sherlock-review-gate.md` → "Research-Enhanced Agents" for the full list and the `RESEARCH_NEEDED` flag protocol that all agents use to escalate uncertainty.

---

## `.sherlock-plan.md` Format (Spec-Anchored)

See [`.claude/spec-format.md`](.claude/spec-format.md) for the complete template and spec section guidelines. This file is the single source of truth for the plan format — referenced by `fw-tdd-red` and `fw-author-spec` agents.

---

## Workspace Hygiene — Durable Writes in Ephemeral Workspaces

Applies to Hudson, Sherlock Lite, Full Sherlock, Holmes — every workflow that may run inside a session worktree, devcontainer, Codespace, Docker volume, or CI runner.

### The rule

Before writing **durable working content** (drafts the next session expects to read — submission copy, contractor briefs, design notes, plan artifacts, scratch reasoning intended to outlive the session) to a **gitignored path** inside an **ephemeral workspace**, redirect the write to the main checkout (or to a path outside the repo entirely).

The rule does NOT apply to artifacts that are *expected* to be re-derived: build caches, `node_modules/`, language compile outputs, `actions/cache` paths, devcontainer tool installs. Those are correctly ephemeral and gitignored.

### Two orthogonal questions

Every file you create has two independent properties:

1. **"Is this in git?"** — exposure / collaboration question. Answered by `.gitignore`.
2. **"Will the filesystem this lives on be there next week?"** — persistence / durability question. Answered by where the file lives.

`.gitignore` is exposure control, not persistence control. A file can be gitignored AND lost on worktree cleanup at the same time — that is the failure mode this rule prevents. A file that gets "no" to git AND "yes" to filesystem (`private/` in the main checkout) is a perfectly valid working draft.

### Ephemeral-workspace detection

```bash
common_dir="$(git rev-parse --git-common-dir 2>/dev/null)"
git_dir="$(git rev-parse --git-dir 2>/dev/null)"
[ "$common_dir" != "$git_dir" ] && echo "session worktree"
```

Correct in spec. Three real edge cases the check must handle:

- **Submodules** — a submodule's `.git` is a file pointing into `$GIT_DIR/modules/<name>/`. Inside a submodule of a worktreed superproject, the discriminator returns "main checkout" (false negative). If `git rev-parse --show-superproject-working-tree` is non-empty, evaluate the superproject before deciding.
- **`GIT_DIR` env override** — with `GIT_DIR` exported and CWD inside a worktree, both rev-parse calls return the env value, so the discriminator reports "main checkout" in a directory that is physically a worktree. If `$GIT_DIR` is set with mismatched CWD, abstain rather than misclassify.
- **Git version** — `--git-common-dir` was broken in git ≤ 2.1.4 (returned the literal flag string) and is reliable from ~2.11.0 onward (pre-commit issue #831). Require git ≥ 2.11 or abstain.

### Recovery (if it already happened)

1. Copy the file to the main checkout's equivalent path (or a path outside the repo).
2. `git check-ignore -v <path>` to verify the destination's `.gitignore` covers it.
3. `md5` both copies to confirm byte-identical.
4. Optionally make a third copy outside the repo as backup.

### Honest limit on this rule

This rule is **documentation, not enforcement**. Published instruction-following accuracy for prompt-based rules drops to ~68% at high instruction density (IFScale, arXiv 2507.11538) and degrades for instructions placed mid-context (lost-in-the-middle, arXiv 2307.03172). CLAUDE.md and `.claude/rules/*.md` are delivered as user-context, not system prompt — compliance is probabilistic. Treat this rule as a hint that catches some incidents, not as a guarantee that prevents all of them.

A deterministic PreToolUse hook in `.claude/hooks/auto_approve_base.py` is the durable fix. **Build it when the failure recurs at N=3 incidents** (Rule of Three; Beck/Fowler). At N=1, the rule plus the workflow-step cross-references below is the deferred-cost option.

### Generalization

The shape is *ephemeral workspace + gitignored path + durable-content expectation*, not *ephemeral workspace + any gitignored write*. The rule applies wherever a workspace can vanish without a commit:

- `git worktree add` (any user — not just Claude)
- Devcontainers when their lifecycle does not survive what you wrote (i.e., the source-of-truth lives outside the container)
- GitHub Codespaces ("lifecycle-tied storage" outside `/workspaces`)
- Docker volumes that are not bind-mounted or persistent
- CI/CD runners (workspace destroyed at job end)

Build caches and tool installs are correctly ephemeral and outside the rule's scope.

---

## 🎩 HOLMES MODE (Execution)

When the user types "holmes", this is the GO signal to execute a Sherlock plan:

1. **Verify Plan Exists** — If no Sherlock plan exists in this session, warn: "No approved plan found. Run `sherlock` first to create and approve a plan, then `holmes` to execute it."
2. **Create Branch** — Create a feature branch with a descriptive name based on the approved plan (e.g., `feature/add-widget-caching`, `fix/auth-token-refresh`). Ask the user to confirm the branch name before creating.
3. **Begin Implementation** — Execute the approved Sherlock plan using the classified tier's steps:
   - **Sherlock Lite tasks**: Follow the 6-step Lite workflow
   - **Full Sherlock tasks**: Follow the 8-step Full workflow
   - **Hudson tasks do NOT use Holmes** (too lightweight — Hudson is self-contained)
   - If a `.sherlock-plan.md` exists, load it and use it for design-sync throughout.
   - **Promotion still applies**: If complexity grows during execution, announce and promote.
4. **Domain Agent Invocation** — During implementation, proactively invoke domain-specific agents (IN ADDITION to the per-phase review pipeline):
   - DB work → `/schema-check` skill first, then **fw-author-migration** agent
   - API work → **fw-review-api-contracts** (validate contracts)
   - UI work → **fw-review-ux** (review usability, accessibility, interaction states)
   - AI/LLM work → **fw-advisor-architecture** (evaluate model choices, prompt design, cost)
   - Complex tests → **fw-review-tests** (design test strategy, review coverage)
5. **Deployment Readiness** — When the user wants to deploy after Holmes completes:
   - Run `/deploy` skill (tiered deployment checklist)
   - Run `/health` skill to verify production status after deploy
   - Invoke **fw-advisor-release** agent for deployment guidance if needed

---

## Agent Teams Mode

When `orchestration.mode: agent-teams` is set in `config/framework.yaml`, the Sherlock/Holmes workflow adapts to use Agent Teams' task-based orchestration with dependency chains. This requires Claude Code v2.1.32+ and `CLAUDE_CODE_EXPERIMENTAL_AGENT_TEAMS=1`.

### Mode Detection

Check `config/framework.yaml` → `orchestration.mode`. If `"subagent"` (default), use the standard workflow above. If `"agent-teams"`, apply the adaptations below.

### What Changes

| Step | Subagent Mode (default) | Agent Teams Mode |
|------|------------------------|-----------------|
| Steps 1-3 (Plan/Clarify/Research) | Lead does directly | **No change** — lead does directly |
| Step 4 (Architecture) | Spawn fw-advisor-architecture | Create task for fw-advisor-architecture teammate |
| Step 5 (TDD) | Spawn RED→GREEN→REFACTOR sequentially | Create 3 tasks with `blockedBy` chain |
| Step 6 (Per-Phase Review) | Spawn N reviewers in parallel | Create N parallel tasks, all `blockedBy` last TDD task |
| Step 7 (Final Gate) | Spawn all gate reviewers in parallel | Create parallel tasks, all `blockedBy` per-phase reviews |
| Step 8 (Post-Commit) | Lead does directly | **No change** — lead does directly |

### TDD Task Chain (Step 5)

Create three sequential tasks with dependency enforcement:

```
Task 1: fw-tdd-red
  subject: "Write failing tests from acceptance criteria (RED)"
  description: Include AC references and interface contracts ONLY.
               DO NOT include implementation file paths or requirement prose.
  blockedBy: [] (or architecture task if Step 4 ran)

Task 2: fw-tdd-green
  subject: "Write minimal implementation to pass tests (GREEN)"
  description: Include ONLY the test file path(s) from Task 1.
               DO NOT include .sherlock-plan.md content or requirement prose.
  blockedBy: [Task 1 ID]

Task 3: fw-tdd-refactor
  subject: "Refactor implementation while keeping tests green (REFACTOR)"
  description: Include both test and implementation file paths.
  blockedBy: [Task 2 ID]
```

**Cognitive isolation is enforced by task descriptions**: RED's description contains only specs, GREEN's contains only test paths. The `blockedBy` chain prevents out-of-order execution.

### Review Pipeline as Tasks (Steps 6-7)

Use `python3 scripts/cost_routing.py --mode agent-teams --predecessor-task <LAST_TDD_TASK_ID>` to generate task definitions. The output includes `tasks` with correct `blockedBy` fields.

For the final gate, add `--final-gate`:
```bash
python3 scripts/cost_routing.py --mode agent-teams --final-gate --predecessor-task <LAST_REVIEW_TASK_ID>
```

### Configuration

Settings in `config/framework.yaml` under `orchestration.agent_teams`:
- `max_concurrent_teammates`: Limit parallel teammates (default: 4)
- `tdd_chain`: `"sequential"` enforces RED→GREEN→REFACTOR via blockedBy (default)
- `review_parallelism`: Max simultaneous review tasks (default: 5)
- `task_timeout_minutes`: Per-task timeout (default: 30)

### Conflict Resolution

Same protocol as subagent mode (see `sherlock-review-gate.md`). The lead collects all completed task results, applies the severity hierarchy and domain authority table, and resolves conflicts. If unresolvable after 2 rounds, escalate to user.
