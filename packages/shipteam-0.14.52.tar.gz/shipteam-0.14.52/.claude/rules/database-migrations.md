---
paths:
  - "backend/database/**"
  - "migrations/**"
  - "**/migrations/**"
---

# Database/Migration Protocol -- MANDATORY

**BEFORE touching ANY migration file or writing SQL:**

## Step 1: Verify Schema (ALWAYS)
```bash
# Find table creation
grep -A50 "CREATE TABLE.*<table_name>" migrations/*.sql

# Verify columns exist in codebase
grep -r "<column_name>" app/ --include="*.py" | head -10
```

## Step 2: Document What You Found
```python
# Example:
# Schema check for 'users' table:
# - email: TEXT (not VARCHAR)
# - status: TEXT with CHECK constraint
# - NO is_active column exists
```

## Step 3: Write SQL (Only After Schema Verified)

**Common Mistakes to Avoid**:
- Guessing column names -> "column does not exist" error
- `CREATE INDEX CONCURRENTLY` -> "cannot run inside transaction block"
- JSONB in WHERE clause -> "functions must be IMMUTABLE"
- Assuming constraints match across tables -> CHECK constraint violation

**Solutions**:
- Always grep schema first (30 seconds prevents 10 minutes of trial-and-error)
- Remove CONCURRENTLY keyword for transactional migrations
- Remove WHERE clause from JSONB expression indexes
- Verify enum/constraint for EACH table -- they may differ

**Enforcement**: If you edit a migration without showing schema verification, user will reject it.
