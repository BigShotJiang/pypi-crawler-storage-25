# Claude Settings Guide

Companion documentation for Claude Code settings files.

## Settings Files

The framework uses two settings files with distinct purposes:

| File | Purpose | Git Status |
|------|---------|------------|
| `.claude/settings.json` | **Shared hooks** -- team-wide safety gates and lifecycle hooks | Committed (shared) |
| `.claude/settings.local.json` | **Personal permissions** -- individual allow/deny tool patterns | Gitignored (personal) |

### Why Two Files?

- **Hooks are team policy**: Safety gates (blocking force pushes, dangerous SQL, branch deletion) should be consistent across all developers. These live in `settings.json` and are version-controlled.
- **Permissions are personal preference**: Which commands you auto-approve depends on your comfort level and workflow. These live in `settings.local.json` and are gitignored.

### Safety Gate Behavior

The `auto-approve.py` hook uses exit code 2 to **hard block** dangerous operations. Unlike exit code 0 (which falls through to the normal permission prompt), exit code 2 prevents the command entirely -- even if the user has auto-approved the tool pattern.

**Blocked patterns** (exit code 2):
- `rm -rf` on project/system paths (backend, frontend, docs, .git, ~/, ../)
- `git push --force` / `git push -f`
- `DROP TABLE/DATABASE/SCHEMA`
- `TRUNCATE`
- `DELETE FROM` without `WHERE` clause
- `git reset --hard`
- `git branch -d` / `git branch -D`
- `gh pr merge --delete-branch`

**Fall-through patterns** (exit code 0 -- user prompted):
- `DELETE FROM ... WHERE ...` (has a WHERE clause)
- `git rebase`
- `git commit` / `git push` (normal)
- `sudo` commands

## Permission Model

Claude Code uses three permission levels for tool access:

| Level | Behavior | Use For |
|-------|----------|---------|
| `allow` | Auto-approved, no prompt | Safe read-only commands, project scripts |
| `deny` | Blocked entirely | Dangerous commands, secret file access |
| (unlisted) | Prompts user for approval | Everything else (default) |

## Allow Patterns

Patterns use glob syntax. Examples:
- `Bash(git *)` -- All git commands
- `Bash(./scripts/*)` -- All project scripts
- `Read(*)` -- Read any file
- `Bash(npm test)` -- Specific command only

### Recommended Allow List
```json
"allow": [
  "Bash(git *)",        // Version control
  "Bash(gh *)",         // GitHub CLI
  "Bash(ls *)",         // Directory listing
  "Bash(pwd)",          // Current directory
  "Bash(cat *)",        // File reading
  "Bash(head *)",       // File preview
  "Bash(tail *)",       // File tail
  "Bash(grep *)",       // Content search
  "Bash(find *)",       // File search
  "Bash(which *)",      // Binary lookup
  "Bash(echo *)",       // Output
  "Bash(wc *)",         // Word/line count
  "Bash(diff *)",       // File comparison
  "Bash(sort *)",       // Sorting
  "Bash(./scripts/*)",  // Project scripts
  "Read(*)",            // Read tool
  "Grep(*)",            // Grep tool
  "Glob(*)",            // Glob tool
  "WebFetch(*)",        // Web fetching
  "WebSearch(*)"        // Web search
]
```

## Deny Patterns

Deny patterns block commands entirely. These protect against accidental destructive operations and secret exposure.

### Recommended Deny List
```json
"deny": [
  "Bash(rm -rf /)",         // Catastrophic deletion
  "Read(.env*)",             // Environment secrets
  "Read(*.pem)",             // SSL certificates
  "Read(*.key)",             // Private keys
  "Read(*.secret)",          // Secret files
  "Read(credentials.json)"  // Credential files
]
```

### Why Deny Patterns Matter

Even with a well-configured allow list, deny patterns add defense-in-depth:
- **Prevent accidental exposure**: Claude won't read secret files even if asked
- **Block catastrophic commands**: Destructive operations are blocked at the tool level
- **Complement .gitignore**: .gitignore prevents commits; deny prevents reading

## Hooks

Hooks run custom scripts at specific lifecycle points:

| Hook Type | When It Fires | Use For |
|-----------|---------------|---------|
| `PreToolUse` | Before a tool executes | Blocking dangerous commands, auto-approval |
| `PostToolUse` | After a tool executes | Warnings, logging, state tracking |
| `UserPromptSubmit` | When user sends a message | Branch validation, conflict detection |
| `PreCompact` | Before context compaction | Saving state for session continuity |

### Hook Response Format

PreToolUse hooks must output JSON with `hookSpecificOutput`:
```json
{
  "hookSpecificOutput": {
    "hookEventName": "PreToolUse",
    "permissionDecision": "allow",
    "permissionDecisionReason": "Safe read-only command"
  }
}
```

To block a command, output to stderr with `"permissionDecision": "deny"` and exit code 2.

**Exit code semantics**:
- Exit code 0 = continue (approve if JSON output present, else fall through to normal permission)
- Exit code 2 = block the command (overrides matching allow patterns)
- Other non-zero = hook error (logged but not blocking)

> **Note**: PreToolUse hooks fire before permission evaluation. An exit code 2 block overrides any matching allow patterns in settings. This is an architectural assumption based on Claude Code hook execution order -- verify against your SDK version if behavior seems unexpected.

## Auto Mode (Research Preview)

Claude Code's **auto mode** replaces human approval with an AI classifier (Sonnet 4.6) that evaluates each action for scope deviation, target trustworthiness, and prompt injection before approving or blocking.

> **Note**: Research Preview as of March 2026. Behavioral details may change — verify with `claude auto-mode config`.

### Permission Modes

| Mode | Approves | Prompts For | Best For |
|------|----------|-------------|----------|
| `plan` | Nothing | Everything (read-only) | Exploring before deciding |
| `default` | Nothing | All bash + edits | Sensitive work, full oversight |
| `acceptEdits` | File edits | Bash commands | Code iteration with review |
| `auto` | Most actions | Nothing (classifier checks) | Long sessions, less friction |
| `dontAsk` | Pre-approved only | Denies all others | CI pipelines |
| `bypassPermissions` | Everything | Nothing (no checks) | Isolated containers only |

### Hook Interaction

PreToolUse hooks run BEFORE the classifier (verify against your SDK version):

- Hook exit 2 → **hard block** (overrides auto mode)
- Hook exit 0 + approval JSON → **auto-approved** (skips classifier)
- Hook exit 0, no JSON → **falls through** to classifier

The framework's safety gates (`auto_approve_base.py`) remain effective in auto mode. Auto mode also blocks `curl | bash`, force push, push to `main`, production deploys, and mass deletion by default. It auto-approves local file ops, dependency installs from lockfiles, read-only HTTP, and pushing to your branch.

**Caveats**: Auto mode reportedly strips broad allow rules (`Bash(git *)`, `Bash(python*)`) from settings while active — narrow rules like `Bash(npm test)` carry over. A circuit breaker (~3 consecutive or ~20 total blocks) pauses auto mode and resumes standard prompting.

### Configuration

Toggle with `Shift+Tab` in the CLI. Or set in `settings.local.json` (gitignored — never set in committed `settings.json`):

```json
{
  "permissions": { "defaultMode": "auto" },
  "autoMode": {
    "environment": [
      "Organization: YourOrg. Source control: github.com/your-org",
      "Trusted internal domains: *.internal.yourorg.com"
    ]
  }
}
```

The `autoMode.environment` key configures trusted infrastructure (only read from user-level or project-local settings, never committed). Verify with `claude auto-mode config` after adding — misspelled keys produce no error.

### Guidance

**Good fit**: Long Sherlock/Holmes sessions, routine development (hooks still protect you).
**Do not use**: Deployments, migrations, security-sensitive work (auth, RLS). Use `dontAsk` for CI.
**Cost**: Classifier adds token cost (Sonnet 4.6) and latency per action. Read-only and local edits skip the classifier.

**Framework recommendation**: Supported but not the default. The framework's hook-based safety gates are deterministic and auditable. Auto mode adds a probabilistic layer on top — use it for less friction, not as a replacement for hooks.

## Stack-Specific Additions

Add language/framework-specific commands to your allow list:

### Python
```json
"Bash(python3 *)", "Bash(pytest *)", "Bash(pip *)"
```

### Node.js
```json
"Bash(npm *)", "Bash(npx *)", "Bash(node *)"
```

### Go
```json
"Bash(go *)"
```

### Docker
```json
"Bash(docker *)", "Bash(docker-compose *)"
```
