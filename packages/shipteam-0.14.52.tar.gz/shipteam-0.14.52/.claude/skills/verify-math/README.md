# verify-math

Symbolic and numeric math verification skill.

## Citation Sources

- **NIST DLMF** — Digital Library of Mathematical Functions: https://dlmf.nist.gov/
- **IEEE 754-2019** — Floating-Point Arithmetic Standard
- **SEMATECH e-Handbook** — Statistical Methods: https://www.itl.nist.gov/div898/handbook/

## Usage

```bash
python3 .claude/skills/verify-math/verify.py "integrate(x**2, x)"
python3 .claude/skills/verify-math/verify.py "sqrt(2) * pi" --source=all
python3 .claude/skills/verify-math/verify.py "sin(pi)" --domain=calculus
```

## Dependencies

```bash
uv pip install sympy numpy
```
