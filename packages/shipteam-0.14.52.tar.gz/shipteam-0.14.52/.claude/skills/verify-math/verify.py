#!/usr/bin/env python3
"""Math verification skill — symbolic + numeric cross-check via sympy and numpy."""

import ast
import json
import os
import pathlib
import sys
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import List, Optional, Tuple

# ---------------------------------------------------------------------------
# sys.path bootstrap so fw_event_log can be imported
# ---------------------------------------------------------------------------

_SCRIPTS = pathlib.Path(__file__).resolve().parent.parent.parent.parent / "scripts"
if str(_SCRIPTS) not in sys.path:
    sys.path.insert(0, str(_SCRIPTS))

try:
    from fw_event_log import append_event as _append_event
except ImportError:
    _append_event = None

# ---------------------------------------------------------------------------
# Optional heavy deps — fail-closed on CLI if missing
# ---------------------------------------------------------------------------

try:
    import sympy
    from sympy.parsing.sympy_parser import parse_expr
    import numpy as np
    _DEPS_AVAILABLE = True
except ImportError:
    _DEPS_AVAILABLE = False


# ---------------------------------------------------------------------------
# Result type
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class VerifyResult:
    inputs: str
    method: str
    symbolic_result: Optional[str]
    numeric_result: Optional[float]
    independent_check: str
    authoritative_reference: str
    caveats: List[str]
    ok: bool


# ---------------------------------------------------------------------------
# Input sanitization — AST pre-filter and input cap.
#
# SymPy's `parse_expr` internally invokes `eval` on transformed tokens, and its
# default `global_dict` exposes Python `__builtins__`. That means a raw string
# like `__import__('os').system('echo pwned')` will EXECUTE during parsing.
# Before the string reaches `parse_expr`, we walk its AST and reject anything
# outside a strict whitelist of arithmetic node types and known names. This is
# the security boundary; parse_expr is not trusted with untrusted input.
# ---------------------------------------------------------------------------

_MAX_EXPRESSION_LEN = 1024

_ALLOWED_AST_NODES: tuple = (
    ast.Expression,
    ast.BinOp,
    ast.UnaryOp,
    ast.Constant,
    ast.Name,
    ast.Call,
    ast.Load,
    ast.Add,
    ast.Sub,
    ast.Mult,
    ast.Div,
    ast.Pow,
    ast.Mod,
    ast.USub,
    ast.UAdd,
    ast.FloorDiv,
)

_ALLOWED_NAMES: frozenset = frozenset(
    {"sqrt", "pi", "exp", "log", "sin", "cos", "tan",
     "integrate", "x", "y", "z", "n", "e", "E",
     # Phase 4 (REC 5a SAFE-tier per /deep-r A1 verdict): no new AST nodes
     # required. factorial is deliberately deferred to Stage 5b (NEEDS-GUARD —
     # arg cap). Sum/Product/comparison/logical/Matrix are deferred entirely.
     "gamma", "erf", "floor", "ceil", "Min", "Max"}
)


#: Cap on integer constants (blocks `2**99999` DoS — the `99999` literal).
_MAX_INT_CONSTANT = 10_000


#: SymPy types that signal "couldn't reduce to a closed form." Stringifying
#: such an object as the verification result is silent corruption — the caller
#: sees a stringified expression and assumes verification succeeded. Defined
#: at module scope so the type set is visible from the top of the file.
_UNEVAL_TYPES: tuple = ()
if _DEPS_AVAILABLE:
    _UNEVAL_TYPES = (sympy.Sum, sympy.Integral, sympy.Limit, sympy.Order)


def _prevalidate_expression(expression: str) -> Optional[str]:
    """Walk the AST and return None if safe, otherwise a rejection reason.

    Blocks: attribute access (`.`), subscript (`[]`), starred args, comprehensions,
    lambdas, strings, unknown identifiers, any node type outside the whitelist,
    and integer literals large enough to trigger DoS via exponentiation (e.g.
    `2**99999` produces a 30k-digit int that locks the parser for ~minutes).
    """
    try:
        tree = ast.parse(expression, mode="eval")
    except SyntaxError as exc:
        return f"syntax error: {exc}"

    for node in ast.walk(tree):
        if not isinstance(node, _ALLOWED_AST_NODES):
            return f"disallowed AST node: {type(node).__name__}"
        if isinstance(node, ast.Name) and node.id not in _ALLOWED_NAMES:
            return f"disallowed name: {node.id}"
        if isinstance(node, ast.Constant):
            if not isinstance(node.value, (int, float, complex)):
                return f"disallowed constant type: {type(node.value).__name__}"
            if isinstance(node.value, int) and abs(node.value) > _MAX_INT_CONSTANT:
                return f"integer constant exceeds cap ({_MAX_INT_CONSTANT})"
    return None


# ---------------------------------------------------------------------------
# Domain references
# ---------------------------------------------------------------------------

_DOMAIN_REFS: dict[str, str] = {
    "general": "NIST DLMF (https://dlmf.nist.gov/) + SEMATECH e-Handbook",
    "calculus": "NIST DLMF (https://dlmf.nist.gov/) + SEMATECH e-Handbook",
    "statistics": "NIST SEMATECH e-Handbook of Statistical Methods (https://www.itl.nist.gov/div898/handbook/)",
    "numerical": "IEEE 754-2019 Floating-Point Standard + NIST DLMF",
}


# ---------------------------------------------------------------------------
# Wolfram opt-in (REC 4 from /deep-r plans/5031d8fa65ae.md)
#
# Wolfram is gated entirely on WOLFRAM_APP_ID. The free tier is documented as
# 2,000 non-commercial calls/month BUT the vendor reserves the right to adjust
# at discretion (FAQ verbatim) — never make Wolfram a load-bearing path.
# Stdlib urllib.request is the fit-for-purpose HTTP client (single endpoint,
# no streaming) — we deliberately do NOT add `requests` or `httpx`.
# ---------------------------------------------------------------------------

#: Threshold at which we start emitting WOLFRAM-QUOTA-WARN on stderr.
#: Vendor states 2,000 calls/month free; warn at 80% so users notice before hitting cap.
_WOLFRAM_QUOTA_WARN_THRESHOLD = 1600
_WOLFRAM_QUOTA_TOTAL = 2000

#: Wolfram LLM API endpoint per https://products.wolframalpha.com/llm-api/documentation
_WOLFRAM_LLM_API_URL = "https://www.wolframalpha.com/api/v1/llm-api"


def _wolfram_call_counter_path() -> pathlib.Path:
    """Project-local counter location matching scripts/fw_event_log.py's `.context/metrics/`
    pattern. Per Sherlock Lite Step 2 Q-A decision: gitignored, sandboxable in CI,
    survives `uvx` ephemeral-env weirdness that `~/.shipteam/` would not."""
    return pathlib.Path.cwd() / ".context" / "metrics" / "wolfram_calls.json"


def _wolfram_increment_call_counter() -> int:
    """Bump the call count for the current YYYY-MM month and return the new value.

    File format: ``{"YYYY-MM": <int>, ...}``. New months get a fresh entry;
    historical months stay readable (so a /retro can see usage trends).

    Returns 1 on first-ever call (file created, current month set to 1).
    Returns 0 if the counter file cannot be read OR written — this is the
    safety bottom: never fail verification on counter-persistence problems
    AND never silently overwrite an unreadable file (which would reset the
    month count to 1 and lose history).

    Concurrency: read-modify-write is NOT atomic. Concurrent verify.py
    invocations may lose increments. Acceptable for quota-warn purposes;
    the warn fires at ">1600/2000" — a few missed counts shifts the warn
    by a few calls, no user-visible damage. NOT suitable for billing.
    """
    month_key = datetime.now(timezone.utc).strftime("%Y-%m")
    path = _wolfram_call_counter_path()
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        if path.exists():
            try:
                data = json.loads(path.read_text())
                if not isinstance(data, dict):
                    data = {}
            except (json.JSONDecodeError, OSError):
                # Read failed — do NOT fall through and write a fresh `{}`,
                # which would reset the month count to 1 and lose history.
                # Return 0 so the caller's quota-warn check stays quiet on
                # bad data (silence > false-confidence).
                return 0
        else:
            data = {}
        data[month_key] = int(data.get(month_key, 0)) + 1
        path.write_text(json.dumps(data))
        return data[month_key]
    except OSError:
        # Write-side OSError: counter persistence is best-effort; never fail
        # verification on disk errors. Return 0 → no quota warn this call.
        return 0


def _wolfram_query(
    expression: str, app_id: str, timeout: float = 5.0
) -> Tuple[Optional[str], Optional[str]]:
    """Query the Wolfram LLM API. Returns ``(result_text, error_message)``.

    On success: ``(text, None)``. On any failure (network, non-200, timeout):
    ``(None, "<reason>")``. The caller emits ``WOLFRAM-UNAVAILABLE: <reason>``
    as a visible caveat and continues — Wolfram is corroboration, never the
    sole source of truth.

    No retry on failure: per /deep-r State 2, quota exhaustion is non-transient
    and retrying burns more calls. The fail-closed posture is by design.
    """
    qs = urllib.parse.urlencode({"appid": app_id, "input": expression, "maxchars": 1024})
    url = f"{_WOLFRAM_LLM_API_URL}?{qs}"
    try:
        # nosemgrep: python.lang.security.audit.dynamic-urllib-use-detected.dynamic-urllib-use-detected
        with urllib.request.urlopen(url, timeout=timeout) as resp:  # nosec B310 — URL is fixed HTTPS host (_WOLFRAM_LLM_API_URL constant), only query params are dynamic
            if resp.status != 200:
                return None, f"HTTP {resp.status}"
            return resp.read().decode("utf-8", errors="replace"), None
    except urllib.error.HTTPError as exc:
        # 403 (invalid AppID), 429 (quota — though Wolfram doesn't publicly document 429)
        return None, f"HTTP {exc.code}: {exc.reason}"
    except urllib.error.URLError as exc:
        return None, f"URLError: {exc.reason}"
    except Exception as exc:  # noqa: BLE001 — fail-closed on ANY unforeseen network issue
        return None, f"{type(exc).__name__}: {exc}"


# ---------------------------------------------------------------------------
# Core implementation
# ---------------------------------------------------------------------------

def verify(
    expression: str,
    *,
    domain: str = "general",
    source: str = "all",
    tolerance: float = 1e-9,
) -> VerifyResult:
    """Verify a mathematical expression symbolically and/or numerically."""
    if not _DEPS_AVAILABLE:
        raise ImportError("sympy and numpy are required. Install with: uv pip install sympy numpy")

    caveats: list[str] = []
    symbolic_result: str | None = None
    numeric_result: float | None = None
    independent_check: str = "N/A"
    ok: bool = False
    sources_used: list[str] = []

    authoritative_reference = _DOMAIN_REFS.get(domain, _DOMAIN_REFS["general"])

    # Defense-in-depth input cap — keeps SymPy's parser off pathological inputs
    # and blocks "attribute smuggling" through very long crafted strings.
    if len(expression) > _MAX_EXPRESSION_LEN:
        caveats.append(f"expression exceeds {_MAX_EXPRESSION_LEN} chars")
        return VerifyResult(
            inputs=expression[:200] + "...",
            method=f"source={source}",
            symbolic_result=None,
            numeric_result=None,
            independent_check="N/A",
            authoritative_reference=authoritative_reference,
            caveats=caveats,
            ok=False,
        )

    # Sympy local dict for parse_expr. The dict scopes name resolution so only
    # these symbols/functions are visible — unknown names become Function stubs
    # or raise. Default transformations (standard_transformations) are used, not
    # "all", because "all" enables implicit-multiplication + split-symbols which
    # widen the parser's surface without adding needed capability.
    local_dict = {
        "integrate": sympy.integrate,
        "sqrt": sympy.sqrt,
        "pi": sympy.pi,
        "exp": sympy.exp,
        "log": sympy.log,
        "sin": sympy.sin,
        "cos": sympy.cos,
        "tan": sympy.tan,
        # `e` and `E` were in _ALLOWED_NAMES but not bound here — without these
        # entries `e**(I*pi)` and `log(e)` silently resolve `e` as a free symbol
        # instead of Euler's number. Both lowercase and uppercase share sympy.E.
        "e": sympy.E,
        "E": sympy.E,
        # Phase 4 (REC 5a) — note SymPy uses `ceiling`, not `ceil`; the
        # user-facing name `ceil` maps to it. Min/Max are SymPy variadic.
        "gamma": sympy.gamma,
        "erf": sympy.erf,
        "floor": sympy.floor,
        "ceil": sympy.ceiling,
        "Min": sympy.Min,
        "Max": sympy.Max,
        "x": sympy.Symbol("x"),
        "y": sympy.Symbol("y"),
        "z": sympy.Symbol("z"),
        "n": sympy.Symbol("n"),
    }

    # --- AST pre-filter (security boundary) ---
    # parse_expr invokes eval internally with builtins accessible; the AST walk
    # must reject dunder attribute access, subscripts, lambdas, string literals,
    # and unknown names BEFORE the string reaches parse_expr.
    rejection = _prevalidate_expression(expression)
    if rejection is not None:
        caveats.append(f"expression rejected: {rejection}")
        return VerifyResult(
            inputs=expression,
            method=f"source={source}",
            symbolic_result=None,
            numeric_result=None,
            independent_check="N/A",
            authoritative_reference=authoritative_reference,
            caveats=caveats,
            ok=False,
        )

    # --- Parse (safe now that AST filter has passed) ---
    # Catch broad exceptions (ValueError, OverflowError, MemoryError,
    # RecursionError) so pathological but syntactically valid inputs produce
    # a clean ok=False result instead of propagating uncaught to the caller.
    parsed_expr = None
    try:
        parsed_expr = parse_expr(expression, local_dict=local_dict)
        if isinstance(parsed_expr, sympy.Integral):
            parsed_expr = parsed_expr.doit()
        if not isinstance(parsed_expr, sympy.Basic):
            caveats.append(
                f"parse produced non-SymPy type: {type(parsed_expr).__name__}"
            )
            parsed_expr = None
    except (
        ValueError,
        OverflowError,
        MemoryError,
        RecursionError,
        ArithmeticError,
        TypeError,
    ) as exc:
        caveats.append(f"sympy parse error: {type(exc).__name__}: {exc}")
    except Exception as exc:
        caveats.append(f"sympy parse error: {exc}")

    # --- Unevaluated-form guard ---
    # See _UNEVAL_TYPES at module scope. The .has() check catches nested cases
    # where an unevaluated Sum/Integral/Limit/Order is wrapped in an Add or Mul.
    if isinstance(parsed_expr, sympy.Basic):
        if isinstance(parsed_expr, _UNEVAL_TYPES) or parsed_expr.has(*_UNEVAL_TYPES):
            caveats.append(
                "MATH-VERIFY-FLAG: result contains unevaluated symbolic forms — "
                "SymPy could not produce a closed form"
            )
            parsed_expr = None

    # --- Symbolic path ---
    if source in ("sympy", "all"):
        if parsed_expr is not None:
            symbolic_result = str(parsed_expr)
            sources_used.append("sympy")
            ok = True
        else:
            ok = False

    # --- Numeric path (numpy via lambdify) ---
    # lambdify compiles the ALREADY-parsed SymPy tree into a numpy callable.
    # The generated code is produced by SymPy from its AST — no user string
    # is re-evaluated — which closes the eval() sandbox-escape path.
    if source in ("numpy", "all") and parsed_expr is not None:
        free_syms = sorted(parsed_expr.free_symbols, key=lambda s: s.name)
        if free_syms:
            caveats.append(
                f"numeric evaluation requires values for free symbols: {[s.name for s in free_syms]}"
            )
            if source == "all":
                independent_check = "N/A"
            elif source == "numpy":
                ok = False
        else:
            try:
                numeric_fn = sympy.lambdify([], parsed_expr, modules="numpy")
                numpy_val = float(numeric_fn())
                numeric_result = numpy_val
                sources_used.append("numpy")
                if source == "numpy":
                    ok = True

                # Cross-check: sympy.evalf (arbitrary precision) vs lambdify-numpy
                # (machine-precision). These are independent code paths inside
                # SymPy, so agreement is a meaningful corroboration signal.
                try:
                    sympy_val = float(parsed_expr.evalf())
                    if abs(sympy_val - numpy_val) < tolerance:
                        independent_check = "PASS"
                    else:
                        independent_check = "FAIL"
                        caveats.append(
                            f"sympy ({sympy_val}) and numpy ({numpy_val}) disagree beyond tolerance {tolerance}"
                        )
                        ok = False
                except (TypeError, ValueError):
                    independent_check = "N/A"
            except Exception as exc:
                caveats.append(f"numeric eval error: {exc}")
                if source == "all":
                    ok = False
                    independent_check = "FAILED-EVAL"
                elif source == "numpy":
                    ok = False

    # --- Wolfram path (REC 4 — opt-in, gated on WOLFRAM_APP_ID) ---
    # Wolfram is corroboration, never sole source. For `source=wolfram` it IS
    # the result; for `source=all` it's an additional check. Either way, ANY
    # Wolfram failure surfaces as WOLFRAM-UNAVAILABLE (visible, not silent).
    if source in ("wolfram", "all"):
        app_id = os.environ.get("WOLFRAM_APP_ID")
        if not app_id:
            if source == "wolfram":
                caveats.append(
                    "WOLFRAM-UNAVAILABLE: WOLFRAM_APP_ID env var not set — "
                    "set this env var to enable Wolfram corroboration"
                )
                ok = False
            else:
                # source='all' with no env var: surface the skip as a low-
                # noise caveat so users know Wolfram didn't run (otherwise
                # source=all looks identical to source=sympy+numpy).
                caveats.append("Wolfram skipped: WOLFRAM_APP_ID not set")
        else:
            wolf_text, wolf_err = _wolfram_query(expression, app_id)
            if wolf_err is not None:
                caveats.append(f"WOLFRAM-UNAVAILABLE: {wolf_err}")
                if source == "wolfram":
                    # Wolfram-only failed → fail the call
                    ok = False
                # source='all': SymPy+NumPy already set ok above; Wolfram failure
                # adds a caveat but doesn't override their success.
            else:
                sources_used.append("wolfram")
                if source == "wolfram":
                    # Wolfram-only mode — its result IS the verification.
                    # If local parse failed (parsed_expr is None) but Wolfram
                    # succeeded, surface that the local cross-check is absent —
                    # users seeing ok=True deserve to know SymPy didn't agree.
                    symbolic_result = wolf_text
                    ok = True
                    if parsed_expr is None:
                        caveats.append(
                            "MATH-VERIFY-FLAG: local SymPy parse failed; "
                            "Wolfram result is sole source — cross-check unavailable"
                        )
                count = _wolfram_increment_call_counter()
                if count > _WOLFRAM_QUOTA_WARN_THRESHOLD:
                    print(
                        f"WOLFRAM-QUOTA-WARN: {count}/{_WOLFRAM_QUOTA_TOTAL} "
                        f"calls used this month",
                        file=sys.stderr,
                    )

    # --- Event logging ---
    if _append_event is not None:
        try:
            _append_event(
                event="math_verify",
                category="math-verify",
                data={
                    "domain": domain,
                    "source": source,
                    "sources_used": sources_used,
                    "ok": ok,
                    "independent_check": independent_check,
                },
            )
        except Exception:
            pass

    return VerifyResult(
        inputs=expression,
        method=f"source={source}",
        symbolic_result=symbolic_result,
        numeric_result=numeric_result,
        independent_check=independent_check,
        authoritative_reference=authoritative_reference,
        caveats=caveats,
        ok=ok,
    )


# ---------------------------------------------------------------------------
# CLI entry point
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    if not _DEPS_AVAILABLE:
        print(
            "MATH-VERIFY-UNAVAILABLE: install with 'uv pip install sympy numpy'",
            file=sys.stderr,
        )
        sys.exit(2)

    import argparse

    parser = argparse.ArgumentParser(description="Verify a mathematical expression.")
    parser.add_argument("expression", help="Mathematical expression to verify")
    parser.add_argument(
        "--source",
        default="all",
        choices=["sympy", "numpy", "wolfram", "all"],
        help="Verification source(s). 'wolfram' and 'all' use Wolfram only when WOLFRAM_APP_ID is set",
    )
    parser.add_argument("--domain", default="general", help="Domain context")
    parser.add_argument("--tolerance", type=float, default=1e-9, help="Numeric tolerance")
    args = parser.parse_args()

    result = verify(
        args.expression,
        source=args.source,
        domain=args.domain,
        tolerance=args.tolerance,
    )
    # Exit-code convention (contract):
    #   0 = verified (ok=True)
    #   2 = MATH-VERIFY-UNAVAILABLE (missing deps; handled above)
    #   3 = FAIL — parse rejection, cross-check disagreement, or numeric error
    print(f"Inputs:                {result.inputs}")
    print(f"Method:                {result.method}")
    print(f"Symbolic Result:       {result.symbolic_result}")
    print(f"Numeric Result:        {result.numeric_result}")
    print(f"Independent Check:     {result.independent_check}")
    print(f"Authoritative Reference: {result.authoritative_reference}")
    print(f"Caveats:               {result.caveats}")
    print(f"OK:                    {result.ok}")
    sys.exit(0 if result.ok else 3)
