---
name: verify-math
description: Cross-verify a mathematical expression using sympy (symbolic) and numpy (numeric) with optional Wolfram Alpha corroboration and authoritative source citation.
allowed-tools: Bash Read
argument-hint: "<expression> [--source=sympy|numpy|wolfram|all] [--domain=general|calculus|statistics|numerical]"
---

Verify the mathematical expression: $ARGUMENTS

## Steps

1. Run `python3 .claude/skills/verify-math/verify.py "<expression>" [--source=all] [--domain=general]`
2. Check `Independent Check` field — PASS means sympy and numpy agree within tolerance
3. Note the `Authoritative Reference` for citation purposes
4. If exit code is 2, install missing deps: `uv pip install 'shipteam[verify]'`

## Install

```bash
uv pip install 'shipteam[verify]'
```

This installs sympy + numpy (the skill's primary verification paths). Without these, the skill fail-closes with `MATH-VERIFY-UNAVAILABLE` per ADR-013.

## Optional: Wolfram Alpha corroboration (opt-in)

Set the `WOLFRAM_APP_ID` env var to enable Wolfram as an additional verification source. Get an AppID from the Wolfram developer portal.

```bash
export WOLFRAM_APP_ID=your-app-id-here
python3 .claude/skills/verify-math/verify.py "<expression>" --source=wolfram
# or include Wolfram alongside sympy + numpy:
python3 .claude/skills/verify-math/verify.py "<expression>" --source=all
```

Without `WOLFRAM_APP_ID`, the Wolfram code path is dead — `--source=wolfram` fails with `WOLFRAM-UNAVAILABLE`, and `--source=all` silently uses only sympy + numpy.

### Wolfram quota caveat

Wolfram's free tier is currently **2,000 non-commercial calls/month** per vendor docs. The vendor explicitly **reserves the right to adjust these limits and usage quotas at its discretion** (Wolfram FAQ verbatim) — quota stability is NOT contractually guaranteed. The skill tracks local call counts in `.context/metrics/wolfram_calls.json` and emits `WOLFRAM-QUOTA-WARN` on stderr once monthly usage exceeds 1,600 calls (80% threshold). Treat Wolfram as backup corroboration, never the sole source of truth.
