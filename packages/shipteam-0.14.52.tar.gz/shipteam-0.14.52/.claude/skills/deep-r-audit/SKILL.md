---
name: deep-r-audit
description: Reverse-direction /deep-r. Audits CURRENT project configuration (settings.json, hooks, scripts, deps) against known upstream issues for the installed version. Surfaces latent bugs that forward-looking design validation never catches. Run manually before major releases or monthly.
allowed-tools: Agent Bash Read Grep Glob WebSearch WebFetch
argument-hint: "[optional: restrict scope — e.g., 'hooks' or 'deps' or 'all']"
---

Audit the current project's infrastructure for latent bugs matching known upstream issues. Scope: $ARGUMENTS (default: all).

> **Distinct from /deep-r.** /deep-r validates *forward-looking design choices* against authoritative sources. /deep-r-audit inspects *already-shipped configuration* against upstream issue trackers. The first asks "is this the right pattern?" The second asks "are the patterns I'm already using quietly broken?"

## Why This Skill Exists

Forward-looking /deep-r has a blind spot: it evaluates a specific decision at planning time. It never goes back to the existing running configuration and asks "is this still correct?" Latent defects stay latent until they bite at runtime — often months after the original decision was made, often in edge cases that reproduction requires.

A concrete example this skill would have caught: Claude Code hook commands registered as `python3 .claude/hooks/foo.py` in `settings.json`. The docs don't flag this as a problem. Forward-looking /deep-r, asked "how should I register hooks?" would validate the pattern against docs and return green. Only adversarial inspection of the existing config against upstream issue trackers surfaces #33815 (`$CLAUDE_PROJECT_DIR` empty) and the class of cwd-drift bugs.

## Audit Protocol

### 1. Enumerate Primitives In Use

Read the project's current configuration and extract every upstream-provided primitive the project depends on. Primitives include:

- **Claude Code hooks** — parse `.claude/settings.json`: list all hook types in use (PreToolUse, PostToolUse, UserPromptSubmit, SessionStart, PreCompact, PostCompact, SubagentStart, TaskCreated, TaskCompleted, TeammateIdle, WorktreeCreate, etc.) and the command strings
- **Claude Code env vars** — grep hook scripts for `$CLAUDE_*`, `os.environ.get("CLAUDE_*")` references
- **Claude Code features** — grep for MCP server usage, skills invocation, agent types, model selection
- **Dependencies** — parse `package.json`, `requirements.txt`, `pyproject.toml`, `Cargo.toml`, `go.mod` for top-level deps
- **Shell/OS primitives** — grep `scripts/` for `git worktree`, `gh pr`, platform-specific flags
- **Third-party SDKs** — Anthropic SDK, any LLM client libraries, cloud SDKs

For each primitive, record: **name**, **version/source** (from lockfile or CLI version output), **files where used**.

### 2. Determine Installed Versions

Run version probes for primitive sources:

```bash
claude --version 2>/dev/null || echo "claude-code: unknown"
gh --version 2>/dev/null | head -1
git --version
python3 --version
node --version 2>/dev/null || echo "node: absent"
```

Record each version. This is the filter for step 3.

### 3. Adversarial Upstream Search (per primitive)

For each primitive enumerated in step 1, run the /deep-r Adversarial Search Pass (see `.claude/skills/deep-r/SKILL.md` → *Adversarial Search Pass*):

1. Site-filtered issue search against the upstream repo
2. Failure-keyword search
3. Version-filtered check against the installed version from step 2

Filter results aggressively: include ONLY issues where (a) the pattern described matches a pattern actually present in this project's config (don't cry wolf over hypothetical uses) AND (b) the issue affects the installed version.

### 4. Rank Findings

Each finding is (primitive, upstream-issue, project-location, severity). Severity:

- **Critical** — upstream bug causes silent wrong-behavior or security bypass in a pattern this project uses
- **High** — upstream bug causes loud failure in a pattern this project uses (recoverable but disruptive)
- **Medium** — upstream bug affects a related pattern; project may hit it under edge case
- **Low** — known bug, project's usage is outside the failure envelope but worth tracking

### 5. Output Report

```
# Infrastructure Audit — YYYY-MM-DD
Scope: <hooks | deps | all>
Project: <repo name / branch>
Installed versions: claude-code v<X>, gh v<Y>, python <Z>, ...

## Summary
<N> primitives audited, <M> findings (<C> Critical, <H> High, <Med> Medium, <L> Low)

## Findings

### Critical
- **[primitive] @ [location]** — [upstream issue URL]
  - Impact: <what breaks, under what conditions>
  - Recommended action: <fix / workaround / monitor>

### High
(same format)

### Medium / Low
(abbreviated)

## Primitives Audited With No Findings
<bullet list — shows audit coverage>

## Search Queries Executed
<bullet list — for reproducibility>
```

## Cadence Guidance

Run /deep-r-audit:

- Before every major release (v0.X.0 or v1.0)
- Monthly on mature projects (latent bugs accumulate as upstream issues are filed)
- Immediately after a Claude Code version upgrade
- When new project patterns are adopted (first time a new hook type is registered, first MCP server integration, etc.)

**Future work (v0.15+)**: Register a fw-sync post-hook that runs /deep-r-audit in a lightweight mode and surfaces "these N patterns in your config have known upstream issues — review." This moves from *manual* audit to *continuous* audit without requiring Claude to be invoked.

## Lens Consultation

Apply the following lenses when evaluating findings:

- **failure-domain-isolation** — flag any primitive whose failure mode would take down BOTH the component and its recovery path
- **hot-path-latency** — flag any primitive on a hot path that has reported performance regressions in upstream issues
- **explicit-tradeoff** — when recommending a workaround, name what the workaround gives up

See `.claude/lenses/README.md`.

## Quality Bar

- No findings without a cited upstream issue (no "I think this might be broken")
- No findings based on patterns not actually present in the project's config
- Each finding includes the file:line where the project uses the affected pattern
- Search queries logged for reproducibility
- Audit run is idempotent — running twice on unchanged config produces identical report
