# Adversarial Source Check — Hunt Docs-as-Truth Bias

**Purpose**: Vendor documentation describes intended behavior. It rarely documents current bugs, version-specific regressions, or empirical failure modes. Every `/deep-r` run MUST actively search for contradicting evidence before finalizing recommendations whose correctness depends on an upstream primitive.

> Docs-as-truth bias is the #1 failure mode of design validation. A recommendation that survives only because nobody looked at the issue tracker is a recommendation you'll regret within a release cycle.

## When This Step Runs

Phase 3 of SKILL.md — **after** research subagents complete, **before** convergence.

Applies to every load-bearing upstream primitive that appears in the fact set or would be cited in Recommendations. A primitive is:

- An environment variable (e.g., `$CLAUDE_PROJECT_DIR`, `$DATABASE_URL`)
- A hook name (e.g., `PreToolUse`, `UserPromptSubmit`)
- An API endpoint, SDK method, or library function
- A CLI flag (e.g., `--print`, `--no-track`)
- A config key (e.g., `allowed_domains` on WebSearch)

## MANDATORY Searches Per Primitive

Execute AT LEAST these three per primitive. Budget ~2 tool calls each.

### 1. Issue-Filtered Upstream Search

- `site:github.com/<upstream-org>/<repo>/issues <primitive-name>`
- Include BOTH open and closed issues.
- Filter to the last 12 months where possible.
- Look for issues that contradict the happy-path claim — reports of the primitive being empty, broken, absent, wrong-typed, or version-gated.

### 2. Failure-Keyword Search

- `"<primitive-name>" "not working"` OR `"empty"` OR `"broken"` OR `"undefined"` OR `"null"`
- `"<primitive-name>" "does not"` OR `"fails"` OR `"returns empty"` OR `"regression"`
- Biases search toward people reporting misbehavior, not people celebrating intended behavior.

### 3. Version-Filtered Check

- If the installed version of the upstream tool is knowable, search for issues filed against that version or later.
- Example: `site:github.com/anthropics/claude-code/issues "v2.1.74" CLAUDE_PROJECT_DIR`.
- If no version is pinned in the conversation, note this as a gap in the output rather than silently proceeding.

## Worked Example — What This Pass Actually Catches

Claude Code's `$CLAUDE_PROJECT_DIR` is documented as "the project root." The official hook docs are silent on any limitation. One adversarial search (`site:github.com/anthropics/claude-code/issues CLAUDE_PROJECT_DIR`) surfaces **issue #33815** documenting the variable is empty in PreToolUse hooks on v2.1.74+ — exactly the failure a forward-looking design review would hit in production.

Vendor docs said one thing, issue tracker said another. The design that trusted docs is broken; the design that ran this pass is not.

## Output Requirement (MANDATORY)

The final `/deep-r` output MUST include a section titled `## Known Upstream Issues`. It lists each contradicting hit with citation (issue URL) and impact. If no hits surface, the section MUST still be present and say explicitly:

```
## Known Upstream Issues
None found after adversarial search against: <list of primitives searched>.
Search method: issue-filtered + failure-keyword + version-filtered.
Caveat: absence of evidence is not evidence of absence; re-run this pass when new versions ship.
```

Suppressing the section entirely is a protocol violation — it removes the accountability that the pass actually ran.

## When a Contradiction Is Found

If any hit contradicts a happy-path claim, the Recommendation MUST be adjusted to survive the failure mode. Three valid adjustments:

1. **Fallback layer** — design the recommendation to tolerate the failure mode (e.g., "fall back to computing project root from git if `$CLAUDE_PROJECT_DIR` is empty").
2. **Conditional guard** — wrap the recommendation in a version/state check (e.g., "only applies on claude-code < v2.1.74").
3. **Explicit limitation** — ship the recommendation with a documented caveat, so readers know the boundary.

A recommendation that ignores the issue-tracker contradiction is NOT acceptable.

## Anti-Patterns (DO NOT)

- DO NOT search only the docs repo. Docs show intent; issues show reality.
- DO NOT skip the failure-keyword variant. It catches issues whose titles don't mention the primitive by name.
- DO NOT suppress the `Known Upstream Issues` section when zero hits — the empty section is the accountability.
- DO NOT search for validation ("primitive X is reliable"); search for contradiction ("primitive X is broken"). Confirmation bias defeats the pass.
