# Lens Consultation — Pressure-Test Common Defaults

**Purpose**: Reasoning lenses in `.claude/lenses/` encode lessons from past framework failures. They are advisory, not mandatory to *apply*, but **mandatory to *consider*** during any `/deep-r` that compares alternatives. The consultation forces the reasoner to externalize assumptions that usually stay implicit.

> Rules (`.claude/rules/`) are *what you must do*. Lenses are *how to think* about a decision. Don't confuse them. Every recommendation that picks between options MUST show its lens check — even if the result is "no lens applicable."

## When This Step Runs

Phase 5 of SKILL.md — during Synthesis, producing the `## Lens Check` section. Required when the investigation compares alternatives: tool choice, library choice, architecture pattern, model choice, vendor choice, or any "A vs B" structural recommendation.

If the investigation is pure fact-finding with no comparison (e.g., "what's the current state of X?"), this step may be skipped with an explicit note:

```
## Lens Check
Not applicable — pure research task, no alternatives compared.
```

Do NOT omit the header.

## Prerequisites

1. Read `.claude/lenses/README.md` (project-relative path) to see the active lens set.
   - If the project does not have `.claude/lenses/` (e.g., a project that doesn't run the dev-framework), note this in the output: `## Lens Check — Skipped (no lens set in project)`.
2. Each lens file encodes ONE question. Apply the lens by asking that question of each candidate approach.

## Current Lens Set

These are the current lenses distributed by the framework. Descriptions here are summaries; consult the lens files themselves for the full question and past-failure citations.

| Lens | Core question | Fires on |
|------|---------------|----------|
| `hot-path-latency` | `cost_per_call × invocations_per_session` — is that budget acceptable? | Code paths that run per-tool-call, per-request, per-render, per-keystroke |
| `failure-domain-isolation` | Does the thing that locates/launches X share deps with X? | Launchers, dispatchers, supervisors, gates, health checks |
| `fit-for-purpose` | Does this task actually need what this tool provides? | Tool/language/library/abstraction selection |
| `explicit-tradeoff` | What am I giving up, and is the cost worth naming? | Every non-trivial choice |

If a lens not in this list appears in the project's `.claude/lenses/` directory, apply it too and document in the Lens Check output.

## Output Requirement — `## Lens Check`

One line per lens considered. Structure:

```
## Lens Check

**hot-path-latency**: <applied/not applicable>.
  <one-line result or reason for non-applicability>

**failure-domain-isolation**: <applied/not applicable>.
  <one-line result>

**fit-for-purpose**: <applied/not applicable>.
  <one-line result>

**explicit-tradeoff**: <applied/not applicable>.
  <one-line result>
```

### What "applied" looks like — example for `hot-path-latency`:

> **hot-path-latency**: applied. Recommendation A fires per-tool-call (~50ms × ~200 calls/session = 10s of latency); Recommendation B is one-time per session. At session budget of 30min total, 10s is 0.5% — acceptable. Conclusion: A is fine on this axis.

### What "not applicable" looks like — example:

> **hot-path-latency**: not applicable. Both recommendations run at most once per deployment (monthly cadence); per-call latency is not a budget line.

### Bad lens check (protocol violation):

> **hot-path-latency**: applied. Both look fine.

— No cost number, no calls-per-session figure, no actual comparison. Fails because it didn't externalize the assumption.

## Admission Criteria for New Lenses (reference only)

Not your concern during consultation, but worth knowing: per `.claude/lenses/README.md`, a new lens must (1) cite a concrete past failure, (2) force exactly one question, (3) resist a common default, (4) stay ~60–120 lines. The current cap is ~8 lenses.

## Anti-Patterns (DO NOT)

- DO NOT skip the Lens Check header. The empty header is the accountability; omission is a protocol violation.
- DO NOT apply only the lenses you remember. Read the README first — lenses change.
- DO NOT apply a lens without naming the actual data ("50ms × 200 calls"). Vibes-based lens application is equivalent to no lens application.
- DO NOT treat lenses as rules. A lens that fires doesn't mean "don't do it" — it means "here's the hidden cost, decide explicitly."
- DO NOT skip a lens as "not applicable" without a one-line reason. The reason is proof you thought about it.
