# Decomposition Lens — Fixed 3-Axis Planning Template

**Purpose**: Eliminate cross-run variance in problem decomposition. Every `/deep-r` topic MUST be split along the same three axes. A fixed lens is load-bearing — Anthropic's own research on multi-agent systems identifies decomposition drift as a primary source of between-run inconsistency.

## The Three Axes (MANDATORY)

Every topic MUST be decomposed along all three. No skipping, no merging.

### Axis 1: Correctness & Risk

*Does it work as claimed? What breaks it?*

- Does the approach actually solve the stated problem?
- Known CVEs, security advisories, incident reports
- Failure modes under load, at edge cases, under adversarial input
- Known false claims and vendor marketing gap vs. measured reality
- Threat model: who can break it, how

### Axis 2: Operability & Cost

*What does it take to run?*

- Deployment footprint (nodes, memory, licensing, required services)
- Cost at stated scale: dollars/month, engineer-hours/month
- Maintenance burden: upgrade cadence, breaking-change history, operator skill required
- Observability story: metrics, tracing, debugging posture
- Disaster recovery: backup, restore, RTO/RPO

### Axis 3: Ecosystem & Adoption

*Who else uses it, at what scale, and what are the alternatives?*

- Named production deployments at comparable or larger scale
- Community health: release cadence, maintainer count, issue response time
- Alternatives considered and why they lose (migration cost, feature gaps, wrong shape)
- Lock-in cost: switching effort if this choice is wrong

## Axis Specialization Rule

Two axes MUST always be **Correctness/Risk** AND one of **{Operability/Cost, Ecosystem/Adoption}**.

If a topic genuinely does not fit one of the three standard axes (rare — e.g., a pure theoretical research question with no operational dimension), the lead agent MUST:

1. Replace the ill-fitting axis with a topic-specific axis.
2. Name the replacement axis explicitly.
3. Justify the swap in the plan's output, in one sentence, citing why the standard axis does not apply.

Do NOT silently drop an axis. Do NOT collapse two axes into one.

## Plan Output Format

The lead agent MUST emit this exact structure during Phase 1:

```
## Proposed Research Plan

Topic: <normalized topic string>
Topic hash: <sha256 first 12 chars>
Cache status: [hit | miss | skipped via --no-cache]

### Axis 1: Correctness & Risk
Sub-questions:
  1. <specific question>
  2. <specific question>
Planned sources (tier + domain):
  - Tier A: <domain or known URL>
  - Tier B: <domain or known URL>

### Axis 2: Operability & Cost
Sub-questions:
  1. <specific question>
  2. <specific question>
Planned sources (tier + domain):
  - Tier A: <domain or known URL>
  - Tier B: <domain or known URL>

### Axis 3: Ecosystem & Adoption
Sub-questions:
  1. <specific question>
  2. <specific question>
Planned sources (tier + domain):
  - Tier A: <domain or known URL>
  - Tier B: <domain or known URL>

Budget: <N> subagents × <M> tool calls each (per complexity scaling)
Stopping rule: per verification.md stopping clause
Topic-class domain allowlist: <class name from source-ladder.md>

**REPLY WITH ONE OF:**
- "approve" → proceed with this plan
- "edit: <instructions>" → modify and re-propose
- "rebuild" → scrap and re-plan from scratch
```

## Complexity Scaling (Budget)

Pick the tier by reading the topic. Budget MUST match; do not over-provision.

| Complexity | Subagents per axis | Tool calls per subagent | Total calls |
|---|---|---|---|
| Simple fact-finding | 1 | 3–5 | 9–15 |
| Comparative evaluation | 1 | 8–12 | 24–36 |
| Architecture / production audit | 2 | 10–15 | 60–90 |

Heuristics for class selection:
- **Simple** — "What is X?", "What's the current state of Y in <year>?", single-vendor lookup.
- **Comparative** — "Should we use A or B?", "Evaluate A vs B for <use case>."
- **Architecture/audit** — "Is this production-ready?", "Evaluate <system design>", "Audit <existing setup>."

## Pause-for-Approval Protocol (MANDATORY)

After emitting the plan, the lead agent MUST STOP. It MUST NOT call any tool — no WebSearch, no WebFetch, no subagent spawn — until the user responds.

Accepted user responses:

- `approve` — proceed exactly as planned.
- `edit: <instructions>` — apply the edits, re-emit the updated plan, wait for approval again.
- `rebuild` — discard the plan, re-decompose from scratch (typically after new information surfaced), emit new plan, wait for approval.

Any other response → ask a clarifying question rather than guessing intent. Never silently interpret ambiguous input as approval.

## Re-Run UX (Cache Hit)

When `bin/cache.sh read-plan <topic>` returns a hit, the lead agent MUST prepend this block to the plan output before showing it:

```
Prior plan found (age: <N> days). Cache contents below.
Options:
  - "reuse" → re-run research with the same plan (facts cache still bypassed; fresh sources)
  - "edit: <instructions>" → modify the prior plan
  - "rebuild" → discard and re-plan from scratch (for when the landscape has shifted)
```

Then show the cached plan. Still wait for explicit user response — never auto-reuse. The user may have new context that justifies re-planning even when the cached plan looks fine.

## Anti-Patterns (DO NOT)

- DO NOT emit the plan and immediately start research "to save a round trip." Pause is the point.
- DO NOT merge two axes when one looks thin — if Operability/Cost has only one sub-question, note that the axis is small, not that it merges into Correctness.
- DO NOT invent sub-questions to pad the plan. Three specific questions per axis beats six vague ones.
- DO NOT select Tier E domains in the planned-sources list. Planned sources MUST be Tier A/B/C/D.
