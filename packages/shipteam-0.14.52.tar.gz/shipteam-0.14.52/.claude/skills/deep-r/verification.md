# Verification & Convergence Protocol

**Purpose**: Factored verification on load-bearing claims + convergence step that enforces the source ladder at synthesis time. Based on Dhuliawala et al., *Chain-of-Verification Reduces Hallucination in Large Language Models* (ACL 2024, arXiv 2309.11495), whose core finding is that **independent** verification questions — asked without the draft as context — catch hallucinations that self-review misses.

## Convergence Step Protocol (R5 — run AFTER all subagents return)

After subagents finish Phase 2, the lead agent MUST perform these steps in order. No skipping.

### Step 1 — Compile deduplicated claim list

Build a table: `(claim text, subagent source, cited URL, tier)`. Normalize near-duplicates (same assertion worded differently) into a single row with multiple `(subagent, URL)` pairs.

### Step 2 — Identify single-source claims

A **single-source claim** is one reported by exactly one subagent. These are the highest risk for hallucination or for being a subagent's confident-but-wrong read.

### Step 3 — Re-verify single-source Primary claims

For EVERY single-source claim tagged as Primary (Tier A or B), the lead agent MUST:

1. Call WebFetch on the cited URL.
2. Read the fetched content for the specific assertion.
3. Verdict:
   - **Confirmed** → claim stands at Primary.
   - **Partial support** → downgrade to Secondary, note the gap.
   - **Not supported** → downgrade to Tertiary OR remove.
   - **URL dead / 404** → remove the claim, add an entry to Gaps & Risks.

Single-source Tier C/D claims do NOT require WebFetch re-verification, but they MUST NOT be used to back a Recommendation unless promoted via additional sources.

### Step 4 — Identify conflicting claims

Two or more subagents report contradictory facts on the same point. Apply `source-ladder.md` resolution:

- Default rule: higher tier wins.
- Override rule: only if the lower-tier source satisfies the override block (direct measurement / PoC / independent replication / timestamped primary disclosure) — and the override block MUST appear in the final output.

### Step 5 — Emit convergence log (internal)

Summarize the convergence step for the user:

```
## Convergence Log
Single-source claims: N
  Verified: M
  Downgraded: D
  Removed: N-M-D
Conflicting claims: K
  Resolved per ladder: K-O
  Resolved via override: O (see OVERRIDE blocks below)
```

This log goes in the output. It's evidence the convergence step actually ran — removing it removes the accountability.

## Chain-of-Verification Factored Protocol (R6 — run AFTER synthesis draft)

After Phase 4 produces the synthesis draft (Executive Summary, Detailed Analysis, Gaps & Risks, Recommendations), but BEFORE the self-judge rubric:

### Step 1 — Identify load-bearing claims

A claim is load-bearing if removing it would change a Recommendation's direction or priority. Pick 3–5 of these from the Recommendations section. Fewer than 3 is fine if the recommendation set is small; more than 5 is expensive — prefer to cover the most decision-relevant.

### Step 2 — Generate verification questions

For each load-bearing claim, write ONE verification question that:

- Asks for the underlying fact, NOT for the claim itself.
- Does NOT reference the draft, the recommendation, or the overall topic framing.
- Is answerable with ≤3 tool calls.

Example:
- Load-bearing claim: "Argon2id is recommended for password hashing in 2026 per NIST SP 800-63B-4."
- BAD verification question: "Is Argon2id the right choice?" (leading, references the recommendation)
- GOOD verification question: "What password hashing algorithms does NIST SP 800-63B (latest revision) list as approved, and what is the publication date of the latest revision?"

### Step 3 — Spawn independent verifier subagents

For each question, spawn a fresh subagent with ONLY:

- The verification question.
- The topic class (for allowlist selection).
- The source-ladder rules (for tier tagging).

The verifier MUST NOT see the draft, the recommendations, or any other subagent's output. Independence is the point — Dhuliawala's result is that self-generated verification with draft context fails because the model defends its own draft.

### Step 4 — Compare and reconcile

For each verification answer, compare to the corresponding claim in the draft:

- **Agreement** → claim stands.
- **Partial disagreement** → rework the claim with new nuance. Re-run affected Recommendation through the recommendation rubric.
- **Contradiction** → cut or replace the claim. If a Recommendation depended on it, the Recommendation MUST be rewritten or cut.

Log the CoVe result in the convergence log under `CoVe Questions: N, Confirmed: M, Reworked: R, Cut: C`.

## Stopping Rule (R3 — when to halt research)

Research MUST halt when ALL THREE conditions hold:

1. Every load-bearing claim is Primary or Secondary (no Tertiary claims backing Recommendations).
2. No Tier A source contradicts any Recommendation.
3. Each Primary claim has ≥2 independent Tier A or B sources (the override rule allows lower-tier backing under specific conditions, not relaxation of independence).

If budget is exhausted and these conditions DO NOT all hold:

- Emit the output with a `**TENTATIVE**` marker in the Recommendations section.
- Note each unmet condition in Gaps & Risks with specificity: *"Claim X lacks a second independent source"* or *"Tier A source Y contradicts Recommendation Z on point P."*
- Do NOT continue past budget silently. The stopping rule prevents infinite research loops; the tentative marker prevents pretending unfinished work is complete.

## Anti-Patterns (DO NOT)

- DO NOT skip WebFetch re-verification on single-source Primary claims. The whole point is catching the subagent who confidently paraphrased the RFC wrong.
- DO NOT show CoVe verification questions to the verifier subagent alongside the draft. Independence is the point.
- DO NOT silently suppress a failed verification — that breaks accountability. Rework or cut, and log the rework.
- DO NOT drop the convergence log from the final output. If the user can't see it ran, they can't trust it ran.
