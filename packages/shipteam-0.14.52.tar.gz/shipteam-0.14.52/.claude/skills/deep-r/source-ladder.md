# Source Ladder — Tier Definitions & Override Rule

**Purpose**: Rank sources by evidential weight. Every `/deep-r` claim MUST carry a tier tag. Recommendations are bounded by the tier of their supporting evidence.

## Tier Definitions

### Tier A — Authoritative Primary

Direct, canonical sources. Treat as ground truth unless overridden per the rule below.

- IETF RFCs, drafts with WG consensus (`rfc-editor.org`, `tools.ietf.org`, `datatracker.ietf.org`)
- ISO standards (`iso.org`)
- NIST Special Publications (`csrc.nist.gov`, `nvlpubs.nist.gov`)
- CVE/MITRE records (`cve.mitre.org`, `nvd.nist.gov`)
- W3C Recommendations and WHATWG living standards (`w3.org`, `whatwg.org`)
- Source code reads (git blame/log, GitHub source, vendor source repos)
- Timestamped primary disclosures (CVE publish dates, vendor security bulletins)

### Tier B — Official Secondary

Vendor-authored or peer-reviewed. Load-bearing for implementation details.

- Vendor official documentation: `docs.aws.amazon.com`, `cloud.google.com/docs`, `learn.microsoft.com`, `docs.anthropic.com`, `platform.openai.com`, `kubernetes.io/docs`, `postgresql.org/docs`, etc.
- Peer-reviewed papers: arXiv preprints (prefer those accepted at ACM/IEEE/NeurIPS/ICML/ACL/ICLR), `aclanthology.org`, `proceedings.neurips.cc`, `openreview.net`
- Vendor security advisories on the vendor's own site

### Tier C — Working-Group Output

Consensus documents from recognized working groups; less authoritative than A but domain-vetted.

- CNCF project docs and TAG whitepapers (`cncf.io`)
- OWASP Top 10, Cheat Sheets, ASVS (`owasp.org`)
- Linux Foundation working-group output
- IETF drafts without full WG consensus
- IEEE/ACM committee reports that aren't yet standards

### Tier D — Named Engineering Blogs

Signed, durable posts from organizations or researchers with track records. Can back Secondary claims; cannot alone back a Primary claim unless combined via the override rule.

- `sre.google` (Google SRE Book/blog)
- AWS Well-Architected whitepapers and architecture blog
- `azure.microsoft.com/architecture`, `cloud.google.com/architecture`
- Anthropic / OpenAI / DeepMind engineering posts
- Uber, Meta, Netflix, Stripe, Shopify, Cloudflare engineering blogs
- Personal sites of identifiable researchers with peer-reviewed credentials

### Tier E — Aggregators, Forums, SEO Content

Research-only. MAY NEVER back a Primary claim, never override anything.

- Medium, Dev.to, Hashnode
- Stack Overflow answers (the question itself is evidence of user interest, not truth)
- Hacker News, Reddit threads
- LLM-generated tutorials, content mill posts
- Random blog posts without author attribution or dated provenance

## Default Rule

**Higher tier wins on conflict.** If a Tier A and a Tier D source disagree, Tier A stands.

## Override Rule (Middle Path)

A Tier A/B/C/D source MAY override a higher-tier source ONLY when all three conditions hold and the override block appears in the output:

```
OVERRIDE: <lower-tier-URL> takes precedence over <higher-tier-URL>
EVIDENCE TYPE: [direct measurement | PoC | independent replication | timestamped primary disclosure]
WHY HIGHER TIER IS WRONG: <one sentence>
```

**Valid evidence types (exhaustive — no others accepted):**

1. **Direct measurement** — benchmark, trace, or instrumented run with data attached.
2. **Working PoC** — reproducible proof-of-concept with steps.
3. **Independent replication** — ≥2 Tier-C-or-higher sources independently reporting the same contradicting finding.
4. **Timestamped primary disclosure** — e.g., a CVE or vendor bulletin dated AFTER the higher-tier source, proving the higher source is stale.

**Tier E MAY NEVER override anything.** An aggregator post claiming a vendor doc is wrong is insufficient — it can only prompt further research at Tier C or higher.

## Topic-Class Domain Allowlists

Pass these to WebSearch's `allowed_domains` parameter when the topic maps to a class. Extend as needed; document additions here.

### Security

```
nist.gov, csrc.nist.gov, nvd.nist.gov, owasp.org, cve.mitre.org, cvedetails.com,
ietf.org, tools.ietf.org, rfc-editor.org, datatracker.ietf.org
```

### SRE / Operations

```
sre.google, aws.amazon.com, learn.microsoft.com, cloud.google.com,
kubernetes.io, cncf.io
```

### ML / AI

```
arxiv.org, openreview.net, aclanthology.org, proceedings.neurips.cc,
icml.cc, iclr.cc, docs.anthropic.com, platform.openai.com, deepmind.google
```

### Web / Standards

```
w3.org, whatwg.org, ietf.org, rfc-editor.org, developer.mozilla.org
```

### Databases / Data Infra

```
postgresql.org, sqlite.org, kafka.apache.org, cassandra.apache.org,
redis.io, cockroachlabs.com, tigerbeetle.com
```

### Tooling / Frameworks

```
nodejs.org, python.org, rust-lang.org, go.dev, golang.org,
docs.gradle.org, maven.apache.org, pnpm.io, bun.sh, yarnpkg.com
```

## How to Use This File

- When writing the decomposition plan, the lead agent MUST select the matching topic-class allowlist and attach it to subagent prompts.
- Each subagent's output MUST tag every claim with a tier letter, e.g., `[Tier A] RFC 9110 § 7.2`.
- The convergence step (`verification.md`) enforces the override rule at synthesis time.
- When no topic class cleanly matches, default to Tier A/B (RFCs, standards, arXiv) and document the absence of a class-specific allowlist in the plan.
