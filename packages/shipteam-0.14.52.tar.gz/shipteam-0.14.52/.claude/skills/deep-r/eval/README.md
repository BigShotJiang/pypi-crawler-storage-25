# /deep-r Eval Harness

**Purpose**: Measure cross-run agreement on `/deep-r` output. The v2 skill was designed to reduce "3+ runs to converge" variance; this harness is how we tell whether that worked.

## What It Does

For each question in `questions.jsonl`, runs `/deep-r <question> --no-cache` `N` times (default 3) via headless `claude -p`. Saves per-run `output.md` and extracts the `## Recommendations` section into `recommendations.md`.

**The harness captures; it does NOT score.** Scoring is a manual read of `recommendations.md` across runs per question. If we later want an automated agreement score, that's a separate scoring subagent — out of scope for v1.

## Prerequisites

- `claude` CLI on `PATH`. Verify: `which claude`.
- `bin/eval-runner.sh` executable: `chmod +x ../bin/eval-runner.sh`.
- Billing enabled on your Anthropic account — each run spends real API tokens.

## How to Run

```bash
cd ~/.claude/skills/deep-r
./bin/eval-runner.sh                    # Default: 3 runs × 10 questions
./bin/eval-runner.sh --runs 5           # More runs for tighter variance estimate
./bin/eval-runner.sh --yes              # Skip the cost-confirmation prompt
./bin/eval-runner.sh --questions my.jsonl  # Custom question set
```

Output goes to `eval/runs/<qid>/run-<n>/`:

```
eval/runs/
├── sec-01/
│   ├── run-1/
│   │   ├── output.md             # full /deep-r output
│   │   └── recommendations.md    # just the Recommendations section
│   ├── run-2/
│   └── run-3/
├── summary.tsv                   # qid | run | status | bytes
└── ...
```

## How to Interpret Results

For each `qid`, open the three `recommendations.md` files side by side and ask:

| Check | What to look for |
|---|---|
| **Top recommendation stability** | Is the same top recommendation picked across runs? (same verb + same target) |
| **Recommendation set overlap** | If there are 3 recs, do ≥2 appear in all 3 runs? |
| **Primary source stability** | Do the load-bearing Primary sources (RFCs, NIST SPs, vendor docs) match? |
| **Gap identification stability** | Do the Gaps & Risks sections flag similar concerns? |

Per the success criteria in `IMPLEMENTATION_PLAN.md`, the bar is **≥80% agreement** on top 3 recommendations + primary sources across 3 consecutive runs for standard queries.

### What's acceptable variance

- Wording differences in the same recommendation (fine — wording drift is harness-level).
- Citation swap between two equivalent Tier A sources (fine — e.g., RFC 9110 vs. W3C URL spec for the same normalization rule).
- Different ordering of Recommendations 2 and 3 (fine as long as top pick is stable).

### What's concerning variance

- Top recommendation flips across runs (e.g., "use Argon2id" vs. "use scrypt").
- Primary source appears in one run and is absent in another.
- One run flags a Critical Gap that another run misses entirely.
- Convergence log shows wildly different single-source-claim counts across runs.

When you see concerning variance: the v2 design assumption (prompt-fixable variance dominates) may be wrong. Open a note in the sidecar you suspect is weak (decomposition-lens, source-ladder, verification) and iterate.

## Cost Estimate

- Per `/deep-r` run: ~\$0.50–\$2 depending on subagent count and question class.
- Default eval (10 questions × 3 runs = 30 runs): **~\$15–\$60**.

The runner prints an estimate and prompts for confirmation unless `--yes` is passed. Do NOT run full eval in CI without explicit human initiation.

## How to Add Questions

Append a line to `questions.jsonl`:

```json
{"qid": "short-id", "topic_class": "security|SRE/operability|ML/AI|architecture/evaluation|web/standards|tooling/framework choice", "question": "..."}
```

Topic classes align with the allowlists in `source-ladder.md` — prefer an existing class to keep allowlists stable. If your question genuinely doesn't fit, add a new class to `source-ladder.md` as part of the same change.

## Known Limitations (v1)

- No automated agreement scoring. A v2 enhancement could add a scoring subagent that reads all runs for a qid and emits a numeric agreement score per axis.
- `claude -p` output captured as plain text; if Claude Code changes output format, the `extract_recommendations` awk filter may need updating.
- No rate-limit handling — if the API returns 429, the failed run is logged but not retried. Re-run just the failed `qid` manually.
