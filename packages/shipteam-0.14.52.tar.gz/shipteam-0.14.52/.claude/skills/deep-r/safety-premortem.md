# Safety Pre-Mortem — Runtime Failure Modes for Safety Infrastructure

**Purpose**: Safety infrastructure (hooks, middleware, auth gates, permission systems, rate limiters, access control, secrets handling) demands runtime-failure reasoning that forward-looking happy-path analysis does not produce. Every `/deep-r` output whose Recommendations touch safety infra MUST enumerate runtime failure states and classify each by failure mode.

> A safety gate that fails-open in a way users cannot detect is worse than no gate at all. Forward-looking reviews celebrate the primitive; pre-mortems surface the day the primitive silently stops firing.

## When This Step Runs

Phase 5 of SKILL.md — during Synthesis, producing the `## Runtime Failure Modes` section. Required when the investigation touches ANY of:

- Claude Code hooks (`PreToolUse`, `PostToolUse`, `UserPromptSubmit`, `Stop`, etc.)
- Authentication / authorization logic
- Input validation and sanitization
- Rate limiting or permission gating
- Secrets handling (env vars, keychain, vault access)
- File-system permissions or sandbox boundaries
- Supervisor / launcher / health-check components whose failure degrades security posture

If the investigation does NOT touch safety infra, skip this step — but say so explicitly in the output under the `## Runtime Failure Modes` header:

```
## Runtime Failure Modes
Not applicable — this investigation does not touch safety infrastructure.
```

Do NOT omit the header. The empty header is the accountability that the scope was evaluated.

## Required Output Section — `## Runtime Failure Modes`

Enumerate AT LEAST THREE runtime states. For each, document four fields:

1. **Trigger** — what event or environment condition causes this state.
2. **Behavior** — how the design behaves in this state (what the gate does, what the caller sees).
3. **Recovery** — whether the user can recover from inside the normal workflow, or whether the system is wedged until external intervention.
4. **Failure mode classification** — one of:
   - **fail-open** — the tool call / request proceeds, safety skipped.
   - **fail-closed** — the tool call / request is blocked, user sees an error.
   - **silent corruption** — no obvious error; wrong behavior ships.

## Failure-Mode Classification Rules

- **fail-open** is acceptable ONLY if the safety gate is advisory (e.g., warning logs). Any gate that exists to block unsafe actions MUST NOT fail-open on infrastructure faults.
- **fail-closed** is the default correct mode for blocking gates, but only if the user can tell it fired. A fail-closed gate that silently swallows the error is equivalent to silent corruption.
- **silent corruption** is ALWAYS the worst outcome. If the analysis identifies a silent-corruption state, the Recommendation MUST either (a) convert it to fail-closed with visible error, (b) add instrumentation that surfaces it, or (c) be rewritten to avoid the state entirely.

## Candidate States to Consider

Start the enumeration from this list; add domain-specific states as needed:

- **cwd drift** — the process chdir'd after hook registration; paths no longer resolve.
- **missing env vars** — the primitive the gate depends on is unset or empty.
- **permission denied** — OS-level read/write refused (config file, socket, keychain).
- **race condition** — two concurrent invocations conflict (lockfile, PID file, lease).
- **version skew** — installed version differs from the version the gate was designed for.
- **stale cache** — cached value is no longer valid (policy, key, token).
- **partial config** — config file loaded but missing required section.
- **interrupted writes** — mid-write crash leaves partial state readable.
- **network partition** — remote policy/permission service unreachable.
- **disk full** — logging or audit write fails; does the gate still enforce?
- **concurrent session interference** — another session holds the lock/lease the gate expects.

## Example Output

```
## Runtime Failure Modes

**State 1: $CLAUDE_PROJECT_DIR empty in PreToolUse hook on v2.1.74+**
- Trigger: upstream bug #33815 — variable not populated in this hook type on affected versions.
- Behavior: gate script runs with CWD at claude-code binary location, resolves nothing, returns success without running checks.
- Recovery: user notices wrong files staged; no gate-side indication of failure.
- Classification: **silent corruption** (gate appears to run; actually no-ops).
- Mitigation required: fallback to `git rev-parse --show-toplevel`; if still empty, fail-closed with explicit error.

**State 2: keychain locked (user not logged in)**
- Trigger: first invocation after system boot or keychain auto-lock timeout.
- Behavior: secret fetch raises; current gate version exits non-zero with opaque traceback.
- Recovery: user must unlock keychain manually; next run succeeds.
- Classification: **fail-closed with poor UX** — blocks correctly, but error doesn't tell user what to do.
- Mitigation required: catch exception, emit actionable message ("unlock keychain with: security unlock-keychain").

**State 3: concurrent hook invocation (two Claude sessions in same worktree)**
- Trigger: user runs `claude-session.sh` from two terminals against the same project path.
- Behavior: both acquire the branch-check lock sequentially; second sees stale value from first's completed read.
- Recovery: only detectable after the fact (wrong branch reported).
- Classification: **silent corruption**.
- Mitigation required: lock with flock, or move to read-after-write acquisition pattern.
```

## Anti-Patterns (DO NOT)

- DO NOT list fewer than three states. If you can only think of two, you haven't thought hard enough — go back and apply the candidate-states checklist.
- DO NOT classify without justification. "fail-closed" without naming the visible error is not classification; it's vibes.
- DO NOT declare a state "recoverable" without naming the recovery path. "User restarts" is a recovery path ONLY if it's documented and the user can discover it.
- DO NOT skip this step because "the design is simple." Simple designs have silent-corruption modes too; they're just harder to find.
