# Self-Judge & Recommendation Rubrics

**Purpose**: Deterministic LLM-as-judge evaluation applied to `/deep-r` output before it returns. Based on Zheng et al., *Judging LLM-as-a-Judge with MT-Bench and Chatbot Arena* (NeurIPS 2023, arXiv 2306.05685), whose 5-axis fixed rubric was most aligned with human judgment in Anthropic's internal deployment.

## Self-Judge Rubric (MANDATORY — applied before output is returned)

Score each axis on `{0.0, 0.5, 1.0}`. No intermediate scores, no bonus points.

| Axis | 0.0 (fail) | 0.5 (partial) | 1.0 (pass) |
|---|---|---|---|
| **Factual accuracy** | ≥1 claim contradicts its cited source | Minor drift between claim and source | Every claim traceable to its cited source verbatim or by paraphrase |
| **Citation accuracy** | Any URL in Sources doesn't support the claim it's attached to | Citations support claims partially or loosely | All URLs directly support the specific claim they back |
| **Completeness** | Missed ≥1 of the three axes entirely | All axes covered but ≥1 axis has <2 sub-findings | All axes covered with ≥2 distinct findings per axis |
| **Source quality** | Any Primary claim backed only by Tier E | Some Primary claims backed by Tier D only | All Primary claims backed by ≥1 Tier A or B source |
| **Tool efficiency** | >2× planned budget used | 1×–2× budget | Within planned budget |

### Pass Threshold

- **Average ≥ 0.8** AND
- **No axis below 0.5**

If BOTH conditions hold: emit output normally.

If EITHER fails: emit output with a `**QUALITY FLAG**` header at the top, listing each failing axis and the reason. Do NOT suppress the output — flag it. The user MUST see both the research result and the quality concern.

Example quality flag header:

```
**QUALITY FLAG** — This output did not meet the self-judge threshold.
- Source quality: 0.5 (Primary claim on migration cost backed only by Tier D blog post)
- Completeness: 1.0
- Citation accuracy: 1.0
- Factual accuracy: 1.0
- Tool efficiency: 1.0
Average: 0.90, but Source quality below 1.0 threshold for "no axis below 0.5" requires attention.
[Note: this example passes — the real quality flag fires when average <0.8 OR any axis <0.5.]
```

## Recommendation Rubric (MANDATORY — applied per recommendation)

Each item in the Recommendations section MUST satisfy ALL FOUR criteria. Recommendations failing any check MUST be rewritten or cut — never shipped as-is.

1. **Addresses a specific Gap or Risk** from the Gaps & Risks section. No free-floating recommendations.
2. **Backed by ≥1 Primary claim**. No Tertiary-only recommendations — if the only supporting evidence is Tertiary, the recommendation MUST be downgraded to a "research ask" or cut.
3. **Reversibility and cost noted explicitly**. One line naming: reversibility (easy/medium/hard), implementation effort (hours/days/weeks), operational cost change.
4. **Alternative considered and named**, even if rejected. "Alternative: X; rejected because Y" or "Alternative: none — this is a unique solution to the constraint."

Rejected recommendations (failing any check) are not discarded silently. The synthesis pass MUST log the failed candidates so the user can see what was proposed and why it was cut.

## Position-Swap Instruction (MANDATORY for all pairwise comparisons)

When comparing two options A and B in any evaluation — architecture, tool choice, model choice, vendor — the synthesis pass MUST:

1. Evaluate the pair in (A, B) order.
2. Evaluate the same pair in (B, A) order.
3. Compare verdicts.
4. If verdicts disagree, DISCARD both and mark the comparison as unresolved. Emit a note in Gaps & Risks: "Position-swap disagreement on A vs. B — verdict is unstable under ordering. Further evidence required."

Per Zheng et al., GPT-4 judges were only ~60% consistent on pairwise comparisons without swap mitigation. Claude is better but not immune — swap is cheap insurance against anchoring.

## What This Rubric Does NOT Do

- It does NOT score the technical merit of the research topic itself — only the research output's quality.
- It does NOT replace human review. It's a self-consistency check, not a reviewer.
- It does NOT gate output suppression. A failed rubric emits a flag, never silence.

## Invocation Order

The rubric runs as Phase 5 (Self-judge) in SKILL.md, AFTER synthesis+citation pass (Phase 4) and BEFORE output emission. If `--consensus` or `--debate` is set, rubric runs once more on the consensus/debate result, not on the intermediate synthesis.
