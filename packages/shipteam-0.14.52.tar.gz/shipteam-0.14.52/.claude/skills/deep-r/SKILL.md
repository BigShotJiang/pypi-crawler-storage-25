---
name: deep-r
description: Thorough, web-validated investigation with adversarial upstream search, safety-infra pre-mortem, and reasoning-lens consultation. Plan-pinning and source-ladder enforcement resist docs-as-truth bias. Use for architecture evaluation, production readiness audits, or any topic requiring rigorous analysis.
allowed-tools: Agent Bash Read Grep Glob WebSearch WebFetch
argument-hint: "<topic> [--consensus] [--debate] [--no-cache]"
---

Conduct a thorough, authoritative investigation of: $ARGUMENTS

## Protocol MUST-Reads

You MUST read each of these before proceeding. They define non-negotiable rules for this skill.

1. `source-ladder.md` — Tier A–E source hierarchy, override rule, topic-class domain allowlists.
2. `decomposition-lens.md` — Fixed 3-axis plan template, pause-for-approval protocol, budget tiers.
3. `adversarial-search.md` — Docs-as-truth defense: issue-filtered + failure-keyword + version-filtered upstream search.
4. `safety-premortem.md` — Runtime Failure Modes enumeration for safety infrastructure (hooks, auth, gates).
5. `lens-consultation.md` — Reasoning lenses from `.claude/lenses/` applied to any alternatives comparison.
6. `rubric.md` — 5-axis self-judge + per-recommendation rubric + position-swap rule.
7. `verification.md` — Convergence step, Chain-of-Verification, stopping rule.

If any of these files fail to load, STOP and tell the user. Do not proceed without them — skipping them defeats the point of this skill.

## Argument Parsing

Extract flags from `$ARGUMENTS`:

- `--consensus` → enable Self-Consistency majority vote on the final recommendation. N=3 subagents on the synthesis bundle, majority-vote top recommendation. Adds ~30–50% cost.
- `--debate` → enable Multi-Agent Debate when convergence finds Tier A sources disagreeing. One round: affirmative, negative, judge. Adds ~40% cost.
- `--no-cache` → skip reading cached plan and facts.
- Default (no flags) → skip consensus/debate; use cache if present.

The topic is `$ARGUMENTS` with flags stripped.

## Phase 1 — Plan

Apply `decomposition-lens.md`.

1. **Hash the topic**: `bash bin/cache.sh hash "<topic>"` → 12-char hex. (Use `bash bin/cache.sh …` so the skill works whether or not the executable bit survived framework sync.)
2. **Check cache** (unless `--no-cache`): `bash bin/cache.sh read-plan "<topic>"`.
   - On hit: prepend the cache-hit block from `decomposition-lens.md § Re-Run UX`, then show the cached plan.
   - On miss: proceed to generate a fresh plan.
3. **Generate plan** per the 3-axis template. Select topic-class allowlist from `source-ladder.md`. Pick complexity tier (simple / comparative / architecture-audit) and set budget accordingly.
4. **STOP**. You MUST NOT call any tool — no WebSearch, no WebFetch, no subagent spawn — until the user responds.
5. **Accept user response**:
   - `approve` → write the plan via `bash bin/cache.sh write-plan "<topic>" <tempfile>`, then proceed to Phase 2.
   - `edit: <instructions>` → apply edits, re-emit plan, wait again.
   - `rebuild` → discard and re-plan from scratch, wait again.
   - Anything else → ask clarifying.

## Phase 2 — Research

Spawn subagents per the approved plan. Each subagent receives:

- Its assigned axis.
- The relevant sub-questions from the plan.
- The source-ladder rules.
- The topic-class allowlist as the WebSearch `allowed_domains` parameter.
- Output schema: one claim per line, format `[Tier X] <claim> — <URL>`.

Subagents MUST NOT merge each other's work — parallel, axis-disjoint; the lead reconciles later.

## Phase 3 — Adversarial Source Check

Apply `adversarial-search.md`.

1. Enumerate load-bearing upstream primitives surfaced by Phase 2 (env vars, hook names, API methods, CLI flags, config keys, library functions).
2. For each primitive, execute the three mandatory searches (issue-filtered, failure-keyword, version-filtered).
3. Collect every contradicting hit (docs say X, issues say X is broken under condition Y).
4. These contradictions feed Phase 4 (Convergence) as "conflict" rows and Phase 5 (Synthesis) as the `## Known Upstream Issues` section.

This phase exists because docs-as-truth bias is the #1 failure mode of design validation. Skipping it ships recommendations that break on issues the issue tracker already documents.

## Phase 4 — Convergence

Apply `verification.md § Convergence Step Protocol`.

1. Compile deduplicated claim list from Phase 2 + Phase 3.
2. Identify single-source claims.
3. Re-verify single-source Primary claims via WebFetch. Downgrade / remove if unsupported.
4. Resolve conflicts per the source ladder. Emit OVERRIDE blocks for any lower-tier-wins.
5. Emit the convergence log (MUST appear in final output).
6. Cache surviving facts: `bash bin/cache.sh write-facts "<topic>" <tempfile>`.

## Phase 5 — Synthesis + Citation Pass + Lens Check + Safety Pre-Mortem

Two-pass draft, then two mandatory cross-checks.

**Pass 1 — Draft.** Write Executive Summary, Detailed Analysis, Gaps & Risks, Recommendations. Work from the convergence-log fact set only — no new research in this phase.

**Pass 2 — Citation.** Re-read each Recommendation; attach specific URLs to each supporting claim. Mark any Recommendation whose citations don't hold as `DRAFT — NEEDS REWORK` and fix or cut.

**Lens Consultation (mandatory).** Apply `lens-consultation.md`. Read `.claude/lenses/README.md` (project-relative). For every alternatives comparison in the draft, apply each lens and emit a one-line result. Output the `## Lens Check` section — do NOT omit the header even for pure-research runs (say "not applicable" instead).

**Safety Pre-Mortem (conditional).** Apply `safety-premortem.md`. If Recommendations touch safety infrastructure (hooks, auth, gates, rate limiters, secrets, permissions), emit `## Runtime Failure Modes` with ≥3 states classified as fail-open / fail-closed / silent corruption. If no safety infra involved, still emit the header with "Not applicable — this investigation does not touch safety infrastructure."

**Known Upstream Issues (mandatory).** Emit the `## Known Upstream Issues` section from Phase 3 findings. Even if zero hits, the header MUST be present saying so explicitly.

## Phase 6 — Self-Judge

Apply `rubric.md § Self-Judge Rubric`. Score 5 axes. If average <0.8 OR any axis <0.5, prepend a `**QUALITY FLAG**` header. Do NOT suppress output — flag it.

Apply `rubric.md § Recommendation Rubric` per recommendation. Failing recommendations MUST be rewritten or cut.

If pairwise comparison (A vs B), apply the position-swap check.

Apply `verification.md § CoVe Factored Protocol` on 3–5 load-bearing claims. Independent verifier subagents — they MUST NOT see the draft.

## Phase 7 — Consensus / Debate (Opt-In)

Only if `--consensus` or `--debate` flag is set.

**Consensus** (Self-Consistency; Wang et al. ICLR 2023, arXiv 2203.11171): N=3 synthesis subagents from the same fact set; majority-vote top recommendation. No majority → note as unstable, cut.

**Debate** (Multi-Agent Debate; Liang et al. EMNLP 2024, arXiv 2305.19118): One round: affirmative defends prior position, negative argues alternative, judge decides. Triggered only if convergence found disagreeing Tier A sources.

Re-run Phase 6 (self-judge) on the refined output.

## Output Format

```
**QUALITY FLAG** (only if rubric failed)

## Executive Summary
<3–5 bullets>

## Detailed Analysis
<organized by the 3 axes from the plan; each claim tier-tagged>

## Claim Confidence
<load-bearing claims tagged Primary/Secondary/Tertiary/Unverified>

## Known Upstream Issues     ← MANDATORY — populated by Phase 3
<contradicting hits with citations + impact, or explicit "None found after adversarial search against: X">

## Runtime Failure Modes     ← MANDATORY — populated by Phase 5 Safety Pre-Mortem
<≥3 states with Trigger/Behavior/Recovery/Classification, or "Not applicable — no safety infra touched">

## Lens Check                ← MANDATORY — populated by Phase 5 Lens Consultation
<one line per lens applied/not applicable, or "Not applicable — pure research task">

## Gaps & Risks
<ranked by severity; include position-swap disagreements>

## Recommendations
<each one: links to specific gap, tier-bounded, reversibility/cost noted, alternative named>

## Convergence Log
<from Phase 4; the evidence the protocol ran>

## Sources
<all URLs cited, grouped by tier>

## OVERRIDE blocks (if any)
<per source-ladder.md override rule>

---
Approved plan: plans/<hash>.md | Cache: {hit|miss|skipped}
```

## Language Discipline

Use MUST / MUST NOT throughout when writing subagent prompts and intermediate instructions. Avoid "should" or "try to" — deontic language reduces drift.

## Quality Bar

- No unsourced claims about best practices.
- Every upstream primitive in load-bearing claims has been adversarially searched.
- Safety-infra recommendations have pre-mortem coverage (≥3 states, each classified).
- Lens Check present (even if result is "not applicable").
- Known Upstream Issues header present (even if zero hits).
- Convergence log present (proof verification ran).
- Claim Confidence section present; no Recommendation exceeds the tier of its supporting claim.
- Appropriately critical — acknowledge strengths without hedging on weaknesses.
