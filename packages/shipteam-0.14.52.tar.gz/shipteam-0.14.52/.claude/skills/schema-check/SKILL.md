---
name: schema-check
description: Verify database table schema before writing migrations. Use before any migration work to confirm column names, types, and constraints.
allowed-tools: Bash Read Grep Glob
argument-hint: "<table_name>"
---

Verify the schema for table: $ARGUMENTS

## Steps

1. **Find the CREATE TABLE statement**:
   Search migration files for the table creation and all ALTER TABLE statements.
   ```bash
   grep -rn "CREATE TABLE.*$ARGUMENTS" migrations/ backend/database/migrations/ --include="*.sql" 2>/dev/null
   grep -rn "ALTER TABLE.*$ARGUMENTS" migrations/ backend/database/migrations/ --include="*.sql" 2>/dev/null
   ```

2. **List all columns with types**:
   Extract column names, types, defaults, and constraints from the migration files.

3. **Check for constraints**:
   Find CHECK constraints, UNIQUE constraints, and foreign keys for this table.

4. **Check for access control policies**:
   Find any row-level security policies or equivalent for this table.

5. **Find repository/model usage**:
   Search application code for how this table is queried (column names used in SQL or ORM).

6. **Output summary**:
   Present a clear table of: column name | type | nullable | default | constraints

## Important
- NEVER guess column names -- only report what you find in migration files
- If a column was added via ALTER TABLE in a later migration, include it
- Flag any discrepancies between migration SQL and application model definitions
