# Lens: Explicit Trade-off

> *Name the rejected alternative and the cost of rejecting it. If you can't, you're not making a decision — you're following a default.*

## When to apply

Any time you choose one approach over another, especially when:
- You're about to say "for consistency" / "to match existing patterns"
- The choice is so obvious you don't feel like explaining it
- You're removing an option from consideration without articulating why
- A review asks "why did you do it this way?" and your first instinct is "that's how we always do it"

## Core question it forces

**What am I giving up, and is the cost worth naming?**

A good decision has a loser. Articulating the loser forces you to check whether the default ("consistency," "simplicity," "what we know") is actually serving the current situation or just coasting on inertia.

## Worked example

Choosing bash over Python for a 15-line hook shim. Two framings:

**Framing without the lens**: *"I'll write the shim in bash because it's lighter."*

Sounds reasonable. Also wouldn't survive a code review that asks "why not Python like everything else?" because the counter-argument was never articulated.

**Framing with the lens**: *"Consistency with existing Python hooks isn't worth the latency tax. Every hook fires on every tool call (~100-200 per session). Python cold-start is ~40ms; bash is ~3ms. The shim does pure path resolution — no Python capability is used. The cost of breaking language consistency is low (one new file, one new skillset — bash is not exotic). The cost of preserving it is ~8 seconds of per-session latency for zero functional value. Consistency loses."*

Now the decision is auditable. A reviewer who disagrees can attack a specific claim ("8 seconds isn't meaningful for our workflows") rather than waving at general taste.

## Anti-patterns it catches

- **Consistency-as-argument.** "For consistency with X" is not an argument; it's a preference. Convert to explicit trade-off: *what does consistency buy, what does abandoning it cost?*
- **Status-quo bias.** "That's how we do it" → ask: *if we were choosing today from scratch, would we still pick this?*
- **Invisible defaults.** Unstated assumptions passed through code review because nobody articulated what the alternative would have been.
- **False binaries.** Listing only two options and quietly eliminating the third without saying why.
- **"Obviously X."** When something feels obvious, the lens forces you to write down *why* — and occasionally the exercise reveals the obvious answer is wrong.

## Past failure it would have prevented

**Hook-shim language choice, this session.** Initial reasoning was "use Python for consistency." Lens reframed as: *Consistency with existing Python hooks is worth ~X. Cost of breaking it is ~Y. Compare.* Once the costs are named, the answer flips. The lens doesn't pick bash — it forces the comparison that makes bash the obvious choice.

**Broader pattern across the framework.** Every time someone writes "for consistency" or "to match the existing pattern" in a commit message or PR description without naming the alternative, a decision is being made invisibly. Running this lens retroactively on past decisions surfaces several "we chose X because Y was already there" patterns whose Y-side cost was never measured.

## Reasoning cadence

When making any non-trivial choice, produce a two-line disclosure:

```
Chosen: <approach> — <what it costs, what it buys>
Rejected: <approach> — <what we'd gain by picking it, what it costs>
```

If the "Rejected" line is empty or says "no good alternative," pause. There is almost always an alternative; if you can't name it, you haven't looked.

## Distinction from fit-for-purpose

`fit-for-purpose` asks whether a tool matches a task. `explicit-tradeoff` asks whether any choice — tool or otherwise — has been made deliberately rather than by default. A choice can pass fit-for-purpose and still fail explicit-tradeoff if it was made without considering the alternative.
