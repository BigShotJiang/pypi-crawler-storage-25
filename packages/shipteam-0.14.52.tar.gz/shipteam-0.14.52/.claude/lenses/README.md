# Reasoning Lenses

> Advisory, not mandatory. Lenses are *how to think* about a decision. Rules (`.claude/rules/`) are *what you must do*. Don't confuse them.

## What a lens is

A short, named reasoning pattern that pressure-tests a common default. Each lens asks one core question. Applied at decision time, it forces the reasoner to externalize an assumption that usually stays implicit.

## How lenses are used

- **/deep-r** consults lenses when comparing alternatives (mandatory Lens Consultation step).
- **/deep-r-audit** applies lenses when ranking latent infrastructure risks.
- **fw-advisor-architecture** cites relevant lenses in its approach comparisons.
- **fw-review-maintainability** and **fw-review-performance** reference lenses in findings to explain *why* a pattern is problematic, not just *that* it is.
- Authors picking tools/languages/patterns can invoke a lens by name in conversation to force an explicit weighing.

## The bar for admitting a new lens

A lens file must satisfy ALL of:

1. **Concrete past failure.** It cites a real failure (in this framework, a downstream project, or a well-known public incident) that applying the lens would have prevented. No hypotheticals.
2. **One question.** It forces exactly one question. If it has three questions, it's three lenses — or it's unfocused.
3. **Resists a common default.** It opposes something most engineers do by reflex (choose the familiar tool, optimize for consistency, skip cost math).
4. **Short.** ~60-120 lines. If a lens needs more, it's probably a rule, a pattern doc, or an ADR.

## Current lens set (cap: ~8)

| Lens | Core question | Resists default |
|------|---------------|-----------------|
| [hot-path-latency](hot-path-latency.md) | `cost_per_call × calls_per_session` — is this budget acceptable? | Ignoring per-call overhead on infrastructure that fires often |
| [failure-domain-isolation](failure-domain-isolation.md) | Does the thing that locates/launches X share deps with X? | Reusing the same runtime/language everywhere for consistency |
| [fit-for-purpose](fit-for-purpose.md) | Does this task actually need what this tool provides? | Choosing the more capable tool because it's available |
| [explicit-tradeoff](explicit-tradeoff.md) | What am I giving up, and is the cost worth naming? | Defaulting to the status quo or an unnamed ambient convention |

## Anti-patterns to avoid when writing lenses

- **Kitchen-sink lenses** ("good engineering" — too broad). A lens that could apply to any decision applies to none usefully.
- **Restating rules.** If the content is "you must X," it's a rule, not a lens.
- **Stacking with existing lenses without differentiation.** Before adding a lens, explain in its *Past failure* section why an existing lens wouldn't have caught the same failure.
- **Style/aesthetic lenses.** ("Prefer composition over inheritance" — that's a pattern, not a lens.)

## When to retire a lens

If six months pass without a lens being cited in any /deep-r output, agent finding, or ADR, it's decoration. Retire it by moving to `.claude/lenses/archive/` with a note on why it wasn't useful.
