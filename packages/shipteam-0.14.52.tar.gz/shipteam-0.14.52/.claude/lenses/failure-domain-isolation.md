# Lens: Failure Domain Isolation

> *The thing that locates, launches, or supervises a component should not share its failure modes.*

## When to apply

Anywhere a dispatcher, supervisor, launcher, or bootstrap sits in front of the component it manages:
- Process launchers (init systems, hook dispatchers, script runners)
- Health checkers (a health check written in the same runtime as the service it checks cannot detect runtime-death)
- Fallback handlers (a fallback that depends on the same DB as the primary)
- Configuration loaders (config loaders that need the config to load)
- Boot scripts (the thing that starts the system can't depend on the system being started)

## Core question it forces

**Does the thing that locates/launches/recovers X share critical dependencies with X?**

If yes, a single failure in a shared dependency takes down both the component AND the mechanism supposed to detect, launch, or recover it. Two failures at once, with the diagnostic layer blinded.

## Worked example

Claude Code hook dispatcher shim. The shim's job is to resolve a path and `exec` a Python hook.

**Option 1: Python shim.** Imports Python, resolves path, `exec`s target hook.
- If Python install is broken (version mismatch, site-packages corruption, missing `sys.path` entry), the shim fails. User sees a Python traceback from the *dispatcher*, not the hook. Diagnosis: is it my hook code? Is it the dispatcher? Both? The error surface is ambiguous because both layers fail together.

**Option 2: Bash shim.** Resolves path in shell, `exec`s target hook.
- If Python is broken, the shim succeeds and Python fails — at the target. The error message is unambiguous: "your hook's Python couldn't import X." Dispatcher isolation preserved.

The bash shim is not "better at path resolution" than Python. It's **independently failing**, which is the property that matters here.

## Anti-patterns it catches

- **Self-monitoring systems without out-of-band channels.** Service reports its own health via the same network it runs on — the moment the network fails, so does the health signal.
- **"One language to rule them all."** Teams that standardize on a single runtime lose the independence that comes from heterogeneous failure modes.
- **Init scripts written in the thing being inited.** Running `npm run build` to build npm itself.
- **Fallback that shares the primary's blast radius.** Redis cache falling back to the same Redis instance via a different key prefix.
- **Circular safety gates.** The safety gate that prevents `cd` to bad directories… runs from the directory you cd'd to.

## Past failure it would have prevented

**dev-framework cwd-deadlock bug (2026-04).** The PreToolUse hook `no-cd-commands.py` was designed to block dangerous `cd` commands. But it was invoked via relative path, resolved against the shell's cwd. When cwd drifted into a removed worktree, the hook file couldn't be found. The tool call to `cd` back failed because the hook that gates `cd` also couldn't be found — the gate and the navigation primitive it gated shared the same failure mode (cwd resolution). Unrecoverable from inside the session. This lens would have caught it at design time: the mechanism that gates navigation cannot itself depend on the thing it's gating.

## Reasoning cadence

When designing any launcher/dispatcher/supervisor/gate, draw the dependency graph of the **supervising layer** separately from the **supervised component**. Any shared node is a risk — document it as "co-failure" and decide explicitly whether the co-failure is acceptable or requires isolation.

Pattern to look for in reviews: does layer A call layer B to launch/locate layer B? That's almost always a circular-dependency smell.
