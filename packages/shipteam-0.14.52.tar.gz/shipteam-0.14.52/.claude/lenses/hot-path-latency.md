# Lens: Hot-Path Latency

> *Before choosing a language, library, or tool for a utility that runs on every invocation of something, compute its per-call cost × invocation frequency.*

## When to apply

Any code path that runs on:
- Every tool call (hooks, middleware, interceptors)
- Every request (web middleware, auth checks, request logging)
- Every render (React component wrappers, HOCs, context providers)
- Every commit (git hooks, pre-commit frameworks)
- Every test (test setup, fixture loading)

If the thing executes hundreds or thousands of times in a normal session, it's a hot path.

## Core question it forces

**`cost_per_call × calls_per_session` — is this budget acceptable?**

Not *is this fast?* — speed is relative. *Is this budget acceptable given what this component does?* A 40ms cold-start is negligible for a once-per-deploy task and catastrophic for a per-tool-call hook.

## Worked example

Choosing the language for a Claude Code hook dispatcher (the shim that locates and launches the real hook):

| Language | Cold-start | 100-call session | 500-call session |
|----------|-----------|------------------|------------------|
| bash | ~3ms | 0.3s | 1.5s |
| python3 | ~40ms | 4.0s | 20.0s |
| node | ~60ms | 6.0s | 30.0s |

The shim's job is 15 lines of path resolution. It gains nothing from Python's stdlib. The "consistency with existing Python hooks" argument loses to 20 seconds of accumulated latency per long session.

If the dispatcher needed JSON parsing, subprocess management, or stdlib crypto — the math flips. Lens doesn't prescribe bash; it prescribes *doing the math*.

## Anti-patterns it catches

- **"We use Python everywhere."** Consistency is cheap to claim and expensive when misapplied to hot paths.
- **"It's fast enough on my machine."** Single-shot timing ignores the per-session multiplier.
- **"We can optimize later."** Hot-path utilities tend to stay in place forever; the cost compounds across every project that inherits them.
- **Framework-of-the-week syndrome.** Pulling in a 50MB runtime for 15 lines of logic.
- **Transparent wrappers with non-transparent cost.** Shims, adapters, and facades are tempting because they "just pass through" — but every pass-through has a cost-per-call.

## Past failure it would have prevented

**dev-framework hook-path-resolution bug (2026-04, documented in this session).** The /deep-r research correctly identified that `$CLAUDE_PROJECT_DIR` is broken in Claude Code v2.1.74+ and recommended a shim. Shim language was initially underspecified. Without this lens, the default would have been "write the shim in Python to match the existing hooks." That choice would have added ~40ms to every PreToolUse hook fire — ~8 seconds per typical session — for zero functional benefit, because the shim does only shell-level path resolution. The lens forced the math and bash was chosen. The framework's entire per-session latency budget would have quietly degraded otherwise.

## Reasoning cadence

When the lens applies, add two lines to your analysis:

```
Per-call cost: <measured or estimated>ms
Invocations per session: <lower bound>
```

If the product is > 1 second, the choice needs explicit justification. If > 5 seconds, the choice is almost certainly wrong unless the utility genuinely requires what the heavier tool provides.
