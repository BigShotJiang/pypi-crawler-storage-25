# Lens: Fit-for-Purpose

> *Tool choice should be driven by what the task actually needs, not by what the tool is capable of.*

## When to apply

Any choice of:
- Language for a utility
- Framework for a feature
- Library for a one-off integration
- Data store for a new entity
- Abstraction for a piece of logic

Especially when the candidate tool is already "in the stack" and reaching for it feels free.

## Core question it forces

**Does this task actually need what this tool provides?**

A tool earns its keep through the specific capabilities it provides that alternatives don't. If the task uses none of those capabilities, the tool's cost (complexity, dependency weight, cold-start, cognitive load) is pure overhead.

## Worked example

A 15-line script that needs to: (1) read two env vars, (2) run one subprocess, (3) forward stdin and exit code.

| Tool | What you use | What you pay for but don't use |
|------|--------------|--------------------------------|
| Python | subprocess, os.environ | import system, site.py, pathlib, dataclasses, async runtime, site-packages, version-pin discipline |
| Node | child_process, process.env | V8, npm, package.json, tsconfig.json, 300MB node_modules tree |
| bash | `exec`, `$VAR` | almost nothing — the shell is already there |

None of the Python/Node-specific capabilities are exercised. The task is so shell-native that reaching for anything above shell imports costs without benefit.

Flip side: a script that needs to parse JSON, make 3 HTTP calls, retry with exponential backoff, and emit structured logs — bash becomes the wrong choice because it doesn't provide those capabilities cleanly. Fit-for-purpose cuts both ways.

## Anti-patterns it catches

- **"We already use X."** True, but irrelevant if the task doesn't need X.
- **Resume-driven development.** Choosing a tool because it's new/trendy, not because it fits.
- **Framework reach.** Wiring a feature flag system through a React Context Provider when a single `window.FEATURES` object would do.
- **Premature abstraction library-ification.** Extracting a 3-line helper into an npm-published package.
- **Capability inflation.** Using Kubernetes for a process manager. Using Kafka for a task queue of 10 messages/day. Using Terraform for a one-line aws-cli invocation.

## Past failure it would have prevented

**This session, hook-dispatcher language choice.** The initial instinct was Python because every existing hook is Python. The task — resolve a path, exec a file — uses zero Python-specific capability. Python's import system, exception machinery, and stdlib were all pure overhead for this job. The `fit-for-purpose` question ("does this task actually need what Python provides?") produces a clear "no" and eliminates the choice. Without the lens, ambient consistency wins by default and Python is chosen despite adding ~40ms cold-start per invocation for no functional benefit.

## Reasoning cadence

When considering a tool for a task, write two lists:

1. **Capabilities this task genuinely needs.** Be specific: "parse JSON," "make concurrent HTTP calls," "maintain a long-lived process."
2. **Capabilities this tool provides over the alternatives.** Also specific.

If list 2 doesn't overlap list 1, the tool is wrong for the task. The overlap test resists both capability inflation ("we'll need it eventually") and ambient-inertia ("we use it everywhere").

## Distinction from hot-path-latency

`hot-path-latency` is about *cost at scale* (cost_per_call × calls). `fit-for-purpose` is about *value vs. cost* regardless of scale. A tool can be fit-for-purpose but still wrong on a hot path (expensive for its niche). A tool can be lightweight but not fit-for-purpose (cheap but doesn't do what you need).
