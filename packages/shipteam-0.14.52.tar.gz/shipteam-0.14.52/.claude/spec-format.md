# `.sherlock-plan.md` Format (Spec-Anchored)

> Single source of truth for the Sherlock plan artifact format. Referenced by `sherlock-methodology.md`, `fw-tdd-red.md`, and `fw-author-spec.md`.

When creating the plan artifact at end of Full Sherlock Phase 4 (architecture approved) or Sherlock Lite Phase 1 (plan approved):

```markdown
# Sherlock Plan: [Feature/Fix Title]
Created: [ISO date]
Tier: Full Sherlock | Sherlock Lite
Status: APPROVED — Executing

## Lead Judgment
<!-- Written by the lead at plan creation. Survives compaction because it's in this file. -->
<!-- Update on major pivots only (not per-phase — use Decision Digest for that). -->
<!-- No MEMORY.md body content here — title-only citations ONLY if citing a user preference. -->

### Priority Stack
<!-- 3-5 bullets. What matters most and WHY. This is the anti-snacking/anti-preening gate (Larson). -->
<!-- Each bullet: [priority, 1 sentence] — [reasoning, 1 sentence]. -->
1. [Priority item] — [reasoning]
2. ...

### Risk Watch
<!-- ≥1 bullet. Risks SPECIFIC to this changeset (not generic "tests might fail"). -->
<!-- Each bullet: [risk] — [mitigation or monitoring plan]. -->
- [Specific risk] — [mitigation]

## Scope Boundaries
- IN SCOPE: [bullet list]
- OUT OF SCOPE: [bullet list]

## Architecture Decision
Approach chosen: [Minimal/Clean/Pragmatic]
Summary: [1-2 sentences]
Rationale: [Why this approach over alternatives — extracted to ADR post-commit]

## Acceptance Criteria
<!-- Given/When/Then format. Each criterion maps to 1+ test cases in RED phase. -->
<!-- This is the STRUCTURED SPEC — it replaces prose requirements for TDD agents. -->

### AC-1: [Short descriptive name]
- **Given** [precondition]
- **When** [action]
- **Then** [expected outcome]

### AC-2: [Short descriptive name]
- **Given** [precondition]
- **When** [action]
- **Then** [expected outcome]

### AC-3: [Error/edge case name]
- **Given** [precondition]
- **When** [invalid action or boundary condition]
- **Then** [error behavior or graceful handling]

## Interface Contracts
<!-- Type signatures, API shapes, data contracts. Feeds both RED and GREEN phases. -->
<!-- Use the project's language. Omit for doc-only or config-only changes. -->

\`\`\`typescript
// Function signatures
export function processWidget(input: WidgetInput): WidgetResult;

// API endpoint contracts
// POST /api/widgets
// Request: { name: string; config: WidgetConfig }
// Response: { id: string; status: 'created' | 'failed' }
// Error: { error: string; code: number }
\`\`\`

## Planned Files
| File | Action | Reason |
|------|--------|--------|
| path/to/file.ts | CREATE | [why] |
| path/to/other.ts | MODIFY | [why] |
| path/to/test.test.ts | CREATE | [why] |

## Planned Tests
| Test File | Covers | Acceptance Criteria |
|-----------|--------|---------------------|
| path/to/test.test.ts | [module] | AC-1, AC-2, AC-3 |

## TDD Phase Plan
- Phase 1: [core logic — RED/GREEN/REFACTOR — covers AC-1, AC-2]
- Phase 2: [error handling — RED/GREEN/REFACTOR — covers AC-3]

## Pivot Log
<!-- Append entries when implementation diverges from plan (scope deviations only) -->
<!-- Format: | Date | Phase | Planned | Actual | Reason | -->

## Decision Digest
<!-- Populated ONLY after TDD phase reviews begin. Empty at plan creation — do not fill pre-execution. -->
<!-- Review OUTCOMES, not scope deviations (that's Pivot Log). -->
<!-- Always append — even if zero findings (that's a signal). -->
<!-- NO MEMORY.md content: Digest bullets must not quote, paraphrase, or reference MEMORY.md body content. Cite feedback or priorities in terms of the plan's own Lead Judgment, not by pointing back to memory. -->
<!-- Format (one block per phase): -->

### Phase N Review — YYYY-MM-DD
- Fired: [list of review agents run]
- Critical/High: [issues addressed — or empty if none]
- Deferred: [items + explicit reason — or empty]
- Inherited to next phase: [open work — or "none"]
- Digest: [≤1 sentence synthesis; if zero findings: "no blocking issues, proceeding"]
```

## Spec Section Guidelines

- **Lead Judgment**: Required for both Sherlock Lite and Full. Hudson is exempt (no plan artifact). Priority Stack forces the lead to externalize priorities so they survive compaction. Risk Watch forces proactive risk-flagging at plan time — not after a reviewer surfaces it. Must NOT contain MEMORY.md body content (security: ADR-007 bright-line sanitization). Title-only entry names (e.g., `[Bundle entangled doc refactors]`) are permitted **only in the live conversation stream** — do NOT write them into this plan file or any other persisted artifact.
- **Acceptance Criteria**: Write at minimum 1 happy path, 1 edge case, 1 error case. The fw-tdd-red agent uses these directly as test definitions and may add additional edge cases beyond the ACs to meet its coverage requirements.
- **Interface Contracts**: Include for any change that introduces new functions, types, or API endpoints. Omit for doc/config/CSS-only changes.
- **Decision Digest**: Appended after every per-phase review gate by the lead. One block per phase; append-only (never rewrite prior phases). Always write an entry — empty findings is itself a signal and should be captured with `Digest: no blocking issues, proceeding`. Do not conflate with Pivot Log (which is scope-deviation only). **No MEMORY.md content allowed** (body OR titles) — the Digest is a persisted artifact subject to the same sanitization rule as Lead Judgment.
- **Sherlock Lite**: Lead Judgment + Acceptance Criteria required. Interface Contracts required if introducing new interfaces. Architecture Decision section is simpler (single approach, brief rationale).
- **Full Sherlock**: All sections required. Architecture Decision includes full rationale (becomes ADR).
