#!/usr/bin/env python3
"""
Commit Trust Verification Hook - Runs on EVERY user prompt submission.

This hook verifies that the current HEAD commit has passed CI checks
and (for main branch) that production is healthy.

Verification Levels:
  - Feature branches: CI must pass on HEAD commit
  - Main branch: CI + production health + commit age warning (< 1 hour)

Exit codes:
  0 = Allow (verification passed or bypassed)
  1 = Block (verification failed)

Cache: Results are cached in .claude/trust-cache.json to avoid
repeated API calls within the same session. Cache auto-invalidates
when HEAD changes on a branch.

Configuration (config/framework.yaml):
  hooks.deploy_gate: true/false — controls whether fw-sync distributes this hook
  deployment.health_url: "" — production health endpoint; empty = skip health check

Usage: Added to settings.local.json as UserPromptSubmit hook
"""

import json
import os
import subprocess
import sys
import time
from pathlib import Path

# Import worktree-aware path utilities
try:
    from path_utils import get_project_root, get_config, GIT_ENV, get_current_branch
    PROJECT_ROOT = get_project_root()
except ImportError:
    PROJECT_ROOT = Path.cwd()
    while PROJECT_ROOT != PROJECT_ROOT.parent:
        if (PROJECT_ROOT / '.git').exists():
            break
        PROJECT_ROOT = PROJECT_ROOT.parent

    def get_config(key, default=""):
        return default

    GIT_ENV = {
        **os.environ,
        'GIT_DIR': str(PROJECT_ROOT / '.git'),
        'GIT_WORK_TREE': str(PROJECT_ROOT)
    }

    def get_current_branch() -> str:
        try:
            result = subprocess.run(
                ['git', 'rev-parse', '--abbrev-ref', 'HEAD'],
                capture_output=True, text=True,
                cwd=str(PROJECT_ROOT), env=GIT_ENV, timeout=10
            )
            return result.stdout.strip() if result.returncode == 0 else "UNKNOWN"
        except Exception:
            return "UNKNOWN"

CACHE_FILE = PROJECT_ROOT / ".claude" / "trust-cache.json"
BYPASS_FLAG_FILE = PROJECT_ROOT / ".claude" / "trust-bypass.flag"
CACHE_TTL_SECONDS = 300  # 5 minutes
COMMIT_AGE_WARNING_SECONDS = 3600  # 1 hour
BYPASS_FLAG_MAX_AGE_SECONDS = 3600  # 1 hour


# =============================================================================
# Cache Management
# =============================================================================

def load_cache() -> dict:
    """Load cached verification results."""
    try:
        if CACHE_FILE.exists():
            data = json.loads(CACHE_FILE.read_text())
            if isinstance(data, dict) and "version" in data:
                return data
    except (json.JSONDecodeError, IOError) as e:
        print(f"[commit-trust] WARNING: Could not load trust cache: {e}", file=sys.stderr)
    return {"version": 1, "entries": {}}


def save_cache(cache: dict) -> None:
    """Save verification results to cache."""
    try:
        CACHE_FILE.parent.mkdir(parents=True, exist_ok=True)
        CACHE_FILE.write_text(json.dumps(cache, indent=2))
    except IOError as e:
        print(f"[commit-trust] WARNING: Could not save trust cache: {e}", file=sys.stderr)


def get_cache_key(commit_sha: str, branch: str) -> str:
    """Generate cache key from commit and branch."""
    short_sha = commit_sha[:7] if len(commit_sha) >= 7 else commit_sha
    branch_safe = branch.replace("/", "-")
    return f"{short_sha}_{branch_safe}"


def invalidate_stale_branch_entries(current_sha: str, branch: str) -> int:
    """
    Invalidate cached entries for a branch when HEAD has changed.

    When a new commit is pushed, old cache entries for the same branch
    become stale and should be removed to prevent blocking based on
    outdated CI results.

    Returns:
        Number of entries invalidated
    """
    cache = load_cache()
    branch_safe = branch.replace("/", "-")
    invalidated = 0

    # Find all entries for this branch with a different commit SHA
    keys_to_remove = []
    for key, entry in cache.get("entries", {}).items():
        if key.endswith(f"_{branch_safe}"):
            cached_sha = entry.get("commit_sha", "")
            if cached_sha:
                min_len = min(len(cached_sha), len(current_sha), 7)
                if cached_sha[:min_len] != current_sha[:min_len]:
                    keys_to_remove.append(key)

    for key in keys_to_remove:
        del cache["entries"][key]
        invalidated += 1

    if invalidated > 0:
        save_cache(cache)

    return invalidated


def get_cached_result(commit_sha: str, branch: str) -> dict | None:
    """Get cached result if still valid (within TTL)."""
    invalidate_stale_branch_entries(commit_sha, branch)

    cache = load_cache()
    key = get_cache_key(commit_sha, branch)

    if key in cache.get("entries", {}):
        entry = cache["entries"][key]
        age = time.time() - entry.get("timestamp", 0)
        if age < CACHE_TTL_SECONDS:
            return entry
    return None


def cache_result(commit_sha: str, branch: str, result: dict) -> None:
    """Cache a verification result with timestamp."""
    cache = load_cache()
    key = get_cache_key(commit_sha, branch)

    cache["entries"][key] = {
        **result,
        "timestamp": time.time(),
        "commit_sha": commit_sha,
        "branch": branch
    }
    save_cache(cache)


# =============================================================================
# Git Operations
# =============================================================================

def get_current_commit() -> str:
    """Get HEAD commit SHA using git worktree env vars."""
    try:
        result = subprocess.run(
            ['git', 'rev-parse', 'HEAD'],
            capture_output=True, text=True,
            cwd=str(PROJECT_ROOT), env=GIT_ENV, timeout=10
        )
        if result.returncode == 0:
            return result.stdout.strip()
        return "UNKNOWN"
    except Exception:
        return "UNKNOWN"


def get_commit_age_seconds(commit_sha: str) -> int:
    """Get age of commit in seconds."""
    try:
        result = subprocess.run(
            ['git', 'log', '-1', '--format=%ct', commit_sha],
            capture_output=True, text=True,
            cwd=str(PROJECT_ROOT), env=GIT_ENV, timeout=10
        )
        if result.returncode == 0:
            commit_time = int(result.stdout.strip())
            return int(time.time() - commit_time)
        return -1
    except Exception:
        return -1


# =============================================================================
# CI Status Verification
# =============================================================================

def check_ci_status(commit_sha: str) -> dict:
    """
    Check CI status for a specific commit using gh CLI.

    Returns:
        {
            "passed": bool,
            "status": "success" | "failure" | "pending" | "not_found" | "error",
            "workflow_name": str | None,
            "error": str | None,
            "graceful": bool  # If True, should warn but allow
        }
    """
    try:
        result = subprocess.run(
            ['gh', 'run', 'list', '--commit', commit_sha,
             '--json', 'status,conclusion,name', '--limit', '5'],
            capture_output=True, text=True,
            cwd=str(PROJECT_ROOT), env=GIT_ENV, timeout=15
        )

        if result.returncode == 127 or "command not found" in result.stderr.lower():
            return {
                "passed": False, "status": "error",
                "error": "gh CLI not found - install GitHub CLI to enable CI checks",
                "graceful": True
            }

        if "rate limit" in result.stderr.lower():
            return {
                "passed": False, "status": "error",
                "error": "GitHub API rate limit exceeded",
                "graceful": True
            }

        if result.returncode != 0:
            return {
                "passed": False, "status": "error",
                "error": result.stderr.strip() or "Unknown gh error",
                "graceful": True
            }

        try:
            runs = json.loads(result.stdout)
        except json.JSONDecodeError:
            return {
                "passed": False, "status": "error",
                "error": "Invalid JSON from gh CLI",
                "graceful": True
            }

        if not runs:
            return {
                "passed": False, "status": "not_found",
                "workflow_name": None, "graceful": False
            }

        latest_run = runs[0]
        status = latest_run.get("status", "").lower()
        conclusion = latest_run.get("conclusion", "")
        workflow_name = latest_run.get("name", "Unknown")

        if status in ("in_progress", "queued"):
            return {
                "passed": False, "status": "pending",
                "workflow_name": workflow_name, "graceful": False
            }

        if conclusion == "success":
            return {
                "passed": True, "status": "success",
                "workflow_name": workflow_name, "graceful": False
            }
        else:
            return {
                "passed": False, "status": "failure",
                "workflow_name": workflow_name, "graceful": False
            }

    except subprocess.TimeoutExpired:
        return {
            "passed": False, "status": "error",
            "error": "GitHub API timeout", "graceful": True
        }
    except Exception as e:
        return {
            "passed": False, "status": "error",
            "error": str(e), "graceful": True
        }


# =============================================================================
# Production Health Verification
# =============================================================================

def check_production_health() -> dict:
    """
    Check production health using deployment.health_url from config.
    Skips health check if no URL is configured (CI-only mode).

    Returns:
        {
            "healthy": bool,
            "version": str | None,
            "error": str | None,
            "graceful": bool
        }
    """
    health_url = get_config("deployment.health_url")

    # No health URL configured = CI-only mode, skip health check
    if not health_url:
        return {
            "healthy": True,
            "version": None,
            "graceful": True
        }

    # Validate URL scheme to prevent SSRF via file://, gopher://, etc.
    from urllib.parse import urlparse
    parsed = urlparse(health_url)
    if parsed.scheme not in ("http", "https"):
        return {
            "healthy": False, "version": None,
            "error": f"Invalid health URL scheme: {parsed.scheme} (only http/https allowed)",
            "graceful": True
        }

    try:
        result = subprocess.run(
            ['curl', '-s', '-f', '--max-time', '10', health_url],
            capture_output=True, text=True, timeout=15
        )

        if result.returncode != 0:
            return {
                "healthy": False, "version": None,
                "error": result.stderr.strip() or "Health check failed",
                "graceful": False
            }

        try:
            health_data = json.loads(result.stdout)
            version = health_data.get("version")
            status = health_data.get("status", "").lower()

            return {
                "healthy": status in ["healthy", "ok", "up"],
                "version": version, "graceful": False
            }
        except json.JSONDecodeError as e:
            print(f"[commit-trust] WARNING: Could not parse health response JSON: {e}", file=sys.stderr)
            return {
                "healthy": True, "version": None, "graceful": True
            }

    except subprocess.TimeoutExpired:
        return {
            "healthy": False, "version": None,
            "error": "Health check timeout", "graceful": True
        }
    except Exception as e:
        return {
            "healthy": False, "version": None,
            "error": str(e), "graceful": True
        }


# =============================================================================
# Bypass Mechanism
# =============================================================================

def check_bypass_flag() -> dict:
    """
    Check if bypass flag exists.

    Returns:
        {
            "bypass": bool,
            "method": "file" | "env" | None,
            "reason": str | None
        }
    """
    if os.environ.get("CLAUDE_TRUST_BYPASS") == "1":
        return {
            "bypass": True, "method": "env",
            "reason": "CLAUDE_TRUST_BYPASS=1 environment variable set"
        }

    if BYPASS_FLAG_FILE.exists():
        try:
            file_age = time.time() - BYPASS_FLAG_FILE.stat().st_mtime
            if file_age > BYPASS_FLAG_MAX_AGE_SECONDS:
                try:
                    BYPASS_FLAG_FILE.unlink()
                except IOError as e:
                    print(f"[commit-trust] WARNING: Could not delete stale bypass file: {e}", file=sys.stderr)
                return {
                    "bypass": False, "method": None,
                    "reason": "stale bypass file deleted (older than 1 hour)"
                }

            return {
                "bypass": True, "method": "file",
                "reason": f"Bypass file exists: {BYPASS_FLAG_FILE}"
            }
        except IOError as e:
            print(f"[commit-trust] WARNING: Could not check bypass file: {e}", file=sys.stderr)

    return {"bypass": False, "method": None, "reason": None}


# =============================================================================
# Main Verification Logic
# =============================================================================

def verify_commit_trust(commit_sha: str, branch: str) -> dict:
    """
    Verify trust for a commit on a given branch.

    Returns:
        {
            "decision": "allow" | "block",
            "reason": str,
            "warning": str | None,
            "ci_status": dict,
            "prod_health": dict | None
        }
    """
    is_main_branch = branch in ["main", "master"]

    ci_status = check_ci_status(commit_sha)

    if ci_status.get("status") == "error" and ci_status.get("graceful"):
        return {
            "decision": "allow",
            "reason": f"CI check skipped: {ci_status.get('error')}",
            "warning": f"Could not verify CI status: {ci_status.get('error')}",
            "ci_status": ci_status, "prod_health": None
        }

    if ci_status.get("status") == "not_found":
        return {
            "decision": "allow",
            "reason": "No CI runs found for this commit (new commit)",
            "warning": "This commit has no CI runs yet - proceed with caution",
            "ci_status": ci_status, "prod_health": None
        }

    if ci_status.get("status") == "pending":
        return {
            "decision": "allow",
            "reason": "CI is pending but allowing work to continue",
            "warning": f"CI is still running: {ci_status.get('workflow_name')}",
            "ci_status": ci_status, "prod_health": None
        }

    if ci_status.get("status") == "failure":
        return {
            "decision": "block",
            "reason": f"CI failed: {ci_status.get('workflow_name')}",
            "ci_status": ci_status, "prod_health": None
        }

    # CI passed — for feature branches, we're done
    if not is_main_branch:
        return {
            "decision": "allow", "reason": "CI passed",
            "ci_status": ci_status, "prod_health": None
        }

    # Main branch: also check production health
    prod_health = check_production_health()

    if prod_health.get("graceful"):
        return {
            "decision": "allow",
            "reason": "CI passed, production health check skipped",
            "warning": f"Could not verify production health: {prod_health.get('error')}",
            "ci_status": ci_status, "prod_health": prod_health
        }

    if not prod_health.get("healthy"):
        return {
            "decision": "block",
            "reason": f"Production is unhealthy: {prod_health.get('error', 'Unknown error')}",
            "ci_status": ci_status, "prod_health": prod_health
        }

    commit_age = get_commit_age_seconds(commit_sha)
    warning = None
    if 0 < commit_age < COMMIT_AGE_WARNING_SECONDS:
        warning = f"This commit is only {commit_age // 60} minutes old - not yet battle-tested"

    return {
        "decision": "allow",
        "reason": "CI passed and production is healthy",
        "warning": warning,
        "ci_status": ci_status, "prod_health": prod_health
    }


# =============================================================================
# Main Entry Point
# =============================================================================

def main():
    """Main entry point for the hook."""
    bypass_check = check_bypass_flag()
    if bypass_check["bypass"]:
        result = {
            "status": "TRUST_CHECK_BYPASSED",
            "bypass_method": bypass_check["method"],
            "warning": "Trust verification bypassed. Proceed with caution.",
        }
        print(json.dumps(result, indent=2))
        sys.exit(0)

    commit_sha = get_current_commit()
    branch = get_current_branch()

    if commit_sha == "UNKNOWN" or branch == "UNKNOWN":
        result = {
            "status": "TRUST_CHECK_SKIPPED",
            "warning": "Could not determine git state",
            "commit": commit_sha, "branch": branch
        }
        print(json.dumps(result, indent=2))
        sys.exit(0)

    cached = get_cached_result(commit_sha, branch)
    if cached:
        result = {
            "status": "TRUST_CHECK_PASSED" if cached.get("decision") == "allow" else "TRUST_CHECK_FAILED",
            "commit": commit_sha, "branch": branch,
            "cached": True, **cached
        }

        if cached.get("decision") == "block":
            result["action_required"] = "Fix failing CI or production health issues"
            result["bypass_instructions"] = f"touch {BYPASS_FLAG_FILE}"
            print(json.dumps(result, indent=2))
            sys.exit(1)

        print(json.dumps(result, indent=2))
        sys.exit(0)

    verification = verify_commit_trust(commit_sha, branch)
    cache_result(commit_sha, branch, verification)

    if verification["decision"] == "allow":
        result = {
            "status": "TRUST_CHECK_PASSED",
            "commit": commit_sha, "branch": branch,
            "reason": verification["reason"],
            "ci_status": verification.get("ci_status", {}).get("status"),
            "cached": False
        }
        if verification.get("warning"):
            result["warning"] = verification["warning"]
        if verification.get("prod_health", {}).get("version"):
            result["prod_version"] = verification["prod_health"]["version"]

        print(json.dumps(result, indent=2))
        sys.exit(0)
    else:
        result = {
            "status": "TRUST_CHECK_FAILED",
            "commit": commit_sha, "branch": branch,
            "reason": verification["reason"],
            "ci_status": verification.get("ci_status", {}).get("status"),
            "action_required": "Fix failing CI before continuing. Check your project's test command in config/framework.yaml.",
            "bypass_instructions": f"If this is an emergency, create bypass flag:\n  touch {BYPASS_FLAG_FILE}\n\nOr set environment variable:\n  export CLAUDE_TRUST_BYPASS=1"
        }

        print(json.dumps(result, indent=2))
        sys.exit(1)


if __name__ == "__main__":
    main()
