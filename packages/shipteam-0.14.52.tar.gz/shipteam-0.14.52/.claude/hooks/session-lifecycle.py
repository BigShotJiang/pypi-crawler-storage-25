#!/usr/bin/env python3
"""SessionStart hook — creates session lock and logs lifecycle events.

Fires when a Claude Code session begins. Creates a session-lock.json so
concurrent-session protection (checkout-guard, worktree-enforcer) works
from the very first prompt. Also logs a session_start event for observability.

Exit codes:
  0 = Always (non-blocking, never interferes with session startup)
"""

import json
import os
import subprocess
import sys
import uuid
from datetime import datetime
from pathlib import Path

# Fire-and-forget import of event logger
try:
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent / "scripts"))
    from fw_event_log import append_event as _log_event
except Exception:
    def _log_event(*a, **kw):
        pass

# Import worktree-aware path utilities
try:
    from path_utils import get_project_root, get_state_dir, GIT_ENV, get_current_branch
    PROJECT_ROOT = get_project_root()
    STATE_DIR = get_state_dir()
except ImportError:
    PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent
    STATE_DIR = PROJECT_ROOT / '.claude' / 'state'

    GIT_ENV = {
        **os.environ,
        'GIT_DIR': str(PROJECT_ROOT / '.git'),
        'GIT_WORK_TREE': str(PROJECT_ROOT)
    }

    def get_current_branch():
        try:
            result = subprocess.run(
                ['git', 'rev-parse', '--abbrev-ref', 'HEAD'],
                capture_output=True, text=True,
                cwd=str(PROJECT_ROOT), env=GIT_ENV, timeout=5
            )
            return result.stdout.strip() if result.returncode == 0 else 'unknown'
        except Exception:
            return 'unknown'

SESSION_LOCK_FILE = STATE_DIR / 'session-lock.json'


def _find_main_repo_claude_dir() -> Path | None:
    """Locate the main repo's .claude/ directory for self-heal bootstrap.

    Checks, in order:
    1. FW_PROJECT_ROOT env var (set by claude-session.sh)
    2. CLAUDE_PROJECT_DIR env var (set by Claude Code runtime)
    3. .git file worktree pointer (parse gitdir from .git file to find main repo)
    """
    for env_var in ('FW_PROJECT_ROOT', 'CLAUDE_PROJECT_DIR'):
        candidate = os.environ.get(env_var)
        if candidate:
            claude_dir = Path(candidate) / '.claude'
            hooks_dir = claude_dir / 'hooks'
            if hooks_dir.is_dir() and any(hooks_dir.iterdir()):
                return claude_dir

    # Parse .git file for worktree pointer
    git_path = PROJECT_ROOT / '.git'
    if git_path.is_file():
        try:
            content = git_path.read_text().strip()
            if content.startswith('gitdir:'):
                gitdir = Path(content.split(':', 1)[1].strip())
                # gitdir points to e.g. /main-repo/.git/worktrees/branch-name
                # main repo is 3 levels up from worktrees/<name>
                if 'worktrees' in gitdir.parts:
                    main_repo = gitdir.parent.parent.parent
                    claude_dir = main_repo / '.claude'
                    hooks_dir = claude_dir / 'hooks'
                    if hooks_dir.is_dir() and any(hooks_dir.iterdir()):
                        return claude_dir
        except Exception:
            pass

    return None


def _bootstrap_from_source(source_claude_dir: Path) -> bool:
    """Copy hooks/, rules/, agents/, skills/, settings.json from source to PROJECT_ROOT/.claude/.

    Uses shutil.copytree with dirs_exist_ok=False (no clobber at directory level).
    Returns True if hooks/ now exists.
    """
    import shutil

    target_claude = PROJECT_ROOT / '.claude'
    target_claude.mkdir(parents=True, exist_ok=True)

    for subdir in ('hooks', 'rules', 'agents', 'skills'):
        src = source_claude_dir / subdir
        dst = target_claude / subdir
        if src.is_dir() and not dst.is_dir():
            shutil.copytree(str(src), str(dst))

    # settings.json — no clobber
    src_settings = source_claude_dir / 'settings.json'
    dst_settings = target_claude / 'settings.json'
    if src_settings.is_file() and not dst_settings.is_file():
        shutil.copy2(str(src_settings), str(dst_settings))

    return (target_claude / 'hooks').is_dir() and any((target_claude / 'hooks').iterdir())


def verify_claude_hooks() -> bool:
    """Check .claude/hooks/ exists and is non-empty.

    If missing: attempt self-heal from main repo.
    If STILL missing: return False (caller should exit 2).
    Returns True if hooks are present (either already or after self-heal).
    """
    hooks_dir = PROJECT_ROOT / '.claude' / 'hooks'

    # Happy path: hooks exist and are non-empty
    if hooks_dir.is_dir() and any(hooks_dir.iterdir()):
        return True

    # Self-heal: find main repo and bootstrap
    print("[session-lifecycle] WARNING: .claude/hooks/ missing or empty — attempting self-heal...",
          file=sys.stderr)

    source = _find_main_repo_claude_dir()
    if source is None:
        print("[session-lifecycle] ERROR: Cannot find main repo .claude/ for self-heal.",
              file=sys.stderr)
        return False

    try:
        if _bootstrap_from_source(source):
            print(
                f"[session-lifecycle] Self-healed .claude/ from {source}.\n"
                "  Hooks were missing and have been restored.\n"
                "  RESTART REQUIRED: Re-launch this session for all hooks to take effect.",
                file=sys.stderr,
            )
            # Return False to trigger exit 2 — forces a clean restart so ALL
            # hooks (not just session-lifecycle) are active from the first prompt.
            return False
    except Exception as e:
        print(f"[session-lifecycle] Self-heal failed: {e}", file=sys.stderr)

    return False


def create_session_lock(session_id: str, branch: str) -> bool:
    """Write session-lock.json so concurrent-session guards work immediately.

    If a lock already exists for a live process, leaves it untouched (another
    session owns this worktree). If the lock is stale (process dead), reclaims it.

    Returns True if lock was written, False otherwise.
    """
    try:
        STATE_DIR.mkdir(parents=True, exist_ok=True)

        if SESSION_LOCK_FILE.exists():
            try:
                existing = json.loads(SESSION_LOCK_FILE.read_text())
                existing_pid = existing.get('pid')
                if existing_pid and existing_pid != os.getpid():
                    # Check if the other process is still alive
                    try:
                        os.kill(existing_pid, 0)
                        # Process alive — don't overwrite
                        return False
                    except (OSError, ProcessLookupError):
                        pass  # Stale lock — reclaim below
            except (json.JSONDecodeError, IOError):
                pass  # Corrupt lock — overwrite

        lock_data = {
            'session_id': session_id,
            'pid': os.getpid(),
            'branch': branch,
            'started_at': datetime.now().isoformat(),
            'last_heartbeat': datetime.now().isoformat(),
        }
        SESSION_LOCK_FILE.write_text(json.dumps(lock_data, indent=2))
        return True
    except Exception as e:
        print(f"[session-lifecycle] WARNING: Could not create session lock: {e}", file=sys.stderr)
        return False


def main() -> None:
    """Create session lock and log a session_start event."""
    try:
        # Read stdin (SessionStart provides session metadata)
        stdin_data = {}
        try:
            import select
            if select.select([sys.stdin], [], [], 0.1)[0]:
                raw = sys.stdin.read()
                if raw.strip():
                    stdin_data = json.loads(raw)
        except Exception:
            pass

        branch = get_current_branch()
        session_id = stdin_data.get("session_id", None)
        if not session_id:
            session_id = os.environ.get('CLAUDE_SESSION_ID', str(uuid.uuid4())[:8])

        # Create session lock FIRST — guards depend on it from the first prompt
        create_session_lock(session_id, branch)

        _log_event(
            "session_start",
            "session",
            {
                "branch": branch,
                "pid": os.getpid(),
                "session_id": session_id,
                "worktree": str(PROJECT_ROOT),
            },
            hook="session_lifecycle",
        )
    except Exception:
        pass  # Fire-and-forget


if __name__ == "__main__":
    # Layer 3: Verify hooks exist BEFORE session starts.
    # Exit 2 = HARD BLOCK — prevents sessions with no safety hooks.
    if not verify_claude_hooks():
        print(
            "\n  BLOCKED: .claude/hooks/ is missing or empty.\n"
            "  Safety hooks are not active — this session cannot proceed.\n\n"
            "  To fix:\n"
            "    1. If in a worktree: re-run claude-session.sh (bootstraps .claude/)\n"
            "    2. If standalone: copy .claude/ from the framework repo\n"
            "    3. Contact the project maintainer\n",
            file=sys.stderr,
        )
        sys.exit(2)

    try:
        main()
    except Exception:
        pass
    sys.exit(0)
