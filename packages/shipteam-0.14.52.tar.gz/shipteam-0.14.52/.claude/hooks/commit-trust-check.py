#!/usr/bin/env python3
"""
Commit Trust Verification Hook - Entry point script.

This script simply imports and runs the main function from the module.
The actual implementation is in commit_trust_check.py.
"""

import sys
from pathlib import Path

# Add the hooks directory to path
sys.path.insert(0, str(Path(__file__).parent))

from commit_trust_check import main

if __name__ == "__main__":
    main()
