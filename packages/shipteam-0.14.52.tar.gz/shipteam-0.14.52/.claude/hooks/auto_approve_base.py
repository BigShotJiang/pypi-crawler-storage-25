#!/usr/bin/env python3
"""
Claude Code PreToolUse Hook — Base Safety Gate

Universal safety logic for auto-approving safe commands and blocking dangerous ones.
Projects extend this by importing main() and passing project-specific patterns.

Usage (default — no project customization):
    if __name__ == "__main__":
        main()

Usage (project overlay — adds project-specific patterns):
    from auto_approve_base import main
    main(
        extra_safe_rm_targets=[os.path.expanduser("~/worktrees/")],
        extra_script_patterns=["manage_servers\\.sh", "deploy-railway\\.sh"],
        extra_file_op_patterns=[r"/my-project"],
        extra_git_worktree_pattern=r"my-project",
        extra_env_prefixes=["MY_VAR"],
    )

Exit codes:
  0 = Continue (with optional approval JSON)
  2 = Block the command
"""
import json
import re
import shlex
import sys
import time
from pathlib import Path

# Fire-and-forget metrics logging
try:
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent / "scripts"))
    from fw_event_log import append_event as _log_event
except Exception:
    def _log_event(*a, **kw): pass  # no-op fallback

# Monotonic clock start-time set at main() entry; read by approve/block
# to emit duration_ms on their event-log entries. None until main() runs.
_HOOK_START_TIME = None


def _duration_ms() -> float:
    if _HOOK_START_TIME is None:
        return 0.0
    return round((time.monotonic() - _HOOK_START_TIME) * 1000, 3)


def approve(reason: str) -> None:
    """Return JSON to auto-approve the command."""
    _log_event("approve", "safety",
               {"reason": reason, "duration_ms": _duration_ms()},
               hook="auto_approve_base", level="debug")
    print(json.dumps({
        "hookSpecificOutput": {
            "hookEventName": "PreToolUse",
            "permissionDecision": "allow",
            "permissionDecisionReason": reason
        }
    }))
    sys.exit(0)


def block(reason: str) -> None:
    """Block the command (exit code 2)."""
    _log_event("block", "safety",
               {"reason": reason, "duration_ms": _duration_ms()},
               hook="auto_approve_base", level="warn")
    print(json.dumps({
        "hookSpecificOutput": {
            "hookEventName": "PreToolUse",
            "permissionDecision": "deny",
            "permissionDecisionReason": reason
        }
    }), file=sys.stderr)
    sys.exit(2)


def _approve_if_matches(cmds: set, pattern: str, reason: str) -> None:
    """Approve if any command variant matches the regex pattern."""
    for cmd in cmds:
        if re.match(pattern, cmd):
            approve(reason)


PROTECTED_BRANCH_PATTERN = r"^(origin/)?(main|master|develop|release/\S+|hotfix/\S+)$"
SAFE_FEATURE_PREFIX_PATTERN = r"^(session/|feat/|fix/|docs/|chore/|refactor/|test/)"
DISALLOWED_REF_NAMESPACES = ("refs/notes/", "refs/replace/", "refs/tags/")
# Flag-only forms; flag-with-value forms (e.g. -o, --push-option) are not parsed
# yet so unknown flags fall through to user prompt.
ALLOWED_PUSH_FLAGS = frozenset({"-u", "--set-upstream"})
# Env-prefix detection on the ORIGINAL command. Auto-approve must refuse when
# any env var is set, because git inherits env from its parent process —
# GIT_SSH_COMMAND, LD_PRELOAD, PATH, GIT_EXTERNAL_DIFF, DYLD_INSERT_LIBRARIES
# are all RCE vectors. The canonicalize-vs-execute asymmetry that catches
# blocks (any variant matches → block) inverts for allows (execution sees
# the env even if matching does not).
#
# Shell builtins like `command`, `exec`, `nice`, `nohup`, `time`, `setsid`,
# `unshare` shift the env-prefix anchor right by one or more words. The
# pattern absorbs them so `command env GIT_SSH_COMMAND=evil git push ...`
# still matches as env-bearing — defense-in-depth against future widening
# of `push_regex` that would otherwise turn this into a latent RCE.
ENV_PREFIX_PATTERN = re.compile(
    r"^\s*(?:(?:command|exec|nice|nohup|time|setsid|unshare)\s+)*"
    r"(?:env\s+)?\w+=\S+\s+"
)


def _normalize_ref(token: str) -> str:
    """Strip surrounding cruft, '+' (force-refspec), and 'refs/heads/' (canonical form).

    Surrounding cruft includes whitespace, quotes, and parens (subshell tail).
    """
    token = token.strip().strip("'\"()").lstrip("+")
    if token.startswith("refs/heads/"):
        token = token[len("refs/heads/"):]
    return token


def _parse_push_targets(command: str) -> list:
    """Return list of normalized destination refs from a `git push ...` command.

    For each non-flag, non-keyword arg AFTER the remote name (first non-flag positional after 'push'):
      - If contains ':' (refspec form), take the second half (dst)
      - Else, take the whole token
      - Apply _normalize_ref()
    Skip flags (--*, -*) and the 'git'/'push' keywords.
    Return empty list if no targets found.
    """
    tokens = command.split()
    # Skip until past 'push'
    idx = 0
    while idx < len(tokens) and tokens[idx] != "push":
        idx += 1
    idx += 1  # skip 'push' itself
    # Skip flags and find the remote (first non-flag positional)
    remote_found = False
    targets = []
    while idx < len(tokens):
        t = tokens[idx]
        idx += 1
        if t.startswith("-"):
            continue
        if not remote_found:
            # This is the remote name
            remote_found = True
            continue
        # This is a refspec or branch name
        if ":" in t:
            dst = t.split(":", 1)[1]
        else:
            dst = t
        targets.append(_normalize_ref(dst.strip("'\"")))
    return targets


def _command_has_wildcard_refspec(command: str) -> bool:
    """True if any token in the command (split on whitespace) contains a literal '*'."""
    return "*" in command


def _command_has_disallowed_namespace(targets: list) -> bool:
    """True if any target starts with any prefix in DISALLOWED_REF_NAMESPACES.
    Note: targets passed in are already normalized; refs/heads/ prefix is stripped,
    but refs/notes/, refs/replace/, refs/tags/ are NOT — they remain so this check works.
    """
    return any(
        any(t.startswith(ns) for ns in DISALLOWED_REF_NAMESPACES)
        for t in targets
    )


def _command_has_delete_refspec(tokens: list) -> bool:
    """True if any token is a delete-refspec form with empty source half.

    Forms detected: `:dst`, `+:dst` (force-delete after `+` strip).
    Phase 1 hard-denies catch protected-branch deletion via the destination
    matching the protected pattern, but the source-empty signal is what
    distinguishes a destructive delete from a normal push.
    """
    for t in tokens:
        s = t.lstrip("+")
        if ":" not in s:
            continue
        src, _ = s.split(":", 1)
        if not src.strip():
            return True
    return False


def main(
    *,
    extra_safe_rm_targets: list = None,
    extra_dangerous_rm_targets: list = None,
    extra_script_patterns: list = None,
    extra_git_worktree_pattern: str = None,
    extra_file_op_patterns: list = None,
    extra_env_prefixes: list = None,
) -> None:
    """Main hook entry point with extension points for project customization.

    Args:
        extra_safe_rm_targets: Additional paths safe for recursive rm (e.g., worktree base)
        extra_dangerous_rm_targets: Additional paths to block for recursive rm
        extra_script_patterns: Additional root-level scripts to auto-approve
        extra_git_worktree_pattern: Regex fragment for project-specific GIT_DIR matching
        extra_file_op_patterns: Additional path patterns for safe file operations
        extra_env_prefixes: Additional environment variable prefixes to auto-approve
    """
    global _HOOK_START_TIME
    _HOOK_START_TIME = time.monotonic()

    if extra_safe_rm_targets is None:
        extra_safe_rm_targets = []
    if extra_dangerous_rm_targets is None:
        extra_dangerous_rm_targets = []
    if extra_script_patterns is None:
        extra_script_patterns = []
    if extra_file_op_patterns is None:
        extra_file_op_patterns = []
    if extra_env_prefixes is None:
        extra_env_prefixes = []

    try:
        input_data = json.load(sys.stdin)
    except json.JSONDecodeError as e:
        print(f"[auto-approve] WARNING: Could not parse hook input: {e}", file=sys.stderr)
        sys.exit(0)

    tool_name = input_data.get("tool_name", "")
    tool_input = input_data.get("tool_input", {})

    # ============================================================
    # BASH COMMANDS
    # ============================================================
    if tool_name == "Bash":
        command = tool_input.get("command", "")

        # ----- STRIP SUBSHELL PARENS -----
        inner_command = re.sub(r"^\(\s*", "", command)

        # ----- STRIP cd PREFIX -----
        effective_command = re.sub(r"^cd\s+\S+\s*&&\s*", "", inner_command)

        # ----- STRIP ENV VAR PREFIXES -----
        # "NODE_ENV=test npx -y pkg" -> "npx -y pkg" so per-tool guards apply
        effective_command = re.sub(r"^(\w+=\S+\s+)+", "", effective_command)

        # ----- NETWORK RECON/EXFILTRATION TOOLS (hard block) -----
        # Strip common path prefixes to catch /usr/bin/nc, /usr/sbin/nmap etc.
        net_cmd = re.sub(r"^(?:env\s+)?(?:/usr/(?:s?bin|local/bin)/)?", "", effective_command)
        if re.match(r"^(nc|ncat|nmap|socat|tcpdump)\b", net_cmd):
            block("BLOCKED: Network reconnaissance/exfiltration tool is prohibited.")

        # ----- COMPOUND COMMAND GUARD (CANONICALIZE-FIRST — CWE-551) -----
        # Compute flags NOW so approve paths below can refuse when shell
        # metacharacters are present. Fall-through action is deferred to
        # after the hard-block stack so "dangerous cmd wins" is preserved
        # (e.g., `ls; rm -rf /` still hard-blocks rather than falls through).
        has_shell_operators = re.search(
            r'[^-]>{1,2}\s'    # output redirection (but not --flag>)
            r'|>{1,2}/'        # redirect to absolute path (>/.., >/tmp)
            r'|>\S'            # no-space redirection (echo payload>file)
            r'|^>'             # command starting with redirect (> /tmp/file)
            r'|\d+>'           # fd redirection (2>, 1>)
            r'|`[^`]+`'        # backtick command substitution
            r'|\$'             # any $: $(), ${var}, $VAR, $'...', $"..." (CWE-551)
            r'|\|'             # pipe (also catches ||)
            r'|;\s*\S'         # semicolon chaining (ls; rm -rf /)
            r'|&'              # & backgrounding, && chaining (CWE-551 F2)
            r'|<'              # < input redirection, << heredoc
            r'|\*'             # * glob — break authorize==execute invariant
            r'|\\\n',          # backslash line continuation (AC-6)
            command
        )
        # Match write operators that target the safety path. The operator
        # must be ADJACENT to the safety path — it's not enough for both to
        # appear independently in the command text. This prevents false
        # positives on:
        #   - `git show HASH -- .claude/settings.json` (read-only VCS op)
        #   - `git commit -m "message about .claude/hooks/..."` (path in
        #     message body, not a write — the `>` in `<placeholder>` text
        #     used to also trip the old regex)
        #   - `cp .claude/settings.json /tmp/backup.json` (safety path is
        #     SOURCE, not destination)
        #   - `cat .claude/settings.json | jq` (read-side pipe)
        # All five attack patterns currently covered by safety_gate.bats
        # remain hard-blocked by the new patterns.
        SAFETY_PATH_RE = r'\.claude/(?:hooks/|rules/|settings\.json)'
        writes_to_safety = any(re.search(p, command) for p in (
            # Output redirection TO safety path: `> .claude/x` / `>> .claude/x`
            # (>>? is equivalent to >{1,2} but avoids the f-string brace pitfall)
            rf'>>?\s*[\'"]?{SAFETY_PATH_RE}',
            # tee TO safety path (with optional flags): `tee .claude/x`, `tee -a .claude/x`
            rf'\btee\b(?:\s+-[a-zA-Z]+)*\s+[\'"]?{SAFETY_PATH_RE}',
            # cp/mv where safety path is the destination (last positional arg).
            # `(?:\S+\s+)+` allows 1+ source args before the destination.
            rf'\b(?:cp|mv)\b(?:\s+-[a-zA-Z]+)*\s+(?:\S+\s+)+[\'"]?{SAFETY_PATH_RE}',
            # ln where safety path is the destination
            rf'\bln\b(?:\s+-[a-zA-Z]+)*\s+(?:\S+\s+)+[\'"]?{SAFETY_PATH_RE}',
            # sed -i (in-place edit) targeting safety path
            rf'\bsed\b\s+-i\b[^|;&]*?{SAFETY_PATH_RE}',
        ))

        if writes_to_safety:
            block("BLOCKED: Write to safety infrastructure via shell is prohibited.")

        cmds_to_check = {command, inner_command, effective_command}

        # ----- DANGEROUS COMMANDS - CHECK FIRST -----
        is_recursive_rm = re.search(r"rm\s+(-[a-zA-Z]*r|--recursive)", command)
        if is_recursive_rm:
            safe_prefixes = ["/tmp/", "/var/tmp/", "/private/tmp/"]
            safe_prefixes.extend(extra_safe_rm_targets)

            dangerous_targets = [
                r"rm -rf /[^a-zA-Z.]", r"rm -rf /$", r"rm -rf ~/",
                r"rm -rf backend", r"rm -rf frontend",
                r"rm -rf docs", r"rm -rf .git", r"rm -rf ../",
            ]
            dangerous_targets.extend(extra_dangerous_rm_targets)
            target_is_dangerous = any(re.search(p, command) for p in dangerous_targets)

            # Parse actual path targets from the command (skip flags)
            # Validates each target starts with a safe prefix and has no path traversal
            target_is_safe = False
            try:
                tokens = shlex.split(command)
                path_args = [t for t in tokens[1:] if not t.startswith("-")]
                if path_args:
                    target_is_safe = all(
                        any(t.startswith(prefix) for prefix in safe_prefixes)
                        and ".." not in t
                        for t in path_args
                    )
            except ValueError as e:
                print(f"[auto-approve] WARNING: Could not parse command (shlex): {e}", file=sys.stderr)

            if target_is_safe and not target_is_dangerous:
                if has_shell_operators:
                    # CWE-551 guard: shlex parses `/tmp/safe$(evil)` as safe,
                    # but shell expansion at execution time runs the substitution.
                    sys.exit(0)
                approve("Recursive removal of safe path")
            elif target_is_dangerous:
                block("BLOCKED: Recursive removal of project/system paths requires manual execution.")
            else:
                block("BLOCKED: Recursive removal requires manual review.")

        # git push --force, -f, or --force-with-lease
        if re.search(r"git\s+push\s+.*(-f\b|--force\b|--force-with-lease)", command):
            block("BLOCKED: Force push is prohibited. Use normal push or create a PR.")

        # sudo commands
        if re.match(r"^sudo\s", command):
            sys.exit(0)

        # SQL destructive commands (comment-aware normalization)
        normalized = re.sub(r'--[^\n]*', ' ', command)
        normalized = re.sub(r'/\*.*?\*/', ' ', normalized, flags=re.DOTALL)

        if re.search(r"DROP\s+(TABLE|DATABASE|SCHEMA)", normalized, re.IGNORECASE):
            block("BLOCKED: DROP operations require manual DBA execution.")
        if re.search(r"TRUNCATE", normalized, re.IGNORECASE):
            block("BLOCKED: TRUNCATE requires manual DBA execution.")
        if re.search(r"DELETE\s+FROM", normalized, re.IGNORECASE):
            if not re.search(r"DELETE\s+FROM\s+\S+\s+WHERE", normalized, re.IGNORECASE):
                block("BLOCKED: DELETE without WHERE clause is prohibited.")
            sys.exit(0)

        # ----- REQUIRE APPROVAL FOR DESTRUCTIVE GIT COMMANDS -----
        merge_match = re.search(r"git\s+merge\s+(\S+)", command)
        if merge_match and merge_match.group(1) != "--abort":
            sys.exit(0)

        if re.search(r"git\s+rebase", command):
            sys.exit(0)

        if re.search(r"git\s+reset\s+--hard", command):
            block("BLOCKED: git reset --hard is prohibited. Use git stash or git checkout <file>.")

        # ----- BRANCH DELETION (policy-aligned: Auto-OK / ASK / REFUSE) -----
        branch_del = re.search(r"git\s+branch\b.*(\s+-[a-zA-Z]*[dD]|\s+--delete\b)", command)
        if branch_del:
            # Extract branch names: non-flag tokens after "git branch"
            branch_part = re.sub(r"^.*?git\s+branch\s+", "", command)
            branch_names = [t.strip("\"'") for t in branch_part.split() if not t.startswith("-")]
            protected = r"^(origin/)?(main|master|develop|release/\S+|hotfix/\S+)$"
            if any(re.match(protected, b) for b in branch_names):
                block("BLOCKED: Deletion of protected branch is prohibited.")
            # Auto-OK: session/claude-* and dependabot/* with safe delete (-d)
            # Check flags only (not branch names) for force-delete indicator
            flags_part = re.sub(r"^.*?git\s+branch\s+", "", command)
            flag_tokens = [t for t in flags_part.split() if t.startswith("-")]
            is_force = any(re.match(r"-[a-zA-Z]*D", f) for f in flag_tokens)
            auto_ok = r"^(origin/)?(session/claude-|dependabot/)"
            if not is_force and branch_names and all(re.match(auto_ok, b) for b in branch_names):
                if has_shell_operators:
                    # CWE-551 guard: prefix match on `session/claude-$(evil)`
                    # is insufficient — shell metachars in the branch name let
                    # payloads piggyback on the auto-approve decision.
                    sys.exit(0)
                approve("Branch deletion: merged session/dependabot branch")
            # All other branch deletion: fall through to user prompt
            sys.exit(0)

        if re.search(r"git\s+push\b.*--delete\b", command):
            # Check all non-flag tokens (excluding git, push, remote names)
            tokens = command.split()
            non_flag = [t.strip("\"'") for t in tokens if not t.startswith("-") and t not in ("git", "push")]
            protected = r"^(main|master|develop|release/\S+|hotfix/\S+)$"
            if any(re.match(protected, t) for t in non_flag):
                block("BLOCKED: Remote deletion of protected branch is prohibited.")
            sys.exit(0)

        # gh pr merge (with or without --delete-branch): fall through to user prompt
        if re.search(r"gh\s+pr\s+merge\b", command):
            sys.exit(0)

        # ----- PUSH POLICY HARD DENIES (Phase 1) -----
        # Operates on every canonicalized variant of the command (env-stripped,
        # subshell-stripped, cd-stripped) so ENV-prefix, absolute-path, and
        # subshell forms all hard-deny rather than falling through.
        # Regex permits an optional /usr/{bin,sbin,local/bin}/ path prefix to
        # match `/usr/bin/git push ...` after the path strip below.
        push_regex = r"^\s*(?:env\s+)?(?:/usr/(?:s?bin|local/bin)/)?git\s+push\b"
        for push_candidate in cmds_to_check:
            if not re.match(push_regex, push_candidate):
                continue

            # Wildcard refspec check runs BEFORE has_shell_operators skip so
            # `git push origin *:*` is denied (not merely fallen through).
            if _command_has_wildcard_refspec(push_candidate):
                block("wildcard refspecs are forbidden")

            # CWE-551 guard: if shell metacharacters are present in the
            # ORIGINAL command, skip per-token policy. The existing
            # fall-through (L412) defers to user prompt rather than auto-approve.
            if has_shell_operators:
                continue

            tokens_push = push_candidate.split()

            # --no-verify bypasses pre-push hooks
            if "--no-verify" in tokens_push:
                block("git push --no-verify is forbidden (skips pre-push hooks)")

            # --tags pushes all tags
            if "--tags" in tokens_push:
                block("git push --tags is forbidden (use a branch push)")

            # --mirror overwrites entire remote
            if "--mirror" in tokens_push:
                block("git push --mirror is forbidden (overwrites remote)")

            # --all pushes all branches
            if "--all" in tokens_push:
                block("git push --all is forbidden (too coarse)")

            # Disallowed ref namespaces
            targets = _parse_push_targets(push_candidate)
            if _command_has_disallowed_namespace(targets):
                block("namespace push (notes/replace/tags) is forbidden")

            # Protected branch targets
            for target in targets:
                if re.match(PROTECTED_BRANCH_PATTERN, target):
                    block(f"push to protected branch {target} is forbidden")

            # Bare semver tag push (e.g. v1.0, V1.2.3 — case-insensitive, no slash)
            for target in targets:
                if re.match(r"^[vV]\d+(\.\d+)*$", target) and "/" not in target:
                    block("tag push is forbidden")

        # ----- PUSH AUTO-APPROVE (safe feature prefixes) -----
        # Refuse to auto-approve any push carrying an env-prefix on the
        # original command. The env attaches to the executed git binary
        # (GIT_SSH_COMMAND, LD_PRELOAD, PATH, GIT_EXTERNAL_DIFF,
        # DYLD_INSERT_LIBRARIES are all RCE vectors). Falls through to user
        # prompt rather than auto-approving the canonicalized variant.
        if not ENV_PREFIX_PATTERN.match(command):
            for push_candidate in cmds_to_check:
                if not re.match(push_regex, push_candidate):
                    continue
                if has_shell_operators:
                    continue
                push_tokens = push_candidate.split()
                flags = [t for t in push_tokens if t.startswith("-")]
                if any(f not in ALLOWED_PUSH_FLAGS for f in flags):
                    continue
                # Delete-refspecs (`:branch`, `+:branch`) are destructive.
                # _parse_push_targets returns the dst losing the empty-source
                # signal, so detect on raw tokens before parsing.
                if _command_has_delete_refspec(push_tokens):
                    continue
                targets = _parse_push_targets(push_candidate)
                if not targets:
                    continue
                if all(re.match(SAFE_FEATURE_PREFIX_PATTERN, t) for t in targets):
                    approve("feature-branch push")
                    return

        # ----- BLOCK COMMIT/PUSH FROM AUTO-APPROVAL -----
        if re.search(r"git\s+(commit|push)", command):
            sys.exit(0)

        # ----- APPROVAL CHECKS -----
        # Final compound-guard fall-through: any shell metacharacters reach
        # this point only if no hard-block fired above. Defer to user prompt
        # rather than auto-approving compound commands.
        if has_shell_operators:
            sys.exit(0)

        # ----- GIT COMMANDS (all variants) -----
        for cmd in cmds_to_check:
            if extra_git_worktree_pattern:
                if re.match(
                    rf"^GIT_DIR=.*{extra_git_worktree_pattern}.*GIT_WORK_TREE=.*{extra_git_worktree_pattern}.*\s*(/usr/bin/)?(git|gh)\s",
                    cmd
                ):
                    approve("Git/gh command with worktree env vars")
            else:
                if re.match(r"^GIT_DIR=.*GIT_WORK_TREE=.*\s*(/usr/bin/)?(git|gh)\s", cmd):
                    approve("Git/gh command with worktree env vars")
            if re.match(r"^GIT_DIR=\.git\s+GIT_WORK_TREE=\.\s+(git|gh)\s", cmd):
                approve("Git/gh command with relative worktree env vars")
            if re.match(r"^(/usr/bin/|/opt/homebrew/bin/)?(git|gh)\s", cmd):
                approve("Git/gh command")

        # ----- SECRETS FILE ACCESS VIA SHELL (fall through to prompt) -----
        secrets_pattern = r"\.(env|pem|key|secret|credentials)"
        for cmd in cmds_to_check:
            if re.match(r"^(cat|head|tail|less|more)\s", cmd):
                if re.search(secrets_pattern, cmd, re.IGNORECASE):
                    sys.exit(0)

        # ----- READ-ONLY COMMANDS -----
        # NOTE: echo/printf removed — they write via shell redirection.
        # NOTE: find removed — it has -delete and -exec flags.
        readonly_commands = (
            "ls", "pwd", "cat", "head", "tail", "less", "more",
            "grep", "egrep", "fgrep", "rg", "ag",
            "locate", "which", "whereis",
            "tree", "file", "stat", "du", "df",
            "wc", "sort", "uniq", "diff", "cmp", "comm",
            "date", "whoami", "hostname",
            "ps", "top", "htop", "free", "uptime", "lsof"
        )
        _approve_if_matches(cmds_to_check,
                            rf"^({'|'.join(readonly_commands)})(\s|$)",
                            "Read-only command")

        # ----- ECHO/PRINTF (safe only without redirection) -----
        _approve_if_matches(cmds_to_check,
                            r"^(echo|printf)(\s|$)",
                            "Echo/printf (no redirection)")

        # ----- FIND (safe only without destructive flags) -----
        for cmd in cmds_to_check:
            if re.match(r"^find\s", cmd):
                if re.search(r'-delete|-exec|-execdir|-ok\b', cmd):
                    sys.exit(0)  # Fall through for destructive find
                approve("Find command (read-only)")

        # ----- PYTHON/VENV COMMANDS -----
        # Block inline code execution via -c flag (can run arbitrary code)
        for cmd in cmds_to_check:
            if re.match(r"^(python3?|node)\s+(-c|--command|-e|--eval)\s", cmd):
                sys.exit(0)  # Fall through — inline code needs user review
        _approve_if_matches(cmds_to_check,
                            r"^(PYTHONPATH=.*\s+)?\.?/?venv/bin/(python|pytest|pip|bandit)",
                            "Python venv command")
        _approve_if_matches(cmds_to_check, r"^\./venv/bin/", "Venv command")
        _approve_if_matches(cmds_to_check,
                            r"^(python3?|pytest|pip3?|bandit)(\s|$)",
                            "Python command")
        _approve_if_matches(cmds_to_check,
                            r"^/\S*/(python3?|pytest)(\s|$)",
                            "Python command (absolute path)")

        # ----- ENVIRONMENT VARIABLE PREFIXES -----
        env_prefixes = [
            "PYTHONPATH", "QASE_MODE", "QASE_ENABLED",
            "PLAYWRIGHT_SKIP_WEBSERVER", "PLAYWRIGHT_BASE_URL",
            "TEST_EMAIL", "TEST_PASSWORD",
            "TOKEN", "NODE_ENV",
        ]
        env_prefixes.extend(extra_env_prefixes)
        _approve_if_matches(cmds_to_check,
                            rf"^({'|'.join(env_prefixes)})=",
                            "Environment variable prefixed command")

        # ----- NPM/NODE COMMANDS -----
        for cmd in cmds_to_check:
            if re.match(r"^npx\s+(-y|--yes)\s", cmd):
                sys.exit(0)  # Fall through — auto-install needs review
        _approve_if_matches(cmds_to_check,
                            r"^(npm|npx|node|yarn|pnpm|bun)\s",
                            "Node.js command")

        # ----- PROJECT SCRIPTS -----
        # Reject path traversal (scripts/../evil.sh)
        script_pattern = r"^(\./)?scripts/(?!\.\\.)"
        if extra_script_patterns:
            combined = "|".join(extra_script_patterns)
            script_pattern = rf"^(\./)?(?:scripts/(?!\.\\.)|{combined})"
        for cmd in cmds_to_check:
            if re.match(r"^(\./)?scripts/", cmd) and ".." in cmd:
                sys.exit(0)  # Fall through — path traversal
        _approve_if_matches(cmds_to_check, script_pattern, "Project script")

        bash_script_pattern = r"^bash\s+(\./)?scripts/"
        if extra_script_patterns:
            combined = "|".join(extra_script_patterns)
            bash_script_pattern = rf"^bash\s+(\./)?(?:scripts/|{combined})"
        for cmd in cmds_to_check:
            if re.match(r"^bash\s+(\./)?scripts/", cmd) and ".." in cmd:
                sys.exit(0)  # Fall through — path traversal
        _approve_if_matches(cmds_to_check, bash_script_pattern, "Project script (via bash)")

        # ----- CURL/WGET (API TESTING) -----
        for cmd in cmds_to_check:
            if re.match(r"^curl\s", cmd):
                if re.search(
                    r'\s(-[dFT]\b|-X\s*(POST|PUT|PATCH|DELETE)'
                    r'|--data\b|--form\b|--upload-file\b'
                    r'|-o\b|-O\b|--output\b|--remote-name\b)', cmd
                ):
                    sys.exit(0)  # Fall through — not a simple GET
                approve("HTTP GET request (curl)")
            if re.match(r"^wget\s", cmd):
                if re.search(r'\s(-O\b|--output-document\b|--post-data\b)', cmd):
                    sys.exit(0)  # Fall through — writes or POSTs
                approve("HTTP GET request (wget)")

        # ----- DOCKER COMMANDS -----
        for cmd in cmds_to_check:
            if re.match(r"^docker\s+run\b", cmd):
                if re.search(r'\s(-v\b|--volume\b|--privileged\b|--cap-add\b)', cmd):
                    sys.exit(0)  # Fall through — filesystem escape risk
        _approve_if_matches(cmds_to_check,
                            r"^docker(\s+compose)?\s",
                            "Docker command")

        # ----- MAKE/BUILD COMMANDS -----
        for cmd in cmds_to_check:
            if re.match(r"^go\s+run\s", cmd):
                sys.exit(0)  # Fall through — arbitrary code execution
            if re.match(r"^make\s+(-f|--file)\s", cmd):
                sys.exit(0)  # Fall through — arbitrary makefile
        _approve_if_matches(cmds_to_check,
                            r"^(make|cmake|cargo|go)\s",
                            "Build command")

        # ----- SAFE FILE REMOVAL (non-recursive) -----
        sensitive_rm_targets = (
            r"\.(env|pem|key|secret|credentials)",
            r"auto.approve", r"auto_approve",  # Safety gate self-deletion
            r"\.claude/hooks/", r"\.claude/rules/",
        )
        for cmd in cmds_to_check:
            rm_match = re.match(r"^rm\s+((-[a-zA-Z]+\s+)*)", cmd)
            if rm_match and not re.search(r"-[a-zA-Z]*r", rm_match.group(1)):
                if any(re.search(p, cmd) for p in sensitive_rm_targets):
                    sys.exit(0)  # Fall through to user prompt for sensitive files
                approve("Non-recursive file removal")

        # ----- CD COMMANDS -----
        _approve_if_matches(cmds_to_check, r"^cd\s", "Directory navigation")

        # ----- PROJECT-SPECIFIC FILE OPERATIONS -----
        for pattern in extra_file_op_patterns:
            _approve_if_matches(cmds_to_check,
                                rf"^(mkdir|touch|cp|mv)\s.*{pattern}",
                                "File operation in project directory")

        # ----- TEMP DIRECTORY OPERATIONS -----
        _approve_if_matches(cmds_to_check,
                            r"^(mkdir|cp|mv)\s+.*(/tmp/|/var/tmp/)",
                            "Temp directory operation")

    # ============================================================
    # WEBFETCH - Always approve (read-only)
    # ============================================================
    if tool_name == "WebFetch":
        approve("WebFetch is read-only")

    # ============================================================
    # WEBSEARCH - Always approve (read-only)
    # ============================================================
    if tool_name == "WebSearch":
        approve("WebSearch is read-only")

    # ============================================================
    # READ - Approve except secrets files
    # ============================================================
    if tool_name == "Read":
        file_path = tool_input.get("file_path", "")

        if re.search(r"\.(env|pem|key|secret|credentials)", file_path, re.IGNORECASE):
            sys.exit(0)

        if re.search(r"/(\.ssh|\.gnupg|\.aws)/", file_path):
            sys.exit(0)

        approve("File read (not secrets)")

    # ============================================================
    # GREP - Always approve (read-only)
    # ============================================================
    if tool_name == "Grep":
        approve("Grep is read-only")

    # ============================================================
    # GLOB - Always approve (read-only)
    # ============================================================
    if tool_name == "Glob":
        approve("Glob is read-only")

    # ============================================================
    # EDIT/WRITE - Block writes to safety infrastructure (user prompt)
    # ============================================================
    if tool_name in ("Edit", "Write"):
        file_path = tool_input.get("file_path", "")
        if re.search(
            r'\.claude/hooks/'
            r'|\.claude/rules/'
            r'|\.claude/settings\.json',
            file_path
        ):
            # Edit/Write shows a diff preview in Claude Code's UI, so user
            # prompt is sufficient. Bash writes are hard-blocked because shell
            # commands execute immediately with no preview.
            sys.exit(0)

    # ============================================================
    # Default: Fall through to normal permission flow
    # ============================================================
    sys.exit(0)


if __name__ == "__main__":
    main()
