#!/usr/bin/env python3
"""
Claude Code PostToolUse Hook for Sherlock methodology enforcement.

Warns (never blocks) when a git commit touches 3+ files without a
.sherlock-plan.md in the project root. PostToolUse hooks cannot block
per the Claude Code docs — the tool has already executed. The warning
feeds back to Claude, who should suggest Sherlock methodology.

Rate-limited: warns once per session via flag file to avoid noise.

Config keys:
  hooks.methodology_enforcer: true|false  (default: true)
  rules.sherlock_review_gate: true|false  (must be true for warnings)

Exit codes:
  0 = Always (PostToolUse hooks cannot block)
"""
import json
import os
import re
import subprocess
import sys
import time
from pathlib import Path

# Fire-and-forget metrics logging
try:
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent / "scripts"))
    from fw_event_log import append_event as _log_event
except Exception:
    def _log_event(*a, **kw): pass

# Import config reader
try:
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    from path_utils import get_config, get_project_root
except ImportError:
    def get_config(key, default=""):
        return default

    def get_project_root():
        current = os.path.abspath(os.getcwd())
        while True:
            if os.path.exists(os.path.join(current, ".git")):
                return current
            parent = os.path.dirname(current)
            if parent == current:
                return os.getcwd()
            current = parent


WARN_THRESHOLD = 3  # Minimum files changed to trigger warning
RATE_LIMIT_SECONDS = 3600  # 1 hour between warnings


def warn(message: str) -> None:
    """Output warning to stderr (visible to Claude)."""
    try:
        _log_event("warn", "methodology", {"message": message[:200]},
                   hook="methodology_enforcer")
    except Exception:
        pass  # fire-and-forget: logging failure must not suppress warning
    separator = "=" * 60
    print(f"\n{separator}", file=sys.stderr)
    print(message, file=sys.stderr)
    print(f"{separator}\n", file=sys.stderr)


def is_rate_limited(project_root: str) -> bool:
    """Check if we've warned recently (prevents noise)."""
    flag = os.path.join(project_root, ".claude", "state",
                        "methodology-warned.flag")
    try:
        if os.path.exists(flag):
            mtime = os.path.getmtime(flag)
            if time.time() - mtime < RATE_LIMIT_SECONDS:
                return True
    except OSError:
        pass
    return False


def touch_rate_limit(project_root: str) -> None:
    """Mark that we've warned in this session."""
    flag = os.path.join(project_root, ".claude", "state",
                        "methodology-warned.flag")
    try:
        os.makedirs(os.path.dirname(flag), exist_ok=True)
        Path(flag).touch()
    except OSError:
        pass


def count_files_in_last_commit(cwd: str | None = None) -> int:
    """Count files changed in the most recent commit."""
    try:
        result = subprocess.run(
            ["git", "diff", "--name-only", "HEAD~1..HEAD"],
            capture_output=True, text=True, timeout=5,
            cwd=cwd
        )
        if result.returncode != 0:
            return 0
        files = [f for f in result.stdout.strip().splitlines() if f]
        return len(files)
    except (subprocess.SubprocessError, FileNotFoundError, OSError):
        return 0


def _main() -> None:
    """Inner main — exceptions caught by outer main()."""
    try:
        input_text = sys.stdin.read()
        if not input_text.strip():
            sys.exit(0)
        input_data = json.loads(input_text)
    except (json.JSONDecodeError, ValueError):
        sys.exit(0)

    # Only process Bash commands
    if input_data.get("tool_name") != "Bash":
        sys.exit(0)

    command = input_data.get("tool_input", {}).get("command", "")
    if not command:
        sys.exit(0)

    # Only trigger on git commit
    if not re.search(r"git\s+commit\b", command):
        sys.exit(0)

    # Check config gates (YAML returns booleans, not strings)
    enforcer = get_config("hooks.methodology_enforcer")
    if str(enforcer).lower() == "false":
        sys.exit(0)
    sherlock = get_config("rules.sherlock_review_gate")
    if str(sherlock).lower() == "false":
        sys.exit(0)

    project_root = str(get_project_root())

    # If a plan exists, no warning needed
    plan_path = os.path.join(project_root, ".sherlock-plan.md")
    if os.path.exists(plan_path):
        sys.exit(0)

    # Check rate limit
    if is_rate_limited(project_root):
        sys.exit(0)

    # Count files in last commit (pass cwd for worktree correctness)
    files_changed = count_files_in_last_commit(cwd=str(project_root))
    if files_changed < WARN_THRESHOLD:
        sys.exit(0)

    # Emit warning
    touch_rate_limit(project_root)
    warn(
        f"SHERLOCK METHODOLOGY SUGGESTION\n\n"
        f"This commit touched {files_changed} files without a Sherlock plan.\n"
        f"For changes spanning 3+ files, structured development helps:\n\n"
        f'  Type "sherlock" to classify complexity and choose a workflow\n'
        f'  Type "hudson" for a quick 4-step fix\n\n'
        f"This is a suggestion, not a block. Disable with:\n"
        f"  hooks.methodology_enforcer: false in config/framework.yaml"
    )

    sys.exit(0)


def main() -> None:
    """Outer safety net — hook must always exit 0."""
    try:
        _main()
    except Exception:
        sys.exit(0)


if __name__ == "__main__":
    main()
