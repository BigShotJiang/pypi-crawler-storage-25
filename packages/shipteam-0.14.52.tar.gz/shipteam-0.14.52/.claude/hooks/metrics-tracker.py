#!/usr/bin/env python3
"""Metrics tracker hook — captures SubagentStart events for cost routing telemetry.

Logs agent spawn events to fw_event_log as fire-and-forget. Designed for async
execution (non-blocking). Exits 0 unconditionally — never interferes with workflow.
"""

import json
import sys
from pathlib import Path

# Fire-and-forget import of event logger
try:
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent / "scripts"))
    from fw_event_log import append_event as _log_event
except Exception:
    def _log_event(*a, **kw):
        pass


def main() -> None:
    try:
        raw = sys.stdin.read()
        if not raw.strip():
            return

        data = json.loads(raw)
    except Exception:
        return

    event_name = data.get("hook_event_name", "")

    if event_name == "SubagentStart":
        agent_type = data.get("agent_type", "unknown")
        agent_id = data.get("agent_id", "unknown")
        _log_event(
            "agent_spawn",
            "cost",
            {"agent_type": agent_type, "agent_id": agent_id},
            hook="metrics_tracker",
        )

    elif event_name == "TaskCreated":
        _log_event(
            "task_created",
            "team",
            {
                "task_id": data.get("task_id", "unknown"),
                "teammate_type": data.get("teammate_type", "unknown"),
                "blocked_by": data.get("blocked_by", []),
            },
            hook="metrics_tracker",
        )

    elif event_name == "TaskCompleted":
        _log_event(
            "task_completed",
            "team",
            {
                "task_id": data.get("task_id", "unknown"),
                "teammate_type": data.get("teammate_type", "unknown"),
                "duration_seconds": data.get("duration_seconds", 0),
            },
            hook="metrics_tracker",
        )

    elif event_name == "TeammateIdle":
        _log_event(
            "teammate_idle",
            "team",
            {
                "teammate_type": data.get("teammate_type", "unknown"),
            },
            hook="metrics_tracker",
        )


if __name__ == "__main__":
    try:
        main()
    except Exception:
        pass
    sys.exit(0)
