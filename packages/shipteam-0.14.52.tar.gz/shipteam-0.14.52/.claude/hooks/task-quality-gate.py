#!/usr/bin/env python3
"""Task quality gate hook -- validates reviewer task completion.

Fires on TaskCompleted events. Parses reviewer output for BLOCK/WARNING
verdicts and critical issue counts. Warns the lead when critical issues
are found so dependent tasks can be held.

Exit codes:
  0 — allow task completion
  2 — block task completion (critical issues found, stderr fed back)
"""

import json
import re
import sys


def _count_issues(result_text: str) -> tuple[int, int]:
    """Count Critical and High issues from reviewer output text.

    Looks for patterns like "Critical: N" or "**Critical**: N" or
    severity markers in structured output.
    """
    critical = 0
    high = 0

    # Pattern: "Critical: N" or "Critical (N)" or "**Critical**: N"
    for match in re.finditer(r"[*]*Critical[*]*[:\s(]+(\d+)", result_text, re.IGNORECASE):
        critical += int(match.group(1))

    for match in re.finditer(r"[*]*High[*]*[:\s(]+(\d+)", result_text, re.IGNORECASE):
        high += int(match.group(1))

    # Also check for BLOCK verdict
    if re.search(r"\bBLOCK\b", result_text):
        critical = max(critical, 1)

    return critical, high


def main() -> None:
    try:
        raw = sys.stdin.read()
        if not raw.strip():
            return

        data = json.loads(raw)
    except Exception:
        return

    event_name = data.get("hook_event_name", "")
    if event_name != "TaskCompleted":
        return

    teammate_type = data.get("teammate_type", "")
    result_text = data.get("result", "")

    # Only gate reviewer agents (fw-review-* and fw-author-migration)
    if not (teammate_type.startswith("fw-review-") or teammate_type == "fw-author-migration"):
        return

    critical, high = _count_issues(result_text)

    if critical > 0:
        verdict = "BLOCK"
        msg = (
            f"QUALITY GATE: {teammate_type} found {critical} Critical "
            f"and {high} High issue(s). Resolve before proceeding."
        )
        print(msg, file=sys.stderr)
        sys.exit(2)

    output = {
        "decision": "allow" if high == 0 else "warn",
        "verdict": "APPROVE" if high == 0 else "WARNING",
        "critical_count": critical,
        "high_count": high,
    }
    print(json.dumps(output))


if __name__ == "__main__":
    try:
        main()
    except Exception:
        pass
    sys.exit(0)
