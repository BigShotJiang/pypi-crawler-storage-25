#!/usr/bin/env python3
"""
PostCompact Hook - Restores context AFTER context compaction.

Fires when Claude's context has been compacted (summarized).
Reads the pre-compact handoff file and outputs a context restoration
message to stderr so Claude can resume work with full awareness.

Key behaviors:
- Reads .claude/state/pre-compact-handoff.json for saved state
- Checks .sherlock-plan.md for plan tier and status
- Checks git log for recent TDD phase commits
- Outputs restoration summary to stderr
- Always exits 0 (non-blocking)
"""

import json
import re
import subprocess
import sys
from pathlib import Path

# ---------------------------------------------------------------------------
# Project root resolution — mirrors pre-compact.py pattern
# ---------------------------------------------------------------------------

try:
    from path_utils import get_project_root
    PROJECT_ROOT = get_project_root()
except ImportError:
    PROJECT_ROOT = Path.cwd()
    while PROJECT_ROOT != PROJECT_ROOT.parent:
        if (PROJECT_ROOT / '.git').exists():
            break
        PROJECT_ROOT = PROJECT_ROOT.parent

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _read_handoff(project_root: Path) -> dict:
    """Read pre-compact handoff JSON; return empty dict if missing or malformed."""
    handoff_path = project_root / '.claude' / 'state' / 'pre-compact-handoff.json'
    try:
        if handoff_path.exists():
            return json.loads(handoff_path.read_text())
    except Exception:
        pass
    return {}


def _parse_plan(project_root: Path) -> dict | None:
    """Parse .sherlock-plan.md for Tier and Status lines. Returns None if absent."""
    plan_path = project_root / '.sherlock-plan.md'
    if not plan_path.exists():
        return None

    tier = None
    status = None
    try:
        for line in plan_path.read_text().splitlines():
            if line.startswith('Tier:'):
                tier = line.split(':', 1)[1].strip()
            elif line.startswith('Status:'):
                status = line.split(':', 1)[1].strip()
    except Exception:
        pass

    return {'tier': tier, 'status': status}


def _get_recent_tdd_commits(project_root: Path) -> list[str]:
    """Run git log --oneline HEAD~20..HEAD and return lines matching tdd(...)."""
    try:
        result = subprocess.run(
            ['git', 'log', '--oneline', 'HEAD~20..HEAD'],
            capture_output=True,
            text=True,
            cwd=str(project_root),
            timeout=5,
        )
        if result.returncode != 0:
            return []
        lines = result.stdout.strip().splitlines()
        return [line for line in lines if re.search(r'tdd\(', line)]
    except Exception:
        return []


def _get_branch(project_root: Path) -> str:
    """Get current branch from git."""
    try:
        result = subprocess.run(
            ['git', 'rev-parse', '--abbrev-ref', 'HEAD'],
            capture_output=True,
            text=True,
            cwd=str(project_root),
            timeout=5,
        )
        if result.returncode == 0:
            return result.stdout.strip()
    except Exception:
        pass
    return 'UNKNOWN'


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------


def main():
    """Output context restoration message to stderr; always returns cleanly."""
    root = PROJECT_ROOT
    handoff = _read_handoff(root)
    plan = _parse_plan(root)

    lines = ['[post-compact-restore] Context restoration:']

    if plan is not None:
        # Plan-aware path (AC-4)
        if plan.get('tier'):
            lines.append(f"  Plan tier: {plan['tier']}")
        if plan.get('status'):
            lines.append(f"  Plan status: {plan['status']}")

        tdd_commits = _get_recent_tdd_commits(root)
        if tdd_commits:
            # Extract phase from the most recent matching commit
            first = tdd_commits[0]
            phase_match = re.search(r'tdd\(([^)]+)\)', first)
            phase = phase_match.group(1) if phase_match else 'unknown'
            lines.append(f"  Last TDD phase: {phase}")
        else:
            lines.append('  No recent TDD commits')
    else:
        # No-plan path (AC-5): include branch, skip plan labels
        branch = handoff.get('branch') or _get_branch(root)
        lines.append(f"  Branch: {branch}")

    print('\n'.join(lines), file=sys.stderr)


if __name__ == '__main__':
    main()
    sys.exit(0)
