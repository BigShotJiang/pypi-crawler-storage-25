"""
Frozen acceptance tests for the URL shortener task pack.

These tests are loaded post-drive by scoring.acceptance.run_pytest_on_frozen_suite
with WORKSPACE set to the driver-written workspace directory. The conftest.py
adds WORKSPACE to sys.path so `import shortener` resolves to the driver's code.

Six tests cover the URLShortener contract from prompt.md:
    T1 round-trip:   shorten then expand returns the original URL
    T2 idempotent:   shorten same URL twice returns identical short URL
    T3 distinct:     shorten of different URLs yields different codes
    T4 unknown_raises: expand on an unknown code raises KeyError
    T5 visit_clicks: visit increments stats["total_clicks"]
    T6 base_prefix:  short URL begins with the configured base_url

Each bug variant in injected_bugs/bug_NN.py is engineered to fail a
distinct subset of these six tests (AC-6: each bug detectable by at
least one test, no two bugs producing the same (passed, failed) tuple).
"""
import pytest

from shortener import URLShortener


def test_round_trip_returns_original_url():
    s = URLShortener()
    short = s.shorten("https://example.com/very/long/path?q=1")
    assert s.expand(short) == "https://example.com/very/long/path?q=1"


def test_idempotent_same_url_same_short():
    s = URLShortener()
    a = s.shorten("https://example.com/a")
    b = s.shorten("https://example.com/a")
    assert a == b


def test_distinct_urls_distinct_codes():
    s = URLShortener()
    a = s.shorten("https://example.com/a")
    b = s.shorten("https://example.com/b")
    assert a != b


def test_expand_unknown_code_raises_key_error():
    s = URLShortener()
    with pytest.raises(KeyError):
        s.expand("not_a_real_code_xyz")


def test_visit_increments_total_clicks():
    s = URLShortener()
    short = s.shorten("https://example.com/clickme")
    before = s.stats()["total_clicks"]
    assert before >= 0
    s.visit(short)
    s.visit(short)
    after = s.stats()["total_clicks"]
    assert after - before == 2


def test_short_url_starts_with_base_url():
    s = URLShortener()
    short = s.shorten("https://example.com/x")
    assert short.startswith("https://sh.rt/")
