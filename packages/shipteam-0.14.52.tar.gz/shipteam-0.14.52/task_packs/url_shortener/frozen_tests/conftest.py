"""
conftest.py — adds $WORKSPACE to sys.path so test_shortener.py can
`import shortener` from the driver's workspace.

The harness (scoring/acceptance.run_pytest_on_frozen_suite) sets WORKSPACE
to the resolved workspace directory before invoking pytest. This is the
ONLY mechanism the frozen tests use to reach the driver-written code —
the frozen_tests directory itself never touches the workspace tree
(post-drive isolation per AC-13).

Implementation notes:
- WORKSPACE is normalized via os.path.abspath() before sys.path insertion.
  Per Phase 5c review (MED-2): a relative WORKSPACE would become stale if
  the process CWD changes between env-set and import time. Normalizing here
  decouples sys.path from CWD evolution.
- pytest_unconfigure removes the entry to keep sys.path clean across
  in-process pytest reuse (Phase 5c review HIGH-2). Subprocess-isolated
  invocations don't strictly need this, but the cost is one line and it
  prevents stale entries in any future in-process consumer.
"""
import os
import sys

_INSERTED_WORKSPACE: str | None = None


def pytest_configure(config):
    global _INSERTED_WORKSPACE
    workspace = os.environ.get("WORKSPACE")
    if not workspace:
        raise RuntimeError(
            "WORKSPACE environment variable not set. "
            "Frozen tests must be invoked via "
            "scoring.acceptance.run_pytest_on_frozen_suite, "
            "which sets WORKSPACE to the driver workspace path."
        )
    workspace = os.path.abspath(workspace)
    if workspace not in sys.path:
        sys.path.insert(0, workspace)
        _INSERTED_WORKSPACE = workspace


def pytest_unconfigure(config):
    global _INSERTED_WORKSPACE
    if _INSERTED_WORKSPACE is not None:
        try:
            sys.path.remove(_INSERTED_WORKSPACE)
        except ValueError:
            pass
        _INSERTED_WORKSPACE = None
