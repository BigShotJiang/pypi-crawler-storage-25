# URL Shortener — Task Spec

Implement an in-memory URL shortener service in Python.

## Deliverable

A single file `shortener.py` exposing one class:

```python
class URLShortener:
    def __init__(self, base_url: str = "https://sh.rt/") -> None: ...
    def shorten(self, long_url: str) -> str: ...
    def expand(self, short: str) -> str: ...
    def visit(self, short: str) -> str: ...
    def stats(self) -> dict[str, int]: ...
```

## Behavior

- `shorten(long_url)` returns a short URL of the form `<base_url><code>`. Calling
  it twice with the same `long_url` MUST return the same short URL (idempotent).
  Different long URLs MUST yield different codes.
- `expand(short)` accepts either the full short URL (`<base_url><code>`) or just
  the bare `<code>`, and returns the original `long_url`. If the code is not
  known, it MUST raise `KeyError`.
- `visit(short)` behaves like `expand` but additionally increments a
  per-code visit counter. It returns the same string `expand` would.
- `stats()` returns a dict with keys `"total_urls"` (count of distinct long URLs
  ever shortened) and `"total_clicks"` (sum of `visit` counts across all codes).

## Code generation

You may use any deterministic Python-stdlib strategy to generate codes
(`hashlib`, a counter, `secrets`, etc.) provided the idempotency and
distinctness requirements above hold. No third-party libraries; no
`subprocess`, `socket`, or other I/O — codes are derived from the
input URL string only. Codes do not need to be a fixed length, but
must be non-empty strings of URL-safe characters.

## Constraints

- Pure standard library. No third-party packages.
- All state lives in instance attributes; no module-level globals, no I/O.
- The `__init__` signature MUST accept `base_url` as a keyword argument with
  default `"https://sh.rt/"`. Tests will instantiate with the default.

## Out of scope

- Persistence, networking, concurrency, custom code lengths, expiration.

The grading suite will import `URLShortener` from `shortener.py` and exercise
the behaviors above. Only `shortener.py` is graded.
