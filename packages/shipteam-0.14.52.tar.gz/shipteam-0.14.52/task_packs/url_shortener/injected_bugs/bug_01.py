"""bug_01 — shorten returns the long URL itself (no shortening)."""
import hashlib


class URLShortener:
    def __init__(self, base_url: str = "https://sh.rt/") -> None:
        self._base_url = base_url
        self._codes: dict[str, str] = {}
        self._urls: dict[str, str] = {}
        self._clicks: dict[str, int] = {}

    def _generate_code(self, long_url: str) -> str:
        return hashlib.sha256(long_url.encode("utf-8")).hexdigest()[:8]

    def _strip_prefix(self, short: str) -> str:
        if short.startswith(self._base_url):
            return short[len(self._base_url):]
        return short

    def shorten(self, long_url: str) -> str:
        # BUG: returns the long URL untransformed; ignores base_url and storage.
        return long_url

    def expand(self, short: str) -> str:
        code = self._strip_prefix(short)
        if code not in self._codes:
            raise KeyError(code)
        return self._codes[code]

    def visit(self, short: str) -> str:
        code = self._strip_prefix(short)
        if code not in self._codes:
            raise KeyError(code)
        self._clicks[code] += 1
        return self._codes[code]

    def stats(self) -> dict[str, int]:
        return {
            "total_urls": len(self._codes),
            "total_clicks": sum(self._clicks.values()),
        }
