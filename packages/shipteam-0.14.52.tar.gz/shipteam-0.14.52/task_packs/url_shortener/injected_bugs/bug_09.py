"""bug_09 — shorten generates fresh counter code AND doesn't store."""
import hashlib


class URLShortener:
    def __init__(self, base_url: str = "https://sh.rt/") -> None:
        self._base_url = base_url
        self._codes: dict[str, str] = {}
        self._urls: dict[str, str] = {}
        self._clicks: dict[str, int] = {}
        self._counter = 0

    def _generate_code(self, long_url: str) -> str:
        self._counter += 1
        return f"c{self._counter}"

    def _strip_prefix(self, short: str) -> str:
        if short.startswith(self._base_url):
            return short[len(self._base_url):]
        return short

    def shorten(self, long_url: str) -> str:
        # BUG: code is counter-based (no idempotency) AND no mapping stored —
        # any expand/visit on the returned short URL raises KeyError.
        code = self._generate_code(long_url)
        return self._base_url + code

    def expand(self, short: str) -> str:
        code = self._strip_prefix(short)
        if code not in self._codes:
            raise KeyError(code)
        return self._codes[code]

    def visit(self, short: str) -> str:
        code = self._strip_prefix(short)
        if code not in self._codes:
            raise KeyError(code)
        self._clicks[code] += 1
        return self._codes[code]

    def stats(self) -> dict[str, int]:
        return {
            "total_urls": len(self._codes),
            "total_clicks": sum(self._clicks.values()),
        }
