"""task_packs/loader.py — TaskPack loading and cost utilities."""
from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import yaml


CLAUDE_RATE_SHEET_2026_04: dict[str, dict[str, float]] = {
    "claude-opus-4-7": {
        "input_per_mtok": 15.0,
        "output_per_mtok": 75.0,
    },
    "claude-sonnet-4-5": {
        "input_per_mtok": 3.0,
        "output_per_mtok": 15.0,
    },
    "claude-haiku-3-5": {
        "input_per_mtok": 0.8,
        "output_per_mtok": 4.0,
    },
}

_PINNED_IMAGE_RE = re.compile(r"^[^:]+:[^@]+@sha256:[0-9a-f]{64}$")

# Reject any test_command that stops on first failure: -x or --exitfirst
# would inflate acceptance_pct by truncating the run before later failures
# are counted. The bidirectional check (no other forbidden flags here yet)
# stays minimal so it's clear what each rejection enforces.
_FORBIDDEN_TEST_COMMAND_FLAGS_RE = re.compile(r"(?:^|\s)(-x|--exitfirst)(?=\s|$)")

_REQUIRED_FIELDS = (
    "name",
    "container_image_pinned",
    "entry_point",
    "test_command",
    "stryker_config_path",
    "language",
    "seed",
)


def compute_cost(model_id: str, input_tokens: int, output_tokens: int) -> float:
    if not isinstance(model_id, str):
        raise TypeError(f"model_id must be a str, got {type(model_id)}")
    if model_id not in CLAUDE_RATE_SHEET_2026_04:
        raise KeyError(f"model_id {model_id!r} not found in CLAUDE_RATE_SHEET_2026_04")
    rates = CLAUDE_RATE_SHEET_2026_04[model_id]
    return (input_tokens / 1_000_000) * rates["input_per_mtok"] + (
        output_tokens / 1_000_000
    ) * rates["output_per_mtok"]


@dataclass(frozen=True)
class TaskPack:
    name: str
    container_image_pinned: str
    entry_point: str
    test_command: str
    stryker_config_path: str
    language: str
    seed: int
    pack_dir: Path

    def __post_init__(self) -> None:
        if not _PINNED_IMAGE_RE.match(self.container_image_pinned):
            raise ValueError(
                f"container_image_pinned must match <image>:<tag>@sha256:<64-hex-chars>; "
                f"got {self.container_image_pinned!r}"
            )

    def to_manifest_dict(self) -> dict[str, Any]:
        return {
            "entry_point": self.entry_point,
            "test_command": self.test_command,
            "stryker_config_path": self.stryker_config_path,
            "language": self.language,
        }


def load_pack(pack_dir: Path) -> TaskPack:
    pack_yaml = pack_dir / "pack.yaml"
    if not pack_yaml.exists():
        raise FileNotFoundError(f"pack.yaml not found: {pack_yaml}")

    with pack_yaml.open() as f:
        data = yaml.safe_load(f)

    if not isinstance(data, dict):
        raise ValueError(
            f"pack.yaml must parse to a YAML mapping; got {type(data).__name__} from {pack_yaml}"
        )

    for field in _REQUIRED_FIELDS:
        if field not in data:
            raise KeyError(
                f"Required field {field!r} missing in {pack_yaml}"
            )

    image = data["container_image_pinned"]
    if not _PINNED_IMAGE_RE.match(image):
        raise ValueError(
            f"container_image_pinned must match <image>:<tag>@sha256:<64-hex-chars>; "
            f"got {image!r}"
        )

    test_command = data["test_command"]
    if not isinstance(test_command, str):
        raise ValueError(
            f"test_command must be a string; got {type(test_command).__name__} from {pack_yaml}"
        )
    forbidden = _FORBIDDEN_TEST_COMMAND_FLAGS_RE.search(test_command)
    if forbidden:
        raise ValueError(
            f"test_command must not include {forbidden.group(1)!r} "
            f"(stops pytest on first failure, inflates acceptance_pct by skipping later cases). "
            f"Got: {test_command!r} from {pack_yaml}"
        )

    return TaskPack(
        name=data["name"],
        container_image_pinned=image,
        entry_point=data["entry_point"],
        test_command=data["test_command"],
        stryker_config_path=data["stryker_config_path"],
        language=data["language"],
        seed=data["seed"],
        pack_dir=pack_dir,
    )


def resolve_pack(task_id: str) -> TaskPack:
    pack_dir = Path("task_packs") / task_id
    return load_pack(pack_dir)
