"""
dashboard/render.py — Render benchmark JSONL to HTML with the ADR-007 denylist gate.

Reads JSONL benchmark results, groups by (driver, task), aggregates via
aggregate_cell, renders to HTML, and enforces the ADR-007 denylist gate.
"""
from __future__ import annotations

import json
import re
import sys
import unicodedata
from pathlib import Path

from jinja2 import Environment, select_autoescape

from aggregation.results import aggregate_cell, CellSummary

# ---------------------------------------------------------------------------
# Jinja2 inline template (no external template file to manage)
# ---------------------------------------------------------------------------

_TEMPLATE_SRC = """\
<!DOCTYPE html>
<html>
<head><title>Benchmark Dashboard</title></head>
<body>
<h1>Benchmark Dashboard</h1>
{% set mixed_digest_cells = cells | selectattr("mixed_digest") | list %}
{% if mixed_digest_cells %}
<div data-qa="digest-banner" class="warning banner">
  <strong>Mixed container digests detected in the following cells:</strong>
  <ul>
    {% for cell in mixed_digest_cells %}
    <li>{{ cell.driver }} / {{ cell.task }}</li>
    {% endfor %}
  </ul>
</div>
{% endif %}
{% set mixed_sdk_cells = cells | selectattr("mixed_sdk") | list %}
{% if mixed_sdk_cells %}
<div data-qa="sdk-banner" class="warning banner">
  <strong>Mixed SDK versions detected in the following cells:</strong>
  <ul>
    {% for cell in mixed_sdk_cells %}
    <li>{{ cell.driver }} / {{ cell.task }}</li>
    {% endfor %}
  </ul>
</div>
{% endif %}
{% if malformed_count > 0 %}
<div data-qa="malformed-rows-banner" class="warning banner">
  Skipped {{ malformed_count }} malformed row(s).
</div>
{% endif %}
{% for cell in cells %}
<section>
  <h2>{{ cell.driver }} / {{ cell.task }}</h2>
  <p>driver_version: {{ cell.driver_version }}</p>
  <p>n_complete: {{ cell.summary.n_complete }} | n_aborted: {{ cell.summary.n_aborted }}</p>
  {% if cell.summary.is_partial %}<p data-qa="partial-cell" class="warning">partial cell</p>{% endif %}
  {% if cell.mixed_digest %}<p data-qa="digest-badge" class="warning">mixed container digest</p>{% endif %}
  {% if cell.mixed_sdk %}<p data-qa="sdk-badge" class="warning">mixed sdk version</p>{% endif %}
  <table>
    <thead><tr><th>metric</th><th>p25</th><th>median</th><th>p75</th></tr></thead>
    <tbody>
    <tr>
      <td>acceptance_pct</td>
      <td>{{ cell.summary.acceptance_pct.p25 | fmt }}</td>
      <td>{{ cell.summary.acceptance_pct.median | fmt }}</td>
      <td>{{ cell.summary.acceptance_pct.p75 | fmt }}</td>
    </tr>
    <tr>
      <td>wall_clock_ms</td>
      <td>{{ cell.summary.wall_clock_ms.p25 | fmt }}</td>
      <td>{{ cell.summary.wall_clock_ms.median | fmt }}</td>
      <td>{{ cell.summary.wall_clock_ms.p75 | fmt }}</td>
    </tr>
    <tr>
      <td>cost_usd</td>
      <td>{{ cell.summary.cost_usd.p25 | fmt }}</td>
      <td>{{ cell.summary.cost_usd.median | fmt }}</td>
      <td>{{ cell.summary.cost_usd.p75 | fmt }}</td>
    </tr>
    </tbody>
  </table>
</section>
{% endfor %}
</body>
</html>
"""

def _fmt(value: float) -> str:
    """Format a float with 10 significant digits; `g` trims trailing zeros.

    `.10g` rounds away accumulated IEEE 754 noise (the percentile math here
    can emit e.g. 0.22499999999999998 for p25 of [0.2, 0.3]) while keeping
    exact small decimals like 0.00325 intact.
    """
    return f"{value:.10g}"


_ENV = Environment(autoescape=select_autoescape(["html"]))
_ENV.filters["fmt"] = _fmt
_TEMPLATE = _ENV.from_string(_TEMPLATE_SRC)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _load_denylist(denylist_path: Path) -> list[str]:
    """Load denylist tokens: skip blank lines and comment lines.

    Raises ValueError when the denylist parses zero tokens (file is 0 bytes,
    contains only blank lines, or contains only comment lines). An empty
    denylist is misconfiguration, not a legitimate state — the dashboard's
    primary safety property is denylist enforcement, so a gate that does
    nothing is a gate that does not exist. Distinct exception class from
    _check_denylist's RuntimeError so callers can distinguish "your config
    is wrong" from "your content leaked".
    """
    tokens: list[str] = []
    for line in denylist_path.read_text(encoding="utf-8").splitlines():
        stripped = line.strip()
        if stripped and not stripped.startswith("#"):
            tokens.append(stripped)
    if not tokens:
        raise ValueError(
            f"Denylist at {denylist_path} contains no tokens "
            "(empty after stripping comments and blank lines)"
        )
    return tokens


# Cyrillic letters that are visual confusables of Latin counterparts.
# NFKC alone does not fold cross-script confusables (they are not
# compatibility-equivalent within Unicode); this table covers the 6 letters
# exercised by the test suite. Expand as DA-15 test set grows.
_CYRILLIC_CONFUSABLES = str.maketrans({
    "р": "p",  # р → p
    "о": "o",  # о → o
    "а": "a",  # а → a
    "с": "c",  # с → c
    "е": "e",  # е → e
    "х": "x",  # х → x
})

# Zero-width and invisible Unicode characters that can be used to split tokens.
_ZERO_WIDTH_CHARS = frozenset("​‌‍﻿")


def _normalize_for_denylist(text: str) -> str:
    """Return a canonicalized form of *text* for denylist matching.

    Steps applied in order:
    1. NFKC normalization — folds compatibility variants (fullwidth, math
       alphanumeric, ligatures). Does NOT fold cross-script confusables
       (Cyrillic/Greek/Armenian) and does NOT strip combining marks.
    2. Cyrillic confusable substitution — 6-letter table covering the most
       common Cyrillic→Latin lookalikes. Greek, Armenian, combining-diacritic,
       and other Unicode bypass classes are NOT covered; the UTS #39 skeleton
       algorithm is the planned follow-up (see ADR-007).
    3. Zero-width character removal — strips 4 specific invisible chars
       (ZWSP, ZWNJ, ZWJ, BOM). Does NOT strip other Cf-category chars like
       U+2060 (word joiner) or U+180E (Mongolian vowel separator).
    4. Whitespace collapsing — removes all whitespace so 'pri cing' → 'pricing'.
    """
    normalized = unicodedata.normalize("NFKC", text)
    normalized = normalized.translate(_CYRILLIC_CONFUSABLES)
    normalized = "".join(c for c in normalized if c not in _ZERO_WIDTH_CHARS)
    normalized = re.sub(r"\s+", "", normalized)
    return normalized


def _token_matches(html: str, token: str) -> bool:
    """Return True when *token* appears as a whole word in *html* (case-insensitive).

    Uses word-boundary anchors so 'pricing' does not fire on 'repricing', but
    does fire on 'pricing-model' (hyphens are word-boundary characters in re).
    Returns False for an empty token string.
    """
    if not token:
        return False
    return bool(re.search(rf"\b{re.escape(token)}\b", html, re.IGNORECASE))


def _check_denylist(html: str, tokens: list[str]) -> None:
    """Raise RuntimeError if any denylist token matches (word-boundary, case-insensitive).

    Each token is checked against both the original HTML (to enforce word-boundary
    semantics for normal ASCII input) and a normalized form (to catch Unicode
    lookalike, zero-width-space, and ASCII-space bypass attempts). The token is
    normalized on the bypass path so multi-word entries survive whitespace removal
    on both sides before comparison.
    """
    normalized_html = _normalize_for_denylist(html)
    for token in tokens:
        normalized_token = _normalize_for_denylist(token)
        if _token_matches(html, token) or _token_matches(normalized_html, normalized_token):
            raise RuntimeError(
                f"Denylist violation: token {token!r} found in rendered HTML"
            )


def _detect_mixed_metadata(rows: list[dict], field: str) -> bool:
    """Return True when `rows` contain two or more distinct values for `field`.

    Used by the mixed-container-digest and mixed-sdk-version warnings
    (AC-10 (c)). `None` from a missing field counts as a distinct value — a
    row missing metadata is environment-unknown, which is warning-worthy.
    """
    return len({r.get(field) for r in rows}) > 1


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def render_dashboard(
    input_jsonl: Path,
    output_html: Path,
    denylist_path: Path = Path("release/denylist.txt"),
) -> None:
    """Render benchmark JSONL to an HTML dashboard with denylist enforcement.

    Raises:
        FileNotFoundError: if ``denylist_path`` does not exist.
        ValueError: if ``denylist_path`` exists but parses zero tokens
            (empty file, or only blank/comment lines). Misconfiguration is
            fail-closed — see ``_load_denylist``.
        RuntimeError: if any denylist token appears in the rendered output;
            no file is written in this case (atomic-write semantics).
    """

    # 1. Read and group rows by (driver, task)
    groups: dict[tuple[str, str], list[dict]] = {}
    driver_versions: dict[tuple[str, str], str] = {}
    malformed_count = 0

    for line in input_jsonl.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line:
            continue
        row = json.loads(line)
        if "driver" not in row or "task" not in row:
            malformed_count += 1
            continue
        key = (row["driver"], row["task"])
        groups.setdefault(key, []).append(row)
        # Track driver_version (last seen per cell is fine for rendering)
        driver_versions[key] = row.get("driver_version", "")

    # 2. Aggregate each cell + detect metadata homogeneity per AC-10 (c).
    # Mixed container_digest or mixed sdk_version within a single cell means
    # we are comparing runs from different environments — the median is still
    # computable but interpretation requires a hard warning (AC-10 (c):
    # dual-surface banner + per-cell badge, not silent data loss).
    # Detection reads row metadata directly; aggregate_cell's signature is
    # unchanged (AC-10 (c) scope boundary: aggregator is not expanded).
    cells = []
    for (driver, task), rows in groups.items():
        summary: CellSummary = aggregate_cell(rows)
        cells.append(
            {
                "driver": driver,
                "task": task,
                "driver_version": driver_versions[(driver, task)],
                "summary": summary,
                "mixed_digest": _detect_mixed_metadata(rows, "container_digest"),
                "mixed_sdk": _detect_mixed_metadata(rows, "sdk_version"),
            }
        )

    # 3. Render to string
    html = _TEMPLATE.render(cells=cells, malformed_count=malformed_count)

    # 4. Denylist gate — check BEFORE writing any file
    tokens = _load_denylist(denylist_path)
    _check_denylist(html, tokens)

    # 5. Write output
    output_html.write_text(html, encoding="utf-8")
