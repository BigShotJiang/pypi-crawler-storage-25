## Summary
<!-- 1-3 bullet points describing what this PR does -->

-

## Type of Change
- [ ] Bug fix (non-breaking change that fixes an issue)
- [ ] New feature (non-breaking change that adds functionality)
- [ ] Breaking change (fix or feature that would cause existing functionality to change)
- [ ] Documentation update
- [ ] Refactoring (no functional changes)

## Test Plan
<!-- How was this tested? -->

- [ ] Unit tests pass
- [ ] Integration tests pass
- [ ] Manual testing completed

## Checklist
- [ ] Code follows project style guidelines
- [ ] Self-review completed
- [ ] Tests added/updated for changes
- [ ] Documentation updated (if applicable)
- [ ] No security vulnerabilities introduced

## Insight (optional)
<!-- For maintainers: link to a design insight if this PR introduces a non-obvious decision -->
<!-- Format: Insight #N: Brief description -->
<!-- External contributors can skip this section -->
