# Copilot Instructions for ShipTeam

ShipTeam is a Claude Code development framework — a config-driven harness of hooks, scripts, rules, skills, and agents that enforce quality gates during AI-assisted development.

## Key Conventions

- **Config-driven**: `config/framework.yaml` defines framework behavior
- **Safety hooks**: `.claude/hooks/` contain auto-approve gates that block dangerous operations
- **Rules**: `.claude/rules/` contain mandatory guidelines (anti-patterns, security, database migrations)
- **Skills**: `.claude/skills/` define slash-command workflows (deploy, health, release-notes)
- **Agents**: `.claude/agents/` define specialized review agents

## Setup

First-time setup: run `claude` in the repo root and describe your project. Claude reads `SETUP.md` and handles configuration, the setup wizard, hooks, and verification automatically. See `SETUP.md` for manual setup.

## When Editing

- Never bypass safety hooks or auto-approve gates
- Never hardcode secrets or credentials
- Follow TDD workflow: RED (failing test) -> GREEN (minimal implementation) -> REFACTOR
- Run `/schema-check` before any database migration work
- Check `docs/` for relevant documentation before making changes

## Architecture

See `docs/10-ARCHITECTURE.md` for full details. The framework uses:
- Git worktrees for session isolation
- Multi-agent review pipelines with cost routing
- Tiered deployment (Tier 1/2/3) with auto version bumping
- 36 safety gate tests validating hook behavior

## File Structure

| Path | Purpose |
|------|---------|
| `.claude/hooks/` | Safety gate scripts |
| `.claude/rules/` | Mandatory development rules |
| `.claude/skills/` | Slash-command skill definitions |
| `.claude/agents/` | Specialized agent definitions |
| `scripts/` | Shell utilities and automation |
| `config/` | Framework configuration |
| `docs/` | Numbered documentation (00-80) |
| `tests/` | Safety gate test suite |
