"""
harness/container.py — Git repo sanitization for benchmark seed repos (AC-13)
                       AND containerized SUT execution for benchmark cells.

Two responsibilities:
  - sanitize_git_repo (Phase 5b): strip branches, reflogs, future-dated
    commits from a seed repo. SWE-Bench#465 regression guard.
  - run_container_for_seed (Phase 5d): spawn a tightly-isolated docker
    container under the Option A inline run-and-done model — the container
    CMD IS the per-driver SUT runner script, which writes a result.json
    into the bind-mounted workspace before exiting. The host then reads
    that file into a DriverResult. AC-8 + AC-13 + AC-16 enforced at the
    subprocess boundary; remote daemons (R15/R17) and non-$HOME workspace
    paths (Colima mount-set constraint) are refused at preflight.

The per-driver SUT runner scripts (the ones that actually write
result.json) are Phase 5e work. Phase 5d wires the host side and stubs the
absent-file case as an aborted-row tombstone.
"""
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path
from typing import TYPE_CHECKING

from drivers._protocol import AbortReason, DriverResult

if TYPE_CHECKING:
    from drivers._protocol import Driver
    from task_packs.loader import TaskPack


class SanitizationError(RuntimeError):
    """Raised when sanitize_git_repo cannot complete its contract."""


def _git(repo: Path, *args: str, env: dict | None = None) -> subprocess.CompletedProcess:
    full_env = {**os.environ,
                "GIT_AUTHOR_NAME": "sanitize",
                "GIT_AUTHOR_EMAIL": "sanitize@harness",
                "GIT_COMMITTER_NAME": "sanitize",
                "GIT_COMMITTER_EMAIL": "sanitize@harness"}
    if env:
        full_env.update(env)
    return subprocess.run(
        ["git", "-C", str(repo), *args],
        capture_output=True, text=True, check=True, env=full_env,
    )


def _iso_date_prefix(iso_datetime: str) -> str:
    """Return the YYYY-MM-DD prefix of an ISO author-date string."""
    return iso_datetime[:10]


def sanitize_git_repo(repo: Path, pack_revision_date: str) -> None:
    """
    Sanitize a git repository for use as a benchmark seed.

    1. Rewind HEAD to the most recent commit on the current branch whose
       author date is on or before pack_revision_date. This is the AC-13
       load-bearing step: a future-dated commit on HEAD (the SWE-Bench#465
       pattern) is physically removed from the current branch history.
    2. Delete all branches except the current one. Failure to delete any
       branch is a contract violation → raises SanitizationError.
    3. Remove reflogs (.git/logs/) entirely.
    4. Run `git gc --prune=now` to remove unreachable objects. Failure here
       is a hard error — without gc, stripped commits remain accessible via
       `git cat-file` and `git log --all` can still reach them.

    Args:
        repo: Path to the git repository (worktree root).
        pack_revision_date: ISO date string (YYYY-MM-DD). Commits on HEAD
            authored after this date are stripped.

    Raises:
        SanitizationError: when any required step cannot complete.
    """
    # 1. Rewind HEAD past any future-dated commits on the current branch.
    try:
        log_result = _git(repo, "log", "HEAD", "--format=%H %ai")
    except subprocess.CalledProcessError as exc:
        raise SanitizationError(
            f"sanitize_git_repo: failed to read HEAD log in {repo}: {exc.stderr.strip()}"
        ) from exc

    target_sha: str | None = None
    for line in log_result.stdout.splitlines():
        if not line.strip():
            continue
        sha, ai = line.split(" ", 1)
        if _iso_date_prefix(ai) <= pack_revision_date:
            target_sha = sha
            break

    if target_sha is None:
        raise SanitizationError(
            f"sanitize_git_repo: no commit on HEAD is dated on or before "
            f"{pack_revision_date!r} in {repo}; cannot rewind safely."
        )

    try:
        _git(repo, "reset", "--hard", target_sha)
    except subprocess.CalledProcessError as exc:
        raise SanitizationError(
            f"sanitize_git_repo: git reset --hard {target_sha} failed: {exc.stderr.strip()}"
        ) from exc

    # 2. Delete non-current branches. A failure here violates the sanitization
    #    contract: a surviving branch may contain solution leaks that `git log
    #    --all` can still reach.
    current_branch = _git(repo, "rev-parse", "--abbrev-ref", "HEAD").stdout.strip()
    branches_raw = _git(repo, "branch", "--list").stdout
    all_branches: list[str] = []
    for line in branches_raw.splitlines():
        name = line.strip().lstrip("* ").strip()
        if name:
            all_branches.append(name)

    for branch in all_branches:
        if branch == current_branch:
            continue
        try:
            _git(repo, "branch", "-D", branch)
        except subprocess.CalledProcessError as exc:
            raise SanitizationError(
                f"sanitize_git_repo: failed to delete branch {branch!r} in "
                f"{repo}: {exc.stderr.strip()}"
            ) from exc

    # 3. Remove reflogs.
    logs_dir = repo / ".git" / "logs"
    if logs_dir.exists():
        shutil.rmtree(logs_dir)

    # 4. gc --prune=now removes unreachable objects. Load-bearing for AC-13:
    #    without it, stripped commits remain addressable via `git cat-file`.
    try:
        _git(repo, "gc", "--prune=now", "--quiet")
    except subprocess.CalledProcessError as exc:
        raise SanitizationError(
            f"sanitize_git_repo: git gc failed in {repo}: {exc.stderr.strip()}"
        ) from exc


# ---------------------------------------------------------------------------
# Phase 5d — run_container_for_seed (AC-8, AC-13, AC-16)
# ---------------------------------------------------------------------------

# AC-16 R17 two-part error template. Platform hints + captured stderr.
# Operator-actionable text was the explicit ask from /deep-r R17.
_DOCKER_INFO_FAILED_TEMPLATE = (
    "Docker required for sandboxed benchmark execution "
    "(cwd is not a security boundary — SDK Issue #36).\n"
    "  - macOS Docker Desktop: open Docker Desktop and wait for 'Engine running'.\n"
    "  - macOS Colima: run 'colima start' (and 'brew install colima' if missing).\n"
    "  - Linux: run 'sudo systemctl start docker' "
    "(and 'sudo usermod -aG docker $USER' if first-time).\n"
    "  - Verify with: docker info\n"
    "Underlying error: {stderr}"
)

# AC-16 R15/R17 redesign (Phase 5d empirical probe): allow ANY unix:// socket
# (default, Colima, rootless, podman emulation). Refuse tcp:// and ssh://
# unless explicit operator opt-in via env. The threat model is "remote
# daemon proxies bind-mounts to a host the client can't see," not "any
# non-default socket path."
_REMOTE_ENDPOINT_SCHEMES = ("tcp://", "ssh://")
_REMOTE_OVERRIDE_ENV = "SHIPTEAM_ALLOW_REMOTE_DOCKER"


def _resolve_docker_endpoint() -> str:
    """Return the active docker daemon endpoint URI.

    Uses `docker context inspect` rather than `docker context show` because
    `show` returns the context NAME (e.g., "default") which is misleading
    when DOCKER_HOST overrides the endpoint — a tcp:// override leaves the
    name as "default" but the URI as the attacker-controlled URL.
    Empirically verified 2026-04-27 with a DOCKER_HOST override probe.

    Returns the endpoint URI verbatim. Best-effort: if docker is missing
    entirely, returns empty string (the docker-info preflight will then
    fire with a clearer error).
    """
    try:
        proc = subprocess.run(
            ["docker", "context", "inspect", "--format",
             "{{.Endpoints.docker.Host}}"],
            capture_output=True, text=True, check=False,
        )
    except FileNotFoundError:
        # Docker binary missing entirely — let the docker-info preflight
        # raise the operator-actionable RuntimeError instead of swallowing
        # an unrelated PermissionError or PATH problem here.
        return ""
    return proc.stdout.strip()


def _check_docker_endpoint_allowed() -> None:
    """AC-16 R15/R17: refuse tcp:// and ssh:// daemon endpoints.

    Bind mounts resolve on the daemon's host, not the client's — a remote
    daemon makes `--volume <host_workspace>:/workspace` mount a path the
    daemon may not have, silently producing an empty workspace and
    `acceptance_pct=0.0` recorded as a legitimate driver failure.

    Resolves endpoint once and routes either to (a) audit-log + permit when
    the operator has opted in via SHIPTEAM_ALLOW_REMOTE_DOCKER=1, or
    (b) refuse with an error message naming both the endpoint URI AND the
    DOCKER_HOST source if set, so the operator can trace WHERE the override
    came from.
    """
    endpoint = _resolve_docker_endpoint()
    is_remote = any(endpoint.startswith(s) for s in _REMOTE_ENDPOINT_SCHEMES)

    if os.environ.get(_REMOTE_OVERRIDE_ENV) == "1":
        if is_remote:
            # Audit log the bypass so it doesn't go silent — without this,
            # an unintentional env-leak could make every JSONL row record
            # against an attacker-controlled daemon with no operator visibility.
            print(
                f"[shipteam] WARNING: {_REMOTE_OVERRIDE_ENV}=1 set; "
                f"bypassing AC-16 remote-daemon refusal "
                f"(endpoint={endpoint!r}). Workspace bind-mounts will resolve "
                f"on the daemon's host, NOT this client.",
                file=sys.stderr,
            )
        return  # operator has explicitly opted in; trust the override

    if is_remote:
        docker_host_env = os.environ.get("DOCKER_HOST", "")
        source_hint = (
            f" (DOCKER_HOST={docker_host_env!r})"
            if docker_host_env
            else " (active docker context)"
        )
        raise RuntimeError(
            f"Docker daemon endpoint is remote (got: {endpoint!r}{source_hint}). "
            f"Bind mounts resolve on the daemon's host, not the client "
            f"— benchmark workspace would be empty. "
            f"Set {_REMOTE_OVERRIDE_ENV}=1 to override."
        )


def _check_docker_info_available() -> None:
    """AC-16: `docker info` must succeed before we attempt any container ops."""
    try:
        proc = subprocess.run(
            ["docker", "info"],
            capture_output=True, text=True, check=False,
        )
    except FileNotFoundError as exc:
        # docker binary missing on PATH — distinct from "daemon down."
        # Same operator-actionable template; the inner stderr names the cause.
        raise RuntimeError(
            _DOCKER_INFO_FAILED_TEMPLATE.format(
                stderr=f"docker binary not found on PATH ({exc})"
            )
        ) from exc
    if proc.returncode != 0:
        raise RuntimeError(
            _DOCKER_INFO_FAILED_TEMPLATE.format(stderr=proc.stderr.strip())
        )


def _check_workspace_under_home(workspace_dir: Path) -> None:
    """AC-8: workspace MUST resolve under $HOME for bind-mount portability.

    Empirically verified 2026-04-27: macOS Colima's default mount set is
    $HOME and /tmp/colima only. A bind mount of /tmp/* or /var/folders/*
    silently produces an empty host directory after `--rm` (writes live in
    the VM's ephemeral overlay). Without this check, `tempfile.mkdtemp()`
    would land the workspace in /var/folders/... by default and produce a
    silent benchmark-invalidating failure at scoring time.
    """
    home = Path.home().resolve()
    resolved = workspace_dir.resolve()
    if resolved == home:
        return  # workspace == $HOME itself is fine
    if home not in resolved.parents:
        raise RuntimeError(
            f"Workspace path must be under $HOME for Docker bind-mount "
            f"portability (Colima default mount set on macOS is $HOME only; "
            f"/tmp/* and /var/folders/* silently produce empty mounts). "
            f"Got workspace_dir={workspace_dir!r}, $HOME={home!s}. "
            f"Recommended: ~/.cache/shipteam/workspaces/{{task_id}}/seed-{{seed}}/"
        )


def _build_docker_run_argv(
    *,
    container_image: str,
    workspace_dir: Path,
    pack: "TaskPack",
) -> list[str]:
    """Assemble the `docker run` argv with all AC-13 security flags.

    Returns the full argv as a list. Each flag is positional and ordered
    so the test assertions can locate them by index-aware lookup or by
    presence in the joined string.

    Security flag rationale:
      --rm                : auto-remove container; no leaked state across runs
      --read-only         : root FS RO; SUT cannot persist anything outside mounts
      --cap-drop=ALL      : CapEff/CapBnd=0 (verified 2026-04-27 alpine probe)
      -u 1000:1000        : non-root SUT
      --tmpfs /tmp:...    : SUT-writable /tmp with noexec+nosuid (defense-in-depth)
      --workdir /workspace: SUT cwd defaults to the writable mount

    Mounts:
      <workspace>:/workspace:rw — SUT's writable workspace (host-mounted for
                                  scoring to see what was written)
      <pack>/frozen_tests:/frozen_tests:ro — AC-13 boundary: oracle is RO
      <pack>/injected_bugs:/injected_bugs:ro — mutants are RO
    """
    frozen_tests_src = pack.pack_dir / "frozen_tests"
    injected_bugs_src = pack.pack_dir / "injected_bugs"
    return [
        "docker", "run", "--rm",
        "--read-only",
        "--cap-drop=ALL",
        "-u", "1000:1000",
        "--tmpfs", "/tmp:rw,noexec,nosuid,size=64m",
        "--workdir", "/workspace",
        "--volume", f"{workspace_dir.resolve()}:/workspace:rw",
        "--volume", f"{frozen_tests_src.resolve()}:/frozen_tests:ro",
        "--volume", f"{injected_bugs_src.resolve()}:/injected_bugs:ro",
        container_image,
    ]


# Container result handoff (Option A — inline run-and-done):
# The container CMD IS the per-driver SUT runner script. The runner writes
# `RESULT_RELATIVE_PATH` inside the workspace before exiting. The host reads
# this file post-`docker run` and lifts it into a DriverResult. The schema
# is per-driver but the file path + the surrounding wrapper are stable so
# host-side aggregation never needs to know which driver produced the row.
RESULT_RELATIVE_PATH = Path(".shipteam") / "result.json"

# Grace seconds added to max_wall_clock_minutes for the subprocess.run timeout.
# Inside-container budget is the wall-clock; host-side timeout adds slack so
# `docker run` returns control even if the SUT's own timeout enforcement
# misfires by a few seconds. The container-side `--rm` then garbage-collects
# the (still-running) container — `docker kill` of the orphaned container is
# Phase 5e work, scoped with the per-driver container naming convention.
_TIMEOUT_GRACE_SECONDS = 30


def run_container_for_seed(
    driver: "Driver",  # noqa: ARG001 — Phase 5e per-driver runner-image hook
    task: str,         # noqa: ARG001 — Phase 5e per-task image build args
    seed: int,         # noqa: ARG001 — Phase 5e per-seed env injection
    budget_usd: float,  # noqa: ARG001 — Phase 5e SUT runner env injection
    max_wall_clock_minutes: int,
    container_image: str,
    pack: "TaskPack",
    workspace_dir: Path,
) -> DriverResult:
    """
    Run one benchmark seed inside a tightly-isolated docker container.

    Preflight order is significant:
      1. Endpoint scheme (cheap; no daemon required)
      2. Workspace path (cheap; pure path inspection)
      3. `docker info` (medium; requires daemon contact)

    Container lifecycle (Option A — inline run-and-done):
      - The container CMD IS the per-driver SUT runner script (built into
        the image). Phase 5d wires the host side; the runner script is
        per-driver work that lands in Phase 5e.
      - The runner writes `<workspace>/.shipteam/result.json` before exiting.
      - This function reads that file post-container into a DriverResult.
        Absent file ⇒ aborted-row tombstone (placeholder until per-driver
        runners exist).

    Most of `driver`/`task`/`seed`/`budget_usd` are kept on the signature
    surface for Phase 5e — the per-driver image-build hook will need them
    to inject runner env vars. They are unused under the Phase 5d placeholder.

    Raises:
        RuntimeError: AC-16 (docker unavailable / remote endpoint),
                      AC-8 (workspace not under $HOME).
    """
    _check_docker_endpoint_allowed()
    _check_workspace_under_home(workspace_dir)
    _check_docker_info_available()

    docker_argv = _build_docker_run_argv(
        container_image=container_image,
        workspace_dir=workspace_dir,
        pack=pack,
    )

    timeout_seconds = max_wall_clock_minutes * 60 + _TIMEOUT_GRACE_SECONDS
    try:
        proc = subprocess.run(
            docker_argv,
            capture_output=True, text=True,
            check=False, timeout=timeout_seconds,
        )
    except subprocess.TimeoutExpired:
        # Container exceeded wall-clock budget. The daemon still owns the
        # running container; `--rm` will clean it up when it eventually
        # exits (or when explicit `docker kill` lands in Phase 5e).
        return DriverResult(
            wall_clock_ms=timeout_seconds * 1000,
            input_tokens=None,
            output_tokens=None,
            cost_usd=None,
            cost_source="computed",
            aborted=True,
            abort_reason=AbortReason(
                "wall_clock_exceeded",
                f"container exceeded wall_clock budget {timeout_seconds}s "
                f"(includes {_TIMEOUT_GRACE_SECONDS}s host-side grace)",
            ),
            cache_strategy="salted",
            driver_metadata={},
        )

    return _parse_container_result(
        workspace_dir=workspace_dir,
        returncode=proc.returncode,
        stderr=proc.stderr,
    )


def _parse_container_result(
    *,
    workspace_dir: Path,
    returncode: int,
    stderr: str,
) -> DriverResult:
    """Lift `<workspace>/.shipteam/result.json` into a DriverResult.

    Phase 5d placeholder: per-driver SUT runner scripts (Phase 5e) are what
    actually write this file. If the file is absent, return an aborted-row
    tombstone so `runner.py` records a JSONL row for the seed instead of
    raising — the operator should see "no runner produced a result" as a
    row, not as an unhandled exception that would skip subsequent seeds.

    Future work (Phase 5e): formalize the JSON schema. For now we accept a
    flat dict keyed by DriverResult fields plus an optional `abort_reason`
    sub-dict matching `{"category": str, "detail": str}`.
    """
    result_path = workspace_dir / RESULT_RELATIVE_PATH
    if not result_path.exists():
        # Truncate stderr at 200 chars so a runaway stderr stream doesn't
        # bloat the JSONL row beyond reason. Operator triage uses the head.
        stderr_preview = stderr.strip()[:200]
        return DriverResult(
            wall_clock_ms=0,
            input_tokens=None,
            output_tokens=None,
            cost_usd=None,
            cost_source="computed",
            aborted=True,
            abort_reason=AbortReason(
                "driver_error",
                f"result.json not written by container "
                f"(returncode={returncode}, stderr_head={stderr_preview!r})",
            ),
            cache_strategy="salted",
            driver_metadata={},
        )

    raw = json.loads(result_path.read_text())
    abort_raw = raw.get("abort_reason")
    abort = AbortReason(**abort_raw) if abort_raw else None
    return DriverResult(
        wall_clock_ms=raw["wall_clock_ms"],
        input_tokens=raw.get("input_tokens"),
        output_tokens=raw.get("output_tokens"),
        cost_usd=raw.get("cost_usd"),
        cost_source=raw["cost_source"],
        aborted=raw["aborted"],
        abort_reason=abort,
        cache_strategy=raw["cache_strategy"],
        driver_metadata=raw.get("driver_metadata", {}),
    )
