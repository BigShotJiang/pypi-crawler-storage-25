"""
harness/runner.py — run_cell: execute one benchmark cell (driver x task x seeds).

Patches expected by tests:
  - harness.runner.load_driver
  - harness.runner.run_container_for_seed
  - harness.runner.score_workspace
"""
from __future__ import annotations

import shutil
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from aggregation.results import append_result_row
from harness.container import run_container_for_seed
from scoring.acceptance import score_acceptance
from scoring.mutation import score_mutation
from task_packs.loader import resolve_pack

_HARNESS_VERSION = "0.1.0"

# Registry of supported driver names. Phase 5d expands from claude_code
# only (Phase 5a) to all three v1 drivers. Adding a driver here is a
# one-line change; the ValueError below names this set so an operator
# typo at the CLI gets a self-correcting error message rather than a
# silent fallback.
_SUPPORTED_DRIVERS = ("claude_code", "aider", "droid")


# ---------------------------------------------------------------------------
# Driver registry + workspace scoring aggregator
# ---------------------------------------------------------------------------

def load_driver(driver_name: str) -> Any:
    """Return a Driver instance for the named adapter.

    Imports are local so an unrelated driver's import error (e.g., aider's
    optional CLI dep missing) doesn't break the others.
    """
    if driver_name == "claude_code":
        from drivers.claude_code import ClaudeCodeDriver
        return ClaudeCodeDriver()
    if driver_name == "aider":
        from drivers.aider import AiderDriver
        return AiderDriver()
    if driver_name == "droid":
        from drivers.droid import DroidDriver
        return DroidDriver()
    raise ValueError(
        f"Unknown driver: {driver_name!r}. "
        f"Supported: {_SUPPORTED_DRIVERS!r}"
    )


def score_workspace(workspace_dir: Path, pack: Any) -> dict:
    """Aggregate acceptance + mutation scoring for one cell.

    AC-13 boundary: score_acceptance enforces the workspace/frozen_tests
    isolation guard (bidirectional ancestor + inode overlap); its
    RuntimeError on hardlink/bind-mount tampering propagates UNCHANGED so
    the cell aborts loudly rather than recording a 0.0 acceptance row that
    looks like an honest driver failure. `run_cell` reflects this by NOT
    catching RuntimeError — the broken-isolation cell stops mid-run.

    semgrep_high / semgrep_critical / injected_bug_detections are stub'd
    to 0 (not None) so the JSONL row schema stays stable for v1 smoke runs.
    Real semgrep scoring and bug-detection scoring are scoped to v1.1, not
    Phase 5e/5f — the v1 thesis is acceptance + mutation as the load-bearing
    quality signals; everything else is downstream UX.
    """
    frozen_tests = pack.pack_dir / "frozen_tests"
    acceptance = score_acceptance(workspace_dir, frozen_tests)
    mutation = score_mutation(workspace_dir, pack.to_manifest_dict())

    mutation_score: dict = {}
    for lang, lang_score in mutation.per_language.items():
        if lang_score is None:
            continue
        mutation_score[lang] = {
            "killed": lang_score.killed,
            "survived": lang_score.survived,
            "timeout": lang_score.timeout,
            "score": lang_score.score,
        }

    return {
        "acceptance_pct": acceptance.acceptance_pct,
        "mutation_score": mutation_score,
        "semgrep_high": 0,
        "semgrep_critical": 0,
        "injected_bug_detections": 0,
    }


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _extract_digest(container_image: str) -> str:
    """
    Extract the sha256 digest portion from a pinned image reference.

    AC-3 reproducibility: every row must record a content-addressed digest.
    A tag-only reference (e.g. `python:3.12`) is mutable; silently accepting
    it would falsify AC-3 without raising. Refuse at the boundary.
    """
    if "@sha256:" not in container_image:
        raise ValueError(
            f"container_image must be pinned by @sha256:<digest>, got {container_image!r}. "
            "Tags are not reproducible."
        )
    return container_image.split("@", 1)[1]


# ---------------------------------------------------------------------------
# run_cell — main entry point
# ---------------------------------------------------------------------------

def run_cell(
    driver: str,
    task: str,
    seeds: list[int],
    budget_usd: float,
    max_wall_clock_minutes: int,
    output_jsonl: Path,
    container_image: str,
    require_sdk_version_gate: bool = True,
) -> int:
    """
    Execute one benchmark cell: driver x task x seeds.

    For each seed, runs the driver via run_container_for_seed, scores the
    workspace, assembles a ResultRow, and appends it to output_jsonl.

    Returns 0 on success.
    """
    driver_instance = load_driver(driver)
    container_digest = _extract_digest(container_image)
    pack = resolve_pack(task)

    driver_version = driver_instance.version()
    sdk_version = driver_instance.sdk_version()
    sdk_release_date = driver_instance.release_date()

    for seed in seeds:
        # AC-8: workspace must live under $HOME for Colima/Docker bind-mount
        # portability. Phase 5d empirical-probe finding: macOS Colima default
        # mount set is $HOME only — /tmp/* and /var/folders/* silently produce
        # phantom mounts.
        workspace_dir = (
            Path.home() / ".cache" / "shipteam" / "workspaces"
            / task / f"seed-{seed}"
        )
        # Cleanup before each seed: a stale workspace from a prior run can
        # contaminate scoring (frozen_tests pass against last-run output, not
        # this-run output). `mkdir(exist_ok=True)` alone is insufficient
        # because the directory contents persist.
        if workspace_dir.exists():
            shutil.rmtree(workspace_dir)
        workspace_dir.mkdir(parents=True)

        # The two boundaries are split deliberately: an AC-13 RuntimeError
        # from score_workspace is a broken-isolation signal that MUST stop
        # the cell, not be tombstoned as if the driver itself failed. Only
        # driver-side failures (network, container, missing tokens) get the
        # per-seed tombstone treatment.
        try:
            result = run_container_for_seed(
                driver=driver_instance,
                task=task,
                seed=seed,
                budget_usd=budget_usd,
                max_wall_clock_minutes=max_wall_clock_minutes,
                container_image=container_image,
                pack=pack,
                workspace_dir=workspace_dir,
            )
        except Exception as exc:
            # Per-seed isolation: write a tombstone row so the JSONL retains
            # a record for every attempted seed. Subsequent seeds still run.
            _write_tombstone(
                driver=driver,
                driver_version=driver_version,
                sdk_version=sdk_version,
                sdk_release_date=sdk_release_date,
                task=task,
                task_pack_revision=container_digest,
                seed=seed,
                container_digest=container_digest,
                abort_reason=f"driver_error: {exc!r}",
                output_jsonl=output_jsonl,
            )
            continue

        # NOT wrapped in try: AC-13 RuntimeError from score_acceptance must
        # propagate. The score_workspace docstring is the contract.
        scores = score_workspace(
            workspace_dir=workspace_dir,
            pack=pack,
        )

        timestamp_utc = datetime.now(timezone.utc).isoformat()

        row: dict = {
            "driver": driver,
            "driver_version": driver_version,
            "task": task,
            "task_pack_revision": container_digest,
            "seed": seed,
            "container_digest": container_digest,
            "harness_version": _HARNESS_VERSION,
            "sdk_version": sdk_version,
            "sdk_release_date": sdk_release_date,
            "timestamp_utc": timestamp_utc,
            "wall_clock_ms": result.wall_clock_ms,
            "input_tokens": result.input_tokens,
            "output_tokens": result.output_tokens,
            "cost_usd": result.cost_usd,
            "cost_source": result.cost_source,
            "acceptance_pct": scores["acceptance_pct"],
            "mutation_score": scores.get("mutation_score", {}),
            "semgrep_high": scores["semgrep_high"],
            "semgrep_critical": scores["semgrep_critical"],
            "injected_bug_detections": scores["injected_bug_detections"],
            "aborted": result.aborted,
            "abort_reason": result.abort_reason,
            "cache_strategy": result.cache_strategy,
            "driver_metadata": result.driver_metadata,
        }

        append_result_row(row, output_jsonl)

    return 0


def _write_tombstone(
    *,
    driver: str,
    driver_version: str,
    sdk_version: str,
    sdk_release_date: str,
    task: str,
    task_pack_revision: str,
    seed: int,
    container_digest: str,
    abort_reason: str,
    output_jsonl: Path,
) -> None:
    """Write a minimal aborted-row tombstone when a seed fails mid-execution."""
    row = {
        "driver": driver,
        "driver_version": driver_version,
        "task": task,
        "task_pack_revision": task_pack_revision,
        "seed": seed,
        "container_digest": container_digest,
        "harness_version": _HARNESS_VERSION,
        "sdk_version": sdk_version,
        "sdk_release_date": sdk_release_date,
        "timestamp_utc": datetime.now(timezone.utc).isoformat(),
        "wall_clock_ms": 0,
        "input_tokens": None,
        "output_tokens": None,
        "cost_usd": None,
        # "computed" not "native" — there was no native billing event to source
        # from; the row exists because the seed aborted before the driver could
        # report a real cost. Filtering by cost_source="native" downstream
        # would otherwise pick up tombstones as if they were billed runs.
        "cost_source": "computed",
        "acceptance_pct": 0.0,
        "mutation_score": {},
        "semgrep_high": 0,
        "semgrep_critical": 0,
        "injected_bug_detections": 0,
        "aborted": True,
        "abort_reason": abort_reason,
        "cache_strategy": "salted",
        "driver_metadata": {"cache_strategy": "salted", "cache_read_input_tokens": 0},
    }
    append_result_row(row, output_jsonl)
