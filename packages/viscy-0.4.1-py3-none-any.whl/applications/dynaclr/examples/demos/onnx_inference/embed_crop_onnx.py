"""Minimal ONNX inference example for a DynaCLR 2D-MIP model.

Loads an exported ``.onnx`` model and embeds a single ``(H, W)`` cell crop
into a 768-dim feature vector. The ONNX graph expects input shape
``(B, C, Z, H, W)`` with ``Z=1`` (the only frozen axis); ``B``, ``C``, ``H``,
and ``W`` are dynamic, so the same model handles batches of any size and
square or rectangular crops.

Pixel-size-aware extract → resize matches the training pipeline:
``source_shape = round(size * image_um / training_um)`` is extracted from
the image, then resized to the model's input size. Use
``--image-pixel-size-um`` and ``--training-pixel-size-um`` to enable; if
both are omitted the crop is taken at the model's input size directly.

Usage
-----
Run with a synthetic crop (defaults to 160x160 — the training crop size)::

    python embed_crop_onnx.py \
        --onnx /hpc/projects/.../onnx/epoch=105-step=84800.onnx

Run on a real 2D image, rescaling for pixel-size differences::

    python embed_crop_onnx.py \
        --onnx /hpc/projects/.../onnx/epoch=105-step=84800.onnx \
        --image /path/to/cell_crop.tif \
        --size 160 \
        --image-pixel-size-um 0.190 \
        --training-pixel-size-um 0.149
"""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import onnxruntime as ort
from skimage.transform import resize


def load_image(path: Path) -> np.ndarray:
    """Load a 2D grayscale image as float32.

    Parameters
    ----------
    path : Path
        Path to a TIFF or PNG.

    Returns
    -------
    np.ndarray
        2D ``(H, W)`` float32 array.
    """
    from skimage.io import imread

    img = imread(str(path)).astype(np.float32)
    if img.ndim == 3:
        img = img.mean(axis=-1)
    return img


def center_crop_or_pad(img: np.ndarray, shape: tuple[int, int]) -> np.ndarray:
    """Center-crop or reflect-pad ``img`` to ``shape``.

    Parameters
    ----------
    img : np.ndarray
        2D ``(H, W)`` array.
    shape : tuple[int, int]
        Target ``(H, W)``.

    Returns
    -------
    np.ndarray
        2D ``shape`` array.
    """
    h, w = img.shape
    th, tw = shape

    h_src = min(h, th)
    w_src = min(w, tw)
    y0_src = (h - h_src) // 2
    x0_src = (w - w_src) // 2
    cropped = img[y0_src : y0_src + h_src, x0_src : x0_src + w_src]

    pad_top = (th - h_src) // 2
    pad_bot = th - h_src - pad_top
    pad_left = (tw - w_src) // 2
    pad_right = tw - w_src - pad_left
    if pad_top or pad_bot or pad_left or pad_right:
        cropped = np.pad(
            cropped,
            ((pad_top, pad_bot), (pad_left, pad_right)),
            mode="reflect",
        )
    return cropped


def extract_and_resize(
    img: np.ndarray,
    final_shape: tuple[int, int],
    pixel_size_scale: float,
) -> np.ndarray:
    """Extract at scaled size then resize to ``final_shape``.

    Matches the inference pipeline in
    ``dynaclr.evaluation.benchmarking.tracking_accuracy.evaluate_tracking``.

    Parameters
    ----------
    img : np.ndarray
        2D source image.
    final_shape : tuple[int, int]
        ``(H, W)`` of the model input.
    pixel_size_scale : float
        ``image_um / training_um``. ``1.0`` for no rescaling.

    Returns
    -------
    np.ndarray
        2D ``final_shape`` float32 array.
    """
    source_shape = (
        round(final_shape[0] * pixel_size_scale),
        round(final_shape[1] * pixel_size_scale),
    )
    crop = center_crop_or_pad(img, source_shape).astype(np.float32)
    if source_shape != final_shape:
        crop = resize(
            crop,
            final_shape,
            order=1,
            anti_aliasing=True,
            preserve_range=True,
        ).astype(np.float32)
    return crop


def normalize_per_frame(crop: np.ndarray, ref: np.ndarray | None = None) -> np.ndarray:
    """Zero-mean unit-std normalization.

    Uses ``ref`` statistics if provided (matches per-frame
    ``timepoint_statistics`` normalization used at training time), else
    falls back to the crop's own mean/std.

    Parameters
    ----------
    crop : np.ndarray
        2D ``(H, W)`` float32 array.
    ref : np.ndarray, optional
        2D image to compute mean/std from. Defaults to ``crop``.

    Returns
    -------
    np.ndarray
        Normalized 2D array.
    """
    src = ref if ref is not None else crop
    mean = float(src.mean())
    std = float(src.std()) or 1.0
    return (crop - mean) / std


def embed(session: ort.InferenceSession, crop: np.ndarray) -> np.ndarray:
    """Run the ONNX model on a single ``(H, W)`` crop.

    Parameters
    ----------
    session : ort.InferenceSession
        Loaded ONNX runtime session.
    crop : np.ndarray
        Normalized 2D ``(H, W)`` float32 crop.

    Returns
    -------
    np.ndarray
        L2-normalized 1D embedding vector.
    """
    input_name = session.get_inputs()[0].name
    batch = crop[None, None, None, ...].astype(np.float32)  # (1, 1, 1, H, W)
    output = session.run(None, {input_name: batch})[0]  # (1, 768)
    emb = output[0]
    return emb / (np.linalg.norm(emb) or 1.0)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--onnx", type=Path, required=True, help="Path to the exported .onnx file.")
    parser.add_argument(
        "--image",
        type=Path,
        default=None,
        help="Optional 2D TIFF/PNG. If omitted, a synthetic random crop is embedded.",
    )
    parser.add_argument("--size", type=int, default=160, help="Model input side length (default 160).")
    parser.add_argument(
        "--image-pixel-size-um",
        type=float,
        default=None,
        help="Pixel size of the input image in micrometers.",
    )
    parser.add_argument(
        "--training-pixel-size-um",
        type=float,
        default=None,
        help="Pixel size used at training in micrometers (e.g. 0.149 for ALFI dragonfly).",
    )
    args = parser.parse_args()

    if (args.image_pixel_size_um is None) != (args.training_pixel_size_um is None):
        parser.error(
            "--image-pixel-size-um and --training-pixel-size-um must be set together "
            "(or both omitted to skip rescaling)."
        )

    if args.image is not None:
        img = load_image(args.image)
    else:
        rng = np.random.default_rng(0)
        img = rng.standard_normal((args.size, args.size)).astype(np.float32)

    if args.image_pixel_size_um is not None:
        pixel_size_scale = args.image_pixel_size_um / args.training_pixel_size_um
    else:
        pixel_size_scale = 1.0

    final_shape = (args.size, args.size)
    source_shape = (
        round(final_shape[0] * pixel_size_scale),
        round(final_shape[1] * pixel_size_scale),
    )
    print(
        f"Crop pipe : extract {source_shape} px -> resize to {final_shape} px "
        f"(scale={pixel_size_scale:.3f})"
    )

    crop = extract_and_resize(img, final_shape, pixel_size_scale)
    crop = normalize_per_frame(crop, ref=img)

    session = ort.InferenceSession(
        str(args.onnx),
        providers=["CUDAExecutionProvider", "CPUExecutionProvider"],
    )
    spec = session.get_inputs()[0]
    print(f"ONNX input: name={spec.name!r} shape={spec.shape} type={spec.type}")
    print(f"Providers : {session.get_providers()}")

    emb = embed(session, crop)
    print(f"Embedding : shape={emb.shape} dtype={emb.dtype} L2-norm={np.linalg.norm(emb):.4f}")
    print(f"First 8   : {emb[:8]}")


if __name__ == "__main__":
    main()
