"""Per-model embedding extraction for occlusion saliency.

Mirrors :mod:`dynaclr.visualization.pca_rgb_overlay` but returns
``(B, D)`` global cls / pooled embeddings instead of dense patch
features.  These embeddings are what the rest of DynaCLR's pipeline
consumes (PHATE, classifiers, retrieval), so occlusion against them
measures what the model's *production output* depends on.

Two output flavors:

- :func:`make_embed_fn` — returns the raw embedding.  Saliency = how
  much occlusion shifts the *representation*.
- :func:`make_classifier_fn` — chains a published linear-classifier
  pipeline (joblib) on top of the embedding and returns the predicted
  probability for one target class.  Saliency = how much occlusion
  changes the *prediction* for that class.  Use this when you want a
  task-grounded answer like "what region drives the infected vs
  uninfected call".
"""

from __future__ import annotations

from typing import Callable

import joblib
import numpy as np
import torch
import torch.nn as nn
from torch import Tensor

from viscy_models.foundation import CellDinoModel, DINOv3Model, OpenPhenomModel

_FOUNDATION_TYPES = (CellDinoModel, DINOv3Model, OpenPhenomModel)


def _unwrap_encoder(model: nn.Module) -> nn.Module:
    """Mirror the PCA-RGB overlay's dispatch and stop at the leaf encoder."""
    if isinstance(model, _FOUNDATION_TYPES):
        return model
    if hasattr(model, "stem") and hasattr(model, "encoder"):
        return model
    if hasattr(model, "encoder") and isinstance(model.encoder, nn.Module):
        return model.encoder
    if hasattr(model, "model") and isinstance(model.model, nn.Module):
        return model.model
    return model


def _embed_cell_dino(model: CellDinoModel, images: Tensor) -> Tensor:
    """``(B, 1024)`` cls token, mean-pooled across input channels.

    Matches :meth:`CellDinoModel.forward` exactly so the occlusion
    target equals the production embedding.
    """
    feats, _ = model(images)
    return feats


def _embed_dinov3(model: DINOv3Model, images: Tensor) -> Tensor:
    """``(B, D)`` cls / pooled output for DINOv3."""
    feats, _ = model(images)
    return feats


def _embed_openphenom(model: OpenPhenomModel, images: Tensor) -> Tensor:
    """OpenPhenom CA-MAE pooled output."""
    feats, _ = model(images)
    return feats


def _embed_dynaclr(encoder: nn.Module, images: Tensor) -> Tensor:
    """DynaCLR ContrastiveEncoder global embedding."""
    if not (hasattr(encoder, "stem") and hasattr(encoder, "encoder")):
        raise RuntimeError("expected ContrastiveEncoder with .stem and .encoder")
    if images.ndim == 4:
        images = images.unsqueeze(2)
    embedding, _projection = encoder(images)
    return embedding


def make_embed_fn(model: nn.Module) -> Callable[[Tensor], Tensor]:
    """Return a closure that maps ``(B, C, H, W)`` -> ``(B, D)`` for ``model``.

    The closure runs in ``torch.no_grad()`` and on whatever device the
    model is on.  Caller is responsible for matching the input
    distribution the wrapper expects (z-scored phase for foundation
    models, raw for DynaCLR's stem).
    """
    inner = _unwrap_encoder(model)
    if isinstance(inner, CellDinoModel):
        fn = lambda x: _embed_cell_dino(inner, x)  # noqa: E731
    elif isinstance(inner, DINOv3Model):
        fn = lambda x: _embed_dinov3(inner, x)  # noqa: E731
    elif isinstance(inner, OpenPhenomModel):
        fn = lambda x: _embed_openphenom(inner, x)  # noqa: E731
    elif hasattr(inner, "stem") and hasattr(inner, "encoder"):
        fn = lambda x: _embed_dynaclr(inner, x)  # noqa: E731
    else:
        raise TypeError(f"unsupported encoder for occlusion: {type(inner).__name__}")

    def _wrapped(x: Tensor) -> Tensor:
        with torch.no_grad():
            return fn(x)

    return _wrapped


def make_classifier_fn(
    model: nn.Module,
    classifier_path: str,
    target_class: str | None = None,
) -> Callable[[Tensor], Tensor]:
    """Return ``(B, C, H, W)`` -> ``(B, 1)`` predicted-probability closure.

    Chains the model's embedding into a published
    ``LinearClassifierPipeline`` (joblib) and returns the predicted
    probability for ``target_class``.  When ``target_class`` is
    ``None`` the full ``(B, n_classes)`` probability vector is
    returned, and saliency reports how much the *whole class
    distribution* moves.

    Parameters
    ----------
    model : nn.Module
        Encoder accepted by :func:`make_embed_fn`.
    classifier_path : str
        Path to a ``.joblib`` produced by
        ``viscy_utils.evaluation.linear_classifier`` (the format used
        by every infectomics ``linear_classifiers/pipelines/``
        directory).
    target_class : str or None
        Class label whose predicted probability is the saliency
        target.  Must match one of the strings in
        ``pipeline.classifier.classes_``.  ``None`` = use the full
        probability vector (saliency on the entire distribution).

    Returns
    -------
    Callable
        Closure that maps ``(B, C, H, W)`` to either ``(B, 1)``
        (single class) or ``(B, n_classes)`` (full distribution).
    """
    pipeline = joblib.load(classifier_path)
    embed_fn = make_embed_fn(model)

    classes = list(pipeline.classifier.classes_)
    target_idx: int | None = None
    if target_class is not None:
        if target_class not in classes:
            raise ValueError(
                f"target_class={target_class!r} not in classifier classes {classes} (loaded from {classifier_path})"
            )
        target_idx = classes.index(target_class)

    def _classifier_wrapped(x: Tensor) -> Tensor:
        emb = embed_fn(x)
        emb_np = emb.detach().cpu().float().numpy()
        proba = pipeline.predict_proba(emb_np)  # (B, n_classes)
        proba_t = torch.from_numpy(np.asarray(proba)).to(x.device, dtype=torch.float32)
        if target_idx is None:
            return proba_t
        return proba_t[:, target_idx : target_idx + 1]

    return _classifier_wrapped
