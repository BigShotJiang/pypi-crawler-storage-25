"""CLI: render a multi-task occlusion-saliency timelapse for one model.

Cells × tasks grid.  For one DynaCLR encoder we run occlusion against
every published linear classifier (e.g. infection_state, cell_division_state)
on the same phase patches and render side-by-side columns.

A thin probability bar sits above each saliency panel: it shows
``P(target_class)`` for that cell at that timepoint, and switches
colour at a threshold (default 0.5) so the viewer can see when the
classifier is "calling" the target class as the saliency map evolves.

Spec format::

    output_mp4: ...
    fps: 4
    patch_size: 160
    image_channel: Phase3D

    occlusion:
      occ_size: 16
      stride: 8
      ...

    track:
      cell_index_path: ...
      experiment: 2025_07_24_A549_Phase3D_ZIKV
      marker: Phase3D
      lineage_mode: path

    cells:
      - lineage_id: ...
        label: ...

    model:
      kind: dynaclr
      config_path: ...
      ckpt_path: ...

    tasks:
      - label: "P(infected)"
        classifier_path: .../infection_state_Phase3D.joblib
        target_class: infected
      - label: "P(mitosis)"
        classifier_path: .../cell_division_state_Phase3D.joblib
        target_class: mitosis
        threshold: 0.5    # optional, defaults to spec-level threshold
"""

from __future__ import annotations

import argparse
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
import torch
import yaml
from torch import Tensor

from dynaclr.visualization.compare_pca_rgb_cli import _BUILDERS
from dynaclr.visualization.occlusion_overlay import make_classifier_fn
from dynaclr.visualization.timelapse_pca_rgb_cli import (
    _load_cell_patches,
    _load_lineage_df,
    _select_path,
    _write_movie,
)
from viscy_utils.visualization.occlusion import occlusion_saliency, saliency_to_rgb


def _draw_prob_bar(
    ax,
    proba: float,
    *,
    extent: tuple[float, float, float, float],
    threshold: float = 0.5,
    bar_height_frac: float = 0.06,
    below_color: str = "magenta",
    above_color: str = "limegreen",
):
    """Draw a thin filled probability bar at the top of an axes.

    The bar fills from left (P=0) to right (P=1).  Colour switches at
    ``threshold``.  Bar lives inside ``extent[0:2]`` × top
    ``bar_height_frac`` slice of the axes.
    """
    import matplotlib.patches as patches

    x0, x1, y_top, _ = extent  # imshow uses (left, right, top, bottom) when origin is upper
    # Bar sits above the image — outside the imshow extent so it
    # doesn't obscure the saliency. We extend ylim to make room.
    width = x1 - x0
    bar_y_height = bar_height_frac * width
    color = above_color if proba >= threshold else below_color
    bar = patches.Rectangle(
        (x0, -bar_y_height),
        proba * width,
        bar_y_height * 0.85,
        linewidth=0,
        facecolor=color,
        zorder=10,
    )
    ax.add_patch(bar)
    # Outline of the full bar so the empty portion is visible
    outline = patches.Rectangle(
        (x0, -bar_y_height),
        width,
        bar_y_height * 0.85,
        linewidth=0.5,
        edgecolor="black",
        facecolor="none",
        zorder=11,
    )
    ax.add_patch(outline)
    # Probability text on the right side of the bar
    ax.text(
        x0 + width * 0.98,
        -bar_y_height * 0.4,
        f"{proba:.2f}",
        fontsize=7,
        ha="right",
        va="center",
        color="black",
        zorder=12,
    )


def _render_frame(
    cells: list[dict[str, Any]],
    task_labels: list[str],
    timepoint: int,
    *,
    overlay_alpha: float = 0.55,
    threshold: float = 0.5,
    image_cmap: str = "gray",
    dpi: int = 150,
):
    """Render one (cells × (1 + n_tasks)) frame with probability bars."""
    import matplotlib.pyplot as plt

    n_rows = len(cells)
    n_cols = 1 + len(task_labels)
    fig, axes = plt.subplots(n_rows, n_cols, figsize=(2.4 * n_cols, 2.6 * n_rows), dpi=dpi, squeeze=False)
    blank = np.full((1, 1, 3), 0.85, dtype=np.float32)

    for row, cell in enumerate(cells):
        # Phase column
        ax = axes[row, 0]
        if cell["image"] is not None:
            ax.imshow(cell["image"].detach().cpu().numpy(), cmap=image_cmap)
        else:
            ax.imshow(blank)
        ax.set_xticks([])
        ax.set_yticks([])
        ax.set_ylabel(cell["label"], fontsize=8)
        if row == 0:
            ax.set_title(f"phase  t={timepoint}", fontsize=9)

        # Task columns
        for col, task_label in enumerate(task_labels, start=1):
            ax = axes[row, col]
            entry = cell["tasks"].get(task_label)
            if entry is not None:
                rgb = entry["overlay"]
                rgb_np = rgb.detach().cpu().numpy().transpose(1, 2, 0)
                rgb_h, rgb_w, _ = rgb_np.shape
                rgb_extent = (0, rgb_w, rgb_h, 0)
                if overlay_alpha < 1.0 and cell["image"] is not None:
                    img_np = cell["image"].detach().cpu().numpy()
                    ax.imshow(img_np, cmap=image_cmap, extent=rgb_extent, aspect="equal")
                    ax.imshow(rgb_np, alpha=overlay_alpha, interpolation="nearest", extent=rgb_extent, aspect="equal")
                else:
                    ax.imshow(rgb_np, interpolation="nearest", extent=rgb_extent, aspect="equal")
                _draw_prob_bar(
                    ax,
                    proba=entry["proba"],
                    extent=rgb_extent,
                    threshold=entry.get("threshold", threshold),
                )
                # Make room for the bar above the image
                bar_height_frac = 0.06 * rgb_w
                ax.set_xlim(0, rgb_w)
                ax.set_ylim(rgb_h, -bar_height_frac * 1.4)
            else:
                ax.imshow(blank)
                ax.set_xlim(-1, 1)
                ax.set_ylim(-1, 1)
            ax.set_xticks([])
            ax.set_yticks([])
            # Per-frame title shows the prediction state — flips at the
            # spec threshold (default 0.5), not at exact 1.0 like the
            # legacy script. Predicted "true" iff prob ≥ threshold.
            if entry is not None:
                thr = entry.get("threshold", threshold)
                pred = "true" if entry["proba"] >= thr else "false"
                if row == 0:
                    ax.set_title(f"{task_label}\n{pred}  p={entry['proba']:.2f}", fontsize=8)
                else:
                    ax.set_title(f"{pred}  p={entry['proba']:.2f}", fontsize=8)
            elif row == 0:
                ax.set_title(task_label, fontsize=9)

    fig.tight_layout(pad=0.5)
    fig.canvas.draw()
    frame = np.asarray(fig.canvas.buffer_rgba())[..., :3].copy()
    plt.close(fig)
    return frame


def main(spec_path: str) -> None:
    """Read spec, run occlusion saliency for every (cell × task), write movie."""
    with open(spec_path) as f:
        spec = yaml.safe_load(f)

    patch_size = int(spec.get("patch_size", 160))
    image_channel = spec.get("image_channel", "Phase3D")
    threshold = float(spec.get("threshold", 0.5))

    occ_cfg = spec.get("occlusion", {})
    occ_size = int(occ_cfg.get("occ_size", 16))
    stride = int(occ_cfg.get("stride", 8))
    fill_value = occ_cfg.get("fill_value", 0.0)
    # Default to signed_delta + icefire for classifier saliency: zero
    # at the colormap centre, blue = occlusion drops the prediction,
    # red = occlusion raises it. Override in spec for L2 magnitude.
    distance = occ_cfg.get("distance", "signed_delta")
    cmap = occ_cfg.get("cmap", "icefire")
    # Fixed symmetric clip — required for cross-frame comparability.
    # Spec sets clip_value (e.g. 0.2 = ±20% probability) explicitly to
    # opt into legacy-style scaling; falls back to clip_percentile
    # otherwise (per-frame, less comparable across time).
    clip_value = occ_cfg.get("clip_value")
    clip_value = float(clip_value) if clip_value is not None else None
    clip_percentile = occ_cfg.get("clip_percentile", [2.0, 98.0])
    if clip_percentile is not None:
        clip_percentile = (float(clip_percentile[0]), float(clip_percentile[1]))
    overlay_alpha = float(occ_cfg.get("overlay_alpha", 0.55))
    occ_batch_size = int(occ_cfg.get("batch_size", 32))

    track_shared = spec.get("track", {})
    cells_spec = list(spec["cells"])
    parquet_path = track_shared.get("cell_index_path")
    if parquet_path is None:
        raise ValueError("track.cell_index_path is required")
    parquet = pd.read_parquet(parquet_path)

    # Per-cell loading (same as PCA / single-task occlusion CLIs)
    cells_data: list[dict[str, Any]] = []
    daughter_preference = track_shared.get("daughter_preference", "longer")
    for entry in cells_spec:
        lineage_df = _load_lineage_df(parquet, entry, track_shared)
        path_df = _select_path(lineage_df, daughter_preference)
        images, timepoints, _ = _load_cell_patches(path_df, image_channel, patch_size)
        label = entry.get("label") or entry.get("lineage_id") or f"track {entry.get('track_id')}"
        cells_data.append(
            {
                "label": str(label),
                "images": images,
                "timepoints": timepoints,
                "t_to_idx": {t: i for i, t in enumerate(timepoints)},
            }
        )
    if not cells_data:
        raise ValueError("no cells loaded")
    all_t = sorted({t for c in cells_data for t in c["timepoints"]})
    print(f"[multitask-occlusion] {len(cells_data)} cells, {len(all_t)} unique timepoints (t={all_t[0]}–{all_t[-1]})")

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    for c in cells_data:
        c["images"] = c["images"].to(device)

    # Build the single model
    model_spec = spec["model"]
    kind = model_spec["kind"]
    if kind not in _BUILDERS:
        raise ValueError(f"unknown model kind {kind!r}")
    model = _BUILDERS[kind](model_spec).to(device)

    # Build a classifier closure per task
    tasks = list(spec["tasks"])
    task_labels = [t["label"] for t in tasks]
    fns: dict[str, Any] = {}
    thresholds: dict[str, float] = {}
    for t in tasks:
        fns[t["label"]] = make_classifier_fn(
            model,
            t["classifier_path"],
            t.get("target_class"),
        )
        thr = float(t.get("threshold", threshold))
        thresholds[t["label"]] = thr
        target = t.get("target_class")
        print(f"[multitask-occlusion] {t['label']}: target={target!r}, threshold={thr}")

    # Compute saliency + per-frame probability for every (cell, t, task)
    saliency: dict[tuple[int, str], Tensor] = {}
    probas: dict[tuple[int, str], np.ndarray] = {}
    upsample_hw = (patch_size, patch_size)
    with torch.no_grad():
        for c_idx, c in enumerate(cells_data):
            imgs_4d = c["images"].squeeze(2)  # (T_cell, 1, H, W)
            for t in tasks:
                tlabel = t["label"]
                fn = fns[tlabel]
                # Baseline probability per frame
                proba_baseline = fn(imgs_4d).flatten().cpu().numpy()  # (T_cell,)
                probas[(c_idx, tlabel)] = proba_baseline
                # Saliency over occlusion grid
                sal = occlusion_saliency(
                    imgs_4d,
                    fn,
                    occ_size=occ_size,
                    stride=stride,
                    fill_value=fill_value,
                    batch_size=occ_batch_size,
                    distance=distance,
                )
                saliency[(c_idx, tlabel)] = sal
            print(f"[multitask-occlusion] cell {c_idx}: done ({len(tasks)} tasks)")

    # Render frames
    frames: list[np.ndarray] = []
    for t in all_t:
        cells_render: list[dict[str, Any]] = []
        for c_idx, c in enumerate(cells_data):
            idx = c["t_to_idx"].get(t)
            if idx is None:
                cells_render.append({"label": c["label"], "image": None, "tasks": {}})
                continue
            image = c["images"][idx, 0, 0]
            task_entries: dict[str, dict[str, Any]] = {}
            for task in tasks:
                tlabel = task["label"]
                sal = saliency[(c_idx, tlabel)][idx : idx + 1]
                rgb = saliency_to_rgb(
                    sal,
                    cmap=cmap,
                    clip_percentile=clip_percentile,
                    clip_value=clip_value,
                    upsample_to=upsample_hw,
                    interp_mode="nearest",
                )
                task_entries[tlabel] = {
                    "overlay": rgb[0],
                    "proba": float(probas[(c_idx, tlabel)][idx]),
                    "threshold": thresholds[tlabel],
                }
            cells_render.append({"label": c["label"], "image": image, "tasks": task_entries})
        frames.append(
            _render_frame(
                cells_render,
                task_labels,
                t,
                overlay_alpha=overlay_alpha,
                threshold=threshold,
            )
        )

    output_path = Path(spec["output_mp4"]).expanduser()
    output_path.parent.mkdir(parents=True, exist_ok=True)
    written = _write_movie(frames, str(output_path), fps=int(spec.get("fps", 4)))
    print(f"wrote {written} ({len(frames)} frames, {len(cells_data)} cells × {len(tasks)} tasks)")


def cli() -> None:
    """Argparse entry point."""
    parser = argparse.ArgumentParser(description="Render multi-task occlusion-saliency timelapse with P-bars.")
    parser.add_argument("--spec", required=True, help="Path to YAML spec.")
    args = parser.parse_args()
    main(args.spec)


if __name__ == "__main__":
    cli()
