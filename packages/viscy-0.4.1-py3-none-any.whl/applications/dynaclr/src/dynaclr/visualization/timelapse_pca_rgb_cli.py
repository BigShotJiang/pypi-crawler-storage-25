"""CLI: render a multi-cell timelapse PCA-RGB movie.

Reads cell coordinates from a flat ``cell_index`` parquet (the same one
that drives DynaCLR training), pulls phase patches centred on each
``(t, y, x)``, runs each encoder, and paints PCA-RGB overlays.

For each model, the PCA basis is fit *once* across patches from **all
cells × all timepoints** (``mode='reference'``).  This gives consistency
within a column (same model across cells and frames) without forcing
different models into the same color space (each model has its own
basis).

Lineage handling per cell:

- ``path`` (default) — follow one daughter at each division.  Picks the
  daughter with the most frames (configurable via ``daughter_preference``).

Time alignment across cells: pad to the union range so all rows share
one timeline.  Frames where a cell doesn't exist yet, or has died, are
rendered as a neutral gray.

Spec format::

    output_mp4: /path/to/movie.mp4
    fps: 4
    patch_size: 160
    upsample_to: 224
    image_channel: Phase3D
    mask_fg: true
    fg_threshold: 0.5
    clip_percentile: [2, 98]   # robust min/max for the RGB rescale

    track:                      # shared parquet / filters
      cell_index_path: /hpc/.../DynaCLR-2D-MIP-BagOfChannels-v3.parquet
      experiment: 2025_07_24_A549_Phase3D_ZIKV
      marker: Phase3D
      lineage_mode: path
      daughter_preference: longer

    cells:
      - lineage_id: 2025_07_24_A549_Phase3D_ZIKV_A/2/000001_100
        label: "A/2 cell 100"
      - lineage_id: 2025_07_24_A549_Phase3D_ZIKV_B/2/000000_43
        label: "B/2 lineage 43 (divides)"
      - lineage_id: 2025_07_24_A549_Phase3D_ZIKV_C/2/002001_76
        label: "C/2 lineage 76"

    models:
      - name: CELL-DINO
        kind: cell_dino
        weights_path: ...
"""

from __future__ import annotations

import argparse
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
import torch
import yaml
from iohub.ngff import open_ome_zarr
from torch import Tensor

from dynaclr.visualization.compare_pca_rgb_cli import (
    _BUILDERS,
    load_phase_patch,
)
from dynaclr.visualization.pca_rgb_overlay import extract_patches
from viscy_utils.visualization.pca_rgb import (
    fit_pca_components,
    pca_rgb_from_patches,
)


def _load_lineage_df(parquet: pd.DataFrame, cell_spec: dict[str, Any], shared: dict[str, Any]) -> pd.DataFrame:
    """Filter the parquet to one cell's lineage according to ``cell_spec``.

    ``shared`` carries fields common to all cells (``experiment``,
    ``marker``).  ``cell_spec`` overrides per-cell — ``lineage_id`` or
    ``track_id`` plus optional ``t_start`` / ``t_end``.
    """
    df = parquet
    experiment = cell_spec.get("experiment", shared.get("experiment"))
    if experiment is not None:
        df = df[df["experiment"] == experiment]
    marker = cell_spec.get("marker", shared.get("marker"))
    if marker is not None:
        df = df[df["marker"] == marker]

    lineage_id = cell_spec.get("lineage_id")
    track_id = cell_spec.get("track_id")
    if lineage_id is None and track_id is None:
        raise ValueError(f"cell entry must specify lineage_id or track_id (got {cell_spec!r})")

    if lineage_id is None:
        match = df[df["track_id"] == int(track_id)]
        if match.empty:
            raise ValueError(f"track_id={track_id} not found in {experiment}")
        lineage_id = match["lineage_id"].iloc[0]

    sub = df[df["lineage_id"] == lineage_id].copy()
    if sub.empty:
        raise ValueError(f"lineage_id={lineage_id!r} not found in {experiment}")

    t_start = cell_spec.get("t_start", shared.get("t_start"))
    t_end = cell_spec.get("t_end", shared.get("t_end"))
    if t_start is not None:
        sub = sub[sub["t"] >= int(t_start)]
    if t_end is not None:
        sub = sub[sub["t"] <= int(t_end)]
    if sub.empty:
        raise ValueError(f"no frames in [{t_start}, {t_end}] for {lineage_id}")

    return sub.sort_values(["track_id", "t"]).reset_index(drop=True)


def _select_path(lineage_df: pd.DataFrame, daughter_preference: str = "longer") -> pd.DataFrame:
    """Walk one daughter at each division → continuous (t, y, x) sequence."""
    children: dict[int, list[int]] = {}
    track_meta: dict[int, dict[str, Any]] = {}
    for tid, group in lineage_df.groupby("track_id"):
        track_meta[int(tid)] = {
            "n_frames": len(group),
            "t_min": int(group["t"].min()),
            "t_max": int(group["t"].max()),
        }
        parent = group["parent_track_id"].iloc[0]
        if pd.notna(parent):
            parent = int(parent)
            children.setdefault(parent, []).append(int(tid))

    all_tracks = set(lineage_df["track_id"].astype(int))
    roots = [
        int(tid)
        for tid in all_tracks
        if pd.isna(lineage_df[lineage_df["track_id"] == tid]["parent_track_id"].iloc[0])
        or int(lineage_df[lineage_df["track_id"] == tid]["parent_track_id"].iloc[0]) not in all_tracks
    ]
    if not roots:
        raise ValueError("could not find root track in lineage")
    root = roots[0]

    def pick(candidates: list[int]) -> int:
        if daughter_preference == "longer":
            return max(candidates, key=lambda t: track_meta[t]["n_frames"])
        if daughter_preference == "first":
            return min(candidates, key=lambda t: track_meta[t]["t_min"])
        if daughter_preference == "last":
            return max(candidates, key=lambda t: track_meta[t]["t_min"])
        raise ValueError(f"unknown daughter_preference {daughter_preference!r}")

    chosen: list[int] = []
    cur = root
    while True:
        chosen.append(cur)
        kids = children.get(cur, [])
        if not kids:
            break
        cur = pick(kids) if len(kids) > 1 else kids[0]

    return lineage_df[lineage_df["track_id"].isin(chosen)].sort_values("t").reset_index(drop=True)


def _resolve_center(row: pd.Series) -> tuple[int, int]:
    return int(round(row["y"])), int(round(row["x"]))


def _clamp_center(cy: int, cx: int, half: int, h: int, w: int) -> tuple[int, int]:
    return min(max(cy, half), h - half), min(max(cx, half), w - half)


def _fov_shape(store: str, well: str, fov: str) -> tuple[int, int]:
    fov_path = f"{store}/{well}/{fov}"
    with open_ome_zarr(fov_path, mode="r") as pos:
        arr = pos["0"]
        return int(arr.shape[-2]), int(arr.shape[-1])


def _load_cell_patches(
    path_df: pd.DataFrame,
    image_channel: str,
    patch_size: int,
) -> tuple[Tensor, list[int], list[int]]:
    """Return ``(T_cell, 1, 1, H, W)`` patches, list of timepoints, list of track_ids."""
    half = patch_size // 2
    fov_shape_cache: dict[tuple[str, str, str], tuple[int, int]] = {}
    patches: list[Tensor] = []
    timepoints: list[int] = []
    track_ids: list[int] = []
    for _, row in path_df.iterrows():
        store = row["store_path"]
        well = row["well"]
        fov = str(row["fov"])
        key = (store, well, fov)
        if key not in fov_shape_cache:
            fov_shape_cache[key] = _fov_shape(store, well, fov)
        h, w = fov_shape_cache[key]
        cy, cx = _clamp_center(*_resolve_center(row), half=half, h=h, w=w)
        if "z" in row and pd.notna(row["z"]):
            z_idx = int(row["z"])
        elif "z_focus_mean" in row and pd.notna(row["z_focus_mean"]):
            z_idx = int(round(row["z_focus_mean"]))
        else:
            z_idx = None
        norm_mean = float(row["norm_mean"]) if "norm_mean" in row and pd.notna(row["norm_mean"]) else None
        norm_std = float(row["norm_std"]) if "norm_std" in row and pd.notna(row["norm_std"]) else None
        patch = load_phase_patch(
            store=store,
            well=well,
            fov=fov,
            t=int(row["t"]),
            center_yx=(cy, cx),
            patch_size=patch_size,
            image_channel=image_channel,
            z=z_idx,
            norm_mean=norm_mean,
            norm_std=norm_std,
        )
        patches.append(patch)
        timepoints.append(int(row["t"]))
        track_ids.append(int(row["track_id"]))

    images = torch.cat(patches, dim=0).unsqueeze(2)
    return images, timepoints, track_ids


def _render_frame(
    cells: list[dict[str, Any]],
    n_models: int,
    model_names: list[str],
    timepoint: int,
    *,
    overlay_alpha: float = 1.0,
    image_cmap: str = "gray",
    dpi: int = 150,
):
    """Render one timelapse frame as ``(H, W, 3)`` uint8 numpy array.

    ``cells`` is a list of per-row dicts with keys ``label``, ``image``
    (``(H, W)`` Tensor or ``None``), ``overlays`` (``{name: (3, H, W)
    Tensor}`` or empty dict if the cell has no frame at this t).

    ``overlay_alpha`` < 1.0 composites each model's PCA-RGB grid over
    the grayscale phase image at that alpha — useful when the patch
    grid is coarse (e.g. 5×5 or 7×7) and you want cell morphology to
    remain visible underneath the colored squares.
    """
    import matplotlib.pyplot as plt

    n_rows = len(cells)
    n_cols = 1 + n_models
    fig, axes = plt.subplots(n_rows, n_cols, figsize=(2.4 * n_cols, 2.4 * n_rows), dpi=dpi, squeeze=False)
    blank = np.full((1, 1, 3), 0.85, dtype=np.float32)

    for row, cell in enumerate(cells):
        # Phase column
        ax = axes[row, 0]
        if cell["image"] is not None:
            ax.imshow(cell["image"].detach().cpu().numpy(), cmap=image_cmap)
        else:
            ax.imshow(blank)
        ax.set_xticks([])
        ax.set_yticks([])
        ax.set_ylabel(cell["label"], fontsize=8)
        if row == 0:
            ax.set_title(f"phase  t={timepoint}", fontsize=9)

        # Model columns. Both phase and RGB are forced into the same
        # (W, H) extent so matplotlib doesn't auto-fit them to different
        # boxes — that's what produced the cropped/misaligned look
        # before, since ``upsample_to`` and ``patch_size`` could differ.
        for col, name in enumerate(model_names, start=1):
            ax = axes[row, col]
            rgb = cell["overlays"].get(name)
            if rgb is not None:
                rgb_np = rgb.detach().cpu().numpy().transpose(1, 2, 0)
                rgb_h, rgb_w, _ = rgb_np.shape
                rgb_extent = (0, rgb_w, rgb_h, 0)
                if overlay_alpha < 1.0 and cell["image"] is not None:
                    img_np = cell["image"].detach().cpu().numpy()
                    img_h, img_w = img_np.shape
                    # Display phase using the RGB extent so the two
                    # images perfectly co-register regardless of pixel
                    # count.
                    ax.imshow(img_np, cmap=image_cmap, extent=rgb_extent, aspect="equal")
                    ax.imshow(rgb_np, alpha=overlay_alpha, interpolation="nearest", extent=rgb_extent, aspect="equal")
                    ax.set_xlim(0, rgb_w)
                    ax.set_ylim(rgb_h, 0)
                    del img_h, img_w
                else:
                    ax.imshow(rgb_np, interpolation="nearest", extent=rgb_extent, aspect="equal")
                    ax.set_xlim(0, rgb_w)
                    ax.set_ylim(rgb_h, 0)
            else:
                ax.imshow(blank)
            ax.set_xticks([])
            ax.set_yticks([])
            if row == 0:
                ax.set_title(name, fontsize=9)

    fig.tight_layout(pad=0.5)
    fig.canvas.draw()
    frame = np.asarray(fig.canvas.buffer_rgba())[..., :3].copy()
    plt.close(fig)
    return frame


def _write_movie(frames, output_path: str, fps: int) -> str:
    """Write frames as MP4 (preferred) or GIF if FFmpeg unavailable."""
    import imageio.v2 as iio

    arr = np.stack(frames, axis=0)
    if arr.shape[1] % 2:
        arr = arr[:, :-1]
    if arr.shape[2] % 2:
        arr = arr[:, :, :-1]

    out = Path(output_path)
    if out.suffix.lower() in {".mp4", ".mov", ".webm"}:
        try:
            with iio.get_writer(str(out), format="FFMPEG", fps=fps, codec="libx264", quality=8) as writer:
                for frame in arr:
                    writer.append_data(frame)
            return str(out)
        except (ImportError, ValueError) as e:
            fallback = out.with_suffix(".gif")
            print(f"[timelapse] FFmpeg unavailable ({e}); falling back to {fallback}")
            out = fallback

    duration_ms = int(round(1000 / max(fps, 1)))
    iio.mimsave(str(out), list(arr), duration=duration_ms, loop=0)
    return str(out)


def main(spec_path: str) -> None:
    """Read spec, build models, walk every cell, paint frames, write movie."""
    with open(spec_path) as f:
        spec = yaml.safe_load(f)

    patch_size = int(spec.get("patch_size", 160))
    image_channel = spec.get("image_channel", "Phase3D")
    upsample_to_value = int(spec.get("upsample_to", patch_size))
    upsample_hw = (upsample_to_value, upsample_to_value)
    mask_fg = bool(spec.get("mask_fg", True))
    fg_threshold = float(spec.get("fg_threshold", 0.5))
    clip_percentile = spec.get("clip_percentile")
    if clip_percentile is not None:
        clip_percentile = (float(clip_percentile[0]), float(clip_percentile[1]))
    interp_mode = spec.get("interp_mode", "nearest")
    overlay_alpha = float(spec.get("overlay_alpha", 1.0))

    track_shared = spec.get("track", {})
    if "cells" in spec:
        cells_spec = list(spec["cells"])
    else:
        # Back-compat single-cell shorthand: lift fields from `track` block.
        single = {k: v for k, v in track_shared.items() if k in {"lineage_id", "track_id", "t_start", "t_end"}}
        single.setdefault("label", single.get("lineage_id") or f"track {single.get('track_id')}")
        cells_spec = [single]

    parquet_path = track_shared.get("cell_index_path")
    if parquet_path is None:
        raise ValueError("track.cell_index_path is required")
    parquet = pd.read_parquet(parquet_path)

    # Per-cell loading
    cells_data: list[dict[str, Any]] = []
    daughter_preference = track_shared.get("daughter_preference", "longer")
    for entry in cells_spec:
        lineage_df = _load_lineage_df(parquet, entry, track_shared)
        path_df = _select_path(lineage_df, daughter_preference)
        images, timepoints, _ = _load_cell_patches(path_df, image_channel, patch_size)
        label = entry.get("label") or entry.get("lineage_id") or f"track {entry.get('track_id')}"
        cells_data.append(
            {
                "label": str(label),
                "images": images,  # (T_cell, 1, 1, H, W)
                "timepoints": timepoints,
                "t_to_idx": {t: i for i, t in enumerate(timepoints)},
            }
        )

    if not cells_data:
        raise ValueError("no cells loaded")

    # Union timeline
    all_t = sorted({t for c in cells_data for t in c["timepoints"]})
    print(f"[timelapse] {len(cells_data)} cells, {len(all_t)} unique timepoints (t={all_t[0]}–{all_t[-1]})")

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    for c in cells_data:
        c["images"] = c["images"].to(device)

    # Build models
    models: dict[str, torch.nn.Module] = {}
    mask_overrides: dict[str, tuple[bool, float]] = {}
    for entry in spec["models"]:
        kind = entry["kind"]
        if kind not in _BUILDERS:
            raise ValueError(f"unknown model kind {kind!r}; expected one of {list(_BUILDERS)}")
        models[entry["name"]] = _BUILDERS[kind](entry).to(device)
        mask_overrides[entry["name"]] = (
            bool(entry.get("mask_fg", mask_fg)),
            float(entry.get("fg_threshold", fg_threshold)),
        )
    model_names = list(models.keys())

    # Per-model patches: stack patches from every cell × every frame, fit one PCA basis per model.
    components_per_model: dict[str, tuple[Tensor, Tensor]] = {}
    patches_per_model_per_cell: dict[str, list[Tensor]] = {name: [] for name in model_names}
    with torch.no_grad():
        for c_idx, c in enumerate(cells_data):
            for name, model in models.items():
                p = extract_patches(model, c["images"])
                patches_per_model_per_cell[name].append(p)
        for name in model_names:
            stacked = torch.cat(patches_per_model_per_cell[name], dim=0)  # (sum T_cell, N, D)
            mean, comps = fit_pca_components(stacked.reshape(-1, stacked.shape[-1]), n_components=3)
            components_per_model[name] = (mean, comps)
            print(f"[timelapse] {name}: pooled {stacked.shape[0]} patch sets across {len(cells_data)} cells")

    # Frame loop — walk the union timeline
    frames: list[np.ndarray] = []
    with torch.no_grad():
        for t in all_t:
            cells_render: list[dict[str, Any]] = []
            for c_idx, c in enumerate(cells_data):
                idx = c["t_to_idx"].get(t)
                if idx is None:
                    cells_render.append({"label": c["label"], "image": None, "overlays": {}})
                    continue
                image = c["images"][idx, 0, 0]
                overlays: dict[str, Tensor] = {}
                for name, _ in models.items():
                    patches = patches_per_model_per_cell[name][c_idx]
                    mean, comps = components_per_model[name]
                    mask_fg_i, fg_threshold_i = mask_overrides[name]
                    overlay = pca_rgb_from_patches(
                        patches[idx : idx + 1],
                        mode="reference",
                        mean=mean,
                        components=comps,
                        mask_fg=mask_fg_i,
                        fg_threshold=fg_threshold_i,
                        upsample_to=upsample_hw,
                        clip_percentile=clip_percentile,
                        interp_mode=interp_mode,
                    )
                    overlays[name] = overlay[0]
                cells_render.append({"label": c["label"], "image": image, "overlays": overlays})
            frames.append(_render_frame(cells_render, len(models), model_names, t, overlay_alpha=overlay_alpha))

    output_path = Path(spec["output_mp4"]).expanduser()
    output_path.parent.mkdir(parents=True, exist_ok=True)
    written = _write_movie(frames, str(output_path), fps=int(spec.get("fps", 4)))
    print(f"wrote {written} ({len(frames)} frames, {len(cells_data)} cells)")


def cli() -> None:
    """Argparse entry point for ``python -m dynaclr.visualization.timelapse_pca_rgb_cli``."""
    parser = argparse.ArgumentParser(description="Render a multi-cell timelapse PCA-RGB movie.")
    parser.add_argument("--spec", required=True, help="Path to YAML spec.")
    args = parser.parse_args()
    main(args.spec)


if __name__ == "__main__":
    cli()
