"""Per-model patch extraction and PCA-RGB overlay glue.

The pure tensor math lives in
:mod:`viscy_utils.visualization.pca_rgb`; this module is the
*model-aware* layer that knows how to ask each backbone for its dense
patch features and feeds them into ``pca_rgb_from_patches``.

Supported encoders:

- :class:`viscy_models.foundation.CellDinoModel` — channel-adaptive
  ViT-L/16 (CELL-DINO).  Patches are extracted per channel and
  mean-pooled across channels, matching the wrapper's cls-pooling
  convention.
- :class:`viscy_models.foundation.DINOv3Model` — HuggingFace ViT.
- :class:`viscy_models.foundation.OpenPhenomModel` — Recursion's MAE.
- :class:`viscy_models.contrastive.encoder.ContrastiveEncoder` (and
  any wrapper exposing it as ``self.encoder``) — DynaCLR ConvNeXt /
  ResNet.  Uses timm ``forward_features`` on the post-stem feature map.
"""

from __future__ import annotations

from typing import Iterable

import torch
import torch.nn as nn
from torch import Tensor

from viscy_models.foundation import CellDinoModel, DINOv3Model, OpenPhenomModel
from viscy_utils.visualization.pca_rgb import pca_rgb_from_patches

_FOUNDATION_TYPES = (CellDinoModel, DINOv3Model, OpenPhenomModel)


def _unwrap_encoder(model: nn.Module) -> nn.Module:
    """Return the underlying encoder if ``model`` is a Lightning wrapper.

    Stops at the first foundation-model wrapper or
    ``ContrastiveEncoder``-shaped module — those *are* the leaf encoders
    we dispatch on.  Lightning wrappers (``ContrastiveModule``,
    ``FoundationModule``) get unwrapped one level via ``self.encoder``
    or ``self.model``.
    """
    if isinstance(model, _FOUNDATION_TYPES):
        return model
    if hasattr(model, "stem") and hasattr(model, "encoder"):
        return model
    if hasattr(model, "encoder") and isinstance(model.encoder, nn.Module):
        return model.encoder
    if hasattr(model, "model") and isinstance(model.model, nn.Module):
        return model.model
    return model


def _patches_cell_dino(model: CellDinoModel, images: Tensor) -> Tensor:
    """``(B, N, D)`` patch tokens, mean-pooled across input channels."""
    x = model.preprocess_2d(images)
    b, c, h, w = x.shape
    out = model.model.forward_features(x.reshape(b * c, 1, h, w))
    patches = out["x_norm_patchtokens"]
    bc, n, d = patches.shape
    return patches.view(b, c, n, d).mean(dim=1)


def _patches_dinov3(model: DINOv3Model, images: Tensor) -> Tensor:
    """Drop cls token from HuggingFace last hidden state."""
    x = model.preprocess_2d(images)
    out = model.model(pixel_values=x, output_hidden_states=False)
    hidden = out.last_hidden_state
    if hidden.ndim == 3:
        return hidden[:, 1:]
    if hidden.ndim == 4:
        b, d, h, w = hidden.shape
        return hidden.permute(0, 2, 3, 1).reshape(b, h * w, d)
    raise RuntimeError(f"unexpected DINOv3 hidden shape {tuple(hidden.shape)}")


def _patches_openphenom(model: OpenPhenomModel, images: Tensor) -> Tensor:
    """OpenPhenom CA-MAE — pull dense tokens from the encoder.

    Note: OpenPhenom expects uint8 ``[0, 255]`` input, so its
    ``preprocess_2d`` always runs min-max regardless of the upstream
    normalization state.
    """
    x = model.preprocess_2d(images)
    inner = model.model
    if hasattr(inner, "forward_features"):
        feats = inner.forward_features(x)
    elif hasattr(inner, "encoder"):
        feats = inner.encoder(x)
    else:
        raise RuntimeError("OpenPhenom model exposes neither forward_features nor encoder")
    if feats.ndim == 3:
        if feats.shape[1] > 1:
            return feats[:, 1:]
        return feats
    if feats.ndim == 4:
        b, d, h, w = feats.shape
        return feats.permute(0, 2, 3, 1).reshape(b, h * w, d)
    raise RuntimeError(f"unexpected OpenPhenom feature shape {tuple(feats.shape)}")


def _patches_dynaclr(encoder: nn.Module, images: Tensor) -> Tensor:
    """DynaCLR ContrastiveEncoder — flatten timm forward_features map.

    DynaCLR was trained with ``NormalizeSampled`` per-FOV stats; pass
    pre-normalized input straight to the stem.
    """
    if not (hasattr(encoder, "stem") and hasattr(encoder, "encoder")):
        raise RuntimeError("expected ContrastiveEncoder with .stem and .encoder")
    if images.ndim == 4:
        images = images.unsqueeze(2)
    x = encoder.stem(images)
    feat_map = encoder.encoder.forward_features(x)
    if feat_map.ndim != 4:
        raise RuntimeError(f"expected (B, D, H, W) from forward_features, got {tuple(feat_map.shape)}")
    b, d, h, w = feat_map.shape
    return feat_map.permute(0, 2, 3, 1).reshape(b, h * w, d)


def extract_patches(model: nn.Module, images: Tensor) -> Tensor:
    """Return ``(B, N, D)`` dense patch features from any supported encoder.

    The caller is expected to have applied dataset-aware normalization
    (e.g. per-FOV ``NormalizeSampled`` stats from the cell_index
    parquet) — model wrappers default to ``preprocess_2d(normalize=False)``.

    Parameters
    ----------
    model : nn.Module
        A foundation-model wrapper (``CellDinoModel``, ``DINOv3Model``,
        ``OpenPhenomModel``), a DynaCLR ``ContrastiveEncoder``, or any
        Lightning wrapper exposing one of those as ``self.encoder`` /
        ``self.model``.
    images : Tensor
        ``(B, C, D, H, W)`` or ``(B, C, H, W)``.  Foundation-model
        wrappers do their own ``preprocess_2d``; the DynaCLR path
        feeds 5D input into the stem.

    Returns
    -------
    Tensor
        ``(B, N, D)`` patch features.
    """
    inner = _unwrap_encoder(model)
    if isinstance(inner, CellDinoModel):
        return _patches_cell_dino(inner, images)
    if isinstance(inner, DINOv3Model):
        return _patches_dinov3(inner, images)
    if isinstance(inner, OpenPhenomModel):
        return _patches_openphenom(inner, images)
    if hasattr(inner, "stem") and hasattr(inner, "encoder"):
        return _patches_dynaclr(inner, images)
    raise TypeError(f"unsupported encoder for PCA-RGB: {type(inner).__name__}")


@torch.no_grad()
def pca_rgb_overlay(
    model: nn.Module,
    images: Tensor,
    *,
    mode: str = "batch",
    mask_fg: bool = True,
    fg_threshold: float = 0.5,
    upsample_to: tuple[int, int] | None = None,
) -> Tensor:
    """Run a model and paint a PCA-RGB overlay for each image.

    Convenience wrapper around :func:`extract_patches` +
    :func:`viscy_utils.visualization.pca_rgb_from_patches`.

    Parameters
    ----------
    model : nn.Module
        Encoder or Lightning wrapper accepted by :func:`extract_patches`.
    images : Tensor
        ``(B, C, D, H, W)`` or ``(B, C, H, W)``.
    mode : str
        PCA fitting mode — ``'per_image'``, ``'batch'``, or ``'reference'``.
    mask_fg : bool
        Apply PC1-median foreground mask.
    fg_threshold : float
        Threshold on normalized PC1 (default 0.5 = median).
    upsample_to : tuple[int, int] or None
        If given, bilinearly upsample the RGB grid to ``(H, W)``.

    Returns
    -------
    Tensor
        ``(B, 3, H, W)`` RGB tensor in ``[0, 1]``.
    """
    patches = extract_patches(model, images)
    return pca_rgb_from_patches(
        patches,
        mode=mode,
        mask_fg=mask_fg,
        fg_threshold=fg_threshold,
        upsample_to=upsample_to,
    )


@torch.no_grad()
def pca_rgb_compare(
    models: dict[str, nn.Module],
    images: Tensor,
    *,
    mode: str = "batch",
    mask_fg: bool = True,
    fg_threshold: float = 0.5,
    upsample_to: tuple[int, int] | None = None,
) -> dict[str, Tensor]:
    """Compute PCA-RGB overlays for the same images across multiple models.

    Parameters
    ----------
    models : dict[str, nn.Module]
        Name → encoder.  All models see the same input batch; each fits
        its own PCA basis (so colors are not comparable across models —
        each model's color space is its own).

    Returns
    -------
    dict[str, Tensor]
        Name → ``(B, 3, H, W)`` overlay.
    """
    return {
        name: pca_rgb_overlay(
            m,
            images,
            mode=mode,
            mask_fg=mask_fg,
            fg_threshold=fg_threshold,
            upsample_to=upsample_to,
        )
        for name, m in models.items()
    }


def render_comparison_grid(
    images: Tensor,
    overlays: dict[str, Tensor],
    *,
    output_path: str,
    image_titles: Iterable[str] | None = None,
    image_cmap: str = "gray",
) -> None:
    """Save a multi-panel comparison figure (image + per-model overlays).

    Parameters
    ----------
    images : Tensor
        ``(B, H, W)`` or ``(B, 1, H, W)`` grayscale phase images displayed
        in the first column.
    overlays : dict[str, Tensor]
        Name → ``(B, 3, H, W)`` RGB tensors from :func:`pca_rgb_compare`.
    output_path : str
        Path to write PDF / PNG (extension drives the format).
    image_titles : Iterable[str] or None
        Per-row titles (cell IDs, conditions, timepoints).
    image_cmap : str
        Matplotlib colormap for the phase column.
    """
    import matplotlib.pyplot as plt

    if images.ndim == 4:
        images = images[:, 0]
    b = images.shape[0]
    n_models = len(overlays)
    titles = list(image_titles) if image_titles is not None else [f"cell {i}" for i in range(b)]
    fig, axes = plt.subplots(b, n_models + 1, figsize=(2.4 * (n_models + 1), 2.4 * b), squeeze=False)
    img_np = images.detach().cpu().numpy()
    overlays_np = {k: v.detach().cpu().numpy() for k, v in overlays.items()}
    for row in range(b):
        axes[row, 0].imshow(img_np[row], cmap=image_cmap)
        axes[row, 0].set_ylabel(titles[row], fontsize=8)
        axes[row, 0].set_xticks([])
        axes[row, 0].set_yticks([])
        if row == 0:
            axes[row, 0].set_title("phase", fontsize=9)
        for col, (name, rgb) in enumerate(overlays_np.items(), start=1):
            axes[row, col].imshow(rgb[row].transpose(1, 2, 0))
            axes[row, col].set_xticks([])
            axes[row, col].set_yticks([])
            if row == 0:
                axes[row, col].set_title(name, fontsize=9)
    fig.tight_layout()
    fig.savefig(output_path, dpi=200, bbox_inches="tight")
    plt.close(fig)
