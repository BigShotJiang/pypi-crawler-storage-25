"""DynaCLR visualization (model-aware glue around viscy_utils.visualization)."""

from dynaclr.visualization.occlusion_overlay import make_embed_fn
from dynaclr.visualization.pca_rgb_overlay import (
    extract_patches,
    pca_rgb_compare,
    pca_rgb_overlay,
)

__all__ = [
    "extract_patches",
    "make_embed_fn",
    "pca_rgb_overlay",
    "pca_rgb_compare",
]
