"""CLI: render multi-stage PCA-RGB feature maps for one cell.

Ports the legacy ``viscy/scripts/visualize_features.py`` recipe to the
DynaCLR ConvNeXt encoder.  For one (or several) phase patches we
extract the feature map at every ConvNeXt stage and render its top-3
PCA components as RGB, side-by-side.  Produces a static PNG/PDF — not
a movie.

Why this is useful even though we already have the PCA-RGB timelapse:
the timelapse uses the *final* stage (5×5 for DynaCLR ConvNeXt at
160 px input).  Stage 0 has 64× more patches (40×40), so feature maps
look dramatically smoother — but the features there are more
primitive (texture / gradient).  Comparing across stages tells you
where in the network the cell-state representation lives.

Stage geometry for DynaCLR ConvNeXt-tiny @ 160 px input:
- Stage 0 → 40×40 feature map, 96 channels
- Stage 1 → 20×20, 192 channels
- Stage 2 → 10×10, 384 channels
- Stage 3 → 5×5,   768 channels  (this is what the global cls vector pools)

Spec format::

    output_path: /path/to/figure.png
    patch_size: 160
    image_channel: Phase3D

    track:
      cell_index_path: ...
      experiment: ...
      marker: Phase3D

    cells:
      - lineage_id: ...
        t: 30           # single timepoint per cell
        label: "..."

    model:
      kind: dynaclr
      config_path: ...
      ckpt_path: ...

    n_components: 8     # for explained-variance plot; first 3 are RGB
"""

from __future__ import annotations

import argparse
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
import torch
import yaml

from dynaclr.visualization.compare_pca_rgb_cli import _BUILDERS
from dynaclr.visualization.timelapse_pca_rgb_cli import (
    _load_cell_patches,
    _load_lineage_df,
    _select_path,
)


def _stagewise_feature_maps(encoder: torch.nn.Module, images: torch.Tensor) -> list[torch.Tensor]:
    """Run a DynaCLR ContrastiveEncoder and return the per-stage ``(B, C, H, W)`` maps.

    Reproduces the legacy script's iteration over ``encoder.stages``.
    Input must be (B, C, Z, Y, X) for the stem.
    """
    if not (hasattr(encoder, "stem") and hasattr(encoder, "encoder")):
        raise RuntimeError("expected ContrastiveEncoder with .stem and .encoder")
    if images.ndim == 4:
        images = images.unsqueeze(2)
    backbone = encoder.encoder  # timm ConvNeXt
    if not hasattr(backbone, "stages"):
        raise RuntimeError(f"encoder.encoder lacks .stages (got {type(backbone).__name__})")
    x = encoder.stem(images)
    if hasattr(backbone, "stem"):
        # convnext_tiny.stem may have layers we should skip if encoder.stem
        # already replaced it. The DynaCLR ContrastiveEncoder sets
        # encoder.stem[0] = Identity, so we only need to apply the LayerNorm
        # remainder of timm's stem (if any).
        if isinstance(backbone.stem, torch.nn.Sequential) and len(backbone.stem) > 1:
            x = backbone.stem[1:](x)
    feats: list[torch.Tensor] = []
    for s in backbone.stages:
        x = s(x)
        feats.append(x)
    return feats


def _feature_map_pca_rgb(feat: np.ndarray, n_components: int = 8):
    """Mirror the legacy script: PCA over channels, top 3 components → RGB.

    Returns ``(rgb (H, W, 3), explained_variance_ratio (n_components,))``.
    """
    from skimage.exposure import rescale_intensity
    from sklearn.decomposition import PCA

    c, h, w = feat.shape
    flat = feat.reshape(c, -1)  # (C, H*W)
    pca = PCA(n_components=min(n_components, c, flat.shape[1]))
    pca.fit(flat)
    pc = pca.components_[:3].reshape(3, h, w)
    rgb = np.stack([rescale_intensity(p) for p in pc], axis=-1)
    return rgb, pca.explained_variance_ratio_


def main(spec_path: str) -> None:
    """Read spec, run one cell × multi-stage PCA, write static figure."""
    import matplotlib.pyplot as plt
    from matplotlib.patches import Rectangle

    with open(spec_path) as f:
        spec = yaml.safe_load(f)

    patch_size = int(spec.get("patch_size", 160))
    image_channel = spec.get("image_channel", "Phase3D")
    n_components = int(spec.get("n_components", 8))

    track_shared = spec.get("track", {})
    parquet_path = track_shared.get("cell_index_path")
    if parquet_path is None:
        raise ValueError("track.cell_index_path is required")
    parquet = pd.read_parquet(parquet_path)

    cells_spec = list(spec["cells"])
    cell_payloads: list[dict[str, Any]] = []
    for entry in cells_spec:
        lineage_df = _load_lineage_df(parquet, entry, track_shared)
        path_df = _select_path(lineage_df, track_shared.get("daughter_preference", "longer"))
        # Optional `t` selects a single frame; otherwise we use the middle frame.
        t_target = entry.get("t")
        if t_target is not None:
            picked = path_df[path_df["t"] == int(t_target)]
            if picked.empty:
                raise ValueError(f"t={t_target} not in lineage {entry.get('lineage_id')!r}")
            path_df = picked
        else:
            mid = len(path_df) // 2
            path_df = path_df.iloc[[mid]]
        images, _, _ = _load_cell_patches(path_df, image_channel, patch_size)
        label = entry.get("label") or entry.get("lineage_id") or f"cell {len(cell_payloads)}"
        cell_payloads.append({"label": str(label), "image": images, "row": path_df.iloc[0]})

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    # Build the model and unwrap to the ContrastiveEncoder.  The
    # Lightning ``ContrastiveModule`` exposes the encoder under ``.model``
    # (see ``dynaclr.engine``); ``.encoder`` is not a top-level attr.
    model_spec = spec["model"]
    kind = model_spec["kind"]
    if kind != "dynaclr":
        raise NotImplementedError("multi-stage PCA only implemented for DynaCLR ConvNeXt encoders")
    module = _BUILDERS[kind](model_spec).to(device)
    if hasattr(module, "model") and hasattr(module.model, "stem"):
        encoder = module.model
    elif hasattr(module, "encoder") and hasattr(module.encoder, "stem"):
        encoder = module.encoder
    elif hasattr(module, "stem"):
        encoder = module
    else:
        raise RuntimeError(f"could not locate ContrastiveEncoder inside {type(module).__name__}")

    # Compute per-stage feature maps for every cell
    n_cells = len(cell_payloads)
    feats_per_cell: list[list[np.ndarray]] = []
    with torch.no_grad():
        for c in cell_payloads:
            imgs = c["image"].to(device)  # (1, 1, 1, H, W)
            stages = _stagewise_feature_maps(encoder, imgs)
            feats_per_cell.append([s.detach().cpu().numpy()[0] for s in stages])

    n_stages = len(feats_per_cell[0])
    print(f"[feature-pca] {n_cells} cells × {n_stages} stages, shapes={[f.shape for f in feats_per_cell[0]]}")

    # Render: rows = cells, cols = phase + n_stages (RGB) + 1 (variance plot)
    fig, axes = plt.subplots(
        n_cells,
        n_stages + 2,
        figsize=(2.6 * (n_stages + 2), 2.6 * n_cells),
        squeeze=False,
        dpi=spec.get("dpi", 150),
    )
    for row, c in enumerate(cell_payloads):
        img = c["image"][0, 0, 0].cpu().numpy()
        axes[row, 0].imshow(img, cmap="gray")
        axes[row, 0].set_xticks([])
        axes[row, 0].set_yticks([])
        axes[row, 0].set_ylabel(c["label"], fontsize=9)
        if row == 0:
            axes[row, 0].set_title("phase", fontsize=10)

        evs = []
        for s_idx, feat in enumerate(feats_per_cell[row]):
            rgb, ev = _feature_map_pca_rgb(feat, n_components=n_components)
            evs.append(ev)
            axes[row, s_idx + 1].imshow(rgb, interpolation="nearest")
            axes[row, s_idx + 1].set_xticks([])
            axes[row, s_idx + 1].set_yticks([])
            if row == 0:
                axes[row, s_idx + 1].set_title(f"stage {s_idx + 1}\n{feat.shape[1]}×{feat.shape[2]}", fontsize=10)

        ax_var = axes[row, n_stages + 1]
        for s_idx, ev in enumerate(evs):
            ax_var.plot(range(1, len(ev) + 1), ev, label=f"stage {s_idx + 1}")
        ax_var.set_xlabel("PC")
        ax_var.set_ylabel("variance ratio")
        if row == 0:
            ax_var.set_title("explained var", fontsize=10)
        ax_var.legend(fontsize=6)

    legend_table = {"PC1": (1, 0, 0), "PC2": (0, 1, 0), "PC3": (0, 0, 1)}
    handles = [Rectangle((0, 0), 1, 1, color=v) for v in legend_table.values()]
    fig.legend(
        handles,
        legend_table.keys(),
        title="RGB channel",
        bbox_to_anchor=(1.0, 0.5),
        loc="center left",
        fontsize=8,
    )

    fig.tight_layout()
    output_path = Path(spec["output_path"]).expanduser()
    output_path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(str(output_path), dpi=spec.get("dpi", 150), bbox_inches="tight")
    plt.close(fig)
    print(f"wrote {output_path}")


def cli() -> None:
    """Argparse entry point."""
    parser = argparse.ArgumentParser(description="Render multi-stage PCA-RGB feature maps for one or more cells.")
    parser.add_argument("--spec", required=True, help="Path to YAML spec.")
    args = parser.parse_args()
    main(args.spec)


if __name__ == "__main__":
    cli()
