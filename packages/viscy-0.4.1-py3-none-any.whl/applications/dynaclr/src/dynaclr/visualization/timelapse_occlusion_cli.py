"""CLI: render a multi-cell timelapse occlusion-saliency movie.

For each (cell, timepoint) we slide a fill patch across the phase
image, measure how much each model's global embedding shifts, and
paint the resulting saliency map as a colormap overlay on the phase
image.

Unlike PCA-RGB, occlusion saliency's spatial resolution is set by the
sweep stride — not the encoder's patch grid.  At ``occ_size=16,
stride=8`` on a 160×160 phase patch we get a 19×19 saliency map for
*every* model, including DynaCLR's ConvNeXt (which only has a 5×5
native patch grid).

Cost: one forward pass per occlusion position per cell × timepoint.
At ``stride=8`` that's ~400 forwards per (cell, t) per model.

Spec format::

    output_mp4: /path/to/movie.mp4
    fps: 4
    patch_size: 160
    image_channel: Phase3D

    occlusion:
      occ_size: 16
      stride: 8
      fill_value: 0.0       # z-scored input → 0 = FOV mean
      distance: l2          # l2 | cosine
      cmap: magma
      clip_percentile: [2, 98]
      overlay_alpha: 0.55

    track:
      cell_index_path: ...
      experiment: 2025_07_24_A549_Phase3D_ZIKV
      marker: Phase3D
      lineage_mode: path

    cells:
      - lineage_id: 2025_07_24_A549_Phase3D_ZIKV_A/2/000001_100
        label: "A/2 cell 100"

    models:
      - name: CELL-DINO
        kind: cell_dino
        weights_path: ...
"""

from __future__ import annotations

import argparse
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
import torch
import yaml
from torch import Tensor

from dynaclr.visualization.compare_pca_rgb_cli import _BUILDERS
from dynaclr.visualization.occlusion_overlay import make_classifier_fn, make_embed_fn
from dynaclr.visualization.timelapse_pca_rgb_cli import (
    _load_cell_patches,
    _load_lineage_df,
    _select_path,
    _write_movie,
)
from viscy_utils.visualization.occlusion import (
    occlusion_saliency,
    saliency_to_rgb,
)


def _render_frame(
    cells: list[dict[str, Any]],
    n_models: int,
    model_names: list[str],
    timepoint: int,
    *,
    overlay_alpha: float = 0.55,
    image_cmap: str = "gray",
    dpi: int = 150,
):
    """Render one (cells × (1 + n_models)) frame as ``(H, W, 3)`` uint8."""
    import matplotlib.pyplot as plt

    n_rows = len(cells)
    n_cols = 1 + n_models
    fig, axes = plt.subplots(n_rows, n_cols, figsize=(2.4 * n_cols, 2.4 * n_rows), dpi=dpi, squeeze=False)
    blank = np.full((1, 1, 3), 0.85, dtype=np.float32)

    for row, cell in enumerate(cells):
        ax = axes[row, 0]
        if cell["image"] is not None:
            ax.imshow(cell["image"].detach().cpu().numpy(), cmap=image_cmap)
        else:
            ax.imshow(blank)
        ax.set_xticks([])
        ax.set_yticks([])
        ax.set_ylabel(cell["label"], fontsize=8)
        if row == 0:
            ax.set_title(f"phase  t={timepoint}", fontsize=9)

        for col, name in enumerate(model_names, start=1):
            ax = axes[row, col]
            rgb = cell["overlays"].get(name)
            if rgb is not None:
                rgb_np = rgb.detach().cpu().numpy().transpose(1, 2, 0)
                rgb_h, rgb_w, _ = rgb_np.shape
                rgb_extent = (0, rgb_w, rgb_h, 0)
                if overlay_alpha < 1.0 and cell["image"] is not None:
                    img_np = cell["image"].detach().cpu().numpy()
                    ax.imshow(img_np, cmap=image_cmap, extent=rgb_extent, aspect="equal")
                    ax.imshow(rgb_np, alpha=overlay_alpha, interpolation="nearest", extent=rgb_extent, aspect="equal")
                else:
                    ax.imshow(rgb_np, interpolation="nearest", extent=rgb_extent, aspect="equal")
                ax.set_xlim(0, rgb_w)
                ax.set_ylim(rgb_h, 0)
            else:
                ax.imshow(blank)
            ax.set_xticks([])
            ax.set_yticks([])
            if row == 0:
                ax.set_title(name, fontsize=9)

    fig.tight_layout(pad=0.5)
    fig.canvas.draw()
    frame = np.asarray(fig.canvas.buffer_rgba())[..., :3].copy()
    plt.close(fig)
    return frame


def main(spec_path: str) -> None:
    """Read spec, run occlusion saliency, write movie."""
    with open(spec_path) as f:
        spec = yaml.safe_load(f)

    patch_size = int(spec.get("patch_size", 160))
    image_channel = spec.get("image_channel", "Phase3D")

    occ_cfg = spec.get("occlusion", {})
    occ_size = int(occ_cfg.get("occ_size", 16))
    stride = int(occ_cfg.get("stride", 8))
    fill_value = occ_cfg.get("fill_value", 0.0)
    distance = occ_cfg.get("distance", "l2")
    cmap = occ_cfg.get("cmap", "magma")
    clip_percentile = occ_cfg.get("clip_percentile", [2.0, 98.0])
    if clip_percentile is not None:
        clip_percentile = (float(clip_percentile[0]), float(clip_percentile[1]))
    overlay_alpha = float(occ_cfg.get("overlay_alpha", 0.55))
    occ_batch_size = int(occ_cfg.get("batch_size", 32))

    track_shared = spec.get("track", {})
    if "cells" in spec:
        cells_spec = list(spec["cells"])
    else:
        single = {k: v for k, v in track_shared.items() if k in {"lineage_id", "track_id", "t_start", "t_end"}}
        single.setdefault("label", single.get("lineage_id") or f"track {single.get('track_id')}")
        cells_spec = [single]

    parquet_path = track_shared.get("cell_index_path")
    if parquet_path is None:
        raise ValueError("track.cell_index_path is required")
    parquet = pd.read_parquet(parquet_path)

    cells_data: list[dict[str, Any]] = []
    daughter_preference = track_shared.get("daughter_preference", "longer")
    for entry in cells_spec:
        lineage_df = _load_lineage_df(parquet, entry, track_shared)
        path_df = _select_path(lineage_df, daughter_preference)
        images, timepoints, _ = _load_cell_patches(path_df, image_channel, patch_size)
        label = entry.get("label") or entry.get("lineage_id") or f"track {entry.get('track_id')}"
        cells_data.append(
            {
                "label": str(label),
                "images": images,
                "timepoints": timepoints,
                "t_to_idx": {t: i for i, t in enumerate(timepoints)},
            }
        )

    if not cells_data:
        raise ValueError("no cells loaded")
    all_t = sorted({t for c in cells_data for t in c["timepoints"]})
    print(f"[occlusion] {len(cells_data)} cells, {len(all_t)} unique timepoints (t={all_t[0]}–{all_t[-1]})")

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    for c in cells_data:
        c["images"] = c["images"].to(device)

    # Build models. Each model entry can declare:
    #   classifier_path: <joblib>   target_class: <label>
    # to switch its saliency target from the embedding to the predicted
    # probability of one class. When neither is set, saliency is on the
    # raw embedding.
    models: dict[str, torch.nn.Module] = {}
    embed_fns: dict[str, Any] = {}
    saliency_targets: dict[str, str] = {}
    for entry in spec["models"]:
        kind = entry["kind"]
        if kind not in _BUILDERS:
            raise ValueError(f"unknown model kind {kind!r}; expected one of {list(_BUILDERS)}")
        m = _BUILDERS[kind](entry).to(device)
        models[entry["name"]] = m

        clf_path = entry.get("classifier_path")
        if clf_path:
            target_class = entry.get("target_class")
            embed_fns[entry["name"]] = make_classifier_fn(m, clf_path, target_class)
            saliency_targets[entry["name"]] = f"P({target_class})" if target_class is not None else "class-prob vector"
        else:
            embed_fns[entry["name"]] = make_embed_fn(m)
            saliency_targets[entry["name"]] = "embedding"
    model_names = list(models.keys())
    for name, target in saliency_targets.items():
        print(f"[occlusion] {name}: saliency target = {target}")

    # Compute saliency for every (cell, t, model). Resolution = stride.
    # Shape per (cell, t, model): (H_out, W_out) where H_out = len(positions(H, occ_size, stride)).
    print(f"[occlusion] occ_size={occ_size}, stride={stride}, fill_value={fill_value}, distance={distance}")
    saliency_per_cell_per_model: dict[str, list[Tensor]] = {name: [] for name in model_names}
    upsample_hw = (patch_size, patch_size)
    with torch.no_grad():
        for c_idx, c in enumerate(cells_data):
            # Squeeze the singleton Z dim so we have (T_cell, 1, H, W) for foundation paths.
            # DynaCLR's _embed_dynaclr unsqueezes back when needed.
            imgs_4d = c["images"].squeeze(2)  # (T_cell, 1, H, W)
            for name in model_names:
                sal = occlusion_saliency(
                    imgs_4d,
                    embed_fns[name],
                    occ_size=occ_size,
                    stride=stride,
                    fill_value=fill_value,
                    batch_size=occ_batch_size,
                    distance=distance,
                )  # (T_cell, H_out, W_out)
                saliency_per_cell_per_model[name].append(sal)
            print(f"[occlusion] cell {c_idx}: saliency shape {tuple(sal.shape)} per model")

    # Render frames
    frames: list[np.ndarray] = []
    for t in all_t:
        cells_render: list[dict[str, Any]] = []
        for c_idx, c in enumerate(cells_data):
            idx = c["t_to_idx"].get(t)
            if idx is None:
                cells_render.append({"label": c["label"], "image": None, "overlays": {}})
                continue
            image = c["images"][idx, 0, 0]
            overlays: dict[str, Tensor] = {}
            for name in model_names:
                sal = saliency_per_cell_per_model[name][c_idx][idx : idx + 1]
                rgb = saliency_to_rgb(
                    sal,
                    cmap=cmap,
                    clip_percentile=clip_percentile,
                    upsample_to=upsample_hw,
                    interp_mode="nearest",
                )
                overlays[name] = rgb[0]
            cells_render.append({"label": c["label"], "image": image, "overlays": overlays})
        frames.append(_render_frame(cells_render, len(models), model_names, t, overlay_alpha=overlay_alpha))

    output_path = Path(spec["output_mp4"]).expanduser()
    output_path.parent.mkdir(parents=True, exist_ok=True)
    written = _write_movie(frames, str(output_path), fps=int(spec.get("fps", 4)))
    print(f"wrote {written} ({len(frames)} frames, {len(cells_data)} cells)")


def cli() -> None:
    """Argparse entry point for ``python -m dynaclr.visualization.timelapse_occlusion_cli``."""
    parser = argparse.ArgumentParser(description="Render multi-cell timelapse occlusion-saliency movie.")
    parser.add_argument("--spec", required=True, help="Path to YAML spec.")
    args = parser.parse_args()
    main(args.spec)


if __name__ == "__main__":
    cli()
