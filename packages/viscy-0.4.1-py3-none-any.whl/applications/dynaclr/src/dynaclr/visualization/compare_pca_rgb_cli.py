"""CLI: render side-by-side PCA-RGB overlays across multiple models.

Takes a YAML spec listing models (CELL-DINO / DINOv3 / DynaCLR / ...) and
a list of phase-image patches by ``(store, well, fov, t, y, x)``,
extracts dense features from each model, fits PCA-RGB independently per
model, and writes a comparison PDF.

Spec format::

    output_pdf: /path/to/figure.pdf
    patch_size: 160       # ZYX patch size (z=1, height=width=patch_size)
    upsample_to: 224
    mask_fg: true
    mode: batch           # per_image | batch | reference
    image_channel: Phase3D

    models:
      - name: CELL-DINO
        kind: cell_dino
        weights_path: /hpc/projects/.../channel_adaptive_dino_vitl16_pretrain_cells-ef7c17ff.pth
      - name: DINOv3
        kind: dinov3
        model_name: facebook/dinov3-convnext-tiny-pretrain-lvd1689m
      - name: DynaCLR-2D-BoC
        kind: dynaclr
        config_path: /hpc/projects/.../config.yaml
        ckpt_path: /hpc/projects/.../last.ckpt

    cells:
      - store: /hpc/.../registered.zarr
        well: A/1
        fov: '0'
        t: 12
        center_yx: [256, 256]   # patch is centred here
        title: A/1/0 t=12 ZIKV
"""

from __future__ import annotations

import argparse
from pathlib import Path
from typing import Any

import torch
import yaml
from iohub.ngff import open_ome_zarr
from torch import Tensor

from dynaclr.visualization.pca_rgb_overlay import (
    pca_rgb_compare,
    render_comparison_grid,
)


def _build_cell_dino(spec: dict[str, Any]) -> torch.nn.Module:
    from viscy_models.foundation import CellDinoModel

    return CellDinoModel(
        weights_path=spec["weights_path"],
        img_size=spec.get("img_size", 224),
        patch_size=spec.get("patch_size", 16),
    ).eval()


def _build_dinov3(spec: dict[str, Any]) -> torch.nn.Module:
    from viscy_models.foundation import DINOv3Model

    return DINOv3Model(model_name=spec["model_name"], freeze=True).eval()


def _build_openphenom(spec: dict[str, Any]) -> torch.nn.Module:
    from viscy_models.foundation import OpenPhenomModel

    return OpenPhenomModel(model_name=spec["model_name"], freeze=True).eval()


def _build_dynaclr(spec: dict[str, Any]) -> torch.nn.Module:
    """Load a DynaCLR ContrastiveModule from config + checkpoint."""
    from lightning.pytorch.cli import LightningArgumentParser

    from dynaclr.engine import ContrastiveModule

    with open(spec["config_path"]) as f:
        config = yaml.safe_load(f)
    parser = LightningArgumentParser()
    parser.add_lightning_class_args(ContrastiveModule, "model")
    args = parser.parse_object({"model": config["model"]["init_args"]})
    init = parser.instantiate_classes(args)
    module: ContrastiveModule = init.model
    state = torch.load(spec["ckpt_path"], map_location="cpu", weights_only=False)
    module.load_state_dict(state["state_dict"], strict=False)
    return module.eval()


_BUILDERS = {
    "cell_dino": _build_cell_dino,
    "dinov3": _build_dinov3,
    "openphenom": _build_openphenom,
    "dynaclr": _build_dynaclr,
}


def load_phase_patch(
    store: str,
    well: str,
    fov: str,
    t: int,
    center_yx: tuple[int, int],
    patch_size: int,
    image_channel: str,
    z: int | None = None,
    norm_mean: float | None = None,
    norm_std: float | None = None,
) -> Tensor:
    """Read a single ``(C=1, Z=1, H, W)`` phase patch centred on ``center_yx``.

    Parameters
    ----------
    z : int or None
        Explicit z-slice to extract.  When ``None``, falls back to the
        middle of the stack.  Callers driven by the cell_index parquet
        should pass the per-cell ``z`` column (which is the per-cell
        focus slice) so we follow the actual focal plane instead of
        slicing through cell tops or coverslip blur.
    norm_mean, norm_std : float or None
        Per-FOV normalization statistics applied as
        ``(patch - mean) / std`` after the zarr read.  These should be
        the same ``norm_mean`` / ``norm_std`` columns that drive
        ``viscy_transforms.NormalizeSampled`` at training time so the
        encoder sees the input distribution it was trained on.  When
        either is ``None``, no normalization is applied.
    """
    fov_path = f"{store}/{well}/{fov}"
    half = patch_size // 2
    cy, cx = center_yx
    with open_ome_zarr(fov_path, mode="r") as pos:
        channel_idx = pos.channel_names.index(image_channel)
        zarr_arr = pos["0"]
        z_idx = int(z) if z is not None else zarr_arr.shape[2] // 2
        z_idx = max(0, min(z_idx, zarr_arr.shape[2] - 1))
        patch = zarr_arr[t, channel_idx, z_idx, cy - half : cy + half, cx - half : cx + half]
    if patch.shape != (patch_size, patch_size):
        raise RuntimeError(f"patch out of bounds: got {patch.shape} for {fov_path} t={t}")
    tensor = torch.from_numpy(patch.copy()).float().unsqueeze(0).unsqueeze(0)
    if norm_mean is not None and norm_std is not None:
        tensor = (tensor - float(norm_mean)) / max(float(norm_std), 1e-8)
    return tensor


def main(spec_path: str) -> None:
    """Read spec, build models, load patches, render comparison PDF."""
    with open(spec_path) as f:
        spec = yaml.safe_load(f)

    patch_size = int(spec.get("patch_size", 160))
    image_channel = spec.get("image_channel", "Phase3D")

    images_list = []
    titles = []
    for cell in spec["cells"]:
        patch = load_phase_patch(
            store=cell["store"],
            well=cell["well"],
            fov=str(cell["fov"]),
            t=int(cell["t"]),
            center_yx=tuple(cell["center_yx"]),
            patch_size=patch_size,
            image_channel=image_channel,
        )
        images_list.append(patch)
        titles.append(cell.get("title", f"{cell['well']}/{cell['fov']} t={cell['t']}"))
    images = torch.cat(images_list, dim=0).unsqueeze(2)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    images = images.to(device)

    models: dict[str, torch.nn.Module] = {}
    for entry in spec["models"]:
        kind = entry["kind"]
        if kind not in _BUILDERS:
            raise ValueError(f"unknown model kind {kind!r}; expected one of {list(_BUILDERS)}")
        models[entry["name"]] = _BUILDERS[kind](entry).to(device)

    overlays = pca_rgb_compare(
        models,
        images,
        mode=spec.get("mode", "batch"),
        mask_fg=spec.get("mask_fg", True),
        fg_threshold=spec.get("fg_threshold", 0.5),
        upsample_to=(int(spec.get("upsample_to", patch_size)),) * 2,
    )

    output_pdf = Path(spec["output_pdf"]).expanduser()
    output_pdf.parent.mkdir(parents=True, exist_ok=True)
    render_comparison_grid(
        images.squeeze(2),
        overlays,
        output_path=str(output_pdf),
        image_titles=titles,
    )
    print(f"wrote {output_pdf}")


def cli() -> None:
    """Argparse entry point for ``python -m dynaclr.visualization.compare_pca_rgb_cli``."""
    parser = argparse.ArgumentParser(description="Render side-by-side PCA-RGB overlays across models.")
    parser.add_argument("--spec", required=True, help="Path to YAML spec.")
    args = parser.parse_args()
    main(args.spec)


if __name__ == "__main__":
    cli()
