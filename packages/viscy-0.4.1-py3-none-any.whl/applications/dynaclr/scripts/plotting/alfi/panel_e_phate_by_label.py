"""Panel 3b-v: PHATE colored by human annotation vs linear-classifier prediction.

Two columns:

- Left: PHATE colored by ``cell_division_state`` (human annotation).
- Right: PHATE colored by ``predicted_cell_division_state`` (linear
  classifier trained on DynaCLR embeddings, stored in the evaluation
  zarr as ``obsm.predicted_cell_division_state_proba``).

Each row is one cell line. If annotation and prediction overlap on the
same PHATE region the linear classifier has recovered the geometric
separation produced by the backbone — a sanity check, not the paper's
headline claim. Points missing an annotation are drawn in faded gray.
"""

from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from _common import (
    CELL_LINE_ZARRS,
    DEFAULT_EMB_ROOT,
    DEFAULT_OUTPUT_DIR,
    STATE_COLORS,
    ensure_outdir,
    load_cell_line,
)


def _scatter_by_category(ax, xy: np.ndarray, labels: pd.Series, color_map: dict[str, str], title: str) -> None:
    """Scatter PHATE colored by a categorical label column."""
    values = labels.to_numpy()
    mask_missing = pd.isna(values) | (values == "") | (values == "nan")
    if mask_missing.any():
        ax.scatter(xy[mask_missing, 0], xy[mask_missing, 1], s=2, c="#d9d9d9", alpha=0.4, linewidths=0)
    for cat, color in color_map.items():
        m = (values == cat) & (~mask_missing)
        if not m.any():
            continue
        ax.scatter(xy[m, 0], xy[m, 1], s=4, c=color, alpha=0.65, linewidths=0, label=f"{cat} (n={int(m.sum())})")
    ax.set_title(title, fontsize=10)
    ax.set_xticks([])
    ax.set_yticks([])
    for spine in ax.spines.values():
        spine.set_visible(False)
    ax.legend(fontsize=8, frameon=False, loc="best", markerscale=2)


def plot(
    emb_root: Path,
    output_dir: Path,
    phate_key: str = "X_phate_combined",
    model_label: str = "time-aware",
) -> Path:
    """Render the annotation-vs-prediction PHATE grid.

    Parameters
    ----------
    emb_root : Path
        Root embedding directory.
    output_dir : Path
        Destination directory.
    phate_key : str
        ``obsm`` key to visualize.
    model_label : str
        Tag appended to filenames.

    Returns
    -------
    Path
        Saved PNG.
    """
    lines = list(CELL_LINE_ZARRS)
    fig, axes = plt.subplots(len(lines), 2, figsize=(10.0, 3.4 * len(lines)), constrained_layout=True)
    if len(lines) == 1:
        axes = np.array([axes])

    for row, line in enumerate(lines):
        adata = load_cell_line(line, emb_root=emb_root)
        xy = np.asarray(adata.obsm[phate_key])
        ann = adata.obs["cell_division_state"].astype(str)
        pred = adata.obs["predicted_cell_division_state"].astype(str)
        _scatter_by_category(axes[row, 0], xy, ann, STATE_COLORS, f"{line} — human annotation")
        _scatter_by_category(axes[row, 1], xy, pred, STATE_COLORS, f"{line} — linear-classifier prediction")

    fig.suptitle(f"PHATE colored by division state ({model_label})", fontsize=12)

    ensure_outdir(output_dir)
    out = output_dir / f"panel_3bv_phate_by_label_{model_label}.png"
    fig.savefig(out, dpi=200)
    plt.close(fig)
    return out


def main() -> None:
    """CLI entry point."""
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--emb-root", type=Path, default=DEFAULT_EMB_ROOT)
    p.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT_DIR)
    p.add_argument("--phate-key", default="X_phate_combined")
    p.add_argument("--model-label", default="time-aware")
    args = p.parse_args()
    out = plot(args.emb_root, args.output_dir, phate_key=args.phate_key, model_label=args.model_label)
    print(f"wrote {out}")


if __name__ == "__main__":
    main()
