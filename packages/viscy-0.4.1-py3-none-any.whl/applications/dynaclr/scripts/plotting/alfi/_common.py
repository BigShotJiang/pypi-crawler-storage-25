"""Shared helpers for ALFI mitosis cycle-structure panels.

These panels test whether DynaCLR embeddings recover the closed-loop
structure of a division event (interphase -> mitosis -> interphase) at
single-cell resolution. Classification of interphase vs mitosis from DIC
is saturated — every baseline scores high AUROC — so the discriminative
tests here are geometric: cycle closure error, displacement peak alignment
with human annotations, and drug-perturbed trajectory shape (U2OS DMSO
vs MLN8237).

Embedding source:
``/hpc/projects/organelle_phenotyping/models/DynaCLR-2D-MIP-BagOfChannels/
2d-mip-ntxent-t0p2-lr2e5-bs256-192to160-zext11/evaluations/alfi/embeddings/``
"""

from __future__ import annotations

import warnings
from pathlib import Path

import anndata as ad
import numpy as np
import pandas as pd

DEFAULT_EMB_ROOT = Path(
    "/hpc/projects/organelle_phenotyping/models/"
    "DynaCLR-2D-MIP-BagOfChannels/"
    "2d-mip-ntxent-t0p2-lr2e5-bs256-192to160-zext11/"
    "evaluations/alfi/embeddings"
)

CELL_LINE_ZARRS: dict[str, str] = {
    "HeLa": "ALFI_HeLa_DMSO_MLN8237.zarr",
    "RPE1": "ALFI_RPE1_untreated.zarr",
    "U2OS": "ALFI_U2OS_DMSO_MLN8237.zarr",
}

CELL_LINE_COLORS: dict[str, str] = {
    "HeLa": "#1f77b4",
    "RPE1": "#2ca02c",
    "U2OS": "#d62728",
}

PERTURBATION_COLORS: dict[str, str] = {
    "DMSO": "#1f77b4",
    "untreated": "#7f7f7f",
    "MLN8237": "#d62728",
}

STATE_COLORS: dict[str, str] = {
    "interphase": "#4f7dc0",
    "mitosis": "#e03b3b",
}

MODEL_COLORS: dict[str, str] = {
    "time-aware": "#2ca02c",
    "classical": "#ff7f0e",
    "frozen": "#7f7f7f",
}

DEFAULT_OUTPUT_DIR = Path(__file__).resolve().parent / "outputs"

INTERPHASE_LABEL = "interphase"
MITOSIS_LABEL = "mitosis"


def load_embedding(zarr_path: Path) -> ad.AnnData:
    """Read an ALFI embedding zarr produced by the DynaCLR evaluation pipeline.

    Observation names are non-unique — the obs index is replaced with a
    plain ``RangeIndex`` so downstream code indexes by position.
    ``obs_names_make_unique`` is not called because it is O(n^2) on the
    ArrowStringArrays produced by AnnData 0.10+ for large zarrs.

    Parameters
    ----------
    zarr_path : Path
        Path to the AnnData ``.zarr``.

    Returns
    -------
    AnnData
        Loaded embeddings with a positional obs index.
    """
    with warnings.catch_warnings():
        warnings.filterwarnings("ignore", message="Observation names are not unique")
        adata = ad.read_zarr(zarr_path)
    adata.obs.index = pd.RangeIndex(adata.n_obs).astype(str)
    return adata


def load_cell_line(cell_line: str, emb_root: Path = DEFAULT_EMB_ROOT) -> ad.AnnData:
    """Load embeddings for a named ALFI cell line.

    Parameters
    ----------
    cell_line : {"HeLa", "RPE1", "U2OS"}
        ALFI cell-line key.
    emb_root : Path
        Root directory containing the per-cell-line ``.zarr`` folders.

    Returns
    -------
    AnnData
        Embeddings with positional obs index.
    """
    fname = CELL_LINE_ZARRS[cell_line]
    return load_embedding(emb_root / fname)


def get_features(adata: ad.AnnData, embedding_key: str, n_components: int | None = None) -> np.ndarray:
    """Return a dense feature matrix from ``X`` or an ``obsm`` key.

    Parameters
    ----------
    adata : AnnData
        Embedding container.
    embedding_key : str
        ``"X"`` for the full 768-D features, or a key in ``obsm``
        (e.g. ``"X_pca_combined"``).
    n_components : int or None
        Truncate to the first ``n_components`` dimensions if provided.

    Returns
    -------
    np.ndarray
        Array of shape ``(n_obs, d)``.
    """
    if embedding_key == "X":
        feats = np.asarray(adata.X)
    else:
        feats = np.asarray(adata.obsm[embedding_key])
    if n_components is not None:
        feats = feats[:, :n_components]
    return feats


def _find_longest_run(mask: np.ndarray) -> tuple[int, int] | None:
    """Return ``(start, stop_exclusive)`` of the longest True run in ``mask``.

    Returns ``None`` if no True value is present.
    """
    if not mask.any():
        return None
    idx = np.flatnonzero(mask)
    gaps = np.where(np.diff(idx) > 1)[0]
    splits = np.split(idx, gaps + 1)
    best = max(splits, key=len)
    return int(best[0]), int(best[-1]) + 1


def extract_division_windows(
    adata: ad.AnnData,
    k_flank: int = 5,
    state_key: str = "cell_division_state",
    aggregate_sisters: bool = True,
    require_full_cycle: bool = False,
) -> pd.DataFrame:
    """Extract lineage-stitched division windows (pre / mit / post).

    ALFI tracking splits lineages at each division event, so a single
    ``track_id`` is a *lineage segment* rather than a full cell lifespan.
    To recover pre → mit → post we stitch parent → daughter through
    ``parent_track_id``: the mitosis segment lives at the end of the
    parent track and the start of the daughter track.

    For each candidate parent track ending in ``mitosis``:

    - ``pre_rows``  — up to ``k_flank`` interphase frames at the end of
      the parent track (the frames immediately preceding the mitosis
      run).
    - ``mit_rows``  — all mitosis frames of the parent track concatenated
      with the leading mitosis frames of the daughter (sister daughters
      pooled when ``aggregate_sisters=True``).
    - ``post_rows`` — daughter interphase frames following the mitosis
      segment (sister daughters pooled when ``aggregate_sisters=True``).

    Tracks without both a parent (``parent_track_id``) and at least one
    daughter (back-link via ``parent_track_id``) are dropped, as are
    windows that do not meet ``k_flank`` frames of interphase on either
    side.

    Parameters
    ----------
    adata : AnnData
        ALFI embedding object.
    k_flank : int
        Number of interphase frames required on each side.
    state_key : str
        ``obs`` column holding the division-state label.
    aggregate_sisters : bool
        If True (default) sister daughters are pooled into one post and
        one mit segment per division event (preserves existing panel
        behavior). If False, each sister daughter emits its own row,
        sharing the parent's ``pre_rows`` and ``parent_track_id`` but
        carrying the sister's own ``daughter_track_id`` and row indices.
        This surfaces sister-to-sister heterogeneity (useful under
        MLN8237 where sisters diverge).
    require_full_cycle : bool
        If True, additionally require the parent track to **start** in
        mitosis, meaning we observed the cell's birth. Combined with the
        existing "ends in mitosis" requirement, this selects cells for
        which the full division → interphase → division cycle is
        captured in-frame. Default False.

    Returns
    -------
    pandas.DataFrame
        One row per accepted event. Columns always include
        ``fov_name``, ``parent_track_id``, ``perturbation``,
        ``pre_rows``, ``mit_rows``, ``post_rows``, ``t_mit_start``,
        ``t_mit_end``, ``t_mit_mid``, ``n_mit``, ``full_cycle``. When
        ``aggregate_sisters=True`` an additional ``daughter_track_ids``
        tuple is present; when False a single ``daughter_track_id`` is
        present instead. ``*_rows`` are 1-D numpy arrays of adata row
        indices sorted by ``t``.
    """
    cols = ["fov_name", "track_id", "parent_track_id", "t", "perturbation", state_key]
    df = adata.obs[cols].copy()
    df["row"] = np.arange(len(df))

    track_map: dict[tuple[str, int], pd.DataFrame] = {}
    daughters_of: dict[tuple[str, int], list[int]] = {}
    for (fov, tid), sub in df.groupby(["fov_name", "track_id"], sort=False, observed=True):
        sub = sub.sort_values("t").reset_index(drop=True)
        track_map[(fov, int(tid))] = sub
        parent = int(sub["parent_track_id"].iloc[0])
        if parent >= 0:
            daughters_of.setdefault((fov, parent), []).append(int(tid))

    out: list[dict] = []
    for (fov, tid), parent_sub in track_map.items():
        daughters = daughters_of.get((fov, tid), [])
        if not daughters:
            continue

        p_states = parent_sub[state_key].to_numpy()
        p_rows = parent_sub["row"].to_numpy()
        p_t = parent_sub["t"].to_numpy()

        run = _find_longest_run(p_states == MITOSIS_LABEL)
        if run is None:
            continue
        mit_start, mit_stop = run
        if mit_stop != len(p_states):
            continue
        if mit_start < k_flank:
            continue
        if not np.all(p_states[mit_start - k_flank : mit_start] == INTERPHASE_LABEL):
            continue

        full_cycle = bool(p_states[0] == MITOSIS_LABEL)
        if require_full_cycle and not full_cycle:
            continue

        accepted: list[dict] = []
        for dtid in daughters:
            d_sub = track_map.get((fov, dtid))
            if d_sub is None or len(d_sub) < k_flank + 1:
                continue
            d_states = d_sub[state_key].to_numpy()
            d_rows = d_sub["row"].to_numpy()
            lead = 0
            while lead < len(d_states) and d_states[lead] == MITOSIS_LABEL:
                lead += 1
            post_end = lead + k_flank
            if post_end > len(d_states):
                continue
            if not np.all(d_states[lead:post_end] == INTERPHASE_LABEL):
                continue
            accepted.append(
                {
                    "daughter_track_id": dtid,
                    "mit_rows": d_rows[:lead],
                    "post_rows": d_rows[lead:post_end],
                }
            )

        if not accepted:
            continue

        pre_rows = p_rows[mit_start - k_flank : mit_start]
        parent_mit = p_rows[mit_start:mit_stop]
        t_mit_start = int(p_t[mit_start])
        t_mit_end = int(p_t[mit_stop - 1])
        t_mit_mid = int(p_t[mit_start + (mit_stop - mit_start) // 2])

        base = {
            "fov_name": fov,
            "parent_track_id": int(tid),
            "perturbation": parent_sub["perturbation"].iloc[0],
            "pre_rows": pre_rows,
            "t_mit_start": t_mit_start,
            "t_mit_end": t_mit_end,
            "t_mit_mid": t_mit_mid,
            "full_cycle": full_cycle,
        }

        if aggregate_sisters:
            mit_rows = np.concatenate([parent_mit] + [a["mit_rows"] for a in accepted])
            post_rows = np.concatenate([a["post_rows"] for a in accepted])
            out.append(
                {
                    **base,
                    "daughter_track_ids": tuple(a["daughter_track_id"] for a in accepted),
                    "mit_rows": mit_rows,
                    "post_rows": post_rows,
                    "n_mit": int(len(mit_rows)),
                }
            )
        else:
            for a in accepted:
                mit_rows = np.concatenate([parent_mit, a["mit_rows"]])
                out.append(
                    {
                        **base,
                        "daughter_track_id": a["daughter_track_id"],
                        "mit_rows": mit_rows,
                        "post_rows": a["post_rows"],
                        "n_mit": int(len(mit_rows)),
                    }
                )
    return pd.DataFrame(out)


def interphase_reference(
    adata: ad.AnnData,
    features: np.ndarray,
    state_key: str = "cell_division_state",
    weight_by_track: bool = True,
) -> np.ndarray:
    """Compute the mean embedding over interphase frames.

    By default each ``(fov_name, track_id)`` gets equal weight: the
    function first averages interphase frames within a track, then
    averages across tracks. This prevents long tracks from dominating
    the reference — e.g. a 184-frame HeLa track otherwise contributes
    184× the weight of a 5-frame track. Set ``weight_by_track=False``
    to recover the naive "mean over all interphase observations"
    behavior.

    Parameters
    ----------
    adata : AnnData
        Embeddings object.
    features : np.ndarray
        Feature matrix aligned to ``adata`` rows.
    state_key : str
        ``obs`` column with division-state labels.
    weight_by_track : bool
        If True, average within each track before averaging across
        tracks. Default True.

    Returns
    -------
    np.ndarray
        Reference vector of shape ``(d,)``.
    """
    mask = (adata.obs[state_key].to_numpy() == INTERPHASE_LABEL)
    if not weight_by_track:
        return features[mask].mean(axis=0)
    df = adata.obs[["fov_name", "track_id"]].copy()
    df["row"] = np.arange(len(df))
    df = df[mask]
    means: list[np.ndarray] = []
    for _, sub in df.groupby(["fov_name", "track_id"], sort=False, observed=True):
        rows = sub["row"].to_numpy()
        means.append(features[rows].mean(axis=0))
    return np.stack(means, axis=0).mean(axis=0)


def window_trajectory_rows(window: pd.Series) -> np.ndarray:
    """Concatenate pre / mit / post row indices for a single window row.

    Parameters
    ----------
    window : pandas.Series
        Row returned by :func:`extract_division_windows`.

    Returns
    -------
    np.ndarray
        1-D array of row indices, time-ordered.
    """
    return np.concatenate([window["pre_rows"], window["mit_rows"], window["post_rows"]])


def ensure_outdir(path: Path) -> Path:
    """Create ``path`` (and parents) if missing and return it."""
    path.mkdir(parents=True, exist_ok=True)
    return path
