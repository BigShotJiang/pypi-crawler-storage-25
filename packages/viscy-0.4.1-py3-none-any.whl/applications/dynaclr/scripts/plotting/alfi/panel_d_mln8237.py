"""Panel 3b-iv: MLN8237 vs DMSO on U2OS — mitosis duration and trajectory shape.

MLN8237 inhibits Aurora-A kinase and causes mitotic arrest: dividing
cells dwell on the mitotic manifold for several times longer than DMSO
controls. Two readouts:

- **Mitosis duration (frames).** Per accepted division event, the count
  of frames on the mitotic segment. This is the primary biological
  readout — a direct measure of time spent in mitosis. Plotted as a
  violin + stripplot with individual events visible.

- **Per-phase Hausdorff distance.** For each of ``pre`` / ``mit`` /
  ``post`` windows, compute the symmetric Hausdorff distance between
  DMSO and MLN8237 point clouds in PCA-32 space. If MLN8237 distorts
  the trajectory it should show as a larger Hausdorff at ``mit`` than
  at ``pre`` (the interphase starting condition should differ least
  between the two drug groups; the mitotic state should differ most).

U2OS-only — the other ALFI zarrs lack MLN8237. Reviewer notes:
U2OS-DMSO n=3 is small; the panel shows individual points and reports n.
"""

from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.metrics import pairwise_distances

from _common import (
    DEFAULT_EMB_ROOT,
    DEFAULT_OUTPUT_DIR,
    PERTURBATION_COLORS,
    ensure_outdir,
    extract_division_windows,
    get_features,
    load_cell_line,
)


def hausdorff_symmetric(a: np.ndarray, b: np.ndarray) -> float:
    """Return the symmetric Hausdorff distance between two point clouds.

    Parameters
    ----------
    a, b : np.ndarray
        ``(n, d)`` arrays.

    Returns
    -------
    float
        ``max(sup_a min_b d, sup_b min_a d)``.
    """
    d = pairwise_distances(a, b)
    return float(max(d.min(axis=1).max(), d.min(axis=0).max()))


def duration_per_window(windows: pd.DataFrame) -> pd.DataFrame:
    """Return per-window mitosis duration labeled with perturbation.

    Parameters
    ----------
    windows : pandas.DataFrame
        Division windows.

    Returns
    -------
    pandas.DataFrame
        Columns ``parent_track_id``, ``perturbation``,
        ``mitosis_duration``.
    """
    if windows.empty:
        return pd.DataFrame(columns=["parent_track_id", "perturbation", "mitosis_duration"])
    return pd.DataFrame(
        {
            "parent_track_id": windows["parent_track_id"].to_numpy(),
            "perturbation": windows["perturbation"].to_numpy(),
            "mitosis_duration": windows["mit_rows"].apply(len).astype(int).to_numpy(),
        }
    )


def collect_phase_clouds(
    features: np.ndarray, windows: pd.DataFrame
) -> dict[tuple[str, str], np.ndarray]:
    """Collect ``(perturbation, phase) -> stacked embeddings``.

    Parameters
    ----------
    features : np.ndarray
        Aligned feature matrix.
    windows : pandas.DataFrame
        Division windows.

    Returns
    -------
    dict
        Keys like ``("DMSO", "pre")``; values are ``(n, d)`` arrays.
    """
    buckets: dict[tuple[str, str], list[np.ndarray]] = {}
    for _, w in windows.iterrows():
        pert = w["perturbation"]
        for phase_key, rows_key in (("pre", "pre_rows"), ("mit", "mit_rows"), ("post", "post_rows")):
            buckets.setdefault((pert, phase_key), []).append(features[w[rows_key]])
    return {k: np.concatenate(v, axis=0) for k, v in buckets.items()}


def plot(
    emb_root: Path,
    output_dir: Path,
    embedding_key: str = "X_pca_combined",
    n_components: int | None = 32,
    k_flank: int = 5,
    model_label: str = "time-aware",
) -> tuple[Path, Path]:
    """Render the U2OS DMSO-vs-MLN8237 figure and write CSVs.

    Parameters
    ----------
    emb_root : Path
        Root embedding directory.
    output_dir : Path
        Destination directory.
    embedding_key : str
        Feature source for the Hausdorff distance (defaults to PCA-32).
    n_components : int or None
        Feature truncation for Hausdorff.
    k_flank : int
        Interphase flank length.
    model_label : str
        Tag appended to filenames.

    Returns
    -------
    (Path, Path)
        Figure and the per-event mitosis-duration CSV.
    """
    adata = load_cell_line("U2OS", emb_root=emb_root)
    feats = get_features(adata, embedding_key, n_components=n_components)
    windows = extract_division_windows(adata, k_flank=k_flank)
    if windows.empty:
        raise RuntimeError("no U2OS division windows — check k_flank and labels")

    durations = duration_per_window(windows)
    clouds = collect_phase_clouds(feats, windows)

    dmso = durations[durations["perturbation"] == "DMSO"]["mitosis_duration"].to_numpy()
    mln = durations[durations["perturbation"] == "MLN8237"]["mitosis_duration"].to_numpy()

    hausdorff_per_phase: dict[str, float] = {}
    for phase in ("pre", "mit", "post"):
        a = clouds.get(("DMSO", phase))
        b = clouds.get(("MLN8237", phase))
        if a is None or b is None or len(a) == 0 or len(b) == 0:
            continue
        hausdorff_per_phase[phase] = hausdorff_symmetric(a, b)

    fig, (ax_box, ax_haus) = plt.subplots(1, 2, figsize=(11.0, 4.3), constrained_layout=True)

    positions = [0, 1]
    data = [dmso, mln]
    labels = [f"DMSO\n(n={len(dmso)})", f"MLN8237\n(n={len(mln)})"]
    vp = ax_box.violinplot(data, positions=positions, widths=0.7, showmedians=True, showextrema=False)
    for body, pert in zip(vp["bodies"], ("DMSO", "MLN8237")):
        body.set_facecolor(PERTURBATION_COLORS[pert])
        body.set_alpha(0.5)
        body.set_edgecolor("#333")
    rng = np.random.default_rng(0)
    for i, (pert, arr) in enumerate(zip(("DMSO", "MLN8237"), data)):
        jitter = rng.uniform(-0.07, 0.07, size=len(arr))
        ax_box.scatter(
            positions[i] + jitter, arr,
            s=40, color=PERTURBATION_COLORS[pert],
            alpha=0.85, edgecolors="#222", linewidths=0.5,
        )
    ax_box.set_xticks(positions)
    ax_box.set_xticklabels(labels)
    ax_box.set_ylabel("mitosis duration (frames)")
    ax_box.set_title(f"U2OS mitosis duration — DMSO vs MLN8237 ({model_label})")
    ax_box.grid(axis="y", linestyle=":", linewidth=0.5, alpha=0.6)

    phases = list(hausdorff_per_phase.keys())
    vals = [hausdorff_per_phase[p] for p in phases]
    ax_haus.bar(phases, vals, color="#555", width=0.55)
    ax_haus.set_ylabel(f"symmetric Hausdorff distance ({embedding_key})")
    ax_haus.set_title(f"DMSO ↔ MLN8237 phase clouds ({model_label})")
    ax_haus.grid(axis="y", linestyle=":", linewidth=0.5, alpha=0.6)

    ensure_outdir(output_dir)
    fig_path = output_dir / f"panel_3biv_mln8237_{model_label}.png"
    csv_path = output_dir / f"panel_3biv_mln8237_{model_label}.csv"
    summary_path = output_dir / f"panel_3biv_hausdorff_{model_label}.csv"
    fig.savefig(fig_path, dpi=200)
    plt.close(fig)

    durations.assign(cell_line="U2OS", model=model_label).to_csv(csv_path, index=False)
    pd.DataFrame(
        [
            {"phase": p, "hausdorff": v, "model": model_label, "embedding_key": embedding_key}
            for p, v in hausdorff_per_phase.items()
        ]
    ).to_csv(summary_path, index=False)
    return fig_path, csv_path


def main() -> None:
    """CLI entry point."""
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--emb-root", type=Path, default=DEFAULT_EMB_ROOT)
    p.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT_DIR)
    p.add_argument("--embedding-key", default="X_pca_combined")
    p.add_argument("--n-components", type=int, default=32)
    p.add_argument("--k-flank", type=int, default=5)
    p.add_argument("--model-label", default="time-aware")
    args = p.parse_args()

    fig_path, csv_path = plot(
        args.emb_root,
        args.output_dir,
        embedding_key=args.embedding_key,
        n_components=args.n_components if args.n_components > 0 else None,
        k_flank=args.k_flank,
        model_label=args.model_label,
    )
    print(f"wrote {fig_path}")
    print(f"wrote {csv_path}")


if __name__ == "__main__":
    main()
