"""Panel 3b-i: representative cycle loop + displacement curve, per cell line.

For each ALFI cell line (HeLa, RPE1, U2OS) render a two-column row:

- Left column: one representative dividing cell's pre -> mit -> post
  trajectory overlaid on the pre-computed ``X_phate_combined`` embedding.
  Background shows all cells; mitotic frames are pink; the trajectory is
  colored by relative frame position with pre/post endpoints boxed.
- Right column: that same cell's displacement from the interphase
  reference (Euclidean norm in the 768-D feature space) vs
  ``t_rel = t - t_mit_mid``. Shaded band: inter-quartile range across
  all accepted tracks for the cell line, so the single cell can be read
  against the population.

A well-formed cycle returns near its starting point (small closure
error) and produces a sharp, roughly-symmetric displacement pulse.
To compare across models, re-run with ``--model-label classical`` /
``frozen`` against different ``--emb-root`` and bundle via
``make_story_pdf.py``.
"""

from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from _common import (
    CELL_LINE_COLORS,
    CELL_LINE_ZARRS,
    DEFAULT_EMB_ROOT,
    DEFAULT_OUTPUT_DIR,
    MITOSIS_LABEL,
    ensure_outdir,
    extract_division_windows,
    get_features,
    interphase_reference,
    load_cell_line,
    window_trajectory_rows,
)


def pick_representative(windows: pd.DataFrame, features: np.ndarray, reference: np.ndarray) -> int:
    """Return the iloc of the median-peak-displacement track.

    Picks the track whose peak displacement is closest to the median
    across accepted tracks, which avoids cherry-picking extremes.

    Parameters
    ----------
    windows : pandas.DataFrame
        Output of :func:`extract_division_windows`.
    features : np.ndarray
        Feature matrix for the displacement norm.
    reference : np.ndarray
        Interphase mean embedding.

    Returns
    -------
    int
        Integer position into ``windows``.
    """
    peaks = []
    for _, w in windows.iterrows():
        d = np.linalg.norm(features[w["mit_rows"]] - reference, axis=1)
        peaks.append(float(d.max()))
    peaks = np.asarray(peaks)
    target = np.median(peaks)
    return int(np.argmin(np.abs(peaks - target)))


def per_track_displacements(
    features: np.ndarray, windows: pd.DataFrame, reference: np.ndarray, t_obs: np.ndarray
) -> pd.DataFrame:
    """Return a long-format (parent_track_id, t_rel, displacement) table.

    Parameters
    ----------
    features : np.ndarray
        Feature matrix (e.g. 768-D).
    windows : pandas.DataFrame
        Accepted windows.
    reference : np.ndarray
        Interphase mean.
    t_obs : np.ndarray
        ``adata.obs["t"]`` aligned to feature rows.

    Returns
    -------
    pandas.DataFrame
        Columns ``parent_track_id``, ``t_rel``, ``displacement``.
    """
    rows = []
    for _, w in windows.iterrows():
        idx = window_trajectory_rows(w)
        d = np.linalg.norm(features[idx] - reference, axis=1)
        rows.append(
            pd.DataFrame(
                {
                    "parent_track_id": w["parent_track_id"],
                    "t_rel": t_obs[idx] - w["t_mit_mid"],
                    "displacement": d,
                }
            )
        )
    return pd.concat(rows, ignore_index=True)


def _plot_loop(ax, adata, window, phate: np.ndarray) -> None:
    """Draw one representative loop on a PHATE background."""
    ax.scatter(phate[:, 0], phate[:, 1], s=2, c="#d9d9d9", alpha=0.5, linewidths=0)
    mit_mask = adata.obs["cell_division_state"].to_numpy() == MITOSIS_LABEL
    ax.scatter(phate[mit_mask, 0], phate[mit_mask, 1], s=3, c="#f2b3b3", alpha=0.6, linewidths=0)

    rows = window_trajectory_rows(window)
    xy = phate[rows]
    t_local = np.arange(len(rows))
    ax.plot(xy[:, 0], xy[:, 1], "-", color="#333", linewidth=1.0, alpha=0.85)
    sc = ax.scatter(xy[:, 0], xy[:, 1], c=t_local, cmap="viridis", s=20, zorder=3)

    n_pre = len(window["pre_rows"])
    n_mit = len(window["mit_rows"])
    ax.scatter(*xy[0], marker="s", s=80, facecolor="none", edgecolor="#4f7dc0", linewidths=2)
    ax.scatter(*xy[n_pre - 1], marker="o", s=80, facecolor="none", edgecolor="#4f7dc0", linewidths=2)
    ax.scatter(*xy[n_pre + n_mit // 2], marker="*", s=160, facecolor="#e03b3b", edgecolor="k", linewidths=0.8)
    ax.scatter(*xy[n_pre + n_mit], marker="o", s=80, facecolor="none", edgecolor="#2ca02c", linewidths=2)
    ax.scatter(*xy[-1], marker="s", s=80, facecolor="none", edgecolor="#2ca02c", linewidths=2)
    ax.set_xticks([])
    ax.set_yticks([])
    for spine in ax.spines.values():
        spine.set_visible(False)
    return sc


def _plot_displacement(ax, per_track: pd.DataFrame, rep_tid: int, color: str) -> None:
    """Draw population IQR band + the representative track."""
    if per_track.empty:
        return
    agg = per_track.groupby("t_rel")["displacement"].agg(
        median="median",
        q25=lambda x: np.percentile(x, 25),
        q75=lambda x: np.percentile(x, 75),
        n="count",
    ).reset_index()
    x = agg["t_rel"].to_numpy()
    ax.fill_between(x, agg["q25"], agg["q75"], color=color, alpha=0.2, linewidth=0, label="population IQR")
    ax.plot(x, agg["median"], "-", color=color, linewidth=1.5, alpha=0.7, label="population median")

    rep = per_track[per_track["parent_track_id"] == rep_tid].sort_values("t_rel")
    ax.plot(rep["t_rel"], rep["displacement"], "-", color="#222", linewidth=2.0, label="representative cell")

    ax.axvline(0, color="#888", linewidth=0.8, linestyle="--")
    ax.set_xlabel("frames relative to mitosis midpoint")
    ax.set_ylabel("displacement from interphase")
    ax.legend(fontsize=8, frameon=False, loc="upper right")


def plot(
    emb_root: Path,
    output_dir: Path,
    embedding_key: str = "X",
    n_components: int | None = None,
    k_flank: int = 5,
    phate_key: str = "X_phate_combined",
    model_label: str = "time-aware",
) -> Path:
    """Render a 3x2 figure: loops (left) and displacement curves (right).

    Parameters
    ----------
    emb_root : Path
        Root embedding directory.
    output_dir : Path
        Destination directory.
    embedding_key : str
        Feature source for the displacement norm.
    n_components : int or None
        Optional feature truncation.
    k_flank : int
        Interphase flank length on each side of the mitosis run.
    phate_key : str
        ``obsm`` key for the loop background.
    model_label : str
        Tag appended to filenames.

    Returns
    -------
    Path
        Saved PNG.
    """
    lines = list(CELL_LINE_ZARRS)
    fig, axes = plt.subplots(
        len(lines), 2,
        figsize=(10.0, 3.3 * len(lines)),
        gridspec_kw={"width_ratios": [1.0, 1.3]},
        constrained_layout=True,
    )
    if len(lines) == 1:
        axes = np.array([axes])

    sc_last = None
    for row_idx, line in enumerate(lines):
        ax_loop, ax_disp = axes[row_idx]
        adata = load_cell_line(line, emb_root=emb_root)
        feats = get_features(adata, embedding_key, n_components=n_components)
        windows = extract_division_windows(adata, k_flank=k_flank)
        if windows.empty:
            for a in (ax_loop, ax_disp):
                a.text(0.5, 0.5, f"{line}: no windows", ha="center", va="center", transform=a.transAxes)
                a.set_axis_off()
            continue

        ref = interphase_reference(adata, feats)
        rep_idx = pick_representative(windows, feats, ref)
        rep_window = windows.iloc[rep_idx]

        phate = np.asarray(adata.obsm[phate_key])
        sc_last = _plot_loop(ax_loop, adata, rep_window, phate)
        ax_loop.set_title(f"{line} ({model_label}) — representative loop", fontsize=10)

        t_obs = adata.obs["t"].to_numpy()
        per_track = per_track_displacements(feats, windows, ref, t_obs)
        _plot_displacement(ax_disp, per_track, rep_window["parent_track_id"], CELL_LINE_COLORS[line])
        ax_disp.set_title(f"{line} — displacement (n={len(windows)} events)", fontsize=10)

    if sc_last is not None:
        cbar = fig.colorbar(sc_last, ax=axes[:, 0].tolist(), shrink=0.6, pad=0.02, location="left")
        cbar.set_label("frame in window", fontsize=9)

    ensure_outdir(output_dir)
    out = output_dir / f"panel_3bi_loops_{model_label}.png"
    fig.savefig(out, dpi=200)
    plt.close(fig)
    return out


def main() -> None:
    """CLI entry point."""
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--emb-root", type=Path, default=DEFAULT_EMB_ROOT)
    p.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT_DIR)
    p.add_argument("--embedding-key", default="X")
    p.add_argument("--n-components", type=int, default=0)
    p.add_argument("--k-flank", type=int, default=5)
    p.add_argument("--phate-key", default="X_phate_combined")
    p.add_argument("--model-label", default="time-aware")
    args = p.parse_args()

    out = plot(
        args.emb_root,
        args.output_dir,
        embedding_key=args.embedding_key,
        n_components=args.n_components if args.n_components > 0 else None,
        k_flank=args.k_flank,
        phate_key=args.phate_key,
        model_label=args.model_label,
    )
    print(f"wrote {out}")


if __name__ == "__main__":
    main()
