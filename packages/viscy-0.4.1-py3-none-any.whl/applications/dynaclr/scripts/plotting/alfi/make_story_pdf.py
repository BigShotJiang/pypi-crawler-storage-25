"""Bundle the ALFI Fig 3b panels into a single PDF for review.

Each expected panel PNG is added as one page. Filenames follow the
``panel_3b{i,ii,iii,iv}_*_{model_label}.png`` convention produced by the
panel scripts. Missing files are skipped with a warning — the bundle
still renders so mock / partial runs remain reviewable.

Pass ``--model-label`` multiple ways:

- Single model: ``--model-label time-aware`` bundles one model's panels.
- All models: ``--model-labels time-aware classical frozen`` interleaves
  panels across models for side-by-side comparison.
"""

from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib.image as mpimg
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages

OUTPUTS = Path(__file__).resolve().parent / "outputs"

PANEL_ORDER: list[tuple[str, str]] = [
    ("3b-i   — representative loop + displacement (per cell line)", "panel_3bi_loops"),
    ("3b-iv  — MLN8237 vs DMSO on U2OS", "panel_3biv_mln8237"),
    ("3b-v   — PHATE: annotation vs linear-classifier prediction", "panel_3bv_phate_by_label"),
    ("3b-vi  — cell-type × condition: embedding and dynamics", "panel_3bvi_cell_type"),
    ("3b-vii — full-cycle cell trajectories (diagnostic)", "panel_3bvii_fullcycle"),
]


def _add_image_page(pdf: PdfPages, title: str, path: Path) -> None:
    """Render one PNG as a full page in the PDF."""
    img = mpimg.imread(path)
    h, w = img.shape[:2]
    long_side = 11.0
    scale = long_side / max(h, w)
    fig_w = w * scale
    fig_h = h * scale + 0.6
    fig = plt.figure(figsize=(fig_w, fig_h))
    ax = fig.add_axes((0.02, 0.02, 0.96, 0.88))
    ax.imshow(img)
    ax.set_xticks([])
    ax.set_yticks([])
    for spine in ax.spines.values():
        spine.set_visible(False)
    fig.text(0.02, 0.94, title, fontsize=11, fontweight="bold")
    fig.text(0.02, 0.91, str(path.name), fontsize=7, color="#666", family="monospace")
    pdf.savefig(fig, bbox_inches="tight")
    plt.close(fig)


def collect_pages(outputs_dir: Path, model_labels: list[str]) -> list[tuple[str, Path]]:
    """Build the list of pages in display order.

    Panels are grouped by panel first, then by model, so a reviewer sees
    the three models back-to-back for 3b-i before moving on to 3b-ii.

    Parameters
    ----------
    outputs_dir : Path
        Directory where the panel scripts wrote their PNGs.
    model_labels : list of str
        One or more model tags (``time-aware``, ``classical``, ``frozen``).

    Returns
    -------
    list of (title, path) tuples
    """
    pages: list[tuple[str, Path]] = []
    for panel_title, stem in PANEL_ORDER:
        for label in model_labels:
            path = outputs_dir / f"{stem}_{label}.png"
            title = f"{panel_title}  |  {label}"
            pages.append((title, path))
    return pages


def compose(output_pdf: Path, outputs_dir: Path, model_labels: list[str]) -> Path:
    """Bundle expected panels into a multi-page PDF.

    Parameters
    ----------
    output_pdf : Path
        Destination PDF.
    outputs_dir : Path
        Directory with per-panel PNGs.
    model_labels : list of str
        Models to interleave.

    Returns
    -------
    Path
        Destination PDF.
    """
    output_pdf.parent.mkdir(parents=True, exist_ok=True)
    pages = collect_pages(outputs_dir, model_labels)
    written = 0
    skipped: list[str] = []
    with PdfPages(output_pdf) as pdf:
        for title, path in pages:
            if not path.exists():
                skipped.append(f"{title} -> {path.name}")
                continue
            _add_image_page(pdf, title, path)
            written += 1
    print(f"wrote {output_pdf} ({written} pages)")
    if skipped:
        print("skipped (file missing):")
        for s in skipped:
            print(f"  - {s}")
    return output_pdf


def main() -> None:
    """CLI entry point."""
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--output", type=Path, default=OUTPUTS / "alfi_fig3b_bundle.pdf")
    p.add_argument("--outputs-dir", type=Path, default=OUTPUTS)
    p.add_argument(
        "--model-labels",
        nargs="+",
        default=["time-aware"],
        help="One or more model tags matching panel filenames.",
    )
    args = p.parse_args()
    compose(args.output, args.outputs_dir, args.model_labels)


if __name__ == "__main__":
    main()
