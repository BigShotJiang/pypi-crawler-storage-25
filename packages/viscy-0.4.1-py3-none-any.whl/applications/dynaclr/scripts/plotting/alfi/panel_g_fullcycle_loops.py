"""Panel 3b-vii (diagnostic): full-cycle cell trajectories on PHATE.

A "full cycle" cell here is one whose parent track both **starts** and
**ends** in a mitosis run — meaning we observed the cell's own birth
division and its subsequent dividing division in the same field of view.
In the ALFI zarrs only HeLa has such cells (16 of 20 events at k=5);
RPE1 and U2OS parent tracks never begin with mitosis in the available
FOVs.

Layout:
- One combined PHATE axis per cell line with full-cycle cells.
- Each full-cycle cell's trajectory (pre + mit + post, lineage-stitched)
  is drawn on top of a gray background of all cells.
- Trajectories are colored by relative frame position (viridis) so the
  reader can read the progression: mitosis_start of the parent →
  interphase body → mitosis_end before division → daughter mitosis →
  daughter interphase.

This is a visualization diagnostic, not a quantitative panel. It
answers the reviewer's question "does a full-cycle cell traverse a
coherent loop in embedding space?" without making a numeric claim.
"""

from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np

from _common import (
    CELL_LINE_ZARRS,
    DEFAULT_EMB_ROOT,
    DEFAULT_OUTPUT_DIR,
    MITOSIS_LABEL,
    ensure_outdir,
    extract_division_windows,
    load_cell_line,
    window_trajectory_rows,
)


def _draw_track(ax, phate: np.ndarray, row_indices: np.ndarray) -> None:
    """Plot one lineage trajectory in viridis color order."""
    xy = phate[row_indices]
    if len(xy) < 2:
        return
    t_local = np.linspace(0.0, 1.0, len(xy))
    ax.plot(xy[:, 0], xy[:, 1], "-", color="#111", linewidth=0.8, alpha=0.45, zorder=2)
    ax.scatter(xy[:, 0], xy[:, 1], c=t_local, cmap="viridis", s=14, zorder=3, linewidths=0)
    ax.scatter(xy[0, 0], xy[0, 1], marker="s", s=55, facecolor="none", edgecolor="#4f7dc0", linewidths=1.5, zorder=4)
    ax.scatter(xy[-1, 0], xy[-1, 1], marker="s", s=55, facecolor="none", edgecolor="#e03b3b", linewidths=1.5, zorder=4)


def _plot_cell_line(ax, adata, windows, phate: np.ndarray, title: str) -> None:
    """Overlay all full-cycle trajectories for one cell line."""
    ax.scatter(phate[:, 0], phate[:, 1], s=2, c="#e0e0e0", alpha=0.5, linewidths=0)
    mit_mask = adata.obs["cell_division_state"].to_numpy() == MITOSIS_LABEL
    ax.scatter(phate[mit_mask, 0], phate[mit_mask, 1], s=3, c="#f3c0c0", alpha=0.6, linewidths=0)

    if windows.empty:
        ax.text(0.5, 0.5, "no full-cycle cells", ha="center", va="center", transform=ax.transAxes, fontsize=10, color="#555")
    else:
        for _, w in windows.iterrows():
            _draw_track(ax, phate, window_trajectory_rows(w))

    ax.set_title(f"{title} (n={len(windows)} full-cycle)", fontsize=10)
    ax.set_xticks([])
    ax.set_yticks([])
    for spine in ax.spines.values():
        spine.set_visible(False)


def plot(
    emb_root: Path,
    output_dir: Path,
    k_flank: int = 5,
    phate_key: str = "X_phate_combined",
    model_label: str = "time-aware",
) -> Path:
    """Render one combined-PHATE axis per cell line with all full-cycle loops.

    Parameters
    ----------
    emb_root : Path
        Root embedding directory.
    output_dir : Path
        Destination directory.
    k_flank : int
        Interphase flank length.
    phate_key : str
        ``obsm`` key to visualize.
    model_label : str
        Tag appended to filename.

    Returns
    -------
    Path
        Saved PNG.
    """
    lines = list(CELL_LINE_ZARRS)
    fig, axes = plt.subplots(1, len(lines), figsize=(4.3 * len(lines), 4.2), constrained_layout=True)
    if len(lines) == 1:
        axes = [axes]

    for ax, line in zip(axes, lines):
        adata = load_cell_line(line, emb_root=emb_root)
        windows = extract_division_windows(adata, k_flank=k_flank, require_full_cycle=True)
        phate = np.asarray(adata.obsm[phate_key])
        _plot_cell_line(ax, adata, windows, phate, title=line)

    fig.suptitle(f"Full-cycle cell trajectories on combined PHATE ({model_label})", fontsize=12)

    ensure_outdir(output_dir)
    out = output_dir / f"panel_3bvii_fullcycle_{model_label}.png"
    fig.savefig(out, dpi=200)
    plt.close(fig)
    return out


def main() -> None:
    """CLI entry point."""
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--emb-root", type=Path, default=DEFAULT_EMB_ROOT)
    p.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT_DIR)
    p.add_argument("--k-flank", type=int, default=5)
    p.add_argument("--phate-key", default="X_phate_combined")
    p.add_argument("--model-label", default="time-aware")
    args = p.parse_args()
    out = plot(
        args.emb_root,
        args.output_dir,
        k_flank=args.k_flank,
        phate_key=args.phate_key,
        model_label=args.model_label,
    )
    print(f"wrote {out}")


if __name__ == "__main__":
    main()
