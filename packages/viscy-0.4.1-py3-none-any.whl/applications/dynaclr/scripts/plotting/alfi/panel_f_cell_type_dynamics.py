"""Panel 3b-vi: cell-type × condition separation from embedding and dynamics.

Layout (1x3 grid):

- Left: combined ``X_phate_combined`` across all three ALFI zarrs,
  one glyph per cell × timepoint. Color = cell line, marker shape =
  perturbation. Whether cell types separate is readable here; whether
  drug state contributes is readable from the marker-shape distribution
  inside the U2OS cloud.

- Middle: per-event dynamics scatter — peak displacement vs mitosis
  duration. Color = cell line, marker = perturbation.

- Right: 1-D strip plot of mitosis duration with the four groups
  (``HeLa-DMSO``, ``RPE1-untreated``, ``U2OS-DMSO``, ``U2OS-MLN8237``)
  stacked vertically. This is the panel that directly answers the
  confound question: is the cross-cell-line separation a cell-type
  effect, a drug effect, or both? Individual points are drawn so the
  reader can see the n=3 U2OS-DMSO case without the boxplot hiding it.

A small stacked bar on the suptitle band summarizes the per-cell-line
perturbation composition so the asymmetric treatment design is not
hidden: HeLa/RPE1 are controls only; U2OS is the only cell line with
both DMSO and MLN8237.

For every dynamics feature present in the CSV, medians per
``(cell_line, perturbation)`` pair are also printed to stdout so the
numbers that anchor the paper narrative are always visible.
"""

from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from _common import (
    CELL_LINE_COLORS,
    CELL_LINE_ZARRS,
    DEFAULT_EMB_ROOT,
    DEFAULT_OUTPUT_DIR,
    ensure_outdir,
    extract_division_windows,
    get_features,
    interphase_reference,
    load_cell_line,
    window_trajectory_rows,
)

PERTURBATION_MARKERS: dict[str, str] = {
    "DMSO": "o",
    "untreated": "o",
    "MLN8237": "X",
}


def dynamics_features(adata, features: np.ndarray, windows: pd.DataFrame) -> pd.DataFrame:
    """Compute per-event dynamics features.

    Parameters
    ----------
    adata : AnnData
        Embeddings container (used for the interphase reference).
    features : np.ndarray
        Aligned feature matrix.
    windows : pandas.DataFrame
        Output of :func:`extract_division_windows`.

    Returns
    -------
    pandas.DataFrame
        Columns: ``parent_track_id``, ``perturbation``,
        ``mitosis_duration``, ``peak_displacement``, ``arc_length``,
        ``closure``.
    """
    if windows.empty:
        return pd.DataFrame(
            columns=[
                "parent_track_id", "perturbation", "mitosis_duration",
                "peak_displacement", "arc_length",
            ]
        )
    ref = interphase_reference(adata, features)
    rows = []
    for _, w in windows.iterrows():
        traj = features[window_trajectory_rows(w)]
        arc = float(np.linalg.norm(np.diff(traj, axis=0), axis=1).sum())
        peak = float(np.linalg.norm(features[w["mit_rows"]] - ref, axis=1).max())
        rows.append(
            {
                "parent_track_id": w["parent_track_id"],
                "perturbation": w["perturbation"],
                "mitosis_duration": int(len(w["mit_rows"])),
                "peak_displacement": peak,
                "arc_length": arc,
            }
        )
    return pd.DataFrame(rows)


def _grouped_iter(df: pd.DataFrame):
    """Yield ``(cell_line, perturbation, color, marker, sub_df)`` in a deterministic order.

    Color follows cell line; marker follows perturbation (filled circle
    for baseline controls, ``X`` for MLN8237). Order is HeLa-DMSO,
    RPE1-untreated, U2OS-DMSO, U2OS-MLN8237 so legends read the same
    way every time.
    """
    order = [
        ("HeLa", "DMSO"),
        ("RPE1", "untreated"),
        ("U2OS", "DMSO"),
        ("U2OS", "MLN8237"),
    ]
    for line, pert in order:
        color = CELL_LINE_COLORS[line]
        marker = PERTURBATION_MARKERS.get(pert, "o")
        sub = df[(df["cell_line"] == line) & (df["perturbation"] == pert)]
        if sub.empty:
            continue
        yield line, pert, color, marker, sub


def _plot_combined_phate(
    ax, phate_stack: np.ndarray, line_stack: np.ndarray, pert_stack: np.ndarray
) -> None:
    """Scatter the combined PHATE, colored by cell line with marker = perturbation."""
    drawn_labels: set[str] = set()
    for line, pert, color, marker, _ in _grouped_iter(
        pd.DataFrame({"cell_line": line_stack, "perturbation": pert_stack})
        .assign(_i=np.arange(len(line_stack)))
    ):
        # Re-lookup rows since the helper returns the dataframe's view.
        m = (line_stack == line) & (pert_stack == pert)
        if not m.any():
            continue
        label = f"{line}-{pert} (n={int(m.sum())})"
        ax.scatter(
            phate_stack[m, 0],
            phate_stack[m, 1],
            s=3,
            c=color,
            marker=marker,
            alpha=0.5,
            linewidths=0,
            label=label,
        )
        drawn_labels.add(label)
    ax.set_title("Combined PHATE — cell line (color) × perturbation (shape)", fontsize=10)
    ax.set_xticks([])
    ax.set_yticks([])
    for spine in ax.spines.values():
        spine.set_visible(False)
    ax.legend(fontsize=8, frameon=False, markerscale=2, loc="best")


def _plot_feature_scatter(ax, feats: pd.DataFrame, x: str, y: str, title: str) -> None:
    """Per-event scatter colored by cell line, marker = perturbation."""
    for line, pert, color, marker, sub in _grouped_iter(feats):
        label = f"{line}-{pert} (n={len(sub)})"
        ax.scatter(
            sub[x],
            sub[y],
            s=60,
            c=color,
            marker=marker,
            alpha=0.85,
            edgecolors="#222",
            linewidths=0.6,
            label=label,
        )
    ax.set_xlabel(x.replace("_", " "))
    ax.set_ylabel(y.replace("_", " "))
    ax.set_title(title, fontsize=10)
    ax.grid(linestyle=":", linewidth=0.5, alpha=0.5)
    ax.legend(fontsize=8, frameon=False)


def _plot_strip(ax, feats: pd.DataFrame, feature: str) -> None:
    """One-column strip plot: each (cell_line, perturbation) group on its own row."""
    groups = list(_grouped_iter(feats))
    rng = np.random.default_rng(0)
    ytick_pos: list[float] = []
    ytick_labels: list[str] = []

    for idx, (line, pert, color, marker, sub) in enumerate(groups):
        y_base = float(len(groups) - 1 - idx)
        jitter = rng.uniform(-0.16, 0.16, size=len(sub))
        ax.scatter(
            sub[feature],
            np.full(len(sub), y_base) + jitter,
            s=55,
            c=color,
            marker=marker,
            alpha=0.85,
            edgecolors="#222",
            linewidths=0.6,
        )
        med = float(sub[feature].median())
        ax.plot(
            [med, med],
            [y_base - 0.32, y_base + 0.32],
            color="#111",
            linewidth=2,
            solid_capstyle="butt",
        )
        ytick_pos.append(y_base)
        ytick_labels.append(f"{line}-{pert}\nn={len(sub)}")

    ax.set_yticks(ytick_pos)
    ax.set_yticklabels(ytick_labels, fontsize=9)
    ax.set_xlabel(feature.replace("_", " "))
    ax.set_title(f"{feature.replace('_', ' ')} per group (median bar)", fontsize=10)
    ax.grid(axis="x", linestyle=":", linewidth=0.5, alpha=0.5)
    ax.set_axisbelow(True)


def _format_medians(feats: pd.DataFrame) -> pd.DataFrame:
    """Return a ``(cell_line, perturbation)`` median table across all numeric features."""
    numeric = ["mitosis_duration", "peak_displacement", "arc_length"]
    agg = (
        feats.groupby(["cell_line", "perturbation"], observed=True)[numeric]
        .agg(["median", "count"])
    )
    return agg


def plot(
    emb_root: Path,
    output_dir: Path,
    embedding_key: str = "X",
    n_components: int | None = None,
    k_flank: int = 5,
    phate_key: str = "X_phate_combined",
    strip_feature: str = "mitosis_duration",
    model_label: str = "time-aware",
) -> tuple[Path, Path]:
    """Render the cell-type × condition figure and write the dynamics CSV.

    Parameters
    ----------
    emb_root : Path
        Root embedding directory.
    output_dir : Path
        Destination directory.
    embedding_key : str
        Feature source for dynamics features.
    n_components : int or None
        Optional feature truncation.
    k_flank : int
        Interphase flank length.
    phate_key : str
        ``obsm`` key for the combined PHATE panel.
    strip_feature : str
        Dynamics column used on the strip panel.
    model_label : str
        Tag appended to filenames.

    Returns
    -------
    (Path, Path)
        Figure PNG, dynamics-feature CSV.
    """
    phate_parts: list[np.ndarray] = []
    line_parts: list[np.ndarray] = []
    pert_parts: list[np.ndarray] = []
    feat_parts: list[pd.DataFrame] = []

    for line in CELL_LINE_ZARRS:
        adata = load_cell_line(line, emb_root=emb_root)
        phate_parts.append(np.asarray(adata.obsm[phate_key]))
        line_parts.append(np.array([line] * adata.n_obs))
        pert_parts.append(adata.obs["perturbation"].astype(str).to_numpy())
        feats = get_features(adata, embedding_key, n_components=n_components)
        windows = extract_division_windows(adata, k_flank=k_flank)
        d = dynamics_features(adata, feats, windows).assign(cell_line=line)
        feat_parts.append(d)

    phate_stack = np.concatenate(phate_parts, axis=0)
    line_stack = np.concatenate(line_parts, axis=0)
    pert_stack = np.concatenate(pert_parts, axis=0)
    merged = pd.concat(feat_parts, ignore_index=True) if feat_parts else pd.DataFrame()

    fig = plt.figure(figsize=(16.5, 4.8), constrained_layout=True)
    gs = fig.add_gridspec(1, 3, width_ratios=[1.2, 1.0, 1.0])
    ax_phate = fig.add_subplot(gs[0, 0])
    ax_scatter = fig.add_subplot(gs[0, 1])
    ax_strip = fig.add_subplot(gs[0, 2])
    _plot_combined_phate(ax_phate, phate_stack, line_stack, pert_stack)
    if not merged.empty:
        _plot_feature_scatter(
            ax_scatter, merged,
            x="mitosis_duration", y="peak_displacement",
            title="peak displacement vs mitosis duration",
        )
        _plot_strip(ax_strip, merged, feature=strip_feature)

    fig.suptitle(
        f"Cell type × condition — embedding and dynamics ({model_label})", fontsize=12
    )

    ensure_outdir(output_dir)
    fig_path = output_dir / f"panel_3bvi_cell_type_{model_label}.png"
    csv_path = output_dir / f"panel_3bvi_dynamics_features_{model_label}.csv"
    fig.savefig(fig_path, dpi=200)
    plt.close(fig)
    merged.to_csv(csv_path, index=False)

    medians = _format_medians(merged)
    print("per-group medians:")
    print(medians.to_string())
    return fig_path, csv_path


def main() -> None:
    """CLI entry point."""
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--emb-root", type=Path, default=DEFAULT_EMB_ROOT)
    p.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT_DIR)
    p.add_argument("--embedding-key", default="X")
    p.add_argument("--n-components", type=int, default=0)
    p.add_argument("--k-flank", type=int, default=5)
    p.add_argument("--phate-key", default="X_phate_combined")
    p.add_argument(
        "--strip-feature",
        default="mitosis_duration",
        choices=["mitosis_duration", "peak_displacement", "arc_length"],
    )
    p.add_argument("--model-label", default="time-aware")
    args = p.parse_args()

    fig_path, csv_path = plot(
        args.emb_root,
        args.output_dir,
        embedding_key=args.embedding_key,
        n_components=args.n_components if args.n_components > 0 else None,
        k_flank=args.k_flank,
        phate_key=args.phate_key,
        strip_feature=args.strip_feature,
        model_label=args.model_label,
    )
    print(f"wrote {fig_path}")
    print(f"wrote {csv_path}")


if __name__ == "__main__":
    main()
