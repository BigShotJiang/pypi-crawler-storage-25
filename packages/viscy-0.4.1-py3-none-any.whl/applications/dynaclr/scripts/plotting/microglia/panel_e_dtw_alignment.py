"""DTW alignment of treatment-cell trajectories to an untreated reference.

For each cell tracked across time, treat the cell's per-frame DynaCLR
embedding as a time-series. Build an untreated *consensus* trajectory by
averaging untreated cells frame-by-frame, then for every query cell run
DTW against that reference. Two readouts:

- **Warping cost** = mean local cosine distance along the optimal path.
  Low = trajectory shape similar to the reference. High = trajectory
  shape diverges from untreated.
- **Mean warping-path slope** = how the query's time axis maps to the
  reference's time axis. Slope ≈ 1 → same pace. Slope < 1 → query is
  *slower* than reference (one query frame maps to multiple reference
  frames). Slope > 1 → query is *faster*.

Per-condition aggregation answers:
  1. Do treated cells diverge from the untreated baseline trajectory?
  2. Do they progress at different paces?

DynaCLR-only — no real-space speed, no clustering, no labels except for
the reference-builder (using untreated cells; treatment labels are not
used downstream for the DTW itself).
"""

from __future__ import annotations

import argparse
import warnings
from pathlib import Path

import anndata as ad
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from _common import CONDITION_COLORS, ensure_outdir


def build_untreated_reference(
    adata: ad.AnnData,
    untreated_label: str,
    n_top_tracks: int,
    time_key: str,
) -> tuple[np.ndarray, np.ndarray]:
    """Build a consensus untreated trajectory: mean embedding per timepoint.

    Selects the ``n_top_tracks`` longest untreated tracks, snaps each to its
    actual timepoints, and averages by ``t``. Returns the consensus
    embedding sequence and the timepoint grid it was computed on.

    Parameters
    ----------
    adata : AnnData
        Embedding object.
    untreated_label : str
        Value of ``adata.obs.perturbation`` flagging the untreated subset.
    n_top_tracks : int
        Use the ``n`` longest untreated tracks for the consensus.
    time_key : str
        Time column for diagnostic reporting (not used for the consensus
        index — that uses ``t`` directly).

    Returns
    -------
    ref_emb : np.ndarray, shape (T, D)
        Mean L2-normalized embedding per timepoint.
    ref_times : np.ndarray, shape (T,)
        Integer timepoint grid for the reference.
    """
    feats = np.asarray(adata.X, dtype=np.float32)
    norms = np.linalg.norm(feats, axis=1, keepdims=True)
    norms[norms == 0] = 1.0
    feats = feats / norms

    obs = adata.obs[["fov_name", "track_id", "t", "perturbation", time_key]].reset_index(drop=True)
    obs["row"] = np.arange(len(obs))

    untreated = obs[obs["perturbation"] == untreated_label]
    track_lengths = untreated.groupby(["fov_name", "track_id"], observed=True).size().sort_values(ascending=False)
    top = track_lengths.head(n_top_tracks).index.tolist()

    rows_per_t: dict[int, list[np.ndarray]] = {}
    for fov, tid in top:
        sub = untreated[(untreated["fov_name"] == fov) & (untreated["track_id"] == tid)].sort_values("t")
        for _, r in sub.iterrows():
            rows_per_t.setdefault(int(r["t"]), []).append(feats[int(r["row"])])

    times_sorted = sorted(rows_per_t)
    ref_emb = np.stack([np.mean(np.stack(rows_per_t[t], axis=0), axis=0) for t in times_sorted], axis=0)
    norms = np.linalg.norm(ref_emb, axis=1, keepdims=True)
    norms[norms == 0] = 1.0
    ref_emb = ref_emb / norms
    return ref_emb.astype(np.float32), np.array(times_sorted, dtype=np.int32)


def _cosine_distance_matrix(query: np.ndarray, ref: np.ndarray) -> np.ndarray:
    """Pairwise cosine distance between rows of L2-normalized arrays."""
    return 1.0 - query @ ref.T


def dtw_align(query: np.ndarray, ref: np.ndarray, band_frac: float) -> tuple[float, np.ndarray]:
    """Itakura-style constrained DTW.

    The band is defined relative to the **rectangle's diagonal** so that
    queries shorter than the reference can still warp to the corner:
    ``|i * n / m - j| ≤ band_cells``. ``band_frac`` sets ``band_cells = max(1, band_frac * max(m, n))``.

    Returns:
      - **path-length-normalized cost** (mean local cosine distance along
        the optimal alignment),
      - alignment path as an (L, 2) int array of (i, j) pairs.
    """
    m, n = len(query), len(ref)
    cost_local = _cosine_distance_matrix(query, ref)

    band = max(1, int(band_frac * max(m, n)))
    slope = n / max(m, 1)

    INF = 1e9
    D = np.full((m + 1, n + 1), INF, dtype=np.float32)
    D[0, 0] = 0.0

    for i in range(1, m + 1):
        j_center = i * slope
        j_lo = max(1, int(np.floor(j_center)) - band)
        j_hi = min(n, int(np.ceil(j_center)) + band)
        # ensure (m, n) is reachable: the last row must include j = n
        if i == m:
            j_hi = n
        for j in range(j_lo, j_hi + 1):
            D[i, j] = cost_local[i - 1, j - 1] + min(D[i - 1, j], D[i, j - 1], D[i - 1, j - 1])

    if not np.isfinite(D[m, n]):
        return float("nan"), np.empty((0, 2), dtype=np.int32)

    # backtrack
    path = []
    i, j = m, n
    while i > 0 and j > 0:
        path.append((i - 1, j - 1))
        choices = [D[i - 1, j - 1], D[i - 1, j], D[i, j - 1]]
        k = int(np.argmin(choices))
        if k == 0:
            i, j = i - 1, j - 1
        elif k == 1:
            i = i - 1
        else:
            j = j - 1
    path.reverse()
    path_arr = np.array(path, dtype=np.int32)

    if len(path_arr) == 0:
        return float("nan"), path_arr
    accumulated = float(D[m, n])
    return accumulated / len(path_arr), path_arr


def warping_slope(path: np.ndarray) -> float:
    """Linear-fit slope dj/di of the alignment path.

    Slope < 1: query is slower than reference (multiple ref frames per query frame).
    Slope > 1: query is faster than reference.
    Slope ≈ 1: same pace.
    """
    if len(path) < 2:
        return float("nan")
    i, j = path[:, 0].astype(np.float32), path[:, 1].astype(np.float32)
    var_i = float(np.var(i))
    if var_i < 1e-9:
        return float("nan")
    return float(np.cov(i, j, ddof=0)[0, 1] / var_i)


def query_track(
    adata: ad.AnnData,
    feats: np.ndarray,
    fov: str,
    track_id: int,
) -> np.ndarray | None:
    """Pull a single L2-normalized track sequence ordered by ``t``."""
    sub = adata.obs[(adata.obs["fov_name"] == fov) & (adata.obs["track_id"] == track_id)]
    if len(sub) == 0:
        return None
    sub = sub.sort_values("t")
    rows = sub.index.astype(int).to_numpy()
    return feats[rows]


def plot_kde_by_condition(
    df: pd.DataFrame,
    value_col: str,
    title: str,
    axis_label: str,
) -> plt.Figure:
    """Per-condition KDE-style density of a DTW readout."""
    fig, ax = plt.subplots(figsize=(8.0, 4.5), constrained_layout=True)
    qx0, qx1 = float(df[value_col].quantile(0.005)), float(df[value_col].quantile(0.995))
    for c in CONDITION_COLORS:
        sub = df[df["perturbation"] == c]
        if len(sub) < 30:
            continue
        h, edges = np.histogram(sub[value_col].to_numpy(), bins=120, range=(qx0, qx1), density=True)
        x = 0.5 * (edges[:-1] + edges[1:])
        kernel = np.exp(-0.5 * np.linspace(-3, 3, 9) ** 2)
        kernel /= kernel.sum()
        h_s = np.convolve(h, kernel, mode="same")
        ax.plot(x, h_s, "-", color=CONDITION_COLORS[c], linewidth=1.6, label=f"{c} (n={len(sub)})")
    ax.set_xlabel(axis_label)
    ax.set_ylabel("density")
    ax.set_title(title)
    ax.legend(frameon=False, fontsize=8)
    return fig


def plot_cost_vs_slope(df: pd.DataFrame) -> plt.Figure:
    """Joint scatter of (cost, slope) per condition."""
    cond_set = [c for c in CONDITION_COLORS if c in df["perturbation"].unique()]
    fig, axes = plt.subplots(
        1, len(cond_set), figsize=(3.6 * len(cond_set), 3.8), constrained_layout=True, sharex=True, sharey=True
    )
    if len(cond_set) == 1:
        axes = np.array([axes])
    qx0, qx1 = float(df["cost"].quantile(0.01)), float(df["cost"].quantile(0.99))
    qy0, qy1 = float(df["slope"].quantile(0.01)), float(df["slope"].quantile(0.99))
    for ax, c in zip(axes, cond_set):
        sub = df[df["perturbation"] == c]
        ax.hexbin(
            sub["cost"].to_numpy(),
            sub["slope"].to_numpy(),
            gridsize=30,
            extent=(qx0, qx1, qy0, qy1),
            cmap="magma",
            mincnt=1,
        )
        ax.axhline(1.0, color="white", linewidth=0.6, linestyle="--")
        ax.set_title(f"{c} (n={len(sub)})", fontsize=9)
        ax.set_xlabel("DTW cost (mean cosine distance)")
    axes[0].set_ylabel("warping slope (1.0 = same pace)")
    fig.suptitle("DTW cost vs. warping slope, per condition", y=1.04)
    return fig


def run(
    zarr_path: Path,
    output_dir: Path,
    untreated_label: str,
    n_reference_tracks: int,
    n_query_per_condition: int,
    min_track_length: int,
    band_frac: float,
    time_key: str,
    seed: int,
) -> list[Path]:
    """End-to-end DTW alignment per condition."""
    with warnings.catch_warnings():
        warnings.filterwarnings("ignore", message="Observation names are not unique")
        adata = ad.read_zarr(zarr_path)
    adata.obs.index = pd.RangeIndex(adata.n_obs).astype(str)
    print(f"loaded {zarr_path.name}: n_obs={adata.n_obs}")

    print(f"\n[1/3] building untreated consensus from top {n_reference_tracks} tracks")
    ref_emb, ref_times = build_untreated_reference(adata, untreated_label, n_reference_tracks, time_key)
    print(f"reference: {len(ref_emb)} timepoints, embedding dim {ref_emb.shape[1]}")
    print(f"timepoint range: t = [{int(ref_times.min())}, {int(ref_times.max())}]")

    feats = np.asarray(adata.X, dtype=np.float32)
    norms = np.linalg.norm(feats, axis=1, keepdims=True)
    norms[norms == 0] = 1.0
    feats = feats / norms

    print(f"\n[2/3] sampling {n_query_per_condition} query tracks per condition (length ≥ {min_track_length})")
    rng = np.random.default_rng(seed)
    obs = adata.obs[["fov_name", "track_id", "perturbation", "t"]].reset_index(drop=True)
    track_index = obs.groupby(["fov_name", "track_id", "perturbation"], observed=True).size().reset_index(name="length")
    eligible = track_index[track_index["length"] >= min_track_length]

    queries: list[tuple[str, str, int]] = []
    for c in CONDITION_COLORS:
        pool = eligible[eligible["perturbation"] == c]
        if len(pool) == 0:
            print(f"  {c}: no tracks ≥ {min_track_length} — skipped")
            continue
        n_pick = min(n_query_per_condition, len(pool))
        picks = pool.sample(n=n_pick, random_state=seed)
        for _, r in picks.iterrows():
            queries.append((c, r["fov_name"], int(r["track_id"])))
        print(f"  {c}: {n_pick} queries (pool={len(pool)})")

    print(f"\n[3/3] running DTW: {len(queries)} alignments (band={band_frac:.2f})")
    rows = []
    for k, (c, fov, tid) in enumerate(queries):
        if k > 0 and k % 200 == 0:
            print(f"  {k}/{len(queries)} done")
        q = query_track(adata, feats, fov, tid)
        if q is None or len(q) < 2:
            continue
        cost, path = dtw_align(q, ref_emb, band_frac)
        slope = warping_slope(path)
        rows.append(
            {"perturbation": c, "fov_name": fov, "track_id": tid, "n_frames_query": int(len(q)), "cost": float(cost), "slope": float(slope)}
        )
    df = pd.DataFrame(rows)

    ensure_outdir(output_dir)
    paths: list[Path] = []

    csv = output_dir / "dtw_alignment_per_query.csv"
    df.to_csv(csv, index=False)
    paths.append(csv)

    summary = (
        df.groupby("perturbation", observed=True)
        .agg(
            n=("cost", "size"),
            median_cost=("cost", "median"),
            mean_cost=("cost", "mean"),
            median_slope=("slope", "median"),
            mean_slope=("slope", "mean"),
        )
        .reset_index()
    )
    print()
    print("### DTW alignment summary per condition")
    print(summary.round(4).to_markdown(index=False))
    summary_csv = output_dir / "dtw_alignment_summary.csv"
    summary.to_csv(summary_csv, index=False)
    paths.append(summary_csv)

    fig_cost = plot_kde_by_condition(df, "cost", "DTW cost vs. untreated reference, per condition", "DTW cost (mean cosine distance along path)")
    p = output_dir / "dtw_cost_kde.png"
    fig_cost.savefig(p, dpi=200)
    plt.close(fig_cost)
    paths.append(p)

    fig_slope = plot_kde_by_condition(df, "slope", "Warping slope vs. untreated reference (1.0 = same pace)", "warping slope (dj/di)")
    p = output_dir / "dtw_slope_kde.png"
    fig_slope.savefig(p, dpi=200)
    plt.close(fig_slope)
    paths.append(p)

    fig_joint = plot_cost_vs_slope(df)
    p = output_dir / "dtw_cost_vs_slope.png"
    fig_joint.savefig(p, dpi=200)
    plt.close(fig_joint)
    paths.append(p)

    return paths


def main() -> None:
    """CLI entry point."""
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--zarr", type=Path, required=True)
    p.add_argument("--output-dir", type=Path, required=True)
    p.add_argument("--untreated-label", default="untreated")
    p.add_argument("--n-reference-tracks", type=int, default=50)
    p.add_argument("--n-query-per-condition", type=int, default=200)
    p.add_argument("--min-track-length", type=int, default=30)
    p.add_argument(
        "--band-frac",
        type=float,
        default=0.2,
        help="Sakoe-Chiba band as fraction of max(m,n) (default 0.2 = ±20%%).",
    )
    p.add_argument("--time-key", default="hours_post_perturbation")
    p.add_argument("--seed", type=int, default=0)
    args = p.parse_args()

    out = run(
        args.zarr,
        args.output_dir,
        untreated_label=args.untreated_label,
        n_reference_tracks=args.n_reference_tracks,
        n_query_per_condition=args.n_query_per_condition,
        min_track_length=args.min_track_length,
        band_frac=args.band_frac,
        time_key=args.time_key,
        seed=args.seed,
    )
    for p_ in out:
        print(f"wrote {p_}")


if __name__ == "__main__":
    main()
