"""Panel E follow-up: characterize Leiden clusters by motility.

Loads the labels CSV from a previous Panel E run, applies a minimum-size
threshold to drop trace clusters, and asks whether the surviving "dominant"
clusters differ in real-space cell motility.

Outputs (all written to ``--output-dir``)
-----------------------------------------
- A markdown / CSV table: cluster_id, n_cells, %_total, mean_speed,
  median_speed, mean_persistence, mean_msd_5, %_amoeboid_by_TFV,
  top_condition_pct.
- ``phate_by_cluster.png`` — PHATE colored by dominant cluster id, trace
  clusters greyed out.
- ``phate_by_speed.png`` — PHATE colored by real-space centroid speed
  (continuous gradient).
- ``phate_by_embedding_speed.png`` — same PHATE, colored by per-frame
  embedding-space velocity (cosine angular speed in radians/hour).
- ``speed_per_cluster_violin.png`` — per-cluster speed distribution
  (dominant clusters only).

The combination answers two distinct questions: do clusters separate by
motility (table + violin), and does motility have a spatial gradient on
the manifold (PHATE overlays)?
"""

from __future__ import annotations

import argparse
import warnings
from pathlib import Path

import anndata as ad
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from _common import CONDITION_COLORS, attach_phate_parquet, ensure_outdir
from behavioral_states import TFVConfig, compute_tfv
from panel_f_realspace_velocity import compute_realspace_speed


def _embedding_angular_speed(adata: ad.AnnData, time_key: str) -> np.ndarray:
    """Per-frame angular speed on the L2-normalized embedding (radians/hour).

    Uses central difference: angle between f(t-1) and f(t+1) divided by the
    elapsed time. Endpoints fall back to forward/backward differences. This
    matches the geometry the model was trained on (NT-Xent on a hypersphere)
    better than ambient-Euclidean velocity.
    """
    feats = np.asarray(adata.X, dtype=np.float32)
    norms = np.linalg.norm(feats, axis=1, keepdims=True)
    norms[norms == 0] = 1.0
    feats = feats / norms

    obs = adata.obs[["fov_name", "track_id", "t", time_key]].reset_index(drop=True)
    obs["row"] = np.arange(len(obs))
    speed = np.full(len(obs), np.nan, dtype=np.float32)
    for _, sub in obs.groupby(["fov_name", "track_id"], sort=False, observed=True):
        sub = sub.sort_values("t")
        rows = sub["row"].to_numpy()
        times = sub[time_key].to_numpy(dtype=np.float32)
        f = feats[rows]
        n = len(rows)
        if n < 2:
            continue
        if n == 2:
            cs = float(np.clip(np.dot(f[0], f[1]), -1.0, 1.0))
            ang = float(np.arccos(cs))
            dt = max(times[1] - times[0], 1e-6)
            speed[rows[0]] = ang / dt
            speed[rows[1]] = ang / dt
            continue
        cs = np.clip(np.einsum("ij,ij->i", f[2:], f[:-2]), -1.0, 1.0)
        ang = np.arccos(cs)
        dts = np.maximum(times[2:] - times[:-2], 1e-6)
        speed[rows[1:-1]] = ang / dts
        cs0 = float(np.clip(np.dot(f[0], f[1]), -1.0, 1.0))
        speed[rows[0]] = float(np.arccos(cs0)) / max(times[1] - times[0], 1e-6)
        cs1 = float(np.clip(np.dot(f[-1], f[-2]), -1.0, 1.0))
        speed[rows[-1]] = float(np.arccos(cs1)) / max(times[-1] - times[-2], 1e-6)
    return speed


def _attach_labels(adata: ad.AnnData, labels_csv: Path) -> str:
    """Merge a Panel E labels CSV onto ``adata.obs`` and return the cluster column."""
    lab = pd.read_csv(labels_csv)
    cluster_cols = [c for c in lab.columns if c.startswith("leiden_")]
    if not cluster_cols:
        raise ValueError(f"no leiden_* column in {labels_csv}")
    cluster_col = cluster_cols[0]

    obs_keys = list(zip(adata.obs["fov_name"].astype(str), adata.obs["track_id"].astype(int), adata.obs["t"].astype(int)))
    lab_keys = list(zip(lab["fov_name"].astype(str), lab["track_id"].astype(int), lab["t"].astype(int)))
    pos = {k: i for i, k in enumerate(lab_keys)}
    arr = np.full(adata.n_obs, -1, dtype=np.int32)
    src = lab[cluster_col].to_numpy()
    for j, k in enumerate(obs_keys):
        i = pos.get(k, -1)
        if i >= 0:
            arr[j] = int(src[i])
    adata.obs[cluster_col] = arr
    return cluster_col


def _dominant_clusters(labels: np.ndarray, min_fraction: float) -> list[int]:
    """Return cluster ids whose share of the total exceeds ``min_fraction``."""
    valid = labels[labels >= 0]
    counts = pd.Series(valid).value_counts()
    total = len(valid)
    keep = sorted(int(c) for c, n in counts.items() if n / total >= min_fraction)
    return keep


def build_cluster_table(
    labels: np.ndarray,
    real_speed: np.ndarray,
    emb_speed: np.ndarray,
    tfv: pd.DataFrame,
    perturbation: np.ndarray,
    keep: list[int],
) -> pd.DataFrame:
    """Per-cluster summary of motility, persistence, MSD, condition composition."""
    rows = []
    total = int(np.sum(labels >= 0))
    for c in keep:
        mask = labels == c
        n = int(mask.sum())
        rs = real_speed[mask]
        es = emb_speed[mask]
        persist = tfv["persistence"].to_numpy()[mask]
        msd5 = tfv["msd_5"].to_numpy()[mask]
        cond = perturbation[mask]
        cond_counts = pd.Series(cond).value_counts(normalize=True)
        top_cond = cond_counts.index[0]
        top_pct = 100.0 * cond_counts.iloc[0]
        rows.append(
            {
                "cluster": c,
                "n_cells": n,
                "%_of_total": 100.0 * n / total,
                "mean_real_speed_px_h": float(np.nanmean(rs)),
                "median_real_speed_px_h": float(np.nanmedian(rs)),
                "mean_emb_angular_speed_rad_h": float(np.nanmean(es)),
                "mean_persistence": float(np.nanmean(persist)),
                "mean_log_msd_5": float(np.nanmean(msd5)),
                "top_condition": top_cond,
                "top_condition_pct": float(top_pct),
            }
        )
    return pd.DataFrame(rows).sort_values("mean_real_speed_px_h").reset_index(drop=True)


def plot_phate_by_cluster(
    phate_xy: np.ndarray,
    labels: np.ndarray,
    keep: list[int],
    subsample: int,
    seed: int,
) -> plt.Figure:
    """PHATE colored by dominant cluster; trace clusters in light grey."""
    rng = np.random.default_rng(seed)
    valid = (labels >= 0) & ~np.isnan(phate_xy[:, 0])
    idx = np.where(valid)[0]
    if subsample < len(idx):
        idx = rng.choice(idx, size=subsample, replace=False)

    fig, ax = plt.subplots(figsize=(8.0, 7.0), constrained_layout=True)
    trace = ~np.isin(labels[idx], keep)
    if trace.any():
        ax.scatter(
            phate_xy[idx[trace], 0],
            phate_xy[idx[trace], 1],
            s=0.6,
            c="lightgrey",
            alpha=0.5,
            linewidths=0,
            label="trace (<threshold)",
        )
    cmap = plt.get_cmap("tab10", max(len(keep), 1))
    for i, c in enumerate(keep):
        mask = labels[idx] == c
        if not mask.any():
            continue
        ax.scatter(
            phate_xy[idx[mask], 0],
            phate_xy[idx[mask], 1],
            s=1.4,
            color=cmap(i),
            alpha=0.7,
            linewidths=0,
            label=f"cluster {c} (n={(labels == c).sum()})",
        )
    ax.set_xlabel("phate_0")
    ax.set_ylabel("phate_1")
    ax.set_title("PHATE colored by dominant Leiden clusters")
    leg = ax.legend(markerscale=4, frameon=False, fontsize=8, loc="best")
    for lh in leg.legend_handles:
        lh.set_alpha(1.0)
    return fig


def plot_phate_by_continuous(
    phate_xy: np.ndarray,
    values: np.ndarray,
    title: str,
    cbar_label: str,
    subsample: int,
    seed: int,
    cmap: str = "magma",
) -> plt.Figure:
    """PHATE scatter colored by a continuous value (e.g. speed)."""
    rng = np.random.default_rng(seed)
    valid = (~np.isnan(phate_xy[:, 0])) & np.isfinite(values)
    idx = np.where(valid)[0]
    if subsample < len(idx):
        idx = rng.choice(idx, size=subsample, replace=False)
    idx = rng.permutation(idx)

    v = values[idx]
    vmin = float(np.nanquantile(v, 0.02))
    vmax = float(np.nanquantile(v, 0.98))

    fig, ax = plt.subplots(figsize=(8.0, 7.0), constrained_layout=True)
    sc = ax.scatter(
        phate_xy[idx, 0],
        phate_xy[idx, 1],
        s=1.0,
        c=v,
        cmap=cmap,
        vmin=vmin,
        vmax=vmax,
        alpha=0.7,
        linewidths=0,
    )
    cbar = fig.colorbar(sc, ax=ax, shrink=0.8, pad=0.02)
    cbar.set_label(cbar_label)
    ax.set_xlabel("phate_0")
    ax.set_ylabel("phate_1")
    ax.set_title(title)
    return fig


def plot_speed_violin_per_cluster(
    labels: np.ndarray,
    real_speed: np.ndarray,
    keep: list[int],
    table: pd.DataFrame,
) -> plt.Figure:
    """Per-cluster real-space speed violin, ordered by table (slowest → fastest)."""
    order = table["cluster"].astype(int).tolist()
    cmap = plt.get_cmap("tab10", max(len(keep), 1))

    data = []
    colors = []
    xticklabels = []
    for c in order:
        sub = real_speed[labels == c]
        sub = sub[np.isfinite(sub)]
        if len(sub) == 0:
            continue
        data.append(sub)
        i = keep.index(c)
        colors.append(cmap(i))
        xticklabels.append(str(c))

    fig, ax = plt.subplots(figsize=(max(7.0, 1.0 * len(data)), 4.5), constrained_layout=True)
    parts = ax.violinplot(data, showmedians=True)
    for i, body in enumerate(parts["bodies"]):
        body.set_facecolor(colors[i])
        body.set_alpha(0.65)
    ax.set_xticks(range(1, len(data) + 1))
    ax.set_xticklabels(xticklabels)
    ax.set_xlabel("Leiden cluster (ordered by mean real-space speed)")
    ax.set_ylabel("real-space speed (px/hour)")
    q99 = float(np.nanquantile(real_speed[np.isfinite(real_speed)], 0.99))
    ax.set_ylim(0, q99)
    ax.set_title("Real-space speed per dominant cluster")
    return fig


def plot_condition_composition(
    labels: np.ndarray,
    perturbation: np.ndarray,
    keep: list[int],
    table: pd.DataFrame,
) -> plt.Figure:
    """Stacked bar of condition composition per dominant cluster."""
    order = table["cluster"].astype(int).tolist()
    conditions = [c for c in CONDITION_COLORS if c in np.unique(perturbation)]

    rows = []
    for c in order:
        mask = labels == c
        if not mask.any():
            continue
        cond_counts = pd.Series(perturbation[mask]).value_counts(normalize=True)
        rows.append({"cluster": c, **{cond: cond_counts.get(cond, 0.0) for cond in conditions}})
    df = pd.DataFrame(rows).set_index("cluster")

    fig, ax = plt.subplots(figsize=(max(7.0, 1.0 * len(df)), 4.5), constrained_layout=True)
    bottoms = np.zeros(len(df))
    x = np.arange(len(df))
    for cond in conditions:
        y = df[cond].to_numpy()
        ax.bar(x, y, bottom=bottoms, color=CONDITION_COLORS[cond], label=cond, edgecolor="white", linewidth=0.3)
        bottoms += y
    ax.set_xticks(x)
    ax.set_xticklabels([str(c) for c in df.index])
    ax.set_ylabel("condition fraction")
    ax.set_title("Condition composition per dominant cluster")
    ax.set_ylim(0, 1)
    ax.legend(frameon=False, fontsize=8, bbox_to_anchor=(1.02, 1), loc="upper left")
    return fig


def run(
    zarr_path: Path,
    labels_csv: Path,
    phate_parquet: Path,
    output_dir: Path,
    min_fraction: float,
    subsample: int,
    pixel_size_um: float | None,
    time_key: str,
    seed: int,
    window_frames: int,
) -> list[Path]:
    """Run the full follow-up analysis and write artifacts."""
    with warnings.catch_warnings():
        warnings.filterwarnings("ignore", message="Observation names are not unique")
        adata = ad.read_zarr(zarr_path)
    adata.obs.index = pd.RangeIndex(adata.n_obs).astype(str)
    print(f"loaded {zarr_path.name}: n_obs={adata.n_obs}")

    cluster_col = _attach_labels(adata, labels_csv)
    labels = adata.obs[cluster_col].to_numpy()
    keep = _dominant_clusters(labels, min_fraction)
    n_dominant = len(keep)
    n_total = int(np.sum(labels >= 0))
    n_kept = int(np.sum(np.isin(labels, keep)))
    print(
        f"clusters: {len(np.unique(labels[labels >= 0]))} total, "
        f"{n_dominant} dominant (≥{100*min_fraction:.1f}%) covering {100*n_kept/n_total:.1f}% of cells"
    )
    print(f"dominant cluster ids: {keep}")

    attach_phate_parquet(adata, phate_parquet, key="X_phate")
    phate_xy = adata.obsm["X_phate"]

    real_speed = compute_realspace_speed(adata, time_key, pixel_size_um)
    emb_speed = _embedding_angular_speed(adata, time_key)
    tfv = compute_tfv(adata.obs.reset_index(drop=True), TFVConfig(window_frames=window_frames, min_track_length=window_frames), time_key=time_key)
    perturbation = adata.obs["perturbation"].to_numpy()

    table = build_cluster_table(labels, real_speed, emb_speed, tfv, perturbation, keep)
    print()
    print("### Per-cluster motility summary (sorted by mean real-space speed)")
    print(table.round(3).to_markdown(index=False))

    ensure_outdir(output_dir)
    tag = labels_csv.stem.replace("panel_E_", "").replace("_labels", "")
    paths: list[Path] = []

    csv_path = output_dir / f"panel_E_followup_{tag}_table.csv"
    table.to_csv(csv_path, index=False)
    paths.append(csv_path)

    figures: list[tuple[str, plt.Figure]] = [
        ("phate_by_cluster", plot_phate_by_cluster(phate_xy, labels, keep, subsample, seed)),
        (
            "phate_by_real_speed",
            plot_phate_by_continuous(
                phate_xy, real_speed, "PHATE colored by real-space speed", "real-space speed (px/hour)", subsample, seed, "magma"
            ),
        ),
        (
            "phate_by_embedding_speed",
            plot_phate_by_continuous(
                phate_xy,
                emb_speed,
                "PHATE colored by embedding-space angular speed",
                "embedding speed (rad/hour)",
                subsample,
                seed,
                "viridis",
            ),
        ),
        ("speed_violin", plot_speed_violin_per_cluster(labels, real_speed, keep, table)),
        ("condition_composition", plot_condition_composition(labels, perturbation, keep, table)),
    ]

    for name, fig in figures:
        out = output_dir / f"panel_E_followup_{tag}_{name}.png"
        fig.savefig(out, dpi=200)
        plt.close(fig)
        paths.append(out)

    return paths


def main() -> None:
    """CLI entry point."""
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--zarr", type=Path, required=True)
    p.add_argument("--labels-csv", type=Path, required=True)
    p.add_argument("--phate-parquet", type=Path, required=True)
    p.add_argument("--output-dir", type=Path, required=True)
    p.add_argument(
        "--min-fraction",
        type=float,
        default=0.01,
        help="Minimum cluster size as a fraction of total cells (default 1%%).",
    )
    p.add_argument("--subsample", type=int, default=80_000, help="Max points per scatter.")
    p.add_argument("--pixel-size-um", type=float, default=None)
    p.add_argument("--time-key", default="hours_post_perturbation")
    p.add_argument("--window-frames", type=int, default=13, help="TFV rolling window (Wu's 2 h ≈ 13 frames).")
    p.add_argument("--seed", type=int, default=0)
    args = p.parse_args()

    out = run(
        args.zarr,
        args.labels_csv,
        args.phate_parquet,
        args.output_dir,
        min_fraction=args.min_fraction,
        subsample=args.subsample,
        pixel_size_um=args.pixel_size_um,
        time_key=args.time_key,
        seed=args.seed,
        window_frames=args.window_frames,
    )
    for p_ in out:
        print(f"wrote {p_}")


if __name__ == "__main__":
    main()
