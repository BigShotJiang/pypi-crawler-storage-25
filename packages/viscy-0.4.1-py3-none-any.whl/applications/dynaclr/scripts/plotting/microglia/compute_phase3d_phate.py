"""Compute a Phase3D-only PHATE on the DynaCLR microglia embedding.

The shared embedding zarr already carries an ``X_phate_combined`` (computed
across multiple channels). For per-channel grounding figures we want PHATE
fit on the Phase3D embedding alone. This script computes that and writes
it as a side parquet keyed by ``(fov_name, track_id, t)``, leaving the
upstream zarr untouched.

Default input is the 32-d ``X_pca`` already in the zarr (PHATE's standard
preprocessing step). Pass ``--feature-key X`` to run PHATE on the raw 768-d
encoder output instead.
"""

from __future__ import annotations

import argparse
import warnings
from pathlib import Path

import anndata as ad
import numpy as np
import pandas as pd
import phate

DEFAULT_ZARR = Path(
    "/hpc/projects/organelle_phenotyping/models/"
    "DynaCLR-2D-MIP-BagOfChannels/"
    "2d-mip-ntxent-t0p2-lr2e5-bs256-192to160-zext11/"
    "evaluations/microglia/embeddings/"
    "20191107_GW23_dynamorph_Phase3D.zarr"
)
DEFAULT_OUT = Path("/tmp/phase3d_phate.parquet")


def compute_phate(
    zarr_path: Path,
    out_path: Path,
    feature_key: str,
    knn: int,
    decay: int,
    t: int | str,
    n_jobs: int,
    seed: int,
) -> Path:
    """Compute PHATE on a per-channel embedding and write a side parquet.

    Parameters
    ----------
    zarr_path : Path
        DynaCLR per-channel embedding zarr.
    out_path : Path
        Destination parquet keyed by ``(fov_name, track_id, t)`` with
        columns ``phate_0``, ``phate_1``.
    feature_key : str
        ``"X"`` for the 768-d encoder output, or an ``obsm`` key (default
        ``"X_pca"``: the 32-d dataset-local PCA already in the zarr).
    knn : int
        PHATE ``knn`` parameter (default 15).
    decay : int
        PHATE ``decay`` parameter (default 40).
    t : int or str
        PHATE ``t`` (diffusion time). ``"auto"`` lets PHATE choose.
    n_jobs : int
        Parallelism for k-NN search.
    seed : int
        RNG seed.

    Returns
    -------
    Path
        Written parquet path.
    """
    with warnings.catch_warnings():
        warnings.filterwarnings("ignore", message="Observation names are not unique")
        adata = ad.read_zarr(zarr_path)
    print(f"loaded {zarr_path.name}: n_obs={adata.n_obs}, X={adata.X.shape}")

    if feature_key == "X":
        feats = np.asarray(adata.X, dtype=np.float32)
    else:
        feats = np.asarray(adata.obsm[feature_key], dtype=np.float32)
    print(f"PHATE input: feature_key={feature_key!r}, shape={feats.shape}")

    op = phate.PHATE(
        n_components=2,
        knn=knn,
        decay=decay,
        t=t if t != "auto" else "auto",
        n_jobs=n_jobs,
        random_state=seed,
        verbose=1,
    )
    coords = op.fit_transform(feats)
    print(f"PHATE done: coords shape {coords.shape}")

    df = pd.DataFrame(
        {
            "fov_name": adata.obs["fov_name"].astype(str).to_numpy(),
            "track_id": adata.obs["track_id"].astype(int).to_numpy(),
            "t": adata.obs["t"].astype(int).to_numpy(),
            "phate_0": coords[:, 0].astype(np.float32),
            "phate_1": coords[:, 1].astype(np.float32),
        }
    )
    out_path.parent.mkdir(parents=True, exist_ok=True)
    df.to_parquet(out_path, index=False)
    print(f"wrote {out_path}")
    return out_path


def main() -> None:
    """CLI entry point."""
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--zarr", type=Path, default=DEFAULT_ZARR)
    p.add_argument("--out", type=Path, default=DEFAULT_OUT)
    p.add_argument(
        "--feature-key",
        default="X_pca",
        help="'X' for raw 768-d, 'X_pca' for dataset-local 32-d PCA (default).",
    )
    p.add_argument("--knn", type=int, default=15)
    p.add_argument("--decay", type=int, default=40)
    p.add_argument("--t", default="auto", help="PHATE diffusion time; 'auto' or integer.")
    p.add_argument("--n-jobs", type=int, default=-1)
    p.add_argument("--seed", type=int, default=0)
    args = p.parse_args()

    t_arg: int | str
    try:
        t_arg = int(args.t)
    except ValueError:
        t_arg = args.t

    compute_phate(
        args.zarr,
        args.out,
        feature_key=args.feature_key,
        knn=args.knn,
        decay=args.decay,
        t=t_arg,
        n_jobs=args.n_jobs,
        seed=args.seed,
    )


if __name__ == "__main__":
    main()
