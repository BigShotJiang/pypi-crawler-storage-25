"""Bundle the microglia panels into a single PDF for review.

Each panel gets its own page at native resolution. Order follows the
grounding narrative: condition layout → behavior overlay → Wu-state overlay
→ trajectories → smoothness → retrieval → velocity context. No compositing,
no recoloring — just a viewing aid so everything is in one file.
"""

from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib.image as mpimg
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages

OUTPUTS = Path(__file__).resolve().parent / "outputs"

TAG = "20191107_GW23_dynamorph_Phase3D"
TAG_F = f"{TAG}_X_pca_combinedd32"
TAG_H = f"{TAG}_k20_g2"

PAGES: list[tuple[str, Path]] = [
    ("Panel A — PHATE by condition", OUTPUTS / "panel_A_by_condition_X_phate_combined.png"),
    ("Panel B — PHATE by time, per condition", OUTPUTS / "panel_B_by_time_X_phate_combined_percond.png"),
    ("Panel C — per-cell trajectories through embedding", OUTPUTS / "panel_C_trajectories_X_phate_combined.png"),
    ("Panel D — displacement vs time, per condition", OUTPUTS / "panel_D_displacement_X_pca_combined_d32.png"),
    (
        "Panel E — Leiden clusters on embedding (r=0.05, coarse) — composition",
        OUTPUTS / "panel_E_composition_20191107_GW23_dynamorph_Phase3D_X_r0.05.png",
    ),
    (
        "Panel E — Leiden clusters on embedding (r=0.05, coarse) — PHATE",
        OUTPUTS / "panel_E_phate_20191107_GW23_dynamorph_Phase3D_X_r0.05.png",
    ),
    ("Panel F — real-space speed overlay on PHATE", OUTPUTS / f"panel_F_phate_{TAG_F}.png"),
    ("Panel F — real-space tracks colored by speed", OUTPUTS / f"panel_F_tracks_{TAG_F}.png"),
    ("Panel F — real-space speed distribution", OUTPUTS / f"panel_F_dist_{TAG_F}.png"),
    ("Panel F — real-space speed vs time", OUTPUTS / f"panel_F_vs_time_{TAG_F}.png"),
    ("Panel F — embedding vs real-space velocity (ρ ≈ 0.30)", OUTPUTS / f"panel_F_corr_{TAG_F}.png"),
    ("Panel G — embedding-space speed on PHATE", OUTPUTS / f"panel_G_phate_{TAG_F}.png"),
    ("Panel G — embedding speed distribution", OUTPUTS / f"panel_G_dist_{TAG_F}.png"),
    ("Panel G — embedding speed vs time", OUTPUTS / f"panel_G_vs_time_{TAG_F}.png"),
    (
        "Panel H — Wu-style TFV behavioral state space (GMM k=2)",
        OUTPUTS / f"panel_H_tfv_tfv_space_{TAG_H}.png",
    ),
    (
        "Panel H — Wu-states on PHATE, per condition",
        OUTPUTS / f"panel_H_tfv_states_phate_{TAG_H}.png",
    ),
    (
        "Panel H — same-track retrieval recall by Wu-state",
        OUTPUTS / f"panel_H_tfv_retrieval_{TAG_H}.png",
    ),
]


def _add_image_page(pdf: PdfPages, title: str, path: Path) -> None:
    """Render one PNG as a full page in the PDF."""
    img = mpimg.imread(path)
    h, w = img.shape[:2]
    # cap long-side to 11in for print-sanity, preserve aspect
    long_side = 11.0
    scale = long_side / max(h, w)
    fig_w = w * scale
    fig_h = h * scale + 0.6  # extra space for title
    fig = plt.figure(figsize=(fig_w, fig_h))
    ax = fig.add_axes((0.02, 0.02, 0.96, 0.88))
    ax.imshow(img)
    ax.set_xticks([])
    ax.set_yticks([])
    for spine in ax.spines.values():
        spine.set_visible(False)
    fig.text(0.02, 0.94, title, fontsize=11, fontweight="bold")
    fig.text(0.02, 0.91, str(path.name), fontsize=7, color="#666", family="monospace")
    pdf.savefig(fig, bbox_inches="tight")
    plt.close(fig)


def compose(output_pdf: Path) -> Path:
    """Bundle all expected panels into a multi-page PDF.

    Missing PNGs are skipped with a printed warning — the bundle still renders.
    """
    output_pdf.parent.mkdir(parents=True, exist_ok=True)
    written = 0
    skipped: list[str] = []
    with PdfPages(output_pdf) as pdf:
        for title, path in PAGES:
            if not path.exists():
                skipped.append(f"{title} → {path.name}")
                continue
            _add_image_page(pdf, title, path)
            written += 1
    print(f"wrote {output_pdf} ({written} pages)")
    if skipped:
        print("skipped (file missing):")
        for s in skipped:
            print(f"  - {s}")
    return output_pdf


def main() -> None:
    """CLI entry point."""
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument(
        "--output",
        type=Path,
        default=OUTPUTS / "microglia_panels_bundle.pdf",
        help="Destination PDF path.",
    )
    args = p.parse_args()
    compose(args.output)


if __name__ == "__main__":
    main()
