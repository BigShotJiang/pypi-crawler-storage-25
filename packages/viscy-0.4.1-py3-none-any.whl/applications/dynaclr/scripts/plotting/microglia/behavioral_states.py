"""Wu-style trajectory feature vectors (TFVs) for microglia behavioral states.

Implements the motility side of the DynaMorph TFV (Wu et al. 2022, Mol Biol
Cell, doi:10.1091/mbc.E21-11-0561):

- Mean log-speed (centroid displacement per frame, log-transformed).
- Directional persistence — here, the mean cosine of the angle between
  consecutive velocity vectors. 1 = straight-line motion, 0 = random walk,
  -1 = back-and-forth. Wu's original version uses the angle between the
  cell's long axis and the direction of motion; we substitute velocity-vector
  autocorrelation because the cellpose centroids don't carry a body axis.
- Mean squared displacement at short, medium, long lags
  (τ = 1, 5, 10 frames at 9 min/frame ≈ 0.15, 0.75, 1.5 h).

Each feature is averaged over a **2-hour rolling window** per track, matching
Wu's choice for microglia imaged at ~9 min/frame (13 frames per 2-hour window).

Outputs
-------
``per_frame_tfv`` returns a DataFrame, one row per ``(fov_name, track_id, t)``,
with columns ``log_speed``, ``persistence``, ``msd_1``, ``msd_5``, ``msd_10``.
Rows where the window doesn't fit (track too short, start/end) are NaN.

The Panel-H pipeline feeds this into a GMM to assign behavioral states.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd


@dataclass(frozen=True)
class TFVConfig:
    """Parameters for trajectory feature computation.

    Parameters
    ----------
    window_frames : int
        Rolling window length for TFV averaging. Wu uses 2 h; with 9 min/frame
        imaging that is 13 frames.
    msd_lags : tuple of int
        Time lags (in frames) at which MSD is evaluated.
    min_track_length : int
        Tracks shorter than this are skipped entirely.
    """

    window_frames: int = 13
    msd_lags: tuple[int, ...] = (1, 5, 10)
    min_track_length: int = 13


def _unit_vectors(v: np.ndarray) -> np.ndarray:
    """L2-normalize rows of a 2D vector array, zero-safe."""
    n = np.linalg.norm(v, axis=1, keepdims=True)
    n[n == 0] = 1.0
    return v / n


def _per_track_tfv(
    pos: np.ndarray,
    times: np.ndarray,
    cfg: TFVConfig,
) -> np.ndarray:
    """Compute per-frame rolling-window TFV features for a single track.

    Parameters
    ----------
    pos : np.ndarray, shape (N, 2)
        Track (x, y) positions, sorted by time.
    times : np.ndarray, shape (N,)
        Hours at each frame (used only for log_speed normalization).
    cfg : TFVConfig
        Feature config.

    Returns
    -------
    np.ndarray, shape (N, F)
        Columns: ``[log_speed, persistence, msd_1, msd_5, msd_10, ...]``
        (MSD columns follow ``cfg.msd_lags``). NaN where the window doesn't
        fit (start/end) or track too short.
    """
    n = len(pos)
    f_cols = 2 + len(cfg.msd_lags)
    out = np.full((n, f_cols), np.nan, dtype=np.float32)
    if n < cfg.min_track_length:
        return out

    # instantaneous velocity and speed per frame
    v = np.zeros_like(pos)
    v[1:] = pos[1:] - pos[:-1]
    dt = np.zeros(n, dtype=np.float32)
    dt[1:] = np.maximum(times[1:] - times[:-1], 1e-6)
    speed = np.zeros(n, dtype=np.float32)
    speed[1:] = np.linalg.norm(v[1:], axis=1) / dt[1:]

    # per-step cosine between consecutive velocity vectors
    uv = _unit_vectors(v)
    cos_step = np.zeros(n, dtype=np.float32)
    cos_step[2:] = np.sum(uv[2:] * uv[1:-1], axis=1)

    W = cfg.window_frames
    half = W // 2
    for i in range(half, n - half):
        sl = slice(i - half, i + half + 1)
        sp = speed[sl]
        sp = sp[sp > 0]
        if len(sp) < 2:
            continue
        out[i, 0] = float(np.log1p(np.mean(sp)))
        out[i, 1] = float(np.mean(cos_step[sl][1:]))  # drop leading zero
        p_sl = pos[sl]
        for k, lag in enumerate(cfg.msd_lags):
            if len(p_sl) <= lag:
                continue
            disp = p_sl[lag:] - p_sl[:-lag]
            out[i, 2 + k] = float(np.log1p(np.mean(np.sum(disp**2, axis=1))))
    return out


def compute_tfv(
    obs: pd.DataFrame,
    cfg: TFVConfig | None = None,
    time_key: str = "hours_post_perturbation",
) -> pd.DataFrame:
    """Compute Wu-style TFV features per ``(fov_name, track_id, t)``.

    Parameters
    ----------
    obs : pandas.DataFrame
        Must contain ``fov_name``, ``track_id``, ``t``, ``x``, ``y`` and
        ``time_key``. Row order is preserved in the output.
    cfg : TFVConfig or None
        Feature config. Defaults to 2-hour window, MSD lags (1, 5, 10).
    time_key : str
        Column with time in hours (for speed units).

    Returns
    -------
    pandas.DataFrame
        Same row count as ``obs``, columns ``log_speed``, ``persistence``,
        ``msd_1``, ``msd_5``, ``msd_10``. NaN for frames where the rolling
        window doesn't fit.
    """
    cfg = cfg or TFVConfig()
    n = len(obs)
    f_cols = 2 + len(cfg.msd_lags)
    out = np.full((n, f_cols), np.nan, dtype=np.float32)

    sub = obs[["fov_name", "track_id", "t", "x", "y", time_key]].reset_index(drop=True)
    sub["row"] = np.arange(n)
    for _, tr in sub.groupby(["fov_name", "track_id"], sort=False, observed=True):
        tr = tr.sort_values("t")
        rows = tr["row"].to_numpy()
        pos = np.column_stack([tr["x"].to_numpy(dtype=np.float32), tr["y"].to_numpy(dtype=np.float32)])
        times = tr[time_key].to_numpy(dtype=np.float32)
        feats = _per_track_tfv(pos, times, cfg)
        out[rows] = feats

    cols = ["log_speed", "persistence"] + [f"msd_{lag}" for lag in cfg.msd_lags]
    return pd.DataFrame(out, columns=cols)
