"""Panel H: behavioral-state assignment via GMM on real-space speed, plus
self-track retrieval in the DynaCLR embedding stratified by that state.

Pipeline
--------
1. Compute per-frame real-space speed (same definition as Panel F).
2. Fit a Gaussian Mixture on ``log1p(speed)`` to assign each cell-frame an
   unsupervised behavioral state (slow / mid / fast, k components).
3. L2-normalize the DynaCLR embedding and run approximate k-NN.
4. For each query frame, compute:
     - same-track recall@k: fraction of top-k neighbors sharing
       ``(fov_name, track_id)``,
     - temporal recall@k: fraction of top-k neighbors that are the *same
       cell* within ±Δt frames (stricter).
5. Stratify both metrics by GMM state, and by PHATE location.

Why
---
Claim (b) of the three-claim story — "DynaCLR maintains cell identity even
when cells are morphologically changing" — is a statement about how
retrieval recall behaves as cells move through different dynamic regimes.
Fast (amoeboid, transitioning) cells are the hardest case; a static
morphology encoder would lose them. Temporal contrastive training should
keep them held together, with recall flat or only mildly degrading.

Runs DynaCLR-only — no baseline, no labels required.
"""

from __future__ import annotations

import argparse
from pathlib import Path

import anndata as ad
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.mixture import GaussianMixture
from sklearn.neighbors import NearestNeighbors
from sklearn.preprocessing import StandardScaler

from _common import (
    CONDITION_COLORS,
    DEFAULT_OUTPUT_DIR,
    DEFAULT_ZARR,
    ensure_outdir,
    load_embedding,
)
from behavioral_states import TFVConfig, compute_tfv
from panel_f_realspace_velocity import compute_realspace_speed

# Discrete high-contrast palettes for GMM behavioral states.
# k=2: Wu's ramified-like (slow/large) vs. amoeboid-like (fast/dense) — the
#      paper's primary finding. Blue = slow, magenta = fast.
# k=3: blue / green / magenta — kept for the speed-only fallback.
STATE_PALETTE_2 = ["#2066a8", "#c21f8b"]  # blue, magenta
STATE_PALETTE_3 = ["#2066a8", "#4daf4a", "#c21f8b"]
STATE_LABELS_2 = ["state-1 (slow/ramified-like)", "state-2 (fast/amoeboid-like)"]
STATE_LABELS_2_SHORT = ["state-1", "state-2"]
STATE_LABELS_3 = ["slow", "mid", "fast"]


def state_colors(n: int) -> list[str]:
    """Return a categorical palette of length ``n`` for GMM states.

    ``n == 2`` matches Wu et al.'s two-state finding (slow/ramified-like vs.
    fast/amoeboid-like). ``n == 3`` is the finer-grained fallback used for
    speed-only binning. Other sizes fall back to a plasma ramp.
    """
    if n == 2:
        return STATE_PALETTE_2
    if n == 3:
        return STATE_PALETTE_3
    return [plt.cm.plasma(x) for x in np.linspace(0.15, 0.85, n)]


def state_label(i: int, n: int, short: bool = False) -> str:
    """Human-readable GMM state label."""
    if n == 2:
        return STATE_LABELS_2_SHORT[i] if short else STATE_LABELS_2[i]
    if n == 3:
        return STATE_LABELS_3[i]
    return f"state {i}"



def fit_speed_gmm(
    speed: np.ndarray,
    n_components: int,
    seed: int,
) -> tuple[np.ndarray, GaussianMixture, np.ndarray]:
    """Fit a Gaussian Mixture on ``log1p(speed)`` and return hard assignments.

    Components are re-ordered so label 0 is the slowest-mean component and
    ``n_components - 1`` is the fastest. This makes later stratification
    ("Q1 = slowest") consistent regardless of EM init.

    Parameters
    ----------
    speed : np.ndarray
        Per-frame real-space speed (px/hour or µm/hour). NaNs are dropped
        from the fit and are returned with label ``-1``.
    n_components : int
        Number of mixture components.
    seed : int
        RNG seed for GMM init.

    Returns
    -------
    labels : np.ndarray of int
        Component assignment per input row, ``-1`` where speed was NaN.
    gmm : GaussianMixture
        The fitted model (label order follows ``sorted_idx``).
    sorted_means : np.ndarray
        Component means (on the ``log1p`` scale) sorted ascending.
    """
    labels = np.full(len(speed), -1, dtype=np.int8)
    finite_mask = np.isfinite(speed)
    x = np.log1p(speed[finite_mask]).reshape(-1, 1).astype(np.float32)

    gmm = GaussianMixture(
        n_components=n_components,
        covariance_type="full",
        random_state=seed,
        max_iter=200,
        n_init=3,
    ).fit(x)

    raw = gmm.predict(x)
    order = np.argsort(gmm.means_.ravel())
    remap = np.empty(n_components, dtype=np.int8)
    for new_label, old_label in enumerate(order):
        remap[old_label] = new_label
    labels[finite_mask] = remap[raw]
    return labels, gmm, gmm.means_.ravel()[order]


def fit_tfv_gmm(
    tfv: pd.DataFrame,
    n_components: int,
    seed: int,
) -> tuple[np.ndarray, GaussianMixture, StandardScaler, np.ndarray]:
    """Fit a Gaussian Mixture on Wu-style TFV features.

    Follows Wu et al. 2022 (Mol Biol Cell): concatenate motility descriptors
    (log-speed, directional persistence, MSD at several lags) into one
    vector, averaged over a rolling window per track (default 2 h ≈ 13
    frames at 9 min/frame), then cluster with GMM. Components are re-ordered
    so label 0 is the slower-speed component (``state-1`` in Wu's notation).

    Parameters
    ----------
    tfv : pandas.DataFrame
        One row per cell-frame with numeric feature columns. NaNs are
        dropped from the fit and returned with label ``-1``.
    n_components : int
        Mixture components. Wu settled on ``k=2`` after silhouette
        comparison on their microglia dataset.
    seed : int
        RNG seed.

    Returns
    -------
    labels : np.ndarray of int
        Component assignment per input row, ``-1`` where any feature was NaN.
    gmm : GaussianMixture
        The fitted model (label order follows log-speed ascending).
    scaler : StandardScaler
        The feature scaler, for re-using on other data or for plotting.
    order : np.ndarray
        Permutation that maps raw GMM labels to sorted labels.
    """
    labels = np.full(len(tfv), -1, dtype=np.int8)
    feats = tfv.to_numpy(dtype=np.float32)
    finite_mask = np.all(np.isfinite(feats), axis=1)
    x = feats[finite_mask]

    scaler = StandardScaler().fit(x)
    xs = scaler.transform(x)

    gmm = GaussianMixture(
        n_components=n_components,
        covariance_type="full",
        random_state=seed,
        max_iter=500,
        n_init=5,
    ).fit(xs)

    raw = gmm.predict(xs)
    log_speed_col = tfv.columns.get_loc("log_speed")
    # order components by mean log-speed on the scaled space -> stable label mapping
    mean_speed_per_component = np.array(
        [xs[raw == c, log_speed_col].mean() if np.any(raw == c) else -np.inf for c in range(n_components)]
    )
    order = np.argsort(mean_speed_per_component)
    remap = np.empty(n_components, dtype=np.int8)
    for new_label, old_label in enumerate(order):
        remap[old_label] = new_label
    labels[finite_mask] = remap[raw]
    return labels, gmm, scaler, order


def plot_tfv_space(
    tfv: pd.DataFrame,
    states: np.ndarray,
    subsample: int,
    seed: int,
) -> plt.Figure:
    """2D scatter of ``(log_speed, persistence)`` colored by GMM state.

    Shows the behavioral-state space Wu et al. use for microglia clustering.
    Amoeboid/migratory cells cluster in the fast+persistent quadrant,
    ramified/surveilling cells in the slow+non-persistent region.
    """
    rng = np.random.default_rng(seed)
    valid = (states >= 0) & np.all(np.isfinite(tfv.to_numpy()), axis=1)
    idx = np.where(valid)[0]
    if subsample < len(idx):
        idx = rng.choice(idx, size=subsample, replace=False)

    x = tfv["log_speed"].to_numpy()[idx]
    y = tfv["persistence"].to_numpy()[idx]
    s = states[idx]
    n_states = int(states[valid].max()) + 1
    colors = state_colors(n_states)

    fig, axes = plt.subplots(1, 2, figsize=(11, 4.6), constrained_layout=True)

    ax = axes[0]
    for c in range(n_states):
        m = s == c
        ax.scatter(x[m], y[m], s=2.5, c=[colors[c]], alpha=0.5, linewidths=0, label=state_label(c, n_states))
    ax.set_xlabel("log-speed (rolling 2h mean)")
    ax.set_ylabel("directional persistence (mean cos of turning angle)")
    ax.axhline(0, color="k", linewidth=0.5, linestyle=":")
    ax.set_title("Wu-style behavioral state space", fontsize=10)
    ax.legend(frameon=False, fontsize=8, markerscale=3, loc="lower right")

    ax = axes[1]
    df = pd.DataFrame({"state": states[valid], **{c: tfv[c].to_numpy()[valid] for c in tfv.columns}})
    state_vals = sorted(df["state"].unique())
    tick_labels = [state_label(int(sv), n_states, short=True) for sv in state_vals]
    feat_cols = list(tfv.columns)
    x_pos = np.arange(len(feat_cols))
    width = 0.8 / max(len(state_vals), 1)
    for i, sv in enumerate(state_vals):
        means = [df[df["state"] == sv][fc].mean() for fc in feat_cols]
        ax.bar(
            x_pos + (i - (len(state_vals) - 1) / 2) * width,
            means,
            width=width,
            color=colors[int(sv)],
            edgecolor="#333",
            linewidth=0.5,
            label=tick_labels[i],
        )
    ax.set_xticks(x_pos)
    ax.set_xticklabels(feat_cols, rotation=25, ha="right", fontsize=8)
    ax.set_ylabel("feature mean")
    ax.set_title("TFV feature means per state", fontsize=10)
    ax.legend(frameon=False, fontsize=8)

    fig.suptitle("Panel H — behavioral state space (Wu-style TFV)", y=1.04)
    return fig


def plot_gmm_fit(
    speed: np.ndarray,
    labels: np.ndarray,
    sorted_means: np.ndarray,
    unit_label: str,
) -> plt.Figure:
    """Show the GMM fit over the speed distribution."""
    fig, ax = plt.subplots(figsize=(7.0, 4.2), constrained_layout=True)
    valid = labels >= 0
    n_states = len(sorted_means)
    colors = state_colors(n_states)
    q99 = float(np.quantile(speed[valid], 0.99))
    bins = np.linspace(0, q99, 80)
    for lbl in range(n_states):
        sub = speed[(labels == lbl)]
        ax.hist(
            sub[sub <= q99],
            bins=bins,
            color=colors[lbl],
            alpha=0.75,
            label=f"{state_label(lbl, n_states)} (mean log1p={sorted_means[lbl]:.2f})",
            edgecolor="none",
        )
    ax.set_xlabel(f"real-space speed ({unit_label})")
    ax.set_ylabel("cell-frames")
    ax.set_title("Panel H — GMM behavioral states on real-space speed")
    ax.legend(frameon=False, fontsize=8)
    return fig


def build_knn(
    embedding: np.ndarray,
    k: int,
    query_idx: np.ndarray,
) -> np.ndarray:
    """Return top-``k`` neighbor indices (in the full database) for each query row.

    Embedding is L2-normalized so cosine similarity reduces to inner product,
    matching the geometry of the NT-Xent training objective. Uses sklearn's
    ``NearestNeighbors`` with ``metric='cosine'`` over the full dataset as
    the retrieval database, but only queries the ``query_idx`` subset to
    keep runtime bounded on ~10^6 row datasets.

    Parameters
    ----------
    embedding : np.ndarray, shape (N, D)
        The full embedding (all cell-frames).
    k : int
        Number of neighbors (excluding self).
    query_idx : np.ndarray of int
        Row indices used as queries. Queries still see all N rows as
        candidates.

    Returns
    -------
    np.ndarray, shape (len(query_idx), k)
        Indices (in the full-dataset coordinates) of the top-``k`` neighbors,
        with the self-match removed.
    """
    nn = NearestNeighbors(n_neighbors=k + 1, metric="cosine", algorithm="brute", n_jobs=-1)
    nn.fit(embedding)
    _, idx = nn.kneighbors(embedding[query_idx])
    out = np.empty((len(query_idx), k), dtype=np.int64)
    for i, q in enumerate(query_idx):
        row = idx[i]
        out[i] = row[row != q][:k]
    return out


def score_retrieval(
    neighbor_idx: np.ndarray,
    obs: pd.DataFrame,
    query_idx: np.ndarray,
    delta_t: int,
) -> pd.DataFrame:
    """Compute same-track and temporal recall@k per query.

    Parameters
    ----------
    neighbor_idx : np.ndarray, shape (Q, k)
        Top-k neighbor row indices per query.
    obs : pandas.DataFrame
        Full ``adata.obs`` — needs ``fov_name``, ``track_id``, ``t``.
    query_idx : np.ndarray
        Query row indices (length Q).
    delta_t : int
        Temporal tolerance (frames): a neighbor counts as a "temporal hit"
        if it's the same cell and ``|t_query - t_neighbor| <= delta_t``.

    Returns
    -------
    pandas.DataFrame
        One row per query with ``same_track_frac`` and ``temporal_frac``.
    """
    fov = obs["fov_name"].to_numpy()
    tid = obs["track_id"].to_numpy()
    t = obs["t"].to_numpy()

    same_track = np.zeros(len(query_idx), dtype=np.float32)
    temporal = np.zeros(len(query_idx), dtype=np.float32)
    for i, q in enumerate(query_idx):
        n = neighbor_idx[i]
        same = (fov[n] == fov[q]) & (tid[n] == tid[q])
        same_track[i] = float(np.mean(same))
        temporal[i] = float(np.mean(same & (np.abs(t[n] - t[q]) <= delta_t)))
    return pd.DataFrame(
        {
            "query_idx": query_idx,
            "same_track_frac": same_track,
            "temporal_frac": temporal,
        }
    )


def plot_retrieval_by_state(
    scores: pd.DataFrame,
    states: np.ndarray,
    conditions: np.ndarray,
    k: int,
    random_floor: float,
) -> plt.Figure:
    """Retrieval recall by GMM behavioral state, overall and per condition."""
    df = scores.copy()
    df["state"] = states[df["query_idx"].to_numpy()]
    df["perturbation"] = conditions[df["query_idx"].to_numpy()]
    df = df[df["state"] >= 0]

    fig, axes = plt.subplots(1, 3, figsize=(15, 4.5), constrained_layout=True)

    state_vals = sorted(df["state"].unique())
    n_states = len(state_vals)
    palette = state_colors(n_states)
    tick_labels = [state_label(int(s), n_states) for s in state_vals]

    ax = axes[0]
    means = df.groupby("state", observed=True)["same_track_frac"].mean().reindex(state_vals)
    sems = df.groupby("state", observed=True)["same_track_frac"].sem().reindex(state_vals)
    ax.bar(
        state_vals,
        means.to_numpy(),
        yerr=sems.to_numpy(),
        color=[palette[int(s)] for s in state_vals],
        edgecolor="#333",
        linewidth=0.6,
    )
    ax.axhline(random_floor, color="k", linestyle="--", linewidth=0.8, label=f"random: {random_floor:.4f}")
    ax.set_xticks(state_vals)
    ax.set_xticklabels(tick_labels)
    ax.set_xlabel("GMM behavioral state (real-space speed)")
    ax.set_ylabel(f"same-track recall@{k}")
    ax.set_title("Same-track retrieval by state")
    ax.legend(frameon=False, fontsize=8)

    ax = axes[1]
    means_t = df.groupby("state", observed=True)["temporal_frac"].mean().reindex(state_vals)
    sems_t = df.groupby("state", observed=True)["temporal_frac"].sem().reindex(state_vals)
    ax.bar(
        state_vals,
        means_t.to_numpy(),
        yerr=sems_t.to_numpy(),
        color=[palette[int(s)] for s in state_vals],
        edgecolor="#333",
        linewidth=0.6,
    )
    ax.set_xticks(state_vals)
    ax.set_xticklabels(tick_labels)
    ax.set_xlabel("GMM behavioral state (real-space speed)")
    ax.set_ylabel(f"temporal recall@{k} (same cell, ±Δt)")
    ax.set_title("Temporal-neighbor retrieval by state")

    ax = axes[2]
    for c, color in CONDITION_COLORS.items():
        sub = df[df["perturbation"] == c]
        if sub.empty:
            continue
        m = sub.groupby("state", observed=True)["same_track_frac"].mean().reindex(state_vals)
        ax.plot(state_vals, m.to_numpy(), "-o", color=color, label=c, linewidth=1.5, markersize=5)
    ax.axhline(random_floor, color="k", linestyle="--", linewidth=0.8)
    ax.set_xticks(state_vals)
    ax.set_xticklabels(tick_labels)
    ax.set_xlabel("GMM behavioral state (real-space speed)")
    ax.set_ylabel(f"same-track recall@{k}")
    ax.set_title("Per-condition trend")
    ax.legend(frameon=False, fontsize=8)

    fig.suptitle("Panel H — identity retrieval stratified by GMM behavioral state", y=1.04)
    return fig


def plot_states_on_phate(
    adata: ad.AnnData,
    states: np.ndarray,
    subsample: int,
    seed: int,
) -> plt.Figure:
    """PHATE scatter colored by GMM state, per condition."""
    rng = np.random.default_rng(seed)
    xy = adata.obsm["X_phate_combined"]
    cond = adata.obs["perturbation"].to_numpy()
    conditions = [c for c in CONDITION_COLORS if c in np.unique(cond)]
    n_states = int(states[states >= 0].max()) + 1
    colors = state_colors(n_states)

    fig, axes = plt.subplots(
        1, len(conditions), figsize=(4.2 * len(conditions), 4.2), constrained_layout=True,
        sharex=True, sharey=True,
    )
    if len(conditions) == 1:
        axes = np.array([axes])

    for ax, c in zip(axes, conditions):
        mask = (cond == c) & (states >= 0)
        idx = np.where(mask)[0]
        if subsample < len(idx):
            idx = rng.choice(idx, size=subsample, replace=False)
        idx = rng.permutation(idx)
        for s in range(n_states):
            m = states[idx] == s
            ax.scatter(
                xy[idx[m], 0],
                xy[idx[m], 1],
                s=1.2,
                c=[colors[s]],
                alpha=0.7,
                linewidths=0,
                label=state_label(s, n_states),
            )
        ax.set_title(f"{c} (n={mask.sum()})", fontsize=9)
        ax.set_xlabel("X_phate_combined [0]")
    axes[0].set_ylabel("X_phate_combined [1]")
    axes[-1].legend(frameon=False, fontsize=7, loc="upper right", markerscale=4)
    fig.suptitle("Panel H — GMM behavioral states on PHATE", y=1.03)
    return fig


def plot(
    zarr_path: Path,
    output_dir: Path,
    k: int,
    delta_t: int,
    n_gmm_components: int,
    query_per_state: int,
    subsample_phate: int,
    time_key: str,
    pixel_size_um: float | None,
    seed: int,
    state_mode: str = "tfv",
    window_frames: int = 13,
) -> list[Path]:
    """Compute GMM states and retrieval recall, write figures + CSVs.

    Parameters
    ----------
    zarr_path : Path
        DynaCLR embedding zarr.
    output_dir : Path
        Destination.
    k : int
        Number of neighbors for retrieval.
    delta_t : int
        Temporal tolerance for temporal recall.
    n_gmm_components : int
        GMM mixture components. Default 2 for ``tfv`` mode (Wu's finding);
        3 is a reasonable fallback for ``speed`` mode.
    query_per_state : int
        Max queries per GMM state (kept balanced across states).
    subsample_phate : int
        Max points per condition for the PHATE-state scatter.
    time_key : str
        ``obs`` column (hours) — used for real-space speed.
    pixel_size_um : float or None
        If set, speed is µm/hour, else px/hour.
    seed : int
        RNG seed.
    state_mode : {"tfv", "speed"}
        ``tfv`` (default): Wu-style multi-feature GMM (log-speed, persistence,
        MSD at several lags, averaged over ``window_frames``).
        ``speed``: legacy speed-only GMM, useful as a diagnostic.
    window_frames : int
        Rolling window (frames) for TFV averaging. 13 frames ≈ 2 h at
        9 min/frame imaging, matching Wu et al.

    Returns
    -------
    list of Path
        All saved artifacts.
    """
    adata = load_embedding(zarr_path)
    real_speed = compute_realspace_speed(adata, time_key, pixel_size_um)
    unit_label = "px/hour" if pixel_size_um is None else "µm/hour"
    obs = adata.obs.reset_index(drop=True)

    tfv_df: pd.DataFrame | None = None
    if state_mode == "tfv":
        print(f"computing Wu-style TFV (window = {window_frames} frames ≈ 2h at 9 min/frame)")
        tfv_df = compute_tfv(obs, TFVConfig(window_frames=window_frames, min_track_length=window_frames), time_key=time_key)
        states, _, _, _ = fit_tfv_gmm(tfv_df, n_gmm_components, seed)
        print(f"TFV state counts: {np.bincount(states[states >= 0], minlength=n_gmm_components).tolist()}")
    elif state_mode == "speed":
        states, _, sorted_means = fit_speed_gmm(real_speed, n_gmm_components, seed)
        print(f"speed GMM states (log1p scale): {np.round(sorted_means, 3).tolist()}")
        print(f"state counts: {np.bincount(states[states >= 0], minlength=n_gmm_components).tolist()}")
    else:
        raise ValueError(f"unknown state_mode: {state_mode!r} (expected 'tfv' or 'speed')")

    emb = np.asarray(adata.X, dtype=np.float32)
    norms = np.linalg.norm(emb, axis=1, keepdims=True)
    norms[norms == 0] = 1.0
    emb = emb / norms

    rng = np.random.default_rng(seed)
    query_rows = []
    for s in range(n_gmm_components):
        pool = np.where(states == s)[0]
        if len(pool) == 0:
            continue
        pick = rng.choice(pool, size=min(query_per_state, len(pool)), replace=False)
        query_rows.append(pick)
    query_idx = np.concatenate(query_rows)
    print(f"querying {len(query_idx)} frames across {n_gmm_components} states against {len(emb)} candidates")

    neighbor_idx = build_knn(emb, k, query_idx)

    scores = score_retrieval(neighbor_idx, obs, query_idx, delta_t)

    # random floor: probability a random other-frame shares (fov, track_id)
    track_counts = obs.groupby(["fov_name", "track_id"], observed=True).size()
    n = len(obs)
    random_floor = float(((track_counts * (track_counts - 1)).sum()) / (n * (n - 1)))

    ensure_outdir(output_dir)
    tag = zarr_path.stem
    paths: list[Path] = []

    figures: list[tuple[str, plt.Figure]] = []
    if state_mode == "tfv":
        figures.append(("tfv_space", plot_tfv_space(tfv_df, states, subsample_phate * 2, seed)))
    else:
        sorted_means_for_plot = np.array(
            [float(np.nanmean(np.log1p(real_speed[(states == c)]))) for c in range(n_gmm_components)]
        )
        figures.append(("gmm_fit", plot_gmm_fit(real_speed, states, sorted_means_for_plot, unit_label)))
    figures.append(("states_phate", plot_states_on_phate(adata, states, subsample_phate, seed)))
    figures.append(
        ("retrieval", plot_retrieval_by_state(scores, states, obs["perturbation"].to_numpy(), k, random_floor))
    )

    for name, fig in figures:
        out = output_dir / f"panel_H_{state_mode}_{name}_{tag}_k{k}_g{n_gmm_components}.png"
        fig.savefig(out, dpi=200)
        plt.close(fig)
        paths.append(out)

    scores["state"] = states[scores["query_idx"].to_numpy()]
    scores["perturbation"] = obs["perturbation"].to_numpy()[scores["query_idx"].to_numpy()]

    summary = (
        scores.groupby(["state", "perturbation"], observed=True)
        .agg(
            same_track_mean=("same_track_frac", "mean"),
            same_track_sem=("same_track_frac", "sem"),
            temporal_mean=("temporal_frac", "mean"),
            temporal_sem=("temporal_frac", "sem"),
            n=("same_track_frac", "size"),
        )
        .reset_index()
    )
    summary["random_floor"] = random_floor
    summary_csv = output_dir / f"panel_H_{state_mode}_summary_{tag}_k{k}_g{n_gmm_components}.csv"
    summary.to_csv(summary_csv, index=False)
    paths.append(summary_csv)

    per_query_csv = output_dir / f"panel_H_{state_mode}_per_query_{tag}_k{k}_g{n_gmm_components}.csv"
    scores.to_csv(per_query_csv, index=False)
    paths.append(per_query_csv)

    print(f"\nrandom floor (same (fov,track_id) by chance): {random_floor:.5f}")
    print("\n### Same-track recall@k by GMM state")
    overall = (
        scores.groupby("state", observed=True)["same_track_frac"]
        .agg(["mean", "sem", "size"])
        .round(3)
    )
    print(overall.to_markdown())

    return paths


def main() -> None:
    """CLI entry point."""
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--zarr", type=Path, default=DEFAULT_ZARR)
    p.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT_DIR)
    p.add_argument("--k", type=int, default=20, help="Retrieval k.")
    p.add_argument("--delta-t", type=int, default=5, help="Temporal tolerance (frames) for temporal recall.")
    p.add_argument(
        "--state-mode",
        choices=("tfv", "speed"),
        default="tfv",
        help="Behavioral state definition. 'tfv' = Wu-style multi-feature GMM (default); 'speed' = legacy speed-only.",
    )
    p.add_argument(
        "--n-gmm-components",
        type=int,
        default=2,
        help="GMM components. Default 2 matches Wu's finding for TFV mode; use 3 for speed-only mode.",
    )
    p.add_argument(
        "--window-frames",
        type=int,
        default=13,
        help="Rolling window for TFV averaging (frames). 13 ≈ 2h at 9 min/frame (Wu's choice).",
    )
    p.add_argument(
        "--query-per-state",
        type=int,
        default=2000,
        help="Max queries per GMM state (balances fast/slow populations).",
    )
    p.add_argument("--subsample-phate", type=int, default=20_000)
    p.add_argument("--time-key", default="hours_post_perturbation")
    p.add_argument("--pixel-size-um", type=float, default=None)
    p.add_argument("--seed", type=int, default=0)
    args = p.parse_args()

    out = plot(
        args.zarr,
        args.output_dir,
        k=args.k,
        delta_t=args.delta_t,
        n_gmm_components=args.n_gmm_components,
        query_per_state=args.query_per_state,
        subsample_phate=args.subsample_phate,
        time_key=args.time_key,
        pixel_size_um=args.pixel_size_um,
        state_mode=args.state_mode,
        window_frames=args.window_frames,
        seed=args.seed,
    )
    for p_ in out:
        print(f"wrote {p_}")


if __name__ == "__main__":
    main()
