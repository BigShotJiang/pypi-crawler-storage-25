"""Panel C: per-cell trajectories through embedding space.

Samples N tracks per condition and plots each track as a line in the 2D
embedding, plus the component-vs-time traces. Track shapes (plateau,
oscillate, diverge) reveal how each stimulus drives morphotype dynamics.
"""

from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from _common import (
    CONDITION_COLORS,
    DEFAULT_OUTPUT_DIR,
    DEFAULT_ZARR,
    ensure_outdir,
    get_2d_embedding,
    load_embedding,
    track_groups,
)


def _sample_tracks(
    grouped: pd.core.groupby.DataFrameGroupBy,
    condition: str,
    n: int,
    min_length: int,
    rng: np.random.Generator,
) -> list[pd.DataFrame]:
    """Return up to ``n`` tracks for a condition, sorted by time, length >= ``min_length``."""
    picks: list[pd.DataFrame] = []
    candidates = []
    for _, sub in grouped:
        if len(sub) < min_length:
            continue
        if sub["perturbation"].iloc[0] != condition:
            continue
        candidates.append(sub)
    if not candidates:
        return picks
    idx = rng.choice(len(candidates), size=min(n, len(candidates)), replace=False)
    return [candidates[i] for i in idx]


def plot(
    zarr_path: Path,
    embedding_key: str,
    components: tuple[int, int],
    output_dir: Path,
    tracks_per_condition: int = 8,
    min_length: int = 30,
    time_key: str = "hours_post_perturbation",
    seed: int = 0,
) -> Path:
    """Plot per-cell trajectories for each condition.

    Produces a figure with two rows:
    - Top row: per-condition panels showing full embedding cloud (grey)
      with sampled tracks overlaid as colored lines.
    - Bottom row: component 0 vs time for each sampled track, one subplot per condition.

    Parameters
    ----------
    zarr_path : Path
        Embedding AnnData zarr.
    embedding_key : str
        Key in ``adata.obsm``.
    components : tuple of int
        Two 0-indexed components to plot in the 2D panels.
    output_dir : Path
        Directory for the output PNG.
    tracks_per_condition : int
        Number of tracks to sample per condition.
    min_length : int
        Minimum number of timepoints for a track to be eligible.
    time_key : str
        Column used for x-axis of the bottom row.
    seed : int
        RNG seed.

    Returns
    -------
    Path
        Path to the saved figure.
    """
    adata = load_embedding(zarr_path)
    xy = get_2d_embedding(adata, embedding_key, components)
    grouped = track_groups(adata)
    rng = np.random.default_rng(seed)

    conditions = list(CONDITION_COLORS.keys())
    ncols = len(conditions)
    fig, axes = plt.subplots(
        2, ncols, figsize=(4.0 * ncols, 7.5), constrained_layout=True, sharex="row", sharey="row"
    )

    # background cloud
    bg_idx = rng.choice(len(xy), size=min(30_000, len(xy)), replace=False)

    for j, cond in enumerate(conditions):
        ax_top = axes[0, j]
        ax_bot = axes[1, j]
        ax_top.scatter(xy[bg_idx, 0], xy[bg_idx, 1], s=0.4, c="lightgrey", alpha=0.4, linewidths=0)

        tracks = _sample_tracks(grouped, cond, tracks_per_condition, min_length, rng)
        color = CONDITION_COLORS[cond]
        for sub in tracks:
            rows = sub["row"].to_numpy()
            ax_top.plot(
                xy[rows, 0],
                xy[rows, 1],
                "-",
                color=color,
                alpha=0.8,
                linewidth=0.8,
            )
            ax_top.scatter(
                xy[rows[0], 0], xy[rows[0], 1], marker="o", s=14, facecolor=color, edgecolor="k", linewidths=0.4
            )
            ax_top.scatter(
                xy[rows[-1], 0], xy[rows[-1], 1], marker="s", s=14, facecolor=color, edgecolor="k", linewidths=0.4
            )
            ax_bot.plot(
                sub[time_key].to_numpy(),
                xy[rows, 0],
                "-",
                color=color,
                alpha=0.7,
                linewidth=0.8,
            )
        ax_top.set_title(f"{cond} (showing {len(tracks)})", fontsize=9)
        ax_top.set_xlabel(f"{embedding_key} [{components[0]}]")
        ax_bot.set_xlabel(time_key)
        if j == 0:
            ax_top.set_ylabel(f"{embedding_key} [{components[1]}]")
            ax_bot.set_ylabel(f"{embedding_key} [{components[0]}]")

    fig.suptitle("Panel C — per-cell trajectories through embedding space", y=1.02)
    ensure_outdir(output_dir)
    out = output_dir / f"panel_C_trajectories_{embedding_key}.png"
    fig.savefig(out, dpi=200)
    plt.close(fig)
    return out


def main() -> None:
    """CLI entry point."""
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--zarr", type=Path, default=DEFAULT_ZARR)
    p.add_argument("--embedding-key", default="X_phate_combined")
    p.add_argument("--components", type=int, nargs=2, default=(0, 1))
    p.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT_DIR)
    p.add_argument("--tracks-per-condition", type=int, default=8)
    p.add_argument("--min-length", type=int, default=30)
    p.add_argument("--time-key", default="hours_post_perturbation")
    p.add_argument("--seed", type=int, default=0)
    args = p.parse_args()

    out = plot(
        args.zarr,
        args.embedding_key,
        tuple(args.components),
        args.output_dir,
        tracks_per_condition=args.tracks_per_condition,
        min_length=args.min_length,
        time_key=args.time_key,
        seed=args.seed,
    )
    print(f"wrote {out}")


if __name__ == "__main__":
    main()
