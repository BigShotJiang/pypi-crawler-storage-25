"""Shared helpers for microglia dynamics panels."""

from __future__ import annotations

from pathlib import Path

import warnings

import anndata as ad
import numpy as np
import pandas as pd

CONDITION_COLORS: dict[str, str] = {
    "untreated": "#7f7f7f",
    "IL17": "#1f77b4",
    "IFN-beta": "#2ca02c",
    "Glioblastoma_supernatant": "#d62728",
    "Rubella": "#9467bd",
}

DEFAULT_ZARR = Path(
    "/hpc/projects/organelle_phenotyping/models/"
    "DynaCLR-2D-MIP-BagOfChannels/"
    "2d-mip-ntxent-t0p2-lr2e5-bs256-192to160-zext11/"
    "evaluations/microglia/embeddings/"
    "20191107_GW23_dynamorph_Phase3D.zarr"
)

DEFAULT_OUTPUT_DIR = Path(__file__).resolve().parent / "outputs"


def load_embedding(zarr_path: Path) -> ad.AnnData:
    """Read an AnnData embedding zarr.

    The non-unique obs-names warning is suppressed: the obs index is
    replaced with a plain ``RangeIndex`` so plotting code indexes by
    position. Calling ``obs_names_make_unique`` on ArrowStringArrays
    with ~10^6 rows triggers an O(n^2) path and effectively hangs.

    Parameters
    ----------
    zarr_path : Path
        Path to the ``.zarr`` produced by the DynaCLR evaluation pipeline.

    Returns
    -------
    AnnData
        Loaded AnnData with ``obs.index`` reset to ``RangeIndex``.
    """
    with warnings.catch_warnings():
        warnings.filterwarnings("ignore", message="Observation names are not unique")
        adata = ad.read_zarr(zarr_path)
    adata.obs.index = pd.RangeIndex(adata.n_obs).astype(str)
    return adata


def get_2d_embedding(adata: ad.AnnData, key: str, components: tuple[int, int]) -> np.ndarray:
    """Return a 2D slice of an obsm embedding.

    Parameters
    ----------
    adata : AnnData
        Embeddings object.
    key : str
        ``obsm`` key (e.g. ``"X_phate_combined"``, ``"X_pca_combined"``).
    components : tuple of int
        Two 0-indexed component indices.

    Returns
    -------
    np.ndarray
        Array of shape ``(n_obs, 2)``.
    """
    emb = adata.obsm[key]
    return np.stack([emb[:, components[0]], emb[:, components[1]]], axis=1)


def track_groups(adata: ad.AnnData) -> pd.core.groupby.DataFrameGroupBy:
    """Return a groupby over unique tracks sorted by time.

    Tracks are identified by ``(fov_name, track_id)`` and sorted by ``t``.
    """
    df = adata.obs[["fov_name", "track_id", "t", "perturbation", "hours_post_perturbation"]].copy()
    df["row"] = np.arange(len(df))
    df = df.sort_values(["fov_name", "track_id", "t"])
    return df.groupby(["fov_name", "track_id"], sort=False, observed=True)


def ensure_outdir(path: Path) -> Path:
    """Create ``path`` (and parents) if missing and return it."""
    path.mkdir(parents=True, exist_ok=True)
    return path


def attach_phate_parquet(
    adata: ad.AnnData,
    parquet_path: Path,
    key: str = "X_phate",
) -> None:
    """Attach a per-channel PHATE parquet to ``adata.obsm[key]``.

    The parquet must have columns ``fov_name``, ``track_id``, ``t``,
    ``phate_0``, ``phate_1``. Rows in ``adata`` missing from the parquet
    get NaN coordinates.

    Useful for newer prediction artifacts where ``X_phate_combined`` is
    not pre-baked into the zarr — compute PHATE locally with
    ``compute_phase3d_phate.py`` and attach here at plot time.
    """
    df = pd.read_parquet(parquet_path)
    obs_keys = list(
        zip(
            adata.obs["fov_name"].astype(str),
            adata.obs["track_id"].astype(int),
            adata.obs["t"].astype(int),
        )
    )
    pq_keys = list(
        zip(
            df["fov_name"].astype(str),
            df["track_id"].astype(int),
            df["t"].astype(int),
        )
    )
    pos = {k: i for i, k in enumerate(pq_keys)}
    coords = np.full((adata.n_obs, 2), np.nan, dtype=np.float32)
    p0 = df["phate_0"].to_numpy()
    p1 = df["phate_1"].to_numpy()
    for j, k in enumerate(obs_keys):
        i = pos.get(k, -1)
        if i >= 0:
            coords[j, 0] = p0[i]
            coords[j, 1] = p1[i]
    adata.obsm[key] = coords
