"""Panel B: embedding scatter colored by time since perturbation.

Key comparison panel — a smooth, directional gradient indicates the training
strategy captured temporal dynamics. A scattered/uniform color distribution
indicates the embedding does not carry strong temporal structure.
"""

from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np

from _common import (
    DEFAULT_OUTPUT_DIR,
    DEFAULT_ZARR,
    ensure_outdir,
    get_2d_embedding,
    load_embedding,
)


def plot(
    zarr_path: Path,
    embedding_key: str,
    components: tuple[int, int],
    output_dir: Path,
    time_key: str = "hours_post_perturbation",
    point_size: float = 1.0,
    subsample: int | None = 50_000,
    per_condition: bool = True,
    seed: int = 0,
) -> Path:
    """Scatter the 2D embedding colored by time since perturbation.

    Parameters
    ----------
    zarr_path : Path
        Embedding AnnData zarr.
    embedding_key : str
        Key in ``adata.obsm``.
    components : tuple of int
        Two 0-indexed components to plot.
    output_dir : Path
        Directory for the output PNG.
    time_key : str
        ``obs`` column used for the color axis.
    point_size : float
        Marker size.
    subsample : int or None
        Random subsample size (applied before faceting).
    per_condition : bool
        If True, produce one subplot per perturbation. If False, pool
        all conditions into one axes.
    seed : int
        RNG seed.

    Returns
    -------
    Path
        Path to the saved figure.
    """
    adata = load_embedding(zarr_path)
    xy = get_2d_embedding(adata, embedding_key, components)
    t = adata.obs[time_key].to_numpy()
    cond = adata.obs["perturbation"].to_numpy()

    rng = np.random.default_rng(seed)
    if subsample is not None and subsample < len(xy):
        idx = rng.choice(len(xy), size=subsample, replace=False)
    else:
        idx = np.arange(len(xy))
    idx = rng.permutation(idx)

    vmin, vmax = float(np.min(t)), float(np.max(t))

    if per_condition:
        conditions = [c for c in np.unique(cond)]
        ncols = len(conditions)
        fig, axes = plt.subplots(
            1, ncols, figsize=(4.0 * ncols, 4.0), constrained_layout=True, sharex=True, sharey=True
        )
        if ncols == 1:
            axes = np.array([axes])
        sc = None
        for ax, c in zip(axes, conditions):
            mask = cond[idx] == c
            sc = ax.scatter(
                xy[idx][mask, 0],
                xy[idx][mask, 1],
                s=point_size,
                c=t[idx][mask],
                cmap="viridis",
                vmin=vmin,
                vmax=vmax,
                alpha=0.6,
                linewidths=0,
            )
            ax.set_title(f"{c} (n={(cond == c).sum()})", fontsize=9)
            ax.set_xlabel(f"{embedding_key} [{components[0]}]")
        axes[0].set_ylabel(f"{embedding_key} [{components[1]}]")
        cbar = fig.colorbar(sc, ax=axes, shrink=0.8, pad=0.02)
        cbar.set_label(time_key)
        fig.suptitle("Panel B — embeddings colored by time since perturbation", y=1.03)
    else:
        fig, ax = plt.subplots(figsize=(6.5, 6), constrained_layout=True)
        sc = ax.scatter(
            xy[idx, 0],
            xy[idx, 1],
            s=point_size,
            c=t[idx],
            cmap="viridis",
            vmin=vmin,
            vmax=vmax,
            alpha=0.5,
            linewidths=0,
        )
        ax.set_xlabel(f"{embedding_key} [{components[0]}]")
        ax.set_ylabel(f"{embedding_key} [{components[1]}]")
        ax.set_title("Panel B — embeddings colored by time")
        cbar = fig.colorbar(sc, ax=ax)
        cbar.set_label(time_key)

    ensure_outdir(output_dir)
    suffix = "percond" if per_condition else "pooled"
    out = output_dir / f"panel_B_by_time_{embedding_key}_{suffix}.png"
    fig.savefig(out, dpi=200)
    plt.close(fig)
    return out


def main() -> None:
    """CLI entry point."""
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--zarr", type=Path, default=DEFAULT_ZARR)
    p.add_argument("--embedding-key", default="X_phate_combined")
    p.add_argument("--components", type=int, nargs=2, default=(0, 1))
    p.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT_DIR)
    p.add_argument("--time-key", default="hours_post_perturbation")
    p.add_argument("--subsample", type=int, default=50_000)
    p.add_argument("--point-size", type=float, default=1.0)
    p.add_argument("--pooled", action="store_true", help="one combined panel instead of per-condition facets")
    args = p.parse_args()

    out = plot(
        args.zarr,
        args.embedding_key,
        tuple(args.components),
        args.output_dir,
        time_key=args.time_key,
        point_size=args.point_size,
        subsample=args.subsample,
        per_condition=not args.pooled,
    )
    print(f"wrote {out}")


if __name__ == "__main__":
    main()
