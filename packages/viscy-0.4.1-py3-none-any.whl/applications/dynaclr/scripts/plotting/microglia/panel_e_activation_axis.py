"""Discover an activation axis in the DynaCLR embedding without labels.

Two label-free derivations, then validation by overlay:

1. **Per-cell displacement from t=0** — for each tracked cell, the embedding
   distance from its own first frame. A cell whose displacement grows is
   moving through embedding space; one whose displacement stays small is
   stable. No reference state, no treatment labels — only the cell's own
   trajectory.

2. **Principal axis of within-track motion (PC1-of-motion)** — across all
   tracks, pool the per-frame displacement vectors ``Δf(t) = f(t) − f(t-1)``
   and run PCA. PC1 is the direction along which cells move fastest in the
   embedding. Projecting every cell onto this direction gives a 1-D
   activation score that uses no labels.

Then we overlay treatment condition (untreated, IL-17, IFN-β, GBM, Rubella)
post-hoc to ask whether the discovered axis aligns with known biology.

Outputs (under ``--output-dir``)
-------------------------------
- ``activation_axis_summary.json`` — the PC1-of-motion vector, mean t=0
  displacement per condition, etc. (saved for downstream re-use).
- ``displacement_vs_time.png`` — embedding displacement from t=0 per
  condition (Panel-D style but on the embedding, not on PCA-32).
- ``activation_score_kde.png`` — KDE of the activation score per condition.
- ``trajectory_space.png`` — joint plot of (displacement, activation score)
  per condition.
- ``extreme_cells_<low|high>_<cond>.csv`` — sampled cell-frames at each
  end of the activation axis, per condition, for downstream phase-contrast
  inspection.

The script is purely DynaCLR-only (no Wu features, no real-space speed) —
the activation axis is derived from the embedding's training signal
(temporal smoothness) and validated post-hoc.
"""

from __future__ import annotations

import argparse
import json
import warnings
from pathlib import Path

import anndata as ad
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from _common import CONDITION_COLORS, attach_phate_parquet, ensure_outdir


def per_cell_displacement_from_t0(adata: ad.AnnData, time_key: str) -> np.ndarray:
    """Embedding displacement from each cell's own t=0 frame, per cell-frame.

    L2 distance in the raw 768-d embedding (not L2-normalized, so the
    measurement is in the model's native scale). Cells with no t=0 anchor
    (their first observed timepoint) are anchored to whatever their
    earliest observed frame is.

    Parameters
    ----------
    adata : AnnData
        Embedding object.
    time_key : str
        ``obs`` column for time (hours).

    Returns
    -------
    np.ndarray
        Per-frame displacement, length n_obs.
    """
    feats = np.asarray(adata.X, dtype=np.float32)
    obs = adata.obs[["fov_name", "track_id", "t", time_key]].reset_index(drop=True)
    obs["row"] = np.arange(len(obs))
    disp = np.zeros(len(obs), dtype=np.float32)
    for _, sub in obs.groupby(["fov_name", "track_id"], sort=False, observed=True):
        sub = sub.sort_values("t")
        rows = sub["row"].to_numpy()
        ref = feats[rows[0]]
        disp[rows] = np.linalg.norm(feats[rows] - ref, axis=1)
    return disp


def pc1_of_motion(adata: ad.AnnData) -> tuple[np.ndarray, float, np.ndarray]:
    """Principal axis of within-track displacement vectors.

    Pools ``Δf(t) = f(t) − f(t-1)`` across all tracks, runs an SVD on the
    centered matrix, and returns the right-singular vector with the
    largest singular value.

    Parameters
    ----------
    adata : AnnData
        Embedding object.

    Returns
    -------
    direction : np.ndarray
        Unit vector in the embedding space (shape (D,)).
    explained_var_ratio : float
        Fraction of total within-track motion variance explained by PC1.
    sing_values : np.ndarray
        Top-10 singular values (for diagnostic plots).
    """
    feats = np.asarray(adata.X, dtype=np.float32)
    obs = adata.obs[["fov_name", "track_id", "t"]].reset_index(drop=True)
    obs["row"] = np.arange(len(obs))

    deltas: list[np.ndarray] = []
    for _, sub in obs.groupby(["fov_name", "track_id"], sort=False, observed=True):
        if len(sub) < 2:
            continue
        sub = sub.sort_values("t")
        rows = sub["row"].to_numpy()
        f = feats[rows]
        deltas.append(f[1:] - f[:-1])
    Δ = np.concatenate(deltas, axis=0)
    print(f"PC1-of-motion: pooled {Δ.shape[0]} delta vectors of dim {Δ.shape[1]}")

    Δ -= Δ.mean(axis=0, keepdims=True)
    # Use randomized SVD via numpy for tractability on ~10^6 × 768
    # Direct SVD on the covariance matrix (768 × 768) is fast.
    cov = (Δ.T @ Δ) / max(len(Δ) - 1, 1)
    eigvals, eigvecs = np.linalg.eigh(cov)
    # eigh returns ascending; reverse
    order = np.argsort(eigvals)[::-1]
    eigvals = eigvals[order]
    eigvecs = eigvecs[:, order]
    direction = eigvecs[:, 0]
    explained = float(eigvals[0] / eigvals.sum())
    return direction, explained, np.sqrt(np.maximum(eigvals[:10], 0.0))


def project(feats: np.ndarray, direction: np.ndarray) -> np.ndarray:
    """Project rows of ``feats`` onto a unit ``direction``."""
    return feats @ direction


def plot_displacement_vs_time(
    adata: ad.AnnData,
    disp: np.ndarray,
    time_key: str,
    n_bins: int,
) -> plt.Figure:
    """Mean ± std displacement-from-t0 vs. time, per condition."""
    df = pd.DataFrame(
        {
            "perturbation": adata.obs["perturbation"].to_numpy(),
            "t": adata.obs[time_key].to_numpy(),
            "disp": disp,
        }
    )
    edges = np.linspace(float(df["t"].min()), float(df["t"].max()), n_bins + 1)
    df["bin"] = pd.cut(df["t"], bins=edges, include_lowest=True)
    df["t_center"] = df["bin"].apply(lambda iv: 0.5 * (iv.left + iv.right)).astype(float)

    fig, ax = plt.subplots(figsize=(7.5, 5.0), constrained_layout=True)
    for c, color in CONDITION_COLORS.items():
        sub = (
            df[df["perturbation"] == c]
            .groupby("t_center", observed=True)["disp"]
            .agg(["mean", "std"])
            .reset_index()
        )
        if sub.empty:
            continue
        x = sub["t_center"].to_numpy()
        m = sub["mean"].to_numpy()
        s = sub["std"].to_numpy()
        ax.plot(x, m, "-", color=color, linewidth=2, label=c)
        ax.fill_between(x, m - s, m + s, color=color, alpha=0.15, linewidth=0)
    ax.set_xlabel(time_key)
    ax.set_ylabel("embedding displacement from t=0 (L2)")
    ax.set_title("Per-cell embedding displacement vs. time, by condition")
    ax.legend(frameon=False, fontsize=9)
    return fig


def plot_kde_by_condition(
    values: np.ndarray,
    conditions: np.ndarray,
    axis_label: str,
    title: str,
) -> plt.Figure:
    """KDE-style condition density along a 1-D projection."""
    valid = np.isfinite(values)
    qx0, qx1 = float(np.quantile(values[valid], 0.005)), float(np.quantile(values[valid], 0.995))
    fig, ax = plt.subplots(figsize=(8.0, 4.5), constrained_layout=True)
    for c in CONDITION_COLORS:
        m = valid & (conditions == c)
        if m.sum() < 100:
            continue
        sub = values[m]
        h, edges = np.histogram(sub, bins=200, range=(qx0, qx1), density=True)
        x = 0.5 * (edges[:-1] + edges[1:])
        kernel = np.exp(-0.5 * (np.linspace(-3, 3, 9)) ** 2)
        kernel /= kernel.sum()
        h_s = np.convolve(h, kernel, mode="same")
        ax.plot(x, h_s, "-", color=CONDITION_COLORS[c], linewidth=1.6, label=f"{c} (n={int(m.sum())})")
    ax.set_xlabel(axis_label)
    ax.set_ylabel("density")
    ax.set_title(title)
    ax.legend(frameon=False, fontsize=8)
    return fig


def plot_trajectory_space(
    disp: np.ndarray,
    activation: np.ndarray,
    conditions: np.ndarray,
    subsample: int,
    seed: int,
) -> plt.Figure:
    """Joint scatter (displacement-from-t0, activation score) per condition."""
    rng = np.random.default_rng(seed)
    cond_set = [c for c in CONDITION_COLORS if c in np.unique(conditions)]
    fig, axes = plt.subplots(
        1,
        len(cond_set),
        figsize=(3.6 * len(cond_set), 3.8),
        constrained_layout=True,
        sharex=True,
        sharey=True,
    )
    if len(cond_set) == 1:
        axes = np.array([axes])

    qx1 = float(np.nanquantile(disp, 0.99))
    qy0 = float(np.nanquantile(activation, 0.005))
    qy1 = float(np.nanquantile(activation, 0.995))

    for ax, c in zip(axes, cond_set):
        m = conditions == c
        idx = np.where(m)[0]
        if subsample < len(idx):
            idx = rng.choice(idx, size=subsample, replace=False)
        ax.hexbin(
            disp[idx],
            activation[idx],
            gridsize=60,
            extent=(0, qx1, qy0, qy1),
            cmap="magma",
            mincnt=1,
        )
        ax.set_title(f"{c} (n={int(m.sum())})", fontsize=9)
        ax.set_xlabel("displacement from t=0")
    axes[0].set_ylabel("activation score (PC1-of-motion projection)")
    fig.suptitle("Trajectory space — displacement vs. activation score by condition", y=1.04)
    return fig


def sample_extremes(
    obs: pd.DataFrame,
    activation: np.ndarray,
    conditions: np.ndarray,
    time_key: str,
    n_per_condition: int,
    late_frac: float,
    seed: int,
) -> dict[str, dict[str, pd.DataFrame]]:
    """Pick top/bottom cells along the activation axis, restricted to late frames.

    "Late frames" means the last ``late_frac`` of each cell's observed
    lifetime — that's where states have settled, so endpoint sampling is
    most diagnostic. Returns ``{condition: {"high": df, "low": df}}``
    with columns ``fov_name``, ``track_id``, ``t``, ``activation``.
    """
    rng = np.random.default_rng(seed)
    # mark late-frame mask per track
    df = obs[["fov_name", "track_id", "t"]].copy()
    df["row"] = np.arange(len(df))
    df["activation"] = activation
    df["perturbation"] = conditions

    # cutoff per track: keep frames whose t is >= (t_max - late_frac * (t_max - t_min))
    grp = df.groupby(["fov_name", "track_id"], observed=True)
    t_min = grp["t"].transform("min")
    t_max = grp["t"].transform("max")
    cutoff = t_max - late_frac * (t_max - t_min)
    df["is_late"] = df["t"] >= cutoff

    out: dict[str, dict[str, pd.DataFrame]] = {}
    for c in CONDITION_COLORS:
        sub = df[(df["perturbation"] == c) & df["is_late"] & np.isfinite(df["activation"])]
        if len(sub) == 0:
            continue
        high = sub.nlargest(n_per_condition, "activation")[["fov_name", "track_id", "t", "activation"]]
        low = sub.nsmallest(n_per_condition, "activation")[["fov_name", "track_id", "t", "activation"]]
        out[c] = {"high": high.reset_index(drop=True), "low": low.reset_index(drop=True)}
    return out


def run(
    zarr_path: Path,
    output_dir: Path,
    time_key: str,
    n_time_bins: int,
    subsample: int,
    n_extreme_per_condition: int,
    late_frac: float,
    phate_parquet: Path | None,
    seed: int,
) -> list[Path]:
    """Run the activation-axis discovery end-to-end."""
    with warnings.catch_warnings():
        warnings.filterwarnings("ignore", message="Observation names are not unique")
        adata = ad.read_zarr(zarr_path)
    adata.obs.index = pd.RangeIndex(adata.n_obs).astype(str)
    print(f"loaded {zarr_path.name}: n_obs={adata.n_obs}, X={adata.X.shape}")

    if phate_parquet is not None:
        attach_phate_parquet(adata, phate_parquet, key="X_phate")
        print(f"attached PHATE from {phate_parquet}")

    print("\n[1/2] computing per-cell displacement from t=0")
    disp = per_cell_displacement_from_t0(adata, time_key)

    print("\n[2/2] computing PC1-of-motion (pooled within-track Δf)")
    direction, explained, sigmas = pc1_of_motion(adata)
    print(f"PC1 explains {100 * explained:.1f}% of within-track motion variance")
    print(f"top-10 singular values: {np.round(sigmas, 3).tolist()}")

    feats = np.asarray(adata.X, dtype=np.float32)
    activation = project(feats, direction)
    cond = adata.obs["perturbation"].to_numpy()

    ensure_outdir(output_dir)
    paths: list[Path] = []

    summary = {
        "n_obs": int(adata.n_obs),
        "embedding_dim": int(feats.shape[1]),
        "pc1_motion_explained_var_ratio": float(explained),
        "top10_singular_values": np.round(sigmas, 4).tolist(),
        "mean_disp_per_condition": {
            c: float(np.nanmean(disp[cond == c])) for c in CONDITION_COLORS if (cond == c).any()
        },
        "median_activation_per_condition": {
            c: float(np.nanmedian(activation[cond == c])) for c in CONDITION_COLORS if (cond == c).any()
        },
    }
    p = output_dir / "activation_axis_summary.json"
    with p.open("w") as fh:
        json.dump(summary, fh, indent=2)
    paths.append(p)

    direction_path = output_dir / "activation_axis_direction.npy"
    np.save(direction_path, direction)
    paths.append(direction_path)

    fig_d = plot_displacement_vs_time(adata, disp, time_key, n_time_bins)
    p = output_dir / "displacement_vs_time.png"
    fig_d.savefig(p, dpi=200)
    plt.close(fig_d)
    paths.append(p)

    fig_kde = plot_kde_by_condition(
        activation, cond, axis_label="activation score (PC1-of-motion projection)",
        title=f"Activation score per condition (PC1 explains {100*explained:.1f}% of motion variance)",
    )
    p = output_dir / "activation_score_kde.png"
    fig_kde.savefig(p, dpi=200)
    plt.close(fig_kde)
    paths.append(p)

    fig_disp_kde = plot_kde_by_condition(
        disp, cond, axis_label="embedding displacement from t=0",
        title="Per-frame displacement-from-t0 distribution per condition",
    )
    p = output_dir / "displacement_kde.png"
    fig_disp_kde.savefig(p, dpi=200)
    plt.close(fig_disp_kde)
    paths.append(p)

    fig_traj = plot_trajectory_space(disp, activation, cond, subsample, seed)
    p = output_dir / "trajectory_space.png"
    fig_traj.savefig(p, dpi=200)
    plt.close(fig_traj)
    paths.append(p)

    print("\nsampling extreme cells (late frames only) per condition")
    obs = adata.obs.reset_index(drop=True)
    extremes = sample_extremes(obs, activation, cond, time_key, n_extreme_per_condition, late_frac, seed)
    for c, dfs in extremes.items():
        for tag in ("high", "low"):
            p = output_dir / f"extreme_cells_{tag}_{c.replace(' ', '_')}.csv"
            dfs[tag].to_csv(p, index=False)
            paths.append(p)

    print("\n### Median activation score per condition")
    rows = [
        {
            "condition": c,
            "n_cells": int((cond == c).sum()),
            "median_activation": float(np.nanmedian(activation[cond == c])),
            "mean_displacement": float(np.nanmean(disp[cond == c])),
        }
        for c in CONDITION_COLORS
        if (cond == c).any()
    ]
    table = pd.DataFrame(rows).sort_values("median_activation").reset_index(drop=True)
    print(table.round(3).to_markdown(index=False))
    p = output_dir / "activation_axis_per_condition.csv"
    table.to_csv(p, index=False)
    paths.append(p)

    return paths


def main() -> None:
    """CLI entry point."""
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--zarr", type=Path, required=True)
    p.add_argument("--output-dir", type=Path, required=True)
    p.add_argument("--time-key", default="hours_post_perturbation")
    p.add_argument("--n-time-bins", type=int, default=24)
    p.add_argument("--subsample", type=int, default=80_000)
    p.add_argument("--n-extreme-per-condition", type=int, default=50)
    p.add_argument(
        "--late-frac",
        type=float,
        default=0.25,
        help="Use the last fraction of each track for extreme-cell sampling (default 25%%).",
    )
    p.add_argument(
        "--phate-parquet",
        type=Path,
        default=None,
        help="Optional per-channel PHATE parquet to attach (used downstream by other panels).",
    )
    p.add_argument("--seed", type=int, default=0)
    args = p.parse_args()

    out = run(
        args.zarr,
        args.output_dir,
        time_key=args.time_key,
        n_time_bins=args.n_time_bins,
        subsample=args.subsample,
        n_extreme_per_condition=args.n_extreme_per_condition,
        late_frac=args.late_frac,
        phate_parquet=args.phate_parquet,
        seed=args.seed,
    )
    for p_ in out:
        print(f"wrote {p_}")


if __name__ == "__main__":
    main()
