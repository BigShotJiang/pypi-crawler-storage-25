"""Panel D: per-track displacement from t=0 in embedding space, aggregated by condition.

Quantifies how fast/far each stimulus drives microglia morphotype. Displacement
is the Euclidean distance in the chosen embedding between a track's sample at
time ``t`` and the same track's earliest observed sample. Curves are binned in
``hours_post_perturbation`` and plotted as mean ± std per condition.

Compare time-aware vs. classical here: tight bands with smooth monotonic
trajectories -> the embedding carries temporal signal; wide noisy bands ->
it does not.
"""

from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from _common import (
    CONDITION_COLORS,
    DEFAULT_OUTPUT_DIR,
    DEFAULT_ZARR,
    ensure_outdir,
    load_embedding,
)


def compute_displacement(
    adata,
    embedding_key: str,
    time_key: str = "hours_post_perturbation",
    n_components: int | None = None,
) -> pd.DataFrame:
    """Compute per-observation displacement from each track's t=0 sample.

    Parameters
    ----------
    adata : AnnData
        Embeddings object.
    embedding_key : str
        Either ``"X"`` for the full feature vector, or a key in ``obsm``.
    time_key : str
        ``obs`` column to report alongside displacement.
    n_components : int or None
        If set, only the first ``n_components`` dimensions are used.

    Returns
    -------
    pandas.DataFrame
        Columns: ``fov_name``, ``track_id``, ``perturbation``, ``t``,
        ``time_key``, ``displacement``.
    """
    if embedding_key == "X":
        feats = np.asarray(adata.X)
    else:
        feats = np.asarray(adata.obsm[embedding_key])
    if n_components is not None:
        feats = feats[:, :n_components]

    obs = adata.obs[["fov_name", "track_id", "t", "perturbation", time_key]].reset_index(drop=True)
    obs["row"] = np.arange(len(obs))

    disp = np.zeros(len(obs), dtype=np.float32)
    for _, sub in obs.groupby(["fov_name", "track_id"], sort=False, observed=True):
        sub = sub.sort_values("t")
        rows = sub["row"].to_numpy()
        ref = feats[rows[0]]
        disp[rows] = np.linalg.norm(feats[rows] - ref, axis=1)

    obs["displacement"] = disp
    return obs


def plot(
    zarr_path: Path,
    embedding_key: str,
    output_dir: Path,
    time_key: str = "hours_post_perturbation",
    n_components: int | None = 32,
    n_bins: int = 24,
    min_track_length: int = 20,
) -> Path:
    """Compute and plot mean ± std displacement vs. time for each condition.

    Parameters
    ----------
    zarr_path : Path
        Embedding AnnData zarr.
    embedding_key : str
        ``"X"`` or a key in ``obsm`` (e.g. ``"X_pca_combined"``).
    output_dir : Path
        Directory for the output PNG and CSV.
    time_key : str
        ``obs`` column used for the x-axis.
    n_components : int or None
        Restrict the displacement norm to the first ``n_components``
        dimensions (defaults to 32 for ``X_pca_combined``).
    n_bins : int
        Number of equal-width time bins over ``[t_min, t_max]``.
    min_track_length : int
        Tracks shorter than this are dropped before aggregation.

    Returns
    -------
    Path
        Path to the saved figure.
    """
    adata = load_embedding(zarr_path)

    df = compute_displacement(adata, embedding_key, time_key=time_key, n_components=n_components)

    lengths = df.groupby(["fov_name", "track_id"], observed=True)["t"].transform("size")
    df = df[lengths >= min_track_length].copy()

    t = df[time_key].to_numpy()
    bin_edges = np.linspace(float(t.min()), float(t.max()), n_bins + 1)
    df["time_bin"] = pd.cut(df[time_key], bins=bin_edges, include_lowest=True)

    agg = (
        df.groupby(["perturbation", "time_bin"], observed=True)["displacement"]
        .agg(["mean", "std", "count"])
        .reset_index()
    )
    agg["t_center"] = agg["time_bin"].apply(lambda iv: 0.5 * (iv.left + iv.right))

    fig, ax = plt.subplots(figsize=(7.0, 5.0), constrained_layout=True)
    for cond, color in CONDITION_COLORS.items():
        sub = agg[agg["perturbation"] == cond].sort_values("t_center")
        if sub.empty:
            continue
        mean = sub["mean"].to_numpy()
        std = sub["std"].to_numpy()
        x = sub["t_center"].to_numpy()
        ax.plot(x, mean, "-", color=color, linewidth=2, label=cond)
        ax.fill_between(x, mean - std, mean + std, color=color, alpha=0.2, linewidth=0)

    ax.set_xlabel(time_key)
    label_suffix = embedding_key if n_components is None else f"{embedding_key}[:{n_components}]"
    ax.set_ylabel(f"displacement from t=0 in {label_suffix} (Euclidean)")
    ax.set_title("Panel D — morphotype displacement vs. time, by condition")
    ax.legend(frameon=False, fontsize=9)

    ensure_outdir(output_dir)
    tag = embedding_key if n_components is None else f"{embedding_key}_d{n_components}"
    fig_path = output_dir / f"panel_D_displacement_{tag}.png"
    csv_path = output_dir / f"panel_D_displacement_{tag}.csv"
    fig.savefig(fig_path, dpi=200)
    plt.close(fig)
    agg.drop(columns=["time_bin"]).to_csv(csv_path, index=False)
    return fig_path


def main() -> None:
    """CLI entry point."""
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--zarr", type=Path, default=DEFAULT_ZARR)
    p.add_argument(
        "--embedding-key",
        default="X_pca_combined",
        help="'X' for full features, or an obsm key (default X_pca_combined).",
    )
    p.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT_DIR)
    p.add_argument("--time-key", default="hours_post_perturbation")
    p.add_argument("--n-components", type=int, default=32)
    p.add_argument("--n-bins", type=int, default=24)
    p.add_argument("--min-track-length", type=int, default=20)
    args = p.parse_args()

    out = plot(
        args.zarr,
        args.embedding_key,
        args.output_dir,
        time_key=args.time_key,
        n_components=args.n_components if args.n_components > 0 else None,
        n_bins=args.n_bins,
        min_track_length=args.min_track_length,
    )
    print(f"wrote {out}")


if __name__ == "__main__":
    main()
