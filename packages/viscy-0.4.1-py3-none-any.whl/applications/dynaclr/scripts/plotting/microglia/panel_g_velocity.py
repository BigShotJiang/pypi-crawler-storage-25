"""Panel G: embedding-space velocity colored on PHATE.

For each cell-timepoint we compute the local speed of morphotype change
as the central difference of the learned features, in PCA-32 space (PHATE
distances are not metric). The PHATE scatter is then colored by this speed
per condition, plus an aggregated density-weighted comparison panel.

Interpretation: fast regions = morphotype-changing states; slow regions =
stable states / attractors. Two conditions that share a cluster can still
differ in how fast their cells traverse it.
"""

from __future__ import annotations

import argparse
from pathlib import Path

import anndata as ad
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from _common import (
    CONDITION_COLORS,
    DEFAULT_OUTPUT_DIR,
    DEFAULT_ZARR,
    ensure_outdir,
    load_embedding,
)


def compute_speed(
    adata: ad.AnnData,
    feature_key: str,
    n_components: int | None,
    time_key: str,
) -> np.ndarray:
    """Central-difference speed per observation in feature space.

    Speed at ``t`` = ``||f[t+1] - f[t-1]|| / (time[t+1] - time[t-1])``.
    Endpoints of each track fall back to a forward/backward difference.
    Tracks of length 1 get NaN.

    Parameters
    ----------
    adata : AnnData
        Embedding object.
    feature_key : str
        ``"X"`` or an ``obsm`` key; PCA-32 is the usual choice.
    n_components : int or None
        Truncate the feature vector to the first ``n_components`` dims.
    time_key : str
        ``obs`` column in hours used for the time delta in the central
        difference denominator.

    Returns
    -------
    np.ndarray
        Speed in feature-norm units per hour; length ``n_obs``.
    """
    if feature_key == "X":
        feats = np.asarray(adata.X)
    else:
        feats = np.asarray(adata.obsm[feature_key])
    if n_components is not None:
        feats = feats[:, :n_components]

    obs = adata.obs[["fov_name", "track_id", "t", time_key]].reset_index(drop=True)
    obs["row"] = np.arange(len(obs))

    speed = np.full(len(obs), np.nan, dtype=np.float32)
    for _, sub in obs.groupby(["fov_name", "track_id"], sort=False, observed=True):
        sub = sub.sort_values("t")
        rows = sub["row"].to_numpy()
        times = sub[time_key].to_numpy().astype(np.float32)
        f = feats[rows]
        n = len(rows)
        if n < 2:
            continue
        if n == 2:
            d = np.linalg.norm(f[1] - f[0])
            dt = max(times[1] - times[0], 1e-6)
            speed[rows[0]] = d / dt
            speed[rows[1]] = d / dt
            continue
        # central difference for interior
        diffs = np.linalg.norm(f[2:] - f[:-2], axis=1)
        dts = np.maximum(times[2:] - times[:-2], 1e-6)
        speed[rows[1:-1]] = diffs / dts
        # forward / backward at the ends
        speed[rows[0]] = np.linalg.norm(f[1] - f[0]) / max(times[1] - times[0], 1e-6)
        speed[rows[-1]] = np.linalg.norm(f[-1] - f[-2]) / max(times[-1] - times[-2], 1e-6)
    return speed


def plot_speed_on_phate(
    adata: ad.AnnData,
    speed: np.ndarray,
    components: tuple[int, int],
    subsample: int,
    seed: int,
    vmin: float,
    vmax: float,
) -> plt.Figure:
    """Per-condition PHATE scatter colored by speed."""
    rng = np.random.default_rng(seed)
    xy = adata.obsm["X_phate_combined"]
    cond = adata.obs["perturbation"].to_numpy()
    conditions = [c for c in CONDITION_COLORS if c in np.unique(cond)]

    fig, axes = plt.subplots(
        1,
        len(conditions),
        figsize=(4.2 * len(conditions), 4.2),
        constrained_layout=True,
        sharex=True,
        sharey=True,
    )
    if len(conditions) == 1:
        axes = np.array([axes])

    sc = None
    for ax, c in zip(axes, conditions):
        mask = cond == c
        idx_c = np.where(mask)[0]
        if subsample < len(idx_c):
            idx_c = rng.choice(idx_c, size=subsample, replace=False)
        idx_c = rng.permutation(idx_c)
        s = speed[idx_c]
        sc = ax.scatter(
            xy[idx_c, components[0]],
            xy[idx_c, components[1]],
            s=1.2,
            c=s,
            cmap="magma",
            vmin=vmin,
            vmax=vmax,
            alpha=0.7,
            linewidths=0,
        )
        ax.set_title(f"{c} (n={mask.sum()})", fontsize=9)
        ax.set_xlabel(f"X_phate_combined [{components[0]}]")
    axes[0].set_ylabel(f"X_phate_combined [{components[1]}]")
    cbar = fig.colorbar(sc, ax=axes, shrink=0.8, pad=0.02)
    cbar.set_label("speed (feature L2 / hour)")
    fig.suptitle("Panel G — embedding-space velocity by condition", y=1.03)
    return fig


def plot_speed_distribution(adata: ad.AnnData, speed: np.ndarray) -> plt.Figure:
    """Per-condition speed distribution (ECDF + violin)."""
    df = pd.DataFrame({"perturbation": adata.obs["perturbation"].to_numpy(), "speed": speed})
    df = df.dropna()
    conditions = [c for c in CONDITION_COLORS if c in df["perturbation"].unique()]

    fig, (ax_v, ax_e) = plt.subplots(1, 2, figsize=(12, 4.5), constrained_layout=True)

    data = [df.loc[df["perturbation"] == c, "speed"].to_numpy() for c in conditions]
    parts = ax_v.violinplot(data, showmeans=False, showmedians=True)
    for i, pc in enumerate(parts["bodies"]):
        pc.set_facecolor(CONDITION_COLORS[conditions[i]])
        pc.set_alpha(0.6)
    ax_v.set_xticks(range(1, len(conditions) + 1))
    ax_v.set_xticklabels(conditions, rotation=20, ha="right")
    ax_v.set_ylabel("speed (feature L2 / hour)")
    ax_v.set_title("Speed distribution per condition")
    q99 = float(np.quantile(df["speed"], 0.99))
    ax_v.set_ylim(0, q99)

    for c in conditions:
        s = np.sort(df.loc[df["perturbation"] == c, "speed"].to_numpy())
        y = np.linspace(0, 1, len(s))
        ax_e.plot(s, y, "-", color=CONDITION_COLORS[c], label=c, linewidth=1.5)
    ax_e.set_xlabel("speed (feature L2 / hour)")
    ax_e.set_ylabel("cumulative fraction")
    ax_e.set_title("Speed ECDF")
    ax_e.set_xlim(0, q99)
    ax_e.legend(frameon=False, fontsize=8)

    return fig


def plot_speed_vs_time(
    adata: ad.AnnData, speed: np.ndarray, time_key: str, n_bins: int
) -> plt.Figure:
    """Mean ± std speed vs. time, per condition."""
    df = pd.DataFrame(
        {
            "perturbation": adata.obs["perturbation"].to_numpy(),
            "t": adata.obs[time_key].to_numpy(),
            "speed": speed,
        }
    ).dropna()
    edges = np.linspace(float(df["t"].min()), float(df["t"].max()), n_bins + 1)
    df["bin"] = pd.cut(df["t"], bins=edges, include_lowest=True)
    df["t_center"] = df["bin"].apply(lambda iv: 0.5 * (iv.left + iv.right)).astype(float)

    fig, ax = plt.subplots(figsize=(7.0, 5.0), constrained_layout=True)
    for c, color in CONDITION_COLORS.items():
        sub = (
            df[df["perturbation"] == c]
            .groupby("t_center", observed=True)["speed"]
            .agg(["mean", "std"])
            .reset_index()
        )
        if sub.empty:
            continue
        x = sub["t_center"].to_numpy()
        m = sub["mean"].to_numpy()
        s = sub["std"].to_numpy()
        ax.plot(x, m, "-", color=color, linewidth=2, label=c)
        ax.fill_between(x, m - s, m + s, color=color, alpha=0.15, linewidth=0)
    ax.set_xlabel(time_key)
    ax.set_ylabel("mean speed (feature L2 / hour)")
    ax.set_title("Panel G — morphotype speed vs. time, by condition")
    ax.legend(frameon=False, fontsize=9)
    return fig


def plot(
    zarr_path: Path,
    feature_key: str,
    n_components: int | None,
    output_dir: Path,
    subsample: int,
    n_time_bins: int,
    time_key: str,
    clip_quantile: float,
    seed: int,
) -> list[Path]:
    """Compute speed and produce the Panel-G figures.

    Parameters
    ----------
    zarr_path : Path
        Embedding zarr for one channel.
    feature_key : str
        ``"X"`` or an ``obsm`` key — space in which to compute speed.
    n_components : int or None
        Truncate to first ``n_components`` dims.
    output_dir : Path
        Destination.
    subsample : int
        Max points per condition in the PHATE scatter.
    n_time_bins : int
        Bins for the speed-vs-time plot.
    time_key : str
        ``obs`` column for time (hours).
    clip_quantile : float
        Upper quantile used to clip the colorbar for the PHATE speed scatter
        (avoids a handful of outliers flattening the colormap).
    seed : int
        RNG seed.

    Returns
    -------
    list of Path
        Saved figures.
    """
    adata = load_embedding(zarr_path)
    speed = compute_speed(adata, feature_key, n_components, time_key)
    finite = speed[np.isfinite(speed)]
    vmin = float(np.quantile(finite, 0.01))
    vmax = float(np.quantile(finite, clip_quantile))
    print(
        f"{zarr_path.name}: speed range [{finite.min():.3f}, {finite.max():.3f}], "
        f"clip [{vmin:.3f}, {vmax:.3f}]"
    )

    ensure_outdir(output_dir)
    tag_ft = feature_key if n_components is None else f"{feature_key}d{n_components}"
    tag = f"{zarr_path.stem}_{tag_ft}"
    paths: list[Path] = []
    for name, fig in [
        ("phate", plot_speed_on_phate(adata, speed, (0, 1), subsample, seed, vmin, vmax)),
        ("dist", plot_speed_distribution(adata, speed)),
        ("vs_time", plot_speed_vs_time(adata, speed, time_key, n_time_bins)),
    ]:
        out = output_dir / f"panel_G_{name}_{tag}.png"
        fig.savefig(out, dpi=200)
        plt.close(fig)
        paths.append(out)

    summary = (
        pd.DataFrame({"perturbation": adata.obs["perturbation"].to_numpy(), "speed": speed})
        .dropna()
        .groupby("perturbation", observed=True)["speed"]
        .agg(["mean", "median", "std", "count"])
    )
    csv = output_dir / f"panel_G_summary_{tag}.csv"
    summary.to_csv(csv)
    paths.append(csv)
    return paths


def main() -> None:
    """CLI entry point."""
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--zarr", type=Path, default=DEFAULT_ZARR)
    p.add_argument(
        "--feature-key",
        default="X_pca_combined",
        help="Space to compute speed in. Default X_pca_combined; use 'X' for full 768-d.",
    )
    p.add_argument("--n-components", type=int, default=32)
    p.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT_DIR)
    p.add_argument("--subsample", type=int, default=50_000)
    p.add_argument("--n-time-bins", type=int, default=24)
    p.add_argument("--time-key", default="hours_post_perturbation")
    p.add_argument("--clip-quantile", type=float, default=0.98)
    p.add_argument("--seed", type=int, default=0)
    args = p.parse_args()

    out = plot(
        args.zarr,
        args.feature_key,
        args.n_components if args.n_components > 0 else None,
        args.output_dir,
        subsample=args.subsample,
        n_time_bins=args.n_time_bins,
        time_key=args.time_key,
        clip_quantile=args.clip_quantile,
        seed=args.seed,
    )
    for p_ in out:
        print(f"wrote {p_}")


if __name__ == "__main__":
    main()
