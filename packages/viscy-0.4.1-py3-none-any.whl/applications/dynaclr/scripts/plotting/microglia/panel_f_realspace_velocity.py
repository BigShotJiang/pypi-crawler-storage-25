"""Panel F: real-space (image) velocity and its correlation with embedding velocity.

Wu et al. use image-space cell motility to stratify microglia states rather
than embedding-space velocity. This panel computes the same quantity here
— per-cell speed in the ``(x, y)`` pixel plane from tracking output — and
compares it to the embedding-space speed from Panel G.

Outputs
-------
- Per-condition PHATE scatter colored by real-space speed (are fast-moving
  cells clustered in a specific morphotype region?).
- Real-space tracks colored by instantaneous speed, one subplot per condition
  (do conditions differ in trajectory shape, not just displacement?).
- Speed distributions per condition (violin + ECDF), mean speed vs. time.
- Joint density of (real-space speed, embedding-space speed) plus per-track
  Spearman correlations — does morphotype change track physical motility?

Interpretation
--------------
If real-space and embedding speeds decorrelate, the embedding captures
morphology-change independent of migration. If they co-vary, part of the
embedding signal is driven by motility rather than intrinsic state.
"""

from __future__ import annotations

import argparse
from pathlib import Path

import anndata as ad
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.stats import spearmanr

from _common import (
    CONDITION_COLORS,
    DEFAULT_OUTPUT_DIR,
    DEFAULT_ZARR,
    ensure_outdir,
    load_embedding,
)
from panel_g_velocity import compute_speed as compute_embedding_speed


def compute_realspace_speed(
    adata: ad.AnnData,
    time_key: str,
    pixel_size_um: float | None,
) -> np.ndarray:
    """Central-difference speed in ``(x, y)`` image space per observation.

    Speed at ``t`` = ``||pos[t+1] - pos[t-1]|| / (time[t+1] - time[t-1])``.
    Endpoints use a forward/backward difference. Tracks of length 1 get NaN.

    Parameters
    ----------
    adata : AnnData
        Embedding object with ``obs`` columns ``x``, ``y``, ``fov_name``,
        ``track_id``, ``t`` and ``time_key``.
    time_key : str
        ``obs`` column in hours for the central-difference denominator.
    pixel_size_um : float or None
        If given, convert pixel displacement to micrometers. If ``None``
        the output is in pixels per hour.

    Returns
    -------
    np.ndarray
        Speed in pixels (or µm) per hour; length ``n_obs``.
    """
    pos = np.stack(
        [adata.obs["x"].to_numpy(dtype=np.float32), adata.obs["y"].to_numpy(dtype=np.float32)],
        axis=1,
    )
    if pixel_size_um is not None:
        pos = pos * float(pixel_size_um)

    obs = adata.obs[["fov_name", "track_id", "t", time_key]].reset_index(drop=True)
    obs["row"] = np.arange(len(obs))

    speed = np.full(len(obs), np.nan, dtype=np.float32)
    for _, sub in obs.groupby(["fov_name", "track_id"], sort=False, observed=True):
        sub = sub.sort_values("t")
        rows = sub["row"].to_numpy()
        times = sub[time_key].to_numpy().astype(np.float32)
        p = pos[rows]
        n = len(rows)
        if n < 2:
            continue
        if n == 2:
            d = float(np.linalg.norm(p[1] - p[0]))
            dt = max(times[1] - times[0], 1e-6)
            speed[rows[0]] = d / dt
            speed[rows[1]] = d / dt
            continue
        diffs = np.linalg.norm(p[2:] - p[:-2], axis=1)
        dts = np.maximum(times[2:] - times[:-2], 1e-6)
        speed[rows[1:-1]] = diffs / dts
        speed[rows[0]] = np.linalg.norm(p[1] - p[0]) / max(times[1] - times[0], 1e-6)
        speed[rows[-1]] = np.linalg.norm(p[-1] - p[-2]) / max(times[-1] - times[-2], 1e-6)
    return speed


def plot_realspeed_on_phate(
    adata: ad.AnnData,
    speed: np.ndarray,
    components: tuple[int, int],
    subsample: int,
    seed: int,
    vmin: float,
    vmax: float,
    unit_label: str,
) -> plt.Figure:
    """Per-condition PHATE scatter colored by real-space speed."""
    rng = np.random.default_rng(seed)
    xy = adata.obsm["X_phate_combined"]
    cond = adata.obs["perturbation"].to_numpy()
    conditions = [c for c in CONDITION_COLORS if c in np.unique(cond)]

    fig, axes = plt.subplots(
        1,
        len(conditions),
        figsize=(4.2 * len(conditions), 4.2),
        constrained_layout=True,
        sharex=True,
        sharey=True,
    )
    if len(conditions) == 1:
        axes = np.array([axes])

    sc = None
    for ax, c in zip(axes, conditions):
        mask = cond == c
        idx_c = np.where(mask)[0]
        if subsample < len(idx_c):
            idx_c = rng.choice(idx_c, size=subsample, replace=False)
        idx_c = rng.permutation(idx_c)
        s = speed[idx_c]
        sc = ax.scatter(
            xy[idx_c, components[0]],
            xy[idx_c, components[1]],
            s=1.2,
            c=s,
            cmap="viridis",
            vmin=vmin,
            vmax=vmax,
            alpha=0.7,
            linewidths=0,
        )
        ax.set_title(f"{c} (n={mask.sum()})", fontsize=9)
        ax.set_xlabel(f"X_phate_combined [{components[0]}]")
    axes[0].set_ylabel(f"X_phate_combined [{components[1]}]")
    cbar = fig.colorbar(sc, ax=axes, shrink=0.8, pad=0.02)
    cbar.set_label(f"real-space speed ({unit_label})")
    fig.suptitle("Panel F — real-space velocity by condition", y=1.03)
    return fig


def plot_realspace_tracks(
    adata: ad.AnnData,
    speed: np.ndarray,
    tracks_per_condition: int,
    min_length: int,
    seed: int,
    vmin: float,
    vmax: float,
    unit_label: str,
) -> plt.Figure:
    """Real-space ``(x, y)`` tracks per condition, colored by instantaneous speed."""
    rng = np.random.default_rng(seed)
    df = adata.obs[["fov_name", "track_id", "t", "perturbation", "x", "y"]].reset_index(drop=True)
    df["row"] = np.arange(len(df))
    conditions = [c for c in CONDITION_COLORS if c in df["perturbation"].unique()]

    fig, axes = plt.subplots(
        1,
        len(conditions),
        figsize=(4.2 * len(conditions), 4.4),
        constrained_layout=True,
    )
    if len(conditions) == 1:
        axes = np.array([axes])

    lc_last = None
    for ax, c in zip(axes, conditions):
        sub = df[df["perturbation"] == c]
        lengths = sub.groupby(["fov_name", "track_id"], observed=True)["t"].transform("size")
        sub = sub[lengths >= min_length]
        if sub.empty:
            ax.set_title(f"{c} (no tracks ≥ {min_length})", fontsize=9)
            continue
        keys = list(sub.groupby(["fov_name", "track_id"], observed=True).groups.keys())
        pick = rng.choice(len(keys), size=min(tracks_per_condition, len(keys)), replace=False)
        from matplotlib.collections import LineCollection

        for k_i in pick:
            fov, tid = keys[k_i]
            tr = sub[(sub["fov_name"] == fov) & (sub["track_id"] == tid)].sort_values("t")
            pts = np.column_stack([tr["x"].to_numpy(), tr["y"].to_numpy()])
            if len(pts) < 2:
                continue
            segs = np.stack([pts[:-1], pts[1:]], axis=1)
            seg_speed = 0.5 * (speed[tr["row"].to_numpy()[:-1]] + speed[tr["row"].to_numpy()[1:]])
            lc = LineCollection(segs, cmap="viridis", linewidth=1.1, alpha=0.85)
            lc.set_array(seg_speed)
            lc.set_clim(vmin, vmax)
            ax.add_collection(lc)
            ax.plot(pts[0, 0], pts[0, 1], "o", ms=3, mfc="white", mec="k", mew=0.4)
            ax.plot(pts[-1, 0], pts[-1, 1], "s", ms=3, mfc="black", mec="white", mew=0.4)
            lc_last = lc
        ax.set_aspect("equal", adjustable="datalim")
        ax.invert_yaxis()
        ax.set_title(f"{c} (showing {len(pick)})", fontsize=9)
        ax.set_xlabel("x (px)")
    axes[0].set_ylabel("y (px)")
    if lc_last is not None:
        cbar = fig.colorbar(lc_last, ax=axes, shrink=0.8, pad=0.02)
        cbar.set_label(f"real-space speed ({unit_label})")
    fig.suptitle("Panel F — real-space tracks colored by speed", y=1.03)
    return fig


def plot_realspeed_distribution(
    adata: ad.AnnData, speed: np.ndarray, unit_label: str
) -> plt.Figure:
    """Per-condition real-space speed distribution (violin + ECDF)."""
    df = pd.DataFrame({"perturbation": adata.obs["perturbation"].to_numpy(), "speed": speed}).dropna()
    conditions = [c for c in CONDITION_COLORS if c in df["perturbation"].unique()]

    fig, (ax_v, ax_e) = plt.subplots(1, 2, figsize=(12, 4.5), constrained_layout=True)

    data = [df.loc[df["perturbation"] == c, "speed"].to_numpy() for c in conditions]
    parts = ax_v.violinplot(data, showmeans=False, showmedians=True)
    for i, pc in enumerate(parts["bodies"]):
        pc.set_facecolor(CONDITION_COLORS[conditions[i]])
        pc.set_alpha(0.6)
    ax_v.set_xticks(range(1, len(conditions) + 1))
    ax_v.set_xticklabels(conditions, rotation=20, ha="right")
    ax_v.set_ylabel(f"real-space speed ({unit_label})")
    ax_v.set_title("Real-space speed per condition")
    q99 = float(np.quantile(df["speed"], 0.99))
    ax_v.set_ylim(0, q99)

    for c in conditions:
        s = np.sort(df.loc[df["perturbation"] == c, "speed"].to_numpy())
        y = np.linspace(0, 1, len(s))
        ax_e.plot(s, y, "-", color=CONDITION_COLORS[c], label=c, linewidth=1.5)
    ax_e.set_xlabel(f"real-space speed ({unit_label})")
    ax_e.set_ylabel("cumulative fraction")
    ax_e.set_title("Real-space speed ECDF")
    ax_e.set_xlim(0, q99)
    ax_e.legend(frameon=False, fontsize=8)

    return fig


def plot_realspeed_vs_time(
    adata: ad.AnnData,
    speed: np.ndarray,
    time_key: str,
    n_bins: int,
    unit_label: str,
) -> plt.Figure:
    """Mean ± std real-space speed vs. time, per condition."""
    df = pd.DataFrame(
        {
            "perturbation": adata.obs["perturbation"].to_numpy(),
            "t": adata.obs[time_key].to_numpy(),
            "speed": speed,
        }
    ).dropna()
    edges = np.linspace(float(df["t"].min()), float(df["t"].max()), n_bins + 1)
    df["bin"] = pd.cut(df["t"], bins=edges, include_lowest=True)
    df["t_center"] = df["bin"].apply(lambda iv: 0.5 * (iv.left + iv.right)).astype(float)

    fig, ax = plt.subplots(figsize=(7.0, 5.0), constrained_layout=True)
    for c, color in CONDITION_COLORS.items():
        sub = (
            df[df["perturbation"] == c]
            .groupby("t_center", observed=True)["speed"]
            .agg(["mean", "std"])
            .reset_index()
        )
        if sub.empty:
            continue
        x = sub["t_center"].to_numpy()
        m = sub["mean"].to_numpy()
        s = sub["std"].to_numpy()
        ax.plot(x, m, "-", color=color, linewidth=2, label=c)
        ax.fill_between(x, m - s, m + s, color=color, alpha=0.15, linewidth=0)
    ax.set_xlabel(time_key)
    ax.set_ylabel(f"mean real-space speed ({unit_label})")
    ax.set_title("Panel F — real-space speed vs. time, by condition")
    ax.legend(frameon=False, fontsize=9)
    return fig


def plot_embedding_vs_realspace(
    adata: ad.AnnData,
    real_speed: np.ndarray,
    emb_speed: np.ndarray,
    min_track_length: int,
    unit_label: str,
) -> tuple[plt.Figure, pd.DataFrame]:
    """Joint density and per-track Spearman ρ of real-space vs. embedding speed."""
    df = pd.DataFrame(
        {
            "perturbation": adata.obs["perturbation"].to_numpy(),
            "fov_name": adata.obs["fov_name"].to_numpy(),
            "track_id": adata.obs["track_id"].to_numpy(),
            "real": real_speed,
            "emb": emb_speed,
        }
    ).dropna()
    conditions = [c for c in CONDITION_COLORS if c in df["perturbation"].unique()]

    fig, axes = plt.subplots(1, len(conditions) + 1, figsize=(4.2 * (len(conditions) + 1), 4.2), constrained_layout=True)

    per_track_rows = []
    for ax, c in zip(axes[:-1], conditions):
        sub = df[df["perturbation"] == c]
        if sub.empty:
            ax.set_title(f"{c} (empty)", fontsize=9)
            continue
        x = sub["real"].to_numpy()
        y = sub["emb"].to_numpy()
        qx = float(np.quantile(x, 0.99))
        qy = float(np.quantile(y, 0.99))
        ax.hexbin(x, y, gridsize=60, extent=(0, qx, 0, qy), cmap="magma", mincnt=1)
        rho, _ = spearmanr(x, y)
        ax.set_title(f"{c}  ρ={rho:.2f} (n={len(sub)})", fontsize=9)
        ax.set_xlabel(f"real-space speed ({unit_label})")
        if ax is axes[0]:
            ax.set_ylabel("embedding speed (L2 / hour)")

        rhos = []
        for _, tr in sub.groupby(["fov_name", "track_id"], observed=True):
            if len(tr) < min_track_length:
                continue
            if np.std(tr["real"]) < 1e-6 or np.std(tr["emb"]) < 1e-6:
                continue
            r, _ = spearmanr(tr["real"].to_numpy(), tr["emb"].to_numpy())
            if np.isfinite(r):
                rhos.append(r)
        for r in rhos:
            per_track_rows.append({"perturbation": c, "rho": r})

    ax_box = axes[-1]
    tdf = pd.DataFrame(per_track_rows)
    if not tdf.empty:
        data = [tdf.loc[tdf["perturbation"] == c, "rho"].to_numpy() for c in conditions]
        parts = ax_box.violinplot(data, showmeans=False, showmedians=True)
        for i, pc in enumerate(parts["bodies"]):
            pc.set_facecolor(CONDITION_COLORS[conditions[i]])
            pc.set_alpha(0.6)
        ax_box.axhline(0, color="k", linewidth=0.6, linestyle="--")
        ax_box.set_xticks(range(1, len(conditions) + 1))
        ax_box.set_xticklabels(conditions, rotation=20, ha="right")
        ax_box.set_ylabel("per-track Spearman ρ (real vs. embedding speed)")
        ax_box.set_title(f"Per-track correlation (min len {min_track_length})", fontsize=9)
    else:
        ax_box.text(0.5, 0.5, "no tracks ≥ min length", ha="center", va="center")

    fig.suptitle("Panel F — embedding-space vs. real-space velocity", y=1.03)
    return fig, tdf


def plot(
    zarr_path: Path,
    feature_key: str,
    n_components: int | None,
    output_dir: Path,
    subsample: int,
    tracks_per_condition: int,
    min_track_length: int,
    n_time_bins: int,
    time_key: str,
    clip_quantile: float,
    pixel_size_um: float | None,
    seed: int,
) -> list[Path]:
    """Compute real-space speed and produce all Panel-F figures.

    Parameters
    ----------
    zarr_path : Path
        Embedding zarr.
    feature_key : str
        ``"X"`` or ``obsm`` key used for the embedding-speed reference
        (must match Panel G to make the comparison meaningful).
    n_components : int or None
        Truncate feature vector for the embedding-speed reference.
    output_dir : Path
        Destination directory for PNG/CSV outputs.
    subsample : int
        Max points per condition in the PHATE scatter.
    tracks_per_condition : int
        Number of real-space tracks to draw per condition.
    min_track_length : int
        Minimum track length for the real-space track overlay and the
        per-track correlation estimate.
    n_time_bins : int
        Bins for the speed-vs-time plot.
    time_key : str
        ``obs`` column (hours) for the central-difference denominator.
    clip_quantile : float
        Upper quantile for colorbar clipping.
    pixel_size_um : float or None
        Pixel size for optional conversion to µm/hour.
    seed : int
        RNG seed.

    Returns
    -------
    list of Path
        Saved figures and CSVs.
    """
    adata = load_embedding(zarr_path)
    real_speed = compute_realspace_speed(adata, time_key, pixel_size_um)
    emb_speed = compute_embedding_speed(adata, feature_key, n_components, time_key)

    unit_label = "px/hour" if pixel_size_um is None else "µm/hour"
    finite = real_speed[np.isfinite(real_speed)]
    vmin = float(np.quantile(finite, 0.01))
    vmax = float(np.quantile(finite, clip_quantile))
    print(
        f"{zarr_path.name}: real-space speed range "
        f"[{finite.min():.3f}, {finite.max():.3f}] {unit_label}, clip [{vmin:.3f}, {vmax:.3f}]"
    )

    ensure_outdir(output_dir)
    tag_ft = feature_key if n_components is None else f"{feature_key}d{n_components}"
    tag = f"{zarr_path.stem}_{tag_ft}"
    paths: list[Path] = []

    fig_phate = plot_realspeed_on_phate(
        adata, real_speed, (0, 1), subsample, seed, vmin, vmax, unit_label
    )
    fig_tracks = plot_realspace_tracks(
        adata, real_speed, tracks_per_condition, min_track_length, seed, vmin, vmax, unit_label
    )
    fig_dist = plot_realspeed_distribution(adata, real_speed, unit_label)
    fig_vst = plot_realspeed_vs_time(adata, real_speed, time_key, n_time_bins, unit_label)
    fig_corr, per_track_rho = plot_embedding_vs_realspace(
        adata, real_speed, emb_speed, min_track_length, unit_label
    )

    for name, fig in [
        ("phate", fig_phate),
        ("tracks", fig_tracks),
        ("dist", fig_dist),
        ("vs_time", fig_vst),
        ("corr", fig_corr),
    ]:
        out = output_dir / f"panel_F_{name}_{tag}.png"
        fig.savefig(out, dpi=200)
        plt.close(fig)
        paths.append(out)

    summary = (
        pd.DataFrame({"perturbation": adata.obs["perturbation"].to_numpy(), "speed": real_speed})
        .dropna()
        .groupby("perturbation", observed=True)["speed"]
        .agg(["mean", "median", "std", "count"])
    )
    csv = output_dir / f"panel_F_summary_{tag}.csv"
    summary.to_csv(csv)
    paths.append(csv)

    if not per_track_rho.empty:
        rho_csv = output_dir / f"panel_F_per_track_rho_{tag}.csv"
        per_track_rho.to_csv(rho_csv, index=False)
        paths.append(rho_csv)

    return paths


def main() -> None:
    """CLI entry point."""
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--zarr", type=Path, default=DEFAULT_ZARR)
    p.add_argument(
        "--feature-key",
        default="X_pca_combined",
        help="Embedding space for the correlation reference (match Panel G).",
    )
    p.add_argument("--n-components", type=int, default=32)
    p.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT_DIR)
    p.add_argument("--subsample", type=int, default=50_000)
    p.add_argument("--tracks-per-condition", type=int, default=12)
    p.add_argument("--min-track-length", type=int, default=20)
    p.add_argument("--n-time-bins", type=int, default=24)
    p.add_argument("--time-key", default="hours_post_perturbation")
    p.add_argument("--clip-quantile", type=float, default=0.98)
    p.add_argument(
        "--pixel-size-um",
        type=float,
        default=None,
        help="If set, convert px to µm for the speed axes; otherwise units are px/hour.",
    )
    p.add_argument("--seed", type=int, default=0)
    args = p.parse_args()

    out = plot(
        args.zarr,
        args.feature_key,
        args.n_components if args.n_components > 0 else None,
        args.output_dir,
        subsample=args.subsample,
        tracks_per_condition=args.tracks_per_condition,
        min_track_length=args.min_track_length,
        n_time_bins=args.n_time_bins,
        time_key=args.time_key,
        clip_quantile=args.clip_quantile,
        pixel_size_um=args.pixel_size_um,
        seed=args.seed,
    )
    for p_ in out:
        print(f"wrote {p_}")


if __name__ == "__main__":
    main()
