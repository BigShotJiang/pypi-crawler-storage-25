"""Panel A: embedding scatter colored by perturbation.

Shows that cells from different stimuli occupy overlapping but distinct regions
in the DynaCLR embedding space — shared morphological states but different
distributions across states.
"""

from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np

from _common import (
    CONDITION_COLORS,
    DEFAULT_OUTPUT_DIR,
    DEFAULT_ZARR,
    ensure_outdir,
    get_2d_embedding,
    load_embedding,
)


def plot(
    zarr_path: Path,
    embedding_key: str,
    components: tuple[int, int],
    output_dir: Path,
    point_size: float = 1.0,
    subsample: int | None = 50_000,
    seed: int = 0,
) -> Path:
    """Scatter the 2D embedding colored by perturbation.

    Parameters
    ----------
    zarr_path : Path
        Embedding AnnData zarr.
    embedding_key : str
        Key in ``adata.obsm`` (e.g. ``"X_phate_combined"``).
    components : tuple of int
        Two 0-indexed components to plot.
    output_dir : Path
        Directory for the output PNG.
    point_size : float
        Marker size for each cell-timepoint.
    subsample : int or None
        If set, randomly draw this many points for scatter readability.
    seed : int
        RNG seed for subsampling.

    Returns
    -------
    Path
        Path to the saved figure.
    """
    adata = load_embedding(zarr_path)
    xy = get_2d_embedding(adata, embedding_key, components)
    labels = adata.obs["perturbation"].to_numpy()

    rng = np.random.default_rng(seed)
    if subsample is not None and subsample < len(xy):
        idx = rng.choice(len(xy), size=subsample, replace=False)
    else:
        idx = np.arange(len(xy))
    idx = rng.permutation(idx)

    fig, ax = plt.subplots(figsize=(6.5, 6), constrained_layout=True)
    for cond, color in CONDITION_COLORS.items():
        mask = labels[idx] == cond
        if not mask.any():
            continue
        ax.scatter(
            xy[idx][mask, 0],
            xy[idx][mask, 1],
            s=point_size,
            c=color,
            alpha=0.5,
            linewidths=0,
            label=f"{cond} (n={(labels == cond).sum()})",
        )
    ax.set_xlabel(f"{embedding_key} [{components[0]}]")
    ax.set_ylabel(f"{embedding_key} [{components[1]}]")
    ax.set_title("Panel A — microglia embeddings by condition")
    leg = ax.legend(markerscale=4, frameon=False, fontsize=8, loc="best")
    for lh in leg.legend_handles:
        lh.set_alpha(1.0)

    ensure_outdir(output_dir)
    out = output_dir / f"panel_A_by_condition_{embedding_key}.png"
    fig.savefig(out, dpi=200)
    plt.close(fig)
    return out


def main() -> None:
    """CLI entry point."""
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--zarr", type=Path, default=DEFAULT_ZARR)
    p.add_argument("--embedding-key", default="X_phate_combined")
    p.add_argument("--components", type=int, nargs=2, default=(0, 1))
    p.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT_DIR)
    p.add_argument("--subsample", type=int, default=50_000)
    p.add_argument("--point-size", type=float, default=1.0)
    args = p.parse_args()

    out = plot(
        args.zarr,
        args.embedding_key,
        tuple(args.components),
        args.output_dir,
        point_size=args.point_size,
        subsample=args.subsample,
    )
    print(f"wrote {out}")


if __name__ == "__main__":
    main()
