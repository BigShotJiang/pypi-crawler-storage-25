"""Panel E: Leiden morphotype clustering on learned features.

Runs Leiden on the DynaCLR-learned features of one channel, then produces:
1. Clusters overlaid on the precomputed PHATE embedding (sanity check).
2. Cluster composition per perturbation (stacked bar).
3. Cluster occupancy fraction vs. hours_post_perturbation, per condition —
   the DynaMorph-style "trajectory through morphotype space" plot.

Cluster labels and the k-NN graph are written back into the AnnData zarr so
downstream scripts can reuse them.
"""

from __future__ import annotations

import argparse
from pathlib import Path

import anndata as ad
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import scanpy as sc

from _common import (
    CONDITION_COLORS,
    DEFAULT_OUTPUT_DIR,
    DEFAULT_ZARR,
    ensure_outdir,
    load_embedding,
)


def attach_external_phate(adata: ad.AnnData, parquet_path: Path, key: str = "X_phate") -> None:
    """Attach a per-channel PHATE parquet to ``adata.obsm`` keyed by tracking IDs.

    Parameters
    ----------
    adata : AnnData
        Embedding object with ``obs`` columns ``fov_name``, ``track_id``, ``t``.
    parquet_path : Path
        Parquet with columns ``fov_name``, ``track_id``, ``t``, ``phate_0``, ``phate_1``.
    key : str
        ``obsm`` slot to write to (default ``"X_phate"``).

    Notes
    -----
    Rows missing from the parquet get ``NaN`` coordinates. Useful when the
    parquet was computed from the same zarr — alignment is exact.
    """
    df = pd.read_parquet(parquet_path)
    obs_keys = list(zip(adata.obs["fov_name"].astype(str), adata.obs["track_id"].astype(int), adata.obs["t"].astype(int)))
    pq_keys = list(zip(df["fov_name"].astype(str), df["track_id"].astype(int), df["t"].astype(int)))
    pos = {k: i for i, k in enumerate(pq_keys)}
    coords = np.full((adata.n_obs, 2), np.nan, dtype=np.float32)
    for j, k in enumerate(obs_keys):
        i = pos.get(k, -1)
        if i >= 0:
            coords[j, 0] = df["phate_0"].iat[i]
            coords[j, 1] = df["phate_1"].iat[i]
    adata.obsm[key] = coords


def run_leiden(
    adata: ad.AnnData,
    feature_key: str,
    n_pcs: int,
    n_neighbors: int,
    resolution: float,
    seed: int,
    metric: str = "euclidean",
) -> str:
    """Build a k-NN graph and run Leiden clustering in place.

    By default this matches the original scanpy recipe: build the graph in
    ``feature_key`` directly (no PCA pre-step when ``feature_key`` already
    points at a low-dim representation; PCA-then-graph when ``feature_key``
    is the raw ``X``). DynaCLR is trained with NT-Xent on L2-normalized
    projections, so the geometrically-consistent metric is ``cosine`` —
    pass ``metric="cosine"`` to honor that.

    Parameters
    ----------
    adata : AnnData
        Embeddings.
    feature_key : str
        ``"X"`` (raw 768-d encoder output) or an ``obsm`` key.
    n_pcs : int
        Components used to build the k-NN graph. Set to ``0`` to skip the
        PCA pre-step entirely and build the graph directly on
        ``feature_key`` — the geometrically clean choice when
        ``feature_key == "X"``.
    n_neighbors : int
        k for the k-NN graph.
    resolution : float
        Leiden resolution.
    seed : int
        RNG seed.
    metric : str
        Distance for the k-NN graph: ``"euclidean"`` (scanpy default) or
        ``"cosine"`` (matches DynaCLR training geometry).

    Returns
    -------
    str
        Name of the ``adata.obs`` column with integer cluster ids.
    """
    use_rep = feature_key
    n_pcs_for_graph: int | None = n_pcs if n_pcs > 0 else None
    sc.pp.neighbors(
        adata,
        n_neighbors=n_neighbors,
        n_pcs=n_pcs_for_graph,
        use_rep=use_rep,
        metric=metric,
        random_state=seed,
    )
    key = f"leiden_r{resolution:g}"
    sc.tl.leiden(
        adata,
        resolution=resolution,
        random_state=seed,
        flavor="igraph",
        n_iterations=2,
        directed=False,
        key_added=key,
    )
    return key


def plot_clusters_on_phate(
    adata: ad.AnnData,
    cluster_key: str,
    components: tuple[int, int],
    subsample: int,
    seed: int,
    phate_key: str = "X_phate_combined",
) -> plt.Figure:
    """Scatter clusters on the chosen PHATE embedding.

    ``phate_key`` defaults to the cross-channel ``X_phate_combined`` for
    backward compatibility, but can be set to a per-channel PHATE attached
    via ``attach_external_phate`` (e.g. ``X_phate``).
    """
    rng = np.random.default_rng(seed)
    xy = adata.obsm[phate_key]
    labels = adata.obs[cluster_key].to_numpy()

    idx = rng.choice(len(xy), size=min(subsample, len(xy)), replace=False)
    idx = rng.permutation(idx)

    unique = np.unique(labels)
    cmap = plt.get_cmap("tab20", len(unique))
    fig, ax = plt.subplots(figsize=(7.0, 6.0), constrained_layout=True)
    for i, lab in enumerate(unique):
        mask = labels[idx] == lab
        ax.scatter(
            xy[idx][mask, components[0]],
            xy[idx][mask, components[1]],
            s=1.0,
            color=cmap(i),
            alpha=0.5,
            linewidths=0,
            label=f"{lab} (n={(labels == lab).sum()})",
        )
    ax.set_xlabel(f"{phate_key} [{components[0]}]")
    ax.set_ylabel(f"{phate_key} [{components[1]}]")
    ax.set_title(f"Panel E — Leiden clusters ({cluster_key}) on {phate_key}")
    leg = ax.legend(markerscale=4, frameon=False, fontsize=7, loc="best", ncol=2)
    for lh in leg.legend_handles:
        lh.set_alpha(1.0)
    return fig


def plot_composition(adata: ad.AnnData, cluster_key: str) -> plt.Figure:
    """Stacked bar: cluster composition per perturbation."""
    ct = pd.crosstab(adata.obs["perturbation"], adata.obs[cluster_key], normalize="index")
    ct = ct.reindex(
        [c for c in CONDITION_COLORS if c in ct.index]
    )

    fig, ax = plt.subplots(figsize=(8.0, 5.0), constrained_layout=True)
    cmap = plt.get_cmap("tab20", ct.shape[1])
    bottoms = np.zeros(len(ct))
    x = np.arange(len(ct))
    for i, col in enumerate(ct.columns):
        ax.bar(x, ct[col].to_numpy(), bottom=bottoms, color=cmap(i), label=str(col), edgecolor="white", linewidth=0.3)
        bottoms += ct[col].to_numpy()
    ax.set_xticks(x)
    ax.set_xticklabels(ct.index, rotation=20, ha="right")
    ax.set_ylabel("cluster occupancy fraction")
    ax.set_title(f"Panel E — {cluster_key} composition by condition")
    ax.legend(title="cluster", frameon=False, fontsize=7, bbox_to_anchor=(1.02, 1), loc="upper left", ncol=1)
    ax.set_ylim(0, 1)
    return fig


def plot_occupancy_over_time(
    adata: ad.AnnData,
    cluster_key: str,
    time_key: str,
    n_bins: int,
) -> plt.Figure:
    """Cluster occupancy fraction vs. time, one subplot per condition."""
    df = adata.obs[["perturbation", time_key, cluster_key]].copy()
    t = df[time_key].to_numpy()
    edges = np.linspace(float(t.min()), float(t.max()), n_bins + 1)
    df["time_bin"] = pd.cut(df[time_key], bins=edges, include_lowest=True)
    df["t_center"] = df["time_bin"].apply(lambda iv: 0.5 * (iv.left + iv.right)).astype(float)

    conditions = [c for c in CONDITION_COLORS if c in df["perturbation"].unique()]
    ncols = len(conditions)
    fig, axes = plt.subplots(1, ncols, figsize=(4.2 * ncols, 4.0), constrained_layout=True, sharex=True, sharey=True)
    if ncols == 1:
        axes = np.array([axes])

    clusters = sorted(df[cluster_key].unique(), key=lambda v: int(v))
    cmap = plt.get_cmap("tab20", len(clusters))

    for ax, cond in zip(axes, conditions):
        sub = df[df["perturbation"] == cond]
        ct = (
            sub.groupby(["t_center", cluster_key], observed=True)
            .size()
            .unstack(fill_value=0)
            .reindex(columns=clusters, fill_value=0)
        )
        ct = ct.div(ct.sum(axis=1), axis=0)
        bottoms = np.zeros(len(ct))
        for i, lab in enumerate(clusters):
            if lab not in ct.columns:
                continue
            y = ct[lab].to_numpy()
            ax.fill_between(ct.index.to_numpy(), bottoms, bottoms + y, color=cmap(i), alpha=0.9, linewidth=0, label=str(lab))
            bottoms += y
        ax.set_title(cond, fontsize=9)
        ax.set_xlabel(time_key)
        ax.set_ylim(0, 1)
    axes[0].set_ylabel("cluster occupancy fraction")
    axes[-1].legend(title="cluster", frameon=False, fontsize=7, bbox_to_anchor=(1.02, 1), loc="upper left")
    fig.suptitle(f"Panel E — {cluster_key} trajectories through morphotype space", y=1.03)
    return fig


def plot(
    zarr_path: Path,
    feature_key: str,
    output_dir: Path,
    resolution: float,
    n_neighbors: int,
    n_pcs: int,
    subsample: int,
    n_time_bins: int,
    time_key: str,
    seed: int,
    write_labels: bool,
    metric: str = "euclidean",
    phate_parquet: Path | None = None,
    phate_key: str = "X_phate_combined",
) -> list[Path]:
    """Run Leiden and produce all Panel-E figures for one zarr.

    Parameters
    ----------
    zarr_path : Path
        Embedding AnnData zarr for one channel.
    feature_key : str
        ``"X"`` or an obsm key to cluster on.
    output_dir : Path
        Destination directory.
    resolution : float
        Leiden resolution.
    n_neighbors : int
        k for the k-NN graph.
    n_pcs : int
        Components used when building the graph.
    subsample : int
        Scatter subsample for the PHATE plot.
    n_time_bins : int
        Time bins for the occupancy plot.
    time_key : str
        ``obs`` column for the time axis.
    seed : int
        RNG seed.
    write_labels : bool
        If True, write the new ``obs[cluster_key]`` column back to
        the zarr store so other scripts can reuse it.

    Returns
    -------
    list of Path
        Saved figure paths.
    """
    adata = load_embedding(zarr_path)
    if phate_parquet is not None:
        attach_external_phate(adata, phate_parquet, key=phate_key)
        print(f"attached PHATE from {phate_parquet} -> obsm['{phate_key}']")
    cluster_key = run_leiden(
        adata,
        feature_key=feature_key,
        n_pcs=n_pcs,
        n_neighbors=n_neighbors,
        resolution=resolution,
        seed=seed,
        metric=metric,
    )
    n_clusters = adata.obs[cluster_key].nunique()
    print(f"{zarr_path.name}: {n_clusters} clusters at resolution={resolution} (metric={metric})")

    ensure_outdir(output_dir)
    tag = f"{zarr_path.stem}_{feature_key}_{metric}_r{resolution:g}"
    paths: list[Path] = []

    for name, fig in [
        ("phate", plot_clusters_on_phate(adata, cluster_key, (0, 1), subsample, seed, phate_key=phate_key)),
        ("composition", plot_composition(adata, cluster_key)),
        ("over_time", plot_occupancy_over_time(adata, cluster_key, time_key, n_time_bins)),
    ]:
        out = output_dir / f"panel_E_{name}_{tag}.png"
        fig.savefig(out, dpi=200)
        plt.close(fig)
        paths.append(out)

    csv = output_dir / f"panel_E_{tag}_summary.csv"
    (
        pd.crosstab(adata.obs["perturbation"], adata.obs[cluster_key])
        .to_csv(csv)
    )
    paths.append(csv)

    if write_labels:
        labels_csv = output_dir / f"panel_E_{tag}_labels.csv"
        adata.obs[["fov_name", "track_id", "t", cluster_key]].to_csv(labels_csv, index=False)
        paths.append(labels_csv)

    return paths


def main() -> None:
    """CLI entry point."""
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--zarr", type=Path, default=DEFAULT_ZARR)
    p.add_argument(
        "--feature-key",
        default="X",
        help="'X' for full 768-d learned features, or an obsm key such as X_pca_combined.",
    )
    p.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT_DIR)
    p.add_argument("--resolution", type=float, default=0.6)
    p.add_argument("--n-neighbors", type=int, default=30)
    p.add_argument(
        "--n-pcs",
        type=int,
        default=0,
        help="Components for the k-NN graph. 0 (default) skips the PCA pre-step and builds the graph directly on feature_key.",
    )
    p.add_argument(
        "--metric",
        default="cosine",
        choices=("cosine", "euclidean"),
        help="k-NN distance. 'cosine' (default) honors DynaCLR's NT-Xent training geometry.",
    )
    p.add_argument(
        "--phate-parquet",
        type=Path,
        default=None,
        help="Optional path to a per-channel PHATE parquet (fov_name, track_id, t, phate_0, phate_1) to overlay clusters on instead of X_phate_combined.",
    )
    p.add_argument(
        "--phate-key",
        default="X_phate_combined",
        help="obsm key for the PHATE overlay. If --phate-parquet is given, set this to e.g. 'X_phate'.",
    )
    p.add_argument("--subsample", type=int, default=80_000)
    p.add_argument("--n-time-bins", type=int, default=24)
    p.add_argument("--time-key", default="hours_post_perturbation")
    p.add_argument("--seed", type=int, default=0)
    p.add_argument(
        "--save-labels",
        action="store_true",
        help="Write cluster labels as a CSV next to the figures for reuse.",
    )
    args = p.parse_args()

    out = plot(
        args.zarr,
        args.feature_key,
        args.output_dir,
        resolution=args.resolution,
        n_neighbors=args.n_neighbors,
        n_pcs=args.n_pcs,
        subsample=args.subsample,
        n_time_bins=args.n_time_bins,
        time_key=args.time_key,
        seed=args.seed,
        write_labels=args.save_labels,
        metric=args.metric,
        phate_parquet=args.phate_parquet,
        phate_key=args.phate_key,
    )
    for p_ in out:
        print(f"wrote {p_}")


if __name__ == "__main__":
    main()
