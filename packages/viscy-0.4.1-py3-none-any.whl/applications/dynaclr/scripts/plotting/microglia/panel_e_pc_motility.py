"""Find the motility axis in the DynaCLR embedding without clustering.

Three complementary analyses, all unsupervised at the embedding level
(supervision only enters via the *target* — real-space speed or Wu's TFV):

1. **Per-PC Spearman correlation.** For each component of the dataset-local
   PCA already in the zarr (``X_pca``), compute ρ between PC value and
   real-space speed. Identifies whichever PC happens to align with motility.

2. **Ridge regression `speed ~ X`.** Train a linear regressor from the raw
   768-d L2-normalized embedding to log-speed, with a track-grouped
   train/test split. The fitted weight vector is the maximally
   speed-aligned direction in embedding space. Report cross-validated R²
   and project all cells onto that axis.

3. **PLS regression against Wu's TFV.** PLS finds the embedding direction
   that maximally covaries with a multivariate target — here the Wu
   trajectory feature vector (log_speed, persistence, MSDs averaged over
   2-h windows). One direction per latent component; report variance
   explained and condition density along the first.

Outputs (under ``--output-dir``)
-------------------------------
- ``pc_speed_correlations.csv`` — per-PC Spearman ρ, p-value, ρ² (with
  bootstrap CI optionally).
- ``pc_top_correlations.png`` — bar chart of top-|ρ| PCs.
- ``pc_best_vs_speed.png`` — 2D hexbin of PC[best] vs. log-speed.
- ``pc2_scatter_by_speed.png`` — (PC[best], PC[second]) colored by speed.
- ``pc_speed_axis_by_condition.png`` — KDE of PC[best] per condition.
- ``ridge_axis_by_condition.png`` — KDE of the ridge-fit speed axis,
  per condition. Plus ``ridge_summary.csv`` with R²s.
- ``pls_axis_by_condition.png`` (only if ``--do-pls``) — same but with
  PLS-on-TFV axis. Plus ``pls_summary.csv``.

The story this answers: does the embedding have a low-dimensional axis
along which condition shifts and motility shifts agree? If yes, that
single axis is the figure.
"""

from __future__ import annotations

import argparse
import warnings
from pathlib import Path

import anndata as ad
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.stats import spearmanr
from sklearn.cross_decomposition import PLSRegression
from sklearn.linear_model import Ridge
from sklearn.preprocessing import StandardScaler

from _common import CONDITION_COLORS, ensure_outdir
from behavioral_states import TFVConfig, compute_tfv
from panel_f_realspace_velocity import compute_realspace_speed


def _per_pc_spearman(pcs: np.ndarray, target: np.ndarray) -> pd.DataFrame:
    """Spearman ρ between each column of ``pcs`` and ``target``.

    Drops rows where ``target`` is NaN. Returns columns ``pc``, ``rho``,
    ``rho_sq``, ``p_value``, sorted by |ρ| descending.
    """
    valid = np.isfinite(target)
    rows = []
    for i in range(pcs.shape[1]):
        rho, p = spearmanr(pcs[valid, i], target[valid])
        rows.append({"pc": i, "rho": float(rho), "rho_sq": float(rho) ** 2, "p_value": float(p)})
    df = pd.DataFrame(rows)
    df["abs_rho"] = df["rho"].abs()
    return df.sort_values("abs_rho", ascending=False).drop(columns="abs_rho").reset_index(drop=True)


def plot_top_pc_correlations(rho_df: pd.DataFrame, top_n: int = 20) -> plt.Figure:
    """Bar chart of the top-|ρ| PCs against real-space speed."""
    df = rho_df.head(top_n).copy()
    df["pc_label"] = df["pc"].astype(str)
    fig, ax = plt.subplots(figsize=(max(6.0, 0.4 * top_n), 4.2), constrained_layout=True)
    colors = ["#1f77b4" if r > 0 else "#d62728" for r in df["rho"].to_numpy()]
    ax.bar(df["pc_label"], df["rho"], color=colors, edgecolor="#333", linewidth=0.4)
    ax.axhline(0, color="k", linewidth=0.6, linestyle="--")
    ax.set_xlabel("PC index (sorted by |ρ|)")
    ax.set_ylabel("Spearman ρ vs. real-space speed")
    ax.set_title("Per-PC correlation with image-space cell speed")
    return fig


def plot_pc_vs_speed_hexbin(pc_values: np.ndarray, speed: np.ndarray, pc_idx: int) -> plt.Figure:
    """Joint density of one PC vs. log-speed."""
    valid = np.isfinite(speed)
    x = pc_values[valid]
    y = np.log1p(speed[valid])
    qx0, qx1 = float(np.quantile(x, 0.01)), float(np.quantile(x, 0.99))
    qy1 = float(np.quantile(y, 0.99))
    fig, ax = plt.subplots(figsize=(7.0, 5.0), constrained_layout=True)
    hb = ax.hexbin(x, y, gridsize=80, extent=(qx0, qx1, 0, qy1), cmap="magma", mincnt=1)
    fig.colorbar(hb, ax=ax, label="cell-frame count")
    ax.set_xlabel(f"PC {pc_idx}")
    ax.set_ylabel("log1p(real-space speed [px/h])")
    rho, _ = spearmanr(x, y)
    ax.set_title(f"PC {pc_idx} vs. real-space speed (ρ = {rho:.3f})")
    return fig


def plot_pc_2d_by_speed(pcs: np.ndarray, speed: np.ndarray, pc_a: int, pc_b: int, subsample: int, seed: int) -> plt.Figure:
    """(PC_a, PC_b) scatter colored by real-space speed."""
    rng = np.random.default_rng(seed)
    valid = np.isfinite(speed)
    idx = np.where(valid)[0]
    if subsample < len(idx):
        idx = rng.choice(idx, size=subsample, replace=False)
    idx = rng.permutation(idx)
    s = speed[idx]
    vmin = float(np.quantile(s, 0.02))
    vmax = float(np.quantile(s, 0.98))
    fig, ax = plt.subplots(figsize=(7.5, 6.0), constrained_layout=True)
    sc = ax.scatter(pcs[idx, pc_a], pcs[idx, pc_b], s=1.0, c=s, cmap="magma", vmin=vmin, vmax=vmax, alpha=0.7, linewidths=0)
    fig.colorbar(sc, ax=ax, label="real-space speed (px/h)")
    ax.set_xlabel(f"PC {pc_a}")
    ax.set_ylabel(f"PC {pc_b}")
    ax.set_title(f"PC {pc_a} vs. PC {pc_b}, colored by speed")
    return fig


def plot_axis_kde_by_condition(values: np.ndarray, conditions: np.ndarray, axis_label: str, title: str) -> plt.Figure:
    """Kernel-density of a 1-D projection per condition."""
    valid = np.isfinite(values)
    fig, ax = plt.subplots(figsize=(8.0, 4.5), constrained_layout=True)
    cond_set = [c for c in CONDITION_COLORS if c in np.unique(conditions[valid])]
    qx0, qx1 = float(np.quantile(values[valid], 0.005)), float(np.quantile(values[valid], 0.995))
    grid = np.linspace(qx0, qx1, 256)
    for c in cond_set:
        m = valid & (conditions == c)
        sub = values[m]
        if len(sub) < 100:
            continue
        # Gaussian KDE via numpy histogram smoothing (avoids scipy.gaussian_kde memory blow-up at 10^5+ points)
        h, edges = np.histogram(sub, bins=200, range=(qx0, qx1), density=True)
        x = 0.5 * (edges[:-1] + edges[1:])
        # smooth lightly
        kernel = np.exp(-0.5 * (np.linspace(-3, 3, 9)) ** 2)
        kernel /= kernel.sum()
        h_s = np.convolve(h, kernel, mode="same")
        ax.plot(x, h_s, "-", color=CONDITION_COLORS[c], linewidth=1.6, label=f"{c} (n={int(m.sum())})")
    ax.set_xlabel(axis_label)
    ax.set_ylabel("density")
    ax.set_title(title)
    ax.legend(frameon=False, fontsize=8)
    return fig


def fit_ridge_on_speed(
    X: np.ndarray,
    y: np.ndarray,
    track_id: np.ndarray,
    seed: int,
    alpha: float,
) -> tuple[np.ndarray, float, float]:
    """Track-grouped ridge regression for log-speed.

    Returns (projection_for_all_cells, train_r2, test_r2). 80/20 split by
    unique track id keeps within-track frames out of the test set.
    """
    valid = np.isfinite(y)
    rng = np.random.default_rng(seed)
    unique_tracks = np.unique(track_id[valid])
    rng.shuffle(unique_tracks)
    n_test = max(1, int(0.2 * len(unique_tracks)))
    test_tracks = set(unique_tracks[:n_test].tolist())
    is_test = np.array([t in test_tracks for t in track_id])

    train = valid & ~is_test
    test = valid & is_test
    scaler = StandardScaler(with_mean=False).fit(X[train])  # centering optional on L2-norm features
    Xt = scaler.transform(X)

    yt = np.log1p(y)
    ridge = Ridge(alpha=alpha, fit_intercept=True, random_state=seed).fit(Xt[train], yt[train])
    train_r2 = float(ridge.score(Xt[train], yt[train]))
    test_r2 = float(ridge.score(Xt[test], yt[test]))
    proj = Xt @ ridge.coef_
    return proj, train_r2, test_r2


def fit_pls_on_tfv(
    X: np.ndarray,
    Y: np.ndarray,
    track_id: np.ndarray,
    n_components: int,
    seed: int,
) -> tuple[np.ndarray, pd.DataFrame]:
    """PLS regression of TFV on the embedding, track-grouped.

    Returns (n_obs × n_components projection, summary DataFrame with
    train/test R² per output column).
    """
    valid_rows = np.all(np.isfinite(Y), axis=1)
    rng = np.random.default_rng(seed)
    unique_tracks = np.unique(track_id[valid_rows])
    rng.shuffle(unique_tracks)
    n_test = max(1, int(0.2 * len(unique_tracks)))
    test_tracks = set(unique_tracks[:n_test].tolist())
    is_test = np.array([t in test_tracks for t in track_id])

    train = valid_rows & ~is_test
    test = valid_rows & is_test

    Xs = StandardScaler(with_mean=False).fit_transform(X)
    Ys = StandardScaler().fit_transform(Y[valid_rows])
    Y_full = np.full((len(Y), Y.shape[1]), np.nan, dtype=np.float32)
    Y_full[valid_rows] = Ys

    pls = PLSRegression(n_components=n_components).fit(Xs[train], Y_full[train])
    proj = Xs @ pls.x_weights_
    rows = []
    for j in range(Y.shape[1]):
        train_pred = pls.predict(Xs[train])[:, j]
        test_pred = pls.predict(Xs[test])[:, j]
        train_r2 = 1 - np.var(Y_full[train, j] - train_pred) / np.var(Y_full[train, j])
        test_r2 = 1 - np.var(Y_full[test, j] - test_pred) / np.var(Y_full[test, j])
        rows.append({"target_dim": j, "train_r2": float(train_r2), "test_r2": float(test_r2)})
    return proj, pd.DataFrame(rows)


def run(
    zarr_path: Path,
    output_dir: Path,
    pca_key: str,
    subsample: int,
    do_pls: bool,
    pls_components: int,
    ridge_alpha: float,
    time_key: str,
    pixel_size_um: float | None,
    seed: int,
    window_frames: int,
) -> list[Path]:
    """Run all three analyses end-to-end."""
    with warnings.catch_warnings():
        warnings.filterwarnings("ignore", message="Observation names are not unique")
        adata = ad.read_zarr(zarr_path)
    adata.obs.index = pd.RangeIndex(adata.n_obs).astype(str)
    print(f"loaded {zarr_path.name}: n_obs={adata.n_obs}, X={adata.X.shape}")

    pcs = np.asarray(adata.obsm[pca_key], dtype=np.float32)
    print(f"using {pca_key} for per-PC analysis: shape={pcs.shape}")

    real_speed = compute_realspace_speed(adata, time_key, pixel_size_um)
    cond = adata.obs["perturbation"].to_numpy()
    track_id = adata.obs["track_id"].to_numpy()

    rho_df = _per_pc_spearman(pcs, real_speed)
    print()
    print("### Top-10 PCs by |ρ| with real-space speed")
    print(rho_df.head(10).round(4).to_markdown(index=False))

    ensure_outdir(output_dir)
    paths: list[Path] = []

    rho_csv = output_dir / "pc_speed_correlations.csv"
    rho_df.to_csv(rho_csv, index=False)
    paths.append(rho_csv)

    fig_bar = plot_top_pc_correlations(rho_df, top_n=min(20, pcs.shape[1]))
    p = output_dir / "pc_top_correlations.png"
    fig_bar.savefig(p, dpi=200)
    plt.close(fig_bar)
    paths.append(p)

    pc_best = int(rho_df.iloc[0]["pc"])
    pc_second = int(rho_df.iloc[1]["pc"])
    print(f"\nbest speed-aligned PC: {pc_best}  (ρ = {rho_df.iloc[0]['rho']:.3f})")
    print(f"second-best PC:        {pc_second} (ρ = {rho_df.iloc[1]['rho']:.3f})")

    fig_hex = plot_pc_vs_speed_hexbin(pcs[:, pc_best], real_speed, pc_best)
    p = output_dir / "pc_best_vs_speed.png"
    fig_hex.savefig(p, dpi=200)
    plt.close(fig_hex)
    paths.append(p)

    fig_2d = plot_pc_2d_by_speed(pcs, real_speed, pc_best, pc_second, subsample, seed)
    p = output_dir / "pc2_scatter_by_speed.png"
    fig_2d.savefig(p, dpi=200)
    plt.close(fig_2d)
    paths.append(p)

    fig_kde = plot_axis_kde_by_condition(
        pcs[:, pc_best], cond, axis_label=f"PC {pc_best}", title=f"Distribution of PC {pc_best} per condition"
    )
    p = output_dir / "pc_speed_axis_by_condition.png"
    fig_kde.savefig(p, dpi=200)
    plt.close(fig_kde)
    paths.append(p)

    # --- Ridge ---
    print("\nfitting ridge: log-speed ~ embedding (track-grouped 80/20 split)")
    Xn = np.asarray(adata.X, dtype=np.float32)
    norms = np.linalg.norm(Xn, axis=1, keepdims=True)
    norms[norms == 0] = 1.0
    Xn = Xn / norms
    proj_ridge, r2_train, r2_test = fit_ridge_on_speed(Xn, real_speed, track_id, seed=seed, alpha=ridge_alpha)
    print(f"  train R² = {r2_train:.3f}, test R² = {r2_test:.3f}")
    rho_ridge, _ = spearmanr(proj_ridge[np.isfinite(real_speed)], real_speed[np.isfinite(real_speed)])
    print(f"  Spearman ρ(ridge axis, real-space speed) = {rho_ridge:.3f}")

    ridge_summary = pd.DataFrame(
        [{"target": "log_real_speed", "train_r2": r2_train, "test_r2": r2_test, "spearman_rho": float(rho_ridge), "alpha": ridge_alpha}]
    )
    p = output_dir / "ridge_summary.csv"
    ridge_summary.to_csv(p, index=False)
    paths.append(p)

    fig_ridge = plot_axis_kde_by_condition(
        proj_ridge,
        cond,
        axis_label="ridge speed axis (a.u.)",
        title=f"Ridge speed axis per condition (test R²={r2_test:.2f}, ρ={rho_ridge:.2f})",
    )
    p = output_dir / "ridge_axis_by_condition.png"
    fig_ridge.savefig(p, dpi=200)
    plt.close(fig_ridge)
    paths.append(p)

    # --- PLS on TFV ---
    if do_pls:
        print("\ncomputing Wu-style TFV...")
        tfv_df = compute_tfv(adata.obs.reset_index(drop=True), TFVConfig(window_frames=window_frames, min_track_length=window_frames), time_key=time_key)
        Y = tfv_df.to_numpy(dtype=np.float32)
        print(f"TFV shape: {Y.shape}, dropping NaN rows for fit ({int(np.all(np.isfinite(Y), axis=1).sum())} valid)")
        proj_pls, pls_summary = fit_pls_on_tfv(Xn, Y, track_id, n_components=pls_components, seed=seed)
        pls_summary["target_name"] = list(tfv_df.columns)
        print(pls_summary.round(3).to_markdown(index=False))
        p = output_dir / "pls_summary.csv"
        pls_summary.to_csv(p, index=False)
        paths.append(p)

        # Spearman of first PLS axis vs real-space speed for sanity
        rho_pls0, _ = spearmanr(proj_pls[np.isfinite(real_speed), 0], real_speed[np.isfinite(real_speed)])
        print(f"  Spearman ρ(PLS axis 0, real-space speed) = {rho_pls0:.3f}")

        fig_pls = plot_axis_kde_by_condition(
            proj_pls[:, 0],
            cond,
            axis_label="PLS axis 0 (Wu-TFV)",
            title=f"PLS-on-TFV axis 0 per condition (ρ vs. real speed = {rho_pls0:.2f})",
        )
        p = output_dir / "pls_axis_by_condition.png"
        fig_pls.savefig(p, dpi=200)
        plt.close(fig_pls)
        paths.append(p)

    return paths


def main() -> None:
    """CLI entry point."""
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--zarr", type=Path, required=True)
    p.add_argument("--output-dir", type=Path, required=True)
    p.add_argument("--pca-key", default="X_pca", help="obsm key with the dataset-local PCA (default 'X_pca').")
    p.add_argument("--subsample", type=int, default=80_000)
    p.add_argument("--do-pls", action="store_true", help="Also fit PLS against Wu's TFV (slower).")
    p.add_argument("--pls-components", type=int, default=2)
    p.add_argument("--ridge-alpha", type=float, default=10.0)
    p.add_argument("--time-key", default="hours_post_perturbation")
    p.add_argument("--pixel-size-um", type=float, default=None)
    p.add_argument("--window-frames", type=int, default=13)
    p.add_argument("--seed", type=int, default=0)
    args = p.parse_args()

    out = run(
        args.zarr,
        args.output_dir,
        pca_key=args.pca_key,
        subsample=args.subsample,
        do_pls=args.do_pls,
        pls_components=args.pls_components,
        ridge_alpha=args.ridge_alpha,
        time_key=args.time_key,
        pixel_size_um=args.pixel_size_um,
        seed=args.seed,
        window_frames=args.window_frames,
    )
    for p_ in out:
        print(f"wrote {p_}")


if __name__ == "__main__":
    main()
