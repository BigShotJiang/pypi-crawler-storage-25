"""Dataloader demo: OPS 1000-gene × 15-marker SupCon pipeline.

Visualizes single-marker batches with same-gene positives, showing raw
and augmented anchor/positive patches side-by-side.

For each batch:
- **Row 0 (anchor raw)**: raw 2D patch from zarr (Phase2D, GFP, or mCherry).
- **Row 1 (anchor aug)**: after percentile normalization + affine + crop etc.
- **Row 2 (positive raw)**: a different cell with the same gene in the same marker.
- **Row 3 (positive aug)**: positive after the full transform pipeline.

Usage::

    uv run python applications/dynaclr/scripts/dataloader_inspection/ops_1000genes_allmarkers_demo.py
"""

# ruff: noqa: E402, D103

# %% [markdown]
# # OPS 1000-gene × 15-marker Dataloader Demo
#
# Verifies the Option 1 SupCon pipeline: single-marker batches with
# same-gene positives. Mirrors `OPS-1000genes-15markers.yml`.

# %%
from __future__ import annotations

import copy
from collections import Counter
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np

from dynaclr.data.datamodule import MultiExperimentDataModule
from viscy_transforms import (
    BatchedRandAdjustContrastd,
    BatchedRandAffined,
    BatchedRandFlipd,
    BatchedRandGaussianNoised,
    BatchedRandGaussianSmoothd,
    BatchedRandScaleIntensityd,
    BatchedScaleIntensityRangePercentilesd,
)

# %% [markdown]
# ## Configuration — mirrors OPS-1000genes-15markers.yml

# %%
CELL_INDEX_PATH = (
    "/hpc/projects/organelle_phenotyping/models/collections/"
    "ops_1000genes_allmarkers_demo.parquet"  # subsampled (50k/marker) for in-memory demo
)

# Sqrt-of-cell-count sampling (floor=1.0) — mirrors OPS-1000genes-allmarkers.yml.
# Phase gets ~13× the sampling of TOMM20 (not 170×), preventing both
# Phase domination and over-cycling of small markers.
GROUP_WEIGHTS = {
    "Phase": 13.1,
    "5xUPRE": 2.97,
    "ATG101": 2.36,
    "ATP1B3": 1.96,
    "BODIPY_live_cell_dye": 1.35,
    "CLTA": 2.4,
    "COP-II": 2.1,
    "COPE": 2.02,
    "CellEvent-Caspase_live-cell_dye": 1.77,
    "CellROX_live-cell_dye": 1.84,
    "ChromaLIVE_488_excitation": 2.17,
    "ChromaLIVE_561_excitation": 1.58,
    "EEA1": 2.18,
    "FBL": 2.02,
    "FastAct_SPY555_Live_Cell_Dye": 2.23,
    "FeRhoNox_live-cell_dye": 1.89,
    "G3BP1": 2.29,
    "H2B_(TOMM20-combo)": 1.0,
    "HSPA1B": 1.21,
    "LAMP1": 1.7,
    "LysoTracker_live-cell_dye": 3.1,
    "MAP1LC3B": 3.29,
    "MAP4": 2.27,
    "MKI67": 2.57,
    "NCLN": 2.06,
    "NPM3": 1.59,
    "PLIN2": 1.7,
    "PSMB7": 1.84,
    "Peroxi_SPY650_live_cell_dye": 2.57,
    "RAB7A": 1.5,
    "SEC61B": 2.97,
    "SLC3A2": 2.2,
    "SRRM2": 1.85,
    "TOMM20": 1.0,
    "TOMM70A": 1.86,
    "VAMP3": 1.75,
    "VAPA": 2.61,
    "VIM": 2.25,
    "VPS35": 2.39,
    "pHrodo-dextran_Live_Cell_Dye": 1.76,
}
# GROUP_WEIGHTS = {
#     # DEBUG: sample only visually distinct markers to verify channel routing.
#     # Each has an instantly recognizable phenotype:
#     #   Phase              — label-free grey-scale texture
#     #   H2B_(TOMM20-combo) — chromatin (nuclear only)
#     #   TOMM20             — filamentous mitochondrial network
#     #   FBL                — bright nucleolar speckles (1-5 per nucleus)
#     #   MAP4               — microtubule meshwork
#     #   MAP1LC3B           — autophagosome puncta (small bright dots, cytoplasmic)
#     "Phase": 1e-6,
#     "H2B_(TOMM20-combo)": 1e-6,
#     "TOMM20": 2.0,
#     "FBL": 1e-6,
#     "MAP4": 1e-6,
#     "MAP1LC3B": 1e-6,
#     # All other markers muted.
#     "5xUPRE": 1e-6,
#     "ATG101": 1e-6,
#     "ATP1B3": 1e-6,
#     "BODIPY_live_cell_dye": 1e-6,
#     "CLTA": 1e-6,
#     "COP-II": 1e-6,
#     "COPE": 1e-6,
#     "CellEvent-Caspase_live-cell_dye": 1e-6,
#     "CellROX_live-cell_dye": 1e-6,
#     "ChromaLIVE_488_excitation": 1e-6,
#     "ChromaLIVE_561_excitation": 1e-6,
#     "EEA1": 1e-6,
#     "FastAct_SPY555_Live_Cell_Dye": 1e-6,
#     "FeRhoNox_live-cell_dye": 1e-6,
#     "G3BP1": 1e-6,
#     "HSPA1B": 1e-6,
#     "LAMP1": 1e-6,
#     "LysoTracker_live-cell_dye": 1e-6,
#     "MKI67": 1e-6,
#     "NCLN": 1e-6,
#     "NPM3": 1e-6,
#     "PLIN2": 1e-6,
#     "PSMB7": 1e-6,
#     "Peroxi_SPY650_live_cell_dye": 1e-6,
#     "RAB7A": 1e-6,
#     "SEC61B": 1.0,
#     "SLC3A2": 1e-6,
#     "SRRM2": 1e-6,
#     "TOMM70A": 1e-6,
#     "VAMP3": 1e-6,
#     "VAPA": 1e-6,
#     "VIM": 1e-6,
#     "VPS35": 1e-6,
#     "pHrodo-dextran_Live_Cell_Dye": 1e-6,
# }

# 2D OPS: single Z slice, 224×224 extraction → 128×128 final crop
Z_WINDOW = 1
YX_PATCH_SIZE = (224, 224)
FINAL_YX_PATCH_SIZE = (128, 128)

CHANNELS_PER_SAMPLE = 1
CHANNEL_NAMES = ["channel_0"]

# SupCon on single-marker batches
POSITIVE_CELL_SOURCE = "lookup"
POSITIVE_MATCH_COLUMNS = ["gene_name", "marker"]
BATCH_GROUP_BY = "marker"
STRATIFY_BY = None

BATCH_SIZE = 8
SEED = 42

# Percentile normalization per batch
NORMALIZATIONS = [
    BatchedScaleIntensityRangePercentilesd(
        keys=CHANNEL_NAMES, lower=1, upper=99, b_min=0.0, b_max=1.0, clip=True
    ),
]

# Same augmentations as ops_2d_mild.yml
AUGMENTATIONS = [
    BatchedRandAffined(
        keys=CHANNEL_NAMES,
        prob=0.8,
        scale_range=[[1.0, 1.0], [0.9, 1.1], [0.9, 1.1]],
        rotate_range=[3.14, 0.0, 0.0],
        shear_range=[0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
    ),
    BatchedRandFlipd(keys=CHANNEL_NAMES, spatial_axes=[1, 2], prob=0.5),
    BatchedRandAdjustContrastd(keys=CHANNEL_NAMES, prob=0.5, gamma=(0.8, 1.2)),
    BatchedRandScaleIntensityd(keys=CHANNEL_NAMES, prob=0.5, factors=0.5),
    BatchedRandGaussianSmoothd(
        keys=CHANNEL_NAMES,
        prob=0.5,
        sigma_x=[0.2, 0.5],
        sigma_y=[0.2, 0.5],
        sigma_z=[0.0, 0.0],
    ),
    BatchedRandGaussianNoised(keys=CHANNEL_NAMES, prob=0.5, mean=0.0, std=0.08),
]

N_BATCHES = 12
N_SHOW = 8
NUM_WORKERS = 4
SHOW_AUGMENTED = True
OUTPUT_DIR = Path(
    "applications/dynaclr/scripts/dataloader_inspection/results/ops_1000genes_allmarkers_demo"
)


# %% [markdown]
# ## Helpers


# %%
def _img_2d(tensor_5d: np.ndarray, sample_idx: int) -> np.ndarray:
    """Extract a 2D slice from (B, C, Z, Y, X) for display."""
    img = tensor_5d[sample_idx]
    if img.ndim == 4:
        img = img[0, img.shape[1] // 2]
    elif img.ndim == 3:
        img = img[0]
    return img


def plot_batch(
    raw_batch: dict,
    aug_batch: dict | None,
    batch_idx: int,
    n_show: int,
    show_augmented: bool = True,
    save_path: Path | None = None,
) -> None:
    """Plot one batch: raw and augmented anchor/positive pairs."""
    anchor_raw = raw_batch["anchor"].numpy()
    positive_raw = raw_batch.get("positive")
    has_positive = positive_raw is not None
    if has_positive:
        positive_raw = positive_raw.numpy()

    anchor_meta = raw_batch["anchor_meta"]
    positive_meta = raw_batch.get("positive_meta", [{}] * len(anchor_meta))
    n = min(n_show, len(anchor_meta))

    row_labels = ["anchor (raw)"]
    if show_augmented and aug_batch is not None:
        row_labels.append("anchor (aug)")
    if has_positive:
        row_labels.append("positive (raw)")
        if show_augmented and aug_batch is not None:
            row_labels.append("positive (aug)")
    n_rows = len(row_labels)

    fig, axes = plt.subplots(n_rows, n, figsize=(n * 2.0, n_rows * 2.4), squeeze=False)

    markers = Counter(m.get("marker", "?") for m in anchor_meta[:n])
    perts = Counter(m.get("perturbation", "?") for m in anchor_meta[:n])
    same_gene = sum(
        1
        for a, p in zip(anchor_meta[:n], positive_meta[:n])
        if a.get("perturbation") == p.get("perturbation")
    )
    m_str = " ".join(f"{k}={v}" for k, v in markers.most_common(3))
    p_str = " ".join(f"{k}={v}" for k, v in perts.most_common(3))
    fig.suptitle(
        f"Batch {batch_idx}  |  marker: {m_str}  |  top pert: {p_str}  |  SupCon pos match: {same_gene}/{n}",
        fontsize=9,
        fontweight="bold",
    )

    anchor_aug = aug_batch["anchor"].numpy() if (show_augmented and aug_batch) else None
    positive_aug = None
    if has_positive and show_augmented and aug_batch:
        pa = aug_batch.get("positive")
        positive_aug = pa.numpy() if pa is not None else None

    for i in range(n):
        am = anchor_meta[i]
        pm = positive_meta[i] if i < len(positive_meta) else {}

        # Row 0: anchor raw
        img = _img_2d(anchor_raw, i)
        vmin, vmax = np.percentile(img, [1, 99])
        axes[0, i].imshow(img, cmap="gray", vmin=vmin, vmax=vmax)
        axes[0, i].set_xticks([])
        axes[0, i].set_yticks([])
        lines = [
            f"{am.get('experiment', '?')[:18]}",
            f"fov={am.get('fov_name', '?')}",
            f"marker={am.get('marker', '?')}",
            f"pert={am.get('perturbation', '?')}",
        ]
        if has_positive:
            gene_ok = am.get("perturbation") == pm.get("perturbation")
            mark_ok = am.get("marker") == pm.get("marker")
            lines.append(
                f"gene={'✓' if gene_ok else '✗'}  marker={'✓' if mark_ok else '✗'}"
            )
        axes[0, i].set_title("\n".join(lines), fontsize=5, linespacing=1.1)

        row = 1
        if anchor_aug is not None:
            img_a = _img_2d(anchor_aug, i)
            vmin_a, vmax_a = np.percentile(img_a, [1, 99])
            axes[row, i].imshow(img_a, cmap="gray", vmin=vmin_a, vmax=vmax_a)
            axes[row, i].set_xticks([])
            axes[row, i].set_yticks([])
            axes[row, i].set_title(
                f"μ={img_a.mean():.2f} σ={img_a.std():.2f}", fontsize=5
            )
            row += 1

        if has_positive:
            img_p = _img_2d(positive_raw, i)
            vmin_p, vmax_p = np.percentile(img_p, [1, 99])
            axes[row, i].imshow(img_p, cmap="gray", vmin=vmin_p, vmax=vmax_p)
            axes[row, i].set_xticks([])
            axes[row, i].set_yticks([])
            pos_lines = [
                f"fov={pm.get('fov_name', '?')}",
                f"pert={pm.get('perturbation', '?')}",
            ]
            axes[row, i].set_title("\n".join(pos_lines), fontsize=5, linespacing=1.1)
            row += 1

            if positive_aug is not None:
                img_pa = _img_2d(positive_aug, i)
                vmin_pa, vmax_pa = np.percentile(img_pa, [1, 99])
                axes[row, i].imshow(img_pa, cmap="gray", vmin=vmin_pa, vmax=vmax_pa)
                axes[row, i].set_xticks([])
                axes[row, i].set_yticks([])
                axes[row, i].set_title(
                    f"μ={img_pa.mean():.2f} σ={img_pa.std():.2f}", fontsize=5
                )

    for r, label in enumerate(row_labels):
        axes[r, 0].set_ylabel(label, fontsize=7, fontweight="bold")

    plt.tight_layout()
    if save_path:
        fig.savefig(save_path, dpi=150, bbox_inches="tight")
        print(f"  Saved: {save_path}")
    else:
        plt.show()


# %% [markdown]
# ## Build DataModule (mirrors OPS-1000genes-15markers.yml)

# %%
dm = MultiExperimentDataModule(
    cell_index_path=CELL_INDEX_PATH,
    z_window=Z_WINDOW,
    yx_patch_size=YX_PATCH_SIZE,
    final_yx_patch_size=FINAL_YX_PATCH_SIZE,
    channels_per_sample=CHANNELS_PER_SAMPLE,
    positive_cell_source=POSITIVE_CELL_SOURCE,
    positive_match_columns=POSITIVE_MATCH_COLUMNS,
    batch_group_by=BATCH_GROUP_BY,
    stratify_by=STRATIFY_BY,
    group_weights=GROUP_WEIGHTS,  # equal weights for all 40 markers
    batch_size=BATCH_SIZE,
    num_workers=NUM_WORKERS,
    seed=SEED,
    shuffle_val=True,
    normalizations=NORMALIZATIONS,
    augmentations=AUGMENTATIONS,
    label_columns={"gene_label": "gene_name"},
)
dm.setup("fit")


# Fake a minimal trainer so on_after_batch_transfer can check .predicting
class _FakeTrainer:
    predicting = False
    training = True


dm.trainer = _FakeTrainer()
print("DataModule ready.\n")

va = dm.train_dataset.index.valid_anchors
print(f"Train anchors: {len(va):,}")
print(f"Markers: {sorted(va['marker'].unique())}")
print(f"Experiments: {va['experiment'].nunique()}")
print(f"Genes: {va['gene_name'].nunique()}")


# %% [markdown]
# ## Draw batches

# %%
if OUTPUT_DIR:
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

dl = dm.train_dataloader()
dl_iter = iter(dl)

for batch_idx in range(N_BATCHES):
    print(f"\n--- Batch {batch_idx} ---")
    batch = next(dl_iter)

    meta = batch["anchor_meta"]
    pmeta = batch["positive_meta"]
    n = len(meta)
    markers = Counter(m.get("marker", "?") for m in meta)
    perts = Counter(m.get("perturbation", "?") for m in meta)
    same_gene = sum(
        1 for a, p in zip(meta, pmeta) if a.get("perturbation") == p.get("perturbation")
    )
    same_marker = sum(
        1 for a, p in zip(meta, pmeta) if a.get("marker") == p.get("marker")
    )
    print(
        f"  {n} samples, marker={dict(markers)}, unique_pert={len(perts)}, "
        f"SupCon gene-match={same_gene}/{n}, marker-match={same_marker}/{n}"
    )

    raw_batch = copy.deepcopy(batch)
    aug_batch = (
        dm.on_after_batch_transfer(batch, dataloader_idx=0) if SHOW_AUGMENTED else None
    )

    save_path = OUTPUT_DIR / f"train_batch_{batch_idx}.png" if OUTPUT_DIR else None
    plot_batch(
        raw_batch=raw_batch,
        aug_batch=aug_batch,
        batch_idx=batch_idx,
        n_show=N_SHOW,
        show_augmented=SHOW_AUGMENTED,
        save_path=save_path,
    )

# %%
print("\nDone.")


# %% [markdown]
# ## Validation dataloader
#
# Now uses the same `FlexibleBatchSampler` as train (same batch_group_by,
# stratify_by, group_weights). Each val batch should therefore match the
# train batch composition: single-marker batches with same-gene SupCon
# positive matches. We also scan each val batch for NaN/Inf before and
# after normalization to catch any rows the preprocess step missed.

# %%
val_dl = dm.val_dataloader()
val_iter = iter(val_dl)

nan_batches_raw = 0
nan_batches_norm = 0
for batch_idx in range(N_BATCHES):
    print(f"\n--- Val batch {batch_idx} ---")
    batch = next(val_iter)

    meta = batch["anchor_meta"]
    pmeta = batch["positive_meta"]
    n = len(meta)
    markers = Counter(m.get("marker", "?") for m in meta)
    perts = Counter(m.get("perturbation", "?") for m in meta)
    same_gene = sum(
        1 for a, p in zip(meta, pmeta) if a.get("perturbation") == p.get("perturbation")
    )
    same_marker = sum(
        1 for a, p in zip(meta, pmeta) if a.get("marker") == p.get("marker")
    )
    print(
        f"  {n} samples, marker={dict(markers)}, unique_pert={len(perts)}, "
        f"SupCon gene-match={same_gene}/{n}, marker-match={same_marker}/{n}"
    )

    raw_anchor = batch["anchor"]
    raw_pos = batch.get("positive")
    raw_bad = raw_anchor.isnan().any() or raw_anchor.isinf().any()
    if raw_pos is not None:
        raw_bad = raw_bad or raw_pos.isnan().any() or raw_pos.isinf().any()
    if raw_bad:
        nan_batches_raw += 1
        print(f"  ⚠ raw val batch contains NaN/Inf")

    raw_batch = copy.deepcopy(batch)
    aug_batch = (
        dm.on_after_batch_transfer(batch, dataloader_idx=1) if SHOW_AUGMENTED else None
    )

    if aug_batch is not None:
        aa = aug_batch["anchor"]
        ap = aug_batch.get("positive")
        norm_bad = aa.isnan().any() or aa.isinf().any()
        if ap is not None:
            norm_bad = norm_bad or ap.isnan().any() or ap.isinf().any()
        if norm_bad and not raw_bad:
            nan_batches_norm += 1
            print(f"  ⚠ post-normalize val batch contains NaN/Inf")

    save_path = OUTPUT_DIR / f"val_batch_{batch_idx}.png" if OUTPUT_DIR else None
    plot_batch(
        raw_batch=raw_batch,
        aug_batch=aug_batch,
        batch_idx=batch_idx,
        n_show=N_SHOW,
        show_augmented=SHOW_AUGMENTED,
        save_path=save_path,
    )

print(
    f"\nVal scan over {N_BATCHES} batches: "
    f"raw NaN/Inf={nan_batches_raw}, post-norm NaN/Inf={nan_batches_norm}"
)

# %%
