"""Minimal DynaCLR-2D-MIP training entry point for the DragonHPC handoff.

Every component is instantiated explicitly in Python — no Lightning CLI,
no YAML merging. This is the same training as
``DynaCLR-2D-MIP-BagOfChannels.yml``, transcribed inline.

The narrowest place to swap in a Dragon-backed DataLoader is the
:class:`MultiExperimentDataModule`. Subclass it and override
``train_dataloader`` / ``val_dataloader``. The dataset
(``MultiExperimentTripletDataset``) and sampler (``FlexibleBatchSampler``)
are accessed as ``self.train_dataset`` and via ``self._build_*_sampler``
patterns inside the datamodule itself — see ``datamodule.py:632`` for the
current wiring.

Usage
-----
Smoke test (single GPU, 5 train + 5 val steps, tiny parquet)::

    uv run python applications/dynaclr/scripts/dragonhpc/train_2d_mip_minimal.py --fastdev

Single-GPU short run on the production parquet (20 train + 5 val)::

    uv run python applications/dynaclr/scripts/dragonhpc/train_2d_mip_minimal.py

For full DDP runs, use ``sbatch
applications/dynaclr/configs/training/DynaCLR-2D/DynaCLR-2D-MIP-BagOfChannels.sh``
instead — that path is what we use in production.
"""

from __future__ import annotations

import argparse

import lightning.pytorch as pl

from dynaclr.data.datamodule import MultiExperimentDataModule
from dynaclr.engine import ContrastiveModule
from viscy_models.contrastive import ContrastiveEncoder
from viscy_models.contrastive.loss import NTXentLoss
from viscy_transforms import (
    BatchedChannelWiseZReductiond,
    BatchedRandAdjustContrastd,
    BatchedRandAffined,
    BatchedRandFlipd,
    BatchedRandGaussianNoised,
    BatchedRandGaussianSmoothd,
    BatchedRandScaleIntensityd,
    BatchedRandSpatialCropd,
    NormalizeSampled,
)

PROD_PARQUET = (
    "/hpc/projects/organelle_phenotyping/models/collections/"
    "DynaCLR-2D-MIP-BagOfChannels-v3.parquet"
)
FASTDEV_PARQUET = "/hpc/mydata/eduardo.hirata/repos/viscy/tmp/boc_tiny.parquet"


def build_datamodule(
    parquet_path: str, batch_size: int, num_workers: int
) -> MultiExperimentDataModule:
    """Construct the production DynaCLR-2D-MIP datamodule.

    Mirrors ``configs/training/DynaCLR-2D/DynaCLR-2D-MIP-BagOfChannels.yml``
    field-for-field. DragonHPC: subclass and override ``train_dataloader``
    to swap the I/O layer.
    """
    return MultiExperimentDataModule(
        cell_index_path=parquet_path,
        focus_channel="Phase3D",
        reference_pixel_size_xy_um=0.1494,
        z_window=1,
        z_extraction_window=16,
        z_focus_offset=0.3,
        yx_patch_size=(256, 256),
        final_yx_patch_size=(160, 160),
        channels_per_sample=1,
        positive_cell_source="lookup",
        positive_match_columns=["lineage_id"],
        positive_channel_source="same",
        tau_range=(0.5, 2.0),
        tau_decay_rate=2.0,
        stratify_by=["perturbation", "marker"],
        split_ratio=0.8,
        batch_size=batch_size,
        num_workers=num_workers,
        prefetch_factor=2,
        buffer_size=1,
        cache_pool_bytes=0,
        file_io_concurrency=32,
        seed=42,
        normalizations=[
            NormalizeSampled(
                keys=["channel_0"],
                level="timepoint_statistics",
                subtrahend="mean",
                divisor="std",
            ),
        ],
        augmentations=[
            BatchedRandAffined(
                keys=["channel_0"],
                prob=0.8,
                scale_range=((0.8, 1.3), (0.8, 1.3), (0.8, 1.3)),
                rotate_range=(3.14, 0.0, 0.0),
                shear_range=(0.05, 0.05, 0.0, 0.05, 0.0, 0.05),
            ),
            BatchedRandFlipd(keys=["channel_0"], spatial_axes=(1, 2), prob=0.5),
            BatchedRandAdjustContrastd(keys=["channel_0"], prob=0.5, gamma=(0.6, 1.6)),
            BatchedRandScaleIntensityd(keys=["channel_0"], prob=0.5, factors=0.5),
            BatchedRandGaussianSmoothd(
                keys=["channel_0"],
                prob=0.5,
                sigma_x=(0.25, 0.50),
                sigma_y=(0.25, 0.50),
                sigma_z=(0.0, 0.0),
            ),
            BatchedRandGaussianNoised(keys=["channel_0"], prob=0.5, mean=0.0, std=0.1),
            # Random Z crop (must precede ZReduction) → MIP/center-slice reduction.
            BatchedRandSpatialCropd(keys=["channel_0"], roi_size=(10, 192, 192)),
            BatchedChannelWiseZReductiond(keys=["channel_0"], allow_missing_keys=True),
        ],
    )


def build_model() -> ContrastiveModule:
    """Construct the production ContrastiveModule (ConvNeXt-Tiny + NTXent)."""
    encoder = ContrastiveEncoder(
        backbone="convnext_tiny",
        in_channels=1,
        embedding_dim=768,
        in_stack_depth=1,
        stem_kernel_size=(1, 4, 4),
        stem_stride=(1, 4, 4),
        projection_dim=32,
        drop_path_rate=0.1,
    )
    return ContrastiveModule(
        encoder=encoder,
        loss_function=NTXentLoss(temperature=0.2),
        lr=2e-5,
        log_batches_per_epoch=3,
        log_samples_per_batch=3,
        log_embeddings_every_n_epochs=10,
        log_negative_metrics_every_n_epochs=2,
        example_input_array_shape=(1, 1, 1, 160, 160),
    )


def build_trainer(fastdev: bool) -> pl.Trainer:
    """Construct a single-GPU Lightning trainer.

    No W&B, no checkpoints — we want clean perf timing.
    """
    if fastdev:
        return pl.Trainer(
            accelerator="gpu",
            devices=1,
            strategy="auto",
            precision="bf16-mixed",
            fast_dev_run=5,
            logger=False,
            enable_checkpointing=False,
            enable_model_summary=False,
            inference_mode=True,
            use_distributed_sampler=False,
            benchmark=True,
        )
    return pl.Trainer(
        accelerator="gpu",
        devices=1,
        strategy="auto",
        precision="bf16-mixed",
        max_epochs=1,
        limit_train_batches=20,
        limit_val_batches=5,
        log_every_n_steps=1,
        logger=False,
        enable_checkpointing=False,
        enable_model_summary=False,
        inference_mode=True,
        use_distributed_sampler=False,
        benchmark=True,
    )


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--fastdev",
        action="store_true",
        help="Run on the 20k-row tiny parquet with fast_dev_run=5. Default: 20-batch run on prod parquet.",
    )
    parser.add_argument("--batch-size", type=int, default=256)
    parser.add_argument("--num-workers", type=int, default=4)
    args = parser.parse_args()

    pl.seed_everything(42, workers=True)

    parquet = FASTDEV_PARQUET if args.fastdev else PROD_PARQUET
    batch_size = 8 if args.fastdev else args.batch_size
    num_workers = 0 if args.fastdev else args.num_workers

    print(f"[dragonhpc-handoff] parquet={parquet}")
    print(f"[dragonhpc-handoff] batch_size={batch_size}, num_workers={num_workers}")

    datamodule = build_datamodule(parquet, batch_size, num_workers)
    model = build_model()
    trainer = build_trainer(fastdev=args.fastdev)

    trainer.fit(model, datamodule=datamodule)


if __name__ == "__main__":
    main()
