"""Visualize linear-classifier organelle-state predictions against marker crops.

Loads an embeddings anndata zarr that already has `predicted_organelle_state`
appended by the linear classifier step, samples N cells per (predicted_class,
ground_truth_class) bucket for a chosen marker and perturbation, then renders
the corresponding center-cropped marker images as a grid.

Edit the constants at the bottom of the file and run:

    python applications/dynaclr/scripts/linear_classifiers/inspect_organelle_predictions.py
"""

from pathlib import Path

import anndata as ad
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from cmap import Colormap
from iohub.ngff import open_ome_zarr

MARKER_COLORMAPS = {
    "G3BP1": Colormap("green").to_mpl(),
    "SEC61B": Colormap("green").to_mpl(),
    "viral_sensor": Colormap("magenta").to_mpl(),
    "Phase3D": Colormap("gray").to_mpl(),
}
DEFAULT_COLORMAP = Colormap("gray").to_mpl()


def _crop_yx(img2d: np.ndarray, cy: float, cx: float, size: int) -> np.ndarray:
    """Center-crop a 2D array around (cy, cx), zero-padding when out of bounds."""
    H, W = img2d.shape
    half = size // 2
    y0, x0 = int(round(cy)) - half, int(round(cx)) - half
    y1, x1 = y0 + size, x0 + size
    pad_top = max(0, -y0)
    pad_left = max(0, -x0)
    pad_bot = max(0, y1 - H)
    pad_right = max(0, x1 - W)
    y0c, x0c = max(0, y0), max(0, x0)
    y1c, x1c = min(H, y1), min(W, x1)
    out = np.zeros((size, size), dtype=img2d.dtype)
    out[pad_top : pad_top + (y1c - y0c), pad_left : pad_left + (x1c - x0c)] = img2d[
        y0c:y1c, x0c:x1c
    ]
    return out


def _normalize_missing_inplace(obs: pd.DataFrame, col: str) -> None:
    """Collapse all missing-value flavors in ``obs[col]`` into a single ``pd.NA``.

    AnnData zarr round-trips can stringify ``np.nan`` / ``pd.NA`` into the
    literal strings ``"nan"`` / ``"<NA>"`` / ``"None"`` / ``""``, which then
    survive ``dropna()`` and surface as separate buckets when enumerating
    unique class values. This normalizes them so ``dropna()`` behaves.
    """
    if col not in obs.columns:
        return
    s = obs[col]
    if isinstance(s.dtype, pd.CategoricalDtype):
        bad = [c for c in s.cat.categories if str(c).strip().lower() in {"nan", "<na>", "none", ""}]
        if bad:
            s = s.cat.remove_categories(bad)
    else:
        s = s.replace({"nan": pd.NA, "<NA>": pd.NA, "None": pd.NA, "": pd.NA})
    obs[col] = s


def _build_source_lookup(collection_parquet: Path, experiment: str) -> dict:
    """Return mapping ``fov_name -> (store_path, channel_index)`` for the experiment.

    The collection parquet stores ``store_path`` and ``channel_name`` per row;
    we resolve the channel index by opening the zarr once per unique store.
    """
    df = pd.read_parquet(collection_parquet)
    sub = df[df["experiment"].astype(str) == experiment]
    if sub.empty:
        raise ValueError(f"No rows for experiment {experiment!r} in {collection_parquet}")
    sub = sub.assign(fov_name=sub["well"].astype(str) + "/" + sub["fov"].astype(str))
    lookup = {}
    channel_index_cache: dict[tuple[str, str], int] = {}
    for fov_name, grp in sub.groupby("fov_name"):
        store_path = grp["store_path"].iloc[0]
        channel_name = grp["channel_name"].iloc[0]
        key = (store_path, channel_name)
        if key not in channel_index_cache:
            with open_ome_zarr(store_path, mode="r") as plate:
                channel_index_cache[key] = plate.channel_names.index(channel_name)
        lookup[fov_name] = (store_path, channel_index_cache[key])
    return lookup


def _read_crop(
    store_path: str,
    fov_name: str,
    channel_idx: int,
    t: int,
    z: int,
    y: float,
    x: float,
    crop_size: int,
) -> np.ndarray:
    """Read a single (t, c, z, y, x) center crop from the source zarr."""
    with open_ome_zarr(store_path, mode="r") as plate:
        pos = plate[fov_name]
        z_clipped = int(np.clip(z, 0, pos.data.shape[2] - 1))
        plane = np.asarray(pos.data[int(t), channel_idx, z_clipped])
    return _crop_yx(plane, y, x, crop_size)


UNLABELED = "unlabeled"


def _sample_per_bucket(
    obs: pd.DataFrame,
    predicted_col: str,
    gt_col: str | None,
    n_per_bucket: int,
    seed: int,
) -> pd.DataFrame:
    """Sample ``n_per_bucket`` rows per (predicted, ground_truth) class pair.

    Cells with a prediction but no annotation are bucketed under
    ``__gt = "unlabeled"`` so they remain visible and distinguishable from
    annotated cells. If ``gt_col`` is None or absent, every cell is treated
    as unlabeled.
    """
    rng = np.random.default_rng(seed)
    chunks = []
    has_gt = gt_col is not None and gt_col in obs.columns
    pred_classes = sorted(obs[predicted_col].dropna().unique())
    if has_gt:
        gt_classes = sorted(obs[gt_col].dropna().unique()) + [UNLABELED]
    else:
        gt_classes = [UNLABELED]
    for pred_cls in pred_classes:
        for gt_cls in gt_classes:
            if not has_gt or gt_cls == UNLABELED:
                gt_mask = obs[gt_col].isna() if has_gt else pd.Series(True, index=obs.index)
            else:
                gt_mask = obs[gt_col] == gt_cls
            bucket = obs[(obs[predicted_col] == pred_cls) & gt_mask]
            if bucket.empty:
                continue
            take = min(n_per_bucket, len(bucket))
            idx = rng.choice(bucket.index.to_numpy(), size=take, replace=False)
            chosen = bucket.loc[idx].copy()
            chosen["__pred"] = pred_cls
            chosen["__gt"] = gt_cls
            chunks.append(chosen)
    return pd.concat(chunks, axis=0)


def render_grid(
    embeddings_zarr: Path,
    collection_parquet: Path,
    experiment: str,
    output_png: Path,
    task: str = "organelle_state",
    n_per_bucket: int = 6,
    crop_size: int = 192,
    seed: int = 0,
    perturbation_filter: str | None = None,
    disagreements_only: bool = False,
) -> None:
    """Render a grid of marker crops grouped by predicted vs ground-truth class.

    Parameters
    ----------
    embeddings_zarr : Path
        Anndata zarr produced by the linear-classifier step (contains
        ``predicted_<task>`` in ``.obs``).
    collection_parquet : Path
        Collection parquet used to train/predict; maps experiment+fov to source
        zarr + channel.
    experiment : str
        Experiment name to filter on (the embeddings file may contain only one
        already; this is mainly a sanity check).
    output_png : Path
        Destination PNG.
    task : str
        Classification task. One of ``"organelle_state"``, ``"infection_state"``,
        ``"cell_division_state"``, ``"cell_death_state"``. Ground-truth column
        must match this name; predicted column is ``predicted_<task>``.
    n_per_bucket : int
        Examples per (predicted, ground_truth) class pair.
    crop_size : int
        YX crop size in pixels.
    seed : int
        RNG seed for sampling.
    perturbation_filter : str | None
        If set, restrict to a single perturbation value (e.g. ``"infected"``).
    disagreements_only : bool
        If True, only sample cells where the prediction disagrees with the
        ground-truth label (rows are off-diagonal pred vs gt). Rows with missing
        ground truth are excluded. Use this to triage suspicious annotations.
    """
    adata = ad.read_zarr(embeddings_zarr)
    obs = adata.obs.copy()
    obs = obs[obs["experiment"].astype(str) == experiment]
    if perturbation_filter is not None:
        obs = obs[obs["perturbation"].astype(str) == perturbation_filter]
    if obs.empty:
        raise ValueError(
            f"No cells left after filtering experiment={experiment!r} "
            f"perturbation={perturbation_filter!r}"
        )

    predicted_col = f"predicted_{task}"
    if predicted_col not in obs.columns:
        raise ValueError(f"Missing {predicted_col!r} in embeddings {embeddings_zarr}")
    gt_col = task if task in obs.columns else None

    _normalize_missing_inplace(obs, predicted_col)
    if gt_col is not None:
        _normalize_missing_inplace(obs, gt_col)

    print(f"\nPopulation counts for {experiment} / {task}:")
    pred_view = obs[predicted_col].fillna(UNLABELED).astype(str)
    if gt_col is not None:
        gt_view = obs[gt_col].fillna(UNLABELED).astype(str)
        pop = (
            pd.crosstab(pred_view, gt_view, dropna=False)
            .rename_axis(index="predicted", columns="annotated")
        )
    else:
        pop = pred_view.value_counts().rename_axis("predicted").to_frame("n")
    print(pop.to_markdown())

    if disagreements_only:
        if gt_col is None:
            raise ValueError(
                f"disagreements_only=True requires ground-truth column {task!r}; "
                f"not present in {embeddings_zarr}"
            )
        obs_gt = obs[obs[gt_col].notna() & (obs[gt_col].astype(str) != "nan")]
        obs = obs_gt[obs_gt[predicted_col].astype(str) != obs_gt[gt_col].astype(str)]
        if obs.empty:
            print(f"No disagreements for {experiment} / {task} — skipping")
            return

    sampled = _sample_per_bucket(obs, predicted_col, gt_col, n_per_bucket, seed)

    print("Sampling summary:")
    summary = sampled.groupby(["__pred", "__gt"]).size().rename("n").reset_index()
    print(summary.to_markdown(index=False))

    source_lookup = _build_source_lookup(collection_parquet, experiment)
    marker = str(obs["marker"].iloc[0])
    cmap_for_marker = MARKER_COLORMAPS.get(marker, DEFAULT_COLORMAP)

    pred_classes = sorted(sampled["__pred"].unique())
    gt_classes = sorted(sampled["__gt"].unique())
    n_rows = len(pred_classes) * len(gt_classes)
    fig, axes = plt.subplots(
        n_rows,
        n_per_bucket,
        figsize=(1.6 * n_per_bucket, 1.6 * n_rows),
        squeeze=False,
    )

    row_i = 0
    for pred_cls in pred_classes:
        for gt_cls in gt_classes:
            bucket = sampled[(sampled["__pred"] == pred_cls) & (sampled["__gt"] == gt_cls)]
            for col_i in range(n_per_bucket):
                ax = axes[row_i, col_i]
                ax.set_xticks([])
                ax.set_yticks([])
                if col_i >= len(bucket):
                    ax.axis("off")
                    continue
                row = bucket.iloc[col_i]
                fov = str(row["fov_name"])
                if fov not in source_lookup:
                    ax.set_title(f"missing fov\n{fov}", fontsize=6)
                    ax.axis("off")
                    continue
                store_path, ch_idx = source_lookup[fov]
                crop = _read_crop(
                    store_path,
                    fov,
                    ch_idx,
                    int(row["t"]),
                    int(row["z"]),
                    float(row["y"]),
                    float(row["x"]),
                    crop_size,
                )
                vmin, vmax = np.percentile(crop, [1, 99])
                ax.imshow(crop, cmap=cmap_for_marker, vmin=vmin, vmax=vmax)
                ax.set_title(
                    f"{fov} t={int(row['t'])}",
                    fontsize=6,
                )
            axes[row_i, 0].set_ylabel(
                f"pred={pred_cls}\ngt={gt_cls}", fontsize=8, rotation=0, ha="right", va="center"
            )
            row_i += 1

    title = f"{experiment} | marker={marker} | task={task}"
    if perturbation_filter is not None:
        title += f" | {perturbation_filter}"
    if disagreements_only:
        title += " | DISAGREEMENTS ONLY"
    fig.suptitle(title, fontsize=10)
    fig.tight_layout(rect=(0, 0, 1, 0.97))
    output_png.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(output_png, dpi=150, bbox_inches="tight")
    plt.close(fig)
    print(f"Wrote {output_png}")


if __name__ == "__main__":
    EMBEDDINGS_ROOT = Path(
        "/hpc/projects/organelle_phenotyping/models/DynaCLR-2D-MIP-BagOfChannels"
        "/2d-mip-ntxent-t0p2-lr2e5-bs256-192to160-zext11-single-marker-fix-shuffler"
        "/evaluations/infectomics-annotated/embeddings"
    )
    COLLECTION_PARQUET = Path(
        "/hpc/projects/organelle_phenotyping/models/collections/DynaCLR-BoC-lc-evaluation-v1.parquet"
    )
    OUTPUT_DIR = Path(
        "/hpc/mydata/eduardo.hirata/repos/viscy/applications/dynaclr/scripts/linear_classifiers/inspect_outputs"
    )

    # (experiment, zarr_name, task) — ZIKV-only embeddings.
    targets = [
        # organelle_state — only G3BP1 and SEC61B markers have this classifier.
        ("2025_07_24_A549_G3BP1_ZIKV", "2025_07_24_A549_G3BP1_ZIKV.zarr", "organelle_state"),
        ("2025_07_22_A549_G3BP1_ZIKV", "2025_07_22_A549_G3BP1_ZIKV.zarr", "organelle_state"),
        ("2025_07_24_A549_SEC61_ZIKV", "2025_07_24_A549_SEC61_ZIKV.zarr", "organelle_state"),
        ("2025_08_26_A549_SEC61_ZIKV", "2025_08_26_A549_SEC61_ZIKV.zarr", "organelle_state"),
        # infection_state on viral_sensor (the readout channel for infection).
        ("2025_07_22_A549_viral_sensor_ZIKV", "2025_07_22_A549_viral_sensor_ZIKV.zarr", "infection_state"),
        ("2025_07_24_A549_viral_sensor_ZIKV", "2025_07_24_A549_viral_sensor_ZIKV.zarr", "infection_state"),
        ("2025_08_26_A549_viral_sensor_ZIKV", "2025_08_26_A549_viral_sensor_ZIKV.zarr", "infection_state"),
        # infection_state and cell_division_state on Phase3D.
        ("2025_07_22_A549_Phase3D_ZIKV", "2025_07_22_A549_Phase3D_ZIKV.zarr", "infection_state"),
        ("2025_07_24_A549_Phase3D_ZIKV", "2025_07_24_A549_Phase3D_ZIKV.zarr", "infection_state"),
        ("2025_08_26_A549_Phase3D_ZIKV", "2025_08_26_A549_Phase3D_ZIKV.zarr", "infection_state"),
        ("2025_07_22_A549_Phase3D_ZIKV", "2025_07_22_A549_Phase3D_ZIKV.zarr", "cell_division_state"),
        ("2025_07_24_A549_Phase3D_ZIKV", "2025_07_24_A549_Phase3D_ZIKV.zarr", "cell_division_state"),
    ]
    DISAGREEMENTS_ONLY = True
    for experiment, zarr_name, task in targets:
        # cell_division_state: don't restrict by perturbation (mitosis is rare).
        pert_filter = None if task == "cell_division_state" else "infected"
        suffix = "disagreements" if DISAGREEMENTS_ONLY else "inspect"
        render_grid(
            embeddings_zarr=EMBEDDINGS_ROOT / zarr_name,
            collection_parquet=COLLECTION_PARQUET,
            experiment=experiment,
            output_png=OUTPUT_DIR / f"{experiment}_{task}_{suffix}.png",
            task=task,
            n_per_bucket=8,
            crop_size=192,
            seed=42,
            perturbation_filter=pert_filter,
            disagreements_only=DISAGREEMENTS_ONLY,
        )
