"""Rank prediction/annotation disagreements and render a focused triage grid.

For each (experiment, task), this script finds cells where the linear
classifier's prediction disagrees with the human annotation, then ranks them
by the classifier's confidence in its own (wrong-vs-annotation) call. The
top-N rows go into:

1. A CSV (per experiment + task) with ``(fov_name, track_id, t, y, x,
   predicted, annotated, confidence)`` — open this alongside napari and jump
   to each cell by ``(fov_name, track_id, t)``.
2. A PNG grid showing the same top-N crops, with track_id in the title so
   you can re-locate the cell in the napari annotator.

Reuses helpers from ``inspect_organelle_predictions.py``.

Edit the constants at the bottom of the file and run:

    python applications/dynaclr/scripts/linear_classifiers/triage_suspicious_annotations.py
"""

from pathlib import Path

import anndata as ad
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from inspect_organelle_predictions import (
    DEFAULT_COLORMAP,
    MARKER_COLORMAPS,
    UNLABELED,
    _build_source_lookup,
    _normalize_missing_inplace,
    _read_crop,
)


def _rank_disagreements(
    adata: ad.AnnData,
    obs_mask: np.ndarray,
    task: str,
) -> pd.DataFrame:
    """Return rows where ``predicted_<task>`` disagrees with ``<task>`` GT,
    ranked by classifier confidence in the predicted class (descending).

    Parameters
    ----------
    adata : ad.AnnData
        Embeddings anndata with predictions appended.
    obs_mask : np.ndarray
        Boolean mask over ``adata.obs`` rows (e.g. experiment + perturbation
        filter).
    task : str
        Task name (e.g. ``"organelle_state"``).

    Returns
    -------
    pd.DataFrame
        Disagreement rows with columns: ``fov_name``, ``track_id``, ``t``,
        ``y``, ``x``, ``predicted``, ``annotated``, ``confidence``.
    """
    gt_col = task
    pred_col = f"predicted_{task}"
    proba_key = f"predicted_{task}_proba"
    classes_key = f"predicted_{task}_classes"

    if proba_key not in adata.obsm:
        raise KeyError(f"Missing obsm[{proba_key!r}] in embeddings")
    if classes_key not in adata.uns:
        raise KeyError(f"Missing uns[{classes_key!r}] in embeddings")

    classes = np.array([str(c) for c in adata.uns[classes_key]])
    proba = np.asarray(adata.obsm[proba_key])

    obs = adata.obs.copy().reset_index(drop=True)
    _normalize_missing_inplace(obs, pred_col)
    _normalize_missing_inplace(obs, gt_col)

    mask = np.asarray(obs_mask) & obs[gt_col].notna().to_numpy() & obs[pred_col].notna().to_numpy()
    pred_str = obs[pred_col].astype(str)
    gt_str = obs[gt_col].astype(str)
    disagree = mask & (pred_str != gt_str).to_numpy()

    sub = obs.loc[disagree, ["fov_name", "track_id", "t", "y", "x", pred_col, gt_col]].copy()
    sub = sub.rename(columns={pred_col: "predicted", gt_col: "annotated"})

    pred_class_idx = np.array(
        [np.where(classes == p)[0][0] for p in sub["predicted"].astype(str)]
    )
    proba_disagree = proba[disagree.nonzero()[0]]
    sub["confidence"] = proba_disagree[np.arange(len(sub)), pred_class_idx]

    return sub.sort_values("confidence", ascending=False).reset_index(drop=True)


def triage_one(
    embeddings_zarr: Path,
    collection_parquet: Path,
    experiment: str,
    task: str,
    output_csv: Path,
    output_png: Path,
    top_n: int = 48,
    crop_size: int = 192,
    perturbation_filter: str | None = "infected",
) -> None:
    """Run the triage workflow for one (experiment, task) pair.

    Parameters
    ----------
    embeddings_zarr : Path
        Anndata zarr with predictions + probas appended.
    collection_parquet : Path
        Collection parquet used to resolve source zarr paths + channel index.
    experiment : str
        Experiment name to filter on.
    task : str
        Classification task name (e.g. ``"organelle_state"``).
    output_csv : Path
        Destination CSV of ranked disagreements.
    output_png : Path
        Destination PNG grid showing the top-N crops.
    top_n : int
        How many highest-confidence disagreements to render.
    crop_size : int
        YX crop size in pixels.
    perturbation_filter : str | None
        Restrict to a single perturbation (e.g. ``"infected"``); ``None`` to
        skip the filter.
    """
    adata = ad.read_zarr(embeddings_zarr)
    obs = adata.obs.reset_index(drop=True)
    mask = (obs["experiment"].astype(str) == experiment).to_numpy().copy()
    if perturbation_filter is not None:
        mask &= (obs["perturbation"].astype(str) == perturbation_filter).to_numpy()
    if not mask.any():
        print(f"[{experiment} / {task}] no rows after filter — skipping")
        return

    ranked = _rank_disagreements(adata, mask, task)
    ranked.insert(0, "experiment", experiment)
    ranked.insert(1, "task", task)

    output_csv.parent.mkdir(parents=True, exist_ok=True)
    ranked.to_csv(output_csv, index=False)
    print(f"[{experiment} / {task}] {len(ranked)} disagreements -> {output_csv.name}")

    if ranked.empty:
        print(f"[{experiment} / {task}] no disagreements to render")
        return

    top = ranked.head(top_n).copy()
    print(top[["fov_name", "track_id", "t", "predicted", "annotated", "confidence"]].to_markdown(index=False))

    source_lookup = _build_source_lookup(collection_parquet, experiment)
    marker = str(obs.loc[mask, "marker"].iloc[0])
    cmap_for_marker = MARKER_COLORMAPS.get(marker, DEFAULT_COLORMAP)

    n_cols = 8
    n_rows = int(np.ceil(len(top) / n_cols))
    fig, axes = plt.subplots(
        n_rows, n_cols, figsize=(1.7 * n_cols, 1.7 * n_rows), squeeze=False
    )
    for ax in axes.flat:
        ax.set_xticks([])
        ax.set_yticks([])

    for i, row in top.reset_index(drop=True).iterrows():
        ax = axes[i // n_cols, i % n_cols]
        fov = str(row["fov_name"])
        if fov not in source_lookup:
            ax.set_title(f"missing fov\n{fov}", fontsize=6)
            ax.axis("off")
            continue
        store_path, ch_idx = source_lookup[fov]
        crop = _read_crop(
            store_path,
            fov,
            ch_idx,
            int(row["t"]),
            int(getattr(row, "z", 0) or 0),
            float(row["y"]),
            float(row["x"]),
            crop_size,
        )
        vmin, vmax = np.percentile(crop, [1, 99])
        ax.imshow(crop, cmap=cmap_for_marker, vmin=vmin, vmax=vmax)
        ax.set_title(
            f"{fov} trk={int(row['track_id'])} t={int(row['t'])}\n"
            f"pred={row['predicted']} gt={row['annotated']} "
            f"conf={row['confidence']:.2f}",
            fontsize=6,
        )

    for j in range(len(top), n_rows * n_cols):
        axes[j // n_cols, j % n_cols].axis("off")

    fig.suptitle(
        f"{experiment} | marker={marker} | task={task} | top-{top_n} disagreements by confidence",
        fontsize=10,
    )
    fig.tight_layout(rect=(0, 0, 1, 0.97))
    output_png.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(output_png, dpi=150, bbox_inches="tight")
    plt.close(fig)
    print(f"Wrote {output_png}")


if __name__ == "__main__":
    EMBEDDINGS_ROOT = Path(
        "/hpc/projects/organelle_phenotyping/models/DynaCLR-2D-MIP-BagOfChannels"
        "/2d-mip-ntxent-t0p2-lr2e5-bs256-192to160-zext11-single-marker-fix-shuffler"
        "/evaluations/infectomics-annotated/embeddings"
    )
    COLLECTION_PARQUET = Path(
        "/hpc/projects/organelle_phenotyping/models/collections/DynaCLR-BoC-lc-evaluation-v1.parquet"
    )
    OUTPUT_DIR = Path(
        "/hpc/mydata/eduardo.hirata/repos/viscy/applications/dynaclr/scripts/linear_classifiers/triage_outputs"
    )

    targets = [
        ("2025_07_24_A549_G3BP1_ZIKV", "2025_07_24_A549_G3BP1_ZIKV.zarr", "organelle_state"),
        ("2025_07_22_A549_G3BP1_ZIKV", "2025_07_22_A549_G3BP1_ZIKV.zarr", "organelle_state"),
        ("2025_07_24_A549_SEC61_ZIKV", "2025_07_24_A549_SEC61_ZIKV.zarr", "organelle_state"),
        ("2025_07_22_A549_viral_sensor_ZIKV", "2025_07_22_A549_viral_sensor_ZIKV.zarr", "infection_state"),
        ("2025_07_24_A549_viral_sensor_ZIKV", "2025_07_24_A549_viral_sensor_ZIKV.zarr", "infection_state"),
        ("2025_08_26_A549_viral_sensor_ZIKV", "2025_08_26_A549_viral_sensor_ZIKV.zarr", "infection_state"),
        ("2025_07_22_A549_Phase3D_ZIKV", "2025_07_22_A549_Phase3D_ZIKV.zarr", "infection_state"),
        ("2025_07_24_A549_Phase3D_ZIKV", "2025_07_24_A549_Phase3D_ZIKV.zarr", "infection_state"),
        ("2025_08_26_A549_Phase3D_ZIKV", "2025_08_26_A549_Phase3D_ZIKV.zarr", "infection_state"),
        ("2025_07_22_A549_Phase3D_ZIKV", "2025_07_22_A549_Phase3D_ZIKV.zarr", "cell_division_state"),
        ("2025_07_24_A549_Phase3D_ZIKV", "2025_07_24_A549_Phase3D_ZIKV.zarr", "cell_division_state"),
    ]

    for experiment, zarr_name, task in targets:
        pert = None if task == "cell_division_state" else "infected"
        triage_one(
            embeddings_zarr=EMBEDDINGS_ROOT / zarr_name,
            collection_parquet=COLLECTION_PARQUET,
            experiment=experiment,
            task=task,
            output_csv=OUTPUT_DIR / f"{experiment}_{task}_disagreements.csv",
            output_png=OUTPUT_DIR / f"{experiment}_{task}_disagreements.png",
            top_n=48,
            crop_size=192,
            perturbation_filter=pert,
        )
