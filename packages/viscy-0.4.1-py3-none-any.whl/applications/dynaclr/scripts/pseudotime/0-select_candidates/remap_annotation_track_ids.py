"""Remap an annotation CSV's track_ids to match the embedding tracker.

Annotation CSVs from one tracking run are sometimes joined against
embedding zarrs from a *different* tracking run. The (fov, t, y, x)
centroids match across the two — the same physical cells were found —
but the integer ``track_id`` labels are independent. Without a remap,
``align_embedding.py`` outputs track_ids that don't appear in the
annotation CSV's track_id column, and quantitative recall against
annotations becomes unjoinable.

This script rewrites the annotation CSV's ``track_id`` column using a
centroid lookup against a ``tracking.zarr`` (the segmentation labels
from the embedding's tracker):

  emb_track_id = tracking.zarr[fov][t, 0, 0, y, x]

For each (fov, original_track_id) we take the **mode** across all its
annotated frames as the canonical embedding track_id, so a single
mis-segmented frame doesn't split an annotation track.

Versioning convention (per project policy):

- The current annotation CSV at ``{root}/{dataset}_combined_annotations.csv``
  is moved to ``{root}/v1/{dataset}_combined_annotations.csv`` (or v2, v3,
  ... if v1 already exists).
- The remapped CSV is written in place at the original path so any code
  that reads "the annotation CSV" gets the remapped version by default.
- The original annotation track_id is preserved on every row as a new
  column ``track_id_annotation``.

Usage::

    cd applications/dynaclr/scripts/pseudotime/0-select_candidates
    uv run python remap_annotation_track_ids.py \\
        --annotations /hpc/projects/.../2025_07_22_..._combined_annotations.csv \\
        --tracking-zarr /hpc/projects/.../2025_07_22_.../tracking.zarr
"""

from __future__ import annotations

import argparse
import logging
import shutil
from collections import Counter
from pathlib import Path

import numpy as np
import pandas as pd
from iohub import open_ome_zarr

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(levelname)s %(message)s")
_logger = logging.getLogger(__name__)


def _next_version_dir(root: Path) -> Path:
    """Return ``root/v{N}`` where N is one greater than any existing v* dir."""
    existing = [int(p.name[1:]) for p in root.iterdir() if p.is_dir() and p.name.startswith("v") and p.name[1:].isdigit()]
    n = (max(existing) + 1) if existing else 1
    return root / f"v{n}"


def _lookup_neighborhood_label(plane: np.ndarray, y: int, x: int, half: int) -> int:
    """Return the most common non-zero label in a ``(2*half+1)`` square window.

    When ``half == 0`` this reduces to a single-pixel lookup. With ``half > 0``
    the lookup pulls a small kernel around the centroid to:

    - rescue rows where the centroid rounded onto a background pixel between
      cells (single-pixel lookup returns 0),
    - resist 1-2 px centroid noise that pulls a row into a neighbor's label
      (mode of the window snaps back to the dominant cell).

    Returns 0 only when the entire window is background.
    """
    if half == 0:
        return int(plane[y, x])
    H, W = plane.shape
    y0 = max(0, y - half); y1 = min(H, y + half + 1)
    x0 = max(0, x - half); x1 = min(W, x + half + 1)
    window = plane[y0:y1, x0:x1]
    nonzero = window[window > 0]
    if nonzero.size == 0:
        return 0
    # Counter is faster than np.unique here for tiny windows.
    return int(Counter(nonzero.tolist()).most_common(1)[0][0])


def remap_fov(
    fov_df: pd.DataFrame,
    labels_array,
    fov_name: str,
    kernel_half: int = 0,
) -> pd.DataFrame:
    """Add ``embedding_track_id`` column by looking up tracking.zarr labels.

    Parameters
    ----------
    fov_df : pd.DataFrame
        Annotation rows for a single FOV. Must have ``t, y, x`` columns.
    labels_array
        A 5-D zarr array shaped ``(T, C=1, Z=1, Y, X)`` from the tracking
        zarr's position. Integer label per pixel (0 = background).
    fov_name : str
        Used only for log messages.
    kernel_half : int
        Half-side of the square window around each centroid. 0 = single-pixel
        lookup (legacy behavior). N>0 = ``(2*N+1)`` square window; per-row
        label is the **mode of non-zero values** in the window. Defaults to 0
        for backwards compatibility; pass 2 (5x5 window) to rescue centroids
        that fall on cell boundaries.

    Returns
    -------
    pd.DataFrame
        Copy of ``fov_df`` with an added int64 ``embedding_track_id`` column
        (0 where the window was entirely background or out-of-bounds).
    """
    sub = fov_df.copy()
    sub["t"] = sub["t"].astype(int)
    ys = np.clip(np.round(sub["y"].to_numpy(dtype=float)).astype(int), 0, labels_array.shape[3] - 1)
    xs = np.clip(np.round(sub["x"].to_numpy(dtype=float)).astype(int), 0, labels_array.shape[4] - 1)
    ts = sub["t"].to_numpy()
    new_tids = np.zeros(len(sub), dtype=np.int64)
    for t in np.unique(ts):
        mask = ts == t
        if t < 0 or t >= labels_array.shape[0]:
            continue
        plane = np.asarray(labels_array[int(t), 0, 0])  # (Y, X)
        if kernel_half == 0:
            # Vectorized single-pixel path (fast).
            new_tids[mask] = plane[ys[mask], xs[mask]]
        else:
            # Per-row neighborhood lookup. The tracking zarr is small per FOV
            # (~700×1100 px) so this is cheap even with a Python loop.
            for i in np.flatnonzero(mask):
                new_tids[i] = _lookup_neighborhood_label(plane, int(ys[i]), int(xs[i]), kernel_half)
    sub["embedding_track_id"] = new_tids
    n_mapped = (new_tids > 0).sum()
    _logger.info(
        f"  [{fov_name}] {n_mapped}/{len(sub)} rows mapped "
        f"({100 * n_mapped / max(1, len(sub)):.0f}%, kernel={2 * kernel_half + 1}x{2 * kernel_half + 1})"
    )
    return sub


def main() -> None:
    """Run the remap and version the original CSV."""
    parser = argparse.ArgumentParser(description="Remap annotation track_ids to embedding tracker via centroid lookup")
    parser.add_argument("--annotations", required=True, type=Path, help="Path to the annotation CSV (will be overwritten)")
    parser.add_argument(
        "--tracking-zarr", required=True, type=Path,
        help="Path to the tracking.zarr (pixel-wise integer labels, channel 0)",
    )
    parser.add_argument(
        "--min-frames-for-mode", type=int, default=3,
        help="Drop annotation tracks with fewer than this many mapped frames; "
             "modes computed from very short tracks are unreliable (default: 3)",
    )
    parser.add_argument(
        "--kernel-half", type=int, default=2,
        help="Half-side of the square neighborhood window around each centroid (default: 2 → 5x5). "
             "0 = single-pixel lookup. Use ≥2 to rescue rows whose centroid rounded onto a boundary "
             "pixel between cells and to resist ±1-2 px centroid noise pulling rows into a neighbor's label.",
    )
    args = parser.parse_args()

    ann_path = args.annotations.resolve()
    if not ann_path.exists():
        raise FileNotFoundError(f"Annotation CSV not found: {ann_path}")
    tracking_zarr = args.tracking_zarr.resolve()
    if not tracking_zarr.exists():
        raise FileNotFoundError(f"Tracking zarr not found: {tracking_zarr}")

    _logger.info(f"Reading annotations: {ann_path}")
    ann = pd.read_csv(ann_path)
    required = {"fov_name", "track_id", "t", "y", "x"}
    missing = required - set(ann.columns)
    if missing:
        raise KeyError(f"Annotation CSV missing required columns: {sorted(missing)}")
    ann["fov_name"] = ann["fov_name"].astype(str)
    ann["track_id"] = ann["track_id"].astype(int)

    # Preserve the original track_id before we overwrite it.
    ann["track_id_annotation"] = ann["track_id"]

    _logger.info(f"Opening tracking zarr: {tracking_zarr}")
    remapped_parts: list[pd.DataFrame] = []
    fov_stats: list[dict] = []
    with open_ome_zarr(str(tracking_zarr), mode="r") as plate:
        available_fovs = {name for name, _ in plate.positions()}
        for fov_name, fov_df in ann.groupby("fov_name", sort=False):
            if fov_name not in available_fovs:
                _logger.warning(f"  [{fov_name}] not present in tracking zarr — leaving track_ids unchanged")
                # keep rows but mark with embedding_track_id=NaN -> 0
                fov_df = fov_df.copy()
                fov_df["embedding_track_id"] = 0
                remapped_parts.append(fov_df)
                fov_stats.append({"fov_name": fov_name, "n_rows": len(fov_df), "n_mapped": 0, "in_tracking_zarr": False})
                continue
            position = plate[fov_name]
            labels = position["0"]
            mapped = remap_fov(fov_df, labels, fov_name, kernel_half=args.kernel_half)
            remapped_parts.append(mapped)
            fov_stats.append({
                "fov_name": fov_name,
                "n_rows": len(mapped),
                "n_mapped": int((mapped["embedding_track_id"] > 0).sum()),
                "in_tracking_zarr": True,
            })

    remapped = pd.concat(remapped_parts, ignore_index=True)

    # Per (fov, original_track_id), take the mode of mapped embedding_track_id
    # over rows where label > 0. Single-frame or all-background tracks are
    # left with track_id_annotation as the fallback.
    _logger.info("Computing per-track mode of embedding_track_id")
    mode_records: list[dict] = []
    for (fov, ann_tid), g in remapped.groupby(["fov_name", "track_id_annotation"], sort=False):
        mapped = g[g["embedding_track_id"] > 0]
        if len(mapped) < args.min_frames_for_mode:
            new_tid = int(ann_tid)  # fallback: keep original ID; flagged below
            confidence = 0.0
            n_distinct = 0
        else:
            counts = Counter(mapped["embedding_track_id"].astype(int).tolist())
            new_tid, top_n = counts.most_common(1)[0]
            confidence = top_n / len(mapped)
            n_distinct = len(counts)
        mode_records.append({
            "fov_name": fov,
            "track_id_annotation": int(ann_tid),
            "embedding_track_id_mode": int(new_tid),
            "confidence": float(confidence),
            "n_mapped_frames": int(len(mapped)),
            "n_distinct_emb_tracks": n_distinct,
        })
    mode_df = pd.DataFrame(mode_records)

    # Diagnostics: how many tracks remap confidently?
    n_total_tracks = len(mode_df)
    n_high_conf = int((mode_df["confidence"] >= 0.9).sum())
    n_medium = int(((mode_df["confidence"] >= 0.5) & (mode_df["confidence"] < 0.9)).sum())
    n_low = int((mode_df["confidence"] < 0.5).sum())
    _logger.info(
        f"Track-level remap: {n_total_tracks} annotation tracks → "
        f"{n_high_conf} high-conf (≥90%), {n_medium} medium (50–89%), {n_low} low/empty (<50%)"
    )

    # Many-to-one: do multiple annotation tracks remap to the same embedding track?
    emb_to_ann = mode_df.groupby(["fov_name", "embedding_track_id_mode"]).size()
    n_collisions = int((emb_to_ann > 1).sum())
    if n_collisions:
        _logger.info(
            f"  {n_collisions} embedding tracks are the destination of >1 annotation track "
            "(probably parent+daughter pairs collapsed by one tracker but split by the other)"
        )

    # Apply the mode mapping back to every annotation row.
    mode_lookup = {
        (str(r["fov_name"]), int(r["track_id_annotation"])): int(r["embedding_track_id_mode"])
        for _, r in mode_df.iterrows()
    }
    remapped["track_id"] = remapped.apply(
        lambda r: mode_lookup.get((str(r["fov_name"]), int(r["track_id_annotation"])), int(r["track_id_annotation"])),
        axis=1,
    ).astype(int)
    # Drop the per-row embedding_track_id helper column; the per-track mode
    # in `track_id` is the canonical answer.
    remapped = remapped.drop(columns=["embedding_track_id"])

    # Archive the original CSV under v{N}/ next to it.
    archive_dir = _next_version_dir(ann_path.parent)
    archive_dir.mkdir(parents=True, exist_ok=False)
    archived_path = archive_dir / ann_path.name
    shutil.copy2(ann_path, archived_path)
    _logger.info(f"Archived original to {archived_path}")

    # Overwrite the original path with the remapped version.
    remapped.to_csv(ann_path, index=False)
    _logger.info(f"Wrote remapped CSV in place: {ann_path}")
    _logger.info(f"  {len(remapped)} rows; column 'track_id' is now the embedding tracker's id; "
                 "'track_id_annotation' preserves the original.")


if __name__ == "__main__":
    main()
