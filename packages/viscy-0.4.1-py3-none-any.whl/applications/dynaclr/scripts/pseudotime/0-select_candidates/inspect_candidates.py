r"""Visualize a candidate-set's tracks as a per-track-anchored image montage + QC table.

Stage 0 diagnostic. Reads ``candidates/{candidate_set}_annotations.csv``,
anchors each row at that cell's ``t_key_event`` (first positive ``anchor_label``
frame), and renders a montage where every row spans the same relative-time
window so bad candidates are easy to spot by scanning down.

Also writes a sidecar CSV with per-track stats (n_frames, pre/post headroom,
anchor frame, FOV) for non-visual QC.

Usage::

    cd applications/dynaclr/scripts/pseudotime/0-select_candidates
    uv run python inspect_candidates.py \
        --datasets ../../../configs/pseudotime/datasets.yaml \
        --config ../../../configs/pseudotime/build_template.yaml \
        --candidate-set infection_transitioning_nondiv
"""

from __future__ import annotations

import argparse
import logging
import sys
from pathlib import Path

import matplotlib
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from anndata import read_zarr
from iohub import open_ome_zarr

matplotlib.use("Agg")

from dynaclr.pseudotime import date_prefix_from_dataset_id, find_embedding_zarr

SCRIPT_DIR = Path(__file__).resolve().parent
CANDIDATES_DIR = SCRIPT_DIR / "candidates"

sys.path.insert(0, str(SCRIPT_DIR.parent))
from utils import load_stage_config, read_focus_slice  # noqa: E402

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(levelname)s %(message)s")
_logger = logging.getLogger(__name__)


def _load_xy_lookup(embedding_zarr: str) -> dict[tuple[str, int, int], tuple[int, int]]:
    """Build ``(fov_name, track_id, t) -> (x, y)`` lookup from ``adata.obs``."""
    adata = read_zarr(embedding_zarr)
    adata.obs_names_make_unique()
    obs = adata.obs
    return {
        (str(row["fov_name"]), int(row["track_id"]), int(row["t"])): (
            int(row["x"]),
            int(row["y"]),
        )
        for _, row in obs.iterrows()
    }


def _mip_crop(
    img_arr,
    t: int,
    z_center: int,
    y: int,
    x: int,
    channel: int,
    crop_half: int,
    mip_half: int,
) -> np.ndarray | None:
    """MIP over ``[z_center - mip_half, z_center + mip_half]`` slices at (y, x)."""
    if t < 0 or t >= img_arr.shape[0]:
        return None
    if channel < 0 or channel >= img_arr.shape[1]:
        return None
    z0 = max(0, z_center - mip_half)
    z1 = min(img_arr.shape[2], z_center + mip_half + 1)
    if z1 <= z0:
        return None
    y0, y1 = max(0, y - crop_half), min(img_arr.shape[3], y + crop_half)
    x0, x1 = max(0, x - crop_half), min(img_arr.shape[4], x + crop_half)
    stack = np.asarray(img_arr[t, channel, z0:z1, y0:y1, x0:x1])
    return stack.max(axis=0)


def _build_track_summary(ann_df: pd.DataFrame, anchor_label: str, anchor_positive: str) -> pd.DataFrame:
    """Reduce the annotation CSV to one row per track with anchor + window info.

    Columns: dataset_id, fov_name, track_id, t_min, t_max, t_key_event, n_frames,
    pre_frames, post_frames.
    """
    pos = ann_df[ann_df[anchor_label] == anchor_positive]
    t_key = pos.groupby(["dataset_id", "fov_name", "track_id"])["t"].min().rename("t_key_event").reset_index()
    window = (
        ann_df.groupby(["dataset_id", "fov_name", "track_id"])
        .agg(t_min=("t", "min"), t_max=("t", "max"), n_frames=("t", "nunique"))
        .reset_index()
    )
    out = window.merge(t_key, on=["dataset_id", "fov_name", "track_id"], how="left")
    out["pre_frames"] = out["t_key_event"] - out["t_min"]
    out["post_frames"] = out["t_max"] - out["t_key_event"]
    return out.sort_values(["dataset_id", "fov_name", "track_id"]).reset_index(drop=True)


def main() -> None:
    """Render the per-track-anchored montage + QC CSV for a candidate set."""
    parser = argparse.ArgumentParser(description="Inspect a candidate set (Stage 0 diagnostic)")
    parser.add_argument("--datasets", required=True, help="Path to datasets.yaml")
    parser.add_argument("--config", required=True, help="Path to build_template.yaml")
    parser.add_argument("--candidate-set", required=True, help="Name under config['candidate_sets']")
    parser.add_argument(
        "--offset-frames",
        type=int,
        default=7,
        help="Half-window around each track's t_key_event (frames, dataset-specific time scale).",
    )
    parser.add_argument("--crop-half", type=int, default=80, help="Half side of crop square (px)")
    parser.add_argument("--mip-half", type=int, default=5, help="Half-thickness of MIP window (z slices)")
    parser.add_argument("--channel-index", type=int, default=2, help="Image-zarr channel index")
    parser.add_argument("--channel-name", default="mCherry", help="Display name for the channel")
    parser.add_argument("--focus-channel", default="Phase3D", help="Channel key in zattrs.focus_slice")
    args = parser.parse_args()

    config = load_stage_config(args.datasets, args.config)
    dataset_cfgs = {d["dataset_id"]: d for d in config["datasets"]}
    cand_sets = config.get("candidate_sets", {})
    if args.candidate_set not in cand_sets:
        raise KeyError(f"Candidate set {args.candidate_set!r} not in config['candidate_sets']")
    cand_cfg = cand_sets[args.candidate_set]
    # Refined sets inherit the filter (anchor_label/anchor_positive) from their parent.
    if "filter" in cand_cfg:
        filter_src = cand_cfg["filter"]
    else:
        parent_name = cand_cfg.get("refine_from")
        if not parent_name or parent_name not in cand_sets:
            raise KeyError(f"Candidate set {args.candidate_set!r} has no 'filter' and no resolvable 'refine_from'")
        filter_src = cand_sets[parent_name]["filter"]
    anchor_label = filter_src["anchor_label"]
    anchor_positive = filter_src["anchor_positive"]

    ann_path = CANDIDATES_DIR / f"{args.candidate_set}_annotations.csv"
    if not ann_path.exists():
        raise FileNotFoundError(f"Annotations CSV not found: {ann_path}. Run select_candidates.py first.")
    ann_df = pd.read_csv(ann_path)
    _logger.info(f"Read {ann_path}: {len(ann_df)} rows")

    tracks = _build_track_summary(ann_df, anchor_label, anchor_positive)
    _logger.info(f"  {len(tracks)} tracks across {tracks['dataset_id'].nunique()} datasets")

    # Sidecar QC CSV — per-track stats for non-visual inspection.
    qc_path = CANDIDATES_DIR / f"{args.candidate_set}_qc.csv"
    tracks.to_csv(qc_path, index=False)
    _logger.info(f"Wrote {qc_path}")

    # Resolve per-dataset resources. Use per-dataset data_zarr if present,
    # else fall back to the top-level one in datasets.yaml.
    default_data_zarr = config.get("data_zarr")
    embedding_channel = "sensor"  # inspection always on the sensor channel (mCherry)
    embedding_pattern = config["embeddings"][embedding_channel]
    plate_cache: dict[str, object] = {}
    xy_cache: dict[str, dict] = {}
    position_cache: dict[tuple[str, str], tuple] = {}

    # Columns: -offset .. 0 .. +offset  (offset in frames; each dataset has its
    # own frame_interval, so these are frame-unit offsets, not minutes).
    offsets = np.arange(-args.offset_frames, args.offset_frames + 1)
    n_rows = len(tracks)
    n_cols = len(offsets)

    fig, axes = plt.subplots(n_rows, n_cols, figsize=(n_cols * 0.6, n_rows * 0.6))
    if n_rows == 1:
        axes = axes[np.newaxis, :]
    if n_cols == 1:
        axes = axes[:, np.newaxis]

    for row_idx, track in tracks.iterrows():
        ds_id = track["dataset_id"]
        fov = str(track["fov_name"])
        tid = int(track["track_id"])
        t_key = int(track["t_key_event"]) if pd.notna(track["t_key_event"]) else None
        t_min = int(track["t_min"])
        t_max = int(track["t_max"])

        ds_cfg = dataset_cfgs[ds_id]
        data_zarr_path = ds_cfg.get("data_zarr", default_data_zarr)
        if data_zarr_path is None:
            raise KeyError(f"No data_zarr for dataset {ds_id!r} (neither per-dataset nor top-level fallback)")

        if ds_id not in plate_cache:
            plate_cache[ds_id] = open_ome_zarr(data_zarr_path, mode="r")
            emb_zarr = find_embedding_zarr(ds_cfg["pred_dir"], date_prefix_from_dataset_id(ds_id) + embedding_pattern)
            xy_cache[ds_id] = _load_xy_lookup(emb_zarr)
        plate = plate_cache[ds_id]
        xy_lookup = xy_cache[ds_id]

        pos_key = (ds_id, fov)
        if pos_key not in position_cache:
            try:
                position = plate[fov]
                img_arr = position["0"]
            except (KeyError, IndexError):
                img_arr, position = None, None
            position_cache[pos_key] = (img_arr, position)
        img_arr, position = position_cache[pos_key]

        for col_idx, offset in enumerate(offsets):
            ax = axes[row_idx, col_idx]
            ax.set_xticks([])
            ax.set_yticks([])

            t_abs = None if t_key is None else int(t_key + offset)
            in_track = t_abs is not None and t_min <= t_abs <= t_max
            xy = xy_lookup.get((fov, tid, t_abs)) if in_track else None
            crop = None
            if xy is not None and img_arr is not None and position is not None:
                x, y = xy
                try:
                    z_center = read_focus_slice(position, args.focus_channel, level="timepoint", timepoint=t_abs)
                except KeyError:
                    z_center = img_arr.shape[2] // 2
                crop = _mip_crop(img_arr, t_abs, int(z_center), y, x, args.channel_index, args.crop_half, args.mip_half)

            if crop is not None and crop.size > 0:
                vmin, vmax = np.percentile(crop, [2, 98])
                if vmax <= vmin:
                    vmax = vmin + 1
                ax.imshow(crop, cmap="gray", vmin=vmin, vmax=vmax)
            else:
                ax.set_facecolor("#e0e0e0")

            if offset == 0:
                for spine in ax.spines.values():
                    spine.set_visible(True)
                    spine.set_color("red")
                    spine.set_linewidth(1.5)
            else:
                for spine in ax.spines.values():
                    spine.set_visible(False)

            if row_idx == 0:
                ax.set_title(f"{offset:+d}", fontsize=6)

        axes[row_idx, 0].set_ylabel(
            f"{ds_id.split('_')[-1]}\n{fov}\ntrack={tid}\nt_key={t_key}",
            fontsize=4,
            rotation=0,
            labelpad=45,
            va="center",
        )

    fig.suptitle(
        f"Candidate montage — {args.candidate_set} ({args.channel_name} ch {args.channel_index})\n"
        f"rows = {n_rows} tracks anchored at t_key_event (red border at offset 0)  |  "
        f"columns = frame offsets {offsets.min():+d}..{offsets.max():+d}",
        fontsize=9,
    )
    fig.subplots_adjust(wspace=0.03, hspace=0.05)

    out_path = CANDIDATES_DIR / f"{args.candidate_set}_montage.png"
    fig.savefig(out_path, dpi=180, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    _logger.info(f"Wrote {out_path}")


if __name__ == "__main__":
    main()
