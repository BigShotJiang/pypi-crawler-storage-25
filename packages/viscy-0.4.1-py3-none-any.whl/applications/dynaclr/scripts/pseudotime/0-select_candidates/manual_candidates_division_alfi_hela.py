"""Manual candidate set for ALFI HeLa cell-division template.

HeLa annotations differ from U2OS/RPE1: mitosis-labeled runs in HeLa
tracks are often very long (10-40+ frames), and most parent tracks
don't have a clean ``interphase → 2-5 mitosis`` terminal pattern. Only
2 build-set candidates pass the standard filter (terminal mitosis with
≥3 pre-interphase + only-interphase pre + clean termination):

- MI06/0/0 t53: 124 pre + 39 mit run
- MI06/0/0 t70:  18 pre + 10 mit run

A 2-cell template is risky but the alignment + lineage-aware machinery
should still find divisions in HeLa as long as the round-up morphology
is consistent across cells. Treat as a stress test for the pipeline.

Run::

    cd applications/dynaclr/scripts/pseudotime/0-select_candidates
    uv run python manual_candidates_division_alfi_hela.py
"""

from __future__ import annotations

import sys
from pathlib import Path

import anndata as ad
import pandas as pd

SCRIPT_DIR = Path(__file__).resolve().parent

sys.path.insert(0, str(SCRIPT_DIR))
from lineage_utils import assign_lineage_ids, classify_divides  # noqa: E402

CANDIDATE_SET = "manual_debug_division_alfi_hela"
ANCHOR_LABEL = "cell_division_state"
ANCHOR_POSITIVE = "mitosis"

ANNOTATIONS_OUTPUT = SCRIPT_DIR / "candidates" / f"{CANDIDATE_SET}_annotations.csv"
PRODUCTIVE_OUTPUT = SCRIPT_DIR / "candidates" / f"{CANDIDATE_SET}_productive.csv"

LABEL_VALUES: dict[str, tuple[str, str]] = {
    "infection_state": ("infected", "uninfected"),
    "organelle_state": ("remodeled", "noremodeled"),
    "cell_division_state": ("mitosis", "interphase"),
}

ALFI_EMB_DIR = (
    "/hpc/projects/organelle_phenotyping/models/DynaCLR-2D-MIP-BagOfChannels/"
    "2d-mip-ntxent-t0p2-lr2e5-bs256-192to160-zext11-single-marker-fix-shuffler/"
    "evaluations/alfi-annotated/embeddings"
)

DATASETS: dict[str, dict] = {
    "ALFI_HeLa_DMSO_MLN8237": {
        "frame_interval_minutes": 21.0,
        "embedding_zarr": f"{ALFI_EMB_DIR}/ALFI_HeLa_DMSO_MLN8237.zarr",
        "transition_window_k_pre_minutes": 60.0,
        "transition_window_k_post_minutes": 120.0,
    },
}

# Asymmetric 5-frame crop: 1 pre-interphase frame + onset + 3 post = [t_first_mit-1, t_first_mit+3].
TRACKS: dict[tuple[str, str], list[dict]] = {
    ("ALFI_HeLa_DMSO_MLN8237", "MI06/0/0"): [
        {
            "track_id": 53,
            "t_before": 123,
            "t_after": 127,
            "labels": {"cell_division_state": [[124, 127]]},
        },
        {
            "track_id": 70,
            "t_before": 17,
            "t_after": 21,
            "labels": {"cell_division_state": [[18, 21]]},
        },
    ],
}


def _t_key_event(spec: dict) -> int:
    labels = spec.get("labels", {})
    if ANCHOR_LABEL not in labels or not labels[ANCHOR_LABEL]:
        raise ValueError(f"Track {spec.get('track_id')!r} is missing an anchor interval for '{ANCHOR_LABEL}'.")
    return int(labels[ANCHOR_LABEL][0][0])


def _validate_against_anndata(dataset_id: str, fov_name: str, tracks: list[dict]) -> dict[int, int]:
    ds_meta = DATASETS[dataset_id]
    adata = ad.read_zarr(ds_meta["embedding_zarr"])
    adata.obs_names_make_unique()
    fov_obs = adata.obs[adata.obs["fov_name"].astype(str) == fov_name]
    problems: list[str] = []
    parent_lookup: dict[int, int] = {}
    for spec in tracks:
        tid = int(spec["track_id"])
        track_obs = fov_obs[fov_obs["track_id"].astype(int) == tid]
        if len(track_obs) == 0:
            problems.append(f"  {dataset_id} {fov_name} t{tid}: not found in embedding")
            continue
        track_tps = set(track_obs["t"].astype(int).tolist())
        parent_lookup[tid] = (
            int(track_obs.iloc[0]["parent_track_id"])
            if "parent_track_id" in track_obs.columns
            else int(spec.get("parent_track_id", -1))
        )
        for col in ("t_before", "t_after"):
            if int(spec[col]) not in track_tps:
                problems.append(
                    f"  {dataset_id} {fov_name} t{tid}: {col}={spec[col]} not in track "
                    f"(min={min(track_tps)}, max={max(track_tps)})"
                )
        labels = spec.get("labels", {})
        for label_col, intervals in labels.items():
            for interval in intervals:
                if interval[0] not in track_tps or interval[1] not in track_tps:
                    problems.append(
                        f"  {dataset_id} {fov_name} t{tid}: {label_col} interval {interval} "
                        f"has frame(s) outside the track"
                    )
    if problems:
        raise ValueError("Manual candidate validation failed:\n" + "\n".join(problems))
    return parent_lookup


def build_annotation_rows() -> pd.DataFrame:
    rows = []
    parent_by_dataset: dict[str, dict[int, int]] = {}
    for (dataset_id, fov_name), tracks in TRACKS.items():
        parent_by_dataset.setdefault(dataset_id, {}).update(
            _validate_against_anndata(dataset_id, fov_name, tracks)
        )
    for (dataset_id, fov_name), tracks in TRACKS.items():
        parent_lookup = parent_by_dataset[dataset_id]
        for spec in tracks:
            tid = int(spec["track_id"])
            t_before = int(spec["t_before"])
            t_after = int(spec["t_after"])
            intervals = spec.get("labels", {})
            parent_tid = int(spec.get("parent_track_id", parent_lookup.get(tid, -1)))
            for t in range(t_before, t_after + 1):
                row = {
                    "dataset_id": dataset_id,
                    "fov_name": fov_name,
                    "track_id": tid,
                    "parent_track_id": parent_tid,
                    "t": t,
                }
                for label_col, (pos, neg) in LABEL_VALUES.items():
                    spans = intervals.get(label_col)
                    if spans is None:
                        row[label_col] = ""
                    elif any(lo <= t <= hi for lo, hi in spans):
                        row[label_col] = pos
                    else:
                        row[label_col] = neg
                rows.append(row)
    return pd.DataFrame(rows)


def main() -> None:
    df = build_annotation_rows()
    df = assign_lineage_ids(df, return_both_branches=True)
    t_zero_lookup: dict[str, int] = {}
    for (dataset_id, fov_name), tracks in TRACKS.items():
        for spec in tracks:
            tid = int(spec["track_id"])
            mask = (df["dataset_id"] == dataset_id) & (df["fov_name"] == fov_name) & (df["track_id"] == tid)
            if not mask.any():
                continue
            lineage_id = str(df.loc[mask, "lineage_id"].iloc[0])
            if not lineage_id:
                continue
            t_anchor = _t_key_event(spec)
            t_zero_lookup[lineage_id] = min(t_zero_lookup.get(lineage_id, t_anchor), t_anchor)

    divides: dict[str, str] = {}
    for lineage_id, lineage_df in df.groupby("lineage_id"):
        if not lineage_id:
            divides[lineage_id] = "none"
            continue
        t_zero = t_zero_lookup.get(str(lineage_id))
        if t_zero is None:
            divides[lineage_id] = "none"
            continue
        ds_id = str(lineage_df["dataset_id"].iloc[0])
        ds_meta = DATASETS[ds_id]
        frame_interval = float(ds_meta["frame_interval_minutes"])
        k_pre = int(round(float(ds_meta["transition_window_k_pre_minutes"]) / frame_interval))
        k_post = int(round(float(ds_meta["transition_window_k_post_minutes"]) / frame_interval))
        divides[lineage_id] = classify_divides(lineage_df, t_zero, k_pre, k_post)

    df["cohort"] = "productive"
    df["divides"] = df["lineage_id"].map(divides).fillna("none")

    output_columns = [
        "dataset_id", "fov_name", "lineage_id", "track_id", "parent_track_id", "t",
        "cohort", "divides", "infection_state", "organelle_state", "cell_division_state",
    ]
    out = df[output_columns]
    ANNOTATIONS_OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    out.to_csv(ANNOTATIONS_OUTPUT, index=False)
    out.to_csv(PRODUCTIVE_OUTPUT, index=False)
    print(f"Wrote {len(out)} rows to {ANNOTATIONS_OUTPUT}")
    print(f"Wrote {len(out)} rows to {PRODUCTIVE_OUTPUT}")


if __name__ == "__main__":
    main()
