"""Write a manual productive-cohort CSV for the ALFI cell-division validation.

Pseudotime validation entry point: anchor on the first ``mitosis`` frame
from human annotations on the ALFI dataset, using the Phase embeddings.

Mirrors :mod:`manual_candidates` but:

- ``ANCHOR_LABEL = cell_division_state``, ``ANCHOR_POSITIVE = mitosis``
  (not infection_state).
- Embedding zarr is the per-cell-line ALFI MIP zarr from the
  ``-single-marker-fix-shuffler`` evaluation. Only U2OS picks here; the
  other cell lines have far fewer clean transitions.
- Frame interval is 21 minutes (ALFI standard).
- The CSV-side annotations cover the same frames as the embedding; we
  cross-validate every (fov, track, t) against the zarr's ``.obs`` so a
  missing frame fails fast.

Each spec defines an inclusive ``[t_before, t_after]`` crop window plus
a ``labels`` dict. The labels list ``[t_on, t_off]`` intervals on the
anchor (cell_division_state = mitosis); the script auto-fills
``interphase`` outside those intervals so build_template can derive
``t_perturb`` from the anchor.

Run::

    cd applications/dynaclr/scripts/pseudotime/0-select_candidates
    uv run python manual_candidates_division_alfi.py
"""

from __future__ import annotations

import sys
from pathlib import Path

import anndata as ad
import pandas as pd

SCRIPT_DIR = Path(__file__).resolve().parent

sys.path.insert(0, str(SCRIPT_DIR))
from lineage_utils import assign_lineage_ids, classify_divides  # noqa: E402

CANDIDATE_SET = "manual_debug_division_alfi"
ANCHOR_LABEL = "cell_division_state"
ANCHOR_POSITIVE = "mitosis"

ANNOTATIONS_OUTPUT = SCRIPT_DIR / "candidates" / f"{CANDIDATE_SET}_annotations.csv"
PRODUCTIVE_OUTPUT = SCRIPT_DIR / "candidates" / f"{CANDIDATE_SET}_productive.csv"

# ALFI annotation schema. Cell-division is the only label populated; we
# leave infection / organelle blank.
LABEL_VALUES: dict[str, tuple[str, str]] = {
    "infection_state": ("infected", "uninfected"),
    "organelle_state": ("remodeled", "noremodeled"),
    "cell_division_state": ("mitosis", "interphase"),
}

ALFI_EMB_DIR = (
    "/hpc/projects/organelle_phenotyping/models/DynaCLR-2D-MIP-BagOfChannels/"
    "2d-mip-ntxent-t0p2-lr2e5-bs256-192to160-zext11-single-marker-fix-shuffler/"
    "evaluations/alfi-annotated/embeddings"
)

DATASETS: dict[str, dict] = {
    "ALFI_U2OS_DMSO_MLN8237": {
        "frame_interval_minutes": 21.0,
        "embedding_zarr": f"{ALFI_EMB_DIR}/ALFI_U2OS_DMSO_MLN8237.zarr",
        "transition_window_k_pre_minutes": 60.0,
        "transition_window_k_post_minutes": 120.0,
    },
}

# Hand-picked U2OS tracks with clean interphase->mitosis transitions and
# enough pre/post coverage in the embedding zarr.
# Asymmetric crop: 1 frame of interphase before mitosis onset + 4 frames
# starting at onset (5 total = ~105 min at 21 min/frame). The morphology
# transition is itself asymmetric — a long flat interphase plateau, a
# rapid round-up at onset, then 2-4 frames of mitotic body and daughter
# separation. A symmetric template wastes capacity on redundant interphase
# frames; the asymmetric (1+4) shape concentrates template positions where
# the embedding moves fastest. Empirically (see /tmp/sweep_asymmetric.py)
# this template recovers 34 mitoses with 24/25 top-25 precision vs the
# symmetric 7-frame template's 21 / 19/25.
TRACKS: dict[tuple[str, str], list[dict]] = {
    ("ALFI_U2OS_DMSO_MLN8237", "MI04/0/0"): [
        {
            "track_id": 7,
            "t_before": 7,
            "t_after": 11,
            "labels": {"cell_division_state": [[8, 11]]},
        },
        {
            "track_id": 2,
            "t_before": 48,
            "t_after": 52,
            "labels": {"cell_division_state": [[49, 52]]},
        },
    ],
    ("ALFI_U2OS_DMSO_MLN8237", "MI05/0/0"): [
        {
            "track_id": 7,
            "t_before": 35,
            "t_after": 39,
            "labels": {"cell_division_state": [[36, 39]]},
        },
        {
            "track_id": 4,
            "t_before": 7,
            "t_after": 11,
            "labels": {"cell_division_state": [[8, 11]]},
        },
    ],
    ("ALFI_U2OS_DMSO_MLN8237", "MI03/0/0"): [
        {
            "track_id": 10,
            "t_before": 38,
            "t_after": 42,
            "labels": {"cell_division_state": [[39, 42]]},
        },
        {
            "track_id": 11,
            "t_before": 23,
            "t_after": 27,
            "labels": {"cell_division_state": [[24, 27]]},
        },
    ],
    ("ALFI_U2OS_DMSO_MLN8237", "MI01/0/0"): [
        {
            "track_id": 9,
            "t_before": 14,
            "t_after": 18,
            "labels": {"cell_division_state": [[15, 18]]},
        },
    ],
}


def _t_key_event(spec: dict) -> int:
    """First positive frame of ``ANCHOR_LABEL`` — the per-cell anchor."""
    labels = spec.get("labels", {})
    if ANCHOR_LABEL not in labels or not labels[ANCHOR_LABEL]:
        raise ValueError(f"Track {spec.get('track_id')!r} is missing an anchor interval for '{ANCHOR_LABEL}'.")
    return int(labels[ANCHOR_LABEL][0][0])


def _validate_against_anndata(dataset_id: str, fov_name: str, tracks: list[dict]) -> dict[int, int]:
    """Validate every spec against the embedding ``.obs`` and return parent ids."""
    ds_meta = DATASETS[dataset_id]
    emb_path = ds_meta["embedding_zarr"]
    adata = ad.read_zarr(emb_path)
    adata.obs_names_make_unique()
    obs = adata.obs
    fov_obs = obs[obs["fov_name"].astype(str) == fov_name]

    problems: list[str] = []
    parent_lookup: dict[int, int] = {}

    for spec in tracks:
        tid = int(spec["track_id"])
        track_obs = fov_obs[fov_obs["track_id"].astype(int) == tid]
        if len(track_obs) == 0:
            problems.append(f"  {dataset_id} {fov_name} track_id={tid}: not found in {emb_path}")
            continue
        track_tps = set(track_obs["t"].astype(int).tolist())

        if "parent_track_id" in track_obs.columns:
            parent_lookup[tid] = int(track_obs.iloc[0]["parent_track_id"])
        else:
            parent_lookup[tid] = int(spec.get("parent_track_id", -1))

        for col in ("t_before", "t_after"):
            if int(spec[col]) not in track_tps:
                problems.append(
                    f"  {dataset_id} {fov_name} track_id={tid}: {col}={spec[col]} not in track "
                    f"(min={min(track_tps)}, max={max(track_tps)})"
                )

        labels = spec.get("labels", {})
        if ANCHOR_LABEL not in labels or not labels[ANCHOR_LABEL]:
            problems.append(f"  {dataset_id} {fov_name} track_id={tid}: missing anchor label '{ANCHOR_LABEL}'")
        for label_col, intervals in labels.items():
            if label_col not in LABEL_VALUES:
                problems.append(
                    f"  {dataset_id} {fov_name} track_id={tid}: unknown label column '{label_col}' "
                    f"(known: {list(LABEL_VALUES)})"
                )
            for interval in intervals:
                if len(interval) != 2 or interval[0] > interval[1]:
                    problems.append(
                        f"  {dataset_id} {fov_name} track_id={tid}: {label_col} interval {interval} "
                        f"is not a valid [t_on, t_off] pair"
                    )
                    continue
                if interval[0] not in track_tps or interval[1] not in track_tps:
                    problems.append(
                        f"  {dataset_id} {fov_name} track_id={tid}: {label_col} interval {interval} "
                        f"has frame(s) outside the track (min={min(track_tps)}, max={max(track_tps)})"
                    )

    if problems:
        raise ValueError("Manual candidate validation failed:\n" + "\n".join(problems))

    return parent_lookup


def build_annotation_rows() -> pd.DataFrame:
    """Expand every track spec into per-timepoint rows."""
    rows = []
    parent_by_dataset: dict[str, dict[int, int]] = {}
    for (dataset_id, fov_name), tracks in TRACKS.items():
        parent_by_dataset.setdefault(dataset_id, {}).update(
            _validate_against_anndata(dataset_id, fov_name, tracks)
        )

    for (dataset_id, fov_name), tracks in TRACKS.items():
        parent_lookup = parent_by_dataset[dataset_id]
        for spec in tracks:
            tid = int(spec["track_id"])
            t_before = int(spec["t_before"])
            t_after = int(spec["t_after"])
            intervals = spec.get("labels", {})
            parent_tid = int(spec.get("parent_track_id", parent_lookup.get(tid, -1)))

            for t in range(t_before, t_after + 1):
                row = {
                    "dataset_id": dataset_id,
                    "fov_name": fov_name,
                    "track_id": tid,
                    "parent_track_id": parent_tid,
                    "t": t,
                }
                for label_col, (pos, neg) in LABEL_VALUES.items():
                    spans = intervals.get(label_col)
                    if spans is None:
                        row[label_col] = ""
                    elif any(lo <= t <= hi for lo, hi in spans):
                        row[label_col] = pos
                    else:
                        row[label_col] = neg
                rows.append(row)
    return pd.DataFrame(rows)


def main() -> None:
    """Validate specs, reconnect lineages, classify divides, write CSVs."""
    df = build_annotation_rows()
    df = assign_lineage_ids(df, return_both_branches=True)

    t_zero_lookup: dict[str, int] = {}
    for (dataset_id, fov_name), tracks in TRACKS.items():
        for spec in tracks:
            tid = int(spec["track_id"])
            mask = (df["dataset_id"] == dataset_id) & (df["fov_name"] == fov_name) & (df["track_id"] == tid)
            if not mask.any():
                continue
            lineage_id = str(df.loc[mask, "lineage_id"].iloc[0])
            if not lineage_id:
                continue
            t_anchor = _t_key_event(spec)
            t_zero_lookup[lineage_id] = min(t_zero_lookup.get(lineage_id, t_anchor), t_anchor)

    divides: dict[str, str] = {}
    for lineage_id, lineage_df in df.groupby("lineage_id"):
        if not lineage_id:
            divides[lineage_id] = "none"
            continue
        t_zero = t_zero_lookup.get(str(lineage_id))
        if t_zero is None:
            divides[lineage_id] = "none"
            continue
        ds_id = str(lineage_df["dataset_id"].iloc[0])
        ds_meta = DATASETS[ds_id]
        frame_interval = float(ds_meta["frame_interval_minutes"])
        k_pre = int(round(float(ds_meta["transition_window_k_pre_minutes"]) / frame_interval))
        k_post = int(round(float(ds_meta["transition_window_k_post_minutes"]) / frame_interval))
        divides[lineage_id] = classify_divides(lineage_df, t_zero, k_pre, k_post)

    df["cohort"] = "productive"
    df["divides"] = df["lineage_id"].map(divides).fillna("none")

    output_columns = [
        "dataset_id",
        "fov_name",
        "lineage_id",
        "track_id",
        "parent_track_id",
        "t",
        "cohort",
        "divides",
        "infection_state",
        "organelle_state",
        "cell_division_state",
    ]
    out = df[output_columns]

    ANNOTATIONS_OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    out.to_csv(ANNOTATIONS_OUTPUT, index=False)
    out.to_csv(PRODUCTIVE_OUTPUT, index=False)
    print(f"Wrote {len(out)} rows to {ANNOTATIONS_OUTPUT}")
    print(f"Wrote {len(out)} rows to {PRODUCTIVE_OUTPUT}")
    print(out.head(10).to_string(index=False))


if __name__ == "__main__":
    main()
