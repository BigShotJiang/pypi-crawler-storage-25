"""DTW length-normalized cost threshold — selection and validation.

For each cell-track in the Stage 5 per-frame parquets, compute:

- ``length_normalized_cost`` — constant per track from the alignment.
- ``t_true`` — first frame where the ground-truth label equals the positive class.
- ``t_dtw`` — first frame where ``dtw_<positive_class> >= 0.5``.
- ``t_lc_K`` — first frame where ``lc_K{K}_prob_pos >= 0.5`` for each K.
- ``delta_dtw`` / ``delta_lc_K`` — frame error vs ``t_true``.

Then sweep a candidate ``dtw_cost`` threshold τ. Tracks with cost ≤ τ are
"template-fit", > τ are "template-misfit". Report:

- mean / median |Δ_dtw| within each stratum.
- "below-τ" minus "above-τ" gap (we expect below to be smaller).
- F1 / accuracy of the binary "DTW-trusted vs LC-fallback" split.

Picks the τ that maximizes a chosen objective (default: median |Δ| gap)
on a labeled validation subset. Output: a markdown table + a scatter plot
of cost-vs-|Δ| per dataset.

Usage::

    python dtw_cost_threshold.py \\
        --per-frame-glob 'scripts/pseudotime/5-eval/out/*/per_frame_*.parquet' \\
        --positive-class infected \\
        --output-dir scripts/pseudotime/5-eval/out/cost_threshold
"""

from __future__ import annotations

import argparse
import glob
import logging
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
_logger = logging.getLogger("dtw_cost_threshold")


def _per_track_table(df: pd.DataFrame, positive_class: str) -> pd.DataFrame:
    """Collapse a Stage 5 per-frame parquet to one row per (fov, track_id).

    Returns columns:
    - ``fov_name``, ``track_id``, ``length_normalized_cost``
    - ``has_event`` — whether the track has at least one positive-class frame
    - ``t_true`` — first positive-class frame (NaN if none)
    - ``t_dtw`` — first frame with ``dtw_<positive> >= 0.5``
    - ``t_lc_K{1,3,7}`` — first frame with ``lc_K{K}_prob_pos >= 0.5``
    - ``delta_dtw`` and ``delta_lc_K{1,3,7}`` — frame errors vs ``t_true``
    """
    if "length_normalized_cost" not in df.columns:
        raise KeyError(
            "Per-frame parquet missing length_normalized_cost. Re-run multi_frame_lc.py "
            "with the updated _load_dtw helper that carries cost columns."
        )

    rows: list[dict] = []
    for (fov, tid), grp in df.groupby(["fov_name", "track_id"]):
        grp_sorted = grp.sort_values("t")
        pos_mask = grp_sorted["gt"] == positive_class
        t_true = int(grp_sorted.loc[pos_mask, "t"].iloc[0]) if pos_mask.any() else np.nan
        out = {
            "fov_name": fov,
            "track_id": int(tid),
            "length_normalized_cost": float(grp_sorted["length_normalized_cost"].iloc[0]),
            "has_event": bool(pos_mask.any()),
            "n_frames": len(grp_sorted),
            "t_true": t_true,
        }
        # DTW first crossing
        dtw_col = f"dtw_{positive_class}"
        if dtw_col in grp_sorted.columns:
            cross = grp_sorted[grp_sorted[dtw_col] >= 0.5]
            out["t_dtw"] = int(cross["t"].iloc[0]) if not cross.empty else np.nan
            out["delta_dtw"] = out["t_dtw"] - t_true if (out["t_dtw"] == out["t_dtw"]) and (t_true == t_true) else np.nan
        # LC first crossings
        for K in (1, 3, 7):
            col = f"lc_K{K}_prob_pos"
            if col not in grp_sorted.columns:
                continue
            cross = grp_sorted[grp_sorted[col] >= 0.5]
            t_lc = int(cross["t"].iloc[0]) if not cross.empty else np.nan
            out[f"t_lc_K{K}"] = t_lc
            out[f"delta_lc_K{K}"] = t_lc - t_true if (t_lc == t_lc) and (t_true == t_true) else np.nan
        rows.append(out)
    return pd.DataFrame(rows)


def _sweep_thresholds(
    per_track: pd.DataFrame, taus: np.ndarray
) -> pd.DataFrame:
    """For each τ, compute median |Δ_dtw| below vs above and the gap.

    Only tracks with ``has_event`` contribute (Δ is meaningful only when
    there's a ground-truth event).
    """
    sub = per_track[per_track["has_event"] & per_track["delta_dtw"].notna()].copy()
    sub["abs_delta_dtw"] = sub["delta_dtw"].abs()
    out: list[dict] = []
    for tau in taus:
        below = sub[sub["length_normalized_cost"] <= tau]
        above = sub[sub["length_normalized_cost"] > tau]
        out.append({
            "tau": float(tau),
            "n_below": int(len(below)),
            "n_above": int(len(above)),
            "median_below": float(below["abs_delta_dtw"].median()) if len(below) else np.nan,
            "median_above": float(above["abs_delta_dtw"].median()) if len(above) else np.nan,
            "mean_below": float(below["abs_delta_dtw"].mean()) if len(below) else np.nan,
            "mean_above": float(above["abs_delta_dtw"].mean()) if len(above) else np.nan,
        })
    df = pd.DataFrame(out)
    df["median_gap"] = df["median_above"] - df["median_below"]
    df["mean_gap"] = df["mean_above"] - df["mean_below"]
    return df


def _plot_cost_vs_delta(per_track: pd.DataFrame, dataset: str, output_path: Path) -> None:
    """Scatter ``length_normalized_cost`` vs ``|Δ_dtw|`` for event-bearing tracks."""
    sub = per_track[per_track["has_event"] & per_track["delta_dtw"].notna()]
    if sub.empty:
        return
    fig, ax = plt.subplots(figsize=(6, 4))
    ax.scatter(
        sub["length_normalized_cost"], sub["delta_dtw"].abs(),
        alpha=0.6, s=20, c="C0", edgecolors="none",
    )
    ax.set_xlabel("length_normalized_cost (per track)")
    ax.set_ylabel("|Δ_dtw|  (frames)")
    ax.set_title(f"DTW cost vs event-timing error — {dataset}")
    ax.grid(True, alpha=0.3)
    fig.tight_layout()
    fig.savefig(output_path, dpi=120)
    plt.close(fig)


def main() -> None:
    """Pick a DTW-cost threshold per dataset; report validation table."""
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--per-frame-glob", required=True,
                        help="Glob matching Stage 5 per_frame_*.parquet files.")
    parser.add_argument("--positive-class", required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--n-tau", type=int, default=50, help="Number of candidate thresholds to sweep")
    args = parser.parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)

    paths = sorted(glob.glob(args.per_frame_glob))
    if not paths:
        raise SystemExit(f"No parquets matched {args.per_frame_glob!r}")
    _logger.info("Found %d per-frame parquet(s)", len(paths))

    sections: list[str] = [f"# DTW cost threshold — positive={args.positive_class}", ""]
    summary_rows: list[dict] = []

    for p in paths:
        dataset = Path(p).stem
        df = pd.read_parquet(p)
        if "length_normalized_cost" not in df.columns:
            _logger.warning("[%s] missing length_normalized_cost — skipping", dataset)
            continue
        per_track = _per_track_table(df, args.positive_class)

        sections.append(f"## {dataset}")
        sections.append("")
        sections.append(
            f"- Tracks: {len(per_track)} "
            f"(with event: {int(per_track['has_event'].sum())}, "
            f"with measurable Δ_dtw: "
            f"{int((per_track['has_event'] & per_track['delta_dtw'].notna()).sum())})"
        )

        cost = per_track["length_normalized_cost"].dropna()
        if cost.empty:
            sections.append("(no cost data)")
            continue
        taus = np.linspace(cost.min(), cost.max(), args.n_tau)
        sweep = _sweep_thresholds(per_track, taus)
        # Pick τ maximizing median_gap among τ that have ≥5 tracks on each side
        feasible = sweep[(sweep["n_below"] >= 5) & (sweep["n_above"] >= 5)]
        if feasible.empty:
            sections.append("(no feasible τ with ≥5 tracks per stratum)")
            continue
        best = feasible.loc[feasible["median_gap"].idxmax()]
        sections.append(
            f"- Recommended τ = **{best['tau']:.3f}** "
            f"(median |Δ_dtw| below: {best['median_below']:.1f}, above: {best['median_above']:.1f}, "
            f"gap: {best['median_gap']:.1f}; n_below={int(best['n_below'])}, n_above={int(best['n_above'])})"
        )
        sections.append("")
        sections.append("### Sweep summary (top 10 by median_gap)")
        sections.append("")
        top = feasible.sort_values("median_gap", ascending=False).head(10)
        sections.append(top.to_markdown(index=False, floatfmt=".3f"))
        sections.append("")

        # Plot
        plot_path = args.output_dir / f"{dataset}__cost_vs_delta.png"
        _plot_cost_vs_delta(per_track, dataset, plot_path)
        sections.append(f"![{dataset}]({plot_path.name})")
        sections.append("")

        summary_rows.append({
            "dataset": dataset,
            "tau": float(best["tau"]),
            "n_below": int(best["n_below"]),
            "n_above": int(best["n_above"]),
            "median_below": float(best["median_below"]),
            "median_above": float(best["median_above"]),
            "median_gap": float(best["median_gap"]),
        })

    if summary_rows:
        sections.insert(2, "## Summary")
        sections.insert(3, "")
        sections.insert(4, pd.DataFrame(summary_rows).to_markdown(index=False, floatfmt=".3f"))
        sections.insert(5, "")
    report = "\n".join(sections)
    out_md = args.output_dir / "report.md"
    out_md.write_text(report)
    _logger.info("Wrote %s", out_md)
    print(report)


if __name__ == "__main__":
    main()
