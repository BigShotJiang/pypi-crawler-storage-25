"""Stage 5: compare static linear-classifier predictions to DTW-propagated labels.

The DynaCLR paper argument is that temporal embeddings + DTW propagation
beats a static per-frame logistic regression on the same embeddings. This
script joins three sources on ``(fov_name, track_id, t)`` for a single
annotation task (e.g. ``cell_division_state``) and reports head-to-head
metrics:

- ground truth from the annotation CSV
- LC predictions/probabilities from a trained
  :class:`viscy_utils.evaluation.linear_classifier.LinearClassifierPipeline`
  applied per cell-frame embedding
- DTW per-class fractions from the multiclass alignment parquet
  (``propagated_<col_clean>_<class>_label``)

Outputs a markdown report (``report.md``) and a per-frame predictions
parquet (``per_frame_predictions.parquet``).

Examples
--------
ALFI U2OS division::

    python compare_lc_vs_dtw.py \\
        --alignment-parquet .../alignments/manual_debug_division_alfi_raw_on_phase_alfi_division_qset.parquet \\
        --embedding-zarr .../embeddings/ALFI_U2OS_DMSO_MLN8237.zarr \\
        --lc-pipeline .../linear_classifiers/pipelines/cell_division_state_DIC.joblib \\
        --annotation-csv /hpc/projects/organelle_phenotyping/datasets/annotations/ALFI/ALFI_combined_annotations.csv \\
        --task cell_division_state \\
        --positive-class mitosis \\
        --output-dir ./out/alfi_u2os_division
"""

from __future__ import annotations

import argparse
import json
import logging
from pathlib import Path

import anndata as ad
import joblib
import numpy as np
import pandas as pd
from sklearn.metrics import (
    accuracy_score,
    classification_report,
    confusion_matrix,
    f1_score,
    precision_score,
    recall_score,
    roc_auc_score,
)

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
_logger = logging.getLogger("compare_lc_vs_dtw")


def _load_annotation(csv_path: Path, task: str, fov_names: list[str]) -> pd.DataFrame:
    """Load annotation rows for the given task, restricted to FOVs in scope.

    Parameters
    ----------
    csv_path : Path
        Path to the annotation CSV (must contain ``fov_name``, ``track_id``,
        ``t``, and the requested task column).
    task : str
        Annotation column name (e.g. ``cell_division_state``).
    fov_names : list[str]
        FOVs to keep (typically the alignment parquet's FOVs).

    Returns
    -------
    pd.DataFrame
        Columns ``fov_name``, ``track_id``, ``t``, ``gt`` (the task column
        renamed). Rows with null ``gt`` are dropped.
    """
    df = pd.read_csv(csv_path)
    if task not in df.columns:
        raise KeyError(f"Annotation CSV is missing task column {task!r}. Found: {list(df.columns)}")
    df = df[df["fov_name"].isin(fov_names)]
    df = df[["fov_name", "track_id", "t", task]].rename(columns={task: "gt"})
    df = df[df["gt"].notna() & (df["gt"] != "")]
    df["t"] = df["t"].astype(int)
    df["track_id"] = df["track_id"].astype(int)
    before = len(df)
    df = df.drop_duplicates(subset=["fov_name", "track_id", "t"], keep="first").reset_index(drop=True)
    if before != len(df):
        _logger.info("Annotation: deduped %d → %d unique (fov, track, t)", before, len(df))
    return df


def _load_lc_predictions(
    embedding_zarr: Path,
    lc_pipeline_path: Path,
    fov_names: list[str],
) -> pd.DataFrame:
    """Apply the trained LC to every embedding row in the zarr.

    Parameters
    ----------
    embedding_zarr : Path
        AnnData zarr produced by ``viscy predict`` / ``dynaclr split-embeddings``.
    lc_pipeline_path : Path
        ``.joblib`` produced by ``viscy_utils.evaluation.linear_classifier``.
        Must expose ``predict`` and ``predict_proba``; ``classifier.classes_``
        gives the class label order for proba columns.
    fov_names : list[str]
        FOVs to keep (restrict to the comparison scope).

    Returns
    -------
    pd.DataFrame
        Columns: ``fov_name``, ``track_id``, ``t``, ``lc_pred``,
        ``lc_prob_<class>`` (one per class).
    """
    a = ad.read_zarr(embedding_zarr)
    obs = a.obs.copy()
    obs["_iloc"] = np.arange(len(obs))
    obs = obs[obs["fov_name"].isin(fov_names)]
    if obs.empty:
        raise ValueError(
            f"No embedding rows match the alignment FOVs in {embedding_zarr}. "
            f"Expected one of: {fov_names[:5]}..."
        )
    X = a.X[obs["_iloc"].to_numpy()]
    if hasattr(X, "toarray"):
        X = X.toarray()

    pipeline = joblib.load(lc_pipeline_path)
    classes = list(pipeline.classifier.classes_)
    preds = pipeline.predict(X)
    probs = pipeline.predict_proba(X)

    out = pd.DataFrame(
        {
            "fov_name": obs["fov_name"].to_numpy(),
            "track_id": obs["track_id"].astype(int).to_numpy(),
            "t": obs["t"].astype(int).to_numpy(),
            "lc_pred": preds,
        }
    )
    for i, cls in enumerate(classes):
        out[f"lc_prob_{cls}"] = probs[:, i]
    # The embedding zarr can carry the same (fov, track, t) row twice when
    # the cell index was built with both channels of a 2-channel acquisition;
    # collapse so each cell-frame contributes a single LC prediction.
    before = len(out)
    out = out.drop_duplicates(subset=["fov_name", "track_id", "t"], keep="first").reset_index(drop=True)
    if before != len(out):
        _logger.info("LC: deduped %d embedding rows → %d unique (fov, track, t)", before, len(out))
    return out


def _load_dtw_predictions(
    alignment_parquet: Path,
    task: str,
) -> pd.DataFrame:
    """Extract DTW propagated per-class fractions for one task.

    Parameters
    ----------
    alignment_parquet : Path
        Alignment parquet from Stage 2 (multiclass propagation).
    task : str
        Annotation column name (e.g. ``cell_division_state``).

    Returns
    -------
    pd.DataFrame
        Columns: ``fov_name``, ``track_id``, ``t``,
        ``dtw_<class>`` (one per class observed in the template).
    """
    df = pd.read_parquet(alignment_parquet)
    col_clean = task.replace("_state", "")
    prefix = f"propagated_{col_clean}_"
    suffix = "_label"
    class_cols = [c for c in df.columns if c.startswith(prefix) and c.endswith(suffix)]
    if not class_cols:
        raise KeyError(
            f"Alignment parquet has no columns matching {prefix}<class>{suffix}. "
            f"Available propagated columns: "
            f"{[c for c in df.columns if c.startswith('propagated_')]}"
        )
    rename = {c: "dtw_" + c[len(prefix) : -len(suffix)] for c in class_cols}
    out = df[["fov_name", "track_id", "t", "alignment_region", *class_cols]].rename(columns=rename)
    out["track_id"] = out["track_id"].astype(int)
    out["t"] = out["t"].astype(int)
    # Lineage-aware DTW duplicates a parent's rows into both daughter
    # lineages — those duplicates carry bit-identical propagation values,
    # so collapse to one row per (fov, track, t).
    before = len(out)
    out = out.drop_duplicates(subset=["fov_name", "track_id", "t"], keep="first").reset_index(drop=True)
    if before != len(out):
        _logger.info("DTW: deduped %d lineage-fanout rows → %d unique (fov, track, t)", before, len(out))
    return out


def _binary_metrics(
    gt: np.ndarray,
    pred: np.ndarray,
    prob: np.ndarray | None,
    positive: str,
) -> dict[str, float]:
    """Compute the standard binary metrics with ``positive`` as the positive class."""
    gt_bin = (gt == positive).astype(int)
    pred_bin = (pred == positive).astype(int)
    out = {
        "accuracy": float(accuracy_score(gt, pred)),
        "weighted_f1": float(f1_score(gt, pred, average="weighted", zero_division=0)),
        "binary_precision": float(precision_score(gt_bin, pred_bin, zero_division=0)),
        "binary_recall": float(recall_score(gt_bin, pred_bin, zero_division=0)),
        "binary_f1": float(f1_score(gt_bin, pred_bin, zero_division=0)),
    }
    if prob is not None and len(np.unique(gt_bin)) > 1:
        out["roc_auc"] = float(roc_auc_score(gt_bin, prob))
    else:
        out["roc_auc"] = float("nan")
    return out


def _format_metric_row(name: str, m: dict[str, float]) -> str:
    """Render one row of the comparison markdown table."""
    keys = ["accuracy", "weighted_f1", "binary_precision", "binary_recall", "binary_f1", "roc_auc"]
    cells = " | ".join(f"{m[k]:.3f}" if not np.isnan(m[k]) else "n/a" for k in keys)
    return f"| {name} | {cells} |"


def _confusion_md(label: str, gt: np.ndarray, pred: np.ndarray, classes: list[str]) -> str:
    """Render a labeled confusion matrix as a markdown table."""
    cm = confusion_matrix(gt, pred, labels=classes)
    header = " | ".join([f"**{label}**", *[f"pred {c}" for c in classes]])
    sep = " | ".join(["---"] * (len(classes) + 1))
    rows = []
    for i, c in enumerate(classes):
        rows.append(" | ".join([f"true {c}", *[str(int(x)) for x in cm[i]]]))
    return "\n".join([f"| {header} |", f"| {sep} |", *[f"| {r} |" for r in rows]])


def main() -> None:
    """Run Stage 5 LC-vs-DTW comparison on one alignment + LC pair."""
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--alignment-parquet", required=True, type=Path)
    parser.add_argument("--embedding-zarr", required=True, type=Path)
    parser.add_argument("--lc-pipeline", required=True, type=Path)
    parser.add_argument("--annotation-csv", required=True, type=Path)
    parser.add_argument("--task", required=True, help="Annotation column (e.g. cell_division_state)")
    parser.add_argument("--positive-class", required=True, help="Class treated as positive for binary metrics")
    parser.add_argument("--output-dir", required=True, type=Path)
    parser.add_argument(
        "--restrict-to-aligned",
        action=argparse.BooleanOptionalAction,
        default=True,
        help="Restrict comparison to rows that appear in the DTW alignment "
        "(default). With --no-restrict-to-aligned, evaluate the LC over the "
        "full annotation set even on cells DTW filtered out.",
    )
    args = parser.parse_args()

    args.output_dir.mkdir(parents=True, exist_ok=True)

    _logger.info("Loading DTW alignment %s", args.alignment_parquet)
    dtw = _load_dtw_predictions(args.alignment_parquet, args.task)
    fov_names = sorted(dtw["fov_name"].unique())
    _logger.info("  DTW rows: %d across %d FOVs", len(dtw), len(fov_names))

    _logger.info("Loading annotation %s", args.annotation_csv)
    ann = _load_annotation(args.annotation_csv, args.task, fov_names)
    _logger.info("  Annotated rows in scope: %d (%d unique tracks)",
                 len(ann), ann.groupby(["fov_name", "track_id"]).ngroups)

    _logger.info("Applying LC %s on embeddings %s", args.lc_pipeline.name, args.embedding_zarr.name)
    lc = _load_lc_predictions(args.embedding_zarr, args.lc_pipeline, fov_names)
    _logger.info("  LC predictions for %d embedding rows", len(lc))

    # Join: annotation ∩ LC (every annotated cell needs an embedding to be evaluated)
    joined = ann.merge(lc, on=["fov_name", "track_id", "t"], how="inner")
    _logger.info("Annotation ∩ LC: %d rows", len(joined))

    # Add DTW columns (left join — DTW may not cover every annotated row, but if
    # restrict_to_aligned is True we further drop rows with no DTW prediction).
    joined = joined.merge(dtw, on=["fov_name", "track_id", "t"], how="left")
    dtw_cols = [c for c in joined.columns if c.startswith("dtw_")]
    has_dtw = joined[dtw_cols].notna().all(axis=1) if dtw_cols else pd.Series(False, index=joined.index)
    n_with_dtw = int(has_dtw.sum())
    n_total = len(joined)
    _logger.info("Annotation ∩ LC ∩ DTW: %d / %d", n_with_dtw, n_total)

    if args.restrict_to_aligned:
        joined = joined[has_dtw].reset_index(drop=True)
        _logger.info("Restricting to DTW-covered rows: %d", len(joined))

    if joined.empty:
        raise RuntimeError("No rows to evaluate — annotation/LC/DTW join is empty.")

    pipeline = joblib.load(args.lc_pipeline)
    classes = list(pipeline.classifier.classes_)
    if args.positive_class not in classes:
        raise ValueError(
            f"--positive-class {args.positive_class!r} is not in the LC's classes {classes}."
        )
    lc_pos_col = f"lc_prob_{args.positive_class}"
    dtw_pos_col = f"dtw_{args.positive_class}"

    # LC label conversion: predict already gives strings in `classes`.
    gt = joined["gt"].to_numpy()
    lc_pred = joined["lc_pred"].to_numpy()

    # DTW label: argmax over per-class fractions.
    dtw_class_cols = [c for c in joined.columns if c.startswith("dtw_")]
    dtw_class_names = [c[len("dtw_") :] for c in dtw_class_cols]
    dtw_pred = np.array(
        [dtw_class_names[i] for i in joined[dtw_class_cols].to_numpy().argmax(axis=1)]
    )

    # Probabilities for the positive class.
    lc_prob_pos = joined[lc_pos_col].to_numpy() if lc_pos_col in joined.columns else None
    dtw_prob_pos = joined[dtw_pos_col].to_numpy() if dtw_pos_col in joined.columns else None

    lc_metrics = _binary_metrics(gt, lc_pred, lc_prob_pos, args.positive_class)
    dtw_metrics = _binary_metrics(gt, dtw_pred, dtw_prob_pos, args.positive_class)

    # Aligned-region-only metrics — DTW's actual playing field. Pre/post are
    # forced to template[0]/template[-1] by the subsequence override, which
    # is informative but not "what the warp said".
    aligned_metrics_md = ""
    region_breakdown_md = ""
    if "alignment_region" in joined.columns:
        aligned_mask = joined["alignment_region"] == "aligned"
        if aligned_mask.any():
            g = joined.loc[aligned_mask, "gt"].to_numpy()
            lcp = joined.loc[aligned_mask, "lc_pred"].to_numpy()
            dtwp = np.array(
                [
                    dtw_class_names[i]
                    for i in joined.loc[aligned_mask, dtw_class_cols].to_numpy().argmax(axis=1)
                ]
            )
            lc_prob_aligned = (
                joined.loc[aligned_mask, lc_pos_col].to_numpy()
                if lc_pos_col in joined.columns
                else None
            )
            dtw_prob_aligned = (
                joined.loc[aligned_mask, dtw_pos_col].to_numpy()
                if dtw_pos_col in joined.columns
                else None
            )
            lc_aligned = _binary_metrics(g, lcp, lc_prob_aligned, args.positive_class)
            dtw_aligned = _binary_metrics(g, dtwp, dtw_prob_aligned, args.positive_class)
            aligned_metrics_md = (
                "## Head-to-head — aligned region only "
                f"(n={int(aligned_mask.sum())}, where DTW is actually warping rather than pinning)\n\n"
                "| method | accuracy | weighted F1 | precision (pos) | recall (pos) | F1 (pos) | ROC AUC |\n"
                "| --- | --- | --- | --- | --- | --- | --- |\n"
                f"{_format_metric_row('LC (static)', lc_aligned)}\n"
                f"{_format_metric_row('DTW (propagated)', dtw_aligned)}"
            )

        lines = [
            "| region | n | LC acc | LC F1 (pos) | DTW acc | DTW F1 (pos) |",
            "| --- | --- | --- | --- | --- | --- |",
        ]
        for region in ["pre", "aligned", "post"]:
            sub_mask = joined["alignment_region"] == region
            if not sub_mask.any():
                continue
            g = joined.loc[sub_mask, "gt"].to_numpy()
            lcp = joined.loc[sub_mask, "lc_pred"].to_numpy()
            dtw_p = np.array(
                [
                    dtw_class_names[i]
                    for i in joined.loc[sub_mask, dtw_class_cols].to_numpy().argmax(axis=1)
                ]
            )
            gb = (g == args.positive_class).astype(int)
            lcb = (lcp == args.positive_class).astype(int)
            dtwb = (dtw_p == args.positive_class).astype(int)
            lines.append(
                f"| {region} | {int(sub_mask.sum())} | "
                f"{accuracy_score(g, lcp):.3f} | {f1_score(gb, lcb, zero_division=0):.3f} | "
                f"{accuracy_score(g, dtw_p):.3f} | {f1_score(gb, dtwb, zero_division=0):.3f} |"
            )
        region_breakdown_md = "\n".join(lines)

    # Write per-frame predictions parquet.
    out_parquet = args.output_dir / "per_frame_predictions.parquet"
    joined.to_parquet(out_parquet, index=False)
    _logger.info("Wrote %s (%d rows)", out_parquet, len(joined))

    # Write report.
    report_md = []
    report_md.append(f"# LC vs DTW — {args.task} (positive={args.positive_class})")
    report_md.append("")
    report_md.append(f"- Alignment: `{args.alignment_parquet.name}`")
    report_md.append(f"- LC pipeline: `{args.lc_pipeline.name}`")
    report_md.append(f"- Embedding zarr: `{args.embedding_zarr.name}`")
    report_md.append(f"- Annotation: `{args.annotation_csv.name}`")
    report_md.append(f"- Rows evaluated: {len(joined)} "
                     f"(restrict_to_aligned={args.restrict_to_aligned})")
    report_md.append(f"- LC classes: {classes}")
    report_md.append(f"- DTW classes (template-observed): {dtw_class_names}")
    report_md.append("")
    report_md.append("## Head-to-head metrics")
    report_md.append("")
    report_md.append(
        "| method | accuracy | weighted F1 | precision (pos) | recall (pos) | F1 (pos) | ROC AUC |"
    )
    report_md.append("| --- | --- | --- | --- | --- | --- | --- |")
    report_md.append(_format_metric_row("LC (static)", lc_metrics))
    report_md.append(_format_metric_row("DTW (propagated)", dtw_metrics))
    report_md.append("")
    if aligned_metrics_md:
        report_md.append(aligned_metrics_md)
        report_md.append("")
    if region_breakdown_md:
        report_md.append("## By alignment region")
        report_md.append("")
        report_md.append(region_breakdown_md)
        report_md.append("")
    report_md.append("## Confusion matrices")
    report_md.append("")
    report_md.append("### LC")
    report_md.append(_confusion_md("LC", gt, lc_pred, classes))
    report_md.append("")
    report_md.append("### DTW (argmax over per-class fractions)")
    report_md.append(_confusion_md("DTW", gt, dtw_pred, dtw_class_names))
    report_md.append("")
    report_md.append("## Per-class classification report (LC)")
    report_md.append("```")
    report_md.append(classification_report(gt, lc_pred, zero_division=0))
    report_md.append("```")
    report_md.append("")
    report_md.append("## Per-class classification report (DTW)")
    report_md.append("```")
    report_md.append(classification_report(gt, dtw_pred, zero_division=0))
    report_md.append("```")

    out_md = args.output_dir / "report.md"
    out_md.write_text("\n".join(report_md))
    _logger.info("Wrote %s", out_md)

    # Also write a machine-readable summary.
    summary = {
        "task": args.task,
        "positive_class": args.positive_class,
        "n_rows": int(len(joined)),
        "restrict_to_aligned": bool(args.restrict_to_aligned),
        "lc_metrics": lc_metrics,
        "dtw_metrics": dtw_metrics,
        "lc_classes": classes,
        "dtw_classes": dtw_class_names,
    }
    (args.output_dir / "summary.json").write_text(json.dumps(summary, indent=2))

    print("\n".join(report_md))


if __name__ == "__main__":
    main()
