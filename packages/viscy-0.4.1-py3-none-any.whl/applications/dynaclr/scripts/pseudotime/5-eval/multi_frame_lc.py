"""Multi-frame LC vs single-frame LC vs DTW comparison — config-driven.

For each K ∈ {1, 3, 7}, builds a sliding-window feature representation that
concatenates ``K`` consecutive frame embeddings (replicate-padded at the
track boundaries) and trains classifiers in two flavors:

- ``LC_K{K}`` — **single-label** head: one LR predicts the center frame's
  task column from the concatenated K-frame window. One label per row.
- ``LC_K{K}_multi`` — **multi-label** head: K independent LRs, one per
  window offset (``-K//2 … +K//2``), each predicting that offset's frame
  from the same concatenated K-frame window. At inference, each cell-frame
  is covered by up to K overlapping windows; their positive-class
  probabilities are averaged to produce one prediction per frame. This is
  the cheap analog of DTW's overlapping-warp smoothing, without warping.

Two evaluation modes:

- **stratified 80/20** (track-level, all datasets pooled, stratified by
  ``dataset × has_event``).
- **leave-one-dataset-out (LOCO)** — train on N-1, test on the held-out one.

The script is biology-agnostic and reads a YAML config that lists the
task, positive class, datasets (each with its embedding zarr, DTW
alignment parquet, and annotation CSV), and modes to run. Same pipeline
runs on ALFI division and on infection eval. Pipelines are not
persisted — the script is for head-to-head comparison, not productionizing.
"""

from __future__ import annotations

import argparse
import logging
from dataclasses import dataclass
from pathlib import Path

import anndata as ad
import numpy as np
import pandas as pd
import yaml
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    accuracy_score,
    f1_score,
    precision_score,
    recall_score,
    roc_auc_score,
)
from sklearn.model_selection import StratifiedKFold, train_test_split
from sklearn.preprocessing import StandardScaler

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
_logger = logging.getLogger("multi_frame_lc")


def _load_config_with_recipes(config_path: Path) -> dict:
    """Load a leaf YAML and merge any ``base:`` recipe imports.

    The leaf may declare a ``base:`` list of relative YAML paths. Each is
    loaded in order and merged into the working config (later-wins for
    top-level scalars; ``datasets`` lists are replaced wholesale by the
    deepest definer). The leaf itself overrides on top.

    Per-dataset path resolution: when a dataset entry uses
    ``embedding_filename`` + ``dtw_alignment_filename`` (recipe pattern),
    they are joined with the leaf's ``embedding_dir`` / ``alignment_dir``
    to produce absolute ``embedding_zarr`` / ``dtw_alignment`` paths.
    Already-absolute legacy entries are passed through unchanged.
    """
    config_path = Path(config_path).resolve()
    with open(config_path) as f:
        leaf = yaml.safe_load(f) or {}

    merged: dict = {}
    for rel in leaf.pop("base", []):
        recipe_path = (config_path.parent / rel).resolve()
        with open(recipe_path) as f:
            piece = yaml.safe_load(f) or {}
        merged.update(piece)
    merged.update(leaf)

    embedding_dir = merged.get("embedding_dir")
    alignment_dir = merged.get("alignment_dir")
    datasets = merged.get("datasets") or []
    for d in datasets:
        if "embedding_zarr" not in d and "embedding_filename" in d:
            if embedding_dir is None:
                raise KeyError(
                    f"Dataset {d.get('name')} uses embedding_filename but the leaf "
                    "did not set embedding_dir."
                )
            d["embedding_zarr"] = str(Path(embedding_dir) / d["embedding_filename"])
        if "dtw_alignment" not in d and "dtw_alignment_filename" in d:
            if alignment_dir is None:
                raise KeyError(
                    f"Dataset {d.get('name')} uses dtw_alignment_filename but the leaf "
                    "did not set alignment_dir."
                )
            d["dtw_alignment"] = str(Path(alignment_dir) / d["dtw_alignment_filename"])
        if "annotation_csv" not in d and "annotation_path" in d:
            d["annotation_csv"] = d["annotation_path"]
    return merged


@dataclass
class CellLineData:
    """Per-cell-line pre-loaded data: embeddings, labels, and per-row keys."""

    name: str
    obs: pd.DataFrame  # columns: fov_name, track_id, t, gt
    embeddings: np.ndarray  # (N, 768)
    features_by_k: dict[int, np.ndarray]  # K → (N, 768*K) sliding-window features
    labels_by_k: dict[int, np.ndarray]  # K → (N, K) per-window-offset labels (replicate-padded)
    track_neighbors_by_k: dict[int, np.ndarray]  # K → (N, K) row indices of the K neighbors per row


def _load_dataset(
    name: str,
    embedding_zarr: Path,
    annotation_csv: Path,
    task: str,
    ks: list[int],
) -> CellLineData:
    """Load one dataset: embeddings, annotation, and K-frame sliding-window features.

    Replicate-pads at the start and end of each track so every cell-frame
    gets a window of length ``max(ks)``.

    Parameters
    ----------
    name : str
        Display name for the dataset (used in logs/tables; e.g. ``U2OS`` or
        ``07_24_viral_sensor``).
    embedding_zarr : Path
        AnnData zarr produced by ``viscy predict`` / ``dynaclr split-embeddings``.
    annotation_csv : Path
        Ground-truth annotation CSV with ``fov_name``, ``track_id``, ``t``,
        and the ``task`` column.
    task : str
        Annotation column to use as the target (e.g. ``cell_division_state``).
    ks : list[int]
        Window sizes to precompute (e.g. ``[1, 3, 7]``). Each ``K`` must be odd.
    """
    _logger.info("[%s] loading %s", name, embedding_zarr.name)
    a = ad.read_zarr(embedding_zarr)
    obs = a.obs.copy().reset_index(drop=True)
    obs["track_id"] = obs["track_id"].astype(int)
    obs["t"] = obs["t"].astype(int)
    obs["_iloc"] = np.arange(len(obs))
    obs = obs.drop_duplicates(subset=["fov_name", "track_id", "t"]).reset_index(drop=True)
    X = a.X[obs["_iloc"].to_numpy()]
    if hasattr(X, "toarray"):
        X = X.toarray()
    obs = obs.drop(columns=["_iloc"])

    ann = pd.read_csv(annotation_csv)
    if task not in ann.columns:
        raise KeyError(f"[{name}] annotation CSV {annotation_csv} missing column {task!r}")
    ann = ann[ann["fov_name"].isin(obs["fov_name"].unique())]
    ann = ann[["fov_name", "track_id", "t", task]].rename(columns={task: "gt"})
    ann["track_id"] = ann["track_id"].astype(int)
    ann["t"] = ann["t"].astype(int)
    ann = ann[ann["gt"].notna() & (ann["gt"] != "")]
    ann = ann.drop_duplicates(subset=["fov_name", "track_id", "t"])
    merged = obs.merge(ann, on=["fov_name", "track_id", "t"], how="inner")
    obs_to_idx = {(r.fov_name, r.track_id, r.t): i for i, r in enumerate(obs.itertuples())}
    iloc = np.array([obs_to_idx[(r.fov_name, r.track_id, r.t)] for r in merged.itertuples()])
    X = X[iloc]
    obs = merged.reset_index(drop=True)

    features_by_k: dict[int, np.ndarray] = {}
    labels_by_k: dict[int, np.ndarray] = {}
    track_neighbors_by_k: dict[int, np.ndarray] = {}
    gt_arr = obs["gt"].to_numpy()
    for K in ks:
        if K % 2 == 0:
            raise ValueError(f"K must be odd; got {K}")
        half = K // 2
        feats = np.zeros((len(obs), X.shape[1] * K), dtype=np.float32)
        neighbors = np.zeros((len(obs), K), dtype=np.int64)
        # Default to self so K=1 path and any unvisited rows stay sane.
        neighbors[:] = np.arange(len(obs))[:, None]
        for (_fov, _tid), grp in obs.groupby(["fov_name", "track_id"]):
            grp_sorted = grp.sort_values("t")
            ilocs = grp_sorted.index.to_numpy()
            n = len(ilocs)
            for j in range(n):
                window_rows = []
                for slot, off in enumerate(range(-half, half + 1)):
                    k = max(0, min(n - 1, j + off))  # replicate-pad
                    window_rows.append(X[ilocs[k]])
                    neighbors[ilocs[j], slot] = ilocs[k]
                feats[ilocs[j]] = np.concatenate(window_rows)
        features_by_k[K] = feats
        # Per-window-offset labels: shape (N, K). For each row j, slot s holds
        # the gt of the row that contributed to offset (s - half) in the
        # feature window. Replicate-padded at track boundaries (same policy as
        # the feature window).
        labels_by_k[K] = gt_arr[neighbors]
        track_neighbors_by_k[K] = neighbors
        _logger.info("[%s] K=%d sliding features shape %s", name, K, feats.shape)

    return CellLineData(
        name=name,
        obs=obs,
        embeddings=X,
        features_by_k=features_by_k,
        labels_by_k=labels_by_k,
        track_neighbors_by_k=track_neighbors_by_k,
    )


def _train_logreg(
    X: np.ndarray,
    y: np.ndarray,
    label_classes: list[str],
) -> tuple[StandardScaler, LogisticRegression]:
    """Fit a scaled logistic regression on (X, y).

    Mirrors the existing single-frame LC config: standardize features,
    L2-regularized logistic regression, balanced class weights.
    """
    scaler = StandardScaler()
    Xs = scaler.fit_transform(X)
    clf = LogisticRegression(
        max_iter=1000,
        class_weight="balanced",
        solver="liblinear",
        random_state=42,
    )
    clf.fit(Xs, y)
    if not set(clf.classes_).issuperset(set(label_classes)):
        _logger.warning(
            "Trained LC classes %s do not cover label_classes %s; ROC AUC may be skipped.",
            list(clf.classes_),
            label_classes,
        )
    return scaler, clf


def _apply(scaler: StandardScaler, clf: LogisticRegression, X: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    """Return ``(predicted_class, probability_of_positive_class)``.

    Probability of the positive class is selected by the caller from
    ``clf.classes_``; we return all class probabilities.
    """
    Xs = scaler.transform(X)
    pred = clf.predict(Xs)
    prob = clf.predict_proba(Xs)
    return pred, prob


def _load_dtw(alignment_parquet: Path, task: str) -> pd.DataFrame:
    """Read the DTW alignment parquet, dedupe lineage fanout, and carry cost+match window.

    Downstream (Stage 5 threshold work) needs the per-cell ``length_normalized_cost``
    and the matched window bounds, so we surface those alongside the per-class
    propagated labels.
    """
    df = pd.read_parquet(alignment_parquet)
    col_clean = task.replace("_state", "")
    prefix = f"propagated_{col_clean}_"
    suffix = "_label"
    class_cols = [c for c in df.columns if c.startswith(prefix) and c.endswith(suffix)]
    rename = {c: "dtw_" + c[len(prefix) : -len(suffix)] for c in class_cols}
    extra = [c for c in ("length_normalized_cost", "dtw_cost", "match_q_start", "match_q_end")
             if c in df.columns]
    out = df[["fov_name", "track_id", "t", "alignment_region", *extra, *class_cols]].rename(columns=rename)
    out["track_id"] = out["track_id"].astype(int)
    out["t"] = out["t"].astype(int)
    return out.drop_duplicates(["fov_name", "track_id", "t"]).reset_index(drop=True)


@dataclass
class TemplatePanel:
    """Raw per-track template embeddings + per-frame ground truth.

    Used by ``LC_K{K}_nn_fused`` to give the LC a template-anchor *without*
    the monotonic time warping DTW does. Each test track picks a 1-NN
    template track by mean cosine distance over the overlap of their
    wall-clock t-ranges; the neighbor's per-frame label is then fused
    50/50 into the LC's positive-class probability.

    Attributes
    ----------
    tracks : list of dict
        One entry per template build track with keys:
        ``build_dataset``, ``fov_name``, ``track_id``, ``t`` (ndarray),
        ``embeddings`` (ndarray of shape (T, 768)),
        ``gt`` (ndarray of label strings, length T).
    """

    tracks: list[dict]


def _load_template_panel(
    template_embedding_dir: Path,
    build_datasets: list[str],
    annotation_csv_by_build_dataset: dict[str, Path],
    task: str,
    refined_track_ids: dict[str, list[tuple[str, int]]] | None = None,
    zarr_filename_by_build_dataset: dict[str, str] | None = None,
) -> TemplatePanel:
    """Load the raw per-track embeddings + annotations of the template build set.

    Each build dataset's embedding zarr is read once and split per
    ``(fov_name, track_id)``. Annotations are joined per frame so each
    track carries both its embedding sequence and its per-frame ground
    truth.

    Parameters
    ----------
    template_embedding_dir : Path
        Directory containing the per-build-dataset embedding zarrs. The
        zarr filename for build dataset ``BD`` is resolved as
        ``BD.zarr`` (case sensitive). For the canonical viral_sensor
        template this is the same as the eval embedding dir; for the
        Phase3D template this is the Phase3D-channel embedding dir.
    build_datasets : list of str
        Names of the build datasets (e.g. ``["2025_07_24_SEC61", "2025_07_24_G3BP1"]``).
    annotation_csv_by_build_dataset : dict
        Mapping from build dataset name to its annotation CSV path. The
        roster carries this for every entry that aligns against the
        template; we look up by build dataset name.
    task : str
        Annotation column to use as the per-frame label (same as the eval
        task; e.g. ``infection_state``).
    refined_track_ids : dict, optional
        If supplied, restrict to a known subset of refined tracks per
        build dataset: ``{build_dataset: [(fov_name, track_id), ...]}``.
        If None, every track in the build dataset is included.

    Returns
    -------
    TemplatePanel
    """
    tracks: list[dict] = []
    for bd in build_datasets:
        if zarr_filename_by_build_dataset and bd in zarr_filename_by_build_dataset:
            zarr_path = template_embedding_dir / zarr_filename_by_build_dataset[bd]
        else:
            zarr_path = template_embedding_dir / f"{bd}.zarr"
        if not zarr_path.exists():
            raise FileNotFoundError(
                f"template embedding zarr for build dataset {bd!r} not found at {zarr_path}"
            )
        if bd not in annotation_csv_by_build_dataset:
            raise KeyError(
                f"no annotation CSV registered for build dataset {bd!r}; "
                f"add it under the matching roster entry"
            )
        a = ad.read_zarr(zarr_path)
        obs = a.obs.copy().reset_index(drop=True)
        obs["track_id"] = obs["track_id"].astype(int)
        obs["t"] = obs["t"].astype(int)
        obs["_iloc"] = np.arange(len(obs))
        obs = obs.drop_duplicates(subset=["fov_name", "track_id", "t"]).reset_index(drop=True)
        X = a.X[obs["_iloc"].to_numpy()]
        if hasattr(X, "toarray"):
            X = X.toarray()
        obs = obs.drop(columns=["_iloc"])

        ann = pd.read_csv(annotation_csv_by_build_dataset[bd])
        if task not in ann.columns:
            raise KeyError(f"[{bd}] annotation CSV missing column {task!r}")
        ann = ann[["fov_name", "track_id", "t", task]].rename(columns={task: "gt"})
        ann["track_id"] = ann["track_id"].astype(int)
        ann["t"] = ann["t"].astype(int)
        ann = ann[ann["gt"].notna() & (ann["gt"] != "")]
        ann = ann.drop_duplicates(subset=["fov_name", "track_id", "t"])
        merged = obs.merge(ann, on=["fov_name", "track_id", "t"], how="inner")
        obs_to_idx = {(r.fov_name, r.track_id, r.t): i for i, r in enumerate(obs.itertuples())}
        iloc = np.array([obs_to_idx[(r.fov_name, r.track_id, r.t)] for r in merged.itertuples()])
        X_m = X[iloc]
        merged = merged.reset_index(drop=True)

        keep = None
        if refined_track_ids is not None and bd in refined_track_ids:
            keep_set = set(refined_track_ids[bd])
            keep = merged.apply(lambda r: (r["fov_name"], int(r["track_id"])) in keep_set, axis=1)
            merged = merged[keep].reset_index(drop=True)
            X_m = X_m[keep.to_numpy()]

        for (fov, tid), grp in merged.groupby(["fov_name", "track_id"]):
            grp_sorted = grp.sort_values("t")
            ilocs = grp_sorted.index.to_numpy()
            tracks.append({
                "build_dataset": bd,
                "fov_name": fov,
                "track_id": int(tid),
                "t": grp_sorted["t"].to_numpy(),
                "embeddings": X_m[ilocs].astype(np.float32),
                "gt": grp_sorted["gt"].to_numpy(),
            })

    _logger.info(
        "Template panel: %d tracks across %d build datasets (%s)",
        len(tracks), len(build_datasets), ", ".join(build_datasets),
    )
    return TemplatePanel(tracks=tracks)


def _nn_template_for_track(
    test_embeddings: np.ndarray,
    test_t: np.ndarray,
    panel: TemplatePanel,
) -> tuple[int, float, np.ndarray, np.ndarray]:
    """Find the 1-NN template track for one test track (legacy 1-NN, kept stable).

    Returns
    -------
    nn_idx : int
        Index into ``panel.tracks`` of the chosen neighbor; -1 if no
        candidate had any overlap.
    nn_cosdist : float
        Mean cosine distance over the overlap. NaN if nn_idx == -1.
    nn_labels : ndarray of shape (T_test,)
        Per-test-frame neighbor label (empty string outside the overlap).
    nn_in_overlap : ndarray of bool, shape (T_test,)
        True where the neighbor covered the test frame.
    """
    best_idx = -1
    best_score = np.inf
    test_norms = np.linalg.norm(test_embeddings, axis=1) + 1e-12
    for i, tpl in enumerate(panel.tracks):
        tpl_t = tpl["t"]
        if len(tpl_t) == 0:
            continue
        t_lo = max(test_t[0], tpl_t[0])
        t_hi = min(test_t[-1], tpl_t[-1])
        if t_hi < t_lo:
            continue
        common = np.intersect1d(test_t[(test_t >= t_lo) & (test_t <= t_hi)],
                                tpl_t[(tpl_t >= t_lo) & (tpl_t <= t_hi)])
        if common.size == 0:
            continue
        test_pos = np.searchsorted(test_t, common)
        tpl_pos = np.searchsorted(tpl_t, common)
        a = test_embeddings[test_pos]
        b = tpl["embeddings"][tpl_pos]
        a_n = test_norms[test_pos]
        b_n = np.linalg.norm(b, axis=1) + 1e-12
        cos_sim = (a * b).sum(axis=1) / (a_n * b_n)
        score = float((1.0 - cos_sim).mean())
        if score < best_score:
            best_score = score
            best_idx = i

    if best_idx == -1:
        return -1, float("nan"), np.array([""] * len(test_t), dtype=object), np.zeros(len(test_t), dtype=bool)

    tpl = panel.tracks[best_idx]
    tpl_t = tpl["t"]
    tpl_gt = tpl["gt"]
    nn_labels = np.array([""] * len(test_t), dtype=object)
    in_overlap = np.zeros(len(test_t), dtype=bool)
    valid = np.isin(test_t, tpl_t)
    pos_in_tpl = np.searchsorted(tpl_t, test_t)
    nn_labels[valid] = tpl_gt[pos_in_tpl[valid]]
    in_overlap[:] = valid
    return best_idx, best_score, nn_labels, in_overlap


def _nn_template_for_track_robust(
    test_embeddings: np.ndarray,
    test_t: np.ndarray,
    panel: TemplatePanel,
    n_neighbors: int = 1,
    exclude_predicate=None,
    rng: np.random.Generator | None = None,
) -> tuple[list[int], float, np.ndarray, np.ndarray]:
    """Top-K template-NN matcher with optional exclude + random baseline.

    Used by the robustness ablations (k=3 fusion, leave-one-day-out,
    random-template baseline). Returns per-test-frame *positive-class
    fraction across the K neighbors* — the caller already knows the
    positive class so we let it binarize.

    Parameters
    ----------
    test_embeddings : ndarray of shape (T_test, 768)
    test_t : ndarray of shape (T_test,)
    panel : TemplatePanel
    n_neighbors : int
        How many templates to fuse. K=1 reproduces 1-NN; K=3 is the
        robustness check against a single overfit match.
    exclude_predicate : callable(tpl_dict) -> bool, optional
        When given, panel tracks for which the predicate returns True are
        excluded from the candidate pool. Use case: exclude templates
        from the same imaging day as the test cell to break in-distribution
        self-match.
    rng : np.random.Generator, optional
        When supplied, pick K *random* templates (uniform over candidates
        with any overlap) instead of the K nearest. Random baseline.

    Returns
    -------
    nn_idxs : list of int
        K chosen panel indices (or empty if no overlap).
    mean_cosdist : float
        Mean cosine distance over the chosen templates. NaN if empty.
    label_matrix : ndarray of shape (T_test, K)
        Per-frame neighbor labels per chosen template, "" outside coverage.
    any_covered : ndarray of bool, shape (T_test,)
        True where ≥1 of the K neighbors covers the frame.
    """
    scored: list[tuple[float, int]] = []
    test_norms = np.linalg.norm(test_embeddings, axis=1) + 1e-12
    for i, tpl in enumerate(panel.tracks):
        if exclude_predicate is not None and exclude_predicate(tpl):
            continue
        tpl_t = tpl["t"]
        if len(tpl_t) == 0:
            continue
        t_lo = max(test_t[0], tpl_t[0])
        t_hi = min(test_t[-1], tpl_t[-1])
        if t_hi < t_lo:
            continue
        common = np.intersect1d(test_t[(test_t >= t_lo) & (test_t <= t_hi)],
                                tpl_t[(tpl_t >= t_lo) & (tpl_t <= t_hi)])
        if common.size == 0:
            continue
        test_pos = np.searchsorted(test_t, common)
        tpl_pos = np.searchsorted(tpl_t, common)
        a = test_embeddings[test_pos]
        b = tpl["embeddings"][tpl_pos]
        a_n = test_norms[test_pos]
        b_n = np.linalg.norm(b, axis=1) + 1e-12
        cos_sim = (a * b).sum(axis=1) / (a_n * b_n)
        score = float((1.0 - cos_sim).mean())
        scored.append((score, i))

    if not scored:
        return [], float("nan"), np.empty((len(test_t), 0), dtype=object), np.zeros(len(test_t), dtype=bool)

    if rng is None:
        scored.sort(key=lambda x: x[0])
        chosen = scored[:n_neighbors]
    else:
        score_by_idx = {i: s for s, i in scored}
        idx_pool = list(score_by_idx.keys())
        n_pick = min(n_neighbors, len(idx_pool))
        picked = rng.choice(idx_pool, size=n_pick, replace=False).tolist()
        chosen = [(score_by_idx[i], i) for i in picked]

    nn_idxs = [i for _, i in chosen]
    mean_cosdist = float(np.mean([s for s, _ in chosen]))

    K = len(chosen)
    label_matrix = np.full((len(test_t), K), "", dtype=object)
    any_covered = np.zeros(len(test_t), dtype=bool)
    for j, (_, nn_idx) in enumerate(chosen):
        tpl = panel.tracks[nn_idx]
        tpl_t = tpl["t"]
        tpl_gt = tpl["gt"]
        valid = np.isin(test_t, tpl_t)
        if not valid.any():
            continue
        pos_in_tpl = np.searchsorted(tpl_t, test_t)
        label_matrix[valid, j] = tpl_gt[pos_in_tpl[valid]]
        any_covered |= valid
    return nn_idxs, mean_cosdist, label_matrix, any_covered


def _binary_metrics(
    gt: np.ndarray,
    pred: np.ndarray,
    prob: np.ndarray | None,
    positive: str,
) -> dict[str, float]:
    """Standard accuracy / F1 / precision / recall / ROC-AUC with one positive class."""
    gt_bin = (gt == positive).astype(int)
    pred_bin = (pred == positive).astype(int)
    out = {
        "accuracy": float(accuracy_score(gt, pred)),
        "precision": float(precision_score(gt_bin, pred_bin, zero_division=0)),
        "recall": float(recall_score(gt_bin, pred_bin, zero_division=0)),
        "f1": float(f1_score(gt_bin, pred_bin, zero_division=0)),
    }
    if prob is not None and len(np.unique(gt_bin)) > 1:
        out["roc_auc"] = float(roc_auc_score(gt_bin, prob))
    else:
        out["roc_auc"] = float("nan")
    return out


def _train_test_locos(data: dict[str, CellLineData], cell_lines: list[str]) -> list[tuple[str, dict, dict]]:
    """Yield ``(label, train_rows_by_cl, test_rows_by_cl)`` for each LOCO fold.

    For each held-out cell line, the training rows are *all rows* of the
    other two cell lines and the test rows are *all rows* of the held-out
    cell line. The boolean masks per cell line index into
    ``data[cl].obs`` / ``data[cl].features_by_k[K]``.
    """
    folds: list[tuple[str, dict, dict]] = []
    for held_out in cell_lines:
        train_rows = {cl: np.ones(len(data[cl].obs), dtype=bool) if cl != held_out
                      else np.zeros(len(data[cl].obs), dtype=bool) for cl in cell_lines}
        test_rows = {cl: ~train_rows[cl] for cl in cell_lines}
        folds.append((f"LOCO_held_out_{held_out}", train_rows, test_rows))
    return folds


def _train_test_stratified(
    data: dict[str, CellLineData],
    cell_lines: list[str],
    positive_class: str,
    test_size: float = 0.2,
    random_state: int = 42,
) -> list[tuple[str, dict, dict]]:
    """Single train/test fold via 80/20 split stratified by (cell_line × has_event_track).

    The split is at the **track** level (not the row level) so adjacent
    frames from the same track stay on the same side, preventing the
    multi-frame LC from trivially seeing test rows. Each track is labeled
    by (cell_line, whether-it-contains-a-positive-frame). The full
    annotation row set is then re-split, with whole tracks landing in
    train or test as determined by the stratified track split.

    Parameters
    ----------
    test_size : float
        Fraction of tracks to hold out per stratum.
    random_state : int
        Seed for reproducibility.
    """
    track_keys: list[tuple[str, str, int, str]] = []
    for cl in cell_lines:
        obs = data[cl].obs
        for (fov, tid), grp in obs.groupby(["fov_name", "track_id"]):
            has_event = (grp["gt"] == positive_class).any()
            strat = f"{cl}__{'pos' if has_event else 'neg'}"
            track_keys.append((cl, fov, int(tid), strat))
    track_df = pd.DataFrame(track_keys, columns=["cell_line", "fov_name", "track_id", "stratum"])
    train_tracks, test_tracks = train_test_split(
        track_df,
        test_size=test_size,
        stratify=track_df["stratum"],
        random_state=random_state,
    )
    _logger.info(
        "Stratified split: %d train tracks, %d test tracks (per-stratum train/test):",
        len(train_tracks),
        len(test_tracks),
    )
    for stratum, sub in train_tracks.groupby("stratum"):
        n_test = (test_tracks["stratum"] == stratum).sum()
        _logger.info("  %s: train=%d, test=%d", stratum, len(sub), n_test)

    train_set = {(r.cell_line, r.fov_name, r.track_id) for r in train_tracks.itertuples()}
    test_set = {(r.cell_line, r.fov_name, r.track_id) for r in test_tracks.itertuples()}

    train_rows: dict[str, np.ndarray] = {}
    test_rows: dict[str, np.ndarray] = {}
    for cl in cell_lines:
        obs = data[cl].obs
        keys = list(zip([cl] * len(obs), obs["fov_name"], obs["track_id"]))
        train_rows[cl] = np.array([k in train_set for k in keys], dtype=bool)
        test_rows[cl] = np.array([k in test_set for k in keys], dtype=bool)
    return [("stratified_80_20", train_rows, test_rows)]


def _load_lineage_ids(
    alignment_parquet: Path,
    annotation_csv: Path | None = None,
) -> dict[tuple[str, int], str]:
    """Return ``{(fov_name, track_id): lineage_id}`` for every track in the alignment.

    First tries the alignment parquet's ``lineage_id`` column (written by
    Stage 2 lineage-aware DTW when a productive-cohort CSV was supplied).
    When ``lineage_id`` is missing or empty, falls back to computing
    lineage roots from the annotation CSV's ``parent_track_id`` chain.

    Parameters
    ----------
    alignment_parquet : Path
        Stage 2 DTW alignment parquet. Restricts the returned mapping to
        DTW-covered tracks.
    annotation_csv : Path or None
        Optional annotation CSV used to derive lineage IDs when the
        alignment parquet doesn't carry them. Expects ``fov_name``,
        ``track_id``, ``parent_track_id`` columns.
    """
    cols = ["fov_name", "track_id"]
    align = pd.read_parquet(alignment_parquet)
    has_lineage = (
        "lineage_id" in align.columns
        and align["lineage_id"].notna().any()
        and (align["lineage_id"].astype(str).str.len() > 0).any()
    )
    align = align[cols + (["lineage_id"] if "lineage_id" in align.columns else [])].drop_duplicates(cols)

    if has_lineage:
        result = {
            (row.fov_name, int(row.track_id)): str(row.lineage_id)
            for row in align.itertuples()
            if str(row.lineage_id) not in ("", "nan", "None")
        }
        if result:
            return result

    if annotation_csv is None:
        # Fall back to per-track (no lineage collapse)
        return {(row.fov_name, int(row.track_id)): f"{row.fov_name}::{int(row.track_id)}"
                for row in align.itertuples()}

    # Compute lineage roots by walking parent_track_id back to -1 (no parent)
    ann = pd.read_csv(annotation_csv)
    if "parent_track_id" not in ann.columns:
        _logger.warning("[%s] annotation has no parent_track_id; using per-track lineage", annotation_csv.name)
        return {(row.fov_name, int(row.track_id)): f"{row.fov_name}::{int(row.track_id)}"
                for row in align.itertuples()}

    ann = ann[["fov_name", "track_id", "parent_track_id"]].drop_duplicates()
    ann["track_id"] = ann["track_id"].astype(int)
    ann["parent_track_id"] = ann["parent_track_id"].fillna(-1).astype(int)
    parent_lookup: dict[tuple[str, int], int] = {
        (row.fov_name, row.track_id): row.parent_track_id for row in ann.itertuples()
    }

    def _root(fov: str, tid: int) -> int:
        seen: set[int] = set()
        cur = tid
        while True:
            if cur in seen:
                return cur
            seen.add(cur)
            parent = parent_lookup.get((fov, cur), -1)
            if parent is None or int(parent) == -1:
                return cur
            cur = int(parent)

    result = {}
    for row in align.itertuples():
        root = _root(row.fov_name, int(row.track_id))
        result[(row.fov_name, int(row.track_id))] = f"{row.fov_name}::root{root}"
    return result


def _train_test_per_cell_type(
    data: dict[str, CellLineData],
    dataset_names: list[str],
    cell_type_by_dataset: dict[str, str],
    alignment_by_dataset: dict[str, Path],
    annotation_by_dataset: dict[str, Path],
    positive_class: str,
    n_folds: int = 5,
    test_size: float = 0.2,
    random_state: int = 42,
) -> list[tuple[str, dict, dict]]:
    """Per-cell-type splits — train+test stays within one cell type.

    Behaviour per cell type depends on the number of contributing datasets
    *and* whether lineage_id is available in the alignment parquet:

    - **lineage-aware** (used when ≥ one dataset has lineage_id and only one
      dataset per cell type — ALFI division case): build a per-lineage table
      with ``has_event`` stratification, run ``StratifiedKFold(n_folds)``.
      Produces ``n_folds`` folds per cell type.
    - **track-level single-fold** (used for cell types with multiple datasets
      — infection A549 case): build a per-track table stratified by
      ``(dataset, has_event)``, run a single ``train_test_split`` with the
      given ``test_size``. Produces one fold per cell type.

    Tracks that DTW filtered out (no row in the alignment parquet) are
    dropped — keeps the comparison apples-to-apples between LC and DTW.
    """
    folds: list[tuple[str, dict, dict]] = []

    # Group datasets by cell type
    by_type: dict[str, list[str]] = {}
    for ds in dataset_names:
        ct = cell_type_by_dataset[ds]
        by_type.setdefault(ct, []).append(ds)

    for cell_type, ds_list in by_type.items():
        # Build per-track table (one row per (dataset, fov, track_id))
        # with lineage_id where available and has_event flag.
        rows: list[dict] = []
        for ds in ds_list:
            obs = data[ds].obs
            lineage_lookup = _load_lineage_ids(
                alignment_by_dataset[ds],
                annotation_csv=annotation_by_dataset.get(ds),
            )
            for (fov, tid), grp in obs.groupby(["fov_name", "track_id"]):
                key = (fov, int(tid))
                if key not in lineage_lookup:
                    continue  # restrict to DTW-covered tracks
                rows.append({
                    "dataset": ds,
                    "fov_name": fov,
                    "track_id": int(tid),
                    "lineage_id": lineage_lookup[key],
                    "has_event": bool((grp["gt"] == positive_class).any()),
                })
        track_df = pd.DataFrame(rows)
        if track_df.empty:
            _logger.warning("[%s] no DTW-covered tracks; skipping", cell_type)
            continue

        n_datasets = len(ds_list)
        if n_datasets == 1:
            # Lineage-level k-fold for single-dataset cell types (ALFI case)
            lineage_df = (
                track_df.groupby("lineage_id")
                .agg(has_event=("has_event", "any"))
                .reset_index()
            )
            n_pos = int(lineage_df["has_event"].sum())
            n_neg = int(len(lineage_df) - n_pos)
            if min(n_pos, n_neg) < n_folds:
                _logger.warning(
                    "[%s] not enough lineages for %d-fold (pos=%d, neg=%d); falling back to 80/20",
                    cell_type, n_folds, n_pos, n_neg,
                )
                # Fall through to single-fold 80/20 on lineages
                from sklearn.model_selection import train_test_split as _tts
                train_l, test_l = _tts(
                    lineage_df, test_size=test_size,
                    stratify=lineage_df["has_event"], random_state=random_state,
                )
                lineage_splits = [(set(test_l["lineage_id"]), 0)]
            else:
                skf = StratifiedKFold(n_splits=n_folds, shuffle=True, random_state=random_state)
                lineage_splits = []
                for fold_i, (_, test_idx) in enumerate(
                    skf.split(lineage_df["lineage_id"], lineage_df["has_event"])
                ):
                    test_lineages = set(lineage_df.iloc[test_idx]["lineage_id"])
                    lineage_splits.append((test_lineages, fold_i))

            for test_lineages, fold_i in lineage_splits:
                fold_label = f"per_cell_type_{cell_type}_fold{fold_i}"
                _logger.info(
                    "[%s fold %d] %d test lineages, %d train lineages",
                    cell_type, fold_i,
                    len(test_lineages), len(lineage_df) - len(test_lineages),
                )
                train_rows: dict[str, np.ndarray] = {}
                test_rows: dict[str, np.ndarray] = {}
                for ds in dataset_names:
                    obs = data[ds].obs
                    if cell_type_by_dataset[ds] != cell_type:
                        # Other cell types not in this fold at all
                        train_rows[ds] = np.zeros(len(obs), dtype=bool)
                        test_rows[ds] = np.zeros(len(obs), dtype=bool)
                        continue
                    keys = list(zip(obs["fov_name"], obs["track_id"].astype(int)))
                    ds_track_df = track_df[track_df["dataset"] == ds]
                    lineage_by_key = {
                        (r.fov_name, int(r.track_id)): r.lineage_id
                        for r in ds_track_df.itertuples()
                    }
                    test_mask = np.array(
                        [lineage_by_key.get(k) in test_lineages for k in keys], dtype=bool
                    )
                    train_mask = np.array(
                        [
                            (lineage_by_key.get(k) is not None)
                            and (lineage_by_key.get(k) not in test_lineages)
                            for k in keys
                        ],
                        dtype=bool,
                    )
                    train_rows[ds] = train_mask
                    test_rows[ds] = test_mask
                folds.append((fold_label, train_rows, test_rows))
        else:
            # Track-level single 80/20 stratified by (dataset, has_event)
            track_df["stratum"] = track_df["dataset"] + "__" + np.where(
                track_df["has_event"], "pos", "neg"
            )
            from sklearn.model_selection import train_test_split as _tts
            train_t, test_t = _tts(
                track_df, test_size=test_size,
                stratify=track_df["stratum"], random_state=random_state,
            )
            test_keys = {
                (r.dataset, r.fov_name, int(r.track_id)) for r in test_t.itertuples()
            }
            train_keys = {
                (r.dataset, r.fov_name, int(r.track_id)) for r in train_t.itertuples()
            }
            fold_label = f"per_cell_type_{cell_type}"
            _logger.info(
                "[%s] %d test tracks, %d train tracks (across %d datasets)",
                cell_type, len(test_keys), len(train_keys), n_datasets,
            )
            train_rows = {}
            test_rows = {}
            for ds in dataset_names:
                obs = data[ds].obs
                if cell_type_by_dataset[ds] != cell_type:
                    train_rows[ds] = np.zeros(len(obs), dtype=bool)
                    test_rows[ds] = np.zeros(len(obs), dtype=bool)
                    continue
                keys = list(zip([ds] * len(obs), obs["fov_name"], obs["track_id"].astype(int)))
                train_rows[ds] = np.array([k in train_keys for k in keys], dtype=bool)
                test_rows[ds] = np.array([k in test_keys for k in keys], dtype=bool)
            folds.append((fold_label, train_rows, test_rows))

    return folds


def _train_eval_one_fold(
    fold_label: str,
    train_rows: dict[str, np.ndarray],
    test_rows: dict[str, np.ndarray],
    data: dict[str, CellLineData],
    cell_lines: list[str],
    ks: list[int],
    positive_class: str,
    all_labels: list[str],
    fold_kind: str,
    template_panel: TemplatePanel | None = None,
    nn_fuse_k: int | None = None,
) -> tuple[list[dict], dict[str, pd.DataFrame]]:
    """Train one LC per K on the fold's train rows, predict on its test rows.

    When ``template_panel`` is supplied, additionally emit
    ``LC_K{nn_fuse_k}_nn_fused`` predictions per test cell: for each test
    track find its 1-NN template track by frame-aligned mean cosine
    distance (no warp), then fuse the 1-NN's per-frame labels with the
    ``LC_K{nn_fuse_k}`` positive-class probability via 50/50 averaging.
    The fused metric row is added to ``results``; the new columns land in
    each test record so they propagate into the per-frame parquet and the
    DTW-intersection re-score.

    Returns
    -------
    results : list[dict]
        Per-cell-line × per-K metric rows (mode-agnostic).
    test_rows_by_cl : dict[str, pd.DataFrame]
        For each cell line, the test rows with attached per-K predictions
        and probabilities. Used downstream for the DTW intersection score.
    """
    results: list[dict] = []
    per_cl_records: dict[str, list[pd.DataFrame]] = {cl: [] for cl in cell_lines}

    for K in ks:
        X_train_parts: list[np.ndarray] = []
        y_train_parts: list[np.ndarray] = []
        y_train_multi_parts: list[np.ndarray] = []
        for cl in cell_lines:
            mask = train_rows[cl]
            if not mask.any():
                continue
            X_train_parts.append(data[cl].features_by_k[K][mask])
            y_train_parts.append(data[cl].obs["gt"].to_numpy()[mask])
            y_train_multi_parts.append(data[cl].labels_by_k[K][mask])  # (n_train, K)
        X_train = np.concatenate(X_train_parts, axis=0)
        y_train = np.concatenate(y_train_parts, axis=0)
        y_train_multi = np.concatenate(y_train_multi_parts, axis=0)
        _logger.info("[%s K=%d] train rows: %d", fold_label, K, len(y_train))

        scaler, clf = _train_logreg(X_train, y_train, all_labels)
        pos_idx = list(clf.classes_).index(positive_class) if positive_class in clf.classes_ else None

        # Multi-label heads: K independent LRs, one per window offset.
        # Each head reuses the same scaled features (refit per-head to keep
        # _train_logreg's scaler contract intact); positive-class probabilities
        # from overlapping windows are then averaged per cell-frame at
        # inference. Reuses the same scaler each time would be slightly faster
        # but training K LRs on the same features is the bottleneck either way.
        multi_heads: list[tuple[StandardScaler, LogisticRegression, int | None]] = []
        for slot in range(K):
            y_slot = y_train_multi[:, slot]
            if len(set(y_slot.tolist())) < 2:
                multi_heads.append((None, None, None))  # degenerate slot — skip
                continue
            scaler_s, clf_s = _train_logreg(X_train, y_slot, all_labels)
            pos_idx_s = (
                list(clf_s.classes_).index(positive_class)
                if positive_class in clf_s.classes_ else None
            )
            multi_heads.append((scaler_s, clf_s, pos_idx_s))

        for cl in cell_lines:
            mask = test_rows[cl]
            if not mask.any():
                continue
            X_test = data[cl].features_by_k[K][mask]
            obs_test = data[cl].obs[mask].reset_index(drop=True)
            pred, prob = _apply(scaler, clf, X_test)
            prob_pos = prob[:, pos_idx] if pos_idx is not None else None
            record = obs_test[["fov_name", "track_id", "t", "gt"]].copy()
            record[f"lc_K{K}_pred"] = pred
            if prob_pos is not None:
                record[f"lc_K{K}_prob_pos"] = prob_pos

            # Multi-label inference: each test-row provides one window (size K).
            # Head s of that window predicts the label of the frame at window
            # offset (s - K//2), which lives at obs row index
            # track_neighbors_by_k[K][row, s]. We accumulate positive-class
            # probabilities for every (target_row, s) covered by any window
            # whose center is in the test set, then average per target_row.
            N = len(data[cl].obs)
            prob_sum = np.zeros(N, dtype=np.float64)
            prob_cnt = np.zeros(N, dtype=np.int64)
            test_iloc = np.where(mask)[0]
            neighbors_K = data[cl].track_neighbors_by_k[K]  # (N, K)
            for slot in range(K):
                scaler_s, clf_s, pos_idx_s = multi_heads[slot]
                if clf_s is None or pos_idx_s is None:
                    continue
                prob_s = _apply(scaler_s, clf_s, X_test)[1][:, pos_idx_s]
                # target_rows: which obs row this slot's prediction belongs to.
                target_rows = neighbors_K[test_iloc, slot]
                np.add.at(prob_sum, target_rows, prob_s)
                np.add.at(prob_cnt, target_rows, 1)

            # Average across overlapping windows; only target rows that appear
            # in at least one test window get a multi prediction (most often
            # all test rows + a few train-adjacent rows; we drop the latter
            # by restricting to the test set when building the record).
            with np.errstate(invalid="ignore"):
                prob_avg = np.where(prob_cnt > 0, prob_sum / np.maximum(prob_cnt, 1), np.nan)
            # Restrict to the actual test rows for this cell line (the record
            # frame's rows correspond to test_iloc in order).
            prob_pos_multi = prob_avg[test_iloc]
            # Predicted class = positive iff averaged prob_pos > 0.5; otherwise
            # the next-most-frequent label seen at training time. For binary
            # tasks this is just (positive vs the unique non-positive label).
            neg_label = next((lbl for lbl in all_labels if lbl != positive_class), None)
            if neg_label is None:
                pred_multi = np.array([positive_class] * len(prob_pos_multi))
            else:
                pred_multi = np.where(prob_pos_multi >= 0.5, positive_class, neg_label)
                # Rows with no coverage (count == 0) → fall back to single-label pred.
                nocov = np.isnan(prob_pos_multi)
                if nocov.any():
                    pred_multi[nocov] = pred[nocov]
                    prob_pos_multi[nocov] = prob_pos[nocov] if prob_pos is not None else np.nan
            record[f"lc_K{K}_multi_pred"] = pred_multi
            record[f"lc_K{K}_multi_prob_pos"] = prob_pos_multi

            # Template-anchored 1-NN fusion (only for the requested K).
            if template_panel is not None and K == nn_fuse_k and prob_pos is not None:
                nn_track_ids = np.array([""] * len(obs_test), dtype=object)
                nn_cosdists = np.full(len(obs_test), np.nan, dtype=np.float64)
                nn_labels_per_row = np.array([""] * len(obs_test), dtype=object)
                in_overlap = np.zeros(len(obs_test), dtype=bool)
                obs_test_sorted = obs_test.assign(_row=np.arange(len(obs_test)))
                for (fov, tid), grp in obs_test_sorted.groupby(["fov_name", "track_id"]):
                    grp_sorted = grp.sort_values("t")
                    rows = grp_sorted["_row"].to_numpy()
                    ts = grp_sorted["t"].to_numpy()
                    # Embeddings for this test track at these frames.
                    cl_obs_iloc = (
                        data[cl].obs.reset_index()
                        .merge(grp_sorted[["fov_name", "track_id", "t"]],
                               on=["fov_name", "track_id", "t"], how="inner")
                        .sort_values("t")["index"].to_numpy()
                    )
                    test_emb = data[cl].embeddings[cl_obs_iloc]
                    nn_idx, nn_score, nn_lab, nn_cov = _nn_template_for_track(
                        test_emb, ts, template_panel,
                    )
                    if nn_idx >= 0:
                        tpl = template_panel.tracks[nn_idx]
                        track_str = f"{tpl['build_dataset']}|{tpl['fov_name']}|{tpl['track_id']}"
                    else:
                        track_str = ""
                    nn_track_ids[rows] = track_str
                    nn_cosdists[rows] = nn_score
                    nn_labels_per_row[rows] = nn_lab
                    in_overlap[rows] = nn_cov

                # Build the 50/50 fused probability. Frames outside any
                # template's t-range (or where the NN has no label) keep
                # the bare LC_K{K} probability — no extrapolation.
                p_nn = np.where(
                    in_overlap,
                    (nn_labels_per_row == positive_class).astype(np.float64),
                    np.nan,
                )
                p_lc = prob_pos
                p_fused = np.where(np.isnan(p_nn), p_lc, 0.5 * p_lc + 0.5 * p_nn)
                neg_label = next((lbl for lbl in all_labels if lbl != positive_class), None)
                pred_fused = (
                    np.where(p_fused >= 0.5, positive_class, neg_label or positive_class)
                )
                record["nn_template_track"] = nn_track_ids
                record["nn_template_cosdist"] = nn_cosdists
                record["nn_label_at_t"] = nn_labels_per_row
                record[f"lc_K{K}_nn_fused_pred"] = pred_fused
                record[f"lc_K{K}_nn_fused_prob_pos"] = p_fused

            per_cl_records[cl].append(record)

            m = _binary_metrics(obs_test["gt"].to_numpy(), pred, prob_pos, positive_class)
            results.append({"fold": fold_label, "fold_kind": fold_kind, "cell_line": cl,
                            "method": f"LC_K{K}", **m})
            m_multi = _binary_metrics(
                obs_test["gt"].to_numpy(), pred_multi, prob_pos_multi, positive_class
            )
            results.append({"fold": fold_label, "fold_kind": fold_kind, "cell_line": cl,
                            "method": f"LC_K{K}_multi", **m_multi})
            if template_panel is not None and K == nn_fuse_k and prob_pos is not None:
                m_fused = _binary_metrics(
                    obs_test["gt"].to_numpy(), pred_fused, p_fused, positive_class
                )
                results.append({"fold": fold_label, "fold_kind": fold_kind, "cell_line": cl,
                                "method": f"LC_K{K}_nn_fused", **m_fused})

    # Combine per-K predictions into one frame per cell line
    test_rows_by_cl: dict[str, pd.DataFrame] = {}
    for cl in cell_lines:
        if not per_cl_records[cl]:
            continue
        base = per_cl_records[cl][0][["fov_name", "track_id", "t", "gt"]].copy()
        for r in per_cl_records[cl]:
            keep_cols = ["fov_name", "track_id", "t"] + [
                c for c in r.columns
                if c.startswith("lc_K") or c.startswith("nn_")
            ]
            base = base.merge(r[keep_cols], on=["fov_name", "track_id", "t"], how="left")
        test_rows_by_cl[cl] = base
    return results, test_rows_by_cl


def _score_dtw_on_test_rows(
    test_rows_by_cl: dict[str, pd.DataFrame],
    dtw_path_by_cl: dict[str, Path],
    data_task: str,
    cell_lines: list[str],
    ks: list[int],
    positive_class: str,
    fold_label: str,
    fold_kind: str,
    aligned_only: bool,
) -> tuple[list[dict], dict[str, pd.DataFrame]]:
    """Intersect each dataset's test rows with the DTW alignment parquet and score.

    Returns the per-dataset metric rows (DTW + LC re-scored on the join)
    plus the joined per-frame frames (for parquet output).
    """
    results: list[dict] = []
    joined_by_cl: dict[str, pd.DataFrame] = {}
    for cl in cell_lines:
        if cl not in test_rows_by_cl or cl not in dtw_path_by_cl:
            continue
        dtw = _load_dtw(dtw_path_by_cl[cl], data_task)
        joined = test_rows_by_cl[cl].merge(dtw, on=["fov_name", "track_id", "t"], how="inner")
        if aligned_only:
            joined = joined[joined["alignment_region"] == "aligned"].reset_index(drop=True)
        if joined.empty:
            _logger.warning("[%s/%s] empty DTW intersection; skipping", fold_label, cl)
            continue

        # Per-class propagated columns only — exclude DTW cost/window/pred fields.
        _excluded_dtw_cols = {"dtw_pred", "dtw_cost"}
        class_cols = [
            c for c in joined.columns
            if c.startswith("dtw_") and c not in _excluded_dtw_cols
        ]
        class_names = [c[len("dtw_"):] for c in class_cols]
        dtw_pred = np.array([class_names[i] for i in joined[class_cols].to_numpy().argmax(axis=1)])
        prob_pos = (joined[f"dtw_{positive_class}"].to_numpy()
                    if f"dtw_{positive_class}" in joined.columns else None)
        joined["dtw_pred"] = dtw_pred
        joined_by_cl[cl] = joined

        m = _binary_metrics(joined["gt"].to_numpy(), dtw_pred, prob_pos, positive_class)
        results.append({"fold": fold_label, "fold_kind": fold_kind, "cell_line": cl, "method": "DTW", **m})

        for K in ks:
            for variant in ("", "_multi", "_nn_fused"):
                pred_col = f"lc_K{K}{variant}_pred"
                prob_col = f"lc_K{K}{variant}_prob_pos"
                if pred_col not in joined.columns:
                    continue
                m = _binary_metrics(
                    joined["gt"].to_numpy(),
                    joined[pred_col].to_numpy(),
                    joined[prob_col].to_numpy() if prob_col in joined.columns else None,
                    positive_class,
                )
                method_name = f"LC_K{K}{variant}_joined"
                results.append({"fold": fold_label, "fold_kind": fold_kind, "cell_line": cl,
                                "method": method_name, **m})
    return results, joined_by_cl


def _emit_dtw_template_legend(template_by_dataset: dict[str, dict], cell_lines: list[str]) -> str:
    """Render the DTW template provenance legend.

    Lists each distinct (template_name, build_datasets, build_channel) used
    by the listed datasets, and notes which evaluation datasets were
    propagated from each template.
    """
    by_template: dict[tuple[str, str, str], list[str]] = {}
    for cl in cell_lines:
        tpl = template_by_dataset.get(cl, {})
        key = (
            tpl.get("name", "<unspecified>"),
            "+".join(tpl.get("build_datasets") or []) or "<unspecified>",
            tpl.get("build_channel", "<unspecified>"),
        )
        by_template.setdefault(key, []).append(cl)
    lines = ["_DTW templates used:_"]
    for (name, build_ds, build_ch), users in by_template.items():
        lines.append(
            f"- **{name}** (built on `{build_ds}`, channel `{build_ch}`) "
            f"→ propagated to: {', '.join(users)}"
        )
    return "\n".join(lines)


def _dtw_column_label(template_by_dataset: dict[str, dict], scope_datasets: list[str]) -> str:
    """Return the DTW column header for a table.

    When all rows in the table share one (template, build_datasets) pair,
    the column header embeds it. When templates differ across rows, the
    header stays bare and the per-section legend disambiguates.
    """
    keys = {
        (
            template_by_dataset.get(cl, {}).get("name", "<unspecified>"),
            "+".join(template_by_dataset.get(cl, {}).get("build_datasets") or []) or "<unspecified>",
        )
        for cl in scope_datasets
    }
    if len(keys) == 1:
        name, build = next(iter(keys))
        return f"DTW (template={name}; built on {build})"
    return "DTW"


def _emit_table(
    results: list[dict],
    cell_lines: list[str],
    ks: list[int],
    fold_kind: str,
    scope_label: str,
    title: str,
    template_by_dataset: dict[str, dict] | None = None,
) -> str:
    """Render a per-(cell line × metric) table for one fold_kind from results.

    Parameters
    ----------
    template_by_dataset : dict, optional
        Map of dataset name → {name, build_datasets, build_channel}. When
        supplied and all rows share one template, the DTW column header
        embeds the template name and build-dataset list.
    """
    sub = [r for r in results if r["fold_kind"] == fold_kind]
    if not sub:
        return ""
    df = pd.DataFrame(sub)
    pivot = df.pivot_table(index="cell_line", columns="method", values=["accuracy", "f1", "roc_auc"])
    dtw_label = (
        _dtw_column_label(template_by_dataset, cell_lines)
        if template_by_dataset is not None
        else "DTW"
    )
    nn_fused_cols = [f"LC_K{K}_nn_fused_joined" for K in ks if K == 7]
    methods = (
        [f"LC_K{K}_joined" for K in ks]
        + [f"LC_K{K}_multi_joined" for K in ks]
        + nn_fused_cols
        + ["DTW"]
    )
    headers = (
        [f"LC_K{K}_joined" for K in ks]
        + [f"LC_K{K}_multi_joined" for K in ks]
        + nn_fused_cols
        + [dtw_label]
    )
    lines = [f"## {title}", f"_Scope: {scope_label}_", "",
             "| cell line | metric | " + " | ".join(headers) + " |",
             "| " + " | ".join(["---"] * (len(headers) + 2)) + " |"]
    for cl in cell_lines:
        for metric in ["accuracy", "f1", "roc_auc"]:
            row = []
            for m in methods:
                v = pivot.get((metric, m), pd.Series(dtype=float)).get(cl, float("nan"))
                row.append(f"{v:.3f}" if pd.notna(v) else "n/a")
            lines.append(f"| {cl} | {metric} | " + " | ".join(row) + " |")
    return "\n".join(lines)


def _emit_cell_type_table(
    results: list[dict],
    ks: list[int],
    fold_kind: str,
    scope_label: str,
    title: str,
    template_by_dataset: dict[str, dict] | None = None,
    cell_type_by_dataset: dict[str, str] | None = None,
) -> str:
    """Aggregate over folds and datasets to render one row per cell_type.

    Each (cell_type, method, metric) cell is the **mean** across folds; the
    rendered string also includes the across-fold std in parentheses when
    n_folds > 1. When ``template_by_dataset`` + ``cell_type_by_dataset``
    are supplied and every cell type maps to a single template, the DTW
    column header embeds that template's provenance.
    """
    sub = [r for r in results if r["fold_kind"] == fold_kind and "cell_type" in r]
    if not sub:
        return ""
    df = pd.DataFrame(sub)
    cell_types = sorted(df["cell_type"].unique())
    if template_by_dataset is not None and cell_type_by_dataset is not None:
        keys = set()
        for cl, ct in cell_type_by_dataset.items():
            if ct in cell_types:
                tpl = template_by_dataset.get(cl, {})
                keys.add((
                    tpl.get("name", "<unspecified>"),
                    "+".join(tpl.get("build_datasets") or []) or "<unspecified>",
                ))
        dtw_label = (
            f"DTW (template={next(iter(keys))[0]}; built on {next(iter(keys))[1]})"
            if len(keys) == 1
            else "DTW"
        )
    else:
        dtw_label = "DTW"
    nn_fused_cols = [f"LC_K{K}_nn_fused_joined" for K in ks if K == 7]
    methods = (
        [f"LC_K{K}_joined" for K in ks]
        + [f"LC_K{K}_multi_joined" for K in ks]
        + nn_fused_cols
        + ["DTW"]
    )
    headers = (
        [f"LC_K{K}_joined" for K in ks]
        + [f"LC_K{K}_multi_joined" for K in ks]
        + nn_fused_cols
        + [dtw_label]
    )
    lines = [
        f"## {title}",
        f"_Scope: {scope_label}_",
        "",
        "| cell type | metric | " + " | ".join(headers) + " |",
        "| " + " | ".join(["---"] * (len(headers) + 2)) + " |",
    ]
    for ct in cell_types:
        sub_ct = df[df["cell_type"] == ct]
        for metric in ["accuracy", "f1", "roc_auc"]:
            row = []
            for m in methods:
                vals = sub_ct[sub_ct["method"] == m][metric].dropna()
                if vals.empty:
                    row.append("n/a")
                elif len(vals) == 1:
                    row.append(f"{vals.iloc[0]:.3f}")
                else:
                    row.append(f"{vals.mean():.3f} ± {vals.std(ddof=0):.3f}")
            lines.append(f"| {ct} | {metric} | " + " | ".join(row) + " |")
    return "\n".join(lines)


def main() -> None:
    """Run LOCO and stratified-80/20 evaluation from a YAML config; emit a combined report.

    The config schema is::

        task: cell_division_state
        positive_class: mitosis
        ks: [1, 3, 7]
        modes: [loco, stratified]   # subset of {loco, stratified}
        test_size: 0.2
        random_state: 42
        datasets:
          - name: U2OS
            embedding_zarr: /abs/path/...zarr
            dtw_alignment:  /abs/path/...parquet
            annotation_csv: /abs/path/...csv
          - name: ...
    """
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--config", type=Path, required=True, help="YAML config (see docstring)")
    parser.add_argument("--output-dir", type=Path, required=True)
    args = parser.parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)

    # Snapshot config + git revision into the output dir for reproducibility.
    import shutil
    import subprocess
    shutil.copy2(args.config, args.output_dir / args.config.name)
    try:
        repo_root = Path(__file__).resolve().parents[5]
        git_rev = subprocess.check_output(
            ["git", "-C", str(repo_root), "rev-parse", "HEAD"], text=True
        ).strip()
        git_status = subprocess.check_output(
            ["git", "-C", str(repo_root), "status", "--porcelain", "applications/dynaclr/scripts/pseudotime/5-eval"],
            text=True,
        ).strip()
        (args.output_dir / "run_info.txt").write_text(
            f"script: {Path(__file__).resolve()}\n"
            f"config: {args.config}\n"
            f"git_rev: {git_rev}\n"
            f"5-eval working-tree dirty: {bool(git_status)}\n"
            f"{git_status}\n"
        )
    except Exception as exc:  # noqa: BLE001
        _logger.warning("Could not capture git rev: %s", exc)

    cfg = _load_config_with_recipes(args.config)
    task = cfg["task"]
    positive_class = cfg["positive_class"]
    ks = sorted(set(cfg.get("ks", [1, 3, 7])))
    modes = cfg.get("modes", ["loco", "stratified"])
    test_size = float(cfg.get("test_size", 0.2))
    random_state = int(cfg.get("random_state", 42))

    datasets = cfg["datasets"]
    if len(datasets) < 1:
        raise ValueError("config must list at least one dataset")
    if "loco" in modes and len(datasets) < 2:
        _logger.warning("LOCO requested but only one dataset configured; skipping LOCO.")
        modes = [m for m in modes if m != "loco"]

    cell_lines = [d["name"] for d in datasets]
    dtw_path_by_cl = {d["name"]: Path(d["dtw_alignment"]) for d in datasets}
    annotation_by_dataset = {d["name"]: Path(d["annotation_csv"]) for d in datasets}
    cell_type_by_dataset = {d["name"]: d.get("cell_type", d["name"]) for d in datasets}
    template_by_dataset: dict[str, dict] = {}
    for d in datasets:
        tpl = d.get("dtw_template") or {}
        template_by_dataset[d["name"]] = {
            "name": tpl.get("name", "<unspecified>"),
            "build_datasets": list(tpl.get("build_datasets") or []),
            "build_channel": tpl.get("build_channel", "<unspecified>"),
        }

    _logger.info("Loading %d datasets (one-time embedding + window feature pass)", len(datasets))
    data: dict[str, CellLineData] = {}
    for d in datasets:
        data[d["name"]] = _load_dataset(
            d["name"],
            embedding_zarr=Path(d["embedding_zarr"]),
            annotation_csv=Path(d["annotation_csv"]),
            task=task,
            ks=ks,
        )

    all_labels = sorted({lbl for d in data.values() for lbl in d.obs["gt"].unique()})
    _logger.info("Labels seen across all datasets: %s", all_labels)
    if positive_class not in all_labels:
        raise ValueError(f"positive_class {positive_class!r} not in observed labels {all_labels}")

    # Optional template panel for LC_K{nn_fuse_k}_nn_fused (option 2 ablation).
    # Leaf YAML schema:
    #   template_panel:
    #     embedding_dir: /abs/path/.../embeddings          # build-dataset zarrs
    #     fuse_k: 7                                        # which K to fuse
    #     build_datasets:                                  # if absent, take from dtw_template
    #       - name: 2025_07_24_SEC61
    #         annotation_csv: /abs/.../combined_annotations.csv
    #         refined_track_ids: [["B/3/9/8", 91], ...]    # optional, restrict to refined tracks
    #       - name: 2025_07_24_G3BP1
    #         annotation_csv: /abs/.../combined_annotations.csv
    template_panel: TemplatePanel | None = None
    nn_fuse_k: int | None = None
    tpl_cfg = cfg.get("template_panel")
    if tpl_cfg is not None:
        tpl_embedding_dir = Path(tpl_cfg["embedding_dir"])
        nn_fuse_k = int(tpl_cfg.get("fuse_k", 7))
        if nn_fuse_k not in ks:
            raise ValueError(
                f"template_panel.fuse_k={nn_fuse_k} not in ks={ks}; "
                f"add it to the leaf's ks list"
            )
        build_entries = tpl_cfg.get("build_datasets")
        if build_entries is None:
            # Pull build dataset names from each dataset's dtw_template block;
            # require the roster to also expose their annotation_csv paths
            # via dataset entries whose `name` matches the build_dataset.
            build_names: list[str] = sorted({
                bd
                for d in datasets
                for bd in (d.get("dtw_template") or {}).get("build_datasets") or []
            })
            ann_by_bd = {d["name"]: Path(d["annotation_csv"]) for d in datasets}
            missing = [bn for bn in build_names if bn not in ann_by_bd]
            if missing:
                raise ValueError(
                    f"template_panel.build_datasets not listed in leaf and these "
                    f"dtw_template.build_datasets are not in the roster: {missing}. "
                    f"Either list them under `datasets:` or add an explicit "
                    f"`template_panel.build_datasets:` block."
                )
            build_names_list = build_names
            ann_csv_by_bd = ann_by_bd
            refined_ids_by_bd = None
        else:
            build_names_list = [e["name"] for e in build_entries]
            ann_csv_by_bd = {e["name"]: Path(e["annotation_csv"]) for e in build_entries}
            refined_ids_by_bd = {
                e["name"]: [(str(p[0]), int(p[1])) for p in e["refined_track_ids"]]
                for e in build_entries if "refined_track_ids" in e
            } or None
            zarr_fn_by_bd = {
                e["name"]: e["zarr_filename"]
                for e in build_entries if "zarr_filename" in e
            } or None
        template_panel = _load_template_panel(
            template_embedding_dir=tpl_embedding_dir,
            build_datasets=build_names_list,
            annotation_csv_by_build_dataset=ann_csv_by_bd,
            task=task,
            refined_track_ids=refined_ids_by_bd,
            zarr_filename_by_build_dataset=zarr_fn_by_bd if build_entries else None,
        )

    all_results: list[dict] = []
    folds_for_mode: dict[str, list] = {}

    if "loco" in modes:
        folds_for_mode["loco"] = _train_test_locos(data, cell_lines)
    if "stratified" in modes:
        folds_for_mode["stratified"] = _train_test_stratified(
            data, cell_lines, positive_class, test_size, random_state
        )
    if "per_cell_type" in modes:
        folds_for_mode["per_cell_type"] = _train_test_per_cell_type(
            data=data,
            dataset_names=cell_lines,
            cell_type_by_dataset=cell_type_by_dataset,
            alignment_by_dataset=dtw_path_by_cl,
            annotation_by_dataset=annotation_by_dataset,
            positive_class=positive_class,
            n_folds=int(cfg.get("n_folds", 5)),
            test_size=test_size,
            random_state=random_state,
        )

    for mode, folds in folds_for_mode.items():
        for fold_label, train_rows, test_rows in folds:
            _logger.info("=== mode=%s fold=%s ===", mode, fold_label)
            res, test_rows_by_cl = _train_eval_one_fold(
                fold_label, train_rows, test_rows, data, cell_lines, ks,
                positive_class, all_labels, fold_kind=mode,
                template_panel=template_panel, nn_fuse_k=nn_fuse_k,
            )
            for r in res:
                r["cell_type"] = cell_type_by_dataset.get(r["cell_line"], r["cell_line"])
            all_results.extend(res)
            for aligned_only in (False, True):
                scope_kind = f"{mode}_{'aligned' if aligned_only else 'all'}"
                dtw_res, joined_by_cl = _score_dtw_on_test_rows(
                    test_rows_by_cl, dtw_path_by_cl, task, cell_lines, ks,
                    positive_class, fold_label, scope_kind, aligned_only,
                )
                for r in dtw_res:
                    r["cell_type"] = cell_type_by_dataset.get(r["cell_line"], r["cell_line"])
                    tpl = template_by_dataset.get(r["cell_line"], {})
                    r["dtw_template_name"] = tpl.get("name", "")
                    r["dtw_template_build_datasets"] = "+".join(tpl.get("build_datasets") or [])
                    r["dtw_template_build_channel"] = tpl.get("build_channel", "")
                all_results.extend(dtw_res)
                if not aligned_only:
                    for cl, joined in joined_by_cl.items():
                        joined.to_parquet(
                            args.output_dir / f"per_frame_{mode}_{fold_label}_{cl}.parquet",
                            index=False,
                        )

    pd.DataFrame(all_results).to_csv(args.output_dir / "metrics.csv", index=False)

    # Wide-format aggregated CSV: one file per (mode, scope) crossing.
    # Rows = (cell_type/cell_line, metric); columns = methods.
    # For per_cell_type mode with k-fold, the cell.csv carries "mean ± std"
    # strings (publication-ready). For everything else, single value per cell.
    wide_dir = args.output_dir / "tables"
    wide_dir.mkdir(exist_ok=True)
    all_df = pd.DataFrame(all_results)
    metric_cols = ["accuracy", "precision", "recall", "f1", "roc_auc"]
    methods_order = (
        [f"LC_K{K}_joined" for K in ks]
        + [f"LC_K{K}_multi_joined" for K in ks]
        + [f"LC_K{K}_nn_fused_joined" for K in ks if K == 7]
        + ["DTW"]
    )
    for mode in modes:
        for aligned_only in (False, True):
            scope_kind = f"{mode}_{'aligned' if aligned_only else 'all'}"
            scope_label = "aligned" if aligned_only else "all"
            sub = all_df[all_df["fold_kind"] == scope_kind]
            if sub.empty:
                continue

            # Per-dataset wide table (each row = one dataset × metric, single value)
            def _wide(group_col: str, aggregate: bool) -> pd.DataFrame:
                """Pivot results to wide format, optionally aggregating across folds."""
                wide_rows: list[dict] = []
                for entity, sub2 in sub.groupby(group_col):
                    for metric in metric_cols:
                        row = {group_col: entity, "metric": metric}
                        for m in methods_order:
                            vals = sub2[sub2["method"] == m][metric].dropna()
                            if vals.empty:
                                row[m] = ""
                            elif aggregate and len(vals) > 1:
                                row[m] = f"{vals.mean():.4f} ± {vals.std(ddof=0):.4f}"
                                row[f"{m}_mean"] = float(vals.mean())
                                row[f"{m}_std"] = float(vals.std(ddof=0))
                                row[f"{m}_n_folds"] = int(len(vals))
                            else:
                                row[m] = f"{vals.iloc[0]:.4f}"
                                row[f"{m}_mean"] = float(vals.iloc[0])
                        wide_rows.append(row)
                return pd.DataFrame(wide_rows)

            wide_ds = _wide("cell_line", aggregate=False)
            # Tag each dataset row with the template that propagated its DTW labels.
            wide_ds["dtw_template_name"] = wide_ds["cell_line"].map(
                lambda cl: template_by_dataset.get(cl, {}).get("name", "")
            )
            wide_ds["dtw_template_build_datasets"] = wide_ds["cell_line"].map(
                lambda cl: "+".join(template_by_dataset.get(cl, {}).get("build_datasets") or [])
            )
            wide_ds["dtw_template_build_channel"] = wide_ds["cell_line"].map(
                lambda cl: template_by_dataset.get(cl, {}).get("build_channel", "")
            )
            wide_ds.to_csv(wide_dir / f"by_dataset__{mode}__{scope_label}.csv", index=False)
            if "cell_type" in sub.columns:
                wide_ct = _wide("cell_type", aggregate=(mode == "per_cell_type"))
                # For cell_type rows, list every (distinct) template feeding that cell type.
                ct_to_templates: dict[str, set[tuple[str, str, str]]] = {}
                for d in datasets:
                    ct = cell_type_by_dataset[d["name"]]
                    tpl = template_by_dataset[d["name"]]
                    ct_to_templates.setdefault(ct, set()).add(
                        (tpl["name"], "+".join(tpl["build_datasets"]), tpl["build_channel"])
                    )
                wide_ct["dtw_template_name"] = wide_ct["cell_type"].map(
                    lambda ct: "; ".join(sorted({t[0] for t in ct_to_templates.get(ct, set())}))
                )
                wide_ct["dtw_template_build_datasets"] = wide_ct["cell_type"].map(
                    lambda ct: "; ".join(sorted({t[1] for t in ct_to_templates.get(ct, set())}))
                )
                wide_ct["dtw_template_build_channel"] = wide_ct["cell_type"].map(
                    lambda ct: "; ".join(sorted({t[2] for t in ct_to_templates.get(ct, set())}))
                )
                wide_ct.to_csv(wide_dir / f"by_cell_type__{mode}__{scope_label}.csv", index=False)

    title = f"# Multi-frame LC vs DTW — {task} (positive={positive_class})"
    legend = _emit_dtw_template_legend(template_by_dataset, cell_lines)
    sections: list[str] = [title, "", f"_Config: `{args.config}`_", "", legend, ""]
    for mode in modes:
        for aligned_only in (False, True):
            scope_kind = f"{mode}_{'aligned' if aligned_only else 'all'}"
            scope_label = "aligned region only" if aligned_only else "annotation ∩ DTW alignment (all regions)"
            mode_label = {
                "loco": "Leave-one-dataset-out (LOCO)",
                "stratified": "Stratified 80/20 (track-level, by dataset × has_event)",
                "per_cell_type": "Per-cell-type (lineage-level k-fold for single-dataset cell types; "
                                 "track-level 80/20 for multi-dataset cell types)",
            }.get(mode, mode)
            if mode == "per_cell_type":
                # Cell-type summary first, then per-dataset breakdown
                sections.append(
                    _emit_cell_type_table(
                        all_results, ks, scope_kind,
                        scope_label=scope_label,
                        title=f"{mode_label} — by cell_type — {scope_label}",
                        template_by_dataset=template_by_dataset,
                        cell_type_by_dataset=cell_type_by_dataset,
                    )
                )
                sections.append("")
            sections.append(
                _emit_table(
                    all_results, cell_lines, ks, scope_kind,
                    scope_label=scope_label,
                    title=f"{mode_label} — by dataset — {scope_label}",
                    template_by_dataset=template_by_dataset,
                )
            )
            sections.append("")
    report = "\n".join(sections)
    print(report)
    (args.output_dir / "report.md").write_text(report)


if __name__ == "__main__":
    main()
