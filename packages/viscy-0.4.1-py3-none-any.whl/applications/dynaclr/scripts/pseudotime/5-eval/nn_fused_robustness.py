"""Robustness ablations for the template-anchored 1-NN LC fusion.

Reads the same leaf YAML as ``multi_frame_lc.py`` and the corresponding
per-frame parquets, then evaluates three additional variants of the
``LC_K{nn_fuse_k}_nn_fused`` method to check whether the headline result
(LC_K7_nn_fused beats DTW on Phase3D) is robust to overfit/leakage:

- ``LC_K{K}_nn1_fused``       — baseline 1-NN (matches the parquet column;
                                regenerated here for sanity).
- ``LC_K{K}_nn3_fused``       — 3-NN, average positive-class labels.
- ``LC_K{K}_nn1_xday_fused``  — 1-NN restricted to template tracks from
                                a DIFFERENT imaging day than the test cell.
                                Breaks the 07_24 self-match.
- ``LC_K{K}_nn1_rand_fused``  — 1 random template (uniform over candidates
                                with any wall-clock overlap). Tests whether
                                the lift came from the matching or just from
                                averaging in any per-frame label.

Writes ``nn_fused_robustness.csv`` to ``--output-dir`` with one row per
(fold, dataset, method, metric).

Usage:
    python nn_fused_robustness.py \\
      --config configs/<MODEL>/zikv_phase3d.yml \\
      --eval-output-dir out/<MODEL>/zikv_pool_phase3d_multi_nn \\
      --output-dir      out/<MODEL>/zikv_pool_phase3d_robustness
"""

from __future__ import annotations

import argparse
import logging
from pathlib import Path

import numpy as np
import pandas as pd

from multi_frame_lc import (
    _load_config_with_recipes,
    _load_template_panel,
    _nn_template_for_track_robust,
)

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
_logger = logging.getLogger("nn_robust")


def _binary_metrics(gt: np.ndarray, pred: np.ndarray, prob: np.ndarray, positive: str) -> dict[str, float]:
    """Subset of multi_frame_lc._binary_metrics (kept here to avoid the heavy import)."""
    from sklearn.metrics import accuracy_score, f1_score, precision_score, recall_score, roc_auc_score

    gt_bin = (gt == positive).astype(int)
    pred_bin = (pred == positive).astype(int)
    out = {
        "accuracy": float(accuracy_score(gt, pred)),
        "precision": float(precision_score(gt_bin, pred_bin, zero_division=0)),
        "recall": float(recall_score(gt_bin, pred_bin, zero_division=0)),
        "f1": float(f1_score(gt_bin, pred_bin, zero_division=0)),
    }
    if prob is not None and len(np.unique(gt_bin)) > 1:
        out["roc_auc"] = float(roc_auc_score(gt_bin, prob))
    else:
        out["roc_auc"] = float("nan")
    return out


def _fuse(p_lc: np.ndarray, label_matrix: np.ndarray, covered: np.ndarray, positive: str) -> np.ndarray:
    """Average positive-class binary labels across K templates; 50/50 with LC.

    Where no template covers, fall back to bare LC probability.
    """
    if label_matrix.shape[1] == 0:
        return p_lc
    pos_frac = np.where(
        covered,
        (label_matrix == positive).any(axis=1).astype(np.float64)
        if label_matrix.shape[1] == 1
        else (label_matrix == positive).mean(axis=1),
        np.nan,
    )
    return np.where(np.isnan(pos_frac), p_lc, 0.5 * p_lc + 0.5 * pos_frac)


def main() -> None:
    """Re-run the NN-fused ablation with 3 robustness variants on the same Phase3D inputs."""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, required=True, help="Same leaf YAML used by multi_frame_lc.py.")
    parser.add_argument(
        "--eval-output-dir", type=Path, required=True,
        help="Output dir of the original multi_frame_lc.py run; the per-frame parquets live here.",
    )
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--random-seed", type=int, default=42)
    args = parser.parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)

    cfg = _load_config_with_recipes(args.config)
    task = cfg["task"]
    positive_class = cfg["positive_class"]
    tpl_cfg = cfg["template_panel"]
    fuse_k = int(tpl_cfg.get("fuse_k", 7))

    # Build the panel exactly as main() does in multi_frame_lc.
    build_entries = tpl_cfg["build_datasets"]
    panel = _load_template_panel(
        template_embedding_dir=Path(tpl_cfg["embedding_dir"]),
        build_datasets=[e["name"] for e in build_entries],
        annotation_csv_by_build_dataset={e["name"]: Path(e["annotation_csv"]) for e in build_entries},
        task=task,
        refined_track_ids={
            e["name"]: [(str(p[0]), int(p[1])) for p in e["refined_track_ids"]]
            for e in build_entries if "refined_track_ids" in e
        } or None,
        zarr_filename_by_build_dataset={
            e["name"]: e["zarr_filename"]
            for e in build_entries if "zarr_filename" in e
        } or None,
    )

    # Imaging-day key: the build_dataset name's date prefix
    # (e.g. "2025_07_24_SEC61" → "2025_07_24"). For test cells we infer
    # from the dataset name in the roster ("07_24_ZIKV" → "2025_07_24").
    def _build_day(build_ds: str) -> str:
        parts = build_ds.split("_")
        return "_".join(parts[:3]) if len(parts) >= 3 else build_ds

    def _test_day(dataset_name: str) -> str:
        # Roster names look like "07_22_ZIKV" — map to "2025_07_22".
        # If the convention diverges, fall back to passing through.
        parts = dataset_name.split("_")
        if len(parts) >= 2 and parts[0].isdigit() and parts[1].isdigit():
            return f"2025_{parts[0]}_{parts[1]}"
        return dataset_name

    # Read the dataset roster so we can map dataset_name → embedding path
    # to load the test embeddings (we need them for the cosine match).
    datasets = cfg["datasets"]
    rng = np.random.default_rng(args.random_seed)

    rows: list[dict] = []
    for parquet_path in sorted(args.eval_output_dir.glob("per_frame_*.parquet")):
        _logger.info("processing %s", parquet_path.name)
        df = pd.read_parquet(parquet_path)
        # Identify the dataset this parquet belongs to. Filename pattern:
        # per_frame_<mode>_<fold>_<cell_line>.parquet
        stem = parquet_path.stem.removeprefix("per_frame_")
        # Split: <mode>_<fold>_<cell_line>; cell_line is one of the dataset
        # names in the roster.
        ds_name = next((d["name"] for d in datasets if stem.endswith(d["name"])), None)
        if ds_name is None:
            _logger.warning("could not identify dataset for %s; skipping", parquet_path.name)
            continue
        fold_label = stem[: -(len(ds_name) + 1)]
        mode = fold_label.split("_")[0]

        # Load test embeddings.
        ds_entry = next(d for d in datasets if d["name"] == ds_name)
        import anndata as ad
        a = ad.read_zarr(Path(ds_entry["embedding_zarr"]))
        obs = a.obs.copy().reset_index(drop=True)
        obs["track_id"] = obs["track_id"].astype(int)
        obs["t"] = obs["t"].astype(int)
        obs["_iloc"] = np.arange(len(obs))
        obs = obs.drop_duplicates(subset=["fov_name", "track_id", "t"]).reset_index(drop=True)
        X_all = a.X[obs["_iloc"].to_numpy()]
        if hasattr(X_all, "toarray"):
            X_all = X_all.toarray()
        obs = obs.drop(columns=["_iloc"])
        key_to_iloc = {(r.fov_name, int(r.track_id), int(r.t)): i for i, r in enumerate(obs.itertuples())}

        # Per-test-track inference: gather embeddings and frames in order.
        gt = df["gt"].to_numpy()
        p_lc = df["lc_K7_prob_pos"].to_numpy() if "lc_K7_prob_pos" in df.columns else None
        if p_lc is None:
            _logger.warning("no lc_K7_prob_pos column in %s; skipping", parquet_path.name)
            continue

        # We'll accumulate per-row fused probabilities for each variant.
        N = len(df)
        p_nn1 = np.copy(p_lc)
        p_nn3 = np.copy(p_lc)
        p_nn1_xday = np.copy(p_lc)
        p_nn1_rand = np.copy(p_lc)

        test_day = _test_day(ds_name)
        xday_predicate = lambda tpl: _build_day(tpl["build_dataset"]) == test_day

        df["_row"] = np.arange(N)
        for (fov, tid), grp in df.groupby(["fov_name", "track_id"]):
            grp_sorted = grp.sort_values("t")
            rows_idx = grp_sorted["_row"].to_numpy()
            ts = grp_sorted["t"].to_numpy().astype(int)
            ilocs = np.array([key_to_iloc.get((fov, int(tid), int(t)), -1) for t in ts])
            if (ilocs < 0).any():
                # Some frames not in the embedding zarr — drop them locally.
                keep = ilocs >= 0
                rows_idx = rows_idx[keep]
                ts = ts[keep]
                ilocs = ilocs[keep]
                if ilocs.size == 0:
                    continue
            test_emb = X_all[ilocs]

            # 1-NN baseline.
            _, _, lm1, cov1 = _nn_template_for_track_robust(test_emb, ts, panel, n_neighbors=1)
            p_lc_local = p_lc[rows_idx]
            p_nn1[rows_idx] = _fuse(p_lc_local, lm1, cov1, positive_class)

            # 3-NN.
            _, _, lm3, cov3 = _nn_template_for_track_robust(test_emb, ts, panel, n_neighbors=3)
            p_nn3[rows_idx] = _fuse(p_lc_local, lm3, cov3, positive_class)

            # 1-NN, exclude same-day templates.
            _, _, lmx, covx = _nn_template_for_track_robust(
                test_emb, ts, panel, n_neighbors=1, exclude_predicate=xday_predicate,
            )
            p_nn1_xday[rows_idx] = _fuse(p_lc_local, lmx, covx, positive_class)

            # 1-NN, random template.
            _, _, lmr, covr = _nn_template_for_track_robust(
                test_emb, ts, panel, n_neighbors=1, rng=rng,
            )
            p_nn1_rand[rows_idx] = _fuse(p_lc_local, lmr, covr, positive_class)

        neg_label = next(lbl for lbl in np.unique(gt) if lbl != positive_class)
        for name, p_v in [
            ("LC_K7_nn1_fused", p_nn1),
            ("LC_K7_nn3_fused", p_nn3),
            ("LC_K7_nn1_xday_fused", p_nn1_xday),
            ("LC_K7_nn1_rand_fused", p_nn1_rand),
        ]:
            pred_v = np.where(p_v >= 0.5, positive_class, neg_label)
            m = _binary_metrics(gt, pred_v, p_v, positive_class)
            for scope in ("all", "aligned"):
                if scope == "aligned":
                    if "alignment_region" not in df.columns:
                        continue
                    mask = df["alignment_region"].to_numpy() == "aligned"
                    if not mask.any():
                        continue
                    pred_s = pred_v[mask]
                    p_s = p_v[mask]
                    gt_s = gt[mask]
                    m_s = _binary_metrics(gt_s, pred_s, p_s, positive_class)
                else:
                    m_s = m
                rows.append({
                    "fold": fold_label, "fold_kind": f"{mode}_{scope}",
                    "cell_line": ds_name, "method": name, **m_s,
                })

    out_df = pd.DataFrame(rows)
    out_df.to_csv(args.output_dir / "nn_fused_robustness.csv", index=False)

    # Wide format: rows = (cell_line, metric, fold_kind); cols = methods.
    pivot = out_df.pivot_table(
        index=["fold_kind", "cell_line", "fold"],
        columns="method",
        values=["accuracy", "f1", "roc_auc"],
    )
    pivot.to_csv(args.output_dir / "nn_fused_robustness_wide.csv")
    _logger.info("wrote %s and %s", args.output_dir / "nn_fused_robustness.csv",
                 args.output_dir / "nn_fused_robustness_wide.csv")


if __name__ == "__main__":
    main()
