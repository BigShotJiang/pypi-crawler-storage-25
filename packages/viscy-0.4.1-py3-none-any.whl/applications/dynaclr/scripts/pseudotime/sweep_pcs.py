r"""Sweep PCA n_components for a template and compare alignment quality.

For each requested ``n_components``, rebuilds the chosen template with that PCA
dimensionality, runs Stage 2 alignment against a fixed query set, and collects
per-cell metrics. Produces a summary plot showing:

- Cost distribution vs n_components (boxplot)
- Number of tracks kept vs n_components
- Spearman rank correlation of PCA costs vs RAW costs — the sweet-spot indicator
- PCA explained-variance vs n_components

The point is to find the smallest n_components that matches RAW behaviour.

Usage::

    cd applications/dynaclr/scripts/pseudotime
    uv run python sweep_pcs.py \
        --datasets configs/pseudotime/datasets.yaml \
        --build-config configs/pseudotime/build_template.yaml \
        --align-config configs/pseudotime/align_cells.yaml \
        --template infection_nondividing_sensor \
        --query-set sensor_manual_debug_qset \
        --n-components 5,10,15,20,30,50 \
        --min-match-ratio 0.7 --max-skew 0.7
"""

from __future__ import annotations

import argparse
import copy
import logging
import subprocess
import sys
from pathlib import Path

import matplotlib
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import yaml

matplotlib.use("Agg")

SCRIPT_DIR = Path(__file__).resolve().parent
BUILD_DIR = SCRIPT_DIR / "1-build_template"
ALIGN_DIR = SCRIPT_DIR / "2-align_cells"
TEMPLATES_DIR = BUILD_DIR / "templates"
ALIGNMENTS_DIR = ALIGN_DIR / "alignments"
PLOTS_DIR = ALIGN_DIR / "plots"

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(levelname)s %(message)s")
_logger = logging.getLogger(__name__)


def _write_swept_build_config(
    original_build_yaml: Path,
    template_name: str,
    new_template_name: str,
    n_components: int,
    out_dir: Path,
) -> Path:
    """Materialize a build config where one template's n_components is overridden.

    Writes to ``out_dir / build_{new_template_name}.yaml``. Preserves the rest
    of the config verbatim. The swept template gets a synthetic name so each
    PC setting produces a distinct template zarr.
    """
    with open(original_build_yaml) as f:
        cfg = yaml.safe_load(f)

    if template_name not in cfg.get("templates", {}):
        raise KeyError(f"Template {template_name!r} not in {original_build_yaml}")
    template_cfg = copy.deepcopy(cfg["templates"][template_name])
    template_cfg.setdefault("preprocessing", {}).setdefault("pca", {})["n_components"] = int(n_components)
    cfg["templates"][new_template_name] = template_cfg

    out_dir.mkdir(parents=True, exist_ok=True)
    out_path = out_dir / f"build_{new_template_name}.yaml"
    with open(out_path, "w") as f:
        yaml.safe_dump(cfg, f, sort_keys=False)
    return out_path


def _run(cmd: list[str], cwd: Path) -> None:
    """Run a subprocess, capturing output and raising on failure."""
    _logger.info(f"$ {' '.join(cmd)}   (cwd={cwd})")
    result = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True)
    if result.returncode != 0:
        sys.stderr.write(result.stdout)
        sys.stderr.write(result.stderr)
        raise RuntimeError(f"command failed: {' '.join(cmd)}")


def _per_cell_metrics(parquet_path: Path) -> pd.DataFrame:
    """Reduce a Stage 2 alignment parquet to one row per cell with key metrics."""
    df = pd.read_parquet(parquet_path)
    return df.groupby(["dataset_id", "fov_name", "track_id"], as_index=False).agg(
        cost=("length_normalized_cost", "first"),
        path_skew=("path_skew", "first"),
        match_dur=("match_duration_minutes", "first"),
    )


def _plot_sweep(
    summary: pd.DataFrame,
    per_cell: dict[int, pd.DataFrame],
    raw_reference: pd.DataFrame | None,
    out_path: Path,
    template_name: str,
    query_set: str,
) -> None:
    """Render the 2×2 sweep-summary figure."""
    fig, axes = plt.subplots(2, 2, figsize=(12, 8))
    ax_hist = axes[0, 0]
    ax_kept = axes[0, 1]
    ax_corr = axes[1, 0]
    ax_var = axes[1, 1]

    n_list = sorted(per_cell)

    # (0,0) boxplot of costs per n_components
    data = [per_cell[n]["cost"].to_numpy() for n in n_list]
    ax_hist.boxplot(data, tick_labels=[str(n) for n in n_list], showfliers=False)
    ax_hist.set_xlabel("PCA n_components")
    ax_hist.set_ylabel("length-normalized DTW cost")
    ax_hist.set_title("Cost distribution (box = IQR, line = median)")

    # (0,1) n_tracks kept vs n_components
    ax_kept.plot(n_list, summary["n_tracks"], "o-", color="steelblue")
    ax_kept.set_xlabel("PCA n_components")
    ax_kept.set_ylabel("n query tracks kept")
    ax_kept.set_title("Tracks surviving guards vs n_components")
    ax_kept.grid(alpha=0.3)

    # (1,0) Spearman rank correlation to RAW (if available)
    if raw_reference is not None:
        corrs = []
        for n in n_list:
            pc = per_cell[n].set_index(["dataset_id", "fov_name", "track_id"])["cost"]
            raw = raw_reference.set_index(["dataset_id", "fov_name", "track_id"])["cost"]
            common = pc.index.intersection(raw.index)
            if len(common) < 3:
                corrs.append(np.nan)
            else:
                corrs.append(pc.loc[common].corr(raw.loc[common], method="spearman"))
        ax_corr.plot(n_list, corrs, "o-", color="darkgreen")
        ax_corr.set_ylim(-0.1, 1.05)
        ax_corr.axhline(1.0, color="grey", linestyle=":", alpha=0.5)
        ax_corr.set_xlabel("PCA n_components")
        ax_corr.set_ylabel("Spearman corr vs RAW 768-D")
        ax_corr.set_title("Rank agreement with RAW (1.0 = identical)")
        ax_corr.grid(alpha=0.3)
    else:
        ax_corr.text(
            0.5,
            0.5,
            "(RAW reference not available)",
            ha="center",
            va="center",
            transform=ax_corr.transAxes,
            fontsize=10,
            color="grey",
        )
        ax_corr.set_title("Rank agreement with RAW")

    # (1,1) PCA explained variance
    ax_var.plot(n_list, summary["explained_variance"] * 100.0, "o-", color="purple")
    ax_var.set_ylim(0, 105)
    ax_var.set_xlabel("PCA n_components")
    ax_var.set_ylabel("explained variance (%)")
    ax_var.set_title("PCA explained variance")
    ax_var.grid(alpha=0.3)

    fig.suptitle(f"PCA sweep — {template_name} on {query_set}", fontsize=12)
    fig.tight_layout(rect=(0, 0, 1, 0.97))
    fig.savefig(out_path, dpi=150, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    _logger.info(f"Wrote {out_path}")


def main() -> None:
    """Sweep PCA n_components for a template and write a summary plot."""
    parser = argparse.ArgumentParser(description="Sweep PCA n_components and compare alignment quality")
    parser.add_argument("--datasets", required=True, help="Path to datasets.yaml")
    parser.add_argument("--build-config", required=True, help="Path to build_template.yaml")
    parser.add_argument("--align-config", required=True, help="Path to align_cells.yaml")
    parser.add_argument("--template", required=True, help="Base template name (the one whose n_components to sweep)")
    parser.add_argument("--query-set", required=True)
    parser.add_argument(
        "--n-components",
        required=True,
        help="Comma-separated n_components values to sweep, e.g. '5,10,20,50'",
    )
    parser.add_argument("--min-match-ratio", type=float, default=0.5)
    parser.add_argument("--max-skew", type=float, default=0.8)
    parser.add_argument(
        "--include-raw",
        action="store_true",
        default=True,
        help="Also build+align with the RAW 768-D flavor for a reference line (default: on)",
    )
    args = parser.parse_args()

    n_list = [int(x) for x in args.n_components.split(",") if x.strip()]
    _logger.info(f"Sweeping n_components = {n_list} for template {args.template!r}")

    swept_cfg_dir = SCRIPT_DIR / "_sweep_configs"
    per_cell: dict[int, pd.DataFrame] = {}
    summary_rows: list[dict] = []

    for n in n_list:
        swept_name = f"{args.template}_pc{n}"
        _logger.info(f"=== n_components={n} → template {swept_name} ===")

        swept_cfg = _write_swept_build_config(
            Path(args.build_config),
            template_name=args.template,
            new_template_name=swept_name,
            n_components=n,
            out_dir=swept_cfg_dir,
        )

        # Build (produces template_{swept_name}.zarr with both flavors)
        _run(
            [
                "uv",
                "run",
                "python",
                "build_template.py",
                "--datasets",
                str(Path(args.datasets).resolve()),
                "--config",
                str(swept_cfg.resolve()),
                "--template",
                swept_name,
            ],
            cwd=BUILD_DIR,
        )

        # Align PCA flavor (the one we're sweeping)
        _run(
            [
                "uv",
                "run",
                "python",
                "align_cells.py",
                "--datasets",
                str(Path(args.datasets).resolve()),
                "--config",
                str(Path(args.align_config).resolve()),
                "--template",
                swept_name,
                "--flavor",
                "pca",
                "--query-set",
                args.query_set,
                "--min-match-ratio",
                str(args.min_match_ratio),
                "--max-skew",
                str(args.max_skew),
            ],
            cwd=ALIGN_DIR,
        )

        parquet = ALIGNMENTS_DIR / f"{swept_name}_pca_on_{args.query_set}.parquet"
        cells = _per_cell_metrics(parquet)
        per_cell[n] = cells

        # Explained variance — read from the template zarr via the library helper.
        from dynaclr.pseudotime import load_template_flavor

        result, _attrs = load_template_flavor(TEMPLATES_DIR / f"template_{swept_name}.zarr", "pca")
        attrs = {
            "n_components": int(result.pca.n_components_) if result.pca is not None else 0,
            "explained_variance": float(result.explained_variance or 0.0),
        }
        summary_rows.append(
            {
                "n_components": n,
                "n_tracks": len(cells),
                "cost_p50": cells["cost"].median(),
                "cost_p90": cells["cost"].quantile(0.9),
                "skew_p50": cells["path_skew"].median(),
                "explained_variance": attrs.get("explained_variance", 0.0),
            }
        )

    summary = pd.DataFrame(summary_rows).sort_values("n_components").reset_index(drop=True)

    raw_reference: pd.DataFrame | None = None
    if args.include_raw:
        # Use the base template's raw flavor as the reference — build it once if
        # it's not already present.
        base_raw_parquet = ALIGNMENTS_DIR / f"{args.template}_raw_on_{args.query_set}.parquet"
        if not base_raw_parquet.exists():
            _logger.info(f"Building {args.template}/raw for reference alignment")
            _run(
                [
                    "uv",
                    "run",
                    "python",
                    "build_template.py",
                    "--datasets",
                    str(Path(args.datasets).resolve()),
                    "--config",
                    str(Path(args.build_config).resolve()),
                    "--template",
                    args.template,
                ],
                cwd=BUILD_DIR,
            )
            _run(
                [
                    "uv",
                    "run",
                    "python",
                    "align_cells.py",
                    "--datasets",
                    str(Path(args.datasets).resolve()),
                    "--config",
                    str(Path(args.align_config).resolve()),
                    "--template",
                    args.template,
                    "--flavor",
                    "raw",
                    "--query-set",
                    args.query_set,
                    "--min-match-ratio",
                    str(args.min_match_ratio),
                    "--max-skew",
                    str(args.max_skew),
                ],
                cwd=ALIGN_DIR,
            )
        raw_reference = _per_cell_metrics(base_raw_parquet)
        _logger.info(f"RAW reference: {len(raw_reference)} cells, cost p50={raw_reference['cost'].median():.3f}")

    PLOTS_DIR.mkdir(parents=True, exist_ok=True)
    out_path = PLOTS_DIR / f"pca_sweep_{args.template}_{args.query_set}.png"
    _plot_sweep(summary, per_cell, raw_reference, out_path, args.template, args.query_set)

    # Append the RAW reference as a final row so the sidecar table is standalone.
    table = summary.copy()
    table["explained_variance_%"] = (table["explained_variance"] * 100).round(1)
    table = table.drop(columns=["explained_variance"])
    table = table.round({"cost_p50": 3, "cost_p90": 3, "skew_p50": 3})
    table["n_components"] = table["n_components"].astype(str)
    if raw_reference is not None:
        raw_row = pd.DataFrame(
            [
                {
                    "n_components": "RAW-768",
                    "n_tracks": len(raw_reference),
                    "cost_p50": round(raw_reference["cost"].median(), 3),
                    "cost_p90": round(raw_reference["cost"].quantile(0.9), 3),
                    "skew_p50": round(raw_reference["path_skew"].median(), 3),
                    "explained_variance_%": 100.0,
                }
            ]
        )
        table = pd.concat([table, raw_row], ignore_index=True)

    md_path = PLOTS_DIR / f"pca_sweep_{args.template}_{args.query_set}.md"
    md_lines = [
        f"# PCA sweep — {args.template} on {args.query_set}",
        "",
        f"Guards: `min_match_ratio={args.min_match_ratio}`, `max_skew={args.max_skew}`",
        "",
        table.to_markdown(index=False),
        "",
    ]
    md_path.write_text("\n".join(md_lines))
    _logger.info(f"Wrote {md_path}")
    _logger.info("\n=== PCA sweep summary ===\n" + table.to_markdown(index=False))


if __name__ == "__main__":
    main()
