"""Shared utilities for the pseudotime pipeline scripts."""

from __future__ import annotations

from pathlib import Path
from typing import Literal

import yaml

Level = Literal["dataset", "fov", "timepoint"]


def load_stage_config(datasets_path: str | Path, stage_config_path: str | Path) -> dict:
    """Load and merge the shared datasets config with a stage-specific config.

    Each stage script takes two configs: ``datasets.yaml`` (shared infra —
    datasets, embedding patterns, data_zarr) and a stage-specific file
    (``build_template.yaml``, ``align_cells.yaml``, ...). They are shallow-merged
    with the stage config winning on conflict.

    Parameters
    ----------
    datasets_path : str or Path
        Path to ``datasets.yaml``.
    stage_config_path : str or Path
        Path to the stage-specific config (e.g. ``build_template.yaml``).

    Returns
    -------
    dict
        Merged config ready for the stage script to consume.
    """
    with open(datasets_path) as f:
        base = yaml.safe_load(f) or {}
    with open(stage_config_path) as f:
        stage = yaml.safe_load(f) or {}
    merged = {**base, **stage}
    return merged


def read_focus_slice(
    handle,
    channel_name: str,
    level: Level = "fov",
    timepoint: int | None = None,
):
    """Read ``focus_slice`` metadata for a channel from an ome-zarr handle.

    The ``focus_slice`` attribute is written by ``viscy preprocess`` into
    each FOV's ``.zattrs`` under the schema::

        focus_slice:
          <channel_name>:
            fov_statistics:
              z_focus_mean: <float>
            per_timepoint:
              "<t>": <int>

    Parameters
    ----------
    handle : iohub.ngff.Plate or iohub.ngff.Position
        Open ome-zarr handle. Must be a ``Plate`` when ``level='dataset'``
        and a ``Position`` when ``level='fov'`` or ``level='timepoint'``.
    channel_name : str
        Channel under which ``focus_slice`` was stored
        (e.g. ``"Phase3D"`` or ``"mCherry"``).
    level : {'dataset', 'fov', 'timepoint'}
        Granularity to return:

        - ``'dataset'``: mean of each FOV's ``z_focus_mean`` across the
          plate. Requires a ``Plate`` handle.
        - ``'fov'``: this position's ``z_focus_mean``.
        - ``'timepoint'``: dict ``{t: z}`` from ``per_timepoint``.
          If ``timepoint`` is given, returns a single ``int`` (falls back
          to ``z_focus_mean`` when the timepoint is absent).
    timepoint : int or None
        Specific timepoint to look up when ``level='timepoint'``.

    Returns
    -------
    int or float or dict[int, int]
        Depends on ``level``.
    """
    if level == "dataset":
        values = []
        for _, position in handle.positions():
            ch = position.zattrs.get("focus_slice", {}).get(channel_name, {})
            z = ch.get("fov_statistics", {}).get("z_focus_mean")
            if z is not None:
                values.append(float(z))
        if not values:
            raise KeyError(f"No z_focus_mean found for channel '{channel_name}' in plate")
        return sum(values) / len(values)

    ch = handle.zattrs.get("focus_slice", {}).get(channel_name, {})

    if level == "fov":
        z = ch.get("fov_statistics", {}).get("z_focus_mean")
        if z is None:
            raise KeyError(f"No fov-level z_focus_mean for channel '{channel_name}'")
        return int(round(float(z)))

    if level == "timepoint":
        per_t_raw = ch.get("per_timepoint", {})
        per_t = {int(k): int(round(float(v))) for k, v in per_t_raw.items() if v is not None}
        if timepoint is None:
            return per_t
        if timepoint in per_t:
            return per_t[timepoint]
        fallback = ch.get("fov_statistics", {}).get("z_focus_mean")
        if fallback is None:
            raise KeyError(
                f"No focus z for channel '{channel_name}' at t={timepoint} "
                f"(per_timepoint missing and no z_focus_mean fallback)"
            )
        return int(round(float(fallback)))
