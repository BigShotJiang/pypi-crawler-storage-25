"""Diagnostic PC plot: unaligned vs aligned embeddings over time.

Stage 3 of the pseudotime pipeline. Reads the alignment parquet from
:mod:`evaluate_template`, pulls the raw 768-D embeddings of the aligned
cells from the channel's zarr, fits a **post-hoc** PCA on those
embeddings (independent of whether Stage 1 used a PCA flavor), and
renders a side-by-side grid:

- **Left column (unaligned):** PC vs ``t_relative_minutes`` (each cell
  anchored on its own ``t_key_event``).
- **Right column (aligned):**  PC vs ``estimated_t_rel_minutes``
  (pseudotime mapped back to minutes via the template's
  ``time_calibration``).

If DTW works, the right column should collapse the traces that scatter
in the left column onto a shared curve.

Usage::

    cd applications/dynaclr/scripts/pseudotime/1-build_template
    uv run python plot_pcs.py \
        --datasets ../../../configs/pseudotime/datasets.yaml \
        --config ../../../configs/pseudotime/build_template.yaml \
        --template manual_debug_sensor \
        --flavor raw
"""

from __future__ import annotations

import argparse
import logging
import sys
from pathlib import Path

import anndata as ad
import matplotlib
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.decomposition import PCA

from dynaclr.pseudotime import (
    date_prefix_from_dataset_id,
    find_embedding_zarr,
    read_time_calibration,
)
from dynaclr.pseudotime.io import load_template_flavor as _load_template_flavor  # noqa: F401

matplotlib.use("Agg")

SCRIPT_DIR = Path(__file__).resolve().parent
TEMPLATES_DIR = SCRIPT_DIR / "templates"
ALIGNMENTS_DIR = SCRIPT_DIR / "alignments"
PLOTS_DIR = SCRIPT_DIR / "plots"
CANDIDATES_DIR = SCRIPT_DIR.parent / "0-select_candidates" / "candidates"

sys.path.insert(0, str(SCRIPT_DIR.parent))
from utils import load_stage_config  # noqa: E402

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(levelname)s %(message)s")
_logger = logging.getLogger(__name__)


def _collect_embeddings(
    alignments: pd.DataFrame,
    dataset_cfgs: dict[str, dict],
    embedding_pattern: str,
) -> pd.DataFrame:
    """Attach the raw 768-D embedding vector to each row of the alignment parquet.

    Returns a DataFrame with the original alignment columns plus an
    ``embedding`` column (each value an ``np.ndarray`` of shape (D,)).
    """
    parts = []
    for dataset_id, ds_align in alignments.groupby("dataset_id"):
        ds_cfg = dataset_cfgs[dataset_id]
        prefix = date_prefix_from_dataset_id(dataset_id)
        zarr_path = find_embedding_zarr(ds_cfg["pred_dir"], prefix + embedding_pattern)
        _logger.info(f"  [{dataset_id}] loading {Path(zarr_path).name}")
        adata = ad.read_zarr(zarr_path)
        adata.obs_names_make_unique()

        X = adata.X
        if hasattr(X, "toarray"):
            X = X.toarray()
        X = np.asarray(X, dtype=np.float64)

        obs = adata.obs.reset_index(drop=True)
        lookup: dict[tuple[str, int, int], int] = {
            (str(row["fov_name"]), int(row["track_id"]), int(row["t"])): i for i, row in obs.iterrows()
        }

        aligned_rows = ds_align.reset_index(drop=True).copy()
        embeddings = []
        for _, row in aligned_rows.iterrows():
            key = (str(row["fov_name"]), int(row["track_id"]), int(row["t"]))
            idx = lookup.get(key)
            if idx is None:
                raise KeyError(f"(fov_name, track_id, t) {key} not in embedding zarr")
            embeddings.append(X[idx])
        aligned_rows["embedding"] = embeddings
        parts.append(aligned_rows)

    return pd.concat(parts, ignore_index=True)


def _load_template_label(
    template_path: Path,
    flavor: str,
    label_col: str,
    class_value: str,
):
    """Return (positions_in_minutes, fraction) for one class of one label column.

    ``template_labels`` is multiclass ``{col: {class: (T,)}}``. The caller
    picks which class's fraction curve to plot. Returns ``(None, None)`` if
    the column, class, or time calibration is missing.
    """
    result, _attrs = _load_template_flavor(template_path, flavor)
    if result.template_labels is None or label_col not in result.template_labels:
        return None, None
    class_dict = result.template_labels[label_col]
    if class_value not in class_dict:
        return None, None
    if result.time_calibration is None:
        return None, None
    return read_time_calibration(template_path, flavor), class_dict[class_value]


def _scatter_with_bins(
    ax,
    x: np.ndarray,
    y: np.ndarray,
    cells: np.ndarray,
    n_bins: int = 12,
) -> None:
    """Scatter colored by cell + binned median ± IQR overlay."""
    unique_cells = np.unique(cells)
    cmap = plt.get_cmap("tab10")
    for i, cell in enumerate(unique_cells):
        mask = cells == cell
        ax.scatter(
            x[mask],
            y[mask],
            s=20,
            color=cmap(i % 10),
            alpha=0.65,
            edgecolors="none",
            label=str(cell).split("/")[-1],
        )

    if len(x) >= 6:
        lo, hi = float(np.nanmin(x)), float(np.nanmax(x))
        edges = np.linspace(lo, hi, n_bins + 1)
        centers = 0.5 * (edges[:-1] + edges[1:])
        med, q25, q75 = (np.full(n_bins, np.nan) for _ in range(3))
        for b in range(n_bins):
            in_bin = (x >= edges[b]) & (x < edges[b + 1])
            if in_bin.sum() >= 3:
                v = y[in_bin]
                med[b] = np.median(v)
                q25[b] = np.percentile(v, 25)
                q75[b] = np.percentile(v, 75)
        ok = np.isfinite(med)
        if ok.any():
            ax.plot(centers[ok], med[ok], color="black", linewidth=2.0, zorder=5)
            ax.fill_between(centers[ok], q25[ok], q75[ok], color="black", alpha=0.15, zorder=4)


def main() -> None:
    """Render the unaligned-vs-aligned PC grid."""
    parser = argparse.ArgumentParser(description="Plot PCs vs time (Stage 1a diagnostic)")
    parser.add_argument("--datasets", required=True, help="Path to datasets.yaml (shared infra config)")
    parser.add_argument("--config", required=True, help="Path to build_template.yaml")
    parser.add_argument("--template", required=True, help="Template name")
    parser.add_argument("--flavor", choices=["raw", "pca"], default="raw")
    parser.add_argument("--n-pcs", type=int, default=4, help="Number of PCs to plot")
    parser.add_argument("--n-bins", type=int, default=12, help="Bins for median/IQR")
    args = parser.parse_args()

    config = load_stage_config(args.datasets, args.config)

    template_cfg = config["templates"][args.template]
    channel = template_cfg["channel"]
    anchor_label = template_cfg["anchor_label"]
    anchor_positive = template_cfg["anchor_positive"]
    label_col = anchor_label  # the label whose fraction we overlay
    label_class = anchor_positive  # which class within label_col to plot

    template_path = TEMPLATES_DIR / f"template_{args.template}.zarr"
    alignments_path = ALIGNMENTS_DIR / f"template_alignments_{args.template}_{args.flavor}.parquet"
    if not alignments_path.exists():
        raise FileNotFoundError(f"Alignments parquet not found: {alignments_path}")

    _logger.info(f"Reading {alignments_path}")
    alignments = pd.read_parquet(alignments_path)

    embedding_pattern = config["embeddings"][channel]
    dataset_cfgs = {d["dataset_id"]: d for d in config["datasets"]}

    _logger.info("Collecting raw embeddings for aligned cells")
    joined = _collect_embeddings(alignments, dataset_cfgs, embedding_pattern)

    # Post-hoc PCA: fit on all aligned cells' raw embeddings (fresh, not the build-time PCA)
    X = np.stack(joined["embedding"].to_list())
    n_pcs = min(args.n_pcs, X.shape[0], X.shape[1])
    _logger.info(f"Fitting post-hoc PCA ({n_pcs} components) on {X.shape[0]} rows")
    pca = PCA(n_components=n_pcs)
    pcs = pca.fit_transform(X)
    for i in range(n_pcs):
        joined[f"pc_{i + 1}"] = pcs[:, i]

    cell_ids = joined["cell_uid"].to_numpy()
    t_rel = joined["t_relative_minutes"].to_numpy(dtype=float)
    t_aligned = joined["estimated_t_rel_minutes"].to_numpy(dtype=float)

    # Template label overlay (optional bottom row)
    tmpl_x, tmpl_frac = _load_template_label(template_path, args.flavor, label_col, label_class)
    has_label_row = tmpl_frac is not None

    n_rows = n_pcs + (1 if has_label_row else 0)
    fig, axes = plt.subplots(
        n_rows,
        2,
        figsize=(10, 2.4 * n_rows),
        sharex="col",
        squeeze=False,
    )

    for i in range(n_pcs):
        y = joined[f"pc_{i + 1}"].to_numpy()
        evr = pca.explained_variance_ratio_[i] * 100.0

        ax_l = axes[i, 0]
        _scatter_with_bins(ax_l, t_rel, y, cell_ids, n_bins=args.n_bins)
        ax_l.axvline(0, color="red", linestyle=":", alpha=0.5, linewidth=1.0)
        ax_l.set_ylabel(f"PC{i + 1} ({evr:.1f}%)")
        if i == 0:
            ax_l.set_title("Unaligned (t_relative_minutes)")
            ax_l.legend(fontsize=7, markerscale=0.6, loc="best", frameon=False)

        ax_r = axes[i, 1]
        _scatter_with_bins(ax_r, t_aligned, y, cell_ids, n_bins=args.n_bins)
        ax_r.axvline(0, color="red", linestyle=":", alpha=0.5, linewidth=1.0)
        if i == 0:
            ax_r.set_title("Aligned (estimated_t_rel_minutes via time_calibration)")

    if has_label_row:
        ax_l = axes[-1, 0]
        ax_r = axes[-1, 1]
        # Both panels use the SAME per-cell true annotation. The only
        # difference is the time axis: left bins by each cell's own
        # t_relative_minutes (anchored at its annotated t_key_event — a
        # definitional step at 0), right bins by the DTW-warped
        # estimated_t_rel_minutes. Honest comparison: if DTW is doing real
        # work, the right curve should be at least as sharp as the left.
        # The template's stored DBA-averaged label fraction is overlaid as
        # a dashed grey secondary reference (NOT primary evidence).
        anchor_positive = template_cfg["anchor_positive"]
        cand_set_name = template_cfg["candidate_set"]
        cand_csv = CANDIDATES_DIR / f"{cand_set_name}_annotations.csv"
        ann_j = None
        if cand_csv.exists():
            ann = pd.read_csv(cand_csv)
            ann = ann.dropna(subset=[anchor_label])
            ann["is_positive"] = (ann[anchor_label] == anchor_positive).astype(float)
            on_cols = ["dataset_id", "fov_name", "track_id", "t"]
            ann_j = ann[on_cols + ["is_positive"]].merge(
                alignments[on_cols + ["t_relative_minutes", "estimated_t_rel_minutes"]],
                on=on_cols,
                how="inner",
            )

        def _binned_fraction(x: np.ndarray, y: np.ndarray, n_bins: int):
            mask = np.isfinite(x) & np.isfinite(y)
            x, y = x[mask], y[mask]
            if len(x) < 6:
                return None, None
            lo, hi = float(np.nanmin(x)), float(np.nanmax(x))
            if not np.isfinite(lo) or not np.isfinite(hi) or lo == hi:
                return None, None
            edges = np.linspace(lo, hi, n_bins + 1)
            centers = 0.5 * (edges[:-1] + edges[1:])
            frac = np.full(n_bins, np.nan)
            for b in range(n_bins):
                in_bin = (x >= edges[b]) & (x < edges[b + 1])
                if in_bin.sum() > 0:
                    frac[b] = np.nanmean(y[in_bin])
            return centers, frac

        if ann_j is not None and len(ann_j) > 0:
            # Left panel: per-cell true annotation binned by each cell's own t_relative_minutes
            x_l = ann_j["t_relative_minutes"].to_numpy(dtype=float)
            y_l = ann_j["is_positive"].to_numpy(dtype=float)
            centers_l, frac_l = _binned_fraction(x_l, y_l, args.n_bins)
            if centers_l is not None:
                ok = np.isfinite(frac_l)
                ax_l.plot(centers_l[ok], frac_l[ok], color="#c0392b", linewidth=2, label="per-cell truth")
                ax_l.fill_between(centers_l[ok], 0, frac_l[ok], color="#c0392b", alpha=0.3)

            # Right panel: SAME per-cell true annotation binned by DTW-warped estimated_t_rel_minutes
            x_r = ann_j["estimated_t_rel_minutes"].to_numpy(dtype=float)
            y_r = ann_j["is_positive"].to_numpy(dtype=float)
            centers_r, frac_r = _binned_fraction(x_r, y_r, args.n_bins)
            if centers_r is not None:
                ok = np.isfinite(frac_r)
                ax_r.plot(centers_r[ok], frac_r[ok], color="#c0392b", linewidth=2, label="per-cell truth")
                ax_r.fill_between(centers_r[ok], 0, frac_r[ok], color="#c0392b", alpha=0.3)

        # Template DBA-averaged label fraction as secondary reference (right panel only).
        if tmpl_x is not None and tmpl_frac is not None:
            ax_r.plot(
                tmpl_x,
                tmpl_frac,
                color="grey",
                linewidth=1.5,
                linestyle="--",
                label="template DBA fraction",
            )

        ax_l.set_ylim(-0.05, 1.05)
        ax_l.axvline(0, color="red", linestyle=":", alpha=0.5, linewidth=1.0)
        ax_l.set_ylabel(f"{label_col}\nfraction (per-cell truth)")
        ax_l.set_xlabel("t_relative_minutes")
        ax_l.legend(fontsize=7, loc="best", frameon=False)

        ax_r.set_ylim(-0.05, 1.05)
        ax_r.axvline(0, color="red", linestyle=":", alpha=0.5, linewidth=1.0)
        ax_r.set_xlabel("estimated_t_rel_minutes")
        ax_r.legend(fontsize=7, loc="best", frameon=False)

    fig.suptitle(
        f"{args.template} [{args.flavor}] — unaligned vs aligned ({X.shape[0]} rows, {len(np.unique(cell_ids))} cells)",
        fontsize=11,
    )
    fig.tight_layout(rect=(0, 0, 1, 0.97))

    PLOTS_DIR.mkdir(parents=True, exist_ok=True)
    out_path = PLOTS_DIR / f"pcs_over_pseudotime_{args.template}_{args.flavor}.png"
    fig.savefig(out_path, dpi=160, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    _logger.info(f"Wrote {out_path}")


if __name__ == "__main__":
    main()
