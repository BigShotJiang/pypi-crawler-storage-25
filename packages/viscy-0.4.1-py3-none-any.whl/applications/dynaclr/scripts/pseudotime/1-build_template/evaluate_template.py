r"""Self-align the template cells back to the template.

Stage 2 of the pseudotime pipeline. Loads the two-flavor template zarr
produced by :mod:`build_template`, reconstructs a single-flavor
``TemplateResult`` (either ``raw/`` or ``pca/``), and DTW-aligns the
same cells that were used to build the template. Writes one parquet of
per-(cell, frame) pseudotime / dtw_cost / estimated_t_rel_minutes rows.

This is a self-consistency check: in theory, each cell should warp
cleanly onto the template it helped build.

Usage::

    cd applications/dynaclr/scripts/pseudotime/1-build_template
    uv run python evaluate_template.py \\
        --datasets ../../../configs/pseudotime/datasets.yaml \\
        --config ../../../configs/pseudotime/build_template.yaml \\
        --template manual_debug_sensor \\
        --flavor raw
"""

from __future__ import annotations

import argparse
import logging
import sys
from pathlib import Path

import anndata as ad
import numpy as np
import pandas as pd

from dynaclr.pseudotime import (
    alignment_results_to_dataframe,
    date_prefix_from_dataset_id,
    dtw_align_tracks,
    find_embedding_zarr,
    load_template_flavor,
)

SCRIPT_DIR = Path(__file__).resolve().parent
CANDIDATES_DIR = SCRIPT_DIR.parent / "0-select_candidates" / "candidates"
TEMPLATES_DIR = SCRIPT_DIR / "templates"
OUTPUT_ALIGNMENTS_DIR = SCRIPT_DIR / "alignments"

sys.path.insert(0, str(SCRIPT_DIR.parent))
from utils import load_stage_config  # noqa: E402

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(levelname)s %(message)s")
_logger = logging.getLogger(__name__)


def _prepare_dataset_inputs(
    ann_df: pd.DataFrame,
    dataset_cfgs: dict[str, dict],
    embedding_pattern: str,
    anchor_label: str,
    anchor_positive: str,
) -> tuple[dict[str, ad.AnnData], dict[str, pd.DataFrame]]:
    """Build per-dataset ``adata`` + ``aligned_df`` dicts from the CSV."""
    adata_dict: dict[str, ad.AnnData] = {}
    df_dict: dict[str, pd.DataFrame] = {}

    for dataset_id, sub in ann_df.groupby("dataset_id"):
        ds_cfg = dataset_cfgs[dataset_id]
        prefix = date_prefix_from_dataset_id(dataset_id)
        zarr_path = find_embedding_zarr(ds_cfg["pred_dir"], prefix + embedding_pattern)

        adata = ad.read_zarr(zarr_path)
        adata.obs_names_make_unique()

        keys_wanted = set(
            zip(
                sub["fov_name"].astype(str),
                sub["track_id"].astype(int),
                sub["t"].astype(int),
            )
        )
        mask = [
            (str(f), int(tid), int(t)) in keys_wanted
            for f, tid, t in zip(adata.obs["fov_name"], adata.obs["track_id"], adata.obs["t"])
        ]
        adata = adata[np.asarray(mask)].copy()
        if len(adata) == 0:
            raise ValueError(f"No adata rows match the CSV for dataset {dataset_id}")

        pos = sub[sub[anchor_label] == anchor_positive]
        t_perturb = pos.groupby(["dataset_id", "fov_name", "track_id"])["t"].min().rename("t_perturb").reset_index()
        sub = sub.merge(t_perturb, on=["dataset_id", "fov_name", "track_id"], how="inner")
        sub["t_relative_minutes"] = (sub["t"] - sub["t_perturb"]) * ds_cfg["frame_interval_minutes"]

        adata_dict[dataset_id] = adata
        df_dict[dataset_id] = sub
        _logger.info(f"  [{dataset_id}] {adata.n_obs} rows, {sub.groupby(['fov_name', 'track_id']).ngroups} tracks")

    return adata_dict, df_dict


def main() -> None:
    """Self-align the template cells and write the alignment parquet."""
    parser = argparse.ArgumentParser(description="Evaluate template via self-alignment (Stage 1a)")
    parser.add_argument("--datasets", required=True, help="Path to datasets.yaml (shared infra config)")
    parser.add_argument("--config", required=True, help="Path to build_template.yaml")
    parser.add_argument("--template", required=True, help="Template name under config['templates']")
    parser.add_argument(
        "--flavor",
        choices=["raw", "pca"],
        default="raw",
        help="Which template flavor to align against (default: raw)",
    )
    parser.add_argument(
        "--min-track-timepoints",
        type=int,
        default=3,
        help="Minimum timepoints per track passed to dtw_align_tracks (default: 3)",
    )
    args = parser.parse_args()

    config = load_stage_config(args.datasets, args.config)

    template_cfg = config["templates"].get(args.template)
    if template_cfg is None or "candidate_set" not in template_cfg:
        raise ValueError(f"Template {args.template!r} is not a new-shape entry. Needs candidate_set.")

    candidate_set = template_cfg["candidate_set"]
    channel = template_cfg["channel"]
    anchor_label = template_cfg["anchor_label"]
    anchor_positive = template_cfg["anchor_positive"]

    template_path = TEMPLATES_DIR / f"template_{args.template}.zarr"
    if not template_path.exists():
        raise FileNotFoundError(f"Template zarr not found: {template_path}")

    _logger.info(f"Loading template {template_path} (flavor={args.flavor})")
    template_result, _attrs = load_template_flavor(template_path, args.flavor)
    _logger.info(f"  template shape {template_result.template.shape}, {template_result.n_input_tracks} input tracks")

    csv_path = CANDIDATES_DIR / f"{candidate_set}_annotations.csv"
    if not csv_path.exists():
        raise FileNotFoundError(f"Annotations CSV not found: {csv_path}")
    ann_df = pd.read_csv(csv_path)

    embedding_pattern = config["embeddings"][channel]
    dataset_cfgs = {d["dataset_id"]: d for d in config["datasets"]}

    adata_dict, df_dict = _prepare_dataset_inputs(
        ann_df, dataset_cfgs, embedding_pattern, anchor_label, anchor_positive
    )

    all_results = []
    for dataset_id, adata in adata_dict.items():
        df = df_dict[dataset_id]
        # Self-alignment: build cells are pre-cropped to template length, so
        # use global DTW (subsequence=False). dtw_align_tracks defaults to
        # subsequence=True, which is right for query alignment but would
        # change cost normalization for self-alignment.
        results = dtw_align_tracks(
            adata=adata,
            df=df,
            template_result=template_result,
            dataset_id=dataset_id,
            min_track_timepoints=args.min_track_timepoints,
            subsequence=False,
        )
        all_results.extend(results)

    flat = alignment_results_to_dataframe(
        all_results,
        template_id=template_result.template_id,
        time_calibration=template_result.time_calibration,
    )

    t_rel_parts = []
    for dataset_id, df in df_dict.items():
        part = df[["dataset_id", "fov_name", "track_id", "t", "t_relative_minutes"]].copy()
        part["track_id"] = part["track_id"].astype(int)
        t_rel_parts.append(part)
    t_rel_df = pd.concat(t_rel_parts, ignore_index=True)
    flat = flat.merge(
        t_rel_df,
        on=["dataset_id", "fov_name", "track_id", "t"],
        how="left",
    )

    OUTPUT_ALIGNMENTS_DIR.mkdir(parents=True, exist_ok=True)
    out_path = OUTPUT_ALIGNMENTS_DIR / f"template_alignments_{args.template}_{args.flavor}.parquet"
    flat.to_parquet(out_path, index=False)
    n_tracks = flat.groupby(["dataset_id", "fov_name", "track_id"]).ngroups
    _logger.info(f"Wrote {out_path} ({len(flat)} rows, {n_tracks} tracks)")


if __name__ == "__main__":
    main()
