r"""Build a DBA template in two feature spaces from an annotations CSV.

Stage 1 of the pseudotime pipeline. Reads the annotations CSV produced
by stage 0 (``manual_candidates.py`` or ``select_candidates.py``),
pulls each cell's embedding sequence from the channel's zarr, and
runs DBA twice on the same input cells to produce two template
flavors side by side:

- ``raw/``  — DBA in the raw embedding space (z-scored and L2-normalized).
- ``pca/``  — DBA after PCA to ``n_components`` (z-scored and L2-normalized
  before PCA). PCA components + mean are stored alongside for downstream
  alignment to project new cells into the same space.

Both flavors share the same z-score parameters and t_key_event values.
The cosine metric is realized via L2-normalization of the inputs;
:mod:`dtaidistance` only exposes (squared) Euclidean DTW under the
hood. ``l2_normalize=true`` is mandatory.

Usage::

    cd applications/dynaclr/scripts/pseudotime/1-build_template
    uv run python build_template.py \\
        --datasets ../../../configs/pseudotime/datasets.yaml \\
        --config ../../../configs/pseudotime/build_template.yaml \\
        --template manual_debug_sensor
"""

from __future__ import annotations

import argparse
import logging
import sys
from pathlib import Path

import anndata as ad
import numpy as np
import pandas as pd

from dynaclr.pseudotime import (
    build_template,
    date_prefix_from_dataset_id,
    find_embedding_zarr,
    save_template_zarr,
)

SCRIPT_DIR = Path(__file__).resolve().parent
CANDIDATES_DIR = SCRIPT_DIR.parent / "0-select_candidates" / "candidates"
OUTPUT_DIR = SCRIPT_DIR / "templates"

sys.path.insert(0, str(SCRIPT_DIR.parent))
from utils import load_stage_config  # noqa: E402

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(levelname)s %(message)s")
_logger = logging.getLogger(__name__)


def _derive_per_cell_metadata(
    ann_df: pd.DataFrame,
    anchor_label: str,
    anchor_positive: str,
    frame_interval_minutes: float,
) -> pd.DataFrame:
    """Compute ``t_perturb`` and ``t_relative_minutes`` per (cell, frame) row.

    ``t_perturb`` is the cell's first frame where ``anchor_label == anchor_positive``.
    """
    pos_rows = ann_df[ann_df[anchor_label] == anchor_positive]
    if len(pos_rows) == 0:
        raise ValueError(f"No rows where {anchor_label}={anchor_positive!r} in annotations — cannot derive t_perturb.")
    t_perturb = pos_rows.groupby(["dataset_id", "fov_name", "track_id"])["t"].min().rename("t_perturb").reset_index()
    merged = ann_df.merge(t_perturb, on=["dataset_id", "fov_name", "track_id"], how="inner")
    merged["t_relative_minutes"] = (merged["t"] - merged["t_perturb"]) * frame_interval_minutes
    return merged


def _prepare_inputs(
    ann_df: pd.DataFrame,
    dataset_cfgs: dict[str, dict],
    embedding_pattern: str,
    anchor_label: str,
    anchor_positive: str,
) -> tuple[dict[str, ad.AnnData], dict[str, pd.DataFrame]]:
    """Build the per-dataset ``adata`` + ``aligned_df`` dicts.

    - Loads the channel-specific embedding zarr per dataset.
    - Filters each ``adata`` to only the (fov, track, t) rows listed in
      the annotations CSV.
    - Attaches ``t_perturb``, ``t_relative_minutes``, and label columns
      from the CSV onto the dataset's aligned DataFrame.
    """
    adata_dict: dict[str, ad.AnnData] = {}
    aligned_df_dict: dict[str, pd.DataFrame] = {}

    for dataset_id, sub in ann_df.groupby("dataset_id"):
        if dataset_id not in dataset_cfgs:
            raise KeyError(f"dataset_id {dataset_id!r} in annotations CSV not found in config datasets")
        ds_cfg = dataset_cfgs[dataset_id]
        prefix = date_prefix_from_dataset_id(dataset_id)
        zarr_path = find_embedding_zarr(ds_cfg["pred_dir"], prefix + embedding_pattern)
        _logger.info(f"  [{dataset_id}] loading {Path(zarr_path).name}")

        adata = ad.read_zarr(zarr_path)
        adata.obs_names_make_unique()
        keys_wanted = set(
            zip(
                sub["fov_name"].astype(str),
                sub["track_id"].astype(int),
                sub["t"].astype(int),
            )
        )
        mask = [
            (str(f), int(tid), int(t)) in keys_wanted
            for f, tid, t in zip(adata.obs["fov_name"], adata.obs["track_id"], adata.obs["t"])
        ]
        adata = adata[np.asarray(mask)].copy()
        if len(adata) == 0:
            raise ValueError(f"No adata rows match the CSV for dataset {dataset_id}")

        sub = _derive_per_cell_metadata(sub.copy(), anchor_label, anchor_positive, ds_cfg["frame_interval_minutes"])

        adata_dict[dataset_id] = adata
        aligned_df_dict[dataset_id] = sub
        _logger.info(f"  [{dataset_id}] {adata.n_obs} rows, {sub.groupby(['fov_name', 'track_id']).ngroups} tracks")

    return adata_dict, aligned_df_dict


def main() -> None:
    """Build the two-flavor template for a named template entry."""
    parser = argparse.ArgumentParser(description="Build DBA template (Stage 1)")
    parser.add_argument("--datasets", required=True, help="Path to datasets.yaml (shared infra config)")
    parser.add_argument("--config", required=True, help="Path to build_template.yaml")
    parser.add_argument("--template", required=True, help="Template name under config['templates']")
    args = parser.parse_args()

    config = load_stage_config(args.datasets, args.config)

    template_cfg = config["templates"].get(args.template)
    if template_cfg is None:
        raise KeyError(f"Template {args.template!r} not in config")
    if "candidate_set" not in template_cfg:
        raise ValueError(
            f"Template {args.template!r} is a legacy entry. This script only handles "
            f"new-shape entries with candidate_set, channel, anchor_label."
        )

    candidate_set = template_cfg["candidate_set"]
    channel = template_cfg["channel"]
    anchor_label = template_cfg["anchor_label"]
    anchor_positive = template_cfg["anchor_positive"]
    preprocessing = template_cfg.get("preprocessing", {})
    pca_n_components = int(preprocessing.get("pca", {}).get("n_components", 20))
    aggregator = template_cfg.get("aggregator", "dba")
    dba_cfg = template_cfg.get("dba", {})

    cfg_propagate = template_cfg.get("propagate_columns")
    if cfg_propagate is None:
        propagate_columns = [anchor_label]
    else:
        propagate_columns = list(cfg_propagate)
        if anchor_label not in propagate_columns:
            propagate_columns.append(anchor_label)
    _logger.info("Propagating multiclass labels for columns: %s", propagate_columns)

    if aggregator != "dba":
        raise NotImplementedError(f"aggregator={aggregator!r} not implemented yet")

    csv_path = CANDIDATES_DIR / f"{candidate_set}_annotations.csv"
    if not csv_path.exists():
        raise FileNotFoundError(f"Annotations CSV not found: {csv_path}")
    _logger.info(f"Reading {csv_path}")
    ann_df = pd.read_csv(csv_path)

    embedding_pattern = config["embeddings"][channel]
    dataset_cfgs = {d["dataset_id"]: d for d in config["datasets"]}

    adata_dict, aligned_df_dict = _prepare_inputs(
        ann_df, dataset_cfgs, embedding_pattern, anchor_label, anchor_positive
    )

    t_key_per_cell_map = {
        (row["dataset_id"], str(row["fov_name"]), int(row["track_id"])): int(row["t_perturb"])
        for df in aligned_df_dict.values()
        for _, row in df.groupby(["dataset_id", "fov_name", "track_id"]).first().reset_index().iterrows()
    }

    _logger.info("Building raw/ flavor (no PCA)")
    raw_result = build_template(
        adata_dict=adata_dict,
        aligned_df_dict=aligned_df_dict,
        pca_n_components=None,
        dba_max_iter=int(dba_cfg.get("max_iter", 30)),
        dba_tol=float(dba_cfg.get("tol", 1e-5)),
        dba_init=str(dba_cfg.get("init", "medoid")),
        propagate_columns=propagate_columns,
    )

    _logger.info(f"Building pca/ flavor (n_components={pca_n_components})")
    pca_result = build_template(
        adata_dict=adata_dict,
        aligned_df_dict=aligned_df_dict,
        pca_n_components=pca_n_components,
        dba_max_iter=int(dba_cfg.get("max_iter", 30)),
        dba_tol=float(dba_cfg.get("tol", 1e-5)),
        dba_init=str(dba_cfg.get("init", "medoid")),
        propagate_columns=propagate_columns,
    )

    t_key_event_per_cell = np.asarray(
        [t_key_per_cell_map[(ds, fov, tid)] for (ds, fov, tid) in raw_result.template_cell_ids],
        dtype=np.int64,
    )

    build_frame_intervals = {ds_id: float(dataset_cfgs[ds_id]["frame_interval_minutes"]) for ds_id in adata_dict}
    tc = raw_result.time_calibration
    template_duration_minutes = float(tc[-1] - tc[0]) if (tc is not None and tc.size >= 2) else 0.0

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    out_path = OUTPUT_DIR / f"template_{args.template}.zarr"
    save_template_zarr(
        out_path=out_path,
        raw_result=raw_result,
        pca_result=pca_result,
        template_name=args.template,
        config_snapshot=config,
        anchor_label=anchor_label,
        anchor_positive=anchor_positive,
        aggregator=aggregator,
        t_key_event_per_cell=t_key_event_per_cell,
        build_frame_intervals_minutes=build_frame_intervals,
        template_duration_minutes=template_duration_minutes,
    )
    _logger.info(
        f"Wrote {out_path} (duration={template_duration_minutes:.1f} min, build intervals: {build_frame_intervals})"
    )


if __name__ == "__main__":
    main()
