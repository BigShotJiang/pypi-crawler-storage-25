"""Per-cell DTW-pseudotime onset offset between sensor and organelle channels.

For each query cell in a Stage 2a alignment parquet, compute two onsets
on the **DTW-warped time axis** ``estimated_t_rel_minutes``:

- **Sensor onset** (``t_sensor_onset_min``): first aligned ``t_rel``
  where ``dtw_infection_state`` ≥ 0.5. The infection-template label
  fraction propagated along the warp path; sharp (spans 0→1 across the
  template) so a 0.5 threshold is robust.

- **Organelle onset** (``t_organelle_onset_min``): first aligned
  ``t_rel`` where this cell's own **organelle embedding cosine
  distance from its pre-baseline** crosses ``pre_median + 0.5 ×
  Δpeak``. Per-cell measurement on the organelle channel
  (``--organelle-channel``); same half-rise rule as
  :mod:`compute_timing_metrics` Stage 3c.

This combines (a) DTW pseudotime as the master clock for sensor onset
with (b) per-cell embedding measurement for organelle onset — avoiding
the bimodal-Δ artifact you get when both onsets are derived from the
template's discrete propagated label fractions.

Per-cell offset:

    Δ = t_organelle_onset_min - t_sensor_onset_min

Δ < 0 → organelle leads sensor; Δ > 0 → organelle lags.

Usage
-----

::

    cd applications/dynaclr/scripts/pseudotime/3-organelle-remodeling

    uv run python compute_dtw_onset_offset.py compute \\
        --datasets ../../../configs/pseudotime/datasets.yaml \\
        --config ../../../configs/pseudotime/align_cells.yaml \\
        --alignment ../2-align_cells/alignments/infection_nondividing_sensor_raw_on_sensor_all_07_24.parquet \\
        --organelle-channel organelle_sec61 \\
        --out-stem dtw_offset_07_24_sec61

    # SEC61 vs G3BP1 comparison (must run compute twice first)
    uv run python compute_dtw_onset_offset.py compare \\
        --per-cell timing_dtw/dtw_offset_07_24_sec61_per_cell.parquet \\
                   timing_dtw/dtw_offset_07_24_g3bp1_per_cell.parquet \\
        --out-stem compare_sec61_vs_g3bp1_07_24
"""

from __future__ import annotations

import argparse
import logging
import sys
from dataclasses import asdict, dataclass
from pathlib import Path

import anndata as ad
import matplotlib
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy import stats

from dynaclr.pseudotime import date_prefix_from_dataset_id, find_embedding_zarr

matplotlib.use("Agg")

SCRIPT_DIR = Path(__file__).resolve().parent
TIMING_DIR = SCRIPT_DIR / "timing_dtw"

sys.path.insert(0, str(SCRIPT_DIR.parent))
from utils import load_stage_config  # noqa: E402

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(levelname)s %(message)s")
_logger = logging.getLogger(__name__)


@dataclass
class _CellOnset:
    """Per-cell sensor + organelle onset and their delta."""

    dataset_id: str
    fov_name: str
    track_id: int
    n_aligned: int
    n_pre: int
    pre_median_distance: float
    peak_distance: float
    delta_peak: float
    organelle_threshold: float
    t_sensor_onset_min: float
    t_organelle_onset_min: float
    delta_organelle_minus_sensor_min: float
    passes_control_floor: bool = True


@dataclass
class _ControlCell:
    """Per-cell delta_peak for a paired uninfected cell.

    Same metric the infected cells get, computed on the uninfected
    population. Used to derive the noise-floor threshold below which
    an infected cell's `delta_peak` is indistinguishable from a
    control cell.
    """

    dataset_id: str
    fov_name: str
    track_id: int
    n_frames: int
    pre_median_distance: float
    peak_distance: float
    delta_peak: float


def _first_crossing(t: np.ndarray, y: np.ndarray, threshold: float) -> float:
    """First ``t`` (linear-interpolated) where ``y`` first reaches ``threshold``.

    Returns NaN if no crossing exists.
    """
    if len(t) == 0 or len(y) == 0:
        return float("nan")
    above = y >= threshold
    if not above.any():
        return float("nan")
    if above.all():
        return float(t[0])
    first = int(np.argmax(above))
    if first == 0:
        return float(t[0])
    t0, t1 = float(t[first - 1]), float(t[first])
    y0, y1 = float(y[first - 1]), float(y[first])
    if y1 == y0:
        return t1
    return t0 + (threshold - y0) / (y1 - y0) * (t1 - t0)


def _join_organelle_embedding(
    df: pd.DataFrame,
    dataset_cfgs: dict[str, dict],
    organelle_pattern: str,
) -> pd.DataFrame:
    """Attach the organelle embedding vector to each parquet row.

    Drops rows whose ``(fov_name, track_id, t)`` is absent from the
    organelle zarr — common when a sensor query cell is in a well that
    was not imaged with that organelle (e.g. SEC61 in A wells but not C
    wells). Those cells silently disappear from the per-organelle
    output, which is the correct behavior.
    """
    parts = []
    for dataset_id, ds_align in df.groupby("dataset_id"):
        ds_cfg = dataset_cfgs[dataset_id]
        prefix = date_prefix_from_dataset_id(dataset_id)
        zarr_path = find_embedding_zarr(ds_cfg["pred_dir"], prefix + organelle_pattern)
        _logger.info(f"  [{dataset_id}] joining organelle embedding from {Path(zarr_path).name}")
        adata = ad.read_zarr(zarr_path)
        adata.obs_names_make_unique()
        X = adata.X
        if hasattr(X, "toarray"):
            X = X.toarray()
        X = np.asarray(X, dtype=np.float64)
        obs = adata.obs.reset_index(drop=True)
        lookup: dict[tuple[str, int, int], int] = {
            (str(row["fov_name"]), int(row["track_id"]), int(row["t"])): i for i, row in obs.iterrows()
        }
        ds_aligned = ds_align.reset_index(drop=True).copy()
        ds_aligned["fov_name"] = ds_aligned["fov_name"].astype(str)
        ds_aligned["track_id"] = ds_aligned["track_id"].astype(int)
        ds_aligned["t"] = ds_aligned["t"].astype(int)
        embeddings: list[np.ndarray | None] = []
        for _, row in ds_aligned.iterrows():
            key = (str(row["fov_name"]), int(row["track_id"]), int(row["t"]))
            idx = lookup.get(key)
            embeddings.append(X[idx] if idx is not None else None)
        ds_aligned["organelle_embedding"] = embeddings
        parts.append(ds_aligned[ds_aligned["organelle_embedding"].notna()].reset_index(drop=True))
    return pd.concat(parts, ignore_index=True)


def _cosine_distance_from_baseline(
    joined: pd.DataFrame,
    baselines: dict[str, np.ndarray] | None = None,
) -> np.ndarray:
    """Per-frame cosine distance to a baseline embedding.

    Two baseline modes:

    - **per-cell** (``baselines`` is None) — each cell's own mean pre-event
      embedding (or earliest 25% of aligned frames if no pre frames). This
      cancels per-cell appearance variation but is noisy on short tracks.

    - **per-dataset population** (``baselines`` is a dict mapping
      ``dataset_id`` to a ``(D,)`` mean vector) — every cell in that
      dataset uses the same population baseline. Stable; isolates
      infection-driven divergence from the uninfected population.
    """
    distances = np.full(len(joined), np.nan, dtype=np.float64)
    for (dataset_id, _, _), group in joined.groupby(["dataset_id", "fov_name", "track_id"], sort=False):
        idx = group.index.to_numpy()
        emb = np.stack(group["organelle_embedding"].to_list())
        if baselines is not None:
            if dataset_id not in baselines:
                continue
            baseline = baselines[dataset_id]
        else:
            pre_mask = group["alignment_region"].to_numpy() == "pre"
            if pre_mask.any():
                baseline = emb[pre_mask].mean(axis=0)
            else:
                aligned_mask = group["alignment_region"].to_numpy() == "aligned"
                if not aligned_mask.any():
                    continue
                earliest = aligned_mask.nonzero()[0][: max(1, aligned_mask.sum() // 4)]
                baseline = emb[earliest].mean(axis=0)
        bn = np.linalg.norm(baseline)
        en = np.linalg.norm(emb, axis=1)
        denom = bn * en
        cos_sim = np.where(denom > 0, (emb @ baseline) / np.where(denom > 0, denom, 1.0), 0.0)
        distances[idx] = 1.0 - cos_sim
    return distances


def _load_population_baselines(
    dataset_cfgs: dict[str, dict],
    organelle_pattern: str,
    dataset_ids: list[str],
    control_perturbation: str,
) -> dict[str, np.ndarray]:
    """Compute per-dataset mean embedding across all uninfected cell-frames.

    Returned vectors are intended for use as the baseline in
    :func:`_cosine_distance_from_baseline`. One vector per dataset
    because optical-path / acquisition differences between datasets are
    real — pooling baselines across datasets would absorb infection
    signal.
    """
    out: dict[str, np.ndarray] = {}
    for ds_id in dataset_ids:
        ds_cfg = dataset_cfgs[ds_id]
        prefix = date_prefix_from_dataset_id(ds_id)
        zarr_path = find_embedding_zarr(ds_cfg["pred_dir"], prefix + organelle_pattern)
        adata = ad.read_zarr(zarr_path)
        adata.obs_names_make_unique()
        if "perturbation" not in adata.obs.columns:
            raise KeyError(f"[{ds_id}] obs.perturbation missing — cannot compute population baseline")
        ctrl_mask = (adata.obs["perturbation"].astype(str) == control_perturbation).to_numpy()
        if not ctrl_mask.any():
            _logger.warning(f"  [{ds_id}] no '{control_perturbation}' cells — skipping baseline")
            continue
        X = adata.X
        if hasattr(X, "toarray"):
            X = X.toarray()
        X = np.asarray(X, dtype=np.float64)
        baseline = X[ctrl_mask].mean(axis=0)
        out[ds_id] = baseline
        _logger.info(f"  [{ds_id}] population baseline: {int(ctrl_mask.sum())} control cell-frames, ||μ||={np.linalg.norm(baseline):.3f}")
    return out


def _compute_control_delta_peaks(
    dataset_cfgs: dict[str, dict],
    organelle_pattern: str,
    dataset_ids: list[str],
    control_perturbation: str,
    min_track_length: int,
    baselines: dict[str, np.ndarray] | None = None,
) -> list[_ControlCell]:
    """Compute per-cell ``delta_peak`` for control (uninfected) cells.

    For each control cell track in the organelle zarr, computes cosine
    distance to a baseline (per-dataset population baseline if
    ``baselines`` is provided, else each cell's own first-25% mean),
    then returns ``peak − baseline_median``. This is the empirical
    distribution of "delta_peak with no infection happening" against
    the same baseline used for infected cells.

    Tracks shorter than ``min_track_length`` frames are skipped (their
    delta_peak is dominated by sample-size noise rather than biology).
    """
    out: list[_ControlCell] = []
    for ds_id in dataset_ids:
        ds_cfg = dataset_cfgs[ds_id]
        prefix = date_prefix_from_dataset_id(ds_id)
        zarr_path = find_embedding_zarr(ds_cfg["pred_dir"], prefix + organelle_pattern)
        _logger.info(f"  [{ds_id}] loading control cells from {Path(zarr_path).name}")
        adata = ad.read_zarr(zarr_path)
        adata.obs_names_make_unique()
        if "perturbation" not in adata.obs.columns:
            raise KeyError(f"[{ds_id}] obs.perturbation missing — cannot select control cells")
        obs = adata.obs.reset_index(drop=True)
        ctrl_mask = obs["perturbation"].astype(str) == control_perturbation
        n_ctrl = int(ctrl_mask.sum())
        if n_ctrl == 0:
            _logger.warning(f"  [{ds_id}] no cells with perturbation == '{control_perturbation}'")
            continue
        X = adata.X
        if hasattr(X, "toarray"):
            X = X.toarray()
        X = np.asarray(X, dtype=np.float64)
        ctrl_obs = obs[ctrl_mask].reset_index(drop=True)
        ctrl_X = X[ctrl_mask.to_numpy()]

        ctrl_obs["fov_name"] = ctrl_obs["fov_name"].astype(str)
        ctrl_obs["track_id"] = ctrl_obs["track_id"].astype(int)
        ctrl_obs["t"] = ctrl_obs["t"].astype(int)

        ds_baseline = baselines.get(ds_id) if baselines is not None else None

        for (fov, tid), grp in ctrl_obs.groupby(["fov_name", "track_id"], sort=False):
            if len(grp) < min_track_length:
                continue
            ordered = grp.sort_values("t")
            indices = ordered.index.to_numpy()
            emb = ctrl_X[indices]
            n_frames = len(emb)
            n_baseline = max(1, n_frames // 4)
            baseline = ds_baseline if ds_baseline is not None else emb[:n_baseline].mean(axis=0)
            bn = np.linalg.norm(baseline)
            en = np.linalg.norm(emb, axis=1)
            denom = bn * en
            cos_sim = np.where(denom > 0, (emb @ baseline) / np.where(denom > 0, denom, 1.0), 0.0)
            d = 1.0 - cos_sim
            pre_median = float(np.nanmedian(d[:n_baseline]))
            interior_n = max(3, n_frames - 2)
            peak = float(np.nanmax(d[:interior_n]))
            out.append(
                _ControlCell(
                    dataset_id=str(ds_id),
                    fov_name=str(fov),
                    track_id=int(tid),
                    n_frames=int(n_frames),
                    pre_median_distance=pre_median,
                    peak_distance=peak,
                    delta_peak=peak - pre_median,
                )
            )
    return out


def _per_cell_onsets(joined: pd.DataFrame, distances: np.ndarray) -> list[_CellOnset]:
    """Compute per-cell sensor + organelle onsets and their delta."""
    joined = joined.copy()
    joined["distance"] = distances
    out: list[_CellOnset] = []
    for (ds, fov, tid), grp in joined.groupby(["dataset_id", "fov_name", "track_id"], sort=False):
        grp = grp.sort_values("t").reset_index(drop=True)
        aligned = grp[grp["alignment_region"] == "aligned"].copy()
        pre = grp[grp["alignment_region"] == "pre"]
        if len(aligned) < 3:
            continue

        t = aligned["estimated_t_rel_minutes"].to_numpy(dtype=float)
        sensor = aligned["dtw_infection_state"].to_numpy(dtype=float)
        d = aligned["distance"].to_numpy(dtype=float)
        mask = np.isfinite(t) & np.isfinite(d) & np.isfinite(sensor)
        if mask.sum() < 3:
            continue
        t, sensor, d = t[mask], sensor[mask], d[mask]

        # Sensor onset: first t_rel where dtw_infection_state crosses 0.5.
        t_sensor = _first_crossing(t, sensor, 0.5)
        if not np.isfinite(t_sensor):
            continue

        # Organelle onset: per-cell half-rise of cosine distance from baseline.
        # Use the interior (drop last 2 aligned frames) for peak detection to
        # avoid DTW endpoint pile-up — same convention as compute_timing_metrics.
        interior_n = max(3, len(d) - 2)
        i_d = d[:interior_n]
        i_t = t[:interior_n]
        peak = float(i_d.max())
        if len(pre) > 0:
            pre_d = pre["distance"].to_numpy(dtype=float)
            pre_d = pre_d[np.isfinite(pre_d)]
            pre_median = float(np.nanmedian(pre_d)) if len(pre_d) > 0 else float(d.min())
        else:
            pre_median = float(d.min())
        delta_peak = peak - pre_median
        if delta_peak < 1e-3:
            continue
        threshold = pre_median + 0.5 * delta_peak
        t_org = _first_crossing(i_t, i_d, threshold)
        if not np.isfinite(t_org):
            continue

        out.append(
            _CellOnset(
                dataset_id=str(ds),
                fov_name=str(fov),
                track_id=int(tid),
                n_aligned=int(len(t)),
                n_pre=int(len(pre)),
                pre_median_distance=pre_median,
                peak_distance=peak,
                delta_peak=delta_peak,
                organelle_threshold=threshold,
                t_sensor_onset_min=t_sensor,
                t_organelle_onset_min=t_org,
                delta_organelle_minus_sensor_min=t_org - t_sensor,
            )
        )
    return out


def _floor_diagnostic_plot(
    infected_delta_peaks: np.ndarray,
    control_delta_peaks: np.ndarray,
    floor_thresholds: dict[int, float],
    floor_sweep: list[tuple[int, int, float, float, float]],
    out_png: Path,
) -> None:
    """Histogram of infected vs control delta_peak + median Δ vs floor sweep.

    Parameters
    ----------
    infected_delta_peaks, control_delta_peaks : np.ndarray
        Per-cell delta_peak distributions for the two populations.
    floor_thresholds : dict[int, float]
        Mapping percentile (50/75/90/95) → control delta_peak at that
        percentile.
    floor_sweep : list of (percentile, n_kept, median_delta, ci_low, ci_high)
        For the median Δ vs floor curve. The percentiles match the keys
        of ``floor_thresholds``.
    """
    fig, axes = plt.subplots(1, 2, figsize=(11, 4.2))

    ax_l = axes[0]
    bins = np.linspace(
        0,
        max(float(np.nanmax(infected_delta_peaks)) if len(infected_delta_peaks) else 0.0,
            float(np.nanmax(control_delta_peaks)) if len(control_delta_peaks) else 0.0,
            0.01),
        40,
    )
    ax_l.hist(control_delta_peaks, bins=bins, alpha=0.6, color="grey", label=f"control (n={len(control_delta_peaks)})")
    ax_l.hist(infected_delta_peaks, bins=bins, alpha=0.6, color="#c0392b", label=f"infected (n={len(infected_delta_peaks)})")
    cmap = plt.get_cmap("viridis")
    n_thr = max(len(floor_thresholds), 1)
    for i, (pct, thr) in enumerate(sorted(floor_thresholds.items())):
        ax_l.axvline(thr, color=cmap(i / n_thr), linestyle="--", linewidth=1.2, label=f"P{pct} = {thr:.3f}")
    ax_l.set_xlabel("delta_peak (cosine distance from baseline)")
    ax_l.set_ylabel("count")
    ax_l.set_title("delta_peak: infected vs control")
    ax_l.legend(fontsize=7, frameon=False)

    ax_r = axes[1]
    if floor_sweep:
        pcts = [s[0] for s in floor_sweep]
        n_kept = [s[1] for s in floor_sweep]
        meds = [s[2] for s in floor_sweep]
        lows = [s[3] for s in floor_sweep]
        his = [s[4] for s in floor_sweep]
        ax_r.errorbar(
            pcts,
            meds,
            yerr=[np.array(meds) - np.array(lows), np.array(his) - np.array(meds)],
            fmt="o-",
            color="#2c3e50",
            capsize=4,
        )
        ax_r.axhline(0, color="grey", linestyle="--", linewidth=0.8)
        for p, n_k, m in zip(pcts, n_kept, meds, strict=False):
            ax_r.annotate(f"n={n_k}", xy=(p, m), xytext=(4, 4), textcoords="offset points", fontsize=8)
    ax_r.set_xlabel("control floor percentile")
    ax_r.set_ylabel("median Δ (organelle − sensor)  [min]")
    ax_r.set_title("median Δ vs floor (robustness check)")
    ax_r.grid(alpha=0.3)

    fig.tight_layout()
    fig.savefig(out_png, dpi=160, bbox_inches="tight", facecolor="white")
    plt.close(fig)


def _bootstrap_median_ci(x: np.ndarray, n_boot: int = 2000, ci: float = 95.0) -> tuple[float, float, float]:
    """Median + percentile bootstrap CI."""
    if len(x) == 0:
        return float("nan"), float("nan"), float("nan")
    rng = np.random.default_rng(42)
    idx = rng.integers(0, len(x), size=(n_boot, len(x)))
    boots = np.median(x[idx], axis=1)
    lo = np.percentile(boots, (100 - ci) / 2)
    hi = np.percentile(boots, 100 - (100 - ci) / 2)
    return float(np.median(x)), float(lo), float(hi)


def _summary_md(
    args: argparse.Namespace,
    scores: list[_CellOnset],
    floor_thresholds: dict[int, float] | None = None,
    control_cells: list[_ControlCell] | None = None,
) -> str:
    """Render a markdown summary for one compute run.

    Parameters
    ----------
    args : argparse.Namespace
        Parsed CLI args (used for paths and flags shown in the header).
    scores : list of _CellOnset
        All scored infected cells (pre-filter).
    floor_thresholds : dict, optional
        Maps percentile → control delta_peak threshold. When set, the
        summary includes a post-filter section keyed off
        ``args.floor_percentile``.
    control_cells : list of _ControlCell, optional
        Per-control-cell delta_peak rows. Counted in the summary.
    """
    if not scores:
        return f"# DTW onset offset — {args.out_stem}\n\n_(no cells passed filtering)_\n"

    sensor = np.array([s.t_sensor_onset_min for s in scores])
    organelle = np.array([s.t_organelle_onset_min for s in scores])
    delta = np.array([s.delta_organelle_minus_sensor_min for s in scores])

    s_med, s_lo, s_hi = _bootstrap_median_ci(sensor)
    o_med, o_lo, o_hi = _bootstrap_median_ci(organelle)
    d_med, d_lo, d_hi = _bootstrap_median_ci(delta)
    p = stats.wilcoxon(delta, alternative="two-sided").pvalue if len(delta) > 1 else float("nan")

    lines = [
        f"# DTW onset offset — {args.out_stem}",
        "",
        f"- alignment parquet:   `{args.alignment}`",
        f"- organelle channel:   `{args.organelle_channel}`",
        f"- sensor onset:        `dtw_infection_state` ≥ 0.5 on the warped axis",
        f"- organelle onset:     per-cell cosine distance from pre-baseline, "
        f"half-rise (`pre_median + 0.5·Δpeak`)",
        f"- n cells scored:      **{len(scores)}** (pre-filter)",
        "",
        "## Pre-filter (all cells with finite onsets)",
        "",
        "| metric | median [95% CI] (min) |",
        "|---|---:|",
        f"| sensor onset (t_sensor)        | {s_med:+.0f} [{s_lo:+.0f}, {s_hi:+.0f}] |",
        f"| organelle onset (t_organelle) | {o_med:+.0f} [{o_lo:+.0f}, {o_hi:+.0f}] |",
        f"| **Δ = organelle − sensor**    | **{d_med:+.0f} [{d_lo:+.0f}, {d_hi:+.0f}]** |",
        "",
        f"Wilcoxon two-sided p (Δ ≠ 0): **{p:.2g}**",
    ]

    if floor_thresholds and control_cells:
        n_ctrl = len(control_cells)
        lines += [
            "",
            "## Control-floor filter",
            "",
            f"- control perturbation: `{args.control_perturbation}`",
            f"- n control cells: **{n_ctrl}**",
            "",
            "| percentile | control delta_peak | infected cells passing |",
            "|---:|---:|---:|",
        ]
        for pct in sorted(floor_thresholds):
            n_pass = sum(1 for s in scores if s.delta_peak > floor_thresholds[pct])
            mark = "  ⟵ chosen" if pct == args.floor_percentile else ""
            lines.append(f"| P{pct}{mark} | {floor_thresholds[pct]:.3f} | {n_pass} / {len(scores)} |")

        kept = [s for s in scores if s.passes_control_floor]
        if kept:
            d_k = np.array([s.delta_organelle_minus_sensor_min for s in kept], dtype=float)
            s_k = np.array([s.t_sensor_onset_min for s in kept], dtype=float)
            o_k = np.array([s.t_organelle_onset_min for s in kept], dtype=float)
            ds_med, ds_lo, ds_hi = _bootstrap_median_ci(s_k)
            do_med, do_lo, do_hi = _bootstrap_median_ci(o_k)
            dd_med, dd_lo, dd_hi = _bootstrap_median_ci(d_k)
            p_k = stats.wilcoxon(d_k, alternative="two-sided").pvalue if len(d_k) > 1 else float("nan")
            lines += [
                "",
                f"## Post-filter (P{args.floor_percentile} control-floor, n = {len(kept)})",
                "",
                "| metric | median [95% CI] (min) |",
                "|---|---:|",
                f"| sensor onset (t_sensor)        | {ds_med:+.0f} [{ds_lo:+.0f}, {ds_hi:+.0f}] |",
                f"| organelle onset (t_organelle) | {do_med:+.0f} [{do_lo:+.0f}, {do_hi:+.0f}] |",
                f"| **Δ = organelle − sensor**    | **{dd_med:+.0f} [{dd_lo:+.0f}, {dd_hi:+.0f}]** |",
                "",
                f"Wilcoxon two-sided p (Δ ≠ 0): **{p_k:.2g}**",
            ]

    lines += [
        "",
        "## Interpretation",
        "",
        "- Δ < 0 → organelle reaches half-rise **before** sensor → organelle leads.",
        "- Δ > 0 → organelle reaches half-rise **after** sensor → organelle lags.",
        "- The control-floor filter keeps only cells whose `delta_peak` exceeds what we observe in",
        "  uninfected controls (cosine-distance noise floor). Cells under the floor have no detectable",
        "  remodeling — assigning them an onset would be reading noise.",
    ]
    return "\n".join(lines) + "\n"


def _compute_command(args: argparse.Namespace) -> None:
    parquet_path = Path(args.alignment)
    if not parquet_path.exists():
        raise FileNotFoundError(parquet_path)
    _logger.info(f"Reading {parquet_path.name}")
    df = pd.read_parquet(parquet_path)
    for col in ["dtw_infection_state", "estimated_t_rel_minutes", "alignment_region"]:
        if col not in df.columns:
            raise KeyError(f"required column '{col}' missing from parquet")

    config = load_stage_config(args.datasets, args.config)
    dataset_cfgs = {d["dataset_id"]: d for d in config["datasets"]}
    organelle_pattern = config["embeddings"][args.organelle_channel]

    if args.dataset_id:
        df = df[df["dataset_id"] == args.dataset_id]
        _logger.info(f"  filtered to dataset_id='{args.dataset_id}': {len(df):,} rows")

    _logger.info("Joining organelle embeddings")
    joined = _join_organelle_embedding(df, dataset_cfgs, organelle_pattern)
    _logger.info(
        f"  joined rows: {len(joined):,} ({joined.groupby(['dataset_id', 'fov_name', 'track_id']).ngroups} cells)"
    )

    population_baselines: dict[str, np.ndarray] | None = None
    if args.baseline_mode == "population":
        ctrl_dataset_ids = sorted(joined["dataset_id"].unique().tolist())
        _logger.info(f"Computing per-dataset population baselines (perturbation == '{args.control_perturbation}')")
        population_baselines = _load_population_baselines(
            dataset_cfgs, organelle_pattern, ctrl_dataset_ids, args.control_perturbation
        )
        if not population_baselines:
            raise RuntimeError("baseline-mode=population requested but no baselines were computed")

    baseline_label = "population (uninfected mean)" if args.baseline_mode == "population" else "per-cell pre"
    _logger.info(f"Computing per-frame cosine distance from baseline [{baseline_label}]")
    distances = _cosine_distance_from_baseline(joined, baselines=population_baselines)

    _logger.info("Reducing to per-cell sensor + organelle onsets")
    scores = _per_cell_onsets(joined, distances)
    _logger.info(f"  cells with finite sensor + organelle onsets: {len(scores)}")

    TIMING_DIR.mkdir(parents=True, exist_ok=True)

    floor_thresholds: dict[int, float] = {}
    floor_sweep: list[tuple[int, int, float, float, float]] = []
    control_cells: list[_ControlCell] = []

    if args.use_control_floor and scores:
        ctrl_dataset_ids = sorted(joined["dataset_id"].unique().tolist())
        _logger.info(f"Loading control cells (perturbation == '{args.control_perturbation}') from {len(ctrl_dataset_ids)} dataset(s)")
        control_cells = _compute_control_delta_peaks(
            dataset_cfgs,
            organelle_pattern,
            ctrl_dataset_ids,
            args.control_perturbation,
            args.min_control_track_length,
            baselines=population_baselines,
        )
        if not control_cells:
            _logger.warning("No control cells survived filtering — skipping floor application")
        else:
            ctrl_deltas = np.array([c.delta_peak for c in control_cells], dtype=float)
            for pct in (50, 75, 90, 95):
                floor_thresholds[pct] = float(np.percentile(ctrl_deltas, pct))
            ctrl_path = TIMING_DIR / f"{args.out_stem}_control_floor.parquet"
            pd.DataFrame([asdict(c) for c in control_cells]).to_parquet(ctrl_path, index=False)
            _logger.info(f"Wrote {ctrl_path.name}  (n_control_cells={len(control_cells)})")
            _logger.info(
                "Control delta_peak percentiles: P50=%.3f  P75=%.3f  P90=%.3f  P95=%.3f",
                floor_thresholds[50],
                floor_thresholds[75],
                floor_thresholds[90],
                floor_thresholds[95],
            )

            chosen = floor_thresholds[args.floor_percentile]
            for s in scores:
                s.passes_control_floor = s.delta_peak > chosen
            for pct, thr in sorted(floor_thresholds.items()):
                kept = [s for s in scores if s.delta_peak > thr]
                if not kept:
                    floor_sweep.append((pct, 0, float("nan"), float("nan"), float("nan")))
                    continue
                deltas = np.array([k.delta_organelle_minus_sensor_min for k in kept], dtype=float)
                med, lo, hi = _bootstrap_median_ci(deltas)
                floor_sweep.append((pct, len(kept), med, lo, hi))

            kept_n = sum(1 for s in scores if s.passes_control_floor)
            _logger.info(
                "Applied control floor at P%d (delta_peak > %.3f): %d / %d cells pass",
                args.floor_percentile,
                chosen,
                kept_n,
                len(scores),
            )

    per_cell_path = TIMING_DIR / f"{args.out_stem}_per_cell.parquet"
    pd.DataFrame([asdict(s) for s in scores]).to_parquet(per_cell_path, index=False)
    summary_path = TIMING_DIR / f"{args.out_stem}_summary.md"
    summary_path.write_text(_summary_md(args, scores, floor_thresholds, control_cells))
    _logger.info(f"Wrote {per_cell_path.name}")
    _logger.info(f"Wrote {summary_path.name}")

    if floor_thresholds and scores:
        diag_path = TIMING_DIR / f"{args.out_stem}_floor_diagnostic.png"
        infected_dp = np.array([s.delta_peak for s in scores], dtype=float)
        control_dp = np.array([c.delta_peak for c in control_cells], dtype=float)
        _floor_diagnostic_plot(infected_dp, control_dp, floor_thresholds, floor_sweep, diag_path)
        _logger.info(f"Wrote {diag_path.name}")

    if scores:
        delta_all = np.array([s.delta_organelle_minus_sensor_min for s in scores], dtype=float)
        med_all = float(np.median(delta_all))
        word = "leads" if med_all < 0 else "lags"
        _logger.info(f"Pre-filter median Δ = {med_all:+.0f} min → organelle {word} sensor (n={len(scores)})")
        if floor_thresholds:
            kept = [s for s in scores if s.passes_control_floor]
            if kept:
                d_kept = np.array([s.delta_organelle_minus_sensor_min for s in kept], dtype=float)
                med_k = float(np.median(d_kept))
                word_k = "leads" if med_k < 0 else "lags"
                _logger.info(
                    f"Post-filter median Δ (P{args.floor_percentile}) = {med_k:+.0f} min → organelle {word_k} sensor (n={len(kept)})"
                )


def _strip_plot(per_cells: list[Path], out_png: Path) -> None:
    """Strip plot of Δ for each per_cell parquet, side by side.

    Cells passing the control floor are colored; cells below the floor
    are shown faded grey. The black median line is computed over
    surviving cells only.
    """
    labels = [p.stem.replace("_per_cell", "") for p in per_cells]
    fig, ax = plt.subplots(1, 1, figsize=(1.6 * len(per_cells) + 2, 5))
    cmap = plt.get_cmap("tab10")
    for i, p in enumerate(per_cells):
        df = pd.read_parquet(p)
        rng = np.random.default_rng(i)
        if "passes_control_floor" in df.columns:
            keep = df[df["passes_control_floor"]]["delta_organelle_minus_sensor_min"].to_numpy(dtype=float)
            drop = df[~df["passes_control_floor"]]["delta_organelle_minus_sensor_min"].to_numpy(dtype=float)
            x_keep = np.full(len(keep), i) + rng.uniform(-0.12, 0.12, len(keep))
            x_drop = np.full(len(drop), i) + rng.uniform(-0.12, 0.12, len(drop))
            ax.scatter(x_drop, drop, alpha=0.25, color="grey", edgecolors="none", s=22, label="below floor" if i == 0 else None)
            ax.scatter(x_keep, keep, alpha=0.7, color=cmap(i), edgecolors="black", linewidths=0.3, s=32)
            if len(keep) > 0:
                ax.hlines(np.median(keep), i - 0.25, i + 0.25, color="black", linewidth=2.5, zorder=5)
        else:
            vals = df["delta_organelle_minus_sensor_min"].to_numpy(dtype=float)
            x = np.full(len(vals), i) + rng.uniform(-0.12, 0.12, len(vals))
            ax.scatter(x, vals, alpha=0.6, color=cmap(i), edgecolors="black", linewidths=0.3, s=30)
            if len(vals) > 0:
                ax.hlines(np.median(vals), i - 0.25, i + 0.25, color="black", linewidth=2.5, zorder=5)
    ax.axhline(0, color="grey", linestyle="--", linewidth=1.0)
    ax.set_xticks(range(len(labels)))
    ax.set_xticklabels(labels, fontsize=8, rotation=20, ha="right")
    ax.set_ylabel("Δ (organelle onset − sensor onset)  [min]")
    ax.set_title("Per-cell DTW onset offset (organelle embedding half-rise vs sensor 0.5)")
    ax.grid(axis="y", alpha=0.3)
    fig.tight_layout()
    fig.savefig(out_png, dpi=160, bbox_inches="tight", facecolor="white")
    plt.close(fig)


def _compare_command(args: argparse.Namespace) -> None:
    per_cells = [Path(p) for p in args.per_cell]
    for p in per_cells:
        if not p.exists():
            raise FileNotFoundError(p)
    series = {p.stem.replace("_per_cell", ""): pd.read_parquet(p) for p in per_cells}

    out_md = TIMING_DIR / f"{args.out_stem}.md"
    out_png = TIMING_DIR / f"{args.out_stem}.png"
    TIMING_DIR.mkdir(parents=True, exist_ok=True)

    lines = [
        f"# Compare DTW onset offsets — {args.out_stem}",
        "",
        "| set | n | median Δ [95% CI] (min) | sensor med | organelle med |",
        "|---|---:|---|---:|---:|",
    ]
    for label, df in series.items():
        delta = df["delta_organelle_minus_sensor_min"].to_numpy(dtype=float)
        sensor = df["t_sensor_onset_min"].to_numpy(dtype=float)
        organelle = df["t_organelle_onset_min"].to_numpy(dtype=float)
        d_med, d_lo, d_hi = _bootstrap_median_ci(delta)
        lines.append(
            f"| {label} | {len(delta)} | {d_med:+.0f} [{d_lo:+.0f}, {d_hi:+.0f}] | "
            f"{np.median(sensor):+.0f} | {np.median(organelle):+.0f} |"
        )
    if len(series) == 2:
        keys = list(series.keys())
        a = series[keys[0]]["delta_organelle_minus_sensor_min"].to_numpy(dtype=float)
        b = series[keys[1]]["delta_organelle_minus_sensor_min"].to_numpy(dtype=float)
        u = stats.mannwhitneyu(a, b, alternative="two-sided")
        lines.append("")
        lines.append(f"Mann-Whitney U (two-sided) on Δ: **p = {u.pvalue:.2g}**, U = {u.statistic:.0f}")

    out_md.write_text("\n".join(lines) + "\n")
    _strip_plot(per_cells, out_png)
    _logger.info(f"Wrote {out_md.name}")
    _logger.info(f"Wrote {out_png.name}")


def _binned_curve(
    t: np.ndarray, y: np.ndarray, edges: np.ndarray
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """Per-bin median + IQR + count for a scattered (t, y) signal.

    Returns ``(centers, median, q25, q75, n)`` arrays with NaN where
    a bin has no samples.
    """
    centers = 0.5 * (edges[:-1] + edges[1:])
    n_bins = len(centers)
    med = np.full(n_bins, np.nan)
    q25 = np.full(n_bins, np.nan)
    q75 = np.full(n_bins, np.nan)
    n = np.zeros(n_bins, dtype=int)
    for b in range(n_bins):
        mask = (t >= edges[b]) & (t < edges[b + 1])
        vals = y[mask]
        vals = vals[np.isfinite(vals)]
        n[b] = len(vals)
        if len(vals) >= 3:
            med[b] = float(np.median(vals))
            q25[b] = float(np.percentile(vals, 25))
            q75[b] = float(np.percentile(vals, 75))
    return centers, med, q25, q75


def _population_curve_command(args: argparse.Namespace) -> None:
    """Render per-organelle population-median trajectory of cosine distance.

    For each organelle channel passed via ``--organelle-channel``, joins
    the alignment parquet with the organelle embedding zarr, computes
    cosine distance from the **per-dataset uninfected population mean**,
    and emits:

    - per-cell-frame parquet (``population_curve_{stem}.parquet``)
    - PNG with one panel per organelle channel — infected-population
      median ± IQR vs ``estimated_t_rel_minutes``, with the control
      population median ± IQR overlaid as reference.

    Threshold-crossing summaries (where each curve first crosses
    user-specified absolute distance levels) are written to a
    sidecar markdown.
    """
    parquet_path = Path(args.alignment)
    if not parquet_path.exists():
        raise FileNotFoundError(parquet_path)
    df = pd.read_parquet(parquet_path)
    for col in ["estimated_t_rel_minutes", "alignment_region", "dtw_infection_state"]:
        if col not in df.columns:
            raise KeyError(f"required column '{col}' missing from parquet")

    config = load_stage_config(args.datasets, args.config)
    dataset_cfgs = {d["dataset_id"]: d for d in config["datasets"]}

    if args.dataset_id:
        df = df[df["dataset_id"] == args.dataset_id]

    TIMING_DIR.mkdir(parents=True, exist_ok=True)
    edges = np.linspace(args.t_min, args.t_max, args.n_bins + 1)

    fig, axes = plt.subplots(
        len(args.organelle_channel), 1, figsize=(8, 3.0 * len(args.organelle_channel)), sharex=True, squeeze=False
    )
    cmap = plt.get_cmap("tab10")
    rows = []

    threshold_lines: list[str] = ["| organelle | curve | threshold | t_rel where crossed |", "|---|---|---:|---:|"]

    for chan_i, channel in enumerate(args.organelle_channel):
        organelle_pattern = config["embeddings"][channel]
        ds_ids = sorted(df["dataset_id"].unique().tolist())
        _logger.info(f"[{channel}] computing per-dataset population baselines")
        baselines = _load_population_baselines(dataset_cfgs, organelle_pattern, ds_ids, args.control_perturbation)
        if not baselines:
            _logger.warning(f"[{channel}] no baselines available — skipping")
            continue

        _logger.info(f"[{channel}] joining infected-cell organelle embeddings")
        joined_inf = _join_organelle_embedding(df, dataset_cfgs, organelle_pattern)
        d_inf = _cosine_distance_from_baseline(joined_inf, baselines=baselines)
        joined_inf = joined_inf.assign(distance=d_inf)
        # Use ALL frames on the warped axis — pre/aligned/post — to capture organelle response
        # outside the aligned window. estimated_t_rel_minutes for pre/post is extrapolated using
        # time_calibration[0] / time_calibration[-1] as anchors (Stage 2 convention).
        if args.cost_filter is not None:
            n_before = joined_inf.groupby(["dataset_id", "fov_name", "track_id"]).ngroups
            joined_inf = joined_inf[joined_inf["length_normalized_cost"] <= args.cost_filter]
            n_after = joined_inf.groupby(["dataset_id", "fov_name", "track_id"]).ngroups
            _logger.info(
                f"[{channel}] cost filter (length_normalized_cost ≤ {args.cost_filter}): "
                f"{n_after}/{n_before} cells retained"
            )

        # Anchor each cell at its sensor onset (real-time), then express every frame
        # (pre/aligned/post) as (t - t_sensor_onset_real) * frame_interval. The aligned
        # region keeps its DTW-warped t_rel; pre/post get a real-time extension where
        # the parquet has NaN. This way we cover the full track around the sensor anchor.
        joined_inf = joined_inf.copy()
        for ds_id in joined_inf["dataset_id"].unique():
            ds_cfg = dataset_cfgs[ds_id]
            frame_int = float(ds_cfg["frame_interval_minutes"])
            ds_mask = joined_inf["dataset_id"] == ds_id
            for (_, fov, tid), grp in joined_inf[ds_mask].groupby(["dataset_id", "fov_name", "track_id"], sort=False):
                aligned = grp[grp["alignment_region"] == "aligned"]
                if aligned.empty:
                    continue
                # First aligned frame where dtw_infection_state crosses 0.5 = sensor onset.
                ordered = aligned.sort_values("t")
                t_aligned = ordered["t"].astype(int).to_numpy()
                inf_state = ordered["dtw_infection_state"].to_numpy(dtype=float)
                cross_idx = int(np.argmax(inf_state >= 0.5)) if (inf_state >= 0.5).any() else -1
                if cross_idx < 0:
                    continue
                t_onset_real = int(t_aligned[cross_idx])
                # Fill NaN pre/post t_rel with real-time-anchored values.
                idx = grp.index.to_numpy()
                t_real = grp["t"].astype(int).to_numpy()
                t_rel_existing = grp["estimated_t_rel_minutes"].to_numpy(dtype=float)
                t_rel_filled = np.where(
                    np.isfinite(t_rel_existing),
                    t_rel_existing,
                    (t_real - t_onset_real) * frame_int,
                )
                joined_inf.loc[idx, "estimated_t_rel_minutes"] = t_rel_filled

        t_inf = joined_inf["estimated_t_rel_minutes"].to_numpy(dtype=float)
        y_inf = joined_inf["distance"].to_numpy(dtype=float)
        regions_inf = joined_inf["alignment_region"].to_numpy()

        _logger.info(f"[{channel}] computing control-population per-frame distances")
        ctrl_rows = []
        for ds_id in ds_ids:
            ds_cfg = dataset_cfgs[ds_id]
            prefix = date_prefix_from_dataset_id(ds_id)
            zarr_path = find_embedding_zarr(ds_cfg["pred_dir"], prefix + organelle_pattern)
            adata = ad.read_zarr(zarr_path)
            adata.obs_names_make_unique()
            obs = adata.obs.reset_index(drop=True)
            ctrl_mask = (obs["perturbation"].astype(str) == args.control_perturbation).to_numpy()
            if not ctrl_mask.any() or ds_id not in baselines:
                continue
            X = adata.X
            if hasattr(X, "toarray"):
                X = X.toarray()
            X = np.asarray(X, dtype=np.float64)
            ctrl_emb = X[ctrl_mask]
            baseline = baselines[ds_id]
            bn = np.linalg.norm(baseline)
            en = np.linalg.norm(ctrl_emb, axis=1)
            denom = bn * en
            cos_sim = np.where(denom > 0, (ctrl_emb @ baseline) / np.where(denom > 0, denom, 1.0), 0.0)
            d_ctrl = 1.0 - cos_sim
            # Place each control frame uniformly across [t_min, t_max] for a flat reference line.
            # We DON'T have a t_rel for controls — they have no infection event. Use frame "t" within
            # each track recentered to the mid-window.
            obs_ctrl = obs[ctrl_mask].copy()
            obs_ctrl["distance_pop"] = d_ctrl
            ctrl_rows.append(obs_ctrl)
        ctrl_all = pd.concat(ctrl_rows, ignore_index=True) if ctrl_rows else pd.DataFrame()

        ax = axes[chan_i, 0]
        if len(t_inf) > 0:
            # Full trajectory (all regions) — solid line.
            mask_all = np.isfinite(t_inf) & np.isfinite(y_inf)
            centers_i, med_i, q25_i, q75_i = _binned_curve(t_inf[mask_all], y_inf[mask_all], edges)
            ok = np.isfinite(med_i)
            ax.plot(
                centers_i[ok], med_i[ok], color=cmap(chan_i), linewidth=2.0,
                label=f"infected median ± IQR (all regions, n_frames={int(mask_all.sum()):,})",
            )
            ax.fill_between(centers_i[ok], q25_i[ok], q75_i[ok], color=cmap(chan_i), alpha=0.25)

            # Aligned-only median — dashed darker line so reader can see what changes when pre/post are added.
            aligned_mask = mask_all & (regions_inf == "aligned")
            if aligned_mask.any():
                centers_a, med_a, _, _ = _binned_curve(t_inf[aligned_mask], y_inf[aligned_mask], edges)
                ok_a = np.isfinite(med_a)
                ax.plot(
                    centers_a[ok_a], med_a[ok_a],
                    color=cmap(chan_i), linewidth=1.2, linestyle="--", alpha=0.85,
                    label=f"aligned-only median (n_frames={int(aligned_mask.sum()):,})",
                )

            for thr in args.thresholds:
                cross = _first_crossing(centers_i[ok], med_i[ok], thr)
                rows.append(
                    {"organelle_channel": channel, "curve": "infected_all", "threshold": thr, "t_cross_min": cross}
                )
                threshold_lines.append(
                    f"| {channel} | infected_all | {thr:.2f} | {cross:+.0f} min |"
                    if np.isfinite(cross)
                    else f"| {channel} | infected_all | {thr:.2f} | (not crossed) |"
                )

        if not ctrl_all.empty:
            d_ctrl_all = ctrl_all["distance_pop"].to_numpy(dtype=float)
            ctrl_med = float(np.nanmedian(d_ctrl_all))
            ctrl_q25 = float(np.nanpercentile(d_ctrl_all, 25))
            ctrl_q75 = float(np.nanpercentile(d_ctrl_all, 75))
            ax.axhspan(ctrl_q25, ctrl_q75, color="grey", alpha=0.15)
            ax.axhline(ctrl_med, color="grey", linestyle="--", linewidth=1.0, label=f"control population median (n_frames={len(d_ctrl_all):,})")
            for thr in args.thresholds:
                rows.append(
                    {"organelle_channel": channel, "curve": "control", "threshold": thr, "t_cross_min": float("nan")}
                )

        ax.axvline(0, color="red", linestyle=":", linewidth=1.0, alpha=0.6)
        ax.set_ylabel(f"{channel}\ncos dist from control μ")
        ax.set_title(f"{channel} — population-baseline cosine distance vs DTW pseudotime", fontsize=10)
        ax.grid(alpha=0.3)
        ax.legend(fontsize=8, frameon=False, loc="best")

    axes[-1, 0].set_xlabel("estimated_t_rel_minutes (sensor DTW pseudotime)")
    fig.suptitle(f"Population-curve organelle remodeling — {args.out_stem}", fontsize=11)
    fig.tight_layout(rect=(0, 0, 1, 0.96))
    out_png = TIMING_DIR / f"population_curve_{args.out_stem}.png"
    fig.savefig(out_png, dpi=160, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    _logger.info(f"Wrote {out_png.name}")

    out_csv = TIMING_DIR / f"population_curve_{args.out_stem}_thresholds.csv"
    pd.DataFrame(rows).to_csv(out_csv, index=False)
    out_md = TIMING_DIR / f"population_curve_{args.out_stem}.md"
    out_md.write_text(
        f"# Population curve thresholds — {args.out_stem}\n\n"
        + "\n".join(threshold_lines)
        + "\n\nThreshold = absolute cosine distance from per-dataset uninfected population mean.\n"
        + "`t_cross_min` is the first `estimated_t_rel_minutes` where the infected-population median crosses the threshold.\n"
    )
    _logger.info(f"Wrote {out_md.name}")
    _logger.info(f"Wrote {out_csv.name}")


def main() -> None:
    parser = argparse.ArgumentParser(description="Per-cell DTW onset offset (sensor vs organelle)")
    sub = parser.add_subparsers(dest="cmd", required=True)

    p_compute = sub.add_parser("compute", help="Compute per-cell sensor and organelle onsets")
    p_compute.add_argument("--datasets", required=True, help="datasets.yaml")
    p_compute.add_argument("--config", required=True, help="align_cells.yaml")
    p_compute.add_argument("--alignment", required=True, help="Stage 2a alignment parquet")
    p_compute.add_argument(
        "--organelle-channel",
        required=True,
        choices=["organelle_sec61", "organelle_g3bp1", "phase"],
        help="Channel key in datasets.yaml::embeddings",
    )
    p_compute.add_argument("--dataset-id", default="", help="Optional dataset_id filter")
    p_compute.add_argument("--out-stem", required=True)
    p_compute.add_argument(
        "--baseline-mode",
        choices=["per_cell_pre", "population"],
        default="per_cell_pre",
        help=(
            "How to compute the cosine-distance baseline. "
            "'per_cell_pre' = each cell's own mean pre-event embedding (cancels per-cell appearance "
            "variation but noisy on short tracks). "
            "'population' = per-dataset mean embedding across all uninfected cell-frames "
            "(stable, isolates infection-driven divergence; recommended)."
        ),
    )
    p_compute.add_argument(
        "--use-control-floor",
        action="store_true",
        help="Compute delta_peak on uninfected cells and use it as the noise floor for filtering",
    )
    p_compute.add_argument(
        "--control-perturbation",
        default="uninfected",
        help="Value of obs.perturbation that identifies control cells (default: uninfected)",
    )
    p_compute.add_argument(
        "--floor-percentile",
        type=int,
        choices=[50, 75, 90, 95],
        default=95,
        help="Percentile of control delta_peak to use as the floor cutoff (default: 95)",
    )
    p_compute.add_argument(
        "--min-control-track-length",
        type=int,
        default=4,
        help="Minimum frames per control track (filters tiny tracks where delta_peak is noise)",
    )
    p_compute.set_defaults(func=_compute_command)

    p_compare = sub.add_parser("compare", help="Compare two or more per-cell parquets")
    p_compare.add_argument("--per-cell", nargs="+", required=True)
    p_compare.add_argument("--out-stem", required=True)
    p_compare.set_defaults(func=_compare_command)

    p_pop = sub.add_parser(
        "population-curve",
        help="Render per-organelle population-median trajectories vs DTW pseudotime",
    )
    p_pop.add_argument("--datasets", required=True)
    p_pop.add_argument("--config", required=True)
    p_pop.add_argument("--alignment", required=True, help="Stage 2a alignment parquet")
    p_pop.add_argument(
        "--organelle-channel",
        nargs="+",
        required=True,
        help="One or more channel keys in datasets.yaml::embeddings (e.g. organelle_sec61 organelle_g3bp1)",
    )
    p_pop.add_argument("--dataset-id", default="")
    p_pop.add_argument("--control-perturbation", default="uninfected")
    p_pop.add_argument("--t-min", type=float, default=-300.0)
    p_pop.add_argument("--t-max", type=float, default=300.0)
    p_pop.add_argument("--n-bins", type=int, default=20)
    p_pop.add_argument(
        "--thresholds",
        nargs="+",
        type=float,
        default=[0.05, 0.10, 0.20],
        help="Absolute cosine-distance thresholds for first-crossing summary",
    )
    p_pop.add_argument(
        "--cost-filter",
        type=float,
        default=None,
        help="If set, drop cells with length_normalized_cost > this value (DTW match quality gate)",
    )
    p_pop.add_argument("--out-stem", required=True)
    p_pop.set_defaults(func=_population_curve_command)

    args = parser.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
