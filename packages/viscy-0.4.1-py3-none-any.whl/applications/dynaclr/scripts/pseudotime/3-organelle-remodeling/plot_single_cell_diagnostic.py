"""Per-cell diagnostic plot for one (or a few) curated cells.

Produces a 5-panel figure per cell on the **sensor-DTW pseudotime axis**
so we can spot-check whether the cell's individual trajectory matches
what the population plot claims:

1. Sensor cosine distance from per-cell pre-baseline    (sensor_channel)
2. Organelle cosine distance from per-cell pre-baseline  (--organelle-channel)
3. Organelle PC1/PC2 (post-hoc PCA on this cell's aligned-region embeddings)
4. organelle_state human + LC predictions (per-frame, scatter)
5. infection_state human + LC + DTW-propagated (per-frame, scatter)

Vertical reference lines on every panel:

- **Solid red @ t=0**: DTW-derived sensor onset (`dtw_infection_state` first ≥ 0.5).
- **Dashed grey @ annotated t**: human `infection_state` first `infected` if labels
  are present in the parquet.

Inputs come from the Stage 2a alignment parquet (sensor channel) + the
organelle channel zarr. The per-cell list is supplied via ``--cells``
(repeatable: ``dataset_id:fov_name:track_id``).

Usage::

    cd applications/dynaclr/scripts/pseudotime/3-organelle-remodeling
    uv run python plot_single_cell_diagnostic.py \\
        --datasets ../../../configs/pseudotime/datasets.yaml \\
        --config ../../../configs/pseudotime/align_cells.yaml \\
        --alignment ../2-align_cells/alignments/infection_nondividing_sensor_raw_on_sensor_all_07_24.parquet \\
        --organelle-channel organelle_sec61 \\
        --cells "2025_07_24_SEC61:A/2/001001:87" \\
                "2025_07_24_SEC61:A/2/001001:84" \\
                "2025_07_24_SEC61:A/2/000001:86" \\
        --out-stem sec61_top_remodelers
"""

from __future__ import annotations

import argparse
import logging
import sys
from pathlib import Path

import anndata as ad
import matplotlib
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.decomposition import PCA

from dynaclr.pseudotime import date_prefix_from_dataset_id, find_embedding_zarr

matplotlib.use("Agg")

SCRIPT_DIR = Path(__file__).resolve().parent
PLOTS_DIR = SCRIPT_DIR / "plots" / "single_cell"

sys.path.insert(0, str(SCRIPT_DIR.parent))
from utils import load_stage_config  # noqa: E402

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(levelname)s %(message)s")
_logger = logging.getLogger(__name__)


def _parse_cell_spec(s: str) -> tuple[str, str, int]:
    """Split ``"dataset_id:fov_name:track_id"`` into a tuple."""
    parts = s.split(":")
    if len(parts) != 3:
        raise ValueError(f"--cells entry must be 'dataset_id:fov_name:track_id', got '{s}'")
    return parts[0], parts[1], int(parts[2])


def _channel_embedding(
    dataset_cfg: dict, embedding_pattern: str, fov_name: str, track_id: int
) -> tuple[pd.DataFrame, np.ndarray]:
    """Return (track obs, embedding matrix) for a single cell from a channel zarr.

    Filters obs to the requested ``(fov_name, track_id)``. Drops duplicate
    rows on ``t``. Sorts by ``t``. The embedding matrix is aligned with the
    returned obs row-for-row.
    """
    prefix = date_prefix_from_dataset_id(dataset_cfg["dataset_id"])
    zarr_path = find_embedding_zarr(dataset_cfg["pred_dir"], prefix + embedding_pattern)
    adata = ad.read_zarr(zarr_path)
    adata.obs_names_make_unique()
    obs = adata.obs.reset_index(drop=True).copy()
    obs["fov_name"] = obs["fov_name"].astype(str)
    obs["track_id"] = obs["track_id"].astype(int)
    obs["t"] = obs["t"].astype(int)
    mask = (obs["fov_name"] == fov_name) & (obs["track_id"] == track_id)
    if not mask.any():
        raise KeyError(f"track ({fov_name}, {track_id}) not found in {zarr_path.name}")
    sub_obs = obs[mask].drop_duplicates(subset=["t"]).sort_values("t").reset_index(drop=True)
    X = adata.X
    if hasattr(X, "toarray"):
        X = X.toarray()
    X = np.asarray(X, dtype=np.float64)
    sub_X = X[obs.index.isin(sub_obs.index)]  # not enough — use mask + sort
    # simpler: re-derive indices from full obs after dedup
    sub_idx = obs[mask].drop_duplicates(subset=["t"]).sort_values("t").index.to_numpy()
    sub_X = X[sub_idx]
    return sub_obs, sub_X


def _cosine_distance(emb: np.ndarray, baseline: np.ndarray) -> np.ndarray:
    """Cosine distance from each row of ``emb`` to ``baseline``."""
    bn = np.linalg.norm(baseline)
    en = np.linalg.norm(emb, axis=1)
    denom = bn * en
    cos_sim = np.where(denom > 0, (emb @ baseline) / np.where(denom > 0, denom, 1.0), 0.0)
    return 1.0 - cos_sim


def _attach_t_rel(track_obs: pd.DataFrame, parquet_rows: pd.DataFrame, frame_interval: float) -> pd.DataFrame:
    """Merge sensor-parquet's per-frame ``estimated_t_rel_minutes`` and region onto a track.

    Frames in ``track_obs`` not present in the parquet (outside the
    parquet's pre/aligned/post window for this cell) get NaN t_rel and
    region "out_of_window".

    For frames the parquet has marked pre/post (where ``estimated_t_rel_minutes``
    is NaN), we fill in real-time anchored at the cell's sensor onset
    (first frame where ``dtw_infection_state`` ≥ 0.5 in the parquet's
    aligned region).
    """
    out = track_obs.merge(
        parquet_rows[["t", "estimated_t_rel_minutes", "alignment_region", "dtw_infection_state"]],
        on="t",
        how="left",
    )
    out["alignment_region"] = out["alignment_region"].fillna("out_of_window")
    aligned = out[out["alignment_region"] == "aligned"].sort_values("t")
    onset_t: int | None = None
    if not aligned.empty:
        inf_state = aligned["dtw_infection_state"].to_numpy(dtype=float)
        if np.any(inf_state >= 0.5):
            onset_t = int(aligned["t"].iloc[int(np.argmax(inf_state >= 0.5))])
    if onset_t is None:
        return out
    fill = (out["t"].astype(int).to_numpy() - onset_t) * frame_interval
    have = out["estimated_t_rel_minutes"].to_numpy(dtype=float)
    out["estimated_t_rel_minutes"] = np.where(np.isfinite(have), have, fill)
    out.attrs["sensor_onset_t"] = onset_t
    return out


def _attach_t_rel_from_annotation(
    track_obs: pd.DataFrame, frame_interval: float, anchor_label: str = "infection_state", anchor_positive: str = "infected"
) -> pd.DataFrame:
    """Fallback when a cell isn't in the DTW alignment parquet.

    Anchors t=0 at the **first human-annotated positive frame** of
    ``anchor_label``. Every frame in ``track_obs`` gets a real-time
    ``estimated_t_rel_minutes``; ``alignment_region`` is set to
    ``"unaligned"`` for the whole track so the plot shows that DTW
    wasn't used.
    """
    out = track_obs.copy()
    out["alignment_region"] = "unaligned"
    out["dtw_infection_state"] = np.nan
    if anchor_label not in out.columns:
        out["estimated_t_rel_minutes"] = np.nan
        return out
    pos_mask = out[anchor_label].astype(str) == anchor_positive
    if not pos_mask.any():
        out["estimated_t_rel_minutes"] = np.nan
        return out
    onset_t = int(out.sort_values("t").loc[pos_mask, "t"].iloc[0])
    out["estimated_t_rel_minutes"] = (out["t"].astype(int) - onset_t) * frame_interval
    out.attrs["sensor_onset_t"] = onset_t
    out.attrs["fallback_anchor"] = "annotation"
    return out


def _plot_one_cell(
    sensor_obs: pd.DataFrame,
    sensor_X: np.ndarray,
    org_obs: pd.DataFrame,
    org_X: np.ndarray,
    parquet_rows: pd.DataFrame,
    cell_label: str,
    organelle_channel: str,
    frame_interval: float,
    out_path: Path,
) -> None:
    """Render the 5-panel diagnostic for one cell to ``out_path``.

    Sensor and organelle obs may have *different* frame coverage (the
    organelle zarr is restricted to its imaging well). Both are merged
    onto the parquet's t_rel axis independently.
    """
    if parquet_rows is None or parquet_rows.empty:
        sensor_attached = _attach_t_rel_from_annotation(sensor_obs, frame_interval)
        org_attached = _attach_t_rel_from_annotation(org_obs, frame_interval)
    else:
        sensor_attached = _attach_t_rel(sensor_obs, parquet_rows, frame_interval)
        org_attached = _attach_t_rel(org_obs, parquet_rows, frame_interval)

    # Per-cell pre-baseline = mean of "pre" frames; fall back to earliest
    # 25% of "aligned" frames if no pre.
    def _baseline(obs: pd.DataFrame, X: np.ndarray) -> np.ndarray | None:
        regions = obs["alignment_region"].to_numpy()
        if (regions == "pre").any():
            return X[regions == "pre"].mean(axis=0)
        ali = (regions == "aligned").nonzero()[0]
        if len(ali) == 0:
            return None
        n = max(1, len(ali) // 4)
        return X[ali[:n]].mean(axis=0)

    sensor_baseline = _baseline(sensor_attached, sensor_X)
    org_baseline = _baseline(org_attached, org_X)

    sensor_dist = _cosine_distance(sensor_X, sensor_baseline) if sensor_baseline is not None else np.full(len(sensor_X), np.nan)
    org_dist = _cosine_distance(org_X, org_baseline) if org_baseline is not None else np.full(len(org_X), np.nan)

    # Organelle PCA (just on this cell — useful for shape-of-trajectory inspection).
    n_pcs = min(2, org_X.shape[0], org_X.shape[1])
    if n_pcs >= 2 and len(org_X) >= 2:
        pca = PCA(n_components=2)
        org_pcs = pca.fit_transform(org_X)
        evr = pca.explained_variance_ratio_ * 100.0
    else:
        org_pcs = np.full((len(org_X), 2), np.nan)
        evr = np.array([0.0, 0.0])

    # Per-frame label sources for organelle and infection states.
    def _label_series(obs: pd.DataFrame, col: str, positive: str) -> tuple[np.ndarray, np.ndarray]:
        if col not in obs.columns:
            return obs["estimated_t_rel_minutes"].to_numpy(dtype=float), np.full(len(obs), np.nan)
        vals = obs[col].astype(str)
        mask = vals != "nan"
        x = obs.loc[mask, "estimated_t_rel_minutes"].to_numpy(dtype=float)
        y = (vals[mask] == positive).astype(float).to_numpy()
        return x, y

    fig, axes = plt.subplots(5, 1, figsize=(9, 13), sharex=True)

    region_colors = {
        "pre": "grey",
        "aligned": "tab:blue",
        "post": "tab:red",
        "out_of_window": "lightgrey",
        "unaligned": "tab:orange",
    }

    def _scatter(ax, obs: pd.DataFrame, y: np.ndarray, ylabel: str) -> None:
        regions = obs["alignment_region"].to_numpy()
        x = obs["estimated_t_rel_minutes"].to_numpy(dtype=float)
        for region, color in region_colors.items():
            m = regions == region
            if m.any():
                ax.scatter(x[m], y[m], s=30, color=color, alpha=0.85, edgecolors="black", linewidths=0.4, label=region)
        ax.set_ylabel(ylabel)
        ax.grid(alpha=0.3)

    _scatter(axes[0], sensor_attached, sensor_dist, "sensor cos-dist\nfrom pre-baseline")
    axes[0].plot(sensor_attached["estimated_t_rel_minutes"], sensor_dist, color="black", linewidth=0.8, alpha=0.5)

    _scatter(axes[1], org_attached, org_dist, f"organelle cos-dist\nfrom pre-baseline\n({organelle_channel})")
    axes[1].plot(org_attached["estimated_t_rel_minutes"], org_dist, color="black", linewidth=0.8, alpha=0.5)

    # PC1 vs t
    _scatter(axes[2], org_attached, org_pcs[:, 0], f"organelle PC1\n({evr[0]:.1f}% var)")
    if not np.all(np.isnan(org_pcs[:, 1])):
        ax2b = axes[2].twinx()
        ax2b.plot(org_attached["estimated_t_rel_minutes"], org_pcs[:, 1], color="purple", linewidth=1.0, alpha=0.5)
        ax2b.set_ylabel(f"PC2 ({evr[1]:.1f}%)", color="purple")
        ax2b.tick_params(axis="y", labelcolor="purple")

    # organelle_state labels
    ax3 = axes[3]
    if "organelle_state" in org_attached.columns:
        x_h, y_h = _label_series(org_attached, "organelle_state", "remodel")
        ax3.scatter(x_h, y_h, color="#c0392b", s=45, marker="D", label="human (remodel=1)", zorder=3)
    if "predicted_organelle_state" in org_attached.columns:
        x_p, y_p = _label_series(org_attached, "predicted_organelle_state", "remodel")
        ax3.scatter(x_p, y_p, color="#2980b9", s=20, marker="o", alpha=0.7, label="predicted (LC)")
    ax3.set_ylabel("organelle_state\n(0/1)")
    ax3.set_yticks([0, 1])
    ax3.set_ylim(-0.15, 1.15)
    ax3.grid(alpha=0.3)
    ax3.legend(fontsize=7, frameon=False, loc="best")

    # infection_state labels
    ax4 = axes[4]
    if "infection_state" in sensor_attached.columns:
        x_h, y_h = _label_series(sensor_attached, "infection_state", "infected")
        ax4.scatter(x_h, y_h, color="#c0392b", s=45, marker="D", label="human (infected=1)", zorder=3)
    if "predicted_infection_state" in sensor_attached.columns:
        x_p, y_p = _label_series(sensor_attached, "predicted_infection_state", "infected")
        ax4.scatter(x_p, y_p, color="#2980b9", s=20, marker="o", alpha=0.7, label="predicted (LC)")
    if "dtw_infection_state" in parquet_rows.columns:
        ali = parquet_rows.dropna(subset=["estimated_t_rel_minutes", "dtw_infection_state"])
        if not ali.empty:
            ax4.plot(
                ali["estimated_t_rel_minutes"],
                ali["dtw_infection_state"],
                color="grey",
                linestyle=":",
                linewidth=1.3,
                label="dtw-propagated",
            )
    ax4.set_ylabel("infection_state\n(0/1)")
    ax4.set_yticks([0, 1])
    ax4.set_ylim(-0.15, 1.15)
    ax4.set_xlabel("estimated_t_rel_minutes (sensor-aligned)")
    ax4.grid(alpha=0.3)
    ax4.legend(fontsize=7, frameon=False, loc="best")

    # Vertical reference lines on every panel.
    for ax in axes:
        ax.axvline(0, color="red", linestyle="-", linewidth=1.0, alpha=0.7)
        # Mark annotated infection onset if available.
        if "infection_state" in sensor_attached.columns:
            ann = sensor_attached[sensor_attached["infection_state"].astype(str) == "infected"].sort_values("t")
            if not ann.empty:
                t_ann = float(ann["estimated_t_rel_minutes"].iloc[0])
                if np.isfinite(t_ann):
                    ax.axvline(t_ann, color="grey", linestyle="--", linewidth=1.0, alpha=0.6)

    axes[0].legend(fontsize=8, frameon=False, loc="best")
    fig.suptitle(
        f"{cell_label}  ·  organelle={organelle_channel}\n"
        f"red @ 0 = DTW sensor onset · grey -- = annotated first 'infected'",
        fontsize=11,
    )
    fig.tight_layout(rect=(0, 0, 1, 0.96))
    out_path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(out_path, dpi=150, bbox_inches="tight", facecolor="white")
    plt.close(fig)


def main() -> None:
    parser = argparse.ArgumentParser(description="Per-cell diagnostic plot")
    parser.add_argument("--datasets", required=True)
    parser.add_argument("--config", required=True)
    parser.add_argument("--alignment", required=True, help="Stage 2a alignment parquet")
    parser.add_argument(
        "--organelle-channel",
        required=True,
        choices=["organelle_sec61", "organelle_g3bp1", "phase"],
    )
    parser.add_argument(
        "--sensor-channel",
        default="sensor",
        help="Channel key in datasets.yaml::embeddings (default: sensor)",
    )
    parser.add_argument(
        "--cells",
        nargs="+",
        required=True,
        help="One or more cells: dataset_id:fov_name:track_id",
    )
    parser.add_argument("--out-stem", required=True)
    args = parser.parse_args()

    config = load_stage_config(args.datasets, args.config)
    dataset_cfgs = {d["dataset_id"]: d for d in config["datasets"]}
    sensor_pattern = config["embeddings"][args.sensor_channel]
    org_pattern = config["embeddings"][args.organelle_channel]

    parquet = pd.read_parquet(args.alignment)
    parquet["fov_name"] = parquet["fov_name"].astype(str)
    parquet["track_id"] = parquet["track_id"].astype(int)
    parquet["t"] = parquet["t"].astype(int)

    for spec in args.cells:
        dataset_id, fov_name, track_id = _parse_cell_spec(spec)
        cell_label = f"{dataset_id}|{fov_name}|t={track_id}"
        _logger.info(f"--- {cell_label} ---")
        rows = parquet[
            (parquet["dataset_id"] == dataset_id)
            & (parquet["fov_name"] == fov_name)
            & (parquet["track_id"] == track_id)
        ]
        if rows.empty:
            _logger.info("  not in DTW alignment parquet — falling back to annotation-anchored plot")
            rows = pd.DataFrame()

        ds_cfg = dict(dataset_cfgs[dataset_id])
        ds_cfg["dataset_id"] = dataset_id
        frame_interval = float(ds_cfg["frame_interval_minutes"])

        try:
            sensor_obs, sensor_X = _channel_embedding(ds_cfg, sensor_pattern, fov_name, track_id)
        except KeyError as e:
            _logger.warning(f"  sensor track missing: {e}")
            continue
        try:
            org_obs, org_X = _channel_embedding(ds_cfg, org_pattern, fov_name, track_id)
        except KeyError as e:
            _logger.warning(f"  organelle track missing in {args.organelle_channel}: {e}")
            continue

        out_path = (
            PLOTS_DIR
            / f"{args.out_stem}__{dataset_id}_{fov_name.replace('/', '-')}_t{track_id}__{args.organelle_channel}.png"
        )
        _plot_one_cell(
            sensor_obs, sensor_X, org_obs, org_X, rows, cell_label, args.organelle_channel, frame_interval, out_path
        )
        _logger.info(f"  Wrote {out_path.relative_to(SCRIPT_DIR)}")


if __name__ == "__main__":
    main()
