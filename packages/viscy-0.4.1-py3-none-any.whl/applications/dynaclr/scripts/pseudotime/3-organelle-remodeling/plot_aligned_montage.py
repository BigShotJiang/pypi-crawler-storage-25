r"""Aligned realtime image montage for organelle channels (Stage 3 companion).

Same structure as ``2-align_cells/plot_top_n_montage.py``: rows = top/worst
cells by length-normalized sensor DTW cost, columns = evenly-spaced real-time
offsets anchored at each cell's warped t=0. This version pulls the
*organelle* fluorescence channel from the shared data zarr instead of the
sensor channel, so you can visually inspect whether the aligned-window
frames really do show the expected organelle remodeling.

Cell centroids still come from the sensor embedding zarr (same ``(x, y)``
as Stage 2c), because the sensor template built the alignment and its
cell coordinates are what we want to follow on the image. The only
difference from Stage 2c is which zarr *channel* we read for the crop.

Usage::

    cd applications/dynaclr/scripts/pseudotime/3-organelle-remodeling
    uv run python plot_aligned_montage.py \
        --datasets ../../../configs/pseudotime/datasets.yaml \
        --config ../../../configs/pseudotime/align_cells.yaml \
        --template infection_nondividing_sensor --flavor raw \
        --query-set sensor_all_07_24 \
        --channel-index 1 --channel-name SEC61-GFP \
        --top-n 20 --worst-n 5
"""

from __future__ import annotations

import argparse
import logging
import sys
from pathlib import Path

import matplotlib
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from anndata import read_zarr
from iohub import open_ome_zarr

matplotlib.use("Agg")

from dynaclr.pseudotime import date_prefix_from_dataset_id, find_embedding_zarr

SCRIPT_DIR = Path(__file__).resolve().parent
ALIGNMENTS_DIR = SCRIPT_DIR.parent / "2-align_cells" / "alignments"
PLOTS_DIR = SCRIPT_DIR / "plots"

sys.path.insert(0, str(SCRIPT_DIR.parent))
from utils import load_stage_config, read_focus_slice  # noqa: E402

_date_prefix_from_dataset_id = date_prefix_from_dataset_id
_find_zarr = find_embedding_zarr

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(levelname)s %(message)s")
_logger = logging.getLogger(__name__)


def _load_xy_lookup(embedding_zarr: str) -> dict[tuple[str, int, int], tuple[int, int]]:
    """Build ``(fov_name, track_id, t) -> (x, y)`` lookup from ``adata.obs``."""
    adata = read_zarr(embedding_zarr)
    adata.obs_names_make_unique()
    obs = adata.obs
    return {
        (str(row["fov_name"]), int(row["track_id"]), int(row["t"])): (int(row["x"]), int(row["y"]))
        for _, row in obs.iterrows()
    }


def _mip_crop(
    img_arr,
    t: int,
    z_center: int,
    y: int,
    x: int,
    channel: int,
    crop_half: int,
    mip_half: int,
) -> np.ndarray | None:
    """MIP over ``[z_center - mip_half, z_center + mip_half]`` slices at (y, x)."""
    if t < 0 or t >= img_arr.shape[0]:
        return None
    if channel < 0 or channel >= img_arr.shape[1]:
        return None
    z0 = max(0, z_center - mip_half)
    z1 = min(img_arr.shape[2], z_center + mip_half + 1)
    if z1 <= z0:
        return None
    y0, y1 = max(0, y - crop_half), min(img_arr.shape[3], y + crop_half)
    x0, x1 = max(0, x - crop_half), min(img_arr.shape[4], x + crop_half)
    stack = np.asarray(img_arr[t, channel, z0:z1, y0:y1, x0:x1])
    return stack.max(axis=0)


def _anchor_frame(cell_rows: pd.DataFrame) -> int | None:
    """Return the query frame whose ``estimated_t_rel_minutes`` is closest to 0 (aligned only)."""
    aligned = cell_rows[cell_rows["alignment_region"] == "aligned"]
    if aligned.empty:
        return None
    return int(aligned.iloc[aligned["estimated_t_rel_minutes"].abs().argmin()]["t"])


def _select_cells(cell_df: pd.DataFrame, top_n: int, worst_n: int) -> pd.DataFrame:
    """Pick top-N + worst-N rows by length-normalized cost, tagged with a ``_band`` column."""
    ordered = cell_df.sort_values("length_normalized_cost").reset_index(drop=True)
    top = ordered.head(top_n).copy()
    top["_band"] = "top"
    if worst_n > 0:
        worst = ordered.tail(worst_n).copy()
        worst["_band"] = "worst"
        return pd.concat([top, worst], ignore_index=True)
    return top


def main() -> None:
    """Render the Stage 3 aligned montage for an organelle fluorescence channel."""
    parser = argparse.ArgumentParser(description="Aligned realtime montage for an organelle channel (Stage 3).")
    parser.add_argument("--datasets", required=True, help="Path to datasets.yaml")
    parser.add_argument("--config", required=True, help="Path to align_cells.yaml")
    parser.add_argument("--template", required=True, help="Sensor template name")
    parser.add_argument("--flavor", choices=["raw", "pca"], default="raw")
    parser.add_argument("--query-set", required=True, help="Sensor query set")
    parser.add_argument("--top-n", type=int, default=20)
    parser.add_argument("--worst-n", type=int, default=5)
    parser.add_argument("--pre-minutes", type=float, default=240.0)
    parser.add_argument("--post-minutes", type=float, default=240.0)
    parser.add_argument("--crop-half", type=int, default=80)
    parser.add_argument("--mip-half", type=int, default=5)
    parser.add_argument(
        "--channel-index",
        type=int,
        required=True,
        help="Index of the organelle fluorescence channel in the data zarr "
        "(e.g. 1 for SEC61-GFP / G3BP1-GFP; confirm with plate.channel_names)",
    )
    parser.add_argument(
        "--channel-name",
        required=True,
        help="Display name for the channel (used in plot title and output filename)",
    )
    parser.add_argument("--focus-channel", default="Phase3D", help="Channel in zattrs.focus_slice")
    parser.add_argument(
        "--sensor-channel-index",
        type=int,
        default=None,
        help="Optional: index of the viral-sensor fluorescence channel in the data zarr "
        "(e.g. 2 for mCherry). When set, a second row per cell shows the sensor crops "
        "stacked under the organelle crops, with the same anchor / remodel overlays.",
    )
    parser.add_argument(
        "--sensor-channel-name",
        default="sensor",
        help="Display name for the sensor channel (used in the row label).",
    )
    parser.add_argument(
        "--organelle-channel",
        default=None,
        help="Key in datasets.yaml:embeddings for the organelle zarr to read the remodel label from "
        "(e.g. 'organelle_sec61'). Omit to skip the orange remodel overlay.",
    )
    parser.add_argument(
        "--truth-column",
        default="organelle_state",
        help="obs column in the organelle zarr carrying the per-frame remodel label.",
    )
    parser.add_argument(
        "--truth-positive",
        default="remodel",
        help="Value of --truth-column that triggers the orange border.",
    )
    args = parser.parse_args()

    config = load_stage_config(args.datasets, args.config)
    dataset_cfgs = {d["dataset_id"]: d for d in config["datasets"]}

    alignment_path = ALIGNMENTS_DIR / f"{args.template}_{args.flavor}_on_{args.query_set}.parquet"
    if not alignment_path.exists():
        raise FileNotFoundError(
            f"Alignment parquet not found: {alignment_path}. Run Stage 2 align_cells.py first."
        )
    _logger.info(f"Reading {alignment_path}")
    df = pd.read_parquet(alignment_path)

    cell_df = df.groupby(["dataset_id", "fov_name", "track_id"], as_index=False).agg(
        length_normalized_cost=("length_normalized_cost", "first"),
    )
    _logger.info(f"  {len(cell_df)} cells in alignment parquet")

    selected = _select_cells(cell_df, args.top_n, args.worst_n)
    n_rows = len(selected)
    _logger.info(f"Selected {n_rows} cells ({args.top_n} top + {args.worst_n} worst)")

    query_cfg = config["query_sets"][args.query_set]
    intervals = [dataset_cfgs[d["dataset_id"]]["frame_interval_minutes"] for d in query_cfg["datasets"]]
    col_step = float(min(intervals))
    time_offsets = np.arange(-args.pre_minutes, args.post_minutes + col_step / 2, col_step)
    n_cols = len(time_offsets)

    data_zarr_by_ds: dict[str, str] = {}
    if "data_zarr" in config:
        default = config["data_zarr"]
        for d in query_cfg["datasets"]:
            data_zarr_by_ds[d["dataset_id"]] = dataset_cfgs[d["dataset_id"]].get("data_zarr", default)

    plate_cache: dict[str, object] = {}
    xy_cache: dict[str, dict] = {}
    position_cache: dict[tuple[str, str], tuple] = {}
    # (dataset_id, fov, track, t) -> bool: True if obs[truth_column] == truth_positive
    remodel_cache: dict[str, dict[tuple[str, int, int], bool]] = {}
    if args.organelle_channel is not None:
        organelle_pattern = config["embeddings"][args.organelle_channel]
        for ds_id_q in {str(c["dataset_id"]) for _, c in selected.iterrows()}:
            ds_cfg_q = dataset_cfgs[ds_id_q]
            try:
                zarr_path = _find_zarr(
                    ds_cfg_q["pred_dir"], _date_prefix_from_dataset_id(ds_id_q) + organelle_pattern
                )
            except FileNotFoundError:
                _logger.warning(f"  [{ds_id_q}] no organelle zarr matching {organelle_pattern!r} — skipping remodel overlay")
                continue
            adata_o = read_zarr(zarr_path)
            adata_o.obs_names_make_unique()
            if args.truth_column not in adata_o.obs.columns:
                _logger.warning(
                    f"  [{ds_id_q}] obs has no {args.truth_column!r} — skipping remodel overlay"
                )
                continue
            remodel_cache[ds_id_q] = {
                (str(row["fov_name"]), int(row["track_id"]), int(row["t"])): str(row[args.truth_column])
                == args.truth_positive
                for _, row in adata_o.obs.iterrows()
            }

    # Number of image rows per cell: organelle row, plus an optional sensor row below.
    show_sensor = args.sensor_channel_index is not None
    rows_per_cell = 2 if show_sensor else 1
    fig_rows = n_rows * rows_per_cell
    fig, axes = plt.subplots(fig_rows, n_cols, figsize=(n_cols * 0.5, fig_rows * 0.5))
    if fig_rows == 1:
        axes = axes[np.newaxis, :]
    if n_cols == 1:
        axes = axes[:, np.newaxis]

    def _render_channel_row(
        img_row_idx: int,
        channel_index: int,
        img_arr,
        position,
        xy_lookup,
        anchor_t: int,
        frame_interval: float,
        aligned_lo: int,
        aligned_hi: int,
        ds_id: str,
        fov: str,
        tid: int,
        is_organelle: bool,
    ) -> None:
        """Render one image row (organelle or sensor) for this cell."""
        for col_idx, offset_min in enumerate(time_offsets):
            ax = axes[img_row_idx, col_idx]
            ax.set_xticks([])
            ax.set_yticks([])

            t_frame = int(round(anchor_t + offset_min / frame_interval))
            faded = not (aligned_lo <= t_frame <= aligned_hi)

            xy = xy_lookup.get((fov, tid, t_frame))
            crop = None
            if xy is not None and img_arr is not None and position is not None:
                x, y = xy
                try:
                    z_center = read_focus_slice(position, args.focus_channel, level="timepoint", timepoint=t_frame)
                except KeyError:
                    z_center = img_arr.shape[2] // 2
                crop = _mip_crop(
                    img_arr,
                    t_frame,
                    int(z_center),
                    y,
                    x,
                    channel_index,
                    args.crop_half,
                    args.mip_half,
                )

            if crop is not None and crop.size > 0:
                vmin, vmax = np.percentile(crop, [2, 98])
                if vmax <= vmin:
                    vmax = vmin + 1
                ax.imshow(crop, cmap="gray", vmin=vmin, vmax=vmax, alpha=0.35 if faded else 1.0)
            else:
                ax.set_facecolor("#e0e0e0")

            is_anchor = abs(offset_min) < col_step / 2
            # Orange remodel border only renders on the organelle row (label lives in organelle zarr).
            is_remodel = is_organelle and remodel_cache.get(ds_id, {}).get((fov, tid, t_frame), False)
            if is_anchor:
                for spine in ax.spines.values():
                    spine.set_visible(True)
                    spine.set_color("red")
                    spine.set_linewidth(1.5)
            elif is_remodel:
                for spine in ax.spines.values():
                    spine.set_visible(True)
                    spine.set_color("#e67e22")
                    spine.set_linewidth(1.5)
            else:
                for spine in ax.spines.values():
                    spine.set_visible(False)

            if img_row_idx == 0:
                ax.set_title(f"{int(offset_min):+d}", fontsize=5)

    for cell_row_idx, (_, cell) in enumerate(selected.iterrows()):
        ds_id = cell["dataset_id"]
        fov = str(cell["fov_name"])
        tid = int(cell["track_id"])
        band = cell["_band"]

        organelle_row = cell_row_idx * rows_per_cell
        sensor_row = organelle_row + 1 if show_sensor else None

        cell_rows = (
            df[(df["dataset_id"] == ds_id) & (df["fov_name"] == fov) & (df["track_id"] == tid)]
            .sort_values("t")
            .reset_index(drop=True)
        )
        anchor_t = _anchor_frame(cell_rows)
        if anchor_t is None:
            for r in ([organelle_row] if sensor_row is None else [organelle_row, sensor_row]):
                for ax in axes[r]:
                    ax.set_facecolor("#f0f0f0")
                    ax.set_xticks([])
                    ax.set_yticks([])
            continue

        if ds_id not in plate_cache:
            plate_cache[ds_id] = open_ome_zarr(data_zarr_by_ds[ds_id], mode="r")
            embedding_pattern = config["embeddings"][query_cfg.get("channel", "sensor")]
            emb_zarr = _find_zarr(
                dataset_cfgs[ds_id]["pred_dir"], _date_prefix_from_dataset_id(ds_id) + embedding_pattern
            )
            xy_cache[ds_id] = _load_xy_lookup(emb_zarr)

        plate = plate_cache[ds_id]
        xy_lookup = xy_cache[ds_id]
        frame_interval = float(dataset_cfgs[ds_id]["frame_interval_minutes"])

        pos_key = (ds_id, fov)
        if pos_key not in position_cache:
            try:
                position = plate[fov]
                img_arr = position["0"]
            except (KeyError, IndexError):
                img_arr, position = None, None
            position_cache[pos_key] = (img_arr, position)
        img_arr, position = position_cache[pos_key]

        aligned_range = cell_rows[cell_rows["alignment_region"] == "aligned"]["t"]
        aligned_lo = int(aligned_range.min()) if not aligned_range.empty else anchor_t
        aligned_hi = int(aligned_range.max()) if not aligned_range.empty else anchor_t

        _render_channel_row(
            organelle_row, args.channel_index, img_arr, position, xy_lookup,
            anchor_t, frame_interval, aligned_lo, aligned_hi, ds_id, fov, tid, is_organelle=True,
        )
        if show_sensor:
            _render_channel_row(
                sensor_row, args.sensor_channel_index, img_arr, position, xy_lookup,
                anchor_t, frame_interval, aligned_lo, aligned_hi, ds_id, fov, tid, is_organelle=False,
            )

        label_color = "green" if band == "top" else "darkred"
        axes[organelle_row, 0].set_ylabel(
            f"{ds_id.split('_')[-1]}\n{fov}\ntrack={tid}\ncost={cell['length_normalized_cost']:.2f}\n[{args.channel_name}]",
            fontsize=4,
            rotation=0,
            labelpad=50,
            va="center",
            color=label_color,
        )
        if show_sensor:
            axes[sensor_row, 0].set_ylabel(
                f"[{args.sensor_channel_name}]",
                fontsize=4,
                rotation=0,
                labelpad=50,
                va="center",
                color=label_color,
            )

    remodel_note = (
        f"  |  orange = {args.truth_column}=={args.truth_positive!r}"
        if args.organelle_channel is not None and remodel_cache
        else ""
    )
    sensor_note = (
        f"  |  top sub-row = {args.channel_name} (ch {args.channel_index}), "
        f"bottom sub-row = {args.sensor_channel_name} (ch {args.sensor_channel_index})"
        if show_sensor
        else ""
    )
    fig.suptitle(
        f"Aligned montage — {args.channel_name} (ch {args.channel_index}) — "
        f"{args.template}/{args.flavor}/{args.query_set}\n"
        f"rows = top {args.top_n} + worst {args.worst_n} cells sorted by length-norm cost  |  "
        f"cols = minutes from warped t=0 (red border)  |  faded = outside aligned window"
        f"{remodel_note}{sensor_note}",
        fontsize=9,
    )
    fig.subplots_adjust(wspace=0.03, hspace=0.05)

    PLOTS_DIR.mkdir(parents=True, exist_ok=True)
    channel_slug = args.channel_name.replace(" ", "_").replace("/", "_")
    out_path = (
        PLOTS_DIR / f"aligned_montage_{args.template}_{args.flavor}_{channel_slug}_{args.query_set}.png"
    )
    fig.savefig(out_path, dpi=200, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    _logger.info(f"Wrote {out_path}")


if __name__ == "__main__":
    main()
