r"""Realtime image montage of top-N (and worst-N) query cells, anchored at warped t=0.

Stage 2c of the pseudotime pipeline. Reads the alignment parquet from
:mod:`align_cells` and the source image zarr, then renders a single PNG:

- Rows = query cells, ranked by ``length_normalized_cost`` ascending.
  Top-N best matches at the top; optional ``--worst-n`` bottom band for
  contrast.
- Columns = evenly-spaced real-time offsets in minutes, anchored at each
  cell's warped ``t=0`` (the query frame closest to
  ``t_rel_minutes_warped = 0``). Red border marks the anchor column.
- Pre/post frames are shown faded (outside the aligned window).

Usage::

    cd applications/dynaclr/scripts/pseudotime/2-align_cells
    uv run python plot_top_n_montage.py \
        --datasets ../../../configs/pseudotime/datasets.yaml \
        --config ../../../configs/pseudotime/align_cells.yaml \
        --template manual_debug_sensor \
        --flavor raw \
        --query-set sensor_manual_debug_qset \
        --top-n 30 --worst-n 10
"""

from __future__ import annotations

import argparse
import logging
import sys
from pathlib import Path

import matplotlib
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from anndata import read_zarr
from iohub import open_ome_zarr

matplotlib.use("Agg")

from dynaclr.pseudotime import date_prefix_from_dataset_id, find_embedding_zarr

SCRIPT_DIR = Path(__file__).resolve().parent
ALIGNMENTS_DIR = SCRIPT_DIR / "alignments"
PLOTS_DIR = SCRIPT_DIR / "plots"

sys.path.insert(0, str(SCRIPT_DIR.parent))
from utils import load_stage_config, read_focus_slice  # noqa: E402

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(levelname)s %(message)s")
_logger = logging.getLogger(__name__)


def _load_xy_lookup(embedding_zarr: str) -> dict[tuple[str, int, int], tuple[int, int]]:
    """Build ``(fov_name, track_id, t) -> (x, y)`` lookup from ``adata.obs``."""
    adata = read_zarr(embedding_zarr)
    adata.obs_names_make_unique()
    obs = adata.obs
    return {
        (str(row["fov_name"]), int(row["track_id"]), int(row["t"])): (
            int(row["x"]),
            int(row["y"]),
        )
        for _, row in obs.iterrows()
    }


def _mip_crop(
    img_arr,
    t: int,
    z_center: int,
    y: int,
    x: int,
    channel: int,
    crop_half: int,
    mip_half: int,
) -> np.ndarray | None:
    """MIP over ``[z_center - mip_half, z_center + mip_half]`` slices at (y, x)."""
    if t < 0 or t >= img_arr.shape[0]:
        return None
    if channel < 0 or channel >= img_arr.shape[1]:
        return None
    z0 = max(0, z_center - mip_half)
    z1 = min(img_arr.shape[2], z_center + mip_half + 1)
    if z1 <= z0:
        return None
    y0, y1 = max(0, y - crop_half), min(img_arr.shape[3], y + crop_half)
    x0, x1 = max(0, x - crop_half), min(img_arr.shape[4], x + crop_half)
    stack = np.asarray(img_arr[t, channel, z0:z1, y0:y1, x0:x1])
    return stack.max(axis=0)


def _anchor_frame(cell_rows: pd.DataFrame) -> int | None:
    """Return the query frame whose ``t_rel_minutes_warped`` is closest to 0.

    Restricted to ``alignment_region == "aligned"``. Returns ``None`` if
    the cell has no aligned frames.
    """
    aligned = cell_rows[cell_rows["alignment_region"] == "aligned"]
    if aligned.empty:
        return None
    return int(aligned.iloc[aligned["t_rel_minutes_warped"].abs().argmin()]["t"])


def _select_cells(
    cell_df: pd.DataFrame,
    top_n: int,
    worst_n: int,
) -> tuple[pd.DataFrame, list[str]]:
    """Pick top-N + worst-N rows and return them with a ``band`` label.

    Returns
    -------
    tuple[pd.DataFrame, list[str]]
        (selected rows ordered top→worst, band labels per row).
    """
    ordered = cell_df.sort_values("length_normalized_cost").reset_index(drop=True)
    top = ordered.head(top_n).copy()
    top["_band"] = "top"
    if worst_n > 0:
        worst = ordered.tail(worst_n).copy()
        worst["_band"] = "worst"
        selected = pd.concat([top, worst], ignore_index=True)
    else:
        selected = top
    return selected, selected["_band"].tolist()


def main() -> None:
    """Render the Stage 2c top/worst-N realtime montage."""
    parser = argparse.ArgumentParser(description="Top/worst-N realtime montage (Stage 2c)")
    parser.add_argument("--datasets", required=True, help="Path to datasets.yaml")
    parser.add_argument("--config", required=True, help="Path to align_cells.yaml")
    parser.add_argument("--template", required=True)
    parser.add_argument("--flavor", choices=["raw", "pca"], default="raw")
    parser.add_argument("--query-set", required=True)
    parser.add_argument("--top-n", type=int, default=20, help="Best-match cells to show")
    parser.add_argument("--worst-n", type=int, default=5, help="Worst-match cells (contrast); 0 disables")
    parser.add_argument(
        "--pre-minutes",
        type=float,
        default=120.0,
        help="Minutes before anchor (t=0) to include",
    )
    parser.add_argument(
        "--post-minutes",
        type=float,
        default=240.0,
        help="Minutes after anchor to include",
    )
    parser.add_argument("--crop-half", type=int, default=80, help="Half side of crop square (px)")
    parser.add_argument("--mip-half", type=int, default=5, help="Half-thickness of the MIP window (z slices)")
    parser.add_argument("--channel-index", type=int, default=2, help="Image-zarr channel index")
    parser.add_argument("--channel-name", default="mCherry", help="Display name for the channel")
    parser.add_argument("--focus-channel", default="Phase3D", help="Channel in zattrs.focus_slice")
    args = parser.parse_args()

    config = load_stage_config(args.datasets, args.config)
    dataset_cfgs = {d["dataset_id"]: d for d in config["datasets"]}

    alignment_path = ALIGNMENTS_DIR / f"{args.template}_{args.flavor}_on_{args.query_set}.parquet"
    if not alignment_path.exists():
        raise FileNotFoundError(f"Alignment parquet not found: {alignment_path}. Run align_cells.py first.")
    _logger.info(f"Reading {alignment_path}")
    df = pd.read_parquet(alignment_path)

    # One row per cell with its ranking cost.
    cell_df = df.groupby(["dataset_id", "fov_name", "track_id"], as_index=False).agg(
        length_normalized_cost=("length_normalized_cost", "first"),
    )
    _logger.info(f"  {len(cell_df)} cells in alignment parquet")

    selected, _ = _select_cells(cell_df, args.top_n, args.worst_n)
    n_rows = len(selected)
    _logger.info(f"Selected {n_rows} cells ({args.top_n} top + {args.worst_n} worst)")

    # Column time axis: evenly-spaced offsets from anchor (minutes).
    query_cfg = config["query_sets"][args.query_set]
    # All datasets in the query set should share a frame interval for a sane shared time axis.
    # If not, fall back to the smallest; render intent is the real-time axis anyway.
    intervals = [dataset_cfgs[d["dataset_id"]]["frame_interval_minutes"] for d in query_cfg["datasets"]]
    col_step = float(min(intervals))
    time_offsets = np.arange(-args.pre_minutes, args.post_minutes + col_step / 2, col_step)
    n_cols = len(time_offsets)

    # Lazy-open one (plate, xy_lookup) per dataset.
    data_zarr_by_ds: dict[str, str] = {}
    if "data_zarr" in config:
        # Fallback: single top-level data_zarr applies to every dataset in the query set.
        # For multi-dataset query sets with distinct image zarrs, add per-dataset ``data_zarr``
        # keys to the dataset entries in datasets.yaml. (Not required for single-dataset sets.)
        default = config["data_zarr"]
        for d in query_cfg["datasets"]:
            data_zarr_by_ds[d["dataset_id"]] = dataset_cfgs[d["dataset_id"]].get("data_zarr", default)

    plate_cache: dict[str, object] = {}
    xy_cache: dict[str, dict] = {}
    position_cache: dict[tuple[str, str], tuple] = {}

    fig, axes = plt.subplots(n_rows, n_cols, figsize=(n_cols * 0.5, n_rows * 0.5))
    if n_rows == 1:
        axes = axes[np.newaxis, :]
    if n_cols == 1:
        axes = axes[:, np.newaxis]

    for row_idx, (_, cell) in enumerate(selected.iterrows()):
        ds_id = cell["dataset_id"]
        fov = str(cell["fov_name"])
        tid = int(cell["track_id"])
        band = cell["_band"]

        # Per-cell rows — sorted by t so frame-axis arithmetic is sane.
        cell_rows = (
            df[(df["dataset_id"] == ds_id) & (df["fov_name"] == fov) & (df["track_id"] == tid)]
            .sort_values("t")
            .reset_index(drop=True)
        )
        anchor_t = _anchor_frame(cell_rows)
        if anchor_t is None:
            for ax in axes[row_idx]:
                ax.set_facecolor("#f0f0f0")
                ax.set_xticks([])
                ax.set_yticks([])
            continue

        # Lazy-load dataset resources the first time we see it.
        if ds_id not in plate_cache:
            plate_cache[ds_id] = open_ome_zarr(data_zarr_by_ds[ds_id], mode="r")
            embedding_pattern = config["embeddings"][query_cfg.get("channel", "sensor")]
            emb_zarr = find_embedding_zarr(
                dataset_cfgs[ds_id]["pred_dir"], date_prefix_from_dataset_id(ds_id) + embedding_pattern
            )
            xy_cache[ds_id] = _load_xy_lookup(emb_zarr)

        plate = plate_cache[ds_id]
        xy_lookup = xy_cache[ds_id]
        frame_interval = float(dataset_cfgs[ds_id]["frame_interval_minutes"])

        pos_key = (ds_id, fov)
        if pos_key not in position_cache:
            try:
                position = plate[fov]
                img_arr = position["0"]
            except (KeyError, IndexError):
                img_arr, position = None, None
            position_cache[pos_key] = (img_arr, position)
        img_arr, position = position_cache[pos_key]

        aligned_range = cell_rows[cell_rows["alignment_region"] == "aligned"]["t"]
        aligned_lo = int(aligned_range.min()) if not aligned_range.empty else anchor_t
        aligned_hi = int(aligned_range.max()) if not aligned_range.empty else anchor_t

        for col_idx, offset_min in enumerate(time_offsets):
            ax = axes[row_idx, col_idx]
            ax.set_xticks([])
            ax.set_yticks([])

            # Convert the real-time offset into an absolute query frame via the
            # dataset's frame interval. May land outside the track.
            t_frame = int(round(anchor_t + offset_min / frame_interval))
            faded = not (aligned_lo <= t_frame <= aligned_hi)

            xy = xy_lookup.get((fov, tid, t_frame))
            crop = None
            if xy is not None and img_arr is not None and position is not None:
                x, y = xy
                try:
                    z_center = read_focus_slice(position, args.focus_channel, level="timepoint", timepoint=t_frame)
                except KeyError:
                    z_center = img_arr.shape[2] // 2
                crop = _mip_crop(
                    img_arr,
                    t_frame,
                    int(z_center),
                    y,
                    x,
                    args.channel_index,
                    args.crop_half,
                    args.mip_half,
                )

            if crop is not None and crop.size > 0:
                vmin, vmax = np.percentile(crop, [2, 98])
                if vmax <= vmin:
                    vmax = vmin + 1
                ax.imshow(crop, cmap="gray", vmin=vmin, vmax=vmax, alpha=0.35 if faded else 1.0)
            else:
                ax.set_facecolor("#e0e0e0")

            if abs(offset_min) < col_step / 2:
                for spine in ax.spines.values():
                    spine.set_visible(True)
                    spine.set_color("red")
                    spine.set_linewidth(1.5)
            else:
                for spine in ax.spines.values():
                    spine.set_visible(False)

            if row_idx == 0:
                ax.set_title(f"{int(offset_min):+d}", fontsize=5)

        label_color = "green" if band == "top" else "darkred"
        axes[row_idx, 0].set_ylabel(
            f"{ds_id.split('_')[-1]}\n{fov}\ntrack={tid}\ncost={cell['length_normalized_cost']:.2f}",
            fontsize=4,
            rotation=0,
            labelpad=50,
            va="center",
            color=label_color,
        )

    fig.suptitle(
        f"Realtime montage — {args.channel_name} (ch {args.channel_index}) — "
        f"{args.template}/{args.flavor}/{args.query_set}\n"
        f"rows = top {args.top_n} + worst {args.worst_n} cells sorted by length-norm cost  |  "
        f"cols = minutes from warped t=0 (red border)  |  faded = outside aligned window",
        fontsize=9,
    )
    fig.subplots_adjust(wspace=0.03, hspace=0.05)

    PLOTS_DIR.mkdir(parents=True, exist_ok=True)
    out_path = PLOTS_DIR / f"realtime_montage_{args.template}_{args.flavor}_{args.query_set}.png"
    fig.savefig(out_path, dpi=200, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    _logger.info(f"Wrote {out_path}")


if __name__ == "__main__":
    main()
