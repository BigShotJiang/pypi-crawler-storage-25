r"""Rank query cells by DTW cost — diagnostic before montage/PC plots.

Stage 2b of the pseudotime pipeline. Reads the alignment parquet produced
by :mod:`align_cells`, reduces it to one row per cell, and renders two
diagnostic plots side-by-side:

- **Histogram of ``length_normalized_cost``** — shows the overall
  distribution of match quality across query cells. Use it to pick a
  cost cutoff for Stage 2c montages.
- **Scatter of ``match_duration_minutes`` vs cost** — a good match
  should cover roughly the template's duration. Cells with very short
  matches but low cost are suspicious (collapsed warp path); cells
  with very long matches are using the full subsequence freedom.

Usage::

    cd applications/dynaclr/scripts/pseudotime/2-align_cells
    uv run python rank_by_cost.py \
        --datasets ../../../configs/pseudotime/datasets.yaml \
        --config ../../../configs/pseudotime/align_cells.yaml \
        --template manual_debug_sensor \
        --flavor raw \
        --query-set sensor_manual_debug_qset
"""

from __future__ import annotations

import argparse
import logging
import sys
from pathlib import Path

import matplotlib
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import zarr

matplotlib.use("Agg")

SCRIPT_DIR = Path(__file__).resolve().parent
TEMPLATES_DIR = SCRIPT_DIR.parent / "1-build_template" / "templates"
ALIGNMENTS_DIR = SCRIPT_DIR / "alignments"
PLOTS_DIR = SCRIPT_DIR / "plots"

sys.path.insert(0, str(SCRIPT_DIR.parent))
from utils import load_stage_config  # noqa: E402

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(levelname)s %(message)s")
_logger = logging.getLogger(__name__)


def _template_duration_minutes(template_path: Path, flavor: str) -> float | None:
    """Return the total real-time span of the template in minutes.

    Computed as ``time_calibration[-1] - time_calibration[0]`` for the
    chosen flavor. Returns ``None`` if the template has no time
    calibration (e.g. build ran without ``t_relative_minutes``).
    """
    store = zarr.open(str(template_path), mode="r")
    if flavor not in store:
        return None
    grp = store[flavor]
    if "time_calibration" not in grp:
        return None
    tc = np.asarray(grp["time_calibration"])
    if tc.size < 2:
        return None
    return float(tc[-1] - tc[0])


def _plot_cost_ranking(
    cell_df: pd.DataFrame,
    template_duration: float | None,
    title: str,
) -> plt.Figure:
    """Render the (histogram, duration-vs-cost scatter) diagnostic figure.

    Parameters
    ----------
    cell_df : pd.DataFrame
        One row per cell with ``length_normalized_cost``,
        ``match_duration_minutes``, and ``dataset_id`` columns.
    template_duration : float or None
        Template duration in minutes; drawn as a reference line on the
        scatter plot when available.
    title : str
        Figure-level title (``{template} / {flavor} / {query_set}``).
    """
    fig, (ax_hist, ax_scatter) = plt.subplots(1, 2, figsize=(12, 4.5))

    # Histogram of length-normalized cost
    costs = cell_df["length_normalized_cost"].to_numpy()
    ax_hist.hist(costs, bins=30, color="steelblue", edgecolor="white")
    ax_hist.set_xlabel("length-normalized DTW cost")
    ax_hist.set_ylabel("n cells")
    ax_hist.set_title(f"Cost distribution (n={len(cell_df)})")

    # Overlay quartile markers for easy cutoff selection
    q25, q50, q75 = np.percentile(costs, [25, 50, 75])
    for q, label in [(q25, "Q1"), (q50, "median"), (q75, "Q3")]:
        ax_hist.axvline(q, linestyle="--", color="black", alpha=0.5)
        ax_hist.text(q, ax_hist.get_ylim()[1] * 0.95, f" {label}={q:.2f}", fontsize=8, va="top")

    # Scatter: match duration vs cost, coloured by dataset
    datasets = sorted(cell_df["dataset_id"].unique())
    cmap = plt.get_cmap("tab10")
    for i, ds in enumerate(datasets):
        sub = cell_df[cell_df["dataset_id"] == ds]
        ax_scatter.scatter(
            sub["match_duration_minutes"],
            sub["length_normalized_cost"],
            s=20,
            color=cmap(i % 10),
            alpha=0.6,
            edgecolors="none",
            label=ds,
        )
    if template_duration is not None:
        ax_scatter.axvline(
            template_duration,
            linestyle=":",
            color="red",
            label=f"template duration ({template_duration:.0f} min)",
        )
    ax_scatter.set_xlabel("match duration (min)")
    ax_scatter.set_ylabel("length-normalized DTW cost")
    ax_scatter.set_title("Duration vs cost")
    ax_scatter.legend(loc="best", fontsize=8)

    fig.suptitle(title)
    fig.tight_layout()
    return fig


def main() -> None:
    """Render the Stage 2b cost-ranking diagnostic figure."""
    parser = argparse.ArgumentParser(description="Rank query cells by DTW cost (Stage 2b)")
    parser.add_argument("--datasets", required=True, help="Path to datasets.yaml (shared infra config)")
    parser.add_argument("--config", required=True, help="Path to align_cells.yaml")
    parser.add_argument("--template", required=True, help="Template name")
    parser.add_argument("--flavor", choices=["raw", "pca"], default="raw")
    parser.add_argument("--query-set", required=True, help="Query set name (under config['query_sets'])")
    args = parser.parse_args()

    _ = load_stage_config(args.datasets, args.config)  # validates both configs parse cleanly

    alignment_path = ALIGNMENTS_DIR / f"{args.template}_{args.flavor}_on_{args.query_set}.parquet"
    if not alignment_path.exists():
        raise FileNotFoundError(f"Alignment parquet not found: {alignment_path}. Run align_cells.py first.")

    _logger.info(f"Reading {alignment_path}")
    df = pd.read_parquet(alignment_path)

    # Reduce to one row per cell — cost and match bounds are already per-track
    # (repeated on every frame in the flat parquet). `first()` is safe because
    # these columns are constant within a track.
    cell_df = df.groupby(["dataset_id", "fov_name", "track_id"], as_index=False).agg(
        length_normalized_cost=("length_normalized_cost", "first"),
        dtw_cost=("dtw_cost", "first"),
        match_duration_minutes=("match_duration_minutes", "first"),
        match_q_start=("match_q_start", "first"),
        match_q_end=("match_q_end", "first"),
    )

    template_path = TEMPLATES_DIR / f"template_{args.template}.zarr"
    template_duration = _template_duration_minutes(template_path, args.flavor)

    title = f"{args.template} / {args.flavor} / {args.query_set}"
    fig = _plot_cost_ranking(cell_df, template_duration, title)

    PLOTS_DIR.mkdir(parents=True, exist_ok=True)
    out_path = PLOTS_DIR / f"cost_ranking_{args.template}_{args.flavor}_{args.query_set}.png"
    fig.savefig(out_path, dpi=150)
    plt.close(fig)
    _logger.info(f"Wrote {out_path}")

    # Also log a markdown cost table for quick copy into a wiki.
    pct = cell_df["length_normalized_cost"].quantile([0.1, 0.25, 0.5, 0.75, 0.9]).to_dict()
    _logger.info(
        "Cost percentiles (length-normalized DTW cost):\n"
        "| p10 | p25 | p50 | p75 | p90 |\n"
        "|---|---|---|---|---|\n"
        f"| {pct[0.1]:.3f} | {pct[0.25]:.3f} | {pct[0.5]:.3f} | {pct[0.75]:.3f} | {pct[0.9]:.3f} |"
    )


if __name__ == "__main__":
    main()
