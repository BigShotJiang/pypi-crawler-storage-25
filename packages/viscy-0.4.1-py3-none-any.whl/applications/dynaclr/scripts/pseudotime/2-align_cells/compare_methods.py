"""Render a paper-style comparison table + bar chart from ``scoring/results.csv``.

Filters rows by template/flavor (defaults to ``infection_nondividing_sensor``
+ ``raw``), groups by query_set × method, and emits two artifacts:

- ``compare_methods.md``  markdown table for the paper
- ``compare_methods.png`` 2×2 grid: median |Δt|, IQR, AUROC, F1@0 vs query_set,
  one bar per method.

Each row of ``results.csv`` is one scoring run. If the same
(query_set, method, truth_column) was run multiple times, the most
recent row wins.

Usage::

    cd applications/dynaclr/scripts/pseudotime/2-align_cells
    uv run python compare_methods.py
"""

from __future__ import annotations

import argparse
import logging
from pathlib import Path

import matplotlib
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

matplotlib.use("Agg")
SCRIPT_DIR = Path(__file__).resolve().parent
SCORING_DIR = SCRIPT_DIR / "scoring"

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(levelname)s %(message)s")
_logger = logging.getLogger(__name__)


def _latest_per_run(df: pd.DataFrame) -> pd.DataFrame:
    """Keep the most recent row per (template, flavor, query_set, method, truth_column)."""
    df = df.sort_values("timestamp_utc")
    keys = ["template", "flavor", "query_set", "method", "truth_column"]
    return df.drop_duplicates(subset=keys, keep="last").reset_index(drop=True)


def _markdown_table(df: pd.DataFrame) -> str:
    """Wide-format paper table: rows = query_set × truth_column, cols = method × metric."""
    if df.empty:
        return "_(no rows)_\n"
    df = df.copy()
    df["query_label"] = df["query_set"] + " (" + df["truth_column"] + ")"
    metric_cols = [
        ("median_abs_onset_error_minutes", "med|Δt|", "{:.0f}"),
        ("iqr_abs_onset_error_minutes", "IQR|Δt|", "{:.0f}"),
        ("auroc", "AUROC", "{:.3f}"),
        ("f1_at_zero", "F1@0", "{:.3f}"),
        ("n_cells_scored", "n", "{:.0f}"),
    ]

    methods = sorted(df["method"].unique().tolist())
    query_labels = sorted(df["query_label"].unique().tolist())

    header = ["query_set"]
    for met_col, met_name, _ in metric_cols:
        for m in methods:
            header.append(f"{met_name} ({m})")
    rows = ["| " + " | ".join(header) + " |", "|" + "|".join(["---"] * len(header)) + "|"]

    for ql in query_labels:
        row = [ql]
        sub = df[df["query_label"] == ql]
        for met_col, _, fmt in metric_cols:
            for m in methods:
                cell = sub[sub["method"] == m]
                if cell.empty:
                    row.append("—")
                else:
                    val = cell.iloc[0][met_col]
                    row.append(fmt.format(val) if pd.notna(val) else "—")
        rows.append("| " + " | ".join(row) + " |")

    return "\n".join(rows) + "\n"


def _bar_grid(df: pd.DataFrame, out_path: Path) -> None:
    """4-panel bar chart: median|Δt|, IQR, AUROC, F1@0 vs query_set, one bar per method."""
    metrics = [
        ("median_abs_onset_error_minutes", "median |Δt|  (min, lower=better)"),
        ("iqr_abs_onset_error_minutes", "IQR |Δt|  (min, lower=better)"),
        ("auroc", "AUROC  (higher=better)"),
        ("f1_at_zero", "F1 @ t_rel=0  (higher=better)"),
    ]

    df = df.copy()
    df["query_label"] = df["query_set"] + "\n(" + df["truth_column"] + ")"
    methods = sorted(df["method"].unique().tolist())
    query_labels = sorted(df["query_label"].unique().tolist())

    fig, axes = plt.subplots(2, 2, figsize=(11, 8))
    cmap = plt.get_cmap("tab10")
    method_color = {m: cmap(i) for i, m in enumerate(methods)}
    bar_w = 0.8 / max(len(methods), 1)

    for ax, (col, title) in zip(axes.flat, metrics, strict=False):
        x = np.arange(len(query_labels))
        for j, m in enumerate(methods):
            sub = df[df["method"] == m].set_index("query_label").reindex(query_labels)
            vals = sub[col].to_numpy(dtype=float)
            ax.bar(
                x + (j - (len(methods) - 1) / 2) * bar_w,
                vals,
                width=bar_w,
                color=method_color[m],
                label=m,
                edgecolor="black",
                linewidth=0.5,
            )
        ax.set_xticks(x)
        ax.set_xticklabels(query_labels, fontsize=8, rotation=20, ha="right")
        ax.set_title(title, fontsize=10)
        ax.grid(axis="y", alpha=0.3)
        if col == "auroc":
            ax.axhline(0.5, color="grey", linestyle="--", linewidth=0.8, label="chance")
            ax.set_ylim(0, 1)
        elif col == "f1_at_zero":
            ax.set_ylim(0, 1)

    axes.flat[0].legend(fontsize=8, loc="best", frameon=False)
    fig.suptitle("DynaCLR pseudotime alignment — DTW vs no-align baseline", fontsize=12)
    fig.tight_layout(rect=(0, 0, 1, 0.96))
    fig.savefig(out_path, dpi=160, bbox_inches="tight", facecolor="white")
    plt.close(fig)


def main() -> None:
    """Render comparison table + plot from ``scoring/results.csv``."""
    parser = argparse.ArgumentParser()
    parser.add_argument("--template", default="infection_nondividing_sensor")
    parser.add_argument("--flavor", default="raw")
    parser.add_argument("--results-csv", default=str(SCORING_DIR / "results.csv"))
    parser.add_argument("--out-stem", default="compare_methods")
    args = parser.parse_args()

    csv_path = Path(args.results_csv)
    if not csv_path.exists():
        raise FileNotFoundError(f"{csv_path} does not exist — run score_alignment.py first")
    df = pd.read_csv(csv_path)
    df = df[(df["template"] == args.template) & (df["flavor"] == args.flavor)].copy()
    if df.empty:
        raise SystemExit(f"No rows for template={args.template} flavor={args.flavor}")
    df = _latest_per_run(df)

    out_md = SCORING_DIR / f"{args.out_stem}.md"
    out_png = SCORING_DIR / f"{args.out_stem}.png"

    md_lines = [
        f"# Alignment method comparison — {args.template} [{args.flavor}]",
        "",
        f"Source: `{csv_path}`",
        "",
        _markdown_table(df),
    ]
    out_md.write_text("\n".join(md_lines) + "\n")
    _bar_grid(df, out_png)
    _logger.info(f"Wrote {out_md.name}")
    _logger.info(f"Wrote {out_png.name}")


if __name__ == "__main__":
    main()
