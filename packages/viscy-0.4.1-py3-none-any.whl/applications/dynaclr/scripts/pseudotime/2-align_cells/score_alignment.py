"""Quantitative alignment scoring for the pseudotime pipeline.

Stage 2 evaluation. Given a Stage 2a alignment parquet (or a no-align
baseline) plus the query-set obs annotations, compute per-cell
onset-recovery error and population AUROC/F1@0 against a binary
ground-truth label.

Three methods are supported via ``--method``:

- ``dtw`` (default): use ``estimated_t_rel_minutes`` from the parquet.
- ``lc_onset``: ignore DTW; for each cell, derive a temporally-naive
  onset from the linear classifier's per-frame
  ``--lc-column`` predictions (default
  ``predicted_infection_state``). Onset = first frame entering a run
  of ``--min-run`` consecutive positives. ``estimated_t_rel_minutes``
  is then re-defined as ``(t - lc_onset_t) * frame_interval`` — i.e. 0
  at the cell's LC-derived onset. This is the "no temporal model"
  baseline that uses the same DynaCLR embeddings as DTW but classifies
  frame-by-frame.
- ``no_align``: ignore DTW *and* the LC; substitute ``(t -
  first_t_in_track) * frame_interval - half_template_minutes`` so each
  cell is anchored at its track midpoint. The lower-bound floor.

Outputs three artifacts under ``2-align_cells/scoring/``:

- ``{stem}_per_cell.parquet``  one row per cell with onset_error and
  per-cell metric scalars
- ``{stem}_summary.md``         markdown table of pop-level metrics
- ``results.csv``               appended results row for cross-method
                                comparison plotting (one row per run)

Usage (DTW)::

    cd applications/dynaclr/scripts/pseudotime/2-align_cells
    uv run python score_alignment.py \\
        --datasets ../../../configs/pseudotime/datasets.yaml \\
        --config   ../../../configs/pseudotime/align_cells.yaml \\
        --template infection_nondividing_sensor --flavor raw \\
        --query-set sensor_all_07_24 \\
        --truth-column infection_state --truth-positive infected \\
        --method dtw

Usage (no-align baseline on the same parquet)::

    uv run python score_alignment.py ... --method no_align
"""

from __future__ import annotations

import argparse
import csv
import logging
import sys
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path

import anndata as ad
import numpy as np
import pandas as pd
from sklearn.metrics import f1_score, roc_auc_score

from dynaclr.pseudotime import date_prefix_from_dataset_id, find_embedding_zarr

SCRIPT_DIR = Path(__file__).resolve().parent
ALIGNMENTS_DIR = SCRIPT_DIR / "alignments"
SCORING_DIR = SCRIPT_DIR / "scoring"

sys.path.insert(0, str(SCRIPT_DIR.parent))
from utils import load_stage_config  # noqa: E402

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(levelname)s %(message)s")
_logger = logging.getLogger(__name__)


@dataclass
class _CellScore:
    """Per-cell timing + classification scoring scalars."""

    dataset_id: str
    fov_name: str
    track_id: int
    n_frames: int
    n_aligned: int
    has_transition: bool
    onset_error_minutes: float
    abs_onset_error_minutes: float


def _annotate_obs(
    parquet_df: pd.DataFrame,
    dataset_cfgs: dict[str, dict],
    embedding_pattern: str,
    truth_column: str,
    truth_positive: str,
) -> pd.DataFrame:
    """Attach per-frame ``is_positive`` from query obs to the alignment parquet.

    Parameters
    ----------
    parquet_df : DataFrame
        Stage 2 alignment parquet (one row per cell-frame).
    dataset_cfgs : dict
        Dataset entries from datasets.yaml keyed by dataset_id.
    embedding_pattern : str
        Glob suffix from ``config["embeddings"][channel]``.
    truth_column : str
        Obs column to read (e.g. ``infection_state`` or
        ``predicted_infection_state``).
    truth_positive : str
        Value treated as positive (e.g. ``"infected"``).

    Returns
    -------
    DataFrame
        ``parquet_df`` with an added ``is_positive`` column (float in
        {0.0, 1.0, NaN}).
    """
    parts = []
    for dataset_id, ds_align in parquet_df.groupby("dataset_id"):
        ds_cfg = dataset_cfgs[dataset_id]
        prefix = date_prefix_from_dataset_id(dataset_id)
        zarr_path = find_embedding_zarr(ds_cfg["pred_dir"], prefix + embedding_pattern)
        _logger.info(f"  [{dataset_id}] joining truth from {Path(zarr_path).name}")
        adata = ad.read_zarr(zarr_path)
        adata.obs_names_make_unique()

        if truth_column not in adata.obs.columns:
            _logger.warning(f"  [{dataset_id}] truth column '{truth_column}' missing — skipping")
            ds_align = ds_align.copy()
            ds_align["is_positive"] = np.nan
            parts.append(ds_align)
            continue

        obs = adata.obs.reset_index(drop=True)
        truth = obs[[("fov_name"), ("track_id"), ("t"), truth_column]].copy()
        truth["fov_name"] = truth["fov_name"].astype(str)
        truth["track_id"] = truth["track_id"].astype(int)
        truth["t"] = truth["t"].astype(int)
        truth["is_positive"] = (truth[truth_column].astype(str) == truth_positive).astype(float)
        truth.loc[truth[truth_column].isna(), "is_positive"] = np.nan
        truth = truth.drop(columns=[truth_column])

        ds_aligned = ds_align.copy()
        ds_aligned["fov_name"] = ds_aligned["fov_name"].astype(str)
        ds_aligned["track_id"] = ds_aligned["track_id"].astype(int)
        ds_aligned["t"] = ds_aligned["t"].astype(int)
        merged = ds_aligned.merge(truth, on=["fov_name", "track_id", "t"], how="left")
        parts.append(merged)

    return pd.concat(parts, ignore_index=True)


def _attach_lc_predictions(
    parquet_df: pd.DataFrame,
    dataset_cfgs: dict[str, dict],
    embedding_pattern: str,
    lc_column: str,
    lc_positive: str,
) -> pd.DataFrame:
    """Attach per-frame ``lc_is_positive`` from the LC's ``--lc-column`` output.

    Mirrors :func:`_annotate_obs` but for the classifier output rather
    than the human ground truth. Used by the ``lc_onset`` method.
    """
    parts = []
    for dataset_id, ds_align in parquet_df.groupby("dataset_id"):
        ds_cfg = dataset_cfgs[dataset_id]
        prefix = date_prefix_from_dataset_id(dataset_id)
        zarr_path = find_embedding_zarr(ds_cfg["pred_dir"], prefix + embedding_pattern)
        adata = ad.read_zarr(zarr_path)
        adata.obs_names_make_unique()

        if lc_column not in adata.obs.columns:
            raise KeyError(f"[{dataset_id}] LC column '{lc_column}' missing from obs — run append-predictions first")

        obs = adata.obs.reset_index(drop=True)
        lc = obs[["fov_name", "track_id", "t", lc_column]].copy()
        lc["fov_name"] = lc["fov_name"].astype(str)
        lc["track_id"] = lc["track_id"].astype(int)
        lc["t"] = lc["t"].astype(int)
        lc["lc_is_positive"] = (lc[lc_column].astype(str) == lc_positive).astype(float)
        lc.loc[lc[lc_column].isna(), "lc_is_positive"] = np.nan
        lc = lc.drop(columns=[lc_column])

        ds_aligned = ds_align.copy()
        ds_aligned["fov_name"] = ds_aligned["fov_name"].astype(str)
        ds_aligned["track_id"] = ds_aligned["track_id"].astype(int)
        ds_aligned["t"] = ds_aligned["t"].astype(int)
        merged = ds_aligned.merge(lc, on=["fov_name", "track_id", "t"], how="left")
        parts.append(merged)
    return pd.concat(parts, ignore_index=True)


def _apply_lc_onset_baseline(
    df: pd.DataFrame,
    dataset_cfgs: dict[str, dict],
    min_run: int,
) -> pd.DataFrame:
    """Replace ``estimated_t_rel_minutes`` with LC-derived per-cell onset.

    For each cell, find the first frame entering a run of ``min_run``
    consecutive positives in ``lc_is_positive``. That frame's ``t``
    becomes the cell's onset. ``estimated_t_rel_minutes`` is then
    ``(t - onset_t) * frame_interval``. ``alignment_region`` is reset
    to "aligned" everywhere (LC has no pre/post concept).

    Cells with no LC-derived onset get NaN in
    ``estimated_t_rel_minutes`` for the whole track, so they drop out
    of scoring just like cells with no DTW match.
    """
    out = df.copy()
    out["estimated_t_rel_minutes"] = np.nan
    out["alignment_region"] = "aligned"
    for (dataset_id, fov_name, track_id), grp in out.groupby(["dataset_id", "fov_name", "track_id"]):
        ds_cfg = dataset_cfgs[dataset_id]
        frame_interval = float(ds_cfg["frame_interval_minutes"])
        ordered = grp.sort_values("t")
        idx = ordered.index
        ts = ordered["t"].astype(int).to_numpy()
        pos = ordered["lc_is_positive"].fillna(0.0).to_numpy()

        onset_t: int | None = None
        run = 0
        for i, p in enumerate(pos):
            if p == 1.0:
                run += 1
                if run >= min_run:
                    onset_t = int(ts[i - run + 1])
                    break
            else:
                run = 0
        if onset_t is None:
            continue
        out.loc[idx, "estimated_t_rel_minutes"] = (out.loc[idx, "t"].astype(int) - onset_t) * frame_interval
    return out


def _apply_no_align_baseline(
    df: pd.DataFrame,
    dataset_cfgs: dict[str, dict],
    half_template_minutes: float,
) -> pd.DataFrame:
    """Replace ``estimated_t_rel_minutes`` with a no-learning baseline.

    Anchors each cell at the start of its observed track:
    ``(t - min(t_in_track)) * frame_interval - half_template_minutes``.

    The ``-half_template_minutes`` offset puts the midpoint of each
    track at t_rel=0 so the comparison to DTW is in the same minute
    range. ``alignment_region`` is also reset to "aligned" everywhere
    since this baseline does not classify pre/post.

    Parameters
    ----------
    df : DataFrame
        Alignment parquet annotated with truth labels.
    dataset_cfgs : dict
        Dataset entries from datasets.yaml.
    half_template_minutes : float
        Half the template duration (minutes); used as the anchoring
        offset.

    Returns
    -------
    DataFrame
        Modified copy with overwritten ``estimated_t_rel_minutes`` and
        ``alignment_region``.
    """
    out = df.copy()
    out["estimated_t_rel_minutes"] = np.nan
    out["alignment_region"] = "aligned"
    for (dataset_id, fov_name, track_id), grp in out.groupby(["dataset_id", "fov_name", "track_id"]):
        ds_cfg = dataset_cfgs[dataset_id]
        frame_interval = float(ds_cfg["frame_interval_minutes"])
        t_min = int(grp["t"].min())
        idx = grp.index
        out.loc[idx, "estimated_t_rel_minutes"] = (
            (out.loc[idx, "t"].astype(int) - t_min) * frame_interval - half_template_minutes
        )
    return out


def _per_cell_scores(annotated: pd.DataFrame) -> list[_CellScore]:
    """Compute per-cell ``onset_error_minutes`` for cells with a transition.

    A cell has a "transition" if it contains both ``is_positive == 0``
    and ``is_positive == 1`` frames within ``alignment_region ==
    "aligned"``. The onset is the FIRST aligned frame where
    ``is_positive == 1`` AND a strictly earlier aligned frame has
    ``is_positive == 0`` (i.e. the cell starts negative and turns
    positive). ``onset_error_minutes`` is the warped time at that
    frame.

    Cells with no transition (all-positive, all-negative, or
    all-NaN truth in the aligned region) are skipped — they cannot be
    used to score onset recovery.
    """
    scores: list[_CellScore] = []
    for (dataset_id, fov_name, track_id), grp in annotated.groupby(["dataset_id", "fov_name", "track_id"]):
        grp = grp.sort_values("t").reset_index(drop=True)
        n_frames = len(grp)
        aligned = grp[grp["alignment_region"] == "aligned"].reset_index(drop=True)
        n_aligned = len(aligned)
        if n_aligned < 2:
            continue
        truth = aligned["is_positive"].to_numpy()
        finite = np.isfinite(truth)
        if not finite.any():
            continue
        has_neg = bool(((truth == 0.0) & finite).any())
        has_pos = bool(((truth == 1.0) & finite).any())
        has_transition = has_neg and has_pos
        if not has_transition:
            continue
        # First aligned frame where is_positive == 1 *and* a strictly earlier aligned frame is 0.
        first_neg_idx = None
        onset_idx = None
        for i in range(n_aligned):
            v = truth[i]
            if not np.isfinite(v):
                continue
            if v == 0.0 and first_neg_idx is None:
                first_neg_idx = i
            if v == 1.0 and first_neg_idx is not None:
                onset_idx = i
                break
        if onset_idx is None:
            continue
        onset_t = float(aligned.loc[onset_idx, "estimated_t_rel_minutes"])
        if not np.isfinite(onset_t):
            continue
        scores.append(
            _CellScore(
                dataset_id=str(dataset_id),
                fov_name=str(fov_name),
                track_id=int(track_id),
                n_frames=int(n_frames),
                n_aligned=int(n_aligned),
                has_transition=True,
                onset_error_minutes=onset_t,
                abs_onset_error_minutes=abs(onset_t),
            )
        )
    return scores


def _classification_metrics(annotated: pd.DataFrame) -> dict[str, float]:
    """Compute population AUROC and F1@0 over aligned-region (cell, frame) pairs.

    The "score" used for AUROC/F1 is ``estimated_t_rel_minutes``; the
    label is ``is_positive``. AUROC asks: ranked by warped time, are
    positive frames later than negative frames? F1@0 binarizes at the
    threshold ``estimated_t_rel_minutes >= 0`` (the template's
    consensus event time).
    """
    aligned = annotated[annotated["alignment_region"] == "aligned"].copy()
    aligned = aligned.dropna(subset=["is_positive", "estimated_t_rel_minutes"])
    if len(aligned) == 0 or aligned["is_positive"].nunique() < 2:
        return {"auroc": float("nan"), "f1_at_zero": float("nan"), "n_pairs": float(len(aligned))}
    y_true = aligned["is_positive"].to_numpy(dtype=int)
    y_score = aligned["estimated_t_rel_minutes"].to_numpy(dtype=float)
    auroc = float(roc_auc_score(y_true, y_score))
    y_pred = (y_score >= 0).astype(int)
    f1 = float(f1_score(y_true, y_pred, zero_division=0))
    return {"auroc": auroc, "f1_at_zero": f1, "n_pairs": float(len(aligned))}


def _summarize(per_cell: list[_CellScore], cls_metrics: dict[str, float]) -> dict[str, float]:
    """Reduce per-cell scores + classification metrics to a population summary."""
    if not per_cell:
        return {
            "n_cells_scored": 0,
            "median_abs_onset_error_minutes": float("nan"),
            "iqr_abs_onset_error_minutes": float("nan"),
            "median_signed_onset_error_minutes": float("nan"),
            **cls_metrics,
        }
    abs_err = np.array([s.abs_onset_error_minutes for s in per_cell])
    signed = np.array([s.onset_error_minutes for s in per_cell])
    return {
        "n_cells_scored": int(len(per_cell)),
        "median_abs_onset_error_minutes": float(np.median(abs_err)),
        "iqr_abs_onset_error_minutes": float(np.percentile(abs_err, 75) - np.percentile(abs_err, 25)),
        "median_signed_onset_error_minutes": float(np.median(signed)),
        **cls_metrics,
    }


def _write_summary_md(out_path: Path, args: argparse.Namespace, summary: dict[str, float]) -> None:
    """Write a markdown summary table for paper-style copy/paste."""
    lines = [
        f"# Alignment scoring — {args.template} [{args.flavor}] / {args.query_set} / method={args.method}",
        "",
        f"- truth_column: `{args.truth_column}` (positive = `{args.truth_positive}`)",
        f"- generated: {datetime.now(timezone.utc).isoformat(timespec='seconds')}",
        "",
        "| metric | value |",
        "|---|---:|",
        f"| n_cells_scored                          | {summary['n_cells_scored']} |",
        f"| median \\|onset error\\| (min)              | {summary['median_abs_onset_error_minutes']:.1f} |",
        f"| IQR \\|onset error\\| (min)                 | {summary['iqr_abs_onset_error_minutes']:.1f} |",
        f"| median signed onset error (min)         | {summary['median_signed_onset_error_minutes']:.1f} |",
        f"| AUROC                                   | {summary['auroc']:.3f} |",
        f"| F1 at threshold 0                       | {summary['f1_at_zero']:.3f} |",
        f"| n (cell, frame) pairs                   | {int(summary['n_pairs'])} |",
        "",
        "Notes",
        "-----",
        "- `onset error` = `estimated_t_rel_minutes` at each cell's first aligned positive frame "
        "preceded by a negative frame. 0 = perfect recovery of the annotated onset.",
        "- AUROC ranks aligned (cell, frame) pairs by warped time; chance = 0.5. "
        "F1@0 binarizes at `estimated_t_rel_minutes >= 0`.",
        "- `no_align` baseline anchors each cell at its track midpoint with no learning.",
    ]
    out_path.write_text("\n".join(lines) + "\n")


def _append_results_csv(results_csv: Path, args: argparse.Namespace, summary: dict[str, float]) -> None:
    """Append one row to ``scoring/results.csv`` for cross-method comparison."""
    row = {
        "template": args.template,
        "flavor": args.flavor,
        "query_set": args.query_set,
        "method": args.method,
        "truth_column": args.truth_column,
        "truth_positive": args.truth_positive,
        **summary,
        "timestamp_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
    }
    file_exists = results_csv.exists()
    with results_csv.open("a", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(row.keys()))
        if not file_exists:
            writer.writeheader()
        writer.writerow(row)


def main() -> None:
    """Score one alignment parquet against ground-truth annotations."""
    parser = argparse.ArgumentParser(description="Score alignment quality vs annotated onset")
    parser.add_argument("--datasets", required=True)
    parser.add_argument("--config", required=True)
    parser.add_argument("--template", required=True)
    parser.add_argument("--flavor", choices=["raw", "pca"], default="raw")
    parser.add_argument("--query-set", required=True)
    parser.add_argument("--method", choices=["dtw", "lc_onset", "no_align"], default="dtw")
    parser.add_argument("--truth-column", default="infection_state")
    parser.add_argument("--truth-positive", default="infected")
    parser.add_argument(
        "--lc-column",
        default="predicted_infection_state",
        help="Obs column for LC predictions (only for --method lc_onset)",
    )
    parser.add_argument(
        "--lc-positive",
        default="infected",
        help="Positive value in --lc-column",
    )
    parser.add_argument(
        "--min-run",
        type=int,
        default=3,
        help="Min consecutive positives to call LC onset (only for --method lc_onset)",
    )
    args = parser.parse_args()

    config = load_stage_config(args.datasets, args.config)
    dataset_cfgs = {d["dataset_id"]: d for d in config["datasets"]}

    qset_cfg = config["query_sets"][args.query_set]
    channel = qset_cfg["channel"]
    embedding_pattern = config["embeddings"][channel]

    parquet_path = ALIGNMENTS_DIR / f"{args.template}_{args.flavor}_on_{args.query_set}.parquet"
    if not parquet_path.exists():
        raise FileNotFoundError(f"Alignment parquet not found: {parquet_path}")
    _logger.info(f"Reading {parquet_path.name}")
    df = pd.read_parquet(parquet_path)
    _logger.info(f"  rows={len(df):,}  tracks={df.groupby(['dataset_id', 'fov_name', 'track_id']).ngroups}")

    _logger.info("Joining truth labels from query obs")
    annotated = _annotate_obs(df, dataset_cfgs, embedding_pattern, args.truth_column, args.truth_positive)

    if args.method == "no_align":
        # Half-template offset only matters for the absolute scale of t_rel; pull from parquet
        # if available (constant per template).
        match_durations = df.groupby(["dataset_id", "fov_name", "track_id"])["match_duration_minutes"].first()
        half_template = float(match_durations.median()) / 2.0 if match_durations.notna().any() else 200.0
        _logger.info(f"Applying no-align baseline (half_template_minutes={half_template:.1f})")
        annotated = _apply_no_align_baseline(annotated, dataset_cfgs, half_template)
    elif args.method == "lc_onset":
        _logger.info(
            f"Applying LC-onset baseline (lc_column={args.lc_column}, lc_positive={args.lc_positive}, min_run={args.min_run})"
        )
        annotated = _attach_lc_predictions(
            annotated, dataset_cfgs, embedding_pattern, args.lc_column, args.lc_positive
        )
        annotated = _apply_lc_onset_baseline(annotated, dataset_cfgs, args.min_run)

    _logger.info("Computing per-cell onset errors")
    per_cell = _per_cell_scores(annotated)
    _logger.info(f"  cells with usable transitions: {len(per_cell)}")

    _logger.info("Computing population classification metrics")
    cls = _classification_metrics(annotated)

    summary = _summarize(per_cell, cls)
    SCORING_DIR.mkdir(parents=True, exist_ok=True)
    stem = f"{args.template}_{args.flavor}_on_{args.query_set}_{args.method}"

    per_cell_path = SCORING_DIR / f"{stem}_per_cell.parquet"
    pd.DataFrame([s.__dict__ for s in per_cell]).to_parquet(per_cell_path, index=False)
    _logger.info(f"Wrote {per_cell_path.name}")

    summary_path = SCORING_DIR / f"{stem}_summary.md"
    _write_summary_md(summary_path, args, summary)
    _logger.info(f"Wrote {summary_path.name}")

    results_csv = SCORING_DIR / "results.csv"
    _append_results_csv(results_csv, args, summary)
    _logger.info(f"Appended row to {results_csv.name}")

    _logger.info(
        "Summary: median |Δt|=%.1f min  IQR=%.1f  AUROC=%.3f  F1@0=%.3f  n=%d",
        summary["median_abs_onset_error_minutes"],
        summary["iqr_abs_onset_error_minutes"],
        summary["auroc"],
        summary["f1_at_zero"],
        summary["n_cells_scored"],
    )


if __name__ == "__main__":
    main()
