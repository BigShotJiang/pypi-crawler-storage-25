r"""PCs over time for query cells — unaligned vs aligned, generalized to query sets.

Stage 2d of the pseudotime pipeline. Reads the Stage 2a alignment parquet,
pulls the raw 768-D embeddings for the top-N (by length-normalized cost)
query cells, fits a **post-hoc** PCA on the aligned-region frames only,
and plots top PCs vs minutes in two columns:

- **Left (unaligned):** PC vs ``(t - match_q_start) * frame_interval`` — each
  cell anchored at its own match start. Real-time offsets; if cells traverse
  the event at different speeds, traces scatter in shape.
- **Right (aligned):** PC vs ``estimated_t_rel_minutes`` — pseudotime mapped
  back to minutes via the template's ``time_calibration``. If DTW works,
  traces collapse onto a shared curve.

``--split-by <label_col>`` draws separate traces per group (e.g. infected vs
control); controls SHOULD NOT collapse.

Usage::

    cd applications/dynaclr/scripts/pseudotime/2-align_cells
    uv run python plot_pcs_aligned.py \
        --datasets ../../../configs/pseudotime/datasets.yaml \
        --config ../../../configs/pseudotime/align_cells.yaml \
        --template manual_debug_sensor \
        --flavor raw \
        --query-set sensor_manual_debug_qset \
        --top-n 50 --n-pcs 5
"""

from __future__ import annotations

import argparse
import logging
import sys
from pathlib import Path

import matplotlib
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.decomposition import PCA

from dynaclr.pseudotime import (
    date_prefix_from_dataset_id,
    find_embedding_zarr,
    read_template_attrs,
    read_time_calibration,
)

matplotlib.use("Agg")

SCRIPT_DIR = Path(__file__).resolve().parent
TEMPLATES_DIR = SCRIPT_DIR.parent / "1-build_template" / "templates"
ALIGNMENTS_DIR = SCRIPT_DIR / "alignments"
PLOTS_DIR = SCRIPT_DIR / "plots"

sys.path.insert(0, str(SCRIPT_DIR.parent))
sys.path.insert(0, str(SCRIPT_DIR.parent / "1-build_template"))
# Reuse plot helpers from Stage 1 plot_pcs (binned scatter, template-label loader,
# raw-embedding joiner). These remain script-local since they're plotting concerns.
from plot_pcs import _collect_embeddings, _load_template_label  # noqa: E402
from utils import load_stage_config  # noqa: E402

# Names re-bound to keep diff small for unrelated callers.
_date_prefix_from_dataset_id = date_prefix_from_dataset_id
_find_zarr = find_embedding_zarr

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(levelname)s %(message)s")
_logger = logging.getLogger(__name__)


def _top_n_cells(alignments: pd.DataFrame, top_n: int) -> pd.DataFrame:
    """Select rows from the alignment parquet belonging to the top-N cells by cost."""
    costs = alignments.groupby(["dataset_id", "fov_name", "track_id"])["length_normalized_cost"].first()
    top_keys = set(costs.sort_values().head(top_n).index)
    mask = [
        (ds, fov, tid) in top_keys
        for ds, fov, tid in zip(alignments["dataset_id"], alignments["fov_name"], alignments["track_id"])
    ]
    return alignments[mask].reset_index(drop=True)


def main() -> None:
    """Render the Stage 2d unaligned-vs-aligned PC plot for query cells."""
    parser = argparse.ArgumentParser(description="Post-hoc PCs vs time for query cells (Stage 2d)")
    parser.add_argument("--datasets", required=True, help="Path to datasets.yaml")
    parser.add_argument("--config", required=True, help="Path to align_cells.yaml")
    parser.add_argument("--template", required=True)
    parser.add_argument("--flavor", choices=["raw", "pca"], default="raw")
    parser.add_argument("--query-set", required=True)
    parser.add_argument("--top-n", type=int, default=30, help="Cells to plot, ranked by length-norm cost")
    parser.add_argument("--n-pcs", type=int, default=4, help="Number of PCs to plot")
    parser.add_argument("--n-bins", type=int, default=12, help="Bins for median/IQR overlay")
    parser.add_argument(
        "--exclude-template-cells",
        action="store_true",
        help=(
            "Drop query cells that match (dataset_id, fov_name, track_id) in the template's "
            "build set. By default the template cells are kept — they should align best to themselves "
            "which is a useful sanity check — but for honest generalization reporting you'll want to exclude them."
        ),
    )
    parser.add_argument(
        "--truth-column",
        default="predicted_infection_state",
        help=(
            "adata.obs column holding a per-frame truth/prediction label for the left-panel "
            "fraction curve (e.g. 'infection_state' for human-annotated, 'predicted_infection_state' "
            "for classifier output). Falls back to the template-propagated label when the column is "
            "missing. Set to '' to disable the left-side curve."
        ),
    )
    parser.add_argument(
        "--truth-positive",
        default="infected",
        help="Value of --truth-column that counts as 'positive' (numerator of the fraction).",
    )
    args = parser.parse_args()

    config = load_stage_config(args.datasets, args.config)
    dataset_cfgs = {d["dataset_id"]: d for d in config["datasets"]}
    query_cfg = config["query_sets"][args.query_set]
    channel = query_cfg.get("channel", "sensor")

    alignment_path = ALIGNMENTS_DIR / f"{args.template}_{args.flavor}_on_{args.query_set}.parquet"
    if not alignment_path.exists():
        raise FileNotFoundError(f"Alignment parquet not found: {alignment_path}. Run align_cells.py first.")

    _logger.info(f"Reading {alignment_path}")
    alignments = pd.read_parquet(alignment_path)
    _logger.info(f"  {len(alignments)} rows, {alignments['cell_uid'].nunique()} cells")

    # Optionally exclude the template build-set cells so we evaluate generalization,
    # not self-consistency. Build-set cells will always rank at the top by cost —
    # they literally helped build the template they're aligning against.
    template_path = TEMPLATES_DIR / f"template_{args.template}.zarr"
    snapshot_attrs = read_template_attrs(template_path)
    template_cell_ids = [tuple(c) for c in snapshot_attrs.get("template_cell_ids", [])]
    if args.exclude_template_cells and template_cell_ids:
        tc_set = {(str(ds), str(fov), int(tid)) for ds, fov, tid in template_cell_ids}
        before = alignments["cell_uid"].nunique()
        key = list(
            zip(
                alignments["dataset_id"].astype(str),
                alignments["fov_name"].astype(str),
                alignments["track_id"].astype(int),
            )
        )
        mask = np.asarray([k not in tc_set for k in key])
        alignments = alignments[mask].reset_index(drop=True)
        after = alignments["cell_uid"].nunique()
        _logger.info(f"Excluded {before - after} template build-set cells; {after} query cells remain")

    # Keep ALL regions — pre/aligned/post — so the PC plot reveals the
    # organelle-remodeling trajectory before and after the event, not just
    # the event window. Pre/post frames are coloured differently below.
    selected = _top_n_cells(alignments, args.top_n)
    _logger.info(f"  {selected['cell_uid'].nunique()} cells after top-{args.top_n} filter")

    # Unaligned x-axis (left column): minutes from each cell's own match_q_start.
    # Well-defined for all three regions — pre frames get negative values, post
    # frames get values > match_duration_minutes.
    frame_interval_by_ds = {d["dataset_id"]: float(d["frame_interval_minutes"]) for d in config["datasets"]}
    selected = selected.copy()
    selected["frame_interval"] = selected["dataset_id"].map(frame_interval_by_ds)
    selected["t_from_match_start_minutes"] = (selected["t"] - selected["match_q_start"]) * selected["frame_interval"]

    # Aligned x-axis (right column): estimated_t_rel_minutes already exists for
    # aligned frames; for pre/post we extrapolate using the dataset's frame
    # interval so trajectories continue off either end of the template window.
    # (template_path was opened above for template_cell_ids.)
    tc = None
    try:
        tc = read_time_calibration(template_path, args.flavor)
    except KeyError:
        pass

    def _extrapolate_minutes(row: pd.Series) -> float:
        if row["alignment_region"] == "aligned":
            return float(row["estimated_t_rel_minutes"])
        fi = row["frame_interval"]
        if tc is None:
            return float("nan")
        if row["alignment_region"] == "pre":
            return float(tc[0] + (row["t"] - row["match_q_start"]) * fi)
        # post
        return float(tc[-1] + (row["t"] - row["match_q_end"]) * fi)

    selected["t_rel_minutes_extrap"] = selected.apply(_extrapolate_minutes, axis=1)

    # Pull raw 768-D embeddings (all regions) and fit post-hoc PCA on aligned-only
    # to keep the PCA basis consistent with the template's event window. Pre/post
    # frames get projected through this same basis.
    embedding_pattern = config["embeddings"][channel]
    _logger.info("Collecting raw embeddings for pre + aligned + post frames")
    joined = _collect_embeddings(selected, dataset_cfgs, embedding_pattern)

    X_all = np.stack(joined["embedding"].to_list())
    aligned_mask = (joined["alignment_region"] == "aligned").to_numpy()
    X_fit = X_all[aligned_mask]
    if X_fit.shape[0] < args.n_pcs:
        raise RuntimeError(f"Only {X_fit.shape[0]} aligned-region rows available; need ≥ {args.n_pcs} for PCA.")
    n_pcs = min(args.n_pcs, X_fit.shape[0], X_fit.shape[1])
    _logger.info(
        f"Fitting post-hoc PCA ({n_pcs} components) on {X_fit.shape[0]} aligned rows; "
        f"projecting {X_all.shape[0]} total (pre + aligned + post)"
    )
    pca = PCA(n_components=n_pcs)
    pca.fit(X_fit)
    pcs = pca.transform(X_all)
    for i in range(n_pcs):
        joined[f"pc_{i + 1}"] = pcs[:, i]

    regions = joined["alignment_region"].to_numpy()
    t_unaligned = joined["t_from_match_start_minutes"].to_numpy(dtype=float)
    t_aligned_extrap = joined["t_rel_minutes_extrap"].to_numpy(dtype=float)

    # Template-label overlay for the aligned (right) column.
    snapshot = read_template_attrs(template_path).get("config_snapshot", {})
    template_entry = snapshot.get("templates", {}).get(args.template, {})
    anchor_label = template_entry.get("anchor_label", "infection_state")
    tmpl_x, tmpl_frac = _load_template_label(template_path, args.flavor, anchor_label)
    has_label_row = tmpl_frac is not None

    region_colors = {"pre": "#7f7f7f", "aligned": "#1f77b4", "post": "#c0392b"}

    def _plot_regions(ax, x, y, n_bins):
        """Scatter colored by alignment region + binned median/IQR overlay.

        Skips per-cell legend entries (n_cells × 3 would flood the plot). The
        region legend is drawn once on the shared legend figure.
        """
        for region, color in region_colors.items():
            m = regions == region
            if m.any():
                ax.scatter(x[m], y[m], s=14, color=color, alpha=0.55, edgecolors="none")
        # Binned median/IQR across ALL regions (not per-cell) — same logic as
        # _scatter_with_bins but without the per-cell scatter+legend loop.
        x_f = x[np.isfinite(x)]
        y_f = y[np.isfinite(x)]
        if x_f.size >= 6:
            lo, hi = float(np.nanmin(x_f)), float(np.nanmax(x_f))
            edges = np.linspace(lo, hi, n_bins + 1)
            centers = 0.5 * (edges[:-1] + edges[1:])
            med = np.full(n_bins, np.nan)
            q25 = np.full(n_bins, np.nan)
            q75 = np.full(n_bins, np.nan)
            for b in range(n_bins):
                in_bin = (x_f >= edges[b]) & (x_f < edges[b + 1])
                if in_bin.sum() >= 3:
                    v = y_f[in_bin]
                    med[b] = np.median(v)
                    q25[b] = np.percentile(v, 25)
                    q75[b] = np.percentile(v, 75)
            ok = np.isfinite(med)
            if ok.any():
                ax.plot(centers[ok], med[ok], color="black", linewidth=2.0, zorder=5)
                ax.fill_between(centers[ok], q25[ok], q75[ok], color="black", alpha=0.15, zorder=4)

    n_rows = n_pcs + (1 if has_label_row else 0)
    fig, axes = plt.subplots(n_rows, 2, figsize=(10, 2.4 * n_rows), sharex="col", squeeze=False)

    for i in range(n_pcs):
        y = joined[f"pc_{i + 1}"].to_numpy()
        evr = pca.explained_variance_ratio_[i] * 100.0

        ax_l = axes[i, 0]
        _plot_regions(ax_l, t_unaligned, y, n_bins=args.n_bins)
        ax_l.axvline(0, color="black", linestyle="--", alpha=0.4, linewidth=1.0)
        ax_l.set_ylabel(f"PC{i + 1} ({evr:.1f}%)")
        if i == 0:
            ax_l.set_title("Unaligned (minutes from match_q_start)")

        ax_r = axes[i, 1]
        _plot_regions(ax_r, t_aligned_extrap, y, n_bins=args.n_bins)
        ax_r.axvline(0, color="red", linestyle=":", alpha=0.5, linewidth=1.0)
        if i == 0:
            ax_r.set_title("Aligned (estimated_t_rel_minutes, pre/post extrapolated)")

    if has_label_row:
        ax_l = axes[-1, 0]
        ax_r = axes[-1, 1]

        # Left: fraction of query cells whose adata.obs[truth_column] == truth_positive
        # at each t_from_match_start_minutes bin. Read from the query embedding zarrs
        # directly so it's independent of the template-propagated label on the right.
        truth_col = args.truth_column
        truth_positive = args.truth_positive
        drew_truth = False
        if truth_col:
            from anndata import read_zarr as _read_zarr  # local import — this path is cold

            lookups: dict[str, dict[tuple[str, int, int], str]] = {}
            for dataset_id in joined["dataset_id"].unique():
                ds_cfg = dataset_cfgs[dataset_id]
                emb_zarr = _find_zarr(
                    ds_cfg["pred_dir"],
                    _date_prefix_from_dataset_id(dataset_id) + embedding_pattern,
                )
                ad_q = _read_zarr(emb_zarr)
                ad_q.obs_names_make_unique()
                if truth_col not in ad_q.obs.columns:
                    _logger.warning(
                        f"[{dataset_id}] obs has no {truth_col!r} column — skipping truth curve for this dataset"
                    )
                    continue
                lookups[dataset_id] = {
                    (str(r["fov_name"]), int(r["track_id"]), int(r["t"])): str(r[truth_col])
                    for _, r in ad_q.obs.iterrows()
                }

            truth_vals = []
            for _, r in joined.iterrows():
                key = (str(r["fov_name"]), int(r["track_id"]), int(r["t"]))
                label = lookups.get(r["dataset_id"], {}).get(key)
                if label is None:
                    truth_vals.append(np.nan)
                else:
                    truth_vals.append(1.0 if label == truth_positive else 0.0)
            truth_arr = np.asarray(truth_vals, dtype=float)

            def _bin_fraction(x: np.ndarray, y: np.ndarray, n_bins: int):
                """Return (centers, frac) for bins with ≥1 sample."""
                mask = np.isfinite(y) & np.isfinite(x)
                if mask.sum() < 6:
                    return None, None
                lo, hi = float(np.nanmin(x[mask])), float(np.nanmax(x[mask]))
                edges = np.linspace(lo, hi, n_bins + 1)
                centers = 0.5 * (edges[:-1] + edges[1:])
                frac = np.full(n_bins, np.nan)
                for b in range(n_bins):
                    in_bin = mask & (x >= edges[b]) & (x < edges[b + 1])
                    if in_bin.sum() > 0:
                        frac[b] = np.nanmean(y[in_bin])
                return centers, frac

            # Left: query-truth binned by minutes-from-match_q_start (all regions).
            centers, frac = _bin_fraction(t_unaligned, truth_arr, args.n_bins)
            if centers is not None:
                ok = np.isfinite(frac)
                if ok.any():
                    ax_l.plot(centers[ok], frac[ok], color="#c0392b", linewidth=2)
                    ax_l.fill_between(centers[ok], 0, frac[ok], color="#c0392b", alpha=0.3)
                    drew_truth = True

            # Right: query-truth binned by estimated_t_rel_minutes.
            # Restrict to aligned rows only — outside that region t_rel is extrapolated
            # and the binned curve wouldn't correspond to a real DTW match.
            aligned_mask = regions == "aligned"
            x_aligned = t_aligned_extrap.copy()
            y_aligned = truth_arr.copy()
            x_aligned[~aligned_mask] = np.nan
            y_aligned[~aligned_mask] = np.nan
            centers_r, frac_r = _bin_fraction(x_aligned, y_aligned, args.n_bins)
            drew_truth_right = False
            if centers_r is not None:
                ok = np.isfinite(frac_r)
                if ok.any():
                    ax_r.plot(centers_r[ok], frac_r[ok], color="#c0392b", linewidth=2, label="query truth (aligned rows)")
                    ax_r.fill_between(centers_r[ok], 0, frac_r[ok], color="#c0392b", alpha=0.3)
                    drew_truth_right = True

        if not drew_truth:
            ax_l.text(
                0.5,
                0.5,
                f"(no {truth_col!r} column found in query obs)" if truth_col else "(truth curve disabled)",
                ha="center",
                va="center",
                transform=ax_l.transAxes,
                fontsize=9,
                color="grey",
            )
        ax_l.set_ylim(-0.05, 1.05)
        ax_l.axvline(0, color="black", linestyle="--", alpha=0.4, linewidth=1.0)
        ax_l.set_ylabel(f"{truth_col}\nfraction (query obs)")
        ax_l.set_xlabel("minutes from match_q_start")

        # Template-label overlay (dashed grey, secondary) — it's a property of
        # the build-set cells only, not the query. Kept for reference against
        # the query-truth curve but de-emphasised so it doesn't read as evidence.
        ax_r.plot(tmpl_x, tmpl_frac, color="#7f7f7f", linewidth=1.3, linestyle="--", label="template fraction (build cells)")
        ax_r.set_ylim(-0.05, 1.05)
        ax_r.axvline(0, color="red", linestyle=":", alpha=0.5, linewidth=1.0)
        ax_r.set_ylabel(f"{anchor_label}\nfraction")
        ax_r.set_xlabel("estimated_t_rel_minutes")
        if drew_truth_right:
            ax_r.legend(loc="lower right", fontsize=7, frameon=False)

    n_pre = int((regions == "pre").sum())
    n_aligned = int((regions == "aligned").sum())
    n_post = int((regions == "post").sum())
    exclude_tag = " (template cells excluded)" if args.exclude_template_cells else ""
    fig.suptitle(
        f"{args.template}/{args.flavor}/{args.query_set} — pre/aligned/post over time{exclude_tag}\n"
        f"{n_pre} pre | {n_aligned} aligned | {n_post} post  ·  "
        f"{joined['cell_uid'].nunique()} cells, top-{args.top_n} by cost",
        fontsize=10,
    )
    fig.tight_layout(rect=(0, 0, 1, 0.97))

    PLOTS_DIR.mkdir(parents=True, exist_ok=True)
    out_path = PLOTS_DIR / f"pcs_over_pseudotime_{args.template}_{args.flavor}_{args.query_set}.png"
    fig.savefig(out_path, dpi=160, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    _logger.info(f"Wrote {out_path}")

    # Standalone legend PNG for the region colors + median-trace overlay.
    # Kept separate so the main PC grid isn't squeezed by a large legend.
    legend_fig, legend_ax = plt.subplots(figsize=(3.2, 1.4))
    legend_ax.axis("off")
    handles = [
        plt.Line2D([], [], marker="o", color=color, linestyle="", markersize=7, label=region)
        for region, color in region_colors.items()
    ]
    handles.append(plt.Line2D([], [], color="black", linewidth=2, label="binned median"))
    handles.append(plt.Rectangle((0, 0), 1, 1, color="black", alpha=0.15, label="IQR (25–75%)"))
    legend_ax.legend(handles=handles, loc="center", frameon=False, fontsize=9)
    legend_path = PLOTS_DIR / f"pcs_over_pseudotime_{args.template}_{args.flavor}_{args.query_set}.legend.png"
    legend_fig.savefig(legend_path, dpi=160, bbox_inches="tight", facecolor="white")
    plt.close(legend_fig)
    _logger.info(f"Wrote {legend_path}")


if __name__ == "__main__":
    main()
