"""Sweep num_workers × buffer_size × cache_pool_bytes on the real 2D-MIP-BoC v2 parquet.

The earlier production A/B landed at ~65 samples/s with the training
config's ``num_workers=2, buffer_size=4, cache_pool_bytes=500MB``. This
sweep answers "can we push past that ceiling by turning the three
DataLoader/tensorstore knobs up"?

Three axes:

- ``num_workers`` — threads in MONAI's thread shim.  More threads →
  more concurrent ``ts.stack.read()`` calls (they release the GIL).
- ``buffer_size`` — MONAI's queue between the background fetcher and
  the consumer.  Lets the pipeline coast during long GPU steps.
- ``cache_pool_bytes`` — tensorstore's chunk cache budget, shared across
  the thread pool.  DynaCLR re-reads the same FOV for anchor + positive
  within a few batches so caching helps.

Fixed: production config, 10 warmup + 40 timed batches per cell.

Usage
-----
    uv run python applications/dynaclr/scripts/profiling/benchmark_boc2d_workers.py
"""

from __future__ import annotations

import statistics
import time
from dataclasses import dataclass

import numpy as np
from dynaclr.data.datamodule import MultiExperimentDataModule
from viscy_transforms import (
    BatchedChannelWiseZReductiond,
    BatchedRandSpatialCropd,
    NormalizeSampled,
)

CELL_INDEX_PARQUET = (
    "/hpc/projects/organelle_phenotyping/models/collections/DynaCLR-2D-MIP-BagOfChannels-v2.parquet"
)

BATCH_SIZE = 256
WARMUP_BATCHES = 10
N_BATCHES = 40
SEED = 42

# Sweep cells: (num_workers, buffer_size, cache_pool_bytes, label)
SWEEP: list[tuple[int, int, int, str]] = [
    (2, 4, 500_000_000, "baseline (prod config)"),
    (4, 4, 500_000_000, "nw=4, bs=4"),
    (8, 4, 500_000_000, "nw=8, bs=4"),
    (4, 16, 500_000_000, "nw=4, bs=16"),
    (8, 16, 500_000_000, "nw=8, bs=16"),
    (8, 16, 2_000_000_000, "nw=8, bs=16, cache=2GB"),
    (8, 16, 4_000_000_000, "nw=8, bs=16, cache=4GB"),
]


@dataclass
class CellResult:
    """Timing outcome for one sweep cell."""

    label: str
    num_workers: int
    buffer_size: int
    cache_pool_bytes: int
    iter_latencies_s: list[float]
    total_s: float

    @property
    def median_ms(self) -> float:
        """Return median inter-batch latency in milliseconds."""
        return statistics.median(self.iter_latencies_s) * 1000.0

    @property
    def p95_ms(self) -> float:
        """Return p95 inter-batch latency in milliseconds."""
        return float(np.percentile(self.iter_latencies_s, 95)) * 1000.0

    @property
    def iter_per_s(self) -> float:
        """Return sustained iterations per second."""
        return len(self.iter_latencies_s) / self.total_s

    @property
    def samples_per_s(self) -> float:
        """Return sustained samples per second."""
        return self.iter_per_s * BATCH_SIZE


def _build_dm(num_workers: int, buffer_size: int, cache_pool_bytes: int) -> MultiExperimentDataModule:
    """Build a production-config DataModule with overridden DataLoader knobs."""
    normalizations = [
        NormalizeSampled(keys=["channel_0"], level="timepoint_statistics", subtrahend="mean", divisor="std"),
    ]
    augmentations = [
        BatchedRandSpatialCropd(keys=["channel_0"], roi_size=(10, 192, 192)),
        BatchedChannelWiseZReductiond(keys=["channel_0"], allow_missing_keys=True),
    ]
    dm = MultiExperimentDataModule(
        cell_index_path=CELL_INDEX_PARQUET,
        focus_channel="Phase3D",
        reference_pixel_size_xy_um=0.1494,
        z_window=1,
        z_extraction_window=20,
        z_focus_offset=0.3,
        yx_patch_size=(256, 256),
        final_yx_patch_size=(160, 160),
        channels_per_sample=1,
        positive_cell_source="lookup",
        positive_match_columns=["lineage_id"],
        positive_channel_source="same",
        tau_range=(0.5, 2.0),
        tau_decay_rate=2.0,
        stratify_by=["perturbation", "marker"],
        split_ratio=0.8,
        batch_size=BATCH_SIZE,
        num_workers=num_workers,
        buffer_size=buffer_size,
        cache_pool_bytes=cache_pool_bytes,
        seed=SEED,
        normalizations=normalizations,
        augmentations=augmentations,
    )
    return dm


def _run_cell(num_workers: int, buffer_size: int, cache_pool_bytes: int, label: str) -> CellResult:
    """Run one sweep cell and return timing."""
    print(f"\n-- {label} (nw={num_workers}, bs={buffer_size}, cache={cache_pool_bytes // 1_000_000}MB) --", flush=True)
    dm = _build_dm(num_workers, buffer_size, cache_pool_bytes)
    dm.setup("fit")
    loader = dm.train_dataloader()
    it = iter(loader)

    for _ in range(WARMUP_BATCHES):
        _ = next(it)

    latencies_s: list[float] = []
    t_total = time.perf_counter()
    t_prev = time.perf_counter()
    for _ in range(N_BATCHES):
        _ = next(it)
        t_now = time.perf_counter()
        latencies_s.append(t_now - t_prev)
        t_prev = t_now
    total_s = time.perf_counter() - t_total

    del it
    del loader

    result = CellResult(
        label=label,
        num_workers=num_workers,
        buffer_size=buffer_size,
        cache_pool_bytes=cache_pool_bytes,
        iter_latencies_s=latencies_s,
        total_s=total_s,
    )
    print(
        f"  median {result.median_ms:.0f} ms | p95 {result.p95_ms:.0f} ms | "
        f"{result.iter_per_s:.2f} iter/s | {result.samples_per_s:.1f} samples/s",
        flush=True,
    )
    return result


def _print_markdown(results: list[CellResult]) -> None:
    """Emit a markdown-formatted results table."""
    print()
    print("## DataLoader-knob sweep (real 2D-MIP-BoC v2)")
    print()
    print(f"- Parquet: `{CELL_INDEX_PARQUET.split('/')[-1]}`")
    print(f"- Batch size: {BATCH_SIZE}, warmup: {WARMUP_BATCHES}, timed: {N_BATCHES}")
    print("- recheck_cached_data=open (datamodule default)")
    print()
    print("| config | num_workers | buffer_size | cache (MB) | median ms | p95 ms | iter/s | samples/s |")
    print("|---|---:|---:|---:|---:|---:|---:|---:|")
    for r in results:
        print(
            f"| {r.label} | {r.num_workers} | {r.buffer_size} | {r.cache_pool_bytes // 1_000_000} | "
            f"{r.median_ms:.0f} | {r.p95_ms:.0f} | {r.iter_per_s:.2f} | {r.samples_per_s:.1f} |"
        )
    print()


def main() -> None:
    """Run every cell and print a combined summary."""
    print("=" * 72)
    print("DataLoader-knob sweep — num_workers × buffer_size × cache_pool_bytes")
    print("=" * 72)

    results: list[CellResult] = []
    for nw, bs, cp, label in SWEEP:
        results.append(_run_cell(nw, bs, cp, label))

    _print_markdown(results)


if __name__ == "__main__":
    main()
