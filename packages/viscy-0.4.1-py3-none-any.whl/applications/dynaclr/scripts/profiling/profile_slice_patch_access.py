"""Micro-benchmark pandas Series vs NumPy array access in _slice_patch hot path.

Measures the 6 column reads that happen per anchor inside ``_slice_patch``
(store_path, fov_name, experiment, t, y_clamp, x_clamp) plus the 4 norm columns
(norm_mean/std/median/iqr) read inside ``_build_norm_meta``. Compares:

1. Pandas ``row[col]`` per row (legacy, via ``.iterrows``)
2. NumPy array indexing (current, post-refactor)

Run: uv run python applications/dynaclr/scripts/dataloader_inspection/profile_slice_patch_access.py
"""

# ruff: noqa: E402, D103
from __future__ import annotations

import time

import numpy as np
import pandas as pd

N_ROWS = 100_000
BATCH_SIZE = 512
N_BATCHES = 50


def _time(fn, *args, n=N_BATCHES):
    t = time.perf_counter()
    for _ in range(n):
        fn(*args)
    return (time.perf_counter() - t) / n * 1000  # ms per batch


def bench_series_access(rows):
    """Legacy: iterate rows, read each column from the Series."""
    out = []
    for _, row in rows.iterrows():
        store_path = row["store_path"]
        fov_name = row["fov_name"]
        exp_name = row["experiment"]
        t = int(row["t"])
        y = int(row["y_clamp"])
        x = int(row["x_clamp"])
        # norm columns from _build_norm_meta
        if "norm_mean" in row.index and pd.notna(row.get("norm_mean")):
            nm = row["norm_mean"]
            ns = row["norm_std"]
            nmed = row["norm_median"]
            niq = row["norm_iqr"]
            out.append((store_path, fov_name, exp_name, t, y, x, nm, ns, nmed, niq))
        else:
            out.append((store_path, fov_name, exp_name, t, y, x))


def bench_numpy_cache(arrays, indices):
    """Refactored: dict of NumPy arrays, indexed by positional idx."""
    out = []
    norm_mean_arr = arrays.get("norm_mean")
    for idx in indices:
        store_path = arrays["store_path"][idx]
        fov_name = arrays["fov_name"][idx]
        exp_name = arrays["experiment"][idx]
        t = int(arrays["t"][idx])
        y = int(arrays["y_clamp"][idx])
        x = int(arrays["x_clamp"][idx])
        if norm_mean_arr is not None:
            nm = norm_mean_arr[idx]
            if nm is not None and not (isinstance(nm, float) and np.isnan(nm)):
                ns = arrays["norm_std"][idx]
                nmed = arrays["norm_median"][idx]
                niq = arrays["norm_iqr"][idx]
                out.append((store_path, fov_name, exp_name, t, y, x, nm, ns, nmed, niq))
                continue
        out.append((store_path, fov_name, exp_name, t, y, x))


def main():
    print("# Profiling _slice_patch column-access hot path\n")
    rng = np.random.default_rng(42)

    # Synthesize a representative DataFrame
    df = pd.DataFrame(
        {
            "store_path": np.array(["/path/to/zarr"] * N_ROWS),
            "fov_name": np.array([f"A/{i % 96}/0" for i in range(N_ROWS)]),
            "experiment": np.array(["exp_a"] * N_ROWS),
            "t": rng.integers(0, 100, N_ROWS),
            "y_clamp": rng.integers(50, 500, N_ROWS),
            "x_clamp": rng.integers(50, 500, N_ROWS),
            "norm_mean": rng.normal(0, 1, N_ROWS).astype(np.float64),
            "norm_std": rng.normal(1, 0.1, N_ROWS).astype(np.float64),
            "norm_median": rng.normal(0, 1, N_ROWS).astype(np.float64),
            "norm_iqr": rng.normal(1, 0.1, N_ROWS).astype(np.float64),
        }
    )
    print(f"- Synthesized {len(df):,} rows")

    # Build NumPy array cache
    arrays = {col: df[col].to_numpy() for col in df.columns}

    # Realistic batch
    anchor_indices = rng.choice(N_ROWS, size=BATCH_SIZE, replace=False).tolist()
    rows = df.iloc[anchor_indices]

    # Anchor + positive = 2x reads per batch
    effective_reads = BATCH_SIZE * 2

    print(
        f"\n## Per-batch wall time (batch={BATCH_SIZE}, "
        f"effective {effective_reads} reads, n={N_BATCHES} runs)\n"
    )
    print("| Strategy | ms/batch | ms/read |")
    print("|---|---|---|")
    t1 = _time(bench_series_access, rows)
    print(f"| 1. Pandas `row[col]` + `.iterrows` (legacy) | {t1:.2f} | {t1 * 1000 / BATCH_SIZE:.1f} μs |")
    t2 = _time(bench_numpy_cache, arrays, anchor_indices)
    print(f"| 2. NumPy array indexing (refactored) | {t2:.2f} | {t2 * 1000 / BATCH_SIZE:.1f} μs |")

    print("\n## Speedup vs. legacy")
    print(f"- NumPy cache: **{t1 / t2:.1f}×**")
    print(
        f"- Anchor+positive per batch (x2): legacy ≈ {t1 * 2:.1f} ms, refactored ≈ {t2 * 2:.1f} ms"
    )


if __name__ == "__main__":
    main()
