"""Run a fixed-window production DataLoader benchmark for py-spy sampling.

Launches the real ``DynaCLR-2D-MIP-BagOfChannels.yml`` config, warms
``WARMUP_BATCHES`` to settle thread buffers and tensorstore caches, then
iterates ``N_BATCHES`` steady-state batches while printing its PID so an
external ``py-spy record --pid <PID>`` can sample the live process.

Expected usage
--------------

Terminal 1 (kicks off the benchmark and prints its PID):

    uv run python applications/dynaclr/scripts/profiling/pyspy_boc2d_real.py

Terminal 2 (sample for ~60s once the script prints ``SAMPLING NOW``):

    py-spy record -p <PID> -o /tmp/boc2d.svg -d 60 --idle --threads --rate 200

The resulting flame graph shows where steady-state time lives: inside
tensorstore's ``read().result()``, Python bookkeeping in
``_slice_patches``, positive lookup, pin-memory, or the training loop.
"""

from __future__ import annotations

import os
import time

from dynaclr.data.datamodule import MultiExperimentDataModule
from viscy_transforms import (
    BatchedChannelWiseZReductiond,
    BatchedRandSpatialCropd,
    NormalizeSampled,
)

CELL_INDEX_PARQUET = (
    "/hpc/projects/organelle_phenotyping/models/collections/DynaCLR-2D-MIP-BagOfChannels-v2.parquet"
)

BATCH_SIZE = 256
NUM_WORKERS = 2
WARMUP_BATCHES = 5
N_BATCHES = 20


def main() -> None:
    """Build the production DataModule and hand-iterate enough for py-spy."""
    normalizations = [
        NormalizeSampled(
            keys=["channel_0"],
            level="timepoint_statistics",
            subtrahend="mean",
            divisor="std",
        ),
    ]
    augmentations = [
        BatchedRandSpatialCropd(keys=["channel_0"], roi_size=(10, 192, 192)),
        BatchedChannelWiseZReductiond(keys=["channel_0"], allow_missing_keys=True),
    ]
    dm = MultiExperimentDataModule(
        cell_index_path=CELL_INDEX_PARQUET,
        focus_channel="Phase3D",
        reference_pixel_size_xy_um=0.1494,
        z_window=1,
        z_extraction_window=20,
        z_focus_offset=0.3,
        yx_patch_size=(256, 256),
        final_yx_patch_size=(160, 160),
        channels_per_sample=1,
        positive_cell_source="lookup",
        positive_match_columns=["lineage_id"],
        positive_channel_source="same",
        tau_range=(0.5, 2.0),
        tau_decay_rate=2.0,
        stratify_by=["perturbation", "marker"],
        split_ratio=0.8,
        batch_size=BATCH_SIZE,
        num_workers=NUM_WORKERS,
        seed=42,
        normalizations=normalizations,
        augmentations=augmentations,
    )
    print(f"PID: {os.getpid()}", flush=True)
    print("Building datamodule...", flush=True)
    dm.setup("fit")
    loader = dm.train_dataloader()
    it = iter(loader)

    print(f"Warmup: {WARMUP_BATCHES} batches...", flush=True)
    for _ in range(WARMUP_BATCHES):
        _ = next(it)

    print("SAMPLING NOW — start py-spy against this PID", flush=True)
    t0 = time.perf_counter()
    for i in range(N_BATCHES):
        _ = next(it)
        if (i + 1) % 10 == 0:
            elapsed = time.perf_counter() - t0
            print(
                f"  {i + 1}/{N_BATCHES} in {elapsed:.1f}s "
                f"({(i + 1) * BATCH_SIZE / elapsed:.1f} samples/s)",
                flush=True,
            )
    total = time.perf_counter() - t0
    print(f"Done: {N_BATCHES} batches in {total:.1f}s ({N_BATCHES * BATCH_SIZE / total:.1f} samples/s)", flush=True)

    del it
    del loader


if __name__ == "__main__":
    main()
