"""A/B throughput baseline for MultiExperimentDataModule.

Measures steady-state ``samples/s`` for the production DynaCLR-2D-MIP-BoC
config with one knob varied per invocation. Designed to be run repeatedly
across code changes to confirm a speedup is real, not noise.

Knobs (env vars, optional):
    RECHECK    None | "open" | "closed" | "false" — tensorstore recheck_cached_data
    NUM_WORKERS   int (default 2)
    LABEL      str — prepended to the final result line

Output: a single markdown table row printed at the end, suitable to paste
into a comparison log.

Usage
-----
    # baseline
    LABEL=baseline uv run python applications/dynaclr/scripts/profiling/ab_dataloader_throughput.py

    # with recheck=open
    LABEL=recheck_open RECHECK=open uv run python applications/dynaclr/scripts/profiling/ab_dataloader_throughput.py
"""

from __future__ import annotations

import os
import time

from dynaclr.data.datamodule import MultiExperimentDataModule
from viscy_transforms import (
    BatchedChannelWiseZReductiond,
    BatchedRandSpatialCropd,
    NormalizeSampled,
)


def _patch_shared_context() -> None:
    """Monkey-patch iohub's TensorStoreImplementation._context to return a
    process-wide singleton ts.Context instead of a per-plate Context.

    Without this, every open_ome_zarr(implementation="tensorstore") builds
    its own ts.Context → its own cache_pool. With 26 experiments that means
    26 independent 500 MB caches that never share chunks. Sharing collapses
    them into one pool.

    Enabled by env var SHARED_CTX=1.
    """
    import tensorstore as ts
    from iohub.core.implementations.tensorstore import TensorStoreImplementation

    _shared_ctx: list[ts.Context | None] = [None]

    original_context = TensorStoreImplementation._context

    def _shared_context(self: TensorStoreImplementation) -> ts.Context:
        if _shared_ctx[0] is None:
            _shared_ctx[0] = original_context(self)
            print(f"   [shared-ctx] created singleton Context", flush=True)
        return _shared_ctx[0]

    TensorStoreImplementation._context = _shared_context

CELL_INDEX_PARQUET = (
    "/hpc/projects/organelle_phenotyping/models/collections/DynaCLR-2D-MIP-BagOfChannels-v2.parquet"
)

BATCH_SIZE = 256
WARMUP_BATCHES = 5
N_BATCHES = 20


def _read_nfs_bytes() -> int | None:
    """Return cumulative bytes read over NFS for this process, or None.

    Parses /proc/self/mountstats for the organelle_phenotyping VAST mount.
    VAST uses NFSv3/RDMA; nfsiostat reports 0 for RDMA transports but
    /proc/self/mountstats has the real numbers under the 'bytes:' line.
    Column 5 of 'bytes:' is total bytes read from server.
    """
    try:
        with open("/proc/self/mountstats") as f:
            data = f.read()
    except OSError:
        return None
    in_block = False
    for line in data.splitlines():
        if "organelle_phenotyping" in line:
            in_block = True
            continue
        if in_block and line.startswith("device "):
            in_block = False
        if in_block and line.lstrip().startswith("bytes:"):
            parts = line.split()
            if len(parts) >= 6:
                return int(parts[5])
    return None


def _parse_recheck(raw: str | None) -> str | bool | None:
    if raw is None or raw == "" or raw.lower() == "none":
        return None
    if raw.lower() == "false":
        return False
    if raw.lower() == "true":
        return True
    return raw  # "open" | "closed"


def main() -> None:
    recheck = _parse_recheck(os.environ.get("RECHECK"))
    num_workers = int(os.environ.get("NUM_WORKERS", "2"))
    label = os.environ.get("LABEL", "run")
    data_copy_concurrency = os.environ.get("DCC")  # override for tensorstore data_copy_concurrency
    file_io_concurrency = os.environ.get("FIO")  # override for tensorstore file_io_concurrency
    shared_ctx = os.environ.get("SHARED_CTX", "0") == "1"
    if shared_ctx:
        _patch_shared_context()
        print("   [shared-ctx] enabled process-wide ts.Context singleton", flush=True)

    normalizations = [
        NormalizeSampled(
            keys=["channel_0"],
            level="timepoint_statistics",
            subtrahend="mean",
            divisor="std",
        ),
    ]
    augmentations = [
        BatchedRandSpatialCropd(keys=["channel_0"], roi_size=(10, 192, 192)),
        BatchedChannelWiseZReductiond(keys=["channel_0"], allow_missing_keys=True),
    ]
    dm = MultiExperimentDataModule(
        cell_index_path=CELL_INDEX_PARQUET,
        focus_channel="Phase3D",
        reference_pixel_size_xy_um=0.1494,
        z_window=1,
        z_extraction_window=20,
        z_focus_offset=0.3,
        yx_patch_size=(256, 256),
        final_yx_patch_size=(160, 160),
        channels_per_sample=1,
        positive_cell_source=os.environ.get("POS_SOURCE", "lookup"),
        positive_match_columns=["lineage_id"],
        positive_channel_source="same",
        tau_range=(0.5, 2.0),
        tau_decay_rate=2.0,
        stratify_by=["perturbation", "marker"],
        split_ratio=0.8,
        batch_size=BATCH_SIZE,
        num_workers=num_workers,
        seed=42,
        normalizations=normalizations,
        augmentations=augmentations,
        recheck_cached_data=recheck,
        file_io_concurrency=int(file_io_concurrency) if file_io_concurrency is not None else None,
    )
    if data_copy_concurrency is not None:
        dm.tensorstore_config = dm.tensorstore_config.model_copy(
            update={"data_copy_concurrency": int(data_copy_concurrency)}
        )
    print(
        f"## config: label={label} recheck={recheck!r} num_workers={num_workers} "
        f"dcc={dm.tensorstore_config.data_copy_concurrency} "
        f"fio={dm.tensorstore_config.file_io_concurrency} "
        f"batch={BATCH_SIZE} warmup={WARMUP_BATCHES} timed={N_BATCHES}",
        flush=True,
    )
    t_setup0 = time.perf_counter()
    dm.setup("fit")
    loader = dm.train_dataloader()
    it = iter(loader)
    t_setup = time.perf_counter() - t_setup0
    print(f"   setup took {t_setup:.1f}s", flush=True)

    t_warm0 = time.perf_counter()
    for i in range(WARMUP_BATCHES):
        _ = next(it)
    t_warm = time.perf_counter() - t_warm0
    print(f"   warmup {WARMUP_BATCHES} batches took {t_warm:.1f}s", flush=True)

    per_batch_s = []
    bytes_before = _read_nfs_bytes()
    t0 = time.perf_counter()
    t_prev = t0
    for i in range(N_BATCHES):
        _ = next(it)
        t_now = time.perf_counter()
        per_batch_s.append(t_now - t_prev)
        t_prev = t_now
    total = time.perf_counter() - t0
    bytes_after = _read_nfs_bytes()
    nfs_read_gb = (
        (bytes_after - bytes_before) / 1e9
        if bytes_before is not None and bytes_after is not None
        else float("nan")
    )
    nfs_rate_gbs = nfs_read_gb / total if total > 0 else float("nan")

    per_batch_s.sort()
    median = per_batch_s[len(per_batch_s) // 2]
    p95 = per_batch_s[int(len(per_batch_s) * 0.95)]
    samples_per_s = N_BATCHES * BATCH_SIZE / total

    print()
    print(
        "| label | recheck | num_workers | median ms | p95 ms | samples/s "
        "| total s | NFS GB read | NFS GB/s |"
    )
    print("|---|---|---:|---:|---:|---:|---:|---:|---:|")
    print(
        f"| {label} | {recheck!r} | {num_workers} | "
        f"{median * 1000:.0f} | {p95 * 1000:.0f} | {samples_per_s:.1f} | {total:.1f} "
        f"| {nfs_read_gb:.2f} | {nfs_rate_gbs:.2f} |",
        flush=True,
    )

    del it
    del loader


if __name__ == "__main__":
    main()
