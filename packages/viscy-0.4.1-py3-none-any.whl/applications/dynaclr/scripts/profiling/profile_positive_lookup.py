"""Micro-benchmark the positive-lookup hot path.

Measures wall time of each sub-step in ``__getitems__`` / ``_sample_positives``
on the canonical OPS parquet to identify the real bottleneck before any
rewrite. Compares:

1. Pandas ``.iloc`` per row (current)
2. Pandas ``.iloc[indices]`` batched
3. Pre-cached NumPy arrays (proposed refactor)
4. Polars equivalent (if installed)

Run: uv run python applications/dynaclr/scripts/dataloader_inspection/profile_positive_lookup.py
"""

# ruff: noqa: E402, D103
from __future__ import annotations

import time
from pathlib import Path

import numpy as np
import pandas as pd

PARQUET = Path("/hpc/projects/organelle_phenotyping/models/collections/ops_1000genes_allmarkers.parquet")
BATCH_SIZE = 512
N_BATCHES = 20


def bench_pandas_iloc(df, lookup, anchor_indices, rng):
    """Current strategy: .iloc per anchor, build tuple key, look up."""
    pos_indices = []
    for idx in anchor_indices:
        row = df.iloc[idx]
        key = (row["gene_name"], row["marker"])
        cands = lookup.get(key, [])
        cands = [c for c in cands if c != idx]
        if cands:
            pos_indices.append(cands[rng.integers(len(cands))])
        else:
            pos_indices.append(idx)
    _ = df.iloc[pos_indices]  # simulate downstream gather


def bench_pandas_iloc_batch(df, lookup, anchor_indices, rng):
    """Mid strategy: single .iloc[indices] call then row-iterate for positives."""
    sub = df.iloc[anchor_indices]
    pos_indices = []
    for idx, gene, marker in zip(anchor_indices, sub["gene_name"].values, sub["marker"].values):
        key = (gene, marker)
        cands = lookup.get(key, [])
        cands = [c for c in cands if c != idx]
        if cands:
            pos_indices.append(cands[rng.integers(len(cands))])
        else:
            pos_indices.append(idx)
    _ = df.iloc[pos_indices]


def bench_numpy_cache(genes_arr, markers_arr, lookup, anchor_indices, rng):
    """Proposed: all lookups via precomputed NumPy arrays, no Series construction."""
    pos_indices = []
    for idx in anchor_indices:
        key = (genes_arr[idx], markers_arr[idx])
        cands = lookup.get(key, [])
        cands = [c for c in cands if c != idx]
        if cands:
            pos_indices.append(cands[rng.integers(len(cands))])
        else:
            pos_indices.append(idx)
    # No downstream gather — indices are all we need for patch slicing


def bench_numpy_cache_vectorized(genes_arr, markers_arr, lookup, anchor_indices, rng):
    """Proposed + vectorized anchor-to-key mapping."""
    anchor_keys = list(zip(genes_arr[anchor_indices], markers_arr[anchor_indices]))
    pos_indices = []
    for idx, key in zip(anchor_indices, anchor_keys):
        cands = lookup.get(key, [])
        if not cands:
            pos_indices.append(idx)
        else:
            # Pre-exclude anchor — faster than list comprehension filter
            chosen = cands[rng.integers(len(cands))]
            if chosen == idx and len(cands) > 1:
                chosen = cands[(rng.integers(len(cands) - 1) + 1) % len(cands)]
            pos_indices.append(chosen)


def _time(fn, *args, n=N_BATCHES):
    t = time.perf_counter()
    for _ in range(n):
        fn(*args)
    return (time.perf_counter() - t) / n * 1000  # ms per batch


def main():
    print("# Profiling positive-lookup hot path\n")
    print(f"- Parquet: {PARQUET.name}")
    t = time.perf_counter()
    df = pd.read_parquet(PARQUET, columns=["gene_name", "marker"])
    print(f"- Load: {time.perf_counter() - t:.1f}s, {len(df):,} rows")

    # Simulate valid_anchors: filter to groups with ≥2 cells
    t = time.perf_counter()
    group_sizes = df.groupby(["gene_name", "marker"])["gene_name"].transform("size")
    valid = df[group_sizes >= 2].reset_index(drop=True)
    print(f"- valid_anchors: {time.perf_counter() - t:.1f}s, {len(valid):,} rows")

    t = time.perf_counter()
    grouped = valid.groupby(["gene_name", "marker"]).indices
    lookup = {k: v.tolist() for k, v in grouped.items()}
    print(f"- _match_lookup build: {time.perf_counter() - t:.1f}s, {len(lookup):,} keys")

    genes_arr = valid["gene_name"].to_numpy()
    markers_arr = valid["marker"].to_numpy()
    rng = np.random.default_rng(42)

    # Sample a realistic batch: single-marker group
    phase_indices = np.where(markers_arr == "Phase")[0]
    anchor_indices = rng.choice(phase_indices, size=BATCH_SIZE, replace=False).tolist()

    print(f"\n## Per-batch wall time (batch={BATCH_SIZE}, Phase marker, n={N_BATCHES} runs each)\n")
    print("| Strategy | ms/batch |")
    print("|---|---|")
    t1 = _time(bench_pandas_iloc, df, lookup, anchor_indices, rng)
    print(f"| 1. `.iloc` per row + downstream gather (current) | {t1:.2f} |")
    t2 = _time(bench_pandas_iloc_batch, df, lookup, anchor_indices, rng)
    print(f"| 2. `.iloc[indices]` batched | {t2:.2f} |")
    t3 = _time(bench_numpy_cache, genes_arr, markers_arr, lookup, anchor_indices, rng)
    print(f"| 3. NumPy-cached columns + dict lookup (proposed) | {t3:.2f} |")
    t4 = _time(bench_numpy_cache_vectorized, genes_arr, markers_arr, lookup, anchor_indices, rng)
    print(f"| 4. NumPy cached + vectorized key construction | {t4:.2f} |")

    print("\n## Speedup vs. current")
    print(f"- Batched .iloc: {t1 / t2:.1f}×")
    print(f"- NumPy cache: {t1 / t3:.1f}×")
    print(f"- NumPy + vectorized: {t1 / t4:.1f}×")

    # Polars if available
    try:
        import polars as pl

        print("\n## Polars comparison\n")
        t = time.perf_counter()
        pl_df = pl.read_parquet(PARQUET, columns=["gene_name", "marker"])
        print(f"- Polars load: {time.perf_counter() - t:.1f}s, {len(pl_df):,} rows")
        t = time.perf_counter()
        pl_lookup = (
            pl_df.filter(pl.col("gene_name").is_not_null())
            .with_row_index()
            .group_by(["gene_name", "marker"])
            .agg(pl.col("index"))
        )
        print(f"- Polars group_by build: {time.perf_counter() - t:.1f}s")
    except ImportError:
        print("\n(polars not installed — skipping)")


if __name__ == "__main__":
    main()
