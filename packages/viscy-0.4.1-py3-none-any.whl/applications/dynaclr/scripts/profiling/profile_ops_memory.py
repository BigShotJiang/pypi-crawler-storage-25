"""Profile per-stage RSS growth for OPS-1000genes-allmarkers setup.

Reproduces the OOM path from job 31264591: load the OPS parquet, compute
valid_anchors, build match_lookup, build anchor cache, twice (train + val).
Reports resident set size (RSS) delta after each step so we can attribute
the memory blow-up to a specific stage.

Runs single-rank (no DDP) on the login/dev node. Enough to confirm
per-rank memory; multiply by 4 for the 4-GPU DDP run.

Usage
-----
    uv run python applications/dynaclr/scripts/dataloader_inspection/profile_ops_memory.py
"""

from __future__ import annotations

import gc
import os
import resource
import time
from pathlib import Path

import psutil
import yaml

CONFIG_PATH = Path(
    "/hpc/mydata/eduardo.hirata/repos/viscy/applications/dynaclr/configs/training/OPS-1000genes-allmarkers.yml"
)


def rss_gb() -> float:
    """Current process RSS in GiB."""
    return psutil.Process(os.getpid()).memory_info().rss / (1024**3)


def peak_rss_gb() -> float:
    """Peak RSS since process start in GiB (Linux: ru_maxrss is KiB)."""
    return resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / (1024**2)


class Stopwatch:
    def __init__(self) -> None:
        self.t0 = time.perf_counter()
        self.rss0 = rss_gb()

    def mark(self, label: str) -> None:
        now_rss = rss_gb()
        dt = time.perf_counter() - self.t0
        d_rss = now_rss - self.rss0
        print(
            f"[{dt:6.1f}s] {label:<40s} RSS={now_rss:7.2f} GiB "
            f"(+{d_rss:+6.2f})  peak={peak_rss_gb():7.2f} GiB"
        )
        self.t0 = time.perf_counter()
        self.rss0 = now_rss


def main() -> None:
    sw = Stopwatch()
    sw.mark("process start")

    # Lazy imports so we see the import cost.
    import pandas as pd  # noqa: F401

    sw.mark("import pandas")

    import numpy as np  # noqa: F401

    sw.mark("import numpy")

    from dynaclr.data.datamodule import MultiExperimentDataModule

    sw.mark("import MultiExperimentDataModule")

    # Load the OPS allmarkers YAML and extract the data init_args.
    with open(CONFIG_PATH) as f:
        cfg = yaml.safe_load(f)

    data_args = cfg["data"]["init_args"]
    sw.mark("load YAML")

    # Build the DM. Force num_workers=0 so the process itself carries the
    # entire memory footprint (no fork-copy effects; reflects one DDP rank).
    data_args["num_workers"] = 0
    # Strip normalizations — that's a separate cost we don't care about here.
    data_args.pop("normalizations", None)

    dm = MultiExperimentDataModule(**data_args)
    sw.mark("instantiate DataModule (no setup)")

    # setup("fit") is what the OOM job ran. Instrument by monkeypatching.
    from dynaclr.data import dataset as dataset_mod

    orig_build_match = dataset_mod.MultiExperimentTripletDataset._build_match_lookup
    orig_build_cache = dataset_mod.MultiExperimentTripletDataset._build_anchor_cache

    call_counter = {"match": 0, "cache": 0}

    def logged_build_match(self):
        call_counter["match"] += 1
        tag = f"_build_match_lookup #{call_counter['match']}"
        t0 = time.perf_counter()
        rss0 = rss_gb()
        orig_build_match(self)
        dt = time.perf_counter() - t0
        print(
            f"           {tag:<40s} +{rss_gb() - rss0:+.2f} GiB ({dt:.1f}s)"
        )

    def logged_build_cache(self):
        call_counter["cache"] += 1
        tag = f"_build_anchor_cache #{call_counter['cache']}"
        t0 = time.perf_counter()
        rss0 = rss_gb()
        orig_build_cache(self)
        dt = time.perf_counter() - t0
        # Report size of the cache itself.
        va_bytes = sum(
            getattr(a, "nbytes", 0) for a in getattr(self, "_va_arrays", {}).values()
        )
        tr_bytes = sum(
            getattr(a, "nbytes", 0) for a in getattr(self, "_tr_arrays", {}).values()
        )
        print(
            f"           {tag:<40s} +{rss_gb() - rss0:+.2f} GiB ({dt:.1f}s) "
            f"va_arrays={va_bytes / 1024**3:.2f} GiB "
            f"tr_arrays={tr_bytes / 1024**3:.2f} GiB"
        )

    dataset_mod.MultiExperimentTripletDataset._build_match_lookup = logged_build_match
    dataset_mod.MultiExperimentTripletDataset._build_anchor_cache = logged_build_cache

    print("\n--- dm.setup('fit') ---")
    dm.setup("fit")
    sw.mark("setup('fit') complete")

    # Report dataset sizes.
    if dm.train_dataset is not None:
        print(
            f"  train_dataset: {len(dm.train_dataset):,} anchors, "
            f"tracks={len(dm.train_dataset.index.tracks):,}"
        )
    if dm.val_dataset is not None:
        print(
            f"  val_dataset:   {len(dm.val_dataset):,} anchors, "
            f"tracks={len(dm.val_dataset.index.tracks):,}"
        )

    gc.collect()
    sw.mark("gc.collect()")

    print("\n--- Summary ---")
    print(f"Peak RSS this process: {peak_rss_gb():.2f} GiB")
    print(f"Per 4-rank DDP node (naive × 4): {peak_rss_gb() * 4:.1f} GiB")


if __name__ == "__main__":
    main()
