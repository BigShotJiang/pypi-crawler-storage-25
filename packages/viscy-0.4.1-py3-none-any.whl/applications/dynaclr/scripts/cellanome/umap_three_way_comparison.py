"""UMAP comparison: frozen-baseline vs frozen-xmodal vs unfrozen-xmodal.

Plots three side-by-side UMAPs of the encoder's 768-d backbone features,
colored by cell-cycle phase. Uses the same UMAP hyperparameters across all
three for fair visual comparison. Operates on the val-split cells from the
SLURM v1 runs (so each run uses the same cell pool).
"""

from __future__ import annotations

from pathlib import Path

import anndata as ad
import matplotlib.pyplot as plt
import numpy as np
import seaborn as sns
import umap
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler

DATASET_DIR = Path(
    "/hpc/projects/multimodal/datasets/cellanome/"
    "20260401095121_P-05_R000515_FC_2026_04_01_A549_SEC61B_DENV_ZIKV_mRNA+imaging"
)
RUN_ROOT = Path(
    "/hpc/mydata/eduardo.hirata/repos/viscy/applications/dynaclr/scripts/"
    "cellanome/output/DynaCLR-2D-Cellanome-A549"
)
FROZEN_RUN = RUN_ROOT / "DynaCLR-2D-Cellanome-A549-frozen-X_pls-v1"
UNFROZEN_RUN = RUN_ROOT / "DynaCLR-2D-Cellanome-A549-unfrozen-X_pls-v1"
OUT_DIR = RUN_ROOT / "umap_comparison"
OUT_DIR.mkdir(parents=True, exist_ok=True)

UMAP_KW = dict(n_neighbors=10, min_dist=0.1, metric="cosine", random_state=0)
N_PCS = 40
PHASE_PALETTE = {"G1": "#1F77B4", "S": "#2CA02C", "G2M": "#FF7F0E"}


def load_baseline_features(val_phase: np.ndarray, n: int) -> np.ndarray:
    """Extract n raw frozen-baseline 768-d features from the precomputed zarr.

    We pick the same number of cells as the val pool, stratified by phase, so
    the visual is comparable.
    """
    cell_index = ad.read_zarr(DATASET_DIR / "2-embeddings/dynaclr_2d_boc_BF.zarr")
    tx = ad.read_h5ad(DATASET_DIR / "2-embeddings/A549_single_cell_embedded.h5ad", backed="r")
    barcode_keys = (
        tx.obs["barcode.sequence"].astype(str) + "-" + tx.obs["lane"].astype(str)
    ).to_numpy()
    barcode_to_idx = {bc: i for i, bc in enumerate(barcode_keys)}
    phase_per_cell = np.full(cell_index.n_obs, "", dtype=object)
    img_b = cell_index.obs["barcode_index"].astype(str).to_numpy()
    tx_phase = tx.obs["phase"].astype(str).to_numpy()
    for i, bc in enumerate(img_b):
        j = barcode_to_idx.get(bc)
        if j is not None:
            phase_per_cell[i] = tx_phase[j]
    paired_mask = phase_per_cell != ""
    features = np.asarray(cell_index.X[paired_mask], dtype=np.float32)
    labels = phase_per_cell[paired_mask]

    # Subsample with the same per-class proportions as val_phase
    rng = np.random.default_rng(0)
    n_per_class = {p: int((val_phase == p).sum()) for p in PHASE_PALETTE}
    chosen: list[int] = []
    chosen_labels: list[str] = []
    for p, k in n_per_class.items():
        idx = np.where(labels == p)[0]
        if len(idx) < k:
            print(f"WARNING: only {len(idx)} cells in baseline class {p} (wanted {k})")
            k = len(idx)
        pick = rng.choice(idx, size=k, replace=False)
        chosen.extend(pick.tolist())
        chosen_labels.extend([p] * k)
    chosen_arr = np.asarray(chosen)
    return features[chosen_arr], np.asarray(chosen_labels)


def umap_embed(x: np.ndarray) -> np.ndarray:
    """Z-score → PCA(N_PCS) → UMAP. Standard scanpy-style preprocessing."""
    x_z = StandardScaler().fit_transform(x)
    x_pca = PCA(n_components=N_PCS, random_state=0).fit_transform(x_z)
    return umap.UMAP(**UMAP_KW).fit_transform(x_pca)


def panel(ax, emb: np.ndarray, labels: np.ndarray, title: str) -> None:
    sns.scatterplot(
        x=emb[:, 0],
        y=emb[:, 1],
        hue=labels,
        hue_order=["G1", "S", "G2M"],
        palette=PHASE_PALETTE,
        s=4,
        linewidth=0,
        alpha=0.7,
        ax=ax,
    )
    ax.set_title(title, fontsize=11)
    ax.set_xlabel("UMAP 1")
    ax.set_ylabel("UMAP 2")
    ax.set_xticks([])
    ax.set_yticks([])
    ax.legend(loc="best", fontsize=8, markerscale=2, frameon=False)


def main() -> None:
    print("## Loading run features")
    frozen_feats = np.load(FROZEN_RUN / "val_features.npy")
    frozen_phase = np.load(FROZEN_RUN / "val_phase.npy", allow_pickle=True).astype(str)
    unfrozen_feats = np.load(UNFROZEN_RUN / "val_features.npy")
    unfrozen_phase = np.load(UNFROZEN_RUN / "val_phase.npy", allow_pickle=True).astype(str)
    print(f"- frozen run: {frozen_feats.shape}, phases: {dict(zip(*np.unique(frozen_phase, return_counts=True)))}")
    print(f"- unfrozen run: {unfrozen_feats.shape}, phases: {dict(zip(*np.unique(unfrozen_phase, return_counts=True)))}")

    print("\n## Sampling matched baseline subset from precomputed zarr")
    baseline_feats, baseline_phase = load_baseline_features(frozen_phase, n=len(frozen_phase))
    print(f"- baseline: {baseline_feats.shape}")

    print("\n## Computing UMAPs")
    print("- baseline …")
    e_base = umap_embed(baseline_feats)
    print("- frozen-xmodal …")
    e_frozen = umap_embed(frozen_feats)
    print("- unfrozen-xmodal …")
    e_unfrozen = umap_embed(unfrozen_feats)

    print("\n## Plotting")
    fig, axes = plt.subplots(1, 3, figsize=(15, 5))
    panel(axes[0], e_base, baseline_phase, "Frozen baseline\n(no fine-tuning)")
    panel(axes[1], e_frozen, frozen_phase, "Cross-modal head\n(frozen encoder)")
    panel(axes[2], e_unfrozen, unfrozen_phase, "Cross-modal head\n(unfrozen encoder)")
    fig.suptitle(
        f"UMAP of 768-d image features (PCA→{N_PCS}, n_neighbors={UMAP_KW['n_neighbors']}, "
        f"min_dist={UMAP_KW['min_dist']}), colored by phase",
        fontsize=12,
    )
    fig.tight_layout()
    out_path = OUT_DIR / "umap_three_way_phase.png"
    fig.savefig(out_path, dpi=200, bbox_inches="tight")
    plt.close(fig)
    print(f"- saved {out_path}")

    # Save the embeddings + labels for re-plotting later
    np.savez(
        OUT_DIR / "umap_three_way.npz",
        baseline_emb=e_base,
        baseline_phase=baseline_phase,
        frozen_emb=e_frozen,
        frozen_phase=frozen_phase,
        unfrozen_emb=e_unfrozen,
        unfrozen_phase=unfrozen_phase,
    )
    print(f"- saved arrays to {OUT_DIR / 'umap_three_way.npz'}")


if __name__ == "__main__":
    main()
