"""Train DynaCLR-2D-Cellanome-A549 — DynaCLR + cross-modal contrastive head.

Loads the trained 2D BF DynaCLR backbone and adds a
:class:`CrossModalContrastiveHead` that pulls image features toward paired
transcriptomic embeddings (default: ``X_pls`` from the cellanome A549 h5ad).
After training, extracts backbone features on the held-out val split and runs
a logistic-regression phase probe to compare against the published 77%
baseline.

Modes
-----
``--fastdev``
    1k-cell smoke run, ``fast_dev_run=5``. No checkpoint loading by default
    (use ``--ckpt`` to verify the load path).
``--frozen``
    Freeze backbone, train only the cross-modal head + projection MLP. Cheap
    diagnostic — does the head alone reshape the projection enough to lift
    phase accuracy?
``--unfrozen`` (default)
    Full fine-tune: backbone + projection + cross-modal head all train.

Usage
-----
Smoke test (single GPU, no W&B)::

    uv run python applications/dynaclr/scripts/cellanome/train_dynaclr_cellanome_a549.py --fastdev

Frozen backbone, 20 epochs, W&B::

    uv run python applications/dynaclr/scripts/cellanome/train_dynaclr_cellanome_a549.py \\
        --frozen --epochs 20 --wandb

Full fine-tune::

    uv run python applications/dynaclr/scripts/cellanome/train_dynaclr_cellanome_a549.py \\
        --epochs 30 --wandb --run-name DynaCLR-2D-Cellanome-A549-unfrozen-v0
"""

from __future__ import annotations

import argparse
from pathlib import Path

import lightning.pytorch as pl
import numpy as np
import pandas as pd
import torch
from lightning.pytorch.callbacks import ModelCheckpoint
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from torch.utils.data import DataLoader, Dataset

from cross_modal_dataset import CellanomePairedConfig, CellanomePairedDataset, collate_paired

from dynaclr.engine import ContrastiveModule
from viscy_models.contrastive import ContrastiveEncoder
from viscy_models.contrastive.loss import NTXentLoss
from viscy_models.components.heads import CrossModalContrastiveHead

DATASET_DIR = (
    "/hpc/projects/multimodal/datasets/cellanome/"
    "20260401095121_P-05_R000515_FC_2026_04_01_A549_SEC61B_DENV_ZIKV_mRNA+imaging"
)
DEFAULT_CKPT = (
    "/hpc/projects/organelle_phenotyping/models/SEC61_TOMM20_G3BP1_Sensor/"
    "time_interval/dynaclr_gfp_rfp_Ph/"
    "organelle_sensor_phase_maxproj_ver3_150epochs/"
    "saved_checkpoints/epoch=104-step=53760.ckpt"
)
DEFAULT_OUT = (
    "/hpc/mydata/eduardo.hirata/repos/viscy/applications/dynaclr/scripts/"
    "cellanome/output/DynaCLR-2D-Cellanome-A549"
)
PROJECT_NAME = "DynaCLR-2D-Cellanome-A549"


def build_config(pairs_only: bool, target_keys: tuple[str, ...]) -> CellanomePairedConfig:
    """Construct the cellanome-A549 dataset config."""
    return CellanomePairedConfig(
        zarr_store=(
            f"{DATASET_DIR}/0-convert/ome-zarr/"
            "20260401095121_P-05_R000515_FC_2026_04_01_A549_SEC61B_DENV_ZIKV_mRNA+imaging.zarr"
        ),
        cell_index_zarr=f"{DATASET_DIR}/2-embeddings/dynaclr-2d-boc-BF.zarr",
        transcriptome_h5ad=f"{DATASET_DIR}/A549_single_cell_embedded.h5ad",
        target_keys=target_keys,
        pairs_only=pairs_only,
    )


def stratified_split(
    cfg: CellanomePairedConfig, val_fraction: float, seed: int
) -> tuple[np.ndarray, np.ndarray]:
    """Stratified train/val split on phase across paired cells."""
    ds_full = CellanomePairedDataset(cfg, augment=False)
    phase = ds_full.phase_labels
    n = len(phase)
    indices = np.arange(n)
    paired_mask = phase != ""
    paired_idx = indices[paired_mask]
    paired_phase = phase[paired_mask]
    train_p, val_p = train_test_split(
        paired_idx,
        test_size=val_fraction,
        stratify=paired_phase,
        random_state=seed,
    )
    return train_p, val_p


class CellanomeDataModule(pl.LightningDataModule):
    """Thin Lightning datamodule wrapping :class:`CellanomePairedDataset`."""

    def __init__(
        self,
        cfg: CellanomePairedConfig,
        train_indices: np.ndarray,
        val_indices: np.ndarray,
        batch_size: int,
        num_workers: int,
    ) -> None:
        super().__init__()
        self.cfg = cfg
        self.train_indices = train_indices
        self.val_indices = val_indices
        self.batch_size = batch_size
        self.num_workers = num_workers

    def setup(self, stage: str | None = None) -> None:  # noqa: D102
        self.train_ds = CellanomePairedDataset(self.cfg, indices=self.train_indices, augment=True)
        self.val_ds = CellanomePairedDataset(self.cfg, indices=self.val_indices, augment=False)

    def train_dataloader(self) -> DataLoader:  # noqa: D102
        return DataLoader(
            self.train_ds,
            batch_size=self.batch_size,
            shuffle=True,
            num_workers=self.num_workers,
            collate_fn=collate_paired,
            persistent_workers=self.num_workers > 0,
            pin_memory=True,
        )

    def val_dataloader(self) -> DataLoader:  # noqa: D102
        return DataLoader(
            self.val_ds,
            batch_size=self.batch_size,
            shuffle=False,
            num_workers=self.num_workers,
            collate_fn=collate_paired,
            persistent_workers=self.num_workers > 0,
            pin_memory=True,
        )


def build_model(
    ckpt_path: str | None,
    target_dim: int,
    target_key: str,
    freeze_backbone: bool,
    lr: float,
) -> ContrastiveModule:
    """Build ContrastiveModule with cross-modal head, optionally checkpoint-loaded."""
    encoder = ContrastiveEncoder(
        backbone="convnext_tiny",
        in_channels=1,
        embedding_dim=768,
        in_stack_depth=1,
        stem_kernel_size=(1, 4, 4),
        stem_stride=(1, 4, 4),
        projection_dim=32,
        drop_path_rate=0.1,
    )
    head = CrossModalContrastiveHead(
        head_name="xmodal",
        batch_key=target_key,
        in_dims=768,
        target_dims=target_dim,
        proj_dims=128,
        temperature=0.1,
        loss_weight=1.0,
    )
    return ContrastiveModule(
        encoder=encoder,
        loss_function=NTXentLoss(temperature=0.2),
        lr=lr,
        log_batches_per_epoch=2,
        log_samples_per_batch=2,
        log_embeddings_every_n_epochs=10,
        log_negative_metrics_every_n_epochs=2,
        example_input_array_shape=(1, 1, 1, 160, 160),
        ckpt_path=ckpt_path,
        freeze_backbone=freeze_backbone,
        auxiliary_heads={"xmodal": head},
    )


def build_trainer(
    fastdev: bool,
    epochs: int,
    out_dir: Path,
    run_name: str,
    use_wandb: bool,
) -> pl.Trainer:
    """Lightning Trainer with optional W&B + checkpoint callback."""
    if fastdev:
        return pl.Trainer(
            accelerator="gpu",
            devices=1,
            strategy="auto",
            precision="bf16-mixed",
            fast_dev_run=5,
            logger=False,
            enable_checkpointing=False,
            enable_model_summary=False,
            inference_mode=False,
            use_distributed_sampler=False,
            benchmark=True,
        )
    logger = False
    if use_wandb:
        from lightning.pytorch.loggers import WandbLogger

        logger = WandbLogger(project=PROJECT_NAME, name=run_name, save_dir=str(out_dir))
    ckpt_cb = ModelCheckpoint(
        dirpath=str(out_dir / run_name / "checkpoints"),
        filename="{epoch:02d}-{val_loss:.4f}",
        monitor="loss/aux/xmodal/val",
        mode="min",
        save_top_k=2,
        save_last=True,
    )
    return pl.Trainer(
        accelerator="gpu",
        devices=1,
        strategy="auto",
        precision="bf16-mixed",
        max_epochs=epochs,
        log_every_n_steps=20,
        logger=logger,
        callbacks=[ckpt_cb],
        enable_checkpointing=True,
        enable_model_summary=False,
        inference_mode=False,
        use_distributed_sampler=False,
        benchmark=True,
    )


def extract_features(model: ContrastiveModule, loader: DataLoader, device: str) -> tuple[np.ndarray, np.ndarray]:
    """Run the encoder on a loader and return (features, phase_labels)."""
    model.eval().to(device)
    feats: list[np.ndarray] = []
    phases: list[str] = []
    with torch.no_grad():
        for batch in loader:
            anchor = batch["anchor"].to(device)
            f, _ = model(anchor)
            feats.append(f.float().cpu().numpy())
            phases.extend(m["phase"] for m in batch["anchor_meta"])
    return np.concatenate(feats), np.asarray(phases)


def phase_probe(
    train_feats: np.ndarray, train_phase: np.ndarray, val_feats: np.ndarray, val_phase: np.ndarray
) -> dict[str, float]:
    """Train logistic regression on train_feats, score on val_feats."""
    train_mask = train_phase != ""
    val_mask = val_phase != ""
    clf = LogisticRegression(max_iter=2000)
    clf.fit(train_feats[train_mask], train_phase[train_mask])
    val_acc = float((clf.predict(val_feats[val_mask]) == val_phase[val_mask]).mean())
    train_acc = float((clf.predict(train_feats[train_mask]) == train_phase[train_mask]).mean())
    return {"train_acc": train_acc, "val_acc": val_acc, "n_val_paired": int(val_mask.sum())}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--fastdev", action="store_true", help="fast_dev_run=5 smoke test")
    parser.add_argument("--frozen", action="store_true", help="freeze backbone, train head only")
    parser.add_argument("--epochs", type=int, default=20)
    parser.add_argument("--batch-size", type=int, default=64)
    parser.add_argument("--num-workers", type=int, default=4)
    parser.add_argument("--lr", type=float, default=2e-5)
    parser.add_argument("--val-fraction", type=float, default=0.2)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--max-train", type=int, default=None, help="Cap training set size (random sample)")
    parser.add_argument("--max-val", type=int, default=None, help="Cap validation set size (random sample)")
    parser.add_argument("--ckpt", default=DEFAULT_CKPT, help="DynaCLR backbone checkpoint")
    parser.add_argument("--no-ckpt", action="store_true", help="skip checkpoint loading")
    parser.add_argument("--target", default="X_pls", help="paired-target obsm key from h5ad")
    parser.add_argument("--target-dim", type=int, default=50)
    parser.add_argument("--out-dir", default=DEFAULT_OUT)
    parser.add_argument("--run-name", default=None)
    parser.add_argument("--wandb", action="store_true", help="enable W&B logging")
    args = parser.parse_args()

    pl.seed_everything(args.seed, workers=True)
    torch.set_float32_matmul_precision("high")

    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    run_tag = "frozen" if args.frozen else "unfrozen"
    run_name = args.run_name or f"{PROJECT_NAME}-{run_tag}-{args.target}"
    print(f"## Run: {run_name}")
    print(f"## Output: {out_dir / run_name}")

    cfg = build_config(pairs_only=True, target_keys=(args.target,))
    print("## Building stratified split (paired cells only)")
    train_idx, val_idx = stratified_split(cfg, args.val_fraction, args.seed)
    print(f"- train: {len(train_idx)} | val: {len(val_idx)}")

    rng = np.random.default_rng(args.seed)
    if args.fastdev:
        train_idx = train_idx[:1024]
        val_idx = val_idx[:256]
        print(f"- fastdev subset: train={len(train_idx)}, val={len(val_idx)}")
    else:
        if args.max_train is not None and args.max_train < len(train_idx):
            train_idx = rng.choice(train_idx, size=args.max_train, replace=False)
            print(f"- capped train: {len(train_idx)}")
        if args.max_val is not None and args.max_val < len(val_idx):
            val_idx = rng.choice(val_idx, size=args.max_val, replace=False)
            print(f"- capped val:   {len(val_idx)}")

    dm = CellanomeDataModule(
        cfg,
        train_indices=train_idx,
        val_indices=val_idx,
        batch_size=8 if args.fastdev else args.batch_size,
        num_workers=0 if args.fastdev else args.num_workers,
    )

    ckpt_path = None if (args.no_ckpt or args.fastdev) else args.ckpt
    model = build_model(
        ckpt_path=ckpt_path,
        target_dim=args.target_dim,
        target_key=args.target,
        freeze_backbone=args.frozen,
        lr=args.lr,
    )

    trainer = build_trainer(
        fastdev=args.fastdev,
        epochs=args.epochs,
        out_dir=out_dir,
        run_name=run_name,
        use_wandb=args.wandb,
    )

    print("\n## Training")
    trainer.fit(model, datamodule=dm)

    if args.fastdev:
        print("\n## Skipping phase probe in fastdev mode")
        return

    print("\n## Extracting features for phase probe")
    dm.setup()
    device = "cuda" if torch.cuda.is_available() else "cpu"
    train_feats, train_phase = extract_features(model, dm.train_dataloader(), device)
    val_feats, val_phase = extract_features(model, dm.val_dataloader(), device)

    print("\n## Phase linear probe")
    scores = phase_probe(train_feats, train_phase, val_feats, val_phase)
    print(f"- train acc: {scores['train_acc']:.4f}")
    print(f"- val   acc: {scores['val_acc']:.4f}")
    print(f"- val paired: {scores['n_val_paired']}")
    pd.DataFrame([scores | {"run_name": run_name}]).to_csv(
        out_dir / run_name / "phase_probe.csv", index=False
    )
    np.save(out_dir / run_name / "val_features.npy", val_feats)
    np.save(out_dir / run_name / "val_phase.npy", val_phase)

    print(f"\n## Done — outputs in {out_dir / run_name}")


if __name__ == "__main__":
    main()
