"""Inspect the actual patches fed to the model for cellanome inference.

Jupyter-style notebook (use ``# %%`` cells in VS Code or JupyterLab).

Shows the resized patches exactly as the model receives them, so you can
verify the crop size captures the full cell at the right scale.
Reads primary_analysis.csv directly (same source as the embed scripts).

Usage::

    uv run python applications/dynaclr/scripts/cellanome/inspect_crops.py
"""

# ruff: noqa: E402, D103

# %%
from __future__ import annotations

from pathlib import Path

import anndata as ad
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import torch
import torch.nn.functional as F
import zarr

CHANNEL_SHORT_NAMES = {
    "White": "BF",
    "Blue-FITC (520)": "FITC",
    "Red-CY5 (700)": "CY5",
    "Green-CY3 (605)": "CY3",
}

# %% [markdown]
# ## Configuration

# %%
ZARR_STORE = "/hpc/projects/multimodal/datasets/20251203141914_P-05_R000414_FC_BH_120325_try4_Adherent_with_SRA_training_4lanes/20251203141914_P-05_R000414_FC_BH_120325_try4_Adherent_with_SRA_training_4lanes.zarr"
ANALYSIS_BASE = "/hpc/instruments/cm.r3200/20251203141914_P-05_R000414_FC_BH_120325_try4_Adherent_with_SRA_training_4lanes/image_analysis_output-12032025-143316"
TRANSCRIPTOME_ANNDATA = "/hpc/projects/multimodal/datasets/20251203141914_P-05_R000414_FC_BH_120325_try4_Adherent_with_SRA_training_4lanes/anndata/seurat-bc3a-l_all.zarr"

# Run on one scan/lane for quick inspection
SCAN_ID = 5
LANE_ID = 3

# --- Crop parameters ---
PATCH_SIZE = 160
REFERENCE_PIXEL_SIZE = 0.149
SOURCE_PIXEL_SIZE = 0.247

# --- Filtering ---
MIN_RADIUS_PX = 35
MAX_RADIUS_PX = None  # set to e.g. 50 to show only small cells
OBJECT_CLASSES = ["cell", "cell-adhered"]
SHOW_NEAR_THRESHOLD = True  # show cells near MIN_RADIUS_PX boundary

# --- Display ---
CHANNEL_IDX = 0  # 0=White/BF
N_CELLS = 16
N_COLS = 4
SEED = 42
OUTPUT_PATH = None  # "crops.png" to save

# %% [markdown]
# ## Load primary_analysis.csv and prepare data

# %%
csv_path = (
    Path(ANALYSIS_BASE)
    / f"scan_{SCAN_ID}"
    / f"lane_{LANE_ID}"
    / "processed"
    / "CAGE_REGISTRATION"
    / "primary_analysis.csv"
)
df = pd.read_csv(csv_path)
print(f"Loaded {len(df)} objects from {csv_path.name}")

# Filter
df = df[df["object_class"].isin(OBJECT_CLASSES)]
df_all_cells = df.copy()  # keep unfiltered for threshold inspection
df = df[df["object_radius_px"] >= MIN_RADIUS_PX]
if MAX_RADIUS_PX is not None:
    df = df[df["object_radius_px"] <= MAX_RADIUS_PX]
print(f"After filtering: {len(df)} cells (from {len(df_all_cells)} total)")
print(f"Radius range: [{df['object_radius_px'].min()}, {df['object_radius_px'].max()}]")


# Derive zarr paths
def _parse_position(cage_crop: str) -> str:
    parts = str(cage_crop).split("_")
    return f"{parts[4]}{parts[5]}"


df["zarr_position"] = df["cage_crop_file_name"].apply(_parse_position)
df["zarr_path"] = (
    df["lane_id"].astype(str)
    + "/"
    + df["scan_id"].astype(str)
    + "/"
    + df["zarr_position"]
)

# Barcode lookup
adata = ad.read_zarr(TRANSCRIPTOME_ANNDATA)
obs = adata.obs.copy()
obs["_lane"] = obs.index.str.extract(r"(lane_\d)")[0].values
obs["_cage_id"] = obs["global.cage.id.matched"].astype(int)
obs_set = set(adata.obs_names)

barcode_lookup: dict[tuple[int, str], list[str]] = {}
for idx, row in obs.iterrows():
    key = (row["_cage_id"], row["_lane"])
    barcode_lookup.setdefault(key, []).append(idx)

# Join barcodes
barcode_indices = []
for _, row in df.iterrows():
    key = (int(row["global_cage_id_matched"]), f"lane_{int(row['lane_id'])}")
    barcodes = barcode_lookup.get(key, [])
    barcode_indices.append(";".join(barcodes) if barcodes else "")
df["barcode_index"] = barcode_indices
df["in_anndata"] = df["barcode_index"] != ""
df = df.reset_index(drop=True)
print(f"Barcode match: {df['in_anndata'].sum()}/{len(df)} cells")

# Crop parameters
raw_half = round(PATCH_SIZE * REFERENCE_PIXEL_SIZE / SOURCE_PIXEL_SIZE) // 2
raw_crop_size = 2 * raw_half
print(
    f"Raw crop: {raw_crop_size}x{raw_crop_size} -> resize to {PATCH_SIZE}x{PATCH_SIZE}"
)

store = zarr.open(ZARR_STORE, mode="r")

# %% [markdown]
# ## Plot model-input patches

# %%
rng = np.random.default_rng(SEED)
sample_idx = rng.choice(len(df), size=min(N_CELLS, len(df)), replace=False)
sample_idx.sort()
sample_df = df.iloc[sample_idx].reset_index(drop=True)

n_rows = int(np.ceil(len(sample_df) / N_COLS))
fig, axes = plt.subplots(
    n_rows, N_COLS, figsize=(N_COLS * 3.5, n_rows * 4.0), squeeze=False
)

for i, (_, row) in enumerate(sample_df.iterrows()):
    ax = axes[i // N_COLS, i % N_COLS]
    zarr_path = row["zarr_path"]
    cy, cx = int(row["object_y_fov"]), int(row["object_x_fov"])

    fov = store[zarr_path]["0"][0, :, 0]
    _, fov_h, fov_w = fov.shape

    y0, y1 = cy - raw_half, cy + raw_half
    x0, x1 = cx - raw_half, cx + raw_half
    if y0 < 0 or x0 < 0 or y1 > fov_h or x1 > fov_w:
        ax.text(0.5, 0.5, "BORDER", transform=ax.transAxes, ha="center", va="center")
        ax.set_xticks([])
        ax.set_yticks([])
        continue

    raw_patch = fov[CHANNEL_IDX, y0:y1, x0:x1]

    # Resize to model input — this is what the model sees
    t = torch.from_numpy(raw_patch).unsqueeze(0).unsqueeze(0).float()
    if raw_crop_size != PATCH_SIZE:
        t = F.interpolate(
            t, size=(PATCH_SIZE, PATCH_SIZE), mode="bilinear", align_corners=False
        )
    patch = t[0, 0].numpy()

    vmin, vmax = np.percentile(patch, [1, 99])
    ax.imshow(patch, cmap="gray", vmin=vmin, vmax=vmax)

    # Annotation
    barcode = str(row["barcode_index"])
    barcodes = [bc.strip() for bc in barcode.split(";") if bc.strip()]

    lines = [
        f"uuid: {str(row['object_uuid'])[:8]}",
        f"fov: {zarr_path}",
        f"centroid: ({cy}, {cx})  radius: {row['object_radius_px']}px",
        f"cage: {row['global_cage_id_matched']}  class: {row['object_class']}",
    ]
    for bc in barcodes:
        bc_short = bc[:22] + ".." if len(bc) > 22 else bc
        if bc in obs_set:
            obs_row = adata.obs.loc[bc]
            lines.append(f"bc: {bc_short} (RNA={obs_row['nCount_RNA']:.0f})")
        else:
            lines.append(f"bc: {bc_short} NOT IN ADATA")
    if not barcodes:
        lines.append("no barcode match")

    ax.set_title("\n".join(lines), fontsize=5.5, linespacing=1.2, ha="left", x=0.02)
    ax.set_xticks([])
    ax.set_yticks([])

for i in range(len(sample_df), n_rows * N_COLS):
    axes[i // N_COLS, i % N_COLS].set_visible(False)

# Get channel name
first_fov = store[sample_df["zarr_path"].iloc[0]]
omero_channels = first_fov.attrs.get("omero", {}).get("channels", [])
ch_label = (
    omero_channels[CHANNEL_IDX].get("label", f"ch{CHANNEL_IDX}")
    if CHANNEL_IDX < len(omero_channels)
    else f"ch{CHANNEL_IDX}"
)
ch_short = CHANNEL_SHORT_NAMES.get(ch_label, ch_label)

fig.suptitle(
    f"Model input  |  {ch_short} ({ch_label})  |  "
    f"{PATCH_SIZE}x{PATCH_SIZE} px  |  "
    f"scan {SCAN_ID} lane {LANE_ID}  |  "
    f"{len(df)} cells after filtering",
    fontsize=9,
    fontweight="bold",
)
plt.tight_layout()

if OUTPUT_PATH:
    Path(OUTPUT_PATH).parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(OUTPUT_PATH, dpi=150, bbox_inches="tight")
    print(f"Saved to {OUTPUT_PATH}")
else:
    plt.show()

# %% [markdown]
# ## Threshold boundary inspection
#
# Shows cells sorted by radius around the MIN_RADIUS_PX cutoff.
# Left side: cells just below threshold (rejected). Right side: cells just above (kept).
# Helps judge whether the threshold is in the right place.

# %%
if SHOW_NEAR_THRESHOLD:
    # Derive zarr paths for unfiltered cells too
    df_all_cells["zarr_position"] = df_all_cells["cage_crop_file_name"].apply(
        _parse_position
    )
    df_all_cells["zarr_path"] = (
        df_all_cells["lane_id"].astype(str)
        + "/"
        + df_all_cells["scan_id"].astype(str)
        + "/"
        + df_all_cells["zarr_position"]
    )

    # Pick cells near threshold: N/2 just below, N/2 just above
    n_each = N_CELLS // 2
    below = df_all_cells[df_all_cells["object_radius_px"] < MIN_RADIUS_PX].nlargest(
        n_each, "object_radius_px"
    )
    above = df_all_cells[df_all_cells["object_radius_px"] >= MIN_RADIUS_PX].nsmallest(
        n_each, "object_radius_px"
    )
    boundary_df = pd.concat([below, above]).reset_index(drop=True)

    n_rows_b = int(np.ceil(len(boundary_df) / N_COLS))
    fig_b, axes_b = plt.subplots(
        n_rows_b, N_COLS, figsize=(N_COLS * 3.0, n_rows_b * 3.5), squeeze=False
    )

    for i, (_, row) in enumerate(boundary_df.iterrows()):
        ax = axes_b[i // N_COLS, i % N_COLS]
        zarr_path = row["zarr_path"]
        cy, cx = int(row["object_y_fov"]), int(row["object_x_fov"])
        radius = row["object_radius_px"]
        kept = radius >= MIN_RADIUS_PX

        fov = store[zarr_path]["0"][0, :, 0]
        _, fov_h, fov_w = fov.shape
        y0, y1 = cy - raw_half, cy + raw_half
        x0, x1 = cx - raw_half, cx + raw_half

        if y0 < 0 or x0 < 0 or y1 > fov_h or x1 > fov_w:
            ax.text(
                0.5, 0.5, "BORDER", transform=ax.transAxes, ha="center", va="center"
            )
        else:
            raw_patch = fov[CHANNEL_IDX, y0:y1, x0:x1]
            t = torch.from_numpy(raw_patch).unsqueeze(0).unsqueeze(0).float()
            if raw_crop_size != PATCH_SIZE:
                t = F.interpolate(
                    t,
                    size=(PATCH_SIZE, PATCH_SIZE),
                    mode="bilinear",
                    align_corners=False,
                )
            patch = t[0, 0].numpy()
            vmin, vmax = np.percentile(patch, [1, 99])
            ax.imshow(patch, cmap="gray", vmin=vmin, vmax=vmax)

        color = "green" if kept else "red"
        label = "KEPT" if kept else "REJECTED"
        ax.set_title(
            f"r={radius}px  {label}", fontsize=7, color=color, fontweight="bold"
        )
        ax.set_xticks([])
        ax.set_yticks([])

    for i in range(len(boundary_df), n_rows_b * N_COLS):
        axes_b[i // N_COLS, i % N_COLS].set_visible(False)

    fig_b.suptitle(
        f"Threshold boundary: min_radius_px = {MIN_RADIUS_PX}  |  "
        f"rejected: {(df_all_cells['object_radius_px'] < MIN_RADIUS_PX).sum()}  |  "
        f"kept: {(df_all_cells['object_radius_px'] >= MIN_RADIUS_PX).sum()}",
        fontsize=9,
        fontweight="bold",
    )
    plt.tight_layout()
    plt.show()

# %% [markdown]
# ## Barcode → cell mapping
#
# Multiple cells in the same cage share a barcode. This plot samples a few
# barcodes and shows all cells that map to each one.

# %%
N_BARCODES = 6
N_BARCODE_SEED = 123

df_bc = df[df["in_anndata"]].copy()
df_bc["barcode_list"] = df_bc["barcode_index"].str.split(";")
df_exploded = df_bc.explode("barcode_list")
df_exploded["barcode_list"] = df_exploded["barcode_list"].str.strip()
df_exploded = df_exploded[df_exploded["barcode_list"] != ""]

bc_counts = df_exploded.groupby("barcode_list").size()
multi_barcodes = bc_counts[bc_counts > 1].index.tolist()
print(f"Barcodes with >1 cell: {len(multi_barcodes)} out of {bc_counts.shape[0]}")

rng2 = np.random.default_rng(N_BARCODE_SEED)
chosen_barcodes = rng2.choice(
    multi_barcodes, size=min(N_BARCODES, len(multi_barcodes)), replace=False
)

for barcode in chosen_barcodes:
    rows = df_exploded[df_exploded["barcode_list"] == barcode]
    n_cells = len(rows)

    fig, axes = plt.subplots(1, n_cells, figsize=(n_cells * 2.5, 3.0), squeeze=False)
    fig.suptitle(
        f"barcode: {barcode}  ({n_cells} cells)", fontsize=8, fontweight="bold"
    )

    for j, (_, row) in enumerate(rows.iterrows()):
        ax = axes[0, j]
        zarr_path = row["zarr_path"]
        cy, cx = int(row["object_y_fov"]), int(row["object_x_fov"])

        fov = store[zarr_path]["0"][0, :, 0]
        _, fov_h, fov_w = fov.shape

        y0, y1 = cy - raw_half, cy + raw_half
        x0, x1 = cx - raw_half, cx + raw_half
        if y0 < 0 or x0 < 0 or y1 > fov_h or x1 > fov_w:
            ax.text(
                0.5, 0.5, "BORDER", transform=ax.transAxes, ha="center", va="center"
            )
        else:
            raw_patch = fov[CHANNEL_IDX, y0:y1, x0:x1]
            t = torch.from_numpy(raw_patch).unsqueeze(0).unsqueeze(0).float()
            if raw_crop_size != PATCH_SIZE:
                t = F.interpolate(
                    t,
                    size=(PATCH_SIZE, PATCH_SIZE),
                    mode="bilinear",
                    align_corners=False,
                )
            patch = t[0, 0].numpy()
            vmin, vmax = np.percentile(patch, [1, 99])
            ax.imshow(patch, cmap="gray", vmin=vmin, vmax=vmax)

        ax.set_title(
            f"uuid: {str(row['object_uuid'])[:8]}\n"
            f"r={row['object_radius_px']}px  cage={row['global_cage_id_matched']}",
            fontsize=6,
        )
        ax.set_xticks([])
        ax.set_yticks([])

    plt.tight_layout()
    plt.show()

# %%
