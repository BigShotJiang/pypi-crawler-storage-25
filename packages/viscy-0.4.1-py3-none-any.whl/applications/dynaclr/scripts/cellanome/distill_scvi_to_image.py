"""Feature-level distillation: image embedding → scVI embedding.

Asks: is the biological signal (e.g. cell-cycle phase) present-but-tangled in
DynaCLR, or genuinely missing? Train a small MLP head on frozen DynaCLR that
regresses to the paired scVI embedding, then probe phase on the distilled
output and compare to a probe on the raw DynaCLR.

Outcome interpretation
----------------------
- distilled phase acc >> raw → signal was there, MLP untangles it
- distilled ≈ raw → signal genuinely absent, distillation won't save you
- distilled overshoots scVI-direct probe → unlikely (teacher caps student)
"""

from __future__ import annotations

import argparse
from pathlib import Path

import anndata as ad
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.nn.functional as F
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from torch.utils.data import DataLoader, TensorDataset

H5AD = Path(
    "/hpc/projects/multimodal/datasets/cellanome/"
    "20260401095121_P-05_R000515_FC_2026_04_01_A549_SEC61B_DENV_ZIKV_mRNA+imaging/"
    "A549_single_cell_embedded.h5ad"
)
OUT = Path(
    "/hpc/mydata/eduardo.hirata/repos/viscy/applications/dynaclr/scripts/"
    "cellanome/output/distillation"
)
OUT.mkdir(parents=True, exist_ok=True)

IMAGE_KEY = "dynaclr"
SCVI_KEY = "X_scvi"
PHASE_KEY = "phase"

VAL_FRACTION = 0.2
SEED = 0
HIDDEN = (256, 128)
DROPOUT = 0.1
EPOCHS = 200
BATCH_SIZE = 512
LR = 1e-3
WEIGHT_DECAY = 1e-4
COS_LAMBDA = 0.5
EARLY_STOP_PATIENCE = 20


class DistillMLP(nn.Module):
    """MLP head that maps image embedding to scVI embedding."""

    def __init__(self, in_dim: int, hidden: tuple[int, ...], out_dim: int, dropout: float):
        super().__init__()
        layers: list[nn.Module] = []
        prev = in_dim
        for h in hidden:
            layers += [nn.Linear(prev, h), nn.GELU(), nn.Dropout(dropout)]
            prev = h
        layers.append(nn.Linear(prev, out_dim))
        self.net = nn.Sequential(*layers)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.net(x)


def distill_loss(pred: torch.Tensor, target: torch.Tensor, cos_lambda: float) -> torch.Tensor:
    """MSE plus a cosine-similarity term to preserve direction."""
    mse = F.mse_loss(pred, target)
    cos = 1.0 - F.cosine_similarity(pred, target, dim=-1).mean()
    return mse + cos_lambda * cos


def fit_distiller(
    x_train: np.ndarray,
    y_train: np.ndarray,
    x_val: np.ndarray,
    y_val: np.ndarray,
    device: str,
) -> tuple[DistillMLP, list[dict]]:
    """Train the distillation MLP with early stopping on val MSE."""
    in_dim = x_train.shape[1]
    out_dim = y_train.shape[1]
    model = DistillMLP(in_dim, HIDDEN, out_dim, DROPOUT).to(device)
    opt = torch.optim.AdamW(model.parameters(), lr=LR, weight_decay=WEIGHT_DECAY)

    train_ds = TensorDataset(torch.from_numpy(x_train).float(), torch.from_numpy(y_train).float())
    train_loader = DataLoader(train_ds, batch_size=BATCH_SIZE, shuffle=True, drop_last=False)
    x_val_t = torch.from_numpy(x_val).float().to(device)
    y_val_t = torch.from_numpy(y_val).float().to(device)

    best_val = float("inf")
    best_state = None
    bad = 0
    history: list[dict] = []
    for epoch in range(EPOCHS):
        model.train()
        running = 0.0
        for xb, yb in train_loader:
            xb, yb = xb.to(device), yb.to(device)
            opt.zero_grad()
            pred = model(xb)
            loss = distill_loss(pred, yb, COS_LAMBDA)
            loss.backward()
            opt.step()
            running += loss.item() * xb.size(0)
        train_loss = running / len(train_ds)

        model.eval()
        with torch.no_grad():
            val_pred = model(x_val_t)
            val_loss = distill_loss(val_pred, y_val_t, COS_LAMBDA).item()
            val_cos = F.cosine_similarity(val_pred, y_val_t, dim=-1).mean().item()
        history.append(
            {"epoch": epoch, "train_loss": train_loss, "val_loss": val_loss, "val_cos": val_cos}
        )

        if val_loss < best_val - 1e-5:
            best_val = val_loss
            best_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}
            bad = 0
        else:
            bad += 1
            if bad >= EARLY_STOP_PATIENCE:
                break

    if best_state is not None:
        model.load_state_dict(best_state)
    return model, history


def linear_probe(x_train: np.ndarray, y_train, x_val: np.ndarray, y_val) -> float:
    """Phase accuracy from a logistic-regression probe."""
    clf = LogisticRegression(max_iter=2000)
    clf.fit(x_train, y_train)
    return float((clf.predict(x_val) == y_val).mean())


def plot_history(history: list[dict], out_path: Path) -> None:
    df = pd.DataFrame(history)
    fig, ax = plt.subplots(1, 2, figsize=(9, 3.5))
    ax[0].plot(df["epoch"], df["train_loss"], label="train")
    ax[0].plot(df["epoch"], df["val_loss"], label="val")
    ax[0].set_xlabel("epoch")
    ax[0].set_ylabel("MSE + λ·(1 − cos)")
    ax[0].set_title("distillation loss")
    ax[0].legend()
    ax[1].plot(df["epoch"], df["val_cos"])
    ax[1].set_xlabel("epoch")
    ax[1].set_ylabel("val cosine similarity")
    ax[1].set_title("val cosine to scVI target")
    fig.tight_layout()
    fig.savefig(out_path, dpi=200)
    plt.close(fig)


def plot_accuracy_bars(scores: dict[str, float], out_path: Path) -> None:
    labels = list(scores)
    vals = [scores[k] for k in labels]
    colors = ["#999999", "#4C72B0", "#55A868", "#C44E52"][: len(labels)]
    fig, ax = plt.subplots(figsize=(6, 4))
    ax.bar(labels, vals, color=colors)
    for i, v in enumerate(vals):
        ax.text(i, v + 0.005, f"{v:.3f}", ha="center", fontsize=9)
    ax.set_ylabel("val phase accuracy (held-out cells)")
    ax.set_ylim(0, 1.0)
    ax.set_title("Linear probe on phase: raw vs distilled image embedding")
    fig.tight_layout()
    fig.savefig(out_path, dpi=200)
    plt.close(fig)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--target",
        default="X_scvi",
        help="obsm key to distill onto (e.g., X_scvi, X_pls, Concord)",
    )
    parser.add_argument(
        "--tag",
        default=None,
        help="subdirectory tag for outputs; defaults to target",
    )
    args = parser.parse_args()
    target_key = args.target
    tag = args.tag or target_key.replace("X_", "")

    out_dir = OUT / tag
    out_dir.mkdir(parents=True, exist_ok=True)

    device = "cuda" if torch.cuda.is_available() else "cpu"
    print(f"## Device: {device}")
    print(f"## Distillation target: {target_key} → outputs in {out_dir}")

    print("\n## Loading paired anndata")
    adata = ad.read_h5ad(H5AD)
    image = adata.obsm[IMAGE_KEY].astype(np.float32)
    target = adata.obsm[target_key].astype(np.float32)
    phase = adata.obs[PHASE_KEY].astype(str).to_numpy()
    print(f"- cells: {adata.n_obs}, image: {image.shape}, target: {target.shape}")

    print("\n## Stratified 80/20 split on phase")
    idx_train, idx_val = train_test_split(
        np.arange(adata.n_obs), test_size=VAL_FRACTION, stratify=phase, random_state=SEED
    )
    x_tr_raw, x_va_raw = image[idx_train], image[idx_val]
    y_tr, y_va = target[idx_train], target[idx_val]
    p_tr, p_va = phase[idx_train], phase[idx_val]
    print(f"- train: {len(idx_train)} | val: {len(idx_val)}")

    print(f"\n## Standardizing image (fit on train), targeting raw {target_key}")
    sc_x = StandardScaler().fit(x_tr_raw)
    x_tr = sc_x.transform(x_tr_raw).astype(np.float32)
    x_va = sc_x.transform(x_va_raw).astype(np.float32)

    print(f"\n## Training distillation MLP image → {target_key}")
    model, history = fit_distiller(x_tr, y_tr, x_va, y_va, device=device)
    print(f"- final val cos: {history[-1]['val_cos']:.4f}")
    print(f"- best val loss: {min(h['val_loss'] for h in history):.4f}")
    plot_history(history, out_dir / "distill_history.png")
    pd.DataFrame(history).to_csv(out_dir / "distill_history.csv", index=False)

    print("\n## Inference: distilled image embedding on val")
    model.eval()
    with torch.no_grad():
        x_tr_dist = model(torch.from_numpy(x_tr).float().to(device)).cpu().numpy()
        x_va_dist = model(torch.from_numpy(x_va).float().to(device)).cpu().numpy()

    print("\n## Linear probe on phase (val accuracy)")
    scores = {
        "raw DynaCLR (768)": linear_probe(x_tr, p_tr, x_va, p_va),
        f"distilled image→{tag} ({y_tr.shape[1]})": linear_probe(
            x_tr_dist, p_tr, x_va_dist, p_va
        ),
        f"{target_key} direct ({y_tr.shape[1]}, teacher)": linear_probe(
            y_tr, p_tr, y_va, p_va
        ),
    }
    for k, v in scores.items():
        print(f"- {k:45s} {v:.4f}")
    plot_accuracy_bars(scores, out_dir / "distill_phase_accuracy.png")
    pd.DataFrame([{"space": k, "val_acc": v} for k, v in scores.items()]).to_csv(
        out_dir / "distill_phase_accuracy.csv", index=False
    )

    np.save(out_dir / "distilled_val_embeddings.npy", x_va_dist)
    np.save(out_dir / "distilled_val_indices.npy", idx_val)

    torch.save(
        {
            "state_dict": model.state_dict(),
            "in_dim": x_tr.shape[1],
            "hidden": HIDDEN,
            "out_dim": y_tr.shape[1],
            "dropout": DROPOUT,
            "target_key": target_key,
            "x_scaler_mean": sc_x.mean_,
            "x_scaler_scale": sc_x.scale_,
        },
        out_dir / "distill_mlp.pt",
    )

    print(f"\n## Done — outputs in {out_dir}")


if __name__ == "__main__":
    main()
