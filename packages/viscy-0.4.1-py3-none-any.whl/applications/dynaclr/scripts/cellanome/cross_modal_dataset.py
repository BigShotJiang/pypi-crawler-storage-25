"""Custom paired-cellanome dataset for cross-modal contrastive training.

Reads cellanome image crops directly from the OME-Zarr store (no cell_index
parquet yet — cellanome isn't standardized) and joins paired transcriptomic
embeddings (e.g. ``X_pls``, ``X_scvi``) from the per-cell h5ad. Returns
``TripletSample``-shaped batches consumed by ``ContrastiveModule``.

Pairing is partial: cells without a transcriptome get a NaN target, which the
:class:`CrossModalContrastiveHead` masks out at loss time. This keeps unpaired
cells contributing to the self-supervised contrastive loss.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import anndata as ad
import numpy as np
import pandas as pd
import torch
import torch.nn.functional as F
import zarr
from torch.utils.data import Dataset

CHANNEL_SHORT_NAMES = {
    "White": "BF",
    "Blue-FITC (520)": "FITC",
    "Red-CY5 (700)": "CY5",
    "Green-CY3 (605)": "CY3",
}


@dataclass
class CellanomePairedConfig:
    """Configuration for :class:`CellanomePairedDataset`.

    The cell index is sourced from a precomputed image-embedding AnnData zarr
    (e.g. ``2-embeddings/dynaclr-2d-boc-BF.zarr``) which already contains
    per-cell ``zarr_path``, ``object_x_fov``, ``object_y_fov``,
    ``object_uuid``, and ``barcode_index`` (foreign key into the transcriptome
    h5ad's ``obs_names``).
    """

    zarr_store: str
    cell_index_zarr: str
    transcriptome_h5ad: str
    target_keys: tuple[str, ...] = ("X_pls",)
    phase_key: str | None = "phase"
    channel_name: str = "White"
    patch_size: int = 160
    reference_pixel_size: float = 0.149
    source_pixel_size: float = 0.247
    pairs_only: bool = False


def _resolve_channel_index(store: zarr.Group, zarr_path: str, channel_name: str) -> int:
    fov_group = store[zarr_path]
    attrs = dict(fov_group.attrs)
    omero = attrs.get("ome", attrs).get("omero") if "ome" in attrs else attrs.get("omero")
    if omero is None:
        raise KeyError(f"No omero metadata at {zarr_path}; attrs keys={list(attrs)}")
    channels = omero["channels"]
    labels = [ch.get("label", ch.get("name", "")) for ch in channels]
    if channel_name not in labels:
        raise ValueError(f"Channel '{channel_name}' not in {labels}")
    return labels.index(channel_name)


def build_paired_index(
    cfg: CellanomePairedConfig,
) -> tuple[pd.DataFrame, dict[str, np.ndarray], np.ndarray]:
    """Read the cell-index zarr and join paired transcriptomic embeddings.

    Returns
    -------
    df : pd.DataFrame
        Cell rows with ``zarr_path``, ``object_x_fov``, ``object_y_fov``,
        ``barcode_index``, ``in_anndata`` from the cell-index AnnData zarr.
    targets : dict[str, np.ndarray]
        Mapping from target key (e.g. ``"X_pls"``) to a ``(N_cells, D)`` matrix
        aligned to ``df``. Unpaired rows are NaN.
    phase_labels : np.ndarray
        Per-cell phase string label (``""`` if unpaired or ``phase_key`` is
        None).
    """
    cell_index = ad.read_zarr(cfg.cell_index_zarr)
    df = cell_index.obs.copy().reset_index(drop=True)
    if cfg.pairs_only:
        df = df[df["in_anndata"].astype(bool)].reset_index(drop=True)

    transcriptome = ad.read_h5ad(cfg.transcriptome_h5ad, backed="r")
    tx_obs = transcriptome.obs
    barcode_keys = (
        tx_obs["barcode.sequence"].astype(str) + "-" + tx_obs["lane"].astype(str)
    ).to_numpy()
    barcode_to_idx = {bc: i for i, bc in enumerate(barcode_keys)}
    embeddings = {
        k: np.asarray(transcriptome.obsm[k], dtype=np.float32) for k in cfg.target_keys
    }
    phase_arr = (
        transcriptome.obs[cfg.phase_key].astype(str).to_numpy()
        if cfg.phase_key and cfg.phase_key in transcriptome.obs.columns
        else None
    )

    targets: dict[str, np.ndarray] = {}
    for key, mat in embeddings.items():
        out = np.full((len(df), mat.shape[1]), np.nan, dtype=np.float32)
        for i, bc in enumerate(df["barcode_index"].to_numpy()):
            j = barcode_to_idx.get(str(bc))
            if j is not None:
                out[i] = mat[j]
        targets[key] = out

    phase_labels = np.full(len(df), "", dtype=object)
    if phase_arr is not None:
        for i, bc in enumerate(df["barcode_index"].to_numpy()):
            j = barcode_to_idx.get(str(bc))
            if j is not None:
                phase_labels[i] = phase_arr[j]

    return df, targets, phase_labels


class CellanomePairedDataset(Dataset):
    """Yields TripletSample-shaped dicts for cross-modal contrastive training.

    Two augmentations of the same crop form (anchor, positive). Targets are
    attached to ``anchor_meta[0]["labels"][target_key]`` per sample (NaN when
    unpaired). The current batch is single-channel BF; augmentations are
    light: random horizontal/vertical flip + small brightness/contrast jitter.
    """

    def __init__(
        self,
        cfg: CellanomePairedConfig,
        indices: np.ndarray | None = None,
        augment: bool = True,
    ):
        super().__init__()
        self.cfg = cfg
        self.augment = augment
        df, targets, phase_labels = build_paired_index(cfg)
        if indices is not None:
            df = df.iloc[indices].reset_index(drop=True)
            targets = {k: v[indices] for k, v in targets.items()}
            phase_labels = phase_labels[indices]
        self.df = df
        self.targets = targets
        self.phase_labels = phase_labels
        self.store = zarr.open(cfg.zarr_store, mode="r")
        self.channel_idx = _resolve_channel_index(
            self.store, self.df["zarr_path"].iloc[0], cfg.channel_name
        )
        self.raw_half = round(cfg.patch_size * cfg.reference_pixel_size / cfg.source_pixel_size) // 2
        self.raw_crop = 2 * self.raw_half

    def __len__(self) -> int:
        return len(self.df)

    def _crop(self, row: pd.Series) -> np.ndarray | None:
        zp = row["zarr_path"]
        cached = getattr(self, "_fov_cache", None)
        if cached is None or cached[0] != zp:
            arr = np.asarray(self.store[zp]["0"][0, self.channel_idx, 0])
            self._fov_cache = (zp, arr)
        fov = self._fov_cache[1]
        cy, cx = int(row["object_y_fov"]), int(row["object_x_fov"])
        h, w = fov.shape
        y0, y1 = cy - self.raw_half, cy + self.raw_half
        x0, x1 = cx - self.raw_half, cx + self.raw_half
        if y0 < 0 or x0 < 0 or y1 > h or x1 > w:
            return None
        return np.asarray(fov[y0:y1, x0:x1], dtype=np.float32)

    @staticmethod
    def _augment(patch: torch.Tensor) -> torch.Tensor:
        if torch.rand(1).item() < 0.5:
            patch = torch.flip(patch, dims=[-1])
        if torch.rand(1).item() < 0.5:
            patch = torch.flip(patch, dims=[-2])
        gain = 1.0 + 0.1 * (torch.rand(1).item() - 0.5)
        bias = 0.05 * (torch.rand(1).item() - 0.5)
        return patch * gain + bias

    @staticmethod
    def _normalize(patch: torch.Tensor) -> torch.Tensor:
        m = patch.mean()
        s = patch.std().clamp(min=1e-8)
        return (patch - m) / s

    def __getitem__(self, idx: int) -> dict:
        row = self.df.iloc[idx]
        patch = self._crop(row)
        if patch is None:
            # Border-skip: try a neighbour
            return self.__getitem__((idx + 1) % len(self))
        t = torch.from_numpy(patch)[None, None]  # (1, 1, H, W)
        if self.raw_crop != self.cfg.patch_size:
            t = F.interpolate(
                t, size=(self.cfg.patch_size, self.cfg.patch_size), mode="bilinear", align_corners=False
            )
        if self.augment:
            anchor = self._normalize(self._augment(t.squeeze(0)))
            positive = self._normalize(self._augment(t.squeeze(0)))
        else:
            base = self._normalize(t.squeeze(0))
            anchor = base
            positive = base
        anchor = anchor.unsqueeze(1)
        positive = positive.unsqueeze(1)

        labels: dict[str, np.ndarray] = {}
        for key in self.cfg.target_keys:
            labels[key] = self.targets[key][idx]
        meta = {
            "labels": labels,
            "object_uuid": row.get("object_uuid", ""),
            "in_anndata": bool(row["in_anndata"]),
            "phase": str(self.phase_labels[idx]),
        }
        return {
            "anchor": anchor,
            "positive": positive,
            "anchor_meta": meta,
            "index": idx,
        }


def collate_paired(samples: list[dict]) -> dict:
    """Custom collate preserving anchor_meta as a list of dicts."""
    return {
        "anchor": torch.stack([s["anchor"] for s in samples]),
        "positive": torch.stack([s["positive"] for s in samples]),
        "anchor_meta": [s["anchor_meta"] for s in samples],
        "index": [s["index"] for s in samples],
    }
