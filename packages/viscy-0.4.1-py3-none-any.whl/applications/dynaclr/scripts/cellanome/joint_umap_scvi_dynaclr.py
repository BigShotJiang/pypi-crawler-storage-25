"""Joint UMAP of scVI + DynaCLR embeddings on paired A549 multimodal data.

Step 1 sanity check: do paired transcriptomic (scVI) and imaging (DynaCLR)
embeddings form coherent joint structure, colored by cell-cycle phase?

Strategy
--------
1. Load paired anndata (already aligned: h5ad has both modalities per cell).
2. Per-block standardize (z-score), then PCA the image block to match scVI
   dimensionality so neither modality dominates by scale or dim.
3. Concatenate, run UMAP, save plots colored by phase / modality / condition.
4. Also compute and save baseline UMAPs for each modality alone for comparison.
"""

from __future__ import annotations

from pathlib import Path

import anndata as ad
import matplotlib.pyplot as plt
import numpy as np
import seaborn as sns
import umap
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler

H5AD = Path(
    "/hpc/projects/multimodal/datasets/cellanome/"
    "20260401095121_P-05_R000515_FC_2026_04_01_A549_SEC61B_DENV_ZIKV_mRNA+imaging/"
    "A549_single_cell_embedded.h5ad"
)
OUT = Path(
    "/hpc/mydata/eduardo.hirata/repos/viscy/applications/dynaclr/scripts/"
    "cellanome/output/joint_umap"
)
OUT.mkdir(parents=True, exist_ok=True)

SCVI_KEY = "X_scvi"
IMAGE_KEY = "dynaclr"
PHASE_KEY = "phase"
COND_KEY = "condition"

N_IMAGE_PCS = 30
UMAP_KW = dict(n_neighbors=30, min_dist=0.3, metric="cosine", random_state=0)
PHASE_PALETTE = {"G1": "#4C72B0", "S": "#55A868", "G2M": "#C44E52"}


def standardize(x: np.ndarray) -> np.ndarray:
    """Z-score columns of a matrix."""
    return StandardScaler().fit_transform(x)


def reduce_image(x: np.ndarray, n_components: int) -> np.ndarray:
    """PCA the high-dim image embedding to match scVI dimensionality."""
    pca = PCA(n_components=n_components, random_state=0)
    return pca.fit_transform(x), pca.explained_variance_ratio_.sum()


def umap_embed(x: np.ndarray) -> np.ndarray:
    """Compute a 2-D UMAP."""
    reducer = umap.UMAP(**UMAP_KW)
    return reducer.fit_transform(x)


def plot_umap(
    emb: np.ndarray,
    labels: np.ndarray,
    title: str,
    out_path: Path,
    palette: dict | None = None,
) -> None:
    """Scatter UMAP colored by a categorical label."""
    fig, ax = plt.subplots(figsize=(6, 6))
    sns.scatterplot(
        x=emb[:, 0],
        y=emb[:, 1],
        hue=labels,
        palette=palette,
        s=4,
        linewidth=0,
        alpha=0.7,
        ax=ax,
    )
    ax.set_title(title)
    ax.set_xlabel("UMAP 1")
    ax.set_ylabel("UMAP 2")
    ax.legend(markerscale=3, frameon=False, loc="best", fontsize=8)
    fig.tight_layout()
    fig.savefig(out_path, dpi=200)
    plt.close(fig)


def main() -> None:
    print("## Loading paired anndata")
    adata = ad.read_h5ad(H5AD)
    print(f"- cells: {adata.n_obs}")
    print(f"- phase counts: {adata.obs[PHASE_KEY].value_counts().to_dict()}")

    scvi = adata.obsm[SCVI_KEY].astype(np.float32)
    image = adata.obsm[IMAGE_KEY].astype(np.float32)
    phase = adata.obs[PHASE_KEY].astype(str).to_numpy()
    cond = adata.obs[COND_KEY].astype(str).to_numpy()

    print(f"- scVI: {scvi.shape}, image: {image.shape}")

    print("\n## Standardizing each block independently")
    scvi_z = standardize(scvi)
    image_pca, var_kept = reduce_image(image, N_IMAGE_PCS)
    image_z = standardize(image_pca)
    print(f"- image PCA→{N_IMAGE_PCS} dims, variance kept: {var_kept:.3f}")

    print("\n## Joint embedding (concat → UMAP)")
    joint = np.concatenate([scvi_z, image_z], axis=1)
    print(f"- joint shape: {joint.shape}")
    joint_umap = umap_embed(joint)
    np.save(OUT / "joint_umap.npy", joint_umap)
    plot_umap(
        joint_umap,
        phase,
        "Joint scVI + DynaCLR (concat) — colored by phase",
        OUT / "joint_umap_phase.png",
        palette=PHASE_PALETTE,
    )
    plot_umap(
        joint_umap,
        cond,
        "Joint scVI + DynaCLR (concat) — colored by condition",
        OUT / "joint_umap_condition.png",
    )

    print("\n## Per-modality baselines")
    scvi_umap = umap_embed(scvi_z)
    plot_umap(
        scvi_umap,
        phase,
        "scVI only — phase",
        OUT / "scvi_only_umap_phase.png",
        palette=PHASE_PALETTE,
    )

    image_umap = umap_embed(image_z)
    plot_umap(
        image_umap,
        phase,
        "DynaCLR only — phase",
        OUT / "dynaclr_only_umap_phase.png",
        palette=PHASE_PALETTE,
    )

    print("\n## Done")
    print(f"- outputs in {OUT}")


if __name__ == "__main__":
    main()
