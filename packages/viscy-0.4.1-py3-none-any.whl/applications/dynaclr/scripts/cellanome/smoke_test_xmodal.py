"""Smoke test for cross-modal dataset + head + engine integration.

Verifies the data pipeline (custom paired cellanome dataset) feeds tensors of
the expected shape to the existing :class:`ContrastiveModule` running with the
new :class:`CrossModalContrastiveHead`. Runs one forward + backward pass on a
tiny batch on CPU/GPU. No checkpoint loading.
"""

from __future__ import annotations

import torch
from torch.utils.data import DataLoader

from dynaclr.engine import ContrastiveModule
from viscy_models.contrastive import ContrastiveEncoder
from viscy_models.contrastive.loss import NTXentLoss
from viscy_models.components.heads import CrossModalContrastiveHead

from cross_modal_dataset import CellanomePairedConfig, CellanomePairedDataset, collate_paired

DATASET_DIR = (
    "/hpc/projects/multimodal/datasets/cellanome/"
    "20260401095121_P-05_R000515_FC_2026_04_01_A549_SEC61B_DENV_ZIKV_mRNA+imaging"
)
CFG = CellanomePairedConfig(
    zarr_store=(
        f"{DATASET_DIR}/0-convert/ome-zarr/"
        "20260401095121_P-05_R000515_FC_2026_04_01_A549_SEC61B_DENV_ZIKV_mRNA+imaging.zarr"
    ),
    cell_index_zarr=f"{DATASET_DIR}/2-embeddings/dynaclr-2d-boc-BF.zarr",
    transcriptome_h5ad=f"{DATASET_DIR}/A549_single_cell_embedded.h5ad",
    target_keys=("X_pls",),
    pairs_only=True,
)


def main() -> None:
    print("## Building dataset")
    ds = CellanomePairedDataset(CFG)
    print(f"- cells: {len(ds)}")
    sample = ds[0]
    print(f"- anchor shape: {sample['anchor'].shape}")
    print(f"- X_pls target shape: {sample['anchor_meta']['labels']['X_pls'].shape}")
    print(f"- in_anndata: {sample['anchor_meta']['in_anndata']}")

    loader = DataLoader(ds, batch_size=4, shuffle=True, collate_fn=collate_paired, num_workers=0)
    batch = next(iter(loader))
    print(f"\n## Batch")
    print(f"- anchor: {batch['anchor'].shape}")
    print(f"- positive: {batch['positive'].shape}")
    print(f"- anchor_meta is list: {isinstance(batch['anchor_meta'], list)}, len={len(batch['anchor_meta'])}")

    print("\n## Building model with cross-modal head")
    encoder = ContrastiveEncoder(
        backbone="convnext_tiny",
        in_channels=1,
        in_stack_depth=1,
        stem_kernel_size=(1, 4, 4),
        stem_stride=(1, 4, 4),
        embedding_dim=768,
        projection_dim=32,
    )
    aux_heads = {
        "pls_xmodal": CrossModalContrastiveHead(
            head_name="pls_xmodal",
            batch_key="X_pls",
            in_dims=768,
            target_dims=50,
            proj_dims=128,
            temperature=0.1,
        )
    }
    module = ContrastiveModule(
        encoder=encoder,
        loss_function=NTXentLoss(temperature=0.5),
        auxiliary_heads=aux_heads,
        example_input_array_shape=(1, 1, 1, 160, 160),
    )

    print("\n## One training step on CPU")
    module.train()
    loss = module.training_step(batch, 0)
    print(f"- combined loss: {loss.item():.4f}")
    loss.backward()
    print("- backward OK")

    aux_head = module.auxiliary_heads["pls_xmodal"]
    target = torch.from_numpy(
        torch.utils.data._utils.collate.default_collate(
            [m["labels"]["X_pls"] for m in batch["anchor_meta"]]
        ).numpy()
    )
    print(f"- aux target tensor shape: {target.shape}")
    print(f"- aux head proj OK: image proj→{aux_head.image_proj(torch.zeros(2, 768)).shape}, "
          f"target proj→{aux_head.target_proj(torch.zeros(2, 50)).shape}")
    print("\n## Smoke test passed")


if __name__ == "__main__":
    main()
