"""Phase linear probe baseline on frozen precomputed DynaCLR features.

Reads the per-cell DynaCLR-BF embedding zarr and the transcriptome h5ad,
joins on (barcode.sequence + lane), runs a stratified 80/20 split on phase,
fits a logistic-regression probe on the 768-d backbone features, and reports
val accuracy. This is the fair baseline the cross-modal training should beat.
"""

from __future__ import annotations

from pathlib import Path

import anndata as ad
import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

DATASET_DIR = (
    "/hpc/projects/multimodal/datasets/cellanome/"
    "20260401095121_P-05_R000515_FC_2026_04_01_A549_SEC61B_DENV_ZIKV_mRNA+imaging"
)
OUT = Path(
    "/hpc/mydata/eduardo.hirata/repos/viscy/applications/dynaclr/scripts/"
    "cellanome/output/DynaCLR-2D-Cellanome-A549"
)
OUT.mkdir(parents=True, exist_ok=True)


def main() -> None:
    print("## Loading precomputed DynaCLR-BF embedding zarr")
    cell_index = ad.read_zarr(f"{DATASET_DIR}/2-embeddings/dynaclr-2d-boc-BF.zarr")
    print(f"- cells: {cell_index.n_obs}")
    paired = cell_index.obs["in_anndata"].astype(bool).to_numpy()
    print(f"- paired: {int(paired.sum())}")

    print("\n## Loading transcriptome h5ad")
    tx = ad.read_h5ad(f"{DATASET_DIR}/A549_single_cell_embedded.h5ad", backed="r")
    barcode_keys = (
        tx.obs["barcode.sequence"].astype(str) + "-" + tx.obs["lane"].astype(str)
    ).to_numpy()
    barcode_to_idx = {bc: i for i, bc in enumerate(barcode_keys)}
    phase = tx.obs["phase"].astype(str).to_numpy()

    print("\n## Joining phase to image cells")
    img_barcodes = cell_index.obs["barcode_index"].astype(str).to_numpy()
    phase_per_cell = np.full(cell_index.n_obs, "", dtype=object)
    for i, bc in enumerate(img_barcodes):
        j = barcode_to_idx.get(bc)
        if j is not None:
            phase_per_cell[i] = phase[j]
    paired_mask = phase_per_cell != ""
    print(f"- joined paired (phase known): {int(paired_mask.sum())}")

    features = np.asarray(cell_index.X[paired_mask], dtype=np.float32)
    labels = phase_per_cell[paired_mask]
    print(f"- features: {features.shape}")

    print("\n## Stratified 80/20 split")
    idx = np.arange(len(labels))
    train_idx, val_idx = train_test_split(idx, test_size=0.2, stratify=labels, random_state=42)
    print(f"- train: {len(train_idx)} | val: {len(val_idx)}")

    print("\n## Fitting LogisticRegression probe (z-scored)")
    sc = StandardScaler().fit(features[train_idx])
    x_tr = sc.transform(features[train_idx])
    x_va = sc.transform(features[val_idx])
    y_tr, y_va = labels[train_idx], labels[val_idx]

    clf = LogisticRegression(max_iter=2000, C=1.0)
    clf.fit(x_tr, y_tr)
    train_acc = float((clf.predict(x_tr) == y_tr).mean())
    val_acc = float((clf.predict(x_va) == y_va).mean())
    print(f"\n## Frozen DynaCLR-BF (768-d) phase probe")
    print(f"- train acc: {train_acc:.4f}")
    print(f"- val   acc: {val_acc:.4f}")

    pd.DataFrame(
        [{"space": "frozen DynaCLR-BF (768)", "train_acc": train_acc, "val_acc": val_acc, "n_train": len(train_idx), "n_val": len(val_idx)}]
    ).to_csv(OUT / "frozen_dynaclr_phase_probe_baseline.csv", index=False)
    print(f"\nSaved: {OUT / 'frozen_dynaclr_phase_probe_baseline.csv'}")


if __name__ == "__main__":
    main()
