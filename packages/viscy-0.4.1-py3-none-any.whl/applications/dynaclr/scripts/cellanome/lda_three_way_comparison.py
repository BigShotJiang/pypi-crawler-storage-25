"""LDA projection comparison: frozen-baseline vs frozen-xmodal vs unfrozen-xmodal.

Plots three side-by-side LDA scatter plots colored by cell-cycle phase.
LDA is a supervised dimensionality reduction that projects onto the most
phase-discriminative axes — so this *isolates* whatever phase signal is in
the embedding, even when phase doesn't dominate the variance (which is the
case for our 768-d image features per the prior UMAP).

For each embedding:
  1. Fit LDA on a held-out subset (50/50 of val, stratified by phase).
  2. Project both halves into the 2-d LDA space.
  3. Plot the held-out half (so we see *generalization*, not training fit).

Higher class separation in this view = more phase information in the
embedding.
"""

from __future__ import annotations

from pathlib import Path

import anndata as ad
import matplotlib.pyplot as plt
import numpy as np
import seaborn as sns
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

DATASET_DIR = Path(
    "/hpc/projects/multimodal/datasets/cellanome/"
    "20260401095121_P-05_R000515_FC_2026_04_01_A549_SEC61B_DENV_ZIKV_mRNA+imaging"
)
RUN_ROOT = Path(
    "/hpc/mydata/eduardo.hirata/repos/viscy/applications/dynaclr/scripts/"
    "cellanome/output/DynaCLR-2D-Cellanome-A549"
)
FROZEN_RUN = RUN_ROOT / "DynaCLR-2D-Cellanome-A549-frozen-X_pls-v1"
UNFROZEN_RUN = RUN_ROOT / "DynaCLR-2D-Cellanome-A549-unfrozen-X_pls-v1"
OUT_DIR = RUN_ROOT / "umap_comparison"
OUT_DIR.mkdir(parents=True, exist_ok=True)

PHASE_PALETTE = {"G1": "#1F77B4", "S": "#2CA02C", "G2M": "#FF7F0E"}
SEED = 0


def load_baseline_features(val_phase: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    cell_index = ad.read_zarr(DATASET_DIR / "2-embeddings/dynaclr_2d_boc_BF.zarr")
    tx = ad.read_h5ad(DATASET_DIR / "2-embeddings/A549_single_cell_embedded.h5ad", backed="r")
    barcode_keys = (
        tx.obs["barcode.sequence"].astype(str) + "-" + tx.obs["lane"].astype(str)
    ).to_numpy()
    barcode_to_idx = {bc: i for i, bc in enumerate(barcode_keys)}
    phase_per_cell = np.full(cell_index.n_obs, "", dtype=object)
    img_b = cell_index.obs["barcode_index"].astype(str).to_numpy()
    tx_phase = tx.obs["phase"].astype(str).to_numpy()
    for i, bc in enumerate(img_b):
        j = barcode_to_idx.get(bc)
        if j is not None:
            phase_per_cell[i] = tx_phase[j]
    paired_mask = phase_per_cell != ""
    features = np.asarray(cell_index.X[paired_mask], dtype=np.float32)
    labels = phase_per_cell[paired_mask]

    rng = np.random.default_rng(SEED)
    n_per_class = {p: int((val_phase == p).sum()) for p in PHASE_PALETTE}
    chosen: list[int] = []
    chosen_labels: list[str] = []
    for p, k in n_per_class.items():
        idx = np.where(labels == p)[0]
        k = min(k, len(idx))
        pick = rng.choice(idx, size=k, replace=False)
        chosen.extend(pick.tolist())
        chosen_labels.extend([p] * k)
    chosen_arr = np.asarray(chosen)
    return features[chosen_arr], np.asarray(chosen_labels)


def lda_holdout(features: np.ndarray, labels: np.ndarray) -> tuple[np.ndarray, np.ndarray, float]:
    """Fit LDA on half, project the other half. Returns (proj, val_labels, val_acc)."""
    idx = np.arange(len(labels))
    tr, va = train_test_split(idx, test_size=0.5, stratify=labels, random_state=SEED)
    sc = StandardScaler().fit(features[tr])
    x_tr = sc.transform(features[tr])
    x_va = sc.transform(features[va])
    lda = LinearDiscriminantAnalysis(n_components=2)
    lda.fit(x_tr, labels[tr])
    proj_va = lda.transform(x_va)
    val_acc = float(lda.score(x_va, labels[va]))
    return proj_va, labels[va], val_acc


def panel(ax, proj: np.ndarray, labels: np.ndarray, title: str, val_acc: float) -> None:
    sns.scatterplot(
        x=proj[:, 0],
        y=proj[:, 1],
        hue=labels,
        hue_order=["G1", "S", "G2M"],
        palette=PHASE_PALETTE,
        s=4,
        linewidth=0,
        alpha=0.7,
        ax=ax,
    )
    ax.set_title(f"{title}\n(LDA val acc = {val_acc:.3f})", fontsize=10.5)
    ax.set_xlabel("LDA 1")
    ax.set_ylabel("LDA 2")
    ax.set_xticks([])
    ax.set_yticks([])
    ax.legend(loc="best", fontsize=8, markerscale=2, frameon=False)


def main() -> None:
    print("## Loading run features")
    frozen_feats = np.load(FROZEN_RUN / "val_features.npy")
    frozen_phase = np.load(FROZEN_RUN / "val_phase.npy", allow_pickle=True).astype(str)
    unfrozen_feats = np.load(UNFROZEN_RUN / "val_features.npy")
    unfrozen_phase = np.load(UNFROZEN_RUN / "val_phase.npy", allow_pickle=True).astype(str)

    print("## Sampling matched baseline subset")
    baseline_feats, baseline_phase = load_baseline_features(frozen_phase)

    print("## Fitting LDA (50/50 holdout)")
    proj_base, lbl_base, acc_base = lda_holdout(baseline_feats, baseline_phase)
    proj_frozen, lbl_frozen, acc_frozen = lda_holdout(frozen_feats, frozen_phase)
    proj_unfrozen, lbl_unfrozen, acc_unfrozen = lda_holdout(unfrozen_feats, unfrozen_phase)
    print(f"- baseline LDA val acc:        {acc_base:.4f}")
    print(f"- frozen-xmodal LDA val acc:   {acc_frozen:.4f}")
    print(f"- unfrozen-xmodal LDA val acc: {acc_unfrozen:.4f}")

    print("## Plotting")
    fig, axes = plt.subplots(1, 3, figsize=(15, 5))
    panel(axes[0], proj_base, lbl_base, "Frozen baseline\n(no fine-tuning)", acc_base)
    panel(axes[1], proj_frozen, lbl_frozen, "Cross-modal head\n(frozen encoder)", acc_frozen)
    panel(axes[2], proj_unfrozen, lbl_unfrozen, "Cross-modal head\n(unfrozen encoder)", acc_unfrozen)
    fig.suptitle("LDA projection of 768-d image features, colored by phase", fontsize=13)
    fig.tight_layout()
    out_path = OUT_DIR / "lda_three_way_phase.png"
    fig.savefig(out_path, dpi=200, bbox_inches="tight")
    plt.close(fig)
    print(f"- saved {out_path}")


if __name__ == "__main__":
    main()
