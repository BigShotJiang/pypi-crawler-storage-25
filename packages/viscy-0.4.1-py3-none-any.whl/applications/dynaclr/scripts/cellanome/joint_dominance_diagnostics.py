"""Diagnose which modality dominates the joint scVI + DynaCLR embedding.

Three diagnostics
-----------------
1. kNN-overlap: for each cell, fraction of joint kNN that are also kNN in
   scVI-only / image-only. Whichever is higher dominates the geometry.
2. PCA loadings: for each leading joint PC, norm of scVI block vs image block.
3. Linear-probe accuracy on phase, in scVI-only / image-only / joint spaces.
"""

from __future__ import annotations

from pathlib import Path

import anndata as ad
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.decomposition import PCA
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import StratifiedKFold, cross_val_score
from sklearn.neighbors import NearestNeighbors
from sklearn.preprocessing import StandardScaler

H5AD = Path(
    "/hpc/projects/multimodal/datasets/cellanome/"
    "20260401095121_P-05_R000515_FC_2026_04_01_A549_SEC61B_DENV_ZIKV_mRNA+imaging/"
    "A549_single_cell_embedded.h5ad"
)
OUT = Path(
    "/hpc/mydata/eduardo.hirata/repos/viscy/applications/dynaclr/scripts/"
    "cellanome/output/joint_umap"
)
OUT.mkdir(parents=True, exist_ok=True)

SCVI_KEY = "X_scvi"
IMAGE_KEY = "dynaclr"
PHASE_KEY = "phase"
N_IMAGE_PCS = 30
K_NEIGHBORS = 30
N_FOLDS = 5


def neighbor_overlap(query: np.ndarray, ref: np.ndarray, k: int) -> np.ndarray:
    """Per-cell fraction of query kNN that are also ref kNN."""
    nn_q = NearestNeighbors(n_neighbors=k + 1, metric="cosine").fit(query)
    nn_r = NearestNeighbors(n_neighbors=k + 1, metric="cosine").fit(ref)
    idx_q = nn_q.kneighbors(return_distance=False)[:, 1:]
    idx_r = nn_r.kneighbors(return_distance=False)[:, 1:]
    overlaps = np.empty(len(query), dtype=np.float32)
    for i in range(len(query)):
        overlaps[i] = len(set(idx_q[i]) & set(idx_r[i])) / k
    return overlaps


def block_pca_loadings(
    joint: np.ndarray, scvi_dim: int, n_components: int
) -> pd.DataFrame:
    """For each top joint PC, report L2 norm contributed by each block."""
    pca = PCA(n_components=n_components, random_state=0).fit(joint)
    rows = []
    for i, comp in enumerate(pca.components_):
        rows.append(
            {
                "PC": i + 1,
                "var_explained": pca.explained_variance_ratio_[i],
                "scvi_norm": float(np.linalg.norm(comp[:scvi_dim])),
                "image_norm": float(np.linalg.norm(comp[scvi_dim:])),
            }
        )
    return pd.DataFrame(rows)


def cv_linear_probe(x: np.ndarray, y: np.ndarray) -> tuple[float, float]:
    """5-fold stratified CV macro-F1 of a logistic-regression phase probe."""
    skf = StratifiedKFold(n_splits=N_FOLDS, shuffle=True, random_state=0)
    clf = LogisticRegression(max_iter=2000, n_jobs=-1)
    scores = cross_val_score(clf, x, y, cv=skf, scoring="accuracy", n_jobs=N_FOLDS)
    return float(scores.mean()), float(scores.std())


def plot_overlap_hist(
    o_scvi: np.ndarray, o_image: np.ndarray, out_path: Path
) -> None:
    fig, ax = plt.subplots(figsize=(6, 4))
    ax.hist(o_scvi, bins=40, alpha=0.6, label=f"scVI (mean={o_scvi.mean():.3f})")
    ax.hist(o_image, bins=40, alpha=0.6, label=f"DynaCLR (mean={o_image.mean():.3f})")
    ax.set_xlabel(f"per-cell kNN overlap with joint (k={K_NEIGHBORS})")
    ax.set_ylabel("cells")
    ax.set_title("Joint-vs-single kNN overlap (higher = that modality dominates)")
    ax.legend()
    fig.tight_layout()
    fig.savefig(out_path, dpi=200)
    plt.close(fig)


def plot_pc_loadings(df: pd.DataFrame, out_path: Path) -> None:
    fig, ax = plt.subplots(figsize=(7, 4))
    x = df["PC"]
    width = 0.4
    ax.bar(x - width / 2, df["scvi_norm"], width=width, label="scVI block")
    ax.bar(x + width / 2, df["image_norm"], width=width, label="DynaCLR block")
    ax2 = ax.twinx()
    ax2.plot(x, df["var_explained"].cumsum(), "k--", marker="o", label="cum var")
    ax.set_xlabel("Joint PC")
    ax.set_ylabel("block L2 norm in PC")
    ax2.set_ylabel("cumulative variance explained")
    ax.set_title("Per-block contribution to leading joint PCs")
    ax.legend(loc="upper left")
    ax2.legend(loc="upper right")
    fig.tight_layout()
    fig.savefig(out_path, dpi=200)
    plt.close(fig)


def plot_probe_bars(scores: dict[str, tuple[float, float]], out_path: Path) -> None:
    labels = list(scores)
    means = [scores[k][0] for k in labels]
    stds = [scores[k][1] for k in labels]
    colors = ["#4C72B0", "#C44E52", "#55A868", "#8172B2"][: len(labels)]
    fig, ax = plt.subplots(figsize=(6, 4))
    ax.bar(labels, means, yerr=stds, color=colors, capsize=4)
    for i, m in enumerate(means):
        ax.text(i, m + 0.005, f"{m:.3f}", ha="center", fontsize=9)
    ax.set_ylabel("5-fold CV phase accuracy")
    ax.set_ylim(0, 1.0)
    ax.set_title("Linear probe on phase by embedding space")
    fig.tight_layout()
    fig.savefig(out_path, dpi=200)
    plt.close(fig)


def main() -> None:
    print("## Loading paired anndata")
    adata = ad.read_h5ad(H5AD)
    scvi = adata.obsm[SCVI_KEY].astype(np.float32)
    image = adata.obsm[IMAGE_KEY].astype(np.float32)
    phase = adata.obs[PHASE_KEY].astype(str).to_numpy()
    print(f"- cells: {adata.n_obs}, scVI: {scvi.shape}, image: {image.shape}")

    print("\n## Standardizing + PCA on image block")
    scvi_z = StandardScaler().fit_transform(scvi)
    image_pcs = PCA(n_components=N_IMAGE_PCS, random_state=0).fit_transform(image)
    image_z = StandardScaler().fit_transform(image_pcs)
    joint = np.concatenate([scvi_z, image_z], axis=1)
    print(f"- joint shape: {joint.shape}")

    print("\n## Diagnostic 1: kNN-overlap (joint vs each modality)")
    o_scvi = neighbor_overlap(joint, scvi_z, K_NEIGHBORS)
    o_image = neighbor_overlap(joint, image_z, K_NEIGHBORS)
    print(f"- mean overlap joint↔scVI:    {o_scvi.mean():.3f}")
    print(f"- mean overlap joint↔DynaCLR: {o_image.mean():.3f}")
    ratio = o_scvi.mean() / max(o_image.mean(), 1e-6)
    if ratio > 2:
        verdict = "**scVI dominates**"
    elif ratio < 0.5:
        verdict = "**DynaCLR dominates**"
    else:
        verdict = "**Balanced**"
    print(f"- verdict: {verdict} (ratio scvi/image = {ratio:.2f})")
    plot_overlap_hist(o_scvi, o_image, OUT / "diag_knn_overlap.png")

    print("\n## Diagnostic 2: per-block PCA loadings")
    df_pc = block_pca_loadings(joint, scvi_dim=scvi_z.shape[1], n_components=10)
    print(df_pc.to_markdown(index=False, floatfmt=".3f"))
    plot_pc_loadings(df_pc, OUT / "diag_pc_loadings.png")
    df_pc.to_csv(OUT / "diag_pc_loadings.csv", index=False)

    print("\n## Diagnostic 3: linear probe accuracy on phase")
    scores: dict[str, tuple[float, float]] = {}
    scores["scVI"] = cv_linear_probe(scvi_z, phase)
    scores["DynaCLR"] = cv_linear_probe(image_z, phase)
    scores["joint"] = cv_linear_probe(joint, phase)
    for k, (m, s) in scores.items():
        print(f"- {k:8s} acc = {m:.4f} ± {s:.4f}")
    plot_probe_bars(scores, OUT / "diag_phase_probe.png")
    pd.DataFrame(
        [{"space": k, "acc_mean": m, "acc_std": s} for k, (m, s) in scores.items()]
    ).to_csv(OUT / "diag_phase_probe.csv", index=False)

    print("\n## Done — outputs in", OUT)


if __name__ == "__main__":
    main()
