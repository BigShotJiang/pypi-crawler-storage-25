"""Post-hoc analysis of a trained DynaCLR-2D-Cellanome-A549 cross-modal run.

For a given checkpoint:
1. Loads model + cross-modal head with trained weights.
2. Runs the val loader, collects:
   - 768-d backbone features
   - 128-d cross-modal head projections
   - 50-d (or D-d) raw paired target
   - phase labels
3. Reports:
   - cross-modal val loss (InfoNCE)
   - mean cosine(image_proj, target_proj)
   - retrieval@1
   - phase linear probe on backbone (768) and on head projection (128)
4. Writes a JSON + CSV next to the checkpoint.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd
import torch
import torch.nn.functional as F
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from torch.utils.data import DataLoader

from cross_modal_dataset import CellanomePairedConfig, CellanomePairedDataset, collate_paired
from dynaclr.engine import ContrastiveModule
from viscy_models.contrastive import ContrastiveEncoder
from viscy_models.contrastive.loss import NTXentLoss
from viscy_models.components.heads import CrossModalContrastiveHead

DATASET_DIR = (
    "/hpc/projects/multimodal/datasets/cellanome/"
    "20260401095121_P-05_R000515_FC_2026_04_01_A549_SEC61B_DENV_ZIKV_mRNA+imaging"
)


def build_config() -> CellanomePairedConfig:
    return CellanomePairedConfig(
        zarr_store=(
            f"{DATASET_DIR}/0-convert/ome-zarr/"
            "20260401095121_P-05_R000515_FC_2026_04_01_A549_SEC61B_DENV_ZIKV_mRNA+imaging.zarr"
        ),
        cell_index_zarr=f"{DATASET_DIR}/2-embeddings/dynaclr-2d-boc-BF.zarr",
        transcriptome_h5ad=f"{DATASET_DIR}/A549_single_cell_embedded.h5ad",
        target_keys=("X_pls",),
        pairs_only=True,
    )


def build_module(target_dim: int, target_key: str) -> ContrastiveModule:
    encoder = ContrastiveEncoder(
        backbone="convnext_tiny",
        in_channels=1,
        embedding_dim=768,
        in_stack_depth=1,
        stem_kernel_size=(1, 4, 4),
        stem_stride=(1, 4, 4),
        projection_dim=32,
        drop_path_rate=0.1,
    )
    head = CrossModalContrastiveHead(
        head_name="xmodal",
        batch_key=target_key,
        in_dims=768,
        target_dims=target_dim,
        proj_dims=128,
        temperature=0.1,
    )
    return ContrastiveModule(
        encoder=encoder,
        loss_function=NTXentLoss(temperature=0.2),
        example_input_array_shape=(1, 1, 1, 160, 160),
        auxiliary_heads={"xmodal": head},
    )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--ckpt", required=True, help="Path to last.ckpt from training")
    parser.add_argument(
        "--indices",
        default=None,
        help="Optional .npy of validation indices to use (else random 2048)",
    )
    parser.add_argument("--n-val", type=int, default=2048)
    parser.add_argument("--n-train-probe", type=int, default=8192)
    parser.add_argument("--batch-size", type=int, default=64)
    parser.add_argument("--num-workers", type=int, default=4)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--target", default="X_pls")
    parser.add_argument("--target-dim", type=int, default=50)
    args = parser.parse_args()

    device = "cuda" if torch.cuda.is_available() else "cpu"
    print(f"## Device: {device}")

    print("## Loading checkpoint", args.ckpt)
    module = build_module(args.target_dim, args.target)
    state = torch.load(args.ckpt, map_location="cpu", weights_only=False)["state_dict"]
    missing, unexpected = module.load_state_dict(state, strict=False)
    print(f"- missing keys: {len(missing)}  unexpected: {len(unexpected)}")
    module.eval().to(device)

    print("\n## Building paired val + train-probe datasets")
    cfg = build_config()
    rng = np.random.default_rng(args.seed)
    full_ds_for_idx = CellanomePairedDataset(cfg, augment=False)
    n_total = len(full_ds_for_idx)
    paired_idx = np.where(full_ds_for_idx.phase_labels != "")[0]
    rng.shuffle(paired_idx)
    val_idx = paired_idx[: args.n_val]
    train_idx = paired_idx[args.n_val : args.n_val + args.n_train_probe]
    print(f"- total paired: {len(paired_idx)} | val: {len(val_idx)} | train probe: {len(train_idx)}")

    def make_loader(indices: np.ndarray) -> DataLoader:
        ds = CellanomePairedDataset(cfg, indices=indices, augment=False)
        return DataLoader(
            ds,
            batch_size=args.batch_size,
            shuffle=False,
            num_workers=args.num_workers,
            collate_fn=collate_paired,
            pin_memory=True,
        )

    val_loader = make_loader(val_idx)
    train_loader = make_loader(train_idx)

    head: CrossModalContrastiveHead = module.auxiliary_heads["xmodal"]  # type: ignore[assignment]

    def extract(loader: DataLoader) -> dict[str, np.ndarray]:
        feats: list[np.ndarray] = []
        projs: list[np.ndarray] = []
        targets: list[np.ndarray] = []
        phases: list[str] = []
        with torch.no_grad():
            for batch in loader:
                anchor = batch["anchor"].to(device)
                f, _ = module(anchor)
                p = head(f)
                t = torch.from_numpy(
                    np.stack([m["labels"][args.target] for m in batch["anchor_meta"]])
                ).to(device)
                feats.append(f.float().cpu().numpy())
                projs.append(p.float().cpu().numpy())
                targets.append(t.float().cpu().numpy())
                phases.extend(m["phase"] for m in batch["anchor_meta"])
        return {
            "features": np.concatenate(feats),
            "projs": np.concatenate(projs),
            "targets": np.concatenate(targets),
            "phases": np.asarray(phases),
        }

    print("\n## Extracting val")
    val = extract(val_loader)
    print(f"- features {val['features'].shape}  projs {val['projs'].shape}")

    print("## Extracting train (probe fit set)")
    train = extract(train_loader)

    print("\n## Cross-modal head metrics (val)")
    z_img = torch.from_numpy(val["projs"]).to(device)
    target_proj = head.project_target(torch.from_numpy(val["targets"]).to(device))
    cos_diag = (z_img * target_proj).sum(dim=-1).mean().item()
    logits = z_img @ target_proj.t() / head.temperature
    labels = torch.arange(z_img.size(0), device=z_img.device)
    info_nce = 0.5 * (
        F.cross_entropy(logits, labels) + F.cross_entropy(logits.t(), labels)
    )
    r1 = (logits.argmax(dim=1) == labels).float().mean().item()
    print(f"- val InfoNCE loss:    {info_nce.item():.4f}")
    print(f"- val mean cos(img,t): {cos_diag:.4f}")
    print(f"- val retrieval @ 1:   {r1:.4f}")

    print("\n## Phase linear probe — backbone features (768)")
    sc_b = StandardScaler().fit(train["features"])
    clf_b = LogisticRegression(max_iter=2000)
    clf_b.fit(sc_b.transform(train["features"]), train["phases"])
    backbone_acc = float(
        (clf_b.predict(sc_b.transform(val["features"])) == val["phases"]).mean()
    )
    print(f"- val acc: {backbone_acc:.4f}")

    print("\n## Phase linear probe — head projections (128)")
    sc_p = StandardScaler().fit(train["projs"])
    clf_p = LogisticRegression(max_iter=2000)
    clf_p.fit(sc_p.transform(train["projs"]), train["phases"])
    proj_acc = float(
        (clf_p.predict(sc_p.transform(val["projs"])) == val["phases"]).mean()
    )
    print(f"- val acc: {proj_acc:.4f}")

    out_dir = Path(args.ckpt).parent.parent
    summary = {
        "ckpt": str(args.ckpt),
        "n_val": int(len(val_idx)),
        "n_train_probe": int(len(train_idx)),
        "val_xmodal_infonce": float(info_nce.item()),
        "val_mean_cos_img_target": cos_diag,
        "val_retrieval_at_1": r1,
        "phase_probe_backbone_768": backbone_acc,
        "phase_probe_head_proj_128": proj_acc,
    }
    (out_dir / "xmodal_analysis.json").write_text(json.dumps(summary, indent=2))
    pd.DataFrame([summary]).to_csv(out_dir / "xmodal_analysis.csv", index=False)
    print(f"\nSaved: {out_dir / 'xmodal_analysis.json'}")


if __name__ == "__main__":
    main()
