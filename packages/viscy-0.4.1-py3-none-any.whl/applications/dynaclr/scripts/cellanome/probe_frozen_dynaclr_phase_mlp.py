"""Frozen DynaCLR-BF phase probes — LR + MLP, 3-class + binary G2M-vs-rest.

Reads the precomputed image-embedding zarr (no GPU, no images), joins phase
labels from the transcriptome h5ad, and reports four probes:

1. Linear (logistic regression), 3-class
2. MLP, 3-class
3. Linear, binary G2M-vs-rest
4. MLP, binary G2M-vs-rest

For each probe we report bal_acc, macro F1, per-class F1 (3-class) or AUROC
(binary). These are the numbers that match the published DynaCLR-BF baselines
in ``2-embeddings/figures/`` (3-class bal_acc 0.548, binary G2M bal_acc 0.743).

This sets the *frozen ceiling* the cross-modal training has to beat.
"""

from __future__ import annotations

from pathlib import Path

import anndata as ad
import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import balanced_accuracy_score, f1_score, roc_auc_score
from sklearn.model_selection import train_test_split
from sklearn.neural_network import MLPClassifier
from sklearn.preprocessing import StandardScaler

DATASET_DIR = (
    "/hpc/projects/multimodal/datasets/cellanome/"
    "20260401095121_P-05_R000515_FC_2026_04_01_A549_SEC61B_DENV_ZIKV_mRNA+imaging"
)
OUT = Path(
    "/hpc/mydata/eduardo.hirata/repos/viscy/applications/dynaclr/scripts/"
    "cellanome/output/DynaCLR-2D-Cellanome-A549"
)
OUT.mkdir(parents=True, exist_ok=True)


def load_paired() -> tuple[np.ndarray, np.ndarray]:
    """Return (features, phase_labels) for cells with paired phase."""
    cell_index = ad.read_zarr(f"{DATASET_DIR}/2-embeddings/dynaclr-2d-boc-BF.zarr")
    tx = ad.read_h5ad(f"{DATASET_DIR}/A549_single_cell_embedded.h5ad", backed="r")
    barcode_keys = (
        tx.obs["barcode.sequence"].astype(str) + "-" + tx.obs["lane"].astype(str)
    ).to_numpy()
    barcode_to_idx = {bc: i for i, bc in enumerate(barcode_keys)}
    phase = tx.obs["phase"].astype(str).to_numpy()
    img_b = cell_index.obs["barcode_index"].astype(str).to_numpy()
    phase_per_cell = np.full(cell_index.n_obs, "", dtype=object)
    for i, bc in enumerate(img_b):
        j = barcode_to_idx.get(bc)
        if j is not None:
            phase_per_cell[i] = phase[j]
    mask = phase_per_cell != ""
    features = np.asarray(cell_index.X[mask], dtype=np.float32)
    labels = phase_per_cell[mask].astype("U8")
    return features, labels


def split(features: np.ndarray, labels: np.ndarray, seed: int = 42):
    """Stratified 80/20 split + standardize from train."""
    idx = np.arange(len(labels))
    tr, va = train_test_split(idx, test_size=0.2, stratify=labels, random_state=seed)
    sc = StandardScaler().fit(features[tr])
    return sc.transform(features[tr]), sc.transform(features[va]), labels[tr], labels[va]


def report_3class(
    name: str, clf, x_tr, y_tr, x_va, y_va, classes: list[str]
) -> dict:
    """Fit clf on train, score on val; return 3-class metrics dict."""
    cls_to_int = {c: i for i, c in enumerate(classes)}
    y_tr_i = np.asarray([cls_to_int[c] for c in y_tr], dtype=np.int64)
    y_va_i = np.asarray([cls_to_int[c] for c in y_va], dtype=np.int64)
    clf.fit(x_tr, y_tr_i)
    pred_i = clf.predict(x_va)
    bal_acc = balanced_accuracy_score(y_va_i, pred_i)
    macro_f1 = f1_score(y_va_i, pred_i, average="macro")
    per_class = f1_score(y_va_i, pred_i, labels=list(range(len(classes))), average=None)
    print(f"- {name:30s} bal_acc={bal_acc:.4f}  macro_f1={macro_f1:.4f}")
    for cls, f in zip(classes, per_class):
        print(f"    {cls:5s} F1={f:.4f}")
    return {
        "probe": name,
        "task": "3class",
        "bal_acc": float(bal_acc),
        "macro_f1": float(macro_f1),
        **{f"f1_{c}": float(f) for c, f in zip(classes, per_class)},
    }


def report_binary(name: str, clf, x_tr, y_tr_bin, x_va, y_va_bin) -> dict:
    """Fit binary clf, return AUROC / bal_acc / F1."""
    clf.fit(x_tr, y_tr_bin)
    if hasattr(clf, "predict_proba"):
        proba = clf.predict_proba(x_va)[:, 1]
    else:  # fall back
        proba = clf.decision_function(x_va)
    pred = clf.predict(x_va)
    auroc = roc_auc_score(y_va_bin, proba)
    bal_acc = balanced_accuracy_score(y_va_bin, pred)
    f1 = f1_score(y_va_bin, pred)
    print(f"- {name:30s} auroc={auroc:.4f}  bal_acc={bal_acc:.4f}  f1={f1:.4f}")
    return {
        "probe": name,
        "task": "binary_G2M_vs_rest",
        "auroc": float(auroc),
        "bal_acc": float(bal_acc),
        "f1": float(f1),
    }


def main() -> None:
    print("## Loading paired DynaCLR-BF features + phase labels")
    features, labels = load_paired()
    print(f"- cells: {len(labels)}, features: {features.shape}")
    print(f"- class counts: {pd.Series(labels).value_counts().to_dict()}")

    print("\n## Stratified 80/20 split (seed=42)")
    x_tr, x_va, y_tr, y_va = split(features, labels)
    print(f"- train: {len(y_tr)} | val: {len(y_va)}")

    classes = ["G1", "S", "G2M"]
    rows: list[dict] = []

    print("\n## 3-class probes")
    rows.append(
        report_3class(
            "Linear (LogReg, C=1.0)",
            LogisticRegression(max_iter=2000, C=1.0),
            x_tr, y_tr, x_va, y_va, classes,
        )
    )
    rows.append(
        report_3class(
            "MLP (256, 128)",
            MLPClassifier(
                hidden_layer_sizes=(256, 128),
                max_iter=200,
                early_stopping=True,
                validation_fraction=0.1,
                random_state=42,
            ),
            x_tr, y_tr, x_va, y_va, classes,
        )
    )

    print("\n## Binary G2M-vs-rest probes")
    y_tr_bin = (y_tr == "G2M").astype(int)
    y_va_bin = (y_va == "G2M").astype(int)
    rows.append(
        report_binary(
            "Linear (LogReg, C=1.0)",
            LogisticRegression(max_iter=2000, C=1.0),
            x_tr, y_tr_bin, x_va, y_va_bin,
        )
    )
    rows.append(
        report_binary(
            "MLP (256, 128)",
            MLPClassifier(
                hidden_layer_sizes=(256, 128),
                max_iter=200,
                early_stopping=True,
                validation_fraction=0.1,
                random_state=42,
            ),
            x_tr, y_tr_bin, x_va, y_va_bin,
        )
    )

    df = pd.DataFrame(rows)
    out_csv = OUT / "frozen_dynaclr_phase_probes_full.csv"
    df.to_csv(out_csv, index=False)
    print(f"\n## Saved: {out_csv}")


if __name__ == "__main__":
    main()
