"""Fig 2 — Hierarchical channel-adaptive embedding panels with crop callouts.

Reads the per-(experiment x marker) AnnData zarrs produced by ``dynaclr evaluate``,
concatenates them into one joint AnnData, and emits:

- Panel 2a: joint PHATE colored / hexbinned by marker (markers occupy distinct
  regions of the global embedding).
- Panel 2b: small multiples — one subplot per marker, points colored by
  ``perturbation`` and sized by ``hours_post_perturbation`` (biology within
  each marker's region).
- Crop contact sheet: image patches sampled from the source zarrs at picked
  PHATE positions, plus a numbered overlay on panel 2a so each crop maps
  back to its embedding coordinate.
- ``crops_index.csv``: one row per picked crop with marker, perturbation,
  hpp, fov_name, track_id, t, y, x, phate_x, phate_y.

The joint embedding is *not* recomputed — ``evaluation.reduce_combined`` already
wrote ``X_phate_combined`` and ``X_pca_combined`` into each store after fitting
once on the concatenation of all stores. We just slice it back.

Usage
-----
    uv run python applications/dynaclr/scripts/evaluation/fig2_channel_adaptive.py \
        -c applications/dynaclr/configs/evaluation/figures/fig2_channel_adaptive.yaml
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Optional

import anndata as ad
import click
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from iohub.ngff import open_ome_zarr
from matplotlib.colors import Normalize
from matplotlib.patches import Circle

from viscy_utils.cli_utils import format_markdown_table, load_config


# ---------------------------------------------------------------------------
# Data loading
# ---------------------------------------------------------------------------


@dataclass
class CropTarget:
    """One row of the crop index — selected cell to crop and annotate.

    Attributes
    ----------
    label : str
        Display id used both in the contact sheet header and on the PHATE
        scatter overlay.
    marker : str
        Marker / channel label (e.g. ``"SEC61B"``).
    perturbation : str
        Perturbation label.
    hpp : float
        Hours post perturbation.
    experiment : str
        Source experiment id (matches parquet ``experiment``).
    fov_name : str
        FOV path (e.g. ``"B/2/000000"``).
    track_id : int
        Track id within the FOV.
    t : int
        Timepoint index.
    z : int
        Z slice center.
    y : float
        Y centroid (pixels).
    x : float
        X centroid (pixels).
    store_path : str
        OME-Zarr plate path.
    channel_name : str
        Zarr channel name to read.
    phate_x : float
        Joint PHATE coordinate 0.
    phate_y : float
        Joint PHATE coordinate 1.
    """

    label: str
    marker: str
    perturbation: str
    hpp: float
    experiment: str
    fov_name: str
    track_id: int
    t: int
    z: int
    y: float
    x: float
    store_path: str
    channel_name: str
    phate_x: float
    phate_y: float


def _load_concat(embeddings_dir: Path) -> ad.AnnData:
    """Concatenate every ``*.zarr`` AnnData under ``embeddings_dir``.

    Parameters
    ----------
    embeddings_dir : Path
        Directory containing per-(experiment x marker) AnnData zarrs written
        by ``dynaclr evaluate``.

    Returns
    -------
    ad.AnnData
        Concatenated AnnData with ``obsm['X_phate_combined']`` and
        ``obsm['X_pca_combined']``.
    """
    paths = sorted(p for p in embeddings_dir.glob("*.zarr") if p.is_dir())
    if not paths:
        raise click.ClickException(f"No *.zarr stores under {embeddings_dir}")
    click.echo(f"Loading {len(paths)} stores from {embeddings_dir}")
    stores = [ad.read_zarr(p) for p in paths]
    # Make obs_names unique before concat (per-store duplicates seen in practice)
    for a in stores:
        a.obs_names_make_unique()
    concat = ad.concat(stores, join="outer", index_unique="-", label="store_index", merge="first")
    click.echo(
        f"Concatenated: {concat.n_obs:,} cells x {concat.n_vars} features; "
        f"markers={sorted(concat.obs['marker'].unique())}"
    )
    return concat


def _resolve_parquet_lookup(cell_index_path: Path) -> pd.DataFrame:
    """Load minimal columns from the cell-index parquet for crop lookup.

    Parameters
    ----------
    cell_index_path : Path
        Flat cell-index parquet (one row per cell x timepoint x channel).

    Returns
    -------
    pd.DataFrame
        Index columns sufficient to resolve ``store_path`` and
        ``channel_name`` from ``(experiment, fov_name, marker)``.
    """
    cols = ["experiment", "well", "fov", "marker", "channel_name", "store_path"]
    df = pd.read_parquet(cell_index_path, columns=cols)
    df["fov_name"] = df["well"].astype(str) + "/" + df["fov"].astype(str)
    df = df.drop_duplicates(subset=["experiment", "fov_name", "marker"]).reset_index(drop=True)
    return df


# ---------------------------------------------------------------------------
# Display sampling
# ---------------------------------------------------------------------------


def _subsample_per_marker(adata: ad.AnnData, per_marker: int, random_state: int) -> np.ndarray:
    """Return row indices subsampled uniformly per marker.

    Parameters
    ----------
    adata : ad.AnnData
        Concatenated AnnData.
    per_marker : int
        Cap per marker. Rows in markers with fewer cells are all kept.
    random_state : int
        Seed.

    Returns
    -------
    np.ndarray
        Global row indices, shuffled so plotting doesn't stack colors.
    """
    rng = np.random.default_rng(random_state)
    markers = adata.obs["marker"].to_numpy()
    out = []
    for m in np.unique(markers):
        idx = np.where(markers == m)[0]
        if idx.size > per_marker:
            idx = rng.choice(idx, size=per_marker, replace=False)
        out.append(idx)
    picked = np.concatenate(out)
    rng.shuffle(picked)
    return picked


# ---------------------------------------------------------------------------
# Panel 2a — joint embedding colored by marker
# ---------------------------------------------------------------------------


def _plot_panel_2a(
    coords: np.ndarray,
    markers: np.ndarray,
    cfg: dict,
    crop_targets: list[CropTarget],
    out_dir: Path,
    fmt: str,
    dpi: int,
) -> None:
    """Joint PHATE colored / hexbinned by marker, with optional crop callouts."""
    marker_order = sorted(np.unique(markers).tolist())
    fig, ax = plt.subplots(figsize=(7, 6))
    x_all, y_all = coords[:, 0], coords[:, 1]
    pad = 0.05 * (x_all.max() - x_all.min())
    ax.set_xlim(x_all.min() - pad, x_all.max() + pad)
    ax.set_ylim(y_all.min() - pad, y_all.max() + pad)

    if cfg["mode"] == "hexbin":
        # Per-marker hexbin layered on top of each other; each marker has its own colormap.
        for m in marker_order:
            mask = markers == m
            if mask.sum() == 0:
                continue
            ax.hexbin(
                coords[mask, 0],
                coords[mask, 1],
                gridsize=cfg["gridsize"],
                cmap=cfg["cmap_per_marker"].get(m, "viridis"),
                mincnt=cfg["mincnt"],
                alpha=0.65,
                linewidths=0,
            )
        # Legend proxies (one filled circle per marker, color taken from the cmap midpoint)
        handles = []
        for m in marker_order:
            cmap = plt.get_cmap(cfg["cmap_per_marker"].get(m, "viridis"))
            handles.append(plt.Line2D([0], [0], marker="o", linestyle="", color=cmap(0.7), label=m, markersize=8))
        ax.legend(handles=handles, title="marker", loc="best", frameon=False)
    else:
        for m in marker_order:
            mask = markers == m
            ax.scatter(
                coords[mask, 0],
                coords[mask, 1],
                s=cfg["point_size"],
                alpha=cfg["alpha"],
                label=m,
                linewidths=0,
            )
        ax.legend(title="marker", loc="best", frameon=False, markerscale=3)

    ax.set_xlabel("PHATE 1")
    ax.set_ylabel("PHATE 2")
    ax.set_title("Joint PHATE — markers cluster by channel")

    if crop_targets and cfg.get("annotate_phate_scatter", True):
        for ct in crop_targets:
            ax.add_patch(
                Circle(
                    (ct.phate_x, ct.phate_y),
                    radius=pad * 0.25,
                    fill=False,
                    edgecolor="black",
                    linewidth=1.0,
                )
            )
            ax.text(
                ct.phate_x,
                ct.phate_y,
                ct.label,
                fontsize=7,
                ha="center",
                va="center",
                color="black",
            )

    _save(fig, out_dir / "panel_2a_joint_phate_by_marker", fmt, dpi)


# ---------------------------------------------------------------------------
# Panel 2b — small multiples per marker, biology within each region
# ---------------------------------------------------------------------------


_PERTURBATION_COLORS = {
    "uninfected": "#7f7f7f",
    "ZIKV": "#d9534f",
    "DENV": "#1b69a1",
    "infected": "#9467bd",
    "mock": "#5cb85c",
}


def _plot_panel_2b(
    coords: np.ndarray,
    obs: pd.DataFrame,
    cfg: dict,
    out_dir: Path,
    fmt: str,
    dpi: int,
) -> None:
    """Faceted PHATE — one panel per marker, hue=perturbation, size=hpp.

    Each subplot uses the global PHATE axis limits so marker regions are
    visually anchored.
    """
    markers = sorted(obs["marker"].unique().tolist())
    cols = cfg["cols"]
    rows = (len(markers) + cols - 1) // cols
    fig, axes = plt.subplots(rows, cols, figsize=(4 * cols, 4 * rows), squeeze=False)

    xmin, xmax = coords[:, 0].min(), coords[:, 0].max()
    ymin, ymax = coords[:, 1].min(), coords[:, 1].max()
    pad_x = 0.05 * (xmax - xmin)
    pad_y = 0.05 * (ymax - ymin)

    hpp = obs[cfg["size"]].to_numpy(dtype=float)
    hpp_finite = hpp[np.isfinite(hpp)]
    if hpp_finite.size == 0:
        hpp_norm = Normalize(vmin=0, vmax=1)
    else:
        hpp_norm = Normalize(vmin=float(np.nanmin(hpp_finite)), vmax=float(np.nanmax(hpp_finite)))
    s_lo, s_hi = cfg["size_range"]

    def _sizes(values: np.ndarray) -> np.ndarray:
        v = hpp_norm(values)
        v = np.clip(np.where(np.isfinite(v), v, 0.0), 0.0, 1.0)
        return s_lo + v * (s_hi - s_lo)

    for ax, m in zip(axes.ravel(), markers):
        # Faint global background — all points, gray
        ax.scatter(coords[:, 0], coords[:, 1], s=1, c="#e0e0e0", linewidths=0, rasterized=True)
        mask = (obs["marker"] == m).to_numpy()
        for pert in obs.loc[mask, "perturbation"].dropna().unique():
            sub = mask & (obs["perturbation"] == pert).to_numpy()
            color = _PERTURBATION_COLORS.get(pert, "#444444")
            ax.scatter(
                coords[sub, 0],
                coords[sub, 1],
                s=_sizes(hpp[sub]),
                c=color,
                alpha=cfg["alpha"],
                label=pert,
                linewidths=0,
                edgecolors="none",
            )
        ax.set_xlim(xmin - pad_x, xmax + pad_x)
        ax.set_ylim(ymin - pad_y, ymax + pad_y)
        ax.set_title(m)
        ax.set_xlabel("PHATE 1")
        ax.set_ylabel("PHATE 2")
        ax.legend(title="perturbation", fontsize=7, frameon=False, loc="best", markerscale=2)

    # Drop unused axes
    for ax in axes.ravel()[len(markers):]:
        ax.axis("off")

    # Size legend — three swatches at min / mid / max hpp
    if hpp_finite.size:
        ax = axes.ravel()[len(markers) - 1]
        legend_handles = []
        for q in (0.0, 0.5, 1.0):
            v = hpp_norm.vmin + q * (hpp_norm.vmax - hpp_norm.vmin)
            legend_handles.append(
                plt.scatter([], [], s=_sizes(np.array([v])), c="#444", label=f"{v:.0f} h", edgecolors="none")
            )
        ax.legend(
            handles=legend_handles,
            title="hpp",
            fontsize=7,
            frameon=False,
            loc="lower right",
        )

    fig.suptitle("Within each marker's region, perturbation × hpp is recovered")
    fig.tight_layout()
    _save(fig, out_dir / "panel_2b_phate_per_marker", fmt, dpi)


# ---------------------------------------------------------------------------
# Crop sampling
# ---------------------------------------------------------------------------


def _select_stratified(
    obs: pd.DataFrame,
    coords: np.ndarray,
    cfg: dict,
    markers: list[str],
    perturbations: list[str],
) -> list[dict]:
    """Sample N cells per (marker, perturbation, hpp_bin)."""
    rng = np.random.default_rng(cfg["random_state"])
    bins = np.asarray(cfg["hpp_bins"], dtype=float)
    n = cfg["n_per_cell"]
    hpp = obs["hours_post_perturbation"].to_numpy(dtype=float)
    bin_idx = np.digitize(hpp, bins) - 1  # -1 means below first edge; len(bins)-1 means above last edge
    rows: list[dict] = []
    for m in markers:
        for p in perturbations:
            for b in range(len(bins) - 1):
                mask = (
                    (obs["marker"].to_numpy() == m)
                    & (obs["perturbation"].to_numpy() == p)
                    & (bin_idx == b)
                )
                idx = np.where(mask)[0]
                if idx.size == 0:
                    continue
                k = min(n, idx.size)
                picked = rng.choice(idx, size=k, replace=False)
                for i in picked:
                    rows.append(
                        {
                            "i": int(i),
                            "marker": m,
                            "perturbation": p,
                            "hpp_bin": f"[{bins[b]:.0f},{bins[b + 1]:.0f})",
                        }
                    )
    return rows


def _select_nearest(
    obs: pd.DataFrame,
    coords: np.ndarray,
    points: list[dict],
) -> list[dict]:
    """Pick the k nearest cells in PHATE space to each user-specified point."""
    rows: list[dict] = []
    for pt in points:
        target = np.asarray(pt["xy"], dtype=float)
        marker = pt.get("marker")
        k = int(pt.get("k", 1))
        label = pt["label"]
        mask = np.ones(obs.shape[0], dtype=bool)
        if marker is not None:
            mask = obs["marker"].to_numpy() == marker
        idx = np.where(mask)[0]
        if idx.size == 0:
            continue
        d2 = ((coords[idx] - target) ** 2).sum(axis=1)
        order = np.argsort(d2)[:k]
        for j, off in enumerate(order):
            rows.append(
                {
                    "i": int(idx[off]),
                    "marker": obs["marker"].iloc[idx[off]],
                    "perturbation": obs["perturbation"].iloc[idx[off]],
                    "hpp_bin": f"nearest:{label}#{j}",
                }
            )
    return rows


def _build_crop_targets(
    selected: list[dict],
    obs: pd.DataFrame,
    coords: np.ndarray,
    parquet_lookup: pd.DataFrame,
) -> list[CropTarget]:
    """Resolve ``store_path`` / ``channel_name`` for each selected cell."""
    lut = parquet_lookup.set_index(["experiment", "fov_name", "marker"])[["store_path", "channel_name"]]
    targets: list[CropTarget] = []
    for n, row in enumerate(selected):
        i = row["i"]
        o = obs.iloc[i]
        key = (o["experiment"], o["fov_name"], o["marker"])
        if key not in lut.index:
            click.echo(f"  [skip] no parquet row for {key}", err=True)
            continue
        store_path, channel_name = lut.loc[key, ["store_path", "channel_name"]]
        targets.append(
            CropTarget(
                label=str(n + 1),
                marker=str(o["marker"]),
                perturbation=str(o["perturbation"]),
                hpp=float(o["hours_post_perturbation"]),
                experiment=str(o["experiment"]),
                fov_name=str(o["fov_name"]),
                track_id=int(o["track_id"]),
                t=int(o["t"]),
                z=int(o["z"]),
                y=float(o["y"]),
                x=float(o["x"]),
                store_path=str(store_path),
                channel_name=str(channel_name),
                phate_x=float(coords[i, 0]),
                phate_y=float(coords[i, 1]),
            )
        )
    return targets


def _read_crop(target: CropTarget, crop_yx: tuple[int, int], z_extent: int) -> np.ndarray:
    """Read a single crop from the source OME-Zarr.

    Returns a 2D array — single slice if ``z_extent == 1``, else MIP over a
    ``z_extent``-deep stack centered at ``target.z``.
    """
    h, w = crop_yx
    y0 = max(0, int(target.y) - h // 2)
    x0 = max(0, int(target.x) - w // 2)
    with open_ome_zarr(target.store_path, mode="r", layout="hcs") as plate:
        pos = plate[target.fov_name]
        ch_idx = pos.channel_names.index(target.channel_name)
        arr = pos["0"]
        Y = arr.shape[-2]
        X = arr.shape[-1]
        y0 = min(y0, Y - h)
        x0 = min(x0, X - w)
        if z_extent <= 1:
            patch = arr[target.t, ch_idx, target.z, y0 : y0 + h, x0 : x0 + w]
            return np.asarray(patch)
        z_lo = max(0, target.z - z_extent // 2)
        z_hi = min(arr.shape[-3], z_lo + z_extent)
        stack = arr[target.t, ch_idx, z_lo:z_hi, y0 : y0 + h, x0 : x0 + w]
        return np.asarray(stack).max(axis=0)


def _plot_contact_sheet(
    targets: list[CropTarget],
    crop_yx: tuple[int, int],
    z_extent: int,
    cfg: dict,
    out_dir: Path,
    fmt: str,
    dpi: int,
) -> None:
    """Render a grid of crops with marker/perturbation/hpp/label headers."""
    cols = cfg["cols"]
    rows = (len(targets) + cols - 1) // cols
    panel = cfg["panel_size"]
    p_lo, p_hi = cfg["percentile_clip"]
    fig, axes = plt.subplots(rows, cols, figsize=(panel * cols, panel * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")

    for ax, ct in zip(axes.ravel(), targets):
        try:
            img = _read_crop(ct, crop_yx, z_extent)
        except Exception as e:  # noqa: BLE001 — surface but don't abort the figure
            click.echo(f"  [skip {ct.label}] {e}", err=True)
            continue
        lo, hi = np.percentile(img, [p_lo, p_hi])
        ax.imshow(img, cmap="gray", vmin=lo, vmax=hi)
        ax.set_title(
            f"#{ct.label}  {ct.marker}\n{ct.perturbation}  {ct.hpp:.0f}h",
            fontsize=7,
        )
    fig.tight_layout()
    _save(fig, out_dir / "panel_2_crops_contact_sheet", fmt, dpi)


def _write_crops_index(targets: list[CropTarget], out_dir: Path) -> None:
    df = pd.DataFrame(
        [
            {
                "label": t.label,
                "marker": t.marker,
                "perturbation": t.perturbation,
                "hours_post_perturbation": t.hpp,
                "experiment": t.experiment,
                "fov_name": t.fov_name,
                "track_id": t.track_id,
                "t": t.t,
                "z": t.z,
                "y": t.y,
                "x": t.x,
                "phate_x": t.phate_x,
                "phate_y": t.phate_y,
                "store_path": t.store_path,
                "channel_name": t.channel_name,
            }
            for t in targets
        ]
    )
    out = out_dir / "crops_index.csv"
    df.to_csv(out, index=False)
    click.echo(f"Wrote {out} ({len(df)} rows)")


# ---------------------------------------------------------------------------
# IO helpers
# ---------------------------------------------------------------------------


def _save(fig, base: Path, fmt: str, dpi: int) -> None:
    base.parent.mkdir(parents=True, exist_ok=True)
    formats = ["pdf", "png"] if fmt == "both" else [fmt]
    for ext in formats:
        out = base.with_suffix(f".{ext}")
        fig.savefig(out, dpi=dpi, bbox_inches="tight")
        click.echo(f"Wrote {out}")
    plt.close(fig)


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------


@click.command(context_settings={"help_option_names": ["-h", "--help"]})
@click.option("-c", "--config", required=True, type=click.Path(exists=True, dir_okay=False, path_type=str))
def main(config: str) -> None:
    """Generate Fig 2 panels (joint PHATE by marker, faceted-by-marker, crops)."""
    cfg = load_config(config)

    embeddings_dir = Path(cfg["embeddings_dir"])
    cell_index_path = Path(cfg["cell_index_path"])
    out_dir = Path(cfg["output_dir"])
    panels_dir = out_dir / "panels"
    data_dir = out_dir / "data"
    panels_dir.mkdir(parents=True, exist_ok=True)
    data_dir.mkdir(parents=True, exist_ok=True)

    adata = _load_concat(embeddings_dir)
    emb_key = cfg["embedding_key"]
    if emb_key not in adata.obsm:
        raise click.ClickException(f"obsm['{emb_key}'] missing — did reduce_combined run?")
    coords = np.asarray(adata.obsm[emb_key])

    sub_idx = _subsample_per_marker(
        adata,
        per_marker=int(cfg["display_subsample"]["per_marker"]),
        random_state=int(cfg["display_subsample"]["random_state"]),
    )
    sub_coords = coords[sub_idx]
    sub_obs = adata.obs.iloc[sub_idx].reset_index(drop=True)
    click.echo(
        "\n"
        + format_markdown_table(
            sub_obs["marker"].value_counts().reset_index().to_dict("records"),
            title="Display sample (cells per marker)",
        )
    )

    crop_targets: list[CropTarget] = []
    if cfg["crops"]["enabled"]:
        parquet_lookup = _resolve_parquet_lookup(cell_index_path)
        selected: list[dict] = []
        if cfg["crops"]["mode"] == "stratified":
            selected = _select_stratified(
                obs=adata.obs,
                coords=coords,
                cfg=cfg["crops"]["stratified"],
                markers=cfg["markers"],
                perturbations=cfg["perturbations"],
            )
        elif cfg["crops"]["mode"] == "nearest":
            selected = _select_nearest(
                obs=adata.obs, coords=coords, points=cfg["crops"]["nearest"]["points"]
            )
        else:
            raise click.ClickException(f"Unknown crops.mode={cfg['crops']['mode']!r}")
        crop_targets = _build_crop_targets(
            selected=selected, obs=adata.obs, coords=coords, parquet_lookup=parquet_lookup
        )
        click.echo(f"Selected {len(crop_targets)} crop targets")

    # Panel 2a
    _plot_panel_2a(
        coords=sub_coords,
        markers=sub_obs["marker"].to_numpy(),
        cfg={**cfg["panel_2a"], "annotate_phate_scatter": cfg["crops"]["contact_sheet"]["annotate_phate_scatter"]
             if cfg["crops"]["enabled"] else False},
        crop_targets=crop_targets,
        out_dir=panels_dir,
        fmt=cfg["format"],
        dpi=cfg["dpi"],
    )

    # Panel 2b
    _plot_panel_2b(
        coords=sub_coords,
        obs=sub_obs,
        cfg=cfg["panel_2b"],
        out_dir=panels_dir,
        fmt=cfg["format"],
        dpi=cfg["dpi"],
    )

    if crop_targets:
        _write_crops_index(crop_targets, data_dir)
        _plot_contact_sheet(
            targets=crop_targets,
            crop_yx=tuple(cfg["crops"]["crop_size_yx"]),
            z_extent=int(cfg["crops"]["z_extent"]),
            cfg=cfg["crops"]["contact_sheet"],
            out_dir=panels_dir,
            fmt=cfg["format"],
            dpi=cfg["dpi"],
        )


if __name__ == "__main__":
    main()
