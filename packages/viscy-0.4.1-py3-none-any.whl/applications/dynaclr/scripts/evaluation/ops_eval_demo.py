"""Phenotypic activity / distinctiveness mAP for OPS DynaCLR embeddings.

Runs after Nextflow ``-entry evaluation`` completes. Reads the per-experiment
zarrs, joins metadata from the source parquet on ``cell_id``, aggregates cells
to sgRNA-level (guide) mean embeddings, and computes:

1. Phenotypic activity mAP — positives = same gene / different sgRNA,
   negatives = NTC. Answers "does this gene KO produce a reproducible
   phenotype distinct from controls?"
2. Phenotypic distinctiveness mAP — for active perturbations only, positives
   same as above but negatives = any other gene. Answers "is this gene's
   phenotype distinct from other genes?"

Per-reporter variants split the same computations by the reporter/marker
channel, producing one mAP per reporter.

Reuses the existing implementation from
``/home/eduardo.hirata/repos/ops_model/experiments/models/dynaclr/evaluate/evaluate_map.py``
for now (Phase 1). Phase 2 will migrate that into viscy.

Usage
-----
python ops_eval_demo.py --eval-output-dir /path/to/evaluations/demo-v1
"""

from __future__ import annotations

import json
import sys
import time
from pathlib import Path

import anndata as ad
import click
import numpy as np
import pandas as pd

# Reuse the existing OPS eval functions. They are not importable as a package,
# so we add the directory to sys.path.
OPS_EVAL_DIR = Path("/home/eduardo.hirata/repos/ops_model/experiments/models/dynaclr/evaluate")
if str(OPS_EVAL_DIR) not in sys.path:
    sys.path.insert(0, str(OPS_EVAL_DIR))

from evaluate_map import (  # noqa: E402
    aggregate,
    aggregate_guides_per_reporter,
    phenotypic_activity,
    phenotypic_activity_per_reporter,
    phenotypic_distinctiveness,
    phenotypic_distinctiveness_per_reporter,
)


def _load_and_merge_metadata(eval_output_dir: Path, cell_index_parquet: Path) -> ad.AnnData:
    """Load all per-experiment zarrs + merge parquet metadata on cell_id.

    The per-experiment zarrs produced by ``split-embeddings`` contain cell-level
    embeddings but only a subset of obs columns. We join the full parquet on
    ``cell_id`` to restore ``sgRNA``, ``gene_name``, ``reporter``, ``perturbation``.
    """
    embeddings_dir = eval_output_dir / "embeddings"
    zarr_paths = sorted(embeddings_dir.glob("*.zarr"))
    if not zarr_paths:
        raise FileNotFoundError(f"No per-experiment zarrs in {embeddings_dir}")

    click.echo(f"Loading {len(zarr_paths)} per-experiment zarrs...")
    parts = [ad.read_zarr(p) for p in zarr_paths]
    adata = ad.concat(parts, join="outer")
    click.echo(f"  combined: {adata.shape}")

    # Join metadata from source parquet on cell_id. Parquet has full metadata;
    # zarr obs has whatever the predict step wrote plus obsm/X.
    click.echo(f"Loading labels from {cell_index_parquet.name}...")
    needed_cols = ["cell_id", "gene_name", "sgRNA", "perturbation", "reporter", "marker", "experiment"]
    labels = pd.read_parquet(cell_index_parquet, columns=needed_cols)
    # Parquet is one row per (cell, timepoint, channel). Collapse to per-cell.
    labels = labels.drop_duplicates("cell_id").set_index("cell_id")

    # adata.obs_names are cell_ids (stringified)
    obs = adata.obs.copy()
    obs.index = obs.index.astype(str)
    labels.index = labels.index.astype(str)
    for col in ["gene_name", "sgRNA", "perturbation", "reporter"]:
        if col not in obs.columns:
            obs[col] = labels.loc[obs.index, col].to_numpy()
    adata.obs = obs

    click.echo(f"  perturbations: {adata.obs['perturbation'].nunique()} (incl. NTC)")
    click.echo(f"  sgRNAs: {adata.obs['sgRNA'].nunique()}")
    click.echo(f"  reporters: {adata.obs['reporter'].nunique()}")
    return adata


@click.command(context_settings={"help_option_names": ["-h", "--help"]})
@click.option(
    "--eval-output-dir",
    type=click.Path(exists=True, path_type=Path, file_okay=False),
    required=True,
    help="Evaluation output directory containing embeddings/ from Nextflow run.",
)
@click.option(
    "--cell-index-parquet",
    type=click.Path(exists=True, path_type=Path),
    default=Path("/hpc/projects/organelle_phenotyping/models/collections/ops_1000genes_allmarkers_demo.parquet"),
    show_default=True,
    help="Source parquet used for predict (joined to restore sgRNA/gene_name metadata).",
)
def main(eval_output_dir: Path, cell_index_parquet: Path) -> None:
    """Compute phenotypic activity + distinctiveness mAP for an OPS eval run."""
    save_dir = eval_output_dir / "ops_map"
    save_dir.mkdir(parents=True, exist_ok=True)

    t_start = time.time()

    # 1. Load + merge metadata
    adata = _load_and_merge_metadata(eval_output_dir, cell_index_parquet)

    # 2. Aggregate cell-level embeddings to guide (sgRNA) level
    click.echo("\n--- Aggregating to sgRNA (guide) level ---")
    adata_guide = aggregate(adata, level="guide")
    click.echo(f"Guide-level: {adata_guide.shape}")
    adata_guide.write_zarr(save_dir / "adata_guide.zarr")

    # 3. Aggregate to (sgRNA x reporter) level for per-reporter mAP
    click.echo("\n--- Aggregating to (sgRNA x reporter) level ---")
    adata_guide_pr = aggregate_guides_per_reporter(adata)
    click.echo(f"(sgRNA x reporter)-level: {adata_guide_pr.shape}")
    adata_guide_pr.write_zarr(save_dir / "adata_guide_per_reporter.zarr")

    # 4. Phenotypic activity (guide-level)
    click.echo("\n--- Phenotypic activity (guide-level) ---")
    activity_map = phenotypic_activity(adata_guide)
    activity_map.to_csv(save_dir / "phenotypic_activity.csv", index=False)
    n_active = int(activity_map["below_corrected_p"].sum())
    click.echo(f"  {n_active} / {len(activity_map)} perturbations active (corrected p < 0.05)")

    # 5. Phenotypic distinctiveness (active only)
    click.echo("\n--- Phenotypic distinctiveness (active only) ---")
    distinct_map = phenotypic_distinctiveness(adata_guide, activity_map)
    distinct_map.to_csv(save_dir / "phenotypic_distinctiveness.csv", index=False)

    # 6. Per-reporter variants
    click.echo("\n--- Per-reporter phenotypic activity ---")
    activity_pr = phenotypic_activity_per_reporter(adata_guide_pr)
    activity_pr.to_csv(save_dir / "phenotypic_activity_per_reporter.csv", index=False)

    click.echo("\n--- Per-reporter phenotypic distinctiveness ---")
    distinct_pr = phenotypic_distinctiveness_per_reporter(adata_guide_pr, activity_pr)
    distinct_pr.to_csv(save_dir / "phenotypic_distinctiveness_per_reporter.csv", index=False)

    # 7. Summary
    diagnostics = {
        "n_cells": int(adata.shape[0]),
        "n_features": int(adata.shape[1]),
        "n_genes": int(adata.obs["gene_name"].nunique()),
        "n_sgRNAs": int(adata.obs["sgRNA"].nunique()),
        "n_reporters": int(adata.obs["reporter"].nunique()),
        "n_active_perturbations": n_active,
        "median_activity_map": float(activity_map["mean_average_precision"].median()),
        "median_distinctiveness_map": float(distinct_map["mean_average_precision"].median())
        if len(distinct_map)
        else float("nan"),
    }
    with open(save_dir / "diagnostics.json", "w") as f:
        json.dump(diagnostics, f, indent=2)

    click.echo(f"\nSaved to {save_dir}:")
    click.echo("  - phenotypic_activity.csv")
    click.echo("  - phenotypic_distinctiveness.csv")
    click.echo("  - phenotypic_activity_per_reporter.csv")
    click.echo("  - phenotypic_distinctiveness_per_reporter.csv")
    click.echo("  - adata_guide.zarr, adata_guide_per_reporter.zarr")
    click.echo("  - diagnostics.json")
    click.echo(f"\nDone in {(time.time() - t_start) / 60:.1f} min")
    click.echo(f"\nSummary:")
    for k, v in diagnostics.items():
        click.echo(f"  {k}: {v}")


if __name__ == "__main__":
    main()
