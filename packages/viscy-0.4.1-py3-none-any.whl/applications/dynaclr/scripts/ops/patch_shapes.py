"""Patch Y_shape/X_shape into ops_1000genes_15markers.parquet.

``convert_ops_parquet`` leaves these columns as NaN because the OPS
input doesn't carry them. The DynaCLR index expects them populated when
present — it takes the first-branch shortcut and propagates NaN, which
drops every row in ``_clamp_borders``.

This script reads one-time the zarr store for each unique (store_path,
well, fov) and writes Y_shape/X_shape back to the parquet in chunks.

Run in the viscy venv.
"""

from pathlib import Path

import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq
from iohub import open_ome_zarr

from viscy_data.cell_index import CELL_INDEX_SCHEMA

PARQUET = Path(
    "/home/eduardo.hirata/repos/viscy/applications/dynaclr/configs/cell_index/ops_1000genes_15markers.parquet"
)
TMP_PARQUET = PARQUET.with_name(PARQUET.stem + ".patched.parquet")
CHUNK_ROWS = 2_000_000


def build_shape_lookup(df: pd.DataFrame) -> dict[tuple[str, str, str], tuple[int, int]]:
    """Open each unique store once, read per-FOV image dimensions."""
    keys = df[["store_path", "well", "fov"]].drop_duplicates()
    lookup: dict[tuple[str, str, str], tuple[int, int]] = {}
    store_cache: dict[str, object] = {}
    for _, row in keys.iterrows():
        sp, well, fov = row["store_path"], row["well"], row["fov"]
        if sp not in store_cache:
            store_cache[sp] = open_ome_zarr(sp, mode="r")
        plate = store_cache[sp]
        position = plate[f"{well}/{fov}"]
        img = position["0"]
        lookup[(sp, well, fov)] = (img.height, img.width)
        print(f"  {sp.split('/')[-3]} {well}/{fov}: {img.height}×{img.width}")
    return lookup


def main() -> None:
    print(f"# Patching shapes into {PARQUET.name}\n")

    print("## Scanning unique FOVs")
    # Read only the keys first
    df_keys = pd.read_parquet(PARQUET, columns=["store_path", "well", "fov"])
    shape_lookup = build_shape_lookup(df_keys)
    print(f"\n- unique FOVs: {len(shape_lookup)}")

    print(f"\n## Rewriting parquet in chunks of {CHUNK_ROWS:,}")
    reader = pq.ParquetFile(PARQUET)
    writer = pq.ParquetWriter(str(TMP_PARQUET), CELL_INDEX_SCHEMA)
    total = 0
    for batch in reader.iter_batches(batch_size=CHUNK_ROWS):
        chunk = batch.to_pandas()
        sp = chunk["store_path"].to_numpy()
        well = chunk["well"].to_numpy()
        fov = chunk["fov"].to_numpy()
        heights = [shape_lookup[(sp[i], well[i], fov[i])][0] for i in range(len(chunk))]
        widths = [shape_lookup[(sp[i], well[i], fov[i])][1] for i in range(len(chunk))]
        chunk["Y_shape"] = heights
        chunk["X_shape"] = widths
        table = pa.Table.from_pandas(chunk, schema=CELL_INDEX_SCHEMA, preserve_index=False)
        writer.write_table(table)
        total += len(chunk)
        print(f"  +{len(chunk):,} rows (total {total:,})")
    writer.close()

    # Atomic swap
    PARQUET.unlink()
    TMP_PARQUET.rename(PARQUET)
    print(f"\nDone. Rewrote {total:,} rows to {PARQUET}")


if __name__ == "__main__":
    main()
