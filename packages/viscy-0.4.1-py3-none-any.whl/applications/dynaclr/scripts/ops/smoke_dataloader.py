"""Smoke test the MultiExperimentDataModule with the Option 1 SupCon config.

Verifies:
1. The new parquet loads correctly (no schema mismatch)
2. ``batch_group_by="marker"`` produces single-marker batches
3. ``positive_match_columns=["gene_name"]`` finds valid positives per anchor
4. One training batch actually materializes (zarr reads succeed)

Run: conda run -n viscy python applications/dynaclr/scripts/ops/smoke_dataloader.py
or:  .venv/bin/python applications/dynaclr/scripts/ops/smoke_dataloader.py
"""

import time
from pathlib import Path

from dynaclr.data.datamodule import MultiExperimentDataModule
from viscy_transforms import (
    BatchedRandAdjustContrastd,
    BatchedRandAffined,
    BatchedRandFlipd,
    BatchedRandGaussianNoised,
    BatchedRandGaussianSmoothd,
    BatchedRandScaleIntensityd,
    BatchedScaleIntensityRangePercentilesd,
)

PARQUET = Path(
    "/home/eduardo.hirata/repos/viscy/applications/dynaclr/configs/cell_index/ops_1000genes_15markers.parquet"
)


def main() -> None:
    print("# Smoke test: Option 1 SupCon dataloader\n")

    normalizations = [
        BatchedScaleIntensityRangePercentilesd(keys=["channel_0"], lower=1, upper=99, b_min=0.0, b_max=1.0, clip=True)
    ]
    augmentations = [
        BatchedRandAffined(
            keys=["channel_0"],
            prob=0.8,
            scale_range=[[1.0, 1.0], [0.9, 1.1], [0.9, 1.1]],
            rotate_range=[3.14, 0.0, 0.0],
            shear_range=[0.0] * 6,
        ),
        BatchedRandFlipd(keys=["channel_0"], spatial_axes=[1, 2], prob=0.5),
        BatchedRandAdjustContrastd(keys=["channel_0"], prob=0.5, gamma=(0.8, 1.2)),
        BatchedRandScaleIntensityd(keys=["channel_0"], prob=0.5, factors=0.5),
        BatchedRandGaussianSmoothd(
            keys=["channel_0"], prob=0.5, sigma_x=[0.2, 0.5], sigma_y=[0.2, 0.5], sigma_z=[0.0, 0.0]
        ),
        BatchedRandGaussianNoised(keys=["channel_0"], prob=0.5, mean=0.0, std=0.08),
    ]

    dm = MultiExperimentDataModule(
        cell_index_path=str(PARQUET),
        z_window=1,
        yx_patch_size=(224, 224),
        final_yx_patch_size=(128, 128),
        channels_per_sample=1,
        batch_size=64,  # small for smoke
        num_workers=2,
        batch_group_by="marker",
        stratify_by=None,
        positive_cell_source="lookup",
        positive_match_columns=["gene_name", "marker"],
        split_ratio=0.8,
        seed=0,
        shuffle_val=False,
        normalizations=normalizations,
        augmentations=augmentations,
        label_columns={"gene_label": "gene_name"},
    )

    print("## Setup\n")
    t0 = time.time()
    dm.setup(stage="fit")
    print(f"- setup elapsed: {time.time() - t0:.1f}s")

    anchors = dm.train_dataset.index.valid_anchors
    print(f"- train anchors: {len(anchors):,}")
    print(f"- train markers: {sorted(anchors['marker'].unique())}")
    print(f"- train experiments: {anchors['experiment'].nunique()}")
    print(f"- train genes: {anchors['gene_name'].nunique()}")

    print("\n## First batch\n")
    loader = dm.train_dataloader()
    t0 = time.time()
    batch = next(iter(loader))
    dt = time.time() - t0
    print(f"- batch fetched in {dt:.1f}s")
    if isinstance(batch, dict):
        for k, v in batch.items():
            if hasattr(v, "shape"):
                print(f"- batch['{k}']: shape={tuple(v.shape)}, dtype={v.dtype}")
            else:
                print(f"- batch['{k}']: type={type(v).__name__}")
        # Single-marker check via anchor_meta
        meta = batch.get("anchor_meta")
        if meta is not None:
            markers = [m.get("marker") for m in meta]
            genes = [m.get("gene_name") for m in meta]
            exps = [m.get("experiment") for m in meta]
            print(f"\n- anchor markers in batch: {sorted(set(markers))}")
            print(f"- unique genes in batch: {len(set(genes))} / {len(genes)} anchors")
            print(f"- unique experiments in batch: {len(set(exps))}")
            # SupCon positives per anchor:
            pmeta = batch.get("positive_meta")
            if pmeta is not None:
                same_gene = sum(1 for a, p in zip(meta, pmeta) if a.get("gene_name") == p.get("gene_name"))
                print(f"- positive match on gene_name: {same_gene}/{len(meta)} anchors")
    else:
        print(f"- batch type: {type(batch).__name__}")

    print("\n✅ Dataloader works end-to-end.")


if __name__ == "__main__":
    main()
