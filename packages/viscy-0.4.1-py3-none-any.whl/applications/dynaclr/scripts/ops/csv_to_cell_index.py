"""Convert the OPS labels CSV to the canonical DynaCLR cell_index parquet.

Inline version of ``convert_ops_parquet`` that writes in row-group chunks
to avoid the 2GB-per-column limit of pyarrow's ``string`` type when the
total string payload exceeds 2GB (e.g. a 56M-row parquet with long
``store_path`` repeats).

Run in the viscy venv.
"""

from pathlib import Path

import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq
from iohub import open_ome_zarr

from viscy_data.cell_index import CELL_INDEX_SCHEMA, _parse_bbox_to_centroid

LABELS_CSV = Path(
    "/home/eduardo.hirata/repos/viscy/applications/dynaclr/configs/cell_index/labels_1000genes_allmarkers.csv"
)
OUTPUT_PARQUET = Path("/hpc/projects/organelle_phenotyping/models/collections/ops_1000genes_allmarkers.parquet")
STORE_ROOT = "/hpc/projects/icd.fast.ops"
STORE_SUFFIX = "3-assembly/phenotyping_v3.zarr"
CHUNK_ROWS = 2_000_000


def build_shape_lookup(csv_path: Path) -> dict[tuple[str, str, str], tuple[int, int]]:
    """Open each unique zarr FOV once to read (height, width)."""
    print("## Scanning unique FOVs for Y_shape/X_shape")
    keys = pd.read_csv(csv_path, usecols=["store_key", "well"], low_memory=False).drop_duplicates()
    lookup: dict[tuple[str, str, str], tuple[int, int]] = {}
    store_cache: dict[str, object] = {}
    for _, row in keys.iterrows():
        sk, well = row["store_key"], row["well"]
        store_path = f"{STORE_ROOT}/{sk}/{STORE_SUFFIX}"
        fov = well.rsplit("/", 1)[1]
        well_only = well.rsplit("/", 1)[0]
        if store_path not in store_cache:
            store_cache[store_path] = open_ome_zarr(store_path, mode="r")
        plate = store_cache[store_path]
        img = plate[f"{well_only}/{fov}"]["0"]
        lookup[(store_path, well_only, fov)] = (img.height, img.width)
        print(f"  {sk} {well}: {img.height}×{img.width}")
    return lookup


def ops_row_to_cell_index(
    df: pd.DataFrame,
    shape_lookup: dict[tuple[str, str, str], tuple[int, int]],
) -> pd.DataFrame:
    """Mirror ``convert_ops_parquet`` transforms on a DataFrame chunk."""
    out = pd.DataFrame()
    out["experiment"] = df["store_key"]
    out["store_path"] = df["store_key"].apply(lambda k: f"{STORE_ROOT}/{k}/{STORE_SUFFIX}")
    out["fov"] = df["well"].apply(lambda w: w.rsplit("/", 1)[1] if "/" in w else w)
    out["well"] = df["well"].apply(lambda w: w.rsplit("/", 1)[0])

    centroids = df["bbox"].apply(_parse_bbox_to_centroid)
    out["y"] = centroids.apply(lambda c: c[0]).astype("float32")
    out["x"] = centroids.apply(lambda c: c[1]).astype("float32")
    out["z"] = pd.array([0] * len(df), dtype="int16")

    out["channel_name"] = df["channel"] if "channel" in df.columns else ""
    out["marker"] = df["reporter"] if "reporter" in df.columns else out["channel_name"]
    out["organelle"] = None

    out["gene_name"] = df["gene_name"].fillna("NTC") if "gene_name" in df.columns else None
    out["reporter"] = df["reporter"] if "reporter" in df.columns else None
    out["sgRNA"] = df["sgRNA"] if "sgRNA" in df.columns else None
    out["perturbation"] = out["gene_name"] if "gene_name" in df.columns else "unknown"

    out["t"] = pd.array([0] * len(df), dtype="Int32")
    id_series = df["total_index"].astype(str)
    out["track_id"] = df["total_index"].astype("Int32")
    out["cell_id"] = df["store_key"].astype(str) + "_" + id_series
    out["global_track_id"] = out["cell_id"]
    out["lineage_id"] = out["cell_id"]
    out["parent_track_id"] = pd.array([-1] * len(df), dtype="Int32")
    out["hours_post_perturbation"] = pd.array([0.0] * len(df), dtype="float32")

    out["tracks_path"] = ""
    out["interval_minutes"] = pd.array([0.0] * len(df), dtype="float32")
    out["microscope"] = ""
    out["pixel_size_xy_um"] = None
    out["pixel_size_z_um"] = None

    # Populate Y_shape/X_shape from the per-FOV lookup (avoids zarr reopen at load time)
    heights = [shape_lookup[(sp, well, fov)][0] for sp, well, fov in zip(out["store_path"], out["well"], out["fov"])]
    widths = [shape_lookup[(sp, well, fov)][1] for sp, well, fov in zip(out["store_path"], out["well"], out["fov"])]
    out["Y_shape"] = heights
    out["X_shape"] = widths

    for field in CELL_INDEX_SCHEMA:
        if field.name not in out.columns:
            out[field.name] = None

    return out


def main() -> None:
    print(f"# Convert → {OUTPUT_PARQUET}\n")
    shape_lookup = build_shape_lookup(LABELS_CSV)
    print(f"\nFOV shape lookup: {len(shape_lookup)} unique FOVs\n")
    print(f"Streaming CSV in chunks of {CHUNK_ROWS:,} rows")

    reader = pd.read_csv(LABELS_CSV, low_memory=False, chunksize=CHUNK_ROWS)
    writer: pq.ParquetWriter | None = None
    total = 0
    for i, chunk in enumerate(reader):
        out_chunk = ops_row_to_cell_index(chunk, shape_lookup)
        table = pa.Table.from_pandas(out_chunk, schema=CELL_INDEX_SCHEMA, preserve_index=False)
        if writer is None:
            writer = pq.ParquetWriter(str(OUTPUT_PARQUET), CELL_INDEX_SCHEMA)
        writer.write_table(table)
        total += len(out_chunk)
        print(f"  chunk {i}: +{len(out_chunk):,} rows (total: {total:,})")

    if writer is not None:
        writer.close()

    print("\n## Summary\n")
    print(f"- **Total rows:** {total:,}")
    print(f"- **Output:** {OUTPUT_PARQUET}")


if __name__ == "__main__":
    main()
