"""Build the 1000-gene × 15-marker labels CSV for OPS DynaCLR training.

Reads the canonical 53 DinoV3 OPS experiments, concatenates per-well
``*_linked_pheno_iss.csv`` tables with small-bbox QC, keeps ALL ~1000
library genes (no gene-list subsetting), expands each cell row into one
row per ``out_channel``, maps channel → reporter via the pre-resolved
``dataset_inventory.csv``, and keeps only the 15 compartment-balanced
reporters (plus Phase).

The output CSV is the input to ``dynaclr convert-ops-parquet``.

Notes
-----
- Run in the ``ops-model`` conda env (needs ``ops_model`` for ``OpsPaths``
  and ``filter_small_bboxes``; does NOT need ``ops_utils``/``FeatureMetadata``).
- Channel-presence validation against zarr ``.zattrs`` is inlined from
  ``validate_n_filter_csv.py`` — rows whose channel is absent from a given
  (experiment, well) zarr are dropped.
"""

import sys
from pathlib import Path

import pandas as pd
import yaml
import zarr

sys.path.insert(0, "/home/eduardo.hirata/repos/ops_model/src")
from ops_model.data.paths import OpsPaths  # noqa: E402
from ops_model.data.qc.qc_labels import filter_small_bboxes  # noqa: E402

CONFIG_LIST_PATH = Path("/home/eduardo.hirata/repos/viscy/applications/dynaclr/configs/ops/dino_configs_all.txt")
INVENTORY_CSV = Path("/home/eduardo.hirata/repos/ops_model/.planning/output/dataset_inventory.csv")
OUTPUT_CSV = Path(
    "/home/eduardo.hirata/repos/viscy/applications/dynaclr/configs/cell_index/labels_1000genes_allmarkers.csv"
)

KEEP_REPORTERS = {
    # Label-free — hardcoded for the Phase2D channel (present in every experiment)
    "Phase",
    # Every fluorescent reporter in the canonical 53-experiment pipeline (39 markers,
    # excluding bookkeeping labels "no_label" and "Phase2D_only" from the inventory).
    "5xUPRE",
    "ATG101",
    "ATP1B3",
    "BODIPY_live_cell_dye",
    "CLTA",
    "COP-II",
    "COPE",
    "CellEvent-Caspase_live-cell_dye",
    "CellROX_live-cell_dye",
    "ChromaLIVE_488_excitation",
    "ChromaLIVE_561_excitation",
    "EEA1",
    "FBL",
    "FastAct_SPY555_Live_Cell_Dye",
    "FeRhoNox_live-cell_dye",
    "G3BP1",
    "H2B_(TOMM20-combo)",
    "HSPA1B",
    "LAMP1",
    "LysoTracker_live-cell_dye",
    "MAP1LC3B",
    "MAP4",
    "MKI67",
    "NCLN",
    "NPM3",
    "PLIN2",
    "PSMB7",
    "Peroxi_SPY650_live_cell_dye",
    "RAB7A",
    "SEC61B",
    "SLC3A2",
    "SRRM2",
    "TOMM20",
    "TOMM70A",
    "VAMP3",
    "VAPA",
    "VIM",
    "VPS35",
    "pHrodo-dextran_Live_Cell_Dye",
}

BBOX_THRESHOLD = 5


def load_config_list(path: Path) -> list[Path]:
    """Parse the canonical DinoV3 config list.

    Parameters
    ----------
    path : Path
        Path to ``dino_configs_all.txt``. Lines starting with ``#`` and
        blank lines are ignored.
    """
    with open(path) as f:
        lines = [line.strip() for line in f if line.strip() and not line.startswith("#")]
    return [Path(line) for line in lines]


def load_channel_reporter_map(inventory_csv: Path) -> dict[tuple[str, str], str]:
    """Build ``(full_experiment_key, channel_name) -> reporter`` from the inventory CSV.

    Uses only rows where ``in_dinov3_pipeline is True``.
    """
    inv = pd.read_csv(inventory_csv)
    pipe = inv[inv["in_dinov3_pipeline"]]
    mapping: dict[tuple[str, str], str] = {}
    for _, row in pipe.iterrows():
        mapping[(row["full_experiment_key"], row["channel_name"])] = row["reporter"]
    return mapping


def load_zarr_channels(zarr_path: Path, well: str) -> set[str]:
    """Return the set of channel labels available in a given zarr well."""
    try:
        store = zarr.open_group(str(zarr_path), mode="r")
        attrs = store[well].attrs.asdict()
        return {c["label"] for c in attrs["ome"]["omero"]["channels"]}
    except (KeyError, TypeError, FileNotFoundError):
        return set()


def build_labels() -> pd.DataFrame:
    """Iterate canonical experiments + wells, concat labels, expand by channel."""
    config_paths = load_config_list(CONFIG_LIST_PATH)
    channel_to_reporter = load_channel_reporter_map(INVENTORY_CSV)
    print(f"## Config\n\n- **Experiments:** {len(config_paths)}")
    print(f"- **Reporter-map rows:** {len(channel_to_reporter)}")

    labels: list[pd.DataFrame] = []
    missing_map: list[tuple[str, str]] = []
    bad_channels: list[tuple[str, str, str]] = []
    row_totals = {"read": 0, "after_bbox": 0, "after_reporter_filter": 0, "after_zarr_validate": 0}

    for config_path in config_paths:
        with open(config_path) as f:
            config = yaml.safe_load(f)
        experiments = config["data_manager"]["experiments"]
        out_channels = config["data_manager"]["out_channels"]

        for exp_name, wells in experiments.items():
            for well in wells:
                link_path = OpsPaths(exp_name, well=well).links["training"]
                if not link_path.exists():
                    print(f"  MISSING link CSV: {link_path}")
                    continue

                df = pd.read_csv(link_path, low_memory=False)
                row_totals["read"] += len(df)
                df["gene_name"] = df["gene_name"].fillna("NTC")
                df = df.dropna(subset=["segmentation_id"])
                df, _ = filter_small_bboxes(df, threshold=BBOX_THRESHOLD)
                row_totals["after_bbox"] += len(df)

                df["store_key"] = exp_name
                df["well"] = well

                zarr_channels = load_zarr_channels(OpsPaths(exp_name).stores["phenotyping_v3"], well)

                for channel in out_channels:
                    if channel == "Phase2D":
                        reporter = "Phase"
                    elif channel == "Focus3D":
                        continue
                    else:
                        key = (exp_name, channel)
                        if key not in channel_to_reporter:
                            missing_map.append(key)
                            continue
                        reporter = channel_to_reporter[key]
                    if reporter not in KEEP_REPORTERS:
                        continue
                    if channel not in zarr_channels:
                        bad_channels.append((exp_name, well, channel))
                        continue

                    sub = df.copy()
                    sub["channel"] = channel
                    sub["reporter"] = reporter
                    labels.append(sub)
                    row_totals["after_zarr_validate"] += len(sub)

                print(
                    f"  {exp_name} {well}: {len(df):,} cells × "
                    f"{sum(1 for ch in out_channels if channel_to_reporter.get((exp_name, ch)) in KEEP_REPORTERS)} "
                    "kept channels"
                )

    if missing_map:
        uniq = set(missing_map)
        print(f"\n## Missing channel→reporter entries ({len(uniq)} unique)")
        for key in sorted(uniq):
            print(f"  - {key}")

    if bad_channels:
        uniq = set(bad_channels)
        print(f"\n## Channels absent from zarr ({len(uniq)} unique)")
        for key in sorted(uniq):
            print(f"  - {key}")

    print("\n## Row counts\n")
    for stage, n in row_totals.items():
        print(f"- **{stage}:** {n:,}")

    labels_df = pd.concat(labels, ignore_index=True)
    labels_df["total_index"] = range(len(labels_df))
    return labels_df


def main() -> None:
    print("# Build 1000-gene × 15-marker labels CSV\n")
    labels_df = build_labels()

    print("\n## Summary\n")
    print(f"- **Final rows:** {len(labels_df):,}")
    print(f"- **Unique genes:** {labels_df['gene_name'].nunique():,}")
    print(f"- **Unique reporters:** {labels_df['reporter'].nunique()}")
    print(f"- **Reporters:** {sorted(labels_df['reporter'].unique())}")
    print(f"- **Unique experiments:** {labels_df['store_key'].nunique()}")
    print(f"- **Output:** {OUTPUT_CSV}")

    OUTPUT_CSV.parent.mkdir(parents=True, exist_ok=True)
    labels_df.to_csv(OUTPUT_CSV, index=False)
    print("\nDone.")


if __name__ == "__main__":
    main()
