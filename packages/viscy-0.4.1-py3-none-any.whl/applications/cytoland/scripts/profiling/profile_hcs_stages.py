"""Profile per-stage breakdown for ``HCSDataModule`` (cytoland VSCyto pipeline).

Isolates the cost of each step in a single training batch so we can tell
where the bottleneck is: network I/O, per-sample CPU transforms,
host->device transfer, or GPU augmentations.

Stages timed (per batch, in order):

1. ``Worker (read+cpu)`` — DataLoader yields a collated batch. This
   includes the per-sample zarr ``oindex`` read, ``RandWeightedCropd``,
   and any ``normalizations`` declared in the YAML
   (``HCSDataModule.normalizations`` runs on CPU inside ``__getitem__``).
2. ``H2D``               — ``batch.to(device, non_blocking=True)`` for
   ``source`` and ``target`` tensors.
3. ``GPU augmentations`` — ``on_after_batch_transfer`` (``BatchedRandAffined``,
   ``BatchedCenterSpatialCropd``, intensity perturbations, etc.).

The script does NOT use ``Trainer.fit``; it constructs ``HCSDataModule``
directly so the only thing in the loop is what we want to measure.

Usage
-----
    uv run python applications/cytoland/scripts/profiling/profile_hcs_stages.py

By default profiles **D1 only** (single-plate, no ``CombinedDataModule``).
Override ``--plate`` / ``--num-workers`` / ``--batch-size`` from the CLI.

Outputs a markdown table to stdout with median, p95, and per-batch raw
timings for each stage. Iteration counts: 5 warmup + 20 measured batches.
"""

from __future__ import annotations

import argparse
import statistics
import time

import torch
import yaml

from monai.transforms import Compose

from viscy_data.hcs import HCSDataModule
from viscy_transforms import (
    BatchedCenterSpatialCropd,
    BatchedRandAdjustContrastd,
    BatchedRandAffined,
    BatchedRandGaussianNoised,
    BatchedRandGaussianSmoothd,
    BatchedRandScaleIntensityd,
    NormalizeSampled,
)
from viscy_transforms._monai_wrappers import RandWeightedCropd


# ---------------------------------------------------------------------------
# Plate registry — keyed by the labels D1/D2/D3 used elsewhere in this repo
# ---------------------------------------------------------------------------
PLATES = {
    "d1": {
        "data_path": (
            "/hpc/projects/virtual_staining/training/a549/2026_05_infected_cell/"
            "zarrv3/2026_01_29_A549_H2B_CAAX_DAPI_DENV_ZIKV.zarr"
        ),
        "source_channel": "Phase3D",
        "target_channel": ["DAPI_Density3D", "TXR_Density3D"],
        "weight_key": "DAPI_Density3D",
        "fluor_norm": ["DAPI_Density3D", "TXR_Density3D"],
    },
    "d2": {
        "data_path": (
            "/hpc/projects/virtual_staining/training/a549/2026_05_infected_cell/"
            "zarrv3/2026_03_10_A549_H2B_CAXX_DAPI_DENV_ZIKV.zarr"
        ),
        "source_channel": "Phase3D",
        "target_channel": ["DAPI_Density3D", "TXR_Density3D"],
        "weight_key": "DAPI_Density3D",
        "fluor_norm": ["DAPI_Density3D", "TXR_Density3D"],
    },
    "d3": {
        "data_path": (
            "/hpc/projects/virtual_staining/training/a549/2026_05_infected_cell/"
            "zarrv3/2026_03_26_A549_CAAX_H2B_DENV_ZIKV.zarr"
        ),
        "source_channel": "Phase3D",
        "target_channel": [
            "raw mCherry EX561 EM600-37",
            "raw Cy5 EX639 EM698-70",
        ],
        "weight_key": "raw mCherry EX561 EM600-37",
        "fluor_norm": [
            "raw mCherry EX561 EM600-37",
            "raw Cy5 EX639 EM698-70",
        ],
    },
}


def _build_datamodule(plate_key: str, batch_size: int, num_workers: int) -> HCSDataModule:
    cfg = PLATES[plate_key]
    augmentations = [
        RandWeightedCropd(
            keys=[cfg["source_channel"], *cfg["target_channel"]],
            w_key=cfg["weight_key"],
            spatial_size=[20, 600, 600],
            num_samples=4,
        ),
    ]
    normalizations = [
        NormalizeSampled(
            keys=[cfg["source_channel"]],
            level="timepoint_statistics",
            subtrahend="mean",
            divisor="std",
        ),
        NormalizeSampled(
            keys=cfg["fluor_norm"],
            level="timepoint_statistics",
            subtrahend="median",
            divisor="iqr",
        ),
    ]
    gpu_augmentations = [
        BatchedRandAffined(
            keys=["source", "target"],
            prob=0.8,
            rotate_range=[3.14, 0, 0],
            shear_range=[0.0, 0.05, 0.05],
            scale_range=[[0.7, 1.3], [0.5, 1.5], [0.5, 1.5]],
        ),
        BatchedCenterSpatialCropd(keys=["source", "target"], roi_size=[15, 384, 384]),
        BatchedRandAdjustContrastd(keys=["source"], prob=0.5, gamma=(0.8, 1.2)),
        BatchedRandScaleIntensityd(keys=["source"], prob=0.5, factors=0.5),
        BatchedRandGaussianNoised(keys=["source"], prob=0.5, mean=0.0, std=0.3),
        BatchedRandGaussianSmoothd(
            keys=["source"],
            prob=0.5,
            sigma_x=(0.25, 0.75),
            sigma_y=(0.25, 0.75),
            sigma_z=(0.25, 0.75),
        ),
    ]

    dm = HCSDataModule(
        data_path=cfg["data_path"],
        source_channel=cfg["source_channel"],
        target_channel=cfg["target_channel"],
        z_window_size=20,
        split_ratio=0.8,
        batch_size=batch_size,
        num_workers=num_workers,
        persistent_workers=num_workers > 0,
        mmap_preload=False,
        yx_patch_size=[384, 384],
        augmentations=augmentations,
        normalizations=normalizations,
        gpu_augmentations=gpu_augmentations,
    )
    dm.setup("fit")
    return dm


def _move_to_device(batch: dict, device: torch.device) -> dict:
    out = {}
    for k, v in batch.items():
        if isinstance(v, torch.Tensor):
            out[k] = v.to(device, non_blocking=True)
        else:
            out[k] = v
    return out


def _summary(label: str, samples_ms: list[float]) -> dict:
    if not samples_ms:
        return {"stage": label, "median_ms": 0.0, "p95_ms": 0.0, "min_ms": 0.0, "max_ms": 0.0}
    sorted_s = sorted(samples_ms)
    p95 = sorted_s[int(0.95 * (len(sorted_s) - 1))]
    return {
        "stage": label,
        "median_ms": statistics.median(samples_ms),
        "p95_ms": p95,
        "min_ms": min(samples_ms),
        "max_ms": max(samples_ms),
    }


def _print_markdown(rows: list[dict], header: str) -> None:
    print(f"\n## {header}\n")
    print("| Stage | median (ms) | p95 (ms) | min (ms) | max (ms) |")
    print("|---|---:|---:|---:|---:|")
    for r in rows:
        print(
            f"| {r['stage']} | {r['median_ms']:.1f} | {r['p95_ms']:.1f} | "
            f"{r['min_ms']:.1f} | {r['max_ms']:.1f} |"
        )


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--plate", choices=list(PLATES.keys()), default="d1")
    parser.add_argument("--batch-size", type=int, default=8, help="Per-loader batch size (post-RandWeightedCropd 4x).")
    parser.add_argument("--num-workers", type=int, default=4)
    parser.add_argument("--warmup", type=int, default=5)
    parser.add_argument("--measured", type=int, default=20)
    parser.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    args = parser.parse_args()

    device = torch.device(args.device)
    print(yaml.safe_dump({
        "plate": args.plate,
        "batch_size": args.batch_size,
        "num_workers": args.num_workers,
        "warmup": args.warmup,
        "measured": args.measured,
        "device": str(device),
        "data_path": PLATES[args.plate]["data_path"],
    }))

    dm = _build_datamodule(args.plate, args.batch_size, args.num_workers)
    loader = dm.train_dataloader()

    worker_ms: list[float] = []
    h2d_ms: list[float] = []
    gpu_aug_ms: list[float] = []

    use_cuda = device.type == "cuda"
    it = iter(loader)

    total_iters = args.warmup + args.measured
    for i in range(total_iters):
        # 1) Worker (read + per-sample CPU transforms + collate)
        t0 = time.perf_counter()
        batch = next(it)
        worker_dt = (time.perf_counter() - t0) * 1000

        # 2) Host -> Device
        if use_cuda:
            torch.cuda.synchronize()
        t1 = time.perf_counter()
        batch_on_device = _move_to_device(batch, device)
        if use_cuda:
            torch.cuda.synchronize()
        h2d_dt = (time.perf_counter() - t1) * 1000

        # 3) on_after_batch_transfer (GPU augmentations)
        if use_cuda:
            torch.cuda.synchronize()
        t2 = time.perf_counter()
        if dm._gpu_augmentations is not None:
            batch_on_device = dm._gpu_augmentations(batch_on_device)
        if use_cuda:
            torch.cuda.synchronize()
        gpu_dt = (time.perf_counter() - t2) * 1000

        if i >= args.warmup:
            worker_ms.append(worker_dt)
            h2d_ms.append(h2d_dt)
            gpu_aug_ms.append(gpu_dt)
            print(
                f"  iter {i - args.warmup + 1}/{args.measured}: "
                f"worker={worker_dt:.1f}ms h2d={h2d_dt:.1f}ms gpu_aug={gpu_dt:.1f}ms",
                flush=True,
            )
        else:
            print(f"  warmup {i + 1}/{args.warmup} (worker={worker_dt:.1f}ms)", flush=True)

    rows = [
        _summary("Worker (read + CPU norm + RandWeightedCrop)", worker_ms),
        _summary("Host -> Device", h2d_ms),
        _summary("GPU augmentations", gpu_aug_ms),
    ]
    end_to_end_ms = [a + b + c for a, b, c in zip(worker_ms, h2d_ms, gpu_aug_ms, strict=True)]
    rows.append(_summary("End-to-end (sum)", end_to_end_ms))

    _print_markdown(
        rows,
        f"HCSDataModule profile — plate={args.plate} "
        f"batch_size={args.batch_size} workers={args.num_workers}",
    )

    if worker_ms:
        worker_share = statistics.median(worker_ms) / statistics.median(end_to_end_ms) * 100
        h2d_share = statistics.median(h2d_ms) / statistics.median(end_to_end_ms) * 100
        gpu_share = statistics.median(gpu_aug_ms) / statistics.median(end_to_end_ms) * 100
        print(
            f"\nMedian share: worker={worker_share:.0f}%  h2d={h2d_share:.0f}%  gpu_aug={gpu_share:.0f}%"
        )


if __name__ == "__main__":
    main()
