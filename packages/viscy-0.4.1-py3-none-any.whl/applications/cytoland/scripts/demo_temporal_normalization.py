"""Compare fov vs per-timepoint vs smoothed-per-timepoint normalization on a VS timelapse.

Hypothesis
----------
Temporal flickering in virtual-staining timelapses comes from the ``Phase3D``
input being normalized with a single ``fov_statistics`` summary; any real
drift in the source distribution leaks straight into the prediction. Using
``timepoint_statistics`` should track the drift, and smoothing those per-t
stats with a rolling median/mean should damp any outlier timepoints (focus
drift, bubbles, etc.) that would otherwise *add* flicker.

What this script does
---------------------
1. Loads the legacy ``predict.yml`` checkpoint into the new ``cytoland.VSUNet``.
2. Reads per-t ``median``/``iqr`` for ``Phase3D`` from the position zattrs,
   and optionally smooths them with a centered rolling ``SMOOTH_KIND`` window
   of size ``SMOOTH_WINDOW``.
3. Runs sliding-window inference over ``T_START..T_STOP`` in three modes —
   ``fov_statistics``, raw ``timepoint_statistics``, smoothed
   ``timepoint_statistics`` — reading the zarr directly (no DataModule /
   DataLoader) so we only pay for the T indices we care about.
4. Writes all three predictions into a single OME-Zarr plate
   (``outputs/vs_norm_comparison.zarr``) at the same ``row/col/fov`` as the
   input. Channel order::

     [VS_nuclei_fov_stat, VS_membrane_fov_stat,
      VS_nuclei_tp_stat,  VS_membrane_tp_stat,
      VS_nuclei_tp_<kind><w>, VS_membrane_tp_<kind><w>]

   Open it next to the original ``Phase3D`` and the existing
   ``3-virtual-stain`` zarr in napari to scrub the three variants
   side-by-side.
5. Reports per-timepoint mean/std of source + predicted channels, plus a
   peak-to-peak comparison across the three modes (lower = smoother).

Notes
-----
- The on-disk checkpoint predates the ``cytoland`` namespace move. It still
  loads cleanly because the FCMAE state-dict keys are identical.
- The direct zarr-read loop replaces an earlier ``HCSDataModule`` path that
  iterated the whole timelapse before reaching ``T_START``.
"""

from __future__ import annotations

import logging
from pathlib import Path

import numpy as np
import pandas as pd
import torch
from iohub import open_ome_zarr

from cytoland.engine import AugmentedPredictionVSUNet, VSUNet
from viscy_utils.meta_utils import generate_normalization_metadata


def _d4_tta_transforms() -> tuple[list, list]:
    """Return (forward, inverse) transform lists for the D4 symmetry group.

    Eight views: 4 rotations (0°, 90°, 180°, 270°) × {identity, horizontal flip}.
    Each forward rotates/flips ``(..., Y, X)``; the matching inverse undoes it
    so outputs land back in the original orientation before reduction.
    """
    fwd, inv = [], []
    # YX dims are -2, -1 for (B, C, Z, Y, X)
    for k in range(4):
        fwd.append(lambda t, k=k: torch.rot90(t, k, dims=(-2, -1)))
        inv.append(lambda t, k=k: torch.rot90(t, -k, dims=(-2, -1)))
    for k in range(4):
        fwd.append(lambda t, k=k: torch.flip(torch.rot90(t, k, dims=(-2, -1)), dims=(-1,)))
        inv.append(lambda t, k=k: torch.rot90(torch.flip(t, dims=(-1,)), -k, dims=(-2, -1)))
    return fwd, inv

logging.basicConfig(
    level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s"
)
log = logging.getLogger("demo_temporal_normalization")

DATA_PATH = Path(
    "/hpc/projects/intracellular_dashboard/organelle_dynamics/2026_03_24_A549_SEC61_ZIKV"
    "/1-preprocess/2-reconstruct/2026_03_24_A549_SEC61_ZIKV.zarr"
)
CKPT_PATH = (
    "/hpc/projects/comp.micro/virtual_staining/models/fcmae-cyto3d-sensor"
    "/vscyto3d-logs/hek-a549-ipsc-finetune/checkpoints/epoch=83-step=14532-loss=0.492.ckpt"
)
SOURCE_CHANNEL = "Phase3D"
TARGET_CHANNELS = ["nuclei", "membrane"]
Z_WINDOW_SIZE = 15
DEMO_FOV = "A/3/fov3"
T_START = 30
T_STOP = 40  # exclusive; yields 10 timepoints (30..39)
# Spatial crop applied to each timepoint before inference. Use `None` for full extent.
Z_CROP: tuple[int, int] | None = None   # e.g. (20, 60) to clip Z to 40 slices
Y_CROP: tuple[int, int] | None = (300, 812)  # e.g. a 512 px ROI
X_CROP: tuple[int, int] | None = (300, 812)
SMOOTH_WINDOW = 5  # odd window for rolling smoother; center-aligned
SMOOTH_KIND = "median"  # "mean" or "median"
# Mode 4: clip Phase3D to this physical range before computing stats & normalizing.
# Phase3D is optical path length in radians; the reconstruction range is ~[-0.2, 0.2].
CLIP_RANGE: tuple[float, float] = (-0.2, 0.2)
# Mode 4: use a temporal pool of neighboring frames (center-aligned, clipped at edges)
# to compute median/iqr on the actual voxels — not the zattrs scalar summary.
POOL_WINDOW = 5  # odd
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"


def _slice_or_full(crop: tuple[int, int] | None, full: int) -> slice:
    """Return a slice from ``crop`` or a full-range slice if ``crop`` is None."""
    if crop is None:
        return slice(0, full)
    lo, hi = crop
    if lo < 0 or hi > full or lo >= hi:
        raise ValueError(f"Invalid crop {crop} for axis of length {full}")
    return slice(lo, hi)


def ensure_timepoint_stats(zarr_path: Path, channel: str = SOURCE_CHANNEL) -> None:
    """Run ``viscy preprocess``-equivalent if per-timepoint stats are missing.

    Parameters
    ----------
    zarr_path : Path
        Path to the HCS OME-Zarr store.
    channel : str
        Channel to check (and recompute for if needed).
    """
    with open_ome_zarr(zarr_path, mode="r") as plate:
        _, first_pos = next(plate.positions())
        norm = first_pos.zattrs.get("normalization", {}).get(channel, {})
        if "timepoint_statistics" in norm:
            log.info(
                "`%s` already has `timepoint_statistics` — skipping preprocess.",
                channel,
            )
            return
    log.info(
        "`%s` missing `timepoint_statistics` — running generate_normalization_metadata...",
        channel,
    )
    channel_id = None
    with open_ome_zarr(zarr_path, mode="r") as plate:
        channel_id = plate.channel_names.index(channel)
    generate_normalization_metadata(zarr_path, num_workers=8, channel_ids=[channel_id])


def build_model(tta: bool = False) -> AugmentedPredictionVSUNet:
    """Reproduce the legacy ``predict.yml`` model and wrap for sliding-window inference.

    Parameters
    ----------
    tta : bool
        If True, wrap with the D4 group (8 views: 4 rotations × {id, flip})
        and median aggregation. Otherwise identity transforms (matches the
        old ``predict.yml``).
    """
    base = VSUNet(
        architecture="fcmae",
        model_config={
            "in_channels": 1,
            "out_channels": 2,
            "encoder_blocks": [3, 3, 9, 3],
            "dims": [96, 192, 384, 768],
            "decoder_conv_blocks": 2,
            "stem_kernel_size": [5, 4, 4],
            "in_stack_depth": Z_WINDOW_SIZE,
            "pretraining": False,
        },
        ckpt_path=CKPT_PATH,
    )
    if tta:
        fwd, inv = _d4_tta_transforms()
        vs = AugmentedPredictionVSUNet(
            model=base.model,
            forward_transforms=fwd,
            inverse_transforms=inv,
            reduction="median",
        )
    else:
        vs = AugmentedPredictionVSUNet(
            model=base.model,
            forward_transforms=[lambda t: t],
            inverse_transforms=[lambda t: t],
        )
    vs.to(DEVICE).eval()
    return vs


def load_stats(zarr_path: Path, fov_rel: str, channel: str) -> dict:
    """Read normalization metadata for a single FOV/channel from zattrs.

    Returns
    -------
    dict
        ``{"fov": {"median": float, "iqr": float},
           "tp":  {t_int: {"median": float, "iqr": float}, ...}}``
    """
    with open_ome_zarr(zarr_path / fov_rel, mode="r") as pos:
        norm = pos.zattrs["normalization"][channel]
    fov = {"median": float(norm["fov_statistics"]["median"]),
           "iqr": float(norm["fov_statistics"]["iqr"])}
    tp = {int(k): {"median": float(v["median"]), "iqr": float(v["iqr"])}
          for k, v in norm["timepoint_statistics"].items()}
    return {"fov": fov, "tp": tp}


def smooth_tp_stats(tp: dict, window: int, kind: str) -> dict:
    """Apply a centered rolling smoother to per-timepoint stats.

    Parameters
    ----------
    tp : dict
        ``{t_int: {"median": float, "iqr": float}}`` from :func:`load_stats`.
    window : int
        Odd window size. If <=1, returns ``tp`` unchanged.
    kind : {"mean", "median"}
        Reduction applied inside the window.

    Returns
    -------
    dict
        Same shape as ``tp``, with smoothed values. Edge timepoints use
        whatever samples fall inside the (truncated) window — ``pandas``
        ``min_periods=1`` behavior.
    """
    if window <= 1:
        return tp
    if window % 2 == 0:
        raise ValueError(f"SMOOTH_WINDOW must be odd, got {window}")
    ts = sorted(tp.keys())
    df = pd.DataFrame({t: tp[t] for t in ts}).T  # rows=t, cols=[median, iqr]
    roller = df.rolling(window=window, center=True, min_periods=1)
    sm = roller.median() if kind == "median" else roller.mean()
    return {int(t): {"median": float(sm.loc[t, "median"]),
                     "iqr": float(sm.loc[t, "iqr"])} for t in ts}


@torch.no_grad()
def run_inference_direct(
    model: AugmentedPredictionVSUNet,
    zarr_path: Path,
    fov_rel: str,
    channel: str,
    stats_by_t: dict,
    output_image,
    channel_offset: int,
    sliding_step: int = 1,
) -> pd.DataFrame:
    """Predict whole volumes with :meth:`predict_sliding_windows` per timepoint.

    Uses the same linear-feathering blend as ``viscy predict``. Normalization
    is applied to the full ``(Z, Y, X)`` volume for the timepoint using the
    supplied ``stats_by_t`` (raw per-t, smoothed per-t, or fov-replicated).

    Parameters
    ----------
    stats_by_t : dict
        ``{t_int: {"median": float, "iqr": float}}`` — one entry per T in
        ``[T_START, T_STOP)``.
    sliding_step : int
        Step along Z between windows. ``1`` matches ``viscy predict``.
    """
    rows = []
    with open_ome_zarr(zarr_path / fov_rel, mode="r") as pos:
        img = pos["0"]
        ch_idx = pos.channel_names.index(channel)
        _t_total, _c, z_total, y_total, x_total = img.shape
        z_sl = _slice_or_full(Z_CROP, z_total)
        y_sl = _slice_or_full(Y_CROP, y_total)
        x_sl = _slice_or_full(X_CROP, x_total)
        log.info(
            "  crop: Z[%d:%d] Y[%d:%d] X[%d:%d] (full was Z=%d Y=%d X=%d)",
            z_sl.start, z_sl.stop, y_sl.start, y_sl.stop, x_sl.start, x_sl.stop,
            z_total, y_total, x_total,
        )
        for t_val in range(T_START, T_STOP):
            stats = stats_by_t[t_val]
            med = stats["median"]
            iqr = stats["iqr"] + 1e-8
            raw = img.oindex[t_val, ch_idx, z_sl, y_sl, x_sl].astype(np.float32)  # (Z', Y', X')
            normed = (raw - med) / iqr
            source = torch.from_numpy(normed).to(DEVICE)[None, None]  # (1, 1, Z', Y', X')

            pred = model.predict_sliding_windows(source, out_channel=2, step=sliding_step)
            pred_np = pred[0].cpu().numpy().astype(np.float32)  # (2, Z', Y', X')

            ch_slice = slice(channel_offset, channel_offset + pred_np.shape[0])
            # Output zarr T axis is the compact processed range [0..T_STOP-T_START).
            output_image.oindex[t_val - T_START, ch_slice] = pred_np

            center_z = pred_np.shape[1] // 2
            rows.append({
                "t": t_val,
                "src_mean": float(normed.mean()),
                "src_std": float(normed.std()),
                "nuc_mean": float(pred_np[0, center_z].mean()),
                "nuc_std": float(pred_np[0, center_z].std()),
                "mem_mean": float(pred_np[1, center_z].mean()),
                "mem_std": float(pred_np[1, center_z].std()),
            })
            log.info("  t=%d done", t_val)
    return pd.DataFrame(rows)


@torch.no_grad()
def run_inference_clip_and_pool(
    model: AugmentedPredictionVSUNet,
    zarr_path: Path,
    fov_rel: str,
    channel: str,
    output_image,
    channel_offset: int,
    clip: tuple[float, float] = CLIP_RANGE,
    pool_window: int = POOL_WINDOW,
    sliding_step: int = 1,
) -> pd.DataFrame:
    """Mode 4: clip Phase3D to a physical range and normalize with pooled stats.

    For each ``t`` in ``[T_START, T_STOP)``:
    1. Read a centered temporal pool of ``pool_window`` frames (truncated at
       T edges).
    2. Clip every voxel in the pool to ``clip`` (radians).
    3. Compute ``median`` and ``iqr`` over the **clipped pool** (not scalar
       summaries from zattrs).
    4. Clip ``Phase3D[t]`` and normalize with those pooled stats.
    5. Run the same sliding-window prediction as the other modes.

    This attacks Phase3D's scale sensitivity directly:
    - Clipping removes wrap/artifact tails that distort percentiles.
    - Pooling across neighbors damps per-t stat noise without blurring pixels
      (the pixels themselves pass through untouched; only the scalar scale
      factor is smoothed).
    """
    rows = []
    with open_ome_zarr(zarr_path / fov_rel, mode="r") as pos:
        img = pos["0"]
        ch_idx = pos.channel_names.index(channel)
        t_total, _c, z_total, y_total, x_total = img.shape
        z_sl = _slice_or_full(Z_CROP, z_total)
        y_sl = _slice_or_full(Y_CROP, y_total)
        x_sl = _slice_or_full(X_CROP, x_total)
        lo, hi = clip
        half = pool_window // 2
        log.info("  clip=[%.3f, %.3f], pool_window=%d", lo, hi, pool_window)
        for t_val in range(T_START, T_STOP):
            t_lo = max(0, t_val - half)
            t_hi = min(t_total, t_val + half + 1)
            # (pool, Z', Y', X')
            pool = img.oindex[slice(t_lo, t_hi), ch_idx, z_sl, y_sl, x_sl].astype(np.float32)
            pool_clipped = np.clip(pool, lo, hi)
            flat = pool_clipped.reshape(-1)
            q25, q50, q75 = np.percentile(flat, [25, 50, 75])
            med = float(q50)
            iqr = float(q75 - q25) + 1e-8

            # Pull the target frame from the pool (center of the pool window,
            # respecting edge truncation).
            target_idx = t_val - t_lo
            raw = pool_clipped[target_idx]  # (Z', Y', X')
            normed = (raw - med) / iqr
            source = torch.from_numpy(normed).to(DEVICE)[None, None]

            pred = model.predict_sliding_windows(source, out_channel=2, step=sliding_step)
            pred_np = pred[0].cpu().numpy().astype(np.float32)

            ch_slice = slice(channel_offset, channel_offset + pred_np.shape[0])
            output_image.oindex[t_val - T_START, ch_slice] = pred_np

            center_z = pred_np.shape[1] // 2
            rows.append({
                "t": t_val,
                "pool_med": med,
                "pool_iqr": iqr,
                "src_mean": float(normed.mean()),
                "src_std": float(normed.std()),
                "nuc_mean": float(pred_np[0, center_z].mean()),
                "nuc_std": float(pred_np[0, center_z].std()),
                "mem_mean": float(pred_np[1, center_z].mean()),
                "mem_std": float(pred_np[1, center_z].std()),
            })
            log.info("  t=%d done (pool t=[%d, %d), med=%.5f, iqr=%.5f)",
                     t_val, t_lo, t_hi, med, iqr)
    return pd.DataFrame(rows)


def open_output_position(out_zarr: Path):
    """Open (or create) an OME-Zarr plate position to hold side-by-side VS outputs.

    The output mirrors the input layout (same row/col/fov) so napari can open
    both stores together and the position node will align. Channel order is::

        [VS_nuclei_fov, VS_membrane_fov, VS_nuclei_tp, VS_membrane_tp]

    Returns
    -------
    tuple
        ``(plate, position, image_array)`` — the caller is responsible for
        closing ``plate``.
    """
    row, col, fov = DEMO_FOV.split("/")
    channel_names = [
        "VS_nuclei_fov_stat",
        "VS_membrane_fov_stat",
        "VS_nuclei_tp_stat",
        "VS_membrane_tp_stat",
        f"VS_nuclei_tp_{SMOOTH_KIND}{SMOOTH_WINDOW}",
        f"VS_membrane_tp_{SMOOTH_KIND}{SMOOTH_WINDOW}",
        f"VS_nuclei_clip_pool{POOL_WINDOW}",
        f"VS_membrane_clip_pool{POOL_WINDOW}",
        "VS_nuclei_fov_stat_D4tta",
        "VS_membrane_fov_stat_D4tta",
    ]
    with open_ome_zarr(DATA_PATH / DEMO_FOV, mode="r") as src_pos:
        src_arr = src_pos["0"]
        t_total, _, z_total, y_total, x_total = src_arr.shape
        try:
            scale = src_pos.zattrs["multiscales"][0]["datasets"][0][
                "coordinateTransformations"
            ][0]["scale"]
        except (KeyError, IndexError):
            scale = [1.0, 1.0, 1.0, 1.0, 1.0]
    z_sl = _slice_or_full(Z_CROP, z_total)
    y_sl = _slice_or_full(Y_CROP, y_total)
    x_sl = _slice_or_full(X_CROP, x_total)
    z_total = z_sl.stop - z_sl.start
    y_total = y_sl.stop - y_sl.start
    x_total = x_sl.stop - x_sl.start
    t_processed = T_STOP - T_START  # only write the processed time range

    plate = open_ome_zarr(
        out_zarr,
        layout="hcs",
        mode="a",
        channel_names=channel_names,
    )
    expected_shape = (t_processed, len(channel_names), z_total, y_total, x_total)
    if f"{row}/{col}/{fov}" in plate.zgroup:
        position = plate[f"{row}/{col}/{fov}"]
        image = position["0"]
        if tuple(image.shape) != expected_shape:
            raise RuntimeError(
                f"Existing output zarr has shape {image.shape} but current config "
                f"expects {expected_shape} (channel count or crop changed). "
                f"Delete {out_zarr} and rerun."
            )
    else:
        position = plate.create_position(row, col, fov)
        image = position.create_zeros(
            "0",
            shape=expected_shape,
            dtype=np.float32,
            chunks=(1, 1, 1, min(512, y_total), min(512, x_total)),
            transform=[{"type": "scale", "scale": scale}],
        )
    return plate, position, image


def per_timepoint_summary(df: pd.DataFrame) -> pd.DataFrame:
    """Pass-through: inference already yields one row per timepoint."""
    return df.reset_index(drop=True)


def _legacy_per_timepoint_summary(df: pd.DataFrame) -> pd.DataFrame:
    """(unused) Aggregate per-timepoint statistics by averaging over Z windows."""
    return df.groupby("t").mean(numeric_only=True).reset_index()


def report(label: str, df_t: pd.DataFrame) -> None:
    """Print a markdown summary of temporal variance for a given mode."""
    log.info("\n## %s\n", label)
    cols = ["src_mean", "src_std", "nuc_mean", "nuc_std", "mem_mean", "mem_std"]
    summary = pd.DataFrame(
        {
            "metric": cols,
            "mean_over_t": [df_t[c].mean() for c in cols],
            "std_over_t": [df_t[c].std() for c in cols],
            "p2p_over_t": [df_t[c].max() - df_t[c].min() for c in cols],
        }
    )
    log.info("\n%s\n", summary.to_markdown(index=False, floatfmt=".5f"))


def main() -> None:
    """Run fov vs per-timepoint vs smoothed-per-timepoint normalization comparison."""
    log.info("Device: %s", DEVICE)
    ensure_timepoint_stats(DATA_PATH)

    model = build_model()
    stats = load_stats(DATA_PATH, DEMO_FOV, SOURCE_CHANNEL)

    # Build stats_by_t for each mode, covering only [T_START, T_STOP).
    fov_stats_by_t = {t: stats["fov"] for t in range(T_START, T_STOP)}
    tp_stats_by_t = {t: stats["tp"][t] for t in range(T_START, T_STOP)}
    smoothed_all = smooth_tp_stats(stats["tp"], SMOOTH_WINDOW, SMOOTH_KIND)
    smoothed_stats_by_t = {t: smoothed_all[t] for t in range(T_START, T_STOP)}

    log.info("Per-t stats being used (median, iqr) per mode:")
    tbl = pd.DataFrame({
        "t": list(range(T_START, T_STOP)),
        "fov_med": [fov_stats_by_t[t]["median"] for t in range(T_START, T_STOP)],
        "tp_med": [tp_stats_by_t[t]["median"] for t in range(T_START, T_STOP)],
        f"tp_{SMOOTH_KIND}{SMOOTH_WINDOW}_med": [smoothed_stats_by_t[t]["median"] for t in range(T_START, T_STOP)],
        "tp_iqr": [tp_stats_by_t[t]["iqr"] for t in range(T_START, T_STOP)],
        f"tp_{SMOOTH_KIND}{SMOOTH_WINDOW}_iqr": [smoothed_stats_by_t[t]["iqr"] for t in range(T_START, T_STOP)],
    })
    log.info("\n%s\n", tbl.to_markdown(index=False, floatfmt=".5f"))

    out_dir = Path(__file__).parent / "outputs"
    out_dir.mkdir(exist_ok=True)
    out_zarr = out_dir / "vs_norm_comparison.zarr"
    log.info("Writing predictions to %s", out_zarr)
    plate, _position, image = open_output_position(out_zarr)
    try:
        log.info("Mode 1/5: fov_statistics")
        df_fov = run_inference_direct(model, DATA_PATH, DEMO_FOV, SOURCE_CHANNEL,
                                      fov_stats_by_t, image, channel_offset=0)
        df_fov_t = per_timepoint_summary(df_fov)
        report("fov_statistics", df_fov_t)

        log.info("Mode 2/5: timepoint_statistics")
        df_tp = run_inference_direct(model, DATA_PATH, DEMO_FOV, SOURCE_CHANNEL,
                                     tp_stats_by_t, image, channel_offset=2)
        df_tp_t = per_timepoint_summary(df_tp)
        report("timepoint_statistics", df_tp_t)

        log.info("Mode 3/5: timepoint_statistics smoothed (%s, w=%d)", SMOOTH_KIND, SMOOTH_WINDOW)
        df_sm = run_inference_direct(model, DATA_PATH, DEMO_FOV, SOURCE_CHANNEL,
                                     smoothed_stats_by_t, image, channel_offset=4)
        df_sm_t = per_timepoint_summary(df_sm)
        report(f"timepoint_{SMOOTH_KIND}{SMOOTH_WINDOW}", df_sm_t)

        log.info("Mode 4/5: clip [%s] + pool%d stats", CLIP_RANGE, POOL_WINDOW)
        df_cp = run_inference_clip_and_pool(model, DATA_PATH, DEMO_FOV, SOURCE_CHANNEL,
                                            image, channel_offset=6)
        df_cp_t = per_timepoint_summary(df_cp)
        report(f"clip_pool{POOL_WINDOW}", df_cp_t)

        log.info("Mode 5/5: fov_statistics + D4 TTA (8 views, median)")
        model_tta = build_model(tta=True)
        df_tta = run_inference_direct(model_tta, DATA_PATH, DEMO_FOV, SOURCE_CHANNEL,
                                      fov_stats_by_t, image, channel_offset=8)
        df_tta_t = per_timepoint_summary(df_tta)
        report("fov_stat_D4tta", df_tta_t)
    finally:
        plate.close()

    df_fov_t.to_csv(out_dir / "per_t_fov_statistics.csv", index=False)
    df_tp_t.to_csv(out_dir / "per_t_timepoint_statistics.csv", index=False)
    df_sm_t.to_csv(out_dir / f"per_t_timepoint_{SMOOTH_KIND}{SMOOTH_WINDOW}.csv", index=False)
    df_cp_t.to_csv(out_dir / f"per_t_clip_pool{POOL_WINDOW}.csv", index=False)
    df_tta_t.to_csv(out_dir / "per_t_fov_stat_D4tta.csv", index=False)
    log.info("Wrote per-timepoint summaries to %s", out_dir)

    cols = ["src_mean", "src_std", "nuc_mean", "nuc_std", "mem_mean", "mem_std"]
    cmp = pd.DataFrame({
        "metric": cols,
        "fov_p2p": [df_fov_t[c].max() - df_fov_t[c].min() for c in cols],
        "tp_p2p": [df_tp_t[c].max() - df_tp_t[c].min() for c in cols],
        f"tp_{SMOOTH_KIND}{SMOOTH_WINDOW}_p2p": [df_sm_t[c].max() - df_sm_t[c].min() for c in cols],
        f"clip_pool{POOL_WINDOW}_p2p": [df_cp_t[c].max() - df_cp_t[c].min() for c in cols],
        "fov_D4tta_p2p": [df_tta_t[c].max() - df_tta_t[c].min() for c in cols],
    })
    log.info("\n## Peak-to-peak temporal range (lower = smoother)\n\n%s\n",
             cmp.to_markdown(index=False, floatfmt=".5f"))


if __name__ == "__main__":
    main()
