# %%
import os

os.environ["DISPLAY"] = ":1"
os.environ["PYTHONNOUSERSITE"] = "1"

from pathlib import Path

import dask.array as da
import napari
import numpy as np
import torch
import tracksdata as td
from eet_features.features import add_border_dist, normalize_image
from eet_features.graph import add_features
from eet_inference import predict
from eet_inference.tracking import ILPSolverConfig
from iohub import open_ome_zarr
from numpy.typing import ArrayLike
from rich import print
from ultrack.imgproc import detect_foreground
from ultrack_td import UltrackMultiHypotheses

# %%


def _foreground_frame(frame: np.ndarray, sigma: float) -> np.ndarray:
    return detect_foreground(frame[0], sigma=sigma).astype(bool)[np.newaxis]


def mem_nuc_contour(
    nuclei_prediction: ArrayLike, membrane_prediction: ArrayLike
) -> ArrayLike:
    """
    Compute a contour map at the boundary between nuclei and membranes.

    Parameters
    ----------
    nuclei_prediction : ArrayLike
        Normalized nuclear signal, values in [0, 1].
    membrane_prediction : ArrayLike
        Normalized membrane signal, values in [0, 1].

    Returns
    -------
    ArrayLike
        Contour map as ``membrane * (1 - nucleus)``, same shape as inputs.
        High only where membrane is strong AND nucleus is weak — produces
        sharper cell-cell boundaries, especially between touching daughter cells.
    """
    return np.asarray(membrane_prediction) * (1 - np.asarray(nuclei_prediction))


# %%
viewer = napari.Viewer()

# %%
if __name__ == "__main__":

    DATA_ZARR = Path(
        "/hpc/projects/intracellular_dashboard/organelle_dynamics/2026_03_24_A549_SEC61_ZIKV/2-assemble/2026_03_24_A549_SEC61_ZIKV.zarr"
    )
    # TEMP: channels are split across two zarrs until 2-assemble is regenerated.
    # Set SPLIT_ZARRS = False and clear the overrides below to go back to a single zarr.
    SPLIT_ZARRS = True
    LABELFREE_ZARR = Path(
        "/hpc/projects/intracellular_dashboard/organelle_dynamics/2026_03_24_A549_SEC61_ZIKV/1-preprocess/2-reconstruct/2026_03_24_A549_SEC61_ZIKV.zarr"
    )
    PREDICTION_ZARR = Path(
        "/hpc/projects/intracellular_dashboard/organelle_dynamics/2026_03_24_A549_SEC61_ZIKV/1-preprocess/3-virtual-stain/2026_03_24_A549_SEC61_ZIKV.zarr"
    )
    FOV_KEY = "A/2/fov3"
    OUTPUT_DIR = Path(
        "/home/eduardo.hirata/repos/viscy/applications/eet/tmp/2026_03_24_A549_SEC61_ZIKV"
    )
    MODEL_PATH = Path(
        "/hpc/projects/organelle_phenotyping/models/eet/2026_03_17_CTC_HSC_01_50k_steps.pt"
    )

    # Limit timepoints for fast iteration — set to None to run all
    N_TIMEPOINTS = 57

    ### CHANGE THESE — channels
    NUCLEI_CHANNEL = "nuclei_prediction"
    MEMBRANE_CHANNEL = "membrane_prediction"
    IMAGE_CHANNEL = "Phase3D"  # GNN intensity features; falls back to nuclei if absent
    FOCUS_CHANNEL = "Phase3D"  # which channel's focus_slice metadata to use
    # Channels that are quantitative (signed, zero-centered) — use middle slice and
    # zero-mean/unit-std normalization instead of max-projection + quantile scaling.
    QUANTITATIVE_CHANNELS = {"Phase3D", "BF", "Phase2D"}

    ### CHANGE THESE — preprocessing
    Z_RANGE = 9  # ±slices around focus for max-projection
    FOREGROUND_SIGMA = 120.0  # Gaussian sigma (px) for background estimation

    ### CHANGE THESE — segmentation
    MIN_NUM_PIXELS = 5_000  # min cell area in pixels
    MAX_NUM_PIXELS = 100_000  # max cell area (polynucleated cells may be large)
    MIN_FRONTIER = 0.5  # boundary strength threshold
    N_WORKERS = 11  # parallel workers

    ### CHANGE THESE — linking
    DISTANCE_THRESHOLD = 180.0  # max centroid distance for candidate edges (pixels)
    N_NEIGHBORS = 10  # k-nearest neighbours per node
    MAX_DELTA_T = 3  # max frame gap bridged

    ### CHANGE THESE — EET inference
    WINDOW_SIZE = 10

    TEST_TIME_AUGS = 3  # 0=fast, 5=more accurate

    SOLVER = ILPSolverConfig(
        appearance_weight=1.0 * (1 - td.NodeAttr("border_dist")),
        disappearance_weight=1.0 * (1 - td.NodeAttr("border_dist")),
        division_weight=0,  ##5.0 * (1 - td.NodeAttr("border_dist")) ** 3,
        delta_t_weight=0.2,
        edge_bias=0.2,
        node_weight=0.0,  ##-td.NodeAttr("equivalent_diameter_area") / MIN_NUM_PIXELS,
        tracklet_solver=True,
    )
    # %%
    print("\n[bold]Preprocessing...[/bold]")
    pred_zarr = PREDICTION_ZARR if SPLIT_ZARRS else DATA_ZARR
    image_zarr = LABELFREE_ZARR if SPLIT_ZARRS else DATA_ZARR

    with (
        open_ome_zarr(pred_zarr / FOV_KEY, mode="r") as pred_ds,
        open_ome_zarr(image_zarr / FOV_KEY, mode="r") as img_ds,
    ):
        pred_arr = pred_ds["0"]  # (T, C, Z, Y, X)
        img_arr = img_ds["0"]
        if pred_arr.shape[::2] != img_arr.shape[::2]:
            # Compare T, Z, Y, X (skip C at index 1 — channel counts may differ)
            raise ValueError(
                f"Shape mismatch between labelfree {img_arr.shape} and "
                f"predictions {pred_arr.shape} (T, Z, Y, X must match)"
            )
        T, _, Z, Y, X = pred_arr.shape
        scale_yx = tuple(pred_ds.scale[-2:])

        nuc_idx = pred_ds.channel_names.index(NUCLEI_CHANNEL)
        mem_idx = pred_ds.channel_names.index(MEMBRANE_CHANNEL)
        if IMAGE_CHANNEL in img_ds.channel_names:
            img_idx = img_ds.channel_names.index(IMAGE_CHANNEL)
            img_source = img_arr
        elif IMAGE_CHANNEL in pred_ds.channel_names:
            img_idx = pred_ds.channel_names.index(IMAGE_CHANNEL)
            img_source = pred_arr
        else:
            img_idx = nuc_idx
            img_source = pred_arr

        # focus_slice metadata lives with the labelfree zarr (Phase3D focus)
        focus_ds = img_ds if FOCUS_CHANNEL in img_ds.channel_names else pred_ds
        per_timepoint = (
            focus_ds.zattrs.get("focus_slice", {})
            .get(FOCUS_CHANNEL, {})
            .get("per_timepoint", {})
        )
        z_focus_default = min(19, Z - 1)
        n_t = N_TIMEPOINTS if N_TIMEPOINTS is not None else T

        nuclei_frames = np.empty((n_t, Y, X), dtype=np.float32)
        membrane_frames = np.empty((n_t, Y, X), dtype=np.float32)
        image_frames = np.empty((n_t, Y, X), dtype=np.float32)
        image_is_quantitative = IMAGE_CHANNEL in QUANTITATIVE_CHANNELS

        # Dataset-level min/max from viscy preprocess (per-FOV normalization meta),
        # used to rescale the phase channel to [0, 1] consistently across frames.
        img_norm_meta = img_ds.zattrs.get("normalization", {}).get(IMAGE_CHANNEL, {})
        img_stats = img_norm_meta.get("dataset_statistics", {})
        img_vmin = img_stats.get("min")
        img_vmax = img_stats.get("max")
        if img_vmin is None or img_vmax is None:
            print(
                f"  [yellow]no normalization min/max for {IMAGE_CHANNEL} in zarr "
                f"metadata — will fall back to per-frame quantile[/yellow]"
            )

        # Empty-frame policy: forward-fill (first frame cannot be filled → leave as-is).
        empty_frames: list[int] = []
        last_good: int | None = None
        for t in range(n_t):
            z_focus = (
                int(per_timepoint[str(t)])
                if str(t) in per_timepoint
                else z_focus_default
            )
            z_lo = max(0, z_focus - Z_RANGE)
            z_hi = min(Z, z_focus + Z_RANGE + 1)
            nuc_slab = np.mean(pred_arr[t, nuc_idx, z_lo:z_hi], axis=0)
            mem_slab = np.mean(pred_arr[t, mem_idx, z_lo:z_hi], axis=0)
            if image_is_quantitative:
                img_slab = np.asarray(img_source[t, img_idx, z_focus], dtype=np.float32)
            else:
                img_slab = np.mean(img_source[t, img_idx, z_lo:z_hi], axis=0)

            # A frame is "empty" if the label-free image has no intensity variation
            # (constant plane, common when acquisition dropped a timepoint). Checking
            # std on the phase slab is robust: real data has non-zero variance.
            is_empty = float(img_slab.std()) < 1e-6 or float(nuc_slab.max()) == 0.0
            if is_empty and last_good is not None:
                empty_frames.append(t)
                nuclei_frames[t] = nuclei_frames[last_good]
                membrane_frames[t] = membrane_frames[last_good]
                image_frames[t] = image_frames[last_good]
            else:
                if is_empty:
                    # First frame empty — cannot forward-fill; keep raw values.
                    empty_frames.append(t)
                nuclei_frames[t] = nuc_slab
                membrane_frames[t] = mem_slab
                image_frames[t] = img_slab
                if not is_empty:
                    last_good = t

        if empty_frames:
            print(
                f"  forward-filled {len(empty_frames)} empty frame(s): {empty_frames}"
            )

    nuc_dask = da.from_array(nuclei_frames).rechunk((1, Y, X))
    mem_dask = da.from_array(membrane_frames).rechunk((1, Y, X))
    img_dask = da.from_array(image_frames).rechunk((1, Y, X))

    nuc_norm = nuc_dask.map_blocks(normalize_image, clip=True, dtype=np.float32)
    mem_norm = mem_dask.map_blocks(normalize_image, clip=True, dtype=np.float32)
    foreground = nuc_norm.map_blocks(
        _foreground_frame, sigma=FOREGROUND_SIGMA, dtype=bool
    )
    contour = da.map_blocks(mem_nuc_contour, nuc_norm, mem_norm, dtype=np.float32)
    if image_is_quantitative:
        # Quantitative phase is signed (radians / fractions of wave). Rescale to
        # [0, 1] so downstream code (display, EET model) sees intensity-like values.
        # Prefer dataset-level min/max from viscy preprocess metadata (stable across
        # frames); fall back to per-frame symmetric quantile clipping around zero.
        if img_vmin is not None and img_vmax is not None:
            _vmin = float(img_vmin)
            _vrange = float(img_vmax) - _vmin

            def _phase_to_unit(frame: np.ndarray) -> np.ndarray:
                f = np.asarray(frame, dtype=np.float32)
                return np.clip((f - _vmin) / (_vrange + 1e-7), 0.0, 1.0)

        else:

            def _phase_to_unit(frame: np.ndarray, q: float = 0.999) -> np.ndarray:
                f = np.asarray(frame, dtype=np.float32)
                lo, hi = np.quantile(f, [1 - q, q])
                bound = max(abs(lo), abs(hi), 1e-7)
                return np.clip((f + bound) / (2 * bound), 0.0, 1.0)

        norm_image = img_dask.map_blocks(_phase_to_unit, dtype=np.float32)[
            :, np.newaxis
        ]
    else:
        norm_image = img_dask.map_blocks(normalize_image, dtype=np.float32)[
            :, np.newaxis
        ]
    # foreground/contour: (T, Y, X); norm_image: (T, 1, Y, X) singleton Z for add_features

    print(f"  foreground: {foreground.shape}, dtype={foreground.dtype}")
    print(
        f"  contour:    {contour.shape},    dtype={contour.dtype}",
    )
    print(f"  norm_image: {norm_image.shape}, scale_yx={scale_yx}")

    # %%
    # viewer.add_image(
    #     norm_image[:, 0],  # squeeze singleton Z for display: (T, Y, X)
    #     name="image (normalized)",
    #     colormap="gray",
    #     blending="additive",
    #     scale=scale_yx,
    # )
    # viewer.add_labels(
    #     foreground.astype(np.uint8), name="foreground", opacity=0.3, scale=scale_yx
    # )
    viewer.add_image(
        contour,
        name="contour add (current)",
        colormap="gray",
        blending="additive",
        opacity=0.5,
        scale=scale_yx,
        visible=False,
    )
    viewer.add_image(
        nuc_norm,
        name="nuclei (normalized)",
        colormap="green",
        blending="additive",
        scale=scale_yx,
        visible=False,
    )
    viewer.add_image(
        mem_norm,
        name="membrane (normalized)",
        colormap="magenta",
        blending="additive",
        scale=scale_yx,
        visible=False,
    )

    viewer.add_image(
        img_source[:, 0, z_focus, :],
        name="image (original)",
        colormap="gray",
        blending="additive",
        scale=scale_yx,
    )
    # %%
    # 2. Segment — run once; re-run only if you change segmentation params above

    print("\n[bold]Segmenting...[/bold]")

    graph = td.graph.InMemoryGraph()
    with td.options.Options(n_workers=N_WORKERS):
        UltrackMultiHypotheses(
            min_num_pixels=MIN_NUM_PIXELS,
            max_num_pixels=MAX_NUM_PIXELS,
            min_frontier=MIN_FRONTIER,
        ).add_nodes(graph, foreground=foreground, contours=contour)

    if graph.num_nodes() == 0:
        raise RuntimeError(f"No segmentation hypotheses found for FOV {FOV_KEY}.")
    print(f"  hypotheses: {graph.num_nodes()} nodes")

    td.edges.DistanceEdges(
        distance_threshold=DISTANCE_THRESHOLD,
        n_neighbors=N_NEIGHBORS,
        delta_t=MAX_DELTA_T,
        neighbors_per_frame=True,
    ).add_edges(graph)

    print(f"  edges:      {graph.num_edges()} candidates")

    print("Adding border distance...")
    add_border_dist(graph, norm_image.shape, was_2d=True)

    print("Adding features...")
    with td.options.Options(n_workers=1):
        add_features(graph, None)  # norm_image)

    graph.metadata["was_2d"] = True
    graph.metadata["shape"] = norm_image.shape  # required by to_napari_format

    # %%
    # 3. Track — re-run this cell (and cell 4) to tune SOLVER weights

    device = "cuda" if torch.cuda.is_available() else "cpu"
    print(f"\n[bold]Loading model[/bold] ({device})...")
    model = torch.jit.load(str(MODEL_PATH), map_location=device)
    model.eval()

    print("[bold]Running EET inference + ILP...[/bold]")
    solution = predict(
        model,
        graph=graph,
        solver_config=SOLVER,
        window_size=WINDOW_SIZE,
        test_time_augs=TEST_TIME_AUGS,
    )
    print(f"  solution: {solution.num_nodes()} nodes, {solution.num_edges()} edges")

    tracks_df, track_graph, track_labels = td.functional.to_napari_format(
        solution, mask_key="mask"
    )
    track_labels_arr = np.asarray(track_labels).squeeze()
    print(
        f"  tracklets: {tracks_df['tracklet_id'].n_unique()} across {len(tracks_df)} entries"
    )

    # %%
    # 4. napari — re-run to refresh visualization after tracking

    viewer.add_labels(
        track_labels_arr, name="EET tracked labels", opacity=0.5, scale=scale_yx
    )
    viewer.add_tracks(
        tracks_df.select(["tracklet_id", "t", "y", "x"]).to_pandas().to_numpy(),
        graph=track_graph,
        name="EET tracks",
        scale=scale_yx,
        colormap="hsv",
        tail_length=10,
        blending="opaque",
    )

    napari.run()

    # %%
    # 5. Tracking summary
    lengths = tracks_df.group_by("tracklet_id").len()["len"]
    n_tracklets = tracks_df["tracklet_id"].n_unique()
    parents = list(track_graph.values())
    n_divisions = sum(1 for p in set(parents) if parents.count(p) > 1)

    # Lineage-aware stats: trace parent → longest-daughter through track_graph.
    # track_graph maps child_id -> parent_id. Build children map and recurse.
    _length_by_id = dict(
        zip(
            tracks_df.group_by("tracklet_id").len()["tracklet_id"].to_list(),
            lengths.to_list(),
            strict=True,
        )
    )
    _children: dict[int, list[int]] = {}
    for _child, _parent in track_graph.items():
        _children.setdefault(_parent, []).append(_child)
    _roots = [tid for tid in _length_by_id if tid not in track_graph]

    def _lineage_len(_tid: int) -> int:
        own = _length_by_id.get(_tid, 0)
        kids = _children.get(_tid, [])
        return own + (max(_lineage_len(c) for c in kids) if kids else 0)

    _lineage_lengths = [_lineage_len(r) for r in _roots]
    _lineage_arr = np.asarray(_lineage_lengths) if _lineage_lengths else np.array([0])
    print(
        f"""
## Tracking summary — {FOV_KEY}

| Metric | Value |
|--------|-------|
| Nodes in solution | {solution.num_nodes()} |
| Edges in solution | {solution.num_edges()} |
| Tracklets | {n_tracklets} |
| Lineages (roots) | {len(_roots)} |
| Divisions | {n_divisions} |
| Tracklet length — mean | {lengths.mean():.1f} |
| Tracklet length — median | {lengths.median():.1f} |
| Tracklet length — min | {lengths.min()} |
| Tracklet length — max | {lengths.max()} |
| Lineage length — mean | {_lineage_arr.mean():.1f} |
| Lineage length — median | {float(np.median(_lineage_arr)):.1f} |
| Lineage length — min | {_lineage_arr.min()} |
| Lineage length — max | {_lineage_arr.max()} |
| Short tracklets (≤2 frames) | {(lengths <= 2).sum()} |
| Long tracklets (≥ {n_t // 2} frames) | {(lengths >= n_t // 2).sum()} |
| Long lineages (≥ {n_t // 2} frames) | {int((_lineage_arr >= n_t // 2).sum())} |
"""
    )


# %%
