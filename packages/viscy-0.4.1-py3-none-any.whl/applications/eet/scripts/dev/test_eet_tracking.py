# %%
"""
EET (Edge Embedding Tracking) test script.

Tests Jordao's eet_inference + eet_features packages on our 5D microscopy data
as an alternative to ultrack-based tracking. Mirrors the structure of
mantis-analysis-template/1-preprocess/label-free/3-track/test_tracking.py.

Assumption: we already have segmentation labels from a prior ultrack run.
EET takes labels → builds a candidate graph with regionprops features →
runs a trained GNN to score edges → solves ILP.

NOTE: EET is a linker only — it cannot generate or split segmentations.
Tracking quality is bounded by the quality of the input labels.

Data paths follow the dynaclr convention:
    data_zarr    = datasets_root/datasets/{dataset}/{dataset}.zarr
    tracking_zarr = datasets_root/datasets/{dataset}/tracking.zarr
        channel: nuclei_prediction_labels_labels, shape (T, 1, 1, Y, X) uint32

Data flow:
    data.zarr     Phase3D center slice → normalize → dask (T, Y, X)
    tracking.zarr nuclei_prediction_labels_labels → squeeze (T, Y, X)
    eet_inference.predict(model, labels, images) → solution graph
    tracksdata.to_napari_format → tracks_df, track_graph, track_labels
"""

import json
import os

os.environ["PYTHONNOUSERSITE"] = "1"  # prevent ~/.local from shadowing conda env
os.environ["DISPLAY"] = ":1"

from pathlib import Path

import dask.array as da
import napari
import numpy as np
import torch
import tracksdata as td
from eet_features.features import normalize_image
from eet_inference import predict
from eet_inference.tracking import ILPSolverConfig
from iohub import open_ome_zarr
from rich import print

# %%
### CHANGE THESE VALUES ###

datasets_root = Path("/hpc/projects/organelle_phenotyping")
dataset = "2025_07_24_A549_SEC61_TOMM20_G3BP1_ZIKV"

data_zarr = datasets_root / f"datasets/{dataset}/{dataset}.zarr"
tracking_zarr = datasets_root / f"datasets/{dataset}/tracking.zarr"

### CHANGE THIS: well / row / FOV  (see dynaclr config for perturbation_wells)
fov_key = "B/2/000001"

### CHANGE THIS: model weights path
model_path = Path(
    "/hpc/projects/organelle_phenotyping/models/eet/2026_03_17_CTC_HSC_01_50k_steps.pt"
)

output_dir = Path(f"/hpc/mydata/eduardo.hirata/repos/eet_tracking_test/{dataset}")
os.makedirs(output_dir, exist_ok=True)

print(f"Dataset:      {dataset}")
print(f"FOV:          {fov_key}")
print(f"data_zarr:    {data_zarr}")
print(f"tracking:     {tracking_zarr}")
print(f"Output:       {output_dir}")

# %%
# Load segmentation labels from tracking.zarr
# channel: nuclei_prediction_labels_labels, shape (T, 1, 1, Y, X) uint32 → squeeze to (T, Y, X)
with open_ome_zarr(tracking_zarr / fov_key, mode="r") as track_ds:
    labels = np.asarray(track_ds["0"][:, 0, 0, :, :])  # (T, Y, X)
    scale_yx = track_ds.scale[-2:]  # (Y, X) physical pixel size in µm
    print(f"Labels shape: {labels.shape}, dtype: {labels.dtype}")
    print(f"Scale (y, x): {scale_yx} µm/px")

# Load Phase3D using z_focus_mean from zarr.json (QC-computed focus slice per FOV).
# Falls back to center slice if focus_slice metadata is absent.
zarr_json = data_zarr / fov_key / "zarr.json"
with open(zarr_json) as f:
    _meta = json.load(f)
_focus = _meta.get("attributes", {}).get("focus_slice", {}).get("Phase3D", {})
z_focus = int(round(_focus.get("fov_statistics", {}).get("z_focus_mean", -1)))

with open_ome_zarr(data_zarr / fov_key, mode="r") as data_ds:
    phase_idx = data_ds.channel_names.index("Phase3D")
    if z_focus < 0:
        z_focus = data_ds.data.shape[2] // 2
    phase_arr = np.asarray(data_ds["0"][:, phase_idx, z_focus, :, :])  # (T, Y, X)
    print(f"Phase3D shape: {phase_arr.shape}, z_focus={z_focus}")

assert (
    labels.shape == phase_arr.shape
), f"Shape mismatch: labels {labels.shape} vs Phase3D {phase_arr.shape}"

# %%
# Visualize input data before EET tracking
viewer = napari.Viewer()
# %%
viewer.add_image(
    phase_arr, name="Phase3D", colormap="gray", blending="additive", scale=scale_yx
)
viewer.add_labels(labels, name="Input labels (ultrack)", scale=scale_yx)

# %%
# Convert to dask arrays — EET expects one chunk per timepoint
images_da = da.from_array(phase_arr).rechunk((1, *phase_arr.shape[1:]))
images_da = images_da.map_blocks(normalize_image)

labels_da = da.from_array(labels).rechunk((1, *labels.shape[1:]))

print(f"Images dask: {images_da.shape}, dtype: {images_da.dtype}")
print(f"Labels dask: {labels_da.shape}, dtype: {labels_da.dtype}")

# %%
# Load model and configure ILP solver
device = "cuda" if torch.cuda.is_available() else "cpu"
print(f"Using device: {device}")

model = torch.jit.load(str(model_path), map_location=device)
model.eval()

### CHANGE THIS: ILP solver weights — from basic_tracking.py defaults
solver_config = ILPSolverConfig(
    appearance_weight=1 * (1 - td.NodeAttr("border_dist")),
    disappearance_weight=1 * (1 - td.NodeAttr("border_dist")),
    division_weight=0.0,  # TODO: -.5 to .5
    delta_t_weight=0.2,
    edge_bias=0.2,
    node_weight=0.0,
    tracklet_solver=True,
)
print(f"Solver config: {solver_config.model_dump()}")

# %%
# Run EET tracking
# scale = (t, y, x); EET internally expands 2D → 3D (adds z=1.0)
scale_tyx = (1.0, float(scale_yx[0]), float(scale_yx[1]))

graph = predict(
    model=model,
    labels=labels_da,
    images=images_da,
    solver_config=solver_config,
    ### CHANGE THESE: spatial linking parameters
    distance_threshold=200.0,  # max centroid distance for candidate edges (pixels)
    n_neighbors=10,  # k-nearest neighbors per node
    max_delta_t=3,  # max frame gap for linking
    scale=scale_tyx,
    window_size=5,
    tiling_scheme=None,  # None is fine for (66, 744, 1119); set for larger volumes
    test_time_augs=2,  # set to 5 for better accuracy, slower
    return_solution=True,
)

print(f"Solution graph: {graph.num_nodes()} nodes, {graph.num_edges()} edges")

# %%
# Convert solution graph to napari format
# returns (pl.DataFrame[tracklet_id, t, y, x], dict[int,int], GraphArrayView)
tracks_df, track_graph, track_labels = td.functional.to_napari_format(
    graph, mask_key="mask"
)
print(
    f"Tracks: {len(tracks_df)} entries across {tracks_df['tracklet_id'].n_unique()} tracklets"
)

# Materialize and squeeze singleton Z so track_labels is (T, Y, X) like labels
track_labels_arr = np.asarray(track_labels).squeeze()
assert (
    track_labels_arr.shape == labels.shape
), f"Shape mismatch after squeeze: track_labels {track_labels_arr.shape} vs labels {labels.shape}"

# %%
# Visualize EET results
# viewer = napari.Viewer()
# viewer.add_image(
#     phase_arr, name="Phase3D", colormap="gray", blending="additive", scale=scale_yx
# )
# viewer.add_labels(labels, name="Input labels (ultrack)", scale=scale_yx, opacity=0.4)
viewer.add_labels(track_labels_arr, name="EET tracked labels", scale=scale_yx)
viewer.add_tracks(
    tracks_df.select(["tracklet_id", "t", "y", "x"]).to_pandas().to_numpy(),
    graph=track_graph,
    name="EET tracks",
    scale=scale_yx,
    colormap="hsv",
    blending="opaque",
)
napari.run()

# %%
# Save EET solution as GEFF (zarr) — used by compare_tracks.py via napari-geff plugin
geff_path = output_dir / "eet_solution.geff"
graph.to_geff(str(geff_path), overwrite=True)
print(f"Saved: {geff_path}")
print(f"Open in napari: viewer.open('{geff_path}', plugin='napari-geff')")

# %%
