# %%
"""
Side-by-side comparison of ultrack vs EET tracks in napari.

Prerequisites:
  1. Run test_eet_tracking.py first — it saves eet_solution.geff
  2. Install napari-geff: pip install napari-geff (or editable from ~/repos/napari-geff)

What this loads:
  - Phase3D image from data.zarr (background)
  - ultrack labels + tracks CSV from tracking.zarr
  - EET solution via napari-geff plugin (full graph with divisions)

Toggle layer visibility in napari to compare ultrack vs EET linking.
"""

import os

os.environ["PYTHONNOUSERSITE"] = "1"

from pathlib import Path

import napari
import numpy as np
import pandas as pd
from iohub import open_ome_zarr
from rich import print

# %%
### CHANGE THESE VALUES — must match test_eet_tracking.py ###

datasets_root = Path("/hpc/projects/organelle_phenotyping")
dataset = "2025_07_24_A549_SEC61_TOMM20_G3BP1_ZIKV"

data_zarr = datasets_root / f"datasets/{dataset}/{dataset}.zarr"
tracking_zarr = datasets_root / f"datasets/{dataset}/tracking.zarr"

### CHANGE THIS: well / row / FOV
fov_key = "B/1/000000"

### CHANGE THIS: EET solution saved by test_eet_tracking.py
geff_path = Path(f"/hpc/mydata/eduardo.hirata/repos/eet_tracking_test/{dataset}/eet_solution.geff")

# %%
# Load Phase3D center slice for background
with open_ome_zarr(data_zarr / fov_key, mode="r") as data_ds:
    phase_idx = data_ds.channel_names.index("Phase3D")
    z_center = data_ds.data.shape[2] // 2
    phase_arr = np.asarray(data_ds["0"][:, phase_idx, z_center, :, :])  # (T, Y, X)
    scale_yx = tuple(float(s) for s in data_ds.scale[-2:])
    print(f"Phase3D: {phase_arr.shape}, scale: {scale_yx}")

# Load ultrack labels (T, 1, 1, Y, X) → (T, Y, X)
with open_ome_zarr(tracking_zarr / fov_key, mode="r") as track_ds:
    ultrack_labels = np.asarray(track_ds["0"][:, 0, 0, :, :])
    print(f"Ultrack labels: {ultrack_labels.shape}")

# Load ultrack tracks CSV — columns: track_id, t, y, x, parent_track_id, ...
well_row_fov = fov_key.replace("/", "_")
ultrack_csv = tracking_zarr / fov_key / f"tracks_{well_row_fov}.csv"
ultrack_df = pd.read_csv(ultrack_csv)
ultrack_graph = {
    int(r.track_id): int(r.parent_track_id)
    for _, r in ultrack_df.iterrows()
    if r.parent_track_id != -1
}
print(f"Ultrack: {ultrack_df['track_id'].nunique()} tracks")

# %%
# Build napari viewer — load EET via napari-geff plugin
viewer = napari.Viewer()

viewer.add_image(phase_arr, name="Phase3D", colormap="gray", blending="additive", scale=scale_yx)

viewer.add_labels(ultrack_labels, name="labels (ultrack)", scale=scale_yx, opacity=0.3, visible=False)

viewer.add_tracks(
    ultrack_df[["track_id", "t", "y", "x"]].to_numpy(),
    graph=ultrack_graph,
    name="ultrack tracks",
    scale=scale_yx,
    colormap="hsv",
    tail_length=10,
)

# Load EET solution — napari-geff creates a Tracks layer with full division graph
viewer.open(str(geff_path), plugin="napari-geff")
# Rename the layer napari-geff created so it's easy to identify
viewer.layers[-1].name = "EET tracks"

print("Toggle 'ultrack tracks' and 'EET tracks' layers to compare.")
napari.run()
