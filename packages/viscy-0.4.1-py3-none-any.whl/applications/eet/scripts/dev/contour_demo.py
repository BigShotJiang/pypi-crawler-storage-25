"""Compare contour formulas on a single frame for intuition.

Loads one timepoint from the A549 FOV and computes several contour variants:
- additive: (mem + (1 - nuc)) / 2   (current)
- multiplicative: mem * (1 - nuc)
- max:            max(mem, 1 - nuc)
- weighted:       0.7 * mem + 0.3 * (1 - nuc)

Shows each as a napari image layer so we can compare visually.
"""

# %%
import os
from pathlib import Path

import numpy as np

os.environ["DISPLAY"] = ":1"
os.environ["PYTHONNOUSERSITE"] = "1"

import napari  # noqa: E402
from eet_features.features import normalize_image  # noqa: E402
from iohub import open_ome_zarr  # noqa: E402
from rich import print  # noqa: E402
from ultrack.imgproc import detect_foreground  # noqa: E402


DATA_ZARR = Path(
    "/hpc/projects/intracellular_dashboard/organelle_dynamics"
    "/2026_03_24_A549_SEC61_ZIKV/1-preprocess/3-virtual-stain/v1"
    "/_2026_03_24_A549_SEC61_ZIKV.zarr"
)
FOV_KEY = "A/2/fov3"
NUCLEI_CHANNEL = "nuclei_prediction"
MEMBRANE_CHANNEL = "membrane_prediction"
FOCUS_CHANNEL = "membrane_prediction"
T_IDX = 10  # middle-ish frame
Z_RANGE = 9
FOREGROUND_SIGMA = 100.0


def main() -> None:
    with open_ome_zarr(DATA_ZARR / FOV_KEY, mode="r") as ds:
        arr = ds["0"]
        T, C, Z, Y, X = arr.shape
        scale_yx = tuple(ds.scale[-2:])
        nuc_idx = ds.channel_names.index(NUCLEI_CHANNEL)
        mem_idx = ds.channel_names.index(MEMBRANE_CHANNEL)

        per_tp = (
            ds.zattrs.get("focus_slice", {})
            .get(FOCUS_CHANNEL, {})
            .get("per_timepoint", {})
        )
        z_focus = int(per_tp.get(str(T_IDX), Z // 2))
        z_lo = max(0, z_focus - Z_RANGE)
        z_hi = min(Z, z_focus + Z_RANGE + 1)
        print(f"frame {T_IDX}: z_focus={z_focus}, z_range=[{z_lo}, {z_hi})")

        nuc = np.mean(arr[T_IDX, nuc_idx, z_lo:z_hi], axis=0).astype(np.float32)
        mem = np.mean(arr[T_IDX, mem_idx, z_lo:z_hi], axis=0).astype(np.float32)

    nuc_n = normalize_image(nuc, clip=True)
    mem_n = normalize_image(mem, clip=True)
    inv_nuc = 1.0 - nuc_n

    c_add = (mem_n + inv_nuc) / 2
    c_mul = mem_n * inv_nuc
    c_max = np.maximum(mem_n, inv_nuc)
    c_wgt = 0.7 * mem_n + 0.3 * inv_nuc

    fg = detect_foreground(nuc_n, sigma=FOREGROUND_SIGMA).astype(bool)

    print(
        "\n## Contour statistics (on foreground pixels only)\n"
        "| Formula | mean | std | p5 | p95 | contrast (p95-p5) |\n"
        "|---|---|---|---|---|---|"
    )
    for name, c in [
        ("additive (current)", c_add),
        ("multiplicative", c_mul),
        ("max", c_max),
        ("weighted 0.7/0.3", c_wgt),
    ]:
        vals = c[fg]
        p5, p95 = np.quantile(vals, [0.05, 0.95])
        print(
            f"| {name} | {vals.mean():.3f} | {vals.std():.3f} | "
            f"{p5:.3f} | {p95:.3f} | {p95 - p5:.3f} |"
        )

    viewer = napari.Viewer()
    viewer.add_image(nuc_n, name="nuclei", colormap="green", scale=scale_yx)
    viewer.add_image(mem_n, name="membrane", colormap="magenta", scale=scale_yx)
    viewer.add_labels(
        fg.astype(np.uint8), name="foreground", opacity=0.2, scale=scale_yx
    )
    viewer.add_image(
        c_add, name="contour add (current)", colormap="magma", scale=scale_yx
    )
    viewer.add_image(c_mul, name="contour mul", colormap="magma", scale=scale_yx)
    viewer.add_image(c_max, name="contour max", colormap="magma", scale=scale_yx)
    viewer.add_image(
        c_wgt, name="contour wgt 0.7/0.3", colormap="magma", scale=scale_yx
    )
    napari.run()


if __name__ == "__main__":
    main()

# %%
