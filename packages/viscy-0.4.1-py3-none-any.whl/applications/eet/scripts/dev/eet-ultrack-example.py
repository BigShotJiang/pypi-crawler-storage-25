import shutil
from pathlib import Path

import napari
import numpy as np
import torch
import tracksdata as td
from dask.array.image import imread
from edt import edt
from eet_features.features import normalize_image
from eet_features.graph import add_features
from eet_inference import predict
from eet_inference.tracking import ILPSolverConfig
from numpy.typing import ArrayLike
from rich import print
from ultrack_td import UltrackMultiHypotheses


def _labels_to_contour(labels: ArrayLike) -> ArrayLike:
    assert labels.shape[0] == 1
    labels = labels[0]
    dist = edt(labels).astype(np.float32)
    dist = dist.max() - dist
    dist[labels == 0] = 0
    dist = dist / dist.max()
    return dist[None, ...]  # expanding back to (1, chunk_size)


def main() -> None:
    viewer = napari.Viewer()
    viewer.window.resize(1800, 1000)

    data_dir = Path(
        "/hpc/projects/group.royer/people/jordao.bragantini/bovine_embryo_bernhard_magerl"
    )

    img = imread(f"{data_dir}/Pos9_SwitchSend/deconv_561/561_Fusion/*.tif")
    segm = imread(f"{data_dir}/Pos9_SwitchSend/561_Fusion_StardistPredict/*.tif")

    # # for testing purposes
    # img = img[800:900]
    # segm = segm[800:900]

    viewer.add_image(img)
    viewer.add_labels(segm, visible=False, name="input labels")

    # indicates which pixels can be ignored as background
    foreground = segm > 0

    # creates a topology that represents captures convex-like objects
    contours = segm.map_blocks(_labels_to_contour, dtype=np.float32)
    norm_img = img.map_blocks(normalize_image, dtype=np.float32)

    viewer.add_labels(foreground, visible=False)
    viewer.add_image(contours, colormap="gray_r", visible=False)

    graph = td.graph.InMemoryGraph()

    with td.options.Options(n_workers=10):
        UltrackMultiHypotheses(
            min_num_pixels=15_000,
            max_num_pixels=200_000,
            min_frontier=0.05,
        ).add_nodes(
            graph=graph,
            foreground=foreground,
            contours=contours,
        )

    td.edges.DistanceEdges(
        distance_threshold=100,
        n_neighbors=10,
        delta_t=3,
        neighbors_per_frame=True,
    ).add_edges(graph=graph)

    print("Adding features...")
    with td.options.Options(n_workers=10):
        add_features(graph, norm_img)

    print("Loading model...")
    model_path = "weights/2026_01_30_09_23_41_job_26961657.pt"
    device = "cuda" if torch.cuda.is_available() else "cpu"
    model = torch.jit.load(model_path, map_location=device)

    # # turn this on to see attributes statistics
    # graph.summary(attrs_stats=True)

    # weights were chosen on vibes, we want to penalize entry and exit a lot!
    solver_config = ILPSolverConfig(
        appearance_weight=5,
        disappearance_weight=5,
        division_weight=2,
        node_weight=-td.NodeAttr("equivalent_diameter_area")
        / 60,  # chose this value looking at the data range
        delta_t_weight=0.1,  # the formula is exp(-delta_t_weight * (delta_t - 1)) * edge_weight
        edge_bias=0.5,
        tracklet_solver=True,
    )
    print("Predicting...")
    solution = predict(model, graph=graph, solver_config=solver_config)

    # # these lines below are the non-deep learning tracking
    # td.edges.IoUEdgeAttr(output_key="iou").add_edge_attrs(graph=graph)
    # # these values are flipped from original ultrack because we are minimizing the cost function
    # # penalizations are positive
    # # edge weights are negative
    # solution = td.solvers.ILPSolver(
    #     edge_weight=-td.EdgeAttr("iou"),
    #     appearance_weight=0.1 * (td.NodeAttr("t") > td.NodeAttr("t").min()),
    #     disappearance_weight=0.1 * (td.NodeAttr("t") < td.NodeAttr("t").max()),
    #     division_weight=0.1,
    # ).solve(graph=graph)

    tracks_df, tracks_graph, segms = td.functional.to_napari_format(
        solution,
        shape=contours.shape,
        solution_key=None,
        mask_key=td.DEFAULT_ATTR_KEYS.MASK,
    )

    output_path = Path("solution.geff")
    if output_path.exists():
        shutil.rmtree(output_path)
    solution.to_geff(output_path)

    viewer.add_tracks(tracks_df, graph=tracks_graph)
    viewer.add_labels(segms, opacity=0.5)

    napari.run()


if __name__ == "__main__":
    main()
