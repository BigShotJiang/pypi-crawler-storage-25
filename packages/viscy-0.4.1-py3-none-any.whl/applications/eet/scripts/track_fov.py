"""Track a single FOV using the EET pipeline, driven by a YAML config.

Usage
-----
    uv run python scripts/track_fov.py \\
        --config configs/a549_zikv.yaml \\
        --fov-key A/2/fov3

The YAML config holds all tracking parameters (paths, channels, segmentation,
linking, solver weights). For experiment-specific tuning, duplicate and edit
``configs/default.yaml``.
"""

import argparse
from pathlib import Path

from eet_tracking.config import TrackingConfig
from eet_tracking.pipeline import track_one_fov


def main() -> None:
    parser = argparse.ArgumentParser(description="EET single-FOV tracking (YAML config)")
    parser.add_argument(
        "--config", type=Path, required=True, help="Path to YAML tracking config"
    )
    parser.add_argument(
        "--fov-key",
        required=True,
        help="FOV key within the zarr store (e.g. A/2/fov3)",
    )
    args = parser.parse_args()

    config = TrackingConfig.from_yaml(args.config, fov_key=args.fov_key)
    track_one_fov(config)


if __name__ == "__main__":
    main()
