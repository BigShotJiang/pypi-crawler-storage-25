"""Configuration for the EET single-FOV tracking pipeline.

Load from YAML via :func:`TrackingConfig.from_yaml`. Solver weight expressions
are parsed from strings referencing node/edge attributes (``border_dist``,
``distance``, ``equivalent_diameter_area``) and standard arithmetic.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import tracksdata as td
import yaml
from eet_inference.tracking import ILPSolverConfig


_NODE_ATTRS: frozenset[str] = frozenset(
    {"border_dist", "equivalent_diameter_area", "t"}
)
_EDGE_ATTRS: frozenset[str] = frozenset({"distance", "delta_t"})


def _parse_weight_expr(expr: str | float | int) -> Any:
    """Parse a solver weight string into a scalar or ``td.Attr`` expression.

    Recognizes names in :data:`_NODE_ATTRS` and :data:`_EDGE_ATTRS` as
    ``td.NodeAttr(...)`` / ``td.EdgeAttr(...)`` respectively, plus standard
    Python arithmetic. Scalars are returned as-is.

    Parameters
    ----------
    expr : str or float or int
        Weight expression. If numeric, returned unchanged. If string, evaluated
        with a restricted namespace (only whitelisted attribute names plus
        arithmetic operators).

    Returns
    -------
    Any
        Scalar or ``td.Attr`` expression suitable for ``ILPSolverConfig`` fields.
    """
    if isinstance(expr, (int, float)):
        return expr
    namespace: dict[str, Any] = {
        name: td.NodeAttr(name) for name in _NODE_ATTRS
    }
    namespace.update({name: td.EdgeAttr(name) for name in _EDGE_ATTRS})
    return eval(expr, {"__builtins__": {}}, namespace)  # noqa: S307


def _solver_from_dict(d: dict[str, Any]) -> ILPSolverConfig:
    """Build an ``ILPSolverConfig`` from a YAML dict, parsing weight expressions."""
    parsed: dict[str, Any] = {}
    for key, value in d.items():
        if key in {
            "appearance_weight",
            "disappearance_weight",
            "division_weight",
            "node_weight",
            "edge_bias",
        }:
            parsed[key] = _parse_weight_expr(value)
        else:
            parsed[key] = value
    return ILPSolverConfig(**parsed)


def _default_solver() -> ILPSolverConfig:
    """Default solver tuned for A549/ZIKV HCS data (from debug_fov.py, 2026-04-16).

    - border-aware appearance/disappearance (free at edges, costly interior)
    - interior divisions free, cubic border penalty to suppress edge divisions
    - size-proportional node reward (drops small fragments, keeps big cells)
    """
    return ILPSolverConfig(
        appearance_weight=1.0 * (1 - td.NodeAttr("border_dist")),
        disappearance_weight=1.0 * (1 - td.NodeAttr("border_dist")),
        division_weight=20.0 * td.NodeAttr("border_dist") ** 3,
        delta_t_weight=0.0,
        edge_bias=0.3,
        node_weight=-td.NodeAttr("equivalent_diameter_area") / 100,
        tracklet_solver=True,
    )


@dataclass(frozen=True)
class TrackingConfig:
    """Configuration for the EET single-FOV tracking pipeline.

    Parameters
    ----------
    data_zarr : Path
        OME-Zarr store containing raw channels (nuclei, membrane, image).
    fov_key : str
        Position key within the zarr store, e.g. ``"A/2/fov3"``.
    model_path : Path
        Path to the JIT-scripted EET model weights (``*.pt``).
    output_dir : Path
        Directory where GEFF and CSV outputs are written.
    solver : ILPSolverConfig
        ILP solver weights.
    nuclei_channel : str
        Channel name for the nuclei virtual staining prediction.
    membrane_channel : str
        Channel name for the membrane virtual staining prediction.
    image_channel : str
        Channel name used for GNN intensity features.
    focus_channel : str
        Channel whose ``focus_slice`` metadata is read from ``zarr.json``.
    z_range : int
        Number of Z-slices above and below focus for max-projection.
    min_num_pixels : int
        Minimum pixel count for a segmentation hypothesis.
    max_num_pixels : int
        Maximum pixel count for a segmentation hypothesis.
    min_frontier : float
        Minimum boundary strength for splitting a region into sub-hypotheses.
    distance_threshold : float
        Maximum centroid distance for candidate edges, in pixels.
    n_neighbors : int
        Maximum nearest neighbours per node for candidate edges.
    max_delta_t : int
        Maximum temporal gap (frames) for candidate edges.
    window_size : int
        Temporal window size for the EET frame dataset.
    test_time_augs : int
        Number of test-time augmentations (0 = fastest).
    foreground_sigma : float
        Gaussian sigma (pixels) for ``ultrack.imgproc.detect_foreground``.
    border_dist_cutoff : float
        Pixels from FOV edge where ``border_dist`` falls to 0.
    n_workers : int
        Parallel workers for segmentation and feature extraction.
    """

    data_zarr: Path
    fov_key: str
    model_path: Path
    output_dir: Path

    solver: ILPSolverConfig = field(default_factory=_default_solver)

    nuclei_channel: str = "nuclei_prediction"
    membrane_channel: str = "membrane_prediction"
    image_channel: str = "nuclei_prediction"
    focus_channel: str = "membrane_prediction"

    z_range: int = 9

    min_num_pixels: int = 15_000
    max_num_pixels: int = 130_000
    min_frontier: float = 0.1

    distance_threshold: float = 180.0
    n_neighbors: int = 10
    max_delta_t: int = 3
    window_size: int = 5
    test_time_augs: int = 1

    foreground_sigma: float = 100.0
    border_dist_cutoff: float = 50.0

    n_workers: int = 10

    @classmethod
    def from_yaml(
        cls,
        path: str | Path,
        *,
        fov_key: str | None = None,
    ) -> TrackingConfig:
        """Load a ``TrackingConfig`` from a YAML file.

        Parameters
        ----------
        path : str or Path
            Path to the YAML config file.
        fov_key : str, optional
            Override the ``fov_key`` from the config file. Useful for SLURM
            array jobs where one config is used across many FOVs.

        Returns
        -------
        TrackingConfig
            Loaded configuration with solver expressions parsed into ``td.Attr``
            objects.
        """
        with open(path) as f:
            data = yaml.safe_load(f)
        solver_dict = data.pop("solver", None)
        solver = _solver_from_dict(solver_dict) if solver_dict else _default_solver()
        for pkey in ("data_zarr", "model_path", "output_dir"):
            if pkey in data:
                data[pkey] = Path(data[pkey])
        if fov_key is not None:
            data["fov_key"] = fov_key
        return cls(solver=solver, **data)
