"""Core EET tracking pipeline for a single FOV.

Pipeline stages
---------------
1. Read per-timepoint z-focus from ``zarr.json`` (written by ``qc focus``).
2. Mean-project nuclei, membrane, and image channels around each timepoint's
   in-focus Z-slice.
3. Compute foreground mask and contour map for segmentation.
4. Build candidate tracking graph via ``UltrackMultiHypotheses``.
5. Score candidate edges with the EET GNN and solve with ILP.
6. Save outputs: GEFF (full graph) + CSV (tracklet coordinates).
"""

from __future__ import annotations

from pathlib import Path

import dask.array as da
import numpy as np
import torch
import tracksdata as td
from eet_features.features import add_border_dist, normalize_image
from eet_features.graph import add_features
from eet_inference import predict
from iohub import open_ome_zarr
from numpy.typing import ArrayLike
from rich import print
from ultrack.imgproc import detect_foreground
from ultrack_td import UltrackMultiHypotheses

from eet_tracking.config import TrackingConfig


def _foreground_frame(frame: np.ndarray, sigma: float) -> np.ndarray:
    return detect_foreground(frame[0], sigma=sigma).astype(bool)[np.newaxis]


def mem_nuc_contour(
    nuclei_prediction: ArrayLike, membrane_prediction: ArrayLike
) -> ArrayLike:
    """Compute a contour map emphasizing cell-cell boundaries.

    The multiplicative form ``membrane * (1 - nucleus)`` is high only where the
    membrane signal is strong AND the nucleus signal is weak, producing sharp
    boundaries between touching daughter cells after division.

    Parameters
    ----------
    nuclei_prediction : ArrayLike
        Normalized nuclear signal, values in ``[0, 1]``.
    membrane_prediction : ArrayLike
        Normalized membrane signal, values in ``[0, 1]``.

    Returns
    -------
    ArrayLike
        Contour map as ``membrane * (1 - nucleus)``, same shape as inputs.
    """
    return np.asarray(membrane_prediction) * (1 - np.asarray(nuclei_prediction))


def preprocess_fov(
    config: TrackingConfig,
) -> tuple[da.Array, da.Array, da.Array, tuple[float, float]]:
    """Load and preprocess one FOV into foreground, contour, and image dask arrays.

    Mean-projects each channel around per-timepoint focus ± ``z_range``, then
    builds lazy dask arrays so downstream operators can pull each frame in
    parallel workers.

    Parameters
    ----------
    config : TrackingConfig
        Pipeline configuration.

    Returns
    -------
    foreground : da.Array
        Boolean foreground mask, shape ``(T, Y, X)``.
    contour : da.Array
        Float32 contour map, shape ``(T, Y, X)``.
    norm_image : da.Array
        Float32 normalized image, shape ``(T, 1, Y, X)``. Singleton Z required
        by ``add_features`` (masks are always 3D).
    scale_yx : tuple[float, float]
        Physical pixel size ``(y, x)`` in microns.
    """
    with open_ome_zarr(config.data_zarr / config.fov_key, mode="r") as ds:
        arr = ds["0"]
        T, C, Z, Y, X = arr.shape
        scale_yx = tuple(ds.scale[-2:])

        nuc_idx = ds.channel_names.index(config.nuclei_channel)
        mem_idx = ds.channel_names.index(config.membrane_channel)
        img_idx = (
            ds.channel_names.index(config.image_channel)
            if config.image_channel in ds.channel_names
            else nuc_idx
        )

        per_timepoint = (
            ds.zattrs.get("focus_slice", {})
            .get(config.focus_channel, {})
            .get("per_timepoint", {})
        )
        z_focus_default = Z // 2

        nuclei_frames = np.empty((T, Y, X), dtype=np.float32)
        membrane_frames = np.empty((T, Y, X), dtype=np.float32)
        image_frames = np.empty((T, Y, X), dtype=np.float32)

        for t in range(T):
            z_focus = (
                int(per_timepoint[str(t)])
                if str(t) in per_timepoint
                else z_focus_default
            )
            z_lo = max(0, z_focus - config.z_range)
            z_hi = min(Z, z_focus + config.z_range + 1)
            nuclei_frames[t] = np.mean(arr[t, nuc_idx, z_lo:z_hi], axis=0)
            membrane_frames[t] = np.mean(arr[t, mem_idx, z_lo:z_hi], axis=0)
            image_frames[t] = np.mean(arr[t, img_idx, z_lo:z_hi], axis=0)

    nuc_dask = da.from_array(nuclei_frames).rechunk((1, Y, X))
    mem_dask = da.from_array(membrane_frames).rechunk((1, Y, X))
    img_dask = da.from_array(image_frames).rechunk((1, Y, X))

    nuc_norm = nuc_dask.map_blocks(normalize_image, clip=True, dtype=np.float32)
    mem_norm = mem_dask.map_blocks(normalize_image, clip=True, dtype=np.float32)
    foreground = nuc_norm.map_blocks(
        _foreground_frame, sigma=config.foreground_sigma, dtype=bool
    )
    contour = da.map_blocks(mem_nuc_contour, nuc_norm, mem_norm, dtype=np.float32)
    norm_image = img_dask.map_blocks(normalize_image, dtype=np.float32)[:, np.newaxis]

    return foreground, contour, norm_image, scale_yx


def _recompute_border_dist(
    graph: td.graph.BaseGraph, shape_yx: tuple[int, int], cutoff: float
) -> None:
    """Overwrite the ``border_dist`` attribute with a user-specified cutoff.

    ``add_border_dist`` hardcodes a 5px cutoff, which is too tight for HCS FOVs
    where cells within 50+ pixels of the edge should be considered "near border"
    for appearance/disappearance purposes.

    Parameters
    ----------
    graph : td.graph.BaseGraph
        Graph with ``border_dist`` already added via ``add_border_dist``.
    shape_yx : tuple[int, int]
        Image dimensions ``(Y, X)`` in pixels.
    cutoff : float
        Distance from edge at which ``border_dist`` reaches 0.
    """
    nid_key = td.DEFAULT_ATTR_KEYS.NODE_ID
    node_df = graph.node_attrs(attr_keys=[nid_key, "y", "x"])
    coords = node_df[["y", "x"]].to_numpy()
    shape_arr = np.asarray(shape_yx)
    dist = np.minimum(coords, shape_arr - coords).min(axis=1)
    border_dist_values = (1 - np.minimum(1.0, dist / cutoff)).tolist()
    graph.update_node_attrs(
        attrs={"border_dist": border_dist_values},
        node_ids=node_df[nid_key].to_list(),
    )


def build_tracking_graph(
    foreground: da.Array,
    contour: da.Array,
    norm_image: da.Array,
    config: TrackingConfig,
) -> td.graph.InMemoryGraph:
    """Build candidate tracking graph from foreground + contour maps.

    Parameters
    ----------
    foreground : da.Array
        Boolean foreground mask, shape ``(T, Y, X)``.
    contour : da.Array
        Float32 contour map, shape ``(T, Y, X)``.
    norm_image : da.Array
        Float32 normalized intensity image, shape ``(T, 1, Y, X)``.
    config : TrackingConfig
        Pipeline configuration.

    Returns
    -------
    td.graph.InMemoryGraph
        Candidate graph with segmentation nodes, edges, and GNN features.

    Raises
    ------
    RuntimeError
        If no segmentation hypotheses are found (empty FOV).
    """
    graph = td.graph.InMemoryGraph()

    print("[bold]Segmenting...[/bold]")
    with td.options.Options(n_workers=config.n_workers):
        UltrackMultiHypotheses(
            min_num_pixels=config.min_num_pixels,
            max_num_pixels=config.max_num_pixels,
            min_frontier=config.min_frontier,
        ).add_nodes(graph, foreground=foreground, contours=contour)

    if graph.num_nodes() == 0:
        raise RuntimeError(
            f"No segmentation hypotheses found for FOV {config.fov_key}."
        )
    print(f"[green]Segmentation:[/green] {graph.num_nodes()} hypotheses")

    print("[bold]Adding candidate edges...[/bold]")
    td.edges.DistanceEdges(
        distance_threshold=config.distance_threshold,
        n_neighbors=config.n_neighbors,
        delta_t=config.max_delta_t,
        neighbors_per_frame=True,
    ).add_edges(graph)
    print(f"[green]Edges:[/green] {graph.num_edges()} candidates")

    add_border_dist(graph, norm_image.shape, was_2d=True)
    _recompute_border_dist(graph, norm_image.shape[-2:], config.border_dist_cutoff)

    print("[bold]Computing GNN features...[/bold]")
    with td.options.Options(n_workers=config.n_workers):
        add_features(graph, norm_image)

    graph.metadata["was_2d"] = True
    graph.metadata["shape"] = norm_image.shape

    return graph


def _compute_lineage_stats(
    track_graph: dict[int, int], lengths_by_id: dict[int, int]
) -> dict[str, float]:
    """Compute lineage-aware length stats across parent→daughter chains."""
    children: dict[int, list[int]] = {}
    for child, parent in track_graph.items():
        children.setdefault(parent, []).append(child)
    roots = [tid for tid in lengths_by_id if tid not in track_graph]

    def _lineage_len(tid: int) -> int:
        own = lengths_by_id.get(tid, 0)
        kids = children.get(tid, [])
        return own + (max(_lineage_len(c) for c in kids) if kids else 0)

    lengths = np.asarray([_lineage_len(r) for r in roots]) if roots else np.array([0])
    return {
        "n_lineages": len(roots),
        "mean": float(lengths.mean()),
        "median": float(np.median(lengths)),
        "min": int(lengths.min()),
        "max": int(lengths.max()),
    }


def track_one_fov(config: TrackingConfig) -> Path:
    """Run the full EET tracking pipeline on a single FOV.

    Parameters
    ----------
    config : TrackingConfig
        Complete pipeline configuration including ``fov_key``.

    Returns
    -------
    Path
        Path to the saved GEFF output file.
    """
    fov_slug = config.fov_key.replace("/", "_")
    config.output_dir.mkdir(parents=True, exist_ok=True)
    geff_path = config.output_dir / f"{fov_slug}.geff"
    csv_path = config.output_dir / f"{fov_slug}.csv"

    print(f"\n[bold cyan]EET Tracking[/bold cyan] — FOV: [yellow]{config.fov_key}[/yellow]")
    print(f"  data_zarr:  {config.data_zarr}")
    print(f"  model:      {config.model_path}")
    print(f"  output_dir: {config.output_dir}")

    print("\n[bold]Preprocessing...[/bold]")
    foreground, contour, norm_image, scale_yx = preprocess_fov(config)
    print(f"  foreground: {foreground.shape}, scale_yx={scale_yx}")

    graph = build_tracking_graph(foreground, contour, norm_image, config)

    device = "cuda" if torch.cuda.is_available() else "cpu"
    print(f"\n[bold]Loading model[/bold] ({device})...")
    model = torch.jit.load(str(config.model_path), map_location=device)
    model.eval()

    print("[bold]Running EET inference + ILP...[/bold]")
    solution = predict(
        model,
        graph=graph,
        solver_config=config.solver,
        window_size=config.window_size,
        test_time_augs=config.test_time_augs,
    )
    print(f"[green]Solution:[/green] {solution.num_nodes()} nodes, {solution.num_edges()} edges")

    tracks_df, track_graph, _ = td.functional.to_napari_format(solution, mask_key="mask")

    print(f"\n[bold]Saving GEFF[/bold] → {geff_path}")
    if geff_path.exists():
        import shutil

        shutil.rmtree(geff_path)
    solution.to_geff(str(geff_path))

    print(f"[bold]Saving CSV[/bold]  → {csv_path}")
    tracks_df.write_csv(str(csv_path))

    # Summary statistics
    lengths_df = tracks_df.group_by("tracklet_id").len()
    lengths_by_id = dict(
        zip(
            lengths_df["tracklet_id"].to_list(),
            lengths_df["len"].to_list(),
            strict=True,
        )
    )
    lineage_stats = _compute_lineage_stats(track_graph, lengths_by_id)
    parents = list(track_graph.values())
    n_divisions = sum(1 for p in set(parents) if parents.count(p) > 1)

    print(
        f"\n## Tracking summary — {config.fov_key}\n\n"
        f"| Metric | Value |\n"
        f"|--------|-------|\n"
        f"| Tracklets | {tracks_df['tracklet_id'].n_unique()} |\n"
        f"| Lineages | {lineage_stats['n_lineages']} |\n"
        f"| Divisions | {n_divisions} |\n"
        f"| Lineage median | {lineage_stats['median']:.1f} |\n"
        f"| Lineage max | {lineage_stats['max']} |\n"
    )

    return geff_path
