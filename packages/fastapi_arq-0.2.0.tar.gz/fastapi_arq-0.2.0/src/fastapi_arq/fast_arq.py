from __future__ import annotations

import contextlib
from collections.abc import AsyncIterator, Callable
from typing import Any

from arq.connections import RedisSettings
from fastapi import FastAPI

from fastapi_arq.arq_redis import ArqRedis
from fastapi_arq.context_builder import ContextBuilder
from fastapi_arq.health import build_router
from fastapi_arq.models import CronConfig, TaskConfig, WorkerSettings
from fastapi_arq.task_registry import TaskRegistry
from fastapi_arq.worker_manager import ArqWorker, WorkerManager


class FastArq:
    def __init__(
        self,
        app: FastAPI,
        redis_settings: RedisSettings | str,
        context_dependencies: list[Callable[..., Any]] | None = None,
        worker_concurrency: int = 10,
        poll_delay: float = 0.5,
        health_prefix: str = "/arq",
        run_worker: bool = True,
    ) -> None:
        self._app = app
        self._redis_settings = (
            RedisSettings.from_dsn(redis_settings)
            if isinstance(redis_settings, str)
            else redis_settings
        )
        self._registry = TaskRegistry()
        self._context_builder = ContextBuilder(context_dependencies)
        self._worker_manager = WorkerManager(
            concurrency=worker_concurrency,
            poll_delay=poll_delay,
        )
        self._health_prefix = health_prefix
        self._arq_redis: ArqRedis | None = None
        self._existing_lifespan = app.router.lifespan_context
        self._health_router: object = None
        self._run_worker = run_worker

        app.router.lifespan_context = self._lifespan

    @contextlib.asynccontextmanager
    async def _lifespan(self, app: FastAPI) -> AsyncIterator[dict[str, Any]]:
        if self._existing_lifespan:
            async with self._existing_lifespan(app) as state:
                await self._startup()
                yield dict(state) if state else {}
        else:
            await self._startup()
            yield {}
        await self._shutdown()

    async def _startup(self) -> None:
        self._arq_redis = ArqRedis(
            registry=self._registry,
            host=self._redis_settings.host,
            port=self._redis_settings.port,
            db=self._redis_settings.database,
            username=self._redis_settings.username,
            password=self._redis_settings.password,
            socket_connect_timeout=self._redis_settings.conn_timeout,
            ssl=self._redis_settings.ssl,
        )
        if not self._run_worker:
            return
        ctx = await self._context_builder.build()
        functions = self._registry.build_arq_functions()
        cron_jobs = self._registry.build_cron_jobs()
        await self._worker_manager.start(self._arq_redis, functions, ctx, cron_jobs)

    async def _shutdown(self) -> None:
        await self._worker_manager.stop()
        await self._context_builder.shutdown()
        if self._arq_redis is not None:
            await self._arq_redis.close()
            self._arq_redis = None

    def task(
        self,
        max_tries: int = 1,
        timeout: int | None = None,
        keep_result: int | None = None,
        unique: bool = False,
    ) -> Callable[..., Any]:
        def decorator(func: Callable[..., Any]) -> Callable[..., Any]:
            config = TaskConfig(
                max_tries=max_tries,
                timeout=timeout,
                keep_result=keep_result,
                unique=unique,
            )
            self._registry.register(func, config)
            return func

        return decorator

    def cron(
        self,
        month: set[int] | int | None = None,
        day: set[int] | int | None = None,
        weekday: set[int] | int | str | None = None,
        hour: set[int] | int | None = None,
        minute: set[int] | int | None = None,
        second: set[int] | int = 0,
        microsecond: int = 123456,
        run_at_startup: bool = False,
        unique: bool = True,
        job_id: str | None = None,
        max_tries: int = 1,
        timeout: int | None = None,
        keep_result: int | None = None,
    ) -> Callable[..., Any]:
        def decorator(func: Callable[..., Any]) -> Callable[..., Any]:
            task_config = TaskConfig(
                max_tries=max_tries,
                timeout=timeout,
                keep_result=keep_result,
            )
            cron_config = CronConfig(
                month=month,
                day=day,
                weekday=weekday,
                hour=hour,
                minute=minute,
                second=second,
                microsecond=microsecond,
                run_at_startup=run_at_startup,
                unique=unique,
                job_id=job_id,
            )
            self._registry.register_cron(func, task_config, cron_config)
            return func

        return decorator

    @property
    def health_router(self) -> Any:
        if self._health_router is None:
            self._health_router = build_router(
                self.get_redis, prefix=self._health_prefix
            )
        return self._health_router

    async def get_redis(self) -> ArqRedis:
        if self._arq_redis is None:
            raise RuntimeError("ArqRedis not initialized. Is the app running?")
        return self._arq_redis

    @property
    def worker_settings(self) -> WorkerSettings:
        return WorkerSettings(
            redis_settings=self._redis_settings,
            functions=self._registry.build_arq_functions(),
            cron_jobs=self._registry.build_cron_jobs(),
            context_dependencies=self._context_builder.dependencies,
            concurrency=self._worker_manager._concurrency,
            poll_delay=self._worker_manager._poll_delay,
        )

    @property
    def worker_runner(self) -> ArqWorker:
        return ArqWorker(self.worker_settings)
