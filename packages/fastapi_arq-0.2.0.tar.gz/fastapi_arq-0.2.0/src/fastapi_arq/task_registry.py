from __future__ import annotations

from collections.abc import Callable
from typing import Any

from arq.cron import CronJob

from fastapi_arq.models import CronConfig, TaskConfig


class TaskRegistry:
    def __init__(self) -> None:
        self._tasks: dict[str, tuple[Callable[..., Any], TaskConfig]] = {}
        self._cron_tasks: list[tuple[Callable[..., Any], TaskConfig, CronConfig]] = []

    def register(self, func: Callable[..., Any], config: TaskConfig) -> None:
        self._tasks[func.__name__] = (func, config)

    def register_cron(
        self, func: Callable[..., Any], task_config: TaskConfig, cron_config: CronConfig
    ) -> None:
        self._tasks[func.__name__] = (func, task_config)
        self._cron_tasks.append((func, task_config, cron_config))

    def build_arq_functions(self) -> list[Callable[..., Any]]:
        functions: list[Callable[..., Any]] = []
        for name, (func, config) in self._tasks.items():
            wrapped = self._wrap_task(func, config)
            wrapped.__name__ = name
            functions.append(wrapped)
        return functions

    def build_cron_jobs(self) -> list[CronJob]:
        jobs: list[CronJob] = []
        for func, task_config, cron_config in self._cron_tasks:
            wrapped = self._wrap_task(func, task_config)
            job = CronJob(
                name=wrapped.__name__,
                coroutine=wrapped,
                month=cron_config.month,
                day=cron_config.day,
                weekday=cron_config.weekday,  # type: ignore[arg-type]
                hour=cron_config.hour,
                minute=cron_config.minute,
                second=cron_config.second,
                microsecond=cron_config.microsecond,
                run_at_startup=cron_config.run_at_startup,
                unique=cron_config.unique,
                job_id=cron_config.job_id,
                timeout_s=task_config.timeout,
                keep_result_s=task_config.keep_result,
                keep_result_forever=None,
                max_tries=task_config.max_tries,
            )
            jobs.append(job)
        return jobs

    @staticmethod
    def _wrap_task(func: Callable[..., Any], config: TaskConfig) -> Callable[..., Any]:
        async def wrapped(ctx: dict[str, Any], *args: Any, **kwargs: Any) -> Any:
            return await func(ctx, *args, **kwargs)

        wrapped.__name__ = func.__name__
        wrapped.__qualname__ = func.__qualname__
        setattr(wrapped, "max_tries", config.max_tries)
        setattr(wrapped, "keep_result", config.keep_result)
        if config.timeout is not None:
            setattr(wrapped, "timeout", config.timeout)
        return wrapped
