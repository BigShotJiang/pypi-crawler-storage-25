from __future__ import annotations

from datetime import datetime, timedelta
from hashlib import md5
from typing import Any

from arq.connections import ArqRedis as _ArqRedis
from arq.jobs import Job

from fastapi_arq.task_registry import TaskRegistry


class ArqRedis(_ArqRedis):
    def __init__(self, *args: Any, registry: TaskRegistry | None = None, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)
        self._registry = registry or TaskRegistry()

    async def enqueue(
        self,
        function: Any,
        *args: Any,
        _job_id: str | None = None,
        _defer_until: datetime | None = None,
        _defer_by: timedelta | float | None = None,
        **kwargs: Any,
    ) -> Job | None:
        return await self.enqueue_job(
            function.__name__,
            *args,
            _job_id=_job_id,
            _defer_until=_defer_until,
            _defer_by=_defer_by,
            **kwargs,
        )

    async def enqueue_unique(
        self,
        function: Any,
        *args: Any,
        ttl: int = 3600,
        _job_id: str | None = None,
        **kwargs: Any,
    ) -> Job | None:
        raw = md5(repr((function.__name__, args, kwargs)).encode()).hexdigest()
        key = f"unique:{function.__name__}:{raw}"
        ok = await self.setnx(key, "1")
        if not ok:
            return None
        await self.expire(key, ttl)
        return await self.enqueue(function, *args, _job_id=_job_id, **kwargs)
