from __future__ import annotations

import asyncio
import time
from collections.abc import Callable
from typing import Any

from fastapi import APIRouter, Response, status

from fastapi_arq.models import HealthStatus


def build_router(
    get_redis: Callable[[], Any], prefix: str = "/arq"
) -> APIRouter:
    router = APIRouter(prefix=prefix, tags=["arq"])

    @router.get("/health", response_model=HealthStatus)
    async def health() -> HealthStatus:
        try:
            redis = await get_redis()
        except RuntimeError:
            return HealthStatus(status="error", redis_ping_ms=None)

        start = time.monotonic()
        try:
            pong = await asyncio.wait_for(redis.ping(), timeout=5)
            latency = (time.monotonic() - start) * 1000
            if not pong:
                return HealthStatus(status="error", redis_ping_ms=None)
        except Exception:
            return HealthStatus(status="error", redis_ping_ms=None)

        return HealthStatus(
            status="ok",
            redis_ping_ms=round(latency, 1),
        )

    @router.get("/health/live")
    async def health_live() -> dict[str, str]:
        return {"status": "alive"}

    @router.get("/health/ready", status_code=status.HTTP_503_SERVICE_UNAVAILABLE)
    async def health_ready(response: Response) -> dict[str, str]:
        try:
            redis = await get_redis()
            await asyncio.wait_for(redis.ping(), timeout=2)
            response.status_code = status.HTTP_200_OK
            return {"status": "ready"}
        except Exception:
            return {"status": "not ready"}

    return router
