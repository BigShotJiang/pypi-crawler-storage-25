from __future__ import annotations

from importlib.metadata import version

from fastapi_arq.arq_redis import ArqRedis
from fastapi_arq.fast_arq import FastArq
from fastapi_arq.models import CronConfig, TaskConfig, WorkerSettings
from fastapi_arq.worker_manager import ArqWorker

__all__ = ["FastArq", "ArqRedis", "ArqWorker", "TaskConfig", "CronConfig", "WorkerSettings"]
__version__ = version("fastapi-arq")
