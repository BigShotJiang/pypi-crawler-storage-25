from __future__ import annotations

import inspect
from collections.abc import Callable
from typing import Any

from fastapi.params import Depends


class ContextBuilder:
    def __init__(self, dependencies: list[Callable[..., Any]] | None = None) -> None:
        self._dependencies = dependencies or []
        self._cleanups: list[Callable[[], Any]] = []

    @property
    def dependencies(self) -> list[Callable[..., Any]]:
        return list(self._dependencies)

    async def build(self) -> dict[str, Any]:
        ctx: dict[str, Any] = {}
        self._cleanups.clear()
        for dep in self._dependencies:
            callable = dep.dependency if isinstance(dep, Depends) else dep
            key = getattr(callable, "__name__", type(callable).__name__)
            result = callable()
            if inspect.isasyncgen(result):
                value = await anext(result)
                self._cleanups.append(result.aclose)
            elif inspect.iscoroutine(result):
                value = await result
            else:
                value = result
            ctx[key] = value
        return ctx

    async def shutdown(self) -> None:
        for cleanup in self._cleanups:
            await cleanup()
        self._cleanups.clear()
