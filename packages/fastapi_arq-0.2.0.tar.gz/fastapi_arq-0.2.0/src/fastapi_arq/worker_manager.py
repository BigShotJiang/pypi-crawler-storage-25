from __future__ import annotations

import asyncio
from collections.abc import Callable
from typing import Any

from arq.connections import ArqRedis as _ArqRedis
from arq.cron import CronJob
from arq.worker import Worker

from fastapi_arq.context_builder import ContextBuilder
from fastapi_arq.models import WorkerSettings


class WorkerManager:
    def __init__(self, concurrency: int = 10, poll_delay: float = 0.5) -> None:
        self._concurrency = concurrency
        self._poll_delay = poll_delay
        self._worker: Worker | None = None
        self._task: asyncio.Task[Any] | None = None

    async def start(
        self,
        redis: _ArqRedis,
        functions: list[Callable[..., Any]],
        ctx: dict[str, Any],
        cron_jobs: list[CronJob] | None = None,
    ) -> None:
        self._worker = Worker(
            functions,
            redis_pool=redis,
            ctx=ctx,
            cron_jobs=cron_jobs or None,
            max_jobs=self._concurrency,
            poll_delay=self._poll_delay,
            handle_signals=False,
        )
        self._task = asyncio.create_task(self._worker.main())

    async def stop(self) -> None:
        if self._task is not None:
            self._task.cancel()
            try:
                await asyncio.wait_for(self._task, timeout=10)
            except (asyncio.CancelledError, TimeoutError):
                pass
            except Exception:
                pass
            self._task = None
        if self._worker is not None:
            try:
                await asyncio.wait_for(self._worker.close(), timeout=5)
            except TimeoutError:
                pass
            self._worker = None


class ArqWorker:
    def __init__(self, settings: WorkerSettings) -> None:
        self._settings = settings
        self._context_builder = ContextBuilder(settings.context_dependencies)
        self._cleanups: list[Callable[[], Any]] = []

    async def run(self) -> None:
        ctx = await self._context_builder.build()
        worker = Worker(
            self._settings.functions,
            redis_settings=self._settings.redis_settings,
            ctx=ctx,
            cron_jobs=self._settings.cron_jobs,
            max_jobs=self._settings.concurrency,
            poll_delay=self._settings.poll_delay,
            handle_signals=True,
        )
        try:
            await worker.main()
        finally:
            await self._context_builder.shutdown()
