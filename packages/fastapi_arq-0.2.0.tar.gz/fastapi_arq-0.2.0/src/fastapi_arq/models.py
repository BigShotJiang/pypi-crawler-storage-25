from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass, field
from typing import Any

from arq.connections import RedisSettings
from arq.cron import CronJob
from pydantic import BaseModel, Field


class TaskConfig(BaseModel):
    max_tries: int = 1
    timeout: int | None = None
    keep_result: int | None = None
    unique: bool = False


@dataclass
class WorkerSettings:
    redis_settings: RedisSettings
    functions: list[Callable[..., Any]]
    cron_jobs: list[CronJob] | None = None
    context_dependencies: list[Callable[..., Any]] = field(default_factory=list)
    concurrency: int = 10
    poll_delay: float = 0.5


class CronConfig(BaseModel):
    month: set[int] | int | None = None
    day: set[int] | int | None = None
    weekday: set[int] | int | str | None = None
    hour: set[int] | int | None = None
    minute: set[int] | int | None = None
    second: set[int] | int = 0
    microsecond: int = 123456
    run_at_startup: bool = False
    unique: bool = True
    job_id: str | None = None


class HealthStatus(BaseModel):
    status: str = Field(..., description="Overall health: ok or error")
    redis_ping_ms: float | None = Field(None, description="Redis ping latency in ms")
    queues: dict[str, int] = Field(
        default_factory=dict, description="Queue name -> job count"
    )
