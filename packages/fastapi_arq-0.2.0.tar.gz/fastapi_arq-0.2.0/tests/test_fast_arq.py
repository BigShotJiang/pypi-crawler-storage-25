from __future__ import annotations

import asyncio
import logging
from typing import Any
from unittest.mock import AsyncMock, patch

import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient

from fastapi_arq import ArqWorker, FastArq
from fastapi_arq.arq_redis import ArqRedis
from fastapi_arq.context_builder import ContextBuilder
from fastapi_arq.health import build_router
from fastapi_arq.models import CronConfig, HealthStatus, TaskConfig, WorkerSettings
from fastapi_arq.task_registry import TaskRegistry
from fastapi_arq.worker_manager import WorkerManager

# ══════════════════════════════════════════════════════════════════════════
#  TaskRegistry
# ══════════════════════════════════════════════════════════════════════════


class TestContextBuilderPositive:
    @pytest.mark.asyncio
    async def test_sync_dependency(self, ctx_db: Any) -> None:
        builder = ContextBuilder([ctx_db])
        ctx = await builder.build()
        assert ctx["get_db"] == "db_session"

    @pytest.mark.asyncio
    async def test_async_dependency(self, ctx_s3: Any) -> None:
        builder = ContextBuilder([ctx_s3])
        ctx = await builder.build()
        assert ctx["get_s3"] == "s3_client"

    @pytest.mark.asyncio
    async def test_depends_wrapper(self) -> None:
        from fastapi.params import Depends

        def get_db() -> str:
            return "db_session"

        builder = ContextBuilder([Depends(get_db)])
        ctx = await builder.build()
        assert ctx["get_db"] == "db_session"

    @pytest.mark.asyncio
    async def test_multiple_dependencies(self, ctx_db: Any, ctx_s3: Any) -> None:
        builder = ContextBuilder([ctx_db, ctx_s3])
        ctx = await builder.build()
        assert ctx["get_db"] == "db_session"
        assert ctx["get_s3"] == "s3_client"

    @pytest.mark.asyncio
    async def test_async_generator_with_cleanup(self) -> None:
        clean: list[str] = []

        async def get_engine():
            try:
                yield "engine_ref"
            finally:
                clean.append("closed")

        builder = ContextBuilder([get_engine])
        ctx = await builder.build()
        assert ctx["get_engine"] == "engine_ref"
        assert clean == []

        await builder.shutdown()
        assert clean == ["closed"]

    @pytest.mark.asyncio
    async def test_build_idempotent(self, ctx_db: Any) -> None:
        builder = ContextBuilder([ctx_db])
        first = await builder.build()
        second = await builder.build()
        assert first == second

    @pytest.mark.asyncio
    async def test_dependency_without_name(self) -> None:
        dep = lambda: 42  # noqa: E731
        builder = ContextBuilder([dep])
        ctx = await builder.build()
        assert ctx.get("<lambda>") == 42

    @pytest.mark.asyncio
    async def test_dependencies_property(self) -> None:
        def db() -> str:
            return "db"

        def s3() -> str:
            return "s3"

        builder = ContextBuilder([db, s3])
        deps = builder.dependencies
        assert deps == [db, s3]
        assert deps is not builder._dependencies


class TestContextBuilderNegative:
    @pytest.mark.asyncio
    async def test_empty_list(self) -> None:
        builder = ContextBuilder([])
        ctx = await builder.build()
        assert ctx == {}

    @pytest.mark.asyncio
    async def test_none_dependencies(self) -> None:
        builder = ContextBuilder(None)
        ctx = await builder.build()
        assert ctx == {}

    @pytest.mark.asyncio
    async def test_shutdown_without_build(self) -> None:
        builder = ContextBuilder()
        await builder.shutdown()

    @pytest.mark.asyncio
    async def test_dependency_raises(self) -> None:
        def broken() -> None:
            raise RuntimeError("db down")

        builder = ContextBuilder([broken])
        with pytest.raises(RuntimeError, match="db down"):
            await builder.build()

    @pytest.mark.asyncio
    async def test_async_dependency_raises(self) -> None:
        async def broken() -> None:
            raise RuntimeError("s3 down")

        builder = ContextBuilder([broken])
        with pytest.raises(RuntimeError, match="s3 down"):
            await builder.build()


class TestTaskRegistryPositive:
    def test_register_minimal(self, registry: TaskRegistry, sample_task: Any) -> None:
        registry.register(sample_task, TaskConfig())
        assert sample_task.__name__ in registry._tasks

    def test_register_full_config(self, registry: TaskRegistry, sample_task: Any) -> None:
        config = TaskConfig(max_tries=5, timeout=300, keep_result=3600, unique=True)
        registry.register(sample_task, config)
        _, stored = registry._tasks[sample_task.__name__]
        assert stored.max_tries == 5
        assert stored.timeout == 300
        assert stored.keep_result == 3600
        assert stored.unique is True

    def test_build_functions_have_arq_attrs(self, registry: TaskRegistry, sample_task: Any) -> None:
        registry.register(sample_task, TaskConfig(max_tries=3, keep_result=120, timeout=60))
        funcs = registry.build_arq_functions()
        f = funcs[0]
        assert f.max_tries == 3
        assert f.keep_result == 120
        assert f.timeout == 60

    def test_build_preserves_name(self, registry: TaskRegistry, sample_task: Any) -> None:
        registry.register(sample_task, TaskConfig())
        funcs = registry.build_arq_functions()
        assert funcs[0].__name__ == sample_task.__name__

    def test_build_preserves_args_kwargs(self, registry: TaskRegistry) -> None:
        async def task(ctx: dict, a: int, b: str) -> str:
            return f"{a}:{b}"

        registry.register(task, TaskConfig())
        funcs = registry.build_arq_functions()
        result = asyncio.run(funcs[0]({}, a=1, b="x"))
        assert result == "1:x"

    def test_multiple_tasks_distinct(self, registry: TaskRegistry) -> None:
        async def ta(ctx: dict) -> int:
            return 1

        async def tb(ctx: dict) -> int:
            return 2

        registry.register(ta, TaskConfig())
        registry.register(tb, TaskConfig())
        assert len(registry._tasks) == 2

    def test_context_passed_through(self, registry: TaskRegistry) -> None:
        async def task(ctx: dict) -> str:
            return ctx["key"]

        registry.register(task, TaskConfig())
        funcs = registry.build_arq_functions()
        result = asyncio.run(funcs[0]({"key": "val"}))
        assert result == "val"

    def test_timeout_not_set_when_none(self, registry: TaskRegistry) -> None:
        async def task(ctx: dict) -> None:
            pass

        registry.register(task, TaskConfig(timeout=None))
        funcs = registry.build_arq_functions()
        assert not hasattr(funcs[0], "timeout")

    def test_keep_result_zero(self, registry: TaskRegistry) -> None:
        async def task(ctx: dict) -> None:
            pass

        registry.register(task, TaskConfig(keep_result=0))
        funcs = registry.build_arq_functions()
        assert funcs[0].keep_result == 0

    def test_same_name_overwrites_config(self, registry: TaskRegistry) -> None:
        async def task(ctx: dict) -> int:
            return 1

        registry.register(task, TaskConfig(max_tries=1))
        registry.register(task, TaskConfig(max_tries=9))
        _func, config = registry._tasks["task"]
        assert config.max_tries == 9


class TestTaskRegistryNegative:
    def test_empty_registry_returns_empty_list(self, registry: TaskRegistry) -> None:
        assert registry.build_arq_functions() == []

    def test_build_is_idempotent(self, registry: TaskRegistry, sample_task: Any) -> None:
        registry.register(sample_task, TaskConfig())
        first = registry.build_arq_functions()
        second = registry.build_arq_functions()
        assert len(first) == len(second)
        assert first[0] is not second[0]

    def test_wrapper_raises_on_missing_ctx_key(self, registry: TaskRegistry) -> None:
        async def task(ctx: dict) -> str:
            return ctx["missing"]

        registry.register(task, TaskConfig())
        funcs = registry.build_arq_functions()
        with pytest.raises(KeyError):
            asyncio.run(funcs[0]({}))

    def test_wrapper_propagates_exception(self, registry: TaskRegistry) -> None:
        async def task(ctx: dict) -> None:
            raise ValueError("bad")

        registry.register(task, TaskConfig())
        funcs = registry.build_arq_functions()
        with pytest.raises(ValueError, match="bad"):
            asyncio.run(funcs[0]({}))


# ══════════════════════════════════════════════════════════════════════════
#  Cron
# ══════════════════════════════════════════════════════════════════════════


class TestCronPositive:
    def test_register_cron_adds_to_both(self, registry: TaskRegistry) -> None:
        async def task(ctx: dict) -> None:
            pass

        registry.register_cron(task, TaskConfig(), CronConfig(hour=6, minute=0))
        assert task.__name__ in registry._tasks
        assert len(registry._cron_tasks) == 1

    def test_cron_job_has_correct_schedule(self, registry: TaskRegistry) -> None:
        async def task(ctx: dict) -> None:
            pass

        registry.register_cron(task, TaskConfig(), CronConfig(hour=6, minute=30, second=0))
        jobs = registry.build_cron_jobs()
        assert len(jobs) == 1
        assert jobs[0].name == "task"
        assert jobs[0].hour == 6
        assert jobs[0].minute == 30

    def test_cron_job_inherits_task_config(self, registry: TaskRegistry) -> None:
        async def task(ctx: dict) -> None:
            pass

        registry.register_cron(
            task,
            TaskConfig(max_tries=5, timeout=120, keep_result=3600),
            CronConfig(hour=0, minute=0),
        )
        jobs = registry.build_cron_jobs()
        assert jobs[0].max_tries == 5
        assert jobs[0].timeout_s == 120
        assert jobs[0].keep_result_s == 3600

    def test_multiple_cron_jobs(self, registry: TaskRegistry) -> None:
        async def cleanup(ctx: dict) -> None:
            pass

        async def report(ctx: dict) -> None:
            pass

        registry.register_cron(cleanup, TaskConfig(), CronConfig(hour=6, minute=0))
        registry.register_cron(report, TaskConfig(), CronConfig(hour=18, minute=0))
        jobs = registry.build_cron_jobs()
        assert len(jobs) == 2

    def test_cron_unique_default_true(self, registry: TaskRegistry) -> None:
        async def task(ctx: dict) -> None:
            pass

        registry.register_cron(task, TaskConfig(), CronConfig(hour=6, minute=0))
        jobs = registry.build_cron_jobs()
        assert jobs[0].unique is True

    def test_cron_run_at_startup(self, registry: TaskRegistry) -> None:
        async def task(ctx: dict) -> None:
            pass

        registry.register_cron(
            task, TaskConfig(), CronConfig(hour=6, minute=0, run_at_startup=True)
        )
        jobs = registry.build_cron_jobs()
        assert jobs[0].run_at_startup is True

    def test_cron_with_kwargs_all(self, registry: TaskRegistry) -> None:
        async def task(ctx: dict) -> None:
            pass

        registry.register_cron(
            task,
            TaskConfig(max_tries=3),
            CronConfig(month={1, 6}, day=15, weekday=0, hour=12, minute=30, second=0),
        )
        jobs = registry.build_cron_jobs()
        assert jobs[0].month == {1, 6}
        assert jobs[0].day == 15
        assert jobs[0].weekday == 0

    def test_cron_job_function_is_async(self, registry: TaskRegistry) -> None:
        async def task(ctx: dict) -> str:
            return ctx.get("key", "default")

        registry.register_cron(task, TaskConfig(), CronConfig(hour=6, minute=0))
        jobs = registry.build_cron_jobs()
        import asyncio
        result = asyncio.run(jobs[0].coroutine({"key": "val"}))
        assert result == "val"

    def test_cron_is_also_regular_task(self, registry: TaskRegistry) -> None:
        """Cron-registered functions are also available as regular tasks."""
        async def task(ctx: dict) -> None:
            pass

        registry.register_cron(task, TaskConfig(max_tries=7), CronConfig(hour=6, minute=0))
        funcs = registry.build_arq_functions()
        assert len(funcs) == 1
        assert funcs[0].__name__ == "task"
        assert funcs[0].max_tries == 7


class TestCronNegative:
    def test_empty_cron_returns_empty_list(self, registry: TaskRegistry) -> None:
        assert registry.build_cron_jobs() == []

    def test_no_cron_does_not_affect_regular(self, registry: TaskRegistry) -> None:
        async def task(ctx: dict) -> None:
            pass

        registry.register(task, TaskConfig())
        assert registry.build_cron_jobs() == []
        assert len(registry.build_arq_functions()) == 1


# ══════════════════════════════════════════════════════════════════════════
#  FastArq
# ══════════════════════════════════════════════════════════════════════════


class TestFastArqPositive:
    def test_create_with_str_redis(self, app: FastAPI) -> None:
        arq = FastArq(app, redis_settings="redis://localhost:6379")
        assert arq._redis_settings.host == "localhost"
        assert arq._redis_settings.port == 6379

    def test_create_with_redis_settings_object(self, app: FastAPI) -> None:
        from arq.connections import RedisSettings

        rs = RedisSettings(host="10.0.0.1", port=6380, database=1)
        arq = FastArq(app, redis_settings=rs)
        assert arq._redis_settings.host == "10.0.0.1"
        assert arq._redis_settings.port == 6380
        assert arq._redis_settings.database == 1

    def test_task_decorator_registers(self, app: FastAPI) -> None:
        arq = FastArq(app, redis_settings="redis://localhost:6379")

        @arq.task(max_tries=3, timeout=120)
        async def my_task(ctx: dict, user_id: int) -> int:
            return user_id

        assert "my_task" in arq._registry._tasks
        _func, config = arq._registry._tasks["my_task"]
        assert config.max_tries == 3
        assert config.timeout == 120

    def test_task_decorator_with_parens(self, app: FastAPI) -> None:
        """@arq.task() works (explicit call)."""
        arq = FastArq(app, redis_settings="redis://localhost:6379")

        @arq.task()
        async def simple_task(ctx: dict) -> str:
            return "done"

        assert "simple_task" in arq._registry._tasks

    def test_multiple_tasks_decorated(self, app: FastAPI) -> None:
        arq = FastArq(app, redis_settings="redis://localhost:6379")

        @arq.task(max_tries=1)
        async def task_a(ctx: dict) -> None:
            pass

        @arq.task(max_tries=5, timeout=60)
        async def task_b(ctx: dict) -> None:
            pass

        assert len(arq._registry._tasks) == 2

    def test_task_keeps_callable(self, app: FastAPI) -> None:
        arq = FastArq(app, redis_settings="redis://localhost:6379")

        @arq.task(max_tries=3)
        async def my_task(ctx: dict) -> str:
            return "original"

        assert callable(my_task)
        result = asyncio.run(my_task({}))
        assert result == "original"

    def test_health_router_routes(self, app: FastAPI) -> None:
        arq = FastArq(app, redis_settings="redis://localhost:6379")
        router = arq.health_router
        routes = {r.path for r in router.routes}
        assert routes == {"/arq/health", "/arq/health/live", "/arq/health/ready"}

    def test_health_router_custom_prefix(self, app: FastAPI) -> None:
        arq = FastArq(app, redis_settings="redis://localhost:6379", health_prefix="/custom")
        router = arq.health_router
        assert router.prefix == "/custom"

    def test_health_router_cached(self, app: FastAPI) -> None:
        arq = FastArq(app, redis_settings="redis://localhost:6379")
        assert arq.health_router is arq.health_router

    def test_context_dependencies_stored(self, app: FastAPI) -> None:
        def get_db() -> str:
            return "db_session"

        arq = FastArq(app, redis_settings="redis://localhost:6379", context_dependencies=[get_db])
        assert len(arq._context_builder._dependencies) == 1

    def test_redis_dsn_parsed(self, app: FastAPI) -> None:
        arq = FastArq(app, redis_settings="redis://user:pass@remote:6380/2")
        assert arq._redis_settings.host == "remote"
        assert arq._redis_settings.port == 6380
        assert arq._redis_settings.database == 2
        assert arq._redis_settings.password == "pass"

    def test_lifespan_is_bound_to_app(self, app: FastAPI) -> None:
        FastArq(app, redis_settings="redis://localhost:6379")
        assert app.router.lifespan_context is not None
        assert callable(app.router.lifespan_context)

    def test_worker_concurrency_passed(self, app: FastAPI) -> None:
        arq = FastArq(app, redis_settings="redis://localhost:6379", worker_concurrency=5)
        assert arq._worker_manager._concurrency == 5

    def test_run_worker_false_skips_worker(self, app: FastAPI) -> None:
        arq = FastArq(app, redis_settings="redis://localhost:6379", run_worker=False)
        assert arq._run_worker is False
        assert arq._worker_manager._task is None
        assert arq._worker_manager._worker is None

    @pytest.mark.asyncio
    async def test_run_worker_false_startup_creates_redis(self, app: FastAPI) -> None:
        arq = FastArq(app, redis_settings="redis://localhost:6379", run_worker=False)
        await arq._startup()
        assert arq._arq_redis is not None
        assert arq._worker_manager._task is None
        await arq._shutdown()

    @pytest.mark.asyncio
    async def test_run_worker_true_startup_starts_worker(self, app: FastAPI) -> None:
        """With run_worker=True (default), startup starts the worker."""
        from unittest.mock import patch

        arq = FastArq(app, redis_settings="redis://localhost:6379", run_worker=True)

        @arq.task()
        async def dummy(ctx: dict) -> None:
            pass

        with patch.object(arq, "_arq_redis"):
            await arq._startup()
            assert arq._worker_manager._task is not None
            await arq._shutdown()

    def test_worker_settings_property(self, app: FastAPI) -> None:
        arq = FastArq(app, redis_settings="redis://localhost:6379")
        ws = arq.worker_settings
        assert ws.redis_settings.host == "localhost"
        assert ws.concurrency == 10
        assert ws.poll_delay == 0.5
        assert ws.functions == []
        assert ws.cron_jobs == []
        assert ws.context_dependencies == []

    def test_worker_settings_with_tasks(self, app: FastAPI) -> None:
        arq = FastArq(app, redis_settings="redis://localhost:6379")

        @arq.task(max_tries=3)
        async def my_task(ctx: dict) -> None:
            pass

        ws = arq.worker_settings
        assert len(ws.functions) == 1
        assert ws.functions[0].__name__ == "my_task"
        assert ws.functions[0].max_tries == 3

    def test_worker_runner_property(self, app: FastAPI) -> None:
        arq = FastArq(app, redis_settings="redis://localhost:6379")
        runner = arq.worker_runner
        assert isinstance(runner, ArqWorker)
        assert runner._settings.redis_settings.host == "localhost"


class TestFastArqNegative:
    def test_get_redis_before_startup_raises(self, app: FastAPI) -> None:
        arq = FastArq(app, redis_settings="redis://localhost:6379")
        with pytest.raises(RuntimeError, match="not initialized"):
            asyncio.run(arq.get_redis())

    def test_get_redis_after_shutdown_raises(self, app: FastAPI) -> None:
        arq = FastArq(app, redis_settings="redis://localhost:6379")
        asyncio.run(arq._shutdown())
        with pytest.raises(RuntimeError, match="not initialized"):
            asyncio.run(arq.get_redis())

    def test_invalid_redis_dsn_raises(self, app: FastAPI) -> None:
        with pytest.raises((ValueError, Exception)):
            FastArq(app, redis_settings="not-a-valid-url!")


class TestFastArqEdge:
    def test_empty_context_dependencies(self, app: FastAPI) -> None:
        arq = FastArq(app, redis_settings="redis://localhost:6379", context_dependencies=[])
        assert arq._context_builder._dependencies == []

    def test_task_unique_flag(self, app: FastAPI) -> None:
        arq = FastArq(app, redis_settings="redis://localhost:6379")

        @arq.task(unique=True)
        async def unique_task(ctx: dict) -> None:
            pass

        _func, config = arq._registry._tasks["unique_task"]
        assert config.unique is True

    def test_task_keep_result_default(self, app: FastAPI) -> None:
        arq = FastArq(app, redis_settings="redis://localhost:6379")

        @arq.task()
        async def my_task(ctx: dict) -> None:
            pass

        _func, config = arq._registry._tasks["my_task"]
        assert config.keep_result is None


# ══════════════════════════════════════════════════════════════════════════
#  WorkerManager
# ══════════════════════════════════════════════════════════════════════════


class TestWorkerManagerPositive:
    @pytest.mark.asyncio
    async def test_start_and_stop(self, fake_pool: Any) -> None:
        from arq.connections import ArqRedis as BaseArqRedis

        redis = BaseArqRedis(pool_or_conn=fake_pool)
        registry = TaskRegistry()

        async def task(ctx: dict) -> None:
            pass

        registry.register(task, TaskConfig())
        manager = WorkerManager(concurrency=2, poll_delay=0.5)
        await manager.start(redis, registry.build_arq_functions(), {})
        assert manager._worker is not None
        assert manager._task is not None
        await manager.stop()

    @pytest.mark.asyncio
    async def test_worker_receives_context(self, fake_pool: Any) -> None:
        from arq.connections import ArqRedis as BaseArqRedis

        redis = BaseArqRedis(pool_or_conn=fake_pool)
        registry = TaskRegistry()

        async def task(ctx: dict) -> None:
            pass

        registry.register(task, TaskConfig())
        manager = WorkerManager(poll_delay=0.5)
        ctx = {"custom_key": "custom_val"}
        await manager.start(redis, registry.build_arq_functions(), ctx)
        assert manager._worker is not None
        assert manager._worker.ctx["custom_key"] == "custom_val"
        await manager.stop()

    @pytest.mark.asyncio
    async def test_multiple_stop_calls(self, fake_pool: Any) -> None:
        from arq.connections import ArqRedis as BaseArqRedis

        redis = BaseArqRedis(pool_or_conn=fake_pool)
        registry = TaskRegistry()

        async def task(ctx: dict) -> None:
            pass

        registry.register(task, TaskConfig())
        manager = WorkerManager(poll_delay=0.5)
        await manager.start(redis, registry.build_arq_functions(), {})
        await manager.stop()
        await manager.stop()


class TestWorkerManagerNegative:
    @pytest.mark.asyncio
    async def test_stop_without_start(self) -> None:
        manager = WorkerManager()
        await manager.stop()

    @pytest.mark.asyncio
    async def test_stop_idempotent(self) -> None:
        manager = WorkerManager()
        await manager.stop()
        await manager.stop()
        await manager.stop()

    @pytest.mark.asyncio
    async def test_start_without_functions_raises(self, fake_pool: Any) -> None:
        from arq.connections import ArqRedis as BaseArqRedis

        redis = BaseArqRedis(pool_or_conn=fake_pool)
        manager = WorkerManager(poll_delay=0.5)
        with pytest.raises(RuntimeError, match="at least one function"):
            await manager.start(redis, [], {})


class TestArqWorker:
    def test_create_from_settings(self) -> None:
        from arq.connections import RedisSettings

        ws = WorkerSettings(
            redis_settings=RedisSettings(host="localhost", port=6379),
            functions=[],
            context_dependencies=[],
            concurrency=5,
            poll_delay=0.3,
        )
        worker = ArqWorker(ws)
        assert worker._settings.concurrency == 5
        assert worker._settings.poll_delay == 0.3

    def test_create_with_no_functions(self) -> None:
        from arq.connections import RedisSettings

        ws = WorkerSettings(
            redis_settings=RedisSettings(host="localhost", port=6379),
            functions=[],
        )
        worker = ArqWorker(ws)
        assert worker._settings.functions == []

    @pytest.mark.asyncio
    async def test_run_builds_context(self) -> None:
        from arq.connections import RedisSettings

        calls: list[str] = []

        def get_db() -> str:
            calls.append("db_called")
            return "db_session"

        ws = WorkerSettings(
            redis_settings=RedisSettings(host="localhost", port=6379),
            functions=[],
            context_dependencies=[get_db],
        )
        worker = ArqWorker(ws)
        ctx = await worker._context_builder.build()
        assert ctx == {"get_db": "db_session"}
        await worker._context_builder.shutdown()


class TestWorkerManagerFaultTolerance:
    @pytest.mark.asyncio
    async def test_stop_does_not_hang_when_redis_down(self) -> None:
        """Stop should handle graceful timeout when Redis is unreachable."""
        from arq.connections import ArqRedis as BaseArqRedis

        pool = AsyncMock()
        pool.aclose = AsyncMock()
        pool.connection_pool = pool
        redis = BaseArqRedis(pool_or_conn=pool)
        registry = TaskRegistry()

        async def task(ctx: dict) -> None:
            pass

        registry.register(task, TaskConfig())
        manager = WorkerManager(poll_delay=0.5)
        await manager.start(redis, registry.build_arq_functions(), {})
        await manager.stop()


# ══════════════════════════════════════════════════════════════════════════
#  ArqRedis
# ══════════════════════════════════════════════════════════════════════════


class TestArqRedisPositive:
    @pytest.mark.asyncio
    async def test_enqueue_job_created(self, fake_pool: Any) -> None:
        registry = TaskRegistry()

        async def task(ctx: dict) -> None:
            pass

        registry.register(task, TaskConfig())
        ar = ArqRedis(pool_or_conn=fake_pool, registry=registry)
        job = await ar.enqueue(task, user_id=42)
        assert job is not None
        assert job.job_id is not None
        assert len(str(job.job_id)) > 0

    @pytest.mark.asyncio
    async def test_enqueue_job_in_queue(self, fake_pool: Any) -> None:
        registry = TaskRegistry()

        async def task(ctx: dict) -> None:
            pass

        registry.register(task, TaskConfig())
        ar = ArqRedis(pool_or_conn=fake_pool, registry=registry)
        await ar.enqueue(task, x=1)
        assert await ar.zcard("arq:queue") == 1

    @pytest.mark.asyncio
    async def test_enqueue_with_job_id(self, fake_pool: Any) -> None:
        registry = TaskRegistry()

        async def task(ctx: dict) -> None:
            pass

        registry.register(task, TaskConfig())
        ar = ArqRedis(pool_or_conn=fake_pool, registry=registry)
        job = await ar.enqueue(task, _job_id="my-fixed-id", x=1)
        assert job.job_id == "my-fixed-id"

    @pytest.mark.asyncio
    async def test_enqueue_with_defer_until(self, fake_pool: Any) -> None:
        import time
        from datetime import datetime

        registry = TaskRegistry()

        async def task(ctx: dict) -> None:
            pass

        registry.register(task, TaskConfig())
        ar = ArqRedis(pool_or_conn=fake_pool, registry=registry)
        future = datetime.fromtimestamp(time.time() + 3600)
        job = await ar.enqueue(task, _defer_until=future, x=1)
        score = await ar.zscore("arq:queue", job.job_id)
        assert score is not None
        assert score > time.time()

    @pytest.mark.asyncio
    async def test_enqueue_unique_first(self, fake_pool: Any) -> None:
        registry = TaskRegistry()

        async def task(ctx: dict) -> None:
            pass

        registry.register(task, TaskConfig())
        ar = ArqRedis(pool_or_conn=fake_pool, registry=registry)
        first = await ar.enqueue_unique(task, user_id=42)
        assert first is not None

    @pytest.mark.asyncio
    async def test_enqueue_unique_different_args(self, fake_pool: Any) -> None:
        registry = TaskRegistry()

        async def task(ctx: dict) -> None:
            pass

        registry.register(task, TaskConfig())
        ar = ArqRedis(pool_or_conn=fake_pool, registry=registry)
        assert await ar.enqueue_unique(task, user_id=42) is not None
        assert await ar.enqueue_unique(task, user_id=99) is not None

    @pytest.mark.asyncio
    async def test_enqueue_unique_kwargs_distinguish(self, fake_pool: Any) -> None:
        registry = TaskRegistry()

        async def task(ctx: dict) -> None:
            pass

        registry.register(task, TaskConfig())
        ar = ArqRedis(pool_or_conn=fake_pool, registry=registry)
        assert await ar.enqueue_unique(task, email="a@x") is not None
        assert await ar.enqueue_unique(task, email="b@x") is not None

    @pytest.mark.asyncio
    async def test_enqueue_uses_correct_function_name(self, fake_pool: Any) -> None:
        """The job stores the function name, not the object reference."""
        registry = TaskRegistry()

        async def my_custom_task(ctx: dict) -> None:
            pass

        registry.register(my_custom_task, TaskConfig())
        ar = ArqRedis(pool_or_conn=fake_pool, registry=registry)
        job = await ar.enqueue(my_custom_task)
        raw = await ar.get(f"arq:job:{job.job_id}")
        assert raw is not None
        # arq serializes with pickle; we can at least verify the job ID exists
        assert job.job_id is not None


class TestArqRedisNegative:
    @pytest.mark.asyncio
    async def test_enqueue_unique_duplicate_blocked(self, fake_pool: Any) -> None:
        registry = TaskRegistry()

        async def task(ctx: dict) -> None:
            pass

        registry.register(task, TaskConfig())
        ar = ArqRedis(pool_or_conn=fake_pool, registry=registry)
        assert await ar.enqueue_unique(task, user_id=42) is not None
        duplicate = await ar.enqueue_unique(task, user_id=42)
        assert duplicate is None

    @pytest.mark.asyncio
    async def test_enqueue_unique_only_one_in_queue(self, fake_pool: Any) -> None:
        registry = TaskRegistry()

        async def task(ctx: dict) -> None:
            pass

        registry.register(task, TaskConfig())
        ar = ArqRedis(pool_or_conn=fake_pool, registry=registry)
        await ar.enqueue_unique(task, x=1)
        await ar.enqueue_unique(task, x=1)
        assert await ar.zcard("arq:queue") == 1


class TestArqRedisEdge:
    @pytest.mark.asyncio
    async def test_enqueue_unique_no_args(self, fake_pool: Any) -> None:
        registry = TaskRegistry()

        async def task(ctx: dict) -> None:
            pass

        registry.register(task, TaskConfig())
        ar = ArqRedis(pool_or_conn=fake_pool, registry=registry)
        assert await ar.enqueue_unique(task) is not None

    @pytest.mark.asyncio
    async def test_enqueue_unique_ttl_blocks_immediately(self, fake_pool: Any) -> None:
        registry = TaskRegistry()

        async def task(ctx: dict) -> None:
            pass

        registry.register(task, TaskConfig())
        ar = ArqRedis(pool_or_conn=fake_pool, registry=registry)
        assert await ar.enqueue_unique(task, user_id=1, ttl=1) is not None
        duplicate = await ar.enqueue_unique(task, user_id=1)
        assert duplicate is None

    @pytest.mark.asyncio
    async def test_enqueue_unique_ttl_default(self, fake_pool: Any) -> None:
        registry = TaskRegistry()

        async def task(ctx: dict) -> None:
            pass

        registry.register(task, TaskConfig())
        ar = ArqRedis(pool_or_conn=fake_pool, registry=registry)
        assert await ar.enqueue_unique(task, user_id=1) is not None


# ══════════════════════════════════════════════════════════════════════════
#  Health Router
# ══════════════════════════════════════════════════════════════════════════


class TestHealthRouterPositive:
    def test_live_endpoint(self, mock_get_redis_ok: Any) -> None:
        app = FastAPI()
        router = build_router(mock_get_redis_ok, prefix="/arq")
        app.include_router(router)
        client = TestClient(app)
        resp = client.get("/arq/health/live")
        assert resp.status_code == 200
        assert resp.json() == {"status": "alive"}

    def test_ready_endpoint_ok(self, mock_get_redis_ok: Any) -> None:
        app = FastAPI()
        router = build_router(mock_get_redis_ok, prefix="/arq")
        app.include_router(router)
        client = TestClient(app)
        resp = client.get("/arq/health/ready")
        assert resp.status_code == 200
        assert resp.json() == {"status": "ready"}

    def test_health_endpoint_ok(self, mock_get_redis_ok: Any) -> None:
        app = FastAPI()
        router = build_router(mock_get_redis_ok, prefix="/arq")
        app.include_router(router)
        client = TestClient(app)
        resp = client.get("/arq/health")
        assert resp.status_code == 200
        data = resp.json()
        assert data["status"] == "ok"
        assert data["redis_ping_ms"] is not None
        assert isinstance(data["queues"], dict)

    def test_custom_prefix(self, mock_get_redis_ok: Any) -> None:
        app = FastAPI()
        router = build_router(mock_get_redis_ok, prefix="/custom")
        app.include_router(router)
        client = TestClient(app)
        assert client.get("/custom/health/live").status_code == 200
        assert client.get("/custom/health").status_code == 200


class TestHealthRouterNegative:
    def test_ready_endpoint_fails(self, mock_get_redis_error: Any) -> None:
        app = FastAPI()
        router = build_router(mock_get_redis_error, prefix="/arq")
        app.include_router(router)
        client = TestClient(app)
        resp = client.get("/arq/health/ready")
        assert resp.status_code == 503
        assert resp.json() == {"status": "not ready"}

    def test_health_endpoint_error(self, mock_get_redis_error: Any) -> None:
        app = FastAPI()
        router = build_router(mock_get_redis_error, prefix="/arq")
        app.include_router(router)
        client = TestClient(app)
        resp = client.get("/arq/health")
        assert resp.status_code == 200
        assert resp.json()["status"] == "error"

    def test_health_ping_fail(self, mock_get_redis_ping_fail: Any) -> None:
        app = FastAPI()
        router = build_router(mock_get_redis_ping_fail, prefix="/arq")
        app.include_router(router)
        client = TestClient(app)
        resp = client.get("/arq/health")
        assert resp.status_code == 200
        assert resp.json()["status"] == "error"


class TestHealthRouterEdge:
    def test_not_found(self, mock_get_redis_ok: Any) -> None:
        app = FastAPI()
        router = build_router(mock_get_redis_ok, prefix="/arq")
        app.include_router(router)
        client = TestClient(app)
        assert client.get("/arq/nonexistent").status_code == 404

    def test_health_response_model(self, mock_get_redis_ok: Any) -> None:
        app = FastAPI()
        router = build_router(mock_get_redis_ok, prefix="/arq")
        app.include_router(router)
        client = TestClient(app)
        resp = client.get("/arq/health")
        model = HealthStatus(**resp.json())
        assert model.status == "ok"


# ══════════════════════════════════════════════════════════════════════════
#  Integration
# ══════════════════════════════════════════════════════════════════════════


class TestIntegrationPositive:
    @pytest.mark.asyncio
    async def test_lifespan_startup_shutdown(self, app: FastAPI) -> None:
        """Startup creates redis, shutdown cleans up."""
        arq = FastArq(app, redis_settings="redis://localhost:6379")
        assert arq._arq_redis is None
        # simulate partial startup to verify state
        arq._arq_redis = AsyncMock(spec=ArqRedis, close=AsyncMock())
        await arq._shutdown()
        assert arq._arq_redis is None

    @pytest.mark.asyncio
    async def test_lifespan_preserves_existing(self, app_with_lifespan: FastAPI) -> None:
        app = app_with_lifespan
        orig_lifespan = app.router.lifespan_context
        arq = FastArq(app, redis_settings="redis://localhost:6379")
        assert arq._existing_lifespan is orig_lifespan
        assert app.router.lifespan_context is not orig_lifespan
        assert callable(app.router.lifespan_context)

    @pytest.mark.asyncio
    async def test_context_integration(self, app: FastAPI) -> None:
        from arq.connections import RedisSettings

        calls: list[str] = []

        def get_db() -> str:
            calls.append("db_called")
            return "db_session"

        arq = FastArq(
            app,
            redis_settings=RedisSettings(host="localhost", port=6379),
            context_dependencies=[get_db],
        )
        assert arq._context_builder._dependencies == [get_db]


class TestIntegrationFaultTolerance:
    @pytest.mark.asyncio
    async def test_multiple_shutdown_calls(self, app: FastAPI) -> None:
        arq = FastArq(app, redis_settings="redis://localhost:6379")
        await arq._shutdown()
        await arq._shutdown()
        await arq._shutdown()

    @pytest.mark.asyncio
    async def test_context_builder_shutdown_after_error(self, app: FastAPI) -> None:
        def broken() -> None:
            raise RuntimeError("fail")

        arq = FastArq(app, redis_settings="redis://localhost:6379", context_dependencies=[broken])
        with pytest.raises(RuntimeError):
            await arq._context_builder.build()
        await arq._context_builder.shutdown()

    @pytest.mark.asyncio
    async def test_lifespan_wraps_state(self) -> None:
        """FastArq lifespan runs existing lifespan and wraps its state."""
        from collections.abc import AsyncIterator
        from contextlib import asynccontextmanager

        app = FastAPI()

        @asynccontextmanager
        async def custom_lifespan(_app: FastAPI) -> AsyncIterator[dict]:
            yield {"db": "conn"}

        app.router.lifespan_context = custom_lifespan
        arq = FastArq(app, redis_settings="redis://localhost:6379")
        assert arq._existing_lifespan is custom_lifespan

    @pytest.mark.asyncio
    async def test_empty_lifespan(self, app: FastAPI) -> None:
        """FastArq works even when there's no custom lifespan."""
        arq = FastArq(app, redis_settings="redis://localhost:6379")
        assert arq._existing_lifespan is not None


# ══════════════════════════════════════════════════════════════════════════
#  Logging
# ══════════════════════════════════════════════════════════════════════════


class TestLogging:
    @pytest.mark.asyncio
    async def test_worker_start_logged(self, fake_pool: Any) -> None:
        from arq.connections import ArqRedis as BaseArqRedis

        redis = BaseArqRedis(pool_or_conn=fake_pool)
        registry = TaskRegistry()

        async def task(ctx: dict) -> None:
            pass

        registry.register(task, TaskConfig())
        manager = WorkerManager(poll_delay=0.5)
        await manager.start(redis, registry.build_arq_functions(), {})
        assert manager._task is not None
        assert not manager._task.done()
        await manager.stop()

    @pytest.mark.asyncio
    async def test_stop_logged(self, fake_pool: Any, caplog: Any) -> None:
        from arq.connections import ArqRedis as BaseArqRedis

        redis = BaseArqRedis(pool_or_conn=fake_pool)
        registry = TaskRegistry()

        async def task(ctx: dict) -> None:
            pass

        registry.register(task, TaskConfig())
        manager = WorkerManager(poll_delay=0.5)
        caplog.set_level(logging.INFO, logger="arq.worker")
        await manager.start(redis, registry.build_arq_functions(), {})
        caplog.clear()
        await manager.stop()
        # stop itself might not log, but at least we verify no crash

    @pytest.mark.asyncio
    async def test_worker_error_logged(self, fake_pool: Any, caplog: Any) -> None:
        """When worker encounters an error, it's logged."""
        from arq.connections import ArqRedis as BaseArqRedis
        from arq.worker import Worker

        # Make the worker's main() raise immediately
        with patch.object(Worker, "main", AsyncMock(side_effect=RuntimeError("boom"))):
            redis = BaseArqRedis(pool_or_conn=fake_pool)
            registry = TaskRegistry()

            async def task(ctx: dict) -> None:
                pass

            registry.register(task, TaskConfig())
            manager = WorkerManager(poll_delay=0.5)
            caplog.set_level(logging.ERROR)
            await manager.start(redis, registry.build_arq_functions(), {})
            await asyncio.sleep(0.05)
            await manager.stop()


# ══════════════════════════════════════════════════════════════════════════
#  Models
# ══════════════════════════════════════════════════════════════════════════


class TestModels:
    def test_task_config_defaults(self) -> None:
        cfg = TaskConfig()
        assert cfg.max_tries == 1
        assert cfg.timeout is None
        assert cfg.keep_result is None
        assert cfg.unique is False

    def test_task_config_custom(self) -> None:
        cfg = TaskConfig(max_tries=5, timeout=300, keep_result=3600, unique=True)
        assert cfg.max_tries == 5
        assert cfg.timeout == 300
        assert cfg.keep_result == 3600
        assert cfg.unique is True

    def test_health_status_defaults(self) -> None:
        hs = HealthStatus(status="ok")
        assert hs.redis_ping_ms is None
        assert hs.queues == {}

    def test_health_status_full(self) -> None:
        hs = HealthStatus(status="ok", redis_ping_ms=1.5, queues={"arq:queue": 3})
        assert hs.redis_ping_ms == 1.5
        assert hs.queues == {"arq:queue": 3}

    def test_health_status_error(self) -> None:
        hs = HealthStatus(status="error", redis_ping_ms=None)
        assert hs.status == "error"

    def test_cron_config_defaults(self) -> None:
        cfg = CronConfig()
        assert cfg.second == 0
        assert cfg.microsecond == 123456
        assert cfg.unique is True
        assert cfg.run_at_startup is False

    def test_cron_config_full(self) -> None:
        cfg = CronConfig(hour=6, minute=30, second=0, month={1, 7}, day=15, run_at_startup=True)
        assert cfg.hour == 6
        assert cfg.minute == 30
        assert cfg.month == {1, 7}
        assert cfg.day == 15
        assert cfg.run_at_startup is True

    def test_worker_settings_defaults(self) -> None:
        from arq.connections import RedisSettings

        ws = WorkerSettings(
            redis_settings=RedisSettings(host="localhost", port=6379),
            functions=[],
        )
        assert ws.cron_jobs is None
        assert ws.context_dependencies == []
        assert ws.concurrency == 10
        assert ws.poll_delay == 0.5

    def test_worker_settings_custom(self) -> None:
        from arq.connections import RedisSettings

        def dep() -> str:
            return "x"

        ws = WorkerSettings(
            redis_settings=RedisSettings(host="10.0.0.1", port=6380),
            functions=[],
            context_dependencies=[dep],
            concurrency=20,
            poll_delay=0.1,
        )
        assert ws.redis_settings.host == "10.0.0.1"
        assert ws.redis_settings.port == 6380
        assert ws.context_dependencies == [dep]
        assert ws.concurrency == 20
        assert ws.poll_delay == 0.1
