"""Forward-model output wrappers."""
