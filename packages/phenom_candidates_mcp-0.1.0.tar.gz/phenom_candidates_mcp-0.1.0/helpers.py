def build_candidate_url(api_base_url: str, candidate_id: str) -> str:
    return f"{api_base_url}/v2/candidates?candidateId={candidate_id}"


def build_experiences_url(api_base_url: str, candidate_id: str) -> str:
    return f"{api_base_url}/v1/candidates/{candidate_id}/experiences"


def format_api_error(status_code: int, message: str, endpoint: str) -> str:
    return f"HTTP {status_code} error from {endpoint}: {message}"
