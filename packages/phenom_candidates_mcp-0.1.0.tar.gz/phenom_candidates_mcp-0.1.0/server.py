import json
import sys

from mcp.server.fastmcp import FastMCP

from config import Config, load_config
from errors import AuthenticationError, NotFoundError, PhenomApiError
from models import AuthInput, CandidateInput, ExperienceInput
from token_manager import TokenManager
from phenom_client import PhenomClient

mcp_server = FastMCP(name="phenom-candidates-mcp")

token_manager: TokenManager | None = None
phenom_client: PhenomClient | None = None


@mcp_server.tool(name="authenticate")
async def authenticate(client_id: str | None = None, client_secret: str | None = None) -> str:
    try:
        if token_manager is None:
            return "Server not initialized"
        token = await token_manager.refresh_token()
        return token
    except AuthenticationError as e:
        raise ValueError(str(e)) from e
    except Exception as e:
        raise ValueError(f"Authentication failed: {e}") from e


@mcp_server.tool(name="get-candidate")
async def get_candidate(candidate_id: str) -> str:
    try:
        if phenom_client is None:
            return "Server not initialized"
        data = await phenom_client.get_candidate(candidate_id)
        return json.dumps(data)
    except NotFoundError as e:
        raise ValueError(f"Candidate not found: {e}") from e
    except AuthenticationError as e:
        raise ValueError(f"Authentication error: {e}") from e
    except PhenomApiError as e:
        raise ValueError(str(e)) from e
    except Exception as e:
        raise ValueError(f"Failed to get candidate: {e}") from e


@mcp_server.tool(name="get-candidate-experiences")
async def get_candidate_experiences(candidate_id: str) -> str:
    try:
        if phenom_client is None:
            return "Server not initialized"
        data = await phenom_client.get_candidate_experiences(candidate_id)
        return json.dumps(data)
    except NotFoundError as e:
        raise ValueError(f"Candidate experiences not found: {e}") from e
    except AuthenticationError as e:
        raise ValueError(f"Authentication error: {e}") from e
    except PhenomApiError as e:
        raise ValueError(str(e)) from e
    except Exception as e:
        raise ValueError(f"Failed to get candidate experiences: {e}") from e


def main() -> None:
    global token_manager, phenom_client
    try:
        config = load_config()
    except ValueError as e:
        print(str(e), file=sys.stderr)
        sys.exit(1)

    token_manager = TokenManager(config)
    phenom_client = PhenomClient(token_manager, config)
    mcp_server.run(transport="stdio")


if __name__ == "__main__":
    main()
