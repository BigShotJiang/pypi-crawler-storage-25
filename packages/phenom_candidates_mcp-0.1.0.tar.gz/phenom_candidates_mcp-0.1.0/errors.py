from helpers import format_api_error


class PhenomApiError(Exception):
    def __init__(self, status_code: int, message: str, endpoint: str):
        self.status_code = status_code
        self.message = message
        self.endpoint = endpoint
        super().__init__(format_api_error(status_code, message, endpoint))


class AuthenticationError(PhenomApiError):
    pass


class NotFoundError(PhenomApiError):
    pass
