from pydantic import BaseModel, Field


class AuthInput(BaseModel):
    client_id: str | None = Field(None, description="Override client ID")
    client_secret: str | None = Field(None, description="Override client secret")


class CandidateInput(BaseModel):
    candidate_id: str = Field(..., description="The candidate ID to look up")


class ExperienceInput(BaseModel):
    candidate_id: str = Field(..., description="The candidate ID whose experiences to retrieve")


class TokenResponse(BaseModel):
    access_token: str
    token_type: str
    expires_in: int | None = None
