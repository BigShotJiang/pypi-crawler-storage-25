import os

from pydantic import BaseModel


class Config(BaseModel):
    client_id: str
    client_secret: str
    auth_cookie: str = ""
    cookie: str = ""
    user_id: str
    api_key: str = ""
    login_url: str = "https://login-intqa.phenompro.com/token"
    api_base_url: str = "https://api-qa.phenompro.com/candidates-api"


def load_config() -> Config:
    required = {
        "PHENOM_CLIENT_ID": "client_id",
        "PHENOM_CLIENT_SECRET": "client_secret",
        "PHENOM_USER_ID": "user_id",
    }
    for env_var in required:
        if not os.environ.get(env_var):
            raise ValueError(f"Missing required environment variable: {env_var}")

    return Config(
        client_id=os.environ["PHENOM_CLIENT_ID"],
        client_secret=os.environ["PHENOM_CLIENT_SECRET"],
        auth_cookie=os.environ.get("PHENOM_AUTH_COOKIE", ""),
        cookie=os.environ.get("PHENOM_COOKIE", ""),
        user_id=os.environ["PHENOM_USER_ID"],
        api_key=os.environ.get("PHENOM_API_KEY", ""),
        login_url=os.environ.get("PHENOM_LOGIN_URL", "https://login-intqa.phenompro.com/token"),
        api_base_url=os.environ.get("PHENOM_API_BASE_URL", "https://api-qa.phenompro.com/candidates-api"),
    )
