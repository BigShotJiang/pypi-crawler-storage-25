import httpx

from config import Config
from errors import AuthenticationError
from models import TokenResponse


class TokenManager:
    def __init__(self, config: Config, http_client: httpx.AsyncClient | None = None):
        self._token: str | None = None
        self._config = config
        self._http_client = http_client or httpx.AsyncClient()

    async def get_token(self) -> str:
        if self._token is not None:
            return self._token
        return await self.refresh_token()

    async def refresh_token(self) -> str:
        headers = {}
        if self._config.auth_cookie:
            headers["AUTH_COOKIE"] = self._config.auth_cookie
        if self._config.cookie:
            headers["Cookie"] = self._config.cookie

        try:
            response = await self._http_client.post(
                self._config.login_url,
                data={
                    "client_id": self._config.client_id,
                    "client_secret": self._config.client_secret,
                },
                headers=headers,
            )
        except httpx.HTTPError as exc:
            raise AuthenticationError(
                status_code=0,
                message=str(exc),
                endpoint=self._config.login_url,
            ) from exc

        if response.status_code >= 400:
            raise AuthenticationError(
                status_code=response.status_code,
                message=response.text,
                endpoint=self._config.login_url,
            )

        token_response = TokenResponse.model_validate(response.json())
        self._token = token_response.access_token
        return self._token

    def clear_token(self) -> None:
        self._token = None
