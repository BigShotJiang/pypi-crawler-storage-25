import httpx

from config import Config
from errors import AuthenticationError, NotFoundError, PhenomApiError
from helpers import build_candidate_url, build_experiences_url
from token_manager import TokenManager


class PhenomClient:
    def __init__(
        self,
        token_manager: TokenManager,
        config: Config,
        http_client: httpx.AsyncClient | None = None,
    ):
        self._token_manager = token_manager
        self._config = config
        self._http_client = http_client or httpx.AsyncClient()

    async def get_candidate(self, candidate_id: str) -> dict:
        url = build_candidate_url(self._config.api_base_url, candidate_id)
        return await self._request_with_retry(
            url,
            headers_builder=self._candidate_headers,
        )

    async def get_candidate_experiences(self, candidate_id: str) -> list:
        url = build_experiences_url(self._config.api_base_url, candidate_id)
        return await self._request_with_retry(
            url,
            headers_builder=self._experiences_headers,
        )

    def _candidate_headers(self, token: str) -> dict[str, str]:
        return {
            "Authorization": f"Bearer {token}",
            "x-ph-userid": self._config.user_id,
        }

    def _experiences_headers(self, token: str) -> dict[str, str]:
        return {
            "Authorization": f"Bearer {token}",
            "x-ph-userId": self._config.user_id,
            "api-key": self._config.api_key,
        }

    async def _request_with_retry(
        self,
        url: str,
        headers_builder,
    ):
        token = await self._token_manager.get_token()
        response = await self._http_client.get(url, headers=headers_builder(token))

        if response.status_code == 401:
            self._token_manager.clear_token()
            token = await self._token_manager.refresh_token()
            response = await self._http_client.get(url, headers=headers_builder(token))

            if response.status_code == 401:
                raise AuthenticationError(
                    status_code=401,
                    message=response.text,
                    endpoint=url,
                )

        if response.status_code == 404:
            raise NotFoundError(
                status_code=404,
                message=response.text,
                endpoint=url,
            )

        if response.status_code >= 400:
            raise PhenomApiError(
                status_code=response.status_code,
                message=response.text,
                endpoint=url,
            )

        return response.json()
