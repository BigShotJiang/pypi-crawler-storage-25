"""Babon — kinematics-as-a-service client for Python.

    pip install babon

    from babon import Babon
    Babon("bk_...").analyze("trial.mp4").save("out.zip")

That's it.

Internally this wraps `api.babon.eu/v1/*` with `requests`. Idempotency,
polling, error envelope decoding, file handling: all handled. Customer
sees one class and three methods.
"""

from __future__ import annotations

import hashlib
import os
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, Iterator, Optional, Union

import requests

from babon._keyring import resolve_key, ENV_VAR


__all__ = [
    "Babon",
    "Run",
    "RunBatch",
    "BabonError",
    "BabonAuthError",
    "BabonQuotaExceeded",
    "BabonInvalidVideo",
    "BabonInvalidLabel",
    "BabonRunFailed",
    "BabonTimeout",
]


DEFAULT_BASE_URL = "https://api.babon.eu"
DEFAULT_POLL_INTERVAL_S = 30
DEFAULT_WAIT_TIMEOUT_S = 60 * 60 * 6  # 6 hours, covers an overnight batch


# ─────────────────── exceptions ───────────────────

class BabonError(Exception):
    """Base class for everything the client raises."""

    def __init__(self, message: str, *, code: str = "", request_id: str = ""):
        super().__init__(message)
        self.code = code
        self.request_id = request_id


class BabonAuthError(BabonError): pass
class BabonQuotaExceeded(BabonError): pass
class BabonInvalidVideo(BabonError): pass
class BabonInvalidLabel(BabonError): pass
class BabonRunFailed(BabonError): pass
class BabonTimeout(BabonError): pass


_CODE_TO_EXC: dict[str, type[BabonError]] = {
    "MISSING_AUTH":      BabonAuthError,
    "INVALID_AUTH":      BabonAuthError,
    "WRONG_ENVIRONMENT": BabonAuthError,
    "DPA_NOT_ACCEPTED":  BabonAuthError,
    "QUOTA_EXCEEDED":    BabonQuotaExceeded,
    "CONCURRENT_LIMIT":  BabonQuotaExceeded,
    "RATE_LIMITED":      BabonQuotaExceeded,
    "INVALID_VIDEO":     BabonInvalidVideo,
    "VIDEO_REQUIRED":    BabonInvalidVideo,
    "INVALID_LABEL":     BabonInvalidLabel,
}


def _raise_for_envelope(response: requests.Response) -> None:
    if response.ok:
        return
    try:
        body = response.json()
    except Exception:
        raise BabonError(f"HTTP {response.status_code}: {response.text[:200]}")
    err = (body or {}).get("error") or {}
    code = err.get("code", "")
    message = err.get("message", f"HTTP {response.status_code}")
    request_id = err.get("request_id", "")
    exc_cls = _CODE_TO_EXC.get(code, BabonError)
    raise exc_cls(message, code=code, request_id=request_id)


def _auto_idempotency_key(file_path: Path, key: str) -> str:
    """Stable hash of (api key + filename + size + first 4 KB of file).

    First 4 KB is enough to discriminate distinct uploads without
    re-reading the whole file. Same input, same upload → same idem key →
    server replays the prior response.
    """
    h = hashlib.sha256()
    h.update(key.encode())
    h.update(b"\x00")
    h.update(str(file_path).encode())
    h.update(b"\x00")
    h.update(str(file_path.stat().st_size).encode())
    h.update(b"\x00")
    with open(file_path, "rb") as f:
        h.update(f.read(4096))
    return h.hexdigest()


# ─────────────────── public surface ───────────────────

@dataclass
class Run:
    """A submitted analysis. Returned from `Babon.analyze(...)`.

    Methods you care about:
      .wait()                          block until the run terminates
      .save(path)                      block + download the bundle.zip
      .data                            block + return clinical_report.json as a dict
      .id, .status                     introspection
    """

    id: str
    _client: "Babon"
    _status: str = "queued"

    @property
    def status(self) -> str:
        return self._status

    def refresh(self) -> "Run":
        body = self._client._get(f"/api/v1/runs/{self.id}")
        self._status = body.get("status", "unknown")
        return self

    def wait(
        self,
        *,
        timeout_s: int = DEFAULT_WAIT_TIMEOUT_S,
        poll_every_s: int = DEFAULT_POLL_INTERVAL_S,
    ) -> "Run":
        """Block until the run reaches a terminal state."""
        started = time.monotonic()
        while True:
            self.refresh()
            if self._status == "completed":
                return self
            if self._status == "failed":
                raise BabonRunFailed(f"run {self.id} failed", code="RUN_FAILED")
            if time.monotonic() - started > timeout_s:
                raise BabonTimeout(
                    f"run {self.id} did not complete within {timeout_s}s "
                    f"(last status: {self._status})",
                    code="TIMEOUT",
                )
            time.sleep(poll_every_s)

    def save(self, path: Union[str, os.PathLike], *, include_preview: bool = False) -> Path:
        """Wait for completion and write the bundle to `path`."""
        self.wait()
        url = f"/api/v1/runs/{self.id}/bundle.zip"
        if include_preview:
            url += "?include_preview=true"
        out = Path(path)
        out.write_bytes(self._client._get_bytes(url))
        return out

    @property
    def data(self) -> dict:
        """Wait for completion and return clinical_report.json as a dict."""
        self.wait()
        body = self._client._get_bytes(f"/api/v1/runs/{self.id}/files/clinical_report.json")
        import json as _json
        return _json.loads(body)


@dataclass
class RunBatch:
    runs: list[Run]

    def __iter__(self) -> Iterator[Run]:
        return iter(self.runs)

    def __len__(self) -> int:
        return len(self.runs)

    def wait(self, **kwargs) -> "RunBatch":
        for run in self.runs:
            run.wait(**kwargs)
        return self

    def save(self, directory: Union[str, os.PathLike], *, include_preview: bool = False) -> list[Path]:
        out_dir = Path(directory)
        out_dir.mkdir(parents=True, exist_ok=True)
        paths = []
        for run in self.runs:
            paths.append(run.save(out_dir / f"{run.id}.zip", include_preview=include_preview))
        return paths


class Babon:
    """Babon client. One key per organisation.

    The key defaults to the ``BABON_API_KEY`` env var so you never have
    to write the secret in code:

        export BABON_API_KEY=bk_...
        # then in Python:
        Babon().analyze("trial.mp4").save("out.zip")

    Or pass it explicitly if you really want to:

        Babon(key="bk_...").analyze("trial.mp4").save("out.zip")
    """

    def __init__(
        self,
        key: Optional[str] = None,
        *,
        base_url: str = DEFAULT_BASE_URL,
        timeout_s: int = 600,
    ):
        resolved = resolve_key(key)
        if not resolved:
            raise BabonAuthError(
                "No Babon API key found. Run 'babon login' to set one "
                "interactively, or export BABON_API_KEY=bk_... yourself.",
                code="MISSING_AUTH",
            )
        self._key = resolved
        self._base_url = base_url.rstrip("/")
        self._timeout_s = timeout_s

    # public surface
    def analyze(
        self,
        video: Union[str, os.PathLike, Iterable[Union[str, os.PathLike]]],
        *,
        label: Optional[str] = None,
    ) -> Union[Run, RunBatch]:
        """Submit one video or a list. Returns a Run or a RunBatch.

        analyze("trial.mp4")                       -> Run
        analyze(["a.mp4", "b.mp4"])                -> RunBatch
        analyze("trial.mp4", label="cohort-3")     -> Run with custom label
        """
        if isinstance(video, (str, os.PathLike)):
            return self._submit_one(Path(video), label=label)
        return RunBatch([self._submit_one(Path(v), label=label) for v in video])

    # internals
    def _headers(self) -> dict:
        return {"Authorization": f"Bearer {self._key}"}

    def _submit_one(self, path: Path, *, label: Optional[str]) -> Run:
        if not path.is_file():
            raise FileNotFoundError(f"video not found: {path}")
        headers = self._headers()
        headers["Idempotency-Key"] = _auto_idempotency_key(path, self._key)
        data: dict = {}
        if label:
            data["label"] = label
        with open(path, "rb") as f:
            files = {"video": (path.name, f, "application/octet-stream")}
            resp = requests.post(
                f"{self._base_url}/api/v1/runs",
                headers=headers,
                data=data,
                files=files,
                timeout=self._timeout_s,
            )
        _raise_for_envelope(resp)
        body = resp.json()
        return Run(id=body["run_id"], _client=self, _status=body.get("status", "queued"))

    def _get(self, path: str) -> dict:
        resp = requests.get(f"{self._base_url}{path}", headers=self._headers(), timeout=self._timeout_s)
        _raise_for_envelope(resp)
        return resp.json()

    def _get_bytes(self, path: str) -> bytes:
        resp = requests.get(f"{self._base_url}{path}", headers=self._headers(), timeout=self._timeout_s)
        _raise_for_envelope(resp)
        return resp.content
