"""Key resolution + .env IO for the Babon Python client.

Owns the single source of truth for "where does the key come from?" so
``Babon()`` and the ``babon`` CLI never drift apart on key handling.

Resolution order, first hit wins:

1. Explicit ``key=`` argument to ``Babon(...)``.
2. ``BABON_API_KEY`` in the process environment.
3. ``BABON_API_KEY=...`` line in ``.env``, looked up by walking the
   current working directory up to 3 parent directories. Same heuristic
   pytest uses for rootdir discovery.

If none of those find a key, ``Babon()`` raises ``BabonAuthError`` with
a friendly message pointing at ``babon login``. The client never
prompts interactively from ``__init__`` — Jupyter notebooks would hang
on ``input()``.

The ``.env`` reader is intentionally a 30-line parser, not a
``python-dotenv`` dependency. We only care about one variable; adding
a transitive dep for that is overkill.
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Optional

ENV_VAR = "BABON_API_KEY"
DOTENV_FILENAME = ".env"
DOTENV_PARENT_WALK = 3  # CWD + 3 parents (pytest's rootdir heuristic)


def _parse_dotenv_key(text: str, var_name: str) -> Optional[str]:
    """Find ``VAR_NAME=value`` in a .env-format string. Returns the
    value (unquoted, untrimmed of internal whitespace) or None."""
    for line in text.splitlines():
        stripped = line.strip()
        if not stripped or stripped.startswith("#"):
            continue
        if "=" not in stripped:
            continue
        name, _, value = stripped.partition("=")
        if name.strip() != var_name:
            continue
        value = value.strip()
        if len(value) >= 2 and value[0] == value[-1] and value[0] in ("'", '"'):
            value = value[1:-1]
        return value
    return None


def find_dotenv(start: Optional[Path] = None) -> Optional[Path]:
    """Walk CWD + up to DOTENV_PARENT_WALK parents looking for `.env`.
    Returns the first match (deepest) or None."""
    here = (start or Path.cwd()).resolve()
    for candidate in [here, *here.parents][: 1 + DOTENV_PARENT_WALK]:
        path = candidate / DOTENV_FILENAME
        if path.is_file():
            return path
    return None


def read_dotenv_key(start: Optional[Path] = None) -> Optional[str]:
    """Read BABON_API_KEY from the nearest .env (walking up). None if
    no .env is found, or if the file exists but doesn't carry the key."""
    path = find_dotenv(start)
    if path is None:
        return None
    try:
        return _parse_dotenv_key(path.read_text(), ENV_VAR)
    except OSError:
        return None


def resolve_key(explicit: Optional[str] = None) -> Optional[str]:
    """Apply the documented resolution order. Returns the key string or
    None if nothing resolves."""
    if explicit:
        return explicit
    env_value = os.environ.get(ENV_VAR, "").strip()
    if env_value:
        return env_value
    return read_dotenv_key()


def write_key_to_dotenv(key: str, path: Optional[Path] = None) -> Path:
    """Write or replace the BABON_API_KEY line in `.env`. Creates the
    file if missing; preserves every other line if present. Returns
    the written path."""
    target = path or (Path.cwd() / DOTENV_FILENAME)
    new_line = f"{ENV_VAR}={key}\n"

    if not target.exists():
        target.write_text(new_line)
        return target

    existing = target.read_text()
    out_lines: list[str] = []
    replaced = False
    for line in existing.splitlines(keepends=True):
        stripped = line.strip()
        if stripped and not stripped.startswith("#") and "=" in stripped:
            name = stripped.partition("=")[0].strip()
            if name == ENV_VAR:
                out_lines.append(new_line)
                replaced = True
                continue
        out_lines.append(line)
    if not replaced:
        if out_lines and not out_lines[-1].endswith("\n"):
            out_lines[-1] = out_lines[-1] + "\n"
        out_lines.append(new_line)
    target.write_text("".join(out_lines))
    return target
