"""Tests for the `babon login` subcommand (PRD #329 slice #330)."""

from __future__ import annotations

import argparse
from pathlib import Path
from unittest.mock import patch

import pytest

from babon import BabonAuthError, BabonError
from babon._keyring import ENV_VAR, DOTENV_FILENAME, read_dotenv_key
from babon.cli import cmd_login


@pytest.fixture(autouse=True)
def _clean_env(monkeypatch):
    monkeypatch.delenv(ENV_VAR, raising=False)


def _args(key=None, to=None):
    return argparse.Namespace(key=key, to=to)


def test_login_with_valid_key_writes_dotenv(tmp_path, monkeypatch, capsys):
    monkeypatch.chdir(tmp_path)
    with patch("babon.Babon._get") as get_mock:
        get_mock.return_value = {"org_id": "sarah@uni.nl", "environment": "live", "key_name": "Laptop"}
        rc = cmd_login(_args(key="bk_valid"))
    assert rc == 0

    out = capsys.readouterr().out
    assert "sarah@uni.nl" in out
    assert "live" in out
    assert "Wrote BABON_API_KEY" in out

    written = tmp_path / DOTENV_FILENAME
    assert written.exists()
    assert read_dotenv_key(tmp_path) == "bk_valid"


def test_login_with_rejected_key_does_not_write(tmp_path, monkeypatch, capsys):
    monkeypatch.chdir(tmp_path)
    with patch("babon.Babon._get", side_effect=BabonAuthError("bad key", code="INVALID_AUTH")):
        rc = cmd_login(_args(key="bk_bad"))
    assert rc == 1
    assert not (tmp_path / DOTENV_FILENAME).exists()
    err = capsys.readouterr().err
    assert "rejected" in err.lower()
    assert "/developers/keys" in err


def test_login_with_other_error_does_not_write(tmp_path, monkeypatch, capsys):
    monkeypatch.chdir(tmp_path)
    with patch("babon.Babon._get", side_effect=BabonError("network down")):
        rc = cmd_login(_args(key="bk_anything"))
    assert rc == 1
    assert not (tmp_path / DOTENV_FILENAME).exists()


def test_login_empty_interactive_prompt_aborts(tmp_path, monkeypatch, capsys):
    monkeypatch.chdir(tmp_path)
    with patch("babon.cli.getpass.getpass", return_value="   "):
        rc = cmd_login(_args(key=None))
    assert rc == 1
    err = capsys.readouterr().err
    assert "empty" in err.lower()
    assert not (tmp_path / DOTENV_FILENAME).exists()


def test_login_to_custom_path(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    custom = tmp_path / "subdir" / "custom.env"
    custom.parent.mkdir()
    with patch("babon.Babon._get") as get_mock:
        get_mock.return_value = {"org_id": "o", "environment": "live", "key_name": "k"}
        rc = cmd_login(_args(key="bk_custom", to=str(custom)))
    assert rc == 0
    assert custom.exists()
    assert "BABON_API_KEY=bk_custom" in custom.read_text()


def test_login_preserves_other_env_lines(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    (tmp_path / DOTENV_FILENAME).write_text("OTHER=stays\nDB_URL=postgres://...\n")
    with patch("babon.Babon._get") as get_mock:
        get_mock.return_value = {"org_id": "o", "environment": "live", "key_name": "k"}
        cmd_login(_args(key="bk_new"))
    content = (tmp_path / DOTENV_FILENAME).read_text()
    assert "OTHER=stays\n" in content
    assert "DB_URL=postgres://...\n" in content
    assert "BABON_API_KEY=bk_new\n" in content
