"""Tests for the key-resolution + .env IO seam (PRD #329 slice #330).

The keyring is the single source of truth for "where does the key
come from?". Both ``Babon()`` and the ``babon`` CLI consume it, so
drift here is invisible: lock the resolution order down.
"""

from __future__ import annotations

import os
from pathlib import Path

import pytest

from babon._keyring import (
    ENV_VAR,
    DOTENV_FILENAME,
    find_dotenv,
    read_dotenv_key,
    resolve_key,
    write_key_to_dotenv,
    _parse_dotenv_key,
)


@pytest.fixture(autouse=True)
def _clean_env(monkeypatch):
    """Every test starts with no BABON_API_KEY in the environment."""
    monkeypatch.delenv(ENV_VAR, raising=False)
    yield


# ─────────────────── _parse_dotenv_key ───────────────────

def test_parse_simple_assignment():
    assert _parse_dotenv_key("BABON_API_KEY=bk_abc\n", "BABON_API_KEY") == "bk_abc"


def test_parse_skips_blank_and_comment_lines():
    text = "\n# comment\n\nBABON_API_KEY=bk_xyz\n"
    assert _parse_dotenv_key(text, "BABON_API_KEY") == "bk_xyz"


def test_parse_strips_surrounding_quotes():
    assert _parse_dotenv_key('BABON_API_KEY="bk_quoted"', "BABON_API_KEY") == "bk_quoted"
    assert _parse_dotenv_key("BABON_API_KEY='bk_single'", "BABON_API_KEY") == "bk_single"


def test_parse_ignores_other_variables():
    text = "OTHER=value\nBABON_API_KEY=bk_target\n"
    assert _parse_dotenv_key(text, "BABON_API_KEY") == "bk_target"
    assert _parse_dotenv_key(text, "MISSING") is None


# ─────────────────── find_dotenv + read_dotenv_key ───────────────────

def test_find_dotenv_in_cwd(tmp_path, monkeypatch):
    (tmp_path / DOTENV_FILENAME).write_text("BABON_API_KEY=bk_cwd\n")
    monkeypatch.chdir(tmp_path)
    assert find_dotenv() == tmp_path / DOTENV_FILENAME


def test_find_dotenv_walks_up(tmp_path, monkeypatch):
    (tmp_path / DOTENV_FILENAME).write_text("BABON_API_KEY=bk_root\n")
    deep = tmp_path / "a" / "b" / "c"
    deep.mkdir(parents=True)
    monkeypatch.chdir(deep)
    found = find_dotenv()
    assert found == tmp_path / DOTENV_FILENAME


def test_find_dotenv_returns_none_when_absent(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    assert find_dotenv() is None


def test_read_dotenv_key_picks_up_value(tmp_path, monkeypatch):
    (tmp_path / DOTENV_FILENAME).write_text("BABON_API_KEY=bk_from_dotenv\n")
    monkeypatch.chdir(tmp_path)
    assert read_dotenv_key() == "bk_from_dotenv"


def test_read_dotenv_key_returns_none_when_file_missing(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    assert read_dotenv_key() is None


# ─────────────────── resolve_key: the order ───────────────────

def test_resolve_explicit_wins_over_everything(tmp_path, monkeypatch):
    (tmp_path / DOTENV_FILENAME).write_text("BABON_API_KEY=bk_dotenv\n")
    monkeypatch.chdir(tmp_path)
    monkeypatch.setenv(ENV_VAR, "bk_env")
    assert resolve_key("bk_arg") == "bk_arg"


def test_resolve_env_wins_over_dotenv(tmp_path, monkeypatch):
    (tmp_path / DOTENV_FILENAME).write_text("BABON_API_KEY=bk_dotenv\n")
    monkeypatch.chdir(tmp_path)
    monkeypatch.setenv(ENV_VAR, "bk_env")
    assert resolve_key() == "bk_env"


def test_resolve_dotenv_when_env_absent(tmp_path, monkeypatch):
    (tmp_path / DOTENV_FILENAME).write_text("BABON_API_KEY=bk_dotenv\n")
    monkeypatch.chdir(tmp_path)
    assert resolve_key() == "bk_dotenv"


def test_resolve_returns_none_when_nothing_set(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    assert resolve_key() is None


def test_resolve_empty_env_falls_through_to_dotenv(tmp_path, monkeypatch):
    """An empty BABON_API_KEY='' shouldn't shadow a real value in .env."""
    (tmp_path / DOTENV_FILENAME).write_text("BABON_API_KEY=bk_dotenv\n")
    monkeypatch.chdir(tmp_path)
    monkeypatch.setenv(ENV_VAR, "")
    assert resolve_key() == "bk_dotenv"


# ─────────────────── write_key_to_dotenv ───────────────────

def test_write_creates_file(tmp_path):
    target = tmp_path / DOTENV_FILENAME
    assert not target.exists()
    out = write_key_to_dotenv("bk_new", target)
    assert out == target
    assert target.read_text() == "BABON_API_KEY=bk_new\n"


def test_write_replaces_existing_key_line(tmp_path):
    target = tmp_path / DOTENV_FILENAME
    target.write_text(
        "OTHER_VAR=stays\n"
        "BABON_API_KEY=bk_old\n"
        "ANOTHER=also_stays\n"
    )
    write_key_to_dotenv("bk_new", target)
    content = target.read_text()
    assert "OTHER_VAR=stays\n" in content
    assert "ANOTHER=also_stays\n" in content
    assert "BABON_API_KEY=bk_new\n" in content
    assert "bk_old" not in content


def test_write_appends_when_key_absent(tmp_path):
    target = tmp_path / DOTENV_FILENAME
    target.write_text("OTHER=stays\n")
    write_key_to_dotenv("bk_new", target)
    content = target.read_text()
    assert "OTHER=stays\n" in content
    assert content.endswith("BABON_API_KEY=bk_new\n")


def test_write_handles_missing_final_newline(tmp_path):
    target = tmp_path / DOTENV_FILENAME
    target.write_text("OTHER=stays")  # no trailing newline
    write_key_to_dotenv("bk_new", target)
    content = target.read_text()
    # Append should add a newline between OTHER= and our line.
    assert "OTHER=stays\nBABON_API_KEY=bk_new\n" == content


def test_write_round_trips_through_read(tmp_path, monkeypatch):
    target = tmp_path / DOTENV_FILENAME
    write_key_to_dotenv("bk_round_trip", target)
    monkeypatch.chdir(tmp_path)
    assert read_dotenv_key() == "bk_round_trip"
