# Re-export from common — M11 and CPT share the same DOCX loader.
from usdm4_protocol.common.load import LoadDocx  # noqa: F401
