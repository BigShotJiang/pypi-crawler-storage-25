from usdm4_protocol.cpt.import_.load import LoadDocx
from usdm4_protocol.cpt.import_.extract import ExtractStudy
from usdm4_protocol.common.base_import import BaseImport
from simple_error_log.errors import Errors


class CPTImport(BaseImport):
    MODULE = "usdm4_protocol.cpt.import_.cpt_import.CPTImport"

    def __init__(self, file_path: str, errors: Errors):
        super().__init__(file_path, errors)

    def _load(self):
        loader = LoadDocx(self._file_path, self._errors)
        return loader.process()

    def _extract(self, loaded) -> dict:
        extractor = ExtractStudy(loaded, self._errors)
        return extractor.process()

    @property
    def extra(self) -> dict:
        return {
            "title_page": {
                "compound_codes": "",
                "compound_names": "",
                "amendment_identifier": "",
                "sponsor_confidentiality": "",
                # Not used?
                "amendment_details": "",
                "amendment_scope": "",
                "manufacturer_name_and_address": "",
                "medical_expert_contact": "",
                "original_protocol": "",
                "regulatory_agency_identifiers": "",
                "sae_reporting_method": "",
                "sponsor_approval_date": "",
                "sponsor_name_and_address": "",
                "sponsor_signatory": "",
            },
            "amendment": {
                "amendment_details": "",
                "robustness_impact": False,
                "robustness_impact_reason": "",
                "safety_impact": False,
                "safety_impact_reason": "",
            },
            "miscellaneous": {
                "medical_expert_contact": "",
                "sae_reporting_method": "",
                "sponsor_signatory": "",
            },
        }
