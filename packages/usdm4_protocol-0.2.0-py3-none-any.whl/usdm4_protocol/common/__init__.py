# Common utilities for all packages
