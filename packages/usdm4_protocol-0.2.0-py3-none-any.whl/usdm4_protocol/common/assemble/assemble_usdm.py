from usdm4 import USDM4
from simple_error_log.errors import Errors
from simple_error_log.error_location import KlassMethodLocation
from usdm4.assembler.assembler import Assembler
from usdm4.api.wrapper import Wrapper
from usdm4_protocol.__info__ import (
    __package_version__ as system_version,
    __system_name__ as system_name,
)


class AssembleUSDM:
    """Unified USDM assembler for all source formats."""

    MODULE = "usdm4_protocol.common.assemble.assemble_usdm.AssembleUSDM"

    def __init__(self, source_data: dict, errors: Errors):
        """
        Initialize the USDM assembler.

        Args:
            source_data: Source data dictionary to be assembled into USDM4
            errors: Error logging object
        """
        self._source_data = source_data
        self._errors = errors
        self._usdm4 = USDM4()
        self._assembler: Assembler = self._usdm4.assembler(self._errors)

    def process(self) -> Wrapper:
        """
        Process the source data and assemble into USDM4.

        Returns:
            USDM4 wrapper object or empty dict if assembly fails
        """
        try:
            self._assembler.execute(self._source_data)
            return self._assembler.wrapper(system_name, system_version)
        except Exception as e:
            location = KlassMethodLocation(self.MODULE, "process")
            self._errors.exception(
                "Exception raised assembling USDM",
                e,
                location,
            )
            return {}

    @property
    def source(self):
        """Get the source data."""
        return self._source_data
