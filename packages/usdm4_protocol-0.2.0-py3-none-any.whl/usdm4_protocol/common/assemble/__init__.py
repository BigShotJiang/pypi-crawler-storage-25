# Assembly utilities
