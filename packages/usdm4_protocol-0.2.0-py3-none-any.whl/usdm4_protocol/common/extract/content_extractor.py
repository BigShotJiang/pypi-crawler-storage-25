from simple_error_log.errors import Errors
from simple_error_log.error_location import KlassMethodLocation
from usdm4_protocol.common.ai.base_ai import BaseAIProvider


class ContentExtractor:
    """Base class for AI-based content extraction from HTML.

    Provides the common pattern of: build prompt → call AI → parse JSON response.
    Subclasses supply the prompt template and define the output shape.
    """

    MODULE = "usdm4_protocol.common.extract.content_extractor.ContentExtractor"

    def __init__(self, ai: BaseAIProvider, errors: Errors):
        """
        Initialize the content extractor.

        Args:
            ai: An AI provider instance (e.g., ClaudeProvider). May be None if AI is unavailable.
            errors: Error logging object.
        """
        self._ai = ai
        self._errors = errors

    @property
    def ai_available(self) -> bool:
        """Check if the AI provider is available for use."""
        return self._ai is not None and self._ai.available

    def extract(
        self, html: str, prompt: str, as_list: bool = True, system_message: str = "", task_type: str = ""
    ) -> list | dict | None:
        """
        Extract structured content from HTML using an AI prompt.

        Args:
            html: The HTML content to process.
            prompt: The full prompt text to send to the AI.
            as_list: If True, expect a JSON list response; if False, expect a dict.
            system_message: Optional system message for context.
            task_type: Optional task type label for training data logging.

        Returns:
            Parsed JSON result (list or dict), or None on failure.
        """
        try:
            if not self.ai_available:
                self._errors.warning(
                    "AI provider not available for content extraction",
                    KlassMethodLocation(self.MODULE, "extract"),
                )
                return None

            if task_type and self._ai.logger:
                self._ai.logger.set_task_context(task_type)

            prompt_result = self._ai.streaming_prompt(prompt, system_message=system_message)
            if prompt_result is None:
                self._errors.error(
                    "AI returned no response for content extraction",
                    KlassMethodLocation(self.MODULE, "extract"),
                )
                return None

            result = self._ai.extract_json(prompt_result, dict=not as_list)
            return result
        except Exception as e:
            self._errors.exception(
                "Exception during AI content extraction",
                e,
                KlassMethodLocation(self.MODULE, "extract"),
            )
            return None
