import re


def find_sections_by_title(sections: list[dict], search_text: str, ocr_tolerant: bool = False) -> list[dict]:
    """
    Find sections whose title contains the search text (case-insensitive, whitespace-normalized).

    Args:
        sections: List of section dicts from SplitHTML, each with keys:
            - section_number: str
            - section_title: str
            - text: str (HTML content)
        search_text: Text to search for in section titles.
        ocr_tolerant: If True, also try matching with all whitespace stripped
            (handles OCR-corrupted titles like "Sc he d ule of Act i vities").

    Returns:
        List of matching section dicts, in the order they appear.
    """
    search_upper = re.sub(r"\s+", " ", search_text).upper()
    search_stripped = re.sub(r"\s+", "", search_text).upper() if ocr_tolerant else None
    result = []
    for section in sections:
        title = section.get("section_title", "")
        normalised = re.sub(r"\s+", " ", title).upper()
        if search_upper in normalised:
            result.append(section)
        elif search_stripped:
            title_stripped = re.sub(r"\s+", "", title).upper()
            if search_stripped in title_stripped:
                result.append(section)
    return result


def find_section_by_number(sections: list[dict], section_number: str) -> dict | None:
    """
    Find a section by its exact section number.

    Args:
        sections: List of section dicts from SplitHTML.
        section_number: The section number to match (e.g., "5.2").

    Returns:
        The matching section dict, or None if not found.
    """
    for section in sections:
        if section.get("section_number", "") == section_number:
            return section
    return None
