import re
from raw_docx.raw_table import RawTable
from raw_docx.raw_table_row import RawTableRow
from raw_docx.raw_table_cell import RawTableCell
from raw_docx.raw_paragraph import RawParagraph
from raw_docx.raw_section import RawSection


@staticmethod
def text_within(this_text: str, in_text: str) -> bool:
    """
    Check if text is contained within another text (case-insensitive, whitespace-normalized).

    Args:
        this_text: Text to search for
        in_text: Text to search in

    Returns:
        True if this_text is found in in_text
    """
    clean_text = re.sub(r"\s+", " ", in_text)
    return this_text.upper() in clean_text.upper()


@staticmethod
def table_get_row(table: RawTable, key: str) -> str:
    """
    Get the value from the second cell of the first row matching the key.

    Args:
        table: RawTable object
        key: Text to search for in the first cell

    Returns:
        Text from the second cell of the matching row, or empty string
    """
    for row in table.rows:
        if row.cells[0].is_text():
            if text_within(key, row.cells[0].text()):
                cell = row.next_cell(0)
                result = cell.text() if cell else ""
                return result.strip()
    return ""


@staticmethod
def table_get_row_html(table: RawTable, key: str) -> str:
    """
    Get the HTML from the second cell of the first row matching the key.

    Args:
        table: RawTable object
        key: Text to search for in the first cell

    Returns:
        HTML from the second cell of the matching row, or empty string
    """
    for row in table.rows:
        if row.cells[0].is_text():
            if text_within(key, row.cells[0].text()):
                cell = row.next_cell(0)
                return cell.to_html() if cell else ""
    return ""


@staticmethod
def section_get_para(section: RawSection, search_text: str) -> str:
    """
    Get text after a colon in the first paragraph containing search_text.

    Args:
        section: RawSection object
        search_text: Text to search for

    Returns:
        Text after the colon, or empty string
    """
    para: RawParagraph
    for para in section.paragraphs():
        if text_within(search_text, para.text):
            parts = para.text.split(":")
            return (":").join(parts[1:]).strip() if len(parts) >= 2 else ""
    return ""


@staticmethod
def section_get_text_between(section: RawSection, start_text: str, end_text: str) -> str:
    """
    Extract text between two markers in a section.

    Args:
        section: RawSection object
        start_text: Text marking the start of the range
        end_text: Text marking the end of the range

    Returns:
        Text between the markers, or empty string
    """
    full_text = _get_section_text(section)
    clean_text = re.sub(r"[^\S\n]+", " ", full_text)
    clean_upper = clean_text.upper()
    start_pos = clean_upper.find(start_text.upper())
    if start_pos == -1:
        return ""
    after_start = start_pos + len(start_text)
    end_pos = clean_upper.find(end_text.upper(), after_start)
    if end_pos == -1:
        return ""
    result = clean_text[after_start:end_pos].strip()
    return result


@staticmethod
def section_find_para(section: RawSection, search_text: str) -> int:
    """
    Find the index of the first paragraph containing search_text.

    Args:
        section: RawSection object
        search_text: Text to search for

    Returns:
        Index of the matching paragraph, or None
    """
    for index, para in enumerate(section.paragraphs()):
        if text_within(search_text, para.text):
            return index
    return None


@staticmethod
def _get_section_text(section: RawSection) -> str:
    """
    Extract all text from a section, combining tables and paragraphs.

    Args:
        section: RawSection object

    Returns:
        All text from the section joined by newlines
    """
    parts = []
    for item in section.items:
        if isinstance(item, RawTable):
            row: RawTableRow
            item: RawTable
            for row in item.rows:
                row_text = []
                cell: RawTableCell
                for cell in row.cells:
                    row_text.append(cell.text())
                parts.append(" ".join(row_text))
        elif isinstance(item, RawParagraph):
            parts.append(item.text)
    return "\n".join(parts)
