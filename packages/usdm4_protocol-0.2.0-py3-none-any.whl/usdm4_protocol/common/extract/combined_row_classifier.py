"""Combined AI + heuristic row classification for SoA tables.

Runs both the AI classifier and the deterministic heuristic classifier,
then merges their results using consensus logic. This lives in common/
so that both the M11 (SoA) and Legacy (ScheduleOfActivities) orchestrators
can use a single classification method.

Consensus rules:
1. Agreement — both assign the same type to a row → use it (highest confidence).
2. AI only — AI assigns a type, heuristic doesn't → use AI assignment.
3. Heuristic only — heuristic assigns a type, AI didn't → use heuristic.
4. Conflict — AI and heuristic disagree about a row → prefer the classifier
   whose assignment is uncontested by the other (i.e. the other classifier
   assigned that row a different type or didn't assign it at all).
   If both are contested, prefer AI (it has holistic context).
"""

from simple_error_log.errors import Errors
from simple_error_log.error_location import KlassMethodLocation
from usdm4_protocol.common.ai.base_ai import BaseAIProvider
from usdm4_protocol.common.extract.soa_row_classifier import SoARowClassifier
from usdm4_protocol.soa.features.row_classifier import RowClassifier


class CombinedRowClassifier:
    """Merges AI and heuristic SoA row classification for best results.

    Both classifiers run independently, then their outputs are combined
    using consensus logic. The merged result is a single dict mapping
    row_index (0-based) → row_type string, plus extracted hints for
    each feature type.
    """

    MODULE = "usdm4_protocol.common.extract.combined_row_classifier.CombinedRowClassifier"

    # Row types that should appear at most once
    UNIQUE_TYPES = {"epoch", "timepoint", "window"}

    def __init__(self, errors: Errors, ai: BaseAIProvider | None = None):
        """
        Initialize the combined classifier.

        Args:
            errors: Error logging object.
            ai: An AI provider instance. May be None if AI is not available.
        """
        self._errors = errors
        self._ai_classifier = SoARowClassifier(ai, errors) if ai else None
        self._heuristic_classifier = RowClassifier(errors)

    def classify(self, table_html: str, max_rows: int) -> dict[int, str]:
        """Classify header rows using combined AI + heuristic evidence.

        Args:
            table_html: HTML string of the SoA table.
            max_rows: Maximum number of rows to analyze (typically first_activity_row + 1).

        Returns:
            dict mapping row_index (0-based) → row_type string.
        """
        try:
            ai_classification = self._run_ai(table_html)
            heuristic_classification = self._run_heuristic(table_html, max_rows)
            merged = self._merge(ai_classification, heuristic_classification)
            self._errors.info(
                f"Combined row classification: {merged}",
                KlassMethodLocation(self.MODULE, "classify"),
            )
            return merged
        except Exception as e:
            self._errors.exception(
                "Exception in combined row classification",
                e,
                KlassMethodLocation(self.MODULE, "classify"),
            )
            return {}

    def get_hints(self, classification: dict[int, str]) -> dict[str, int | None]:
        """Extract row hints from classification for each feature type.

        Args:
            classification: dict mapping row_index → row_type.

        Returns:
            dict with keys "epoch", "visit", "timepoint", "window",
            each mapping to a row index or None.
        """
        hints: dict[str, int | None] = {
            "epoch": None,
            "visit": None,
            "timepoint": None,
            "window": None,
        }
        for row_idx, row_type in classification.items():
            if row_type in hints:
                hints[row_type] = row_idx
        return hints

    def _run_ai(self, table_html: str) -> dict[int, str]:
        """Run AI classifier and convert result to 0-based row→type dict."""
        if not self._ai_classifier:
            return {}
        try:
            ai_result = self._ai_classifier.classify(table_html)
            if not ai_result or "rows" not in ai_result:
                return {}
            classification = {}
            for entry in ai_result["rows"]:
                row_idx = entry.get("row", 0) - 1  # AI uses 1-based
                row_type = entry.get("type", "")
                if row_idx >= 0 and row_type and row_type != "other":
                    classification[row_idx] = row_type
            if classification:
                self._errors.info(
                    f"AI classification: {classification}",
                    KlassMethodLocation(self.MODULE, "_run_ai"),
                )
            return classification
        except Exception as e:
            self._errors.warning(
                f"AI classification failed: {e}",
                KlassMethodLocation(self.MODULE, "_run_ai"),
            )
            return {}

    def _run_heuristic(self, table_html: str, max_rows: int) -> dict[int, str]:
        """Run heuristic classifier."""
        try:
            result = self._heuristic_classifier.classify_rows(table_html, max_rows)
            if result:
                self._errors.info(
                    f"Heuristic classification: {result}",
                    KlassMethodLocation(self.MODULE, "_run_heuristic"),
                )
            return result
        except Exception as e:
            self._errors.warning(
                f"Heuristic classification failed: {e}",
                KlassMethodLocation(self.MODULE, "_run_heuristic"),
            )
            return {}

    def _merge(
        self,
        ai: dict[int, str],
        heuristic: dict[int, str],
    ) -> dict[int, str]:
        """Merge AI and heuristic classifications using consensus logic.

        Strategy:
        1. Collect all row indices from both classifiers.
        2. For each row, determine if classifiers agree, only one assigned,
           or they conflict.
        3. Build merged result ensuring no type appears more than once
           (for unique types: epoch, timepoint, window).
        """
        if not ai and not heuristic:
            return {}
        if not ai:
            return dict(heuristic)
        if not heuristic:
            return dict(ai)

        # Collect all rows mentioned by either classifier
        all_rows = sorted(set(ai.keys()) | set(heuristic.keys()))

        # Build candidate assignments with source tracking
        candidates: list[dict] = []
        for row_idx in all_rows:
            ai_type = ai.get(row_idx)
            h_type = heuristic.get(row_idx)

            if ai_type and h_type and ai_type == h_type:
                # Agreement — strongest signal
                candidates.append(
                    {
                        "row": row_idx,
                        "type": ai_type,
                        "source": "agreement",
                        "priority": 3,
                    }
                )
            elif ai_type and h_type and ai_type != h_type:
                # Conflict — include both, resolve during assignment
                candidates.append(
                    {
                        "row": row_idx,
                        "type": ai_type,
                        "source": "ai_contested",
                        "priority": 1,
                    }
                )
                candidates.append(
                    {
                        "row": row_idx,
                        "type": h_type,
                        "source": "heuristic_contested",
                        "priority": 0,
                    }
                )
            elif ai_type:
                # AI only
                candidates.append(
                    {
                        "row": row_idx,
                        "type": ai_type,
                        "source": "ai_only",
                        "priority": 2,
                    }
                )
            elif h_type:
                # Heuristic only
                candidates.append(
                    {
                        "row": row_idx,
                        "type": h_type,
                        "source": "heuristic_only",
                        "priority": 2,
                    }
                )

        # Greedy assignment: sort by priority (highest first), then assign
        # ensuring each row and each unique type is used at most once.
        candidates.sort(key=lambda c: c["priority"], reverse=True)
        result: dict[int, str] = {}
        used_rows: set[int] = set()
        used_unique_types: set[str] = set()

        for candidate in candidates:
            row_idx = candidate["row"]
            row_type = candidate["type"]

            if row_idx in used_rows:
                continue
            if row_type in self.UNIQUE_TYPES and row_type in used_unique_types:
                continue

            result[row_idx] = row_type
            used_rows.add(row_idx)
            if row_type in self.UNIQUE_TYPES:
                used_unique_types.add(row_type)

        # Log conflicts for debugging
        for row_idx in all_rows:
            ai_type = ai.get(row_idx)
            h_type = heuristic.get(row_idx)
            if ai_type and h_type and ai_type != h_type:
                chosen = result.get(row_idx, "none")
                self._errors.info(
                    f"Row {row_idx} conflict: AI={ai_type}, heuristic={h_type}, chosen={chosen}",
                    KlassMethodLocation(self.MODULE, "_merge"),
                )

        return result
