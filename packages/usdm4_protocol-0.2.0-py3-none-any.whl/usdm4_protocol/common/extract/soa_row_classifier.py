from bs4 import BeautifulSoup
from simple_error_log.errors import Errors
from simple_error_log.error_location import KlassMethodLocation
from usdm4_protocol.common.ai.base_ai import BaseAIProvider
from usdm4_protocol.common.extract.content_extractor import ContentExtractor


class SoARowClassifier:
    """AI-based classification of SoA table header rows.

    Sends the header rows (plus a few activity rows for context) to Claude
    in a single call and receives back a structured JSON classifying each row.

    Row types: epoch, visit, timepoint, window, activity_header, other.
    """

    MODULE = "usdm4_protocol.common.extract.soa_row_classifier.SoARowClassifier"

    SYSTEM_MESSAGE = (
        "You are an expert at analyzing Schedule of Activities (SoA) tables from "
        "clinical trial protocol documents. You classify header rows by their semantic "
        "type with high accuracy. You understand that SoA tables vary widely across "
        "sponsors and therapeutic areas — row labels may use non-standard terminology "
        "and table structures differ significantly between protocols. You always return "
        "valid JSON and nothing else."
    )

    def __init__(self, ai: BaseAIProvider, errors: Errors):
        """
        Initialize the SoA row classifier.

        Args:
            ai: An AI provider instance. May be None if AI is not available.
            errors: Error logging object.
        """
        self._errors = errors
        self._content_extractor = ContentExtractor(ai, errors)

    def classify(self, table_html: str) -> dict | None:
        """Classify header rows in the SoA table using AI.

        Args:
            table_html: HTML string of the full SoA table.

        Returns:
            A dict with structure:
                {
                    "rows": [
                        {"row": 1, "type": "epoch", "confidence": 0.95},
                        {"row": 2, "type": "visit", "confidence": 0.90},
                        ...
                    ],
                    "has_multi_cycle": false,
                    "notes_column": "last"
                }
            Or None on failure.
        """
        try:
            if not self._content_extractor.ai_available:
                return None

            header_html = self._extract_header_rows(table_html)
            if not header_html:
                self._errors.warning(
                    "No header rows found for AI classification",
                    KlassMethodLocation(self.MODULE, "classify"),
                )
                return None

            prompt = self._build_prompt(header_html)
            result = self._content_extractor.extract(
                header_html,
                prompt,
                as_list=False,
                system_message=self.SYSTEM_MESSAGE,
                task_type="soa_row_classification",
            )

            if result:
                validated = self._validate_and_clean(result)
                if validated:
                    self._errors.info(
                        f"AI SoA classification: {validated}",
                        KlassMethodLocation(self.MODULE, "classify"),
                    )
                    return validated

            self._errors.warning(
                "AI SoA classification returned invalid result",
                KlassMethodLocation(self.MODULE, "classify"),
            )
            return None
        except Exception as e:
            self._errors.exception(
                "Exception during AI SoA classification",
                e,
                KlassMethodLocation(self.MODULE, "classify"),
            )
            return None

    def _extract_header_rows(self, table_html: str) -> str:
        """Extract the first N rows (headers + a few activity rows for context).

        Finds the first row containing an "X" marker, then takes all rows up to
        that point plus 2 additional activity rows.

        Returns:
            HTML string of the extracted rows within a <table> wrapper.
        """
        try:
            soup = BeautifulSoup(table_html, "html.parser")
            table = soup.find("table")
            if not table:
                return ""

            rows = table.find_all("tr")
            if not rows:
                return ""

            # Find the first activity row (contains X markers)
            first_activity = len(rows)
            for i, row in enumerate(rows):
                cells = row.find_all(["td", "th"])
                cell_texts = [c.get_text(strip=True).upper() for c in cells]
                if "X" in cell_texts:
                    first_activity = i
                    break

            # Take headers + 2 context rows
            end = min(first_activity + 3, len(rows))
            selected_rows = rows[:end]

            # Build a new table with just these rows
            parts = ["<table>"]
            for row in selected_rows:
                parts.append(str(row))
            parts.append("</table>")
            return "\n".join(parts)
        except Exception:
            return ""

    def _build_prompt(self, header_html: str) -> str:
        """Build the AI prompt for SoA row classification."""
        return f"""Classify each header row in this Schedule of Activities (SoA) table by its semantic type.

The table shows header rows followed by a few activity/data rows for context. Activity rows
contain "X" markers indicating which procedures are performed at which visits.

## Row Types

**epoch** — Study period or phase labels spanning groups of visits.
  - Common labels: Screening, Treatment, Follow-up, Baseline, Washout, Run-in, End of Study
  - Non-standard labels that are ALSO epochs: "Period 1", "Period 2", "Part A", "Part B",
    "Cycle 1", "Cycle 2", "Phase 1", "Phase 2", "Open-label", "Double-blind"
  - Typically the first row. Cells often span multiple columns (same text repeated across
    adjacent cells after colspan expansion).
  - First column may be empty, or say "Epoch", "Period", "Phase", "Study Period", "Study Phase".

**visit** — Visit identifiers (labels or numbers for individual protocol visits).
  - Common patterns: "V1", "V2", "Visit 1", "SCN", "SCR", "BL", "EoS", "ET", "EDV",
    "Day 1 Visit", "Week 4 Visit"
  - Non-standard labels that are ALSO visits: "Assessment 1", "Assessment 2", "Evaluation 1"
  - First column often says "Visit", "Study Visit", or is empty.
  - Each cell represents a distinct visit — values are usually unique across the row.

**timepoint** — Numeric timing values indicating when visits occur.
  - Common patterns: bare numbers ("-28", "1", "15", "168"), "Day 1", "D8", "D15",
    "Week 4", "Month 3", ranges ("Day -28 ~ -17"), inequalities ("≤28"),
    tolerances ("Day 120 ± 2"), "CCI" (redacted values).
  - First column often says "Day", "Week", "Study Day", "Target Day", "(Day)".
  - In multi-cycle tables, values may reset at cycle boundaries (e.g., D1, D8, D15 → D1, D8).
    This is valid — do NOT reject the row because values decrease.

**window** — Time window tolerances for visit scheduling.
  - Common patterns: "±3 days", "+2/-1", "±1 week", "±7", "+3".
  - First column often says "Window", "Study Day Window", "Visit Window".

**activity_header** — A merged parent row where ALL cells contain the same text.
  - This is a section heading grouping child activities below it.
  - It does NOT contain X markers.

**other** — Any row that does not match the types above.

## Rules

1. Only classify the header rows (rows BEFORE the first row containing "X" markers).
   Activity rows with X markers should be typed as "other".
2. Each header row gets exactly one type.
3. Epoch, timepoint, and window should each appear AT MOST once. Visit may also appear
   at most once. If you see two candidate rows for the same type, choose the stronger match.
4. "has_multi_cycle": set true if timepoint values appear to reset (decrease then increase
   again across cycle boundaries), indicating multiple treatment cycles.
5. "notes_column": set to "last" if the rightmost column appears to contain references
   or footnote markers (e.g., "Section 8.1", "a,b"), otherwise "none".
6. "row" numbers are 1-based (first row = 1).
7. Return ONLY valid JSON — no markdown fences, no explanation.

## Output Format

{{
  "rows": [
    {{"row": 1, "type": "<type>", "confidence": <0.0-1.0>}},
    {{"row": 2, "type": "<type>", "confidence": <0.0-1.0>}}
  ],
  "has_multi_cycle": <true/false>,
  "notes_column": "<last/none>"
}}

## Table

{header_html}"""

    def _validate_and_clean(self, result: dict) -> dict | None:
        """Validate and clean the AI classification result.

        Unlike the previous _validate_result, this method does NOT reject the
        entire result when there are duplicate type assignments. Instead, it
        keeps the highest-confidence assignment for each unique type and
        downgrades duplicates to "other". This preserves valid partial results
        when the AI makes one incorrect duplicate assignment.
        """
        if not isinstance(result, dict):
            return None
        if "rows" not in result:
            return None
        if not isinstance(result["rows"], list):
            return None

        valid_types = {"epoch", "visit", "timepoint", "window", "activity_header", "other"}

        # First pass: validate individual entries
        cleaned_rows = []
        for entry in result["rows"]:
            if not isinstance(entry, dict):
                continue
            if "row" not in entry or "type" not in entry:
                continue
            row_type = entry["type"]
            if row_type not in valid_types:
                continue
            cleaned_rows.append(entry)

        if not cleaned_rows:
            return None

        # Second pass: enforce uniqueness for constrained types.
        # Keep the highest-confidence assignment; downgrade duplicates.
        unique_types = {"epoch", "timepoint", "window", "visit"}
        best_for_type: dict[str, dict] = {}

        for entry in cleaned_rows:
            row_type = entry["type"]
            if row_type in unique_types:
                confidence = entry.get("confidence", 0.5)
                if row_type not in best_for_type or confidence > best_for_type[row_type].get("confidence", 0.5):
                    best_for_type[row_type] = entry

        # Build final rows list: keep best assignment for unique types,
        # downgrade duplicates to "other"
        final_rows = []
        for entry in cleaned_rows:
            row_type = entry["type"]
            if row_type in unique_types:
                if entry is best_for_type.get(row_type):
                    final_rows.append(entry)
                else:
                    # Duplicate — downgrade to "other" and log
                    self._errors.warning(
                        f"Duplicate {row_type} assignment at row {entry.get('row')}, "
                        f"keeping row {best_for_type[row_type].get('row')} instead",
                        KlassMethodLocation(self.MODULE, "_validate_and_clean"),
                    )
                    downgraded = dict(entry)
                    downgraded["type"] = "other"
                    final_rows.append(downgraded)
            else:
                final_rows.append(entry)

        result["rows"] = final_rows
        return result
