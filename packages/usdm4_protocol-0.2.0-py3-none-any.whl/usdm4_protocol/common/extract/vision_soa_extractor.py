"""
Vision-Based SoA Extractor
===========================

Fallback extraction path for protocols where the HTML extraction pipeline
(Docling) produces incomplete or empty SoA table data.  Renders PDF pages
as images and sends them to Claude vision to produce an HTML ``<table>``
string compatible with ``decode_soa()``.

This module is self-contained: page finding, image rendering, and vision
extraction are all encapsulated here.  The page-finding heuristics are
adapted from ``corpus/generate_ground_truth.py`` (keyword scoring + X-mark
scanning + gap fill + boundary expansion).

Design document: ``docs/vision_fallback_design.md``
"""

import base64
import os
import re
import tempfile

from simple_error_log.errors import Errors
from simple_error_log.error_location import KlassMethodLocation

try:
    import pymupdf

    PYMUPDF_AVAILABLE = True
except ImportError:
    PYMUPDF_AVAILABLE = False

try:
    from anthropic import Anthropic
    from d4k_ms_base.service_environment import ServiceEnvironment

    ANTHROPIC_AVAILABLE = True
except ImportError:
    ANTHROPIC_AVAILABLE = False


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

XMARK_PATTERN = re.compile(r"^[Xx✓✔√●•]$")
MIN_XMARK_PAGE = 3
MIN_PAGE_SCORE = 2.0

SOA_KEYWORDS = [
    "schedule of activities",
    "schedule of assessments",
    "study schedule",
    "study procedures",
    "time and events",
    "schedule of visits",
    "schedule of evaluations",
]

TABLE_STRUCTURE_PATTERNS = [
    r"\bvisit\s*\d+",
    r"\bweek\s*[-+]?\d+",
    r"\bday\s*[-+]?\d+",
    r"\bscreening\b",
    r"\bbaseline\b",
    r"\bend\s*of\s*treatment",
    r"\bfollow[-\s]*up\b",
    r"\btreatment\s+period\b",
]

VISION_MODEL = "claude-sonnet-4-20250514"
SCREENING_MODEL = "claude-haiku-4-5-20251001"
SCREENING_DPI = 150

VISION_SYSTEM_MESSAGE = (
    "You are a clinical trial protocol analyst specialising in extracting "
    "Schedule of Activities (SoA) tables. You produce structured HTML tables "
    "from page images with high fidelity and consistency. You never add "
    "activities, visits, or marks that are not visible in the images."
)

VISION_PROMPT = """Extract the Schedule of Activities (SoA) table from these clinical trial protocol page images into a single HTML <table>.

## OUTPUT FORMAT

The table MUST be in CROSS-TABULATION format:
- Each ACTIVITY appears as exactly ONE row
- Each VISIT/ENCOUNTER appears as exactly ONE column
- The intersection cells contain "X" where the activity is performed at that visit, or are empty

## TABLE STRUCTURE

1. HEADER ROWS (at the top of the table):
   - Row 1 (if present): Epoch/phase labels (e.g. "Screening", "Treatment", "Follow-up"). Use <th colspan="N"> to span the correct number of visit columns.
   - Row 2: Visit labels (e.g. "Visit 1", "V2", "Screening", "Day 1"). One <th> per visit column.
   - Row 3 (if present): Timepoint values (e.g. "Day -28", "Week 4"). One <th> per visit column.
   - Row 4 (if present): Window values (e.g. "±3 days"). One <th> per visit column.
   - Use <th> for all header cells.

2. DATA ROWS (activity rows):
   - First cell: activity/procedure name (use <td>)
   - Remaining cells: "X" where performed, empty string where not (use <td>)
   - Each activity appears ONCE — never repeat an activity across multiple rows

3. GROUP/CATEGORY ROWS (if present):
   - Bold category headers like "Laboratory Tests" or "Safety Assessments"
   - Include as a row with the label in the first cell and remaining cells empty
   - These help preserve the grouping structure

## MULTI-PAGE TABLE RULES

These images show pages from the SAME table that spans multiple PDF pages. You MUST combine them into ONE table:

- Use the header rows from the FIRST page only
- SKIP duplicate header rows on continuation pages (pages 2, 3, etc. often repeat the column headers)
- Append all activity/data rows from all pages in document order
- The column structure is IDENTICAL across all pages — do not add or remove columns
- If a page shows the same visits as the first page, it is a continuation with MORE activities (more rows), not a different table

## CONTENT RULES

- Preserve activity names EXACTLY as they appear (spelling, capitalisation, abbreviations)
- Preserve visit labels EXACTLY as they appear
- Preserve timepoint values EXACTLY (Day -28, Week 4, ±3, etc.)
- Normalise all activity marks to "X" — convert ✓, ✔, √, ●, •, Yes, Y to "X"
- Preserve footnote markers as superscript: <sup>a</sup>, <sup>1</sup>
- Mark cells with ONLY a footnote marker (no X) as containing just the superscript
- For cells with both X and a footnote marker, use: X<sup>a</sup>

## WHAT TO EXCLUDE

- No <table> attributes (no class, style, id, border, etc.)
- No page headers, footers, page numbers, or document stamps
- No content outside the <table> tags
- No markdown code fences or explanatory text
- No <div>, <span>, or wrapper elements around the table

## ACCURACY

- Only mark "X" where you can clearly see a mark in the image
- If a cell is ambiguous or hard to read, leave it EMPTY rather than guessing
- Do not infer patterns — extract only what is visible
- Count your columns carefully: every data row must have the same number of cells as the header row

Return ONLY the <table>...</table> HTML."""


# ---------------------------------------------------------------------------
# Page finding
# ---------------------------------------------------------------------------


def score_page(text: str) -> dict:
    """Score a page's likelihood of containing SoA content."""
    text_lower = text.lower()
    keyword_score = 0.0
    for kw in SOA_KEYWORDS:
        if kw in text_lower:
            keyword_score += 2.0

    structure_score = 0.0
    for pattern in TABLE_STRUCTURE_PATTERNS:
        matches = re.findall(pattern, text_lower, re.IGNORECASE)
        if matches:
            structure_score += len(matches) * 0.3

    visit_matches = re.findall(r"visit\s*\d+", text_lower, re.IGNORECASE)
    if len(visit_matches) >= 3:
        structure_score += 2.0

    return {
        "keyword_score": keyword_score,
        "structure_score": structure_score,
        "total": keyword_score + structure_score,
    }


def count_xmarks_on_page(pdf_path: str, page_num: int) -> int:
    """Count X-marks on a single page via PyMuPDF tables."""
    doc = pymupdf.open(pdf_path)
    page = doc[page_num]
    tables_result = page.find_tables()
    count = 0
    for table in tables_result.tables:
        for row in table.extract():
            for cell in row:
                if cell and XMARK_PATTERN.match(cell.strip()):
                    count += 1
    doc.close()
    return count


def find_soa_pages(pdf_path: str) -> list[int]:
    """Find pages containing SoA tables using heuristics + X-mark scan.

    Returns 0-indexed page numbers sorted in order.

    Algorithm:
        1. Score all pages using keyword + structural pattern heuristics
        2. Filter candidates above MIN_PAGE_SCORE
        3. X-mark scan on candidates (and full PDF if no candidates pass)
        4. Gap fill (max gap 3) and ±1 boundary expansion
    """
    doc = pymupdf.open(pdf_path)
    total_pages = len(doc)

    # Score all pages
    candidates = []
    for page_num in range(total_pages):
        text = doc[page_num].get_text()
        scores = score_page(text)
        if scores["total"] >= MIN_PAGE_SCORE:
            candidates.append(page_num)
    doc.close()

    # X-mark scan on candidates
    xmark_pages = []
    for page_num in candidates:
        xm = count_xmarks_on_page(pdf_path, page_num)
        if xm >= MIN_XMARK_PAGE:
            xmark_pages.append(page_num)

    # If no X-mark pages found from candidates, scan all pages
    if not xmark_pages:
        doc = pymupdf.open(pdf_path)
        for page_num in range(total_pages):
            tables_result = doc[page_num].find_tables()
            xm = 0
            for table in tables_result.tables:
                for row in table.extract():
                    for cell in row:
                        if cell and XMARK_PATTERN.match(cell.strip()):
                            xm += 1
            if xm >= MIN_XMARK_PAGE:
                xmark_pages.append(page_num)
        doc.close()

    # Select seed pages: X-mark pages preferred, heuristic candidates as fallback
    seed_pages = xmark_pages if xmark_pages else candidates[:5]
    if not seed_pages:
        return []

    # Gap fill (max gap 3) and boundary expand ±1
    expanded = set(seed_pages)
    sorted_p = sorted(seed_pages)
    for i in range(len(sorted_p) - 1):
        start, end = sorted_p[i], sorted_p[i + 1]
        if end - start <= 3:
            for gap in range(start + 1, end):
                expanded.add(gap)

    mn, mx = min(expanded), max(expanded)
    doc = pymupdf.open(pdf_path)
    tp = len(doc)
    doc.close()
    if mn - 1 >= 0:
        expanded.add(mn - 1)
    if mx + 1 < tp:
        expanded.add(mx + 1)

    return sorted(expanded)


# ---------------------------------------------------------------------------
# Image rendering
# ---------------------------------------------------------------------------


def render_pages(pdf_path: str, page_numbers: list[int], output_dir: str, dpi: int = 300) -> list[dict]:
    """Render PDF pages as PNG images.

    Returns list of ``{"page": int, "page_display": int, "path": str}``.
    """
    os.makedirs(output_dir, exist_ok=True)
    doc = pymupdf.open(pdf_path)
    results = []
    for page_num in page_numbers:
        if 0 <= page_num < len(doc):
            page = doc[page_num]
            pix = page.get_pixmap(dpi=dpi)
            img_path = os.path.join(output_dir, f"page_{page_num + 1:03d}.png")
            pix.save(img_path)
            results.append(
                {
                    "page": page_num,
                    "page_display": page_num + 1,
                    "path": img_path,
                }
            )
    doc.close()
    return results


# ---------------------------------------------------------------------------
# Page screening (Phase 1 — cheap Haiku call to filter candidates)
# ---------------------------------------------------------------------------

SCREENING_PROMPT = """Look at each numbered page image. For each page, answer YES or NO: does this page contain a Schedule of Activities (SoA) table?

An SoA table is a GRID with:
- Activity/procedure names listed as ROWS on the left
- Visit/timepoint labels as COLUMNS across the top
- X marks (or checkmarks/dots) in the grid cells showing which activities occur at which visits

Answer with ONLY a JSON array of page numbers that contain an SoA table. Example: [5, 6, 7]
If no pages contain an SoA table, return: []"""


def screen_pages(image_paths: list[dict], client, model: str = SCREENING_MODEL) -> list[int]:
    """Screen candidate pages to identify which actually contain SoA tables.

    Sends low-DPI thumbnails to a fast model (Haiku) in a single call.
    Returns 0-indexed page numbers of confirmed SoA pages.

    Args:
        image_paths: List of dicts with "path", "page_display", and "page" keys.
        client: An ``anthropic.Anthropic`` client instance.
        model: Model to use for screening (default: Haiku for speed/cost).

    Returns:
        List of 0-indexed page numbers confirmed to contain SoA tables.
        Returns all input pages on any failure (fail-open).
    """
    if not image_paths:
        return []

    content = []
    for img in image_paths:
        with open(img["path"], "rb") as f:
            image_data = base64.b64encode(f.read()).decode("utf-8")
        content.append(
            {
                "type": "text",
                "text": f"Page {img['page_display']}:",
            }
        )
        content.append(
            {
                "type": "image",
                "source": {
                    "type": "base64",
                    "media_type": "image/png",
                    "data": image_data,
                },
            }
        )

    content.append({"type": "text", "text": SCREENING_PROMPT})

    try:
        response_text = ""
        with client.messages.stream(
            model=model,
            max_tokens=256,
            temperature=0.0,
            messages=[{"role": "user", "content": content}],
        ) as stream:
            for text in stream.text_stream:
                response_text += text

        # Parse the JSON array of 1-indexed page numbers
        import json

        # Extract JSON array from response (may have surrounding text)
        array_match = re.search(r"\[[\d\s,]*\]", response_text)
        if array_match:
            page_numbers_1indexed = json.loads(array_match.group())
            # Convert to 0-indexed using the image_paths mapping
            display_to_zero = {img["page_display"]: img["page"] for img in image_paths}
            confirmed = [display_to_zero[p] for p in page_numbers_1indexed if p in display_to_zero]
            return confirmed
        # Empty array or unparseable → fail open
        return [img["page"] for img in image_paths]

    except Exception:
        # Fail open — return all candidates rather than losing pages
        return [img["page"] for img in image_paths]


# ---------------------------------------------------------------------------
# Vision extraction
# ---------------------------------------------------------------------------


def extract_html_via_vision(image_paths: list[dict], client, model: str = VISION_MODEL) -> str:
    """Send page images to Claude vision and extract an HTML table.

    Args:
        image_paths: List of dicts with "path" and "page_display" keys.
        client: An ``anthropic.Anthropic`` client instance.
        model: Claude model to use for vision extraction.

    Returns:
        The ``<table>...</table>`` HTML string, or empty string on failure.
    """
    # Build message content with images
    content = []
    for img in image_paths:
        with open(img["path"], "rb") as f:
            image_data = base64.b64encode(f.read()).decode("utf-8")
        content.append(
            {
                "type": "text",
                "text": f"Page {img['page_display']}:",
            }
        )
        content.append(
            {
                "type": "image",
                "source": {
                    "type": "base64",
                    "media_type": "image/png",
                    "data": image_data,
                },
            }
        )

    content.append({"type": "text", "text": VISION_PROMPT})

    # Use streaming to avoid the Anthropic SDK 10-minute timeout
    # for large multi-image requests
    response_text = ""
    with client.messages.stream(
        model=model,
        max_tokens=32768,
        temperature=0.0,
        system=VISION_SYSTEM_MESSAGE,
        messages=[{"role": "user", "content": content}],
    ) as stream:
        for text in stream.text_stream:
            response_text += text

    # Extract <table>...</table> from response
    table_match = re.search(r"<table[^>]*>[\s\S]*</table>", response_text)
    if table_match:
        return table_match.group()
    return ""


# ---------------------------------------------------------------------------
# HTML validation
# ---------------------------------------------------------------------------


def validate_vision_html(html: str) -> bool:
    """Check that vision-produced HTML has basic table structure.

    Validates:
        - Contains <tr> elements
        - Contains <td> or <th> elements
        - Contains at least one X-mark cell
    """
    if not html:
        return False
    if "<tr" not in html:
        return False
    if "<td" not in html and "<th" not in html:
        return False
    # Check for at least one X-mark
    xmark_pattern = re.compile(r"<t[dh][^>]*>\s*X\s*</t[dh]>", re.IGNORECASE)
    if not xmark_pattern.search(html):
        return False
    return True


# ---------------------------------------------------------------------------
# Quality gate
# ---------------------------------------------------------------------------

# Minimum X-mark count below which vision fallback is triggered
MIN_VISION_XMARKS = 5


def needs_vision_fallback(table_html: str, first_activity_row: int) -> bool:
    """Decide whether the merged HTML table needs vision fallback.

    Three signals, checked in order:

    1. **No table found**: ``table_html`` is empty.
    2. **No activity rows**: ``first_activity_row == -1``.
    3. **Low X-mark density**: fewer than ``MIN_VISION_XMARKS`` X-marks.

    Args:
        table_html: The merged HTML table from Phase 2.
        first_activity_row: Result from ``ActivityRowFeature``.
            Use -1 if activity detection has not been run yet.

    Returns:
        True if vision extraction should be attempted.
    """
    # Signal 1: no table
    if not table_html or not table_html.strip():
        return True

    # Signal 2: no activity rows
    if first_activity_row == -1:
        return True

    # Signal 3: low X-mark count
    from bs4 import BeautifulSoup

    soup = BeautifulSoup(table_html, "html.parser")
    xmark_count = 0
    for cell in soup.find_all(["td", "th"]):
        if cell.get_text(strip=True).upper() == "X":
            xmark_count += 1
    if xmark_count < MIN_VISION_XMARKS:
        return True

    return False


# ---------------------------------------------------------------------------
# Main extractor class
# ---------------------------------------------------------------------------


class VisionSoAExtractor:
    """Extract SoA table HTML from PDF page images via Claude vision.

    This is the fallback path for protocols where the HTML extraction
    pipeline (Docling) produces incomplete or empty table data.

    Usage::

        extractor = VisionSoAExtractor(pdf_path, errors)
        table_html, footnote_html = extractor.extract()
        if table_html:
            result = decode_soa(table_html, footnote_html, ...)
    """

    MODULE = "usdm4_protocol.common.extract.vision_soa_extractor.VisionSoAExtractor"

    def __init__(self, pdf_path: str, errors: Errors, logger=None):
        """
        Args:
            pdf_path: Absolute path to the protocol PDF file.
            errors: Error logging object.
            logger: Optional ``TrainingDataLogger`` for capturing vision
                prompt/response pairs.  Created and managed by the
                pipeline entry point (``ExtractStudy``) and passed
                through via ``ScheduleOfActivities``.
        """
        self._pdf_path = pdf_path
        self._errors = errors
        self._client = None
        self._logger = logger

        # Initialise Anthropic client
        if ANTHROPIC_AVAILABLE:
            try:
                api_key = ServiceEnvironment().get("ANTHROPIC_API_KEY")
                if api_key:
                    self._client = Anthropic(api_key=api_key)
            except Exception as e:
                self._errors.warning(
                    f"Could not initialise Anthropic client for vision: {e}",
                    KlassMethodLocation(self.MODULE, "__init__"),
                )

    @property
    def available(self) -> bool:
        """Whether vision extraction is possible (dependencies + API key)."""
        return PYMUPDF_AVAILABLE and self._client is not None

    def extract(self) -> tuple[str, str]:
        """Extract SoA table HTML from PDF page images.

        Returns:
            ``(table_html, footnote_html)`` tuple.  ``footnote_html`` is
            always empty — vision does not extract footnotes separately.
            Returns ``("", "")`` on any failure.
        """
        if not self.available:
            self._errors.info(
                "Vision extraction not available (missing pymupdf or API key)",
                KlassMethodLocation(self.MODULE, "extract"),
            )
            return "", ""

        try:
            return self._do_extract()
        except Exception as e:
            self._errors.exception(
                "Vision SoA extraction failed",
                e,
                KlassMethodLocation(self.MODULE, "extract"),
            )
            return "", ""

    def _do_extract(self) -> tuple[str, str]:
        """Internal extraction pipeline."""
        # Step 1: Find candidate SoA pages (heuristic)
        pages = find_soa_pages(self._pdf_path)
        if not pages:
            self._errors.warning(
                "No SoA pages found in PDF for vision extraction",
                KlassMethodLocation(self.MODULE, "_do_extract"),
            )
            return "", ""

        self._errors.info(
            f"Vision fallback: found {len(pages)} candidate pages (1-indexed: {[p + 1 for p in pages]})",
            KlassMethodLocation(self.MODULE, "_do_extract"),
        )

        # Step 2: Screen candidates with Haiku at low DPI
        with tempfile.TemporaryDirectory() as screen_dir:
            screen_images = render_pages(
                self._pdf_path,
                pages,
                screen_dir,
                dpi=SCREENING_DPI,
            )
            if screen_images:
                confirmed = screen_pages(
                    screen_images,
                    self._client,
                    SCREENING_MODEL,
                )
                if confirmed:
                    dropped = set(pages) - set(confirmed)
                    if dropped:
                        self._errors.info(
                            f"Vision screening: kept {len(confirmed)} pages, "
                            f"dropped {len(dropped)} "
                            f"(1-indexed dropped: {sorted(p + 1 for p in dropped)})",
                            KlassMethodLocation(self.MODULE, "_do_extract"),
                        )
                    pages = confirmed
                else:
                    self._errors.warning(
                        "Vision screening found no SoA pages in candidates",
                        KlassMethodLocation(self.MODULE, "_do_extract"),
                    )
                    return "", ""

        # Step 3: Render confirmed pages at full DPI
        with tempfile.TemporaryDirectory() as tmp_dir:
            images = render_pages(self._pdf_path, pages, tmp_dir)
            if not images:
                self._errors.warning(
                    "No page images rendered for vision extraction",
                    KlassMethodLocation(self.MODULE, "_do_extract"),
                )
                return "", ""

            self._errors.info(
                f"Vision fallback: rendered {len(images)} confirmed page images at 300dpi",
                KlassMethodLocation(self.MODULE, "_do_extract"),
            )

            # Step 4: Send to Claude Sonnet for full extraction
            table_html = extract_html_via_vision(images, self._client, VISION_MODEL)

        # Log for training data capture
        if self._logger and table_html:
            self._logger.log_vision(
                page_count=len(pages),
                page_numbers=pages,
                response=table_html,
                model=VISION_MODEL,
                pdf_path=self._pdf_path,
            )

        # Step 4: Validate response
        if not validate_vision_html(table_html):
            self._errors.warning(
                "Vision response did not contain valid HTML table",
                KlassMethodLocation(self.MODULE, "_do_extract"),
            )
            return "", ""

        self._errors.info(
            f"Vision fallback: extracted HTML table ({len(table_html)} chars)",
            KlassMethodLocation(self.MODULE, "_do_extract"),
        )

        # Vision doesn't extract footnotes separately
        return table_html, ""
