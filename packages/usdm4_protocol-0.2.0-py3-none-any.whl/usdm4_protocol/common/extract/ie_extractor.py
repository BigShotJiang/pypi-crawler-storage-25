import re
from bs4 import BeautifulSoup
from simple_error_log.errors import Errors
from simple_error_log.error_location import KlassMethodLocation
from usdm4_protocol.common.ai.base_ai import BaseAIProvider
from usdm4_protocol.common.extract.content_extractor import ContentExtractor


class IEExtractor:
    """Extracts Inclusion/Exclusion criteria from HTML content.

    This is a content-specific extractor that uses the common ContentExtractor
    for AI-based extraction, with a simple HTML-based fallback for when AI
    is unavailable.

    The AI prompt and simple fallback are both format-agnostic — they operate
    on HTML regardless of whether it originated from a DOCX or PDF source.
    """

    MODULE = "usdm4_protocol.common.extract.ie_extractor.IEExtractor"

    def __init__(self, ai: BaseAIProvider, errors: Errors):
        """
        Initialize the IE extractor.

        Args:
            ai: An AI provider instance. May be None if AI is not available.
            errors: Error logging object.
        """
        self._errors = errors
        self._content_extractor = ContentExtractor(ai, errors)

    def extract_criteria(self, html: str, criteria_type: str) -> list[dict]:
        """
        Extract inclusion or exclusion criteria from HTML content.

        Attempts AI extraction first, falling back to simple HTML parsing.

        Args:
            html: HTML content of the section containing the criteria.
            criteria_type: Either "inclusion" or "exclusion".

        Returns:
            List of dicts, each with "identifier" and "text" keys.
            Returns empty list on failure.
        """
        try:
            if self._content_extractor.ai_available:
                ai_result = self._extract_ai(html, criteria_type)
                if ai_result is not None:
                    return ai_result
                # AI failed, fall through to simple
                self._errors.info(
                    f"AI extraction failed for {criteria_type} criteria, falling back to simple extraction",
                    KlassMethodLocation(self.MODULE, "extract_criteria"),
                )

            simple_result = self._extract_simple(html)
            return simple_result if simple_result else []
        except Exception as e:
            self._errors.exception(
                f"Exception extracting {criteria_type} criteria",
                e,
                KlassMethodLocation(self.MODULE, "extract_criteria"),
            )
            return []

    def _extract_ai(self, html: str, criteria_type: str) -> list[dict] | None:
        """
        Extract criteria using AI.

        Args:
            html: HTML content of the criteria section.
            criteria_type: Either "inclusion" or "exclusion".

        Returns:
            List of criterion dicts, empty list if no criteria found, or None on failure.
        """
        try:
            title = f"{criteria_type} criteria"
            prompt = self._build_prompt(html, title)
            result = self._content_extractor.extract(html, prompt, as_list=True, task_type="ie_extraction")
            if result is None:
                return None
            self._errors.info(
                f"AI extracted {len(result)} {criteria_type} criteria",
                KlassMethodLocation(self.MODULE, "_extract_ai"),
            )
            return result
        except Exception as e:
            self._errors.exception(
                f"Exception during AI extraction of {criteria_type} criteria",
                e,
                KlassMethodLocation(self.MODULE, "_extract_ai"),
            )
            return None

    def _extract_simple(self, html: str) -> list[dict]:
        """
        Extract criteria from HTML using simple parsing (no AI).

        Tries strategies in order:
        1. HTML list items (<li> elements)
        2. Numbered paragraphs (e.g., "1. Text..." or "1  Text...")
        3. Block elements as individual criteria (paragraphs or headings that
           contain substantive text, skipping introductory preamble)

        Args:
            html: HTML content of the criteria section.

        Returns:
            List of criterion dicts with "identifier" and "text" keys.
        """
        try:
            soup = BeautifulSoup(html, "html.parser")

            # Strategy 1: Extract from HTML list items
            list_result = self._extract_from_lists(soup)
            if list_result:
                return list_result

            # Strategy 2: Extract numbered paragraphs
            para_result = self._extract_numbered_paragraphs(soup)
            if para_result:
                return para_result

            # Strategy 3: Extract block elements as individual criteria
            block_result = self._extract_block_elements(soup)
            if block_result:
                return block_result

            self._errors.warning(
                "No criteria found via simple extraction",
                KlassMethodLocation(self.MODULE, "_extract_simple"),
            )
            return []
        except Exception as e:
            self._errors.exception(
                "Exception during simple IE extraction",
                e,
                KlassMethodLocation(self.MODULE, "_extract_simple"),
            )
            return []

    def _extract_from_lists(self, soup: BeautifulSoup) -> list[dict]:
        """
        Extract criteria from HTML list items (<li> elements).

        Args:
            soup: Parsed HTML content.

        Returns:
            List of criterion dicts, or empty list if no lists found.
        """
        list_items = soup.find_all("li", recursive=True)
        if not list_items:
            return []

        result = []
        index = 1
        for item in list_items:
            # Skip nested list items (only process top-level)
            parent = item.parent
            if parent and parent.name in ("ul", "ol"):
                grandparent = parent.parent
                if grandparent and grandparent.name == "li":
                    continue  # This is a nested sub-item, skip it

            # Get the full HTML including any nested sub-lists
            text = str(item)
            result.append({"identifier": index, "text": text})
            index += 1

        return result

    def _extract_numbered_paragraphs(self, soup: BeautifulSoup) -> list[dict]:
        """
        Extract criteria from numbered paragraphs.

        Handles patterns like "1. Text", "1 Text", "1　Text" (full-width space).

        Args:
            soup: Parsed HTML content.

        Returns:
            List of criterion dicts, or empty list if no numbered paragraphs found.
        """
        number_pattern = re.compile(r"^(\d+)[\.\)\s\u3000]+(.*)$")
        paragraphs = soup.find_all("p")
        result = []

        for para in paragraphs:
            text = para.get_text().strip()
            if not text:
                continue

            match = number_pattern.match(text)
            if match:
                identifier = int(match.group(1))
                result.append({"identifier": identifier, "text": str(para)})
            elif result:
                # Continuation paragraph — append to previous criterion
                last = result[-1]
                last["text"] += str(para)
            # Skip non-numbered paragraphs before the first criterion (intro text)

        return result

    def _extract_block_elements(self, soup: BeautifulSoup) -> list[dict]:
        """
        Extract criteria from block-level elements (paragraphs and headings).

        This is a fallback for PDFs where criteria appear as individual <p> or
        <h5>/<h6> elements without numbering or list markup. It skips short
        introductory/preamble elements and category headings, treating each
        remaining block as a criterion.

        Args:
            soup: Parsed HTML content.

        Returns:
            List of criterion dicts, or empty list if no suitable elements found.
        """
        BLOCK_TAGS = ["p", "h1", "h2", "h3", "h4", "h5", "h6"]
        MIN_CRITERION_LENGTH = 20  # Skip very short headings/preamble
        PREAMBLE_INDICATORS = [
            "criteria apply",
            "following criteria",
            "eligible to be included",
            "excluded from the study",
            "must meet",
            "will be excluded",
            "are eligible",
            "are excluded",
        ]

        elements = soup.find_all(BLOCK_TAGS)
        result = []
        index = 1

        for elem in elements:
            text = elem.get_text().strip()
            if not text:
                continue

            # Skip preamble/introductory text
            text_lower = text.lower()
            if any(indicator in text_lower for indicator in PREAMBLE_INDICATORS):
                continue

            # Skip very short elements (likely category headings like "Age", "Medical conditions")
            if len(text) < MIN_CRITERION_LENGTH:
                continue

            result.append({"identifier": index, "text": str(elem)})
            index += 1

        return result

    def _build_prompt(self, html: str, title: str) -> str:
        """
        Build the AI prompt for extracting criteria.

        Args:
            html: The HTML content to process.
            title: The criteria type label (e.g., "inclusion criteria").

        Returns:
            The full prompt text.
        """
        return f"""
            You are an expert in reading clinical trial protocols. Your task is to extract all {title} from the provided HTML content.

            ## Instructions

            1. Identify and extract each individual {title} from the text
            2. Criteria may appear as:
            - Numbered or bulleted lists
            - Paragraphs
            - Items under category headings (e.g., "General {title}", "Indication specific {title}")
            3. Extract ALL criteria regardless of which category or section they appear in
            4. Do NOT include category headings as criteria - only extract the actual criterion text
            5. No text must be lost
            6. The case of all text must be preserved

            ## Handling Hierarchical Criteria

            Some criteria contain nested sub-lists that provide additional detail, qualifications, or breakdowns. When you encounter a criterion with sub-items:

            1. Treat the entire criterion (parent text AND all nested sub-items) as a SINGLE criterion
            2. Preserve the complete text including all sub-items in the "text" field
            3. Maintain the original formatting and structure (line breaks, indentation, sub-numbering)
            4. Do NOT split hierarchical criteria into separate entries

            ## Identifier Rules

            - If the criterion has an explicit identifier in the source text (e.g., "E1", "EC-01", "1.", "a)"), extract and use that identifier
            - If no identifier is present, assign sequential integer identifiers starting from 1 (i.e., "1", "2", "3", etc.)
            - Maintain consistent identifier format throughout the response

            ## Output Format

            Return a JSON array of objects. Each object must contain:
            - "identifier": The criterion identifier (string)
            - "text": The criterion text with original HTML formatting preserved (string)

            Example output structure:
            [
                {{
                    "identifier": "1",
                    "text": "Subjects under 18 years of age"
                }},
                {{
                    "identifier": "2",
                    "text": "Subjects with known hypersensitivity to <b>study drug</b> or excipients"
                }}
            ]

            ## Edge Cases

            - If no {title} can be found, return an empty array: []
            - Preserve any HTML formatting (e.g., <b>, <i>, <sub>, <sup>) within the criterion text
            - Do not include introductory text such as "Subjects will be excluded if..." as a criterion

            ## Content to Process

            {html}
        """
