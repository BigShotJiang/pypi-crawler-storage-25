import copy
from abc import ABC, abstractmethod
from simple_error_log.errors import Errors
from simple_error_log.error_location import KlassMethodLocation
from usdm4_protocol.common.assemble.assemble_usdm import AssembleUSDM


class BaseImport(ABC):
    """Base class for format-specific import handlers.

    Provides the shared Load -> Extract -> Assemble -> Wrapper pipeline and
    common properties (source, source_no_sections, extra). Subclasses must
    implement _load() and _extract() to supply format-specific behaviour.
    """

    MODULE = "usdm4_protocol.common.base_import.BaseImport"

    def __init__(self, file_path: str, errors: Errors):
        self._file_path = file_path
        self._errors = errors
        self._study = None

    def process(self):
        try:
            loaded = self._load()
            self._study = self._extract(loaded)
            assembler = AssembleUSDM(self._study, self._errors)
            wrapper = assembler.process()
            return wrapper
        except Exception as e:
            location = KlassMethodLocation(self.MODULE, "process")
            self._errors.exception(
                f"Exception raised processing '{self._file_path}'",
                e,
                location,
            )
            return None

    @abstractmethod
    def _load(self):
        """Load the source file. Returns format-specific data."""

    @abstractmethod
    def _extract(self, loaded) -> dict:
        """Extract study data from the loaded source. Returns study dict."""

    @property
    def source(self) -> dict:
        return self._study

    @property
    def source_no_sections(self) -> dict:
        the_copy = copy.deepcopy(self._study)
        the_copy["document"]["sections"] = []
        return the_copy

    @property
    def extra(self) -> dict:
        """Override in subclasses that need extra metadata."""
        return {}
