import json
from simple_error_log.errors import Errors
from simple_error_log.error_location import KlassMethodLocation
from usdm4_protocol.common.ai.base_ai import BaseAIProvider
from usdm4_protocol.common.ai.training_data_logger import TrainingDataLogger

try:
    from anthropic import Anthropic
    from d4k_ms_base.service_environment import ServiceEnvironment

    ANTHROPIC_AVAILABLE = True
except ImportError:
    ANTHROPIC_AVAILABLE = False


class ClaudeProvider(BaseAIProvider):
    """Claude AI provider using Anthropic API."""

    MODULE = "usdm4_protocol.common.ai.claude_provider.ClaudeProvider"
    DEFAULT_MODEL = "claude-haiku-4-5-20251001"
    MODEL_PRICING = {DEFAULT_MODEL: {"input": 15.0, "output": 75.0}}

    def __init__(self, errors: Errors, model: str = None, logger: TrainingDataLogger = None):
        """
        Initialize the Claude provider.

        Args:
            errors: Error logging object
            model: Model name (defaults to haiku)
            logger: Optional training data logger for capturing
                prompt/response pairs.  Created and managed by the
                pipeline entry point (``ExtractStudy``) and passed
                through to all extractors.
        """
        self._errors = errors
        self._model = model or self.DEFAULT_MODEL
        self._client = None
        self._available = False
        self._logger = logger

        if not ANTHROPIC_AVAILABLE:
            errors.warning(
                "Anthropic package not installed. Install with 'pip install anthropic d4k_ms_base'",
                KlassMethodLocation(self.MODULE, "__init__"),
            )
            return

        try:
            api_key = ServiceEnvironment().get("ANTHROPIC_API_KEY")
            if not api_key:
                errors.error(
                    "Anthropic API key environment variable is not set",
                    KlassMethodLocation(self.MODULE, "__init__"),
                )
            else:
                self._client = Anthropic(api_key=api_key)
                self._available = True
        except Exception as e:
            errors.exception(
                "Failed to initialize Anthropic client",
                e,
                KlassMethodLocation(self.MODULE, "__init__"),
            )

    @property
    def available(self) -> bool:
        """Check if the Claude provider is available."""
        return self._available

    @property
    def logger(self):
        """Return the training data logger, if any."""
        return self._logger

    def prompt(self, text: str, system: str = "") -> str:
        """Send a prompt to Claude and get a response."""
        if not self._client:
            self._errors.error(
                "No client object found",
                KlassMethodLocation(self.MODULE, "prompt"),
            )
            return None

        try:
            message = self._client.messages.create(
                max_tokens=1024,
                system=system if system else "",
                messages=[
                    {
                        "role": "user",
                        "content": text,
                    }
                ],
                model=self._model,
            )
            result = message.content[0].text
            if self._logger:
                self._logger.log(text, result, self._model, "prompt", system)
            return result
        except Exception as e:
            self._errors.exception(
                "Error executing prompt",
                e,
                KlassMethodLocation(self.MODULE, "prompt"),
            )
            return None

    def streaming_prompt(self, text: str, system_message: str = "") -> str:
        """Send a prompt to Claude with streaming response."""
        if not self._client:
            self._errors.error(
                "No client object found",
                KlassMethodLocation(self.MODULE, "streaming_prompt"),
            )
            return None

        try:
            with self._client.messages.stream(
                model=self._model,
                max_tokens=16384,
                temperature=0,
                system=system_message if system_message else "",
                messages=[
                    {
                        "role": "user",
                        "content": text,
                    }
                ],
            ) as stream:
                result = self._streaming_response(stream)
                if self._logger and result is not None:
                    self._logger.log(text, result, self._model, "streaming_prompt", system_message)
                return result
        except Exception as e:
            self._errors.exception(
                "Error executing streaming prompt",
                e,
                KlassMethodLocation(self.MODULE, "streaming_prompt"),
            )
            return None

    def extract_json(self, text: str, dict: bool = True) -> dict | list | None:
        """Extract JSON from response text."""
        if not text:
            self._errors.error(
                "Error decoding Claude response - empty text",
                KlassMethodLocation(self.MODULE, "extract_json"),
            )
            return None

        try:
            result = text.replace("\n", "")
            if dict:
                s_index = result.find("{")
                e_index = result.rfind("}")
            else:
                s_index = result.find("[")
                e_index = result.rfind("]")

            if s_index >= 0 and e_index >= 0 and e_index > s_index:
                result = result[s_index : e_index + 1]
                return json.loads(result)
            else:
                self._errors.error(
                    "Error decoding Claude response - no JSON found",
                    KlassMethodLocation(self.MODULE, "extract_json"),
                )
                return None
        except Exception as e:
            self._errors.exception(
                "Error decoding Claude JSON",
                e,
                KlassMethodLocation(self.MODULE, "extract_json"),
            )
            return None

    def _streaming_response(self, stream) -> str:
        """Process streamed response from Claude."""
        full_response = ""
        try:
            for chunk in stream:
                if hasattr(chunk, "delta") and hasattr(chunk.delta, "text"):
                    content = chunk.delta.text
                    full_response += content
        except Exception as e:
            self._errors.exception(
                "Error decoding Claude stream",
                e,
                KlassMethodLocation(self.MODULE, "_streaming_response"),
            )
            return None
        return full_response
