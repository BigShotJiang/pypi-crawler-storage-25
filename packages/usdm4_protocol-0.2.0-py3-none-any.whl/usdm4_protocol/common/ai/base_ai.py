from abc import ABC, abstractmethod


class BaseAIProvider(ABC):
    """Abstract base class for AI providers."""

    @property
    @abstractmethod
    def available(self) -> bool:
        """Check if the AI provider is available."""
        pass

    @property
    def logger(self):
        """Return the training data logger, if any.

        Subclasses that support logging (e.g. ``ClaudeProvider``) override
        this to return their ``TrainingDataLogger`` instance.  The default
        returns ``None``.
        """
        return None

    @abstractmethod
    def prompt(self, text: str, system: str = "") -> str:
        """
        Send a prompt to the AI model and get a response.

        Args:
            text: The prompt text
            system: Optional system message for context

        Returns:
            The response text from the AI model, or None if unavailable
        """
        pass

    @abstractmethod
    def streaming_prompt(self, text: str, system_message: str = "") -> str:
        """
        Send a prompt to the AI model with streaming response.

        Args:
            text: The prompt text
            system_message: Optional system message for context

        Returns:
            The full response text from the AI model, or None if unavailable
        """
        pass

    @abstractmethod
    def extract_json(self, text: str, dict: bool = True) -> dict | list | None:
        """
        Extract JSON from AI response text.

        Args:
            text: The response text containing JSON
            dict: If True, extract dictionary; if False, extract list

        Returns:
            Parsed JSON object/list, or None if extraction failed
        """
        pass
