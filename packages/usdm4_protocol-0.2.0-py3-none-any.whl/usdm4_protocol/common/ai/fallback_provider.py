from simple_error_log.errors import Errors
from usdm4_protocol.common.ai.base_ai import BaseAIProvider


class FallbackProvider(BaseAIProvider):
    """Fallback provider that returns None for all operations."""

    MODULE = "usdm4_protocol.common.ai.fallback_provider.FallbackProvider"

    def __init__(self, errors: Errors):
        """
        Initialize the fallback provider.

        Args:
            errors: Error logging object
        """
        self._errors = errors

    @property
    def available(self) -> bool:
        """Fallback provider is never available."""
        return False

    def prompt(self, text: str, system: str = "") -> None:
        """Fallback always returns None."""
        return None

    def streaming_prompt(self, text: str, system_message: str = "") -> None:
        """Fallback always returns None."""
        return None

    def extract_json(self, text: str, dict: bool = True) -> None:
        """Fallback always returns None."""
        return None
