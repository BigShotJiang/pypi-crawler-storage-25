"""
Training Data Logger
=====================

Captures AI prompt/response pairs as JSONL files for future model training.
Every call to ``ClaudeProvider.prompt()`` and ``streaming_prompt()`` is logged
with the prompt text, system message, response, model, and context metadata.

Activation is controlled by the ``TRAINING_DATA_DIR`` environment variable.
When set, JSONL files are written to that directory, one file per task type.
When unset, no logging occurs and there is zero overhead.

Usage::

    # Automatic — set the environment variable and run the pipeline
    export TRAINING_DATA_DIR=/path/to/training_data

    # Manual — create a logger and attach it to a ClaudeProvider
    logger = TrainingDataLogger("/path/to/training_data")
    provider = ClaudeProvider(errors, logger=logger)

    # Set context before extraction calls
    logger.set_protocol_context("NCT04184622")
    logger.set_task_context("soa_row_classification")
    result = provider.streaming_prompt(prompt, system_message=system)
    # → logged automatically

Task types (set by extractors before AI calls):

- ``soa_row_classification`` — SoA header row classification
- ``ie_extraction`` — inclusion/exclusion criteria extraction
- ``title_page`` — title page metadata extraction
- ``amendments`` — amendment extraction
- ``vision_soa`` — vision-based SoA table extraction
- ``unknown`` — default when no context is set

Design document: ``docs/learning_path.md`` (Phase 4).
"""

import json
import os
from datetime import datetime, timezone
from pathlib import Path


class TrainingDataLogger:
    """Captures AI prompt/response pairs for future model training.

    Each logged interaction is written as a single JSON line to a file
    named ``<task_type>.jsonl`` in the output directory.  The logger is
    designed to be lightweight — no buffering, no threads, just append.

    Attributes:
        output_dir: Directory where JSONL files are written.
    """

    def __init__(self, output_dir: str):
        """
        Args:
            output_dir: Directory for JSONL output files.  Created if
                it does not exist.  If directory creation fails (e.g.
                read-only filesystem), logging calls will silently
                no-op rather than raising.
        """
        self._output_dir = Path(output_dir)
        self._active = True
        try:
            self._output_dir.mkdir(parents=True, exist_ok=True)
        except OSError:
            self._active = False
        self._task_type = "unknown"
        self._protocol_id = "unknown"

    def set_task_context(self, task_type: str):
        """Set the current task type for subsequent log entries.

        Callers (extractors) should call this before making AI calls
        so that logged entries carry the correct task label.

        Args:
            task_type: One of the recognised task types (see module docstring).
        """
        self._task_type = task_type

    def set_protocol_context(self, protocol_id: str):
        """Set the current protocol ID for subsequent log entries.

        Called at the pipeline level (e.g. ``BaseImport.process()``)
        before extraction begins.

        Args:
            protocol_id: The protocol identifier (e.g. "NCT04184622").
        """
        self._protocol_id = protocol_id

    @property
    def task_type(self) -> str:
        """The current task type label."""
        return self._task_type

    @property
    def protocol_id(self) -> str:
        """The current protocol ID."""
        return self._protocol_id

    def log(
        self,
        prompt: str,
        response: str,
        model: str,
        method: str,
        system_message: str = "",
    ):
        """Log a single AI prompt/response pair.

        Args:
            prompt: The prompt text sent to the AI.
            response: The AI's response text (may be None on failure).
            model: The model identifier (e.g. "claude-haiku-4-5-20251001").
            method: The calling method ("prompt" or "streaming_prompt").
            system_message: The system message, if any.
        """
        if not self._active:
            return
        entry = {
            "task_type": self._task_type,
            "protocol_id": self._protocol_id,
            "prompt": prompt,
            "system_message": system_message,
            "response": response,
            "model": model,
            "method": method,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "response_length": len(response) if response else 0,
        }

        file_path = self._output_dir / f"{self._task_type}.jsonl"
        try:
            with open(file_path, "a", encoding="utf-8") as f:
                f.write(json.dumps(entry, ensure_ascii=False) + "\n")
        except Exception:
            # Never let logging failures break the pipeline
            pass

    def log_vision(
        self,
        page_count: int,
        page_numbers: list[int],
        response: str,
        model: str,
        pdf_path: str = "",
    ):
        """Log a vision extraction call.

        Vision calls are different from text prompts — the input is
        page images, not text.  We log the page metadata rather than
        the image data itself (images can be re-rendered from the PDF).

        Args:
            page_count: Number of page images sent.
            page_numbers: 0-indexed page numbers sent to vision.
            response: The vision response (HTML table string).
            model: The model identifier.
            pdf_path: Path to the source PDF (for re-rendering).
        """
        if not self._active:
            return
        entry = {
            "task_type": "vision_soa",
            "protocol_id": self._protocol_id,
            "pdf_path": pdf_path,
            "page_count": page_count,
            "page_numbers": page_numbers,
            "response": response,
            "model": model,
            "method": "vision",
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "response_length": len(response) if response else 0,
        }

        file_path = self._output_dir / "vision_soa.jsonl"
        try:
            with open(file_path, "a", encoding="utf-8") as f:
                f.write(json.dumps(entry, ensure_ascii=False) + "\n")
        except Exception:
            pass

    @staticmethod
    def from_env() -> "TrainingDataLogger | None":
        """Create a logger from the ``TRAINING_DATA_DIR`` environment variable.

        The protocol context should be set by the pipeline entry point
        (``ExtractStudy``) after creating the logger, using
        ``set_protocol_context()``.

        Returns:
            A ``TrainingDataLogger`` if ``TRAINING_DATA_DIR`` is set, else ``None``.
        """
        output_dir = os.environ.get("TRAINING_DATA_DIR")
        if output_dir:
            return TrainingDataLogger(output_dir)
        return None
