from usdm4_protocol.__info__ import (
    __package_version__ as __package_version__,
    __model_version__ as __model_version__,
    __system_name__ as __system_name__,
)
from usdm4_protocol.m11 import USDM4M11
from usdm4_protocol.cpt import USDM4CPT
from usdm4_protocol.legacy import USDM4Legacy
from simple_error_log.errors import Errors


class USDM4Protocol:
    """Unified entry point for importing clinical trial protocols into USDM4.

    Supports three protocol formats:
    - M11 (ICH M11 template, DOCX)
    - CPT (TransCelerate Common Protocol Template, DOCX)
    - Legacy (unknown sponsor format, PDF)
    """

    def __init__(self):
        self._errors = Errors()
        self._handler = None

    def from_m11(self, filepath: str, use_ai: bool = False):
        """Import an M11-formatted protocol (DOCX)."""
        self._handler = USDM4M11()
        return self._handler.from_docx(filepath, use_ai=use_ai)

    def from_cpt(self, filepath: str):
        """Import a CPT-formatted protocol (DOCX)."""
        self._handler = USDM4CPT()
        return self._handler.from_docx(filepath)

    def from_pdf(self, filepath: str, pdf_converter: str = "auto"):
        """Import a legacy PDF protocol.

        Args:
            filepath: Path to the PDF file.
            pdf_converter: Which converter to use.
                - "auto": Use docling if available, otherwise pymupdf.
                - "docling": Use docling (pip install usdm4_protocol[pdf-docling]).
                - "pymupdf": Use pymupdf (pip install usdm4_protocol[pdf]).
        """
        self._handler = USDM4Legacy()
        return self._handler.from_pdf(filepath, pdf_converter=pdf_converter)

    def from_file(self, filepath: str, use_ai: bool = False):
        """Import a protocol, detecting format from the file extension and content.

        For .pdf files, uses the Legacy handler.
        For .docx files, attempts M11 first (if use_ai is requested or M11 markers
        are detected), otherwise falls back to CPT.
        """
        lower = filepath.lower()
        if lower.endswith(".pdf"):
            return self.from_pdf(filepath, pdf_converter="auto")
        elif lower.endswith(".docx"):
            if use_ai:
                return self.from_m11(filepath, use_ai=True)
            return self.from_cpt(filepath)
        else:
            self._errors.error(f"Unsupported file format: {filepath}")
            return None

    def to_html(self, file_path: str, template: str = "M11") -> str | None:
        """Export USDM4 data to HTML.

        Args:
            file_path: Path to USDM4 JSON file.
            template: Template to use ("M11" or "CPT").
        """
        if template.upper() == "M11":
            handler = USDM4M11()
            return handler.to_html(file_path)
        elif template.upper() == "CPT":
            handler = USDM4CPT()
            return handler.to_html(file_path)
        else:
            self._errors.error(f"Unsupported template: {template}")
            return None

    def data_views(self, file_path: str) -> dict:
        """Generate data views from USDM4 data (M11 format)."""
        handler = USDM4M11()
        return handler.data_views(file_path)

    @property
    def source(self) -> dict:
        if self._handler:
            return self._handler.source
        return {}

    @property
    def source_no_sections(self) -> dict:
        if self._handler:
            return self._handler.source_no_sections
        return {}

    @property
    def errors(self):
        if self._handler:
            return self._handler.errors
        return self._errors
