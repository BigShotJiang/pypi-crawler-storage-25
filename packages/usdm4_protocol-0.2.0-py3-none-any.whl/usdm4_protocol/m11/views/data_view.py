from usdm4 import Wrapper
from usdm4_protocol.m11.specification import Specification
from usdm4_protocol.m11.elements import Elements
from simple_error_log.errors import Errors
from simple_error_log.error_location import KlassMethodLocation


class DataView:
    MODULE = "usdm4_protocol.m11.views.data_view.DataView"

    def __init__(self, wrapper: Wrapper, errors: Errors) -> None:
        self._wrapper: Wrapper = wrapper
        self._errors: Errors = errors

    def title_page(self) -> dict | None:
        return self._generic_view("title_page")

    def _generic_view(
        self,
        name: str,
    ) -> dict | None:
        try:
            result = None
            if self._wrapper:
                elements = Elements(self._wrapper)
                specification = Specification()
                element_list: dict = specification.elements(name)
                result = {element: elements.get(element, data=True) for element in element_list.keys()}
            return result
        except Exception as e:
            location = KlassMethodLocation(self.MODULE, "_generic_view")
            self._errors.exception(
                "Exception raised processing M11 view",
                e,
                location,
            )
            return None
