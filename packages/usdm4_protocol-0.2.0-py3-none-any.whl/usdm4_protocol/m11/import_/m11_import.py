from usdm4_protocol.m11.import_.load import LoadDocx
from usdm4_protocol.m11.import_.extract import ExtractStudy
from usdm4_protocol.common.base_import import BaseImport
from simple_error_log.errors import Errors


class M11Import(BaseImport):
    MODULE = "usdm4_protocol.m11.import_.m11_import.M11Import"

    def __init__(self, file_path: str, errors: Errors, use_ai: bool = False):
        super().__init__(file_path, errors)
        self._use_ai = use_ai

    def _load(self):
        loader = LoadDocx(self._file_path, self._errors)
        return loader.process()

    def _extract(self, loaded) -> dict:
        extractor = ExtractStudy(loaded, self._errors, self._use_ai)
        return extractor.process()
