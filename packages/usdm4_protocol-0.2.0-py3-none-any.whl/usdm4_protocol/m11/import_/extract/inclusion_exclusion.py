import re
from raw_docx.raw_docx import RawDocx, RawListItem, RawList, RawSection
from simple_error_log.errors import Errors
from simple_error_log.error_location import KlassMethodLocation
from usdm4_protocol.common.ai.base_ai import BaseAIProvider
from usdm4_protocol.common.extract.ie_extractor import IEExtractor


class InclusionExclusion:
    """Extract Inclusion/Exclusion criteria from M11 DOCX protocol sections.

    Uses the common IEExtractor for AI-based extraction (operating on HTML
    converted from the DOCX section). The simple (non-AI) fallback path
    operates directly on RawDocx objects (RawList/RawListItem) for the best
    fidelity when extracting from Word list structures.
    """

    MODULE = "usdm4_protocol.m11.import_.extract.inclusion_exclusion.InclusionExclusion"

    # M11 section numbers for inclusion and exclusion criteria
    INCLUSION_SECTION = "5.2"
    EXCLUSION_SECTION = "5.3"

    def __init__(self, raw_docx: RawDocx, errors: Errors, use_ai: bool = False, ai: BaseAIProvider = None):
        """
        Args:
            raw_docx: RawDocx document object.
            errors: Error logging object.
            use_ai: Whether to use AI for extraction.
                Ignored when ``ai`` is provided.
            ai: Pre-configured AI provider.  When provided, ``use_ai``
                is ignored and this provider is used directly.
        """
        self._errors = errors
        self._raw_docx = raw_docx
        self._use_ai = use_ai if ai is None else True
        if ai is None and use_ai:
            from usdm4_protocol.common.ai.claude_provider import ClaudeProvider

            ai = ClaudeProvider(self._errors)
        self._ie_extractor = IEExtractor(ai, errors)

    def process(self) -> dict:
        try:
            result = {"inclusion": [], "exclusion": []}
            result["inclusion"] = [x["text"] for x in self._process_section(self.INCLUSION_SECTION, "inclusion")]
            result["exclusion"] = [x["text"] for x in self._process_section(self.EXCLUSION_SECTION, "exclusion")]
            return result
        except Exception as e:
            location = KlassMethodLocation(self.MODULE, "process")
            self._errors.exception(
                "Failed to decode the Inclusion/Exclusion criteria in the document",
                e,
                location,
            )
            return None

    def _process_section(self, section_number: str, criteria_type: str) -> list:
        section = self._raw_docx.target_document.section_by_number(section_number)
        if section:
            if self._use_ai:
                ai_result = self._process_ai(section, criteria_type)
                if ai_result is None:
                    ai_result = self._process_simple(section)
                return ai_result if ai_result else []
            else:
                simple_result = self._process_simple(section)
                return simple_result if simple_result else []
        else:
            self._errors.error(f"Failed to find section {section_number} in M11 document")
        return []

    def _process_ai(self, section: RawSection, criteria_type: str) -> list:
        """Extract criteria using the common IEExtractor AI path.

        Converts the DOCX section to HTML and delegates to the format-agnostic
        IEExtractor which contains the shared AI prompt.
        """
        try:
            html = section.to_html()
            return self._ie_extractor.extract_criteria(html, criteria_type)
        except Exception as e:
            self._errors.exception(
                "Exception detected using IE AI processing",
                e,
                KlassMethodLocation(self.MODULE, "_process_ai"),
            )
            return None

    def _process_simple(self, section: RawSection) -> list:
        """M11-specific simple extraction operating on native DOCX objects.

        Tries Word list structures first (RawList/RawListItem), then falls back
        to numbered paragraphs. This path is M11-specific because it works with
        the raw DOCX object model rather than HTML.
        """
        try:
            lists = section.lists()
            if lists:
                return self._process_list(lists[0])
            else:
                # Fallback: extract numbered paragraphs (e.g., Japanese style)
                result = self._process_numbered_paragraphs(section)
                if result:
                    return result
                self._errors.error(
                    f"Failed to find a list or numbered paragraphs in section {section.number} in M11 document"
                )
                return []
        except Exception as e:
            self._errors.exception(
                "Exception detected using IE simple processing",
                e,
                KlassMethodLocation(self.MODULE, "_process_simple"),
            )
            return None

    def _process_list(self, the_list: list) -> list:
        index = 1
        result = []
        for item in the_list.items:
            if isinstance(item, RawListItem):
                result.append({"identifier": index, "text": item.to_html()})
                index += 1
            elif isinstance(item, RawList):
                if result:
                    last = result[-1]
                    last["text"] += item.to_html()
                else:
                    self._errors.error(
                        f"RawList item detected with no previous RawListItem entries, type: '{type(item)}', text: '{item.to_text()}'"
                    )
            else:
                self._errors.error(
                    f"Neither a RawList or RawListItem detected, type: '{type(item)}', text: '{item.to_text()}'"
                )
        return result

    def _process_numbered_paragraphs(self, section: RawSection) -> list:
        """
        Extract criteria from numbered paragraphs (used when no Word lists are present).
        Handles patterns like "1　Text" or "1 Text" where numbers may be followed by
        full-width or regular spaces.
        """
        # Pattern matches number at start followed by space (regular or full-width)
        number_pattern = re.compile(r"^(\d+)[\s\u3000]+(.*)$")

        paragraphs = section.paragraphs()
        result = []

        for para in paragraphs:
            text = para.to_text().strip()
            if not text:
                continue

            match = number_pattern.match(text)
            if match:
                # New numbered criterion
                identifier = match.group(1)
                result.append({"identifier": int(identifier), "text": para.to_html()})
            elif result:
                # Non-numbered paragraph - append to previous criterion as continuation
                last = result[-1]
                last["text"] += para.to_html()
            # Skip non-numbered paragraphs before the first criterion (intro text)

        return result
