# Deprecated: use usdm4_protocol.common.extract.utility directly.
# This re-export exists only for backward compatibility.
from usdm4_protocol.common.extract.utility import (  # noqa: F401
    text_within,
    table_get_row,
    table_get_row_html,
    section_get_para,
    section_get_text_between,
    section_find_para,
)
