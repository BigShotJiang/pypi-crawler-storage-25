from raw_docx.raw_docx import RawDocx
from simple_error_log.errors import Errors
from simple_error_log.error_location import KlassMethodLocation
from usdm4_protocol.m11.import_.extract.title_page import TitlePage
from usdm4_protocol.m11.import_.extract.inclusion_exclusion import InclusionExclusion
from usdm4_protocol.m11.import_.extract.amendments import Amendments
from usdm4_protocol.m11.import_.extract.document import Document
from usdm4_protocol.soa.soa_extractor import SoA


class ExtractStudy:
    MODULE = "usdm4_protocol.m11.import_.extract.__init__.ExtractStudy"

    def __init__(self, raw_docx: RawDocx, errors: Errors, use_ai: bool = False):
        self._raw_docx = raw_docx
        self._sections = self._raw_docx.target_document.sections
        self._errors = errors
        self._use_ai = use_ai

        # Create AI provider and logger once for the entire pipeline
        self._ai = None
        self._logger = None
        self._init_providers()

    def _init_providers(self):
        """Create shared AI provider and training data logger.

        M11 uses Haiku for all extraction tasks (title page, IE, SoA,
        amendments).  The logger captures all AI prompt/response pairs
        when ``TRAINING_DATA_DIR`` is set.
        """
        from usdm4_protocol.common.ai.training_data_logger import TrainingDataLogger

        self._logger = TrainingDataLogger.from_env()

        if self._use_ai:
            try:
                from usdm4_protocol.common.ai.claude_provider import ClaudeProvider

                self._ai = ClaudeProvider(
                    self._errors,
                    logger=self._logger,
                )
            except Exception as e:
                self._errors.warning(
                    f"AI provider not available: {e}",
                    KlassMethodLocation(self.MODULE, "_init_providers"),
                )

    def process(self) -> dict:
        try:
            title_page = TitlePage(self._raw_docx, self._errors, ai=self._ai)
            soa = SoA(self._raw_docx, self._errors, ai=self._ai)
            ie = InclusionExclusion(self._raw_docx, self._errors, ai=self._ai)
            amendments = Amendments(self._raw_docx, self._errors, ai=self._ai)
            document = Document(self._raw_docx, self._errors)
            result = title_page.process()
            soa_result = soa.process({})
            if soa_result:
                result["soa"] = soa_result
            result["document"] = document.process(result["study"]["version_date"])
            result["population"] = {
                "label": "Default population",
                "inclusion_exclusion": ie.process(),
            }
            result["amendments"] = amendments.process(result["amendments_summary"]) or {}
            return result
        except Exception as e:
            # print(f"Exception: {e}")
            location = KlassMethodLocation(self.MODULE, "process")
            self._errors.exception(
                "Exception raised extracting study data",
                e,
                location,
            )
            return None
