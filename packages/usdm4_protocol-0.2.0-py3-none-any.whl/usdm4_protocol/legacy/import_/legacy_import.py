from simple_error_log.errors import Errors
from usdm4_protocol.legacy.import_.load import LoadPDF
from usdm4_protocol.legacy.import_.extract import ExtractStudy
from usdm4_protocol.common.base_import import BaseImport


class LegacyImport(BaseImport):
    MODULE = "usdm4_protocol.legacy.import_.legacy_import.LegacyImport"

    def __init__(self, file_path: str, errors: Errors, pdf_converter: str = "auto"):
        super().__init__(file_path, errors)
        self._pdf_converter = pdf_converter

    def _load(self):
        loader = LoadPDF(self._file_path, self._errors, pdf_converter=self._pdf_converter)
        return loader.process()

    def _extract(self, loaded) -> dict:
        extractor = ExtractStudy(
            loaded,
            self._errors,
            pdf_path=self._file_path,
        )
        return extractor.process()

    @property
    def extra(self) -> dict:
        return {
            "title_page": {
                "compound_codes": "",
                "compound_names": "",
                "amendment_identifier": "",
                "sponsor_confidentiality": "",
                # Not used?
                "amendment_details": "",
                "amendment_scope": "",
                "manufacturer_name_and_address": "",
                "medical_expert_contact": "",
                "original_protocol": "",
                "regulatory_agency_identifiers": "",
                "sae_reporting_method": "",
                "sponsor_approval_date": "",
                "sponsor_name_and_address": "",
                "sponsor_signatory": "",
            },
            "amendment": {
                "amendment_details": "",
                "robustness_impact": False,
                "robustness_impact_reason": "",
                "safety_impact": False,
                "safety_impact_reason": "",
            },
            "miscellaneous": {
                "medical_expert_contact": "",
                "sae_reporting_method": "",
                "sponsor_signatory": "",
            },
        }
