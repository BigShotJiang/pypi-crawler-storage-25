import re

from simple_error_log.errors import Errors
from simple_error_log.error_location import KlassMethodLocation
from usdm4_protocol.legacy.import_.extract.title_page import TitlePage
from usdm4_protocol.legacy.import_.extract.inclusion_exclusion import InclusionExclusion
from usdm4_protocol.legacy.import_.extract.schedule_of_activities import ScheduleOfActivities


class ExtractStudy:
    MODULE = "usdm4_protocol.legacy.import_.extract.ExtractStudy"

    def __init__(self, sections: list[str], errors: Errors, use_ai: bool = True, pdf_path: str = None):
        self._sections = sections
        self._errors = errors
        self._use_ai = use_ai
        self._pdf_path = pdf_path

        # Create AI providers and logger once for the entire pipeline
        self._ai_haiku = None
        self._ai_sonnet = None
        self._logger = None
        self._init_providers()

    def _init_providers(self):
        """Create shared AI providers and training data logger.

        Haiku is used for IE extraction and SoA row classification.
        Sonnet is used for title page extraction (more complex task).
        The logger captures all AI prompt/response pairs when
        ``TRAINING_DATA_DIR`` is set.
        """
        from usdm4_protocol.common.ai.training_data_logger import TrainingDataLogger

        self._logger = TrainingDataLogger.from_env()
        if self._logger and self._pdf_path:
            protocol_id = self._extract_protocol_id(self._pdf_path)
            if protocol_id:
                self._logger.set_protocol_context(protocol_id)

        if self._use_ai:
            try:
                from usdm4_protocol.common.ai.claude_provider import ClaudeProvider

                self._ai_haiku = ClaudeProvider(
                    self._errors,
                    logger=self._logger,
                )
                self._ai_sonnet = ClaudeProvider(
                    self._errors,
                    model="claude-sonnet-4-20250514",
                    logger=self._logger,
                )
            except Exception as e:
                self._errors.warning(
                    f"AI providers not available: {e}",
                    KlassMethodLocation(self.MODULE, "_init_providers"),
                )

    @staticmethod
    def _extract_protocol_id(file_path: str) -> str:
        """Extract NCT ID from the file path or filename.

        Looks for the standard ``NCT`` + 8-digit pattern in the file
        path.  Returns empty string if not found.
        """
        match = re.search(r"(NCT\d{8})", file_path, re.IGNORECASE)
        return match.group(1).upper() if match else ""

    def process(self) -> dict:
        try:
            result = {}
            title_page = TitlePage(self._sections, self._errors, ai=self._ai_sonnet)
            tp_result = title_page.process() or {}
            ie = InclusionExclusion(self._sections, self._errors, ai=self._ai_haiku)
            result["identification"] = self._identification(tp_result)
            result["document"] = {
                "document": {
                    "label": "Protocol Document",
                    "version": "",  # @todo
                    "status": "Final",  # @todo
                    "template": "Legacy",
                    "version_date": tp_result.get("other", {}).get("approval_date", ""),
                },
                "sections": None,
            }
            result["study_design"] = {
                "label": "Study Design 1",
                "rationale": "",  # @todo
                "trial_phase": tp_result.get("other", {}).get("phase", ""),
            }
            result["population"] = {
                "label": "Default population",
                "inclusion_exclusion": ie.process(),
            }
            result["amendments"] = {}
            soa = ScheduleOfActivities(
                self._sections,
                self._errors,
                use_ai=self._use_ai,
                pdf_path=self._pdf_path,
                ai=self._ai_haiku,
                logger=self._logger,
            )
            soa_result = soa.process()
            if soa_result:
                result["soa"] = soa_result
            acronym = (result["identification"]["titles"].get("acronym", "") or "").strip()
            sponsor_id = (tp_result.get("sponsor", {}).get("identifier", "") or "").strip()
            result["study"] = {
                "sponsor_approval_date": tp_result.get("other", {}).get("approval_date", ""),
                "version": "1",  # @todo
                "rationale": "Not set",  # @todo
                "name": {
                    "acronym": acronym if acronym else "Unknown",
                    "identifier": sponsor_id if sponsor_id else "Unknown",
                    "compound_code": "",
                },
            }
            result["document"]["sections"] = self._sections
            return result
        except Exception as e:
            location = KlassMethodLocation(self.MODULE, "process")
            self._errors.exception(
                "Exception raised extracting study data",
                e,
                location,
            )
            return None

    def _identification(self, tp: dict) -> dict:
        # Map from the AI extraction keys to the STANDARD_ORGS keys
        # expected by the IdentificationAssembler
        SCOPE_MAP = {"ct.gov": "nct", "fda": "fda-ind"}

        try:
            result = {
                "titles": tp.get(
                    "titles",
                    {
                        "official": "Unknown",
                        "acronym": "",
                        "brief": "",
                    },
                ),
                "identifiers": [],
            }
            for org in ["ct.gov", "fda"]:
                if org in tp and tp[org].get("identifier"):
                    result["identifiers"].append(
                        {
                            "identifier": tp[org]["identifier"],
                            "scope": {"standard": SCOPE_MAP[org]},
                        }
                    )
            if "sponsor" in tp:
                label = (tp["sponsor"].get("label", "") or "").strip()
                name = label.upper().replace(" ", "-")
                name = name if name else "SPONSOR"
                label = label if label else "Sponsor"
                result["identifiers"].append(
                    {
                        "identifier": tp["sponsor"]["identifier"],
                        "scope": {
                            "non_standard": {
                                "type": "pharma",
                                "role": "sponsor",
                                "name": name,
                                "description": "The sponsor organization",
                                "label": label,
                                "identifier": "UNKNOWN",
                                "identifierScheme": "UNKNOWN",
                                "legalAddress": self._validate_address_field(tp["sponsor"].get("legalAddress", {})),
                            }
                        },
                    },
                )
            return result
        except Exception as e:
            location = KlassMethodLocation(self.MODULE, "_identification")
            self._errors.exception(
                "Exception raised building identification data",
                e,
                location,
            )
            return {}

    def _validate_address_field(self, address: dict) -> dict:
        result = {}
        result["lines"] = address["lines"] if "lines" in address else []
        for field in ["city", "district", "state", "postalCode", "country"]:
            result[field] = address[field] if field in address else ""
        return result
