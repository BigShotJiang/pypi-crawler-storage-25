import re

from bs4 import BeautifulSoup
from simple_error_log.errors import Errors
from simple_error_log.error_location import KlassMethodLocation
from usdm4_protocol.common.extract.section_finder import find_sections_by_title
from usdm4_protocol.common.extract.vision_soa_extractor import (
    VisionSoAExtractor,
    needs_vision_fallback,
)
from usdm4_protocol.soa.decode_soa import decode_soa, init_row_classifier


class ScheduleOfActivities:
    """Extract Schedule of Activities from legacy PDF protocol sections.

    Uses a three-phase algorithm to handle multi-page SoA tables:

    1. **Discover** all sections containing SoA content (title matching,
       X-mark scanning, gap filling, boundary expansion).
    2. **Collect and merge** tables from discovered sections, grouping by
       column count and deduplicating header rows.
    3. **Extract footnotes** across all SoA sections, filtering page metadata.

    The merged table and footnotes are then passed to the shared
    ``decode_soa()`` pipeline.  The downstream interface is unchanged.
    """

    MODULE = "usdm4_protocol.legacy.import_.extract.schedule_of_activities.ScheduleOfActivities"

    SEARCH_TERMS = [
        "schedule of activities",
        "schedule of assessments",
        "schedule of events",
        "schedule of procedures",
        "schedule of visits and procedures",
        "schedule of visits",
        "visit schedule",
        "study schedule",
        "study procedures and assessments",
        "study procedures",
        "table of activities",
        "assessment schedule",
        "time and events table",
        "time and events",
    ]

    # Minimum X-mark count for a table to be considered SoA in content scan
    MIN_XMARK_COUNT = 6

    # Patterns for filtering out page metadata from footnote paragraphs
    _PAGE_METADATA_PATTERNS = [
        re.compile(r"^[A-Z]{2,}[\d-]+$"),  # Drug codes: LY2835219
        re.compile(r"^[A-Z]\d[A-Z]-[A-Z]{2}-[A-Z]{4}"),  # Protocol IDs: I8F-MC-GPJA
        re.compile(r"^Page\s+\d+\s+of\s+\d+", re.I),  # Page X of Y
        re.compile(r"Confidential", re.I),  # Confidentiality stamps
        re.compile(r"Approval\s+Date", re.I),  # Approval date stamps
        re.compile(r"^PPD$"),  # PPD stamps
        re.compile(r"Leo\s+Document\s+ID", re.I),  # Document ID stamps
        re.compile(r"^\d+$"),  # Bare page numbers
    ]

    def __init__(
        self, sections: list[dict], errors: Errors, use_ai: bool = False, pdf_path: str = None, ai=None, logger=None
    ):
        """
        Args:
            sections: List of section dicts from SplitHTML.
            errors: Error logging object.
            use_ai: Whether to use AI for row classification.
                Ignored when ``ai`` is provided.
            pdf_path: Path to the source PDF (for vision fallback).
            ai: Pre-configured AI provider (Haiku).  When provided,
                ``use_ai`` is ignored.
            logger: Pre-configured ``TrainingDataLogger`` for vision
                extraction logging.
        """
        self._sections = sections
        self._errors = errors
        self._use_ai = use_ai
        self._pdf_path = pdf_path
        self._ai = ai
        self._logger = logger
        self._row_classifier = None

    def process(self) -> dict | None:
        """
        Extract SoA data from legacy PDF sections.

        Returns:
            Dictionary with SoA feature results, or None if no SoA found.
        """
        try:
            # Initialise combined row classifier
            self._row_classifier = self._init_row_classifier()

            # Phase 1: Discover all SoA sections
            candidates = self._find_all_soa_sections()

            # Phase 2: Collect and merge tables
            table_html = ""
            if candidates:
                table_html = self._collect_and_merge_tables(candidates)

            # Quality gate: check if vision fallback is needed
            first_activity_row = self._quick_activity_row_check(table_html)
            if needs_vision_fallback(table_html, first_activity_row):
                vision_html = self._try_vision_extraction()
                if vision_html:
                    self._errors.info(
                        "Using vision-extracted HTML table (fallback)",
                        KlassMethodLocation(self.MODULE, "process"),
                    )
                    table_html = vision_html

            if not table_html:
                self._errors.info(
                    "No SoA table found (HTML pipeline and vision fallback both failed)",
                    KlassMethodLocation(self.MODULE, "process"),
                )
                return None

            # Phase 3: Extract footnotes across sections
            footnote_html = ""
            if candidates:
                footnote_html = self._extract_footnote_html(candidates)

            return self._decode_soa(table_html, footnote_html)
        except Exception as e:
            self._errors.exception(
                "Exception raised extracting Schedule of Activities",
                e,
                KlassMethodLocation(self.MODULE, "process"),
            )
            return None

    def _init_row_classifier(self):
        """Create the combined AI + heuristic row classifier."""
        return init_row_classifier(self._errors, self._use_ai, ai=self._ai)

    def _quick_activity_row_check(self, table_html: str) -> int:
        """Quick check for first activity row (row with X-marks).

        This is a lightweight version of ``ActivityRowFeature`` used only
        for the quality gate decision.  Returns the 0-based row index of
        the first row containing ≥2 X-marks, or -1 if none found.
        """
        if not table_html:
            return -1
        soup = BeautifulSoup(table_html, "html.parser")
        for i, row in enumerate(soup.find_all("tr")):
            x_count = sum(1 for cell in row.find_all(["td", "th"]) if cell.get_text(strip=True).upper() == "X")
            if x_count >= 2:
                return i
        return -1

    def _try_vision_extraction(self) -> str:
        """Attempt vision-based SoA extraction from PDF page images.

        Returns the extracted HTML table string, or empty string on failure.
        """
        if not self._pdf_path:
            self._errors.info(
                "Vision fallback skipped — no PDF path available",
                KlassMethodLocation(self.MODULE, "_try_vision_extraction"),
            )
            return ""

        extractor = VisionSoAExtractor(self._pdf_path, self._errors, logger=self._logger)
        if not extractor.available:
            self._errors.info(
                "Vision fallback skipped — extractor not available",
                KlassMethodLocation(self.MODULE, "_try_vision_extraction"),
            )
            return ""

        table_html, _ = extractor.extract()
        return table_html

    # ------------------------------------------------------------------
    # Phase 1: Discover all SoA sections
    # ------------------------------------------------------------------

    def _find_all_soa_sections(self) -> list[dict]:
        """Find all sections that may contain SoA content.

        Returns a list of candidate dicts sorted by section index::

            {
                "section": dict,       # original section dict
                "index": int,          # position in self._sections
                "source": str,         # "title_match" | "xmark_scan" | "gap_fill" | "adjacent"
                "xmark_count": int,    # total X-marks across all tables in section
            }

        Uses four strategies in sequence:

        1a. Title matching (normal + OCR-tolerant) — collects ALL matching
            sections that contain tables.
        1b. X-mark content scan — finds sections with tables containing
            ≥ MIN_XMARK_COUNT X-marks, regardless of title.
        1c. Gap filling — adds sections between discovered candidates
            (gaps of 1 or 2).
        1d. Boundary expansion — adds ±1 section beyond the discovered
            range if the section contains a table with ≥1 X-mark.
        """
        candidates = []
        seen_indices = set()

        # 1a. Title matching (normal + OCR-tolerant)
        self._title_match_pass(candidates, seen_indices, ocr_tolerant=False)
        self._title_match_pass(candidates, seen_indices, ocr_tolerant=True)

        title_count = len(candidates)

        # 1b. X-mark content scan
        self._xmark_scan_pass(candidates, seen_indices)
        xmark_count = len(candidates) - title_count

        # 1c. Gap filling
        self._gap_fill_pass(candidates, seen_indices)
        gap_count = len(candidates) - title_count - xmark_count

        # 1d. Boundary expansion
        boundary_count = self._boundary_expansion_pass(candidates, seen_indices)

        # Sort by document order
        candidates.sort(key=lambda c: c["index"])

        total_xmarks = sum(c["xmark_count"] for c in candidates)
        self._errors.info(
            f"SoA discovery: {len(candidates)} sections "
            f"(title: {title_count}, xmark: {xmark_count}, "
            f"gap: {gap_count}, boundary: {boundary_count}), "
            f"total X-marks: {total_xmarks}",
            KlassMethodLocation(self.MODULE, "_find_all_soa_sections"),
        )

        return candidates

    def _title_match_pass(self, candidates: list[dict], seen_indices: set, ocr_tolerant: bool) -> None:
        """Collect all title-matched sections that contain tables."""
        label = "OCR-tolerant" if ocr_tolerant else "normal"
        for term in self.SEARCH_TERMS:
            matches = find_sections_by_title(self._sections, term, ocr_tolerant=ocr_tolerant)
            for section in matches:
                idx = self._sections.index(section)
                if idx in seen_indices:
                    continue
                html = section.get("text", "")
                if "<table" not in html.lower():
                    # No table — try child subsections
                    parent_num = section.get("section_number", "")
                    if parent_num:
                        child_idx = self._find_child_with_table(parent_num)
                        if child_idx is not None and child_idx not in seen_indices:
                            child_section = self._sections[child_idx]
                            child_html = child_section.get("text", "")
                            seen_indices.add(child_idx)
                            candidates.append(
                                {
                                    "section": child_section,
                                    "index": child_idx,
                                    "source": "title_match",
                                    "xmark_count": self._count_xmarks(child_html),
                                }
                            )
                            self._errors.info(
                                f"SoA table in child of '{parent_num}' ({label})",
                                KlassMethodLocation(self.MODULE, "_find_all_soa_sections"),
                            )
                    continue

                xmarks = self._count_xmarks(html)
                seen_indices.add(idx)
                candidates.append(
                    {
                        "section": section,
                        "index": idx,
                        "source": "title_match",
                        "xmark_count": xmarks,
                    }
                )
                self._errors.info(
                    f"SoA section ({label}): '{section.get('section_title', '')}'",
                    KlassMethodLocation(self.MODULE, "_find_all_soa_sections"),
                )

    def _find_child_with_table(self, parent_number: str) -> int | None:
        """Find the index of the first child subsection containing a table."""
        prefix = parent_number + "."
        for idx, section in enumerate(self._sections):
            num = section.get("section_number", "")
            if num.startswith(prefix):
                text = section.get("text", "")
                if "<table" in text.lower():
                    return idx
        return None

    def _xmark_scan_pass(self, candidates: list[dict], seen_indices: set) -> None:
        """Scan all sections for tables with enough X-marks to be SoA."""
        for idx, section in enumerate(self._sections):
            if idx in seen_indices:
                continue
            html = section.get("text", "")
            if "<table" not in html.lower():
                continue
            xmarks = self._count_xmarks(html)
            if xmarks >= self.MIN_XMARK_COUNT:
                seen_indices.add(idx)
                candidates.append(
                    {
                        "section": section,
                        "index": idx,
                        "source": "xmark_scan",
                        "xmark_count": xmarks,
                    }
                )
                self._errors.info(
                    f"SoA by X-mark scan ({xmarks} marks): '{section.get('section_title', '(untitled)')}'",
                    KlassMethodLocation(self.MODULE, "_find_all_soa_sections"),
                )

    def _gap_fill_pass(self, candidates: list[dict], seen_indices: set) -> None:
        """Fill gaps of 1–2 sections between discovered candidates."""
        if not candidates:
            return
        candidate_indices = sorted(c["index"] for c in candidates)
        gaps_to_fill = set()
        for i in range(len(candidate_indices) - 1):
            gap = candidate_indices[i + 1] - candidate_indices[i]
            if gap == 2:
                gaps_to_fill.add(candidate_indices[i] + 1)
            elif gap == 3:
                gaps_to_fill.add(candidate_indices[i] + 1)
                gaps_to_fill.add(candidate_indices[i] + 2)

        for idx in sorted(gaps_to_fill):
            if idx in seen_indices or idx >= len(self._sections):
                continue
            section = self._sections[idx]
            html = section.get("text", "")
            if "<table" not in html.lower():
                continue
            xmarks = self._count_xmarks(html)
            seen_indices.add(idx)
            candidates.append(
                {
                    "section": section,
                    "index": idx,
                    "source": "gap_fill",
                    "xmark_count": xmarks,
                }
            )

    def _boundary_expansion_pass(self, candidates: list[dict], seen_indices: set) -> int:
        """Add ±1 section beyond the discovered range.

        Returns the number of sections added.
        """
        if not candidates:
            return 0
        candidate_indices = sorted(c["index"] for c in candidates)
        added = 0
        for boundary_idx in [candidate_indices[0] - 1, candidate_indices[-1] + 1]:
            if boundary_idx < 0 or boundary_idx >= len(self._sections):
                continue
            if boundary_idx in seen_indices:
                continue
            section = self._sections[boundary_idx]
            html = section.get("text", "")
            if "<table" not in html.lower():
                continue
            xmarks = self._count_xmarks(html)
            if xmarks >= 1:  # lower threshold for boundary
                seen_indices.add(boundary_idx)
                candidates.append(
                    {
                        "section": section,
                        "index": boundary_idx,
                        "source": "adjacent",
                        "xmark_count": xmarks,
                    }
                )
                added += 1
        return added

    # ------------------------------------------------------------------
    # Phase 2: Collect and merge tables
    # ------------------------------------------------------------------

    def _collect_and_merge_tables(self, candidates: list[dict]) -> str:
        """Collect all tables from candidates, group by column count,
        and merge the largest compatible group.

        Returns a single ``<table>`` HTML string.
        """
        if not candidates:
            return ""

        # 2a. Extract all tables with metadata
        all_tables = []
        for c in candidates:
            html = c["section"].get("text", "")
            soup = BeautifulSoup(html, "html.parser")
            for table in soup.find_all("table"):
                table_html = str(table)
                xmarks = self._count_xmarks(table_html)
                cols = self._count_columns(table)
                all_tables.append(
                    {
                        "element": table,
                        "candidate_index": c["index"],
                        "xmark_count": xmarks,
                        "col_count": cols,
                        "first_xmark_row": self._first_xmark_row(table),
                    }
                )

        if not all_tables:
            return ""

        # 2b. Group by column count — select group with most X-marks
        xmark_tables = [t for t in all_tables if t["xmark_count"] > 0]
        if not xmark_tables:
            # No X-marks at all — fall back to largest table by row count
            best = max(all_tables, key=lambda t: len(t["element"].find_all("tr")))
            return str(best["element"])

        col_groups: dict[int, list] = {}
        for t in xmark_tables:
            col_groups.setdefault(t["col_count"], []).append(t)

        best_col = max(
            col_groups,
            key=lambda c: sum(t["xmark_count"] for t in col_groups[c]),
        )

        # Include all tables (with or without X-marks) within ±2 cols
        primary_group = [t for t in all_tables if abs(t["col_count"] - best_col) <= 2]
        primary_group.sort(key=lambda t: t["candidate_index"])

        self._errors.info(
            f"Table merge: {len(primary_group)} tables, "
            f"target col count {best_col} (±2), "
            f"from {len(all_tables)} total tables",
            KlassMethodLocation(self.MODULE, "_collect_and_merge_tables"),
        )

        if len(primary_group) == 1:
            return str(primary_group[0]["element"])

        return self._merge_tables(primary_group)

    def _merge_tables(self, tables: list[dict]) -> str:
        """Merge multiple tables into one, deduplicating header rows.

        Header rows are identified as rows before the first X-mark row.
        Continuation tables' header rows that match the first table's
        headers (by normalised text) are skipped.
        """
        first = tables[0]
        first_element = first["element"]
        first_rows = first_element.find_all("tr")
        first_x_idx = first["first_xmark_row"]
        if first_x_idx < 0:
            first_x_idx = len(first_rows)

        # Collect normalised header text for dedup
        header_texts = set()
        for row in first_rows[:first_x_idx]:
            cells = row.find_all(["td", "th"])
            normalised = " | ".join(c.get_text(strip=True).lower() for c in cells)
            header_texts.add(normalised)

        # Start with all rows from first table
        merged_rows = [str(row) for row in first_rows]
        skipped_headers = 0
        appended_rows = 0

        for t in tables[1:]:
            t_element = t["element"]
            t_rows = t_element.find_all("tr")
            t_x_idx = t["first_xmark_row"]
            if t_x_idx < 0:
                t_x_idx = len(t_rows)

            for i, row in enumerate(t_rows):
                cells = row.find_all(["td", "th"])
                normalised = " | ".join(c.get_text(strip=True).lower() for c in cells)

                # Skip duplicate header rows
                if i < t_x_idx and normalised in header_texts:
                    skipped_headers += 1
                    continue

                # Skip empty rows
                if not normalised.strip(" |"):
                    continue

                merged_rows.append(str(row))
                appended_rows += 1

        self._errors.info(
            f"Merged {len(tables)} tables: skipped {skipped_headers} duplicate headers, appended {appended_rows} rows",
            KlassMethodLocation(self.MODULE, "_merge_tables"),
        )

        return f"<table>{''.join(merged_rows)}</table>"

    # ------------------------------------------------------------------
    # Phase 3: Extract footnotes across sections
    # ------------------------------------------------------------------

    def _extract_footnote_html(self, candidates: list[dict]) -> str:
        """Extract footnote paragraphs from all SoA sections.

        Collects ``<p>`` elements (outside tables) from all candidate
        sections plus the section immediately after the last candidate.
        Filters out page metadata and deduplicates.
        """
        all_paragraphs = []

        # 3a. Collect paragraphs from all candidate sections
        for c in candidates:
            html = c["section"].get("text", "")
            self._collect_paragraphs(html, all_paragraphs)

        # 3b. Also check section after last candidate
        if candidates:
            last_idx = candidates[-1]["index"]
            next_idx = last_idx + 1
            if next_idx < len(self._sections):
                next_section = self._sections[next_idx]
                next_html = next_section.get("text", "")
                # Only include if it does NOT contain an X-mark table
                if self._count_xmarks(next_html) == 0:
                    self._collect_paragraphs(next_html, all_paragraphs)

        # 3c. Filter out page metadata
        filtered = []
        for text, html in all_paragraphs:
            if len(text) < 10:
                continue
            if any(p.search(text) for p in self._PAGE_METADATA_PATTERNS):
                continue
            filtered.append((text, html))

        # 3d. Deduplicate by normalised text
        seen = set()
        deduped = []
        for text, html in filtered:
            key = text.lower().strip()
            if key in seen:
                continue
            seen.add(key)
            deduped.append(html)

        return "".join(deduped)

    @staticmethod
    def _collect_paragraphs(section_html: str, result: list[tuple[str, str]]) -> None:
        """Collect (text, html) tuples for paragraphs not inside tables."""
        soup = BeautifulSoup(section_html, "html.parser")
        for p in soup.find_all("p"):
            if p.find_parent("table"):
                continue
            text = p.get_text(strip=True)
            if text:
                result.append((text, str(p)))

    # ------------------------------------------------------------------
    # Shared utilities
    # ------------------------------------------------------------------

    @staticmethod
    def _count_xmarks(html: str) -> int:
        """Count X-mark cell values in HTML table content.

        Looks for table cells containing only 'X' or 'x' (with optional
        whitespace), which is the standard SoA activity indicator.
        """
        soup = BeautifulSoup(html, "html.parser")
        count = 0
        for cell in soup.find_all(["td", "th"]):
            text = cell.get_text(strip=True)
            if text.upper() == "X":
                count += 1
        return count

    @staticmethod
    def _count_columns(table_element) -> int:
        """Count columns in a table (max cells in any row, respecting colspan)."""
        max_cols = 0
        for row in table_element.find_all("tr"):
            cells = row.find_all(["td", "th"])
            col_count = sum(int(cell.get("colspan", 1)) for cell in cells)
            max_cols = max(max_cols, col_count)
        return max_cols

    @staticmethod
    def _first_xmark_row(table_element) -> int:
        """Find the index of the first row containing an X-mark. -1 if none."""
        for i, row in enumerate(table_element.find_all("tr")):
            for cell in row.find_all(["td", "th"]):
                if cell.get_text(strip=True).upper() == "X":
                    return i
        return -1

    def _decode_soa(self, table_html: str, footnote_html: str) -> dict:
        """Run the shared SoA decode pipeline on the table HTML."""
        return decode_soa(
            table_html=table_html,
            footnote_html=footnote_html,
            assessments={},
            errors=self._errors,
            row_classifier=self._row_classifier,
        )

    # ------------------------------------------------------------------
    # Legacy single-section API (kept for backward compatibility)
    # ------------------------------------------------------------------

    def _find_soa_section(self) -> str:
        """Find a single SoA section HTML (legacy API).

        Delegates to ``_find_all_soa_sections()`` and returns the HTML
        of the first candidate with the most X-marks.  Used only by
        external callers that depend on the old single-section interface.
        """
        candidates = self._find_all_soa_sections()
        if not candidates:
            return ""
        best = max(candidates, key=lambda c: c["xmark_count"])
        return best["section"].get("text", "")

    def _extract_table_html(self, section_html: str) -> str:
        """Extract the best SoA table from a single section (legacy API).

        When the section contains multiple ``<table>`` elements, selects
        the table with the highest X-mark count.
        """
        soup = BeautifulSoup(section_html, "html.parser")
        tables = soup.find_all("table")
        if not tables:
            return ""
        if len(tables) == 1:
            return str(tables[0])

        best_table = tables[0]
        best_count = 0
        for table in tables:
            count = self._count_xmarks(str(table))
            if count > best_count:
                best_count = count
                best_table = table
        return str(best_table)
