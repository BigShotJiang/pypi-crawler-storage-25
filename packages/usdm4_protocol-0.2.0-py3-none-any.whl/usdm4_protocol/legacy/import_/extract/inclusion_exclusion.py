from simple_error_log.errors import Errors
from simple_error_log.error_location import KlassMethodLocation
from usdm4_protocol.common.ai.base_ai import BaseAIProvider
from usdm4_protocol.common.extract.ie_extractor import IEExtractor
from usdm4_protocol.common.extract.section_finder import find_sections_by_title


class InclusionExclusion:
    """Extract Inclusion/Exclusion criteria from legacy PDF protocol sections.

    Uses the common IEExtractor for the actual extraction logic. Section
    location is done by title matching since legacy PDFs do not have fixed
    section numbers for IE content.
    """

    MODULE = "usdm4_protocol.legacy.import_.extract.inclusion_exclusion.InclusionExclusion"

    # Search terms for finding IE sections by title — ordered from most
    # specific to least.  "eligibility" handles combined sections that
    # contain both inclusion and exclusion criteria under one heading.
    INCLUSION_SEARCH_TERMS = ["inclusion criteria", "inclusion", "eligibility criteria", "eligibility"]
    EXCLUSION_SEARCH_TERMS = ["exclusion criteria", "exclusion", "eligibility criteria", "eligibility"]

    def __init__(self, sections: list[dict], errors: Errors, use_ai: bool = True, ai: BaseAIProvider = None):
        """
        Initialize the legacy IE extractor.

        Args:
            sections: List of section dicts from SplitHTML, each with:
                - section_number: str
                - section_title: str
                - text: str (HTML content)
            errors: Error logging object.
            use_ai: Whether to use AI for extraction (default True for legacy).
                Ignored when ``ai`` is provided.
            ai: Pre-configured AI provider.  When provided, ``use_ai`` is
                ignored and this provider is used directly.
        """
        self._sections = sections
        self._errors = errors
        if ai is None and use_ai:
            from usdm4_protocol.common.ai.claude_provider import ClaudeProvider

            ai = ClaudeProvider(errors)
        self._ie_extractor = IEExtractor(ai, errors)

    def process(self) -> dict:
        """
        Extract inclusion and exclusion criteria.

        Returns:
            Dict matching the population schema:
            {"inclusion": [str, ...], "exclusion": [str, ...]}
            where each string is HTML text of a criterion.
            Returns {"inclusion": [], "exclusion": []} on failure.
        """
        try:
            inclusion_html = self._find_section_html(self.INCLUSION_SEARCH_TERMS, "inclusion")
            exclusion_html = self._find_section_html(self.EXCLUSION_SEARCH_TERMS, "exclusion")

            inclusion = self._extract_criteria(inclusion_html, "inclusion")
            exclusion = self._extract_criteria(exclusion_html, "exclusion")

            return {
                "inclusion": [item["text"] for item in inclusion],
                "exclusion": [item["text"] for item in exclusion],
            }
        except Exception as e:
            self._errors.exception(
                "Failed to extract Inclusion/Exclusion criteria from legacy document",
                e,
                KlassMethodLocation(self.MODULE, "process"),
            )
            return {"inclusion": [], "exclusion": []}

    def _find_section_html(self, search_terms: list[str], criteria_type: str) -> str:
        """
        Find the HTML content for a criteria section by searching titles.

        Tries each search term in order, from most specific to least. When the
        matched section has sparse content, collects text from subsequent orphaned
        sections — numbered criteria that the PDF parser misidentified as top-level
        sections — until the next structural sibling is reached.

        Args:
            search_terms: List of terms to search for in section titles.
            criteria_type: "inclusion" or "exclusion" (for error messages).

        Returns:
            The HTML text of the matching section, or empty string if not found.
        """
        for term in search_terms:
            matches = find_sections_by_title(self._sections, term)
            if matches:
                if len(matches) > 1:
                    self._errors.info(
                        f"Multiple sections found matching '{term}' for {criteria_type} criteria, using first match: '{matches[0].get('section_title', '')}'",
                        KlassMethodLocation(self.MODULE, "_find_section_html"),
                    )
                section = matches[0]
                html = section.get("text", "")
                child_html = self._collect_child_content(section)
                if child_html:
                    html += child_html
                return html

        self._errors.warning(
            f"No section found for {criteria_type} criteria in legacy document",
            KlassMethodLocation(self.MODULE, "_find_section_html"),
        )
        return ""

    def _collect_child_content(self, section: dict) -> str:
        """
        Collect text from orphaned sections that follow the matched section.

        PDF parsing can misidentify numbered criteria (1, 2, 3...) as top-level
        sections. These sit between the parent IE section and its next structural
        sibling. This method detects that pattern and merges the orphaned content.

        Args:
            section: The matched section dict.

        Returns:
            Concatenated HTML from orphaned child sections, or empty string.
        """
        try:
            idx = self._sections.index(section)
        except ValueError:
            return ""

        section_number = section.get("section_number", "")
        if not section_number:
            return ""

        sibling_prefix = self._sibling_prefix(section_number)
        parts = []
        for subsequent in self._sections[idx + 1 :]:
            num = subsequent.get("section_number", "")
            if self._is_structural_sibling_or_parent(num, sibling_prefix):
                break
            title = subsequent.get("section_title", "")
            text = subsequent.get("text", "")
            title_html = f"<p>{title}</p>" if title else ""
            parts.append(title_html + text)

        return "".join(parts)

    @staticmethod
    def _sibling_prefix(section_number: str) -> str:
        """
        Return the parent prefix used to identify structural siblings.

        For "5.2" returns "5.", for "4.1" returns "4.", for "5" returns "".
        """
        dot = section_number.rfind(".")
        if dot == -1:
            return ""
        return section_number[: dot + 1]

    @staticmethod
    def _is_structural_sibling_or_parent(num: str, sibling_prefix: str) -> bool:
        """
        Check whether a section number indicates a structural sibling or parent.

        A section is a structural sibling if its number starts with the same
        parent prefix (e.g., "5.3" is a sibling of "5.2" — both share "5.").
        If there is no parent prefix, any hierarchical number (containing a dot)
        is considered structural.
        """
        if not num:
            return False
        if sibling_prefix:
            return num.startswith(sibling_prefix)
        return "." in num

    def _extract_criteria(self, html: str, criteria_type: str) -> list[dict]:
        """
        Extract criteria from HTML content.

        Args:
            html: HTML content of the criteria section.
            criteria_type: "inclusion" or "exclusion".

        Returns:
            List of dicts with "identifier" and "text" keys.
        """
        if not html:
            return []
        return self._ie_extractor.extract_criteria(html, criteria_type)
