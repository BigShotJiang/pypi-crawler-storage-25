from abc import ABC, abstractmethod
from simple_error_log.errors import Errors


class ToHTMLBase(ABC):
    """Base class for PDF to HTML converters.

    All implementations must produce a single HTML string from a PDF file.
    The downstream pipeline (CleanHTML → SplitHTML) expects standard HTML
    with headings (h1-h6), paragraphs (p), and tables (table/tr/td).
    """

    def __init__(self, full_path: str, errors: Errors):
        self._full_path = full_path
        self._errors = errors

    @abstractmethod
    def process(self) -> str | None:
        """Convert PDF to HTML string.

        Returns:
            HTML string, or None on failure.
        """
        ...

    @classmethod
    @abstractmethod
    def available(cls) -> bool:
        """Check whether this converter's dependencies are installed."""
        ...
