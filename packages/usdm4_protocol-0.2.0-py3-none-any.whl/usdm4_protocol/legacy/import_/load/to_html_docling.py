import warnings

from simple_error_log.errors import Errors
from simple_error_log.error_location import KlassMethodLocation
from usdm4_protocol.legacy.import_.load.to_html_base import ToHTMLBase

# Docling's pydantic models use "model_" prefixed fields (model_spec, model_path,
# model_name, etc.) without configuring protected_namespaces, which triggers
# UserWarning from pydantic v2.  Filter before importing docling.
# Tracking: https://github.com/pydantic/pydantic/issues/10315
warnings.filterwarnings(
    "ignore",
    message=r'Field "model_\w+" has conflict with protected namespace "model_"',
    category=UserWarning,
    module=r"pydantic\._internal\._fields",
)

try:
    from docling.document_converter import DocumentConverter

    DOCLING_AVAILABLE = True
except ImportError:
    DocumentConverter = None
    DOCLING_AVAILABLE = False


class ToHTMLDocling(ToHTMLBase):
    """PDF to HTML converter using IBM Docling.

    Provides the highest accuracy for complex tables and document structure,
    but requires a large dependency footprint (~1GB+ including AI models).

    Install with: pip install usdm4_protocol[pdf-docling]
    """

    MODULE = "usdm4_protocol.legacy.import_.load.to_html_docling.ToHTMLDocling"

    def __init__(self, full_path: str, errors: Errors):
        super().__init__(full_path, errors)
        if not DOCLING_AVAILABLE:
            raise ImportError(
                "The 'docling' package is required for the Docling PDF converter. "
                "Install it with: pip install usdm4_protocol[pdf-docling]"
            )
        self._converter = DocumentConverter()

    def process(self) -> str | None:
        try:
            result = self._converter.convert(self._full_path)
            return result.document.export_to_html()
        except Exception as e:
            location = KlassMethodLocation(self.MODULE, "process")
            self._errors.exception(
                "Exception raised converting document to HTML via Docling",
                e,
                location,
            )
            return None

    @classmethod
    def available(cls) -> bool:
        return DOCLING_AVAILABLE
