try:
    import pymupdf

    PYMUPDF_AVAILABLE = True
except ImportError:
    pymupdf = None
    PYMUPDF_AVAILABLE = False

import re
from simple_error_log.errors import Errors
from simple_error_log.error_location import KlassMethodLocation
from usdm4_protocol.legacy.import_.load.to_html_base import ToHTMLBase


class ToHTMLPyMuPDF(ToHTMLBase):
    """PDF to HTML converter using PyMuPDF.

    Lightweight (~20MB install, no GPU, no model downloads) with good
    support for structured documents. Uses geometric heuristics for
    table detection rather than AI models.

    Install with: pip install usdm4_protocol[pdf]
    """

    MODULE = "usdm4_protocol.legacy.import_.load.to_html_pymupdf.ToHTMLPyMuPDF"

    # Font size thresholds for heading detection
    HEADING_SIZES = {
        18.0: "h1",
        16.0: "h2",
        14.0: "h3",
        13.0: "h4",
        12.0: "h5",
    }

    def __init__(self, full_path: str, errors: Errors):
        super().__init__(full_path, errors)
        if not PYMUPDF_AVAILABLE:
            raise ImportError(
                "The 'pymupdf' package is required for the PyMuPDF PDF converter. "
                "Install it with: pip install usdm4_protocol[pdf]"
            )

    def process(self) -> str | None:
        try:
            doc = pymupdf.open(self._full_path)
            html_parts = ["<html><body>"]
            for page in doc:
                page_html = self._process_page(page)
                html_parts.append(page_html)
            html_parts.append("</body></html>")
            doc.close()
            return "\n".join(html_parts)
        except Exception as e:
            location = KlassMethodLocation(self.MODULE, "process")
            self._errors.exception(
                "Exception raised converting document to HTML via PyMuPDF",
                e,
                location,
            )
            return None

    def _process_page(self, page) -> str:
        """Process a single page, combining text blocks and tables into HTML."""
        try:
            # Get table regions so we can exclude them from text extraction
            tables_result = page.find_tables()
            table_rects = []
            table_html_map = {}  # map from top-y position to table HTML

            for table in tables_result.tables:
                table_rects.append(pymupdf.Rect(table.bbox))
                table_html_map[table.bbox[1]] = self._table_to_html(table)

            # Get text blocks with position info
            blocks = page.get_text("dict", flags=pymupdf.TEXT_PRESERVE_WHITESPACE)["blocks"]

            elements = []  # list of (y_position, html_string)

            for block in blocks:
                if block["type"] != 0:  # skip image blocks
                    continue

                block_rect = pymupdf.Rect(block["bbox"])

                # Skip blocks that fall within a table region
                if self._in_table_region(block_rect, table_rects):
                    continue

                block_html = self._block_to_html(block)
                if block_html:
                    elements.append((block["bbox"][1], block_html))

            # Insert tables at their y-positions
            for y_pos, table_html in table_html_map.items():
                elements.append((y_pos, table_html))

            # Sort by y-position to maintain reading order
            elements.sort(key=lambda e: e[0])

            return "\n".join(html for _, html in elements)

        except Exception as e:
            location = KlassMethodLocation(self.MODULE, "_process_page")
            self._errors.debug(
                f"Error processing page: {e}",
                location,
            )
            # Fallback: use simple text extraction
            return self._simple_page_html(page)

    def _block_to_html(self, block: dict) -> str | None:
        """Convert a text block to an HTML element (heading or paragraph)."""
        lines = block.get("lines", [])
        if not lines:
            return None

        # Collect all text and determine formatting
        text_parts = []
        max_font_size = 0.0
        is_bold = False

        for line in lines:
            for span in line.get("spans", []):
                text = span.get("text", "")
                if text.strip():
                    text_parts.append(self._escape_html(text))
                    size = span.get("size", 12.0)
                    if size > max_font_size:
                        max_font_size = size
                    flags = span.get("flags", 0)
                    if flags & 2**4:  # bold flag
                        is_bold = True

        full_text = " ".join(text_parts).strip()
        if not full_text:
            return None

        # Determine if this is a heading based on font size and boldness
        tag = self._detect_heading_tag(full_text, max_font_size, is_bold)

        return f"<{tag}>{full_text}</{tag}>"

    def _detect_heading_tag(self, text: str, font_size: float, is_bold: bool) -> str:
        """Detect whether text should be a heading based on font size and style."""
        # Check if text starts with a section number pattern
        has_section_number = bool(re.match(r"^\d+(\.\d+)*\.?\s", text))

        # Large font sizes are likely headings
        for threshold, tag in sorted(self.HEADING_SIZES.items(), reverse=True):
            if font_size >= threshold:
                return tag

        # Bold text with a section number pattern is likely a heading
        if is_bold and has_section_number:
            return "h4"

        return "p"

    def _table_to_html(self, table) -> str:
        """Convert a PyMuPDF table to an HTML table element."""
        rows = table.extract()
        if not rows:
            return ""

        html_parts = ["<table>"]

        for i, row in enumerate(rows):
            html_parts.append("<tr>")
            tag = "th" if i == 0 else "td"
            for cell in row:
                cell_text = self._escape_html(cell) if cell else ""
                # Preserve line breaks within cells
                cell_text = cell_text.replace("\n", "<br/>")
                html_parts.append(f"<{tag}>{cell_text}</{tag}>")
            html_parts.append("</tr>")

        html_parts.append("</table>")
        return "\n".join(html_parts)

    def _in_table_region(self, block_rect, table_rects: list) -> bool:
        """Check if a text block falls within any table region."""
        for table_rect in table_rects:
            if block_rect.intersects(table_rect):
                return True
        return False

    def _simple_page_html(self, page) -> str:
        """Fallback: simple text-to-paragraph conversion."""
        text = page.get_text("text")
        if not text.strip():
            return ""
        paragraphs = text.split("\n\n")
        return "\n".join(f"<p>{self._escape_html(p.strip())}</p>" for p in paragraphs if p.strip())

    @staticmethod
    def _escape_html(text: str) -> str:
        """Escape HTML special characters."""
        return text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace('"', "&quot;")

    @classmethod
    def available(cls) -> bool:
        return PYMUPDF_AVAILABLE
