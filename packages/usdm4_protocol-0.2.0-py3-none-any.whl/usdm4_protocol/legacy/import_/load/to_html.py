from simple_error_log.errors import Errors
from usdm4_protocol.legacy.import_.load.to_html_base import ToHTMLBase
from usdm4_protocol.legacy.import_.load.to_html_pymupdf import ToHTMLPyMuPDF
from usdm4_protocol.legacy.import_.load.to_html_docling import ToHTMLDocling


def get_converter(full_path: str, errors: Errors, prefer: str = "auto") -> ToHTMLBase:
    """Get the best available PDF-to-HTML converter.

    Args:
        full_path: Path to the PDF file.
        errors: Error logging object.
        prefer: Converter preference.
            - "auto": Use docling if available, otherwise pymupdf.
            - "docling": Use docling (raises ImportError if not installed).
            - "pymupdf": Use pymupdf (raises ImportError if not installed).

    Returns:
        A ToHTMLBase instance.

    Raises:
        ImportError: If the requested converter is not installed, or if
            no PDF converter is available when using "auto".
    """
    if prefer == "docling":
        return ToHTMLDocling(full_path, errors)
    elif prefer == "pymupdf":
        return ToHTMLPyMuPDF(full_path, errors)
    else:
        # Auto: prefer docling for best accuracy, fall back to pymupdf
        if ToHTMLDocling.available():
            return ToHTMLDocling(full_path, errors)
        elif ToHTMLPyMuPDF.available():
            return ToHTMLPyMuPDF(full_path, errors)
        else:
            raise ImportError(
                "No PDF converter available. Install one of:\n"
                "  pip install usdm4_protocol[pdf]          # lightweight (PyMuPDF)\n"
                "  pip install usdm4_protocol[pdf-docling]   # best accuracy (Docling)"
            )


# Backward compatibility: ToHTML as an alias for the factory
class ToHTML:
    """PDF to HTML converter (backward-compatible wrapper).

    Uses the best available converter at runtime.
    """

    def __init__(self, full_path: str, errors: Errors, prefer: str = "auto"):
        self._converter = get_converter(full_path, errors, prefer)

    def process(self) -> str | None:
        return self._converter.process()
