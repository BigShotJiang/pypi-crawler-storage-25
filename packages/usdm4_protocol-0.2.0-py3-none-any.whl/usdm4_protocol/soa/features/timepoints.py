import re
import unicodedata
from typing import List, Dict, Any
from simple_error_log import Errors
from simple_error_log.error_location import KlassMethodLocation
from usdm4_protocol.common.html.expand_table import expand_table


class TimepointsFeature:
    """Extract timepoint timing information from SoA table."""

    MODULE = "usdm4_protocol.soa.features.timepoints.TimepointsFeature"

    def __init__(self, errors: Errors):
        self._errors = errors

    def process(
        self,
        html_content: str,
        max_rows_to_analyze: int,
        ignore_last: bool = False,
        row_hint: int = None,
        visits_result: dict = None,
    ) -> List[Dict[str, Any]]:
        """
        Extract timing values and units from SoA table.

        Args:
            html_content (str): HTML content containing the SoA table
            max_rows_to_analyze (int): Maximum number of rows to analyze
            ignore_last (bool): Whether to ignore the last column
            row_hint (int): If provided, only evaluate this row index (0-based).
                When a hint is provided (from the row classifier), the row is
                trusted and value extraction proceeds without re-validating
                via ``_is_timing_row_new``.
            visits_result (dict): Optional visits result dict.  When provided
                and no real timepoints are found, placeholder timepoints are
                synthesised from the visit items so the assembler has a spine.

        Returns:
            List[Dict[str, Any]]: List of dictionaries containing timing values and units
        """
        results = {
            "found": False,
            "items": [],
        }
        try:
            table = expand_table(html_content)
            if not table:
                self._errors.error("No table detected", KlassMethodLocation(self.MODULE, "process"))
                return results

            rows = table.find_all("tr")

            # --- Trusted hint path ---
            # When the row classifier already identified the timepoint row,
            # trust that classification and go straight to value extraction.
            if row_hint is not None:
                if row_hint < len(rows):
                    row = rows[row_hint]
                    cells = row.find_all(["td", "th"])
                    if cells:
                        first_cell_text = self._clean_text(cells[0].get_text())
                        unit = self._get_time_unit(first_cell_text)
                        timing_data = self._extract_values_from_cells(cells[1:], unit)
                        timing_data = timing_data[:-1] if ignore_last else timing_data
                        # Accept the row if we extracted at least one numeric value
                        if any(item["value"] != 0 for item in timing_data):
                            results = {"found": True, "items": timing_data, "row": row_hint}
                            self._errors.info(f"Timing (hint): Row={row_hint}\n{timing_data}")
                        else:
                            # Log CCI-redacted rows for diagnostics
                            cci_count = sum(1 for item in timing_data if item.get("text", "").strip().upper() == "CCI")
                            if cci_count > 0:
                                self._errors.info(
                                    f"Timepoint row {row_hint} is CCI-redacted "
                                    f"({cci_count} CCI cells, 0 numeric values)",
                                    KlassMethodLocation(self.MODULE, "process"),
                                )
                results = synthesise_default_timepoints(results, visits_result)
                self._errors.info(
                    f"Timepoints '{results}'",
                    KlassMethodLocation(self.MODULE, "process"),
                )
                return results

            # --- Scanning path (no hint) ---
            timing_row = None
            rows_to_check = list(enumerate(rows[:max_rows_to_analyze]))

            result = None
            current_score = 0
            for r_index, row in rows_to_check:
                cells = row.find_all(["td", "th"])
                # Skip rows with merged cells
                if any(cell.get("colspan") or cell.get("rowspan") for cell in cells):
                    continue

                if not cells:
                    continue

                first_cell_text = self._clean_text(cells[0].get_text())

                is_timing_row, score = self._is_timing_row_new(cells)
                if is_timing_row:
                    unit = self._get_time_unit(first_cell_text)
                    timing_data = self._extract_values_from_cells(cells[1:], unit)
                    if score > current_score:
                        current_score = score
                        result = timing_data
                        timing_row = r_index + 1
            if result:
                result = result[:-1] if ignore_last else result
                results = {"found": True, "items": result, "row": timing_row}
                self._errors.info(f"Timing: Row={timing_row}, Score={current_score}\n{result}")
            results = synthesise_default_timepoints(results, visits_result)
            self._errors.info(f"Timepoints '{results}'", KlassMethodLocation(self.MODULE, "process"))
            return results
        except Exception as e:
            self._errors.exception(
                "Exception raised extracting timepoints",
                e,
                KlassMethodLocation(self.MODULE, "process"),
            )
            results = synthesise_default_timepoints(results, visits_result)
            return results

    def _extract_values_from_cells(self, cells: list, unit: str) -> List[Dict[str, Any]]:
        """Extract timing values from a list of cells (excluding the first/label column).

        Args:
            cells: Cell elements to extract values from.
            unit: Default time unit (day/week/month).

        Returns:
            List of timing value dicts.
        """
        timing_data: List[Dict[str, Any]] = []
        for index, cell in enumerate(cells):
            cell_text = self._clean_text(cell.get_text())
            original_text = cell_text
            if not cell_text:
                timing_data.append({"text": original_text, "value": 0, "unit": "", "index": index})
                continue

            value, up_to_unit = self._decode_up_to_pattern(cell_text)
            if value and up_to_unit:
                timing_data.append({"text": original_text, "value": 0, "unit": "", "index": index})
                continue

            value = self._decode_range_pattern(cell_text)
            if value is not None:
                timing_data.append({"text": original_text, "value": value, "unit": unit, "index": index})
                continue

            value = self._decode_visit_day_pattern(cell_text)
            if value:
                timing_data.append({"text": original_text, "value": value, "unit": "day", "index": index})
                continue

            value = self._decode_value_pattern(cell_text)
            if value:
                timing_data.append({"text": original_text, "value": value, "unit": unit, "index": index})
                continue
            else:
                timing_data.append({"text": original_text, "value": 0, "unit": unit, "index": index})
        return timing_data

    def _clean_text(self, text: str) -> str:
        """Clean and normalize text content."""
        if not text:
            return ""

        # Normalize unicode
        text = unicodedata.normalize("NFKD", text)

        # Convert unicode minus characters
        minus_chars = ["−", "‒", "–", "—", "âˆ'"]
        for minus_char in minus_chars:
            text = text.replace(minus_char, "-")

        # Handle other unicode
        text = text.replace("Â±", "±")
        text = text.replace("â‰¥", ">=")

        # Normalize whitespace
        text = re.sub(r"\s+", " ", text).strip()
        return text

    def _is_timing_row_new(self, row_cells: List[str]) -> tuple[bool, int]:
        """
        Check if row matches timing criteria based on comprehensive analysis.

        Args:
            row_cells: List of cell elements from the row

        Returns:
            tuple: (True if timing row, score)
        """
        if not row_cells or len(row_cells) < 2:
            return False, 0

        # Clean all cell texts
        cleaned_cells = [self._clean_text(cell.get_text()) for cell in row_cells]

        # Check first column for timing indicators
        first_cell = cleaned_cells[0].lower()
        first_column_matches = (
            "day" in first_cell or "week" in first_cell or "target day" in first_cell or "study day" in first_cell
        )

        # Check first few cells (<=3) for timing patterns
        timing_pattern_found = False
        for i in range(min(3, len(cleaned_cells))):
            cell_lower = cleaned_cells[i].lower()

            # Pattern: "n to m" days/weeks
            if re.search(r"\d+\s+to\s+\d+\s*(day|week)", cell_lower):
                timing_pattern_found = True
                break

            # Pattern: "Up to n" days/weeks
            digits, time_unit = self._decode_up_to_pattern(cell_lower)
            if digits is not None and time_unit is not None:
                timing_pattern_found = True
                break

            # Pattern: other timing text
            if any(word in cell_lower for word in ["day", "week", "target"]):
                timing_pattern_found = True
                break

        # If neither first column nor timing patterns match, return False
        if not (first_column_matches or timing_pattern_found):
            return False, 0

        # Analyze remaining cells (after first 3 or from index 1 if no timing pattern in first 3)
        start_index = 1
        remaining_cells = cleaned_cells[start_index:]

        if not remaining_cells:
            return False, 0

        # Check if remaining cells match the criteria
        numeric_values = []
        valid_pattern_count = 0
        countable_cells = 0  # non-empty, non-CCI cells

        for cell in remaining_cells:
            cell_clean = cell.strip()
            # Skip empty cells — do not count them against the threshold
            if not cell_clean:
                continue

            # Skip CCI-redacted or similar — treat as neutral
            if cell_clean.upper() in ["CCI"]:
                continue

            countable_cells += 1

            # Handle NA or similar at the end
            if cell_clean.lower() in ["na", "n/a", "not applicable", "-", "et"]:
                valid_pattern_count += 1
                continue

            # Remove parenthetical content like (±3) or (+2) or (-1)
            cell_for_analysis = re.sub(r"\([±+\-]?\d+\)", "", cell_clean).strip()

            # Also remove non-parenthetical ± tolerance: "120 ± 2" → "120"
            cell_for_analysis = re.sub(r"\s*[±]\s*\d+", "", cell_for_analysis).strip()

            # Pattern 1: digits or minus sign with digits
            digit_match = re.match(r"^-?\d+$", cell_for_analysis)
            if digit_match:
                numeric_values.append(int(digit_match.group()))
                valid_pattern_count += 1
                continue

            # Pattern: range with tilde/dash "28 ~ 17" or "-28 ~ -17"
            range_match = re.match(r"^-?\d+\s*[~–—]\s*-?\d+$", cell_for_analysis)
            if range_match:
                first_num = re.match(r"^(-?\d+)", cell_for_analysis)
                if first_num:
                    numeric_values.append(int(first_num.group(1)))
                valid_pattern_count += 1
                continue

            # Pattern: "≤28", ">=14", "≥7"
            inequality_match = re.match(r"^[≤≥<>]=?\s*(-?\d+)$", cell_for_analysis)
            if inequality_match:
                numeric_values.append(int(inequality_match.group(1)))
                valid_pattern_count += 1
                continue

            # Pattern 3: V<digits>[/Text]<white space>D<digits>
            time_pattern_match = re.match(r"^V\d+\w*\/?\w*\s*D(\d+)", cell_for_analysis, re.IGNORECASE)
            if time_pattern_match:
                numeric_values.append(int(time_pattern_match.group(1)))
                valid_pattern_count += 1
                continue

            # Pattern 2: D<digit>, W<digit>, Day <digit>, Week <digit>
            time_pattern_match = re.match(r"^(D|W|Day\s+|Week\s+)(-?\d+)", cell_for_analysis, re.IGNORECASE)
            if time_pattern_match:
                numeric_values.append(int(time_pattern_match.group(2)))
                valid_pattern_count += 1
                continue

            # Pattern: "Day -28 ~ -17" or "Day 120 ± 2" (with Day prefix)
            day_range_match = re.match(r"^(?:Day\s*|D)(-?\d+)", cell_for_analysis, re.IGNORECASE)
            if day_range_match:
                numeric_values.append(int(day_range_match.group(1)))
                valid_pattern_count += 1
                continue

        # Must have at least some valid patterns among countable cells
        if countable_cells == 0 or valid_pattern_count < countable_cells * 0.4:
            return False, 0

        # Check if numeric values are increasing within segments.
        # Multi-cycle tables (e.g., Cycle 1: D1,D8,D15 → Cycle 2: D1,D8) have
        # values that reset across cycles. We detect segments and check each
        # segment independently rather than requiring global monotonicity.
        if len(numeric_values) >= 2:
            segments = self._detect_segments(numeric_values)
            for segment in segments:
                if len(segment) >= 2:
                    increasing_count = sum(1 for i in range(1, len(segment)) if segment[i] >= segment[i - 1])
                    if increasing_count < (len(segment) - 1) * 0.6:
                        return False, 0

        return True, valid_pattern_count + (1 if first_column_matches else 0) + (1 if timing_pattern_found else 0)

    def _detect_segments(self, values: list[int]) -> list[list[int]]:
        """Split numeric values into segments where each segment is roughly increasing.

        A new segment starts when a value drops below 50% of the previous value,
        indicating a cycle reset (e.g., Cycle 1: D1,D8,D15 → Cycle 2: D1,D8).

        Args:
            values: List of numeric timepoint values.

        Returns:
            List of segments, each a list of ints.
        """
        if not values:
            return []
        segments: list[list[int]] = [[values[0]]]
        for i in range(1, len(values)):
            if values[i] < values[i - 1] * 0.5:
                segments.append([values[i]])
            else:
                segments[-1].append(values[i])
        return segments

    def _decode_range_pattern(self, text: str):
        """Decode range patterns like 'Day -28 ~ -17', '-28 to -2', '≤28', 'Day 120 ± 2'.

        Extracts the first (or only) numeric value from the range.

        Returns:
            int or None
        """
        # "Day -28 ~ -17" or "-28 ~ -17"
        m = re.search(r"(-?\d+)\s*[~–—]\s*-?\d+", text)
        if m:
            return int(m.group(1))

        # "Day -28 to -2" or "-28 to -2"
        m = re.search(r"(-?\d+)\s+to\s+-?\d+", text, re.IGNORECASE)
        if m:
            return int(m.group(1))

        # "≤28" or "<=28" or "≥14"
        m = re.match(r"^[≤≥<>]=?\s*(-?\d+)$", text.strip())
        if m:
            return int(m.group(1))

        # "Day 120 ± 2" or "Day -14 ±1" (tolerance not in parentheses)
        m = re.search(r"(-?\d+)\s*[±]\s*\d+", text)
        if m:
            return int(m.group(1))

        return None

    def _decode_up_to_pattern(self, text: str) -> tuple:
        """
        Decode a string containing "Up to" pattern and extract digits and time unit.

        Args:
            text: Input string to decode

        Returns:
            tuple: (digits, time_unit) or (None, None) if pattern not found
        """
        pattern = r"(?i)up\s+to\s+(\d+)\s+(days?|weeks?)"
        match = re.search(pattern, text)
        if match:
            digits = int(match.group(1))
            time_unit = match.group(2).lower()
            # Normalize to singular form
            if time_unit.endswith("s"):
                time_unit = time_unit[:-1]
            return (digits, time_unit)
        return (None, None)

    def _decode_visit_day_pattern(self, text: str) -> int:
        """Decode visit day information using regex to extract digits from D<digits> pattern."""
        pattern = r".*?([-+])?D(\d+).*?"
        match = re.search(pattern, text, re.IGNORECASE)
        if match:
            sign = match.group(1) if match.group(1) else ""
            result = int(sign + match.group(2))
            return result
        return None

    def _decode_value_pattern(self, text: str) -> int:
        """Decode information using regex to extract digits from text."""
        pattern = r".*?([-+]?\d+).*?"
        match = re.search(pattern, text, re.IGNORECASE)
        if match:
            result = int(match.group(1))
            return result
        return None

    def _get_time_unit(self, cell_text: str) -> str:
        """Determine time unit from first cell."""
        cell_lower = cell_text.lower()
        if "week" in cell_lower:
            return "week"
        elif "month" in cell_lower:
            return "month"
        return "day"


def synthesise_default_timepoints(timepoints_result: dict, visits_result: dict) -> dict:
    """Synthesise placeholder timepoints from visits when no real timing data exists.

    The ``usdm4`` assembler uses the timepoints list as the backbone for
    timeline assembly — epochs and encounters are attached by positional
    index.  When real timing values are unavailable (CCI-redacted rows,
    text-only timing, or no timepoint row at all), this function creates
    one placeholder timepoint per visit so the assembler spine is populated.

    Args:
        timepoints_result: The result dict from ``TimepointsFeature.process()``.
        visits_result: The result dict from ``VisitsFeature.process()``.

    Returns:
        The *timepoints_result* dict — either unchanged (if real timepoints
        were already found) or updated with synthetic placeholders.
    """
    if timepoints_result.get("found") and timepoints_result.get("items"):
        return timepoints_result

    if not visits_result:
        return timepoints_result

    visit_items = visits_result.get("items", [])
    if not visit_items:
        return timepoints_result

    default_items = [
        {
            "text": item.get("text", ""),
            "value": 0,
            "unit": "day",
            "index": item["index"],
        }
        for item in visit_items
    ]
    timepoints_result["found"] = True
    timepoints_result["items"] = default_items
    timepoints_result["synthetic"] = True
    return timepoints_result
