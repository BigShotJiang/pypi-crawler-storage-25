from typing import List, Dict
from simple_error_log import Errors
from simple_error_log.error_location import KlassMethodLocation
from usdm4_protocol.common.html.expand_table import expand_table
from usdm4_protocol.soa.features.utility import cell_text, cell_references


class ActivitiesFeature:
    """Extract activity information from SoA table."""

    MODULE = "usdm4_protocol.soa.features.activities.ActivitiesFeature"

    def __init__(self, errors: Errors):
        self._errors = errors

    def process(self, html_content: str, assessments: dict, start_row: int, last_column: int) -> List[Dict]:
        """
        Extract parent and child activities from a Schedule of Activities HTML table.

        Args:
            html_content (str): HTML content containing the table
            assessments (dict): Dictionary of assessments
            start_row (int): Row number to start processing activities from
            last_column (int): Index of the last column to include

        Returns:
            List of activity dictionaries
        """
        results = {
            "found": False,
            "items": [],
        }
        table = expand_table(html_content)
        if not table:
            self._errors.error("No table detected", KlassMethodLocation(self.MODULE, "process"))
            return results

        # Extract all table rows
        rows = table.find_all("tr")

        # Convert rows to list of cell contents
        table_data = []
        table_references = []
        for row in rows:
            cells = row.find_all(["td", "th"])
            row_cells = []
            row_references = []
            for cell in cells[: last_column + 2]:  # +2 because includes activity name column
                row_references.append(cell_references(cell))
                row_cells.append(cell_text(cell))
            table_data.append(row_cells)
            table_references.append(row_references)

        if not table_data:
            raise ValueError("No data found in table")

        # Extract activities
        results["items"] = self._extract_activities(table_data, table_references, assessments, start_row)
        results["found"] = True
        return results

    def _extract_activities(
        self,
        table_data: List[List[str]],
        table_references: List[List[str]],
        assessments: dict,
        start_row: int,
    ) -> List[Dict]:
        """
        Extract parent and child activities from the table data.

        Args:
            table_data: List of rows
            table_references: List of row references
            assessments: Dictionary of assessments
            start_row: Row to start processing from

        Returns:
            List of activity dictionaries
        """
        activities = []
        current_parent = None

        for i in range(start_row, len(table_data)):
            row = table_data[i]
            references = table_references[i]
            if not row:
                continue
            activity_name = row[0].strip()

            if not activity_name:
                self._errors.warning(f"Missing activity name in row {i + 1}")
                continue

            if self._is_parent(row):
                current_parent = {
                    "name": activity_name,
                    "index": i,
                    "children": [],
                    # Include activity-compatible keys so the assembler
                    # receives a uniform structure for both parents and leaves.
                    "visits": [],
                    "references": references[0] if references else [],
                    "actions": {"bcs": [], "procedures": [], "timelines": []},
                }
                activities.append(current_parent)
            else:
                # Only rows with X markers or other non-empty visit cells
                # are treated as activities. Rows with a name but no visit
                # data are skipped — they may be sub-headers, notes, or
                # other non-activity content.
                if not self._has_x_markers(row) and not self._has_text_markers(row):
                    continue
                activity = {
                    "name": activity_name,
                    "index": i,
                    "visits": self._extract_visits_for_activity(row, references),
                    "references": references[0],
                    "actions": {
                        "bcs": self._include_assessments(activity_name, assessments),
                        "procedures": [],
                        "timelines": [],
                    },
                }
                if current_parent:
                    current_parent["children"].append(activity)
                else:
                    activities.append(activity)

        return activities

    def _include_assessments(self, activity_name: str, assessments: dict) -> list[str]:
        """Check if assessments apply to this activity."""
        result = []
        name_upper: str = activity_name.upper()
        name: str
        tests: list
        for name, tests in assessments.items():
            if name.upper() in name_upper:
                result += tests
        return result

    def _has_x_markers(self, row: List[str]) -> bool:
        """Check if a row contains "X" markers indicating scheduled activities."""
        return any(cell.strip().upper() == "X" for cell in row if cell)

    def _has_text_markers(self, row: List[str]) -> bool:
        """Check if visit columns contain non-empty text (non-X markers).

        This catches rows where visit cells have text like checkmarks,
        abbreviations, or other non-X indicators of scheduled activities.
        Only checks cells after the first (activity name) column.
        """
        for cell in row[1:]:
            text = cell.strip()
            if text and text.upper() != "X":
                return True
        return False

    def _is_parent(self, row: List[str]) -> bool:
        """Check if a row is a parent/category header.

        Currently only detects **merged rows**: all cells are identical
        (the table had a merged row that was expanded by ``expand_table``
        so every cell repeats the label).

        Note: Label-only rows (first cell has text, rest empty) are a
        common pattern for category headers, but detecting them here is
        unsafe because real activity rows without X marks look identical.
        See CLAUDE.md "Parent Activity Detection — Two Patterns" for
        context on why Pattern 2 was reverted.
        """
        if not row or not row[0].strip():
            return False
        # Pattern 1: all cells identical (merged row from expand_table)
        if all(x == row[0] for x in row):
            return True
        return False

    def _extract_visits_for_activity(self, row: list[str], references: list[str]) -> list[str]:
        """
        Extract which visits an activity is scheduled for based on markers.

        Args:
            row: Row data containing markers
            references: List of references for each cell

        Returns:
            List of visit information
        """
        visits = []
        # Check each cell for markers, mapping to visit headers
        for j in range(1, len(row)):
            if row[j].strip().upper() == "X" or row[j].strip() != "":
                visits.append({"index": j - 1, "references": references[j]})
        return visits
