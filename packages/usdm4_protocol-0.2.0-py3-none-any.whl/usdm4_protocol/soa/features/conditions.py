import re
from bs4 import BeautifulSoup
from simple_error_log import Errors
from simple_error_log.error_location import KlassMethodLocation


class ConditionsFeature:
    """Extract conditional information from SoA footnotes.

    Footnote paragraphs appear after the SoA table and typically contain
    conditions like "Labs must be drawn fasting" linked to specific
    activities via reference markers (superscript letters, anchor links,
    or numbered footnotes).

    Extracts reference IDs from three patterns:
    - <a href="#ref_id"> anchor links
    - <sup>a</sup> superscript markers (common in PyMuPDF output)
    - Leading text markers: "a. Some text" or "1) Some text"
    """

    MODULE = "usdm4_protocol.soa.features.conditions.ConditionsFeature"

    # Pattern for leading footnote markers at start of paragraph text
    # Matches: "a.", "a)", "a:", "1.", "1)", "*", "†" etc. at start
    _LEADING_MARKER_RE = re.compile(
        r"^([a-z]|[A-Z]|\d{1,2}|\*|†|‡|§)\s*[.):]\s*",
    )

    def __init__(self, errors: Errors):
        self._errors = errors

    # Pattern for standalone footnote markers: a single letter, digit, or
    # symbol on its own in a paragraph (PyMuPDF puts superscripts on
    # separate lines).
    _STANDALONE_MARKER_RE = re.compile(r"^([a-z]|[A-Z]|\d{1,2}|\*+|†|‡|§)$")

    def process(self, html_content: str) -> dict:
        """
        Extract conditions/footnotes from HTML content.

        Args:
            html_content (str): HTML content containing footnotes/conditions

        Returns:
            dict: Results containing found status and items list.
                Each item has:
                - "text": Clean footnote text (marker stripped)
                - "reference": Primary reference ID (normalised, lowercase)
                - "references": List of all reference IDs for this footnote
        """
        results = {
            "found": False,
            "items": [],
        }
        try:
            if not html_content or not html_content.strip():
                return results

            soup = BeautifulSoup(html_content, "html.parser")
            paragraphs = soup.findAll("p")

            # Pre-process: merge standalone marker paragraphs with following
            # text. PyMuPDF often renders superscript markers as separate
            # <p> elements: <p>a</p><p>Footnote text here...</p>
            merged = self._merge_standalone_markers(paragraphs)

            for refs, text in merged:
                if not text:
                    continue

                if refs:
                    results["items"].append(
                        {
                            "text": text,
                            "reference": refs[0],
                            "references": refs,
                        }
                    )
                elif text:
                    # Footnote paragraph without a clear reference marker —
                    # still capture it as a condition with empty reference
                    results["items"].append(
                        {
                            "text": text,
                            "reference": "",
                            "references": [],
                        }
                    )

            results["found"] = len(results["items"]) > 0
            self._errors.info(
                f"Conditions: {len(results['items'])} items extracted",
                KlassMethodLocation(self.MODULE, "process"),
            )
            return results
        except Exception as e:
            self._errors.exception(
                "Exception raised processing conditions",
                e,
                KlassMethodLocation(self.MODULE, "process"),
            )
            return results

    def _merge_standalone_markers(self, paragraphs) -> list[tuple[list[str], str]]:
        """Pre-process paragraphs, merging standalone markers with following text.

        PyMuPDF often renders superscript footnote markers as separate
        ``<p>`` elements::

            <p>a</p>
            <p>Short-term follow-up begins...</p>

        This method detects standalone marker paragraphs and merges them
        with the next paragraph that has actual content, producing a list
        of ``(refs, text)`` tuples ready for condition extraction.

        For normal paragraphs (no standalone marker), the usual extraction
        logic applies: HTML-based references first, then leading text
        markers.
        """
        result = []
        pending_marker = None  # marker string waiting to merge with next para
        i = 0
        while i < len(paragraphs):
            para = paragraphs[i]
            text = para.get_text(separator=" ", strip=True)

            if not text:
                i += 1
                continue

            # Check for standalone marker paragraph
            m = self._STANDALONE_MARKER_RE.match(text)
            if m and pending_marker is None:
                pending_marker = m.group(1).strip().lower()
                i += 1
                continue

            # Normal paragraph — extract refs and text
            refs = self._extract_references(para)

            if not refs:
                marker_match = self._LEADING_MARKER_RE.match(text)
                if marker_match:
                    marker = marker_match.group(1).strip().lower()
                    refs.append(marker)
                    text = text[marker_match.end() :].strip()

            # If there's a pending standalone marker, prepend it as a ref
            if pending_marker is not None:
                if not refs:
                    refs = [pending_marker]
                elif pending_marker not in refs:
                    refs.insert(0, pending_marker)
                pending_marker = None

            result.append((refs, text))
            i += 1

        # If a marker was pending at the end with no following text,
        # emit it as a marker-only condition
        if pending_marker is not None:
            result.append(([pending_marker], pending_marker))

        return result

    def _extract_references(self, para) -> list[str]:
        """Extract reference IDs from a footnote paragraph element.

        Checks three sources:
        1. <a href="#..."> anchor links
        2. <sup> superscript markers
        3. <span id="..."> span anchors

        Args:
            para: BeautifulSoup paragraph element

        Returns:
            List of normalised reference IDs (lowercase, '#' stripped)
        """
        refs = []

        # 1. <a href="#..."> anchor links
        for anchor in para.findAll("a"):
            href = anchor.get("href", "").strip()
            if href.startswith("#"):
                refs.append(href.lstrip("#").strip().lower())

        # 2. <sup> superscript markers
        for sup in para.findAll("sup"):
            text = sup.get_text(strip=True)
            if text:
                for marker in re.split(r"[,;\s]+", text):
                    marker = marker.strip().lower()
                    if marker and self._is_footnote_marker(marker):
                        refs.append(marker)

        # 3. <span id="..."> anchors
        for span in para.findAll("span"):
            span_id = span.get("id", "").strip()
            if span_id:
                refs.append(span_id.lower())

        return refs

    @staticmethod
    def _is_footnote_marker(text: str) -> bool:
        """Check if text looks like a footnote marker."""
        if re.match(r"^[a-z]$", text, re.IGNORECASE):
            return True
        if re.match(r"^\d{1,2}$", text):
            return True
        if text in ("*", "**", "†", "‡", "§", "||", "¶"):
            return True
        return False
