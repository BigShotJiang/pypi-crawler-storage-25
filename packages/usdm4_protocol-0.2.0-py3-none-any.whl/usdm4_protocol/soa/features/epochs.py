from simple_error_log import Errors
from simple_error_log.error_location import KlassMethodLocation
from usdm4_protocol.common.html.expand_table import expand_table


class EpochsFeature:
    """Extract epoch/period information from SoA table."""

    MODULE = "usdm4_protocol.soa.features.epochs.EpochsFeature"

    PERIOD_TERMS = [
        "screening",
        "scn",
        "treatment",
        "follow-up",
        "follow up",
        "baseline",
        "washout",
        "run-in",
        "eos",
        "end of study",
        "edv",
        "early discontinuation",
    ]

    def __init__(self, errors: Errors):
        self._errors = errors

    def process(
        self,
        html_content: str,
        last_column: int,
        max_rows: int = 1,
        row_hint: int = None,
        timepoints_result: dict = None,
    ) -> dict:
        """
        Extract clinical trial period information with detailed analysis.

        Args:
            html_content (str): HTML string containing the table
            last_column (int): Index of the last column to process
            max_rows (int): Maximum number of rows to scan for epoch data.
                Defaults to 1 for backward compatibility.
            row_hint (int): If provided, only evaluate this row index (0-based).
                Skips the normal row-scanning logic.
            timepoints_result (dict): If provided, used to synthesise a default
                epoch when no epoch row is found.  Allows the assembler to build
                a ScheduleTimeline even without an explicit epoch row.

        Returns:
            dict: Detailed analysis including period information
        """
        results = {
            "found": False,
            "items": [],
        }
        try:
            table = expand_table(html_content)
            if not table:
                self._errors.error("No table detected", KlassMethodLocation(self.MODULE, "process"))
                return synthesise_default_epoch(results, timepoints_result)

            rows = table.find_all("tr")
            if not rows:
                self._errors.error(
                    "No rows detected in table",
                    KlassMethodLocation(self.MODULE, "process"),
                )
                return synthesise_default_epoch(results, timepoints_result)

            # If row_hint is provided, trust the classifier — extract all
            # non-empty cell values as epoch labels without requiring
            # PERIOD_TERMS matches.  Fall back to keyword matching only if
            # the trusted extraction yields nothing useful.
            if row_hint is not None:
                if row_hint < len(rows):
                    result = self._extract_from_row_trusted(rows[row_hint], last_column, row_hint)
                    if result["found"]:
                        self._errors.info(
                            f"Epochs (trusted hint) '{result}'",
                            KlassMethodLocation(self.MODULE, "process"),
                        )
                        return result
                    # If trusted extraction identified a merged title row
                    # (single label spanning all columns), do NOT fall back
                    # to keyword matching — it would false-positive on
                    # period terms in the title text (e.g. "Schedule of
                    # Activities for the Screening and Treatment Periods").
                    if not result.get("merged_title"):
                        result = self._extract_from_row(rows[row_hint], last_column, row_hint)
                        if result["found"]:
                            self._errors.info(
                                f"Epochs '{result}'",
                                KlassMethodLocation(self.MODULE, "process"),
                            )
                            return result
                return synthesise_default_epoch(results, timepoints_result)

            # Scan up to max_rows looking for epoch data
            for row_index in range(min(max_rows, len(rows))):
                result = self._extract_from_row(rows[row_index], last_column, row_index)
                if result["found"]:
                    self._errors.info(
                        f"Epochs '{result}'",
                        KlassMethodLocation(self.MODULE, "process"),
                    )
                    return result

            self._errors.info(f"Epochs '{results}'", KlassMethodLocation(self.MODULE, "process"))
            return synthesise_default_epoch(results, timepoints_result)
        except Exception as e:
            self._errors.exception(
                "Exception raised extracting epochs",
                e,
                KlassMethodLocation(self.MODULE, "process"),
            )
            return synthesise_default_epoch(results, timepoints_result)

    def _extract_from_row_trusted(self, row, last_column: int, row_index: int) -> dict:
        """Extract epoch data from a classifier-confirmed row.

        Trusts the classifier and treats every non-empty cell (after the
        first column) as an epoch label, without requiring PERIOD_TERMS
        matches.  Returns ``found=True`` when at least two distinct
        non-empty labels are present (a single label across all columns
        is likely a merged header, not epoch data).

        Args:
            row: BeautifulSoup row element.
            last_column (int): Index of the last column to process.
            row_index (int): 0-based index of this row in the table.

        Returns:
            dict with 'found', 'items', and optionally 'row' keys.
            When the row is a merged title (single label spanning all
            columns), the result includes ``"merged_title": True`` so
            the caller can skip keyword fallback.
        """
        results = {"found": False, "items": []}
        cells = row.find_all(["td", "th"])

        period_columns = []
        for i, cell in enumerate(cells):
            text = cell.get_text(strip=True)
            colspan = int(cell.get("colspan", 1))

            # Skip first column
            if i == 0:
                continue

            # Skip columns after last column
            if i > (last_column + 1):
                continue

            # Add to result columns (expanding colspan)
            for index, _ in enumerate(range(colspan)):
                period_columns.append({"text": text, "index": i + index - 1})

        # Require at least two distinct non-empty labels
        non_empty = {col["text"] for col in period_columns if col["text"]}
        if len(non_empty) >= 2:
            results["found"] = True
            results["items"] = period_columns
            results["row"] = row_index + 1
        elif len(non_empty) == 1:
            # Check whether this is a table title row (single cell
            # spanning the entire table, including cell 0).  After
            # expand_table, a title row has ALL cells — including the
            # first — with identical text.  A real single-epoch row
            # (e.g. "Treatment" spanning visit columns) has a different
            # or empty first column.
            first_cell_text = cells[0].get_text(strip=True) if cells else ""
            single_label = next(iter(non_empty))
            if first_cell_text == single_label:
                # Cell 0 matches the data columns — merged title row.
                # Flag so the caller skips keyword fallback (which would
                # false-positive on period terms in the title text).
                results["merged_title"] = True
        return results

    def _extract_from_row(self, row, last_column: int, row_index: int) -> dict:
        """
        Extract epoch data from a single table row.

        Args:
            row: BeautifulSoup row element.
            last_column (int): Index of the last column to process.
            row_index (int): 0-based index of this row in the table.

        Returns:
            dict with 'found', 'items', and optionally 'row' keys.
        """
        results = {"found": False, "items": []}
        cells = row.find_all(["td", "th"])

        period_columns = []
        found = False

        for i, cell in enumerate(cells):
            text = cell.get_text(strip=True)
            text_lower = text.lower()
            colspan = int(cell.get("colspan", 1))

            # Skip first column
            if i == 0:
                continue

            # Skip columns after last column
            if i > (last_column + 1):
                continue

            # Check for period information
            matching_terms = [term for term in self.PERIOD_TERMS if term in text_lower]
            is_period_cell = len(matching_terms) > 0

            if is_period_cell:
                found = True

            # Add to result columns (expanding colspan)
            for index, _ in enumerate(range(colspan)):
                period_columns.append({"text": text, "index": i + index - 1})

        if found:
            # Guard: reject merged title rows where all non-empty data
            # cells have the same text as cell 0 (a table caption
            # spanning all columns, not an epoch row).
            data_texts = {col["text"] for col in period_columns if col["text"]}
            if len(data_texts) == 1:
                first_cell_text = cells[0].get_text(strip=True) if cells else ""
                if first_cell_text == next(iter(data_texts)):
                    return results  # found stays False
            results["found"] = True
            results["items"] = period_columns
            results["row"] = row_index + 1
        return results


def synthesise_default_epoch(epochs_result: dict, timepoints_result: dict) -> dict:
    """Synthesise a default epoch when none was found.

    When the SoA table has no epoch row (or epoch extraction failed),
    the assembler cannot build a schedule timeline because it requires
    at least one epoch.  This function creates a single "Study Period"
    epoch that spans all timepoint columns, allowing the pipeline to
    continue.

    Args:
        epochs_result: The result dict from ``EpochsFeature.process()``.
        timepoints_result: The result dict from ``TimepointsFeature.process()``.

    Returns:
        The *epochs_result* dict — either unchanged (if epochs were
        already found) or updated with a synthesised default epoch.
    """
    if epochs_result.get("found") and epochs_result.get("items"):
        return epochs_result

    if not timepoints_result:
        return epochs_result

    tp_items = timepoints_result.get("items", [])
    if not tp_items:
        return epochs_result

    # Create one epoch item per timepoint column, all with the same label
    default_items = [{"text": "Study Period", "index": item["index"]} for item in tp_items]
    epochs_result["found"] = True
    epochs_result["items"] = default_items
    epochs_result["type"] = "unknown"
    return epochs_result
