from simple_error_log import Errors
from simple_error_log.error_location import KlassMethodLocation
from usdm4_protocol.common.html.expand_table import expand_table


class ActivityRowFeature:
    """Extract first and last activity row indices from SoA table."""

    MODULE = "usdm4_protocol.soa.features.activity_row.ActivityRowFeature"

    def __init__(self, errors: Errors):
        self._errors = errors

    def process(self, html_content, ignore_last: bool = False):
        """
        Enhanced version that provides detailed analysis of the table structure.

        Args:
            html_content (str): HTML content containing table structure
            ignore_last (bool): Whether to ignore the last column

        Returns:
            dict: Analysis results including first_activity_row, last_activity_row, total_rows
        """
        table = expand_table(html_content)
        if not table:
            self._errors.error("No table detected", KlassMethodLocation(self.MODULE, "process"))
            return {"first_activity_row": -1, "total_rows": 0}
        rows = table.find_all("tr")
        result = {
            "first_activity_row": -1,
            "last_activity_row": -1,
            "total_rows": len(rows),
        }

        for row_index, row in enumerate(rows):
            cells = row.find_all(["td", "th"])
            if ignore_last:
                cells = cells[:-1]
            cell_contents = [cell.get_text(strip=True) for cell in cells]

            # Check for "X" cells — require at least 2 to avoid false positives
            # from single-cell matches in header rows
            x_cells = [content for content in cell_contents if content.upper() == "X"]
            has_x = len(x_cells) >= 2

            # Single X is accepted if the row has at least one other non-empty cell
            # (i.e. has a label in the first column + one X mark = activity row)
            if not has_x and len(x_cells) == 1:
                non_empty = [c for c in cell_contents if c.strip()]
                has_x = len(non_empty) >= 2

            # Check for a merged line, every cell will be the same AND non-empty
            merged_row = (
                len(cell_contents) >= 2
                and cell_contents[0].strip()
                and all(x == cell_contents[0] for x in cell_contents)
            )

            # Check for an "all cells" line, every cell will be the same from
            # second column to the end — but only if those cells are non-empty
            # and the first column differs (a label + repeated content pattern)
            all_row = (
                len(cell_contents) >= 3
                and cell_contents[1].strip()
                and cell_contents[0] != cell_contents[1]
                and all(x == cell_contents[1] for x in cell_contents[1:])
            )

            # Set first_activity_row if not already set
            if result["first_activity_row"] == -1 and (has_x or merged_row or all_row):
                result["first_activity_row"] = row_index
            if has_x or merged_row or all_row:
                result["last_activity_row"] = row_index

        self._errors.info(
            f"Activity Row: {result}",
            KlassMethodLocation(self.MODULE, "process"),
        )
        return result
