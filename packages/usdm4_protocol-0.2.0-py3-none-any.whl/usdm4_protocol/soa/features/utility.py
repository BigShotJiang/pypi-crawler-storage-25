import re


def cell_text(cell) -> str:
    """
    Extract clean text from a table cell, removing anchors, spans, sups,
    and plain-text footnote markers.

    Args:
        cell: BeautifulSoup cell element

    Returns:
        Clean text content from the cell
    """
    for anchor in cell.findAll("a"):
        anchor.replaceWith("")
    for anchor in cell.findAll("span"):
        anchor.replaceWith("")
    for sup in cell.findAll("sup"):
        sup.replaceWith("")
    text = clean_text(cell.get_text(separator=" ", strip=True))
    text = text.replace(" ,", "")  # Fix space comma, indicates a reference followed by comma was present
    # Strip trailing asterisk markers (plain-text footnote refs from PyMuPDF)
    text = re.sub(r"\*+\s*$", "", text).strip()
    return text


def cell_references(cell) -> list[str]:
    """
    Extract reference IDs from a table cell.

    Looks for footnote markers in three element types:
    - <span id="..."> — DOCX-origin anchor spans
    - <a href="#..."> — anchor links to footnotes
    - <sup>a</sup> — superscript footnote markers (common in PyMuPDF output)

    Reference IDs are normalised: stripped, lowercased, and '#' prefix removed.
    Duplicates are preserved (a cell may reference the same footnote twice).

    Args:
        cell: BeautifulSoup cell element

    Returns:
        List of reference ID strings found in the cell
    """
    result = []

    # 1. <span id="..."> elements (DOCX-origin)
    for span in cell.findAll("span"):
        span_id = span.get("id", "").strip()
        if span_id:
            result.append(_normalise_ref(span_id))

    # 2. <a href="#..."> elements (anchor links)
    for anchor in cell.findAll("a"):
        href = anchor.get("href", "").strip()
        if href.startswith("#"):
            result.append(_normalise_ref(href))

    # 3. <sup> elements (superscript markers from PyMuPDF)
    for sup in cell.findAll("sup"):
        text = sup.get_text(strip=True)
        if text:
            # Split on commas for multi-reference sups: <sup>a,b</sup>
            for marker in re.split(r"[,;\s]+", text):
                marker = marker.strip()
                if marker and _is_footnote_marker(marker):
                    result.append(_normalise_ref(marker))

    # 4. Plain-text fallback: detect footnote markers in cells without
    #    HTML markup. PyMuPDF extracts superscripts as plain text, so
    #    "X" cells may appear as "Xf" or "X*" and names as "Visit*".
    if not result:
        plain_refs = _extract_plain_text_refs(cell)
        result.extend(plain_refs)

    return result


def _normalise_ref(ref: str) -> str:
    """Normalise a reference ID for matching.

    Strips leading '#', whitespace, and lowercases. This ensures
    references from different sources (span id, anchor href, sup text)
    can be matched against each other and against condition references.
    """
    ref = ref.strip().lstrip("#").strip().lower()
    return ref


def _extract_plain_text_refs(cell) -> list[str]:
    """Extract footnote markers from plain text in a cell.

    Handles PyMuPDF output where superscript markers are extracted as
    plain text appended to cell content. Detects:

    - Trailing asterisks: ``"Visit*"`` → ``"*"``
    - Single-letter markers after X: ``"Xf"`` → ``"f"``, ``"Xa"`` → ``"a"``
    - Trailing single-letter markers after whitespace/newline: common when
      PyMuPDF puts a superscript on its own line (``"CTCAE\\nf\\nGrading"``)

    Conservative: only extracts markers in patterns that are unambiguous.
    Activity names with trailing letters (e.g. ``"Hematologya"``) are NOT
    matched because the trailing letter could be part of the word.

    Args:
        cell: BeautifulSoup cell element

    Returns:
        List of normalised reference IDs
    """
    text = cell.get_text(separator="\n", strip=True)
    if not text:
        return []

    refs = []

    # Pattern 1: Trailing asterisk(s) — unambiguous footnote marker
    # Matches "Visit*", "Visit**", "X*"
    m = re.search(r"(\*+)\s*$", text)
    if m:
        refs.append(_normalise_ref("*"))
        return refs

    # Pattern 2: X + single letter — "Xf", "Xa", "X a"
    # The cell is a visit marker with an attached footnote ref
    stripped = re.sub(r"\s+", "", text)  # Remove all whitespace
    if re.match(r"^[Xx]([a-z])$", stripped):
        refs.append(_normalise_ref(stripped[-1]))
        return refs

    # Pattern 3: X + symbol marker — "X†", "X‡"
    if re.match(r"^[Xx]([†‡§¶])$", stripped):
        refs.append(_normalise_ref(stripped[-1]))
        return refs

    return refs


def _is_footnote_marker(text: str) -> bool:
    """Check if text looks like a footnote marker.

    Accepts: single letters (a-z), single/double digits (1-99),
    asterisks (*), daggers (†, ‡), or common combinations.
    """
    if re.match(r"^[a-z]$", text, re.IGNORECASE):
        return True
    if re.match(r"^\d{1,2}$", text):
        return True
    if text in ("*", "**", "†", "‡", "§", "||", "¶"):
        return True
    return False


def clean_text(text: str) -> str:
    """
    Clean and normalize text content.

    Args:
        text: Text to clean

    Returns:
        Cleaned text
    """
    text = text.replace("\u00a0", " ")  # &nbsp;
    text = text.replace("±", "±")  # Fix encoding issues
    text = text.replace("−", "-")  # Fix minus signs
    text = " ".join(text.split())  # Normalize whitespace
    return text
