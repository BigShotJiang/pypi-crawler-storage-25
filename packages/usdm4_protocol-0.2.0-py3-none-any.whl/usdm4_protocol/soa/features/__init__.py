# SoA feature extraction utilities
