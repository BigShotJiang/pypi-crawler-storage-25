import re
import unicodedata
from simple_error_log import Errors
from simple_error_log.error_location import KlassMethodLocation
from usdm4_protocol.common.html.expand_table import expand_table


class RowClassifier:
    """Non-AI row classification using combined heuristics.

    Performs a single pass over header rows, scoring each row against all
    known types simultaneously. Assigns the best non-conflicting classification
    so that each row gets at most one type and each type is used at most once.

    Row types: epoch, visit, timepoint, window, activity_header, other.
    """

    MODULE = "usdm4_protocol.soa.features.row_classifier.RowClassifier"

    PERIOD_TERMS = [
        "screening",
        "scn",
        "treatment",
        "follow-up",
        "follow up",
        "baseline",
        "washout",
        "run-in",
        "eos",
        "end of study",
        "edv",
        "early discontinuation",
    ]

    def __init__(self, errors: Errors):
        self._errors = errors

    def classify_rows(self, html_content: str, max_rows: int) -> dict[int, str]:
        """Classify header rows by type using combined evidence.

        Args:
            html_content: HTML string containing the expanded SoA table.
            max_rows: Maximum number of rows to analyze (typically first_activity_row + 1).

        Returns:
            dict mapping row_index (0-based) → row_type string.
        """
        try:
            table = expand_table(html_content)
            if not table:
                return {}

            rows = table.find_all("tr")
            if not rows:
                return {}

            num_rows = min(max_rows, len(rows))
            if num_rows == 0:
                return {}

            # Score each row for each type
            scores: list[dict[str, float]] = []
            for i in range(num_rows):
                row = rows[i]
                cells = row.find_all(["td", "th"])
                row_scores = {
                    "epoch": self._score_epoch(cells),
                    "visit": self._score_visit(cells),
                    "timepoint": self._score_timepoint(cells),
                    "window": self._score_window(cells),
                    "activity_header": self._score_activity_header(cells),
                }
                scores.append(row_scores)

            # Greedy assignment: assign types in priority order to the
            # highest-scoring row. Each type and row used at most once.
            # Priority: epoch first (usually row 0), then visit, timepoint, window.
            classification: dict[int, str] = {}
            assigned_rows: set[int] = set()
            assigned_types: set[str] = set()

            priority_types = ["epoch", "visit", "timepoint", "window", "activity_header"]
            for row_type in priority_types:
                best_row = -1
                best_score = 0
                for i in range(num_rows):
                    if i in assigned_rows:
                        continue
                    s = scores[i][row_type]
                    if s > best_score:
                        best_score = s
                        best_row = i
                if best_row >= 0 and best_score > 0:
                    classification[best_row] = row_type
                    assigned_rows.add(best_row)
                    assigned_types.add(row_type)

            self._errors.info(
                f"Row classification: {classification}",
                KlassMethodLocation(self.MODULE, "classify_rows"),
            )
            return classification
        except Exception as e:
            self._errors.exception(
                "Exception raised classifying rows",
                e,
                KlassMethodLocation(self.MODULE, "classify_rows"),
            )
            return {}

    # --- Scoring functions ---

    def _score_epoch(self, cells) -> float:
        """Score a row's likelihood of being an epoch row."""
        if not cells:
            return 0

        score = 0.0
        text_cells = [self._clean(c.get_text()) for c in cells]

        # Reject merged title rows: a table title/caption spans all
        # columns (including cell 0) with identical text.  After
        # expand_table, every cell contains the same title string.
        # Period terms in the title ("Screening and Treatment Period")
        # would otherwise cause a false-positive epoch match.
        # A real single-epoch row has a different cell 0 (e.g. "Period")
        # or an empty cell 0, so we only reject when cell 0 matches.
        data_texts = [t for t in text_cells[1:] if t.strip()]
        if data_texts and len(set(data_texts)) == 1:
            first = text_cells[0].strip() if text_cells else ""
            if first == data_texts[0]:
                return 0

        # Epoch rows typically have period terms across multiple cells
        period_matches = 0
        for text in text_cells[1:]:  # skip first column
            text_lower = text.lower()
            if any(term in text_lower for term in self.PERIOD_TERMS):
                period_matches += 1

        if period_matches == 0:
            return 0

        score += period_matches * 10

        # Bonus if first column is empty or says "epoch"/"period"/"study period"
        first_lower = text_cells[0].lower() if text_cells else ""
        if any(w in first_lower for w in ["epoch", "period", "study period", "phase"]):
            score += 5
        elif not first_lower.strip():
            score += 2

        # Epoch rows often have colspan (before expand_table). After expansion,
        # many consecutive cells will have the same text.
        if len(text_cells) > 2:
            same_count = sum(
                1 for i in range(2, len(text_cells)) if text_cells[i] == text_cells[i - 1] and text_cells[i].strip()
            )
            if same_count > 0:
                score += same_count * 2

        return score

    def _score_visit(self, cells) -> float:
        """Score a row's likelihood of being a visit row."""
        if not cells:
            return 0

        score = 0.0
        text_cells = [self._clean(c.get_text()) for c in cells]
        first_lower = text_cells[0].lower() if text_cells else ""

        # First column indicator
        if any(w in first_lower for w in ["visit", "study visit"]):
            score += 10

        # Visit patterns in data cells
        visit_patterns = [
            (15, r"^(SCN|SCR)\b"),
            (10, r"^(BL)\b"),
            (10, r"^(EoS|EDV|ET)\b"),
            (15, r"^V\d+"),
            (10, r"^Visit\s*\d+"),
            (5, r"^W\d+"),
            (5, r"^Day\s*-?\d+"),
        ]

        for text in text_cells[1:]:
            text_stripped = text.strip()
            if not text_stripped:
                continue
            for weight, pattern in visit_patterns:
                if re.match(pattern, text_stripped, re.IGNORECASE):
                    score += weight
                    break

        return score

    def _score_timepoint(self, cells) -> float:
        """Score a row's likelihood of being a timepoint/timing row."""
        if not cells or len(cells) < 2:
            return 0

        score = 0.0
        text_cells = [self._clean(c.get_text()) for c in cells]
        first_lower = text_cells[0].lower() if text_cells else ""

        # First column indicators
        if any(w in first_lower for w in ["day", "week", "study day", "target day"]):
            score += 10

        # Skip if row has colspan/rowspan (pre-expansion markers)
        if any(c.get("colspan") or c.get("rowspan") for c in cells):
            return 0

        # Check data cells for numeric timing patterns
        numeric_values = []
        valid_count = 0
        countable = 0
        remaining = text_cells[1:]

        for text in remaining:
            text_stripped = text.strip()
            if not text_stripped:
                continue
            # Skip CCI-redacted cells
            if text_stripped.upper() in ["CCI"]:
                continue

            countable += 1

            if text_stripped.lower() in ["na", "n/a", "-", "et"]:
                valid_count += 1
                continue

            # Remove parenthetical windows e.g. (±3)
            cleaned = re.sub(r"\([±+\-]?\d+\)", "", text_stripped).strip()
            # Remove non-parenthetical ± tolerance: "120 ± 2" → "120"
            cleaned = re.sub(r"\s*[±]\s*\d+", "", cleaned).strip()

            # Bare number
            m = re.match(r"^-?\d+$", cleaned)
            if m:
                numeric_values.append(int(m.group()))
                valid_count += 1
                continue

            # Range: "-28 ~ -17" or "1 – 15"
            m = re.match(r"^(-?\d+)\s*[~–—]\s*-?\d+$", cleaned)
            if m:
                numeric_values.append(int(m.group(1)))
                valid_count += 1
                continue

            # Inequality: "≤28", ">=14"
            m = re.match(r"^[≤≥<>]=?\s*(-?\d+)$", cleaned)
            if m:
                numeric_values.append(int(m.group(1)))
                valid_count += 1
                continue

            # D<n> or Day <n>
            m = re.match(r"^(D|Day\s*)(-?\d+)", cleaned, re.IGNORECASE)
            if m:
                numeric_values.append(int(m.group(2)))
                valid_count += 1
                continue

            # V<n> D<n>
            m = re.match(r"^V\d+\w*\/?\w*\s*D(\d+)", cleaned, re.IGNORECASE)
            if m:
                numeric_values.append(int(m.group(1)))
                valid_count += 1
                continue

        if countable > 0 and valid_count >= countable * 0.4:
            score += valid_count * 3

        # Segment-aware monotonicity bonus
        if len(numeric_values) >= 2:
            score += 5  # bonus for having numeric sequence

        return score

    def _score_window(self, cells) -> float:
        """Score a row's likelihood of being a window row."""
        if not cells:
            return 0

        score = 0.0
        text_cells = [self._clean(c.get_text()) for c in cells]
        first_lower = text_cells[0].lower() if text_cells else ""

        # First column indicator
        if "window" in first_lower:
            score += 15
        if "study day window" in first_lower:
            score += 5

        # ± patterns in data cells
        window_count = 0
        for text in text_cells[1:]:
            if re.search(r"[±]\s*\d+", text):
                window_count += 1
            elif re.search(r"[+\-]\s*\d+", text) and not re.match(r"^-?\d+$", text.strip()):
                window_count += 1

        score += window_count * 5
        return score

    def _score_activity_header(self, cells) -> float:
        """Score a row's likelihood of being an activity header (merged/parent row)."""
        if not cells:
            return 0

        text_cells = [self._clean(c.get_text()) for c in cells]

        # All cells identical = merged row (parent activity heading)
        if len(text_cells) >= 2 and all(t == text_cells[0] for t in text_cells):
            # But not if it contains X markers
            if text_cells[0].strip().upper() != "X":
                return 10
        return 0

    def _clean(self, text: str) -> str:
        """Normalize text for comparison."""
        if not text:
            return ""
        text = unicodedata.normalize("NFKD", text)
        text = re.sub(r"\s+", " ", text).strip()
        return text
