from raw_docx.raw_docx import RawDocx, RawParagraph, RawSection
from simple_error_log.errors import Errors
from simple_error_log.error_location import KlassMethodLocation
from usdm4_protocol.soa.decode_soa import decode_soa, init_row_classifier


class SoA:
    """Extract Schedule of Activities from a document."""

    MODULE = "usdm4_protocol.soa.soa_extractor.SoA"

    def __init__(self, raw_docx: RawDocx, errors: Errors, use_ai: bool = False, ai=None):
        """
        Initialize SoA extractor.

        Args:
            raw_docx: RawDocx object
            errors: Error logging object
            use_ai: Whether to use AI for row classification.
                Ignored when ``ai`` is provided.
            ai: Pre-configured AI provider.  When provided, ``use_ai``
                is ignored.
        """
        self._raw_docx = raw_docx
        self._errors = errors
        self._use_ai = use_ai
        self._ai = ai
        self._row_classifier = None

    def process(self, assessments: dict) -> dict | None:
        """
        Process and extract SoA from the document.

        Args:
            assessments: Dictionary of assessments

        Returns:
            Dictionary with SoA extraction results, or None if extraction fails
        """
        try:
            self._assessments = assessments

            # Initialise combined row classifier
            self._row_classifier = self._init_row_classifier()

            section = self._raw_docx.target_document.section_by_title("Schedule of Activities")
            if section:
                raw_result = self._decode_soa(section)
            else:
                self._errors.error(
                    "Failed to find the SoA section in the document",
                    KlassMethodLocation(self.MODULE, "process"),
                )
                raw_result = None
            return raw_result
        except Exception as e:
            self._errors.exception("Error processing SoA", e, KlassMethodLocation(self.MODULE, "process"))
            return None

    def _init_row_classifier(self):
        """Create the combined AI + heuristic row classifier."""
        return init_row_classifier(self._errors, self._use_ai, ai=self._ai)

    def _decode_soa(self, section: RawSection) -> dict | None:
        """
        Decode the SoA from a section.

        Args:
            section: RawSection object containing SoA table

        Returns:
            Dictionary with all extracted SoA features, or None
        """
        if soa_tables := section.tables():
            html = soa_tables[0].to_html()
            soa_index = section.index(soa_tables[0])
            footnote_html = self._extract_footnotes(section, soa_index)
            return decode_soa(
                table_html=html,
                footnote_html=footnote_html,
                assessments=self._assessments,
                errors=self._errors,
                row_classifier=self._row_classifier,
            )
        else:
            self._errors.error("No SoA found", KlassMethodLocation(self.MODULE, "_decode_soa"))
            return None

    def _extract_footnotes(self, section: RawSection, soa_index: int) -> str:
        """
        Extract footnotes/conditions following the SoA table.

        Args:
            section: RawSection object
            soa_index: Index of the SoA table in the section

        Returns:
            HTML text of the footnotes
        """
        items = section.items_between(soa_index + 1, len(section.items))
        text = ""
        for item in items:
            if isinstance(item, RawParagraph):
                text += item.to_html()
            else:
                break
        return text
