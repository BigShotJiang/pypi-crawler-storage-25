"""Shared SoA decoding pipeline.

Once format-specific code has located the SoA table and extracted its HTML,
all formats share the same feature-extraction pipeline.  This module provides
that pipeline as a single function so both the M11/DOCX and Legacy/PDF
orchestrators delegate here rather than duplicating the logic.
"""

from collections import Counter

from bs4 import BeautifulSoup
from simple_error_log.errors import Errors
from simple_error_log.error_location import KlassMethodLocation
from usdm4_protocol.common.extract.combined_row_classifier import CombinedRowClassifier
from usdm4_protocol.soa.features.activity_row import ActivityRowFeature
from usdm4_protocol.soa.features.notes import NotesFeature
from usdm4_protocol.soa.features.epochs import EpochsFeature
from usdm4_protocol.soa.features.visits import VisitsFeature
from usdm4_protocol.soa.features.timepoints import TimepointsFeature
from usdm4_protocol.soa.features.windows import WindowsFeature
from usdm4_protocol.soa.features.activities import ActivitiesFeature
from usdm4_protocol.soa.features.conditions import ConditionsFeature

MODULE = "usdm4_protocol.soa.decode_soa"


def init_row_classifier(errors: Errors, use_ai: bool = False, ai=None) -> CombinedRowClassifier:
    """Create the combined AI + heuristic row classifier.

    Shared by both the M11/DOCX and Legacy/PDF orchestrators so the
    initialisation logic is not duplicated.

    Args:
        errors: Shared error-logging instance.
        use_ai: Whether to attempt loading the AI provider.
            Ignored when ``ai`` is provided.
        ai: Pre-configured AI provider.  When provided, ``use_ai`` is
            ignored and this provider is used directly (if available).

    Returns:
        A ready-to-use ``CombinedRowClassifier``.
    """
    if ai is not None:
        # Use the pre-configured provider if it's available
        provider_ai = ai if ai.available else None
        return CombinedRowClassifier(errors, ai=provider_ai)

    provider_ai = None
    if use_ai:
        try:
            from usdm4_protocol.common.ai.claude_provider import ClaudeProvider

            provider = ClaudeProvider(errors)
            if provider.available:
                provider_ai = provider
        except Exception as e:
            errors.warning(
                f"AI provider not available: {e}",
                KlassMethodLocation(MODULE, "init_row_classifier"),
            )
    return CombinedRowClassifier(errors, ai=provider_ai)


def decode_soa(
    table_html: str,
    footnote_html: str,
    assessments: dict,
    errors: Errors,
    row_classifier: CombinedRowClassifier,
) -> dict:
    """Run the SoA feature-extraction pipeline on a single table.

    This is the **single implementation** of the decode pipeline used by both
    the M11/DOCX orchestrator (``SoA``) and the Legacy/PDF orchestrator
    (``ScheduleOfActivities``).  Callers are responsible for locating the
    table and extracting its HTML; this function handles everything from
    activity-row detection through conditions extraction.

    Args:
        table_html: HTML string containing the SoA ``<table>`` element.
        footnote_html: HTML string with footnote/condition paragraphs
            following the table.  May be empty.
        assessments: Assessment dictionary passed to ``ActivitiesFeature``.
            M11 provides the real assessments dict; Legacy passes ``{}``.
        errors: Shared error-logging instance.
        row_classifier: Pre-initialised ``CombinedRowClassifier``.

    Returns:
        Dictionary keyed by feature name (``activity_row``, ``notes``,
        ``timepoints``, ``epochs``, ``visits``, ``windows``, ``activities``,
        ``conditions``).
    """
    result: dict = {}

    # 1. Activity-row detection
    result["activity_row"] = ActivityRowFeature(errors).process(table_html)
    activity_row = result["activity_row"]["first_activity_row"]
    if activity_row < 0:
        # No X-marks found — use total rows (capped) as header range
        soup = BeautifulSoup(table_html, "html.parser")
        total_rows = len(soup.find_all("tr"))
        last_header_row = min(total_rows, 10)
        errors.info(
            f"No activity rows detected, using last_header_row={last_header_row}",
            KlassMethodLocation(MODULE, "decode_soa"),
        )
    else:
        last_header_row = activity_row + 1

    # 2. Notes detection
    result["notes"] = NotesFeature(errors).process(table_html)
    ignore_last = result["notes"]["has_references"]

    # 3. Row classification
    classification = row_classifier.classify(table_html, last_header_row)
    hints = row_classifier.get_hints(classification)

    # 4. Visits (before timepoints — timepoint synthesis needs visits)
    result["visits"] = VisitsFeature(errors).process(table_html, last_header_row, 999, row_hint=hints["visit"])

    # 5. Timepoints (with visit-based synthesis fallback)
    result["timepoints"] = TimepointsFeature(errors).process(
        table_html,
        last_header_row,
        ignore_last,
        row_hint=hints["timepoint"],
        visits_result=result["visits"],
    )
    last_column = _check_timepoints(result["timepoints"])

    # Trim visits to last_column now that we know it
    if result["visits"].get("items"):
        result["visits"]["items"] = result["visits"]["items"][: last_column + 1]

    # 6. Timepoint unit for window inheritance
    timepoint_unit = _get_timepoint_unit(result["timepoints"])

    # 7. Epochs (with default-epoch synthesis fallback)
    result["epochs"] = EpochsFeature(errors).process(
        table_html,
        last_column,
        max_rows=last_header_row,
        row_hint=hints["epoch"],
        timepoints_result=result["timepoints"],
    )

    # 8. Windows
    result["windows"] = WindowsFeature(errors).process(
        table_html,
        last_header_row,
        last_column,
        row_hint=hints["window"],
        timepoint_unit=timepoint_unit,
    )

    # 9. Activities
    result["activities"] = ActivitiesFeature(errors).process(
        table_html,
        assessments,
        activity_row,
        last_column,
    )

    # 10. Conditions
    result["conditions"] = ConditionsFeature(errors).process(footnote_html)

    # 11. Link footnote references between activities and conditions
    _link_footnotes(result, errors)

    return result


# ---------------------------------------------------------------------------
# Helper functions (previously duplicated in both orchestrators)
# ---------------------------------------------------------------------------


def _check_timepoints(result: dict) -> int:
    """Check and clean timepoints, removing trailing empty ones.

    Skips trimming when timepoints are synthetic (all values are
    placeholders) to avoid stripping the entire spine.

    Returns:
        Index of last valid timepoint column.
    """
    if result.get("synthetic"):
        return len(result["items"]) - 1
    index = len(result["items"]) - 1
    for item in reversed(result["items"]):
        if item["value"] > 0:
            break
        index -= 1
    if index >= 0:
        result["items"] = result["items"][: index + 1]
        return index
    return len(result["items"]) - 1


def _get_timepoint_unit(timepoints_result: dict) -> str:
    """Extract the predominant time unit from timepoints result."""
    items = timepoints_result.get("items", [])
    if not items:
        return "day"
    units = [item.get("unit", "") for item in items if item.get("unit")]
    if not units:
        return "day"
    return Counter(units).most_common(1)[0][0]


def _link_footnotes(result: dict, errors: Errors) -> None:
    """Link footnote references between activities and conditions.

    Builds a lookup from condition reference IDs to condition text,
    then walks through each activity's visits and the activity itself,
    matching reference IDs to condition text. Adds a ``conditions``
    list to each visit dict and a ``linked_conditions`` list to each
    activity/child dict.

    Modifies ``result`` in place.

    Args:
        result: The full SoA result dict (must contain "activities" and
            "conditions" keys).
        errors: Error-logging instance.
    """
    activities = result.get("activities", {})
    conditions = result.get("conditions", {})

    if not activities.get("found") or not conditions.get("items"):
        return

    # Build reference → condition text lookup
    # A reference may map to multiple conditions (rare but possible)
    ref_to_conditions: dict[str, list[str]] = {}
    for item in conditions["items"]:
        for ref in item.get("references", []):
            if ref:
                ref_to_conditions.setdefault(ref, []).append(item["text"])
        # Also index by the primary "reference" for backward compatibility
        primary = item.get("reference", "")
        if primary and primary not in ref_to_conditions:
            ref_to_conditions.setdefault(primary, []).append(item["text"])

    if not ref_to_conditions:
        return

    linked_count = 0

    for activity in activities.get("items", []):
        # Process activity itself + its children
        all_items = [activity] + activity.get("children", [])
        for item in all_items:
            # Link activity-level references
            activity_refs = item.get("references", [])
            if activity_refs:
                matched = _match_refs(activity_refs, ref_to_conditions)
                if matched:
                    item["linked_conditions"] = matched
                    linked_count += len(matched)

            # Link per-visit references
            for visit in item.get("visits", []):
                visit_refs = visit.get("references", [])
                if visit_refs:
                    matched = _match_refs(visit_refs, ref_to_conditions)
                    if matched:
                        visit["conditions"] = matched
                        linked_count += len(matched)

    if linked_count > 0:
        errors.info(
            f"Linked {linked_count} footnote references to activities",
            KlassMethodLocation(MODULE, "_link_footnotes"),
        )
    else:
        errors.info(
            f"No footnote references matched ({len(ref_to_conditions)} conditions, "
            f"{len(activities.get('items', []))} activities)",
            KlassMethodLocation(MODULE, "_link_footnotes"),
        )


def _match_refs(refs: list[str], ref_to_conditions: dict[str, list[str]]) -> list[str]:
    """Match a list of reference IDs against the conditions lookup.

    Args:
        refs: List of reference IDs from a cell or activity.
        ref_to_conditions: Lookup dict mapping ref ID → list of condition texts.

    Returns:
        Flat list of matched condition texts (deduplicated, order-preserving).
    """
    matched = []
    seen = set()
    for ref in refs:
        ref_normalised = ref.strip().lower().lstrip("#")
        for text in ref_to_conditions.get(ref_normalised, []):
            if text not in seen:
                matched.append(text)
                seen.add(text)
    return matched
