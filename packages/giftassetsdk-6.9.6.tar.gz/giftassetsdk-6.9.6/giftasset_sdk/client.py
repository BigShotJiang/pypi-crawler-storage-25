﻿from __future__ import annotations

import asyncio
from dataclasses import dataclass
from typing import Any, Awaitable, Callable, Dict, Optional
from urllib.parse import quote

import aiohttp


class SDKError(Exception):
    """Base SDK error."""


class SDKNotInitializedError(SDKError):
    """Raised when SDK initialization fails."""


class SDKMethodNotFoundError(SDKError):
    """Raised when requested method is not found in OpenAPI."""


@dataclass(slots=True)
class EndpointSpec:
    method_name: str
    http_method: str
    path: str
    summary: str
    parameters: list[dict[str, Any]]
    has_request_body: bool
    request_body_required: bool


class SDK:
    """Dynamic GiftAsset SDK.

    It loads openapi.json and builds an in-memory method map.
    Methods are available as async callables by endpoint name, e.g.:
    await client.get_gift_by_name(name="EasterEgg-1")
    """

    def __init__(
        self,
        api_key: str,
        base_url: str = "https://giftasset.gifts",
        openapi_path: str = "/openapi.json",
        timeout_seconds: int = 60,
    ) -> None:
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.openapi_url = f"{self.base_url}{openapi_path}"
        self.timeout_seconds = timeout_seconds

        self._session: Optional[aiohttp.ClientSession] = None
        self._methods: Dict[str, EndpointSpec] = {}
        self._openapi_raw: dict[str, Any] = {}
        self._initialized = False
        self._init_lock = asyncio.Lock()

    async def initialize(self, force: bool = False) -> None:
        if self._initialized and not force:
            return

        async with self._init_lock:
            if self._initialized and not force:
                return
            await self._load_openapi()

    async def close(self) -> None:
        if self._session and not self._session.closed:
            await self._session.close()

    async def __aenter__(self) -> "SDK":
        await self.initialize()
        return self

    async def __aexit__(self, exc_type, exc, tb) -> None:
        await self.close()

    def list_methods(self) -> list[str]:
        return sorted(self._methods.keys())

    def get_endpoint_spec(self, method_name: str) -> EndpointSpec:
        spec = self._methods.get(method_name)
        if not spec:
            raise SDKMethodNotFoundError(
                f"Method '{method_name}' not found. Run initialize() and check list_methods()."
            )
        return spec

    async def call(self, method_name: str, **kwargs: Any) -> Any:
        await self._ensure_initialized()

        spec = self._methods.get(method_name)
        if not spec:
            available = ", ".join(self.list_methods()[:15])
            raise SDKMethodNotFoundError(
                f"Method '{method_name}' not found in OpenAPI. Available: {available}"
            )

        url = self._build_url(spec.path, kwargs)
        query, body, unused = self._extract_payload(spec, kwargs)
        if unused:
            raise SDKError(f"Unexpected arguments for '{method_name}': {sorted(unused)}")

        return await self._request(spec.http_method, url, query=query, json_body=body)

    def __getattr__(self, name: str) -> Callable[..., Awaitable[Any]]:
        if name.startswith("_"):
            raise AttributeError(name)

        async def dynamic_method(**kwargs: Any) -> Any:
            return await self.call(name, **kwargs)

        dynamic_method.__name__ = name
        dynamic_method.__doc__ = f"Dynamic SDK method for '{name}'."
        return dynamic_method

    async def _ensure_initialized(self) -> None:
        if not self._initialized:
            await self.initialize()
        if not self._initialized:
            raise SDKNotInitializedError("SDK could not initialize from OpenAPI")

    async def _load_openapi(self) -> None:
        data = await self._request("GET", self.openapi_url, query=None, json_body=None)
        if not isinstance(data, dict) or "paths" not in data:
            raise SDKNotInitializedError("Invalid OpenAPI schema received")

        self._openapi_raw = data
        self._methods = self._build_method_map(data)
        self._initialized = True

    def _build_method_map(self, schema: dict[str, Any]) -> dict[str, EndpointSpec]:
        result: dict[str, EndpointSpec] = {}
        paths = schema.get("paths", {})

        for path, path_item in paths.items():
            if not isinstance(path_item, dict):
                continue

            for http_method, operation in path_item.items():
                m = str(http_method).lower()
                if m not in {"get", "post", "put", "patch", "delete", "head", "options"}:
                    continue
                if not isinstance(operation, dict):
                    continue

                method_name = self._pick_method_name(path, m, operation, result)
                spec = EndpointSpec(
                    method_name=method_name,
                    http_method=m.upper(),
                    path=path,
                    summary=str(operation.get("summary", "")).strip(),
                    parameters=list(operation.get("parameters", [])),
                    has_request_body="requestBody" in operation,
                    request_body_required=bool(operation.get("requestBody", {}).get("required", False)),
                )
                result[method_name] = spec

        return result

    def _pick_method_name(
        self,
        path: str,
        http_method: str,
        operation: dict[str, Any],
        existing: dict[str, EndpointSpec],
    ) -> str:
        operation_id = operation.get("operationId")
        if isinstance(operation_id, str) and operation_id.strip():
            base = self._sanitize_name(operation_id)
            if base and base not in existing:
                return base

        pieces = [
            p for p in path.strip("/").split("/")
            if p and not (p.startswith("{") and p.endswith("}"))
        ]
        base = self._sanitize_name(pieces[-1]) if pieces else "endpoint"
        if not base:
            base = "endpoint"

        if base not in existing:
            return base

        fallback = f"{base}_{http_method}"
        if fallback not in existing:
            return fallback

        i = 2
        while f"{fallback}_{i}" in existing:
            i += 1
        return f"{fallback}_{i}"

    @staticmethod
    def _sanitize_name(name: str) -> str:
        allowed = []
        for ch in name.strip():
            if ch.isalnum() or ch == "_":
                allowed.append(ch.lower())
            else:
                allowed.append("_")
        cleaned = "".join(allowed).strip("_")
        while "__" in cleaned:
            cleaned = cleaned.replace("__", "_")
        return cleaned

    def _build_url(self, path: str, kwargs: dict[str, Any]) -> str:
        url = path
        for key, value in list(kwargs.items()):
            token = f"{{{key}}}"
            if token in url:
                if value is None:
                    raise SDKError(f"Path parameter '{key}' cannot be None")
                url = url.replace(token, quote(str(value), safe=""))
        return f"{self.base_url}{url}"

    def _extract_payload(
        self,
        spec: EndpointSpec,
        kwargs: dict[str, Any],
    ) -> tuple[dict[str, Any], Optional[dict[str, Any]], set[str]]:
        query: dict[str, Any] = {}
        used: set[str] = set()

        for p in spec.parameters:
            name = p.get("name")
            location = p.get("in")
            required = bool(p.get("required", False))
            if not isinstance(name, str):
                continue

            if location == "path":
                if required and name not in kwargs:
                    raise SDKError(f"Missing required path parameter '{name}'")
                if name in kwargs:
                    used.add(name)
            elif location == "query":
                if required and name not in kwargs:
                    raise SDKError(f"Missing required query parameter '{name}'")
                if name in kwargs:
                    query[name] = kwargs[name]
                    used.add(name)
            elif location == "header":
                if name in kwargs:
                    used.add(name)

        body: Optional[dict[str, Any]] = None
        request_body_keys = {"body", "json", "data", "payload"}
        provided_body_key = next((k for k in request_body_keys if k in kwargs), None)
        if provided_body_key is not None:
            body_value = kwargs[provided_body_key]
            if body_value is None:
                body = None
            elif isinstance(body_value, dict):
                body = body_value
            else:
                raise SDKError(f"'{provided_body_key}' must be dict or None")
            used.add(provided_body_key)

        extras = {k: v for k, v in kwargs.items() if k not in used and f"{{{k}}}" not in spec.path}
        if body is None and spec.has_request_body and extras:
            body = extras
            used.update(extras.keys())

        if body is None and spec.request_body_required:
            raise SDKError("Request body is required. Pass it as body=... or json=...")

        unused = set(kwargs.keys()) - used
        return query, body, unused

    async def _get_session(self) -> aiohttp.ClientSession:
        if self._session is None or self._session.closed:
            timeout = aiohttp.ClientTimeout(total=self.timeout_seconds)
            self._session = aiohttp.ClientSession(timeout=timeout)
        return self._session

    async def _request(
        self,
        method: str,
        url: str,
        query: Optional[dict[str, Any]],
        json_body: Optional[dict[str, Any]],
    ) -> Any:
        session = await self._get_session()
        headers = {
            "X-API-Key": self.api_key,
            "Accept": "application/json",
        }

        async with session.request(method=method, url=url, params=query, json=json_body, headers=headers) as resp:
            content_type = (resp.headers.get("Content-Type") or "").lower()
            if "application/json" in content_type:
                payload = await resp.json(content_type=None)
            elif content_type.startswith("image/"):
                payload = await resp.read()
            else:
                payload = await resp.text()

            if resp.status >= 400:
                raise SDKError(f"HTTP {resp.status} for {method} {url}: {payload}")

            return payload
