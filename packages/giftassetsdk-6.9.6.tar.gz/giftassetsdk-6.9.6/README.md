﻿# giftassetsdk 6.9.6

Dynamic async SDK for GiftAsset API.

The SDK loads the live OpenAPI schema from:
`https://giftasset.gifts/openapi.json`
and builds method mapping in memory for the current process runtime.

## Install (local)

```bash
pip install .
```

from folder:
`D:\hellno\apps\giftasset_sdk\v_696`

## Quick start

```python
import asyncio
from giftasset_sdk import SDK


async def main():
    client = SDK(api_key="YOUR_API_KEY")
    await client.initialize()

    gift = await client.get_gift_by_name(name="EasterEgg-1")
    print(gift["telegram_gift_name"])

    # Optional: inspect available methods loaded from OpenAPI
    print(len(client.list_methods()))
    print(client.list_methods()[:10])

    await client.close()


asyncio.run(main())
```

## Calling any method from OpenAPI

Method names are resolved from OpenAPI path names.
Example:

`/api/v1/gifts/get_gift_by_name` -> `client.get_gift_by_name(...)`

If endpoint has request body, you can pass body in 2 ways:

1. Explicit body:
```python
await client.get_collection_offers(body={"collection_name": "Evil Eye"})
```

2. Direct kwargs (auto-packed into body):
```python
await client.get_collection_offers(collection_name="Evil Eye")
```

For path parameters:

```python
image_bytes = await client.data(
    collection_shortname="artisanbrick",
    attribute_type="models",
    attribute_name="fightclub.png",
)
```

## Notes

- Initialization fetches OpenAPI and creates temporary in-memory map.
- No hardcoded endpoint catalog in source.
- `X-API-Key` is sent automatically for each request.
