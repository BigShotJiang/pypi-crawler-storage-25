"""Learn range-sensor confidences through a batched least-squares localization layer.

This example shows a use case where unrolled differentiation is genuinely
useful rather than merely demonstrative.

Problem setup
-------------
Each training sample contains noisy range measurements from a fixed set of
anchors to an unknown 2D target position. Some measurements are outliers. A
small neural network receives per-measurement metadata and predicts confidence
weights. Those weights are then used inside a batched nonlinear least-squares
solve that estimates the target position.

The outer training loss supervises the final solved position, not the raw
confidence weights. Unrolled differentiation lets gradients flow backward
through the accepted solver iterations into the confidence network.

Why this matters
----------------
Without differentiating through the solver, the confidence network would have
to be trained with a proxy objective. Here it is trained directly for the real
task: minimizing downstream localization error after geometric consistency is
enforced by optimization.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from time import perf_counter

import matplotlib.pyplot as plt
import seaborn as sns
import torch

from pytorch_nonlinear import BatchMode, DebugConfig, DiffMode, NonlinearLeastSquaresProblem, SharedStructureBatchResult, SolverConfig, solve


ANCHORS = torch.tensor(
    [
        [-1.8, -1.6],
        [-1.6, 1.7],
        [1.7, -1.7],
        [1.8, 1.6],
        [0.0, -2.2],
        [2.2, 0.0],
    ],
    dtype=torch.float64,
)


@dataclass(frozen=True)
class LocalizationBatch:
    """Synthetic localization data used for end-to-end training.

    Parameters
    ----------
    true_positions : torch.Tensor
        Ground-truth target positions with shape ``(batch, 2)``.
    measured_ranges : torch.Tensor
        Noisy per-anchor range measurements with shape ``(batch, n_anchors)``.
    features : torch.Tensor
        Per-measurement metadata consumed by the confidence network with shape
        ``(batch, n_anchors, n_features)``.
    is_outlier : torch.Tensor
        Boolean mask marking which measurements are corrupted outliers.
    """

    true_positions: torch.Tensor
    measured_ranges: torch.Tensor
    features: torch.Tensor
    is_outlier: torch.Tensor


@dataclass(frozen=True)
class DemoSample:
    """One qualitative localization example for the final plot."""

    true_position: torch.Tensor
    uniform_estimate: torch.Tensor
    learned_estimate: torch.Tensor
    learned_weights: torch.Tensor
    is_outlier: torch.Tensor


@dataclass(frozen=True)
class TrainingTrace:
    """Recorded metrics for the learned optimization-layer example."""

    train_losses: list[float]
    eval_rmses: list[float]
    inlier_weights: list[float]
    outlier_weights: list[float]
    baseline_uniform_rmse: float
    final_learned_rmse: float
    demo_sample: DemoSample
    final_result: SharedStructureBatchResult
    total_time_s: float


class ConfidenceNetwork(torch.nn.Module):
    """Predict positive confidence weights from sensor metadata."""

    def __init__(self) -> None:
        super().__init__()
        self.network = torch.nn.Sequential(
            torch.nn.Linear(3, 24),
            torch.nn.Tanh(),
            torch.nn.Linear(24, 24),
            torch.nn.Tanh(),
            torch.nn.Linear(24, 1),
        )

    def forward(self, features: torch.Tensor) -> torch.Tensor:
        logits = self.network(features).squeeze(-1)
        return 0.05 + 0.95 * torch.sigmoid(logits)


def euclidean_norm(value: torch.Tensor, *, dim: int) -> torch.Tensor:
    """Compute an Euclidean norm without relying on torch.linalg stubs."""

    return torch.sqrt(torch.sum(value * value, dim=dim))


def build_localization_problem() -> NonlinearLeastSquaresProblem:
    """Build the shared-structure localization problem."""

    def residual(state: torch.Tensor, params: dict[str, torch.Tensor]) -> torch.Tensor:
        anchors = params["anchors"]
        measured_ranges = params["measured_ranges"]
        weights = params["weights"]
        predicted_ranges = euclidean_norm(anchors - state.unsqueeze(0), dim=-1)
        return weights * (predicted_ranges - measured_ranges)

    return NonlinearLeastSquaresProblem(residual=residual)


def make_dataset(*, batch_size: int, seed: int, device: torch.device) -> LocalizationBatch:
    """Generate synthetic range-sensor localization data."""

    generator = torch.Generator()
    generator.manual_seed(seed)

    true_positions = -1.25 + 2.5 * torch.rand(batch_size, 2, dtype=torch.float64, generator=generator)
    true_ranges = euclidean_norm(true_positions.unsqueeze(1) - ANCHORS.unsqueeze(0), dim=-1)

    outlier_probability = 0.28
    is_outlier = torch.rand(batch_size, ANCHORS.shape[0], generator=generator) < outlier_probability
    inlier_noise = 0.03 * torch.randn(batch_size, ANCHORS.shape[0], dtype=torch.float64, generator=generator)
    outlier_bias = 0.45 + 0.55 * torch.rand(batch_size, ANCHORS.shape[0], dtype=torch.float64, generator=generator)
    outlier_sign = torch.where(
        torch.rand(batch_size, ANCHORS.shape[0], generator=generator) < 0.5,
        -torch.ones(batch_size, ANCHORS.shape[0], dtype=torch.float64),
        torch.ones(batch_size, ANCHORS.shape[0], dtype=torch.float64),
    )
    outlier_noise = 0.06 * torch.randn(batch_size, ANCHORS.shape[0], dtype=torch.float64, generator=generator)
    measurement_noise = torch.where(is_outlier, outlier_sign * outlier_bias + outlier_noise, inlier_noise)
    measured_ranges = true_ranges + measurement_noise

    quality_inlier = 0.65 + 0.35 * torch.rand(batch_size, ANCHORS.shape[0], dtype=torch.float64, generator=generator)
    quality_outlier = 0.05 + 0.60 * torch.rand(batch_size, ANCHORS.shape[0], dtype=torch.float64, generator=generator)
    reported_quality = torch.where(is_outlier, quality_outlier, quality_inlier)

    anchor_radius = euclidean_norm(ANCHORS, dim=-1).unsqueeze(0).expand(batch_size, -1)
    features = torch.stack(
        (
            reported_quality,
            measured_ranges / 3.5,
            anchor_radius / 3.0,
        ),
        dim=-1,
    )

    return LocalizationBatch(
        true_positions=true_positions.to(device),
        measured_ranges=measured_ranges.to(device),
        features=features.to(device),
        is_outlier=is_outlier.to(device),
    )


def solve_localization_batch(
    problem: NonlinearLeastSquaresProblem,
    *,
    anchors: torch.Tensor,
    measured_ranges: torch.Tensor,
    weights: torch.Tensor,
    diff_mode: DiffMode,
) -> SharedStructureBatchResult:
    """Solve one shared-structure batch of localization problems."""

    batch_size = int(measured_ranges.shape[0])
    result = solve(
        problem,
        x0=torch.zeros(batch_size, 2, dtype=measured_ranges.dtype, device=measured_ranges.device),
        params={
            "anchors": anchors,
            "measured_ranges": measured_ranges,
            "weights": weights,
        },
        config=SolverConfig(
            method="lm",
            diff_mode=diff_mode,
            batch_mode=BatchMode.SHARED_STRUCTURE,
            max_iter=25,
            tol=1e-8,
            debug=DebugConfig(capture_history=False),
        ),
    )
    if not isinstance(result, SharedStructureBatchResult):
        raise TypeError("Expected SharedStructureBatchResult from shared-structure batch solve.")
    return result


def batch_rmse(estimate: torch.Tensor, truth: torch.Tensor) -> float:
    """Return batch root-mean-square localization error."""

    squared_error = torch.sum((estimate - truth) ** 2, dim=-1)
    return float(torch.sqrt(torch.mean(squared_error)).detach().cpu().item())


def evaluate_model(
    model: ConfidenceNetwork,
    problem: NonlinearLeastSquaresProblem,
    validation_data: LocalizationBatch,
    anchors: torch.Tensor,
) -> tuple[float, float, float, SharedStructureBatchResult, torch.Tensor]:
    """Evaluate localization quality and confidence separation on validation data."""

    with torch.no_grad():
        weights = model(validation_data.features)

    result = solve_localization_batch(
        problem,
        anchors=anchors,
        measured_ranges=validation_data.measured_ranges,
        weights=weights,
        diff_mode=DiffMode.AUTO,
    )
    rmse = batch_rmse(result.x, validation_data.true_positions)
    inlier_weight = float(weights[~validation_data.is_outlier].mean().detach().cpu().item())
    outlier_weight = float(weights[validation_data.is_outlier].mean().detach().cpu().item())
    return rmse, inlier_weight, outlier_weight, result, weights


def pick_demo_sample(
    validation_data: LocalizationBatch,
    uniform_result: SharedStructureBatchResult,
    learned_result: SharedStructureBatchResult,
    learned_weights: torch.Tensor,
) -> DemoSample:
    """Choose a qualitative validation sample where learning helps most."""

    uniform_error = torch.sum((uniform_result.x - validation_data.true_positions) ** 2, dim=-1)
    learned_error = torch.sum((learned_result.x - validation_data.true_positions) ** 2, dim=-1)
    improvement = uniform_error - learned_error
    index = int(torch.argmax(improvement).detach().cpu().item())
    return DemoSample(
        true_position=validation_data.true_positions[index].detach().cpu(),
        uniform_estimate=uniform_result.x[index].detach().cpu(),
        learned_estimate=learned_result.x[index].detach().cpu(),
        learned_weights=learned_weights[index].detach().cpu(),
        is_outlier=validation_data.is_outlier[index].detach().cpu(),
    )


def run_training(*, epochs: int = 30, learning_rate: float = 0.05) -> TrainingTrace:
    """Train a confidence network through the batched least-squares solver."""

    torch.manual_seed(0)
    device = torch.device("cpu")
    anchors = ANCHORS.to(device)
    problem = build_localization_problem()
    model = ConfidenceNetwork().to(device=device, dtype=torch.float64)
    optimizer = torch.optim.Adam(model.parameters(), lr=learning_rate)

    train_data = make_dataset(batch_size=96, seed=7, device=device)
    validation_data = make_dataset(batch_size=128, seed=19, device=device)

    uniform_weights = torch.ones_like(validation_data.measured_ranges)
    uniform_result = solve_localization_batch(
        problem,
        anchors=anchors,
        measured_ranges=validation_data.measured_ranges,
        weights=uniform_weights,
        diff_mode=DiffMode.AUTO,
    )
    baseline_uniform_rmse = batch_rmse(uniform_result.x, validation_data.true_positions)

    train_losses: list[float] = []
    eval_rmses: list[float] = []
    inlier_weights: list[float] = []
    outlier_weights: list[float] = []
    final_result: SharedStructureBatchResult | None = None
    final_validation_weights: torch.Tensor | None = None
    total_start = perf_counter()

    for _ in range(epochs):
        optimizer.zero_grad()
        train_weights = model(train_data.features)
        train_result = solve_localization_batch(
            problem,
            anchors=anchors,
            measured_ranges=train_data.measured_ranges,
            weights=train_weights,
            diff_mode=DiffMode.UNROLL,
        )

        position_error = torch.sum((train_result.x - train_data.true_positions) ** 2, dim=-1)
        loss = torch.mean(position_error)
        loss.backward()
        optimizer.step()

        eval_rmse, inlier_weight, outlier_weight, final_result, final_validation_weights = evaluate_model(
            model,
            problem,
            validation_data,
            anchors,
        )
        train_losses.append(float(loss.detach().cpu().item()))
        eval_rmses.append(eval_rmse)
        inlier_weights.append(inlier_weight)
        outlier_weights.append(outlier_weight)

    total_time_s = perf_counter() - total_start
    if final_result is None or final_validation_weights is None:
        raise RuntimeError("Training loop did not produce a validation result.")

    demo_sample = pick_demo_sample(validation_data, uniform_result, final_result, final_validation_weights)
    return TrainingTrace(
        train_losses=train_losses,
        eval_rmses=eval_rmses,
        inlier_weights=inlier_weights,
        outlier_weights=outlier_weights,
        baseline_uniform_rmse=baseline_uniform_rmse,
        final_learned_rmse=eval_rmses[-1],
        demo_sample=demo_sample,
        final_result=final_result,
        total_time_s=total_time_s,
    )


def plot_trace(*, trace: TrainingTrace, output_path: Path) -> None:
    """Write a compact visualization of the learned optimization layer."""

    sns.set_theme(style="whitegrid", context="talk")
    epochs = list(range(1, len(trace.train_losses) + 1))
    figure, axes = plt.subplots(1, 3, figsize=(17, 5), constrained_layout=True)

    sns.lineplot(x=epochs, y=trace.eval_rmses, ax=axes[0], marker="o", linewidth=2.5, color="#0f766e")
    axes[0].axhline(
        trace.baseline_uniform_rmse,
        color="#b91c1c",
        linestyle="--",
        linewidth=2.0,
        label="uniform weights",
    )
    axes[0].set_title("Validation Localization Error")
    axes[0].set_xlabel("epoch")
    axes[0].set_ylabel("RMSE")
    axes[0].legend(loc="best")

    sns.lineplot(x=epochs, y=trace.inlier_weights, ax=axes[1], marker="o", linewidth=2.5, color="#1d4ed8", label="inliers")
    sns.lineplot(x=epochs, y=trace.outlier_weights, ax=axes[1], marker="o", linewidth=2.5, color="#ea580c", label="outliers")
    axes[1].set_title("Learned Confidence Separation")
    axes[1].set_xlabel("epoch")
    axes[1].set_ylabel("mean predicted weight")
    axes[1].set_ylim(0.0, 1.05)
    axes[1].legend(loc="best")

    demo = trace.demo_sample
    anchor_colors = ["#dc2626" if is_outlier else "#0f766e" for is_outlier in demo.is_outlier.tolist()]
    anchor_sizes = 120 + 280 * demo.learned_weights.numpy()
    axes[2].scatter(ANCHORS[:, 0].numpy(), ANCHORS[:, 1].numpy(), s=anchor_sizes, c=anchor_colors, alpha=0.85, edgecolors="#111827")
    axes[2].scatter(demo.true_position[0], demo.true_position[1], s=220, marker="*", color="#111827", label="true position")
    axes[2].scatter(demo.uniform_estimate[0], demo.uniform_estimate[1], s=140, marker="X", color="#b91c1c", label="uniform solve")
    axes[2].scatter(demo.learned_estimate[0], demo.learned_estimate[1], s=140, marker="D", color="#2563eb", label="learned solve")
    for anchor_index, weight in enumerate(demo.learned_weights.tolist()):
        axes[2].text(
            float(ANCHORS[anchor_index, 0].item()) + 0.05,
            float(ANCHORS[anchor_index, 1].item()) + 0.05,
            f"w={weight:.2f}",
            fontsize=9,
        )
    axes[2].set_title("One Validation Scene")
    axes[2].set_xlabel("x")
    axes[2].set_ylabel("y")
    axes[2].set_aspect("equal", adjustable="box")
    axes[2].legend(loc="best")

    figure.savefig(output_path, format="svg", bbox_inches="tight")
    plt.close(figure)


def main() -> None:
    """Run the learned sensor-fusion optimization-layer example."""

    trace = run_training()
    output_dir = Path(__file__).resolve().parent / "artifacts"
    output_dir.mkdir(parents=True, exist_ok=True)
    output_path = output_dir / "learned_range_sensor_fusion.svg"
    plot_trace(trace=trace, output_path=output_path)

    print(trace.final_result.summary())
    print(f"Uniform-weight validation RMSE: {trace.baseline_uniform_rmse:.4f}")
    print(f"Learned-weight validation RMSE: {trace.final_learned_rmse:.4f}")
    print(f"Mean learned inlier weight: {trace.inlier_weights[-1]:.3f}")
    print(f"Mean learned outlier weight: {trace.outlier_weights[-1]:.3f}")
    print(f"Total training time: {trace.total_time_s:.3f} s")
    print(f"Wrote visualization: {output_path}")


if __name__ == "__main__":
    main()