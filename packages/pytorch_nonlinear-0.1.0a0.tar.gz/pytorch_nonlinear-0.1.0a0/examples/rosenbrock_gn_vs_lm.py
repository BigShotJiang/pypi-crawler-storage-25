"""Compare Gauss-Newton and Levenberg-Marquardt on Rosenbrock least squares.

This example reformulates the Rosenbrock function as a two-residual nonlinear
least-squares problem, runs both Gauss-Newton and Levenberg-Marquardt from the
classic difficult start, and writes a seaborn-styled figure showing the solver
trajectories and objective history.
"""

from __future__ import annotations

from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import seaborn as sns
import torch

from pytorch_nonlinear import IterationRecord, NonlinearLeastSquaresProblem, SolverConfig, solve


def build_rosenbrock_problem(a: float = 1.0, b: float = 100.0) -> NonlinearLeastSquaresProblem:
    """Build the Rosenbrock function as a least-squares residual system.

    Parameters
    ----------
    a : float, optional
        Rosenbrock shift parameter.
    b : float, optional
        Rosenbrock valley curvature parameter.

    Returns
    -------
    NonlinearLeastSquaresProblem
        Least-squares formulation with residuals ``a - x`` and
        ``sqrt(b) * (y - x^2)``.
    """

    sqrt_b = b**0.5

    def residual(state: torch.Tensor, params: None) -> torch.Tensor:
        """Evaluate the Rosenbrock residual vector.

        Parameters
        ----------
        state : torch.Tensor
            Two-vector ``[x, y]``.
        params : None
            Unused placeholder to match the typed problem callback signature.

        Returns
        -------
        torch.Tensor
            Two residual values whose squared norm is the Rosenbrock objective.
        """

        return torch.stack((a - state[0], sqrt_b * (state[1] - state[0] ** 2)))

    return NonlinearLeastSquaresProblem(residual=residual)


def rosenbrock_objective(point: torch.Tensor) -> float:
    """Evaluate the Rosenbrock objective at a point.

    Parameters
    ----------
    point : torch.Tensor
        Two-vector ``[x, y]``.

    Returns
    -------
    float
        Objective value.
    """

    x_value = point[0]
    y_value = point[1]
    return float((1.0 - x_value) ** 2 + 100.0 * (y_value - x_value**2) ** 2)


def iterate_path(start: torch.Tensor, history: tuple[IterationRecord, ...]) -> np.ndarray:
    """Convert accepted iteration states into a plotted path.

    Parameters
    ----------
    start : torch.Tensor
        Common starting point.
    history : tuple[IterationRecord, ...]
        Solver iteration history.

    Returns
    -------
    numpy.ndarray
        Array with shape ``(num_points, 2)``.
    """

    points = [start.reshape(-1).detach().cpu().numpy()]
    for record in history:
        state = record.state
        if state is None:
            continue
        points.append(state.reshape(-1).detach().cpu().numpy())
    return np.vstack(points)


def attempted_trial_path(start: torch.Tensor, history: tuple[IterationRecord, ...]) -> np.ndarray:
    """Convert the final attempted trial from each iteration into a path.

    Parameters
    ----------
    start : torch.Tensor
        Common starting point.
    history : tuple[IterationRecord, ...]
        Solver iteration history.

    Returns
    -------
    numpy.ndarray
        Array with shape ``(num_points, 2)``.
    """

    points = [start.reshape(-1).detach().cpu().numpy()]
    for record in history:
        if not record.trials:
            continue
        state = record.trials[-1].state
        if state is None:
            continue
        points.append(state.reshape(-1).detach().cpu().numpy())
    return np.vstack(points)


def trial_objective_history(start: torch.Tensor, history: tuple[IterationRecord, ...]) -> list[float]:
    """Collect objective values from the final attempted trial per iteration.

    Parameters
    ----------
    start : torch.Tensor
        Common starting point.
    history : tuple[IterationRecord, ...]
        Solver iteration history.

    Returns
    -------
    list[float]
        Objective values beginning at the initial point and continuing with the
        final attempted trial from each iteration.
    """

    values = [rosenbrock_objective(start)]
    for record in history:
        if record.trials and record.trials[-1].objective_value is not None:
            values.append(record.trials[-1].objective_value)
    return values


def accepted_objective_history(start: torch.Tensor, history: tuple[IterationRecord, ...]) -> list[float]:
    """Collect objective values from accepted iterates.

    Parameters
    ----------
    start : torch.Tensor
        Common starting point.
    history : tuple[IterationRecord, ...]
        Solver iteration history.

    Returns
    -------
    list[float]
        Objective values beginning at the initial point and continuing with the
        recorded outer iterate after each iteration.
    """

    values = [rosenbrock_objective(start)]
    for record in history:
        if record.objective_value is not None:
            values.append(record.objective_value)
    return values


def plot_rosenbrock_comparison(
    *,
    start: torch.Tensor,
    gauss_newton_history: tuple[IterationRecord, ...],
    lm_history: tuple[IterationRecord, ...],
    output_path: Path,
) -> None:
    """Plot GN vs LM on the Rosenbrock landscape.

    Parameters
    ----------
    start : torch.Tensor
        Common starting point.
    gauss_newton_history : tuple[IterationRecord, ...]
        Gauss-Newton iteration history.
    lm_history : tuple[IterationRecord, ...]
        Levenberg-Marquardt iteration history.
    output_path : Path
        Output figure path.
    """

    sns.set_theme(style="whitegrid", context="talk")
    x_grid, y_grid = np.meshgrid(np.linspace(-1.8, 1.8, 260), np.linspace(-3.4, 3.0, 520))
    z_grid = (1.0 - x_grid) ** 2 + 100.0 * (y_grid - x_grid**2) ** 2

    gn_path = attempted_trial_path(start, gauss_newton_history)
    lm_path = iterate_path(start, lm_history)
    gauss_newton_objectives = trial_objective_history(start, gauss_newton_history)
    lm_objectives = accepted_objective_history(start, lm_history)
    iterations_gn = list(range(len(gauss_newton_objectives)))
    iterations_lm = list(range(len(lm_objectives)))

    figure, axes = plt.subplots(1, 2, figsize=(14, 5.5), constrained_layout=True)

    contour_levels = np.geomspace(1e-2, 1e3, 18)
    axes[0].contourf(x_grid, y_grid, z_grid, levels=contour_levels, cmap=sns.color_palette("crest", as_cmap=True), alpha=0.95)
    axes[0].contour(x_grid, y_grid, z_grid, levels=contour_levels, colors="white", linewidths=0.35, alpha=0.5)
    sns.lineplot(x=lm_path[:, 0], y=lm_path[:, 1], ax=axes[0], color="#0f766e", linewidth=3, marker="o", label="LM path")
    sns.lineplot(
        x=gn_path[:, 0],
        y=gn_path[:, 1],
        ax=axes[0],
        color="#d9480f",
        linewidth=2.5,
        marker="X",
        linestyle="--",
        label="GN full-step path",
    )
    axes[0].scatter([1.0], [1.0], s=90, color="#111827", label="minimizer")
    axes[0].set_title("Rosenbrock Landscape")
    axes[0].set_xlabel("x")
    axes[0].set_ylabel("y")
    axes[0].legend(loc="upper left")

    sns.lineplot(x=iterations_lm, y=lm_objectives, ax=axes[1], color="#1d4ed8", linewidth=2.8, marker="o", label="LM")
    sns.lineplot(
        x=iterations_gn,
        y=gauss_newton_objectives,
        ax=axes[1],
        color="#d9480f",
        linewidth=2.5,
        marker="X",
        linestyle="--",
        label="GN",
    )
    axes[1].set_yscale("log")
    axes[1].set_title("Objective History")
    axes[1].set_xlabel("iteration")
    axes[1].set_ylabel("Rosenbrock objective")

    figure.savefig(output_path, format="svg", bbox_inches="tight")
    plt.close(figure)


def main() -> None:
    """Run the Rosenbrock comparison and write the figure artifact.

    Returns
    -------
    None
        The example writes an SVG artifact and prints concise solver summaries.
    """

    problem = build_rosenbrock_problem()
    start = torch.tensor([-1.2, 1.0], dtype=torch.float64)

    gauss_newton_result = solve(problem, x0=start, params=None, config=SolverConfig(method="gauss_newton", max_iter=10, tol=1e-10))
    lm_result = solve(problem, x0=start, params=None, config=SolverConfig(method="lm", max_iter=30, tol=1e-10))

    output_dir = Path(__file__).resolve().parent / "artifacts"
    output_dir.mkdir(parents=True, exist_ok=True)
    output_path = output_dir / "rosenbrock_gn_vs_lm.svg"

    plot_rosenbrock_comparison(
        start=start,
        gauss_newton_history=gauss_newton_result.history,
        lm_history=lm_result.history,
        output_path=output_path,
    )

    # Print both summaries so users can connect the SVG to the solver outcomes.
    print(f"Gauss-Newton: {gauss_newton_result.summary()}")
    print(f"Levenberg-Marquardt: {lm_result.summary()}")
    print(f"Wrote visualization: {output_path}")


if __name__ == "__main__":
    main()