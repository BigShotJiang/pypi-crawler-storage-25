"""Compare GN, LM, and trust-region on Rosenbrock using CUDA.

This example uses a difficult Rosenbrock least-squares start where the three
methods separate clearly on CUDA: Gauss-Newton rejects its full step, LM
converges more cautiously, and the trust-region method takes a distinct, more
aggressive accepted path.
"""

from __future__ import annotations

from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import seaborn as sns
import torch

from pytorch_nonlinear import IterationRecord, NonlinearLeastSquaresProblem, SolverConfig, solve


COLORS = {"GN": "#c2410c", "LM": "#0f766e", "TR": "#1d4ed8"}
LINE_STYLES = {"GN": "--", "LM": "-", "TR": ":"}
MARKERS = {"GN": "X", "LM": "o", "TR": "s"}


def build_rosenbrock_problem(a: float = 1.0, b: float = 100.0) -> NonlinearLeastSquaresProblem:
    """Build the Rosenbrock function as a least-squares residual system.

    Parameters
    ----------
    a : float, optional
        Rosenbrock shift parameter.
    b : float, optional
        Rosenbrock valley curvature parameter.

    Returns
    -------
    NonlinearLeastSquaresProblem
        Least-squares formulation with residuals ``a - x`` and
        ``sqrt(b) * (y - x^2)``.
    """

    sqrt_b = b**0.5

    def residual(state: torch.Tensor, params: None) -> torch.Tensor:
        """Evaluate the Rosenbrock residual vector."""

        return torch.stack((a - state[0], sqrt_b * (state[1] - state[0] ** 2)))

    return NonlinearLeastSquaresProblem(residual=residual)


def rosenbrock_objective(point: torch.Tensor) -> float:
    """Evaluate the Rosenbrock objective at a point."""

    x_value = point[0]
    y_value = point[1]
    return float((1.0 - x_value) ** 2 + 100.0 * (y_value - x_value**2) ** 2)


def accepted_or_last_trial_path(start: torch.Tensor, history: tuple[IterationRecord, ...]) -> np.ndarray:
    """Build a plotted path from accepted states or last attempted trials."""

    points = [start.reshape(-1).detach().cpu().numpy()]
    for record in history:
        point = None
        if record.accepted and record.state is not None:
            point = record.state
        elif record.trials and record.trials[-1].state is not None:
            point = record.trials[-1].state
        elif record.state is not None:
            point = record.state
        if point is not None:
            points.append(point.reshape(-1).detach().cpu().numpy())
    return np.vstack(points)


def objective_history(start: torch.Tensor, history: tuple[IterationRecord, ...]) -> list[float]:
    """Collect objective values for plotted history traces."""

    values = [rosenbrock_objective(start.detach().cpu())]
    for record in history:
        if record.accepted and record.objective_value is not None:
            values.append(record.objective_value)
        elif record.trials and record.trials[-1].objective_value is not None:
            values.append(record.trials[-1].objective_value)
        elif record.objective_value is not None:
            values.append(record.objective_value)
    return values


def plot_cuda_comparison(
    *,
    start: torch.Tensor,
    histories: dict[str, tuple[IterationRecord, ...]],
    output_path: Path,
) -> None:
    """Plot CUDA Rosenbrock trajectories and objective histories."""

    sns.set_theme(style="whitegrid", context="talk")
    x_grid, y_grid = np.meshgrid(np.linspace(-5.8, 2.2, 320), np.linspace(-30, 26.0, 1280))
    z_grid = (1.0 - x_grid) ** 2 + 100.0 * (y_grid - x_grid**2) ** 2
    contour_levels = np.geomspace(1e-1, 1e6, 20)

    figure, axes = plt.subplots(1, 2, figsize=(15, 6), constrained_layout=True)
    axes[0].contourf(x_grid, y_grid, z_grid, levels=contour_levels, cmap=sns.color_palette("crest", as_cmap=True), alpha=0.95)
    axes[0].contour(x_grid, y_grid, z_grid, levels=contour_levels, colors="white", linewidths=0.35, alpha=0.5)

    for method_label, history in histories.items():
        path = accepted_or_last_trial_path(start, history)
        sns.lineplot(
            x=path[:, 0],
            y=path[:, 1],
            ax=axes[0],
            color=COLORS[method_label],
            linewidth=2.5,
            marker=MARKERS[method_label],
            linestyle=LINE_STYLES[method_label],
            label=method_label,
        )

    axes[0].scatter([1.0], [1.0], s=90, color="#111827", label="minimizer")
    axes[0].set_title("CUDA Rosenbrock Trajectories")
    axes[0].set_xlabel("x")
    axes[0].set_ylabel("y")
    axes[0].legend(loc="upper left")

    for method_label, history in histories.items():
        values = objective_history(start, history)
        sns.lineplot(
            x=list(range(len(values))),
            y=values,
            ax=axes[1],
            color=COLORS[method_label],
            linewidth=2.5,
            marker=MARKERS[method_label],
            linestyle=LINE_STYLES[method_label],
            label=method_label,
        )

    axes[1].set_yscale("log")
    axes[1].set_title("Objective History")
    axes[1].set_xlabel("iteration")
    axes[1].set_ylabel("Rosenbrock objective")

    figure.savefig(output_path, format="svg", bbox_inches="tight")
    plt.close(figure)


def main() -> None:
    """Run the CUDA Rosenbrock comparison and write the SVG artifact."""

    if not torch.cuda.is_available():
        raise RuntimeError("This example requires CUDA so it can compare GN, LM, and trust-region on the GPU.")

    device = "cuda"
    problem = build_rosenbrock_problem()
    start = torch.tensor([-5.0, -4.0], dtype=torch.float64, device=device)

    results = {
        "GN": solve(problem, x0=start, params=None, config=SolverConfig(method="gauss_newton", device=device, max_iter=8, tol=1e-10)),
        "LM": solve(problem, x0=start, params=None, config=SolverConfig(method="lm", device=device, max_iter=20, tol=1e-10)),
        "TR": solve(problem, x0=start, params=None, config=SolverConfig(method="trust_region", device=device, max_iter=20, tol=1e-10)),
    }

    output_dir = Path(__file__).resolve().parent / "artifacts"
    output_dir.mkdir(parents=True, exist_ok=True)
    output_path = output_dir / "cuda_rosenbrock_gn_lm_tr.svg"

    plot_cuda_comparison(
        start=start,
        histories={method_label: result.history for method_label, result in results.items()},
        output_path=output_path,
    )

    print(f"Device: {device}")
    print(f"Start: {start.detach().cpu().tolist()}")
    print("method | iterations | status | termination | final_objective")
    for method_label, result in results.items():
        print(
            f"{method_label:>6} | {result.num_iter:>10} | {result.status.value:>16} | {result.termination.value:>12} | {float(result.objective_value):>15.6e}"
        )
    print(f"Wrote visualization: {output_path}")


if __name__ == "__main__":
    main()