"""Run the repository examples from the examples directory.

By default, this script executes every example file in this folder except
itself. CUDA-only examples are skipped automatically when CUDA is not
available.
"""

from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path

import torch


CUDA_ONLY_EXAMPLES = {
    "cpu_vs_gpu_gn_lm.py",
    "cuda_robust_loss_comparison_hard.py",
    "cuda_rosenbrock_gn_lm_tr.py",
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run all repository examples.")
    parser.add_argument(
        "--include-cuda",
        action="store_true",
        help="Attempt CUDA-only examples even when CUDA is unavailable.",
    )
    parser.add_argument(
        "--stop-on-failure",
        action="store_true",
        help="Stop immediately after the first failing example.",
    )
    return parser.parse_args()


def iter_example_paths(examples_dir: Path) -> list[Path]:
    return sorted(
        path
        for path in examples_dir.glob("*.py")
        if path.name != "run_all_examples.py"
    )


def main() -> int:
    args = parse_args()
    examples_dir = Path(__file__).resolve().parent
    python_executable = sys.executable
    cuda_available = torch.cuda.is_available()

    ran = 0
    skipped: list[str] = []
    failed: list[str] = []

    for example_path in iter_example_paths(examples_dir):
        if example_path.name in CUDA_ONLY_EXAMPLES and not (args.include_cuda or cuda_available):
            skipped.append(f"{example_path.name} (requires CUDA)")
            continue

        print(f"=== Running {example_path.name} ===")
        completed = subprocess.run([python_executable, str(example_path)], cwd=examples_dir.parent)
        ran += 1

        if completed.returncode != 0:
            failed.append(example_path.name)
            print(f"--- FAILED: {example_path.name} (exit code {completed.returncode}) ---")
            if args.stop_on_failure:
                break
        else:
            print(f"--- OK: {example_path.name} ---")

    print("\nSummary")
    print(f"  ran: {ran}")
    print(f"  skipped: {len(skipped)}")
    print(f"  failed: {len(failed)}")
    if skipped:
        print("  skipped examples:")
        for item in skipped:
            print(f"    - {item}")
    if failed:
        print("  failed examples:")
        for item in failed:
            print(f"    - {item}")
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())