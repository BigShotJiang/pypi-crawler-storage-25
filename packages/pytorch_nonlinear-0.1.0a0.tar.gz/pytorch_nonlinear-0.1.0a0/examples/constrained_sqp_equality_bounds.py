"""Visualize dense constrained SQP with equality and active box bounds.

This example compares two related constrained solves on the same
two-dimensional objective:

- an equality-only SQP solve on ``x + y = 1``
- an equality-plus-bounds SQP solve with an active upper bound on ``x``

The figure shows how the added bound changes the feasible set, accepted path,
and final KKT point. Analytical reference points are included so the two
solver traces can be compared against the known geometry.
"""

from __future__ import annotations

from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import seaborn as sns
import torch

from pytorch_nonlinear import Bounds, ConstrainedNLPProblem, EqualityConstraint, IterationRecord, SolverConfig, solve


_OBJECTIVE_CENTER = torch.tensor([1.7, -0.4], dtype=torch.float64)
_EQUALITY_TARGET = 1.0
_PLOT_LOG_FLOOR = 1e-16


def objective_value(x_coord: np.ndarray, y_coord: np.ndarray) -> np.ndarray:
    """Evaluate the dense objective on a plotting grid.

    Parameters
    ----------
    x_coord : numpy.ndarray
        Meshgrid x coordinates.
    y_coord : numpy.ndarray
        Meshgrid y coordinates.

    Returns
    -------
    numpy.ndarray
        Objective values for the example quadratic objective.
    """

    return (x_coord - float(_OBJECTIVE_CENTER[0])) ** 2 + (y_coord - float(_OBJECTIVE_CENTER[1])) ** 2


def build_problems() -> tuple[ConstrainedNLPProblem, ConstrainedNLPProblem]:
    """Construct the equality-only and equality-plus-bounds problems.

    Returns
    -------
    tuple[ConstrainedNLPProblem, ConstrainedNLPProblem]
        Pair of problems sharing the same objective and equality constraint.
    """

    objective = lambda state, params: (state[0] - _OBJECTIVE_CENTER[0]) ** 2 + (state[1] - _OBJECTIVE_CENTER[1]) ** 2
    equality = EqualityConstraint(lambda state, params: state[0] + state[1] - _EQUALITY_TARGET)

    equality_only = ConstrainedNLPProblem(
        objective=objective,
        constraints=(equality,),
    )
    equality_plus_bounds = ConstrainedNLPProblem(
        objective=objective,
        constraints=(equality,),
        bounds=Bounds(
            lower=torch.tensor([-1.0, -2.0], dtype=torch.float64),
            upper=torch.tensor([1.5, 1.5], dtype=torch.float64),
            name="box",
        ),
    )
    return equality_only, equality_plus_bounds


def analytical_reference_points() -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    """Return analytic reference points for the plotting narrative.

    Returns
    -------
    tuple[torch.Tensor, torch.Tensor, torch.Tensor]
        Unconstrained minimizer, equality-only reference, and bounded optimum.
    """

    unconstrained = _OBJECTIVE_CENTER.clone()
    equality_shift = 0.5 * (float(_OBJECTIVE_CENTER.sum().item()) - _EQUALITY_TARGET)
    equality_only = _OBJECTIVE_CENTER - equality_shift * torch.ones(2, dtype=torch.float64)
    bounded = torch.tensor([1.5, _EQUALITY_TARGET - 1.5], dtype=torch.float64)

    return unconstrained, equality_only, bounded


def history_path(start: torch.Tensor, history: tuple[IterationRecord, ...]) -> np.ndarray:
    """Collect a plotted optimization path from the solver history.

    Parameters
    ----------
    start : torch.Tensor
        Shared starting point.
    history : tuple[IterationRecord, ...]
        Solver history.

    Returns
    -------
    numpy.ndarray
        Path points stacked as ``(x, y)`` rows.
    """

    points = [start.detach().cpu().reshape(-1).numpy()]
    for record in history:
        if record.state is not None:
            points.append(record.state.detach().cpu().reshape(-1).numpy())
    return np.vstack(points)


def objective_history(start: torch.Tensor, history: tuple[IterationRecord, ...]) -> list[float]:
    """Collect objective values including the initial point.

    Parameters
    ----------
    start : torch.Tensor
        Initial point.
    history : tuple[IterationRecord, ...]
        Solver history.

    Returns
    -------
    list[float]
        Objective values from the start through recorded iterations.
    """

    values = [float(((start[0] - _OBJECTIVE_CENTER[0]) ** 2 + (start[1] - _OBJECTIVE_CENTER[1]) ** 2).item())]
    for record in history:
        if record.objective_value is not None:
            values.append(float(record.objective_value))
    return values


def violation_history(start: torch.Tensor, history: tuple[IterationRecord, ...]) -> list[float]:
    """Collect constraint violations including the initial point.

    Parameters
    ----------
    start : torch.Tensor
        Initial point.
    history : tuple[IterationRecord, ...]
        Solver history.

    Returns
    -------
    list[float]
        Constraint violations from the start through recorded iterations.
    """

    values = [float(torch.abs(start[0] + start[1] - _EQUALITY_TARGET).item())]
    for record in history:
        if record.constraint_violation is not None:
            values.append(float(record.constraint_violation))
    return values


def clipped_log_series(values: list[float]) -> list[float]:
    """Clip nonnegative values away from zero for log plotting.

    Parameters
    ----------
    values : list[float]
        Nonnegative series to plot on a log axis.

    Returns
    -------
    list[float]
        Series clipped below by a tiny positive floor.
    """

    return [max(value, _PLOT_LOG_FLOOR) for value in values]


def plot_example(
    *,
    start: torch.Tensor,
    equality_history: tuple[IterationRecord, ...],
    bounded_history: tuple[IterationRecord, ...],
    equality_solution: torch.Tensor,
    bounded_solution: torch.Tensor,
    unconstrained_reference: torch.Tensor,
    equality_reference: torch.Tensor,
    bounded_reference: torch.Tensor,
    output_path: Path,
) -> None:
    """Render the constrained-optimization geometry and histories.

    Parameters
    ----------
    start : torch.Tensor
        Shared initial point.
    equality_history : tuple[IterationRecord, ...]
        Equality-only solver history.
    bounded_history : tuple[IterationRecord, ...]
        Equality-plus-bounds solver history.
    equality_solution : torch.Tensor
        Final equality-only solution.
    bounded_solution : torch.Tensor
        Final equality-plus-bounds solution.
    unconstrained_reference : torch.Tensor
        Analytical unconstrained minimizer.
    equality_reference : torch.Tensor
        Analytical equality-only reference point.
    bounded_reference : torch.Tensor
        Analytical equality-plus-bounds optimum.
    output_path : Path
        Output SVG path.
    """

    sns.set_theme(style="whitegrid", context="talk")
    figure, axes = plt.subplot_mosaic(
        [["geometry", "geometry"], ["objective", "violation"]],
        figsize=(13, 9),
        constrained_layout=True,
    )

    x_grid, y_grid = np.meshgrid(np.linspace(-0.2, 2.2, 280), np.linspace(-1.4, 1.2, 280))
    z_grid = objective_value(x_grid, y_grid)
    contour_levels = np.geomspace(max(float(z_grid.min()), 1e-3), float(z_grid.max()), 18)

    equality_path = history_path(start, equality_history)
    bounded_path = history_path(start, bounded_history)
    equality_objectives = objective_history(start, equality_history)
    bounded_objectives = objective_history(start, bounded_history)
    equality_violations = violation_history(start, equality_history)
    bounded_violations = violation_history(start, bounded_history)

    geometry_axis = axes["geometry"]
    objective_axis = axes["objective"]
    violation_axis = axes["violation"]

    geometry_axis.contourf(x_grid, y_grid, z_grid, levels=contour_levels, cmap=sns.color_palette("crest", as_cmap=True), alpha=0.95)
    geometry_axis.contour(x_grid, y_grid, z_grid, levels=contour_levels, colors="white", linewidths=0.35, alpha=0.45)

    feasible_x = np.linspace(-0.2, 1.5, 200)
    feasible_y = _EQUALITY_TARGET - feasible_x
    equality_x = np.linspace(-0.2, 2.2, 200)
    equality_y = _EQUALITY_TARGET - equality_x

    geometry_axis.plot(equality_x, equality_y, linestyle="--", linewidth=2.0, color="#475569", label="equality: x + y = 1")
    geometry_axis.plot(feasible_x, feasible_y, linewidth=4.0, color="#0f766e", alpha=0.85, label="feasible segment")
    geometry_axis.plot([-1.0, 1.5, 1.5, -1.0, -1.0], [-2.0, -2.0, 1.5, 1.5, -2.0], linewidth=2.0, color="#7c3aed", label="box bounds")
    sns.lineplot(x=equality_path[:, 0], y=equality_path[:, 1], ax=geometry_axis, color="#1d4ed8", linewidth=2.8, marker="o", label="equality-only path")
    sns.lineplot(x=bounded_path[:, 0], y=bounded_path[:, 1], ax=geometry_axis, color="#c2410c", linewidth=2.8, marker="X", linestyle="--", label="equality + bounds path")
    geometry_axis.scatter([float(start[0])], [float(start[1])], s=100, color="#111827", label="start")
    geometry_axis.scatter([float(unconstrained_reference[0])], [float(unconstrained_reference[1])], s=120, color="#334155", edgecolors="white", linewidths=1.5, label="unconstrained minimizer")
    geometry_axis.scatter([float(equality_reference[0])], [float(equality_reference[1])], s=120, color="#059669", edgecolors="white", linewidths=1.5, label="equality-only reference")
    geometry_axis.scatter([float(bounded_reference[0])], [float(bounded_reference[1])], s=140, color="#dc2626", edgecolors="white", linewidths=1.5, label="bounded optimum")
    geometry_axis.scatter([float(equality_solution[0])], [float(equality_solution[1])], s=70, color="#1d4ed8", edgecolors="white", linewidths=1.0)
    geometry_axis.scatter([float(bounded_solution[0])], [float(bounded_solution[1])], s=70, color="#c2410c", edgecolors="white", linewidths=1.0)
    geometry_axis.set_title("Feasible Geometry And Paths")
    geometry_axis.set_xlabel("x")
    geometry_axis.set_ylabel("y")
    geometry_axis.set_xlim(-0.1, 2.15)
    geometry_axis.set_ylim(-1.25, 1.1)
    geometry_axis.legend(loc="lower left", fontsize=10)

    sns.lineplot(x=list(range(len(equality_objectives))), y=equality_objectives, ax=objective_axis, color="#1d4ed8", linewidth=2.8, marker="o", label="equality-only")
    sns.lineplot(x=list(range(len(bounded_objectives))), y=bounded_objectives, ax=objective_axis, color="#c2410c", linewidth=2.8, marker="X", linestyle="--", label="equality + bounds")
    objective_axis.set_yscale("log")
    objective_axis.set_title("Objective History")
    objective_axis.set_xlabel("iteration")
    objective_axis.set_ylabel("objective")
    objective_axis.legend(loc="upper right")

    sns.lineplot(x=list(range(len(equality_violations))), y=clipped_log_series(equality_violations), ax=violation_axis, color="#1d4ed8", linewidth=2.8, marker="o", label="equality-only")
    sns.lineplot(x=list(range(len(bounded_violations))), y=clipped_log_series(bounded_violations), ax=violation_axis, color="#c2410c", linewidth=2.8, marker="X", linestyle="--", label="equality + bounds")
    violation_axis.set_yscale("log")
    violation_axis.set_title("Constraint Violation History")
    violation_axis.set_xlabel("iteration")
    violation_axis.set_ylabel("max violation (clipped for log scale)")
    violation_axis.legend(loc="upper right")

    figure.savefig(output_path, format="svg", bbox_inches="tight")
    plt.close(figure)


def print_result(label: str, result_x: torch.Tensor, summary: str, active_set: tuple[str, ...], constraint_violation: float | None, kkt_residual: float | None) -> None:
    """Print a concise solver summary block.

    Parameters
    ----------
    label : str
        Human-readable solve label.
    result_x : torch.Tensor
        Final state.
    summary : str
        One-line result summary.
    active_set : tuple[str, ...]
        Active-set labels.
    constraint_violation : float | None
        Final constraint violation.
    kkt_residual : float | None
        Final KKT residual.
    """

    print(f"{label}: {summary}")
    print(f"  x = {result_x.tolist()}")
    print(f"  active_set = {active_set or ()}")
    print(f"  constraint_violation = {constraint_violation}")
    print(f"  kkt_residual = {kkt_residual}")


def main() -> None:
    """Run the constrained-optimization example and write the SVG artifact."""

    equality_problem, bounded_problem = build_problems()
    unconstrained_reference, equality_reference, bounded_reference = analytical_reference_points()
    start = torch.tensor([0.5, -0.5], dtype=torch.float64)
    equality_result = solve(
        equality_problem,
        x0=start,
        config=SolverConfig(method="sqp", max_iter=30, tol=1e-10, constrained_hessian_model="bfgs"),
    )
    bounded_result = solve(
        bounded_problem,
        x0=start,
        config=SolverConfig(method="sqp", max_iter=30, tol=1e-10, constrained_hessian_model="bfgs"),
    )

    if not equality_result.success:
        raise RuntimeError(f"Equality-only constrained solve failed.\n{equality_result.explanation()}")
    if not bounded_result.success:
        raise RuntimeError(f"Equality-plus-bounds constrained solve failed.\n{bounded_result.explanation()}")

    output_dir = Path(__file__).resolve().parent / "artifacts"
    output_dir.mkdir(parents=True, exist_ok=True)
    output_path = output_dir / "constrained_sqp_equality_bounds.svg"

    plot_example(
        start=start,
        equality_history=equality_result.history,
        bounded_history=bounded_result.history,
        equality_solution=equality_result.x,
        bounded_solution=bounded_result.x,
        unconstrained_reference=unconstrained_reference,
        equality_reference=equality_reference,
        bounded_reference=bounded_reference,
        output_path=output_path,
    )

    print("Constrained optimization example")
    print(f"Analytical unconstrained minimizer: {unconstrained_reference.tolist()}")
    print(f"Analytical equality-only reference: {equality_reference.tolist()}")
    print(f"Analytical bounded optimum: {bounded_reference.tolist()}")
    print_result(
        "Equality-only SQP",
        equality_result.x,
        equality_result.summary(),
        equality_result.active_set,
        equality_result.constraint_violation,
        equality_result.kkt_residual,
    )
    print_result(
        "Equality plus bounds SQP",
        bounded_result.x,
        bounded_result.summary(),
        bounded_result.active_set,
        bounded_result.constraint_violation,
        bounded_result.kkt_residual,
    )
    print(f"Wrote visualization: {output_path}")


if __name__ == "__main__":
    main()