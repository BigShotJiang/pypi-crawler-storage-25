"""Batch mode multi-sensor damped oscillator fitting.

This example demonstrates the current shared-structure batch-mode API for
fitting a nonlinear damped oscillator model to measurements from many sensors
simultaneously.

Problem setup
-------------
N_SENSORS independent sensors each record a damped sinusoid:

    y(t) = A * exp(-alpha * t) * cos(omega * t + phi) + noise

with four parameters per sensor: ``[A, alpha, omega, phi]``.  The true
parameters differ between sensors, mimicking a realistic multi-sensor
calibration scenario.

What this example demonstrates
------------------------------
1.  **Single API call** – no manual result bookkeeping or index juggling.
2.  **SharedStructureBatchResult** – per-instance diagnostics, stacked final
    states, and a one-line batch summary without any extra glue code.
3.  **Unified device-aware execution** – the shared-structure solver path runs
    as one batched least-squares solve on CPU or CUDA.
4.  **Timing comparison with caveats** – the batch API is now a real batched
    execution path, but speedup still depends on problem size, batch size,
    hardware, and whether detailed history capture is enabled.
"""

from __future__ import annotations

from pathlib import Path
from time import perf_counter

import matplotlib.pyplot as plt
import numpy as np
import seaborn as sns
import torch

from pytorch_nonlinear import BatchMode, NonlinearLeastSquaresProblem, SharedStructureBatchResult, SolverConfig, solve


# ---------------------------------------------------------------------------
# Problem settings
# ---------------------------------------------------------------------------

N_SENSORS = 64           # number of independent sensors in the batch
N_PLOT_SENSORS = 6       # number of example sensors shown in the figure
N_TIMEPOINTS = 200       # measurements per sensor
MAX_ITER = 60            # solver iteration budget
TOL = 1e-6               # convergence tolerance
SOLVER_METHOD = "lm"     # Levenberg-Marquardt for robustness across starts


# ---------------------------------------------------------------------------
# Data generation
# ---------------------------------------------------------------------------

def generate_sensor_data(
    n_sensors: int,
    n_timepoints: int,
    device: torch.device,
    *,
    seed: int = 0,
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    """Generate synthetic damped-oscillator observations for all sensors.

    Parameters
    ----------
    n_sensors : int
        Number of independent sensors.
    n_timepoints : int
        Number of time steps per sensor.
    device : torch.device
        Target device for the generated tensors.
    seed : int, optional
        Random seed for reproducibility.

    Returns
    -------
    t : torch.Tensor, shape (n_timepoints,)
        Shared time grid on ``device``.
    true_params : torch.Tensor, shape (n_sensors, 4)
        Ground-truth ``[A, alpha, omega, phi]`` per sensor on ``device``.
    y_obs : torch.Tensor, shape (n_sensors, n_timepoints)
        Noisy observations per sensor on ``device``.
    """

    rng = torch.Generator()
    rng.manual_seed(seed)

    t = torch.linspace(0.0, 10.0, n_timepoints, dtype=torch.float64, device=device)

    # True parameters: amplitude, decay rate, frequency, phase.
    # Drawn from realistic physical ranges so every instance is non-trivial.
    A = torch.empty(n_sensors, dtype=torch.float64).uniform_(0.5, 3.0, generator=rng)
    alpha = torch.empty(n_sensors, dtype=torch.float64).uniform_(0.1, 0.8, generator=rng)
    omega = torch.empty(n_sensors, dtype=torch.float64).uniform_(1.0, 4.0, generator=rng)
    phi = torch.empty(n_sensors, dtype=torch.float64).uniform_(0.0, torch.pi, generator=rng)
    true_params = torch.stack([A, alpha, omega, phi], dim=1).to(device)

    # Noiseless signal: (n_sensors, n_timepoints)
    signal = (
        true_params[:, 0:1]
        * torch.exp(-true_params[:, 1:2] * t.unsqueeze(0))
        * torch.cos(true_params[:, 2:3] * t.unsqueeze(0) + true_params[:, 3:4])
    )

    # Add small Gaussian noise on CPU then move to device
    noise = torch.randn(n_sensors, n_timepoints, dtype=torch.float64, generator=rng)
    noise = noise.to(device)
    y_obs = signal + 0.02 * noise

    return t, true_params, y_obs


# ---------------------------------------------------------------------------
# Problem definition (shared structure)
# ---------------------------------------------------------------------------

def build_oscillator_problem() -> NonlinearLeastSquaresProblem:
    """Build the damped-oscillator fitting problem.

    The residual function is shared across all batch instances.  The per-
    instance observations are passed via ``params["y_obs"]`` which the batch
    machinery automatically slices to a ``(n_timepoints,)`` vector for each
    solver instance.

    Returns
    -------
    NonlinearLeastSquaresProblem
        Problem whose residual maps ``state=[A, alpha, omega, phi]`` to the
        vector of prediction errors at every time step.
    """

    def residual(state: torch.Tensor, params: dict[str, torch.Tensor]) -> torch.Tensor:
        """Evaluate prediction error for one sensor.

        Parameters
        ----------
        state : torch.Tensor, shape (4,)
            Per-instance parameters ``[A, alpha, omega, phi]``.
        params : dict[str, torch.Tensor]
            Must contain:
            - ``"t"``:     shape ``(n_timepoints,)`` – shared time grid.
            - ``"y_obs"``: shape ``(n_timepoints,)`` – per-instance observations.

        Returns
        -------
        torch.Tensor, shape (n_timepoints,)
            Prediction minus observation at each time step.
        """

        t_grid = params["t"]
        y_observed = params["y_obs"]
        a_val, alpha_val, omega_val, phi_val = state[0], state[1], state[2], state[3]
        prediction = a_val * torch.exp(-alpha_val * t_grid) * torch.cos(omega_val * t_grid + phi_val)
        return prediction - y_observed

    return NonlinearLeastSquaresProblem(residual=residual)


# ---------------------------------------------------------------------------
# Solve helpers
# ---------------------------------------------------------------------------

def initial_guess(n_sensors: int, device: torch.device) -> torch.Tensor:
    """Return a shared initial guess for all sensor instances.

    Parameters
    ----------
    n_sensors : int
        Batch size (leading dimension of the returned tensor).
    device : torch.device
        Target device.

    Returns
    -------
    torch.Tensor, shape (n_sensors, 4)
        Repeated default starting point perturbed slightly per instance to
        avoid degenerate identical Jacobians across the batch.
    """

    rng = torch.Generator(device=device.type)
    rng.manual_seed(42)
    base = torch.tensor([1.5, 0.4, 2.5, 1.0], dtype=torch.float64, device=device)
    perturbation = torch.empty(n_sensors, 4, dtype=torch.float64, device=device).uniform_(-0.15, 0.15, generator=rng)
    return base.unsqueeze(0).expand(n_sensors, -1) + perturbation


def run_batch_mode(
    problem: NonlinearLeastSquaresProblem,
    x0_batch: torch.Tensor,
    t: torch.Tensor,
    y_obs: torch.Tensor,
    *,
    device_str: str,
) -> tuple[SharedStructureBatchResult, float]:
    """Run a single shared-structure batch solve and measure wall time.

    Parameters
    ----------
    problem : NonlinearLeastSquaresProblem
        Shared problem definition.
    x0_batch : torch.Tensor, shape (n_sensors, 4)
        Batched initial states.
    t : torch.Tensor, shape (n_timepoints,)
        Shared time grid.
    y_obs : torch.Tensor, shape (n_sensors, n_timepoints)
        Per-instance observations (batch dimension must match ``x0_batch``).
    device_str : str
        Device string passed to the solver configuration.

    Returns
    -------
    result : SharedStructureBatchResult
    elapsed : float
        Wall-clock time in seconds.
    """

    config = SolverConfig(
        method=SOLVER_METHOD,
        device=device_str,
        max_iter=MAX_ITER,
        tol=TOL,
        batch_mode=BatchMode.SHARED_STRUCTURE,
    )
    params_batch = {"t": t, "y_obs": y_obs}

    if device_str.startswith("cuda"):
        torch.cuda.synchronize()
    t_start = perf_counter()
    result = solve(problem, x0=x0_batch, params=params_batch, config=config)
    if device_str.startswith("cuda"):
        torch.cuda.synchronize()
    elapsed = perf_counter() - t_start

    return result, elapsed


def run_sequential_loop(
    problem: NonlinearLeastSquaresProblem,
    x0_batch: torch.Tensor,
    t: torch.Tensor,
    y_obs: torch.Tensor,
    *,
    device_str: str,
) -> tuple[list, float]:
    """Run N individual solves in a manual Python loop.

    This baseline mimics the boilerplate a user would write without the batch
    API and is used to contrast timing and code complexity.

    Parameters
    ----------
    problem : NonlinearLeastSquaresProblem
        Shared problem definition.
    x0_batch : torch.Tensor, shape (n_sensors, 4)
        Initial states; each row is used for one single solve.
    t : torch.Tensor, shape (n_timepoints,)
        Shared time grid.
    y_obs : torch.Tensor, shape (n_sensors, n_timepoints)
        Per-instance observations.
    device_str : str
        Device string.

    Returns
    -------
    results : list[SolveResult]
        One result per sensor.
    elapsed : float
        Total wall-clock time in seconds.
    """

    n_sensors = x0_batch.shape[0]
    config = SolverConfig(
        method=SOLVER_METHOD,
        device=device_str,
        max_iter=MAX_ITER,
        tol=TOL,
    )

    if device_str.startswith("cuda"):
        torch.cuda.synchronize()
    t_start = perf_counter()
    results = []
    for i in range(n_sensors):
        params_i = {"t": t, "y_obs": y_obs[i]}
        results.append(solve(problem, x0=x0_batch[i], params=params_i, config=config))
    if device_str.startswith("cuda"):
        torch.cuda.synchronize()
    elapsed = perf_counter() - t_start

    return results, elapsed


# ---------------------------------------------------------------------------
# Accuracy evaluation
# ---------------------------------------------------------------------------

def parameter_recovery_error(
    fitted: torch.Tensor, true_params: torch.Tensor
) -> torch.Tensor:
    """Compute per-sensor relative parameter recovery error.

    Parameters
    ----------
    fitted : torch.Tensor, shape (n_sensors, 4)
        Fitted parameter vectors.
    true_params : torch.Tensor, shape (n_sensors, 4)
        Ground-truth parameter vectors.

    Returns
    -------
    torch.Tensor, shape (n_sensors,)
        Per-sensor relative error ``||fitted - true|| / ||true||``.
    """

    diff = fitted - true_params
    return torch.linalg.norm(diff, dim=1) / torch.linalg.norm(true_params, dim=1)


# ---------------------------------------------------------------------------
# Visualization
# ---------------------------------------------------------------------------

def plot_batch_results(
    *,
    t: torch.Tensor,
    y_obs: torch.Tensor,
    true_params: torch.Tensor,
    batch_result: SharedStructureBatchResult,
    timing_records: list[dict],
    output_path: Path,
) -> None:
    """Write an SVG figure summarizing batch fitting results.

    The figure contains three panels:

    * **Left** – fitted curves for a representative sample of sensors
      overlaid on noisy observations and ground-truth signals.
    * **Centre** – per-sensor relative parameter recovery error.
    * **Right** – wall-clock timing comparison across solve strategies.

    Parameters
    ----------
    t : torch.Tensor, shape (n_timepoints,)
        Shared time grid.
    y_obs : torch.Tensor, shape (n_sensors, n_timepoints)
        Noisy observations.
    true_params : torch.Tensor, shape (n_sensors, 4)
        Ground-truth parameters.
    batch_result : SharedStructureBatchResult
        Batch solve result (used to extract fitted parameters).
    timing_records : list[dict]
        Records with keys ``"label"`` (str) and ``"time"`` (float).
    output_path : Path
        Destination SVG path.
    """

    sns.set_theme(style="whitegrid", context="talk")

    t_cpu = t.detach().cpu().numpy()
    fitted_all = batch_result.x.detach().cpu()
    true_cpu = true_params.detach().cpu()

    rel_errors = parameter_recovery_error(fitted_all, true_cpu).numpy()

    # --- Pick a handful of sensors to show individual fits ----------------
    n_show = N_PLOT_SENSORS
    palette = sns.color_palette("tab10", n_show)
    sample_indices = np.linspace(0, len(batch_result.results) - 1, n_show, dtype=int)

    figure, axes = plt.subplots(1, 3, figsize=(20, 6), constrained_layout=True)

    # Panel 1: sample fits
    ax_fits = axes[0]
    for plot_idx, sensor_idx in enumerate(sample_indices):
        y_noisy = y_obs[sensor_idx].detach().cpu().numpy()
        fp = fitted_all[sensor_idx]
        tp = true_cpu[sensor_idx]
        y_fit = (
            fp[0].item()
            * np.exp(-fp[1].item() * t_cpu)
            * np.cos(fp[2].item() * t_cpu + fp[3].item())
        )
        y_true_sig = (
            tp[0].item()
            * np.exp(-tp[1].item() * t_cpu)
            * np.cos(tp[2].item() * t_cpu + tp[3].item())
        )
        col = palette[plot_idx]
        ax_fits.plot(t_cpu, y_noisy, alpha=0.3, lw=1.0, color=col)
        ax_fits.plot(t_cpu, y_true_sig, lw=1.5, linestyle="--", color=col, alpha=0.7)
        ax_fits.plot(t_cpu, y_fit, lw=2.2, color=col, label=f"sensor {sensor_idx}")

    ax_fits.set_title("Sample Sensor Fits (batch result)")
    ax_fits.set_xlabel("time [s]")
    ax_fits.set_ylabel("signal")
    ax_fits.legend(fontsize=9, loc="upper right")

    # Panel 2: per-sensor recovery error
    ax_err = axes[1]
    ax_err.bar(range(N_SENSORS), rel_errors, color=sns.color_palette("crest", N_SENSORS), width=1.0)
    ax_err.axhline(float(np.median(rel_errors)), color="#c2410c", linestyle="--", linewidth=2, label=f"median={float(np.median(rel_errors)):.2e}")
    ax_err.set_title("Per-Sensor Parameter Recovery Error")
    ax_err.set_xlabel("sensor index")
    ax_err.set_ylabel("relative error ||Δθ|| / ||θ*||")
    ax_err.set_yscale("log")
    ax_err.legend()

    # Panel 3: timing comparison
    ax_time = axes[2]
    labels = [r["label"] for r in timing_records]
    times = [r["time"] for r in timing_records]
    bar_colors = [sns.color_palette("tab10")[i] for i in range(len(labels))]
    bars = ax_time.bar(labels, times, color=bar_colors, edgecolor="#111827", linewidth=0.8)
    for bar, val in zip(bars, times):
        ax_time.text(
            bar.get_x() + bar.get_width() / 2.0,
            bar.get_height() + 0.002 * max(times),
            f"{val:.3f}s",
            ha="center",
            va="bottom",
            fontsize=11,
        )
    ax_time.set_title(f"Illustrative Wall-Clock Time ({N_SENSORS} sensors)")
    ax_time.set_ylabel("time [s]")
    ax_time.set_xlabel("solve strategy")

    figure.savefig(output_path, format="svg", bbox_inches="tight")
    plt.close(figure)


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> None:
    """Run the batch mode sensor fitting example.

    Prints a console report comparing the batch API against a sequential
    manual loop, including timing, success rates, and parameter accuracy.
    Writes an SVG figure to ``examples/artifacts/``.
    """

    # ------------------------------------------------------------------
    # Device selection: prefer CUDA, fall back to CPU with a note.
    # ------------------------------------------------------------------
    if torch.cuda.is_available():
        device_str = "cuda"
        device = torch.device("cuda")
        print("Device: CUDA (GPU)")
    else:
        device_str = "cpu"
        device = torch.device("cpu")
        print("Device: CPU (CUDA not available – GPU speedup not demonstrated here)")
    print()

    # ------------------------------------------------------------------
    # Generate synthetic multi-sensor data
    # ------------------------------------------------------------------
    t, true_params, y_obs = generate_sensor_data(N_SENSORS, N_TIMEPOINTS, device)
    problem = build_oscillator_problem()
    x0_batch = initial_guess(N_SENSORS, device)

    print(f"Problem: {N_SENSORS} sensors × {N_TIMEPOINTS} time points × 4 parameters")
    print(f"Solver:  {SOLVER_METHOD.upper()}, max_iter={MAX_ITER}, tol={TOL:.0e}")
    print()

    # ------------------------------------------------------------------
    # Approach A: manual sequential loop (baseline)
    # ------------------------------------------------------------------
    print("Running sequential manual loop (baseline) …")
    seq_results, seq_time = run_sequential_loop(
        problem, x0_batch, t, y_obs, device_str=device_str
    )
    seq_successes = sum(int(r.success) for r in seq_results)
    seq_fitted = torch.stack([r.x for r in seq_results]).to("cpu")
    seq_errors = parameter_recovery_error(seq_fitted, true_params.cpu())

    # ------------------------------------------------------------------
    # Approach B: shared-structure batch API (recommended)
    # ------------------------------------------------------------------
    print("Running shared-structure batch API …")
    batch_result, batch_time = run_batch_mode(
        problem, x0_batch, t, y_obs, device_str=device_str
    )

    # ------------------------------------------------------------------
    # Report
    # ------------------------------------------------------------------
    batch_fitted = batch_result.x.to("cpu")
    batch_errors = parameter_recovery_error(batch_fitted, true_params.cpu())

    print()
    print("=" * 70)
    print("RESULTS")
    print("=" * 70)
    print(f"{'Metric':<35} {'Sequential':>15} {'Batch API':>15}")
    print("-" * 70)
    print(f"{'Wall-clock time (s)':<35} {seq_time:>15.3f} {batch_time:>15.3f}")
    print(f"{'Successes':<35} {seq_successes:>15}/{N_SENSORS} {batch_result.num_succeeded:>14}/{N_SENSORS}")
    print(f"{'Median param recovery error':<35} {float(seq_errors.median()):>15.2e} {float(batch_errors.median()):>15.2e}")
    print(f"{'Max param recovery error':<35} {float(seq_errors.max()):>15.2e} {float(batch_errors.max()):>15.2e}")
    print("=" * 70)

    print()
    print("Batch API summary:")
    print(" ", batch_result.summary())

    # Demonstrate stacked result access
    print()
    print("Batch result features:")
    print(f"  batch_result.x          → tensor shape {batch_result.x.shape}  (auto-stacked)")
    print(f"  batch_result.batch_size → {batch_result.batch_size}")
    print(f"  batch_result.success    → tuple of {len(batch_result.success)} bool flags")
    print(f"  batch_result.objective_value → tuple of {len(batch_result.objective_value)} values")

    # Show the observed timing ratio without claiming unconditional wins.
    if seq_time > 0 and batch_time > 0:
        speedup = seq_time / batch_time
        print()
        print(f"Observed timing ratio (sequential / batch): {speedup:.2f}x")
        print(
            "These timings are still workload-dependent. Shared-structure batching is now a real vectorized solver "
            "path, but the break-even point depends on device, batch size, residual dimension, and history-capture overhead."
        )

    print()
    print("Per-instance solve summary (first 8 sensors):")
    print(f"  {'sensor':>6}  {'status':>20}  {'iterations':>10}  {'obj_value':>12}  {'param_err':>10}")
    for i in range(min(8, N_SENSORS)):
        res = batch_result.results[i]
        print(
            f"  {i:>6}  {res.status.value:>20}  {res.num_iter:>10}  "
            f"{float(res.objective_value):>12.4e}  {float(batch_errors[i]):>10.2e}"
        )

    # ------------------------------------------------------------------
    # Visualization
    # ------------------------------------------------------------------
    timing_records = [
        {"label": f"Sequential\n({device_str.upper()})", "time": seq_time},
        {"label": f"Batch API\n({device_str.upper()})", "time": batch_time},
    ]

    output_dir = Path(__file__).resolve().parent / "artifacts"
    output_dir.mkdir(parents=True, exist_ok=True)
    output_path = output_dir / "batch_mode_sensor_fitting.svg"
    plot_batch_results(
        t=t,
        y_obs=y_obs,
        true_params=true_params,
        batch_result=batch_result,
        timing_records=timing_records,
        output_path=output_path,
    )
    print()
    print(f"Wrote visualization: {output_path}")


if __name__ == "__main__":
    main()
