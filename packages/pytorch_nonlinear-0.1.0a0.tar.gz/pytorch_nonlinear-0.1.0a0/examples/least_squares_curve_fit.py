"""Polynomial curve fitting with a seaborn visualization.

This example fits a quadratic curve with the Levenberg-Marquardt baseline and
writes a compact seaborn-based figure showing the fitted curve and objective
history.
"""

from __future__ import annotations

from pathlib import Path

import matplotlib.pyplot as plt
import seaborn as sns
import torch

from pytorch_nonlinear import NonlinearLeastSquaresProblem, SolverConfig, solve


def build_curve_fit_problem() -> tuple[NonlinearLeastSquaresProblem, dict[str, torch.Tensor]]:
    """Create a small dense least-squares curve-fitting problem.

    Returns
    -------
    tuple[NonlinearLeastSquaresProblem, dict[str, torch.Tensor]]
        Problem instance plus the parameter dictionary needed by the residual.
    """

    x_data = torch.linspace(-2.0, 2.0, 17, dtype=torch.float64)
    true_params = torch.tensor([1.5, -0.75, 0.25], dtype=torch.float64)
    y_data = true_params[0] * x_data**2 + true_params[1] * x_data + true_params[2] + 0.05 * torch.sin(3.0 * x_data)

    def residual(state: torch.Tensor, params: dict[str, torch.Tensor]) -> torch.Tensor:
        """Evaluate the residual vector for the quadratic fit.

        Parameters
        ----------
        state : torch.Tensor
            Quadratic coefficient vector ``[a, b, c]``.
        params : dict[str, torch.Tensor]
            Example data containing ``x_data`` and ``y_data``.

        Returns
        -------
        torch.Tensor
            Prediction error at each sample point.
        """

        prediction = state[0] * params["x_data"] ** 2 + state[1] * params["x_data"] + state[2]
        return prediction - params["y_data"]

    return NonlinearLeastSquaresProblem(residual=residual), {"x_data": x_data, "y_data": y_data}


def plot_curve_fit(
    *,
    x_data: torch.Tensor,
    y_data: torch.Tensor,
    fitted_params: torch.Tensor,
    objective_history: list[float],
    output_path: Path,
) -> None:
    """Plot the fitted curve and objective history with seaborn.

    Parameters
    ----------
    x_data : torch.Tensor
        Sample x coordinates.
    y_data : torch.Tensor
        Sample observations.
    fitted_params : torch.Tensor
        Fitted quadratic coefficient vector.
    objective_history : list[float]
        Objective values from the solver history.
    output_path : Path
        Output figure path.
    """

    sns.set_theme(style="whitegrid", context="talk")
    curve_x = torch.linspace(float(x_data.min()), float(x_data.max()), 200, dtype=torch.float64)
    curve_y = fitted_params[0] * curve_x**2 + fitted_params[1] * curve_x + fitted_params[2]
    iterations = list(range(1, len(objective_history) + 1))

    figure, axes = plt.subplots(1, 2, figsize=(12, 5), constrained_layout=True)

    sns.scatterplot(x=x_data.tolist(), y=y_data.tolist(), ax=axes[0], s=80, color="#0f766e", label="observations")
    sns.lineplot(x=curve_x.tolist(), y=curve_y.tolist(), ax=axes[0], linewidth=3, color="#c2410c", label="LM fit")
    axes[0].set_title("Quadratic Curve Fit")
    axes[0].set_xlabel("x")
    axes[0].set_ylabel("y")

    sns.lineplot(x=iterations, y=objective_history, ax=axes[1], marker="o", linewidth=2.5, color="#1d4ed8")
    axes[1].set_title("Objective History")
    axes[1].set_xlabel("iteration")
    axes[1].set_ylabel("0.5 * ||r||^2")

    figure.savefig(output_path, format="svg", bbox_inches="tight")
    plt.close(figure)


def main() -> None:
    """Run the curve-fitting example and write the figure artifact.

    Returns
    -------
    None
        The example writes an SVG artifact and prints a short summary.
    """

    problem, params = build_curve_fit_problem()
    initial_guess = torch.tensor([0.25, 0.25, 0.25], dtype=torch.float64)
    result = solve(problem, x0=initial_guess, params=params, config=SolverConfig(method="lm", max_iter=25, tol=1e-10))

    if not result.success:
        raise RuntimeError(result.explanation())

    output_dir = Path(__file__).resolve().parent / "artifacts"
    output_dir.mkdir(parents=True, exist_ok=True)
    output_path = output_dir / "least_squares_curve_fit.svg"
    plot_curve_fit(
        x_data=params["x_data"],
        y_data=params["y_data"],
        fitted_params=result.x,
        objective_history=[record.objective_value for record in result.history if record.objective_value is not None],
        output_path=output_path,
    )

    print(result.summary())
    print(f"Fitted parameters: {result.x.tolist()}")
    print(f"Wrote visualization: {output_path}")


if __name__ == "__main__":
    main()