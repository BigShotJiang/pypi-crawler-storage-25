"""Show a case where scaling helps least-squares convergence.

This example uses a deliberately badly scaled two-parameter least-squares
problem and compares two Levenberg-Marquardt solves from the same start:

- the default unscaled solve
- an automatically variable-scaled solve

On this problem, the unscaled run stalls because one variable direction
dominates the local model. Automatic variable scaling balances the metric,
reaches the true solution, and drives the objective to numerical zero. The
figure makes that difference visible through the optimization paths and
objective histories.
"""

from __future__ import annotations

from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import seaborn as sns
import torch

from pytorch_nonlinear import IterationRecord, NonlinearLeastSquaresProblem, ScalingConfig, ScalingMode, SolverConfig, solve


def build_badly_scaled_problem() -> NonlinearLeastSquaresProblem:
    """Build a two-parameter least-squares problem with poor scaling.

    Returns
    -------
    NonlinearLeastSquaresProblem
        Problem whose first residual dominates the local model unless the
        variable directions are scaled automatically.
    """

    def residual(state: torch.Tensor, params: None) -> torch.Tensor:
        """Evaluate the residual vector for the scaling demonstration.

        Parameters
        ----------
        state : torch.Tensor
            Dense state vector ``[x, y]``.
        params : None
            Unused placeholder required by the typed callback signature.

        Returns
        -------
        torch.Tensor
            Residual vector with intentionally mismatched sensitivity.
        """

        return torch.stack(
            (
                1e8 * (state[0] - 1.0),
                state[1] - 2.0,
            )
        )

    return NonlinearLeastSquaresProblem(residual=residual)


def objective_value(x_grid: np.ndarray, y_grid: np.ndarray) -> np.ndarray:
    """Evaluate the example objective on a grid.

    Parameters
    ----------
    x_grid : numpy.ndarray
        Meshgrid of x coordinates.
    y_grid : numpy.ndarray
        Meshgrid of y coordinates.

    Returns
    -------
    numpy.ndarray
        Objective values ``0.5 * ||r||^2`` over the grid.
    """

    residual_0 = 1e8 * (x_grid - 1.0)
    residual_1 = y_grid - 2.0
    return 0.5 * (residual_0**2 + residual_1**2)


def history_path(start: torch.Tensor, history: tuple[IterationRecord, ...]) -> np.ndarray:
    """Build a plotted path from accepted states or last trials.

    Parameters
    ----------
    start : torch.Tensor
        Starting point.
    history : tuple[IterationRecord, ...]
        Solver history.

    Returns
    -------
    numpy.ndarray
        Stacked path points in ``(x, y)`` coordinates.
    """

    points = [start.detach().cpu().reshape(-1).numpy()]
    for record in history:
        point = None
        if record.accepted and record.state is not None:
            point = record.state
        elif record.trials and record.trials[-1].state is not None:
            point = record.trials[-1].state
        elif record.state is not None:
            point = record.state
        if point is not None:
            points.append(point.detach().cpu().reshape(-1).numpy())
    return np.vstack(points)


def objective_history(start: torch.Tensor, history: tuple[IterationRecord, ...]) -> list[float]:
    """Collect a scalar objective history from solver records.

    Parameters
    ----------
    start : torch.Tensor
        Starting point.
    history : tuple[IterationRecord, ...]
        Solver history.

    Returns
    -------
    list[float]
        Objective values beginning at the initial point.
    """

    initial = float(0.5 * ((1e8 * (start[0] - 1.0)) ** 2 + (start[1] - 2.0) ** 2))
    values = [initial]
    for record in history:
        if record.objective_value is not None:
            values.append(record.objective_value)
    return values


def plot_scaling_effect(
    *,
    start: torch.Tensor,
    plain_history: tuple[IterationRecord, ...],
    scaled_history: tuple[IterationRecord, ...],
    output_path: Path,
) -> None:
    """Plot unscaled and scaled LM convergence.

    Parameters
    ----------
    start : torch.Tensor
        Shared starting point.
    plain_history : tuple[IterationRecord, ...]
        Unscaled LM history.
    scaled_history : tuple[IterationRecord, ...]
        Automatically scaled LM history.
    output_path : Path
        Output SVG path.
    """

    sns.set_theme(style="whitegrid", context="talk")
    figure, axes = plt.subplots(1, 2, figsize=(14, 5.5), constrained_layout=True)

    x_grid, y_grid = np.meshgrid(np.linspace(-0.2, 1.2, 320), np.linspace(-0.2, 2.4, 280))
    z_grid = objective_value(x_grid, y_grid)
    contour_levels = np.geomspace(max(float(z_grid.min()), 1e-8), float(z_grid.max()), 20)

    plain_path = history_path(start, plain_history)
    scaled_path = history_path(start, scaled_history)
    plain_objectives = objective_history(start, plain_history)
    scaled_objectives = objective_history(start, scaled_history)

    axes[0].contourf(x_grid, y_grid, z_grid, levels=contour_levels, cmap=sns.color_palette("crest", as_cmap=True), alpha=0.95)
    axes[0].contour(x_grid, y_grid, z_grid, levels=contour_levels, colors="white", linewidths=0.35, alpha=0.5)
    sns.lineplot(x=plain_path[:, 0], y=plain_path[:, 1], ax=axes[0], color="#c2410c", linewidth=2.5, marker="X", linestyle="--", label="unscaled")
    sns.lineplot(x=scaled_path[:, 0], y=scaled_path[:, 1], ax=axes[0], color="#1d4ed8", linewidth=2.8, marker="o", linestyle="-", label="scaled")
    axes[0].scatter([1.0], [2.0], s=90, color="#111827", label="reference")
    axes[0].set_title("Optimization Paths")
    axes[0].set_xlabel("x")
    axes[0].set_ylabel("y")
    axes[0].legend(loc="upper left")

    sns.lineplot(x=list(range(len(plain_objectives))), y=plain_objectives, ax=axes[1], color="#c2410c", linewidth=2.5, marker="X", linestyle="--", label="unscaled")
    sns.lineplot(x=list(range(len(scaled_objectives))), y=scaled_objectives, ax=axes[1], color="#1d4ed8", linewidth=2.8, marker="o", linestyle="-", label="scaled")
    axes[1].set_yscale("log")
    axes[1].set_title("Objective History")
    axes[1].set_xlabel("iteration")
    axes[1].set_ylabel("0.5 * ||r||^2")
    axes[1].legend(loc="upper right")

    figure.savefig(output_path, format="svg", bbox_inches="tight")
    plt.close(figure)


def main() -> None:
    """Run the scaling example and write the SVG artifact.

    Returns
    -------
    None
        The example writes an SVG artifact and prints concise solver results.
    """

    problem = build_badly_scaled_problem()
    start = torch.tensor([0.0, 0.0], dtype=torch.float64)

    plain_result = solve(problem, x0=start, params=None, config=SolverConfig(method="lm", max_iter=20, tol=1e-12))
    scaled_result = solve(
        problem,
        x0=start,
        params=None,
        config=SolverConfig(
            method="lm",
            max_iter=20,
            tol=1e-12,
            scaling=ScalingConfig(variable_mode=ScalingMode.AUTO),
        ),
    )

    output_dir = Path(__file__).resolve().parent / "artifacts"
    output_dir.mkdir(parents=True, exist_ok=True)
    output_path = output_dir / "least_squares_scaling_effect.svg"

    plot_scaling_effect(
        start=start,
        plain_history=plain_result.history,
        scaled_history=scaled_result.history,
        output_path=output_path,
    )

    print(f"Start: {start.tolist()}")
    print("method: levenberg-marquardt")
    print("scaled configuration: variable_mode=auto")
    print(f"Unscaled solve: {plain_result.summary()}")
    print(f"Scaled solve: {scaled_result.summary()}")
    print(f"Scaled reproducibility metadata: {scaled_result.reproducibility['scaling']}")
    print(f"Wrote visualization: {output_path}")


if __name__ == "__main__":
    main()