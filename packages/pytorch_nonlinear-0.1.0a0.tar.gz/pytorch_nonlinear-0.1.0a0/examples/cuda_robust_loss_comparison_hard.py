"""Visualize robust loss effects on a harder nonlinear GPU curve fit.

This example fits a five-parameter damped oscillation model on CUDA with
several loss functions. The model is nonlinear in amplitude, decay,
frequency, phase, and bias, and the observations contain a handful of large
outliers. Compared with the lighter robust-loss example, this setup produces a
clearer separation between squared and robust objectives while still
converging reliably with an example-appropriate tolerance.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import matplotlib.pyplot as plt
import seaborn as sns
import torch

from pytorch_nonlinear import CauchyLoss, HuberLoss, NonlinearLeastSquaresProblem, SolveResult, SoftL1Loss, SolverConfig, solve


COLORS = {
    "Squared": "#111827",
    "Huber": "#c2410c",
    "Cauchy": "#0f766e",
    "SoftL1": "#1d4ed8",
}


@dataclass(frozen=True)
class FitRun:
    """Concrete plotting payload for one fitted loss model."""

    result: SolveResult
    curve: torch.Tensor
    residuals: torch.Tensor
    weights: torch.Tensor


def damped_oscillation(state: torch.Tensor, x_data: torch.Tensor) -> torch.Tensor:
    """Evaluate a five-parameter damped oscillation model."""

    amplitude, decay, frequency, phase, bias = state
    return amplitude * torch.exp(-decay * x_data) * torch.sin(frequency * x_data + phase) + bias


def build_problem_bundle(device: str) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor, list[int], torch.Tensor]:
    """Build a harder nonlinear regression dataset with structured outliers."""

    x_data = torch.linspace(0.0, 6.5, 240, dtype=torch.float64, device=device)
    true_params = torch.tensor([1.45, 0.23, 2.35, 0.35, -0.1], dtype=torch.float64, device=device)
    clean_signal = damped_oscillation(true_params, x_data)

    generator = torch.Generator(device=device)
    generator.manual_seed(7)
    noisy_signal = clean_signal + 0.045 * torch.randn(clean_signal.shape, generator=generator, dtype=torch.float64, device=device)

    # Spread more large corruptions across the full trajectory so squared loss
    # is visibly pulled away from the underlying signal while robust losses
    # still have enough uncontaminated samples to recover the oscillation.
    outlier_indices = [14, 24, 38, 61, 84, 109, 127, 154, 176, 201, 214, 225]
    outlier_offsets = torch.tensor(
        [1.4, -1.7, 1.2, -1.5, 1.8, -1.9, 1.3, -1.7, 1.55, -1.4, 1.1, -1.6],
        dtype=torch.float64,
        device=device,
    )
    observations = noisy_signal.clone()
    observations[outlier_indices] = observations[outlier_indices] + outlier_offsets

    return x_data, observations, clean_signal, outlier_indices, true_params


def build_curve_fit_problem(loss: object | None = None) -> NonlinearLeastSquaresProblem:
    """Create the damped-oscillation least-squares problem."""

    def residual(state: torch.Tensor, params: dict[str, torch.Tensor]) -> torch.Tensor:
        prediction = damped_oscillation(state, params["x_data"])
        return prediction - params["y_data"]

    return NonlinearLeastSquaresProblem(residual=residual, loss=loss)


def loss_weights(loss_name: str, residuals: torch.Tensor) -> torch.Tensor:
    """Evaluate final per-sample weights for plotting."""

    if loss_name == "Squared":
        return torch.ones_like(residuals)
    if loss_name == "Huber":
        return HuberLoss(delta=0.2).weights(residuals)
    if loss_name == "Cauchy":
        return CauchyLoss(c=0.2).weights(residuals)
    if loss_name == "SoftL1":
        return SoftL1Loss(c=0.2).weights(residuals)
    raise ValueError(f"Unsupported loss label: {loss_name}")


def run_fit(
    *,
    loss_name: str,
    loss: object | None,
    x0: torch.Tensor,
    x_data: torch.Tensor,
    y_data: torch.Tensor,
    device: str,
) -> FitRun:
    """Run one nonlinear fit on CUDA and return plotting data."""

    params = {"x_data": x_data, "y_data": y_data}
    problem = build_curve_fit_problem(loss=loss)
    result = solve(
        problem,
        x0=x0,
        params=params,
        config=SolverConfig(method="lm", device=device, max_iter=60, tol=1e-6),
    )
    if not result.success:
        raise RuntimeError(f"{loss_name} fit failed: {result.explanation()}")

    fitted_curve = damped_oscillation(result.x, x_data)
    residuals = fitted_curve - y_data
    return FitRun(
        result=result,
        curve=fitted_curve,
        residuals=residuals,
        weights=loss_weights(loss_name, residuals.detach()),
    )


def plot_results(
    *,
    x_data: torch.Tensor,
    observations: torch.Tensor,
    clean_signal: torch.Tensor,
    outlier_indices: list[int],
    fits: dict[str, FitRun],
    output_path: Path,
) -> None:
    """Create the comparison visualization."""

    sns.set_theme(style="whitegrid", context="talk")
    figure, axes = plt.subplots(2, 2, figsize=(16, 10), constrained_layout=True)

    x_cpu = x_data.detach().cpu().tolist()
    observations_cpu = observations.detach().cpu().tolist()
    clean_cpu = clean_signal.detach().cpu().tolist()
    outlier_x = x_data[outlier_indices].detach().cpu().tolist()
    outlier_y = observations[outlier_indices].detach().cpu().tolist()

    sns.scatterplot(x=x_cpu, y=observations_cpu, ax=axes[0, 0], s=26, color="#475569", alpha=0.72, label="observations")
    sns.lineplot(x=x_cpu, y=clean_cpu, ax=axes[0, 0], linewidth=2.0, color="#94a3b8", linestyle="--", label="clean signal")
    axes[0, 0].scatter(outlier_x, outlier_y, s=95, color="#dc2626", marker="X", label="outliers")
    for loss_name, fit_data in fits.items():
        sns.lineplot(
            x=x_cpu,
            y=fit_data.curve.detach().cpu().tolist(),
            ax=axes[0, 0],
            linewidth=2.4,
            color=COLORS[loss_name],
            label=loss_name,
        )
    axes[0, 0].set_title("Hard CUDA Nonlinear Fit")
    axes[0, 0].set_xlabel("x")
    axes[0, 0].set_ylabel("y")

    sample_ids = list(range(len(x_cpu)))
    for loss_name, fit_data in fits.items():
        sns.lineplot(
            x=sample_ids,
            y=fit_data.weights.detach().cpu().tolist(),
            ax=axes[0, 1],
            linewidth=2.2,
            color=COLORS[loss_name],
            label=loss_name,
        )
    axes[0, 1].scatter(outlier_indices, [1.03] * len(outlier_indices), s=70, color="#dc2626", marker="X", label="outlier index")
    axes[0, 1].set_ylim(-0.02, 1.08)
    axes[0, 1].set_title("Final Sample Weights")
    axes[0, 1].set_xlabel("sample index")
    axes[0, 1].set_ylabel("IRLS weight")

    for loss_name, fit_data in fits.items():
        history = [record.objective_value for record in fit_data.result.history if record.objective_value is not None]
        if not history:
            history = [float(fit_data.result.objective_value)]
        sns.lineplot(
            x=list(range(1, len(history) + 1)),
            y=history,
            ax=axes[1, 0],
            linewidth=2.2,
            marker="o",
            color=COLORS[loss_name],
            label=loss_name,
        )
    axes[1, 0].set_yscale("log")
    axes[1, 0].set_title("Objective History")
    axes[1, 0].set_xlabel("iteration")
    axes[1, 0].set_ylabel("loss objective")

    absolute_residuals = {
        loss_name: fit_data.residuals.abs().detach().cpu().tolist() for loss_name, fit_data in fits.items()
    }
    for loss_name, residual_values in absolute_residuals.items():
        sns.lineplot(
            x=sample_ids,
            y=residual_values,
            ax=axes[1, 1],
            linewidth=2.0,
            color=COLORS[loss_name],
            label=loss_name,
        )
    axes[1, 1].scatter(outlier_indices, [max(max(values) for values in absolute_residuals.values()) * 1.02] * len(outlier_indices), s=70, color="#dc2626", marker="X", label="outlier index")
    axes[1, 1].set_title("Absolute Residuals After Fitting")
    axes[1, 1].set_xlabel("sample index")
    axes[1, 1].set_ylabel("|residual|")

    for axis in axes.reshape(-1):
        handles, labels = axis.get_legend_handles_labels()
        unique_labels: dict[str, object] = {}
        for handle, label in zip(handles, labels):
            if label not in unique_labels:
                unique_labels[label] = handle
        if unique_labels:
            axis.legend(unique_labels.values(), unique_labels.keys(), loc="best")

    figure.savefig(output_path, format="svg", bbox_inches="tight")
    plt.close(figure)


def main() -> None:
    """Run the hard CUDA robust-loss comparison and write the SVG artifact."""

    if not torch.cuda.is_available():
        raise RuntimeError("This example requires CUDA so the hard nonlinear robust-loss comparison runs on the GPU.")

    device = "cuda"
    x_data, observations, clean_signal, outlier_indices, true_params = build_problem_bundle(device)
    initial_guess = torch.tensor([1.1, 0.08, 1.8, -0.15, 0.15], dtype=torch.float64, device=device)

    fits = {
        "Squared": run_fit(loss_name="Squared", loss=None, x0=initial_guess, x_data=x_data, y_data=observations, device=device),
        "Huber": run_fit(loss_name="Huber", loss=HuberLoss(delta=0.2), x0=initial_guess, x_data=x_data, y_data=observations, device=device),
        "Cauchy": run_fit(loss_name="Cauchy", loss=CauchyLoss(c=0.2), x0=initial_guess, x_data=x_data, y_data=observations, device=device),
        "SoftL1": run_fit(loss_name="SoftL1", loss=SoftL1Loss(c=0.2), x0=initial_guess, x_data=x_data, y_data=observations, device=device),
    }

    output_dir = Path(__file__).resolve().parent / "artifacts"
    output_dir.mkdir(parents=True, exist_ok=True)
    output_path = output_dir / "cuda_robust_loss_comparison_hard.svg"
    plot_results(
        x_data=x_data,
        observations=observations,
        clean_signal=clean_signal,
        outlier_indices=outlier_indices,
        fits=fits,
        output_path=output_path,
    )

    print(f"Device: {device}")
    print(f"True parameters: {true_params.detach().cpu().tolist()}")
    print("loss | iterations | status | final_objective | fitted_parameters")
    for loss_name, fit_data in fits.items():
        result = fit_data.result
        print(
            f"{loss_name:>7} | {result.num_iter:>10} | {result.status.value:>16} | {float(result.objective_value):>15.6e} | {result.x.detach().cpu().tolist()}"
        )
    print(f"Wrote visualization: {output_path}")


if __name__ == "__main__":
    main()