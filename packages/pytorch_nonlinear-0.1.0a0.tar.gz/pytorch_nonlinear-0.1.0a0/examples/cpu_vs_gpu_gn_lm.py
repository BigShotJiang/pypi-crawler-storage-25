"""Compare CPU vs GPU runtime for GN, LM, and trust-region least squares.

The benchmark uses a weakly coupled high-multiplicity least-squares problem.
That keeps the problem numerically hard enough that both methods need many
iterations while still converging cleanly on CPU and CUDA.
"""

from __future__ import annotations

from pathlib import Path
from time import perf_counter

import matplotlib.pyplot as plt
import numpy as np
import seaborn as sns
import torch

from pytorch_nonlinear import NonlinearLeastSquaresProblem, SolverConfig, solve


BENCHMARK_CASES = (
    ("GN", "gn", "CPU", "cpu"),
    ("GN", "gn", "CUDA", "cuda"),
    ("LM", "lm", "CPU", "cpu"),
    ("LM", "lm", "CUDA", "cuda"),
    ("TR", "trust_region", "CPU", "cpu"),
    ("TR", "trust_region", "CUDA", "cuda"),
)
COLORS = {"GN": "#c2410c", "LM": "#0f766e", "TR": "#1d4ed8"}
LINE_STYLES = {"GN": ("-", "X"), "LM": ("--", "o"), "TR": (":", "s")}
MARKERS = {"CPU": "o", "CUDA": "X"}
BENCHMARK_DIM = 2500
BENCHMARK_MAX_ITER = 20
COUPLING_WEIGHT = 0.05
ROOT_POWER = 6


def build_chain_problem() -> NonlinearLeastSquaresProblem:
    """Return a weakly coupled large-scale least-squares problem."""

    def residual(state: torch.Tensor, params: None) -> torch.Tensor:
        return torch.cat((COUPLING_WEIGHT * (state[1:] - state[:-1]), (state - 1.0) ** ROOT_POWER))

    return NonlinearLeastSquaresProblem(residual=residual)


def time_solve(problem: NonlinearLeastSquaresProblem, x0: torch.Tensor, *, method: str, device: str, max_iter: int, tol: float) -> tuple[object, float]:
    """Run one solve and measure only the final wall-clock time."""

    if device == "cuda":
        torch.cuda.synchronize()
    start_time = perf_counter()
    result = solve(problem, x0=x0, params=None, config=SolverConfig(method=method, device=device, max_iter=max_iter, tol=tol))
    if device == "cuda":
        torch.cuda.synchronize()
    return result, perf_counter() - start_time


def result_residual(result: object) -> float:
    """Return the final residual norm for a least-squares solve result."""

    return float((2.0 * float(result.objective_value)) ** 0.5)


def projected_path_from_history(start: torch.Tensor, history: tuple) -> np.ndarray:
    """Project a solver trajectory onto the first two coordinates."""

    points = [start.detach().cpu().reshape(-1).numpy()[:2]]
    for record in history:
        point = None
        if record.accepted and record.state is not None:
            point = record.state
        elif record.trials and record.trials[-1].state is not None:
            point = record.trials[-1].state
        elif record.state is not None:
            point = record.state
        if point is not None:
            points.append(point.detach().cpu().reshape(-1).numpy()[:2])
    return np.vstack(points)


def benchmark_slice_objective_grid(reference_state: torch.Tensor) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Build a first-two-coordinate objective slice of the benchmark problem."""

    reference = reference_state.detach().cpu().reshape(-1).numpy()
    x_grid, y_grid = np.meshgrid(np.linspace(0.6, 7.2, 260), np.linspace(0.6, 7.2, 260))

    x2 = reference[2]
    coupling_head = COUPLING_WEIGHT * (y_grid - x_grid)
    coupling_next = COUPLING_WEIGHT * (x2 - y_grid)
    root_x = (x_grid - 1.0) ** ROOT_POWER
    root_y = (y_grid - 1.0) ** ROOT_POWER

    z_grid = 0.5 * (coupling_head**2 + coupling_next**2 + root_x**2 + root_y**2)
    return x_grid, y_grid, z_grid


def plot_surface(
    axis: plt.Axes,
    *,
    title: str,
    x_grid: np.ndarray,
    y_grid: np.ndarray,
    z_grid: np.ndarray,
    method_paths: dict[str, np.ndarray],
) -> None:
    """Plot method trajectories on a benchmark-problem slice."""

    levels = np.geomspace(max(float(z_grid.min()), 1e-6), max(float(z_grid.max()), 1e-5), 16)

    axis.contourf(x_grid, y_grid, z_grid, levels=levels, cmap=sns.color_palette("crest", as_cmap=True), alpha=0.95)
    axis.contour(x_grid, y_grid, z_grid, levels=levels, colors="white", linewidths=0.35, alpha=0.5)
    for method_label, path in method_paths.items():
        line_style, marker = LINE_STYLES[method_label]
        sns.lineplot(
            x=path[:, 0],
            y=path[:, 1],
            ax=axis,
            color=COLORS[method_label],
            marker=marker,
            linestyle=line_style,
            linewidth=1.5,
            label=method_label,
        )
    axis.scatter([1.0], [1.0], s=75, color="#111827", label="minimizer")
    axis.set_title(title)
    axis.set_xlabel("x")
    axis.set_ylabel("y")
    axis.legend(loc="upper left")


def plot_results(
    records: list[dict[str, float | str]],
    *,
    x_grid: np.ndarray,
    y_grid: np.ndarray,
    z_grid: np.ndarray,
    cpu_paths: dict[str, np.ndarray],
    cuda_paths: dict[str, np.ndarray],
    output_path: Path,
) -> None:
    """Plot final time/residual points and projected benchmark trajectories."""

    sns.set_theme(style="whitegrid", context="talk")
    figure, axes = plt.subplots(1, 3, figsize=(19, 5.5), constrained_layout=True)

    for record in records:
        axes[0].scatter(
            record["time"],
            record["residual"],
            s=180,
            color=COLORS[record["method"]],
            marker=MARKERS[record["device"]],
            edgecolors="#111827",
            linewidths=1.0,
        )
        axes[0].annotate(
            f"{record['method']} {record['device']}",
            (record["time"], record["residual"]),
            xytext=(8, 8),
            textcoords="offset points",
            fontsize=11,
        )

    axes[0].set_title("Final Residual vs Final Time")
    axes[0].set_xlabel("solve time [s]")
    axes[0].set_ylabel("final residual norm")
    min_residual = min(float(record["residual"]) for record in records)
    max_residual = max(float(record["residual"]) for record in records)
    if min_residual == max_residual:
        margin = max(abs(min_residual) * 0.1, 1e-12)
        axes[0].set_ylim(min_residual - margin, max_residual + margin)
    else:
        axes[0].set_ylim(0.9 * min_residual, 1.1 * max_residual)

    plot_surface(axes[1], title="CPU Surface Slice", x_grid=x_grid, y_grid=y_grid, z_grid=z_grid, method_paths=cpu_paths)
    plot_surface(axes[2], title="CUDA Surface Slice", x_grid=x_grid, y_grid=y_grid, z_grid=z_grid, method_paths=cuda_paths)

    figure.savefig(output_path, format="svg", bbox_inches="tight")
    plt.close(figure)


def main() -> None:
    """Run the benchmark and write the SVG artifact."""

    if not torch.cuda.is_available():
        raise RuntimeError("This example requires CUDA so it can compare CPU and GPU timings.")

    benchmark_problem = build_chain_problem()
    benchmark_start = torch.full((BENCHMARK_DIM,), 6.0, dtype=torch.float32)
    benchmark_start[0] = 7.0
    benchmark_start[1] = 4.0


    benchmark_results: dict[tuple[str, str], object] = {}
    benchmark_records: list[dict[str, float | str]] = []
    for method_label, method_name, device_label, device_name in BENCHMARK_CASES:
        result, elapsed = time_solve(
            benchmark_problem,
            benchmark_start,
            method=method_name,
            device=device_name,
            max_iter=BENCHMARK_MAX_ITER,
            tol=1e-10,
        )
        benchmark_results[(method_label, device_label)] = result
        benchmark_records.append(
            {
                "method": method_label,
                "device": device_label,
                "time": elapsed,
                "residual": result_residual(result),
                "objective": float(result.objective_value),
                "iterations": result.num_iter,
                "status": result.status.value,
            }
        )

    x_grid, y_grid, z_grid = benchmark_slice_objective_grid(benchmark_start)

    output_dir = Path(__file__).resolve().parent / "artifacts"
    output_dir.mkdir(parents=True, exist_ok=True)
    output_path = output_dir / "cpu_vs_gpu_gn_lm.svg"
    plot_results(
        benchmark_records,
        x_grid=x_grid,
        y_grid=y_grid,
        z_grid=z_grid,
        cpu_paths={
            "GN": projected_path_from_history(benchmark_start, benchmark_results[("GN", "CPU")].history),
            "LM": projected_path_from_history(benchmark_start, benchmark_results[("LM", "CPU")].history),
            "TR": projected_path_from_history(benchmark_start, benchmark_results[("TR", "CPU")].history),
        },
        cuda_paths={
            "GN": projected_path_from_history(benchmark_start, benchmark_results[("GN", "CUDA")].history),
            "LM": projected_path_from_history(benchmark_start, benchmark_results[("LM", "CUDA")].history),
            "TR": projected_path_from_history(benchmark_start, benchmark_results[("TR", "CUDA")].history),
        },
        output_path=output_path,
    )

    print(
        f"Benchmark problem: dim={BENCHMARK_DIM}, coupling={COUPLING_WEIGHT}, root_power={ROOT_POWER}, "
        f"start=(x0={benchmark_start[0].item():.1f}, x1={benchmark_start[1].item():.1f}, rest=6.0)"
    )
    print(f"Benchmark iteration budget: max_iter={BENCHMARK_MAX_ITER}")
    print("method | device | final_time_s | final_residual | final_objective | iterations | status")
    for record in benchmark_records:
        print(
            f"{record['method']:>6} | {record['device']:>4} | {record['time']:>12.4f} | {record['residual']:>14.6e} | "
            f"{record['objective']:>15.6e} | {record['iterations']:>10} | {record['status']}"
        )
    print(f"Wrote visualization: {output_path}")


if __name__ == "__main__":
    main()