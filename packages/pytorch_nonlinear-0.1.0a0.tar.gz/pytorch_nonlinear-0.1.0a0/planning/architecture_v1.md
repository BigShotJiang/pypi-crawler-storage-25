# Architecture v1

## Document Contract

- Audience: internal architecture and coding-agent implementation guidance only
- Update this file when: module ownership, runtime object boundaries, or subsystem interfaces change
- Do not use this file for: milestone completion notes or live validation progress

## Purpose

This document translates the master plan into an implementation-ready architecture for a PyTorch-native nonlinear optimization toolbox.

The architecture is designed to support four properties from the start:

- typed problem definitions rather than a monolithic `minimize()` core
- strong diagnostics and failure explanation as part of normal solver output
- batch- and GPU-aware execution without contaminating solver code with device-specific hacks
- explicit differentiation strategies with validity reporting

## Governing Decisions

### 1. Least squares is the first wedge

The initial architecture optimizes for nonlinear least squares first, then grows into smooth unconstrained and constrained NLP.

### 2. Typed internals, convenience wrapper outside

The canonical internal path is:

```python
problem -> solver -> result
```

The SciPy-like wrapper is an adapter layer, not the primary abstraction.

### 3. Linear algebra is a subsystem, not a helper function

All serious second-order methods depend on a clean linear algebra layer. Solvers should request linear solves from an interface, not call `torch.linalg.solve` directly.

### 4. Differentiation is explicit

Differentiation is not a side effect of implementation details. It is a strategy selected by configuration and reported by the result object.

### 5. Diagnostics are produced by design, not by debug logging

A failed solve without a useful diagnosis is treated as an incomplete implementation.

## Repository Layout

Recommended repository shape:

```text
repo/
  pyproject.toml
  README.md
  LICENSE
  src/
    torch_nonlinear/
      __init__.py
      api/
        __init__.py
        solve.py
        minimize.py
        layer.py
        config.py
      problem/
        __init__.py
        base.py
        least_squares.py
        smooth.py
        constrained.py
        evaluation.py
      variables/
        __init__.py
        tree.py
        packing.py
        selection.py
        state.py
      constraints/
        __init__.py
        base.py
        bounds.py
        equality.py
        inequality.py
      losses/
        __init__.py
        base.py
        robust.py
        weighting.py
      solvers/
        __init__.py
        base.py
        gauss_newton.py
        levenberg_marquardt.py
        lbfgs.py
        sqp.py
        interior_point.py
        registry.py
      steps/
        __init__.py
        trust_region.py
        line_search.py
        damping.py
        acceptance.py
      linear/
        __init__.py
        operators.py
        base.py
        direct.py
        iterative.py
        preconditioners.py
        diagnostics.py
      diff/
        __init__.py
        base.py
        unrolled.py
        implicit.py
        validity.py
        sensitivities.py
      diagnostics/
        __init__.py
        status.py
        history.py
        report.py
        explain.py
        events.py
        inspection.py
      batching/
        __init__.py
        mode.py
        shared_structure.py
        independent.py
      scaling/
        __init__.py
        base.py
        auto.py
        heuristics.py
      utils/
        __init__.py
        pytree.py
        tensor_checks.py
        device.py
        dtype.py
        enums.py
  tests/
    unit/
    integration/
    regression/
    gradient/
  examples/
  benchmarks/
  docs/
```

## Package Responsibilities

## `api/`

Public entry points and public configuration objects.

- `solve.py`: typed entry point that accepts problem objects
- `minimize.py`: convenience adapter for familiar user entry
- `layer.py`: `OptimizationLayer` integration for `nn.Module`
- `config.py`: user-facing solver, scaling, debug, and differentiation config dataclasses

Rule:

- `api/` may depend on everything below it.
- Nothing outside `api/` should depend on `api/`.

## `problem/`

Canonical problem definitions and evaluation protocols.

- `base.py`: common `Problem` protocol and shared metadata
- `least_squares.py`: residual-based problems
- `smooth.py`: unconstrained smooth minimization
- `constrained.py`: equality, inequality, and bounds composition
- `evaluation.py`: evaluation records used by solvers and diagnostics

Rule:

- Problem objects are lightweight, immutable, and side-effect free.
- Problem evaluation never mutates solver state.

## `variables/`

Structured variable handling.

- flatten and unflatten tensor trees
- retain names and block boundaries for diagnostics
- support partial optimization over selected leaves
- manage packed solver vectors plus structural metadata

This is essential because real PyTorch users optimize over structured tensor sets, not just single flat vectors.

## `constraints/`

Typed constraint objects and bound handling.

- encode semantics cleanly
- carry optional names and scaling hints
- expose shared shape-validation behavior

## `losses/`

Residual losses and weighting for least-squares problems.

- squared loss
- robust losses
- residual weighting abstractions

This package should remain independent of solver implementation details.

## `solvers/`

Top-level solver orchestration.

- manage iterations
- request problem evaluations
- build local models
- call step strategies and linear solvers
- produce final `SolveResult`

Each solver file owns one algorithm family, not a grab bag of variants.

## `steps/`

Step computation and acceptance policy.

- trust-region policy
- line-search policy
- damping updates
- ratio tests and acceptance decisions

This keeps solver files smaller and makes step logic reusable across methods.

Current implementation note:
Implementation coverage for this subsystem is tracked in `implementation_status_v1.md` and `github_issues_v1.md`.

## `scaling/`

Local-model scaling logic.

- variable scaling for dense least-squares directions
- residual scaling for dense least-squares rows
- automatic heuristics for large-magnitude spreads
- reproducibility metadata for the applied scales

Current implementation note:
Implementation coverage for this subsystem is tracked in `implementation_status_v1.md` and `github_issues_v1.md`.

## `linear/`

Linear operator and solver layer.

- dense and matrix-free operator interfaces
- direct and iterative solvers
- preconditioner hooks
- linear-system diagnostics

Current implementation note:
Implementation coverage for this subsystem is tracked in `implementation_status_v1.md` and `github_issues_v1.md`.

The rest of the system should never care whether a step came from a dense factorization or a Krylov method.

## `diff/`

Differentiation strategies.

- unrolled differentiation
- implicit differentiation
- gradient validity checks
- sensitivity-related utilities

This package consumes optimality data produced by solvers; it should not control solver iteration logic.

## `diagnostics/`

Result statuses, history capture, inspection, and explainability.

- status enums
- history storage format
- diagnosis rules
- human-readable explanation rendering
- pre-flight inspection helpers

Diagnostics should be deterministic given solver history and configuration.

## `batching/`

Execution policy for repeated solves.

- shared-structure vectorized execution
- independent same-shape batched execution

This package should enforce explicit batching semantics rather than letting implicit broadcasting create undefined behavior.

Current architectural rule for shared-structure least-squares execution:

- normalize direct solves to the same leading-batch core used by shared-structure solves
- keep batching-mode differences at input normalization and output finalization boundaries
- do not reintroduce per-instance Python solve loops into the hot path
- keep runtime parameter preparation and diagnostic materialization outside the tight inner iteration path when possible

## `scaling/`

Variable, residual, and constraint scaling.

- auto-scaling heuristics
- user-supplied scaling rules
- scaling metadata passed to diagnostics

## Core Runtime Objects

The initial implementation should define the following core dataclasses or protocols.

## 1. `VariableSpec`

Describes one logical optimization block.

Fields:

- `name`
- `shape`
- `dtype`
- `device`
- `requires_grad`
- `slice_in_packed_vector`

## 2. `PackedState`

Represents the current optimization variables in both packed and structured form.

Fields:

- `flat`
- `tree`
- `specs`
- `batch_shape`

Invariants:

- `flat` is the canonical state for solver updates
- `tree` is reconstructed lazily or cached
- shape metadata is stable across the solve

## 3. `ProblemEvaluation`

Captures a problem evaluation at the current state.

Fields:

- `objective_value`
- `residual`
- `gradient`
- `constraint_values`
- `jacobian_info`
- `hvp_operator`
- `aux`

Notes:

- not all fields are populated for all problem types
- fields can be dense tensors or operator wrappers

## 4. `Linearization`

Represents the local model used to compute a step.

Fields:

- `gradient`
- `normal_operator` or `kkt_operator`
- `rhs`
- `model_metadata`

This object is the handoff between a solver and the `linear/` package.

## 5. `StepProposal`

Stores a candidate step and its local-model metadata.

Fields:

- `delta`
- `predicted_reduction`
- `step_norm`
- `trust_radius_used`
- `linear_diagnostics`

## 6. `IterationRecord`

One row of history.

Fields:

- `iteration`
- `objective_value`
- `gradient_norm`
- `constraint_violation`
- `step_norm`
- `accepted`
- `reason`
- `linear_iterations`

## 7. `SolveState`

Mutable solver-owned state for the current run.

Fields:

- `x`
- `iteration`
- `trust_radius`
- `lambda_damping`
- `history`
- `best_seen`
- `termination_flags`

Rule:

- only solver implementations mutate `SolveState`

## 8. `SolveResult`

Final user-facing result object.

Fields:

- solution fields
- termination fields
- diagnostics
- differentiation validity fields
- reproducibility metadata
- optional plots/explanation adapters

## 9. `InspectionReport`

Output of pre-flight analysis before solving.

Fields:

- `problem_class`
- `scale_warnings`
- `feasibility_warnings`
- `estimated_conditioning`
- `solver_recommendation`
- `notes`

## Key Protocols

Minimal protocols that should exist before serious solver work begins:

```python
class Problem(Protocol):
    def evaluate(self, state: PackedState, params: Any) -> ProblemEvaluation: ...


class Solver(Protocol):
    def solve(self, problem: Problem, x0: Any, params: Any, config: SolverConfig) -> SolveResult: ...


class LinearSolver(Protocol):
    def solve(self, system: Linearization, config: LinearSolveConfig) -> StepProposal: ...


class DiffStrategy(Protocol):
    def attach(self, result: SolveResult, context: Any) -> SolveResult: ...
```

These interfaces should remain stable even if implementations evolve.

## Dependency Rules

The following dependency constraints should be enforced deliberately.

### Allowed directions

- `api -> problem, solvers, diff, diagnostics, batching, scaling`
- `solvers -> problem, steps, linear, diagnostics, scaling`
- `steps -> linear, diagnostics`
- `diff -> problem, linear, diagnostics`
- `diagnostics -> problem, linear`

### Disallowed directions

- `linear` must not depend on `solvers`
- `problem` must not depend on `solvers`
- `diagnostics` must not import `api`
- `losses` and `constraints` must not depend on concrete solvers

These rules are important because they preserve testability and prevent the package from collapsing into one tightly coupled solver core.

## End-to-End Solve Flow

The typed solve path should look like this.

### Stage 1: input normalization

- validate problem object
- pack `x0`
- normalize config
- infer batch mode
- run optional `inspect_problem()`

### Stage 2: initialize solver state

- choose default step and linear solver policies
- initialize trust radius or damping
- allocate history storage

### Stage 3: iterate

Each iteration performs:

1. evaluate problem at current state
2. compute local linearization
3. solve step subproblem through `linear/`
4. accept or reject step through `steps/`
5. record diagnostics
6. check termination

### Stage 4: finalize

- compute final constraint/KKT statistics if applicable
- attach differentiation metadata
- build explanation text if requested
- return `SolveResult`

## Least-Squares Solver Slice

The first serious implementation slice should support:

- dense batched Jacobians for moderate-size problems
- Gauss-Newton
- Levenberg-Marquardt
- optional trust-region adaptation
- robust losses through residual reweighting

The least-squares path should be optimized around the following decomposition:

```python
residual -> weighted residual -> Jacobian information -> normal equations or operator -> step
```

This structure creates a clean path to later matrix-free and iterative methods.

## Constrained Solver Slice

Constrained NLP should be added only after the least-squares stack is stable.

The equality-and-bounds path should use:

- typed constraints
- KKT linearization
- SQP outer loop
- trust-region or filter-style step acceptance later if needed

The inequality path should use:

- first-class `InequalityConstraint` objects at the problem boundary
- explicit slack handling only as internal solver state when useful
- SQP-compatible feasibility and active-set handling first
- feasibility diagnostics

The architecture should not reduce inequality support to a public equality-with-slacks formulation. That reduction inflates the working problem, obscures which original constraints are active or violated, and makes later scaling, batching, and diagnostic reporting less direct. Reuse only the stable M8 constrained helpers that genuinely transfer, but keep the public model and result surfaces expressed in the original inequality coordinates.

For implementation ownership, extending the current dense SQP constrained path to cover inequalities is acceptable because it stays within one solver family. If a later interior-point method is added, keep it as a separate solver-family implementation and share only stable constrained evaluation, scaling, certification, and result-construction helpers. If either path requires new diagnostics or config fields for feasibility, active-set state, restoration, complementarity, or method control, add the minimum first-class surface needed rather than encoding those concepts only in freeform messages.

For stabilization ownership, constrained scaling should be supported by both solver families, because both SQP and interior-point can become misleading or brittle without it. Preconditioning should be owned where it becomes technically real: usually the interior-point path or any constrained method that actually introduces iterative solves, not the dense SQP baseline by default.

If the later interior-point path is implemented, it should handle equality, inequality, bounds, and mixed constrained problems through one coherent solver family rather than becoming an inequality-only side path with separate mixed-constraint fallbacks.

## Batching Semantics

Batching needs strict semantics from the start.

## `shared_structure`

Use this when all batch elements share:

- variable structure
- residual/constraint shapes
- algorithm path

This is the preferred GPU path.

## `independent`

Use this when shapes are compatible but per-instance behavior or histories must remain logically separate.

The solver implementation may still use batched tensor operations internally, but results and diagnostics are reported per instance.

## Device and Dtype Policy

Core rules:

- variables stay on user-provided device unless explicitly promoted
- solver defaults must never silently move data between CPU and GPU
- higher precision for linear solves must be explicit and reportable
- every `SolveResult` must record evaluation dtype and solve dtype

## Diagnostics Architecture

Diagnostics should be split into three levels.

## Level 1: raw measurements

- norms
- residuals
- predicted vs actual reduction
- linear residuals
- trust radius history

## Level 2: interpreted diagnosis

Examples:

- `poor_scaling`
- `likely_rank_deficient_jacobian`
- `line_search_stagnation`
- `infeasible_constraints`
- `ill_conditioned_kkt_system`

## Level 3: user explanation

Human-readable recommendation strings derived from level 2 diagnoses.

Example:

"Convergence stalled because the residual Jacobian appears nearly rank-deficient near the current iterate. Try better initialization, stronger damping, or variable scaling."

## Differentiation Architecture

Differentiation attaches after the solve, not during each solver step.

The solver must emit enough context for the selected strategy to work:

- final linearization
- convergence state
- relevant multipliers or normal-equation objects
- retained unrolled history if requested

The `diff/` package then:

- selects the actual strategy
- validates assumptions
- registers backward behavior or reports why it cannot

## Testing Architecture

The test layout should mirror the product risks.

## Unit tests

- variable packing
- constraint validation
- robust losses
- linear solver wrappers
- status and diagnosis rules

## Integration tests

- end-to-end least squares
- weighted and robust least squares
- batched shared-structure solves
- equality/bounds solves once available

## Gradient tests

- unrolled gradients vs finite differences
- implicit gradients vs unrolled references on small problems
- invalid implicit differentiation cases report cleanly

## Regression tests

- convergence pathologies discovered in benchmarks
- previously failing initialization or scaling cases

## Initial Build Cut

The first implementation cut should include only these runtime objects and packages:

- `api`
- `problem`
- `variables`
- `losses`
- `solvers` with Gauss-Newton and LM only
- `linear` with dense direct solve only
- `diagnostics`
- `batching` with `shared_structure` only

Everything else should be stubbed or deferred until the core slice is correct.

## Deferred Until After v0.1 Core

- SQP
- interior-point
- iterative linear solvers
- independent batch mode
- full inspection engine
- advanced scaling heuristics
- higher-order differentiation guarantees

## Non-Negotiable Invariants

The architecture should preserve these invariants throughout implementation.

1. Problem objects remain declarative.
2. Solver outputs always include structured diagnostics.
3. No solver contains hidden device transfers.
4. Differentiation validity is always explicit in results.
5. Step computation is separable from linear algebra backend.
6. Convenience APIs never dictate internal structure.

If a design choice violates one of these invariants, the design choice should lose.