# Implementation Status v1

This is the live execution tracker for the repository.

If there is any ambiguity between planning files, this file is the operational source of truth for:

- what is completed
- what is partially implemented but still needs validation
- what is currently in progress
- what is next and unblocked
- what remains in scope so no feature is lost

## Document Contract

- Audience: internal development and coding-agent execution only
- Update this file when: implementation state, milestone completion, validation evidence, current gate, or next unblocked work changes
- This file owns: aggregate status counts, milestone state, current gate, next-work ordering, and scope-protection rules
- This file does not own: milestone definitions, long-term product thesis, or deep architectural rationale

## Companion Documents

This is the only planning document that should carry aggregate project state.

- `plan_v1.md`: product strategy and long-term direction
- `architecture_v1.md`: target codebase shape and interfaces
- `github_issues_v1.md`: issue metadata, dependencies, and per-issue evidence

## Synchronization Order

When work status changes, update companion documents in this order:

1. `implementation_status_v1.md`
2. `github_issues_v1.md`

## Status Vocabulary

- `done`: implemented and validated against the stated acceptance criteria
- `implemented_needs_validation`: code or artifact exists, but executable validation is still incomplete
- `in_progress`: actively being worked on
- `planned`: not started yet
- `blocked`: cannot proceed until a dependency or decision is resolved

## Current Summary

As of 2026-05-05:

- `done`: 23
- `implemented_needs_validation`: 0
- `in_progress`: 0
- `planned`: 2
- `blocked`: 0

## Milestone Status

| Milestone | Scope | Status | Issue Coverage | Notes |
| --- | --- | --- | --- | --- |
| M0 | Repository and tooling spine | done | #1, #2 | Editable install succeeded, the test suite passed, and the benchmark harness wrote a timestamped JSON report under `benchmarks/results/`. |
| M1 | Typed problems and variable packing | done | #3, #4, #5 | Typed problem classes, constraints, and packing helpers are implemented and covered by executable tests. |
| M2 | Result object and diagnostics spine | done | #6, #7 | Result/history schema, serialization support, and explanation rendering are implemented and test-covered. |
| M3 | Nonlinear least squares core | done | #8, #9, #10 | Dense least-squares evaluation, Gauss-Newton, and Levenberg-Marquardt are implemented, test-covered, and exercised by a visualization example. |
| M4 | Linear solver abstraction | done | #11, #12 | Backend interfaces plus dense-direct and Cholesky implementations are in place; least-squares steps now route through the backend boundary, and solver-facing results and histories now expose linear residual and conditioning diagnostics. |
| M5 | Trust region, scaling, stabilization | done | #13, #14 | Dense least-squares now supports trust-region acceptance, auto/manual local-model scaling including residual-row application, poor-scaling diagnoses, and scaling reproducibility metadata. |
| M6 | Batched GPU execution | done | #15, #19 | Shared-structure least-squares now runs through one leading-batch solver core for single and batched execution, dense backends and trust-region policy accept batched systems, the benchmark harness records real CPU/CUDA workloads including history-capture overhead, and the shared-structure sensor-fitting example reflects the real vectorized path. |
| M7 | Differentiation and sensitivity | done | #16, #17 | Unrolled least-squares differentiation and a conservative implicit least-squares baseline are implemented, validated, and explicitly report differentiation validity in results. |
| M8 | Equality and bounds constrained NLP | done | #18 | A dense single-instance SQP baseline now solves equality-and-bounds constrained tensor problems through the typed `solve()` entry point with BFGS or exact dense Hessian models, dense-direct KKT solves, active-bound-aware KKT certification, and focused executable coverage across equality-only, bounds-only, mixed equality-plus-bounds, inactive-constraint, redundant-equality, fixed-variable, near-active-bound, structured failure, and CPU-oriented dense cases. |
| M9 | SQP inequality extension | done | #20, #21 | The dense SQP baseline now supports first-class `InequalityConstraint` objects, inequality feasibility and active-set diagnostics, structured fail-closed behavior, explicit constrained scaling with reproducibility metadata, near-active inactive inequality reporting that no longer overstates activity, and expanded mixed-regime certification coverage across converged, max-iter, and fail-closed cases. Constrained differentiation remains out of scope and continues to report unsupported semantics explicitly. |
| M10 | Interior-point solver | done | #22 | A separate dense primal-dual interior-point solver now exists for equality, inequality, bounds, and mixed constrained problems, with dedicated scaling, structured telemetry, focused regression coverage, and matched benchmark/profile support on CPU and CUDA. |
| M11 | Release preparation | planned | #23, #24, #25 | This milestone packages the constrained stack for external use through examples, benchmarks, release-facing docs, the now-recorded performance analysis of the current interior-point runtime gap versus SQP, and follow-on exploration of quasi-Newton interior-point curvature models when that analysis justifies them. |

## Issue Status Ledger

| Issue | Title | Status | Evidence | Next Action |
| --- | --- | --- | --- | --- |
| #1 | Bootstrap package skeleton and CI | done | Editable install passed; `pytest` passed; CI workflow exists under `.github/workflows/ci.yml`. | Keep CI green as new code lands. |
| #2 | Add benchmark harness and result schema | done | `benchmarks/run_benchmarks.py`; first report written under `benchmarks/results/`. | Extend the harness with real workloads in M3. |
| #3 | Implement structured variable packing | done | `src/torch_nonlinear/variables/state.py`; `tests/unit/test_variable_packing.py` passed. | Extend packing once tensor-backed states arrive. |
| #4 | Add typed problem classes | done | `src/torch_nonlinear/problem/`; `tests/unit/test_problem_models.py` passed. | Keep the public shape stable while M3 starts. |
| #5 | Add typed constraints and bounds | done | `src/torch_nonlinear/constraints/`; validation/evaluation tests passed. | Extend metadata only when solver usage requires it. |
| #6 | Implement solve status and result schema | done | `src/torch_nonlinear/diagnostics/`; `tests/unit/test_diagnostics.py` passed. | Reuse this schema for solver outputs in M3. |
| #7 | Add iteration history and explanation scaffolding | done | `src/torch_nonlinear/diagnostics/explain.py`; explanation and serialization tests passed. | Expand explanations once real solver histories exist. |
| #8 | Implement dense least-squares evaluation path | done | `src/torch_nonlinear/solvers/least_squares.py`; `tests/unit/test_least_squares_solvers.py` passed. | Reuse this local model for the M4 linear backend boundary. |
| #9 | Implement Gauss-Newton baseline solver | done | `solve()` now dispatches to a dense Gauss-Newton path with structured failure reporting; regression tests passed. | Route the linear solve through the upcoming backend interface in M4. |
| #10 | Implement Levenberg-Marquardt damping policy | done | Damped solve path, rejection handling, and iteration diagnostics are implemented; the curve-fit example generated `examples/artifacts/least_squares_curve_fit.svg`. | Preserve damping semantics while decoupling linear algebra in M4. |
| #11 | Introduce linear solver abstraction | done | `src/torch_nonlinear/linear/backends.py`; `SolverConfig(linear_solver=...)`; 10 focused least-squares tests passed. | Reuse this interface for additional dense and matrix-free backends. |
| #12 | Refactor least-squares solvers onto linear backends | done | `src/torch_nonlinear/solvers/least_squares.py` now requests GN/LM steps through `LinearSolver`; `SolveResult`, `IterationRecord`, and `TrialRecord` now expose linear residual and conditioning metrics; focused solver/diagnostics tests passed. | Use the completed backend-driven slice as the base for trust-region robustness. |
| #13 | Add trust-region acceptance logic | done | `src/torch_nonlinear/steps/trust_region.py` now provides the dense trust-region subproblem policy; `src/torch_nonlinear/solvers/least_squares.py` exposes `method="trust_region"`; focused solver and diagnostics tests passed with 15 tests, including a difficult Rosenbrock start where trust-region converges inside the budget and LM-only does not. | Start #14, scaling interfaces and auto-scaling heuristics. |
| #14 | Add scaling interfaces and auto-scaling heuristics | done | `ScalingConfig` and `ScalingMode` now expose manual and automatic least-squares scaling controls; `src/torch_nonlinear/scaling/least_squares.py` applies both variable and residual-row local-model scaling and surfaces poor-scaling diagnoses plus reproducibility metadata; the full suite passed after the residual-scaling fix. | Start #15, shared-structure batch mode. |
| #15 | Implement shared-structure batch mode | done | `src/torch_nonlinear/api/solve.py` now routes both direct and shared-structure least-squares solves into one leading-batch solver core in `src/torch_nonlinear/solvers/least_squares.py`; `src/torch_nonlinear/linear/backends.py` and `src/torch_nonlinear/steps/trust_region.py` now accept batched systems; `tests/unit/test_least_squares_solvers.py` now validates shared-structure equivalence plus single-vs-batch-size-one equivalence; `benchmarks/run_benchmarks.py` now records real shared-structure CPU/CUDA timing data in timestamped JSON reports under `benchmarks/results/`; `examples/batch_mode_sensor_fitting.py` now describes the real batched path honestly. | Start #17, implicit differentiation baseline. |
| #19 | Add explicit solver device selection policy | done | `SolverConfig(device=...)`; recursive parameter placement; least-squares device metadata; CPU/CUDA placement coverage. | Reuse this device policy when batched and backend-driven execution lands. |
| #16 | Implement unrolled differentiation path | done | `src/torch_nonlinear/solvers/least_squares.py` now preserves autograd connectivity when `diff_mode=unroll`; `tests/unit/test_least_squares_solvers.py` verifies finite-difference gradient agreement and shared-structure batch-vs-sequential unrolled gradient agreement; `examples/learned_range_sensor_fusion.py` demonstrates a practical learned optimization layer trained through the unrolled least-squares solve path. | M7 is now complete; proceed to #18. |
| #17 | Implement implicit differentiation baseline | done | `src/torch_nonlinear/diff/least_squares.py` now attaches a conservative exact-stationarity implicit backward rule for certifiable least-squares results; `SolveResult` now surfaces implicit validity plus conditioning and linear-residual diagnostics; focused solver, diagnostics, and M6 pressure tests passed. | Start #18, equality and bounds constrained SQP baseline. |
| #18 | Add equality and bounds constrained SQP baseline | done | `src/torch_nonlinear/solvers/constrained_nlp.py`; `solve()` now dispatches constrained NLP problems; constrained SQP tests passed with mixed equality-plus-bounds, inactive-constraint, redundant-equality, fixed-variable, near-active-bound, and structured failure coverage (`10 passed`); adjacent problem/diagnostics/import tests passed (`10 passed`); existing least-squares regressions stayed green (`104 passed`). | Use the closed M8 baseline as the compatibility surface for Issue #20. |
| #20 | Extend dense SQP to inequality constraints | done | `src/torch_nonlinear/solvers/constrained_nlp.py` now accepts first-class inequalities, reports inequality feasibility/active-set/complementarity-aware diagnostics, keeps constrained differentiation explicitly unsupported, and integrates dense constrained scaling metadata; `tests/unit/test_constrained_nlp_solvers.py` passed with 29 focused constrained tests including nonlinear active inequality, poor-start mixed constraints, degenerate fail-closed behavior, auto scaling, and a direct-inequality versus public-slack-reduction comparison; full `pytest` passed (`252 passed`). | Start #21, mixed constrained compatibility and certification hardening. |
| #21 | Harden SQP mixed constrained compatibility and certification | done | `src/torch_nonlinear/solvers/constrained_nlp.py` now uses a tighter reporting tolerance for active-set diagnostics so near-active but inactive constraints are not mislabeled active; `tests/unit/test_constrained_nlp_solvers.py` passed with 32 focused constrained tests including mixed near-active inactive inequality reporting, mixed max-iter termination without false step rejection, and a mixed equality-plus-inequality-plus-bounds degenerate fail-closed case with structured diagnoses; full `pytest` passed (`255 passed`). | Start #22, the separate interior-point solver milestone. |
| #22 | Add full interior-point constrained solver | done | `src/torch_nonlinear/solvers/interior_point/` now implements a separate dense primal-dual interior-point method with exact Lagrangian Hessians, slack/complementarity residuals, globalization, scaling, linear certification, and deferred telemetry; `tests/unit/test_interior_point_solvers.py` passed with `22 passed`; constrained benchmark/profile harnesses were extended to run `interior_point`; matched mixed CPU/CUDA reports and xlarge exact-comparison artifacts were generated under `benchmarks/results/`. | Use the completed IP solver as the comparison surface for Issue #24 and the release-facing documentation in Issue #23. |
| #23 | Publish constrained examples, benchmarks, and release docs | planned | Planned in `github_issues_v1.md` and `plan_v1.md` as the M11 release-preparation slice that follows the solver milestones. | After the quasi-Newton decision in #25, add example and benchmark evidence, document solver-selection tradeoffs, and document that constrained differentiation remains unsupported. |
| #24 | Analyze interior-point runtime gap versus SQP exact and BFGS | done | `benchmarks/results/2026-05-05_issue24_ip_runtime_analysis.md` now records the matched four-rung and xlarge comparisons plus current-branch xlarge CUDA profiles for `interior_point` and `sqp` exact; the analysis shows the gap to SQP exact is mainly iteration count, while the gap to SQP BFGS is mainly per-iteration cost from the exact-curvature primal block and the two-solve interior-point structure. | Start #25, the quasi-Newton interior-point exploration justified by the recorded runtime analysis. |
| #25 | Explore quasi-Newton curvature models for interior-point | planned | The runtime-gap analysis in #24 may show that exact Lagrangian Hessian construction remains a material contributor to interior-point cost; if so, the next principled optimization surface is a quasi-Newton primal block such as BFGS or L-BFGS inside the primal-dual KKT system. | After #24, decide whether quasi-Newton interior-point variants are justified, and if so implement the narrowest coherent version with measurable benchmark impact. |

## Current Gate

The current project gate is:

> M10 is closed. Issue #24 is now recorded. Start Issue #25 by deciding whether a quasi-Newton interior-point variant is justified before finalizing release-facing solver guidance.

This is the right gate because the separate interior-point method now has both executable validation and a written runtime analysis that explains the current gap honestly: SQP exact wins mainly on iteration count, while SQP BFGS wins mainly on cheaper iterations. The next remaining work is the narrow follow-on decision that analysis was meant to unlock, namely whether a quasi-Newton interior-point curvature model is justified.

## Next Unblocked Work

Work should proceed in exactly this order:

1. Start Issue #25, the quasi-Newton interior-point exploration and narrow implementation slice if justified by the recorded runtime analysis.
2. Then continue M11 with Issue #23, constrained examples, benchmarks, and release-facing documentation.

The M6 slices that are now in place are:

- explicit per-solve device selection through `SolverConfig(device=...)`
- shared-structure batch dispatch through `BatchMode.SHARED_STRUCTURE`
- one unified leading-batch least-squares core for direct and shared-structure execution
- batched dense-direct and Cholesky backends plus batched trust-region subproblem handling
- batch-size-one equivalence tests for the unified solver core
- real CPU and CUDA benchmark evidence with history enabled and disabled
- a shared-structure example and benchmark harness that no longer describe a per-instance loop implementation

## Completed Artifacts

These artifacts already exist in the repository and protect against scope loss:

- repository scaffold and package layout
- CI workflow skeleton
- benchmark harness with real shared-structure CPU/CUDA workloads
- typed problem classes
- typed constraints and bounds
- variable packing helpers
- result and iteration data structures
- explanation rendering and serialization helpers
- dense least-squares local model evaluation
- Gauss-Newton and Levenberg-Marquardt baseline solvers
- explicit single-solve device selection and reproducibility metadata
- shared-structure batch least-squares result reporting
- dense constrained SQP baseline for equality constraints and bounds
- inequality-capable dense constrained SQP with active inequality handling, complementarity-aware diagnostics, and constrained scaling metadata
- constrained regression matrix covering equality-only, bounds-only, mixed equality-plus-bounds, inactive-constraint, redundant-equality, fixed-variable, near-active-bound, and structured failure behavior
- constrained regression coverage for inactive, active, nonlinear, poor-start, mixed, degenerate, and scaling-sensitive inequality cases plus a nearby direct-inequality versus slack-reduction comparison
- mixed constrained certification coverage for near-active inactive inequalities, mixed max-iter semantics, and mixed degenerate fail-closed inequality models
- separate dense primal-dual interior-point solver for equality, inequality, bounds, and mixed constrained problems
- interior-point regression coverage, benchmark harness support, and matched CPU/CUDA comparison artifacts
- least-squares visualization example and generated SVG artifact
- initial unit tests
- architecture and roadmap documents
- issue ledger and implementation tracker

## Scope Protection Rules

To ensure no feature is lost while implementation moves forward:

1. Every issue in `github_issues_v1.md` must map to one milestone in `plan_v1.md`.
2. Any new feature request must be added to the issue ledger before code work starts.
3. No issue can be marked `done` without evidence and validation notes in this file.
4. If work is partially implemented, it must remain `implemented_needs_validation` rather than silently treated as complete.

## Change Log

- 2026-04-30: Created the live implementation tracker and aligned it with the scaffold already added to the repository.
- 2026-04-30: Completed M0, M1, and M2 after editable install succeeded, all 8 unit tests passed, and the benchmark harness wrote a timestamped JSON report under `benchmarks/results/`.
- 2026-04-30: Completed M3 after adding the dense least-squares evaluation path, Gauss-Newton and Levenberg-Marquardt baselines, 3 focused solver tests, and a curve-fitting example that generated `examples/artifacts/least_squares_curve_fit.svg`.
- 2026-04-30: Completed Issue #19 as an M6 enabling slice by adding explicit solver device selection, central device utilities, and validated CPU/CUDA placement coverage (`15 passed, 1 skipped`).
- 2026-05-01: Completed Issue #11 by introducing the dense linear backend boundary, adding dense-direct and Cholesky backends, wiring backend selection into `SolverConfig`, and validating the least-squares slice with 10 focused solver tests.
- 2026-05-01: Completed Issue #12 by surfacing linear residual and conditioning metrics through `SolveResult`, `IterationRecord`, and `TrialRecord`, and validating the solver plus diagnostics slice with 14 focused tests.
- 2026-05-01: Completed Issue #13 by adding a dense trust-region least-squares path, recording trust-region radius and reduction ratios in iteration and trial history, and validating the slice with 15 focused tests including a difficult Rosenbrock robustness regression.
- 2026-05-01: Completed Issue #14 by adding auto/manual least-squares scaling controls, poor-scaling diagnoses, scaling reproducibility metadata, and regression coverage for auto scaling, manual scaling, and invalid scale validation.
- 2026-05-01: Landed the first Issue #15 slice by adding explicit shared-structure batch dispatch, a `SharedStructureBatchResult` wrapper with per-instance reporting, batch parameter slicing rules, README/docs updates, and regression coverage for batch result reporting plus device-preserving parameter handling (`38 passed, 2 skipped`).
- 2026-05-02: Reopened M6/Issue #15 after review confirmed that the implemented `shared_structure` path is still a per-instance loop, the benchmark harness remains an M0 placeholder, and batch-aware variable packing is not integrated into solver execution.
- 2026-05-03: Completed Issue #15 by routing direct and shared-structure least-squares solves through one leading-batch solver core, extending dense backends and trust-region helpers to batched systems, adding single-vs-batch-size-one equivalence coverage, replacing the placeholder benchmark harness with real shared-structure CPU/CUDA workloads, and validating the repository with `83 passed` plus a fresh timestamped benchmark report under `benchmarks/results/`.
- 2026-05-04: Closed M6 after a stricter audit of the implemented shared-structure least-squares path confirmed that the core numerical execution is genuinely batched, the dedicated M6 pressure suite passed (`64 passed`), and the remaining limits (independent batch mode, multi-axis batch shapes, some per-instance bookkeeping and convergence-certification work) do not block the milestone scope.
- 2026-05-04: Completed Issue #17 and closed M7 by adding a conservative exact-stationarity implicit differentiation baseline for least-squares solves, surfacing implicit conditioning and certification residual diagnostics through `SolveResult`, and validating the slice with focused solver tests (`83 passed`), diagnostics tests (`5 passed`), and the M6 pressure suite (`64 passed`).
- 2026-05-04: Started Issue #18 by adding a dense single-instance constrained SQP baseline for equality constraints and bounds, wiring constrained dispatch through `solve()`, exposing BFGS and exact dense Hessian modes plus merit-backtracking acceptance in `src/torch_nonlinear/solvers/constrained_nlp.py`, and validating the slice with focused constrained tests (`4 passed`), adjacent problem/diagnostics/import tests (`10 passed`), and the shared least-squares regression suite (`104 passed`).
- 2026-05-04: Completed Issue #18 and closed M8 after extending the constrained SQP baseline with active-bound-aware reduced KKT steps and multiplier certification, then validating mixed equality-plus-bounds behavior, an inactive-constraint optimum case, and a structured infeasible equality-plus-bounds failure path (`7 passed`) while keeping adjacent problem/diagnostics/import tests green (`10 passed`).
- 2026-05-04: Hardened the closed M8 baseline with additional constrained regressions for redundant equality constraints, fixed-variable bounds, and a near-active but inactive bound case, bringing the focused constrained SQP matrix to `10 passed` without reopening the milestone scope.
- 2026-05-04: Production-hardened the constrained SQP degeneracy path by failing closed on uncertified singular KKT fallback steps, skipping BFGS curvature updates when equality multipliers are non-unique under degenerate equality models, and extending the constrained regression matrix with an inconsistent redundant-equality failure case; the repository suite remained green (`220 passed`).
- 2026-05-04: Reframed the constrained roadmap after design review so M9 now extends the existing dense SQP baseline to support inequalities with explicit constrained scaling ownership, M10 is reserved for a separate full interior-point solver with the stronger preconditioning and iterative-linear-solver ownership, M11 owns release preparation, constrained differentiation stays explicitly unsupported, and slack variables remain an internal formulation choice rather than the public modeling abstraction.
- 2026-05-04: Completed Issue #20 by extending the dense constrained SQP baseline to first-class inequalities, adding inequality feasibility and active-set diagnostics plus complementarity-aware KKT checks and constrained scaling metadata, and validating the slice with 29 focused constrained tests, a direct-inequality versus public-slack-reduction comparison, targeted ad hoc probes on nonlinear/poor-start/degenerate cases, and a clean full-suite run (`252 passed`).
- 2026-05-04: Completed Issue #21 and closed M9 by tightening constrained active-set reporting so near-active inactive inequalities are not mislabeled active, extending the regression matrix with mixed near-active inactive, mixed max-iter, and mixed degenerate fail-closed certification cases, and validating the repository with `32` focused constrained tests plus a clean full-suite run (`255 passed`).
- 2026-05-05: Completed Issue #22 and closed M10 by landing the separate dense primal-dual interior-point solver, extending constrained benchmarks and profiles to the new method, validating the focused IP slice (`22 passed`), and generating matched mixed CPU/CUDA reports plus xlarge exact-curvature comparison artifacts.
- 2026-05-05: Opened Issue #24 under M11 to analyze more deeply why the current interior-point implementation remains slower than SQP BFGS and SQP exact on dense mixed benchmarks despite converging to the same certified terminal point.
- 2026-05-05: Opened Issue #25 under M11 to capture the follow-on need to explore and, if justified by Issue #24, implement quasi-Newton interior-point curvature models such as BFGS or L-BFGS.
- 2026-05-05: Completed Issue #24 by recording the matched mixed benchmark evidence and current-branch xlarge CUDA profiles in `benchmarks/results/2026-05-05_issue24_ip_runtime_analysis.md`; the analysis showed that interior-point loses to SQP exact mainly on iteration count and loses to SQP BFGS mainly on higher per-iteration exact-curvature cost, which makes Issue #25 the next narrow optimization target.
