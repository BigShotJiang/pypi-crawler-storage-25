# Differentiable Nonlinear Optimization Toolbox for PyTorch

## Master Plan v1

## Document Contract

- Audience: internal product strategy and coding-agent alignment only
- Update this file when: product thesis, scope boundaries, solver-family roadmap, or release gates change
- Do not use this file for: live implementation progress, milestone completion notes, or issue execution evidence

## 1. Product Thesis

Build the best PyTorch-native toolbox for smooth nonlinear optimization when the optimizer is part of a larger differentiable program.

This project should not try to win by matching SciPy's breadth or JAXopt's full optimizer catalog. It should win by being the most practical library for PyTorch users who need all of the following at the same time:

- tensor-native problem definitions
- batch and GPU execution
- trustworthy gradients through solves
- strong numerical diagnostics when things fail
- structured APIs for least-squares and constrained problems

The core value proposition is:

> Make nonlinear optimization inside PyTorch easier to debug, faster to differentiate, and more natural to deploy in real ML, robotics, vision, calibration, and inverse-problem pipelines.

## 2. Strategic Positioning

### What this project is not

- Not "SciPy minimize on tensors".
- Not a broad collection of classical optimizers with shallow implementations.
- Not a robotics-specific factor graph library like Theseus.
- Not a JAXopt clone for PyTorch.
- Not a derivative-free or non-smooth optimization toolbox in v1.

### What this project is

- A PyTorch-first second-order optimization toolbox for smooth problems.
- Focused on differentiable nonlinear least squares and general smooth nonlinear programs.
- Designed for repeated solves inside training, inference, and control loops.
- Diagnostics-first: it should tell users why convergence failed, not just that it failed.

## 3. The Killer Wedge

The project becomes genuinely valuable if it delivers these four things together:

### 3.1 Structured problem classes

Do not hide fundamentally different problems behind one flat abstraction. Provide separate problem types with specialized solvers.

- `NonlinearLeastSquaresProblem`
- `SmoothMinimizationProblem`
- `ConstrainedNLPProblem`

### 3.2 Diagnostics that explain failure

Most optimization libraries stop at status codes. This toolbox should produce actionable diagnoses such as:

- poor variable scaling
- infeasible initialization
- rank-deficient Jacobian
- ill-conditioned KKT system
- rejected steps due to bad local model
- implicit differentiation invalid because convergence assumptions are not met

### 3.3 Differentiation users can trust

Gradients through optimization are a flagship feature, but only if the library is explicit about validity.

Every solve should report:

- whether unrolled differentiation is available
- whether implicit differentiation is valid at the returned point
- estimated conditioning of the linearized system used for implicit gradients
- whether gradients are exact, approximate, or disabled

### 3.4 Batched GPU solves with shared structure

This is a major PyTorch-native advantage. The library should be excellent at solving many problems with the same structure but different data, for example:

- fitting one model to many trajectories
- solving per-sample inverse problems in a minibatch
- warm-started control problems over time
- calibration across multiple scenes or sensors

## 4. Scope and Boundaries

## 4.1 Supported problem families

### Priority 1: nonlinear least squares

Primary form:

```python
min_x 0.5 * ||r(x, theta)||^2
```

Extensions:

- robust losses: Huber, Cauchy, soft L1
- optional weighting
- optional box bounds
- batched residual evaluation

Why first:

- high practical demand in vision, geometry, system identification, calibration, inverse problems
- strong fit for Gauss-Newton, Levenberg-Marquardt, trust-region methods
- uses Jacobian structure naturally
- easier to make fast and reliable than fully general constrained NLP on day one

### Priority 2: smooth unconstrained minimization

Primary form:

```python
min_x f(x, theta)
```

This is useful, but it is not the main differentiator. Support it with a focused set of methods, not a giant solver list.

### Priority 3: smooth equality and bound constrained NLP

Primary form:

```python
min_x f(x, theta)
subject to g(x, theta) = 0
           l <= x <= u
```

### Priority 4: smooth inequality constrained NLP

Primary form:

```python
min_x f(x, theta)
subject to g(x, theta) = 0
           h(x, theta) <= 0
           l <= x <= u
```

This belongs in the roadmap, but it should not dilute the initial release.

## 4.2 Explicit non-goals for v1

- derivative-free optimization
- integer or mixed-integer optimization
- generic non-smooth optimization
- arbitrary sparse NLP at massive scale
- exotic manifold optimization as a core feature
- a long list of legacy methods for API parity with SciPy

## 5. Product Requirements

The library should satisfy these user-facing requirements.

### 5.1 PyTorch-native authoring

- objectives, residuals, and constraints are plain Python callables over tensors
- support `nn.Module` parameters and structured tensor containers
- preserve tensor device and dtype semantics
- work with `torch.autograd` and `torch.func`

### 5.2 Typed problem definition

The typed API is the core API. A SciPy-like wrapper can exist, but must not drive internal design.

```python
problem = NonlinearLeastSquaresProblem(
    residual=residual_fn,
    bounds=bounds,
    loss=HuberLoss(delta=1.0),
    scaling=scaling,
    structure=structure_hint,
)

result = solve(
    problem,
    x0=x0,
    params=params,
    method="lm",
    diff_mode="auto",
    batch_mode="shared_structure",
)
```

Provide a convenience wrapper later:

```python
result = minimize(fun=f, x0=x0, constraints=constraints, method="auto")
```

### 5.3 First-class constraints

Constraints must be typed and extensible.

- `Bounds`
- `EqualityConstraint`
- `InequalityConstraint`

Each constraint should be able to carry optional metadata:

- Jacobian callback or hint
- scale
- expected output shape
- structure hint
- name for diagnostics

### 5.4 Structured variable handling

PyTorch users often optimize over trees of tensors, not one flat vector.

The library should support:

- flatten/unflatten utilities
- named variable blocks
- partial optimization over selected tensors
- state packing that preserves shapes and device placement

## 6. Core Technical Decisions

## 6.1 Solver family roadmap

### v0.1/v0.2 core methods

- Gauss-Newton
- Levenberg-Marquardt
- trust-region Gauss-Newton / dogleg for least squares
- L-BFGS as a robust smooth fallback

### v0.3+ constrained methods

- SQP for equality and bound constrained problems
- primal-dual interior-point for general inequalities

For inequalities, keep `InequalityConstraint` first-class in the public model. Slack variables are an internal formulation choice for the solver, not the user-facing abstraction.

### Why this set

- least-squares methods provide a strong early wedge
- trust-region methods are more robust than line-search-only designs for second-order problems
- SQP and interior-point give a credible path to serious constrained optimization
- L-BFGS provides a practical fallback when second-order local models are unreliable

## 6.1.1 Execution Milestone Map

This is the stable milestone sequence used by the issue ledger and live status tracker.

| Milestone | Goal | Exit Signal |
| --- | --- | --- |
| M0 | Repository and tooling spine | Editable install works, tests run in CI, benchmark command writes machine-readable results. |
| M1 | Typed problems and variable packing | Structured state packing is lossless, modeling objects validate deterministically, constraints stay solver-decoupled. |
| M2 | Result object and diagnostics spine | A standard `SolveResult` exists, failure messages are structured, results serialize cleanly. |
| M3 | Nonlinear least squares core | Gauss-Newton and LM solve representative least-squares problems reliably with meaningful diagnostics. |
| M4 | Linear solver abstraction | Least-squares solvers request steps through linear backends and surface structured linear diagnostics. |
| M5 | Trust-region, scaling, and stabilization | Hard cases are more robust than the initial LM baseline, and stabilization metadata appears in diagnostics. |
| M6 | Batched GPU execution | Shared-structure least-squares solves work on CPU and GPU with intelligible per-instance diagnostics and benchmark evidence. |
| M7 | Differentiation and sensitivity | First-order gradients are correct on reference problems and invalid implicit differentiation is reported explicitly. |
| M8 | Equality and bounds constrained NLP | Equality and bounds problems solve with consistent KKT reporting and diagnosable failures. |
| M9 | SQP inequality extension | Dense constrained SQP supports equality, inequality, and bounds with honest feasibility and certification diagnostics on scoped reference problems. |
| M10 | Interior-point solver | A separate interior-point method exists for equality, inequality, bounds, and mixed constrained regimes where the SQP baseline is not the right long-term method. |
| M11 | Release preparation | Public docs, examples, and benchmark evidence explain solver selection honestly and justify an external release. |

Execution ownership is split as follows:

- `implementation_status_v1.md` owns the live state of these milestones
- `github_issues_v1.md` owns issue-level evidence and dependencies

## 6.2 Linear algebra is a first-class subsystem

Do not hard-code `torch.linalg.solve` into solver logic.

Create a linear solver abstraction from the start:

- `DenseDirectSolver`
- `CholeskySolver` when valid
- `CGSolver`
- `MINRESSolver`
- `LSQRSolver` for least-squares subproblems

And a shared interface:

- matrix-free operator API
- preconditioner hook
- residual and conditioning diagnostics
- batch-aware solves

This is essential for scale, stability, and differentiation.

## 6.3 HVP/JVP/VJP before full Hessians

The default implementation path should prefer:

- Jacobian-vector products
- vector-Jacobian products
- Hessian-vector products

Avoid materializing full Hessians by default. Full Hessians can remain available for small dense problems and debugging.

## 6.4 Trust region over line search as the flagship strategy

Line search should exist, but trust-region methods should be the primary path for second-order solvers because they are more robust under poor local curvature and imperfect derivatives.

## 6.5 Scaling and preconditioning are mandatory

This is not an optional optimization.

Every serious plan must include:

- variable scaling
- residual scaling
- constraint scaling
- preconditioning hooks for iterative linear solves
- automatic scale diagnostics in the report

Ownership note for the constrained roadmap:

- dense SQP milestones should own the constrained scaling they actually need for stable dense solves
- interior-point milestones should own any stronger preconditioning or iterative-linear-solver hooks required by their KKT systems

## 6.6 Explicit batching semantics

Define batching early so the implementation stays coherent.

Support two modes:

- `shared_structure`: same variable shapes, same residual/constraint structure across the batch
- `independent`: same tensor shape but independent solves and histories

Do not promise ragged variable-size batching in the first release.

## 6.7 Mixed precision with solve-time control

Second-order optimization is numerically sensitive. Add explicit control of:

- evaluation dtype
- linear solve dtype
- accumulation dtype

This can become a major differentiator on GPU.

## 7. Differentiation Strategy

## 7.1 Supported differentiation modes

- `unroll`: differentiate through iterations directly
- `implicit`: differentiate through optimality conditions or the fixed-point map
- `auto`: choose based on problem class, convergence state, and user settings

## 7.2 Validity semantics must be explicit

Implicit differentiation should never be treated as automatically safe.

Each result must include:

- `diff_mode_used`
- `diff_valid`
- `diff_reason`
- `diff_linear_residual`
- `diff_condition_estimate`

If the solver does not converge, the default behavior should be conservative:

- allow unrolled differentiation if the user requested it
- disable implicit differentiation unless `allow_inexact_implicit=True`
- report exactly why differentiation was downgraded or blocked

## 7.3 Higher-order differentiation

Design for higher-order differentiation, but do not over-promise in the first release.

Initial goal:

- correct first-order gradients through solves
- documented support boundaries for second-order gradients
- test coverage for higher-order cases on small reference problems

## 8. Diagnostics and Explainability

Diagnostics are the main product differentiator. Treat them as part of the solver API, not logging.

## 8.1 Result object

Every solver returns a rich result object with at least:

- `x`
- `success`
- `status`
- `message`
- `num_iter`
- `objective_value`
- `gradient_norm`
- `step_norm`
- `constraint_violation`
- `kkt_residual`
- `active_set`
- `history`
- `diagnosis`
- `reproducibility`
- differentiation fields

## 8.2 Explain mode

Add a template-based explain mode:

```python
result = solve(problem, x0, explain=True)
print(result.explanation)
```

This should summarize:

- what the solver tried
- why steps were accepted or rejected
- what limited convergence
- what the user should try next

## 8.3 Problem inspection

Add a pre-flight inspector:

```python
report = inspect_problem(problem, x0, params)
```

It should estimate:

- scale mismatches
- likely Jacobian rank issues
- degree of nonlinearity from local probes
- feasibility of the initial point
- recommended solver family

## 8.4 Reproducibility and audit trail

Every result should capture:

- device
- dtype
- solver options
- random seed if relevant
- problem class
- derivative mode
- termination condition

## 9. Public API Shape

## 9.1 Core typed API

```python
problem = ConstrainedNLPProblem(
    objective=f,
    constraints=[
        EqualityConstraint(g, name="mass_balance"),
        InequalityConstraint(h, name="safety_margin"),
    ],
    bounds=Bounds(lower, upper),
    scaling=AutoScaling(),
)

result = solve(
    problem,
    x0=x0,
    params=params,
    method="auto",
    diff_mode="auto",
    debug=DebugConfig(level="standard"),
)
```

## 9.2 Convenience API

Keep a SciPy-like wrapper for approachability, but map it into typed internals.

```python
result = minimize(
    fun=f,
    x0=x0,
    constraints=constraints,
    bounds=bounds,
    method="auto",
    tol=1e-6,
    max_iter=100,
    diff_mode="auto",
)
```

## 9.3 Layer and module integration

Provide an `OptimizationLayer` that behaves naturally inside `nn.Module` code:

```python
layer = OptimizationLayer(problem, method="lm", diff_mode="implicit")
x_star = layer(x0, params)
```

## 10. Internal Architecture

Recommended top-level modules:

```text
toolbox/
  api/
  problem/
  variables/
  constraints/
  solvers/
  line_search/
  trust_region/
  linear/
  diff/
  diagnostics/
  batching/
  scaling/
  losses/
  inspect/
  interop/
  examples/
  benchmarks/
  tests/
```

Key interfaces:

- `Problem`
- `LeastSquaresProblem`
- `Constraint`
- `Solver`
- `StepStrategy`
- `LinearOperator`
- `LinearSolver`
- `DiffStrategy`
- `DiagnosticsCollector`

Critical rule:

> Problem definitions, solver logic, linear algebra, differentiation, and diagnostics must stay decoupled.

## 11. Release Roadmap

## Phase 0: Research, benchmark design, and API freeze

Duration: 1 to 2 weeks

Deliverables:

- benchmark matrix and target workloads
- problem class definitions
- result object schema
- linear solver interface
- typed API design review

Exit criteria:

- no ambiguity on initial supported problem classes
- no ambiguity on differentiation semantics
- no ambiguity on batching semantics

## Phase 1: v0.1 nonlinear least squares core

Duration: 4 to 6 weeks

Deliverables:

- `NonlinearLeastSquaresProblem`
- Gauss-Newton and Levenberg-Marquardt
- robust losses
- weighted residuals
- batching with shared structure
- result object with history and diagnosis
- basic plotting helpers

Exit criteria:

- end-to-end examples work on CPU and GPU
- batched solves are correct and stable
- solver failures produce meaningful diagnoses

## Phase 2: trust region, scaling, and linear algebra

Duration: 4 to 6 weeks

Deliverables:

- trust-region step strategy
- line-search fallback where helpful
- scaling subsystem
- dense direct and iterative linear solvers
- preconditioner hook
- mixed precision controls

Exit criteria:

- trust-region outperforms or matches LM on difficult reference problems
- linear solver abstraction is used across core methods
- scaling reports identify common pathologies

## Phase 3: differentiation and sensitivity

Duration: 4 to 6 weeks

Deliverables:

- unrolled differentiation
- implicit differentiation for least squares and unconstrained smooth solves
- gradient validity reporting
- sensitivity outputs and multiplier reporting where available

Exit criteria:

- gradients match finite differences or unrolled references on test problems
- invalid implicit gradients are detected and reported

## Phase 4: constrained smooth NLP

Duration: 6 to 8 weeks

Deliverables:

- equality constraints
- bounds
- SQP core
- KKT diagnostics
- warm starts and continuation support

Exit criteria:

- equality and bound constrained examples work reliably
- KKT residuals and active-set reports are trustworthy

## Phase 5: SQP inequality extension

Duration: 6 to 8 weeks

Deliverables:

- first-class inequality constraints on top of the existing constrained NLP path
- dense SQP support for equality, inequality, and bounds within one constrained solver family
- pragmatic feasibility restoration or honest fail-closed behavior for poor starts on small certifiable problems
- the minimum result/history/config extensions needed for inequality feasibility, active-set, complementarity, and method-selection visibility
- constrained scaling for the dense SQP path, with diagnostics when scaling materially affects constrained behavior

Design note:

- do not make inequality support a public equality-with-slacks reduction
- allow explicit slack variables only as internal SQP formulation state when they improve the subproblem or multiplier logic
- preserve diagnostics in the original inequality coordinates so active-set, feasibility, and complementarity reporting stay intelligible
- finish the current constrained SQP family before introducing a second inequality method
- constrained differentiation remains out of scope for this phase and must be reported as unsupported explicitly rather than implied or partially implemented
- preconditioning is not required in this phase unless the SQP path actually introduces an iterative constrained linear solve

Exit criteria:

- dense SQP solves scoped equality-plus-inequality-plus-bounds problems with credible feasibility and certification diagnostics
- at least one poor-start or infeasible-start case is handled honestly within the documented SQP scope
- the SQP equality-and-bounds path remains stable when no inequalities are present

## Phase 6: dedicated interior-point method

Duration: 4 to 6 weeks

Deliverables:

- support for equality, inequality, bounds, and mixed constrained problems through one coherent interior-point method
- problem classes or benchmarks that demonstrate why interior-point is justified beyond the generalized SQP baseline
- coherent solver-selection guidance between SQP and interior-point at the API level
- interior-point-safe constrained scaling and any justified preconditioning or iterative-linear-solver hooks for that method

Exit criteria:

- the interior-point method covers equality, inequality, bounds, and mixed constrained regimes where the generalized SQP baseline is not the right long-term method
- solver-selection semantics between SQP and interior-point are documented and testable

## Phase 7: release preparation and packaging

Duration: 2 to 4 weeks

Deliverables:

- constrained examples and tutorials suitable for external users
- benchmark publication and release-facing evidence
- packaging polish and public documentation
- honest solver-selection guidance across least-squares, generalized SQP, and interior-point constrained methods
- explicit documentation that constrained differentiation remains unsupported

Exit criteria:

- public release is justified by benchmarks, examples, and honest solver-selection guidance
- release docs state supported constrained regimes and current limitations clearly

## 12. Benchmark and Quality Strategy

This project must prove value with data.

## 12.1 Benchmark baselines

Compare against:

- SciPy for CPU single-instance references
- PyTorch `LBFGS` where relevant
- Theseus on overlapping least-squares workloads
- JAXopt conceptually for feature coverage, not necessarily head-to-head runtime on identical stacks

## 12.2 Benchmark workloads

- Rosenbrock and standard smooth test problems
- curve fitting and parameter estimation
- robust regression with outliers
- camera or sensor calibration
- small bundle-adjustment-style least squares
- differentiable inverse problem inside a training loop
- warm-started repeated solves resembling MPC

## 12.3 Metrics

- wall-clock time
- iterations and linear solves
- convergence rate
- final objective / residual quality
- KKT residual
- gradient correctness
- peak memory
- CPU vs GPU break-even points

## 12.4 Quality bar for release

Do not publish a serious public release until all of the following are true:

- every public solver has documented assumptions and failure modes
- gradient correctness tests exist for advertised differentiation modes
- diagnostics are more informative than raw status codes
- benchmark results clearly show when users should and should not use the library

## 13. Documentation and Adoption Plan

The first impression should communicate that this is a serious systems library, not an experiment.

Required documentation tracks:

- quickstart with a least-squares example
- "when to use this library"
- differentiation guide
- diagnostics guide
- solver selection guide
- troubleshooting guide
- performance guide for batching and GPU

High-value example gallery:

- batched curve fitting
- robust calibration
- differentiable bundle-adjustment-like optimization
- optimization layer inside a neural network
- constrained engineering example with KKT diagnostics

## 14. Risks and Mitigations

### Risk: scope explosion

Mitigation:

- keep least squares as the initial wedge
- defer derivative-free, non-smooth, and massive sparse ambitions

### Risk: poor numerical robustness

Mitigation:

- trust-region methods
- scaling and preconditioning
- benchmark pathological cases early

### Risk: gradients are mathematically fragile

Mitigation:

- explicit validity flags
- conservative defaults
- reference tests against finite differences and unrolled solves

### Risk: GPU value is overstated

Mitigation:

- document break-even regimes
- focus on batched shared-structure workloads

### Risk: PyTorch sparse limitations block scale

Mitigation:

- build around linear operators and iterative solvers first
- support dense and block-structured problems well before promising full sparse NLP

## 15. Success Criteria

This project is successful if, within the first serious release window, users can honestly say:

- "I can express my problem naturally in PyTorch."
- "I can batch solves and run them on GPU when it actually helps."
- "I can differentiate through the optimizer and know when to trust the gradient."
- "When the solve fails, the library tells me what is wrong and what to try next."
- "This saves me real engineering time compared with stitching together PyTorch autograd and ad hoc solver code."

## 16. Immediate Build Order

If implementation starts now, the order should be:

1. typed problem classes and variable packing
2. result object and diagnostics schema
3. nonlinear least squares core with Gauss-Newton and LM
4. linear solver abstraction
5. trust-region strategy and scaling subsystem
6. batched shared-structure execution
7. unrolled and implicit differentiation
8. equality and bound constrained SQP
9. inequality constrained interior-point support

## 17. Final Guidance

The project should be opinionated.

The right initial ambition is not "support every optimizer." It is:

> Become the default PyTorch toolbox for differentiable smooth nonlinear least squares and constrained optimization with first-class diagnostics.

If that wedge is executed well, broader general minimization can grow on top of a credible core instead of being promised too early.