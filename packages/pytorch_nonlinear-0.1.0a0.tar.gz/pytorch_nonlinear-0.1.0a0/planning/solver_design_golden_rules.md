# Solver Design Golden Rules

Internal design guidance for building new solvers in this repository.

This document is not a product overview. It is a concise set of rules for designing solver implementations that are fast, numerically sane, GPU-aware, diagnosable, and maintainable.

## Goal

Design solvers so that the common path is:

- numerically stable enough to make progress
- cheap enough to benchmark honestly
- structured enough to extend to batching, rollout, and implicit differentiation
- observable enough to explain failures without ad hoc debugging

## Golden Rules

1. Separate algorithmic phases strictly.

   Every solver should have explicit ownership boundaries for: current-state evaluation, local-model construction, subproblem solve, trial evaluation, acceptance or rejection, state update, terminal certification, and result reporting. A solver loop that mixes all of these concerns becomes slow to optimize and hard to trust.

2. Keep the timed path minimal.

   Only compute what is required to choose the next iterate. Full certification, exact condition checks, explanation rendering, heavy history materialization, and other diagnostic luxuries must be lazy, cached, sampled, or debug-gated.

3. Make rejected trials cheap.

   Trial evaluation should compute only the quantities needed for acceptance. Full gradients, full Jacobians, multiplier refreshes, Hessian updates, and rich terminal metrics belong on accepted steps unless correctness truly requires otherwise.

4. Treat linear algebra as a subsystem, not a helper call.

   Solvers should emit linearization objects and request steps from a backend boundary. Factorization choice, damping, iterative tolerances, preconditioning, residual checks, and condition estimates should live behind that interface.

5. Scale the local model, not the public problem.

   Variable, residual, and constraint scaling should stabilize step computation while preserving user-facing objective values and convergence semantics. Automatic scaling should be bounded and lagged so the solver metric does not thrash between accepted steps.

6. Design batching into the core.

   Use one leading-batch solver core for single-instance and shared-structure execution. Batching differences should stay at input normalization and output finalization boundaries, not inside the hot iteration loop.

7. Avoid host synchronization in inner loops.

   Do not pepper the step path with `.item()`, CPU-side branching, or repeated tensor-to-host transfers. Keep decisions on device whenever possible and materialize Python scalars only at clear reporting or control boundaries.

8. Cut factorization count before polishing kernels.

   The biggest performance wins usually come from fewer KKT or normal solves, fewer exact decompositions, fewer working-set rebuilds, and smaller reduced systems. Optimize algorithmic work first, then optimize tensor plumbing.

9. Reserve exact algebra for suspicious or terminal states.

   Repeated SVD, pseudoinverse, full eigenanalysis, or exact certification inside every iteration is usually the wrong default. Use cheaper guards in the common path and escalate only when the solve is numerically questionable or about to terminate.

10. Use reduced systems conservatively.

   Active-set reductions, Schur complements, block eliminations, and similar shortcuts should be used when local conditions justify them. The full system remains the correctness baseline unless a reduced path is provably equivalent or adequately safeguarded.

11. Fail closed on uncertified numerics.

   Rank deficiency, ill conditioning, non-unique multipliers, uncertified fallback steps, and broken curvature updates should produce structured diagnoses and safe termination. Do not silently convert a numerically questionable iterate into a success.

12. Separate progress from convergence, and convergence from certification.

   A small step is not the same as first-order convergence. First-order convergence is not the same as a certified local minimum. A converged primal solve is not the same as an implicit-differentiation-safe point. Each claim needs its own rule and its own reported validity.

13. Treat differentiation as a design surface from day one.

   Solver state updates, accepted-step logic, and result objects should preserve enough structure for unrolled differentiation now and explicit implicit-diff certification later. The differentiation layer should consume solver outputs, not dictate solver iteration logic.

14. Keep constraint semantics explicit.

   Equality feasibility, inequality activity, bound activity, complementarity, and KKT residuals should each have a clear convention and a single owning implementation. Mixed constrained behavior becomes unmaintainable when these semantics are inferred indirectly from scattered code.

15. Make observability structured and layered.

   Results should expose the small set of quantities that explain behavior: objective value, optimality measure, step norm, constraint violation, acceptance reason, active set, linear residual, condition estimate, scaling metadata, and differentiation validity. The timed path should capture cheap numeric telemetry first and only later materialize Python records, strings, and exported artifacts.

16. Encode structure, do not just detect size.

   Solver selection and linear algebra strategy should depend on problem structure: dense versus sparse, least-squares versus general NLP, separable blocks, Schur-eliminable variables, bounds, mixed constraints, and shared structure across instances. Size thresholds alone are not enough.

17. Match the method family to the regime.

   Small dense unconstrained least squares may want LM or dogleg. Large sparse least squares may want iterative trust-region methods with preconditioning. Mixed constrained NLP may want SQP or interior-point depending on structure and robustness goals. Do not force one method family to own every regime.

18. Build rollout readiness into state handling.

   Solver configuration, state snapshots, reproducibility metadata, and terminal summaries should be serializable and stable enough for benchmarking, deployment, and regression comparison. A solver that cannot be inspected or replayed is hard to operate in production.

19. Prefer stable extension seams over option sprawl.

   New behavior should usually land by extending an existing owning abstraction such as scaling, step policy, linear backend, or convergence validation. Adding one more top-level flag is usually worse than strengthening a boundary that already exists.

20. Test observability overhead explicitly.

   Benchmarking should measure telemetry cost as well as math cost. A solver that is fast with history disabled but expensive with default observability is not yet well designed. Track the overhead of history capture, scalar extraction, snapshots, and export separately from numerical progress.

21. Test by compatibility matrix, not by anecdote.

   Every nontrivial solver change should be checked against nearby compatibility surfaces: method family, scaling mode, batching mode, device, differentiation mode, constraint mix, and terminal behavior. The right regression is the smallest problem that certifies the behavior, not the biggest benchmark that happens to move.

## Telemetry Layers

- Core solver kernel: tensor math, batching, local-model updates, acceptance logic, and numerics safeguards.
- Internal telemetry buffer: numeric tensors or compact scalar arrays recorded with minimal branching and no formatting.
- History materializer: converts buffered telemetry into `IterationRecord`, `TrialRecord`, and similar Python-facing objects.
- Presentation layer: summaries, explanation strings, JSON or CSV export, and forensic artifacts.

Keep these layers separate. When they collapse into one loop body, throughput and maintainability both degrade.

## External Inspirations

These libraries are worth learning from, but the goal is to extract design principles rather than copy APIs.

- Ceres Solver: make ordering, preconditioning, structure exploitation, and exact versus inexact step computation first-class algorithm choices. Its strongest lesson is that performance comes from matching linear algebra to problem structure, not from one universal step routine.
- Ceres Solver: report solver progress in operational terms such as cost change, gradient norm, step norm, trust-region ratio, radius, and linear iterations. Good progress reporting reduces blind debugging.
- SciPy least_squares and MINPACK tradition: choose defaults that are robust for the common case, but expose the right low-level controls for scaling, sparsity, trust-region subproblem strategy, robust losses, callbacks, and bounds.
- SciPy least_squares: keep iterates strictly feasible for bounded methods when the method requires it, and define optimality using bound-aware projected quantities rather than pretending the unconstrained gradient is the whole story.
- SciPy least_squares: robust losses are best implemented as a wrapper around the residual model and local linearization, not as a separate solver family.
- IPOPT: for general NLP, the linear solve is a central robustness surface, not an implementation detail. Solver design should make it easy to swap sparse symmetric-indefinite backends, scaling strategies, and ordering strategies.
- IPOPT: mixed constrained problems deserve a dedicated method family when the mathematical regime changes. Do not keep stretching a least-squares or simplified SQP architecture past the point where an interior-point formulation is the right abstraction.
- IPOPT: production solvers need disciplined iteration output, option validation, and backend prerequisites stated explicitly. Operational clarity is part of solver quality.

## Current Repository Fit

Useful now:

- tighter hot-path discipline around scalar extraction and history materialization
- explicit telemetry layers and observability levels such as minimal, structured, and forensic
- benchmark observability overhead as a first-class performance metric
- accepted-step-first snapshot policy instead of cloning rich state for every rejected candidate
- workspace preallocation and buffer reuse for repeated dense solves

Useful later:

- GPU-friendly preconditioners and iterative linear solves once sparse or matrix-free solver paths land

Not a current priority:

- multi-GPU sharding and NCCL aggregation for this single-device dense solver stack
- stream choreography as a primary optimization target before algorithmic reductions in factorizations and host sync boundaries
- low-level warp-divergence framing, which is less actionable here than removing Python materialization and host transfers from iterative paths

## What This Repository Already Learned

- Repeated exact decompositions in the hot loop are often the real throughput killer.
- Cheap trial evaluation matters more than beautiful but redundant iteration bookkeeping.
- Reduced-first constrained solves can be excellent optimizations, but only behind local safety checks.
- GPU speedups appear only after the solver stops forcing extra synchronizations and extra factorizations.
- A faster isolated differentiation primitive does not count as a solver win until the full-profile path stays healthy; exact-Hessian changes can shift work into more expensive downstream `mm` or `dot` traffic.
- Diagnostics are most useful when they are structured enough to drive focused tests and benchmark comparisons.
- Current least-squares and constrained paths still contain real host-sync boundaries inside iterative code, especially for scalar control flow and history capture. Those are valid next cleanup targets, not just abstract style advice.
- Removing a host-sync scalar guard is only a win when the replacement path stays cheap and device-native. If the rewrite adds masked gathers, subset checks, builder calls, or extra transfers, the net result can be slower.
- Zero-length or empty-mask tensor no-op paths are good optimization targets when they avoid real work rather than merely moving the same decision deeper into the call stack.
- Cache-aware working-set reuse is usually better than branchless recomputation. Reusing an already materialized active-row Jacobian is a better optimization pattern than rebuilding or directly gathering the same rows in a more expensive form.
- Revision-to-revision benchmark and profile comparisons are more trustworthy than ad hoc reruns from a dirty worktree. Performance claims should be anchored to matched commands, matched scenarios, and clean code states.
- Broad regressions in this repository often show up as a package of costs in `transfer_conversion`, `indexing_masking`, `shape_view`, and `allocation_init`, not as one obviously bad kernel. Treat that pattern as a sign that a cleanup added tensor plumbing work rather than reducing algorithmic work.

## Anti-Patterns

- One giant solver loop that evaluates, linearizes, globalizes, diagnoses, certifies, and reports in one place.
- Recomputing expensive exact metrics on every iteration because they are convenient to print.
- Building batch support as a Python loop around a single-instance solver.
- Letting constraint activity, scaling, and convergence checks each invent their own tolerances and semantics.
- Returning success from numerically dubious terminal states without an explicit certification story.
- Adding new public flags for every benchmark regression instead of fixing the owning abstraction.

## Design Check Before Implementation

Before adding a new solver or major solver feature, be able to answer these questions in one page:

1. What is the owning abstraction?
2. What invariant must it preserve?
3. What is the common-path cost driver?
4. What expensive work can be deferred or cached?
5. What structure can the linear algebra exploit?
6. What is the active notion of feasibility and optimality?
7. What makes a terminal result safe for rollout?
8. What makes it safe or unsafe for implicit differentiation?
9. What metrics will explain failure without manual debugging?
10. Which nearby compatibility surface will be the first regression check?