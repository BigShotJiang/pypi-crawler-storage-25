# GitHub Issues v1

This file translates the implementation backlog into issue-ready GitHub tickets with rough effort and dependency information.

Use this file as the issue-level execution ledger.

## Document Contract

- Audience: internal development and coding-agent execution only
- Update this file when: issue metadata, dependencies, acceptance criteria, or per-issue evidence changes
- Do not use this file for: aggregate milestone counts, current gate decisions, or sprint sequencing

`implementation_status_v1.md` remains the live source of truth for aggregate project state. This file owns issue-level metadata and evidence.

## Label Set

- `area:tooling`
- `area:modeling`
- `area:diagnostics`
- `area:least-squares`
- `area:linear-algebra`
- `area:batching`
- `area:diff`
- `area:constrained`
- `kind:feature`
- `kind:test`
- `kind:docs`
- `priority:p0`
- `priority:p1`

## Status Vocabulary

- `done`
- `implemented_needs_validation`
- `in_progress`
- `planned`
- `blocked`

## Issue Matrix

| ID | Title | Milestone | Status | Labels | Estimate | Depends On |
| --- | --- | --- | --- | --- | --- | --- |
| 1 | Bootstrap package skeleton and CI | M0 | done | area:tooling, kind:feature, priority:p0 | M | - |
| 2 | Add benchmark harness and result schema | M0 | done | area:tooling, kind:feature, priority:p0 | S | 1 |
| 3 | Implement structured variable packing | M1 | done | area:modeling, kind:feature, priority:p0 | M | 1 |
| 4 | Add typed problem classes | M1 | done | area:modeling, kind:feature, priority:p0 | M | 1 |
| 5 | Add typed constraints and bounds | M1 | done | area:modeling, kind:feature, priority:p0 | S | 4 |
| 6 | Implement solve status and result schema | M2 | done | area:diagnostics, kind:feature, priority:p0 | M | 1 |
| 7 | Add iteration history and explanation scaffolding | M2 | done | area:diagnostics, kind:feature, priority:p1 | S | 6 |
| 8 | Implement dense least-squares evaluation path | M3 | done | area:least-squares, kind:feature, priority:p0 | M | 3, 4, 6 |
| 9 | Implement Gauss-Newton baseline solver | M3 | done | area:least-squares, kind:feature, priority:p0 | M | 8 |
| 10 | Implement Levenberg-Marquardt damping policy | M3 | done | area:least-squares, kind:feature, priority:p0 | M | 9 |
| 11 | Introduce linear solver abstraction | M4 | done | area:linear-algebra, kind:feature, priority:p0 | M | 8 |
| 12 | Refactor least-squares solvers onto linear backends | M4 | done | area:linear-algebra, kind:feature, priority:p0 | M | 9, 10, 11 |
| 13 | Add trust-region acceptance logic | M5 | done | area:least-squares, kind:feature, priority:p1 | M | 10, 12 |
| 14 | Add scaling interfaces and auto-scaling heuristics | M5 | done | area:diagnostics, kind:feature, priority:p1 | M | 3, 6 |
| 15 | Implement shared-structure batch mode | M6 | done | area:batching, kind:feature, priority:p1 | M | 12 |
| 16 | Implement unrolled differentiation path | M7 | done | area:diff, kind:feature, priority:p1 | M | 10, 12 |
| 17 | Implement implicit differentiation baseline | M7 | done | area:diff, kind:feature, priority:p1 | L | 12, 16 |
| 18 | Add equality and bounds constrained SQP baseline | M8 | done | area:constrained, kind:feature, priority:p1 | L | 5, 11, 12 |
| 19 | Add explicit solver device selection policy | M6 | done | area:batching, kind:feature, priority:p0 | S | 6, 9 |
| 20 | Extend dense SQP to inequality constraints | M9 | done | area:constrained, area:diagnostics, kind:feature, priority:p0 | L | 18 |
| 21 | Harden SQP mixed constrained compatibility and certification | M9 | done | area:constrained, area:diagnostics, kind:feature, priority:p1 | M | 20 |
| 22 | Add full interior-point constrained solver | M10 | done | area:constrained, kind:feature, priority:p1 | L | 20, 21 |
| 23 | Publish constrained examples, benchmarks, and release docs | M11 | planned | area:constrained, area:tooling, kind:docs, priority:p1 | M | 20, 21, 22 |
| 24 | Analyze interior-point runtime gap versus SQP exact and BFGS | M11 | done | area:constrained, area:linear-algebra, area:tooling, kind:test, priority:p1 | M | 22 |
| 25 | Explore quasi-Newton curvature models for interior-point | M11 | planned | area:constrained, area:linear-algebra, kind:feature, priority:p1 | M | 22, 24 |

## Progress Rules

1. Update `implementation_status_v1.md` first when aggregate work state changes.
2. Update this file second so the issue matrix and detail blocks match the live status tracker.

## Next Unblocked Issues

- Issue 25: if the runtime analysis justifies it, explore and implement a narrow quasi-Newton interior-point variant such as BFGS or L-BFGS on the Lagrangian Hessian block.
- Issue 23: package the constrained stack with examples, benchmarks, and release-facing docs after the solver milestones and runtime analysis are captured.

## Issue Details

## Issue 1: Bootstrap package skeleton and CI

Labels: `area:tooling`, `kind:feature`, `priority:p0`

Milestone: `M0`

Current Status: `done`

Description:

Create the editable-install package layout, baseline developer tooling, `.gitignore`, and CI workflow.

Acceptance Criteria:

- `pip install -e .[dev]` succeeds
- `pytest` runs in CI
- repository structure matches the agreed architecture spine

## Issue 2: Add benchmark harness and result schema

Labels: `area:tooling`, `kind:feature`, `priority:p0`

Milestone: `M0`

Current Status: `done`

Depends On: 1

Description:

Add a benchmark runner entry point and a machine-readable JSON result schema that later benchmarks can reuse.

Acceptance Criteria:

- benchmark runner writes JSON output to `benchmarks/results/`
- report includes version, timestamp, and workload slots

## Issue 3: Implement structured variable packing

Labels: `area:modeling`, `kind:feature`, `priority:p0`

Milestone: `M1`

Current Status: `done`

Depends On: 1

Description:

Implement the `VariableSpec` and `PackedState` path plus flatten/unflatten helpers for structured optimization variables.

Acceptance Criteria:

- rectangular nested inputs pack and unflatten losslessly
- block order is stable and test-covered
- jagged inputs fail loudly

## Issue 4: Add typed problem classes

Labels: `area:modeling`, `kind:feature`, `priority:p0`

Milestone: `M1`

Current Status: `done`

Depends On: 1

Description:

Create `NonlinearLeastSquaresProblem`, `SmoothMinimizationProblem`, and `ConstrainedNLPProblem` with validation hooks.

Acceptance Criteria:

- problems validate callable inputs and basic configuration
- typed internals become the canonical path for solver work

## Issue 5: Add typed constraints and bounds

Labels: `area:modeling`, `kind:feature`, `priority:p0`

Milestone: `M1`

Current Status: `done`

Depends On: 4

Description:

Implement first-class `Bounds`, `EqualityConstraint`, and `InequalityConstraint` objects with metadata support.

Acceptance Criteria:

- constraints carry names and metadata without solver coupling
- invalid bound configuration is rejected

## Issue 6: Implement solve status and result schema

Labels: `area:diagnostics`, `kind:feature`, `priority:p0`

Milestone: `M2`

Current Status: `done`

Depends On: 1

Description:

Define `SolveStatus`, `TerminationReason`, diagnosis enums, and the baseline `SolveResult` object.

Acceptance Criteria:

- result object is stable enough for early solver integration
- reproducibility fields and diff fields exist in the schema

## Issue 7: Add iteration history and explanation scaffolding

Labels: `area:diagnostics`, `kind:feature`, `priority:p1`

Milestone: `M2`

Current Status: `done`

Depends On: 6

Description:

Add `IterationRecord`, history storage conventions, and a first explanation-summary path.

Acceptance Criteria:

- iteration rows serialize cleanly
- explanation text is templated rather than ad hoc logging

## Issue 8: Implement dense least-squares evaluation path

Labels: `area:least-squares`, `kind:feature`, `priority:p0`

Milestone: `M3`

Current Status: `done`

Depends On: 3, 4, 6

Description:

Add the first least-squares local model path, including residual evaluation and weighted/robust residual hooks.

Acceptance Criteria:

- dense least-squares evaluation works for moderate-size reference problems
- residual outputs integrate with the result schema

Validation Evidence:

- `src/torch_nonlinear/solvers/least_squares.py` now builds a dense residual, Jacobian, gradient, and normal matrix local model.
- `tests/unit/test_least_squares_solvers.py` verifies the dense evaluation path.

## Issue 9: Implement Gauss-Newton baseline solver

Labels: `area:least-squares`, `kind:feature`, `priority:p0`

Milestone: `M3`

Current Status: `done`

Depends On: 8

Description:

Implement the first end-to-end solver with predictable convergence and failure behavior on small reference problems.

Acceptance Criteria:

- solves standard curve-fitting references
- produces structured failure information on bad initializations

Validation Evidence:

- `src/torch_nonlinear/api/solve.py` now dispatches least-squares problems to the dense solver path.
- `tests/unit/test_least_squares_solvers.py` verifies convergent and rejected-step Gauss-Newton behavior.

## Issue 10: Implement Levenberg-Marquardt damping policy

Labels: `area:least-squares`, `kind:feature`, `priority:p0`

Milestone: `M3`

Current Status: `done`

Depends On: 9

Description:

Add LM damping and step adaptation to improve robustness over raw Gauss-Newton.

Acceptance Criteria:

- LM improves or matches GN on difficult least-squares cases
- damping state is observable in diagnostics

Validation Evidence:

- The dense solver records LM damping retries in iteration history via `linear_iterations` and reason strings.
- `examples/least_squares_curve_fit.py` converged and wrote `examples/artifacts/least_squares_curve_fit.svg`.

## Issue 11: Introduce linear solver abstraction

Labels: `area:linear-algebra`, `kind:feature`, `priority:p0`

Milestone: `M4`

Current Status: `done`

Depends On: 8

Description:

Create the solver-to-linear-system boundary so least-squares and future constrained solvers stop hard-coding dense direct solves.

Acceptance Criteria:

- step computation routes through a backend interface
- linear failures expose structured diagnostics

Validation Evidence:

- `src/torch_nonlinear/linear/backends.py` now defines `Linearization`, `LinearSolveResult`, `LinearSolver`, and backend construction.
- `SolverConfig(linear_solver=...)` now selects between `dense_direct`, `cholesky`, and `auto`.
- `tests/unit/test_least_squares_solvers.py` passed with 10 focused solver tests after the backend boundary landed.

## Issue 12: Refactor least-squares solvers onto linear backends

Labels: `area:linear-algebra`, `kind:feature`, `priority:p0`

Milestone: `M4`

Current Status: `done`

Depends On: 9, 10, 11

Description:

Move existing least-squares solvers onto the new linear backend interface without changing their public API.

Acceptance Criteria:

- GN and LM no longer call linear algebra primitives directly
- backend swap is config-driven

Validation Evidence:

- `src/torch_nonlinear/solvers/least_squares.py` routes both GN and LM step computation through the backend interface.
- `src/torch_nonlinear/diagnostics/result.py`, `src/torch_nonlinear/diagnostics/history.py`, and `src/torch_nonlinear/diagnostics/explain.py` now surface linear residual and conditioning diagnostics through results, iteration history, trial history, and human-readable explanations.
- `tests/unit/test_least_squares_solvers.py` and `tests/unit/test_diagnostics.py` passed with 14 focused tests covering the surfaced linear diagnostics.

## Issue 13: Add trust-region acceptance logic

Labels: `area:least-squares`, `kind:feature`, `priority:p1`

Milestone: `M5`

Current Status: `done`

Depends On: 10, 12

Description:

Implement a trust-region step acceptance path for the least-squares slice.

Acceptance Criteria:

- difficult references show robustness gains over LM-only behavior
- trust-region metrics appear in history

Validation Evidence:

- `src/torch_nonlinear/steps/trust_region.py` now implements the dense trust-region subproblem policy used by the least-squares solver.
- `src/torch_nonlinear/solvers/least_squares.py` now supports `method="trust_region"` and records trust-region radius and acceptance ratios in `IterationRecord` and `TrialRecord` history.
- `tests/unit/test_least_squares_solvers.py` and `tests/unit/test_diagnostics.py` passed with 15 focused tests, including a difficult Rosenbrock start where trust-region converges within 8 iterations while the LM-only baseline hits the iteration limit.

## Issue 14: Add scaling interfaces and auto-scaling heuristics

Labels: `area:diagnostics`, `kind:feature`, `priority:p1`

Milestone: `M5`

Current Status: `done`

Depends On: 3, 6

Description:

Implement variable/residual scaling interfaces and a first diagnosis pass for scale pathologies.

Acceptance Criteria:

- automatic scaling warnings appear in results
- scaling metadata is captured in reproducibility output

Validation Evidence:

- `src/torch_nonlinear/api/config.py` now exposes `ScalingConfig` and `ScalingMode` so least-squares solves can request automatic or manual scaling.
- `src/torch_nonlinear/scaling/least_squares.py` now builds scaled dense local models with both variable and residual-row scaling, emits poor-scaling diagnoses for large auto-detected spreads, and serializes scaling metadata for reproducibility.
- `src/torch_nonlinear/solvers/least_squares.py` now applies scaling to GN, LM, and trust-region local models while preserving the original user-facing objective and result shape.
- `tests/unit/test_least_squares_solvers.py` now covers automatic scaling warnings, manual scaling metadata, and invalid manual scale validation; the full suite passed with 22 tests.

## Issue 15: Implement shared-structure batch mode

Labels: `area:batching`, `kind:feature`, `priority:p1`

Milestone: `M6`

Current Status: `done`

Depends On: 12

Description:

Implement true shared-structure batch mode for least-squares solves so repeated solves with common structure execute through a real leading-batch path rather than a Python loop over per-instance solves.

Acceptance Criteria:

- batched least-squares solves work correctly on CPU and GPU
- per-batch diagnostics remain intelligible through per-instance `SolveResult` objects
- benchmark evidence shows where GPU batching is actually beneficial
- all public solver entry points honor an explicit requested device without hidden CPU/GPU transfers

Validation Evidence:

- `src/torch_nonlinear/api/solve.py` now routes both direct and `BatchMode.SHARED_STRUCTURE` least-squares calls into one unified leading-batch solver core.
- `src/torch_nonlinear/solvers/least_squares.py` now normalizes direct solves to `batch_size=1`, runs GN, LM, and trust-region through the same leading-batch execution path, and finalizes direct or shared-structure results without a per-instance API loop.
- `src/torch_nonlinear/linear/backends.py` and `src/torch_nonlinear/steps/trust_region.py` now support batched systems needed by the shared-structure path.
- `tests/unit/test_least_squares_solvers.py` now validates shared-structure equivalence and explicit single-vs-batch-size-one equivalence for the unified solver core.
- `benchmarks/run_benchmarks.py` now writes real shared-structure CPU and CUDA timing data, including history enabled and disabled, to timestamped JSON reports under `benchmarks/results/`.

## Issue 16: Implement unrolled differentiation path

Labels: `area:diff`, `kind:feature`, `priority:p1`

Milestone: `M7`

Current Status: `done`

Depends On: 10, 12

Description:

Implement the first differentiable solve path by backpropagating through unrolled solver iterations.

Acceptance Criteria:

- first-order gradients match reference checks on small problems
- diff mode is explicit in results

Validation Evidence:

- `src/torch_nonlinear/solvers/least_squares.py` now preserves autograd connectivity through accepted least-squares solver iterations when `SolverConfig(diff_mode=DiffMode.UNROLL)` is requested, while still surfacing explicit diff metadata in `SolveResult`.
- `tests/unit/test_least_squares_solvers.py` now verifies both single-solve finite-difference gradient agreement and shared-structure batch-vs-sequential unrolled gradient agreement.
- `examples/learned_range_sensor_fusion.py` now demonstrates an end-to-end learned optimization layer where a confidence network is trained through the unrolled least-squares solve path to improve downstream batched localization accuracy.

## Issue 17: Implement implicit differentiation baseline

Labels: `area:diff`, `kind:feature`, `priority:p1`

Milestone: `M7`

Current Status: `done`

Depends On: 12, 16

Description:

Add an implicit differentiation baseline with validity reporting and conservative fallback behavior.

Acceptance Criteria:

- invalid implicit cases are reported explicitly
- conditioning metrics and linear residuals are surfaced

Validation Evidence:

- `src/torch_nonlinear/diff/least_squares.py` now attaches an exact-stationarity implicit backward rule after the solve and certifies it conservatively from the returned least-squares point instead of silently falling back to unrolled gradients.
- `src/torch_nonlinear/solvers/least_squares.py` now populates `SolveResult.diff_valid`, `diff_reason`, `diff_condition_estimate`, and `diff_linear_residual` for explicit implicit requests while preserving per-instance validity in shared-structure batches.
- `tests/unit/test_least_squares_solvers.py` now verifies implicit-vs-unrolled gradient agreement for Gauss-Newton, Levenberg-Marquardt, and trust-region on small certified problems, shared-structure batch-vs-sequential implicit gradient agreement, and explicit invalidity for non-differentiable-parameter and non-converged cases.
- `tests/unit/test_diagnostics.py` now verifies that implicit certification metrics surface through human-readable explanations.

## Issue 18: Add equality and bounds constrained SQP baseline

Labels: `area:constrained`, `kind:feature`, `priority:p1`

Milestone: `M8`

Current Status: `done`

Depends On: 5, 11, 12

Description:

Implement the first constrained solver path using equality constraints and bounds with KKT diagnostics.

Validation Evidence:

- `src/torch_nonlinear/solvers/constrained_nlp.py` now implements a dense single-instance SQP baseline for equality constraints and simple bounds using dense-direct KKT solves, merit backtracking, and BFGS or exact dense Hessian models.
- `src/torch_nonlinear/solvers/constrained_nlp.py` now reduces KKT solves onto free variables when active bounds block the unconstrained trial direction, and its KKT certification now estimates equality multipliers consistently at active-bound iterates.
- `src/torch_nonlinear/solvers/constrained_nlp.py` now treats singular constrained KKT rescues as certifiable fallback steps rather than automatic successes: it computes a minimum-norm pseudoinverse candidate only for diagnosed ill-conditioned or rank-deficient solves, rejects that candidate when the normalized residual stays too large, and skips BFGS curvature updates when equality degeneracy makes multiplier-based curvature information non-unique.
- `src/torch_nonlinear/api/solve.py` now dispatches `ConstrainedNLPProblem` instances to the constrained solver path.
- `src/torch_nonlinear/api/config.py` now carries the minimal constrained Hessian and merit controls required by the baseline implementation.
- `src/torch_nonlinear/problem/constrained.py` now validates attached bounds through the typed problem boundary.
- `tests/unit/test_constrained_nlp_solvers.py` now covers equality-constrained convergence, bounds-active-set behavior, mixed equality-plus-bounds convergence, an inactive-constraint optimum where the constrained and unconstrained solutions coincide, redundant equality constraints with structured diagnoses, fixed-variable bounds, a near-active but inactive bound case, BFGS-versus-exact Hessian agreement on a certified small problem, a larger dense CPU-oriented case that stays on the default BFGS path, a structured infeasible equality-plus-bounds failure path, and an inconsistent redundant-equality case that must fail closed with an uncertified-KKT diagnosis.
- Validation commands passed: `pytest tests/unit/test_constrained_nlp_solvers.py` (`11 passed`), `pytest tests/unit/test_problem_models.py tests/unit/test_diagnostics.py tests/unit/test_smoke_imports.py` (`10 passed`), `pytest tests/unit/test_least_squares_solvers.py` (`104 passed`), and the full repository suite `pytest` (`220 passed`).

Next Action:

- Use the closed M8 baseline as the compatibility surface for Issue 20, the first inequality-constrained slice.

## Issue 19: Add explicit solver device selection policy

Labels: `area:batching`, `kind:feature`, `priority:p0`

Milestone: `M6`

Current Status: `done`

Depends On: 6, 9

Description:

Add an explicit device selection policy to the public solver configuration so users can request CPU or CUDA execution without relying on incidental placement from the initial state object.

Acceptance Criteria:

- `SolverConfig` accepts an explicit requested device
- least-squares solvers honor the requested device without hidden host/device transfers beyond the explicit policy
- CPU and CUDA tests cover the placement contract
- this enabling slice does not claim M6 complete without batched GPU execution

Validation Evidence:

- `src/torch_nonlinear/api/config.py` now exposes `SolverConfig(device=...)`.
- `src/torch_nonlinear/utils/device.py` centralizes requested-device validation and nested parameter placement.
- `tests/unit/test_least_squares_solvers.py` covers explicit CPU placement, invalid device requests, and CUDA placement when CUDA is available.

## Issue 20: Extend dense SQP to inequality constraints

Labels: `area:constrained`, `area:diagnostics`, `kind:feature`, `priority:p0`

Milestone: `M9`

Current Status: `done`

Depends On: 18

Description:

Extend the existing dense SQP constrained solver to support first-class `InequalityConstraint` objects so the current constrained method family reaches a pragmatic baseline for equality, inequality, and bounds before a second inequality method is introduced.

This issue should reuse the current constrained problem definition and extend the current SQP implementation in a way that remains coherent for one solver family. The planning decision is that inequalities remain explicit in the public model and diagnostics. Slack variables may be introduced internally when they simplify the SQP subproblem or multiplier logic, but M9 should not reduce public inequality support to a generic equality-with-slacks interface because that would blur active-set and feasibility diagnostics while overstating what has actually been implemented.

This issue also owns the minimum public-surface changes needed by the extended SQP method: if inequality-capable SQP requires new result, history, trial, reproducibility, or solver-config fields for feasibility, active-set, complementarity, restoration, or method controls, they should land here rather than being left as undocumented incidental changes. Constrained differentiation remains out of scope for M9; the generalized SQP path must continue to report constrained differentiation as unsupported explicitly.

For numerical stabilization ownership, this issue should add the constrained scaling support that the dense SQP baseline actually needs, including scale application and diagnostics for constraint residuals or linearized constraint rows when that materially improves certification and step quality. Full preconditioning ownership does not belong here unless the SQP path genuinely grows an iterative constrained linear solve; otherwise preconditioning should stay deferred to the later interior-point milestone.

Acceptance Criteria:

- `solve()` accepts `ConstrainedNLPProblem` instances containing `InequalityConstraint` objects without changing the public problem API, while exposing an explicit SQP constrained method selection and an honest `auto` policy.
- the dense constrained solver reports inequality feasibility, active-set or multiplier state, complementarity-relevant diagnostics, and restoration or rejection behavior through the minimum required result/history/config surface rather than burying them in freeform strings.
- constrained scaling is implemented for the dense SQP path and surfaces enough metadata or diagnoses to explain when scaling materially affected constrained behavior.
- small convex and nonlinear reference problems with inactive, active, and mixed equality-plus-inequality constraints converge with certified feasibility inside the configured budget.
- at least one infeasible or poorly centered start is handled honestly on a small certifiable problem, either through successful restoration/progress or through explicit fail-closed diagnostics consistent with the documented SQP scope.
- structured failures for infeasible, uncertified, or numerically unstable inequality cases are reported explicitly rather than silently falling back to an equality-only path.
- constrained differentiation remains explicitly unsupported, with clear result metadata rather than silent partial behavior.

Planned Validation:

- focused constrained solver tests covering inactive inequalities, active inequalities, mixed equality-plus-inequality-plus-bounds cases, and an infeasible-start or poor-start case
- at least one nearby comparison that shows the generalized SQP path behaves coherently on the same problem family where a naive public equality-with-slacks reduction would obscure diagnostics or add unnecessary state
- focused checks that the SQP equality-and-bounds path remains behaviorally unchanged when no inequalities are present

Validation Evidence:

- `src/torch_nonlinear/solvers/constrained_nlp.py` now extends the existing dense SQP path to first-class `InequalityConstraint` objects, active-inequality linearization, inequality feasibility accounting, complementarity-aware KKT diagnostics, structured fail-closed behavior, and explicit constrained scaling metadata under `SolveResult.reproducibility["constrained_scaling"]`.
- `tests/unit/test_constrained_nlp_solvers.py` passed with `29 passed`, covering inactive inequalities, nonlinear active inequalities, mixed equality-plus-inequality-plus-bounds problems, poor/infeasible starts, degenerate fail-closed inequality behavior, constrained auto scaling, and a direct-inequality versus public-slack-reduction comparison that preserves the cleaner `ineq[0]` active-set diagnostic on the same active-boundary problem.
- Ad hoc probes on the implemented SQP path confirmed: a nonlinear boundary inequality converged near `x=1`, a poorly centered mixed equality-plus-inequality start converged near `[0.8, 0.2]`, and an infeasible inequality-only case failed closed with the structured message `The constrained SQP linear solve failed.`
- Full repository validation passed with `252 passed`, supporting the compatibility claim that the pre-existing equality-and-bounds path and adjacent solver surfaces remained stable after the inequality extension.

Next Action:

- Use the closed #20 baseline as the compatibility surface for Issue #21, then harden mixed constrained certification and fail-closed behavior without widening M9 into the interior-point milestone.

## Issue 21: Harden SQP mixed constrained compatibility and certification

Labels: `area:constrained`, `area:diagnostics`, `kind:feature`, `priority:p1`

Milestone: `M9`

Current Status: `done`

Depends On: 20

Description:

Harden the inequality-capable SQP solver after the baseline exists by expanding mixed constrained regime coverage, certification, and fail-closed behavior without reopening constrained differentiation scope or prematurely turning M9 into a second solver-family milestone.

Acceptance Criteria:

- regression coverage includes near-active but inactive inequalities, mixed equality-plus-inequality-plus-bounds problems, and at least one degenerate or ill-conditioned inequality model that must fail closed with a structured diagnosis.
- certification and termination semantics remain intelligible across the equality-only, bounds-only, and mixed inequality-capable SQP path.
- the design keeps the M8 equality-and-bounds path stable rather than regressing it under the new generalized SQP policy.
- any additional diagnostics introduced after the baseline remain narrow and solver-relevant rather than becoming a grab bag of method-specific strings.

Validation Evidence:

- `src/torch_nonlinear/solvers/constrained_nlp.py` now uses a tighter active-set reporting tolerance in the constrained evaluation path so near-active but truly inactive inequalities and bounds are not mislabeled active in result or history diagnostics, without changing the KKT solve or certification logic.
- `tests/unit/test_constrained_nlp_solvers.py` passed with `32 passed`, adding focused Issue #21 coverage for a mixed equality-plus-inequality problem where a near-active but inactive inequality must stay out of the active set, a mixed-regime `MAX_ITER` case that preserves the distinction between accepted progress and step rejection, and a mixed equality-plus-inequality-plus-bounds degenerate model that fails closed with structured diagnoses.
- The mixed fail-closed regression records the intended structured diagnoses (`rank_deficient_jacobian`, `ill_conditioned_system`, and `uncertified_kkt_step`) rather than silently collapsing back to an equality-only or feasibility-obscuring path.
- Full repository validation passed with `255 passed`, supporting the compatibility claim that the closed M8 equality-and-bounds path and the closed Issue #20 inequality baseline remained stable after the M9 certification hardening slice.

Next Action:

- Start Issue #22 by using the closed M9 SQP baseline as the comparison surface for a separate interior-point solver, rather than widening the SQP family further.

## Issue 22: Add full interior-point constrained solver

Labels: `area:constrained`, `kind:feature`, `priority:p1`

Milestone: `M10`

Current Status: `done`

Depends On: 20, 21

Description:

Add a separate full primal-dual interior-point constrained solver after the generalized SQP path exists, supporting equality, inequality, bounds, and mixed constrained problems through one coherent method. The point of this milestone is not to add an inequality-only specialist, but to provide a second serious constrained solver family for regimes where the pragmatic dense SQP baseline is not the right long-term method.

This issue owns the heavier constrained linear-algebra stabilization work that should not be forced into the pragmatic dense SQP milestone: interior-point-safe constraint scaling, and preconditioning or iterative-linear-solver hooks when those are justified by the interior-point linear systems rather than speculative future need.

Acceptance Criteria:

- a separate interior-point constrained method exists rather than further overloading the generalized SQP path.
- the method is documented and tested on equality-only, inequality-dominant, and mixed equality-plus-inequality constrained problems where interior-point behavior is meaningfully different from the M9 SQP baseline.
- result, history, and config surfaces remain coherent across the SQP and interior-point methods rather than diverging ad hoc.
- constrained scaling works coherently for the interior-point path, and any preconditioning or iterative-linear-solver hooks added for that method are explicit, justified, and test-covered.
- constrained differentiation remains explicitly unsupported unless a later milestone adds it deliberately.

Next Action:

- Use the completed interior-point method as the comparison surface for Issue #24 and the release-facing documentation in Issue #23.

Validation Evidence:

- `src/torch_nonlinear/solvers/interior_point/` now implements a separate dense primal-dual interior-point solver with exact Lagrangian Hessians, slack/complementarity residuals, fraction-to-the-boundary globalization, dedicated KKT scaling, structured linear certification, and deferred telemetry materialization.
- `tests/unit/test_interior_point_solvers.py` passed with `22 passed`, covering equality-only, bounds-only, mixed equality-plus-inequality-plus-bounds, scaling behavior, failure paths, history behavior, and certification-related regressions.
- `benchmarks/constrained_benchmark_common.py`, `benchmarks/run_constrained_benchmarks.py`, and `benchmarks/profile_constrained_benchmarks.py` now support `method="interior_point"`, matched mixed CPU/CUDA comparison suites, and targeted profiler runs for the interior-point path.
- Matched CPU/CUDA artifacts were generated for the mixed comparison ladder, including `benchmarks/results/matched_mixed_four_rung_interior_point.json`, plus xlarge exact-curvature comparison artifacts `benchmarks/results/xlarge_mixed_interior_point_cpu_cuda.json` and `benchmarks/results/xlarge_mixed_sqp_exact_cpu_cuda.json`.

## Issue 23: Publish constrained examples, benchmarks, and release docs

Labels: `area:constrained`, `area:tooling`, `kind:docs`, `priority:p1`

Milestone: `M11`

Current Status: `planned`

Depends On: 20, 21, 22

Description:

Open M11 by turning the completed constrained-solver stack into an honest release story: examples, benchmark evidence, and public documentation that state exactly what the constrained stack does well, where it is still limited, how users should choose among least-squares, generalized SQP, and the dedicated interior-point method, and that constrained differentiation is still unsupported.

Acceptance Criteria:

- at least one executable inequality-constrained example exists and is referenced by the repository docs.
- the benchmark harness includes at least one constrained inequality workload with recorded feasibility and convergence metrics.
- README or release-facing docs explain solver selection across generalized SQP and interior-point, supported constrained regimes, that constrained differentiation remains unsupported, and the fact that inequalities are modeled directly rather than through a public slack-variable reformulation.
- the release checklist and issue tracker contain enough evidence to justify calling the constrained slice externally usable.

Next Action:

- After the solver and diagnostics slices are validated, add one representative inequality example, one benchmark workload, and the release-facing constrained documentation update.

## Issue 24: Analyze interior-point runtime gap versus SQP exact and BFGS

Labels: `area:constrained`, `area:linear-algebra`, `area:tooling`, `kind:test`, `priority:p1`

Milestone: `M11`

Current Status: `done`

Depends On: 22

Description:

Analyze more deeply why the current dense primal-dual interior-point implementation remains slower than both SQP with BFGS and SQP with exact Hessians on the matched dense mixed benchmark ladder, even when all methods converge to the same certified terminal point.

This issue is not a request for speculative optimization branches. It owns the profiling, benchmark, and diagnosis work needed to identify which remaining costs are method-intrinsic versus implementation-contingent. The goal is to produce a defensible explanation of the current gap and to narrow the next optimization targets so release-facing solver-selection guidance is honest.

Acceptance Criteria:

- matched evidence exists for interior-point versus SQP BFGS and SQP exact on at least one shared mixed constrained ladder, including the current xlarge case.
- the analysis distinguishes iteration-count effects from per-iteration cost drivers such as exact Hessian construction, affine-plus-corrector solve structure, KKT factorization count, and certification overhead.
- at least one targeted profile exists for the controlling device/workload pair, and the findings are translated into a concrete next-optimization shortlist rather than a vague "IP is slower" statement.
- the outcome is recorded in a form usable by Issue #23 release documentation without overstating either solver family.

Validation Evidence:

- `benchmarks/results/2026-05-05_issue24_ip_runtime_analysis.md` now records the issue-level comparison in one release-usable note, citing the matched ladder reports `benchmarks/results/matched_mixed_four_rung_interior_point.json` and `benchmarks/results/matched_mixed_four_rung_sqp.json`, the xlarge matched reports `benchmarks/results/xlarge_mixed_interior_point_cpu_cuda.json` and `benchmarks/results/xlarge_mixed_sqp_exact_cpu_cuda.json`, and the current-branch targeted CUDA profiles under `benchmarks/results/profiles_issue24_ip_xlarge_cuda/` and `benchmarks/results/profiles_issue24_sqp_exact_xlarge_cuda/`.
- The recorded xlarge mixed comparison shows that all three methods converge to the same certified terminal point, but with materially different cost splits: SQP BFGS at about `4.76 s` CPU / `3.48 s` CUDA over `32` accepted iterations, SQP exact at about `5.39 s` CPU / `1.67 s` CUDA over `2` accepted iterations, and interior-point at about `15.91 s` CPU / `7.06 s` CUDA over `8` accepted iterations.
- The analysis distinguishes the controlling effects explicitly: versus SQP exact, interior-point is slower mainly because it needs about `4x` as many accepted outer iterations on the xlarge case while costing about the same per accepted iteration on CUDA; versus SQP BFGS, interior-point is slower because each accepted iteration is much more expensive.
- The current-branch xlarge CUDA interior-point profile shows the slower path is dominated by dense primal-block math rather than certification overhead: `aten::bmm` (~`3.41 s`), `aten::mm` (~`1.50 s`), and `aten::linalg_lu_factor_ex` (~`0.87 s`) dominate device time, while `aten::_linalg_eigh` remains only ~`0.28 s`.
- The recorded next-optimization shortlist is therefore narrow and concrete: keep the current exact Hessian baseline, and use Issue #25 to explore a quasi-Newton approximation on the interior-point primal/Lagrangian Hessian block before reopening broader release-facing solver guidance.

Next Action:

- Start Issue #25, using the recorded runtime analysis to decide whether a quasi-Newton interior-point curvature model is justified and where that approximation should live in the primal-dual system.

## Issue 25: Explore quasi-Newton curvature models for interior-point

Labels: `area:constrained`, `area:linear-algebra`, `kind:feature`, `priority:p1`

Milestone: `M11`

Current Status: `planned`

Depends On: 22, 24

Description:

Explore whether the current dense primal-dual interior-point solver should gain a quasi-Newton curvature option, such as BFGS or L-BFGS on the Lagrangian Hessian block, as a principled alternative to always building the exact second-order model.

This issue is explicitly downstream of Issue #24. It should not start from the assumption that quasi-Newton interior-point is automatically better. The point is to use the runtime-gap analysis to decide whether exact Lagrangian Hessian construction is a controlling cost on the relevant workload and, only if that diagnosis is supported, implement the narrowest coherent quasi-Newton interior-point slice that can be benchmarked honestly against the existing exact variant.

Acceptance Criteria:

- the issue records a design decision about where the quasi-Newton approximation lives: objective Hessian, Lagrangian Hessian primal block, or another explicitly justified block of the primal-dual system.
- if implementation is justified, the interior-point solver exposes a narrow configuration surface for at least one quasi-Newton variant, with BFGS or L-BFGS update semantics documented clearly enough to explain what remains exact in the KKT system.
- focused validation covers at least one small certifiable constrained problem showing the quasi-Newton variant converges coherently and preserves explicit failure reporting when curvature updates become invalid or unhelpful.
- benchmark evidence compares the quasi-Newton variant against the current exact interior-point path on at least one shared mixed constrained workload and reports both iteration count and wall-clock tradeoffs.

Planned Validation:

- one focused design note or implementation comment that states exactly which Hessian block is approximated and how the update is formed from primal-dual iterates.
- focused interior-point regression coverage for the chosen quasi-Newton variant, including at least one curvature-skip or damped-update case if the implementation needs that safeguard.
- matched constrained benchmark runs comparing exact interior-point versus the quasi-Newton variant on at least one shared mixed scenario.
