"""Profile a single benchmark scenario with torch.profiler."""

from __future__ import annotations

import argparse
import json
import time
from collections import defaultdict
from collections.abc import Sequence
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import torch
from torch.profiler import ProfilerActivity, profile

from run_benchmarks import (
    _SUPPORTED_METHODS,
    _prepare_sensor_case,
    _run_batch_solve,
    _run_sequential_solve,
    _synchronize,
    collect_git_metadata,
    ensure_clean_git_worktree,
)


_CATEGORY_RULES: tuple[tuple[str, tuple[str, ...], tuple[str, ...]], ...] = (
    ("launch_runtime", ("cudaLaunchKernel", "cudaMalloc", "cudaFree", "cudaMemset"), ()),
    (
        "transfer_conversion",
        ("cudaMemcpy", "Memcpy ", "aten::copy_", "aten::to", "aten::_to_copy"),
        (),
    ),
    (
        "sync_scalar",
        (
            "cudaStreamSynchronize",
            "aten::item",
            "aten::_local_scalar_dense",
            "aten::is_nonzero",
        ),
        (),
    ),
    (
        "indexing_masking",
        (
            "aten::index",
            "aten::index_",
            "aten::index_select",
            "aten::index_copy",
            "aten::_index_put_impl_",
            "aten::nonzero",
            "aten::select",
            "aten::slice",
            "aten::masked_",
            "aten::where",
        ),
        ("Nonzero", "index_elementwise_kernel", "DeviceSelect", "DeviceReduce"),
    ),
    (
        "dense_math",
        (
            "aten::add",
            "aten::bmm",
            "aten::div",
            "aten::einsum",
            "aten::exp",
            "aten::linalg_",
            "aten::matmul",
            "aten::mm",
            "aten::mul",
            "aten::neg",
            "aten::pow",
            "aten::sigmoid",
            "aten::solve",
            "aten::sqrt",
            "aten::sub",
            "aten::sum",
        ),
        ("svd", "gemm", "elementwise_kernel"),
    ),
    (
        "shape_view",
        (
            "aten::as_strided",
            "aten::view",
            "aten::reshape",
            "aten::permute",
            "aten::expand",
            "aten::flatten",
            "aten::squeeze",
            "aten::unsqueeze",
            "aten::transpose",
        ),
        (),
    ),
    (
        "tensor_lifecycle",
        (
            "aten::detach",
            "detach",
            "aten::clone",
            "aten::contiguous",
            "aten::resolve_",
        ),
        (),
    ),
    (
        "allocation_init",
        (
            "aten::empty",
            "aten::empty_strided",
            "aten::zeros",
            "aten::zero_",
            "aten::ones",
            "aten::fill_",
            "aten::resize_",
        ),
        (),
    ),
    ("autograd", ("autograd::", "torch::autograd::"), ()),
)


def _metric(event: Any, *names: str) -> float:
    for name in names:
        if hasattr(event, name):
            value = getattr(event, name)
            if value is not None:
                return float(value)
    return 0.0


def _categorize_op(name: str) -> str:
    for category, prefixes, substrings in _CATEGORY_RULES:
        if name.startswith(prefixes):
            return category
        if any(token in name for token in substrings):
            return category
    return "other"


def _build_top_ops(events: Sequence[Any], *, limit: int = 12) -> list[dict[str, Any]]:
    ranked = sorted(
        events,
        key=lambda event: (
            _metric(event, "self_device_time_total", "self_cuda_time_total"),
            _metric(event, "self_cpu_time_total"),
        ),
        reverse=True,
    )
    return [
        {
            "name": event.key,
            "calls": int(_metric(event, "count")),
            "self_cpu_ms": round(_metric(event, "self_cpu_time_total") / 1000.0, 3),
            "cpu_total_ms": round(_metric(event, "cpu_time_total") / 1000.0, 3),
            "self_device_ms": round(_metric(event, "self_device_time_total", "self_cuda_time_total") / 1000.0, 3),
            "device_total_ms": round(_metric(event, "device_time_total", "cuda_time_total") / 1000.0, 3),
        }
        for event in ranked[:limit]
    ]


def _build_category_breakdown(events: Sequence[Any]) -> list[dict[str, Any]]:
    totals: dict[str, dict[str, float]] = defaultdict(lambda: {"self_cpu_us": 0.0, "self_device_us": 0.0, "calls": 0.0})
    total_cpu_us = 0.0
    total_device_us = 0.0
    for event in events:
        category = _categorize_op(event.key)
        self_cpu_us = _metric(event, "self_cpu_time_total")
        self_device_us = _metric(event, "self_device_time_total", "self_cuda_time_total")
        calls = _metric(event, "count")
        totals[category]["self_cpu_us"] += self_cpu_us
        totals[category]["self_device_us"] += self_device_us
        totals[category]["calls"] += calls
        total_cpu_us += self_cpu_us
        total_device_us += self_device_us

    rows: list[dict[str, Any]] = []
    for category, values in totals.items():
        rows.append(
            {
                "category": category,
                "self_cpu_ms": round(values["self_cpu_us"] / 1000.0, 3),
                "self_cpu_pct": round((values["self_cpu_us"] / total_cpu_us) * 100.0, 1) if total_cpu_us else 0.0,
                "self_device_ms": round(values["self_device_us"] / 1000.0, 3),
                "self_device_pct": round((values["self_device_us"] / total_device_us) * 100.0, 1) if total_device_us else 0.0,
                "calls": int(values["calls"]),
            }
        )
    return sorted(rows, key=lambda row: (row["self_device_ms"], row["self_cpu_ms"]), reverse=True)


def _render_text_summary(*, metadata: dict[str, Any], category_breakdown: Sequence[dict[str, Any]], top_ops: Sequence[dict[str, Any]]) -> str:
    lines = [
        f"Profiler summary for {metadata['method']} ({metadata['execution']}) on {metadata['device']}",
        f"Scenario: batch_size={metadata['batch_size']} timepoints={metadata['timepoints']} capture_history={metadata['capture_history']}",
    ]
    lines.extend(["", "Category breakdown:"])
    for row in category_breakdown[:6]:
        lines.append(
            "- {category}: cpu={cpu_ms:.3f} ms ({cpu_pct:.1f}%), device={device_ms:.3f} ms ({device_pct:.1f}%), calls={calls}".format(
                category=row["category"],
                cpu_ms=row["self_cpu_ms"],
                cpu_pct=row["self_cpu_pct"],
                device_ms=row["self_device_ms"],
                device_pct=row["self_device_pct"],
                calls=row["calls"],
            )
        )
    lines.extend(["", "Top ops:"])
    for row in top_ops[:8]:
        lines.append(
            "- {name}: cpu={cpu_ms:.3f} ms, device={device_ms:.3f} ms, calls={calls}".format(
                name=row["name"],
                cpu_ms=row["self_cpu_ms"],
                device_ms=row["self_device_ms"],
                calls=row["calls"],
            )
        )
    return "\n".join(lines) + "\n"


def _parse_bool(value: str) -> bool:
    normalized = value.strip().lower()
    if normalized in {"1", "true", "yes", "on"}:
        return True
    if normalized in {"0", "false", "no", "off"}:
        return False
    raise argparse.ArgumentTypeError(f"Invalid boolean value: {value}")


def _profile_output_stem(
    *,
    method: str,
    device: str,
    batch_size: int,
    timepoints: int,
    capture_history: bool,
    execution: str,
) -> str:
    history = "history_on" if capture_history else "history_off"
    return f"{method}_{execution}_{device}_bs{batch_size}_tp{timepoints}_{history}"


def _activities_for_device(device: torch.device) -> list[ProfilerActivity]:
    activities = [ProfilerActivity.CPU]
    if device.type == "cuda":
        activities.append(ProfilerActivity.CUDA)
    return activities


def _build_profile_target(
    *,
    method: str,
    device: torch.device,
    batch_size: int,
    timepoints: int,
    capture_history: bool,
    execution: str,
    max_iter: int,
    tol: float,
) -> tuple[callable, dict[str, Any]]:
    problem, x0_batch, params_batch, true_params = _prepare_sensor_case(
        device=device,
        batch_size=batch_size,
        timepoints=timepoints,
    )

    if execution == "batch":
        def run_once() -> Any:
            return _run_batch_solve(
                problem,
                x0_batch,
                params_batch,
                device=device,
                capture_history=capture_history,
                method=method,
                max_iter=max_iter,
                tol=tol,
            )
    else:
        def run_once() -> Any:
            return _run_sequential_solve(
                problem,
                x0_batch,
                params_batch,
                device=device,
                capture_history=capture_history,
                method=method,
                max_iter=max_iter,
                tol=tol,
            )

    metadata = {
        "method": method,
        "device": str(device),
        "batch_size": batch_size,
        "timepoints": timepoints,
        "capture_history": capture_history,
        "execution": execution,
        "max_iter": max_iter,
        "tol": tol,
        "true_parameter_shape": list(true_params.shape),
    }
    return run_once, metadata


def parse_args(argv: Sequence[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Profile a single solver benchmark scenario with torch.profiler.")
    parser.add_argument("--method", choices=_SUPPORTED_METHODS, default="trust_region")
    parser.add_argument("--device", choices=("cpu", "cuda"), default="cpu")
    parser.add_argument("--batch-size", type=int, default=32)
    parser.add_argument("--timepoints", type=int, default=100)
    parser.add_argument("--capture-history", type=_parse_bool, default=False)
    parser.add_argument("--execution", choices=("batch", "sequential"), default="batch")
    parser.add_argument("--warmup", type=int, default=1)
    parser.add_argument("--active", type=int, default=1)
    parser.add_argument("--max-iter", type=int, default=30)
    parser.add_argument("--tol", type=float, default=1e-6)
    parser.add_argument(
        "--output-dir",
        default=f"benchmarks/results/profiles_{datetime.now(timezone.utc).strftime('%Y-%m-%dT%H%M%S')}",
        help="Directory where trace and summary artifacts are written.",
    )
    parser.add_argument(
        "--verbose",
        action="store_true",
        help="Also write the Chrome trace and human-readable text summary.",
    )
    parser.add_argument(
        "--force",
        action="store_true",
        help="Run even if the git worktree is dirty.",
    )
    return parser.parse_args(argv)


def _write_summary(
    *,
    output_dir: Path,
    stem: str,
    profiler: Any,
    metadata: dict[str, Any],
    verbose: bool,
) -> Path:
    summary_path = output_dir / f"{stem}_summary.json"
    events = list(profiler.key_averages())
    top_ops = _build_top_ops(events)
    category_breakdown = _build_category_breakdown(events)
    payload = {
        **metadata,
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "category_breakdown": category_breakdown,
        "top_ops": top_ops,
    }
    summary_path.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    if verbose:
        text_summary_path = output_dir / f"{stem}_summary.txt"
        text_summary_path.write_text(
            _render_text_summary(
                metadata=metadata,
                category_breakdown=category_breakdown,
                top_ops=top_ops,
            ),
            encoding="utf-8",
        )
    return summary_path


def main(argv: Sequence[str] | None = None) -> int:
    args = parse_args(argv)
    if args.device == "cuda" and not torch.cuda.is_available():
        print("CUDA profiling requested, but CUDA is not available.")
        return 1

    repo_root = Path(__file__).resolve().parents[1]
    try:
        git_metadata = collect_git_metadata(repo_root=repo_root)
        if not args.force:
            ensure_clean_git_worktree(git_metadata)
    except Exception as exc:
        print(str(exc))
        return 1

    device = torch.device(args.device)
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    stem = _profile_output_stem(
        method=args.method,
        device=args.device,
        batch_size=args.batch_size,
        timepoints=args.timepoints,
        capture_history=args.capture_history,
        execution=args.execution,
    )
    trace_path = output_dir / f"{stem}.json"

    run_once, metadata = _build_profile_target(
        method=args.method,
        device=device,
        batch_size=args.batch_size,
        timepoints=args.timepoints,
        capture_history=args.capture_history,
        execution=args.execution,
        max_iter=args.max_iter,
        tol=args.tol,
    )
    metadata.update(git_metadata)

    for _ in range(args.warmup):
        run_once()
        _synchronize(device)

    with profile(activities=_activities_for_device(device), record_shapes=True) as profiler:
        for _ in range(args.active):
            run_once()
            _synchronize(device)
            profiler.step()

    if args.verbose:
        profiler.export_chrome_trace(str(trace_path))
    summary_path = _write_summary(
        output_dir=output_dir,
        stem=stem,
        profiler=profiler,
        metadata=metadata,
        verbose=args.verbose,
    )
    if args.verbose:
        print(f"Wrote profiler trace to {trace_path}")
    print(f"Wrote profiler summary to {summary_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())