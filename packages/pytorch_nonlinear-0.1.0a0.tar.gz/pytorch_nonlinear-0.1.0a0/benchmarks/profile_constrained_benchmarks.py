"""Profile a single constrained-method scenario with torch.profiler."""

from __future__ import annotations

import argparse
import json
import subprocess
from collections.abc import Callable
from collections.abc import Sequence
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import torch
from torch.profiler import profile

from constrained_benchmark_common import (
    build_constrained_scenario,
    default_profile_scenario_for_set,
    resolve_constrained_scenario_name,
    run_constrained_scenario,
    summarize_constrained_result,
    supported_benchmark_scenario_sets,
    supported_constrained_methods,
)
from profile_benchmarks import _activities_for_device, _build_category_breakdown, _build_top_ops
from run_benchmarks import _synchronize, collect_git_metadata, ensure_clean_git_worktree


def _parse_bool(value: str) -> bool:
    normalized = value.strip().lower()
    if normalized in {"1", "true", "yes", "on"}:
        return True
    if normalized in {"0", "false", "no", "off"}:
        return False
    raise argparse.ArgumentTypeError(f"Invalid boolean value: {value}")


def _tol_tag(tol: float) -> str:
    return f"{tol:.0e}" if tol != 0.0 else "0"


def _record_shapes_enabled(*, profiler_overhead: str) -> bool:
    return profiler_overhead != "reduced"


def _should_export_chrome_trace(*, verbose: bool, skip_chrome_trace: bool) -> bool:
    return verbose and not skip_chrome_trace


def _profile_output_stem(
    *,
    method: str,
    scenario: str,
    device: str,
    hessian_model: str,
    max_iter: int,
    tol: float,
) -> str:
    if method == "sqp":
        return f"sqp_{scenario}_{device}_{hessian_model}_iter{max_iter}_tol{_tol_tag(tol)}"
    return f"{method}_{scenario}_{device}_iter{max_iter}_tol{_tol_tag(tol)}"


def _render_text_summary(
    *,
    metadata: dict[str, Any],
    category_breakdown: Sequence[dict[str, Any]],
    top_ops: Sequence[dict[str, Any]],
) -> str:
    hessian_suffix = ""
    if metadata.get("constrained_hessian_model") is not None:
        hessian_suffix = f" hessian={metadata['constrained_hessian_model']}"
    lines = [
        f"Profiler summary for {metadata['method']} on {metadata['device']}",
        f"Scenario: {metadata['scenario']} dim={metadata['dimension']} equalities={metadata['num_equalities']}{hessian_suffix}",
        (
            "Run summary: success={success} termination={termination} iterations={iterations} "
            "initial_violation={initial_violation} final_violation={final_violation} final_kkt={final_kkt}"
        ).format(
            success=metadata["success"],
            termination=metadata["termination"],
            iterations=metadata["num_outer_iterations"],
            initial_violation=metadata["initial_constraint_violation"],
            final_violation=metadata["final_constraint_violation"],
            final_kkt=metadata["final_kkt_residual"],
        ),
        (
            "Iteration counts: accepted={accepted} rejected={rejected} total_trials={trials} projected_init={projected}"
        ).format(
            accepted=metadata["accepted_iterations"],
            rejected=metadata["rejected_iterations"],
            trials=metadata["total_trial_attempts"],
            projected=metadata["projected_initialization"],
        ),
    ]
    lines.extend(["", "Category breakdown:"])
    for row in category_breakdown[:6]:
        lines.append(
            "- {category}: cpu={cpu_ms:.3f} ms ({cpu_pct:.1f}%), device={device_ms:.3f} ms ({device_pct:.1f}%), calls={calls}".format(
                category=row["category"],
                cpu_ms=row["self_cpu_ms"],
                cpu_pct=row["self_cpu_pct"],
                device_ms=row["self_device_ms"],
                device_pct=row["self_device_pct"],
                calls=row["calls"],
            )
        )
    lines.extend(["", "Top ops:"])
    for row in top_ops[:8]:
        lines.append(
            "- {name}: cpu={cpu_ms:.3f} ms, device={device_ms:.3f} ms, calls={calls}".format(
                name=row["name"],
                cpu_ms=row["self_cpu_ms"],
                device_ms=row["self_device_ms"],
                calls=row["calls"],
            )
        )
    return "\n".join(lines) + "\n"


def _build_profile_target(
    *,
    method: str,
    scenario_name: str,
    device: torch.device,
    hessian_model: str,
    capture_history: bool,
    max_iter: int,
    tol: float,
) -> tuple[Callable[[], Any], dict[str, Any]]:
    scenario = build_constrained_scenario(scenario_name, device=device)

    def run_once() -> Any:
        result = run_constrained_scenario(
            scenario,
            device=device,
            method=method,
            hessian_model=hessian_model,
            max_iter=max_iter,
            tol=tol,
            capture_history=capture_history,
        )
        return result

    metadata = {
        "scenario": scenario.name,
        "device": str(device),
        "method": method,
        "max_iter": max_iter,
        "tol": tol,
        "capture_history": capture_history,
        **scenario.metadata,
    }
    if method == "sqp":
        metadata["constrained_hessian_model"] = hessian_model
    return run_once, metadata


def parse_args(argv: Sequence[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Profile a single constrained-method scenario with torch.profiler.")
    parser.add_argument("--method", choices=supported_constrained_methods(), default="sqp")
    parser.add_argument(
        "--scenario-set",
        choices=supported_benchmark_scenario_sets(),
        default="default",
        help="Named constrained benchmark suite used to choose a default scenario when --scenario is omitted.",
    )
    parser.add_argument("--scenario", type=resolve_constrained_scenario_name, default=None)
    parser.add_argument("--device", choices=("cpu", "cuda"), default="cpu")
    parser.add_argument("--hessian-model", choices=("bfgs", "exact"), default="bfgs")
    parser.add_argument("--capture-history", type=_parse_bool, default=True)
    parser.add_argument("--warmup", type=int, default=1)
    parser.add_argument("--active", type=int, default=1)
    parser.add_argument("--max-iter", type=int, default=40)
    parser.add_argument("--tol", type=float, default=1e-6)
    parser.add_argument(
        "--profiler-overhead",
        choices=("standard", "reduced"),
        default="standard",
        help=(
            "Profiler metadata mode. 'reduced' disables record_shapes to lower tracing overhead, "
            "which is useful for CUDA exact SQP runs."
        ),
    )
    parser.add_argument(
        "--skip-chrome-trace",
        action="store_true",
        help="Skip Chrome trace export and only write the summarized profiler report.",
    )
    parser.add_argument(
        "--output-dir",
        default=f"benchmarks/results/profiles_constrained_{datetime.now(timezone.utc).strftime('%Y-%m-%dT%H%M%S')}",
        help="Directory where trace and summary artifacts are written.",
    )
    parser.add_argument(
        "--verbose",
        action="store_true",
        help="Also write the Chrome trace and human-readable text summary.",
    )
    parser.add_argument(
        "--force",
        action="store_true",
        help="Run even if the git worktree is dirty.",
    )
    args = parser.parse_args(argv)
    if args.scenario is None:
        args.scenario = default_profile_scenario_for_set(method=args.method, scenario_set=args.scenario_set)
    return args


def _write_summary(
    *,
    output_dir: Path,
    stem: str,
    profiler: Any,
    metadata: dict[str, Any],
    verbose: bool,
) -> Path:
    summary_path = output_dir / f"{stem}_summary.json"
    events = list(profiler.key_averages())
    top_ops = _build_top_ops(events)
    category_breakdown = _build_category_breakdown(events)
    payload = {
        **metadata,
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "category_breakdown": category_breakdown,
        "top_ops": top_ops,
    }
    summary_path.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    if verbose:
        text_summary_path = output_dir / f"{stem}_summary.txt"
        text_summary_path.write_text(
            _render_text_summary(
                metadata=metadata,
                category_breakdown=category_breakdown,
                top_ops=top_ops,
            ),
            encoding="utf-8",
        )
    return summary_path


def main(argv: Sequence[str] | None = None) -> int:
    args = parse_args(argv)
    if args.device == "cuda" and not torch.cuda.is_available():
        print("CUDA profiling requested, but CUDA is not available.")
        return 1

    repo_root = Path(__file__).resolve().parents[1]
    try:
        git_metadata = collect_git_metadata(repo_root=repo_root)
        if not args.force:
            ensure_clean_git_worktree(git_metadata)
    except (OSError, RuntimeError, subprocess.SubprocessError) as exc:
        print(str(exc))
        return 1

    device = torch.device(args.device)
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    stem = _profile_output_stem(
        method=args.method,
        scenario=args.scenario,
        device=args.device,
        hessian_model=args.hessian_model,
        max_iter=args.max_iter,
        tol=args.tol,
    )
    trace_path = output_dir / f"{stem}.json"
    run_once, metadata = _build_profile_target(
        method=args.method,
        scenario_name=args.scenario,
        device=device,
        hessian_model=args.hessian_model,
        capture_history=args.capture_history,
        max_iter=args.max_iter,
        tol=args.tol,
    )
    metadata.update(git_metadata)
    metadata.update(
        {
            "profiler_overhead": args.profiler_overhead,
            "profiler_record_shapes": _record_shapes_enabled(profiler_overhead=args.profiler_overhead),
            "skip_chrome_trace": args.skip_chrome_trace,
        }
    )

    for _ in range(args.warmup):
        run_once()
        _synchronize(device)

    last_result = None
    with profile(
        activities=_activities_for_device(device),
        record_shapes=_record_shapes_enabled(profiler_overhead=args.profiler_overhead),
    ) as profiler:
        for _ in range(args.active):
            last_result = run_once()
            _synchronize(device)
            profiler.step()

    if last_result is None:
        last_result = run_once()
        _synchronize(device)

    scenario = build_constrained_scenario(args.scenario, device=device)
    metadata.update(
        summarize_constrained_result(
            scenario=scenario,
            result=last_result,
            device=device,
            method=args.method,
            hessian_model=args.hessian_model,
            max_iter=args.max_iter,
            tol=args.tol,
        )
    )

    if _should_export_chrome_trace(verbose=args.verbose, skip_chrome_trace=args.skip_chrome_trace):
        profiler.export_chrome_trace(str(trace_path))
    summary_path = _write_summary(
        output_dir=output_dir,
        stem=stem,
        profiler=profiler,
        metadata=metadata,
        verbose=args.verbose,
    )
    if _should_export_chrome_trace(verbose=args.verbose, skip_chrome_trace=args.skip_chrome_trace):
        print(f"Wrote profiler trace to {trace_path}")
    print(f"Wrote profiler summary to {summary_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())