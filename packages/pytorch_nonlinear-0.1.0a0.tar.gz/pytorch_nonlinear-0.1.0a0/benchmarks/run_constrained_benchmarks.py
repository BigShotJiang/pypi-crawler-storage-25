"""Benchmark constrained methods with matched CPU/CUDA comparisons by default."""

from __future__ import annotations

import argparse
import json
import subprocess
import sys
from collections.abc import Sequence
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable

import torch

from constrained_benchmark_common import (
    benchmark_scenarios_for_set,
    build_constrained_scenario,
    run_constrained_scenario,
    resolve_constrained_scenario_name,
    summarize_constrained_result,
    supported_benchmark_scenario_sets,
    supported_constrained_methods,
)
from run_benchmarks import _measure, collect_git_metadata, ensure_clean_git_worktree


def _print_progress(message: str) -> None:
    print(f"[constrained-bench] {message}", flush=True)


def _format_seconds(seconds: float) -> str:
    return f"{seconds:.4f}s"


def _benchmark_summary_line(record: dict[str, Any]) -> str:
    return (
        f"completed {record['scenario']} on {record['device']}: "
        f"median={_format_seconds(float(record['time_seconds_median']))} "
        f"status={record['status']} success={record['success']} "
        f"iters={record['num_outer_iterations']} trials={record['total_trial_attempts']}"
    )


def _paired_device_summary_line(records_by_device: dict[str, dict[str, Any]]) -> str | None:
    cpu_record = records_by_device.get("cpu")
    cuda_record = records_by_device.get("cuda")
    if cpu_record is None or cuda_record is None:
        return None

    cpu_time = float(cpu_record["time_seconds_median"])
    cuda_time = float(cuda_record["time_seconds_median"])
    speedup = (cpu_time / cuda_time) if cuda_time > 0.0 else None
    speedup_text = f"{speedup:.2f}x" if speedup is not None else "n/a"
    return (
        f"summary {cpu_record['scenario']}: "
        f"cpu={_format_seconds(cpu_time)} cuda={_format_seconds(cuda_time)} "
        f"cpu_vs_cuda={speedup_text}"
    )


def _benchmark_case(
    *,
    scenario_name: str,
    device: torch.device,
    method: str,
    hessian_model: str,
    repeats: int,
    max_iter: int,
    tol: float,
    capture_history: bool,
) -> dict[str, Any]:
    scenario = build_constrained_scenario(scenario_name, device=device)
    diagnostic_result = run_constrained_scenario(
        scenario,
        device=device,
        method=method,
        hessian_model=hessian_model,
        max_iter=max_iter,
        tol=tol,
        capture_history=True,
    )
    median_seconds, timings = _measure(
        lambda: run_constrained_scenario(
            scenario,
            device=device,
            method=method,
            hessian_model=hessian_model,
            max_iter=max_iter,
            tol=tol,
            capture_history=capture_history,
        ),
        device=device,
        repeats=repeats,
    )
    record = summarize_constrained_result(
        scenario=scenario,
        result=diagnostic_result,
        device=device,
        method=method,
        hessian_model=hessian_model,
        max_iter=max_iter,
        tol=tol,
    )
    name_parts = ["constrained", scenario_name, method]
    if method == "sqp":
        name_parts.append(hessian_model)
    record.update(
        {
            "name": "_".join(name_parts),
            "repeats": repeats,
            "capture_history_timed": capture_history,
            "time_seconds_median": median_seconds,
            "time_seconds_runs": timings,
        }
    )
    return record


def _annotate_device_speedups(records: list[dict[str, Any]]) -> list[dict[str, Any]]:
    grouped: dict[tuple[str, str, str], dict[str, dict[str, Any]]] = {}
    for record in records:
        key = (
            str(record["scenario"]),
            str(record["method"]),
            str(record.get("constrained_hessian_model")),
        )
        grouped.setdefault(key, {})[str(record["device"])] = record

    for device_rows in grouped.values():
        cpu_record = device_rows.get("cpu")
        cuda_record = device_rows.get("cuda")
        if cpu_record is None or cuda_record is None:
            continue
        cuda_time = float(cuda_record["time_seconds_median"])
        speedup = (float(cpu_record["time_seconds_median"]) / cuda_time) if cuda_time > 0.0 else None
        cpu_record["cpu_vs_cuda_speedup"] = speedup
        cuda_record["cpu_vs_cuda_speedup"] = speedup
    return records


def build_report(
    *,
    scenarios: Sequence[str],
    devices: Sequence[torch.device],
    method: str,
    hessian_model: str,
    repeats: int,
    max_iter: int,
    tol: float,
    capture_history: bool,
    progress_callback: Callable[[str], None] | None = None,
) -> dict[str, Any]:
    benchmarks: list[dict[str, Any]] = []
    grouped_records: dict[tuple[str, str, str | None], dict[str, dict[str, Any]]] = {}
    total_cases = len(scenarios) * len(devices)
    completed_cases = 0

    for scenario_name in scenarios:
        for device in devices:
            completed_cases += 1
            if progress_callback is not None:
                method_label = method if method != "sqp" else f"{method}/{hessian_model}"
                progress_callback(
                    f"[{completed_cases}/{total_cases}] running {scenario_name} on {device} ({method_label})"
                )

            record = _benchmark_case(
                scenario_name=scenario_name,
                device=device,
                method=method,
                hessian_model=hessian_model,
                repeats=repeats,
                max_iter=max_iter,
                tol=tol,
                capture_history=capture_history,
            )
            benchmarks.append(record)

            if progress_callback is not None:
                progress_callback(_benchmark_summary_line(record))

            key = (
                str(record["scenario"]),
                str(record["method"]),
                str(record.get("constrained_hessian_model")),
            )
            records_by_device = grouped_records.setdefault(key, {})
            records_by_device[str(record["device"])] = record
            paired_summary = _paired_device_summary_line(records_by_device)
            if progress_callback is not None and paired_summary is not None:
                progress_callback(paired_summary)

    _annotate_device_speedups(benchmarks)
    benchmark_family = f"constrained_{method}"
    notes = [
        "Default constrained scenarios are a shared cross-method comparison suite for SQP and interior-point, with matched CPU/CUDA cases and mixed equality-plus-inequality-plus-bounds workloads; smaller diagnostic and method-specific workloads remain available through explicit scenario selection.",
        "Large dense constrained workloads are included on purpose so CPU-versus-CUDA speedup reflects KKT and Jacobian cost rather than mostly Python control flow.",
        f"The constrained iteration budget for this report is set to {max_iter} so the selected comparison workloads converge honestly without requiring per-scenario overrides.",
        "Each row records solver outcome, iteration diagnostics, and timing so performance regressions can be separated from convergence failures.",
        "The timed path can disable history capture while the report still carries accepted-iteration and trial-attempt counts from an untimed diagnostic run.",
    ]
    return {
        "project": "torch-nonlinear",
        "benchmark_family": benchmark_family,
        "version": "0.1.0a0",
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "requested_scenarios": list(scenarios),
        "requested_devices": [str(device) for device in devices],
        "method": method,
        "comparison_methods": ["sqp", "interior_point"],
        "constrained_hessian_model": hessian_model if method == "sqp" else None,
        "benchmarks": benchmarks,
        "notes": notes,
    }


def write_report(output_path: Path, report: dict[str, Any]) -> Path:
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    return output_path


def parse_args(argv: Sequence[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Benchmark constrained-method scenarios and write a JSON report.")
    parser.add_argument("--method", choices=supported_constrained_methods(), default="sqp")
    parser.add_argument(
        "--scenario-set",
        choices=supported_benchmark_scenario_sets(),
        default="default",
        help="Named constrained benchmark suite to run when --scenarios is not specified.",
    )
    parser.add_argument(
        "--scenarios",
        nargs="+",
        type=resolve_constrained_scenario_name,
        default=None,
        help="Subset of constrained scenarios to benchmark. Defaults depend on the selected constrained method.",
    )
    parser.add_argument(
        "--devices",
        nargs="+",
        choices=("cpu", "cuda"),
        default=("cpu", "cuda"),
        help="Devices to benchmark. Defaults to matched CPU and CUDA runs for direct comparison.",
    )
    parser.add_argument("--hessian-model", choices=("bfgs", "exact"), default="bfgs")
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--max-iter", type=int, default=40)
    parser.add_argument("--tol", type=float, default=1e-6)
    parser.add_argument("--capture-history", action="store_true", help="Capture history during timed runs as well as the untimed diagnostic run.")
    parser.add_argument(
        "--output",
        default=f"benchmarks/results/{datetime.now(timezone.utc).strftime('%Y-%m-%dT%H%M%S')}_constrained_benchmark.json",
        help="Path to the JSON output file.",
    )
    parser.add_argument(
        "--force",
        action="store_true",
        help="Run even if the git worktree is dirty.",
    )
    args = parser.parse_args(argv)
    if args.scenarios is None:
        args.scenarios = list(benchmark_scenarios_for_set(method=args.method, scenario_set=args.scenario_set))
    return args


def main(argv: Sequence[str] | None = None) -> int:
    args = parse_args(argv)
    if "cuda" in args.devices and not torch.cuda.is_available():
        print("CUDA benchmarking requested, but CUDA is not available.", file=sys.stderr)
        return 1

    repo_root = Path(__file__).resolve().parents[1]
    try:
        git_metadata = collect_git_metadata(repo_root=repo_root)
        if not args.force:
            ensure_clean_git_worktree(git_metadata)
    except (OSError, RuntimeError, subprocess.SubprocessError) as exc:
        print(str(exc), file=sys.stderr)
        return 1

    devices = tuple(torch.device(name) for name in args.devices)
    method_label = args.method if args.method != "sqp" else f"{args.method}/{args.hessian_model}"
    _print_progress(
        f"starting benchmark run for {method_label} across {len(args.scenarios)} scenarios on {', '.join(args.devices)}"
    )
    report = build_report(
        scenarios=tuple(args.scenarios),
        devices=devices,
        method=args.method,
        hessian_model=args.hessian_model,
        repeats=args.repeats,
        max_iter=args.max_iter,
        tol=args.tol,
        capture_history=args.capture_history,
        progress_callback=_print_progress,
    )
    report.update(git_metadata)
    output_path = Path(args.output)
    write_report(output_path, report)
    _print_progress(f"wrote constrained benchmark report to {output_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())