# pyright: reportMissingTypeStubs=false

"""Shared constrained benchmark scenarios and result summarization helpers."""

from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass
from typing import Any

import torch

from pytorch_nonlinear.api.config import DebugConfig, SolverConfig
from pytorch_nonlinear.api.solve import solve
from pytorch_nonlinear.constraints import Bounds, EqualityConstraint, InequalityConstraint
from pytorch_nonlinear.diagnostics import SolveResult
from pytorch_nonlinear.problem import ConstrainedNLPProblem


@dataclass(frozen=True)
class ConstrainedBenchmarkScenario:
    """Concrete constrained benchmark problem plus scenario metadata."""

    name: str
    problem: ConstrainedNLPProblem
    x0: torch.Tensor
    params: dict[str, Any] | None
    metadata: dict[str, Any]
    reference_solution: torch.Tensor | None = None


@dataclass(frozen=True)
class ConstrainedScenarioSuite:
    """Named route over canonical constrained scenario names."""

    name: str
    scenarios: tuple[str, ...]


@dataclass(frozen=True)
class ConstrainedScenarioSetRoute:
    """Default benchmark and profile routing for a constrained scenario set."""

    name: str
    benchmark_scenarios: tuple[str, ...]
    default_profile_scenario: str


_DIAGNOSTIC_SCENARIOS = (
    "quadratic_equality_only_small",
    "quadratic_equality_bounds_active_small",
    "quadratic_equality_bounds_infeasible_start_small",
    "quadratic_redundant_equality_small",
    "quadratic_near_active_bound_small",
    "quadratic_mixed_constraints_small",
    "quadratic_mixed_infeasible_start_small",
)

_COMPARISON_SCENARIOS = (
    "quadratic_equality_bounds_medium",
    "quadratic_mixed_constraints_medium",
    "quadratic_equality_bounds_large",
    "quadratic_mixed_constraints_large",
    "quadratic_mixed_constraints_1024",
    "quadratic_mixed_constraints_xlarge",
    "quadratic_multi_equality_bounds_large",
    "quadratic_infeasible_start_large",
    "quadratic_multi_equality_bounds_xlarge",
)

_REALISTIC_COMPARISON_SCENARIOS = (
    "nonlinear_mixed_constraints_medium",
    "nonlinear_mixed_constraints_large",
    "nonlinear_mixed_constraints_1024",
    "nonlinear_mixed_constraints_xlarge",
)

_REALISTIC_PROFILE_SCENARIOS = (
    "nonlinear_mixed_constraints_1536",
)

_SCENARIO_COMPATIBILITY_ALIASES = {
    "quadratic_equality_bounds_medium_cpu": "quadratic_equality_bounds_medium",
    "quadratic_equality_bounds_large_cuda": "quadratic_equality_bounds_large",
    "quadratic_multi_equality_bounds_large_cuda": "quadratic_multi_equality_bounds_large",
    "quadratic_multi_equality_bounds_xlarge_cuda": "quadratic_multi_equality_bounds_xlarge",
    "quadratic_infeasible_start_large_cuda": "quadratic_infeasible_start_large",
}

_COMPARABLE_METHOD_SCENARIOS = (
    "quadratic_mixed_constraints_medium",
    "quadratic_mixed_constraints_large",
    "quadratic_mixed_constraints_1024",
    "quadratic_mixed_constraints_xlarge",
)
_DEFAULT_BENCHMARK_SCENARIOS = _COMPARISON_SCENARIOS
_SUPPORTED_METHODS = ("sqp", "interior_point")
_SCENARIO_SUITES = {
    "diagnostic": ConstrainedScenarioSuite(name="diagnostic", scenarios=_DIAGNOSTIC_SCENARIOS),
    "comparison": ConstrainedScenarioSuite(name="comparison", scenarios=_COMPARISON_SCENARIOS),
    "realistic_comparison": ConstrainedScenarioSuite(name="realistic_comparison", scenarios=_REALISTIC_COMPARISON_SCENARIOS),
    "realistic_profile": ConstrainedScenarioSuite(name="realistic_profile", scenarios=_REALISTIC_PROFILE_SCENARIOS),
}
_SCENARIO_SET_ROUTES = {
    "default": ConstrainedScenarioSetRoute(
        name="default",
        benchmark_scenarios=_COMPARABLE_METHOD_SCENARIOS,
        default_profile_scenario="quadratic_mixed_constraints_large",
    ),
    "realistic": ConstrainedScenarioSetRoute(
        name="realistic",
        benchmark_scenarios=_REALISTIC_COMPARISON_SCENARIOS,
        default_profile_scenario="nonlinear_mixed_constraints_large",
    ),
}


def _ordered_unique(names: Sequence[str]) -> tuple[str, ...]:
    return tuple(dict.fromkeys(names))


_SUPPORTED_SCENARIOS = _ordered_unique(
    [
        *(_SCENARIO_SUITES["diagnostic"].scenarios),
        *(_SCENARIO_SUITES["comparison"].scenarios),
        *(_SCENARIO_SUITES["realistic_comparison"].scenarios),
        *(_SCENARIO_SUITES["realistic_profile"].scenarios),
    ]
)


def _supported_scenario_set_names() -> tuple[str, ...]:
    return tuple(_SCENARIO_SET_ROUTES)


def _validate_supported_method(method: str) -> str:
    normalized_method = method.strip().lower()
    if normalized_method in _SUPPORTED_METHODS:
        return normalized_method
    supported = ", ".join(_SUPPORTED_METHODS)
    raise ValueError(f"Unsupported constrained benchmark method '{method}'. Expected one of: {supported}.")


def _scenario_set_route(name: str) -> ConstrainedScenarioSetRoute:
    normalized_name = name.strip().lower()
    try:
        return _SCENARIO_SET_ROUTES[normalized_name]
    except KeyError as exc:
        supported = ", ".join(_supported_scenario_set_names())
        raise ValueError(
            f"Unsupported constrained benchmark scenario set '{name}'. Expected one of: {supported}."
        ) from exc


def _canonical_scenario_name(name: str) -> str:
    return _SCENARIO_COMPATIBILITY_ALIASES.get(name, name)


def resolve_constrained_scenario_name(name: str) -> str:
    canonical_name = _canonical_scenario_name(name.strip())
    if canonical_name in _SUPPORTED_SCENARIOS:
        return canonical_name
    supported = ", ".join(_SUPPORTED_SCENARIOS)
    raise ValueError(f"Unsupported constrained benchmark scenario '{name}'. Expected one of: {supported}.")


def resolve_constrained_scenarios(names: Sequence[str]) -> tuple[str, ...]:
    return tuple(resolve_constrained_scenario_name(name) for name in names)


def _comparison_mode_for_group(group: str) -> str:
    if group in {"comparison", "realistic_comparison"}:
        return "matched_cpu_cuda"
    return "targeted_diagnostic"


def _comparison_devices_for_group(group: str) -> list[str]:
    if group in {"comparison", "realistic_comparison"}:
        return ["cpu", "cuda"]
    return ["cpu"]


def diagnostic_benchmark_scenarios() -> tuple[str, ...]:
    return _SCENARIO_SUITES["diagnostic"].scenarios


def comparison_benchmark_scenarios() -> tuple[str, ...]:
    return _SCENARIO_SUITES["comparison"].scenarios


def supported_scenarios() -> tuple[str, ...]:
    return _SUPPORTED_SCENARIOS


def default_benchmark_scenarios() -> tuple[str, ...]:
    return _DEFAULT_BENCHMARK_SCENARIOS


def comparable_benchmark_scenarios() -> tuple[str, ...]:
    return _COMPARABLE_METHOD_SCENARIOS


def realistic_benchmark_scenarios() -> tuple[str, ...]:
    return _SCENARIO_SET_ROUTES["realistic"].benchmark_scenarios


def supported_constrained_methods() -> tuple[str, ...]:
    return _SUPPORTED_METHODS


def supported_benchmark_scenario_sets() -> tuple[str, ...]:
    return _supported_scenario_set_names()


def default_benchmark_scenarios_for_method(method: str) -> tuple[str, ...]:
    _validate_supported_method(method)
    return _SCENARIO_SET_ROUTES["default"].benchmark_scenarios


def benchmark_scenarios_for_set(*, method: str, scenario_set: str) -> tuple[str, ...]:
    _validate_supported_method(method)
    return _scenario_set_route(scenario_set).benchmark_scenarios


def default_profile_scenario_for_set(*, method: str, scenario_set: str) -> str:
    _validate_supported_method(method)
    return _scenario_set_route(scenario_set).default_profile_scenario


def _float(value: Any) -> float | None:
    if value is None:
        return None
    tensor = torch.as_tensor(value)
    return float(tensor.detach().cpu().item())


def _round_or_none(value: float | None, *, digits: int = 6) -> float | None:
    if value is None:
        return None
    return round(value, digits)


def _make_generator(*, seed: int) -> torch.Generator:
    generator = torch.Generator(device="cpu")
    generator.manual_seed(seed)
    return generator


def _randn(shape: tuple[int, ...], *, device: torch.device, generator: torch.Generator) -> torch.Tensor:
    return torch.randn(*shape, dtype=torch.float64, generator=generator).to(device=device)


def _dense_spd_matrix(dim: int, *, device: torch.device, seed: int, ridge: float = 0.4) -> torch.Tensor:
    generator = _make_generator(seed=seed)
    base = _randn((dim, dim), device=device, generator=generator)
    return (base.T @ base) / float(dim) + ridge * torch.eye(dim, dtype=torch.float64, device=device)


def _dense_constraint_matrix(rows: int, cols: int, *, device: torch.device, seed: int) -> torch.Tensor:
    if rows == 0:
        return torch.zeros((0, cols), dtype=torch.float64, device=device)
    generator = _make_generator(seed=seed)
    raw = _randn((rows, cols), device=device, generator=generator)
    row_norms = torch.norm(raw, dim=1, keepdim=True).clamp_min(1e-12)
    normalized = raw / row_norms
    scales = torch.linspace(0.75, 1.25, rows, dtype=torch.float64, device=device)
    return (normalized * scales[:, None]).contiguous()


def _project_bounds(x: torch.Tensor, lower: torch.Tensor | None, upper: torch.Tensor | None) -> torch.Tensor:
    projected = x.clone()
    if lower is not None:
        projected = torch.maximum(projected, lower)
    if upper is not None:
        projected = torch.minimum(projected, upper)
    return projected


def _constraint_violation(
    x: torch.Tensor,
    *,
    equality_matrix: torch.Tensor,
    equality_rhs: torch.Tensor,
    inequality_matrix: torch.Tensor,
    inequality_rhs: torch.Tensor,
    lower: torch.Tensor | None,
    upper: torch.Tensor | None,
) -> float:
    components: list[torch.Tensor] = []
    if equality_matrix.shape[0] > 0:
        components.append(torch.max(torch.abs(equality_matrix @ x - equality_rhs)))
    if inequality_matrix.shape[0] > 0:
        components.append(torch.max(torch.clamp(inequality_matrix @ x - inequality_rhs, min=0.0)))
    if lower is not None:
        components.append(torch.max(torch.clamp(lower - x, min=0.0)))
    if upper is not None:
        components.append(torch.max(torch.clamp(x - upper, min=0.0)))
    if not components:
        return 0.0
    return float(torch.stack(components).max().detach().cpu().item())


def _problem_constraint_violation(problem: ConstrainedNLPProblem, x: torch.Tensor) -> float:
    components: list[torch.Tensor] = []
    for constraint in problem.constraints:
        value = torch.as_tensor(constraint.evaluate(x, None), dtype=torch.float64, device=x.device)
        if isinstance(constraint, EqualityConstraint):
            components.append(torch.max(torch.abs(value)))
        else:
            components.append(torch.max(torch.clamp(value, min=0.0)))

    bounds = problem.bounds
    if bounds is not None and bounds.lower is not None:
        lower = torch.as_tensor(bounds.lower, dtype=torch.float64, device=x.device)
        components.append(torch.max(torch.clamp(lower - x, min=0.0)))
    if bounds is not None and bounds.upper is not None:
        upper = torch.as_tensor(bounds.upper, dtype=torch.float64, device=x.device)
        components.append(torch.max(torch.clamp(x - upper, min=0.0)))

    if not components:
        return 0.0
    return float(torch.stack(components).max().detach().cpu().item())


def _build_linear_quadratic_scenario(
    name: str,
    *,
    device: torch.device,
    dim: int,
    num_equalities: int,
    num_inequalities: int = 0,
    seed: int,
    scenario_group: str,
    active_upper_indices: tuple[int, ...] = (),
    near_upper_indices: tuple[int, ...] = (),
    active_inequality_indices: tuple[int, ...] = (),
    near_active_inequality_indices: tuple[int, ...] = (),
    initial_perturbation_scale: float = 0.35,
    infeasible_start: bool = False,
    redundant_equalities: bool = False,
) -> ConstrainedBenchmarkScenario:
    quadratic = _dense_spd_matrix(dim, device=device, seed=seed)
    generator = _make_generator(seed=seed + 1)
    x_star = 0.2 * _randn((dim,), device=device, generator=generator)

    lower = x_star - 1.5
    upper = x_star + 1.5
    for index in active_upper_indices:
        upper[index] = x_star[index]
    for index in near_upper_indices:
        upper[index] = x_star[index] + 1e-3

    if redundant_equalities:
        effective_equalities = max(num_equalities, 2)
    else:
        effective_equalities = num_equalities
    equality_matrix = _dense_constraint_matrix(effective_equalities, dim, device=device, seed=seed + 2)
    if redundant_equalities:
        equality_matrix[1] = 2.0 * equality_matrix[0]
    equality_rhs = equality_matrix @ x_star

    inequality_matrix = _dense_constraint_matrix(num_inequalities, dim, device=device, seed=seed + 3)
    inequality_rhs = x_star.new_zeros(num_inequalities)
    inequality_multipliers = x_star.new_zeros(num_inequalities)
    if num_inequalities > 0:
        inequality_slack = torch.linspace(0.2, 0.6, num_inequalities, dtype=torch.float64, device=device)
        for index in active_inequality_indices:
            inequality_slack[index] = 0.0
        for index in near_active_inequality_indices:
            inequality_slack[index] = 1e-4
        inequality_rhs = inequality_matrix @ x_star + inequality_slack
        for offset, index in enumerate(active_inequality_indices):
            inequality_multipliers[index] = 0.18 + 0.04 * offset

    multiplier_values = torch.linspace(0.15, 0.35, effective_equalities, dtype=torch.float64, device=device)
    lower_multipliers = torch.zeros(dim, dtype=torch.float64, device=device)
    upper_multipliers = torch.zeros(dim, dtype=torch.float64, device=device)
    for offset, index in enumerate(active_upper_indices):
        upper_multipliers[index] = 0.2 + 0.05 * offset
    linear = -(quadratic @ x_star)
    if effective_equalities > 0:
        linear = linear - equality_matrix.T @ multiplier_values
    if num_inequalities > 0:
        linear = linear - inequality_matrix.T @ inequality_multipliers
    linear = linear + lower_multipliers - upper_multipliers

    def objective(state: torch.Tensor, params: dict[str, Any] | None) -> torch.Tensor:
        del params
        return 0.5 * torch.dot(state, quadratic @ state) + torch.dot(linear, state)

    equality_constraints = tuple(
        EqualityConstraint(
            lambda state, params, row=equality_matrix[index], rhs=equality_rhs[index]: torch.dot(row, state) - rhs
        )
        for index in range(effective_equalities)
    )
    inequality_constraints = tuple(
        InequalityConstraint(
            lambda state, params, row=inequality_matrix[index], rhs=inequality_rhs[index]: torch.dot(row, state) - rhs
        )
        for index in range(num_inequalities)
    )
    bounds = Bounds(lower=lower, upper=upper, name="box")
    problem = ConstrainedNLPProblem(
        objective=objective,
        constraints=(*equality_constraints, *inequality_constraints),
        bounds=bounds,
    )

    raw_x0 = x_star + initial_perturbation_scale * _randn((dim,), device=device, generator=generator)
    if infeasible_start:
        raw_x0 = x_star + 1.25 * _randn((dim,), device=device, generator=generator)
        if dim > 0:
            raw_x0[0] = upper[0] + 0.8
        if dim > 1:
            raw_x0[1] = lower[1] - 0.8
        if num_inequalities > 0:
            violating_index = active_inequality_indices[0] if active_inequality_indices else 0
            raw_x0 = raw_x0 + 1.1 * inequality_matrix[violating_index]
    effective_x0 = _project_bounds(raw_x0, lower, upper)
    projected_initialization = not torch.allclose(raw_x0, effective_x0)

    metadata = {
        "scenario": name,
        "dimension": dim,
        "num_equalities": effective_equalities,
        "num_inequalities": num_inequalities,
        "has_equalities": effective_equalities > 0,
        "has_inequalities": num_inequalities > 0,
        "has_bounds": True,
        "scenario_group": scenario_group,
        "comparison_mode": _comparison_mode_for_group(scenario_group),
        "comparison_devices": _comparison_devices_for_group(scenario_group),
        "projected_initialization": projected_initialization,
        "reference_active_bound_count": len(active_upper_indices),
        "reference_active_inequality_count": len(active_inequality_indices),
        "initial_constraint_violation": _round_or_none(
            _constraint_violation(
                effective_x0,
                equality_matrix=equality_matrix,
                equality_rhs=equality_rhs,
                inequality_matrix=inequality_matrix,
                inequality_rhs=inequality_rhs,
                lower=lower,
                upper=upper,
            )
        ),
    }
    return ConstrainedBenchmarkScenario(
        name=name,
        problem=problem,
        x0=raw_x0,
        params=None,
        metadata=metadata,
        reference_solution=x_star,
    )


def _build_nonlinear_mixed_scenario(
    name: str,
    *,
    device: torch.device,
    dim: int,
    num_equalities: int,
    num_inequalities: int,
    seed: int,
    scenario_group: str,
    active_upper_indices: tuple[int, ...] = (),
    active_inequality_indices: tuple[int, ...] = (),
    near_active_inequality_indices: tuple[int, ...] = (),
    initial_perturbation_scale: float = 0.2,
) -> ConstrainedBenchmarkScenario:
    quadratic = _dense_spd_matrix(dim, device=device, seed=seed)
    generator = _make_generator(seed=seed + 1)
    x_star = 0.15 * _randn((dim,), device=device, generator=generator)

    lower = x_star - 1.25
    upper = x_star + 1.25
    for index in active_upper_indices:
        upper[index] = x_star[index]

    equality_matrix = _dense_constraint_matrix(num_equalities, dim, device=device, seed=seed + 2)
    equality_rhs = equality_matrix @ x_star

    base_rows = _dense_constraint_matrix(num_inequalities, dim, device=device, seed=seed + 3)
    curve_rows = _dense_constraint_matrix(num_inequalities, dim, device=device, seed=seed + 4)
    curvature = torch.linspace(0.18, 0.42, num_inequalities, dtype=torch.float64, device=device)

    shifted_projection = curve_rows @ x_star
    inequality_slack = torch.linspace(0.08, 0.28, num_inequalities, dtype=torch.float64, device=device)
    for index in active_inequality_indices:
        inequality_slack[index] = 0.0
    for index in near_active_inequality_indices:
        inequality_slack[index] = 5e-4
    inequality_rhs = base_rows @ x_star + curvature * shifted_projection.square() + inequality_slack

    equality_multipliers = torch.linspace(0.12, 0.28, num_equalities, dtype=torch.float64, device=device)
    inequality_multipliers = torch.zeros(num_inequalities, dtype=torch.float64, device=device)
    for offset, index in enumerate(active_inequality_indices):
        inequality_multipliers[index] = 0.12 + 0.03 * offset
    upper_multipliers = torch.zeros(dim, dtype=torch.float64, device=device)
    for offset, index in enumerate(active_upper_indices):
        upper_multipliers[index] = 0.14 + 0.03 * offset

    inequality_gradient_at_star = base_rows + 2.0 * curvature[:, None] * shifted_projection[:, None] * curve_rows

    linear = -(quadratic @ x_star)
    if num_equalities > 0:
        linear = linear - equality_matrix.T @ equality_multipliers
    if num_inequalities > 0:
        linear = linear - inequality_gradient_at_star.T @ inequality_multipliers
    linear = linear - upper_multipliers

    def objective(state: torch.Tensor, params: dict[str, Any] | None) -> torch.Tensor:
        del params
        return 0.5 * torch.dot(state, quadratic @ state) + torch.dot(linear, state)

    equality_constraints = tuple(
        EqualityConstraint(
            lambda state, params, row=equality_matrix[index], rhs=equality_rhs[index]: torch.dot(row, state) - rhs
        )
        for index in range(num_equalities)
    )
    inequality_constraints = tuple(
        InequalityConstraint(
            lambda state, params, base_row=base_rows[index], curve_row=curve_rows[index], curve=curvature[index], rhs=inequality_rhs[index]: (
                torch.dot(base_row, state) + curve * torch.dot(curve_row, state).square() - rhs
            )
        )
        for index in range(num_inequalities)
    )
    bounds = Bounds(lower=lower, upper=upper, name="box")
    problem = ConstrainedNLPProblem(
        objective=objective,
        constraints=(*equality_constraints, *inequality_constraints),
        bounds=bounds,
    )

    raw_x0 = x_star + initial_perturbation_scale * _randn((dim,), device=device, generator=generator)
    effective_x0 = _project_bounds(raw_x0, lower, upper)
    projected_initialization = not torch.allclose(raw_x0, effective_x0)

    metadata = {
        "scenario": name,
        "dimension": dim,
        "num_equalities": num_equalities,
        "num_inequalities": num_inequalities,
        "has_equalities": num_equalities > 0,
        "has_inequalities": num_inequalities > 0,
        "has_bounds": True,
        "scenario_group": scenario_group,
        "comparison_mode": _comparison_mode_for_group(scenario_group),
        "comparison_devices": _comparison_devices_for_group(scenario_group),
        "projected_initialization": projected_initialization,
        "reference_active_bound_count": len(active_upper_indices),
        "reference_active_inequality_count": len(active_inequality_indices),
        "constraint_family": "nonlinear_convex_mixed",
        "initial_constraint_violation": None,
    }
    scenario = ConstrainedBenchmarkScenario(
        name=name,
        problem=problem,
        x0=raw_x0,
        params=None,
        metadata=metadata,
        reference_solution=x_star,
    )
    scenario.metadata["initial_constraint_violation"] = _round_or_none(
        _problem_constraint_violation(problem, effective_x0)
    )
    return scenario


def build_constrained_scenario(name: str, *, device: torch.device) -> ConstrainedBenchmarkScenario:
    canonical_name = _canonical_scenario_name(name)
    builders = {
        "quadratic_equality_only_small": lambda: _build_linear_quadratic_scenario(
            canonical_name,
            device=device,
            dim=6,
            num_equalities=1,
            seed=11,
            scenario_group="diagnostic",
        ),
        "quadratic_equality_bounds_active_small": lambda: _build_linear_quadratic_scenario(
            canonical_name,
            device=device,
            dim=8,
            num_equalities=1,
            seed=13,
            scenario_group="diagnostic",
            active_upper_indices=(0,),
        ),
        "quadratic_equality_bounds_infeasible_start_small": lambda: _build_linear_quadratic_scenario(
            canonical_name,
            device=device,
            dim=8,
            num_equalities=1,
            seed=17,
            scenario_group="diagnostic",
            active_upper_indices=(0,),
            infeasible_start=True,
        ),
        "quadratic_redundant_equality_small": lambda: _build_linear_quadratic_scenario(
            canonical_name,
            device=device,
            dim=8,
            num_equalities=2,
            seed=19,
            scenario_group="diagnostic",
            redundant_equalities=True,
        ),
        "quadratic_near_active_bound_small": lambda: _build_linear_quadratic_scenario(
            canonical_name,
            device=device,
            dim=8,
            num_equalities=1,
            seed=23,
            scenario_group="diagnostic",
            near_upper_indices=(0,),
        ),
        "quadratic_mixed_constraints_small": lambda: _build_linear_quadratic_scenario(
            canonical_name,
            device=device,
            dim=10,
            num_equalities=1,
            num_inequalities=2,
            seed=27,
            scenario_group="diagnostic",
            active_upper_indices=(0,),
            active_inequality_indices=(0,),
            near_active_inequality_indices=(1,),
        ),
        "quadratic_mixed_infeasible_start_small": lambda: _build_linear_quadratic_scenario(
            canonical_name,
            device=device,
            dim=10,
            num_equalities=1,
            num_inequalities=2,
            seed=28,
            scenario_group="diagnostic",
            active_upper_indices=(0,),
            active_inequality_indices=(0,),
            infeasible_start=True,
        ),
        "quadratic_equality_bounds_medium": lambda: _build_linear_quadratic_scenario(
            canonical_name,
            device=device,
            dim=96,
            num_equalities=6,
            seed=29,
            scenario_group="comparison",
            active_upper_indices=(0, 3),
        ),
        "quadratic_mixed_constraints_medium": lambda: _build_linear_quadratic_scenario(
            canonical_name,
            device=device,
            dim=96,
            num_equalities=4,
            num_inequalities=6,
            seed=33,
            scenario_group="comparison",
            active_upper_indices=(0, 3),
            active_inequality_indices=(0,),
            near_active_inequality_indices=(2,),
            initial_perturbation_scale=0.12,
        ),
        "quadratic_equality_bounds_large": lambda: _build_linear_quadratic_scenario(
            canonical_name,
            device=device,
            dim=384,
            num_equalities=8,
            seed=31,
            scenario_group="comparison",
            active_upper_indices=(0, 5, 11),
        ),
        "quadratic_mixed_constraints_large": lambda: _build_linear_quadratic_scenario(
            canonical_name,
            device=device,
            dim=384,
            num_equalities=10,
            num_inequalities=12,
            seed=35,
            scenario_group="comparison",
            active_upper_indices=(0, 9),
            active_inequality_indices=(0, 4),
            near_active_inequality_indices=(7,),
            initial_perturbation_scale=0.1,
        ),
        "quadratic_mixed_constraints_1024": lambda: _build_linear_quadratic_scenario(
            canonical_name,
            device=device,
            dim=1024,
            num_equalities=20,
            num_inequalities=24,
            seed=45,
            scenario_group="comparison",
            active_upper_indices=(0, 17, 121, 509),
            active_inequality_indices=(0, 5, 13),
            near_active_inequality_indices=(8, 19),
            initial_perturbation_scale=0.09,
        ),
        "quadratic_mixed_constraints_xlarge": lambda: _build_linear_quadratic_scenario(
            canonical_name,
            device=device,
            dim=2048,
            num_equalities=32,
            num_inequalities=48,
            seed=47,
            scenario_group="comparison",
            active_upper_indices=(0, 41, 211, 503, 1207),
            active_inequality_indices=(0, 7, 19, 31, 43),
            near_active_inequality_indices=(11,),
            initial_perturbation_scale=0.08,
        ),
        "nonlinear_mixed_constraints_medium": lambda: _build_nonlinear_mixed_scenario(
            canonical_name,
            device=device,
            dim=128,
            num_equalities=4,
            num_inequalities=12,
            seed=51,
            scenario_group="realistic_comparison",
            active_upper_indices=(0, 9),
            active_inequality_indices=(0, 4, 9),
            near_active_inequality_indices=(6,),
            initial_perturbation_scale=0.16,
        ),
        "nonlinear_mixed_constraints_large": lambda: _build_nonlinear_mixed_scenario(
            canonical_name,
            device=device,
            dim=512,
            num_equalities=8,
            num_inequalities=24,
            seed=53,
            scenario_group="realistic_comparison",
            active_upper_indices=(0, 19, 87),
            active_inequality_indices=(0, 7, 13, 21),
            near_active_inequality_indices=(10, 18),
            initial_perturbation_scale=0.14,
        ),
        "nonlinear_mixed_constraints_1024": lambda: _build_nonlinear_mixed_scenario(
            canonical_name,
            device=device,
            dim=1024,
            num_equalities=12,
            num_inequalities=40,
            seed=55,
            scenario_group="realistic_comparison",
            active_upper_indices=(0, 33, 211, 509),
            active_inequality_indices=(0, 8, 17, 31),
            near_active_inequality_indices=(12, 24, 35),
            initial_perturbation_scale=0.12,
        ),
        "nonlinear_mixed_constraints_1536": lambda: _build_nonlinear_mixed_scenario(
            canonical_name,
            device=device,
            dim=1536,
            num_equalities=14,
            num_inequalities=52,
            seed=56,
            scenario_group="realistic_comparison",
            active_upper_indices=(0, 37, 211, 503),
            active_inequality_indices=(0, 9, 19, 33, 44),
            near_active_inequality_indices=(12, 27, 39),
            initial_perturbation_scale=0.11,
        ),
        "nonlinear_mixed_constraints_xlarge": lambda: _build_nonlinear_mixed_scenario(
            canonical_name,
            device=device,
            dim=2048,
            num_equalities=16,
            num_inequalities=64,
            seed=57,
            scenario_group="realistic_comparison",
            active_upper_indices=(0, 41, 211, 503, 1207),
            active_inequality_indices=(0, 11, 23, 37, 52),
            near_active_inequality_indices=(7, 18, 44),
            initial_perturbation_scale=0.1,
        ),
        "quadratic_multi_equality_bounds_large": lambda: _build_linear_quadratic_scenario(
            canonical_name,
            device=device,
            dim=512,
            num_equalities=24,
            seed=37,
            scenario_group="comparison",
            active_upper_indices=(0, 7, 21, 35),
        ),
        "quadratic_multi_equality_bounds_xlarge": lambda: _build_linear_quadratic_scenario(
            canonical_name,
            device=device,
            dim=2048,
            num_equalities=96,
            seed=43,
            scenario_group="comparison",
            active_upper_indices=(0, 19, 61, 149, 311, 587, 1013, 1601),
        ),
        "quadratic_infeasible_start_large": lambda: _build_linear_quadratic_scenario(
            canonical_name,
            device=device,
            dim=384,
            num_equalities=12,
            seed=41,
            scenario_group="comparison",
            active_upper_indices=(0, 4),
            infeasible_start=True,
        ),
    }
    try:
        return builders[canonical_name]()
    except KeyError as exc:
        supported = ", ".join(_SUPPORTED_SCENARIOS)
        raise ValueError(f"Unsupported constrained benchmark scenario '{name}'. Expected one of: {supported}.") from exc


def run_constrained_scenario(
    scenario: ConstrainedBenchmarkScenario,
    *,
    device: torch.device,
    method: str,
    hessian_model: str,
    max_iter: int,
    tol: float,
    capture_history: bool,
) -> SolveResult:
    normalized_method = method.strip().lower()
    if normalized_method not in _SUPPORTED_METHODS:
        supported = ", ".join(_SUPPORTED_METHODS)
        raise ValueError(f"Unsupported constrained benchmark method '{method}'. Expected one of: {supported}.")

    config_kwargs: dict[str, Any] = {
        "method": normalized_method,
        "device": str(device),
        "max_iter": max_iter,
        "tol": tol,
        "debug": DebugConfig(capture_history=capture_history),
    }
    if normalized_method == "sqp":
        config_kwargs["constrained_hessian_model"] = hessian_model

    return solve(
        scenario.problem,
        x0=scenario.x0,
        params=scenario.params,
        config=SolverConfig(**config_kwargs),
    )


def summarize_constrained_result(
    *,
    scenario: ConstrainedBenchmarkScenario,
    result: SolveResult,
    device: torch.device,
    method: str,
    hessian_model: str,
    max_iter: int,
    tol: float,
) -> dict[str, Any]:
    normalized_method = method.strip().lower()
    trial_counts = [len(record.trials) for record in result.history]
    total_trial_attempts = int(sum(trial_counts))
    accepted_iterations = int(sum(int(record.accepted) for record in result.history))
    rejected_iterations = int(len(result.history) - accepted_iterations)
    reference_error = None
    if result.x is not None and scenario.reference_solution is not None:
        final_x = torch.as_tensor(result.x, dtype=scenario.reference_solution.dtype, device=scenario.reference_solution.device).reshape(-1)
        reference_error = float(torch.norm(final_x - scenario.reference_solution).detach().cpu().item())

    summary = {
        **scenario.metadata,
        "device": str(device),
        "method": normalized_method,
        "max_iter": max_iter,
        "tol": tol,
        "success": bool(result.success),
        "status": result.status.value,
        "termination": result.termination.value,
        "num_outer_iterations": int(result.num_iter),
        "accepted_iterations": accepted_iterations,
        "rejected_iterations": rejected_iterations,
        "total_trial_attempts": total_trial_attempts,
        "max_trial_attempts_per_outer_iteration": int(max(trial_counts)) if trial_counts else 0,
        "average_trial_attempts_per_outer_iteration": _round_or_none(total_trial_attempts / len(trial_counts), digits=4) if trial_counts else 0.0,
        "objective_value": _round_or_none(_float(result.objective_value)),
        "gradient_norm": _round_or_none(_float(result.gradient_norm)),
        "step_norm": _round_or_none(_float(result.step_norm)),
        "final_constraint_violation": _round_or_none(_float(result.constraint_violation)),
        "final_kkt_residual": _round_or_none(_float(result.kkt_residual)),
        "linear_condition_estimate": _round_or_none(_float(result.linear_condition_estimate)),
        "linear_residual_norm": _round_or_none(_float(result.linear_residual_norm)),
        "final_active_set": list(result.active_set),
        "final_diagnosis": [code.value for code in result.diagnosis],
        "reference_solution_error_norm": _round_or_none(reference_error),
    }
    if normalized_method == "sqp":
        summary["constrained_hessian_model"] = hessian_model
    return summary