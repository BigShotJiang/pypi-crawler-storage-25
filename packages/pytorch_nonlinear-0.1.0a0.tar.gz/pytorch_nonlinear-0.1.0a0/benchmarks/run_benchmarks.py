"""Benchmark shared-structure least-squares execution on CPU and CUDA."""

from __future__ import annotations

import argparse
import json
import subprocess
import sys
from dataclasses import dataclass
from collections.abc import Sequence
from datetime import datetime, timezone
from pathlib import Path
from statistics import median
from time import perf_counter
from typing import Any, Callable

import torch

from pytorch_nonlinear import BatchMode, DebugConfig, NonlinearLeastSquaresProblem, SolverConfig, solve


_SUPPORTED_METHODS = ("lm", "trust_region")


@dataclass(frozen=True)
class BenchmarkWorkloadSpec:
    label: str
    batch_size: int
    timepoints: int


_WORKLOAD_SET_REGISTRY = {
    "default": (
        BenchmarkWorkloadSpec(label="small", batch_size=8, timepoints=100),
        BenchmarkWorkloadSpec(label="medium", batch_size=32, timepoints=100),
        BenchmarkWorkloadSpec(label="large", batch_size=64, timepoints=200),
    ),
}


def _print_progress(message: str) -> None:
    print(f"[bench] {message}", flush=True)


def _format_seconds(seconds: float) -> str:
    return f"{seconds:.4f}s"


def _benchmark_summary_line(record: dict[str, Any]) -> str:
    return (
        f"completed {record['method']} {record['workload']} on {record['device']} "
        f"history={'on' if record['capture_history'] else 'off'}: "
        f"batch={_format_seconds(float(record['batch_time_seconds_median']))} "
        f"seq={_format_seconds(float(record['sequential_time_seconds_median']))} "
        f"seq_over_batch={record['speedup_sequential_over_batch']:.2f}x "
        f"successes={record['batch_successes']}/{record['sequential_successes']}"
    )


def supported_workload_sets() -> tuple[str, ...]:
    return tuple(_WORKLOAD_SET_REGISTRY)


def workload_specs_for_set(workload_set: str) -> tuple[BenchmarkWorkloadSpec, ...]:
    normalized_name = workload_set.strip().lower()
    try:
        return _WORKLOAD_SET_REGISTRY[normalized_name]
    except KeyError as exc:
        supported = ", ".join(supported_workload_sets())
        raise ValueError(f"Unsupported benchmark workload set '{workload_set}'. Expected one of: {supported}.") from exc


def _run_git_command(args: Sequence[str], *, repo_root: Path) -> str:
    completed = subprocess.run(
        ["git", *args],
        cwd=repo_root,
        check=True,
        capture_output=True,
        text=True,
    )
    return completed.stdout.strip()


def collect_git_metadata(*, repo_root: Path) -> dict[str, Any]:
    commit = _run_git_command(("rev-parse", "HEAD"), repo_root=repo_root)
    branch = _run_git_command(("rev-parse", "--abbrev-ref", "HEAD"), repo_root=repo_root)
    dirty = bool(_run_git_command(("status", "--porcelain"), repo_root=repo_root))
    return {
        "git_commit": commit,
        "git_branch": branch,
        "git_dirty": dirty,
    }


def ensure_clean_git_worktree(git_metadata: dict[str, Any]) -> None:
    if not git_metadata["git_dirty"]:
        return

    prompt = (
        "Repository has uncommitted changes. Benchmarks are only recorded for clean commits. "
        "Type 'commit' to stop and commit first, or 'abort' to cancel: "
    )
    if not sys.stdin.isatty():
        raise RuntimeError(
            "Repository has uncommitted changes. Commit or stash them before running benchmarks."
        )

    while True:
        response = input(prompt).strip().lower()
        if response == "commit":
            raise RuntimeError("Benchmark run cancelled. Commit your changes and rerun the benchmark.")
        if response == "abort":
            raise RuntimeError("Benchmark run aborted because the repository is dirty.")
        print("Please type 'commit' or 'abort'.", file=sys.stderr)


def _build_sensor_problem() -> NonlinearLeastSquaresProblem:
    def residual(state: torch.Tensor, params: dict[str, torch.Tensor]) -> torch.Tensor:
        t_grid = params["t"]
        y_observed = params["y_obs"]
        prediction = state[0] * torch.exp(-state[1] * t_grid) * torch.cos(state[2] * t_grid + state[3])
        return prediction - y_observed

    return NonlinearLeastSquaresProblem(residual=residual)


def _generate_sensor_data(
    batch_size: int,
    timepoints: int,
    *,
    device: torch.device,
    seed: int,
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    rng = torch.Generator(device=device.type)
    rng.manual_seed(seed)
    t = torch.linspace(0.0, 10.0, timepoints, dtype=torch.float64, device=device)
    amplitude = torch.empty(batch_size, dtype=torch.float64, device=device).uniform_(0.5, 3.0, generator=rng)
    alpha = torch.empty(batch_size, dtype=torch.float64, device=device).uniform_(0.1, 0.8, generator=rng)
    omega = torch.empty(batch_size, dtype=torch.float64, device=device).uniform_(1.0, 4.0, generator=rng)
    phi = torch.empty(batch_size, dtype=torch.float64, device=device).uniform_(0.0, torch.pi, generator=rng)
    true_params = torch.stack([amplitude, alpha, omega, phi], dim=1)
    signal = (
        true_params[:, 0:1]
        * torch.exp(-true_params[:, 1:2] * t.unsqueeze(0))
        * torch.cos(true_params[:, 2:3] * t.unsqueeze(0) + true_params[:, 3:4])
    )
    noise = torch.randn(batch_size, timepoints, dtype=torch.float64, generator=rng, device=device)
    return t, true_params, signal + 0.02 * noise


def _initial_guess(batch_size: int, *, device: torch.device) -> torch.Tensor:
    rng = torch.Generator(device=device.type)
    rng.manual_seed(42)
    base = torch.tensor([1.5, 0.4, 2.5, 1.0], dtype=torch.float64, device=device)
    perturbation = torch.empty(batch_size, 4, dtype=torch.float64, device=device).uniform_(-0.15, 0.15, generator=rng)
    return base.unsqueeze(0).expand(batch_size, -1) + perturbation


def _synchronize(device: torch.device) -> None:
    if device.type == "cuda":
        torch.cuda.synchronize(device)


def _measure(callable_obj: Any, *, device: torch.device, repeats: int) -> tuple[float, list[float]]:
    timings: list[float] = []
    for _ in range(repeats):
        _synchronize(device)
        start = perf_counter()
        callable_obj()
        _synchronize(device)
        timings.append(perf_counter() - start)
    return float(median(timings)), timings


def _trust_region_trial_attempt_diagnostics(results: Sequence[Any]) -> dict[str, float | int] | None:
    trial_counts = [len(record.trials) for result in results for record in result.history]
    if not trial_counts:
        return None

    return {
        "average_trial_attempts_per_outer_iteration": float(sum(trial_counts) / len(trial_counts)),
        "max_trial_attempts_per_outer_iteration": int(max(trial_counts)),
        "outer_iterations_profiled": int(len(trial_counts)),
    }


def _run_batch_solve(
    problem: NonlinearLeastSquaresProblem,
    x0_batch: torch.Tensor,
    params_batch: dict[str, torch.Tensor],
    *,
    device: torch.device,
    capture_history: bool,
    method: str,
    max_iter: int,
    tol: float,
) -> Any:
    return solve(
        problem,
        x0=x0_batch,
        params=params_batch,
        config=SolverConfig(
            method=method,
            device=str(device),
            batch_mode=BatchMode.SHARED_STRUCTURE,
            max_iter=max_iter,
            tol=tol,
            debug=DebugConfig(capture_history=capture_history),
        ),
    )


def _run_sequential_solve(
    problem: NonlinearLeastSquaresProblem,
    x0_batch: torch.Tensor,
    params_batch: dict[str, torch.Tensor],
    *,
    device: torch.device,
    capture_history: bool,
    method: str,
    max_iter: int,
    tol: float,
) -> list[Any]:
    results = []
    for index in range(x0_batch.shape[0]):
        results.append(
            solve(
                problem,
                x0=x0_batch[index],
                params={"t": params_batch["t"], "y_obs": params_batch["y_obs"][index]},
                config=SolverConfig(
                    method=method,
                    device=str(device),
                    max_iter=max_iter,
                    tol=tol,
                    debug=DebugConfig(capture_history=capture_history),
                ),
            )
        )
    return results


def _prepare_sensor_case(
    *,
    device: torch.device,
    batch_size: int,
    timepoints: int,
) -> tuple[
    NonlinearLeastSquaresProblem,
    torch.Tensor,
    dict[str, torch.Tensor],
    torch.Tensor,
]:
    problem = _build_sensor_problem()
    t, true_params, y_obs = _generate_sensor_data(batch_size, timepoints, device=device, seed=batch_size + timepoints)
    x0_batch = _initial_guess(batch_size, device=device)
    params_batch = {"t": t, "y_obs": y_obs}
    return problem, x0_batch, params_batch, true_params


def _benchmark_case(
    *,
    device: torch.device,
    batch_size: int,
    timepoints: int,
    repeats: int,
    method: str,
    max_iter: int,
    tol: float,
    capture_history: bool,
) -> dict[str, Any]:
    problem, x0_batch, params_batch, true_params = _prepare_sensor_case(
        device=device,
        batch_size=batch_size,
        timepoints=timepoints,
    )
    diagnostics_capture_history = capture_history or method == "trust_region"

    # Warm up both paths once to reduce one-time overhead skew and, for trust-region,
    # collect untimed trial-attempt diagnostics from the recorded iteration history.
    batch_result = _run_batch_solve(
        problem,
        x0_batch,
        params_batch,
        device=device,
        capture_history=diagnostics_capture_history,
        method=method,
        max_iter=max_iter,
        tol=tol,
    )
    seq_results = _run_sequential_solve(
        problem,
        x0_batch,
        params_batch,
        device=device,
        capture_history=diagnostics_capture_history,
        method=method,
        max_iter=max_iter,
        tol=tol,
    )

    batch_median, batch_timings = _measure(
        lambda: _run_batch_solve(
            problem,
            x0_batch,
            params_batch,
            device=device,
            capture_history=capture_history,
            method=method,
            max_iter=max_iter,
            tol=tol,
        ),
        device=device,
        repeats=repeats,
    )
    seq_median, seq_timings = _measure(
        lambda: _run_sequential_solve(
            problem,
            x0_batch,
            params_batch,
            device=device,
            capture_history=capture_history,
            method=method,
            max_iter=max_iter,
            tol=tol,
        ),
        device=device,
        repeats=repeats,
    )

    batch_successes = int(batch_result.num_succeeded)
    seq_successes = int(sum(int(item.success) for item in seq_results))
    batch_error = torch.linalg.vector_norm(batch_result.x - true_params, dim=-1).mean().detach().cpu().item()
    seq_error = torch.linalg.vector_norm(torch.stack([item.x for item in seq_results]) - true_params, dim=-1).mean().detach().cpu().item()
    history_overhead_note = "history_enabled" if capture_history else "history_disabled"
    trust_region_trial_diagnostics = None
    if method == "trust_region":
        trust_region_trial_diagnostics = {
            "batch": _trust_region_trial_attempt_diagnostics(batch_result.results),
            "sequential": _trust_region_trial_attempt_diagnostics(seq_results),
        }

    record = {
        "name": f"shared_structure_sensor_fit_{method}_{history_overhead_note}",
        "device": str(device),
        "method": method,
        "batch_size": batch_size,
        "timepoints": timepoints,
        "capture_history": capture_history,
        "repeats": repeats,
        "batch_time_seconds_median": batch_median,
        "batch_time_seconds_runs": batch_timings,
        "sequential_time_seconds_median": seq_median,
        "sequential_time_seconds_runs": seq_timings,
        "speedup_sequential_over_batch": (seq_median / batch_median) if batch_median > 0.0 else None,
        "batch_successes": batch_successes,
        "sequential_successes": seq_successes,
        "mean_batch_parameter_error": batch_error,
        "mean_sequential_parameter_error": seq_error,
    }
    if trust_region_trial_diagnostics is not None:
        record["trust_region_trial_diagnostics"] = trust_region_trial_diagnostics
    return record


def build_report(
    *,
    methods: Sequence[str],
    workload_set: str = "default",
    progress_callback: Callable[[str], None] | None = None,
) -> dict[str, Any]:
    max_iter = 30
    tol = 1e-6
    repeats = 3
    workload_specs = workload_specs_for_set(workload_set)
    devices = [torch.device("cpu")]
    if torch.cuda.is_available():
        devices.append(torch.device("cuda"))

    benchmarks: list[dict[str, Any]] = []
    total_cases = len(devices) * len(methods) * len(workload_specs) * 2
    completed_cases = 0
    for device in devices:
        for method in methods:
            for workload in workload_specs:
                for capture_history in (False, True):
                    completed_cases += 1
                    if progress_callback is not None:
                        progress_callback(
                            f"[{completed_cases}/{total_cases}] running {method} {workload.label} on {device} history={'on' if capture_history else 'off'}"
                        )
                    record = _benchmark_case(
                        device=device,
                        batch_size=workload.batch_size,
                        timepoints=workload.timepoints,
                        repeats=repeats,
                        method=method,
                        max_iter=max_iter,
                        tol=tol,
                        capture_history=capture_history,
                    )
                    record["workload"] = workload.label
                    benchmarks.append(record)
                    if progress_callback is not None:
                        progress_callback(_benchmark_summary_line(record))

    return {
        "project": "torch-nonlinear",
        "version": "0.1.0a0",
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "requested_methods": list(methods),
        "requested_workload_set": workload_set,
        "benchmarks": benchmarks,
        "notes": [
            "Shared-structure sensor-fitting benchmarks compare the unified batched solver path against an explicit sequential loop.",
            "The harness covers both Levenberg-Marquardt and trust-region methods on the same workload matrix for apples-to-apples batching comparisons.",
            "Trust-region rows include untimed trial-attempt diagnostics derived from recorded solver history so retry cost can be interpreted without contaminating the timed measurements.",
            "History capture is benchmarked in both enabled and disabled modes so logging overhead remains visible.",
            "GPU speedup is workload-dependent; use the recorded speedup field and raw timing runs rather than assuming unconditional wins.",
        ],
    }


def write_report(output_path: Path, report: dict[str, Any]) -> Path:
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    return output_path


def parse_args(argv: Sequence[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Benchmark shared-structure least-squares workloads and write a JSON report.")
    parser.add_argument(
        "--methods",
        nargs="+",
        choices=_SUPPORTED_METHODS,
        default=_SUPPORTED_METHODS,
        help="Subset of solver methods to benchmark. Defaults to all supported methods.",
    )
    parser.add_argument(
        "--workload-set",
        choices=supported_workload_sets(),
        default="default",
        help="Named workload matrix to benchmark. Defaults to the shared small/medium/large suite.",
    )
    parser.add_argument(
        "--output",
        default=f"benchmarks/results/{datetime.now(timezone.utc).strftime('%Y-%m-%dT%H%M%S')}_benchmark.json",
        help="Path to the JSON output file.",
    )
    parser.add_argument(
        "--force",
        action="store_true",
        help="Run even if the git worktree is dirty.",
    )
    return parser.parse_args(argv)


def main() -> int:
    args = parse_args()
    repo_root = Path(__file__).resolve().parents[1]
    try:
        git_metadata = collect_git_metadata(repo_root=repo_root)
        if not args.force:
            ensure_clean_git_worktree(git_metadata)
    except (OSError, subprocess.SubprocessError, RuntimeError) as exc:
        print(str(exc), file=sys.stderr)
        return 1

    output_path = Path(args.output)
    _print_progress(
        f"starting benchmark run for methods {', '.join(args.methods)} using workload set {args.workload_set}"
    )
    report = build_report(
        methods=tuple(args.methods),
        workload_set=args.workload_set,
        progress_callback=_print_progress,
    )
    report.update(git_metadata)
    write_report(output_path, report)
    _print_progress(f"wrote benchmark report to {output_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
