"""Compare constrained benchmark and profile results across two git revisions."""

from __future__ import annotations

import argparse
import json
import subprocess
import sys
from collections.abc import Sequence
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, cast

import torch

from constrained_benchmark_common import resolve_constrained_scenario_name, supported_constrained_methods


def _tol_tag(tol: float) -> str:
    return f"{tol:.0e}" if tol != 0.0 else "0"


def _profile_output_stem(
    *,
    method: str,
    scenario: str,
    device: str,
    hessian_model: str,
    max_iter: int,
    tol: float,
) -> str:
    if method == "sqp":
        return f"sqp_{scenario}_{device}_{hessian_model}_iter{max_iter}_tol{_tol_tag(tol)}"
    return f"{method}_{scenario}_{device}_iter{max_iter}_tol{_tol_tag(tol)}"


def _parse_revision_output(stdout: str) -> dict[str, Any]:
    return json.loads(stdout)


def _print_progress(message: str) -> None:
    print(f"[compare] {message}", flush=True)


def _run_command(command: Sequence[str], *, cwd: Path) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        command,
        cwd=cwd,
        check=True,
        capture_output=True,
        text=True,
    )


def _run_git_command(args: Sequence[str], *, repo_root: Path) -> str:
    completed = _run_command(["git", *args], cwd=repo_root)
    return completed.stdout.strip()


def _verify_revision(*, repo_root: Path, revision: str) -> tuple[str, str]:
    full_revision = _run_git_command(("rev-parse", "--verify", revision), repo_root=repo_root)
    short_revision = _run_git_command(("rev-parse", "--short", full_revision), repo_root=repo_root)
    return full_revision, short_revision


def _worktree_path_for_revision(*, repo_root: Path, short_revision: str) -> Path:
    return repo_root.parent / f"{repo_root.name}-{short_revision}"


def _ensure_worktree(*, repo_root: Path, revision: str, short_revision: str) -> Path:
    worktree_path = _worktree_path_for_revision(repo_root=repo_root, short_revision=short_revision)
    if worktree_path.exists():
        existing_revision = _run_git_command(("rev-parse", "HEAD"), repo_root=worktree_path)
        if existing_revision != revision:
            raise RuntimeError(
                f"Existing worktree at {worktree_path} points to {existing_revision}, expected {revision}."
            )
        return worktree_path

    _run_command(
        ["git", "worktree", "add", "--detach", str(worktree_path), revision],
        cwd=repo_root,
    )
    return worktree_path


def _supported_scenarios_for_worktree(*, worktree_root: Path) -> tuple[str, ...]:
    command = [
        sys.executable,
        "-c",
        (
            "import json, sys; from pathlib import Path; "
            "root = Path.cwd(); "
            "sys.path.insert(0, str(root / 'benchmarks')); "
            "sys.path.insert(0, str(root / 'src')); "
            "import constrained_benchmark_common as common; "
            "print(json.dumps({'supported_scenarios': common.supported_scenarios()}))"
        ),
    ]
    completed = _run_command(command, cwd=worktree_root)
    payload = _parse_revision_output(completed.stdout)
    return tuple(payload["supported_scenarios"])


def _validate_scenarios(*, worktree_root: Path, scenarios: Sequence[str]) -> None:
    supported = set(_supported_scenarios_for_worktree(worktree_root=worktree_root))
    missing = [scenario for scenario in scenarios if scenario not in supported]
    if missing:
        joined = ", ".join(missing)
        raise RuntimeError(f"Worktree {worktree_root} does not support requested scenarios: {joined}")


def _benchmark_artifact_path(*, output_dir: Path, label: str) -> Path:
    return output_dir / "raw" / f"{label}_benchmark.json"


def _profile_artifact_dir(*, output_dir: Path, label: str, scenario: str, device: str) -> Path:
    return output_dir / "raw" / f"{label}_{scenario}_{device}"


def _extract_summary_path_from_stdout(stdout: str) -> Path | None:
    prefix = "Wrote profiler summary to "
    for line in reversed(stdout.splitlines()):
        if line.startswith(prefix):
            return Path(line[len(prefix):].strip())
    return None


def _discover_profile_summary_path(*, output_dir: Path, stdout: str) -> Path:
    summary_path = _extract_summary_path_from_stdout(stdout)
    if summary_path is not None:
        return summary_path

    summary_candidates = sorted(output_dir.glob("*_summary.json"))
    if len(summary_candidates) == 1:
        return summary_candidates[0]

    if summary_candidates:
        return max(summary_candidates, key=lambda path: path.stat().st_mtime_ns)

    raise RuntimeError(f"Could not determine profiler summary path under {output_dir}.")


def _run_benchmark_suite(
    *,
    worktree_root: Path,
    output_path: Path,
    method: str,
    hessian_model: str,
    scenarios: Sequence[str],
    repeats: int,
    max_iter: int,
    tol: float,
    capture_history: bool,
) -> Path:
    output_path.parent.mkdir(parents=True, exist_ok=True)
    _print_progress(
        "running benchmark suite in "
        f"{worktree_root.name} for scenarios {', '.join(scenarios)} on cpu,cuda"
    )
    command = [
        sys.executable,
        "benchmarks/run_constrained_benchmarks.py",
        "--method",
        method,
        "--hessian-model",
        hessian_model,
        "--scenarios",
        *scenarios,
        "--devices",
        "cpu",
        "cuda",
        "--repeats",
        str(repeats),
        "--max-iter",
        str(max_iter),
        "--tol",
        str(tol),
        "--force",
        "--output",
        str(output_path),
    ]
    if capture_history:
        command.append("--capture-history")
    _run_command(command, cwd=worktree_root)
    return output_path


def _run_profile_suite(
    *,
    worktree_root: Path,
    output_dir: Path,
    method: str,
    hessian_model: str,
    scenarios: Sequence[str],
    max_iter: int,
    tol: float,
    capture_history: bool,
    profiler_overhead: str,
    warmup: int,
    active: int,
    verbose: bool,
) -> dict[tuple[str, str], Path]:
    results: dict[tuple[str, str], Path] = {}
    for scenario in scenarios:
        for device in ("cpu", "cuda"):
            _print_progress(
                f"profiling {scenario} on {device} in {worktree_root.name}"
            )
            scenario_output_dir = _profile_artifact_dir(
                output_dir=output_dir,
                label=worktree_root.name,
                scenario=scenario,
                device=device,
            )
            scenario_output_dir.mkdir(parents=True, exist_ok=True)
            command = [
                sys.executable,
                "benchmarks/profile_constrained_benchmarks.py",
                "--method",
                method,
                "--scenario",
                scenario,
                "--device",
                device,
                "--hessian-model",
                hessian_model,
                "--capture-history",
                "true" if capture_history else "false",
                "--warmup",
                str(warmup),
                "--active",
                str(active),
                "--max-iter",
                str(max_iter),
                "--tol",
                str(tol),
                "--profiler-overhead",
                profiler_overhead,
                "--force",
                "--output-dir",
                str(scenario_output_dir),
            ]
            if verbose:
                command.append("--verbose")
            completed = _run_command(command, cwd=worktree_root)
            results[(scenario, device)] = _discover_profile_summary_path(
                output_dir=scenario_output_dir,
                stdout=completed.stdout,
            )
    return results


def _load_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def _benchmark_key(row: dict[str, Any]) -> tuple[str, str, str, str | None]:
    return (
        str(row["scenario"]),
        str(row["device"]),
        str(row["method"]),
        cast(str | None, row.get("constrained_hessian_model")),
    )


def _profile_time_field(*, device: str) -> str:
    return "self_device_ms" if device == "cuda" else "self_cpu_ms"


def _delta_percent(*, baseline: float, candidate: float) -> float | None:
    if baseline == 0.0:
        return None
    return ((candidate - baseline) / baseline) * 100.0


def _status_signature(row: dict[str, Any]) -> tuple[Any, ...]:
    return (
        row.get("success"),
        row.get("status"),
        row.get("termination"),
        row.get("num_outer_iterations"),
        row.get("accepted_iterations"),
        row.get("rejected_iterations"),
        row.get("total_trial_attempts"),
    )


def _zero_profile_row(*, category: str, time_field: str) -> dict[str, Any]:
    return {
        "category": category,
        time_field: 0.0,
        "calls": 0,
    }


def _build_benchmark_comparison(
    *,
    base_report: dict[str, Any],
    compare_report: dict[str, Any],
) -> list[dict[str, Any]]:
    base_rows = {_benchmark_key(row): row for row in base_report["benchmarks"]}
    compare_rows = {_benchmark_key(row): row for row in compare_report["benchmarks"]}
    if set(base_rows) != set(compare_rows):
        missing_in_compare = sorted(set(base_rows) - set(compare_rows))
        missing_in_base = sorted(set(compare_rows) - set(base_rows))
        raise RuntimeError(
            "Benchmark reports are not directly comparable. "
            f"Missing in compare: {missing_in_compare}. Missing in base: {missing_in_base}."
        )

    rows: list[dict[str, Any]] = []
    for key in sorted(base_rows):
        base_row = base_rows[key]
        compare_row = compare_rows[key]
        base_time = float(base_row["time_seconds_median"])
        compare_time = float(compare_row["time_seconds_median"])
        rows.append(
            {
                "scenario": key[0],
                "device": key[1],
                "method": key[2],
                "constrained_hessian_model": key[3],
                "base_time_seconds_median": base_time,
                "compare_time_seconds_median": compare_time,
                "delta_percent": _delta_percent(baseline=base_time, candidate=compare_time),
                "base_speedup": base_row.get("cpu_vs_cuda_speedup"),
                "compare_speedup": compare_row.get("cpu_vs_cuda_speedup"),
                "status_match": _status_signature(base_row) == _status_signature(compare_row),
                "base_status": base_row.get("status"),
                "compare_status": compare_row.get("status"),
                "base_termination": base_row.get("termination"),
                "compare_termination": compare_row.get("termination"),
                "base_num_outer_iterations": base_row.get("num_outer_iterations"),
                "compare_num_outer_iterations": compare_row.get("num_outer_iterations"),
            }
        )
    return rows


def _select_curated_top_ops(
    *,
    base_summary: dict[str, Any],
    compare_summary: dict[str, Any],
    limit: int = 10,
) -> list[str]:
    device = str(base_summary["device"])
    time_field = _profile_time_field(device=device)
    base_map = {row["name"]: row for row in base_summary["top_ops"]}
    compare_map = {row["name"]: row for row in compare_summary["top_ops"]}
    candidates = set(list(base_map)[:limit] + list(compare_map)[:limit])
    ranked = sorted(
        candidates,
        key=lambda name: max(
            float(base_map.get(name, {}).get(time_field, 0.0)),
            float(compare_map.get(name, {}).get(time_field, 0.0)),
        ),
        reverse=True,
    )
    return ranked[:limit]


def _build_profile_comparison(
    *,
    scenario: str,
    device: str,
    base_summary: dict[str, Any],
    compare_summary: dict[str, Any],
) -> dict[str, Any]:
    if _status_signature(base_summary) != _status_signature(compare_summary):
        status_match = False
    else:
        status_match = True

    time_field = _profile_time_field(device=device)
    base_categories = {row["category"]: row for row in base_summary["category_breakdown"]}
    compare_categories = {row["category"]: row for row in compare_summary["category_breakdown"]}

    category_rows = []
    for category in sorted(set(base_categories) | set(compare_categories)):
        base_present = category in base_categories
        compare_present = category in compare_categories
        base_row = base_categories.get(category, _zero_profile_row(category=category, time_field=time_field))
        compare_row = compare_categories.get(category, _zero_profile_row(category=category, time_field=time_field))
        baseline = float(base_row[time_field])
        candidate = float(compare_row[time_field])
        category_rows.append(
            {
                "category": category,
                "base_time_ms": baseline,
                "compare_time_ms": candidate,
                "delta_percent": _delta_percent(baseline=baseline, candidate=candidate),
                "base_calls": base_row["calls"],
                "compare_calls": compare_row["calls"],
                "base_present": base_present,
                "compare_present": compare_present,
            }
        )

    base_ops = {row["name"]: row for row in base_summary["top_ops"]}
    compare_ops = {row["name"]: row for row in compare_summary["top_ops"]}
    op_rows = []
    for op_name in _select_curated_top_ops(base_summary=base_summary, compare_summary=compare_summary):
        base_row = base_ops.get(op_name, {time_field: 0.0, "calls": 0, "cpu_total_ms": 0.0, "device_total_ms": 0.0})
        compare_row = compare_ops.get(op_name, {time_field: 0.0, "calls": 0, "cpu_total_ms": 0.0, "device_total_ms": 0.0})
        baseline = float(base_row.get(time_field, 0.0))
        candidate = float(compare_row.get(time_field, 0.0))
        op_rows.append(
            {
                "name": op_name,
                "base_time_ms": baseline,
                "compare_time_ms": candidate,
                "delta_percent": _delta_percent(baseline=baseline, candidate=candidate),
                "base_calls": int(base_row.get("calls", 0)),
                "compare_calls": int(compare_row.get("calls", 0)),
            }
        )

    standard_metrics = {
        "base": {
            "objective_value": base_summary.get("objective_value"),
            "final_constraint_violation": base_summary.get("final_constraint_violation"),
            "final_kkt_residual": base_summary.get("final_kkt_residual"),
            "num_outer_iterations": base_summary.get("num_outer_iterations"),
            "accepted_iterations": base_summary.get("accepted_iterations"),
            "rejected_iterations": base_summary.get("rejected_iterations"),
            "total_trial_attempts": base_summary.get("total_trial_attempts"),
        },
        "compare": {
            "objective_value": compare_summary.get("objective_value"),
            "final_constraint_violation": compare_summary.get("final_constraint_violation"),
            "final_kkt_residual": compare_summary.get("final_kkt_residual"),
            "num_outer_iterations": compare_summary.get("num_outer_iterations"),
            "accepted_iterations": compare_summary.get("accepted_iterations"),
            "rejected_iterations": compare_summary.get("rejected_iterations"),
            "total_trial_attempts": compare_summary.get("total_trial_attempts"),
        },
    }

    return {
        "scenario": scenario,
        "device": device,
        "status_match": status_match,
        "base_status": base_summary.get("status"),
        "compare_status": compare_summary.get("status"),
        "base_termination": base_summary.get("termination"),
        "compare_termination": compare_summary.get("termination"),
        "standard_metrics": standard_metrics,
        "category_rows": category_rows,
        "top_op_rows": op_rows,
    }


def _format_float(value: float | None, *, digits: int = 4) -> str:
    if value is None:
        return "n/a"
    return f"{value:.{digits}f}"


def _format_percent(value: float | None) -> str:
    if value is None:
        return "n/a"
    return f"{value:+.2f}%"


def _render_markdown_table(headers: Sequence[str], rows: Sequence[Sequence[str]]) -> str:
    header_row = "| " + " | ".join(headers) + " |"
    separator = "| " + " | ".join("---" for _ in headers) + " |"
    body = ["| " + " | ".join(row) + " |" for row in rows]
    return "\n".join([header_row, separator, *body])


def render_benchmark_table(rows: Sequence[dict[str, Any]]) -> str:
    headers = ["scenario", "device", "base_s", "compare_s", "delta", "status_match", "base_speedup", "compare_speedup"]
    body = [
        [
            str(row["scenario"]),
            str(row["device"]),
            _format_float(row["base_time_seconds_median"]),
            _format_float(row["compare_time_seconds_median"]),
            _format_percent(row["delta_percent"]),
            "yes" if row["status_match"] else "no",
            _format_float(row["base_speedup"]),
            _format_float(row["compare_speedup"]),
        ]
        for row in rows
    ]
    return _render_markdown_table(headers, body)


def render_profile_tables(rows: Sequence[dict[str, Any]]) -> str:
    sections: list[str] = []
    for row in rows:
        sections.append(f"### {row['scenario']} ({row['device']})")
        sections.append(
            _render_markdown_table(
                ["metric", "base", "compare"],
                [
                    ["status", str(row["base_status"]), str(row["compare_status"])],
                    ["termination", str(row["base_termination"]), str(row["compare_termination"])],
                    ["outer_iterations", str(row["standard_metrics"]["base"]["num_outer_iterations"]), str(row["standard_metrics"]["compare"]["num_outer_iterations"])],
                    ["accepted_iterations", str(row["standard_metrics"]["base"]["accepted_iterations"]), str(row["standard_metrics"]["compare"]["accepted_iterations"])],
                    ["rejected_iterations", str(row["standard_metrics"]["base"]["rejected_iterations"]), str(row["standard_metrics"]["compare"]["rejected_iterations"])],
                    ["total_trial_attempts", str(row["standard_metrics"]["base"]["total_trial_attempts"]), str(row["standard_metrics"]["compare"]["total_trial_attempts"])],
                    ["final_constraint_violation", str(row["standard_metrics"]["base"]["final_constraint_violation"]), str(row["standard_metrics"]["compare"]["final_constraint_violation"])],
                    ["final_kkt_residual", str(row["standard_metrics"]["base"]["final_kkt_residual"]), str(row["standard_metrics"]["compare"]["final_kkt_residual"])],
                ],
            )
        )
        sections.append(
            _render_markdown_table(
                ["category", "base_ms", "compare_ms", "delta", "presence"],
                [
                    [
                        str(category_row["category"]),
                        _format_float(category_row["base_time_ms"]),
                        _format_float(category_row["compare_time_ms"]),
                        _format_percent(category_row["delta_percent"]),
                        (
                            "both"
                            if category_row["base_present"] and category_row["compare_present"]
                            else "base-only"
                            if category_row["base_present"]
                            else "compare-only"
                        ),
                    ]
                    for category_row in row["category_rows"]
                ],
            )
        )
        sections.append(
            _render_markdown_table(
                ["op", "base_ms", "compare_ms", "delta", "base_calls", "compare_calls"],
                [
                    [
                        str(op_row["name"]),
                        _format_float(op_row["base_time_ms"]),
                        _format_float(op_row["compare_time_ms"]),
                        _format_percent(op_row["delta_percent"]),
                        str(op_row["base_calls"]),
                        str(op_row["compare_calls"]),
                    ]
                    for op_row in row["top_op_rows"]
                ],
            )
        )
    return "\n\n".join(sections)


def parse_args(argv: Sequence[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Compare constrained benchmark and profile results across two revisions.")
    parser.add_argument("--base-rev", required=True)
    parser.add_argument("--compare-rev", required=True)
    parser.add_argument("--benchmark-scenarios", nargs="+", required=True, type=resolve_constrained_scenario_name)
    parser.add_argument("--profile-scenarios", nargs="+", required=True, type=resolve_constrained_scenario_name)
    parser.add_argument("--method", choices=supported_constrained_methods(), default="sqp")
    parser.add_argument("--hessian-model", choices=("bfgs", "exact"), default="bfgs")
    parser.add_argument("--benchmark-repeats", type=int, default=5)
    parser.add_argument("--benchmark-max-iter", type=int, default=40)
    parser.add_argument("--profile-max-iter", type=int, default=40)
    parser.add_argument("--tol", type=float, default=1e-6)
    parser.add_argument("--capture-history", action="store_true")
    parser.add_argument("--profiler-overhead", choices=("standard", "reduced"), default="standard")
    parser.add_argument("--warmup", type=int, default=1)
    parser.add_argument("--active", type=int, default=1)
    parser.add_argument("--output-dir", default=None)
    parser.add_argument("--verbose", action="store_true")
    return parser.parse_args(argv)


def main(argv: Sequence[str] | None = None) -> int:
    args = parse_args(argv)
    if not torch.cuda.is_available():
        print("CUDA is required for revision comparison runs.", file=sys.stderr)
        return 1

    repo_root = Path(__file__).resolve().parents[1]
    generated_at = datetime.now(timezone.utc)
    output_dir = Path(args.output_dir) if args.output_dir is not None else repo_root / "benchmarks" / "results" / f"compare_{generated_at.strftime('%Y-%m-%dT%H%M%S')}"
    output_dir.mkdir(parents=True, exist_ok=True)
    _print_progress(f"writing outputs under {output_dir}")

    _print_progress("verifying requested revisions")
    base_revision, base_short = _verify_revision(repo_root=repo_root, revision=args.base_rev)
    compare_revision, compare_short = _verify_revision(repo_root=repo_root, revision=args.compare_rev)
    _print_progress(f"resolved base revision {base_short} and compare revision {compare_short}")

    _print_progress("preparing detached worktrees")
    base_worktree = _ensure_worktree(repo_root=repo_root, revision=base_revision, short_revision=base_short)
    compare_worktree = _ensure_worktree(repo_root=repo_root, revision=compare_revision, short_revision=compare_short)
    _print_progress(f"using worktrees {base_worktree.name} and {compare_worktree.name}")

    all_scenarios = tuple(dict.fromkeys([*args.benchmark_scenarios, *args.profile_scenarios]))
    _print_progress("validating requested scenarios in both worktrees")
    _validate_scenarios(worktree_root=base_worktree, scenarios=all_scenarios)
    _validate_scenarios(worktree_root=compare_worktree, scenarios=all_scenarios)
    _print_progress("scenario validation complete")

    base_benchmark_path = _run_benchmark_suite(
        worktree_root=base_worktree,
        output_path=_benchmark_artifact_path(output_dir=output_dir, label=f"base_{base_short}"),
        method=args.method,
        hessian_model=args.hessian_model,
        scenarios=args.benchmark_scenarios,
        repeats=args.benchmark_repeats,
        max_iter=args.benchmark_max_iter,
        tol=args.tol,
        capture_history=args.capture_history,
    )
    _print_progress(f"base benchmark artifact ready at {base_benchmark_path}")
    compare_benchmark_path = _run_benchmark_suite(
        worktree_root=compare_worktree,
        output_path=_benchmark_artifact_path(output_dir=output_dir, label=f"compare_{compare_short}"),
        method=args.method,
        hessian_model=args.hessian_model,
        scenarios=args.benchmark_scenarios,
        repeats=args.benchmark_repeats,
        max_iter=args.benchmark_max_iter,
        tol=args.tol,
        capture_history=args.capture_history,
    )
    _print_progress(f"compare benchmark artifact ready at {compare_benchmark_path}")

    base_profile_paths = _run_profile_suite(
        worktree_root=base_worktree,
        output_dir=output_dir,
        method=args.method,
        hessian_model=args.hessian_model,
        scenarios=args.profile_scenarios,
        max_iter=args.profile_max_iter,
        tol=args.tol,
        capture_history=args.capture_history,
        profiler_overhead=args.profiler_overhead,
        warmup=args.warmup,
        active=args.active,
        verbose=args.verbose,
    )
    _print_progress("base profile suite complete")
    compare_profile_paths = _run_profile_suite(
        worktree_root=compare_worktree,
        output_dir=output_dir,
        method=args.method,
        hessian_model=args.hessian_model,
        scenarios=args.profile_scenarios,
        max_iter=args.profile_max_iter,
        tol=args.tol,
        capture_history=args.capture_history,
        profiler_overhead=args.profiler_overhead,
        warmup=args.warmup,
        active=args.active,
        verbose=args.verbose,
    )
    _print_progress("compare profile suite complete")

    _print_progress("building comparison tables")
    benchmark_rows = _build_benchmark_comparison(
        base_report=_load_json(base_benchmark_path),
        compare_report=_load_json(compare_benchmark_path),
    )
    profile_rows = [
        _build_profile_comparison(
            scenario=scenario,
            device=device,
            base_summary=_load_json(base_profile_paths[(scenario, device)]),
            compare_summary=_load_json(compare_profile_paths[(scenario, device)]),
        )
        for scenario in args.profile_scenarios
        for device in ("cpu", "cuda")
    ]

    _print_progress("writing markdown and json comparison artifacts")
    markdown_parts = [
        f"# Constrained Revision Comparison\n\nBase: `{base_revision}`\n\nCompare: `{compare_revision}`",
        "## Benchmark Comparison\n\n" + render_benchmark_table(benchmark_rows),
        "## Profile Comparison\n\n" + render_profile_tables(profile_rows),
    ]
    markdown = "\n\n".join(markdown_parts) + "\n"
    markdown_path = output_dir / "comparison.md"
    markdown_path.write_text(markdown, encoding="utf-8")

    comparison_payload = {
        "generated_at": generated_at.isoformat(),
        "base_revision": base_revision,
        "compare_revision": compare_revision,
        "method": args.method,
        "constrained_hessian_model": args.hessian_model if args.method == "sqp" else None,
        "benchmark_scenarios": list(args.benchmark_scenarios),
        "profile_scenarios": list(args.profile_scenarios),
        "devices": ["cpu", "cuda"],
        "benchmark_parameters": {
            "repeats": args.benchmark_repeats,
            "max_iter": args.benchmark_max_iter,
            "tol": args.tol,
            "capture_history": args.capture_history,
        },
        "profile_parameters": {
            "max_iter": args.profile_max_iter,
            "tol": args.tol,
            "capture_history": args.capture_history,
            "profiler_overhead": args.profiler_overhead,
            "warmup": args.warmup,
            "active": args.active,
        },
        "environment": {
            "python_version": sys.version,
            "torch_version": torch.__version__,
            "cuda_available": torch.cuda.is_available(),
            "cuda_device_name": torch.cuda.get_device_name(0) if torch.cuda.is_available() else None,
        },
        "artifacts": {
            "base_benchmark": str(base_benchmark_path),
            "compare_benchmark": str(compare_benchmark_path),
            "base_profiles": {f"{scenario}:{device}": str(path) for (scenario, device), path in base_profile_paths.items()},
            "compare_profiles": {f"{scenario}:{device}": str(path) for (scenario, device), path in compare_profile_paths.items()},
            "markdown": str(markdown_path),
        },
        "benchmark_comparison": benchmark_rows,
        "profile_comparison": profile_rows,
    }
    comparison_path = output_dir / "comparison.json"
    comparison_path.write_text(json.dumps(comparison_payload, indent=2) + "\n", encoding="utf-8")

    _print_progress("comparison complete")
    print(markdown)
    print(f"Wrote comparison artifact to {comparison_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())