from __future__ import annotations

import importlib.util
import sys
from pathlib import Path
from types import SimpleNamespace


MODULE_PATH = Path(__file__).resolve().parents[2] / "benchmarks" / "compare_constrained_revisions.py"
SPEC = importlib.util.spec_from_file_location("compare_constrained_revisions", MODULE_PATH)
assert SPEC is not None
assert SPEC.loader is not None
compare_constrained_revisions = importlib.util.module_from_spec(SPEC)
sys.path.insert(0, str(MODULE_PATH.parent))
sys.modules.setdefault("compare_constrained_revisions", compare_constrained_revisions)
SPEC.loader.exec_module(compare_constrained_revisions)


def test_parse_args_requires_explicit_revisions_and_scenarios() -> None:
    args = compare_constrained_revisions.parse_args(
        [
            "--base-rev",
            "abc123",
            "--compare-rev",
            "def456",
            "--benchmark-scenarios",
            "nonlinear_mixed_constraints_medium",
            "nonlinear_mixed_constraints_1024",
            "--profile-scenarios",
            "nonlinear_mixed_constraints_medium",
            "--method",
            "sqp",
            "--hessian-model",
            "exact",
            "--benchmark-repeats",
            "7",
            "--profile-max-iter",
            "60",
            "--capture-history",
        ]
    )

    assert args.base_rev == "abc123"
    assert args.compare_rev == "def456"
    assert args.benchmark_scenarios == [
        "nonlinear_mixed_constraints_medium",
        "nonlinear_mixed_constraints_1024",
    ]
    assert args.profile_scenarios == ["nonlinear_mixed_constraints_medium"]
    assert args.method == "sqp"
    assert args.hessian_model == "exact"
    assert args.benchmark_repeats == 7
    assert args.profile_max_iter == 60
    assert args.capture_history is True


def test_build_benchmark_comparison_reports_delta_and_status_match() -> None:
    build_benchmark_comparison = getattr(compare_constrained_revisions, "_build_benchmark_comparison")
    base_report = {
        "benchmarks": [
            {
                "scenario": "nonlinear_mixed_constraints_medium",
                "device": "cpu",
                "method": "sqp",
                "constrained_hessian_model": "exact",
                "time_seconds_median": 1.0,
                "cpu_vs_cuda_speedup": 2.0,
                "success": True,
                "status": "converged",
                "termination": "step_tol",
                "num_outer_iterations": 4,
                "accepted_iterations": 4,
                "rejected_iterations": 0,
                "total_trial_attempts": 4,
            }
        ]
    }
    compare_report = {
        "benchmarks": [
            {
                "scenario": "nonlinear_mixed_constraints_medium",
                "device": "cpu",
                "method": "sqp",
                "constrained_hessian_model": "exact",
                "time_seconds_median": 1.25,
                "cpu_vs_cuda_speedup": 1.8,
                "success": True,
                "status": "converged",
                "termination": "step_tol",
                "num_outer_iterations": 4,
                "accepted_iterations": 4,
                "rejected_iterations": 0,
                "total_trial_attempts": 4,
            }
        ]
    }

    rows = build_benchmark_comparison(
        base_report=base_report,
        compare_report=compare_report,
    )

    assert len(rows) == 1
    assert rows[0]["scenario"] == "nonlinear_mixed_constraints_medium"
    assert rows[0]["delta_percent"] == 25.0
    assert rows[0]["status_match"] is True
    assert rows[0]["base_speedup"] == 2.0
    assert rows[0]["compare_speedup"] == 1.8


def test_select_curated_top_ops_uses_union_of_significant_ops() -> None:
    select_curated_top_ops = getattr(compare_constrained_revisions, "_select_curated_top_ops")
    base_summary = {
        "device": "cuda",
        "top_ops": [
            {"name": "aten::mm", "self_device_ms": 50.0},
            {"name": "aten::add", "self_device_ms": 20.0},
        ],
    }
    compare_summary = {
        "device": "cuda",
        "top_ops": [
            {"name": "aten::mul", "self_device_ms": 60.0},
            {"name": "aten::add", "self_device_ms": 10.0},
        ],
    }

    selected = select_curated_top_ops(
        base_summary=base_summary,
        compare_summary=compare_summary,
        limit=3,
    )

    assert selected == ["aten::mul", "aten::mm", "aten::add"]


def test_build_profile_comparison_tracks_categories_and_curated_ops() -> None:
    build_profile_comparison = getattr(compare_constrained_revisions, "_build_profile_comparison")
    base_summary = {
        "device": "cuda",
        "status": "converged",
        "termination": "step_tol",
        "success": True,
        "num_outer_iterations": 4,
        "accepted_iterations": 4,
        "rejected_iterations": 0,
        "total_trial_attempts": 4,
        "objective_value": -1.0,
        "final_constraint_violation": 0.0,
        "final_kkt_residual": 1e-4,
        "category_breakdown": [
            {"category": "dense_math", "self_device_ms": 10.0, "calls": 5},
            {"category": "sync_scalar", "self_device_ms": 2.0, "calls": 3},
        ],
        "top_ops": [
            {"name": "aten::mm", "self_device_ms": 8.0, "calls": 2},
            {"name": "aten::nonzero", "self_device_ms": 3.0, "calls": 4},
        ],
    }
    compare_summary = {
        "device": "cuda",
        "status": "converged",
        "termination": "step_tol",
        "success": True,
        "num_outer_iterations": 4,
        "accepted_iterations": 4,
        "rejected_iterations": 0,
        "total_trial_attempts": 4,
        "objective_value": -1.0,
        "final_constraint_violation": 0.0,
        "final_kkt_residual": 1e-4,
        "category_breakdown": [
            {"category": "dense_math", "self_device_ms": 12.0, "calls": 5},
            {"category": "sync_scalar", "self_device_ms": 1.0, "calls": 2},
        ],
        "top_ops": [
            {"name": "aten::mm", "self_device_ms": 6.0, "calls": 2},
            {"name": "aten::_to_copy", "self_device_ms": 4.0, "calls": 5},
        ],
    }

    comparison = build_profile_comparison(
        scenario="nonlinear_mixed_constraints_medium",
        device="cuda",
        base_summary=base_summary,
        compare_summary=compare_summary,
    )

    assert comparison["status_match"] is True
    assert comparison["category_rows"][0]["category"] == "dense_math"
    assert comparison["category_rows"][0]["delta_percent"] == 20.0
    assert [row["name"] for row in comparison["top_op_rows"]] == ["aten::mm", "aten::_to_copy", "aten::nonzero"]


def test_build_profile_comparison_uses_union_of_categories_with_presence_flags() -> None:
    build_profile_comparison = getattr(compare_constrained_revisions, "_build_profile_comparison")
    base_summary = {
        "device": "cpu",
        "status": "converged",
        "termination": "step_tol",
        "success": True,
        "num_outer_iterations": 2,
        "accepted_iterations": 2,
        "rejected_iterations": 0,
        "total_trial_attempts": 2,
        "category_breakdown": [
            {"category": "dense_math", "self_cpu_ms": 5.0, "calls": 2},
        ],
        "top_ops": [],
    }
    compare_summary = {
        "device": "cpu",
        "status": "converged",
        "termination": "step_tol",
        "success": True,
        "num_outer_iterations": 2,
        "accepted_iterations": 2,
        "rejected_iterations": 0,
        "total_trial_attempts": 2,
        "category_breakdown": [
            {"category": "line_search", "self_cpu_ms": 3.0, "calls": 1},
        ],
        "top_ops": [],
    }

    comparison = build_profile_comparison(
        scenario="nonlinear_mixed_constraints_medium",
        device="cpu",
        base_summary=base_summary,
        compare_summary=compare_summary,
    )

    assert [row["category"] for row in comparison["category_rows"]] == ["dense_math", "line_search"]
    assert comparison["category_rows"][0]["base_present"] is True
    assert comparison["category_rows"][0]["compare_present"] is False
    assert comparison["category_rows"][0]["compare_time_ms"] == 0.0
    assert comparison["category_rows"][1]["base_present"] is False
    assert comparison["category_rows"][1]["compare_present"] is True
    assert comparison["category_rows"][1]["base_time_ms"] == 0.0


def test_extract_summary_path_from_stdout_reads_reported_path() -> None:
    extract_summary_path_from_stdout = getattr(compare_constrained_revisions, "_extract_summary_path_from_stdout")

    summary_path = extract_summary_path_from_stdout(
        "profiling...\nWrote profiler summary to C:/tmp/profile_summary.json\n"
    )

    assert summary_path == Path("C:/tmp/profile_summary.json")


def test_run_profile_suite_discovers_reported_summary_path(monkeypatch) -> None:
    run_profile_suite = getattr(compare_constrained_revisions, "_run_profile_suite")
    discovered_path = Path("C:/tmp/actual_revision_specific_summary.json")
    calls: list[list[str]] = []

    def fake_run_command(command: list[str], *, cwd: Path) -> SimpleNamespace:
        calls.append(command)
        assert cwd == Path("C:/repo/worktree")
        return SimpleNamespace(
            stdout=f"noise\nWrote profiler summary to {discovered_path}\n",
            stderr="",
        )

    monkeypatch.setattr(compare_constrained_revisions, "_run_command", fake_run_command)

    results = run_profile_suite(
        worktree_root=Path("C:/repo/worktree"),
        output_dir=Path("C:/repo/output"),
        method="sqp",
        hessian_model="exact",
        scenarios=["nonlinear_mixed_constraints_medium"],
        max_iter=40,
        tol=1e-6,
        capture_history=False,
        profiler_overhead="standard",
        warmup=1,
        active=1,
        verbose=False,
    )

    assert len(calls) == 2
    assert results[("nonlinear_mixed_constraints_medium", "cpu")] == discovered_path
    assert results[("nonlinear_mixed_constraints_medium", "cuda")] == discovered_path


def test_render_benchmark_table_outputs_markdown_table() -> None:
    markdown = compare_constrained_revisions.render_benchmark_table(
        [
            {
                "scenario": "nonlinear_mixed_constraints_medium",
                "device": "cuda",
                "base_time_seconds_median": 0.25,
                "compare_time_seconds_median": 0.3,
                "delta_percent": 20.0,
                "status_match": True,
                "base_speedup": 0.5,
                "compare_speedup": 0.4,
            }
        ]
    )

    assert "| scenario | device | base_s | compare_s | delta | status_match | base_speedup | compare_speedup |" in markdown
    assert "| nonlinear_mixed_constraints_medium | cuda | 0.2500 | 0.3000 | +20.00% | yes | 0.5000 | 0.4000 |" in markdown