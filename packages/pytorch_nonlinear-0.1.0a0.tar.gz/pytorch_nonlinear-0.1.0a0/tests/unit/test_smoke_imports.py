from pytorch_nonlinear import (
    Bounds,
    ConstrainedNLPProblem,
    EqualityConstraint,
    NonlinearLeastSquaresProblem,
    SmoothMinimizationProblem,
    __version__,
)


def test_public_symbols_import() -> None:
    assert __version__ == "0.1.0a0"
    assert Bounds is not None
    assert EqualityConstraint is not None
    assert NonlinearLeastSquaresProblem is not None
    assert SmoothMinimizationProblem is not None
    assert ConstrainedNLPProblem is not None
