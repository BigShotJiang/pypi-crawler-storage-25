from __future__ import annotations

import importlib.util
import sys
from pathlib import Path

import pytest


MODULE_PATH = Path(__file__).resolve().parents[2] / "benchmarks" / "run_benchmarks.py"
SPEC = importlib.util.spec_from_file_location("run_benchmarks", MODULE_PATH)
assert SPEC is not None
assert SPEC.loader is not None
run_benchmarks = importlib.util.module_from_spec(SPEC)
sys.modules.setdefault("run_benchmarks", run_benchmarks)
SPEC.loader.exec_module(run_benchmarks)


def test_collect_git_metadata_reports_clean_repo(monkeypatch: pytest.MonkeyPatch) -> None:
    responses = {
        ("rev-parse", "HEAD"): "abc123",
        ("rev-parse", "--abbrev-ref", "HEAD"): "main",
        ("status", "--porcelain"): "",
    }

    def fake_run_git_command(args: tuple[str, ...], *, repo_root: Path) -> str:
        assert repo_root == Path("repo")
        return responses[args]

    monkeypatch.setattr(run_benchmarks, "_run_git_command", fake_run_git_command)

    metadata = run_benchmarks.collect_git_metadata(repo_root=Path("repo"))

    assert metadata == {
        "git_commit": "abc123",
        "git_branch": "main",
        "git_dirty": False,
    }


def test_parse_args_accepts_force_flag(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(sys, "argv", ["run_benchmarks.py", "--force"])

    args = run_benchmarks.parse_args()

    assert args.force is True


def test_parse_args_accepts_workload_set(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(sys, "argv", ["run_benchmarks.py", "--workload-set", "default"])

    args = run_benchmarks.parse_args()

    assert args.workload_set == "default"


def test_ensure_clean_git_worktree_rejects_dirty_commit_choice(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(run_benchmarks.sys.stdin, "isatty", lambda: True)
    monkeypatch.setattr("builtins.input", lambda _: "commit")

    with pytest.raises(RuntimeError, match="Commit your changes and rerun"):
        run_benchmarks.ensure_clean_git_worktree(
            {"git_commit": "abc123", "git_branch": "main", "git_dirty": True}
        )


def test_ensure_clean_git_worktree_rejects_dirty_noninteractive() -> None:
    with pytest.MonkeyPatch.context() as monkeypatch:
        monkeypatch.setattr(run_benchmarks.sys.stdin, "isatty", lambda: False)

        with pytest.raises(RuntimeError, match="Commit or stash them"):
            run_benchmarks.ensure_clean_git_worktree(
                {"git_commit": "abc123", "git_branch": "main", "git_dirty": True}
            )


def test_build_report_emits_progress_messages(monkeypatch: pytest.MonkeyPatch) -> None:
    messages: list[str] = []

    def fake_benchmark_case(
        *,
        device,
        batch_size: int,
        timepoints: int,
        repeats: int,
        method: str,
        max_iter: int,
        tol: float,
        capture_history: bool,
    ) -> dict[str, object]:
        _ = (batch_size, timepoints, repeats, max_iter, tol)
        return {
            "name": f"sensor_{method}",
            "device": str(device),
            "method": method,
            "capture_history": capture_history,
            "batch_time_seconds_median": 1.5,
            "batch_time_seconds_runs": [1.5],
            "sequential_time_seconds_median": 6.0,
            "sequential_time_seconds_runs": [6.0],
            "speedup_sequential_over_batch": 4.0,
            "batch_successes": 8,
            "sequential_successes": 8,
            "mean_batch_parameter_error": 0.1,
            "mean_sequential_parameter_error": 0.1,
        }

    monkeypatch.setattr(run_benchmarks, "_benchmark_case", fake_benchmark_case)
    monkeypatch.setattr(run_benchmarks.torch.cuda, "is_available", lambda: False)

    report = run_benchmarks.build_report(methods=("lm",), progress_callback=messages.append)

    assert len(report["benchmarks"]) == 6
    assert report["requested_workload_set"] == "default"
    assert messages[0] == "[1/6] running lm small on cpu history=off"
    assert messages[1] == "completed lm small on cpu history=off: batch=1.5000s seq=6.0000s seq_over_batch=4.00x successes=8/8"
    assert messages[-2] == "[6/6] running lm large on cpu history=on"
    assert messages[-1] == "completed lm large on cpu history=on: batch=1.5000s seq=6.0000s seq_over_batch=4.00x successes=8/8"