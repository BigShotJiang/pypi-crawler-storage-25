from pytorch_nonlinear.diagnostics import DiagnosisCode, IterationRecord, SolveResult, SolveStatus, TerminationReason, TrialRecord, render_explanation


def test_solve_result_summary_and_serialization() -> None:
    result = SolveResult(
        success=False,
        status=SolveStatus.MAX_ITER_REACHED,
        termination=TerminationReason.MAX_ITER,
        num_iter=10,
        message="stopped at iteration limit",
        diagnosis=(DiagnosisCode.POOR_SCALING, DiagnosisCode.STEP_REJECTED),
        reproducibility={"device": "cpu", "dtype": "float64"},
    )

    summary = result.summary()
    payload = result.to_dict()

    assert "status=max_iter_reached" in summary
    assert "diagnosis=poor_scaling, step_rejected" in summary
    assert payload["num_iter"] == 10
    assert payload["reproducibility"]["dtype"] == "float64"


def test_solve_result_serializes_nested_trials() -> None:
    result = SolveResult(
        history=(
            IterationRecord(
                iteration=1,
                accepted=False,
                reason="rejected step",
                linear_residual_norm=1e-5,
                linear_condition_estimate=42.0,
                trust_region_radius=0.5,
                trust_region_ratio=-0.25,
                trials=(
                    TrialRecord(
                        attempt=1,
                        accepted=False,
                        reason="objective increased",
                        linear_residual_norm=2e-5,
                        linear_condition_estimate=84.0,
                        trust_region_radius=0.5,
                        trust_region_ratio=-0.25,
                    ),
                ),
            ),
        ),
    )

    payload = result.to_dict()

    assert payload["history"][0]["trials"][0]["reason"] == "objective increased"
    assert payload["history"][0]["linear_residual_norm"] == 1e-5
    assert payload["history"][0]["trials"][0]["linear_condition_estimate"] == 84.0
    assert payload["history"][0]["trust_region_radius"] == 0.5
    assert payload["history"][0]["trials"][0]["trust_region_ratio"] == -0.25


def test_render_explanation_includes_history_and_diff_context() -> None:
    result = SolveResult(
        success=False,
        status=SolveStatus.FAILED,
        termination=TerminationReason.NUMERICAL_FAILURE,
        num_iter=3,
        diagnosis=(DiagnosisCode.ILL_CONDITIONED_SYSTEM, DiagnosisCode.UNCERTIFIED_KKT_STEP, DiagnosisCode.DIFF_INVALID),
        history=(
            IterationRecord(
                iteration=3,
                accepted=False,
                reason="ill-conditioned local solve",
                trials=(TrialRecord(attempt=1, accepted=False, reason="step rejected"),),
            ),
        ),
        diff_mode_used="implicit",
        diff_valid=False,
        diff_reason="KKT system was singular at the returned point",
    )

    explanation = render_explanation(result)

    assert "Solve status: failed." in explanation
    assert "ill-conditioned" in explanation.lower()
    assert "could not certify" in explanation.lower()
    assert "implicit" in explanation
    assert "singular" in explanation
    assert "attempts=1" in explanation


def test_render_explanation_includes_linear_diagnostics() -> None:
    result = SolveResult(
        success=False,
        status=SolveStatus.FAILED,
        termination=TerminationReason.NUMERICAL_FAILURE,
        num_iter=1,
        linear_residual_norm=1e-6,
        linear_condition_estimate=12345.0,
        history=(
            IterationRecord(
                iteration=1,
                accepted=False,
                reason="linear solve failed",
                linear_residual_norm=1e-6,
                linear_condition_estimate=12345.0,
                trials=(
                    TrialRecord(
                        attempt=1,
                        accepted=False,
                        reason="factorization failed",
                        linear_residual_norm=None,
                        linear_condition_estimate=12345.0,
                    ),
                ),
            ),
        ),
    )

    explanation = render_explanation(result)

    assert "Final linear solve summary" in explanation
    assert "Last iteration linear solve" in explanation
    assert "condition=12345.0" in explanation


def test_render_explanation_includes_implicit_certification_metrics() -> None:
    result = SolveResult(
        success=True,
        status=SolveStatus.CONVERGED,
        termination=TerminationReason.GRADIENT_TOL,
        num_iter=2,
        diff_mode_used="implicit",
        diff_valid=True,
        diff_reason="Implicit differentiation certified the returned local minimum.",
        diff_condition_estimate=12.5,
        diff_linear_residual=1e-9,
    )

    explanation = render_explanation(result)

    assert "Differentiation mode: implicit (valid)." in explanation
    assert "Implicit differentiation certification" in explanation
    assert "condition=12.5" in explanation


def test_render_explanation_omits_missing_implicit_certification_metrics() -> None:
    result = SolveResult(
        success=True,
        status=SolveStatus.CONVERGED,
        termination=TerminationReason.GRADIENT_TOL,
        num_iter=2,
        diff_mode_used="implicit",
        diff_valid=False,
        diff_reason="Implicit differentiation is invalid because the terminal optimality system is ill-conditioned.",
        diff_condition_estimate=1e12,
        diff_linear_residual=None,
    )

    explanation = render_explanation(result)

    assert "Implicit differentiation certification: condition=1000000000000.0." in explanation
    assert "residual=None" not in explanation
