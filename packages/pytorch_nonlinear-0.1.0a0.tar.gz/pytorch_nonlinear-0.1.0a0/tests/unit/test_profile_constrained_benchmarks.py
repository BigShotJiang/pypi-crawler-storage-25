from __future__ import annotations

import importlib.util
import sys
from pathlib import Path
from types import SimpleNamespace

import pytest


MODULE_PATH = Path(__file__).resolve().parents[2] / "benchmarks" / "profile_constrained_benchmarks.py"
SPEC = importlib.util.spec_from_file_location("profile_constrained_benchmarks", MODULE_PATH)
assert SPEC is not None
assert SPEC.loader is not None
profile_constrained_benchmarks = importlib.util.module_from_spec(SPEC)
sys.path.insert(0, str(MODULE_PATH.parent))
sys.modules.setdefault("profile_constrained_benchmarks", profile_constrained_benchmarks)
SPEC.loader.exec_module(profile_constrained_benchmarks)

COMMON_MODULE_PATH = Path(__file__).resolve().parents[2] / "benchmarks" / "constrained_benchmark_common.py"
COMMON_SPEC = importlib.util.spec_from_file_location("constrained_benchmark_common", COMMON_MODULE_PATH)
assert COMMON_SPEC is not None
assert COMMON_SPEC.loader is not None
constrained_benchmark_common = importlib.util.module_from_spec(COMMON_SPEC)
sys.modules.setdefault("constrained_benchmark_common", constrained_benchmark_common)
COMMON_SPEC.loader.exec_module(constrained_benchmark_common)


def test_parse_args_accepts_explicit_constrained_scenario() -> None:
    args = profile_constrained_benchmarks.parse_args(
        [
            "--method",
            "sqp",
            "--scenario",
            "quadratic_equality_bounds_large",
            "--device",
            "cuda",
            "--hessian-model",
            "exact",
            "--capture-history",
            "false",
            "--warmup",
            "2",
            "--active",
            "3",
            "--verbose",
            "--force",
        ]
    )

    assert args.method == "sqp"
    assert args.scenario == "quadratic_equality_bounds_large"
    assert args.device == "cuda"
    assert args.hessian_model == "exact"
    assert args.capture_history is False
    assert args.warmup == 2
    assert args.active == 3
    assert args.verbose is True
    assert args.force is True


def test_parse_args_accepts_reduced_overhead_options() -> None:
    args = profile_constrained_benchmarks.parse_args(
        [
            "--method",
            "sqp",
            "--device",
            "cuda",
            "--hessian-model",
            "exact",
            "--profiler-overhead",
            "reduced",
            "--skip-chrome-trace",
        ]
    )

    assert args.profiler_overhead == "reduced"
    assert args.skip_chrome_trace is True


def test_parse_args_uses_ip_default_profile_scenario() -> None:
    args = profile_constrained_benchmarks.parse_args(["--method", "interior_point"])

    assert args.method == "interior_point"
    assert args.scenario == "quadratic_mixed_constraints_large"


def test_parse_args_uses_realistic_default_profile_scenario() -> None:
    args = profile_constrained_benchmarks.parse_args(["--method", "interior_point", "--scenario-set", "realistic"])

    assert args.method == "interior_point"
    assert args.scenario_set == "realistic"
    assert args.scenario == "nonlinear_mixed_constraints_large"


def test_parse_args_uses_same_cross_method_default_profile_scenario_for_sqp() -> None:
    args = profile_constrained_benchmarks.parse_args(["--method", "sqp"])

    assert args.method == "sqp"
    assert args.scenario == "quadratic_mixed_constraints_large"


def test_profile_output_stem_is_scenario_specific() -> None:
    profile_output_stem = getattr(profile_constrained_benchmarks, "_profile_output_stem")
    stem = profile_output_stem(
        method="sqp",
        scenario="quadratic_equality_bounds_large",
        device="cuda",
        hessian_model="bfgs",
        max_iter=40,
        tol=1e-8,
    )

    assert stem == "sqp_quadratic_equality_bounds_large_cuda_bfgs_iter40_tol1e-08"


def test_profile_output_stem_for_ip_omits_hessian_suffix() -> None:
    profile_output_stem = getattr(profile_constrained_benchmarks, "_profile_output_stem")
    stem = profile_output_stem(
        method="interior_point",
        scenario="quadratic_mixed_constraints_large",
        device="cpu",
        hessian_model="bfgs",
        max_iter=40,
        tol=1e-8,
    )

    assert stem == "interior_point_quadratic_mixed_constraints_large_cpu_iter40_tol1e-08"


def test_record_shapes_enabled_respects_profiler_overhead_mode() -> None:
    record_shapes_enabled = getattr(profile_constrained_benchmarks, "_record_shapes_enabled")

    assert record_shapes_enabled(profiler_overhead="standard") is True
    assert record_shapes_enabled(profiler_overhead="reduced") is False


def test_should_export_chrome_trace_respects_skip_flag() -> None:
    should_export_chrome_trace = getattr(profile_constrained_benchmarks, "_should_export_chrome_trace")

    assert should_export_chrome_trace(verbose=True, skip_chrome_trace=False) is True
    assert should_export_chrome_trace(verbose=True, skip_chrome_trace=True) is False
    assert should_export_chrome_trace(verbose=False, skip_chrome_trace=False) is False


class _FakeEvent:
    def __init__(
        self,
        key: str,
        *,
        count: int,
        self_cpu_time_total: float,
        cpu_time_total: float,
        self_cuda_time_total: float = 0.0,
        cuda_time_total: float = 0.0,
    ) -> None:
        self.key = key
        self.count = count
        self.self_cpu_time_total = self_cpu_time_total
        self.cpu_time_total = cpu_time_total
        self.self_cuda_time_total = self_cuda_time_total
        self.cuda_time_total = cuda_time_total


def test_build_profile_target_reports_constrained_metadata() -> None:
    build_profile_target = getattr(profile_constrained_benchmarks, "_build_profile_target")
    _, metadata = build_profile_target(
        method="sqp",
        scenario_name="quadratic_equality_only_small",
        device=profile_constrained_benchmarks.torch.device("cpu"),
        hessian_model="bfgs",
        capture_history=True,
        max_iter=20,
        tol=1e-6,
    )

    assert metadata["scenario"] == "quadratic_equality_only_small"
    assert metadata["dimension"] == 6
    assert metadata["num_equalities"] == 1
    assert metadata["has_bounds"] is True
    assert metadata["constrained_hessian_model"] == "bfgs"


def test_build_profile_target_reports_ip_metadata_without_hessian_model() -> None:
    build_profile_target = getattr(profile_constrained_benchmarks, "_build_profile_target")
    _, metadata = build_profile_target(
        method="interior_point",
        scenario_name="quadratic_mixed_constraints_large",
        device=profile_constrained_benchmarks.torch.device("cpu"),
        hessian_model="bfgs",
        capture_history=False,
        max_iter=20,
        tol=1e-6,
    )

    assert metadata["method"] == "interior_point"
    assert metadata["scenario"] == "quadratic_mixed_constraints_large"
    assert metadata["num_inequalities"] == 12
    assert "constrained_hessian_model" not in metadata


def test_supported_scenarios_include_xlarge_cuda_case_in_default_comparison_suite() -> None:
    assert "quadratic_multi_equality_bounds_xlarge" in constrained_benchmark_common.supported_scenarios()
    assert "quadratic_multi_equality_bounds_xlarge" in constrained_benchmark_common.default_benchmark_scenarios()


def test_supported_scenarios_include_mixed_m9_comparison_case() -> None:
    assert "quadratic_mixed_constraints_large" in constrained_benchmark_common.supported_scenarios()
    assert "quadratic_mixed_constraints_large" in constrained_benchmark_common.default_benchmark_scenarios()


def test_supported_scenarios_include_medium_mixed_comparable_case() -> None:
    assert "quadratic_mixed_constraints_medium" in constrained_benchmark_common.supported_scenarios()
    assert "quadratic_mixed_constraints_medium" in constrained_benchmark_common.comparable_benchmark_scenarios()


def test_supported_scenarios_include_1024_mixed_comparable_case() -> None:
    assert "quadratic_mixed_constraints_1024" in constrained_benchmark_common.supported_scenarios()
    assert "quadratic_mixed_constraints_1024" in constrained_benchmark_common.comparable_benchmark_scenarios()


def test_supported_scenarios_include_realistic_nonlinear_cases() -> None:
    assert "nonlinear_mixed_constraints_medium" in constrained_benchmark_common.supported_scenarios()
    assert "nonlinear_mixed_constraints_xlarge" in constrained_benchmark_common.realistic_benchmark_scenarios()
    assert "nonlinear_mixed_constraints_1536" in constrained_benchmark_common.supported_scenarios()
    assert "nonlinear_mixed_constraints_1536" not in constrained_benchmark_common.realistic_benchmark_scenarios()
    assert "quadratic_equality_bounds_large_cuda" not in constrained_benchmark_common.supported_scenarios()


def test_build_mixed_medium_scenario_reports_comparison_metadata() -> None:
    scenario = constrained_benchmark_common.build_constrained_scenario(
        "quadratic_mixed_constraints_medium",
        device=profile_constrained_benchmarks.torch.device("cpu"),
    )

    assert scenario.metadata["dimension"] == 96
    assert scenario.metadata["num_equalities"] == 4
    assert scenario.metadata["num_inequalities"] == 6
    assert scenario.metadata["has_equalities"] is True
    assert scenario.metadata["has_inequalities"] is True
    assert scenario.metadata["reference_active_bound_count"] == 2
    assert scenario.metadata["reference_active_inequality_count"] == 1
    assert scenario.metadata["scenario_group"] == "comparison"
    assert scenario.metadata["comparison_mode"] == "matched_cpu_cuda"
    assert scenario.x0.shape == (96,)


def test_supported_scenarios_include_xlarge_mixed_m9_comparison_case() -> None:
    assert "quadratic_mixed_constraints_xlarge" in constrained_benchmark_common.supported_scenarios()
    assert "quadratic_mixed_constraints_xlarge" in constrained_benchmark_common.default_benchmark_scenarios()


def test_legacy_aliases_resolve_to_canonical_comparison_names() -> None:
    canonical_name = constrained_benchmark_common.resolve_constrained_scenario_name(
        "quadratic_equality_bounds_large_cuda"
    )
    scenario = constrained_benchmark_common.build_constrained_scenario(
        "quadratic_equality_bounds_large_cuda",
        device=profile_constrained_benchmarks.torch.device("cpu"),
    )

    assert canonical_name == "quadratic_equality_bounds_large"
    assert scenario.name == "quadratic_equality_bounds_large"
    assert scenario.metadata["scenario"] == "quadratic_equality_bounds_large"
    assert scenario.metadata["comparison_mode"] == "matched_cpu_cuda"


def test_build_xlarge_cuda_scenario_reports_gpu_focused_metadata() -> None:
    scenario = constrained_benchmark_common.build_constrained_scenario(
        "quadratic_multi_equality_bounds_xlarge",
        device=profile_constrained_benchmarks.torch.device("cpu"),
    )

    assert scenario.metadata["dimension"] == 2048
    assert scenario.metadata["num_equalities"] == 96
    assert scenario.metadata["scenario_group"] == "comparison"
    assert scenario.metadata["comparison_mode"] == "matched_cpu_cuda"
    assert scenario.metadata["comparison_devices"] == ["cpu", "cuda"]
    assert scenario.metadata["reference_active_bound_count"] == 8
    assert scenario.x0.shape == (2048,)


def test_build_mixed_large_scenario_reports_m9_metadata() -> None:
    scenario = constrained_benchmark_common.build_constrained_scenario(
        "quadratic_mixed_constraints_large",
        device=profile_constrained_benchmarks.torch.device("cpu"),
    )

    assert scenario.metadata["dimension"] == 384
    assert scenario.metadata["num_equalities"] == 10
    assert scenario.metadata["num_inequalities"] == 12
    assert scenario.metadata["has_equalities"] is True
    assert scenario.metadata["has_inequalities"] is True
    assert scenario.metadata["reference_active_bound_count"] == 2
    assert scenario.metadata["reference_active_inequality_count"] == 2
    assert scenario.metadata["scenario_group"] == "comparison"
    assert scenario.metadata["comparison_mode"] == "matched_cpu_cuda"
    assert scenario.x0.shape == (384,)


def test_build_mixed_xlarge_scenario_reports_xlarge_m9_metadata() -> None:
    scenario = constrained_benchmark_common.build_constrained_scenario(
        "quadratic_mixed_constraints_xlarge",
        device=profile_constrained_benchmarks.torch.device("cpu"),
    )

    assert scenario.metadata["dimension"] == 2048
    assert scenario.metadata["num_equalities"] == 32
    assert scenario.metadata["num_inequalities"] == 48
    assert scenario.metadata["has_equalities"] is True
    assert scenario.metadata["has_inequalities"] is True
    assert scenario.metadata["reference_active_bound_count"] == 5
    assert scenario.metadata["reference_active_inequality_count"] == 5
    assert scenario.metadata["scenario_group"] == "comparison"
    assert scenario.metadata["comparison_mode"] == "matched_cpu_cuda"


def test_build_realistic_nonlinear_large_scenario_reports_metadata() -> None:
    scenario = constrained_benchmark_common.build_constrained_scenario(
        "nonlinear_mixed_constraints_large",
        device=profile_constrained_benchmarks.torch.device("cpu"),
    )

    assert scenario.metadata["dimension"] == 512
    assert scenario.metadata["num_equalities"] == 8
    assert scenario.metadata["num_inequalities"] == 24
    assert scenario.metadata["constraint_family"] == "nonlinear_convex_mixed"
    assert scenario.metadata["scenario_group"] == "realistic_comparison"
    assert scenario.metadata["comparison_mode"] == "matched_cpu_cuda"
    assert scenario.metadata["initial_constraint_violation"] is not None
    assert scenario.metadata["initial_constraint_violation"] > 0.0
    assert scenario.x0.shape == (512,)


def test_build_realistic_nonlinear_1536_scenario_reports_metadata() -> None:
    scenario = constrained_benchmark_common.build_constrained_scenario(
        "nonlinear_mixed_constraints_1536",
        device=profile_constrained_benchmarks.torch.device("cpu"),
    )

    assert scenario.metadata["dimension"] == 1536
    assert scenario.metadata["num_equalities"] == 14
    assert scenario.metadata["num_inequalities"] == 52
    assert scenario.metadata["constraint_family"] == "nonlinear_convex_mixed"
    assert scenario.metadata["scenario_group"] == "realistic_comparison"
    assert scenario.metadata["comparison_mode"] == "matched_cpu_cuda"
    assert scenario.metadata["initial_constraint_violation"] is not None
    assert scenario.metadata["initial_constraint_violation"] > 0.0
    assert scenario.x0.shape == (1536,)


def test_build_mixed_1024_scenario_reports_bridge_metadata() -> None:
    scenario = constrained_benchmark_common.build_constrained_scenario(
        "quadratic_mixed_constraints_1024",
        device=profile_constrained_benchmarks.torch.device("cpu"),
    )

    assert scenario.metadata["dimension"] == 1024
    assert scenario.metadata["num_equalities"] == 20
    assert scenario.metadata["num_inequalities"] == 24
    assert scenario.metadata["has_equalities"] is True
    assert scenario.metadata["has_inequalities"] is True
    assert scenario.metadata["reference_active_bound_count"] == 4
    assert scenario.metadata["reference_active_inequality_count"] == 3
    assert scenario.metadata["scenario_group"] == "comparison"
    assert scenario.metadata["comparison_mode"] == "matched_cpu_cuda"
    assert scenario.x0.shape == (1024,)


def test_build_mixed_infeasible_start_small_scenario_reports_positive_initial_violation() -> None:
    scenario = constrained_benchmark_common.build_constrained_scenario(
        "quadratic_mixed_infeasible_start_small",
        device=profile_constrained_benchmarks.torch.device("cpu"),
    )

    assert scenario.metadata["num_equalities"] == 1
    assert scenario.metadata["num_inequalities"] == 2
    assert scenario.metadata["scenario_group"] == "diagnostic"
    assert scenario.metadata["comparison_mode"] == "targeted_diagnostic"
    assert scenario.metadata["initial_constraint_violation"] is not None
    assert scenario.metadata["initial_constraint_violation"] > 0.0


def test_mixed_large_benchmark_scenario_runs_end_to_end_on_cpu() -> None:
    scenario = constrained_benchmark_common.build_constrained_scenario(
        "quadratic_mixed_constraints_large",
        device=profile_constrained_benchmarks.torch.device("cpu"),
    )

    result = constrained_benchmark_common.run_constrained_scenario(
        scenario,
        device=profile_constrained_benchmarks.torch.device("cpu"),
        method="sqp",
        hessian_model="bfgs",
        max_iter=40,
        tol=1e-6,
        capture_history=False,
    )

    assert result.success is True
    assert result.constraint_violation is not None and result.constraint_violation <= 1e-6
    assert result.kkt_residual is not None and result.kkt_residual <= 1e-4


def test_ip_medium_benchmark_scenario_runs_end_to_end_on_cpu() -> None:
    scenario = constrained_benchmark_common.build_constrained_scenario(
        "quadratic_equality_bounds_medium",
        device=profile_constrained_benchmarks.torch.device("cpu"),
    )

    result = constrained_benchmark_common.run_constrained_scenario(
        scenario,
        device=profile_constrained_benchmarks.torch.device("cpu"),
        method="interior_point",
        hessian_model="bfgs",
        max_iter=40,
        tol=1e-6,
        capture_history=False,
    )

    assert result.success is True
    assert result.constraint_violation is not None and result.constraint_violation <= 1e-6
    assert result.kkt_residual is not None and result.kkt_residual <= 1e-4


def test_realistic_nonlinear_medium_benchmark_runs_end_to_end_for_both_methods_on_cpu() -> None:
    scenario = constrained_benchmark_common.build_constrained_scenario(
        "nonlinear_mixed_constraints_medium",
        device=profile_constrained_benchmarks.torch.device("cpu"),
    )

    sqp_result = constrained_benchmark_common.run_constrained_scenario(
        scenario,
        device=profile_constrained_benchmarks.torch.device("cpu"),
        method="sqp",
        hessian_model="exact",
        max_iter=60,
        tol=1e-6,
        capture_history=False,
    )
    ip_result = constrained_benchmark_common.run_constrained_scenario(
        scenario,
        device=profile_constrained_benchmarks.torch.device("cpu"),
        method="interior_point",
        hessian_model="bfgs",
        max_iter=60,
        tol=1e-6,
        capture_history=False,
    )

    assert sqp_result.success is True
    assert sqp_result.status.name == "CONVERGED"
    assert sqp_result.constraint_violation is not None and sqp_result.constraint_violation <= 1e-6
    assert sqp_result.kkt_residual is not None and sqp_result.kkt_residual <= 2e-4
    assert sqp_result.num_iter > 1
    assert ip_result.success is True
    assert ip_result.status.name == "CONVERGED"
    assert ip_result.constraint_violation is not None and ip_result.constraint_violation <= 1e-6
    assert ip_result.kkt_residual is not None and ip_result.kkt_residual <= 1e-4
    assert ip_result.num_iter > 1


def test_mixed_xlarge_benchmark_scenario_builds_for_cpu_without_running_full_solver() -> None:
    scenario = constrained_benchmark_common.build_constrained_scenario(
        "quadratic_mixed_constraints_xlarge",
        device=profile_constrained_benchmarks.torch.device("cpu"),
    )

    assert scenario.name == "quadratic_mixed_constraints_xlarge"
    assert scenario.metadata["comparison_mode"] == "matched_cpu_cuda"
    assert scenario.metadata["num_inequalities"] == 48
    assert scenario.x0.shape == (2048,)


def test_render_text_summary_is_descriptive_not_interpretive() -> None:
    render_text_summary = getattr(profile_constrained_benchmarks, "_render_text_summary")
    rendered = render_text_summary(
        metadata={
            "method": "sqp",
            "device": "cuda",
            "scenario": "quadratic_equality_bounds_large",
            "dimension": 384,
            "num_equalities": 8,
            "constrained_hessian_model": "bfgs",
            "success": True,
            "termination": "step_tol",
            "num_outer_iterations": 12,
            "initial_constraint_violation": 0.75,
            "final_constraint_violation": 0.0,
            "final_kkt_residual": 1e-7,
            "accepted_iterations": 12,
            "rejected_iterations": 0,
            "total_trial_attempts": 15,
            "projected_initialization": True,
        },
        category_breakdown=[
            {"category": "dense_math", "self_cpu_ms": 20.0, "self_cpu_pct": 40.0, "self_device_ms": 2.0, "self_device_pct": 10.0, "calls": 10},
        ],
        top_ops=[
            {"name": "aten::linalg_solve", "self_cpu_ms": 10.0, "self_device_ms": 5.0, "calls": 5},
        ],
    )

    assert "Headline findings" not in rendered
    assert "Category breakdown" in rendered
    assert "Top ops" in rendered
    assert "initial_violation=0.75" in rendered


def test_category_breakdown_reuses_existing_op_grouping() -> None:
    build_category_breakdown = getattr(profile_constrained_benchmarks, "_build_category_breakdown")
    rows = build_category_breakdown(
        [
            _FakeEvent("aten::linalg_solve", count=3, self_cpu_time_total=1000.0, cpu_time_total=1500.0),
            _FakeEvent("cudaMemcpyAsync", count=4, self_cpu_time_total=800.0, cpu_time_total=800.0),
        ]
    )

    categories = [row["category"] for row in rows]
    assert "dense_math" in categories
    assert "transfer_conversion" in categories


def test_main_reduced_overhead_disables_record_shapes_and_can_skip_trace_export(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    captured: dict[str, object] = {}

    class _FakeProfiler:
        def __init__(self, *, activities: object, record_shapes: bool) -> None:
            captured["activities"] = activities
            captured["record_shapes"] = record_shapes
            captured["export_called"] = False

        def __enter__(self) -> _FakeProfiler:
            return self

        def __exit__(self, exc_type, exc, tb) -> None:
            return None

        def step(self) -> None:
            captured["step_called"] = True

        def key_averages(self) -> list[object]:
            return []

        def export_chrome_trace(self, path: str) -> None:
            captured["export_called"] = True
            captured["trace_path"] = path

    monkeypatch.setattr(profile_constrained_benchmarks.torch.cuda, "is_available", lambda: True)
    monkeypatch.setattr(profile_constrained_benchmarks, "profile", lambda **kwargs: _FakeProfiler(**kwargs))
    monkeypatch.setattr(profile_constrained_benchmarks, "collect_git_metadata", lambda repo_root: {})
    monkeypatch.setattr(profile_constrained_benchmarks, "_activities_for_device", lambda device: ["cuda"])
    monkeypatch.setattr(profile_constrained_benchmarks, "_synchronize", lambda device: None)
    monkeypatch.setattr(
        profile_constrained_benchmarks,
        "_build_profile_target",
        lambda **kwargs: (
            lambda: SimpleNamespace(),
            {
                "scenario": kwargs["scenario_name"],
                "device": str(kwargs["device"]),
                "method": kwargs["method"],
                "max_iter": kwargs["max_iter"],
                "tol": kwargs["tol"],
                "capture_history": kwargs["capture_history"],
                "dimension": 512,
                "num_equalities": 8,
            },
        ),
    )
    monkeypatch.setattr(
        profile_constrained_benchmarks,
        "build_constrained_scenario",
        lambda scenario_name, device: SimpleNamespace(name=scenario_name, metadata={"dimension": 512, "num_equalities": 8}),
    )
    monkeypatch.setattr(
        profile_constrained_benchmarks,
        "summarize_constrained_result",
        lambda **kwargs: {
            "success": True,
            "termination": "step_tol",
            "num_outer_iterations": 1,
            "initial_constraint_violation": 1.0,
            "final_constraint_violation": 0.0,
            "final_kkt_residual": 0.0,
            "accepted_iterations": 1,
            "rejected_iterations": 0,
            "total_trial_attempts": 1,
            "projected_initialization": True,
        },
    )
    monkeypatch.setattr(profile_constrained_benchmarks, "_write_summary", lambda **kwargs: tmp_path / "summary.json")

    exit_code = profile_constrained_benchmarks.main(
        [
            "--method",
            "sqp",
            "--scenario",
            "nonlinear_mixed_constraints_large",
            "--device",
            "cuda",
            "--hessian-model",
            "exact",
            "--active",
            "1",
            "--warmup",
            "0",
            "--verbose",
            "--force",
            "--profiler-overhead",
            "reduced",
            "--skip-chrome-trace",
            "--output-dir",
            str(tmp_path),
        ]
    )

    assert exit_code == 0
    assert captured["record_shapes"] is False
    assert captured["export_called"] is False


@pytest.mark.parametrize(
    "scenario_name",
    [
        "quadratic_equality_bounds_large",
        "quadratic_mixed_constraints_xlarge",
        "quadratic_multi_equality_bounds_xlarge",
    ],
)
def test_constrained_scenarios_match_across_cpu_and_cuda_when_available(scenario_name: str) -> None:
    if not profile_constrained_benchmarks.torch.cuda.is_available():
        return

    cpu_scenario = constrained_benchmark_common.build_constrained_scenario(
        scenario_name,
        device=profile_constrained_benchmarks.torch.device("cpu"),
    )
    cuda_scenario = constrained_benchmark_common.build_constrained_scenario(
        scenario_name,
        device=profile_constrained_benchmarks.torch.device("cuda"),
    )

    assert cpu_scenario.metadata["initial_constraint_violation"] == cuda_scenario.metadata["initial_constraint_violation"]
    assert profile_constrained_benchmarks.torch.allclose(cpu_scenario.x0.cpu(), cuda_scenario.x0.cpu())
    assert profile_constrained_benchmarks.torch.allclose(
        cpu_scenario.reference_solution.cpu(),
        cuda_scenario.reference_solution.cpu(),
    )