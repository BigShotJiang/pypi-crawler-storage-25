"""Focused regression tests for the dense interior-point constrained solver."""

from __future__ import annotations

from typing import Any, cast

import pytest
import torch

from pytorch_nonlinear import BatchMode, Bounds, ConstrainedNLPProblem, DebugConfig, DiagnosisCode, DiffMode, EqualityConstraint, InequalityConstraint, ScalingConfig, ScalingMode, SolveStatus, SolverConfig, TerminationReason, solve
from pytorch_nonlinear.linear import LinearSolveResult
from pytorch_nonlinear.scaling.interior_point import build_interior_point_kkt_scaling
from pytorch_nonlinear.solvers.interior_point.evaluation import combine_inequalities
from pytorch_nonlinear.solvers.interior_point import core as interior_point_core
from pytorch_nonlinear.solvers.interior_point.globalization import TrialSelection
from pytorch_nonlinear.solvers.interior_point.telemetry import make_trial_record


def _equality_problem() -> ConstrainedNLPProblem:
    return ConstrainedNLPProblem(
        objective=lambda state, params: (state[0] - 2.0) ** 2 + (state[1] + 2.0) ** 2,
        constraints=(EqualityConstraint(lambda state, params: state[0] + state[1] - 1.0),),
    )


def _dummy_linear_failure(*, like: torch.Tensor, message: str) -> tuple[LinearSolveResult, None, None, None, None, torch.Tensor, torch.Tensor, object]:
    scaling = build_interior_point_kkt_scaling(
        torch.eye(like.numel(), dtype=like.dtype, device=like.device),
        like.new_zeros((0, like.numel())),
        like.new_zeros((0, like.numel())),
        ScalingConfig(),
    )
    return (
        LinearSolveResult(
            success=False,
            step=None,
            diagnosis=(DiagnosisCode.UNCERTIFIED_KKT_STEP,),
            residual_norm=1.0,
            solver_name="dense_direct",
            message=message,
        ),
        None,
        None,
        None,
        None,
        torch.eye(like.numel(), dtype=like.dtype, device=like.device),
        like.new_zeros(like.numel()),
        scaling,
    )


def test_interior_point_solves_mixed_equality_and_bounds_problem() -> None:
    problem = ConstrainedNLPProblem(
        objective=lambda state, params: (state[0] - 2.0) ** 2 + (state[1] + 2.0) ** 2,
        constraints=(EqualityConstraint(lambda state, params: state[0] + state[1] - 1.0),),
        bounds=Bounds(upper=torch.tensor([1.5, 10.0], dtype=torch.float64), name="box"),
    )

    result = solve(
        problem,
        x0=torch.tensor([0.0, 0.0], dtype=torch.float64),
        config=SolverConfig(method="interior_point", max_iter=40, tol=1e-8),
    )

    assert result.success is True
    assert result.status is SolveStatus.CONVERGED
    assert result.termination in {TerminationReason.GRADIENT_TOL, TerminationReason.STEP_TOL}
    assert torch.allclose(result.x, torch.tensor([1.5, -0.5], dtype=torch.float64), atol=1e-5)
    assert result.constraint_violation is not None and result.constraint_violation <= 1e-6
    assert result.kkt_residual is not None and result.kkt_residual <= 1e-6
    assert result.complementarity is not None and result.complementarity <= 1e-6
    assert result.barrier_parameter is not None and result.barrier_parameter <= 1e-6
    assert result.active_set == ("box.upper[0]",)


def test_interior_point_solves_mixed_equality_inequality_and_bounds_problem() -> None:
    problem = ConstrainedNLPProblem(
        objective=lambda state, params: (state[0] - 0.8) ** 2 + (state[1] - 0.2) ** 2,
        constraints=(
            EqualityConstraint(lambda state, params: state[0] + state[1] - 1.0),
            InequalityConstraint(lambda state, params: 0.2 - state[1]),
        ),
        bounds=Bounds(upper=torch.tensor([0.8, 10.0], dtype=torch.float64), name="box"),
    )

    result = solve(
        problem,
        x0=torch.tensor([0.0, 0.0], dtype=torch.float64),
        config=SolverConfig(method="interior_point", max_iter=40, tol=1e-8),
    )

    assert result.success is True
    assert result.status is SolveStatus.CONVERGED
    assert result.termination in {TerminationReason.GRADIENT_TOL, TerminationReason.STEP_TOL}
    assert torch.allclose(result.x, torch.tensor([0.8, 0.2], dtype=torch.float64), atol=2e-4)
    assert result.constraint_violation is not None and result.constraint_violation <= 1e-6
    assert result.kkt_residual is not None and result.kkt_residual <= 1e-6
    assert result.complementarity is not None and result.complementarity <= 1e-6
    assert result.barrier_parameter is not None and result.barrier_parameter <= 1e-6


def test_interior_point_handles_infeasible_linear_inequality_start() -> None:
    problem = ConstrainedNLPProblem(
        objective=lambda state, params: (state[0] - 0.5) ** 2,
        constraints=(InequalityConstraint(lambda state, params: 1.0 - state[0]),),
    )

    result = solve(
        problem,
        x0=torch.tensor([0.0], dtype=torch.float64),
        config=SolverConfig(method="ip", max_iter=40, tol=1e-8),
    )

    assert result.success is True
    assert result.status is SolveStatus.CONVERGED
    assert result.termination in {TerminationReason.GRADIENT_TOL, TerminationReason.STEP_TOL}
    assert torch.allclose(result.x, torch.tensor([1.0], dtype=torch.float64), atol=1e-5)
    assert result.constraint_violation is not None and result.constraint_violation <= 1e-6
    assert result.kkt_residual is not None and result.kkt_residual <= 1e-6
    assert DiagnosisCode.INFEASIBLE_INITIALIZATION in result.diagnosis


def test_interior_point_supports_bounds_only_lower_bound_problem() -> None:
    problem = ConstrainedNLPProblem(
        objective=lambda state, params: (state[0] - 0.25) ** 2,
        bounds=Bounds(lower=torch.tensor([1.0], dtype=torch.float64), name="box"),
    )

    result = solve(
        problem,
        x0=torch.tensor([3.0], dtype=torch.float64),
        config=SolverConfig(method="interior_point", max_iter=40, tol=1e-8),
    )

    assert result.success is True
    assert result.status is SolveStatus.CONVERGED
    assert torch.allclose(result.x, torch.tensor([1.0], dtype=torch.float64), atol=1e-6)
    assert result.active_set == ("box.lower[0]",)
    assert result.constraint_violation is not None and result.constraint_violation <= 1e-8
    assert result.complementarity is not None and result.complementarity <= 1e-6


def test_interior_point_handles_fixed_variable_bounds() -> None:
    problem = ConstrainedNLPProblem(
        objective=lambda state, params: (state[0] - 3.0) ** 2 + (state[1] + 1.0) ** 2,
        bounds=Bounds(
            lower=torch.tensor([2.0, -10.0], dtype=torch.float64),
            upper=torch.tensor([2.0, 10.0], dtype=torch.float64),
            name="fixed",
        ),
    )

    result = solve(
        problem,
        x0=torch.tensor([0.0, 0.0], dtype=torch.float64),
        config=SolverConfig(method="interior_point", max_iter=40, tol=1e-8),
    )

    assert result.success is True
    assert result.status is SolveStatus.CONVERGED
    assert torch.allclose(result.x, torch.tensor([2.0, -1.0], dtype=torch.float64), atol=1e-5)
    assert "fixed.lower[0]" in result.active_set
    assert "fixed.upper[0]" in result.active_set
    assert result.constraint_violation is not None and result.constraint_violation <= 1e-8


def test_interior_point_and_sqp_agree_on_certifiable_equality_problem() -> None:
    problem = ConstrainedNLPProblem(
        objective=lambda state, params: (state[0] - 2.0) ** 2 + (state[1] + 2.0) ** 2,
        constraints=(EqualityConstraint(lambda state, params: state[0] + state[1] - 1.0),),
    )

    interior_point_result = solve(
        problem,
        x0=torch.tensor([0.0, 0.0], dtype=torch.float64),
        config=SolverConfig(method="interior_point", max_iter=40, tol=1e-8),
    )
    sqp_result = solve(
        problem,
        x0=torch.tensor([0.0, 0.0], dtype=torch.float64),
        config=SolverConfig(method="sqp", max_iter=40, tol=1e-8),
    )

    assert interior_point_result.success is True
    assert sqp_result.success is True
    assert interior_point_result.status is SolveStatus.CONVERGED
    assert sqp_result.status is SolveStatus.CONVERGED
    assert torch.allclose(interior_point_result.x, torch.tensor([2.5, -1.5], dtype=torch.float64), atol=1e-5)
    assert torch.allclose(sqp_result.x, torch.tensor([2.5, -1.5], dtype=torch.float64), atol=1e-5)
    assert torch.allclose(interior_point_result.x, sqp_result.x, atol=1e-5)
    assert interior_point_result.constraint_violation is not None and interior_point_result.constraint_violation <= 1e-6
    assert sqp_result.constraint_violation is not None and sqp_result.constraint_violation <= 1e-6
    assert interior_point_result.kkt_residual is not None and interior_point_result.kkt_residual <= 1e-6
    assert sqp_result.kkt_residual is not None and sqp_result.kkt_residual <= 1e-6


def test_interior_point_fails_closed_on_uncertified_singular_kkt_fallback() -> None:
    problem = ConstrainedNLPProblem(
        objective=lambda state, params: state[0] ** 2,
        constraints=(
            EqualityConstraint(lambda state, params: state[0] - 1.0),
            EqualityConstraint(lambda state, params: 2.0 * state[0] - 1.0),
        ),
    )

    result = solve(
        problem,
        x0=torch.tensor([0.0], dtype=torch.float64),
        config=SolverConfig(method="interior_point", max_iter=10, tol=1e-8),
    )

    assert result.success is False
    assert result.status is SolveStatus.FAILED
    assert result.termination is TerminationReason.NUMERICAL_FAILURE
    assert DiagnosisCode.UNCERTIFIED_KKT_STEP in result.diagnosis
    assert DiagnosisCode.RANK_DEFICIENT_JACOBIAN in result.diagnosis
    assert result.linear_residual_norm is not None and result.linear_residual_norm > 1e-8


def test_interior_point_rejects_non_auto_batch_mode() -> None:
    with pytest.raises(NotImplementedError, match="batch modes are not implemented"):
        interior_point_core.solve_interior_point_nlp(
            problem=_equality_problem(),
            x0=torch.tensor([0.0, 0.0], dtype=torch.float64),
            config=SolverConfig(method="interior_point", batch_mode=BatchMode.SHARED_STRUCTURE),
        )


def test_interior_point_rejects_cholesky_backend() -> None:
    with pytest.raises(ValueError, match="indefinite-capable linear solver"):
        interior_point_core.solve_interior_point_nlp(
            problem=_equality_problem(),
            x0=torch.tensor([0.0, 0.0], dtype=torch.float64),
            config=SolverConfig(method="interior_point", linear_solver="cholesky"),
        )


@pytest.mark.parametrize("diff_mode", [DiffMode.UNROLL, DiffMode.IMPLICIT])
def test_interior_point_reports_constrained_diff_as_unsupported(diff_mode: DiffMode) -> None:
    result = solve(
        _equality_problem(),
        x0=torch.tensor([0.0, 0.0], dtype=torch.float64),
        config=SolverConfig(method="interior_point", diff_mode=diff_mode, max_iter=40, tol=1e-8),
    )

    assert result.success is True
    assert result.diff_mode_used == diff_mode.value
    assert result.diff_valid is False
    assert result.diff_reason == "Constrained solver differentiation is not implemented yet."


def test_interior_point_reports_newton_system_failure(monkeypatch: pytest.MonkeyPatch) -> None:
    def fail_step(**kwargs: Any) -> tuple[LinearSolveResult, None, None, None, None, torch.Tensor, torch.Tensor, object]:
        hessian = cast(torch.Tensor, kwargs["hessian"])
        return _dummy_linear_failure(like=hessian.diagonal(), message="forced affine failure")

    monkeypatch.setattr(interior_point_core, "_solve_primal_dual_step", fail_step)

    result = solve(
        _equality_problem(),
        x0=torch.tensor([0.0, 0.0], dtype=torch.float64),
        config=SolverConfig(method="interior_point", max_iter=10, tol=1e-8),
    )

    assert result.success is False
    assert result.status is SolveStatus.FAILED
    assert result.termination is TerminationReason.NUMERICAL_FAILURE
    assert result.message == "The interior-point Newton system solve failed."
    assert DiagnosisCode.UNCERTIFIED_KKT_STEP in result.diagnosis


def test_interior_point_reports_corrector_system_failure(monkeypatch: pytest.MonkeyPatch) -> None:
    call_count = 0
    original = cast(Any, interior_point_core.__dict__["_solve_primal_dual_step"])

    def fail_on_second_call(*args: Any, **kwargs: Any) -> tuple[LinearSolveResult, torch.Tensor | None, torch.Tensor | None, torch.Tensor | None, torch.Tensor | None, torch.Tensor, torch.Tensor, object]:
        nonlocal call_count
        call_count += 1
        if call_count == 2:
            hessian = cast(torch.Tensor, kwargs["hessian"])
            return _dummy_linear_failure(like=hessian.diagonal(), message="forced corrector failure")
        return original(*args, **kwargs)

    monkeypatch.setattr(interior_point_core, "_solve_primal_dual_step", fail_on_second_call)

    result = solve(
        _equality_problem(),
        x0=torch.tensor([0.0, 0.0], dtype=torch.float64),
        config=SolverConfig(method="interior_point", max_iter=10, tol=1e-8),
    )

    assert result.success is False
    assert result.status is SolveStatus.FAILED
    assert result.termination is TerminationReason.NUMERICAL_FAILURE
    assert result.message == "The interior-point corrector system solve failed."
    assert DiagnosisCode.UNCERTIFIED_KKT_STEP in result.diagnosis


def test_interior_point_records_step_rejection_history(monkeypatch: pytest.MonkeyPatch) -> None:
    def reject_all_trials(**kwargs: Any) -> TrialSelection:
        x = cast(torch.Tensor, kwargs["x"])
        original_shape = cast(torch.Size, kwargs["original_shape"])
        linear_result = cast(LinearSolveResult, kwargs["linear_result"])
        trial_record = make_trial_record(
            attempt=1,
            objective_value=1.0,
            step_norm=0.5,
            accepted=False,
            reason="barrier_not_improved",
            state=x.reshape(original_shape).detach(),
            step_parameter=1.0,
            linear_solver_iterations=linear_result.iterations,
            linear_residual_norm=linear_result.residual_norm,
            linear_condition_estimate=linear_result.condition_estimate,
        )
        return TrialSelection(
            accepted_alpha=None,
            accepted_state=None,
            accepted_step_norm=None,
            trial_records=(trial_record,),
        )

    monkeypatch.setattr(interior_point_core, "select_trial_step", reject_all_trials)

    result = solve(
        _equality_problem(),
        x0=torch.tensor([0.0, 0.0], dtype=torch.float64),
        config=SolverConfig(method="interior_point", max_iter=10, tol=1e-8),
    )

    assert result.success is False
    assert result.status is SolveStatus.FAILED
    assert result.termination is TerminationReason.NUMERICAL_FAILURE
    assert DiagnosisCode.STEP_REJECTED in result.diagnosis
    assert result.history
    assert result.history[-1].accepted is False
    assert result.history[-1].reason == "step_rejected"
    assert result.history[-1].trials
    assert result.history[-1].trials[0].accepted is False
    assert result.history[-1].trials[0].reason == "barrier_not_improved"


def test_interior_point_converges_on_nonlinear_equality_constraint() -> None:
    # min y s.t. y = x^2.  The Lagrangian Hessian is indefinite at the
    # starting point ([[-2λ,0],[0,0]] with λ≈1), so correct computation of
    # second-order constraint curvature is required for convergence.
    problem = ConstrainedNLPProblem(
        objective=lambda state, params: state[1],
        constraints=(EqualityConstraint(lambda state, params: state[1] - state[0] ** 2),),
    )

    result = solve(
        problem,
        x0=torch.tensor([1.0, 1.0], dtype=torch.float64),
        config=SolverConfig(method="interior_point", max_iter=40, tol=1e-8),
    )

    assert result.success is True
    assert result.status is SolveStatus.CONVERGED
    assert result.termination in {TerminationReason.GRADIENT_TOL, TerminationReason.STEP_TOL}
    assert torch.allclose(result.x, torch.tensor([0.0, 0.0], dtype=torch.float64), atol=1e-5)
    assert result.objective_value is not None and abs(result.objective_value) <= 1e-8
    assert result.constraint_violation is not None and result.constraint_violation <= 1e-8
    assert result.kkt_residual is not None and result.kkt_residual <= 1e-8
    assert result.complementarity is not None and result.complementarity <= 1e-8
    assert result.barrier_parameter is not None and result.barrier_parameter <= 1e-8
    assert DiagnosisCode.UNCERTIFIED_KKT_STEP not in result.diagnosis


def test_interior_point_skips_history_materialization_when_disabled() -> None:
    problem = ConstrainedNLPProblem(
        objective=lambda state, params: (state[0] - 2.0) ** 2 + (state[1] + 2.0) ** 2,
        constraints=(EqualityConstraint(lambda state, params: state[0] + state[1] - 1.0),),
    )

    result = solve(
        problem,
        x0=torch.tensor([0.0, 0.0], dtype=torch.float64),
        config=SolverConfig(
            method="interior_point",
            max_iter=40,
            tol=1e-8,
            debug=DebugConfig(capture_history=False),
        ),
    )

    assert result.success is True
    assert result.history == ()
    assert result.num_iter > 0
    assert result.linear_condition_estimate is None


def test_interior_point_reports_linear_condition_estimate_when_history_capture_is_enabled() -> None:
    result = solve(
        _equality_problem(),
        x0=torch.tensor([0.0, 0.0], dtype=torch.float64),
        config=SolverConfig(
            method="interior_point",
            max_iter=40,
            tol=1e-8,
            debug=DebugConfig(capture_history=True),
        ),
    )

    assert result.success is True
    assert result.linear_condition_estimate is not None
    assert result.history
    assert result.history[-1].linear_condition_estimate is not None


def test_interior_point_reports_auto_scaling_metadata() -> None:
    problem = ConstrainedNLPProblem(
        objective=lambda state, params: (10.0 * state[0] - 1.0) ** 2 + (0.1 * state[1] + 2.0) ** 2,
        constraints=(EqualityConstraint(lambda state, params: 100.0 * state[0] + 0.01 * state[1] - 1.0),),
    )

    result = solve(
        problem,
        x0=torch.tensor([0.0, 0.0], dtype=torch.float64),
        config=SolverConfig(
            method="interior_point",
            max_iter=40,
            tol=1e-8,
            scaling=ScalingConfig(variable_mode=ScalingMode.AUTO, residual_mode=ScalingMode.AUTO),
        ),
    )

    assert result.success is True
    scaling_metadata = result.reproducibility.get("interior_point_scaling")
    assert scaling_metadata is not None
    assert scaling_metadata["variable_mode"] == "auto"
    assert scaling_metadata["equality_mode"] == "auto"
    assert scaling_metadata["inequality_mode"] == "auto"


def test_interior_point_scaling_surfaces_poor_scaling_diagnosis() -> None:
    scaling = build_interior_point_kkt_scaling(
        augmented_hessian=torch.diag(torch.tensor([1e-16, 1e16], dtype=torch.float64)),
        equality_jacobian=torch.tensor([[1e-8, 0.0], [0.0, 1e8]], dtype=torch.float64),
        inequality_jacobian=torch.tensor([[1e8, 0.0], [0.0, 1e-8]], dtype=torch.float64),
        config=ScalingConfig(variable_mode=ScalingMode.AUTO, residual_mode=ScalingMode.AUTO),
    )

    assert DiagnosisCode.POOR_SCALING in scaling.diagnoses
    assert scaling.equality_spread is not None and scaling.equality_spread > 1e4
    assert scaling.inequality_spread is not None and scaling.inequality_spread > 1e4


def test_interior_point_scaling_accepts_manual_scales() -> None:
    scaling = build_interior_point_kkt_scaling(
        augmented_hessian=torch.eye(2, dtype=torch.float64),
        equality_jacobian=torch.tensor([[1.0, -1.0]], dtype=torch.float64),
        inequality_jacobian=torch.tensor([[2.0, 3.0]], dtype=torch.float64),
        config=ScalingConfig(
            variable_mode=ScalingMode.MANUAL,
            residual_mode=ScalingMode.MANUAL,
            variable_scale=torch.tensor([2.0, 0.5], dtype=torch.float64),
            residual_scale=torch.tensor([4.0, 0.25], dtype=torch.float64),
        ),
    )

    assert scaling.variable_mode == "manual"
    assert scaling.equality_mode == "manual"
    assert scaling.inequality_mode == "manual"
    assert torch.allclose(scaling.variable_scale, torch.tensor([2.0, 0.5], dtype=torch.float64))
    assert torch.allclose(scaling.equality_scale, torch.tensor([4.0], dtype=torch.float64))
    assert torch.allclose(scaling.inequality_scale, torch.tensor([0.25], dtype=torch.float64))


def test_interior_point_scaling_rejects_invalid_manual_scale_shapes() -> None:
    with pytest.raises(ValueError, match="scaling.variable_scale"):
        build_interior_point_kkt_scaling(
            augmented_hessian=torch.eye(2, dtype=torch.float64),
            equality_jacobian=torch.zeros((0, 2), dtype=torch.float64),
            inequality_jacobian=torch.zeros((0, 2), dtype=torch.float64),
            config=ScalingConfig(
                variable_mode=ScalingMode.MANUAL,
                variable_scale=None,
            ),
        )

    with pytest.raises(ValueError, match="scaling.variable_scale"):
        build_interior_point_kkt_scaling(
            augmented_hessian=torch.eye(2, dtype=torch.float64),
            equality_jacobian=torch.zeros((0, 2), dtype=torch.float64),
            inequality_jacobian=torch.zeros((0, 2), dtype=torch.float64),
            config=ScalingConfig(
                variable_mode=ScalingMode.MANUAL,
                variable_scale=torch.tensor([1.0, 2.0, 3.0], dtype=torch.float64),
            ),
        )

    with pytest.raises(ValueError, match="scaling.residual_scale"):
        build_interior_point_kkt_scaling(
            augmented_hessian=torch.eye(2, dtype=torch.float64),
            equality_jacobian=torch.tensor([[1.0, 0.0]], dtype=torch.float64),
            inequality_jacobian=torch.tensor([[0.0, 1.0]], dtype=torch.float64),
            config=ScalingConfig(
                residual_mode=ScalingMode.MANUAL,
                residual_scale=None,
            ),
        )

    with pytest.raises(ValueError, match="positive"):
        build_interior_point_kkt_scaling(
            augmented_hessian=torch.eye(2, dtype=torch.float64),
            equality_jacobian=torch.tensor([[1.0, 0.0]], dtype=torch.float64),
            inequality_jacobian=torch.tensor([[0.0, 1.0]], dtype=torch.float64),
            config=ScalingConfig(
                residual_mode=ScalingMode.MANUAL,
                residual_scale=torch.tensor([1.0, 0.0], dtype=torch.float64),
            ),
        )


def test_combine_inequalities_can_compute_values_without_jacobian() -> None:
    combined = combine_inequalities(
        torch.tensor([1.5, -0.5], dtype=torch.float64),
        nonlinear_values=torch.tensor([0.25], dtype=torch.float64),
        nonlinear_jacobian=None,
        lower=torch.tensor([1.0, -1.0], dtype=torch.float64),
        upper=torch.tensor([2.0, 0.0], dtype=torch.float64),
    )

    assert torch.allclose(combined.values, torch.tensor([0.25, -0.5, -0.5, -0.5, -0.5], dtype=torch.float64))
    assert combined.jacobian.shape == (0, 2)


def test_interior_point_max_iter_can_report_healthy_progress() -> None:
    problem = ConstrainedNLPProblem(
        objective=lambda state, params: (state[0] - 1.0) ** 4 + (state[1] - 1.0) ** 4,
        constraints=(EqualityConstraint(lambda state, params: state[0] - state[1]),),
    )

    x0 = torch.tensor([3.0, -1.0], dtype=torch.float64)
    initial_objective = float(((x0[0] - 1.0) ** 4 + (x0[1] - 1.0) ** 4).item())

    result = solve(
        problem,
        x0=x0,
        config=SolverConfig(method="interior_point", max_iter=1, tol=1e-16),
    )

    assert result.success is False
    assert result.status is SolveStatus.MAX_ITER_REACHED
    assert result.termination is TerminationReason.MAX_ITER
    assert DiagnosisCode.STEP_REJECTED not in result.diagnosis
    assert result.history
    assert result.history[-1].accepted is True
    assert all(trial.accepted for trial in result.history[-1].trials)
    assert result.objective_value is not None and result.objective_value < initial_objective