from __future__ import annotations

import math

import pytest
import torch

from pytorch_nonlinear import BatchMode, NonlinearLeastSquaresProblem, SmoothMinimizationProblem, SolverConfig, minimize, solve
from pytorch_nonlinear.api.config import normalize_solver_config
from pytorch_nonlinear.batching.shared_structure import SharedStructureBatchResult, shared_structure_batch_shape, slice_shared_structure_value
from pytorch_nonlinear.diagnostics import DiagnosisCode
from pytorch_nonlinear.linear import CholeskyLinearSolver, DenseDirectLinearSolver, LinearSolveResult, Linearization, build_linear_solver
from pytorch_nonlinear.steps import initial_trust_region_radius, solve_trust_region_subproblem
from pytorch_nonlinear.utils import move_to_device, resolve_requested_device


def test_normalize_solver_config_returns_default_and_preserves_explicit_instance() -> None:
    default_config = normalize_solver_config(None)
    user_config = SolverConfig(method="trust_region", max_iter=7)

    assert isinstance(default_config, SolverConfig)
    assert default_config == SolverConfig()
    assert normalize_solver_config(user_config) is user_config


def test_minimize_placeholder_raises_not_implemented() -> None:
    with pytest.raises(NotImplementedError, match="not implemented"):
        minimize(lambda x: x, x0=[0.0], method="lm", config=SolverConfig())


def test_solve_rejects_independent_batch_mode_before_solver_dispatch() -> None:
    problem = NonlinearLeastSquaresProblem(residual=lambda state, params: state - 1.0)

    with pytest.raises(NotImplementedError, match="Independent batch mode"):
        solve(
            problem,
            x0=torch.tensor([[0.0], [1.0]], dtype=torch.float64),
            params=None,
            config=SolverConfig(method="gauss_newton", batch_mode=BatchMode.INDEPENDENT),
        )


def test_solve_rejects_unimplemented_problem_kinds() -> None:
    problem = SmoothMinimizationProblem(objective=lambda state, params: state[0] ** 2)

    with pytest.raises(NotImplementedError, match="smooth"):
        solve(problem, x0=torch.tensor([1.0], dtype=torch.float64), params=None, config=SolverConfig())


def test_shared_structure_helpers_slice_batched_values_and_preserve_shared_inputs() -> None:
    x0 = torch.tensor([[1.0, 2.0], [3.0, 4.0]], dtype=torch.float64)
    params = {
        "targets": torch.tensor([[10.0], [20.0]], dtype=torch.float64),
        "shared_bias": torch.tensor([5.0], dtype=torch.float64),
        "nested": (torch.tensor([[7.0], [8.0]], dtype=torch.float64), ["keep"]),
    }

    batch_shape = shared_structure_batch_shape(x0)
    sliced = slice_shared_structure_value(params, index=1, batch_size=batch_shape[0])

    assert batch_shape == (2,)
    assert torch.equal(sliced["targets"], torch.tensor([20.0], dtype=torch.float64))
    assert torch.equal(sliced["shared_bias"], params["shared_bias"])
    assert torch.equal(sliced["nested"][0], torch.tensor([8.0], dtype=torch.float64))
    assert sliced["nested"][1] == ["keep"]


def test_shared_structure_batch_result_serializes_and_summarizes() -> None:
    problem = NonlinearLeastSquaresProblem(residual=lambda state, params: state - params["target"])
    result = solve(
        problem,
        x0=torch.tensor([[0.0], [2.0]], dtype=torch.float64),
        params={"target": torch.tensor([[1.0], [3.0]], dtype=torch.float64)},
        config=SolverConfig(method="lm", batch_mode=BatchMode.SHARED_STRUCTURE, max_iter=8, tol=1e-10),
    )

    assert isinstance(result, SharedStructureBatchResult)
    assert result.to_dict()["batch_shape"] == [2]
    assert "succeeded=2/2" in result.summary()


def test_resolve_requested_device_and_move_to_device_preserve_nested_structure() -> None:
    device = resolve_requested_device("cpu")
    payload = {
        "tensor": torch.tensor([1.0], dtype=torch.float64),
        "tuple": (torch.tensor([2.0], dtype=torch.float64), [torch.tensor([3.0], dtype=torch.float64)]),
        "text": "kept",
    }

    moved = move_to_device(payload, device)

    assert device == torch.device("cpu")
    assert moved["tensor"].device.type == "cpu"
    assert moved["tuple"][0].device.type == "cpu"
    assert moved["tuple"][1][0].device.type == "cpu"
    assert moved["text"] == "kept"


def test_build_linear_solver_rejects_unknown_backends() -> None:
    with pytest.raises(ValueError, match="Unsupported linear solver"):
        build_linear_solver("qr")


def test_dense_direct_solver_reports_rank_deficiency_when_falling_back_to_least_squares() -> None:
    linearization = Linearization(
        matrix=torch.tensor([[1.0, 1.0], [1.0, 1.0]], dtype=torch.float64),
        rhs=torch.tensor([1.0, 1.0], dtype=torch.float64),
    )

    result = DenseDirectLinearSolver().solve(linearization)

    assert result.success is True
    assert DiagnosisCode.RANK_DEFICIENT_JACOBIAN in result.diagnosis
    assert result.solver_name == "dense_direct"
    assert result.residual_norm == pytest.approx(0.0, abs=1e-10)
    assert torch.allclose(result.step, torch.tensor([0.5, 0.5], dtype=torch.float64), atol=1e-8)


def test_dense_direct_solver_batched_solve_matches_looped_instances() -> None:
    linearization = Linearization(
        matrix=torch.tensor(
            (
                ((4.0, 1.0), (1.0, 3.0)),
                ((2.0, 0.0), (0.0, 5.0)),
            ),
            dtype=torch.float64,
        ),
        rhs=torch.tensor(((1.0, 2.0), (3.0, 4.0)), dtype=torch.float64),
    )

    solver = DenseDirectLinearSolver()
    result = solver.solve(linearization)
    loop_results = tuple(
        solver.solve(Linearization(matrix=linearization.matrix[i], rhs=linearization.rhs[i]))
        for i in range(linearization.matrix.shape[0])
    )

    assert result.success is True
    assert result.step is not None
    assert result.step.shape == (2, 2)
    assert torch.allclose(result.step, torch.stack([item.step for item in loop_results]))
    assert torch.allclose(result.condition_estimate, torch.tensor([item.condition_estimate for item in loop_results], dtype=torch.float64))
    assert torch.allclose(result.residual_norm, torch.tensor([item.residual_norm for item in loop_results], dtype=torch.float64))


def test_dense_direct_solver_can_skip_condition_estimate() -> None:
    linearization = Linearization(
        matrix=torch.tensor(((4.0, 1.0), (1.0, 3.0)), dtype=torch.float64),
        rhs=torch.tensor((1.0, 2.0), dtype=torch.float64),
        compute_condition_estimate=False,
    )

    result = DenseDirectLinearSolver().solve(linearization)

    assert result.success is True
    assert result.condition_estimate is None
    assert result.diagnosis == ()
    assert torch.allclose(result.step, torch.tensor((0.09090909090909091, 0.6363636363636364), dtype=torch.float64), atol=1e-10)


def test_cholesky_solver_batched_solve_matches_looped_instances() -> None:
    linearization = Linearization(
        matrix=torch.tensor(
            (
                ((4.0, 1.0), (1.0, 3.0)),
                ((6.0, 0.0), (0.0, 2.0)),
            ),
            dtype=torch.float64,
        ),
        rhs=torch.tensor(((1.0, 2.0), (3.0, 4.0)), dtype=torch.float64),
    )

    solver = CholeskyLinearSolver()
    result = solver.solve(linearization)
    loop_results = tuple(
        solver.solve(Linearization(matrix=linearization.matrix[i], rhs=linearization.rhs[i]))
        for i in range(linearization.matrix.shape[0])
    )

    assert result.success is True
    assert result.step is not None
    assert result.step.shape == (2, 2)
    assert torch.allclose(result.step, torch.stack([item.step for item in loop_results]))
    assert torch.allclose(result.condition_estimate, torch.tensor([item.condition_estimate for item in loop_results], dtype=torch.float64))
    assert torch.allclose(result.residual_norm, torch.tensor([item.residual_norm for item in loop_results], dtype=torch.float64))


def test_cholesky_solver_reports_per_instance_diagnoses_in_batched_failure_case() -> None:
    linearization = Linearization(
        matrix=torch.tensor(
            (
                ((0.0, 0.0), (0.0, 0.0)),
                ((4.0, 0.0), (0.0, 3.0)),
            ),
            dtype=torch.float64,
        ),
        rhs=torch.tensor(((0.0, 0.0), (1.0, 2.0)), dtype=torch.float64),
    )

    result = CholeskyLinearSolver().solve(linearization)

    assert isinstance(result.success, torch.Tensor)
    assert result.diagnosis_by_batch is not None
    assert DiagnosisCode.RANK_DEFICIENT_JACOBIAN in result.diagnosis_by_batch[0]
    assert DiagnosisCode.ILL_CONDITIONED_SYSTEM in result.diagnosis_by_batch[0]
    assert result.diagnosis_by_batch[1] == ()


def test_initial_trust_region_radius_respects_configured_and_fallback_paths() -> None:
    normal_matrix = torch.tensor([[0.0, 0.0], [0.0, 0.0]], dtype=torch.float64)
    gradient = torch.tensor([1.0, -2.0], dtype=torch.float64)
    variable_scale = torch.tensor([1.0, 1.0], dtype=torch.float64)

    configured = initial_trust_region_radius(
        normal_matrix,
        gradient,
        gradient,
        variable_scale,
        build_linear_solver("dense_direct"),
        configured_radius=0.25,
    )
    fallback = initial_trust_region_radius(
        normal_matrix,
        gradient,
        gradient,
        variable_scale,
        build_linear_solver("cholesky"),
        configured_radius=None,
    )

    assert configured == pytest.approx(0.25)
    assert fallback == pytest.approx(math.sqrt(5.0), rel=1e-9, abs=1e-9)


def test_batched_initial_trust_region_radius_matches_looped_instances() -> None:
    normal_matrix = torch.tensor(
        (
            ((4.0, 1.0), (1.0, 3.0)),
            ((6.0, 0.0), (0.0, 2.0)),
        ),
        dtype=torch.float64,
    )
    gradient = torch.tensor(((1.0, -2.0), (3.0, 4.0)), dtype=torch.float64)
    original_gradient = gradient.clone()
    variable_scale = torch.ones_like(gradient)
    solver = build_linear_solver("dense_direct")

    batched_radius = initial_trust_region_radius(
        normal_matrix,
        gradient,
        original_gradient,
        variable_scale,
        solver,
        configured_radius=None,
    )
    looped_radius = torch.tensor(
        [
            initial_trust_region_radius(
                normal_matrix[index],
                gradient[index],
                original_gradient[index],
                variable_scale[index],
                solver,
                configured_radius=None,
            )
            for index in range(normal_matrix.shape[0])
        ],
        dtype=torch.float64,
    )

    assert isinstance(batched_radius, torch.Tensor)
    assert torch.allclose(batched_radius, looped_radius, atol=1e-10, rtol=1e-10)


def test_solve_trust_region_subproblem_projects_last_successful_step_to_boundary() -> None:
    result = solve_trust_region_subproblem(
        normal_matrix=torch.eye(2, dtype=torch.float64),
        gradient=torch.tensor([-3.0, 0.0], dtype=torch.float64),
        variable_scale=torch.ones(2, dtype=torch.float64),
        radius=1.0,
        linear_solver=build_linear_solver("dense_direct"),
        max_damping_adjustments=1,
    )

    assert result.success is True
    assert result.projected is True
    assert result.boundary_hit is True
    assert result.linear_result is not None
    assert isinstance(result.linear_result.success, bool)
    assert result.step_norm == pytest.approx(1.0, rel=1e-9, abs=1e-9)
    assert result.predicted_reduction == pytest.approx(2.5, rel=1e-9, abs=1e-9)
    assert torch.allclose(result.step, torch.tensor([1.0, 0.0], dtype=torch.float64), atol=1e-10)


def test_batched_trust_region_projection_keeps_failed_rows_failed() -> None:
    class PartialSuccessSolver:
        name = "partial_success"

        def solve(self, linearization: Linearization) -> LinearSolveResult:
            batch_size = int(linearization.matrix.shape[0])
            if batch_size == 1:
                return LinearSolveResult(
                    success=torch.tensor([True]),
                    step=torch.tensor([[2.0, 0.0]], dtype=torch.float64),
                    condition_estimate=torch.tensor([1.0], dtype=torch.float64),
                    residual_norm=torch.tensor([0.0], dtype=torch.float64),
                    iterations=1,
                    solver_name=self.name,
                    message="diagnostic",
                )
            return LinearSolveResult(
                success=torch.tensor([True, False]),
                step=torch.tensor([[2.0, 0.0], [0.0, 0.0]], dtype=torch.float64),
                condition_estimate=torch.tensor([1.0, float("nan")], dtype=torch.float64),
                residual_norm=torch.tensor([0.0, float("nan")], dtype=torch.float64),
                iterations=1,
                solver_name=self.name,
                message="stub",
            )

    result = solve_trust_region_subproblem(
        normal_matrix=torch.eye(2, dtype=torch.float64).unsqueeze(0).expand(2, -1, -1),
        gradient=torch.tensor([[-2.0, 0.0], [-1.0, 0.0]], dtype=torch.float64),
        variable_scale=torch.ones((2, 2), dtype=torch.float64),
        radius=torch.ones(2, dtype=torch.float64),
        linear_solver=PartialSuccessSolver(),
        max_damping_adjustments=1,
    )

    assert isinstance(result.success, torch.Tensor)
    assert torch.equal(result.success.cpu(), torch.tensor([True, False]))
    assert isinstance(result.projected, torch.Tensor)
    assert torch.equal(result.projected.cpu(), torch.tensor([True, False]))
    assert torch.allclose(result.step[0], torch.tensor([1.0, 0.0], dtype=torch.float64), atol=1e-10)
    assert torch.allclose(result.step[1], torch.tensor([0.0, 0.0], dtype=torch.float64), atol=1e-10)


def test_batched_trust_region_subproblem_compacts_unresolved_rows() -> None:
    class RecordingSolver:
        name = "recording"

        def __init__(self) -> None:
            self.retry_batch_sizes: list[int] = []
            self.diagnostic_batch_sizes: list[int] = []

        def solve(self, linearization: Linearization) -> LinearSolveResult:
            batch_size = int(linearization.matrix.shape[0])
            target = self.diagnostic_batch_sizes if linearization.compute_condition_estimate else self.retry_batch_sizes
            target.append(batch_size)
            if batch_size == 3:
                step = torch.tensor([[0.5, 0.0], [2.0, 0.0], [0.4, 0.0]], dtype=torch.float64)
                return LinearSolveResult(
                    success=torch.tensor([True, True, True]),
                    step=step,
                    condition_estimate=torch.ones(3, dtype=torch.float64),
                    residual_norm=torch.zeros(3, dtype=torch.float64),
                    iterations=1,
                    solver_name=self.name,
                    message="first pass",
                )

            assert batch_size == 1
            return LinearSolveResult(
                success=torch.tensor([True]),
                step=torch.tensor([[0.5, 0.0]], dtype=torch.float64),
                condition_estimate=torch.ones(1, dtype=torch.float64),
                residual_norm=torch.zeros(1, dtype=torch.float64),
                iterations=1,
                solver_name=self.name,
                message="second pass",
            )

    solver = RecordingSolver()
    result = solve_trust_region_subproblem(
        normal_matrix=torch.eye(2, dtype=torch.float64).unsqueeze(0).expand(3, -1, -1),
        gradient=torch.tensor([[-0.5, 0.0], [-2.0, 0.0], [-0.4, 0.0]], dtype=torch.float64),
        variable_scale=torch.ones((3, 2), dtype=torch.float64),
        radius=torch.ones(3, dtype=torch.float64),
        linear_solver=solver,
        max_damping_adjustments=2,
    )

    assert solver.retry_batch_sizes == [3, 1]
    assert solver.diagnostic_batch_sizes == [3]
    assert isinstance(result.success, torch.Tensor)
    assert torch.equal(result.success.cpu(), torch.tensor([True, True, True]))
    assert isinstance(result.projected, torch.Tensor)
    assert torch.equal(result.projected.cpu(), torch.tensor([False, False, False]))
    assert torch.allclose(result.step_norm, torch.tensor([0.5, 0.5, 0.4], dtype=torch.float64), atol=1e-10)


def test_trust_region_subproblem_skips_condition_estimate_on_intermediate_solves() -> None:
    class RecordingSolver:
        def __init__(self) -> None:
            self.inner = DenseDirectLinearSolver()
            self.name = self.inner.name
            self.flags: list[bool] = []

        def solve(self, linearization: Linearization) -> LinearSolveResult:
            self.flags.append(linearization.compute_condition_estimate)
            return self.inner.solve(linearization)

    solver = RecordingSolver()
    result = solve_trust_region_subproblem(
        normal_matrix=torch.eye(2, dtype=torch.float64).unsqueeze(0).expand(3, -1, -1),
        gradient=torch.tensor([[-0.5, 0.0], [-2.0, 0.0], [-0.4, 0.0]], dtype=torch.float64),
        variable_scale=torch.ones((3, 2), dtype=torch.float64),
        radius=torch.ones(3, dtype=torch.float64),
        linear_solver=solver,
        max_damping_adjustments=2,
    )

    assert solver.flags[0] is False
    assert any(flag is False for flag in solver.flags)
    assert any(flag is True for flag in solver.flags)
    assert result.linear_result is not None
    assert isinstance(result.linear_result.condition_estimate, torch.Tensor)
    assert torch.isfinite(result.linear_result.condition_estimate).all()
