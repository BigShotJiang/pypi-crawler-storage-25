"""Focused regression tests for the constrained SQP baseline."""

from __future__ import annotations

import pytest
import torch

from pytorch_nonlinear import Bounds, ConstrainedNLPProblem, DebugConfig, DiagnosisCode, EqualityConstraint, InequalityConstraint, SolveStatus, SolverConfig, TerminationReason, solve
from pytorch_nonlinear.api.config import ScalingConfig, ScalingMode
from pytorch_nonlinear.solvers.constrained_nlp import DenseConstrainedEvaluation, DenseConstrainedMultipliers, _exact_lagrangian_hessian, _kkt_residual, _recover_bound_multipliers, _selected_inequality_jacobian, _should_try_position_active_reduced_solve, _split_constraints, evaluate_dense_constrained_problem


def test_sqp_solves_dense_equality_constrained_problem() -> None:
    problem = ConstrainedNLPProblem(
        objective=lambda state, params: (state[0] - 1.0) ** 2 + (state[1] + 2.0) ** 2,
        constraints=(EqualityConstraint(lambda state, params: state[0] + state[1] - 1.0),),
    )

    result = solve(
        problem,
        x0=torch.tensor([0.0, 0.0], dtype=torch.float64),
        config=SolverConfig(method="sqp", max_iter=20, tol=1e-8),
    )

    assert result.success is True
    assert result.status is SolveStatus.CONVERGED
    assert result.termination in {TerminationReason.GRADIENT_TOL, TerminationReason.STEP_TOL}
    assert torch.allclose(result.x, torch.tensor([2.0, -1.0], dtype=torch.float64), atol=1e-5)
    assert result.constraint_violation is not None and result.constraint_violation <= 1e-6
    assert result.kkt_residual is not None and result.kkt_residual <= 1e-6


@pytest.mark.parametrize("hessian_model", ["bfgs", "exact"])
def test_sqp_tight_tolerance_equality_problem_converges_without_step_rejection(hessian_model: str) -> None:
    problem = ConstrainedNLPProblem(
        objective=lambda state, params: (state[0] - 2.0) ** 2 + (state[1] + 2.0) ** 2,
        constraints=(EqualityConstraint(lambda state, params: state[0] + state[1] - 1.0),),
    )

    result = solve(
        problem,
        x0=torch.tensor([0.0, 0.0], dtype=torch.float64),
        config=SolverConfig(method="sqp", max_iter=30, tol=1e-10, constrained_hessian_model=hessian_model),
    )

    assert result.success is True
    assert result.status is SolveStatus.CONVERGED
    assert result.termination in {TerminationReason.GRADIENT_TOL, TerminationReason.STEP_TOL}
    assert torch.allclose(result.x, torch.tensor([2.5, -1.5], dtype=torch.float64), atol=1e-7)
    assert result.constraint_violation is not None and result.constraint_violation <= 1e-12
    assert DiagnosisCode.STEP_REJECTED not in result.diagnosis


def test_sqp_respects_simple_bounds_and_reports_active_set() -> None:
    problem = ConstrainedNLPProblem(
        objective=lambda state, params: (state[0] - 2.0) ** 2,
        bounds=Bounds(upper=torch.tensor([1.5], dtype=torch.float64), name="box"),
    )

    result = solve(
        problem,
        x0=torch.tensor([0.0], dtype=torch.float64),
        config=SolverConfig(method="sqp", max_iter=20, tol=1e-8),
    )

    assert result.success is True
    assert torch.allclose(result.x, torch.tensor([1.5], dtype=torch.float64), atol=1e-6)
    assert result.active_set == ("box.upper[0]",)


def test_sqp_solves_dense_inequality_constrained_problem() -> None:
    problem = ConstrainedNLPProblem(
        objective=lambda state, params: (state[0] - 0.5) ** 2,
        constraints=(InequalityConstraint(lambda state, params: 1.0 - state[0]),),
    )

    result = solve(
        problem,
        x0=torch.tensor([0.0], dtype=torch.float64),
        config=SolverConfig(method="sqp", max_iter=20, tol=1e-8),
    )

    assert result.success is True
    assert result.status is SolveStatus.CONVERGED
    assert result.termination in {TerminationReason.GRADIENT_TOL, TerminationReason.STEP_TOL}
    assert torch.allclose(result.x, torch.tensor([1.0], dtype=torch.float64), atol=1e-5)
    assert result.constraint_violation is not None and result.constraint_violation <= 1e-6
    assert result.kkt_residual is not None and result.kkt_residual <= 1e-6


def test_sqp_solves_nonlinear_active_inequality_problem() -> None:
    problem = ConstrainedNLPProblem(
        objective=lambda state, params: (state[0] - 2.0) ** 2,
        constraints=(InequalityConstraint(lambda state, params: state[0] ** 2 - 1.0),),
    )

    result = solve(
        problem,
        x0=torch.tensor([0.2], dtype=torch.float64),
        config=SolverConfig(method="sqp", max_iter=40, tol=1e-8),
    )

    assert result.success is True
    assert result.status is SolveStatus.CONVERGED
    assert result.termination is TerminationReason.GRADIENT_TOL
    assert torch.allclose(result.x, torch.tensor([1.0], dtype=torch.float64), atol=1e-5)
    assert result.constraint_violation is not None and result.constraint_violation <= 1e-8
    assert result.kkt_residual is not None and result.kkt_residual <= 1e-8
    assert result.active_set == ("ineq[0]",)


def test_dense_evaluation_materializes_only_active_inequality_jacobian_rows() -> None:
    problem = ConstrainedNLPProblem(
        objective=lambda state, params: (state[0] - 1.0) ** 2 + (state[1] - 0.5) ** 2,
        constraints=(
            EqualityConstraint(lambda state, params: state[0] + state[1] - 1.0),
            InequalityConstraint(lambda state, params: torch.stack((state[0] - 0.5, state[1] - 2.0))),
        ),
    )

    x = torch.tensor([0.5, 0.5], dtype=torch.float64)
    evaluation = evaluate_dense_constrained_problem(
        problem,
        x,
        None,
        original_shape=x.shape,
        equality_constraints=(problem.constraints[0],),
        inequality_constraints=(problem.constraints[1],),
        bounds=problem.bounds,
        lower=None,
        upper=None,
        previous_inequality_multipliers=None,
        tolerance=1e-8,
    )

    assert torch.equal(evaluation.inequality_jacobian_mask, torch.tensor([True, False]))
    assert evaluation.inequality_jacobian.shape == (1, 2)
    assert torch.allclose(evaluation.inequality_jacobian, torch.tensor([[1.0, 0.0]], dtype=torch.float64))


def test_selected_inequality_jacobian_reuses_cached_subset_rows() -> None:
    evaluation = DenseConstrainedEvaluation(
        x=torch.tensor([0.0, 0.0], dtype=torch.float64),
        objective_value=torch.tensor(0.0, dtype=torch.float64),
        objective_gradient=torch.tensor([0.0, 0.0], dtype=torch.float64),
        equality_values=torch.zeros(0, dtype=torch.float64),
        equality_jacobian=torch.zeros((0, 2), dtype=torch.float64),
        inequality_values=torch.tensor([1.0, 0.0, -1.0], dtype=torch.float64),
        inequality_jacobian=torch.tensor([[1.0, 0.0], [0.0, 1.0]], dtype=torch.float64),
        constraint_violation=torch.tensor(0.0, dtype=torch.float64),
        active_set=(),
        inequality_jacobian_mask=torch.tensor([True, True, False]),
        inequality_jacobian_builder=lambda active_mask: (_ for _ in ()).throw(AssertionError("builder should not be called")),
    )

    selected = _selected_inequality_jacobian(evaluation, torch.tensor([False, True, False]))

    assert torch.allclose(selected, torch.tensor([[0.0, 1.0]], dtype=torch.float64))


def test_sqp_direct_inequality_path_preserves_cleaner_active_set_than_public_slack_reduction() -> None:
    direct_problem = ConstrainedNLPProblem(
        objective=lambda state, params: (state[0] - 0.5) ** 2,
        constraints=(InequalityConstraint(lambda state, params: 1.0 - state[0]),),
    )
    slack_problem = ConstrainedNLPProblem(
        objective=lambda state, params: (state[0] - 0.5) ** 2 + 1e-6 * state[1] ** 2,
        constraints=(EqualityConstraint(lambda state, params: 1.0 - state[0] + state[1]),),
        bounds=Bounds(lower=torch.tensor([-10.0, 0.0], dtype=torch.float64), name="slack"),
    )

    direct_result = solve(
        direct_problem,
        x0=torch.tensor([0.0], dtype=torch.float64),
        config=SolverConfig(method="sqp", max_iter=40, tol=1e-8),
    )
    slack_result = solve(
        slack_problem,
        x0=torch.tensor([0.0, 1.0], dtype=torch.float64),
        config=SolverConfig(method="sqp", max_iter=40, tol=1e-8),
    )

    assert direct_result.success is True
    assert slack_result.success is True
    assert torch.allclose(direct_result.x, torch.tensor([1.0], dtype=torch.float64), atol=1e-6)
    assert torch.allclose(slack_result.x, torch.tensor([1.0, 0.0], dtype=torch.float64), atol=1e-6)
    assert direct_result.active_set == ("ineq[0]",)
    assert slack_result.active_set == ("slack.lower[1]",)


def test_sqp_auto_scaling_surfaces_metadata_for_badly_scaled_inequality_problem() -> None:
    problem = ConstrainedNLPProblem(
        objective=lambda state, params: (state[0] - 1e-6) ** 2 + (state[1] - 1.0) ** 2,
        constraints=(InequalityConstraint(lambda state, params: 1e6 * state[0] + state[1] - 2.0),),
    )

    result = solve(
        problem,
        x0=torch.tensor([0.0, 0.0], dtype=torch.float64),
        config=SolverConfig(
            method="sqp",
            max_iter=40,
            tol=1e-8,
            scaling=ScalingConfig(variable_mode=ScalingMode.AUTO, residual_mode=ScalingMode.AUTO),
        ),
    )

    assert result.success is True
    assert DiagnosisCode.POOR_SCALING in result.diagnosis
    assert "constrained_scaling" in result.reproducibility
    metadata = result.reproducibility["constrained_scaling"]
    assert metadata["variable_mode"] == "auto"
    assert metadata["constraint_mode"] == "auto"
    assert metadata["variable_spread"] is not None and metadata["variable_spread"] > 1e4


def test_exact_lagrangian_hessian_matches_autograd_functional_hessian() -> None:
    problem = ConstrainedNLPProblem(
        objective=lambda state, params: (state[0] - 1.0) ** 4 + state[0] * state[1] + (state[1] + 0.5) ** 2,
        constraints=(
            EqualityConstraint(lambda state, params: state[0] ** 2 + state[1] - 1.0),
            InequalityConstraint(lambda state, params: torch.stack((state[0] + 2.0 * state[1] - 0.25, state[0] - 10.0))),
        ),
    )
    x = torch.tensor([0.4, 0.2], dtype=torch.float64)
    equality_constraints, inequality_constraints = _split_constraints(problem)
    multipliers = DenseConstrainedMultipliers(
        equality=torch.tensor([0.7], dtype=torch.float64),
        inequality=torch.tensor([1.1, 0.0], dtype=torch.float64),
    )

    hessian = _exact_lagrangian_hessian(
        problem,
        x,
        None,
        original_shape=x.shape,
        equality_constraints=equality_constraints,
        inequality_constraints=inequality_constraints,
        multipliers=multipliers,
    )

    def lagrangian(flat_x: torch.Tensor) -> torch.Tensor:
        state = flat_x
        objective = (state[0] - 1.0) ** 4 + state[0] * state[1] + (state[1] + 0.5) ** 2
        equality_term = multipliers.equality[0] * (state[0] ** 2 + state[1] - 1.0)
        inequality_term = multipliers.inequality[0] * (state[0] + 2.0 * state[1] - 0.25)
        return objective + equality_term + inequality_term

    expected = torch.autograd.functional.hessian(lagrangian, x.detach())

    assert torch.allclose(hessian, expected, atol=1e-10, rtol=1e-10)


def test_exact_lagrangian_hessian_uses_torch_func_backend(monkeypatch: pytest.MonkeyPatch) -> None:
    problem = ConstrainedNLPProblem(
        objective=lambda state, params: (state[0] - 1.0) ** 2 + (state[1] + 0.5) ** 2,
        constraints=(EqualityConstraint(lambda state, params: state[0] + state[1] - 1.0),),
    )
    x = torch.tensor([0.4, 0.2], dtype=torch.float64)
    equality_constraints, inequality_constraints = _split_constraints(problem)
    multipliers = DenseConstrainedMultipliers(
        equality=torch.tensor([0.7], dtype=torch.float64),
        inequality=torch.zeros(0, dtype=torch.float64),
    )
    nonsymmetric_hessian = torch.tensor([[2.0, 3.0], [1.0, 5.0]], dtype=torch.float64)

    def fail_legacy_backend(*args, **kwargs):
        raise AssertionError("legacy autograd.functional.hessian backend should not be used")

    def fake_func_hessian(function):
        def wrapped(flat_x: torch.Tensor) -> torch.Tensor:
            _ = function(flat_x)
            return nonsymmetric_hessian

        return wrapped

    monkeypatch.setattr(torch.autograd.functional, "hessian", fail_legacy_backend)
    monkeypatch.setattr(torch.func, "hessian", fake_func_hessian)

    hessian = _exact_lagrangian_hessian(
        problem,
        x,
        None,
        original_shape=x.shape,
        equality_constraints=equality_constraints,
        inequality_constraints=inequality_constraints,
        multipliers=multipliers,
    )

    assert torch.allclose(hessian, torch.tensor([[2.0, 2.0], [2.0, 5.0]], dtype=torch.float64))


def test_sqp_keeps_inactive_inequality_inactive_when_optimum_is_feasible() -> None:
    problem = ConstrainedNLPProblem(
        objective=lambda state, params: (state[0] - 0.5) ** 2,
        constraints=(InequalityConstraint(lambda state, params: state[0] - 1.0),),
    )

    result = solve(
        problem,
        x0=torch.tensor([-1.0], dtype=torch.float64),
        config=SolverConfig(method="sqp", max_iter=20, tol=1e-8),
    )

    assert result.success is True
    assert result.status is SolveStatus.CONVERGED
    assert torch.allclose(result.x, torch.tensor([0.5], dtype=torch.float64), atol=1e-5)
    assert result.active_set == ()
    assert result.constraint_violation is not None and result.constraint_violation <= 1e-6


def test_sqp_solves_mixed_equality_inequality_and_bounds_problem() -> None:
    problem = ConstrainedNLPProblem(
        objective=lambda state, params: (state[0] - 2.0) ** 2 + (state[1] + 0.4) ** 2,
        constraints=(
            EqualityConstraint(lambda state, params: state[0] + state[1] - 1.0),
            InequalityConstraint(lambda state, params: state[0] - 1.2),
        ),
        bounds=Bounds(lower=torch.tensor([-10.0, -0.2], dtype=torch.float64), name="box"),
    )

    result = solve(
        problem,
        x0=torch.tensor([0.0, 1.0], dtype=torch.float64),
        config=SolverConfig(method="sqp", max_iter=40, tol=1e-8),
    )

    assert result.success is True
    assert result.status is SolveStatus.CONVERGED
    assert torch.allclose(result.x, torch.tensor([1.2, -0.2], dtype=torch.float64), atol=1e-5)
    assert result.constraint_violation is not None and result.constraint_violation <= 1e-6
    assert result.kkt_residual is not None and result.kkt_residual <= 1e-6
    assert "ineq[0]" in result.active_set
    assert "box.lower[1]" in result.active_set


def test_sqp_handles_poor_start_for_mixed_equality_and_inequality_problem() -> None:
    problem = ConstrainedNLPProblem(
        objective=lambda state, params: (state[0] - 0.1) ** 2 + (state[1] - 0.1) ** 2,
        constraints=(
            EqualityConstraint(lambda state, params: state[0] + state[1] - 1.0),
            InequalityConstraint(lambda state, params: 0.8 - state[0]),
        ),
    )

    result = solve(
        problem,
        x0=torch.tensor([-2.0, 3.0], dtype=torch.float64),
        config=SolverConfig(method="sqp", max_iter=40, tol=1e-8),
    )

    assert result.success is True
    assert result.status is SolveStatus.CONVERGED
    assert result.termination is TerminationReason.GRADIENT_TOL
    assert torch.allclose(result.x, torch.tensor([0.8, 0.2], dtype=torch.float64), atol=1e-5)
    assert result.constraint_violation is not None and result.constraint_violation <= 1e-8
    assert result.kkt_residual is not None and result.kkt_residual <= 1e-8
    assert result.active_set == ("ineq[0]",)


def test_sqp_mixed_near_active_inactive_inequality_stays_out_of_active_set() -> None:
    problem = ConstrainedNLPProblem(
        objective=lambda state, params: (state[0] - 0.9) ** 2 + (state[1] + 0.4) ** 2,
        constraints=(
            EqualityConstraint(lambda state, params: state[0] + state[1] - 0.5),
            InequalityConstraint(lambda state, params: state[0] - 0.9000001),
        ),
    )

    result = solve(
        problem,
        x0=torch.tensor([0.0, 0.5], dtype=torch.float64),
        config=SolverConfig(method="sqp", max_iter=40, tol=1e-6),
    )

    assert result.success is True
    assert result.status is SolveStatus.CONVERGED
    assert torch.allclose(result.x, torch.tensor([0.9, -0.4], dtype=torch.float64), atol=1e-6)
    assert result.active_set == ()
    assert result.constraint_violation is not None and result.constraint_violation <= 1e-8
    assert result.kkt_residual is not None and result.kkt_residual <= 1e-6


def test_sqp_mixed_max_iter_does_not_imply_step_rejection() -> None:
    problem = ConstrainedNLPProblem(
        objective=lambda state, params: (state[0] - 0.1) ** 4 + (state[1] - 0.1) ** 4,
        constraints=(
            EqualityConstraint(lambda state, params: state[0] + state[1] - 1.0),
            InequalityConstraint(lambda state, params: 0.8 - state[0]),
        ),
    )

    result = solve(
        problem,
        x0=torch.tensor([-2.0, 3.0], dtype=torch.float64),
        config=SolverConfig(method="sqp", max_iter=1, tol=1e-16, constrained_hessian_model="bfgs"),
    )

    assert result.success is False
    assert result.status is SolveStatus.MAX_ITER_REACHED
    assert result.termination is TerminationReason.MAX_ITER
    assert DiagnosisCode.STEP_REJECTED not in result.diagnosis
    assert result.history
    assert result.history[-1].accepted is True
    assert all(trial.accepted for trial in result.history[-1].trials)
    assert result.active_set == ("ineq[0]",)


def test_sqp_reports_structured_failure_for_mixed_degenerate_inequality_model() -> None:
    problem = ConstrainedNLPProblem(
        objective=lambda state, params: state[0] ** 2 + state[1] ** 2,
        constraints=(
            EqualityConstraint(lambda state, params: state[0] + state[1] - 1.0),
            InequalityConstraint(lambda state, params: state[0] - 0.75),
            InequalityConstraint(lambda state, params: 1.1 - state[0] - state[1]),
        ),
        bounds=Bounds(lower=torch.tensor([0.0, -1.0], dtype=torch.float64), name="box"),
    )

    result = solve(
        problem,
        x0=torch.tensor([0.8, 0.2], dtype=torch.float64),
        config=SolverConfig(method="sqp", max_iter=20, tol=1e-8),
    )

    assert result.success is False
    assert result.status is SolveStatus.FAILED
    assert result.termination is TerminationReason.NUMERICAL_FAILURE
    assert result.constraint_violation is not None and result.constraint_violation >= 0.1
    assert result.kkt_residual is not None and result.kkt_residual >= 1.0
    assert result.active_set == ("ineq[0]", "ineq[1]")
    assert DiagnosisCode.RANK_DEFICIENT_JACOBIAN in result.diagnosis
    assert DiagnosisCode.ILL_CONDITIONED_SYSTEM in result.diagnosis
    assert DiagnosisCode.UNCERTIFIED_KKT_STEP in result.diagnosis
    assert "linear solve failed" in result.message.lower()


def test_sqp_bfgs_handles_infeasible_start_near_active_bound() -> None:
    problem = ConstrainedNLPProblem(
        objective=lambda state, params: (state[0] - 1.7) ** 2 + (state[1] + 0.4) ** 2,
        constraints=(EqualityConstraint(lambda state, params: state[0] + state[1] - 1.0),),
        bounds=Bounds(
            lower=torch.tensor([-1.0, -2.0], dtype=torch.float64),
            upper=torch.tensor([1.5, 1.5], dtype=torch.float64),
            name="box",
        ),
    )

    result = solve(
        problem,
        x0=torch.tensor([0.5, -0.5], dtype=torch.float64),
        config=SolverConfig(method="sqp", max_iter=40, tol=1e-10, constrained_hessian_model="bfgs"),
    )

    assert result.success is True
    assert result.status is SolveStatus.CONVERGED
    assert result.termination in {TerminationReason.GRADIENT_TOL, TerminationReason.STEP_TOL}
    assert torch.allclose(result.x, torch.tensor([1.5, -0.5], dtype=torch.float64), atol=1e-5)
    assert result.constraint_violation is not None and result.constraint_violation <= 1e-8
    assert result.kkt_residual is not None and result.kkt_residual <= 1e-6
    assert DiagnosisCode.UNCERTIFIED_KKT_STEP not in result.diagnosis


def test_sqp_respects_lower_bound_and_reports_active_set() -> None:
    problem = ConstrainedNLPProblem(
        objective=lambda state, params: (state[0] + 2.0) ** 2,
        bounds=Bounds(lower=torch.tensor([-1.5], dtype=torch.float64), name="box"),
    )

    result = solve(
        problem,
        x0=torch.tensor([0.0], dtype=torch.float64),
        config=SolverConfig(method="sqp", max_iter=20, tol=1e-8),
    )

    assert result.success is True
    assert torch.allclose(result.x, torch.tensor([-1.5], dtype=torch.float64), atol=1e-6)
    assert result.kkt_residual is not None and result.kkt_residual <= 1e-8
    assert result.active_set == ("box.lower[0]",)


def test_sqp_solves_mixed_equality_and_bounds_problem() -> None:
    problem = ConstrainedNLPProblem(
        objective=lambda state, params: (state[0] - 2.0) ** 2 + (state[1] + 2.0) ** 2,
        constraints=(EqualityConstraint(lambda state, params: state[0] + state[1] - 1.0),),
        bounds=Bounds(upper=torch.tensor([1.5, 10.0], dtype=torch.float64), name="box"),
    )

    result = solve(
        problem,
        x0=torch.tensor([0.0, 0.0], dtype=torch.float64),
        config=SolverConfig(method="sqp", max_iter=30, tol=1e-8),
    )

    assert result.success is True
    assert result.status is SolveStatus.CONVERGED
    assert torch.allclose(result.x, torch.tensor([1.5, -0.5], dtype=torch.float64), atol=1e-5)
    assert result.constraint_violation is not None and result.constraint_violation <= 1e-6
    assert result.kkt_residual is not None and result.kkt_residual <= 1e-6
    assert "box.upper[0]" in result.active_set


def test_sqp_keeps_constraints_inactive_when_unconstrained_optimum_is_feasible() -> None:
    problem = ConstrainedNLPProblem(
        objective=lambda state, params: (state[0] - 1.0) ** 2 + (state[1] - 1.0) ** 2,
        constraints=(EqualityConstraint(lambda state, params: state[0] - state[1]),),
        bounds=Bounds(lower=torch.tensor([-2.0, -2.0], dtype=torch.float64), upper=torch.tensor([2.0, 2.0], dtype=torch.float64), name="box"),
    )

    result = solve(
        problem,
        x0=torch.tensor([2.0, -1.0], dtype=torch.float64),
        config=SolverConfig(method="sqp", max_iter=20, tol=1e-8),
    )

    assert result.success is True
    assert result.status is SolveStatus.CONVERGED
    assert torch.allclose(result.x, torch.tensor([1.0, 1.0], dtype=torch.float64), atol=1e-5)
    assert result.active_set == ()
    assert result.constraint_violation is not None and result.constraint_violation <= 1e-6


def test_sqp_max_iter_does_not_imply_step_rejection() -> None:
    problem = ConstrainedNLPProblem(
        objective=lambda state, params: (state[0] - 1.0) ** 4 + (state[1] - 1.0) ** 4,
        constraints=(EqualityConstraint(lambda state, params: state[0] - state[1]),),
    )

    result = solve(
        problem,
        x0=torch.tensor([3.0, -1.0], dtype=torch.float64),
        config=SolverConfig(method="sqp", max_iter=1, tol=1e-16, constrained_hessian_model="bfgs"),
    )

    assert result.success is False
    assert result.status is SolveStatus.MAX_ITER_REACHED
    assert result.termination is TerminationReason.MAX_ITER
    assert DiagnosisCode.STEP_REJECTED not in result.diagnosis
    assert result.history
    assert result.history[-1].accepted is True
    assert all(trial.accepted for trial in result.history[-1].trials)


def test_sqp_reports_structured_failure_for_infeasible_equality_and_bounds() -> None:
    problem = ConstrainedNLPProblem(
        objective=lambda state, params: state[0] ** 2,
        constraints=(EqualityConstraint(lambda state, params: state[0] - 1.0),),
        bounds=Bounds(upper=torch.tensor([0.0], dtype=torch.float64), name="box"),
    )

    result = solve(
        problem,
        x0=torch.tensor([0.0], dtype=torch.float64),
        config=SolverConfig(method="sqp", max_iter=8, tol=1e-8),
    )

    assert result.success is False
    assert result.status is SolveStatus.FAILED
    assert result.termination is TerminationReason.NUMERICAL_FAILURE
    assert DiagnosisCode.STEP_REJECTED in result.diagnosis
    assert result.constraint_violation is not None and result.constraint_violation > 0.5
    assert "rejected" in result.message.lower()
    assert result.history
    assert result.history[-1].accepted is False


def test_sqp_reports_structured_failure_for_degenerate_infeasible_inequalities() -> None:
    problem = ConstrainedNLPProblem(
        objective=lambda state, params: state[0] ** 2,
        constraints=(
            InequalityConstraint(lambda state, params: state[0]),
            InequalityConstraint(lambda state, params: 1.0 - state[0]),
        ),
    )

    result = solve(
        problem,
        x0=torch.tensor([0.25], dtype=torch.float64),
        config=SolverConfig(method="sqp", max_iter=20, tol=1e-8),
    )

    assert result.success is False
    assert result.status is SolveStatus.FAILED
    assert result.termination is TerminationReason.NUMERICAL_FAILURE
    assert result.constraint_violation is not None and result.constraint_violation >= 0.75
    assert result.kkt_residual is not None and result.kkt_residual >= 0.75
    assert result.active_set == ("ineq[0]", "ineq[1]")
    assert DiagnosisCode.RANK_DEFICIENT_JACOBIAN in result.diagnosis
    assert DiagnosisCode.ILL_CONDITIONED_SYSTEM in result.diagnosis
    assert DiagnosisCode.UNCERTIFIED_KKT_STEP in result.diagnosis
    assert "linear solve failed" in result.message.lower()


def test_sqp_handles_redundant_equality_constraints_with_diagnosis() -> None:
    problem = ConstrainedNLPProblem(
        objective=lambda state, params: (state[0] - 1.0) ** 2 + (state[1] - 1.0) ** 2,
        constraints=(
            EqualityConstraint(lambda state, params: state[0] - state[1]),
            EqualityConstraint(lambda state, params: 2.0 * (state[0] - state[1])),
        ),
    )

    result = solve(
        problem,
        x0=torch.tensor([3.0, -1.0], dtype=torch.float64),
        config=SolverConfig(method="sqp", max_iter=30, tol=1e-8),
    )

    assert result.success is True
    assert result.status is SolveStatus.CONVERGED
    assert torch.allclose(result.x, torch.tensor([1.0, 1.0], dtype=torch.float64), atol=1e-5)
    assert result.constraint_violation is not None and result.constraint_violation <= 1e-6
    assert result.kkt_residual is not None and result.kkt_residual <= 1e-6
    assert DiagnosisCode.RANK_DEFICIENT_JACOBIAN in result.diagnosis
    assert DiagnosisCode.ILL_CONDITIONED_SYSTEM in result.diagnosis
    assert DiagnosisCode.SKIPPED_CURVATURE_UPDATE in result.diagnosis


def test_sqp_fails_closed_on_uncertified_singular_kkt_fallback() -> None:
    problem = ConstrainedNLPProblem(
        objective=lambda state, params: state[0] ** 2,
        constraints=(
            EqualityConstraint(lambda state, params: state[0] - 1.0),
            EqualityConstraint(lambda state, params: 2.0 * state[0] - 1.0),
        ),
    )

    result = solve(
        problem,
        x0=torch.tensor([0.0], dtype=torch.float64),
        config=SolverConfig(method="sqp", max_iter=10, tol=1e-8),
    )

    assert result.success is False
    assert result.status is SolveStatus.FAILED
    assert result.termination is TerminationReason.NUMERICAL_FAILURE
    assert DiagnosisCode.UNCERTIFIED_KKT_STEP in result.diagnosis
    assert DiagnosisCode.RANK_DEFICIENT_JACOBIAN in result.diagnosis
    assert result.linear_residual_norm is not None and result.linear_residual_norm > 1e-8


def test_sqp_handles_fixed_variable_bounds_consistently() -> None:
    problem = ConstrainedNLPProblem(
        objective=lambda state, params: (state[0] - 1.0) ** 2 + (state[1] - 2.0) ** 2,
        constraints=(EqualityConstraint(lambda state, params: state[0] + state[1] - 2.0),),
        bounds=Bounds(
            lower=torch.tensor([0.5, 1.5], dtype=torch.float64),
            upper=torch.tensor([0.5, 1.5], dtype=torch.float64),
            name="fix",
        ),
    )

    result = solve(
        problem,
        x0=torch.tensor([0.0, 0.0], dtype=torch.float64),
        config=SolverConfig(method="sqp", max_iter=20, tol=1e-8),
    )

    assert result.success is True
    assert result.status is SolveStatus.CONVERGED
    assert result.termination is TerminationReason.GRADIENT_TOL
    assert result.num_iter == 0
    assert torch.allclose(result.x, torch.tensor([0.5, 1.5], dtype=torch.float64), atol=1e-8)
    assert result.constraint_violation == 0.0
    assert result.kkt_residual == 0.0
    assert set(result.active_set) == {"fix.lower[0]", "fix.lower[1]", "fix.upper[0]", "fix.upper[1]"}


def test_sqp_can_skip_linear_condition_estimates_when_history_capture_is_disabled() -> None:
    problem = ConstrainedNLPProblem(
        objective=lambda state, params: (state[0] - 2.0) ** 2 + (state[1] + 2.0) ** 2,
        constraints=(EqualityConstraint(lambda state, params: state[0] + state[1] - 1.0),),
        bounds=Bounds(upper=torch.tensor([1.5, 10.0], dtype=torch.float64), name="box"),
    )

    result = solve(
        problem,
        x0=torch.tensor([0.0, 0.0], dtype=torch.float64),
        config=SolverConfig(
            method="sqp",
            max_iter=30,
            tol=1e-8,
            debug=DebugConfig(capture_history=False),
        ),
    )

    assert result.success is True
    assert result.status is SolveStatus.CONVERGED
    assert torch.allclose(result.x, torch.tensor([1.5, -0.5], dtype=torch.float64), atol=1e-5)
    assert result.linear_condition_estimate is None


def test_sqp_reports_linear_condition_estimate_when_history_capture_is_enabled() -> None:
    problem = ConstrainedNLPProblem(
        objective=lambda state, params: (state[0] - 2.0) ** 2 + (state[1] + 2.0) ** 2,
        constraints=(EqualityConstraint(lambda state, params: state[0] + state[1] - 1.0),),
        bounds=Bounds(upper=torch.tensor([1.5, 10.0], dtype=torch.float64), name="box"),
    )

    result = solve(
        problem,
        x0=torch.tensor([0.0, 0.0], dtype=torch.float64),
        config=SolverConfig(
            method="sqp",
            max_iter=30,
            tol=1e-8,
            debug=DebugConfig(capture_history=True),
        ),
    )

    assert result.success is True
    assert result.status is SolveStatus.CONVERGED
    assert torch.allclose(result.x, torch.tensor([1.5, -0.5], dtype=torch.float64), atol=1e-5)
    assert result.linear_condition_estimate is not None
    assert result.history
    assert result.history[-1].linear_condition_estimate is not None


def test_explicit_bound_multiplier_recovery_matches_analytic_kkt_cases() -> None:
    lower_multipliers, upper_multipliers, dual_residual = _recover_bound_multipliers(
        x=torch.tensor([-1.5, 1.5, 0.5], dtype=torch.float64),
        stationarity=torch.tensor([1.0, -2.0, 0.0], dtype=torch.float64),
        lower=torch.tensor([-1.5, -10.0, -10.0], dtype=torch.float64),
        upper=torch.tensor([10.0, 1.5, 10.0], dtype=torch.float64),
        tolerance=1e-8,
    )

    assert torch.allclose(lower_multipliers, torch.tensor([1.0, 0.0, 0.0], dtype=torch.float64))
    assert torch.allclose(upper_multipliers, torch.tensor([0.0, 2.0, 0.0], dtype=torch.float64))
    assert torch.allclose(dual_residual, torch.zeros(3, dtype=torch.float64))


def test_explicit_kkt_residual_rejects_wrong_sign_stationarity_at_active_bound() -> None:
    evaluation = DenseConstrainedEvaluation(
        x=torch.tensor([1.5], dtype=torch.float64),
        objective_value=torch.tensor(0.0, dtype=torch.float64),
        objective_gradient=torch.tensor([1.0], dtype=torch.float64),
        equality_values=torch.zeros(0, dtype=torch.float64),
        equality_jacobian=torch.zeros((0, 1), dtype=torch.float64),
        inequality_values=torch.zeros(0, dtype=torch.float64),
        inequality_jacobian=torch.zeros((0, 1), dtype=torch.float64),
        constraint_violation=torch.tensor(0.0, dtype=torch.float64),
        active_set=("box.upper[0]",),
    )

    residual = _kkt_residual(
        evaluation,
        multipliers=DenseConstrainedMultipliers(
            equality=torch.zeros(0, dtype=torch.float64),
            inequality=torch.zeros(0, dtype=torch.float64),
        ),
        lower=None,
        upper=torch.tensor([1.5], dtype=torch.float64),
        tolerance=1e-8,
    )

    assert float(residual.item()) >= 1.0


def test_explicit_kkt_residual_accepts_fixed_variable_dual_decomposition() -> None:
    evaluation = DenseConstrainedEvaluation(
        x=torch.tensor([0.5], dtype=torch.float64),
        objective_value=torch.tensor(0.0, dtype=torch.float64),
        objective_gradient=torch.tensor([3.0], dtype=torch.float64),
        equality_values=torch.zeros(0, dtype=torch.float64),
        equality_jacobian=torch.zeros((0, 1), dtype=torch.float64),
        inequality_values=torch.zeros(0, dtype=torch.float64),
        inequality_jacobian=torch.zeros((0, 1), dtype=torch.float64),
        constraint_violation=torch.tensor(0.0, dtype=torch.float64),
        active_set=("fix.lower[0]", "fix.upper[0]"),
    )

    residual = _kkt_residual(
        evaluation,
        multipliers=DenseConstrainedMultipliers(
            equality=torch.zeros(0, dtype=torch.float64),
            inequality=torch.zeros(0, dtype=torch.float64),
        ),
        lower=torch.tensor([0.5], dtype=torch.float64),
        upper=torch.tensor([0.5], dtype=torch.float64),
        tolerance=1e-8,
    )

    assert residual == 0.0


def test_position_active_reduced_solve_gate_requires_dual_feasible_active_bounds() -> None:
    evaluation = DenseConstrainedEvaluation(
        x=torch.tensor([1.5, -0.5], dtype=torch.float64),
        objective_value=torch.tensor(0.0, dtype=torch.float64),
        objective_gradient=torch.tensor([-2.0, 0.0], dtype=torch.float64),
        equality_values=torch.tensor([0.0], dtype=torch.float64),
        equality_jacobian=torch.tensor([[1.0, 1.0]], dtype=torch.float64),
        inequality_values=torch.zeros(0, dtype=torch.float64),
        inequality_jacobian=torch.zeros((0, 2), dtype=torch.float64),
        constraint_violation=torch.tensor(0.0, dtype=torch.float64),
        active_set=("box.upper[0]",),
    )

    assert _should_try_position_active_reduced_solve(
        evaluation,
        multipliers=DenseConstrainedMultipliers(
            equality=torch.tensor([1.0], dtype=torch.float64),
            inequality=torch.zeros(0, dtype=torch.float64),
        ),
        lower=None,
        upper=torch.tensor([1.5, 10.0], dtype=torch.float64),
        tolerance=1e-8,
    ) is True

    assert _should_try_position_active_reduced_solve(
        evaluation,
        multipliers=DenseConstrainedMultipliers(
            equality=torch.tensor([3.0], dtype=torch.float64),
            inequality=torch.zeros(0, dtype=torch.float64),
        ),
        lower=None,
        upper=torch.tensor([1.5, 10.0], dtype=torch.float64),
        tolerance=1e-8,
    ) is False


def test_sqp_near_active_bounds_do_not_mark_inactive_solution_as_active() -> None:
    problem = ConstrainedNLPProblem(
        objective=lambda state, params: (state[0] - 0.9) ** 2 + (state[1] + 0.4) ** 2,
        constraints=(EqualityConstraint(lambda state, params: state[0] + state[1] - 0.5),),
        bounds=Bounds(
            lower=torch.tensor([-1.0, -1.0], dtype=torch.float64),
            upper=torch.tensor([0.9001, 1.0], dtype=torch.float64),
            name="box",
        ),
    )

    result = solve(
        problem,
        x0=torch.tensor([0.0, 0.5], dtype=torch.float64),
        config=SolverConfig(method="sqp", max_iter=30, tol=1e-6),
    )

    assert result.success is True
    assert result.status is SolveStatus.CONVERGED
    assert torch.allclose(result.x, torch.tensor([0.9, -0.4], dtype=torch.float64), atol=1e-5)
    assert result.active_set == ()
    assert result.constraint_violation is not None and result.constraint_violation <= 1e-8
    assert result.kkt_residual is not None and result.kkt_residual <= 1e-6


def test_exact_hessian_and_bfgs_modes_agree_on_small_problem() -> None:
    problem = ConstrainedNLPProblem(
        objective=lambda state, params: (state[0] - 1.0) ** 2 + (state[1] - 1.0) ** 2,
        constraints=(EqualityConstraint(lambda state, params: state[0] - state[1]),),
    )

    bfgs_result = solve(
        problem,
        x0=torch.tensor([3.0, -1.0], dtype=torch.float64),
        config=SolverConfig(method="sqp", max_iter=20, tol=1e-8, constrained_hessian_model="bfgs"),
    )
    exact_result = solve(
        problem,
        x0=torch.tensor([3.0, -1.0], dtype=torch.float64),
        config=SolverConfig(method="sqp", max_iter=20, tol=1e-8, constrained_hessian_model="exact"),
    )

    assert bfgs_result.success is True
    assert exact_result.success is True
    assert torch.allclose(bfgs_result.x, exact_result.x, atol=1e-5)
    assert bfgs_result.reproducibility["constrained_hessian_model"] == "bfgs"
    assert exact_result.reproducibility["constrained_hessian_model"] == "exact"


def test_sqp_large_dense_cpu_oriented_problem_does_not_require_exact_hessian() -> None:
    target = torch.linspace(-0.5, 0.5, 16, dtype=torch.float64)
    problem = ConstrainedNLPProblem(objective=lambda state, params: torch.sum((state - params["target"]) ** 2))

    result = solve(
        problem,
        x0=torch.zeros(16, dtype=torch.float64),
        params={"target": target},
        config=SolverConfig(method="sqp", max_iter=25, tol=1e-8, constrained_hessian_model="bfgs", device="cpu"),
    )

    assert result.success is True
    assert torch.allclose(result.x, target, atol=1e-6)
    assert result.reproducibility["constrained_hessian_model"] == "bfgs"