"""Pressure tests for M6 shared-structure batch least-squares execution.

These tests treat the implementation as a black box and verify every
important correctness guarantee made by the M6 architecture:

  1. Numerical correctness  – batched == stacked single solves, exact solutions
  2. Partial-failure isolation  – failed instances do not corrupt successes
  3. Per-instance history fidelity  – lengths, ordering, fields, num_iter
  4. Gradient/step norms at convergence  – tolerance guarantees hold
  5. Device consistency  – explicit device request propagates everywhere
  6. State-shape variety  – scalar, vector, matrix states all work
  7. Parameter-structure variety  – None / flat / nested / shared / per-instance
  8. All three solver methods  – gauss_newton, lm, trust_region
  9. Large-batch correctness  – batch_size=32, complex problem
 10. Scaling in batched mode  – auto and manual scaling per-instance metadata
"""

from __future__ import annotations

import math
from typing import Any

import pytest
import torch

from pytorch_nonlinear import (
    BatchMode,
    DiagnosisCode,
    NonlinearLeastSquaresProblem,
    ScalingConfig,
    ScalingMode,
    SharedStructureBatchResult,
    SolveStatus,
    SolverConfig,
    TerminationReason,
    solve,
)

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_ALL_METHODS = ("gauss_newton", "lm", "trust_region")
_ROBUST_METHODS = ("lm", "trust_region")


def _linear_problem(n: int = 3) -> tuple[NonlinearLeastSquaresProblem, torch.Tensor]:
    """Returns an n×n linear LS problem with identity Jacobian and its exact solution."""
    target = torch.arange(1.0, n + 1, dtype=torch.float64)
    problem = NonlinearLeastSquaresProblem(residual=lambda state, params: state - params["target"])
    return problem, target


def _rosenbrock_problem() -> NonlinearLeastSquaresProblem:
    """Standard 2-parameter Rosenbrock as a 2-residual least-squares problem."""
    return NonlinearLeastSquaresProblem(
        residual=lambda state, _params: torch.stack((
            10.0 * (state[1] - state[0] ** 2),
            1.0 - state[0],
        ))
    )


def _exp_problem() -> tuple[NonlinearLeastSquaresProblem, float]:
    """exp(x) == target; exact solution is log(target)."""
    problem = NonlinearLeastSquaresProblem(residual=lambda state, params: torch.exp(state) - params["target"])
    return problem, math.log(2.0)


# ---------------------------------------------------------------------------
# 1. NUMERICAL CORRECTNESS
# ---------------------------------------------------------------------------

class TestNumericalCorrectness:
    """Batched solves must produce the same numerical answers as stacked single solves."""

    @pytest.mark.parametrize("method", _ALL_METHODS)
    def test_linear_problem_all_methods_converge_to_exact_solution(self, method: str) -> None:
        """Every method must find the exact solution for a simple linear problem."""
        problem, target = _linear_problem(n=4)
        x0_batch = torch.zeros((5, 4), dtype=torch.float64)
        params_batch = {"target": target.unsqueeze(0).expand(5, -1).clone()}

        result = solve(
            problem,
            x0=x0_batch,
            params=params_batch,
            config=SolverConfig(method=method, batch_mode=BatchMode.SHARED_STRUCTURE, max_iter=20, tol=1e-10),
        )

        assert isinstance(result, SharedStructureBatchResult)
        assert result.num_succeeded == 5, f"{method}: expected all 5 to succeed"
        expected = target.unsqueeze(0).expand(5, -1)
        assert torch.allclose(result.x, expected, atol=1e-8), f"{method}: solution deviates from expected"

    @pytest.mark.parametrize("method", _ALL_METHODS)
    def test_batch_matches_stacked_single_solves_nonlinear(self, method: str) -> None:
        """Batched nonlinear solve must match stacked per-instance solves numerically.

        Uses a problem with a unique solution per instance so all methods must
        converge to the same point regardless of starting location.
        """
        # unique solutions: state[0]=log(a), state[1]=b  (no multi-modal issues)
        problem = NonlinearLeastSquaresProblem(
            residual=lambda state, params: torch.stack((
                torch.exp(state[0]) - params["a"],
                state[1] - params["b"],
                state[0] + 0.1 * state[1] - params["c"],
            ))
        )
        x0_batch = torch.tensor([[-1.0, 0.5], [0.5, -0.3], [1.0, 1.5], [0.0, 2.0]], dtype=torch.float64)
        params_batch = {
            "a": torch.tensor([2.0, 1.5, 3.0, 1.0], dtype=torch.float64),
            "b": torch.tensor([4.0, 1.0, -2.0, 0.5], dtype=torch.float64),
            # c must satisfy uniqueness: c = log(a) + 0.1*b
            "c": torch.tensor(
                [math.log(2.0) + 0.4, math.log(1.5) + 0.1, math.log(3.0) - 0.2, math.log(1.0) + 0.05],
                dtype=torch.float64,
            ),
        }

        batch_result = solve(
            problem,
            x0=x0_batch,
            params=params_batch,
            config=SolverConfig(method=method, batch_mode=BatchMode.SHARED_STRUCTURE, max_iter=30, tol=1e-10),
        )
        loop_results = [
            solve(
                problem,
                x0=x0_batch[i],
                params={"a": params_batch["a"][i], "b": params_batch["b"][i], "c": params_batch["c"][i]},
                config=SolverConfig(method=method, max_iter=30, tol=1e-10),
            )
            for i in range(4)
        ]

        assert isinstance(batch_result, SharedStructureBatchResult)
        assert batch_result.success == tuple(r.success for r in loop_results), f"{method}: success mismatch"
        for i, (br, lr) in enumerate(zip(batch_result.results, loop_results)):
            assert br.status == lr.status, f"{method} instance {i}: status mismatch"
            assert br.num_iter == lr.num_iter, f"{method} instance {i}: num_iter mismatch"
            if lr.success:
                assert torch.allclose(br.x, lr.x, atol=1e-8), f"{method} instance {i}: x mismatch"
                assert br.objective_value == pytest.approx(lr.objective_value, rel=1e-9, abs=1e-12), (
                    f"{method} instance {i}: objective_value mismatch"
                )

    def test_scalar_states_match_stacked_single_solves(self) -> None:
        """Scalar shared-structure batch (shape: batch,) must match per-instance solves."""
        problem = NonlinearLeastSquaresProblem(
            residual=lambda state, params: torch.exp(state) - params["target"]
        )
        targets = [1.5, 3.0, 0.5, 7.4]
        x0_batch = torch.zeros(4, dtype=torch.float64)
        params_batch = {"target": torch.tensor(targets, dtype=torch.float64)}

        batch_result = solve(
            problem,
            x0=x0_batch,
            params=params_batch,
            config=SolverConfig(method="lm", batch_mode=BatchMode.SHARED_STRUCTURE, max_iter=30, tol=1e-10),
        )
        loop_results = [
            solve(
                problem,
                x0=torch.tensor(0.0, dtype=torch.float64),
                params={"target": torch.tensor(t, dtype=torch.float64)},
                config=SolverConfig(method="lm", max_iter=30, tol=1e-10),
            )
            for t in targets
        ]

        assert isinstance(batch_result, SharedStructureBatchResult)
        assert batch_result.batch_shape == (4,)
        for i, (br, lr) in enumerate(zip(batch_result.results, loop_results)):
            assert br.success == lr.success, f"instance {i}: success mismatch"
            assert torch.allclose(br.x, lr.x, atol=1e-8), (
                f"instance {i}: expected x≈{lr.x.item():.6f}, got {br.x.item():.6f}"
            )

    def test_matrix_state_shape_matches_stacked_single_solves(self) -> None:
        """Matrix states (batch, m, n) must batch correctly and match per-instance results."""
        problem = NonlinearLeastSquaresProblem(
            residual=lambda state, params: (state - params["target"]).reshape(-1)
        )
        x0_batch = torch.zeros((3, 2, 2), dtype=torch.float64)
        targets_batch = torch.tensor([
            [[1.0, 2.0], [3.0, 4.0]],
            [[-1.0, 0.5], [2.0, -3.0]],
            [[5.0, -2.0], [0.0, 1.0]],
        ], dtype=torch.float64)
        params_batch = {"target": targets_batch}

        batch_result = solve(
            problem,
            x0=x0_batch,
            params=params_batch,
            config=SolverConfig(method="lm", batch_mode=BatchMode.SHARED_STRUCTURE, max_iter=10, tol=1e-10),
        )
        loop_results = [
            solve(
                problem,
                x0=torch.zeros(2, 2, dtype=torch.float64),
                params={"target": targets_batch[i]},
                config=SolverConfig(method="lm", max_iter=10, tol=1e-10),
            )
            for i in range(3)
        ]

        assert isinstance(batch_result, SharedStructureBatchResult)
        assert batch_result.x.shape == (3, 2, 2), f"expected (3,2,2), got {batch_result.x.shape}"
        for i, (br, lr) in enumerate(zip(batch_result.results, loop_results)):
            assert br.success == lr.success, f"instance {i}: success mismatch"
            assert torch.allclose(br.x, lr.x, atol=1e-8), f"instance {i}: x mismatch"

    def test_overdetermined_system_correct_least_squares_solution(self) -> None:
        """Overdetermined system (more residuals than parameters) should converge correctly."""
        # 4 residuals, 2 parameters. Least-squares solution is well-defined.
        A = torch.tensor([[1.0, 0.0], [0.0, 1.0], [1.0, 1.0], [1.0, -1.0]], dtype=torch.float64)
        b_batch = torch.tensor([
            [1.0, 2.0, 3.0, -1.0],
            [0.5, 1.5, 2.0, -0.5],
        ], dtype=torch.float64)  # shape: (2, 4)

        problem = NonlinearLeastSquaresProblem(
            residual=lambda state, params: A @ state - params["b"]
        )
        x0_batch = torch.zeros((2, 2), dtype=torch.float64)

        batch_result = solve(
            problem,
            x0=x0_batch,
            params={"b": b_batch},
            config=SolverConfig(method="lm", batch_mode=BatchMode.SHARED_STRUCTURE, max_iter=20, tol=1e-10),
        )
        loop_results = [
            solve(
                problem,
                x0=torch.zeros(2, dtype=torch.float64),
                params={"b": b_batch[i]},
                config=SolverConfig(method="lm", max_iter=20, tol=1e-10),
            )
            for i in range(2)
        ]

        assert isinstance(batch_result, SharedStructureBatchResult)
        for i, (br, lr) in enumerate(zip(batch_result.results, loop_results)):
            assert br.success == lr.success
            if lr.success:
                assert torch.allclose(br.x, lr.x, atol=1e-8), f"instance {i}: overdetermined solution mismatch"


# ---------------------------------------------------------------------------
# 2. PARTIAL-FAILURE ISOLATION
# ---------------------------------------------------------------------------

class TestPartialFailureIsolation:
    """Failed batch elements must not corrupt successful neighbours."""

    def test_successful_instances_have_correct_solutions_when_others_fail_to_converge(self) -> None:
        """Succeeded batch instances must have correct solutions regardless of other instances.

        Instance 0 starts at the exact solution (0 iterations, trivially converged).
        Instances 1-3 start far away and must iterate many steps.
        The key invariant: instance 0's result must equal its initial x0 exactly and must
        not be contaminated by the long-running iterations of the other instances.
        """
        problem = NonlinearLeastSquaresProblem(
            residual=lambda state, params: state - params["target"]
        )
        targets = torch.tensor([[1.0, 2.0], [5.0, 6.0], [-3.0, 4.0], [0.5, -1.0]], dtype=torch.float64)
        # instance 0 starts exactly at its target
        x0_row0 = targets[0].clone()
        x0_rest = torch.zeros((3, 2), dtype=torch.float64)
        x0_batch = torch.cat([x0_row0.unsqueeze(0), x0_rest], dim=0)

        result = solve(
            problem,
            x0=x0_batch,
            params={"target": targets},
            config=SolverConfig(method="lm", batch_mode=BatchMode.SHARED_STRUCTURE, max_iter=20, tol=1e-10),
        )

        assert isinstance(result, SharedStructureBatchResult)
        # All instances should succeed (this is a simple linear problem)
        assert result.num_succeeded == 4
        # Verify every instance converged to its correct target
        assert torch.allclose(result.x, targets, atol=1e-8), (
            f"solutions do not match targets:\nresult.x={result.x}\ntargets={targets}"
        )
        # Instance 0 was already at the solution: must have 0 iterations
        assert result.results[0].num_iter == 0
        # Instance 0's final x must match targets[0] exactly
        assert torch.allclose(result.results[0].x, targets[0], atol=1e-12)

    def test_gn_singular_instance_is_isolated_from_converging_neighbours(self) -> None:
        """GN failure on one instance (singular J) must not contaminate converged neighbours."""
        # residual(x) = x^2 - 1; at x=0, J = 2x = 0 → J^T J singular → GN step=0 → rejected
        problem = NonlinearLeastSquaresProblem(
            residual=lambda state, params: state ** 2 - params["target"]
        )
        # instance 0: start at x=0, target=1 (J=0 at x=0; GN forced to fail)
        # instances 1-2: start at x=1.5, target=1 (J≠0; GN converges to x=1)
        x0_batch = torch.tensor([[0.0], [1.5], [1.5]], dtype=torch.float64)
        params_batch = {"target": torch.ones(3, 1, dtype=torch.float64)}

        result = solve(
            problem,
            x0=x0_batch,
            params=params_batch,
            config=SolverConfig(method="gauss_newton", batch_mode=BatchMode.SHARED_STRUCTURE, max_iter=15, tol=1e-10),
        )

        assert isinstance(result, SharedStructureBatchResult)
        # Instances 1 and 2 must converge to x=1 regardless of instance 0
        for idx in (1, 2):
            assert result.results[idx].success is True, f"instance {idx} should converge to x=1"
            assert torch.allclose(result.results[idx].x, torch.ones(1, dtype=torch.float64), atol=1e-8), (
                f"instance {idx}: expected x=1, got {result.results[idx].x}"
            )

    @pytest.mark.parametrize("method", _ROBUST_METHODS)
    def test_partial_success_count_is_correct(self, method: str) -> None:
        """num_succeeded should accurately reflect partial convergence."""
        # Instance 0 starts AT the solution (already converged)
        # Instances 1,2 start far away and must iterate
        problem, target = _linear_problem(n=2)
        exact = target.unsqueeze(0)
        far_start = torch.tensor([[-50.0, -50.0], [100.0, 100.0]], dtype=torch.float64)
        x0_batch = torch.cat([exact, far_start], dim=0)
        params_batch = {"target": target.unsqueeze(0).expand(3, -1).clone()}

        result = solve(
            problem,
            x0=x0_batch,
            params=params_batch,
            config=SolverConfig(method=method, batch_mode=BatchMode.SHARED_STRUCTURE, max_iter=20, tol=1e-8),
        )

        assert isinstance(result, SharedStructureBatchResult)
        # All three should succeed (linear problem)
        assert result.num_succeeded == 3, f"{method}: expected all 3 to succeed"
        assert result.success == (True, True, True)

    def test_already_converged_instance_has_zero_history_records(self) -> None:
        """An instance starting exactly at the solution must have empty history."""
        problem, target = _linear_problem(n=3)
        exact = target.unsqueeze(0)
        away = torch.tensor([[0.0, 0.0, 0.0]], dtype=torch.float64)
        x0_batch = torch.cat([exact, away], dim=0)
        params_batch = {"target": target.unsqueeze(0).expand(2, -1).clone()}

        result = solve(
            problem,
            x0=x0_batch,
            params=params_batch,
            config=SolverConfig(method="lm", batch_mode=BatchMode.SHARED_STRUCTURE, max_iter=10, tol=1e-10),
        )

        assert isinstance(result, SharedStructureBatchResult)
        assert result.results[0].success is True
        # Instance 0 is already at the solution – gradient ≤ tol before iteration 1
        assert result.results[0].num_iter == 0, (
            f"instance at solution should have 0 iterations, got {result.results[0].num_iter}"
        )
        assert len(result.results[0].history) == 0, "history should be empty for pre-converged instance"
        # Instance 1 must have iterated
        assert result.results[1].num_iter > 0


# ---------------------------------------------------------------------------
# 3. PER-INSTANCE HISTORY FIDELITY
# ---------------------------------------------------------------------------

class TestHistoryFidelity:
    """History records must be per-instance, correctly sized, and internally consistent."""

    def test_num_iter_equals_len_history(self) -> None:
        """result.num_iter must always equal len(result.history) for every instance."""
        problem = NonlinearLeastSquaresProblem(
            residual=lambda state, params: torch.stack((
                state[0] - params["a"],
                2.0 * state[1] - params["b"],
                state[0] + state[1] - params["c"],
            ))
        )
        x0_batch = torch.tensor([[-2.0, 1.0], [4.0, -3.0], [0.5, 0.5]], dtype=torch.float64)
        params_batch = {
            "a": torch.tensor([1.0, 2.0, -1.0], dtype=torch.float64),
            "b": torch.tensor([4.0, -2.0, 6.0], dtype=torch.float64),
            "c": torch.tensor([3.0, 0.0, 2.0], dtype=torch.float64),
        }

        for method in _ALL_METHODS:
            result = solve(
                problem,
                x0=x0_batch,
                params=params_batch,
                config=SolverConfig(method=method, batch_mode=BatchMode.SHARED_STRUCTURE, max_iter=20, tol=1e-10),
            )
            assert isinstance(result, SharedStructureBatchResult)
            for i, r in enumerate(result.results):
                assert r.num_iter == len(r.history), (
                    f"{method} instance {i}: num_iter={r.num_iter} but len(history)={len(r.history)}"
                )

    @pytest.mark.parametrize("method", _ALL_METHODS)
    def test_history_iteration_numbers_are_contiguous_and_start_at_one(self, method: str) -> None:
        """IterationRecord.iteration fields must be 1, 2, …, num_iter in order."""
        problem, target = _linear_problem(n=3)
        x0_batch = torch.zeros((2, 3), dtype=torch.float64)
        params_batch = {"target": target.unsqueeze(0).expand(2, -1).clone()}

        result = solve(
            problem,
            x0=x0_batch,
            params=params_batch,
            config=SolverConfig(method=method, batch_mode=BatchMode.SHARED_STRUCTURE, max_iter=20, tol=1e-10),
        )

        assert isinstance(result, SharedStructureBatchResult)
        for i, r in enumerate(result.results):
            if r.num_iter == 0:
                continue
            iter_nums = [record.iteration for record in r.history]
            assert iter_nums == list(range(1, r.num_iter + 1)), (
                f"{method} instance {i}: iterations not contiguous: {iter_nums}"
            )

    def test_trust_region_history_has_radius_and_ratio_on_accepted_steps(self) -> None:
        """Trust-region records must carry trust_region_radius and trust_region_ratio."""
        problem = _rosenbrock_problem()
        x0_batch = torch.tensor([[-1.2, 1.0], [0.0, 0.0]], dtype=torch.float64)

        result = solve(
            problem,
            x0=x0_batch,
            params=None,
            config=SolverConfig(method="trust_region", batch_mode=BatchMode.SHARED_STRUCTURE, max_iter=40, tol=1e-8),
        )

        assert isinstance(result, SharedStructureBatchResult)
        for i, r in enumerate(result.results):
            for j, record in enumerate(r.history):
                assert record.trust_region_radius is not None, (
                    f"instance {i} iter {j}: trust_region_radius is None"
                )
                # ratio may be None only for the very first record if trust-region radius was
                # initialised but no ratio yet – allow None only when not accepted
                if record.accepted:
                    assert record.trust_region_ratio is not None, (
                        f"instance {i} iter {j}: accepted record missing trust_region_ratio"
                    )

    def test_history_state_shape_matches_original_state_shape(self) -> None:
        """Each history record's state must have the same shape as the original x0 shape."""
        problem, target = _linear_problem(n=4)
        x0_batch = torch.zeros((3, 4), dtype=torch.float64)
        params_batch = {"target": target.unsqueeze(0).expand(3, -1).clone()}

        result = solve(
            problem,
            x0=x0_batch,
            params=params_batch,
            config=SolverConfig(method="lm", batch_mode=BatchMode.SHARED_STRUCTURE, max_iter=10, tol=1e-10),
        )

        assert isinstance(result, SharedStructureBatchResult)
        for i, r in enumerate(result.results):
            for j, record in enumerate(r.history):
                assert record.state.shape == torch.Size([4]), (
                    f"instance {i} iter {j}: expected state shape (4,), got {record.state.shape}"
                )

    def test_different_instances_may_converge_at_different_iterations(self) -> None:
        """Instances requiring different numbers of iterations must have different history lengths."""
        # Make one instance start very close to solution (fast), another far (slow)
        problem = NonlinearLeastSquaresProblem(
            residual=lambda state, params: torch.exp(state) - params["target"]
        )
        # Instance 0: starts at log(2.0) + 1e-4 ≈ very close to solution (target=2.0)
        # Instance 1: starts at -5.0, target=2.0 → needs more iterations
        x0_batch = torch.tensor([math.log(2.0) + 1e-4, -5.0], dtype=torch.float64)
        params_batch = {"target": torch.tensor([2.0, 2.0], dtype=torch.float64)}

        result = solve(
            problem,
            x0=x0_batch,
            params=params_batch,
            config=SolverConfig(method="lm", batch_mode=BatchMode.SHARED_STRUCTURE, max_iter=30, tol=1e-10),
        )

        assert isinstance(result, SharedStructureBatchResult)
        assert result.results[0].success is True
        assert result.results[1].success is True
        # Instance 0 starts very close, should need fewer iterations than instance 1
        assert result.results[0].num_iter < result.results[1].num_iter, (
            f"expected instance 0 (near start) to converge faster, "
            f"but got iter0={result.results[0].num_iter} iter1={result.results[1].num_iter}"
        )


# ---------------------------------------------------------------------------
# 4. GRADIENT NORM AND CONVERGENCE QUALITY
# ---------------------------------------------------------------------------

class TestConvergenceQuality:
    """Every converged instance must actually satisfy the stated tolerance."""

    @pytest.mark.parametrize("method", _ALL_METHODS)
    @pytest.mark.parametrize("tol", [1e-6, 1e-10])
    def test_gradient_norm_satisfies_tol_at_convergence(self, method: str, tol: float) -> None:
        """result.gradient_norm must be ≤ tol for all converged instances."""
        problem, target = _linear_problem(n=3)
        x0_batch = torch.tensor([[-3.0, 2.0, 1.0], [10.0, -5.0, 0.5]], dtype=torch.float64)
        params_batch = {"target": target.unsqueeze(0).expand(2, -1).clone()}

        result = solve(
            problem,
            x0=x0_batch,
            params=params_batch,
            config=SolverConfig(method=method, batch_mode=BatchMode.SHARED_STRUCTURE, max_iter=40, tol=tol),
        )

        assert isinstance(result, SharedStructureBatchResult)
        for i, r in enumerate(result.results):
            if r.success and r.status is SolveStatus.CONVERGED:
                assert float(r.gradient_norm) <= tol * 1.1 + 1e-14, (
                    f"{method} tol={tol} instance {i}: gradient_norm={r.gradient_norm} exceeds tol"
                )

    @pytest.mark.parametrize("method", _ALL_METHODS)
    def test_objective_value_decreases_along_accepted_history(self, method: str) -> None:
        """Accepted IterationRecord objective values must be non-increasing."""
        problem = _rosenbrock_problem()
        x0_batch = torch.tensor([[-1.2, 1.0], [2.0, 2.0]], dtype=torch.float64)

        result = solve(
            problem,
            x0=x0_batch,
            params=None,
            config=SolverConfig(method=method, batch_mode=BatchMode.SHARED_STRUCTURE, max_iter=50, tol=1e-8),
        )

        assert isinstance(result, SharedStructureBatchResult)
        for i, r in enumerate(result.results):
            accepted_obj = [record.objective_value for record in r.history if record.accepted]
            for j in range(len(accepted_obj) - 1):
                assert accepted_obj[j] >= accepted_obj[j + 1] - 1e-12, (
                    f"{method} instance {i}: objective increased between accepted iterations "
                    f"{accepted_obj[j]:.6e} -> {accepted_obj[j+1]:.6e}"
                )

    def test_max_iter_reached_status_is_correct(self) -> None:
        """An instance that hits max_iter without converging must have MAX_ITER_REACHED status."""
        problem = _rosenbrock_problem()
        x0_batch = torch.tensor([[-1.2, 1.0], [-1.2, 1.0]], dtype=torch.float64)

        result = solve(
            problem,
            x0=x0_batch,
            params=None,
            config=SolverConfig(method="gauss_newton", batch_mode=BatchMode.SHARED_STRUCTURE, max_iter=2, tol=1e-14),
        )

        assert isinstance(result, SharedStructureBatchResult)
        for i, r in enumerate(result.results):
            if not r.success:
                # Either MAX_ITER or FAILED are valid for GN with tight tol/small iter
                assert r.status in (SolveStatus.MAX_ITER_REACHED, SolveStatus.FAILED), (
                    f"instance {i}: unexpected status {r.status}"
                )
                assert r.termination in (TerminationReason.MAX_ITER, TerminationReason.NUMERICAL_FAILURE)


# ---------------------------------------------------------------------------
# 5. DEVICE CONSISTENCY
# ---------------------------------------------------------------------------

class TestDeviceConsistency:
    """Explicit device requests must propagate to every tensor touched by the solver."""

    def test_explicit_cpu_device_recorded_in_all_batch_instances(self) -> None:
        """All per-instance reproducibility metadata must report the requested CPU device."""
        problem, target = _linear_problem(n=3)
        x0_batch = torch.zeros((4, 3), dtype=torch.float64)
        params_batch = {"target": target.unsqueeze(0).expand(4, -1).clone()}

        result = solve(
            problem,
            x0=x0_batch,
            params=params_batch,
            config=SolverConfig(method="lm", batch_mode=BatchMode.SHARED_STRUCTURE, device="cpu", max_iter=10, tol=1e-10),
        )

        assert isinstance(result, SharedStructureBatchResult)
        assert result.x.device.type == "cpu"
        for i, r in enumerate(result.results):
            assert r.x.device.type == "cpu", f"instance {i}: x.device={r.x.device}"
            assert r.reproducibility["requested_device"] == "cpu", (
                f"instance {i}: requested_device={r.reproducibility['requested_device']}"
            )
            assert r.reproducibility["solve_device"] == "cpu", (
                f"instance {i}: solve_device={r.reproducibility['solve_device']}"
            )

    def test_residual_callback_receives_state_on_requested_device(self) -> None:
        """Residual callbacks must see the state tensor on the requested device."""
        observed_devices: list[str] = []

        def residual(state: torch.Tensor, params: dict) -> torch.Tensor:
            observed_devices.append(state.device.type)
            return state - params["target"]

        problem = NonlinearLeastSquaresProblem(residual=residual)
        x0_batch = torch.zeros((3, 2), dtype=torch.float64)
        params_batch = {"target": torch.ones((3, 2), dtype=torch.float64)}

        solve(
            problem,
            x0=x0_batch,
            params=params_batch,
            config=SolverConfig(method="lm", batch_mode=BatchMode.SHARED_STRUCTURE, device="cpu", max_iter=5, tol=1e-10),
        )

        assert observed_devices, "residual was never called"
        assert all(d == "cpu" for d in observed_devices), (
            f"residual saw non-CPU devices: {set(observed_devices)}"
        )

    def test_params_on_different_device_are_moved_to_requested_device(self) -> None:
        """Parameters on a different device should be silently moved to the requested device."""
        # Params start on CPU (the default), device="cpu" requested – this is a no-op but
        # the important thing is the solve completes without cross-device errors.
        problem, target = _linear_problem(n=3)
        x0_batch = torch.zeros((2, 3), dtype=torch.float64)  # CPU
        params_batch = {"target": target.unsqueeze(0).expand(2, -1).clone()}  # CPU

        result = solve(
            problem,
            x0=x0_batch,
            params=params_batch,
            config=SolverConfig(method="lm", batch_mode=BatchMode.SHARED_STRUCTURE, device="cpu", max_iter=10, tol=1e-10),
        )

        assert isinstance(result, SharedStructureBatchResult)
        assert result.num_succeeded == 2

    @pytest.mark.skipif(not torch.cuda.is_available(), reason="CUDA not available")
    def test_shared_structure_batch_explicit_cuda_device(self) -> None:
        """Shared-structure batch solve must execute entirely on CUDA when requested."""
        observed: list[str] = []

        def residual(state: torch.Tensor, params: dict) -> torch.Tensor:
            observed.append(state.device.type)
            return state - params["target"]

        problem = NonlinearLeastSquaresProblem(residual=residual)
        x0_batch = torch.zeros((4, 3), dtype=torch.float64)
        params_batch = {"target": torch.ones((4, 3), dtype=torch.float64)}

        result = solve(
            problem,
            x0=x0_batch,
            params=params_batch,
            config=SolverConfig(method="lm", batch_mode=BatchMode.SHARED_STRUCTURE, device="cuda", max_iter=10, tol=1e-10),
        )

        assert isinstance(result, SharedStructureBatchResult)
        assert str(result.x.device).startswith("cuda"), f"x.device={result.x.device}"
        for i, r in enumerate(result.results):
            assert str(r.x.device).startswith("cuda"), f"instance {i}: x.device={r.x.device}"
            assert r.reproducibility["requested_device"].startswith("cuda")
            assert r.reproducibility["solve_device"].startswith("cuda")
        assert all(d == "cuda" for d in observed), f"residual saw non-CUDA devices: {set(observed)}"


# ---------------------------------------------------------------------------
# 6. PARAMETER-STRUCTURE VARIETY
# ---------------------------------------------------------------------------

class TestParameterVariety:
    """The shared-structure param-slicing logic must handle all Python container shapes."""

    def test_params_none_batch_solve(self) -> None:
        """Batch solve with params=None must work for all methods."""
        problem = NonlinearLeastSquaresProblem(
            residual=lambda state, _params: state ** 2 - 1.0
        )
        x0_batch = torch.tensor([[-0.5], [2.0], [-2.0]], dtype=torch.float64)

        for method in _ALL_METHODS:
            result = solve(
                problem,
                x0=x0_batch,
                params=None,
                config=SolverConfig(method=method, batch_mode=BatchMode.SHARED_STRUCTURE, max_iter=30, tol=1e-10),
            )
            assert isinstance(result, SharedStructureBatchResult)
            assert result.num_succeeded == 3, f"{method}: expected 3 successes"

    def test_shared_scalar_param_is_not_sliced(self) -> None:
        """A scalar parameter must be passed identically to every instance."""
        call_args: list[Any] = []

        def residual(state: torch.Tensor, params: dict) -> torch.Tensor:
            call_args.append(params["scale"])
            return state * params["scale"] - params["target"]

        problem = NonlinearLeastSquaresProblem(residual=residual)
        x0_batch = torch.zeros((3, 2), dtype=torch.float64)
        # scale is a scalar (0-dim), target is per-instance
        params_batch = {
            "scale": torch.tensor(2.0, dtype=torch.float64),
            "target": torch.ones((3, 2), dtype=torch.float64),
        }

        solve(
            problem,
            x0=x0_batch,
            params=params_batch,
            config=SolverConfig(method="lm", batch_mode=BatchMode.SHARED_STRUCTURE, max_iter=10, tol=1e-10),
        )

        # scale should have been passed as the original 0-dim tensor (not sliced)
        for scale_arg in call_args:
            assert scale_arg.ndim == 0, f"shared scalar param was sliced, got ndim={scale_arg.ndim}"
            assert float(scale_arg.item()) == pytest.approx(2.0)

    def test_deeply_nested_params_are_correctly_sliced(self) -> None:
        """Deeply nested params must be correctly sliced per-instance."""
        problem = NonlinearLeastSquaresProblem(
            residual=lambda state, params: (
                state
                - params["level1"]["level2"]["per_instance"]
                - params["level1"]["shared"]
            )
        )
        x0_batch = torch.zeros((3, 2), dtype=torch.float64)
        params_batch = {
            "level1": {
                "level2": {
                    "per_instance": torch.tensor([[1.0, 2.0], [3.0, 4.0], [5.0, 6.0]], dtype=torch.float64),
                },
                "shared": torch.tensor([0.5, -0.5], dtype=torch.float64),
            }
        }

        result = solve(
            problem,
            x0=x0_batch,
            params=params_batch,
            config=SolverConfig(method="lm", batch_mode=BatchMode.SHARED_STRUCTURE, max_iter=10, tol=1e-10),
        )

        assert isinstance(result, SharedStructureBatchResult)
        assert result.num_succeeded == 3
        expected_solutions = torch.tensor([
            [1.5, 1.5],
            [3.5, 3.5],
            [5.5, 5.5],
        ], dtype=torch.float64)
        assert torch.allclose(result.x, expected_solutions, atol=1e-8)

    def test_list_and_tuple_params_are_preserved(self) -> None:
        """List and tuple parameter containers must be handled without error."""
        problem = NonlinearLeastSquaresProblem(
            residual=lambda state, params: state - params[0] - params[1]
        )
        x0_batch = torch.zeros((2, 2), dtype=torch.float64)
        # params[0] is per-instance (leading dim == batch_size=2), params[1] is shared
        params_tuple = (
            torch.tensor([[1.0, 2.0], [3.0, 4.0]], dtype=torch.float64),
            torch.tensor([0.1, 0.1], dtype=torch.float64),
        )

        result = solve(
            problem,
            x0=x0_batch,
            params=params_tuple,
            config=SolverConfig(method="lm", batch_mode=BatchMode.SHARED_STRUCTURE, max_iter=10, tol=1e-10),
        )

        assert isinstance(result, SharedStructureBatchResult)
        assert result.num_succeeded == 2
        expected = torch.tensor([[1.1, 2.1], [3.1, 4.1]], dtype=torch.float64)
        assert torch.allclose(result.x, expected, atol=1e-8)


# ---------------------------------------------------------------------------
# 7. ALL THREE METHODS – CROSS-METHOD CONSISTENCY
# ---------------------------------------------------------------------------

class TestCrossMethodConsistency:
    """All three methods must produce consistent results on the same well-conditioned problem."""

    def test_all_methods_find_same_solution_on_nonlinear_problem(self) -> None:
        """GN, LM, TR must all converge to the same solution within tolerance.

        Uses a problem with unique solutions (exp(x0)=a, x1=b, overdetermined)
        to avoid multi-modal effects where different methods land on different minima.
        """
        problem = NonlinearLeastSquaresProblem(
            residual=lambda state, params: torch.stack((
                torch.exp(state[0]) - params["a"],
                state[1] - params["b"],
                state[0] - torch.log(params["a"]),  # reinforces uniqueness
            ))
        )
        x0_batch = torch.tensor([[0.5, 0.5], [1.0, 0.5], [-0.5, 1.5]], dtype=torch.float64)
        params_batch = {
            "a": torch.tensor([2.0, 0.5, 3.0], dtype=torch.float64),
            "b": torch.tensor([1.5, -1.0, 2.0], dtype=torch.float64),
        }

        solutions = {}
        for method in _ALL_METHODS:
            result = solve(
                problem,
                x0=x0_batch,
                params=params_batch,
                config=SolverConfig(method=method, batch_mode=BatchMode.SHARED_STRUCTURE, max_iter=50, tol=1e-10),
            )
            assert isinstance(result, SharedStructureBatchResult)
            solutions[method] = result.x

        for i in range(3):
            x_gn = solutions["gauss_newton"][i]
            x_lm = solutions["lm"][i]
            x_tr = solutions["trust_region"][i]
            assert torch.allclose(x_gn, x_lm, atol=1e-7), (
                f"instance {i}: GN vs LM differ: {x_gn} vs {x_lm}"
            )
            assert torch.allclose(x_lm, x_tr, atol=1e-7), (
                f"instance {i}: LM vs TR differ: {x_lm} vs {x_tr}"
            )

    @pytest.mark.parametrize("method", _ALL_METHODS)
    def test_batch_result_x_stacks_correctly(self, method: str) -> None:
        """`SharedStructureBatchResult.x` must equal `torch.stack([r.x for r in results])`."""
        problem, target = _linear_problem(n=3)
        x0_batch = torch.zeros((4, 3), dtype=torch.float64)
        params_batch = {"target": target.unsqueeze(0).expand(4, -1).clone()}

        result = solve(
            problem,
            x0=x0_batch,
            params=params_batch,
            config=SolverConfig(method=method, batch_mode=BatchMode.SHARED_STRUCTURE, max_iter=20, tol=1e-10),
        )

        assert isinstance(result, SharedStructureBatchResult)
        manual_stack = torch.stack([r.x for r in result.results])
        assert torch.allclose(result.x, manual_stack, atol=1e-14), (
            f"{method}: result.x does not match manual stack"
        )


# ---------------------------------------------------------------------------
# 8. LARGE BATCH CORRECTNESS
# ---------------------------------------------------------------------------

class TestLargeBatch:
    """A large batch must produce per-instance correct results without degradation."""

    @pytest.mark.parametrize("method", _ROBUST_METHODS)
    def test_batch_32_linear_all_converge_correctly(self, method: str) -> None:
        """batch_size=32 linear problems must all converge with correct solutions."""
        n = 4
        batch_size = 32
        problem, _ = _linear_problem(n=n)
        # Each instance has a different target
        targets = torch.arange(1.0, batch_size * n + 1, dtype=torch.float64).reshape(batch_size, n)
        x0_batch = torch.zeros((batch_size, n), dtype=torch.float64)

        result = solve(
            problem,
            x0=x0_batch,
            params={"target": targets},
            config=SolverConfig(method=method, batch_mode=BatchMode.SHARED_STRUCTURE, max_iter=20, tol=1e-10),
        )

        assert isinstance(result, SharedStructureBatchResult)
        assert result.batch_size == batch_size
        assert result.num_succeeded == batch_size, f"{method}: expected all {batch_size} to succeed"
        assert torch.allclose(result.x, targets, atol=1e-8), f"{method}: solutions deviate from targets"

    def test_batch_16_nonlinear_matches_stacked_loop(self) -> None:
        """batch_size=16 nonlinear solve must match a loop over per-instance solves."""
        batch_size = 16
        problem = NonlinearLeastSquaresProblem(
            residual=lambda state, params: torch.stack((
                state[0] + params["b"] - params["t"][0],
                2.0 * state[1] - params["t"][1],
            ))
        )
        x0_batch = torch.zeros((batch_size, 2), dtype=torch.float64)
        b_vals = torch.linspace(0.0, 1.5, batch_size, dtype=torch.float64)
        t_vals = torch.stack([
            torch.linspace(1.0, 16.0, batch_size, dtype=torch.float64),
            torch.linspace(-8.0, 8.0, batch_size, dtype=torch.float64),
        ], dim=-1)

        batch_result = solve(
            problem,
            x0=x0_batch,
            params={"b": b_vals, "t": t_vals},
            config=SolverConfig(method="lm", batch_mode=BatchMode.SHARED_STRUCTURE, max_iter=20, tol=1e-10),
        )
        loop_results = [
            solve(
                problem,
                x0=torch.zeros(2, dtype=torch.float64),
                params={"b": b_vals[i], "t": t_vals[i]},
                config=SolverConfig(method="lm", max_iter=20, tol=1e-10),
            )
            for i in range(batch_size)
        ]

        assert isinstance(batch_result, SharedStructureBatchResult)
        assert batch_result.num_succeeded == batch_size
        for i, (br, lr) in enumerate(zip(batch_result.results, loop_results)):
            assert br.success == lr.success, f"instance {i}: success mismatch"
            assert torch.allclose(br.x, lr.x, atol=1e-8), f"instance {i}: x mismatch"


# ---------------------------------------------------------------------------
# 9. SCALING IN BATCHED MODE
# ---------------------------------------------------------------------------

class TestScalingInBatchedMode:
    """Auto and manual scaling must work correctly across all batch instances."""

    def test_auto_scaling_batch_converges_to_correct_solution(self) -> None:
        """Auto-scaled batch solve on a poorly-conditioned problem must find the exact solution.

        Without scaling, 1e4 / 1e-4 residual imbalance causes ill-conditioning.
        With auto variable scaling, the solver must still converge to (a, b) for each instance.
        """
        problem = NonlinearLeastSquaresProblem(
            residual=lambda state, params: torch.stack((
                1e4 * (state[0] - params["a"]),
                1e-4 * (state[1] - params["b"]),
            ))
        )
        x0_batch = torch.zeros((3, 2), dtype=torch.float64)
        params_batch = {
            "a": torch.tensor([1.0, 2.0, -1.0], dtype=torch.float64),
            "b": torch.tensor([3.0, -1.0, 4.0], dtype=torch.float64),
        }
        # analytical solution: state[0]=a, state[1]=b for each instance
        expected = torch.stack([params_batch["a"], params_batch["b"]], dim=-1)

        result_scaled = solve(
            problem,
            x0=x0_batch,
            params=params_batch,
            config=SolverConfig(
                method="lm",
                batch_mode=BatchMode.SHARED_STRUCTURE,
                max_iter=40,
                tol=1e-8,
                scaling=ScalingConfig(variable_mode=ScalingMode.AUTO),
            ),
        )

        assert isinstance(result_scaled, SharedStructureBatchResult)
        assert result_scaled.num_succeeded == 3, "auto-scaled batch: not all instances converged"
        assert torch.allclose(result_scaled.x, expected, atol=1e-5), (
            f"auto-scaled solution does not match analytical:\ngot={result_scaled.x}\nexpected={expected}"
        )

    def test_scaling_metadata_is_present_in_all_instances(self) -> None:
        """All per-instance results must carry scaling metadata in reproducibility."""
        problem, target = _linear_problem(n=3)
        x0_batch = torch.zeros((3, 3), dtype=torch.float64)
        params_batch = {"target": target.unsqueeze(0).expand(3, -1).clone()}

        result = solve(
            problem,
            x0=x0_batch,
            params=params_batch,
            config=SolverConfig(
                method="lm",
                batch_mode=BatchMode.SHARED_STRUCTURE,
                max_iter=10,
                tol=1e-10,
                scaling=ScalingConfig(variable_mode=ScalingMode.AUTO),
            ),
        )

        assert isinstance(result, SharedStructureBatchResult)
        for i, r in enumerate(result.results):
            repro = r.reproducibility
            assert "scaling" in repro, f"instance {i}: 'scaling' key missing from reproducibility"
            scaling_meta = repro["scaling"]
            assert scaling_meta.get("variable_mode") == "auto", (
                f"instance {i}: variable_mode={scaling_meta.get('variable_mode')}"
            )
            # auto-scaling must report meaningful spread and scale bounds
            assert "variable_scale_min" in scaling_meta
            assert "variable_scale_max" in scaling_meta
            assert "variable_spread" in scaling_meta

    def test_manual_residual_scaling_batch_converges(self) -> None:
        """Manual residual scaling must not prevent convergence in a batched solve."""
        problem = NonlinearLeastSquaresProblem(
            residual=lambda state, params: torch.stack((
                state[0] - params["a"],
                state[1] - params["b"],
            ))
        )
        x0_batch = torch.zeros((3, 2), dtype=torch.float64)
        params_batch = {
            "a": torch.tensor([1.0, 2.0, 3.0], dtype=torch.float64),
            "b": torch.tensor([-1.0, 4.0, -2.0], dtype=torch.float64),
        }

        result = solve(
            problem,
            x0=x0_batch,
            params=params_batch,
            config=SolverConfig(
                method="lm",
                batch_mode=BatchMode.SHARED_STRUCTURE,
                max_iter=20,
                tol=1e-10,
                scaling=ScalingConfig(
                    residual_mode=ScalingMode.MANUAL,
                    residual_scale=torch.tensor([2.0, 0.5], dtype=torch.float64),
                ),
            ),
        )

        assert isinstance(result, SharedStructureBatchResult)
        assert result.num_succeeded == 3
        expected = torch.tensor([[1.0, -1.0], [2.0, 4.0], [3.0, -2.0]], dtype=torch.float64)
        assert torch.allclose(result.x, expected, atol=1e-8)


# ---------------------------------------------------------------------------
# 10. INTERNAL CONSISTENCY INVARIANTS
# ---------------------------------------------------------------------------

class TestInternalConsistencyInvariants:
    """Cross-cutting invariants that must hold regardless of method, shape, or problem."""

    @pytest.mark.parametrize("method", _ALL_METHODS)
    def test_result_x_device_matches_solve_device_metadata(self, method: str) -> None:
        """result.x.device.type must match result.reproducibility['solve_device']."""
        problem, target = _linear_problem(n=3)
        x0_batch = torch.zeros((3, 3), dtype=torch.float64)
        params_batch = {"target": target.unsqueeze(0).expand(3, -1).clone()}

        result = solve(
            problem,
            x0=x0_batch,
            params=params_batch,
            config=SolverConfig(method=method, batch_mode=BatchMode.SHARED_STRUCTURE, max_iter=10, tol=1e-10),
        )

        assert isinstance(result, SharedStructureBatchResult)
        for i, r in enumerate(result.results):
            repro_device = r.reproducibility["solve_device"]
            assert r.x.device.type == repro_device.split(":")[0], (
                f"{method} instance {i}: x.device={r.x.device} but solve_device={repro_device}"
            )

    @pytest.mark.parametrize("method", _ALL_METHODS)
    def test_result_linear_solver_name_is_set_on_all_instances(self, method: str) -> None:
        """Every per-instance result must record the linear solver name."""
        problem, target = _linear_problem(n=3)
        x0_batch = torch.zeros((3, 3), dtype=torch.float64)
        params_batch = {"target": target.unsqueeze(0).expand(3, -1).clone()}

        result = solve(
            problem,
            x0=x0_batch,
            params=params_batch,
            config=SolverConfig(method=method, batch_mode=BatchMode.SHARED_STRUCTURE, max_iter=10, tol=1e-10),
        )

        assert isinstance(result, SharedStructureBatchResult)
        for i, r in enumerate(result.results):
            assert r.reproducibility.get("linear_solver") in ("dense_direct", "cholesky"), (
                f"{method} instance {i}: linear_solver not set: {r.reproducibility}"
            )

    @pytest.mark.parametrize("method", _ALL_METHODS)
    def test_batch_shape_and_batch_size_consistency(self, method: str) -> None:
        """SharedStructureBatchResult.batch_shape[0] must equal batch_size == len(results)."""
        problem, target = _linear_problem(n=2)
        batch_size = 5
        x0_batch = torch.zeros((batch_size, 2), dtype=torch.float64)
        params_batch = {"target": target.unsqueeze(0).expand(batch_size, -1).clone()}

        result = solve(
            problem,
            x0=x0_batch,
            params=params_batch,
            config=SolverConfig(method=method, batch_mode=BatchMode.SHARED_STRUCTURE, max_iter=10, tol=1e-10),
        )

        assert isinstance(result, SharedStructureBatchResult)
        assert result.batch_shape == (batch_size,)
        assert result.batch_size == batch_size
        assert len(result.results) == batch_size

    @pytest.mark.parametrize("method", _ALL_METHODS)
    def test_result_x_shape_matches_x0_shape(self, method: str) -> None:
        """result.x shape per instance must match the input x0 state shape."""
        problem, target = _linear_problem(n=4)
        x0_batch = torch.zeros((3, 4), dtype=torch.float64)
        params_batch = {"target": target.unsqueeze(0).expand(3, -1).clone()}

        result = solve(
            problem,
            x0=x0_batch,
            params=params_batch,
            config=SolverConfig(method=method, batch_mode=BatchMode.SHARED_STRUCTURE, max_iter=10, tol=1e-10),
        )

        assert isinstance(result, SharedStructureBatchResult)
        assert result.x.shape == torch.Size([3, 4]), f"{method}: stacked x shape {result.x.shape}"
        for i, r in enumerate(result.results):
            assert r.x.shape == torch.Size([4]), (
                f"{method} instance {i}: expected x.shape=(4,), got {r.x.shape}"
            )

    def test_summary_string_is_non_empty_and_correct_format(self) -> None:
        """SharedStructureBatchResult.summary() must return a meaningful string."""
        problem, target = _linear_problem(n=2)
        x0_batch = torch.zeros((3, 2), dtype=torch.float64)
        params_batch = {"target": target.unsqueeze(0).expand(3, -1).clone()}

        result = solve(
            problem,
            x0=x0_batch,
            params=params_batch,
            config=SolverConfig(method="lm", batch_mode=BatchMode.SHARED_STRUCTURE, max_iter=10, tol=1e-10),
        )

        assert isinstance(result, SharedStructureBatchResult)
        s = result.summary()
        assert "batch_size=3" in s
        assert "succeeded=" in s

    def test_to_dict_serialisation_round_trips(self) -> None:
        """to_dict must return a JSON-compatible structure covering all batch instances."""
        problem, target = _linear_problem(n=2)
        x0_batch = torch.zeros((2, 2), dtype=torch.float64)
        params_batch = {"target": target.unsqueeze(0).expand(2, -1).clone()}

        result = solve(
            problem,
            x0=x0_batch,
            params=params_batch,
            config=SolverConfig(method="lm", batch_mode=BatchMode.SHARED_STRUCTURE, max_iter=10, tol=1e-10),
        )

        assert isinstance(result, SharedStructureBatchResult)
        d = result.to_dict()
        assert d["batch_shape"] == [2]
        assert d["num_succeeded"] == 2
        assert len(d["results"]) == 2
        for rd in d["results"]:
            assert "success" in rd
            assert "x" in rd or "status" in rd  # at least one result field present

    def test_invalid_batch_mode_raises_not_implemented(self) -> None:
        """BatchMode.INDEPENDENT must raise NotImplementedError through the public API."""
        problem, target = _linear_problem(n=2)

        with pytest.raises(NotImplementedError):
            solve(
                problem,
                x0=torch.zeros((2, 2), dtype=torch.float64),
                params={"target": target.unsqueeze(0).expand(2, -1).clone()},
                config=SolverConfig(method="lm", batch_mode=BatchMode.INDEPENDENT, max_iter=5, tol=1e-8),
            )
