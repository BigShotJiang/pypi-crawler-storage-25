from pytorch_nonlinear.variables import flatten_mapping


def test_flatten_mapping_round_trip() -> None:
    state = flatten_mapping(
        {
            "x": [1.0, 2.0],
            "bias": 3.0,
            "matrix": [[4.0, 5.0], [6.0, 7.0]],
        }
    )

    assert state.flat == (1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0)
    assert state.as_mapping() == {
        "x": (1.0, 2.0),
        "bias": 3.0,
        "matrix": ((4.0, 5.0), (6.0, 7.0)),
    }


def test_flatten_mapping_rejects_jagged_values() -> None:
    try:
        flatten_mapping({"bad": [[1.0], [2.0, 3.0]]})
    except ValueError as error:
        assert "rectangular" in str(error)
    else:
        raise AssertionError("Expected flatten_mapping() to reject jagged inputs.")
