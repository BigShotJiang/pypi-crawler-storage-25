import pytest

from pytorch_nonlinear.constraints import Bounds, EqualityConstraint, InequalityConstraint
from pytorch_nonlinear.problem import ConstrainedNLPProblem, NonlinearLeastSquaresProblem, SmoothMinimizationProblem


def test_problem_evaluation_paths() -> None:
    least_squares = NonlinearLeastSquaresProblem(residual=lambda state, params: (state["x"] - params["target"],))
    smooth = SmoothMinimizationProblem(objective=lambda state, params: state["x"] + params["shift"])
    constrained = ConstrainedNLPProblem(
        objective=lambda state, params: state["x"] ** 2,
        constraints=(
            EqualityConstraint(lambda state, params: state["x"] - params["eq_target"]),
            InequalityConstraint(lambda state, params: state["x"] - params["ineq_limit"]),
        ),
    )

    ls_eval = least_squares.evaluate({"x": 2.0}, {"target": 1.5})
    smooth_eval = smooth.evaluate({"x": 2.0}, {"shift": 0.5})
    constrained_eval = constrained.evaluate({"x": 2.0}, {"eq_target": 2.0, "ineq_limit": 1.0})

    assert ls_eval.residual == (0.5,)
    assert smooth_eval.objective_value == 2.5
    assert constrained_eval.objective_value == 4.0
    assert constrained_eval.constraint_values == (0.0, 1.0)


def test_problem_validation_rejects_non_callables() -> None:
    with pytest.raises(TypeError):
        NonlinearLeastSquaresProblem(residual=123).validate()

    with pytest.raises(TypeError):
        SmoothMinimizationProblem(objective=123).validate()

    with pytest.raises(TypeError):
        ConstrainedNLPProblem(objective=123).validate()


def test_constraint_and_bounds_validation() -> None:
    with pytest.raises(TypeError):
        EqualityConstraint(function=123).validate()

    with pytest.raises(TypeError):
        InequalityConstraint(function=123).validate()

    with pytest.raises(ValueError):
        Bounds().validate()

    Bounds(lower=0.0).validate()
    Bounds(upper=1.0).validate()