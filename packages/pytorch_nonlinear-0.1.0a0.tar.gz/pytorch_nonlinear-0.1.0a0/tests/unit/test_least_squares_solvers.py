"""Tests for the dense least-squares solver slice."""

from __future__ import annotations

import math

import pytest
import torch
import pytorch_nonlinear.solvers.least_squares as least_squares_module

from pytorch_nonlinear import (
    BatchMode,
    CauchyLoss,
    ConvergenceValidationMode,
    DiagnosisCode,
    DiffMode,
    HuberLoss,
    NonlinearLeastSquaresProblem,
    ScalingConfig,
    ScalingMode,
    SharedStructureBatchResult,
    SoftL1Loss,
    SolveStatus,
    SolverConfig,
    TerminationReason,
    solve,
)
from pytorch_nonlinear.scaling import build_least_squares_scaling, build_scaled_least_squares_linear_model
from pytorch_nonlinear.solvers import evaluate_dense_least_squares


_SHARED_STRUCTURE_EQUIVALENCE_METHODS = ("gauss_newton", "lm", "trust_region")


def test_evaluate_dense_least_squares_builds_expected_local_model() -> None:
    """The dense evaluator should expose residual, Jacobian, and gradient data.

    Returns
    -------
    None
        The assertions validate the local model contents.
    """

    problem = NonlinearLeastSquaresProblem(
        residual=lambda state, params: torch.stack(
            (
                state[0] - params["target"],
                2.0 * state[1] + state[0],
            )
        )
    )

    evaluation = evaluate_dense_least_squares(problem, torch.tensor([3.0, -1.0]), {"target": 1.5})

    assert torch.allclose(evaluation.residual, torch.tensor([1.5, 1.0], dtype=torch.float32))
    assert torch.allclose(evaluation.jacobian, torch.tensor([[1.0, 0.0], [1.0, 2.0]], dtype=torch.float32))
    assert math.isclose(float(evaluation.objective_value), 1.625, rel_tol=0.0, abs_tol=1e-6)
    assert torch.allclose(evaluation.gradient, torch.tensor([2.5, 2.0], dtype=torch.float32))


def test_evaluate_dense_least_squares_batch_matches_looped_local_models() -> None:
    """Batched dense evaluation should match the per-instance loop exactly."""

    problem = NonlinearLeastSquaresProblem(
        residual=lambda state, params: torch.stack(
            (
                state[0] - params["target"],
                2.0 * state[1] + state[0],
            )
        )
    )
    x_batch = torch.tensor([[3.0, -1.0], [1.5, 2.0]], dtype=torch.float64)
    params_batch = {"target": torch.tensor([1.5, -0.5], dtype=torch.float64)}

    batch_evaluation = evaluate_dense_least_squares(
        problem,
        x_batch,
        params_batch,
        original_shape=x_batch[0].shape,
    )
    loop_evaluations = tuple(
        evaluate_dense_least_squares(
            problem,
            x_batch[index],
            {"target": params_batch["target"][index]},
        )
        for index in range(x_batch.shape[0])
    )

    assert batch_evaluation.x.shape == (2, 2)
    assert batch_evaluation.residual.shape == (2, 2)
    assert batch_evaluation.jacobian.shape == (2, 2, 2)
    assert batch_evaluation.gradient.shape == (2, 2)
    assert batch_evaluation.normal_matrix.shape == (2, 2, 2)
    assert batch_evaluation.objective_value.shape == (2,)
    assert torch.allclose(batch_evaluation.residual, torch.stack([evaluation.residual for evaluation in loop_evaluations]))
    assert torch.allclose(batch_evaluation.jacobian, torch.stack([evaluation.jacobian for evaluation in loop_evaluations]))
    assert torch.allclose(batch_evaluation.gradient, torch.stack([evaluation.gradient for evaluation in loop_evaluations]))
    assert torch.allclose(batch_evaluation.normal_matrix, torch.stack([evaluation.normal_matrix for evaluation in loop_evaluations]))
    assert torch.allclose(
        batch_evaluation.objective_value,
        torch.stack([evaluation.objective_value for evaluation in loop_evaluations]),
    )


def test_gauss_newton_solves_linearized_scalar_problem() -> None:
    """Gauss-Newton should solve a simple dense least-squares problem."""

    problem = NonlinearLeastSquaresProblem(
        residual=lambda state, params: torch.stack(
            (
                state[0] - params["target"],
                2.0 * (state[0] - params["target"]),
            )
        )
    )

    result = solve(
        problem,
        x0=torch.tensor([-5.0]),
        params={"target": 3.0},
        config=SolverConfig(method="gauss_newton", max_iter=4, tol=1e-10),
    )

    assert result.success is True
    assert result.status is SolveStatus.CONVERGED
    assert result.termination is TerminationReason.GRADIENT_TOL
    assert torch.allclose(result.x, torch.tensor([3.0]), atol=1e-8)


@pytest.mark.parametrize("method", _SHARED_STRUCTURE_EQUIVALENCE_METHODS)
def test_stationary_nonminimum_is_not_reported_as_converged(method: str) -> None:
    """Stationary non-minimizers should fail instead of reporting gradient convergence."""

    problem = NonlinearLeastSquaresProblem(residual=lambda state, params: state[0] ** 2 - 1.0)

    result = solve(
        problem,
        x0=torch.tensor([0.0], dtype=torch.float64),
        params=None,
        config=SolverConfig(method=method, max_iter=8, tol=1e-10),
    )

    assert result.success is False
    assert result.status is SolveStatus.FAILED
    assert result.termination is TerminationReason.NUMERICAL_FAILURE
    assert DiagnosisCode.STATIONARY_NONMINIMUM in result.diagnosis
    assert "lower nearby point" in result.message.lower() or "not locally minimizing" in result.message.lower()
    assert result.num_iter == 0


def test_gradient_only_convergence_validation_preserves_legacy_behavior() -> None:
    """The explicit gradient-only mode should preserve the old first-order convergence rule."""

    problem = NonlinearLeastSquaresProblem(residual=lambda state, params: state[0] ** 2 - 1.0)

    result = solve(
        problem,
        x0=torch.tensor([0.0], dtype=torch.float64),
        params=None,
        config=SolverConfig(method="lm", max_iter=8, tol=1e-10, convergence_validation=ConvergenceValidationMode.GRADIENT_ONLY),
    )

    assert result.success is True
    assert result.status is SolveStatus.CONVERGED
    assert result.termination is TerminationReason.GRADIENT_TOL
    assert DiagnosisCode.STATIONARY_NONMINIMUM not in result.diagnosis
    assert result.reproducibility["convergence_validation"] == ConvergenceValidationMode.GRADIENT_ONLY.value


def test_directional_convergence_validation_rejects_stationary_nonminimum() -> None:
    """Directional validation should catch the simple stationary non-minimum without a dense Hessian."""

    problem = NonlinearLeastSquaresProblem(residual=lambda state, params: state[0] ** 2 - 1.0)

    result = solve(
        problem,
        x0=torch.tensor([0.0], dtype=torch.float64),
        params=None,
        config=SolverConfig(method="lm", max_iter=8, tol=1e-10, convergence_validation=ConvergenceValidationMode.DIRECTIONAL),
    )

    assert result.success is False
    assert result.status is SolveStatus.FAILED
    assert DiagnosisCode.STATIONARY_NONMINIMUM in result.diagnosis
    assert result.reproducibility["convergence_validation"] == ConvergenceValidationMode.DIRECTIONAL.value


def test_auto_convergence_validation_does_not_claim_uncertified_high_dim_stationary_candidate() -> None:
    """Auto validation must fail closed when directional screening is the only remaining evidence."""

    direction = torch.zeros(20, dtype=torch.float64)
    direction[4] = 1.0
    direction[5] = -1.0
    direction = direction / torch.linalg.vector_norm(direction)
    problem = NonlinearLeastSquaresProblem(
        residual=lambda state, params: torch.dot(direction, state) ** 2 - 1.0
    )

    result = solve(
        problem,
        x0=torch.zeros(20, dtype=torch.float64),
        params=None,
        config=SolverConfig(method="lm", max_iter=4, tol=1e-10),
    )

    assert result.success is False
    assert result.status is SolveStatus.FAILED
    assert result.termination is TerminationReason.NUMERICAL_FAILURE
    assert DiagnosisCode.CONVERGENCE_UNVERIFIED in result.diagnosis
    assert "could not certify" in result.message.lower()
    assert result.reproducibility["convergence_validation"] == ConvergenceValidationMode.AUTO.value


def test_strict_convergence_validation_rejects_stationary_nonminimum() -> None:
    """Strict validation should keep the exact-Hessian backstop available."""

    problem = NonlinearLeastSquaresProblem(residual=lambda state, params: state[0] ** 2 - 1.0)

    result = solve(
        problem,
        x0=torch.tensor([0.0], dtype=torch.float64),
        params=None,
        config=SolverConfig(method="lm", max_iter=8, tol=1e-10, convergence_validation=ConvergenceValidationMode.STRICT),
    )

    assert result.success is False
    assert result.status is SolveStatus.FAILED
    assert DiagnosisCode.STATIONARY_NONMINIMUM in result.diagnosis
    assert result.reproducibility["convergence_validation"] == ConvergenceValidationMode.STRICT.value


def test_true_minimum_with_nonzero_residual_is_still_reported_as_converged() -> None:
    """A valid least-squares minimum may keep nonzero residual and should still converge."""

    problem = NonlinearLeastSquaresProblem(
        residual=lambda state, params: torch.stack((state[0] - 1.0, state[0] - 2.0))
    )

    result = solve(
        problem,
        x0=torch.tensor([1.5], dtype=torch.float64),
        params=None,
        config=SolverConfig(method="lm", max_iter=4, tol=1e-10),
    )

    assert result.success is True
    assert result.status is SolveStatus.CONVERGED
    assert result.termination is TerminationReason.GRADIENT_TOL
    assert DiagnosisCode.STATIONARY_NONMINIMUM not in result.diagnosis
    assert result.objective_value == pytest.approx(0.25)
    assert torch.allclose(result.x, torch.tensor([1.5], dtype=torch.float64), atol=1e-8)


def test_stationary_nonminimum_failure_is_isolated_in_shared_structure_batch() -> None:
    """A failed stationary batch element should not block a true minimum neighbor."""

    problem = NonlinearLeastSquaresProblem(residual=lambda state, params: state[0] ** 2 - 1.0)

    result = solve(
        problem,
        x0=torch.tensor([[0.0], [1.0]], dtype=torch.float64),
        params=None,
        config=SolverConfig(method="lm", batch_mode=BatchMode.SHARED_STRUCTURE, max_iter=8, tol=1e-10),
    )

    assert isinstance(result, SharedStructureBatchResult)
    assert result.success == (False, True)
    assert result.results[0].status is SolveStatus.FAILED
    assert result.results[0].termination is TerminationReason.NUMERICAL_FAILURE
    assert DiagnosisCode.STATIONARY_NONMINIMUM in result.results[0].diagnosis
    assert result.results[1].status is SolveStatus.CONVERGED
    assert result.results[1].termination is TerminationReason.GRADIENT_TOL
    assert result.results[1].num_iter == 0


def test_batched_linear_failure_diagnosis_is_isolated_to_failing_instance() -> None:
    """Linear failure diagnoses must stay attached to the failing shared-structure instance only."""

    problem = NonlinearLeastSquaresProblem(
        residual=lambda state, params: params["scale"] * (state - params["target"])
    )

    result = solve(
        problem,
        x0=torch.tensor([[0.0, 0.0], [0.0, 0.0]], dtype=torch.float64),
        params={
            "scale": torch.tensor([[1.0, 0.0], [1.0, 1.0]], dtype=torch.float64),
            "target": torch.tensor([[1.0, 1.0], [1.0, 1.0]], dtype=torch.float64),
        },
        config=SolverConfig(
            method="gauss_newton",
            linear_solver="cholesky",
            batch_mode=BatchMode.SHARED_STRUCTURE,
            max_iter=2,
            tol=1e-10,
        ),
    )

    assert isinstance(result, SharedStructureBatchResult)
    assert DiagnosisCode.RANK_DEFICIENT_JACOBIAN in result.results[0].diagnosis
    assert DiagnosisCode.ILL_CONDITIONED_SYSTEM in result.results[0].diagnosis
    assert DiagnosisCode.RANK_DEFICIENT_JACOBIAN not in result.results[1].diagnosis
    assert DiagnosisCode.ILL_CONDITIONED_SYSTEM not in result.results[1].diagnosis


def test_levenberg_marquardt_recovers_from_rejected_full_step() -> None:
    """LM should damp an unstable full step that Gauss-Newton rejects."""

    problem = NonlinearLeastSquaresProblem(residual=lambda state, params: torch.exp(state) - params["target"])

    gauss_newton_result = solve(
        problem,
        x0=torch.tensor([-3.0]),
        params={"target": torch.tensor([2.0])},
        config=SolverConfig(method="gauss_newton", max_iter=5, tol=1e-10),
    )
    lm_result = solve(
        problem,
        x0=torch.tensor([-3.0]),
        params={"target": torch.tensor([2.0])},
        config=SolverConfig(method="lm", max_iter=20, tol=1e-10),
    )

    assert gauss_newton_result.success is False
    assert DiagnosisCode.STEP_REJECTED in gauss_newton_result.diagnosis
    assert lm_result.success is True
    assert lm_result.status is SolveStatus.CONVERGED
    assert torch.allclose(lm_result.x, torch.log(torch.tensor([2.0])), atol=1e-6)

    # A multi-attempt iteration shows the damping policy actually intervened.
    assert any(len(record.trials) > 1 for record in lm_result.history)
    assert all(record.state is not None for record in lm_result.history)
    assert all(record.trials for record in lm_result.history)
    assert any(trial.step_parameter is not None for record in lm_result.history for trial in record.trials)
    assert lm_result.linear_residual_norm is not None
    assert lm_result.linear_condition_estimate is not None
    assert any(trial.linear_residual_norm is not None for record in lm_result.history for trial in record.trials)
    assert any(trial.linear_condition_estimate is not None for record in lm_result.history for trial in record.trials)


def test_lm_retry_loop_compacts_after_one_batch_element_accepts(monkeypatch: pytest.MonkeyPatch) -> None:
    """LM should shrink later retry solves to the still-unaccepted subset within one outer iteration."""

    recorded_batch_sizes: list[int] = []
    original_build_linear_solver = least_squares_module.build_linear_solver

    class RecordingSolver:
        def __init__(self, inner: object) -> None:
            self._inner = inner
            self.name = inner.name

        def solve(self, linearization: object) -> object:
            matrix = linearization.matrix
            recorded_batch_sizes.append(int(matrix.shape[0]) if matrix.ndim > 2 else 1)
            return self._inner.solve(linearization)

    monkeypatch.setattr(
        least_squares_module,
        "build_linear_solver",
        lambda name: RecordingSolver(original_build_linear_solver(name)),
    )

    problem = NonlinearLeastSquaresProblem(residual=lambda state, params: torch.exp(state) - params["target"])
    result = solve(
        problem,
        x0=torch.tensor([[0.0], [-3.0]], dtype=torch.float64),
        params={"target": torch.tensor([[1.2], [2.0]], dtype=torch.float64)},
        config=SolverConfig(method="lm", batch_mode=BatchMode.SHARED_STRUCTURE, max_iter=20, tol=1e-10),
    )

    assert isinstance(result, SharedStructureBatchResult)
    assert result.success == (True, True)
    assert 2 in recorded_batch_sizes
    assert 1 in recorded_batch_sizes


def test_trust_region_retry_loop_compacts_after_one_batch_element_accepts(monkeypatch: pytest.MonkeyPatch) -> None:
    """Trust-region should shrink later retry solves to the still-unaccepted subset within one outer iteration."""

    recorded_batch_sizes: list[int] = []
    original_solve_trust_region_subproblem = least_squares_module.solve_trust_region_subproblem

    def recording_solve_trust_region_subproblem(*args: object, **kwargs: object) -> object:
        normal_matrix = kwargs.get("normal_matrix", args[0] if args else None)
        assert isinstance(normal_matrix, torch.Tensor)
        recorded_batch_sizes.append(int(normal_matrix.shape[0]) if normal_matrix.ndim > 2 else 1)
        return original_solve_trust_region_subproblem(*args, **kwargs)

    monkeypatch.setattr(
        least_squares_module,
        "solve_trust_region_subproblem",
        recording_solve_trust_region_subproblem,
    )

    problem = NonlinearLeastSquaresProblem(residual=lambda state, params: torch.exp(state) - params["target"])
    result = solve(
        problem,
        x0=torch.tensor([[0.0], [-3.0]], dtype=torch.float64),
        params={"target": torch.tensor([[1.2], [2.0]], dtype=torch.float64)},
        config=SolverConfig(method="trust_region", batch_mode=BatchMode.SHARED_STRUCTURE, max_iter=20, tol=1e-10),
    )

    assert isinstance(result, SharedStructureBatchResult)
    assert result.success[0] is True
    assert 2 in recorded_batch_sizes
    assert 1 in recorded_batch_sizes
    assert any(
        previous_size == 2 and current_size == 1
        for previous_size, current_size in zip(recorded_batch_sizes, recorded_batch_sizes[1:], strict=False)
    )


def test_rosenbrock_example_case_highlights_gn_vs_lm() -> None:
    """The Rosenbrock least-squares case should separate GN and LM behavior."""

    def residual(state: torch.Tensor, params: None) -> torch.Tensor:
        return torch.stack((1.0 - state[0], 10.0 * (state[1] - state[0] ** 2)))

    problem = NonlinearLeastSquaresProblem(residual=residual)
    start = torch.tensor([-1.2, 1.0], dtype=torch.float64)

    gauss_newton_result = solve(
        problem,
        x0=start,
        params=None,
        config=SolverConfig(method="gauss_newton", max_iter=10, tol=1e-10),
    )
    lm_result = solve(
        problem,
        x0=start,
        params=None,
        config=SolverConfig(method="lm", max_iter=30, tol=1e-10),
    )

    assert gauss_newton_result.success is False
    assert DiagnosisCode.STEP_REJECTED in gauss_newton_result.diagnosis
    assert torch.allclose(gauss_newton_result.history[0].state, start)
    assert len(gauss_newton_result.history[0].trials) == 1
    assert gauss_newton_result.history[0].trials[0].state is not None
    assert gauss_newton_result.history[0].trials[0].objective_value is not None
    assert gauss_newton_result.history[0].trials[0].accepted is False
    assert gauss_newton_result.history[0].linear_residual_norm is not None
    assert gauss_newton_result.history[0].linear_condition_estimate is not None
    assert gauss_newton_result.linear_residual_norm == gauss_newton_result.history[0].linear_residual_norm
    assert gauss_newton_result.linear_condition_estimate == gauss_newton_result.history[0].linear_condition_estimate

    assert lm_result.success is True
    assert lm_result.status is SolveStatus.CONVERGED
    assert torch.allclose(lm_result.x, torch.ones(2, dtype=torch.float64), atol=1e-6)
    assert lm_result.history[0].state is not None
    assert torch.allclose(lm_result.history[-1].state, lm_result.x, atol=1e-6)
    assert lm_result.history[-1].linear_residual_norm is not None
    assert lm_result.history[-1].linear_condition_estimate is not None


def test_trust_region_improves_robustness_on_difficult_rosenbrock_start() -> None:
    """Trust-region acceptance should outperform LM-only behavior on a hard start."""

    def residual(state: torch.Tensor, params: None) -> torch.Tensor:
        return torch.stack((1.0 - state[0], 10.0 * (state[1] - state[0] ** 2)))

    problem = NonlinearLeastSquaresProblem(residual=residual)
    start = torch.tensor([-5.0, -4.0], dtype=torch.float64)

    lm_result = solve(
        problem,
        x0=start,
        params=None,
        config=SolverConfig(method="lm", max_iter=8, tol=1e-10),
    )
    trust_region_result = solve(
        problem,
        x0=start,
        params=None,
        config=SolverConfig(method="trust_region", max_iter=8, tol=1e-10),
    )

    assert lm_result.success is False
    assert lm_result.status is SolveStatus.MAX_ITER_REACHED
    assert trust_region_result.success is True
    assert trust_region_result.status is SolveStatus.CONVERGED
    assert trust_region_result.num_iter < lm_result.num_iter
    assert torch.allclose(trust_region_result.x, torch.ones(2, dtype=torch.float64), atol=1e-6)
    assert all(record.trust_region_radius is not None for record in trust_region_result.history)
    assert any(record.trust_region_ratio is not None for record in trust_region_result.history)
    assert any(trial.trust_region_radius is not None for record in trust_region_result.history for trial in record.trials)
    assert any(trial.trust_region_ratio is not None for record in trust_region_result.history for trial in record.trials)


def test_trust_region_handles_unavailable_reduction_ratio_without_crashing() -> None:
    """Trust-region should complete cleanly on a previously crashing case."""

    problem = NonlinearLeastSquaresProblem(
        residual=lambda state, params: torch.stack(
            (
                1.5 - state[0] * (1.0 - state[1]),
                2.25 - state[0] * (1.0 - state[1] ** 2),
                2.625 - state[0] * (1.0 - state[1] ** 3),
            )
        )
    )

    result = solve(
        problem,
        x0=torch.tensor([1.0, 1.0], dtype=torch.float64),
        params=None,
        config=SolverConfig(method="trust_region", max_iter=8, tol=1e-10),
    )

    assert result.status in {SolveStatus.CONVERGED, SolveStatus.FAILED, SolveStatus.MAX_ITER_REACHED}
    assert result.history
    assert all(trial.reason for record in result.history for trial in record.trials)


def test_explicit_cpu_device_selection_is_recorded() -> None:
    """The solver should honor and report an explicit CPU device request."""

    observed: list[tuple[str, str]] = []

    def residual(state: torch.Tensor, params: dict[str, torch.Tensor]) -> torch.Tensor:
        observed.append((state.device.type, params["target"].device.type))
        return state - params["target"]

    problem = NonlinearLeastSquaresProblem(residual=residual)
    result = solve(
        problem,
        x0=[-2.0],
        params={"target": torch.tensor([1.0], dtype=torch.float64)},
        config=SolverConfig(method="lm", device="cpu", max_iter=8, tol=1e-10),
    )

    assert result.success is True
    assert result.reproducibility["requested_device"] == "cpu"
    assert result.reproducibility["solve_device"] == "cpu"
    assert observed and all(state_device == "cpu" and target_device == "cpu" for state_device, target_device in observed)


def test_shared_structure_batch_mode_returns_per_instance_results() -> None:
    """Shared-structure batch mode should keep one result per batch element."""

    problem = NonlinearLeastSquaresProblem(residual=lambda state, params: state - params["target"])
    result = solve(
        problem,
        x0=torch.tensor([[-2.0], [4.5]], dtype=torch.float64),
        params={"target": torch.tensor([[1.0], [3.0]], dtype=torch.float64)},
        config=SolverConfig(method="lm", batch_mode=BatchMode.SHARED_STRUCTURE, max_iter=8, tol=1e-10),
    )

    assert isinstance(result, SharedStructureBatchResult)
    assert result.batch_shape == (2,)
    assert result.batch_size == 2
    assert result.num_succeeded == 2
    assert result.success == (True, True)
    assert torch.allclose(result.x, torch.tensor([[1.0], [3.0]], dtype=torch.float64), atol=1e-8)
    assert len(result.results) == 2
    assert all(instance.success for instance in result.results)
    assert all(instance.status is SolveStatus.CONVERGED for instance in result.results)
    assert torch.allclose(result.results[0].history[-1].state, torch.tensor([1.0], dtype=torch.float64), atol=1e-8)
    assert torch.allclose(result.results[1].history[-1].state, torch.tensor([3.0], dtype=torch.float64), atol=1e-8)


@pytest.mark.parametrize("method", _SHARED_STRUCTURE_EQUIVALENCE_METHODS)
def test_shared_structure_batch_mode_matches_stacked_single_solves(method: str) -> None:
    """Shared-structure batch solves should match stacking per-instance solves."""

    problem = NonlinearLeastSquaresProblem(
        residual=lambda state, params: torch.stack(
            (
                state[0] + params["bias"] - params["target"][0],
                2.0 * state[1] - params["target"][1],
                state[0] - state[1] + params["shared_offset"],
            )
        )
    )
    x0_batch = torch.tensor(((-2.0, 1.0), (4.5, -3.0), (0.5, 2.5)), dtype=torch.float64)
    params_batch = {
        "target": torch.tensor(((1.0, 4.0), (3.0, -2.0), (-1.0, 6.0)), dtype=torch.float64),
        "bias": torch.tensor((0.25, -1.5, 0.75), dtype=torch.float64),
        "shared_offset": torch.tensor(0.5, dtype=torch.float64),
    }
    batch_config = SolverConfig(method=method, batch_mode=BatchMode.SHARED_STRUCTURE, max_iter=12, tol=1e-10)
    single_config = SolverConfig(method=method, max_iter=12, tol=1e-10)

    batch_result = solve(problem, x0=x0_batch, params=params_batch, config=batch_config)
    loop_results = tuple(
        solve(
            problem,
            x0=x0_batch[index],
            params={
                "target": params_batch["target"][index],
                "bias": params_batch["bias"][index],
                "shared_offset": params_batch["shared_offset"],
            },
            config=single_config,
        )
        for index in range(x0_batch.shape[0])
    )

    assert isinstance(batch_result, SharedStructureBatchResult)
    assert batch_result.batch_shape == (3,)
    assert batch_result.success == tuple(item.success for item in loop_results)
    assert tuple(item.status for item in batch_result.results) == tuple(item.status for item in loop_results)
    assert tuple(item.num_iter for item in batch_result.results) == tuple(item.num_iter for item in loop_results)
    assert torch.allclose(batch_result.x, torch.stack([item.x for item in loop_results]), atol=1e-8)
    assert torch.allclose(
        torch.tensor(batch_result.objective_value, dtype=torch.float64),
        torch.tensor([float(item.objective_value) for item in loop_results], dtype=torch.float64),
        atol=1e-10,
    )
    assert torch.allclose(
        torch.tensor([float(item.gradient_norm) for item in batch_result.results], dtype=torch.float64),
        torch.tensor([float(item.gradient_norm) for item in loop_results], dtype=torch.float64),
        atol=1e-10,
    )
    assert torch.allclose(
        torch.tensor([float(item.linear_residual_norm) for item in batch_result.results], dtype=torch.float64),
        torch.tensor([float(item.linear_residual_norm) for item in loop_results], dtype=torch.float64),
        atol=1e-10,
    )


@pytest.mark.parametrize("method", _SHARED_STRUCTURE_EQUIVALENCE_METHODS)
def test_shared_structure_batch_mode_matches_stacked_single_solves_for_matrix_states_and_nested_params(method: str) -> None:
    """Shared-structure solves should match looped solves for matrix states and nested params."""

    problem = NonlinearLeastSquaresProblem(
        residual=lambda state, params: torch.stack(
            (
                state[0, 0] + params["bias"] - params["target"][0],
                2.0 * state[1, 0] - params["target"][1],
                state[0, 0] - state[1, 0] + params["nested"]["shared_offset"],
                state[1, 0] + params["nested"]["corrections"][0] - params["nested"]["target_shift"],
            )
        )
    )
    x0_batch = torch.tensor((((-2.0,), (1.0,)), ((4.5,), (-3.0,))), dtype=torch.float64)
    params_batch = {
        "target": torch.tensor(((1.0, 4.0), (3.0, -2.0)), dtype=torch.float64),
        "bias": torch.tensor((0.25, -1.5), dtype=torch.float64),
        "nested": {
            "shared_offset": torch.tensor(0.5, dtype=torch.float64),
            "target_shift": torch.tensor((2.0, -1.0), dtype=torch.float64),
            "corrections": (
                torch.tensor((1.0, -2.0), dtype=torch.float64),
                [torch.tensor(7.0, dtype=torch.float64)],
            ),
        },
    }
    batch_config = SolverConfig(method=method, batch_mode=BatchMode.SHARED_STRUCTURE, max_iter=12, tol=1e-10)
    single_config = SolverConfig(method=method, max_iter=12, tol=1e-10)

    batch_result = solve(problem, x0=x0_batch, params=params_batch, config=batch_config)
    loop_results = tuple(
        solve(
            problem,
            x0=x0_batch[index],
            params={
                "target": params_batch["target"][index],
                "bias": params_batch["bias"][index],
                "nested": {
                    "shared_offset": params_batch["nested"]["shared_offset"],
                    "target_shift": params_batch["nested"]["target_shift"][index],
                    "corrections": (
                        params_batch["nested"]["corrections"][0][index],
                        params_batch["nested"]["corrections"][1],
                    ),
                },
            },
            config=single_config,
        )
        for index in range(x0_batch.shape[0])
    )

    assert isinstance(batch_result, SharedStructureBatchResult)
    assert batch_result.batch_shape == (2,)
    assert batch_result.success == tuple(item.success for item in loop_results)
    assert tuple(item.status for item in batch_result.results) == tuple(item.status for item in loop_results)
    assert tuple(item.num_iter for item in batch_result.results) == tuple(item.num_iter for item in loop_results)
    assert torch.allclose(batch_result.x, torch.stack([item.x for item in loop_results]), atol=1e-8)
    assert batch_result.x.shape == x0_batch.shape
    assert torch.allclose(
        torch.tensor(batch_result.objective_value, dtype=torch.float64),
        torch.tensor([float(item.objective_value) for item in loop_results], dtype=torch.float64),
        atol=1e-10,
    )
    assert torch.allclose(
        torch.tensor([float(item.gradient_norm) for item in batch_result.results], dtype=torch.float64),
        torch.tensor([float(item.gradient_norm) for item in loop_results], dtype=torch.float64),
        atol=1e-10,
    )
    assert torch.allclose(
        torch.tensor([float(item.linear_residual_norm) for item in batch_result.results], dtype=torch.float64),
        torch.tensor([float(item.linear_residual_norm) for item in loop_results], dtype=torch.float64),
        atol=1e-10,
    )


def test_shared_structure_batch_mode_slices_batched_params_and_preserves_shared_inputs() -> None:
    """Batched params should slice per instance while shared values stay shared."""

    def residual(state: torch.Tensor, params: dict[str, torch.Tensor]) -> torch.Tensor:
        return state + params["bias"] - params["target"]

    problem = NonlinearLeastSquaresProblem(residual=residual)
    result = solve(
        problem,
        x0=torch.tensor([[-1.0], [5.0]], dtype=torch.float64),
        params={
            "target": torch.tensor([[2.0], [6.0]], dtype=torch.float64),
            "bias": torch.tensor([0.5], dtype=torch.float64),
        },
        config=SolverConfig(method="lm", batch_mode=BatchMode.SHARED_STRUCTURE, device="cpu", max_iter=8, tol=1e-10),
    )

    assert isinstance(result, SharedStructureBatchResult)
    assert torch.allclose(result.x, torch.tensor([[1.5], [5.5]], dtype=torch.float64), atol=1e-8)
    assert all(instance.reproducibility["solve_device"] == "cpu" for instance in result.results)


@pytest.mark.parametrize("method", _SHARED_STRUCTURE_EQUIVALENCE_METHODS)
def test_single_instance_matches_batch_size_one_shared_structure(method: str) -> None:
    """The unified solver core should match direct solves and batch_size=1 shared-structure solves."""

    problem = NonlinearLeastSquaresProblem(
        residual=lambda state, params: torch.stack(
            (
                state[0] + params["bias"] - params["target"][0],
                2.0 * state[1] - params["target"][1],
                state[0] - state[1] + params["shared_offset"],
            )
        )
    )
    x0 = torch.tensor([-2.0, 1.0], dtype=torch.float64)
    params = {
        "target": torch.tensor([1.0, 4.0], dtype=torch.float64),
        "bias": torch.tensor(0.25, dtype=torch.float64),
        "shared_offset": torch.tensor(0.5, dtype=torch.float64),
    }

    single_result = solve(
        problem,
        x0=x0,
        params=params,
        config=SolverConfig(method=method, max_iter=12, tol=1e-10),
    )
    batch_result = solve(
        problem,
        x0=x0.unsqueeze(0),
        params={
            "target": params["target"].unsqueeze(0),
            "bias": params["bias"],
            "shared_offset": params["shared_offset"],
        },
        config=SolverConfig(method=method, batch_mode=BatchMode.SHARED_STRUCTURE, max_iter=12, tol=1e-10),
    )

    assert isinstance(batch_result, SharedStructureBatchResult)
    assert batch_result.batch_shape == (1,)
    assert batch_result.results[0].success == single_result.success
    assert batch_result.results[0].status == single_result.status
    assert batch_result.results[0].termination == single_result.termination
    assert batch_result.results[0].num_iter == single_result.num_iter
    assert torch.allclose(batch_result.results[0].x, single_result.x, atol=1e-8)
    assert batch_result.results[0].objective_value == pytest.approx(single_result.objective_value)
    assert batch_result.results[0].gradient_norm == pytest.approx(single_result.gradient_norm)


def test_shared_structure_batch_mode_requires_an_explicit_batch_dimension() -> None:
    """Shared-structure batch mode should reject unbatched state inputs."""

    problem = NonlinearLeastSquaresProblem(residual=lambda state, params: state - 1.0)

    with pytest.raises(ValueError, match="leading batch dimension"):
        solve(
            problem,
            x0=torch.tensor(0.0, dtype=torch.float64),
            params=None,
            config=SolverConfig(method="gauss_newton", batch_mode=BatchMode.SHARED_STRUCTURE, max_iter=4, tol=1e-10),
        )


def test_shared_structure_batch_mode_supports_scalar_states() -> None:
    """Shared-structure batching should support scalar states shaped as (batch,)."""

    problem = NonlinearLeastSquaresProblem(residual=lambda state, params: state - params["target"])
    batch_result = solve(
        problem,
        x0=torch.tensor([-2.0, 4.5], dtype=torch.float64),
        params={"target": torch.tensor([1.0, 3.0], dtype=torch.float64)},
        config=SolverConfig(method="lm", batch_mode=BatchMode.SHARED_STRUCTURE, max_iter=8, tol=1e-10),
    )

    loop_results = tuple(
        solve(
            problem,
            x0=torch.tensor(value, dtype=torch.float64),
            params={"target": torch.tensor(target, dtype=torch.float64)},
            config=SolverConfig(method="lm", max_iter=8, tol=1e-10),
        )
        for value, target in ((-2.0, 1.0), (4.5, 3.0))
    )

    assert isinstance(batch_result, SharedStructureBatchResult)
    assert batch_result.batch_shape == (2,)
    assert batch_result.success == tuple(item.success for item in loop_results)
    assert torch.allclose(batch_result.x, torch.tensor([1.0, 3.0], dtype=torch.float64), atol=1e-8)
    assert tuple(item.status for item in batch_result.results) == tuple(item.status for item in loop_results)
    assert tuple(item.num_iter for item in batch_result.results) == tuple(item.num_iter for item in loop_results)


def test_auto_scaling_surfaces_poor_scaling_warning_and_metadata() -> None:
    """Automatic scaling should warn about large scale spreads and record metadata."""

    problem = NonlinearLeastSquaresProblem(
        residual=lambda state, params: torch.stack(
            (
                1e6 * (state[0] - 1.0),
                1e-6 * (state[1] - 2.0),
            )
        )
    )

    result = solve(
        problem,
        x0=torch.tensor([0.0, 0.0], dtype=torch.float64),
        params=None,
        config=SolverConfig(
            method="gauss_newton",
            scaling=ScalingConfig(variable_mode=ScalingMode.AUTO, residual_mode=ScalingMode.AUTO),
            max_iter=4,
            tol=1e-10,
        ),
    )

    assert result.success is True
    assert DiagnosisCode.POOR_SCALING in result.diagnosis
    assert result.reproducibility["scaling"]["variable_mode"] == "auto"
    assert result.reproducibility["scaling"]["residual_mode"] == "auto"
    assert result.reproducibility["scaling"]["variable_spread"] is not None


def test_manual_scaling_metadata_is_recorded() -> None:
    """Manual scaling inputs should be accepted and preserved in metadata."""

    problem = NonlinearLeastSquaresProblem(residual=lambda state, params: state - torch.tensor([3.0, -2.0], dtype=state.dtype))

    result = solve(
        problem,
        x0=torch.tensor([0.0, 0.0], dtype=torch.float64),
        params=None,
        config=SolverConfig(
            method="gauss_newton",
            scaling=ScalingConfig(
                variable_mode=ScalingMode.MANUAL,
                residual_mode=ScalingMode.MANUAL,
                variable_scale=torch.tensor([1e-3, 2.0]),
                residual_scale=torch.tensor([5.0, 0.5]),
            ),
            max_iter=4,
            tol=1e-10,
        ),
    )

    assert result.success is True
    assert result.reproducibility["scaling"]["variable_mode"] == "manual"
    assert result.reproducibility["scaling"]["residual_mode"] == "manual"
    assert result.reproducibility["scaling"]["variable_scale_min"] == pytest.approx(1e-3)
    assert result.reproducibility["scaling"]["residual_scale_max"] == pytest.approx(5.0)


def test_default_scaling_metadata_skips_spread_diagnostics() -> None:
    """Default scaling should not populate auto-scaling spread diagnostics."""

    problem = NonlinearLeastSquaresProblem(residual=lambda state, params: state - torch.tensor([1.0, -2.0], dtype=state.dtype))

    result = solve(
        problem,
        x0=torch.tensor([0.0, 0.0], dtype=torch.float64),
        params=None,
        config=SolverConfig(method="gauss_newton", max_iter=4, tol=1e-10),
    )

    scaling_meta = result.reproducibility["scaling"]
    assert scaling_meta["variable_mode"] == "none"
    assert scaling_meta["residual_mode"] == "none"
    assert scaling_meta["variable_spread"] is None
    assert scaling_meta["residual_spread"] is None


def test_manual_variable_scaling_preserves_linear_gauss_newton_solution() -> None:
    """Manual variable scaling should preserve the exact GN step on a linear problem."""

    problem = NonlinearLeastSquaresProblem(
        residual=lambda state, params: torch.stack(
            (
                state[0] + 2.0 * state[1] - 5.0,
                3.0 * state[0] - state[1] - 4.0,
            )
        )
    )
    start = torch.tensor([0.0, 0.0], dtype=torch.float64)

    plain_result = solve(
        problem,
        x0=start,
        params=None,
        config=SolverConfig(method="gauss_newton", max_iter=2, tol=1e-10),
    )
    scaled_result = solve(
        problem,
        x0=start,
        params=None,
        config=SolverConfig(
            method="gauss_newton",
            max_iter=2,
            tol=1e-10,
            scaling=ScalingConfig(
                variable_mode=ScalingMode.MANUAL,
                variable_scale=torch.tensor([1e-3, 25.0], dtype=torch.float64),
            ),
        ),
    )

    assert plain_result.success is True
    assert scaled_result.success is True
    assert torch.allclose(plain_result.x, scaled_result.x, atol=1e-10)
    assert plain_result.objective_value == pytest.approx(scaled_result.objective_value)


def test_manual_residual_scaling_rescales_local_model_rows() -> None:
    """Residual scaling should rescale both residual rows and Jacobian rows."""

    residual = torch.tensor([1.0, -2.0, 3.0], dtype=torch.float64)
    jacobian = torch.tensor(
        (
            (1.0, 2.0),
            (3.0, 4.0),
            (5.0, 6.0),
        ),
        dtype=torch.float64,
    )
    scaling = build_least_squares_scaling(
        residual,
        jacobian,
        ScalingConfig(
            residual_mode=ScalingMode.MANUAL,
            residual_scale=torch.tensor([2.0, 0.5, 10.0], dtype=torch.float64),
        ),
    )

    model = build_scaled_least_squares_linear_model(residual, jacobian, scaling)
    expected_residual = torch.tensor([2.0, -1.0, 30.0], dtype=torch.float64)
    expected_jacobian = torch.tensor(
        (
            (2.0, 4.0),
            (1.5, 2.0),
            (50.0, 60.0),
        ),
        dtype=torch.float64,
    )

    assert torch.allclose(model.residual, expected_residual)
    assert torch.allclose(model.jacobian, expected_jacobian)
    assert torch.allclose(model.gradient, expected_jacobian.transpose(0, 1) @ expected_residual)
    assert torch.allclose(model.normal_matrix, expected_jacobian.transpose(0, 1) @ expected_jacobian)


def test_scaling_rejects_mismatched_residual_dimension() -> None:
    """Scaling should reject Jacobians whose residual axis does not match the residual length."""

    residual = torch.tensor([1.0, -2.0], dtype=torch.float64)
    jacobian = torch.tensor(
        (
            (1.0, 2.0),
            (3.0, 4.0),
            (5.0, 6.0),
        ),
        dtype=torch.float64,
    )

    with pytest.raises(ValueError, match="residual and jacobian must share the same leading batch dimensions and residual dimension"):
        build_least_squares_scaling(residual, jacobian, ScalingConfig())


def test_auto_variable_scaling_limits_per_iteration_metric_jumps() -> None:
    """Automatic variable scaling should change smoothly across iterations."""

    config = ScalingConfig(variable_mode=ScalingMode.AUTO)
    residual = torch.ones(2, dtype=torch.float64)
    first_jacobian = torch.tensor(
        (
            (1e6, 0.0),
            (0.0, 1.0),
        ),
        dtype=torch.float64,
    )
    second_jacobian = torch.tensor(
        (
            (1.0, 0.0),
            (0.0, 1e6),
        ),
        dtype=torch.float64,
    )

    first = build_least_squares_scaling(residual, first_jacobian, config)
    second = build_least_squares_scaling(
        residual,
        second_jacobian,
        config,
        previous_variable_scale=first.variable_scale,
    )

    raw_second = torch.tensor([1.0, 1e-6], dtype=torch.float64)
    assert torch.all(second.variable_scale > 0)
    assert torch.all(second.variable_scale / first.variable_scale <= 10.0 + 1e-12)
    assert torch.all(first.variable_scale / second.variable_scale <= 10.0 + 1e-12)
    assert not torch.allclose(second.variable_scale, raw_second)


def test_batched_scaling_and_scaled_model_match_looped_results() -> None:
    """Batched scaling algebra should match looping over individual problems."""

    config = ScalingConfig(
        variable_mode=ScalingMode.AUTO,
        residual_mode=ScalingMode.MANUAL,
        residual_scale=torch.tensor(((2.0, 0.5), (1.5, 3.0)), dtype=torch.float64),
    )
    residual = torch.tensor([[1.0, -2.0], [3.0, 4.0]], dtype=torch.float64)
    jacobian = torch.tensor(
        (
            ((2.0, 0.0), (0.0, 3.0)),
            ((1.0, 1.0), (4.0, 0.5)),
        ),
        dtype=torch.float64,
    )

    batch_scaling = build_least_squares_scaling(residual, jacobian, config)
    batch_model = build_scaled_least_squares_linear_model(residual, jacobian, batch_scaling)
    loop_scalings = tuple(
        build_least_squares_scaling(
            residual[i],
            jacobian[i],
            ScalingConfig(
                variable_mode=ScalingMode.AUTO,
                residual_mode=ScalingMode.MANUAL,
                residual_scale=config.residual_scale[i],
            ),
        )
        for i in range(residual.shape[0])
    )
    loop_models = tuple(
        build_scaled_least_squares_linear_model(residual[i], jacobian[i], loop_scalings[i])
        for i in range(residual.shape[0])
    )

    assert batch_scaling.variable_scale.shape == (2, 2)
    assert batch_scaling.residual_scale.shape == (2, 2)
    assert torch.allclose(batch_scaling.variable_scale, torch.stack([item.variable_scale for item in loop_scalings]))
    assert torch.allclose(batch_scaling.residual_scale, torch.stack([item.residual_scale for item in loop_scalings]))
    assert torch.allclose(batch_model.residual, torch.stack([item.residual for item in loop_models]))
    assert torch.allclose(batch_model.jacobian, torch.stack([item.jacobian for item in loop_models]))
    assert torch.allclose(batch_model.gradient, torch.stack([item.gradient for item in loop_models]))
    assert torch.allclose(batch_model.normal_matrix, torch.stack([item.normal_matrix for item in loop_models]))


def test_auto_variable_scaling_tracks_new_metric_gradually_over_multiple_updates() -> None:
    """Automatic variable scaling should approach a new metric smoothly over time."""

    config = ScalingConfig(variable_mode=ScalingMode.AUTO)
    residual = torch.ones(2, dtype=torch.float64)
    first_jacobian = torch.tensor(
        (
            (1e6, 0.0),
            (0.0, 1.0),
        ),
        dtype=torch.float64,
    )
    second_jacobian = torch.tensor(
        (
            (1.0, 0.0),
            (0.0, 1e6),
        ),
        dtype=torch.float64,
    )
    raw_target = torch.tensor([1.0, 1e-6], dtype=torch.float64)

    first = build_least_squares_scaling(residual, first_jacobian, config)
    previous_scale = first.variable_scale
    previous_log_distance = torch.max(torch.abs(torch.log(previous_scale) - torch.log(raw_target)))

    for _ in range(7):
        current = build_least_squares_scaling(
            residual,
            second_jacobian,
            config,
            previous_variable_scale=previous_scale,
        )
        current_scale = current.variable_scale
        current_log_distance = torch.max(torch.abs(torch.log(current_scale) - torch.log(raw_target)))

        assert torch.all(current_scale > 0)
        assert torch.all(current_scale / previous_scale <= 10.0 + 1e-12)
        assert torch.all(previous_scale / current_scale <= 10.0 + 1e-12)
        assert current_log_distance < previous_log_distance

        previous_scale = current_scale
        previous_log_distance = current_log_distance


def test_auto_variable_scaling_improves_lm_robustness_on_badly_scaled_linear_problem() -> None:
    """Automatic variable scaling should rescue a badly scaled linear LM solve."""

    problem = NonlinearLeastSquaresProblem(
        residual=lambda state, params: torch.stack(
            (
                1e8 * (state[0] - 1.0),
                state[1] - 2.0,
            )
        )
    )
    start = torch.tensor([0.0, 0.0], dtype=torch.float64)

    plain_result = solve(
        problem,
        x0=start,
        params=None,
        config=SolverConfig(method="lm", max_iter=20, tol=1e-12),
    )
    scaled_result = solve(
        problem,
        x0=start,
        params=None,
        config=SolverConfig(
            method="lm",
            max_iter=20,
            tol=1e-12,
            scaling=ScalingConfig(variable_mode=ScalingMode.AUTO),
        ),
    )

    assert plain_result.success is False
    assert scaled_result.success is True
    assert torch.allclose(scaled_result.x, torch.tensor([1.0, 2.0], dtype=torch.float64), atol=1e-8)


def test_matrix_shaped_state_is_restored_for_residual_callbacks() -> None:
    """Least-squares residual callbacks should receive the original state shape."""

    problem = NonlinearLeastSquaresProblem(
        residual=lambda state, params: torch.stack(
            (
                state[0, 0] - 1.0,
                state[1, 0] - 2.0,
            )
        )
    )
    start = torch.tensor([[0.0], [0.0]], dtype=torch.float64)

    evaluation = evaluate_dense_least_squares(problem, start)
    result = solve(
        problem,
        x0=start,
        params=None,
        config=SolverConfig(method="gauss_newton", max_iter=2, tol=1e-10),
    )

    assert torch.allclose(evaluation.residual, torch.tensor([-1.0, -2.0], dtype=torch.float64))
    assert result.success is True
    assert result.status is SolveStatus.CONVERGED
    assert result.x.shape == start.shape
    assert torch.allclose(result.x, torch.tensor([[1.0], [2.0]], dtype=torch.float64), atol=1e-10)


def test_trust_region_residual_scaling_keeps_exact_linear_acceptance_consistent() -> None:
    """Residual scaling should not break trust-region acceptance on an exact linear model."""

    problem = NonlinearLeastSquaresProblem(
        residual=lambda state, params: torch.stack(
            (
                state[0] - 2.0,
                2.0 * (state[0] - 2.0),
            )
        )
    )

    result = solve(
        problem,
        x0=torch.tensor([0.0], dtype=torch.float64),
        params=None,
        config=SolverConfig(
            method="trust_region",
            max_iter=4,
            tol=1e-10,
            scaling=ScalingConfig(
                residual_mode=ScalingMode.MANUAL,
                residual_scale=torch.tensor([100.0, 1.0], dtype=torch.float64),
            ),
        ),
    )

    assert result.success is True
    assert result.status is SolveStatus.CONVERGED
    assert torch.allclose(result.x, torch.tensor([2.0], dtype=torch.float64), atol=1e-10)
    assert result.history[0].trials[0].accepted is True
    assert result.history[0].trials[0].trust_region_ratio == pytest.approx(1.0, rel=1e-9, abs=1e-9)


def test_trust_region_variable_scaling_keeps_radius_in_original_coordinates() -> None:
    """Trust-region radii and recorded step norms should share the same units."""

    problem = NonlinearLeastSquaresProblem(
        residual=lambda state, params: torch.stack(
            (
                1e6 * (state[0] - 1.0),
                1e-6 * (state[1] - 2.0),
            )
        )
    )

    result = solve(
        problem,
        x0=torch.tensor([0.0, 0.0], dtype=torch.float64),
        params=None,
        config=SolverConfig(
            method="trust_region",
            trust_region_initial_radius=1.0,
            max_iter=4,
            tol=1e-10,
            scaling=ScalingConfig(variable_mode=ScalingMode.AUTO),
        ),
    )

    assert result.success is True
    assert result.history
    for record in result.history:
        for trial in record.trials:
            if trial.step_norm is not None and trial.trust_region_radius is not None:
                assert trial.step_norm <= trial.trust_region_radius + 1e-9


def test_lm_step_tolerance_does_not_report_false_convergence_under_scaling() -> None:
    """A tiny LM step should not imply convergence when the gradient is still large."""

    problem = NonlinearLeastSquaresProblem(
        residual=lambda state, params: torch.stack(
            (
                state[0] + 2.0 * state[1] - 5.0,
                3.0 * state[0] - state[1] - 4.0,
            )
        )
    )

    result = solve(
        problem,
        x0=torch.tensor([0.0, 0.0], dtype=torch.float64),
        params=None,
        config=SolverConfig(
            method="lm",
            max_iter=6,
            tol=1e-12,
            scaling=ScalingConfig(
                variable_mode=ScalingMode.MANUAL,
                variable_scale=torch.tensor([1e-6, 1e3], dtype=torch.float64),
            ),
        ),
    )

    assert result.success is False
    assert result.termination is not TerminationReason.STEP_TOL
    assert result.gradient_norm > 1.0


def test_trust_region_auto_radius_fallback_uses_original_gradient_units() -> None:
    """Fallback trust-region radii should stay in original variable coordinates."""

    problem = NonlinearLeastSquaresProblem(
        residual=lambda state, params: torch.stack((state[0] + state[1] - 1.0,))
    )

    result = solve(
        problem,
        x0=torch.tensor([0.0, 0.0], dtype=torch.float64),
        params=None,
        config=SolverConfig(
            method="trust_region",
            linear_solver="cholesky",
            max_iter=4,
            tol=1e-10,
            scaling=ScalingConfig(
                variable_mode=ScalingMode.MANUAL,
                variable_scale=torch.tensor([1e-6, 1e3], dtype=torch.float64),
            ),
        ),
    )

    assert result.success is True
    assert result.history
    first_trial = result.history[0].trials[0]
    assert first_trial.trust_region_radius == pytest.approx(math.sqrt(2.0), rel=1e-9, abs=1e-9)
    assert first_trial.step_norm is not None
    assert first_trial.step_norm <= first_trial.trust_region_radius + 1e-9


def test_gauss_newton_cholesky_failure_returns_structured_result_with_scaling() -> None:
    """A GN linear-solve failure should return a result instead of raising."""

    problem = NonlinearLeastSquaresProblem(
        residual=lambda state, params: torch.stack((state[0] + state[1] - 1.0,))
    )

    result = solve(
        problem,
        x0=torch.tensor([0.0, 0.0], dtype=torch.float64),
        params=None,
        config=SolverConfig(
            method="gauss_newton",
            linear_solver="cholesky",
            scaling=ScalingConfig(
                variable_mode=ScalingMode.MANUAL,
                variable_scale=torch.tensor([2.0, 0.5], dtype=torch.float64),
            ),
            max_iter=2,
            tol=1e-10,
        ),
    )

    assert result.success is False
    assert result.status is SolveStatus.FAILED
    assert result.termination is TerminationReason.NUMERICAL_FAILURE
    assert result.reproducibility["scaling"]["variable_mode"] == "manual"


def test_invalid_manual_scaling_shape_fails_fast() -> None:
    """Manual scaling vectors should match the local model dimensions."""

    problem = NonlinearLeastSquaresProblem(residual=lambda state, params: state - torch.tensor([0.0, 0.0], dtype=state.dtype))

    with pytest.raises(ValueError):
        solve(
            problem,
            x0=torch.tensor([1.0, -1.0], dtype=torch.float64),
            params=None,
            config=SolverConfig(
                method="gauss_newton",
                scaling=ScalingConfig(variable_mode=ScalingMode.MANUAL, variable_scale=torch.tensor([1.0, 2.0, 3.0])),
            ),
        )


def test_invalid_device_request_fails_fast() -> None:
    """Invalid device requests should fail before solver work begins."""

    problem = NonlinearLeastSquaresProblem(residual=lambda state, params: state - params["target"])

    with pytest.raises(ValueError):
        solve(problem, x0=[0.0], params={"target": torch.tensor([0.0])}, config=SolverConfig(device="not-a-device"))


def test_dense_direct_linear_backend_is_recorded() -> None:
    """The default dense-direct backend should be selectable and reported."""

    problem = NonlinearLeastSquaresProblem(residual=lambda state, params: state - params["target"])
    result = solve(
        problem,
        x0=torch.tensor([-2.0], dtype=torch.float64),
        params={"target": torch.tensor([1.5], dtype=torch.float64)},
        config=SolverConfig(method="lm", linear_solver="dense_direct", max_iter=8, tol=1e-10),
    )

    assert result.success is True
    assert result.reproducibility["linear_solver"] == "dense_direct"
    assert torch.allclose(result.x, torch.tensor([1.5], dtype=torch.float64), atol=1e-8)


def test_cholesky_linear_backend_solves_damped_least_squares_step() -> None:
    """The Cholesky backend should solve a positive-definite LM subproblem."""

    problem = NonlinearLeastSquaresProblem(
        residual=lambda state, params: torch.stack(
            (
                state[0] - params["target"],
                2.0 * (state[0] - params["target"]),
            )
        )
    )
    result = solve(
        problem,
        x0=torch.tensor([-5.0], dtype=torch.float64),
        params={"target": 3.0},
        config=SolverConfig(method="lm", linear_solver="cholesky", max_iter=8, tol=1e-10),
    )

    assert result.success is True
    assert result.reproducibility["linear_solver"] == "cholesky"
    assert torch.allclose(result.x, torch.tensor([3.0], dtype=torch.float64), atol=1e-8)


def test_invalid_linear_solver_request_fails_fast() -> None:
    """Unsupported linear backend names should raise a clear error."""

    problem = NonlinearLeastSquaresProblem(residual=lambda state, params: state - params["target"])

    with pytest.raises(ValueError):
        solve(
            problem,
            x0=[0.0],
            params={"target": torch.tensor([0.0])},
            config=SolverConfig(method="lm", linear_solver="not-a-backend"),
        )


def test_unrolled_diff_matches_finite_difference_gradient() -> None:
    """Unrolled least-squares differentiation should match a finite-difference reference."""

    problem = NonlinearLeastSquaresProblem(residual=lambda state, params: torch.exp(state) - params["target"])
    observed_state = torch.tensor([0.4], dtype=torch.float64)
    target = torch.tensor([2.0], dtype=torch.float64, requires_grad=True)

    result = solve(
        problem,
        x0=torch.tensor([-3.0], dtype=torch.float64),
        params={"target": target},
        config=SolverConfig(method="lm", diff_mode=DiffMode.UNROLL, max_iter=20, tol=1e-12),
    )
    loss = 0.5 * torch.sum((result.x - observed_state) ** 2)
    gradient = torch.autograd.grad(loss, target)[0]

    def evaluate_loss_at_target(target_value: float) -> float:
        fd_result = solve(
            problem,
            x0=torch.tensor([-3.0], dtype=torch.float64),
            params={"target": torch.tensor([target_value], dtype=torch.float64)},
            config=SolverConfig(method="lm", max_iter=20, tol=1e-12),
        )
        return float((0.5 * torch.sum((fd_result.x - observed_state) ** 2)).item())

    epsilon = 1e-6
    finite_difference_gradient = (
        evaluate_loss_at_target(2.0 + epsilon) - evaluate_loss_at_target(2.0 - epsilon)
    ) / (2.0 * epsilon)

    assert result.success is True
    assert result.x.requires_grad is True
    assert result.diff_mode_used == DiffMode.UNROLL.value
    assert result.diff_valid is True
    assert "unrolled" in result.diff_reason.lower()
    assert gradient.item() == pytest.approx(finite_difference_gradient, rel=1e-4, abs=1e-5)


@pytest.mark.parametrize(
    ("method", "x0"),
    (
        ("gauss_newton", 0.0),
        ("trust_region", -0.5),
    ),
)
def test_unrolled_diff_matches_analytic_gradient_on_successful_nonlinear_problem(method: str, x0: float) -> None:
    """Successful unrolled nonlinear solves should match the analytic outer gradient for GN and trust-region."""

    problem = NonlinearLeastSquaresProblem(residual=lambda state, params: torch.exp(state) - params["target"])
    observed_state = torch.tensor([0.4], dtype=torch.float64)
    target = torch.tensor([2.0], dtype=torch.float64, requires_grad=True)

    result = solve(
        problem,
        x0=torch.tensor([x0], dtype=torch.float64),
        params={"target": target},
        config=SolverConfig(method=method, diff_mode=DiffMode.UNROLL, max_iter=30, tol=1e-12),
    )
    loss = 0.5 * torch.sum((result.x - observed_state) ** 2)
    gradient = torch.autograd.grad(loss, target)[0]
    expected_gradient = (torch.log(torch.tensor([2.0], dtype=torch.float64)) - observed_state) / torch.tensor([2.0], dtype=torch.float64)

    assert result.success is True
    assert result.x.requires_grad is True
    assert result.diff_mode_used == DiffMode.UNROLL.value
    assert result.diff_valid is True
    assert torch.allclose(result.x, torch.log(torch.tensor([2.0], dtype=torch.float64)), atol=1e-10)
    assert torch.allclose(gradient, expected_gradient, atol=1e-10, rtol=1e-8)


def test_shared_structure_unrolled_diff_matches_stacked_single_solve_gradients() -> None:
    """Shared-structure unrolled gradients should match stacking single-solve unrolled gradients."""

    problem = NonlinearLeastSquaresProblem(residual=lambda state, params: torch.exp(state) - params["target"])
    observed_state = torch.tensor([[0.4], [0.9]], dtype=torch.float64)
    x0_batch = torch.tensor([[-3.0], [-2.0]], dtype=torch.float64)
    target_batch = torch.tensor([[2.0], [3.0]], dtype=torch.float64, requires_grad=True)

    batch_result = solve(
        problem,
        x0=x0_batch,
        params={"target": target_batch},
        config=SolverConfig(
            method="lm",
            diff_mode=DiffMode.UNROLL,
            batch_mode=BatchMode.SHARED_STRUCTURE,
            max_iter=20,
            tol=1e-12,
        ),
    )
    assert isinstance(batch_result, SharedStructureBatchResult)
    batch_loss = 0.5 * torch.sum((batch_result.x - observed_state) ** 2)
    batch_gradient = torch.autograd.grad(batch_loss, target_batch)[0]

    single_target = target_batch.detach().clone().requires_grad_(True)
    single_results = tuple(
        solve(
            problem,
            x0=x0_batch[index],
            params={"target": single_target[index]},
            config=SolverConfig(method="lm", diff_mode=DiffMode.UNROLL, max_iter=20, tol=1e-12),
        )
        for index in range(x0_batch.shape[0])
    )
    single_loss = 0.5 * torch.sum((torch.stack([result.x for result in single_results]) - observed_state) ** 2)
    single_gradient = torch.autograd.grad(single_loss, single_target)[0]

    assert batch_result.x.requires_grad is True
    assert all(result.x.requires_grad for result in batch_result.results)
    assert all(result.success for result in batch_result.results)
    assert all(result.diff_mode_used == DiffMode.UNROLL.value for result in batch_result.results)
    assert all(result.diff_valid is True for result in batch_result.results)
    assert torch.allclose(batch_result.x, torch.stack([result.x for result in single_results]), atol=1e-10)
    assert torch.allclose(batch_gradient, single_gradient, atol=1e-10, rtol=1e-8)


def test_unrolled_diff_is_reported_invalid_when_the_solve_fails() -> None:
    """Unrolled differentiation should not be reported as valid when the solve terminates unsuccessfully."""

    problem = NonlinearLeastSquaresProblem(residual=lambda state, params: torch.exp(state) - params["target"])
    target = torch.tensor([2.0], dtype=torch.float64, requires_grad=True)

    result = solve(
        problem,
        x0=torch.tensor([-3.0], dtype=torch.float64),
        params={"target": target},
        config=SolverConfig(method="gauss_newton", diff_mode=DiffMode.UNROLL, max_iter=20, tol=1e-12),
    )

    assert result.success is False
    assert result.diff_mode_used == DiffMode.UNROLL.value
    assert result.diff_valid is False
    assert "did not terminate successfully" in result.diff_reason.lower()
    assert DiagnosisCode.DIFF_INVALID in result.diagnosis
    assert result.x.requires_grad is False


def test_failed_unrolled_trust_region_solve_detaches_invalid_gradient_path() -> None:
    """Failed unrolled trust-region solves should fail closed by returning a detached state."""

    problem = NonlinearLeastSquaresProblem(
        residual=lambda state, params: torch.exp(state) - params["target"],
        loss=CauchyLoss(c=0.9),
    )
    target = torch.tensor([2.0], dtype=torch.float64, requires_grad=True)

    result = solve(
        problem,
        x0=torch.tensor([-3.0], dtype=torch.float64),
        params={"target": target},
        config=SolverConfig(method="trust_region", diff_mode=DiffMode.UNROLL, max_iter=80, tol=1e-10),
    )

    assert result.success is False
    assert result.status is SolveStatus.MAX_ITER_REACHED
    assert result.termination is TerminationReason.MAX_ITER
    assert result.diff_mode_used == DiffMode.UNROLL.value
    assert result.diff_valid is False
    assert DiagnosisCode.DIFF_INVALID in result.diagnosis
    assert result.x.requires_grad is False


@pytest.mark.parametrize("method", ("gauss_newton", "lm", "trust_region"))
def test_implicit_diff_matches_unrolled_gradient_on_small_certified_problem(method: str) -> None:
    """Implicit differentiation should match unrolled gradients on small certified problems."""

    problem = NonlinearLeastSquaresProblem(residual=lambda state, params: state - params["target"])
    observed_state = torch.tensor([0.4], dtype=torch.float64)

    implicit_target = torch.tensor([2.0], dtype=torch.float64, requires_grad=True)
    implicit_result = solve(
        problem,
        x0=torch.tensor([-3.0], dtype=torch.float64),
        params={"target": implicit_target},
        config=SolverConfig(method=method, diff_mode=DiffMode.IMPLICIT, max_iter=20, tol=1e-12),
    )
    implicit_loss = 0.5 * torch.sum((implicit_result.x - observed_state) ** 2)
    implicit_gradient = torch.autograd.grad(implicit_loss, implicit_target)[0]

    unrolled_target = torch.tensor([2.0], dtype=torch.float64, requires_grad=True)
    unrolled_result = solve(
        problem,
        x0=torch.tensor([-3.0], dtype=torch.float64),
        params={"target": unrolled_target},
        config=SolverConfig(method=method, diff_mode=DiffMode.UNROLL, max_iter=20, tol=1e-12),
    )
    unrolled_loss = 0.5 * torch.sum((unrolled_result.x - observed_state) ** 2)
    unrolled_gradient = torch.autograd.grad(unrolled_loss, unrolled_target)[0]

    assert implicit_result.success is True
    assert implicit_result.diff_mode_used == DiffMode.IMPLICIT.value
    assert implicit_result.diff_valid is True
    assert "certified" in implicit_result.diff_reason.lower()
    assert implicit_result.diff_condition_estimate is not None
    assert implicit_result.diff_linear_residual is not None
    assert implicit_result.x.requires_grad is True
    assert implicit_gradient.item() == pytest.approx(unrolled_gradient.item(), rel=1e-8, abs=1e-10)


@pytest.mark.parametrize("method", ("gauss_newton", "lm", "trust_region"))
def test_implicit_diff_matches_unrolled_gradient_with_scaling(method: str) -> None:
    """Implicit differentiation should stay correct when least-squares scaling is enabled."""

    problem = NonlinearLeastSquaresProblem(
        residual=lambda state, params: torch.stack(
            (
                state[0] - params["target"][0],
                3.0 * (state[1] - params["target"][1]),
            )
        )
    )
    observed_state = torch.tensor([0.4, -1.2], dtype=torch.float64)
    scaling = ScalingConfig(
        variable_mode=ScalingMode.MANUAL,
        residual_mode=ScalingMode.MANUAL,
        variable_scale=torch.tensor([1e-3, 25.0], dtype=torch.float64),
        residual_scale=torch.tensor([50.0, 0.2], dtype=torch.float64),
    )

    implicit_target = torch.tensor([2.0, -0.5], dtype=torch.float64, requires_grad=True)
    implicit_result = solve(
        problem,
        x0=torch.tensor([-3.0, 4.0], dtype=torch.float64),
        params={"target": implicit_target},
        config=SolverConfig(
            method=method,
            diff_mode=DiffMode.IMPLICIT,
            scaling=scaling,
            max_iter=20,
            tol=1e-12,
        ),
    )
    implicit_loss = 0.5 * torch.sum((implicit_result.x - observed_state) ** 2)
    implicit_gradient = torch.autograd.grad(implicit_loss, implicit_target)[0]

    unrolled_target = torch.tensor([2.0, -0.5], dtype=torch.float64, requires_grad=True)
    unrolled_result = solve(
        problem,
        x0=torch.tensor([-3.0, 4.0], dtype=torch.float64),
        params={"target": unrolled_target},
        config=SolverConfig(
            method=method,
            diff_mode=DiffMode.UNROLL,
            scaling=scaling,
            max_iter=20,
            tol=1e-12,
        ),
    )
    unrolled_loss = 0.5 * torch.sum((unrolled_result.x - observed_state) ** 2)
    unrolled_gradient = torch.autograd.grad(unrolled_loss, unrolled_target)[0]
    expected_gradient = implicit_target.detach() - observed_state

    assert implicit_result.success is True
    assert implicit_result.diff_valid is True
    assert implicit_result.x.requires_grad is True
    assert implicit_result.reproducibility["scaling"]["variable_mode"] == "manual"
    assert implicit_result.reproducibility["scaling"]["residual_mode"] == "manual"
    assert torch.allclose(implicit_result.x, implicit_target.detach(), atol=1e-10)
    assert torch.allclose(implicit_gradient, unrolled_gradient, atol=1e-10, rtol=1e-8)
    assert torch.allclose(implicit_gradient, expected_gradient, atol=1e-10, rtol=1e-8)


@pytest.mark.parametrize("method", _SHARED_STRUCTURE_EQUIVALENCE_METHODS)
def test_shared_structure_implicit_diff_matches_stacked_single_solve_gradients(method: str) -> None:
    """Shared-structure implicit gradients should match stacking sequential implicit gradients."""

    problem = NonlinearLeastSquaresProblem(residual=lambda state, params: state - params["target"])
    observed_state = torch.tensor([[0.4], [0.9]], dtype=torch.float64)
    x0_batch = torch.tensor([[-3.0], [-2.0]], dtype=torch.float64)

    batch_target = torch.tensor([[2.0], [3.0]], dtype=torch.float64, requires_grad=True)
    batch_result = solve(
        problem,
        x0=x0_batch,
        params={"target": batch_target},
        config=SolverConfig(
            method=method,
            diff_mode=DiffMode.IMPLICIT,
            batch_mode=BatchMode.SHARED_STRUCTURE,
            max_iter=20,
            tol=1e-12,
        ),
    )
    assert isinstance(batch_result, SharedStructureBatchResult)
    batch_loss = 0.5 * torch.sum((batch_result.x - observed_state) ** 2)
    batch_gradient = torch.autograd.grad(batch_loss, batch_target)[0]

    single_target = torch.tensor([[2.0], [3.0]], dtype=torch.float64, requires_grad=True)
    single_results = tuple(
        solve(
            problem,
            x0=x0_batch[index],
            params={"target": single_target[index]},
            config=SolverConfig(method=method, diff_mode=DiffMode.IMPLICIT, max_iter=20, tol=1e-12),
        )
        for index in range(x0_batch.shape[0])
    )
    single_loss = 0.5 * torch.sum((torch.stack([result.x for result in single_results]) - observed_state) ** 2)
    single_gradient = torch.autograd.grad(single_loss, single_target)[0]

    assert batch_result.x.requires_grad is True
    assert all(result.success for result in batch_result.results)
    assert all(result.diff_valid is True for result in batch_result.results)
    assert all(result.diff_condition_estimate is not None for result in batch_result.results)
    assert all(result.diff_linear_residual is not None for result in batch_result.results)
    assert torch.allclose(batch_result.x, torch.stack([result.x for result in single_results]), atol=1e-10)
    assert torch.allclose(batch_gradient, single_gradient, atol=1e-10, rtol=1e-8)


@pytest.mark.parametrize("method", _SHARED_STRUCTURE_EQUIVALENCE_METHODS)
def test_shared_structure_implicit_diff_supports_nested_params_with_scaling(method: str) -> None:
    """Implicit shared-structure gradients should stay correct with nested params and scaling."""

    problem = NonlinearLeastSquaresProblem(
        residual=lambda state, params: state - (params["nested"]["target"] + params["nested"]["offsets"][0])
    )
    observed_state = torch.tensor([[0.4, -0.9], [1.1, 0.2]], dtype=torch.float64)
    x0_batch = torch.tensor([[-3.0, 1.0], [-2.0, 0.5]], dtype=torch.float64)
    shared_offset = torch.tensor(0.25, dtype=torch.float64)
    scaling = ScalingConfig(
        variable_mode=ScalingMode.MANUAL,
        residual_mode=ScalingMode.MANUAL,
        variable_scale=torch.tensor([1e-2, 10.0], dtype=torch.float64),
        residual_scale=torch.tensor([3.0, 0.25], dtype=torch.float64),
    )

    batch_target = torch.tensor([[2.0, -1.0], [3.0, 0.5]], dtype=torch.float64, requires_grad=True)
    batch_result = solve(
        problem,
        x0=x0_batch,
        params={"nested": {"target": batch_target, "offsets": (shared_offset, [torch.tensor(7.0, dtype=torch.float64)])}},
        config=SolverConfig(
            method=method,
            diff_mode=DiffMode.IMPLICIT,
            batch_mode=BatchMode.SHARED_STRUCTURE,
            scaling=scaling,
            max_iter=20,
            tol=1e-12,
        ),
    )

    assert isinstance(batch_result, SharedStructureBatchResult)
    batch_loss = 0.5 * torch.sum((batch_result.x - observed_state) ** 2)
    batch_gradient = torch.autograd.grad(batch_loss, batch_target)[0]

    single_target = batch_target.detach().clone().requires_grad_(True)
    single_results = tuple(
        solve(
            problem,
            x0=x0_batch[index],
            params={
                "nested": {
                    "target": single_target[index],
                    "offsets": (shared_offset, [torch.tensor(7.0, dtype=torch.float64)]),
                }
            },
            config=SolverConfig(
                method=method,
                diff_mode=DiffMode.IMPLICIT,
                scaling=scaling,
                max_iter=20,
                tol=1e-12,
            ),
        )
        for index in range(x0_batch.shape[0])
    )
    single_loss = 0.5 * torch.sum((torch.stack([result.x for result in single_results]) - observed_state) ** 2)
    single_gradient = torch.autograd.grad(single_loss, single_target)[0]
    expected_gradient = batch_target.detach() + shared_offset - observed_state

    assert batch_result.x.requires_grad is True
    assert all(result.success for result in batch_result.results)
    assert all(result.diff_valid is True for result in batch_result.results)
    assert all(result.x.requires_grad for result in batch_result.results)
    assert torch.allclose(batch_result.x, torch.stack([result.x for result in single_results]), atol=1e-10)
    assert torch.allclose(batch_gradient, single_gradient, atol=1e-10, rtol=1e-8)
    assert torch.allclose(batch_gradient, expected_gradient, atol=1e-10, rtol=1e-8)


def test_implicit_diff_request_is_invalid_without_differentiable_params() -> None:
    """Implicit differentiation should report invalidity when no differentiable parameter tensors exist."""

    problem = NonlinearLeastSquaresProblem(residual=lambda state, params: state - params["target"])
    result = solve(
        problem,
        x0=torch.tensor([-3.0], dtype=torch.float64),
        params={"target": torch.tensor([2.0], dtype=torch.float64)},
        config=SolverConfig(method="lm", diff_mode=DiffMode.IMPLICIT, max_iter=10, tol=1e-10),
    )

    assert result.success is True
    assert result.diff_mode_used == DiffMode.IMPLICIT.value
    assert result.diff_valid is False
    assert "differentiable parameter tensor" in result.diff_reason.lower()
    assert DiagnosisCode.DIFF_INVALID in result.diagnosis
    assert result.reproducibility["diff_mode"] == DiffMode.IMPLICIT.value


def test_implicit_diff_request_is_invalid_for_nonconverged_solve() -> None:
    """Implicit differentiation should fail closed when the solve is not certifiably converged."""

    problem = NonlinearLeastSquaresProblem(residual=lambda state, params: torch.exp(state) - params["target"])
    target = torch.tensor([2.0], dtype=torch.float64, requires_grad=True)
    result = solve(
        problem,
        x0=torch.tensor([-3.0], dtype=torch.float64),
        params={"target": target},
        config=SolverConfig(method="lm", diff_mode=DiffMode.IMPLICIT, max_iter=1, tol=1e-12),
    )

    assert result.success is False
    assert result.diff_mode_used == DiffMode.IMPLICIT.value
    assert result.diff_valid is False
    assert "converged" in result.diff_reason.lower()
    assert DiagnosisCode.DIFF_INVALID in result.diagnosis


def test_implicit_diff_request_is_invalid_for_ill_conditioned_terminal_system() -> None:
    """Implicit differentiation should fail closed when the terminal system is too ill-conditioned."""

    problem = NonlinearLeastSquaresProblem(
        residual=lambda state, params: torch.stack(
            (
                state[0] - params["target"][0],
                1e-6 * (state[1] - params["target"][1]),
            )
        )
    )
    target = torch.tensor([2.0, -1.0], dtype=torch.float64, requires_grad=True)
    result = solve(
        problem,
        x0=torch.tensor([-3.0, 4.0], dtype=torch.float64),
        params={"target": target},
        config=SolverConfig(method="gauss_newton", diff_mode=DiffMode.IMPLICIT, max_iter=10, tol=1e-12),
    )

    assert result.success is True
    assert result.diff_mode_used == DiffMode.IMPLICIT.value
    assert result.diff_valid is False
    assert "ill-conditioned" in result.diff_reason.lower()
    assert DiagnosisCode.DIFF_INVALID in result.diagnosis
    assert result.diff_condition_estimate is not None
    assert result.diff_condition_estimate > 1e8
    assert result.diff_linear_residual is None
    assert result.x.requires_grad is False


@pytest.mark.parametrize("method", ("lm", "trust_region"))
def test_implicit_diff_matches_unrolled_gradient_with_auto_variable_scaling(method: str) -> None:
    """Implicit differentiation should stay correct when automatic variable scaling evolves across iterations."""

    problem = NonlinearLeastSquaresProblem(
        residual=lambda state, params: torch.stack(
            (
                torch.exp(state[0]) - params["target"][0],
                1e4 * (state[1] - params["target"][1]),
            )
        )
    )
    observed_state = torch.tensor([0.4, -1.2], dtype=torch.float64)
    scaling = ScalingConfig(variable_mode=ScalingMode.AUTO)

    implicit_target = torch.tensor([2.0, -0.5], dtype=torch.float64, requires_grad=True)
    implicit_result = solve(
        problem,
        x0=torch.tensor([-3.0, 4.0], dtype=torch.float64),
        params={"target": implicit_target},
        config=SolverConfig(
            method=method,
            diff_mode=DiffMode.IMPLICIT,
            scaling=scaling,
            max_iter=30,
            tol=1e-12,
        ),
    )
    implicit_loss = 0.5 * torch.sum((implicit_result.x - observed_state) ** 2)
    implicit_gradient = torch.autograd.grad(implicit_loss, implicit_target)[0]

    unrolled_target = torch.tensor([2.0, -0.5], dtype=torch.float64, requires_grad=True)
    unrolled_result = solve(
        problem,
        x0=torch.tensor([-3.0, 4.0], dtype=torch.float64),
        params={"target": unrolled_target},
        config=SolverConfig(
            method=method,
            diff_mode=DiffMode.UNROLL,
            scaling=scaling,
            max_iter=30,
            tol=1e-12,
        ),
    )
    unrolled_loss = 0.5 * torch.sum((unrolled_result.x - observed_state) ** 2)
    unrolled_gradient = torch.autograd.grad(unrolled_loss, unrolled_target)[0]

    assert implicit_result.success is True
    assert implicit_result.diff_valid is True
    assert implicit_result.reproducibility["scaling"]["variable_mode"] == "auto"
    assert implicit_result.x.requires_grad is True
    assert torch.allclose(implicit_gradient, unrolled_gradient, atol=1e-9, rtol=1e-7)


@pytest.mark.parametrize("method", _SHARED_STRUCTURE_EQUIVALENCE_METHODS)
def test_shared_structure_implicit_diff_preserves_mixed_certification(method: str) -> None:
    """Shared-structure implicit batches should allow one certified gradient path beside one fail-closed element."""

    problem = NonlinearLeastSquaresProblem(
        residual=lambda state, params: params["scale"] * (state - params["target"])
    )
    observed_state = torch.tensor([[0.4, -0.9], [1.1, 0.2]], dtype=torch.float64)
    x0_batch = torch.tensor([[-3.0, 1.0], [-2.0, 0.5]], dtype=torch.float64)
    batch_target = torch.tensor([[2.0, -1.0], [3.0, 0.5]], dtype=torch.float64, requires_grad=True)
    batch_result = solve(
        problem,
        x0=x0_batch,
        params={
            "target": batch_target,
            "scale": torch.tensor([[1.0, 1.0], [1.0, 1e-6]], dtype=torch.float64),
        },
        config=SolverConfig(
            method=method,
            diff_mode=DiffMode.IMPLICIT,
            batch_mode=BatchMode.SHARED_STRUCTURE,
            max_iter=20,
            tol=1e-12,
        ),
    )

    assert isinstance(batch_result, SharedStructureBatchResult)
    batch_loss = 0.5 * torch.sum((batch_result.x - observed_state) ** 2)
    batch_gradient = torch.autograd.grad(batch_loss, batch_target)[0]

    assert all(result.success for result in batch_result.results)
    assert batch_result.results[0].diff_valid is True
    assert batch_result.results[1].diff_valid is False
    assert "ill-conditioned" in batch_result.results[1].diff_reason.lower()
    assert batch_result.results[1].diff_condition_estimate is not None
    assert DiagnosisCode.DIFF_INVALID in batch_result.results[1].diagnosis
    assert torch.allclose(batch_gradient[0], batch_target.detach()[0] - observed_state[0], atol=1e-10, rtol=1e-8)
    assert torch.allclose(batch_gradient[1], torch.zeros_like(batch_gradient[1]), atol=1e-12, rtol=0.0)


@pytest.mark.parametrize(
    ("loss", "method", "tol"),
    (
        (HuberLoss(delta=0.75), "lm", 1e-7),
        (CauchyLoss(c=0.9), "lm", 1e-7),
        (SoftL1Loss(c=1.2), "lm", 1e-7),
    ),
)
def test_implicit_diff_matches_unrolled_gradient_with_robust_loss(
    loss: HuberLoss | CauchyLoss | SoftL1Loss,
    method: str,
    tol: float,
) -> None:
    """Implicit and unrolled differentiation should match on a nonlinear robust least-squares problem."""

    observed_state = torch.tensor([0.4], dtype=torch.float64)

    def residual_fn(state: torch.Tensor, params: dict[str, torch.Tensor]) -> torch.Tensor:
        return torch.exp(state) - params["target"]

    problem = NonlinearLeastSquaresProblem(residual=residual_fn, loss=loss)

    implicit_target = torch.tensor([2.0], dtype=torch.float64, requires_grad=True)
    implicit_result = solve(
        problem,
        x0=torch.tensor([-3.0], dtype=torch.float64),
        params={"target": implicit_target},
        config=SolverConfig(method=method, diff_mode=DiffMode.IMPLICIT, max_iter=80, tol=1e-10),
    )
    implicit_loss = 0.5 * torch.sum((implicit_result.x - observed_state) ** 2)
    implicit_gradient = torch.autograd.grad(implicit_loss, implicit_target)[0]

    unrolled_target = torch.tensor([2.0], dtype=torch.float64, requires_grad=True)
    unrolled_result = solve(
        problem,
        x0=torch.tensor([-3.0], dtype=torch.float64),
        params={"target": unrolled_target},
        config=SolverConfig(method=method, diff_mode=DiffMode.UNROLL, max_iter=80, tol=1e-10),
    )
    unrolled_loss = 0.5 * torch.sum((unrolled_result.x - observed_state) ** 2)
    unrolled_gradient = torch.autograd.grad(unrolled_loss, unrolled_target)[0]

    expected_gradient = (torch.log(torch.tensor([2.0], dtype=torch.float64)) - observed_state) / torch.tensor([2.0], dtype=torch.float64)

    assert implicit_result.success is True
    assert implicit_result.diff_valid is True
    assert implicit_result.x.requires_grad is True
    assert unrolled_result.success is True
    assert unrolled_result.diff_valid is True
    assert unrolled_result.x.requires_grad is True
    assert torch.allclose(implicit_result.x, torch.log(torch.tensor([2.0], dtype=torch.float64)), atol=1e-10)
    assert torch.allclose(unrolled_result.x, torch.log(torch.tensor([2.0], dtype=torch.float64)), atol=1e-10)
    assert torch.allclose(implicit_gradient, expected_gradient, atol=tol, rtol=1e-6)
    assert torch.allclose(unrolled_gradient, expected_gradient, atol=tol, rtol=1e-6)
    assert torch.allclose(unrolled_gradient, implicit_gradient, atol=tol, rtol=1e-6)


def test_trust_region_cauchy_exp_problem_needs_more_iterations_not_a_step_rejection_fix() -> None:
    """The hard Cauchy exponential case should show steady accepted progress and converge with more budget."""

    def residual_fn(state: torch.Tensor, params: dict[str, torch.Tensor]) -> torch.Tensor:
        return torch.exp(state) - params["target"]

    problem = NonlinearLeastSquaresProblem(residual=residual_fn, loss=CauchyLoss(c=0.9))
    short_budget = solve(
        problem,
        x0=torch.tensor([-3.0], dtype=torch.float64),
        params={"target": torch.tensor([2.0], dtype=torch.float64)},
        config=SolverConfig(method="trust_region", max_iter=80, tol=1e-10),
    )
    long_budget = solve(
        problem,
        x0=torch.tensor([-3.0], dtype=torch.float64),
        params={"target": torch.tensor([2.0], dtype=torch.float64)},
        config=SolverConfig(method="trust_region", max_iter=200, tol=1e-10),
    )

    assert short_budget.success is False
    assert short_budget.status is SolveStatus.MAX_ITER_REACHED
    assert short_budget.termination is TerminationReason.MAX_ITER
    assert DiagnosisCode.STEP_REJECTED not in short_budget.diagnosis
    assert short_budget.history[-1].accepted is True
    assert short_budget.history[-1].trust_region_ratio is not None
    assert short_budget.history[-1].trust_region_ratio > 1.0
    assert short_budget.history[-1].objective_value < short_budget.history[0].objective_value

    assert long_budget.success is True
    assert long_budget.status is SolveStatus.CONVERGED
    assert long_budget.termination is TerminationReason.GRADIENT_TOL
    assert torch.allclose(long_budget.x, torch.log(torch.tensor([2.0], dtype=torch.float64)), atol=1e-10)
    assert long_budget.objective_value == pytest.approx(0.0, abs=1e-12)


@pytest.mark.skipif(not torch.cuda.is_available(), reason="CUDA is not available in the test environment.")
def test_explicit_cuda_device_selection_moves_state_and_params() -> None:
    """The solver should move state and params onto CUDA when requested."""

    observed: list[tuple[str, str]] = []

    def residual(state: torch.Tensor, params: dict[str, torch.Tensor]) -> torch.Tensor:
        observed.append((state.device.type, params["target"].device.type))
        return state - params["target"]

    problem = NonlinearLeastSquaresProblem(residual=residual)
    result = solve(
        problem,
        x0=[-3.0],
        params={"target": torch.tensor([2.0], dtype=torch.float64)},
        config=SolverConfig(method="lm", device="cuda", max_iter=10, tol=1e-10),
    )

    assert result.success is True
    assert str(result.x.device).startswith("cuda")
    assert result.reproducibility["requested_device"].startswith("cuda")
    assert result.reproducibility["solve_device"].startswith("cuda")
    assert observed and all(state_device == "cuda" and target_device == "cuda" for state_device, target_device in observed)


@pytest.mark.skipif(not torch.cuda.is_available(), reason="CUDA is not available in the test environment.")
def test_implicit_cuda_device_selection_moves_params_to_state_device() -> None:
    """The solver should honor the device already carried by the initial state."""

    observed: list[tuple[str, str]] = []

    def residual(state: torch.Tensor, params: dict[str, torch.Tensor]) -> torch.Tensor:
        observed.append((state.device.type, params["target"].device.type))
        return state - params["target"]

    problem = NonlinearLeastSquaresProblem(residual=residual)
    result = solve(
        problem,
        x0=torch.tensor([-3.0], dtype=torch.float64, device="cuda"),
        params={"target": torch.tensor([2.0], dtype=torch.float64)},
        config=SolverConfig(method="lm", max_iter=10, tol=1e-10),
    )

    assert result.success is True
    assert str(result.x.device).startswith("cuda")
    assert result.reproducibility["requested_device"] is None
    assert result.reproducibility["solve_device"].startswith("cuda")
    assert observed and all(state_device == "cuda" and target_device == "cuda" for state_device, target_device in observed)


# ---------------------------------------------------------------------------
# Robust loss tests (M3)
# ---------------------------------------------------------------------------


def test_huber_loss_weights_are_one_for_inliers_and_smaller_for_outliers() -> None:
    """HuberLoss should return unit weights for small residuals and reduced weights for large ones."""

    loss = HuberLoss(delta=1.0)
    residuals = torch.tensor([-3.0, -0.5, 0.0, 0.5, 3.0], dtype=torch.float64)
    weights = loss.weights(residuals)

    # Inlier residuals (|r| <= delta=1.0) should have weight 1.
    assert weights[1].item() == pytest.approx(1.0, abs=1e-12)
    assert weights[2].item() == pytest.approx(1.0, abs=1e-12)
    assert weights[3].item() == pytest.approx(1.0, abs=1e-12)

    # Outlier residuals (|r| > delta=1.0) should have weight < 1.
    assert weights[0].item() == pytest.approx(1.0 / 3.0, rel=1e-9)
    assert weights[4].item() == pytest.approx(1.0 / 3.0, rel=1e-9)

    # Weights are always non-negative.
    assert torch.all(weights >= 0).item()


def test_cauchy_loss_weights_decrease_monotonically_with_residual_magnitude() -> None:
    """CauchyLoss weights should be 1 at zero and decrease as |r| grows."""

    loss = CauchyLoss(c=1.0)
    abs_r = torch.tensor([0.0, 0.5, 1.0, 2.0, 5.0], dtype=torch.float64)
    weights = loss.weights(abs_r)

    assert weights[0].item() == pytest.approx(1.0, abs=1e-12)
    assert torch.all(weights[1:] < weights[:-1]).item()
    assert torch.all(weights >= 0).item()


def test_soft_l1_loss_weights_decrease_monotonically_with_residual_magnitude() -> None:
    """SoftL1Loss weights should be 1 at zero and decrease as |r| grows."""

    loss = SoftL1Loss(c=1.0)
    abs_r = torch.tensor([0.0, 0.5, 1.0, 2.0, 5.0], dtype=torch.float64)
    weights = loss.weights(abs_r)

    assert weights[0].item() == pytest.approx(1.0, abs=1e-12)
    assert torch.all(weights[1:] < weights[:-1]).item()
    assert torch.all(weights >= 0).item()


@pytest.mark.parametrize(
    ("loss", "sample_point"),
    [
        (HuberLoss(delta=0.75), torch.tensor([0.7, -1.1], dtype=torch.float64)),
        (CauchyLoss(c=0.9), torch.tensor([0.7, -1.1], dtype=torch.float64)),
        (SoftL1Loss(c=1.2), torch.tensor([0.7, -1.1], dtype=torch.float64)),
    ],
)
def test_robust_local_model_gradient_matches_true_objective_gradient(
    loss: HuberLoss | CauchyLoss | SoftL1Loss,
    sample_point: torch.Tensor,
) -> None:
    """Robust local-model gradients should match the true robust objective gradient."""

    def residual_fn(state: torch.Tensor, _params: None) -> torch.Tensor:
        return torch.stack(
            (
                state[0] + 2.0 * state[1] - 1.0,
                state[0] ** 2 - state[1],
                0.5 * state[0] - state[1] ** 2,
            )
        )

    problem = NonlinearLeastSquaresProblem(residual=residual_fn, loss=loss)
    evaluation = evaluate_dense_least_squares(problem, sample_point)

    sample_point_with_grad = sample_point.clone().requires_grad_(True)
    residual_value = residual_fn(sample_point_with_grad, None)
    objective_value = loss.value(residual_value).sum()
    expected_gradient = torch.autograd.grad(objective_value, sample_point_with_grad)[0]

    assert torch.allclose(evaluation.gradient, expected_gradient, atol=1e-10)


@pytest.mark.parametrize(
    ("loss", "sample_point"),
    [
        (HuberLoss(delta=0.75), torch.tensor([0.7, -1.1], dtype=torch.float64)),
        (CauchyLoss(c=0.9), torch.tensor([0.7, -1.1], dtype=torch.float64)),
        (SoftL1Loss(c=1.2), torch.tensor([0.7, -1.1], dtype=torch.float64)),
    ],
)
def test_robust_local_model_jacobian_is_row_weighted_raw_jacobian(
    loss: HuberLoss | CauchyLoss | SoftL1Loss,
    sample_point: torch.Tensor,
) -> None:
    """Robust local-model Jacobians should be the IRLS-weighted raw Jacobian."""

    def residual_fn(state: torch.Tensor, _params: None) -> torch.Tensor:
        return torch.stack(
            (
                state[0] + 2.0 * state[1] - 1.0,
                state[0] ** 2 - state[1],
                0.5 * state[0] - state[1] ** 2,
            )
        )

    problem = NonlinearLeastSquaresProblem(residual=residual_fn, loss=loss)
    evaluation = evaluate_dense_least_squares(problem, sample_point)

    raw_residual = residual_fn(sample_point, None)
    raw_jacobian = torch.autograd.functional.jacobian(lambda state: residual_fn(state, None), sample_point)
    sqrt_weights = torch.sqrt(loss.weights(raw_residual))
    expected_weighted_jacobian = sqrt_weights.unsqueeze(1) * raw_jacobian

    assert torch.allclose(evaluation.jacobian, expected_weighted_jacobian, atol=1e-10)


def test_huber_loss_value_is_consistent_with_quadratic_and_linear_branches() -> None:
    """HuberLoss.value should match the analytical formula on both branches."""

    delta = 1.5
    loss = HuberLoss(delta=delta)
    r_in = torch.tensor([0.5], dtype=torch.float64)  # inlier
    r_out = torch.tensor([3.0], dtype=torch.float64)  # outlier

    assert loss.value(r_in).item() == pytest.approx(0.5 * 0.5 ** 2, rel=1e-9)
    assert loss.value(r_out).item() == pytest.approx(delta * (3.0 - 0.5 * delta), rel=1e-9)


def test_cauchy_loss_value_matches_analytical_formula() -> None:
    """CauchyLoss.value should match (c^2/2)*log(1+(r/c)^2)."""

    c = 2.0
    loss = CauchyLoss(c=c)
    r = torch.tensor([3.0], dtype=torch.float64)

    expected = 0.5 * c ** 2 * math.log(1 + (3.0 / c) ** 2)
    assert loss.value(r).item() == pytest.approx(expected, rel=1e-9)


def test_soft_l1_loss_value_matches_analytical_formula() -> None:
    """SoftL1Loss.value should match c^2*(sqrt(1+(r/c)^2)-1)."""

    c = 1.0
    loss = SoftL1Loss(c=c)
    r = torch.tensor([2.0], dtype=torch.float64)

    expected = c ** 2 * (math.sqrt(1 + (2.0 / c) ** 2) - 1.0)
    assert loss.value(r).item() == pytest.approx(expected, rel=1e-9)


def test_huber_loss_reduces_outlier_sensitivity_in_linear_regression() -> None:
    """HuberLoss should produce a better fit than squared loss when outliers are present.

    The true linear model is y = 2*x.  One point is corrupted by a large
    outlier.  The squared-loss fit is pulled toward the outlier; the Huber fit
    should recover a slope much closer to the true value 2.
    """

    x_data = torch.tensor([1.0, 2.0, 3.0, 4.0, 5.0], dtype=torch.float64)
    y_clean = 2.0 * x_data
    # Corrupt the last point with a large outlier.
    y_observed = y_clean.clone()
    y_observed[-1] = 100.0

    def residual_fn(state: torch.Tensor, params: dict) -> torch.Tensor:
        slope = state[0]
        return slope * params["x"] - params["y"]

    params = {"x": x_data, "y": y_observed}
    x0 = torch.tensor([1.0], dtype=torch.float64)

    squared_result = solve(
        NonlinearLeastSquaresProblem(residual=residual_fn),
        x0=x0,
        params=params,
        config=SolverConfig(method="lm", max_iter=30, tol=1e-6),
    )
    huber_result = solve(
        NonlinearLeastSquaresProblem(residual=residual_fn, loss=HuberLoss(delta=1.0)),
        x0=x0,
        params=params,
        config=SolverConfig(method="lm", max_iter=30, tol=1e-6),
    )

    squared_slope = squared_result.x[0].item()
    huber_slope = huber_result.x[0].item()

    assert huber_result.success is True
    assert squared_result.success is True

    # The Huber estimate should be closer to the true slope of 2.
    assert abs(huber_slope - 2.0) < abs(squared_slope - 2.0)


def test_cauchy_loss_reduces_outlier_sensitivity_in_linear_regression() -> None:
    """CauchyLoss should produce a better fit than squared loss when outliers are present."""

    x_data = torch.tensor([1.0, 2.0, 3.0, 4.0, 5.0], dtype=torch.float64)
    y_clean = 2.0 * x_data
    y_observed = y_clean.clone()
    y_observed[-1] = 100.0

    def residual_fn(state: torch.Tensor, params: dict) -> torch.Tensor:
        return state[0] * params["x"] - params["y"]

    params = {"x": x_data, "y": y_observed}
    x0 = torch.tensor([1.0], dtype=torch.float64)

    squared_result = solve(
        NonlinearLeastSquaresProblem(residual=residual_fn),
        x0=x0,
        params=params,
        config=SolverConfig(method="lm", max_iter=30, tol=1e-6),
    )
    cauchy_result = solve(
        NonlinearLeastSquaresProblem(residual=residual_fn, loss=CauchyLoss(c=1.0)),
        x0=x0,
        params=params,
        config=SolverConfig(method="lm", max_iter=30, tol=1e-8),
    )

    squared_slope = squared_result.x[0].item()
    cauchy_slope = cauchy_result.x[0].item()

    assert cauchy_result.success is True
    assert squared_result.success is True
    assert abs(cauchy_slope - 2.0) < abs(squared_slope - 2.0)


def test_soft_l1_loss_reduces_outlier_sensitivity_in_linear_regression() -> None:
    """SoftL1Loss should produce a better fit than squared loss when outliers are present."""

    x_data = torch.tensor([1.0, 2.0, 3.0, 4.0, 5.0], dtype=torch.float64)
    y_clean = 2.0 * x_data
    y_observed = y_clean.clone()
    y_observed[-1] = 100.0

    def residual_fn(state: torch.Tensor, params: dict) -> torch.Tensor:
        return state[0] * params["x"] - params["y"]

    params = {"x": x_data, "y": y_observed}
    x0 = torch.tensor([1.0], dtype=torch.float64)

    squared_result = solve(
        NonlinearLeastSquaresProblem(residual=residual_fn),
        x0=x0,
        params=params,
        config=SolverConfig(method="lm", max_iter=30, tol=1e-6),
    )
    soft_l1_result = solve(
        NonlinearLeastSquaresProblem(residual=residual_fn, loss=SoftL1Loss(c=1.0)),
        x0=x0,
        params=params,
        config=SolverConfig(method="lm", max_iter=30, tol=1e-6),
    )

    squared_slope = squared_result.x[0].item()
    soft_l1_slope = soft_l1_result.x[0].item()

    assert soft_l1_result.success is True
    assert squared_result.success is True
    assert abs(soft_l1_slope - 2.0) < abs(squared_slope - 2.0)


def test_lm_reports_step_tolerance_convergence_when_objective_is_unchanged_at_the_solution() -> None:
    """LM should not report failure when only tiny non-decreasing steps remain at the exact solution."""

    x_data = torch.tensor([1.0, 2.0, 3.0, 4.0], dtype=torch.float64)
    y_data = torch.tensor([2.0, 4.0, 6.0, 8.0], dtype=torch.float64)

    def residual_fn(state: torch.Tensor, params: dict[str, torch.Tensor]) -> torch.Tensor:
        return state[0] * params["x"] - params["y"]

    result = solve(
        NonlinearLeastSquaresProblem(residual=residual_fn, loss=SoftL1Loss(c=1.2)),
        x0=torch.tensor([1.0], dtype=torch.float64),
        params={"x": x_data, "y": y_data},
        config=SolverConfig(method="lm", max_iter=20, tol=1e-12),
    )

    assert result.success is True
    assert result.status is SolveStatus.CONVERGED
    assert result.termination is TerminationReason.STEP_TOL
    assert DiagnosisCode.STEP_REJECTED not in result.diagnosis
    assert torch.allclose(result.x, torch.tensor([2.0], dtype=torch.float64), atol=1e-10)
    assert result.objective_value == pytest.approx(0.0, abs=1e-12)


def test_robust_loss_solve_without_outliers_matches_squared_loss() -> None:
    """On clean data, robust and squared losses should converge to the same solution."""

    x_data = torch.tensor([1.0, 2.0, 3.0, 4.0, 5.0], dtype=torch.float64)
    y_data = 2.0 * x_data

    def residual_fn(state: torch.Tensor, params: dict) -> torch.Tensor:
        return state[0] * params["x"] - params["y"]

    params = {"x": x_data, "y": y_data}
    x0 = torch.tensor([1.0], dtype=torch.float64)

    squared_result = solve(
        NonlinearLeastSquaresProblem(residual=residual_fn),
        x0=x0,
        params=params,
        config=SolverConfig(method="lm", max_iter=30, tol=1e-6),
    )
    huber_result = solve(
        NonlinearLeastSquaresProblem(residual=residual_fn, loss=HuberLoss(delta=1.0)),
        x0=x0,
        params=params,
        config=SolverConfig(method="lm", max_iter=30, tol=1e-6),
    )

    assert squared_result.success is True
    assert huber_result.success is True
    assert torch.allclose(squared_result.x, huber_result.x, atol=1e-6)


def test_robust_loss_gradient_is_zero_at_exact_solution() -> None:
    """The solver gradient norm should be near zero at the robust-loss minimizer."""

    x_data = torch.tensor([1.0, 2.0, 3.0, 4.0], dtype=torch.float64)
    y_data = 3.0 * x_data

    def residual_fn(state: torch.Tensor, params: dict) -> torch.Tensor:
        return state[0] * params["x"] - params["y"]

    result = solve(
        NonlinearLeastSquaresProblem(residual=residual_fn, loss=HuberLoss(delta=0.5)),
        x0=torch.tensor([1.0], dtype=torch.float64),
        params={"x": x_data, "y": y_data},
        config=SolverConfig(method="lm", max_iter=30, tol=1e-6),
    )

    assert result.success is True
    assert result.gradient_norm == pytest.approx(0.0, abs=1e-8)
    assert torch.allclose(result.x, torch.tensor([3.0], dtype=torch.float64), atol=1e-8)
