from __future__ import annotations

import importlib.util
import sys
from pathlib import Path

from torch.profiler import ProfilerActivity


MODULE_PATH = Path(__file__).resolve().parents[2] / "benchmarks" / "profile_benchmarks.py"
SPEC = importlib.util.spec_from_file_location("profile_benchmarks", MODULE_PATH)
assert SPEC is not None
assert SPEC.loader is not None
profile_benchmarks = importlib.util.module_from_spec(SPEC)
sys.path.insert(0, str(MODULE_PATH.parent))
sys.modules.setdefault("profile_benchmarks", profile_benchmarks)
SPEC.loader.exec_module(profile_benchmarks)


def test_parse_args_accepts_explicit_scenario() -> None:
    args = profile_benchmarks.parse_args(
        [
            "--method",
            "trust_region",
            "--device",
            "cuda",
            "--batch-size",
            "64",
            "--timepoints",
            "200",
            "--capture-history",
            "true",
            "--execution",
            "sequential",
            "--verbose",
            "--force",
        ]
    )

    assert args.method == "trust_region"
    assert args.device == "cuda"
    assert args.batch_size == 64
    assert args.timepoints == 200
    assert args.capture_history is True
    assert args.execution == "sequential"
    assert args.verbose is True
    assert args.force is True


def test_profile_output_stem_is_scenario_specific() -> None:
    stem = profile_benchmarks._profile_output_stem(
        method="trust_region",
        device="cuda",
        batch_size=32,
        timepoints=100,
        capture_history=False,
        execution="batch",
    )

    assert stem == "trust_region_batch_cuda_bs32_tp100_history_off"


def test_cpu_activities_exclude_cuda() -> None:
    activities = profile_benchmarks._activities_for_device(profile_benchmarks.torch.device("cpu"))

    assert activities == [ProfilerActivity.CPU]


class _FakeEvent:
    def __init__(
        self,
        key: str,
        *,
        count: int,
        self_cpu_time_total: float,
        cpu_time_total: float,
        self_cuda_time_total: float = 0.0,
        cuda_time_total: float = 0.0,
    ) -> None:
        self.key = key
        self.count = count
        self.self_cpu_time_total = self_cpu_time_total
        self.cpu_time_total = cpu_time_total
        self.self_cuda_time_total = self_cuda_time_total
        self.cuda_time_total = cuda_time_total


def test_build_category_breakdown_groups_related_ops() -> None:
    rows = profile_benchmarks._build_category_breakdown(
        [
            _FakeEvent("cudaMemcpyAsync", count=10, self_cpu_time_total=1000.0, cpu_time_total=1000.0),
            _FakeEvent("aten::copy_", count=20, self_cpu_time_total=500.0, cpu_time_total=500.0),
            _FakeEvent("aten::nonzero", count=5, self_cpu_time_total=700.0, cpu_time_total=900.0),
            _FakeEvent("aten::mul", count=8, self_cpu_time_total=300.0, cpu_time_total=600.0),
            _FakeEvent("aten::view", count=8, self_cpu_time_total=200.0, cpu_time_total=200.0),
            _FakeEvent("aten::empty", count=8, self_cpu_time_total=150.0, cpu_time_total=150.0),
        ]
    )

    names = [row["category"] for row in rows]
    assert "transfer_conversion" in names
    assert "indexing_masking" in names
    assert "dense_math" in names
    assert "shape_view" in names
    assert "allocation_init" in names


def test_categorize_op_matches_kernel_substrings() -> None:
    assert profile_benchmarks._categorize_op("Memcpy DtoH (Device -> Pageable)") == "transfer_conversion"
    assert profile_benchmarks._categorize_op("_Z33batched_svd_parallel_jacobi_32x16IddEv") == "dense_math"
    assert profile_benchmarks._categorize_op("DeviceSelectSweepKernel_Nonzero") == "indexing_masking"


def test_render_text_summary_is_descriptive_not_interpretive() -> None:
    rendered = profile_benchmarks._render_text_summary(
        metadata={
            "method": "trust_region",
            "execution": "batch",
            "device": "cuda",
            "batch_size": 32,
            "timepoints": 100,
            "capture_history": False,
        },
        category_breakdown=[
            {"category": "transfer_conversion", "self_cpu_ms": 20.0, "self_cpu_pct": 40.0, "self_device_ms": 2.0, "self_device_pct": 10.0, "calls": 10},
        ],
        top_ops=[
            {"name": "cudaMemcpyAsync", "self_cpu_ms": 10.0, "self_device_ms": 0.0, "calls": 5},
        ],
    )

    assert "Headline findings" not in rendered
    assert "Category breakdown" in rendered
    assert "Top ops" in rendered