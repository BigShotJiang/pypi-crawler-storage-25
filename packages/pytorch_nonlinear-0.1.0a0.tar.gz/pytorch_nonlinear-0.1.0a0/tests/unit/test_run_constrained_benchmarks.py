from __future__ import annotations

import importlib.util
import sys
from pathlib import Path


MODULE_PATH = Path(__file__).resolve().parents[2] / "benchmarks" / "run_constrained_benchmarks.py"
SPEC = importlib.util.spec_from_file_location("run_constrained_benchmarks", MODULE_PATH)
assert SPEC is not None
assert SPEC.loader is not None
run_constrained_benchmarks = importlib.util.module_from_spec(SPEC)
sys.path.insert(0, str(MODULE_PATH.parent))
sys.modules.setdefault("run_constrained_benchmarks", run_constrained_benchmarks)
SPEC.loader.exec_module(run_constrained_benchmarks)


def test_parse_args_accepts_cuda_devices_and_force_flag() -> None:
    args = run_constrained_benchmarks.parse_args(
        [
            "--method",
            "sqp",
            "--scenarios",
            "quadratic_equality_bounds_large",
            "quadratic_multi_equality_bounds_large",
            "--devices",
            "cpu",
            "cuda",
            "--hessian-model",
            "exact",
            "--repeats",
            "5",
            "--force",
        ]
    )

    assert args.scenarios == [
        "quadratic_equality_bounds_large",
        "quadratic_multi_equality_bounds_large",
    ]
    assert args.method == "sqp"
    assert args.devices == ["cpu", "cuda"]
    assert args.hessian_model == "exact"
    assert args.repeats == 5
    assert args.force is True


def test_parse_args_uses_ip_default_medium_large_xlarge_suite() -> None:
    args = run_constrained_benchmarks.parse_args(["--method", "interior_point"])

    assert args.method == "interior_point"
    assert args.scenarios == [
        "quadratic_mixed_constraints_medium",
        "quadratic_mixed_constraints_large",
        "quadratic_mixed_constraints_1024",
        "quadratic_mixed_constraints_xlarge",
    ]


def test_parse_args_supports_realistic_scenario_set() -> None:
    args = run_constrained_benchmarks.parse_args(["--method", "interior_point", "--scenario-set", "realistic"])

    assert args.scenario_set == "realistic"
    assert args.scenarios == [
        "nonlinear_mixed_constraints_medium",
        "nonlinear_mixed_constraints_large",
        "nonlinear_mixed_constraints_1024",
        "nonlinear_mixed_constraints_xlarge",
    ]


def test_parse_args_uses_same_cross_method_default_suite_for_sqp() -> None:
    args = run_constrained_benchmarks.parse_args(["--method", "sqp"])

    assert args.scenarios == [
        "quadratic_mixed_constraints_medium",
        "quadratic_mixed_constraints_large",
        "quadratic_mixed_constraints_1024",
        "quadratic_mixed_constraints_xlarge",
    ]


def test_parse_args_keeps_legacy_aliases_accepted_for_backwards_compatibility() -> None:
    args = run_constrained_benchmarks.parse_args(
        [
            "--scenarios",
            "quadratic_equality_bounds_large_cuda",
        ]
    )

    assert args.scenarios == ["quadratic_equality_bounds_large"]


def test_annotate_device_speedups_matches_cpu_and_cuda_rows() -> None:
    annotate_device_speedups = getattr(run_constrained_benchmarks, "_annotate_device_speedups")
    rows = annotate_device_speedups(
        [
            {
                "scenario": "quadratic_equality_bounds_large",
                "method": "sqp",
                "constrained_hessian_model": "bfgs",
                "device": "cpu",
                "time_seconds_median": 4.0,
            },
            {
                "scenario": "quadratic_equality_bounds_large",
                "method": "sqp",
                "constrained_hessian_model": "bfgs",
                "device": "cuda",
                "time_seconds_median": 2.0,
            },
        ]
    )

    assert rows[0]["cpu_vs_cuda_speedup"] == 2.0
    assert rows[1]["cpu_vs_cuda_speedup"] == 2.0


def test_build_report_includes_matched_speedup(monkeypatch) -> None:
    def fake_benchmark_case(
        *,
        scenario_name: str,
        device,
        method: str,
        hessian_model: str,
        repeats: int,
        max_iter: int,
        tol: float,
        capture_history: bool,
    ):
        _ = (repeats, max_iter, tol, capture_history)
        return {
            "name": f"constrained_{scenario_name}_{method}_{hessian_model}",
            "scenario": scenario_name,
            "method": method,
            "device": str(device),
            "constrained_hessian_model": hessian_model,
            "time_seconds_median": 6.0 if str(device) == "cpu" else 3.0,
            "time_seconds_runs": [6.0] if str(device) == "cpu" else [3.0],
            "success": True,
            "num_outer_iterations": 5,
            "accepted_iterations": 5,
            "rejected_iterations": 0,
            "total_trial_attempts": 5,
        }

    monkeypatch.setattr(run_constrained_benchmarks, "_benchmark_case", fake_benchmark_case)

    report = run_constrained_benchmarks.build_report(
        scenarios=("quadratic_equality_bounds_large",),
        devices=(run_constrained_benchmarks.torch.device("cpu"), run_constrained_benchmarks.torch.device("cuda")),
        method="sqp",
        hessian_model="bfgs",
        repeats=1,
        max_iter=20,
        tol=1e-6,
        capture_history=False,
    )

    assert report["benchmark_family"] == "constrained_sqp"
    assert report["method"] == "sqp"
    assert report["comparison_methods"] == ["sqp", "interior_point"]
    assert len(report["benchmarks"]) == 2
    assert report["benchmarks"][0]["cpu_vs_cuda_speedup"] == 2.0
    assert report["benchmarks"][1]["cpu_vs_cuda_speedup"] == 2.0
    assert report["requested_scenarios"] == ["quadratic_equality_bounds_large"]
    assert "shared cross-method comparison suite" in report["notes"][0]
    assert "mixed equality-plus-inequality-plus-bounds" in report["notes"][0]
    assert "iteration budget for this report is set to 20" in report["notes"][2]


def test_build_report_emits_progress_and_paired_summary(monkeypatch) -> None:
    messages: list[str] = []

    def fake_benchmark_case(
        *,
        scenario_name: str,
        device,
        method: str,
        hessian_model: str,
        repeats: int,
        max_iter: int,
        tol: float,
        capture_history: bool,
    ):
        _ = (method, hessian_model, repeats, max_iter, tol, capture_history)
        return {
            "name": f"constrained_{scenario_name}_{device}",
            "scenario": scenario_name,
            "method": "sqp",
            "device": str(device),
            "constrained_hessian_model": "bfgs",
            "time_seconds_median": 8.0 if str(device) == "cpu" else 2.0,
            "time_seconds_runs": [8.0] if str(device) == "cpu" else [2.0],
            "success": True,
            "status": "converged",
            "num_outer_iterations": 5,
            "accepted_iterations": 5,
            "rejected_iterations": 0,
            "total_trial_attempts": 6,
        }

    monkeypatch.setattr(run_constrained_benchmarks, "_benchmark_case", fake_benchmark_case)

    run_constrained_benchmarks.build_report(
        scenarios=("quadratic_mixed_constraints_medium",),
        devices=(run_constrained_benchmarks.torch.device("cpu"), run_constrained_benchmarks.torch.device("cuda")),
        method="sqp",
        hessian_model="bfgs",
        repeats=1,
        max_iter=20,
        tol=1e-6,
        capture_history=False,
        progress_callback=messages.append,
    )

    assert messages[0] == "[1/2] running quadratic_mixed_constraints_medium on cpu (sqp/bfgs)"
    assert "completed quadratic_mixed_constraints_medium on cpu: median=8.0000s status=converged success=True iters=5 trials=6" in messages[1]
    assert messages[2] == "[2/2] running quadratic_mixed_constraints_medium on cuda (sqp/bfgs)"
    assert "completed quadratic_mixed_constraints_medium on cuda: median=2.0000s status=converged success=True iters=5 trials=6" in messages[3]
    assert messages[4] == "summary quadratic_mixed_constraints_medium: cpu=8.0000s cuda=2.0000s cpu_vs_cuda=4.00x"


def test_build_report_for_ip_uses_ip_family_and_shared_comparison_notes(monkeypatch) -> None:
    def fake_benchmark_case(
        *,
        scenario_name: str,
        device,
        method: str,
        hessian_model: str,
        repeats: int,
        max_iter: int,
        tol: float,
        capture_history: bool,
    ):
        _ = (hessian_model, repeats, max_iter, tol, capture_history)
        return {
            "name": f"constrained_{scenario_name}_{method}",
            "scenario": scenario_name,
            "method": method,
            "device": str(device),
            "time_seconds_median": 1.0,
            "time_seconds_runs": [1.0],
            "success": True,
            "num_outer_iterations": 4,
            "accepted_iterations": 4,
            "rejected_iterations": 0,
            "total_trial_attempts": 4,
        }

    monkeypatch.setattr(run_constrained_benchmarks, "_benchmark_case", fake_benchmark_case)

    report = run_constrained_benchmarks.build_report(
        scenarios=("quadratic_mixed_constraints_medium", "quadratic_mixed_constraints_large", "quadratic_mixed_constraints_1024", "quadratic_mixed_constraints_xlarge"),
        devices=(run_constrained_benchmarks.torch.device("cpu"),),
        method="interior_point",
        hessian_model="bfgs",
        repeats=1,
        max_iter=20,
        tol=1e-6,
        capture_history=False,
    )

    assert report["benchmark_family"] == "constrained_interior_point"
    assert report["method"] == "interior_point"
    assert report["comparison_methods"] == ["sqp", "interior_point"]
    assert report["constrained_hessian_model"] is None
    assert report["requested_scenarios"] == [
        "quadratic_mixed_constraints_medium",
        "quadratic_mixed_constraints_large",
        "quadratic_mixed_constraints_1024",
        "quadratic_mixed_constraints_xlarge",
    ]
    assert "shared cross-method comparison suite" in report["notes"][0]