"""Public package surface for PTNL."""

from pytorch_nonlinear.api.config import BatchMode, ConvergenceValidationMode, DebugConfig, DiffMode, ScalingConfig, ScalingMode, SolverConfig
from pytorch_nonlinear.batching import SharedStructureBatchResult
from pytorch_nonlinear.api.minimize import minimize
from pytorch_nonlinear.api.solve import solve
from pytorch_nonlinear.constraints import Bounds, EqualityConstraint, InequalityConstraint
from pytorch_nonlinear.diagnostics import DiagnosisCode, IterationRecord, SolveResult, SolveStatus, TerminationReason, TrialRecord, render_explanation
from pytorch_nonlinear.losses import CauchyLoss, HuberLoss, RobustLoss, SoftL1Loss
from pytorch_nonlinear.problem import ConstrainedNLPProblem, NonlinearLeastSquaresProblem, SmoothMinimizationProblem
from pytorch_nonlinear.variables import PackedState, VariableSpec, flatten_mapping

__all__ = [
    "BatchMode",
    "Bounds",
    "CauchyLoss",
    "ConvergenceValidationMode",
    "ConstrainedNLPProblem",
    "DebugConfig",
    "DiagnosisCode",
    "DiffMode",
    "EqualityConstraint",
    "HuberLoss",
    "InequalityConstraint",
    "IterationRecord",
    "NonlinearLeastSquaresProblem",
    "PackedState",
    "RobustLoss",
    "ScalingConfig",
    "ScalingMode",
    "SharedStructureBatchResult",
    "SmoothMinimizationProblem",
    "SoftL1Loss",
    "SolveResult",
    "SolveStatus",
    "SolverConfig",
    "TerminationReason",
    "TrialRecord",
    "VariableSpec",
    "flatten_mapping",
    "minimize",
    "render_explanation",
    "solve",
]

__version__ = "0.1.0a0"
