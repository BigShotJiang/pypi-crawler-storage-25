"""Robust residual loss functions for nonlinear least-squares problems.

Robust losses reduce sensitivity to large residuals (outliers) by applying
iteratively reweighted least squares (IRLS) at each solver iteration.

Each loss class exposes two methods:

- ``weights(residuals)``: returns IRLS weights ``w_i`` such that the local
  Gauss-Newton model is formed from residual rows weighted by ``sqrt(w_i)``
  and Jacobian rows weighted by ``sqrt(w_i)``.

- ``value(residuals)``: returns the per-element true loss value ``rho(r_i)``
  used for objective evaluation and step acceptance tests.

The IRLS weighting corresponds to the relationship::

    w_i = rho'(r_i) / r_i

At the solution, ``J^T W r = 0`` (where ``W = diag(w_i)``), which matches
the first-order optimality condition of the robust objective.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass

import torch


class RobustLoss(ABC):
    """Abstract base class for robust residual loss functions."""

    @abstractmethod
    def weights(self, residuals: torch.Tensor) -> torch.Tensor:
        """Compute per-element IRLS weights for the current residual vector.

        Parameters
        ----------
        residuals : torch.Tensor
            Flat residual vector ``r`` with shape ``(m,)``.

        Returns
        -------
        torch.Tensor
            Non-negative weight tensor with the same shape as ``residuals``.
            Rows of the Jacobian and residual are scaled by ``sqrt(w_i)``
            before forming the Gauss-Newton normal equations.
        """

    @abstractmethod
    def value(self, residuals: torch.Tensor) -> torch.Tensor:
        """Compute per-element true loss values.

        Parameters
        ----------
        residuals : torch.Tensor
            Flat residual vector with shape ``(m,)``.

        Returns
        -------
        torch.Tensor
            Per-element loss values ``rho(r_i)`` with the same shape as
            ``residuals``. Sum these to obtain the scalar objective.
        """


@dataclass
class HuberLoss(RobustLoss):
    """Huber loss with a quadratic core and linear tails.

    For ``|r| <= delta`` the loss is quadratic (``0.5 * r^2``), which gives
    full unit weight to inlier residuals.  For ``|r| > delta`` the loss grows
    linearly, which down-weights large outlier residuals smoothly.

    Parameters
    ----------
    delta : float, optional
        Threshold that separates the quadratic and linear regimes.
        Defaults to ``1.0``.
    """

    delta: float = 1.0

    def weights(self, residuals: torch.Tensor) -> torch.Tensor:
        """Return Huber IRLS weights: 1 for inliers, delta / |r| for outliers.

        Parameters
        ----------
        residuals : torch.Tensor
            Flat residual vector with shape ``(m,)``.

        Returns
        -------
        torch.Tensor
            Non-negative weight tensor with the same shape as ``residuals``.
        """

        abs_r = residuals.abs()
        inlier = abs_r <= self.delta
        return torch.where(inlier, torch.ones_like(abs_r), self.delta / abs_r.clamp(min=1e-12))

    def value(self, residuals: torch.Tensor) -> torch.Tensor:
        """Return per-element Huber loss values.

        Parameters
        ----------
        residuals : torch.Tensor
            Flat residual vector with shape ``(m,)``.

        Returns
        -------
        torch.Tensor
            Per-element Huber loss ``rho(r_i)`` with the same shape as
            ``residuals``.
        """

        abs_r = residuals.abs()
        inlier = abs_r <= self.delta
        quadratic = 0.5 * residuals ** 2
        linear = self.delta * (abs_r - 0.5 * self.delta)
        return torch.where(inlier, quadratic, linear)


@dataclass
class CauchyLoss(RobustLoss):
    """Cauchy (Lorentzian) loss for heavy-tailed outlier suppression.

    The Cauchy loss ``(c^2 / 2) * log(1 + (r / c)^2)`` grows logarithmically
    for large residuals, providing stronger outlier rejection than Huber at the
    cost of non-convexity.

    Parameters
    ----------
    c : float, optional
        Scale parameter that controls the transition from quadratic to
        logarithmic growth.  Defaults to ``1.0``.
    """

    c: float = 1.0

    def __post_init__(self) -> None:
        if self.c <= 0.0:
            raise ValueError(f"CauchyLoss scale parameter c must be positive, got c={self.c}.")

    def weights(self, residuals: torch.Tensor) -> torch.Tensor:
        """Return Cauchy IRLS weights: ``1 / (1 + (r / c)^2)``.

        Parameters
        ----------
        residuals : torch.Tensor
            Flat residual vector with shape ``(m,)``.

        Returns
        -------
        torch.Tensor
            Non-negative weight tensor with the same shape as ``residuals``.
        """

        ratio = residuals / self.c
        return 1.0 / (1.0 + ratio ** 2)

    def value(self, residuals: torch.Tensor) -> torch.Tensor:
        """Return per-element Cauchy loss values.

        Parameters
        ----------
        residuals : torch.Tensor
            Flat residual vector with shape ``(m,)``.

        Returns
        -------
        torch.Tensor
            Per-element Cauchy loss ``rho(r_i)`` with the same shape as
            ``residuals``.
        """

        ratio = residuals / self.c
        return 0.5 * self.c ** 2 * torch.log1p(ratio ** 2)


@dataclass
class SoftL1Loss(RobustLoss):
    """Soft L1 (pseudo-Huber) loss for smooth outlier robustness.

    The soft L1 loss ``c^2 * (sqrt(1 + (r / c)^2) - 1)`` interpolates
    smoothly between quadratic behaviour near zero and linear growth for large
    residuals.  It is convex and everywhere differentiable, which makes it a
    reliable default when mild robustness is sufficient.

    Parameters
    ----------
    c : float, optional
        Scale parameter that controls the transition from quadratic to linear
        growth.  Defaults to ``1.0``.
    """

    c: float = 1.0

    def __post_init__(self) -> None:
        if self.c <= 0.0:
            raise ValueError(f"SoftL1Loss scale parameter c must be positive, got c={self.c}.")

    def weights(self, residuals: torch.Tensor) -> torch.Tensor:
        """Return soft L1 IRLS weights: ``1 / sqrt(1 + (r / c)^2)``.

        Parameters
        ----------
        residuals : torch.Tensor
            Flat residual vector with shape ``(m,)``.

        Returns
        -------
        torch.Tensor
            Non-negative weight tensor with the same shape as ``residuals``.
        """

        ratio = residuals / self.c
        return 1.0 / torch.sqrt(1.0 + ratio ** 2)

    def value(self, residuals: torch.Tensor) -> torch.Tensor:
        """Return per-element soft L1 loss values.

        Parameters
        ----------
        residuals : torch.Tensor
            Flat residual vector with shape ``(m,)``.

        Returns
        -------
        torch.Tensor
            Per-element soft L1 loss ``rho(r_i)`` with the same shape as
            ``residuals``.
        """

        ratio = residuals / self.c
        return self.c ** 2 * (torch.sqrt(1.0 + ratio ** 2) - 1.0)
