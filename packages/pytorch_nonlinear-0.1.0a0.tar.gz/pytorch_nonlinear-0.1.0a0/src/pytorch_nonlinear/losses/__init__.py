"""Robust residual loss functions for nonlinear least-squares problems."""

from pytorch_nonlinear.losses.robust import CauchyLoss, HuberLoss, RobustLoss, SoftL1Loss

__all__ = [
    "CauchyLoss",
    "HuberLoss",
    "RobustLoss",
    "SoftL1Loss",
]
