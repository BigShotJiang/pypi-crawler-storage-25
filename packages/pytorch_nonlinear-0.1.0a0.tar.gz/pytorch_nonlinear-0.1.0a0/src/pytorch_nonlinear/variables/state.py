"""State packing utilities for the scaffold.

These helpers intentionally work on generic Python scalars and rectangular nested
sequences so the repository spine stays testable before PyTorch tensor handling
lands in the implementation phase.
"""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from typing import Any


def _is_sequence(value: Any) -> bool:
    return isinstance(value, Sequence) and not isinstance(value, (str, bytes, bytearray))


def _infer_shape(value: Any) -> tuple[int, ...]:
    if not _is_sequence(value):
        return ()
    if len(value) == 0:
        return (0,)
    child_shapes = [_infer_shape(item) for item in value]
    first_shape = child_shapes[0]
    if any(shape != first_shape for shape in child_shapes[1:]):
        raise ValueError("All nested sequences must be rectangular.")
    return (len(value),) + first_shape


def _flatten_value(value: Any) -> tuple[Any, ...]:
    if not _is_sequence(value):
        return (value,)
    flat: list[Any] = []
    for item in value:
        flat.extend(_flatten_value(item))
    return tuple(flat)


def _unflatten_value(values: Sequence[Any], shape: tuple[int, ...]) -> Any:
    if not shape:
        if len(values) != 1:
            raise ValueError("Scalar shapes must receive exactly one value.")
        return values[0]
    if len(shape) == 1:
        return tuple(values)

    stride = 1
    for size in shape[1:]:
        stride *= size

    outer: list[Any] = []
    for index in range(shape[0]):
        start = index * stride
        stop = start + stride
        outer.append(_unflatten_value(values[start:stop], shape[1:]))
    return tuple(outer)


@dataclass(frozen=True)
class VariableSpec:
    name: str
    shape: tuple[int, ...]
    start: int
    stop: int


@dataclass(frozen=True)
class PackedState:
    flat: tuple[Any, ...]
    tree: Mapping[str, Any]
    specs: tuple[VariableSpec, ...]
    batch_shape: tuple[int, ...] = ()

    def as_mapping(self) -> dict[str, Any]:
        restored: dict[str, Any] = {}
        for spec in self.specs:
            restored[spec.name] = _unflatten_value(self.flat[spec.start:spec.stop], spec.shape)
        return restored


def flatten_mapping(values: Mapping[str, Any]) -> PackedState:
    flat: list[Any] = []
    specs: list[VariableSpec] = []
    normalized: dict[str, Any] = {}

    for name, value in values.items():
        shape = _infer_shape(value)
        flattened = _flatten_value(value)
        start = len(flat)
        flat.extend(flattened)
        stop = len(flat)
        specs.append(VariableSpec(name=name, shape=shape, start=start, stop=stop))
        normalized[name] = _unflatten_value(flattened, shape)

    return PackedState(flat=tuple(flat), tree=normalized, specs=tuple(specs))
