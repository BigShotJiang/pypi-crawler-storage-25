"""Acceptance and backtracking policy helpers for the dense interior-point solver."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import torch

from pytorch_nonlinear.linear import LinearSolveResult
from pytorch_nonlinear.problem import ConstrainedNLPProblem
from pytorch_nonlinear.solvers.constrained_nlp import _reshape_state, evaluate_dense_constrained_trial_problem
from pytorch_nonlinear.solvers.interior_point.evaluation import DenseInteriorPointResiduals, as_bool, as_float, build_interior_point_state, combine_inequalities, inf_norm
from pytorch_nonlinear.solvers.interior_point.telemetry import make_trial_record


@dataclass(frozen=True)
class TrialSelection:
    """Accepted trial information from the interior-point backtracking loop.

    Attributes
    ----------
    accepted_alpha : float | None
        Accepted step parameter, or ``None`` if all trials were rejected.
    accepted_state : Any | None
        Re-evaluated primal-dual state at the accepted trial point.
    accepted_step_norm : float | None
        Euclidean norm of the accepted primal step.
    trial_records : tuple[Any, ...]
        Deferred telemetry for each attempted trial step.
    """

    accepted_alpha: float | None
    accepted_state: Any | None
    accepted_step_norm: float | None
    trial_records: tuple[Any, ...]


def compute_step_limit(current: torch.Tensor, direction: torch.Tensor) -> float:
    """Return the largest step that keeps a positive quantity nonnegative.

    Parameters
    ----------
    current : torch.Tensor
        Current positive state, typically slacks or inequality multipliers.
    direction : torch.Tensor
        Proposed Newton direction for ``current``.

    Returns
    -------
    float
        Largest step length in ``[0, 1]`` that avoids crossing zero.
    """

    if current.numel() == 0:
        return 1.0
    negative_direction = direction < 0.0
    if not as_bool(torch.any(negative_direction)):
        return 1.0
    admissible = -current[negative_direction] / direction[negative_direction]
    return min(1.0, as_float(torch.min(admissible)))


def barrier_merit(
    *,
    objective_value: torch.Tensor,
    equality_values: torch.Tensor,
    inequality_values: torch.Tensor,
    slacks: torch.Tensor,
    barrier_parameter: float,
    penalty: float,
) -> torch.Tensor:
    """Evaluate the merit model used by IP backtracking.

    Parameters
    ----------
    objective_value : torch.Tensor
        Objective value at the trial point.
    equality_values : torch.Tensor
        Equality residual vector.
    inequality_values : torch.Tensor
        Stacked inequality values before adding slacks.
    slacks : torch.Tensor
        Slack variables for the inequality rows.
    barrier_parameter : float
        Log-barrier weight, typically the current complementarity gap.
    penalty : float
        Exact-penalty weight for primal infeasibility.

    Returns
    -------
    torch.Tensor
        Barrier-augmented merit value used for acceptance tests.
    """

    equality_penalty = torch.sum(torch.abs(equality_values)) if equality_values.numel() > 0 else objective_value.new_tensor(0.0)
    inequality_penalty = (
        torch.sum(torch.abs(inequality_values + slacks)) if inequality_values.numel() > 0 else objective_value.new_tensor(0.0)
    )
    merit = objective_value + penalty * (equality_penalty + inequality_penalty)
    if slacks.numel() > 0:
        merit = merit - barrier_parameter * torch.sum(torch.log(slacks))
    return merit


def select_trial_step(
    *,
    problem: ConstrainedNLPProblem,
    x: torch.Tensor,
    dx: torch.Tensor,
    slacks: torch.Tensor,
    ds: torch.Tensor,
    equality_multipliers: torch.Tensor,
    dy: torch.Tensor,
    inequality_multipliers: torch.Tensor,
    dz: torch.Tensor,
    evaluation: Any,
    inequalities: Any,
    residuals: DenseInteriorPointResiduals,
    device_params: Any,
    original_shape: torch.Size,
    equality_constraints: tuple[Any, ...],
    inequality_constraints: tuple[Any, ...],
    bounds: Any,
    lower: torch.Tensor | None,
    upper: torch.Tensor | None,
    barrier_parameter: float,
    merit_penalty: float,
    tolerance: float,
    linear_result: LinearSolveResult,
    capture_history: bool,
    fraction_to_boundary: float,
    min_step_parameter: float,
) -> TrialSelection:
    """Run interior-point backtracking and return the accepted trial state.

    Parameters
    ----------
    problem : ConstrainedNLPProblem
        Constrained problem used for trial evaluation.
    x : torch.Tensor
        Current primal state.
    dx : torch.Tensor
        Proposed primal Newton step.
    slacks : torch.Tensor
        Current slack variables.
    ds : torch.Tensor
        Proposed slack step.
    equality_multipliers : torch.Tensor
        Current equality-dual variables.
    dy : torch.Tensor
        Proposed equality-dual step.
    inequality_multipliers : torch.Tensor
        Current inequality-dual variables.
    dz : torch.Tensor
        Proposed inequality-dual step.
    evaluation : Any
        Current primal evaluation.
    inequalities : Any
        Current stacked inequality data.
    residuals : DenseInteriorPointResiduals
        Current KKT residual summary.
    device_params : Any
        Parameters moved to the active device.
    original_shape : torch.Size
        Shape used to restore flat states to the problem-facing layout.
    equality_constraints : tuple[Any, ...]
        Equality constraints to evaluate at trial points.
    inequality_constraints : tuple[Any, ...]
        Inequality constraints to evaluate at trial points.
    bounds : Any
        Optional bound object.
    lower : torch.Tensor | None
        Flattened lower bounds.
    upper : torch.Tensor | None
        Flattened upper bounds.
    barrier_parameter : float
        Current barrier weight.
    merit_penalty : float
        User-configured lower bound for the feasibility penalty.
    tolerance : float
        Solver tolerance for the step-tolerance acceptance fallback.
    linear_result : LinearSolveResult
        Selected linear solve result whose diagnostics are attached to telemetry.
    capture_history : bool
        Whether trial telemetry should be buffered.
    fraction_to_boundary : float
        Safety factor that keeps the iterate strictly interior.
    min_step_parameter : float
        Smallest backtracking parameter considered before declaring rejection.

    Returns
    -------
    TrialSelection
        Accepted trial data, or an all-``None`` selection if backtracking fails.
    """

    state_shape = original_shape
    alpha_limit = 1.0
    if slacks.numel() > 0:
        # Fraction-to-the-boundary keeps slacks and inequality multipliers in the
        # strictly positive interior required by the logarithmic barrier model.
        alpha_limit = min(
            1.0,
            fraction_to_boundary * compute_step_limit(slacks, ds),
            fraction_to_boundary * compute_step_limit(inequality_multipliers, dz),
        )

    penalty = max(
        merit_penalty,
        residuals.stationarity_norm,
        inf_norm(equality_multipliers),
        inf_norm(inequality_multipliers),
    ) + 1.0
    current_merit = barrier_merit(
        objective_value=evaluation.objective_value,
        equality_values=evaluation.equality_values,
        inequality_values=inequalities.values,
        slacks=slacks,
        barrier_parameter=barrier_parameter,
        penalty=penalty,
    )

    trial_records: list[Any] = []
    alpha = alpha_limit
    while alpha >= min_step_parameter:
        trial_x = x + alpha * dx
        trial_slacks = slacks + alpha * ds
        trial_equality_multipliers = equality_multipliers + alpha * dy
        trial_inequality_multipliers = inequality_multipliers + alpha * dz
        trial_interior_feasible = as_bool(
            torch.logical_and(
                torch.all(trial_slacks > 0.0),
                torch.all(trial_inequality_multipliers > 0.0),
            )
        )
        if not trial_interior_feasible:
            alpha *= 0.5
            continue

        trial_evaluation = evaluate_dense_constrained_trial_problem(
            problem,
            trial_x,
            device_params,
            original_shape=state_shape,
            equality_constraints=equality_constraints,
            inequality_constraints=inequality_constraints,
            bounds=bounds,
            lower=lower,
            upper=upper,
        )
        trial_inequality_values = combine_inequalities(
            trial_x,
            nonlinear_values=trial_evaluation.inequality_values,
            nonlinear_jacobian=None,
            lower=lower,
            upper=upper,
        ).values
        trial_merit = barrier_merit(
            objective_value=trial_evaluation.objective_value,
            equality_values=trial_evaluation.equality_values,
            inequality_values=trial_inequality_values,
            slacks=trial_slacks,
            barrier_parameter=barrier_parameter,
            penalty=penalty,
        )
        scaled_step = alpha * dx
        step_norm_tensor = torch.sqrt(torch.sum(scaled_step * scaled_step))
        step_tol_condition = torch.logical_and(
            step_norm_tensor <= tolerance,
            trial_evaluation.constraint_violation <= tolerance,
        )
        merit_improved = trial_merit < current_merit - 1e-12
        merit_improved_bool = as_bool(merit_improved)
        step_tol_bool = False
        if not merit_improved_bool:
            step_tol_bool = as_bool(step_tol_condition)
        trial_accepted = merit_improved_bool or step_tol_bool
        if capture_history:
            trial_reason = (
                "accepted"
                if merit_improved_bool
                else "step_tol"
                if step_tol_bool
                else "barrier_not_improved"
            )
            trial_records.append(
                make_trial_record(
                    attempt=len(trial_records) + 1,
                    objective_value=as_float(trial_evaluation.objective_value),
                    step_norm=as_float(step_norm_tensor),
                    accepted=trial_accepted,
                    reason=trial_reason,
                    state=_reshape_state(trial_x, state_shape).detach(),
                    step_parameter=alpha,
                    linear_solver_iterations=linear_result.iterations,
                    linear_residual_norm=linear_result.residual_norm,
                    linear_condition_estimate=linear_result.condition_estimate,
                )
            )
        if trial_accepted:
            # Re-evaluate only the accepted trial with full Jacobians and KKT
            # residuals; rejected trials stay on the cheap merit-only path.
            accepted_state = build_interior_point_state(
                problem,
                trial_x,
                device_params,
                original_shape=state_shape,
                equality_constraints=equality_constraints,
                inequality_constraints=inequality_constraints,
                bounds=bounds,
                lower=lower,
                upper=upper,
                equality_multipliers=trial_equality_multipliers,
                slacks=trial_slacks,
                inequality_multipliers=trial_inequality_multipliers,
            )
            return TrialSelection(
                accepted_alpha=alpha,
                accepted_state=accepted_state,
                accepted_step_norm=as_float(step_norm_tensor),
                trial_records=tuple(trial_records),
            )
        alpha *= 0.5

    return TrialSelection(
        accepted_alpha=None,
        accepted_state=None,
        accepted_step_norm=None,
        trial_records=tuple(trial_records),
    )