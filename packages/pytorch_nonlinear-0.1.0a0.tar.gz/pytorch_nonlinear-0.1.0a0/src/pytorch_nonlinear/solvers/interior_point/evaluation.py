"""Evaluation and state helpers for the dense interior-point solver."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import torch

from pytorch_nonlinear.constraints import Bounds, EqualityConstraint, InequalityConstraint
from pytorch_nonlinear.problem import ConstrainedNLPProblem
from pytorch_nonlinear.solvers.constrained_nlp import (
    DenseConstrainedEvaluation,
    _estimate_multipliers,
    _flatten_constraint_value,
    _reshape_state,
    evaluate_dense_constrained_problem,
)


@dataclass(frozen=True)
class DenseInteriorPointInequalities:
    """Stacked inequality values and Jacobian for the interior-point path.

    Attributes
    ----------
    values : torch.Tensor
        Concatenated nonlinear-inequality and bound residuals written in
        the form g(x) <= 0.
    jacobian : torch.Tensor
        Jacobian of the stacked inequality map with rows aligned to ``values``.
    """

    values: torch.Tensor
    jacobian: torch.Tensor


@dataclass(frozen=True)
class DenseInteriorPointResiduals:
    """KKT residual blocks for the primal-dual interior-point iterate.

    Attributes
    ----------
    dual : torch.Tensor
        Stationarity residual of the Lagrangian gradient.
    equality : torch.Tensor
        Equality-feasibility residual.
    inequality : torch.Tensor
        Primal-feasibility residual for the slack reformulation ``g(x) + s = 0``.
    complementarity : torch.Tensor
        Pairwise complementarity products ``s * z``.
    stationarity_norm : float
        Infinity norm of ``dual``.
    equality_norm : float
        Infinity norm of the equality residual.
    inequality_norm : float
        Infinity norm of the slack-form inequality residual.
    complementarity_norm : float
        Infinity norm of the complementarity block.
    complementarity_gap : float
        Mean complementarity, used as the barrier parameter proxy.
    kkt_residual : float
        Maximum norm across the primal-dual KKT blocks.
    """

    dual: torch.Tensor
    equality: torch.Tensor
    inequality: torch.Tensor
    complementarity: torch.Tensor
    stationarity_norm: float
    equality_norm: float
    inequality_norm: float
    complementarity_norm: float
    complementarity_gap: float
    kkt_residual: float


@dataclass(frozen=True)
class DenseInteriorPointState:
    """Fully evaluated primal-dual state for one interior-point iterate.

    Attributes
    ----------
    x : torch.Tensor
        Flattened primal variable vector.
    evaluation : DenseConstrainedEvaluation
        Objective, gradients, Jacobians, and active-set summary at ``x``.
    inequalities : DenseInteriorPointInequalities
        Stacked inequality values and Jacobian, including bounds.
    slacks : torch.Tensor
        Positive slack variables for the inequality rows.
    equality_multipliers : torch.Tensor
        Equality-dual variables.
    inequality_multipliers : torch.Tensor
        Inequality-dual variables paired with ``slacks``.
    residuals : DenseInteriorPointResiduals
        KKT residual blocks induced by the current primal-dual state.
    """

    x: torch.Tensor
    evaluation: DenseConstrainedEvaluation
    inequalities: DenseInteriorPointInequalities
    slacks: torch.Tensor
    equality_multipliers: torch.Tensor
    inequality_multipliers: torch.Tensor
    residuals: DenseInteriorPointResiduals


def as_float(value: torch.Tensor) -> float:
    return float(value.item())


def as_bool(value: torch.Tensor) -> bool:
    return bool(value.item())


def inf_norm(value: torch.Tensor) -> float:
    if value.numel() == 0:
        return 0.0
    return as_float(torch.max(torch.abs(value)))


def symmetrize(matrix: torch.Tensor) -> torch.Tensor:
    return 0.5 * (matrix + matrix.T)


def objective_hessian(
    problem: ConstrainedNLPProblem,
    x: torch.Tensor,
    params: Any | None,
    *,
    original_shape: torch.Size,
) -> torch.Tensor:
    """Return the exact objective Hessian on the flattened primal state.

    Parameters
    ----------
    problem : ConstrainedNLPProblem
        Constrained problem providing the scalar objective.
    x : torch.Tensor
        Flattened primal state.
    params : Any | None
        Optional user parameters forwarded to the objective.
    original_shape : torch.Size
        Shape used to restore ``x`` to the problem-facing state layout.

    Returns
    -------
    torch.Tensor
        Symmetric dense objective Hessian.
    """

    def objective_fn(flat_x: torch.Tensor) -> torch.Tensor:
        state = _reshape_state(flat_x, original_shape)
        value = torch.as_tensor(problem.objective(state, params), dtype=flat_x.dtype, device=flat_x.device)
        if value.ndim != 0:
            raise ValueError("objective must return a scalar tensor-like value.")
        return value

    # The vectorized Hessian path remains the best exact implementation we have
    # for the full solver path; alternative exact primitives regressed downstream
    # linear algebra even when isolated Hessian timing looked better.
    hessian = torch.autograd.functional.hessian(objective_fn, x.detach(), vectorize=True)
    return symmetrize(hessian.reshape(x.numel(), x.numel()).detach())


def _weighted_constraint_term(
    constraints: tuple[EqualityConstraint | InequalityConstraint, ...],
    multipliers: torch.Tensor,
    state: torch.Tensor,
    params: Any | None,
    *,
    like: torch.Tensor,
) -> torch.Tensor:
    if not constraints:
        return like.new_tensor(0.0)

    offset = 0
    weighted_value = like.new_tensor(0.0)
    for constraint in constraints:
        values = _flatten_constraint_value(constraint.evaluate(state, params), like=like)
        size = values.numel()
        if size == 0:
            continue
        weighted_value = weighted_value + torch.dot(multipliers[offset : offset + size], values)
        offset += size
    return weighted_value


def lagrangian_hessian(
    problem: ConstrainedNLPProblem,
    x: torch.Tensor,
    params: Any | None,
    *,
    original_shape: torch.Size,
    equality_constraints: tuple[EqualityConstraint, ...],
    inequality_constraints: tuple[InequalityConstraint, ...],
    equality_multipliers: torch.Tensor,
    inequality_multipliers: torch.Tensor,
) -> torch.Tensor:
    """Return the exact Lagrangian Hessian for the current multiplier state.

    Parameters
    ----------
    problem : ConstrainedNLPProblem
        Constrained problem providing the objective.
    x : torch.Tensor
        Flattened primal state.
    params : Any | None
        Optional user parameters forwarded to the objective and constraints.
    original_shape : torch.Size
        Shape used to restore ``x`` to the problem-facing state layout.
    equality_constraints : tuple[EqualityConstraint, ...]
        Equality constraints included in the Lagrangian.
    inequality_constraints : tuple[InequalityConstraint, ...]
        Nonlinear inequality constraints included in the Lagrangian.
    equality_multipliers : torch.Tensor
        Equality-dual variables.
    inequality_multipliers : torch.Tensor
        Inequality-dual variables for the nonlinear inequality rows.

    Returns
    -------
    torch.Tensor
        Symmetric dense Hessian of the exact Lagrangian.
    """

    def lagrangian_fn(flat_x: torch.Tensor) -> torch.Tensor:
        state = _reshape_state(flat_x, original_shape)
        objective_value = torch.as_tensor(problem.objective(state, params), dtype=flat_x.dtype, device=flat_x.device)
        if objective_value.ndim != 0:
            raise ValueError("objective must return a scalar tensor-like value.")
        equality_term = _weighted_constraint_term(
            equality_constraints,
            equality_multipliers,
            state,
            params,
            like=flat_x,
        )
        inequality_term = _weighted_constraint_term(
            inequality_constraints,
            inequality_multipliers,
            state,
            params,
            like=flat_x,
        )
        return objective_value + equality_term + inequality_term

    # Keep the exact Hessian implementation aligned with the full-solver profile,
    # not just isolated differentiation micro-benchmarks.
    hessian = torch.autograd.functional.hessian(lagrangian_fn, x.detach(), vectorize=True)
    return symmetrize(hessian.reshape(x.numel(), x.numel()).detach())


def combine_inequalities(
    x: torch.Tensor,
    *,
    nonlinear_values: torch.Tensor,
    nonlinear_jacobian: torch.Tensor | None,
    lower: torch.Tensor | None,
    upper: torch.Tensor | None,
) -> DenseInteriorPointInequalities:
    """Stack nonlinear inequalities and bound residuals into one map.

    Parameters
    ----------
    x : torch.Tensor
        Flattened primal state.
    nonlinear_values : torch.Tensor
        Values of the explicit nonlinear inequalities.
    nonlinear_jacobian : torch.Tensor
        Jacobian of the explicit nonlinear inequalities.
    lower : torch.Tensor | None
        Lower bounds written in the flattened state space.
    upper : torch.Tensor | None
        Upper bounds written in the flattened state space.

    Returns
    -------
    DenseInteriorPointInequalities
        Unified inequality values and Jacobian in the form ``g(x) <= 0``.
    """

    values: list[torch.Tensor] = []
    jacobian_rows: list[torch.Tensor] = []
    dimension = x.numel()
    if nonlinear_values.numel() > 0:
        values.append(nonlinear_values)
        if nonlinear_jacobian is not None:
            jacobian_rows.append(nonlinear_jacobian)

    identity: torch.Tensor | None = None
    if lower is not None:
        values.append(lower - x)
        if nonlinear_jacobian is not None:
            if identity is None:
                identity = torch.eye(dimension, dtype=x.dtype, device=x.device)
            jacobian_rows.append(-identity)
    if upper is not None:
        values.append(x - upper)
        if nonlinear_jacobian is not None:
            if identity is None:
                identity = torch.eye(dimension, dtype=x.dtype, device=x.device)
            jacobian_rows.append(identity)

    if not values:
        return DenseInteriorPointInequalities(
            values=x.new_zeros(0),
            jacobian=x.new_zeros((0, dimension)),
        )

    if nonlinear_jacobian is None:
        return DenseInteriorPointInequalities(
            values=torch.cat(values),
            jacobian=x.new_zeros((0, dimension)),
        )

    return DenseInteriorPointInequalities(
        values=torch.cat(values),
        jacobian=torch.cat(jacobian_rows, dim=0),
    )


def initial_slacks(inequality_values: torch.Tensor) -> torch.Tensor:
    if inequality_values.numel() == 0:
        return inequality_values.new_zeros(0)
    return torch.clamp(1.0 - inequality_values, min=1.0)


def initial_dual_variables(slacks: torch.Tensor) -> torch.Tensor:
    if slacks.numel() == 0:
        return slacks.new_zeros(0)
    return torch.ones_like(slacks)


def residuals(
    *,
    objective_gradient: torch.Tensor,
    equality_jacobian: torch.Tensor,
    equality_values: torch.Tensor,
    inequality_jacobian: torch.Tensor,
    inequality_values: torch.Tensor,
    equality_multipliers: torch.Tensor,
    slacks: torch.Tensor,
    inequality_multipliers: torch.Tensor,
) -> DenseInteriorPointResiduals:
    """Assemble the primal-dual KKT residual blocks for one iterate.

    Parameters
    ----------
    objective_gradient : torch.Tensor
        Objective gradient at the current primal state.
    equality_jacobian : torch.Tensor
        Equality Jacobian.
    equality_values : torch.Tensor
        Equality residual vector.
    inequality_jacobian : torch.Tensor
        Stacked inequality Jacobian.
    inequality_values : torch.Tensor
        Stacked inequality values before adding slacks.
    equality_multipliers : torch.Tensor
        Equality-dual variables.
    slacks : torch.Tensor
        Positive slack variables.
    inequality_multipliers : torch.Tensor
        Inequality-dual variables.

    Returns
    -------
    DenseInteriorPointResiduals
        Stationarity, feasibility, and complementarity residual blocks together
        with their summary norms.
    """

    # These are the four primal-dual KKT blocks for the slack reformulation:
    # stationarity, equality feasibility, inequality feasibility, complementarity.
    dual = objective_gradient.clone()
    if equality_jacobian.shape[0] > 0:
        dual = dual + equality_jacobian.T @ equality_multipliers
    if inequality_jacobian.shape[0] > 0:
        dual = dual + inequality_jacobian.T @ inequality_multipliers

    inequality = inequality_values + slacks
    complementarity = slacks * inequality_multipliers
    stationarity_norm = inf_norm(dual)
    equality_norm = inf_norm(equality_values)
    inequality_norm = inf_norm(inequality)
    complementarity_norm = inf_norm(complementarity)
    complementarity_gap = as_float(torch.mean(complementarity)) if complementarity.numel() > 0 else 0.0
    return DenseInteriorPointResiduals(
        dual=dual,
        equality=equality_values,
        inequality=inequality,
        complementarity=complementarity,
        stationarity_norm=stationarity_norm,
        equality_norm=equality_norm,
        inequality_norm=inequality_norm,
        complementarity_norm=complementarity_norm,
        complementarity_gap=complementarity_gap,
        kkt_residual=max(stationarity_norm, equality_norm, inequality_norm, complementarity_norm),
    )


def build_interior_point_state(
    problem: ConstrainedNLPProblem,
    x: torch.Tensor,
    params: Any | None,
    *,
    original_shape: torch.Size,
    equality_constraints: tuple[EqualityConstraint, ...],
    inequality_constraints: tuple[InequalityConstraint, ...],
    bounds: Bounds | None,
    lower: torch.Tensor | None,
    upper: torch.Tensor | None,
    equality_multipliers: torch.Tensor | None = None,
    slacks: torch.Tensor | None = None,
    inequality_multipliers: torch.Tensor | None = None,
) -> DenseInteriorPointState:
    """Evaluate and package a full primal-dual interior-point state.

    Parameters
    ----------
    problem : ConstrainedNLPProblem
        Constrained NLP to evaluate.
    x : torch.Tensor
        Flattened primal state.
    params : Any | None
        Optional user parameters forwarded to callbacks.
    original_shape : torch.Size
        Shape used to restore ``x`` to the problem-facing layout.
    equality_constraints : tuple[EqualityConstraint, ...]
        Equality constraints active in the problem.
    inequality_constraints : tuple[InequalityConstraint, ...]
        Nonlinear inequality constraints active in the problem.
    bounds : Bounds | None
        Optional bound object from the public problem surface.
    lower : torch.Tensor | None
        Flattened lower bounds.
    upper : torch.Tensor | None
        Flattened upper bounds.
    equality_multipliers : torch.Tensor | None, default=None
        Optional equality-dual initialization.
    slacks : torch.Tensor | None, default=None
        Optional slack initialization.
    inequality_multipliers : torch.Tensor | None, default=None
        Optional inequality-dual initialization.

    Returns
    -------
    DenseInteriorPointState
        Fully evaluated primal-dual state with residuals and stacked inequalities.
    """

    evaluation = evaluate_dense_constrained_problem(
        problem,
        x,
        params,
        original_shape=original_shape,
        equality_constraints=equality_constraints,
        inequality_constraints=inequality_constraints,
        bounds=bounds,
        lower=lower,
        upper=upper,
        materialize_active_inequalities_only=False,
    )
    inequalities = combine_inequalities(
        evaluation.x,
        nonlinear_values=evaluation.inequality_values,
        nonlinear_jacobian=evaluation.inequality_jacobian,
        lower=lower,
        upper=upper,
    )
    chosen_equality_multipliers = (
        equality_multipliers
        if equality_multipliers is not None
        else _estimate_multipliers(evaluation.equality_jacobian, evaluation.objective_gradient)
    )
    chosen_slacks = slacks if slacks is not None else initial_slacks(inequalities.values)
    chosen_inequality_multipliers = (
        inequality_multipliers if inequality_multipliers is not None else initial_dual_variables(chosen_slacks)
    )
    return DenseInteriorPointState(
        x=evaluation.x,
        evaluation=evaluation,
        inequalities=inequalities,
        slacks=chosen_slacks,
        equality_multipliers=chosen_equality_multipliers,
        inequality_multipliers=chosen_inequality_multipliers,
        residuals=residuals(
            objective_gradient=evaluation.objective_gradient,
            equality_jacobian=evaluation.equality_jacobian,
            equality_values=evaluation.equality_values,
            inequality_jacobian=inequalities.jacobian,
            inequality_values=inequalities.values,
            equality_multipliers=chosen_equality_multipliers,
            slacks=chosen_slacks,
            inequality_multipliers=chosen_inequality_multipliers,
        ),
    )