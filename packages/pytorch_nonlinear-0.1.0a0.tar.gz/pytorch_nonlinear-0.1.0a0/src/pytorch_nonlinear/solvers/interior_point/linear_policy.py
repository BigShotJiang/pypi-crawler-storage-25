"""Linear certification and recovery helpers for the dense interior-point solver."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import torch

from pytorch_nonlinear.diagnostics import DiagnosisCode
from pytorch_nonlinear.linear import LinearSolveResult, Linearization, compute_condition_diagnostics


_LINEAR_FALLBACK_RELATIVE_RESIDUAL_TOL = 1e-8


@dataclass(frozen=True)
class InteriorPointLinearSolveRequest:
    """Linear solve request for one reduced interior-point KKT system.

    Attributes
    ----------
    system : torch.Tensor
        Dense reduced KKT matrix for the current affine or corrector solve.
    rhs : torch.Tensor
        Right-hand side aligned with ``system``.
    compute_condition_estimate : bool
        Whether condition diagnostics should be reported for this solve.
    force_exact : bool, default=False
        Whether exact certification must be run even if cheaper guards pass.
    """

    system: torch.Tensor
    rhs: torch.Tensor
    compute_condition_estimate: bool
    force_exact: bool = False


def _rhs_scale(rhs: torch.Tensor) -> float:
    return max(float(torch.norm(rhs).detach().cpu().item()), 1.0)


def _residual_norm_value(system: torch.Tensor, step: torch.Tensor, rhs: torch.Tensor) -> float:
    return float(torch.norm(system @ step - rhs).detach().cpu().item())


def _least_squares_fallback_step(system: torch.Tensor, rhs: torch.Tensor) -> torch.Tensor:
    rhs_for_solve = rhs.unsqueeze(-1) if rhs.ndim == system.ndim - 1 else rhs
    step = torch.linalg.lstsq(system, rhs_for_solve).solution  # pyright: ignore[reportCallIssue]
    if step.ndim == rhs_for_solve.ndim and step.shape[-1] == 1 and rhs.ndim == system.ndim - 1:
        step = step.squeeze(-1)
    return step


def _stabilize_linear_result(
    linear_result: LinearSolveResult,
    *,
    system: torch.Tensor,
    rhs: torch.Tensor,
) -> LinearSolveResult:
    diagnoses = set(linear_result.diagnosis)
    residual_norm = linear_result.residual_norm
    relative_residual = None
    rhs_scale = _rhs_scale(rhs)
    if residual_norm is not None:
        relative_residual = float(residual_norm) / rhs_scale

    if (
        DiagnosisCode.ILL_CONDITIONED_SYSTEM not in diagnoses
        and DiagnosisCode.RANK_DEFICIENT_JACOBIAN not in diagnoses
        and (relative_residual is None or relative_residual <= _LINEAR_FALLBACK_RELATIVE_RESIDUAL_TOL)
    ):
        return linear_result

    try:
        # Least-squares recovery is a certification fallback for suspicious KKT
        # solves, not part of the common-path Newton step.
        stable_step = _least_squares_fallback_step(system, rhs)
    except RuntimeError:
        return LinearSolveResult(
            success=False,
            step=None,
            diagnosis=tuple(dict.fromkeys((*linear_result.diagnosis, DiagnosisCode.UNCERTIFIED_KKT_STEP))),
            diagnosis_by_batch=linear_result.diagnosis_by_batch,
            condition_estimate=linear_result.condition_estimate,
            residual_norm=linear_result.residual_norm,
            iterations=linear_result.iterations,
            solver_name=linear_result.solver_name,
            message="Interior-point KKT least-squares fallback failed to produce a certifiable step.",
        )

    stable_residual = _residual_norm_value(system, stable_step, rhs)
    relative_residual = stable_residual / rhs_scale
    if relative_residual > _LINEAR_FALLBACK_RELATIVE_RESIDUAL_TOL:
        return LinearSolveResult(
            success=False,
            step=None,
            diagnosis=tuple(dict.fromkeys((*linear_result.diagnosis, DiagnosisCode.UNCERTIFIED_KKT_STEP))),
            diagnosis_by_batch=linear_result.diagnosis_by_batch,
            condition_estimate=linear_result.condition_estimate,
            residual_norm=stable_residual,
            iterations=linear_result.iterations,
            solver_name=linear_result.solver_name,
            message="Interior-point KKT least-squares fallback could not certify a recovery step.",
        )

    return LinearSolveResult(
        success=True,
        step=stable_step,
        diagnosis=linear_result.diagnosis,
        diagnosis_by_batch=linear_result.diagnosis_by_batch,
        condition_estimate=linear_result.condition_estimate,
        residual_norm=stable_residual,
        iterations=linear_result.iterations,
        solver_name=linear_result.solver_name,
        message=linear_result.message,
    )


def _relative_linear_residual(linear_result: LinearSolveResult, rhs: torch.Tensor) -> float | None:
    residual_norm = linear_result.residual_norm
    if residual_norm is None:
        return None
    return float(residual_norm) / _rhs_scale(rhs)


def _selected_linear_result_needs_exact_certification(
    linear_result: LinearSolveResult,
    *,
    rhs: torch.Tensor,
    force_exact: bool,
) -> bool:
    if force_exact:
        return True
    if not bool(linear_result.success) or linear_result.step is None:
        return True

    diagnoses = set(linear_result.diagnosis)
    if DiagnosisCode.RANK_DEFICIENT_JACOBIAN in diagnoses or DiagnosisCode.ILL_CONDITIONED_SYSTEM in diagnoses:
        return True

    relative_residual = _relative_linear_residual(linear_result, rhs)
    if relative_residual is None:
        return True
    return relative_residual > _LINEAR_FALLBACK_RELATIVE_RESIDUAL_TOL


def _merge_diagnosis_by_batch(
    left: tuple[tuple[DiagnosisCode, ...], ...] | None,
    right: tuple[tuple[DiagnosisCode, ...], ...] | None,
) -> tuple[tuple[DiagnosisCode, ...], ...] | None:
    if left is None:
        return right
    if right is None:
        return left

    merged: list[tuple[DiagnosisCode, ...]] = []
    for left_batch, right_batch in zip(left, right, strict=True):
        merged.append(tuple(dict.fromkeys((*left_batch, *right_batch))))
    return tuple(merged)


def certify_selected_linear_result(
    linear_result: LinearSolveResult,
    *,
    system: torch.Tensor,
    rhs: torch.Tensor,
    compute_condition_estimate: bool,
    force_exact: bool = False,
) -> LinearSolveResult:
    """Certify a selected KKT solve result and recover if needed.

    Parameters
    ----------
    linear_result : LinearSolveResult
        Result returned by the primary linear backend.
    system : torch.Tensor
        Reduced KKT matrix that was solved.
    rhs : torch.Tensor
        Right-hand side for ``system``.
    compute_condition_estimate : bool
        Whether condition diagnostics should be reported.
    force_exact : bool, default=False
        Whether exact certification should run even if cheap guards pass.

    Returns
    -------
    LinearSolveResult
        Certified solve result, potentially augmented with condition diagnoses or
        replaced by a least-squares recovery step.
    """

    if not compute_condition_estimate:
        return _stabilize_linear_result(linear_result, system=system, rhs=rhs)

    if not _selected_linear_result_needs_exact_certification(
        linear_result,
        rhs=rhs,
        force_exact=force_exact,
    ):
        return _stabilize_linear_result(linear_result, system=system, rhs=rhs)

    condition_estimate, condition_diagnoses, condition_by_batch = compute_condition_diagnostics(
        Linearization(
            matrix=system,
            rhs=rhs,
            symmetric=True,
            positive_semidefinite=False,
            compute_condition_estimate=True,
        )
    )
    certified_result = LinearSolveResult(
        success=linear_result.success,
        step=linear_result.step,
        diagnosis=tuple(dict.fromkeys((*linear_result.diagnosis, *condition_diagnoses))),
        diagnosis_by_batch=_merge_diagnosis_by_batch(linear_result.diagnosis_by_batch, condition_by_batch),
        condition_estimate=condition_estimate,
        residual_norm=linear_result.residual_norm,
        iterations=linear_result.iterations,
        solver_name=linear_result.solver_name,
        message=linear_result.message,
    )
    return _stabilize_linear_result(certified_result, system=system, rhs=rhs)


def solve_interior_point_linear_system(
    *,
    linear_solver: Any,
    request: InteriorPointLinearSolveRequest,
) -> LinearSolveResult:
    """Solve one reduced interior-point KKT system.

    Parameters
    ----------
    linear_solver : Any
        Configured dense linear backend.
    request : InteriorPointLinearSolveRequest
        Reduced KKT system, right-hand side, and certification policy.

    Returns
    -------
    LinearSolveResult
        Selected and certified KKT solve result.
    """

    linear_result = linear_solver.solve(
        Linearization(
            matrix=request.system,
            rhs=request.rhs,
            symmetric=True,
            positive_semidefinite=False,
            # The common path skips eager condition estimation. Exact condition
            # checks are deferred to selected or terminal states where they
            # inform diagnosis without dominating the timed iteration loop.
            compute_condition_estimate=False,
        )
    )
    if not bool(linear_result.success) or linear_result.step is None:
        return linear_result
    return certify_selected_linear_result(
        linear_result,
        system=request.system,
        rhs=request.rhs,
        compute_condition_estimate=request.compute_condition_estimate,
        force_exact=request.force_exact,
    )