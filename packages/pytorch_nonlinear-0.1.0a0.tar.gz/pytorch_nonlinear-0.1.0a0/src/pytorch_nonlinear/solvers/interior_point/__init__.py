"""Dense primal-dual interior-point solver package."""

from pytorch_nonlinear.solvers.interior_point.core import solve_interior_point_nlp

__all__ = ["solve_interior_point_nlp"]