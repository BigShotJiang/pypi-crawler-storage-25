"""Dense primal-dual interior-point solver entry point."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import torch

from pytorch_nonlinear.api.config import BatchMode, SolverConfig
from pytorch_nonlinear.diagnostics import DiagnosisCode, SolveResult, SolveStatus, TerminationReason
from pytorch_nonlinear.linear import LinearSolveResult, build_linear_solver
from pytorch_nonlinear.problem import ConstrainedNLPProblem
from pytorch_nonlinear.scaling import unscale_interior_point_kkt_step
from pytorch_nonlinear.scaling.interior_point import ScaledInteriorPointKKTModel, build_scaled_interior_point_kkt_model, scale_interior_point_kkt_rhs
from pytorch_nonlinear.solvers.constrained_nlp import (
    _ACTIVE_SET_REPORT_TOL,
    _append_diagnosis,
    _as_dense_state_tensor,
    _prepare_bounds,
    _reshape_state,
    _split_constraints,
)
from pytorch_nonlinear.solvers.interior_point.evaluation import DenseInteriorPointResiduals, as_bool, as_float, build_interior_point_state, lagrangian_hessian, symmetrize
from pytorch_nonlinear.solvers.interior_point.globalization import compute_step_limit, select_trial_step
from pytorch_nonlinear.solvers.interior_point.linear_policy import InteriorPointLinearSolveRequest, solve_interior_point_linear_system
from pytorch_nonlinear.solvers.interior_point.telemetry import history_payload, make_iteration_record
from pytorch_nonlinear.utils import move_to_device, resolve_requested_device


_SUPPORTED_METHODS = {
    "interior_point": "interior_point",
    "ip": "interior_point",
}
_FRACTION_TO_BOUNDARY = 0.995
_MIN_STEP_PARAMETER = 1e-8


@dataclass(frozen=True)
class _InteriorPointIterationLinearModel:
    """Iteration-local reduced KKT model for affine and corrector solves.

    Parameters
    ----------
    dimension : int
        Number of primal variables.
    equality_count : int
        Number of equality constraints in the current linearization.
    inequality_count : int
        Number of inequality rows, including explicit inequalities and bounds.
    inequality_jacobian : torch.Tensor
        Jacobian of the stacked inequality map.
    slacks : torch.Tensor
        Positive slack variables used to keep the inequality path interior.
    inequality_multipliers : torch.Tensor
        Current dual variables associated with the inequality rows.
    equality_rhs : torch.Tensor
        Right-hand side block for equality feasibility restoration.
    scaled_kkt_model : ScaledInteriorPointKKTModel
        Scaled reduced KKT matrix reused by both the affine and corrector steps.
    """

    dimension: int
    equality_count: int
    inequality_count: int
    inequality_jacobian: torch.Tensor
    slacks: torch.Tensor
    inequality_multipliers: torch.Tensor
    equality_rhs: torch.Tensor
    scaled_kkt_model: ScaledInteriorPointKKTModel


def _scalar_tensor_bool(condition: torch.Tensor) -> bool:
    return as_bool(condition)


def _build_iteration_linear_model(
    *,
    hessian: torch.Tensor,
    equality_jacobian: torch.Tensor,
    inequality_jacobian: torch.Tensor,
    residuals: DenseInteriorPointResiduals,
    slacks: torch.Tensor,
    inequality_multipliers: torch.Tensor,
    scaling_config: Any,
    previous_variable_scale: torch.Tensor | None,
) -> _InteriorPointIterationLinearModel:
    """Assemble the iteration-local reduced KKT model.

    Parameters
    ----------
    hessian : torch.Tensor
        Exact Lagrangian Hessian at the current iterate.
    equality_jacobian : torch.Tensor
        Equality Jacobian.
    inequality_jacobian : torch.Tensor
        Stacked inequality Jacobian.
    residuals : DenseInteriorPointResiduals
        Current KKT residual blocks.
    slacks : torch.Tensor
        Current positive slacks.
    inequality_multipliers : torch.Tensor
        Current inequality-dual variables.
    scaling_config : Any
        Scaling configuration passed through to the KKT-scaling layer.
    previous_variable_scale : torch.Tensor | None
        Previous accepted variable scale used to stabilize auto scaling.

    Returns
    -------
    _InteriorPointIterationLinearModel
        Reduced KKT model shared by the affine and corrector solves.
    """

    dimension = hessian.shape[0]
    equality_count = equality_jacobian.shape[0]
    inequality_count = inequality_jacobian.shape[0]

    if inequality_count > 0:
        # Eliminating slack and inequality-dual corrections yields the reduced
        # primal block H + J_g^T S^{-1} Z J_g used by both predictor and corrector.
        diagonal_ratio = inequality_multipliers / slacks
        weighted_inequality_jacobian = diagonal_ratio[:, None] * inequality_jacobian
        augmented_hessian = symmetrize(hessian + inequality_jacobian.T @ weighted_inequality_jacobian)
    else:
        augmented_hessian = symmetrize(hessian)

    equality_rhs = -residuals.equality if equality_count > 0 else hessian.new_zeros(0)
    # The scaled KKT matrix is iteration-local but RHS-independent, so the
    # affine and corrector solves reuse it instead of rebuilding the system twice.
    scaled_kkt_model = build_scaled_interior_point_kkt_model(
        augmented_hessian,
        equality_jacobian,
        inequality_jacobian,
        scaling_config,
        previous_variable_scale=previous_variable_scale,
    )
    return _InteriorPointIterationLinearModel(
        dimension=dimension,
        equality_count=equality_count,
        inequality_count=inequality_count,
        inequality_jacobian=inequality_jacobian,
        slacks=slacks,
        inequality_multipliers=inequality_multipliers,
        equality_rhs=equality_rhs,
        scaled_kkt_model=scaled_kkt_model,
    )


def _solve_primal_dual_step(
    *,
    linear_solver: Any,
    hessian: torch.Tensor | None,
    iteration_linear_model: _InteriorPointIterationLinearModel,
    residuals: DenseInteriorPointResiduals,
    centering_residual: torch.Tensor,
    compute_condition_estimate: bool,
) -> tuple[LinearSolveResult, torch.Tensor | None, torch.Tensor | None, torch.Tensor | None, torch.Tensor | None, torch.Tensor, torch.Tensor, Any]:
    """Solve one reduced primal-dual Newton system.

    Parameters
    ----------
    linear_solver : Any
        Configured dense linear backend.
    hessian : torch.Tensor | None
        Exact Lagrangian Hessian, used only as a tensor source when the problem
        has no inequalities.
    iteration_linear_model : _InteriorPointIterationLinearModel
        Cached reduced KKT model for the current outer iteration.
    residuals : DenseInteriorPointResiduals
        Current KKT residual blocks.
    centering_residual : torch.Tensor
        Complementarity target used for predictor or corrector centering.
    compute_condition_estimate : bool
        Whether certification may attach condition diagnostics.

    Returns
    -------
    tuple[LinearSolveResult, torch.Tensor | None, torch.Tensor | None, torch.Tensor | None, torch.Tensor | None, torch.Tensor, torch.Tensor, Any]
        Certified linear solve result, primal/dual step blocks, and the scaled
        system data used for optional terminal certification.
    """

    dimension = iteration_linear_model.dimension
    equality_count = iteration_linear_model.equality_count
    inequality_count = iteration_linear_model.inequality_count
    zero_source = hessian if hessian is not None else residuals.dual

    if inequality_count > 0:
        # This Schur-complement RHS is the reduced Newton system after removing
        # the explicit slack and complementarity blocks.
        weighted_rhs = (centering_residual - iteration_linear_model.inequality_multipliers * residuals.inequality) / iteration_linear_model.slacks
        primal_rhs = -residuals.dual + iteration_linear_model.inequality_jacobian.T @ weighted_rhs
    else:
        primal_rhs = -residuals.dual

    scaling = iteration_linear_model.scaled_kkt_model.scaling
    system = iteration_linear_model.scaled_kkt_model.system
    rhs = scale_interior_point_kkt_rhs(
        primal_rhs,
        iteration_linear_model.equality_rhs,
        scaling=scaling,
    )

    linear_result = solve_interior_point_linear_system(
        linear_solver=linear_solver,
        request=InteriorPointLinearSolveRequest(
            system=system,
            rhs=rhs,
            compute_condition_estimate=compute_condition_estimate,
        ),
    )
    if not bool(linear_result.success) or linear_result.step is None:
        return linear_result, None, None, None, None, system, rhs, scaling

    step = unscale_interior_point_kkt_step(linear_result.step, scaling, equality_count=equality_count)
    dx = step[:dimension]
    dy = step[dimension:] if equality_count > 0 else zero_source.new_zeros(0)
    if inequality_count > 0:
        ds = -residuals.inequality - iteration_linear_model.inequality_jacobian @ dx
        dz = (-centering_residual - iteration_linear_model.inequality_multipliers * ds) / iteration_linear_model.slacks
    else:
        ds = zero_source.new_zeros(0)
        dz = zero_source.new_zeros(0)
    unscaled_linear_result = LinearSolveResult(
        success=linear_result.success,
        step=step,
        diagnosis=linear_result.diagnosis,
        diagnosis_by_batch=linear_result.diagnosis_by_batch,
        condition_estimate=linear_result.condition_estimate,
        residual_norm=linear_result.residual_norm,
        iterations=linear_result.iterations,
        solver_name=linear_result.solver_name,
        message=linear_result.message,
    )
    return unscaled_linear_result, dx, dy, ds, dz, system, rhs, scaling


def _result_payload(
    *,
    method: str,
    linear_solver_name: str,
    barrier_parameter: float | None,
    scaling_metadata: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Build reproducibility metadata for an interior-point solve result."""

    payload: dict[str, Any] = {
        "method": method,
        "interior_point_hessian": "lagrangian_exact",
        "linear_solver": linear_solver_name,
    }
    if barrier_parameter is not None:
        payload["barrier_parameter"] = barrier_parameter
    if scaling_metadata is not None:
        payload["interior_point_scaling"] = scaling_metadata
    return payload


def solve_interior_point_nlp(
    problem: ConstrainedNLPProblem,
    x0: Any,
    params: Any | None = None,
    config: SolverConfig | None = None,
) -> SolveResult:
    """Solve a constrained NLP with a dense primal-dual interior-point method.

    Parameters
    ----------
    problem : ConstrainedNLPProblem
        Constrained nonlinear program to solve.
    x0 : Any
        Initial primal state.
    params : Any | None, default=None
        Optional user parameters forwarded to callbacks.
    config : SolverConfig | None, default=None
        Solver configuration. When omitted, repository defaults are used.

    Returns
    -------
    SolveResult
        Terminal primal state, KKT metrics, diagnoses, and optional history.
    """

    normalized_config = config if config is not None else SolverConfig()
    normalized_method = _SUPPORTED_METHODS.get(normalized_config.method.lower())
    if normalized_method is None:
        supported = ", ".join(sorted(_SUPPORTED_METHODS))
        raise ValueError(f"Unsupported interior-point method '{normalized_config.method}'. Expected one of: {supported}.")
    if normalized_config.batch_mode is not BatchMode.AUTO:
        raise NotImplementedError("Constrained NLP batch modes are not implemented yet.")
    if normalized_config.linear_solver.lower() == "cholesky":
        raise ValueError("The interior-point solver requires an indefinite-capable linear solver; use 'auto' or 'dense_direct'.")

    problem.validate()
    equality_constraints, inequality_constraints = _split_constraints(problem)
    requested_device = resolve_requested_device(normalized_config.device)
    device_params = move_to_device(params, requested_device) if requested_device is not None else params
    x, original_shape = _as_dense_state_tensor(x0, name="x0", requested_device=requested_device)
    lower, upper = _prepare_bounds(problem.bounds, like=x, original_shape=original_shape)

    state = build_interior_point_state(
        problem,
        x,
        device_params,
        original_shape=original_shape,
        equality_constraints=equality_constraints,
        inequality_constraints=inequality_constraints,
        bounds=problem.bounds,
        lower=lower,
        upper=upper,
    )
    evaluation = state.evaluation
    inequalities = state.inequalities
    equality_multipliers = state.equality_multipliers
    slacks = state.slacks
    inequality_multipliers = state.inequality_multipliers
    residuals = state.residuals

    diagnoses: list[DiagnosisCode] = []
    if _scalar_tensor_bool(evaluation.constraint_violation > normalized_config.tol):
        _append_diagnosis(diagnoses, DiagnosisCode.INFEASIBLE_INITIALIZATION)

    capture_history = normalized_config.debug.capture_history
    history_records: list[Any] = []
    linear_solver = build_linear_solver("dense_direct" if normalized_config.linear_solver.lower() == "auto" else normalized_config.linear_solver)
    compute_linear_condition_estimate = (
        capture_history
        or normalized_config.debug.explain
        or normalized_config.debug.enabled
    )
    last_linear_result: LinearSolveResult | None = None
    last_linear_system: torch.Tensor | None = None
    last_linear_rhs: torch.Tensor | None = None
    last_step_norm: float | None = None
    last_barrier_parameter = residuals.complementarity_gap
    previous_variable_scale: torch.Tensor | None = None
    last_scaling_metadata: dict[str, Any] | None = None
    num_completed_iterations = 0

    initial_converged = residuals.kkt_residual <= normalized_config.tol and _scalar_tensor_bool(
        evaluation.constraint_violation <= normalized_config.tol
    )
    if initial_converged:
        return SolveResult(
            x=_reshape_state(x, original_shape).detach(),
            success=True,
            status=SolveStatus.CONVERGED,
            termination=TerminationReason.GRADIENT_TOL,
            message="Interior-point converged at the initial iterate.",
            num_iter=0,
            objective_value=as_float(evaluation.objective_value),
            gradient_norm=residuals.stationarity_norm,
            step_norm=None,
            constraint_violation=as_float(evaluation.constraint_violation),
            kkt_residual=residuals.kkt_residual,
            complementarity=residuals.complementarity_gap,
            barrier_parameter=residuals.complementarity_gap,
            active_set=evaluation.active_set,
            diagnosis=tuple(diagnoses),
            reproducibility=_result_payload(
                method=normalized_method,
                linear_solver_name=linear_solver.name,
                barrier_parameter=residuals.complementarity_gap,
                scaling_metadata=last_scaling_metadata,
            ),
            diff_mode_used=normalized_config.diff_mode.value,
            diff_valid=False,
            diff_reason="Constrained solver differentiation is not implemented yet.",
        )

    for iteration in range(1, normalized_config.max_iter + 1):
        hessian = lagrangian_hessian(
            problem,
            x,
            device_params,
            original_shape=original_shape,
            equality_constraints=equality_constraints,
            inequality_constraints=inequality_constraints,
            equality_multipliers=equality_multipliers,
            inequality_multipliers=inequality_multipliers[: evaluation.inequality_values.numel()],
        )
        iteration_linear_model = _build_iteration_linear_model(
            hessian=hessian,
            equality_jacobian=evaluation.equality_jacobian,
            inequality_jacobian=inequalities.jacobian,
            residuals=residuals,
            slacks=slacks,
            inequality_multipliers=inequality_multipliers,
            scaling_config=normalized_config.scaling,
            previous_variable_scale=previous_variable_scale,
        )
        affine_result, dx_aff, dy_aff, ds_aff, dz_aff, _, _, affine_scaling = _solve_primal_dual_step(
            linear_solver=linear_solver,
            hessian=hessian,
            iteration_linear_model=iteration_linear_model,
            residuals=residuals,
            centering_residual=residuals.complementarity,
            compute_condition_estimate=compute_linear_condition_estimate,
        )
        for code in affine_scaling.diagnoses:
            _append_diagnosis(diagnoses, code)
        last_scaling_metadata = affine_scaling.to_metadata()
        last_linear_result = affine_result
        for code in affine_result.diagnosis:
            _append_diagnosis(diagnoses, code)
        if dx_aff is None or dy_aff is None or ds_aff is None or dz_aff is None:
            return SolveResult(
                x=_reshape_state(x, original_shape).detach(),
                success=False,
                status=SolveStatus.FAILED,
                termination=TerminationReason.NUMERICAL_FAILURE,
                message="The interior-point Newton system solve failed.",
                num_iter=num_completed_iterations,
                objective_value=as_float(evaluation.objective_value),
                gradient_norm=residuals.stationarity_norm,
                step_norm=last_step_norm,
                constraint_violation=as_float(evaluation.constraint_violation),
                kkt_residual=residuals.kkt_residual,
                complementarity=residuals.complementarity_gap,
                barrier_parameter=last_barrier_parameter,
                active_set=evaluation.active_set,
                history=history_payload(history_records, capture_history=capture_history),
                diagnosis=tuple(diagnoses),
                reproducibility=_result_payload(
                    method=normalized_method,
                    linear_solver_name=linear_solver.name,
                    barrier_parameter=last_barrier_parameter,
                    scaling_metadata=last_scaling_metadata,
                ),
                diff_mode_used=normalized_config.diff_mode.value,
                diff_valid=False,
                diff_reason="Constrained solver differentiation is not implemented yet.",
                linear_condition_estimate=affine_result.condition_estimate,
                linear_residual_norm=affine_result.residual_norm,
            )

        barrier_parameter = residuals.complementarity_gap
        last_barrier_parameter = barrier_parameter
        if slacks.numel() > 0:
            alpha_aff_pri = compute_step_limit(slacks, ds_aff)
            alpha_aff_dual = compute_step_limit(inequality_multipliers, dz_aff)
            mu_aff = as_float(torch.mean((slacks + alpha_aff_pri * ds_aff) * (inequality_multipliers + alpha_aff_dual * dz_aff)))
            sigma = min(1.0, (mu_aff / max(barrier_parameter, 1e-16)) ** 3)
            centering_residual = residuals.complementarity + ds_aff * dz_aff - sigma * barrier_parameter * torch.ones_like(slacks)
        else:
            centering_residual = residuals.complementarity

        linear_result, dx, dy, ds, dz, corrector_system, corrector_rhs, corrector_scaling = _solve_primal_dual_step(
            linear_solver=linear_solver,
            hessian=hessian,
            iteration_linear_model=iteration_linear_model,
            residuals=residuals,
            centering_residual=centering_residual,
            compute_condition_estimate=compute_linear_condition_estimate,
        )
        for code in corrector_scaling.diagnoses:
            _append_diagnosis(diagnoses, code)
        last_scaling_metadata = corrector_scaling.to_metadata()
        previous_variable_scale = corrector_scaling.variable_scale
        last_linear_result = linear_result
        last_linear_system = corrector_system
        last_linear_rhs = corrector_rhs
        for code in linear_result.diagnosis:
            _append_diagnosis(diagnoses, code)
        if dx is None or dy is None or ds is None or dz is None:
            return SolveResult(
                x=_reshape_state(x, original_shape).detach(),
                success=False,
                status=SolveStatus.FAILED,
                termination=TerminationReason.NUMERICAL_FAILURE,
                message="The interior-point corrector system solve failed.",
                num_iter=num_completed_iterations,
                objective_value=as_float(evaluation.objective_value),
                gradient_norm=residuals.stationarity_norm,
                step_norm=last_step_norm,
                constraint_violation=as_float(evaluation.constraint_violation),
                kkt_residual=residuals.kkt_residual,
                complementarity=residuals.complementarity_gap,
                barrier_parameter=last_barrier_parameter,
                active_set=evaluation.active_set,
                history=history_payload(history_records, capture_history=capture_history),
                diagnosis=tuple(diagnoses),
                reproducibility=_result_payload(
                    method=normalized_method,
                    linear_solver_name=linear_solver.name,
                    barrier_parameter=last_barrier_parameter,
                    scaling_metadata=last_scaling_metadata,
                ),
                diff_mode_used=normalized_config.diff_mode.value,
                diff_valid=False,
                diff_reason="Constrained solver differentiation is not implemented yet.",
                linear_condition_estimate=linear_result.condition_estimate,
                linear_residual_norm=linear_result.residual_norm,
            )

        trial_selection = select_trial_step(
            problem=problem,
            x=x,
            dx=dx,
            slacks=slacks,
            ds=ds,
            equality_multipliers=equality_multipliers,
            dy=dy,
            inequality_multipliers=inequality_multipliers,
            dz=dz,
            evaluation=evaluation,
            inequalities=inequalities,
            residuals=residuals,
            device_params=device_params,
            original_shape=original_shape,
            equality_constraints=equality_constraints,
            inequality_constraints=inequality_constraints,
            bounds=problem.bounds,
            lower=lower,
            upper=upper,
            barrier_parameter=barrier_parameter,
            merit_penalty=normalized_config.constrained_merit_penalty,
            tolerance=normalized_config.tol,
            linear_result=linear_result,
            capture_history=capture_history,
            fraction_to_boundary=_FRACTION_TO_BOUNDARY,
            min_step_parameter=_MIN_STEP_PARAMETER,
        )
        trial_records = list(trial_selection.trial_records)

        if trial_selection.accepted_alpha is None or trial_selection.accepted_state is None:
            _append_diagnosis(diagnoses, DiagnosisCode.STEP_REJECTED)
            num_completed_iterations = iteration
            if capture_history:
                history_records.append(
                    make_iteration_record(
                        iteration=iteration,
                        objective_value=as_float(evaluation.objective_value),
                        gradient_norm=residuals.stationarity_norm,
                        constraint_violation=as_float(evaluation.constraint_violation),
                        step_norm=None,
                        complementarity=residuals.complementarity_gap,
                        barrier_parameter=last_barrier_parameter,
                        accepted=False,
                        reason="step_rejected",
                        state=_reshape_state(x, original_shape).detach(),
                        trials=tuple(trial_records),
                        linear_residual_norm=linear_result.residual_norm,
                        linear_condition_estimate=linear_result.condition_estimate,
                    )
                )
            return SolveResult(
                x=_reshape_state(x, original_shape).detach(),
                success=False,
                status=SolveStatus.FAILED,
                termination=TerminationReason.NUMERICAL_FAILURE,
                message="The interior-point merit backtracking rejected all trial steps.",
                num_iter=num_completed_iterations,
                objective_value=as_float(evaluation.objective_value),
                gradient_norm=residuals.stationarity_norm,
                step_norm=None,
                constraint_violation=as_float(evaluation.constraint_violation),
                kkt_residual=residuals.kkt_residual,
                complementarity=residuals.complementarity_gap,
                barrier_parameter=last_barrier_parameter,
                active_set=evaluation.active_set,
                history=history_payload(history_records, capture_history=capture_history),
                diagnosis=tuple(diagnoses),
                reproducibility=_result_payload(
                    method=normalized_method,
                    linear_solver_name=linear_solver.name,
                    barrier_parameter=last_barrier_parameter,
                    scaling_metadata=last_scaling_metadata,
                ),
                diff_mode_used=normalized_config.diff_mode.value,
                diff_valid=False,
                diff_reason="Constrained solver differentiation is not implemented yet.",
                linear_condition_estimate=linear_result.condition_estimate,
                linear_residual_norm=linear_result.residual_norm,
            )

        accepted_state = trial_selection.accepted_state
        x = accepted_state.x
        slacks = accepted_state.slacks
        equality_multipliers = accepted_state.equality_multipliers
        inequality_multipliers = accepted_state.inequality_multipliers
        evaluation = accepted_state.evaluation
        inequalities = accepted_state.inequalities
        residuals = accepted_state.residuals
        last_step_norm = trial_selection.accepted_step_norm
        assert last_step_norm is not None
        last_barrier_parameter = residuals.complementarity_gap
        num_completed_iterations = iteration
        converged_gradient = residuals.kkt_residual <= normalized_config.tol and _scalar_tensor_bool(
            evaluation.constraint_violation <= normalized_config.tol
        )
        converged_step = (
            last_step_norm is not None
            and last_step_norm <= normalized_config.tol
            and _scalar_tensor_bool(evaluation.constraint_violation <= max(normalized_config.tol, _ACTIVE_SET_REPORT_TOL))
            and residuals.kkt_residual <= normalized_config.tol
        )
        if (
            compute_linear_condition_estimate
            and linear_result.condition_estimate is None
            and last_linear_system is not None
            and last_linear_rhs is not None
            and (converged_gradient or converged_step)
        ):
            # Exact condition diagnostics are forced only near termination so the
            # timed path avoids repeated eigenanalysis in every accepted iteration.
            linear_result = solve_interior_point_linear_system(
                linear_solver=linear_solver,
                request=InteriorPointLinearSolveRequest(
                    system=last_linear_system,
                    rhs=last_linear_rhs,
                    compute_condition_estimate=True,
                    force_exact=True,
                ),
            )
            last_linear_result = linear_result
            for code in linear_result.diagnosis:
                _append_diagnosis(diagnoses, code)

        if capture_history:
            history_records.append(
                make_iteration_record(
                    iteration=iteration,
                    objective_value=as_float(evaluation.objective_value),
                    gradient_norm=residuals.stationarity_norm,
                    constraint_violation=as_float(evaluation.constraint_violation),
                    step_norm=last_step_norm,
                    complementarity=residuals.complementarity_gap,
                    barrier_parameter=last_barrier_parameter,
                    accepted=True,
                    reason="accepted",
                    state=_reshape_state(x, original_shape).detach(),
                    trials=tuple(trial_records),
                    linear_residual_norm=linear_result.residual_norm,
                    linear_condition_estimate=linear_result.condition_estimate,
                )
            )

        if converged_gradient:
            return SolveResult(
                x=_reshape_state(x, original_shape).detach(),
                success=True,
                status=SolveStatus.CONVERGED,
                termination=TerminationReason.GRADIENT_TOL,
                message="Interior-point converged to a KKT point.",
                num_iter=num_completed_iterations,
                objective_value=as_float(evaluation.objective_value),
                gradient_norm=residuals.stationarity_norm,
                step_norm=last_step_norm,
                constraint_violation=as_float(evaluation.constraint_violation),
                kkt_residual=residuals.kkt_residual,
                complementarity=residuals.complementarity_gap,
                barrier_parameter=last_barrier_parameter,
                active_set=evaluation.active_set,
                history=history_payload(history_records, capture_history=capture_history),
                diagnosis=tuple(diagnoses),
                reproducibility=_result_payload(
                    method=normalized_method,
                    linear_solver_name=linear_solver.name,
                    barrier_parameter=last_barrier_parameter,
                    scaling_metadata=last_scaling_metadata,
                ),
                diff_mode_used=normalized_config.diff_mode.value,
                diff_valid=False,
                diff_reason="Constrained solver differentiation is not implemented yet.",
                linear_condition_estimate=linear_result.condition_estimate,
                linear_residual_norm=linear_result.residual_norm,
            )
        if converged_step:
            return SolveResult(
                x=_reshape_state(x, original_shape).detach(),
                success=True,
                status=SolveStatus.CONVERGED,
                termination=TerminationReason.STEP_TOL,
                message="Interior-point accepted a step below the tolerance threshold.",
                num_iter=num_completed_iterations,
                objective_value=as_float(evaluation.objective_value),
                gradient_norm=residuals.stationarity_norm,
                step_norm=last_step_norm,
                constraint_violation=as_float(evaluation.constraint_violation),
                kkt_residual=residuals.kkt_residual,
                complementarity=residuals.complementarity_gap,
                barrier_parameter=last_barrier_parameter,
                active_set=evaluation.active_set,
                history=history_payload(history_records, capture_history=capture_history),
                diagnosis=tuple(diagnoses),
                reproducibility=_result_payload(
                    method=normalized_method,
                    linear_solver_name=linear_solver.name,
                    barrier_parameter=last_barrier_parameter,
                    scaling_metadata=last_scaling_metadata,
                ),
                diff_mode_used=normalized_config.diff_mode.value,
                diff_valid=False,
                diff_reason="Constrained solver differentiation is not implemented yet.",
                linear_condition_estimate=linear_result.condition_estimate,
                linear_residual_norm=linear_result.residual_norm,
            )

    if (
        compute_linear_condition_estimate
        and last_linear_result is not None
        and last_linear_result.condition_estimate is None
        and last_linear_system is not None
        and last_linear_rhs is not None
    ):
        # A final exact certification keeps reporting honest without paying the
        # full condition-estimation cost inside the common Newton path.
        last_linear_result = solve_interior_point_linear_system(
            linear_solver=linear_solver,
            request=InteriorPointLinearSolveRequest(
                system=last_linear_system,
                rhs=last_linear_rhs,
                compute_condition_estimate=True,
                force_exact=True,
            ),
        )
        for code in last_linear_result.diagnosis:
            _append_diagnosis(diagnoses, code)

    return SolveResult(
        x=_reshape_state(x, original_shape).detach(),
        success=False,
        status=SolveStatus.MAX_ITER_REACHED,
        termination=TerminationReason.MAX_ITER,
        message="Interior-point reached the iteration budget before satisfying the KKT tolerance.",
        num_iter=num_completed_iterations,
        objective_value=as_float(evaluation.objective_value),
        gradient_norm=residuals.stationarity_norm,
        step_norm=last_step_norm,
        constraint_violation=as_float(evaluation.constraint_violation),
        kkt_residual=residuals.kkt_residual,
        complementarity=residuals.complementarity_gap,
        barrier_parameter=last_barrier_parameter,
        active_set=evaluation.active_set,
        history=history_payload(history_records, capture_history=capture_history),
        diagnosis=tuple(diagnoses),
        reproducibility=_result_payload(
            method=normalized_method,
            linear_solver_name=linear_solver.name,
            barrier_parameter=last_barrier_parameter,
            scaling_metadata=last_scaling_metadata,
        ),
        diff_mode_used=normalized_config.diff_mode.value,
        diff_valid=False,
        diff_reason="Constrained solver differentiation is not implemented yet.",
        linear_condition_estimate=last_linear_result.condition_estimate if last_linear_result is not None else None,
        linear_residual_norm=last_linear_result.residual_norm if last_linear_result is not None else None,
    )