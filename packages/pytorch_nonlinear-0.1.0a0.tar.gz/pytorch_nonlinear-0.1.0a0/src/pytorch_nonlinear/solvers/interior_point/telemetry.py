"""Telemetry materialization helpers for the dense interior-point solver."""

from __future__ import annotations

from dataclasses import dataclass

from pytorch_nonlinear.diagnostics import IterationRecord, TrialRecord


@dataclass(frozen=True)
class PendingTrialRecord:
    """Compact trial-step payload kept in the hot loop before materialization.

    Attributes
    ----------
    attempt : int
        Trial index within the current outer iteration.
    objective_value : float
        Trial objective value.
    step_norm : float
        Norm of the trial primal step.
    accepted : bool
        Whether the trial satisfied the acceptance rule.
    reason : str
        Acceptance or rejection reason recorded for telemetry.
    state : object
        Detached user-facing state snapshot for the trial.
    step_parameter : float
        Backtracking parameter applied to the Newton step.
    linear_solver_iterations : int | None
        Iteration count reported by the linear backend, if available.
    linear_residual_norm : object
        Residual norm from the selected linear solve.
    linear_condition_estimate : object
        Condition estimate attached to the selected linear solve.
    """

    attempt: int
    objective_value: float
    step_norm: float
    accepted: bool
    reason: str
    state: object
    step_parameter: float
    linear_solver_iterations: int | None
    linear_residual_norm: object
    linear_condition_estimate: object


@dataclass(frozen=True)
class PendingIterationRecord:
    """Compact accepted-iteration payload buffered before Python expansion.

    Attributes
    ----------
    iteration : int
        Outer-iteration index.
    objective_value : float
        Objective value at the recorded iterate.
    gradient_norm : float
        First-order optimality metric at the iterate.
    constraint_violation : float
        Feasibility metric at the iterate.
    step_norm : float | None
        Norm of the accepted step, if one exists.
    complementarity : float
        Complementarity measure at the iterate.
    barrier_parameter : float
        Barrier parameter proxy used for telemetry and reproducibility.
    accepted : bool
        Whether the iteration ended in an accepted trial.
    reason : str
        Iteration outcome description.
    state : object
        Detached user-facing state snapshot.
    trials : tuple[PendingTrialRecord, ...]
        Deferred trial-step telemetry attached to the iteration.
    linear_residual_norm : object
        Residual norm from the selected linear solve.
    linear_condition_estimate : object
        Condition estimate from the selected linear solve.
    """

    iteration: int
    objective_value: float
    gradient_norm: float
    constraint_violation: float
    step_norm: float | None
    complementarity: float
    barrier_parameter: float
    accepted: bool
    reason: str
    state: object
    trials: tuple[PendingTrialRecord, ...]
    linear_residual_norm: object
    linear_condition_estimate: object


def _materialize_trial_record(record: PendingTrialRecord) -> TrialRecord:
    return TrialRecord(
        attempt=record.attempt,
        objective_value=record.objective_value,
        step_norm=record.step_norm,
        accepted=record.accepted,
        reason=record.reason,
        state=record.state,
        step_parameter=record.step_parameter,
        linear_solver_iterations=record.linear_solver_iterations,
        linear_residual_norm=record.linear_residual_norm,
        linear_condition_estimate=record.linear_condition_estimate,
    )


def _materialize_iteration_record(record: PendingIterationRecord) -> IterationRecord:
    return IterationRecord(
        iteration=record.iteration,
        objective_value=record.objective_value,
        gradient_norm=record.gradient_norm,
        constraint_violation=record.constraint_violation,
        step_norm=record.step_norm,
        complementarity=record.complementarity,
        barrier_parameter=record.barrier_parameter,
        accepted=record.accepted,
        reason=record.reason,
        state=record.state,
        trials=tuple(_materialize_trial_record(trial) for trial in record.trials),
        linear_residual_norm=record.linear_residual_norm,
        linear_condition_estimate=record.linear_condition_estimate,
    )


def history_payload(
    history_records: list[PendingIterationRecord],
    *,
    capture_history: bool,
) -> tuple[IterationRecord, ...]:
    """Materialize buffered iteration history for the public result object.

    Parameters
    ----------
    history_records : list[PendingIterationRecord]
        Deferred iteration records buffered in the solver loop.
    capture_history : bool
        Whether history capture is enabled.

    Returns
    -------
    tuple[IterationRecord, ...]
        Materialized iteration history, or an empty tuple when history capture is off.
    """

    if not capture_history:
        return ()
    # Materialization is deferred to keep the timed path numeric and avoid
    # constructing Python-facing record objects inside the solver loop.
    return tuple(_materialize_iteration_record(record) for record in history_records)


def make_trial_record(
    *,
    attempt: int,
    objective_value: float,
    step_norm: float,
    accepted: bool,
    reason: str,
    state: object,
    step_parameter: float,
    linear_solver_iterations: int | None,
    linear_residual_norm: object,
    linear_condition_estimate: object,
) -> PendingTrialRecord:
    """Create a deferred trial telemetry record.

    Returns
    -------
    PendingTrialRecord
        Trial payload stored without constructing public telemetry objects.
    """

    return PendingTrialRecord(
        attempt=attempt,
        objective_value=objective_value,
        step_norm=step_norm,
        accepted=accepted,
        reason=reason,
        state=state,
        step_parameter=step_parameter,
        linear_solver_iterations=linear_solver_iterations,
        linear_residual_norm=linear_residual_norm,
        linear_condition_estimate=linear_condition_estimate,
    )


def make_iteration_record(
    *,
    iteration: int,
    objective_value: float,
    gradient_norm: float,
    constraint_violation: float,
    step_norm: float | None,
    complementarity: float,
    barrier_parameter: float,
    accepted: bool,
    reason: str,
    state: object,
    trials: tuple[PendingTrialRecord, ...],
    linear_residual_norm: object,
    linear_condition_estimate: object,
) -> PendingIterationRecord:
    """Create a deferred accepted-iteration telemetry record.

    Returns
    -------
    PendingIterationRecord
        Iteration payload stored until result materialization.
    """

    return PendingIterationRecord(
        iteration=iteration,
        objective_value=objective_value,
        gradient_norm=gradient_norm,
        constraint_violation=constraint_violation,
        step_norm=step_norm,
        complementarity=complementarity,
        barrier_parameter=barrier_parameter,
        accepted=accepted,
        reason=reason,
        state=state,
        trials=trials,
        linear_residual_norm=linear_residual_norm,
        linear_condition_estimate=linear_condition_estimate,
    )