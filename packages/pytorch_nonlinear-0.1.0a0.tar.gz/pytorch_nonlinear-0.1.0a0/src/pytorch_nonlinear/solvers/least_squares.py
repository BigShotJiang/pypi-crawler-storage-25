"""Dense nonlinear least-squares evaluation and solver routines.

The implementation in this module is intentionally narrow: it supports dense
tensor states and dense Jacobians so M3 can land a tested Gauss-Newton and
Levenberg-Marquardt baseline before the later linear abstraction work.
"""

from __future__ import annotations

import math
from collections.abc import Mapping
from dataclasses import dataclass
from functools import partial
from typing import Any

import torch

from pytorch_nonlinear.api.config import BatchMode, ConvergenceValidationMode, DiffMode, SolverConfig
from pytorch_nonlinear.batching import SharedStructureBatchResult
from pytorch_nonlinear.batching.shared_structure import shared_structure_batch_shape, slice_shared_structure_value
from pytorch_nonlinear.diagnostics import DiagnosisCode, IterationRecord, SolveResult, SolveStatus, TerminationReason, TrialRecord
from pytorch_nonlinear.diff import assess_implicit_least_squares
from pytorch_nonlinear.linear import Linearization, build_linear_solver
from pytorch_nonlinear.losses import RobustLoss
from pytorch_nonlinear.problem import NonlinearLeastSquaresProblem
from pytorch_nonlinear.scaling import LeastSquaresScaling, ScaledLeastSquaresLinearModel, build_least_squares_scaling, build_scaled_least_squares_linear_model
from pytorch_nonlinear.steps import initial_trust_region_radius, solve_trust_region_subproblem
from pytorch_nonlinear.utils import move_to_device, resolve_requested_device


_SUPPORTED_METHODS = {
    "auto": "levenberg_marquardt",
    "gn": "gauss_newton",
    "gauss_newton": "gauss_newton",
    "lm": "levenberg_marquardt",
    "levenberg_marquardt": "levenberg_marquardt",
    "tr": "trust_region",
    "trust_region": "trust_region",
}


def _resolve_diff_mode_metadata(diff_mode: DiffMode) -> tuple[str, bool, str, tuple[DiagnosisCode, ...]]:
    """Resolve user-facing differentiation metadata for one solve.

    Parameters
    ----------
    diff_mode : DiffMode
        Requested differentiation mode from the solver configuration.

    Returns
    -------
    tuple[str, bool, str, tuple[DiagnosisCode, ...]]
        Effective differentiation mode, validity flag, explanatory note, and
        any differentiation-related diagnoses.
    """

    if diff_mode is DiffMode.UNROLL:
        return (
            DiffMode.UNROLL.value,
            True,
            "Unrolled differentiation tracks the accepted solver iterations.",
            (),
        )
    if diff_mode is DiffMode.IMPLICIT:
        return (
            DiffMode.IMPLICIT.value,
            False,
            "Implicit differentiation requires certification at the returned point.",
            (),
        )
    return (
        "autograd_jacobian",
        False,
        "Solver sensitivity derivatives are not implemented yet.",
        (),
    )


@dataclass(frozen=True)
class DenseLeastSquaresEvaluation:
    """Dense least-squares local model at a state.

    Parameters
    ----------
    x : torch.Tensor
        Flattened parameter vector used for the evaluation, or a batch of
        flattened vectors with shape ``(batch, num_parameters)``.
    residual : torch.Tensor
        Flattened residual vector evaluated at ``x``, or a batch of residual
        vectors with shape ``(batch, num_residuals)``.
    jacobian : torch.Tensor
        Dense Jacobian with shape ``(num_residuals, num_parameters)``, or a
        batch of Jacobians with shape ``(batch, num_residuals, num_parameters)``.
    objective_value : torch.Tensor
        Scalar least-squares objective ``0.5 * ||r||^2``, or a batch of
        objectives with shape ``(batch,)``.
    gradient : torch.Tensor
        Gradient of the least-squares objective, or a batch of gradients with
        shape ``(batch, num_parameters)``.
    normal_matrix : torch.Tensor
        Dense Gauss-Newton normal matrix ``J^T J``, or a batch of normal
        matrices with shape ``(batch, num_parameters, num_parameters)``.
    """

    x: torch.Tensor
    residual: torch.Tensor
    jacobian: torch.Tensor
    objective_value: torch.Tensor
    gradient: torch.Tensor
    normal_matrix: torch.Tensor


@dataclass(frozen=True)
class TrustRegionRetryLoopResult:
    """State produced by one trust-region inner retry loop."""

    active_trust_region_radius: torch.Tensor
    accepted_mask: torch.Tensor
    accepted_evaluation: DenseLeastSquaresEvaluation
    accepted_step_norms: torch.Tensor
    accepted_linear_residual: torch.Tensor
    accepted_linear_condition: torch.Tensor
    accepted_radius: torch.Tensor
    accepted_ratio: torch.Tensor
    last_linear_residual: torch.Tensor
    last_linear_condition: torch.Tensor
    last_radius: torch.Tensor
    last_ratio: torch.Tensor
    trial_records: list[list[TrialRecord]] | None


@dataclass(frozen=True)
class LevenbergMarquardtRetryLoopResult:
    """State produced by one LM inner retry loop."""

    updated_damping: torch.Tensor
    accepted_mask: torch.Tensor
    accepted_evaluation: DenseLeastSquaresEvaluation
    accepted_step_norms: torch.Tensor
    accepted_linear_residual: torch.Tensor
    accepted_linear_condition: torch.Tensor
    last_step_norms: torch.Tensor
    last_objective_deltas: torch.Tensor
    last_linear_residual: torch.Tensor
    last_linear_condition: torch.Tensor
    trial_records: list[list[TrialRecord]] | None


def _as_dense_state_tensor(
    x: Any,
    *,
    name: str,
    requested_device: torch.device | None = None,
    preserve_graph: bool = False,
) -> tuple[torch.Tensor, torch.Size]:
    """Convert a scalar or tensor-like value into a flat dense tensor.

    Parameters
    ----------
    x : Any
        State value supplied by the user.
    name : str
        Argument name used for error messages.
    requested_device : torch.device | None, optional
        Explicit device to move the state onto before solving.
    preserve_graph : bool, optional
        When ``True``, keep any existing autograd history attached to ``x``.

    Returns
    -------
    tuple[torch.Tensor, torch.Size]
        Flattened tensor and the original shape.

    Raises
    ------
    TypeError
        If ``x`` cannot be interpreted as a dense floating tensor.
    """

    try:
        tensor = torch.as_tensor(x)
    except (TypeError, ValueError) as exc:
        raise TypeError(f"{name} must be convertible to a dense tensor.") from exc

    if requested_device is not None:
        tensor = tensor.to(device=requested_device)

    if tensor.ndim > 1:
        tensor = tensor.reshape(-1)
    elif tensor.ndim == 0:
        tensor = tensor.reshape(1)

    if not torch.is_floating_point(tensor):
        tensor = tensor.to(dtype=torch.float64)
    elif preserve_graph:
        tensor = tensor.clone()
    else:
        tensor = tensor.detach().clone()

    return tensor, torch.as_tensor(x).shape


def _as_dense_state_tensor_with_optional_batch(
    x: Any,
    *,
    name: str,
    original_shape: torch.Size | None = None,
    requested_device: torch.device | None = None,
    preserve_graph: bool = False,
) -> tuple[torch.Tensor, torch.Size, tuple[int, ...]]:
    """Convert a state value into a flat tensor with an optional batch dimension.

    When ``original_shape`` is omitted, this preserves the existing single-
    instance behavior and flattens all non-scalar inputs into one vector. When
    ``original_shape`` is provided, a leading batch dimension is allowed and is
    preserved in the returned tensor.
    """

    try:
        tensor = torch.as_tensor(x)
    except (TypeError, ValueError) as exc:
        raise TypeError(f"{name} must be convertible to a dense tensor.") from exc

    if requested_device is not None:
        tensor = tensor.to(device=requested_device)

    if not torch.is_floating_point(tensor):
        tensor = tensor.to(dtype=torch.float64)
    elif preserve_graph:
        tensor = tensor.clone()
    else:
        tensor = tensor.detach().clone()

    if original_shape is None:
        if tensor.ndim > 1:
            tensor = tensor.reshape(-1)
        elif tensor.ndim == 0:
            tensor = tensor.reshape(1)
        return tensor, torch.as_tensor(x).shape, ()

    state_shape = torch.Size(original_shape)
    if len(state_shape) == 0:
        if tensor.ndim == 0:
            return tensor.reshape(1), state_shape, ()
        if tensor.shape[-1] == 1:
            batch_shape = tuple(int(dim) for dim in tensor.shape[:-1])
            if batch_shape:
                return tensor.reshape(*batch_shape, 1), state_shape, batch_shape
        batch_shape = tuple(int(dim) for dim in tensor.shape)
        return tensor.reshape(*batch_shape, 1), state_shape, batch_shape

    flattened_size = int(torch.Size(state_shape).numel())
    if tensor.ndim < len(state_shape):
        if tensor.ndim == 1 and tensor.numel() == flattened_size:
            return tensor.reshape(-1), state_shape, ()
        raise ValueError(
            f"{name} must end with state shape {tuple(state_shape)}, got shape {tuple(tensor.shape)}."
        )

    if tuple(tensor.shape[-len(state_shape):]) != tuple(state_shape):
        if tensor.shape[-1] == flattened_size:
            batch_shape = tuple(int(dim) for dim in tensor.shape[:-1])
            if batch_shape:
                return tensor.reshape(*batch_shape, flattened_size), state_shape, batch_shape
            return tensor.reshape(-1), state_shape, ()
        if tensor.ndim == 1 and tensor.numel() == flattened_size:
            return tensor.reshape(-1), state_shape, ()
        raise ValueError(
            f"{name} must end with state shape {tuple(state_shape)}, got shape {tuple(tensor.shape)}."
        )

    batch_shape = tuple(int(dim) for dim in tensor.shape[:-len(state_shape)])
    if batch_shape:
        return tensor.reshape(*batch_shape, -1), state_shape, batch_shape
    return tensor.reshape(-1), state_shape, ()


def _flatten_residual(residual: Any, *, dtype: torch.dtype, device: torch.device) -> torch.Tensor:
    """Convert a residual callback output into a flat tensor.

    Parameters
    ----------
    residual : Any
        Residual callback output.
    dtype : torch.dtype
        Target floating dtype.
    device : torch.device
        Target device.

    Returns
    -------
    torch.Tensor
        Flattened residual vector.

    Raises
    ------
    TypeError
        If the residual output cannot be interpreted as a dense vector.
    ValueError
        If the residual is empty.
    """

    if isinstance(residual, torch.Tensor):
        tensor = residual.to(dtype=dtype, device=device)
    elif isinstance(residual, (tuple, list)):
        pieces = [torch.as_tensor(piece, dtype=dtype, device=device).reshape(-1) for piece in residual]
        if not pieces:
            raise ValueError("residual must contain at least one value.")
        tensor = torch.cat(pieces)
    else:
        try:
            tensor = torch.as_tensor(residual, dtype=dtype, device=device)
        except (TypeError, ValueError) as exc:
            raise TypeError("residual must be tensor-like.") from exc

    if tensor.ndim == 0:
        tensor = tensor.reshape(1)
    else:
        tensor = tensor.reshape(-1)

    if tensor.numel() == 0:
        raise ValueError("residual must contain at least one value.")

    return tensor


def _restore_state_shape(x: torch.Tensor, original_shape: torch.Size) -> torch.Tensor:
    """Restore a flat state vector to the user's original tensor shape."""

    if len(original_shape) == 0:
        return x.reshape(())
    return x.reshape(original_shape)


def _objective_as_float(objective_value: torch.Tensor) -> float:
    """Detach a scalar tensor objective into a Python float."""

    return float(objective_value.detach().cpu().item())


def _norm_as_float(vector: torch.Tensor) -> float:
    """Compute a detached Euclidean norm as a Python float."""

    return float(torch.linalg.vector_norm(vector).detach().cpu().item())


def _evaluate_residual(
    problem: NonlinearLeastSquaresProblem,
    x: torch.Tensor,
    original_shape: torch.Size,
    params: Any | None = None,
) -> torch.Tensor:
    """Evaluate the residual callback on the user's state shape and flatten it."""

    residual = problem.residual(_restore_state_shape(x, original_shape), params)
    return _flatten_residual(residual, dtype=x.dtype, device=x.device)


def _shared_structure_vmap_in_dims(value: Any, batch_size: int) -> Any:
    """Build a pytree of vmap in-dims for shared-structure-style inputs."""

    if isinstance(value, torch.Tensor):
        if value.ndim > 0 and value.shape[0] == batch_size:
            return 0
        return None
    if isinstance(value, Mapping):
        return {key: _shared_structure_vmap_in_dims(item, batch_size) for key, item in value.items()}
    if isinstance(value, tuple):
        return tuple(_shared_structure_vmap_in_dims(item, batch_size) for item in value)
    if isinstance(value, list):
        return [_shared_structure_vmap_in_dims(item, batch_size) for item in value]
    return None


def _select_shared_structure_params_and_in_dims(value: Any, indices: torch.Tensor, batch_size: int) -> tuple[Any, Any]:
    """Select active shared-structure params together with an explicit vmap in-dims tree."""

    if isinstance(value, torch.Tensor):
        if value.ndim > 0 and value.shape[0] == batch_size:
            return value.index_select(0, indices.to(device=value.device)), 0
        return value, None
    if isinstance(value, Mapping):
        selected: dict[Any, Any] = {}
        in_dims: dict[Any, Any] = {}
        for key, item in value.items():
            selected_item, item_in_dims = _select_shared_structure_params_and_in_dims(item, indices, batch_size)
            selected[key] = selected_item
            in_dims[key] = item_in_dims
        return selected, in_dims
    if isinstance(value, tuple):
        selected_items = []
        in_dims_items = []
        for item in value:
            selected_item, item_in_dims = _select_shared_structure_params_and_in_dims(item, indices, batch_size)
            selected_items.append(selected_item)
            in_dims_items.append(item_in_dims)
        return tuple(selected_items), tuple(in_dims_items)
    if isinstance(value, list):
        selected_items = []
        in_dims_items = []
        for item in value:
            selected_item, item_in_dims = _select_shared_structure_params_and_in_dims(item, indices, batch_size)
            selected_items.append(selected_item)
            in_dims_items.append(item_in_dims)
        return selected_items, in_dims_items
    return value, None


def evaluate_dense_least_squares(
    problem: NonlinearLeastSquaresProblem,
    x: Any,
    params: Any | None = None,
    original_shape: torch.Size | None = None,
    *,
    preserve_graph: bool = False,
    params_in_dims: Any | None = None,
) -> DenseLeastSquaresEvaluation:
    """Evaluate the dense least-squares local model at a state.

    Parameters
    ----------
    problem : NonlinearLeastSquaresProblem
        Least-squares problem to linearize.
    x : Any
        Scalar or dense tensor-like state value.
    params : Any | None, optional
        Additional user parameters forwarded to the residual callback.
    preserve_graph : bool, optional
        When ``True``, retain autograd connectivity so outer losses can
        differentiate through the returned local model.

    Returns
    -------
    DenseLeastSquaresEvaluation
        Residual, Jacobian, gradient, and normal matrix for the current state.
    """

    state, inferred_shape, batch_shape = _as_dense_state_tensor_with_optional_batch(
        x,
        name="x",
        original_shape=original_shape,
        preserve_graph=preserve_graph,
    )
    state_shape = inferred_shape if original_shape is None else original_shape
    state = state.requires_grad_(True)

    def residual_fn(flat_state: torch.Tensor) -> torch.Tensor:
        return _evaluate_residual(problem, flat_state, state_shape, params)

    if batch_shape:
        if len(batch_shape) != 1:
            raise ValueError(
                "evaluate_dense_least_squares currently supports at most one leading batch dimension."
            )

        batch_size = batch_shape[0]
        resolved_params_in_dims = params_in_dims
        if resolved_params_in_dims is None and params is not None:
            resolved_params_in_dims = _shared_structure_vmap_in_dims(params, batch_size)
        if params is None:
            residual = torch.func.vmap(residual_fn)(state)
            jacobian = torch.func.vmap(torch.func.jacrev(residual_fn), randomness="error")(state)
        else:
            def residual_fn_with_params(flat_state: torch.Tensor, local_params: Any) -> torch.Tensor:
                return _evaluate_residual(problem, flat_state, state_shape, local_params)

            residual = torch.func.vmap(residual_fn_with_params, in_dims=(0, resolved_params_in_dims), randomness="error")(
                state,
                params,
            )
            jacobian = torch.func.vmap(
                torch.func.jacrev(residual_fn_with_params),
                in_dims=(0, resolved_params_in_dims),
                randomness="error",
            )(state, params)

        if residual.ndim == 1:
            residual = residual.reshape(batch_size, 1)
        if jacobian.ndim == 2:
            jacobian = jacobian.reshape(batch_size, 1, -1)
    else:
        residual = residual_fn(state)
        jacobian = torch.autograd.functional.jacobian(residual_fn, state, vectorize=True, create_graph=preserve_graph)
        if jacobian.ndim == 1:
            jacobian = jacobian.reshape(1, -1)

    loss: RobustLoss | None = getattr(problem, "loss", None)
    if loss is not None:
        # Apply IRLS weighting: scale each residual row and Jacobian row by
        # sqrt(w_i) where w_i = rho'(r_i) / r_i.  Keep the weight computation
        # on-graph when unrolled differentiation is requested so outer
        # sensitivities include how IRLS weights change with the residual.
        weights = loss.weights(residual if preserve_graph else residual.detach())
        if torch.any(weights < 0):
            raise ValueError(
                f"Robust loss returned negative weights: min={float(weights.min().item()):.3e}. "
                "Loss implementations must return non-negative IRLS weights."
            )
        sqrt_w = torch.sqrt(weights.clamp(min=1e-12))
        effective_residual = sqrt_w * residual
        row_scale = sqrt_w.unsqueeze(-1) if batch_shape else sqrt_w.unsqueeze(1)
        effective_jacobian = row_scale * jacobian
        objective_values = loss.value(residual if preserve_graph else residual.detach())
        objective_value = objective_values.sum(dim=-1) if batch_shape else objective_values.sum()
    else:
        effective_residual = residual
        effective_jacobian = jacobian
        objective_value = 0.5 * torch.sum(residual * residual, dim=-1) if batch_shape else 0.5 * torch.dot(residual, residual)

    if batch_shape:
        gradient = torch.einsum("bmn,bm->bn", effective_jacobian, effective_residual)
        normal_matrix = torch.einsum("bmn,bmk->bnk", effective_jacobian, effective_jacobian)
    else:
        gradient = effective_jacobian.transpose(0, 1) @ effective_residual
        normal_matrix = effective_jacobian.transpose(0, 1) @ effective_jacobian

    return DenseLeastSquaresEvaluation(
        x=state.detach() if not preserve_graph else state,
        residual=effective_residual.detach() if not preserve_graph else effective_residual,
        jacobian=effective_jacobian.detach() if not preserve_graph else effective_jacobian,
        objective_value=objective_value.detach() if not preserve_graph else objective_value,
        gradient=gradient.detach() if not preserve_graph else gradient,
        normal_matrix=normal_matrix.detach() if not preserve_graph else normal_matrix,
    )


def _initial_damping(normal_matrix: torch.Tensor) -> float:
    """Choose a scale-aware initial damping coefficient for LM."""

    diagonal = torch.diagonal(normal_matrix, dim1=-2, dim2=-1)
    if diagonal.numel() == 0:
        return 1e-3
    if diagonal.ndim > 1:
        return 1e-3 * torch.clamp(diagonal.abs().max(dim=-1).values, min=1.0)
    scale = float(torch.clamp(diagonal.abs().max(), min=1.0).detach().cpu().item())
    return 1e-3 * scale


def _current_scaling(
    evaluation: DenseLeastSquaresEvaluation,
    config: SolverConfig,
    previous_variable_scale: torch.Tensor | None = None,
) -> LeastSquaresScaling:
    """Build scaling data for the current least-squares local model."""

    return build_least_squares_scaling(
        evaluation.residual,
        evaluation.jacobian,
        config.scaling,
        previous_variable_scale=previous_variable_scale,
    )


def _current_linear_model(evaluation: DenseLeastSquaresEvaluation, scaling: LeastSquaresScaling) -> ScaledLeastSquaresLinearModel:
    """Build the scaled linear model used by the current iteration."""

    return build_scaled_least_squares_linear_model(evaluation.residual, evaluation.jacobian, scaling)


def _build_result(
    *,
    problem: NonlinearLeastSquaresProblem,
    params: Any | None,
    x: torch.Tensor,
    original_shape: torch.Size,
    evaluation: DenseLeastSquaresEvaluation,
    history: list[IterationRecord],
    diagnoses: list[DiagnosisCode],
    method: str,
    requested_device: torch.device | None,
    message: str,
    status: SolveStatus,
    termination: TerminationReason,
    success: bool,
    linear_solver_name: str,
    scaling: LeastSquaresScaling,
    convergence_validation_mode: str,
    tol: float,
    diff_mode_used: str = "autograd_jacobian",
    diff_valid: bool = False,
    diff_reason: str = "Solver sensitivity derivatives are not implemented yet.",
    preserve_x_graph: bool = False,
    num_iter: int | None = None,
    step_norm: float | None = None,
    linear_condition_estimate: float | None = None,
    linear_residual_norm: float | None = None,
) -> SolveResult:
    """Build a structured solve result from dense least-squares state."""

    result_x = _restore_state_shape(x if preserve_x_graph else x.detach(), original_shape)
    working_diagnoses = list(diagnoses)
    final_linear_residual = linear_residual_norm if linear_residual_norm is not None else (history[-1].linear_residual_norm if history else None)
    final_linear_condition = linear_condition_estimate if linear_condition_estimate is not None else (history[-1].linear_condition_estimate if history else None)
    final_step_norm = step_norm if step_norm is not None else (history[-1].step_norm if history else 0.0)
    final_num_iter = num_iter if num_iter is not None else len(history)
    diff_condition_estimate: float | None = None
    diff_linear_residual: float | None = None

    if diff_mode_used == DiffMode.UNROLL.value and not success:
        result_x = _restore_state_shape(x.detach(), original_shape)
        diff_valid = False
        diff_reason = "Unrolled differentiation tracked the accepted solver iterations, but the solve did not terminate successfully."
        working_diagnoses.append(DiagnosisCode.DIFF_INVALID)

    if diff_mode_used == DiffMode.IMPLICIT.value:
        implicit_assessment = assess_implicit_least_squares(
            problem=problem,
            x=x,
            params=params,
            original_shape=original_shape,
            success=success,
            status=status,
            termination=termination,
            diagnosis=tuple(dict.fromkeys(working_diagnoses)),
            tol=tol,
        )
        result_x = _restore_state_shape(implicit_assessment.x, original_shape)
        diff_valid = implicit_assessment.valid
        diff_reason = implicit_assessment.reason
        diff_condition_estimate = implicit_assessment.condition_estimate
        diff_linear_residual = implicit_assessment.linear_residual
        working_diagnoses.extend(implicit_assessment.diagnoses)

    unique_diagnoses = tuple(dict.fromkeys(working_diagnoses))

    return SolveResult(
        x=result_x,
        success=success,
        status=status,
        termination=termination,
        message=message,
        num_iter=final_num_iter,
        objective_value=_objective_as_float(evaluation.objective_value),
        gradient_norm=_norm_as_float(evaluation.gradient),
        step_norm=final_step_norm,
        history=tuple(history),
        diagnosis=unique_diagnoses,
        linear_condition_estimate=final_linear_condition,
        linear_residual_norm=final_linear_residual,
        reproducibility={
            "method": method,
            "linear_solver": linear_solver_name,
            "diff_mode": diff_mode_used,
            "convergence_validation": convergence_validation_mode,
            "scaling": scaling.to_metadata(),
            "requested_device": str(requested_device) if requested_device is not None else None,
            "solve_device": str(evaluation.x.device),
            "evaluation_dtype": str(evaluation.x.dtype),
            "solve_dtype": str(evaluation.x.dtype),
        },
        diff_mode_used=diff_mode_used,
        diff_valid=diff_valid,
        diff_reason=diff_reason,
        diff_condition_estimate=diff_condition_estimate,
        diff_linear_residual=diff_linear_residual,
    )


def _history_state(x: torch.Tensor, original_shape: torch.Size) -> torch.Tensor:
    """Clone a state tensor into the user-facing history shape.

    Parameters
    ----------
    x : torch.Tensor
        Flat solver state.
    original_shape : torch.Size
        Original user-provided state shape.

    Returns
    -------
    torch.Tensor
        Detached state with the original shape restored.
    """

    return _restore_state_shape(x.detach().clone(), original_shape)


def _history_states(x: torch.Tensor, original_shape: torch.Size) -> torch.Tensor:
    """Clone batched state tensors into the user-facing history shape."""

    cloned = x.detach().clone()
    if len(original_shape) == 0:
        return cloned.reshape(-1)
    return cloned.reshape(cloned.shape[0], *original_shape)


def _make_trial_record(
    *,
    attempt: int,
    evaluation: DenseLeastSquaresEvaluation | None,
    original_shape: torch.Size,
    step_norm: float | None,
    accepted: bool,
    reason: str,
    step_parameter: float | None = None,
    linear_solver_iterations: int | None = None,
    linear_residual_norm: float | None = None,
    linear_condition_estimate: float | None = None,
    trust_region_radius: float | None = None,
    trust_region_ratio: float | None = None,
) -> TrialRecord:
    """Build a trial record from a candidate least-squares evaluation.

    Parameters
    ----------
    attempt : int
        One-based trial counter within the outer iteration.
    evaluation : DenseLeastSquaresEvaluation | None
        Candidate evaluation to capture in history. This may be ``None`` when
        the linear solve fails before a trial state is formed.
    original_shape : torch.Size
        Original user-provided state shape.
    step_norm : float | None
        Norm of the candidate step.
    accepted : bool
        Whether the candidate was accepted.
    reason : str
        Short explanation for the trial outcome.
    step_parameter : float | None, optional
        Algorithm-specific scalar controlling the step, such as LM damping.
    linear_solver_iterations : int | None, optional
        Iteration count for the inner linear solver.
    linear_residual_norm : float | None, optional
        Residual norm reported by the inner linear solver.
    linear_condition_estimate : float | None, optional
        Condition estimate reported by the inner linear solver.
    trust_region_radius : float | None, optional
        Trust-region radius used for the trial when applicable.
    trust_region_ratio : float | None, optional
        Ratio of actual to predicted reduction for the trial when available.

    Returns
    -------
    TrialRecord
        Structured trial record.
    """

    return TrialRecord(
        attempt=attempt,
        objective_value=_objective_as_float(evaluation.objective_value) if evaluation is not None else None,
        step_norm=step_norm,
        accepted=accepted,
        reason=reason,
        state=_history_state(evaluation.x, original_shape) if evaluation is not None else None,
        step_parameter=step_parameter,
        linear_solver_iterations=linear_solver_iterations,
        linear_residual_norm=linear_residual_norm,
        linear_condition_estimate=linear_condition_estimate,
        trust_region_radius=trust_region_radius,
        trust_region_ratio=trust_region_ratio,
    )


def _stage_trial_record(
    *,
    attempt: int,
    objective_value: float | None,
    step_norm: float | None,
    accepted: bool,
    reason: str,
    state: Any | None,
    step_parameter: float | None = None,
    linear_solver_iterations: int | None = None,
    linear_residual_norm: float | None = None,
    linear_condition_estimate: float | None = None,
    trust_region_radius: float | None = None,
    trust_region_ratio: float | None = None,
) -> tuple[Any, ...]:
    """Capture one trial record payload before materializing the dataclass."""

    return (
        attempt,
        objective_value,
        step_norm,
        accepted,
        reason,
        state,
        step_parameter,
        linear_solver_iterations,
        linear_residual_norm,
        linear_condition_estimate,
        trust_region_radius,
        trust_region_ratio,
    )


def _materialize_trial_record(payload: tuple[Any, ...]) -> TrialRecord:
    """Materialize one staged trial record payload into the public dataclass."""

    return TrialRecord(
        attempt=payload[0],
        objective_value=payload[1],
        step_norm=payload[2],
        accepted=payload[3],
        reason=payload[4],
        state=payload[5],
        step_parameter=payload[6],
        linear_solver_iterations=payload[7],
        linear_residual_norm=payload[8],
        linear_condition_estimate=payload[9],
        trust_region_radius=payload[10],
        trust_region_ratio=payload[11],
    )


def _materialize_trial_record_lists(
    payloads: list[list[tuple[Any, ...]]] | None,
) -> list[list[TrialRecord]] | None:
    """Materialize staged trial payloads into public trial-record lists."""

    if payloads is None:
        return None
    return [[_materialize_trial_record(payload) for payload in record_list] for record_list in payloads]


def _update_trust_region_radius(radius: float, ratio: float | None, boundary_hit: bool) -> float:
    """Update the trust-region radius from the latest trial quality."""

    if isinstance(radius, torch.Tensor) or isinstance(ratio, torch.Tensor) or isinstance(boundary_hit, torch.Tensor):
        radius_tensor = radius if isinstance(radius, torch.Tensor) else torch.as_tensor(radius)
        boundary_tensor = boundary_hit if isinstance(boundary_hit, torch.Tensor) else torch.full_like(radius_tensor, bool(boundary_hit), dtype=torch.bool)
        if ratio is None:
            ratio_tensor = torch.full_like(radius_tensor, float("nan"))
        else:
            ratio_tensor = ratio if isinstance(ratio, torch.Tensor) else torch.full_like(radius_tensor, float(ratio))

        updated = torch.where(
            torch.isnan(ratio_tensor) | (ratio_tensor < 0.25),
            torch.clamp(0.25 * radius_tensor, min=1e-12),
            radius_tensor,
        )
        return torch.where(
            (~torch.isnan(ratio_tensor)) & (ratio_tensor > 0.75) & boundary_tensor,
            torch.clamp(2.0 * radius_tensor, max=1e12),
            updated,
        )

    if ratio is None or ratio < 0.25:
        return max(0.25 * radius, 1e-12)
    if ratio > 0.75 and boundary_hit:
        return min(2.0 * radius, 1e12)
    return radius


def _predicted_reduction_for_original_model(evaluation: DenseLeastSquaresEvaluation, step: torch.Tensor) -> float:
    """Evaluate predicted reduction for the original least-squares model.

    Parameters
    ----------
    evaluation : DenseLeastSquaresEvaluation
        Unscaled least-squares local model at the current iterate.
    step : torch.Tensor
        Candidate step in the original variable coordinates.

    Returns
    -------
    float
        Predicted reduction in the original least-squares quadratic model.
    """

    if evaluation.gradient.ndim > 1:
        matrix_step = torch.einsum("...ij,...j->...i", evaluation.normal_matrix, step)
        return -(torch.einsum("...i,...i->...", evaluation.gradient, step) + 0.5 * torch.einsum("...i,...i->...", step, matrix_step))

    predicted = -(torch.dot(evaluation.gradient, step) + 0.5 * torch.dot(step, evaluation.normal_matrix @ step))
    return float(predicted.detach().cpu().item())


def _normalize_batched_solve_inputs(
    x0: Any,
    params: Any | None,
    config: SolverConfig,
    requested_device: torch.device | None,
    preserve_graph: bool,
) -> tuple[torch.Tensor, torch.Size, int, Any | None, bool]:
    """Normalize single and shared-structure inputs onto one leading-batch representation."""

    shared_structure_requested = config.batch_mode is BatchMode.SHARED_STRUCTURE

    if shared_structure_requested:
        batch_shape = shared_structure_batch_shape(x0)
        if len(batch_shape) != 1:
            raise ValueError("shared_structure batch mode currently supports exactly one leading batch dimension.")
        original_shape = torch.as_tensor(x0).shape[1:]
        x, _, normalized_batch_shape = _as_dense_state_tensor_with_optional_batch(
            x0,
            name="x0",
            original_shape=original_shape,
            requested_device=requested_device,
            preserve_graph=preserve_graph,
        )
        if tuple(normalized_batch_shape) != tuple(batch_shape):
            raise ValueError("shared_structure batch mode requires x0 to preserve the leading batch dimension.")
        runtime_params = move_to_device(params, x.device) if params is not None else None
        return x, torch.Size(original_shape), batch_shape[0], runtime_params, True

    original_shape = torch.as_tensor(x0).shape
    x, _, _ = _as_dense_state_tensor_with_optional_batch(
        x0,
        name="x0",
        original_shape=original_shape,
        requested_device=requested_device,
        preserve_graph=preserve_graph,
    )
    if x.ndim == 1:
        x = x.unsqueeze(0)
    runtime_params = move_to_device(params, x.device) if params is not None else None
    return x, torch.Size(original_shape), 1, runtime_params, False


def _slice_evaluation(evaluation: DenseLeastSquaresEvaluation, index: int) -> DenseLeastSquaresEvaluation:
    """Slice one batch element from a batched evaluation."""

    return DenseLeastSquaresEvaluation(
        x=evaluation.x[index],
        residual=evaluation.residual[index],
        jacobian=evaluation.jacobian[index],
        objective_value=evaluation.objective_value[index],
        gradient=evaluation.gradient[index],
        normal_matrix=evaluation.normal_matrix[index],
    )


def _slice_scaling(scaling: LeastSquaresScaling, index: int) -> LeastSquaresScaling:
    """Slice one batch element from batched scaling data."""

    if scaling.variable_scale.ndim == 1:
        return scaling

    return LeastSquaresScaling(
        variable_scale=scaling.variable_scale[index],
        residual_scale=scaling.residual_scale[index],
        variable_mode=scaling.variable_mode,
        residual_mode=scaling.residual_mode,
        diagnoses=scaling.diagnoses,
        variable_spread=scaling.variable_spread,
        residual_spread=scaling.residual_spread,
    )


def _metric_item(value: float | torch.Tensor | None, index: int) -> float | None:
    """Convert a scalar or batched metric into one Python float."""

    if value is None:
        return None
    if isinstance(value, torch.Tensor):
        if value.ndim == 0:
            return float(value.detach().cpu().item())
        return float(value[index].detach().cpu().item())
    return float(value)


def _metric_list(value: float | torch.Tensor | None, batch_size: int) -> list[float | None]:
    """Convert a scalar or batched metric into Python floats for one batch slice."""

    if value is None:
        return [None] * batch_size
    if isinstance(value, torch.Tensor):
        if value.ndim == 0:
            scalar = float(value.detach().cpu().item())
            return [scalar] * batch_size
        return [float(item) for item in value.detach().cpu().tolist()]
    return [float(value)] * batch_size


def _linear_diagnoses_for_index(linear_result: Any, index: int) -> tuple[DiagnosisCode, ...]:
    """Return the diagnoses that apply to one batch element of a linear solve."""

    diagnosis_by_batch = getattr(linear_result, "diagnosis_by_batch", None)
    if diagnosis_by_batch is not None:
        return diagnosis_by_batch[index]
    return linear_result.diagnosis


def _success_mask(success: bool | torch.Tensor, batch_size: int, device: torch.device) -> torch.Tensor:
    """Normalize backend success outputs into a batch-sized boolean mask."""

    if isinstance(success, torch.Tensor):
        mask = success.to(device=device, dtype=torch.bool)
        if mask.ndim == 0:
            return mask.reshape(1).expand(batch_size)
        return mask.reshape(batch_size)
    return torch.full((batch_size,), bool(success), dtype=torch.bool, device=device)


def _replace_where(mask: torch.Tensor, new_value: torch.Tensor, old_value: torch.Tensor) -> torch.Tensor:
    """Select batched tensor rows by mask while preserving trailing dimensions."""

    expand_shape = mask.shape + (1,) * (old_value.ndim - mask.ndim)
    return torch.where(mask.reshape(expand_shape), new_value, old_value)


def _select_tensor_rows(value: torch.Tensor, indices: torch.Tensor) -> torch.Tensor:
    """Select a subset of leading-batch rows from a tensor."""

    return value.index_select(0, indices.to(device=value.device))


def _scatter_tensor_rows(base: torch.Tensor, indices: torch.Tensor, values: torch.Tensor) -> torch.Tensor:
    """Scatter a subset of leading-batch rows back into a tensor copy."""

    updated = base.clone()
    return updated.index_copy(0, indices.to(device=base.device), values)


def _select_structure_by_in_dims(value: Any, in_dims: Any, indices: torch.Tensor) -> Any:
    """Select a subset of a pytree using an explicit vmap in-dims structure."""

    if isinstance(value, torch.Tensor):
        if in_dims == 0:
            return value.index_select(0, indices.to(device=value.device))
        return value
    if isinstance(value, Mapping):
        return {
            key: _select_structure_by_in_dims(item, in_dims[key], indices)
            for key, item in value.items()
        }
    if isinstance(value, tuple):
        return tuple(_select_structure_by_in_dims(item, in_dim, indices) for item, in_dim in zip(value, in_dims, strict=True))
    if isinstance(value, list):
        return [_select_structure_by_in_dims(item, in_dim, indices) for item, in_dim in zip(value, in_dims, strict=True)]
    return value


def _metric_as_tensor(
    value: float | torch.Tensor | None,
    batch_size: int,
    *,
    dtype: torch.dtype,
    device: torch.device,
) -> torch.Tensor:
    """Normalize a scalar or batched metric into a length-batch tensor."""

    if value is None:
        return torch.full((batch_size,), float("nan"), dtype=dtype, device=device)
    if isinstance(value, torch.Tensor):
        tensor = value.to(dtype=dtype, device=device)
        if tensor.ndim == 0:
            return tensor.reshape(1).expand(batch_size)
        return tensor.reshape(batch_size)
    return torch.full((batch_size,), float(value), dtype=dtype, device=device)


def _select_evaluation(evaluation: DenseLeastSquaresEvaluation, indices: torch.Tensor) -> DenseLeastSquaresEvaluation:
    """Select a subset of batch elements from a dense least-squares evaluation."""

    return DenseLeastSquaresEvaluation(
        x=_select_tensor_rows(evaluation.x, indices),
        residual=_select_tensor_rows(evaluation.residual, indices),
        jacobian=_select_tensor_rows(evaluation.jacobian, indices),
        objective_value=_select_tensor_rows(evaluation.objective_value, indices),
        gradient=_select_tensor_rows(evaluation.gradient, indices),
        normal_matrix=_select_tensor_rows(evaluation.normal_matrix, indices),
    )


def _select_scaling(scaling: LeastSquaresScaling, indices: torch.Tensor) -> LeastSquaresScaling:
    """Select a subset of batch elements from scaling data."""

    variable_scale = scaling.variable_scale
    residual_scale = scaling.residual_scale
    if variable_scale.ndim > 1:
        variable_scale = _select_tensor_rows(variable_scale, indices)
    if residual_scale.ndim > 1:
        residual_scale = _select_tensor_rows(residual_scale, indices)
    return LeastSquaresScaling(
        variable_scale=variable_scale,
        residual_scale=residual_scale,
        variable_mode=scaling.variable_mode,
        residual_mode=scaling.residual_mode,
        diagnoses=scaling.diagnoses,
        variable_spread=scaling.variable_spread,
        residual_spread=scaling.residual_spread,
    )


def _select_linear_model(linear_model: ScaledLeastSquaresLinearModel, indices: torch.Tensor) -> ScaledLeastSquaresLinearModel:
    """Select a subset of batch elements from a scaled linear model."""

    return ScaledLeastSquaresLinearModel(
        residual=_select_tensor_rows(linear_model.residual, indices),
        jacobian=_select_tensor_rows(linear_model.jacobian, indices),
        gradient=_select_tensor_rows(linear_model.gradient, indices),
        normal_matrix=_select_tensor_rows(linear_model.normal_matrix, indices),
        scaling=_select_scaling(linear_model.scaling, indices),
    )


def _scatter_evaluation(
    base: DenseLeastSquaresEvaluation,
    indices: torch.Tensor,
    values: DenseLeastSquaresEvaluation,
) -> DenseLeastSquaresEvaluation:
    """Scatter a subset evaluation back into a full-batch evaluation."""

    return DenseLeastSquaresEvaluation(
        x=_scatter_tensor_rows(base.x, indices, values.x),
        residual=_scatter_tensor_rows(base.residual, indices, values.residual),
        jacobian=_scatter_tensor_rows(base.jacobian, indices, values.jacobian),
        objective_value=_scatter_tensor_rows(base.objective_value, indices, values.objective_value),
        gradient=_scatter_tensor_rows(base.gradient, indices, values.gradient),
        normal_matrix=_scatter_tensor_rows(base.normal_matrix, indices, values.normal_matrix),
    )


def _expand_active_mask(local_mask: torch.Tensor, active_indices: torch.Tensor, batch_size: int) -> torch.Tensor:
    """Expand a local active-slice mask back to the full batch size."""

    full_mask = torch.zeros(batch_size, dtype=torch.bool, device=active_indices.device)
    return full_mask.index_copy(0, active_indices, local_mask)


def _resolve_method(method: str) -> str:
    """Normalize the user-supplied least-squares method name."""

    normalized_method = method.lower()
    if normalized_method not in _SUPPORTED_METHODS:
        supported = ", ".join(sorted(_SUPPORTED_METHODS))
        raise ValueError(f"Unsupported least-squares method '{method}'. Expected one of: {supported}.")
    return _SUPPORTED_METHODS[normalized_method]


def _objective_value_from_problem(
    problem: NonlinearLeastSquaresProblem,
    x: torch.Tensor,
    original_shape: torch.Size,
    params: Any | None,
) -> torch.Tensor:
    """Evaluate the scalar least-squares objective for one flat state tensor."""

    residual = _evaluate_residual(problem, x, original_shape, params)
    loss: RobustLoss | None = getattr(problem, "loss", None)
    if loss is not None:
        return loss.value(residual).sum()
    return 0.5 * torch.dot(residual, residual)


def _candidate_params(
    params: Any | None,
    *,
    index: int,
    batch_size: int,
    batch_output: bool,
) -> Any | None:
    """Resolve per-instance params for convergence validation."""

    if params is None or not batch_output:
        return params
    return slice_shared_structure_value(params, index, batch_size)


def _directional_probe_directions(state_dim: int, probe_count: int, device: torch.device, dtype: torch.dtype) -> tuple[torch.Tensor, ...]:
    """Build deterministic low-cost probe directions for local objective checks."""

    if state_dim <= 0 or probe_count <= 0:
        return ()

    basis_count = min(state_dim, probe_count)
    directions = [
        torch.nn.functional.one_hot(torch.tensor(index, device=device), num_classes=state_dim).to(dtype=dtype)
        for index in range(basis_count)
    ]
    if probe_count > basis_count and state_dim > 1:
        all_ones = torch.ones(state_dim, dtype=dtype, device=device)
        directions.append(all_ones / torch.linalg.vector_norm(all_ones))
    return tuple(directions[:probe_count])


def _directional_stationary_screen(
    problem: NonlinearLeastSquaresProblem,
    evaluation: DenseLeastSquaresEvaluation,
    *,
    original_shape: torch.Size,
    params: Any | None,
    tol: float,
    probe_count: int,
) -> tuple[bool, str]:
    """Screen stationary points for obvious descent directions using cheap probes."""

    state = evaluation.x.detach().reshape(-1)
    directions = _directional_probe_directions(int(state.numel()), probe_count, state.device, state.dtype)
    if not directions:
        return True, "Directional convergence screen found no descent direction."

    base_objective = float(evaluation.objective_value.detach().cpu().item())
    step_scale = max(1e-4, math.sqrt(max(tol, 1e-16)) * (1.0 + float(torch.linalg.vector_norm(state).detach().cpu().item())))
    decrease_tolerance = max(1e-12, tol * max(1.0, abs(base_objective)))

    for direction in directions:
        forward = _objective_value_from_problem(problem, state + step_scale * direction, original_shape, params)
        backward = _objective_value_from_problem(problem, state - step_scale * direction, original_shape, params)
        best_probe = min(float(forward.detach().cpu().item()), float(backward.detach().cpu().item()))
        if best_probe < base_objective - decrease_tolerance:
            return (
                False,
                "Gradient norm satisfied the convergence tolerance, but a directional objective probe found a lower "
                f"nearby point (objective {best_probe:.3e} < {base_objective:.3e}).",
            )

    return True, "Directional convergence screen found no descent direction."


def _strict_curvature_validation(
    problem: NonlinearLeastSquaresProblem,
    evaluation: DenseLeastSquaresEvaluation,
    *,
    original_shape: torch.Size,
    params: Any | None,
    tol: float,
) -> tuple[bool, str]:
    """Validate a stationary point with an exact dense Hessian curvature check."""

    x = evaluation.x.detach().clone().requires_grad_(True)

    def objective_fn(flat_state: torch.Tensor) -> torch.Tensor:
        return _objective_value_from_problem(problem, flat_state, original_shape, params)

    hessian = torch.autograd.functional.hessian(objective_fn, x, vectorize=True)
    if hessian.ndim == 0:
        hessian = hessian.reshape(1, 1)
    hessian = 0.5 * (hessian + hessian.transpose(-2, -1))
    min_eigenvalue = float(torch.linalg.eigvalsh(hessian).min().detach().cpu().item())
    curvature_tolerance = max(1e-10, 10.0 * tol)
    if not math.isfinite(min_eigenvalue) or min_eigenvalue < -curvature_tolerance:
        return (
            False,
            "Gradient norm satisfied the convergence tolerance, but the objective is not locally minimizing "
            f"(min Hessian eigenvalue={min_eigenvalue:.3e}).",
        )

    return True, "Strict curvature validation confirmed a local minimum."


def _validate_convergence_candidate(
    problem: NonlinearLeastSquaresProblem,
    evaluation: DenseLeastSquaresEvaluation,
    *,
    original_shape: torch.Size,
    params: Any | None,
    tol: float,
    validation_mode: ConvergenceValidationMode,
    probe_count: int,
    exact_hessian_dim_limit: int,
) -> tuple[bool, str, tuple[DiagnosisCode, ...]]:
    """Validate that a stationary point is locally minimizing the objective."""

    if _norm_as_float(evaluation.gradient) > tol:
        return False, "Gradient norm does not satisfy the convergence tolerance.", ()

    if validation_mode is ConvergenceValidationMode.GRADIENT_ONLY:
        return True, "Gradient norm satisfied the convergence tolerance.", ()

    state_dim = int(evaluation.x.numel())
    if validation_mode is ConvergenceValidationMode.STRICT:
        converged, message = _strict_curvature_validation(
            problem,
            evaluation,
            original_shape=original_shape,
            params=params,
            tol=tol,
        )
        return converged, message, (() if converged else (DiagnosisCode.STATIONARY_NONMINIMUM,))

    screened, screen_message = _directional_stationary_screen(
        problem,
        evaluation,
        original_shape=original_shape,
        params=params,
        tol=tol,
        probe_count=probe_count,
    )
    if not screened:
        return False, screen_message, (DiagnosisCode.STATIONARY_NONMINIMUM,)

    if validation_mode is ConvergenceValidationMode.DIRECTIONAL:
        return True, "Gradient norm satisfied the convergence tolerance after directional validation.", ()

    residual_norm = _norm_as_float(evaluation.residual)
    residual_threshold = max(1e-8, math.sqrt(max(tol, 1e-16)))
    if residual_norm <= residual_threshold:
        return True, "Gradient norm satisfied the convergence tolerance and residual norm is small.", ()

    if state_dim <= exact_hessian_dim_limit:
        converged, message = _strict_curvature_validation(
            problem,
            evaluation,
            original_shape=original_shape,
            params=params,
            tol=tol,
        )
        return converged, message, (() if converged else (DiagnosisCode.STATIONARY_NONMINIMUM,))

    return (
        False,
        "Gradient norm satisfied the convergence tolerance, but auto convergence validation could not certify "
        f"a local minimum without an exact curvature check at state dimension {state_dim}. Increase "
        "convergence_validation_exact_hessian_dim_limit or use convergence_validation='directional' if heuristic "
        "screening is acceptable.",
        (DiagnosisCode.CONVERGENCE_UNVERIFIED,),
    )


def _set_terminal_state(
    *,
    index: int,
    statuses: list[SolveStatus | None],
    terminations: list[TerminationReason | None],
    messages: list[str],
    succeeded: torch.Tensor,
    completed: torch.Tensor,
    status: SolveStatus,
    termination: TerminationReason,
    message: str,
    success: bool,
) -> None:
    """Write one terminal per-instance solver state."""

    statuses[index] = status
    terminations[index] = termination
    messages[index] = message
    succeeded[index] = success
    completed[index] = True


def _finalize_convergence_candidate(
    *,
    problem: NonlinearLeastSquaresProblem,
    evaluation: DenseLeastSquaresEvaluation,
    index: int,
    original_shape: torch.Size,
    params: Any | None,
    tol: float,
    validation_mode: ConvergenceValidationMode,
    probe_count: int,
    exact_hessian_dim_limit: int,
    diagnoses: list[list[DiagnosisCode]],
    statuses: list[SolveStatus | None],
    terminations: list[TerminationReason | None],
    messages: list[str],
    succeeded: torch.Tensor,
    completed: torch.Tensor,
    converged_termination: TerminationReason,
    converged_message: str | None = None,
) -> None:
    """Validate a stationary candidate and write the matching terminal state."""

    converged, message, convergence_diagnoses = _validate_convergence_candidate(
        problem,
        evaluation,
        original_shape=original_shape,
        params=params,
        tol=tol,
        validation_mode=validation_mode,
        probe_count=probe_count,
        exact_hessian_dim_limit=exact_hessian_dim_limit,
    )
    if converged:
        _set_terminal_state(
            index=index,
            statuses=statuses,
            terminations=terminations,
            messages=messages,
            succeeded=succeeded,
            completed=completed,
            status=SolveStatus.CONVERGED,
            termination=converged_termination,
            message=message if converged_message is None else converged_message,
            success=True,
        )
        return

    diagnoses[index].extend(convergence_diagnoses)
    _set_terminal_state(
        index=index,
        statuses=statuses,
        terminations=terminations,
        messages=messages,
        succeeded=succeeded,
        completed=completed,
        status=SolveStatus.FAILED,
        termination=TerminationReason.NUMERICAL_FAILURE,
        message=message,
        success=False,
    )


def _finalize_failure(
    *,
    index: int,
    message: str,
    statuses: list[SolveStatus | None],
    terminations: list[TerminationReason | None],
    messages: list[str],
    succeeded: torch.Tensor,
    completed: torch.Tensor,
    diagnoses: list[list[DiagnosisCode]] | None = None,
    diagnosis: DiagnosisCode | None = None,
) -> None:
    """Write a numerical-failure terminal state, optionally appending one diagnosis."""

    if diagnoses is not None and diagnosis is not None:
        diagnoses[index].append(diagnosis)
    _set_terminal_state(
        index=index,
        statuses=statuses,
        terminations=terminations,
        messages=messages,
        succeeded=succeeded,
        completed=completed,
        status=SolveStatus.FAILED,
        termination=TerminationReason.NUMERICAL_FAILURE,
        message=message,
        success=False,
    )


def _run_trust_region_retry_loop(
    *,
    problem: NonlinearLeastSquaresProblem,
    active_evaluation: DenseLeastSquaresEvaluation,
    current_linear_model: ScaledLeastSquaresLinearModel,
    active_params: Any | None,
    active_params_in_dims: Any | None,
    original_shape: torch.Size,
    track_unrolled_gradients: bool,
    linear_solver: Any,
    active_trust_region_radius: torch.Tensor,
    max_trials: int,
    acceptance_threshold: float,
    capture_history: bool,
) -> TrustRegionRetryLoopResult:
    """Run the trust-region inner retry loop for one active batch slice."""

    active_batch_size = int(active_evaluation.x.shape[0])
    staged_trial_records: list[list[tuple[Any, ...]]] | None = [[] for _ in range(active_batch_size)] if capture_history else None
    accepted_mask = torch.zeros(active_batch_size, dtype=torch.bool, device=active_evaluation.x.device)
    accepted_evaluation = active_evaluation
    accepted_step_norms = torch.zeros(active_batch_size, dtype=active_evaluation.x.dtype, device=active_evaluation.x.device)
    accepted_linear_residual = torch.full((active_batch_size,), float("nan"), dtype=active_evaluation.x.dtype, device=active_evaluation.x.device)
    accepted_linear_condition = torch.full((active_batch_size,), float("nan"), dtype=active_evaluation.x.dtype, device=active_evaluation.x.device)
    accepted_radius = active_trust_region_radius.clone()
    accepted_ratio = torch.full((active_batch_size,), float("nan"), dtype=active_evaluation.x.dtype, device=active_evaluation.x.device)
    last_linear_residual = torch.full((active_batch_size,), float("nan"), dtype=active_evaluation.x.dtype, device=active_evaluation.x.device)
    last_linear_condition = torch.full((active_batch_size,), float("nan"), dtype=active_evaluation.x.dtype, device=active_evaluation.x.device)
    last_radius = active_trust_region_radius.clone()
    last_ratio = torch.full((active_batch_size,), float("nan"), dtype=active_evaluation.x.dtype, device=active_evaluation.x.device)

    for attempt in range(1, max_trials + 1):
        remaining = ~accepted_mask
        if not torch.any(remaining):
            break
        remaining_indices = torch.nonzero(remaining, as_tuple=False).flatten()
        remaining_index_list = remaining_indices.detach().cpu().tolist() if capture_history else None
        remaining_evaluation = _select_evaluation(active_evaluation, remaining_indices)
        remaining_linear_model = _select_linear_model(current_linear_model, remaining_indices)
        remaining_radius = _select_tensor_rows(active_trust_region_radius, remaining_indices)
        remaining_params = (
            active_params
            if active_params_in_dims is None
            else _select_structure_by_in_dims(active_params, active_params_in_dims, remaining_indices)
        )
        step_result = solve_trust_region_subproblem(
            remaining_linear_model.normal_matrix,
            remaining_linear_model.gradient,
            remaining_linear_model.scaling.variable_scale,
            remaining_radius,
            linear_solver,
        )
        linear_result = step_result.linear_result
        remaining_batch_size = int(remaining_indices.shape[0])
        success_mask = _success_mask(step_result.success, remaining_batch_size, active_evaluation.x.device)
        if linear_result is not None and linear_result.step is not None and step_result.step is not None:
            step = remaining_linear_model.scaling.variable_scale * step_result.step
            trial_evaluation = evaluate_dense_least_squares(
                problem,
                remaining_evaluation.x + step,
                remaining_params,
                original_shape=original_shape,
                preserve_graph=track_unrolled_gradients,
                params_in_dims=active_params_in_dims,
            )
            actual_reduction = remaining_evaluation.objective_value - trial_evaluation.objective_value
            predicted_reduction = _predicted_reduction_for_original_model(remaining_evaluation, step)
            ratio = torch.where(predicted_reduction > 0.0, actual_reduction / predicted_reduction, torch.full_like(actual_reduction, float("nan")))
            accepted_now = success_mask & (actual_reduction > 0.0) & torch.isfinite(ratio) & (ratio >= acceptance_threshold)
            updated_radius = _update_trust_region_radius(remaining_radius, ratio, step_result.boundary_hit)
            remaining_linear_residual = _metric_as_tensor(
                linear_result.residual_norm,
                remaining_batch_size,
                dtype=active_evaluation.x.dtype,
                device=active_evaluation.x.device,
            )
            remaining_linear_condition = _metric_as_tensor(
                linear_result.condition_estimate,
                remaining_batch_size,
                dtype=active_evaluation.x.dtype,
                device=active_evaluation.x.device,
            )
            last_linear_residual = _scatter_tensor_rows(last_linear_residual, remaining_indices, remaining_linear_residual)
            last_linear_condition = _scatter_tensor_rows(last_linear_condition, remaining_indices, remaining_linear_condition)
            last_radius = _scatter_tensor_rows(last_radius, remaining_indices, remaining_radius)
            remaining_last_ratio = _select_tensor_rows(last_ratio, remaining_indices)
            remaining_last_ratio = torch.where(torch.isfinite(ratio), ratio, remaining_last_ratio)
            last_ratio = _scatter_tensor_rows(last_ratio, remaining_indices, remaining_last_ratio)

            if capture_history and remaining_index_list is not None and staged_trial_records is not None:
                accepted_now_list = accepted_now.detach().cpu().tolist()
                ratio_list = _metric_list(ratio, remaining_batch_size)
                radius_list = [float(item) for item in remaining_radius.detach().cpu().tolist()]
                step_norm_list = [float(item) for item in torch.linalg.vector_norm(step, dim=-1).detach().cpu().tolist()]
                step_parameter_list = _metric_list(step_result.damping, remaining_batch_size)
                linear_residual_list = _metric_list(remaining_linear_residual, remaining_batch_size)
                linear_condition_list = _metric_list(remaining_linear_condition, remaining_batch_size)
                trial_objective_list = [float(item) for item in trial_evaluation.objective_value.detach().cpu().tolist()]
                trial_states = _history_states(trial_evaluation.x, original_shape)
                for remaining_local_index, active_local_index in enumerate(remaining_index_list):
                    accepted_trial = bool(accepted_now_list[remaining_local_index])
                    ratio_value = ratio_list[remaining_local_index]
                    radius_value = radius_list[remaining_local_index]
                    reason = (
                        f"Accepted trust-region step with ratio={ratio_value:.3e} and radius={radius_value:.3e}."
                        if accepted_trial
                        else f"Rejected trust-region step with ratio={(ratio_value if ratio_value is not None else float('nan')):.3e} and radius={radius_value:.3e}."
                    )
                    staged_trial_records[active_local_index].append(
                        _stage_trial_record(
                            attempt=attempt,
                            objective_value=trial_objective_list[remaining_local_index],
                            step_norm=step_norm_list[remaining_local_index],
                            accepted=accepted_trial,
                            reason=reason,
                            state=trial_states[remaining_local_index],
                            step_parameter=step_parameter_list[remaining_local_index],
                            linear_solver_iterations=linear_result.iterations,
                            linear_residual_norm=linear_residual_list[remaining_local_index],
                            linear_condition_estimate=linear_condition_list[remaining_local_index],
                            trust_region_radius=radius_value,
                            trust_region_ratio=ratio_value,
                        )
                    )

            accepted_remaining_indices = torch.nonzero(accepted_now, as_tuple=False).flatten()
            if accepted_remaining_indices.numel() > 0:
                accepted_active_indices = remaining_indices.index_select(0, accepted_remaining_indices)
                accepted_evaluation = _scatter_evaluation(
                    accepted_evaluation,
                    accepted_active_indices,
                    _select_evaluation(trial_evaluation, accepted_remaining_indices),
                )
                accepted_step_norms = _scatter_tensor_rows(
                    accepted_step_norms,
                    accepted_active_indices,
                    _select_tensor_rows(torch.linalg.vector_norm(step, dim=-1), accepted_remaining_indices),
                )
                accepted_linear_residual = _scatter_tensor_rows(
                    accepted_linear_residual,
                    accepted_active_indices,
                    _select_tensor_rows(remaining_linear_residual, accepted_remaining_indices),
                )
                accepted_linear_condition = _scatter_tensor_rows(
                    accepted_linear_condition,
                    accepted_active_indices,
                    _select_tensor_rows(remaining_linear_condition, accepted_remaining_indices),
                )
                accepted_radius = _scatter_tensor_rows(
                    accepted_radius,
                    accepted_active_indices,
                    _select_tensor_rows(remaining_radius, accepted_remaining_indices),
                )
                accepted_ratio = _scatter_tensor_rows(
                    accepted_ratio,
                    accepted_active_indices,
                    _select_tensor_rows(ratio, accepted_remaining_indices),
                )
            accepted_mask = accepted_mask | _expand_active_mask(accepted_now, remaining_indices, active_batch_size)
            active_trust_region_radius = _scatter_tensor_rows(active_trust_region_radius, remaining_indices, updated_radius)
            continue

        if capture_history and remaining_index_list is not None and staged_trial_records is not None:
            failed_radius_list = [float(item) for item in remaining_radius.detach().cpu().tolist()]
            failed_step_parameter_list = _metric_list(step_result.damping, remaining_batch_size)
            failed_linear_residual_list = (
                _metric_list(linear_result.residual_norm, remaining_batch_size) if linear_result is not None else [None] * remaining_batch_size
            )
            failed_linear_condition_list = (
                _metric_list(linear_result.condition_estimate, remaining_batch_size) if linear_result is not None else [None] * remaining_batch_size
            )
            for remaining_local_index, active_local_index in enumerate(remaining_index_list):
                radius_value = failed_radius_list[remaining_local_index]
                staged_trial_records[active_local_index].append(
                    _stage_trial_record(
                        attempt=attempt,
                        objective_value=None,
                        step_norm=None,
                        accepted=False,
                        reason=f"Trust-region subproblem failed at radius={radius_value:.3e}.",
                        state=None,
                        step_parameter=failed_step_parameter_list[remaining_local_index],
                        linear_solver_iterations=linear_result.iterations if linear_result is not None else None,
                        linear_residual_norm=failed_linear_residual_list[remaining_local_index],
                        linear_condition_estimate=failed_linear_condition_list[remaining_local_index],
                        trust_region_radius=radius_value,
                    )
                )
        active_trust_region_radius = _scatter_tensor_rows(
            active_trust_region_radius,
            remaining_indices,
            torch.clamp(0.25 * remaining_radius, min=1e-12),
        )

    return TrustRegionRetryLoopResult(
        active_trust_region_radius=active_trust_region_radius,
        accepted_mask=accepted_mask,
        accepted_evaluation=accepted_evaluation,
        accepted_step_norms=accepted_step_norms,
        accepted_linear_residual=accepted_linear_residual,
        accepted_linear_condition=accepted_linear_condition,
        accepted_radius=accepted_radius,
        accepted_ratio=accepted_ratio,
        last_linear_residual=last_linear_residual,
        last_linear_condition=last_linear_condition,
        last_radius=last_radius,
        last_ratio=last_ratio,
        trial_records=_materialize_trial_record_lists(staged_trial_records),
    )


def _run_levenberg_marquardt_retry_loop(
    *,
    problem: NonlinearLeastSquaresProblem,
    active_evaluation: DenseLeastSquaresEvaluation,
    current_linear_model: ScaledLeastSquaresLinearModel,
    active_params: Any | None,
    active_params_in_dims: Any | None,
    original_shape: torch.Size,
    track_unrolled_gradients: bool,
    linear_solver: Any,
    active_damping: torch.Tensor,
    max_attempts: int,
    capture_history: bool,
    diagnoses: list[list[DiagnosisCode]],
    active_index_list: list[int],
) -> LevenbergMarquardtRetryLoopResult:
    """Run the Levenberg-Marquardt inner retry loop for one active batch slice."""

    active_batch_size = int(active_evaluation.x.shape[0])
    trial_records: list[list[TrialRecord]] | None = [[] for _ in range(active_batch_size)] if capture_history else None
    accepted_mask = torch.zeros(active_batch_size, dtype=torch.bool, device=active_evaluation.x.device)
    accepted_evaluation = active_evaluation
    accepted_step_norms = torch.zeros(active_batch_size, dtype=active_evaluation.x.dtype, device=active_evaluation.x.device)
    accepted_linear_residual = torch.full((active_batch_size,), float("nan"), dtype=active_evaluation.x.dtype, device=active_evaluation.x.device)
    accepted_linear_condition = torch.full((active_batch_size,), float("nan"), dtype=active_evaluation.x.dtype, device=active_evaluation.x.device)
    accepted_damping = active_damping.clone()
    current_damping = active_damping.clone()
    last_step_norms = torch.full((active_batch_size,), float("nan"), dtype=active_evaluation.x.dtype, device=active_evaluation.x.device)
    last_objective_deltas = torch.full((active_batch_size,), float("nan"), dtype=active_evaluation.x.dtype, device=active_evaluation.x.device)
    last_linear_residual = torch.full((active_batch_size,), float("nan"), dtype=active_evaluation.x.dtype, device=active_evaluation.x.device)
    last_linear_condition = torch.full((active_batch_size,), float("nan"), dtype=active_evaluation.x.dtype, device=active_evaluation.x.device)

    for attempt in range(1, max_attempts + 1):
        remaining = ~accepted_mask
        if not torch.any(remaining):
            break
        remaining_indices = torch.nonzero(remaining, as_tuple=False).flatten()
        remaining_index_list = remaining_indices.detach().cpu().tolist() if capture_history else None
        remaining_evaluation = _select_evaluation(active_evaluation, remaining_indices)
        remaining_linear_model = _select_linear_model(current_linear_model, remaining_indices)
        remaining_damping = _select_tensor_rows(current_damping, remaining_indices)
        remaining_params = (
            active_params
            if active_params_in_dims is None
            else _select_structure_by_in_dims(active_params, active_params_in_dims, remaining_indices)
        )
        linear_result = linear_solver.solve(
            Linearization(
                matrix=remaining_linear_model.normal_matrix,
                rhs=-remaining_linear_model.gradient,
                damping=remaining_damping,
                symmetric=True,
                positive_semidefinite=True,
            )
        )
        remaining_batch_size = int(remaining_indices.shape[0])
        success_mask = _success_mask(linear_result.success, remaining_batch_size, active_evaluation.x.device)
        if linear_result.step is None:
            success_mask = torch.zeros_like(success_mask)
            step = torch.zeros_like(remaining_evaluation.x)
        else:
            step = remaining_linear_model.scaling.variable_scale * linear_result.step
        trial_evaluation = evaluate_dense_least_squares(
            problem,
            remaining_evaluation.x + step,
            remaining_params,
            original_shape=original_shape,
            preserve_graph=track_unrolled_gradients,
            params_in_dims=active_params_in_dims,
        )
        step_norms = torch.linalg.vector_norm(step, dim=-1)
        objective_deltas = trial_evaluation.objective_value - remaining_evaluation.objective_value
        objective_decreased = objective_deltas < 0.0
        accepted_now = success_mask & objective_decreased
        last_step_norms = _scatter_tensor_rows(last_step_norms, remaining_indices, step_norms)
        last_objective_deltas = _scatter_tensor_rows(last_objective_deltas, remaining_indices, objective_deltas)
        remaining_linear_residual = _metric_as_tensor(
            linear_result.residual_norm,
            remaining_batch_size,
            dtype=active_evaluation.x.dtype,
            device=active_evaluation.x.device,
        )
        remaining_linear_condition = _metric_as_tensor(
            linear_result.condition_estimate,
            remaining_batch_size,
            dtype=active_evaluation.x.dtype,
            device=active_evaluation.x.device,
        )
        last_linear_residual = _scatter_tensor_rows(last_linear_residual, remaining_indices, remaining_linear_residual)
        last_linear_condition = _scatter_tensor_rows(last_linear_condition, remaining_indices, remaining_linear_condition)

        for remaining_local_index in range(remaining_batch_size):
            local_linear_diagnoses = _linear_diagnoses_for_index(linear_result, remaining_local_index)
            if local_linear_diagnoses:
                diagnoses[active_index_list[int(remaining_indices[remaining_local_index].detach().cpu().item())]].extend(local_linear_diagnoses)
        if capture_history and remaining_index_list is not None and trial_records is not None:
            for remaining_local_index, active_local_index in enumerate(remaining_index_list):
                if not success_mask[remaining_local_index]:
                    reason = f"Linear solve failed for LM damping={float(remaining_damping[remaining_local_index].detach().cpu().item()):.3e}."
                    trial_records[active_local_index].append(
                        _make_trial_record(
                            attempt=attempt,
                            evaluation=None,
                            original_shape=original_shape,
                            step_norm=None,
                            accepted=False,
                            reason=reason,
                            step_parameter=float(remaining_damping[remaining_local_index].detach().cpu().item()),
                            linear_solver_iterations=linear_result.iterations,
                            linear_residual_norm=_metric_item(remaining_linear_residual, remaining_local_index),
                            linear_condition_estimate=_metric_item(remaining_linear_condition, remaining_local_index),
                        )
                    )
                else:
                    accepted_trial = bool(accepted_now[remaining_local_index].detach().cpu().item())
                    reason = (
                        f"Accepted LM step with damping={float(remaining_damping[remaining_local_index].detach().cpu().item()):.3e}."
                        if accepted_trial
                        else f"Rejected LM step with damping={float(remaining_damping[remaining_local_index].detach().cpu().item()):.3e}."
                    )
                    trial_records[active_local_index].append(
                        _make_trial_record(
                            attempt=attempt,
                            evaluation=_slice_evaluation(trial_evaluation, remaining_local_index),
                            original_shape=original_shape,
                            step_norm=float(step_norms[remaining_local_index].detach().cpu().item()),
                            accepted=accepted_trial,
                            reason=reason,
                            step_parameter=float(remaining_damping[remaining_local_index].detach().cpu().item()),
                            linear_solver_iterations=linear_result.iterations,
                            linear_residual_norm=_metric_item(remaining_linear_residual, remaining_local_index),
                            linear_condition_estimate=_metric_item(remaining_linear_condition, remaining_local_index),
                        )
                    )

        accepted_remaining_indices = torch.nonzero(accepted_now, as_tuple=False).flatten()
        if accepted_remaining_indices.numel() > 0:
            accepted_active_indices = remaining_indices.index_select(0, accepted_remaining_indices)
            accepted_evaluation = _scatter_evaluation(
                accepted_evaluation,
                accepted_active_indices,
                _select_evaluation(trial_evaluation, accepted_remaining_indices),
            )
            accepted_step_norms = _scatter_tensor_rows(
                accepted_step_norms,
                accepted_active_indices,
                _select_tensor_rows(step_norms, accepted_remaining_indices),
            )
            accepted_linear_residual = _scatter_tensor_rows(
                accepted_linear_residual,
                accepted_active_indices,
                _select_tensor_rows(remaining_linear_residual, accepted_remaining_indices),
            )
            accepted_linear_condition = _scatter_tensor_rows(
                accepted_linear_condition,
                accepted_active_indices,
                _select_tensor_rows(remaining_linear_condition, accepted_remaining_indices),
            )
            accepted_damping = _scatter_tensor_rows(
                accepted_damping,
                accepted_active_indices,
                _select_tensor_rows(remaining_damping, accepted_remaining_indices),
            )
        accepted_mask = accepted_mask | _expand_active_mask(accepted_now, remaining_indices, active_batch_size)
        current_damping = _scatter_tensor_rows(
            current_damping,
            remaining_indices,
            torch.where(accepted_now, remaining_damping, remaining_damping * 10.0),
        )

    return LevenbergMarquardtRetryLoopResult(
        updated_damping=torch.where(accepted_mask, torch.clamp(accepted_damping * 0.3, min=1e-12), current_damping),
        accepted_mask=accepted_mask,
        accepted_evaluation=accepted_evaluation,
        accepted_step_norms=accepted_step_norms,
        accepted_linear_residual=accepted_linear_residual,
        accepted_linear_condition=accepted_linear_condition,
        last_step_norms=last_step_norms,
        last_objective_deltas=last_objective_deltas,
        last_linear_residual=last_linear_residual,
        last_linear_condition=last_linear_condition,
        trial_records=trial_records,
    )


def _solve_least_squares_batched_core(
    problem: NonlinearLeastSquaresProblem,
    x_batch: torch.Tensor,
    original_shape: torch.Size,
    params: Any | None,
    config: SolverConfig,
    requested_device: torch.device | None,
    *,
    batch_output: bool,
) -> tuple[SolveResult, ...]:
    """Run the unified least-squares solver core on a leading-batch representation."""

    method = _resolve_method(config.method)
    diff_mode_used, diff_valid, diff_reason, diff_diagnoses = _resolve_diff_mode_metadata(config.diff_mode)
    track_unrolled_gradients = config.diff_mode is DiffMode.UNROLL
    result_builder = partial(
        _build_result,
        problem=problem,
        convergence_validation_mode=config.convergence_validation.value,
        tol=config.tol,
        diff_mode_used=diff_mode_used,
        diff_valid=diff_valid,
        diff_reason=diff_reason,
        preserve_x_graph=track_unrolled_gradients,
    )
    batch_size = int(x_batch.shape[0])
    linear_solver = build_linear_solver(config.linear_solver)
    capture_history = config.debug.capture_history
    histories: list[list[IterationRecord]] = [[] for _ in range(batch_size)]
    iteration_counts: list[int] = [0] * batch_size
    final_step_norms: list[float | None] = [None] * batch_size
    final_linear_residuals: list[float | None] = [None] * batch_size
    final_linear_conditions: list[float | None] = [None] * batch_size
    diagnoses: list[list[DiagnosisCode]] = [list(diff_diagnoses) for _ in range(batch_size)]
    statuses: list[SolveStatus | None] = [None] * batch_size
    terminations: list[TerminationReason | None] = [None] * batch_size
    messages: list[str] = [""] * batch_size
    succeeded = torch.zeros(batch_size, dtype=torch.bool, device=x_batch.device)
    completed = torch.zeros(batch_size, dtype=torch.bool, device=x_batch.device)
    finalize_convergence_candidate = partial(
        _finalize_convergence_candidate,
        problem=problem,
        original_shape=original_shape,
        tol=config.tol,
        validation_mode=config.convergence_validation,
        probe_count=config.convergence_validation_probe_count,
        exact_hessian_dim_limit=config.convergence_validation_exact_hessian_dim_limit,
        diagnoses=diagnoses,
        statuses=statuses,
        terminations=terminations,
        messages=messages,
        succeeded=succeeded,
        completed=completed,
    )
    finalize_failure = partial(
        _finalize_failure,
        statuses=statuses,
        terminations=terminations,
        messages=messages,
        succeeded=succeeded,
        completed=completed,
    )

    evaluation = evaluate_dense_least_squares(
        problem,
        x_batch,
        params,
        original_shape=original_shape,
        preserve_graph=track_unrolled_gradients,
    )
    previous_variable_scale: torch.Tensor | None = None
    gradient_norms = torch.linalg.vector_norm(evaluation.gradient, dim=-1)
    initially_converged = gradient_norms <= config.tol
    for index in torch.nonzero(initially_converged, as_tuple=False).flatten().tolist():
        local_params = _candidate_params(params, index=index, batch_size=batch_size, batch_output=batch_output)
        finalize_convergence_candidate(
            evaluation=_slice_evaluation(evaluation, index),
            index=index,
            params=local_params,
            converged_termination=TerminationReason.GRADIENT_TOL,
        )

    current_scaling = _current_scaling(evaluation, config, previous_variable_scale=previous_variable_scale)
    previous_variable_scale = current_scaling.variable_scale.detach().clone()
    current_linear_model = _current_linear_model(evaluation, current_scaling)
    damping = _initial_damping(current_linear_model.normal_matrix)
    if not isinstance(damping, torch.Tensor):
        damping = torch.full((batch_size,), float(damping), dtype=evaluation.x.dtype, device=evaluation.x.device)
    trust_region_radius = initial_trust_region_radius(
        current_linear_model.normal_matrix,
        current_linear_model.gradient,
        evaluation.gradient,
        current_scaling.variable_scale,
        linear_solver,
        config.trust_region_initial_radius,
    )
    if not isinstance(trust_region_radius, torch.Tensor):
        trust_region_radius = torch.full((batch_size,), float(trust_region_radius), dtype=evaluation.x.dtype, device=evaluation.x.device)

    for iteration in range(1, config.max_iter + 1):
        active = ~completed
        if not torch.any(active):
            break

        active_indices = torch.nonzero(active, as_tuple=False).flatten()
        active_index_list = active_indices.detach().cpu().tolist()
        active_evaluation = _select_evaluation(evaluation, active_indices)
        active_params_in_dims = None
        if batch_output and params is not None:
            active_params, active_params_in_dims = _select_shared_structure_params_and_in_dims(params, active_indices, batch_size)
        else:
            active_params = params
        active_previous_variable_scale = (
            None if previous_variable_scale is None else _select_tensor_rows(previous_variable_scale, active_indices)
        )

        current_scaling = _current_scaling(
            active_evaluation,
            config,
            previous_variable_scale=active_previous_variable_scale,
        )
        previous_variable_scale = _scatter_tensor_rows(
            previous_variable_scale,
            active_indices,
            current_scaling.variable_scale.detach().clone(),
        )
        current_linear_model = _current_linear_model(active_evaluation, current_scaling)
        rhs = -current_linear_model.gradient
        for index in active_index_list:
            diagnoses[index].extend(current_scaling.diagnoses)

        if method == "gauss_newton":
            linear_result = linear_solver.solve(
                Linearization(
                    matrix=current_linear_model.normal_matrix,
                    rhs=rhs,
                    damping=torch.zeros_like(damping),
                    symmetric=True,
                    positive_semidefinite=True,
                )
            )
            active_batch_size = int(active_indices.shape[0])
            success_mask = _success_mask(linear_result.success, active_batch_size, evaluation.x.device)
            if linear_result.step is None:
                success_mask = torch.zeros_like(success_mask)
                step = torch.zeros_like(active_evaluation.x)
            else:
                step = current_scaling.variable_scale * linear_result.step
            trial_evaluation = evaluate_dense_least_squares(
                problem,
                active_evaluation.x + step,
                active_params,
                original_shape=original_shape,
                preserve_graph=track_unrolled_gradients,
                params_in_dims=active_params_in_dims,
            )
            step_norms = torch.linalg.vector_norm(step, dim=-1)
            accept_mask = success_mask & (trial_evaluation.objective_value < active_evaluation.objective_value)
            reject_mask = success_mask & ~accept_mask
            failure_mask = ~success_mask

            for local_index, index in enumerate(active_index_list):
                local_linear_diagnoses = _linear_diagnoses_for_index(linear_result, local_index)
                if local_linear_diagnoses:
                    diagnoses[index].extend(local_linear_diagnoses)
                iteration_counts[index] += 1
                final_step_norms[index] = float(step_norms[local_index].detach().cpu().item()) if accept_mask[local_index] else None
                final_linear_residuals[index] = _metric_item(linear_result.residual_norm, local_index)
                final_linear_conditions[index] = _metric_item(linear_result.condition_estimate, local_index)
                if failure_mask[local_index]:
                    reason = linear_result.message or "Gauss-Newton linear solve failed."
                    if capture_history:
                        histories[index].append(
                            IterationRecord(
                                iteration=iteration,
                                objective_value=_objective_as_float(_slice_evaluation(active_evaluation, local_index).objective_value),
                                gradient_norm=_norm_as_float(_slice_evaluation(active_evaluation, local_index).gradient),
                                step_norm=None,
                                accepted=False,
                                reason=reason,
                                state=_history_state(active_evaluation.x[local_index], original_shape),
                                linear_residual_norm=_metric_item(linear_result.residual_norm, local_index),
                                linear_condition_estimate=_metric_item(linear_result.condition_estimate, local_index),
                                trials=(
                                    _make_trial_record(
                                        attempt=1,
                                        evaluation=None,
                                        original_shape=original_shape,
                                        step_norm=None,
                                        accepted=False,
                                        reason=reason,
                                        linear_solver_iterations=linear_result.iterations,
                                        linear_residual_norm=_metric_item(linear_result.residual_norm, local_index),
                                        linear_condition_estimate=_metric_item(linear_result.condition_estimate, local_index),
                                    ),
                                ),
                            )
                        )
                    finalize_failure(
                        index=index,
                        message="Gauss-Newton linear solve failed.",
                    )
                elif reject_mask[local_index]:
                    trial_slice = _slice_evaluation(trial_evaluation, local_index)
                    if capture_history:
                        histories[index].append(
                            IterationRecord(
                                iteration=iteration,
                                objective_value=_objective_as_float(_slice_evaluation(active_evaluation, local_index).objective_value),
                                gradient_norm=_norm_as_float(_slice_evaluation(active_evaluation, local_index).gradient),
                                step_norm=None,
                                accepted=False,
                                reason="Gauss-Newton full step increased the objective.",
                                state=_history_state(active_evaluation.x[local_index], original_shape),
                                linear_residual_norm=_metric_item(linear_result.residual_norm, local_index),
                                linear_condition_estimate=_metric_item(linear_result.condition_estimate, local_index),
                                trials=(
                                    _make_trial_record(
                                        attempt=1,
                                        evaluation=trial_slice,
                                        original_shape=original_shape,
                                        step_norm=float(step_norms[local_index].detach().cpu().item()),
                                        accepted=False,
                                        reason="Gauss-Newton full step increased the objective.",
                                        linear_solver_iterations=linear_result.iterations,
                                        linear_residual_norm=_metric_item(linear_result.residual_norm, local_index),
                                        linear_condition_estimate=_metric_item(linear_result.condition_estimate, local_index),
                                    ),
                                ),
                            )
                        )
                    finalize_failure(
                        index=index,
                        message="Gauss-Newton rejected a non-decreasing step.",
                        diagnoses=diagnoses,
                        diagnosis=DiagnosisCode.STEP_REJECTED,
                    )
                elif accept_mask[local_index]:
                    trial_slice = _slice_evaluation(trial_evaluation, local_index)
                    if capture_history:
                        histories[index].append(
                            IterationRecord(
                                iteration=iteration,
                                objective_value=_objective_as_float(trial_slice.objective_value),
                                gradient_norm=_norm_as_float(trial_slice.gradient),
                                step_norm=float(step_norms[local_index].detach().cpu().item()),
                                accepted=True,
                                reason="Accepted Gauss-Newton full step.",
                                state=_history_state(trial_slice.x, original_shape),
                                linear_residual_norm=_metric_item(linear_result.residual_norm, local_index),
                                linear_condition_estimate=_metric_item(linear_result.condition_estimate, local_index),
                                trials=(
                                    _make_trial_record(
                                        attempt=1,
                                        evaluation=trial_slice,
                                        original_shape=original_shape,
                                        step_norm=float(step_norms[local_index].detach().cpu().item()),
                                        accepted=True,
                                        reason="Accepted Gauss-Newton full step.",
                                        linear_solver_iterations=linear_result.iterations,
                                        linear_residual_norm=_metric_item(linear_result.residual_norm, local_index),
                                        linear_condition_estimate=_metric_item(linear_result.condition_estimate, local_index),
                                    ),
                                ),
                            )
                        )

            updated_active_evaluation = DenseLeastSquaresEvaluation(
                x=_replace_where(accept_mask, trial_evaluation.x, active_evaluation.x),
                residual=_replace_where(accept_mask, trial_evaluation.residual, active_evaluation.residual),
                jacobian=_replace_where(accept_mask, trial_evaluation.jacobian, active_evaluation.jacobian),
                objective_value=torch.where(accept_mask, trial_evaluation.objective_value, active_evaluation.objective_value),
                gradient=_replace_where(accept_mask, trial_evaluation.gradient, active_evaluation.gradient),
                normal_matrix=_replace_where(accept_mask, trial_evaluation.normal_matrix, active_evaluation.normal_matrix),
            )
            evaluation = _scatter_evaluation(evaluation, active_indices, updated_active_evaluation)
            updated_gradient_norms = torch.linalg.vector_norm(updated_active_evaluation.gradient, dim=-1)
            converged_step = accept_mask & (step_norms <= config.tol) & (updated_gradient_norms <= config.tol)
            converged_grad = accept_mask & ~converged_step & (updated_gradient_norms <= config.tol)
            for local_index in torch.nonzero(converged_step | converged_grad, as_tuple=False).flatten().tolist():
                index = active_index_list[local_index]
                local_params = _candidate_params(params, index=index, batch_size=batch_size, batch_output=batch_output)
                finalize_convergence_candidate(
                    evaluation=_slice_evaluation(updated_active_evaluation, local_index),
                    index=index,
                    params=local_params,
                    converged_termination=(TerminationReason.STEP_TOL if converged_step[local_index] else TerminationReason.GRADIENT_TOL),
                    converged_message=(
                        "Step norm satisfied the convergence tolerance."
                        if converged_step[local_index]
                        else None
                    ),
                )
            continue

        if method == "trust_region":
            active_trust_region_radius = _select_tensor_rows(trust_region_radius, active_indices)
            trust_region_retry_result = _run_trust_region_retry_loop(
                problem=problem,
                active_evaluation=active_evaluation,
                current_linear_model=current_linear_model,
                active_params=active_params,
                active_params_in_dims=active_params_in_dims,
                original_shape=original_shape,
                track_unrolled_gradients=track_unrolled_gradients,
                linear_solver=linear_solver,
                active_trust_region_radius=active_trust_region_radius,
                max_trials=config.trust_region_max_trials,
                acceptance_threshold=config.trust_region_acceptance_threshold,
                capture_history=capture_history,
            )

            updated_active_evaluation = trust_region_retry_result.accepted_evaluation
            evaluation = _scatter_evaluation(evaluation, active_indices, updated_active_evaluation)
            trust_region_radius = _scatter_tensor_rows(
                trust_region_radius,
                active_indices,
                trust_region_retry_result.active_trust_region_radius,
            )
            gradient_norms = torch.linalg.vector_norm(updated_active_evaluation.gradient, dim=-1)

            accepted_mask_list = (
                trust_region_retry_result.accepted_mask.detach().cpu().tolist() if capture_history else None
            )
            accepted_step_norms_list = (
                _metric_list(trust_region_retry_result.accepted_step_norms, len(active_index_list))
                if capture_history
                else None
            )
            accepted_linear_residual_list = (
                _metric_list(trust_region_retry_result.accepted_linear_residual, len(active_index_list))
                if capture_history
                else None
            )
            last_linear_residual_list = (
                _metric_list(trust_region_retry_result.last_linear_residual, len(active_index_list))
                if capture_history
                else None
            )
            accepted_linear_condition_list = (
                _metric_list(trust_region_retry_result.accepted_linear_condition, len(active_index_list))
                if capture_history
                else None
            )
            last_linear_condition_list = (
                _metric_list(trust_region_retry_result.last_linear_condition, len(active_index_list))
                if capture_history
                else None
            )
            accepted_radius_list = (
                _metric_list(trust_region_retry_result.accepted_radius, len(active_index_list))
                if capture_history
                else None
            )
            last_radius_list = (
                _metric_list(trust_region_retry_result.last_radius, len(active_index_list))
                if capture_history
                else None
            )
            accepted_ratio_list = (
                _metric_list(trust_region_retry_result.accepted_ratio, len(active_index_list))
                if capture_history
                else None
            )
            last_ratio_list = (
                _metric_list(trust_region_retry_result.last_ratio, len(active_index_list))
                if capture_history
                else None
            )
            updated_objective_list = (
                [float(item) for item in updated_active_evaluation.objective_value.detach().cpu().tolist()]
                if capture_history
                else None
            )
            updated_gradient_norm_list = (
                [float(item) for item in gradient_norms.detach().cpu().tolist()]
                if capture_history
                else None
            )
            updated_history_states = _history_states(updated_active_evaluation.x, original_shape) if capture_history else None

            for local_index, index in enumerate(active_index_list):
                iteration_counts[index] += 1
                final_step_norms[index] = (
                    _metric_item(trust_region_retry_result.accepted_step_norms, local_index)
                    if trust_region_retry_result.accepted_mask[local_index]
                    else None
                )
                final_linear_residuals[index] = _metric_item(
                    trust_region_retry_result.accepted_linear_residual
                    if trust_region_retry_result.accepted_mask[local_index]
                    else trust_region_retry_result.last_linear_residual,
                    local_index,
                )
                final_linear_conditions[index] = _metric_item(
                    trust_region_retry_result.accepted_linear_condition
                    if trust_region_retry_result.accepted_mask[local_index]
                    else trust_region_retry_result.last_linear_condition,
                    local_index,
                )
                if capture_history:
                    accepted_trial = bool(accepted_mask_list[local_index]) if accepted_mask_list is not None else False
                    local_evaluation = _slice_evaluation(updated_active_evaluation, local_index)
                    local_linear_residual = (
                        accepted_linear_residual_list[local_index]
                        if accepted_trial and accepted_linear_residual_list is not None
                        else last_linear_residual_list[local_index] if last_linear_residual_list is not None else None
                    )
                    local_linear_condition = (
                        accepted_linear_condition_list[local_index]
                        if accepted_trial and accepted_linear_condition_list is not None
                        else last_linear_condition_list[local_index] if last_linear_condition_list is not None else None
                    )
                    local_radius = (
                        accepted_radius_list[local_index]
                        if accepted_trial and accepted_radius_list is not None
                        else last_radius_list[local_index] if last_radius_list is not None else None
                    )
                    local_ratio = (
                        accepted_ratio_list[local_index]
                        if accepted_trial and accepted_ratio_list is not None
                        else last_ratio_list[local_index] if last_ratio_list is not None else None
                    )
                    histories[index].append(
                        IterationRecord(
                            iteration=iteration,
                            objective_value=updated_objective_list[local_index] if updated_objective_list is not None else _objective_as_float(local_evaluation.objective_value),
                            gradient_norm=updated_gradient_norm_list[local_index] if updated_gradient_norm_list is not None else _norm_as_float(local_evaluation.gradient),
                            step_norm=accepted_step_norms_list[local_index] if accepted_trial and accepted_step_norms_list is not None else None,
                            accepted=accepted_trial,
                            reason=(
                                trust_region_retry_result.trial_records[local_index][-1].reason
                                if trust_region_retry_result.trial_records is not None and trust_region_retry_result.trial_records[local_index]
                                else "Trust-region step acceptance did not find an acceptable step."
                            ),
                            state=updated_history_states[local_index] if updated_history_states is not None else _history_state(local_evaluation.x, original_shape),
                            linear_residual_norm=local_linear_residual,
                            linear_condition_estimate=local_linear_condition,
                            trust_region_radius=local_radius,
                            trust_region_ratio=local_ratio,
                            trials=tuple(trust_region_retry_result.trial_records[local_index]) if trust_region_retry_result.trial_records is not None else (),
                        )
                    )
                if not trust_region_retry_result.accepted_mask[local_index]:
                    if gradient_norms[local_index] <= config.tol:
                        local_params = _candidate_params(params, index=index, batch_size=batch_size, batch_output=batch_output)
                        finalize_convergence_candidate(
                            evaluation=_slice_evaluation(updated_active_evaluation, local_index),
                            index=index,
                            params=local_params,
                            converged_termination=TerminationReason.GRADIENT_TOL,
                        )
                    else:
                        finalize_failure(
                            index=index,
                            message="Trust-region acceptance did not find an acceptable step.",
                            diagnoses=diagnoses,
                            diagnosis=DiagnosisCode.STEP_REJECTED,
                        )

            converged_step = (
                trust_region_retry_result.accepted_mask
                & (trust_region_retry_result.accepted_step_norms <= config.tol)
                & (gradient_norms <= config.tol)
            )
            converged_grad = trust_region_retry_result.accepted_mask & ~converged_step & (gradient_norms <= config.tol)
            for local_index in torch.nonzero(converged_step | converged_grad, as_tuple=False).flatten().tolist():
                index = active_index_list[local_index]
                local_params = _candidate_params(params, index=index, batch_size=batch_size, batch_output=batch_output)
                finalize_convergence_candidate(
                    evaluation=_slice_evaluation(updated_active_evaluation, local_index),
                    index=index,
                    params=local_params,
                    converged_termination=(TerminationReason.STEP_TOL if converged_step[local_index] else TerminationReason.GRADIENT_TOL),
                    converged_message=(
                        "Step norm satisfied the convergence tolerance."
                        if converged_step[local_index]
                        else None
                    ),
                )
            continue

        active_batch_size = int(active_indices.shape[0])
        active_damping = _select_tensor_rows(damping, active_indices)
        lm_retry_result = _run_levenberg_marquardt_retry_loop(
            problem=problem,
            active_evaluation=active_evaluation,
            current_linear_model=current_linear_model,
            active_params=active_params,
            active_params_in_dims=active_params_in_dims,
            original_shape=original_shape,
            track_unrolled_gradients=track_unrolled_gradients,
            linear_solver=linear_solver,
            active_damping=active_damping,
            max_attempts=8,
            capture_history=capture_history,
            diagnoses=diagnoses,
            active_index_list=active_index_list,
        )

        updated_active_evaluation = lm_retry_result.accepted_evaluation
        evaluation = _scatter_evaluation(evaluation, active_indices, updated_active_evaluation)
        damping = _scatter_tensor_rows(damping, active_indices, lm_retry_result.updated_damping)
        gradient_norms = torch.linalg.vector_norm(updated_active_evaluation.gradient, dim=-1)

        for local_index, index in enumerate(active_index_list):
            iteration_counts[index] += 1
            final_step_norms[index] = _metric_item(lm_retry_result.accepted_step_norms, local_index) if lm_retry_result.accepted_mask[local_index] else None
            final_linear_residuals[index] = _metric_item(
                lm_retry_result.accepted_linear_residual if lm_retry_result.accepted_mask[local_index] else lm_retry_result.last_linear_residual,
                local_index,
            )
            final_linear_conditions[index] = _metric_item(
                lm_retry_result.accepted_linear_condition if lm_retry_result.accepted_mask[local_index] else lm_retry_result.last_linear_condition,
                local_index,
            )
            if capture_history:
                histories[index].append(
                    IterationRecord(
                        iteration=iteration,
                        objective_value=_objective_as_float(_slice_evaluation(updated_active_evaluation, local_index).objective_value),
                        gradient_norm=_norm_as_float(_slice_evaluation(updated_active_evaluation, local_index).gradient),
                        step_norm=_metric_item(lm_retry_result.accepted_step_norms, local_index) if lm_retry_result.accepted_mask[local_index] else None,
                        accepted=bool(lm_retry_result.accepted_mask[local_index].detach().cpu().item()),
                        reason=(
                            lm_retry_result.trial_records[local_index][-1].reason
                            if lm_retry_result.trial_records is not None and lm_retry_result.trial_records[local_index]
                            else "Levenberg-Marquardt did not find a decreasing step."
                        ),
                        state=_history_state(updated_active_evaluation.x[local_index], original_shape),
                        linear_residual_norm=_metric_item(
                            lm_retry_result.accepted_linear_residual if lm_retry_result.accepted_mask[local_index] else lm_retry_result.last_linear_residual,
                            local_index,
                        ),
                        linear_condition_estimate=_metric_item(
                            lm_retry_result.accepted_linear_condition if lm_retry_result.accepted_mask[local_index] else lm_retry_result.last_linear_condition,
                            local_index,
                        ),
                        trials=tuple(lm_retry_result.trial_records[local_index]) if lm_retry_result.trial_records is not None else (),
                    )
                )
            if not lm_retry_result.accepted_mask[local_index]:
                objective_tolerance = max(
                    1e-12,
                    config.tol * max(1.0, abs(_objective_as_float(_slice_evaluation(updated_active_evaluation, local_index).objective_value))),
                )
                objective_unchanged = (
                    math.isfinite(float(lm_retry_result.last_objective_deltas[local_index].detach().cpu().item()))
                    and abs(float(lm_retry_result.last_objective_deltas[local_index].detach().cpu().item())) <= objective_tolerance
                )
                tiny_last_step = (
                    math.isfinite(float(lm_retry_result.last_step_norms[local_index].detach().cpu().item()))
                    and float(lm_retry_result.last_step_norms[local_index].detach().cpu().item()) <= config.tol
                )
                if gradient_norms[local_index] <= config.tol:
                    local_params = _candidate_params(params, index=index, batch_size=batch_size, batch_output=batch_output)
                    finalize_convergence_candidate(
                        evaluation=_slice_evaluation(updated_active_evaluation, local_index),
                        index=index,
                        params=local_params,
                        converged_termination=TerminationReason.GRADIENT_TOL,
                    )
                elif tiny_last_step and objective_unchanged:
                    _set_terminal_state(
                        index=index,
                        statuses=statuses,
                        terminations=terminations,
                        messages=messages,
                        succeeded=succeeded,
                        completed=completed,
                        status=SolveStatus.CONVERGED,
                        termination=TerminationReason.STEP_TOL,
                        message="Step norm satisfied the convergence tolerance.",
                        success=True,
                    )
                else:
                    finalize_failure(
                        index=index,
                        message="Levenberg-Marquardt could not find a decreasing step.",
                        diagnoses=diagnoses,
                        diagnosis=DiagnosisCode.STEP_REJECTED,
                    )

        converged_step = lm_retry_result.accepted_mask & (lm_retry_result.accepted_step_norms <= config.tol) & (gradient_norms <= config.tol)
        converged_grad = lm_retry_result.accepted_mask & ~converged_step & (gradient_norms <= config.tol)
        for local_index in torch.nonzero(converged_step | converged_grad, as_tuple=False).flatten().tolist():
            index = active_index_list[local_index]
            local_params = _candidate_params(params, index=index, batch_size=batch_size, batch_output=batch_output)
            finalize_convergence_candidate(
                evaluation=_slice_evaluation(updated_active_evaluation, local_index),
                index=index,
                params=local_params,
                converged_termination=(TerminationReason.STEP_TOL if converged_step[local_index] else TerminationReason.GRADIENT_TOL),
                converged_message=(
                    "Step norm satisfied the convergence tolerance."
                    if converged_step[local_index]
                    else None
                ),
            )

    final_scaling = _current_scaling(evaluation, config, previous_variable_scale=previous_variable_scale)
    results: list[SolveResult] = []
    for index in range(batch_size):
        if statuses[index] is None:
            statuses[index] = SolveStatus.MAX_ITER_REACHED
            terminations[index] = TerminationReason.MAX_ITER
            messages[index] = "Reached the maximum iteration count."

        result = result_builder(
            params=_candidate_params(params, index=index, batch_size=batch_size, batch_output=batch_output),
            x=evaluation.x[index],
            original_shape=original_shape,
            evaluation=_slice_evaluation(evaluation, index),
            history=histories[index],
            num_iter=iteration_counts[index],
            step_norm=final_step_norms[index],
            linear_residual_norm=final_linear_residuals[index],
            linear_condition_estimate=final_linear_conditions[index],
            diagnoses=diagnoses[index],
            method=method,
            requested_device=requested_device,
            message=messages[index],
            status=statuses[index],
            termination=terminations[index],
            success=bool(succeeded[index].detach().cpu().item()),
            linear_solver_name=linear_solver.name,
            scaling=_slice_scaling(final_scaling, index),
        )
        results.append(result)

    return tuple(results)


def solve_least_squares(
    problem: NonlinearLeastSquaresProblem,
    x0: Any,
    params: Any | None,
    config: SolverConfig,
) -> SolveResult | SharedStructureBatchResult:
    """Solve a dense nonlinear least-squares problem through one leading-batch core."""

    requested_device = resolve_requested_device(config.device)
    track_unrolled_gradients = config.diff_mode is DiffMode.UNROLL
    x_batch, original_shape, batch_size, runtime_params, batch_output = _normalize_batched_solve_inputs(
        x0,
        params,
        config,
        requested_device,
        track_unrolled_gradients,
    )
    results = _solve_least_squares_batched_core(
        problem,
        x_batch,
        original_shape,
        runtime_params,
        config,
        requested_device,
        batch_output=batch_output,
    )
    if batch_output:
        return SharedStructureBatchResult(results=results, batch_shape=(batch_size,))
    return results[0]
