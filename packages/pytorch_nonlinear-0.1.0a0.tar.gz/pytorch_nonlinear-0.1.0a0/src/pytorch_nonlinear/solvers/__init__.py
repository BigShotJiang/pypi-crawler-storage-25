"""Least-squares and constrained solver implementations."""

from pytorch_nonlinear.solvers.constrained_nlp import solve_constrained_nlp
from pytorch_nonlinear.solvers.interior_point import solve_interior_point_nlp
from pytorch_nonlinear.solvers.least_squares import DenseLeastSquaresEvaluation, evaluate_dense_least_squares, solve_least_squares

__all__ = [
	"DenseLeastSquaresEvaluation",
	"evaluate_dense_least_squares",
	"solve_constrained_nlp",
	"solve_interior_point_nlp",
	"solve_least_squares",
]
