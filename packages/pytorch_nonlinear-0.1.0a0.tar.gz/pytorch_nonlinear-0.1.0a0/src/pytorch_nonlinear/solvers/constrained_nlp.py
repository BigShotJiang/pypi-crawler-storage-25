"""Dense constrained SQP baseline for equality constraints and bounds."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable, cast

import torch

from pytorch_nonlinear.api.config import BatchMode, DiffMode, ScalingConfig, SolverConfig
from pytorch_nonlinear.constraints import Bounds, EqualityConstraint, InequalityConstraint
from pytorch_nonlinear.diagnostics import DiagnosisCode, IterationRecord, SolveResult, SolveStatus, TerminationReason, TrialRecord
from pytorch_nonlinear.linear import LinearSolveResult, Linearization, build_linear_solver, compute_condition_diagnostics
from pytorch_nonlinear.problem import ConstrainedNLPProblem
from pytorch_nonlinear.scaling.constrained import ConstrainedSQPScaling, apply_constrained_sqp_scaling, build_constrained_sqp_scaling
from pytorch_nonlinear.utils import move_to_device, resolve_requested_device


_SUPPORTED_METHODS = {
    "auto": "sqp",
    "sqp": "sqp",
}

_LINEAR_FALLBACK_RELATIVE_RESIDUAL_TOL = 1e-8
_EQUALITY_DEGENERACY_SINGULAR_VALUE_RATIO = 1e8
_ACTIVE_SET_REPORT_TOL = 1e-8


@dataclass(frozen=True)
class DenseConstrainedEvaluation:
    x: torch.Tensor
    objective_value: torch.Tensor
    objective_gradient: torch.Tensor
    equality_values: torch.Tensor
    equality_jacobian: torch.Tensor
    inequality_values: torch.Tensor
    inequality_jacobian: torch.Tensor
    constraint_violation: torch.Tensor
    active_set: tuple[str, ...]
    inequality_jacobian_mask: torch.Tensor = field(default_factory=lambda: torch.zeros(0, dtype=torch.bool))
    inequality_jacobian_builder: Callable[[torch.Tensor], torch.Tensor] | None = None


@dataclass(frozen=True)
class DenseConstrainedTrialEvaluation:
    x: torch.Tensor
    objective_value: torch.Tensor
    equality_values: torch.Tensor
    inequality_values: torch.Tensor
    constraint_violation: torch.Tensor
    active_set: tuple[str, ...]


@dataclass(frozen=True)
class FlattenedConstraintValues:
    values: torch.Tensor
    sizes: tuple[int, ...]


@dataclass(frozen=True)
class DenseConstrainedMultipliers:
    equality: torch.Tensor
    inequality: torch.Tensor


@dataclass(frozen=True)
class DenseScaledKKTSystem:
    system: torch.Tensor
    rhs: torch.Tensor
    scaling: ConstrainedSQPScaling
    active_inequality_mask: torch.Tensor


def _as_dense_state_tensor(
    x: Any,
    *,
    name: str,
    requested_device: torch.device | None = None,
) -> tuple[torch.Tensor, torch.Size]:
    try:
        tensor = torch.as_tensor(x)
    except (TypeError, ValueError) as exc:
        raise TypeError(f"{name} must be convertible to a dense tensor.") from exc

    if requested_device is not None:
        tensor = tensor.to(device=requested_device)

    original_shape = tensor.shape
    if tensor.ndim == 0:
        tensor = tensor.reshape(1)
    else:
        tensor = tensor.reshape(-1)

    if not torch.is_floating_point(tensor):
        tensor = tensor.to(dtype=torch.float64)
    else:
        tensor = tensor.detach().clone()

    return tensor, original_shape


def _reshape_state(flat_x: torch.Tensor, original_shape: torch.Size) -> torch.Tensor:
    if len(original_shape) == 0:
        return flat_x.reshape(())
    return flat_x.reshape(original_shape)


def _coerce_scalar(value: Any, *, like: torch.Tensor, name: str) -> torch.Tensor:
    tensor = torch.as_tensor(value, dtype=like.dtype, device=like.device)
    if tensor.ndim != 0:
        raise ValueError(f"{name} must return a scalar tensor-like value.")
    return tensor


def _flatten_constraint_value(value: Any, *, like: torch.Tensor) -> torch.Tensor:
    tensor = torch.as_tensor(value, dtype=like.dtype, device=like.device)
    if tensor.ndim == 0:
        return tensor.reshape(1)
    return tensor.reshape(-1)


def _broadcast_bound(bound: Any, *, like: torch.Tensor, original_shape: torch.Size, label: str) -> torch.Tensor | None:
    if bound is None:
        return None

    tensor = torch.as_tensor(bound, dtype=like.dtype, device=like.device)
    state_shape = original_shape if len(original_shape) > 0 else torch.Size((1,))
    try:
        broadcast = torch.broadcast_to(tensor, state_shape)
    except RuntimeError as exc:
        raise ValueError(f"{label} bound must broadcast to state shape {tuple(state_shape)}.") from exc
    return broadcast.reshape(-1)


def _prepare_bounds(bounds: Bounds | None, *, like: torch.Tensor, original_shape: torch.Size) -> tuple[torch.Tensor | None, torch.Tensor | None]:
    if bounds is None:
        return None, None
    lower = _broadcast_bound(bounds.lower, like=like, original_shape=original_shape, label="Lower")
    upper = _broadcast_bound(bounds.upper, like=like, original_shape=original_shape, label="Upper")
    if lower is not None and upper is not None and torch.any(lower > upper):
        raise ValueError("Lower bounds must be less than or equal to upper bounds.")
    return lower, upper


def _project_bounds(x: torch.Tensor, lower: torch.Tensor | None, upper: torch.Tensor | None) -> torch.Tensor:
    projected = x
    if lower is not None:
        projected = torch.maximum(projected, lower)
    if upper is not None:
        projected = torch.minimum(projected, upper)
    return projected


def _bound_labels(bounds: Bounds | None, lower: torch.Tensor | None, upper: torch.Tensor | None, x: torch.Tensor, tolerance: float) -> tuple[str, ...]:
    if bounds is None:
        return ()

    labels: list[str] = []
    prefix = bounds.name or "bounds"
    if lower is not None:
        lower_mask = x <= lower + tolerance
        labels.extend(f"{prefix}.lower[{index}]" for index in torch.nonzero(lower_mask, as_tuple=False).flatten().tolist())
    if upper is not None:
        upper_mask = x >= upper - tolerance
        labels.extend(f"{prefix}.upper[{index}]" for index in torch.nonzero(upper_mask, as_tuple=False).flatten().tolist())
    return tuple(labels)


def _split_constraints(problem: ConstrainedNLPProblem) -> tuple[tuple[EqualityConstraint, ...], tuple[InequalityConstraint, ...]]:
    equality_constraints: list[EqualityConstraint] = []
    inequality_constraints: list[InequalityConstraint] = []
    for constraint in problem.constraints:
        if isinstance(constraint, EqualityConstraint):
            equality_constraints.append(constraint)
        elif isinstance(constraint, InequalityConstraint):
            inequality_constraints.append(constraint)
    return tuple(equality_constraints), tuple(inequality_constraints)


def _constraint_vector(
    constraints: tuple[EqualityConstraint | InequalityConstraint, ...],
    state: torch.Tensor,
    params: Any | None,
    *,
    like: torch.Tensor,
) -> torch.Tensor:
    return _constraint_vector_with_sizes(constraints, state, params, like=like).values


def _constraint_vector_with_sizes(
    constraints: tuple[EqualityConstraint | InequalityConstraint, ...],
    state: torch.Tensor,
    params: Any | None,
    *,
    like: torch.Tensor,
) -> FlattenedConstraintValues:
    if not constraints:
        return FlattenedConstraintValues(values=like.new_zeros(0), sizes=())

    flattened_values = tuple(_flatten_constraint_value(constraint.evaluate(state, params), like=like) for constraint in constraints)
    return FlattenedConstraintValues(
        values=torch.cat(flattened_values),
        sizes=tuple(value.numel() for value in flattened_values),
    )


def _constraint_violation(
    equality_values: torch.Tensor,
    inequality_values: torch.Tensor,
    x: torch.Tensor,
    lower: torch.Tensor | None,
    upper: torch.Tensor | None,
) -> torch.Tensor:
    components: list[torch.Tensor] = []
    if equality_values.numel() > 0:
        components.append(torch.max(torch.abs(equality_values)))
    if inequality_values.numel() > 0:
        components.append(torch.max(torch.clamp(inequality_values, min=0.0)))
    if lower is not None:
        components.append(torch.max(torch.clamp(lower - x, min=0.0)))
    if upper is not None:
        components.append(torch.max(torch.clamp(x - upper, min=0.0)))
    if not components:
        return x.new_tensor(0.0)
    return torch.stack(components).max()


def _constraint_label_prefix(
    constraint: EqualityConstraint | InequalityConstraint,
    *,
    index: int,
    default_prefix: str,
) -> str:
    metadata_name = constraint.metadata.name
    if metadata_name is not None and metadata_name != "":
        return metadata_name
    return f"{default_prefix}[{index}]"


def _active_inequality_labels(
    constraints: tuple[InequalityConstraint, ...],
    inequality_values: torch.Tensor,
    *,
    sizes: tuple[int, ...],
    tolerance: float,
) -> tuple[str, ...]:
    labels: list[str] = []
    offset = 0
    for constraint_index, (constraint, size) in enumerate(zip(constraints, sizes, strict=True)):
        values = inequality_values[offset : offset + size]
        offset += size
        active_indices = torch.nonzero(values >= -tolerance, as_tuple=False).flatten().tolist()
        prefix = _constraint_label_prefix(constraint, index=constraint_index, default_prefix="ineq")
        if values.numel() == 1:
            if active_indices:
                labels.append(prefix)
            continue
        labels.extend(f"{prefix}[{value_index}]" for value_index in active_indices)
    return tuple(labels)


def _active_inequality_mask(
    inequality_values: torch.Tensor,
    *,
    multipliers: torch.Tensor | None = None,
    tolerance: float,
) -> torch.Tensor:
    if inequality_values.numel() == 0:
        return torch.zeros_like(inequality_values, dtype=torch.bool)

    active = inequality_values >= -tolerance
    if multipliers is not None and multipliers.numel() == inequality_values.numel():
        active = torch.logical_or(active, multipliers > tolerance)
    return active


def _linearized_constraint_system(
    evaluation: DenseConstrainedEvaluation,
    *,
    inequality_multipliers: torch.Tensor | None,
    tolerance: float,
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    active_inequality_mask = _active_inequality_mask(
        evaluation.inequality_values,
        multipliers=inequality_multipliers,
        tolerance=tolerance,
    )
    if not torch.any(active_inequality_mask):
        return evaluation.equality_jacobian, evaluation.equality_values, active_inequality_mask

    active_inequality_jacobian = _selected_inequality_jacobian(evaluation, active_inequality_mask)
    active_inequality_values = evaluation.inequality_values[active_inequality_mask]
    if evaluation.equality_jacobian.shape[0] == 0:
        return active_inequality_jacobian, active_inequality_values, active_inequality_mask

    return (
        torch.cat((evaluation.equality_jacobian, active_inequality_jacobian), dim=0),
        torch.cat((evaluation.equality_values, active_inequality_values), dim=0),
        active_inequality_mask,
    )


def _expand_constraint_multipliers(
    raw_multipliers: torch.Tensor,
    *,
    equality_count: int,
    active_inequality_mask: torch.Tensor,
    total_inequality_count: int,
) -> DenseConstrainedMultipliers:
    equality_multipliers = raw_multipliers[:equality_count] if equality_count > 0 else raw_multipliers.new_zeros(0)
    inequality_multipliers = raw_multipliers.new_zeros(total_inequality_count)
    inequality_slice = raw_multipliers[equality_count:]
    inequality_multipliers[active_inequality_mask] = torch.clamp(inequality_slice, min=0.0)
    return DenseConstrainedMultipliers(
        equality=equality_multipliers,
        inequality=inequality_multipliers,
    )


def _lagrangian_stationarity(
    evaluation: DenseConstrainedEvaluation,
    multipliers: DenseConstrainedMultipliers,
) -> torch.Tensor:
    stationarity = evaluation.objective_gradient
    if evaluation.equality_jacobian.shape[0] > 0:
        stationarity = stationarity + evaluation.equality_jacobian.T @ multipliers.equality
    active_multiplier_mask = multipliers.inequality > 0
    stationarity = stationarity + _selected_inequality_jacobian(evaluation, active_multiplier_mask).T @ multipliers.inequality[active_multiplier_mask]
    return stationarity


def _selected_inequality_jacobian(
    evaluation: DenseConstrainedEvaluation,
    active_mask: torch.Tensor,
) -> torch.Tensor:
    if active_mask.numel() != evaluation.inequality_values.numel():
        raise ValueError("Active inequality mask must match the number of inequality rows.")

    active_count = int(torch.count_nonzero(active_mask).detach().cpu().item())
    if active_count == 0:
        return evaluation.objective_gradient.new_zeros((0, evaluation.objective_gradient.numel()))

    cached_mask = evaluation.inequality_jacobian_mask
    if cached_mask.numel() == active_mask.numel():
        if torch.equal(cached_mask, active_mask):
            return evaluation.inequality_jacobian

        requested_is_subset = bool(torch.all(torch.logical_or(torch.logical_not(active_mask), cached_mask)).detach().cpu().item())
        if requested_is_subset:
            cached_positions = torch.cumsum(cached_mask.to(dtype=torch.int64), dim=0) - 1
            return evaluation.inequality_jacobian[cached_positions[active_mask]]

    if evaluation.inequality_jacobian_builder is None:
        raise RuntimeError("Missing inequality Jacobian builder for the requested working set.")
    return evaluation.inequality_jacobian_builder(active_mask)


def evaluate_dense_constrained_problem(
    problem: ConstrainedNLPProblem,
    x: torch.Tensor,
    params: Any | None,
    *,
    original_shape: torch.Size,
    equality_constraints: tuple[EqualityConstraint, ...],
    inequality_constraints: tuple[InequalityConstraint, ...],
    bounds: Bounds | None,
    lower: torch.Tensor | None,
    upper: torch.Tensor | None,
    previous_inequality_multipliers: torch.Tensor | None = None,
    tolerance: float = 1e-6,
    materialize_active_inequalities_only: bool = True,
) -> DenseConstrainedEvaluation:
    x_var = x.detach().clone().requires_grad_(True)
    state = _reshape_state(x_var, original_shape)
    objective_value = _coerce_scalar(problem.objective(state, params), like=x_var, name="objective")
    objective_gradient = torch.autograd.grad(objective_value, x_var)[0].detach()

    def equality_fn(flat_x: torch.Tensor) -> torch.Tensor:
        return _constraint_vector(equality_constraints, _reshape_state(flat_x, original_shape), params, like=flat_x)

    def inequality_fn(flat_x: torch.Tensor) -> torch.Tensor:
        return _constraint_vector(inequality_constraints, _reshape_state(flat_x, original_shape), params, like=flat_x)

    equality_values = equality_fn(x_var).detach()
    if equality_values.numel() > 0:
        equality_jacobian = torch.autograd.functional.jacobian(equality_fn, x.detach(), vectorize=True).detach()
        equality_jacobian = equality_jacobian.reshape(equality_values.numel(), x.numel())
    else:
        equality_jacobian = x.new_zeros((0, x.numel()))

    flattened_inequality_values = _constraint_vector_with_sizes(inequality_constraints, state, params, like=x_var)
    inequality_values = flattened_inequality_values.values.detach()

    def build_selected_inequality_jacobian(active_mask: torch.Tensor) -> torch.Tensor:
        if active_mask.numel() != inequality_values.numel():
            raise ValueError("Active inequality mask must match the number of inequality rows.")
        active_count = int(torch.count_nonzero(active_mask).detach().cpu().item())
        if active_count == 0:
            return x.new_zeros((0, x.numel()))

        def selected_inequality_fn(flat_x: torch.Tensor) -> torch.Tensor:
            return inequality_fn(flat_x)[active_mask]

        selected_jacobian = torch.autograd.functional.jacobian(selected_inequality_fn, x.detach(), vectorize=True).detach()
        return selected_jacobian.reshape(active_count, x.numel())

    active_inequality_mask = _active_inequality_mask(
        inequality_values,
        multipliers=previous_inequality_multipliers,
        tolerance=tolerance,
    )
    if materialize_active_inequalities_only:
        inequality_jacobian_mask = active_inequality_mask
    else:
        inequality_jacobian_mask = torch.ones_like(inequality_values, dtype=torch.bool)

    if bool(torch.count_nonzero(inequality_jacobian_mask).detach().cpu().item() > 0):
        inequality_jacobian = build_selected_inequality_jacobian(inequality_jacobian_mask)
    else:
        inequality_jacobian = x.new_zeros((0, x.numel()))

    state = _reshape_state(x.detach(), original_shape)
    constraint_violation = _constraint_violation(equality_values, inequality_values, x.detach(), lower, upper)
    active_set = (
        *_bound_labels(bounds, lower, upper, x.detach(), tolerance=_ACTIVE_SET_REPORT_TOL),
        *_active_inequality_labels(
            inequality_constraints,
            inequality_values,
            sizes=flattened_inequality_values.sizes,
            tolerance=_ACTIVE_SET_REPORT_TOL,
        ),
    )
    return DenseConstrainedEvaluation(
        x=x.detach(),
        objective_value=objective_value.detach(),
        objective_gradient=objective_gradient,
        equality_values=equality_values,
        equality_jacobian=equality_jacobian,
        inequality_values=inequality_values,
        inequality_jacobian=inequality_jacobian,
        inequality_jacobian_mask=inequality_jacobian_mask,
        inequality_jacobian_builder=build_selected_inequality_jacobian if inequality_values.numel() > 0 else None,
        constraint_violation=constraint_violation.detach(),
        active_set=active_set,
    )


def evaluate_dense_constrained_trial_problem(
    problem: ConstrainedNLPProblem,
    x: torch.Tensor,
    params: Any | None,
    *,
    original_shape: torch.Size,
    equality_constraints: tuple[EqualityConstraint, ...],
    inequality_constraints: tuple[InequalityConstraint, ...],
    bounds: Bounds | None,
    lower: torch.Tensor | None,
    upper: torch.Tensor | None,
) -> DenseConstrainedTrialEvaluation:
    state = _reshape_state(x, original_shape)
    objective_value = _coerce_scalar(problem.objective(state, params), like=x, name="objective")
    equality_values = _constraint_vector(equality_constraints, state, params, like=x)
    flattened_inequality_values = _constraint_vector_with_sizes(inequality_constraints, state, params, like=x)
    inequality_values = flattened_inequality_values.values
    constraint_violation = _constraint_violation(equality_values, inequality_values, x, lower, upper)
    active_set = (
        *_bound_labels(bounds, lower, upper, x, tolerance=_ACTIVE_SET_REPORT_TOL),
        *_active_inequality_labels(
            inequality_constraints,
            inequality_values,
            sizes=flattened_inequality_values.sizes,
            tolerance=_ACTIVE_SET_REPORT_TOL,
        ),
    )
    return DenseConstrainedTrialEvaluation(
        x=x.detach(),
        objective_value=objective_value.detach(),
        equality_values=equality_values.detach(),
        inequality_values=inequality_values.detach(),
        constraint_violation=constraint_violation.detach(),
        active_set=active_set,
    )


def _estimate_multipliers(jacobian: torch.Tensor, gradient: torch.Tensor) -> torch.Tensor:
    if jacobian.shape[0] == 0:
        return gradient.new_zeros(0)

    gram = _symmetrize(jacobian @ jacobian.T)
    rhs = -(jacobian @ gradient)
    try:
        return torch.linalg.solve(gram, rhs).detach()
    except RuntimeError:
        return (torch.pinverse(jacobian.T) @ (-gradient)).detach()


def _append_diagnosis(diagnoses: list[DiagnosisCode], code: DiagnosisCode) -> None:
    if code not in diagnoses:
        diagnoses.append(code)


def _equality_model_diagnoses(jacobian: torch.Tensor) -> tuple[DiagnosisCode, ...]:
    if jacobian.shape[0] == 0:
        return ()

    try:
        gram = _symmetrize(jacobian @ jacobian.T)
        eigenvalues = torch.linalg.eigvalsh(gram)
    except RuntimeError:
        return (DiagnosisCode.RANK_DEFICIENT_JACOBIAN, DiagnosisCode.ILL_CONDITIONED_SYSTEM)

    if eigenvalues.numel() == 0:
        return ()

    singular_values_cpu = torch.sqrt(torch.clamp(eigenvalues.detach().cpu(), min=0.0))
    max_singular_value = float(torch.max(singular_values_cpu).item())
    min_singular_value = float(torch.min(singular_values_cpu).item())
    cutoff = max(1e-12, 1e-10 * max(max_singular_value, 1.0))
    effective_rank = int(torch.count_nonzero(singular_values_cpu > cutoff).item())

    diagnoses: list[DiagnosisCode] = []
    if effective_rank < jacobian.shape[0]:
        diagnoses.append(DiagnosisCode.RANK_DEFICIENT_JACOBIAN)

    if max_singular_value == 0.0 or min_singular_value <= 0.0:
        diagnoses.append(DiagnosisCode.ILL_CONDITIONED_SYSTEM)
    else:
        condition_ratio = max_singular_value / min_singular_value
        if condition_ratio > _EQUALITY_DEGENERACY_SINGULAR_VALUE_RATIO:
            diagnoses.append(DiagnosisCode.ILL_CONDITIONED_SYSTEM)

    return tuple(dict.fromkeys(diagnoses))


def _position_active_mask(
    x: torch.Tensor,
    *,
    lower: torch.Tensor | None,
    upper: torch.Tensor | None,
    tolerance: float,
) -> torch.Tensor:
    active = torch.zeros_like(x, dtype=torch.bool)
    if lower is not None:
        active = torch.logical_or(active, x <= lower + tolerance)
    if upper is not None:
        active = torch.logical_or(active, x >= upper - tolerance)
    return active


def _estimate_constraint_multipliers(
    evaluation: DenseConstrainedEvaluation,
    *,
    lower: torch.Tensor | None,
    upper: torch.Tensor | None,
    previous_inequality_multipliers: torch.Tensor | None,
    tolerance: float,
) -> DenseConstrainedMultipliers:
    active_jacobian, _, active_inequality_mask = _linearized_constraint_system(
        evaluation,
        inequality_multipliers=previous_inequality_multipliers,
        tolerance=tolerance,
    )
    if active_jacobian.shape[0] == 0:
        return DenseConstrainedMultipliers(
            equality=evaluation.objective_gradient.new_zeros(0),
            inequality=evaluation.objective_gradient.new_zeros(evaluation.inequality_values.numel()),
        )

    active_mask = _position_active_mask(evaluation.x, lower=lower, upper=upper, tolerance=tolerance)
    free_mask = ~active_mask
    if torch.any(free_mask):
        reduced_jacobian = active_jacobian[:, free_mask]
        reduced_gradient = evaluation.objective_gradient[free_mask]
        if reduced_jacobian.numel() > 0:
            return _expand_constraint_multipliers(
                _estimate_multipliers(reduced_jacobian, reduced_gradient),
                equality_count=evaluation.equality_jacobian.shape[0],
                active_inequality_mask=active_inequality_mask,
                total_inequality_count=evaluation.inequality_values.numel(),
            )

    return _expand_constraint_multipliers(
        _estimate_multipliers(active_jacobian, evaluation.objective_gradient),
        equality_count=evaluation.equality_jacobian.shape[0],
        active_inequality_mask=active_inequality_mask,
        total_inequality_count=evaluation.inequality_values.numel(),
    )


def _recover_bound_multipliers(
    x: torch.Tensor,
    stationarity: torch.Tensor,
    *,
    lower: torch.Tensor | None,
    upper: torch.Tensor | None,
    tolerance: float,
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    lower_multipliers = torch.zeros_like(stationarity)
    upper_multipliers = torch.zeros_like(stationarity)
    dual_feasibility_residual = torch.zeros_like(stationarity)

    at_lower = x <= lower + tolerance if lower is not None else torch.zeros_like(x, dtype=torch.bool)
    at_upper = x >= upper - tolerance if upper is not None else torch.zeros_like(x, dtype=torch.bool)

    fixed = torch.logical_and(at_lower, at_upper)
    lower_only = torch.logical_and(at_lower, torch.logical_not(at_upper))
    upper_only = torch.logical_and(at_upper, torch.logical_not(at_lower))

    if torch.any(lower_only):
        lower_stationarity = stationarity[lower_only]
        lower_multipliers[lower_only] = torch.clamp(lower_stationarity, min=0.0)
        dual_feasibility_residual[lower_only] = torch.clamp(-lower_stationarity, min=0.0)

    if torch.any(upper_only):
        upper_stationarity = stationarity[upper_only]
        upper_multipliers[upper_only] = torch.clamp(-upper_stationarity, min=0.0)
        dual_feasibility_residual[upper_only] = torch.clamp(upper_stationarity, min=0.0)

    if torch.any(fixed):
        fixed_stationarity = stationarity[fixed]
        lower_multipliers[fixed] = torch.clamp(fixed_stationarity, min=0.0)
        upper_multipliers[fixed] = torch.clamp(-fixed_stationarity, min=0.0)

    return lower_multipliers, upper_multipliers, dual_feasibility_residual


def _kkt_residual(
    evaluation: DenseConstrainedEvaluation,
    multipliers: DenseConstrainedMultipliers,
    *,
    lower: torch.Tensor | None,
    upper: torch.Tensor | None,
    tolerance: float,
) -> torch.Tensor:
    stationarity = _lagrangian_stationarity(evaluation, multipliers)

    lower_multipliers, upper_multipliers, dual_feasibility_residual = _recover_bound_multipliers(
        evaluation.x,
        stationarity,
        lower=lower,
        upper=upper,
        tolerance=tolerance,
    )
    bound_stationarity = stationarity - lower_multipliers + upper_multipliers

    components = [evaluation.constraint_violation]
    if bound_stationarity.numel() > 0:
        components.append(torch.max(torch.abs(bound_stationarity)))
    if dual_feasibility_residual.numel() > 0:
        components.append(torch.max(dual_feasibility_residual))
    if multipliers.inequality.numel() > 0:
        components.append(torch.max(torch.clamp(-multipliers.inequality, min=0.0)))
        components.append(torch.max(torch.abs(multipliers.inequality * evaluation.inequality_values)))
    if lower is not None and lower_multipliers.numel() > 0:
        lower_complementarity = torch.abs(lower_multipliers * (evaluation.x - lower))
        components.append(torch.max(lower_complementarity))
    if upper is not None and upper_multipliers.numel() > 0:
        upper_complementarity = torch.abs(upper_multipliers * (upper - evaluation.x))
        components.append(torch.max(upper_complementarity))
    return torch.stack(components).max()


def _merit_value(
    objective_value: torch.Tensor,
    equality_values: torch.Tensor,
    inequality_values: torch.Tensor,
    penalty: float,
) -> torch.Tensor:
    if equality_values.numel() == 0 and inequality_values.numel() == 0:
        return objective_value
    return objective_value + penalty * (
        torch.sum(torch.abs(equality_values)) + torch.sum(torch.clamp(inequality_values, min=0.0))
    )


def _symmetrize(matrix: torch.Tensor) -> torch.Tensor:
    return 0.5 * (matrix + matrix.T)


def _regularized_symmetric_copy(matrix: torch.Tensor, *, diagonal_shift: float = 1e-8) -> torch.Tensor:
    """Return a symmetric copy with a small diagonal regularization.

    Parameters
    ----------
    matrix : torch.Tensor
        Square matrix representing the current Hessian approximation.
    diagonal_shift : float, optional
        Positive diagonal shift used to keep the primal block numerically
        regularized when assembling the KKT system.

    Returns
    -------
    torch.Tensor
        Symmetric copy of ``matrix`` with ``diagonal_shift`` added to the
        diagonal entries.
    """

    regularized = _symmetrize(matrix).clone()
    regularized.diagonal().add_(diagonal_shift)
    return regularized


def _assemble_kkt_system(
    regularized_hessian: torch.Tensor,
    objective_gradient: torch.Tensor,
    equality_jacobian: torch.Tensor,
    equality_values: torch.Tensor,
) -> tuple[torch.Tensor, torch.Tensor]:
    """Assemble the dense SQP KKT system for equality-constrained steps.

    Parameters
    ----------
    regularized_hessian : torch.Tensor
        Regularized primal Hessian block.
    objective_gradient : torch.Tensor
        Objective gradient at the current iterate.
    equality_jacobian : torch.Tensor
        Jacobian of the equality constraints.
    equality_values : torch.Tensor
        Equality constraint residual vector.

    Returns
    -------
    tuple[torch.Tensor, torch.Tensor]
        The saddle-point KKT matrix and right-hand side corresponding to the
        SQP step system.

    Notes
    -----
    This helper preserves the same linear system that the previous blockwise
    ``torch.cat`` construction formed; it only changes the in-memory assembly
    strategy.
    """

    if equality_jacobian.shape[0] == 0:
        return regularized_hessian, -objective_gradient

    primal_dim = regularized_hessian.shape[0]
    equality_dim = equality_jacobian.shape[0]
    total_dim = primal_dim + equality_dim
    system = regularized_hessian.new_zeros((total_dim, total_dim))
    system[:primal_dim, :primal_dim] = regularized_hessian
    system[:primal_dim, primal_dim:] = equality_jacobian.T
    system[primal_dim:, :primal_dim] = equality_jacobian

    rhs = objective_gradient.new_empty(total_dim)
    rhs[:primal_dim] = -objective_gradient
    rhs[primal_dim:] = -equality_values
    return system, rhs


def _build_scaled_kkt_system(
    regularized_hessian: torch.Tensor,
    objective_gradient: torch.Tensor,
    constraint_jacobian: torch.Tensor,
    constraint_values: torch.Tensor,
    *,
    scaling_config: ScalingConfig,
    previous_variable_scale: torch.Tensor | None,
    active_inequality_mask: torch.Tensor,
) -> DenseScaledKKTSystem:
    scaling = build_constrained_sqp_scaling(
        regularized_hessian,
        objective_gradient,
        constraint_jacobian,
        constraint_values,
        scaling_config,
        previous_variable_scale=previous_variable_scale,
    )
    scaled_hessian, scaled_gradient, scaled_jacobian, scaled_values = apply_constrained_sqp_scaling(
        regularized_hessian,
        objective_gradient,
        constraint_jacobian,
        constraint_values,
        scaling,
    )
    system, rhs = _assemble_kkt_system(scaled_hessian, scaled_gradient, scaled_jacobian, scaled_values)
    return DenseScaledKKTSystem(
        system=system,
        rhs=rhs,
        scaling=scaling,
        active_inequality_mask=active_inequality_mask,
    )


def _exact_lagrangian_hessian(
    problem: ConstrainedNLPProblem,
    x: torch.Tensor,
    params: Any | None,
    *,
    original_shape: torch.Size,
    equality_constraints: tuple[EqualityConstraint, ...],
    inequality_constraints: tuple[InequalityConstraint, ...],
    multipliers: DenseConstrainedMultipliers,
) -> torch.Tensor:
    active_inequality_mask = multipliers.inequality > 0
    has_active_inequalities = bool(torch.count_nonzero(active_inequality_mask).detach().cpu().item() > 0)
    active_inequality_multipliers = multipliers.inequality[active_inequality_mask] if has_active_inequalities else multipliers.inequality.new_zeros(0)

    def lagrangian(flat_x: torch.Tensor) -> torch.Tensor:
        state = _reshape_state(flat_x, original_shape)
        value = _coerce_scalar(problem.objective(state, params), like=flat_x, name="objective")
        if equality_constraints:
            equality_values = _constraint_vector(equality_constraints, state, params, like=flat_x)
            value = value + torch.dot(multipliers.equality.to(dtype=flat_x.dtype, device=flat_x.device), equality_values)
        if inequality_constraints and has_active_inequalities:
            inequality_values = _constraint_vector(inequality_constraints, state, params, like=flat_x)[active_inequality_mask]
            value = value + torch.dot(
                active_inequality_multipliers.to(dtype=flat_x.dtype, device=flat_x.device),
                inequality_values,
            )
        return value

    return _symmetrize(torch.func.hessian(lagrangian)(x.detach()).detach())


def _bfgs_update(hessian: torch.Tensor, step: torch.Tensor, gradient_delta: torch.Tensor) -> torch.Tensor:
    curvature = torch.dot(step, gradient_delta)
    step_norm = torch.norm(step)
    delta_norm = torch.norm(gradient_delta)
    if float(curvature.detach().cpu().item()) <= 1e-12 * max(float(step_norm.detach().cpu().item() * delta_norm.detach().cpu().item()), 1.0):
        return hessian

    projected_step = hessian @ step
    step_curvature = torch.dot(step, projected_step)
    if float(step_curvature.detach().cpu().item()) <= 0.0:
        return hessian

    updated = hessian - torch.outer(projected_step, projected_step) / step_curvature + torch.outer(gradient_delta, gradient_delta) / curvature
    return _symmetrize(updated)


def _kkt_system(
    hessian: torch.Tensor,
    evaluation: DenseConstrainedEvaluation,
    *,
    inequality_multipliers: torch.Tensor,
    tolerance: float,
    scaling_config: ScalingConfig,
    previous_variable_scale: torch.Tensor | None,
) -> DenseScaledKKTSystem:
    """Build the full KKT system for the current SQP subproblem.

    Parameters
    ----------
    hessian : torch.Tensor
        Current Hessian or Hessian approximation of the Lagrangian.
    evaluation : DenseConstrainedEvaluation
        Current iterate evaluation containing the gradient, equality Jacobian,
        and equality residuals.

    Returns
    -------
    tuple[torch.Tensor, torch.Tensor]
        Full dense KKT matrix and right-hand side for the unrestricted SQP
        step.
    """

    regularized_hessian = _regularized_symmetric_copy(hessian)
    linearized_jacobian, linearized_values, active_inequality_mask = _linearized_constraint_system(
        evaluation,
        inequality_multipliers=inequality_multipliers,
        tolerance=tolerance,
    )
    return _build_scaled_kkt_system(
        regularized_hessian,
        evaluation.objective_gradient,
        linearized_jacobian,
        linearized_values,
        scaling_config=scaling_config,
        previous_variable_scale=previous_variable_scale,
        active_inequality_mask=active_inequality_mask,
    )


def _active_bound_mask(
    x: torch.Tensor,
    step: torch.Tensor,
    *,
    lower: torch.Tensor | None,
    upper: torch.Tensor | None,
    tolerance: float,
) -> torch.Tensor:
    active = torch.zeros_like(step, dtype=torch.bool)
    if lower is not None:
        active = torch.logical_or(active, torch.logical_and(x <= lower + tolerance, step < 0.0))
    if upper is not None:
        active = torch.logical_or(active, torch.logical_and(x >= upper - tolerance, step > 0.0))
    return active


def _reduced_kkt_system(
    hessian: torch.Tensor,
    evaluation: DenseConstrainedEvaluation,
    *,
    active_mask: torch.Tensor,
    inequality_multipliers: torch.Tensor,
    tolerance: float,
    scaling_config: ScalingConfig,
    previous_variable_scale: torch.Tensor | None,
) -> tuple[DenseScaledKKTSystem | None, torch.Tensor, torch.Tensor]:
    """Build the KKT system restricted to variables not fixed by active bounds.

    Parameters
    ----------
    hessian : torch.Tensor
        Current Hessian or Hessian approximation of the Lagrangian.
    evaluation : DenseConstrainedEvaluation
        Current iterate evaluation.
    active_mask : torch.Tensor
        Boolean mask marking variables treated as fixed at their active bounds.

    Returns
    -------
    tuple[torch.Tensor | None, torch.Tensor | None, torch.Tensor]
        Reduced KKT matrix, reduced right-hand side, and the free-variable mask.
        If all variables are fixed, the matrix and right-hand side are ``None``.

    Notes
    -----
    This is the standard active-set reduction of the primal variables. Equality
    constraints remain explicit; only the bound-fixed coordinates are removed.
    """

    free_mask = ~active_mask
    if torch.all(active_mask):
        return None, free_mask, evaluation.inequality_values.new_zeros(evaluation.inequality_values.shape, dtype=torch.bool)

    reduced_hessian = hessian[free_mask][:, free_mask]
    reduced_gradient = evaluation.objective_gradient[free_mask]
    regularized_reduced_hessian = _regularized_symmetric_copy(reduced_hessian)
    linearized_jacobian, linearized_values, active_inequality_mask = _linearized_constraint_system(
        evaluation,
        inequality_multipliers=inequality_multipliers,
        tolerance=tolerance,
    )
    if linearized_jacobian.shape[0] == 0:
        scaled_system = _build_scaled_kkt_system(
            regularized_reduced_hessian,
            reduced_gradient,
            linearized_jacobian,
            linearized_values,
            scaling_config=scaling_config,
            previous_variable_scale=previous_variable_scale[free_mask] if previous_variable_scale is not None else None,
            active_inequality_mask=active_inequality_mask,
        )
        return scaled_system, free_mask, active_inequality_mask

    reduced_jacobian = linearized_jacobian[:, free_mask]
    scaled_system = _build_scaled_kkt_system(
        regularized_reduced_hessian,
        reduced_gradient,
        reduced_jacobian,
        linearized_values,
        scaling_config=scaling_config,
        previous_variable_scale=previous_variable_scale[free_mask] if previous_variable_scale is not None else None,
        active_inequality_mask=active_inequality_mask,
    )
    return scaled_system, free_mask, active_inequality_mask


def _unscale_kkt_step(step: torch.Tensor, scaling: ConstrainedSQPScaling) -> torch.Tensor:
    primal_dim = scaling.variable_scale.numel()
    unscaled = step.clone()
    if primal_dim > 0:
        unscaled[:primal_dim] = unscaled[:primal_dim] * scaling.variable_scale
    if step.numel() > primal_dim and scaling.constraint_scale.numel() > 0:
        unscaled[primal_dim:] = unscaled[primal_dim:] * scaling.constraint_scale
    return unscaled


def _full_variable_scale(
    full_dim: int,
    *,
    scaling: ConstrainedSQPScaling,
    free_mask: torch.Tensor | None,
    previous_variable_scale: torch.Tensor | None,
    like: torch.Tensor,
) -> torch.Tensor:
    if free_mask is None:
        return scaling.variable_scale.detach().clone()

    if previous_variable_scale is not None and previous_variable_scale.shape == (full_dim,):
        merged = previous_variable_scale.detach().clone()
    else:
        merged = torch.ones(full_dim, dtype=like.dtype, device=like.device)
    merged[free_mask] = scaling.variable_scale
    return merged


def _attempt_position_active_reduced_solve(
    *,
    linear_solver: Any,
    hessian: torch.Tensor,
    evaluation: DenseConstrainedEvaluation,
    multipliers: DenseConstrainedMultipliers,
    lower: torch.Tensor | None,
    upper: torch.Tensor | None,
    tolerance: float,
    compute_condition_estimate: bool,
    scaling_config: ScalingConfig,
    previous_variable_scale: torch.Tensor | None,
) -> tuple[
    LinearSolveResult | None,
    torch.Tensor | None,
    torch.Tensor | None,
    ConstrainedSQPScaling | None,
    torch.Tensor | None,
    torch.Tensor | None,
]:
    """Try a reduced SQP solve using the bounds active at the current iterate.

    Parameters
    ----------
    linear_solver : Any
        Configured dense linear solver backend.
    hessian : torch.Tensor
        Current Hessian or Hessian approximation of the Lagrangian.
    evaluation : DenseConstrainedEvaluation
        Current iterate evaluation.
    lower, upper : torch.Tensor | None
        Bound vectors for the current problem.
    tolerance : float
        Bound-activity tolerance.
    compute_condition_estimate : bool
        Whether the linear backend should compute condition estimates.

    Returns
    -------
    tuple[LinearSolveResult | None, torch.Tensor | None]
        Reduced solve result and the free-variable mask. Returns ``(None, None)``
        when no current-position active set is available or all variables would
        be fixed.
    """

    active_mask = _position_active_mask(evaluation.x, lower=lower, upper=upper, tolerance=tolerance)
    if not torch.any(active_mask):
        return None, None, None, None, None, None

    reduced_system, free_mask, active_inequality_mask = _reduced_kkt_system(
        hessian,
        evaluation,
        active_mask=active_mask,
        inequality_multipliers=multipliers.inequality,
        tolerance=tolerance,
        scaling_config=scaling_config,
        previous_variable_scale=previous_variable_scale,
    )
    if reduced_system is None:
        return None, None, None, None, None, None

    reduced_linear_result = linear_solver.solve(
        Linearization(
            matrix=reduced_system.system,
            rhs=reduced_system.rhs,
            symmetric=True,
            positive_semidefinite=False,
            compute_condition_estimate=False,
        )
    )
    if bool(reduced_linear_result.success) and reduced_linear_result.step is not None:
        reduced_linear_result = _certify_selected_linear_result(
            reduced_linear_result,
            system=reduced_system.system,
            rhs=reduced_system.rhs,
            compute_condition_estimate=compute_condition_estimate,
        )
    if bool(reduced_linear_result.success) and reduced_linear_result.step is not None:
        unscaled_step = _unscale_kkt_step(reduced_linear_result.step, reduced_system.scaling)
        reduced_linear_result = LinearSolveResult(
            success=reduced_linear_result.success,
            step=unscaled_step,
            diagnosis=reduced_linear_result.diagnosis,
            diagnosis_by_batch=reduced_linear_result.diagnosis_by_batch,
            condition_estimate=reduced_linear_result.condition_estimate,
            residual_norm=reduced_linear_result.residual_norm,
            iterations=reduced_linear_result.iterations,
            solver_name=reduced_linear_result.solver_name,
            message=reduced_linear_result.message,
        )
    return reduced_linear_result, free_mask, active_inequality_mask, reduced_system.scaling, reduced_system.system, reduced_system.rhs


def _should_try_position_active_reduced_solve(
    evaluation: DenseConstrainedEvaluation,
    multipliers: DenseConstrainedMultipliers,
    *,
    lower: torch.Tensor | None,
    upper: torch.Tensor | None,
    tolerance: float,
) -> bool:
    """Decide whether a reduced-first active-set solve is locally safe.

    Parameters
    ----------
    evaluation : DenseConstrainedEvaluation
        Current iterate evaluation.
    multipliers : torch.Tensor
        Current equality-multiplier estimate.
    lower, upper : torch.Tensor | None
        Bound vectors for the current problem.
    tolerance : float
        Dual-feasibility tolerance used for the active-bound gate.

    Returns
    -------
    bool
        ``True`` when the bounds active at the current iterate are already
        dual-feasible under the current stationarity model, making a reduced-
        first active-set solve a safe shortcut. ``False`` keeps the original
        full-KKT path as the correctness baseline.
    """

    active_mask = _position_active_mask(evaluation.x, lower=lower, upper=upper, tolerance=tolerance)
    if not torch.any(active_mask):
        return False

    stationarity = _lagrangian_stationarity(evaluation, multipliers)

    _, _, dual_feasibility_residual = _recover_bound_multipliers(
        evaluation.x,
        stationarity,
        lower=lower,
        upper=upper,
        tolerance=tolerance,
    )
    return bool(torch.max(dual_feasibility_residual[active_mask]).detach().cpu().item() <= tolerance)


def _stabilize_linear_result(
    linear_result: LinearSolveResult,
    *,
    system: torch.Tensor,
    rhs: torch.Tensor,
) -> LinearSolveResult:
    diagnoses = set(linear_result.diagnosis)
    residual_norm = linear_result.residual_norm
    relative_residual = None
    if residual_norm is not None:
        rhs_scale = max(float(torch.norm(rhs).detach().cpu().item()), 1.0)
        relative_residual = float(residual_norm) / rhs_scale

    if (
        DiagnosisCode.ILL_CONDITIONED_SYSTEM not in diagnoses
        and DiagnosisCode.RANK_DEFICIENT_JACOBIAN not in diagnoses
        and (relative_residual is None or relative_residual <= _LINEAR_FALLBACK_RELATIVE_RESIDUAL_TOL)
    ):
        return linear_result

    stable_step = torch.pinverse(system) @ rhs
    stable_residual = float(torch.norm(system @ stable_step - rhs).detach().cpu().item())
    rhs_scale = max(float(torch.norm(rhs).detach().cpu().item()), 1.0)
    relative_residual = stable_residual / rhs_scale
    if relative_residual > _LINEAR_FALLBACK_RELATIVE_RESIDUAL_TOL:
        return LinearSolveResult(
            success=False,
            step=None,
            diagnosis=tuple(dict.fromkeys((*linear_result.diagnosis, DiagnosisCode.UNCERTIFIED_KKT_STEP))),
            diagnosis_by_batch=linear_result.diagnosis_by_batch,
            condition_estimate=linear_result.condition_estimate,
            residual_norm=stable_residual,
            iterations=linear_result.iterations,
            solver_name=linear_result.solver_name,
            message="Constrained KKT fallback could not certify a minimum-norm pseudoinverse step.",
        )

    return LinearSolveResult(
        success=True,
        step=stable_step,
        diagnosis=linear_result.diagnosis,
        diagnosis_by_batch=linear_result.diagnosis_by_batch,
        condition_estimate=linear_result.condition_estimate,
        residual_norm=stable_residual,
        iterations=linear_result.iterations,
        solver_name=linear_result.solver_name,
        message=linear_result.message,
    )


def _relative_linear_residual(linear_result: LinearSolveResult, rhs: torch.Tensor) -> float | None:
    residual_norm = linear_result.residual_norm
    if residual_norm is None:
        return None

    rhs_scale = max(float(torch.norm(rhs).detach().cpu().item()), 1.0)
    return float(residual_norm) / rhs_scale


def _selected_linear_result_needs_exact_certification(
    linear_result: LinearSolveResult,
    *,
    rhs: torch.Tensor,
    force_exact: bool,
) -> bool:
    if force_exact:
        return True
    if not bool(linear_result.success) or linear_result.step is None:
        return True

    diagnoses = set(linear_result.diagnosis)
    if DiagnosisCode.RANK_DEFICIENT_JACOBIAN in diagnoses or DiagnosisCode.ILL_CONDITIONED_SYSTEM in diagnoses:
        return True

    relative_residual = _relative_linear_residual(linear_result, rhs)
    if relative_residual is None:
        return True
    return relative_residual > _LINEAR_FALLBACK_RELATIVE_RESIDUAL_TOL


def _merge_diagnosis_by_batch(
    left: tuple[tuple[DiagnosisCode, ...], ...] | None,
    right: tuple[tuple[DiagnosisCode, ...], ...] | None,
) -> tuple[tuple[DiagnosisCode, ...], ...] | None:
    if left is None:
        return right
    if right is None:
        return left

    merged: list[tuple[DiagnosisCode, ...]] = []
    for left_batch, right_batch in zip(left, right, strict=True):
        merged.append(tuple(dict.fromkeys((*left_batch, *right_batch))))
    return tuple(merged)


def _certify_selected_linear_result(
    linear_result: LinearSolveResult,
    *,
    system: torch.Tensor,
    rhs: torch.Tensor,
    compute_condition_estimate: bool,
    force_exact: bool = False,
) -> LinearSolveResult:
    if not compute_condition_estimate:
        return _stabilize_linear_result(linear_result, system=system, rhs=rhs)

    if not _selected_linear_result_needs_exact_certification(
        linear_result,
        rhs=rhs,
        force_exact=force_exact,
    ):
        return _stabilize_linear_result(linear_result, system=system, rhs=rhs)

    condition_estimate, condition_diagnoses, condition_by_batch = compute_condition_diagnostics(
        Linearization(
            matrix=system,
            rhs=rhs,
            symmetric=True,
            positive_semidefinite=False,
            compute_condition_estimate=True,
        )
    )
    certified_result = LinearSolveResult(
        success=linear_result.success,
        step=linear_result.step,
        diagnosis=tuple(dict.fromkeys((*linear_result.diagnosis, *condition_diagnoses))),
        diagnosis_by_batch=_merge_diagnosis_by_batch(linear_result.diagnosis_by_batch, condition_by_batch),
        condition_estimate=condition_estimate,
        residual_norm=linear_result.residual_norm,
        iterations=linear_result.iterations,
        solver_name=linear_result.solver_name,
        message=linear_result.message,
    )
    return _stabilize_linear_result(certified_result, system=system, rhs=rhs)


def solve_constrained_nlp(
    problem: ConstrainedNLPProblem,
    x0: Any,
    params: Any | None = None,
    config: SolverConfig | None = None,
) -> SolveResult:
    """Solve a dense equality-and-bounds constrained NLP with SQP.

    Parameters
    ----------
    problem : ConstrainedNLPProblem
        Constrained optimization problem with equality constraints and optional
        simple bounds.
    x0 : Any
        Initial state, convertible to a dense tensor.
    params : Any | None, optional
        Optional parameter payload forwarded to objective and constraint
        evaluations.
    config : SolverConfig | None, optional
        Solver configuration. Only dense single-instance SQP with equality
        constraints and bounds is supported in this baseline implementation.

    Returns
    -------
    SolveResult
        Structured optimization result containing terminal status, iterate,
        diagnostics, and optional history.

    Notes
    -----
    The implementation follows a standard SQP pattern:

    1. evaluate the current iterate,
    2. form a dense KKT system for the local quadratic model,
    3. solve either the full or a safeguarded reduced active-set system,
    4. accept or reject the trial point with a merit backtracking rule,
    5. update multipliers, KKT metrics, and the BFGS model when applicable.

    The reduced-first shortcut is mathematically restricted to cases where the
    current bound-active set is already dual-feasible; otherwise the method
    reverts to the full KKT solve to preserve the intended solver logic.
    """

    normalized_config = config if config is not None else SolverConfig()
    normalized_method = _SUPPORTED_METHODS.get(normalized_config.method.lower())
    if normalized_method is None:
        supported = ", ".join(sorted(_SUPPORTED_METHODS))
        raise ValueError(f"Unsupported constrained method '{normalized_config.method}'. Expected one of: {supported}.")
    if normalized_config.batch_mode is not BatchMode.AUTO:
        raise NotImplementedError("Constrained NLP batch modes are not implemented yet.")
    if normalized_config.linear_solver.lower() == "cholesky":
        raise ValueError("The constrained SQP baseline requires an indefinite-capable linear solver; use 'auto' or 'dense_direct'.")

    problem.validate()
    equality_constraints, inequality_constraints = _split_constraints(problem)
    requested_device = resolve_requested_device(normalized_config.device)
    device_params = move_to_device(params, requested_device) if requested_device is not None else params
    x, original_shape = _as_dense_state_tensor(x0, name="x0", requested_device=requested_device)
    lower, upper = _prepare_bounds(problem.bounds, like=x, original_shape=original_shape)
    x = _project_bounds(x, lower, upper)

    hessian_mode = normalized_config.constrained_hessian_model.lower()
    if hessian_mode not in {"bfgs", "exact"}:
        raise ValueError("config.constrained_hessian_model must be 'bfgs' or 'exact'.")
    if normalized_config.constrained_merit_penalty <= 0.0:
        raise ValueError("config.constrained_merit_penalty must be positive.")

    # Start from a full first-order model at the projected initial iterate.
    evaluation = evaluate_dense_constrained_problem(
        problem,
        x,
        device_params,
        original_shape=original_shape,
        equality_constraints=equality_constraints,
        inequality_constraints=inequality_constraints,
        bounds=problem.bounds,
        lower=lower,
        upper=upper,
        previous_inequality_multipliers=None,
        tolerance=max(normalized_config.tol, 1e-6),
    )
    multipliers = _estimate_constraint_multipliers(
        evaluation,
        lower=lower,
        upper=upper,
        previous_inequality_multipliers=None,
        tolerance=max(normalized_config.tol, 1e-6),
    )
    kkt_residual = _kkt_residual(evaluation, multipliers, lower=lower, upper=upper, tolerance=max(normalized_config.tol, 1e-6))
    if float(kkt_residual.detach().cpu().item()) <= normalized_config.tol:
        return SolveResult(
            x=_reshape_state(x, original_shape).detach(),
            success=True,
            status=SolveStatus.CONVERGED,
            termination=TerminationReason.GRADIENT_TOL,
            message="Constrained SQP converged at the initial iterate.",
            num_iter=0,
            objective_value=float(evaluation.objective_value.detach().cpu().item()),
            gradient_norm=float(torch.norm(evaluation.objective_gradient).detach().cpu().item()),
            step_norm=None,
            constraint_violation=float(evaluation.constraint_violation.detach().cpu().item()),
            kkt_residual=float(kkt_residual.detach().cpu().item()),
            active_set=evaluation.active_set,
            reproducibility={
                "method": normalized_method,
                "constrained_hessian_model": hessian_mode,
            },
            diff_mode_used=DiffMode.AUTO.value,
            diff_valid=False,
            diff_reason="Constrained solver differentiation is not implemented yet.",
        )

    history_records: list[IterationRecord] = []
    diagnoses: list[DiagnosisCode] = []
    linear_solver = build_linear_solver("dense_direct" if normalized_config.linear_solver.lower() == "auto" else normalized_config.linear_solver)
    compute_linear_condition_estimate = (
        normalized_config.debug.capture_history
        or normalized_config.debug.explain
        or normalized_config.debug.enabled
    )
    hessian = torch.eye(x.numel(), dtype=x.dtype, device=x.device)
    cached_equality_model_diagnoses: tuple[DiagnosisCode, ...] | None = None
    last_step_norm: float | None = None
    last_linear_residual: Any | None = None
    last_linear_condition: Any | None = None
    last_linear_result_for_report: LinearSolveResult | None = None
    last_linear_system_for_report: torch.Tensor | None = None
    last_linear_rhs_for_report: torch.Tensor | None = None
    previous_variable_scale: torch.Tensor | None = None
    last_scaling_metadata: dict[str, Any] | None = None

    def _current_equality_model_diagnoses() -> tuple[DiagnosisCode, ...]:
        nonlocal cached_equality_model_diagnoses
        if cached_equality_model_diagnoses is None:
            cached_equality_model_diagnoses = _equality_model_diagnoses(evaluation.equality_jacobian)
        return cached_equality_model_diagnoses

    def _record_current_equality_model_diagnoses() -> None:
        for code in _current_equality_model_diagnoses():
            _append_diagnosis(diagnoses, code)

    def _reproducibility_payload() -> dict[str, Any]:
        payload: dict[str, Any] = {
            "method": normalized_method,
            "constrained_hessian_model": hessian_mode,
        }
        if last_scaling_metadata is not None:
            payload["constrained_scaling"] = last_scaling_metadata
        return payload

    for iteration in range(1, normalized_config.max_iter + 1):
        if hessian_mode == "exact":
            # In exact mode, rebuild the local Lagrangian Hessian at every iterate.
            hessian = _exact_lagrangian_hessian(
                problem,
                x,
                device_params,
                original_shape=original_shape,
                equality_constraints=equality_constraints,
                inequality_constraints=inequality_constraints,
                multipliers=multipliers,
            )

        scaled_system = _kkt_system(
            hessian,
            evaluation,
            inequality_multipliers=multipliers.inequality,
            tolerance=max(normalized_config.tol, 1e-6),
            scaling_config=normalized_config.scaling,
            previous_variable_scale=previous_variable_scale,
        )
        active_inequality_mask = scaled_system.active_inequality_mask
        selected_scaling = scaled_system.scaling
        for code in scaled_system.scaling.diagnoses:
            _append_diagnosis(diagnoses, code)
        linear_result: LinearSolveResult | None = None
        selected_linear_system: torch.Tensor | None = None
        selected_linear_rhs: torch.Tensor | None = None
        attempted_position_active_reduced_solve = False
        reduced_fallback_free_mask: torch.Tensor | None = None
        reduced_fallback_active_inequality_mask: torch.Tensor | None = None
        # Only skip directly to the reduced system when the current active set
        # is already dual-feasible; otherwise the full-KKT step remains the
        # correctness baseline and the reduced solve is only a fallback.
        if _should_try_position_active_reduced_solve(
            evaluation,
            multipliers,
            lower=lower,
            upper=upper,
            tolerance=max(normalized_config.tol, 1e-6),
        ):
            attempted_position_active_reduced_solve = True
            reduced_linear_result, free_mask, reduced_active_inequality_mask, reduced_scaling, reduced_linear_system, reduced_linear_rhs = _attempt_position_active_reduced_solve(
                linear_solver=linear_solver,
                hessian=hessian,
                evaluation=evaluation,
                multipliers=multipliers,
                lower=lower,
                upper=upper,
                tolerance=max(normalized_config.tol, 1e-6),
                compute_condition_estimate=compute_linear_condition_estimate,
                scaling_config=normalized_config.scaling,
                previous_variable_scale=previous_variable_scale,
            )
            if reduced_scaling is not None:
                for code in reduced_scaling.diagnoses:
                    _append_diagnosis(diagnoses, code)
            if reduced_linear_result is not None:
                for code in reduced_linear_result.diagnosis:
                    _append_diagnosis(diagnoses, code)
                if bool(reduced_linear_result.success) and reduced_linear_result.step is not None and free_mask is not None:
                    linear_result = reduced_linear_result
                    selected_linear_system = reduced_linear_system
                    selected_linear_rhs = reduced_linear_rhs
                    reduced_fallback_free_mask = free_mask
                    reduced_fallback_active_inequality_mask = reduced_active_inequality_mask
                    if reduced_scaling is not None:
                        selected_scaling = reduced_scaling

        if linear_result is None:
            linear_result = linear_solver.solve(
                Linearization(
                    matrix=scaled_system.system,
                    rhs=scaled_system.rhs,
                    symmetric=True,
                    positive_semidefinite=False,
                    compute_condition_estimate=False,
                )
            )
            if bool(linear_result.success) and linear_result.step is not None:
                linear_result = _certify_selected_linear_result(
                    linear_result,
                    system=scaled_system.system,
                    rhs=scaled_system.rhs,
                    compute_condition_estimate=compute_linear_condition_estimate,
                )
            if bool(linear_result.success) and linear_result.step is not None:
                selected_linear_system = scaled_system.system
                selected_linear_rhs = scaled_system.rhs
                linear_result = LinearSolveResult(
                    success=linear_result.success,
                    step=_unscale_kkt_step(linear_result.step, scaled_system.scaling),
                    diagnosis=linear_result.diagnosis,
                    diagnosis_by_batch=linear_result.diagnosis_by_batch,
                    condition_estimate=linear_result.condition_estimate,
                    residual_norm=linear_result.residual_norm,
                    iterations=linear_result.iterations,
                    solver_name=linear_result.solver_name,
                    message=linear_result.message,
                )

        if (not bool(linear_result.success) or linear_result.step is None) and not attempted_position_active_reduced_solve:
            reduced_linear_result, free_mask, reduced_active_inequality_mask, reduced_scaling, reduced_linear_system, reduced_linear_rhs = _attempt_position_active_reduced_solve(
                linear_solver=linear_solver,
                hessian=hessian,
                evaluation=evaluation,
                multipliers=multipliers,
                lower=lower,
                upper=upper,
                tolerance=max(normalized_config.tol, 1e-6),
                compute_condition_estimate=compute_linear_condition_estimate,
                scaling_config=normalized_config.scaling,
                previous_variable_scale=previous_variable_scale,
            )
            if reduced_scaling is not None:
                for code in reduced_scaling.diagnoses:
                    _append_diagnosis(diagnoses, code)
            if reduced_linear_result is not None:
                for code in reduced_linear_result.diagnosis:
                    _append_diagnosis(diagnoses, code)
                if bool(reduced_linear_result.success) and reduced_linear_result.step is not None and free_mask is not None:
                    linear_result = reduced_linear_result
                    selected_linear_system = reduced_linear_system
                    selected_linear_rhs = reduced_linear_rhs
                    reduced_fallback_free_mask = free_mask
                    reduced_fallback_active_inequality_mask = reduced_active_inequality_mask
                    if reduced_scaling is not None:
                        selected_scaling = reduced_scaling

        for code in linear_result.diagnosis:
            _append_diagnosis(diagnoses, code)
        if not bool(linear_result.success) or linear_result.step is None:
            _record_current_equality_model_diagnoses()
            return SolveResult(
                x=_reshape_state(x, original_shape).detach(),
                success=False,
                status=SolveStatus.FAILED,
                termination=TerminationReason.NUMERICAL_FAILURE,
                message="The constrained SQP linear solve failed.",
                num_iter=len(history_records),
                objective_value=float(evaluation.objective_value.detach().cpu().item()),
                gradient_norm=float(torch.norm(evaluation.objective_gradient).detach().cpu().item()),
                constraint_violation=float(evaluation.constraint_violation.detach().cpu().item()),
                kkt_residual=float(kkt_residual.detach().cpu().item()),
                active_set=evaluation.active_set,
                history=tuple(history_records),
                diagnosis=tuple(diagnoses),
                reproducibility=_reproducibility_payload(),
                diff_mode_used=DiffMode.AUTO.value,
                diff_valid=False,
                diff_reason="Constrained solver differentiation is not implemented yet.",
                linear_condition_estimate=linear_result.condition_estimate,
                linear_residual_norm=linear_result.residual_norm,
            )

        full_step = linear_result.step
        if reduced_fallback_free_mask is not None:
            step = x.new_zeros(x.shape)
            free_count = int(torch.count_nonzero(reduced_fallback_free_mask).detach().cpu().item())
            step[reduced_fallback_free_mask] = full_step[:free_count]
            raw_trial_multiplier = full_step[free_count:] if full_step.numel() > free_count else x.new_zeros(0)
            trial_multiplier = _expand_constraint_multipliers(
                raw_trial_multiplier,
                equality_count=evaluation.equality_jacobian.shape[0],
                active_inequality_mask=reduced_fallback_active_inequality_mask
                if reduced_fallback_active_inequality_mask is not None
                else active_inequality_mask,
                total_inequality_count=evaluation.inequality_values.numel(),
            )
        else:
            step = full_step[: x.numel()]
            raw_trial_multiplier = full_step[x.numel() :] if full_step.numel() > x.numel() else x.new_zeros(0)
            trial_multiplier = _expand_constraint_multipliers(
                raw_trial_multiplier,
                equality_count=evaluation.equality_jacobian.shape[0],
                active_inequality_mask=active_inequality_mask,
                total_inequality_count=evaluation.inequality_values.numel(),
            )
        scaling_free_mask = reduced_fallback_free_mask

        # If the trial step pushes into bounds, re-solve on the corresponding
        # reduced free-variable system before evaluating line-search candidates.
        active_mask = _active_bound_mask(
            evaluation.x,
            step,
            lower=lower,
            upper=upper,
            tolerance=max(normalized_config.tol, 1e-8),
        )
        if reduced_fallback_free_mask is None and torch.any(active_mask):
            reduced_system, free_mask, reduced_active_inequality_mask = _reduced_kkt_system(
                hessian,
                evaluation,
                active_mask=active_mask,
                inequality_multipliers=multipliers.inequality,
                tolerance=max(normalized_config.tol, 1e-6),
                scaling_config=normalized_config.scaling,
                previous_variable_scale=previous_variable_scale,
            )
            if reduced_system is not None:
                for code in reduced_system.scaling.diagnoses:
                    _append_diagnosis(diagnoses, code)
                reduced_linear_result = linear_solver.solve(
                    Linearization(
                        matrix=reduced_system.system,
                        rhs=reduced_system.rhs,
                        symmetric=True,
                        positive_semidefinite=False,
                        compute_condition_estimate=False,
                    )
                )
                for code in reduced_linear_result.diagnosis:
                    _append_diagnosis(diagnoses, code)
                if bool(reduced_linear_result.success) and reduced_linear_result.step is not None:
                    assert reduced_linear_result.step is not None
                    assert free_mask is not None
                    reduced_linear_result = _certify_selected_linear_result(
                        reduced_linear_result,
                        system=reduced_system.system,
                        rhs=reduced_system.rhs,
                        compute_condition_estimate=compute_linear_condition_estimate,
                    )
                if bool(reduced_linear_result.success) and reduced_linear_result.step is not None:
                    selected_linear_system = reduced_system.system
                    selected_linear_rhs = reduced_system.rhs
                    reduced_step = _unscale_kkt_step(cast(torch.Tensor, reduced_linear_result.step), reduced_system.scaling)
                    reduced_linear_result = LinearSolveResult(
                        success=reduced_linear_result.success,
                        step=reduced_step,
                        diagnosis=reduced_linear_result.diagnosis,
                        diagnosis_by_batch=reduced_linear_result.diagnosis_by_batch,
                        condition_estimate=reduced_linear_result.condition_estimate,
                        residual_norm=reduced_linear_result.residual_norm,
                        iterations=reduced_linear_result.iterations,
                        solver_name=reduced_linear_result.solver_name,
                        message=reduced_linear_result.message,
                    )
                    reduced_free_mask: torch.Tensor = free_mask
                    reduced_full_step = x.new_zeros(x.shape)
                    free_count = int(torch.count_nonzero(reduced_free_mask).detach().cpu().item())
                    reduced_full_step[reduced_free_mask] = reduced_step[:free_count]
                    step = reduced_full_step
                    raw_trial_multiplier = reduced_step[free_count:] if reduced_step.numel() > free_count else x.new_zeros(0)
                    trial_multiplier = _expand_constraint_multipliers(
                        raw_trial_multiplier,
                        equality_count=evaluation.equality_jacobian.shape[0],
                        active_inequality_mask=reduced_active_inequality_mask,
                        total_inequality_count=evaluation.inequality_values.numel(),
                    )
                    scaling_free_mask = reduced_free_mask
                    linear_result = reduced_linear_result
                    selected_scaling = reduced_system.scaling
        penalty = max(
            normalized_config.constrained_merit_penalty,
            float(
                torch.max(
                    torch.abs(torch.cat((trial_multiplier.equality, trial_multiplier.inequality)))
                ).detach().cpu().item()
            )
            + 1.0
            if (trial_multiplier.equality.numel() + trial_multiplier.inequality.numel()) > 0
            else 0.0,
        )
        current_merit = _merit_value(
            evaluation.objective_value,
            evaluation.equality_values,
            evaluation.inequality_values,
            penalty,
        )

        # Backtrack on the merit function using lightweight trial evaluations.
        accepted_trial_evaluation: DenseConstrainedTrialEvaluation | None = None
        accepted_evaluation: DenseConstrainedEvaluation | None = None
        accepted_x: torch.Tensor | None = None
        accepted_alpha: float | None = None
        accepted_reason = "accepted"
        trial_records: list[TrialRecord] = []
        alpha = 1.0
        while alpha >= 1e-8:
            trial_x = _project_bounds(x + alpha * step, lower, upper)
            step_norm = float(torch.norm(trial_x - x).detach().cpu().item())
            trial_evaluation = evaluate_dense_constrained_trial_problem(
                problem,
                trial_x,
                device_params,
                original_shape=original_shape,
                equality_constraints=equality_constraints,
                inequality_constraints=inequality_constraints,
                bounds=problem.bounds,
                lower=lower,
                upper=upper,
            )
            trial_merit = _merit_value(
                trial_evaluation.objective_value,
                trial_evaluation.equality_values,
                trial_evaluation.inequality_values,
                penalty,
            )
            merit_value = float(trial_merit.detach().cpu().item())
            current_merit_value = float(current_merit.detach().cpu().item())
            merit_improved = merit_value < current_merit_value - 1e-12
            step_tol_candidate = (
                step_norm <= normalized_config.tol
                and float(trial_evaluation.constraint_violation.detach().cpu().item()) <= normalized_config.tol
                and merit_value <= current_merit_value + 1e-12
            )
            accepted = merit_improved or step_tol_candidate
            trial_reason = "accepted" if merit_improved else "step_tol" if step_tol_candidate else "merit_not_improved"
            trial_records.append(
                TrialRecord(
                    attempt=len(trial_records) + 1,
                    objective_value=float(trial_evaluation.objective_value.detach().cpu().item()),
                    step_norm=step_norm,
                    accepted=accepted,
                    reason=trial_reason,
                    state=_reshape_state(trial_x, original_shape).detach(),
                    step_parameter=alpha,
                    linear_solver_iterations=linear_result.iterations,
                    linear_residual_norm=linear_result.residual_norm,
                    linear_condition_estimate=linear_result.condition_estimate,
                )
            )
            if accepted:
                accepted_trial_evaluation = trial_evaluation
                accepted_x = trial_x
                accepted_alpha = alpha
                accepted_reason = trial_reason
                break
            alpha *= 0.5

        if accepted_trial_evaluation is None or accepted_x is None or accepted_alpha is None:
            diagnoses.append(DiagnosisCode.STEP_REJECTED)
            history_records.append(
                IterationRecord(
                    iteration=iteration,
                    objective_value=float(evaluation.objective_value.detach().cpu().item()),
                    gradient_norm=float(torch.norm(evaluation.objective_gradient).detach().cpu().item()),
                    constraint_violation=float(evaluation.constraint_violation.detach().cpu().item()),
                    step_norm=None,
                    accepted=False,
                    reason="step_rejected",
                    state=_reshape_state(x, original_shape).detach(),
                    trials=tuple(trial_records),
                    linear_residual_norm=linear_result.residual_norm,
                    linear_condition_estimate=linear_result.condition_estimate,
                )
            )
            _record_current_equality_model_diagnoses()
            return SolveResult(
                x=_reshape_state(x, original_shape).detach(),
                success=False,
                status=SolveStatus.FAILED,
                termination=TerminationReason.NUMERICAL_FAILURE,
                message="The constrained SQP merit backtracking rejected all trial steps.",
                num_iter=len(history_records),
                objective_value=float(evaluation.objective_value.detach().cpu().item()),
                gradient_norm=float(torch.norm(evaluation.objective_gradient).detach().cpu().item()),
                step_norm=None,
                constraint_violation=float(evaluation.constraint_violation.detach().cpu().item()),
                kkt_residual=float(kkt_residual.detach().cpu().item()),
                active_set=evaluation.active_set,
                history=tuple(history_records),
                diagnosis=tuple(dict.fromkeys(diagnoses)),
                reproducibility=_reproducibility_payload(),
                diff_mode_used=DiffMode.AUTO.value,
                diff_valid=False,
                diff_reason="Constrained solver differentiation is not implemented yet.",
                linear_condition_estimate=linear_result.condition_estimate,
                linear_residual_norm=linear_result.residual_norm,
            )

        # Rebuild the full derivative model only once the trial point is accepted.
        accepted_evaluation = evaluate_dense_constrained_problem(
            problem,
            accepted_x,
            device_params,
            original_shape=original_shape,
            equality_constraints=equality_constraints,
            inequality_constraints=inequality_constraints,
            bounds=problem.bounds,
            lower=lower,
            upper=upper,
            previous_inequality_multipliers=trial_multiplier.inequality,
            tolerance=max(normalized_config.tol, 1e-6),
        )

        next_multipliers = _estimate_constraint_multipliers(
            accepted_evaluation,
            lower=lower,
            upper=upper,
            previous_inequality_multipliers=trial_multiplier.inequality,
            tolerance=max(normalized_config.tol, 1e-6),
        )
        cached_equality_model_diagnoses = _equality_model_diagnoses(accepted_evaluation.equality_jacobian)
        if hessian_mode == "bfgs":
            for code in cached_equality_model_diagnoses:
                _append_diagnosis(diagnoses, code)

            if cached_equality_model_diagnoses:
                _append_diagnosis(diagnoses, DiagnosisCode.SKIPPED_CURVATURE_UPDATE)
            else:
                # Update the quasi-Newton model with Lagrangian-gradient curvature,
                # not the plain objective gradient, so equality effects remain in the model.
                current_lagrangian_gradient = _lagrangian_stationarity(evaluation, multipliers)
                next_lagrangian_gradient = _lagrangian_stationarity(accepted_evaluation, next_multipliers)
                hessian = _bfgs_update(hessian, accepted_x - x, next_lagrangian_gradient - current_lagrangian_gradient)

        x = accepted_x
        evaluation = accepted_evaluation
        multipliers = next_multipliers
        previous_variable_scale = _full_variable_scale(
            x.numel(),
            scaling=selected_scaling,
            free_mask=scaling_free_mask,
            previous_variable_scale=previous_variable_scale,
            like=x,
        )
        last_scaling_metadata = selected_scaling.to_metadata()
        kkt_residual = _kkt_residual(evaluation, multipliers, lower=lower, upper=upper, tolerance=max(normalized_config.tol, 1e-6))
        last_step_norm = float(torch.norm(step * accepted_alpha).detach().cpu().item())
        converged_gradient = float(kkt_residual.detach().cpu().item()) <= normalized_config.tol
        converged_step = last_step_norm <= normalized_config.tol and float(evaluation.constraint_violation.detach().cpu().item()) <= normalized_config.tol
        if (
            compute_linear_condition_estimate
            and linear_result.condition_estimate is None
            and selected_linear_system is not None
            and selected_linear_rhs is not None
            and (converged_gradient or converged_step)
        ):
            linear_result = _certify_selected_linear_result(
                linear_result,
                system=selected_linear_system,
                rhs=selected_linear_rhs,
                compute_condition_estimate=compute_linear_condition_estimate,
                force_exact=True,
            )
        last_linear_residual = linear_result.residual_norm
        last_linear_condition = linear_result.condition_estimate
        last_linear_result_for_report = linear_result
        last_linear_system_for_report = selected_linear_system
        last_linear_rhs_for_report = selected_linear_rhs
        history_records.append(
            IterationRecord(
                iteration=iteration,
                objective_value=float(evaluation.objective_value.detach().cpu().item()),
                gradient_norm=float(torch.norm(evaluation.objective_gradient).detach().cpu().item()),
                constraint_violation=float(evaluation.constraint_violation.detach().cpu().item()),
                step_norm=last_step_norm,
                accepted=True,
                reason=accepted_reason,
                state=_reshape_state(x, original_shape).detach(),
                trials=tuple(trial_records),
                linear_residual_norm=linear_result.residual_norm,
                linear_condition_estimate=linear_result.condition_estimate,
            )
        )

        if converged_gradient:
            _record_current_equality_model_diagnoses()
            return SolveResult(
                x=_reshape_state(x, original_shape).detach(),
                success=True,
                status=SolveStatus.CONVERGED,
                termination=TerminationReason.GRADIENT_TOL,
                message="Constrained SQP converged to a KKT point.",
                num_iter=len(history_records),
                objective_value=float(evaluation.objective_value.detach().cpu().item()),
                gradient_norm=float(torch.norm(evaluation.objective_gradient).detach().cpu().item()),
                step_norm=last_step_norm,
                constraint_violation=float(evaluation.constraint_violation.detach().cpu().item()),
                kkt_residual=float(kkt_residual.detach().cpu().item()),
                active_set=evaluation.active_set,
                history=tuple(history_records),
                diagnosis=tuple(dict.fromkeys(diagnoses)),
                reproducibility=_reproducibility_payload(),
                diff_mode_used=DiffMode.AUTO.value,
                diff_valid=False,
                diff_reason="Constrained solver differentiation is not implemented yet.",
                linear_condition_estimate=last_linear_condition,
                linear_residual_norm=last_linear_residual,
            )

        if converged_step:
            _record_current_equality_model_diagnoses()
            return SolveResult(
                x=_reshape_state(x, original_shape).detach(),
                success=True,
                status=SolveStatus.CONVERGED,
                termination=TerminationReason.STEP_TOL,
                message="Constrained SQP accepted a step below the tolerance threshold.",
                num_iter=len(history_records),
                objective_value=float(evaluation.objective_value.detach().cpu().item()),
                gradient_norm=float(torch.norm(evaluation.objective_gradient).detach().cpu().item()),
                step_norm=last_step_norm,
                constraint_violation=float(evaluation.constraint_violation.detach().cpu().item()),
                kkt_residual=float(kkt_residual.detach().cpu().item()),
                active_set=evaluation.active_set,
                history=tuple(history_records),
                diagnosis=tuple(dict.fromkeys(diagnoses)),
                reproducibility=_reproducibility_payload(),
                diff_mode_used=DiffMode.AUTO.value,
                diff_valid=False,
                diff_reason="Constrained solver differentiation is not implemented yet.",
                linear_condition_estimate=last_linear_condition,
                linear_residual_norm=last_linear_residual,
            )

    if (
        compute_linear_condition_estimate
        and last_linear_result_for_report is not None
        and last_linear_condition is None
        and last_linear_system_for_report is not None
        and last_linear_rhs_for_report is not None
    ):
        last_linear_result_for_report = _certify_selected_linear_result(
            last_linear_result_for_report,
            system=last_linear_system_for_report,
            rhs=last_linear_rhs_for_report,
            compute_condition_estimate=compute_linear_condition_estimate,
            force_exact=True,
        )
        last_linear_residual = last_linear_result_for_report.residual_norm
        last_linear_condition = last_linear_result_for_report.condition_estimate

    _record_current_equality_model_diagnoses()
    return SolveResult(
        x=_reshape_state(x, original_shape).detach(),
        success=False,
        status=SolveStatus.MAX_ITER_REACHED,
        termination=TerminationReason.MAX_ITER,
        message="Constrained SQP reached the iteration budget before satisfying the KKT tolerance.",
        num_iter=len(history_records),
        objective_value=float(evaluation.objective_value.detach().cpu().item()),
        gradient_norm=float(torch.norm(evaluation.objective_gradient).detach().cpu().item()),
        step_norm=last_step_norm,
        constraint_violation=float(evaluation.constraint_violation.detach().cpu().item()),
        kkt_residual=float(kkt_residual.detach().cpu().item()),
        active_set=evaluation.active_set,
        history=tuple(history_records),
        diagnosis=tuple(dict.fromkeys(diagnoses)),
        reproducibility=_reproducibility_payload(),
        diff_mode_used=DiffMode.AUTO.value,
        diff_valid=False,
        diff_reason="Constrained solver differentiation is not implemented yet.",
        linear_condition_estimate=last_linear_condition,
        linear_residual_norm=last_linear_residual,
    )