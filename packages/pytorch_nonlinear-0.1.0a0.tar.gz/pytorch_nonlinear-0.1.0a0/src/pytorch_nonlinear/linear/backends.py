"""Linear solver backends for dense nonlinear optimization subproblems."""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
import math

import torch

from pytorch_nonlinear.diagnostics import DiagnosisCode


@dataclass(frozen=True)
class Linearization:
    """Dense linear system description requested by an outer solver.

    Parameters
    ----------
    matrix : torch.Tensor
        Dense coefficient matrix for the step system.
    rhs : torch.Tensor
        Right-hand side vector.
    damping : float, optional
        Diagonal regularization coefficient added as ``damping * I``.
    symmetric : bool, optional
        Whether the matrix should be treated as symmetric.
    positive_semidefinite : bool, optional
        Whether the undamped matrix is expected to be positive semidefinite.
    compute_condition_estimate : bool, optional
        Whether the backend should estimate the system condition number and
        emit condition-based diagnoses.
    """

    matrix: torch.Tensor
    rhs: torch.Tensor
    damping: float | torch.Tensor = 0.0
    symmetric: bool = False
    positive_semidefinite: bool = False
    compute_condition_estimate: bool = True


@dataclass(frozen=True)
class LinearSolveResult:
    """Structured result returned by a linear solver backend.

    Parameters
    ----------
    success : bool
        Whether the backend produced a usable step.
    step : torch.Tensor | None, optional
        Computed step vector.
    diagnosis : tuple[DiagnosisCode, ...], optional
        Structured diagnoses raised during the solve.
    diagnosis_by_batch : tuple[tuple[DiagnosisCode, ...], ...] | None, optional
        Per-instance diagnoses for batched solves. When present, this carries
        the diagnoses that apply to each batch element without broadcasting
        failures to healthy neighbors.
    condition_estimate : float | None, optional
        Estimated condition number when available.
    residual_norm : float | None, optional
        Norm of the linear residual ``A x - b`` when available.
    iterations : int | None, optional
        Inner solver iteration count. Direct solvers typically report ``1``.
    solver_name : str, optional
        Canonical backend name that produced the result.
    message : str, optional
        Short explanation for the solve outcome.
    """

    success: bool | torch.Tensor
    step: torch.Tensor | None = None
    diagnosis: tuple[DiagnosisCode, ...] = ()
    diagnosis_by_batch: tuple[tuple[DiagnosisCode, ...], ...] | None = None
    condition_estimate: float | torch.Tensor | None = None
    residual_norm: float | torch.Tensor | None = None
    iterations: int | None = None
    solver_name: str = ""
    message: str = ""


class LinearSolver(ABC):
    """Abstract interface for dense linear solver backends."""

    name: str

    @abstractmethod
    def solve(self, linearization: Linearization) -> LinearSolveResult:
        """Solve one dense linear system.

        Parameters
        ----------
        linearization : Linearization
            Dense linear system requested by the outer solver.

        Returns
        -------
        LinearSolveResult
            Structured linear solve outcome.
        """


def _system_with_damping(linearization: Linearization) -> torch.Tensor:
    """Apply diagonal damping to a dense linear system when requested."""

    system = linearization.matrix
    damping = linearization.damping
    if isinstance(damping, torch.Tensor):
        damping_tensor = damping.to(dtype=system.dtype, device=system.device)
        if damping_tensor.ndim == 0:
            if float(damping_tensor.detach().cpu().item()) <= 0.0:
                return system
            damping_tensor = damping_tensor.reshape(1)
        if not torch.any(damping_tensor > 0):
            return system
        identity = torch.eye(system.shape[-1], dtype=system.dtype, device=system.device)
        expand_shape = damping_tensor.shape + (1, 1)
        return system + damping_tensor.reshape(expand_shape) * identity

    if damping > 0.0:
        identity = torch.eye(system.shape[-1], dtype=system.dtype, device=system.device)
        system = system + damping * identity
    return system


def _condition_metrics(
    system: torch.Tensor,
    *,
    compute_condition_estimate: bool,
    symmetric: bool = False,
) -> tuple[float | torch.Tensor | None, tuple[DiagnosisCode, ...], tuple[tuple[DiagnosisCode, ...], ...] | None]:
    """Estimate conditioning and return the value plus any diagnoses."""

    if not compute_condition_estimate:
        return None, (), None

    try:
        if symmetric:
            eigenvalues = torch.linalg.eigvalsh(system)
            singular_values = torch.abs(eigenvalues)
            max_singular_value = torch.amax(singular_values, dim=-1)
            min_singular_value = torch.amin(singular_values, dim=-1)
            infinity = torch.full_like(max_singular_value, float("inf"))
            condition_estimate = torch.where(min_singular_value > 0.0, max_singular_value / min_singular_value, infinity)
        else:
            condition_estimate = torch.linalg.cond(system)
    except RuntimeError:
        if system.ndim > 2:
            failed_diagnosis_by_batch = tuple((DiagnosisCode.ILL_CONDITIONED_SYSTEM,) for _ in range(system.shape[0]))
            return None, (DiagnosisCode.ILL_CONDITIONED_SYSTEM,), failed_diagnosis_by_batch
        return None, (DiagnosisCode.ILL_CONDITIONED_SYSTEM,), None

    if condition_estimate.ndim > 0:
        diagnosis_by_batch: list[tuple[DiagnosisCode, ...]] = []
        any_ill_conditioned = False
        for value in condition_estimate.detach().cpu().tolist():
            if not math.isfinite(value) or value > 1e8:
                diagnosis_by_batch.append((DiagnosisCode.ILL_CONDITIONED_SYSTEM,))
                any_ill_conditioned = True
            else:
                diagnosis_by_batch.append(())
        return condition_estimate, ((DiagnosisCode.ILL_CONDITIONED_SYSTEM,) if any_ill_conditioned else ()), tuple(diagnosis_by_batch)

    condition_value = float(condition_estimate.detach().cpu().item())
    if not torch.isfinite(condition_estimate):
        return condition_value, (DiagnosisCode.ILL_CONDITIONED_SYSTEM,), None

    if condition_value > 1e8:
        return condition_value, (DiagnosisCode.ILL_CONDITIONED_SYSTEM,), None
    return condition_value, (), None


def compute_condition_diagnostics(
    linearization: Linearization,
) -> tuple[float | torch.Tensor | None, tuple[DiagnosisCode, ...], tuple[tuple[DiagnosisCode, ...], ...] | None]:
    """Compute condition metrics for an already-formed linearization."""

    system = _system_with_damping(linearization)
    return _condition_metrics(
        system,
        compute_condition_estimate=linearization.compute_condition_estimate,
        symmetric=linearization.symmetric,
    )


def _residual_norm(system: torch.Tensor, step: torch.Tensor, rhs: torch.Tensor) -> float | torch.Tensor:
    """Compute a detached Euclidean norm of the linear residual."""

    if system.ndim > 2:
        residual = torch.matmul(system, step.unsqueeze(-1)).squeeze(-1) - rhs
    else:
        residual = system @ step - rhs
    if residual.ndim > 1:
        return torch.linalg.vector_norm(residual, dim=-1).detach()
    return float(torch.linalg.vector_norm(residual).detach().cpu().item())


class DenseDirectLinearSolver(LinearSolver):
    """Dense direct linear solver using ``torch.linalg.solve`` with fallback."""

    name = "dense_direct"

    def solve(self, linearization: Linearization) -> LinearSolveResult:
        """Solve the dense system with a direct factorization fallback."""

        diagnoses: list[DiagnosisCode] = []
        system = _system_with_damping(linearization)
        rhs = linearization.rhs
        rhs_for_solve = rhs.unsqueeze(-1) if rhs.ndim == system.ndim - 1 else rhs

        if system.ndim > 2:
            step, info = torch.linalg.solve_ex(system, rhs_for_solve, check_errors=False)
            success_mask = info == 0
            diagnosis_by_batch: list[list[DiagnosisCode]] = [[] for _ in range(system.shape[0])]
            if not torch.all(success_mask):
                failed = ~success_mask
                fallback_step = torch.linalg.lstsq(system[failed], rhs_for_solve[failed]).solution
                step = step.clone()
                step[failed] = fallback_step
                diagnoses.append(DiagnosisCode.RANK_DEFICIENT_JACOBIAN)
                for index in torch.nonzero(failed, as_tuple=False).flatten().tolist():
                    diagnosis_by_batch[index].append(DiagnosisCode.RANK_DEFICIENT_JACOBIAN)

            if step.ndim == rhs_for_solve.ndim and step.shape[-1] == 1 and rhs.ndim == system.ndim - 1:
                step = step.squeeze(-1)

            condition_estimate, condition_diagnoses, condition_by_batch = _condition_metrics(
                system,
                compute_condition_estimate=linearization.compute_condition_estimate,
                symmetric=linearization.symmetric,
            )
            diagnoses.extend(condition_diagnoses)
            if condition_by_batch is not None:
                for index, batch_diagnoses in enumerate(condition_by_batch):
                    diagnosis_by_batch[index].extend(batch_diagnoses)

            return LinearSolveResult(
                success=True,
                step=step,
                diagnosis=tuple(dict.fromkeys(diagnoses)),
                diagnosis_by_batch=tuple(tuple(dict.fromkeys(items)) for items in diagnosis_by_batch),
                condition_estimate=condition_estimate,
                residual_norm=_residual_norm(system, step, rhs),
                iterations=1,
                solver_name=self.name,
                message="Dense direct solve completed.",
            )

        try:
            step = torch.linalg.solve(system, rhs_for_solve)
        except RuntimeError:
            step = torch.linalg.lstsq(system, rhs_for_solve).solution
            diagnoses.append(DiagnosisCode.RANK_DEFICIENT_JACOBIAN)

        if step.ndim == rhs_for_solve.ndim and step.shape[-1] == 1 and rhs.ndim == system.ndim - 1:
            step = step.squeeze(-1)

        condition_estimate, condition_diagnoses, _ = _condition_metrics(
            system,
            compute_condition_estimate=linearization.compute_condition_estimate,
            symmetric=linearization.symmetric,
        )
        diagnoses.extend(condition_diagnoses)
        return LinearSolveResult(
            success=True,
            step=step,
            diagnosis=tuple(dict.fromkeys(diagnoses)),
            condition_estimate=condition_estimate,
            residual_norm=_residual_norm(system, step, rhs),
            iterations=1,
            solver_name=self.name,
            message="Dense direct solve completed.",
        )


class CholeskyLinearSolver(LinearSolver):
    """Dense Cholesky solver for symmetric positive definite systems."""

    name = "cholesky"

    def solve(self, linearization: Linearization) -> LinearSolveResult:
        """Solve the dense system with a Cholesky factorization."""

        system = _system_with_damping(linearization)
        condition_estimate, condition_diagnoses, condition_by_batch = _condition_metrics(
            system,
            compute_condition_estimate=linearization.compute_condition_estimate,
            symmetric=linearization.symmetric,
        )
        diagnoses = list(condition_diagnoses)
        rhs = linearization.rhs
        rhs_for_solve = rhs.unsqueeze(-1) if rhs.ndim == system.ndim - 1 else rhs

        if system.ndim > 2:
            factor, info = torch.linalg.cholesky_ex(system)
            success_mask = info == 0
            diagnosis_by_batch: list[list[DiagnosisCode]] = [list(batch_diagnoses) for batch_diagnoses in (condition_by_batch or tuple(() for _ in range(system.shape[0])))]
            if not torch.all(success_mask):
                diagnoses.append(DiagnosisCode.RANK_DEFICIENT_JACOBIAN)
                for index in torch.nonzero(~success_mask, as_tuple=False).flatten().tolist():
                    diagnosis_by_batch[index].append(DiagnosisCode.RANK_DEFICIENT_JACOBIAN)

            safe_factor = factor.clone()
            if not torch.all(success_mask):
                identity = torch.eye(system.shape[-1], dtype=system.dtype, device=system.device)
                safe_factor = torch.where(success_mask.reshape(-1, 1, 1), safe_factor, identity)

            step = torch.cholesky_solve(rhs_for_solve, safe_factor)
            if step.ndim == rhs_for_solve.ndim and step.shape[-1] == 1 and rhs.ndim == system.ndim - 1:
                step = step.squeeze(-1)
            if not torch.all(success_mask):
                step = torch.where(success_mask.reshape(-1, 1), step, torch.zeros_like(step))

            return LinearSolveResult(
                success=True if torch.all(success_mask) else success_mask,
                step=step,
                diagnosis=tuple(dict.fromkeys(diagnoses)),
                diagnosis_by_batch=tuple(tuple(dict.fromkeys(items)) for items in diagnosis_by_batch),
                condition_estimate=condition_estimate,
                residual_norm=_residual_norm(system, step, rhs),
                iterations=1,
                solver_name=self.name,
                message="Cholesky solve completed." if torch.all(success_mask) else "Cholesky factorization failed for one or more batch elements.",
            )

        try:
            factor = torch.linalg.cholesky(system)
            step = torch.cholesky_solve(rhs_for_solve, factor).squeeze(-1)
        except RuntimeError:
            diagnoses.append(DiagnosisCode.RANK_DEFICIENT_JACOBIAN)
            return LinearSolveResult(
                success=False,
                step=None,
                diagnosis=tuple(dict.fromkeys(diagnoses)),
                condition_estimate=condition_estimate,
                residual_norm=None,
                iterations=1,
                solver_name=self.name,
                message="Cholesky factorization failed.",
            )

        return LinearSolveResult(
            success=True,
            step=step,
            diagnosis=tuple(dict.fromkeys(diagnoses)),
            condition_estimate=condition_estimate,
            residual_norm=_residual_norm(system, step, linearization.rhs),
            iterations=1,
            solver_name=self.name,
            message="Cholesky solve completed.",
        )


_LINEAR_SOLVERS: dict[str, type[LinearSolver]] = {
    "auto": DenseDirectLinearSolver,
    "dense_direct": DenseDirectLinearSolver,
    "cholesky": CholeskyLinearSolver,
}


def build_linear_solver(name: str) -> LinearSolver:
    """Build a configured dense linear solver backend.

    Parameters
    ----------
    name : str
        Requested backend name.

    Returns
    -------
    LinearSolver
        Concrete backend instance.

    Raises
    ------
    ValueError
        If the backend name is not supported.
    """

    normalized_name = name.lower()
    if normalized_name not in _LINEAR_SOLVERS:
        supported = ", ".join(sorted(_LINEAR_SOLVERS))
        raise ValueError(f"Unsupported linear solver '{name}'. Expected one of: {supported}.")
    return _LINEAR_SOLVERS[normalized_name]()