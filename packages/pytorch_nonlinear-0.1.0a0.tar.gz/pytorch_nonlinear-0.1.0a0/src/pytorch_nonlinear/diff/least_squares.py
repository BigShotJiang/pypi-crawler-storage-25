"""Implicit differentiation helpers for dense least-squares solves."""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass
import math
from typing import Any

import torch

from pytorch_nonlinear.diagnostics import DiagnosisCode, SolveStatus, TerminationReason
from pytorch_nonlinear.losses import RobustLoss
from pytorch_nonlinear.problem import NonlinearLeastSquaresProblem


_IMPLICIT_CONDITION_LIMIT = 1e8


@dataclass(frozen=True)
class ImplicitLeastSquaresAssessment:
    """Certification outcome for implicit least-squares differentiation."""

    x: torch.Tensor
    valid: bool
    reason: str
    diagnoses: tuple[DiagnosisCode, ...]
    condition_estimate: float | None
    linear_residual: float | None


def _restore_state_shape(x: torch.Tensor, original_shape: torch.Size | tuple[int, ...]) -> torch.Tensor:
    state_shape = torch.Size(original_shape)
    if len(state_shape) == 0:
        return x.reshape(())
    return x.reshape(state_shape)


def _flatten_residual(residual: Any, *, dtype: torch.dtype, device: torch.device) -> torch.Tensor:
    if isinstance(residual, torch.Tensor):
        tensor = residual.to(dtype=dtype, device=device)
    elif isinstance(residual, (tuple, list)):
        pieces = [torch.as_tensor(piece, dtype=dtype, device=device).reshape(-1) for piece in residual]
        if not pieces:
            raise ValueError("residual must contain at least one value.")
        tensor = torch.cat(pieces)
    else:
        tensor = torch.as_tensor(residual, dtype=dtype, device=device)

    if tensor.ndim == 0:
        tensor = tensor.reshape(1)
    else:
        tensor = tensor.reshape(-1)

    if tensor.numel() == 0:
        raise ValueError("residual must contain at least one value.")
    return tensor


def _evaluate_residual(
    problem: NonlinearLeastSquaresProblem,
    x: torch.Tensor,
    original_shape: torch.Size | tuple[int, ...],
    params: Any | None,
) -> torch.Tensor:
    residual = problem.residual(_restore_state_shape(x, original_shape), params)
    return _flatten_residual(residual, dtype=x.dtype, device=x.device)


def _objective_value(
    problem: NonlinearLeastSquaresProblem,
    x: torch.Tensor,
    original_shape: torch.Size | tuple[int, ...],
    params: Any | None,
) -> torch.Tensor:
    residual = _evaluate_residual(problem, x, original_shape, params)
    loss: RobustLoss | None = getattr(problem, "loss", None)
    if loss is not None:
        return loss.value(residual).sum()
    return 0.5 * torch.dot(residual, residual)


def _collect_tensor_leaves(value: Any) -> list[torch.Tensor]:
    if isinstance(value, torch.Tensor):
        return [value]
    if isinstance(value, Mapping):
        mapping_leaves: list[torch.Tensor] = []
        for item in value.values():
            mapping_leaves.extend(_collect_tensor_leaves(item))
        return mapping_leaves
    if isinstance(value, tuple):
        tuple_leaves: list[torch.Tensor] = []
        for item in value:
            tuple_leaves.extend(_collect_tensor_leaves(item))
        return tuple_leaves
    if isinstance(value, list):
        list_leaves: list[torch.Tensor] = []
        for item in value:
            list_leaves.extend(_collect_tensor_leaves(item))
        return list_leaves
    return []


def _replace_tensor_leaves(template: Any, tensor_iter: Any) -> Any:
    if isinstance(template, torch.Tensor):
        return next(tensor_iter)
    if isinstance(template, Mapping):
        return {key: _replace_tensor_leaves(item, tensor_iter) for key, item in template.items()}
    if isinstance(template, tuple):
        return tuple(_replace_tensor_leaves(item, tensor_iter) for item in template)
    if isinstance(template, list):
        return [_replace_tensor_leaves(item, tensor_iter) for item in template]
    return template


def _as_square_matrix(matrix: torch.Tensor) -> torch.Tensor:
    if matrix.ndim == 0:
        return matrix.reshape(1, 1)
    if matrix.ndim == 1:
        return matrix.reshape(1, -1)
    return matrix


def _vector_norm(vector: torch.Tensor) -> torch.Tensor:
    return torch.norm(vector)


def _condition_estimate(matrix: torch.Tensor) -> float:
    return float(torch.linalg.cond(matrix).detach().cpu().item())


def _solve_linear_system(matrix: torch.Tensor, rhs: torch.Tensor) -> torch.Tensor:
    try:
        return torch.linalg.solve(matrix, rhs)
    except RuntimeError:
        return torch.linalg.lstsq(matrix, rhs).solution


class _ImplicitLeastSquaresSolution(torch.autograd.Function):  # type: ignore[misc]
    @staticmethod
    def forward(*inputs: Any, **kwargs: Any) -> torch.Tensor:
        if kwargs:
            raise TypeError("_ImplicitLeastSquaresSolution.forward does not accept keyword arguments")
        solution, problem, original_shape, param_template, *param_leaves = inputs
        del problem, original_shape, param_template, param_leaves
        return solution.detach().clone()

    @staticmethod
    def setup_context(ctx: Any, inputs: tuple[Any, ...], output: torch.Tensor) -> None:
        solution, problem, original_shape, param_template, *param_leaves = inputs
        detached_leaves = tuple(leaf.detach().clone() for leaf in param_leaves)
        ctx.problem = problem
        ctx.original_shape = torch.Size(original_shape)
        ctx.param_template = param_template
        ctx.param_requires_grad = tuple(bool(leaf.requires_grad) for leaf in param_leaves)
        ctx.save_for_backward(solution.detach().clone(), *detached_leaves)
        del output

    @staticmethod
    def backward(ctx: Any, *grad_outputs: torch.Tensor) -> tuple[Any, ...]:
        grad_output = grad_outputs[0]
        saved = ctx.saved_tensors
        solution = saved[0]
        saved_leaves = saved[1:]
        if not any(ctx.param_requires_grad):
            return (None, None, None, None, *(None for _ in saved_leaves))

        with torch.enable_grad():
            param_values: list[torch.Tensor] = []
            differentiable_params: list[torch.Tensor] = []
            differentiable_indices: list[int] = []
            for index, (leaf, requires_grad) in enumerate(zip(saved_leaves, ctx.param_requires_grad, strict=True)):
                detached = leaf.detach().clone()
                if requires_grad:
                    detached = detached.requires_grad_(True)
                    differentiable_params.append(detached)
                    differentiable_indices.append(index)
                param_values.append(detached)

            params = _replace_tensor_leaves(ctx.param_template, iter(param_values)) if ctx.param_template is not None else None
            x = solution.detach().clone().reshape(-1).requires_grad_(True)

            def objective_fn(flat_state: torch.Tensor) -> torch.Tensor:
                return _objective_value(ctx.problem, flat_state, ctx.original_shape, params)

            objective = objective_fn(x)
            gradient = torch.autograd.grad(objective, x, create_graph=True)[0]
            hessian = _as_square_matrix(torch.autograd.functional.hessian(objective_fn, x, vectorize=True))
            hessian = 0.5 * (hessian + hessian.transpose(-2, -1))

            rhs = grad_output.reshape(-1)
            adjoint = _solve_linear_system(hessian, rhs.unsqueeze(-1)).squeeze(-1)

            differentiable_grads = torch.autograd.grad(
                gradient,
                differentiable_params,
                grad_outputs=-adjoint,
                allow_unused=True,
            )
        leaf_grads: list[torch.Tensor | None] = [None] * len(saved_leaves)
        for index, grad in zip(differentiable_indices, differentiable_grads, strict=True):
            leaf_grads[index] = grad

        return (None, None, None, None, *leaf_grads)

    @staticmethod
    def jvp(ctx: Any, *grad_inputs: Any) -> Any:
        raise NotImplementedError("Forward-mode implicit differentiation is not implemented.")

    @staticmethod
    def vmap(info: Any, in_dims: Any, *args: Any) -> Any:
        raise NotImplementedError("vmap is not implemented for the implicit differentiation wrapper.")


def assess_implicit_least_squares(
    *,
    problem: NonlinearLeastSquaresProblem,
    x: torch.Tensor,
    params: Any | None,
    original_shape: torch.Size | tuple[int, ...],
    success: bool,
    status: SolveStatus,
    termination: TerminationReason,
    diagnosis: tuple[DiagnosisCode, ...],
    tol: float,
) -> ImplicitLeastSquaresAssessment:
    """Assess whether a least-squares result is safe for implicit differentiation."""

    detached_x = x.detach().clone()
    tensor_leaves = _collect_tensor_leaves(params)
    differentiable_leaves = [leaf for leaf in tensor_leaves if leaf.requires_grad]
    if not differentiable_leaves:
        return ImplicitLeastSquaresAssessment(
            x=detached_x,
            valid=False,
            reason="Implicit differentiation requires at least one differentiable parameter tensor.",
            diagnoses=(DiagnosisCode.DIFF_INVALID,),
            condition_estimate=None,
            linear_residual=None,
        )

    if not success or status is not SolveStatus.CONVERGED or termination not in (TerminationReason.GRADIENT_TOL, TerminationReason.STEP_TOL):
        return ImplicitLeastSquaresAssessment(
            x=detached_x,
            valid=False,
            reason="Implicit differentiation requires a certifiably converged solve result.",
            diagnoses=(DiagnosisCode.DIFF_INVALID,),
            condition_estimate=None,
            linear_residual=None,
        )

    if DiagnosisCode.STATIONARY_NONMINIMUM in diagnosis or DiagnosisCode.CONVERGENCE_UNVERIFIED in diagnosis:
        return ImplicitLeastSquaresAssessment(
            x=detached_x,
            valid=False,
            reason="Implicit differentiation is invalid because the returned point is not a certified local minimum.",
            diagnoses=(DiagnosisCode.DIFF_INVALID,),
            condition_estimate=None,
            linear_residual=None,
        )

    rebuilt_params = _replace_tensor_leaves(
        params,
        iter(leaf.detach().clone() for leaf in tensor_leaves),
    ) if params is not None else None
    x_for_checks = detached_x.reshape(-1).requires_grad_(True)

    def objective_fn(flat_state: torch.Tensor) -> torch.Tensor:
        return _objective_value(problem, flat_state, original_shape, rebuilt_params)

    try:
        objective = objective_fn(x_for_checks)
        gradient = torch.autograd.grad(objective, x_for_checks, create_graph=False)[0]
        gradient_norm = float(_vector_norm(gradient).detach().cpu().item())
        gradient_limit = max(1e-8, 10.0 * tol)
        if not math.isfinite(gradient_norm) or gradient_norm > gradient_limit:
            return ImplicitLeastSquaresAssessment(
                x=detached_x,
                valid=False,
                reason=(
                    "Implicit differentiation is invalid because the returned point is not sufficiently stationary "
                    f"(gradient norm={gradient_norm:.3e})."
                ),
                diagnoses=(DiagnosisCode.DIFF_INVALID,),
                condition_estimate=None,
                linear_residual=None,
            )

        hessian = _as_square_matrix(torch.autograd.functional.hessian(objective_fn, x_for_checks, vectorize=True))
        hessian = 0.5 * (hessian + hessian.transpose(-2, -1))
        condition_estimate = _condition_estimate(hessian)
        if not math.isfinite(condition_estimate) or condition_estimate > _IMPLICIT_CONDITION_LIMIT:
            return ImplicitLeastSquaresAssessment(
                x=detached_x,
                valid=False,
                reason=(
                    "Implicit differentiation is invalid because the terminal optimality system is ill-conditioned "
                    f"(condition={condition_estimate:.3e})."
                ),
                diagnoses=(DiagnosisCode.DIFF_INVALID,),
                condition_estimate=condition_estimate,
                linear_residual=None,
            )

        newton_step = _solve_linear_system(hessian, -gradient.unsqueeze(-1)).squeeze(-1)
        residual = hessian @ newton_step + gradient
        residual_norm = float(_vector_norm(residual).detach().cpu().item())
        residual_limit = max(1e-8, 10.0 * tol)
        if not math.isfinite(residual_norm) or residual_norm > residual_limit:
            return ImplicitLeastSquaresAssessment(
                x=detached_x,
                valid=False,
                reason=(
                    "Implicit differentiation is invalid because the terminal optimality system could not be solved "
                    f"accurately enough (residual={residual_norm:.3e})."
                ),
                diagnoses=(DiagnosisCode.DIFF_INVALID,),
                condition_estimate=condition_estimate,
                linear_residual=residual_norm,
            )
    except RuntimeError as exc:
        return ImplicitLeastSquaresAssessment(
            x=detached_x,
            valid=False,
            reason=f"Implicit differentiation is invalid because terminal certification failed: {exc}",
            diagnoses=(DiagnosisCode.DIFF_INVALID,),
            condition_estimate=None,
            linear_residual=None,
        )

    wrapped_x = _ImplicitLeastSquaresSolution.apply(detached_x, problem, tuple(torch.Size(original_shape)), params, *tensor_leaves)
    return ImplicitLeastSquaresAssessment(
        x=wrapped_x,
        valid=True,
        reason="Implicit differentiation certified the returned local minimum and attached an exact stationarity-based backward rule.",
        diagnoses=(),
        condition_estimate=condition_estimate,
        linear_residual=residual_norm,
    )