"""Trust-region step policy helpers for dense nonlinear solvers.

The current least-squares trust-region path uses a compact Gauss-Newton-style
local model. The subproblem is solved by repeatedly asking the configured
linear backend for a damped step, then checking whether that step fits inside
the active trust-region radius.

The policy is intentionally simple:

- start from the undamped Gauss-Newton system
- increase diagonal damping when the proposed step is too large or the linear
    solve fails
- accept the first step that lands inside the current radius
- if no damped step fits after a small number of adjustments, project the last
    successful step onto the trust-region boundary

This module does not decide whether a trial step should be accepted by the
outer nonlinear solver. It only produces a candidate trust-region step plus
model-side quantities such as the predicted reduction and whether the boundary
was hit. The outer solver then compares predicted and actual reduction to
decide whether to accept the trial and how to update the radius.
"""

from __future__ import annotations

from dataclasses import dataclass

import torch

from pytorch_nonlinear.linear import LinearSolveResult, LinearSolver, Linearization


def _as_success_mask(success: bool | torch.Tensor, *, like: torch.Tensor) -> torch.Tensor:
    """Normalize scalar or batched backend success into a boolean mask."""

    if isinstance(success, torch.Tensor):
        if success.ndim == 0:
            return success.to(device=like.device, dtype=torch.bool).reshape(1).expand(like.shape[0])
        return success.to(device=like.device, dtype=torch.bool)
    return torch.full((like.shape[0],), bool(success), device=like.device, dtype=torch.bool)


def _metric_as_tensor(
    value: float | torch.Tensor | None,
    batch_size: int,
    *,
    dtype: torch.dtype,
    device: torch.device,
) -> torch.Tensor:
    if value is None:
        return torch.full((batch_size,), float("nan"), dtype=dtype, device=device)
    if isinstance(value, torch.Tensor):
        tensor = value.to(dtype=dtype, device=device)
        if tensor.ndim == 0:
            return tensor.reshape(1).expand(batch_size)
        return tensor.reshape(batch_size)
    return torch.full((batch_size,), float(value), dtype=dtype, device=device)


def _scalar_metric(value: float | torch.Tensor | None) -> float | None:
    if value is None:
        return None
    if isinstance(value, torch.Tensor):
        return float(value.reshape(-1)[0].detach().cpu().item())
    return float(value)


def _positions_from_mask(mask: torch.Tensor) -> torch.Tensor:
    """Return 1D integer positions for a boolean mask."""

    return torch.nonzero(mask, as_tuple=False).flatten()


def _solve_with_condition_diagnostics(
    linear_solver: LinearSolver,
    matrix: torch.Tensor,
    rhs: torch.Tensor,
    damping: torch.Tensor,
    *,
    dtype: torch.dtype,
    device: torch.device,
) -> tuple[LinearSolveResult, torch.Tensor, torch.Tensor]:
    """Recompute diagnostics for the selected damped systems once per outcome."""

    linear_result = linear_solver.solve(
        Linearization(
            matrix=matrix,
            rhs=rhs,
            damping=damping,
            symmetric=True,
            positive_semidefinite=True,
            compute_condition_estimate=True,
        )
    )
    batch_size = int(matrix.shape[0])
    return (
        linear_result,
        _metric_as_tensor(
            linear_result.residual_norm,
            batch_size,
            dtype=dtype,
            device=device,
        ),
        _metric_as_tensor(
            linear_result.condition_estimate,
            batch_size,
            dtype=dtype,
            device=device,
        ),
    )


def _scalar_bool(value: bool | torch.Tensor) -> bool:
    if isinstance(value, torch.Tensor):
        return bool(value.reshape(-1)[0].detach().cpu().item())
    return bool(value)


def _scalarize_linear_result(result: LinearSolveResult | None) -> LinearSolveResult | None:
    if result is None:
        return None

    step = result.step.squeeze(0) if result.step is not None and result.step.ndim > 0 else result.step
    diagnosis = result.diagnosis_by_batch[0] if result.diagnosis_by_batch is not None else result.diagnosis
    return LinearSolveResult(
        success=_scalar_bool(result.success),
        step=step,
        diagnosis=diagnosis,
        diagnosis_by_batch=None,
        condition_estimate=_scalar_metric(result.condition_estimate),
        residual_norm=_scalar_metric(result.residual_norm),
        iterations=result.iterations,
        solver_name=result.solver_name,
        message=result.message,
    )


def _scalarize_subproblem_result(result: TrustRegionSubproblemResult) -> TrustRegionSubproblemResult:
    step = result.step.squeeze(0) if result.step is not None and result.step.ndim > 0 else result.step
    return TrustRegionSubproblemResult(
        success=_scalar_bool(result.success),
        step=step,
        step_norm=_scalar_metric(result.step_norm),
        damping=_scalar_metric(result.damping) or 0.0,
        predicted_reduction=_scalar_metric(result.predicted_reduction),
        boundary_hit=_scalar_bool(result.boundary_hit),
        projected=_scalar_bool(result.projected),
        linear_result=_scalarize_linear_result(result.linear_result),
        message=result.message,
    )


@dataclass(frozen=True)
class TrustRegionSubproblemResult:
    """Structured result for one trust-region subproblem solve.

    Parameters
    ----------
    success : bool
        Whether a usable trust-region step was produced.
    step : torch.Tensor | None, optional
        Computed step vector, optionally projected to the trust-region
        boundary.
    step_norm : float | None, optional
        Euclidean norm of ``step``.
    damping : float, optional
        Diagonal damping used by the inner linear solve.
    predicted_reduction : float | None, optional
        Quadratic-model reduction predicted for ``step``.
    boundary_hit : bool, optional
        Whether the returned step lies on or near the trust-region boundary.
    projected : bool, optional
        Whether the returned step was projected onto the boundary after the
        final linear solve attempt.
    linear_result : LinearSolveResult | None, optional
        Inner linear solve result used to form the step.
    message : str, optional
        Short explanation of the subproblem outcome.
    """

    success: bool | torch.Tensor
    step: torch.Tensor | None = None
    step_norm: float | torch.Tensor | None = None
    damping: float | torch.Tensor = 0.0
    predicted_reduction: float | torch.Tensor | None = None
    boundary_hit: bool | torch.Tensor = False
    projected: bool | torch.Tensor = False
    linear_result: LinearSolveResult | None = None
    message: str = ""


def _norm_as_float(vector: torch.Tensor) -> float:
    """Compute a detached Euclidean norm as a Python float."""

    return float(torch.linalg.vector_norm(vector).detach().cpu().item())


def _predicted_reduction(normal_matrix: torch.Tensor, gradient: torch.Tensor, step: torch.Tensor) -> float:
    """Evaluate the quadratic-model reduction predicted for a step."""

    predicted = -(torch.dot(gradient, step) + 0.5 * torch.dot(step, normal_matrix @ step))
    return float(predicted.detach().cpu().item())


def initial_trust_region_radius(
    normal_matrix: torch.Tensor,
    gradient: torch.Tensor,
    original_gradient: torch.Tensor,
    variable_scale: torch.Tensor,
    linear_solver: LinearSolver,
    configured_radius: float | None,
) -> float | torch.Tensor:
    """Choose an initial trust-region radius for a dense least-squares solve.

    Parameters
    ----------
    normal_matrix : torch.Tensor
        Dense Gauss-Newton normal matrix.
    gradient : torch.Tensor
        Gradient of the scaled local model used by the linear solver.
    original_gradient : torch.Tensor
        Gradient of the original least-squares objective in the original
        variable coordinates.
    variable_scale : torch.Tensor
        Positive per-variable scale factors used to map solver-space steps back
        to the original variable coordinates.
    linear_solver : LinearSolver
        Linear backend used for the local step solve.
    configured_radius : float | None
        User-provided initial radius override.

    Returns
    -------
    float
        Positive trust-region radius.
    """

    if configured_radius is not None:
        if normal_matrix.ndim > 2:
            return torch.full(
                (normal_matrix.shape[0],),
                max(float(configured_radius), 1e-12),
                dtype=normal_matrix.dtype,
                device=normal_matrix.device,
            )
        return max(float(configured_radius), 1e-12)

    reference = linear_solver.solve(
        Linearization(
            matrix=normal_matrix,
            rhs=-gradient,
            damping=0.0,
            symmetric=True,
            positive_semidefinite=True,
        )
    )
    if normal_matrix.ndim > 2:
        success_mask = _as_success_mask(reference.success, like=normal_matrix)
        gradient_norm = torch.linalg.vector_norm(original_gradient, dim=-1)
        if reference.step is not None:
            reference_norm = torch.linalg.vector_norm(variable_scale * reference.step, dim=-1)
            return torch.where(success_mask, torch.clamp(reference_norm, min=1.0), torch.clamp(gradient_norm, min=1.0))
        return torch.clamp(gradient_norm, min=1.0)

    if reference.success and reference.step is not None:
        return max(_norm_as_float(variable_scale * reference.step), 1.0)
    return max(_norm_as_float(original_gradient), 1.0)


def solve_trust_region_subproblem(
    normal_matrix: torch.Tensor,
    gradient: torch.Tensor,
    variable_scale: torch.Tensor,
    radius: float,
    linear_solver: LinearSolver,
    max_damping_adjustments: int = 8,
) -> TrustRegionSubproblemResult:
    """Solve one damped trust-region subproblem.

    Parameters
    ----------
    normal_matrix : torch.Tensor
        Dense Gauss-Newton normal matrix.
    gradient : torch.Tensor
        Gradient of the least-squares objective.
    variable_scale : torch.Tensor
        Positive per-variable scale factors used to measure step norms in the
        original variable coordinates.
    radius : float
        Active trust-region radius.
    linear_solver : LinearSolver
        Linear backend used for the dense step solve.
    max_damping_adjustments : int, optional
        Maximum number of damping updates used to fit the step inside the
        radius before projecting the final successful step.

    Returns
    -------
    TrustRegionSubproblemResult
        Structured subproblem outcome.
    """

    if normal_matrix.ndim == 2:
        if isinstance(radius, torch.Tensor):
            batched_radius = radius.to(dtype=normal_matrix.dtype, device=normal_matrix.device).reshape(1)
        else:
            batched_radius = torch.full((1,), float(radius), dtype=normal_matrix.dtype, device=normal_matrix.device)
        return _scalarize_subproblem_result(
            solve_trust_region_subproblem(
                normal_matrix=normal_matrix.unsqueeze(0),
                gradient=gradient.unsqueeze(0),
                variable_scale=variable_scale.unsqueeze(0),
                radius=batched_radius,
                linear_solver=linear_solver,
                max_damping_adjustments=max_damping_adjustments,
            )
        )

    rhs = -gradient
    batch_size = normal_matrix.shape[0]
    radius_tensor = radius if isinstance(radius, torch.Tensor) else torch.full((batch_size,), float(radius), dtype=normal_matrix.dtype, device=normal_matrix.device)
    pending_indices = torch.arange(batch_size, device=normal_matrix.device)
    pending_matrix = normal_matrix
    pending_rhs = rhs
    pending_variable_scale = variable_scale
    pending_radius = radius_tensor
    pending_damping = torch.zeros(batch_size, dtype=normal_matrix.dtype, device=normal_matrix.device)
    final_success = torch.zeros(batch_size, dtype=torch.bool, device=normal_matrix.device)
    final_step = torch.zeros_like(gradient)
    final_step_norm = torch.full((batch_size,), float("nan"), dtype=normal_matrix.dtype, device=normal_matrix.device)
    final_boundary_hit = torch.zeros(batch_size, dtype=torch.bool, device=normal_matrix.device)
    final_projected = torch.zeros(batch_size, dtype=torch.bool, device=normal_matrix.device)
    final_damping = torch.zeros(batch_size, dtype=normal_matrix.dtype, device=normal_matrix.device)
    final_linear_residual = torch.full((batch_size,), float("nan"), dtype=normal_matrix.dtype, device=normal_matrix.device)
    final_linear_condition = torch.full((batch_size,), float("nan"), dtype=normal_matrix.dtype, device=normal_matrix.device)
    last_attempt_linear_residual = torch.full((batch_size,), float("nan"), dtype=normal_matrix.dtype, device=normal_matrix.device)
    last_attempt_linear_condition = torch.full((batch_size,), float("nan"), dtype=normal_matrix.dtype, device=normal_matrix.device)
    last_success_mask = torch.zeros(batch_size, dtype=torch.bool, device=normal_matrix.device)
    last_success_step = torch.zeros_like(gradient)
    last_success_step_norm = torch.full((batch_size,), float("nan"), dtype=normal_matrix.dtype, device=normal_matrix.device)
    last_success_damping = torch.zeros(batch_size, dtype=normal_matrix.dtype, device=normal_matrix.device)
    last_success_linear_residual = torch.full((batch_size,), float("nan"), dtype=normal_matrix.dtype, device=normal_matrix.device)
    last_success_linear_condition = torch.full((batch_size,), float("nan"), dtype=normal_matrix.dtype, device=normal_matrix.device)
    last_failure: LinearSolveResult | None = None
    last_linear_result: LinearSolveResult | None = None

    for _ in range(max_damping_adjustments):
        if pending_indices.numel() == 0:
            break
        linear_result = linear_solver.solve(
            Linearization(
                matrix=pending_matrix,
                rhs=pending_rhs,
                damping=pending_damping,
                symmetric=True,
                positive_semidefinite=True,
                compute_condition_estimate=False,
            )
        )
        last_linear_result = linear_result
        pending_batch_size = int(pending_indices.shape[0])
        success_mask = _as_success_mask(
            linear_result.success,
            like=pending_matrix,
        )
        pending_linear_residual = _metric_as_tensor(
            linear_result.residual_norm,
            pending_batch_size,
            dtype=normal_matrix.dtype,
            device=normal_matrix.device,
        )
        pending_linear_condition = _metric_as_tensor(
            linear_result.condition_estimate,
            pending_batch_size,
            dtype=normal_matrix.dtype,
            device=normal_matrix.device,
        )
        last_attempt_linear_residual.index_copy_(0, pending_indices, pending_linear_residual)
        last_attempt_linear_condition.index_copy_(0, pending_indices, pending_linear_condition)
        if linear_result.step is None:
            success_mask = torch.zeros(pending_batch_size, dtype=torch.bool, device=normal_matrix.device)
        success_positions = _positions_from_mask(success_mask)
        successful_global_indices = pending_indices.index_select(0, success_positions)
        successful_count = int(successful_global_indices.shape[0])
        if successful_count == 0:
            last_failure = linear_result
            pending_damping = torch.maximum(
                torch.full_like(pending_damping, 1e-6),
                10.0 * torch.where(pending_damping > 0.0, pending_damping, torch.full_like(pending_damping, 1e-6)),
            )
            continue

        step = linear_result.step
        step_norm = torch.linalg.vector_norm(pending_variable_scale * step, dim=-1)
        if successful_count > 0:
            successful_step = step.index_select(0, success_positions)
            successful_step_norm = step_norm.index_select(0, success_positions)
            successful_damping = pending_damping.index_select(0, success_positions)
            successful_linear_residual = pending_linear_residual.index_select(0, success_positions)
            successful_linear_condition = pending_linear_condition.index_select(0, success_positions)
            last_success_mask.index_fill_(0, successful_global_indices, True)
            last_success_step.index_copy_(0, successful_global_indices, successful_step)
            last_success_step_norm.index_copy_(0, successful_global_indices, successful_step_norm)
            last_success_damping.index_copy_(0, successful_global_indices, successful_damping)
            last_success_linear_residual.index_copy_(0, successful_global_indices, successful_linear_residual)
            last_success_linear_condition.index_copy_(0, successful_global_indices, successful_linear_condition)

        interior_mask = success_mask & (step_norm <= pending_radius * (1.0 + 1e-8))
        interior_positions = _positions_from_mask(interior_mask)
        interior_global_indices = pending_indices.index_select(0, interior_positions)
        interior_count = int(interior_global_indices.shape[0])
        if interior_count > 0:
            interior_step = step.index_select(0, interior_positions)
            interior_step_norm = step_norm.index_select(0, interior_positions)
            interior_radius = pending_radius.index_select(0, interior_positions)
            interior_damping = pending_damping.index_select(0, interior_positions)
            interior_linear_residual = pending_linear_residual.index_select(0, interior_positions)
            interior_linear_condition = pending_linear_condition.index_select(0, interior_positions)
            final_success.index_fill_(0, interior_global_indices, True)
            final_step.index_copy_(0, interior_global_indices, interior_step)
            final_step_norm.index_copy_(0, interior_global_indices, interior_step_norm)
            final_boundary_hit.index_copy_(0, interior_global_indices, interior_step_norm >= 0.9 * interior_radius)
            final_projected.index_fill_(0, interior_global_indices, False)
            final_damping.index_copy_(0, interior_global_indices, interior_damping)
            final_linear_residual.index_copy_(0, interior_global_indices, interior_linear_residual)
            final_linear_condition.index_copy_(0, interior_global_indices, interior_linear_condition)

        unresolved_mask = ~interior_mask
        unresolved_positions = _positions_from_mask(unresolved_mask)
        next_pending_indices = pending_indices.index_select(0, unresolved_positions)
        next_pending_matrix = pending_matrix.index_select(0, unresolved_positions)
        next_pending_rhs = pending_rhs.index_select(0, unresolved_positions)
        next_pending_variable_scale = pending_variable_scale.index_select(0, unresolved_positions)
        next_pending_radius = pending_radius.index_select(0, unresolved_positions)
        if next_pending_indices.numel() == 0:
            pending_indices = next_pending_indices
            pending_matrix = next_pending_matrix
            pending_rhs = next_pending_rhs
            pending_variable_scale = next_pending_variable_scale
            pending_radius = next_pending_radius
            pending_damping = pending_damping.index_select(0, unresolved_positions)
            break

        unresolved_success_mask = success_mask.index_select(0, unresolved_positions)
        unresolved_success_positions = _positions_from_mask(unresolved_success_mask)
        unresolved_success_count = successful_count - interior_count
        next_damping = pending_damping.index_select(0, unresolved_positions).clone()
        if unresolved_success_count > 0:
            unresolved_step_norm = step_norm.index_select(0, unresolved_positions)
            mismatch = torch.maximum(
                unresolved_step_norm.index_select(0, unresolved_success_positions)
                / torch.clamp(next_pending_radius.index_select(0, unresolved_success_positions), min=1e-12),
                torch.ones_like(unresolved_step_norm.index_select(0, unresolved_success_positions)),
            )
            unresolved_success_damping = next_damping.index_select(0, unresolved_success_positions)
            next_damping[unresolved_success_positions] = torch.maximum(
                torch.full_like(unresolved_success_damping, 1e-6),
                mismatch
                * torch.maximum(
                    torch.full_like(unresolved_success_damping, 1e-6),
                    torch.where(
                        unresolved_success_damping > 0.0,
                        unresolved_success_damping,
                        torch.ones_like(unresolved_success_damping),
                    ),
                ),
            )
        failed_mask = ~unresolved_success_mask
        if next_pending_indices.numel() > unresolved_success_count:
            failed_positions = _positions_from_mask(failed_mask)
            failed_damping = next_damping.index_select(0, failed_positions)
            next_damping[failed_positions] = torch.maximum(
                torch.full_like(failed_damping, 1e-6),
                10.0
                * torch.where(
                    failed_damping > 0.0,
                    failed_damping,
                    torch.full_like(failed_damping, 1e-6),
                ),
            )
        pending_indices = next_pending_indices
        pending_matrix = next_pending_matrix
        pending_rhs = next_pending_rhs
        pending_variable_scale = next_pending_variable_scale
        pending_radius = next_pending_radius
        pending_damping = next_damping

    projected_indices = pending_indices[last_success_mask[pending_indices]]
    if projected_indices.numel() > 0:
        projected_step = last_success_step[projected_indices] * (
            radius_tensor[projected_indices] / torch.clamp(last_success_step_norm[projected_indices], min=1e-12)
        ).unsqueeze(-1)
        projected_norm = torch.linalg.vector_norm(
            variable_scale[projected_indices] * projected_step,
            dim=-1,
        )
        final_success.index_fill_(0, projected_indices, True)
        final_step.index_copy_(0, projected_indices, projected_step)
        final_step_norm.index_copy_(0, projected_indices, projected_norm)
        final_boundary_hit.index_fill_(0, projected_indices, True)
        final_projected.index_fill_(0, projected_indices, True)
        final_damping.index_copy_(0, projected_indices, last_success_damping.index_select(0, projected_indices))
        final_linear_residual.index_copy_(0, projected_indices, last_success_linear_residual.index_select(0, projected_indices))
        final_linear_condition.index_copy_(0, projected_indices, last_success_linear_condition.index_select(0, projected_indices))

    success_indices = torch.nonzero(final_success, as_tuple=False).flatten()
    if success_indices.numel() > 0:
        _, _, success_condition = _solve_with_condition_diagnostics(
            linear_solver,
            normal_matrix.index_select(0, success_indices),
            rhs.index_select(0, success_indices),
            final_damping.index_select(0, success_indices),
            dtype=normal_matrix.dtype,
            device=normal_matrix.device,
        )
        final_linear_condition.index_copy_(0, success_indices, success_condition)

    if pending_indices.numel() > 0:
        pending_diagnostic_result, pending_residual, pending_condition = _solve_with_condition_diagnostics(
            linear_solver,
            pending_matrix,
            pending_rhs,
            pending_damping,
            dtype=normal_matrix.dtype,
            device=normal_matrix.device,
        )
        last_attempt_linear_residual.index_copy_(0, pending_indices, pending_residual)
        last_attempt_linear_condition.index_copy_(0, pending_indices, pending_condition)
        last_failure = pending_diagnostic_result

    if success_indices.numel() > 0:
        success_step = final_step[success_indices]
        success_matrix_step = torch.einsum(
            "...ij,...j->...i",
            normal_matrix[success_indices],
            success_step,
        )
        success_predicted_reduction = -(
            torch.einsum("...i,...i->...", gradient[success_indices], success_step)
            + 0.5 * torch.einsum("...i,...i->...", success_step, success_matrix_step)
        )
        predicted_reduction = torch.full((batch_size,), float("nan"), dtype=normal_matrix.dtype, device=normal_matrix.device)
        predicted_reduction.index_copy_(0, success_indices, success_predicted_reduction)
        result_damping = torch.zeros(batch_size, dtype=normal_matrix.dtype, device=normal_matrix.device)
        result_damping.index_copy_(0, success_indices, final_damping.index_select(0, success_indices))
        if pending_indices.numel() > 0:
            result_damping.index_copy_(0, pending_indices, pending_damping)
        linear_result = LinearSolveResult(
            success=final_success,
            step=final_step,
            condition_estimate=torch.where(final_success, final_linear_condition, last_attempt_linear_condition),
            residual_norm=torch.where(final_success, final_linear_residual, last_attempt_linear_residual),
            iterations=last_linear_result.iterations if last_linear_result is not None else None,
            solver_name=last_linear_result.solver_name if last_linear_result is not None else linear_solver.name,
            message="Computed trust-region batch steps for the active radii.",
        )
        return TrustRegionSubproblemResult(
            success=final_success,
            step=final_step,
            step_norm=final_step_norm,
            damping=result_damping,
            predicted_reduction=predicted_reduction,
            boundary_hit=final_boundary_hit,
            projected=final_projected,
            linear_result=linear_result,
            message=(
                "Projected trust-region batch steps onto the active radii."
                if projected_indices.numel() > 0
                else "Computed trust-region batch steps for the active radii."
            ),
        )

    return TrustRegionSubproblemResult(
        success=torch.zeros_like(radius_tensor, dtype=torch.bool),
        damping=(
            torch.zeros(batch_size, dtype=normal_matrix.dtype, device=normal_matrix.device)
            if pending_indices.numel() == 0
            else torch.zeros(batch_size, dtype=normal_matrix.dtype, device=normal_matrix.device).index_copy(0, pending_indices, pending_damping)
        ),
        linear_result=last_failure,
        message="Trust-region subproblem solve failed.",
    )