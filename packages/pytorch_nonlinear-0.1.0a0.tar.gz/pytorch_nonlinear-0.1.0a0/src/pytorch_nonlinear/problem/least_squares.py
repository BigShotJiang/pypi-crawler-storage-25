"""Nonlinear least-squares problem definition."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable

from pytorch_nonlinear.problem.base import ProblemEvaluation, ProblemKind, ProblemMetadata


ResidualFn = Callable[[Any, Any | None], Any]


@dataclass(frozen=True)
class NonlinearLeastSquaresProblem:
    residual: ResidualFn
    bounds: Any | None = None
    loss: Any | None = None
    scaling: Any | None = None
    structure: Any | None = None
    metadata: ProblemMetadata = field(default_factory=ProblemMetadata)
    kind: ProblemKind = field(default=ProblemKind.LEAST_SQUARES, init=False)

    def validate(self) -> None:
        if not callable(self.residual):
            raise TypeError("residual must be callable")

    def evaluate(self, state: Any, params: Any | None = None) -> ProblemEvaluation:
        self.validate()
        return ProblemEvaluation(residual=self.residual(state, params))
