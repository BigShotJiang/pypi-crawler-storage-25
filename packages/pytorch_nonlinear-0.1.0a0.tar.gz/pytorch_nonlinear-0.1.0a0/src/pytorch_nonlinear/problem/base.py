"""Base problem types and evaluation records."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Mapping, Protocol


class ProblemKind(str, Enum):
    LEAST_SQUARES = "least_squares"
    SMOOTH = "smooth"
    CONSTRAINED_NLP = "constrained_nlp"


@dataclass(frozen=True)
class ProblemMetadata:
    name: str | None = None
    tags: tuple[str, ...] = ()
    extras: Mapping[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class ProblemEvaluation:
    objective_value: Any | None = None
    residual: Any | None = None
    gradient: Any | None = None
    constraint_values: Any | None = None
    jacobian_info: Any | None = None
    hvp_operator: Any | None = None
    aux: Mapping[str, Any] = field(default_factory=dict)


class Problem(Protocol):
    kind: ProblemKind
    metadata: ProblemMetadata

    def validate(self) -> None:
        """Validate the problem configuration."""

    def evaluate(self, state: Any, params: Any | None = None) -> ProblemEvaluation:
        """Evaluate the problem at the provided state."""
