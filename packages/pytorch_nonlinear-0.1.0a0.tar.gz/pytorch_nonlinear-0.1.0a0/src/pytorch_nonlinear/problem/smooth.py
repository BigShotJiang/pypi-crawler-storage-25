"""Smooth minimization problem definition."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable

from pytorch_nonlinear.problem.base import ProblemEvaluation, ProblemKind, ProblemMetadata


ObjectiveFn = Callable[[Any, Any | None], Any]


@dataclass(frozen=True)
class SmoothMinimizationProblem:
    objective: ObjectiveFn
    bounds: Any | None = None
    scaling: Any | None = None
    metadata: ProblemMetadata = field(default_factory=ProblemMetadata)
    kind: ProblemKind = field(default=ProblemKind.SMOOTH, init=False)

    def validate(self) -> None:
        if not callable(self.objective):
            raise TypeError("objective must be callable")

    def evaluate(self, state: Any, params: Any | None = None) -> ProblemEvaluation:
        self.validate()
        return ProblemEvaluation(objective_value=self.objective(state, params))
