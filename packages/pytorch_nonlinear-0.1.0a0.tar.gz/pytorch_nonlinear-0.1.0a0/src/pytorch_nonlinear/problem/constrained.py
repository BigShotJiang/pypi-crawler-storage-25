"""Constrained NLP problem definition."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable, Sequence

from pytorch_nonlinear.problem.base import ProblemEvaluation, ProblemKind, ProblemMetadata


ObjectiveFn = Callable[[Any, Any | None], Any]


@dataclass(frozen=True)
class ConstrainedNLPProblem:
    objective: ObjectiveFn
    constraints: Sequence[Any] = ()
    bounds: Any | None = None
    scaling: Any | None = None
    metadata: ProblemMetadata = field(default_factory=ProblemMetadata)
    kind: ProblemKind = field(default=ProblemKind.CONSTRAINED_NLP, init=False)

    def validate(self) -> None:
        if not callable(self.objective):
            raise TypeError("objective must be callable")
        for constraint in self.constraints:
            if hasattr(constraint, "validate"):
                constraint.validate()
        if self.bounds is not None and hasattr(self.bounds, "validate"):
            self.bounds.validate()

    def evaluate(self, state: Any, params: Any | None = None) -> ProblemEvaluation:
        self.validate()
        values = [constraint.evaluate(state, params) for constraint in self.constraints]
        return ProblemEvaluation(objective_value=self.objective(state, params), constraint_values=tuple(values))
