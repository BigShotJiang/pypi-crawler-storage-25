"""Status enums for solve results."""

from __future__ import annotations

from enum import Enum


class SolveStatus(str, Enum):
    NOT_RUN = "not_run"
    CONVERGED = "converged"
    FAILED = "failed"
    MAX_ITER_REACHED = "max_iter_reached"


class TerminationReason(str, Enum):
    NOT_RUN = "not_run"
    STEP_TOL = "step_tol"
    GRADIENT_TOL = "gradient_tol"
    MAX_ITER = "max_iter"
    NUMERICAL_FAILURE = "numerical_failure"
    INVALID_CONFIGURATION = "invalid_configuration"


class DiagnosisCode(str, Enum):
    NONE = "none"
    POOR_SCALING = "poor_scaling"
    INFEASIBLE_INITIALIZATION = "infeasible_initialization"
    RANK_DEFICIENT_JACOBIAN = "rank_deficient_jacobian"
    ILL_CONDITIONED_SYSTEM = "ill_conditioned_system"
    UNCERTIFIED_KKT_STEP = "uncertified_kkt_step"
    SKIPPED_CURVATURE_UPDATE = "skipped_curvature_update"
    STEP_REJECTED = "step_rejected"
    STATIONARY_NONMINIMUM = "stationary_nonminimum"
    CONVERGENCE_UNVERIFIED = "convergence_unverified"
    DIFF_INVALID = "diff_invalid"
