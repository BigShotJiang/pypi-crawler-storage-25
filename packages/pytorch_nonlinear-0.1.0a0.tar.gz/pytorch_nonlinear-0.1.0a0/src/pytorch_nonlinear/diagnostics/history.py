"""Iteration and trial diagnostics records."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class TrialRecord:
    """Candidate trial evaluated within one outer solver iteration.

    Parameters
    ----------
    attempt : int
        One-based index of the trial within the enclosing outer iteration.
    objective_value : Any | None, optional
        Objective value at the candidate trial state.
    step_norm : Any | None, optional
        Norm of the candidate step relative to the iteration start.
    accepted : bool, optional
        Whether this candidate became the new iterate.
    reason : str, optional
        Short machine-readable explanation for the trial outcome.
    state : Any | None, optional
        Candidate state in the user-facing shape.
    step_parameter : Any | None, optional
        Algorithm-specific scalar controlling the trial, such as LM damping or
        a future trust-region radius.
    linear_solver_iterations : int | None, optional
        Iteration count reported by the inner linear solver when iterative
        backends are used.
    linear_residual_norm : Any | None, optional
        Norm of the residual from the inner linear solve.
    linear_condition_estimate : Any | None, optional
        Condition estimate reported by the inner linear solve.
    trust_region_radius : float | None, optional
        Trust-region radius used for this trial when a trust-region method is
        active.
    trust_region_ratio : float | None, optional
        Ratio of actual to predicted reduction for this trial when available.
    """

    attempt: int
    objective_value: Any | None = None
    step_norm: Any | None = None
    accepted: bool = False
    reason: str = ""
    state: Any | None = None
    step_parameter: Any | None = None
    linear_solver_iterations: int | None = None
    linear_residual_norm: Any | None = None
    linear_condition_estimate: Any | None = None
    trust_region_radius: float | None = None
    trust_region_ratio: float | None = None


@dataclass(frozen=True)
class IterationRecord:
    """Summary of one outer solver iteration.

    Parameters
    ----------
    iteration : int
        One-based outer iteration counter.
    objective_value : Any | None, optional
        Objective value at the recorded iterate after the iteration finishes.
        If ``accepted`` is ``False``, this is the incumbent objective carried
        forward from the previous iterate.
    gradient_norm : Any | None, optional
        Gradient norm at the recorded iterate after the iteration finishes.
    constraint_violation : Any | None, optional
        Constraint violation at the recorded iterate.
    step_norm : Any | None, optional
        Norm of the accepted step for this iteration. This stays ``None`` when
        no candidate trial is accepted.
    complementarity : Any | None, optional
        Complementarity measure at the recorded iterate for interior-point
        methods.
    barrier_parameter : Any | None, optional
        Barrier parameter at the recorded iterate for interior-point methods.
    accepted : bool, optional
        Whether at least one candidate trial was accepted during the iteration.
    reason : str, optional
        Short summary of the iteration outcome.
    state : Any | None, optional
        Iterate after the iteration finishes, in the user-facing shape.
    trials : tuple[TrialRecord, ...], optional
        Candidate trials evaluated during the iteration, in execution order.
    linear_residual_norm : Any | None, optional
        Residual norm from the accepted inner linear solve, or from the last
        attempted linear solve when no trial is accepted.
    linear_condition_estimate : Any | None, optional
        Condition estimate from the accepted inner linear solve, or from the
        last attempted linear solve when no trial is accepted.
    trust_region_radius : float | None, optional
        Trust-region radius used for the accepted trial, or for the last
        attempted trial when no step is accepted.
    trust_region_ratio : float | None, optional
        Ratio of actual to predicted reduction for the accepted trial, or for
        the last attempted trial when no step is accepted.
    """

    iteration: int
    objective_value: Any | None = None
    gradient_norm: Any | None = None
    constraint_violation: Any | None = None
    step_norm: Any | None = None
    complementarity: Any | None = None
    barrier_parameter: Any | None = None
    accepted: bool = True
    reason: str = ""
    state: Any | None = None
    trials: tuple[TrialRecord, ...] = ()
    linear_residual_norm: Any | None = None
    linear_condition_estimate: Any | None = None
    trust_region_radius: float | None = None
    trust_region_ratio: float | None = None
