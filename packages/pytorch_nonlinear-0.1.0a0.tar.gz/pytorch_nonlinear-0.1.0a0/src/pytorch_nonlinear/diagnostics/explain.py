"""Human-readable explanation rendering for solve results."""

from __future__ import annotations

from typing import TYPE_CHECKING

from pytorch_nonlinear.diagnostics.status import DiagnosisCode, SolveStatus, TerminationReason

if TYPE_CHECKING:
    from pytorch_nonlinear.diagnostics.result import SolveResult


_DIAGNOSIS_GUIDANCE: dict[DiagnosisCode, str] = {
    DiagnosisCode.POOR_SCALING: "Try variable or residual scaling before changing the solver.",
    DiagnosisCode.INFEASIBLE_INITIALIZATION: "Check the initial point and constraint setup for feasibility.",
    DiagnosisCode.RANK_DEFICIENT_JACOBIAN: "Inspect the model structure or add regularization because the local linearization appears rank-deficient.",
    DiagnosisCode.ILL_CONDITIONED_SYSTEM: "Consider damping, scaling, or a more stable linear backend because the local system appears ill-conditioned.",
    DiagnosisCode.UNCERTIFIED_KKT_STEP: "The solver found only a least-squares fallback step for the constrained KKT system and could not certify it as a valid subproblem solve.",
    DiagnosisCode.SKIPPED_CURVATURE_UPDATE: "The quasi-Newton curvature update was skipped because the equality model was degenerate and multiplier-based curvature information was not trustworthy.",
    DiagnosisCode.STEP_REJECTED: "Inspect the step acceptance logic and local model quality because candidate steps are being rejected.",
    DiagnosisCode.CONVERGENCE_UNVERIFIED: "The solver reached a stationary candidate but could not certify local-minimum convergence with the configured validation budget.",
    DiagnosisCode.STATIONARY_NONMINIMUM: "The solver reached a stationary point that does not appear to be a local minimum; inspect curvature and initialization.",
    DiagnosisCode.DIFF_INVALID: "Do not trust implicit gradients at this point; use unrolled differentiation or improve convergence first.",
    DiagnosisCode.NONE: "No diagnosis was recorded.",
}


def render_explanation(result: SolveResult) -> str:
    """Render a multi-line explanation for a solve result.

    Parameters
    ----------
    result : SolveResult
        Solve result to summarize.

    Returns
    -------
    str
        Human-readable explanation covering termination, recent history, and
        differentiation validity.
    """

    lines: list[str] = []

    lines.append(f"Solve status: {result.status.value}.")

    if result.status is SolveStatus.CONVERGED:
        lines.append(f"Termination reason: {result.termination.value} after {result.num_iter} iterations.")
    elif result.status is SolveStatus.NOT_RUN:
        lines.append("The solver has not been executed yet.")
    else:
        lines.append(f"Termination reason: {result.termination.value} after {result.num_iter} iterations.")

    if result.message:
        lines.append(f"Solver message: {result.message}")

    if result.history:
        last = result.history[-1]
        lines.append(
            "Last recorded iteration: "
            f"iter={last.iteration}, accepted={last.accepted}, reason={last.reason or 'n/a'}."
        )
        if last.trials:
            last_trial = last.trials[-1]
            lines.append(
                "Last trial summary: "
                f"attempts={len(last.trials)}, accepted={last_trial.accepted}, reason={last_trial.reason or 'n/a'}."
            )
            if last_trial.linear_residual_norm is not None or last_trial.linear_condition_estimate is not None:
                lines.append(
                    "Last trial linear solve: "
                    f"residual={last_trial.linear_residual_norm}, condition={last_trial.linear_condition_estimate}."
                )
        if last.linear_residual_norm is not None or last.linear_condition_estimate is not None:
            lines.append(
                "Last iteration linear solve: "
                f"residual={last.linear_residual_norm}, condition={last.linear_condition_estimate}."
            )
        if last.complementarity is not None or last.barrier_parameter is not None:
            lines.append(
                "Last iteration interior-point metrics: "
                f"complementarity={last.complementarity}, barrier={last.barrier_parameter}."
            )

    if result.diagnosis:
        diagnosis_text = "; ".join(_DIAGNOSIS_GUIDANCE[code] for code in result.diagnosis)
        lines.append(f"Diagnosis: {diagnosis_text}")
    elif result.status is SolveStatus.CONVERGED:
        lines.append("No failure diagnosis was recorded because the solve converged.")

    if result.diff_mode_used is not None:
        validity = "valid" if result.diff_valid else "invalid"
        lines.append(f"Differentiation mode: {result.diff_mode_used} ({validity}).")
        if result.diff_reason:
            lines.append(f"Differentiation note: {result.diff_reason}")
        if result.diff_condition_estimate is not None or result.diff_linear_residual is not None:
            certification_metrics: list[str] = []
            if result.diff_linear_residual is not None:
                certification_metrics.append(f"residual={result.diff_linear_residual}")
            if result.diff_condition_estimate is not None:
                certification_metrics.append(f"condition={result.diff_condition_estimate}")
            lines.append(
                "Implicit differentiation certification: "
                + ", ".join(certification_metrics)
                + "."
            )

    if result.linear_residual_norm is not None or result.linear_condition_estimate is not None:
        lines.append(
            "Final linear solve summary: "
            f"residual={result.linear_residual_norm}, condition={result.linear_condition_estimate}."
        )

    if result.complementarity is not None or result.barrier_parameter is not None:
        lines.append(
            "Final interior-point summary: "
            f"complementarity={result.complementarity}, barrier={result.barrier_parameter}."
        )

    if result.status is SolveStatus.MAX_ITER_REACHED:
        lines.append("Next action: increase iteration budget only after checking scaling and progress per iteration.")
    elif result.termination is TerminationReason.NUMERICAL_FAILURE:
        lines.append("Next action: inspect numerical conditioning, damping, and scaling before continuing.")
    elif result.status is SolveStatus.CONVERGED:
        lines.append("Next action: use this result as the baseline for solver and gradient regression tests.")

    return "\n".join(lines)