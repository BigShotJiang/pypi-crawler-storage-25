"""Result, status, and iteration diagnostics."""

from pytorch_nonlinear.diagnostics.explain import render_explanation
from pytorch_nonlinear.diagnostics.history import IterationRecord, TrialRecord
from pytorch_nonlinear.diagnostics.result import SolveResult
from pytorch_nonlinear.diagnostics.status import DiagnosisCode, SolveStatus, TerminationReason

__all__ = ["DiagnosisCode", "IterationRecord", "SolveResult", "SolveStatus", "TerminationReason", "TrialRecord", "render_explanation"]
