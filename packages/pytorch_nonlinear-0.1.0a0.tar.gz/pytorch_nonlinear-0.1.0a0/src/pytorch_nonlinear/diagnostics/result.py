"""User-facing solve result object."""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any

from pytorch_nonlinear.diagnostics.explain import render_explanation
from pytorch_nonlinear.diagnostics.history import IterationRecord
from pytorch_nonlinear.diagnostics.status import DiagnosisCode, SolveStatus, TerminationReason


@dataclass(frozen=True)
class SolveResult:
    """Structured result returned by a solver run.

    Parameters
    ----------
    x : Any | None, optional
        Final returned state in the user-facing shape.
    success : bool, optional
        Whether the solve reached an acceptable termination condition.
    status : SolveStatus, optional
        High-level solve status.
    termination : TerminationReason, optional
        Specific termination condition reported by the solver.
    message : str, optional
        Short summary message for the solve outcome.
    num_iter : int, optional
        Number of outer iterations recorded in ``history``.
    objective_value : Any | None, optional
        Objective value at ``x``.
    gradient_norm : Any | None, optional
        Gradient norm at ``x``.
    step_norm : Any | None, optional
        Norm of the final accepted step, when available.
    constraint_violation : Any | None, optional
        Constraint violation at ``x``.
    kkt_residual : Any | None, optional
        KKT residual at ``x`` for constrained methods.
    complementarity : Any | None, optional
        Complementarity measure at ``x`` for interior-point methods.
    barrier_parameter : Any | None, optional
        Barrier parameter reported at ``x`` for interior-point methods.
    active_set : tuple[str, ...], optional
        Names of active constraints at termination.
    history : tuple[IterationRecord, ...], optional
        Outer iteration history recorded by the solver.
    diagnosis : tuple[DiagnosisCode, ...], optional
        Structured diagnoses attached to the solve outcome.
    reproducibility : dict[str, Any], optional
        Machine-readable metadata needed to reproduce the run.
    diff_mode_used : str | None, optional
        Differentiation mode selected for the solve.
    diff_valid : bool, optional
        Whether the returned differentiation data is valid.
    diff_reason : str, optional
        Explanation for differentiation validity or invalidity.
    diff_condition_estimate : Any | None, optional
        Conditioning metric for differentiation diagnostics.
    diff_linear_residual : Any | None, optional
        Residual from the linear system used by implicit differentiation.
    linear_condition_estimate : Any | None, optional
        Conditioning metric from the final accepted linear solve, or from the
        last attempted linear solve when the solve terminates unsuccessfully.
    linear_residual_norm : Any | None, optional
        Residual norm from the final accepted linear solve, or from the last
        attempted linear solve when the solve terminates unsuccessfully.
    """

    x: Any | None = None
    success: bool = False
    status: SolveStatus = SolveStatus.NOT_RUN
    termination: TerminationReason = TerminationReason.NOT_RUN
    message: str = ""
    num_iter: int = 0
    objective_value: Any | None = None
    gradient_norm: Any | None = None
    step_norm: Any | None = None
    constraint_violation: Any | None = None
    kkt_residual: Any | None = None
    complementarity: Any | None = None
    barrier_parameter: Any | None = None
    active_set: tuple[str, ...] = ()
    history: tuple[IterationRecord, ...] = ()
    diagnosis: tuple[DiagnosisCode, ...] = ()
    reproducibility: dict[str, Any] = field(default_factory=dict)
    diff_mode_used: str | None = None
    diff_valid: bool = False
    diff_reason: str = ""
    diff_condition_estimate: Any | None = None
    diff_linear_residual: Any | None = None
    linear_condition_estimate: Any | None = None
    linear_residual_norm: Any | None = None

    def to_dict(self) -> dict[str, Any]:
        """Serialize the result into nested built-in Python containers.

        Returns
        -------
        dict[str, Any]
            JSON-friendly payload built from the dataclass tree.
        """

        return asdict(self)

    def summary(self) -> str:
        """Render a one-line textual summary of the solve outcome.

        Returns
        -------
        str
            Compact summary string for logs or examples.
        """

        parts = [
            f"status={self.status.value}",
            f"termination={self.termination.value}",
            f"iterations={self.num_iter}",
        ]
        if self.message:
            parts.append(f"message={self.message}")
        if self.diagnosis:
            joined = ", ".join(code.value for code in self.diagnosis)
            parts.append(f"diagnosis={joined}")
        return " | ".join(parts)

    def explanation(self) -> str:
        """Render a richer human-readable explanation of the result.

        Returns
        -------
        str
            Multi-line explanation string.
        """

        return render_explanation(self)
