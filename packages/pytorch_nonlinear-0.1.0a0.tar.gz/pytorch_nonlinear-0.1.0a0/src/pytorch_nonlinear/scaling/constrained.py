"""Scaling helpers for dense constrained SQP local models."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import torch

from pytorch_nonlinear.api.config import ScalingConfig, ScalingMode
from pytorch_nonlinear.diagnostics import DiagnosisCode


_AUTO_SCALE_MIN = 1e-6
_AUTO_SCALE_MAX = 1e6
_AUTO_SCALE_BLEND = 0.2
_AUTO_SCALE_CHANGE_LIMIT = 10.0


@dataclass(frozen=True)
class ConstrainedSQPScaling:
    variable_scale: torch.Tensor
    constraint_scale: torch.Tensor
    variable_mode: str
    constraint_mode: str
    diagnoses: tuple[DiagnosisCode, ...] = ()
    variable_spread: float | None = None
    constraint_spread: float | None = None

    def to_metadata(self) -> dict[str, Any]:
        return {
            "variable_mode": self.variable_mode,
            "constraint_mode": self.constraint_mode,
            "variable_scale_min": float(self.variable_scale.min().detach().cpu().item()) if self.variable_scale.numel() > 0 else None,
            "variable_scale_max": float(self.variable_scale.max().detach().cpu().item()) if self.variable_scale.numel() > 0 else None,
            "constraint_scale_min": float(self.constraint_scale.min().detach().cpu().item()) if self.constraint_scale.numel() > 0 else None,
            "constraint_scale_max": float(self.constraint_scale.max().detach().cpu().item()) if self.constraint_scale.numel() > 0 else None,
            "variable_spread": self.variable_spread,
            "constraint_spread": self.constraint_spread,
        }


def _spread(values: torch.Tensor) -> float | None:
    finite = values[torch.isfinite(values)]
    positive = finite[finite > 0]
    if positive.numel() == 0:
        return None
    return float((positive.max() / positive.min()).detach().cpu().item())


def _coerce_scale(scale: Any, *, size: int, name: str, dtype: torch.dtype, device: torch.device) -> torch.Tensor:
    tensor = torch.as_tensor(scale, dtype=dtype, device=device)
    if tensor.ndim == 0:
        tensor = tensor.reshape(1).repeat(size)
    else:
        tensor = tensor.reshape(-1)
        if tensor.numel() == 1 and size != 1:
            tensor = tensor.repeat(size)

    if tensor.numel() != size:
        raise ValueError(f"{name} must have {size} entries after flattening.")
    if not torch.all(torch.isfinite(tensor)):
        raise ValueError(f"{name} must contain only finite values.")
    if not torch.all(tensor > 0):
        raise ValueError(f"{name} must contain only positive values.")
    return tensor


def _resolve_mode(mode: ScalingMode, scale: Any | None) -> ScalingMode:
    if scale is not None and mode is ScalingMode.NONE:
        return ScalingMode.MANUAL
    return mode


def _stabilize_auto_variable_scale(raw_scale: torch.Tensor, previous_scale: torch.Tensor | None) -> torch.Tensor:
    raw = torch.clamp(raw_scale, min=_AUTO_SCALE_MIN, max=_AUTO_SCALE_MAX)
    if previous_scale is None or previous_scale.shape != raw.shape:
        return raw

    previous = torch.clamp(previous_scale.to(dtype=raw.dtype, device=raw.device), min=_AUTO_SCALE_MIN, max=_AUTO_SCALE_MAX)
    lower = previous / _AUTO_SCALE_CHANGE_LIMIT
    upper = previous * _AUTO_SCALE_CHANGE_LIMIT
    limited = torch.minimum(torch.maximum(raw, lower), upper)
    blended = torch.exp(torch.lerp(torch.log(previous), torch.log(limited), _AUTO_SCALE_BLEND))
    return torch.clamp(blended, min=_AUTO_SCALE_MIN, max=_AUTO_SCALE_MAX)


def build_constrained_sqp_scaling(
    regularized_hessian: torch.Tensor,
    objective_gradient: torch.Tensor,
    constraint_jacobian: torch.Tensor,
    constraint_values: torch.Tensor,
    config: ScalingConfig,
    *,
    previous_variable_scale: torch.Tensor | None = None,
) -> ConstrainedSQPScaling:
    if regularized_hessian.ndim != 2 or regularized_hessian.shape[0] != regularized_hessian.shape[1]:
        raise ValueError("regularized_hessian must be a square dense matrix.")
    if objective_gradient.ndim != 1 or objective_gradient.shape[0] != regularized_hessian.shape[0]:
        raise ValueError("objective_gradient must match the primal dimension.")
    if constraint_jacobian.ndim != 2 or constraint_jacobian.shape[1] != regularized_hessian.shape[0]:
        raise ValueError("constraint_jacobian must have shape (num_constraints, num_variables).")
    if constraint_values.ndim != 1 or constraint_values.shape[0] != constraint_jacobian.shape[0]:
        raise ValueError("constraint_values must match the number of constraint rows.")

    dtype = objective_gradient.dtype
    device = objective_gradient.device
    variable_mode = _resolve_mode(config.variable_mode, config.variable_scale)
    constraint_mode = _resolve_mode(config.residual_mode, config.residual_scale)

    hessian_signal = torch.sqrt(torch.clamp(torch.abs(torch.diagonal(regularized_hessian)), min=1e-8))
    if constraint_jacobian.shape[0] > 0:
        column_signal = torch.norm(constraint_jacobian, dim=0)
        row_signal = torch.norm(constraint_jacobian, dim=1)
        variable_signal = torch.maximum(hessian_signal, torch.clamp(column_signal, min=1e-8))
        constraint_signal = torch.maximum(row_signal, torch.clamp(torch.abs(constraint_values), min=1e-8))
    else:
        variable_signal = hessian_signal
        constraint_signal = constraint_values.new_zeros(0)

    diagnoses: list[DiagnosisCode] = []
    if variable_mode is ScalingMode.NONE:
        variable_scale = torch.ones_like(variable_signal, dtype=dtype, device=device)
    elif variable_mode is ScalingMode.AUTO:
        variable_scale = _stabilize_auto_variable_scale(1.0 / torch.clamp(variable_signal, min=1e-8), previous_variable_scale)
    else:
        variable_scale = _coerce_scale(
            config.variable_scale,
            size=objective_gradient.numel(),
            name="scaling.variable_scale",
            dtype=dtype,
            device=device,
        )

    if constraint_mode is ScalingMode.NONE or constraint_values.numel() == 0:
        constraint_scale = torch.ones_like(constraint_values, dtype=dtype, device=device)
    elif constraint_mode is ScalingMode.AUTO:
        constraint_scale = torch.clamp(1.0 / torch.clamp(constraint_signal, min=1e-6), min=_AUTO_SCALE_MIN, max=_AUTO_SCALE_MAX)
    else:
        constraint_scale = _coerce_scale(
            config.residual_scale,
            size=constraint_values.numel(),
            name="scaling.residual_scale",
            dtype=dtype,
            device=device,
        )

    variable_spread = _spread(variable_signal) if variable_mode is ScalingMode.AUTO else None
    constraint_spread = _spread(constraint_signal) if constraint_mode is ScalingMode.AUTO else None
    if variable_mode is ScalingMode.AUTO and variable_spread is not None and variable_spread > 1e4:
        diagnoses.append(DiagnosisCode.POOR_SCALING)
    if constraint_mode is ScalingMode.AUTO and constraint_spread is not None and constraint_spread > 1e4:
        diagnoses.append(DiagnosisCode.POOR_SCALING)

    return ConstrainedSQPScaling(
        variable_scale=variable_scale,
        constraint_scale=constraint_scale,
        variable_mode=variable_mode.value,
        constraint_mode=constraint_mode.value,
        diagnoses=tuple(dict.fromkeys(diagnoses)),
        variable_spread=variable_spread,
        constraint_spread=constraint_spread,
    )


def apply_constrained_sqp_scaling(
    regularized_hessian: torch.Tensor,
    objective_gradient: torch.Tensor,
    constraint_jacobian: torch.Tensor,
    constraint_values: torch.Tensor,
    scaling: ConstrainedSQPScaling,
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
    scaled_hessian = regularized_hessian * scaling.variable_scale.unsqueeze(0) * scaling.variable_scale.unsqueeze(1)
    scaled_gradient = objective_gradient * scaling.variable_scale
    if constraint_jacobian.shape[0] == 0:
        return scaled_hessian, scaled_gradient, constraint_jacobian, constraint_values

    scaled_jacobian = constraint_jacobian * scaling.constraint_scale.unsqueeze(-1) * scaling.variable_scale.unsqueeze(0)
    scaled_values = constraint_values * scaling.constraint_scale
    return scaled_hessian, scaled_gradient, scaled_jacobian, scaled_values