"""Scaling helpers for dense interior-point KKT systems."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import torch

from pytorch_nonlinear.api.config import ScalingConfig, ScalingMode
from pytorch_nonlinear.diagnostics import DiagnosisCode


_AUTO_SCALE_MIN = 1e-6
_AUTO_SCALE_MAX = 1e6
_AUTO_SCALE_BLEND = 0.2
_AUTO_SCALE_CHANGE_LIMIT = 10.0


@dataclass(frozen=True)
class InteriorPointKKTScaling:
    """Diagonal scaling data for the reduced interior-point KKT system.

    Attributes
    ----------
    variable_scale : torch.Tensor
        Diagonal congruence scale applied to primal variables.
    equality_scale : torch.Tensor
        Row scale applied to equality residuals and Jacobian rows.
    inequality_scale : torch.Tensor
        Row scale applied to inequality residuals and Jacobian rows.
    variable_mode : str
        Effective variable-scaling mode used for this iteration.
    equality_mode : str
        Effective equality-row scaling mode used for this iteration.
    inequality_mode : str
        Effective inequality-row scaling mode used for this iteration.
    diagnoses : tuple[DiagnosisCode, ...], default=()
        Scaling-related diagnoses raised while constructing the model.
    variable_spread : float | None, default=None
        Spread of the primal scaling signal before stabilization.
    equality_spread : float | None, default=None
        Spread of the equality-row signal before stabilization.
    inequality_spread : float | None, default=None
        Spread of the inequality-row signal before stabilization.
    """

    variable_scale: torch.Tensor
    equality_scale: torch.Tensor
    inequality_scale: torch.Tensor
    variable_mode: str
    equality_mode: str
    inequality_mode: str
    diagnoses: tuple[DiagnosisCode, ...] = ()
    variable_spread: float | None = None
    equality_spread: float | None = None
    inequality_spread: float | None = None

    def to_metadata(self) -> dict[str, Any]:
        return {
            "variable_mode": self.variable_mode,
            "equality_mode": self.equality_mode,
            "inequality_mode": self.inequality_mode,
            "variable_scale_min": float(self.variable_scale.min().detach().cpu().item()) if self.variable_scale.numel() > 0 else None,
            "variable_scale_max": float(self.variable_scale.max().detach().cpu().item()) if self.variable_scale.numel() > 0 else None,
            "equality_scale_min": float(self.equality_scale.min().detach().cpu().item()) if self.equality_scale.numel() > 0 else None,
            "equality_scale_max": float(self.equality_scale.max().detach().cpu().item()) if self.equality_scale.numel() > 0 else None,
            "inequality_scale_min": float(self.inequality_scale.min().detach().cpu().item()) if self.inequality_scale.numel() > 0 else None,
            "inequality_scale_max": float(self.inequality_scale.max().detach().cpu().item()) if self.inequality_scale.numel() > 0 else None,
            "variable_spread": self.variable_spread,
            "equality_spread": self.equality_spread,
            "inequality_spread": self.inequality_spread,
        }


@dataclass(frozen=True)
class ScaledInteriorPointKKTSystem:
    """Scaled reduced KKT matrix together with one already-scaled RHS.

    Attributes
    ----------
    system : torch.Tensor
        Scaled reduced KKT matrix.
    rhs : torch.Tensor
        Right-hand side after applying the same diagonal scaling.
    scaling : InteriorPointKKTScaling
        Scaling metadata used to build ``system`` and ``rhs``.
    """

    system: torch.Tensor
    rhs: torch.Tensor
    scaling: InteriorPointKKTScaling


@dataclass(frozen=True)
class ScaledInteriorPointKKTModel:
    """Scaled reduced KKT matrix without a bound right-hand side.

    Attributes
    ----------
    system : torch.Tensor
        Scaled reduced KKT matrix.
    scaling : InteriorPointKKTScaling
        Scaling metadata used to build ``system``.
    """

    system: torch.Tensor
    scaling: InteriorPointKKTScaling


def _spread(values: torch.Tensor) -> float | None:
    finite = values[torch.isfinite(values)]
    positive = finite[finite > 0]
    if positive.numel() == 0:
        return None
    return float((positive.max() / positive.min()).detach().cpu().item())


def _coerce_scale(scale: Any, *, size: int, name: str, dtype: torch.dtype, device: torch.device) -> torch.Tensor:
    tensor = torch.as_tensor(scale, dtype=dtype, device=device)
    if tensor.ndim == 0:
        tensor = tensor.reshape(1).repeat(size)
    else:
        tensor = tensor.reshape(-1)
        if tensor.numel() == 1 and size != 1:
            tensor = tensor.repeat(size)
    if tensor.numel() != size:
        raise ValueError(f"{name} must have {size} entries after flattening.")
    if not torch.all(torch.isfinite(tensor)):
        raise ValueError(f"{name} must contain only finite values.")
    if not torch.all(tensor > 0):
        raise ValueError(f"{name} must contain only positive values.")
    return tensor


def _resolve_mode(mode: ScalingMode, scale: Any | None) -> ScalingMode:
    if scale is not None and mode is ScalingMode.NONE:
        return ScalingMode.MANUAL
    return mode


def _stabilize_auto_variable_scale(raw_scale: torch.Tensor, previous_scale: torch.Tensor | None) -> torch.Tensor:
    raw = torch.clamp(raw_scale, min=_AUTO_SCALE_MIN, max=_AUTO_SCALE_MAX)
    if previous_scale is None or previous_scale.shape != raw.shape:
        return raw
    previous = torch.clamp(previous_scale.to(dtype=raw.dtype, device=raw.device), min=_AUTO_SCALE_MIN, max=_AUTO_SCALE_MAX)
    lower = previous / _AUTO_SCALE_CHANGE_LIMIT
    upper = previous * _AUTO_SCALE_CHANGE_LIMIT
    limited = torch.minimum(torch.maximum(raw, lower), upper)
    # Lagged logarithmic blending prevents the scaling metric from thrashing
    # between accepted iterations while still tracking order-of-magnitude drift.
    blended = torch.exp(torch.lerp(torch.log(previous), torch.log(limited), _AUTO_SCALE_BLEND))
    return torch.clamp(blended, min=_AUTO_SCALE_MIN, max=_AUTO_SCALE_MAX)


def _auto_row_scale(signal: torch.Tensor) -> torch.Tensor:
    if signal.numel() == 0:
        return signal.new_zeros(0)
    return torch.clamp(1.0 / torch.clamp(signal, min=1e-6), min=_AUTO_SCALE_MIN, max=_AUTO_SCALE_MAX)


def _resolve_residual_scales(
    config: ScalingConfig,
    *,
    equality_count: int,
    inequality_count: int,
    dtype: torch.dtype,
    device: torch.device,
) -> tuple[torch.Tensor, torch.Tensor]:
    total = equality_count + inequality_count
    if total == 0:
        empty = torch.ones(0, dtype=dtype, device=device)
        return empty, empty
    if config.residual_scale is None:
        raise ValueError("Manual residual scaling requires scaling.residual_scale to be provided.")
    residual_scale = _coerce_scale(
        config.residual_scale,
        size=total,
        name="scaling.residual_scale",
        dtype=dtype,
        device=device,
    )
    equality_scale = residual_scale[:equality_count] if equality_count > 0 else torch.ones(0, dtype=dtype, device=device)
    inequality_scale = residual_scale[equality_count:] if inequality_count > 0 else torch.ones(0, dtype=dtype, device=device)
    return equality_scale, inequality_scale


def build_interior_point_kkt_scaling(
    augmented_hessian: torch.Tensor,
    equality_jacobian: torch.Tensor,
    inequality_jacobian: torch.Tensor,
    config: ScalingConfig,
    *,
    previous_variable_scale: torch.Tensor | None = None,
) -> InteriorPointKKTScaling:
    """Build diagonal scaling for the reduced interior-point KKT system.

    Parameters
    ----------
    augmented_hessian : torch.Tensor
        Reduced primal block of the current KKT model.
    equality_jacobian : torch.Tensor
        Equality Jacobian.
    inequality_jacobian : torch.Tensor
        Stacked inequality Jacobian.
    config : ScalingConfig
        User scaling configuration.
    previous_variable_scale : torch.Tensor | None, default=None
        Previous accepted variable scale used to stabilize auto scaling.

    Returns
    -------
    InteriorPointKKTScaling
        Diagonal scaling data and any scaling-related diagnoses.
    """

    dtype = augmented_hessian.dtype
    device = augmented_hessian.device
    variable_mode = _resolve_mode(config.variable_mode, config.variable_scale)
    row_mode = _resolve_mode(config.residual_mode, config.residual_scale)

    hessian_signal = torch.sqrt(torch.clamp(torch.abs(torch.diagonal(augmented_hessian)), min=1e-8))
    equality_column_signal = torch.norm(equality_jacobian, dim=0) if equality_jacobian.shape[0] > 0 else torch.zeros_like(hessian_signal)
    inequality_column_signal = torch.norm(inequality_jacobian, dim=0) if inequality_jacobian.shape[0] > 0 else torch.zeros_like(hessian_signal)
    # The primal signal approximates local curvature or coupling strength so the
    # congruence scale equalizes the reduced KKT system without changing the NLP.
    variable_signal = torch.maximum(hessian_signal, torch.maximum(equality_column_signal, torch.clamp(inequality_column_signal, min=1e-8)))
    equality_signal = torch.norm(equality_jacobian, dim=1) if equality_jacobian.shape[0] > 0 else equality_jacobian.new_zeros(0)
    inequality_signal = torch.norm(inequality_jacobian, dim=1) if inequality_jacobian.shape[0] > 0 else inequality_jacobian.new_zeros(0)

    diagnoses: list[DiagnosisCode] = []
    if variable_mode is ScalingMode.NONE:
        variable_scale = torch.ones_like(variable_signal, dtype=dtype, device=device)
    elif variable_mode is ScalingMode.AUTO:
        variable_scale = _stabilize_auto_variable_scale(1.0 / torch.clamp(variable_signal, min=1e-8), previous_variable_scale)
    else:
        if config.variable_scale is None:
            raise ValueError("Manual variable scaling requires scaling.variable_scale to be provided.")
        variable_scale = _coerce_scale(
            config.variable_scale,
            size=augmented_hessian.shape[0],
            name="scaling.variable_scale",
            dtype=dtype,
            device=device,
        )

    if row_mode is ScalingMode.NONE:
        equality_scale = torch.ones_like(equality_signal, dtype=dtype, device=device)
        inequality_scale = torch.ones_like(inequality_signal, dtype=dtype, device=device)
    elif row_mode is ScalingMode.AUTO:
        equality_scale = _auto_row_scale(torch.clamp(equality_signal, min=1e-8))
        inequality_scale = _auto_row_scale(torch.clamp(inequality_signal, min=1e-8))
    else:
        equality_scale, inequality_scale = _resolve_residual_scales(
            config,
            equality_count=equality_signal.numel(),
            inequality_count=inequality_signal.numel(),
            dtype=dtype,
            device=device,
        )

    variable_spread = _spread(variable_signal) if variable_mode is ScalingMode.AUTO else None
    equality_spread = _spread(equality_signal) if row_mode is ScalingMode.AUTO else None
    inequality_spread = _spread(inequality_signal) if row_mode is ScalingMode.AUTO else None
    for spread in (variable_spread, equality_spread, inequality_spread):
        if spread is not None and spread > 1e4:
            diagnoses.append(DiagnosisCode.POOR_SCALING)

    return InteriorPointKKTScaling(
        variable_scale=variable_scale,
        equality_scale=equality_scale,
        inequality_scale=inequality_scale,
        variable_mode=variable_mode.value,
        equality_mode=row_mode.value,
        inequality_mode=row_mode.value,
        diagnoses=tuple(dict.fromkeys(diagnoses)),
        variable_spread=variable_spread,
        equality_spread=equality_spread,
        inequality_spread=inequality_spread,
    )


def build_scaled_interior_point_kkt_system(
    augmented_hessian: torch.Tensor,
    equality_jacobian: torch.Tensor,
    inequality_jacobian: torch.Tensor,
    primal_rhs: torch.Tensor,
    equality_rhs: torch.Tensor,
    config: ScalingConfig,
    *,
    previous_variable_scale: torch.Tensor | None = None,
) -> ScaledInteriorPointKKTSystem:
    """Build a scaled reduced KKT matrix together with one scaled RHS.

    Returns
    -------
    ScaledInteriorPointKKTSystem
        Reduced KKT system after applying the current diagonal scaling.
    """

    model = build_scaled_interior_point_kkt_model(
        augmented_hessian,
        equality_jacobian,
        inequality_jacobian,
        config,
        previous_variable_scale=previous_variable_scale,
    )
    rhs = scale_interior_point_kkt_rhs(
        primal_rhs,
        equality_rhs,
        scaling=model.scaling,
    )
    return ScaledInteriorPointKKTSystem(system=model.system, rhs=rhs, scaling=model.scaling)


def build_scaled_interior_point_kkt_model(
    augmented_hessian: torch.Tensor,
    equality_jacobian: torch.Tensor,
    inequality_jacobian: torch.Tensor,
    config: ScalingConfig,
    *,
    previous_variable_scale: torch.Tensor | None = None,
) -> ScaledInteriorPointKKTModel:
    """Build the scaled reduced KKT matrix shared by affine and corrector solves.

    Parameters
    ----------
    augmented_hessian : torch.Tensor
        Reduced primal block of the current KKT model.
    equality_jacobian : torch.Tensor
        Equality Jacobian.
    inequality_jacobian : torch.Tensor
        Stacked inequality Jacobian.
    config : ScalingConfig
        User scaling configuration.
    previous_variable_scale : torch.Tensor | None, default=None
        Previous accepted variable scale used to stabilize auto scaling.

    Returns
    -------
    ScaledInteriorPointKKTModel
        Scaled KKT matrix and the scaling metadata that produced it.
    """

    scaling = build_interior_point_kkt_scaling(
        augmented_hessian,
        equality_jacobian,
        inequality_jacobian,
        config,
        previous_variable_scale=previous_variable_scale,
    )
    # Diagonal congruence preserves the symmetric-indefinite KKT structure while
    # improving the numeric range seen by the dense linear solver.
    scaled_hessian = augmented_hessian * scaling.variable_scale.unsqueeze(0) * scaling.variable_scale.unsqueeze(1)
    if equality_jacobian.shape[0] == 0:
        return ScaledInteriorPointKKTModel(system=scaled_hessian, scaling=scaling)

    scaled_jacobian = equality_jacobian * scaling.equality_scale.unsqueeze(-1) * scaling.variable_scale.unsqueeze(0)
    zeros = scaled_hessian.new_zeros((equality_jacobian.shape[0], equality_jacobian.shape[0]))
    system = torch.cat(
        (
            torch.cat((scaled_hessian, scaled_jacobian.transpose(-2, -1)), dim=1),
            torch.cat((scaled_jacobian, zeros), dim=1),
        ),
        dim=0,
    )
    return ScaledInteriorPointKKTModel(system=system, scaling=scaling)


def scale_interior_point_kkt_rhs(
    primal_rhs: torch.Tensor,
    equality_rhs: torch.Tensor,
    *,
    scaling: InteriorPointKKTScaling,
) -> torch.Tensor:
    """Apply KKT scaling to a reduced-system right-hand side.

    Returns
    -------
    torch.Tensor
        Right-hand side in the same scaled coordinates as the KKT matrix.
    """

    scaled_primal_rhs = primal_rhs * scaling.variable_scale
    if equality_rhs.numel() == 0:
        return scaled_primal_rhs
    scaled_equality_rhs = equality_rhs * scaling.equality_scale
    return torch.cat((scaled_primal_rhs, scaled_equality_rhs), dim=0)


def unscale_interior_point_kkt_step(step: torch.Tensor, scaling: InteriorPointKKTScaling, *, equality_count: int) -> torch.Tensor:
    """Map a scaled reduced-system step back to the original coordinates.

    Parameters
    ----------
    step : torch.Tensor
        Step in scaled KKT coordinates.
    scaling : InteriorPointKKTScaling
        Diagonal scaling used for the solve.
    equality_count : int
        Number of equality-dual entries appended after the primal block.

    Returns
    -------
    torch.Tensor
        Step in the original primal and equality-dual coordinates.
    """

    if equality_count == 0:
        return step * scaling.variable_scale
    primal_count = scaling.variable_scale.numel()
    primal_step = step[:primal_count] * scaling.variable_scale
    equality_step = step[primal_count:] * scaling.equality_scale
    return torch.cat((primal_step, equality_step), dim=0)