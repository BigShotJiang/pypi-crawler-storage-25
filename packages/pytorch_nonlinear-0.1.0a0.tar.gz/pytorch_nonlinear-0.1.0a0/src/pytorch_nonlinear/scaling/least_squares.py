"""Scaling helpers for dense least-squares local models.

The scaling logic in this module is intentionally narrow. It only rescales the
local linearized model used to compute a step. The user-facing objective,
history objective values, and acceptance tests remain based on the original
least-squares problem.

This gives the solver a simple stabilization tool without changing the public
problem definition:

- variable scaling rescales local model columns
- residual scaling rescales local model rows
- automatic variable scaling uses lagged Jacobian-column norms so the local
    metric changes smoothly across accepted iterations
- automatic scaling uses cheap magnitude heuristics from the current residual
  and Jacobian
- poor scaling diagnostics are raised when the raw spreads are large enough to
  be worth surfacing to the user
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import torch

from pytorch_nonlinear.api.config import ScalingConfig, ScalingMode
from pytorch_nonlinear.diagnostics import DiagnosisCode


_AUTO_SCALE_MIN = 1e-6
_AUTO_SCALE_MAX = 1e6
_AUTO_SCALE_BLEND = 0.2
_AUTO_SCALE_CHANGE_LIMIT = 10.0


@dataclass(frozen=True)
class LeastSquaresScaling:
    """Scaling data for one dense least-squares local model.

    Parameters
    ----------
    variable_scale : torch.Tensor
        Positive scale factors applied to parameter directions.
    residual_scale : torch.Tensor
        Positive scale factors applied to residual rows.
    variable_mode : str
        Effective variable scaling mode used for this model.
    residual_mode : str
        Effective residual scaling mode used for this model.
    diagnoses : tuple[DiagnosisCode, ...], optional
        Scaling-related diagnoses raised for this local model.
    variable_spread : float | None, optional
        Spread of the raw variable scaling signal before scaling is applied.
    residual_spread : float | None, optional
        Spread of the raw residual scaling signal before scaling is applied.
    """

    variable_scale: torch.Tensor
    residual_scale: torch.Tensor
    variable_mode: str
    residual_mode: str
    diagnoses: tuple[DiagnosisCode, ...] = ()
    variable_spread: float | None = None
    residual_spread: float | None = None

    def to_metadata(self) -> dict[str, Any]:
        """Serialize scaling details for reproducibility metadata.

        Returns
        -------
        dict[str, Any]
            JSON-friendly scaling metadata.
        """

        return {
            "variable_mode": self.variable_mode,
            "residual_mode": self.residual_mode,
            "variable_scale_min": float(self.variable_scale.min().detach().cpu().item()),
            "variable_scale_max": float(self.variable_scale.max().detach().cpu().item()),
            "residual_scale_min": float(self.residual_scale.min().detach().cpu().item()),
            "residual_scale_max": float(self.residual_scale.max().detach().cpu().item()),
            "variable_spread": self.variable_spread,
            "residual_spread": self.residual_spread,
        }


@dataclass(frozen=True)
class ScaledLeastSquaresLinearModel:
    """Scaled dense least-squares local model.

    Parameters
    ----------
    residual : torch.Tensor
        Residual vector used in the local model.
    jacobian : torch.Tensor
        Jacobian matrix after parameter-direction scaling.
    gradient : torch.Tensor
        Gradient of the scaled quadratic model.
    normal_matrix : torch.Tensor
        Gauss-Newton normal matrix built from the scaled Jacobian.
    scaling : LeastSquaresScaling
        Scaling data used to form the model.
    """

    residual: torch.Tensor
    jacobian: torch.Tensor
    gradient: torch.Tensor
    normal_matrix: torch.Tensor
    scaling: LeastSquaresScaling


def _spread(values: torch.Tensor) -> float | None:
    """Return the positive spread of a magnitude vector or batch of vectors."""

    if values.ndim <= 1:
        finite = values[torch.isfinite(values)]
        positive = finite[finite > 0]
        if positive.numel() == 0:
            return None
        return float((positive.max() / positive.min()).detach().cpu().item())

    flattened = values.reshape(-1, values.shape[-1])
    positive_finite = torch.isfinite(flattened) & (flattened > 0)
    if not torch.any(positive_finite):
        return None

    positive_values = torch.where(positive_finite, flattened, torch.full_like(flattened, float("inf")))
    row_min = positive_values.min(dim=-1).values
    valid_rows = torch.isfinite(row_min)
    if not torch.any(valid_rows):
        return None

    row_max = torch.where(positive_finite, flattened, torch.zeros_like(flattened)).max(dim=-1).values
    spreads = row_max[valid_rows] / row_min[valid_rows]
    return float(spreads.max().detach().cpu().item())


def _coerce_scale(
    scale: Any,
    *,
    size: int,
    name: str,
    dtype: torch.dtype,
    device: torch.device,
    batch_shape: tuple[int, ...] = (),
) -> torch.Tensor:
    """Convert a user-provided scale into a validated dense vector."""

    tensor = torch.as_tensor(scale, dtype=dtype, device=device)
    expected_shape = batch_shape + (size,)

    if tensor.ndim == 0:
        tensor = tensor.reshape(1).repeat(size)

    if not batch_shape:
        tensor = tensor.reshape(-1)
        if tensor.numel() == 1 and size != 1:
            tensor = tensor.repeat(size)
        if tensor.numel() != size:
            raise ValueError(f"{name} must have {size} entries after flattening.")
    else:
        if tuple(tensor.shape) == expected_shape:
            pass
        elif tensor.numel() == 1:
            tensor = tensor.reshape(1).repeat(*batch_shape, size)
        elif tensor.ndim == 1 and tensor.numel() == size:
            tensor = tensor.reshape((1,) * len(batch_shape) + (size,)).expand(expected_shape)
        else:
            raise ValueError(f"{name} must have shape {expected_shape} or ({size},).")

    if not torch.all(torch.isfinite(tensor)):
        raise ValueError(f"{name} must contain only finite values.")
    if not torch.all(tensor > 0):
        raise ValueError(f"{name} must contain only positive values.")
    return tensor


def _resolve_mode(mode: ScalingMode, scale: Any | None) -> ScalingMode:
    """Resolve the effective scaling mode for one scaling channel."""

    if scale is not None and mode is ScalingMode.NONE:
        return ScalingMode.MANUAL
    return mode


def _stabilize_auto_variable_scale(raw_scale: torch.Tensor, previous_scale: torch.Tensor | None) -> torch.Tensor:
    """Lag and bound automatic variable scaling updates across iterations."""

    raw = torch.clamp(raw_scale, min=_AUTO_SCALE_MIN, max=_AUTO_SCALE_MAX)
    if previous_scale is None or previous_scale.shape != raw.shape:
        return raw

    previous = torch.clamp(previous_scale.to(dtype=raw.dtype, device=raw.device), min=_AUTO_SCALE_MIN, max=_AUTO_SCALE_MAX)
    lower = previous / _AUTO_SCALE_CHANGE_LIMIT
    upper = previous * _AUTO_SCALE_CHANGE_LIMIT
    limited = torch.minimum(torch.maximum(raw, lower), upper)
    blended = torch.exp(torch.lerp(torch.log(previous), torch.log(limited), _AUTO_SCALE_BLEND))
    return torch.clamp(blended, min=_AUTO_SCALE_MIN, max=_AUTO_SCALE_MAX)


def build_least_squares_scaling(
    residual: torch.Tensor,
    jacobian: torch.Tensor,
    config: ScalingConfig,
    previous_variable_scale: torch.Tensor | None = None,
) -> LeastSquaresScaling:
    """Build scaling information for one dense least-squares local model.

    Parameters
    ----------
    residual : torch.Tensor
        Unscaled residual vector.
    jacobian : torch.Tensor
        Unscaled dense Jacobian matrix.
    config : ScalingConfig
        User scaling configuration.
    previous_variable_scale : torch.Tensor | None, optional
        Previous accepted automatic variable scale used to stabilize updates.

    Returns
    -------
    LeastSquaresScaling
        Scaling data for the current local model.
    """

    if residual.ndim + 1 != jacobian.ndim:
        raise ValueError(
            "jacobian must have exactly one more dimension than residual, shaped like (..., num_residuals, num_parameters)."
        )
    if tuple(jacobian.shape[:-1]) != tuple(residual.shape):
        raise ValueError(
            "residual and jacobian must share the same leading batch dimensions and residual dimension."
        )

    dtype = residual.dtype
    device = residual.device
    batch_shape = tuple(int(dim) for dim in residual.shape[:-1])
    variable_mode = _resolve_mode(config.variable_mode, config.variable_scale)
    residual_mode = _resolve_mode(config.residual_mode, config.residual_scale)
    variable_signal = torch.linalg.vector_norm(jacobian, dim=-2)
    residual_signal = residual.abs()
    diagnoses: list[DiagnosisCode] = []

    if variable_mode is ScalingMode.NONE:
        variable_scale = torch.ones_like(variable_signal, dtype=dtype, device=device)
    elif variable_mode is ScalingMode.AUTO:
        raw_variable_scale = 1.0 / torch.clamp(variable_signal, min=1e-8)
        variable_scale = _stabilize_auto_variable_scale(raw_variable_scale, previous_variable_scale)
    else:
        variable_scale = _coerce_scale(
            config.variable_scale,
            size=jacobian.shape[-1],
            name="scaling.variable_scale",
            dtype=dtype,
            device=device,
            batch_shape=batch_shape,
        )

    if residual_mode is ScalingMode.NONE:
        residual_scale = torch.ones_like(residual_signal, dtype=dtype, device=device)
    elif residual_mode is ScalingMode.AUTO:
        residual_scale = torch.clamp(1.0 / torch.clamp(residual_signal, min=1e-6), min=_AUTO_SCALE_MIN, max=_AUTO_SCALE_MAX)
    else:
        residual_scale = _coerce_scale(
            config.residual_scale,
            size=residual.shape[-1],
            name="scaling.residual_scale",
            dtype=dtype,
            device=device,
            batch_shape=batch_shape,
        )

    variable_spread = None
    residual_spread = None
    if variable_mode is ScalingMode.AUTO:
        variable_spread = _spread(torch.clamp(variable_signal, min=1e-12))
    if residual_mode is ScalingMode.AUTO:
        residual_spread = _spread(torch.clamp(residual_signal, min=1e-12))

    if variable_mode is ScalingMode.AUTO and variable_spread is not None and variable_spread > 1e4:
        diagnoses.append(DiagnosisCode.POOR_SCALING)
    if residual_mode is ScalingMode.AUTO and residual_spread is not None and residual_spread > 1e4:
        diagnoses.append(DiagnosisCode.POOR_SCALING)

    return LeastSquaresScaling(
        variable_scale=variable_scale,
        residual_scale=residual_scale,
        variable_mode=variable_mode.value,
        residual_mode=residual_mode.value,
        diagnoses=tuple(dict.fromkeys(diagnoses)),
        variable_spread=variable_spread,
        residual_spread=residual_spread,
    )


def build_scaled_least_squares_linear_model(
    residual: torch.Tensor,
    jacobian: torch.Tensor,
    scaling: LeastSquaresScaling,
) -> ScaledLeastSquaresLinearModel:
    """Build the scaled dense least-squares linear model.

    Parameters
    ----------
    residual : torch.Tensor
        Unscaled residual vector.
    jacobian : torch.Tensor
        Unscaled dense Jacobian matrix.
    scaling : LeastSquaresScaling
        Scaling data used to transform the local model.

    Returns
    -------
    ScaledLeastSquaresLinearModel
        Scaled local model used to compute the next step.
    """

    scaled_residual = residual * scaling.residual_scale
    scaled_jacobian = jacobian * scaling.residual_scale.unsqueeze(-1) * scaling.variable_scale.unsqueeze(-2)
    scaled_gradient = torch.einsum("...mn,...m->...n", scaled_jacobian, scaled_residual)
    scaled_normal_matrix = torch.einsum("...mi,...mj->...ij", scaled_jacobian, scaled_jacobian)

    return ScaledLeastSquaresLinearModel(
        residual=scaled_residual,
        jacobian=scaled_jacobian,
        gradient=scaled_gradient,
        normal_matrix=scaled_normal_matrix,
        scaling=scaling,
    )