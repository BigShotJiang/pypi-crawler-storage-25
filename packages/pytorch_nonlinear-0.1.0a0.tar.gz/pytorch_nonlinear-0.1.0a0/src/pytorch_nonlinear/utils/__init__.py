"""Utility helpers shared across solver subsystems."""

from pytorch_nonlinear.utils.device import move_to_device, resolve_requested_device

__all__ = ["move_to_device", "resolve_requested_device"]
