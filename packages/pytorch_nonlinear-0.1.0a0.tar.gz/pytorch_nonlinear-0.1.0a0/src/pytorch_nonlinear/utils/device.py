"""Device placement helpers for solver execution.

The helpers in this module keep device policy explicit and localized so solver
implementations do not grow ad hoc CPU/GPU transfer logic.
"""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from typing import Any

import torch


def resolve_requested_device(requested_device: str | torch.device | None) -> torch.device | None:
    """Resolve and validate an optional requested execution device.

    Parameters
    ----------
    requested_device : str | torch.device | None
        Requested device value from configuration.

    Returns
    -------
    torch.device | None
        Normalized device object, or ``None`` when no explicit device was
        requested.

    Raises
    ------
    ValueError
        If the requested device string is invalid or requests CUDA when CUDA is
        unavailable.
    """

    if requested_device is None:
        return None

    try:
        device = torch.device(requested_device)
    except (TypeError, RuntimeError) as exc:
        raise ValueError(f"Invalid device specification: {requested_device!r}.") from exc

    if device.type == "cuda" and not torch.cuda.is_available():
        raise ValueError("CUDA was requested but is not available in the current environment.")

    return device


def move_to_device(value: Any, device: torch.device) -> Any:
    """Move a nested value onto the requested device.

    Parameters
    ----------
    value : Any
        Tensor-like value, or nested mapping/sequence of tensor-like values.
    device : torch.device
        Target device.

    Returns
    -------
    Any
        Value moved onto ``device`` while preserving basic Python container
        structure.
    """

    if isinstance(value, torch.Tensor):
        return value.to(device=device)
    if isinstance(value, Mapping):
        return {key: move_to_device(item, device) for key, item in value.items()}
    if isinstance(value, tuple):
        return tuple(move_to_device(item, device) for item in value)
    if isinstance(value, list):
        return [move_to_device(item, device) for item in value]
    if isinstance(value, Sequence) and not isinstance(value, (str, bytes, bytearray)):
        return type(value)(move_to_device(item, device) for item in value)
    return value