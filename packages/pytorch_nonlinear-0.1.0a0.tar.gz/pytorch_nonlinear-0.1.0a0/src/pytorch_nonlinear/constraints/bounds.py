"""Bounds specification."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class Bounds:
    lower: Any | None = None
    upper: Any | None = None
    name: str | None = None

    def validate(self) -> None:
        if self.lower is None and self.upper is None:
            raise ValueError("At least one of lower or upper must be provided.")
