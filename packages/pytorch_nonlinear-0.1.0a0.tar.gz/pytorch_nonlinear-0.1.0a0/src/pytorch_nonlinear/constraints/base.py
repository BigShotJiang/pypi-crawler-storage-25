"""Common constraint metadata."""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Any


class ConstraintKind(str, Enum):
    EQUALITY = "equality"
    INEQUALITY = "inequality"


@dataclass(frozen=True)
class ConstraintMetadata:
    name: str | None = None
    scale: float | None = None
    expected_shape: tuple[int, ...] | None = None
    structure_hint: Any | None = None
    jacobian: Any | None = None
