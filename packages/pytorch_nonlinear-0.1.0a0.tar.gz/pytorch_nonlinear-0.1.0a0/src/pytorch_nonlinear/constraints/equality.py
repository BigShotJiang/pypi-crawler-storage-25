"""Equality constraint definition."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable

from pytorch_nonlinear.constraints.base import ConstraintKind, ConstraintMetadata


ConstraintFn = Callable[[Any, Any | None], Any]


@dataclass(frozen=True)
class EqualityConstraint:
    function: ConstraintFn
    metadata: ConstraintMetadata = field(default_factory=ConstraintMetadata)
    kind: ConstraintKind = field(default=ConstraintKind.EQUALITY, init=False)

    def validate(self) -> None:
        if not callable(self.function):
            raise TypeError("function must be callable")

    def evaluate(self, state: Any, params: Any | None = None) -> Any:
        self.validate()
        return self.function(state, params)
