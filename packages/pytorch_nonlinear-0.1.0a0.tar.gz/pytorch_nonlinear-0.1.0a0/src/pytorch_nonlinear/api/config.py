"""User-facing configuration objects for the scaffold."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any


class DiffMode(str, Enum):
    """Differentiation strategy selection."""

    AUTO = "auto"
    UNROLL = "unroll"
    IMPLICIT = "implicit"


class BatchMode(str, Enum):
    """Batch execution policy selection."""

    AUTO = "auto"
    SHARED_STRUCTURE = "shared_structure"
    INDEPENDENT = "independent"


class ScalingMode(str, Enum):
    """Scaling strategy selection for least-squares local models."""

    NONE = "none"
    AUTO = "auto"
    MANUAL = "manual"


class ConvergenceValidationMode(str, Enum):
    """Convergence validation strategy for stationary least-squares candidates."""

    AUTO = "auto"
    GRADIENT_ONLY = "gradient_only"
    DIRECTIONAL = "directional"
    STRICT = "strict"


@dataclass(frozen=True)
class ScalingConfig:
    """Scaling controls for dense least-squares local models.

    Parameters
    ----------
    variable_mode : ScalingMode, optional
        Strategy used to scale parameter directions in the local linear model.
    residual_mode : ScalingMode, optional
        Strategy used to scale residual rows in the local linear model.
    variable_scale : Any | None, optional
        Explicit positive scale factors for parameter directions when
        ``variable_mode`` is ``ScalingMode.MANUAL``.
    residual_scale : Any | None, optional
        Explicit positive scale factors for residual rows when
        ``residual_mode`` is ``ScalingMode.MANUAL``.
    """

    variable_mode: ScalingMode = ScalingMode.NONE
    residual_mode: ScalingMode = ScalingMode.NONE
    variable_scale: Any | None = None
    residual_scale: Any | None = None


@dataclass(frozen=True)
class DebugConfig:
    """Debug and reporting controls for a solver run.

    Parameters
    ----------
    enabled : bool, optional
        Enable extra debugging behavior.
    explain : bool, optional
        Request richer explanation output.
    capture_history : bool, optional
        Record structured iteration and trial history.
    level : str, optional
        Debug verbosity level.
    """

    enabled: bool = False
    explain: bool = False
    capture_history: bool = True
    level: str = "standard"


@dataclass(frozen=True)
class SolverConfig:
    """User-facing configuration for a solver run.

    Parameters
    ----------
    method : str, optional
        Solver method name.
    diff_mode : DiffMode, optional
        Differentiation strategy.
    batch_mode : BatchMode, optional
        Batch execution strategy.
    device : str | None, optional
        Explicit requested execution device, such as ``"cpu"`` or
        ``"cuda:0"``. When omitted, the solver preserves the device implied by
        the provided state tensors.
    linear_solver : str, optional
        Linear backend used by dense second-order methods. Supported values are
        ``"auto"``, ``"dense_direct"``, and ``"cholesky"``.
    max_iter : int, optional
        Maximum number of outer iterations.
    tol : float, optional
        Convergence tolerance.
    trust_region_initial_radius : float | None, optional
        Initial trust-region radius. When omitted, trust-region methods choose
        a scale-aware radius from the local linear model.
    trust_region_acceptance_threshold : float, optional
        Minimum ratio of actual to predicted reduction required to accept a
        trust-region step.
    trust_region_max_trials : int, optional
        Maximum number of trust-region trial steps per outer iteration.
    scaling : ScalingConfig, optional
        Scaling controls for dense least-squares local models.
    convergence_validation : ConvergenceValidationMode, optional
        Strategy used to validate stationary convergence candidates.
        ``"auto"`` uses a staged performance-oriented validator,
        ``"directional"`` uses only cheap directional objective probes,
        ``"strict"`` performs an exact dense Hessian curvature check, and
        ``"gradient_only"`` preserves the legacy first-order-only behavior.
    convergence_validation_probe_count : int, optional
        Number of directional objective probes used by staged convergence
        validation modes.
    convergence_validation_exact_hessian_dim_limit : int, optional
        Maximum state dimension where ``"auto"`` escalates to an exact dense
        Hessian curvature check after directional probing.
    debug : DebugConfig, optional
        Debug and history capture options.
    constrained_hessian_model : str, optional
        Hessian model used by the constrained SQP baseline. Supported values
        are ``"bfgs"`` and ``"exact"``.
    constrained_merit_penalty : float, optional
        Positive penalty coefficient used by constrained solver merit
        functions during backtracking acceptance.
    """

    method: str = "auto"
    diff_mode: DiffMode = DiffMode.AUTO
    batch_mode: BatchMode = BatchMode.AUTO
    device: str | None = None
    linear_solver: str = "auto"
    max_iter: int = 100
    tol: float = 1e-6
    trust_region_initial_radius: float | None = None
    trust_region_acceptance_threshold: float = 0.1
    trust_region_max_trials: int = 8
    scaling: ScalingConfig = field(default_factory=ScalingConfig)
    convergence_validation: ConvergenceValidationMode = ConvergenceValidationMode.AUTO
    convergence_validation_probe_count: int = 4
    convergence_validation_exact_hessian_dim_limit: int = 16
    debug: DebugConfig = field(default_factory=DebugConfig)
    constrained_hessian_model: str = "bfgs"
    constrained_merit_penalty: float = 10.0


def normalize_solver_config(config: SolverConfig | None) -> SolverConfig:
    """Normalize an optional solver configuration.

    Parameters
    ----------
    config : SolverConfig | None
        Optional user-provided configuration.

    Returns
    -------
    SolverConfig
        Concrete configuration object.
    """

    return config if config is not None else SolverConfig()
