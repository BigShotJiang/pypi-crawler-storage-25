"""Typed solve entry point."""

from __future__ import annotations

from typing import Any

from pytorch_nonlinear.api.config import BatchMode, SolverConfig, normalize_solver_config
from pytorch_nonlinear.problem import ConstrainedNLPProblem, NonlinearLeastSquaresProblem
from pytorch_nonlinear.problem.base import Problem
from pytorch_nonlinear.solvers import solve_constrained_nlp, solve_interior_point_nlp, solve_least_squares


def solve(problem: Problem, x0: Any, params: Any | None = None, config: SolverConfig | None = None) -> Any:
    """Solve a typed optimization problem.

    Parameters
    ----------
    problem : Problem
        Typed optimization problem instance.
    x0 : Any
        Initial state for the solver. Dense least-squares currently expects a
        scalar or dense tensor-like value.
    params : Any | None, optional
        Additional user parameters forwarded to the problem callback.
    config : SolverConfig | None, optional
        Solver configuration. ``method`` may be ``"auto"``,
        ``"gauss_newton"``, ``"gn"``, ``"levenberg_marquardt"``, or
        ``"lm"``, ``"trust_region"``, or ``"tr"`` for least-squares
        problems, or ``"sqp"``, ``"interior_point"``, or ``"ip"`` for
        constrained NLP problems.
        ``config.device`` may
        request an explicit execution device such as ``"cpu"`` or
        ``"cuda:0"``. ``config.linear_solver`` may select ``"auto"``,
        ``"dense_direct"``, or ``"cholesky"`` for the dense step solve
        backend. ``config.diff_mode="unroll"`` preserves autograd connectivity
        through accepted least-squares solver iterations. ``config.diff_mode="implicit"``
        attaches a conservative exact-stationarity backward rule only when the
        returned point is certifiably safe for implicit differentiation; otherwise
        the solve result reports ``diff_valid=False`` without silently falling back
        to unrolled gradients. ``config.batch_mode="shared_structure"`` expects ``x0`` to have shape ``(batch, *state_shape)`` and returns a
        ``SharedStructureBatchResult`` containing per-instance ``SolveResult``
        objects.

    Returns
    -------
    SolveResult or SharedStructureBatchResult
        Structured solver result for a single solve, or a shared-structure
        batch wrapper containing per-instance results.

    Raises
    ------
    NotImplementedError
        If the problem type is not implemented yet.
    """

    problem.validate()
    normalized_config = normalize_solver_config(config)

    if isinstance(problem, NonlinearLeastSquaresProblem):
        if normalized_config.batch_mode is BatchMode.INDEPENDENT:
            raise NotImplementedError("Independent batch mode is not implemented yet.")

        return solve_least_squares(problem=problem, x0=x0, params=params, config=normalized_config)

    if isinstance(problem, ConstrainedNLPProblem):
        if normalized_config.batch_mode is not BatchMode.AUTO:
            raise NotImplementedError("Constrained NLP batch modes are not implemented yet.")
        method = normalized_config.method.lower()
        if method in {"interior_point", "ip"}:
            return solve_interior_point_nlp(problem=problem, x0=x0, params=params, config=normalized_config)

        return solve_constrained_nlp(problem=problem, x0=x0, params=params, config=normalized_config)

    raise NotImplementedError(f"The solve() entry point does not yet implement {problem.kind.value} problems.")
