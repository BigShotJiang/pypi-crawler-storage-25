"""SciPy-like convenience entry point."""

from __future__ import annotations

from typing import Any, Sequence

from pytorch_nonlinear.api.config import SolverConfig, normalize_solver_config


def minimize(
    fun: Any,
    x0: Any,
    constraints: Sequence[Any] | None = None,
    bounds: Any | None = None,
    method: str = "auto",
    config: SolverConfig | None = None,
) -> Any:
    """Convenience wrapper placeholder.

    The real implementation will translate the flat convenience surface into the
    typed problem objects defined under `pytorch_nonlinear.problem`.
    """

    _ = normalize_solver_config(config)
    _ = fun
    _ = x0
    _ = constraints
    _ = bounds
    _ = method
    raise NotImplementedError("The minimize() adapter is not implemented yet.")
