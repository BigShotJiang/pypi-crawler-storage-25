"""Shared-structure batching helpers and result objects."""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass
from typing import Any

import torch

from pytorch_nonlinear.diagnostics import SolveResult


@dataclass(frozen=True)
class SharedStructureBatchResult:
    """Structured result for a shared-structure batch of solves.

    Parameters
    ----------
    results : tuple[SolveResult, ...]
        Per-instance solve results in batch order.
    batch_shape : tuple[int, ...]
        Leading batch shape used for the solve request.
    """

    results: tuple[SolveResult, ...]
    batch_shape: tuple[int, ...]

    @property
    def batch_size(self) -> int:
        """Return the leading batch size."""

        return self.batch_shape[0]

    @property
    def success(self) -> tuple[bool, ...]:
        """Return per-instance success flags."""

        return tuple(result.success for result in self.results)

    @property
    def x(self) -> torch.Tensor | tuple[object | None, ...]:
        """Return final states stacked when possible, else as a tuple."""

        states = tuple(result.x for result in self.results)
        if states and all(isinstance(state, torch.Tensor) for state in states):
            try:
                return torch.stack(states)
            except RuntimeError:
                return states
        return states

    @property
    def objective_value(self) -> tuple[object | None, ...]:
        """Return per-instance final objective values."""

        return tuple(result.objective_value for result in self.results)

    @property
    def num_succeeded(self) -> int:
        """Return the number of successful solves in the batch."""

        return sum(int(result.success) for result in self.results)

    def to_dict(self) -> dict[str, Any]:
        """Serialize the batch result into Python containers.

        Returns
        -------
        dict[str, Any]
            JSON-friendly payload containing the batch metadata and nested
            per-instance results.
        """

        return {
            "batch_shape": list(self.batch_shape),
            "num_succeeded": self.num_succeeded,
            "results": [result.to_dict() for result in self.results],
        }

    def summary(self) -> str:
        """Render a compact batch summary string.

        Returns
        -------
        str
            One-line textual summary of the batch solve outcome.
        """

        return f"batch_mode=shared_structure | batch_size={self.batch_size} | succeeded={self.num_succeeded}/{self.batch_size}"


def shared_structure_batch_shape(x0: object) -> tuple[int, ...]:
    """Infer the batch shape for a shared-structure solve request.

    Parameters
    ----------
    x0 : Any
        User-provided initial state value.

    Returns
    -------
    tuple[int, ...]
        Leading batch shape for the solve request.

    Raises
    ------
    ValueError
        If ``x0`` does not expose a leading batch dimension.
    """

    try:
        tensor = torch.as_tensor(x0)
    except (TypeError, ValueError) as exc:
        raise ValueError("shared_structure batch mode requires x0 to be tensor-like.") from exc

    if tensor.ndim == 0:
        raise ValueError(
            "shared_structure batch mode requires x0 to include a leading batch dimension shaped like (batch, *state_shape)."
        )
    return (int(tensor.shape[0]),)


def slice_shared_structure_value(value: object, index: int, batch_size: int) -> object:
    """Slice one batch element from a shared-structure input tree.

    Parameters
    ----------
    value : Any
        Tensor-like value or nested Python container.
    index : int
        Batch index to select.
    batch_size : int
        Expected leading batch size.

    Returns
    -------
    Any
        Per-instance value where tensors whose leading dimension matches
        ``batch_size`` are sliced along that dimension and other values are
        preserved as shared inputs.
    """

    if isinstance(value, torch.Tensor):
        if value.ndim > 0 and value.shape[0] == batch_size:
            return value[index]
        return value
    if isinstance(value, Mapping):
        return {key: slice_shared_structure_value(item, index, batch_size) for key, item in value.items()}
    if isinstance(value, tuple):
        return tuple(slice_shared_structure_value(item, index, batch_size) for item in value)
    if isinstance(value, list):
        return [slice_shared_structure_value(item, index, batch_size) for item in value]
    return value
