"""Batch execution helpers."""

from pytorch_nonlinear.batching.shared_structure import SharedStructureBatchResult

__all__ = ["SharedStructureBatchResult"]
