# Torch-Nonlinear Working Rules

Use these rules for audits, debugging, implementation, solver changes, and test design in this repository.

## Operating Protocol

Before changing code or tests, identify:

1. the failure class: product bug, test bug, budget artifact, numerical limitation, or observability gap
2. one falsifiable local hypothesis
3. one cheap discriminating check
4. the narrowest abstraction that owns the behavior

Do not jump from a failing test directly to a patch.

Before the first substantive edit, keep exploration local. Once the owning code path, one falsifiable hypothesis, and one discriminating check are identified, edit.

After the first substantive edit, run one focused validation before widening scope again. Prefer the smallest behavior-scoped test or executable check over more reading or more patching.

For solver audits and numerical failures:

1. reproduce the issue on the smallest concrete problem
2. inspect terminal state and nearby history: objective, gradient norm, step norm, acceptance ratio, radius or damping, diagnoses, and termination reason
3. test one nearby variant to distinguish local bug from broader behavior or budget effects
4. decide whether the issue is acceptance logic, termination logic, local model quality, linear solve failure, insufficient budget, or missing observability
5. only then edit code

If a run fails near a plausible solution, check whether the returned state already satisfies another valid convergence criterion before adding new failure handling.

## Implementation Rules

Before writing non-trivial code, identify:

1. the owning abstraction
2. the invariant it must preserve
3. the smallest public surface that must change
4. whether the work is new behavior, a correction, or a refactor

Prefer this order:

1. extend the existing owning abstraction
2. extract a helper when it expresses a stable named concept or removes real nesting
3. introduce a new data structure or class only when shared state and invariants need to move together across multiple call sites

Split by algorithmic phase, not by line count. Typical phase boundaries here are:

- build local model
- solve subproblem
- evaluate trial state
- decide acceptance or rejection
- update state
- write diagnostics and terminal result

Prefer:

- one function owning one stage of the algorithm
- pure helpers for local math, classification, metric computation, and shape-preserving updates
- small state carriers when mismatched values would be dangerous
- explicit phase boundaries and narrow ownership
- replacement over accretion: revise or consolidate existing structure before appending more

Avoid:

- giant functions mixing math, bookkeeping, diagnostics, and terminal-state updates
- helper explosions with no stable concept behind them
- classes that are just namespaces
- branches keyed to one test, one example, or one loss unless that specialization is part of the API
- adding new public flags, solver modes, or return channels when existing structures can express the behavior

Refactor before continuing if ownership becomes unclear, one function starts mixing stages and policy decisions, or repeated tensor bookkeeping hides the logic.

## Documentation Of Algorithms And Key Concepts

- Document only stable algorithmic concepts: the mathematical object, invariant, safeguard, or certification condition that a future reader must understand.
- For method and helper docstrings, use NumPy-style docstrings and state the role of the routine, the meaning of key returned quantities, and the condition that makes the logic valid.
- Use inline comments only at major phase boundaries or before non-obvious correctness guards, reduced systems, fallbacks, or acceptance logic.
- Never narrate obvious tensor operations or restate the code; comments must add mathematical or algorithmic meaning.
- Keep terminology and sign conventions consistent across helpers, diagnostics, tests, and examples, and whenever implementation changes make documentation stale, update it or remove it.

## Compatibility And Test Rules

Treat existing solver capabilities as compatibility surfaces, not incidental behavior.

For changes to solver internals, explicitly consider compatibility with:

- GN, LM, and trust-region
- none, unroll, and implicit differentiation
- no scaling, manual scaling, and auto scaling
- single-instance and shared-structure batching
- squared and robust losses

Do not assume a fix in one path is safe for the others. Validate one nearby affected variant unless the change is provably isolated.

Do not weaken a test just to make it pass.

A test may be changed only if at least one is shown:

- the assertion contradicts intended behavior
- the oracle is wrong or incomplete
- the case is actually about budget or numerical difficulty rather than correctness
- the test duplicates stronger existing coverage

When changing a test, state what the old test got wrong and what the new one proves.

Avoid:

- raising tolerances without a numerical explanation
- increasing `max_iter` without checking whether progress is healthy or stalled
- replacing analytical or exact assertions with vague smoke checks
- deleting a failing regression without replacing it with a more correct one

Prefer tests that certify behavior through:

- analytical solutions
- cross-method agreement on certified problems
- finite-difference or exact gradient checks
- invariance or equivariance under scaling, batching, or parameter packing
- acceptance-history evidence for iterative behavior
- explicit diagnosis and termination semantics

For nonlinear numerical tests:

- use the simplest problem that still exposes the behavior
- separate correctness, robustness, and performance-budget cases
- prefer one strong parameterized test over many near-duplicates
- for intentionally hard cases, assert the right thing: healthy progress, correct diagnosis, or eventual convergence with larger budget

Grow coverage by matrix, not by accumulation.

Key axes in this repository:

- method: GN, LM, trust-region
- differentiation: none, unroll, implicit
- scaling: none, manual, auto
- batching: single, shared-structure
- losses: squared, Huber, Cauchy, SoftL1
- terminal behavior: converged, max-iter, rejected-step, ill-conditioned, uncertified diff

Add tests that cover an uncovered intersection or protect a discovered bug class. Do not add near-duplicates unless they provide a stronger oracle.

## Review Standard

For any non-trivial audit, bug fix, or regression review, be able to state:

1. what the current test proves
2. what it does not prove
3. whether the failure is a product bug, test issue, budget artifact, numerical limitation, or unresolved
4. the smallest convincing next check
5. why the chosen code or test change is the minimal general solution
6. what nearby validation shows the design or fix generalizes
7. what existing compatibility surface was checked and why that surface was the right one

## Guardrails

- Never call a case "too hard" without showing whether progress is healthy or stalled.
- Never call a behavior a solver bug if a larger-budget run shows steady accepted progress to the correct solution.
- Never accept a narrow fix until one nearby variant has been checked.
- Never solve visibility problems with speculative branches when diagnostics or structured history would decide the question.
- Never resolve complexity by pushing everything into one giant function or class.
- Never resolve complexity by scattering one concept across many tiny helpers with no clear ownership model.
- Never keep growing files, APIs, or tests by accumulation when a replacement or consolidation pass is the right move.
