"""Tests for SpeakerInfo block on TITLE slides (v0.11.0)."""

from __future__ import annotations

import tempfile
from pathlib import Path

from pptx import Presentation

from pptx_mcp.brand.config import resolve_brand_config
from pptx_mcp.engine.generator import DeckGenerator
from pptx_mcp.models.slides import (
    PresentationDefinition,
    PresentationMetadata,
    SlideDefinition,
    SlideType,
    SpeakerInfo,
)


def _render_title(speaker: SpeakerInfo | None) -> Presentation:
    defn = PresentationDefinition(
        metadata=PresentationMetadata(title="Keynote"),
        slides=[SlideDefinition(
            slide_type=SlideType.TITLE,
            title="The Future of Work",
            subtitle="A conference talk",
            speaker_info=speaker,
        )],
    )
    brand = resolve_brand_config()
    with tempfile.TemporaryDirectory() as td:
        out = Path(td) / "t.pptx"
        DeckGenerator(brand=brand).generate(defn, out)
        return Presentation(str(out))


def _slide_text(prs: Presentation) -> str:
    return " ".join(
        s.text_frame.text for s in prs.slides[0].shapes if s.has_text_frame
    )


class TestSpeakerInfo:
    def test_model_name_required(self) -> None:
        s = SpeakerInfo(name="Jane Doe")
        assert s.title is None and s.company is None

    def test_renders_name_on_title(self) -> None:
        prs = _render_title(SpeakerInfo(name="Jane Doe"))
        text = _slide_text(prs)
        assert "The Future of Work" in text  # title still renders
        assert "Jane Doe" in text

    def test_renders_title_and_company(self) -> None:
        prs = _render_title(SpeakerInfo(
            name="Jane Doe", title="VP Research", company="Acme Labs",
        ))
        text = _slide_text(prs)
        assert "Jane Doe" in text
        assert "VP Research" in text
        assert "Acme Labs" in text
        # Title + company joined with • separator
        assert "•" in text

    def test_renders_socials(self) -> None:
        prs = _render_title(SpeakerInfo(
            name="Jane Doe", socials=["@janedoe", "linkedin.com/in/jane"],
        ))
        text = _slide_text(prs)
        assert "@janedoe" in text
        assert "linkedin.com/in/jane" in text

    def test_missing_avatar_renders_cleanly(self) -> None:
        # Avatar path points to missing file; must not crash
        prs = _render_title(SpeakerInfo(
            name="Jane Doe", image_path="/nonexistent/avatar.png",
        ))
        assert "Jane Doe" in _slide_text(prs)

    def test_no_speaker_info_still_renders_title(self) -> None:
        prs = _render_title(None)
        text = _slide_text(prs)
        assert "The Future of Work" in text
        # Shouldn't have leaked SpeakerInfo fields
        assert "SpeakerInfo" not in text
