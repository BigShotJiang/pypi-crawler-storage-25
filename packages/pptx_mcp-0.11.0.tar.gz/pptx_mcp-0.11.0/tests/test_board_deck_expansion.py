"""Tests for Phase 1d: board_deck slot expansion + required-respecting trim."""

from __future__ import annotations

from pptx_mcp.agents.archetypes import ARCHETYPES
from pptx_mcp.agents.planner import PlannerInput, SlidePlannerAgent
from pptx_mcp.models.slides import SlideType


class TestBoardDeckArchetype:
    def test_has_exec_summary_slot(self) -> None:
        arch = ARCHETYPES["board_deck"]
        types = [s.slide_type for s in arch.slots]
        assert SlideType.EXECUTIVE_SUMMARY in types

    def test_has_scorecard_slot(self) -> None:
        arch = ARCHETYPES["board_deck"]
        types = [s.slide_type for s in arch.slots]
        assert SlideType.SCORECARD in types

    def test_swot_removed(self) -> None:
        arch = ARCHETYPES["board_deck"]
        types = [s.slide_type for s in arch.slots]
        assert SlideType.SWOT not in types

    def test_slot_count_in_valid_range(self) -> None:
        arch = ARCHETYPES["board_deck"]
        # Should be meaningfully richer than pre-expansion (9)
        assert len(arch.slots) >= 14
        assert len(arch.slots) <= 20

    def test_new_slots_marked_optional(self) -> None:
        arch = ARCHETYPES["board_deck"]
        by_title = {s.title_template: s for s in arch.slots}
        assert by_title["CEO Message"].required is False
        assert by_title["Prior Actions Tracker"].required is False
        assert by_title["Segment P&L"].required is False
        assert by_title["Cash & Liquidity"].required is False
        assert by_title["Capital Allocation"].required is False
        assert by_title["ESG & Governance"].required is False
        assert by_title["Appendix"].required is False

    def test_core_slots_still_required(self) -> None:
        arch = ARCHETYPES["board_deck"]
        by_title = {s.title_template: s for s in arch.slots}
        assert by_title["Executive Summary"].required is True
        assert by_title["Strategic Priorities"].required is True
        assert by_title["Financial Overview"].required is True


class TestRequiredRespectingTrim:
    def test_requesting_required_count_yields_all_required_types(self) -> None:
        """Requesting exactly required_count slides must keep all required types.

        The outer run() hard-trims to num_slides, so output ends up equal to
        num_slides (when ≤ min_slides-1 the outer trim bites). This test
        verifies the important property: every required slot is represented.
        """
        arch = ARCHETYPES["board_deck"]
        required_count = sum(1 for s in arch.slots if s.required)

        agent = SlidePlannerAgent()
        deck = agent.run(PlannerInput(
            topic="Q3 Review",
            num_slides=required_count,
            deck_type="board_deck",
        ))
        # Planner's hard trim caps at num_slides, so output = required_count
        assert len(deck.slides) == required_count
        # Every required slot type must be present
        required_types = [s.slide_type for s in arch.slots if s.required]
        output_types = [s.slide_type for s in deck.slides]
        for rt in required_types:
            assert rt in output_types, f"required {rt.value} missing"

    def test_target_between_required_and_all_picks_optional(self) -> None:
        """When target is between required and len(slots), optional slots fill the gap."""
        arch = ARCHETYPES["board_deck"]
        required_count = sum(1 for s in arch.slots if s.required)
        target = required_count + 2

        agent = SlidePlannerAgent()
        deck = agent.run(PlannerInput(
            topic="Q3 Review",
            num_slides=target,
            deck_type="board_deck",
        ))
        assert len(deck.slides) == target

    def test_target_exceeds_slots_adds_filler(self) -> None:
        arch = ARCHETYPES["board_deck"]
        target = min(len(arch.slots) + 2, arch.max_slides)

        agent = SlidePlannerAgent()
        deck = agent.run(PlannerInput(
            topic="Q3 Review",
            num_slides=target,
            deck_type="board_deck",
        ))
        assert len(deck.slides) == target

    def test_title_always_first(self) -> None:
        agent = SlidePlannerAgent()
        deck = agent.run(PlannerInput(
            topic="Q3 Review",
            num_slides=10,
            deck_type="board_deck",
        ))
        assert deck.slides[0].slide_type == SlideType.TITLE

    def test_closing_always_last(self) -> None:
        agent = SlidePlannerAgent()
        deck = agent.run(PlannerInput(
            topic="Q3 Review",
            num_slides=10,
            deck_type="board_deck",
        ))
        assert deck.slides[-1].slide_type == SlideType.CLOSING
