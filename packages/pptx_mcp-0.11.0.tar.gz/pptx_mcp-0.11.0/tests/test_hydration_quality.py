"""Tests for Phase 1b: archetype-specific hydration without fabrication.

Locks in the guarantee that the planner NEVER invents:
- Fake KPI numbers (was: 87% Progress, 12/15 Completion, 4.2/5 Team Capacity)
- Fake quote attributions (was: "Industry Expert")
- Generic boilerplate pros/cons (was: "Aligns with {topic} objectives")

When input data is insufficient, the planner emits explicit placeholder
markers instead of plausible-sounding fake content.
"""

from __future__ import annotations

from pptx_mcp.agents.planner import PlannerInput, SlidePlannerAgent, SlideSpec
from pptx_mcp.models.slides import SlideType


def _plan(key_points=None, num_slides=5, **kwargs):
    agent = SlidePlannerAgent()
    return agent.run(PlannerInput(
        topic="Market Expansion",
        num_slides=num_slides,
        key_points=key_points or [],
        **kwargs,
    ))


# ---------------------------------------------------------------------------
# DASHBOARD — no fabricated KPIs
# ---------------------------------------------------------------------------


class TestDashboardHydration:
    def test_no_fake_87_percent(self) -> None:
        deck = _plan(
            slides=[SlideSpec(slide_type=SlideType.DASHBOARD, title="Metrics")],
            num_slides=3,
        )
        dashboard = next(s for s in deck.slides if s.slide_type == SlideType.DASHBOARD)
        kpi_values = [k.value for k in dashboard.kpis]
        assert "87%" not in kpi_values, "fake 87% KPI must not be emitted"
        assert "12/15" not in kpi_values
        assert "4.2/5" not in kpi_values
        assert "On Track" not in kpi_values

    def test_empty_key_points_emits_tbd(self) -> None:
        deck = _plan(
            slides=[SlideSpec(slide_type=SlideType.DASHBOARD, title="Metrics")],
            num_slides=3,
        )
        dashboard = next(s for s in deck.slides if s.slide_type == SlideType.DASHBOARD)
        assert all(k.value == "TBD" for k in dashboard.kpis), (
            "all KPI values must be TBD when no key_points supplied"
        )

    def test_numeric_key_points_produce_real_kpis(self) -> None:
        deck = _plan(
            key_points=[
                "Revenue grew 23% YoY",
                "MRR reached $1.2M",
                "Churn dropped to 4%",
            ],
            slides=[SlideSpec(slide_type=SlideType.DASHBOARD, title="Metrics")],
            num_slides=3,
        )
        dashboard = next(s for s in deck.slides if s.slide_type == SlideType.DASHBOARD)
        values = [k.value for k in dashboard.kpis]
        assert "23%" in values
        assert any("1.2" in v and "$" in v for v in values)
        assert "4%" in values


# ---------------------------------------------------------------------------
# QUOTE — no fake attribution
# ---------------------------------------------------------------------------


class TestQuoteHydration:
    def test_no_industry_expert(self) -> None:
        deck = _plan(
            slides=[SlideSpec(slide_type=SlideType.QUOTE, title="Voice")],
            num_slides=3,
        )
        quote = next(s for s in deck.slides if s.slide_type == SlideType.QUOTE)
        assert quote.quote_attribution != "Industry Expert"
        assert "Thought Leader" not in (quote.quote_attribution_role or "")

    def test_no_attribution_without_author(self) -> None:
        deck = _plan(
            slides=[SlideSpec(slide_type=SlideType.QUOTE, title="Voice")],
            num_slides=3,
        )
        quote = next(s for s in deck.slides if s.slide_type == SlideType.QUOTE)
        assert quote.quote_attribution is None, (
            "planner must not invent attribution when author not provided"
        )

    def test_author_preserved_when_supplied(self) -> None:
        deck = _plan(
            key_points=["Clarity beats cleverness in execution"],
            slides=[SlideSpec(slide_type=SlideType.QUOTE, title="Voice")],
            num_slides=3,
            author="Jane Doe",
            company="Acme Corp",
        )
        quote = next(s for s in deck.slides if s.slide_type == SlideType.QUOTE)
        assert quote.quote_attribution == "Jane Doe"
        assert quote.quote_attribution_role == "Acme Corp"


# ---------------------------------------------------------------------------
# PROS_CONS — placeholder labels when no key_points
# ---------------------------------------------------------------------------


class TestProsConsHydration:
    def test_no_aligns_with_objectives_filler(self) -> None:
        deck = _plan(
            slides=[SlideSpec(slide_type=SlideType.PROS_CONS, title="Trade-offs")],
            num_slides=3,
        )
        pc = next(s for s in deck.slides if s.slide_type == SlideType.PROS_CONS)
        joined = " ".join(pc.pros + pc.cons)
        assert "Aligns with" not in joined
        assert "Builds on existing" not in joined

    def test_empty_inputs_emit_bracket_placeholders(self) -> None:
        deck = _plan(
            slides=[SlideSpec(slide_type=SlideType.PROS_CONS, title="Trade-offs")],
            num_slides=3,
        )
        pc = next(s for s in deck.slides if s.slide_type == SlideType.PROS_CONS)
        assert all(p.startswith("[") for p in pc.pros)
        assert all(c.startswith("[") for c in pc.cons)

    def test_four_plus_key_points_populate_pros_cons(self) -> None:
        deck = _plan(
            key_points=[
                "Faster time to market",
                "Lower cost per unit",
                "Requires new hires",
                "Adds regulatory complexity",
            ],
            slides=[SlideSpec(slide_type=SlideType.PROS_CONS, title="Trade-offs")],
            num_slides=3,
        )
        pc = next(s for s in deck.slides if s.slide_type == SlideType.PROS_CONS)
        assert "Faster time to market" in pc.pros
        assert "Requires new hires" in pc.cons


# ---------------------------------------------------------------------------
# COMPARISON — no fake "Optimized for speed/cost" labels
# ---------------------------------------------------------------------------


class TestComparisonHydration:
    def test_no_fake_option_labels(self) -> None:
        deck = _plan(
            slides=[SlideSpec(slide_type=SlideType.COMPARISON, title="Options")],
            num_slides=3,
        )
        comp = next(s for s in deck.slides if s.slide_type == SlideType.COMPARISON)
        all_bullets = [b for col in comp.columns for b in col.bullets]
        assert not any("Optimized for" in b for b in all_bullets)
        assert not any("Balanced" in b for b in all_bullets)

    def test_empty_inputs_emit_bracket_columns(self) -> None:
        deck = _plan(
            slides=[SlideSpec(slide_type=SlideType.COMPARISON, title="Options")],
            num_slides=3,
        )
        comp = next(s for s in deck.slides if s.slide_type == SlideType.COMPARISON)
        assert all(c.title.startswith("[") for c in comp.columns)
