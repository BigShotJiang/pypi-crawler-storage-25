"""Tests for Phase 2 / v0.11.0: TESTIMONIAL, PRICING_TABLE, LOGO_WALL,
FULL_BLEED_HERO, BEFORE_AFTER, REFERENCES slide types.
"""

from __future__ import annotations

import tempfile
from pathlib import Path

import pytest
from pptx import Presentation
from pydantic import ValidationError

from pptx_mcp.agents.content_mapper import suggest_slide_type
from pptx_mcp.agents.planner import PlannerInput, SlidePlannerAgent, SlideSpec
from pptx_mcp.brand.config import resolve_brand_config
from pptx_mcp.engine.describer import describe_slide
from pptx_mcp.engine.generator import DeckGenerator
from pptx_mcp.models.slides import (
    BeforeAfter,
    Citation,
    HeroImage,
    LogoWallItem,
    PresentationDefinition,
    PresentationMetadata,
    PricingTier,
    SlideDefinition,
    SlideType,
    Testimonial,
)


def _render(defn: PresentationDefinition) -> Presentation:
    brand = resolve_brand_config()
    with tempfile.TemporaryDirectory() as td:
        out = Path(td) / "t.pptx"
        DeckGenerator(brand=brand).generate(defn, out)
        return Presentation(str(out))


def _slide_text(prs: Presentation, idx: int = 0) -> str:
    return " ".join(
        s.text_frame.text for s in prs.slides[idx].shapes if s.has_text_frame
    )


# ---------------------------------------------------------------------------
# TESTIMONIAL
# ---------------------------------------------------------------------------


class TestTestimonial:
    def test_model_fields(self) -> None:
        t = Testimonial(
            quote="Saved 40 hours a quarter.", name="Jane Doe",
            role="VP Finance", company="Acme", rating=5,
        )
        assert t.rating == 5
        assert t.role == "VP Finance"

    def test_rating_bounds(self) -> None:
        with pytest.raises(ValidationError):
            Testimonial(quote="Q", name="N", rating=0)
        with pytest.raises(ValidationError):
            Testimonial(quote="Q", name="N", rating=6)

    def test_renders_three_cards(self) -> None:
        defn = PresentationDefinition(
            metadata=PresentationMetadata(title="T"),
            slides=[SlideDefinition(
                slide_type=SlideType.TESTIMONIAL, title="Voice",
                testimonials=[
                    Testimonial(quote=f"Quote {i}", name=f"Name {i}", rating=4)
                    for i in range(3)
                ],
            )],
        )
        prs = _render(defn)
        text = _slide_text(prs)
        for i in range(3):
            assert f"Quote {i}" in text and f"Name {i}" in text

    def test_missing_avatar_renders_cleanly(self) -> None:
        defn = PresentationDefinition(
            metadata=PresentationMetadata(title="T"),
            slides=[SlideDefinition(
                slide_type=SlideType.TESTIMONIAL, title="Voice",
                testimonials=[Testimonial(
                    quote="Q", name="N", image_path="/nonexistent/avatar.png",
                )],
            )],
        )
        # Must not raise
        prs = _render(defn)
        assert len(prs.slides) == 1

    def test_clamps_to_three(self) -> None:
        defn = PresentationDefinition(
            metadata=PresentationMetadata(title="T"),
            slides=[SlideDefinition(
                slide_type=SlideType.TESTIMONIAL, title="Voice",
                testimonials=[
                    Testimonial(quote=f"Q{i}", name=f"N{i}") for i in range(3)
                ],
            )],
        )
        # max_length=3 on SlideDefinition.testimonials — should validate
        assert len(defn.slides[0].testimonials) == 3

    def test_content_mapper_routes(self) -> None:
        assert suggest_slide_type("Customer testimonials") == SlideType.TESTIMONIAL
        assert suggest_slide_type("What customers say") == SlideType.TESTIMONIAL

    def test_planner_placeholder_when_empty(self) -> None:
        deck = SlidePlannerAgent().run(PlannerInput(
            topic="X", num_slides=3,
            slides=[SlideSpec(slide_type=SlideType.TESTIMONIAL)],
        ))
        t = deck.slides[0].testimonials[0]
        assert t.name == "[Customer Name]"


# ---------------------------------------------------------------------------
# PRICING_TABLE
# ---------------------------------------------------------------------------


class TestPricingTable:
    def test_highlighted_renders_most_popular_ribbon(self) -> None:
        defn = PresentationDefinition(
            metadata=PresentationMetadata(title="T"),
            slides=[SlideDefinition(
                slide_type=SlideType.PRICING_TABLE, title="Plans",
                pricing_tiers=[
                    PricingTier(name="Starter", price="$9", cta_text="Start"),
                    PricingTier(name="Pro", price="$29", cta_text="Go", highlighted=True),
                    PricingTier(name="Enterprise", price="Contact", cta_text="Call"),
                ],
            )],
        )
        prs = _render(defn)
        text = _slide_text(prs)
        assert "MOST POPULAR" in text or "Most Popular" in text
        assert "Starter" in text and "Pro" in text and "Enterprise" in text

    def test_feature_checkmarks(self) -> None:
        defn = PresentationDefinition(
            metadata=PresentationMetadata(title="T"),
            slides=[SlideDefinition(
                slide_type=SlideType.PRICING_TABLE, title="Plans",
                pricing_tiers=[PricingTier(
                    name="Pro", price="$29/mo",
                    features=["SSO", "Priority support"],
                )],
            )],
        )
        prs = _render(defn)
        text = _slide_text(prs)
        assert "\u2713" in text  # checkmark
        assert "SSO" in text

    def test_content_mapper_routes(self) -> None:
        assert suggest_slide_type("Pricing tiers") == SlideType.PRICING_TABLE
        assert suggest_slide_type("Plans and features") == SlideType.PRICING_TABLE

    def test_content_mapper_does_not_overmatch(self) -> None:
        # "Pricing strategy" should NOT route to PRICING_TABLE
        assert suggest_slide_type("Pricing strategy framework") != SlideType.PRICING_TABLE

    def test_planner_produces_3_tiers_with_one_highlighted(self) -> None:
        deck = SlidePlannerAgent().run(PlannerInput(
            topic="X", num_slides=3,
            slides=[SlideSpec(slide_type=SlideType.PRICING_TABLE)],
        ))
        tiers = deck.slides[0].pricing_tiers
        assert len(tiers) == 3
        assert sum(1 for t in tiers if t.highlighted) == 1


# ---------------------------------------------------------------------------
# LOGO_WALL
# ---------------------------------------------------------------------------


class TestLogoWall:
    def test_name_is_required(self) -> None:
        with pytest.raises(ValidationError):
            LogoWallItem(image_path="/x.png")  # type: ignore[call-arg]

    def test_renders_labels(self) -> None:
        defn = PresentationDefinition(
            metadata=PresentationMetadata(title="T"),
            slides=[SlideDefinition(
                slide_type=SlideType.LOGO_WALL, title="Trusted",
                logo_wall=[
                    LogoWallItem(image_path="/x.png", name="Acme"),
                    LogoWallItem(image_path="/y.png", name="Globex"),
                ],
            )],
        )
        prs = _render(defn)
        text = _slide_text(prs)
        assert "Acme" in text and "Globex" in text

    def test_content_mapper_routes(self) -> None:
        assert suggest_slide_type("Our customer logos") == SlideType.LOGO_WALL
        assert suggest_slide_type("Trusted by leading brands") == SlideType.LOGO_WALL

    def test_content_mapper_does_not_overmatch_clients(self) -> None:
        # "Client feedback" should NOT steal into LOGO_WALL
        assert suggest_slide_type("Client feedback summary") != SlideType.LOGO_WALL


# ---------------------------------------------------------------------------
# FULL_BLEED_HERO
# ---------------------------------------------------------------------------


class TestFullBleedHero:
    def test_default_overlay_opacity_is_reasonable(self) -> None:
        h = HeroImage(image_path="/x.jpg")
        assert h.overlay_opacity == 0.3
        assert h.overlay == "gradient_bottom"

    def test_renders_without_image(self) -> None:
        # Missing image file should degrade, not crash
        defn = PresentationDefinition(
            metadata=PresentationMetadata(title="T"),
            slides=[SlideDefinition(
                slide_type=SlideType.FULL_BLEED_HERO, title="Hero Title",
                subtitle="A talk",
                hero_image=HeroImage(image_path="/nonexistent.jpg"),
            )],
        )
        prs = _render(defn)
        text = _slide_text(prs)
        assert "Hero Title" in text

    def test_renders_title_when_no_hero_image_config(self) -> None:
        defn = PresentationDefinition(
            metadata=PresentationMetadata(title="T"),
            slides=[SlideDefinition(
                slide_type=SlideType.FULL_BLEED_HERO, title="Fallback",
            )],
        )
        prs = _render(defn)
        assert "Fallback" in _slide_text(prs)

    def test_content_mapper_routes(self) -> None:
        assert suggest_slide_type("Hero image slide") == SlideType.FULL_BLEED_HERO


# ---------------------------------------------------------------------------
# BEFORE_AFTER
# ---------------------------------------------------------------------------


class TestBeforeAfter:
    def test_renders_labels_and_delta(self) -> None:
        defn = PresentationDefinition(
            metadata=PresentationMetadata(title="T"),
            slides=[SlideDefinition(
                slide_type=SlideType.BEFORE_AFTER, title="Transformation",
                before_after=BeforeAfter(
                    before_image_path="/a.png", after_image_path="/b.png",
                    before_label="Manual", after_label="Automated",
                    delta_text="+47% throughput",
                ),
            )],
        )
        prs = _render(defn)
        text = _slide_text(prs)
        assert "Manual" in text and "Automated" in text
        assert "+47% throughput" in text

    def test_vertical_orientation_works(self) -> None:
        defn = PresentationDefinition(
            metadata=PresentationMetadata(title="T"),
            slides=[SlideDefinition(
                slide_type=SlideType.BEFORE_AFTER, title="T",
                before_after=BeforeAfter(
                    before_image_path="/a.png", after_image_path="/b.png",
                    orientation="vertical",
                ),
            )],
        )
        prs = _render(defn)
        assert len(prs.slides) == 1

    def test_content_mapper_routes(self) -> None:
        assert suggest_slide_type("Before and after comparison") == SlideType.BEFORE_AFTER

    def test_content_mapper_does_not_overmatch_transformation(self) -> None:
        # "Digital transformation roadmap" should NOT steal into BEFORE_AFTER
        assert suggest_slide_type("Digital transformation roadmap") != SlideType.BEFORE_AFTER


# ---------------------------------------------------------------------------
# REFERENCES
# ---------------------------------------------------------------------------


class TestReferences:
    def test_renders_numbered_citations(self) -> None:
        defn = PresentationDefinition(
            metadata=PresentationMetadata(title="T"),
            slides=[SlideDefinition(
                slide_type=SlideType.REFERENCES, title="References",
                citation_style="numbered",
                citations=[
                    Citation(text="Smith, J. (2024). Study."),
                    Citation(text="Doe, A. (2023). Analysis."),
                ],
            )],
        )
        prs = _render(defn)
        text = _slide_text(prs)
        assert "1. Smith, J." in text
        assert "2. Doe, A." in text

    def test_renders_anchor_ids_when_not_numbered(self) -> None:
        defn = PresentationDefinition(
            metadata=PresentationMetadata(title="T"),
            slides=[SlideDefinition(
                slide_type=SlideType.REFERENCES, title="References",
                citation_style="apa",
                citations=[Citation(text="Smith (2024).", citation_id="Smith2024")],
            )],
        )
        prs = _render(defn)
        text = _slide_text(prs)
        assert "[Smith2024]" in text

    def test_url_validator_rejects_javascript_scheme(self) -> None:
        with pytest.raises(ValidationError):
            Citation(text="x", url="javascript:alert(1)")

    def test_content_mapper_routes(self) -> None:
        assert suggest_slide_type("References") == SlideType.REFERENCES
        assert suggest_slide_type("Bibliography") == SlideType.REFERENCES

    def test_planner_placeholder_when_empty(self) -> None:
        deck = SlidePlannerAgent().run(PlannerInput(
            topic="X", num_slides=3,
            slides=[SlideSpec(slide_type=SlideType.REFERENCES)],
        ))
        cites = deck.slides[0].citations
        assert len(cites) >= 1
        assert cites[0].text.startswith("[")


# ---------------------------------------------------------------------------
# Describer coverage (one test per type — ensures no regressions)
# ---------------------------------------------------------------------------


class TestDescriber:
    def test_testimonial(self) -> None:
        s = SlideDefinition(
            slide_type=SlideType.TESTIMONIAL, title="T",
            testimonials=[Testimonial(quote="Q", name="N", image_path="/x.jpg")],
        )
        d = describe_slide(s, 0)
        assert "testimonial" in d.lower()
        assert "avatar" in d.lower()

    def test_pricing(self) -> None:
        s = SlideDefinition(
            slide_type=SlideType.PRICING_TABLE, title="T",
            pricing_tiers=[PricingTier(name="A", price="$1", highlighted=True)],
        )
        d = describe_slide(s, 0)
        assert "tier" in d.lower() and "highlight" in d.lower()

    def test_logo_wall(self) -> None:
        s = SlideDefinition(
            slide_type=SlideType.LOGO_WALL, title="T",
            logo_wall=[LogoWallItem(image_path="/x.png", name="A")],
            logo_wall_grayscale=True,
        )
        d = describe_slide(s, 0)
        assert "logo" in d.lower() and "grayscale" in d.lower()

    def test_hero(self) -> None:
        s = SlideDefinition(
            slide_type=SlideType.FULL_BLEED_HERO, title="T",
            hero_image=HeroImage(image_path="/x.jpg", text_position="center"),
        )
        d = describe_slide(s, 0)
        assert "overlay" in d.lower() and "center" in d.lower()

    def test_before_after(self) -> None:
        s = SlideDefinition(
            slide_type=SlideType.BEFORE_AFTER, title="T",
            before_after=BeforeAfter(
                before_image_path="/a.png", after_image_path="/b.png",
                delta_text="+47%",
            ),
        )
        d = describe_slide(s, 0)
        assert "horizontal" in d.lower()
        assert "+47%" in d

    def test_references(self) -> None:
        s = SlideDefinition(
            slide_type=SlideType.REFERENCES, title="T",
            citations=[Citation(text="X")],
            citation_style="numbered",
        )
        d = describe_slide(s, 0)
        assert "citation" in d.lower() and "numbered" in d.lower()
