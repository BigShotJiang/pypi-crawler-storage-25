"""CI-enforceable quality gates for brand presets.

These gates encode non-negotiable design quality guarantees for every shipped
preset. Adding a new preset means this test suite must continue to pass.

Gates:
  1. Contrast — primary, secondary, accent pass WCAG 4.5:1 on preset background
  2. Type scale — font sizes monotonically decrease, adjacent ratios in [1.10, 1.50]
  3. Grid alignment report — SpacingConfig exposes drift reporting (no values enforced)

Extend this file as new gates are identified.
"""

from __future__ import annotations

import pytest

from pptx_mcp.brand.defaults import PRESETS
from pptx_mcp.engine.shapes import contrast_ratio
from pptx_mcp.models.brand import BrandConfig


# ---------------------------------------------------------------------------
# Gate 1: WCAG contrast
# ---------------------------------------------------------------------------


@pytest.mark.parametrize("preset_name,brand", list(PRESETS.items()))
class TestContrastGate:
    """Every preset's primary/secondary/accent must pass WCAG 4.5:1 on its background."""

    def test_primary_contrast(self, preset_name: str, brand: BrandConfig) -> None:
        ratio = contrast_ratio(brand.colors.primary, brand.colors.background)
        assert ratio >= 4.5, (
            f"{preset_name}: primary {brand.colors.primary} on "
            f"{brand.colors.background} = {ratio:.2f}:1 (need 4.5)"
        )

    def test_secondary_contrast(self, preset_name: str, brand: BrandConfig) -> None:
        ratio = contrast_ratio(brand.colors.secondary, brand.colors.background)
        assert ratio >= 4.5, (
            f"{preset_name}: secondary {brand.colors.secondary} on "
            f"{brand.colors.background} = {ratio:.2f}:1 (need 4.5)"
        )

    def test_accent_contrast(self, preset_name: str, brand: BrandConfig) -> None:
        ratio = contrast_ratio(brand.colors.accent, brand.colors.background)
        assert ratio >= 4.5, (
            f"{preset_name}: accent {brand.colors.accent} on "
            f"{brand.colors.background} = {ratio:.2f}:1 (need 4.5)"
        )


# ---------------------------------------------------------------------------
# Gate 2: Type scale proportionality
# ---------------------------------------------------------------------------


@pytest.mark.parametrize("preset_name,brand", list(PRESETS.items()))
class TestTypeScaleGate:
    """Font sizes must decrease monotonically with ratios in a sensible range."""

    MIN_RATIO = 1.05
    MAX_RATIO = 1.60

    def test_sizes_monotonic(self, preset_name: str, brand: BrandConfig) -> None:
        f = brand.fonts
        sizes = [f.title_size, f.heading_size, f.subheading_size, f.body_size, f.caption_size]
        for i in range(len(sizes) - 1):
            assert sizes[i] > sizes[i + 1], (
                f"{preset_name}: type scale not monotonic at step {i}: "
                f"{sizes[i]}pt -> {sizes[i + 1]}pt"
            )

    def test_ratios_in_range(self, preset_name: str, brand: BrandConfig) -> None:
        f = brand.fonts
        sizes = [f.title_size, f.heading_size, f.subheading_size, f.body_size, f.caption_size]
        for i in range(len(sizes) - 1):
            ratio = sizes[i] / sizes[i + 1]
            assert self.MIN_RATIO <= ratio <= self.MAX_RATIO, (
                f"{preset_name}: adjacent ratio {sizes[i]}/{sizes[i + 1]} = "
                f"{ratio:.3f} outside [{self.MIN_RATIO}, {self.MAX_RATIO}]"
            )


# ---------------------------------------------------------------------------
# Gate 3: Grid alignment reporting (advisory, non-enforcing)
# ---------------------------------------------------------------------------


@pytest.mark.parametrize("preset_name,brand", list(PRESETS.items()))
def test_grid_alignment_reportable(preset_name: str, brand: BrandConfig) -> None:
    """Every preset's SpacingConfig must expose the grid-alignment report API.

    The report is advisory — values aren't enforced to the grid. This gate just
    guarantees callers can always query drift.
    """
    drift = brand.spacing.grid_alignment_report()
    assert isinstance(drift, dict), (
        f"{preset_name}: grid_alignment_report must return a dict"
    )


# ---------------------------------------------------------------------------
# Gate 4: line-height overrides are well-formed when present
# ---------------------------------------------------------------------------


@pytest.mark.parametrize("preset_name,brand", list(PRESETS.items()))
def test_line_height_overrides_valid(preset_name: str, brand: BrandConfig) -> None:
    """Per-kind line heights (when set) must be positive floats."""
    f = brand.fonts
    for field_name in ("heading_line_height", "body_line_height", "caption_line_height"):
        value = getattr(f, field_name)
        if value is None:
            continue
        assert value > 0, f"{preset_name}: {field_name} = {value} must be > 0"
        assert value <= 3.0, (
            f"{preset_name}: {field_name} = {value} is unreasonably large (> 3.0)"
        )
