"""Tests for Phase 1c: EXECUTIVE_SUMMARY and SCORECARD slide types."""

from __future__ import annotations

import tempfile
from pathlib import Path

from pptx import Presentation

from pptx_mcp.agents.content_mapper import suggest_slide_type
from pptx_mcp.agents.planner import PlannerInput, SlidePlannerAgent, SlideSpec
from pptx_mcp.brand.config import resolve_brand_config
from pptx_mcp.engine.describer import describe_slide
from pptx_mcp.engine.generator import DeckGenerator
from pptx_mcp.models.slides import (
    ExecutiveSummary,
    PresentationDefinition,
    PresentationMetadata,
    ScorecardRow,
    SlideDefinition,
    SlideType,
)


def _render(defn: PresentationDefinition) -> Presentation:
    brand = resolve_brand_config()
    with tempfile.TemporaryDirectory() as td:
        out = Path(td) / "t.pptx"
        DeckGenerator(brand=brand).generate(defn, out)
        return Presentation(str(out))


# ---------------------------------------------------------------------------
# Models
# ---------------------------------------------------------------------------


class TestExecutiveSummaryModel:
    def test_minimal_scr(self) -> None:
        s = ExecutiveSummary(
            situation="S", complication="C", resolution="R",
        )
        assert s.ask is None
        assert s.key_findings == []

    def test_full_scr(self) -> None:
        s = ExecutiveSummary(
            situation="Revenue flat at $42M for 3 quarters",
            complication="EU tariffs reduce Q1 margin 200bps",
            resolution="Shift 30% EU demand to APAC manufacturing",
            ask="Approve $8M capital allocation",
            key_findings=["Finding A", "Finding B", "Finding C"],
        )
        assert s.ask is not None
        assert len(s.key_findings) == 3


class TestScorecardModel:
    def test_default_amber(self) -> None:
        r = ScorecardRow(initiative="X")
        assert r.status == "amber"

    def test_valid_rag_only(self) -> None:
        import pytest
        from pydantic import ValidationError
        with pytest.raises(ValidationError):
            ScorecardRow(initiative="X", status="purple")


# ---------------------------------------------------------------------------
# Rendering
# ---------------------------------------------------------------------------


class TestExecutiveSummaryRendering:
    def test_renders_scr_bands(self) -> None:
        defn = PresentationDefinition(
            metadata=PresentationMetadata(title="T"),
            slides=[SlideDefinition(
                slide_type=SlideType.EXECUTIVE_SUMMARY,
                title="Q3 Summary",
                executive_summary=ExecutiveSummary(
                    situation="Revenue flat at $42M",
                    complication="EU tariffs hit Q1 margin",
                    resolution="Shift to APAC manufacturing",
                    ask="Approve $8M capex",
                ),
            )],
        )
        prs = _render(defn)
        text = " ".join(
            s.text_frame.text for s in prs.slides[0].shapes if s.has_text_frame
        )
        assert "Situation" in text
        assert "Complication" in text
        assert "Resolution" in text
        assert "Revenue flat" in text
        assert "EU tariffs" in text
        assert "APAC" in text
        assert "Recommendation:" in text
        assert "$8M capex" in text

    def test_renders_without_ask(self) -> None:
        defn = PresentationDefinition(
            metadata=PresentationMetadata(title="T"),
            slides=[SlideDefinition(
                slide_type=SlideType.EXECUTIVE_SUMMARY,
                title="Summary",
                executive_summary=ExecutiveSummary(
                    situation="S", complication="C", resolution="R",
                ),
            )],
        )
        prs = _render(defn)
        text = " ".join(
            s.text_frame.text for s in prs.slides[0].shapes if s.has_text_frame
        )
        assert "Recommendation:" not in text


class TestScorecardRendering:
    def test_renders_rag_pills(self) -> None:
        defn = PresentationDefinition(
            metadata=PresentationMetadata(title="T"),
            slides=[SlideDefinition(
                slide_type=SlideType.SCORECARD,
                title="Priorities",
                scorecard_rows=[
                    ScorecardRow(initiative="APAC expansion", owner="JS", status="green"),
                    ScorecardRow(initiative="EU consolidation", owner="MR", status="amber"),
                    ScorecardRow(initiative="PLM platform", owner="LC", status="red"),
                ],
            )],
        )
        prs = _render(defn)
        text = " ".join(
            s.text_frame.text for s in prs.slides[0].shapes if s.has_text_frame
        )
        assert "Initiative" in text  # header
        assert "APAC expansion" in text
        assert "GREEN" in text
        assert "AMBER" in text
        assert "RED" in text

    def test_empty_scorecard_still_renders_title(self) -> None:
        defn = PresentationDefinition(
            metadata=PresentationMetadata(title="T"),
            slides=[SlideDefinition(
                slide_type=SlideType.SCORECARD,
                title="Priorities",
            )],
        )
        prs = _render(defn)
        assert len(prs.slides) == 1


# ---------------------------------------------------------------------------
# Planner + content_mapper
# ---------------------------------------------------------------------------


class TestPlannerIntegration:
    def test_planner_creates_exec_summary(self) -> None:
        agent = SlidePlannerAgent()
        deck = agent.run(PlannerInput(
            topic="Strategic Review",
            num_slides=3,
            key_points=[
                "Revenue grew 23% but churn accelerated",
                "Product-market fit weakening in mid-market",
                "Refocus on enterprise segment by Q2",
            ],
            slides=[SlideSpec(slide_type=SlideType.EXECUTIVE_SUMMARY)],
        ))
        es = deck.slides[0].executive_summary
        assert es is not None
        assert "23%" in es.situation
        assert "mid-market" in es.complication
        assert "enterprise" in es.resolution

    def test_planner_creates_scorecard_with_variety(self) -> None:
        agent = SlidePlannerAgent()
        deck = agent.run(PlannerInput(
            topic="Quarterly Review",
            num_slides=3,
            key_points=[
                "Initiative Alpha: launching Q3",
                "Initiative Beta: delayed by vendor",
                "Initiative Gamma: at risk",
            ],
            slides=[SlideSpec(slide_type=SlideType.SCORECARD)],
        ))
        rows = deck.slides[0].scorecard_rows
        assert len(rows) == 3
        # Must include all three rows from key_points
        titles = [r.initiative for r in rows]
        assert any("Alpha" in t for t in titles)
        assert any("Beta" in t for t in titles)
        assert any("Gamma" in t for t in titles)

    def test_planner_placeholder_when_no_key_points(self) -> None:
        agent = SlidePlannerAgent()
        deck = agent.run(PlannerInput(
            topic="Blank",
            num_slides=3,
            slides=[SlideSpec(slide_type=SlideType.EXECUTIVE_SUMMARY)],
        ))
        es = deck.slides[0].executive_summary
        assert es is not None
        assert es.situation.startswith("[")  # bracket placeholder

    def test_content_mapper_routes_exec_summary(self) -> None:
        assert suggest_slide_type("Executive Summary") == SlideType.EXECUTIVE_SUMMARY
        assert suggest_slide_type("Situation-Complication-Resolution brief") == SlideType.EXECUTIVE_SUMMARY

    def test_content_mapper_routes_scorecard(self) -> None:
        assert suggest_slide_type("Strategic Priorities scorecard") == SlideType.SCORECARD
        assert suggest_slide_type("RAG status review") == SlideType.SCORECARD


# ---------------------------------------------------------------------------
# Describer
# ---------------------------------------------------------------------------


class TestDescriber:
    def test_describes_exec_summary(self) -> None:
        slide = SlideDefinition(
            slide_type=SlideType.EXECUTIVE_SUMMARY,
            title="Q3",
            executive_summary=ExecutiveSummary(
                situation="S", complication="C", resolution="R", ask="A",
            ),
        )
        desc = describe_slide(slide, 0)
        assert "Executive summary" in desc or "SCR" in desc
        assert "ask" in desc.lower()

    def test_describes_scorecard_with_rag_counts(self) -> None:
        slide = SlideDefinition(
            slide_type=SlideType.SCORECARD,
            title="T",
            scorecard_rows=[
                ScorecardRow(initiative="A", status="green"),
                ScorecardRow(initiative="B", status="green"),
                ScorecardRow(initiative="C", status="amber"),
                ScorecardRow(initiative="D", status="red"),
            ],
        )
        desc = describe_slide(slide, 0)
        assert "4 rows" in desc
        assert "2G/1A/1R" in desc
