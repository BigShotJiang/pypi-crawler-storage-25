"""Tests for Phase 1a executive-grade additions.

Covers:
- SlideDefinition.action_title + effective_title()
- Source fields on ChartElement, TableElement, KpiCard, MatrixData
- Source citation rendering in footer band
- check_action_titles review rule (deck-level)
- check_data_provenance review rule (slide-level)
"""

from __future__ import annotations

import tempfile
from pathlib import Path

from pptx import Presentation

from pptx_mcp.brand.config import resolve_brand_config
from pptx_mcp.engine.generator import DeckGenerator
from pptx_mcp.models.diagrams import MatrixData, MatrixQuadrant
from pptx_mcp.models.slides import (
    ChartData,
    ChartDataSeries,
    ChartElement,
    ChartType,
    KpiCard,
    PresentationDefinition,
    PresentationMetadata,
    SlideDefinition,
    SlideType,
    TableCell,
    TableElement,
)
from pptx_mcp.review.rules import check_action_titles, check_data_provenance


# ---------------------------------------------------------------------------
# action_title field + effective_title()
# ---------------------------------------------------------------------------


class TestActionTitle:
    def test_effective_title_prefers_action_title(self) -> None:
        s = SlideDefinition(
            slide_type=SlideType.CONTENT,
            title="Revenue",
            action_title="Revenue grew 23% YoY despite EU headwinds",
        )
        assert s.effective_title() == "Revenue grew 23% YoY despite EU headwinds"

    def test_effective_title_falls_back_to_title(self) -> None:
        s = SlideDefinition(slide_type=SlideType.CONTENT, title="Overview")
        assert s.effective_title() == "Overview"

    def test_effective_title_none_when_both_missing(self) -> None:
        s = SlideDefinition(slide_type=SlideType.BLANK)
        assert s.effective_title() is None

    def test_action_title_renders_on_slide(self) -> None:
        brand = resolve_brand_config()
        defn = PresentationDefinition(
            metadata=PresentationMetadata(title="Test"),
            slides=[
                SlideDefinition(
                    slide_type=SlideType.CONTENT,
                    title="Revenue",
                    action_title="Revenue grew 23% YoY despite EU headwinds",
                    bullets=["Point 1", "Point 2"],
                ),
            ],
        )
        with tempfile.TemporaryDirectory() as td:
            out = Path(td) / "t.pptx"
            DeckGenerator(brand=brand).generate(defn, out)
            prs = Presentation(str(out))
            text_blobs = [
                s.text_frame.text
                for s in prs.slides[0].shapes
                if s.has_text_frame
            ]
            assert any(
                "Revenue grew 23% YoY" in t for t in text_blobs
            ), "action_title must render on slide"
            # Original title should NOT be the rendered title
            assert not any(
                t.strip() == "Revenue" for t in text_blobs
            ), "bare title must not render when action_title is set"


# ---------------------------------------------------------------------------
# Source fields
# ---------------------------------------------------------------------------


class TestSourceFields:
    def test_chart_accepts_source(self) -> None:
        c = ChartElement(
            chart_type=ChartType.BAR,
            data=ChartData(
                categories=["A", "B"],
                series=[ChartDataSeries(name="S", values=[1.0, 2.0])],
            ),
            source="Source: Q3 filings",
        )
        assert c.source == "Source: Q3 filings"

    def test_table_accepts_source(self) -> None:
        t = TableElement(
            rows=[[TableCell(text="H1"), TableCell(text="H2")]],
            source="Internal finance dashboard",
        )
        assert t.source == "Internal finance dashboard"

    def test_kpi_accepts_source(self) -> None:
        k = KpiCard(value="$1.2M", label="MRR", source="Stripe, Nov 2025")
        assert k.source == "Stripe, Nov 2025"

    def test_matrix_accepts_source(self) -> None:
        q = MatrixQuadrant(label="X", items=["a"])
        m = MatrixData(
            top_left=q, top_right=q, bottom_left=q, bottom_right=q,
            source="BCG analysis",
        )
        assert m.source == "BCG analysis"

    def test_source_renders_under_chart_slide(self) -> None:
        brand = resolve_brand_config()
        chart = ChartElement(
            chart_type=ChartType.BAR,
            data=ChartData(
                categories=["A", "B"],
                series=[ChartDataSeries(name="S", values=[1.0, 2.0])],
            ),
            source="Q3 2025 filings",
        )
        defn = PresentationDefinition(
            metadata=PresentationMetadata(title="Test"),
            slides=[
                SlideDefinition(
                    slide_type=SlideType.CHART,
                    title="Revenue",
                    elements=[chart],
                ),
            ],
        )
        with tempfile.TemporaryDirectory() as td:
            out = Path(td) / "t.pptx"
            DeckGenerator(brand=brand).generate(defn, out)
            prs = Presentation(str(out))
            text_blobs = [
                s.text_frame.text
                for s in prs.slides[0].shapes
                if s.has_text_frame
            ]
            assert any("Source: Q3 2025 filings" in t for t in text_blobs), (
                f"source citation should render; got {text_blobs}"
            )

    def test_source_prefix_not_doubled(self) -> None:
        brand = resolve_brand_config()
        chart = ChartElement(
            chart_type=ChartType.BAR,
            data=ChartData(
                categories=["A"],
                series=[ChartDataSeries(name="S", values=[1.0])],
            ),
            source="Source: Bloomberg",  # already prefixed
        )
        defn = PresentationDefinition(
            metadata=PresentationMetadata(title="Test"),
            slides=[SlideDefinition(
                slide_type=SlideType.CHART, title="X", elements=[chart],
            )],
        )
        with tempfile.TemporaryDirectory() as td:
            out = Path(td) / "t.pptx"
            DeckGenerator(brand=brand).generate(defn, out)
            prs = Presentation(str(out))
            text_blobs = [
                s.text_frame.text
                for s in prs.slides[0].shapes
                if s.has_text_frame
            ]
            assert not any(
                "Source: Source:" in t for t in text_blobs
            ), "Source prefix must not double"


# ---------------------------------------------------------------------------
# check_action_titles rule
# ---------------------------------------------------------------------------


class TestActionTitleRule:
    def _brand(self):
        return resolve_brand_config()

    def test_flags_bare_noun_title(self) -> None:
        slides = [SlideDefinition(slide_type=SlideType.CONTENT, title="Revenue")]
        issues = check_action_titles(slides, self._brand())
        assert len(issues) == 1
        assert "topic label" in issues[0].message.lower()

    def test_accepts_verb_led_title(self) -> None:
        slides = [SlideDefinition(
            slide_type=SlideType.CONTENT,
            title="Revenue grew 23% YoY despite headwinds",
        )]
        issues = check_action_titles(slides, self._brand())
        assert issues == []

    def test_accepts_long_title(self) -> None:
        slides = [SlideDefinition(
            slide_type=SlideType.CONTENT,
            title="A more elaborate title with five or more words",
        )]
        issues = check_action_titles(slides, self._brand())
        assert issues == []

    def test_action_title_set_means_no_flag(self) -> None:
        slides = [SlideDefinition(
            slide_type=SlideType.CONTENT,
            title="Revenue",
            action_title="Revenue grew 23% YoY",
        )]
        issues = check_action_titles(slides, self._brand())
        assert issues == []

    def test_skips_exempt_types(self) -> None:
        slides = [
            SlideDefinition(slide_type=SlideType.TITLE, title="Overview"),
            SlideDefinition(slide_type=SlideType.SECTION, title="Finance"),
            SlideDefinition(slide_type=SlideType.AGENDA, title="Agenda"),
            SlideDefinition(slide_type=SlideType.CLOSING, title="Thank You"),
            SlideDefinition(slide_type=SlideType.QUOTE, title="Quote"),
        ]
        issues = check_action_titles(slides, self._brand())
        assert issues == []


# ---------------------------------------------------------------------------
# check_data_provenance rule
# ---------------------------------------------------------------------------


class TestDataProvenanceRule:
    def _brand(self):
        return resolve_brand_config()

    def _chart(self, source=None) -> ChartElement:
        return ChartElement(
            chart_type=ChartType.BAR,
            data=ChartData(
                categories=["A"],
                series=[ChartDataSeries(name="S", values=[1.0])],
            ),
            source=source,
        )

    def test_warns_chart_without_source(self) -> None:
        slide = SlideDefinition(
            slide_type=SlideType.CHART,
            title="X",
            elements=[self._chart()],
        )
        issues = check_data_provenance(slide, 0, self._brand())
        assert len(issues) == 1
        assert "source" in issues[0].message.lower()

    def test_accepts_chart_with_source(self) -> None:
        slide = SlideDefinition(
            slide_type=SlideType.CHART,
            title="X",
            elements=[self._chart(source="Bloomberg")],
        )
        issues = check_data_provenance(slide, 0, self._brand())
        assert issues == []

    def test_accepts_footnote_source(self) -> None:
        slide = SlideDefinition(
            slide_type=SlideType.CHART,
            title="X",
            elements=[self._chart()],
            footnotes=["Source: internal data"],
        )
        issues = check_data_provenance(slide, 0, self._brand())
        assert issues == []

    def test_non_data_slide_not_flagged(self) -> None:
        slide = SlideDefinition(slide_type=SlideType.CONTENT, title="Narrative")
        issues = check_data_provenance(slide, 0, self._brand())
        assert issues == []

    def test_dashboard_without_kpi_source_flagged(self) -> None:
        slide = SlideDefinition(
            slide_type=SlideType.DASHBOARD,
            title="Dashboard",
            kpis=[KpiCard(value="47%", label="Growth")],
        )
        issues = check_data_provenance(slide, 0, self._brand())
        assert len(issues) == 1

    def test_dashboard_with_kpi_source_not_flagged(self) -> None:
        slide = SlideDefinition(
            slide_type=SlideType.DASHBOARD,
            title="Dashboard",
            kpis=[KpiCard(value="47%", label="Growth", source="Internal")],
        )
        issues = check_data_provenance(slide, 0, self._brand())
        assert issues == []
