"""Tests for the pptx_mcp.icons registry (v0.11.0)."""

from __future__ import annotations

from pptx_mcp.icons import (
    ICON_PACKS,
    is_registered_icon,
    list_available_icons,
    resolve_icon_path,
)


class TestRegistryShape:
    def test_lucide_is_registered(self) -> None:
        assert "lucide" in ICON_PACKS


class TestIsRegisteredIcon:
    def test_known_pack_returns_true(self) -> None:
        assert is_registered_icon("lucide:target") is True

    def test_unknown_pack_returns_false(self) -> None:
        assert is_registered_icon("heroicons:star") is False

    def test_no_prefix_returns_false(self) -> None:
        assert is_registered_icon("target") is False

    def test_emoji_returns_false(self) -> None:
        assert is_registered_icon("\u2b50") is False

    def test_empty_returns_false(self) -> None:
        assert is_registered_icon("") is False


class TestResolveIconPath:
    def test_unknown_pack_returns_none(self) -> None:
        assert resolve_icon_path("heroicons:star") is None

    def test_no_prefix_returns_none(self) -> None:
        assert resolve_icon_path("target") is None

    def test_empty_returns_none(self) -> None:
        assert resolve_icon_path("") is None

    def test_missing_file_returns_none(self) -> None:
        # lucide is registered but no files bundled yet
        assert resolve_icon_path("lucide:nonexistent-icon-name") is None

    def test_does_not_raise_for_weird_input(self) -> None:
        # Must be robust to odd inputs
        assert resolve_icon_path(":") is None
        assert resolve_icon_path("lucide:") is None


class TestListAvailableIcons:
    def test_returns_list(self) -> None:
        result = list_available_icons()
        assert isinstance(result, list)

    def test_handles_unknown_pack(self) -> None:
        assert list_available_icons(pack="nonexistent") == []

    def test_handles_missing_pack_dir(self) -> None:
        # lucide pack dir may or may not have files — shouldn't raise
        result = list_available_icons(pack="lucide")
        assert isinstance(result, list)
