# Prompt 2: Consulting Transformation Roadmap

## Instructions for AI

Create a 14-slide consulting deck for a **supply chain digital transformation** engagement. Use `plan_presentation` → `create_from_plan` workflow with brand_preset="consulting" and deck_type="transformation_roadmap".

**Topic**: Digital Supply Chain Transformation — GlobalMed Pharmaceuticals

**Company**: Apex Consulting Group (the consulting firm)

**Audience**: C-suite at GlobalMed Pharmaceuticals (executive)

**Key Points**:
- GlobalMed's supply chain has 23 distribution centers across 14 countries with $4.8B in annual logistics spend
- Current state: 67% manual processes, 3 disconnected ERP systems, 12-day average order-to-delivery cycle
- Target state: AI-driven demand forecasting, real-time inventory visibility, automated cold-chain compliance
- Phase 1 (Q3-Q4 2026): Control tower deployment + data lake consolidation — $3.2M investment, 8% logistics cost reduction
- Phase 2 (Q1-Q2 2027): Predictive analytics + automated replenishment — $4.1M investment, 15% inventory reduction
- Phase 3 (Q3 2027-Q1 2028): Autonomous planning + supplier integration — $5.8M investment, 22% cycle time reduction
- Total investment: $13.1M over 18 months with projected $47M in annual savings by Year 3
- Risk factors: Legacy system integration complexity, cold-chain regulatory requirements (FDA, EMA), change management across 14 country operations
- Benchmark: Similar pharma transformations (Pfizer, Roche) achieved 20-30% logistics cost reduction

**Context**: This is the final readout to the GlobalMed CEO and CFO. The deck must be structured like a top-tier strategy firm deliverable — data-heavy, framework-driven, with clear executive actions at the end. Every claim needs a supporting data point. Use the MECE principle for categorization.

---

## Expected Slide Structure

| # | Type | Title | Key Content |
|---|------|-------|-------------|
| 1 | TITLE | Digital Supply Chain Transformation | GlobalMed Pharmaceuticals — Final Readout |
| 2 | AGENDA | Agenda | Situation, Assessment, Roadmap, Investment, Risks, Next Steps |
| 3 | SECTION | Current State Assessment | Divider slide |
| 4 | DASHBOARD | Supply Chain Performance Snapshot | KPIs: $4.8B spend, 23 DCs, 12-day cycle, 67% manual |
| 5 | SWOT | Strategic Assessment | Strengths/Weaknesses/Opportunities/Threats for GlobalMed SC |
| 6 | SECTION | Transformation Roadmap | Divider slide |
| 7 | TIMELINE | Three-Phase Roadmap | Phase 1 (Control Tower), Phase 2 (Analytics), Phase 3 (Autonomous) |
| 8 | PROCESS | Phase 1: Control Tower Deployment | Steps: Data consolidation → Platform build → Pilot → Scale |
| 9 | TABLE | Investment & Returns by Phase | 3 phases × columns: Investment, Timeline, Key Deliverable, Projected Savings |
| 10 | CHART | Cumulative ROI Projection | Bar chart: investment vs. cumulative savings over 3 years |
| 11 | COMPARISON | Current State vs. Target State | Side-by-side: manual vs automated, disconnected vs integrated |
| 12 | PROS_CONS | Risk Assessment | Risks (integration, regulatory, change mgmt) vs. Mitigations |
| 13 | STEP_CARDS | Immediate Next Steps | 4 action items with owners and deadlines |
| 14 | CLOSING | Thank You | Contact info, Apex Consulting Group |
