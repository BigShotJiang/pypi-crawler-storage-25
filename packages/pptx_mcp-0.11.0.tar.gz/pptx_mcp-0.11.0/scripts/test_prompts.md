# Visual QA Test Prompts for pptx-mcp

Feed these prompts to any Claude project with pptx-mcp MCP tools connected.
Each prompt exercises specific feature areas.

---

## Prompt 1: Full Diagram Suite
**Tests:** All 8 diagram types, consulting preset, data-heavy slides

> Create a 10-slide strategy consulting deck for "Apex Partners" analyzing a client's digital transformation. Use the consulting preset.
>
> Include these specific diagram slides:
> - **Org chart**: CEO Maria Santos, 3 direct reports (CTO, CFO, COO), each with 2 directors underneath
> - **2x2 Matrix**: Prioritize 6 initiatives on Impact (y-axis) vs Effort (x-axis). Quick wins: "SSO Integration", "API Monitoring". Strategic bets: "Cloud Migration", "ML Pipeline". Fill-ins: "Docs Refresh". Avoid: "Full Rewrite"
> - **Pyramid**: 4-layer strategy — Vision (top), Strategy, Capabilities, Execution (bottom)
> - **Venn diagram**: 3 circles — Technology, People, Process — intersecting at "Digital Maturity"
> - **Waterfall chart**: Operating profit bridge — Start $12M, new revenue +$4.2M, cost savings +$1.8M, restructuring -$2.1M, investments -$1.5M, End $14.4M
> - **Gantt chart**: 5 workstreams over 12 months with varying progress percentages
> - **Cycle diagram**: Plan → Build → Test → Deploy → Monitor (5 steps)
> - **Hub-spoke**: "Data Platform" at center, 5 spokes: Ingestion, Storage, Processing, Analytics, Governance
>
> Save to ~/Desktop/test_diagrams.pptx

---

## Prompt 2: Brand Comparison & Designer Features
**Tests:** Multiple presets, edge bars, shadows, callouts, gradient backgrounds, brand guide generation

> I need to compare 3 brand styles for a startup pitch. Do the following:
>
> 1. First, generate a brand guide for the "startup" preset and save to ~/Desktop/test_brand_guide.pptx
>
> 2. Then create a 6-slide pitch deck for "NovaSpark AI" (an AI-powered customer analytics platform) with these slides:
>    - Title slide with gradient background
>    - Dashboard with 4 KPIs: "$2.1M ARR", "340 Customers", "127% Net Retention", "4.8 Rating"
>    - Card grid with 3 product features (each with icon, title, description, and a badge)
>    - Process slide: 4-step customer journey (Onboard → Integrate → Analyze → Scale)
>    - Content slide with a "success" callout box highlighting a customer win
>    - Closing slide with CTA "Start Free Trial" and contact info
>
> Generate this deck 3 times with different presets:
> - ~/Desktop/test_startup_preset.pptx (startup preset)
> - ~/Desktop/test_creative_preset.pptx (creative preset)
> - ~/Desktop/test_minimal_preset.pptx (minimal preset)

---

## Prompt 3: Data-Heavy Charts Deck
**Tests:** All 12 chart types, technical preset, chart data models

> Create a 14-slide analytics report for "DataStream Corp" using the technical preset.
>
> Include one slide for each chart type with realistic data:
> - **Bar chart**: Monthly active users by region (Americas, EMEA, APAC) for 6 months
> - **Line chart**: Revenue trend over 8 quarters showing growth trajectory
> - **Pie chart**: Market share breakdown — DataStream 34%, CompetitorA 28%, CompetitorB 19%, Others 19%
> - **Column chart**: Feature adoption rates for 5 product features
> - **Area chart**: Cumulative customer growth over 12 months
> - **Scatter chart**: Customer satisfaction score vs usage hours (two clusters)
> - **Bubble chart**: Product portfolio — x=market size, y=growth rate, size=our market share
> - **Radar chart**: Compare two products across 6 dimensions (speed, reliability, ease of use, price, support, features)
> - **Doughnut chart**: Revenue by product line (4 segments)
> - **Stacked bar**: Quarterly expenses by category (Engineering, Sales, Marketing, Operations)
> - **Stacked column**: Headcount by department over 4 quarters
> - **Combo chart**: Revenue (bars) vs profit margin % (line) over 6 months
>
> Also include a title slide and a closing slide.
> Save to ~/Desktop/test_all_charts.pptx

---

## Prompt 4: Edit & Review Workflow
**Tests:** read_presentation, review_presentation, add_slide, update_slide, modify_element, list_slide_elements

> I have an existing deck at ~/Desktop/test_startup_preset.pptx (generate one first if it doesn't exist — 5-slide pitch deck for "NovaSpark AI" using startup preset).
>
> Now do the following edit workflow:
> 1. Read the presentation and tell me what's in it
> 2. Review it and show me the score and top issues
> 3. Add a new SWOT slide at position 3 with:
>    - Strengths: "AI-first architecture", "Strong NPS (72)", "Low churn"
>    - Weaknesses: "Small sales team", "Single product", "Limited enterprise features"
>    - Opportunities: "Enterprise market entry", "International expansion", "Platform play"
>    - Threats: "Well-funded competitors", "AI regulation risk", "Talent war"
> 4. List the elements on slide 0 (title slide)
> 5. Review again and compare scores
>
> Save the edited version to ~/Desktop/test_edited.pptx

---

## Prompt 5: Markdown Spec → Large Deck
**Tests:** parse_spec tool, plan_presentation, large deck generation, archetype system

> Use plan_presentation to create a 20-slide annual report for "Meridian Technologies" using the executive preset. Use the "annual_report" deck archetype.
>
> Key data for the report:
> - FY2025 revenue: $189M (up 34% YoY)
> - Gross margin: 74% (up from 68%)
> - Net income: $28M
> - Employees: 486 (grew from 312)
> - Products: 4 product lines
> - Customers: 2,400+ enterprise accounts
> - NPS: 72
> - R&D spend: 31% of revenue
>
> After planning, inspect slide 5 using get_plan_slide, then render it with create_from_plan.
> Save to ~/Desktop/test_annual_report.pptx
>
> Then review the final deck and tell me the score.
