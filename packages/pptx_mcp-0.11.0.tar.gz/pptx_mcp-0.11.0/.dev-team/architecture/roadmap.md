# Roadmap

## Completed

### Phase 1 — Core Enhancements
- Column ratio (asymmetric two-column)
- Background gradients (2-5 color linear)
- Alternate row shading (zebra-stripe tables)
- Custom color tokens on ColorPalette
- Spec parser (markdown → PresentationDefinition)

### Phase 2 — Rich Visual Elements
- Badge model (pill-shaped labels)
- CardDefinition model (rich cards)
- CalloutBox model (info/warning/success)
- CARD_GRID slide type
- Callout on any slide type
- Spec parser: card blocks + callout blocks

### Phase 3 — Gap Filling & Analysis
- CARD_GRID in planner + content mapper + parser
- GroupElement recursive rendering
- Review rules: comprehensive _gather_text + check_card_count
- Slide describer module (natural-language summaries)
- analyze_presentation MCP tool
- .dev-team agent memory infrastructure

### Phase 4 — Fidelity Fixes (from spec-vs-output analysis)
- P0-1: Content slide multi-column rendering (3-6 columns)
- P0-1: Content slide subtitle rendering
- P0-2: Title slide parser classification (round-trip fidelity)
- P1-2: Configurable accent bar (show_accent_bar on ShapeStyleConfig)
- P1-3: Shape border-only rendering (stroke without fill)
- P2-1: title_style / subtitle_style overrides on SlideDefinition
- P2-4: BulletList per-element style priority
- P3-1: Parser extracts textbox fill colors
- P3-2: Parser detects shape types (12 auto shapes via reverse map)
- P3-2: Parser extracts shape fill_color, border_color, border_width
- P3-3: Parser extracts table cell fill_color and text style
- Parser: empty-text auto shapes collected as ShapeElements (gap fix)
- Tests: 27 new tests (453 total, 0 failures)

## Future Ideas
- Animation/transition presets per slide type
- Master slide template support
- Multi-language text support
- PDF export via LibreOffice
- Image generation integration
- Collaboration features (comments, change tracking)
- Theme marketplace / community presets
