# Slide Type Lifecycle

How each of the 24 SlideTypes flows through the system:

## Pipeline Stages

1. **Model** (`models/slides.py`): Enum value + optional fields on SlideDefinition
2. **Planner** (`agents/planner.py`): `_create_skeleton_slide()` handler generates content
3. **Content Mapper** (`agents/content_mapper.py`): Keyword → SlideType suggestion
4. **Generator** (`engine/generator.py`): `_render_slide()` dispatches to layout renderer
5. **Layout** (`engine/layouts.py`): `render_*_slide()` function creates shapes
6. **Parser** (`engine/parser.py`): `_classify_slide()` + `_keyword_classify()` detect type from PPTX
7. **Describer** (`engine/describer.py`): `describe_slide()` generates natural-language summary
8. **Reviewer** (`review/rules.py`): `_gather_text()` + type-specific rules

## Adding a New Slide Type

1. Add enum value to `SlideType`
2. Add optional fields to `SlideDefinition` if needed
3. Add handler in `_create_skeleton_slide()` (planner)
4. Add keyword pattern to `content_mapper._PATTERNS`
5. Add renderer in `layouts.py` + register in `generator._render_slide()`
6. Add title keywords in `parser._TITLE_KEYWORDS` + check in `_keyword_classify()`
7. Add description in `describer._TYPE_DESCRIPTIONS` + detail in `_build_detail()`
8. Extend `_gather_text()` in rules if new fields added
9. Add tests for each stage
