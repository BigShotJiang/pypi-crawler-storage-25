# v1.0 Roadmap: Leadership-Ready, Token-Efficient, Adaptable

## Vision

Move pptx-mcp from "competent operational deck generator" to a tool that produces **board-room-ready** decks by default — with executive discipline (action titles, source citations, MECE structure), token-efficient workflows, and visual polish that stands up against Gamma / Beautiful.ai / Pitch.

Grounded in a three-lens audit (design quality, executive/leadership, non-leadership breadth) completed 2026-04-14. Full audit findings and file:line evidence in `.dev-team/audit-2026-04-14.md` (to be created).

---

## Current State (v0.9.1)

- 32 SlideTypes, 12 ChartTypes, 27 deck archetypes, 12 brand presets
- 42 MCP tools, 10 prompts, 2 resources
- Element editing, spatial validation, plan cache workflow
- Review engine with 26 rules (mechanics, contrast, brand compliance)
- Layout variants system (3 groups: structured_content, sequential_steps, grids)
- 1,289 tests passing

### Known gaps (from 2026-04-14 audit)

**Design quality:** 6 of 12 presets ship accent colors failing WCAG 4.5:1 on white. Type scale ratios are non-musical. `base_unit_pt` is defined but never consumed. Icons are raw emoji. No masters/themes — every slide drawn imperatively (2,215 lines in `layouts.py`). No image treatment (masks, duotone, overlays).

**Executive grade:** No action-title convention (titles are bare nouns). No source-citation binding on charts/tables/KPIs. Planner hydrates DASHBOARD with hardcoded fake metrics ("87% Progress, 12/15 Completion") and fake quotes attributed to "Industry Expert". `executive_default` preset lacks slide numbers and confidential marking. No EXECUTIVE_SUMMARY, SCORECARD, SENSITIVITY_TABLE, TORNADO, HEATMAP, BRIDGE slide types. Review engine catches mechanics but not structure (MECE, pyramid, parallelism).

**Breadth:** Missing TESTIMONIAL, PRICING_TABLE, LOGO_WALL, FULL_BLEED_HERO, BEFORE_AFTER, REFERENCES slide types. Academic, clinical, fundraising archetypes absent. `creative` preset doesn't feel creative; `corporate` is near-duplicate of `executive`.

---

## Guiding Principles

1. **Token-efficient by default.** Every new tool accepts IDs (plan_id, slide_index) over full objects; returns compact summaries. Model on the success of `plan_cache`.
2. **Adaptable by design.** Every new slide type joins a variant group so planner can swap without content loss.
3. **Leadership-grade is a test, not a claim.** Each phase is gated against fixture decks with a "would a partner hand this to a board?" review.
4. **Ship thin slices.** Every phase produces a shippable `v0.x.y` with release notes.

---

## Explicitly Out of Scope

- **Merging `corporate` + `executive` presets.** Revisit after Phase 4 signature pass — distinct fingerprints may resolve redundancy.
- **AI image generation / stock-image library.** Out of scope for an MCP server; users bring their own assets.

---

## Cross-Cutting Tracks (run in parallel to phases)

### Track A — Token Efficiency

- Audit every tool's input/output token cost on 10 fixture decks. Document in `docs/token-costs.md`.
- Deprecate `optimize_design` (8-50K tokens round-trip); route to `optimize_plan` (plan_id → diff summary).
- **Slide-ref pattern** — tools on existing decks take `(plan_id, slide_index)` or `(file_path, slide_index)` and return only diffs.
- **Streaming review findings** — emit incrementally instead of one fat JSON.
- **Slot-descriptor plans** — planner emits slot descriptors (type + hint), hydrates on render. ~60% reduction in plan payload.
- **Token-budget mode** — `token_mode: "strict" | "normal"` kwarg auto-selects plan workflow, summary_only reviews, slot-descriptor hydration.
- Deprecate `return_full_json=True` entirely in Phase 3.

### Track B — Adaptability (Variant Expansion)

Extend `engine/variants.py` from 3 groups to 8:

- `social_proof` — QUOTE ↔ TESTIMONIAL ↔ LOGO_WALL
- `data_tables` — TABLE ↔ PRICING_TABLE ↔ SENSITIVITY_TABLE ↔ SCORECARD
- `exec_openers` — TITLE ↔ EXECUTIVE_SUMMARY ↔ BIG_NUMBER
- `media_hero` — IMAGE_TEXT ↔ FULL_BLEED_HERO ↔ BEFORE_AFTER
- `learning` — CONTENT ↔ QUIZ ↔ KNOWLEDGE_CHECK

Planner proposes variants when confidence is low; `get_layout_variants` exposes choices.

### Track C — Quality Gates (CI-enforceable)

New `tests/test_quality_gates.py` renders one fixture deck per archetype and asserts:

- All accents pass WCAG 4.5:1 on their background
- Type scale ratios fall within [1.2, 1.414] and are monotonic
- Spacing values are multiples of `base_unit_pt`
- No slide title is a bare noun (action-title check) for exec archetypes
- Every CHART/TABLE has a `source` field populated

Block release if any gate fails.

---

## Phase 0 — Foundations → v0.9.2 (Week 1)

**Goal:** Stop shipping broken defaults. Make token costs visible.

| Task | File | Effort |
|---|---|---|
| Fix failing accent contrast in 6 presets | `brand/defaults.py` lines 30, 156, 202, 248, 414, 508, 564 | 30 min |
| Add `header_footer` to `executive_default` | `brand/defaults.py:18-64` | 5 min |
| Split `line_spacing` → `heading_line_height` / `body_line_height` / `caption_line_height` | `models/brand.py:59` | 2 hr |
| Enforce `base_unit_pt` snapping via Pydantic validator | `models/brand.py` `SpacingConfig` | 2 hr |
| Call `ensure_readable_text_color()` in diagram renderers | `engine/diagrams/*.py` | 1 hr |
| Add `docs/token-costs.md` with measured costs per tool | new | 4 hr |
| Add `tests/test_quality_gates.py` skeleton + 3 gates | new | 4 hr |

**Exit criteria:** All 12 presets pass WCAG 4.5:1. Quality gate CI is green.

---

## Phase 1 — Executive Grade → v0.10.0 (Weeks 2–3)

**Highest-leverage phase.** Everything downstream is cosmetic without this.

### 1a. The Three Disciplines (P0)

**Action titles**
- `SlideDefinition.action_title: str | None` in `models/slides.py`
- Planner emits sentence-case verb-led titles from `key_points`
- Review rule `check_action_titles` flags noun-only titles on exec archetypes

**Source citations**
- Add `source: str | None` to `ChartElement`, `TableElement`, `KpiCard`, `MatrixData`
- Renderer auto-places 8pt italic under the element
- Review rule `check_data_provenance` warns missing sources on data slides

**Archetype-specific hydration**
- Delete generic filler in `agents/planner.py:580-725`
- Replace with `_hydrate_board_deck`, `_hydrate_quarterly_earnings`, `_hydrate_due_diligence`, etc.
- When data isn't provided: emit `"N/A — supply via key_points"` placeholders, never fake numbers or attributed quotes

### 1b. Executive Slide Types (P0)

- `EXECUTIVE_SUMMARY` — SCR structure (situation/complication/resolution/ask)
- `SCORECARD` — initiative × owner × target × RAG status pill
- Wire into `board_deck`, `strategy_deck`, `due_diligence`

### 1c. Exec Preset Polish

- Extend `board_deck` slot list to 14-16 slots in `agents/archetypes.py:49-66`
- Add: prior-actions tracker, CEO message, segment P&L, cash/liquidity, capital allocation, ESG/governance, appendix divider
- Make SWOT optional (it's an analysis tool, not a board artefact)

**Exit criteria:** Hand-review rendered `board_deck` and `strategy_deck`. Fails if content reads AI-generated or titles are bare nouns.

---

## Phase 2 — Breadth Unlock → v0.11.0 (Weeks 4–5)

**Goal:** Six new slide types that unlock ~10 archetypes.

| Slide type | Primary archetypes served | Effort |
|---|---|---|
| `TESTIMONIAL` | sales, case_study, product_launch, fundraising | 1 day |
| `PRICING_TABLE` | sales, product_launch | 1 day |
| `LOGO_WALL` | sales, pitch, all_hands | 0.5 day |
| `FULL_BLEED_HERO` | conference_talk, product_launch, portfolio | 1 day |
| `BEFORE_AFTER` | case_study, training, product_launch | 0.5 day |
| `REFERENCES` | academic, clinical, due_diligence | 0.5 day |

Each type delivers: Pydantic model → layout renderer → planner skeleton → content_mapper regex → describer entry → review rule coverage → variant group membership → fixture test.

**Also in Phase 2:** `SpeakerInfo` optional block on TITLE (name/title/org/avatar/socials) — unblocks conference talks, keynotes, fundraising.

**Icon library (pulled forward from Phase 5):** Emoji rendering in Office on Windows is genuinely bad and undermines Phase 2 polish. Ship a curated SVG icon registry (lucide/tabler, ~100 icons) in `pptx_mcp/assets/icons/`. `IconItem.icon = "lucide:target"` resolves to EMF/PNG. Review rule warns on emoji codepoints.

**Exit criteria:** Each P0 archetype from Lens 3 rates ≥ Adequate.

---

## Phase 3 — Intelligence → v0.12.0 (Weeks 6–7)

**Goal:** The review engine gets opinionated about structure, not just mechanics.

### MECE & pyramid validators

- `check_bucket_count` — warn 2 or 7+ buckets on COMPARISON/CARD_GRID
- `check_title_supports_body` — title contains a verb AND ≥1 noun from bullets
- `check_parallelism` — bullet structures consistently start with verb or noun
- `check_deck_color_budget` — ≤7 distinct non-neutrals across the whole deck
- `check_title_position_consistency` — title y-variance < 0.1" across slides

### New exec data-shape slide types (P1)

- `SENSITIVITY_TABLE` — assumption × scenario heatmap
- `TORNADO_CHART` — sorted horizontal impact bars
- `HEATMAP` — risk × likelihood
- `BRIDGE` — financial waterfall variant with volume/price/mix/FX columns

### Financial table primitives

- `TableCell.number_format`, `TableCell.variance_color`
- `TableStyle.total_row_bold`, `total_row_top_border`
- Helper `build_financial_table(actuals, budget, py, fx_adj)` → canonical income-statement shape

**Exit criteria:** Fixture `quarterly_earnings` deck renders with variance-colored table + sensitivity slide and passes MECE validators.

---

## Phase 4 — Long-Tail Archetypes → v0.13.0 (Weeks 8–9)

**Goal:** Serve academic, clinical, fundraising, training, design-review audiences.

### New archetypes

- `research_paper`, `clinical_study`, `fundraising_deck`, `impact_report`, `workshop`, `design_review`, `keynote`

### New P1 slide types

- `QUIZ`, `KNOWLEDGE_CHECK`, `EXERCISE`
- `PERSONA_CARD`, `USER_JOURNEY`, `MOCKUP_GRID`
- `IMPACT_METRIC`, `BENEFICIARY_STORY`, `QA_SLIDE`

### Preset signature pass

Give each of the 12 presets a distinctive shape fingerprint (edge_bar direction + divider style + corner_radius combo) so one slide identifies the preset. Addresses "creative doesn't feel creative" and "corporate ≈ executive" problems.

**Decision point:** After Phase 4, re-evaluate whether `corporate` should be merged with `executive` or kept distinct. If signature pass gives `corporate` a distinct Garamond/navy/gold identity vs executive's Aptos/amber, keep both.

---

## Phase 5 — Strategic → v1.0.0 (Month 3+)

**Goal:** Platform-grade visual quality. Biggest single refactor — don't start until Phases 1–3 are locked.

- **SlideMaster/SlideLayout pipeline** — generate real `.pptx` themes with 3–5 master layouts per brand preset. Enables in-PowerPoint theme recolor. Retire most of imperative `engine/layouts.py` (2,215 lines) in favor of placeholder population.
- **Image treatment system** — `ImageElement.mask`, `overlay_color`, `overlay_opacity`, `duotone`. PIL preprocessing.
- **Proportional type-scale engine** — `TypeScale(base, ratio)` with 3 presets (compact 1.2, comfortable 1.25, editorial 1.333).
- **Dark-mode palette variants** — `ColorPalette.dark: ColorPalette`.
- **Responsive 4:3 / 16:9 / 16:10** — parameterize `LayoutGrid` (`engine/composition.py:81`).
- **Gradient presets** — named `gradient_primary`, `gradient_hero` on palette.

---

## Risk & Sequencing Notes

- **Phase 1 is non-negotiable first.** Everything else is cosmetic without action titles + sources + real hydration. Shipping Phase 2 before Phase 1 broadens surface area of a tool that still reads as AI-generated.
- **Phase 5 is the biggest refactor.** Don't start until Phases 1–3 are locked. It touches `layouts.py` heavily and will conflict with any in-flight layout additions.
- **Quality gates land in Phase 0.** Otherwise regressions in Phases 1–4 go unnoticed until a user complains.
- **Icon library pulled forward to Phase 2** (was originally Phase 5) — emoji rendering quality undermines everything above it.
- **Regenerate `examples/` at each phase boundary** — commit rendered fixture `.pptx` files as review artifacts, not just code.

---

## Token Efficiency Targets

| Intervention | Savings | Phase |
|---|---|---|
| Deprecate `optimize_design`, route to `optimize_plan` only | 8-50K tokens/call | 0 |
| Slot-descriptor plans (hydrate-on-render) | ~60% on plan payload | 1 |
| Streaming review findings | avoid 2-8K review blob | 2 |
| `modify_by_ref(plan_id, slide_index, diff)` pattern | 90%+ vs re-sending slide | 1 |
| Compact describer output (one-line per slide) | review-before-edit without full read | 2 |
| Deprecate `return_full_json=True` | forces compact path | 3 |

---

## Version Map

| Version | Phase | Theme |
|---|---|---|
| v0.9.2 | Phase 0 | Foundations, CI quality gates |
| v0.10.0 | Phase 1 | Executive grade — action titles, sources, EXEC_SUMMARY |
| v0.11.0 | Phase 2 | Breadth — 6 new slide types, icon library |
| v0.12.0 | Phase 3 | Intelligence — MECE validators, exec data-shape types |
| v0.13.0 | Phase 4 | Long-tail archetypes, preset signature pass |
| v1.0.0 | Phase 5 | Masters/themes, image treatment, strategic polish |
