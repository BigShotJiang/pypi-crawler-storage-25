# ADR-004: Composition Grid System

**Status:** Accepted
**Date:** 2025-02-01

## Context

Dashboard, icon grid, and card grid layouts need responsive item positioning that adapts to varying item counts.

## Decision

- `LayoutGrid` in `engine/composition.py` computes responsive grid layouts
- `auto_layout(count, area)` returns list of Position objects
- Grid adapts columns based on item count (2→2col, 3→3col, 4→2x2, etc.)
- Used by dashboard, icon_grid, and card_grid renderers
- `_style_card(shape, brand)` helper applies corner radius + optional shadow

## Consequences

- Consistent card positioning across all grid-based layouts
- Easy to add new grid-based slide types
