# ADR-001: FastMCP Tool Registration Pattern

**Status:** Accepted
**Date:** 2025-01-15

## Context

The MCP server needs to expose tools that LLM clients can discover and call. FastMCP provides a decorator-based registration system.

## Decision

- Use `@mcp.tool()` decorators on plain functions in `server.py`
- Use `instructions=` kwarg for server-level description (NOT `description=`)
- Accept Pydantic models directly as tool parameters — FastMCP handles deserialization
- Use `ToolError` from `mcp.server.fastmcp.exceptions` for MCP-level errors
- Keep all tools in a single `server.py` file for discoverability

## Alternatives

- **Class-based tools**: More structure but heavier boilerplate
- **Multiple server files**: Better separation but harder to discover all tools

## Consequences

- Simple, flat tool registration
- Single file may grow large (currently 19 tools)
- Tests need FastMCP init patching for cross-version compatibility
