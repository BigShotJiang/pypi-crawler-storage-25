# ADR-007: Analyze Presentation Tool

**Status:** Accepted
**Date:** 2025-02-13

## Context

`read_presentation` returns raw JSON — useful for machines but not for understanding what's in a deck. Users and LLM agents need natural-language descriptions and actionable analysis.

## Decision

- New `describer.py` module: pure functions, no LLM calls
- `describe_slide()`: type-specific one-sentence descriptions
- `describe_presentation()`: structured analysis with content inventory, type distribution, narrative assessment, recommendations
- New `analyze_presentation` MCP tool combining parser + describer + review engine
- Returns: title, slide_count, overall_score, slide_descriptions, content_inventory, type_distribution, narrative_assessment, recommendations

## Consequences

- LLM agents can understand deck content without parsing raw JSON
- Enables smarter editing decisions based on analysis
