# ADR-003: Brand Preset System

**Status:** Accepted
**Date:** 2025-01-20

## Context

Presentations need consistent visual identity. Users need easy brand application without crafting full config objects.

## Decision

- 6 built-in presets: executive, technical, minimal, creative, corporate, consulting
- BrandConfig model with nested configs: colors, fonts, spacing, layout rules, header/footer, shape styles
- `resolve_brand_config(preset=, path=)` resolves from preset name or YAML/JSON file
- `consulting` preset adds: shadows, slide numbers, CONFIDENTIAL marking
- HeaderFooterConfig: slide numbers, date, company name, confidential marking
- ShapeStyleConfig: corner radius, shadows, border width

## Consequences

- Users can switch visual identity with a single parameter
- Custom brands via YAML/JSON for advanced use
