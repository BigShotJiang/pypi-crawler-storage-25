# ADR-002: Pydantic Slide Models

**Status:** Accepted
**Date:** 2025-01-15

## Context

Presentations need a structured schema to define slides, elements, and metadata. The schema must be serializable to JSON for MCP transport and validatable.

## Decision

- Use Pydantic v2 BaseModel for all models
- SlideType enum with 24 values drives type-specific rendering
- SlideDefinition is the universal slide container — optional fields per type
- Discriminated union for SlideElement via `type` field
- Hyperlink validation: only http://, https://, mailto: schemes allowed

## Alternatives

- **TypedDict**: Lighter but no validation
- **Separate classes per slide type**: Type-safe but explosion of classes

## Consequences

- Single SlideDefinition handles all 24 types (many optional fields)
- Easy serialization via model_dump_json()
- New slide types only need enum value + optional fields
