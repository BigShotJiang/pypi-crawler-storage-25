# ADR-006: Card Grid and Callout Box

**Status:** Accepted
**Date:** 2025-02-10

## Context

Phase 2 needed richer visual elements: card grids for services/capabilities and callout boxes for warnings/info.

## Decision

- `CardDefinition` model: title, body, icon, bullets, badge, accent_color
- `Badge` model: pill-shaped label (text + optional color)
- `CalloutBox` model: variant (info/warning/success), title, body, icon
- `CARD_GRID` SlideType with max 12 cards via `auto_layout()`
- Callout renders on any slide type at y=6.1 (above footer)
- `render_card_grid_slide`: rounded rect cards with accent bar, icon, title, body, bullets, badge
- `_render_badge`: pill-shaped rounded rect, dynamic width, white text on color fill

## Consequences

- Rich card layouts for consulting-style presentations
- Callouts can annotate any slide type
