# .dev-team — Agent Memory & Project Knowledge

Shared context for AI agents working on pptx-mcp. Follows seed-backend conventions.

## Structure

| Directory | Purpose |
|-----------|---------|
| `adrs/` | Architecture Decision Records |
| `architecture/` | System diagrams, module maps, roadmap |
| `research/` | Investigation notes, coverage matrices |
| `status/` | Sprint tracking, task tables |
| `handoffs/` | Agent-to-agent handoff notes |

## ADR Format

Each ADR follows: Status, Date, Context, Decision, Alternatives, Consequences.

## Naming Conventions

- ADRs: `ADR-NNN-short-slug.md` (zero-padded to 3 digits)
- Research: `topic-slug.md`
- Status: `current-sprint.md` (single living doc)
- Handoffs: `YYYY-MM-DD-agent-name.md`
