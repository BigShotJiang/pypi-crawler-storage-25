# PPTX MCP — CTO Test Prompts

5 prompts to exercise the full range of the PPTX MCP server. Each prompt targets a different workflow and feature set. Copy-paste any prompt directly into Claude (with the PPTX MCP server connected) and it should produce a finished .pptx file.

---

## Prompt 1 — One-Shot Generation (Quick Win)

**What it tests:** `generate_presentation`, brand presets, content hydration, multiple slide types

```
Create a 6-slide presentation about "Why We're Moving to a Platform Engineering Model"
for an engineering leadership audience at Acme Corp.

Use the "technical" brand preset.

Key points to cover:
- Developer productivity has dropped 18% due to infrastructure toil
- Platform teams reduce onboarding time from 3 weeks to 2 days
- Self-service golden paths eliminate 70% of tickets to infra
- We need 4 headcount and 6 months to reach MVP

Save it to ~/Desktop/platform-engineering.pptx
```

**Expected output:** A polished 6-slide deck with title, content, big number, chart, and closing slides — all rendered with the dark/technical brand theme. Should complete in a single tool call.

---

## Prompt 2 — Plan Workflow with Iteration (Large Deck)

**What it tests:** `plan_presentation`, `get_plan_slide`, `update_plan_slide`, `get_layout_variants`, `optimize_plan`, `create_from_plan`

```
I need a 15-slide board deck for our Q1 2026 board meeting at NovaTech.
Topic: "Q1 Performance & Strategic Pivot to AI-First Products"

Key points:
- Revenue hit $42M (+23% YoY), EBITDA margin 18%
- Enterprise segment grew 40%, SMB flat
- Launched 3 AI features; adoption at 28% of MAU in 60 days
- Customer NPS rose from 42 to 58
- Churn dropped to 3.2% (from 5.1%)
- Requesting $8M incremental investment for AI R&D
- Key risk: talent retention in ML engineering (12% attrition)
- Product roadmap: AI copilot GA in Q3, autonomous workflows Q4

Use the "executive" brand preset.

First, create the plan. Then show me what slide 4 looks like. Then check if
any content slides have layout variant options. Finally, optimize the plan
and render it.

Save to ~/Desktop/novaTech-board-q1.pptx
```

**Expected output:** Multi-step interaction exercising the full plan lifecycle — plan creation, slide inspection, variant exploration, server-side optimization, and final render.

---

## Prompt 3 — Consulting Deck with Diagrams & Charts

**What it tests:** Deck archetypes, diagram types (ORG_CHART, MATRIX, WATERFALL), chart types (COMBO, STACKED_COLUMN), consulting brand

```
Build a strategy deck using the "strategy_deck" archetype with the "consulting"
brand preset.

Topic: "Digital Transformation Roadmap for GlobalBank"
Company: McKinsey & Company (preparing for client)
Audience: C-suite at GlobalBank

Key points:
- Current IT spend: $1.2B/year, 72% on maintenance ("keep the lights on")
- Target state: 55% maintenance / 45% innovation within 3 years
- 4 transformation pillars: Cloud Migration, Data Platform, Customer Experience, AI/ML
- Phase 1 (months 1-6): Foundation — cloud landing zone + data lake
- Phase 2 (months 7-18): Scale — migrate 40% of workloads, launch CX platform
- Phase 3 (months 19-36): Optimize — AI-driven operations, full self-service
- Expected ROI: $340M cumulative savings over 5 years
- Risk: organizational resistance in retail banking division

I want at least one waterfall chart showing the cost shift, one matrix slide
showing the transformation pillars mapped to business impact vs implementation effort,
and one org chart showing the proposed transformation office structure.

Save to ~/Desktop/globalbank-transformation.pptx
```

**Expected output:** A 12-18 slide consulting-style deck with specialized diagram slides mixed into the archetype's standard slot sequence. Tests diagram rendering, chart rendering, and archetype content hydration together.

---

## Prompt 4 — Edit an Existing Deck (Element-Level Editing)

**What it tests:** `read_presentation`, `list_slide_elements`, `modify_element`, `add_element`, `find_and_replace`, `batch_modify_elements`, `review_presentation`, `validate_slide_layout`

```
First, generate a quick 5-slide presentation about "2026 Product Roadmap" for
Acme Corp using the "startup" brand preset. Save it to ~/Desktop/roadmap-draft.pptx

Then, do the following edits to the generated file:

1. Read the presentation back and list all elements on slide 2
2. Find and replace "Acme Corp" with "Acme Inc." across all slides
3. On slide 2, make the title font size 32pt and change its color to #1a1a2e
4. Add a new rounded rectangle shape to slide 3 at position (1, 5) inches,
   size (3, 0.8) inches, with fill color #e63946 and white text "PRIORITY"
5. Run a design review on the final file and show me the summary
6. Validate the layout of slide 3 to check for any overlaps

Save the edited version to ~/Desktop/roadmap-final.pptx
```

**Expected output:** A full edit workflow — generate, parse, inspect, bulk replace, element modify, element add, spatial validation, and design review. Demonstrates the round-trip editing pipeline.

---

## Prompt 5 — Brand Extraction & Restyle + Brand Guide

**What it tests:** `extract_brand`, `restyle_presentation`, `generate_brand_guide`, brand system depth

```
I have an existing presentation at ~/Desktop/roadmap-final.pptx
(use whatever deck is there, or generate a quick 5-slide deck about
"Company Overview" with the "corporate" preset first).

Do the following:

1. Extract the brand configuration from the file — show me what colors,
   fonts, and styles it detected
2. Generate a brand guide presentation using the "finance" preset so I can
   see what that brand looks like — save to ~/Desktop/finance-brand-guide.pptx
3. Now restyle the original presentation using the "finance" preset and
   save to ~/Desktop/overview-restyled.pptx
4. Run a design review comparing the restyled version — does it pass
   brand compliance checks?

I want to see how the same content looks when shifted between brand identities.
```

**Expected output:** Brand extraction analysis, a 13-slide brand guide showcasing the finance theme (color swatches, typography specimens, shape styles), a restyled deck, and a review report — demonstrating the full brand pipeline.

---

## What These 5 Prompts Cover

| Capability | P1 | P2 | P3 | P4 | P5 |
|---|---|---|---|---|---|
| One-shot generation | X | | | X | |
| Plan workflow | | X | | | |
| Plan inspection & variants | | X | | | |
| Deck archetypes | | X | X | | |
| Brand presets | X | X | X | X | X |
| Diagrams (org, matrix, waterfall) | | | X | | |
| Charts (combo, stacked) | | | X | | |
| Element-level editing | | | | X | |
| Bulk find & replace | | | | X | |
| Spatial validation | | | | X | |
| Design review | | | | X | X |
| Brand extraction | | | | | X |
| Brand guide generation | | | | | X |
| Restyle pipeline | | | | | X |
| Read/parse existing PPTX | | | | X | X |

---

## Setup Notes

- The PPTX MCP server must be running and connected to Claude
- All output paths use `~/Desktop/` — adjust if needed
- No external files or images are required (all content is generated)
- Each prompt is self-contained and can be run independently
