# Security Policy

## Overview

pptx-mcp is a local Model Context Protocol (MCP) server that generates and manipulates PowerPoint files on behalf of a trusted caller (typically an MCP-compatible AI assistant or CLI tool). It operates under a **trusted caller model**: the server performs file I/O on the local filesystem at the direction of its client, and does not implement its own authentication or authorization layer.

Because pptx-mcp runs locally and is not designed to be exposed to untrusted networks or users, its security boundaries are scoped accordingly.

## Supported Versions

| Version | Supported |
|---------|-----------|
| 0.1.x   | Yes       |
| < 0.1.0 | No        |

## Reporting a Vulnerability

If you discover a security vulnerability in pptx-mcp, please report it responsibly through GitHub's private security advisory feature:

**https://github.com/swak/pptx-mcp/security/advisories**

Click "New draft security advisory" to submit your report. Please include:

- A description of the vulnerability and its potential impact.
- Steps to reproduce or a proof-of-concept, if possible.
- The version(s) affected.

Do **not** open a public issue for security vulnerabilities. We will acknowledge receipt within 7 days and aim to provide a fix or mitigation plan within 30 days, depending on severity.

## Security Protections

### Path Validation

All file operations enforce path validation. Output paths are checked for valid file extensions (`.pptx`) and input template paths are verified to exist before use. This prevents the server from writing to unexpected file types or locations outside the caller's intent.

### Input Validation via Pydantic Schemas

All tool inputs are validated through strict Pydantic models before processing. Malformed or out-of-range values are rejected at the schema boundary, before they reach any file or presentation logic.

### Resource Limits

Pydantic model constraints enforce upper bounds on resource-intensive parameters (e.g., slide counts, element counts, dimension values) to prevent excessive memory or CPU consumption from pathological inputs.

### Error Message Sanitization

Error responses returned to MCP clients are sanitized to avoid leaking internal server state, file paths, or stack traces. Detailed error information is logged locally for debugging but not propagated to callers.

## Known Limitations

- **Local use only.** pptx-mcp is designed to run on a single user's machine, invoked by a trusted MCP client. It is **not** a multi-tenant server and should not be deployed as a shared or network-accessible service without additional hardening.
- **No authentication or authorization.** The server trusts its caller entirely. Any process that can communicate with the MCP server can invoke all available tools.
- **Filesystem access inherits caller permissions.** The server reads and writes files with the permissions of the user running the process. It does not implement a sandbox or chroot.
