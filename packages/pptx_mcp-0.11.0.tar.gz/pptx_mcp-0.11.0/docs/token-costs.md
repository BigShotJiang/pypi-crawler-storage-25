# Token Costs Reference

Measured and estimated token costs for all 42 MCP tools. Use this to pick the cheapest workflow that meets your need.

**Status:** skeleton (2026-04-14). Costs marked ~ are estimates pending measurement in Phase 1 audit. Measured costs marked *.

---

## Token Budget Rule of Thumb

- **Under 500 tokens** per tool call — always safe
- **500–2,000 tokens** — safe for single calls, avoid in loops
- **2,000–10,000 tokens** — use sparingly, never in loops
- **Over 10,000 tokens** — deprecated surface area; see "Avoid" section

The Anthropic prompt cache resets if you sleep past 5 min. Within a session, earlier results stay cached; repeat reads of the same large object are cheap. Cost tables below reflect *first* call.

---

## Recommended Workflows by Deck Size

| Deck size | Recommended path | Est. total tokens |
|---|---|---|
| 3–8 slides | `generate_presentation` | ~300 |
| 9–20 slides | `plan_presentation` → `create_from_plan` | ~700 |
| 21+ slides | `plan_presentation` → `optimize_plan` → `create_from_plan` | ~900 |
| Edit existing | `read_presentation(summary=True)` → element tools | ~500 + per-edit |
| Review only | `review_presentation(summary_only=True)` | ~200 |

---

## Tool Catalog (grouped by cost profile)

### Green — always safe (≤ 500 tokens)

| Tool | Input | Output | Notes |
|---|---|---|---|
| `get_slide_templates` | 0 | ~200 | Static metadata |
| `get_brand_presets` | 0 | ~150 | Static metadata |
| `get_deck_types` | 0 | ~250 | 27 archetype names + descriptions |
| `get_layout_variants` | plan_id + index | ~150 | Compact hint strings |
| `get_plan_slide` | plan_id + index | ~200 | Single slide definition |
| `create_from_plan` | plan_id | ~80 | Output path confirmation |
| `optimize_plan` | plan_id | ~100 | Diff summary |
| `plan_presentation` (compact) | topic + key_points | ~500 | Default mode returns summary |
| `create_checkpoint` | file_path | ~80 | Backup path |
| `restore_checkpoint` | backup_path | ~80 | Confirmation |
| `add_slide` / `update_slide` (small) | slide def | ~250 | Proportional to slide size |
| `delete_slide` / `move_slide` / `duplicate_slide` | indices | ~80 | Confirmation |
| `add_speaker_notes` | slide index + text | ~100 | Confirmation |
| `validate_slide_layout` | file + index | ~300 | Per-slide spatial findings |
| `list_slide_elements` | file + index | ~400 | Shape list with positions |
| `modify_element` | locator + mods | ~150 | Diff summary |
| `add_element` | shape def | ~200 | Confirmation |
| `align_elements` / `group_elements` / `ungroup_elements` | locators | ~100 | Confirmation |
| `delete_element` / `copy_element` | locators | ~100 | Confirmation |
| `reorder_slides` | order list | ~100 | Confirmation |
| `find_and_replace` | pattern | ~200 | Match count + sample |
| `create_checkpoint` | file_path | ~80 | Backup path |
| `update_plan_slide` | plan_id + slide | ~200 | Confirmation |

### Yellow — use with intent (500–2,000 tokens)

| Tool | Input | Output | Notes |
|---|---|---|---|
| `generate_presentation` | topic + key_points | ~300 output / ~200 input | Hard-capped at 8 slides |
| `read_presentation(summary=True)` | file_path | ~800–2,000 | Proportional to deck size |
| `analyze_presentation` | file_path | ~1,500 | Parser + describer + review |
| `review_presentation(summary_only=True)` | file_path | ~200–600 | Findings list only |
| `parse_spec` | markdown | ~500–1,500 | PresentationDefinition output |
| `batch_modify_elements` | mod list | ~300–800 | Proportional to mod count |
| `apply_brand_guidelines` | file + brand | ~400 | Confirmation + style summary |
| `generate_brand_guide` | brand | ~200 | Output path |
| `parse_brand_guide` | markdown/yaml | ~800 | BrandConfig summary |
| `extract_brand` | pptx file | ~1,000 | Frequency-analyzed BrandConfig |

### Orange — large surface area (2,000–10,000 tokens)

| Tool | Input | Output | Notes |
|---|---|---|---|
| `read_presentation(summary=False)` | file_path | 3,000–10,000 | Full JSON; prefer summary |
| `plan_presentation(return_full_json=True)` | topic | 8,000–20,000 | **Deprecated path** — use compact |
| `review_presentation` (full) | file_path | 2,000–8,000 | Use `summary_only=True` |
| `restyle_presentation` | file + brand | 2,000–5,000 | Parser + regenerator |
| `improve_presentation` | file | 1,500–4,000 | Iterative review + edit |

### Red — avoid in loops (10,000+ tokens) / Deprecate candidates

| Tool | Cost | Reason |
|---|---|---|
| `create_presentation` | 4,000–25,000 input | Takes full `PresentationDefinition` — avoid unless output of `parse_spec` or `read_presentation` |
| `optimize_design` | 8,000–50,000 round-trip | Accepts AND returns full definition. **Deprecation candidate.** Use `optimize_plan` on a cached plan instead. |

---

## Efficiency Guidance (patterns to prefer)

### 1. IDs over objects
Tools that take `plan_id` or `(file_path, slide_index)` are far cheaper than tools that serialize the whole deck. Prefer:

- `update_plan_slide(plan_id, slide_index, patch)` over rebuild-and-create
- `create_from_plan(plan_id)` over `create_presentation(full_definition)`
- `optimize_plan(plan_id)` over `optimize_design(full_definition)`

### 2. Summary modes by default
Default to summary variants:

- `read_presentation(summary=True)` — compact per-slide line
- `review_presentation(summary_only=True)` — findings only, no full JSON
- `plan_presentation(...)` — compact mode is default; `return_full_json=True` is deprecated

### 3. Never retrieve + modify + send-back
The pattern:
```
full = read_presentation(path, summary=False)   # 10K tokens
# ... edit in-memory ...
create_presentation(full)                        # 10K more tokens
```
is a **20K round-trip**. Use `update_slide`, `modify_element`, or `batch_modify_elements` instead — each < 300 tokens.

### 4. Scoped reviews
If you only care about one slide, use `validate_slide_layout(file_path, slide_index)` (300 tokens) instead of a deck-wide `review_presentation`.

---

## Planned Phase 1+ Improvements

- **Slot-descriptor plans** — planner emits slot type + hint, hydrates on render. Est. 60% reduction in plan payload.
- **Streaming review findings** — emit findings incrementally instead of one fat JSON.
- **`modify_by_ref(plan_id, slide_index, diff)` pattern** — formalize the "edit by reference" shape across all mutation tools.
- **Compact describer** — one-line-per-slide output for "what's in this deck?" without a full read.
- **Deprecate `return_full_json=True`** entirely in v0.12.0.
- **`token_mode: "strict" | "normal"` kwarg** — auto-selects compact paths across all tools.

---

## Measurement Methodology (Phase 1 TBD)

1. Generate 10 fixture decks of varying sizes (3 / 8 / 15 / 30 slides) across 3 archetypes (board_deck, sales_deck, training).
2. Call each tool with those fixtures; capture Anthropic API token counts.
3. Update the tables above with measured costs, mark with `*`.
4. Add any tool exceeding the estimate by > 30% to the deprecation review list.
