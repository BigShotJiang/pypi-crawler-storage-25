# Release Runbook

How to cut a new PyPI release of `pptx-mcp`. Follow top-to-bottom — each step's output feeds the next. Don't skip pre-flight.

**Assumptions:**
- You have push access to `swak/pptx-mcp` on GitHub.
- `~/.pypirc` is configured with a valid `[pypi]` API token. Verify:
  ```
  grep -E "^\[|^username" ~/.pypirc
  ```
  Expect at least `[pypi]` and a `username = __token__` line.
- `.venv/bin/python` has `build` and `twine` installed:
  ```
  .venv/bin/python -m pip install --upgrade build twine
  ```

---

## 0. Decide the version

Follow semver against the last git tag:
- **Patch** (0.10.0 → 0.10.1): bug fixes, no API changes.
- **Minor** (0.10.0 → 0.11.0): new features, backward-compatible.
- **Major** (0.10.0 → 1.0.0): breaking changes to model shapes, tool signatures, or CLI.

Pick the target version before touching files — everything below references `X.Y.Z`.

---

## 1. Pre-flight — do NOT skip

Run all four in order. Abort if any fail.

```bash
# (a) Working tree must be clean OR have only the release-bump changes.
git status

# (b) On main (or the release branch).
git branch --show-current

# (c) Full test suite must be green.
.venv/bin/python -m pytest tests/ -q

# (d) Quality gates must be green (subset of above but worth confirming).
.venv/bin/python -m pytest tests/test_quality_gates.py -q
```

If tests fail, **stop**. Fix first.

---

## 2. Bump version in two places

Both must match exactly.

**File 1:** `pyproject.toml`
```toml
[project]
name = "pptx-mcp"
version = "X.Y.Z"   # ← bump this
```

**File 2:** `pptx_mcp/__init__.py`
```python
__version__ = "X.Y.Z"   # ← bump this
```

Verify they match:
```bash
grep -E '^version' pyproject.toml
grep __version__ pptx_mcp/__init__.py
```

Both lines must show the same `X.Y.Z`.

---

## 3. Refresh README counts (only when they changed)

If the release adds slide types, review rules, tools, prompts, chart types, archetypes, or presets, update every occurrence in `README.md`:

```bash
# Sanity-check for stale counts — replace numbers with what you expect
grep -nE "[0-9]+ slide type|[0-9]+ rules|[0-9]+ tools|[0-9]+ chart types|[0-9]+ brand presets|[0-9]+ deck archetypes" README.md
```

Audit:
- Intro paragraph ("…with N slide types…")
- "Why Use This" bullet list
- Tool inventory header
- Slide-type reference section
- Review engine section
- Project architecture block

Also update the `description = "..."` line in `pyproject.toml` if it quotes counts.

---

## 4. Commit the bump

One commit, descriptive message. Keep the body scannable — the tag message will echo the same info.

```bash
git add pyproject.toml pptx_mcp/__init__.py README.md docs/
git status  # verify only expected files are staged

git commit -m "$(cat <<'EOF'
Bump version to X.Y.Z

One-line summary of what's in this release.

- Bullet 1: user-visible change
- Bullet 2: user-visible change
- ...
EOF
)"
```

**Do NOT use `--amend`.** Always a new commit.

---

## 5. Tag the release

Annotated tag, version prefix `v`, message mirrors the commit summary.

```bash
git tag -a vX.Y.Z -m "vX.Y.Z: one-line summary"
git tag -l vX.Y.Z  # confirm it exists
```

---

## 6. Push commits + tag to GitHub

```bash
git push origin main
git push origin vX.Y.Z
```

Verify on GitHub:
- `https://github.com/swak/pptx-mcp/commits/main` shows your commit at the top.
- `https://github.com/swak/pptx-mcp/tags` shows `vX.Y.Z`.

Optional: create a GitHub Release from the tag via the web UI for release notes.

---

## 7. Build the distribution

```bash
# Clean any prior artifacts — stale files cause weird upload errors.
rm -rf dist/ build/ *.egg-info

# Build sdist + wheel.
.venv/bin/python -m build
```

Expected output: `dist/pptx_mcp-X.Y.Z-py3-none-any.whl` and `dist/pptx_mcp-X.Y.Z.tar.gz`.

---

## 8. Validate the artifacts before upload

PyPI uploads are **irreversible**. Catch mistakes here.

```bash
# (a) Lint the metadata.
.venv/bin/python -m twine check dist/*

# (b) Inspect the wheel contents — verify no secrets, no __pycache__, no test_output/.
.venv/bin/python -m zipfile -l dist/pptx_mcp-X.Y.Z-py3-none-any.whl | head -50

# (c) Verify the version baked into the artifact matches.
.venv/bin/python -m zipfile -l dist/pptx_mcp-X.Y.Z-py3-none-any.whl | grep -E "METADATA|\.dist-info"
```

Expected: `PASSED` from `twine check` on both files.

If `twine check` fails, **stop**. Common causes:
- Missing `LICENSE` in the wheel.
- Malformed README (PyPI renders a strict subset of Markdown).
- Description too long or contains invalid chars.

---

## 9. Upload to PyPI

```bash
.venv/bin/python -m twine upload dist/*
```

Expected: `View at: https://pypi.org/project/pptx-mcp/X.Y.Z/`.

If upload fails with 400 "File already exists", you pushed this version before. **Don't try to re-upload a published version — PyPI forbids it.** Bump to X.Y.Z+1 and restart from step 2.

---

## 10. Post-upload verification

```bash
# Give PyPI ~30s to propagate, then install from a clean environment.
.venv/bin/python -m pip install --upgrade --no-deps pptx-mcp==X.Y.Z
.venv/bin/python -c "import pptx_mcp; print(pptx_mcp.__version__)"
```

Must print `X.Y.Z`.

Also confirm the PyPI page renders correctly:
- `https://pypi.org/project/pptx-mcp/`
- README should appear formatted (no raw Markdown leaking through).
- Classifiers look right.

---

## 11. Announce (optional)

- GitHub Release: paste the commit body as release notes.
- Update project ROADMAP/CHANGELOG if the repo has one.
- Mention the release in relevant Slack/Discord channels.

---

## Troubleshooting

### `twine upload` hangs or fails with 403
Your API token is invalid/expired. Regenerate at `https://pypi.org/manage/account/token/`, then update `~/.pypirc`.

### Uploaded the wrong version by accident
PyPI does **not** allow re-uploading the same version. Options:
1. **Yank** the release (doesn't delete, but hides from new installs): `pip install pkg==X.Y.Z` still works for pinned users.
   ```
   pip install twine
   # There's no CLI for yank — use the PyPI web UI: Project → Releases → three-dot menu → Yank.
   ```
2. Bump to X.Y.Z+1 and publish a fix.

### Wheel contains unexpected files
Check `pyproject.toml` `[tool.hatch.build]` and `[tool.hatch.build.targets.wheel]` sections. Add patterns to `exclude` or `packages` as needed. Common additions:
```toml
[tool.hatch.build.targets.wheel]
packages = ["pptx_mcp"]
exclude = ["tests/", "docs/", "examples/", "test_output/", ".dev-team/"]
```

### Test suite fails after bumping version
Version string is read somewhere else you haven't updated. Grep:
```
grep -rn "0\.9\.1" --include="*.py" --include="*.toml" --include="*.md"
```

---

## Quick-reference checklist

Copy-paste for the next release:

```
[ ] 0. Pick version X.Y.Z
[ ] 1. Pre-flight (clean git, on main, tests green, quality gates green)
[ ] 2. Bump version in pyproject.toml + pptx_mcp/__init__.py
[ ] 3. Update README counts if they changed
[ ] 4. git commit -m "Bump version to X.Y.Z ..."
[ ] 5. git tag -a vX.Y.Z -m "..."
[ ] 6. git push origin main && git push origin vX.Y.Z
[ ] 7. rm -rf dist/ && .venv/bin/python -m build
[ ] 8. .venv/bin/python -m twine check dist/*
[ ] 9. .venv/bin/python -m twine upload dist/*
[ ] 10. Verify pip install pptx-mcp==X.Y.Z works and PyPI page renders
```
