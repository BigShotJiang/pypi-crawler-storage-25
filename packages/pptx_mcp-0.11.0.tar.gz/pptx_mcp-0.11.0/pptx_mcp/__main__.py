"""Allow running as `python -m pptx_mcp`."""

from pptx_mcp.cli import main

if __name__ == "__main__":
    main()
