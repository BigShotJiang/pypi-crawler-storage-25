"""Icon resolver — maps ``"pack:name"`` strings to bundled image paths.

The actual icon assets live under ``pptx_mcp/assets/icons/<pack>/<name>.png``.
This registry only knows where to look; missing files return None so the
renderer can fall back to text/emoji rendering.
"""

from __future__ import annotations

from pathlib import Path
from typing import Optional

# Resolve assets dir relative to this module
_ASSETS_DIR = Path(__file__).resolve().parent.parent / "assets" / "icons"

# Recognized icon packs and their on-disk subdirectory names
ICON_PACKS: dict[str, str] = {
    "lucide": "lucide",
}


def resolve_icon_path(name: str) -> Optional[str]:
    """Return the absolute path to a bundled icon, or None if unknown.

    Args:
        name: Icon identifier in ``"<pack>:<name>"`` form, e.g. ``"lucide:target"``.

    Returns:
        Absolute string path to a PNG file, or None if the pack/name is not
        registered or the file does not exist on disk.
    """
    if not name or ":" not in name:
        return None
    pack, icon_name = name.split(":", 1)
    pack_dir = ICON_PACKS.get(pack)
    if pack_dir is None:
        return None
    icon_path = _ASSETS_DIR / pack_dir / f"{icon_name}.png"
    if not icon_path.is_file():
        return None
    return str(icon_path)


def is_registered_icon(name: str) -> bool:
    """True when *name* uses ``"pack:icon"`` form with a known pack prefix.

    Does NOT check whether the icon file exists — use ``resolve_icon_path``
    to test for actual availability. Useful for deciding render mode
    (text vs image) without touching the filesystem.
    """
    if not name or ":" not in name:
        return False
    pack = name.split(":", 1)[0]
    return pack in ICON_PACKS


def list_available_icons(pack: Optional[str] = None) -> list[str]:
    """List all bundled icons as ``"pack:name"`` strings.

    Args:
        pack: Restrict to a single pack; returns all packs when None.
    """
    out: list[str] = []
    packs = [pack] if pack else list(ICON_PACKS)
    for p in packs:
        sub = ICON_PACKS.get(p)
        if sub is None:
            continue
        pack_dir = _ASSETS_DIR / sub
        if not pack_dir.is_dir():
            continue
        for png in sorted(pack_dir.glob("*.png")):
            out.append(f"{p}:{png.stem}")
    return out
