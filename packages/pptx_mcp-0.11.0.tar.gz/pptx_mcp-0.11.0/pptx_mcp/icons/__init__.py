"""Curated icon registry — replaces emoji-as-icon with consistent SVG/PNG assets.

Usage:
    from pptx_mcp.icons import resolve_icon_path
    path = resolve_icon_path("lucide:target")  # → bundled PNG path or None

Icon names use the format ``"<pack>:<name>"``:
- ``lucide:*`` — Lucide icon pack (MIT-licensed)
- Future packs may be added; unknown packs return None.

The renderer in IconItem detects the prefix and switches between text
rendering (emoji) and image rendering (registered icons).
"""

from __future__ import annotations

from .registry import (
    ICON_PACKS,
    is_registered_icon,
    list_available_icons,
    resolve_icon_path,
)

__all__ = [
    "ICON_PACKS",
    "is_registered_icon",
    "list_available_icons",
    "resolve_icon_path",
]
