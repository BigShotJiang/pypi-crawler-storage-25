"""ReviewAgent — reads decks and outputs structured critique."""

from __future__ import annotations

from pathlib import Path
from typing import Optional

from pydantic import BaseModel, Field

from pptx_mcp.agents.base import BaseAgent
from pptx_mcp.brand.config import resolve_brand_config
from pptx_mcp.engine.parser import parse_presentation
from pptx_mcp.models.brand import BrandConfig
from pptx_mcp.models.review import ReviewResult
from pptx_mcp.models.slides import PresentationDefinition
from pptx_mcp.review.engine import ReviewEngine


class ReviewerInput(BaseModel):
    """Input for the ReviewAgent."""

    file_path: Optional[str] = Field(
        default=None, description="Path to an existing PPTX file to review"
    )
    definition: Optional[PresentationDefinition] = Field(
        default=None, description="Pre-parsed presentation definition"
    )
    brand_config_path: Optional[str] = None
    brand_preset: Optional[str] = None


class ReviewerOutput(BaseModel):
    """Output from the ReviewAgent."""

    review: ReviewResult
    parsed_definition: Optional[PresentationDefinition] = None


class ReviewAgent(BaseAgent[ReviewerInput, ReviewerOutput]):
    """Reviews presentations and produces structured design critiques.

    Accepts either a file path (which will be parsed) or a pre-parsed
    PresentationDefinition. Returns a ReviewResult with scores, issues,
    and improvement suggestions.
    """

    @property
    def name(self) -> str:
        return "reviewer"

    @property
    def description(self) -> str:
        return "Reads decks and outputs structured critique."

    def run(self, input_data: ReviewerInput) -> ReviewerOutput:
        """Review a presentation.

        Args:
            input_data: File path or pre-parsed definition.

        Returns:
            ReviewerOutput with review results and optional parsed definition.
        """
        brand = resolve_brand_config(
            path=input_data.brand_config_path,
            preset=input_data.brand_preset,
        )

        engine = ReviewEngine(brand=brand)
        parsed_definition: Optional[PresentationDefinition] = None

        if input_data.definition:
            self.logger.info("Reviewing pre-parsed definition")
            review = engine.review_definition(input_data.definition)
        elif input_data.file_path:
            self.logger.info("Reviewing file: %s", input_data.file_path)
            path = Path(input_data.file_path)
            parsed_definition = parse_presentation(path)
            review = engine.review_definition(parsed_definition)
        else:
            from pptx_mcp.utils.errors import AgentError
            raise AgentError("ReviewAgent requires either file_path or definition.")

        self.logger.info(
            "Review complete: score=%.1f, issues=%d",
            review.overall_score,
            review.total_issues,
        )

        return ReviewerOutput(
            review=review,
            parsed_definition=parsed_definition,
        )
