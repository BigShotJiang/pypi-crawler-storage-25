"""Content-to-slide-type heuristics for intelligent slide type selection."""

from __future__ import annotations

import re

from pptx_mcp.models.slides import SlideType

# Keyword patterns mapped to slide types (checked in priority order)
_PATTERNS: list[tuple[re.Pattern[str], SlideType]] = [
    # Executive-grade layouts (v0.10.0) — must match before DASHBOARD/TABLE
    (re.compile(r"\b(executive.?summary|situation.?complication|minto|scr.?brief)\b", re.I), SlideType.EXECUTIVE_SUMMARY),
    (re.compile(r"\b(scorecard|rag.?status|initiative.?tracker|strategic.?priorities)\b", re.I), SlideType.SCORECARD),
    # Breadth-unlock layouts (v0.11.0) — must match before QUOTE/TABLE/IMAGE_TEXT.
    # Patterns anchored to avoid greedy matches (e.g., plain "pricing strategy",
    # "digital transformation", "client feedback" should NOT route here).
    (re.compile(r"\b(testimonials?|customer.voice|what.customers.say)\b", re.I), SlideType.TESTIMONIAL),
    (re.compile(r"\b(pricing.table|pricing.tiers?|plans?.and.features?|packages?.and.pricing|price.comparison)\b", re.I), SlideType.PRICING_TABLE),
    (re.compile(r"\b(logo.wall|trusted.by|our.customer.logos|client.logos|partner.logos|as.seen.in)\b", re.I), SlideType.LOGO_WALL),
    (re.compile(r"\b(hero.image|full.?bleed|cover.image|title.image)\b", re.I), SlideType.FULL_BLEED_HERO),
    (re.compile(r"\b(before.?and.?after|before.vs.after|transformation.impact|delta.impact)\b", re.I), SlideType.BEFORE_AFTER),
    (re.compile(r"\b(references|bibliography|citations?|sources.and.references|works.cited)\b", re.I), SlideType.REFERENCES),
    (re.compile(r"\b(revenue|growth|metric|kpi|dashboard|performance)\b", re.I), SlideType.DASHBOARD),
    (re.compile(r"\b(\d+[%$MBKmk]|\$[\d,.]+|[\d,.]+%)\b"), SlideType.BIG_NUMBER),
    (re.compile(r"\b(process|workflow|pipeline|phases?|stages?)\b", re.I), SlideType.PROCESS),
    (re.compile(r"\b(step[s ]|how.to|guide|tutorial)\b", re.I), SlideType.STEP_CARDS),
    (re.compile(r"\b(timeline|roadmap|milestones?|schedule)\b", re.I), SlideType.TIMELINE),
    (re.compile(r"\b(team|people|leadership|founders?|members?)\b", re.I), SlideType.TEAM),
    (re.compile(r"\b(compar|vs\.?|versus|alternative)\b", re.I), SlideType.COMPARISON),
    (re.compile(r"\b(pros?\b.*\bcons?|trade.?offs?|advantages?\b.*\bdisadvantages?)\b", re.I), SlideType.PROS_CONS),
    (re.compile(r"\b(swot|strengths?\b.*\bweaknesses?)\b", re.I), SlideType.SWOT),
    (re.compile(r"\b(quot[e]|said)\b", re.I), SlideType.QUOTE),
    (re.compile(r"\b(funnel|pipeline|conversion|sales.stages?)\b", re.I), SlideType.FUNNEL),
    (re.compile(r"\b(services?|offerings?|products?|packages?|solutions?|modules?)\b", re.I), SlideType.CARD_GRID),
    (re.compile(r"\b(values?|features?|benefits?|capabilities)\b", re.I), SlideType.ICON_GRID),
    (re.compile(r"\b(agenda|outline|topics?|schedule)\b", re.I), SlideType.AGENDA),
    (re.compile(r"\b(chart|graph|data|analytics)\b", re.I), SlideType.CHART),
    # Diagram types (v0.6.0)
    (re.compile(r"\b(org.?chart|hierarchy|reporting.?structure|organization)\b", re.I), SlideType.ORG_CHART),
    (re.compile(r"\b(matrix|quadrant|2x2|prioriti[sz]ation)\b", re.I), SlideType.MATRIX),
    (re.compile(r"\b(pyramid|hierarchy.?level|tier[s ]|layers?)\b", re.I), SlideType.PYRAMID),
    (re.compile(r"\b(venn|overlap|intersection|synerg)\b", re.I), SlideType.VENN),
    (re.compile(r"\b(waterfall|bridge.?chart|variance|contribution)\b", re.I), SlideType.WATERFALL),
    (re.compile(r"\b(hub.?(?:and|&)?.?spoke|central|radial|ecosystem)\b", re.I), SlideType.HUB_SPOKE),
    (re.compile(r"\b(cycle|loop|circular|continuous|iterati)\b", re.I), SlideType.CYCLE),
    (re.compile(r"\b(gantt|project.?plan|task.?timeline|work.?breakdown)\b", re.I), SlideType.GANTT),
]


def suggest_slide_type(title: str, content_hints: str = "") -> SlideType:
    """Suggest the best slide type based on title and content keywords.

    Args:
        title: The slide title or topic.
        content_hints: Additional text to analyze (body, notes, etc.).

    Returns:
        The suggested SlideType, defaulting to CONTENT.
    """
    text = f"{title} {content_hints}".strip()
    if not text:
        return SlideType.CONTENT

    for pattern, slide_type in _PATTERNS:
        if pattern.search(text):
            return slide_type

    return SlideType.CONTENT
