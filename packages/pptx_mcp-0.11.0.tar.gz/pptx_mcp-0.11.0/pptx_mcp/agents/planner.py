"""SlidePlanner agent — converts a topic and context into a structured slide plan."""

from __future__ import annotations

import re
from typing import Optional

from pydantic import BaseModel, Field

from pptx_mcp.agents.archetypes import ARCHETYPES
from pptx_mcp.agents.base import BaseAgent
from pptx_mcp.agents.content_mapper import suggest_slide_type
from pptx_mcp.models.diagrams import (
    CycleStep,
    GanttTask,
    MatrixData,
    MatrixQuadrant,
    OrgNode,
    PyramidLayer,
    SpokeItem,
    VennCircle,
    VennData,
    WaterfallBar,
)
from pptx_mcp.models.slides import (
    AgendaItem,
    BeforeAfter,
    CardDefinition,
    ChartData,
    ChartDataSeries,
    ChartElement,
    ChartType,
    Citation,
    ColumnContent,
    ExecutiveSummary,
    FunnelStage,
    HeroImage,
    IconItem,
    KpiCard,
    LogoWallItem,
    PresentationDefinition,
    PresentationMetadata,
    PricingTier,
    ProcessStep,
    ScorecardRow,
    SlideDefinition,
    SlideType,
    SwotData,
    TableCell,
    TableElement,
    TeamMember,
    Testimonial,
)


class SlideSpec(BaseModel):
    """Caller-specified slide type + optional title."""
    slide_type: SlideType
    title: Optional[str] = None


class PlannerInput(BaseModel):
    """Input for the SlidePlanner agent."""

    topic: str = Field(description="Main topic or title of the presentation")
    audience: str = Field(default="executive", description="Target audience")
    num_slides: int = Field(default=10, ge=3, le=50, description="Target number of slides")
    key_points: list[str] = Field(default_factory=list, description="Key points to cover")
    context: str = Field(default="", description="Additional context or instructions")
    include_agenda: bool = Field(default=True, description="Include an agenda slide")
    include_summary: bool = Field(default=True, description="Include a summary/closing slide")
    author: Optional[str] = None
    company: Optional[str] = None
    deck_type: Optional[str] = Field(default=None, description="Deck archetype name (e.g. 'pitch_deck', 'board_deck')")
    slides: list[SlideSpec] = Field(default_factory=list, description="Explicit slide sequence — overrides all other paths")


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_NUMBER_RE = re.compile(r"(\d+[\d,.]*\s*[%$MBKmk]|\$[\d,.]+)")


def _extract_number(text: str) -> str | None:
    """Return the first number/percentage/currency token found in *text*."""
    m = _NUMBER_RE.search(text)
    return m.group(1).strip() if m else None


def _distribute_key_points(
    key_points: list[str],
    num_slides: int,
) -> list[list[str]]:
    """Evenly distribute *key_points* across *num_slides* content slots.

    Each slot receives 2-3 points when possible.  If there are fewer points
    than slots, later slots get topic-derived filler handled by the caller.
    """
    if not key_points or num_slides <= 0:
        return [[] for _ in range(max(num_slides, 0))]

    buckets: list[list[str]] = [[] for _ in range(num_slides)]
    for idx, point in enumerate(key_points):
        buckets[idx % num_slides].append(point)
    return buckets


def _truncate(text: str, max_len: int = 97) -> str:
    """Truncate *text* to fit within *max_len* chars, adding ellipsis if needed."""
    if len(text) <= max_len:
        return text
    return text[: max_len - 1] + "\u2026"


class SlidePlannerAgent(BaseAgent[PlannerInput, PresentationDefinition]):
    """Generates a structured slide plan from a topic description."""

    @property
    def name(self) -> str:
        return "slide_planner"

    @property
    def description(self) -> str:
        return "Converts a topic and context into a structured slide plan."

    def run(self, input_data: PlannerInput) -> PresentationDefinition:
        self.logger.info("Planning presentation: '%s' (%d slides)", input_data.topic, input_data.num_slides)

        if input_data.slides:
            slides = self._plan_from_explicit_slides(input_data)
        elif input_data.deck_type and input_data.deck_type in ARCHETYPES:
            slides = self._plan_from_archetype(input_data)
        elif input_data.key_points:
            slides = self._plan_from_key_points_smart(input_data)
        else:
            slides = self._plan_default(input_data)

        # Enforce variety and structure
        slides = self._enforce_variety(slides, input_data)

        # Ensure exact slide count
        if len(slides) > input_data.num_slides:
            slides = slides[:input_data.num_slides]

        metadata = PresentationMetadata(
            title=input_data.topic,
            author=input_data.author,
            company=input_data.company,
            subject=input_data.topic,
        )

        return PresentationDefinition(metadata=metadata, slides=slides)

    # ------------------------------------------------------------------
    # Planning paths
    # ------------------------------------------------------------------

    def _plan_from_explicit_slides(self, input_data: PlannerInput) -> list[SlideDefinition]:
        """Plan slides from an explicit slide sequence provided by the caller."""
        slides: list[SlideDefinition] = []
        for i, spec in enumerate(input_data.slides):
            title = spec.title or self._generate_title_for_type(spec.slide_type, i, input_data)
            slide = self._create_skeleton_slide(spec.slide_type, title, i, input_data)
            # If caller provided explicit title, override hydrated title
            if spec.title:
                slide = slide.model_copy(update={"title": spec.title})
            slides.append(slide)
        return slides

    _TYPE_TITLE_MAP: dict[SlideType, str] = {
        SlideType.TITLE: "{topic}",
        SlideType.SECTION: "{topic}",
        SlideType.CONTENT: "{topic} Overview",
        SlideType.TWO_COLUMN: "{topic} Comparison",
        SlideType.PROS_CONS: "{topic} Trade-offs",
        SlideType.COMPARISON: "{topic} Options",
        SlideType.QUOTE: "Expert Perspective",
        SlideType.BIG_NUMBER: "Key Metric",
        SlideType.PROCESS: "{topic} Process",
        SlideType.TIMELINE: "{topic} Timeline",
        SlideType.STEP_CARDS: "{topic} Steps",
        SlideType.DASHBOARD: "{topic} Dashboard",
        SlideType.ICON_GRID: "{topic} Capabilities",
        SlideType.CARD_GRID: "{topic} Highlights",
        SlideType.IMAGE_TEXT: "{topic} Visual",
        SlideType.TEAM: "Our Team",
        SlideType.CLOSING: "Key Takeaways",
        SlideType.SWOT: "{topic} SWOT Analysis",
        SlideType.FUNNEL: "{topic} Funnel",
        SlideType.AGENDA: "Agenda",
        SlideType.CHART: "{topic} Data",
        SlideType.TABLE: "{topic} Details",
        SlideType.ORG_CHART: "{topic} Organization",
        SlideType.MATRIX: "{topic} Priority Matrix",
        SlideType.PYRAMID: "{topic} Hierarchy",
        SlideType.VENN: "{topic} Overlap",
        SlideType.WATERFALL: "{topic} Breakdown",
        SlideType.HUB_SPOKE: "{topic} Model",
        SlideType.CYCLE: "{topic} Cycle",
        SlideType.GANTT: "{topic} Schedule",
        SlideType.EXECUTIVE_SUMMARY: "Executive Summary",
        SlideType.SCORECARD: "Strategic Priorities",
        SlideType.TESTIMONIAL: "What Customers Say",
        SlideType.PRICING_TABLE: "Pricing",
        SlideType.LOGO_WALL: "Trusted By",
        SlideType.FULL_BLEED_HERO: "{topic}",
        SlideType.BEFORE_AFTER: "Before & After",
        SlideType.REFERENCES: "References",
    }

    def _generate_title_for_type(
        self, slide_type: SlideType, index: int, input_data: PlannerInput,
    ) -> str:
        """Generate a meaningful default title for a slide type."""
        topic = input_data.topic
        kps = input_data.key_points

        # Try round-robin from key_points first for content-ish types
        if kps and slide_type not in (
            SlideType.TITLE, SlideType.CLOSING, SlideType.AGENDA, SlideType.TEAM,
        ):
            return kps[index % len(kps)]

        template = self._TYPE_TITLE_MAP.get(slide_type, "{topic}")
        return template.format(topic=topic)

    def _plan_from_archetype(self, input_data: PlannerInput) -> list[SlideDefinition]:
        """Plan slides from a deck archetype.

        When ``num_slides < len(slots)``: drop required=False slots first
        (preserving original order) until count fits; if still over, fall
        back to evenly-spaced middle trim.
        When ``num_slides > len(slots)``: fill with content-aware filler.
        """
        archetype = ARCHETYPES[input_data.deck_type]  # type: ignore[index]
        # Respect num_slides as the binding target (outer run() trims to
        # num_slides anyway; honoring it here lets us keep CLOSING as the
        # last slot). min_slides is aspirational — bump up only if caller
        # asked for fewer than the required slot count.
        required_count = sum(1 for s in archetype.slots if s.required)
        target = min(
            max(input_data.num_slides, required_count),
            archetype.max_slides,
        )

        # Select slots to materialize
        all_slots = list(archetype.slots)
        if target >= len(all_slots):
            selected = all_slots
        elif target >= required_count:
            # Keep all required + as many optional as budget allows (in order)
            selected = [s for s in all_slots if s.required]
            optional_remaining = target - len(selected)
            for slot in all_slots:
                if not slot.required and optional_remaining > 0:
                    # Insert optional at its original position
                    idx = all_slots.index(slot)
                    # Find insertion point among already-selected (preserving order)
                    insert_at = sum(
                        1 for s in selected if all_slots.index(s) < idx
                    )
                    selected.insert(insert_at, slot)
                    optional_remaining -= 1
        else:
            # Target < required count — keep first, last, evenly spaced middle
            required_slots = [s for s in all_slots if s.required]
            first, last = required_slots[0], required_slots[-1]
            middle = required_slots[1:-1]
            if target <= 2:
                selected = [first, last][:target]
            else:
                step = max(1, len(middle) // max(target - 2, 1))
                kept = middle[::step][: target - 2]
                selected = [first] + kept + [last]

        slides: list[SlideDefinition] = []
        for slot in selected:
            slide = self._create_skeleton_slide(
                slot.slide_type, slot.title_template, len(slides), input_data,
            )
            slides.append(slide)

        # Fill remaining budget with content-aware filler slides
        while len(slides) < target:
            idx = len(slides)
            filler_title = self._filler_title(input_data, idx)
            stype = suggest_slide_type(filler_title, input_data.context)
            slides.insert(-1, self._create_skeleton_slide(
                stype, filler_title, idx, input_data,
            ))

        return slides[:target]

    def _plan_from_key_points_smart(self, input_data: PlannerInput) -> list[SlideDefinition]:
        """Plan content slides using content-aware type selection."""
        slides: list[SlideDefinition] = []

        # Title
        slides.append(SlideDefinition(
            slide_type=SlideType.TITLE,
            title=input_data.topic,
            subtitle=self._generate_subtitle(input_data),
            speaker_notes="Introduce the topic and set expectations.",
        ))

        # Agenda
        if input_data.include_agenda:
            slides.append(SlideDefinition(
                slide_type=SlideType.AGENDA,
                title="Agenda",
                agenda_items=[AgendaItem(title=kp) for kp in input_data.key_points[:8]],
                speaker_notes="Walk through what we'll cover today.",
            ))

        # Content budget
        content_budget = input_data.num_slides - len(slides)
        if input_data.include_summary:
            content_budget -= 1

        for i, point in enumerate(input_data.key_points[:content_budget]):
            if i > 0 and i % 4 == 0:
                slides.append(SlideDefinition(
                    slide_type=SlideType.SECTION,
                    title=point,
                    speaker_notes=f"Transition to: {point}",
                ))
                continue

            stype = suggest_slide_type(point, input_data.context)
            slide = self._create_skeleton_slide(stype, point, i, input_data)
            slides.append(slide)

        # Fill remaining with content-aware filler
        while len(slides) < input_data.num_slides - (1 if input_data.include_summary else 0):
            filler_title = self._filler_title(input_data, len(slides))
            stype = suggest_slide_type(filler_title, input_data.context)
            slides.append(self._create_skeleton_slide(
                stype,
                filler_title,
                len(slides),
                input_data,
            ))

        # Closing
        if input_data.include_summary:
            slides.append(SlideDefinition(
                slide_type=SlideType.CLOSING,
                title="Key Takeaways",
                subtitle=self._closing_message(input_data),
                bullets=self._generate_takeaways(input_data),
                speaker_notes="Summarize key points and call to action.",
            ))

        return slides

    def _plan_default(self, input_data: PlannerInput) -> list[SlideDefinition]:
        """Plan slides with a varied default structure."""
        slides: list[SlideDefinition] = []

        # Title
        slides.append(SlideDefinition(
            slide_type=SlideType.TITLE,
            title=input_data.topic,
            subtitle=self._generate_subtitle(input_data),
            speaker_notes="Introduce the topic and set expectations.",
        ))

        # Agenda
        if input_data.include_agenda:
            agenda_items = self._generate_agenda(input_data)
            slides.append(SlideDefinition(
                slide_type=SlideType.AGENDA,
                title="Agenda",
                agenda_items=[AgendaItem(title=item) for item in agenda_items],
                speaker_notes="Walk through what we'll cover today.",
            ))

        content_budget = input_data.num_slides - len(slides)
        if input_data.include_summary:
            content_budget -= 1

        structure = self._get_default_structure(content_budget, input_data)
        for i, (stype, title_template) in enumerate(structure):
            title = title_template.format(topic=input_data.topic)
            slide = self._create_skeleton_slide(stype, title, i, input_data)
            slides.append(slide)

        # Closing
        if input_data.include_summary:
            slides.append(SlideDefinition(
                slide_type=SlideType.CLOSING,
                title="Key Takeaways",
                subtitle=self._closing_message(input_data),
                bullets=self._generate_takeaways(input_data),
                speaker_notes="Summarize key points and call to action.",
            ))

        return slides

    # ------------------------------------------------------------------
    # Filler title helper
    # ------------------------------------------------------------------

    _FILLER_SUFFIXES = [
        "Deep Dive", "Analysis", "Insights", "Strategy",
        "Implementation", "Impact", "Overview",
    ]

    def _filler_title(self, input_data: PlannerInput, index: int) -> str:
        """Generate a meaningful title for filler slides instead of placeholders."""
        kps = input_data.key_points
        if kps:
            return kps[index % len(kps)]
        topic = input_data.topic
        return f"{topic} {self._FILLER_SUFFIXES[index % len(self._FILLER_SUFFIXES)]}"

    # ------------------------------------------------------------------
    # Enforcement / structure helpers
    # ------------------------------------------------------------------

    def _enforce_variety(
        self,
        slides: list[SlideDefinition],
        input_data: Optional[PlannerInput] = None,
    ) -> list[SlideDefinition]:
        """Ensure no 3+ consecutive identical non-SECTION types."""
        if len(slides) < 3:
            return slides

        topic = input_data.topic if input_data else "Next Section"
        section_idx = 0
        _section_suffixes = ["Continued", "Next Steps", "Details", "Further Analysis", "Summary"]

        result = list(slides)
        i = 2
        while i < len(result):
            if (
                result[i].slide_type == result[i - 1].slide_type == result[i - 2].slide_type
                and result[i].slide_type not in (SlideType.SECTION, SlideType.TITLE)
            ):
                section_title = f"{topic} — {_section_suffixes[section_idx % len(_section_suffixes)]}"
                section_idx += 1
                result.insert(i, SlideDefinition(
                    slide_type=SlideType.SECTION,
                    title=section_title,
                    speaker_notes=f"Transition: {section_title}",
                ))
                i += 2  # skip past the inserted section
            else:
                i += 1

        return result

    # ------------------------------------------------------------------
    # Subtitle / agenda / structure helpers
    # ------------------------------------------------------------------

    def _generate_subtitle(self, input_data: PlannerInput) -> str:
        parts: list[str] = []
        if input_data.company:
            parts.append(input_data.company)
        if input_data.audience == "executive":
            parts.append("Executive Overview")
        elif input_data.audience == "technical":
            parts.append("Technical Deep Dive")
        elif input_data.audience:
            parts.append(f"Prepared for {input_data.audience}")
        else:
            parts.append("Overview")
        if input_data.key_points:
            parts.append(f"{len(input_data.key_points)} key topics")
        return " | ".join(parts) if parts else "Overview"

    def _closing_message(self, input_data: PlannerInput) -> str:
        if input_data.company:
            return f"Thank you — {input_data.company}"
        return f"Thank you for your time"

    def _generate_agenda(self, input_data: PlannerInput) -> list[str]:
        if input_data.key_points:
            return input_data.key_points[:6]
        return [
            "Background & Context",
            "Current State Analysis",
            "Proposed Approach",
            "Key Considerations",
            "Next Steps",
        ]

    def _get_default_structure(
        self, budget: int, input_data: Optional[PlannerInput] = None,
    ) -> list[tuple[SlideType, str]]:
        full_structure: list[tuple[SlideType, str]] = [
            (SlideType.SECTION, "Background"),
            (SlideType.CONTENT, "Current State"),
            (SlideType.TWO_COLUMN, "Analysis"),
            (SlideType.BIG_NUMBER, "Key Metric"),
            (SlideType.SECTION, "Approach"),
            (SlideType.CONTENT, "Proposed Solution"),
            (SlideType.PROS_CONS, "Trade-offs"),
            (SlideType.CHART, "Impact & Metrics"),
            (SlideType.DASHBOARD, "Performance Overview"),
            (SlideType.SECTION, "Path Forward"),
            (SlideType.PROCESS, "Implementation Plan"),
            (SlideType.TIMELINE, "Timeline & Resources"),
            (SlideType.COMPARISON, "Options Comparison"),
            (SlideType.QUOTE, "Expert Perspective"),
        ]

        if budget <= 0:
            return []
        if budget <= len(full_structure):
            step = max(1, len(full_structure) // budget)
            return full_structure[::step][:budget]

        result = list(full_structure)
        while len(result) < budget:
            idx = len(result)
            if input_data:
                filler = self._filler_title(input_data, idx)
            else:
                filler = f"Additional Analysis {idx + 1}"
            stype = suggest_slide_type(filler, input_data.context if input_data else "")
            result.append((stype, filler))
        return result[:budget]

    # ------------------------------------------------------------------
    # Takeaways
    # ------------------------------------------------------------------

    def _generate_takeaways(self, input_data: PlannerInput) -> list[str]:
        topic = input_data.topic
        if input_data.key_points:
            takeaways = [
                f"{kp} — a critical factor for success"
                if i == 0
                else kp
                for i, kp in enumerate(input_data.key_points[:3])
            ]
            takeaways.append(f"Next step: align on {topic} priorities")
            return takeaways
        return [
            f"Strong foundation established for {topic}",
            f"Key opportunities identified for {input_data.audience} stakeholders",
            f"Clear path forward on {topic}",
            f"Align on next steps and owners",
        ]

    # ------------------------------------------------------------------
    # Content helpers for _create_skeleton_slide
    # ------------------------------------------------------------------

    def _points_for_slide(self, input_data: PlannerInput, index: int, count: int = 3) -> list[str]:
        """Return *count* bullet points for a content slide at *index*.

        Round-robins through key_points, falling back to topic-derived text.
        """
        topic = input_data.topic
        kps = input_data.key_points
        if kps:
            start = (index * count) % len(kps) if len(kps) > count else 0
            selected = (kps + kps)[start:start + count]  # wrap-around slice
            return selected[:count]
        audience = input_data.audience or "stakeholders"
        return [
            f"Overview of {topic}",
            f"Key considerations for {audience}",
            f"Implications and next steps for {topic}",
        ][:count]

    def _split_key_points_two(self, input_data: PlannerInput) -> tuple[list[str], list[str]]:
        """Split key_points into two roughly equal groups."""
        kps = input_data.key_points
        topic = input_data.topic
        if len(kps) >= 2:
            mid = len(kps) // 2
            return kps[:mid], kps[mid:]
        # Fallback: generate from topic
        return (
            [f"Current {topic} capabilities", f"Existing {topic} strengths"],
            [f"Future {topic} opportunities", f"Planned {topic} improvements"],
        )

    # ------------------------------------------------------------------
    # Archetype-specific hydrators (Phase 1b)
    # ------------------------------------------------------------------
    #
    # Principle: pull real content from key_points when available; emit
    # explicit placeholders ("[...]", "TBD") when not. NEVER invent specific
    # numbers, quotes, or attributions that could read as real data.

    def _hydrate_dashboard_kpis(self, kps: list[str], topic: str) -> list[KpiCard]:
        """Build KPI cards from key_points, extracting numeric metrics."""
        cards: list[KpiCard] = []
        # Pass 1: any key_point containing a number becomes a KPI card
        for kp in kps[:4]:
            num = _extract_number(kp)
            if num:
                # Label = the rest of the bullet with the number removed
                label = kp.replace(num, "").strip(" -–—:,.") or topic
                cards.append(KpiCard(
                    value=num,
                    label=_truncate(label, 60),
                    trend="neutral",
                ))
        # Pass 2: fill up to 4 with non-numeric key_points as labeled placeholders
        if len(cards) < 4:
            for kp in kps:
                if len(cards) >= 4:
                    break
                # Skip ones already used
                if any(kp.startswith(c.label[:20]) for c in cards):
                    continue
                cards.append(KpiCard(
                    value="TBD",
                    label=_truncate(kp, 60),
                    trend="neutral",
                ))
        # Pass 3: if still short, emit neutral placeholders (no fake numbers)
        while len(cards) < 4:
            cards.append(KpiCard(
                value="TBD",
                label=f"Metric {len(cards) + 1}",
                trend="neutral",
            ))
        return cards

    def _hydrate_quote(
        self, input_data: PlannerInput,
    ) -> tuple[str, str | None, str | None]:
        """Return (body, attribution, attribution_role) for a quote slide.

        Does not invent attributions. When no author/company provided, emits a
        placeholder body and sets attribution to None.
        """
        # If user supplied key_points, use the first as a possible quote seed.
        # But only set attribution if they also gave author or company context.
        kps = input_data.key_points
        if input_data.author:
            body = kps[0] if kps else (
                f"[Insert supporting quote for {input_data.topic}]"
            )
            return (
                body,
                input_data.author,
                (f"{input_data.company}" if input_data.company else None),
            )
        # No attribution available — emit unattributed placeholder
        return (
            "[Insert customer/leader quote here — supply via author/company or edit after render]",
            None,
            None,
        )

    def _hydrate_pros_cons(self, kps: list[str]) -> tuple[list[str], list[str]]:
        """Split key_points into pros/cons; placeholder when absent."""
        if len(kps) >= 4:
            mid = len(kps) // 2
            return kps[:mid][:3], kps[mid:][:3]
        if len(kps) >= 2:
            # One each, rest placeholders
            return (
                [kps[0]] + ["[Benefit — supply via key_points]", "[Benefit — supply via key_points]"],
                [kps[1]] + ["[Risk — supply via key_points]", "[Risk — supply via key_points]"],
            )
        return (
            ["[Benefit 1]", "[Benefit 2]", "[Benefit 3]"],
            ["[Risk 1]", "[Risk 2]", "[Risk 3]"],
        )

    def _hydrate_testimonials(
        self, kps: list[str], input_data: PlannerInput,
    ) -> list[Testimonial]:
        """Build 1-3 testimonials from key_points.

        Never invents attribution: ``input_data.author`` is the DECK author
        (not a customer), so using it here would confuse the reader. Every
        testimonial ships with an explicit ``[Customer Name]`` placeholder
        until the caller supplies real attribution post-render.
        """
        if not kps:
            return [
                Testimonial(
                    quote="[Insert customer testimonial — supply via key_points]",
                    name="[Customer Name]",
                ),
            ]
        return [
            Testimonial(
                quote=_truncate(kp, 380),
                name="[Customer Name]",
            )
            for kp in kps[:3]
        ]

    def _hydrate_pricing_tiers(self, kps: list[str]) -> list[PricingTier]:
        """Produce 3 placeholder tiers. When key_points supplied, use their
        text as feature lists per tier; otherwise emit explicit placeholders.
        """
        names = ["Starter", "Pro", "Enterprise"]
        prices = ["$29/mo", "$99/mo", "Contact us"]
        ctas = ["Start free", "Get Pro", "Talk to sales"]
        features_default = [
            ["[Feature A]", "[Feature B]", "[Feature C]"],
            ["[Everything in Starter]", "[Feature D]", "[Feature E]", "[Feature F]"],
            ["[Everything in Pro]", "[Feature G]", "[Feature H]", "[Feature I]"],
        ]
        features = features_default
        if kps:
            # Split key_points across tiers (3 per tier, round-robin)
            chunk = max(1, len(kps) // 3 or 1)
            features = [
                kps[i * chunk : (i + 1) * chunk] or features_default[i]
                for i in range(3)
            ]
        return [
            PricingTier(
                name=names[i],
                price=prices[i],
                period="per seat, billed annually" if i < 2 else None,
                description=None,
                features=features[i][:8],
                cta_text=ctas[i],
                highlighted=(i == 1),
            )
            for i in range(3)
        ]

    def _hydrate_logo_wall(self, kps: list[str]) -> list[LogoWallItem]:
        """Emit placeholder logos — real paths must be supplied post-render.

        Uses key_points as company names when available; emits explicit
        "[Customer N]" placeholders otherwise.
        """
        names = (kps[:8] if kps else [f"[Customer {i + 1}]" for i in range(6)])
        return [
            LogoWallItem(
                image_path="[Supply image_path]",
                name=_truncate(n, 80),
            )
            for n in names[:8]
        ]

    def _hydrate_citations(self, kps: list[str]) -> list[Citation]:
        """Use key_points as citation text when available, else placeholders."""
        if kps:
            return [
                Citation(text=_truncate(kp, 400), citation_id=str(i + 1))
                for i, kp in enumerate(kps[:8])
            ]
        return [
            Citation(
                text=f"[Citation {i + 1} — supply via key_points]",
                citation_id=str(i + 1),
            )
            for i in range(3)
        ]

    def _hydrate_executive_summary(
        self, kps: list[str], topic: str,
    ) -> ExecutiveSummary:
        """Build an SCR summary from key_points when possible.

        Maps the first 3 key_points to situation/complication/resolution;
        4th (if present) to ask. Emits explicit placeholders otherwise.
        """
        def pick(i: int, placeholder: str) -> str:
            if i < len(kps):
                return _truncate(kps[i], 400)
            return placeholder

        return ExecutiveSummary(
            situation=pick(0, f"[Describe the current state of {topic}]"),
            complication=pick(1, "[Surface the change/risk that makes this urgent]"),
            resolution=pick(2, "[State the recommended path forward]"),
            ask=(kps[3][:300] if len(kps) >= 4 else None),
        )

    def _hydrate_scorecard_rows(self, kps: list[str]) -> list[ScorecardRow]:
        """Build scorecard rows from key_points; placeholder rows when empty."""
        if kps:
            # Rotate through green/amber/red to signal variety
            statuses: list[str] = ["green", "amber", "red", "green", "amber"]
            rows: list[ScorecardRow] = []
            for i, kp in enumerate(kps[:5]):
                rows.append(ScorecardRow(
                    initiative=_truncate(kp, 140),
                    progress="[Supply status]",
                    status=statuses[i % len(statuses)],  # type: ignore[arg-type]
                ))
            return rows
        return [
            ScorecardRow(initiative="[Initiative 1]", progress="[Supply status]", status="green"),
            ScorecardRow(initiative="[Initiative 2]", progress="[Supply status]", status="amber"),
            ScorecardRow(initiative="[Initiative 3]", progress="[Supply status]", status="red"),
        ]

    def _hydrate_comparison_columns(
        self, kps: list[str], topic: str,
    ) -> list[ColumnContent]:
        """Build comparison columns from key_points; placeholder titles otherwise."""
        if len(kps) >= 3:
            return [
                ColumnContent(
                    title=_truncate(kps[i], 60),
                    bullets=["[Supporting detail]"],
                )
                for i in range(min(3, len(kps)))
            ]
        # Placeholder columns — clearly labeled, no invented differentiation
        return [
            ColumnContent(title="[Option A]", bullets=["[Supporting detail]"]),
            ColumnContent(title="[Option B]", bullets=["[Supporting detail]"]),
            ColumnContent(title="[Option C]", bullets=["[Supporting detail]"]),
        ]

    # ------------------------------------------------------------------
    # Skeleton slide factory
    # ------------------------------------------------------------------

    def _create_skeleton_slide(
        self,
        slide_type: SlideType,
        title: str,
        index: int,
        input_data: PlannerInput,
    ) -> SlideDefinition:
        """Create a slide with real content derived from *input_data*."""
        topic = input_data.topic
        company = input_data.company or topic
        audience = input_data.audience or "stakeholders"
        kps = input_data.key_points

        # ---- SECTION ----
        if slide_type == SlideType.SECTION:
            return SlideDefinition(
                slide_type=slide_type,
                title=title,
                speaker_notes=f"Transition: {title}",
            )

        # ---- TWO_COLUMN ----
        if slide_type == SlideType.TWO_COLUMN:
            col_a, col_b = self._split_key_points_two(input_data)
            return SlideDefinition(
                slide_type=slide_type,
                title=title,
                columns=[
                    ColumnContent(title="Current State", bullets=col_a[:3]),
                    ColumnContent(title="Future State", bullets=col_b[:3]),
                ],
                speaker_notes=f"Discuss {title} from two perspectives.",
            )

        # ---- PROS_CONS ----
        if slide_type == SlideType.PROS_CONS:
            pros, cons = self._hydrate_pros_cons(kps)
            return SlideDefinition(
                slide_type=slide_type,
                title=title,
                pros=pros,
                cons=cons,
                speaker_notes=f"Weigh the pros and cons of {title}.",
            )

        # ---- COMPARISON ----
        if slide_type == SlideType.COMPARISON:
            cols = self._hydrate_comparison_columns(kps, topic)
            return SlideDefinition(
                slide_type=slide_type,
                title=title,
                columns=cols,
                speaker_notes=f"Compare options for {title}.",
            )

        # ---- QUOTE ----
        if slide_type == SlideType.QUOTE:
            quote_body, attribution, attribution_role = self._hydrate_quote(input_data)
            return SlideDefinition(
                slide_type=slide_type,
                title=title,
                body=quote_body,
                quote_attribution=attribution,
                quote_attribution_role=attribution_role,
                speaker_notes=(
                    f"Share the context behind this quote and how it relates to {topic}."
                    if attribution else
                    "Replace placeholder with a real customer/leader quote and attribution."
                ),
            )

        # ---- BIG_NUMBER ----
        if slide_type == SlideType.BIG_NUMBER:
            # Try to pull a real number from key_points
            extracted: str | None = None
            source_label = topic
            for kp in kps:
                extracted = _extract_number(kp)
                if extracted:
                    source_label = kp
                    break
            value = extracted or "100%"
            label = f"{topic} achievement" if not extracted else source_label
            return SlideDefinition(
                slide_type=slide_type,
                title=title,
                body=value,
                subtitle=label,
                bullets=[f"Demonstrates strong momentum in {topic}"],
                speaker_notes=f"Highlight the significance of this metric for {topic}.",
            )

        # ---- PROCESS ----
        if slide_type == SlideType.PROCESS:
            step_titles = (
                kps[:4] if kps
                else ["Assess", "Plan", "Execute", "Review"]
            )
            steps = []
            for si, st in enumerate(step_titles):
                if si == 0:
                    status = "completed"
                elif si == 1:
                    status = "active"
                else:
                    status = "future"
                steps.append(ProcessStep(title=_truncate(st), description=f"{st} — {topic}", status=status))
            return SlideDefinition(
                slide_type=slide_type,
                title=title,
                steps=steps,
                active_step=1,
                speaker_notes=f"Walk through each step of the {topic} process and current progress.",
            )

        # ---- TIMELINE ----
        if slide_type == SlideType.TIMELINE:
            step_titles = (
                kps[:4] if kps
                else ["Discovery", "Planning", "Execution", "Delivery"]
            )
            steps = []
            quarter_labels = ["Q1", "Q2", "Q3", "Q4"]
            for si, st in enumerate(step_titles):
                ql = quarter_labels[si % len(quarter_labels)]
                if si == 0:
                    status = "completed"
                elif si == 1:
                    status = "active"
                else:
                    status = "future"
                steps.append(ProcessStep(title=_truncate(st), date=ql, status=status))
            return SlideDefinition(
                slide_type=slide_type,
                title=title,
                steps=steps,
                speaker_notes=f"Review the timeline milestones and current status for {topic}.",
            )

        # ---- STEP_CARDS ----
        if slide_type == SlideType.STEP_CARDS:
            step_titles = (
                kps[:4] if kps
                else ["Assess", "Plan", "Execute", "Review"]
            )
            steps = [
                ProcessStep(title=_truncate(st), description=f"{st} for {topic}")
                for st in step_titles
            ]
            return SlideDefinition(
                slide_type=slide_type,
                title=title,
                steps=steps,
                speaker_notes=f"Explain each step and how they connect in the {topic} workflow.",
            )

        # ---- DASHBOARD ----
        if slide_type == SlideType.DASHBOARD:
            kpis = self._hydrate_dashboard_kpis(kps, topic)
            return SlideDefinition(
                slide_type=slide_type,
                title=title,
                kpis=kpis,
                speaker_notes=f"Review each KPI and highlight trends relevant to {topic}.",
            )

        # ---- ICON_GRID ----
        if slide_type == SlideType.ICON_GRID:
            items = kps[:6] if kps else [
                f"{topic} strategy",
                f"{topic} execution",
                f"{topic} measurement",
                f"{topic} optimization",
            ]
            icons_list = ["\u2605", "\u25CF", "\u25B6", "\u2713", "\u2666", "\u25A0"]
            return SlideDefinition(
                slide_type=slide_type,
                title=title,
                icons=[
                    IconItem(
                        icon=icons_list[i % len(icons_list)],
                        title=item,
                        description=f"Key aspect of {topic}",
                    )
                    for i, item in enumerate(items)
                ],
                speaker_notes=f"Briefly describe each icon and its relevance to {topic}.",
            )

        # ---- CARD_GRID ----
        if slide_type == SlideType.CARD_GRID:
            items = kps[:6] if kps else [
                f"{topic} strategy", f"{topic} execution",
                f"{topic} measurement", f"{topic} optimization",
            ]
            icons_list = ["\u2605", "\u25CF", "\u25B6", "\u2713", "\u2666", "\u25A0"]
            return SlideDefinition(
                slide_type=slide_type, title=title,
                cards=[CardDefinition(
                    title=item, body=f"Key aspect of {topic}",
                    icon=icons_list[i % len(icons_list)],
                ) for i, item in enumerate(items)],
                speaker_notes=f"Walk through each {topic} capability.",
            )

        # ---- IMAGE_TEXT ----
        if slide_type == SlideType.IMAGE_TEXT:
            bullets = self._points_for_slide(input_data, index, count=2)
            body = bullets[0] if bullets else f"Overview of {topic}"
            remaining = bullets[1:] if len(bullets) > 1 else [f"Key insight for {audience}"]
            return SlideDefinition(
                slide_type=slide_type,
                title=title,
                body=body,
                bullets=remaining,
                image_position="left",
                speaker_notes=f"Describe the visual and connect it to {topic}.",
            )

        # ---- TEAM ----
        if slide_type == SlideType.TEAM:
            org = company
            return SlideDefinition(
                slide_type=slide_type,
                title=title,
                team_members=[
                    TeamMember(name="Project Lead", role=f"Leads {topic} at {org}"),
                    TeamMember(name="Technical Lead", role=f"Drives {topic} engineering at {org}"),
                    TeamMember(name="Program Manager", role=f"Coordinates {topic} delivery at {org}"),
                ],
                speaker_notes=f"Introduce each team member and their role in {topic}.",
            )

        # ---- CLOSING ----
        if slide_type == SlideType.CLOSING:
            subtitle = self._closing_message(input_data)
            return SlideDefinition(
                slide_type=slide_type,
                title=title,
                subtitle=subtitle,
                speaker_notes="Summarize and close.",
            )

        # ---- SWOT ----
        if slide_type == SlideType.SWOT:
            return SlideDefinition(
                slide_type=slide_type,
                title=title,
                swot=SwotData(
                    strengths=[f"Strong foundation in {topic}", f"Experienced {audience} team"],
                    weaknesses=[f"Limited resources for {topic}", f"Competing {topic} priorities"],
                    opportunities=[f"Growing demand for {topic}", f"New {topic} partnerships"],
                    threats=[f"Market shifts affecting {topic}", f"Talent competition in {topic}"],
                ),
                speaker_notes=f"Walk through each quadrant of the SWOT analysis for {topic}.",
            )

        # ---- FUNNEL ----
        if slide_type == SlideType.FUNNEL:
            stages = (
                kps[:5] if kps
                else ["Awareness", "Interest", "Evaluation", "Decision"]
            )
            descending_values = ["1,000", "600", "250", "120", "50"]
            return SlideDefinition(
                slide_type=slide_type,
                title=title,
                funnel_stages=[
                    FunnelStage(
                        label=_truncate(s),
                        value=descending_values[i] if i < len(descending_values) else None,
                    )
                    for i, s in enumerate(stages)
                ],
                speaker_notes=f"Explain conversion rates at each stage of the {topic} funnel.",
            )

        # ---- AGENDA ----
        if slide_type == SlideType.AGENDA:
            items = kps[:8] if kps else self._generate_agenda(input_data)
            return SlideDefinition(
                slide_type=slide_type,
                title=title,
                agenda_items=[AgendaItem(title=_truncate(item, 197)) for item in items],
                speaker_notes="Walk through the agenda and set expectations for the session.",
            )

        # ---- CHART ----
        if slide_type == SlideType.CHART:
            points = self._points_for_slide(input_data, index, count=4)
            categories = [p.split(":")[0].strip()[:30] if ":" in p else p[:30] for p in points]
            values = []
            for p in points:
                nums = re.findall(r"[\d.]+", p)
                values.append(float(nums[0]) if nums else float(hash(p) % 90 + 10))
            return SlideDefinition(
                slide_type=slide_type,
                title=title,
                elements=[
                    ChartElement(
                        chart_type=ChartType.BAR,
                        data=ChartData(
                            categories=categories,
                            series=[ChartDataSeries(name=topic[:30], values=values)],
                        ),
                    ),
                ],
                speaker_notes=f"Walk through each data point and highlight key trends in {topic}.",
            )

        # ---- TABLE ----
        if slide_type == SlideType.TABLE:
            points = self._points_for_slide(input_data, index, count=4)
            header = [TableCell(text="Item"), TableCell(text="Details"), TableCell(text="Status")]
            rows = [header]
            for p in points:
                parts = p.split(":", 1)
                item_text = parts[0].strip()
                detail = parts[1].strip() if len(parts) > 1 else f"Details for {item_text}"
                rows.append([
                    TableCell(text=item_text),
                    TableCell(text=detail),
                    TableCell(text="Active"),
                ])
            return SlideDefinition(
                slide_type=slide_type,
                title=title,
                elements=[TableElement(rows=rows)],
                speaker_notes=f"Review each row and discuss the status of {topic} items.",
            )

        # ---- ORG_CHART ----
        if slide_type == SlideType.ORG_CHART:
            return SlideDefinition(
                slide_type=slide_type,
                title=title,
                org_chart=OrgNode(
                    id="lead",
                    name=f"{topic} Lead",
                    role="Program Lead",
                    children=[
                        OrgNode(id="eng", name="Engineering", role="Technical"),
                        OrgNode(id="ops", name="Operations", role="Delivery"),
                        OrgNode(id="biz", name="Business", role="Strategy"),
                    ],
                ),
                speaker_notes=f"Walk through the {topic} organizational structure.",
            )

        # ---- MATRIX ----
        if slide_type == SlideType.MATRIX:
            return SlideDefinition(
                slide_type=slide_type,
                title=title,
                matrix=MatrixData(
                    x_axis_label="Impact",
                    y_axis_label="Effort",
                    top_left=MatrixQuadrant(label="Quick Wins", items=[kps[0] if kps else f"{topic} quick win"]),
                    top_right=MatrixQuadrant(label="Major Projects", items=[kps[1] if len(kps) > 1 else f"{topic} initiative"]),
                    bottom_left=MatrixQuadrant(label="Fill-Ins", items=[kps[2] if len(kps) > 2 else f"{topic} maintenance"]),
                    bottom_right=MatrixQuadrant(label="Thankless Tasks", items=[kps[3] if len(kps) > 3 else f"{topic} overhead"]),
                ),
                speaker_notes=f"Prioritize {topic} initiatives using the effort/impact matrix.",
            )

        # ---- PYRAMID ----
        if slide_type == SlideType.PYRAMID:
            layer_labels = kps[:4] if kps else ["Strategy", "Tactics", "Operations", "Execution"]
            return SlideDefinition(
                slide_type=slide_type,
                title=title,
                pyramid_layers=[
                    PyramidLayer(label=_truncate(lbl, 197), description=f"{lbl} layer of {topic}")
                    for lbl in layer_labels
                ],
                speaker_notes=f"Explain the hierarchical layers of {topic}.",
            )

        # ---- VENN ----
        if slide_type == SlideType.VENN:
            labels = kps[:3] if len(kps) >= 2 else [f"{topic} A", f"{topic} B"]
            return SlideDefinition(
                slide_type=slide_type,
                title=title,
                venn=VennData(
                    circles=[VennCircle(label=lbl) for lbl in labels[:3]],
                    intersection_label=f"Core {topic}",
                ),
                speaker_notes=f"Show the overlap and synergies across {topic} areas.",
            )

        # ---- WATERFALL ----
        if slide_type == SlideType.WATERFALL:
            return SlideDefinition(
                slide_type=slide_type,
                title=title,
                waterfall_bars=[
                    WaterfallBar(label="Baseline", value=100, bar_type="total"),
                    WaterfallBar(label="Growth", value=30, bar_type="increase"),
                    WaterfallBar(label="Efficiency", value=15, bar_type="increase"),
                    WaterfallBar(label="Churn", value=-20, bar_type="decrease"),
                    WaterfallBar(label="Costs", value=-10, bar_type="decrease"),
                    WaterfallBar(label="Net", value=115, bar_type="total"),
                ],
                speaker_notes=f"Walk through each component contributing to the {topic} outcome.",
            )

        # ---- HUB_SPOKE ----
        if slide_type == SlideType.HUB_SPOKE:
            spoke_labels = kps[:6] if kps else [
                f"{topic} Strategy", f"{topic} Execution",
                f"{topic} Measurement", f"{topic} Optimization",
            ]
            return SlideDefinition(
                slide_type=slide_type,
                title=title,
                hub_spoke_center=topic[:30],
                spokes=[SpokeItem(label=lbl) for lbl in spoke_labels],
                speaker_notes=f"Explain how each spoke connects to the central {topic} hub.",
            )

        # ---- CYCLE ----
        if slide_type == SlideType.CYCLE:
            step_labels = kps[:6] if kps else ["Plan", "Build", "Test", "Deploy"]
            return SlideDefinition(
                slide_type=slide_type,
                title=title,
                cycle_steps=[CycleStep(label=lbl) for lbl in step_labels],
                speaker_notes=f"Describe the continuous {topic} cycle and how each step feeds the next.",
            )

        # ---- GANTT ----
        if slide_type == SlideType.GANTT:
            task_labels = kps[:5] if kps else ["Discovery", "Design", "Build", "Test", "Launch"]
            return SlideDefinition(
                slide_type=slide_type,
                title=title,
                gantt_tasks=[
                    GanttTask(
                        label=lbl,
                        start=round(i * 0.18, 2),
                        duration=round(0.25 + (i % 2) * 0.1, 2),
                        progress=max(0.0, 1.0 - i * 0.25),
                    )
                    for i, lbl in enumerate(task_labels)
                ],
                gantt_phases=["Phase 1", "Phase 2", "Phase 3"],
                speaker_notes=f"Review the {topic} project timeline and task progress.",
            )

        # ---- EXECUTIVE_SUMMARY ----
        if slide_type == SlideType.EXECUTIVE_SUMMARY:
            return SlideDefinition(
                slide_type=slide_type,
                title=title,
                executive_summary=self._hydrate_executive_summary(kps, topic),
                speaker_notes=(
                    "Open with the situation, establish why it matters now, "
                    "state the recommended path, then make the ask."
                ),
            )

        # ---- SCORECARD ----
        if slide_type == SlideType.SCORECARD:
            return SlideDefinition(
                slide_type=slide_type,
                title=title,
                scorecard_rows=self._hydrate_scorecard_rows(kps),
                speaker_notes=(
                    "Walk each initiative; explain any amber/red status drivers and mitigation."
                ),
            )

        # ---- TESTIMONIAL ----
        if slide_type == SlideType.TESTIMONIAL:
            return SlideDefinition(
                slide_type=slide_type,
                title=title,
                testimonials=self._hydrate_testimonials(kps, input_data),
                speaker_notes=(
                    "Share each testimonial with context on the customer's situation and outcome."
                ),
            )

        # ---- PRICING_TABLE ----
        if slide_type == SlideType.PRICING_TABLE:
            return SlideDefinition(
                slide_type=slide_type,
                title=title,
                pricing_tiers=self._hydrate_pricing_tiers(kps),
                speaker_notes="Walk each tier; anchor on value, not price.",
            )

        # ---- LOGO_WALL ----
        if slide_type == SlideType.LOGO_WALL:
            return SlideDefinition(
                slide_type=slide_type,
                title=title,
                logo_wall=self._hydrate_logo_wall(kps),
                speaker_notes="Call out 2-3 notable logos; avoid reading the full wall aloud.",
            )

        # ---- FULL_BLEED_HERO ----
        if slide_type == SlideType.FULL_BLEED_HERO:
            return SlideDefinition(
                slide_type=slide_type,
                title=title,
                subtitle=self._generate_subtitle(input_data),
                hero_image=HeroImage(
                    image_path="[Supply hero_image.image_path]",
                    overlay="gradient_bottom",
                    overlay_opacity=0.3,
                    text_position="bottom",
                ),
                speaker_notes="Replace placeholder image path with a real hero asset before presenting.",
            )

        # ---- BEFORE_AFTER ----
        if slide_type == SlideType.BEFORE_AFTER:
            return SlideDefinition(
                slide_type=slide_type,
                title=title,
                before_after=BeforeAfter(
                    before_image_path="[Supply before_image_path]",
                    after_image_path="[Supply after_image_path]",
                    before_label=(kps[0] if len(kps) >= 1 else "Before"),
                    after_label=(kps[1] if len(kps) >= 2 else "After"),
                    delta_text=(kps[2] if len(kps) >= 3 else None),
                ),
                speaker_notes="Narrate the before state, then the after, then the delta.",
            )

        # ---- REFERENCES ----
        if slide_type == SlideType.REFERENCES:
            return SlideDefinition(
                slide_type=slide_type,
                title=title,
                citations=self._hydrate_citations(kps),
                citation_style="numbered",
                speaker_notes="Reference slide — expected to stay on screen during Q&A.",
            )

        # ---- Default: CONTENT / DIAGRAM / BLANK / TITLE ----
        bullets = self._points_for_slide(input_data, index, count=3)
        return SlideDefinition(
            slide_type=slide_type,
            title=title,
            bullets=bullets,
            speaker_notes=f"Cover the key aspects of {title}.",
        )
