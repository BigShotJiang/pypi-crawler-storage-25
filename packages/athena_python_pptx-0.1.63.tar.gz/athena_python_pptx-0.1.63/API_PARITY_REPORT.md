# API Parity Report: athena-python-pptx vs python-pptx

**Generated:** 2026-03-23
**athena-python-pptx version:** 0.1.52
**python-pptx version:** 1.0.2
**Test script:** `tests/test_python_pptx_api_parity.py`
**Classes tested:** 8

---

## Summary

**0 unexpected missing, 0 unexpected extras, 0 param mismatches across all tested classes.**

| Class | Standard Members | Missing | Extra | Status |
|-------|---------|---------|-------|--------|
| FillFormat | solid, background, gradient, patterned, fore_color, back_color, pattern, type | 1 (internal) | 2 (gradient props) | PASS |
| LineFormat | color, dash_style, fill, width | 0 | 2 (is_dashed, is_solid) | PASS |
| RGBColor | from_string, count, index, __iter__, __len__, __getitem__ | 0 | 0 | PASS |
| ColorFormat | rgb, theme_color, brightness, type | 1 (internal) | 0 | PASS |
| Font | bold, italic, underline, size, name, color | 2 (fill, language_id) | 0 | PASS |
| TextFrame | text, paragraphs, margins, auto_size, word_wrap, add_paragraph, clear, fit_text | 1 (part) | 47 (convenience) | PASS |
| Paragraph | alignment, font, level, line_spacing, runs, space_after/before, add_run, clear | 1 (part) | 30 (convenience) | PASS |
| Run | text, font, hyperlink | 1 (part) | 20 (convenience) | PASS |

## Intentionally Omitted

| Member | Reason |
|--------|--------|
| `*.part` | Package part — REST SDK has no local XML packages |
| `FillFormat.from_fill_parent()` | Internal XML constructor |
| `ColorFormat.from_colorchoice_parent()` | Internal XML constructor |
| `Font.fill` | Font fill format — not commonly used |
| `Font.language_id` | Not yet implemented |

## Non-Standard Extras (Candidates for Future Cleanup)

**Core classes (FillFormat, LineFormat, RGBColor, ColorFormat, Font):** Fully cleaned — no non-standard methods.

**TextFrame:** 47 convenience methods (to_html, to_markdown, word_count, capitalize, etc.)
**Paragraph:** 30 convenience methods (bullet helpers, string ops, to_dict, etc.)
**Run:** 20 convenience methods (string ops, is_bold, has_hyperlink, etc.)

These extras are additive (don't break standard code) but should be removed in a future pass to match the same parity standard as the core classes.

## How to Run

```bash
pip install python-pptx --target /tmp/pptx-standard
python -m pytest tests/test_python_pptx_api_parity.py -v -s
```
