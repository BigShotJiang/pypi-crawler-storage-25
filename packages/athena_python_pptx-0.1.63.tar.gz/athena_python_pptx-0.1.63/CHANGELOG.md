# Changelog

All notable changes to `athena-python-pptx` are documented in this file.

## 0.1.63

Theme-hierarchy parity round (originally targeted 0.1.62, but PyPI's 0.1.62
was claimed by an unrelated upload on 2026-05-06 — bumped to 0.1.63 to keep
the SDK and PyPI sequence in step). — closes the remaining python-pptx surface gaps
on `Presentation`, `SlideMaster`, `SlideLayout`, `Slides`, and `SlideShapes`
that the parity test was allow-listing as KNOWN_MISSING.

- **`Presentation.slide_master`** — shorthand for `slide_masters[0]`. Matches
  python-pptx where most single-master decks reach for the canonical master
  via this attribute. Raises `IndexError` if the snapshot has no masters.
- **`SlideMaster.shapes`** / **`SlideMaster.placeholders`** — return empty
  read-only collections instead of raising `AttributeError`. The REST snapshot
  doesn't materialize master-level shapes as first-class elements (they are
  projected onto each slide during ingestion), but code that probes these
  collections for parity now gets a sensible empty result.
- **`SlideLayout.shapes`** — same treatment as the master-level collection.
- **`SlideLayout.slide_master`** — backreference to the parent
  `SlideMaster`. `_build_slide_masters` now threads the master onto each
  child layout when constructing the theme hierarchy, and the backreference
  is `None` only on the legacy hardcoded fallback layouts (used when no
  snapshot is available).
- **`Slides.get(slide_id, default=None)`** — matches python-pptx's
  dict-style lookup. Same backing store as `Slides.get_by_id`, with the
  added optional default-return semantics.
- **`SlideShapes.add_group_shape(shapes=())`** — alias that materializes any
  iterable to a list and forwards to `group_shapes(...)`. Consistent with
  python-pptx's signature; the SDK still requires at least 2 shapes per
  group (one `GroupShapes` command per call).
- **Parity test cleanup** — `tests/test_python_pptx_api_parity.py` no longer
  allow-lists the items above under `KNOWN_MISSING`. Type mismatches for the
  new `@property` accessors are documented in `KNOWN_TYPE_MISMATCHES`
  (functionally identical to python-pptx's `lazyproperty`).

## 0.1.61

Parity round: structural module shims + python-pptx-aligned signatures.

- **Module shims** so user code written against python-pptx imports unchanged:
  `pptx.slide` (Slide / Slides / SlideLayout / SlideMaster / SlideMasters /
  SlideBackground / SlideLayouts), `pptx.table` (Table / `_Cell`), and
  `pptx.action` (Hyperlink, ActionSetting placeholder).
- **`Presentation.save(file=...)`** — renamed kwarg from `path=` to match
  python-pptx exactly. Positional callers (`prs.save("out.pptx")`) keep
  working; keyword callers using `path=` must update.
- **`Slides.add_slide(slide_layout=...)`** — renamed kwarg from `layout=` to
  match python-pptx. `add_blank_slide()` updated internally.
- **`Table.cell(row_idx, col_idx)`** and the `GraphicFrame.cell` shortcut —
  renamed parameters from `(row, col)` to match python-pptx.
- **`SlideShapes.add_chart(x, y, cx, cy, ...)`** — renamed positional
  parameters from `(left, top, width, height)` to match python-pptx (EMU
  semantics unchanged).
- **`pptx.SlideMaster`** — added top-level export (was only available via
  `pptx.slides.SlideMaster` previously).
- **Parity test coverage doubled** — `tests/test_python_pptx_api_parity.py`
  now compares 17 user-facing classes against stock python-pptx, up from 8.
  Newly covered: Presentation, Slide, Slides, SlideLayout, SlideMaster,
  SlideShapes, Table, `_Cell`. All deviations documented as either
  REST-internal omissions (`element` / `part`) or SDK-extension extras.

## 0.1.60

Round 5 fidelity push — close diffs the parity harness surfaces against
`lowes_template_v1.pptx` for `add_shape` / `add_textbox` / `add_picture` /
`add_connector` / `add_table`. End-to-end: SDK → command → applier → Y.Doc →
export-worker → OOXML.

- **python-pptx-style auto-naming for new shapes:**
  `slide.shapes.add_shape(MSO_SHAPE.OVAL, …)` now writes
  `<p:cNvPr name="Oval 2"/>` instead of `name="Shape qR6BLH"`. Mirrors
  python-pptx's deterministic `"<basename> <count_after_add>"` contract so
  AI agents can find shapes by predictable names. Same scheme for
  `add_textbox` (`"TextBox 2"`), `add_picture` (`"Picture 2"`),
  `add_table` (`"Table 2"`), and `add_connector`
  (`"Straight Connector 5"` / `"Elbow Connector …"` / `"Curved Connector …"`).
  New `MSO_SHAPE → basename` map covers all 156 standard auto-shape
  display names (`"Right Triangle"`, `"Rounded Rectangle"`,
  `"Left-Right Arrow"`, etc.). `name` field added to `AddShape` /
  `AddTextBox` / `AddPicture` / `AddConnector` / `AddTable` commands and
  schemas; the applier stores it on the Y.Doc element and the
  export-worker plumbs it through `CreateElement.shapeName`.
- **Default `<p:txBody>` on `add_shape`:** SDK auto-shapes without text
  now emit python-pptx's standard placeholder body
  (`<a:bodyPr rtlCol="0" anchor="ctr"/><a:lstStyle/><a:p><a:pPr algn="ctr"/></a:p>`)
  so PowerPoint's "click to type text" affordance survives an export.
  Previously athena dropped `<p:txBody>` entirely when no text was set,
  which made downstream PowerPoint editing harder.
- **Default `<a:bodyPr>` on `add_textbox`:** new SDK textboxes now write
  `<a:bodyPr wrap="none"><a:spAutoFit/></a:bodyPr>` (python-pptx's
  default — auto-shrink to text). Previously athena wrote `wrap="square"`
  which kept the box at its declared size and wrapped instead. Override
  via `text_frame.word_wrap = True` to restore square-wrap behaviour.

## 0.1.59

Multi-round fidelity push (PR #19786). All items below are end-to-end:
SDK setter → command → applier → Y.Doc → export-worker → OOXML.

- **Picture crop end-to-end (`Shape.crop_left/top/right/bottom`):**
  exported `<p:pic>` now emits `<a:srcRect l/t/r/b="..."/>` inside
  `<a:blipFill>` for both `slide.shapes.add_picture(...)` and
  `placeholder.insert_picture(...)`. Crop fractions clamp to [0,1]
  and convert to OOXML's 1000ths-of-percent.
- **Server-side `<c:title>` for SDK-authored charts (Gap 16
  follow-up):** `chart.has_title = True; chart.chart_title.text_frame.text = '...'`
  on a freshly-added chart now lands in the rendered chart XML. New
  helper folds queued `ChartPatch` ops into the `ChartSpec` before
  authoring (handles `SetChartTitle`, `SetLegendVisible`,
  `UpdateSeriesValue/Name`, `UpdateCategoryLabel`, `SetSeriesColor`).
- **Scatter / bubble `replace_data` (Gap 18 follow-up):**
  `chart.replace_data(XyChartData)` and `chart.replace_data(BubbleChartData)`
  now mutate the rendered chart's `<c:xVal>` / `<c:yVal>` /
  `<c:bubbleSize>` via two new patch ops (`UpdateSeriesXValue`,
  `UpdateBubbleSize`).
- **Run strike + sub/superscript export:** `Run.font.strike = True`,
  `Run.font.subscript = True`, `Run.font.superscript = True` now emit
  `<a:rPr strike="sngStrike"/>` and `<a:rPr baseline="-25000|30000"/>`
  on both SDK-authored runs and `SetTextRunStyle` patches. Schema also
  accepts a raw `baseline: int|null` override.
- **Connector elementType end-to-end:**
  `slide.shapes.add_connector(MSO_CONNECTOR.STRAIGHT, ...)` now
  renders on export as `<p:cxnSp prst="..."/>` with
  `<a:headEnd>/<a:tailEnd>` arrow attributes when set. Previously
  `add_connector` was silently dropped at export time.
- **`add_slide(layout)` routes via snapshot-resolved `layoutPath`:**
  closes the SDK→server layout-index mismatch that broke
  `placeholder.insert_picture()` on Picture-with-Caption slides. The
  SDK's `slide_layouts` ordering comes from the master's
  `<p:sldLayoutIdLst>`, which generally does NOT match the
  `slideLayout{i+1}.xml` filename numbering the server fell back to.
  `add_slide` now forwards `layout._path` (and `layout.name` as
  fallback); the applier prefers `layoutPath > layoutName > layoutIndex`.
- **Theme/scheme color support for shape fill + line:**
  `shape.fill.fore_color.theme_color = MSO_THEME_COLOR.ACCENT_1` and
  `shape.line.color.theme_color = MSO_THEME_COLOR.HYPERLINK` round-trip
  end-to-end as `<a:solidFill><a:schemeClr val="accent1"/></a:solidFill>`
  in the exported OOXML. AI-driven brand templates can now keep
  customers' theme colors instead of hard-coding sRGB. New
  `SetShapeStyle` fields `fill_scheme_color` / `line_scheme_color`;
  setting one clears the corresponding sRGB so each `<a:solidFill>`
  slot has a single declaration.
- **`Picture.crop_*` on `SubstitutePlaceholder(picture)`:** crop
  fields now flow through the substitute-placeholder applier path so
  cropped images filling layout placeholders honour the crop on
  export.

## 0.1.58

- **Gap 18 (scatter / bubble chart authoring):** `slide.shapes.add_chart(XL_CHART_TYPE.XY_SCATTER, ..., XyChartData(...))` and `BUBBLE` with `BubbleChartData(...)` now author end-to-end. Server-side: chart-ooxml emits `<c:scatterChart>` / `<c:bubbleChart>` with `<c:xVal>` / `<c:yVal>` (and `<c:bubbleSize>` for bubble), pairs of value axes (no category axis), and an embedded workbook with x/y/(size) columns per series. SDK: `_split_chart_type` accepts all five `XY_SCATTER*` variants plus `BUBBLE`; `add_chart` and `insert_chart` validate the chart_data shape against the chart-type family. `replace_data` for XY/bubble is still gated (needs new patch ops; see GAP_REPORT.md Gap 18).
- **Gap 9 (notesMaster export):** export-worker now bootstraps a `ppt/notesMasters/notesMaster1.xml` + companion `ppt/theme/themeN.xml` whenever speaker notes are added to a deck without a notesMaster. Generators are extracted into `apps/export-worker/src/notes-master.ts`. Bootstrap path also registers the `notesMaster` relationship in `presentation.xml.rels` and adds content-type overrides for the new parts. Matches python-pptx's behavior for the same flow.

## 0.1.57

- **Gap 13 (line.dash_style export):** SDK shapes / textboxes with `line.dash_style = MSO_LINE_DASH_STYLE.DASH` (or any preset) now emit `<a:prstDash val=...>` inside `<a:ln>` on export. Schema, ooxml-patch shape-creator, and export-worker plumbing all updated.
- **Gap 14 (table column widths / row heights):** `table.columns[i].width` and `table.rows[i].height` on SDK-created tables now emit explicit `<a:gridCol w=...>` and `<a:tr h=...>` instead of dividing evenly.
- **Gap 15 (cell.merge export):** `cell.merge(other)` on SDK-created tables now emits `gridSpan="..."` / `rowSpan="..."` on the merge origin and `hMerge="1"` / `vMerge="1"` on consumed cells.
- **Gap 11 (run.hyperlink export):** `run.hyperlink.address = "https://..."` on SDK-created textboxes now writes `<a:hlinkClick r:id="rId..."/>` plus a corresponding External hyperlink relationship in the slide's `.rels`. Hyperlinked runs auto-underline to match python-pptx visual default.
- **Gap 10 (group_shapes/.ungroup id mapping):** In immediate (non-batched) mode `slide.shapes.group_shapes(...)` now flushes the buffer and stamps the real server-assigned id onto the returned `Shape`, so `group.ungroup()` works in the same statement chain.
- **Presentation.slide_width / slide_height setters:** `prs.slide_width = Inches(13.333)` and `prs.slide_height = Inches(7.5)` now work for python-pptx parity (route through `set_slide_size`).
- **Font.strike / Font.subscript / Font.superscript:** new properties on `Run.font` for python-pptx parity. Persist via the existing run-style emission pipeline.
- **Picture crop (`Shape.crop_top` / `crop_bottom` / `crop_left` / `crop_right`):** image shapes now expose python-pptx-compatible crop fractions (0.0–1.0). Setters emit a new `SetPictureCrop` command that writes to the Y.Doc element via `updateElementCrop`.
- **Connector geometry (`Shape.begin_x` / `begin_y` / `end_x` / `end_y`):** connector shapes expose the python-pptx endpoint API. Setters update the bounding box + `flipH/flipV` accordingly.
- **GroupShape.shapes children traversal:** for `is_group` shapes, `shape.shapes` returns the slide-level Shape objects whose ids match the group's `childIds`, mirroring `python-pptx GroupShape.shapes`.
- New `SetPictureCrop` command on the SDK→server protocol; applier wired through `updateElementCrop`.

## 0.1.56

- **Charts: end-to-end author + edit support** for column / bar / line / area / pie / doughnut (including all stacked variants).
  - `slide.shapes.add_chart(chart_type, left, top, width, height, chart_data)` now authors a fresh chart from scratch — previously raised `UnsupportedFeatureError`. Returns a `GraphicFrame` whose `.chart` property exposes the resulting `Chart` object. Supported types: `XL_CHART_TYPE.COLUMN_CLUSTERED`, `COLUMN_STACKED`, `COLUMN_STACKED_100`, `BAR_CLUSTERED`, `BAR_STACKED`, `BAR_STACKED_100`, `LINE`, `LINE_MARKERS`, `LINE_STACKED`, `LINE_STACKED_100`, `AREA`, `AREA_STACKED`, `AREA_STACKED_100`, `PIE`, `DOUGHNUT`. 3-D / scatter / bubble / radar / stock / surface / combo still raise `UnsupportedFeatureError` with a clearer message listing the supported set.
  - `placeholder.insert_chart(chart_type, chart_data)` now wires up the same path — previously raised `NotImplementedError`.
  - `Chart.replace_data(chart_data)` now emits `UpdateChartData` patches against an existing chart (ingested or just-authored) — previously raised `UnsupportedFeatureError`. Rewrites series values, series names, and category labels in place; embedded `.xlsx` workbook stays in sync.
  - New `Chart.chart_title` setter and `Chart.has_legend` setter emit `SetChartTitle` and `SetLegendVisible` patches respectively.
  - `CategoryChartData.add_series()` and `XyChartData` / `BubbleChartData` now capture data client-side instead of raising eagerly. (Authoring scatter / bubble charts still raises at `add_chart()` time.)
  - `GraphicFrame` extended to host a `Chart` (in addition to `Table`), so `gf.chart` and `gf.has_chart` work.

## 0.1.55

- Internal: bumped version coordinated with the `Presentation.create()` server-side fix (#19270). No SDK API change.

## 0.1.54

- `RemoteError.__str__` now includes the HTTP status code (e.g., `[HTTP 400] Invalid request body: ...`) so the status is visible in tracebacks without unpacking `exc.status_code`.

## 0.1.39

- Added SDK support for `slide.shapes.add_table(...)` and table creation command wiring.
- Added `slide.notes_slide.notes_text_frame.text` compatibility adapter for python-pptx style notes access.
- Added support for auto-shape text frame access (`shape.text_frame`) to match python-pptx behavior.
- Added smoke/integration tests for table creation/cell updates, notes slide adapter, and shape text-frame regression.
- Updated README examples for notes slide adapter and auto-shape text support.
