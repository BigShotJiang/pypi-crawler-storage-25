# Parity tests — `python-pptx` vs `athena-python-pptx`

Small comparison scripts that run the same edit recipe under both SDKs
against the Lowe's brand template and diff the resulting `.pptx`. Used to
identify gaps in our SDK and the studio export pipeline.

## Setup

The two SDKs both register as the import name `pptx`, so we keep them in
separate venvs under `.gitignored_venvs/` (already in `.gitignore`).

```bash
# from this directory
python3 -m venv .gitignored_venvs/real
.gitignored_venvs/real/bin/pip install 'python-pptx==1.0.2'

python3 -m venv .gitignored_venvs/athena
.gitignored_venvs/athena/bin/pip install -e ../  # editable local SDK
```

You'll also need credentials for the staging studio API:

```bash
export ATHENA_PPTX_API_KEY=$BG_STAGING_API_KEY
# default base URL is https://pptx-studio.stg.athenaintel.com
```

And the Lowe's template at `/Users/brendongeils/Downloads/lowes_template_v1.pptx`
(the harness's `DEFAULT_TEMPLATE`).

## Running

```bash
python runner.py             # run all tests
python runner.py test_02     # run just one
```

Outputs land in `outputs/<test>/{real,athena}.{pptx,json}` and a markdown
gap report at `outputs/REPORT.md`.

## How tests are structured

Each `tests/test_NN_*.py` is a self-contained script that takes
`--mode {real|athena} --input <pptx> --output <path>` and produces an
output file. The runner invokes it twice with the two venv interpreters.

The athena flow uploads a fresh deck to staging for each test (so no two
tests share state) — that means each run leaves new decks behind on
staging. Periodically clean those up via the studio API or UI.

## Adding a new test

1. Drop a new `tests/test_NN_<name>.py` with `main(argv)` calling
   `parse_test_argv(argv)` for the standard CLI.
2. Branch on `mode == "real"` vs `"athena"` and import `pptx` accordingly.
3. Re-run `python runner.py test_NN_<name>` and inspect the report.
