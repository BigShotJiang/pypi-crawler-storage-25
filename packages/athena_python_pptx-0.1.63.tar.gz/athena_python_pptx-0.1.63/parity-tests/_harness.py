"""Parity-test harness: diff python-pptx vs athena-python-pptx outputs.

Architecture
------------
- ``runner.py`` calls each ``tests/test_NN_*.py`` *twice*: once with the
  real-pptx venv interpreter and once with the athena-pptx venv interpreter.
- Each test takes ``--mode {real|athena} --input PATH --output PATH``.
- Outputs are two ``.pptx`` files we then unzip, normalize, and diff.

Why two venvs:
  Both packages register as the import name ``pptx``. There's no way to load
  both into the same interpreter; a venv per SDK is the cleanest separation.
"""

from __future__ import annotations

import os
import subprocess
import sys
import zipfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

REPO = Path(__file__).resolve().parents[3]
SDK_ROOT = Path(__file__).resolve().parent.parent
PARITY_ROOT = Path(__file__).resolve().parent
TESTS_ROOT = PARITY_ROOT / "tests"
OUTPUTS_ROOT = PARITY_ROOT / "outputs"
VENVS_ROOT = PARITY_ROOT / ".gitignored_venvs"

REAL_PYTHON = VENVS_ROOT / "real" / "bin" / "python"
ATHENA_PYTHON = VENVS_ROOT / "athena" / "bin" / "python"

# Default Lowe's template path. Tests can override.
DEFAULT_TEMPLATE = Path("/Users/brendongeils/Downloads/lowes_template_v1.pptx")

ATHENA_BASE_URL = os.environ.get(
    "ATHENA_PPTX_BASE_URL", "https://pptx-studio.stg.athenaintel.com"
)


@dataclass
class TestRun:
    """Result of running a test under one SDK."""

    sdk: str  # "real" or "athena"
    output_path: Path
    stdout: str
    stderr: str
    returncode: int

    @property
    def ok(self) -> bool:
        return self.returncode == 0 and self.output_path.exists()


@dataclass
class TestReport:
    """Pair of runs + diff."""

    name: str
    real: TestRun
    athena: TestRun
    diff_summary: list[str] = field(default_factory=list)


def run_test(
    *,
    test_module: Path,
    sdk: str,
    input_path: Path,
    output_path: Path,
    extra_env: Optional[dict[str, str]] = None,
) -> TestRun:
    """Invoke a test module under the given SDK's venv interpreter."""
    interpreter = REAL_PYTHON if sdk == "real" else ATHENA_PYTHON
    env = os.environ.copy()
    if sdk == "athena":
        # Make sure the SDK can read its base URL even if the parent only set
        # ATHENA_BASE_URL or relied on a default.
        env.setdefault("ATHENA_PPTX_BASE_URL", ATHENA_BASE_URL)
    if extra_env:
        env.update(extra_env)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    proc = subprocess.run(
        [
            str(interpreter),
            str(test_module),
            "--mode",
            sdk,
            "--input",
            str(input_path),
            "--output",
            str(output_path),
        ],
        env=env,
        capture_output=True,
        text=True,
        timeout=300,
    )
    return TestRun(
        sdk=sdk,
        output_path=output_path,
        stdout=proc.stdout,
        stderr=proc.stderr,
        returncode=proc.returncode,
    )


def list_pptx_parts(pptx_path: Path) -> list[tuple[str, int]]:
    """Return [(part_path, size_bytes)] for every entry in a .pptx archive."""
    if not pptx_path.exists():
        return []
    with zipfile.ZipFile(pptx_path) as zf:
        return sorted((zi.filename, zi.file_size) for zi in zf.infolist())


def read_pptx_part(pptx_path: Path, part: str) -> Optional[bytes]:
    if not pptx_path.exists():
        return None
    with zipfile.ZipFile(pptx_path) as zf:
        try:
            return zf.read(part)
        except KeyError:
            return None


def _xml_canonical(data: bytes) -> Optional[bytes]:
    """Return a canonical bytes form for XML data, or None if not XML.

    We use ``xml.etree.ElementTree`` rather than shelling out to ``xmllint`` so
    the harness has no system deps. Output is element-tree-roundtripped, which
    normalizes whitespace, attribute order, and quote style — the kinds of
    superficial differences that flood the byte-level diff but don't carry
    fidelity meaning.
    """
    try:
        import xml.etree.ElementTree as ET

        # Strip the XML declaration so two declarations with different attr
        # orders ("standalone" vs "encoding") don't show up as differences.
        root = ET.fromstring(data)
        return ET.tostring(root, encoding="utf-8")
    except Exception:
        return None


def diff_pptx_archives(real: Path, athena: Path) -> list[str]:
    """Compare two .pptx archives. Returns human-readable diff lines.

    Reports two views of the diff:
    - byte-level (every superficial difference, useful for spotting added /
      removed parts)
    - canonical-XML (filters out attribute-order / whitespace noise so only
      *meaningful* content differences remain)
    """
    summary: list[str] = []
    real_parts = dict(list_pptx_parts(real))
    athena_parts = dict(list_pptx_parts(athena))
    if not real_parts:
        summary.append(f"FATAL: real output missing at {real}")
    if not athena_parts:
        summary.append(f"FATAL: athena output missing at {athena}")
    if not real_parts or not athena_parts:
        return summary

    real_only = sorted(set(real_parts) - set(athena_parts))
    athena_only = sorted(set(athena_parts) - set(real_parts))
    common = sorted(set(real_parts) & set(athena_parts))

    if real_only:
        summary.append(f"only-in-real ({len(real_only)}): " + ", ".join(real_only[:8]))
    if athena_only:
        summary.append(
            f"only-in-athena ({len(athena_only)}): " + ", ".join(athena_only[:8])
        )

    byte_diff: list[str] = []
    canon_diff: list[tuple[str, int, int]] = []
    for part in common:
        rb = read_pptx_part(real, part)
        ab = read_pptx_part(athena, part)
        if rb == ab:
            continue
        byte_diff.append(part)
        # XML parts: also check canonical equivalence
        if part.endswith(".xml") or part.endswith(".rels"):
            rc = _xml_canonical(rb or b"")
            ac = _xml_canonical(ab or b"")
            if rc is not None and ac is not None and rc == ac:
                continue
        canon_diff.append((part, len(rb or b""), len(ab or b"")))

    summary.append(f"part counts: real={len(real_parts)} athena={len(athena_parts)}")
    summary.append(
        f"byte-different / canonical-different: {len(byte_diff)} / {len(canon_diff)}"
        f" (of {len(common)} common parts)"
    )
    if canon_diff:
        summary.append("canonical content differences:")
        for name, rs, asize in canon_diff[:30]:
            summary.append(f"  - {name}  real={rs}B athena={asize}B  Δ={asize - rs:+d}")
    return summary


def write_report(reports: list[TestReport], out_path: Path) -> None:
    """Write a markdown gap report comparing all tests."""
    lines: list[str] = []
    lines.append("# python-pptx vs athena-python-pptx parity report\n")
    lines.append(f"Template: `{DEFAULT_TEMPLATE.name}`\n")
    lines.append("")
    for r in reports:
        lines.append(f"## {r.name}\n")
        lines.append(
            f"- real: rc={r.real.returncode} ok={r.real.ok} size="
            f"{r.real.output_path.stat().st_size if r.real.output_path.exists() else 'N/A'}"
        )
        lines.append(
            f"- athena: rc={r.athena.returncode} ok={r.athena.ok} size="
            f"{r.athena.output_path.stat().st_size if r.athena.output_path.exists() else 'N/A'}"
        )
        if r.real.stderr.strip():
            lines.append("- real stderr (first 400 chars):")
            lines.append("  ```")
            lines.append("  " + r.real.stderr.strip()[:400].replace("\n", "\n  "))
            lines.append("  ```")
        if r.athena.stderr.strip():
            lines.append("- athena stderr (first 400 chars):")
            lines.append("  ```")
            lines.append("  " + r.athena.stderr.strip()[:400].replace("\n", "\n  "))
            lines.append("  ```")
        lines.append("- diff:")
        for d in r.diff_summary:
            lines.append(f"  - {d}")
        lines.append("")
    out_path.write_text("\n".join(lines))


# Convenience for tests: a tiny argparse boilerplate ----------------------------


def parse_test_argv(argv: list[str]) -> tuple[str, Path, Path]:
    """Tests use this to read the standard CLI shape."""
    import argparse

    p = argparse.ArgumentParser()
    p.add_argument("--mode", choices=["real", "athena"], required=True)
    p.add_argument("--input", type=Path, required=True)
    p.add_argument("--output", type=Path, required=True)
    args = p.parse_args(argv)
    return args.mode, args.input, args.output
