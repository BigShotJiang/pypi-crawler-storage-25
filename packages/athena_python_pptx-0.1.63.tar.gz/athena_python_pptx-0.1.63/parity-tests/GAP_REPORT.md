# `python-pptx` ↔ `athena-python-pptx` parity gaps

Findings from running the comparison harness against
`lowes_template_v1.pptx` (21 slides, 14 masters, 14 themes). Each test
runs the same recipe under both SDKs and diffs the resulting `.pptx` (or
JSON for read-only tests) byte-for-byte and canonically.

| Test | Real OK | Athena OK | Real-content diffs |
|---|---|---|---|
| 01 — open + save (no edits) | ✓ | ✓ | 9 / 50 parts |
| 02 — set slide 1 title | ✓ | ✓ | similar to 01 + slide 1 |
| 03 — fill 3 captions | ✓ | ✓ | similar + slide 2 |
| 04 — add slide from layout | ✓ | ✓ | similar + new slide |
| 05 — describe shapes (read-only) | ✓ | ✓ | structure differs significantly |
| 22 — table cell formatting | ✓ | ✓ | passes — Gap #12 fixed (SDK-side parity shims) |
| 23 — chart `replace_data` | ✓ | ✗ | post-upload 404, retry budget too short |
| 24 — `shape.rotation = 45` | ✓ | ✓ | `<a:xfrm rot=...>` matches; minor cosmetics |
| 25 — `run.hyperlink.address = ...` | ✓ | ✓ | hyperlink dropped — see Gap #11 |
| 26 — paragraph alignment + line spacing + space before/after | ✓ | ✓ | `<a:pPr algn>` / `<a:lnSpc>` / `<a:spcBef>` / `<a:spcAft>` match |
| 27 — text frame `word_wrap` / `vertical_anchor` / margins | ✓ | ✓ | `<a:bodyPr wrap/anchor/lIns/rIns/tIns/bIns>` match |
| 28 — `line.dash_style = MSO_LINE_DASH_STYLE.DASH` | ✓ | ✓ | dash dropped — see Gap #13 |
| 29 — `add_shape` with OVAL / RIGHT_TRIANGLE / HEXAGON | ✓ | ✓ | `<a:prstGeom prst=...>` matches for all three |
| 30 — `table.columns[i].width = ...` | ✓ | ✓ | column widths dropped — see Gap #14 |
| 31 — `cell.merge(other_cell)` | ✓ | ✓ | merge attributes dropped — see Gap #15 |
| 32 — bar chart (`BAR_CLUSTERED`) | ✓ | ✓ | structure matches; xlsx filename + cosmetic deltas |
| 33 — multi-series line chart (3 series) | ✓ | ✓ | 3 `<c:ser>` blocks emitted on both, structure matches |
| 34 — swap multiple slides to a `SlideLayout` object | ✓ | ✓ | rels-rewrite path runs; minor diff in rels structure |
| 35 — `table.rows[i].height = ...` | ✓ | ✓ | row heights dropped — see Gap #14 (same root cause) |
| 36 — pie chart (`PIE`) | ✓ | ✓ | `<c:pieChart>` matches; same xlsx-filename / cosmetic deltas |
| 37 — `chart.has_title = True` then set title text | ✓ | ✓ | passes — Gap #16 fixed (server-side title export still pending) |
| 38 — stacked bar chart (`BAR_STACKED`) | ✓ | ✓ | `<c:grouping val="stacked"/>` + `<c:overlap val="100"/>` match |
| 39 — `chart.has_legend = True` after `add_chart` | ✓ | ✓ | divergent: real omits `<c:legend>` block, athena emits explicit `legendPos="b"` |
| 40 — notes slide with 3 paragraphs + bold first run | ✓ | ✓ | passes — Gap #17 fixed (SDK-side; bold not exported) |
| 41 — doughnut chart (`DOUGHNUT`) | ✓ | ✓ | `<c:doughnutChart><c:holeSize val="50"/>` matches |
| 42 — scatter plot (`XY_SCATTER`) via `XyChartData` | ✓ | ✗ | crashes — see Gap #18 |
| 43 — notes set on 3 slides | ✓ | ✓ | both produce `notesSlide1/2/3.xml`; matches Gap #9 (notesMaster missing) |

## Gap 1 — `slide.shapes` iterator yields inherited content

**Severity:** high (every read workflow). **Easy to fix.**

`python-pptx` definition: `slide.shapes` returns only shapes authored on
the slide. Inherited content (layout placeholders, master images) is
accessed via `slide.slide_layout.shapes` / `slide.slide_layout.slide_master.shapes`.

Our SDK returns slide-level shapes **plus** inherited layout/master
shapes mixed into the same iterator. Concrete example from slide 2 of the
Lowe's deck:

```text
real:   7 shapes  ['Title 1', 'Picture Placeholder 2', …'Text Placeholder 7']
athena: 16 shapes [None, None, None, None, None, None, None, None, None,
                   'Title 1', 'Picture Placeholder 2', … 'Text Placeholder 7']
```

The 9 unnamed shapes are: 2 master images (Lowe's logo + brand background
EMF) and 7 inherited placeholder copies that mirror the slide-level shells.

**Fix:** in `python-sdk/pptx/shapes.py` `Shapes.__iter__` filter out
elements whose `source` is `'layout'` or `'master'`. The placeholders API
endpoint already has this filter (commit `25c11a6fc3` on PR #19710). The
shapes iterator needs the same de-dup logic.

## Gap 2 — `shape.shape_type` returns raw element type instead of `MSO_SHAPE_TYPE`

**Severity:** medium (breaks `MSO_SHAPE_TYPE.PLACEHOLDER` checks).

`python-pptx` returns `MSO_SHAPE_TYPE.PLACEHOLDER (14)` for placeholder
shapes. Our SDK returns the raw element discriminant: `'text'`,
`'image'`, `'shape'` etc.

Concrete from slide 1:
```text
real:   shape_types = ['PLACEHOLDER (14)']
athena: shape_types = ['text', 'text', 'image']
```

**Fix:** in `python-sdk/pptx/shapes.py` `Shape.shape_type` property,
return `MSO_SHAPE_TYPE.PLACEHOLDER` when `self.is_placeholder` is true,
otherwise map element types to their `MSO_SHAPE_TYPE` equivalents
(`AUTO_SHAPE`, `PICTURE`, `TEXT_BOX`, etc.). python-pptx exports the
enum from `pptx.enum.shapes`.

## Gap 3 — `shape.name` is `None` for inherited shapes

**Severity:** medium (search by name fails for layout placeholders).

When iterating inherited shapes, `shape.name` returns `None` because the
synthetic `__inherited__:slideId:elementId` element doesn't propagate the
underlying layout shape's `cNvPr/@_name`. Real example:
```text
inherited title: name=None  (should be 'Title 1' from layout)
```

**Fix:** in the snapshot builder (`apps/api/src/commands/snapshot.ts`)
make sure the inherited element's properties carry the source layout
element's `name` — the layout-element data already has it; just thread
it through the synthetic projection.

## Gap 4 — Athena export bakes layout text-style defaults into slide runs (FIXED)

**Status:** fixed in this PR.

**Root cause was:** `packages/support-registry/src/handlers/text-run.ts`
merged master / placeholder / local-`<a:lstStyle>` defaults into
`richContent.paragraphs[].runs[].style`. The export-worker then emitted
a `SetTextRunStyle` patch for any run with a non-empty style, baking
those resolved defaults back into the slide's `<a:rPr>`.

**Fix:** split authored vs. resolved style. Ingest now stores the merged
defaults on the new `Paragraph.defaultRunStyle` schema field and keeps
`runs[].style` to **only the explicitly-authored attributes** from the
slide's `<a:rPr>`. The renderer's existing
`mergeTextStyleLayers(paragraph.defaultRunStyle, run.style)` logic at
`render-core/element-builder.ts:1330` combines them at draw time so
visible behaviour is unchanged. Export-worker's gate
`if (runStyle && (runStyle.colorHex || …))` naturally skips unauthored
runs because their style is now undefined.



**Severity:** medium (fidelity drift; layout retheming won't propagate).

For `lowes_template_v1.pptx` slide 7 (and 8-14), the original deck's
slide XML has empty placeholder shells:

```xml
<a:p><a:r><a:rPr lang="en-US" dirty="0"/><a:t>Title</a:t></a:r></a:p>
```

`python-pptx` no-op roundtrip preserves these empty `<a:rPr/>` shells.
Athena's export adds explicit text-style overrides pulled from the
layout's `<a:lstStyle>`:

```xml
<a:p>
  <a:pPr><a:lnSpc><a:spcPct val="90000"/></a:lnSpc></a:pPr>
  <a:r>
    <a:rPr lang="en-US" dirty="0" sz="6600" b="1">
      <a:latin typeface="Gadugi"/>
    </a:rPr>
    <a:t>Title</a:t>
  </a:r>
</a:p>
```

This denormalizes layout-supplied defaults into slide-level run
properties. Two consequences:

1. If the user retheme's the layout (different font / size), the slides
   no longer pick up the new defaults — the values are now baked in.
2. The exported deck is structurally divergent from what was uploaded
   (the no-op roundtrip is no longer a no-op).

**Fix:** trace through `apps/api/src/commands/applier.ts` and
`apps/export-worker/src/main.ts` to find where layout style attributes
get serialized onto slide-level runs. Likely culprit: a "materialize
inherited content" pass that's resolving layout `<a:lstStyle>` defaults
when it shouldn't. The fix is to only materialize the placeholder
metadata (idx, type, name) and leave run properties empty so PowerPoint
re-resolves them from the layout at render time.

## Gap 5 — Upload poll timeout was hardcoded too short

**Severity:** low (already fixed in this branch).

`DEFAULT_MAX_POLL_ATTEMPTS = 30` × `DEFAULT_POLL_INTERVAL = 0.5s` = 15s
budget for upload+ingest. Lowe's brand template (21 slides, 14 masters,
11 EMFs) consistently took 25-60s on staging, so `Presentation.upload()`
raised `UploadError("Processing timed out")` even though the deck was
fine.

**Fix shipped:** bumped default to 240 attempts (120s) and added an
explicit `max_wait_seconds=...` knob on `Presentation.upload()`. See the
commit on this branch.

## Gap 6 — Picture placeholder substitution doesn't persist assetId

**Severity:** high (template-driven generation with pictures is broken).
**Already filed** in the previous PR cycle.

`SDK insert_picture(image_path)` → emits `SubstitutePlaceholder(kind='picture', image_base64=...)`
→ applier flips placeholder element `type='image'` ✓ but never sets
`assetId`. Render shows broken-image-X; export emits `<p:pic
r:embed="rId_phPic_*">` with no matching relationship in the slide rels
or media file in `/ppt/media/`.

Likely fix: in `apps/api/src/commands/applier.ts` `applySubstitutePlaceholder`
add an asset-upload step (analogous to the existing `addPicture` flow)
that uploads the base64 bytes and stamps the resulting `assetId` on the
materialized image element.

## Gap 7 — Post-upload Agora 404 race (FIXED in SDK)

**Status:** mitigated in this PR via SDK retry; no server change yet.

**Symptom:** after a fresh ``Presentation.upload(...)`` succeeds and our
own ingest reports ``status == "ready"``, the *next* SDK call (typically
``prs.save()`` → ``start_export``) sometimes hits ``Asset not found``.
Agora's asset registry takes ~30-40s to settle on heavy decks like the
Lowe's brand template.

**Wrinkle:** the studio API route handler calls ``getAsset(id)`` which
throws ``AgoraApiError(404, …)``. Fastify's default error handler wraps
that as **HTTP 500** with the original ``Agora API error 404: …`` body.
So the SDK was seeing ``status_code = 500``, not ``404`` — first-pass
retry on raw 404 didn't catch it.

**Fix in `python-sdk/pptx/client.py`:** ``_is_post_upload_404`` detects
both forms (raw 404, or 500-wrapped via the message body). Wired into
``start_export`` and ``get_export_status`` via ``_retry_on_404`` (12
attempts × linear backoff = ~39s budget).

## Gap 8 — `add_connector` rejected `MSO_CONNECTOR` enum (FIXED)

**Status:** fixed in this PR.

`shapes.add_connector(MSO_CONNECTOR.STRAIGHT, …)` raised
`ValidationError: connector_type must be 'straight', 'elbow', or 'curved'`.
Now accepts both the string form and the IntEnum, mapping
`STRAIGHT → 'straight'`, `ELBOW → 'elbow'`, `CURVE → 'curved'`. Matches
python-pptx's parameter behaviour.

## Gap 9 — `notes_slide` doesn't write notesMaster (PARTIAL)

**Status:** **fixed in v0.1.58.** The export-worker now bootstraps
`ppt/notesMasters/notesMaster1.xml` plus a companion `ppt/theme/themeN.xml`
on demand whenever speaker notes are added to a deck that lacks a
notesMaster. New helpers live in
`apps/export-worker/src/notes-master.ts` (testable in isolation). The
bootstrap path:

1. Walks the slides; if any slide has notes AND no `notesSlide` rel exists
   on it AND `presentation.xml.rels` has no `notesMaster` relationship,
   triggers the bootstrap.
2. Writes `notesMaster1.xml` (header / date / slide-image / body /
   footer / slide-num placeholders + `<p:clrMap>` + `<p:notesStyle>`)
   and `theme${nextNum}.xml` (default Office color/font/format scheme).
3. Adds `ppt/notesMasters/_rels/notesMaster1.xml.rels` linking to that
   theme.
4. Registers the `notesMaster` relationship in
   `ppt/_rels/presentation.xml.rels` so PowerPoint discovers it.
5. Adds content-type overrides for both new parts.
6. The existing notes-slide creation path then links each
   `notesSlideN.xml` to the now-present notesMaster.

## Gap 10 — `group_shapes(...)` then `.ungroup()` in immediate-mode batch

**Status:** **fixed in v0.1.57 (SDK-side).** When the SDK is in auto-batch
mode (no explicit `with prs.batch():` context), `Shapes.group_shapes(...)`
now force-flushes the buffer right after queueing the `GroupShapes`
command, reads the response's `created.shapeIds`, and stamps the real
server-assigned id onto the returned `Shape`. The subsequent `group.ungroup()`
therefore sends the real id and the applier resolves it without falling
back on per-batch client-id mapping.

```python
grp = slide.shapes.group_shapes([s1, s2])   # returns Shape, in-memory id 'grp_xxx'
grp.ungroup()                               # ❌ "Group not found: grp_xxx"
```

The applier creates the group with a real id but the SDK's local Shape
object retains the synthetic ``grp_xxx`` client id. When ``ungroup()``
fires, it sends the client id and the applier rejects it. Likely fix:
``group_shapes`` needs to wait for the applier's ``created.shapeIds``
response and stamp the real id back onto the returned Shape, similar
to how ``add_shape``/``add_picture`` already do. Same code shape exists
for ``add_connector`` (line 3142).

## Gap 11 — `run.hyperlink.address` doesn't persist on export

**Status:** **fixed in v0.1.57.** The SDK already attached `hyperlinkUrl`
to its `richContent` payload; the missing piece was the `CreateElement`
patcher / export-worker path for SDK-created textboxes. The plumbing
now mirrors the `SetTextRun` pathway:

1. `CreateElementIntent.richContent.runs[].hyperlinkUrl` carries the URL
   through `apps/export-worker → packages/ooxml-patch`.
2. `buildRunToken` (`packages/ooxml-patch/src/shape-creator.ts`) writes
   `<a:hlinkClick r:id="rIdN"/>` inside the run's `<a:rPr>` and
   auto-underlines the run for visual parity with python-pptx.
3. `createTextboxNode` returns allocated rIds via an `AllocatedHyperlinkRId[]`
   out-array; the patcher hoists those to its result's
   `hyperlinkRelationships`.
4. The export-worker (already present, used by the `SetTextRun` path)
   registers each via `addRelationship`, swaps the placeholder rId for
   the real one in the slide XML, and writes the updated `_rels`.

`run.hyperlink.address = "https://..."` accepts the value on the SDK
side (the `Hyperlink` class even warns in its docstring that "links may
not persist to the exported PPTX until backend support is added").
Diff for slide 1's run / rels:

```text
real:   <a:r><a:rPr><a:hlinkClick r:id="rId2"/></a:rPr><a:t>Visit lowes.com</a:t></a:r>
        slide1.xml.rels: <Relationship Id="rId2" Type=".../hyperlink" Target="https://..." TargetMode="External"/>
athena: <a:r><a:rPr lang="en-US" smtClean="0"/><a:t>Visit lowes.com</a:t></a:r>
        slide1.xml.rels: (no hyperlink relationship)
```

**Fix sketch:** the studio applier needs a `SetTextRunHyperlink` (or
similar) command path. Ingest already preserves `hyperlinkUrl` on the
text-run model (`text-run.ts` reads `hlinkClick`); the export-worker's
text-run emitter must turn that back into the `<a:hlinkClick>` plus
slide-level relationship pair. Hooking this up needs:

1. `Run.hyperlink.address` setter emits a command like
   `SetTextRunHyperlink({shape_id, path, url, tooltip})`
2. Applier persists the URL on the run-level metadata in Y.Doc
3. Export-worker reads the URL, allocates an `rId` in the slide's rels,
   and writes `<a:hlinkClick r:id="rId{N}"/>` inside the run's `<a:rPr>`

## Gap 12 — `TableCell.fill` is `Optional[str]` (no `FillFormat` API)

**Status:** **fixed in this PR (SDK-side)**.

python-pptx exposes `cell.fill` as a `FillFormat` instance (so callers
do `cell.fill.solid()` then `cell.fill.fore_color.rgb = RGBColor(...)`)
and `cell.text_frame` as a full `TextFrame`.

Athena's `TableCell.fill` returns `Optional[str]` (a hex string, see
`pptx/shapes.py:3895`) and there's no `cell.text_frame` at all. So the
following standard recipe blows up:

```python
cell.fill.solid()                                 # AttributeError: 'NoneType' has no attribute 'solid'
cell.fill.fore_color.rgb = RGBColor(0xFF,0,0)
cell.text_frame.paragraphs[0].runs[0].font.bold = True   # AttributeError: 'TableCell' has no attribute 'text_frame'
```

The cell already tracks `_fill_color_hex`, `_bold`, `_font_size_pt`,
`_font_color_hex` and emits `SetTableCell` commands when they're
mutated. So a fix is mostly API shape, not new server commands:

1. `cell.fill` should return a `_TableCellFillFormat` object with
   `.solid()` (no-op + flip type), `.fore_color` (returns a ColorFormat
   that, on `.rgb` setter, writes `cell._fill_color_hex` and emits
   `_emit_cell_change`), and `.background()` (clears the hex).
2. `cell.text_frame` should return a `_TableCellTextFrame` whose
   single paragraph yields a single run with a `.font.bold/.size/.color`
   that delegates to the cell's existing per-cell style fields.

Long-term, multi-paragraph / multi-run table cells need a real
`<a:txBody>` model on the server side; the parity shim above just
preserves the python-pptx API for the common single-paragraph case.

**Fix shipped:** added `_TableCellFillFormat` (`shapes.py:3839+`)
exposing `.solid()` / `.fore_color.rgb` / `.background()`, and a
matching `_TableCellTextFrame` (with `.paragraphs[0].runs[0].font.
{bold,size,color}`). Both route into the existing
`_emit_cell_change` pipeline so the same `SetTableCell` command picks
up the changes. The legacy `cell.fill = "FF0000"` shorthand is kept
for backwards compatibility. Test 22 now passes both ways with
correct output (header row bold + Lowe's blue fill + white text).

## Gap 13 — `line.dash_style = ...` doesn't emit `<a:prstDash>` on export

**Status:** **fixed in v0.1.57.** The SDK side was already routing
`MSO_LINE_DASH_STYLE` through `SetShapeStyle.line_dash`; the applier
already wrote `strokeDashStyle` onto the Y.Doc element. The missing
pieces were:

- `CreateElementIntent.strokeDashStyle` field on the patch schema.
- `apps/export-worker` reading `strokeDashStyle` off the element map
  for both shape and text-frame paths and passing it through.
- `packages/ooxml-patch/shape-creator/buildLineToken(...)` mapping the
  preset name (`solid` / `dash` / `dot` / `dash_dot` / `long_dash` /
  `long_dash_dot`) to the OOXML preset (`solid` / `dash` / `dot` /
  `dashDot` / `lgDash` / `lgDashDot`) and emitting
  `<a:prstDash val=...>` inside `<a:ln>` after `<a:solidFill>`.

Round-trip is now byte-stable for SDK-created shapes / textboxes with
dash styling. Verified by `parity-fixes.test.ts`.

`shape.line.dash_style = MSO_LINE_DASH_STYLE.DASH` is accepted by the
SDK and reads back the right value, but the exported PPTX has no
`<a:prstDash val="..."/>` inside `<a:ln>`:

```xml
real:   <a:ln w="38100"><a:solidFill>...</a:solidFill><a:prstDash val="dash"/></a:ln>
athena: <a:ln w="38100"><a:solidFill>...</a:solidFill></a:ln>
```

Color and width round-trip correctly. Only the dash token is dropped.

**Fix sketch:** the SDK already stores `_dash_style` on `LineFormat`
and emits a `SetShapeStyle` (or similar) command via
`_emit_style_change`. Either:

1. The command payload doesn't carry `dash_style` (check the command
   schema in `pptx-studio/packages/schema/src/commands.ts` — likely
   missing the field), or
2. The applier ignores `dash_style` when applying the command.

The export-worker's shape line emitter would then write
`<a:prstDash val="${mapped}"/>` inside `<a:ln>` after `<a:solidFill>`.
Mapping: `'dash' → "dash"`, `'dot' → "dot"`, `'dash_dot' → "dashDot"`,
`'long_dash' → "lgDash"`, `'long_dash_dot' → "lgDashDot"`.

## Gap 14 — `table.columns[i].width` and `rows[i].height` are silent on export

**Status:** **fixed in v0.1.57.** The SDK already accepted the values
and the applier already wrote `columnWidthsEmu` / `rowHeightsEmu` onto
the Y.Doc table; the missing piece was the SDK-created-table
`CreateElement` path. Both fields are now part of `CreateElementIntent`
and `createTableNode` in shape-creator uses them to write
`<a:gridCol w=...>` / `<a:tr h=...>` instead of dividing evenly.

The SDK accepts both per-column widths and per-row heights and emits
the corresponding commands (`SetColWidth` / `SetRowHeight` —
`pptx/shapes.py:4332` and `pptx/shapes.py:4283`), but the exported
deck has equal-width columns and equal-height rows:

```xml
# Columns (1.0 / 4.5 / 1.5 inches set):
real:   <a:tblGrid>
          <a:gridCol w="914400"/>   <!-- 1.0 in -->
          <a:gridCol w="4114800"/>  <!-- 4.5 in -->
          <a:gridCol w="1371600"/>  <!-- 1.5 in -->
        </a:tblGrid>
athena: <a:tblGrid>
          <a:gridCol w="2133600"/>  <!-- table_width / 3 -->
          <a:gridCol w="2133600"/>
          <a:gridCol w="2133600"/>
        </a:tblGrid>

# Rows (0.7 / 0.4 / 0.4 / 0.4 inches set):
real:   <a:tr h="640080"/> <a:tr h="365760"/> <a:tr h="365760"/> <a:tr h="365760"/>
athena: <a:tr h="457200"/> <a:tr h="457200"/> <a:tr h="457200"/> <a:tr h="457200"/>
                           <!-- table_height / 4 each -->
```

**Fix sketch:** trace `SetColWidth` and `SetRowHeight` through
`apps/api/src/commands/applier.ts`. Either the applier doesn't write
the per-column / per-row sizes into the Y.Doc table model, or the
export-worker's table emitter ignores the per-cell sizes and divides
`table.width / cols` and `table.height / rows` evenly.

## Gap 15 — `cell.merge(other_cell)` doesn't emit merge attrs on export

**Status:** **fixed in v0.1.57.** Same root cause as Gap 14 — the
SDK-created-table `CreateElement` path didn't carry the per-cell
`span` info onto its `cellData` payload. `CreateElementIntent.cellData`
now accepts `{gridSpan, rowSpan, hMerge?, vMerge?}` per cell, the
export-worker maps `tableData.cells[r][c].span` into it, and
`createTableNode` writes `gridSpan="..."` / `rowSpan="..."` on the
merge origin and `hMerge="1"` / `vMerge="1"` on consumed cells.

`origin.merge(bottom_right)` is accepted on the SDK (and `TableCell.merge`
at `pptx/shapes.py:4012` emits a `MergeCells` command), but the exported
table has no merge information — every cell is independent:

```xml
real:   <a:tc rowSpan="2" gridSpan="2">…</a:tc>      <!-- merge origin -->
        <a:tc rowSpan="2" hMerge="1">…</a:tc>        <!-- consumed -->
        <a:tc gridSpan="2" vMerge="1">…</a:tc>       <!-- consumed -->
        <a:tc hMerge="1" vMerge="1">…</a:tc>         <!-- consumed -->
athena: <a:tc>…</a:tc> × 9   (no merge attributes anywhere)
```

**Fix sketch:** trace the `MergeCells` command through the applier
into the Y.Doc table model. The export-worker's table emitter then
needs to translate the cell's `_grid_span / _row_span / _h_merge /
_v_merge` into `gridSpan="…" rowSpan="…" hMerge="1" vMerge="1"`
attributes on `<a:tc>`. Both writes need to land for a merged region
to render in PowerPoint.

## Gap 16 — `Chart.has_title` setter is missing

**Status:** **fixed in this PR (SDK-side)**.

```python
chart.has_title = True   # AttributeError on athena
chart.chart_title.text_frame.text = "Q4 storefront revenue"
```

python-pptx exposes `has_title` as a read/write property and
`chart_title.text_frame` as a `TextFrame` so titles are mutable.
Athena exposes `has_title` and `chart_title` only as getters
(`pptx/shapes.py:951` / `pptx/shapes.py:1026`), so the standard
"toggle title on then set its text" recipe blows up.

**Fix sketch:**

1. Add a `has_title` setter that emits a chart-level command
   (`SetChartHasTitle(shape_id, value)`) so the title `<c:title>`
   block can be toggled in the chart XML.
2. Make `chart.chart_title` return a `_ChartTitle` object whose
   `text_frame.text` setter emits a `SetChartTitle(shape_id, text)`
   command. Internally this lands as `<c:title><c:tx><c:rich>...
   <a:t>...</a:t>...</c:rich></c:tx></c:title>` in the chart XML.
3. The applier persists the toggle/text into the chart node in
   Y.Doc; the export-worker emits the matching XML.

**Fix shipped:** added `has_title` setter (no-op for True; clears the
title via empty SetChartTitle for False), `_ChartTitle` adapter
(`shapes.py:931+`) with `.text_frame.text = ...`, and updated
`Chart.chart_title` to return the adapter object. The legacy
`chart.chart_title = "string"` shorthand still works. Test 37 no
longer crashes on athena. **Server-side note:** the export-worker
still drops `<c:title>` for newly-added charts even when the
`SetChartTitle` patch is queued (also the case before this fix);
that's a separate server-side bug to address in a follow-up.

## Gap 17 — `NotesTextFrame` is text-only (no paragraphs/runs)

**Status:** **fixed in this PR (SDK-side)**.

```python
tf = slide.notes_slide.notes_text_frame
tf.text = "Talking points:"
tf.paragraphs[0].runs[0].font.bold = True   # AttributeError on athena
tf.add_paragraph()                          # AttributeError on athena
```

Athena's `NotesTextFrame` (`pptx/slides.py:206`) only has a `text`
getter/setter that round-trips a flat string. python-pptx returns a
full `TextFrame` for `notes_text_frame`, so multi-paragraph notes
with per-run styling work the same way as a slide-level textbox.

**Fix sketch:** make `NotesTextFrame` extend (or wrap) the real
`TextFrame` so `.paragraphs / .add_paragraph() / .runs / .font` all
work. The target serialization is the notes slide's body placeholder
`<p:txBody>`, which is structurally identical to a slide textbox; the
existing run/paragraph commands should land there as long as the
applier knows to route notes-frame writes to the notes slide rather
than the visible slide.

**Fix shipped:** `NotesTextFrame` (`slides.py:206+`) now tracks
paragraphs locally and exposes `.paragraphs / .add_paragraph()` plus
synthetic `_NotesParagraph / _NotesRun / _NotesRunFont` shims. On
any text mutation, paragraphs are joined with `\n` and persisted via
`slide.notes = ...`. Test 40 now passes — multi-paragraph notes
round-trip correctly through the notes slide body. Per-run styling
(bold, size, color) is accepted on the API but not exported (notes
are flat strings server-side); a real `<p:txBody>` notes model is a
follow-up.

## Gap 18 — `add_chart` hard-rejects non-category data shapes

**Status:** **fixed in v0.1.58 for `add_chart` and `insert_chart`** (the
two authoring entrypoints). `replace_data` for scatter/bubble is a
follow-up — needs new chart patch ops `UpdateSeriesXValue` /
`UpdateBubbleSize` since the existing `UpdateSeriesValue` patcher only
mutates `<c:val>`, not `<c:xVal>` / `<c:yVal>` / `<c:bubbleSize>`.

End-to-end fix path for authoring scatter/bubble:

1. **SDK side (`pptx/shapes.py`, `pptx/chart/data.py`):**
   - `_CHART_TYPE_MAP` now includes `XL_CHART_TYPE.XY_SCATTER`,
     `XY_SCATTER_LINES`, `XY_SCATTER_LINES_NO_MARKERS`,
     `XY_SCATTER_SMOOTH`, `XY_SCATTER_SMOOTH_NO_MARKERS`, and
     `BUBBLE` → `("scatter"|"bubble", None)`.
   - `add_chart()` validates that `chart_data` matches the chart type
     family: `XyChartData` for scatter, `BubbleChartData` for bubble,
     `CategoryChartData` for everything else.
   - `XyChartData.to_series_payload()` and
     `BubbleChartData.to_series_payload()` emit `xValues` (and
     `bubbleSizes` for bubble) alongside `values`.

2. **Schema (`packages/schema/src/sdk-commands.ts`):**
   - `AddChartCommandSchema.chartType` now accepts `'scatter'` and
     `'bubble'`.
   - `ChartSeriesInputSchema` gained optional `xValues` and
     `bubbleSizes` arrays.

3. **Applier (`apps/api/src/commands/applier.ts`):**
   - `buildSdkChartSpec` now branches on plot family. XY plots get two
     `value` axes (no category axis); the SeriesSpec carries
     `xValues` / `bubbleSizes`; categories are not duplicated onto the
     series.
   - The legacy `chartData` shape carried alongside also propagates
     `xValues` / `bubbleSizes` so the live editor render is correct.

4. **Chart-OOXML authoring (`packages/chart-ooxml/src/export/author.ts`):**
   - `renderPlot` switch case routes `'scatter'` to
     `renderScatterChart` and `'bubble'` to `renderBubbleChart`.
   - New `renderXySeries` writes `<c:xVal>`/`<c:yVal>` (and
     `<c:bubbleSize>` for bubble) instead of `<c:cat>`/`<c:val>`,
     referencing the embedded workbook by column.
   - New `renderXyAxes` writes a pair of `<c:valAx>` blocks (one for
     x, one for y) instead of the category-axis pair.
   - Embedded workbook layout for XY plots: each series owns 2 columns
     (x, y), or 3 columns (x, y, size) for bubble. Headers in row 1
     give the series name; data starts at row 2.

Verified via 2 new unit tests in
`packages/chart-ooxml/src/index.test.ts` ("emits c:scatterChart with
c:xVal/c:yVal", "emits c:bubbleChart with c:bubbleSize") and 6 new
SDK tests in `python-sdk/tests/test_parity_additions.py`.

```python
data = XyChartData()         # importable, allowed in python-pptx
data.add_series("Sales").add_data_point(100, 24)
slide.shapes.add_chart(XL_CHART_TYPE.XY_SCATTER, ..., data)
# TypeError: add_chart() requires a CategoryChartData instance (got XyChartData)
```

The validation at `pptx/shapes.py:3214` rejects everything except
`CategoryChartData`, so the scatter / bubble / "other" XL chart
families that use the XY-paired data shape can't be added at all.
Same limit also blocks `replace_data` (`shapes.py:968`) and
`insert_chart` (`shapes.py:2525`).

**Fix sketch:** the chart command schema already carries a generic
`series` payload — add a branch for XY data and write
`<c:scatterChart>` / `<c:bubbleChart>` from the export-worker side,
plus a chart-data dict that uses `xVal/yVal` instead of `cat/val`.
Could be incremental (one new chart family at a time) since today
nothing in this code path works for non-category charts.

## Cosmetic non-issue: `[Content_Types].xml` shape

Athena's export uses `<Default Extension="..."/>` defaults plus a single
`<Override>` for `presentation.xml`. python-pptx writes one `<Override>`
per part. Both are valid OOXML and PowerPoint accepts them
interchangeably; no fidelity loss. Documenting here so it's not raised
as a "diff" in future runs of the harness.
