"""Run every test under both SDKs and write a markdown gap report.

Usage::

    cd pptx-studio/python-sdk/parity-tests
    python runner.py
    # writes outputs/<test>/{real,athena}.{pptx,json} + outputs/REPORT.md

Pre-reqs::

    # Lowe's template (default input)
    /Users/brendongeils/Downloads/lowes_template_v1.pptx

    # API credentials for athena-python-pptx tests
    export ATHENA_PPTX_API_KEY=...        # use BG_STAGING_API_KEY
    export ATHENA_PPTX_BASE_URL=https://pptx-studio.stg.athenaintel.com  # default

The two venvs in ``.gitignored_venvs/`` must already be set up — see the
README in this directory.
"""

from __future__ import annotations

import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from _harness import (  # noqa: E402
    DEFAULT_TEMPLATE,
    OUTPUTS_ROOT,
    TESTS_ROOT,
    TestReport,
    diff_pptx_archives,
    run_test,
    write_report,
)


def discover_tests() -> list[Path]:
    return sorted(p for p in TESTS_ROOT.glob("test_*.py"))


def output_extension_for_test(test_module: Path) -> str:
    """test_05_describe_shapes writes JSON; everything else writes a .pptx."""
    if "describe_shapes" in test_module.stem or "describe" in test_module.stem:
        return ".json"
    return ".pptx"


def diff_outputs(real: Path, athena: Path) -> list[str]:
    if real.suffix == ".pptx" and athena.suffix == ".pptx":
        return diff_pptx_archives(real, athena)
    # JSON / text diff — just byte-compare and dump deltas inline
    if not real.exists() or not athena.exists():
        return [
            f"FATAL: missing — real={real.exists()} athena={athena.exists()}",
        ]
    rb = real.read_text().splitlines()
    ab = athena.read_text().splitlines()
    if rb == ab:
        return [f"identical ({len(rb)} lines)"]
    import difflib

    diff = list(difflib.unified_diff(rb, ab, fromfile="real", tofile="athena", n=2))
    summary = [f"line counts: real={len(rb)} athena={len(ab)}"]
    summary.append("unified diff (first 80 lines):")
    summary.extend(diff[:80])
    return summary


def main() -> int:
    if not DEFAULT_TEMPLATE.exists():
        print(f"missing input deck: {DEFAULT_TEMPLATE}", file=sys.stderr)
        return 2
    if not os.environ.get("ATHENA_PPTX_API_KEY"):
        print(
            "ATHENA_PPTX_API_KEY is required (export BG_STAGING_API_KEY first)",
            file=sys.stderr,
        )
        return 2

    OUTPUTS_ROOT.mkdir(exist_ok=True)
    reports: list[TestReport] = []

    only = set(sys.argv[1:])  # optional: restrict to a subset

    for test in discover_tests():
        if only and test.stem not in only and test.name not in only:
            continue
        ext = output_extension_for_test(test)
        out_dir = OUTPUTS_ROOT / test.stem
        out_dir.mkdir(parents=True, exist_ok=True)
        real_out = out_dir / f"real{ext}"
        athena_out = out_dir / f"athena{ext}"

        print(f"\n=== {test.stem} ===")
        real_run = run_test(
            test_module=test, sdk="real", input_path=DEFAULT_TEMPLATE, output_path=real_out
        )
        print(
            f"  real: rc={real_run.returncode} ok={real_run.ok}",
            f"({real_run.stderr.strip().splitlines()[-1] if real_run.stderr.strip() else ''})",
        )

        athena_run = run_test(
            test_module=test,
            sdk="athena",
            input_path=DEFAULT_TEMPLATE,
            output_path=athena_out,
        )
        print(
            f"  athena: rc={athena_run.returncode} ok={athena_run.ok}",
            f"({athena_run.stderr.strip().splitlines()[-1] if athena_run.stderr.strip() else ''})",
        )

        diff = diff_outputs(real_out, athena_out)
        reports.append(
            TestReport(name=test.stem, real=real_run, athena=athena_run, diff_summary=diff)
        )
        for line in diff[:6]:
            print(f"    diff: {line}")

    report_path = OUTPUTS_ROOT / "REPORT.md"
    write_report(reports, report_path)
    print(f"\nwrote {report_path}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
