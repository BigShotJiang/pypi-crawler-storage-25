# athena-python-pptx SDK — Claude Instructions

## API Parity Rule (MANDATORY)

**This SDK MUST be a 100% exact replica of the standard [python-pptx](https://python-pptx.readthedocs.io/) API.**

Every class, method, property, and parameter name must match python-pptx exactly. The goal is that any code written for python-pptx works identically with this SDK — no surprises, no differences.

### What this means in practice

- **Do NOT add new methods** that don't exist in python-pptx (e.g., `fill.set_color()`, `line.no_fill()`, `fill.solid_fill()`)
- **Do NOT add new properties** that don't exist in python-pptx (e.g., `fill.color_hex`, `line.color_hex`, `line.width_pt`)
- **Do NOT rename parameters** — use the exact same parameter names as python-pptx (e.g., `autoshape_type_id`, not `autoshape_type`)
- **Do NOT change method signatures** — if python-pptx's `fill.solid()` takes no arguments, ours must also take no arguments
- **Do NOT change return types** — if python-pptx's `font.color` returns a `ColorFormat`, ours must too (never `None`)

### How to verify parity

Before adding or modifying any API surface:

1. Check the [python-pptx documentation](https://python-pptx.readthedocs.io/)
2. Check the [python-pptx source code](https://github.com/scanny/python-pptx)
3. Confirm the method/property/parameter exists with the same name and signature
4. If it doesn't exist in python-pptx, **do not add it** without explicit user approval

### Current status (v0.1.60)

**Core classes are at 1:1 parity** with python-pptx: FillFormat, LineFormat, RGBColor, ColorFormat, Font. All legacy convenience methods on these classes have been removed.

**Module path shims** mirror stock python-pptx layout: `pptx.slide`, `pptx.table`, `pptx.action`. User code written for python-pptx (`from pptx.table import _Cell`, `from pptx.slide import Slide`) imports unchanged.

**Structural classes** (Presentation, Slide, Slides, SlideLayout, SlideMaster, SlideShapes, Table, `_Cell`) are parity-tested with deviations documented:
- Stock-only members like `element` / `part` are intentionally absent (REST SDK has no XML/OPC parts).
- SDK-specific extras (e.g., `Table.add_row()`, `Slide.title_text`, `Presentation.from_url()`) are listed in the test allowlist.

**TextFrame, Paragraph, and Run** still have non-standard convenience extras (e.g., `to_dict()`, `word_count`, `capitalize()`, string helpers). These are candidates for removal in a future cleanup pass.

Run `python -m pytest tests/test_python_pptx_api_parity.py -v -s` to verify parity across 17 classes.

### Intentionally omitted (REST SDK limitations)

These standard python-pptx members don't apply to a REST SDK:
- `Shape.element`, `Shape.part` — XML element access (no local XML)
- `TextFrame.part`, `Paragraph.part`, `Run.part` — package part access
- `FillFormat.from_fill_parent()`, `ColorFormat.from_colorchoice_parent()` — internal constructors
- `Font.fill` — font fill format (not supported)
- `Font.language_id` — not yet implemented

### If you need a deviation

If there is a genuine technical reason why a deviation from python-pptx is necessary (e.g., the SDK is a REST client and cannot replicate XML-level behavior):

1. **Stop and ask the user** before implementing
2. Explain what the deviation is and why it's needed
3. Get explicit confirmation that the deviation is acceptable
4. Document the deviation in the table above

**Do NOT silently add convenience methods, aliases, or "improved" APIs.** The value of this SDK is that it's a drop-in replacement — any divergence breaks that contract.

## Development

```bash
# Install in editable mode
pip install -e ".[dev]"

# Run tests
python -m pytest tests/ -x -q

# Run specific test file
python -m pytest tests/test_sdk_features.py -x -q
```

## Architecture

This is a **REST API client** that mimics the python-pptx API. Instead of manipulating XML directly, method calls are translated to commands sent to the PPTX Studio API server. Key differences from python-pptx internals:

- No `_element`, `_sp`, `_spTree` XML attributes — these don't exist
- Operations are batched via `with prs.batch():` context manager
- State is synchronized via the PPTX Studio collaboration layer (Yjs)
