"""Category sequence classes for python-pptx compatibility."""

from __future__ import annotations

from collections.abc import Iterable
from typing import Any


class Category(str):
    """Single chart category label."""


class Categories(tuple[Category, ...]):
    """Read-only chart category label sequence."""

    def __new__(cls, values: Iterable[Any] = ()) -> "Categories":
        return super().__new__(cls, (Category(str(value)) for value in values))
