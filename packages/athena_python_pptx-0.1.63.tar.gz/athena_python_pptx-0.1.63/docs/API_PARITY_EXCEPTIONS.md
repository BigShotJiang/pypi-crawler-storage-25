# athena-python-pptx API Parity Exceptions

This document lists all intentional deviations from the standard [python-pptx](https://python-pptx.readthedocs.io/) API in the athena-python-pptx SDK.

The SDK's goal is 1:1 API parity with python-pptx. These exceptions exist because the SDK is a REST client (no local XML), or because LLM agents need ergonomic aliases for common patterns.

---

## REST SDK Limitations (python-pptx members that don't apply)

These standard python-pptx members are omitted because a REST SDK has no access to the underlying XML or package structure:

| Member | Reason |
|--------|--------|
| `Shape.element`, `Shape.part` | XML element access (no local XML) |
| `TextFrame.part`, `Paragraph.part`, `Run.part` | Package part access |
| `FillFormat.from_fill_parent()` | Internal constructor |
| `ColorFormat.from_colorchoice_parent()` | Internal constructor |
| `Font.fill` | Font fill format (not supported) |
| `Font.language_id` | Not yet implemented |

---

## Agent-Friendly Additions (not in python-pptx)

These properties/methods were added because LLM agents (Claude, GPT, etc.) frequently generate code using these patterns. Without them, agent-generated table code fails at runtime.

### `TableCell` — RGB tuple aliases

| Property | Type | Maps to | Why |
|----------|------|---------|-----|
| `cell.font_bold` | `bool` | `cell.bold` | Agents write `cell.font_bold = True` instead of `cell.bold = True` |
| `cell.font_color_rgb` | `tuple(R,G,B)` | `cell.font_color_hex` | Agents write `cell.font_color_rgb = (255, 255, 255)` instead of `cell.font_color_hex = "FFFFFF"` |
| `cell.fill_color_rgb` | `tuple(R,G,B)` | `cell.fill` (hex) | Agents write `cell.fill_color_rgb = (31, 57, 100)` instead of `cell.fill = "1F3964"` |

**Example of the agent pattern these support:**

```python
# LLM agents commonly generate this pattern:
cell = tbl.cell(0, 0)
cell.text = "Header"
cell.font_size_pt = 14
cell.font_bold = True
cell.font_color_rgb = (255, 255, 255)
cell.fill_color_rgb = (31, 57, 100)
```

### `GraphicFrame` — Table passthrough methods

In python-pptx, `add_table()` returns a `GraphicFrame` and the table is accessed via `.table`. However, agents frequently call `.cell()`, `.rows`, `.cols` directly on the return value. These passthroughs prevent `AttributeError`:

| Member | Delegates to |
|--------|-------------|
| `graphic_frame.cell(row, col)` | `graphic_frame.table.cell(row, col)` |
| `graphic_frame.rows` | `graphic_frame.table.rows` |
| `graphic_frame.cols` | `graphic_frame.table.cols` |

**Example:**

```python
# Both patterns work:
tbl = slide.shapes.add_table(rows=3, cols=3, ...)

# Pattern 1: python-pptx canonical
tbl.table.cell(0, 0).text = "Header"

# Pattern 2: agent shortcut (also works)
tbl.cell(0, 0).text = "Header"
```

---

## Structural Deviations (python-pptx behavior differs)

### `Table.first_row` / `Table.last_row` — Boolean look flags, not cell lists

In python-pptx, `Table.first_row` and `Table.last_row` are boolean properties controlling table style look flags (whether the first/last row gets special styling).

In a prior version of this SDK, these were cell-list properties returning `list[TableCell]`. They have been changed to match python-pptx (boolean). The old cell-list accessors are available as methods:

| Old (removed) | New (python-pptx parity) | Cell-list replacement |
|---------------|-------------------------|----------------------|
| `table.first_row` → `list[TableCell]` | `table.first_row` → `bool` | `table.get_first_row_cells()` |
| `table.last_row` → `list[TableCell]` | `table.last_row` → `bool` | `table.get_last_row_cells()` |
| `table.first_column` → `list[TableCell]` | (not a python-pptx property) | `table.get_first_column_cells()` |
| `table.last_column` → `list[TableCell]` | (not a python-pptx property) | `table.get_last_column_cells()` |

### `Shapes.add_table()` — Returns `GraphicFrame`, not `Table`

Changed to match python-pptx semantics. `add_table()` returns a `GraphicFrame`. Access the `Table` via `.table`. The passthrough methods above ensure backward compatibility for code that calls `.cell()` directly.

### `_Row` / `_Column` with height/width setters

python-pptx's `_Row.height` and `_Column.width` are read/write EMU properties. This SDK matches that API, but setting them also emits SDK commands (`SetRowHeight`, `SetColWidth`) to the server.

### `Table.rows` / `Table.columns` — Return `_RowCollection` / `_ColumnCollection`

In python-pptx, `Table.rows` returns a `_RowCollection` of `_Row` objects (each with `.height`). This SDK matches that. In a prior version, `Table.rows` returned a flat collection of cell lists.

---

## Non-Standard Convenience Methods (candidates for future cleanup)

These exist on `TextFrame`, `Paragraph`, `Run`, `TableCell`, and `Table` but are NOT in python-pptx:

- `to_dict()`, `word_count`, `capitalize()`, `upper()`, `lower()`, `title()`, `strip()`, `is_empty`
- `Table.to_csv()`, `Table.to_list()`, `Table.to_dict_list()`, `Table.all_text`, `Table.contains_text()`, `Table.find_cells()`
- `TableCell.address` (A1 notation), `TableCell.copy_from()`, `TableCell.clear()`

These are convenience methods for agents and don't conflict with python-pptx API (python-pptx doesn't have them, so there's no behavioral difference).
