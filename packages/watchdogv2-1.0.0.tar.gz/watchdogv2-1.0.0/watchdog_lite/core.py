"""
watchdog_lite.core
------------------
Watchdog — main class for tracking, detecting anomalies, and alerting.
"""

import contextlib
import functools
import json
import math
import sqlite3
import threading
import time
from dataclasses import dataclass
from datetime import datetime
from enum import Enum
from typing import Any, Callable, Dict, List, Optional

from .metrics import MetricWindow


class AlertLevel(str, Enum):
    INFO    = "info"
    WARNING = "warning"
    CRITICAL = "critical"


@dataclass
class Alert:
    """Represents a triggered alert."""
    metric: str
    level: AlertLevel
    value: float
    threshold: float
    method: str           # "zscore" | "percentile" | "rate_of_change" | "error_rate"
    message: str
    triggered_at: str

    def __str__(self):
        return (
            f"[{self.level.upper()}] {self.metric}: {self.message} "
            f"(value={self.value:.4f}, threshold={self.threshold:.4f})"
        )


class Watchdog:
    """
    Ultra-lightweight metrics tracker and anomaly detector.

    Parameters
    ----------
    window_size : int
        Rolling window size for statistical computations. Default: 100.
    db_path : str, optional
        If provided, metrics and alerts are flushed to SQLite for persistence.
    flush_interval : float
        Seconds between SQLite flushes (if db_path set). Default: 30.0.

    Example
    -------
    >>> wd = Watchdog(db_path="metrics.db")
    >>>
    >>> @wd.track("payment_api", latency_threshold=2.0, error_rate_threshold=0.05)
    ... def call_payment_api(amount):
    ...     return stripe.charge(amount)
    >>>
    >>> @wd.on_alert
    ... def alert_handler(alert):
    ...     slack.send(str(alert))
    >>>
    >>> wd.record("queue_depth", 42)
    >>> wd.detect("queue_depth", method="zscore", threshold=3.0)
    >>> wd.print_stats()
    """

    def __init__(
        self,
        window_size: int = 100,
        db_path: Optional[str] = None,
        flush_interval: float = 30.0,
    ):
        self._window_size = window_size
        self._metrics: Dict[str, MetricWindow] = {}
        self._alert_rules: Dict[str, List[dict]] = {}
        self._alert_callbacks: List[Callable[[Alert], None]] = []
        self._lock = threading.Lock()
        self._alerts: List[Alert] = []

        # SQLite persistence
        self._db: Optional[sqlite3.Connection] = None
        self._flush_interval = flush_interval
        self._flush_thread: Optional[threading.Thread] = None
        if db_path:
            self._db = self._init_db(db_path)
            self._start_flush_thread()

    # ── DB ────────────────────────────────────────────────────────────────────

    def _init_db(self, db_path: str) -> sqlite3.Connection:
        conn = sqlite3.connect(db_path, check_same_thread=False)
        conn.executescript("""
            CREATE TABLE IF NOT EXISTS metric_snapshots (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                metric      TEXT NOT NULL,
                mean        REAL,
                p50         REAL,
                p95         REAL,
                p99         REAL,
                error_rate  REAL,
                count       INTEGER,
                snapped_at  TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS alerts (
                id           INTEGER PRIMARY KEY AUTOINCREMENT,
                metric       TEXT NOT NULL,
                level        TEXT NOT NULL,
                value        REAL,
                threshold    REAL,
                method       TEXT,
                message      TEXT,
                triggered_at TEXT NOT NULL
            );

            CREATE INDEX IF NOT EXISTS idx_snapshots_metric ON metric_snapshots(metric);
            CREATE INDEX IF NOT EXISTS idx_alerts_metric ON alerts(metric);
        """)
        conn.commit()
        return conn

    def _start_flush_thread(self):
        def _loop():
            while True:
                time.sleep(self._flush_interval)
                self._flush_to_db()

        self._flush_thread = threading.Thread(
            target=_loop, daemon=True, name="watchdog-flush"
        )
        self._flush_thread.start()

    def _flush_to_db(self):
        if not self._db:
            return
        now = datetime.now().isoformat()
        with self._lock:
            metrics = list(self._metrics.items())
        for name, window in metrics:
            s = window.summary()
            self._db.execute("""
                INSERT INTO metric_snapshots
                (metric, mean, p50, p95, p99, error_rate, count, snapped_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """, (name, s["mean"], s["p50"], s["p95"], s["p99"],
                  s["error_rate"], s["count"], now))
        self._db.commit()

    def _persist_alert(self, alert: Alert):
        if not self._db:
            return
        self._db.execute("""
            INSERT INTO alerts (metric, level, value, threshold, method, message, triggered_at)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """, (alert.metric, alert.level.value, alert.value, alert.threshold,
              alert.method, alert.message, alert.triggered_at))
        self._db.commit()

    # ── Metric window management ──────────────────────────────────────────────

    def _get_or_create(self, name: str) -> MetricWindow:
        with self._lock:
            if name not in self._metrics:
                self._metrics[name] = MetricWindow(name, self._window_size)
            return self._metrics[name]

    # ── Recording ─────────────────────────────────────────────────────────────

    def record(self, metric: str, value: float, is_error: bool = False):
        """
        Record a metric value.

        Parameters
        ----------
        metric : str
            Metric name (e.g. "latency", "queue_depth").
        value : float
            The value to record.
        is_error : bool
            Whether this call represents an error (for error_rate tracking).
        """
        window = self._get_or_create(metric)
        window.record(value, is_error=is_error)
        self._check_rules(metric, value, window)

    # ── Tracking decorator ────────────────────────────────────────────────────

    def track(
        self,
        name: Optional[str] = None,
        latency_threshold: Optional[float] = None,
        error_rate_threshold: Optional[float] = None,
        zscore_threshold: float = 3.0,
        percentile: int = 95,
        method: str = "both",
    ) -> Callable:
        """
        Decorator that automatically tracks latency and errors for a function.

        Parameters
        ----------
        name : str, optional
            Metric name. Defaults to function name.
        latency_threshold : float, optional
            Alert if p95 latency exceeds this (seconds).
        error_rate_threshold : float, optional
            Alert if error rate exceeds this (0.0-1.0).
        zscore_threshold : float
            Z-score threshold for anomaly detection. Default: 3.0.
        percentile : int
            Percentile for threshold comparison. Default: 95.
        method : str
            Detection method: "zscore", "percentile", or "both".
        """
        def decorator(func: Callable) -> Callable:
            metric_name = name or func.__name__

            # Register alert rules
            if latency_threshold:
                self.add_rule(metric_name, method="percentile",
                              threshold=latency_threshold, percentile=percentile,
                              level=AlertLevel.WARNING)
                if method in ("zscore", "both"):
                    self.add_rule(metric_name, method="zscore",
                                  threshold=zscore_threshold, level=AlertLevel.WARNING)

            if error_rate_threshold:
                self.add_rule(f"{metric_name}.errors", method="error_rate",
                              threshold=error_rate_threshold, level=AlertLevel.CRITICAL)

            @functools.wraps(func)
            def wrapper(*args, **kwargs):
                start = time.monotonic()
                is_error = False
                try:
                    result = func(*args, **kwargs)
                    return result
                except Exception as e:
                    is_error = True
                    raise
                finally:
                    elapsed = time.monotonic() - start
                    self.record(metric_name, elapsed, is_error=is_error)
                    if error_rate_threshold:
                        window = self._get_or_create(f"{metric_name}.errors")
                        window.record(1.0 if is_error else 0.0, is_error=is_error)
                        self._check_rules(f"{metric_name}.errors", is_error, window)

            return wrapper
        return decorator

    @contextlib.contextmanager
    def measure(self, metric: str):
        """
        Context manager to measure elapsed time of a block.

        Usage
        -----
        >>> with wd.measure("db_query"):
        ...     results = db.execute(query)
        """
        start = time.monotonic()
        is_error = False
        try:
            yield
        except Exception:
            is_error = True
            raise
        finally:
            elapsed = time.monotonic() - start
            self.record(metric, elapsed, is_error=is_error)

    # ── Alert rules ───────────────────────────────────────────────────────────

    def add_rule(
        self,
        metric: str,
        method: str,
        threshold: float,
        percentile: int = 95,
        level: AlertLevel = AlertLevel.WARNING,
    ):
        """
        Add an anomaly detection rule for a metric.

        Parameters
        ----------
        metric : str
            Metric name to monitor.
        method : str
            Detection method: "zscore", "percentile", "rate_of_change", "error_rate".
        threshold : float
            Value that triggers an alert.
        percentile : int
            Which percentile to use (for method="percentile"). Default: 95.
        level : AlertLevel
            Alert severity. Default: WARNING.
        """
        with self._lock:
            if metric not in self._alert_rules:
                self._alert_rules[metric] = []
            self._alert_rules[metric].append({
                "method": method,
                "threshold": threshold,
                "percentile": percentile,
                "level": level,
            })

    def detect(
        self,
        metric: str,
        method: str = "zscore",
        threshold: float = 3.0,
        percentile: int = 95,
        level: AlertLevel = AlertLevel.WARNING,
    ) -> Optional[Alert]:
        """
        Manually run anomaly detection on a metric right now.

        Returns an Alert if anomaly detected, else None.
        """
        window = self._get_or_create(metric)
        return self._run_detection(metric, window.values()[-1] if window.values() else 0,
                                   window, method, threshold, percentile, level)

    def _check_rules(self, metric: str, value: float, window: MetricWindow):
        with self._lock:
            rules = list(self._alert_rules.get(metric, []))
        for rule in rules:
            alert = self._run_detection(
                metric, value, window,
                rule["method"], rule["threshold"],
                rule.get("percentile", 95), rule["level"],
            )
            if alert:
                self._fire_alert(alert)

    def _run_detection(
        self,
        metric: str,
        value: float,
        window: MetricWindow,
        method: str,
        threshold: float,
        percentile: int,
        level: AlertLevel,
    ) -> Optional[Alert]:
        triggered = False
        actual = None
        message = ""

        if method == "zscore":
            z = window.zscore(value)
            if z is not None and abs(z) > threshold:
                triggered = True
                actual = z
                message = f"Z-score {z:.2f} exceeds threshold {threshold}"

        elif method == "percentile":
            pval = window.percentile(percentile)
            if pval is not None and pval > threshold:
                triggered = True
                actual = pval
                message = f"p{percentile} ({pval:.4f}) exceeds threshold {threshold}"

        elif method == "rate_of_change":
            roc = window.rate_of_change()
            if roc is not None and abs(roc) > threshold:
                triggered = True
                actual = roc
                message = f"Rate of change {roc:.1f}% exceeds threshold {threshold}%"

        elif method == "error_rate":
            er = window.error_rate()
            if er > threshold:
                triggered = True
                actual = er
                message = f"Error rate {er:.1%} exceeds threshold {threshold:.1%}"

        if triggered and actual is not None:
            return Alert(
                metric=metric,
                level=level,
                value=actual,
                threshold=threshold,
                method=method,
                message=message,
                triggered_at=datetime.now().isoformat(),
            )
        return None

    # ── Alert callbacks ───────────────────────────────────────────────────────

    def on_alert(self, func: Callable[[Alert], None]) -> Callable:
        """
        Register a callback for alerts. Can be used as a decorator.

        Example
        -------
        >>> @wd.on_alert
        ... def handle(alert):
        ...     print(f"🚨 {alert}")
        """
        self._alert_callbacks.append(func)
        return func

    def _fire_alert(self, alert: Alert):
        with self._lock:
            self._alerts.append(alert)
        self._persist_alert(alert)
        for cb in self._alert_callbacks:
            try:
                cb(alert)
            except Exception:
                pass

    # ── Introspection ─────────────────────────────────────────────────────────

    def stats(self, metric: Optional[str] = None) -> dict:
        """Return summary stats for one or all metrics."""
        with self._lock:
            if metric:
                w = self._metrics.get(metric)
                return w.summary() if w else {}
            return {name: w.summary() for name, w in self._metrics.items()}

    def alerts(self, metric: Optional[str] = None) -> List[Alert]:
        """Return all triggered alerts, optionally filtered by metric."""
        with self._lock:
            alerts = list(self._alerts)
        if metric:
            return [a for a in alerts if a.metric == metric]
        return alerts

    def history_from_db(self, metric: str, limit: int = 50) -> List[dict]:
        """Return historical snapshots from SQLite."""
        if not self._db:
            return []
        rows = self._db.execute(
            "SELECT metric, mean, p50, p95, p99, error_rate, count, snapped_at "
            "FROM metric_snapshots WHERE metric = ? ORDER BY snapped_at DESC LIMIT ?",
            (metric, limit)
        ).fetchall()
        return [
            {"metric": r[0], "mean": r[1], "p50": r[2], "p95": r[3],
             "p99": r[4], "error_rate": r[5], "count": r[6], "snapped_at": r[7]}
            for r in rows
        ]

    def export(self, path: str):
        """Export current stats snapshot to JSON."""
        with open(path, "w") as f:
            json.dump({
                "exported_at": datetime.now().isoformat(),
                "metrics": self.stats(),
                "alerts": [
                    {"metric": a.metric, "level": a.level.value,
                     "message": a.message, "triggered_at": a.triggered_at}
                    for a in self.alerts()
                ],
            }, f, indent=2, default=str)

    def flush(self):
        """Manually flush metrics to SQLite."""
        self._flush_to_db()

    def print_stats(self):
        """Print a formatted stats table to stdout."""
        with self._lock:
            metrics = dict(self._metrics)

        if not metrics:
            print("  No metrics recorded.")
            return

        print(f"\n{'Metric':<30} {'Count':>6} {'Mean':>8} {'p50':>8} {'p95':>8} {'p99':>8} {'Err%':>6}  Status")
        print("─" * 90)

        for name, window in sorted(metrics.items()):
            s = window.summary()
            mean = f"{s['mean']:.4f}" if s['mean'] is not None else "—"
            p50  = f"{s['p50']:.4f}"  if s['p50']  is not None else "—"
            p95  = f"{s['p95']:.4f}"  if s['p95']  is not None else "—"
            p99  = f"{s['p99']:.4f}"  if s['p99']  is not None else "—"
            err  = f"{s['error_rate']:.1%}" if s['error_rate'] else "0.0%"
            recent_alerts = [a for a in self._alerts if a.metric == name]
            status = "⚠️ " if recent_alerts else "✅"
            print(f"  {name:<28} {s['count']:>6} {mean:>8} {p50:>8} {p95:>8} {p99:>8} {err:>6}  {status}")

        print()
