"""
watchdog_lite.metrics
---------------------
Rolling window statistics: mean, std, percentiles, Z-score.
"""

import math
import time
from collections import deque
from dataclasses import dataclass, field
from typing import Deque, List, Optional, Tuple


@dataclass
class DataPoint:
    value: float
    timestamp: float = field(default_factory=time.monotonic)


class MetricWindow:
    """
    Thread-safe rolling window of metric values with statistical computations.

    Parameters
    ----------
    name : str
        Metric name.
    window_size : int
        Max number of data points to retain. Default: 100.
    """

    def __init__(self, name: str, window_size: int = 100):
        self.name = name
        self.window_size = window_size
        self._data: Deque[DataPoint] = deque(maxlen=window_size)
        self._total_count = 0
        self._error_count = 0

    def record(self, value: float, is_error: bool = False):
        """Add a new data point."""
        self._data.append(DataPoint(value=value))
        self._total_count += 1
        if is_error:
            self._error_count += 1

    def values(self) -> List[float]:
        return [p.value for p in self._data]

    def count(self) -> int:
        return len(self._data)

    def mean(self) -> Optional[float]:
        vals = self.values()
        if not vals:
            return None
        return sum(vals) / len(vals)

    def std(self) -> Optional[float]:
        vals = self.values()
        if len(vals) < 2:
            return None
        m = sum(vals) / len(vals)
        variance = sum((v - m) ** 2 for v in vals) / (len(vals) - 1)
        return math.sqrt(variance)

    def min(self) -> Optional[float]:
        vals = self.values()
        return min(vals) if vals else None

    def max(self) -> Optional[float]:
        vals = self.values()
        return max(vals) if vals else None

    def percentile(self, p: float) -> Optional[float]:
        """Return the p-th percentile (0-100)."""
        vals = sorted(self.values())
        if not vals:
            return None
        idx = (p / 100) * (len(vals) - 1)
        lower = int(idx)
        upper = min(lower + 1, len(vals) - 1)
        frac = idx - lower
        return vals[lower] * (1 - frac) + vals[upper] * frac

    def p50(self) -> Optional[float]:
        return self.percentile(50)

    def p95(self) -> Optional[float]:
        return self.percentile(95)

    def p99(self) -> Optional[float]:
        return self.percentile(99)

    def zscore(self, value: float) -> Optional[float]:
        """Compute Z-score of a value relative to the current window."""
        m = self.mean()
        s = self.std()
        if m is None or s is None or s == 0:
            return None
        return (value - m) / s

    def error_rate(self) -> float:
        """Return error rate (0.0 to 1.0) over total recorded calls."""
        if self._total_count == 0:
            return 0.0
        return self._error_count / self._total_count

    def rate_of_change(self, last_n: int = 5) -> Optional[float]:
        """
        Return percentage change between the last value and the mean of
        the previous `last_n` values.
        """
        vals = self.values()
        if len(vals) < last_n + 1:
            return None
        recent = vals[-1]
        baseline = sum(vals[-(last_n + 1):-1]) / last_n
        if baseline == 0:
            return None
        return (recent - baseline) / baseline * 100

    def summary(self) -> dict:
        return {
            "name": self.name,
            "count": self.count(),
            "mean": self.mean(),
            "std": self.std(),
            "min": self.min(),
            "max": self.max(),
            "p50": self.p50(),
            "p95": self.p95(),
            "p99": self.p99(),
            "error_rate": self.error_rate(),
        }
