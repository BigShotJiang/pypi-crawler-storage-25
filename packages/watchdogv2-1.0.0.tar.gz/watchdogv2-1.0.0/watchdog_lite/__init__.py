"""
watchdog-lite — Ultra-lightweight structured logging and anomaly detection.
Track metrics, detect spikes, fire alerts — no Datadog, no Grafana, zero deps.
"""

from .core import Watchdog, Alert, AlertLevel
from .metrics import MetricWindow

__all__ = ["Watchdog", "Alert", "AlertLevel", "MetricWindow"]
__version__ = "1.0.0"
__author__ = "prabhay759"
