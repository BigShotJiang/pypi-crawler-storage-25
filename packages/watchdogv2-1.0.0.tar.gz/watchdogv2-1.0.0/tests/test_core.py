"""
Tests for watchdog-lite.
Run with: pytest tests/ -v
"""

import math
import time
import tempfile
import os
import pytest

from watchdog_lite import Watchdog, Alert, AlertLevel
from watchdog_lite.metrics import MetricWindow


# ── MetricWindow ──────────────────────────────────────────────────────────────

class TestMetricWindow:
    def test_record_and_count(self):
        w = MetricWindow("test", 10)
        w.record(1.0); w.record(2.0)
        assert w.count() == 2

    def test_mean(self):
        w = MetricWindow("t", 10)
        for v in [1, 2, 3, 4, 5]:
            w.record(v)
        assert w.mean() == pytest.approx(3.0)

    def test_mean_empty(self):
        w = MetricWindow("t", 10)
        assert w.mean() is None

    def test_std(self):
        w = MetricWindow("t", 10)
        for v in [2, 4, 4, 4, 5, 5, 7, 9]:
            w.record(v)
        assert w.std() is not None
        assert w.std() > 0

    def test_std_single(self):
        w = MetricWindow("t", 10)
        w.record(5.0)
        assert w.std() is None

    def test_min_max(self):
        w = MetricWindow("t", 10)
        for v in [3, 1, 4, 1, 5, 9, 2, 6]:
            w.record(v)
        assert w.min() == 1
        assert w.max() == 9

    def test_percentile_p50(self):
        w = MetricWindow("t", 100)
        for v in range(1, 101):
            w.record(float(v))
        p50 = w.p50()
        assert p50 is not None
        assert 49 <= p50 <= 51

    def test_percentile_p95(self):
        w = MetricWindow("t", 100)
        for v in range(1, 101):
            w.record(float(v))
        p95 = w.p95()
        assert p95 is not None
        assert 93 <= p95 <= 97

    def test_zscore_normal(self):
        w = MetricWindow("t", 100)
        for _ in range(50):
            w.record(1.0)
        z = w.zscore(1.0)
        assert z is not None
        assert abs(z) < 0.1

    def test_zscore_outlier(self):
        w = MetricWindow("t", 100)
        for _ in range(50):
            w.record(1.0)
        w.record(100.0)
        z = w.zscore(100.0)
        assert z is not None
        assert z > 3

    def test_error_rate(self):
        w = MetricWindow("t", 100)
        w.record(1.0, is_error=False)
        w.record(1.0, is_error=True)
        w.record(1.0, is_error=True)
        assert w.error_rate() == pytest.approx(2/3)

    def test_error_rate_empty(self):
        w = MetricWindow("t", 100)
        assert w.error_rate() == 0.0

    def test_rate_of_change(self):
        w = MetricWindow("t", 100)
        for _ in range(10):
            w.record(1.0)
        w.record(2.0)  # 100% increase
        roc = w.rate_of_change(last_n=5)
        assert roc is not None
        assert roc > 50  # at least 50% increase

    def test_window_size_limit(self):
        w = MetricWindow("t", 5)
        for i in range(10):
            w.record(float(i))
        assert w.count() == 5
        assert w.values() == [5.0, 6.0, 7.0, 8.0, 9.0]

    def test_summary_keys(self):
        w = MetricWindow("t", 10)
        w.record(1.0)
        s = w.summary()
        for key in ["name", "count", "mean", "std", "min", "max", "p50", "p95", "p99", "error_rate"]:
            assert key in s


# ── Watchdog ──────────────────────────────────────────────────────────────────

class TestWatchdog:
    def test_record_and_stats(self):
        wd = Watchdog()
        wd.record("latency", 0.1)
        wd.record("latency", 0.2)
        s = wd.stats("latency")
        assert s["count"] == 2
        assert s["mean"] == pytest.approx(0.15)

    def test_track_decorator_records_latency(self):
        wd = Watchdog()
        @wd.track("my_func")
        def fn(): time.sleep(0.01)
        fn()
        s = wd.stats("my_func")
        assert s["count"] == 1
        assert s["mean"] > 0.005

    def test_track_decorator_records_errors(self):
        wd = Watchdog()
        @wd.track("bad_func")
        def fn(): raise ValueError("oops")
        with pytest.raises(ValueError):
            fn()
        s = wd.stats("bad_func")
        assert s["count"] == 1

    def test_measure_context_manager(self):
        wd = Watchdog()
        with wd.measure("db_query"):
            time.sleep(0.01)
        s = wd.stats("db_query")
        assert s["count"] == 1
        assert s["mean"] > 0.005

    def test_on_alert_callback_fired(self):
        wd = Watchdog()
        alerts = []
        wd.on_alert(lambda a: alerts.append(a))

        # Seed window with low values
        for _ in range(50):
            wd.record("metric", 1.0)

        wd.add_rule("metric", method="zscore", threshold=2.0)
        # Record outlier
        wd.record("metric", 1000.0)

        assert len(alerts) >= 1
        assert alerts[0].metric == "metric"

    def test_zscore_detection(self):
        wd = Watchdog()
        for _ in range(50):
            wd.record("x", 1.0)
        wd.add_rule("x", method="zscore", threshold=2.0)
        alerts = []
        wd.on_alert(lambda a: alerts.append(a))
        wd.record("x", 999.0)
        assert any(a.method == "zscore" for a in alerts)

    def test_percentile_detection(self):
        wd = Watchdog()
        alerts = []
        wd.on_alert(lambda a: alerts.append(a))
        wd.add_rule("latency", method="percentile", threshold=0.1, percentile=95)
        for _ in range(100):
            wd.record("latency", 1.0)  # all above threshold
        assert any(a.method == "percentile" for a in alerts)

    def test_error_rate_detection(self):
        wd = Watchdog()
        alerts = []
        wd.on_alert(lambda a: alerts.append(a))
        wd.add_rule("svc.errors", method="error_rate", threshold=0.1)
        for _ in range(5):
            wd.record("svc.errors", 1.0, is_error=True)
        assert any(a.method == "error_rate" for a in alerts)

    def test_alert_level(self):
        wd = Watchdog()
        alerts = []
        wd.on_alert(lambda a: alerts.append(a))
        for _ in range(50):
            wd.record("m", 1.0)
        wd.add_rule("m", method="zscore", threshold=2.0, level=AlertLevel.CRITICAL)
        wd.record("m", 9999.0)
        assert any(a.level == AlertLevel.CRITICAL for a in alerts)

    def test_all_stats(self):
        wd = Watchdog()
        wd.record("a", 1.0)
        wd.record("b", 2.0)
        s = wd.stats()
        assert "a" in s
        assert "b" in s

    def test_export_json(self, tmp_path):
        wd = Watchdog()
        wd.record("latency", 0.5)
        path = str(tmp_path / "metrics.json")
        wd.export(path)
        import json
        with open(path) as f:
            data = json.load(f)
        assert "metrics" in data
        assert "latency" in data["metrics"]

    def test_sqlite_persistence(self, tmp_path):
        db = str(tmp_path / "metrics.db")
        wd = Watchdog(db_path=db, flush_interval=0.1)
        wd.record("cpu", 0.8)
        wd.flush()
        hist = wd.history_from_db("cpu")
        assert len(hist) >= 1
        assert hist[0]["metric"] == "cpu"

    def test_alerts_list(self):
        wd = Watchdog()
        for _ in range(50):
            wd.record("x", 1.0)
        wd.add_rule("x", method="zscore", threshold=2.0)
        wd.record("x", 9999.0)
        assert len(wd.alerts()) >= 1

    def test_alerts_filtered_by_metric(self):
        wd = Watchdog()
        for _ in range(50):
            wd.record("a", 1.0)
            wd.record("b", 1.0)
        wd.add_rule("a", method="zscore", threshold=2.0)
        wd.record("a", 9999.0)
        a_alerts = wd.alerts("a")
        b_alerts = wd.alerts("b")
        assert len(a_alerts) >= 1
        assert len(b_alerts) == 0

    def test_detect_manual(self):
        wd = Watchdog()
        for _ in range(50):
            wd.record("m", 1.0)
        wd.record("m", 9999.0)
        alert = wd.detect("m", method="zscore", threshold=2.0)
        assert alert is not None
        assert alert.metric == "m"
