from __future__ import annotations

import runpy
import urllib.error
from pathlib import Path

import pandas as pd


def test_runner_scripts_are_packaged() -> None:
    import meta_analysis_streamlit.runner as runner

    runners = runner.runners_dir()
    assert (runners / "main.py").exists()
    assert (runners / "binary_outcome.py").exists()
    assert (runners / "continuous_outcome.py").exists()
    assert (runners / "tsa_analysis.py").exists()


def test_tsa_engine_defaults_to_bundled_module(monkeypatch) -> None:
    monkeypatch.delenv("TSA_ANALYSIS_PY", raising=False)

    import meta_analysis_streamlit.runners.tsa_inference as tsa_inference

    assert tsa_inference.TSA_ANALYSIS_PATH.name == "tsa_analysis.py"
    assert tsa_inference.TSA_ANALYSIS_PATH.exists()


def test_lmstudio_url_generation() -> None:
    from meta_analysis_streamlit.app import lmstudio_models_url

    assert lmstudio_models_url("http://localhost:1234/v1") == [
        "http://localhost:1234/v1/models",
        "http://localhost:1234/api/v0/models",
    ]


def test_openai_compatible_url_generation() -> None:
    from meta_analysis_streamlit.app import (
        is_local_llm_url,
        llm_generation_timeout,
        ollama_api_base,
        openai_compatible_chat_url,
        openai_compatible_models_url,
    )
    from meta_analysis_streamlit.runners.binary_outcome import chat_completions_url, models_url

    gemini_base = "https://generativelanguage.googleapis.com/v1beta/openai"
    assert openai_compatible_models_url("https://api.openai.com/v1") == "https://api.openai.com/v1/models"
    assert openai_compatible_chat_url("https://api.openai.com/v1") == "https://api.openai.com/v1/chat/completions"
    assert openai_compatible_models_url("http://localhost:11434/v1") == "http://localhost:11434/v1/models"
    assert ollama_api_base("http://localhost:11434/v1") == "http://localhost:11434"
    assert models_url(gemini_base) == f"{gemini_base}/models"
    assert chat_completions_url(gemini_base) == f"{gemini_base}/chat/completions"
    assert is_local_llm_url("http://localhost:1234/v1")
    assert is_local_llm_url("http://127.0.0.1:1234/v1")
    assert is_local_llm_url("http://192.168.1.20:1234/v1")
    assert not is_local_llm_url(gemini_base)
    assert llm_generation_timeout("http://localhost:1234/v1", 60) is None
    assert llm_generation_timeout(gemini_base, 60) == 60


def test_runner_auth_headers(monkeypatch) -> None:
    from meta_analysis_streamlit.runners.binary_outcome import llm_request_headers

    monkeypatch.setenv("META_ANALYSIS_LLM_API_KEY", "secret")
    assert llm_request_headers(include_content_type=True) == {
        "Content-Type": "application/json",
        "Authorization": "Bearer secret",
    }


def test_saved_api_key_helpers(tmp_path) -> None:
    from meta_analysis_streamlit.app import clear_provider_api_key, load_saved_secrets, save_provider_api_key

    secrets_path = tmp_path / "secrets.json"

    save_provider_api_key("OpenAI", "secret", secrets_path)
    assert load_saved_secrets(secrets_path)["OpenAI"] == "secret"

    clear_provider_api_key("OpenAI", secrets_path)
    assert "OpenAI" not in load_saved_secrets(secrets_path)


def test_cli_entrypoint_points_at_app() -> None:
    import meta_analysis_streamlit.cli as cli

    app_path = Path(cli.__file__).with_name("app.py")
    assert app_path.exists()


def test_streamlit_app_loads_as_script() -> None:
    import meta_analysis_streamlit.cli as cli

    app_path = Path(cli.__file__).with_name("app.py")
    namespace = runpy.run_path(str(app_path))

    assert "main" in namespace


def test_r_installer_command_generation() -> None:
    from meta_analysis_streamlit.install_r import r_package_expression

    expression = r_package_expression(["meta", "metafor"])

    assert '"meta"' in expression
    assert '"metafor"' in expression
    assert "https://cloud.r-project.org" in expression


def test_missing_r_packages_uses_line_delimited_output(monkeypatch) -> None:
    import subprocess
    import meta_analysis_streamlit.install_r as install_r

    captured = {}

    def fake_run(command, **_kwargs):
        captured["command"] = command
        return subprocess.CompletedProcess(command, 0, stdout="meta\n", stderr="")

    monkeypatch.setattr(install_r.subprocess, "run", fake_run)
    monkeypatch.setattr(install_r, "rscript_version", lambda _path: (4, 4, 3))

    assert install_r.missing_r_packages(["meta"], rscript="Rscript") == ["meta"]
    assert "collapse = '\\n'" in captured["command"][2]


def test_rscript_path_helpers() -> None:
    from meta_analysis_streamlit.r_runtime import parse_r_version, path_export_command, path_with_rscript

    assert path_export_command("/opt/homebrew/bin/Rscript") == 'export PATH="/opt/homebrew/bin:$PATH"'
    assert path_with_rscript("/usr/bin", "/opt/homebrew/bin/Rscript") == "/opt/homebrew/bin:/usr/bin"
    assert path_with_rscript("/opt/homebrew/bin:/usr/bin", "/opt/homebrew/bin/Rscript") == "/opt/homebrew/bin:/usr/bin"
    assert parse_r_version("R scripting front-end version 4.3.2 (2023-10-31)") == (4, 3, 2)


def test_find_rscript_prefers_supported_r_over_old_path(monkeypatch, tmp_path) -> None:
    import meta_analysis_streamlit.r_runtime as r_runtime

    old_r = tmp_path / "R-3.6.1" / "bin" / "Rscript.exe"
    new_r = tmp_path / "R-4.4.3" / "bin" / "Rscript.exe"
    old_r.parent.mkdir(parents=True)
    new_r.parent.mkdir(parents=True)
    old_r.touch()
    new_r.touch()

    monkeypatch.setattr(r_runtime.shutil, "which", lambda command: str(old_r) if command == "Rscript" else None)
    monkeypatch.setattr(r_runtime, "candidate_rscript_paths", lambda: [old_r, new_r])
    monkeypatch.setattr(
        r_runtime,
        "rscript_version",
        lambda path: (4, 4, 3) if str(path) == str(new_r) else (3, 6, 1),
    )

    selected, on_path = r_runtime.find_rscript()

    assert selected == str(new_r)
    assert on_path is False


def test_missing_r_packages_rejects_old_r(monkeypatch) -> None:
    import pytest
    import meta_analysis_streamlit.install_r as install_r

    monkeypatch.setattr(install_r, "rscript_version", lambda _path: (3, 6, 1))

    with pytest.raises(RuntimeError, match="too old"):
        install_r.missing_r_packages(["meta"], rscript="Rscript")


def test_r_installer_uses_discovered_rscript(monkeypatch) -> None:
    import meta_analysis_streamlit.install_r as install_r

    monkeypatch.setattr(install_r, "find_rscript", lambda: ("/custom/R/bin/Rscript", False))
    commands, _ = install_r.planned_commands(skip_system_r=True)

    assert commands[0][0] == "/custom/R/bin/Rscript"


def test_r_installer_prefers_conda_when_r_missing(monkeypatch) -> None:
    import meta_analysis_streamlit.install_r as install_r

    monkeypatch.setattr(install_r, "find_rscript", lambda: (None, False))
    monkeypatch.setattr(install_r.shutil, "which", lambda command: "/opt/anaconda3/bin/conda" if command == "conda" else None)
    monkeypatch.setenv("CONDA_PREFIX", "/opt/anaconda3")

    commands, _ = install_r.system_r_commands()

    assert commands == [["/opt/anaconda3/bin/conda", "install", "-y", "-c", "conda-forge", "r-base"]]


def test_binary_route_uses_specialized_single_sheet_runner(tmp_path) -> None:
    from meta_analysis_streamlit.app import build_command

    command = build_command(
        input_path=tmp_path / "workbook.xlsx",
        output_root=tmp_path / "outputs",
        route="Binary pairwise",
        selected_sheets=["Outcome A"],
        outcome_name="Outcome A",
        lmstudio_enabled=False,
        lmstudio_url="http://localhost:1234/v1",
        model_id="",
        binary_effect_size="RR",
        network_engine="frequentist",
        network_effect="auto",
        network_model="random",
        single_arm_type="auto",
        diagnostic_mode="single",
        jobs=1,
        dry_run=False,
        install_r_packages=False,
    )

    assert any(part.endswith("binary_outcome.py") for part in command)
    assert "--sheet" in command
    assert "Outcome A" in command
    assert "--sheets" not in command
    assert "--no-lmstudio" in command


def test_binary_route_can_install_r_packages(tmp_path) -> None:
    from meta_analysis_streamlit.app import build_command

    command = build_command(
        input_path=tmp_path / "workbook.xlsx",
        output_root=tmp_path / "outputs",
        route="Binary pairwise",
        selected_sheets=["Outcome A"],
        outcome_name="Outcome A",
        lmstudio_enabled=False,
        lmstudio_url="http://localhost:1234/v1",
        model_id="",
        binary_effect_size="RR",
        network_engine="frequentist",
        network_effect="auto",
        network_model="random",
        single_arm_type="auto",
        diagnostic_mode="single",
        jobs=1,
        dry_run=False,
        install_r_packages=True,
    )

    assert "--install-r-packages" in command


def test_auto_route_can_select_all_sheets(tmp_path) -> None:
    from meta_analysis_streamlit.app import build_command

    command = build_command(
        input_path=tmp_path / "workbook.xlsx",
        output_root=tmp_path / "outputs",
        route="Auto route workbook",
        selected_sheets=["Outcome A", "Outcome B"],
        outcome_name="",
        lmstudio_enabled=False,
        lmstudio_url="http://localhost:1234/v1",
        model_id="",
        binary_effect_size="auto",
        network_engine="frequentist",
        network_effect="auto",
        network_model="random",
        single_arm_type="auto",
        diagnostic_mode="single",
        jobs=1,
        dry_run=False,
        install_r_packages=False,
        analyze_all_sheets=True,
    )

    assert any(part.endswith("main.py") for part in command)
    assert "--all-sheets" in command
    assert "--sheets" not in command


def test_auto_group_suggestions_skip_study_identifier() -> None:
    from meta_analysis_streamlit.app import auto_group_columns

    df = pd.DataFrame(
        {
            "Study": ["A", "B", "C", "D"],
            "Etiology": ["Malignant", "Benign", "Malignant", "Benign"],
            "Events": [1, 2, 3, 4],
        }
    )

    assert auto_group_columns(df, list(df.columns)) == ["Etiology"]


def test_route_helpers_normalize_llm_and_column_routes() -> None:
    from meta_analysis_streamlit.app import (
        heuristic_route_from_columns,
        normalize_route,
        recommended_ollama_model,
        route_count_summary,
        runtime_estimate_label,
        version_tuple,
    )

    assert normalize_route("binary_pairwise") == "Binary pairwise"
    assert heuristic_route_from_columns(["Study", "event.e", "n.e", "event.c", "n.c"]) == "Binary pairwise"
    assert heuristic_route_from_columns(["Study", "mean.e", "sd.e", "n.e", "mean.c", "sd.c"]) == "Continuous pairwise"
    assert recommended_ollama_model(8, "CPU only") == "llama3.2:3b"
    assert recommended_ollama_model(16, "NVIDIA GPU") == "llama3.1:8b"
    assert recommended_ollama_model(64, "Apple Silicon GPU") == "qwen3:14b"
    assert version_tuple("0.1.10") > version_tuple("0.1.9")
    assert "Binary pairwise: 2" in route_count_summary({"A": "Binary pairwise", "B": "Binary pairwise"})
    assert runtime_estimate_label(3, "Auto route workbook", jobs=2, use_llm=True) != "No sheets selected"


def test_llm_route_payload_compacts_all_sheet_assessment() -> None:
    from meta_analysis_streamlit.app import workbook_assessment_payload

    overview = {
        f"Outcome {index}": {
            "rows": 10,
            "columns": ["Study", "event.e", "n.e", "event.c", "n.c"],
            "preview": pd.DataFrame(
                {
                    "Study": ["A", "B", "C"],
                    "event.e": [1, 2, 3],
                    "n.e": [10, 20, 30],
                    "event.c": [2, 3, 4],
                    "n.c": [11, 21, 31],
                }
            ),
        }
        for index in range(12)
    }

    payload = workbook_assessment_payload(overview, list(overview))

    assert payload["selected_sheet_count"] == 12
    assert payload["included_sheet_count"] == 12
    assert payload["sheets"][0]["heuristic_route"] == "Binary pairwise"
    assert "sample_rows" in payload["sheets"][0]
    assert "sample_rows" not in payload["sheets"][-1]


def test_hosted_llm_does_not_auto_assess_multiple_sheets() -> None:
    from meta_analysis_streamlit.app import hosted_multi_sheet_route_reason, should_auto_assess_routes_with_llm

    assert should_auto_assess_routes_with_llm("Gemini", ["A"], True, "gemini-model")
    assert not should_auto_assess_routes_with_llm("Gemini", ["A", "B"], True, "gemini-model")
    assert not should_auto_assess_routes_with_llm("OpenAI", ["A", "B"], True, "gpt-model")
    assert should_auto_assess_routes_with_llm("LM Studio", ["A", "B"], True, "local-model")
    assert should_auto_assess_routes_with_llm("Ollama", ["A", "B"], True, "local-model")
    assert "Gemini API rate limits" in hosted_multi_sheet_route_reason("Gemini")


def test_sheet_route_display_uses_active_assessment_when_available() -> None:
    from meta_analysis_streamlit.app import sheet_routes_for_display

    overview = {
        "Outcome A": {"rows": 5, "columns": ["Study", "mean.e", "sd.e", "n.e"], "preview": pd.DataFrame()},
        "Outcome B": {"rows": 5, "columns": ["Study", "event.e", "n.e"], "preview": pd.DataFrame()},
    }

    routes, source = sheet_routes_for_display(
        overview,
        ["Outcome A", "Outcome B"],
        {"source": "LLM", "sheet_routes": {"Outcome A": "Continuous pairwise", "Outcome B": "Binary pairwise"}},
    )

    assert source == "LLM"
    assert routes["Outcome A"] == "Continuous pairwise"
    assert routes["Outcome B"] == "Binary pairwise"


def test_friendly_llm_errors_hide_raw_429() -> None:
    from meta_analysis_streamlit.app import friendly_llm_interpretation_error, friendly_llm_route_error

    error = urllib.error.HTTPError(
        "https://api.example.test/v1/chat/completions",
        429,
        "Too Many Requests",
        {},
        None,
    )

    route_message = friendly_llm_route_error(error)
    interpretation_message = friendly_llm_interpretation_error(error)

    assert "rate-limited" in route_message
    assert "429" not in route_message
    assert "rate-limited" in interpretation_message
    assert "429" not in interpretation_message


def test_output_image_discovery_shows_all_analysis_images(tmp_path) -> None:
    from meta_analysis_streamlit.app import discover_output_images

    output = tmp_path / "outputs"
    outcome = output / "01_Outcome A"
    outcome.mkdir(parents=True)
    forest = outcome / "ForestplotOutcome A.png"
    funnel = outcome / "FunnelOutcome A.png"
    leave_one_out = outcome / "LeaveOneOutSensitivityOutcome A.png"
    baujat = outcome / "BaujatOutcome A.png"
    forest.write_bytes(b"fake")
    funnel.write_bytes(b"fake")
    leave_one_out.write_bytes(b"fake")
    baujat.write_bytes(b"fake")

    images = discover_output_images(output)

    assert [item["path"].name for item in images] == [
        "ForestplotOutcome A.png",
        "LeaveOneOutSensitivityOutcome A.png",
        "BaujatOutcome A.png",
        "FunnelOutcome A.png",
    ]
    assert {item["category"] for item in images} == {"Forest", "Leave-one-out", "Baujat", "Funnel"}


def test_vision_helpers_and_image_data_url(tmp_path) -> None:
    from PIL import Image
    from meta_analysis_streamlit.app import image_data_url, likely_vision_model, provider_from_base_url, vision_model_suggestions

    image_path = tmp_path / "plot.png"
    Image.new("RGB", (1, 1), color="white").save(image_path)

    assert likely_vision_model("gemini-2.5-flash")
    assert likely_vision_model("gpt-4o-mini")
    assert likely_vision_model("llama3.2-vision")
    assert likely_vision_model("llama-4-maverick-17b-128e-instruct")
    assert not likely_vision_model("text-embedding-3-small")
    assert provider_from_base_url("https://generativelanguage.googleapis.com/v1beta/openai") == "Gemini"
    assert "gemini-2.5-flash" in vision_model_suggestions("Gemini")
    assert image_data_url(image_path).startswith("data:image/png;base64,")


def test_probe_vision_support_sends_tiny_image(monkeypatch) -> None:
    import meta_analysis_streamlit.app as app

    captured = {}

    def fake_chat(**kwargs):
        captured.update(kwargs)
        return "VISION_OK"

    monkeypatch.setattr(app, "call_openai_compatible_chat", fake_chat)

    result = app.probe_vision_support(
        base_url="https://api.example.test/v1",
        model_id="llama-4-maverick-17b-128e-instruct",
        api_key="secret",
        auth_header="Authorization",
        auth_prefix="Bearer",
    )

    content = captured["messages"][1]["content"]
    assert "VISION_OK" in result
    assert content[1]["type"] == "image_url"
    assert content[1]["image_url"]["url"].startswith("data:image/png;base64,")


def test_interpret_selected_image_can_send_image_payload(monkeypatch, tmp_path) -> None:
    from PIL import Image
    import meta_analysis_streamlit.app as app

    image_path = tmp_path / "forest.png"
    Image.new("RGB", (1, 1), color="white").save(image_path)
    captured = {}

    def fake_chat(**kwargs):
        captured.update(kwargs)
        return "ok"

    monkeypatch.setattr(app, "call_openai_compatible_chat", fake_chat)

    result = app.interpret_selected_image(
        image={"path": image_path, "label": "Forest - Outcome", "category": "Forest", "context": ""},
        base_url="https://api.openai.com/v1",
        model_id="gpt-4o",
        api_key="secret",
        auth_header="Authorization",
        auth_prefix="Bearer",
        include_image=True,
    )

    user_content = captured["messages"][1]["content"]
    assert result == "ok"
    assert isinstance(user_content, list)
    assert user_content[1]["type"] == "image_url"
    assert user_content[1]["image_url"]["url"].startswith("data:image/png;base64,")
    assert "publication-ready Results paragraph" in user_content[0]["text"]
    assert "Return exactly one polished paragraph" in user_content[0]["text"]
    assert "For meta-regression" in user_content[0]["text"]


def test_image_context_includes_statistical_text_and_tables(tmp_path) -> None:
    from meta_analysis_streamlit.app import image_context_text

    output = tmp_path / "outputs"
    outcome = output / "01_Outcome A"
    outcome.mkdir(parents=True)
    image_path = outcome / "ForestplotOutcome A.png"
    image_path.write_bytes(b"fake")
    (outcome / "analysis-summary.txt").write_text(
        "Overall effect RR 0.72, 95% CI 0.55 to 0.95, p = 0.02\n"
        "Heterogeneity: I^2 = 41%, tau^2 = 0.08\n",
        encoding="utf-8",
    )
    pd.DataFrame(
        {
            "effect": ["RR"],
            "estimate": [0.72],
            "ci_lower": [0.55],
            "ci_upper": [0.95],
            "p_value": [0.02],
            "i2": [41],
        }
    ).to_csv(outcome / "effect-results.csv", index=False)

    context = image_context_text(image_path, output)

    assert "p = 0.02" in context
    assert "p_value" in context
    assert "I^2" in context or "i2" in context


def test_image_context_includes_metaregression_tables(tmp_path) -> None:
    from meta_analysis_streamlit.app import image_context_text

    output = tmp_path / "outputs"
    outcome = output / "01_Outcome A"
    outcome.mkdir(parents=True)
    image_path = outcome / "MetaRegressionOutcome A.png"
    image_path.write_bytes(b"fake")
    pd.DataFrame(
        {
            "moderator": ["randomized_trial_regressor"],
            "coefficient": [0.14],
            "ci_lower": [-0.03],
            "ci_upper": [0.31],
            "p_value": [0.11],
            "test_of_moderators_p": [0.11],
        }
    ).to_csv(outcome / "MetaRegressionOutcome A.csv", index=False)

    context = image_context_text(image_path, output)

    assert "randomized_trial_regressor" in context
    assert "coefficient" in context
    assert "test_of_moderators_p" in context


def test_auto_route_filters_missing_column_overrides() -> None:
    import argparse
    import sys

    runners = Path(__file__).resolve().parents[1] / "meta_analysis_streamlit" / "runners"
    sys.path.insert(0, str(runners))
    import main as main_runner

    item = main_runner.PlannedAnalysis(
        index=2,
        sheet="Clinical success",
        rows=21,
        columns=["Study", "Etiology", "Control type", "clinical_success_definition_regressor"],
        outcome_name="Clinical success",
        analysis_type="binary_pairwise",
    )
    args = argparse.Namespace(
        yes=True,
        no_lmstudio=True,
        lmstudio_url="http://localhost:1234/v1",
        model="",
        group_column="Study",
        subgroup_columns="Study,Etiology,adverse_event_definition_regressor",
        covariate_columns="clinical_success_definition_regressor,adverse_event_definition_regressor",
        network_engine="frequentist",
        rank_sims=100000,
        install_r_packages=False,
    )

    command = main_runner.runner_command(item, Path("book.xlsx"), Path("outputs"), args)

    assert command is not None
    assert "--subgroup-columns" in command
    assert command[command.index("--subgroup-columns") + 1] == "Study,Etiology"
    assert "--covariate-columns" in command
    assert command[command.index("--covariate-columns") + 1] == "clinical_success_definition_regressor"
    assert "adverse_event_definition_regressor" not in command


def test_error_log_writer(tmp_path) -> None:
    import sys

    runners = Path(__file__).resolve().parents[1] / "meta_analysis_streamlit" / "runners"
    sys.path.insert(0, str(runners))
    import main as main_runner

    log_path = main_runner.write_analysis_error_log(
        tmp_path,
        [
            {
                "sheet": "Outcome A",
                "outcome": "Outcome A",
                "analysis_type": "Binary pairwise",
                "returncode": 1,
                "output_dir": str(tmp_path / "01_Outcome A"),
                "runner_log": str(tmp_path / "01_Outcome A" / "runner-output.log"),
                "command": "python binary_outcome.py",
                "tail": "Rscript was not found",
            }
        ],
    )

    text = log_path.read_text(encoding="utf-8")
    assert "Outcome A" in text
    assert "Rscript was not found" in text
    assert (tmp_path / "analysis-errors.json").exists()
