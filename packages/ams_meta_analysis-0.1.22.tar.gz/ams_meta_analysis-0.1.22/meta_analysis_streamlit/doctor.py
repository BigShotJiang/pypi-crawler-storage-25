"""Environment checks for the installed app."""

from __future__ import annotations

import importlib.util
import shutil
import subprocess
import sys
import urllib.error
import urllib.request
from pathlib import Path

from .r_runtime import find_rscript, path_export_command


PYTHON_PACKAGES = ["streamlit", "pandas", "openpyxl", "docx", "PIL", "tqdm"]


def _check_python_package(name: str) -> tuple[str, bool, str]:
    spec = importlib.util.find_spec(name)
    if spec is None:
        return name, False, "not importable"
    return name, True, "ok"


def _check_command(command: str) -> tuple[str, bool, str]:
    if command == "Rscript":
        rscript, on_path = find_rscript()
        if not rscript:
            return command, False, "not found on PATH or common R install locations"
        if on_path:
            return command, True, rscript
        return command, True, f"{rscript} (found outside PATH; add with: {path_export_command(rscript)})"
    path = shutil.which(command)
    if not path:
        return command, False, "not found on PATH"
    return command, True, path


def _check_lmstudio(url: str) -> tuple[str, bool, str]:
    endpoint = url.rstrip("/")
    if endpoint.endswith("/v1"):
        endpoint = f"{endpoint}/models"
    else:
        endpoint = f"{endpoint}/v1/models"
    try:
        request = urllib.request.Request(endpoint, method="GET")
        with urllib.request.urlopen(request, timeout=2) as response:
            return "LM Studio", True, f"reachable at {endpoint} ({response.status})"
    except (urllib.error.URLError, TimeoutError, OSError) as exc:
        return "LM Studio", False, f"not reachable at {endpoint}: {exc}"


def run_checks(lmstudio_url: str = "http://localhost:1234/v1") -> list[tuple[str, bool, str]]:
    checks: list[tuple[str, bool, str]] = []
    checks.append(("Python", True, sys.executable))
    checks.extend(_check_python_package(package) for package in PYTHON_PACKAGES)
    checks.append(_check_command("Rscript"))
    checks.append(_check_lmstudio(lmstudio_url))
    return checks


def main(argv: list[str] | None = None) -> int:
    url = argv[0] if argv else "http://localhost:1234/v1"
    failed = False
    rscript_missing = False
    for name, ok, detail in run_checks(url):
        marker = "OK" if ok else "MISSING"
        print(f"{marker:8} {name}: {detail}")
        failed = failed or not ok
        if name == "Rscript" and not ok:
            rscript_missing = True
    if rscript_missing:
        print("\nR is an external system dependency. To install it after pip install, run:")
        print("  meta-analysis-install-r")
        print("Preview first with:")
        print("  meta-analysis-install-r --dry-run")
    return 1 if failed else 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
