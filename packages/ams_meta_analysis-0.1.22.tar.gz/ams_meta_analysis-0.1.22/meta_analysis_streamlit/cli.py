"""Console launcher for the Streamlit app."""

from __future__ import annotations

import sys
from pathlib import Path

from .r_runtime import ensure_rscript_on_path


def main(argv: list[str] | None = None) -> int:
    """Run the packaged Streamlit app."""

    ensure_rscript_on_path()

    from streamlit.web import cli as streamlit_cli

    app_path = Path(__file__).with_name("app.py")
    forwarded = list(argv if argv is not None else sys.argv[1:])
    sys.argv = ["streamlit", "run", str(app_path), *forwarded]
    return int(streamlit_cli.main() or 0)


if __name__ == "__main__":
    raise SystemExit(main())
