"""Helpers for finding and using the external Rscript runtime."""

from __future__ import annotations

import os
import re
import shutil
import subprocess
import sys
from pathlib import Path

MIN_R_VERSION = (4, 0, 0)


def candidate_rscript_paths() -> list[Path]:
    candidates = [
        Path("/opt/homebrew/bin/Rscript"),
        Path("/usr/local/bin/Rscript"),
        Path("/Library/Frameworks/R.framework/Resources/bin/Rscript"),
        Path("/usr/bin/Rscript"),
    ]
    if sys.platform == "win32":
        roots = [
            Path(os.environ.get("ProgramFiles", r"C:\Program Files")) / "R",
            Path(os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)")) / "R",
        ]
        for root in roots:
            if root.exists():
                candidates.extend(sorted(root.glob("R-*/bin/Rscript.exe"), reverse=True))
                candidates.extend(sorted(root.glob("R-*/bin/x64/Rscript.exe"), reverse=True))
    return candidates


def parse_r_version(text: str) -> tuple[int, int, int] | None:
    match = re.search(r"version\s+(\d+)\.(\d+)(?:\.(\d+))?", text, flags=re.IGNORECASE)
    if not match:
        return None
    return tuple(int(part or 0) for part in match.groups())


def format_r_version(version: tuple[int, int, int] | None) -> str:
    return ".".join(str(part) for part in version) if version else "unknown"


def rscript_version(rscript_path: str) -> tuple[int, int, int] | None:
    completed = subprocess.run(
        [rscript_path, "--version"],
        text=True,
        capture_output=True,
        check=False,
    )
    return parse_r_version(f"{completed.stdout}\n{completed.stderr}")


def rscript_is_supported(rscript_path: str) -> bool:
    version = rscript_version(rscript_path)
    return bool(version and version >= MIN_R_VERSION)


def _same_path(left: str, right: str) -> bool:
    try:
        return Path(left).resolve() == Path(right).resolve()
    except OSError:
        return os.path.normcase(left) == os.path.normcase(right)


def find_rscript() -> tuple[str | None, bool]:
    """Return (path, on_path) for Rscript.

    When multiple R installations are present, prefer one that is new enough for
    current CRAN meta-analysis packages. ``on_path`` is false when the chosen
    Rscript is not currently discoverable through PATH.
    """

    found = shutil.which("Rscript")
    candidates: list[str] = []
    if found:
        candidates.append(found)
    candidates.extend(str(candidate) for candidate in candidate_rscript_paths() if candidate.exists())
    unique_candidates: list[str] = []
    for candidate in candidates:
        if not any(_same_path(candidate, existing) for existing in unique_candidates):
            unique_candidates.append(candidate)

    scored: list[tuple[tuple[int, int, int] | None, str]] = []
    for candidate in unique_candidates:
        scored.append((rscript_version(candidate), candidate))
    if not scored:
        return None, False

    supported = [(version, candidate) for version, candidate in scored if version and version >= MIN_R_VERSION]
    choices = supported or scored
    choices.sort(key=lambda item: item[0] or (-1, -1, -1), reverse=True)
    selected = choices[0][1]
    return selected, bool(found and _same_path(selected, found))


def path_export_command(rscript_path: str) -> str:
    folder = str(Path(rscript_path).parent)
    return f'export PATH="{folder}:$PATH"'


def path_with_rscript(current_path: str, rscript_path: str | None) -> str:
    if not rscript_path:
        return current_path
    folder = str(Path(rscript_path).parent)
    entries = current_path.split(os.pathsep) if current_path else []
    if folder in entries:
        return current_path
    return os.pathsep.join([folder, *entries]) if current_path else folder


def ensure_rscript_on_path() -> tuple[str | None, bool]:
    """Find Rscript and add its folder to this process PATH when needed."""

    rscript, on_path = find_rscript()
    if rscript and not on_path:
        os.environ["PATH"] = path_with_rscript(os.environ.get("PATH", ""), rscript)
    return rscript, on_path
