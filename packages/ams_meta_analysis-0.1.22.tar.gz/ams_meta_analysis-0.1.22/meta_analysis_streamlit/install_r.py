"""Install helper for the external R runtime used by the analysis runners."""

from __future__ import annotations

import argparse
import os
import shlex
import shutil
import subprocess
import sys

from .r_runtime import MIN_R_VERSION, find_rscript, format_r_version, path_export_command, rscript_version


R_PACKAGES = [
    "meta",
    "metafor",
    "readxl",
    "dplyr",
    "ggplot2",
    "netmeta",
    "gemtc",
    "rjags",
    "RTSA",
]


def shell_join(command: list[str]) -> str:
    return shlex.join(command)


def r_package_expression(packages: list[str] | None = None) -> str:
    package_list = packages or R_PACKAGES
    quoted = ", ".join(f'"{package}"' for package in package_list)
    return f'install.packages(c({quoted}), repos = "https://cloud.r-project.org")'


def missing_r_packages(packages: list[str], rscript: str | None = None) -> list[str]:
    rscript_path = rscript or find_rscript()[0]
    if not rscript_path:
        raise RuntimeError("Rscript was not found on PATH.")
    version = rscript_version(rscript_path)
    if not version or version < MIN_R_VERSION:
        raise RuntimeError(
            "R is too old for current CRAN meta-analysis packages. "
            f"Found R {format_r_version(version)} at {rscript_path}; "
            f"install or update R to {format_r_version(MIN_R_VERSION)} or newer."
        )
    quoted = ", ".join(f'"{package}"' for package in packages)
    expression = (
        f"packages <- c({quoted}); "
        "missing <- packages[!vapply(packages, requireNamespace, logical(1), quietly = TRUE)]; "
        "cat(paste(missing, collapse = '\\n'))"
    )
    completed = subprocess.run(
        [rscript_path, "-e", expression],
        text=True,
        capture_output=True,
        check=False,
    )
    if completed.returncode != 0:
        detail = completed.stderr.strip() or completed.stdout.strip()
        raise RuntimeError(f"Could not check R package dependencies.\n{detail}")
    return [line.strip() for line in completed.stdout.splitlines() if line.strip()]


def install_r_packages(packages: list[str], rscript: str | None = None) -> None:
    if not packages:
        return
    rscript_path = rscript or find_rscript()[0]
    if not rscript_path:
        raise RuntimeError("Rscript was not found on PATH.")
    version = rscript_version(rscript_path)
    if not version or version < MIN_R_VERSION:
        raise RuntimeError(
            "R is too old for current CRAN meta-analysis packages. "
            f"Found R {format_r_version(version)} at {rscript_path}; "
            f"install or update R to {format_r_version(MIN_R_VERSION)} or newer."
        )
    env = os.environ.copy()
    env.setdefault("R_REMOTES_NO_ERRORS_FROM_WARNINGS", "true")
    subprocess.run(
        [rscript_path, "-e", r_package_expression(packages)],
        check=True,
        env=env,
    )


def ensure_r_packages(packages: list[str], install_missing: bool = False, rscript: str | None = None) -> None:
    missing = missing_r_packages(packages, rscript=rscript)
    if not missing:
        return
    if install_missing:
        print(f"Installing missing R package(s): {', '.join(missing)}")
        install_r_packages(missing, rscript=rscript)
        still_missing = missing_r_packages(packages, rscript=rscript)
        if not still_missing:
            return
        missing = still_missing
    install_hint = r_package_expression(missing)
    raise RuntimeError(
        "Missing R package(s): "
        + ", ".join(missing)
        + "\nEnable 'Install missing R packages before analysis' in the Streamlit app, "
        + "or run:\n"
        + f"  Rscript -e {shlex.quote(install_hint)}"
    )


def system_r_commands() -> tuple[list[list[str]], str | None]:
    """Return platform-specific commands to install R, plus a note if manual action is needed."""

    rscript, on_path = find_rscript()
    old_r_note = None
    if rscript:
        version = rscript_version(rscript)
        if version and version >= MIN_R_VERSION:
            if on_path:
                return [], f"Rscript {format_r_version(version)} is already available on PATH."
            return [], f"Rscript {format_r_version(version)} was found outside PATH at {rscript}. Add it with: {path_export_command(rscript)}"
        old_r_note = (
            f"Rscript was found at {rscript}, but R {format_r_version(version)} is too old. "
            f"Installing or updating to R {format_r_version(MIN_R_VERSION)} or newer."
        )

    conda_like = shutil.which("mamba") or shutil.which("conda")
    if conda_like and (os.environ.get("CONDA_PREFIX") or "conda" in sys.executable.lower()):
        return [[conda_like, "install", "-y", "-c", "conda-forge", "r-base"]], old_r_note

    if shutil.which("micromamba") and os.environ.get("CONDA_PREFIX"):
        return [["micromamba", "install", "-y", "-c", "conda-forge", "r-base"]], old_r_note

    if sys.platform == "darwin":
        if shutil.which("brew"):
            return [["brew", "install", "r"]], old_r_note
        return [], old_r_note or "R was not found and Homebrew is not installed. Install R from https://cran.r-project.org/bin/macosx/ or install Homebrew first."

    if sys.platform.startswith("linux"):
        if shutil.which("apt-get"):
            return [
                ["sudo", "apt-get", "update"],
                ["sudo", "apt-get", "install", "-y", "r-base", "r-base-dev"],
            ], old_r_note
        if shutil.which("dnf"):
            return [["sudo", "dnf", "install", "-y", "R"]], old_r_note
        if shutil.which("yum"):
            return [["sudo", "yum", "install", "-y", "R"]], old_r_note
        if shutil.which("pacman"):
            return [["sudo", "pacman", "-S", "--needed", "r"]], old_r_note
        return [], old_r_note or "R was not found and no supported Linux package manager was detected. Install R from your distribution packages or https://cran.r-project.org/."

    if sys.platform == "win32":
        if shutil.which("winget"):
            return [["winget", "install", "--id", "RProject.R", "--source", "winget"]], old_r_note
        return [], old_r_note or "R was not found. Install R for Windows from https://cran.r-project.org/bin/windows/base/ or install winget first."

    return [], f"Automatic R installation is not supported on this platform: {sys.platform}."


def planned_commands(skip_system_r: bool = False, skip_r_packages: bool = False) -> tuple[list[list[str]], list[str]]:
    commands: list[list[str]] = []
    notes: list[str] = []

    if not skip_system_r:
        system_commands, note = system_r_commands()
        commands.extend(system_commands)
        if note:
            notes.append(note)

    if not skip_r_packages:
        rscript, _ = find_rscript()
        commands.append([rscript or "Rscript", "-e", r_package_expression()])
        notes.append("The rjags package may require JAGS to be installed separately for Bayesian network meta-analysis.")

    return commands, notes


def run_command(command: list[str]) -> None:
    print(f"\n$ {shell_join(command)}")
    subprocess.run(command, check=True)


def run_setup(skip_system_r: bool = False, skip_r_packages: bool = False) -> None:
    commands, _ = planned_commands(skip_system_r=skip_system_r, skip_r_packages=True)
    env = os.environ.copy()
    env.setdefault("R_REMOTES_NO_ERRORS_FROM_WARNINGS", "true")

    for command in commands:
        print(f"\n$ {shell_join(command)}")
        subprocess.run(command, check=True, env=env)

    if skip_r_packages:
        return

    rscript, _ = find_rscript()
    if not rscript:
        raise SystemExit("R was installed or requested, but Rscript still could not be found.")
    command = [rscript, "-e", r_package_expression()]
    print(f"\n$ {shell_join(command)}")
    subprocess.run(command, check=True, env=env)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description="Install or repair the external R runtime needed by ams-meta_analysis.",
    )
    parser.add_argument("--dry-run", action="store_true", help="Print commands without running them.")
    parser.add_argument("--yes", action="store_true", help="Run without the interactive confirmation prompt.")
    parser.add_argument("--skip-system-r", action="store_true", help="Do not try to install the R runtime itself.")
    parser.add_argument("--skip-r-packages", action="store_true", help="Do not install R packages from CRAN.")
    args = parser.parse_args(argv)

    commands, notes = planned_commands(args.skip_system_r, args.skip_r_packages)
    print("ams-meta_analysis R setup")
    print("-------------------------")
    for note in notes:
        print(f"- {note}")

    if not commands:
        print("\nNo install commands are needed.")
        return 0

    print("\nPlanned commands:")
    for command in commands:
        print(f"  {shell_join(command)}")

    if args.dry_run:
        return 0

    if not args.yes:
        answer = input("\nRun these commands now? This may install system software. [y/N]: ").strip().lower()
        if answer not in {"y", "yes"}:
            print("Stopped without making changes.")
            return 1

    run_setup(skip_system_r=args.skip_system_r, skip_r_packages=args.skip_r_packages)

    print("\nR setup completed. Run `meta-analysis-doctor` to verify the environment.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
