#!/usr/bin/env python3
"""Shared Trial Sequential Analysis inference snippets.

The binary and continuous runners generate full R analysis scripts from Python.
Keeping TSA inference here prevents the main outcome runners from carrying
hundreds of lines of embedded R while preserving the same generated R behavior.
"""

from __future__ import annotations

import importlib.util
import json
import math
import os
import re
import shutil
import sys
import textwrap
from pathlib import Path
from typing import Any

import pandas as pd


_BUNDLED_TSA_ANALYSIS_PATH = Path(__file__).with_name("tsa_analysis.py")
TSA_ANALYSIS_PATH = (
    Path(os.environ["TSA_ANALYSIS_PY"])
    if os.environ.get("TSA_ANALYSIS_PY")
    else _BUNDLED_TSA_ANALYSIS_PATH
)


def _load_tsa_analysis_module() -> Any:
    if not TSA_ANALYSIS_PATH.exists():
        raise RuntimeError(
            f"Requested TSA engine was not found: {TSA_ANALYSIS_PATH}. "
            "Set TSA_ANALYSIS_PY to the tsa_analysis.py path, or reinstall ams-meta_analysis to restore the bundled TSA engine."
        )
    spec = importlib.util.spec_from_file_location("external_tsa_analysis", TSA_ANALYSIS_PATH)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Could not import TSA engine from: {TSA_ANALYSIS_PATH}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


def _finite_float(value: Any) -> float | None:
    try:
        parsed = float(value)
    except (TypeError, ValueError):
        return None
    return parsed if math.isfinite(parsed) else None


def _extract_years(studies: pd.Series) -> pd.Series:
    extracted = studies.astype(str).str.extract(r"((?:19|20)\d{2})", expand=False)
    return pd.to_numeric(extracted, errors="coerce")


def _explicit_order_column(data: pd.DataFrame) -> str | None:
    for col in data.columns:
        normalized = re.sub(r"[^a-z0-9]+", "", str(col).lower())
        if normalized in {"tsaorder", "order"}:
            return str(col)
    return None


def _prepare_tsa_ordered_data(
    data: pd.DataFrame,
    *,
    kind: str,
) -> tuple[pd.DataFrame, pd.DataFrame, str, list[str]]:
    if kind == "binary":
        rename = {"Author": "study", "event.e": "eI", "n.e": "nI", "event.c": "eC", "n.c": "nC"}
        required = ["study", "eI", "nI", "eC", "nC"]
    else:
        rename = {"Author": "study", "mean.e": "mI", "sd.e": "sdI", "n.e": "nI", "mean.c": "mC", "sd.c": "sdC", "n.c": "nC"}
        required = ["study", "mI", "sdI", "nI", "mC", "sdC", "nC"]

    missing = [source for source in rename if source not in data.columns]
    if missing:
        raise RuntimeError(f"TSA input is missing required columns: {missing}")

    rtsa_data = data.rename(columns=rename)[required].copy()
    rtsa_data["study"] = rtsa_data["study"].astype(str)
    for col in required[1:]:
        rtsa_data[col] = pd.to_numeric(rtsa_data[col], errors="coerce")
    rtsa_data["analysis_row_order"] = range(1, len(rtsa_data) + 1)
    rtsa_data["year"] = _extract_years(rtsa_data["study"])

    complete = rtsa_data[required[1:]].notna().all(axis=1)
    rtsa_data = rtsa_data.loc[complete].copy()
    if len(rtsa_data) < 2:
        raise RuntimeError("Trial sequential analysis was skipped: fewer than 2 complete studies.")

    warnings: list[str] = []
    order_source = "Chronological publication year parsed from study label; no tied or missing years detected"
    explicit_col = _explicit_order_column(data)
    if explicit_col:
        explicit_values = pd.to_numeric(data.loc[complete, explicit_col], errors="coerce")
        if explicit_values.isna().any() or explicit_values.duplicated().any():
            raise RuntimeError(
                f"Trial sequential analysis was skipped because the explicit {explicit_col} column "
                "was not a complete unique numeric study order."
            )
        rtsa_data["tsa_order_value"] = explicit_values.to_numpy()
        rtsa_data = rtsa_data.sort_values(
            ["tsa_order_value", "year", "analysis_row_order", "study"],
            na_position="last",
            kind="mergesort",
        )
        order_source = f"Explicit {explicit_col} column in the analysis data (analyst-supplied cumulative sequence)"
    else:
        finite_years = rtsa_data["year"].dropna()
        tied_years = finite_years.duplicated().any()
        missing_years = rtsa_data["year"].isna().any()
        if missing_years:
            rtsa_data = rtsa_data.sort_values(["analysis_row_order", "study"], kind="mergesort")
            order_source = (
                "Analyst-entered analysis-data row order used because chronological publication "
                "year could not be parsed for every study"
            )
            warnings.append(
                "Original TSA convention is study-sequential and usually chronological; at least one "
                "study label lacked a parseable publication year, so the cumulative sequence used "
                "the analyst-entered analysis-data row order. Add a numeric tsa_order or order column "
                "for a protocol-defined sequence."
            )
        elif tied_years:
            rtsa_data = rtsa_data.sort_values(["year", "analysis_row_order", "study"], kind="mergesort")
            order_source = (
                "Chronological publication year parsed from study label; same-year ties resolved by "
                "analyst-entered analysis-data row order"
            )
            warnings.append(
                "Original TSA convention is study-sequential and usually chronological; multiple "
                "studies shared a publication year, so same-year ties were resolved by analyst-entered "
                "analysis-data row order. Add a numeric tsa_order or order column for a protocol-defined tie-breaker."
            )
        else:
            rtsa_data = rtsa_data.sort_values(["year", "analysis_row_order", "study"], kind="mergesort")

    rtsa_data.insert(0, "tsa_sequence", range(1, len(rtsa_data) + 1))
    export_cols = ["tsa_sequence", "study", "year", "analysis_row_order", "tsa_order_value"]
    export = rtsa_data[[col for col in export_cols if col in rtsa_data.columns] + [col for col in required[1:] if col in rtsa_data.columns]].copy()
    engine_input = rtsa_data[required].copy()
    return engine_input, export, order_source, warnings


def _observed_binary_inputs(data: pd.DataFrame, summary_measure: str) -> tuple[float | None, float | None, float | None]:
    e_i = pd.to_numeric(data["eI"], errors="coerce").sum()
    n_i = pd.to_numeric(data["nI"], errors="coerce").sum()
    e_c = pd.to_numeric(data["eC"], errors="coerce").sum()
    n_c = pd.to_numeric(data["nC"], errors="coerce").sum()
    pc = e_c / n_c if n_c > 0 else None
    pt = e_i / n_i if n_i > 0 else None
    if pc is None or pt is None:
        return None, None, None
    pc = min(max(pc, 0.001), 0.999)
    pt = min(max(pt, 0.001), 0.999)
    if summary_measure == "RD":
        return pt - pc, pc, pt
    if summary_measure == "OR":
        return (pt / (1 - pt)) / (pc / (1 - pc)), pc, pt
    return pt / pc if pc > 0 else None, pc, pt


def _observed_continuous_mc(data: pd.DataFrame) -> float | None:
    m_i = pd.to_numeric(data["mI"], errors="coerce")
    sd_i = pd.to_numeric(data["sdI"], errors="coerce")
    n_i = pd.to_numeric(data["nI"], errors="coerce")
    m_c = pd.to_numeric(data["mC"], errors="coerce")
    sd_c = pd.to_numeric(data["sdC"], errors="coerce")
    n_c = pd.to_numeric(data["nC"], errors="coerce")
    effect = m_i - m_c
    variance = (sd_i ** 2 / n_i) + (sd_c ** 2 / n_c)
    weights = 1 / variance.replace(0, math.nan)
    mask = effect.notna() & weights.notna()
    if not mask.any() or weights[mask].sum() <= 0:
        return None
    pooled = (effect[mask] * weights[mask]).sum() / weights[mask].sum()
    return abs(float(pooled)) if math.isfinite(float(pooled)) else None


def _write_vector_csv(path: Path, columns: dict[str, list[Any]]) -> None:
    max_len = max((len(values) for values in columns.values()), default=0)
    padded = {
        name: values + [math.nan] * (max_len - len(values))
        for name, values in columns.items()
    }
    pd.DataFrame(padded).to_csv(path, index=False)


def _write_tsa_outputs(
    *,
    result: Any,
    tsa_dir: Path,
    outcome: str,
    kind: str,
    summary_measure: str,
    order_source: str,
    warnings: list[str],
    config: Any,
    effect_source: str,
    input_source: str,
) -> None:
    tsa_dir.mkdir(parents=True, exist_ok=True)
    result.write_json(tsa_dir / f"TSAResult{outcome}.json")
    if result.plot_path and Path(result.plot_path).exists():
        shutil.copyfile(result.plot_path, tsa_dir / "Adjusted Boundaries Print.png")

    _write_vector_csv(
        tsa_dir / f"TSAZCurveData{outcome}.csv",
        {
            "Study": list(result.study_labels),
            "CumulativeInformation": list(result.cumulative_information),
            "CumulativeZ": list(result.cumulative_z),
        },
    )
    _write_vector_csv(
        tsa_dir / f"TSABoundaries{outcome}.csv",
        {
            "UpperBoundary": list(result.upper_alpha_boundary),
            "LowerBoundary": list(result.lower_alpha_boundary),
        },
    )
    _write_vector_csv(
        tsa_dir / f"TSAFutilityBoundaries{outcome}.csv",
        {
            "UpperFutility": list(result.upper_futility_boundary),
            "LowerFutility": list(result.lower_futility_boundary),
        },
    )

    warning_text = " | ".join(warnings + list(result.notes)) if (warnings or result.notes) else "None"
    parameters = pd.DataFrame(
        {
            "Parameter": [
                "Outcome",
                "TSA engine",
                "TSA engine path",
                "Effect measure",
                "Alpha",
                "Power",
                "Fixed/common-effect design",
                "Random adjustment",
                "Futility",
                "Effect source",
                "Anticipated effect (mc passed to RTSA)",
                "Control event proportion (pC passed to RTSA)",
                "Required information size override",
                "Required information size",
                "Diversity adjusted RIS",
                "Heterogeneity adjusted RIS",
                "Study order",
                "TSA input data source",
                "TSA warning details",
                "Conclusion",
            ],
            "Value": [
                outcome,
                "External tsa_analysis.py using RTSA::RTSA(type='analysis') only; no custom TSA fallback",
                str(TSA_ANALYSIS_PATH),
                summary_measure,
                config.alpha,
                config.power,
                config.fixed,
                config.random_adj,
                config.futility,
                effect_source,
                config.mc,
                config.pC,
                config.ris_override,
                result.required_information_size,
                result.diversity_adjusted_ris,
                result.heterogeneity_adjusted_ris,
                order_source,
                input_source,
                warning_text,
                result.conclusion,
            ],
        }
    )
    parameters.to_csv(tsa_dir / f"TSAParameters{outcome}.csv", index=False)
    (tsa_dir / f"TSAParameters{outcome}.txt").write_text(parameters.to_string(index=False), encoding="utf-8")

    audit = pd.DataFrame(
        {
            "Check": [
                "Plot generated",
                "Studies",
                "Cumulative Z values",
                "Alpha boundary values",
                "Futility boundary values",
                "Crossed alpha boundary",
                "Crossed futility boundary",
                "RTSA raw result names",
                "RTSA inference status",
            ],
            "Value": [
                str((tsa_dir / "Adjusted Boundaries Print.png").exists()),
                result.studies,
                len(result.cumulative_z),
                len(result.upper_alpha_boundary),
                len(result.upper_futility_boundary),
                result.crossed_alpha,
                result.crossed_futility,
                json.dumps(result.rtsa_raw.get("rtsa_names", [])),
                "Generated by external tsa_analysis.py; failures are reported without fallback calculations",
            ],
        }
    )
    audit.to_csv(tsa_dir / f"TSAAudit{outcome}.csv", index=False)
    (tsa_dir / f"TSAAudit{outcome}.txt").write_text(audit.to_string(index=False), encoding="utf-8")

    notes = [
        "Trial sequential analysis was calculated with external tsa_analysis.py using RTSA only.",
        "No custom TSA math or fallback boundary calculations were used.",
    ]
    if warnings:
        notes.extend(warnings)
    if result.notes:
        notes.extend(result.notes)
    (tsa_dir / f"TSANotes{outcome}.txt").write_text("\n".join(notes) + "\n", encoding="utf-8")
    if result.summary_text:
        (tsa_dir / f"RTSASummary{outcome}.txt").write_text(result.summary_text, encoding="utf-8")


def run_binary_tsa_analysis(
    *,
    data: pd.DataFrame,
    output_dir: Path,
    outcome: str,
    summary_measure: str,
    pooling_method: str,
    model_type: str,
    tsa_alpha: float,
    tsa_power: float,
    tsa_adjust_for_diversity: bool,
    tsa_effect_source: str,
    tsa_anticipated_effect: float | None,
    tsa_required_information_size: float | None,
    tsa_control_event_proportion: float | None,
    tsa_intervention_event_proportion: float | None,
    subgroup_only: bool = False,
) -> None:
    tsa_dir = output_dir / f"TSA {outcome}"
    tsa_dir.mkdir(parents=True, exist_ok=True)
    if subgroup_only:
        (tsa_dir / f"TSANotes{outcome}.txt").write_text(
            "Trial sequential analysis was skipped because the analysis is subgroup-only.\n",
            encoding="utf-8",
        )
        return
    if summary_measure == "HR":
        (tsa_dir / f"TSANotes{outcome}.txt").write_text(
            "Trial sequential analysis was skipped for HR inputs because arm-level event risks are not available.\n",
            encoding="utf-8",
        )
        return
    if pooling_method == "Peto":
        (tsa_dir / f"TSANotes{outcome}.txt").write_text(
            "Trial sequential analysis was skipped because Peto pooling is not supported by the external RTSA wrapper.\n",
            encoding="utf-8",
        )
        return

    try:
        module = _load_tsa_analysis_module()
        engine_input, export, order_source, warnings = _prepare_tsa_ordered_data(data, kind="binary")
        export.to_csv(tsa_dir / f"TSAAnalysisDataset{outcome}.csv", index=False)
        observed_mc, observed_pc, observed_pt = _observed_binary_inputs(engine_input, summary_measure)
        pc = _finite_float(tsa_control_event_proportion) or observed_pc
        pt = _finite_float(tsa_intervention_event_proportion) or observed_pt
        mc = _finite_float(tsa_anticipated_effect) if tsa_effect_source == "clinically_important" else observed_mc
        if tsa_effect_source != "clinically_important" and pt is not None and pc is not None:
            if summary_measure == "RD":
                mc = pt - pc
            elif summary_measure == "OR":
                pc_clamped = min(max(pc, 0.001), 0.999)
                pt_clamped = min(max(pt, 0.001), 0.999)
                mc = (pt_clamped / (1 - pt_clamped)) / (pc_clamped / (1 - pc_clamped))
            else:
                mc = pt / pc if pc > 0 else mc
        mc = _finite_float(mc)
        pc = _finite_float(pc)
        config = module.TSAConfig(
            alpha=float(tsa_alpha),
            power=float(tsa_power),
            fixed=model_type == "common",
            weights="IV" if pooling_method == "inverse" else "MH",
            random_adj="D2" if tsa_adjust_for_diversity else "tau2",
            futility="non-binding",
            es_beta="esOF",
            mc=mc,
            pC=pc,
            ris_override=_finite_float(tsa_required_information_size),
        )
        result = module.run_binary_tsa(
            engine_input,
            outcome=summary_measure,
            output_dir=tsa_dir,
            plot_basename="RTSA_TSA",
            config=config,
        )
        _write_tsa_outputs(
            result=result,
            tsa_dir=tsa_dir,
            outcome=outcome,
            kind="binary",
            summary_measure=summary_measure,
            order_source=order_source,
            warnings=warnings,
            config=config,
            effect_source=tsa_effect_source,
            input_source="Python extracted analysis data ordered before external tsa_analysis.py",
        )
    except Exception as exc:
        (tsa_dir / f"TSANotes{outcome}.txt").write_text(
            "Trial sequential analysis failed in external tsa_analysis.py. No fallback TSA calculations were performed.\n"
            f"{exc}\n",
            encoding="utf-8",
        )


def run_continuous_tsa_analysis(
    *,
    data: pd.DataFrame,
    output_dir: Path,
    outcome: str,
    summary_measure: str,
    model_type: str,
    tsa_alpha: float,
    tsa_power: float,
    tsa_adjust_for_diversity: bool,
    tsa_effect_source: str,
    tsa_anticipated_effect: float | None,
    tsa_required_information_size: float | None,
    subgroup_only: bool = False,
) -> None:
    tsa_dir = output_dir / f"TSA {outcome}"
    tsa_dir.mkdir(parents=True, exist_ok=True)
    if subgroup_only:
        (tsa_dir / f"TSANotes{outcome}.txt").write_text(
            "Trial sequential analysis was skipped because the analysis is subgroup-only.\n",
            encoding="utf-8",
        )
        return
    if summary_measure == "SMD":
        (tsa_dir / f"TSANotes{outcome}.txt").write_text(
            "Trial sequential analysis was skipped because the external RTSA wrapper supports continuous MD TSA, not SMD.\n",
            encoding="utf-8",
        )
        return
    try:
        module = _load_tsa_analysis_module()
        engine_input, export, order_source, warnings = _prepare_tsa_ordered_data(data, kind="continuous")
        export.to_csv(tsa_dir / f"TSAAnalysisDataset{outcome}.csv", index=False)
        mc = (
            _finite_float(tsa_anticipated_effect)
            if tsa_effect_source == "clinically_important"
            else _observed_continuous_mc(engine_input)
        )
        mc = _finite_float(mc)
        config = module.TSAConfig(
            alpha=float(tsa_alpha),
            power=float(tsa_power),
            fixed=model_type == "common",
            random_adj="D2" if tsa_adjust_for_diversity else "tau2",
            futility="non-binding",
            es_beta="esOF",
            mc=mc,
            ris_override=_finite_float(tsa_required_information_size),
        )
        result = module.run_continuous_tsa(
            engine_input,
            output_dir=tsa_dir,
            plot_basename="RTSA_TSA",
            config=config,
        )
        _write_tsa_outputs(
            result=result,
            tsa_dir=tsa_dir,
            outcome=outcome,
            kind="continuous",
            summary_measure=summary_measure,
            order_source=order_source,
            warnings=warnings,
            config=config,
            effect_source=tsa_effect_source,
            input_source="Python extracted analysis data ordered before external tsa_analysis.py",
        )
    except Exception as exc:
        (tsa_dir / f"TSANotes{outcome}.txt").write_text(
            "Trial sequential analysis failed in external tsa_analysis.py. No fallback TSA calculations were performed.\n"
            f"{exc}\n",
            encoding="utf-8",
        )


_TSA_SOFTWARE_STYLE_PLOT_R = r"""
draw_tsa_software_style_plot <- function(filename, device = c("png", "tiff"),
                                         boundary_df, futility_df, adjusted_ris,
                                         cumulative_information, cumulative_z,
                                         eff_labels, tsa_alpha,
                                         tsa_favor_top, tsa_favor_bottom,
                                         plot_opts = list()) {
  device <- match.arg(device)
  if (!nrow(boundary_df) || !is.finite(adjusted_ris)) {
    stop("TSA plot requires finite RTSA monitoring boundaries and required information size.")
  }
  opt_value <- function(name, default = NULL) {
    if (name %in% names(plot_opts) && length(plot_opts[[name]]) > 0) plot_opts[[name]] else default
  }
  finite_information <- c(
    adjusted_ris,
    cumulative_information[is.finite(cumulative_information)],
    boundary_df$Information[is.finite(boundary_df$Information)],
    futility_df$Information[is.finite(futility_df$Information)]
  )
  max_x <- max(finite_information, na.rm = TRUE) * 1.08
  conventional_z <- stats::qnorm(1 - tsa_alpha / 2)
  sign_value <- suppressWarnings(as.numeric(opt_value("z_sign", 1)))
  z_plot_sign <- if (length(sign_value) && is.finite(sign_value[1]) && sign_value[1] < 0) -1 else 1
  plot_z <- cumulative_z * z_plot_sign
  plot_favor_top <- as.character(opt_value("favor_top", tsa_favor_top))
  plot_favor_bottom <- as.character(opt_value("favor_bottom", tsa_favor_bottom))

  finite_y <- c(
    plot_z[is.finite(plot_z)],
    conventional_z, -conventional_z,
    boundary_df$UpperBoundary[is.finite(boundary_df$UpperBoundary)],
    boundary_df$LowerBoundary[is.finite(boundary_df$LowerBoundary)],
    futility_df$UpperFutility[is.finite(futility_df$UpperFutility)],
    futility_df$LowerFutility[is.finite(futility_df$LowerFutility)]
  )
  max_abs_y <- max(abs(finite_y), na.rm = TRUE)
  y_limit <- min(max(4, ceiling(max_abs_y * 1.06)), 8.5)
  upper_boundary_plot <- pmin(boundary_df$UpperBoundary, y_limit)
  lower_boundary_plot <- pmax(boundary_df$LowerBoundary, -y_limit)
  upper_futility_plot <- if (nrow(futility_df)) pmin(futility_df$UpperFutility, y_limit) else numeric()
  lower_futility_plot <- if (nrow(futility_df)) pmax(futility_df$LowerFutility, -y_limit) else numeric()
  axis_ticks <- seq(-floor(y_limit), floor(y_limit), by = 1)

  red_col <- "#ff1f1f"
  blue_col <- "#263bff"
  conventional_col <- grDevices::adjustcolor(red_col, alpha.f = 0.65)
  ris_col <- grDevices::adjustcolor(red_col, alpha.f = 0.75)
  label_color <- red_col
  point_cex <- 0.52

  label_study <- function(label) {
    label <- trimws(as.character(label))
    year <- regmatches(label, regexpr("(19|20)[0-9]{2}", label))
    author <- sub("\\s*(19|20)[0-9]{2}.*$", "", label)
    author <- sub("[,;:].*$", "", author)
    author <- gsub("\\s+", "", author)
    if (nchar(author) > 14) author <- paste0(substr(author, 1, 14), ".")
    if (length(year) && nzchar(year)) paste0("(", year, ")", author) else author
  }
  study_labels <- vapply(eff_labels, label_study, character(1))

  if (device == "png") {
    png(filename, width = 6600, height = 3600, res = 300, bg = "white")
  } else {
    tiff(filename, width = 6600, height = 3600, res = 300, compression = "none", bg = "white")
  }
  on.exit(dev.off(), add = TRUE)
  par(mar = c(2.2, 5.7, 1.5, 0.6), mgp = c(2.0, 0.55, 0), xpd = FALSE, family = "serif")
  plot(
    NA,
    xlim = c(0, max_x),
    ylim = c(-y_limit, y_limit),
    xlab = "",
    ylab = "",
    main = "",
    axes = FALSE
  )

  axis(
    2, at = axis_ticks, las = 1, cex.axis = 0.82,
    col = "gray35", col.axis = "gray35", tcl = -0.23, lwd = 1.0, lwd.ticks = 1.0
  )
  arrows(0, 0, max_x * 1.01, 0, length = 0.075, angle = 20, col = "black", lwd = 1.15, xpd = NA)
  arrows(0, -y_limit, 0, y_limit * 1.02, length = 0.075, angle = 20, col = "black", lwd = 1.15, xpd = NA)
  text(max_x * 0.50, y_limit * 1.055, "Required information size is a Two-sided graph", cex = 0.74, xpd = NA)
  text(-max_x * 0.006, y_limit * 1.005, "Cumulative\nZ-Score", cex = 0.76, xpd = NA)
  plot_warning <- paste(as.character(opt_value("warning", "")), collapse = " ")
  plot_warning <- trimws(plot_warning)
  if (nzchar(plot_warning)) {
    warning_lines <- strwrap(plot_warning, width = 105)
    warning_lines <- warning_lines[seq_len(min(length(warning_lines), 3))]
    text(
      max_x * 0.50,
      y_limit * 0.90 - (seq_along(warning_lines) - 1) * y_limit * 0.055,
      labels = warning_lines,
      col = "#b00020",
      font = 2,
      cex = 0.58
    )
  }

  segments(0, conventional_z, max_x * 0.965, conventional_z, col = conventional_col, lwd = 0.9)
  segments(0, -conventional_z, max_x * 0.965, -conventional_z, col = conventional_col, lwd = 0.9)
  points(c(0, max_x * 0.965), c(conventional_z, conventional_z), pch = 18, cex = 0.48, col = "black")
  points(c(0, max_x * 0.965), c(-conventional_z, -conventional_z), pch = 18, cex = 0.48, col = "black")

  lines(boundary_df$Information, upper_boundary_plot, col = red_col, lwd = 0.95)
  lines(boundary_df$Information, lower_boundary_plot, col = red_col, lwd = 0.95)
  points(boundary_df$Information, upper_boundary_plot, pch = 18, cex = point_cex, col = "black")
  points(boundary_df$Information, lower_boundary_plot, pch = 18, cex = point_cex, col = "black")
  if (length(upper_futility_plot)) {
    lines(futility_df$Information, upper_futility_plot, col = red_col, lwd = 0.85, lty = 3)
    lines(futility_df$Information, lower_futility_plot, col = red_col, lwd = 0.85, lty = 3)
    points(futility_df$Information, upper_futility_plot, pch = 18, cex = point_cex, col = "black")
    points(futility_df$Information, lower_futility_plot, pch = 18, cex = point_cex, col = "black")
  }

  abline(v = adjusted_ris, col = ris_col, lwd = 0.9)
  points(rep(adjusted_ris, 2), c(-y_limit * 0.97, y_limit * 0.97), pch = 18, cex = 0.5, col = "black")
  text(
    adjusted_ris, y_limit * 0.98,
    paste0("Required information size = ", round(adjusted_ris)),
    col = red_col, pos = 2, cex = 0.70
  )
  text(
    adjusted_ris, -conventional_z * 1.03,
    "Required information size",
    col = red_col, srt = 52, adj = c(1, 0.5), cex = 0.62
  )

  lines(cumulative_information, plot_z, col = blue_col, lwd = 1.05)
  points(cumulative_information, plot_z, pch = 15, cex = 0.45, col = "black")
  segments(cumulative_information, 0, cumulative_information, -0.18, col = "black", lwd = 0.85)
  text(
    cumulative_information,
    rep(-0.28, length(cumulative_information)),
    labels = study_labels,
    srt = 45,
    adj = c(1.05, 1),
    cex = 0.58,
    col = label_color
  )
  if (length(cumulative_information) && any(is.finite(plot_z))) {
    final_idx <- tail(which(is.finite(cumulative_information) & is.finite(plot_z)), 1)
    text(
      cumulative_information[final_idx],
      plot_z[final_idx],
      " Z-curve",
      col = blue_col,
      pos = 4,
      cex = 0.72
    )
  }

  text(-max_x * 0.035, y_limit * 0.55, paste("Favours", plot_favor_top), srt = 90, cex = 0.58, xpd = NA)
  text(-max_x * 0.035, -y_limit * 0.55, paste("Favours", plot_favor_bottom), srt = 90, cex = 0.58, xpd = NA)
  invisible(TRUE)
}
"""


_TSA_HELPERS_R = r"""
boundary_crossing_status <- function(information, z_values, boundary) {
  if (!length(z_values) || !any(is.finite(z_values)) || !nrow(boundary)) {
    return("not assessable")
  }
  for (i in seq_along(z_values)) {
    if (!is.finite(information[i]) || !is.finite(z_values[i])) next
    eligible <- which(is.finite(boundary$Information) & boundary$Information <= information[i])
    if (!length(eligible)) eligible <- which.min(abs(boundary$Information - information[i]))
    if (!length(eligible) || !is.finite(eligible[1])) next
    b <- boundary[tail(eligible, 1), , drop = FALSE]
    if (is.finite(b$UpperBoundary) && z_values[i] >= b$UpperBoundary) return("crossed upper efficacy boundary")
    if (is.finite(b$LowerBoundary) && z_values[i] <= b$LowerBoundary) return("crossed lower efficacy boundary")
  }
  "not crossed"
}

futility_boundary_status <- function(information, z_values, futility) {
  if (!nrow(futility)) return("not drawn")
  if (!length(z_values) || !any(is.finite(z_values))) return("not assessable")
  for (i in seq_along(z_values)) {
    if (!is.finite(information[i]) || !is.finite(z_values[i])) next
    eligible <- which(is.finite(futility$Information) & futility$Information <= information[i])
    if (!length(eligible)) eligible <- which.min(abs(futility$Information - information[i]))
    if (!length(eligible) || !is.finite(eligible[1])) next
    b <- futility[tail(eligible, 1), , drop = FALSE]
    if (is.finite(b$UpperFutility) && is.finite(b$LowerFutility) &&
        z_values[i] <= b$UpperFutility && z_values[i] >= b$LowerFutility) {
      return("entered non-binding futility region; informational only")
    }
  }
  "not entered; non-binding informational only"
}

sorted_ci_bounds <- function(lower, upper) {
  bounds <- suppressWarnings(as.numeric(c(lower, upper)))
  if (length(bounds) != 2 || any(!is.finite(bounds))) return(NULL)
  sort(bounds)
}

extract_study_year <- function(studies) {
  match_pos <- regexpr("(19|20)[0-9]{2}", studies)
  years <- rep(NA_real_, length(studies))
  has_year <- match_pos > 0
  years[has_year] <- suppressWarnings(as.numeric(regmatches(studies, match_pos)[has_year]))
  years
}

add_analysis_row_order <- function(rtsa_data, analysis_data) {
  fallback_order <- seq_len(nrow(rtsa_data))
  row_order <- fallback_order
  if (is.data.frame(analysis_data) && "Author" %in% names(analysis_data)) {
    order_lookup <- data.frame(
      study = as.character(analysis_data$Author),
      analysis_row_order = seq_len(nrow(analysis_data)),
      stringsAsFactors = FALSE
    )
    order_lookup <- order_lookup[!duplicated(order_lookup$study), , drop = FALSE]
    matched_order <- order_lookup$analysis_row_order[match(as.character(rtsa_data$study), order_lookup$study)]
    matched_order <- suppressWarnings(as.numeric(matched_order))
    row_order[is.finite(matched_order)] <- matched_order[is.finite(matched_order)]
  }
  rtsa_data$analysis_row_order <- row_order
  rtsa_data
}

first_finite <- function(x) {
  values <- suppressWarnings(as.numeric(unlist(x, use.names = FALSE)))
  values <- values[is.finite(values)]
  if (length(values)) values[1] else NA_real_
}

pick_best_ris <- function(results) {
  suppressWarnings(as.numeric(
    if (!is.null(results$SMA_HARIS) && is.finite(as.numeric(results$SMA_HARIS))) {
      results$SMA_HARIS
    } else if (!is.null(results$HARIS) && is.finite(as.numeric(results$HARIS))) {
      results$HARIS
    } else if (!is.null(results$SMA_RIS) && is.finite(as.numeric(results$SMA_RIS))) {
      results$SMA_RIS
    } else {
      results$RIS
    }
  ))
}

extract_rtsa_d2 <- function(rtsa_ma) {
  u_values <- if (!is.null(rtsa_ma$synthesize) && !is.null(rtsa_ma$synthesize$U)) {
    suppressWarnings(as.numeric(rtsa_ma$synthesize$U))
  } else {
    numeric()
  }
  u_names <- c("tau2", "H", "I2", "D2")
  if (length(u_values)) {
    names(u_values)[seq_len(min(length(u_values), length(u_names)))] <-
      u_names[seq_len(min(length(u_values), length(u_names)))]
  }
  if ("D2" %in% names(u_values) && is.finite(u_values[["D2"]])) {
    u_values[["D2"]]
  } else {
    NA_real_
  }
}
"""


_BINARY_TSA_R = r"""
run_binary_tsa <- function() {
  tsa_dir <- file.path(output, paste0("TSA ", outcome))
  dir.create(tsa_dir, recursive = TRUE, showWarnings = FALSE)
  unlink(file.path(tsa_dir, paste0("TSANotes", outcome, ".txt")))
  tsa_plot_opts <- list(
    warning = "",
    z_sign = -1,
    favor_top = tsa_favor_bottom,
    favor_bottom = tsa_favor_top
  )

  if (meta$k < 2) {
    writeLines("Trial sequential analysis was skipped because at least two studies are required.",
               con = file.path(tsa_dir, paste0("TSANotes", outcome, ".txt")))
    return(invisible(NULL))
  }
  if (pooling_method == "Peto") {
    unlink(file.path(tsa_dir, c("Adjusted Boundaries Print.png",
                                "Adjusted Boundaries Print.tiff",
                                paste0("TSAZCurveData", outcome, ".csv"),
                                paste0("TSABoundaries", outcome, ".csv"),
                                paste0("TSAFutilityBoundaries", outcome, ".csv"),
                                paste0("TSAParameters", outcome, ".csv"),
                                paste0("TSAParameters", outcome, ".txt"))))
    writeLines(
      "Trial sequential analysis was skipped because Peto pooling is not supported by RTSA.",
      con = file.path(tsa_dir, paste0("TSANotes", outcome, ".txt"))
    )
    return(invisible(NULL))
  }
  if (tsa_adjust_for_diversity && !random_model) {
    writeLines(
      "Trial sequential analysis was skipped because D2 diversity adjustment requires a random-effects RTSA analysis.",
      con = file.path(tsa_dir, paste0("TSANotes", outcome, ".txt"))
    )
    return(invisible(NULL))
  }

  ## ---- Prepare RTSA-format data from the same fitted object used by the forest plot ----
  meta_study <- as.character(meta$studlab)
  rtsa_data <- data.frame(
    study = meta_study,
    eI    = suppressWarnings(as.numeric(meta$event.e)),
    nI    = suppressWarnings(as.numeric(meta$n.e)),
    eC    = suppressWarnings(as.numeric(meta$event.c)),
    nC    = suppressWarnings(as.numeric(meta$n.c)),
    stringsAsFactors = FALSE
  )
  if (!length(meta_study) || nrow(rtsa_data) != meta$k) {
    rtsa_data <- data.frame(
      study = as.character(data$Author),
      eI    = suppressWarnings(as.numeric(data$event.e)),
      nI    = suppressWarnings(as.numeric(data$n.e)),
      eC    = suppressWarnings(as.numeric(data$event.c)),
      nC    = suppressWarnings(as.numeric(data$n.c)),
      stringsAsFactors = FALSE
    )
    rtsa_data_source <- "analysis CSV fallback"
  } else {
    rtsa_data_source <- "meta object used for forest plot"
  }
  rtsa_data <- add_analysis_row_order(rtsa_data, data)
  rtsa_order_source <- "Chronological publication year parsed from study label; no tied or missing years detected"
  tsa_order_warning <- ""
  explicit_order_col <- intersect(c("tsa_order", "order"), names(data))
  if (length(explicit_order_col)) {
    explicit_order_col <- explicit_order_col[1]
    order_lookup <- data.frame(
      study = as.character(data$Author),
      tsa_order_value = suppressWarnings(as.numeric(data[[explicit_order_col]])),
      stringsAsFactors = FALSE
    )
    order_lookup <- order_lookup[!duplicated(order_lookup$study), , drop = FALSE]
    order_idx <- match(rtsa_data$study, order_lookup$study)
    order_values <- order_lookup$tsa_order_value[order_idx]
    if (length(order_values) != nrow(rtsa_data) ||
        any(!is.finite(order_values)) ||
        any(duplicated(order_values))) {
      writeLines(
        c(
          paste0("Trial sequential analysis was skipped because the explicit ", explicit_order_col, " column was not a complete unique numeric study order."),
          "Provide one finite, unique order value for each study so RTSA receives an explicit cumulative sequence."
        ),
        con = file.path(tsa_dir, paste0("TSANotes", outcome, ".txt"))
      )
      return(invisible(NULL))
    }
    rtsa_data$tsa_order_value <- order_values
    rtsa_order_source <- paste("Explicit", explicit_order_col, "column in the analysis data (analyst-supplied cumulative sequence)")
  }
  rtsa_data$year <- extract_study_year(rtsa_data$study)
  if ("tsa_order_value" %in% names(rtsa_data)) {
    rtsa_data <- rtsa_data[order(rtsa_data$tsa_order_value, ifelse(is.na(rtsa_data$year), Inf, rtsa_data$year), rtsa_data$analysis_row_order, rtsa_data$study), ]
  } else {
    finite_year <- rtsa_data$year[is.finite(rtsa_data$year)]
    tied_years <- any(duplicated(finite_year))
    missing_years <- any(!is.finite(rtsa_data$year))
    if (missing_years) {
      rtsa_data <- rtsa_data[order(rtsa_data$analysis_row_order, rtsa_data$study), ]
      rtsa_order_source <- "Analyst-entered analysis-data row order used because chronological publication year could not be parsed for every study"
      tsa_order_warning <- paste(
        "TSA study order note: original TSA convention is study-sequential and usually chronological; at least one study label lacked a parseable publication year, so the cumulative sequence used the analyst-entered analysis-data row order.",
        "Add a numeric tsa_order or order column for a protocol-defined sequence."
      )
    } else if (tied_years) {
      rtsa_data <- rtsa_data[order(rtsa_data$year, rtsa_data$analysis_row_order, rtsa_data$study), ]
      rtsa_order_source <- "Chronological publication year parsed from study label; same-year ties resolved by analyst-entered analysis-data row order"
      tsa_order_warning <- paste(
        "TSA study order note: original TSA convention is study-sequential and usually chronological; multiple studies shared a publication year, so same-year ties were resolved by analyst-entered analysis-data row order.",
        "Add a numeric tsa_order or order column for a protocol-defined tie-breaker."
      )
    } else {
      rtsa_data <- rtsa_data[order(rtsa_data$year, rtsa_data$analysis_row_order, rtsa_data$study), ]
    }
  }
  rtsa_data$tsa_sequence <- seq_len(nrow(rtsa_data))
  rtsa_data_export <- rtsa_data
  first_cols <- c("tsa_sequence", "study", "year", "analysis_row_order", "tsa_order_value")
  rtsa_data_export <- rtsa_data_export[, c(first_cols[first_cols %in% names(rtsa_data_export)],
                                           setdiff(names(rtsa_data_export), first_cols)), drop = FALSE]
  write.csv(rtsa_data_export,
            file.path(tsa_dir, paste0("TSAAnalysisDataset", outcome, ".csv")),
            row.names = FALSE)
  rtsa_data$year <- NULL
  rtsa_data$analysis_row_order <- NULL
  rtsa_data$tsa_order_value <- NULL
  rtsa_data$tsa_sequence <- NULL
  complete_mask <- complete.cases(rtsa_data[, c("eI", "nI", "eC", "nC")])
  rtsa_data <- rtsa_data[complete_mask, ]
  if (nrow(rtsa_data) != meta$k) {
    writeLines(
      paste("TSA input contains", nrow(rtsa_data), "complete rows but the forest-plot meta object contains", meta$k, "studies."),
      con = file.path(tsa_dir, paste0("TSANotes", outcome, ".txt"))
    )
  }
  if (nrow(rtsa_data) < 2) {
    writeLines("Trial sequential analysis was skipped: fewer than 2 complete studies.",
               con = file.path(tsa_dir, paste0("TSANotes", outcome, ".txt")))
    return(invisible(NULL))
  }

  ## ---- Determine mc (anticipated effect on natural scale) ----
  pc_observed <- sum(rtsa_data$eC) / sum(rtsa_data$nC)
  pc_observed <- pmin(pmax(pc_observed, 0.001), 0.999)
  pt_observed <- sum(rtsa_data$eI) / sum(rtsa_data$nI)
  pt_observed <- pmin(pmax(pt_observed, 0.001), 0.999)
  tsa_warnings <- c()
  if (nzchar(tsa_order_warning)) tsa_warnings <- c(tsa_warnings, tsa_order_warning)
  i2_percent <- suppressWarnings(as.numeric(meta$I2))
  if (is.finite(i2_percent) && i2_percent <= 1) i2_percent <- i2_percent * 100
  if (nrow(rtsa_data) < 5) {
    tsa_warnings <- c(tsa_warnings, "RTSA input note: fewer than 5 cumulative looks were available after exclusions.")
  } else if (nrow(rtsa_data) < 10) {
    tsa_warnings <- c(tsa_warnings, "RTSA input note: fewer than 10 cumulative looks were available after exclusions.")
  }
  if (summary_measure %in% c("RR", "OR")) {
    total_events <- sum(rtsa_data$eI + rtsa_data$eC, na.rm = TRUE)
    total_n <- sum(rtsa_data$nI + rtsa_data$nC, na.rm = TRUE)
    total_event_prop <- if (is.finite(total_n) && total_n > 0) total_events / total_n else NA_real_
    if (is.finite(total_event_prop) && total_event_prop < 0.20) {
      tsa_warnings <- c(tsa_warnings, "RTSA routing note: overall binary event proportion was below the script's RTSA 0.2.2 sparse-data guard threshold.")
    }
    if (any(rtsa_data$eI < 3 | rtsa_data$eC < 3, na.rm = TRUE)) {
      tsa_warnings <- c(tsa_warnings, "RTSA routing note: at least one study arm had fewer than 3 events under the script's RTSA 0.2.2 sparse-data guard.")
    }
  }
  if (is.finite(i2_percent) && i2_percent >= 50 && !tsa_adjust_for_diversity) {
    tsa_warnings <- c(tsa_warnings, paste0("Observed I2 is ", signif(i2_percent, 4), "% and RTSA random_adj was set to tau2 rather than D2."))
  }
  pc <- if (is.finite(tsa_control_event_proportion)) tsa_control_event_proportion else pc_observed
  pc <- pmin(pmax(pc, 0.001), 0.999)
  pooled_te <- if (random_model && is.finite(meta$TE.random)) meta$TE.random else meta$TE.common
  effective_tsa_effect_source <- tsa_effect_source
  if (tsa_effect_source == "clinically_important" && is.finite(tsa_anticipated_effect)) {
    mc_value <- tsa_anticipated_effect
    anticipated_note <- paste("clinically important", summary_measure, "=", signif(mc_value, 4))
  } else {
    effective_tsa_effect_source <- "observed"
    mc_value <- if (summary_measure == "RD") pooled_te else exp(pooled_te)
    anticipated_note <- paste("observed pooled", summary_measure, "=", signif(mc_value, 4))
  }
  if (summary_measure == "OR") {
    odds_t <- (pc / (1 - pc)) * mc_value
    pt <- pmin(pmax(odds_t / (1 + odds_t), 0.001), 0.999)
  } else if (summary_measure == "RD") {
    pt <- pmin(pmax(pc + mc_value, 0.001), 0.999)
  } else {
    pt <- pmin(pmax(pc * mc_value, 0.001), 0.999)
  }
  if (is.finite(tsa_intervention_event_proportion)) {
    pt <- pmin(pmax(tsa_intervention_event_proportion, 0.001), 0.999)
    if (summary_measure == "OR") {
      mc_value <- (pt / (1 - pt)) / (pc / (1 - pc))
    } else if (summary_measure == "RD") {
      mc_value <- pt - pc
    } else {
      mc_value <- pt / pc
    }
    effective_tsa_effect_source <- "manual/protocol intervention event proportion"
    anticipated_note <- paste("manual intervention event proportion implies", summary_measure, "=", signif(mc_value, 4))
  }
  if (effective_tsa_effect_source == "observed") {
    tsa_warnings <- c(tsa_warnings, "The RTSA mc input was derived from the observed pooled effect.")
  }
  tsa_warnings <- unique(tsa_warnings)
  tsa_suitability <- if (any(grepl("fewer than 5 cumulative looks", tsa_warnings, ignore.case = TRUE))) {
    "Exploratory only: fewer than 5 cumulative looks recorded in RTSA input"
  } else if (any(grepl("observed pooled effect", tsa_warnings, ignore.case = TRUE))) {
    "Generated with RTSA input notes: observed-effect mc"
  } else if (length(tsa_warnings)) {
    "Generated with recorded RTSA input notes"
  } else {
    "Generated; no RTSA input notes detected"
  }
  tsa_warning_text <- if (length(tsa_warnings)) paste(tsa_warnings, collapse = " | ") else "None"
  if (length(tsa_warnings)) {
    writeLines(c("TSA interpretability warnings:", paste0("- ", tsa_warnings)),
               con = file.path(tsa_dir, paste0("TSAWarnings", outcome, ".txt")))
  }

  ## ---- Initialise result variables ----
  rtsa_obj        <- NULL
  rtsa_error      <- NA_character_
  ris             <- NA_real_
  adjusted_ris    <- NA_real_
  boundary_df     <- data.frame(Information = numeric(), UpperBoundary = numeric(), LowerBoundary = numeric())
  futility_df     <- data.frame(Information = numeric(), UpperFutility = numeric(), LowerFutility = numeric())
  cumulative_z    <- rep(NA_real_, nrow(rtsa_data))
  cumulative_information <- cumsum(rtsa_data$nI + rtsa_data$nC)
  rtsa_information_from_results <- numeric()
  eff_labels      <- as.character(rtsa_data$study)
  ris_engine      <- "not calculated"
  ris_note        <- ""
  boundary_engine <- "not drawn"
  futility_note   <- "none"
  tsa_adj_ci      <- NULL
  tsa_adj_ci_status <- "not computed: integrated RTSA(type='analysis') did not run"
  used_primary    <- FALSE
  cumulative_z_note <- ""

  if (!requireNamespace("RTSA", quietly = TRUE)) {
    rtsa_error <- "RTSA package is not installed. Install with: install.packages('RTSA')"
    writeLines(rtsa_error, con = file.path(tsa_dir, paste0("TSANotes", outcome, ".txt")))
    return(invisible(NULL))
  }

  rtsa_design_boundary_fallback <- function() {
    rtsa_beta <- 1 - tsa_power
    d2_source <- "not used"
    d2_prop <- 0
    if (random_model) {
      rtsa_ma_for_d2 <- try(
        RTSA::metaanalysis(
          outcome = summary_measure,
          data = rtsa_data,
          mc = mc_value,
          weights = rtsa_weights,
          re_method = "DL_HKSJ",
          tau_ci_method = "BJ",
          zero_adj = 0.5
        ),
        silent = TRUE
      )
      d2_from_rtsa <- if (!inherits(rtsa_ma_for_d2, "try-error") &&
                          !is.null(rtsa_ma_for_d2$synthesize)) {
        extract_rtsa_d2(rtsa_ma_for_d2)
      } else {
        NA_real_
      }
      d2_prop <- if (is.finite(d2_from_rtsa)) {
        d2_source <- "RTSA::metaanalysis synthesize U[D2] diversity estimate"
        d2_from_rtsa
      } else {
        d2_source <- "not available from RTSA::metaanalysis"
        NA_real_
      }
    }
    d2_prop <- pmin(pmax(d2_prop, 0), 0.99)
    if (tsa_adjust_for_diversity && !is.finite(d2_prop)) {
      stop("RTSA::metaanalysis did not return a finite D2 estimate for fallback RTSA::ris.")
    }

    rtsa_ris <- try({
      if (summary_measure == "RD") {
        RTSA::ris(
          outcome = "RD",
          mc = mc_value,
          pC = pc,
          p1 = pt,
          side = 2,
          alpha = tsa_alpha,
          beta = rtsa_beta,
          fixed = !tsa_adjust_for_diversity,
          D2 = if (tsa_adjust_for_diversity) d2_prop else NULL,
          type = "prospective"
        )
      } else {
        RTSA::ris(
          outcome = summary_measure,
          mc = mc_value,
          pC = pc,
          side = 2,
          alpha = tsa_alpha,
          beta = rtsa_beta,
          fixed = !tsa_adjust_for_diversity,
          D2 = if (tsa_adjust_for_diversity) d2_prop else NULL,
          type = "prospective"
        )
      }
    }, silent = TRUE)
    if (inherits(rtsa_ris, "try-error")) {
      stop(as.character(rtsa_ris))
    }

    ris_value <- suppressWarnings(as.numeric(rtsa_ris$NF[1]))
    adjusted_value <- if (tsa_adjust_for_diversity) {
      first_finite(list(rtsa_ris$NR_D2, rtsa_ris$NF))
    } else {
      first_finite(list(rtsa_ris$NF, rtsa_ris$NR_D2))
    }
    if (is.finite(tsa_required_information_size)) {
      adjusted_value <- tsa_required_information_size
    }
    if (!is.finite(adjusted_value)) {
      stop("RTSA::ris did not return a finite required information size.")
    }

    look_timing <- sort(unique(c(
      pmin(cumulative_information[is.finite(cumulative_information)] / adjusted_value, 1),
      1
    )))
    look_timing <- look_timing[is.finite(look_timing) & look_timing > 0 & look_timing <= 1]
    if (!length(look_timing)) {
      stop("No valid cumulative information timings were available for RTSA::boundaries.")
    }
    fallback_futility_note <- "FALLBACK: RTSA non-binding O'Brien-Fleming beta-spending futility boundaries"
    rtsa_bounds <- try(
      RTSA::boundaries(
        timing = look_timing,
        alpha = tsa_alpha,
        beta = rtsa_beta,
        side = 2,
        futility = "non-binding",
        es_alpha = "esOF",
        es_beta = "esOF"
      ),
      silent = TRUE
    )
    if (inherits(rtsa_bounds, "try-error")) {
      fallback_futility_note <- paste(
        "FALLBACK: futility boundaries not drawn because RTSA::boundaries failed for non-binding beta-spending:",
        as.character(rtsa_bounds)
      )
      rtsa_bounds <- RTSA::boundaries(
        timing = look_timing,
        alpha = tsa_alpha,
        beta = rtsa_beta,
        side = 2,
        futility = "none",
        es_alpha = "esOF",
        es_beta = NULL
      )
    }
    boundary <- data.frame(
      Information = rtsa_bounds$inf_frac * adjusted_value,
      UpperBoundary = as.numeric(rtsa_bounds$alpha_ubound),
      LowerBoundary = as.numeric(rtsa_bounds$alpha_lbound)
    )
    boundary <- boundary[
      is.finite(boundary$Information) &
        is.finite(boundary$UpperBoundary) &
        is.finite(boundary$LowerBoundary),
    ]
    futility <- data.frame(Information = numeric(), UpperFutility = numeric(), LowerFutility = numeric())
    if (!is.null(rtsa_bounds$beta_ubound) && !is.null(rtsa_bounds$beta_lbound)) {
      futility <- data.frame(
        Information = rtsa_bounds$inf_frac * adjusted_value,
        UpperFutility = as.numeric(rtsa_bounds$beta_ubound),
        LowerFutility = as.numeric(rtsa_bounds$beta_lbound)
      )
      futility <- futility[
        is.finite(futility$Information) &
          is.finite(futility$UpperFutility) &
          is.finite(futility$LowerFutility),
      ]
    }
    list(
      ris = ris_value,
      adjusted_ris = adjusted_value,
      boundary = boundary,
      futility = futility,
      futility_note = fallback_futility_note,
      engine = "RTSA::ris + RTSA::boundaries",
      note = if (is.finite(tsa_required_information_size)) {
        paste("RTSA RIS was calculated; user-specified RIS override used for boundary timing =", round(tsa_required_information_size),
              "; fallback D2 source:", d2_source)
      } else if (tsa_adjust_for_diversity) {
        paste("RTSA diversity-adjusted required information size using D2 =", signif(d2_prop, 4),
              "; D2 source:", d2_source)
      } else {
        "RTSA fixed-effect required information size for fallback boundary timing"
      }
    )
  }

  ## ================================================================
  ## PRIMARY APPROACH: RTSA(type = "analysis") integrated pipeline
  ## This matches the TSA Java software design:
  ##   - Uses DL_HKSJ tau estimator (RTSA default)
  ##   - Computes SMA_HARIS (sequential-inflated RIS) as denominator
  ##   - Z-scores are consistent with boundaries
  ##   - Produces TSA-adjusted confidence interval
  ## ================================================================
  binary_ratio_tsa <- summary_measure %in% c("RR", "OR")
  zero_cell_binary_tsa <- binary_ratio_tsa &&
    any(rtsa_data$eI <= 0 | rtsa_data$eC <= 0, na.rm = TRUE)
  low_cell_binary_tsa <- binary_ratio_tsa &&
    any(rtsa_data$eI < 3 | rtsa_data$eC < 3, na.rm = TRUE)
  rare_event_binary_tsa <- binary_ratio_tsa &&
    is.finite(sum(rtsa_data$eI + rtsa_data$eC, na.rm = TRUE)) &&
    is.finite(sum(rtsa_data$nI + rtsa_data$nC, na.rm = TRUE)) &&
    sum(rtsa_data$nI + rtsa_data$nC, na.rm = TRUE) > 0 &&
    (sum(rtsa_data$eI + rtsa_data$eC, na.rm = TRUE) / sum(rtsa_data$nI + rtsa_data$nC, na.rm = TRUE)) < 0.20
  few_look_binary_tsa <- binary_ratio_tsa && nrow(rtsa_data) < 10
  sparse_binary_tsa <- zero_cell_binary_tsa || low_cell_binary_tsa ||
    rare_event_binary_tsa || few_look_binary_tsa
  sparse_binary_reasons <- c()
  if (zero_cell_binary_tsa) sparse_binary_reasons <- c(sparse_binary_reasons, "zero-event arm cells")
  if (low_cell_binary_tsa) sparse_binary_reasons <- c(sparse_binary_reasons, "arm cells with fewer than 3 events")
  if (rare_event_binary_tsa) sparse_binary_reasons <- c(sparse_binary_reasons, "overall event proportion below 20%")
  if (few_look_binary_tsa) sparse_binary_reasons <- c(sparse_binary_reasons, "fewer than 10 cumulative looks after exclusions")
  if (is.finite(tsa_required_information_size)) {
    rtsa_obj <- structure(
      "Manual RIS override requested; routing to RTSA::ris + RTSA::boundaries because integrated RTSA(type='analysis') cannot replace its internally calculated RIS denominator.",
      class = "try-error"
    )
  } else if (sparse_binary_tsa) {
    rtsa_obj <- structure(
      paste0(
        "Sparse binary ", summary_measure, " TSA data detected (",
        paste(sparse_binary_reasons, collapse = "; "),
        "); skipped integrated RTSA(type='analysis') because RTSA 0.2.2 can stall in its compiled probability routine for sparse binary data. ",
        "Using RTSA::ris + RTSA::boundaries with the same forest-plot studies and sequential meta::metabin Z-curve."
      ),
      class = "try-error"
    )
  } else {
    rtsa_obj <- try({
      RTSA::RTSA(
        type        = "analysis",
        data        = rtsa_data,
        outcome     = summary_measure,
        mc          = mc_value,
        pC          = pc,
        side        = 2,
        alpha       = tsa_alpha,
        beta        = 1 - tsa_power,
        es_alpha    = "esOF",
        es_beta     = "esOF",
        futility    = "non-binding",
        fixed       = !random_model,
        weights     = rtsa_weights,
        re_method   = "DL_HKSJ",
        zero_adj    = 0.5,
        random_adj  = if (tsa_adjust_for_diversity) "D2" else "tau2"
      )
    }, silent = TRUE)
  }

  if (!inherits(rtsa_obj, "try-error") && !is.null(rtsa_obj)) {

    ## ---- SUCCESS: extract results from RTSA object ----
    used_primary    <- TRUE
    ris_engine      <- "RTSA(type='analysis') integrated pipeline"
    boundary_engine <- "RTSA Lan-DeMets O'Brien-Fleming alpha-spending"
    futility_note   <- "RTSA non-binding O'Brien-Fleming beta-spending futility boundaries"

    ## Extract RIS values — prefer SMA_HARIS > HARIS > SMA_RIS > RIS
    ris <- suppressWarnings(as.numeric(
      if (!is.null(rtsa_obj$results$RIS)) rtsa_obj$results$RIS else NA_real_
    ))
    adjusted_ris <- pick_best_ris(rtsa_obj$results)
    ris_note <- paste("RTSA sequential",
                      if (random_model) "heterogeneity-adjusted" else "fixed-effect",
                      "RIS =", if (is.finite(adjusted_ris)) round(adjusted_ris) else "NA")

    ## Extract boundaries and Z-scores from results_df
    rdf <- rtsa_obj$results$results_df
    if (!is.null(rdf) && is.data.frame(rdf) && nrow(rdf) > 0 && is.finite(adjusted_ris)) {
      pick <- function(candidates) {
        hit <- candidates[candidates %in% names(rdf)]
        if (length(hit)) hit[1] else NA_character_
      }
      t_col  <- pick(c("sma_timing", "timing", "inf_frac"))
      u_col  <- pick(c("upper", "alpha_upper", "alpha_ubound"))
      l_col  <- pick(c("lower", "alpha_lower", "alpha_lbound"))
      z_col  <- pick(if (random_model) c("z_random", "z") else c("z_fixed", "z"))
      fu_col <- pick(c("fut_upper", "beta_upper", "beta_ubound"))
      fl_col <- pick(c("fut_lower", "beta_lower", "beta_lbound"))
      if (!is.na(t_col)) {
        rtsa_information_from_results <- suppressWarnings(as.numeric(rdf[[t_col]])) * adjusted_ris
      }

      if (!is.na(t_col) && !is.na(u_col)) {
        info  <- rtsa_information_from_results
        upper <- suppressWarnings(as.numeric(rdf[[u_col]]))
        lower <- if (!is.na(l_col)) suppressWarnings(as.numeric(rdf[[l_col]])) else -upper
        keep  <- is.finite(info) & is.finite(upper) & is.finite(lower)
        boundary_df <- data.frame(Information   = info[keep],
                                   UpperBoundary = upper[keep],
                                   LowerBoundary = lower[keep])
      }
      if (!is.na(z_col)) {
        cumulative_z <- suppressWarnings(as.numeric(rdf[[z_col]]))
      }
      if (!is.na(fu_col) && !is.na(fl_col) && !is.na(t_col)) {
        info <- rtsa_information_from_results
        fu   <- suppressWarnings(as.numeric(rdf[[fu_col]]))
        fl   <- suppressWarnings(as.numeric(rdf[[fl_col]]))
        kf   <- is.finite(info) & is.finite(fu) & is.finite(fl)
        if (any(kf)) {
          futility_df <- data.frame(Information   = info[kf],
                                     UpperFutility = fu[kf],
                                     LowerFutility = fl[kf])
          futility_note <- "RTSA beta-spending futility boundaries"
        }
      }
    }

    ## Use RTSA's internal cumulative information if available
    if (!is.null(rtsa_obj$metaanalysis) && !is.null(rtsa_obj$metaanalysis$study_results)) {
      sr <- rtsa_obj$metaanalysis$study_results
      if ("n" %in% names(sr) && length(sr$n) == nrow(rtsa_data)) {
        cumulative_information <- cumsum(as.numeric(sr$n))
      }
    }
    if (length(cumulative_z) &&
        length(cumulative_information) != length(cumulative_z) &&
        length(rtsa_information_from_results) == length(cumulative_z)) {
      cumulative_information <- rtsa_information_from_results
    }
    if (length(cumulative_z) && length(eff_labels) != length(cumulative_z)) {
      eff_labels <- paste("Look", seq_along(cumulative_z))
    }

    if (length(cumulative_z) != nrow(rtsa_data) || any(!is.finite(cumulative_z))) {
      cumulative_z_note <- "RTSA(type='analysis') did not return a complete cumulative Z-score vector; no substitute Z-curve was calculated."
    }

    ## Extract TSA-adjusted CI (key output for GRADE imprecision)
    ## RTSA's seq_inf list has $lower, $upper, $p.value — these can be NULL
    ## when uniroot fails to converge.
    if (!is.null(rtsa_obj$results$seq_inf)) {
      si <- rtsa_obj$results$seq_inf
      si_lower <- suppressWarnings(as.numeric(si$lower))
      si_upper <- suppressWarnings(as.numeric(si$upper))
      si_pval  <- suppressWarnings(as.numeric(si$p.value))
      if (length(si_lower) > 0 && length(si_upper) > 0 &&
          is.finite(si_lower[1]) && is.finite(si_upper[1])) {
        ci_bounds <- sorted_ci_bounds(si_lower[1], si_upper[1])
        if (!is.null(ci_bounds)) {
          tsa_adj_ci <- list(
            lower   = ci_bounds[1],
            upper   = ci_bounds[2],
            p_value = if (length(si_pval) > 0 && is.finite(si_pval[1])) si_pval[1] else NA_real_
          )
          tsa_adj_ci_status <- "available from RTSA seq_inf"
        }
      }
      if (is.null(tsa_adj_ci)) {
        tsa_adj_ci_status <- "RTSA seq_inf returned without finite CI bounds"
      }
    } else {
      tsa_adj_ci_status <- "RTSA seq_inf was NULL"
    }

    ## Incidence and Z-curve provenance notes for parameters table
    pc_source <- if (is.finite(tsa_control_event_proportion)) "manual/protocol control event proportion" else "observed control arm event proportion"
    pt_source <- if (is.finite(tsa_intervention_event_proportion)) "manual/protocol intervention event proportion" else "derived from anticipated effect and control proportion"
    incidence_note <- paste("RIS input pc:", pc_source, "; RIS input pt:", pt_source)
    if (!nzchar(cumulative_z_note)) {
      cumulative_z_note <- paste0("RTSA(type='analysis') integrated Z-scores from results_df (DL_HKSJ); ",
                                  "consistent with monitoring boundaries")
    }

  } else {
    primary_error <- if (inherits(rtsa_obj, "try-error")) as.character(rtsa_obj) else "unknown"
    rtsa_obj <- NULL
    pc_source <- if (is.finite(tsa_control_event_proportion)) "manual/protocol control event proportion" else "observed control arm event proportion"
    pt_source <- if (is.finite(tsa_intervention_event_proportion)) "manual/protocol intervention event proportion" else "derived from anticipated effect and control proportion"
    incidence_note <- paste("RIS input pc:", pc_source, "; RIS input pt:", pt_source)
    cumulative_information <- cumsum(rtsa_data$nI + rtsa_data$nC)
    eff_labels <- as.character(rtsa_data$study)
    cumulative_z <- rep(NA_real_, nrow(rtsa_data))
    for (look_index in seq_len(nrow(rtsa_data))) {
      look_data <- rtsa_data[seq_len(look_index), , drop = FALSE]
      look_meta <- try(meta::metabin(
        eI, nI, eC, nC,
        studlab = study,
        data = look_data,
        sm = summary_measure,
        method = pooling_method,
        incr = 0.5,
        method.incr = "only0",
        allstudies = TRUE,
        method.tau = "DL",
        method.random.ci = "HK",
        random = random_model,
        common = common_model,
        prediction = FALSE
      ), silent = TRUE)
      if (!inherits(look_meta, "try-error")) {
        te_val <- if (random_model) first_finite(list(look_meta$TE.random, look_meta$TE.common)) else first_finite(list(look_meta$TE.common, look_meta$TE.random))
        se_val <- if (random_model) first_finite(list(look_meta$seTE.random, look_meta$seTE.common)) else first_finite(list(look_meta$seTE.common, look_meta$seTE.random))
        if (is.finite(te_val) && is.finite(se_val) && se_val > 0) {
          cumulative_z[look_index] <- te_val / se_val
        }
      }
    }
    cumulative_z_note <- paste0(
      "Primary RTSA(type='analysis') failed; Z-curve calculated as sequential meta::metabin ",
      pooling_method,
      ifelse(random_model, " random-effects (DL + Hartung-Knapp)", " common-effect"),
      " estimates at each study look. Monitoring boundaries calculated with RTSA::ris + RTSA::boundaries; ",
      "these engines use different information/variance scales, so no monitoring-boundary assessment is made for the fallback display."
    )
    tsa_plot_opts$warning <- paste(
      "FALLBACK DIAGNOSTIC ONLY:",
      "Z-curve from sequential meta::metabin; boundaries/RIS from RTSA::ris + RTSA::boundaries.",
      "Do not interpret crossing as validated RTSA sequential inference."
    )
    fallback_result <- try(rtsa_design_boundary_fallback(), silent = TRUE)
    if (inherits(fallback_result, "try-error")) {
      cumulative_z_note <- "Integrated RTSA(type='analysis') failed; fallback RTSA::ris + RTSA::boundaries also failed."
      ris_engine <- "not calculated: integrated RTSA analysis and fallback failed"
      ris_note <- "Validated TSA monitoring boundaries were not generated."
      boundary_engine <- "not drawn: integrated RTSA analysis and fallback failed"
      futility_note <- "not drawn"
      rtsa_error <- paste(
        "Integrated RTSA(type='analysis') failed:", primary_error,
        "Fallback RTSA::ris + RTSA::boundaries failed:", as.character(fallback_result)
      )
    } else {
      ris <- fallback_result$ris
      adjusted_ris <- fallback_result$adjusted_ris
      boundary_df <- fallback_result$boundary
      futility_df <- fallback_result$futility
      ris_engine <- paste("FALLBACK:", fallback_result$engine)
      ris_note <- paste("FALLBACK:", fallback_result$note)
      boundary_engine <- "FALLBACK: RTSA::boundaries Lan-DeMets O'Brien-Fleming alpha-spending"
      futility_note <- fallback_result$futility_note
      rtsa_error <- paste(
        "Primary RTSA(type='analysis') failed:", primary_error,
        "Used fallback RTSA::ris + RTSA::boundaries for the software-style TSA plot."
      )
    }
  }

  ## ---- Draw the TSA plot ----
  unlink(file.path(tsa_dir, c("Adjusted Boundaries Print.png", "Adjusted Boundaries Print.tiff")))
  if (nrow(boundary_df) > 0 && is.finite(adjusted_ris)) {
    rtsa_plot <- try({
      draw_tsa_software_style_plot(
        file.path(tsa_dir, "Adjusted Boundaries Print.png"), device = "png",
        boundary_df = boundary_df, futility_df = futility_df, adjusted_ris = adjusted_ris,
        cumulative_information = cumulative_information, cumulative_z = cumulative_z,
        eff_labels = eff_labels, tsa_alpha = tsa_alpha,
        tsa_favor_top = tsa_favor_top, tsa_favor_bottom = tsa_favor_bottom,
        plot_opts = tsa_plot_opts
      )
      draw_tsa_software_style_plot(
        file.path(tsa_dir, "Adjusted Boundaries Print.tiff"), device = "tiff",
        boundary_df = boundary_df, futility_df = futility_df, adjusted_ris = adjusted_ris,
        cumulative_information = cumulative_information, cumulative_z = cumulative_z,
        eff_labels = eff_labels, tsa_alpha = tsa_alpha,
        tsa_favor_top = tsa_favor_top, tsa_favor_bottom = tsa_favor_bottom,
        plot_opts = tsa_plot_opts
      )
      TRUE
    }, silent = TRUE)
    if (inherits(rtsa_plot, "try-error")) {
      while (dev.cur() > 1) dev.off()
      rtsa_error <- paste(ifelse(is.na(rtsa_error), "", rtsa_error),
                          "Software-style TSA plotting failed:", as.character(rtsa_plot))
    }
  }
  if (nrow(boundary_df) > 0 && is.finite(adjusted_ris) &&
      !file.exists(file.path(tsa_dir, "Adjusted Boundaries Print.png"))) {
    rtsa_error <- paste(
      ifelse(is.na(rtsa_error), "", rtsa_error),
      "Software-style TSA plotting did not produce Adjusted Boundaries Print.png."
    )
  }

  ## Save RTSA's native plot copy for audit when the integrated object exists.
  if (used_primary && !is.null(rtsa_obj)) {
    try({
      png(file = file.path(tsa_dir, paste0("RTSA_Native_", outcome, ".png")),
          width = 4000, height = 3000, res = 300)
      print(plot(rtsa_obj, model = if (random_model) "random" else "fixed", type = "classic"))
      dev.off()
    }, silent = TRUE)
    if (dev.cur() > 1) try(dev.off(), silent = TRUE)
  }

  if (!is.na(rtsa_error)) {
    writeLines(rtsa_error, con = file.path(tsa_dir, paste0("TSANotes", outcome, ".txt")))
  }

  ## ---- Save output files ----
  tsa_points <- data.frame(
    Study                 = eff_labels,
    CumulativeInformation = cumulative_information,
    CumulativeZ           = cumulative_z,
    stringsAsFactors      = FALSE
  )
  ris_out     <- if (is.finite(ris)) as.character(round(ris)) else "not calculated"
  adj_ris_out <- if (is.finite(adjusted_ris)) as.character(round(adjusted_ris)) else "not calculated"
  plot_generated <- file.exists(file.path(tsa_dir, "Adjusted Boundaries Print.png"))
  z_finite_count <- sum(is.finite(cumulative_z))
  z_status <- if (z_finite_count == length(cumulative_z) && z_finite_count > 0) {
    "complete"
  } else if (z_finite_count > 0) {
    paste("partial:", z_finite_count, "of", length(cumulative_z), "finite")
  } else {
    "missing"
  }
  boundary_status <- boundary_crossing_status(cumulative_information, cumulative_z, boundary_df)
  if (!used_primary && nrow(boundary_df) > 0) {
    boundary_status <- "not evaluated for fallback diagnostic output"
  }
  futility_status <- futility_boundary_status(cumulative_information, cumulative_z, futility_df)
  if (!used_primary && nrow(futility_df) > 0) {
    futility_status <- "not evaluated for fallback diagnostic output; non-binding boundaries informational only"
  }
  rtsa_inference_status <- if (used_primary) {
    "Integrated RTSA(type='analysis') results; Z-curve, information timing, RIS, and boundaries come from the RTSA analysis object"
  } else if (nrow(boundary_df) > 0) {
    "Fallback diagnostic only; Z-curve was not produced by RTSA(type='analysis') and is not directly comparable with RTSA::boundaries"
  } else {
    "No RTSA monitoring-boundary inference generated"
  }
  information_ratio <- if (is.finite(adjusted_ris) && adjusted_ris > 0 && length(cumulative_information)) {
    max(cumulative_information, na.rm = TRUE) / adjusted_ris
  } else {
    NA_real_
  }
  audit <- data.frame(
    Check = c("Plot generated", "Cumulative Z status", "Finite Z values", "Boundary rows",
              "Futility boundary rows", "Boundary assessment", "Futility assessment", "Final cumulative information",
              "Sequential adjusted RIS", "Final information / adjusted RIS", "RTSA engine",
              "Effect source actually used", "TSA suitability", "RTSA inference status",
              "TSA-adjusted CI status"),
    Value = c(as.character(plot_generated), z_status,
              paste(z_finite_count, "of", length(cumulative_z)),
              as.character(nrow(boundary_df)), as.character(nrow(futility_df)),
              boundary_status,
              futility_status,
              if (length(cumulative_information)) as.character(round(max(cumulative_information, na.rm = TRUE), 4)) else "NA",
              adj_ris_out,
              if (is.finite(information_ratio)) as.character(signif(information_ratio, 4)) else "NA",
              if (used_primary) "RTSA(type='analysis') integrated pipeline" else ris_engine,
              effective_tsa_effect_source,
              tsa_suitability,
              rtsa_inference_status,
              tsa_adj_ci_status),
    stringsAsFactors = FALSE
  )

  param_names <- c("Outcome", "Effect measure", "Alpha", "Power", "Effect source",
                    "TSA input data source",
                    "Anticipated effect note", "Anticipated effect (mc passed to RTSA)",
                    "Observed control event proportion", "Observed intervention event proportion",
                    "RIS input pC", "RIS input pT (derived)",
                    "RIS input incidence source",
                    "RTSA weights", "RTSA engine used", "TSA suitability",
                    "Required information size (fixed)", "Diversity adjusted",
                    "Sequential adjusted RIS (boundary denominator)", "Heterogeneity adjustment",
                    "RIS note", "Boundary engine", "Futility boundaries",
                    "Zero-event handling", "Study order", "Cumulative Z source",
                    "RTSA mc scale", "TSA Z display convention",
                    "RTSA inference status", "TSA-adjusted CI status",
                    "TSA plotted top favours", "TSA plotted bottom favours")
  param_values <- c(outcome, summary_measure, tsa_alpha, tsa_power, effective_tsa_effect_source,
                    rtsa_data_source,
                    anticipated_note, signif(mc_value, 4),
                    signif(pc_observed, 4), signif(pt_observed, 4),
                    signif(pc, 4),
                    if (exists("pt", inherits = FALSE)) signif(pt, 4) else "derived",
                    if (exists("incidence_note", inherits = FALSE)) incidence_note else "RTSA-computed internally",
                    rtsa_weights,
                    if (used_primary) "RTSA(type='analysis') integrated pipeline" else ris_engine,
                    tsa_suitability,
                    ris_out, tsa_adjust_for_diversity,
                    adj_ris_out,
                    if (tsa_adjust_for_diversity) "D2 (diversity)" else "tau2",
                    ris_note, boundary_engine, futility_note,
                    "Single-zero RR/OR studies use 0.5 continuity correction; double-zero RR/OR studies are excluded before the forest plot and TSA; RD keeps double-zero studies",
                    rtsa_order_source,
                    if (exists("cumulative_z_note", inherits = FALSE)) cumulative_z_note else "RTSA integrated analysis output",
                    if (summary_measure %in% c("RR", "OR")) "mc passed on natural ratio scale, not log scale" else "mc passed as absolute risk difference",
                    "Binary adjusted-boundaries plot displays -1 * RTSA/meta Z so the top/bottom favour labels match the selected clinical direction; raw CumulativeZ in CSV remains on the extracted engine scale.",
                    rtsa_inference_status,
                    tsa_adj_ci_status,
                    tsa_plot_opts$favor_top,
                    tsa_plot_opts$favor_bottom)
  param_names <- c(param_names, "TSA warning details")
  param_values <- c(param_values, tsa_warning_text)
  if (!is.null(tsa_adj_ci) &&
      is.numeric(tsa_adj_ci$lower) && is.finite(tsa_adj_ci$lower) &&
      is.numeric(tsa_adj_ci$upper) && is.finite(tsa_adj_ci$upper)) {
    param_names  <- c(param_names, "TSA-adjusted CI lower", "TSA-adjusted CI upper", "TSA-adjusted p-value")
    param_values <- c(param_values, signif(tsa_adj_ci$lower, 4),
                      signif(tsa_adj_ci$upper, 4),
                      if (is.numeric(tsa_adj_ci$p_value) && is.finite(tsa_adj_ci$p_value)) signif(tsa_adj_ci$p_value, 4) else "NA")
  }
  parameters <- data.frame(Parameter = param_names, Value = param_values, stringsAsFactors = FALSE)

  write.csv(tsa_points, file.path(tsa_dir, paste0("TSAZCurveData", outcome, ".csv")), row.names = FALSE)
  write.csv(boundary_df, file.path(tsa_dir, paste0("TSABoundaries", outcome, ".csv")), row.names = FALSE)
  write.csv(futility_df, file.path(tsa_dir, paste0("TSAFutilityBoundaries", outcome, ".csv")), row.names = FALSE)
  write.csv(parameters, file.path(tsa_dir, paste0("TSAParameters", outcome, ".csv")), row.names = FALSE)
  capture.output(parameters, file = file.path(tsa_dir, paste0("TSAParameters", outcome, ".txt")))
  write.csv(audit, file.path(tsa_dir, paste0("TSAAudit", outcome, ".csv")), row.names = FALSE)
  capture.output(audit, file = file.path(tsa_dir, paste0("TSAAudit", outcome, ".txt")))

  ## Save RTSA object for audit/re-analysis
  if (!is.null(rtsa_obj) && !inherits(rtsa_obj, "try-error")) {
    saveRDS(rtsa_obj, file = file.path(tsa_dir, paste0("RTSAObject", outcome, ".rds")))
  }
}

run_binary_tsa()
"""

_CONTINUOUS_TSA_R = r"""
run_continuous_tsa <- function() {
  tsa_dir <- file.path(output, paste0("TSA ", outcome))
  dir.create(tsa_dir, recursive = TRUE, showWarnings = FALSE)
  unlink(file.path(tsa_dir, paste0("TSANotes", outcome, ".txt")))
  tsa_plot_opts <- list(
    warning = "",
    z_sign = 1,
    favor_top = tsa_favor_top,
    favor_bottom = tsa_favor_bottom
  )

  if (m.cont$k < 2) {
    writeLines("Trial sequential analysis was skipped because at least two studies are required.",
               con = file.path(tsa_dir, paste0("TSANotes", outcome, ".txt")))
    return(invisible(NULL))
  }
  if (summary_measure == "SMD") {
    writeLines(c(
      "Trial sequential analysis was skipped because the selected continuous effect measure is SMD.",
      "The TSA guide states that continuous TSA software uses mean difference and that standardized mean difference does not work in TSA.",
      "Use MD for TSA when all studies are on the same scale/unit or can be converted to one common unit."
    ), con = file.path(tsa_dir, paste0("TSANotes", outcome, ".txt")))
    return(invisible(NULL))
  }
  if (tsa_adjust_for_diversity && !random_model) {
    writeLines(
      "Trial sequential analysis was skipped because D2 diversity adjustment requires a random-effects RTSA analysis.",
      con = file.path(tsa_dir, paste0("TSANotes", outcome, ".txt"))
    )
    return(invisible(NULL))
  }

  ## ---- Prepare RTSA-format data ----
  rtsa_data <- data.frame(
    study = as.character(m.cont$studlab),
    mI = as.numeric(m.cont$mean.e),
    sdI = as.numeric(m.cont$sd.e),
    nI = as.numeric(m.cont$n.e),
    mC = as.numeric(m.cont$mean.c),
    sdC = as.numeric(m.cont$sd.c),
    nC = as.numeric(m.cont$n.c),
    stringsAsFactors = FALSE
  )
  rtsa_data_source <- "meta object used for forest plot"
  rtsa_data <- add_analysis_row_order(rtsa_data, data)
  rtsa_order_source <- "Chronological publication year parsed from study label; no tied or missing years detected"
  tsa_order_warning <- ""
  explicit_order_col <- intersect(c("tsa_order", "order"), names(data))
  if (length(explicit_order_col)) {
    explicit_order_col <- explicit_order_col[1]
    order_lookup <- data.frame(
      study = as.character(data$Author),
      tsa_order_value = suppressWarnings(as.numeric(data[[explicit_order_col]])),
      stringsAsFactors = FALSE
    )
    order_lookup <- order_lookup[!duplicated(order_lookup$study), , drop = FALSE]
    order_idx <- match(rtsa_data$study, order_lookup$study)
    order_values <- order_lookup$tsa_order_value[order_idx]
    if (length(order_values) != nrow(rtsa_data) ||
        any(!is.finite(order_values)) ||
        any(duplicated(order_values))) {
      writeLines(
        c(
          paste0("Trial sequential analysis was skipped because the explicit ", explicit_order_col, " column was not a complete unique numeric study order."),
          "Provide one finite, unique order value for each study so RTSA receives an explicit cumulative sequence."
        ),
        con = file.path(tsa_dir, paste0("TSANotes", outcome, ".txt"))
      )
      return(invisible(NULL))
    }
    rtsa_data$tsa_order_value <- order_values
    rtsa_order_source <- paste("Explicit", explicit_order_col, "column in the analysis data (analyst-supplied cumulative sequence)")
  }
  rtsa_data$year <- extract_study_year(rtsa_data$study)
  if ("tsa_order_value" %in% names(rtsa_data)) {
    rtsa_data <- rtsa_data[order(rtsa_data$tsa_order_value, ifelse(is.na(rtsa_data$year), Inf, rtsa_data$year), rtsa_data$analysis_row_order, rtsa_data$study), ]
  } else {
    finite_year <- rtsa_data$year[is.finite(rtsa_data$year)]
    tied_years <- any(duplicated(finite_year))
    missing_years <- any(!is.finite(rtsa_data$year))
    if (missing_years) {
      rtsa_data <- rtsa_data[order(rtsa_data$analysis_row_order, rtsa_data$study), ]
      rtsa_order_source <- "Analyst-entered analysis-data row order used because chronological publication year could not be parsed for every study"
      tsa_order_warning <- paste(
        "TSA study order note: original TSA convention is study-sequential and usually chronological; at least one study label lacked a parseable publication year, so the cumulative sequence used the analyst-entered analysis-data row order.",
        "Add a numeric tsa_order or order column for a protocol-defined sequence."
      )
    } else if (tied_years) {
      rtsa_data <- rtsa_data[order(rtsa_data$year, rtsa_data$analysis_row_order, rtsa_data$study), ]
      rtsa_order_source <- "Chronological publication year parsed from study label; same-year ties resolved by analyst-entered analysis-data row order"
      tsa_order_warning <- paste(
        "TSA study order note: original TSA convention is study-sequential and usually chronological; multiple studies shared a publication year, so same-year ties were resolved by analyst-entered analysis-data row order.",
        "Add a numeric tsa_order or order column for a protocol-defined tie-breaker."
      )
    } else {
      rtsa_data <- rtsa_data[order(rtsa_data$year, rtsa_data$analysis_row_order, rtsa_data$study), ]
    }
  }
  rtsa_data$tsa_sequence <- seq_len(nrow(rtsa_data))
  rtsa_data_export <- rtsa_data
  first_cols <- c("tsa_sequence", "study", "year", "analysis_row_order", "tsa_order_value")
  rtsa_data_export <- rtsa_data_export[, c(first_cols[first_cols %in% names(rtsa_data_export)],
                                           setdiff(names(rtsa_data_export), first_cols)), drop = FALSE]
  write.csv(rtsa_data_export,
            file.path(tsa_dir, paste0("TSAAnalysisDataset", outcome, ".csv")),
            row.names = FALSE)
  rtsa_data$year <- NULL
  rtsa_data$analysis_row_order <- NULL
  rtsa_data$tsa_order_value <- NULL
  rtsa_data$tsa_sequence <- NULL
  complete_mask <- is.finite(rtsa_data$mI) & is.finite(rtsa_data$mC) &
                   is.finite(rtsa_data$sdI) & is.finite(rtsa_data$sdC) &
                   is.finite(rtsa_data$nI) & is.finite(rtsa_data$nC)
  rtsa_data <- rtsa_data[complete_mask, ]
  if (nrow(rtsa_data) != m.cont$k) {
    writeLines(
      paste("TSA input contains", nrow(rtsa_data), "complete rows but the forest-plot meta object contains", m.cont$k, "studies."),
      con = file.path(tsa_dir, paste0("TSANotes", outcome, ".txt"))
    )
  }
  if (nrow(rtsa_data) < 2) {
    writeLines("Trial sequential analysis was skipped: fewer than 2 complete studies.",
               con = file.path(tsa_dir, paste0("TSANotes", outcome, ".txt")))
    return(invisible(NULL))
  }
  tsa_warnings <- c()
  if (nzchar(tsa_order_warning)) tsa_warnings <- c(tsa_warnings, tsa_order_warning)
  i2_percent <- suppressWarnings(as.numeric(m.cont$I2))
  if (is.finite(i2_percent) && i2_percent <= 1) i2_percent <- i2_percent * 100
  if (nrow(rtsa_data) < 5) {
    tsa_warnings <- c(tsa_warnings, "RTSA input note: fewer than 5 cumulative looks were available.")
  } else if (nrow(rtsa_data) < 10) {
    tsa_warnings <- c(tsa_warnings, "RTSA input note: fewer than 10 cumulative looks were available.")
  }
  if (is.finite(i2_percent) && i2_percent >= 50 && !tsa_adjust_for_diversity) {
    tsa_warnings <- c(tsa_warnings, paste0("Observed I2 is ", signif(i2_percent, 4), "% and RTSA random_adj was set to tau2 rather than D2."))
  }

  ## ---- Determine mc (anticipated effect) and sd_mc ----
  pooled_te <- if (random_model && is.finite(m.cont$TE.random)) m.cont$TE.random else m.cont$TE.common
  effective_tsa_effect_source <- tsa_effect_source
  if (tsa_effect_source == "clinically_important" && is.finite(tsa_anticipated_effect)) {
    anticipated_delta <- abs(tsa_anticipated_effect)
    anticipated_note <- paste("clinically important", summary_measure, "=", signif(tsa_anticipated_effect, 4))
  } else {
    effective_tsa_effect_source <- "observed"
    anticipated_delta <- abs(pooled_te)
    anticipated_note <- paste("observed pooled", summary_measure, "=", signif(anticipated_delta, 4))
  }
  if (effective_tsa_effect_source == "observed") {
    tsa_warnings <- c(tsa_warnings, "The RTSA mc input was derived from the observed pooled effect.")
  }
  anticipated_delta <- max(anticipated_delta, 1e-6)

  pooled_sd <- NA_real_
  pooled_sd_note <- "sd_mc passed as NULL; RTSA(type='analysis') computes the MD sample-size SD internally"
  tsa_warnings <- unique(tsa_warnings)
  tsa_suitability <- if (any(grepl("fewer than 5 cumulative looks", tsa_warnings, ignore.case = TRUE))) {
    "Exploratory only: fewer than 5 cumulative looks recorded in RTSA input"
  } else if (any(grepl("observed pooled effect", tsa_warnings, ignore.case = TRUE))) {
    "Generated with RTSA input notes: observed-effect mc"
  } else if (length(tsa_warnings)) {
    "Generated with recorded RTSA input notes"
  } else {
    "Generated; no RTSA input notes detected"
  }
  tsa_warning_text <- if (length(tsa_warnings)) paste(tsa_warnings, collapse = " | ") else "None"
  if (length(tsa_warnings)) {
    writeLines(c("TSA interpretability warnings:", paste0("- ", tsa_warnings)),
               con = file.path(tsa_dir, paste0("TSAWarnings", outcome, ".txt")))
  }

  ## ---- Initialise result variables ----
  rtsa_obj        <- NULL
  rtsa_error      <- NA_character_
  ris             <- NA_real_
  adjusted_ris    <- NA_real_
  boundary_df     <- data.frame(Information = numeric(), UpperBoundary = numeric(), LowerBoundary = numeric())
  futility_df     <- data.frame(Information = numeric(), UpperFutility = numeric(), LowerFutility = numeric())
  cumulative_z    <- rep(NA_real_, nrow(rtsa_data))
  cumulative_information <- cumsum(rtsa_data$nI + rtsa_data$nC)
  rtsa_information_from_results <- numeric()
  eff_labels      <- as.character(rtsa_data$study)
  ris_engine      <- "not calculated"
  ris_note        <- ""
  boundary_engine <- "not drawn"
  futility_note   <- "none"
  tsa_adj_ci      <- NULL
  tsa_adj_ci_status <- "not computed: integrated RTSA(type='analysis') did not run"
  used_primary    <- FALSE
  cumulative_z_note <- ""

  if (!requireNamespace("RTSA", quietly = TRUE)) {
    rtsa_error <- "RTSA package is not installed. Install with: install.packages('RTSA')"
    writeLines(rtsa_error, con = file.path(tsa_dir, paste0("TSANotes", outcome, ".txt")))
    return(invisible(NULL))
  }

  if (is.finite(tsa_required_information_size)) {
    rtsa_obj <- structure(
      "Manual RIS override requested; continuous TSA needs integrated RTSA(type='analysis') for comparable Z-scores and monitoring boundaries, but integrated RTSA cannot replace its internally calculated RIS denominator.",
      class = "try-error"
    )
  } else {
    rtsa_obj <- try({
      RTSA::RTSA(
        type        = "analysis",
        data        = rtsa_data,
        outcome     = "MD",
        mc          = anticipated_delta,
        sd_mc       = NULL,
        side        = 2,
        alpha       = tsa_alpha,
        beta        = 1 - tsa_power,
        es_alpha    = "esOF",
        es_beta     = "esOF",
        futility    = "non-binding",
        fixed       = !random_model,
        random_adj  = if (tsa_adjust_for_diversity) "D2" else "tau2"
      )
    }, silent = TRUE)
  }

  if (!inherits(rtsa_obj, "try-error") && !is.null(rtsa_obj)) {
    used_primary    <- TRUE
    ris_engine      <- "RTSA(type='analysis') integrated pipeline"
    boundary_engine <- "RTSA Lan-DeMets O'Brien-Fleming alpha-spending"
    futility_note   <- "RTSA non-binding O'Brien-Fleming beta-spending futility boundaries"

    ris <- suppressWarnings(as.numeric(
      if (!is.null(rtsa_obj$results$RIS)) rtsa_obj$results$RIS else NA_real_
    ))
    adjusted_ris <- pick_best_ris(rtsa_obj$results)
    ris_note <- paste("RTSA sequential",
                      if (random_model) "heterogeneity-adjusted" else "fixed-effect",
                      "RIS =", if (is.finite(adjusted_ris)) round(adjusted_ris) else "NA")

    rdf <- rtsa_obj$results$results_df
    if (!is.null(rdf) && is.data.frame(rdf) && nrow(rdf) > 0 && is.finite(adjusted_ris)) {
      pick <- function(candidates) {
        hit <- candidates[candidates %in% names(rdf)]
        if (length(hit)) hit[1] else NA_character_
      }
      t_col  <- pick(c("sma_timing", "timing", "inf_frac"))
      u_col  <- pick(c("upper", "alpha_upper", "alpha_ubound"))
      l_col  <- pick(c("lower", "alpha_lower", "alpha_lbound"))
      z_col  <- pick(if (random_model) c("z_random", "z") else c("z_fixed", "z"))
      fu_col <- pick(c("fut_upper", "beta_upper", "beta_ubound"))
      fl_col <- pick(c("fut_lower", "beta_lower", "beta_lbound"))
      if (!is.na(t_col)) {
        rtsa_information_from_results <- suppressWarnings(as.numeric(rdf[[t_col]])) * adjusted_ris
      }

      if (!is.na(t_col) && !is.na(u_col)) {
        info  <- rtsa_information_from_results
        upper <- suppressWarnings(as.numeric(rdf[[u_col]]))
        lower <- if (!is.na(l_col)) suppressWarnings(as.numeric(rdf[[l_col]])) else -upper
        keep  <- is.finite(info) & is.finite(upper) & is.finite(lower)
        boundary_df <- data.frame(Information   = info[keep],
                                   UpperBoundary = upper[keep],
                                   LowerBoundary = lower[keep])
      }
      if (!is.na(z_col)) {
        cumulative_z <- suppressWarnings(as.numeric(rdf[[z_col]]))
      }
      if (!is.na(fu_col) && !is.na(fl_col) && !is.na(t_col)) {
        info <- rtsa_information_from_results
        fu   <- suppressWarnings(as.numeric(rdf[[fu_col]]))
        fl   <- suppressWarnings(as.numeric(rdf[[fl_col]]))
        kf   <- is.finite(info) & is.finite(fu) & is.finite(fl)
        if (any(kf)) {
          futility_df <- data.frame(Information   = info[kf],
                                     UpperFutility = fu[kf],
                                     LowerFutility = fl[kf])
          futility_note <- "RTSA beta-spending futility boundaries"
        }
      }
    }

    if (!is.null(rtsa_obj$settings$outcomes)) {
      sr <- rtsa_obj$settings$outcomes
      if (nrow(sr) == nrow(rtsa_data) && "n" %in% names(sr)) {
        cumulative_information <- cumsum(as.numeric(sr$n))
      }
  }
    if (length(cumulative_z) &&
        length(cumulative_information) != length(cumulative_z) &&
        length(rtsa_information_from_results) == length(cumulative_z)) {
      cumulative_information <- rtsa_information_from_results
    }
    if (length(cumulative_z) && length(eff_labels) != length(cumulative_z)) {
      eff_labels <- paste("Look", seq_along(cumulative_z))
    }

    if (length(cumulative_z) != nrow(rtsa_data) || any(!is.finite(cumulative_z))) {
      cumulative_z_note <- "RTSA(type='analysis') did not return a complete cumulative Z-score vector; no substitute Z-curve was calculated."
    }

    ## Extract TSA-adjusted CI (key output for GRADE imprecision)
    ## RTSA's seq_inf list has $lower, $upper, $p.value — these can be NULL
    ## when uniroot fails to converge.
    if (!is.null(rtsa_obj$results$seq_inf)) {
      si <- rtsa_obj$results$seq_inf
      si_lower <- suppressWarnings(as.numeric(si$lower))
      si_upper <- suppressWarnings(as.numeric(si$upper))
      si_pval  <- suppressWarnings(as.numeric(si$p.value))
      if (length(si_lower) > 0 && length(si_upper) > 0 &&
          is.finite(si_lower[1]) && is.finite(si_upper[1])) {
        ci_bounds <- sorted_ci_bounds(si_lower[1], si_upper[1])
        if (!is.null(ci_bounds)) {
          tsa_adj_ci <- list(
            lower   = ci_bounds[1],
            upper   = ci_bounds[2],
            p_value = if (length(si_pval) > 0 && is.finite(si_pval[1])) si_pval[1] else NA_real_
          )
          tsa_adj_ci_status <- "available from RTSA seq_inf"
        }
      }
      if (is.null(tsa_adj_ci)) {
        tsa_adj_ci_status <- "RTSA seq_inf returned without finite CI bounds"
      }
    } else {
      tsa_adj_ci_status <- "RTSA seq_inf was NULL"
    }

    if (!nzchar(cumulative_z_note)) {
      cumulative_z_note <- paste0("RTSA(type='analysis') integrated Z-scores from results_df (DL_HKSJ); ",
                                  "consistent with monitoring boundaries")
    }

  } else {
    primary_error <- if (inherits(rtsa_obj, "try-error")) as.character(rtsa_obj) else "Returned NULL"
    incidence_note <- "Continuous outcome; no incidence computed"
    cumulative_z_note <- "Integrated RTSA(type='analysis') failed; no cumulative Z-curve or monitoring boundaries were generated."
    ris_engine <- "not calculated: integrated RTSA analysis failed"
    ris_note <- "Integrated RTSA(type='analysis') failed; TSA software-equivalent monitoring boundaries were not generated."
    boundary_engine <- "not drawn: integrated RTSA analysis failed"
    futility_note <- "not drawn"
    rtsa_error <- paste(
      "Integrated RTSA(type='analysis') failed:", primary_error,
      "No substitute TSA calculations were performed."
    )
  }

  unlink(file.path(tsa_dir, c("Adjusted Boundaries Print.png", "Adjusted Boundaries Print.tiff")))
  if (nrow(boundary_df) > 0 && is.finite(adjusted_ris)) {
    rtsa_plot <- try({
      draw_tsa_software_style_plot(
        file.path(tsa_dir, "Adjusted Boundaries Print.png"), device = "png",
        boundary_df = boundary_df, futility_df = futility_df, adjusted_ris = adjusted_ris,
        cumulative_information = cumulative_information, cumulative_z = cumulative_z,
        eff_labels = eff_labels, tsa_alpha = tsa_alpha,
        tsa_favor_top = tsa_favor_top, tsa_favor_bottom = tsa_favor_bottom,
        plot_opts = tsa_plot_opts
      )
      draw_tsa_software_style_plot(
        file.path(tsa_dir, "Adjusted Boundaries Print.tiff"), device = "tiff",
        boundary_df = boundary_df, futility_df = futility_df, adjusted_ris = adjusted_ris,
        cumulative_information = cumulative_information, cumulative_z = cumulative_z,
        eff_labels = eff_labels, tsa_alpha = tsa_alpha,
        tsa_favor_top = tsa_favor_top, tsa_favor_bottom = tsa_favor_bottom,
        plot_opts = tsa_plot_opts
      )
      TRUE
    }, silent = TRUE)
    if (inherits(rtsa_plot, "try-error")) {
      while (dev.cur() > 1) dev.off()
      rtsa_error <- paste(ifelse(is.na(rtsa_error), "", rtsa_error),
                          "Software-style TSA plotting failed:", as.character(rtsa_plot))
    }
  }
  if (nrow(boundary_df) > 0 && is.finite(adjusted_ris) &&
      !file.exists(file.path(tsa_dir, "Adjusted Boundaries Print.png"))) {
    rtsa_error <- paste(
      ifelse(is.na(rtsa_error), "", rtsa_error),
      "Software-style TSA plotting did not produce Adjusted Boundaries Print.png."
    )
  }

  if (used_primary && !is.null(rtsa_obj)) {
    try({
      png(file = file.path(tsa_dir, paste0("RTSA_Native_", outcome, ".png")),
          width = 4000, height = 3000, res = 300)
      print(plot(rtsa_obj, model = if (random_model) "random" else "fixed", type = "classic"))
      dev.off()
    }, silent = TRUE)
    if (dev.cur() > 1) try(dev.off(), silent = TRUE)
  }

  if (!is.na(rtsa_error)) {
    writeLines(rtsa_error, con = file.path(tsa_dir, paste0("TSANotes", outcome, ".txt")))
  }

  tsa_points <- data.frame(
    Study                 = eff_labels,
    CumulativeInformation = cumulative_information,
    CumulativeZ           = cumulative_z,
    stringsAsFactors      = FALSE
  )
  ris_out     <- if (is.finite(ris)) as.character(round(ris)) else "not calculated"
  adj_ris_out <- if (is.finite(adjusted_ris)) as.character(round(adjusted_ris)) else "not calculated"
  plot_generated <- file.exists(file.path(tsa_dir, "Adjusted Boundaries Print.png"))
  z_finite_count <- sum(is.finite(cumulative_z))
  z_status <- if (z_finite_count == length(cumulative_z) && z_finite_count > 0) {
    "complete"
  } else if (z_finite_count > 0) {
    paste("partial:", z_finite_count, "of", length(cumulative_z), "finite")
  } else {
    "missing"
  }
  boundary_status <- boundary_crossing_status(cumulative_information, cumulative_z, boundary_df)
  futility_status <- futility_boundary_status(cumulative_information, cumulative_z, futility_df)
  rtsa_inference_status <- if (used_primary) {
    "Integrated RTSA(type='analysis') results; Z-curve, information timing, RIS, and boundaries come from the RTSA analysis object"
  } else {
    "No RTSA monitoring-boundary inference generated"
  }
  information_ratio <- if (is.finite(adjusted_ris) && adjusted_ris > 0 && length(cumulative_information)) {
    max(cumulative_information, na.rm = TRUE) / adjusted_ris
  } else {
    NA_real_
  }
  audit <- data.frame(
    Check = c("Plot generated", "Cumulative Z status", "Finite Z values", "Boundary rows",
              "Futility boundary rows", "Boundary assessment", "Futility assessment", "Final cumulative information",
              "Sequential adjusted RIS", "Final information / adjusted RIS", "RTSA engine",
              "Effect source actually used", "TSA suitability", "RTSA inference status",
              "TSA-adjusted CI status"),
    Value = c(as.character(plot_generated), z_status,
              paste(z_finite_count, "of", length(cumulative_z)),
              as.character(nrow(boundary_df)), as.character(nrow(futility_df)),
              boundary_status,
              futility_status,
              if (length(cumulative_information)) as.character(round(max(cumulative_information, na.rm = TRUE), 4)) else "NA",
              adj_ris_out,
              if (is.finite(information_ratio)) as.character(signif(information_ratio, 4)) else "NA",
              if (used_primary) "RTSA(type='analysis') integrated pipeline" else ris_engine,
              effective_tsa_effect_source,
              tsa_suitability,
              rtsa_inference_status,
              tsa_adj_ci_status),
    stringsAsFactors = FALSE
  )

  param_names <- c("Outcome", "Effect measure", "Alpha", "Power", "Effect source",
                    "TSA input data source",
                    "Anticipated effect note", "Anticipated effect (mc passed to RTSA)",
                    "RTSA sd_mc input", "RTSA sd_mc source",
                    "RTSA engine used", "TSA suitability",
                    "Required information size (fixed)", "Diversity adjusted",
                    "Sequential adjusted RIS (boundary denominator)", "Heterogeneity adjustment",
                    "RIS note", "Boundary engine", "Futility boundaries",
                    "Study order", "Continuous information scale", "Cumulative Z source",
                    "RTSA inference status", "TSA-adjusted CI status",
                    "TSA top favours", "TSA bottom favours")
  param_values <- c(outcome, summary_measure, tsa_alpha, tsa_power, effective_tsa_effect_source,
                    rtsa_data_source,
                    anticipated_note, signif(anticipated_delta, 4),
                    "NULL", pooled_sd_note,
                    if (used_primary) "RTSA(type='analysis') integrated pipeline" else ris_engine,
                    tsa_suitability,
                    ris_out, tsa_adjust_for_diversity,
                    adj_ris_out,
                    if (tsa_adjust_for_diversity) "D2 (diversity)" else "tau2",
                    ris_note, boundary_engine, futility_note,
                    rtsa_order_source,
                    "RTSA(type='analysis') timing extracted from RTSA results when available; otherwise cumulative nI + nC is recorded for audit",
                    if (exists("cumulative_z_note", inherits = FALSE)) cumulative_z_note else "RTSA integrated analysis output",
                    rtsa_inference_status,
                    tsa_adj_ci_status,
                    tsa_favor_top, tsa_favor_bottom)
  param_names <- c(param_names, "TSA warning details")
  param_values <- c(param_values, tsa_warning_text)
  if (!is.null(tsa_adj_ci) &&
      is.numeric(tsa_adj_ci$lower) && is.finite(tsa_adj_ci$lower) &&
      is.numeric(tsa_adj_ci$upper) && is.finite(tsa_adj_ci$upper)) {
    param_names  <- c(param_names, "TSA-adjusted CI lower", "TSA-adjusted CI upper", "TSA-adjusted p-value")
    param_values <- c(param_values, signif(tsa_adj_ci$lower, 4),
                      signif(tsa_adj_ci$upper, 4),
                      if (is.numeric(tsa_adj_ci$p_value) && is.finite(tsa_adj_ci$p_value)) signif(tsa_adj_ci$p_value, 4) else "NA")
  }
  parameters <- data.frame(Parameter = param_names, Value = param_values, stringsAsFactors = FALSE)

  write.csv(tsa_points, file.path(tsa_dir, paste0("TSAZCurveData", outcome, ".csv")), row.names = FALSE)
  write.csv(boundary_df, file.path(tsa_dir, paste0("TSABoundaries", outcome, ".csv")), row.names = FALSE)
  write.csv(futility_df, file.path(tsa_dir, paste0("TSAFutilityBoundaries", outcome, ".csv")), row.names = FALSE)
  write.csv(parameters, file.path(tsa_dir, paste0("TSAParameters", outcome, ".csv")), row.names = FALSE)
  capture.output(parameters, file = file.path(tsa_dir, paste0("TSAParameters", outcome, ".txt")))
  write.csv(audit, file.path(tsa_dir, paste0("TSAAudit", outcome, ".csv")), row.names = FALSE)
  capture.output(audit, file = file.path(tsa_dir, paste0("TSAAudit", outcome, ".txt")))

  if (!is.null(rtsa_obj) && !inherits(rtsa_obj, "try-error")) {
    saveRDS(rtsa_obj, file = file.path(tsa_dir, paste0("RTSAObject", outcome, ".rds")))
  }
}
run_continuous_tsa()
"""


def binary_tsa_r_code() -> str:
    """The active TSA engine is now the external Python RTSA wrapper."""
    return ""


def continuous_tsa_r_code() -> str:
    """The active TSA engine is now the external Python RTSA wrapper."""
    return ""
