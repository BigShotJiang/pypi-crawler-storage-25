import sys
from pathlib import Path

import docx


if len(sys.argv) < 2:
    raise SystemExit("Usage: python extract_docx.py /path/to/manuscript.docx")

file_path = Path(sys.argv[1]).expanduser()
doc = docx.Document(file_path)

start_printing = False
printed_count = 0

for p in doc.paragraphs:
    text = p.text.strip()
    if not text:
        continue
    
    # Look for the start of the meta-analysis results
    if any(header in text for header in ['3.2.', '3.3.', 'Primary Outcome', 'Secondary Outcome']):
        start_printing = True
    
    if start_printing:
        print(text)
        print("-" * 20)
        printed_count += 1
        if printed_count > 40:
            break
