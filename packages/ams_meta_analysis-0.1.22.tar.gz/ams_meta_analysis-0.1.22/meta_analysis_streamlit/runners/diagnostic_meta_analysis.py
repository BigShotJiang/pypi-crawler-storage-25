#!/usr/bin/env python3
"""Run diagnostic test accuracy meta-analysis from Excel through R.

This runner mirrors the binary and continuous outcome wrappers in this folder:
Python reads the workbook, identifies and validates columns, writes a clean CSV
and a generated R script, then R performs the diagnostic meta-analysis.

Supported modes:
  * single: one diagnostic test, using TP/FP/TN/FN study-level counts.
  * comparative: two diagnostic tests in one combined sheet, distinguished by a
    test/category column, or two separate sheets supplied with --test-a-sheet and
    --test-b-sheet.
"""

from __future__ import annotations

import argparse
import json
import math
import re
import shutil
import sys
import tempfile
import textwrap
import urllib.error
import urllib.request
from pathlib import Path
from typing import Any

import pandas as pd

import binary_outcome as common


REQUIRED_FIELDS = ["study_label", "tp", "fp", "tn", "fn"]
OPTIONAL_FIELDS = ["test_group", "study_id", "subgroup", "covariate"]
FIELD_LABELS = {
    "study_label": "Study label / Author",
    "tp": "True positives (TP)",
    "fp": "False positives (FP)",
    "tn": "True negatives (TN)",
    "fn": "False negatives (FN)",
    "test_group": "Diagnostic test / category column",
    "study_id": "Paired study ID for comparative analysis",
    "subgroup": "Subgroup column",
    "covariate": "Meta-regression covariate",
}


def default_mapping(columns: list[str], mode: str) -> dict[str, Any]:
    normalized = {common.normalize_name(col): col for col in columns}
    candidates = {
        "study_label": ["author", "authors", "name", "names", "study", "studlab", "studyid", "trial"],
        "tp": ["tp", "truepositive", "truepositives"],
        "fp": ["fp", "falsepositive", "falsepositives"],
        "tn": ["tn", "truenegative", "truenegatives"],
        "fn": ["fn", "falsenegative", "falsenegatives"],
        "test_group": ["category1", "category", "test", "testtype", "modality", "indextest", "group"],
        "study_id": ["id", "recordid", "studyid", "pairid"],
        "subgroup": ["subgroup", "group", "strata", "category", "region"],
        "covariate": ["covariate", "moderator", "year", "threshold"],
    }
    mapping: dict[str, Any] = {
        "mode": mode,
        "sheet_name": None,
        "outcome_name": "diagnostic accuracy",
        "test_a_label": "Test A",
        "test_b_label": "Test B",
        "columns": {},
        "analysis": {
            "model_type": "random",
            "model_type_reason": "Random-effects is the default for diagnostic accuracy meta-analysis because thresholds, case-mix, and study design commonly vary.",
            "primary_metric": "sensitivity_specificity_sroc",
            "primary_metric_reason": "Diagnostic accuracy should primarily be summarized with pooled sensitivity, pooled specificity, and a bivariate SROC model.",
            "dor_analysis": True,
            "dor_analysis_reason": "Diagnostic odds ratio is included for funnel/Deeks testing, but it should not replace sensitivity/specificity interpretation.",
        },
        "confidence": 0.0,
        "notes": "Heuristic mapping; confirm before running.",
    }
    for field, names in candidates.items():
        for candidate in names:
            if candidate in normalized:
                mapping["columns"][field] = normalized[candidate]
                break
    if mode == "single":
        mapping["columns"].pop("test_group", None)
    return mapping


def call_lmstudio(
    summary: dict[str, Any],
    mode: str,
    lmstudio_url: str,
    model: str | None,
) -> dict[str, Any] | None:
    model = common.resolve_lmstudio_model(lmstudio_url, model)
    if not model:
        return None

    prompt = {
        "task": (
            "Identify columns for diagnostic test accuracy meta-analysis. "
            "The data use study-level 2x2 diagnostic counts: TP, FP, TN, FN. "
            "For comparative mode, identify the column that indicates diagnostic test group/category "
            "and an optional paired study ID."
        ),
        "mode": mode,
        "required_columns": {
            "study_label": "study name, author, trial label, or citation",
            "tp": "true positives",
            "fp": "false positives",
            "tn": "true negatives",
            "fn": "false negatives",
        },
        "optional_columns": {
            "test_group": "diagnostic test category/modality for comparative mode",
            "study_id": "paired study ID for direct comparative GLMM, if present",
            "subgroup": "clinically meaningful subgroup column, if present",
            "covariate": "numeric moderator or threshold column, if present",
        },
        "analysis_choices": {
            "model_type": "random or common; random is usually preferred for diagnostic accuracy",
        },
        "rules": [
            "Return exact column names as they appear in the workbook.",
            "Do not invent columns.",
            "Diagnostic counts must map to TP, FP, TN, and FN.",
            "For comparative mode, choose a categorical test/modality column when present.",
            "Use random-effects by default because threshold effects and case-mix heterogeneity are common.",
        ],
        "workbook": summary,
        "return_json_schema": {
            "sheet_name": "string",
            "outcome_name": "string",
            "test_a_label": "string",
            "test_b_label": "string",
            "columns": {field: "string or null" for field in REQUIRED_FIELDS + OPTIONAL_FIELDS},
            "analysis": {
                "model_type": "random or common",
                "model_type_reason": "short string",
            },
            "confidence": "number from 0 to 1",
            "notes": "short string",
        },
    }
    body = {
        "model": model,
        "messages": [
            {
                "role": "system",
                "content": "You map clinical diagnostic accuracy Excel columns to a strict TP/FP/TN/FN schema. Return only valid JSON.",
            },
            {"role": "user", "content": json.dumps(prompt, default=str)},
        ],
        "temperature": 0,
    }
    request = urllib.request.Request(
        common.chat_completions_url(lmstudio_url),
        data=json.dumps(body).encode("utf-8"),
        headers=common.llm_request_headers(include_content_type=True),
        method="POST",
    )
    try:
        with urllib.request.urlopen(request) as response:
            payload = json.loads(response.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        print(f"LMStudio request failed ({common.lmstudio_error_message(exc)}). Falling back to name matching.")
        return None
    except Exception as exc:
        print(f"LMStudio request failed ({exc}). Falling back to name matching.")
        return None
    content = payload["choices"][0]["message"]["content"]
    try:
        return json.loads(content)
    except json.JSONDecodeError:
        match = re.search(r"\{.*\}", content, flags=re.S)
        if match:
            return json.loads(match.group(0))
        print("LMStudio did not return valid JSON. Falling back to name matching.")
        return None


def normalize_analysis(analysis: dict[str, Any], mapping: dict[str, Any]) -> dict[str, Any]:
    prior = mapping.get("analysis", {})
    model_raw = str(analysis.get("model_type") or prior.get("model_type") or "random").lower()
    model_type = "common" if model_raw in {"common", "fixed", "fixed-effect", "fixed effect"} else "random"
    return {
        "model_type": model_type,
        "model_type_reason": str(
            analysis.get("model_type_reason")
            or prior.get("model_type_reason")
            or "Random-effects is preferred when diagnostic thresholds, spectrum, or methods differ across studies."
        ),
        "primary_metric": "sensitivity_specificity_sroc",
        "primary_metric_reason": str(
            analysis.get("primary_metric_reason")
            or prior.get("primary_metric_reason")
            or "Diagnostic accuracy should be interpreted using sensitivity, specificity, and SROC results."
        ),
        "dor_analysis": common.normalize_bool(analysis.get("dor_analysis", prior.get("dor_analysis")), True),
        "dor_analysis_reason": str(
            analysis.get("dor_analysis_reason")
            or prior.get("dor_analysis_reason")
            or "DOR is a useful single-number diagnostic accuracy summary, but it can hide sensitivity/specificity tradeoffs."
        ),
    }


def merge_mapping(columns: list[str], sheet_name: str, mode: str, lm_mapping: dict[str, Any] | None, outcome: str | None) -> dict[str, Any]:
    mapping = default_mapping(columns, mode)
    mapping["sheet_name"] = sheet_name
    if lm_mapping:
        mapping.update({key: value for key, value in lm_mapping.items() if key not in {"columns"} and value})
        mapping["mode"] = mode
        mapping["sheet_name"] = sheet_name
        for field, col in (lm_mapping.get("columns") or {}).items():
            if col in columns:
                mapping["columns"][field] = col
            elif col in ("", None):
                mapping["columns"].pop(field, None)
    if outcome:
        mapping["outcome_name"] = outcome
    mapping["analysis"] = normalize_analysis(mapping.get("analysis") or {}, mapping)
    return mapping


def print_mapping(mapping: dict[str, Any], columns: list[str]) -> None:
    print("\nIdentified diagnostic meta-analysis mapping")
    print("-------------------------------------------")
    print(f"Mode: {mapping.get('mode')}")
    print(f"Sheet: {mapping.get('sheet_name')}")
    print(f"Outcome name: {mapping.get('outcome_name')}")
    if mapping.get("mode") == "comparative":
        print(f"Test A label: {mapping.get('test_a_label')}")
        print(f"Test B label: {mapping.get('test_b_label')}")
    print("\nColumns:")
    fields = REQUIRED_FIELDS + (OPTIONAL_FIELDS if mapping.get("mode") == "comparative" else ["subgroup", "covariate"])
    for field in fields:
        print(f"  {FIELD_LABELS[field]}: {common.format_column_choice(mapping.get('columns', {}).get(field), columns)}")
    print("\nAvailable columns")
    print("-----------------")
    for index, column in enumerate(columns, start=1):
        print(f"{index}. {column}")
    analysis = normalize_analysis(mapping.get("analysis") or {}, mapping)
    print("\nAnalysis choices:")
    print(f"  Primary analysis: pooled sensitivity, pooled specificity, bivariate SROC")
    print(f"    Why: {analysis['primary_metric_reason']}")
    print(f"  Statistical model: {analysis['model_type']} ({'Random-effects' if analysis['model_type'] == 'random' else 'Common/fixed-effect'})")
    print(f"    Why: {analysis['model_type_reason']}")
    print(f"  DOR analysis: {'yes' if analysis['dor_analysis'] else 'no'}")
    print(f"    Why: {analysis['dor_analysis_reason']}")
    if mapping.get("notes"):
        print(f"Notes: {mapping['notes']}")


def prompt_for_mapping(mapping: dict[str, Any], columns: list[str], assume_yes: bool) -> dict[str, Any]:
    print_mapping(mapping, columns)
    if assume_yes or not sys.stdin.isatty():
        return mapping
    missing = [field for field in REQUIRED_FIELDS if not mapping.get("columns", {}).get(field)]
    if missing:
        print("\nRequired fields are missing: " + ", ".join(FIELD_LABELS[field] for field in missing))
    else:
        correct = input("\nAre these identified columns correct? [Y/n]: ").strip().lower()
        if correct not in {"n", "no"}:
            return mapping

    print("\nType a column number to replace a value, press Enter to keep it, or type 0 for none.")
    mapping["outcome_name"] = input(f"Outcome name [{mapping.get('outcome_name')}]: ").strip() or mapping.get("outcome_name")
    if mapping.get("mode") == "comparative":
        mapping["test_a_label"] = input(f"Test A label [{mapping.get('test_a_label')}]: ").strip() or mapping.get("test_a_label")
        mapping["test_b_label"] = input(f"Test B label [{mapping.get('test_b_label')}]: ").strip() or mapping.get("test_b_label")
    fields = REQUIRED_FIELDS + OPTIONAL_FIELDS
    for field in fields:
        if mapping.get("mode") == "single" and field in {"test_group", "study_id"}:
            continue
        current = mapping.get("columns", {}).get(field) or ""
        value = input(f"{FIELD_LABELS[field]} column [{common.format_column_choice(current, columns)}]: ").strip()
        if value:
            resolved = common.resolve_column_choice(value, columns)
            if resolved is None:
                mapping["columns"].pop(field, None)
            else:
                mapping["columns"][field] = resolved
    return mapping


def prompt_for_analysis_choices(analysis: dict[str, Any], assume_yes: bool) -> dict[str, Any]:
    if assume_yes or not sys.stdin.isatty():
        return analysis
    print("\nChosen diagnostic analysis")
    print("--------------------------")
    print(f"Model: {analysis['model_type']}")
    correct = input("Are these analysis choices correct? [Y/n]: ").strip().lower()
    if correct not in {"n", "no"}:
        return analysis
    model_value = input(f"Statistical model [random/common; {analysis['model_type']}]: ").strip().lower()
    if model_value:
        if model_value not in {"random", "common", "fixed"}:
            raise SystemExit("Model must be random, common, or fixed.")
        analysis["model_type"] = "common" if model_value in {"common", "fixed"} else "random"
        analysis["model_type_reason"] = "Manually selected by user."
    return analysis


def clean_label_series(series: pd.Series) -> pd.Series:
    labels = series.astype("string").str.strip()
    return labels.mask(labels.str.lower().isin({"", "nan", "none", "null"}).fillna(False))


def validate_data(df: pd.DataFrame, mapping: dict[str, Any], test_label: str | None = None) -> pd.DataFrame:
    missing = [field for field in REQUIRED_FIELDS if not mapping.get("columns", {}).get(field)]
    if missing:
        raise SystemExit("Missing required mapping: " + ", ".join(FIELD_LABELS[field] for field in missing))
    r_df = pd.DataFrame()
    r_df["Author"] = clean_label_series(df[mapping["columns"]["study_label"]])
    for field, output_col in [("tp", "TP"), ("fp", "FP"), ("tn", "TN"), ("fn", "FN")]:
        r_df[output_col] = pd.to_numeric(df[mapping["columns"][field]], errors="coerce")
    if test_label is not None:
        r_df["TestGroup"] = test_label
    elif mapping.get("mode") == "comparative" and mapping.get("columns", {}).get("test_group"):
        r_df["TestGroup"] = clean_label_series(df[mapping["columns"]["test_group"]])
    if mapping.get("mode") == "comparative":
        study_id_col = mapping.get("columns", {}).get("study_id")
        if study_id_col:
            r_df["StudyID"] = clean_label_series(df[study_id_col])
        else:
            r_df["StudyID"] = r_df["Author"]
    subgroup_col = mapping.get("columns", {}).get("subgroup")
    if subgroup_col:
        r_df["Subgroup"] = clean_label_series(df[subgroup_col])
    covariate_col = mapping.get("columns", {}).get("covariate")
    if covariate_col:
        r_df["Covariate"] = pd.to_numeric(df[covariate_col], errors="coerce")

    r_df = r_df.dropna(subset=["Author", "TP", "FP", "TN", "FN"]).copy()
    for col in ["TP", "FP", "TN", "FN"]:
        r_df[col] = pd.to_numeric(r_df[col], errors="coerce")
    finite_counts = r_df[["TP", "FP", "TN", "FN"]].apply(lambda column: column.map(math.isfinite))
    if not finite_counts.all().all():
        raise SystemExit("Invalid diagnostic data: TP/FP/TN/FN counts must be finite numbers.")
    whole_counts = (r_df[["TP", "FP", "TN", "FN"]].round() - r_df[["TP", "FP", "TN", "FN"]]).abs() <= 1e-8
    if not whole_counts.all().all():
        raise SystemExit("Invalid diagnostic data: TP/FP/TN/FN counts must be whole numbers.")
    invalid = r_df[(r_df[["TP", "FP", "TN", "FN"]] < 0).any(axis=1)]
    if not invalid.empty:
        raise SystemExit("Invalid diagnostic data: TP/FP/TN/FN counts must be nonnegative.")
    diseased = r_df["TP"] + r_df["FN"]
    non_diseased = r_df["TN"] + r_df["FP"]
    if ((diseased <= 0) | (non_diseased <= 0)).any():
        raise SystemExit("Invalid diagnostic data: each row needs TP+FN > 0 and TN+FP > 0.")
    if r_df.empty:
        raise SystemExit("No complete diagnostic rows remained after validation.")
    if mapping.get("mode") == "comparative":
        if "TestGroup" not in r_df.columns:
            raise SystemExit("Comparative mode requires a test/category column or --test-a-sheet and --test-b-sheet.")
        groups = [group for group in r_df["TestGroup"].dropna().astype(str).unique() if group]
        if len(groups) < 2:
            raise SystemExit("Comparative mode requires at least two diagnostic test groups.")
        if len(groups) > 2:
            raise SystemExit(
                "Comparative mode supports exactly two diagnostic test groups per run. "
                f"Found {len(groups)} groups: {', '.join(groups)}"
            )
    r_df["Author"] = common.make_unique_study_labels(r_df["Author"].astype(str))
    return r_df


def show_extracted_data(r_df: pd.DataFrame, preview_rows: int, assume_yes: bool, extracted_path: Path) -> None:
    r_df.to_csv(extracted_path, index=False)
    print("\nExtracted diagnostic analysis data")
    print("----------------------------------")
    print(f"Rows extracted: {len(r_df)}")
    print(f"Saved copy: {extracted_path}")
    with pd.option_context("display.max_columns", None, "display.width", 180):
        print(r_df.head(preview_rows).to_string(index=False))
    if len(r_df) > preview_rows:
        print(f"... {len(r_df) - preview_rows} more rows not shown.")
    if assume_yes or not sys.stdin.isatty():
        return
    if input("Run R diagnostic meta-analysis with this extracted data? [Y/n]: ").strip().lower() in {"n", "no"}:
        raise SystemExit("Stopped before running R.")


def write_r_script(
    script_path: Path,
    csv_path: Path,
    output_dir: Path,
    mapping: dict[str, Any],
) -> None:
    analysis = normalize_analysis(mapping.get("analysis") or {}, mapping)
    replacements = {
        "__CSV__": common.r_string(str(csv_path)),
        "__OUTPUT__": common.r_string(str(output_dir)),
        "__OUTCOME__": common.r_string(str(mapping.get("outcome_name") or "diagnostic accuracy")),
        "__MODE__": common.r_string(str(mapping.get("mode") or "single")),
        "__MODEL_TYPE__": common.r_string(str(analysis["model_type"])),
        "__TEST_A_LABEL__": common.r_string(str(mapping.get("test_a_label") or "Test A")),
        "__TEST_B_LABEL__": common.r_string(str(mapping.get("test_b_label") or "Test B")),
    }
    script = r'''
suppressPackageStartupMessages(library(meta))

output <- __OUTPUT__
outcome <- __OUTCOME__
mode <- __MODE__
model_type <- __MODEL_TYPE__
random_model <- model_type == "random"
common_model <- model_type == "common"
test_a_label <- __TEST_A_LABEL__
test_b_label <- __TEST_B_LABEL__
dir.create(output, recursive = TRUE, showWarnings = FALSE)

data <- read.csv(__CSV__, check.names = FALSE)
for (col in c("TP", "FP", "TN", "FN")) {
  data[[col]] <- suppressWarnings(as.numeric(data[[col]]))
}
data$Author <- as.character(data$Author)
if (!"TestGroup" %in% names(data)) data$TestGroup <- "Index test"
if (!"StudyID" %in% names(data)) data$StudyID <- data$Author

need_mada <- function() {
  if (!requireNamespace("mada", quietly = TRUE)) {
    return(FALSE)
  }
  TRUE
}

safe_name <- function(x) {
  x <- gsub("[^A-Za-z0-9._ -]+", "_", x)
  x <- trimws(x)
  ifelse(nchar(x) > 0, x, "diagnostic")
}

logit_safe <- function(p) {
  p <- pmin(pmax(p, 1e-6), 1 - 1e-6)
  log(p / (1 - p))
}

diagnostic_table <- function(df) {
  out <- data.frame(
    Author = df$Author,
    TP = df$TP,
    FP = df$FP,
    FN = df$FN,
    TN = df$TN,
    Diseased = df$TP + df$FN,
    NonDiseased = df$TN + df$FP,
    Sensitivity = df$TP / (df$TP + df$FN),
    Specificity = df$TN / (df$TN + df$FP),
    FalsePositiveRate = df$FP / (df$TN + df$FP),
    DOR = (df$TP * df$TN) / pmax(df$FP * df$FN, .Machine$double.eps),
    stringsAsFactors = FALSE
  )
  out
}

make_mada_data <- function(df) {
  mada_df <- data.frame(
    TP = df$TP,
    FN = df$FN,
    FP = df$FP,
    TN = df$TN,
    names = df$Author,
    stringsAsFactors = FALSE
  )
  rownames(mada_df) <- make.unique(df$Author)
  mada_df
}

plot_forest_prop <- function(meta_obj, filename, metric_label, event_label, total_label) {
  png(file.path(output, filename), width = 3200, height = max(1900, 1100 + 95 * meta_obj$k), res = 300)
  meta::forest(
    meta_obj,
    pscale = 100,
    sortvar = studlab,
    digits = 1,
    rightcols = c("effect", "ci"),
    rightlabs = c(metric_label, "95% CI"),
    leftlabs = c("Study", event_label, total_label),
    xlim = c(0, 100),
    pooled.events = TRUE,
    print.tau2 = FALSE,
    overall = TRUE,
    overall.hetstat = TRUE,
    text.random = "Total",
    colgap.forest.left = "10mm",
    just = "center",
    colgap.forest = "3mm",
    col.square = "blue",
    col.square.lines = "black",
    col.diamond = "black",
    col.diamond.lines = "black"
  )
  dev.off()
}

plot_sroc <- function(df, label, filename) {
  if (!need_mada()) {
    writeLines("The R package 'mada' is required for bivariate SROC analysis. Install it with install.packages('mada').",
               con = file.path(output, paste0("SROCNotes - ", safe_name(label), ".txt")))
    return(NULL)
  }
  mada_df <- make_mada_data(df)
  fit <- try(mada::reitsma(mada_df), silent = TRUE)
  if (inherits(fit, "try-error")) {
    writeLines(as.character(fit), con = file.path(output, paste0("SROCNotes - ", safe_name(label), ".txt")))
    return(NULL)
  }
  capture.output(summary(fit), file = file.path(output, paste0("SROCSummary - ", safe_name(label), ".txt")))
  png(file.path(output, filename), width = 2600, height = 2300, res = 300)
  plot(fit,
       pch = 21,
       col = "black",
       bg = "black",
       xlim = c(0, 1),
       ylim = c(0, 1),
       xaxt = "n",
       yaxt = "n",
       ann = FALSE)
  title(xlab = "1 - Specificity (%)", ylab = "Sensitivity (%)", main = paste("Bivariate SROC:", label))
  axis(1, at = seq(0, 1, by = 0.1), labels = paste0(seq(0, 100, by = 10)))
  axis(2, at = seq(0, 1, by = 0.1), labels = paste0(seq(0, 100, by = 10)), las = 1)
  lines(mada::sroc(fit), lty = 1)
  mada::ROCellipse(fit, lty = 2, pch = 1, add = TRUE)
  points(mada::fpr(mada_df), mada::sens(mada_df), pch = 1, cex = 0.65)
  mu <- coef(fit)
  se <- sqrt(diag(vcov(fit)))
  if (length(mu) >= 2 && length(se) >= 2) {
    ci_logit_sens <- mu[1] + c(-1.96, 1.96) * se[1]
    ci_logit_fpr <- mu[2] + c(-1.96, 1.96) * se[2]
    sens_est <- plogis(mu[1])
    spec_est <- 1 - plogis(mu[2])
    ci_sens <- plogis(ci_logit_sens)
    ci_spec <- 1 - plogis(ci_logit_fpr)
    legend("bottomright", legend = c(
      paste0("Sensitivity: ", round(100 * sens_est, 1), "% (95% CI: ",
             round(100 * ci_sens[1], 1), "% - ", round(100 * ci_sens[2], 1), "%)"),
      paste0("Specificity: ", round(100 * spec_est, 1), "% (95% CI: ",
             round(100 * ci_spec[2], 1), "% - ", round(100 * ci_spec[1], 1), "%)")
    ), bty = "n", cex = 0.82)
  }
  legend("bottomleft", c("SROC curve", "95% confidence region"), lty = c(1, 2), lwd = c(1, 1), cex = 0.82)
  dev.off()
  fit
}

run_auc <- function(df, label) {
  if (!requireNamespace("dmetatools", quietly = TRUE)) {
    writeLines("dmetatools is not installed, so AUC bootstrap was skipped.",
               con = file.path(output, paste0("AUCBootstrap - ", safe_name(label), ".txt")))
    return(invisible(NULL))
  }
  auc <- try(dmetatools::AUC_boot(df$TP, df$FP, df$FN, df$TN), silent = TRUE)
  capture.output(auc, file = file.path(output, paste0("AUCBootstrap - ", safe_name(label), ".txt")))
}

run_threshold_effect <- function(df, label) {
  sn <- df$TP / (df$TP + df$FN)
  sp <- df$TN / (df$FP + df$TN)
  result <- data.frame(
    Metric = c("Pearson correlation logit(sensitivity) vs logit(1 - specificity)",
               "Spearman correlation logit(sensitivity) vs logit(1 - specificity)"),
    Value = c(
      suppressWarnings(stats::cor(logit_safe(sn), logit_safe(1 - sp), method = "pearson")),
      suppressWarnings(stats::cor(logit_safe(sn), logit_safe(1 - sp), method = "spearman"))
    )
  )
  write.csv(result, file.path(output, paste0("ThresholdEffect - ", safe_name(label), ".csv")), row.names = FALSE)
  capture.output(result, file = file.path(output, paste0("ThresholdEffect - ", safe_name(label), ".txt")))
}

run_single_test <- function(df, label, prefix = "") {
  label_safe <- safe_name(label)
  diag_table <- diagnostic_table(df)
  write.csv(diag_table, file.path(output, paste0(prefix, "DiagnosticTable - ", label_safe, ".csv")), row.names = FALSE)
  capture.output(summary(diag_table), file = file.path(output, paste0(prefix, "DiagnosticTableSummary - ", label_safe, ".txt")))

  sensitivity <- meta::metaprop(event = TP, n = TP + FN,
                                data = df,
                                random = random_model,
                                common = common_model,
                                method = "Inverse",
                                sm = "PLOGIT",
                                method.ci = "CP",
                                studlab = Author,
                                method.tau = "REML",
                                method.random.ci = "classic",
                                method.I2 = "tau2")
  specificity <- meta::metaprop(event = TN, n = TN + FP,
                                data = df,
                                random = random_model,
                                common = common_model,
                                method = "Inverse",
                                sm = "PLOGIT",
                                method.ci = "CP",
                                studlab = Author,
                                method.tau = "REML",
                                method.random.ci = "classic",
                                method.I2 = "tau2")
  capture.output(summary(sensitivity), file = file.path(output, paste0(prefix, "SummarySensitivity - ", label_safe, ".txt")))
  capture.output(summary(specificity), file = file.path(output, paste0(prefix, "SummarySpecificity - ", label_safe, ".txt")))
  saveRDS(sensitivity, file = file.path(output, paste0(prefix, "MetaObjectSensitivity - ", label_safe, ".rds")))
  saveRDS(specificity, file = file.path(output, paste0(prefix, "MetaObjectSpecificity - ", label_safe, ".rds")))
  plot_forest_prop(sensitivity, paste0(prefix, "ForestplotSensitivity - ", label_safe, ".png"), "Sensitivity", "TP", "TP + FN")
  plot_forest_prop(specificity, paste0(prefix, "ForestplotSpecificity - ", label_safe, ".png"), "Specificity", "TN", "TN + FP")

  dor <- meta::metabin(TP, TP + FP, FN, FN + TN,
                       data = df,
                       sm = "DOR",
                       studlab = Author,
                       random = random_model,
                       common = common_model,
                       method = "inverse",
                       incr = 0.5,
                       method.incr = "only0",
                       allstudies = TRUE,
                       method.tau = "REML",
                       method.random.ci = "classic",
                       method.I2 = "tau2")
  capture.output(summary(dor), file = file.path(output, paste0(prefix, "SummaryDOR - ", label_safe, ".txt")))
  saveRDS(dor, file = file.path(output, paste0(prefix, "MetaObjectDOR - ", label_safe, ".rds")))
  png(file.path(output, paste0(prefix, "ForestplotDOR - ", label_safe, ".png")), width = 3200, height = max(1900, 1100 + 95 * dor$k), res = 300)
  meta::forest(dor,
               layout = "Revman5",
               leftcols = c("studlab", "event.e", "n.e", "event.c", "n.c", if (random_model) "w.random" else "w.common", "effect", "ci"),
               leftlabs = c("Study", "TP", "TP + FP", "FN", "FN + TN", "Weight (%)", "DOR", "95% CI"),
               pooled.events = TRUE,
               pooled.totals = TRUE,
               col.square = "darkblue",
               col.square.lines = "black",
               sortvar = TE,
               fontsize = 8.5,
               fs.study = 8,
               fs.axis = 8,
               spacing = 0.9,
               just.studlab = "left")
  dev.off()
  dor_loo <- meta::metainf(dor, pooled = if (random_model) "random" else "common")
  capture.output(summary(dor_loo), file = file.path(output, paste0(prefix, "LeaveOneOutSummaryDOR - ", label_safe, ".txt")))
  png(file.path(output, paste0(prefix, "Leave-one-outDOR - ", label_safe, ".png")), width = 3200, height = max(1900, 1100 + 95 * dor$k), res = 300)
  meta::forest(dor_loo, col.bg = "lightblue", col.diamond = "gray", rightcols = c("effect", "ci", "I2", "pval"), fontsize = 8.5)
  dev.off()
  png(file.path(output, paste0(prefix, "FunnelPlotDOR - ", label_safe, ".png")), width = 2200, height = 2000, res = 300)
  meta::funnel(dor, studlab = FALSE, backtransf = FALSE, yaxis = "se")
  dev.off()
  if (dor$k >= 5) {
    capture.output(meta::metabias(dor, method.bias = "deeks", k.min = 5),
                   file = file.path(output, paste0(prefix, "DeeksTestDOR - ", label_safe, ".txt")))
  }

  plot_sroc(df, label, paste0(prefix, "SROC - ", label_safe, ".png"))
  run_auc(df, label)
  run_threshold_effect(df, label)
  invisible(list(sensitivity = sensitivity, specificity = specificity, dor = dor))
}

if (mode == "single") {
  run_single_test(data, outcome)
} else {
  groups <- unique(as.character(data$TestGroup[!is.na(data$TestGroup)]))
  if (length(groups) < 2) stop("Comparative mode requires at least two TestGroup values.", call. = FALSE)
  groups <- groups[seq_len(min(2, length(groups)))]
  label_map <- groups
  label_map[1] <- if (test_a_label != "Test A") test_a_label else groups[1]
  label_map[2] <- if (test_b_label != "Test B") test_b_label else groups[2]
  names(label_map) <- groups
  for (group in groups) {
    subset_df <- data[as.character(data$TestGroup) == group, ]
    run_single_test(subset_df, label_map[[group]], prefix = "Comparative - ")
  }
  if (need_mada()) {
    mada_a <- make_mada_data(data[as.character(data$TestGroup) == groups[1], ])
    mada_b <- make_mada_data(data[as.character(data$TestGroup) == groups[2], ])
    fit_a <- try(mada::reitsma(mada_a), silent = TRUE)
    fit_b <- try(mada::reitsma(mada_b), silent = TRUE)
    if (!inherits(fit_a, "try-error") && !inherits(fit_b, "try-error")) {
      png(file.path(output, "Comparative SROC Overlay.png"), width = 2700, height = 2300, res = 300)
      plot(fit_b, xlim = c(0, 1), ylim = c(0, 1), main = paste("SROC:", label_map[[groups[1]]], "vs", label_map[[groups[2]]]))
      lines(mada::sroc(fit_a), lty = 2)
      mada::ROCellipse(fit_a, lty = 2, pch = 2, add = TRUE)
      points(mada::fpr(mada_a), mada::sens(mada_a), pch = 2, cex = 0.55)
      points(mada::fpr(mada_b), mada::sens(mada_b), pch = 1, cex = 0.55)
      legend("bottomright", c(label_map[[groups[2]]], label_map[[groups[1]]]), pch = 1:2, lty = 1:2)
      legend("bottomleft", c(paste(label_map[[groups[2]]], "95% CI region"), paste(label_map[[groups[1]]], "95% CI region")), lty = c(1, 2), lwd = c(1, 1))
      dev.off()
    }
    if (requireNamespace("dmetatools", quietly = TRUE)) {
      auc_comp <- try(dmetatools::AUC_comparison(mada_a$TP, mada_a$FP, mada_a$FN, mada_a$TN,
                                                 mada_b$TP, mada_b$FP, mada_b$FN, mada_b$TN),
                      silent = TRUE)
      capture.output(auc_comp, file = file.path(output, "AUCComparison.txt"))
    }
  } else {
    writeLines("The R package 'mada' is required for comparative SROC overlay and AUC comparison.",
               con = file.path(output, "ComparativeSROCNotes.txt"))
  }
  if (requireNamespace("lme4", quietly = TRUE) && requireNamespace("lmtest", quietly = TRUE)) {
    combined <- data[data$TestGroup %in% groups, ]
    combined$category1 <- ifelse(as.character(combined$TestGroup) == groups[1], "A", "B")
    combined$n1 <- combined$TP + combined$FN
    combined$n0 <- combined$FP + combined$TN
    combined$true1 <- combined$TP
    combined$true0 <- combined$TN
    combined$ID <- as.factor(combined$StudyID)
    y <- reshape(combined,
                 direction = "long",
                 varying = list(c("n1", "n0"), c("true1", "true0")),
                 timevar = "sens",
                 times = c(1, 0),
                 v.names = c("n", "true"))
    y <- y[order(y$ID), ]
    y$spec <- 1 - y$sens
    y$A1 <- as.numeric(y$category1 == "A")
    y$B1 <- as.numeric(y$category1 == "B")
    y$seA1 <- y$A1 * y$sens
    y$seB1 <- y$B1 * y$sens
    y$spA1 <- y$A1 * y$spec
    y$spB1 <- y$B1 * y$spec
    glmm_out <- try({
      A <- lme4::glmer(cbind(true, n - true) ~ 0 + sens + spec + (0 + sens + spec | ID),
                       data = y, family = binomial,
                       control = lme4::glmerControl(optimizer = "bobyqa"))
      B <- lme4::glmer(cbind(true, n - true) ~ 0 + seA1 + seB1 + spA1 + spB1 + (0 + sens + spec | ID),
                       data = y, family = binomial,
                       control = lme4::glmerControl(optimizer = "bobyqa"))
      C <- lme4::glmer(cbind(true, n - true) ~ 0 + sens + spA1 + spB1 + (0 + sens + spec | ID),
                       data = y, family = binomial,
                       control = lme4::glmerControl(optimizer = "bobyqa"))
      D <- lme4::glmer(cbind(true, n - true) ~ 0 + seA1 + seB1 + spec + (0 + sens + spec | ID),
                       data = y, family = binomial,
                       control = lme4::glmerControl(optimizer = "bobyqa"))
      list(
        overall = lmtest::lrtest(A, B),
        sensitivity = lmtest::lrtest(B, C),
        specificity = lmtest::lrtest(B, D),
        summary_A = summary(A),
        summary_B = summary(B),
        summary_C = summary(C),
        summary_D = summary(D)
      )
    }, silent = TRUE)
    capture.output(glmm_out, file = file.path(output, "ComparativeDirectGLMM.txt"))
  } else {
    writeLines("lme4 and lmtest are required for direct comparative GLMM; this step was skipped.",
               con = file.path(output, "ComparativeDirectGLMM.txt"))
  }
}

writeLines(c(
  paste("Outcome:", outcome),
  paste("Mode:", mode),
  paste("Rows:", nrow(data)),
  paste("Statistical model:", model_type),
  paste("Output:", output)
), con = file.path(output, "run-info.txt"))
'''
    for key, value in replacements.items():
        script = script.replace(key, value)
    script_path.write_text(textwrap.dedent(script).strip() + "\n", encoding="utf-8")


def generate_summary_document(output_dir: Path, mapping: dict[str, Any], r_df: pd.DataFrame) -> Path:
    try:
        from docx import Document
        from docx.enum.text import WD_ALIGN_PARAGRAPH
        from docx.shared import Inches, Pt, RGBColor
    except ImportError as exc:
        raise SystemExit(f"python-docx is required to create the manuscript summary document: {exc}") from exc

    outcome = str(mapping.get("outcome_name") or "diagnostic accuracy")
    safe_outcome = common.sanitize_filename(outcome)
    analysis = normalize_analysis(mapping.get("analysis") or {}, mapping)
    document = Document()
    section = document.sections[0]
    section.top_margin = Inches(0.65)
    section.bottom_margin = Inches(0.65)
    section.left_margin = Inches(0.65)
    section.right_margin = Inches(0.65)
    styles = document.styles
    styles["Normal"].font.name = "Arial"
    styles["Normal"].font.size = Pt(9.5)
    styles["Heading 1"].font.name = "Arial"
    styles["Heading 1"].font.size = Pt(15)
    styles["Heading 1"].font.bold = True
    styles["Heading 1"].font.color.rgb = RGBColor(31, 78, 121)

    title = document.add_paragraph()
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = title.add_run("Diagnostic Meta-Analysis Results Summary")
    run.bold = True
    run.font.size = Pt(17)
    subtitle = document.add_paragraph()
    subtitle.alignment = WD_ALIGN_PARAGRAPH.CENTER
    subtitle.add_run(f"Outcome: {outcome}").italic = True

    document.add_heading("Manuscript-Ready Results Draft", level=1)
    mode_text = "comparative diagnostic test accuracy meta-analysis" if mapping.get("mode") == "comparative" else "single-arm diagnostic test accuracy meta-analysis"
    document.add_paragraph(
        f"This {mode_text} included {len(r_df)} extracted diagnostic 2x2 table row(s). "
        f"The primary outputs are pooled sensitivity, pooled specificity, and bivariate SROC analyses. "
        f"A diagnostic odds ratio analysis was generated for single-number summary, Deeks small-study assessment, "
        f"and supplementary diagnostic accuracy interpretation."
    )

    document.add_heading("Analysis Decisions", level=1)
    common.add_docx_table(
        document,
        ["Decision", "Selected", "Reason"],
        [
            ["Primary metric", "Sensitivity, specificity, SROC", analysis["primary_metric_reason"]],
            ["Statistical model", analysis["model_type"], analysis["model_type_reason"]],
            ["DOR analysis", "yes" if analysis["dor_analysis"] else "no", analysis["dor_analysis_reason"]],
        ],
    )

    document.add_heading("Generated Text Outputs", level=1)
    text_files = sorted(output_dir.rglob("*.txt"))
    if text_files:
        for path in text_files:
            if path.name == "run-info.txt":
                continue
            document.add_heading(str(path.relative_to(output_dir)), level=2)
            common.add_preformatted_block(document, common.read_text_if_exists(path), max_chars=5000)
    else:
        document.add_paragraph("No text outputs were found.")

    document.add_heading("Generated Figures and Files", level=1)
    common.add_docx_table(
        document,
        ["Figure", "File path"],
        [[str(path.relative_to(output_dir)), str(path)] for path in sorted(output_dir.rglob("*.png"))],
    )

    document.add_heading("Extracted Analysis Dataset", level=1)
    preview = r_df.head(60)
    if len(r_df) > 60:
        document.add_paragraph(f"Showing the first 60 of {len(r_df)} rows. See extracted-diagnostic-data.csv for the full dataset.")
    common.add_docx_table(document, list(preview.columns), preview.values.astype(str).tolist())

    document.add_heading("Reporting Guidance Note", level=1)
    document.add_paragraph(
        "For diagnostic test accuracy meta-analysis, interpret sensitivity and specificity jointly because threshold "
        "effects can trade one metric against the other. DOR is useful as a compact summary and for Deeks testing, "
        "but it does not show whether accuracy is driven by sensitivity or specificity."
    )
    docx_path = output_dir / f"Manuscript Results Summary - {safe_outcome}.docx"
    document.save(docx_path)
    return docx_path


def build_comparative_from_two_sheets(
    excel: Path,
    sheet_a: str,
    sheet_b: str,
    mapping_a: dict[str, Any],
    mapping_b: dict[str, Any],
    label_a: str,
    label_b: str,
) -> pd.DataFrame:
    df_a = common.load_sheet(excel, sheet_name=sheet_a)
    df_b = common.load_sheet(excel, sheet_name=sheet_b)
    df_a.columns = [str(col) for col in df_a.columns]
    df_b.columns = [str(col) for col in df_b.columns]
    part_a = validate_data(df_a, mapping_a, test_label=label_a)
    part_b = validate_data(df_b, mapping_b, test_label=label_b)
    return pd.concat([part_a, part_b], ignore_index=True)


def main() -> None:
    parser = argparse.ArgumentParser(description="Run diagnostic test accuracy meta-analysis from Excel.")
    parser.add_argument("excel", type=Path, nargs="?", help="Input Excel workbook.")
    parser.add_argument("--mode", choices=["single", "comparative"], default="single", help="Diagnostic analysis mode.")
    parser.add_argument("--sheet", help="Sheet name to analyze.")
    parser.add_argument("--test-a-sheet", help="Comparative mode: first diagnostic test sheet.")
    parser.add_argument("--test-b-sheet", help="Comparative mode: second diagnostic test sheet.")
    parser.add_argument("--test-a-label", default="Test A", help="Comparative mode label for first test.")
    parser.add_argument("--test-b-label", default="Test B", help="Comparative mode label for second test.")
    parser.add_argument("--outcome", help="Outcome name used in output filenames/titles.")
    parser.add_argument("--output-dir", type=Path, help="Output folder. Defaults beside the Excel file using the sheet name.")
    parser.add_argument("--preview-rows", type=int, default=30)
    parser.add_argument("--yes", action="store_true", help="Accept detected mapping and run non-interactively.")
    parser.add_argument("--no-lmstudio", action="store_true", help="Skip LMStudio and use name matching.")
    parser.add_argument("--install-r-packages", action="store_true", help="Install missing CRAN R packages before running R.")
    parser.add_argument("--lmstudio-url", default="http://localhost:1234/v1")
    parser.add_argument("--model", help="LMStudio model id.")

    args = parser.parse_args()

    if args.excel is None:
        args.excel = common.prompt_for_excel_path()
    args.excel = args.excel.expanduser().resolve()
    common.save_last_used_path(args.excel)
    if not args.excel.exists():
        raise SystemExit(f"Excel workbook not found: {args.excel}")

    _, summary = common.workbook_summary(args.excel)

    if args.mode == "comparative" and args.test_a_sheet and args.test_b_sheet:
        if args.test_a_label == args.test_b_label:
            raise SystemExit("--test-a-label and --test-b-label must be different in comparative mode.")
        for sheet in [args.test_a_sheet, args.test_b_sheet]:
            if sheet not in summary:
                raise SystemExit(f"Sheet '{sheet}' was not found. Available: {', '.join(summary)}")
        df_a = common.load_sheet(args.excel, sheet_name=args.test_a_sheet)
        df_b = common.load_sheet(args.excel, sheet_name=args.test_b_sheet)
        columns_a = [str(col) for col in df_a.columns]
        columns_b = [str(col) for col in df_b.columns]
        lm_a = None
        lm_b = None
        if not args.no_lmstudio:
            print(f"\nSending sheet '{args.test_a_sheet}' to LMStudio for diagnostic extraction...")
            lm_a = call_lmstudio({args.test_a_sheet: summary[args.test_a_sheet]}, "single", args.lmstudio_url, args.model)
            print(f"\nSending sheet '{args.test_b_sheet}' to LMStudio for diagnostic extraction...")
            lm_b = call_lmstudio({args.test_b_sheet: summary[args.test_b_sheet]}, "single", args.lmstudio_url, args.model)
        mapping_a = merge_mapping(columns_a, args.test_a_sheet, "single", lm_a, args.outcome)
        mapping_b = merge_mapping(columns_b, args.test_b_sheet, "single", lm_b, args.outcome)
        mapping_a = prompt_for_mapping(mapping_a, columns_a, args.yes)
        mapping_b = prompt_for_mapping(mapping_b, columns_b, args.yes)
        r_df = build_comparative_from_two_sheets(args.excel, args.test_a_sheet, args.test_b_sheet, mapping_a, mapping_b, args.test_a_label, args.test_b_label)
        mapping = mapping_a
        mapping["mode"] = "comparative"
        mapping["sheet_name"] = f"{args.test_a_sheet} + {args.test_b_sheet}"
        mapping["test_a_label"] = args.test_a_label
        mapping["test_b_label"] = args.test_b_label
    else:
        sheet_name = common.choose_sheet(summary, args.sheet, args.yes)
        df = common.load_sheet(args.excel, sheet_name=sheet_name)
        columns = [str(col) for col in df.columns]
        df.columns = columns
        lm_mapping = None
        if not args.no_lmstudio:
            print(f"\nSending sheet '{sheet_name}' to LMStudio for diagnostic extraction...")
            lm_mapping = call_lmstudio({sheet_name: summary[sheet_name]}, args.mode, args.lmstudio_url, args.model)
        mapping = merge_mapping(columns, sheet_name, args.mode, lm_mapping, args.outcome)
        mapping["test_a_label"] = args.test_a_label
        mapping["test_b_label"] = args.test_b_label
        mapping = prompt_for_mapping(mapping, columns, args.yes)
        r_df = validate_data(df, mapping)

    mapping["analysis"] = normalize_analysis(mapping.get("analysis") or {}, mapping)
    mapping["analysis"] = prompt_for_analysis_choices(mapping["analysis"], args.yes)

    output_base = args.sheet or mapping.get("sheet_name") or args.mode
    output_dir = args.output_dir.expanduser().resolve() if args.output_dir else (args.excel.parent / common.sanitize_filename(str(output_base))).resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    mapping_path = output_dir / "identified-columns.json"
    extracted_path = output_dir / "extracted-diagnostic-data.csv"
    mapping_path.write_text(json.dumps(mapping, indent=2, default=str), encoding="utf-8")
    show_extracted_data(r_df, max(args.preview_rows, 1), args.yes, extracted_path)

    with tempfile.TemporaryDirectory(prefix="diagnostic-meta-") as tmp:
        script_path = Path(tmp) / "run_diagnostic_meta.R"
        write_r_script(script_path, extracted_path, output_dir, mapping)
        common.run_r(script_path, install_packages=args.install_r_packages)
        common.crop_output_pngs(output_dir)
        summary_docx = generate_summary_document(output_dir, mapping, r_df)
        shutil.copyfile(script_path, output_dir / "generated_diagnostic_meta_analysis.R")

    print(f"\nDone. Outputs saved to: {output_dir}")
    print(f"Column mapping saved to: {mapping_path}")
    print(f"Manuscript summary saved to: {summary_docx}")


if __name__ == "__main__":
    main()
