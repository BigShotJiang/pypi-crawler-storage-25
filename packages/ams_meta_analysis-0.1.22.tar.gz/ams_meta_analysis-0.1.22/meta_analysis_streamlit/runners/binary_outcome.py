#!/usr/bin/env python3
"""Run the binary endpoint R meta-analysis template from Python.

The script reads an Excel workbook, asks a local LMStudio OpenAI-compatible
server to identify the binary endpoint columns, lets the user confirm the
mapping, and then runs the original R/meta workflow through Rscript.
"""

from __future__ import annotations

import argparse
import json
import math
import os
import re
import shutil
import subprocess
import sys
import tempfile
import textwrap
import unicodedata
import urllib.error
import urllib.request
from pathlib import Path
from typing import Any

import pandas as pd

from tsa_inference import binary_tsa_r_code, run_binary_tsa_analysis


COUNT_FIELDS = ["event_e", "n_e", "event_c", "n_c"]
HR_EFFECT_FIELDS = ["hr", "ci_lower", "ci_upper", "log_hr", "se_log_hr"]
REQUIRED_FIELDS = ["study_label", *COUNT_FIELDS]
OPTIONAL_FIELDS = ["covariate"]
SUMMARY_MEASURES = {
    "RR": "Risk Ratio",
    "OR": "Odds Ratio",
    "RD": "Risk Difference",
    "HR": "Hazard Ratio",
}
POOLING_METHODS = {
    "inverse": "Inverse Variance",
    "MH": "Mantel-Haenszel",
    "Peto": "Peto",
}
FIELD_LABELS = {
    "study_label": "Study label / Author",
    "event_e": "Intervention events",
    "n_e": "Intervention total",
    "event_c": "Control events",
    "n_c": "Control total",
    "hr": "Hazard ratio",
    "ci_lower": "HR CI lower",
    "ci_upper": "HR CI upper",
    "log_hr": "log(HR)",
    "se_log_hr": "SE log(HR)",
    "subgroups": "Subgroup columns",
    "covariate": "Meta-regression covariate",
    "covariates": "Meta-regression covariates",
}


def normalize_name(value: str) -> str:
    return re.sub(r"[^a-z0-9]+", "", str(value).lower())


def sanitize_filename(value: str, fallback: str = "binary outcome") -> str:
    safe = re.sub(r"[^\w .-]+", "_", str(value)).strip(" .")
    safe = re.sub(r"\s+", " ", safe).strip(" .")
    return (safe or fallback)[:140].rstrip(" .")


def append_mapping_note(mapping: dict[str, Any], note: str) -> None:
    existing = str(mapping.get("notes") or "").strip()
    if note in existing:
        return
    mapping["notes"] = f"{existing} {note}".strip() if existing else note


def sanitize_r_name(value: str, fallback: str) -> str:
    safe = re.sub(r"\W+", "_", str(value)).strip("_")
    if not safe:
        safe = fallback
    if re.match(r"^\d", safe):
        safe = f"{fallback}_{safe}"
    return safe


def covariate_r_name(value: str, index: int) -> str:
    return f"covariate_{index}_{sanitize_r_name(value, 'moderator')}"


def prepare_covariate_series(series: pd.Series, source_name: str) -> tuple[pd.Series | None, str | None, str | None]:
    """Return covariate values and whether R should treat them as numeric or categorical."""
    raw = series.copy()
    text = raw.astype("string").str.strip()
    missing_tokens = {"", "na", "n/a", "nan", "none", "null"}
    text = text.mask(text.str.lower().isin(missing_tokens))
    nonmissing = text.notna()
    nonmissing_count = int(nonmissing.sum())
    if nonmissing_count == 0:
        return None, None, "the column did not contain usable non-missing values."

    numeric = pd.to_numeric(raw, errors="coerce")
    numeric_nonmissing = int(numeric[nonmissing].notna().sum())
    numeric_unique = int(numeric.dropna().nunique())
    norm_name = normalize_name(source_name)
    categorical_terms = (
        "type", "group", "category", "class", "classification", "etiology",
        "aetiology", "region", "country", "setting", "center", "centre",
        "design", "approach", "technique", "route", "device", "stent",
    )
    numeric_terms = (
        "age", "bmi", "year", "followup", "duration", "month", "day",
        "percent", "percentage", "proportion", "sample", "size", "mean",
        "median", "sd", "score", "rate", "number",
    )
    categorical_hint = any(term in norm_name for term in categorical_terms) and not any(term in norm_name for term in numeric_terms)
    text_unique = list(dict.fromkeys(str(value) for value in text.dropna()))

    if numeric_nonmissing == nonmissing_count and numeric_unique >= 2 and not (categorical_hint and len(text_unique) <= 10):
        return numeric, "numeric", None
    if numeric_nonmissing >= max(3, int(0.8 * nonmissing_count)) and numeric_unique >= 2 and not categorical_hint:
        return numeric, "numeric", None
    if len(text_unique) >= 2:
        return text.astype(object), "categorical", None
    return None, None, "the column had fewer than two usable numeric values or categories."


def infer_arm_label_from_column(column: str | None, fallback: str) -> str:
    if not column:
        return fallback
    label = re.sub(
        r"\b(events?|event|total|sample size|sample|participants?|patients?|n|mean|sd|median|q1|q3|min|max|lower|upper|ci)\b",
        "",
        str(column),
        flags=re.I,
    )
    label = re.sub(r"\s+", " ", label).strip(" -_/")
    if normalize_name(label) in {"e", "c", "evente", "eventc", "ne", "nc"}:
        return fallback
    return label or fallback


GENERIC_ARM_LABELS = {
    "control",
    "comparator",
    "experimental",
    "intervention",
    "treatment",
    "exposure",
    "placebo",
    "usualcare",
}


def is_generic_arm_label(value: Any) -> bool:
    return normalize_name(str(value or "")) in GENERIC_ARM_LABELS


def refresh_arm_labels_from_columns(mapping: dict[str, Any]) -> dict[str, Any]:
    """Replace generic arm labels with labels inferred from selected arm columns."""
    columns = mapping.get("columns") or {}
    intervention_source = (
        columns.get("event_e")
        or columns.get("n_e")
        or columns.get("mean_e")
        or columns.get("median_e")
        or columns.get("hr")
        or columns.get("log_hr")
    )
    control_source = (
        columns.get("event_c")
        or columns.get("n_c")
        or columns.get("mean_c")
        or columns.get("median_c")
    )

    if is_generic_arm_label(mapping.get("intervention_label")):
        mapping["intervention_label"] = infer_arm_label_from_column(
            intervention_source,
            str(mapping.get("intervention_label") or "Experimental"),
        )
    if is_generic_arm_label(mapping.get("control_label")):
        mapping["control_label"] = infer_arm_label_from_column(
            control_source,
            str(mapping.get("control_label") or "Control"),
        )
    return mapping


def prompt_for_arm_labels_if_needed(mapping: dict[str, Any], assume_yes: bool = False) -> dict[str, Any]:
    """Ask for arm labels when neither the LLM nor column names produced specific names."""
    refresh_arm_labels_from_columns(mapping)
    needs_intervention = is_generic_arm_label(mapping.get("intervention_label"))
    needs_control = is_generic_arm_label(mapping.get("control_label"))
    if not needs_intervention and not needs_control:
        return mapping

    message = (
        "Could not confidently infer the intervention/control names for forest plot labels. "
        "Please provide the names to display."
    )
    if not sys.stdin.isatty():
        print(message + " Using the current generic labels because input is not interactive.")
        return mapping

    print("\n" + message)
    if needs_intervention:
        value = input(f"Intervention label [{mapping.get('intervention_label') or 'Experimental'}]: ").strip()
        if value:
            mapping["intervention_label"] = value
    if needs_control:
        value = input(f"Control/comparator label [{mapping.get('control_label') or 'Control'}]: ").strip()
        if value:
            mapping["control_label"] = value
    return mapping


def plot_safe_label(value: Any) -> str:
    """Use plot-device-safe text for R graphics labels."""
    text = unicodedata.normalize("NFKC", str(value or ""))
    text = re.sub(r"[\u2010\u2011\u2012\u2013\u2014\u2015\u2212\u2043\ufe58\ufe63\uff0d]", "-", text)
    text = text.replace("\u00a0", " ").replace("\u202f", " ")
    text = re.sub(r"\s+", " ", text).strip()
    return text.encode("ascii", "ignore").decode("ascii") or str(value or "")


def has_count_mapping(mapping: dict[str, Any]) -> bool:
    columns = mapping.get("columns", {})
    return all(columns.get(field) for field in COUNT_FIELDS)


def has_hr_mapping(mapping: dict[str, Any]) -> bool:
    columns = mapping.get("columns", {})
    has_hr_ci = all(columns.get(field) for field in ("hr", "ci_lower", "ci_upper"))
    has_log_se = all(columns.get(field) for field in ("log_hr", "se_log_hr"))
    return has_hr_ci or has_log_se


def effect_format(mapping: dict[str, Any]) -> str:
    summary_measure = str((mapping.get("analysis") or {}).get("summary_measure") or "").upper()
    if summary_measure == "HR":
        return "hr"
    if has_count_mapping(mapping):
        return "counts"
    if has_hr_mapping(mapping):
        return "hr"
    return "counts"


def required_mapping_fields(mapping: dict[str, Any]) -> list[str]:
    if effect_format(mapping) == "hr":
        if all(mapping.get("columns", {}).get(field) for field in ("log_hr", "se_log_hr")):
            return ["study_label", "log_hr", "se_log_hr"]
        return ["study_label", "hr", "ci_lower", "ci_upper"]
    return REQUIRED_FIELDS


def make_unique_study_labels(labels: pd.Series) -> pd.Series:
    counts: dict[str, int] = {}
    totals = labels.value_counts(dropna=False).to_dict()
    unique_labels = []
    for raw_label in labels:
        label = str(raw_label)
        counts[label] = counts.get(label, 0) + 1
        if totals.get(label, 0) > 1:
            unique_labels.append(f"{label} ({counts[label]})")
        else:
            unique_labels.append(label)
    return pd.Series(unique_labels, index=labels.index)


STUDY_COPY_SUFFIX_RE = re.compile(
    r"\s*[\[(]\s*\d+\s*[\])]\s*$",
    flags=re.I,
)


def study_group_label(value: Any) -> str:
    """Return a grouping label that treats 'Study (1)'/'Study (2)' as one study."""
    if value is None or pd.isna(value):
        return ""
    label = re.sub(r"\s+", " ", str(value).strip())
    while True:
        stripped = STUDY_COPY_SUFFIX_RE.sub("", label).strip()
        if stripped == label:
            return stripped
        label = stripped


def infer_covariate_columns(columns: list[str], mapping: dict[str, Any]) -> list[str]:
    selected = set(mapping.get("columns", {}).values())
    selected.update(mapping.get("subgroup_columns") or [])
    covariates: list[str] = []
    legacy = mapping.get("columns", {}).get("covariate")
    if legacy in columns:
        covariates.append(legacy)
    covariate_terms = (
        "covariate", "moderator", "regressor", "metareg", "metaregression", "age", "bmi",
        "year", "followup", "followupmonths", "duration", "samplesize", "sample",
        "male", "female", "percent", "proportion",
    )
    excluded_terms = (
        "event", "events", "total", "hazard", "ratio", "ci", "confidence",
        "lower", "upper", "subgroup", "group", "study", "author",
    )
    for col in columns:
        norm = normalize_name(col)
        is_regressor = "regressor" in norm
        if (col in selected and not is_regressor) or col in covariates:
            continue
        if is_regressor or (any(term in norm for term in covariate_terms) and not any(term in norm for term in excluded_terms)):
            covariates.append(col)
    return covariates


def default_mapping(columns: list[str]) -> dict[str, Any]:
    """Best-effort mapping for common binary endpoint column names."""
    normalized = {normalize_name(col): col for col in columns}

    exact = {
        "study_label": ["author", "firstauthor", "paperid", "study", "studlab", "studyid", "trial"],
        "event_e": ["evente", "eventse", "eusgjevents", "eventsintervention", "eventsexperimental",
                    "interventionevents", "experimentalevents", "treatmentevents"],
        "n_e": ["ne", "eusgjtotal", "eusgjn", "nintervention", "nexperimental",
                "interventiontotal", "experimentaltotal", "treatmenttotal"],
        "event_c": ["eventc", "eventsc", "noneusgjevents", "noneusgjevent", "nonexperimentalevents",
                    "noninterventionevents", "eventscontrol", "controlevents",
                    "placeboevents", "comparatorevents"],
        "n_c": ["nc", "noneusgjtotal", "noneusgjn", "noneusgj", "nonexperimentaltotal",
                "noninterventiontotal", "controltotal", "ncontrol", "controln",
                "placebototal", "comparatortotal"],
        "hr": ["hr", "hazardratio", "hazardratiopointestimate", "adjustedhr", "adjustedhazardratio"],
        "ci_lower": ["cilower", "lowerci", "lower95ci", "ci95lower", "lowerconfidenceinterval", "lcl", "lowercl"],
        "ci_upper": ["ciupper", "upperci", "upper95ci", "ci95upper", "upperconfidenceinterval", "ucl", "uppercl"],
        "log_hr": ["loghr", "lnhr", "loghazardratio", "lnhazardratio"],
        "se_log_hr": ["seloghr", "selnhr", "se", "standarderror", "standarderrorloghr", "standarderrorlnhr"],
        "subgroup": ["subgroup", "group", "drug", "country", "region"],
        "covariate": ["covariate", "moderator", "followup", "followupmonths"],
    }

    mapping: dict[str, Any] = {
        "sheet_name": None,
        "outcome_name": "binary outcome",
        "intervention_label": "Experimental",
        "control_label": "Control",
        "columns": {},
        "subgroup_columns": [],
        "covariate_columns": [],
        "analysis": {
            "summary_measure": "RR",
            "summary_measure_reason": "Risk Ratio is the default for raw binary intervention/control counts.",
            "pooling_method": "inverse",
            "pooling_method_reason": "Inverse variance is the default from the R Markdown template.",
            "model_type": "random",
            "model_type_reason": "Random-effects is the default for clinical meta-analysis when between-study heterogeneity is possible.",
            "outcome_direction": "unclear",
            "favor_left": "",
            "favor_right": "",
            "favor_label_reason": "",
            "tsa_alpha": 0.05,
            "tsa_power": 0.80,
            "tsa_adjust_for_diversity": False,
            "tsa_effect_source": "observed",
            "tsa_anticipated_effect": None,
            "tsa_required_information_size": None,
            "tsa_control_event_proportion": None,
            "tsa_intervention_event_proportion": None,
            "tsa_reason": "Trial sequential analysis uses two-sided alpha 0.05, 80% power, the observed pooled effect, and the selected heterogeneity adjustment for required information size (tau2 unless D2 diversity adjustment is selected).",
        },
        "confidence": 0.0,
        "notes": "Heuristic mapping; confirm before running.",
    }

    for field, candidates in exact.items():
        for candidate in candidates:
            if candidate in normalized:
                mapping["columns"][field] = normalized[candidate]
                break

    if "event_c" not in mapping["columns"]:
        for col in columns:
            norm = normalize_name(col)
            if (any(token in norm for token in ("noneusgj", "nonexperimental", "nonintervention", "comparator", "control"))
                    and any(token in norm for token in ("event", "events"))):
                mapping["columns"]["event_c"] = col
                break

    if "n_c" not in mapping["columns"]:
        for col in columns:
            norm = normalize_name(col)
            if (any(token in norm for token in ("noneusgj", "nonexperimental", "nonintervention", "comparator", "control"))
                    and any(token in norm for token in ("total", "sample", "participants"))):
                mapping["columns"]["n_c"] = col
                break

    if "hr" not in mapping["columns"]:
        for col in columns:
            norm = normalize_name(col)
            if "hazardratio" in norm or norm == "hr" or norm.endswith("hr"):
                mapping["columns"]["hr"] = col
                break

    if "ci_lower" not in mapping["columns"]:
        for col in columns:
            norm = normalize_name(col)
            if (("lower" in norm or "lcl" in norm)
                    and any(token in norm for token in ("ci", "confidence", "cl"))):
                mapping["columns"]["ci_lower"] = col
                break

    if "ci_upper" not in mapping["columns"]:
        for col in columns:
            norm = normalize_name(col)
            if (("upper" in norm or "ucl" in norm)
                    and any(token in norm for token in ("ci", "confidence", "cl"))):
                mapping["columns"]["ci_upper"] = col
                break

    if has_hr_mapping(mapping) and not has_count_mapping(mapping):
        mapping["intervention_label"] = "Exposure"
        mapping["control_label"] = "Comparator"
        mapping["analysis"]["summary_measure"] = "HR"
        mapping["analysis"]["summary_measure_reason"] = (
            "Hazard Ratio was selected because the sheet provides time-to-event effect estimates "
            "rather than raw intervention/control event counts."
        )
        mapping["analysis"]["pooling_method"] = "inverse"
        mapping["analysis"]["pooling_method_reason"] = (
            "Hazard ratios are pooled with generic inverse-variance meta-analysis using log(HR) and SE."
        )
        mapping["analysis"]["tsa_reason"] = (
            "Trial sequential analysis is skipped for hazard-ratio inputs because this runner does not "
            "have arm-level event risks for binary TSA required-information-size calculations."
        )

    mapping["intervention_label"] = infer_arm_label_from_column(
        mapping["columns"].get("event_e") or mapping["columns"].get("n_e"),
        mapping["intervention_label"],
    )
    mapping["control_label"] = infer_arm_label_from_column(
        mapping["columns"].get("event_c") or mapping["columns"].get("n_c"),
        mapping["control_label"],
    )

    if "subgroup" not in mapping["columns"]:
        for col in columns:
            norm = normalize_name(col)
            if any(token in norm for token in ("subgroup", "group", "strata", "category")):
                mapping["columns"]["subgroup"] = col
                mapping["subgroup_columns"] = [col]
                break

    mapping["covariate_columns"] = infer_covariate_columns(columns, mapping)
    if mapping["covariate_columns"]:
        mapping["columns"]["covariate"] = mapping["covariate_columns"][0]

    return mapping


def workbook_summary(path: Path) -> tuple[Any, dict[str, Any]]:
    summary: dict[str, Any] = {}
    if path.suffix.lower() == ".csv":
        try:
            df = pd.read_csv(path)
        except Exception:
            df = pd.read_csv(path, encoding="utf-8-sig")
        sheet_name = path.stem
        preview = df.head(5).where(pd.notna(df.head(5)), None)
        summary[sheet_name] = {
            "rows": int(df.shape[0]),
            "columns": [str(col) for col in df.columns],
            "sample_rows": preview.to_dict(orient="records"),
        }
        class MockWorkbook:
            def __init__(self, names):
                self.sheet_names = names
        return MockWorkbook([sheet_name]), summary

    workbook = pd.ExcelFile(path)
    for sheet in workbook.sheet_names:
        df = pd.read_excel(path, sheet_name=sheet)
        preview = df.head(5).where(pd.notna(df.head(5)), None)
        summary[sheet] = {
            "rows": int(df.shape[0]),
            "columns": [str(col) for col in df.columns],
            "sample_rows": preview.to_dict(orient="records"),
        }
    return workbook, summary


def load_sheet(path: Path, sheet_name: str) -> pd.DataFrame:
    if path.suffix.lower() == ".csv":
        try:
            return pd.read_csv(path)
        except Exception:
            return pd.read_csv(path, encoding="utf-8-sig")
    return pd.read_excel(path, sheet_name=sheet_name)


def print_workbook_sheets(summary: dict[str, Any]) -> None:
    print("\nWorkbook sheets")
    print("---------------")
    for index, (sheet, meta) in enumerate(summary.items(), start=1):
        columns = ", ".join(meta["columns"][:8])
        if len(meta["columns"]) > 8:
            columns += ", ..."
        print(f"{index}. {sheet} ({meta['rows']} rows, {len(meta['columns'])} columns)")
        if columns:
            print(f"   Columns: {columns}")


def chat_completions_url(base: str) -> str:
    base = base.rstrip("/")
    if base.endswith("/chat/completions"):
        return base
    if base.endswith("/v1") or base.endswith("/openai"):
        return f"{base}/chat/completions"
    return f"{base}/v1/chat/completions"


def models_url(base: str, version: str = "v1") -> str:
    base = base.rstrip("/")
    if version == "v0":
        # Usually http://localhost:1234/v1 -> http://localhost:1234/api/v0/models
        # or http://localhost:1234 -> http://localhost:1234/api/v0/models
        prefix = base
        if prefix.endswith("/v1"):
            prefix = prefix[:-3]
        return f"{prefix.rstrip('/')}/api/v0/models"

    if base.endswith("/models"):
        return base
    if base.endswith("/v1") or base.endswith("/openai"):
        return f"{base}/models"
    return f"{base}/v1/models"


def llm_api_key() -> str | None:
    return (
        os.environ.get("META_ANALYSIS_LLM_API_KEY")
        or os.environ.get("OPENAI_API_KEY")
        or os.environ.get("GEMINI_API_KEY")
        or os.environ.get("GOOGLE_API_KEY")
    )


def llm_request_headers(include_content_type: bool = False) -> dict[str, str]:
    headers: dict[str, str] = {}
    if include_content_type:
        headers["Content-Type"] = "application/json"
    api_key = llm_api_key()
    if api_key:
        header_name = os.environ.get("META_ANALYSIS_LLM_AUTH_HEADER", "Authorization")
        prefix = os.environ.get("META_ANALYSIS_LLM_AUTH_PREFIX", "Bearer")
        headers[header_name] = f"{prefix} {api_key}" if prefix else api_key
    return headers


def lmstudio_error_message(exc: urllib.error.HTTPError) -> str:
    try:
        body = exc.read().decode("utf-8", errors="replace")
    except Exception:
        return str(exc)
    if not body:
        return str(exc)
    try:
        payload = json.loads(body)
    except json.JSONDecodeError:
        return body
    if isinstance(payload, dict):
        error = payload.get("error")
        if isinstance(error, dict) and error.get("message"):
            return str(error["message"])
        if payload.get("message"):
            return str(payload["message"])
    return body


def list_lmstudio_models(lmstudio_url: str) -> list[dict[str, Any]]:
    # Try v0 first to get state info
    request = urllib.request.Request(models_url(lmstudio_url, version="v0"), headers=llm_request_headers(), method="GET")
    try:
        with urllib.request.urlopen(request) as response:
            payload = json.loads(response.read().decode("utf-8"))
            return payload.get("data", [])
    except Exception:
        # Fallback to v1
        request = urllib.request.Request(models_url(lmstudio_url, version="v1"), headers=llm_request_headers(), method="GET")
        try:
            with urllib.request.urlopen(request) as response:
                payload = json.loads(response.read().decode("utf-8"))
                return payload.get("data", [])
        except Exception:
            return []


def resolve_lmstudio_model(lmstudio_url: str, requested_model: str | None) -> str | None:
    if requested_model:
        return requested_model
    models_data = list_lmstudio_models(lmstudio_url)
    if not models_data:
        print("No LMStudio models were found. Falling back to name matching.")
        return None

    # Prioritize models with state="loaded" (from v0 API)
    loaded_models = [
        str(m["id"]) for m in models_data 
        if isinstance(m, dict) and m.get("state") == "loaded" and m.get("id")
    ]
    
    if loaded_models:
        model = loaded_models[0]
        print(f"Using active LMStudio model: {model}")
        if len(loaded_models) > 1:
            print("Other loaded models: " + ", ".join(loaded_models[1:]))
        return model

    # Fallback to first model in list if none are explicitly "loaded"
    model = None
    all_model_ids = []
    for m in models_data:
        mid = m.get("id") if isinstance(m, dict) else str(m)
        if mid:
            all_model_ids.append(str(mid))
    
    if not all_model_ids:
        return None
        
    model = all_model_ids[0]
    print(f"Using first available LMStudio model: {model}")
    if len(all_model_ids) > 1:
        print("Other available models: " + ", ".join(all_model_ids[1:]))
    return model


def call_lmstudio(
    summary: dict[str, Any],
    lmstudio_url: str,
    model: str | None,
) -> dict[str, Any] | None:
    model = resolve_lmstudio_model(lmstudio_url, model)
    if not model:
        return None

    prompt = {
        "task": (
            "Identify the columns needed for either a binary endpoint meta-analysis "
            "from raw arm counts or a time-to-event hazard-ratio meta-analysis. "
            "For raw counts this is equivalent to R meta::metabin(event.e, n.e, "
            "event.c, n.c, studlab = Author). For hazard ratios this is equivalent "
            "to R meta::metagen(TE = log(HR), seTE = SE(log(HR)), sm = 'HR'). "
            "Choose exact column names from the selected Excel sheet."
        ),
        "required_columns": {
            "study_label": "study name, author, or trial label",
            "event_e": "number of events in intervention/experimental group; null for HR-only sheets",
            "n_e": "total participants in intervention/experimental group; null for HR-only sheets",
            "event_c": "number of events in control/comparator/placebo group; null for HR-only sheets",
            "n_c": "total participants in control/comparator/placebo group; null for HR-only sheets",
            "hr": "reported hazard ratio; use with ci_lower and ci_upper when available",
            "ci_lower": "lower confidence limit for HR, usually 95% CI",
            "ci_upper": "upper confidence limit for HR, usually 95% CI",
            "log_hr": "reported log(HR), if HR is not directly reported",
            "se_log_hr": "standard error of log(HR), if reported or derivable",
        },
        "optional_columns": {
            "subgroup_columns": "all categorical subgroup columns if present; return more than one when appropriate",
            "covariate_columns": "all study-level moderator/regressor columns for meta-regression if present; include numeric moderators and categorical text moderators such as etiology, control type, region, or study design",
            "covariate": "legacy single numeric covariate for meta-regression if present",
        },
        "analysis_choices": {
            "summary_measure": "Choose RR, OR, RD, or HR. Choose HR when studies report hazard ratios or log hazard ratios.",
            "pooling_method": "Choose inverse, MH, or Peto. HR must use inverse.",
            "model_type": "Choose random or common/fixed.",
            "outcome_direction": "Choose beneficial if more events mean better outcome, harmful if more events mean worse outcome.",
            "favor_left": "Which group is favored on the left of the null line, where RR/OR < 1 or RD < 0.",
            "favor_right": "Which group is favored on the right of the null line, where RR/OR > 1 or RD > 0.",
            "tsa_alpha": "Two-sided type I error for trial sequential analysis; default 0.05.",
            "tsa_power": "Power for required information size; default 0.80.",
            "tsa_adjust_for_diversity": "Whether to inflate RIS for heterogeneity/diversity; default true.",
            "tsa_effect_source": "observed unless a protocol-specified clinically important effect is obvious.",
            "tsa_anticipated_effect": "Optional numeric anticipated RR/OR/RD; null if using observed pooled effect.",
            "tsa_required_information_size": "Optional numeric RIS/DARIS override from a protocol or TSA software; null to calculate it.",
            "tsa_control_event_proportion": "Optional protocol-specified control event proportion for RIS; null to calculate from extracted control totals.",
            "tsa_intervention_event_proportion": "Optional protocol-specified intervention event proportion for RIS; null to derive from the anticipated effect.",
            "tsa_favor_top": "Which group/outcome side is favored above zero on the TSA cumulative Z-score plot; should match favor_right for the unflipped Z = TE/SE convention.",
            "tsa_favor_bottom": "Which group/outcome side is favored below zero on the TSA cumulative Z-score plot; should match favor_left for the unflipped Z = TE/SE convention.",
        },
        "workbook": summary,
        "rules": [
            "Return exact column names as they appear in the workbook.",
            "Do not invent columns.",
            "Set intervention_label and control_label from the actual arm prefixes in the selected columns rather than generic labels; for example EUS-GJ Events vs NON EUS-GJ Events should yield intervention_label EUS-GJ and control_label NON EUS-GJ.",
            "Prefer columns containing event counts for event_e/event_c.",
            "Prefer sample-size, total, N, or denominator columns for n_e/n_c.",
            "If the sheet reports hazard ratios, adjusted HRs, log(HR), confidence intervals, or SE(log HR), choose summary_measure HR.",
            "For HR sheets, map either hr + ci_lower + ci_upper or log_hr + se_log_hr. If both are available, map both.",
            "For HR sheets, leave raw count columns null unless true arm-level event and total columns are also present.",
            "If subgroup columns are present, return all clinically meaningful categorical subgroup columns.",
            "Return all plausible meta-regression candidates in covariate_columns, including numeric moderators such as mean age, BMI, publication year, follow-up duration, percent male, sample size, and categorical text moderators such as etiology, control type, region, or study design.",
            "Any column whose name contains 'regressor' should be considered for meta-regression and included in covariate_columns when it is numeric, numeric-coded, or categorical text; it may also appear in subgroup_columns if it represents a categorical subgroup.",
            "Do not map the sheet's dependent clinical outcome itself as a covariate.",
            "Choose covariates only if numeric moderator columns exist; categorical moderators should be subgroup_columns instead.",
            "Effect measure rule: choose RR for most cohort, randomized trial, and clinical intervention data using raw event counts.",
            "Effect measure rule: choose OR for case-control studies or when the study reports odds/logistic-regression style outcomes.",
            "Effect measure rule from the TSA guide: binary TSA can use OR, RR, or RD; choose RD when the clinically important effect is naturally an absolute risk difference.",
            "Effect measure rule: choose HR for time-to-event survival outcomes, including Cox-model adjusted hazard ratios.",
            "Pooling rule from the PDF: choose Mantel-Haenszel (MH) when events are few, sparse, or sample sizes are small.",
            "Pooling rule from the PDF: choose inverse variance when events are common or studies are large.",
            "Pooling rule from the PDF: choose Peto only for very rare events with small effects and balanced groups; Peto can only be used with OR and a fixed/common-effect model.",
            "Model rule: choose random effects when included studies likely differ clinically/methodologically or when generalizing beyond one common true effect.",
            "Model rule: choose common/fixed effect only when a common true effect is plausible, heterogeneity is expected to be minimal, or Peto is selected.",
            "Model rule: Peto must use common/fixed effect here.",
            "Favors-label rule: values left of the null line mean fewer intervention events than control (RR/OR < 1 or RD < 0).",
            "If the event is beneficial (e.g., clinical success), fewer events is worse, so the left side favors control and the right side favors intervention.",
            "If the event is harmful (e.g., mortality, adverse event, complication), fewer events is better, so the left side favors intervention and the right side favors control.",
            "Classify outcomes such as clinical success, technical success, cure, response, remission, patency, survival, or resolution as beneficial events unless the sheet clearly says failure.",
            "Classify outcomes such as stent dysfunction, reintervention, obstruction, occlusion, recurrence, mortality, adverse events, bleeding, infection, perforation, complication, or failure as harmful/risk events.",
            "TSA rule: skip TSA for HR inputs because arm-level event risks are not available for required-information-size calculations.",
            "TSA rule: use a two-sided alpha of 0.05 and 80% power unless the workbook or protocol indicates otherwise.",
            "TSA rule: use diversity-adjusted required information size when heterogeneity is plausible.",
            "TSA rule: use the observed pooled effect as the anticipated effect unless there is a clear protocol-specified clinically important effect.",
            "TSA rule from the TSA guide: binary TSA needs incidence in the control and experimental groups calculated from the meta-analysis.",
            "TSA rule from the TSA guide: include zero-event studies and use a 0.5 continuity correction.",
            "TSA labeling rule: the plotted Z-curve uses Z = TE / SE, where TE is intervention versus control. Positive Z means RR/OR > 1 or RD > 0, so the top TSA label must match the right side of the forest plot. Negative Z means RR/OR < 1 or RD < 0, so the bottom TSA label must match the left side of the forest plot.",
        ],
        "return_json_schema": {
            "sheet_name": "string",
            "outcome_name": "string",
            "intervention_label": "string",
            "control_label": "string",
            "columns": {
                "study_label": "string",
                "event_e": "string",
                "n_e": "string",
                "event_c": "string",
                "n_c": "string",
                "hr": "string or null",
                "ci_lower": "string or null",
                "ci_upper": "string or null",
                "log_hr": "string or null",
                "se_log_hr": "string or null",
                "covariate": "string or null",
            },
            "covariate_columns": ["string"],
            "subgroup_columns": ["string"],
            "analysis": {
                "summary_measure": "RR, OR, RD, or HR",
                "summary_measure_reason": "short string",
                "pooling_method": "inverse, MH, or Peto",
                "pooling_method_reason": "short string",
                "model_type": "random or common",
                "model_type_reason": "short string",
                "outcome_direction": "beneficial or harmful",
                "favor_left": "intervention or control label to show left of null line",
                "favor_right": "intervention or control label to show right of null line",
                "favor_label_reason": "short string",
                "tsa_alpha": "number, usually 0.05",
                "tsa_power": "number, usually 0.80 or 0.90",
                "tsa_adjust_for_diversity": "boolean",
                "tsa_effect_source": "observed or clinically_important",
                "tsa_anticipated_effect": "number or null; anticipated RR/OR/RD when clinically_important",
                "tsa_required_information_size": "number or null; protocol/TSA software RIS override",
                "tsa_control_event_proportion": "number or null; RIS input control event proportion",
                "tsa_intervention_event_proportion": "number or null; RIS input intervention event proportion",
                "tsa_favor_top": "intervention/control label shown above zero",
                "tsa_favor_bottom": "intervention/control label shown below zero",
                "tsa_reason": "short string",
            },
            "confidence": "number from 0 to 1",
            "notes": "short string",
        },
    }

    body = {
        "model": model,
        "messages": [
            {
                "role": "system",
                "content": (
                    "You map messy clinical-study Excel columns to a strict "
                    "binary meta-analysis schema. Return only valid JSON."
                ),
            },
            {"role": "user", "content": json.dumps(prompt, default=str)},
        ],
        "temperature": 0,
    }

    request = urllib.request.Request(
        chat_completions_url(lmstudio_url),
        data=json.dumps(body).encode("utf-8"),
        headers=llm_request_headers(include_content_type=True),
        method="POST",
    )

    try:
        with urllib.request.urlopen(request) as response:
            payload = json.loads(response.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        print(f"LMStudio request failed ({lmstudio_error_message(exc)}). Falling back to name matching.")
        return None
    except (OSError, urllib.error.URLError, json.JSONDecodeError) as exc:
        print(f"LMStudio was not available ({exc}). Falling back to name matching.")
        return None

    content = payload["choices"][0]["message"]["content"]
    try:
        return json.loads(content)
    except json.JSONDecodeError:
        match = re.search(r"\{.*\}", content, flags=re.S)
        if not match:
            print("LMStudio response was not JSON. Falling back to name matching.")
            return None
        return json.loads(match.group(0))


def choose_sheet(summary: dict[str, Any], sheet_arg: str | None, assume_yes: bool) -> str:
    if sheet_arg:
        if sheet_arg not in summary:
            raise SystemExit(f"Sheet '{sheet_arg}' was not found. Available: {', '.join(summary)}")
        return sheet_arg

    print_workbook_sheets(summary)
    if sys.stdin.isatty() and not assume_yes:
        while True:
            value = input("Which sheet should be used? Enter number or sheet name: ").strip()
            if value.isdigit():
                index = int(value)
                sheet_names = list(summary)
                if 1 <= index <= len(sheet_names):
                    return sheet_names[index - 1]
            if value in summary:
                return value
            print("Please enter one of the listed sheet numbers or exact sheet names.")

    non_empty = [name for name, meta in summary.items() if meta["rows"] > 0]
    if len(non_empty) == 1:
        return non_empty[0]
    return next(iter(summary))


def infer_favor_labels(mapping: dict[str, Any], outcome_direction: str | None = None) -> dict[str, str]:
    intervention = str(mapping.get("intervention_label") or "Experimental")
    control = str(mapping.get("control_label") or "Control")
    outcome_hint = normalize_name(
        " ".join(str(mapping.get(key, "")) for key in ("outcome_name", "sheet_name"))
    )
    beneficial_terms = ("success", "response", "remission", "resolution", "cure", "healing",
                        "patency", "improvement", "benefit", "survival")
    harmful_terms = ("mortality", "death", "adverse", "bleeding", "complication", "dysfunction",
                     "failure", "recurrence", "infection", "obstruction", "occlusion",
                     "reintervention", "perforation", "event", "risk")

    direction = (outcome_direction or "").lower()
    if direction not in {"beneficial", "harmful"}:
        is_hr = str((mapping.get("analysis") or {}).get("summary_measure") or "").upper() == "HR"
        if is_hr:
            direction = "harmful"
        elif any(term in outcome_hint for term in beneficial_terms):
            direction = "beneficial"
        elif any(term in outcome_hint for term in harmful_terms):
            direction = "harmful"
        else:
            direction = "harmful"

    if direction == "beneficial":
        return {
            "outcome_direction": "beneficial",
            "favor_left": control,
            "favor_right": intervention,
            "favor_label_reason": (
                "The outcome appears beneficial, so RR/OR < 1 means fewer beneficial events in the "
                "intervention group and favors control; RR/OR > 1 favors intervention."
            ),
        }
    return {
        "outcome_direction": "harmful",
        "favor_left": intervention,
        "favor_right": control,
        "favor_label_reason": (
            "The outcome appears harmful, so RR/OR < 1 means fewer harmful events in the intervention "
            "group and favors intervention; RR/OR > 1 favors control."
        ),
    }


def normalize_favor_group(value: str, mapping: dict[str, Any], fallback: str) -> str:
    cleaned = str(value or "").strip()
    lowered = cleaned.lower()
    if lowered in {"intervention", "intervention_label", "experimental", "experimental_label", "treatment", "eus-gj", "eusgj"}:
        return str(mapping.get("intervention_label") or fallback)
    if lowered in {"control", "control_label", "comparator", "comparator_label", "placebo", "non eus-gj", "noneusgj"}:
        return str(mapping.get("control_label") or fallback)
    if lowered.startswith("favors "):
        cleaned = cleaned[7:].strip()
    return cleaned or fallback


def normalize_bool(value: Any, fallback: bool) -> bool:
    if isinstance(value, bool):
        return value
    if value is None:
        return fallback
    lowered = str(value).strip().lower()
    if lowered in {"true", "t", "yes", "y", "1"}:
        return True
    if lowered in {"false", "f", "no", "n", "0"}:
        return False
    return fallback


def normalize_float(value: Any, fallback: float | None, minimum: float | None = None, maximum: float | None = None) -> float | None:
    if value in {"", None}:
        return fallback
    try:
        result = float(value)
    except (TypeError, ValueError):
        return fallback
    if not math.isfinite(result):
        return fallback
    if minimum is not None and result < minimum:
        return fallback
    if maximum is not None and result > maximum:
        return fallback
    return result


def normalize_analysis_choices(analysis: dict[str, Any], mapping: dict[str, Any]) -> dict[str, Any]:
    prior_analysis = mapping.get("analysis", {})
    sm = str(analysis.get("summary_measure") or "RR").upper()
    if sm not in SUMMARY_MEASURES:
        sm = "RR"

    method_raw = str(analysis.get("pooling_method") or "inverse").strip()
    method_aliases = {
        "iv": "inverse", "inverse variance": "inverse", "inverse": "inverse",
        "mh": "MH", "mantel-haenszel": "MH", "mantel haenszel": "MH", "peto": "Peto",
    }
    method = method_aliases.get(method_raw.lower(), method_raw)
    if method not in POOLING_METHODS:
        method = "inverse"
    if sm == "HR":
        method = "inverse"

    if method == "Peto" and sm != "OR":
        sm = "OR"
        sm_reason = "Peto pooling can only be used with odds ratios, so the effect measure was set to OR."
    elif sm == "HR":
        sm_reason = str(
            analysis.get("summary_measure_reason")
            or mapping.get("analysis", {}).get("summary_measure_reason")
            or "Hazard Ratio is selected for time-to-event outcomes reported as HR with CI or log(HR) with SE."
        )
    else:
        sm_reason = str(
            analysis.get("summary_measure_reason")
            or mapping.get("analysis", {}).get("summary_measure_reason")
            or "Risk Ratio is generally preferred for raw intervention/control binary event counts."
        )

    if sm == "HR":
        method_reason = str(
            analysis.get("pooling_method_reason")
            or mapping.get("analysis", {}).get("pooling_method_reason")
            or "Hazard ratios are pooled with generic inverse-variance meta-analysis using log(HR) and SE."
        )
    else:
        method_reason = str(
            analysis.get("pooling_method_reason")
            or mapping.get("analysis", {}).get("pooling_method_reason")
            or "Inverse variance is the standard choice when events are common or studies are large."
        )

    model_raw = str(analysis.get("model_type") or mapping.get("analysis", {}).get("model_type") or "random").strip().lower()
    model_aliases = {
        "fixed": "common", "fixed-effect": "common", "fixed effect": "common",
        "common-effect": "common", "common effect": "common", "common": "common",
        "random-effects": "random", "random effects": "random", "random": "random",
    }
    model_type = model_aliases.get(model_raw, "random")
    model_reason = str(
        analysis.get("model_type_reason")
        or mapping.get("analysis", {}).get("model_type_reason")
        or "Random-effects is the default for clinical meta-analysis when between-study heterogeneity is possible."
    )
    if method == "Peto":
        model_type = "common"
        model_reason = "Peto pooling is treated as a common/fixed-effect method, so the model was set to common."

    inferred_favors = infer_favor_labels(mapping, str(analysis.get("outcome_direction") or prior_analysis.get("outcome_direction") or ""))
    outcome_direction = str(analysis.get("outcome_direction") or inferred_favors["outcome_direction"]).lower()
    if outcome_direction == "unclear":
        outcome_direction = inferred_favors["outcome_direction"]
    if outcome_direction not in {"beneficial", "harmful"}:
        outcome_direction = inferred_favors["outcome_direction"]
    inferred_favors = infer_favor_labels(mapping, outcome_direction)

    favor_left = normalize_favor_group(
        analysis.get("favor_left") or prior_analysis.get("favor_left") or inferred_favors["favor_left"],
        mapping,
        inferred_favors["favor_left"],
    )
    favor_right = normalize_favor_group(
        analysis.get("favor_right") or prior_analysis.get("favor_right") or inferred_favors["favor_right"],
        mapping,
        inferred_favors["favor_right"],
    )
    favor_reason = str(
        analysis.get("favor_label_reason")
        or prior_analysis.get("favor_label_reason")
        or inferred_favors["favor_label_reason"]
    )

    tsa_alpha = normalize_float(analysis.get("tsa_alpha", prior_analysis.get("tsa_alpha")), 0.05, 0.0001, 0.5)
    tsa_power = normalize_float(analysis.get("tsa_power", prior_analysis.get("tsa_power")), 0.80, 0.5, 0.999)
    tsa_adjust = normalize_bool(
        analysis.get("tsa_adjust_for_diversity", prior_analysis.get("tsa_adjust_for_diversity")), False,
    )
    tsa_effect_source = str(
        analysis.get("tsa_effect_source") or prior_analysis.get("tsa_effect_source") or "observed"
    ).strip().lower()
    if tsa_effect_source not in {"observed", "clinically_important"}:
        tsa_effect_source = "observed"
    if sm == "RD":
        tsa_anticipated = normalize_float(
            analysis.get("tsa_anticipated_effect", prior_analysis.get("tsa_anticipated_effect")), None, -1, 1,
        )
    else:
        tsa_anticipated = normalize_float(
            analysis.get("tsa_anticipated_effect", prior_analysis.get("tsa_anticipated_effect")), None, 0.0001, None,
        )
    tsa_ris_override = normalize_float(
        analysis.get("tsa_required_information_size", prior_analysis.get("tsa_required_information_size")), None, 1, None,
    )
    tsa_control_event_proportion = normalize_float(
        analysis.get("tsa_control_event_proportion", prior_analysis.get("tsa_control_event_proportion")), None, 0.0001, 0.9999,
    )
    tsa_intervention_event_proportion = normalize_float(
        analysis.get("tsa_intervention_event_proportion", prior_analysis.get("tsa_intervention_event_proportion")), None, 0.0001, 0.9999,
    )
    tsa_favor_top = normalize_favor_group(
        analysis.get("tsa_favor_top") or prior_analysis.get("tsa_favor_top") or favor_right,
        mapping,
        favor_right,
    )
    tsa_favor_bottom = normalize_favor_group(
        analysis.get("tsa_favor_bottom") or prior_analysis.get("tsa_favor_bottom") or favor_left,
        mapping,
        favor_left,
    )
    tsa_reason = str(
        analysis.get("tsa_reason")
        or prior_analysis.get("tsa_reason")
        or "TSA uses two-sided alpha 0.05, 80% power, observed pooled effect, and the selected heterogeneity adjustment for required information size (tau2 unless D2 diversity adjustment is selected)."
    )
    if sm == "HR":
        tsa_reason = (
            "Trial sequential analysis is skipped for hazard-ratio inputs because this runner does not "
            "have arm-level event risks for binary TSA required-information-size calculations."
        )

    normalized = {
        "summary_measure": sm,
        "summary_measure_reason": sm_reason,
        "pooling_method": method,
        "pooling_method_reason": method_reason,
        "model_type": model_type,
        "model_type_reason": model_reason,
        "outcome_direction": outcome_direction,
        "favor_left": favor_left,
        "favor_right": favor_right,
        "favor_label_reason": favor_reason,
        "tsa_alpha": tsa_alpha,
        "tsa_power": tsa_power,
        "tsa_adjust_for_diversity": tsa_adjust,
        "tsa_effect_source": tsa_effect_source,
        "tsa_anticipated_effect": tsa_anticipated,
        "tsa_required_information_size": tsa_ris_override,
        "tsa_control_event_proportion": tsa_control_event_proportion,
        "tsa_intervention_event_proportion": tsa_intervention_event_proportion,
        "tsa_favor_top": tsa_favor_top,
        "tsa_favor_bottom": tsa_favor_bottom,
        "tsa_reason": tsa_reason,
    }
    for key in ("subgroup_only", "conflict_resolution", "conflict_resolution_reason"):
        if key in analysis:
            normalized[key] = analysis[key]
        elif key in prior_analysis:
            normalized[key] = prior_analysis[key]
    return normalized


def merge_mapping(
    columns: list[str],
    sheet_name: str,
    lm_mapping: dict[str, Any] | None,
    outcome: str | None,
) -> dict[str, Any]:
    merged = default_mapping(columns)
    merged["sheet_name"] = sheet_name
    if lm_mapping:
        merged.update({k: v for k, v in lm_mapping.items() if k != "columns" and v})
        merged["sheet_name"] = sheet_name
        merged.setdefault("columns", {})
        for field, col in (lm_mapping.get("columns") or {}).items():
            if col in columns:
                merged["columns"][field] = col
            elif col in ("", None):
                merged["columns"].pop(field, None)
        subgroup_columns = []
        for col in lm_mapping.get("subgroup_columns") or []:
            if col in columns and col not in subgroup_columns:
                subgroup_columns.append(col)
        legacy_subgroup = (lm_mapping.get("columns") or {}).get("subgroup")
        if legacy_subgroup in columns and legacy_subgroup not in subgroup_columns:
            subgroup_columns.append(legacy_subgroup)
        merged["subgroup_columns"] = subgroup_columns
        covariate_columns = []
        for col in lm_mapping.get("covariate_columns") or []:
            if col in columns and col not in covariate_columns:
                covariate_columns.append(col)
        legacy_covariate = (lm_mapping.get("columns") or {}).get("covariate")
        if legacy_covariate in columns and legacy_covariate not in covariate_columns:
            covariate_columns.append(legacy_covariate)
        for col in infer_covariate_columns(columns, merged):
            if col in columns and col not in covariate_columns:
                covariate_columns.append(col)
        if covariate_columns:
            merged["covariate_columns"] = covariate_columns
            merged["columns"]["covariate"] = covariate_columns[0]
    if outcome:
        merged["outcome_name"] = outcome
    if has_hr_mapping(merged) and not has_count_mapping(merged):
        merged["intervention_label"] = "Exposure"
        merged["control_label"] = "Comparator"
        merged.setdefault("analysis", {})
        merged["analysis"]["summary_measure"] = "HR"
        merged["analysis"]["summary_measure_reason"] = (
            "Hazard Ratio was selected because HR/log(HR) columns were mapped and raw arm-count columns are absent."
        )
        merged["analysis"]["pooling_method"] = "inverse"
        merged["analysis"]["pooling_method_reason"] = "Hazard ratios use generic inverse-variance pooling."
    else:
        refresh_arm_labels_from_columns(merged)
    merged["analysis"] = normalize_analysis_choices(merged.get("analysis") or {}, merged)
    return merged


def column_number_lookup(columns: list[str]) -> dict[str, str]:
    return {str(index): column for index, column in enumerate(columns, start=1)}


def format_column_choice(column: str | None, columns: list[str]) -> str:
    if not column:
        return "(none)"
    try:
        return f"{columns.index(column) + 1}. {column}"
    except ValueError:
        return str(column)


def print_numbered_columns(columns: list[str]) -> None:
    print("\nAvailable columns")
    print("-----------------")
    for index, column in enumerate(columns, start=1):
        print(f"{index}. {column}")


def print_mapping(mapping: dict[str, Any], columns: list[str]) -> None:
    print("\nIdentified binary endpoint mapping")
    print("----------------------------------")
    print(f"Sheet: {mapping.get('sheet_name')}")
    print(f"Outcome name: {mapping.get('outcome_name')}")
    print(f"Intervention label: {mapping.get('intervention_label')}")
    print(f"Control label: {mapping.get('control_label')}")
    print("\nColumns:")
    shown_fields = ["study_label", *COUNT_FIELDS, *HR_EFFECT_FIELDS]
    for field in shown_fields:
        column = mapping.get("columns", {}).get(field)
        print(f"  {FIELD_LABELS[field]}: {format_column_choice(column, columns)}")
    subgroups = mapping.get("subgroup_columns") or []
    if not subgroups and mapping.get("columns", {}).get("subgroup"):
        subgroups = [mapping["columns"]["subgroup"]]
    subgroup_display = ", ".join(format_column_choice(col, columns) for col in subgroups) or "(none)"
    print(f"  {FIELD_LABELS['subgroups']}: {subgroup_display}")
    covariate_display = ", ".join(
        format_column_choice(col, columns) for col in (mapping.get("covariate_columns") or [])
    ) or format_column_choice(mapping.get("columns", {}).get("covariate"), columns)
    print(f"  {FIELD_LABELS['covariates']}: {covariate_display}")
    for field in OPTIONAL_FIELDS:
        if field == "covariate":
            continue
        column = mapping.get("columns", {}).get(field)
        print(f"  {FIELD_LABELS[field]}: {format_column_choice(column, columns)}")
    print_numbered_columns(columns)
    analysis = normalize_analysis_choices(mapping.get("analysis") or {}, mapping)
    print("\nAnalysis choices:")
    print(f"  Effect size: {analysis['summary_measure']} ({SUMMARY_MEASURES[analysis['summary_measure']]})")
    print(f"    Why: {analysis['summary_measure_reason']}")
    print(f"  Pooling method: {analysis['pooling_method']} ({POOLING_METHODS[analysis['pooling_method']]})")
    print(f"    Why: {analysis['pooling_method_reason']}")
    print(f"  Statistical model: {analysis['model_type']} ({'Random-effects' if analysis['model_type'] == 'random' else 'Common/fixed-effect'})")
    print(f"    Why: {analysis['model_type_reason']}")
    print(f"  Favors label direction: {analysis['outcome_direction']}")
    print(f"    Left of null: Favors {analysis['favor_left']}")
    print(f"    Right of null: Favors {analysis['favor_right']}")
    print(f"    Why: {analysis['favor_label_reason']}")
    print(
        "  TSA: "
        f"alpha {analysis['tsa_alpha']}, power {analysis['tsa_power']}, "
        f"{'diversity-adjusted RIS' if analysis['tsa_adjust_for_diversity'] else 'heterogeneity-adjusted RIS (tau2)'}, "
        f"effect source {analysis['tsa_effect_source']}"
        + (f", RIS override {analysis['tsa_required_information_size']}" if analysis.get("tsa_required_information_size") else "")
    )
    print(f"    TSA top: Favours {analysis['tsa_favor_top']}; bottom: Favours {analysis['tsa_favor_bottom']}")
    print(f"    Why: {analysis['tsa_reason']}")
    if analysis["summary_measure"] == "HR":
        print("    Note: TSA will be skipped for HR analyses.")
    if mapping.get("notes"):
        print(f"Notes: {mapping['notes']}")


def resolve_column_choice(value: str, columns: list[str]) -> str | None:
    cleaned = value.strip()
    if cleaned.lower() in {"none", "null", "-", "0"}:
        return None
    numbered_columns = column_number_lookup(columns)
    if cleaned in numbered_columns:
        return numbered_columns[cleaned]
    if cleaned in columns:
        return cleaned
    raise SystemExit(f"'{value}' is not one of the available column numbers or names.")


def resolve_column_choices(value: str, columns: list[str]) -> list[str]:
    selected = []
    for part in re.split(r"[,; ]+", value.strip()):
        if not part:
            continue
        resolved = resolve_column_choice(part, columns)
        if resolved and resolved not in selected:
            selected.append(resolved)
    return selected


def resolve_override_columns(value: str | None, columns: list[str]) -> list[str]:
    if value is None:
        return []
    cleaned = value.strip()
    if not cleaned or cleaned.lower() in {"none", "null", "-", "0"}:
        return []
    separators = [part.strip() for part in re.split(r"[,;]\s*", cleaned) if part.strip()]
    parts = separators if len(separators) > 1 else [cleaned]
    selected = []
    for part in parts:
        if part in columns:
            resolved = part
        else:
            resolved = resolve_column_choice(part, columns)
        if resolved and resolved not in selected:
            selected.append(resolved)
    return selected


def apply_column_overrides(
    mapping: dict[str, Any],
    columns: list[str],
    *,
    group_column: str | None = None,
    subgroup_columns: str | None = None,
    covariate_columns: str | None = None,
) -> dict[str, Any]:
    mapping.setdefault("columns", {})
    if group_column or subgroup_columns is not None:
        selected_subgroups = []
        for value in (group_column, subgroup_columns):
            for column in resolve_override_columns(value, columns):
                if column not in selected_subgroups:
                    selected_subgroups.append(column)
        mapping["subgroup_columns"] = selected_subgroups
        if selected_subgroups:
            mapping["columns"]["subgroup"] = selected_subgroups[0]
        else:
            mapping["columns"].pop("subgroup", None)
    if covariate_columns is not None:
        selected_covariates = resolve_override_columns(covariate_columns, columns)
        mapping["covariate_columns"] = selected_covariates
        if selected_covariates:
            mapping["columns"]["covariate"] = selected_covariates[0]
        else:
            mapping["columns"].pop("covariate", None)
    return mapping


def prompt_for_analysis_choices(analysis: dict[str, str], assume_yes: bool = False) -> dict[str, str]:
    print("\nChosen analysis and plot direction")
    print("----------------------------------")
    print(f"Effect size: {analysis['summary_measure']} ({SUMMARY_MEASURES[analysis['summary_measure']]})")
    print(f"Why: {analysis['summary_measure_reason']}")
    print(f"Pooling method: {analysis['pooling_method']} ({POOLING_METHODS[analysis['pooling_method']]})")
    print(f"Why: {analysis['pooling_method_reason']}")
    print(f"Statistical model: {analysis['model_type']} ({'Random-effects' if analysis['model_type'] == 'random' else 'Common/fixed-effect'})")
    print(f"Why: {analysis['model_type_reason']}")
    print(f"Outcome direction: {analysis['outcome_direction']}")
    print(f"Left of null line: Favors {analysis['favor_left']}")
    print(f"Right of null line: Favors {analysis['favor_right']}")
    print(f"Why: {analysis['favor_label_reason']}")
    print(
        "Trial sequential analysis: "
        f"alpha {analysis['tsa_alpha']}, power {analysis['tsa_power']}, "
        f"{'diversity-adjusted RIS' if analysis['tsa_adjust_for_diversity'] else 'heterogeneity-adjusted RIS (tau2)'}, "
        f"effect source {analysis['tsa_effect_source']}"
        + (f", RIS override {analysis['tsa_required_information_size']}" if analysis.get("tsa_required_information_size") else "")
    )
    print(f"TSA top: Favours {analysis['tsa_favor_top']}; bottom: Favours {analysis['tsa_favor_bottom']}")
    print(f"Why: {analysis['tsa_reason']}")

    if assume_yes or not sys.stdin.isatty():
        return analysis

    correct = input("Are these analysis choices correct? [Y/n]: ").strip().lower()
    if correct not in {"n", "no"}:
        return analysis

    print("\nEffect size options:")
    print("1. RR - Risk Ratio")
    print("2. OR - Odds Ratio")
    print("3. RD - Risk Difference")
    print("4. HR - Hazard Ratio / time-to-event")
    sm_value = input(f"Effect size [{analysis['summary_measure']}]: ").strip()
    if sm_value:
        sm_lookup = {"1": "RR", "2": "OR", "3": "RD", "4": "HR", "RR": "RR", "OR": "OR", "RD": "RD", "HR": "HR",
                     "rr": "RR", "or": "OR", "rd": "RD", "hr": "HR"}
        if sm_value not in sm_lookup:
            raise SystemExit("Effect size must be 1/RR, 2/OR, 3/RD, or 4/HR.")
        analysis["summary_measure"] = sm_lookup[sm_value]
        analysis["summary_measure_reason"] = "Manually selected by user."

    print("\nPooling method options from the PDF:")
    print("1. MH - Mantel-Haenszel: sparse/few events or small studies")
    print("2. inverse - Inverse Variance: common events or large studies")
    print("3. Peto - very rare events, small effects, balanced groups; OR only")
    if analysis["summary_measure"] == "HR":
        print("HR uses generic inverse-variance pooling, so pooling method is being set to inverse.")
        analysis["pooling_method"] = "inverse"
        analysis["pooling_method_reason"] = "Hazard ratios use generic inverse-variance pooling of log(HR)."
    else:
        method_value = input(f"Pooling method [{analysis['pooling_method']}]: ").strip()
        if method_value:
            method_lookup = {"1": "MH", "2": "inverse", "3": "Peto", "MH": "MH", "mh": "MH",
                             "inverse": "inverse", "iv": "inverse", "IV": "inverse", "Peto": "Peto", "peto": "Peto"}
            if method_value not in method_lookup:
                raise SystemExit("Pooling method must be 1/MH, 2/inverse, or 3/Peto.")
            analysis["pooling_method"] = method_lookup[method_value]
            analysis["pooling_method_reason"] = "Manually selected by user."

    if analysis["pooling_method"] == "Peto" and analysis["summary_measure"] != "OR":
        print("Peto can only be used with odds ratios, so effect size is being set to OR.")
        analysis["summary_measure"] = "OR"
        analysis["summary_measure_reason"] = "Peto pooling requires OR."

    print("\nStatistical model options:")
    print("1. random - Random-effects: allows the true effect to vary across studies")
    print("2. common - Common/fixed-effect: assumes one common true effect")
    model_value = input(f"Statistical model [{analysis['model_type']}]: ").strip()
    if model_value:
        model_lookup = {"1": "random", "2": "common", "random": "random", "random-effects": "random",
                        "random effects": "random", "common": "common", "fixed": "common",
                        "fixed-effect": "common", "fixed effect": "common"}
        normalized_model_value = model_value.lower()
        if normalized_model_value not in model_lookup:
            raise SystemExit("Statistical model must be 1/random or 2/common/fixed.")
        analysis["model_type"] = model_lookup[normalized_model_value]
        analysis["model_type_reason"] = "Manually selected by user."

    if analysis["pooling_method"] == "Peto" and analysis["model_type"] != "common":
        print("Peto uses a common/fixed-effect model here, so statistical model is being set to common.")
        analysis["model_type"] = "common"
        analysis["model_type_reason"] = "Peto pooling requires a common/fixed-effect model."

    print("\nFavors-label options:")
    print(f"Current: left = Favors {analysis['favor_left']}; right = Favors {analysis['favor_right']}")
    flip_value = input("Flip left/right favors labels? [y/N]: ").strip().lower()
    if flip_value in {"y", "yes"}:
        analysis["favor_left"], analysis["favor_right"] = analysis["favor_right"], analysis["favor_left"]
        analysis["favor_label_reason"] = "Manually flipped by user."
    else:
        left_value = input(f"Left label group [{analysis['favor_left']}]: ").strip()
        right_value = input(f"Right label group [{analysis['favor_right']}]: ").strip()
        if left_value:
            analysis["favor_left"] = left_value.removeprefix("Favors ").strip()
            analysis["favor_label_reason"] = "Manually selected by user."
        if right_value:
            analysis["favor_right"] = right_value.removeprefix("Favors ").strip()
            analysis["favor_label_reason"] = "Manually selected by user."

    print("\nTrial sequential analysis options:")
    if analysis["summary_measure"] == "HR":
        analysis["tsa_reason"] = (
            "Trial sequential analysis is skipped for hazard-ratio inputs because this runner does not "
            "have arm-level event risks for binary TSA required-information-size calculations."
        )
        print(analysis["tsa_reason"])
    else:
        alpha_value = input(f"Two-sided alpha [{analysis['tsa_alpha']}]: ").strip()
        if alpha_value:
            parsed = normalize_float(alpha_value, None, 0.0001, 0.5)
            if parsed is None:
                raise SystemExit("TSA alpha must be a number between 0.0001 and 0.5.")
            analysis["tsa_alpha"] = parsed
            analysis["tsa_reason"] = "Manually selected by user."
        power_value = input(f"Power [{analysis['tsa_power']}]: ").strip()
        if power_value:
            parsed = normalize_float(power_value, None, 0.5, 0.999)
            if parsed is None:
                raise SystemExit("TSA power must be a number between 0.5 and 0.999.")
            analysis["tsa_power"] = parsed
            analysis["tsa_reason"] = "Manually selected by user."
        diversity_value = input(
            f"Use diversity-adjusted required information size (instead of tau2)? [{'Y/n' if analysis['tsa_adjust_for_diversity'] else 'y/N'}]: "
        ).strip().lower()
        if diversity_value:
            if diversity_value not in {"y", "yes", "n", "no"}:
                raise SystemExit("Diversity adjustment must be yes or no.")
            analysis["tsa_adjust_for_diversity"] = diversity_value in {"y", "yes"}
            analysis["tsa_reason"] = "Manually selected by user."
        effect_source_value = input(f"TSA anticipated effect source [{analysis['tsa_effect_source']}]: ").strip().lower()
        if effect_source_value:
            if effect_source_value not in {"observed", "clinically_important"}:
                raise SystemExit("TSA effect source must be observed or clinically_important.")
            analysis["tsa_effect_source"] = effect_source_value
            analysis["tsa_reason"] = "Manually selected by user."
        if analysis["tsa_effect_source"] == "clinically_important":
            anticipated_value = input(
                f"Anticipated {analysis['summary_measure']} for TSA [{analysis.get('tsa_anticipated_effect') or 'observed pooled effect'}]: "
            ).strip()
            if anticipated_value:
                if analysis["summary_measure"] == "RD":
                    parsed = normalize_float(anticipated_value, None, -1, 1)
                else:
                    parsed = normalize_float(anticipated_value, None, 0.0001, None)
                if parsed is None:
                    if analysis["summary_measure"] == "RD":
                        raise SystemExit("Anticipated TSA RD must be a number between -1 and 1.")
                    raise SystemExit("Anticipated TSA effect must be a positive number.")
                analysis["tsa_anticipated_effect"] = parsed
                analysis["tsa_reason"] = "Manually selected clinically important effect."
        ris_value = input(
            f"Required information size override [{analysis.get('tsa_required_information_size') or 'calculated'}]: "
        ).strip()
        if ris_value:
            if ris_value.lower() in {"none", "calculated", "calculate", "auto", "0"}:
                analysis["tsa_required_information_size"] = None
            else:
                parsed = normalize_float(ris_value, None, 1, None)
                if parsed is None:
                    raise SystemExit("TSA required information size override must be a positive number.")
                analysis["tsa_required_information_size"] = parsed
                analysis["tsa_reason"] = "Required information size was manually provided by user."
        pc_value = input(
            f"TSA control event proportion for RIS [{analysis.get('tsa_control_event_proportion') or 'observed control risk'}]: "
        ).strip()
        if pc_value:
            if pc_value.lower() in {"none", "observed", "calculated", "calculate", "auto", "0"}:
                analysis["tsa_control_event_proportion"] = None
            else:
                parsed = normalize_float(pc_value, None, 0.0001, 0.9999)
                if parsed is None:
                    raise SystemExit("TSA control event proportion must be between 0.0001 and 0.9999.")
                analysis["tsa_control_event_proportion"] = parsed
                analysis["tsa_reason"] = "Control event proportion for RIS was manually provided by user."
        pt_value = input(
            f"TSA intervention event proportion for RIS [{analysis.get('tsa_intervention_event_proportion') or 'derived from anticipated effect'}]: "
        ).strip()
        if pt_value:
            if pt_value.lower() in {"none", "derived", "calculated", "calculate", "auto", "0"}:
                analysis["tsa_intervention_event_proportion"] = None
            else:
                parsed = normalize_float(pt_value, None, 0.0001, 0.9999)
                if parsed is None:
                    raise SystemExit("TSA intervention event proportion must be between 0.0001 and 0.9999.")
                analysis["tsa_intervention_event_proportion"] = parsed
                analysis["tsa_reason"] = "Intervention event proportion for RIS was manually provided by user."
        print(f"Current TSA labels: top = Favours {analysis['tsa_favor_top']}; bottom = Favours {analysis['tsa_favor_bottom']}")
        flip_tsa = input("Flip TSA top/bottom favour labels? [y/N]: ").strip().lower()
        if flip_tsa in {"y", "yes"}:
            analysis["tsa_favor_top"], analysis["tsa_favor_bottom"] = analysis["tsa_favor_bottom"], analysis["tsa_favor_top"]
            analysis["tsa_reason"] = "TSA labels were manually flipped by user."

    return analysis


def prompt_for_mapping(mapping: dict[str, Any], columns: list[str], assume_yes: bool) -> dict[str, Any]:
    print_mapping(mapping, columns)
    if assume_yes or not sys.stdin.isatty():
        return mapping

    missing_required = [field for field in required_mapping_fields(mapping) if field not in mapping.get("columns", {})]
    if missing_required:
        missing_labels = ", ".join(FIELD_LABELS[field] for field in missing_required)
        print(f"\nRequired fields are missing ({missing_labels}), so column selection is required.")
    else:
        correct = input("\nAre these identified columns correct? [Y/n]: ").strip().lower()
        if correct not in {"n", "no"}:
            return mapping

    print("\nType a column number to replace a value, press Enter to keep it, or type 0 for none.")
    mapping["outcome_name"] = input(f"Outcome name [{mapping.get('outcome_name')}]: ").strip() or mapping.get("outcome_name")
    mapping["intervention_label"] = (
        input(f"Intervention label [{mapping.get('intervention_label')}]: ").strip() or mapping.get("intervention_label")
    )
    mapping["control_label"] = (
        input(f"Control label [{mapping.get('control_label')}]: ").strip() or mapping.get("control_label")
    )

    for field in ["study_label", *COUNT_FIELDS, *HR_EFFECT_FIELDS]:
        current = mapping.get("columns", {}).get(field) or ""
        current_display = format_column_choice(current, columns)
        value = input(f"{FIELD_LABELS[field]} column [{current_display}]: ").strip()
        if value:
            resolved = resolve_column_choice(value, columns)
            if resolved is None:
                mapping["columns"].pop(field, None)
            else:
                mapping["columns"][field] = resolved

    subgroup_display = ", ".join(
        format_column_choice(col, columns) for col in (mapping.get("subgroup_columns") or [])
    ) or "(none)"
    subgroup_value = input(f"{FIELD_LABELS['subgroups']} [{subgroup_display}]: ").strip()
    if subgroup_value:
        if subgroup_value.strip().lower() in {"none", "null", "-", "0"}:
            mapping["subgroup_columns"] = []
            mapping["columns"].pop("subgroup", None)
        else:
            mapping["subgroup_columns"] = resolve_column_choices(subgroup_value, columns)
            if mapping["subgroup_columns"]:
                mapping["columns"]["subgroup"] = mapping["subgroup_columns"][0]

    covariate_display = ", ".join(
        format_column_choice(col, columns) for col in (mapping.get("covariate_columns") or [])
    ) or format_column_choice(mapping.get("columns", {}).get("covariate"), columns)
    covariate_value = input(f"{FIELD_LABELS['covariates']} [{covariate_display}]: ").strip()
    if covariate_value:
        if covariate_value.strip().lower() in {"none", "null", "-", "0"}:
            mapping["covariate_columns"] = []
            mapping["columns"].pop("covariate", None)
        else:
            mapping["covariate_columns"] = resolve_column_choices(covariate_value, columns)
            if mapping["covariate_columns"]:
                mapping["columns"]["covariate"] = mapping["covariate_columns"][0]

    for field in OPTIONAL_FIELDS:
        if field == "covariate":
            continue
        current = mapping.get("columns", {}).get(field) or ""
        current_display = format_column_choice(current, columns)
        value = input(f"{FIELD_LABELS[field]} column [{current_display}]: ").strip()
        if value:
            resolved = resolve_column_choice(value, columns)
            if resolved is None:
                mapping["columns"].pop(field, None)
            else:
                mapping["columns"][field] = resolved

    print_mapping(mapping, columns)
    confirm = input("\nUse this corrected column mapping? [Y/n]: ").strip().lower()
    if confirm in {"n", "no"}:
        raise SystemExit("Stopped before extracting binary data.")
    return mapping


def validate_data(df: pd.DataFrame, mapping: dict[str, Any]) -> pd.DataFrame:
    missing = [field for field in required_mapping_fields(mapping) if not mapping.get("columns", {}).get(field)]
    if missing:
        labels = ", ".join(FIELD_LABELS[field] for field in missing)
        raise SystemExit(f"Missing required mapping: {labels}")
    if df.empty:
        raise SystemExit("The selected sheet has no data rows. Add study rows before running the analysis.")

    r_df = pd.DataFrame()
    study_values = df[mapping["columns"]["study_label"]].astype("string").str.strip()
    study_values = study_values.mask(study_values.str.lower().isin({"", "nan", "none", "null"}).fillna(False))
    r_df["Author"] = study_values
    for source_col in df.columns:
        if normalize_name(source_col) in {"tsaorder", "order"}:
            output_col = "tsa_order" if normalize_name(source_col) == "tsaorder" else "order"
            r_df[output_col] = pd.to_numeric(df[source_col], errors="coerce")
            break
    format_type = effect_format(mapping)
    if format_type == "hr":
        columns = mapping["columns"]
        if columns.get("log_hr") and columns.get("se_log_hr"):
            r_df["TE"] = pd.to_numeric(df[columns["log_hr"]], errors="coerce")
            r_df["seTE"] = pd.to_numeric(df[columns["se_log_hr"]], errors="coerce")
            r_df["HR"] = r_df["TE"].apply(lambda value: math.exp(value) if pd.notna(value) else math.nan)
            r_df["ci.lower"] = (r_df["TE"] - 1.96 * r_df["seTE"]).apply(lambda value: math.exp(value) if pd.notna(value) else math.nan)
            r_df["ci.upper"] = (r_df["TE"] + 1.96 * r_df["seTE"]).apply(lambda value: math.exp(value) if pd.notna(value) else math.nan)
        else:
            r_df["HR"] = pd.to_numeric(df[columns["hr"]], errors="coerce")
            r_df["ci.lower"] = pd.to_numeric(df[columns["ci_lower"]], errors="coerce")
            r_df["ci.upper"] = pd.to_numeric(df[columns["ci_upper"]], errors="coerce")
            r_df["TE"] = r_df["HR"].apply(lambda value: math.log(value) if pd.notna(value) and value > 0 else math.nan)
            r_df["seTE"] = (
                r_df["ci.upper"].apply(lambda value: math.log(value) if pd.notna(value) and value > 0 else math.nan)
                - r_df["ci.lower"].apply(lambda value: math.log(value) if pd.notna(value) and value > 0 else math.nan)
            ) / (2 * 1.96)

        for source_field, output_col in [("event_e", "event.e"), ("n_e", "n.e"), ("event_c", "event.c"), ("n_c", "n.c")]:
            source = mapping.get("columns", {}).get(source_field)
            if source:
                r_df[output_col] = pd.to_numeric(df[source], errors="coerce")
    else:
        for field, r_col in [("event_e", "event.e"), ("n_e", "n.e"), ("event_c", "event.c"), ("n_c", "n.c")]:
            source = mapping["columns"][field]
            r_df[r_col] = pd.to_numeric(df[source], errors="coerce")

    subgroup_sources = list(mapping.get("subgroup_columns") or [])
    legacy_subgroup = mapping.get("columns", {}).get("subgroup")
    if legacy_subgroup and legacy_subgroup not in subgroup_sources:
        subgroup_sources.append(legacy_subgroup)
    valid_subgroups = []
    used_subgroup_cols: set[str] = set()
    for index, subgroup_source in enumerate(subgroup_sources, start=1):
        if subgroup_source:
            subgroup_col = sanitize_r_name(subgroup_source, f"subgroup_{index}")
            reserved_cols = {"Author", "event.e", "n.e", "event.c", "n.c", "HR", "ci.lower", "ci.upper", "TE", "seTE", "covariate"}
            if subgroup_col in reserved_cols:
                subgroup_col = f"{subgroup_col}_subgroup"
            base_col = subgroup_col
            suffix = 2
            while subgroup_col in used_subgroup_cols:
                subgroup_col = f"{base_col}_{suffix}"
                suffix += 1
            used_subgroup_cols.add(subgroup_col)
            r_df[subgroup_col] = df[subgroup_source]
            valid_subgroups.append({"source": subgroup_source, "r_column": subgroup_col})
    mapping["subgroup_columns"] = [item["source"] for item in valid_subgroups]
    mapping["subgroup_r_columns"] = valid_subgroups

    mapping.setdefault("analysis", {})
    mapping["analysis"].setdefault("subgroup_only", False)
    original_authors = study_values
    study_group_labels = original_authors.map(study_group_label)
    duplicate_study_groups = study_group_labels[study_group_labels.notna() & (study_group_labels != "")]
    mapping["duplicate_study_label_conflict"] = bool(duplicate_study_groups.duplicated(keep=False).any())
    mapping["duplicate_subgroup_conflict"] = False
    if valid_subgroups:
        primary_subgroup_col = valid_subgroups[0]["r_column"]
        temp_df = pd.DataFrame({"author": study_group_labels, "subgroup": r_df[primary_subgroup_col]})
        temp_df = temp_df.dropna(subset=["subgroup"])
        unique_combinations = temp_df.drop_duplicates()
        if unique_combinations["author"].duplicated().any():
            mapping["duplicate_subgroup_conflict"] = True

    covariate_sources = list(mapping.get("covariate_columns") or [])
    legacy_covariate = mapping.get("columns", {}).get("covariate")
    if legacy_covariate and legacy_covariate not in covariate_sources:
        covariate_sources.append(legacy_covariate)
    for subgroup_source in list(mapping.get("subgroup_columns") or []):
        if subgroup_source not in covariate_sources:
            covariate_sources.append(subgroup_source)
    for covariate_source in infer_covariate_columns(list(df.columns), mapping):
        if covariate_source not in covariate_sources:
            covariate_sources.append(covariate_source)
    mapping["covariate_skip_notes"] = []
    valid_covariates = []
    used_covariate_cols: set[str] = set()
    for index, covariate_source in enumerate(covariate_sources, start=1):
        if not covariate_source or covariate_source not in df.columns:
            continue
        covariate_col = covariate_r_name(covariate_source, index)
        base_col = covariate_col
        suffix = 2
        while covariate_col in used_covariate_cols or covariate_col in r_df.columns:
            covariate_col = f"{base_col}_{suffix}"
            suffix += 1
        values, covariate_type, reason = prepare_covariate_series(df[covariate_source], covariate_source)
        if values is None or covariate_type is None:
            reason = reason or "the column could not be interpreted as a numeric or categorical moderator."
            print(f"Covariate column '{covariate_source}' was identified but is not usable for meta-regression; skipping it.")
            mapping["covariate_skip_notes"].append({"source": covariate_source, "reason": reason})
            continue
        r_df[covariate_col] = values
        used_covariate_cols.add(covariate_col)
        valid_covariates.append({"source": covariate_source, "r_column": covariate_col, "type": covariate_type})
    mapping["covariate_columns"] = [item["source"] for item in valid_covariates]
    mapping["covariate_r_columns"] = valid_covariates
    if valid_covariates:
        mapping["columns"]["covariate"] = valid_covariates[0]["source"]
    else:
        mapping["columns"].pop("covariate", None)

    duplicate_rows_need_resolution = bool(
        mapping.get("duplicate_subgroup_conflict") or mapping.get("duplicate_study_label_conflict")
    )
    conflict_resolution = mapping.get("analysis", {}).get("conflict_resolution")
    if duplicate_rows_need_resolution and format_type == "hr":
        append_mapping_note(
            mapping,
            "Duplicate study labels were found across subgroup rows for an HR analysis; confirm that strata are independent before interpreting subgroup outputs.",
        )
    if duplicate_rows_need_resolution and format_type != "hr":
        if conflict_resolution == "subgroup_only":
            conflict_resolution = "combine"
            mapping["analysis"]["conflict_resolution"] = "combine"
            mapping["analysis"]["subgroup_only"] = False
            append_mapping_note(
                mapping,
                "Duplicate study labels had been marked as subgroup-only, but the overall forest plot and TSA now use Cochrane-combined rows to avoid double-counting; subgroup plots still use subgroup-specific duplicate handling.",
            )
        if conflict_resolution not in {"combine", "split", "subgroup_only"} and not mapping.get("analysis", {}).get("subgroup_only"):
            conflict_resolution = "combine"
            mapping["analysis"]["conflict_resolution"] = conflict_resolution
            append_mapping_note(
                mapping,
                "Duplicate study labels, including numbered copy labels such as '(1)'/'(2)', were automatically collapsed with conflict_resolution='combine' to avoid double-counting arm-level data.",
            )
    if conflict_resolution in {"combine", "split"} and duplicate_rows_need_resolution:
        if format_type != "hr":
            r_df["Author"] = original_authors
            r_df["_study_group_label"] = study_group_labels
            grouped = r_df.groupby("_study_group_label", sort=False, dropna=False)
            new_rows = []
            subgroup_rows_by_column: dict[str, list[pd.Series]] = {
                subgroup["r_column"]: [] for subgroup in valid_subgroups
            }
            unresolved_authors = []
            for author, group in grouped:
                if len(group) <= 1:
                    new_rows.append(group.iloc[0])
                    for rows in subgroup_rows_by_column.values():
                        rows.append(group.iloc[0])
                    continue
                # Dynamically detect shared sides using both totals and events.
                n_e_unique = group["n.e"].nunique(dropna=True)
                n_c_unique = group["n.c"].nunique(dropna=True)
                event_e_unique = group["event.e"].nunique(dropna=True)
                event_c_unique = group["event.c"].nunique(dropna=True)

                shared_sides = []
                if n_e_unique == 1 and event_e_unique == 1:
                    shared_sides.append("e")
                if n_c_unique == 1 and event_c_unique == 1:
                    shared_sides.append("c")

                if len(shared_sides) == 1:
                    shared_side = shared_sides[0]
                    varying_sides = ["c" if shared_side == "e" else "e"]
                elif len(shared_sides) == 0:
                    shared_side = None
                    varying_sides = ["e", "c"]
                else:
                    unresolved_authors.append(str(author))
                    continue

                row = group.iloc[0].copy()
                if conflict_resolution == "combine":
                    row["Author"] = str(author)
                    for side in varying_sides:
                        row[f"event.{side}"] = group[f"event.{side}"].sum(skipna=True)
                        row[f"n.{side}"] = group[f"n.{side}"].sum(skipna=True)
                    for subgroup in valid_subgroups:
                        row[subgroup["r_column"]] = "Combined"
                    new_rows.append(row)
                    split_group_rows = []
                    if shared_side is None:
                        split_group_rows = [g_row.copy() for _, g_row in group.iterrows()]
                    else:
                        k = len(group)
                        split_event = group[f"event.{shared_side}"] / k
                        split_n = group[f"n.{shared_side}"] / k
                        for i, (_, g_row) in enumerate(group.iterrows()):
                            g_row_copy = g_row.copy()
                            g_row_copy[f"event.{shared_side}"] = split_event.iloc[i]
                            g_row_copy[f"n.{shared_side}"] = split_n.iloc[i]
                            split_group_rows.append(g_row_copy)
                    for subgroup in valid_subgroups:
                        subgroup_col = subgroup["r_column"]
                        subgroup_values = group[subgroup_col].dropna()
                        unique_values = pd.unique(subgroup_values)
                        if len(unique_values) == 1:
                            subgroup_row = row.copy()
                            subgroup_row[subgroup_col] = unique_values[0]
                            subgroup_rows_by_column[subgroup_col].append(subgroup_row)
                        else:
                            subgroup_rows_by_column[subgroup_col].extend([g_row.copy() for g_row in split_group_rows])
                elif conflict_resolution == "split":
                    if shared_side is None:
                        unresolved_authors.append(str(author))
                        continue
                    k = len(group)
                    split_event = group[f"event.{shared_side}"] / k
                    split_n = group[f"n.{shared_side}"] / k
                    for i, (_, g_row) in enumerate(group.iterrows()):
                        g_row_copy = g_row.copy()
                        g_row_copy[f"event.{shared_side}"] = split_event.iloc[i]
                        g_row_copy[f"n.{shared_side}"] = split_n.iloc[i]
                        new_rows.append(g_row_copy)
                        for rows in subgroup_rows_by_column.values():
                            rows.append(g_row_copy)
            if unresolved_authors:
                raise SystemExit(
                    "Duplicate subgroup rows could not be resolved safely for these study labels: "
                    + ", ".join(unresolved_authors)
                    + ". Use a reviewed mapping with analysis.conflict_resolution set to 'combine' or 'split' "
                    "only when the duplicated rows are truly compatible with that assumption."
                )
            r_df = pd.DataFrame(new_rows).reset_index(drop=True)
            r_df = r_df.drop(columns=["_study_group_label"], errors="ignore")
            if conflict_resolution == "combine" and valid_subgroups and subgroup_rows_by_column:
                subgroup_data_by_column = {}
                for subgroup in valid_subgroups:
                    subgroup_col = subgroup["r_column"]
                    subgroup_rows = subgroup_rows_by_column.get(subgroup_col) or []
                    if not subgroup_rows:
                        continue
                    subgroup_df = pd.DataFrame(subgroup_rows).reset_index(drop=True)
                    subgroup_df = subgroup_df.drop(columns=["_study_group_label"], errors="ignore")
                    subgroup_df["Author"] = make_unique_study_labels(subgroup_df["Author"].astype(str))
                    subgroup_data_by_column[subgroup_col] = subgroup_df
                if subgroup_data_by_column:
                    r_df.attrs["subgroup_data_by_column"] = subgroup_data_by_column
                mapping["subgroup_dataset_note"] = (
                    "Overall analysis uses Cochrane-combined multi-arm rows. Subgroup analyses use subgroup-specific "
                    "duplicate handling: rows are combined when duplicate comparisons belong to the same subgroup level, "
                    "and shared arms are split only when duplicate comparisons fall in different subgroup levels."
                )

    if format_type == "hr":
        r_df = r_df.dropna(subset=["Author", "TE", "seTE"])
        for col in ["TE", "seTE", "HR", "ci.lower", "ci.upper"]:
            if col in r_df.columns:
                r_df[col] = r_df[col].astype(float)
        invalid = r_df[(r_df["seTE"] <= 0) | ~r_df["TE"].apply(math.isfinite) | ~r_df["seTE"].apply(math.isfinite)]
        if not invalid.empty:
            raise SystemExit("Invalid HR data: log(HR) must be finite and SE(log HR) must be positive.")
        if {"HR", "ci.lower", "ci.upper"}.issubset(r_df.columns):
            ci_rows = r_df.dropna(subset=["HR", "ci.lower", "ci.upper"])
            invalid_ci = ci_rows[
                (ci_rows["HR"] <= 0)
                | (ci_rows["ci.lower"] <= 0)
                | (ci_rows["ci.upper"] <= 0)
                | (ci_rows["ci.lower"] >= ci_rows["ci.upper"])
                | (ci_rows["HR"] < ci_rows["ci.lower"])
                | (ci_rows["HR"] > ci_rows["ci.upper"])
            ]
            if not invalid_ci.empty:
                raise SystemExit("Invalid HR data: HR and CI limits must be positive, ordered, and contain the HR.")
    else:
        r_df = r_df.dropna(subset=["Author", "event.e", "n.e", "event.c", "n.c"])
        numeric_cols = ["event.e", "n.e", "event.c", "n.c"]
        for col in numeric_cols:
            r_df[col] = r_df[col].astype(float)
        invalid = r_df[
            (r_df["event.e"] < 0) | (r_df["event.c"] < 0)
            | (r_df["n.e"] <= 0) | (r_df["n.c"] <= 0)
            | (r_df["event.e"] > r_df["n.e"]) | (r_df["event.c"] > r_df["n.c"])
        ]
        if not invalid.empty:
            raise SystemExit("Invalid binary data: events must be nonnegative and no greater than totals.")
        if mapping.get("analysis", {}).get("conflict_resolution") != "split":
            non_integer = r_df[
                (r_df[numeric_cols].sub(r_df[numeric_cols].round()).abs() > 1e-8).any(axis=1)
            ]
            if not non_integer.empty:
                raise SystemExit("Invalid binary data: event counts and totals must be whole numbers.")
    if r_df.empty:
        raise SystemExit("No complete analysis rows remained after validation.")
    r_df["Author"] = make_unique_study_labels(r_df["Author"].astype(str))
    return r_df


def infer_analysis_from_data(r_df: pd.DataFrame, mapping: dict[str, Any], lm_mapping: dict[str, Any] | None) -> dict[str, str]:
    current = normalize_analysis_choices(mapping.get("analysis") or {}, mapping)
    if effect_format(mapping) == "hr" or {"TE", "seTE"}.issubset(r_df.columns):
        return {
            "summary_measure": "HR",
            "summary_measure_reason": (
                "Hazard Ratio was selected because the extracted data contain time-to-event "
                "effect estimates as log(HR) with standard errors."
            ),
            "pooling_method": "inverse",
            "pooling_method_reason": "Hazard ratios are pooled with generic inverse-variance meta-analysis.",
            "model_type": current.get("model_type", "random"),
            "model_type_reason": current.get(
                "model_type_reason",
                "Random-effects is the default for clinical meta-analysis when between-study heterogeneity is possible.",
            ),
            "tsa_alpha": current["tsa_alpha"],
            "tsa_power": current["tsa_power"],
            "tsa_adjust_for_diversity": current["tsa_adjust_for_diversity"],
            "tsa_effect_source": current["tsa_effect_source"],
            "tsa_anticipated_effect": current["tsa_anticipated_effect"],
            "tsa_required_information_size": current["tsa_required_information_size"],
            "tsa_control_event_proportion": current["tsa_control_event_proportion"],
            "tsa_intervention_event_proportion": current["tsa_intervention_event_proportion"],
            "tsa_favor_top": current["tsa_favor_top"],
            "tsa_favor_bottom": current["tsa_favor_bottom"],
            "tsa_reason": (
                "Trial sequential analysis is skipped for hazard-ratio inputs because this runner does not "
                "have arm-level event risks for binary TSA required-information-size calculations."
            ),
            **infer_favor_labels(mapping),
        }

    total_events = float(r_df["event.e"].sum() + r_df["event.c"].sum())
    total_n = float(r_df["n.e"].sum() + r_df["n.c"].sum())
    event_rate = total_events / total_n if total_n else 0.0
    median_arm_size = float(pd.Series(r_df[["n.e", "n.c"]].to_numpy().ravel()).median())
    zero_event_studies = int(((r_df["event.e"] == 0) | (r_df["event.c"] == 0)).sum())
    balance_ratio = (r_df[["n.e", "n.c"]].min(axis=1) / r_df[["n.e", "n.c"]].max(axis=1)).median()

    effect_size = str(current.get("summary_measure") or "RR")
    effect_reason = str(current.get("summary_measure_reason") or "")
    if effect_size not in {"RR", "OR", "RD"}:
        effect_size = "RR"
    if not effect_reason or effect_reason.startswith("Risk Ratio is generally preferred"):
        effect_reason = (
            "Risk Ratio is preferred for most clinical intervention/cohort datasets when raw intervention "
            "and control event counts are available."
        )
    sheet_hint = normalize_name(str(mapping.get("sheet_name", "")))
    if "casecontrol" in sheet_hint or "odds" in sheet_hint or "logistic" in sheet_hint:
        effect_size = "OR"
        effect_reason = "Odds Ratio was selected because the sheet name suggests odds, logistic, or case-control data."

    pooling = "inverse"
    pooling_reason = (
        f"Inverse variance was selected because the event rate is {event_rate:.1%} and median arm size is "
        f"{median_arm_size:.0f}, matching the PDF rule for common events or larger studies."
    )
    if effect_size != "RD" and event_rate < 0.01 and zero_event_studies == 0 and balance_ratio >= 0.8:
        pooling = "Peto"
        effect_size = "OR"
        effect_reason = "Odds Ratio was selected because Peto pooling can only be used with OR."
        pooling_reason = (
            f"Peto was selected because events are very rare ({event_rate:.1%}) and group sizes are balanced "
            f"(median smaller/larger arm ratio {balance_ratio:.2f}); per the PDF, Peto is only for very rare "
            "events with small effects and balanced groups."
        )
    elif event_rate < 0.05 or median_arm_size < 50 or zero_event_studies > 0:
        pooling = "MH"
        pooling_reason = (
            f"Mantel-Haenszel was selected because events are sparse ({event_rate:.1%}), median arm size is "
            f"{median_arm_size:.0f}, or zero-event arms are present in {zero_event_studies} studies, matching "
            "the PDF rule for few events or small samples."
        )

    model_type = str(current.get("model_type") or "random")
    model_reason = str(current.get("model_type_reason") or "")
    if pooling == "Peto":
        model_type = "common"
        model_reason = "Peto pooling is treated as a common/fixed-effect method, so the model was set to common."
    elif not model_reason or model_reason.startswith("Random-effects is the default"):
        model_type = "random"
        model_reason = (
            "Random-effects was selected because clinical meta-analyses commonly include between-study "
            "clinical or methodological differences; use common/fixed-effect only if one shared true "
            "effect is justified."
        )

    return {
        "summary_measure": effect_size,
        "summary_measure_reason": effect_reason,
        "pooling_method": pooling,
        "pooling_method_reason": pooling_reason,
        "model_type": model_type,
        "model_type_reason": model_reason,
        "tsa_alpha": current["tsa_alpha"],
        "tsa_power": current["tsa_power"],
        "tsa_adjust_for_diversity": current["tsa_adjust_for_diversity"],
        "tsa_effect_source": current["tsa_effect_source"],
        "tsa_anticipated_effect": current["tsa_anticipated_effect"],
        "tsa_required_information_size": current["tsa_required_information_size"],
        "tsa_control_event_proportion": current["tsa_control_event_proportion"],
        "tsa_intervention_event_proportion": current["tsa_intervention_event_proportion"],
        "tsa_favor_top": current["tsa_favor_top"],
        "tsa_favor_bottom": current["tsa_favor_bottom"],
        "tsa_reason": current["tsa_reason"],
        **infer_favor_labels(mapping),
    }


def show_extracted_data(r_df: pd.DataFrame, preview_rows: int, assume_yes: bool, extracted_path: Path) -> None:
    r_df.to_csv(extracted_path, index=False)
    print("\nExtracted analysis data")
    print("-----------------------")
    print(f"Rows extracted: {len(r_df)}")
    print(f"Saved copy: {extracted_path}")
    display_df = r_df.head(preview_rows)
    with pd.option_context("display.max_columns", None, "display.width", 160):
        print(display_df.to_string(index=False))
    if len(r_df) > preview_rows:
        print(f"... {len(r_df) - preview_rows} more rows not shown.")
    if assume_yes or not sys.stdin.isatty():
        return
    confirm = input("Run R meta-analysis with this extracted data? [Y/n]: ").strip().lower()
    if confirm in {"n", "no"}:
        raise SystemExit("Stopped before running R.")


def ensure_analysis_matches_extracted_data(r_df: pd.DataFrame, mapping: dict[str, Any]) -> None:
    summary_measure = str(mapping.get("analysis", {}).get("summary_measure") or "").upper()
    has_hr_data = {"TE", "seTE"}.issubset(r_df.columns)
    has_count_data = all(col in r_df.columns for col in ["event.e", "n.e", "event.c", "n.c"])
    if summary_measure == "HR" and not has_hr_data:
        raise SystemExit("Analysis choice HR requires HR/log(HR) columns; the extracted dataset only has binary arm counts.")
    if summary_measure != "HR" and not has_count_data:
        raise SystemExit("RR/OR/RD analyses require intervention/control event counts and totals; the extracted dataset only has HR data.")


def r_string(value: str) -> str:
    return json.dumps(value)


def write_covariate_skip_status_files(output_dir: Path, outcome: str, skip_notes: list[dict[str, Any]] | None) -> None:
    for note in skip_notes or []:
        covariate_label = str(note.get("source") or "Covariate")
        covariate_file_label = sanitize_filename(covariate_label, "Covariate")
        reason = str(note.get("reason") or "The covariate could not be used for meta-regression.")
        summary_path = output_dir / f"MetaregSummary - {covariate_file_label} - {outcome}.txt"
        status_path = output_dir / f"MetaregStatus - {covariate_file_label} - {outcome}.txt"
        summary_path.write_text(
            f"Meta-regression for {covariate_label} was skipped because {reason}\n",
            encoding="utf-8",
        )
        status_path.write_text(
            "\n".join(
                [
                    f"Outcome: {outcome}",
                    f"Regressor: {covariate_label}",
                    "Status: skipped",
                    f"Reason: {reason}",
                    f"Summary file: {summary_path.name}",
                ]
            )
            + "\n",
            encoding="utf-8",
        )


def metareg_r_block(covariate_info: list[dict[str, str]], ylab_code: str) -> str:
    block = ""
    for covariate in covariate_info:
        covariate_label = covariate["source"]
        covariate_r_column = covariate["r_column"]
        covariate_type = str(covariate.get("type") or "numeric")
        covariate_file_label = sanitize_filename(covariate_label, "Covariate")
        if covariate_type == "categorical":
            block += f"""
raw_cov_values <- trimws(as.character(data[[{r_string(covariate_r_column)}]]))
raw_cov_values[tolower(raw_cov_values) %in% c("", "na", "n/a", "nan", "none", "null")] <- NA
level_values <- unique(raw_cov_values[!is.na(raw_cov_values)])
cov_factor <- factor(raw_cov_values, levels = level_values)
complete_cov <- !is.na(cov_factor)
level_counts <- table(droplevels(cov_factor[complete_cov]))
metareg_summary_file <- file.path(output, paste0("MetaregSummary - {covariate_file_label} - ", outcome, ".txt"))
metareg_status_file <- file.path(output, paste0("MetaregStatus - {covariate_file_label} - ", outcome, ".txt"))
write_metareg_status <- function(status, reason) {{{{
  writeLines(c(
    paste0("Outcome: ", outcome),
    paste0("Regressor: ", {r_string(covariate_label)}),
    "Regressor type: categorical",
    paste0("Status: ", status),
    paste0("Reason: ", reason),
    paste0("Summary file: ", basename(metareg_summary_file))
  ), con = metareg_status_file)
}}}}
if (random_model && sum(complete_cov) >= 10 && length(level_counts) >= 2 && min(level_counts) >= 2) {{{{
  metareg_error <- NULL
  tryCatch({{{{
    data[[{r_string(covariate_r_column)}]] <- cov_factor
    mreg.object <- metareg(meta, as.formula(paste("~", {r_string(covariate_r_column)})))
    writeLines(c(
      paste("Categorical meta-regression for {covariate_label}"),
      "Reference level is the first level by workbook order.",
      "",
      "Level counts:",
      capture.output(level_counts),
      "",
      capture.output(summary(mreg.object))
    ), con = metareg_summary_file)
  }}}}, error = function(e) {{{{
    metareg_error <<- conditionMessage(e)
  }}}})
  if (!is.null(metareg_error)) {{{{
    reason <- paste("R meta::metareg failed:", metareg_error)
    writeLines(paste("Meta-regression for {covariate_label} was skipped because", reason), con = metareg_summary_file)
    write_metareg_status("failed", reason)
    message(paste("Meta-regression skipped for {covariate_label}:", reason))
  }}}} else {{{{
    reason <- "Categorical meta-regression completed; bubble plot was not generated because the moderator is a factor."
    write_metareg_status("completed_no_plot", reason)
  }}}}
}}}} else if (!random_model) {{{{
  reason <- "a common/fixed-effect model was selected."
  writeLines(paste("Meta-regression for {covariate_label} was skipped because", reason), con = metareg_summary_file)
  write_metareg_status("skipped", reason)
  message(paste("Meta-regression skipped for {covariate_label}:", reason))
}}}} else {{{{
  reason <- paste(
    "categorical meta-regression needs at least ten studies, at least two categories,",
    "and at least two studies in every retained category; observed counts:",
    paste(names(level_counts), as.integer(level_counts), sep = "=", collapse = ", ")
  )
  writeLines(paste("Meta-regression for {covariate_label} was skipped because", reason), con = metareg_summary_file)
  write_metareg_status("skipped", reason)
  message(paste("Meta-regression skipped for {covariate_label}:", reason))
}}}}
"""
            continue
        block += f"""
cov_values <- suppressWarnings(as.numeric(data[[{r_string(covariate_r_column)}]]))
metareg_summary_file <- file.path(output, paste0("MetaregSummary - {covariate_file_label} - ", outcome, ".txt"))
metareg_status_file <- file.path(output, paste0("MetaregStatus - {covariate_file_label} - ", outcome, ".txt"))
write_metareg_status <- function(status, reason) {{{{
  writeLines(c(
    paste0("Outcome: ", outcome),
    paste0("Regressor: ", {r_string(covariate_label)}),
    "Regressor type: numeric",
    paste0("Status: ", status),
    paste0("Reason: ", reason),
    paste0("Summary file: ", basename(metareg_summary_file))
  ), con = metareg_status_file)
}}}}
if (random_model && sum(is.finite(cov_values)) >= 10 && length(unique(cov_values[is.finite(cov_values)])) >= 2) {{{{
  metareg_error <- NULL
  plot_error <- NULL
  plot_open <- FALSE
  tryCatch({{{{
    data[[{r_string(covariate_r_column)}]] <- cov_values
    mreg.object <- metareg(meta, as.formula(paste("~", {r_string(covariate_r_column)})))
    capture.output(summary(mreg.object), file = metareg_summary_file)
    tryCatch({{{{
      png(file = file.path(output, paste0("Metarregression - {covariate_file_label} - ", outcome, ".png")),
          width = 2400,
          height = 2000,
          res = 300)
      plot_open <- TRUE
      bubble(mreg.object,
             xlab = {r_string(covariate_label)},
             ylab = {ylab_code},
             studlab = TRUE,
             bg = "red")
      dev.off()
      plot_open <- FALSE
    }}}}, error = function(e) {{{{
      plot_error <<- conditionMessage(e)
      if (plot_open && dev.cur() > 1) {{{{
        try(dev.off(), silent = TRUE)
        plot_open <<- FALSE
      }}}}
    }}}})
  }}}}, error = function(e) {{{{
    metareg_error <<- conditionMessage(e)
    if (plot_open && dev.cur() > 1) {{{{
      try(dev.off(), silent = TRUE)
      plot_open <<- FALSE
    }}}}
  }}}})
  if (!is.null(metareg_error)) {{{{
    reason <- paste("R meta::metareg failed:", metareg_error)
    writeLines(paste("Meta-regression for {covariate_label} was skipped because", reason), con = metareg_summary_file)
    write_metareg_status("failed", reason)
    message(paste("Meta-regression skipped for {covariate_label}:", reason))
  }}}} else if (!is.null(plot_error)) {{{{
    reason <- paste("Meta-regression completed, but the bubble plot failed:", plot_error)
    write_metareg_status("completed_with_plot_warning", reason)
    message(paste("Meta-regression plot warning for {covariate_label}:", reason))
  }}}} else {{{{
    write_metareg_status("completed", "Meta-regression completed successfully.")
  }}}}
}}}} else if (!random_model) {{{{
  reason <- "a common/fixed-effect model was selected."
  writeLines(paste("Meta-regression for {covariate_label} was skipped because", reason), con = metareg_summary_file)
  write_metareg_status("skipped", reason)
  message(paste("Meta-regression skipped for {covariate_label}:", reason))
}}}} else {{{{
  reason <- "fewer than ten finite study-level values or fewer than two unique values were available."
  writeLines(paste("Meta-regression for {covariate_label} was skipped because", reason), con = metareg_summary_file)
  write_metareg_status("skipped", reason)
  message(paste("Meta-regression skipped for {covariate_label}:", reason))
}}}}
"""
    return block


def write_hr_r_script(
    script_path: Path,
    csv_path: Path,
    output_dir: Path,
    outcome: str,
    subgroup_info: list[dict[str, str]],
    covariate_info: list[dict[str, str]],
    model_type: str,
    favor_left_label: str,
    favor_right_label: str,
    tsa_reason: str,
) -> None:
    subgroup_block = ""
    for subgroup in subgroup_info:
        subgroup_label = subgroup["source"]
        subgroup_r_column = subgroup["r_column"]
        subgroup_file_label = sanitize_filename(subgroup_label, "Subgroup")
        subgroup_block += f"""
data[[{r_string(subgroup_r_column)}]] <- factor(data[[{r_string(subgroup_r_column)}]])
subgroup <- metagen(TE = TE,
                    seTE = seTE,
                    studlab = Author,
                    data = data,
                    sm = "HR",
                    backtransf = TRUE,
                    method.tau = "REML",
                    method.random.ci = "classic",
                    method.I2 = "tau2",
                    random = random_model,
                    common = common_model,
                    prediction = random_model,
                    method.predict = "V",
                    subgroup = data[[{r_string(subgroup_r_column)}]],
                    subgroup.name = "Subgroup",
                    print.subgroup.name = TRUE,
                    sep.subgroup = " = ")

subgroup_levels <- unique(data[[{r_string(subgroup_r_column)}]][!is.na(data[[{r_string(subgroup_r_column)}]])])
plot_width <- 3800
plot_height <- max(2500, 1450 + 105 * nrow(data) + 300 * length(subgroup_levels))
png(file = file.path(output, paste0("Subgroup - {subgroup_file_label} - ", outcome, ".png")),
    width = plot_width,
    height = plot_height,
    res = 300)

forest(subgroup,
       layout = "Revman5",
       label.left = paste("Favors", {r_string(favor_left_label)}),
       label.right = paste("Favors", {r_string(favor_right_label)}),
       leftcols = c("studlab", weight_col, "effect", "ci"),
       leftlabs = c("Studies", "Weight (%)", "HR", "95% CI"),
       colgap = "3mm",
       colgap.forest.left = "8mm",
       colgap.forest.right = "8mm",
       col.square="darkblue",
       col.square.lines="black",
       sortvar = TE,
       subgroup.name = "Subgroup",
       print.subgroup.name = TRUE,
       sep.subgroup = " = ",
       subgroup.hetstat = TRUE,
       test.effect.subgroup.random = FALSE,
       test.effect.subgroup.common = FALSE,
       overall = TRUE,
       overall.hetstat = TRUE,
       test.overall.random = random_model,
       test.overall.common = common_model,
       test.subgroup.random = random_model,
       test.subgroup.common = common_model,
       fontsize = 8.5,
       fs.study = 8,
       fs.heading = 8.5,
       fs.axis = 8,
       spacing = 0.9,
       just.studlab = "left")

dev.off()
capture.output(summary(subgroup), file = file.path(output, paste0("SubgroupSummary - {subgroup_file_label} - ", outcome, ".txt")))
"""

    metareg_block = metareg_r_block(covariate_info, r_string("log(HR)"))

    script = f"""
suppressPackageStartupMessages(library(meta))

output <- {r_string(str(output_dir))}
outcome <- {r_string(outcome)}
model_type <- {r_string(model_type)}
random_model <- model_type == "random"
common_model <- model_type == "common"
weight_col <- if (random_model) "w.random" else "w.common"
dir.create(output, recursive = TRUE, showWarnings = FALSE)
data <- read.csv({r_string(str(csv_path))}, check.names = FALSE)
data$TE <- suppressWarnings(as.numeric(data$TE))
data$seTE <- suppressWarnings(as.numeric(data$seTE))
data <- data[is.finite(data$TE) & is.finite(data$seTE) & data$seTE > 0, ]
if (nrow(data) == 0) {{
  stop("No valid HR rows remained after R-side validation.")
}}

meta <- metagen(TE = TE,
                seTE = seTE,
                studlab = Author,
                data = data,
                sm = "HR",
                backtransf = TRUE,
                method.tau = "REML",
                method.random.ci = "classic",
                method.I2 = "tau2",
                random = random_model,
                common = common_model,
                prediction = random_model,
                method.predict = "V")

capture.output(summary(meta), file = file.path(output, paste0("Summary", outcome, ".txt")))
saveRDS(meta, file = file.path(output, paste0("MetaObject", outcome, ".rds")))

plot_width <- 3800
plot_height <- max(1900, 1100 + 95 * nrow(data))
png(file = file.path(output, paste0("Forestplot", outcome, ".png")),
    width = plot_width,
    height = plot_height,
    res = 300)

forest(meta,
       layout = "Revman5",
       label.left = paste("Favors", {r_string(favor_left_label)}),
       label.right = paste("Favors", {r_string(favor_right_label)}),
       leftcols = c("studlab", weight_col, "effect", "ci"),
       leftlabs = c("Studies", "Weight (%)", "HR", "95% CI"),
       test.overall.random = random_model,
       test.overall.common = common_model,
       colgap = "3mm",
       colgap.forest.left = "8mm",
       colgap.forest.right = "8mm",
       col.square="darkblue",
       col.square.lines="black",
       sortvar = TE,
       fontsize = 8.5,
       fs.study = 8,
       fs.heading = 8.5,
       fs.axis = 8,
       spacing = 0.9,
       just.studlab = "left")

dev.off()

{subgroup_block}

meta_loo <- metainf(meta, pooled = if (random_model) "random" else "common")
capture.output(summary(meta_loo), file = file.path(output, paste0("LeaveOneOutSummary", outcome, ".txt")))

png(file = file.path(output, paste0("Leave-one-out", outcome, ".png")),
    width = plot_width,
    height = plot_height,
    res = 300)

forest(meta_loo,
       col.bg="lightblue",
       col.diamond="gray",
       xlab=paste("Favors", {r_string(favor_left_label)}, "   Favors", {r_string(favor_right_label)}),
       ff.xlab = "bold",
       rightcols = c("effect", "ci", "I2","pval"),
       colgap.right = "6mm",
       just = "center",
       fontsize = 8.5,
       fs.study = 8,
       fs.axis = 8,
       spacing = 0.9)

dev.off()

png(file = file.path(output, paste0("FunnelPlot", outcome, ".png")),
    width = 2200,
    height = 2000,
    res = 300)
funnel(meta,
       studlab = FALSE,
       bg = "red",
       cex = 2,
       cex.studlab = 1,
       random = random_model,
       common = common_model,
       backtransf = FALSE)
dev.off()

if (meta$k >= 2) {{
  tmp_baujat <- tempfile(fileext = ".png")
  png(file = tmp_baujat, width = 400, height = 400)
  baujat_coords <- try(baujat(meta,
                              pooled = if (random_model) "random" else "common",
                              studlab = FALSE), silent = TRUE)
  dev.off()
  unlink(tmp_baujat)

  if (!inherits(baujat_coords, "try-error") && is.data.frame(baujat_coords) && nrow(baujat_coords) > 0) {{
    label_xmin <- if (nrow(baujat_coords) > 8) stats::quantile(baujat_coords$x, 0.75, na.rm = TRUE) else 0
    label_ymin <- if (nrow(baujat_coords) > 8) stats::quantile(baujat_coords$y, 0.75, na.rm = TRUE) else 0
    png(file = file.path(output, paste0("BaujatPlot", outcome, ".png")),
        width = 2400,
        height = 2200,
        res = 300)
    try(baujat(meta,
               pooled = if (random_model) "random" else "common",
               studlab = TRUE,
               cex = 1.3,
               cex.studlab = 0.75,
               pch = 21,
               col = "black",
               bg = "steelblue",
               xmin = label_xmin,
               ymin = label_ymin,
               xlab = "Contribution to overall heterogeneity",
               ylab = "Influence on pooled effect"), silent = TRUE)
    dev.off()
    write.csv(baujat_coords,
              file = file.path(output, paste0("BaujatCoordinates", outcome, ".csv")),
              row.names = FALSE)
    capture.output(baujat_coords,
                   file = file.path(output, paste0("BaujatCoordinates", outcome, ".txt")))
  }} else {{
    writeLines("Baujat plot skipped: insufficient valid data for contribution analysis.",
               con = file.path(output, paste0("BaujatCoordinates", outcome, ".txt")))
  }}
}}

tsa_dir <- file.path(output, paste0("TSA ", outcome))
dir.create(tsa_dir, recursive = TRUE, showWarnings = FALSE)
writeLines({r_string(tsa_reason)},
           con = file.path(tsa_dir, paste0("TSANotes", outcome, ".txt")))

if (meta$k >= 10) {{
  capture.output(metabias(meta, plotit = FALSE),
                 file = file.path(output, paste0("EggerTest", outcome, ".txt")))

  png(file = file.path(output, paste0("EggerTest", outcome, ".png")),
      width = 2200,
      height = 2000,
      res = 300)
  metabias(meta, plotit = TRUE)
  dev.off()
}}

{metareg_block}

writeLines(c(
  paste("Outcome:", outcome),
  paste("Effect measure: HR"),
  paste("Studies:", meta$k),
  paste("Statistical model:", model_type),
  paste("TSA:", {r_string(tsa_reason)}),
  paste("Output:", output)
), con = file.path(output, "run-info.txt"))
"""
    script_path.write_text(textwrap.dedent(script).strip() + "\n", encoding="utf-8")


def write_r_script(
    script_path: Path,
    csv_path: Path,
    output_dir: Path,
    outcome: str,
    intervention_label: str,
    control_label: str,
    subgroup_info: list[dict[str, str]],
    covariate_info: list[dict[str, str]],
    summary_measure: str,
    pooling_method: str,
    model_type: str,
    favor_left_label: str,
    favor_right_label: str,
    tsa_favor_top_label: str,
    tsa_favor_bottom_label: str,
    tsa_alpha: float,
    tsa_power: float,
    tsa_adjust_for_diversity: bool,
    tsa_effect_source: str,
    tsa_anticipated_effect: float | None,
    tsa_required_information_size: float | None,
    tsa_control_event_proportion: float | None,
    tsa_intervention_event_proportion: float | None,
    subgroup_only: bool = False,
    subgroup_csv_path: Path | None = None,
    subgroup_csv_paths: dict[str, Path] | None = None,
) -> None:
    if summary_measure == "HR":
        write_hr_r_script(
            script_path=script_path,
            csv_path=csv_path,
            output_dir=output_dir,
            outcome=outcome,
            subgroup_info=subgroup_info,
            covariate_info=covariate_info,
            model_type=model_type,
            favor_left_label=favor_left_label,
            favor_right_label=favor_right_label,
            tsa_reason=(
                "Trial sequential analysis is skipped for hazard-ratio inputs because this runner does not "
                "have arm-level event risks for binary TSA required-information-size calculations."
            ),
        )
        return

    subgroup_block = ""
    subgroup_csv_paths = subgroup_csv_paths or {}
    subgroup_note_lines = []
    for index, subgroup in enumerate(subgroup_info, start=1):
        subgroup_label = subgroup["source"]
        subgroup_r_column = subgroup["r_column"]
        subgroup_file_label = sanitize_filename(subgroup_label, "Subgroup")
        subgroup_csv = subgroup_csv_paths.get(subgroup_r_column) or subgroup_csv_path or csv_path
        subgroup_data_var = f"subgroup_data_{index}"
        subgroup_uses_adjusted_data = subgroup_csv != csv_path
        subgroup_overall = (not subgroup_only) and not subgroup_uses_adjusted_data
        if subgroup_uses_adjusted_data:
            subgroup_note_lines.append(
                f"{subgroup_label}: used subgroup-specific duplicate handling for multi-arm/shared-arm studies."
            )
        subgroup_block += f"""
	{subgroup_data_var} <- read.csv({r_string(str(subgroup_csv))}, check.names = FALSE)
	{subgroup_data_var} <- apply_binary_zero_event_policy({subgroup_data_var}, {r_string(subgroup_file_label)})
	{subgroup_data_var}[[{r_string(subgroup_r_column)}]] <- factor({subgroup_data_var}[[{r_string(subgroup_r_column)}]])
	subgroup <- metabin(event.e, n.e,
	                event.c,n.c,
	                studlab = Author,
	                data = {subgroup_data_var},
	                sm = summary_measure,
	                method = pooling_method,
	                incr = 0.5,
                method.incr = "only0",
                allstudies = TRUE,
                method.tau = "REML",
                method.random.ci = "classic",
                method.I2 = "tau2",
                random = random_model,
	                common = common_model,
	                prediction = random_model,
	                method.predict = "V",
	                subgroup = {subgroup_data_var}[[{r_string(subgroup_r_column)}]],
	                subgroup.name = "Subgroup",
	                print.subgroup.name = TRUE,
	                sep.subgroup = " = ")

	subgroup_levels <- unique({subgroup_data_var}[[{r_string(subgroup_r_column)}]][!is.na({subgroup_data_var}[[{r_string(subgroup_r_column)}]])])
	plot_width <- 3800
	plot_height <- max(2500, 1450 + 105 * nrow({subgroup_data_var}) + 300 * length(subgroup_levels))
	png(file = file.path(output, paste0("Subgroup - {subgroup_file_label} - ", outcome, ".png")),
	    width = plot_width,
	    height = plot_height,
    res = 300)

forest(subgroup,
       layout = "Revman5",
       label.e = {r_string(intervention_label)},
       label.c = {r_string(control_label)},
       label.left = paste("Favors", {r_string(favor_left_label)}),
       label.right = paste("Favors", {r_string(favor_right_label)}),
       leftcols = c("studlab",
                    "event.e", "n.e",
                    "event.c", "n.c",
                    weight_col,
                    "effect", "ci") ,
       leftlabs = c("Studies",
                    NA, NA,
                    NA, NA,
                    "Weight (%)",
                    "Effect size", "95% CI"),
       colgap = "3mm",
       colgap.forest.left = "8mm",
       colgap.forest.right = "8mm",
       pooled.events = TRUE,
       pooled.totals = TRUE,
       col.square="darkblue",
       col.square.lines="black",
       sortvar = TE,
       subgroup.name = "Subgroup",
       print.subgroup.name = TRUE,
       sep.subgroup = " = ",
       subgroup.hetstat = TRUE,
       test.effect.subgroup.random = FALSE,
       test.effect.subgroup.common = FALSE,
       overall = {str(subgroup_overall).upper()},
       overall.hetstat = {str(subgroup_overall).upper()},
       test.overall.random = random_model,
       test.overall.common = common_model,
       test.subgroup.random = random_model,
       test.subgroup.common = common_model,
       fontsize = 8.5,
       fs.study = 8,
       fs.heading = 8.5,
       fs.axis = 8,
       spacing = 0.9,
       just.studlab = "left")

	dev.off()
	subgroup_summary <- capture.output(summary(subgroup))
	if ({str(subgroup_uses_adjusted_data).upper()}) {{
	  subgroup_summary <- c(
	    "NOTE: This subgroup analysis uses subgroup-specific duplicate handling for multi-arm/shared-arm studies. Use the main Summary file for the primary Cochrane-combined overall pooled estimate.",
	    "",
	    subgroup_summary
	  )
}}
writeLines(subgroup_summary, con = file.path(output, paste0("SubgroupSummary - {subgroup_file_label} - ", outcome, ".txt")))
"""

    metareg_block = metareg_r_block(covariate_info, 'paste("Log", summary_measure)')
    subgroup_note_block = ""
    if subgroup_note_lines:
        subgroup_note_block = f"""
	writeLines(
	  c({", ".join(r_string(line) for line in subgroup_note_lines)}),
	  con = file.path(output, paste0("SubgroupDatasetNote", outcome, ".txt"))
	)
	"""

    # Compute RTSA weights from pooling method
    rtsa_weights_val = "IV" if pooling_method == "inverse" else "MH"

    script = f"""
suppressPackageStartupMessages(library(meta))

output <- {r_string(str(output_dir))}
outcome <- {r_string(outcome)}
summary_measure <- {r_string(summary_measure)}
pooling_method <- {r_string(pooling_method)}
model_type <- {r_string(model_type)}
tsa_alpha <- {float(tsa_alpha)}
tsa_power <- {float(tsa_power)}
tsa_adjust_for_diversity <- {str(bool(tsa_adjust_for_diversity)).upper()}
tsa_effect_source <- {r_string(tsa_effect_source)}
tsa_anticipated_effect <- {("NA_real_" if tsa_anticipated_effect is None else repr(float(tsa_anticipated_effect)))}
tsa_required_information_size <- {("NA_real_" if tsa_required_information_size is None else repr(float(tsa_required_information_size)))}
tsa_control_event_proportion <- {("NA_real_" if tsa_control_event_proportion is None else repr(float(tsa_control_event_proportion)))}
tsa_intervention_event_proportion <- {("NA_real_" if tsa_intervention_event_proportion is None else repr(float(tsa_intervention_event_proportion)))}
tsa_favor_top <- {r_string(tsa_favor_top_label)}
tsa_favor_bottom <- {r_string(tsa_favor_bottom_label)}
rtsa_weights <- {r_string(rtsa_weights_val)}
if (pooling_method == "Peto") {{
  model_type <- "common"
}}
random_model <- model_type == "random"
common_model <- model_type == "common"
weight_col <- if (random_model) "w.random" else "w.common"
	dir.create(output, recursive = TRUE, showWarnings = FALSE)
	data <- read.csv({r_string(str(csv_path))}, check.names = FALSE)
	{subgroup_note_block}

apply_binary_zero_event_policy <- function(dataset, dataset_label = "overall") {{
  if (!summary_measure %in% c("RR", "OR")) {{
    return(dataset)
  }}
  double_zero <- is.finite(dataset$event.e) & is.finite(dataset$event.c) &
    dataset$event.e == 0 & dataset$event.c == 0
  if (any(double_zero, na.rm = TRUE)) {{
    excluded <- dataset[double_zero, , drop = FALSE]
    excluded_file <- if (dataset_label == "overall") {{
      file.path(output, paste0("ExcludedDoubleZeroStudies", outcome, ".csv"))
    }} else {{
      file.path(output, paste0("ExcludedDoubleZeroStudies - ", dataset_label, " - ", outcome, ".csv"))
    }}
    write.csv(excluded, excluded_file, row.names = FALSE)
    note_file <- file.path(output, paste0("ZeroEventHandling", outcome, ".txt"))
    writeLines(
      c(
        "Cochrane zero-event handling for binary ratio effects:",
        "Single-zero studies are retained using a 0.5 continuity correction when needed.",
        "Double-zero studies are excluded for RR/OR because they do not estimate the direction or magnitude of a relative effect.",
        paste("Dataset:", dataset_label),
        paste("Excluded double-zero studies:", paste(excluded$Author, collapse = "; "))
      ),
      con = note_file,
      sep = "\n",
      useBytes = TRUE
    )
    dataset <- dataset[!double_zero, , drop = FALSE]
  }}
  dataset
}}

data <- apply_binary_zero_event_policy(data, "overall")

	build_binary_meta <- function(dataset, method_tau = "REML", method_random_ci = "classic") {{
	  metabin(event.e, n.e,
	                event.c,n.c,
	                studlab = Author,
	                data = dataset,
	                sm = summary_measure,
	                method = pooling_method,
	                incr = 0.5,
	                method.incr = "only0",
	                allstudies = TRUE,
	                method.tau = method_tau,
	                method.random.ci = method_random_ci,
	                method.I2 = "tau2",
	                random = random_model,
	                common = common_model,
	                prediction = random_model,
	                method.predict = "V")
	}}
	
	meta_metrics <- function(meta_obj, label) {{
	  scalar <- function(value) {{
	    value <- suppressWarnings(as.numeric(value))
	    if (length(value) == 0 || !is.finite(value[1])) return(NA_real_)
	    value[1]
	  }}
	  backtransform <- function(value) {{
	    value <- scalar(value)
	    if (!is.finite(value)) return(NA_real_)
	    if (summary_measure %in% c("RR", "OR")) return(exp(value))
	    value
	  }}
	  i2_value <- scalar(meta_obj$I2)
	  if (is.finite(i2_value) && abs(i2_value) <= 1) i2_value <- i2_value * 100
	  data.frame(
	    Analysis = label,
	    Studies = meta_obj$k,
	    PooledEffect = backtransform(if (random_model) meta_obj$TE.random else meta_obj$TE.common),
	    Lower95CI = backtransform(if (random_model) meta_obj$lower.random else meta_obj$lower.common),
	    Upper95CI = backtransform(if (random_model) meta_obj$upper.random else meta_obj$upper.common),
	    PValue = scalar(if (random_model) meta_obj$pval.random else meta_obj$pval.common),
	    I2Percent = i2_value,
	    Tau2 = scalar(meta_obj$tau2),
	    stringsAsFactors = FALSE
	  )
	}}
	
	meta <- build_binary_meta(data)

capture.output(summary(meta), file = file.path(output, paste0("Summary", outcome, ".txt")))
saveRDS(meta, file = file.path(output, paste0("MetaObject", outcome, ".rds")))

write_random_effects_sensitivity <- function(primary_meta, dataset) {{
  sensitivity_txt <- file.path(output, paste0("RandomEffectsSensitivity", outcome, ".txt"))
  sensitivity_csv <- file.path(output, paste0("RandomEffectsSensitivity", outcome, ".csv"))
  if (!random_model) {{
    writeLines(
      "Random-effects tau estimator / confidence interval sensitivity checks were skipped because a common-effect model was selected.",
      con = sensitivity_txt
    )
    return(invisible(NULL))
  }}
  sensitivity_specs <- data.frame(
    Analysis = c(
      "Primary REML + classic CI",
      "Sensitivity REML + Hartung-Knapp CI",
      "Sensitivity Paule-Mandel + Hartung-Knapp CI",
      "Sensitivity DerSimonian-Laird + classic CI"
    ),
    MethodTau = c("REML", "REML", "PM", "DL"),
    RandomEffectsCI = c("classic", "HK", "HK", "classic"),
    SummaryFileLabel = c(
      "Primary REML Classic",
      "Sensitivity REML Hartung-Knapp",
      "Sensitivity Paule-Mandel Hartung-Knapp",
      "Sensitivity DerSimonian-Laird Classic"
    ),
    stringsAsFactors = FALSE
  )
  rows <- list()
  for (i in seq_len(nrow(sensitivity_specs))) {{
    spec <- sensitivity_specs[i, , drop = FALSE]
    fit <- try(
      build_binary_meta(
        dataset,
        method_tau = spec$MethodTau,
        method_random_ci = spec$RandomEffectsCI
      ),
      silent = TRUE
    )
    if (inherits(fit, "try-error")) {{
      rows[[i]] <- data.frame(
        Analysis = spec$Analysis,
        Studies = NA_real_,
        PooledEffect = NA_real_,
        Lower95CI = NA_real_,
        Upper95CI = NA_real_,
        PValue = NA_real_,
        I2Percent = NA_real_,
        Tau2 = NA_real_,
        MethodTau = spec$MethodTau,
        RandomEffectsCI = spec$RandomEffectsCI,
        Status = paste("failed:", as.character(fit)[1]),
        stringsAsFactors = FALSE
      )
    }} else {{
      capture.output(
        summary(fit),
        file = file.path(output, paste0(spec$SummaryFileLabel, " - ", outcome, ".txt"))
      )
      rows[[i]] <- cbind(
        meta_metrics(fit, spec$Analysis),
        MethodTau = spec$MethodTau,
        RandomEffectsCI = spec$RandomEffectsCI,
        Status = "completed"
      )
    }}
  }}
  sensitivity <- do.call(rbind, rows)
  primary_effect <- sensitivity$PooledEffect[1]
  primary_i2 <- sensitivity$I2Percent[1]
  sensitivity$PooledEffectChangeVsPrimary <- sensitivity$PooledEffect - primary_effect
  sensitivity$I2ChangeVsPrimary <- sensitivity$I2Percent - primary_i2
  write.csv(sensitivity, file = sensitivity_csv, row.names = FALSE)
  capture.output(
    {{
      cat("Random-effects tau estimator / confidence interval sensitivity checks\\n")
      cat("Primary analysis remains REML + classic CI. Sensitivity rows are for robustness checks only.\\n\\n")
      print(sensitivity)
    }},
    file = sensitivity_txt
  )
}}

write_random_effects_sensitivity(meta, data)

plot_width <- 3800
plot_height <- max(1900, 1100 + 95 * nrow(data))
png(file = file.path(output, paste0("Forestplot", outcome, ".png")),
    width = plot_width,
    height = plot_height,
    res = 300)

forest(meta,
       layout = "Revman5",
       label.e = {r_string(intervention_label)},
       label.c = {r_string(control_label)},
       label.left = paste("Favors", {r_string(favor_left_label)}),
       label.right = paste("Favors", {r_string(favor_right_label)}),
       leftcols = c("studlab",
                    "event.e", "n.e",
                    "event.c", "n.c",
                    weight_col,
                    "effect", "ci") ,
       leftlabs = c("Studies",
                    NA, NA,
                    NA, NA,
                    "Weight (%)",
                    "Effect size", "95% CI"),
       test.overall.random = random_model,
       test.overall.common = common_model,
       colgap = "3mm",
       colgap.forest.left = "8mm",
       colgap.forest.right = "8mm",
       pooled.events = TRUE,
       pooled.totals = TRUE,
       col.square="darkblue",
       col.square.lines="black",
       sortvar = TE,
       overall = {str(not subgroup_only).upper()},
       overall.hetstat = {str(not subgroup_only).upper()},
       fontsize = 8.5,
       fs.study = 8,
       fs.heading = 8.5,
       fs.axis = 8,
       spacing = 0.9,
       just.studlab = "left")

dev.off()

{subgroup_block}

if ({str(not subgroup_only).upper()}) {{

meta_loo <- metainf(meta, pooled = if (random_model) "random" else "common")
capture.output(summary(meta_loo), file = file.path(output, paste0("LeaveOneOutSummary", outcome, ".txt")))

png(file = file.path(output, paste0("Leave-one-out", outcome, ".png")),
    width = plot_width,
    height = plot_height,
    res = 300)

forest(meta_loo,
       col.bg="lightblue",
       col.diamond="gray",
       xlab=paste("Favors", {r_string(favor_left_label)}, "   Favors", {r_string(favor_right_label)}),
       ff.xlab = "bold",
       rightcols = c("effect", "ci", "I2","pval"),
       colgap.right = "6mm",
       just = "center",
       fontsize = 8.5,
       fs.study = 8,
       fs.axis = 8,
       spacing = 0.9)

dev.off()

png(file = file.path(output, paste0("FunnelPlot", outcome, ".png")),
    width = 2200,
    height = 2000,
    res = 300)

funnel(meta,
       studlab = FALSE,
       bg = "red",
       cex = 2,
       cex.studlab = 1,
       random = random_model,
       common = common_model,
       backtransf = FALSE)
dev.off()

if (meta$k >= 2) {{
  tmp_baujat <- tempfile(fileext = ".png")
  png(file = tmp_baujat, width = 400, height = 400)
  baujat_coords <- try(baujat(meta,
                              pooled = if (random_model) "random" else "common",
                              studlab = FALSE), silent = TRUE)
  dev.off()
  unlink(tmp_baujat)

  if (!inherits(baujat_coords, "try-error") && is.data.frame(baujat_coords) && nrow(baujat_coords) > 0) {{
    label_xmin <- if (nrow(baujat_coords) > 8) stats::quantile(baujat_coords$x, 0.75, na.rm = TRUE) else 0
    label_ymin <- if (nrow(baujat_coords) > 8) stats::quantile(baujat_coords$y, 0.75, na.rm = TRUE) else 0
    png(file = file.path(output, paste0("BaujatPlot", outcome, ".png")),
        width = 2400,
        height = 2200,
        res = 300)
    try(baujat(meta,
               pooled = if (random_model) "random" else "common",
               studlab = TRUE,
               cex = 1.3,
               cex.studlab = 0.75,
               pch = 21,
               col = "black",
               bg = "steelblue",
               xmin = label_xmin,
               ymin = label_ymin,
               xlab = "Contribution to overall heterogeneity",
               ylab = "Influence on pooled effect"), silent = TRUE)
    dev.off()
    write.csv(baujat_coords,
              file = file.path(output, paste0("BaujatCoordinates", outcome, ".csv")),
              row.names = FALSE)
    capture.output(baujat_coords,
                   file = file.path(output, paste0("BaujatCoordinates", outcome, ".txt")))
  }} else {{
    writeLines("Baujat plot skipped: insufficient valid data for contribution analysis.",
               con = file.path(output, paste0("BaujatCoordinates", outcome, ".txt")))
  }}
}}


if (meta$k >= 10) {{
  capture.output(metabias(meta, plotit = FALSE),
                 file = file.path(output, paste0("EggerTest", outcome, ".txt")))

  png(file = file.path(output, paste0("EggerTest", outcome, ".png")),
      width = 2200,
      height = 2000,
      res = 300)
  metabias(meta, plotit = TRUE)
  dev.off()
}}

{metareg_block}

}} # end if not subgroup_only

{binary_tsa_r_code()}

writeLines(c(
  paste("Outcome:", outcome),
  paste("Studies:", meta$k),
  paste("Statistical model:", model_type),
  paste("Output:", output)
), con = file.path(output, "run-info.txt"))
"""
    script_path.write_text(textwrap.dedent(script).strip() + "\n", encoding="utf-8")


def run_r(script_path: Path, install_packages: bool = False) -> None:
    rscript = shutil.which("Rscript")
    if not rscript:
        raise SystemExit("Rscript was not found on PATH.")
    try:
        from meta_analysis_streamlit.install_r import ensure_r_packages

        ensure_r_packages(["meta"], install_missing=install_packages, rscript=rscript)
    except RuntimeError as exc:
        raise SystemExit(str(exc)) from exc
    completed = subprocess.run(
        [rscript, str(script_path)],
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        check=False,
    )
    if completed.stdout:
        print(completed.stdout)
    if completed.returncode != 0:
        raise SystemExit(f"R failed:\n{completed.stderr}")
    if completed.stderr:
        print(completed.stderr)


def crop_png_whitespace(path: Path, padding_ratio: float = 0.035) -> None:
    try:
        from PIL import Image, ImageChops
    except ImportError:
        return

    with Image.open(path) as image:
        rgba = image.convert("RGBA")
        background = Image.new("RGBA", rgba.size, (255, 255, 255, 255))
        diff = ImageChops.difference(rgba, background)
        mask = diff.convert("L").point(lambda pixel: 255 if pixel > 12 else 0)
        bbox = mask.getbbox()
        if not bbox:
            return
        pad = max(40, int(max(rgba.size) * padding_ratio))
        left   = max(0, bbox[0] - pad)
        top    = max(0, bbox[1] - pad)
        right  = min(rgba.size[0], bbox[2] + pad)
        bottom = min(rgba.size[1], bbox[3] + pad)
        cropped = rgba.crop((left, top, right, bottom))
        cropped.save(path)


def crop_output_pngs(output_dir: Path) -> None:
    for path in output_dir.rglob("*.png"):
        crop_png_whitespace(path)


def read_text_if_exists(path: Path) -> str:
    if not path.exists():
        return ""
    return path.read_text(encoding="utf-8", errors="replace")


def parse_overall_summary(summary_text: str) -> dict[str, str]:
    result: dict[str, str] = {}
    patterns = {
        "studies": r"Number of studies:\s+k\s+=\s+(\d+)",
        "observations": r"Number of observations:\s+(.+)",
        "events": r"Number of events:\s+(.+)",
        "heterogeneity": r"(tau\^2\s+=\s+.+)",
        "i2": r"(I\^2\s+=\s+.+)",
        "q": r"Test of heterogeneity:\s*\n\s*Q\s+d\.f\.\s+p-value\s*\n\s*([^\n]+)",
    }
    for key, pattern in patterns.items():
        match = re.search(pattern, summary_text, flags=re.I)
        if match:
            result[key] = " ".join(match.group(1).split())

    model_match = re.search(
        r"((?:Random effects|Common effect|Fixed effect) model)\s+"
        r"([-0-9.]+)\s+\[([-0-9.;\s]+)\]\s+([-0-9.]+)\s+([<>=]?\s*[0-9.]+)",
        summary_text,
        flags=re.I,
    )
    if model_match:
        result.update({
            "model":  model_match.group(1),
            "effect": model_match.group(2),
            "ci":     "[" + " ".join(model_match.group(3).split()) + "]",
            "z":      model_match.group(4),
            "p":      " ".join(model_match.group(5).split()),
        })
    return result


def parse_study_estimates(summary_text: str) -> list[dict[str, str]]:
    rows = []
    for line in summary_text.splitlines():
        match = re.match(r"^(.+?)\s+([-0-9.]+)\s+\[([-0-9.;\s]+)\]\s+([0-9.]+)\s*$", line)
        if match and not match.group(1).lower().startswith(("random", "common", "fixed")):
            rows.append({
                "Study":      match.group(1).strip(),
                "Effect":     match.group(2),
                "95% CI":     "[" + " ".join(match.group(3).split()) + "]",
                "Weight (%)": match.group(4),
            })
    return rows


def extract_egger_text(output_dir: Path, outcome: str) -> str:
    egger_text = read_text_if_exists(output_dir / f"EggerTest{outcome}.txt")
    if not egger_text:
        return "Small-study effects test was not performed because fewer than 10 studies were included."
    compact = " ".join(line.strip() for line in egger_text.splitlines() if line.strip())
    return compact or "Small-study effects test output was generated but did not contain printable text."


def add_docx_table(document: Any, headers: list[str], rows: list[list[Any]], style: str = "Table Grid") -> None:
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    from docx.oxml import OxmlElement
    from docx.oxml.ns import qn
    from docx.shared import Pt, RGBColor

    def shade_cell(cell: Any, fill: str) -> None:
        tc_pr = cell._tc.get_or_add_tcPr()
        shading = OxmlElement("w:shd")
        shading.set(qn("w:fill"), fill)
        tc_pr.append(shading)

    if not rows:
        paragraph = document.add_paragraph("No rows available.")
        paragraph.style = "Body Text"
        return
    table = document.add_table(rows=1, cols=len(headers))
    table.style = style
    table.autofit = True
    header_properties = table.rows[0]._tr.get_or_add_trPr()
    repeated_header = OxmlElement("w:tblHeader")
    repeated_header.set(qn("w:val"), "true")
    header_properties.append(repeated_header)
    for index, header in enumerate(headers):
        cell = table.rows[0].cells[index]
        cell.text = str(header)
        shade_cell(cell, "1F4E79")
        for paragraph in cell.paragraphs:
            paragraph.alignment = WD_ALIGN_PARAGRAPH.LEFT
            for run in paragraph.runs:
                run.font.bold = True
                run.font.color.rgb = RGBColor(255, 255, 255)
                run.font.size = Pt(8.8)
    for row in rows:
        cells = table.add_row().cells
        for index, value in enumerate(row):
            cells[index].text = "" if pd.isna(value) else str(value)
            for paragraph in cells[index].paragraphs:
                for run in paragraph.runs:
                    run.font.color.rgb = RGBColor(0, 0, 0)
                    run.font.size = Pt(8.6)
    document.add_paragraph()


def add_preformatted_block(document: Any, text: str, max_chars: int = 7000) -> None:
    if not text.strip():
        document.add_paragraph("No output available.")
        return
    text = text.strip()
    if len(text) > max_chars:
        text = text[:max_chars].rstrip() + "\n[Output truncated in this summary document; see the corresponding .txt file for full details.]"
    paragraph = document.add_paragraph()
    run = paragraph.add_run(text)
    run.font.name = "Courier New"
    run.font.size = document.styles["Body Text"].font.size


def manuscript_results_paragraph(
    mapping: dict[str, Any],
    overall: dict[str, str],
    egger_text: str,
    subgroup_count: int,
    leave_one_out_available: bool,
) -> str:
    measure = mapping["analysis"]["summary_measure"]
    method  = mapping["analysis"]["pooling_method"]
    model   = overall.get("model", "pooled model")
    studies = overall.get("studies", "the included")
    effect  = overall.get("effect", "[effect]")
    ci      = overall.get("ci", "[95% CI]")
    p_value = overall.get("p", "[p-value]")
    heterogeneity = overall.get("i2") or overall.get("heterogeneity", "heterogeneity statistics are shown in Table 1")
    subgroup_sentence = (
        f"Subgroup analyses were performed for {subgroup_count} subgroup variable(s). "
        if subgroup_count else "No subgroup analysis was performed because no subgroup variable was selected. "
    )
    loo_sentence = (
        "Leave-one-out sensitivity analyses were generated to evaluate the influence of individual studies. "
        if leave_one_out_available else "Leave-one-out sensitivity analysis output was not available. "
    )
    egger_sentence = "Small-study effects/publication bias assessment: " + egger_text
    return (
        f"For {mapping.get('outcome_name', 'the binary outcome')}, {studies} studies were included in the "
        f"meta-analysis. Using {measure} as the effect measure and {method} pooling, the {model.lower()} "
        f"estimated a pooled effect of {effect} {ci} (p = {p_value}). Heterogeneity was quantified as "
        f"{heterogeneity}. {subgroup_sentence}{loo_sentence}{egger_sentence}"
    )


def generate_summary_document(
    output_dir: Path,
    mapping: dict[str, Any],
    r_df: pd.DataFrame,
) -> Path:
    try:
        from docx import Document
        from docx.enum.text import WD_ALIGN_PARAGRAPH
        from docx.shared import Inches, Pt, RGBColor
    except ImportError as exc:
        raise SystemExit(f"python-docx is required to create the manuscript summary document: {exc}") from exc

    outcome = str(mapping.get("outcome_name") or "binary outcome")
    safe_outcome = sanitize_filename(outcome)
    output_stem = str(mapping.get("outcome_file_stem") or safe_outcome)
    summary_text = read_text_if_exists(output_dir / f"Summary{output_stem}.txt")
    overall = parse_overall_summary(summary_text)
    study_rows = parse_study_estimates(summary_text)
    subgroup_files = sorted(output_dir.glob(f"SubgroupSummary*{output_stem}.txt"))
    leave_one_out_text = read_text_if_exists(output_dir / f"LeaveOneOutSummary{output_stem}.txt")
    egger_text = extract_egger_text(output_dir, output_stem)

    document = Document()
    section = document.sections[0]
    section.top_margin    = Inches(0.65)
    section.bottom_margin = Inches(0.65)
    section.left_margin   = Inches(0.65)
    section.right_margin  = Inches(0.65)

    styles = document.styles
    styles["Normal"].font.name    = "Arial"
    styles["Normal"].font.size    = Pt(9.5)
    styles["Body Text"].font.name = "Arial"
    styles["Body Text"].font.size = Pt(9.5)
    styles["Heading 1"].font.name  = "Arial"
    styles["Heading 1"].font.size  = Pt(15)
    styles["Heading 1"].font.bold  = True
    styles["Heading 1"].font.color.rgb = RGBColor(31, 78, 121)
    styles["Heading 2"].font.name  = "Arial"
    styles["Heading 2"].font.size  = Pt(12)
    styles["Heading 2"].font.bold  = True
    styles["Heading 2"].font.color.rgb = RGBColor(31, 78, 121)

    title = document.add_paragraph()
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    title_run = title.add_run("Binary Outcome Meta-Analysis Results Summary")
    title_run.bold = True
    title_run.font.size = Pt(17)
    subtitle = document.add_paragraph()
    subtitle.alignment = WD_ALIGN_PARAGRAPH.CENTER
    subtitle.add_run(f"Outcome: {outcome}").italic = True

    document.add_heading("Manuscript-Ready Results Draft", level=1)
    document.add_paragraph(
        manuscript_results_paragraph(
            mapping=mapping,
            overall=overall,
            egger_text=egger_text,
            subgroup_count=len(subgroup_files),
            leave_one_out_available=bool(leave_one_out_text.strip()),
        )
    )

    document.add_heading("Analysis Decisions", level=1)
    decision_rows = [
        ["Effect measure", mapping["analysis"]["summary_measure"], mapping["analysis"]["summary_measure_reason"]],
        ["Pooling method", mapping["analysis"]["pooling_method"], mapping["analysis"]["pooling_method_reason"]],
        ["Statistical model", mapping["analysis"]["model_type"], mapping["analysis"]["model_type_reason"]],
        ["Outcome direction", mapping["analysis"]["outcome_direction"], mapping["analysis"]["favor_label_reason"]],
        ["Left/right labels", f"Left: Favors {mapping['analysis']['favor_left']}; Right: Favors {mapping['analysis']['favor_right']}", ""],
        [
            "Trial sequential analysis",
            (
                f"alpha {mapping['analysis']['tsa_alpha']}; power {mapping['analysis']['tsa_power']}; "
                f"{'diversity-adjusted RIS' if mapping['analysis']['tsa_adjust_for_diversity'] else 'heterogeneity-adjusted RIS (tau2)'}; "
                f"effect source {mapping['analysis']['tsa_effect_source']}"
                + (f"; RIS override {mapping['analysis']['tsa_required_information_size']}"
                   if mapping["analysis"].get("tsa_required_information_size") else "")
            ),
            mapping["analysis"]["tsa_reason"],
        ],
        ["TSA favour labels", f"Top: Favours {mapping['analysis']['tsa_favor_top']}; Bottom: Favours {mapping['analysis']['tsa_favor_bottom']}", ""],
        ["Model details", "If random-effects is selected, tau² is estimated by REML with classic random-effects CI.", ""],
    ]
    add_docx_table(document, ["Decision", "Selected", "Reason"], decision_rows)

    document.add_heading("Overall Pooled Analysis", level=1)
    overall_rows = [
        ["Studies",       overall.get("studies", "")],
        ["Observations",  overall.get("observations", "")],
        ["Events",        overall.get("events", "")],
        ["Model",         overall.get("model", "")],
        ["Pooled effect", overall.get("effect", "")],
        ["95% CI",        overall.get("ci", "")],
        ["Z / P value",   f"{overall.get('z', '')} / {overall.get('p', '')}".strip(" /")],
        ["Heterogeneity", overall.get("heterogeneity", "")],
        ["I² / H",        overall.get("i2", "")],
        ["Q test",        overall.get("q", "")],
    ]
    add_docx_table(document, ["Metric", "Result"], overall_rows)

    random_effects_sensitivity_csv = output_dir / f"RandomEffectsSensitivity{output_stem}.csv"
    random_effects_sensitivity_txt = output_dir / f"RandomEffectsSensitivity{output_stem}.txt"
    if random_effects_sensitivity_csv.exists() or random_effects_sensitivity_txt.exists():
        document.add_heading("Random-Effects Method Sensitivity Checks", level=1)
        document.add_paragraph(
            "Primary analysis remains REML with a classic random-effects confidence interval. "
            "The sensitivity checks compare Hartung-Knapp confidence intervals and alternative tau² estimators."
        )
        if random_effects_sensitivity_csv.exists():
            sensitivity_df = pd.read_csv(random_effects_sensitivity_csv)
            add_docx_table(document, list(sensitivity_df.columns), sensitivity_df.values.astype(str).tolist())
        elif random_effects_sensitivity_txt.exists():
            add_preformatted_block(document, read_text_if_exists(random_effects_sensitivity_txt), max_chars=5000)

    if study_rows:
        document.add_heading("Study-Level Effect Estimates", level=1)
        add_docx_table(
            document,
            ["Study", "Effect", "95% CI", "Weight (%)"],
            [[row["Study"], row["Effect"], row["95% CI"], row["Weight (%)"]] for row in study_rows],
        )

    document.add_heading("Subgroup Analysis", level=1)
    if subgroup_files:
        document.add_paragraph("Subgroup summary output from R is included below for manuscript drafting and audit.")
        for subgroup_file in subgroup_files:
            document.add_heading(subgroup_file.stem.replace("SubgroupSummary - ", ""), level=2)
            add_preformatted_block(document, read_text_if_exists(subgroup_file), max_chars=6000)
    else:
        document.add_paragraph("No subgroup analysis was generated.")

    document.add_heading("Leave-One-Out Sensitivity Analysis", level=1)
    add_preformatted_block(document, leave_one_out_text, max_chars=8000)

    document.add_heading("Baujat Influence Diagnostics", level=1)
    baujat_path = output_dir / f"BaujatCoordinates{output_stem}.csv"
    if baujat_path.exists():
        baujat_df = pd.read_csv(baujat_path)
        if {"x", "y"}.issubset(baujat_df.columns):
            baujat_df = baujat_df.sort_values(["x", "y"], ascending=False)
        document.add_paragraph(
            "The Baujat plot shows each study's contribution to overall heterogeneity on the x-axis "
            "and influence on the pooled effect on the y-axis."
        )
        add_docx_table(
            document,
            ["Study", "Contribution to Heterogeneity", "Influence on Pooled Effect"],
            [
                [row.get("studlab", ""), f"{float(row.get('x', 0)):.4f}", f"{float(row.get('y', 0)):.4f}"]
                for _, row in baujat_df.head(25).iterrows()
            ],
        )
    else:
        document.add_paragraph("Baujat diagnostics were not available.")

    document.add_heading("Trial Sequential Analysis", level=1)
    tsa_dir = output_dir / f"TSA {output_stem}"
    tsa_parameters_path = tsa_dir / f"TSAParameters{output_stem}.csv"
    tsa_z_path          = tsa_dir / f"TSAZCurveData{output_stem}.csv"
    if tsa_parameters_path.exists():
        tsa_parameters = pd.read_csv(tsa_parameters_path)
        add_docx_table(document, ["Parameter", "Value"], tsa_parameters.values.astype(str).tolist())
        if tsa_z_path.exists():
            tsa_z = pd.read_csv(tsa_z_path)
            document.add_paragraph("Cumulative Z-curve data are shown below for audit and manuscript drafting.")
            add_docx_table(
                document,
                ["Study", "Cumulative information", "Cumulative Z"],
                [
                    [row.get("Study", ""),
                     f"{float(row.get('CumulativeInformation', 0)):.0f}",
                     f"{float(row.get('CumulativeZ', 0)):.3f}"]
                    for _, row in tsa_z.iterrows()
                ],
            )
    else:
        document.add_paragraph("Trial sequential analysis output was not available.")

    document.add_heading("Small-Study Effects / Publication Bias", level=1)
    document.add_paragraph(egger_text)

    document.add_heading("Generated Figures and Files", level=1)
    figure_rows = [[str(path.relative_to(output_dir)), str(path)] for path in sorted(output_dir.rglob("*.png"))]
    add_docx_table(document, ["Figure", "File path"], figure_rows)

    document.add_heading("Extracted Analysis Dataset", level=1)
    preview_df = r_df.copy()
    max_rows = 60
    if len(preview_df) > max_rows:
        document.add_paragraph(
            f"Showing the first {max_rows} of {len(preview_df)} rows. See extracted-binary-data.csv for the full dataset."
        )
        preview_df = preview_df.head(max_rows)
    add_docx_table(document, list(preview_df.columns), preview_df.values.astype(str).tolist())

    document.add_heading("Reporting Guidance Note", level=1)
    document.add_paragraph(
        "This summary is organized to support a manuscript Results section by reporting the pooled effect "
        "estimate with its confidence interval, heterogeneity, subgroup analyses, sensitivity analyses, and "
        "small-study effects assessment when available. This structure follows commonly used PRISMA 2020 and "
        "Cochrane reporting expectations for meta-analyses."
    )
    document.add_paragraph(
        "Guidance checked: PRISMA 2020 checklist "
        "(https://www.prisma-statement.org/s/PRISMA_2020_checklist-ab3g.pdf); "
        "Cochrane Handbook Chapter 10 "
        "(https://www.cochrane.org/authors/handbooks-and-manuals/handbook/current/chapter-10); "
        "Cochrane Handbook Chapter III "
        "(https://www.cochrane.org/authors/handbooks-and-manuals/handbook/current/chapter-iii)."
    )

    docx_path = output_dir / f"Manuscript Results Summary - {safe_outcome}.docx"
    document.save(docx_path)
    return docx_path


LAST_PATH_FILE = Path("~/.meta_analysis_last_path").expanduser()


def get_last_used_path() -> Path | None:
    if LAST_PATH_FILE.exists():
        try:
            path_str = LAST_PATH_FILE.read_text(encoding="utf-8").strip()
            if path_str:
                return Path(path_str)
        except Exception:
            pass
    return None


def save_last_used_path(path: Path) -> None:
    try:
        LAST_PATH_FILE.write_text(str(path.resolve()), encoding="utf-8")
    except Exception:
        pass


def prompt_for_excel_path() -> Path:
    if not sys.stdin.isatty():
        raise SystemExit(
            "Missing Excel file path. Example:\n"
            "  python3 binary_outcome.py \"/path/to/your/data.xlsx\""
        )

    last_path = get_last_used_path()
    if last_path and last_path.exists():
        print(f"\nPrevious file: {last_path}")
        use_last = input("Use this file again? [Y/n]: ").strip().lower()
        if use_last in {"", "y", "yes"}:
            return last_path

    value = input("Excel workbook path: ").strip()
    if not value:
        raise SystemExit(
            "No Excel file path provided. Example:\n"
            "  python3 binary_outcome.py \"/path/to/your/data.xlsx\""
        )
    path = Path(value.strip("'\""))
    save_last_used_path(path)
    return path


def main() -> None:
    parser = argparse.ArgumentParser(
        description="LMStudio-assisted binary endpoint meta-analysis runner."
    )
    parser.add_argument("excel", type=Path, nargs="?", help="Input Excel workbook.")
    parser.add_argument("--sheet",       help="Sheet name to analyze.")
    parser.add_argument("--outcome",     help="Outcome name used in output filenames/titles.")
    parser.add_argument(
        "--output-dir", type=Path,
        help="Output folder. Defaults to a folder named after the chosen sheet beside the Excel file.",
    )
    parser.add_argument(
        "--preview-rows", type=int, default=50,
        help="Number of extracted rows to show before running the analysis.",
    )
    parser.add_argument("--yes",          action="store_true", help="Accept identified mapping without prompts.")
    parser.add_argument("--no-lmstudio", action="store_true", help="Skip LMStudio and use name matching.")
    parser.add_argument("--mapping-json", type=Path, help="Use a previously reviewed mapping/analysis JSON file.")
    parser.add_argument("--install-r-packages", action="store_true", help="Install missing CRAN R packages before running R.")
    parser.add_argument("--group-column", help="Primary subgroup/group column name or number. Included first in subgroup analyses.")
    parser.add_argument("--subgroup-columns", help="Comma-separated subgroup column names or numbers. Use 'none' to clear.")
    parser.add_argument("--covariate-columns", help="Comma-separated meta-regression covariate column names or numbers. Use 'none' to clear.")
    parser.add_argument("--intervention-label", help="Override the intervention/experimental arm label used in plots.")
    parser.add_argument("--control-label", help="Override the control/comparator arm label used in plots.")
    parser.add_argument("--tsa-alpha", type=float, help="Override the two-sided TSA alpha, e.g. --tsa-alpha 0.05.")
    parser.add_argument("--tsa-power", type=float, help="Override TSA power, e.g. --tsa-power 0.90.")
    parser.add_argument("--tsa-ris",  type=float, help="Override the calculated TSA required information size, e.g. --tsa-ris 1068.")
    parser.add_argument("--tsa-pc",   type=float, help="Override the TSA control event proportion used for RIS, e.g. --tsa-pc 0.20.")
    parser.add_argument("--tsa-pt",   type=float, help="Override the TSA intervention event proportion used for RIS, e.g. --tsa-pt 0.10.")
    parser.add_argument(
        "--lmstudio-url",
        default=os.environ.get("LMSTUDIO_URL", "http://localhost:1234/v1"),
        help="LMStudio OpenAI-compatible base URL.",
    )
    parser.add_argument(
        "--model",
        default=os.environ.get("LMSTUDIO_MODEL"),
        help="LMStudio model id. If omitted, the first model from /v1/models is used.",
    )

    args = parser.parse_args()

    if args.excel is None:
        args.excel = prompt_for_excel_path()
    args.excel = args.excel.expanduser().resolve()
    save_last_used_path(args.excel)

    if not args.excel.exists():
        raise SystemExit(f"Input workbook not found: {args.excel}")

    _, summary = workbook_summary(args.excel)
    sheet_name = choose_sheet(summary, args.sheet, args.yes)
    df = load_sheet(args.excel, sheet_name)
    columns = [str(col) for col in df.columns]
    df.columns = columns

    mapping = None
    lm_mapping = None
    mapping_json_has_analysis = False
    if args.mapping_json:
        mapping = json.loads(args.mapping_json.expanduser().read_text(encoding="utf-8"))
        mapping_json_has_analysis = bool(mapping.get("analysis"))
        mapping["sheet_name"]   = mapping.get("sheet_name") or sheet_name
        mapping["outcome_name"] = args.outcome or mapping.get("outcome_name") or sheet_name
    elif not args.no_lmstudio:
        print(f"\nSending sheet '{sheet_name}' to LMStudio for binary endpoint extraction...")
        lm_mapping = call_lmstudio(
            summary={sheet_name: summary[sheet_name]},
            lmstudio_url=args.lmstudio_url,
            model=args.model,
        )

    if mapping is None:
        mapping = merge_mapping(columns, sheet_name, lm_mapping, args.outcome)
        if args.intervention_label:
            mapping["intervention_label"] = args.intervention_label
        if args.control_label:
            mapping["control_label"] = args.control_label
        mapping = prompt_for_mapping(mapping, columns, args.yes)
    if args.intervention_label:
        mapping["intervention_label"] = args.intervention_label
    if args.control_label:
        mapping["control_label"] = args.control_label
    mapping = apply_column_overrides(
        mapping,
        columns,
        group_column=args.group_column,
        subgroup_columns=args.subgroup_columns,
        covariate_columns=args.covariate_columns,
    )
    if has_hr_mapping(mapping) and not has_count_mapping(mapping):
        mapping["intervention_label"] = mapping.get("intervention_label") or "Exposure"
        mapping["control_label"]      = mapping.get("control_label") or "Comparator"
        mapping.setdefault("analysis", {})
        mapping["analysis"]["summary_measure"] = "HR"
    else:
        refresh_arm_labels_from_columns(mapping)
    prompt_for_arm_labels_if_needed(mapping, args.yes)
    mapping["analysis"] = normalize_analysis_choices(mapping.get("analysis") or {}, mapping)
    r_df = validate_data(df, mapping)
    if not mapping_json_has_analysis:
        mapping["analysis"] = infer_analysis_from_data(r_df, mapping, lm_mapping)
        mapping["analysis"] = normalize_analysis_choices(mapping["analysis"], mapping)
    if args.tsa_alpha is not None:
        if not 0.0001 <= args.tsa_alpha <= 0.5:
            raise SystemExit("--tsa-alpha must be between 0.0001 and 0.5.")
        mapping["analysis"]["tsa_alpha"] = args.tsa_alpha
        mapping["analysis"]["tsa_reason"] = "TSA alpha was provided with --tsa-alpha."
    if args.tsa_power is not None:
        if not 0.5 <= args.tsa_power <= 0.999:
            raise SystemExit("--tsa-power must be between 0.5 and 0.999.")
        mapping["analysis"]["tsa_power"] = args.tsa_power
        mapping["analysis"]["tsa_reason"] = "TSA power was provided with --tsa-power."
    mapping["analysis"] = normalize_analysis_choices(mapping["analysis"], mapping)
    mapping["analysis"] = prompt_for_analysis_choices(mapping["analysis"], args.yes)
    mapping["analysis"] = normalize_analysis_choices(mapping["analysis"], mapping)
    if args.tsa_alpha is not None:
        mapping["analysis"]["tsa_alpha"] = args.tsa_alpha
        mapping["analysis"]["tsa_reason"] = "TSA alpha was provided with --tsa-alpha."
    if args.tsa_power is not None:
        mapping["analysis"]["tsa_power"] = args.tsa_power
        mapping["analysis"]["tsa_reason"] = "TSA power was provided with --tsa-power."
    if args.tsa_ris is not None:
        mapping["analysis"]["tsa_required_information_size"] = args.tsa_ris
        mapping["analysis"]["tsa_reason"] = "Required information size was provided with --tsa-ris."
    if args.tsa_pc is not None:
        if not 0.0001 <= args.tsa_pc <= 0.9999:
            raise SystemExit("--tsa-pc must be between 0.0001 and 0.9999.")
        mapping["analysis"]["tsa_control_event_proportion"] = args.tsa_pc
        mapping["analysis"]["tsa_reason"] = "Control event proportion for RIS was provided with --tsa-pc."
    if args.tsa_pt is not None:
        if not 0.0001 <= args.tsa_pt <= 0.9999:
            raise SystemExit("--tsa-pt must be between 0.0001 and 0.9999.")
        mapping["analysis"]["tsa_intervention_event_proportion"] = args.tsa_pt
        mapping["analysis"]["tsa_reason"] = "Intervention event proportion for RIS was provided with --tsa-pt."
    mapping["analysis"] = normalize_analysis_choices(mapping["analysis"], mapping)
    ensure_analysis_matches_extracted_data(r_df, mapping)
    outcome_display = str(mapping.get("outcome_name") or "binary outcome")
    outcome_file_stem = sanitize_filename(outcome_display)
    mapping["outcome_file_stem"] = outcome_file_stem

    if args.output_dir:
        output_dir = args.output_dir.expanduser().resolve()
    else:
        output_dir = (args.excel.resolve().parent / sanitize_filename(sheet_name)).resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    mapping_path   = output_dir / "identified-columns.json"
    extracted_path = output_dir / "extracted-binary-data.csv"
    subgroup_data_by_column = r_df.attrs.get("subgroup_data_by_column")
    subgroup_extracted_paths: dict[str, Path] = {}
    if isinstance(subgroup_data_by_column, dict):
        subgroup_lookup = {
            item.get("r_column"): item
            for item in mapping.get("subgroup_r_columns", [])
            if item.get("r_column")
        }
        for subgroup_col, subgroup_data in subgroup_data_by_column.items():
            if not isinstance(subgroup_data, pd.DataFrame) or subgroup_data.empty:
                continue
            subgroup_label = subgroup_lookup.get(subgroup_col, {}).get("source") or subgroup_col
            subgroup_extracted_path = (
                output_dir
                / f"extracted-binary-subgroup-data-{sanitize_filename(str(subgroup_label), 'Subgroup')}.csv"
            )
            subgroup_data.to_csv(subgroup_extracted_path, index=False)
            subgroup_extracted_paths[str(subgroup_col)] = subgroup_extracted_path
    else:
        subgroup_data = r_df.attrs.get("subgroup_data")
        if isinstance(subgroup_data, pd.DataFrame) and not subgroup_data.empty:
            subgroup_extracted_path = output_dir / "extracted-binary-subgroup-data.csv"
            subgroup_data.to_csv(subgroup_extracted_path, index=False)
            subgroup_extracted_paths[""] = subgroup_extracted_path
    write_covariate_skip_status_files(output_dir, outcome_file_stem, mapping.get("covariate_skip_notes"))
    mapping_path.write_text(json.dumps(mapping, indent=2), encoding="utf-8")
    show_extracted_data(r_df, max(args.preview_rows, 1), args.yes, extracted_path)

    with tempfile.TemporaryDirectory(prefix="binary-outcome-") as tmp:
        tmp_path    = Path(tmp)
        script_path = tmp_path / "run_binary_meta.R"
        write_r_script(
            script_path=script_path,
            csv_path=extracted_path,
            output_dir=output_dir,
            outcome=outcome_file_stem,
            intervention_label=plot_safe_label(mapping.get("intervention_label") or "Experimental"),
            control_label=plot_safe_label(mapping.get("control_label") or "Control"),
            subgroup_info=[
                item for item in mapping.get("subgroup_r_columns", [])
                if item.get("r_column") in r_df.columns and r_df[item["r_column"]].notna().any()
            ],
            covariate_info=[
                item for item in mapping.get("covariate_r_columns", [])
                if item.get("r_column") in r_df.columns
                and r_df[item["r_column"]].notna().any()
            ],
            summary_measure=mapping["analysis"]["summary_measure"],
            pooling_method=mapping["analysis"]["pooling_method"],
            model_type=mapping["analysis"]["model_type"],
            favor_left_label=plot_safe_label(mapping["analysis"]["favor_left"]),
            favor_right_label=plot_safe_label(mapping["analysis"]["favor_right"]),
            tsa_favor_top_label=plot_safe_label(mapping["analysis"]["tsa_favor_top"]),
            tsa_favor_bottom_label=plot_safe_label(mapping["analysis"]["tsa_favor_bottom"]),
            tsa_alpha=mapping["analysis"]["tsa_alpha"],
            tsa_power=mapping["analysis"]["tsa_power"],
            tsa_adjust_for_diversity=mapping["analysis"]["tsa_adjust_for_diversity"],
            tsa_effect_source=mapping["analysis"]["tsa_effect_source"],
            tsa_anticipated_effect=mapping["analysis"]["tsa_anticipated_effect"],
            tsa_required_information_size=mapping["analysis"]["tsa_required_information_size"],
            tsa_control_event_proportion=mapping["analysis"]["tsa_control_event_proportion"],
            tsa_intervention_event_proportion=mapping["analysis"]["tsa_intervention_event_proportion"],
            subgroup_only=mapping["analysis"].get("subgroup_only", False),
            subgroup_csv_path=subgroup_extracted_paths.get(""),
            subgroup_csv_paths=subgroup_extracted_paths,
        )
        run_r(script_path, install_packages=args.install_r_packages)
        run_binary_tsa_analysis(
            data=r_df,
            output_dir=output_dir,
            outcome=outcome_file_stem,
            summary_measure=mapping["analysis"]["summary_measure"],
            pooling_method=mapping["analysis"]["pooling_method"],
            model_type=mapping["analysis"]["model_type"],
            tsa_alpha=mapping["analysis"]["tsa_alpha"],
            tsa_power=mapping["analysis"]["tsa_power"],
            tsa_adjust_for_diversity=mapping["analysis"]["tsa_adjust_for_diversity"],
            tsa_effect_source=mapping["analysis"]["tsa_effect_source"],
            tsa_anticipated_effect=mapping["analysis"]["tsa_anticipated_effect"],
            tsa_required_information_size=mapping["analysis"]["tsa_required_information_size"],
            tsa_control_event_proportion=mapping["analysis"]["tsa_control_event_proportion"],
            tsa_intervention_event_proportion=mapping["analysis"]["tsa_intervention_event_proportion"],
            subgroup_only=mapping["analysis"].get("subgroup_only", False),
        )
        crop_output_pngs(output_dir)
        summary_docx = generate_summary_document(output_dir, mapping, r_df)
        shutil.copyfile(script_path, output_dir / "generated_binary_meta_analysis.R")

    print(f"\nDone. Outputs saved to: {output_dir}")
    print(f"Column mapping saved to: {mapping_path}")
    print(f"Manuscript summary saved to: {summary_docx}")


if __name__ == "__main__":
    main()
