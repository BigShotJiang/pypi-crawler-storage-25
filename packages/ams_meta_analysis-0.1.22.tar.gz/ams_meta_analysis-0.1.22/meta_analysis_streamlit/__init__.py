"""Installable Streamlit wrapper for the meta-analysis runner toolkit."""

from __future__ import annotations

__version__ = "0.1.22"
