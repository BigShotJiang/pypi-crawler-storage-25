from distutils.core import setup
from setuptools import find_packages

with open('README.rst', 'r', encoding="utf-8") as f:
    long_description = f.read()

# warning!
# for pymongo==4.7.3 and mongo version 7.0
# if you want to use old version, switch branch to mongo4

setup(name='fast_web_core',
      version='2.0.0',
      description='fast web core for zsodata',
      long_description=long_description,
      long_description_content_type='text/plain',
      author='zsodata',
      author_email='team@zso.io',
      url='http://www.zsodata.com',
      install_requires=[
          'fastapi==0.115.12',
          'starlette==0.46.2',
          'uvicorn==0.34.2',
          'pydantic==2.11.3',
          'python-dotenv==0.19.0',
          'python-multipart==0.0.20',
          'pymongo==4.7.3',
          'motor==3.5.0',
          'redis==5.0.7',
          'python-dateutil==2.8.2',
          'pytz==2024.1',
          'cryptography==44.0.2',
          'oss2==2.12.1',
          'aio-pika==9.5.5',
          'tenacity==9.1.2',
      ],
      python_requires='>=3.7',
      license='BSD License',
      packages=find_packages(),
      platforms=['all'],
      include_package_data=True,
      classifiers=[
          'Development Status :: 4 - Beta',
          'Intended Audience :: Developers',
          'License :: OSI Approved :: BSD License',
          'Operating System :: OS Independent',
          'Programming Language :: Python :: 3',
          'Programming Language :: Python :: 3.7',
          'Programming Language :: Python :: 3.8',
          'Programming Language :: Python :: 3.9',
          'Programming Language :: Python :: 3.10',
          'Programming Language :: Python :: 3.11',
          'Topic :: Software Development :: Libraries :: Python Modules',
      ],
      keywords='fastapi web core framework async mongodb redis',
      project_urls={
          'Source': 'http://www.zsodata.com',
      },
      )
