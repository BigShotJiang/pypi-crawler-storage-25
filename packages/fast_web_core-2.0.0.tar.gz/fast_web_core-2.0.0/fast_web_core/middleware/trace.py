# encoding: utf-8

import uuid
import logging
from starlette.requests import Request
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.responses import Response

logger = logging.getLogger(__name__)


class TraceMiddleware(BaseHTTPMiddleware):
    """
    链路追踪 ID 中间件（公共库）
    - 为每个请求生成唯一的 trace_id（格式：xxxxxxxx）
    - 优先使用客户端传入的 X-Trace-ID 或 X-Request-ID 请求头
    - 将 trace_id 存储到 request.state 供业务代码使用
    - 在响应头中返回 X-Trace-ID
    - 提供 get_trace_id() 工具函数获取当前请求的追踪 ID

    用法:
        from fast_web_core.middleware.trace_id import TraceMiddleware, get_trace_id

        # 注册中间件
        app.add_middleware(TraceMiddleware)

        # 在业务代码中获取 trace_id
        trace_id = get_trace_id(request)
    """

    async def dispatch(self, request: Request, call_next) -> Response:
        # 优先使用客户端传入的 trace_id（支持 X-Trace-ID 和 X-Request-ID 两种请求头）
        trace_id = request.headers.get('X-Trace-ID', '')
        if not trace_id:
            trace_id = request.headers.get('X-Request-ID', '')
        if not trace_id:
            # 生成短版本 UUID（8 位）
            trace_id = str(uuid.uuid4())[:8]

        # 存储到 request state
        request.state.trace_id = trace_id

        # 处理请求
        response = await call_next(request)

        # 在响应头中返回 trace_id
        response.headers['X-Trace-ID'] = trace_id

        return response


def get_trace_id(request: Request) -> str:
    """
    获取当前请求的 trace_id

    用法:
        from fast_web_core.middleware.trace_id import get_trace_id
        trace_id = get_trace_id(request)

    :param request: Starlette Request 对象
    :return: trace_id 字符串，如果未设置则返回空字符串
    """
    return getattr(request.state, 'trace_id', '')
