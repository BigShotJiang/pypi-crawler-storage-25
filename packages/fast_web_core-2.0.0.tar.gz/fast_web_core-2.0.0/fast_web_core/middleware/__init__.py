from typing import List
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from starlette.middleware import Middleware

from .trace import TraceMiddleware


def register_middleware(app: FastAPI, middlewares: List[Middleware] = []):
    # 链路追踪 ID 中间件（最先注册，确保所有请求都有 trace_id）
    middlewares.insert(0, Middleware(TraceMiddleware))

    # 默认支持跨域
    middlewares.append(Middleware(CORSMiddleware, allow_credentials=True, allow_origins=['*'], allow_methods=["*"], allow_headers=["*"]))

    if middlewares:
        for middleware in middlewares:
            # if app.middleware_stack is not None:  # pragma: no cover
            #     raise RuntimeError("Cannot add middleware after an application has started")
            app.user_middleware.insert(0, middleware)
