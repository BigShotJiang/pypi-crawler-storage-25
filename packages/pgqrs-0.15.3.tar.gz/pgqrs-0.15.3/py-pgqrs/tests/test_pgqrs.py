import pytest
import pgqrs
import asyncio

from pgqrs import Run
from pgqrs.decorators import workflow, step


# Helper to setup a store and admin
async def setup_test(dsn, schema):
    config = pgqrs.Config(dsn, schema=schema)
    return await setup_test_with_config(config)

async def setup_test_with_config(config):
    store = await pgqrs.connect_with(config)
    admin = pgqrs.admin(store)
    await admin.install()
    await admin.verify()
    return store, admin


@pytest.mark.asyncio
async def test_basic_workflow(test_dsn, schema):
    """
    Test basic workflow: Install -> Create Queue -> Produce -> Consume -> Archive
    """
    store, admin = await setup_test(test_dsn, schema)
    await admin.verify()

    queue_name = "test_queue_1"
    await store.queue(queue_name)

    queues = await store.get_queues()
    assert await queues.count() == 1

    payload = {"data": "test_payload", "id": 123}
    msg_id = await pgqrs.produce(store, queue_name, payload)
    assert msg_id > 0

    messages = await store.get_messages()
    assert await messages.count() == 1

    consumer = await store.consumer(queue_name)
    received_msgs = []
    for _ in range(10):
        batch = await pgqrs.dequeue(consumer, 1)
        if batch:
            received_msgs.extend(batch)
            break
        await asyncio.sleep(0.1)

    assert len(received_msgs) == 1
    msg = received_msgs[0]
    assert msg.id == msg_id
    assert msg.payload == payload

    await pgqrs.archive(consumer, msg)

    archived_msgs = await (await store.get_messages()).list_archived_by_queue(
        msg.queue_id
    )
    assert len(archived_msgs) == 1
    assert await messages.count() == 0


@pytest.mark.asyncio
async def test_consumer_archive(test_dsn, schema):
    """
    Test consumer delete (archive) functionality.
    """
    store, admin = await setup_test(test_dsn, schema)
    queue_name = "test_delete_queue"
    await store.queue(queue_name)

    producer = await store.producer(queue_name)
    consumer = await store.consumer(queue_name)

    payload = {"foo": "bar"}
    msg_id = await pgqrs.enqueue(producer, payload)

    msgs = await pgqrs.dequeue(consumer, 1)
    assert len(msgs) == 1
    msg = msgs[0]
    assert msg.id == msg_id

    await pgqrs.archive(consumer, msg)
    assert await (await store.get_messages()).count() == 0


@pytest.mark.asyncio
async def test_batch_operations(test_dsn, schema):
    """
    Test batch operations (enqueue_batch, dequeue, archive_batch).
    """
    store, admin = await setup_test(test_dsn, schema)
    queue_name = "batch_ops_test"
    await store.queue(queue_name)

    producer = await store.producer(queue_name)
    consumer = await store.consumer(queue_name)

    payloads = [{"id": i} for i in range(5)]
    msg_ids = await pgqrs.enqueue_batch(producer, payloads)
    assert len(msg_ids) == 5

    count = await (await store.get_messages()).count()
    assert count == 5

    batch = await pgqrs.dequeue(consumer, 3)
    assert len(batch) == 3

    await pgqrs.archive_batch(consumer, batch)

    count_after = await (await store.get_messages()).count()
    assert count_after == 2

    archived_msgs = await (await store.get_messages()).list_archived_by_queue(
        batch[0].queue_id
    )
    assert len(archived_msgs) == 3


@pytest.mark.asyncio
async def test_config_properties(test_dsn):
    c = pgqrs.Config(test_dsn)

    c.max_connections = 42
    assert c.max_connections == 42

    c.connection_timeout_seconds = 60
    assert c.connection_timeout_seconds == 60

    c.default_lock_time_seconds = 120
    assert c.default_lock_time_seconds == 120

    c.default_max_batch_size = 500
    assert c.default_max_batch_size == 500

    c.max_read_ct = 10
    assert c.max_read_ct == 10

    c.heartbeat_interval_seconds = 15
    assert c.heartbeat_interval_seconds == 15

    c.max_payload_size_bytes = 2048
    assert c.max_payload_size_bytes == 2048

    c.max_string_length = 256
    assert c.max_string_length == 256

    c.max_object_depth = 8
    assert c.max_object_depth == 8

    c.forbidden_keys = ["__proto__", "constructor", "forbidden"]
    assert c.forbidden_keys == ["__proto__", "constructor", "forbidden"]

    c.required_keys = ["job_id"]
    assert c.required_keys == ["job_id"]

    c.max_enqueue_per_second = None
    assert c.max_enqueue_per_second is None

    c.max_enqueue_burst = None
    assert c.max_enqueue_burst is None


@pytest.mark.asyncio
async def test_disable_enqueue_rate_limit_via_config(test_dsn, schema):
    config = pgqrs.Config(test_dsn, schema=schema)
    config.max_enqueue_per_second = None
    config.max_enqueue_burst = None

    store, admin = await setup_test_with_config(config)
    queue_name = "test_disable_enqueue_rate_limit_via_config"
    await store.queue(queue_name)

    producer = await store.producer(queue_name)
    payloads = [{"job": i} for i in range(200)]

    msg_ids = await pgqrs.enqueue_batch(producer, payloads)

    assert len(msg_ids) == len(payloads)


@pytest.mark.asyncio
async def test_connect_string(test_dsn):
    """Test connecting with a plain string DSN."""
    store = await pgqrs.connect(test_dsn)
    assert store is not None
    admin = pgqrs.admin(store)
    await admin.install()
    await admin.verify()


@pytest.mark.asyncio
async def test_enqueue_delayed(test_dsn, schema):
    """
    Test delayed message enqueueing.
    """
    store, admin = await setup_test(test_dsn, schema)
    queue_name = "test_delayed_queue"
    await store.queue(queue_name)

    producer = await store.producer(queue_name)
    consumer = await store.consumer(queue_name)

    payload = {"foo": "bar"}
    # Enqueue with 2 second delay
    await pgqrs.enqueue_delayed(producer, payload, 1)

    # Should not be available immediately
    msgs = await pgqrs.dequeue(consumer, 1)
    assert len(msgs) == 0

    await asyncio.sleep(1.2)

    # Should be available now
    msgs = await pgqrs.dequeue(consumer, 1)
    assert len(msgs) == 1


@pytest.mark.asyncio
async def test_worker_list_status(test_dsn, schema):
    store, admin = await setup_test(test_dsn, schema)
    queue_name = "worker_test_queue"
    await store.queue(queue_name)

    _ = await store.producer(queue_name)
    _ = await store.consumer(queue_name)

    workers_handle = await store.get_workers()
    worker_list = await workers_handle.list()
    assert len(worker_list) >= 2
    # Check status of first worker (should be ready or similar)
    assert worker_list[0].status == pgqrs.WorkerStatus.Ready


@pytest.mark.asyncio
async def test_consumer_delete(test_dsn, schema):
    """
    Test consumer delete (without archiving) functionality.
    """
    store, admin = await setup_test(test_dsn, schema)
    queue_name = "test_delete_logic_queue"
    await store.queue(queue_name)

    producer = await store.producer(queue_name)
    consumer = await store.consumer(queue_name)

    payload = {"foo": "bar"}
    msg_id = await pgqrs.enqueue(producer, payload)

    msgs = await pgqrs.dequeue(consumer, 1)
    assert len(msgs) == 1
    msg = msgs[0]

    # Delete it
    deleted = await consumer.delete(msg.id)
    assert deleted is True, f"Delete failed for message {msg.id}"

    # Verify it's gone from active messages
    active_count = await (await store.get_messages()).count()
    assert active_count == 0

    # Test deleting non-existent message
    deleted = await consumer.delete(999999)
    assert deleted is False, "Delete should return False for non-existent message"

    # Test deleting message not owned by consumer
    msg_id2 = await pgqrs.enqueue(producer, {"foo": "bar2"})
    # Do NOT dequeue it. Consumer does not own it.
    deleted = await consumer.delete(msg_id2)
    assert deleted is False, (
        "Delete should return False for message not owned/locked by consumer"
    )


@pytest.mark.asyncio
async def test_archive_advanced_methods(test_dsn, schema):
    store, admin = await setup_test(test_dsn, schema)
    queue_name = "archive_api_queue"
    await store.queue(queue_name)

    await pgqrs.produce(store, queue_name, {"foo": "bar"})
    consumer = await store.consumer(queue_name)
    msgs = await pgqrs.dequeue(consumer, 1)
    await pgqrs.archive(consumer, msgs[0])

    messages_table = await store.get_messages()
    archived_msgs = await messages_table.list_archived_by_queue(msgs[0].queue_id)
    assert len(archived_msgs) == 1

    # 1. Test get()
    # We need to list to find the ID of the archived message
    # We can use the consumer's ID since we exposed it.
    worker_id = consumer.worker_id

    # Filter archived messages by worker
    arch_msg = next(m for m in archived_msgs if m.consumer_worker_id == worker_id)

    # 2. Test count_by_worker - not directly available in Messages table yet, but we can filter
    assert len([m for m in archived_msgs if m.consumer_worker_id == worker_id]) == 1


@pytest.mark.asyncio
async def test_api_redesign_high_level(test_dsn, schema):
    """
    Test the high-level redesigned API: connect -> produce -> consume.
    """
    config = pgqrs.Config(test_dsn, schema=schema)
    store = await pgqrs.connect_with(config)

    admin = pgqrs.admin(store)
    await admin.install()
    await admin.verify()
    queue = "high_level_q"
    await store.queue(queue)

    payload = {"foo": "bar"}
    msg_id = await pgqrs.produce(store, queue, payload)
    assert msg_id > 0

    consumed = asyncio.Event()

    async def handler(msg):
        assert msg.payload == payload
        consumed.set()
        return True

    await pgqrs.consume(store, queue, handler)
    assert consumed.is_set()


@pytest.mark.asyncio
async def test_api_redesign_low_level(test_dsn, schema):
    """
    Test the low-level redesigned API: connect -> produce -> enqueue/dequeue/archive.
    """
    config = pgqrs.Config(test_dsn, schema=schema)
    store = await pgqrs.connect_with(config)
    admin = pgqrs.admin(store)
    await admin.install()
    queue = "low_level_q"
    await store.queue(queue)

    producer = await store.producer(queue)
    consumer = await store.consumer(queue)

    # Use low-level functions
    msg_id = await pgqrs.enqueue(producer, {"foo": "bar"})
    assert msg_id > 0

    msgs = await pgqrs.dequeue(consumer, 1)
    assert len(msgs) == 1
    assert msgs[0].id == msg_id

    # Use msg.id for archive? No, the archive pyfunction takes Quantitative message object
    await pgqrs.archive(consumer, msgs[0])

    messages_table = await store.get_messages()
    assert await messages_table.count() == 0
    archived_msgs = await messages_table.list_archived_by_queue(msgs[0].queue_id)
    assert len(archived_msgs) == 1


# --- Durable Workflow Tests ---


@step
async def step1(ctx: Run, msg: str):
    return f"processed_{msg}"


@step
async def step2(ctx: Run, val: str):
    return f"step2_{val}"


@workflow(name="simple_wf")
async def simple_wf(ctx: Run, arg: str):
    res1 = await step1(ctx, arg)
    res2 = await step2(ctx, res1)
    return res2


@pytest.mark.asyncio
async def test_workflow_execution(test_dsn, schema):
    store, admin = await setup_test(test_dsn, schema)
    wf_name = "simple_wf"
    wf_arg = "test_data"
    wf_ctx = await admin.create_workflow(wf_name, wf_arg)

    result = await simple_wf(wf_ctx, wf_arg)
    assert result == "step2_processed_test_data"


@pytest.mark.asyncio
async def test_extend_visibility(test_dsn, schema):
    """
    Test extending visibility timeout.
    """
    store, admin = await setup_test(test_dsn, schema)
    queue_name = "test_extend_vt_queue"
    await store.queue(queue_name)

    producer = await store.producer(queue_name)
    consumer = await store.consumer(queue_name)

    await pgqrs.enqueue(producer, {"foo": "bar"})

    # Dequeue
    msgs = await pgqrs.dequeue(consumer, 1)
    assert len(msgs) == 1
    msg = msgs[0]

    # Extend VT by 10 seconds
    await pgqrs.extend_vt(consumer, msg, 10)


@pytest.mark.asyncio
async def test_workflow_crash_recovery(test_dsn, schema):
    """
    Test workflow recovery.
    """
    store, admin = await setup_test(test_dsn, schema)
    wf_name = "recovery_wf"
    wf_arg = "crash_test"

    wf_ctx = await admin.create_workflow(wf_name, wf_arg)

    step1_called = 0
    step2_called = 0

    @step
    async def step_a(ctx, arg):
        nonlocal step1_called
        step1_called += 1
        return f"a_{arg}"

    @step
    async def step_b(ctx, arg):
        nonlocal step2_called
        step2_called += 1
        return f"b_{arg}"

    async def run_wf(ctx):
        res1 = await step_a(ctx, wf_arg)
        return res1

    await run_wf(wf_ctx)
    assert step1_called == 1

    async def run_wf_complete(ctx):
        res1 = await step_a(ctx, wf_arg)  # Skipped
        res2 = await step_b(ctx, res1)  # Executed
        return res2

    result = await run_wf_complete(wf_ctx)
    assert result == "b_a_crash_test"
    assert step1_called == 1
    assert step2_called == 1


@pytest.mark.asyncio
async def test_ephemeral_consume_success(test_dsn, schema):
    """
    Test that successful ephemeral consumption archives the message.
    """
    store, admin = await setup_test(test_dsn, schema)
    queue = "ephemeral_success_q"
    q_info = await store.queue(queue)

    payload = {"data": "test_success"}
    await pgqrs.produce(store, queue, payload)

    # Capture counts before consume
    messages_table = await store.get_messages()
    msgs_before = await messages_table.count()
    archived_msgs_before = await messages_table.list_archived_by_queue(q_info.id)
    archive_before = len(archived_msgs_before)

    consumed_event = asyncio.Event()

    async def handler(msg):
        assert msg.payload == payload
        consumed_event.set()
        return True

    await pgqrs.consume(store, queue, handler)
    assert consumed_event.is_set()

    # Verify message is no longer in THIS queue (by trying to dequeue)
    consumer = await store.consumer(queue)
    remaining_msgs = await consumer.dequeue(batch_size=10)
    assert len(remaining_msgs) == 0, (
        f"Expected no messages in queue, but found {len(remaining_msgs)}"
    )

    # Verify message was archived
    msgs_after = await messages_table.count()
    archived_msgs_after = await messages_table.list_archived_by_queue(q_info.id)
    archive_after = len(archived_msgs_after)
    assert msgs_after == msgs_before - 1, (
        "Message should be removed from active messages after successful consume"
    )
    assert archive_after == archive_before + 1, (
        "Message should be archived after successful consume"
    )


@pytest.mark.asyncio
async def test_ephemeral_consume_failure(test_dsn, schema):
    """
    Test that failed consumption (exception) does NOT archive the message.
    """
    store, admin = await setup_test(test_dsn, schema)
    queue = "ephemeral_fail_q"
    q_info = await store.queue(queue)

    payload = {"data": "test_fail"}
    await pgqrs.produce(store, queue, payload)

    # Capture counts before consume attempt
    messages_table = await store.get_messages()
    msgs_before = await messages_table.count()
    archived_msgs_before = await messages_table.list_archived_by_queue(q_info.id)
    archive_before = len(archived_msgs_before)

    async def handler(msg):
        raise ValueError("Simulated failure")

    with pytest.raises(ValueError, match="Simulated failure"):
        await pgqrs.consume(store, queue, handler)

    # Verify message count unchanged (not archived)
    msgs_after = await messages_table.count()
    archived_msgs_after = await messages_table.list_archived_by_queue(q_info.id)
    archive_after = len(archived_msgs_after)
    assert msgs_after == msgs_before, (
        "Message count should be unchanged after failed consume"
    )
    assert archive_after == archive_before, (
        "Archive count should be unchanged after failed consume"
    )


@pytest.mark.asyncio
async def test_ephemeral_consume_batch_success(test_dsn, schema):
    """
    Test that successful batch consumption archives all messages.
    """
    store, admin = await setup_test(test_dsn, schema)
    queue = "ephemeral_batch_success_q"
    q_info = await store.queue(queue)

    # Capture initial counts
    messages_table = await store.get_messages()
    archived_msgs_before = await messages_table.list_archived_by_queue(q_info.id)
    archive_before = len(archived_msgs_before)

    # Produce 3 messages using produce_batch to avoid multiple ephemeral workers
    payloads = [{"i": i} for i in range(3)]
    await pgqrs.produce_batch(store, queue, payloads)

    consumed_event = asyncio.Event()

    async def batch_handler(msgs):
        assert len(msgs) == 3, f"Expected 3 messages but got {len(msgs)}"
        consumed_event.set()
        return True

    await pgqrs.consume_batch(store, queue, 10, batch_handler)
    assert consumed_event.is_set()

    # Verify all messages from THIS queue are processed (none remaining)
    consumer = await store.consumer(queue)
    remaining_msgs = await consumer.dequeue(batch_size=10)
    assert len(remaining_msgs) == 0, (
        f"Expected no messages in queue, but found {len(remaining_msgs)}"
    )

    # Verify messages were archived
    archived_msgs_after = await messages_table.list_archived_by_queue(q_info.id)
    archive_after = len(archived_msgs_after)
    assert archive_after == archive_before + 3, (
        f"Expected 3 messages archived, but archive count increased by {archive_after - archive_before}"
    )


@pytest.mark.asyncio
async def test_ephemeral_consume_batch_failure(test_dsn, schema):
    """
    Test that failed batch consumption does NOT archive any messages.
    """
    store, admin = await setup_test(test_dsn, schema)
    queue = "ephemeral_batch_fail_q"
    q_info = await store.queue(queue)

    payloads = [{"i": i} for i in range(3)]
    await pgqrs.produce_batch(store, queue, payloads)

    # Capture counts before consume attempt
    messages_table = await store.get_messages()
    msgs_before = await messages_table.count()
    archived_msgs_before = await messages_table.list_archived_by_queue(q_info.id)
    archive_before = len(archived_msgs_before)

    async def batch_handler(msgs):
        raise ValueError("Simulated batch failure")

    with pytest.raises(ValueError, match="Simulated batch failure"):
        await pgqrs.consume_batch(store, queue, 10, batch_handler)

    # Verify message count unchanged (not archived)
    msgs_after = await messages_table.count()
    archived_msgs_after = await messages_table.list_archived_by_queue(q_info.id)
    archive_after = len(archived_msgs_after)
    assert msgs_after == msgs_before, (
        "Message count should be unchanged after failed batch consume"
    )
    assert archive_after == archive_before, (
        "Archive count should be unchanged after failed batch consume"
    )


@pytest.mark.asyncio
async def test_consume_stream_iterator(test_dsn, schema):
    """
    Test the consume_stream iterator and verification of ephemeral consumer cleanup.
    """
    store, admin = await setup_test(test_dsn, schema)
    queue_name = "stream_test_q"
    q_info = await store.queue(queue_name)

    received_count = 0

    async def consume_loop():
        nonlocal received_count
        async with store.consume_iter(queue_name, poll_interval_ms=10) as iterator:
            async for msg in iterator:
                received_count += 1
                # Verify archive method
                res = await iterator.archive(msg.id)
                assert res is True
                if received_count >= 5:
                    break

    # Produce messages FIRST
    producer = await store.producer(queue_name)
    for i in range(5):
        await pgqrs.enqueue(producer, {"i": i})

    consume_task = asyncio.create_task(consume_loop())

    await asyncio.wait_for(consume_task, timeout=5.0)
    assert received_count == 5

    # Verify messages are archived
    messages_table = await store.get_messages()
    archived_msgs = await messages_table.list_archived_by_queue(q_info.id)
    assert len(archived_msgs) == 5

    # Verify ephemeral consumer cleanup
    # Since we used context manager, cleanup (shutdown) should have happened explicitly upon exit.

    # Wait briefly for async shutdown to complete if needed
    await asyncio.sleep(0.5)

    # Check workers
    workers = await (await store.get_workers()).list()
    # Filter ephemeral workers that were consumers/producers (have queue_id)
    ephemeral_workers = [
        w
        for w in workers
        if w.name.startswith("__ephemeral__") and w.queue_id is not None
    ]

    # Verify that any ephemeral worker found is in 'stopped' status
    for w in ephemeral_workers:
        assert w.status == pgqrs.WorkerStatus.Stopped, (
            f"Ephemeral worker {w.id} should be stopped, but is {w.status}"
        )


@pytest.mark.asyncio
async def test_exceptions(test_dsn, schema):
    """
    Test that custom exceptions are raised and catchable.
    """
    store, admin = await setup_test(test_dsn, schema)

    # Test QueueNotFoundError
    qname = "non_existent_queue_abc"
    try:
        await admin.delete_queue(qname)
    except pgqrs.QueueNotFoundError:
        pass  # Expected if it failed
    except Exception:
        pass  # admin.delete_queue might return boolean false instead of error in some impls, but checking exception types here.

    # Tests connect with invalid DSN
    # This test assumes Postgres is enabled. If we are on SQLite-only build,
    # passing a postgres:// DSN will raise ConfigError, not ConnectionError.
    bad_dsn = "postgres://user:pass@non-existent-host-12345.local:5432/db"

    try:
        await pgqrs.connect(bad_dsn)
        pytest.fail("Should have raised an error")
    except (pgqrs.PgqrsConnectionError, pgqrs.ConfigError):
        # PgqrsConnectionError: Postgres enabled, but host unreachable
        # ConfigError: Postgres disabled, scheme not supported
        pass

    # Test create_queue on existing queue
    q2 = "existing_queue"
    await store.queue(q2)
    with pytest.raises(pgqrs.QueueAlreadyExistsError):
        await store.queue(q2)
