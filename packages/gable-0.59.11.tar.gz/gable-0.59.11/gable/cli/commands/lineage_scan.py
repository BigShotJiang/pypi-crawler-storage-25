import os
import shutil

import click
from click.core import Context as ClickContext
from loguru import logger

from gable.api.client import GableAPIClient
from gable.cli.helpers.data_asset import merge_dataflow_config_file_with_backend_config
from gable.cli.helpers.lineage import build_sca_args, ensure_npm, run_sca_and_capture
from gable.cli.helpers.npm import get_sca_cmd
from gable.cli.helpers.sca_run import (
    get_repo_name_from_git_info,
    run_sca_prime_and_capture,
    start_sca_run,
)
from gable.cli.options import global_options
from gable.openapi import CollectionMechanism, Type


@click.command(
    add_help_option=False,
    name="scan",
    epilog="""Example:
    gable lineage scan --project-root ./path/to/project --language java --build-command "mvn clean install" --java-version 17""",
)
@global_options(add_endpoint_options=False)
@click.option(
    "--project-root",
    help="The root directory of the project that will be analyzed.",
    type=click.Path(exists=True),
    required=True,
)
@click.option(
    "--language",
    help="The programming language of the project.",
    type=click.Choice(["java"]),
    default="java",
)
@click.option(
    "--build-command",
    help="The build command used to build the project (e.g. mvn clean install).",
    type=str,
    required=False,
)
@click.option(
    "--java-version",
    help="The version of Java used to build the project.",
    type=str,
    default="17",
    required=False,
)
@click.option(
    "--dataflow-config-file",
    type=click.Path(exists=True),
    help="The path to the dataflow config JSON file.",
    required=False,
)
@click.option(
    "--dataflow-config-files",
    help="Multi option for dataflow config files. Overridden by --dataflow-config-file.",
    multiple=True,
    required=False,
)
@click.option(
    "--schema-depth",
    help="The max depth of the schemas to be extracted.",
    type=int,
    required=False,
)
@click.option(
    "--output",
    type=click.Path(exists=False, file_okay=True, dir_okay=False),
    help="File path to output results.",
    required=False,
    default=os.path.join(os.getcwd(), "gable_lineage_scan_results.json"),
)
@click.option(
    "--sca-mode",
    type=click.Choice(["asset-detector", "prime"]),
    help="Select which sca backend to use for the scan",
    required=False,
    default="asset-detector",
)
@click.option(
    "--prime-annotation",
    help="Prime annotation used for analysis. Can be repeated.",
    type=str,
    multiple=True,
    required=False,
    hidden=True,
)
@click.option(
    "--prime-exclude-pattern",
    help="Prime exclusion pattern. Repeat the flag for multiple patterns.",
    type=str,
    multiple=True,
    required=False,
    hidden=True,
)
@click.option(
    "--prime-rules-file",
    help="Prime rules file path.",
    type=click.Path(exists=True),
    required=False,
    hidden=True,
)
@click.option(
    "--prime-debug",
    help="Enable prime debug mode.",
    is_flag=True,
    default=False,
    required=False,
    hidden=True,
)
@click.option(
    "--memopt-compress-program",  # prime mem opt
    help="Enable prime memory optimization",
    default=False,
    is_flag=True,
    required=False,
    hidden=True,
)
@click.pass_context
def lineage_scan(
    ctx: ClickContext,
    project_root: str,
    language: str,  # pylint: disable=unused-argument
    build_command: str,
    java_version: str,
    dataflow_config_file: str,
    dataflow_config_files: list[str],
    schema_depth: int,
    output: click.Path,
    sca_mode: str,
    prime_annotation: tuple[str, ...],
    prime_exclude_pattern: tuple[str, ...],
    prime_rules_file: str | None,
    memopt_compress_program: bool,
    prime_debug: bool,
):
    """
    Scan a project for data lineage using static code analysis (SCA).
    """
    ensure_npm(ctx)

    client: GableAPIClient = ctx.obj.client
    run_id = None
    repo_name = get_repo_name_from_git_info(project_root)

    if os.getenv("GABLE_CLI_ISOLATION", "") == "true":
        logger.debug("Running in isolation mode, skipping SCA Run API call")
        backend_config = None
    else:
        run_id, backend_config = start_sca_run(
            client=client,
            project_root=project_root,
            action="upload",
            output=None,
            include_unchanged_assets=None,
            external_component_id=None,
            upload_type=Type.CODE,
            repo_name=None,
            namespace=None,
            collection_mechanism=CollectionMechanism.SCA,
        )
        logger.debug(f"Starting static code analysis with run_id: {run_id}")

    output_str = str(output)
    output_dir = os.path.dirname(output_str)

    if sca_mode == "prime":
        lineage_data_file = run_sca_prime_and_capture(
            client=client,
            project_root=project_root,
            language=language,
            prime_annotation=prime_annotation,
            prime_exclude_pattern=prime_exclude_pattern,
            prime_rules_file=prime_rules_file,
            prime_debug=prime_debug,
            repo_name=repo_name,
            prime_memopt=memopt_compress_program,
        )
        if not lineage_data_file:
            logger.debug("No Prime findings detected.")
            return

        # overwrite the sca-prime run_id - this is tech debt,
        # ID's should be generated by the cli only.
        if run_id is not None:
            lineage_data_file.run_id = run_id

        with open(output_str, "w") as output_file:
            output_file.write(
                lineage_data_file.model_dump_json(by_alias=True, indent=2)
            )

        logger.debug(f"Wrote Prime findings to: {output_str}.")

    else:
        updated_dataflow_config_file = merge_dataflow_config_file_with_backend_config(
            dataflow_config_file, backend_config
        )
        asset_detector_cmd = get_sca_cmd(
            None,
            build_sca_args(
                project_root,
                java_version,
                build_command,
                updated_dataflow_config_file,
                dataflow_config_files,
                schema_depth,
                output_dir,
            ),
        )
        # Writes a LineageDataFile to the results.json file
        final_stdout = run_sca_and_capture(asset_detector_cmd)
        shutil.move(os.path.join(output_dir, "results.json"), output_str)
        print(final_stdout)
