import numpy as np
from math import sqrt, pi
from cmath import phase


def calculate_branch_flows(Yf, Yt, V, theta, from_bus, to_bus):
    """Calculate branch power flows and currents from solved voltages.

    Returns (P_from, Q_from, P_to, Q_to, P_loss, Q_loss,
             I_from_mag, I_from_ang, I_to_mag, I_to_ang) all in per unit.
    """
    V_complex = V * np.exp(1j * theta)

    I_from = Yf @ V_complex
    I_to = Yt @ V_complex

    S_from = V_complex[from_bus] * np.conj(I_from)
    S_to = V_complex[to_bus] * np.conj(I_to)
    S_loss = S_from + S_to

    return (
        np.real(S_from), np.imag(S_from),
        np.real(S_to), np.imag(S_to),
        np.real(S_loss), np.imag(S_loss),
        np.abs(I_from), np.angle(I_from),
        np.abs(I_to), np.angle(I_to),
    )


def allocate_generator_powers(bus_types, gen_bus_idx, gen_pf_types,
                              P, Q, p_load, q_load, p_gen, q_gen):
    """Distribute slack/PV bus injections back to individual generators.

    Returns (gen_p, gen_q) arrays with per-generator active and reactive power in pu.
    """
    n_gen = len(gen_bus_idx)
    gen_p = np.zeros(n_gen)
    gen_q = np.zeros(n_gen)

    P_surplus = P + p_load - p_gen
    Q_surplus = Q + q_load - q_gen

    for bus_idx in np.unique(gen_bus_idx):
        bt = bus_types[bus_idx]

        if bt == 2:  # SL
            sl_mask = (gen_bus_idx == bus_idx) & (gen_pf_types == 2)
            n_sl = sl_mask.sum()
            if n_sl > 0:
                gen_p[sl_mask] = P_surplus[bus_idx] / n_sl

            pv_sl_mask = (gen_bus_idx == bus_idx) & ((gen_pf_types == 2) | (gen_pf_types == 1))
            n_pv_sl = pv_sl_mask.sum()
            if n_pv_sl > 0:
                gen_q[pv_sl_mask] = Q_surplus[bus_idx] / n_pv_sl

        elif bt == 1:  # PV
            pv_mask = (gen_bus_idx == bus_idx) & (gen_pf_types == 1)
            n_pv = pv_mask.sum()
            if n_pv > 0:
                gen_q[pv_mask] = Q_surplus[bus_idx] / n_pv

    return gen_p, gen_q


def format_bus_result(v_pu, theta_deg, vr_kv, p_mw, q_mvar):
    """Format a single bus result in engineering units."""
    return {
        'v_pu': v_pu,
        'v_percent': v_pu * 100,
        'v_kv': v_pu * vr_kv if vr_kv is not None else None,
        'theta_degree': theta_deg,
        'p_mw': p_mw,
        'q_mvar': q_mvar,
    }


def format_branch_result(p_from, q_from, p_to, q_to, p_loss, q_loss,
                         i_from_mag, i_from_ang, i_to_mag, i_to_ang,
                         sb_mva, vr_from_kv, vr_to_kv, s_max_pu):
    """Format a single branch result in engineering units."""
    i_base_from = sb_mva / (sqrt(3) * vr_from_kv) if vr_from_kv else 0
    i_base_to = sb_mva / (sqrt(3) * vr_to_kv) if vr_to_kv else 0

    result = {
        'p_1_mw': p_from * sb_mva,
        'q_1_mvar': q_from * sb_mva,
        'p_2_mw': p_to * sb_mva,
        'q_2_mvar': q_to * sb_mva,
        'i_1_ka': i_from_mag * i_base_from,
        'i_2_ka': i_to_mag * i_base_to,
        'i_1_angle_degree': i_from_ang * 180 / pi,
        'i_2_angle_degree': i_to_ang * 180 / pi,
        'p_loss_mw': p_loss * sb_mva,
        'q_loss_mvar': q_loss * sb_mva,
    }
    if s_max_pu is not None and s_max_pu > 0:
        s_from_pu = sqrt(p_from ** 2 + q_from ** 2)
        result['loading_percent'] = s_from_pu / s_max_pu * 100
    return result


def format_injection_result(p_pu, q_pu, v_pu, theta_deg, vr_kv, sb_mva):
    """Format a single-port element result (generator, load, shunt)."""
    i_base = sb_mva / (sqrt(3) * vr_kv) if vr_kv else 0
    s_pu = sqrt(p_pu ** 2 + q_pu ** 2)

    result = {
        'p_mw': p_pu * sb_mva,
        'q_mvar': q_pu * sb_mva,
        'i_ka': s_pu / v_pu * i_base if v_pu > 0 else 0,
    }
    if p_pu != 0 or q_pu != 0:
        result['i_angle_degree'] = theta_deg - phase(p_pu + 1j * q_pu) * 180 / pi
    else:
        result['i_angle_degree'] = 0.0
    return result
