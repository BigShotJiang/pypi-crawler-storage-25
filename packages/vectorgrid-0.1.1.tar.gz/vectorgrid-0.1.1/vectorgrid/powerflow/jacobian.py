import numpy as np


def compute_jacobian_nr(V, theta, G, B, non_slack_buses, pq_buses):
    """Compute full Newton-Raphson Jacobian submatrices J1..J4.

    Returns J1 (dP/dTheta), J2 (dP/dV), J3 (dQ/dTheta), J4 (dQ/dV),
    already sliced to the relevant bus subsets.
    """
    dtheta = theta[:, None] - theta[None, :]
    cos_d = np.cos(dtheta)
    sin_d = np.sin(dtheta)
    VV = V[:, None] * V[None, :]

    A = G * sin_d - B * cos_d
    C = G * cos_d + B * sin_d

    G_diag = np.diag(G)
    B_diag = np.diag(B)

    # J1 = dP/dTheta
    J1 = VV * A
    np.fill_diagonal(J1, -np.sum(VV * A, axis=1) - B_diag * V ** 2)

    # J2 = dP/dV
    J2 = V[:, None] * C
    np.fill_diagonal(J2, np.sum(V[None, :] * C, axis=1) + G_diag * V)

    # J3 = dQ/dTheta
    J3 = -VV * C
    np.fill_diagonal(J3, np.sum(VV * C, axis=1) - G_diag * V ** 2)

    # J4 = dQ/dV
    J4 = V[:, None] * A
    np.fill_diagonal(J4, np.sum(V[None, :] * A, axis=1) - B_diag * V)

    return (
        J1[np.ix_(non_slack_buses, non_slack_buses)],
        J2[np.ix_(non_slack_buses, pq_buses)],
        J3[np.ix_(pq_buses, non_slack_buses)],
        J4[np.ix_(pq_buses, pq_buses)],
    )


def compute_jacobian_dnr(V, theta, G, B, Q, non_slack_buses, pq_buses):
    """Compute decoupled Newton-Raphson Jacobian (H and L matrices)."""
    dtheta = theta[:, None] - theta[None, :]
    VV = V[:, None] * V[None, :]
    A = G * np.sin(dtheta) - B * np.cos(dtheta)

    B_diag = np.diag(B)

    H = VV * A
    np.fill_diagonal(H, -B_diag * V ** 2 - Q)

    L = VV * A.copy()
    np.fill_diagonal(L, -B_diag * V ** 2 + Q)

    return (
        H[np.ix_(non_slack_buses, non_slack_buses)],
        L[np.ix_(pq_buses, pq_buses)],
    )
