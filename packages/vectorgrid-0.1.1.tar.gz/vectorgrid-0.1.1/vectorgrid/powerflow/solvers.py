import numpy as np
from scipy.sparse import csr_matrix
from scipy.sparse.linalg import spsolve
from scipy.linalg import lu_factor, lu_solve

from .jacobian import compute_jacobian_nr, compute_jacobian_dnr
from .load_model import calculate_load_power


def _update_loads(n_buses, V, load_bus, load_p_rated, load_q_rated,
                  load_scaling, load_model_type, load_model_params,
                  p_gen_pq, q_gen_pq):
    """Recalculate voltage-dependent load power and aggregate per bus."""
    n_loads = len(load_bus)
    load_p = np.zeros(n_loads)
    load_q = np.zeros(n_loads)
    p_load = -p_gen_pq.copy()
    q_load = -q_gen_pq.copy()

    for i in range(n_loads):
        bus = load_bus[i]
        p, q = calculate_load_power(
            load_p_rated[i], load_q_rated[i], load_scaling[i],
            load_model_type[i], load_model_params[i], V[bus])
        load_p[i] = p
        load_q[i] = q
        p_load[bus] += p
        q_load[bus] += q

    return p_load, q_load, load_p, load_q


def newton_raphson(system, tolerance, max_iterations):
    """Full Newton-Raphson power flow solver.

    Args:
        system: compiled system dict from Network._compile()
        tolerance: convergence tolerance on complex voltage change
        max_iterations: maximum number of iterations

    Returns:
        dict with V, theta, P, Q, p_load, q_load, load_p, load_q,
        converged, iterations
    """
    n = system['n_buses']
    V = system['V'].copy()
    theta = system['theta'].copy()
    G, B = system['G'], system['B']
    Yb = system['Yb']
    pq = system['pq_buses']
    ns = system['non_slack_buses']
    p_gen = system['p_gen']
    q_gen = system['q_gen']

    V_old = np.zeros(n, dtype=complex)
    n_ns = len(ns)

    for iteration in range(1, max_iterations + 1):
        V_complex = V * np.exp(1j * theta)
        if np.all(np.abs(V_complex - V_old) <= tolerance):
            break
        V_old = V_complex

        p_load, q_load, load_p, load_q = _update_loads(
            n, V, system['load_bus'], system['load_p_rated'],
            system['load_q_rated'], system['load_scaling'],
            system['load_model_type'], system['load_model_params'],
            system['p_gen_pq'], system['q_gen_pq'])

        p_spec = p_gen - p_load
        q_spec = q_gen - q_load

        S = V_complex * np.conj(csr_matrix(Yb) @ V_complex)
        P = np.real(S)
        Q = np.imag(S)

        dP = (p_spec - P)[ns]
        dQ = (q_spec - Q)[pq]

        J1, J2, J3, J4 = compute_jacobian_nr(V, theta, G, B, ns, pq)
        J = np.block([[J1, J2], [J3, J4]])

        try:
            dX = spsolve(csr_matrix(J), np.concatenate([dP, dQ]))
        except Exception:
            return _fail_result(V, theta)

        theta[ns] += dX[:n_ns]
        V[pq] += dX[n_ns:]
    else:
        return _fail_result(V, theta)

    return {
        'V': V, 'theta': theta,
        'P': P, 'Q': Q,
        'p_load': p_load, 'q_load': q_load,
        'load_p': load_p, 'load_q': load_q,
        'converged': True, 'iterations': iteration,
    }


def decoupled_newton_raphson(system, tolerance, max_iterations):
    """Decoupled Newton-Raphson power flow solver."""
    n = system['n_buses']
    V = system['V'].copy()
    theta = system['theta'].copy()
    G, B = system['G'], system['B']
    Yb = system['Yb']
    pq = system['pq_buses']
    ns = system['non_slack_buses']
    p_gen = system['p_gen']
    q_gen = system['q_gen']

    V_old = np.zeros(n, dtype=complex)

    for iteration in range(1, max_iterations + 1):
        V_complex = V * np.exp(1j * theta)
        if np.all(np.abs(V_complex - V_old) <= tolerance):
            break
        V_old = V_complex

        p_load, q_load, load_p, load_q = _update_loads(
            n, V, system['load_bus'], system['load_p_rated'],
            system['load_q_rated'], system['load_scaling'],
            system['load_model_type'], system['load_model_params'],
            system['p_gen_pq'], system['q_gen_pq'])

        p_spec = p_gen - p_load
        q_spec = q_gen - q_load

        S = V_complex * np.conj(Yb @ V_complex)
        P = np.real(S.astype(complex))
        Q = np.imag(S.astype(complex))

        dP = (p_spec - P)[ns]
        dQ = (q_spec - Q)[pq]

        H, L = compute_jacobian_dnr(V, theta, G, B, Q, ns, pq)

        try:
            lu_h, piv_h = lu_factor(H)
            dTh = lu_solve((lu_h, piv_h), dP)
            lu_l, piv_l = lu_factor(L)
            dV = lu_solve((lu_l, piv_l), dQ) * V[pq]
        except Exception:
            return _fail_result(V, theta)

        theta[ns] += dTh
        V[pq] += dV
    else:
        return _fail_result(V, theta)

    return {
        'V': V, 'theta': theta,
        'P': P, 'Q': Q,
        'p_load': p_load, 'q_load': q_load,
        'load_p': load_p, 'load_q': load_q,
        'converged': True, 'iterations': iteration,
    }


def _fail_result(V, theta):
    n = len(V)
    return {
        'V': V, 'theta': theta,
        'P': np.zeros(n), 'Q': np.zeros(n),
        'p_load': np.zeros(n), 'q_load': np.zeros(n),
        'load_p': np.array([]), 'load_q': np.array([]),
        'converged': False, 'iterations': -1,
    }
