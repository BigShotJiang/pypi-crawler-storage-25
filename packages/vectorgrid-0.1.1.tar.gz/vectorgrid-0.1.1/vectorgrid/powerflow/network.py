import uuid
import numpy as np
from math import pi

from .elements import line_to_branch, trafo_2w_to_branch, trafo_3w_to_branches
from .admittance import build_admittance_matrices
from .solvers import newton_raphson, decoupled_newton_raphson
from .results import (calculate_branch_flows, allocate_generator_powers,
                      format_bus_result, format_branch_result,
                      format_injection_result)


class Network:
    """Power system network for steady-state analysis.

    Usage:
        net = Network(sb_mva=100, f_hz=50)
        b1 = net.add_bus(vr_kv=110)
        b2 = net.add_bus(vr_kv=20)
        net.add_external_grid(bus=b1, pf_type='SL', v_percent=105)
        net.add_load(bus=b2, p_mw=50, q_mvar=20)
        net.add_transformer_2w(bus_1=b1, bus_2=b2, sr_mva=100, vk_percent=12)
        results = net.run_power_flow(method='nr')
    """

    def __init__(self, sb_mva=100, f_hz=50):
        self.sb_mva = sb_mva
        self.f_hz = f_hz
        self._buses = {}
        self._lines = {}
        self._transformers_2w = {}
        self._transformers_3w = {}
        self._generators = {}
        self._external_grids = {}
        self._loads = {}
        self._shunts = {}
        self._switches = {}
        self._async_motors = {}
        self._power_station_units = {}

    # ── Element creation ─────────────────────────────────────────────

    def add_bus(self, vr_kv, uid=None, name=None,
                v_min_percent=90, v_max_percent=110,
                area=1, zone=1, in_service=True):
        uid = uid or str(uuid.uuid4())
        self._buses[uid] = {
            'uid': uid,
            'name': name or f'B{len(self._buses) + 1}',
            'vr_kv': vr_kv,
            'v_min_percent': v_min_percent,
            'v_max_percent': v_max_percent,
            'area': area,
            'zone': zone,
            'in_service': in_service,
        }
        return uid

    def add_line(self, bus_1, bus_2, length_km, r_ohm_per_km, x_ohm_per_km,
                 uid=None, name=None, vr_kv=None, num_of_parallel=1,
                 c_muf_per_km=0, g_mus_per_km=0, i_max_ka=None,
                 in_service=True, switch_1_status=True, switch_2_status=True,
                 r0_ohm_per_km=None, x0_ohm_per_km=None, c0_muf_per_km=None,
                 endtemp_degree=None, alpha=0.004):
        uid = uid or str(uuid.uuid4())
        if vr_kv is None:
            vr_kv = self._buses[bus_1]['vr_kv']
        self._lines[uid] = {
            'uid': uid,
            'name': name or f'L{len(self._lines) + 1}',
            'bus_1': bus_1, 'bus_2': bus_2,
            'vr_kv': vr_kv,
            'num_of_parallel': num_of_parallel,
            'length_km': length_km,
            'r_ohm_per_km': r_ohm_per_km,
            'x_ohm_per_km': x_ohm_per_km,
            'c_muf_per_km': c_muf_per_km,
            'g_mus_per_km': g_mus_per_km,
            'i_max_ka': i_max_ka,
            'in_service': in_service,
            'switch_1_status': switch_1_status,
            'switch_2_status': switch_2_status,
            'r0_ohm_per_km': r0_ohm_per_km,
            'x0_ohm_per_km': x0_ohm_per_km,
            'c0_muf_per_km': c0_muf_per_km,
            'endtemp_degree': endtemp_degree,
            'alpha': alpha,
        }
        return uid

    def add_transformer_2w(self, bus_1, bus_2, sr_mva, vk_percent,
                           uid=None, name=None,
                           vr_b1_kv=None, vr_b2_kv=None,
                           vr_1_kv=None, vr_2_kv=None,
                           num_of_parallel=1,
                           pcu_kw=0, j0_percent=0, pfe_kw=0,
                           in_service=True,
                           switch_1_status=True, switch_2_status=True,
                           primary_tap_changer=None,
                           secondary_tap_changer=None,
                           phase_shifter=False, phase_shift_degree=0,
                           vector_group='YNyn', vk0_percent=None):
        uid = uid or str(uuid.uuid4())
        vr_b1 = vr_b1_kv or self._buses[bus_1]['vr_kv']
        vr_b2 = vr_b2_kv or self._buses[bus_2]['vr_kv']
        self._transformers_2w[uid] = {
            'uid': uid,
            'name': name or f'T{len(self._transformers_2w) + 1}',
            'bus_1': bus_1, 'bus_2': bus_2,
            'sr_mva': sr_mva,
            'vr_b1_kv': vr_b1, 'vr_b2_kv': vr_b2,
            'vr_1_kv': vr_1_kv or vr_b1,
            'vr_2_kv': vr_2_kv or vr_b2,
            'num_of_parallel': num_of_parallel,
            'vk_percent': vk_percent,
            'pcu_kw': pcu_kw,
            'j0_percent': j0_percent,
            'pfe_kw': pfe_kw,
            'in_service': in_service,
            'switch_1_status': switch_1_status,
            'switch_2_status': switch_2_status,
            'primary_tap_changer': primary_tap_changer,
            'secondary_tap_changer': secondary_tap_changer,
            'phase_shifter': phase_shifter,
            'phase_shift_degree': phase_shift_degree,
            'vector_group': vector_group,
            'vk0_percent': vk0_percent,
        }
        return uid

    def add_transformer_3w(self, bus_1, bus_2, bus_3,
                           sr_12_mva, sr_13_mva, sr_23_mva,
                           vk_12_percent, vk_13_percent, vk_23_percent,
                           uid=None, name=None,
                           vr_b1_kv=None, vr_b2_kv=None, vr_b3_kv=None,
                           vr_1_kv=None, vr_2_kv=None, vr_3_kv=None,
                           num_of_parallel=1,
                           pcu_12_kw=0, pcu_13_kw=0, pcu_23_kw=0,
                           j0_percent=0, pfe_kw=0,
                           in_service=True,
                           switch_1_status=True, switch_2_status=True,
                           switch_3_status=True,
                           primary_tap_changer=None,
                           secondary_tap_changer=None,
                           tertiary_tap_changer=None,
                           phase_shifter=False,
                           primary_phase_shift_degree=0,
                           secondary_phase_shift_degree=0,
                           tertiary_phase_shift_degree=0,
                           vector_group_1='YN', vector_group_2='YN',
                           vector_group_3='D',
                           vk0_12_percent=None, vk0_13_percent=None,
                           vk0_23_percent=None):
        uid = uid or str(uuid.uuid4())
        vr_b1 = vr_b1_kv or self._buses[bus_1]['vr_kv']
        vr_b2 = vr_b2_kv or self._buses[bus_2]['vr_kv']
        vr_b3 = vr_b3_kv or self._buses[bus_3]['vr_kv']
        self._transformers_3w[uid] = {
            'uid': uid,
            'name': name or f'T3{len(self._transformers_3w) + 1}',
            'bus_1': bus_1, 'bus_2': bus_2, 'bus_3': bus_3,
            'sr_12_mva': sr_12_mva, 'sr_13_mva': sr_13_mva,
            'sr_23_mva': sr_23_mva,
            'vr_b1_kv': vr_b1, 'vr_b2_kv': vr_b2, 'vr_b3_kv': vr_b3,
            'vr_1_kv': vr_1_kv or vr_b1,
            'vr_2_kv': vr_2_kv or vr_b2,
            'vr_3_kv': vr_3_kv or vr_b3,
            'num_of_parallel': num_of_parallel,
            'vk_12_percent': vk_12_percent,
            'vk_13_percent': vk_13_percent,
            'vk_23_percent': vk_23_percent,
            'pcu_12_kw': pcu_12_kw, 'pcu_13_kw': pcu_13_kw,
            'pcu_23_kw': pcu_23_kw,
            'j0_percent': j0_percent, 'pfe_kw': pfe_kw,
            'in_service': in_service,
            'switch_1_status': switch_1_status,
            'switch_2_status': switch_2_status,
            'switch_3_status': switch_3_status,
            'primary_tap_changer': primary_tap_changer,
            'secondary_tap_changer': secondary_tap_changer,
            'tertiary_tap_changer': tertiary_tap_changer,
            'phase_shifter': phase_shifter,
            'primary_phase_shift_degree': primary_phase_shift_degree,
            'secondary_phase_shift_degree': secondary_phase_shift_degree,
            'tertiary_phase_shift_degree': tertiary_phase_shift_degree,
            'vector_group_1': vector_group_1,
            'vector_group_2': vector_group_2,
            'vector_group_3': vector_group_3,
            'vk0_12_percent': vk0_12_percent,
            'vk0_13_percent': vk0_13_percent,
            'vk0_23_percent': vk0_23_percent,
        }
        return uid

    def add_generator(self, bus, pf_type, uid=None, name=None,
                      sr_mva=1, vr_kv=None, cos_phi=0.85,
                      v_percent=100, theta_degree=0,
                      p_mw=0, q_mvar=0,
                      p_min_mw=None, p_max_mw=None,
                      q_min_mvar=None, q_max_mvar=None,
                      in_service=True,
                      x_d_subtrans_percent=None, x2_percent=None,
                      x0_percent=None):
        uid = uid or str(uuid.uuid4())
        self._generators[uid] = {
            'uid': uid,
            'name': name or f'G{len(self._generators) + 1}',
            'bus': bus,
            'pf_type': pf_type,
            'sr_mva': sr_mva,
            'vr_kv': vr_kv,
            'cos_phi': cos_phi,
            'v_percent': v_percent,
            'theta_degree': theta_degree,
            'p_mw': p_mw,
            'q_mvar': q_mvar,
            'p_min_mw': p_min_mw, 'p_max_mw': p_max_mw,
            'q_min_mvar': q_min_mvar, 'q_max_mvar': q_max_mvar,
            'in_service': in_service,
            'x_d_subtrans_percent': x_d_subtrans_percent,
            'x2_percent': x2_percent,
            'x0_percent': x0_percent,
        }
        return uid

    def add_async_motor(self, bus, uid=None, name=None,
                        sr_mva=1.0, vr_kv=None, i_lr_ratio=6.5,
                        cos_phi=0.85, p_pair=2, rx_ratio=0.42,
                        x0x1_ratio=1.0, motor_type='lv',
                        in_service=True):
        uid = uid or str(uuid.uuid4())
        self._async_motors[uid] = {
            'uid': uid,
            'name': name or f'AM{len(self._async_motors) + 1}',
            'bus': bus,
            'sr_mva': sr_mva,
            'vr_kv': vr_kv,
            'i_lr_ratio': i_lr_ratio,
            'cos_phi': cos_phi,
            'p_pair': p_pair,
            'rx_ratio': rx_ratio,
            'x0x1_ratio': x0x1_ratio,
            'motor_type': motor_type,
            'in_service': in_service,
        }
        return uid

    def add_power_station_unit(self, generator_uid, transformer_uid,
                               uid=None, name=None,
                               with_oltc=False, p_t_percent=10):
        uid = uid or str(uuid.uuid4())
        self._power_station_units[uid] = {
            'uid': uid,
            'name': name or f'PSU{len(self._power_station_units) + 1}',
            'generator_uid': generator_uid,
            'transformer_uid': transformer_uid,
            'with_oltc': with_oltc,
            'p_t_percent': p_t_percent,
        }
        return uid

    def add_external_grid(self, bus, uid=None, name=None,
                          pf_type='SL', v_percent=100, theta_degree=0,
                          p_mw=0, q_mvar=0, in_service=True,
                          sk_max_mva=None, rx_ratio=0.1,
                          x0x1_ratio=1.0, r0x0_ratio=0.1,
                          sk_min_mva=None, rx_min_ratio=None):
        uid = uid or str(uuid.uuid4())
        self._external_grids[uid] = {
            'uid': uid,
            'name': name or f'EG{len(self._external_grids) + 1}',
            'bus': bus,
            'pf_type': pf_type,
            'v_percent': v_percent,
            'theta_degree': theta_degree,
            'p_mw': p_mw,
            'q_mvar': q_mvar,
            'in_service': in_service,
            'sk_max_mva': sk_max_mva,
            'rx_ratio': rx_ratio,
            'x0x1_ratio': x0x1_ratio,
            'r0x0_ratio': r0x0_ratio,
            'sk_min_mva': sk_min_mva,
            'rx_min_ratio': rx_min_ratio,
        }
        return uid

    def add_load(self, bus, uid=None, name=None,
                 p_mw=0, q_mvar=0, scaling=1, in_service=True,
                 model_type='constant',
                 p_exponent=0, q_exponent=0,
                 p_z_percent=0, p_i_percent=0, p_p_percent=100,
                 q_z_percent=0, q_i_percent=0, q_p_percent=100):
        uid = uid or str(uuid.uuid4())
        self._loads[uid] = {
            'uid': uid,
            'name': name or f'LD{len(self._loads) + 1}',
            'bus': bus,
            'p_mw': p_mw,
            'q_mvar': q_mvar,
            'scaling': scaling,
            'in_service': in_service,
            'model_type': model_type,
            'p_exponent': p_exponent, 'q_exponent': q_exponent,
            'p_z_percent': p_z_percent, 'p_i_percent': p_i_percent,
            'p_p_percent': p_p_percent,
            'q_z_percent': q_z_percent, 'q_i_percent': q_i_percent,
            'q_p_percent': q_p_percent,
        }
        return uid

    def add_shunt(self, bus, uid=None, name=None,
                  p_mw=0, q_mvar=0, vr_kv=None,
                  num_of_blocks=1, step=1, in_service=True):
        uid = uid or str(uuid.uuid4())
        self._shunts[uid] = {
            'uid': uid,
            'name': name or f'SH{len(self._shunts) + 1}',
            'bus': bus,
            'p_mw': p_mw,
            'q_mvar': q_mvar,
            'vr_kv': vr_kv or self._buses[bus]['vr_kv'],
            'num_of_blocks': num_of_blocks,
            'step': step,
            'in_service': in_service,
        }
        return uid

    def add_switch(self, bus_1, bus_2, uid=None, name=None, status='closed'):
        uid = uid or str(uuid.uuid4())
        self._switches[uid] = {
            'uid': uid,
            'name': name or f'SW{len(self._switches) + 1}',
            'bus_1': bus_1,
            'bus_2': bus_2,
            'status': status,
        }
        return uid

    # ── Power flow ───────────────────────────────────────────────────

    def run_power_flow(self, method='nr', tolerance=1e-6, max_iterations=50):
        """Run power flow analysis.

        Args:
            method: 'nr' for Newton-Raphson, 'dnr' for Decoupled Newton-Raphson
            tolerance: convergence tolerance
            max_iterations: maximum iteration count

        Returns:
            dict with 'converged', 'iterations', 'buses', 'lines',
            'transformers_2w', 'transformers_3w', 'generators',
            'external_grids', 'loads', 'shunts'
        """
        compiled = self._compile()
        system = compiled['system']

        if method == 'nr':
            result = newton_raphson(system, tolerance, max_iterations)
        elif method == 'dnr':
            result = decoupled_newton_raphson(system, tolerance, max_iterations)
        else:
            raise ValueError(f"Unknown method '{method}'. Use 'nr' or 'dnr'.")

        return self._format_results(compiled, result)

    # ── Internal compilation ─────────────────────────────────────────

    def _compile(self):
        """Convert stored elements to solver-ready numpy arrays."""
        sb = self.sb_mva

        # Collect all in-service injection elements
        all_injections = []
        for g in self._generators.values():
            if g['in_service']:
                all_injections.append(g)
        for eg in self._external_grids.values():
            if eg['in_service']:
                all_injections.append(eg)

        # Build internal bus list (in-service only)
        buses = []
        for b in self._buses.values():
            if b['in_service']:
                pf_type, v, theta = self._determine_bus_type(b['uid'], all_injections)
                g_shunt, b_shunt = self._calculate_shunts(b['uid'], b['vr_kv'])
                buses.append({
                    'uid': b['uid'], 'vr_kv': b['vr_kv'],
                    'pf_type': pf_type, 'v': v, 'theta': theta,
                    'g_shunt': g_shunt, 'b_shunt': b_shunt,
                })

        bus_uid_set = {b['uid'] for b in buses}

        # Build branches from lines
        branches = []
        line_branch_map = {}
        for line in self._lines.values():
            if not line['in_service']:
                continue
            if not (line['switch_1_status'] or line['switch_2_status']):
                continue
            if line['bus_1'] not in bus_uid_set or line['bus_2'] not in bus_uid_set:
                continue
            br = line_to_branch(line, sb, self.f_hz)
            branches.append(br)
            line_branch_map[line['uid']] = br['uid']

        # Build branches from 2W transformers
        trafo_2w_branch_map = {}
        for trafo in self._transformers_2w.values():
            if not trafo['in_service']:
                continue
            if not (trafo['switch_1_status'] or trafo['switch_2_status']):
                continue
            if trafo['bus_1'] not in bus_uid_set or trafo['bus_2'] not in bus_uid_set:
                continue
            br = trafo_2w_to_branch(trafo, sb)
            branches.append(br)
            trafo_2w_branch_map[trafo['uid']] = br['uid']

        # Build branches from 3W transformers
        trafo_3w_branch_map = {}
        for trafo in self._transformers_3w.values():
            if not trafo['in_service']:
                continue
            active = (trafo['switch_1_status'] or trafo['switch_2_status']
                      or trafo['switch_3_status'])
            if not active:
                continue
            if not all(trafo[f'bus_{i}'] in bus_uid_set for i in (1, 2, 3)):
                continue
            aux_uid = str(uuid.uuid4())
            aux_bus, br_list = trafo_3w_to_branches(trafo, sb, aux_uid)
            buses.append(aux_bus)
            bus_uid_set.add(aux_uid)
            branches.extend(br_list)
            trafo_3w_branch_map[trafo['uid']] = [b['uid'] for b in br_list]

        # Handle switches (merge buses connected by closed switches)
        uid_remap = {}
        for sw in self._switches.values():
            if sw['status'] != 'closed':
                continue
            b1_uid = uid_remap.get(sw['bus_1'], sw['bus_1'])
            b2_uid = uid_remap.get(sw['bus_2'], sw['bus_2'])
            if b1_uid == b2_uid:
                continue
            b1 = next((b for b in buses if b['uid'] == b1_uid), None)
            b2 = next((b for b in buses if b['uid'] == b2_uid), None)
            if b1 is None or b2 is None:
                continue
            merged_uid = str(uuid.uuid4())
            merged_type = self._merge_pf_type(b1['pf_type'], b2['pf_type'])
            merged_v = self._pick_merged_voltage(b1, b2, merged_type)
            merged_theta = b1['theta'] if b1['pf_type'] in ('SL',) else b2.get('theta', 0)
            merged_bus = {
                'uid': merged_uid,
                'vr_kv': b1['vr_kv'],
                'pf_type': merged_type,
                'v': merged_v,
                'theta': merged_theta if merged_type == 'SL' else 0.0,
                'g_shunt': b1['g_shunt'] + b2['g_shunt'],
                'b_shunt': b1['b_shunt'] + b2['b_shunt'],
            }
            buses = [b for b in buses if b['uid'] not in (b1_uid, b2_uid)]
            buses.append(merged_bus)
            bus_uid_set.discard(b1_uid)
            bus_uid_set.discard(b2_uid)
            bus_uid_set.add(merged_uid)
            for old in (b1_uid, b2_uid):
                uid_remap[old] = merged_uid
            for key, val in list(uid_remap.items()):
                if val in (b1_uid, b2_uid):
                    uid_remap[key] = merged_uid

        def _resolve(uid):
            return uid_remap.get(uid, uid)

        for br in branches:
            br['from_bus'] = _resolve(br['from_bus'])
            br['to_bus'] = _resolve(br['to_bus'])

        # Island detection: keep only buses reachable from a slack bus
        # through fully-connected branches (both switches closed).
        adj = {}
        for br in branches:
            if br['from_status'] and br['to_status']:
                adj.setdefault(br['from_bus'], set()).add(br['to_bus'])
                adj.setdefault(br['to_bus'], set()).add(br['from_bus'])

        slack_uids = {b['uid'] for b in buses if b['pf_type'] == 'SL'}
        live = set()
        frontier = list(slack_uids)
        while frontier:
            uid = frontier.pop()
            if uid in live:
                continue
            live.add(uid)
            for nb in adj.get(uid, ()):
                if nb not in live:
                    frontier.append(nb)

        buses = [b for b in buses if b['uid'] in live]

        # For branches crossing the live/dead boundary, keep only if
        # the live side has a closed switch (contributes a shunt).
        # Redirect the dead-side bus ref to the live side — the dead
        # side has an open switch so its index only appears in
        # zero-valued entries of the admittance matrices.
        kept = []
        for br in branches:
            f_live = br['from_bus'] in live
            t_live = br['to_bus'] in live
            if not f_live and not t_live:
                continue
            if f_live and t_live:
                kept.append(br)
                continue
            if f_live:
                if not br['from_status']:
                    continue
                br['to_bus'] = br['from_bus']
            else:
                if not br['to_status']:
                    continue
                br['from_bus'] = br['to_bus']
            kept.append(br)
        branches = kept

        # Map UIDs to integer indices
        bus_uid_to_idx = {b['uid']: i for i, b in enumerate(buses)}
        n_buses = len(buses)
        n_branches = len(branches)

        # Build bus arrays
        V = np.array([b['v'] for b in buses])
        theta = np.array([b['theta'] for b in buses])
        g_shunt = np.array([b['g_shunt'] for b in buses])
        b_shunt_arr = np.array([b['b_shunt'] for b in buses])
        bus_vr_kv = np.array([b['vr_kv'] if b['vr_kv'] else 0.0 for b in buses])

        pf_type_map = {'PQ': 0, 'PV': 1, 'SL': 2}
        bus_types = np.array([pf_type_map[b['pf_type']] for b in buses])
        pq_buses = np.where(bus_types == 0)[0]
        non_slack_buses = np.where(bus_types != 2)[0]

        # Build branch arrays
        from_bus = np.array([bus_uid_to_idx[br['from_bus']] for br in branches], dtype=int)
        to_bus = np.array([bus_uid_to_idx[br['to_bus']] for br in branches], dtype=int)
        br_r = np.array([br['r'] for br in branches])
        br_x = np.array([br['x'] for br in branches])
        br_g = np.array([br['g'] for br in branches])
        br_b = np.array([br['b'] for br in branches])
        br_ratio = np.array([br['ratio'] for br in branches])
        br_angle = np.array([br['angle'] for br in branches])
        br_from_status = np.array([br['from_status'] for br in branches], dtype=float)
        br_to_status = np.array([br['to_status'] for br in branches], dtype=float)
        br_s_max = np.array([br['s_max_pu'] if br['s_max_pu'] is not None else 0.0
                             for br in branches])

        # Build admittance matrices
        Yf, Yt, Yb = build_admittance_matrices(
            n_buses, n_branches, from_bus, to_bus,
            br_r, br_x, br_g, br_b, br_ratio, br_angle,
            br_from_status, br_to_status, g_shunt, b_shunt_arr)

        # Build generator arrays (active power / voltage specs per bus)
        p_gen = np.zeros(n_buses)
        q_gen = np.zeros(n_buses)
        p_gen_pq = np.zeros(n_buses)
        q_gen_pq = np.zeros(n_buses)

        gen_list = []
        gen_pf_type_int = {'SL': 2, 'PV': 1, 'PQ': 0}
        for g in list(self._generators.values()) + list(self._external_grids.values()):
            if not g['in_service']:
                continue
            bus_uid = _resolve(g['bus'])
            if bus_uid not in bus_uid_to_idx:
                continue
            bus_idx = bus_uid_to_idx[bus_uid]
            pf = g['pf_type']
            if pf == 'PV':
                p_gen[bus_idx] += g['p_mw'] / sb
            elif pf == 'PQ':
                p_gen_pq[bus_idx] += g['p_mw'] / sb
                q_gen_pq[bus_idx] += g['q_mvar'] / sb
            gen_list.append({
                'uid': g['uid'],
                'bus_idx': bus_idx,
                'pf_type_int': gen_pf_type_int[pf],
                'p_spec': g['p_mw'] / sb,
                'q_spec': g['q_mvar'] / sb,
            })

        gen_bus_idx = np.array([g['bus_idx'] for g in gen_list]) if gen_list else np.array([], dtype=int)
        gen_pf_types = np.array([g['pf_type_int'] for g in gen_list]) if gen_list else np.array([], dtype=int)

        # Build load arrays
        load_list = []
        for ld in self._loads.values():
            if not ld['in_service']:
                continue
            bus_uid = _resolve(ld['bus'])
            if bus_uid not in bus_uid_to_idx:
                continue
            bus_idx = bus_uid_to_idx[bus_uid]
            mt = ld['model_type']
            if mt == 'zip' or mt == 'ZIP':
                model_type_int = 1
                params = [ld['p_z_percent'] / 100, ld['p_i_percent'] / 100,
                          ld['p_p_percent'] / 100, ld['q_z_percent'] / 100,
                          ld['q_i_percent'] / 100, ld['q_p_percent'] / 100]
            elif mt == 'exponential':
                model_type_int = 2
                params = [ld['p_exponent'], ld['q_exponent'], 0, 0, 0, 0]
            else:
                model_type_int = 0
                params = [0, 0, 0, 0, 0, 0]
            load_list.append({
                'uid': ld['uid'],
                'bus_idx': bus_idx,
                'p_rated': ld['p_mw'] / sb,
                'q_rated': ld['q_mvar'] / sb,
                'scaling': ld['scaling'],
                'model_type': model_type_int,
                'model_params': params,
            })

        n_loads = len(load_list)
        load_bus = np.array([l['bus_idx'] for l in load_list]) if n_loads else np.array([], dtype=int)
        load_p_rated = np.array([l['p_rated'] for l in load_list]) if n_loads else np.array([])
        load_q_rated = np.array([l['q_rated'] for l in load_list]) if n_loads else np.array([])
        load_scaling = np.array([l['scaling'] for l in load_list]) if n_loads else np.array([])
        load_model_type = np.array([l['model_type'] for l in load_list]) if n_loads else np.array([], dtype=int)
        load_model_params = np.array([l['model_params'] for l in load_list]) if n_loads else np.zeros((0, 6))

        system = {
            'n_buses': n_buses,
            'V': V, 'theta': theta,
            'G': np.real(Yb), 'B': np.imag(Yb), 'Yb': Yb,
            'Yf': Yf, 'Yt': Yt,
            'pq_buses': pq_buses,
            'non_slack_buses': non_slack_buses,
            'bus_types': bus_types,
            'p_gen': p_gen, 'q_gen': q_gen,
            'p_gen_pq': p_gen_pq, 'q_gen_pq': q_gen_pq,
            'load_bus': load_bus,
            'load_p_rated': load_p_rated,
            'load_q_rated': load_q_rated,
            'load_scaling': load_scaling,
            'load_model_type': load_model_type,
            'load_model_params': load_model_params,
            'branch_from': from_bus,
            'branch_to': to_bus,
        }

        return {
            'system': system,
            'buses': buses,
            'branches': branches,
            'gen_list': gen_list,
            'gen_bus_idx': gen_bus_idx,
            'gen_pf_types': gen_pf_types,
            'load_list': load_list,
            'bus_uid_to_idx': bus_uid_to_idx,
            'uid_remap': uid_remap,
            'br_s_max': br_s_max,
            'bus_vr_kv': bus_vr_kv,
        }

    def _format_results(self, compiled, solver_result):
        """Convert solver output to engineering-unit results."""
        if not solver_result['converged']:
            return {'converged': False, 'iterations': solver_result['iterations']}

        sb = self.sb_mva
        V = solver_result['V']
        theta_deg = solver_result['theta'] * 180 / pi
        P = solver_result['P']
        Q = solver_result['Q']
        p_load = solver_result['p_load']
        q_load = solver_result['q_load']

        system = compiled['system']
        buses = compiled['buses']
        branches = compiled['branches']
        bus_vr_kv = compiled['bus_vr_kv']
        bus_uid_to_idx = compiled['bus_uid_to_idx']
        uid_remap = compiled['uid_remap']

        # Branch flows
        Yf, Yt = system['Yf'], system['Yt']
        from_bus = system['branch_from']
        to_bus = system['branch_to']
        (P_from, Q_from, P_to, Q_to, P_loss, Q_loss,
         I_from_mag, I_from_ang, I_to_mag, I_to_ang) = calculate_branch_flows(
            Yf, Yt, V, solver_result['theta'], from_bus, to_bus)

        # Generator powers
        gen_p, gen_q = allocate_generator_powers(
            system['bus_types'], compiled['gen_bus_idx'],
            compiled['gen_pf_types'],
            P, Q, p_load, q_load,
            system['p_gen'], system['q_gen'])

        # Format bus results
        bus_results = {}
        for b in self._buses.values():
            resolved = uid_remap.get(b['uid'], b['uid'])
            if resolved not in bus_uid_to_idx:
                continue
            idx = bus_uid_to_idx[resolved]
            bus_results[b['uid']] = format_bus_result(
                V[idx], theta_deg[idx], b['vr_kv'],
                P[idx] * sb, Q[idx] * sb)

        # Format line results
        line_results = {}
        branch_uid_to_idx = {br['uid']: i for i, br in enumerate(branches)}
        for line_uid, line in self._lines.items():
            if line_uid not in [br['uid'] for br in branches]:
                continue
            bi = branch_uid_to_idx[line_uid]
            vr = line['vr_kv']
            line_results[line_uid] = format_branch_result(
                P_from[bi], Q_from[bi], P_to[bi], Q_to[bi],
                P_loss[bi], Q_loss[bi],
                I_from_mag[bi], I_from_ang[bi],
                I_to_mag[bi], I_to_ang[bi],
                sb, vr, vr, compiled['br_s_max'][bi])

        # Format 2W transformer results
        trafo_2w_results = {}
        for t_uid, trafo in self._transformers_2w.items():
            if t_uid not in [br['uid'] for br in branches]:
                continue
            bi = branch_uid_to_idx[t_uid]
            trafo_2w_results[t_uid] = format_branch_result(
                P_from[bi], Q_from[bi], P_to[bi], Q_to[bi],
                P_loss[bi], Q_loss[bi],
                I_from_mag[bi], I_from_ang[bi],
                I_to_mag[bi], I_to_ang[bi],
                sb, trafo['vr_b1_kv'], trafo['vr_b2_kv'],
                compiled['br_s_max'][bi])

        # Format 3W transformer results
        trafo_3w_results = {}
        for t_uid, trafo in self._transformers_3w.items():
            br_uids = [f"{t_uid}-primary", f"{t_uid}-secondary", f"{t_uid}-tertiary"]
            if not all(u in branch_uid_to_idx for u in br_uids):
                continue
            idxs = [branch_uid_to_idx[u] for u in br_uids]
            total_p_loss = sum(P_loss[i] for i in idxs)
            total_q_loss = sum(Q_loss[i] for i in idxs)
            vr_kvs = [trafo['vr_b1_kv'], trafo['vr_b2_kv'], trafo['vr_b3_kv']]
            r3 = {}
            for port, (bi, vr) in enumerate(zip(idxs, vr_kvs), 1):
                i_base = sb / (3 ** 0.5 * vr) if vr else 0
                p_pu = P_from[bi]
                q_pu = Q_from[bi]
                r3[f'i_{port}_ka'] = I_from_mag[bi] * i_base
                r3[f'i_{port}_angle_degree'] = I_from_ang[bi] * 180 / pi
                r3[f'p_{port}_mw'] = p_pu * sb
                r3[f'q_{port}_mvar'] = q_pu * sb
                s_max_pu = compiled['br_s_max'][bi]
                if s_max_pu > 0:
                    s_pu = (p_pu ** 2 + q_pu ** 2) ** 0.5
                    r3[f'loading_{port}_percent'] = s_pu / s_max_pu * 100
            r3['p_loss_mw'] = total_p_loss * sb
            r3['q_loss_mvar'] = total_q_loss * sb
            trafo_3w_results[t_uid] = r3

        # Format generator and external grid results
        gen_results = {}
        ext_grid_results = {}
        for i, g_data in enumerate(compiled['gen_list']):
            g_uid = g_data['uid']
            bus_idx = g_data['bus_idx']
            vr = bus_vr_kv[bus_idx]

            p_pu = g_data['p_spec'] + gen_p[i] if i < len(gen_p) else g_data['p_spec']
            q_pu = g_data['q_spec'] + gen_q[i] if i < len(gen_q) else g_data['q_spec']

            r = format_injection_result(
                p_pu, q_pu, V[bus_idx], theta_deg[bus_idx], vr, sb)

            if g_uid in self._generators:
                gen_results[g_uid] = r
            elif g_uid in self._external_grids:
                ext_grid_results[g_uid] = r

        # Format load results
        load_results = {}
        for i, l_data in enumerate(compiled['load_list']):
            bus_idx = l_data['bus_idx']
            vr = bus_vr_kv[bus_idx]
            p_pu = solver_result['load_p'][i] if i < len(solver_result['load_p']) else 0
            q_pu = solver_result['load_q'][i] if i < len(solver_result['load_q']) else 0
            load_results[l_data['uid']] = format_injection_result(
                p_pu, q_pu, V[bus_idx], theta_deg[bus_idx], vr, sb)

        # Format shunt results
        shunt_results = {}
        for sh_uid, shunt in self._shunts.items():
            if not shunt['in_service']:
                continue
            bus_uid = uid_remap.get(shunt['bus'], shunt['bus'])
            if bus_uid not in bus_uid_to_idx:
                continue
            idx = bus_uid_to_idx[bus_uid]
            v = V[idx]
            p_mw = shunt['num_of_blocks'] * shunt['step'] * shunt['p_mw'] * v ** 2
            q_mvar = shunt['num_of_blocks'] * shunt['step'] * shunt['q_mvar'] * v ** 2
            shunt_results[sh_uid] = {
                'p_mw': p_mw,
                'q_mvar': q_mvar,
            }

        return {
            'converged': True,
            'iterations': solver_result['iterations'],
            'buses': bus_results,
            'lines': line_results,
            'transformers_2w': trafo_2w_results,
            'transformers_3w': trafo_3w_results,
            'generators': gen_results,
            'external_grids': ext_grid_results,
            'loads': load_results,
            'shunts': shunt_results,
        }

    # ── Helpers ───────────────────────────────────────────────────────

    @staticmethod
    def _determine_bus_type(bus_uid, injections):
        for el in injections:
            if el['bus'] == bus_uid and el['pf_type'] == 'SL':
                return 'SL', el['v_percent'] / 100, el['theta_degree'] * pi / 180
        for el in injections:
            if el['bus'] == bus_uid and el['pf_type'] == 'PV':
                return 'PV', el['v_percent'] / 100, 0.0
        return 'PQ', 1.0, 0.0

    def _calculate_shunts(self, bus_uid, vr_bus_kv):
        sb = self.sb_mva
        g_total, b_total = 0.0, 0.0
        for shunt in self._shunts.values():
            if shunt['in_service'] and shunt['bus'] == bus_uid:
                p = shunt['num_of_blocks'] * shunt['step'] * shunt['p_mw']
                q = shunt['num_of_blocks'] * shunt['step'] * shunt['q_mvar']
                y = (p - 1j * q) / sb * (vr_bus_kv / shunt['vr_kv']) ** 2
                g_total += y.real
                b_total += y.imag
        return g_total, b_total

    @staticmethod
    def _merge_pf_type(t1, t2):
        priority = {'SL': 2, 'PV': 1, 'PQ': 0}
        return t1 if priority[t1] >= priority[t2] else t2

    @staticmethod
    def _pick_merged_voltage(b1, b2, merged_type):
        if merged_type == 'SL':
            if b1['pf_type'] == 'SL' and b2['pf_type'] == 'SL':
                return min(b1['v'], b2['v'])
            return b1['v'] if b1['pf_type'] == 'SL' else b2['v']
        if merged_type == 'PV':
            if b1['pf_type'] == 'PV' and b2['pf_type'] == 'PV':
                return min(b1['v'], b2['v'])
            return b1['v'] if b1['pf_type'] == 'PV' else b2['v']
        return 1.0
