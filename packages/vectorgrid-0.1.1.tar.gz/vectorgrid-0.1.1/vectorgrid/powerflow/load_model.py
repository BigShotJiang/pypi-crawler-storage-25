def calculate_load_power(p_rated, q_rated, scaling, model_type, model_params, v):
    """Calculate voltage-dependent load power in per unit.

    model_type: 0 = constant power, 1 = ZIP, 2 = exponential
    model_params: [p_z, p_i, p_p, q_z, q_i, q_p] for ZIP
                  [p_exp, q_exp, 0, 0, 0, 0] for exponential
    """
    p = p_rated * scaling
    q = q_rated * scaling
    if model_type == 1:
        p *= model_params[0] * v ** 2 + model_params[1] * v + model_params[2]
        q *= model_params[3] * v ** 2 + model_params[4] * v + model_params[5]
    elif model_type == 2:
        p *= v ** model_params[0]
        q *= v ** model_params[1]
    return p, q
