from math import pi, sqrt


def calculate_impedance(vk_percent, pcu_kw, sr_mva, sb_mva):
    """Calculate transformer series impedance in per unit."""
    z = vk_percent / 100 * sb_mva / sr_mva
    r = pcu_kw / 1000 * sb_mva / sr_mva ** 2
    x = sqrt(max(z ** 2 - r ** 2, 0))
    return complex(r, x)


def calculate_tap_ratio(tap_changer, vr_w_kv, vr_b_kv):
    """Calculate off-nominal tap ratio for a transformer winding."""
    ratio = vr_w_kv / vr_b_kv
    if tap_changer and tap_changer.get('tap_changer_active', False):
        tap_adj = ((tap_changer['tap_position'] - tap_changer['tap_neutral'])
                   * tap_changer['tap_step_percent'] / 100)
        ratio *= 1 + tap_adj
    return ratio


def line_to_branch(line, sb_mva, f_hz):
    """Convert a power line dict to a branch dict (per-unit parameters)."""
    z_base = line['vr_kv'] ** 2 / sb_mva
    n = line['num_of_parallel']
    length = line['length_km']

    r = line['r_ohm_per_km'] * length / n / z_base
    x = line['x_ohm_per_km'] * length / n / z_base
    g = line.get('g_mus_per_km', 0) * 1e-6 * length * n * z_base
    b = 2 * pi * f_hz * line.get('c_muf_per_km', 0) * 1e-6 * length * n * z_base

    i_max = line.get('i_max_ka')
    i_base = sb_mva / sqrt(3) / line['vr_kv']
    s_max_pu = i_max / i_base if i_max is not None else None

    return {
        'uid': line['uid'],
        'from_bus': line['bus_1'],
        'to_bus': line['bus_2'],
        'r': r, 'x': x, 'g': g, 'b': b,
        'ratio': 1.0,
        'angle': 0.0,
        's_max_pu': s_max_pu,
        'from_status': line['switch_1_status'],
        'to_status': line['switch_2_status'],
    }


def trafo_2w_to_branch(trafo, sb_mva):
    """Convert a two-winding transformer dict to a branch dict."""
    primary_tap = calculate_tap_ratio(
        trafo.get('primary_tap_changer'), trafo['vr_1_kv'], trafo['vr_b1_kv'])
    secondary_tap = calculate_tap_ratio(
        trafo.get('secondary_tap_changer'), trafo['vr_2_kv'], trafo['vr_b2_kv'])

    tap_ratio = primary_tap / secondary_tap
    angle = trafo['phase_shift_degree'] * pi / 180 if trafo.get('phase_shifter') else 0.0

    sec2 = secondary_tap ** 2
    z = calculate_impedance(trafo['vk_percent'], trafo.get('pcu_kw', 0),
                            trafo['sr_mva'], sb_mva) * sec2

    y_m = trafo.get('j0_percent', 0) / 100 * trafo['sr_mva'] / sb_mva / sec2
    g_m = trafo.get('pfe_kw', 0) / sb_mva / 1000 / sec2
    b_m = -sqrt(max(y_m ** 2 - g_m ** 2, 0))

    return {
        'uid': trafo['uid'],
        'from_bus': trafo['bus_1'],
        'to_bus': trafo['bus_2'],
        'r': z.real, 'x': z.imag, 'g': g_m, 'b': b_m,
        'ratio': tap_ratio,
        'angle': angle,
        's_max_pu': trafo['sr_mva'] / sb_mva,
        'from_status': trafo['switch_1_status'],
        'to_status': trafo['switch_2_status'],
    }


def trafo_3w_to_branches(trafo, sb_mva, aux_bus_uid):
    """Convert a three-winding transformer dict to three branch dicts.

    Returns (aux_bus_data, [branch_1, branch_2, branch_3]).
    aux_bus_data is a dict for the internal star-point bus.
    """
    primary_tap = calculate_tap_ratio(
        trafo.get('primary_tap_changer'), trafo['vr_1_kv'], trafo['vr_b1_kv'])
    secondary_tap = calculate_tap_ratio(
        trafo.get('secondary_tap_changer'), trafo['vr_2_kv'], trafo['vr_b2_kv'])
    tertiary_tap = calculate_tap_ratio(
        trafo.get('tertiary_tap_changer'), trafo['vr_3_kv'], trafo['vr_b3_kv'])

    z_12 = calculate_impedance(trafo['vk_12_percent'], trafo.get('pcu_12_kw', 0),
                               trafo['sr_12_mva'], sb_mva)
    z_13 = calculate_impedance(trafo['vk_13_percent'], trafo.get('pcu_13_kw', 0),
                               trafo['sr_13_mva'], sb_mva)
    z_23 = calculate_impedance(trafo['vk_23_percent'], trafo.get('pcu_23_kw', 0),
                               trafo['sr_23_mva'], sb_mva)

    z_1 = (z_12 + z_13 - z_23) / 2
    z_2 = (z_12 + z_23 - z_13) / 2
    z_3 = (z_13 + z_23 - z_12) / 2

    y_m = trafo.get('j0_percent', 0) / 100 * trafo['sr_12_mva'] / sb_mva
    g_m = trafo.get('pfe_kw', 0) / sb_mva / 1000
    b_m = -sqrt(max(y_m ** 2 - g_m ** 2, 0))

    aux_bus = {
        'uid': aux_bus_uid,
        'vr_kv': None,
        'pf_type': 'PQ',
        'v': 1.0,
        'theta': 0.0,
        'g_shunt': 0.0,
        'b_shunt': 0.0,
    }

    def _angle(key):
        return trafo.get(key, 0) * pi / 180

    branches = [
        {
            'uid': f"{trafo['uid']}-primary",
            'from_bus': trafo['bus_1'],
            'to_bus': aux_bus_uid,
            'r': z_1.real, 'x': z_1.imag, 'g': g_m, 'b': b_m,
            'ratio': primary_tap,
            'angle': _angle('primary_phase_shift_degree'),
            's_max_pu': max(trafo['sr_12_mva'], trafo['sr_13_mva']) / sb_mva,
            'from_status': trafo['switch_1_status'],
            'to_status': True,
        },
        {
            'uid': f"{trafo['uid']}-secondary",
            'from_bus': trafo['bus_2'],
            'to_bus': aux_bus_uid,
            'r': z_2.real, 'x': z_2.imag, 'g': 0.0, 'b': 0.0,
            'ratio': secondary_tap,
            'angle': _angle('secondary_phase_shift_degree'),
            's_max_pu': max(trafo['sr_12_mva'], trafo['sr_23_mva']) / sb_mva,
            'from_status': trafo['switch_2_status'],
            'to_status': True,
        },
        {
            'uid': f"{trafo['uid']}-tertiary",
            'from_bus': trafo['bus_3'],
            'to_bus': aux_bus_uid,
            'r': z_3.real, 'x': z_3.imag, 'g': 0.0, 'b': 0.0,
            'ratio': tertiary_tap,
            'angle': _angle('tertiary_phase_shift_degree'),
            's_max_pu': max(trafo['sr_13_mva'], trafo['sr_23_mva']) / sb_mva,
            'from_status': trafo['switch_3_status'],
            'to_status': True,
        },
    ]
    return aux_bus, branches
