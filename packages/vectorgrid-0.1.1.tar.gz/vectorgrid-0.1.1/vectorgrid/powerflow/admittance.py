import numpy as np
from scipy.sparse import lil_matrix, csr_matrix, diags


def build_admittance_matrices(n_buses, n_branches, from_bus, to_bus,
                              r, x, g, b, ratio, angle,
                              from_status, to_status, g_shunt, b_shunt):
    """Build branch and bus admittance matrices Yf, Yt, Yb.

    All branch parameters are numpy arrays of length n_branches.
    g_shunt, b_shunt are numpy arrays of length n_buses.
    Returns (Yf, Yt, Yb) as dense complex numpy arrays.
    """
    ratio = ratio.copy()
    ratio[ratio == 0] = 1.0
    tap = ratio * (np.cos(angle) + 1j * np.sin(angle))

    y_series = 1.0 / (r + 1j * x)
    y_shunt = g + 1j * b

    from_active = from_status.astype(bool)
    to_active = to_status.astype(bool)

    Yf = lil_matrix((n_branches, n_buses), dtype=np.complex128)
    Yt = lil_matrix((n_branches, n_buses), dtype=np.complex128)

    both = from_active & to_active
    if both.any():
        idx = np.where(both)[0]
        for i in idx:
            f, t = from_bus[i], to_bus[i]
            Yf[i, f] = (y_series[i] + y_shunt[i] / 2) / tap[i] ** 2
            Yf[i, t] = -y_series[i] / tap[i]
            Yt[i, f] = -y_series[i] / tap[i]
            Yt[i, t] = y_series[i] + y_shunt[i] / 2

    from_only = from_active & ~to_active
    if from_only.any():
        idx = np.where(from_only)[0]
        for i in idx:
            f = from_bus[i]
            Yf[i, f] = y_shunt[i] * (0.5 + 1.0 / (2 + y_shunt[i] / y_series[i])) / tap[i] ** 2

    to_only = ~from_active & to_active
    if to_only.any():
        idx = np.where(to_only)[0]
        for i in idx:
            t = to_bus[i]
            Yt[i, t] = y_shunt[i] * (0.5 + 1.0 / (2 + y_shunt[i] / y_series[i]))

    Cf = csr_matrix(
        (from_active | np.zeros(n_branches, dtype=bool),
         (np.arange(n_branches), from_bus)),
        shape=(n_branches, n_buses),
    )
    Ct = csr_matrix(
        (to_active | np.zeros(n_branches, dtype=bool),
         (np.arange(n_branches), to_bus)),
        shape=(n_branches, n_buses),
    )

    Yf_csr = Yf.tocsr()
    Yt_csr = Yt.tocsr()
    Yb = Cf.T @ Yf_csr + Ct.T @ Yt_csr
    Yb += diags(g_shunt + 1j * b_shunt)

    return (
        np.asarray(Yf_csr.todense()),
        np.asarray(Yt_csr.todense()),
        np.asarray(Yb.todense()),
    )
