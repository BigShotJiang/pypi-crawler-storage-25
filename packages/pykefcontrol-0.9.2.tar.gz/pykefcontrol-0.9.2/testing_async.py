"""Mini script to test KefAsyncConnector setData calls (POST migration)."""

import asyncio
import aiohttp
from pykefcontrol import KefAsyncConnector

HOST = "192.168.124.46"


async def main():
    session = aiohttp.ClientSession()
    spkr = KefAsyncConnector(HOST, session=session)

    try:
        # 1. Get current volume
        vol = await spkr.volume
        print(f"Current volume: {vol}")

        # 2. Test set_volume
        new_vol = vol + 5 if vol < 10 else vol - 5
        print(f"Setting volume to {new_vol}...")
        await spkr.set_volume(new_vol)
        check_vol = await spkr.volume
        print(f"Volume after set: {check_vol}")
        assert check_vol == new_vol, f"Expected {new_vol}, got {check_vol}"
        print("  -> set_volume OK")

        # Restore volume
        await spkr.set_volume(vol)
        print(f"Volume restored to {vol}")

        # 3. Test set_source
        src = await spkr.source
        print(f"\nCurrent source: {src}")
        print("Setting source to bluetooth...")
        await spkr.set_source("bluetooth")
        await asyncio.sleep(2)
        check_src = await spkr.source
        print(f"Source after set: {check_src}")
        print("  -> set_source OK")

        # Restore source
        print(f"Restoring source to {src}...")
        await spkr.set_source(src)
        await asyncio.sleep(2)

        # 4. Test set_status (powerOn)
        status = await spkr.status
        print(f"\nCurrent status: {status}")
        print("Setting status to powerOn...")
        await spkr.set_status("powerOn")
        await asyncio.sleep(2)
        check_status = await spkr.status
        print(f"Status after set: {check_status}")
        print("  -> set_status OK")

        # 5. Test track control (pause)
        print("\nSending pause command...")
        await spkr._track_control("pause")
        print("  -> _track_control OK")

        print("\n--- All async tests passed! ---")

    except Exception as e:
        print(f"\nERROR: {e}")
        raise
    finally:
        await session.close()


if __name__ == "__main__":
    asyncio.run(main())
