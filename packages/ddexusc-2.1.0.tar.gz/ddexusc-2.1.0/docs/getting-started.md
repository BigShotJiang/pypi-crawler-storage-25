# Getting Started with ddexusc

## Installation

```bash
pip install ddexusc
```

## First Steps

### 1. Set your API key

```bash
export DDEXUS_API_KEY="your-api-key-here"
```

### 2. Submit a website

```python
from ddexusc import DdexusClient

client = DdexusClient()
result = client.submit(
    title="My Tool",
    description="A great developer tool for Python",
    url="https://mytool.com",
    category="Development Tools",
    tags=["python", "cli"],
    author="Your Name"
)
print(f"Submitted! ID: {result['id']}")
```

### 3. Search websites

```python
results = client.search_websites(query="machine learning")
for website in results.websites:
    print(f"{website.title}: {website.url}")
```

## CLI Usage

```bash
ddexus submit --interactive
ddexus search "python"
ddexus list --category "Development Tools"
```

## Configuration

Priority: explicit args > config file > environment variables

Config file location: `~/.ddexus/config.ini`

```ini
[default]
api_key = your-api-key
base_url = https://ddexus.com
timeout = 30
```
