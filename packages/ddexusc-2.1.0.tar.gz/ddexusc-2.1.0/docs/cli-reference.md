# CLI Reference

## ddexus

```
ddexus [OPTIONS] COMMAND [ARGS]
```

### Global Options
- `--api-key, -k`: API key (or set DDEXUS_API_KEY)
- `--base-url, -b`: API base URL (or set DDEXUS_BASE_URL)
- `--version`: Show version
- `--help`: Show help

## Commands

### ddexus submit
Submit a website to ddexus.

```bash
ddexus submit [OPTIONS]
```

Options:
- `--title, -t`: Website title
- `--url, -u`: Website URL
- `--description, -d`: Website description
- `--category, -c`: Website category
- `--tags`: Tags (repeatable: --tags python --tags cli)
- `--author, -a`: Author name
- `--json`: Output as JSON
- `--interactive, -i`: Interactive prompts

Examples:
```bash
ddexus submit --interactive
ddexus submit -t "My Tool" -u "https://mytool.com" -d "Description" -c "Dev"
```

### ddexus search
Search websites on ddexus.

```bash
ddexus search [QUERY] [OPTIONS]
```

Options:
- `--category, -c`: Filter by category
- `--limit, -n`: Results count (default 10)
- `--sort, -s`: Sort order (newest/oldest/popular/featured)
- `--json`: Output as JSON

Examples:
```bash
ddexus search "python"
ddexus search --category "AI & Machine Learning" --sort popular
```

### ddexus list
List websites on ddexus.

```bash
ddexus list [OPTIONS]
```

Options:
- `--category, -c`: Filter by category
- `--page, -p`: Page number
- `--limit, -n`: Results per page
- `--sort, -s`: Sort order (newest/oldest/popular/featured)
- `--featured`: Show only featured
- `--json`: Output as JSON

Examples:
```bash
ddexus list
ddexus list --featured
ddexus list --category "Design" --sort popular -n 20
```
