# API Reference

## DdexusClient

Main synchronous client for the ddexus API.

### Methods

| Method | Description | Returns |
|--------|-------------|---------|
| `submit(title, description, url, category, tags, author)` | Submit a new website | `Dict[str, Any]` |
| `get_website(website_id)` | Get website by ID | `Website` |
| `search_websites(query, category, page, limit, sort)` | Search websites | `PaginatedResponse` |
| `get_categories()` | List all categories | `List[Category]` |
| `get_featured()` | Get featured websites | `List[Website]` |
| `get_trending(limit)` | Get trending websites | `List[Website]` |
| `get_latest(limit)` | Get latest websites | `List[Website]` |

### Parameters

#### submit()
- `title` (str, required): Website name (2-200 chars)
- `description` (str, required): Website description (10-2000 chars)
- `url` (str, required): Full URL starting with http/https
- `category` (str, required): Category name
- `tags` (List[str], optional): Max 20 tags
- `author` (str, optional): Author name

#### search_websites()
- `query` (str): Search term
- `category` (str): Filter by category
- `page` (int): Page number (default 1)
- `limit` (int): Results per page (1-50, default 12)
- `sort` (str): "newest", "oldest", "popular", "featured"

## Models

### Website
Fields: id, title, description, url, category, tags, author, favicon, screenshot, views, featured, status, createdAt, updatedAt

### Category
Fields: id, name, slug, description, icon, createdAt, _count

### PaginatedResponse
Fields: websites, total, page, limit, totalPages
Properties: has_next, has_prev, next_page, prev_page
