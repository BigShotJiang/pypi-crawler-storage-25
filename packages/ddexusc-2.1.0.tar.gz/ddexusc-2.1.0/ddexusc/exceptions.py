"""Custom exception classes for ddexusc."""


class DdexusError(Exception):
    """Base exception for all ddexus errors."""

    def __init__(self, message: str = "An error occurred", code: str = "UNKNOWN"):
        self.message = message
        self.code = code
        super().__init__(f"[{code}] {message}")


class AuthenticationError(DdexusError):
    """Raised when API key is invalid or missing."""

    def __init__(self, message: str = "Invalid or missing API key"):
        super().__init__(message, code="AUTH_ERROR")


class ValidationError(DdexusError):
    """Raised when request data fails validation."""

    def __init__(self, message: str = "Validation failed"):
        super().__init__(message, code="VALIDATION_ERROR")


class RateLimitError(DdexusError):
    """Raised when API rate limit is exceeded."""

    def __init__(self, message: str = "Rate limit exceeded. Try again later."):
        super().__init__(message, code="RATE_LIMIT")


class NotFoundError(DdexusError):
    """Raised when the requested resource is not found."""

    def __init__(self, message: str = "Requested resource not found"):
        super().__init__(message, code="NOT_FOUND")


class APIError(DdexusError):
    """Raised when the API returns an error response."""

    def __init__(self, message: str = "API returned an error", status_code: int = 500):
        self.status_code = status_code
        super().__init__(message, code="API_ERROR")


class ConnectionError(DdexusError):
    """Raised when connection to the API server fails."""

    def __init__(self, message: str = "Failed to connect to ddexus API"):
        super().__init__(message, code="CONNECTION_ERROR")


class TimeoutError(DdexusError):
    """Raised when a request times out."""

    def __init__(self, message: str = "Request timed out"):
        super().__init__(message, code="TIMEOUT_ERROR")
