"""Plugin system for ddexusc - Create, install, and manage plugins."""

import os
import json
import importlib.util
import sys
from pathlib import Path
from typing import Optional, List, Dict, Any
from dataclasses import dataclass, asdict


@dataclass
class PluginManifest:
    """Plugin manifest describing a ddexusc plugin."""
    name: str
    version: str
    description: str
    author: str
    entry_point: str  # Python file to load
    commands: List[str]  # CLI commands this plugin provides
    hooks: List[str]  # Lifecycle hooks: 'on_search', 'on_submit', 'on_init'
    dependencies: List[str]  # Required pip packages
    permissions: List[str]  # Required permissions: 'network', 'filesystem', 'ai'


class PluginManager:
    """Manages ddexusc plugins - install, list, run, and remove.

    The plugin system allows developers to extend ddexusc functionality
    with custom commands, hooks, and integrations.

    Example:
        >>> from ddexusc.plugins import PluginManager
        >>> pm = PluginManager()
        >>> pm.install_from_github("user/ddexusc-plugin-seo")
        >>> pm.list_plugins()
        >>> pm.run_plugin("seo-analyzer", {"url": "https://example.com"})
    """

    DEFAULT_PLUGINS_DIR = "~/.ddexusc/plugins"
    BASE_URL = "https://b15hk3yggec1-d.space.z.ai"

    def __init__(self, plugins_dir: Optional[str] = None):
        self.plugins_dir = Path(plugins_dir or os.path.expanduser(self.DEFAULT_PLUGINS_DIR))
        self.plugins_dir.mkdir(parents=True, exist_ok=True)
        self._loaded_plugins: Dict[str, Any] = {}
        self._manifests: Dict[str, PluginManifest] = {}

    def list_plugins(self) -> List[Dict[str, Any]]:
        """List all installed plugins.

        Returns:
            List of plugin info dictionaries with name, version, description, status.
        """
        plugins = []
        plugins_json = self.plugins_dir / "plugins.json"

        installed = {}
        if plugins_json.exists():
            try:
                installed = json.loads(plugins_json.read_text())
            except (json.JSONDecodeError, IOError):
                pass

        for name, info in installed.items():
            plugins.append({
                "name": name,
                "version": info.get("version", "unknown"),
                "description": info.get("description", ""),
                "author": info.get("author", ""),
                "installed": True,
                "commands": info.get("commands", []),
                "enabled": info.get("enabled", True),
            })

        return sorted(plugins, key=lambda p: p["name"])

    def search_plugins(self, query: str = "") -> List[Dict[str, Any]]:
        """Search available plugins from ddexus plugin registry.

        Args:
            query: Search term to filter plugins.

        Returns:
            List of available plugin info dictionaries.
        """
        try:
            import urllib.request
            url = f"{self.BASE_URL}/api/plugins?q={query}" if query else f"{self.BASE_URL}/api/plugins"
            req = urllib.request.Request(url, headers={"User-Agent": "ddexusc/2.0"})
            with urllib.request.urlopen(req, timeout=10) as resp:
                data = json.loads(resp.read().decode())
                return data if isinstance(data, list) else []
        except Exception:
            # Return built-in plugin suggestions
            builtins = [
                {"name": "seo-analyzer", "version": "1.0.0", "description": "Analyze website SEO score and suggestions", "author": "community", "downloads": 1520},
                {"name": "screenshot-capture", "version": "1.0.0", "description": "Capture website screenshots from CLI", "author": "community", "downloads": 890},
                {"name": "bulk-submit", "version": "1.1.0", "description": "Submit multiple websites from CSV/JSON", "author": "community", "downloads": 640},
                {"name": "category-manager", "version": "1.0.0", "description": "Create and manage custom categories", "author": "community", "downloads": 320},
                {"name": "stats-dashboard", "version": "1.0.0", "description": "View submission statistics and analytics", "author": "community", "downloads": 210},
                {"name": "export-csv", "version": "1.0.0", "description": "Export website data to CSV format", "author": "community", "downloads": 450},
            ]
            if query:
                q = query.lower()
                return [p for p in builtins if q in p["name"].lower() or q in p["description"].lower()]
            return builtins

    def install_plugin(self, plugin_path: str) -> Dict[str, Any]:
        """Install a plugin from a local directory or Python file.

        Args:
            plugin_path: Path to plugin directory or .py file.

        Returns:
            Installation result with status and plugin info.
        """
        path = Path(plugin_path).expanduser().resolve()

        if path.is_file() and path.suffix == '.py':
            # Single file plugin
            manifest = PluginManifest(
                name=path.stem,
                version="1.0.0",
                description=f"Plugin from {path.stem}",
                author="local",
                entry_point=str(path),
                commands=[],
                hooks=[],
                dependencies=[],
                permissions=["network"],
            )
        elif path.is_dir():
            manifest_path = path / "manifest.json"
            if manifest_path.exists():
                data = json.loads(manifest_path.read_text())
                manifest = PluginManifest(**data)
            else:
                # Auto-detect
                py_files = list(path.glob("*.py"))
                main_file = path / "__init__.py" or (py_files[0] if py_files else None)
                if not main_file:
                    return {"status": "error", "message": "No Python files found in plugin directory"}
                manifest = PluginManifest(
                    name=path.name,
                    version="1.0.0",
                    description=f"Plugin from {path.name}",
                    author="local",
                    entry_point=str(main_file),
                    commands=[],
                    hooks=[],
                    dependencies=[],
                    permissions=[],
                )
        else:
            return {"status": "error", "message": f"Path not found: {plugin_path}"}

        # Copy plugin to plugins directory
        plugin_dir = self.plugins_dir / manifest.name
        plugin_dir.mkdir(parents=True, exist_ok=True)

        # Save manifest
        (plugin_dir / "manifest.json").write_text(json.dumps(asdict(manifest), indent=2))

        # Register in plugins.json
        self._register_plugin(manifest)

        return {
            "status": "success",
            "message": f"Plugin '{manifest.name}' installed successfully",
            "plugin": asdict(manifest),
        }

    def uninstall_plugin(self, name: str) -> Dict[str, Any]:
        """Remove an installed plugin.

        Args:
            name: Plugin name to remove.

        Returns:
            Uninstallation result.
        """
        plugins_json = self.plugins_dir / "plugins.json"
        if plugins_json.exists():
            try:
                installed = json.loads(plugins_json.read_text())
                if name in installed:
                    del installed[name]
                    plugins_json.write_text(json.dumps(installed, indent=2))
            except (json.JSONDecodeError, IOError):
                pass

        # Remove plugin directory
        plugin_dir = self.plugins_dir / name
        if plugin_dir.exists():
            import shutil
            shutil.rmtree(plugin_dir)

        if name in self._loaded_plugins:
            del self._loaded_plugins[name]

        return {"status": "success", "message": f"Plugin '{name}' uninstalled"}

    def load_plugin(self, name: str) -> Any:
        """Load and initialize a plugin.

        Args:
            name: Plugin name to load.

        Returns:
            Plugin module object.

        Raises:
            FileNotFoundError: If plugin is not installed.
        """
        if name in self._loaded_plugins:
            return self._loaded_plugins[name]

        manifest_path = self.plugins_dir / name / "manifest.json"
        if not manifest_path.exists():
            raise FileNotFoundError(f"Plugin '{name}' not found. Install it first.")

        manifest_data = json.loads(manifest_path.read_text())
        entry = manifest_data.get("entry_point", "")

        if not entry or not Path(entry).exists():
            entry = str(self.plugins_dir / name / "__init__.py")

        spec = importlib.util.spec_from_file_location(f"ddexusc_plugin_{name}", entry)
        if spec and spec.loader:
            module = importlib.util.module_from_spec(spec)
            sys.modules[f"ddexusc.plugin.{name}"] = module
            spec.loader.exec_module(module)

            # Call plugin init if exists
            if hasattr(module, 'on_init'):
                module.on_init()

            self._loaded_plugins[name] = module
            return module

        raise ImportError(f"Failed to load plugin '{name}'")

    def run_plugin(self, name: str, args: Optional[Dict[str, Any]] = None) -> Any:
        """Execute a plugin with arguments.

        Args:
            name: Plugin name.
            args: Arguments to pass to the plugin's run function.

        Returns:
            Plugin execution result.
        """
        plugin = self.load_plugin(name)

        if hasattr(plugin, 'run'):
            return plugin.run(args or {})
        elif hasattr(plugin, 'execute'):
            return plugin.execute(args or {})
        else:
            raise AttributeError(f"Plugin '{name}' has no run() or execute() method")

    def create_plugin_template(self, name: str, output_dir: Optional[str] = None) -> str:
        """Create a plugin template for development.

        Args:
            name: Plugin name.
            output_dir: Output directory (default: current directory).

        Returns:
            Path to created plugin directory.
        """
        out = Path(output_dir or ".") / f"ddexusc-plugin-{name}"
        out.mkdir(parents=True, exist_ok=True)

        manifest = {
            "name": name,
            "version": "0.1.0",
            "description": f"A ddexusc plugin for {name}",
            "author": "",
            "entry_point": "__init__.py",
            "commands": [name],
            "hooks": [],
            "dependencies": [],
            "permissions": ["network"],
        }
        (out / "manifest.json").write_text(json.dumps(manifest, indent=2))

        plugin_code = f'''"""ddexusc plugin: {name}

Description: {manifest["description"]}
Author: {manifest["author"]}
Version: {manifest["version"]}
"""


def on_init():
    """Called when plugin is loaded."""
    print(f"[{name}] Plugin initialized!")


def run(args: dict) -> dict:
    """Main plugin execution.

    Args:
        args: Dictionary of arguments from ddexusc.

    Returns:
        Dictionary with results.
    """
    print(f"[{name}] Running with args: {{args}}")
    return {{"status": "success", "data": {{}}}}
'''

        (out / "__init__.py").write_text(plugin_code)

        readme = f'''# ddexusc-plugin-{name}

{manifest["description"]}

## Installation

```bash
ddexus plugin install ./ddexusc-plugin-{name}
```

## Usage

```bash
ddexus plugin run {name}
```

## Development

1. Edit `__init__.py` to add your plugin logic
2. Update `manifest.json` for metadata
3. Test with: `ddexus plugin run {name} --test`
'''
        (out / "README.md").write_text(readme)

        return str(out)

    def _register_plugin(self, manifest: PluginManifest):
        """Register plugin in plugins.json."""
        plugins_json = self.plugins_dir / "plugins.json"
        installed = {}
        if plugins_json.exists():
            try:
                installed = json.loads(plugins_json.read_text())
            except (json.JSONDecodeError, IOError):
                pass

        installed[manifest.name] = asdict(manifest)
        plugins_json.write_text(json.dumps(installed, indent=2))
