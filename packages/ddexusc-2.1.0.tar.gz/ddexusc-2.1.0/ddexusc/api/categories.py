"""Category API operations for ddexusc."""

from typing import List, Optional, Dict, Any

from ddexusc.models import Category
from ddexusc.utils.http import HttpClient


class CategoryAPI:
    """API operations for website categories."""

    def __init__(self, http_client: HttpClient):
        """Initialize category API.

        Args:
            http_client: The HTTP client instance.
        """
        self._http = http_client

    def list(self) -> List[Category]:
        """List all available categories.

        Returns:
            List of Category objects.

        Raises:
            APIError: If the request fails.
        """
        data = self._http.get("/api/categories")
        return [Category(**item) for item in data]

    def get(self, category_id: str) -> Category:
        """Get a single category by ID.

        Args:
            category_id: The category ID.

        Returns:
            Category object.

        Raises:
            NotFoundError: If category not found.
            APIError: If the request fails.
        """
        data = self._http.get(f"/api/categories/{category_id}")
        return Category(**data)

    def get_by_slug(self, slug: str) -> Optional[Category]:
        """Get a category by its slug.

        Args:
            slug: The category slug.

        Returns:
            Category object or None if not found.
        """
        categories = self.list()
        for cat in categories:
            if cat.slug == slug:
                return cat
        return None

    def get_website_count(self, category_name: str) -> int:
        """Get the number of websites in a category.

        Args:
            category_name: The category name.

        Returns:
            Number of websites in the category.
        """
        categories = self.list()
        for cat in categories:
            if cat.name == category_name:
                return cat.website_count
        return 0
