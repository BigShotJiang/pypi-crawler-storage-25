"""API endpoint modules for ddexusc."""

from ddexusc.api.websites import WebsiteAPI
from ddexusc.api.categories import CategoryAPI
from ddexusc.api.search import SearchAPI
from ddexusc.api.auth import AuthAPI

__all__ = ["WebsiteAPI", "CategoryAPI", "SearchAPI", "AuthAPI"]
