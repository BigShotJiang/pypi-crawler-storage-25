"""Authentication helpers for the ddexus API."""

import hashlib
import hmac
import time
from typing import Dict, Optional


class AuthAPI:
    """Handles authentication for the ddexus API."""

    def __init__(self, http_client):
        """Initialize auth API.

        Args:
            http_client: The HTTP client instance.
        """
        self._http = http_client

    @staticmethod
    def generate_signature(api_key: str, method: str, path: str, timestamp: Optional[int] = None) -> Dict[str, str]:
        """Generate HMAC signature for request authentication.

        Args:
            api_key: The API key to sign with.
            method: HTTP method (GET, POST, etc.).
            path: API endpoint path.
            timestamp: Unix timestamp (defaults to current time).

        Returns:
            Dictionary with signature headers.
        """
        if timestamp is None:
            timestamp = int(time.time())

        message = f"{method}:{path}:{timestamp}"
        signature = hmac.new(
            api_key.encode("utf-8"),
            message.encode("utf-8"),
            hashlib.sha256,
        ).hexdigest()

        return {
            "X-Ddexus-Timestamp": str(timestamp),
            "X-Ddexus-Signature": signature,
        }

    def validate_api_key(self, api_key: str) -> bool:
        """Validate if an API key is valid.

        Args:
            api_key: The API key to validate.

        Returns:
            True if valid, False otherwise.
        """
        try:
            self._http.get("/api/auth/validate")
            return True
        except Exception:
            return False
