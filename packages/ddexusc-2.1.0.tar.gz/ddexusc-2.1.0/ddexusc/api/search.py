"""Website search API operations for ddexusc."""

from typing import Optional, Dict, Any

from ddexusc.models import Website, PaginatedResponse, SearchParams
from ddexusc.utils.http import HttpClient


class SearchAPI:
    """API operations for searching websites."""

    def __init__(self, http_client: HttpClient):
        """Initialize search API.

        Args:
            http_client: The HTTP client instance.
        """
        self._http = http_client

    def search(
        self,
        query: str = "",
        category: str = "",
        page: int = 1,
        limit: int = 12,
        sort: str = "newest",
    ) -> PaginatedResponse:
        """Search websites on ddexus.

        Args:
            query: Search term to match against title, description, and tags.
            category: Filter by category name.
            page: Page number (1-indexed).
            limit: Results per page (1-50).
            sort: Sort order: 'newest', 'oldest', 'popular', or 'featured'.

        Returns:
            PaginatedResponse with matching websites.

        Raises:
            ValidationError: If search parameters are invalid.
            APIError: If the request fails.
        """
        params = SearchParams(
            query=query,
            category=category,
            page=page,
            limit=limit,
            sort=sort,
        )

        data = self._http.get(
            "/api/websites",
            params=params.model_dump(exclude_none=True),
        )

        return PaginatedResponse(**data)

    def trending(self, limit: int = 10) -> list:
        """Get trending websites (most viewed).

        Args:
            limit: Number of results to return.

        Returns:
            List of trending Website objects.
        """
        data = self._http.get(
            "/api/websites",
            params={"sort": "popular", "limit": min(limit, 50)},
        )
        return [Website(**item) for item in data.get("websites", [])]

    def featured(self, limit: int = 10) -> list:
        """Get featured websites.

        Args:
            limit: Number of results to return.

        Returns:
            List of featured Website objects.
        """
        data = self._http.get("/api/websites/featured")
        return [Website(**item) for item in data]

    def latest(self, limit: int = 12) -> list:
        """Get the latest websites.

        Args:
            limit: Number of results to return.

        Returns:
            List of latest Website objects.
        """
        data = self._http.get(
            "/api/websites",
            params={"sort": "newest", "limit": min(limit, 50)},
        )
        return [Website(**item) for item in data.get("websites", [])]

    def by_category(
        self,
        category: str,
        page: int = 1,
        limit: int = 12,
        sort: str = "newest",
    ) -> PaginatedResponse:
        """Search websites by category.

        Args:
            category: Category name to filter by.
            page: Page number.
            limit: Results per page.
            sort: Sort order.

        Returns:
            PaginatedResponse filtered by category.
        """
        return self.search(category=category, page=page, limit=limit, sort=sort)
