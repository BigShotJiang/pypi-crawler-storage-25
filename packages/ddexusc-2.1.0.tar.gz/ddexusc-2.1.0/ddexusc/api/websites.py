"""Website CRUD API operations for ddexusc."""

from typing import Optional, Dict, Any

from ddexusc.models import Website, PaginatedResponse
from ddexusc.utils.http import HttpClient
from ddexusc.utils.validators import (
    validate_url,
    validate_title,
    validate_description,
    validate_category,
    validate_tags,
)


class WebsiteAPI:
    """API operations for website management."""

    def __init__(self, http_client: HttpClient):
        """Initialize website API.

        Args:
            http_client: The HTTP client instance.
        """
        self._http = http_client

    def submit(
        self,
        title: str,
        description: str,
        url: str,
        category: str,
        tags: Optional[list] = None,
        author: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Submit a new website to ddexus.

        Args:
            title: Website display name.
            description: Website description.
            url: Website URL.
            category: Website category.
            tags: Optional list of tags.
            author: Optional author name.

        Returns:
            Dictionary with the created website data.

        Raises:
            ValidationError: If input validation fails.
            APIError: If the request fails.
        """
        # Validate all inputs
        title = validate_title(title)
        description = validate_description(description)
        url = validate_url(url)
        category = validate_category(category)
        tags = validate_tags(tags)

        payload = {
            "title": title,
            "description": description,
            "url": url,
            "category": category,
            "tags": ", ".join(tags) if tags else "",
            "author": author or "ddexus",
        }

        return self._http.post("/api/websites", json=payload)

    def get(self, website_id: str) -> Website:
        """Get a website by ID.

        Args:
            website_id: The website ID.

        Returns:
            Website object.

        Raises:
            NotFoundError: If website not found.
            APIError: If the request fails.
        """
        data = self._http.get(f"/api/websites/{website_id}")
        return Website(**data)

    def list(
        self,
        query: str = "",
        category: str = "",
        page: int = 1,
        limit: int = 12,
        sort: str = "newest",
    ) -> PaginatedResponse:
        """List websites with optional filters.

        Args:
            query: Search query string.
            category: Category filter.
            page: Page number (1-indexed).
            limit: Results per page (1-50).
            sort: Sort order.

        Returns:
            PaginatedResponse with website listings.
        """
        params = {
            "q": query,
            "category": category,
            "page": page,
            "limit": min(limit, 50),
            "sort": sort,
        }

        data = self._http.get("/api/websites", params=params)
        return PaginatedResponse(**data)

    def update(
        self,
        website_id: str,
        title: Optional[str] = None,
        description: Optional[str] = None,
        url: Optional[str] = None,
        category: Optional[str] = None,
        tags: Optional[list] = None,
        author: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Update an existing website.

        Args:
            website_id: The website ID to update.
            title: New title (optional).
            description: New description (optional).
            url: New URL (optional).
            category: New category (optional).
            tags: New tags (optional).
            author: New author (optional).

        Returns:
            Dictionary with the updated website data.

        Raises:
            NotFoundError: If website not found.
            APIError: If the request fails.
        """
        payload = {}
        if title is not None:
            payload["title"] = validate_title(title)
        if description is not None:
            payload["description"] = validate_description(description)
        if url is not None:
            payload["url"] = validate_url(url)
        if category is not None:
            payload["category"] = validate_category(category)
        if tags is not None:
            tags = validate_tags(tags)
            payload["tags"] = ", ".join(tags) if tags else ""
        if author is not None:
            payload["author"] = author

        if not payload:
            raise ValueError("At least one field must be provided for update")

        return self._http.put(f"/api/websites/{website_id}", json=payload)

    def delete(self, website_id: str) -> Dict[str, Any]:
        """Delete a website.

        Args:
            website_id: The website ID to delete.

        Returns:
            Dictionary with deletion confirmation.

        Raises:
            NotFoundError: If website not found.
            APIError: If the request fails.
        """
        return self._http.delete(f"/api/websites/{website_id}")
