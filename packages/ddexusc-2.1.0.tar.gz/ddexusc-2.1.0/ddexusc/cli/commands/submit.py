"""Submit command for ddexus CLI."""

import click


@click.command()
@click.option("--title", "-t", help="Website title")
@click.option("--url", "-u", help="Website URL")
@click.option("--description", "-d", help="Website description")
@click.option("--category", "-c", help="Website category")
@click.option("--tags", multiple=True, help="Tags (can specify multiple)")
@click.option("--author", "-a", help="Author name")
@click.option("--json", "is_json", is_flag=True, help="Output as JSON")
@click.option("--interactive", "-i", is_flag=True, help="Force interactive prompts")
def submit_cmd(title, url, description, category, tags, author, is_json, interactive):
    """Submit a website to ddexus."""
    try:
        from ddexusc import DdexusClient
        from ddexusc.cli.utils import print_success

        # Collect missing values interactively if not provided
        if interactive or not all([title, url, description, category]):
            if not title:
                title = click.prompt("Website title")
            if not url:
                url = click.prompt("Website URL")
            if not description:
                description = click.prompt("Website description")
            if not category:
                categories = ["Development Tools", "AI & Machine Learning", "Design",
                              "Productivity", "Cloud Services", "Education",
                              "DevOps", "Analytics", "Open Source", "Other"]
                click.echo("Available categories:")
                for i, cat in enumerate(categories, 1):
                    click.echo(f"  {i}. {cat}")
                choice = click.prompt("Select category number", type=int)
                if 1 <= choice <= len(categories):
                    category = categories[choice - 1]
                else:
                    category = click.prompt("Category name")

        if not all([title, url, description, category]):
            click.secho("Error: title, url, description, and category are required.", fg="red")
            click.echo("Use --interactive flag for guided prompts.")
            raise SystemExit(1)

        client = DdexusClient()
        result = client.submit(
            title=title,
            url=url,
            description=description,
            category=category,
            tags=list(tags) if tags else None,
            author=author,
        )

        if is_json:
            click.echo_json(result)
        else:
            print_success("Website submitted successfully!")
            click.echo(f"  ID:          {result.get('id', 'N/A')}")
            click.echo(f"  Title:       {result.get('title', 'N/A')}")
            click.echo(f"  URL:         {result.get('url', 'N/A')}")
            click.echo(f"  Category:    {result.get('category', 'N/A')}")
            click.echo(f"  Status:      {result.get('status', 'N/A')}")

    except Exception as e:
        click.secho(f"Error: {e}", fg="red")
        raise SystemExit(1)
