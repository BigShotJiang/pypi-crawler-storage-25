"""Search command for ddexus CLI."""

import click


@click.command()
@click.argument("query", required=False, default="")
@click.option("--category", "-c", help="Filter by category")
@click.option("--limit", "-n", default=10, help="Number of results")
@click.option("--sort", "-s", default="newest", type=click.Choice(["newest", "oldest", "popular", "featured"]))
@click.option("--json", "is_json", is_flag=True, help="Output as JSON")
def search_cmd(query, category, limit, sort, is_json):
    """Search websites on ddexus."""
    try:
        from ddexusc import DdexusClient
        from ddexusc.cli.utils import format_table, truncate_text, print_info

        client = DdexusClient()

        results = client.search_websites(
            query=query,
            category=category,
            limit=limit,
            sort=sort,
        )

        if is_json:
            click.echo_json(results.model_dump())
        else:
            if not results.websites:
                click.secho("No results found.", fg="yellow")
                return

            rows = [
                [w.title, w.category, truncate_text(w.description or ""), str(w.views)]
                for w in results.websites
            ]
            click.echo(format_table(["Title", "Category", "Description", "Views"], rows))
            print_info(f"Page {results.page}/{results.totalPages} - {results.total} total results")

    except Exception as e:
        click.secho(f"Error: {e}", fg="red")
        raise SystemExit(1)
