"""Plugin commands for ddexusc CLI."""

import click
import json
import os
import urllib.request
import urllib.error


def get_plugin_manager():
    """Get PluginManager instance."""
    from ddexusc.plugins import PluginManager
    return PluginManager()


def submit_to_web(plugin_data: dict) -> bool:
    """Submit plugin to ddexus web plugin store.

    Args:
        plugin_data: Plugin info dict with name, version, description, author, code, commands.

    Returns:
        True if submitted successfully, False otherwise.
    """
    base_url = os.getenv("DDEXUS_BASE_URL", "https://b15hk3yggec1-d.space.z.ai")
    url = f"{base_url}/api/plugins"

    try:
        payload = json.dumps(plugin_data).encode("utf-8")
        req = urllib.request.Request(
            url,
            data=payload,
            headers={
                "Content-Type": "application/json",
                "User-Agent": "ddexusc/2.0",
            },
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=15) as resp:
            result = json.loads(resp.read().decode())
            if result.get("success"):
                return True
            else:
                click.echo(click.style(f"Warning: {result.get('error', 'Unknown error')}", fg="yellow"))
                return False
    except urllib.error.HTTPError as e:
        body = e.read().decode() if e.fp else ""
        try:
            err = json.loads(body)
            msg = err.get("error", str(e))
        except Exception:
            msg = str(e)
        click.echo(click.style(f"Publish failed: {msg}", fg="yellow"))
        return False
    except Exception as e:
        click.echo(click.style(f"Publish failed: {e}", fg="yellow"))
        return False


@click.group()
def plugin():
    """Manage ddexusc plugins - install, create, list, run, and publish."""
    pass


@plugin.command(name="list")
@click.option("--installed", "-i", is_flag=True, help="Show installed plugins only")
@click.option("--search", "-s", "search_query", default="", help="Search available plugins")
def list_plugins(installed, search_query):
    """List available and installed plugins.

    Examples:
        ddexus plugin list
        ddexus plugin list --installed
        ddexus plugin list --search seo
    """
    pm = get_plugin_manager()

    if installed:
        plugins = pm.list_plugins()
        if not plugins:
            click.echo("No plugins installed. Use 'ddexus plugin search' to find plugins.")
            return
        click.echo(click.style(f"Installed Plugins ({len(plugins)}):", fg="green", bold=True))
        for p in plugins:
            status = click.style("enabled", fg="green") if p.get("enabled") else click.style("disabled", fg="red")
            click.echo(f"  {click.style(p['name'], bold=True)} v{p['version']} [{status}]")
            click.echo(f"    {p['description']}")
            if p.get("commands"):
                click.echo(f"    Commands: {', '.join(p['commands'])}")
    else:
        plugins = pm.search_plugins(search_query)
        if not plugins:
            click.echo("No plugins found.")
            return
        label = f"Available Plugins matching '{search_query}'" if search_query else "Available Plugins"
        click.echo(click.style(f"{label} ({len(plugins)}):", fg="green", bold=True))
        for p in plugins:
            downloads = p.get("downloads", 0)
            status = p.get("status", "available")
            badge = click.style(f"[{status}]", fg="cyan") if status == "official" else click.style(f"[{status}]", fg="yellow")
            click.echo(f"  {click.style(p['name'], bold=True)} v{p['version']} {badge} ({downloads} downloads)")
            click.echo(f"    {p['description']}")
            click.echo(f"    by {p.get('author', 'unknown')}")


@plugin.command(name="search")
@click.argument("query", required=False, default="")
def search(query):
    """Search for plugins.

    Examples:
        ddexus plugin search seo
        ddexus plugin search screenshot
    """
    pm = get_plugin_manager()
    plugins = pm.search_plugins(query)
    if not plugins:
        click.echo(f"No plugins found for '{query}'.")
        return
    click.echo(click.style(f"Found {len(plugins)} plugins:", fg="green", bold=True))
    for p in plugins:
        status = p.get("status", "available")
        badge = click.style(f"[{status}]", fg="cyan") if status == "official" else click.style(f"[{status}]", fg="yellow")
        click.echo(f"  {click.style(p['name'], bold=True)} v{p['version']} {badge}")
        click.echo(f"    {p['description']}")
    click.echo(f"\nInstall with: ddexus plugin install <name>")


@plugin.command(name="install")
@click.argument("name_or_path", required=True)
def install(name_or_path):
    """Install a plugin from ddexus registry or local path.

    To install from the ddexus web registry:
        ddexus plugin install seo-analyzer

    To install from a local path:
        ddexus plugin install ./my-plugin

    Examples:
        ddexus plugin install seo-analyzer
        ddexus plugin install ./my-plugin
        ddexus plugin install /path/to/plugin.py
    """
    pm = get_plugin_manager()

    # Check if it's a local path or a registry name
    if os.path.exists(name_or_path) or name_or_path.startswith("."):
        # Local install
        click.echo(f"Installing plugin from '{name_or_path}'...")
        result = pm.install_plugin(name_or_path)
    else:
        # Registry install - download from web first
        base_url = os.getenv("DDEXUS_BASE_URL", "https://b15hk3yggec1-d.space.z.ai")
        try:
            url = f"{base_url}/api/plugins/{name_or_path}"
            req = urllib.request.Request(url, headers={"User-Agent": "ddexusc/2.0"})
            with urllib.request.urlopen(req, timeout=10) as resp:
                plugin_data = json.loads(resp.read().decode())

            click.echo(click.style(f"Downloading '{name_or_path}' from ddexus registry...", fg="cyan"))

            # Save code to local plugin dir
            plugin_dir = pm.plugins_dir / name_or_path
            plugin_dir.mkdir(parents=True, exist_ok=True)

            # Save the code
            (plugin_dir / "__init__.py").write_text(plugin_data.get("code", ""))

            # Save manifest
            manifest = {
                "name": plugin_data.get("name", name_or_path),
                "version": plugin_data.get("version", "1.0.0"),
                "description": plugin_data.get("description", ""),
                "author": plugin_data.get("author", ""),
                "entry_point": "__init__.py",
                "commands": plugin_data.get("commands", []),
                "hooks": plugin_data.get("hooks", []),
                "dependencies": [],
                "permissions": plugin_data.get("permissions", []),
            }
            (plugin_dir / "manifest.json").write_text(json.dumps(manifest, indent=2))

            # Register
            from ddexusc.plugins import PluginManifest
            pm._register_plugin(PluginManifest(**manifest))

            result = {"status": "success", "message": f"Plugin '{name_or_path}' installed from registry"}
        except urllib.error.HTTPError:
            result = {"status": "error", "message": f"Plugin '{name_or_path}' not found in registry. Check name with: ddexus plugin list"}
        except Exception as e:
            result = {"status": "error", "message": str(e)}

    if result["status"] == "success":
        click.echo(click.style("OK", fg="green") + f" {result['message']}")
    else:
        click.echo(click.style("ERROR", fg="red") + f" {result['message']}")


@plugin.command(name="uninstall")
@click.argument("name", required=True)
@click.confirmation_option(prompt="Are you sure you want to remove this plugin?")
def uninstall(name):
    """Remove an installed plugin.

    Examples:
        ddexus plugin uninstall seo-analyzer
    """
    pm = get_plugin_manager()
    result = pm.uninstall_plugin(name)
    click.echo(click.style("OK", fg="green") + f" {result['message']}")


@plugin.command(name="run")
@click.argument("name", required=True)
@click.option("--arg", "-a", multiple=True, help="Arguments as key=value pairs")
def run(name, arg):
    """Run a plugin.

    Examples:
        ddexus plugin run seo-analyzer
        ddexus plugin run seo-analyzer --arg url=https://example.com
    """
    pm = get_plugin_manager()
    try:
        args = {}
        for a in arg:
            if "=" in a:
                k, v = a.split("=", 1)
                args[k] = v
        click.echo(f"Running plugin '{name}'...")
        result = pm.run_plugin(name, args if args else None)
        if isinstance(result, dict):
            click.echo(json.dumps(result, indent=2, default=str))
        else:
            click.echo(str(result))
    except FileNotFoundError:
        click.echo(click.style("ERROR", fg="red") + f" Plugin '{name}' not installed.")
        click.echo("Install it first with: ddexus plugin install <name>")
    except Exception as e:
        click.echo(click.style("ERROR", fg="red") + f" {e}")


@plugin.command(name="create")
@click.argument("name", required=True)
@click.option("--output", "-o", default=".", help="Output directory")
@click.option("--description", "-d", default="", help="Plugin description")
@click.option("--author", "-a", default="", help="Plugin author name")
@click.option("--publish", "-p", is_flag=True, help="Publish to ddexus Plugin Store after creation")
def create(name, output, description, author, publish):
    """Create a new plugin template.

    The plugin is created locally. Use --publish to also submit it to
    the ddexus Plugin Store so other users can find and install it.

    Examples:
        ddexus plugin create my-tool
        ddexus plugin create my-tool --publish
        ddexus plugin create seo-analyzer --output ./plugins --publish
    """
    pm = get_plugin_manager()
    path = pm.create_plugin_template(name, output)

    click.echo(click.style("OK", fg="green") + f" Plugin template created at: {path}")
    click.echo(f"  - {os.path.join(path, 'manifest.json')}")
    click.echo(f"  - {os.path.join(path, '__init__.py')}")
    click.echo(f"  - {os.path.join(path, 'README.md')}")

    # Auto-submit to web if --publish flag
    if publish:
        click.echo(f"\n{click.style('Publishing to ddexus Plugin Store...', fg='cyan')}")
        init_path = os.path.join(path, "__init__.py")
        manifest_path = os.path.join(path, "manifest.json")

        code = ""
        if os.path.exists(init_path):
            with open(init_path, "r") as f:
                code = f.read()

        manifest = {}
        if os.path.exists(manifest_path):
            with open(manifest_path, "r") as f:
                manifest = json.load(f)

        plugin_data = {
            "name": name,
            "version": manifest.get("version", "0.1.0"),
            "description": description or manifest.get("description", f"A ddexusc plugin for {name}"),
            "author": author or manifest.get("author", "community"),
            "code": code,
            "commands": manifest.get("commands", [name]),
            "permissions": manifest.get("permissions", ["network"]),
            "hooks": manifest.get("hooks", []),
        }

        success = submit_to_web(plugin_data)
        if success:
            click.echo(click.style("OK", fg="green") + f" Plugin '{name}' published to ddexus Plugin Store!")
            click.echo(f"  View at: https://b15hk3yggec1-d.space.z.ai (Plugins section)")
            click.echo(f"  Others can install with: ddexus plugin install {name}")
        else:
            click.echo(click.style("WARNING", fg="yellow") + f" Publish failed. You can manually submit later.")
    else:
        click.echo(f"\nEdit the files, then:")
        click.echo(f"  ddexus plugin install {path}")
        click.echo(f"  ddexus plugin run {name}")
        click.echo(f"\nTo publish to ddexus Plugin Store:")
        click.echo(f"  ddexus plugin create {name} --publish")


@plugin.command(name="publish")
@click.argument("path", required=True)
@click.option("--description", "-d", default="", help="Plugin description")
@click.option("--author", "-a", default="", help="Plugin author name")
def publish(path, description, author):
    """Publish an existing plugin to the ddexus Plugin Store.

    Examples:
        ddexus plugin publish ./my-plugin
        ddexus plugin publish ./ddexusc-plugin-seo --author "YourName"
    """
    plugin_path = os.path.expanduser(path)
    manifest_path = os.path.join(plugin_path, "manifest.json")
    init_path = os.path.join(plugin_path, "__init__.py")

    if not os.path.exists(manifest_path):
        # Maybe it's a single .py file
        if os.path.exists(plugin_path) and plugin_path.endswith(".py"):
            name = os.path.splitext(os.path.basename(plugin_path))[0]
            with open(plugin_path, "r") as f:
                code = f.read()
            plugin_data = {
                "name": name,
                "version": "1.0.0",
                "description": description or f"Plugin {name}",
                "author": author or "community",
                "code": code,
                "commands": [],
                "permissions": ["network"],
                "hooks": [],
            }
        else:
            click.echo(click.style("ERROR", fg="red") + " manifest.json not found in plugin directory")
            return
    else:
        with open(manifest_path, "r") as f:
            manifest = json.load(f)

        code = ""
        if os.path.exists(init_path):
            with open(init_path, "r") as f:
                code = f.read()

        plugin_data = {
            "name": manifest.get("name", os.path.basename(plugin_path)),
            "version": manifest.get("version", "1.0.0"),
            "description": description or manifest.get("description", ""),
            "author": author or manifest.get("author", "community"),
            "code": code,
            "commands": manifest.get("commands", []),
            "permissions": manifest.get("permissions", []),
            "hooks": manifest.get("hooks", []),
        }

    click.echo(f"Publishing '{plugin_data['name']}' to ddexus Plugin Store...")
    success = submit_to_web(plugin_data)
    if success:
        click.echo(click.style("OK", fg="green") + f" Plugin '{plugin_data['name']}' published!")
        click.echo(f"  Others can install with: ddexus plugin install {plugin_data['name']}")
    else:
        click.echo(click.style("ERROR", fg="red") + " Publish failed.")
