"""List command for ddexus CLI."""

import click


@click.command()
@click.option("--category", "-c", help="Filter by category")
@click.option("--page", "-p", default=1, help="Page number")
@click.option("--limit", "-n", default=10, help="Results per page")
@click.option("--sort", "-s", default="newest", type=click.Choice(["newest", "oldest", "popular", "featured"]))
@click.option("--featured", "featured_only", is_flag=True, help="Show only featured")
@click.option("--json", "is_json", is_flag=True, help="Output as JSON")
def list_cmd(category, page, limit, sort, featured_only, is_json):
    """List websites on ddexus."""
    try:
        from ddexusc import DdexusClient
        from ddexusc.cli.utils import format_table, truncate_text, print_info

        client = DdexusClient()

        if featured_only:
            websites = client.get_featured()
            if is_json:
                click.echo_json([w.model_dump() for w in websites])
            else:
                rows = [
                    [w.title, w.category, truncate_text(w.description or ""), str(w.views)]
                    for w in websites
                ]
                click.echo(format_table(["Title", "Category", "Description", "Views"], rows))
            return

        results = client.search_websites(
            category=category,
            page=page,
            limit=limit,
            sort=sort,
        )

        if is_json:
            click.echo_json(results.model_dump())
        else:
            rows = [
                [w.title, w.category, truncate_text(w.description or ""), str(w.views)]
                for w in results.websites
            ]
            click.echo(format_table(["Title", "Category", "Description", "Views"], rows))
            print_info(f"Page {results.page}/{results.totalPages} - {results.total} total results")

    except Exception as e:
        click.secho(f"Error: {e}", fg="red")
        raise SystemExit(1)
