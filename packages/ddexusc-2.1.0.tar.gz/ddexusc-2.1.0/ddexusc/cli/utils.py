"""CLI utility helpers."""

import json
from typing import Any, Dict, List, Optional


def format_table(headers: List[str], rows: List[List[str]], max_width: int = 80) -> str:
    """Format data as a simple text table.

    Args:
        headers: Column headers.
        rows: Table rows.
        max_width: Maximum total width.

    Returns:
        Formatted table string.
    """
    if not rows:
        return "No results found."

    # Calculate column widths
    col_widths = [len(h) for h in headers]
    for row in rows:
        for i, cell in enumerate(row):
            if i < len(col_widths):
                col_widths[i] = max(col_widths[i], len(str(cell)))

    # Truncate if too wide
    total_width = sum(col_widths) + len(col_widths) * 3 + 1
    if total_width > max_width:
        excess = total_width - max_width
        max_col = max(col_widths)
        max_idx = col_widths.index(max_col)
        col_widths[max_idx] = max(10, max_col - excess)

    # Build table
    lines = []
    header_line = " | ".join(h.ljust(w) for h, w in zip(headers, col_widths))
    separator = "-+-".join("-" * w for w in col_widths)

    lines.append(header_line)
    lines.append(separator)

    for row in rows:
        cells = []
        for i, cell in enumerate(row):
            text = str(cell)
            if i < len(col_widths) and len(text) > col_widths[i]:
                text = text[: col_widths[i] - 3] + "..."
            cells.append(text.ljust(col_widths[i]) if i < len(col_widths) else text)
        lines.append(" | ".join(cells))

    return "\n".join(lines)


def truncate_text(text: str, max_length: int = 80) -> str:
    """Truncate text with ellipsis.

    Args:
        text: Text to truncate.
        max_length: Maximum length.

    Returns:
        Truncated text.
    """
    if not text or len(text) <= max_length:
        return text or ""
    return text[: max_length - 3].rsplit(" ", 1)[0] + "..."


def format_json(data: Any) -> str:
    """Format data as pretty-printed JSON.

    Args:
        data: Data to format.

    Returns:
        JSON string.
    """
    return json.dumps(data, indent=2, default=str, ensure_ascii=False)


def print_success(message: str):
    """Print a success message with green color."""
    try:
        import click
        click.secho(message, fg="green")
    except ImportError:
        print(f"[OK] {message}")


def print_error(message: str):
    """Print an error message with red color."""
    try:
        import click
        click.secho(message, fg="red")
    except ImportError:
        print(f"[ERROR] {message}")


def print_info(message: str):
    """Print an info message with cyan color."""
    try:
        import click
        click.secho(message, fg="cyan")
    except ImportError:
        print(f"[INFO] {message}")
