"""CLI subpackage for ddexusc."""

from ddexusc.cli.main import cli

__all__ = ["cli"]
