"""Main CLI entry point for ddexusc."""

import click

from ddexusc.cli.commands.submit import submit_cmd
from ddexusc.cli.commands.search import search_cmd
from ddexusc.cli.commands.list import list_cmd
from ddexusc.cli.commands.plugin import plugin


@click.group()
@click.version_option(
    package_name="ddexusc",
    message="%(prog)s %(version)s",
    prog_name="ddexus",
)
@click.option("--api-key", "-k", envvar="DDEXUS_API_KEY", help="ddexus API key")
@click.option("--base-url", "-b", envvar="DDEXUS_BASE_URL", default="https://b15hk3yggec1-d.space.z.ai", help="ddexus API base URL")
@click.pass_context
def cli(ctx, api_key, base_url):
    """ddexus - Submit, search, and manage websites with plugins.

    ddexusc v2.0 is the official Python client for ddexus, featuring:
    - Website submission and search
    - Plugin system for extensions
    - API key management

    \b
    Examples:
        ddexus submit --interactive
        ddexus search "machine learning"
        ddexus list --category "Development Tools"
        ddexus plugin list
        ddexus plugin create my-plugin
        ddexus plugin run my-plugin
    """
    ctx.ensure_object(dict)
    ctx.obj["api_key"] = api_key
    ctx.obj["base_url"] = base_url


# Register commands
cli.add_command(submit_cmd, name="submit")
cli.add_command(search_cmd, name="search")
cli.add_command(list_cmd, name="list")
cli.add_command(plugin, name="plugin")


if __name__ == "__main__":
    cli()
