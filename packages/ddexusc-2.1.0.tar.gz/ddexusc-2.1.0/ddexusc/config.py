"""Core configuration management for ddexusc."""

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional


@dataclass
class DdexusConfig:
    """Configuration for the ddexus client."""

    api_key: str = ""
    base_url: str = "https://b15hk3yggec1-d.space.z.ai"
    timeout: int = 30
    max_retries: int = 3
    retry_backoff: float = 0.5
    verify_ssl: bool = True
    user_agent: str = "ddexusc/1.0.0"

    @classmethod
    def from_env(cls) -> "DdexusConfig":
        """Create config from environment variables."""
        return cls(
            api_key=os.getenv("DDEXUS_API_KEY", ""),
            base_url=os.getenv("DDEXUS_BASE_URL", "https://b15hk3yggec1-d.space.z.ai"),
            timeout=int(os.getenv("DDEXUS_TIMEOUT", "30")),
            max_retries=int(os.getenv("DDEXUS_MAX_RETRIES", "3")),
            verify_ssl=os.getenv("DDEXUS_VERIFY_SSL", "true").lower() == "true",
        )

    @classmethod
    def from_file(cls, path: str) -> "DdexusConfig":
        """Create config from an INI-style config file."""
        config_path = Path(path)
        if not config_path.exists():
            return cls.from_env()

        config = cls.from_env()
        try:
            import configparser

            parser = configparser.ConfigParser()
            parser.read(config_path)

            if "default" in parser:
                section = parser["default"]
                if "api_key" in section and not config.api_key:
                    config.api_key = section["api_key"]
                if "base_url" in section:
                    config.base_url = section["base_url"]
                if "timeout" in section:
                    config.timeout = int(section["timeout"])
                if "max_retries" in section:
                    config.max_retries = int(section["max_retries"])
                if "verify_ssl" in section:
                    config.verify_ssl = section["verify_ssl"].lower() == "true"
        except Exception:
            pass

        return config

    @classmethod
    def load(cls, config_path: Optional[str] = None) -> "DdexusConfig":
        """Auto-detect and load config.

        Priority: environment variables > config file > defaults.

        Config file search order:
        1. Explicit path if provided
        2. ~/.ddexus/config.ini
        3. .ddexus/config.ini (current directory)
        """
        if config_path:
            cfg = cls.from_file(config_path)
            if cfg.api_key:
                return cfg

        # Try home directory config
        home_config = Path.home() / ".ddexus" / "config.ini"
        if home_config.exists():
            cfg = cls.from_file(str(home_config))
            if cfg.api_key:
                return cfg

        # Try local config
        local_config = Path(".ddexus") / "config.ini"
        if local_config.exists():
            cfg = cls.from_file(str(local_config))
            if cfg.api_key:
                return cfg

        return cls.from_env()
