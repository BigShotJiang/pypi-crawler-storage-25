"""Data models for the ddexus API."""

from typing import List, Optional, Dict, Any
from datetime import datetime
from pydantic import BaseModel, Field, field_validator


class Website(BaseModel):
    """Represents a website entry on ddexus."""

    id: str
    title: str
    description: Optional[str] = None
    url: str
    category: str
    tags: Optional[str] = None
    author: Optional[str] = None
    favicon: Optional[str] = None
    screenshot: Optional[str] = None
    views: int = 0
    featured: bool = False
    status: str = "active"
    createdAt: Optional[datetime] = None
    updatedAt: Optional[datetime] = None

    model_config = {"populate_by_name": True}

    @property
    def tag_list(self) -> List[str]:
        """Parse tags string into a list."""
        if not self.tags:
            return []
        return [t.strip() for t in self.tags.split(",") if t.strip()]

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return self.model_dump()


class Category(BaseModel):
    """Represents a website category."""

    id: str
    name: str
    slug: str
    description: Optional[str] = None
    icon: Optional[str] = None
    createdAt: Optional[datetime] = None
    count: Optional[Dict[str, Any]] = Field(default=None, alias="_count")

    model_config = {"populate_by_name": True}

    @property
    def website_count(self) -> int:
        """Get the number of websites in this category."""
        if self.count and isinstance(self.count, dict):
            return self.count.get("websites", 0)
        return 0


class PaginatedResponse(BaseModel):
    """Paginated API response wrapper."""

    websites: List[Website]
    total: int
    page: int
    limit: int
    totalPages: int

    @property
    def has_next(self) -> bool:
        """Check if there is a next page."""
        return self.page < self.totalPages

    @property
    def has_prev(self) -> bool:
        """Check if there is a previous page."""
        return self.page > 1

    @property
    def next_page(self) -> Optional[int]:
        """Get the next page number, or None if no more pages."""
        return self.page + 1 if self.has_next else None

    @property
    def prev_page(self) -> Optional[int]:
        """Get the previous page number, or None if on first page."""
        return self.page - 1 if self.has_prev else None


class SubmitRequest(BaseModel):
    """Request model for submitting a website."""

    title: str = Field(..., min_length=1, max_length=200)
    description: str = Field(..., min_length=10, max_length=2000)
    url: str = Field(..., min_length=1, max_length=2048)
    category: str = Field(..., min_length=1, max_length=100)
    tags: Optional[List[str]] = Field(default=None, max_length=20)
    author: Optional[str] = Field(default=None, max_length=100)

    @field_validator("url")
    @classmethod
    def validate_url(cls, v: str) -> str:
        v = v.strip()
        if not v.startswith(("http://", "https://")):
            raise ValueError("URL must start with http:// or https://")
        return v


class SearchParams(BaseModel):
    """Parameters for searching websites."""

    query: str = Field(default="", max_length=200)
    category: str = Field(default="", max_length=100)
    page: int = Field(default=1, ge=1)
    limit: int = Field(default=12, ge=1, le=50)
    sort: str = Field(default="newest")

    @field_validator("sort")
    @classmethod
    def validate_sort(cls, v: str) -> str:
        allowed = ["newest", "oldest", "popular", "featured"]
        if v not in allowed:
            raise ValueError(f"sort must be one of: {', '.join(allowed)}")
        return v
