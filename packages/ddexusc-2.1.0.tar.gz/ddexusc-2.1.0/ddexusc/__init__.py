"""ddexusc - Official Python client for ddexus platform."""

__version__ = "2.0.0"
__author__ = "ddexus Team"

from ddexusc.client import DdexusClient
from ddexusc.models import Website, Category, PaginatedResponse
from ddexusc.exceptions import (
    DdexusError,
    AuthenticationError,
    ValidationError,
    RateLimitError,
    NotFoundError,
    APIError,
)
from ddexusc.plugins import PluginManager

__all__ = [
    "DdexusClient",
    "PluginManager",
    "Website",
    "Category",
    "PaginatedResponse",
    "DdexusError",
    "AuthenticationError",
    "ValidationError",
    "RateLimitError",
    "NotFoundError",
    "APIError",
    "__version__",
]
