"""Core synchronous API client for ddexus."""

from typing import Optional, List, Dict, Any

from ddexusc.config import DdexusConfig
from ddexusc.models import Website, Category, PaginatedResponse
from ddexusc.exceptions import DdexusError
from ddexusc.utils.http import HttpClient
from ddexusc.utils.validators import (
    validate_url,
    validate_title,
    validate_description,
    validate_category,
    validate_tags,
)
from ddexusc.api.websites import WebsiteAPI
from ddexusc.api.categories import CategoryAPI
from ddexusc.api.search import SearchAPI
from ddexusc.api.auth import AuthAPI


class DdexusClient:
    """Synchronous client for the ddexus API.

    This is the main entry point for interacting with the ddexus platform.
    It provides methods for submitting websites, searching the directory,
    and managing categories.

    Example:
        >>> from ddexusc import DdexusClient
        >>> client = DdexusClient(api_key="sk-xxx")
        >>> result = client.submit(
        ...     title="My Tool",
        ...     description="A great tool",
        ...     url="https://mytool.com",
        ...     category="Development Tools"
        ... )
        >>> print(result["id"])
    """

    DEFAULT_BASE_URL = "https://ddexus.com"
    DEFAULT_TIMEOUT = 30

    def __init__(
        self,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        timeout: int = DEFAULT_TIMEOUT,
        max_retries: int = 3,
        verify_ssl: bool = True,
        config_path: Optional[str] = None,
    ):
        """Initialize the ddexus client.

        Args:
            api_key: API key for authentication. Falls back to
                     DDEXUS_API_KEY environment variable.
            base_url: Base URL of the ddexus API. Falls back to
                      DDEXUS_BASE_URL environment variable.
            timeout: Request timeout in seconds (default: 30).
            max_retries: Maximum retry attempts for failed requests.
            verify_ssl: Whether to verify SSL certificates.
            config_path: Path to a config file (optional).
        """
        # Load config with priority: explicit args > config file > env > defaults
        config = DdexusConfig.load(config_path)

        self.api_key = api_key or config.api_key
        self.base_url = (base_url or config.base_url or self.DEFAULT_BASE_URL).rstrip("/")
        self.timeout = timeout or config.timeout
        self.verify_ssl = verify_ssl

        # Create HTTP client
        self._http = HttpClient(
            base_url=self.base_url,
            api_key=self.api_key,
            timeout=self.timeout,
            max_retries=max_retries,
            verify_ssl=self.verify_ssl,
        )

        # Initialize API sub-clients
        self.websites = WebsiteAPI(self._http)
        self.categories = CategoryAPI(self._http)
        self.search = SearchAPI(self._http)
        self.auth = AuthAPI(self._http)

    def submit(
        self,
        title: str,
        description: str,
        url: str,
        category: str,
        tags: Optional[List[str]] = None,
        author: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Submit a new website to ddexus.

        This is the primary method for adding websites to the ddexus directory.

        Args:
            title: Website display name (min 2, max 200 characters).
            description: Website description (min 10, max 2000 characters).
            url: Full URL of the website (must start with http/https).
            category: Category name (must match existing categories).
            tags: Optional list of descriptive tags (max 20).
            author: Optional author/submitter name.

        Returns:
            Dictionary with the created website data including:
            - id: Unique identifier
            - title: Website title
            - url: Website URL
            - status: Submission status
            - createdAt: Creation timestamp

        Raises:
            ValidationError: If input validation fails.
            AuthenticationError: If API key is invalid.
            APIError: If the request fails.

        Example:
            >>> result = client.submit(
            ...     title="FastAPI",
            ...     description="Modern web framework for Python",
            ...     url="https://fastapi.tiangolo.com",
            ...     category="Development Tools",
            ...     tags=["python", "api", "framework"],
            ...     author="Sebastian Ramirez"
            ... )
        """
        return self.websites.submit(
            title=title,
            description=description,
            url=url,
            category=category,
            tags=tags,
            author=author,
        )

    def get_website(self, website_id: str) -> Website:
        """Get a website by its ID.

        Args:
            website_id: The unique website identifier.

        Returns:
            Website object with full metadata.

        Raises:
            NotFoundError: If the website does not exist.
        """
        return self.websites.get(website_id)

    def search_websites(
        self,
        query: str = "",
        category: str = "",
        page: int = 1,
        limit: int = 12,
        sort: str = "newest",
    ) -> PaginatedResponse:
        """Search websites on ddexus.

        Args:
            query: Search term to match against title, description, and tags.
            category: Filter results by category name.
            page: Page number for pagination (1-indexed).
            limit: Results per page (1-50, default 12).
            sort: Sort order: 'newest', 'oldest', 'popular', or 'featured'.

        Returns:
            PaginatedResponse with matching websites.

        Example:
            >>> results = client.search_websites(query="python", sort="popular")
            >>> for website in results.websites:
            ...     print(website.title, website.url)
        """
        return self.websites.list(
            query=query,
            category=category,
            page=page,
            limit=limit,
            sort=sort,
        )

    def get_categories(self) -> List[Category]:
        """List all available website categories.

        Returns:
            List of Category objects with name, slug, description, and counts.

        Example:
            >>> categories = client.get_categories()
            >>> for cat in categories:
            ...     print(f"{cat.name}: {cat.website_count} sites")
        """
        return self.categories.list()

    def get_featured(self) -> List[Website]:
        """Get featured websites from the ddexus homepage.

        Returns:
            List of featured Website objects with full metadata.

        Example:
            >>> featured = client.get_featured()
            >>> for site in featured:
            ...     print(f"{site.title} ({site.category})")
        """
        return self.search.featured()

    def get_trending(self, limit: int = 10) -> List[Website]:
        """Get trending (most viewed) websites.

        Args:
            limit: Number of results to return (default 10, max 50).

        Returns:
            List of trending Website objects sorted by view count.
        """
        return self.search.trending(limit=limit)

    def get_latest(self, limit: int = 12) -> List[Website]:
        """Get the latest websites added to ddexus.

        Args:
            limit: Number of results to return (default 12, max 50).

        Returns:
            List of latest Website objects sorted by creation date.
        """
        return self.search.latest(limit=limit)

    def close(self):
        """Close the HTTP session and release resources."""
        self._http.close()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()
        return False

    def __repr__(self) -> str:
        masked_key = f"{self.api_key[:8]}..." if self.api_key else "not set"
        return (
            f"DdexusClient(base_url={self.base_url!r}, "
            f"api_key={masked_key}, timeout={self.timeout})"
        )
