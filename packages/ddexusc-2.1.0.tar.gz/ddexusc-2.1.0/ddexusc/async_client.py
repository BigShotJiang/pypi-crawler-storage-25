"""Asynchronous API client for ddexus."""

from typing import Optional, List, Dict, Any

from ddexusc.models import Website, Category, PaginatedResponse
from ddexusc.exceptions import DdexusError


class AsyncDdexusClient:
    """Asynchronous client for the ddexus API.

    Provides the same interface as DdexusClient but with async/await support.
    Uses httpx for async HTTP operations.

    Requires the async extra: pip install ddexusc[async]

    Example:
        >>> from ddexusc import AsyncDdexusClient
        >>> client = AsyncDdexusClient(api_key="sk-xxx")
        >>> result = await client.submit(
        ...     title="My Tool",
        ...     description="A great tool",
        ...     url="https://mytool.com",
        ...     category="Development Tools"
        ... )
    """

    DEFAULT_BASE_URL = "https://ddexus.com"
    DEFAULT_TIMEOUT = 30

    def __init__(
        self,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        timeout: int = DEFAULT_TIMEOUT,
    ):
        """Initialize the async ddexus client.

        Args:
            api_key: API key for authentication.
            base_url: Base URL of the ddexus API.
            timeout: Request timeout in seconds.
        """
        import os

        self.api_key = api_key or os.getenv("DDEXUS_API_KEY", "")
        self.base_url = (base_url or os.getenv("DDEXUS_BASE_URL", "") or self.DEFAULT_BASE_URL).rstrip("/")
        self.timeout = timeout
        self._client = None

    async def _get_client(self):
        """Lazy-initialize the httpx async client."""
        if self._client is None:
            import httpx

            headers = {
                "User-Agent": "ddexusc-async/1.0.0",
                "Content-Type": "application/json",
                "Accept": "application/json",
            }
            if self.api_key:
                headers["Authorization"] = f"Bearer {self.api_key}"

            self._client = httpx.AsyncClient(
                base_url=self.base_url,
                headers=headers,
                timeout=self.timeout,
            )
        return self._client

    async def _handle_response(self, response) -> Any:
        """Handle API response."""
        if 200 <= response.status_code < 300:
            return response.json()

        from ddexusc.exceptions import (
            AuthenticationError,
            RateLimitError,
            NotFoundError,
            ValidationError,
            APIError,
        )

        try:
            error_data = response.json()
            message = error_data.get("error", error_data.get("message", response.text))
        except Exception:
            message = response.text or f"HTTP {response.status_code}"

        if response.status_code == 401:
            raise AuthenticationError(message)
        elif response.status_code == 404:
            raise NotFoundError(message)
        elif response.status_code == 429:
            raise RateLimitError(message)
        elif response.status_code == 400:
            raise ValidationError(message)
        else:
            raise APIError(message, status_code=response.status_code)

    async def submit(
        self,
        title: str,
        description: str,
        url: str,
        category: str,
        tags: Optional[List[str]] = None,
        author: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Submit a new website to ddexus (async).

        Args:
            title: Website display name.
            description: Website description.
            url: Website URL.
            category: Website category.
            tags: Optional list of tags.
            author: Optional author name.

        Returns:
            Dictionary with the created website data.
        """
        client = await self._get_client()
        payload = {
            "title": title.strip(),
            "description": description.strip(),
            "url": url.strip(),
            "category": category.strip(),
            "tags": ", ".join(tags) if tags else "",
            "author": author or "ddexus",
        }
        response = await client.post("/api/websites", json=payload)
        return await self._handle_response(response)

    async def search_websites(
        self,
        query: str = "",
        category: str = "",
        page: int = 1,
        limit: int = 12,
        sort: str = "newest",
    ) -> PaginatedResponse:
        """Search websites on ddexus (async)."""
        client = await self._get_client()
        params = {
            "q": query, "category": category,
            "page": page, "limit": min(limit, 50), "sort": sort,
        }
        response = await client.get("/api/websites", params=params)
        data = await self._handle_response(response)
        return PaginatedResponse(**data)

    async def get_categories(self) -> List[Category]:
        """List all categories (async)."""
        client = await self._get_client()
        response = await client.get("/api/categories")
        data = await self._handle_response(response)
        return [Category(**item) for item in data]

    async def get_featured(self) -> List[Website]:
        """Get featured websites (async)."""
        client = await self._get_client()
        response = await client.get("/api/websites/featured")
        data = await self._handle_response(response)
        return [Website(**item) for item in data]

    async def close(self):
        """Close the async HTTP client."""
        if self._client:
            await self._client.aclose()
            self._client = None

    async def __aenter__(self):
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        await self.close()
        return False
