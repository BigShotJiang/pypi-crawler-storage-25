"""HTTP request wrapper for ddexusc."""

import json
from typing import Any, Dict, Optional, Union

import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

from ddexusc.exceptions import (
    APIError,
    AuthenticationError,
    ConnectionError,
    NotFoundError,
    RateLimitError,
    TimeoutError,
    DdexusError,
)


class HttpClient:
    """HTTP client wrapper for the ddexus API."""

    DEFAULT_USER_AGENT = "ddexusc/1.0.0"
    DEFAULT_TIMEOUT = 30

    def __init__(
        self,
        base_url: str,
        api_key: str = "",
        timeout: int = DEFAULT_TIMEOUT,
        max_retries: int = 3,
        verify_ssl: bool = True,
    ):
        """Initialize the HTTP client.

        Args:
            base_url: Base URL of the ddexus API.
            api_key: API key for authentication.
            timeout: Request timeout in seconds.
            max_retries: Maximum number of retry attempts.
            verify_ssl: Whether to verify SSL certificates.
        """
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key
        self.timeout = timeout
        self.verify_ssl = verify_ssl

        # Configure session with retry strategy
        self._session = requests.Session()

        retry_strategy = Retry(
            total=max_retries,
            backoff_factor=0.5,
            status_forcelist=[429, 500, 502, 503, 504],
            allowed_methods=["GET", "POST", "PUT", "DELETE"],
        )
        adapter = HTTPAdapter(max_retries=retry_strategy)
        self._session.mount("https://", adapter)
        self._session.mount("http://", adapter)

        # Set default headers
        self._session.headers.update({
            "User-Agent": self.DEFAULT_USER_AGENT,
            "Content-Type": "application/json",
            "Accept": "application/json",
        })

        if api_key:
            self._session.headers["Authorization"] = f"Bearer {api_key}"

    def _build_url(self, path: str) -> str:
        """Build a full URL from a path.

        Args:
            path: API endpoint path.

        Returns:
            Full URL string.
        """
        return f"{self.base_url}{path}"

    def _handle_response(self, response: requests.Response) -> Any:
        """Handle API response and raise appropriate errors.

        Args:
            response: The HTTP response object.

        Returns:
            Parsed JSON response data.

        Raises:
            AuthenticationError: If authentication fails (401).
            RateLimitError: If rate limit is exceeded (429).
            NotFoundError: If resource is not found (404).
            ValidationError: If request data is invalid (400).
            APIError: For other API errors.
        """
        status_code = response.status_code

        if 200 <= status_code < 300:
            try:
                return response.json()
            except (json.JSONDecodeError, ValueError):
                return {"status": "ok"}

        # Handle error responses
        try:
            error_data = response.json()
            message = error_data.get("error", error_data.get("message", response.text))
        except (json.JSONDecodeError, ValueError):
            message = response.text or f"HTTP {status_code}"

        if status_code == 401:
            raise AuthenticationError(message)
        elif status_code == 403:
            raise AuthenticationError(f"Access denied: {message}")
        elif status_code == 404:
            raise NotFoundError(message)
        elif status_code == 429:
            raise RateLimitError(message)
        elif status_code == 400:
            from ddexusc.exceptions import ValidationError as VE
            raise VE(message)
        elif status_code >= 500:
            raise APIError(message, status_code=status_code)
        else:
            raise APIError(message, status_code=status_code)

    def get(
        self,
        path: str,
        params: Optional[Dict[str, Any]] = None,
        **kwargs,
    ) -> Any:
        """Send a GET request.

        Args:
            path: API endpoint path.
            params: Query parameters.
            **kwargs: Additional request arguments.

        Returns:
            Parsed JSON response.

        Raises:
            DdexusError: On API errors.
        """
        url = self._build_url(path)
        try:
            response = self._session.get(
                url,
                params=params,
                timeout=self.timeout,
                verify=self.verify_ssl,
                **kwargs,
            )
            return self._handle_response(response)
        except requests.exceptions.Timeout:
            raise TimeoutError(f"GET {path} timed out after {self.timeout}s")
        except requests.exceptions.ConnectionError:
            raise ConnectionError(f"Failed to connect to {url}")
        except DdexusError:
            raise
        except Exception as e:
            raise DdexusError(f"Unexpected error during GET {path}: {e}")

    def post(
        self,
        path: str,
        json: Optional[Dict[str, Any]] = None,
        **kwargs,
    ) -> Any:
        """Send a POST request.

        Args:
            path: API endpoint path.
            json: JSON body data.
            **kwargs: Additional request arguments.

        Returns:
            Parsed JSON response.

        Raises:
            DdexusError: On API errors.
        """
        url = self._build_url(path)
        try:
            response = self._session.post(
                url,
                json=json,
                timeout=self.timeout,
                verify=self.verify_ssl,
                **kwargs,
            )
            return self._handle_response(response)
        except requests.exceptions.Timeout:
            raise TimeoutError(f"POST {path} timed out after {self.timeout}s")
        except requests.exceptions.ConnectionError:
            raise ConnectionError(f"Failed to connect to {url}")
        except DdexusError:
            raise
        except Exception as e:
            raise DdexusError(f"Unexpected error during POST {path}: {e}")

    def put(
        self,
        path: str,
        json: Optional[Dict[str, Any]] = None,
        **kwargs,
    ) -> Any:
        """Send a PUT request.

        Args:
            path: API endpoint path.
            json: JSON body data.
            **kwargs: Additional request arguments.

        Returns:
            Parsed JSON response.

        Raises:
            DdexusError: On API errors.
        """
        url = self._build_url(path)
        try:
            response = self._session.put(
                url,
                json=json,
                timeout=self.timeout,
                verify=self.verify_ssl,
                **kwargs,
            )
            return self._handle_response(response)
        except requests.exceptions.Timeout:
            raise TimeoutError(f"PUT {path} timed out after {self.timeout}s")
        except requests.exceptions.ConnectionError:
            raise ConnectionError(f"Failed to connect to {url}")
        except DdexusError:
            raise
        except Exception as e:
            raise DdexusError(f"Unexpected error during PUT {path}: {e}")

    def delete(self, path: str, **kwargs) -> Any:
        """Send a DELETE request.

        Args:
            path: API endpoint path.
            **kwargs: Additional request arguments.

        Returns:
            Parsed JSON response.

        Raises:
            DdexusError: On API errors.
        """
        url = self._build_url(path)
        try:
            response = self._session.delete(
                url,
                timeout=self.timeout,
                verify=self.verify_ssl,
                **kwargs,
            )
            return self._handle_response(response)
        except requests.exceptions.Timeout:
            raise TimeoutError(f"DELETE {path} timed out after {self.timeout}s")
        except requests.exceptions.ConnectionError:
            raise ConnectionError(f"Failed to connect to {url}")
        except DdexusError:
            raise
        except Exception as e:
            raise DdexusError(f"Unexpected error during DELETE {path}: {e}")

    def close(self):
        """Close the HTTP session."""
        self._session.close()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()
        return False
