"""Input validation helpers for ddexusc."""

import re
from typing import List, Optional
from urllib.parse import urlparse

from ddexusc.exceptions import ValidationError


# Common categories available on ddexus
VALID_CATEGORIES = [
    "Development Tools",
    "AI & Machine Learning",
    "Design",
    "Productivity",
    "Social Media",
    "Cloud Services",
    "Education",
    "Data Science",
    "DevOps",
    "Cybersecurity",
    "Open Source",
    "Analytics",
]


def validate_url(url: str) -> str:
    """Validate a URL string.

    Args:
        url: The URL to validate.

    Returns:
        The validated and stripped URL.

    Raises:
        ValidationError: If the URL is invalid.
    """
    if not url or not url.strip():
        raise ValidationError("URL cannot be empty")

    url = url.strip()

    parsed = urlparse(url)
    if parsed.scheme not in ("http", "https"):
        raise ValidationError("URL must start with http:// or https://")

    if not parsed.netloc:
        raise ValidationError("URL must contain a valid domain")

    # Basic domain validation
    domain = parsed.netloc
    if "." not in domain:
        raise ValidationError("URL must contain a valid domain with a TLD")

    return url


def validate_title(title: str) -> str:
    """Validate website title.

    Args:
        title: The title to validate.

    Returns:
        The validated and stripped title.

    Raises:
        ValidationError: If the title is invalid.
    """
    if not title or not title.strip():
        raise ValidationError("Title cannot be empty")

    title = title.strip()

    if len(title) < 2:
        raise ValidationError("Title must be at least 2 characters")

    if len(title) > 200:
        raise ValidationError("Title must be at most 200 characters")

    return title


def validate_description(description: str) -> str:
    """Validate website description.

    Args:
        description: The description to validate.

    Returns:
        The validated and stripped description.

    Raises:
        ValidationError: If the description is invalid.
    """
    if not description or not description.strip():
        raise ValidationError("Description cannot be empty")

    description = description.strip()

    if len(description) < 10:
        raise ValidationError("Description must be at least 10 characters")

    if len(description) > 2000:
        raise ValidationError("Description must be at most 2000 characters")

    return description


def validate_category(category: str) -> str:
    """Validate website category.

    Args:
        category: The category to validate.

    Returns:
        The validated and stripped category.

    Raises:
        ValidationError: If the category is invalid.
    """
    if not category or not category.strip():
        raise ValidationError("Category cannot be empty")

    category = category.strip()

    if len(category) > 100:
        raise ValidationError("Category must be at most 100 characters")

    return category


def validate_tags(tags: Optional[List[str]]) -> Optional[List[str]]:
    """Validate and normalize tags.

    Args:
        tags: List of tag strings.

    Returns:
        Normalized list of tags.

    Raises:
        ValidationError: If tags are invalid.
    """
    if tags is None:
        return None

    if len(tags) > 20:
        raise ValidationError("Maximum 20 tags allowed")

    validated = []
    for tag in tags:
        tag = tag.strip()
        if not tag:
            continue
        if len(tag) > 50:
            raise ValidationError(f"Tag '{tag}' is too long (max 50 characters)")
        validated.append(tag)

    return validated if validated else None


def validate_email(email: str) -> str:
    """Validate email format.

    Args:
        email: The email to validate.

    Returns:
        The validated email.

    Raises:
        ValidationError: If the email is invalid.
    """
    if not email or not email.strip():
        raise ValidationError("Email cannot be empty")

    email = email.strip()
    pattern = r"^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$"

    if not re.match(pattern, email):
        raise ValidationError(f"Invalid email format: {email}")

    return email


def sanitize_string(text: str, max_length: int = 200) -> str:
    """Sanitize a string by stripping whitespace and truncating.

    Args:
        text: The string to sanitize.
        max_length: Maximum allowed length.

    Returns:
        Sanitized string.
    """
    text = text.strip()
    if len(text) > max_length:
        text = text[:max_length].rsplit(" ", 1)[0]
    return text
