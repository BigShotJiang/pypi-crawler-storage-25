"""Retry logic with exponential backoff."""

import time
import random
from typing import Callable, TypeVar, Optional

from ddexusc.exceptions import DdexusError, RateLimitError, APIError

T = TypeVar("T")


def retry_with_backoff(
    func: Callable[..., T],
    max_retries: int = 3,
    backoff_factor: float = 0.5,
    max_backoff: float = 30.0,
    jitter: bool = True,
    retryable_exceptions: tuple = (RateLimitError, APIError),
) -> T:
    """Execute a function with retry logic and exponential backoff.

    Args:
        func: The function to execute.
        max_retries: Maximum number of retry attempts.
        backoff_factor: Base multiplier for backoff calculation.
        max_backoff: Maximum backoff time in seconds.
        jitter: Whether to add random jitter to backoff times.
        retryable_exceptions: Tuple of exception types that should be retried.

    Returns:
        The result of the function call.

    Raises:
        The last exception if all retries are exhausted.
    """
    last_exception = None

    for attempt in range(max_retries + 1):
        try:
            return func()
        except retryable_exceptions as e:
            last_exception = e

            if attempt >= max_retries:
                break

            # Calculate backoff time
            backoff = min(backoff_factor * (2 ** attempt), max_backoff)

            if jitter:
                backoff = backoff * (0.5 + random.random())

            time.sleep(backoff)
        except DdexusError:
            raise

    if last_exception:
        raise last_exception

    raise RuntimeError("retry_with_backoff: unexpected state")
