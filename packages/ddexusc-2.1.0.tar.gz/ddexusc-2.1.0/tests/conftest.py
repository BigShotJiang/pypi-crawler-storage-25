"""Pytest configuration and shared fixtures."""

import os
import json
import pytest
from typing import Dict, Any
from unittest.mock import MagicMock, patch


# Set test environment
os.environ.setdefault("DDEXUS_API_KEY", "test-api-key-12345")
os.environ.setdefault("DDEXUS_BASE_URL", "https://test.ddexus.com")


@pytest.fixture
def mock_response():
    """Create a mock response object."""

    def _create(data: Dict[str, Any], status_code: int = 200):
        mock = MagicMock()
        mock.status_code = status_code
        mock.json.return_value = data
        mock.text = json.dumps(data)
        return mock

    return _create


@pytest.fixture
def sample_website_data():
    """Sample website data for testing."""
    return {
        "id": "cltest123abc",
        "title": "Test Website",
        "description": "A test website for unit testing",
        "url": "https://testwebsite.com",
        "category": "Development Tools",
        "tags": "python, testing, cli",
        "author": "Test Author",
        "favicon": None,
        "screenshot": None,
        "views": 42,
        "featured": False,
        "status": "active",
        "createdAt": "2026-04-26T10:00:00.000Z",
        "updatedAt": "2026-04-26T10:00:00.000Z",
    }


@pytest.fixture
def sample_category_data():
    """Sample category data for testing."""
    return [
        {
            "id": "cat1",
            "name": "Development Tools",
            "slug": "development-tools",
            "description": "Tools for software development",
            "icon": "code",
            "createdAt": "2026-01-01T00:00:00.000Z",
            "_count": {"websites": 15},
        },
        {
            "id": "cat2",
            "name": "AI & Machine Learning",
            "slug": "ai-machine-learning",
            "description": "AI and ML tools and platforms",
            "icon": "brain",
            "createdAt": "2026-01-01T00:00:00.000Z",
            "_count": {"websites": 8},
        },
    ]


@pytest.fixture
def sample_paginated_response(sample_website_data):
    """Sample paginated response for testing."""
    websites = [sample_website_data] * 3
    return {
        "websites": websites,
        "total": 33,
        "page": 1,
        "limit": 12,
        "totalPages": 3,
    }
