"""Test suite for ddexusc."""

__all__ = []
