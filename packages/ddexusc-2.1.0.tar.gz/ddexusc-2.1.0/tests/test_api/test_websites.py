"""Tests for the API modules."""

import pytest
from unittest.mock import MagicMock

from ddexusc.api.websites import WebsiteAPI
from ddexusc.api.categories import CategoryAPI
from ddexusc.api.search import SearchAPI


class TestWebsiteAPI:
    """Test suite for WebsiteAPI."""

    def test_submit_success(self, sample_website_data):
        """Test successful website submission."""
        mock_http = MagicMock()
        mock_http.post.return_value = sample_website_data

        api = WebsiteAPI(mock_http)
        result = api.submit(
            title="Test Website",
            description="A test website for unit testing",
            url="https://testwebsite.com",
            category="Development Tools",
            tags=["python"],
            author="Test Author",
        )

        assert result["title"] == "Test Website"
        mock_http.post.assert_called_once()

    def test_submit_validates_url(self):
        """Test that submit validates URL."""
        mock_http = MagicMock()
        api = WebsiteAPI(mock_http)

        with pytest.raises(Exception):
            api.submit(
                title="Test",
                description="Valid description here",
                url="not-a-url",
                category="Dev",
            )


class TestCategoryAPI:
    """Test suite for CategoryAPI."""

    def test_list_categories(self, sample_category_data):
        """Test listing categories."""
        mock_http = MagicMock()
        mock_http.get.return_value = sample_category_data

        api = CategoryAPI(mock_http)
        categories = api.list()

        assert len(categories) == 2
        assert categories[0].name == "Development Tools"

    def test_get_by_slug(self, sample_category_data):
        """Test getting category by slug."""
        mock_http = MagicMock()
        mock_http.get.return_value = sample_category_data

        api = CategoryAPI(mock_http)
        cat = api.get_by_slug("development-tools")

        assert cat is not None
        assert cat.name == "Development Tools"

    def test_get_by_slug_not_found(self, sample_category_data):
        """Test getting non-existent category by slug."""
        mock_http = MagicMock()
        mock_http.get.return_value = sample_category_data

        api = CategoryAPI(mock_http)
        cat = api.get_by_slug("non-existent")

        assert cat is None


class TestSearchAPI:
    """Test suite for SearchAPI."""

    def test_search(self, sample_paginated_response):
        """Test search."""
        mock_http = MagicMock()
        mock_http.get.return_value = sample_paginated_response

        api = SearchAPI(mock_http)
        results = api.search(query="test")

        assert results.total == 33
        mock_http.get.assert_called_once()

    def test_trending(self, sample_website_data):
        """Test trending websites."""
        mock_http = MagicMock()
        mock_http.get.return_value = {
            "websites": [sample_website_data],
            "total": 1,
        }

        api = SearchAPI(mock_http)
        trending = api.trending(limit=5)

        assert len(trending) == 1

    def test_featured(self, sample_website_data):
        """Test featured websites."""
        mock_http = MagicMock()
        mock_http.get.return_value = [sample_website_data]

        api = SearchAPI(mock_http)
        featured = api.featured()

        assert len(featured) == 1
