"""Tests for the DdexusClient."""

import pytest
from unittest.mock import patch, MagicMock

from ddexusc import DdexusClient
from ddexusc.models import Website, Category, PaginatedResponse
from ddexusc.exceptions import ValidationError


class TestDdexusClient:
    """Test suite for DdexusClient."""

    def test_init_with_api_key(self):
        """Test client initialization with explicit API key."""
        client = DdexusClient(api_key="test-key")
        assert client.api_key == "test-key"

    def test_init_defaults(self):
        """Test client initialization with default values."""
        client = DdexusClient(api_key="test-key")
        assert client.timeout == 30
        assert "ddexus" in client.base_url

    def test_repr(self):
        """Test client string representation."""
        client = DdexusClient(api_key="sk-verylongapikey12345")
        repr_str = repr(client)
        assert "DdexusClient" in repr_str
        assert "sk-verylo..." in repr_str

    def test_context_manager(self):
        """Test client as context manager."""
        with DdexusClient(api_key="test-key") as client:
            assert client.api_key == "test-key"

    @patch("ddexusc.client.HttpClient")
    def test_submit(self, mock_http_cls, sample_website_data):
        """Test website submission."""
        mock_http = MagicMock()
        mock_http.post.return_value = sample_website_data
        mock_http_cls.return_value = mock_http

        client = DdexusClient(api_key="test-key")
        result = client.submit(
            title="Test Website",
            description="A test website for unit testing",
            url="https://testwebsite.com",
            category="Development Tools",
            tags=["python", "testing"],
            author="Test Author",
        )

        assert result["title"] == "Test Website"
        assert result["url"] == "https://testwebsite.com"
        mock_http.post.assert_called_once()

    @patch("ddexusc.client.HttpClient")
    def test_submit_validation_error(self, mock_http_cls):
        """Test that submit validates inputs."""
        mock_http = MagicMock()
        mock_http_cls.return_value = mock_http

        client = DdexusClient(api_key="test-key")

        with pytest.raises(ValidationError):
            client.submit(
                title="",  # Empty title
                description="Valid description",
                url="https://valid.com",
                category="Dev",
            )

    @patch("ddexusc.client.HttpClient")
    def test_get_categories(self, mock_http_cls, sample_category_data):
        """Test getting categories."""
        mock_http = MagicMock()
        mock_http.get.return_value = sample_category_data
        mock_http_cls.return_value = mock_http

        client = DdexusClient(api_key="test-key")
        categories = client.get_categories()

        assert len(categories) == 2
        assert categories[0].name == "Development Tools"
        assert isinstance(categories[0], Category)

    @patch("ddexusc.client.HttpClient")
    def test_search(self, mock_http_cls, sample_paginated_response):
        """Test searching websites."""
        mock_http = MagicMock()
        mock_http.get.return_value = sample_paginated_response
        mock_http_cls.return_value = mock_http

        client = DdexusClient(api_key="test-key")
        results = client.search_websites(query="test")

        assert isinstance(results, PaginatedResponse)
        assert results.total == 33
        assert results.page == 1
        assert len(results.websites) == 3
        assert results.has_next is True

    @patch("ddexusc.client.HttpClient")
    def test_get_featured(self, mock_http_cls, sample_website_data):
        """Test getting featured websites."""
        mock_http = MagicMock()
        mock_http.get.return_value = [sample_website_data]
        mock_http_cls.return_value = mock_http

        client = DdexusClient(api_key="test-key")
        featured = client.get_featured()

        assert len(featured) == 1
        assert isinstance(featured[0], Website)
