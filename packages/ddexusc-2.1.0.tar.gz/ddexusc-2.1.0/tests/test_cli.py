"""Tests for the CLI commands."""

import pytest
from click.testing import CliRunner
from unittest.mock import patch, MagicMock


class TestCLI:
    """Test suite for CLI commands."""

    def test_cli_version(self):
        """Test version flag."""
        from ddexusc.cli.main import cli

        runner = CliRunner()
        result = runner.invoke(cli, ["--version"])
        assert result.exit_code == 0
        assert "1.0.0" in result.output

    def test_cli_help(self):
        """Test help output."""
        from ddexusc.cli.main import cli

        runner = CliRunner()
        result = runner.invoke(cli, ["--help"])
        assert result.exit_code == 0
        assert "ddexus" in result.output
        assert "submit" in result.output
        assert "search" in result.output
        assert "list" in result.output

    def test_submit_help(self):
        """Test submit command help."""
        from ddexusc.cli.main import cli

        runner = CliRunner()
        result = runner.invoke(cli, ["submit", "--help"])
        assert result.exit_code == 0
        assert "--title" in result.output
        assert "--url" in result.output

    def test_search_help(self):
        """Test search command help."""
        from ddexusc.cli.main import cli

        runner = CliRunner()
        result = runner.invoke(cli, ["search", "--help"])
        assert result.exit_code == 0
        assert "--category" in result.output
        assert "--limit" in result.output

    def test_list_help(self):
        """Test list command help."""
        from ddexusc.cli.main import cli

        runner = CliRunner()
        result = runner.invoke(cli, ["list", "--help"])
        assert result.exit_code == 0
        assert "--sort" in result.output
        assert "--featured" in result.output


class TestCLIUtils:
    """Test suite for CLI utility functions."""

    def test_format_table(self):
        """Test table formatting."""
        from ddexusc.cli.utils import format_table

        headers = ["Name", "URL", "Category"]
        rows = [
            ["FastAPI", "https://fastapi.tiangolo.com", "Dev"],
            ["React", "https://react.dev", "Dev"],
        ]

        output = format_table(headers, rows)
        assert "FastAPI" in output
        assert "React" in output
        assert "Name" in output

    def test_format_table_empty(self):
        """Test table formatting with no results."""
        from ddexusc.cli.utils import format_table

        output = format_table(["A", "B"], [])
        assert "No results found" in output

    def test_truncate_text(self):
        """Test text truncation."""
        from ddexusc.cli.utils import truncate_text

        assert truncate_text("Short", 10) == "Short"
        assert truncate_text("A very long text that should be truncated", 20) != "A very long text that should be truncated"
        assert truncate_text("", 10) == ""
        assert truncate_text(None, 10) == ""
