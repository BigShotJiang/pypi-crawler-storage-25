# ddexusc

<p align="center">
  <strong>Official Python Client for ddexus Platform</strong>
</p>

ddexusc is the official Python client library for **ddexus**, a modern data aggregation platform that serves as a curated directory of the best websites, tools, and resources across the web.

## Installation

```bash
pip install ddexusc
```

With optional async support:
```bash
pip install ddexusc[async]
```

## Quick Start

```python
from ddexusc import DdexusClient

# Initialize the client
client = DdexusClient(api_key="your-api-key-here")

# Submit a website
result = client.submit(
    title="My Awesome Tool",
    description="A powerful tool for developers",
    url="https://myawesometool.com",
    category="Development Tools",
    tags=["python", "cli", "developer-tools"],
    author="John Doe"
)

print(f"Website submitted! ID: {result['id']}")
```

## CLI Usage

```bash
# Submit a website (interactive prompts)
ddexus submit

# Search websites
ddexus search "machine learning"

# List websites
ddexus list --category "Development Tools" --limit 10
```

## Features

- Submit websites to ddexus programmatically
- Search and browse the directory
- Async support for high-throughput operations
- CLI tool for terminal usage
- Type hints for IDE autocomplete
- Comprehensive error handling

## Configuration

```bash
# Environment variables
export DDEXUS_API_KEY="your-api-key"
export DDEXUS_BASE_URL="https://your-ddexus-instance.com"
```

## License

MIT License - see [LICENSE](LICENSE) file.
