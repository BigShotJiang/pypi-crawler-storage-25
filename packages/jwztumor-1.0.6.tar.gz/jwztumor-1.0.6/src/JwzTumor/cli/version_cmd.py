"""Version command for JwzTumor CLI."""
import typer


def version_cmd():
    """显示版本号、模型名称和环境信息。"""
    from JwzTumor import __version__
    typer.echo(f"JwzTumor v{__version__}")
    typer.echo(f"Model: LABDG_DGBC_MTLNet_MPTC")
    typer.echo(f"CLI: jwzt")
    typer.echo(f"Package: JwzTumor")

    try:
        import torch
        typer.echo(f"PyTorch: {torch.__version__}")
        typer.echo(f"CUDA available: {torch.cuda.is_available()}")
        if torch.cuda.is_available():
            typer.echo(f"CUDA device: {torch.cuda.get_device_name(0)}")
    except ImportError:
        typer.echo("PyTorch: not installed")
