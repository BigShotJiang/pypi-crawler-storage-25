"""Get command - export default config templates."""
import sys
from pathlib import Path

import typer

get_app = typer.Typer(help="导出默认配置模板")

# ---------------------------------------------------------------------------
# Config template with Chinese comments
# ---------------------------------------------------------------------------

TRAIN_FULL_TEMPLATE = """\
# JwzTumor 训练配置文件
# 乳腺超声良恶性诊断 - 分割辅助多任务学习框架
# 使用方法: jwzt train -c <此文件路径>

model:
  # 模型名称标识
  name: LABDG_DGBC_MTLNet_MPTC
  # 原始输入通道数 (1=灰度, 3=RGB)
  raw_input_channels: 1
  # 预处理模块输出通道数
  pre_channels: 16
  # 编码器输入通道数 (通常与 pre_channels 一致)
  encoder_input_channels: 16
  # 编码器各层级通道数列表
  encoder_channels:
  - 64
  - 128
  - 256
  - 512
  # 提示向量维度 (用于域自适应)
  prompt_dim: 128
  # 挑战特征维度
  challenge_dim: 8
  # 是否使用 Mamba 模块
  use_mamba: true
  # Mamba 实现方式: mamba_like / scan / naive
  mamba_impl: mamba_like
  # 是否使用真实的 mamba-ssm 库 (需要额外安装)
  use_real_mamba: false
  # 是否使用掩码预测头 (MPP)
  use_mpp: true
  # 是否使用边缘检测头
  use_edge_head: true
  # 是否使用符号距离图头 (SDM)
  use_sdm_head: true
  # 是否使用不确定性估计头
  use_uncertainty_head: true
  # 是否使用伪影检测头
  use_artifact_head: true
  # 是否使用中心尺度回归头
  use_center_scale_head: true
  # 是否使用瘤周环形特征提取
  use_peritumoral_ring: true
  # 瘤周环最小半径 (像素)
  ring_radius_min: 8
  # 瘤周环最大半径 (像素)
  ring_radius_max: 16
  # 边界宽度 (像素)
  boundary_width: 5
  # Dropout 概率
  dropout: 0.2

dataset:
  # 训练集名称 (BUSBRA / BUSI)
  train_name: BUSBRA
  # 训练集根目录
  train_root: dataset/BUSBRA
  # 训练集图像子目录名
  train_image_dir: Images
  # 训练集掩码子目录名
  train_mask_dir: Masks
  # 训练集 CSV 标签文件名
  train_csv: bus_data.csv
  # 交叉验证 CSV 文件名
  cv_file: 5-fold-cv.csv
  # 当前使用的折数 (从1开始)
  fold: 1
  # 是否按病例级分割数据 (防止同一病例泄漏到验证集)
  use_case_level_split: true
  # 测试集名称
  test_name: BUSI
  # 测试集根目录
  test_root: dataset/Dataset_BUSI_with_GT
  # 测试集类别文件夹列表
  test_classes:
  - benign
  - malignant
  # 忽略的类别文件夹
  ignore_classes:
  - normal-不使用
  # 图像读取模式: grayscale / rgb
  image_mode: grayscale
  # 是否保持原始尺寸
  keep_original_size: true
  # 缩放策略: resize_longest_side_pad / resize_direct / none
  resize_policy: resize_longest_side_pad
  # 填充模式: reflection / zero / edge
  pad_mode: reflection
  # 模型输入尺寸 (正方形边长, 像素)
  model_input_size: 512
  # 掩码插值方式: nearest / bilinear
  mask_interpolation: nearest
  # 图像插值方式: bilinear / bicubic
  image_interpolation: bilinear
  # 分类类别数
  num_classes: 2
  # 类别标签映射
  label_mapping:
    benign: 0
    malignant: 1
  # 数据缓存模式: ram(内存) / disk(磁盘) / none(不缓存)
  cache_mode: ram
  # 是否缓存原始图像
  cache_raw: true
  # 数据集划分随机种子 (控制 DataLoader shuffle 和 worker 初始化)
  split_seed: 42
  # 是否缓存增强后的图像
  cache_augmented: false

training:
  # 训练阶段: pretrain_pre / pretrain_seg / train_cls / finetune_all
  stage: finetune_all
  # 总训练轮数
  epochs: 80
  # 批量大小
  batch_size: 8
  # 初始学习率
  learning_rate: 0.0001
  # 权重衰减 (L2 正则化)
  weight_decay: 0.0001
  # 优化器: AdamW / Adam / SGD
  optimizer: AdamW
  # 学习率调度器: cosine / cosineannealingwarmrestarts / steplr / reducelronplateau / onecyclelr
  scheduler: cosine
  # 预热轮数 (学习率从0线性增加到设定值)
  warmup_epochs: 5
  # 最小学习率 (调度器下限)
  min_lr: 0.000001
  # --- 调度器参数 (仅在使用对应调度器时生效) ---
  # CosineAnnealingLR: 周期长度 (0=自动=epochs)
  cosine_t_max: 0
  # CosineAnnealingLR: 最低学习率 (0=自动=min_lr)
  cosine_eta_min: 0.0
  # CosineAnnealingWarmRestarts: 初始周期长度
  warmrestart_t0: 10
  # CosineAnnealingWarmRestarts: 周期倍增系数
  warmrestart_t_mult: 2
  # StepLR: 衰减步长 (0=自动=epochs//3)
  step_size: 0
  # StepLR: 衰减因子
  step_gamma: 0.1
  # ReduceLROnPlateau: 衰减因子
  plateau_factor: 0.5
  # ReduceLROnPlateau: 容忍轮数
  plateau_patience: 5
  # ReduceLROnPlateau: 模式 (max=指标越大越好 / min=指标越小越好)
  plateau_mode: max
  # 随机种子 (控制训练过程的随机性: 数据增强、dropout 等)
  random_seed: 42
  # 网络初始化种子 (控制模型权重初始化, 与训练种子独立)
  init_seed: 42
  # 计算设备: auto / cuda / cpu / cuda:0
  device: auto
  # 数据加载工作进程数 (0=主进程加载)
  num_workers: 4
  # 是否启用混合精度训练 (AMP, 需要 CUDA)
  mixed_precision: true
  # 梯度裁剪值 (0=不裁剪)
  gradient_clip_val: 0.0
  # 梯度累积批次数 (有效批量 = batch_size * 此值)
  accumulate_grad_batches: 1
  # 冻结策略: none / encoder / decoder / partial
  freeze_method: none
  # 冻结的层名称 (逗号分隔)
  freeze_layers: ''
  # 冻结比例 (0.0-1.0, 从浅到深冻结)
  freeze_ratio: 0.0
  # 难例挖掘配置
  hard_example_mining:
    # 是否启用难例挖掘
    enabled: false
    # 开始应用难例挖掘的 epoch
    start_epoch: 30
    # 难例权重因子
    weight_factor: 2.0
    # 更新间隔 (batch 数)
    update_interval: 10
    # 难例百分位阈值
    top_percentile: 80.0
  # MixUp 数据增强配置
  mixup:
    # 是否启用 MixUp
    enabled: false
    # MixUp alpha 参数 (Beta分布参数)
    alpha: 0.2
  # 是否使用平衡采样
  balanced_sampling: false
  # 是否对恶性样本过采样
  malignant_oversample: true
  # 是否对小病灶过采样
  small_lesion_oversample: true
  # 是否按设备域平衡采样
  device_domain_balancing: true
  # 输出激活函数: sigmoid / softmax
  output_activation: sigmoid

loss:
  # 分割损失函数: dice_bce / focal_dice / bce / dice
  seg_loss: dice_bce
  # 边缘损失函数: boundary_bce / bce
  edge_loss: boundary_bce
  # 符号距离图损失函数: smooth_l1 / l1 / l2
  sdm_loss: smooth_l1
  # 分类损失函数: asymmetric_focal / focal / bce / ce
  cls_loss: asymmetric_focal
  # AUC 损失函数: auc_margin / none
  auc_loss: auc_margin
  # 是否使用 AUC 损失
  use_auc_loss: true
  # 一致性损失函数: kl_mse / none
  consistency_loss: kl_mse
  # 预训练损失函数: boundary_texture_domain / none
  pre_loss: boundary_texture_domain
  # 是否使用不确定性加权损失
  use_uncertainty_weighting: true
  # 边缘损失权重
  lambda_edge: 1.0
  # SDM 损失权重
  lambda_sdm: 1.0
  # 分类损失权重
  lambda_cls: 1.0
  # AUC 损失权重
  lambda_auc: 0.5
  # 一致性损失权重
  lambda_cons: 0.1
  # 预训练损失权重
  lambda_pre: 0.5
  # 不确定性损失权重
  lambda_unc: 0.1
  # Focal 损失 alpha (正类权重)
  focal_alpha: 0.25
  # Focal 损失 gamma (聚焦参数)
  focal_gamma: 2.0
  # Dice 损失权重 (在 dice_bce 组合中)
  dice_weight: 0.5
  # BCE 损失权重 (在 dice_bce 组合中)
  bce_weight: 0.5

augmentation:
  # 随机水平翻转
  random_horizontal_flip: true
  # 随机旋转角度范围
  random_rotation_degree: 10
  # 随机缩放和平移
  random_scale_shift: true
  # 随机弹性形变
  random_elastic: true
  # 斑点噪声模拟 (超声特有)
  speckle_noise: true
  # Gamma 校正
  gamma_adjustment: true
  # 对比度调整
  contrast_adjustment: true
  # 亮度增益
  brightness_gain: true
  # 频域振幅扰动
  frequency_amplitude_perturbation: true
  # 后方声影模拟
  posterior_shadow_simulation: true
  # 后方增强模拟
  posterior_enhancement_simulation: true
  # 随机模糊概率
  random_blur_prob: 0.1
  # 粗粒度 Dropout 概率 (CutOut)
  coarse_dropout_prob: 0.05
  # 前景约束裁剪
  foreground_constrained_crop: true

metrics:
  # 分类评估指标列表
  classification:
  - auc
  - accuracy
  - sensitivity
  - specificity
  - precision
  - f1
  # 分割评估指标列表
  segmentation:
  - dice
  - iou
  - hd95
  - boundary_f1
  - precision
  - recall

checkpoint:
  # 监控的最优指标名称
  monitor: val_auc
  # 是否保存最佳 AUC 模型
  save_best_auc: true
  # 是否保存最佳 F1 模型
  save_best_f1: true
  # 是否保存最佳灵敏度模型
  save_best_sensitivity: true
  # 是否保存最佳 Dice 模型
  save_best_dice: true
  # 是否保存最后一轮模型
  save_last: true

inference:
  # 模型检查点路径
  model_path: checkpoints/best_auc.ckpt
  # 推理输出目录
  output_dir: outputs/busi_predictions
  # 推理模式: single / batch
  mode: batch
  # 是否使用测试时增强 (TTA)
  use_tta: true
  # TTA 缩放因子列表
  tta_scales:
  - 0.9
  - 1.0
  - 1.1
  # TTA 是否包含翻转
  tta_flip: true
  # 分割二值化阈值
  threshold: 0.5
  # 是否仅保留最大连通域
  use_largest_component: true
  # 是否恢复为原始尺寸
  restore_to_original_size: true
  # 是否保存叠加可视化
  save_overlay: true
  # 是否保存不确定性图
  save_uncertainty: true
  # 是否保存边缘检测结果
  save_edge: true
  # 是否保存热力图
  save_heatmap: true

postprocess:
  # 分割后处理阈值
  threshold: 0.5
  # 是否保留最大连通域
  use_largest_component: true
  # 最小区域面积 (像素, 小于此值的区域将被移除)
  min_region_size: 100
  # 温度缩放系数 (用于分类概率校准)
  temperature_scaling: 1.0
  # 是否启用分类校准
  use_calibration: false

experiment:
  # 实验名称
  name: JwzTumor
  # 作者
  author: SuShuheng
  # 许可证
  license: Apache-2.0
  # 实验结果保存根目录
  save_dir: experiments
  # 日志保存目录
  log_dir: experiments/logs
  # 检查点保存目录
  checkpoint_dir: experiments/checkpoints
  # 结果保存目录
  result_dir: experiments/results
  # 每隔 N 步记录一次日志
  log_every_n_steps: 10
  # 验证检查间隔 (1.0=每轮验证, 0.5=每半轮验证)
  val_check_interval: 1.0
  # 保存最优模型的数量
  save_top_k: 1
  # 是否保存最新模型
  save_latest: false
  # 运行阶段标识 (内部使用)
  runtime_stage: ''

monitoring:
  # 早停配置
  early_stopping:
    # 是否启用早停
    enabled: true
    # 监控的指标名称
    metric: val_loss
    # 模式: min(指标越小越好) / max(指标越大越好)
    mode: min
    # 容忍轮数 (连续N轮无改善则停止)
    patience: 10
    # 最小改善量
    min_delta: 0.001
  # 模型选择配置
  model_selection:
    # 选择最优模型的指标
    metric: val_auc
    # 模式: max / min
    mode: max
  # 预测二值化阈值
  predict_threshold: 0.5
  # 是否输出详细监控信息
  verbose: true
"""

# Template-specific overrides applied on top of the base template
_TEMPLATE_OVERRIDES = {
    "train_debug": {
        "training.stage": "finetune_all",
        "training.epochs": "2",
        "training.batch_size": "2",
        "training.num_workers": "2",
        "training.mixed_precision": "true",
    },
    "train_pretrain_pre": {
        "training.stage": "pretrain_pre",
    },
    "train_pretrain_seg": {
        "training.stage": "pretrain_seg",
    },
    "train_cls_head": {
        "training.stage": "train_cls",
    },
    "train_finetune": {
        "training.stage": "finetune_all",
    },
}


def _apply_overrides(template: str, overrides: dict) -> str:
    """Apply key=value overrides to a YAML template string."""
    import re
    for key_path, new_value in overrides.items():
        section, field = key_path.rsplit(".", 1)
        # Find the field in the correct section and replace its value
        pattern = rf"(  {field}:)\s.*$"
        # Only replace within the correct section context
        lines = template.split("\n")
        in_section = False
        for i, line in enumerate(lines):
            stripped = line.rstrip()
            if stripped == f"{section}:" and not stripped.startswith(" "):
                in_section = True
                continue
            if in_section and not stripped.startswith(" ") and stripped:
                in_section = False
                continue
            if in_section and re.match(rf"^  {field}: ", stripped):
                indent = "  "
                lines[i] = f"{indent}{field}: {new_value}"
                break
        template = "\n".join(lines)
    return template


@get_app.callback(invoke_without_command=True)
def get_config(
    name: str = typer.Option("train_full", "--name", "-n", help="模板名称"),
    output: str = typer.Option("-", "--output", "-o", help="输出路径（- 表示标准输出）"),
):
    """导出带中文注释的 YAML 配置模板。

    可用模板:
        train_full, train_debug, train_pretrain_pre,
        train_pretrain_seg, train_cls_head, train_finetune,
        infer_busi, eval_busi
    """
    template = TRAIN_FULL_TEMPLATE

    # Apply template-specific overrides
    overrides = _TEMPLATE_OVERRIDES.get(name, {})
    if overrides:
        template = _apply_overrides(template, overrides)

    if output == "-":
        sys.stdout.write(template)
    else:
        out_path = Path(output)
        # If output is an existing directory or has no .yaml suffix, treat as directory
        if out_path.is_dir() or not out_path.suffix:
            out_path = out_path / f"{name}.yaml"
        out_path.parent.mkdir(parents=True, exist_ok=True)
        out_path.write_text(template, encoding="utf-8")
        typer.echo(f"Config saved to {out_path}")
