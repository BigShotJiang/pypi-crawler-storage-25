"""Audit-data command for JwzTumor CLI."""
import typer

audit_app = typer.Typer(help="审计数据集完整性和统计信息")


@audit_app.callback(invoke_without_command=True)
def audit_data(
    data_root: str = typer.Option("dataset", "--data-root", "-d", help="数据集根目录"),
    output: str = typer.Option("outputs/dataset_audit_summary.json", "--output", "-o", help="审计结果 JSON 输出路径"),
    verbose: bool = typer.Option(False, "--verbose", "-v", help="详细日志模式"),
):
    """审计 BUSBRA 和 BUSI 数据集的完整性与统计信息。

    检查项目:
        - BUSBRA 图像-掩码配对
        - CSV 宽高与实际图像尺寸对比
        - 病例级数据泄漏检测
        - 设备到域ID的映射
        - BUSI 多掩码识别
        - normal 文件夹跳过
        - 图像通道和尺寸统计
        - 掩码前景比例
    """
    import logging
    from ..utils.logging import setup_logging
    from ..utils.io import save_json
    from ..data.audit import audit_dataset

    level = logging.DEBUG if verbose else logging.INFO
    setup_logging(level=level)
    logger = logging.getLogger(__name__)

    logger.info("Auditing datasets in %s", data_root)

    result = audit_dataset(data_root)

    save_json(result, output)
    logger.info("Audit summary saved to %s", output)

    # Print summary
    total_issues = result.get("summary", {}).get("total_issues", 0)
    total_warnings = result.get("summary", {}).get("total_warnings", 0)

    if total_issues > 0:
        typer.secho(f"Found {total_issues} issues:", fg=typer.colors.RED)
        for ds_name, ds_result in result.get("datasets", {}).items():
            for issue in ds_result.get("issues", []):
                typer.secho(f"  [{ds_name}] {issue}", fg=typer.colors.RED)
    else:
        typer.secho("No critical issues found.", fg=typer.colors.GREEN)

    if total_warnings > 0:
        typer.secho(f"\n{total_warnings} warnings:", fg=typer.colors.YELLOW)
        for ds_name, ds_result in result.get("datasets", {}).items():
            for warning in ds_result.get("warnings", []):
                typer.secho(f"  [{ds_name}] {warning}", fg=typer.colors.YELLOW)
