"""CLI utility functions for JwzTumor."""
from pathlib import Path
from typing import Optional


def resolve_config_path(config_name: str, config_dir: str = "configs") -> Path:
    """Resolve config path from name or full path."""
    path = Path(config_name)
    if path.exists():
        return path
    return Path(config_dir) / f"{config_name}.yaml"


def ensure_dir(path: str) -> Path:
    """Ensure directory exists."""
    p = Path(path)
    p.mkdir(parents=True, exist_ok=True)
    return p
