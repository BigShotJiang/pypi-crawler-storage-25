"""Eval command for JwzTumor CLI."""
import typer
from typing import Optional

eval_app = typer.Typer(help="评估预测结果与真实标签的对比")


@eval_app.callback(invoke_without_command=True)
def eval_cmd(
    config: str = typer.Option("configs/eval_busi.yaml", "--config", "-c", help="YAML 配置文件路径"),
    pred: str = typer.Option("outputs/busi_predictions", "--pred", "-p", help="预测结果输出目录"),
    data: str = typer.Option("dataset/Dataset_BUSI_with_GT", "--data", "-d", help="真实标签数据目录"),
    output: Optional[str] = typer.Option(None, "--output", "-o", help="评估结果输出目录"),
    verbose: bool = typer.Option(False, "--verbose", "-v", help="详细日志模式"),
):
    """评估分类和分割指标。"""
    import logging
    import json
    from pathlib import Path

    from ..utils.config import load_config
    from ..utils.logging import setup_logging
    from ..utils.io import load_json
    from ..evaluation.evaluator import Evaluator

    cfg = load_config(config)
    level = logging.DEBUG if verbose else logging.INFO
    setup_logging(level=level)
    logger = logging.getLogger(__name__)

    # Load predictions
    pred_dir = Path(pred)
    pred_csv = pred_dir / "predictions.csv"
    metrics_json = pred_dir / "metrics.json"

    if not pred_csv.exists():
        logger.error("Predictions not found: %s", pred_csv)
        raise typer.Exit(1)

    import pandas as pd
    df = pd.read_csv(pred_csv)

    predictions = []
    for _, row in df.iterrows():
        pred_item = {
            "image_id": row.get("image_id", ""),
            "pred_label": row.get("pred_label", -1),
            "prob_malignant": row.get("prob_malignant", 0),
            "true_label": row.get("true_label"),
        }
        predictions.append(pred_item)

    evaluator = Evaluator(cfg)
    result = evaluator.evaluate_predictions(
        predictions=predictions,
        output_dir=output or str(pred_dir),
    )

    logger.info("Evaluation Results:")
    if "classification" in result:
        for k, v in result["classification"].items():
            logger.info("  %s: %.4f", k, v)
    if "segmentation" in result:
        for k, v in result["segmentation"].items():
            logger.info("  %s: %.4f", k, v)
