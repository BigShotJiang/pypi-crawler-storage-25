"""
MPTCHead -- Multi-Path Tumour Classification Head
===================================================
Four-stream classification head for benign / malignant diagnosis.

The four streams each pool features from a spatially distinct region of the
encoder / decoder outputs:

1. **lesion_inner_stream**  -- features masked by the segmentation probability
   (tumour interior).
2. **boundary_stream**      -- features masked by the edge probability (tumour
   boundary zone).
3. **peritumoral_ring_stream** -- features masked by a dilated ring surrounding
   the tumour (peritumoral tissue).
4. **global_context_stream**   -- deepest encoder features pooled globally.

The four stream embeddings are concatenated with the morphology prompt and
fed into a fusion classifier that produces the final benign / malignant logits.

Config keys consumed:
    ``config.model``:
        - encoder_channels, prompt_dim, use_peritumoral_ring,
          ring_radius_min, ring_radius_max
    ``config.dataset``:
        - num_classes (default 2)
"""
from typing import Dict, List, Optional, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F

import logging

logger = logging.getLogger(__name__)


class MPTCHead(nn.Module):
    """Four-stream classification head for breast ultrasound diagnosis.

    Each stream applies a spatial mask (derived from the segmentation /
    edge predictions) to the encoder feature map ``z_pre``, pools the
    masked features, and projects them to a fixed-size embedding.  The
    four embeddings together with the morphology prompt are fused by a
    two-layer MLP to produce classification logits.

    Args:
        config: A :class:`Config` object.  The relevant sub-configs are
            ``config.model`` and ``config.dataset``.

    Shape:
        - encoder_features: list of 4 Tensors (shallowest to deepest),
          e.g. ``[B, C_i, H_i, W_i]``.
        - seg_prob: ``[B, 1, H, W]`` (sigmoid-activated segmentation).
        - edge_prob: ``[B, 1, H, W]`` (sigmoid-activated edge map).
        - sdm_pred: ``[B, 1, H, W]`` (SDM prediction).
        - uncertainty_map: ``[B, 1, H, W]`` or ``None``.
        - morph_prompt: ``[B, prompt_dim]``.
        - z_pre: ``[B, C_pre, H, W]`` (pre-network output features,
          same spatial size as the segmentation output).
        - aux_maps: dict of auxiliary maps (unused in this head but
          accepted for interface compatibility).
        - Output: ``(cls_logits [B, num_classes], cls_prob [B, num_classes])``
    """

    def __init__(self, config):
        super().__init__()

        model_cfg = config.model
        dataset_cfg = config.dataset

        self.encoder_channels: List[int] = list(
            getattr(model_cfg, "encoder_channels", [64, 128, 256, 512])
        )
        self.prompt_dim: int = getattr(model_cfg, "prompt_dim", 128)
        self.use_peritumoral_ring: bool = getattr(
            model_cfg, "use_peritumoral_ring", True
        )
        self.ring_radius_min: int = getattr(model_cfg, "ring_radius_min", 8)
        self.ring_radius_max: int = getattr(model_cfg, "ring_radius_max", 16)
        self.num_classes: int = getattr(dataset_cfg, "num_classes", 2)

        # z_pre channel count comes from LABDG-Pre's pre_channels config.
        z_pre_channels: int = getattr(model_cfg, "pre_channels", 16)

        # Each stream projects from its pooled channel count to a common
        # embedding dimension.
        self.stream_embed_dim: int = 64

        # ------------------------------------------------------------------
        # Stream 1: lesion inner (masked by seg_prob)
        # ------------------------------------------------------------------
        self.lesion_inner_pool = nn.AdaptiveAvgPool2d(1)
        self.lesion_inner_proj = nn.Linear(z_pre_channels, self.stream_embed_dim)

        # ------------------------------------------------------------------
        # Stream 2: boundary (masked by edge_prob)
        # ------------------------------------------------------------------
        self.boundary_pool = nn.AdaptiveAvgPool2d(1)
        self.boundary_proj = nn.Linear(z_pre_channels, self.stream_embed_dim)

        # ------------------------------------------------------------------
        # Stream 3: peritumoral ring
        # ------------------------------------------------------------------
        if self.use_peritumoral_ring:
            self.ring_pool = nn.AdaptiveAvgPool2d(1)
            self.ring_proj = nn.Linear(z_pre_channels, self.stream_embed_dim)
        else:
            self.ring_pool = None
            self.ring_proj = None

        # ------------------------------------------------------------------
        # Stream 4: global context (deepest encoder features)
        # ------------------------------------------------------------------
        deepest_ch = self.encoder_channels[-1]
        self.global_pool = nn.AdaptiveAvgPool2d(1)
        self.global_proj = nn.Linear(deepest_ch, self.stream_embed_dim)

        # ------------------------------------------------------------------
        # Fusion classifier
        # ------------------------------------------------------------------
        num_active_streams = 4 if self.use_peritumoral_ring else 3
        fusion_in = num_active_streams * self.stream_embed_dim + self.prompt_dim

        self.fusion = nn.Sequential(
            nn.Linear(fusion_in, fusion_in // 2),
            nn.ReLU(inplace=True),
            nn.Dropout(p=getattr(model_cfg, "dropout", 0.2)),
            nn.Linear(fusion_in // 2, self.num_classes),
        )

        self._reset_parameters()

    # -----------------------------------------------------------------
    # Initialisation
    # -----------------------------------------------------------------

    def _reset_parameters(self) -> None:
        """Initialize all linear layers with Kaiming normal."""
        for module in self.modules():
            if isinstance(module, nn.Linear):
                nn.init.kaiming_normal_(module.weight, nonlinearity="relu")
                if module.bias is not None:
                    nn.init.zeros_(module.bias)

    # -----------------------------------------------------------------
    # Ring mask generation
    # -----------------------------------------------------------------

    def _make_ring_mask(self, seg_prob: torch.Tensor) -> torch.Tensor:
        """Create a peritumoral ring mask by dilating the segmentation
        probability and subtracting the original mask.

        The ring is the annular region between ``ring_radius_min`` and
        ``ring_radius_max`` dilations of the binary mask.

        Args:
            seg_prob: Sigmoid-activated segmentation ``[B, 1, H, W]``.

        Returns:
            Ring mask ``[B, 1, H, W]`` with values in [0, 1].
        """
        binary = (seg_prob > 0.5).float()

        B, _, H, W = binary.shape

        # Build disk kernels for dilation.
        def _disk_kernel(radius: int) -> torch.Tensor:
            """Create a binary disk structuring element."""
            r = radius
            size = 2 * r + 1
            ax = torch.arange(size, device=binary.device, dtype=torch.float32) - r
            xx, yy = torch.meshgrid(ax, ax, indexing="ij")
            disk = ((xx ** 2 + yy ** 2) <= r ** 2).float()
            return disk.unsqueeze(0).unsqueeze(0)  # [1, 1, k, k]

        kernel_outer = _disk_kernel(self.ring_radius_max)
        kernel_inner = _disk_kernel(self.ring_radius_min)

        # Dilate using conv2d with binary weights and threshold.
        # outer_dilated = D(binary, r_max)
        outer = F.conv2d(
            binary,
            kernel_outer.expand(binary.shape[1], -1, -1, -1),
            padding=self.ring_radius_max,
        )
        outer = (outer > 0.5).float()

        # inner_dilated = D(binary, r_min)
        inner = F.conv2d(
            binary,
            kernel_inner.expand(binary.shape[1], -1, -1, -1),
            padding=self.ring_radius_min,
        )
        inner = (inner > 0.5).float()

        ring = outer - inner
        ring = ring.clamp(0.0, 1.0)

        return ring

    # -----------------------------------------------------------------
    # Helper: masked pool
    # -----------------------------------------------------------------

    @staticmethod
    def _masked_pool(
        features: torch.Tensor,
        mask: torch.Tensor,
        pool: nn.Module,
    ) -> torch.Tensor:
        """Apply a spatial mask to features and perform adaptive average
        pooling.

        The mask is applied multiplicatively.  If the mask is entirely zero
        for a sample, we fall back to unmasked pooling so that gradients
        remain well-defined.

        Args:
            features: ``[B, C, H, W]``.
            mask:     ``[B, 1, H, W]`` (values in [0, 1]).
            pool:     An ``AdaptiveAvgPool2d(1)`` module.

        Returns:
            ``[B, C]`` pooled feature vector.
        """
        masked = features * mask
        pooled = pool(masked).flatten(1)  # [B, C]

        # Fallback: if all mask values for a sample are zero, use unmasked.
        mask_sum = mask.sum(dim=(1, 2, 3))  # [B]
        empty = mask_sum < 1e-6
        if empty.any():
            unmasked = pool(features).flatten(1)  # [B, C]
            pooled = torch.where(
                empty.unsqueeze(1),
                unmasked,
                pooled,
            )
        return pooled

    # -----------------------------------------------------------------
    # Forward
    # -----------------------------------------------------------------

    def forward(
        self,
        encoder_features: List[torch.Tensor],
        seg_prob: torch.Tensor,
        edge_prob: torch.Tensor,
        sdm_pred: torch.Tensor,
        uncertainty_map: Optional[torch.Tensor],
        morph_prompt: torch.Tensor,
        z_pre: torch.Tensor,
        aux_maps: Optional[Dict[str, torch.Tensor]] = None,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """Run the four-stream classification head.

        Args:
            encoder_features: List of 4 encoder feature maps (shallowest to
                deepest).  ``encoder_features[-1]`` is used by the global
                context stream.
            seg_prob: Sigmoid segmentation probability ``[B, 1, H, W]``.
            edge_prob: Sigmoid edge probability ``[B, 1, H, W]``.
            sdm_pred: Signed distance map prediction ``[B, 1, H, W]``.
                (Accepted for interface compatibility; not directly used by
                the streams.)
            uncertainty_map: Uncertainty map ``[B, 1, H, W]`` or ``None``.
                (Accepted for interface compatibility.)
            morph_prompt: Morphology prompt ``[B, prompt_dim]`` from MPP.
            z_pre: Pre-network output features ``[B, C, H, W]`` at the same
                spatial resolution as ``seg_prob``.
            aux_maps: Dict of auxiliary maps (unused, accepted for
                interface compatibility).

        Returns:
            A tuple of:

            - **cls_logits** ``[B, num_classes]`` -- raw classification logits.
            - **cls_prob** ``[B, num_classes]`` -- softmax probabilities.
        """
        stream_features = []

        # ----------------------------------------------------------------
        # Stream 1: lesion inner
        # ----------------------------------------------------------------
        inner_feat = self._masked_pool(z_pre, seg_prob, self.lesion_inner_pool)
        inner_feat = self.lesion_inner_proj(inner_feat)  # [B, embed_dim]
        stream_features.append(inner_feat)

        # ----------------------------------------------------------------
        # Stream 2: boundary zone
        # ----------------------------------------------------------------
        boundary_feat = self._masked_pool(z_pre, edge_prob, self.boundary_pool)
        boundary_feat = self.boundary_proj(boundary_feat)
        stream_features.append(boundary_feat)

        # ----------------------------------------------------------------
        # Stream 3: peritumoral ring
        # ----------------------------------------------------------------
        if self.use_peritumoral_ring and self.ring_proj is not None:
            ring_mask = self._make_ring_mask(seg_prob)  # [B, 1, H, W]
            ring_feat = self._masked_pool(z_pre, ring_mask, self.ring_pool)
            ring_feat = self.ring_proj(ring_feat)
            stream_features.append(ring_feat)

        # ----------------------------------------------------------------
        # Stream 4: global context (deepest encoder features)
        # ----------------------------------------------------------------
        deep_feat = encoder_features[-1]  # [B, C_deep, H_deep, W_deep]
        global_feat = self.global_pool(deep_feat).flatten(1)  # [B, C_deep]
        global_feat = self.global_proj(global_feat)  # [B, embed_dim]
        stream_features.append(global_feat)

        # ----------------------------------------------------------------
        # Fusion
        # ----------------------------------------------------------------
        fused = torch.cat(stream_features + [morph_prompt], dim=1)
        cls_logits = self.fusion(fused)         # [B, num_classes]
        cls_prob = F.softmax(cls_logits, dim=-1)  # [B, num_classes]

        return cls_logits, cls_prob
