"""
DGBC_MTLNet -- Multi-Task Diagnosis Network for Breast Ultrasound
=================================================================

The main model class that orchestrates the complete pipeline for multi-task
breast ultrasound diagnosis:

1. **LABDG-Pre**  -- domain-aware preprocessing producing ``z_pre``.
2. **DGBCEncoder** -- CNN-Mamba hybrid multi-scale encoder.
3. **MorphologyProxyPrompt (MPP)** -- learns morphological prompt tokens
   that capture lesion characteristics and data difficulty.
4. **BoundaryRegionDecoder** -- multi-head decoder for segmentation,
   edge detection, signed distance map prediction, and uncertainty
   estimation.

Usage::

    model = DGBC_MTLNet(config)
    outputs = model(image, mask=mask, edge=edge, sdm=sdm, label=label, meta=meta)

All output tensors share the original input spatial resolution (H, W).
"""

from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch import Tensor

from .dgbc_encoder import DGBCEncoder

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# LABDG-Pre  (lightweight domain-aware preprocessing head)
# ---------------------------------------------------------------------------

class LABDGPre(nn.Module):
    """Lightweight domain-aware preprocessing module.

    Takes a raw grayscale image [B, 1, H, W] and produces:

    * ``z_pre`` [B, pre_channels, H, W] -- a richer feature map for the
      encoder.
    * ``pre_aux_maps`` -- auxiliary outputs used by the MPP module.

    Parameters
    ----------
    raw_input_channels : int
        Number of channels in the raw image (1 for grayscale).
    pre_channels : int
        Number of output channels for ``z_pre``.
    dropout : float
        Dropout probability.
    """

    def __init__(
        self,
        raw_input_channels: int = 1,
        pre_channels: int = 16,
        dropout: float = 0.2,
    ):
        super().__init__()
        self.pre_channels = pre_channels

        # Stem: raw image -> multi-channel feature map.
        self.stem = nn.Sequential(
            nn.Conv2d(raw_input_channels, pre_channels // 2,
                      kernel_size=3, padding=1, bias=False),
            nn.BatchNorm2d(pre_channels // 2),
            nn.ReLU(inplace=True),
            nn.Conv2d(pre_channels // 2, pre_channels,
                      kernel_size=3, padding=1, bias=False),
            nn.BatchNorm2d(pre_channels),
            nn.ReLU(inplace=True),
        )

        # Auxiliary heads operating on z_pre.
        self.boundary_head = nn.Sequential(
            nn.Conv2d(pre_channels, 1, kernel_size=1),
        )
        self.texture_head = nn.Sequential(
            nn.Conv2d(pre_channels, pre_channels, kernel_size=3,
                      padding=1, groups=pre_channels, bias=False),
            nn.BatchNorm2d(pre_channels),
            nn.ReLU(inplace=True),
            nn.AdaptiveAvgPool2d(1),
        )
        self.domain_head = nn.Sequential(
            nn.Linear(pre_channels, pre_channels),
            nn.ReLU(inplace=True),
        )
        self.dropout = nn.Dropout2d(p=dropout)

    def forward(
        self, image: Tensor, meta: Optional[Dict[str, Any]] = None,
    ) -> Tuple[Tensor, Dict[str, Tensor]]:
        """Preprocess raw image.

        Parameters
        ----------
        image : Tensor [B, 1, H, W]
            Raw grayscale ultrasound image.
        meta : dict, optional
            Metadata dict (may contain ``"device_domain"`` key).

        Returns
        -------
        z_pre : Tensor [B, pre_channels, H, W]
        pre_aux_maps : dict  with keys ``"boundary_map"``,
            ``"texture_code"``, ``"domain_code"``.
        """
        z_pre = self.stem(image)
        z_pre = self.dropout(z_pre)

        boundary_map = self.boundary_head(z_pre)               # [B,1,H,W]
        texture_code = self.texture_head(z_pre).flatten(1)     # [B, C]
        domain_code = self.domain_head(texture_code)           # [B, C]

        pre_aux_maps = {
            "boundary_map": boundary_map,
            "texture_code": texture_code,
            "domain_code": domain_code,
            "z_pre": z_pre,
        }
        return z_pre, pre_aux_maps


# ---------------------------------------------------------------------------
# MorphologyProxyPrompt (MPP)
# ---------------------------------------------------------------------------

class MorphologyProxyPrompt(nn.Module):
    """Morphology Proxy Prompt module.

    Learns a prompt vector that encodes morphological characteristics of the
    lesion and a scalar challenge/difficulty vector that informs the decoder
    about data complexity.

    Parameters
    ----------
    pre_channels : int
        Channel dimension of ``texture_code`` from LABDG-Pre.
    stage_channels : list[int]
        Channel counts from the four encoder stages.
    prompt_dim : int
        Dimension of the morphological prompt vector.
    challenge_dim : int
        Dimension of the challenge vector.
    dropout : float
        Dropout probability.
    """

    def __init__(
        self,
        pre_channels: int = 16,
        stage_channels: Optional[List[int]] = None,
        prompt_dim: int = 128,
        challenge_dim: int = 8,
        dropout: float = 0.2,
    ):
        super().__init__()
        stage_channels = stage_channels or [64, 128, 256, 512]
        self.prompt_dim = prompt_dim
        self.challenge_dim = challenge_dim

        # Per-stage spatial pooling + projection.
        total_stage_dim = 0
        self.stage_projs = nn.ModuleList()
        for c in stage_channels:
            self.stage_projs.append(nn.Linear(c, c // 4))
            total_stage_dim += c // 4

        # Fusion of pre features + stage features.
        fusion_in = pre_channels + total_stage_dim
        self.fusion = nn.Sequential(
            nn.Linear(fusion_in, prompt_dim),
            nn.ReLU(inplace=True),
            nn.Linear(prompt_dim, prompt_dim),
        )

        # Challenge branch.
        self.challenge_proj = nn.Sequential(
            nn.Linear(prompt_dim, challenge_dim),
            nn.ReLU(inplace=True),
        )

        self.dropout = nn.Dropout(p=dropout)

    def forward(
        self,
        pre_aux_maps: Dict[str, Tensor],
        stage_feats: List[Tensor],
    ) -> Tuple[Tensor, Tensor]:
        """Compute morphological prompt and challenge vector.

        Parameters
        ----------
        pre_aux_maps : dict
            Auxiliary maps from LABDG-Pre (must contain ``"texture_code"``).
        stage_feats : list[Tensor]
            Four feature maps from the encoder stages.

        Returns
        -------
        morph_prompt : Tensor [B, prompt_dim]
        challenge_vec : Tensor [B, challenge_dim]
        """
        texture_code = pre_aux_maps["texture_code"]  # [B, pre_channels]

        stage_vectors = []
        for feat, proj in zip(stage_feats, self.stage_projs):
            # Global average pool each stage.
            pooled = feat.mean(dim=[2, 3])  # [B, C]
            stage_vectors.append(proj(pooled))  # [B, C//4]

        fused = torch.cat([texture_code] + stage_vectors, dim=1)  # [B, N]
        fused = self.dropout(fused)

        morph_prompt = self.fusion(fused)          # [B, prompt_dim]
        challenge_vec = self.challenge_proj(morph_prompt)  # [B, challenge_dim]

        return morph_prompt, challenge_vec


# ---------------------------------------------------------------------------
# BoundaryRegionDecoder
# ---------------------------------------------------------------------------

class BoundaryRegionDecoder(nn.Module):
    """Multi-head decoder for segmentation, edge, SDM, and uncertainty.

    Progressively upsamples the bridge feature, injecting stage features and
    morphological prompts at each scale.

    Parameters
    ----------
    bridge_channels : int
        Channel count of the fused bridge feature from CSIB.
    stage_channels : list[int]
        Channel counts of the four encoder stages (coarse to fine).
    prompt_dim : int
        Dimension of the morphological prompt vector.
    use_edge_head : bool
        Whether to include the edge prediction head.
    use_sdm_head : bool
        Whether to include the signed-distance-map prediction head.
    use_uncertainty_head : bool
        Whether to include the uncertainty estimation head.
    dropout : float
        Dropout probability.
    """

    def __init__(
        self,
        bridge_channels: int = 256,
        stage_channels: Optional[List[int]] = None,
        prompt_dim: int = 128,
        use_edge_head: bool = True,
        use_sdm_head: bool = True,
        use_uncertainty_head: bool = True,
        dropout: float = 0.2,
    ):
        super().__init__()
        stage_channels = stage_channels or [64, 128, 256, 512]
        self.use_edge_head = use_edge_head
        self.use_sdm_head = use_sdm_head
        self.use_uncertainty_head = use_uncertainty_head

        # We decode from the deepest level back to full resolution.
        # Decoder blocks: upsample + concat with skip + refine.
        # Stage4 (index 3) is the deepest; we upsample bridge to that
        # resolution, then progressively upsample.

        s4_c, s3_c, s2_c, s1_c = stage_channels[3], stage_channels[2], \
                                   stage_channels[1], stage_channels[0]

        # Prompt injection: project prompt and broadcast.
        self.prompt_proj = nn.Linear(prompt_dim, bridge_channels)

        # Decoder up-blocks.
        # Block 4 -> 3  (bridge_channels + s3_c -> s3_c)
        self.up_block_43 = self._make_up_block(bridge_channels + s3_c, s3_c)
        # Block 3 -> 2
        self.up_block_32 = self._make_up_block(s3_c + s2_c, s2_c)
        # Block 2 -> 1
        self.up_block_21 = self._make_up_block(s2_c + s1_c, s1_c)
        # Block 1 -> full res
        self.up_block_10 = self._make_up_block(s1_c, s1_c // 2)

        # Segmentation head.
        self.seg_head = nn.Sequential(
            nn.Conv2d(s1_c // 2, s1_c // 4, kernel_size=3, padding=1, bias=False),
            nn.BatchNorm2d(s1_c // 4),
            nn.ReLU(inplace=True),
            nn.Conv2d(s1_c // 4, 1, kernel_size=1),
        )

        # Edge head.
        if self.use_edge_head:
            self.edge_head = nn.Sequential(
                nn.Conv2d(s1_c // 2, s1_c // 4, kernel_size=3, padding=1, bias=False),
                nn.BatchNorm2d(s1_c // 4),
                nn.ReLU(inplace=True),
                nn.Conv2d(s1_c // 4, 1, kernel_size=1),
            )

        # SDM head.
        if self.use_sdm_head:
            self.sdm_head = nn.Sequential(
                nn.Conv2d(s1_c // 2, s1_c // 4, kernel_size=3, padding=1, bias=False),
                nn.BatchNorm2d(s1_c // 4),
                nn.ReLU(inplace=True),
                nn.Conv2d(s1_c // 4, 1, kernel_size=1),
            )

        # Uncertainty head.
        if self.use_uncertainty_head:
            self.uncertainty_head = nn.Sequential(
                nn.Conv2d(s1_c // 2, s1_c // 4, kernel_size=3, padding=1, bias=False),
                nn.BatchNorm2d(s1_c // 4),
                nn.ReLU(inplace=True),
                nn.Conv2d(s1_c // 4, 1, kernel_size=1),
            )

        # Coarse mask (from bridge feature directly -- for consistency loss).
        self.coarse_head = nn.Sequential(
            nn.Conv2d(bridge_channels, bridge_channels // 4,
                      kernel_size=3, padding=1, bias=False),
            nn.BatchNorm2d(bridge_channels // 4),
            nn.ReLU(inplace=True),
            nn.Conv2d(bridge_channels // 4, 1, kernel_size=1),
        )

        self.dropout = nn.Dropout2d(p=dropout)

    @staticmethod
    def _make_up_block(in_channels: int, out_channels: int) -> nn.Sequential:
        return nn.Sequential(
            nn.Conv2d(in_channels, out_channels, kernel_size=3,
                      padding=1, bias=False),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True),
            nn.Conv2d(out_channels, out_channels, kernel_size=3,
                      padding=1, bias=False),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True),
        )

    def forward(
        self,
        bridge_feat: Tensor,
        stage_feats: List[Tensor],
        morph_prompt: Tensor,
        original_size: Tuple[int, int],
    ) -> Dict[str, Tensor]:
        """Decode multi-scale features into task-specific outputs.

        Parameters
        ----------
        bridge_feat : Tensor [B, bridge_channels, H_b, W_b]
            Fused bridge feature from CSIB (at Stage-1 resolution).
        stage_feats : list[Tensor]
            Four stage features [s1, s2, s3, s4] of decreasing resolution.
        morph_prompt : Tensor [B, prompt_dim]
            Morphological prompt vector from MPP.
        original_size : tuple[int, int]
            Target spatial resolution (H, W) to upsample to.

        Returns
        -------
        dict with keys:
            ``"seg_logits"``, ``"seg_prob"``,
            ``"edge_logits"``, ``"edge_prob"``,
            ``"sdm_pred"``, ``"uncertainty_map"``,
            ``"coarse_mask"``
        """
        s1, s2, s3, s4 = stage_feats
        H_orig, W_orig = original_size

        # Inject prompt into bridge feature.
        prompt_bias = self.prompt_proj(morph_prompt)             # [B, C_bridge]
        prompt_bias = prompt_bias.unsqueeze(-1).unsqueeze(-1)    # [B, C_bridge, 1, 1]
        bridge_feat = bridge_feat + prompt_bias

        # Upsample bridge to s3 resolution and concatenate with s3 skip.
        up43 = F.interpolate(bridge_feat, size=s3.shape[2:],
                             mode="bilinear", align_corners=False)
        d3 = self.up_block_43(torch.cat([up43, s3], dim=1))

        # Upsample d3 to s2 resolution.
        up32 = F.interpolate(d3, size=s2.shape[2:],
                             mode="bilinear", align_corners=False)
        d2 = self.up_block_32(torch.cat([up32, s2], dim=1))

        # Upsample d2 to s1 resolution.
        up21 = F.interpolate(d2, size=s1.shape[2:],
                             mode="bilinear", align_corners=False)
        d1 = self.up_block_21(torch.cat([up21, s1], dim=1))

        # Upsample d1 to full resolution.
        up10 = F.interpolate(d1, size=(H_orig, W_orig),
                             mode="bilinear", align_corners=False)
        d0 = self.up_block_10(up10)
        d0 = self.dropout(d0)

        # --- Heads ---
        seg_logits = self.seg_head(d0)                           # [B, 1, H, W]
        seg_prob = torch.sigmoid(seg_logits)

        outputs: Dict[str, Tensor] = {
            "seg_logits": seg_logits,
            "seg_prob": seg_prob,
        }

        if self.use_edge_head:
            edge_logits = self.edge_head(d0)
            outputs["edge_logits"] = edge_logits
            outputs["edge_prob"] = torch.sigmoid(edge_logits)

        if self.use_sdm_head:
            sdm_pred = self.sdm_head(d0)
            outputs["sdm_pred"] = sdm_pred

        if self.use_uncertainty_head:
            uncertainty_map = self.uncertainty_head(d0)
            outputs["uncertainty_map"] = uncertainty_map

        # Coarse mask from bridge (used for consistency losses).
        coarse_mask = self.coarse_head(bridge_feat)
        coarse_mask = F.interpolate(coarse_mask, size=(H_orig, W_orig),
                                    mode="bilinear", align_corners=False)
        outputs["coarse_mask"] = torch.sigmoid(coarse_mask)

        return outputs


# ---------------------------------------------------------------------------
# DGBC_MTLNet -- Main Multi-Task Network
# ---------------------------------------------------------------------------

class DGBC_MTLNet(nn.Module):
    """Complete multi-task diagnosis network for breast ultrasound.

    Orchestrates the full pipeline::

        image -> LABDG-Pre -> DGBCEncoder -> MPP -> BoundaryRegionDecoder -> outputs

    Output dictionary keys (all tensors share the original input resolution):

    * ``seg_logits``     -- raw segmentation logits          [B, 1, H, W]
    * ``seg_prob``       -- sigmoid segmentation probability [B, 1, H, W]
    * ``edge_logits``    -- edge prediction logits           [B, 1, H, W]
    * ``edge_prob``      -- sigmoid edge probability         [B, 1, H, W]
    * ``sdm_pred``       -- signed distance map prediction   [B, 1, H, W]
    * ``uncertainty_map`` -- aleatoric uncertainty map       [B, 1, H, W]
    * ``coarse_mask``    -- coarse segmentation from bridge  [B, 1, H, W]
    * ``morph_prompt``   -- morphological prompt vector      [B, prompt_dim]
    * ``challenge_vector"`` -- data difficulty vector        [B, challenge_dim]
    * ``aux_maps``       -- auxiliary outputs from LABDG-Pre (dict)

    Parameters
    ----------
    config : Config
        Application configuration object.  Reads from ``config.model``:

        * ``raw_input_channels`` (int, default 1)
        * ``pre_channels`` (int, default 16)
        * ``encoder_channels`` (list[int], default [64, 128, 256, 512])
        * ``prompt_dim`` (int, default 128)
        * ``challenge_dim`` (int, default 8)
        * ``use_mamba`` (bool, default True)
        * ``use_mpp`` (bool, default True)
        * ``use_edge_head`` (bool, default True)
        * ``use_sdm_head`` (bool, default True)
        * ``use_uncertainty_head`` (bool, default True)
        * ``dropout`` (float, default 0.2)
    """

    def __init__(self, config):
        super().__init__()

        model_cfg = config.model
        self.raw_input_channels: int = getattr(model_cfg, "raw_input_channels", 1)
        self.pre_channels: int = getattr(model_cfg, "pre_channels", 16)
        self.prompt_dim: int = getattr(model_cfg, "prompt_dim", 128)
        self.challenge_dim: int = getattr(model_cfg, "challenge_dim", 8)
        self.use_mpp: bool = getattr(model_cfg, "use_mpp", True)
        self.dropout: float = getattr(model_cfg, "dropout", 0.2)

        # 1. LABDG-Pre
        self.labdg_pre = LABDGPre(
            raw_input_channels=self.raw_input_channels,
            pre_channels=self.pre_channels,
            dropout=self.dropout,
        )

        # 2. Encoder
        self.encoder = DGBCEncoder(config)

        # 3. Morphology Proxy Prompt
        if self.use_mpp:
            self.mpp = MorphologyProxyPrompt(
                pre_channels=self.pre_channels,
                stage_channels=self.encoder.stage_out_channels,
                prompt_dim=self.prompt_dim,
                challenge_dim=self.challenge_dim,
                dropout=self.dropout,
            )
        else:
            self.mpp = None

        # 4. Decoder
        self.decoder = BoundaryRegionDecoder(
            bridge_channels=self.encoder.bridge_channels,
            stage_channels=self.encoder.stage_out_channels,
            prompt_dim=self.prompt_dim,
            use_edge_head=getattr(model_cfg, "use_edge_head", True),
            use_sdm_head=getattr(model_cfg, "use_sdm_head", True),
            use_uncertainty_head=getattr(model_cfg, "use_uncertainty_head", True),
            dropout=self.dropout,
        )

        # 5. MPTC-Head (Classification)
        from .mptc_head import MPTCHead
        self.mptc_head = MPTCHead(config)

        logger.info(
            "DGBC_MTLNet initialised: raw_in=%d, pre=%d, prompt=%d, "
            "challenge=%d, mpp=%s, encoder_channels=%s",
            self.raw_input_channels, self.pre_channels, self.prompt_dim,
            self.challenge_dim, self.use_mpp, self.encoder.stage_out_channels,
        )

    def forward(
        self,
        image: Tensor,
        mask: Optional[Tensor] = None,
        edge: Optional[Tensor] = None,
        sdm: Optional[Tensor] = None,
        label: Optional[Tensor] = None,
        meta: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Full forward pass through the multi-task pipeline.

        Parameters
        ----------
        image : Tensor [B, 1, H, W]
            Raw grayscale breast ultrasound image.
        mask : Tensor [B, 1, H, W], optional
            Ground-truth segmentation mask (training only).
        edge : Tensor [B, 1, H, W], optional
            Ground-truth edge map (training only).
        sdm : Tensor [B, 1, H, W], optional
            Ground-truth signed distance map (training only).
        label : Tensor [B], optional
            Ground-truth classification label (training only).
        meta : dict, optional
            Sample metadata (e.g. device domain identifier).

        Returns
        -------
        dict
            Output dictionary containing all prediction maps and auxiliary
            information.  Ground-truth tensors are passed through unchanged
            (when provided) for convenience in loss computation.
        """
        B, _, H, W = image.shape

        # 1. LABDG-Pre: domain-aware preprocessing.
        z_pre, pre_aux_maps = self.labdg_pre(image, meta=meta)

        # 2. Encoder: multi-scale feature extraction.
        bridge_feat, stage_feats = self.encoder(z_pre)

        # 3. MPP: morphological prompt generation.
        if self.use_mpp and self.mpp is not None:
            morph_prompt, challenge_vec = self.mpp(pre_aux_maps, stage_feats)
        else:
            # Fallback: zero vectors.
            device = image.device
            morph_prompt = torch.zeros(B, self.prompt_dim, device=device)
            challenge_vec = torch.zeros(B, self.challenge_dim, device=device)

        # 4. Decoder: multi-head prediction.
        decoder_out = self.decoder(
            bridge_feat, stage_feats, morph_prompt,
            original_size=(H, W),
        )

        # 5. MPTC-Head: four-stream classification
        cls_logits, cls_prob = self.mptc_head(
            encoder_features=stage_feats,
            seg_prob=decoder_out["seg_prob"],
            edge_prob=decoder_out.get("edge_prob"),
            sdm_pred=decoder_out.get("sdm_pred"),
            uncertainty_map=decoder_out.get("uncertainty_map"),
            morph_prompt=morph_prompt,
            z_pre=z_pre,
            aux_maps=pre_aux_maps,
        )

        # Assemble outputs.
        outputs: Dict[str, Any] = {
            "cls_logits": cls_logits,
            "cls_prob": cls_prob,
            "seg_logits": decoder_out["seg_logits"],
            "seg_prob": decoder_out["seg_prob"],
            "edge_logits": decoder_out.get("edge_logits"),
            "edge_prob": decoder_out.get("edge_prob"),
            "sdm_pred": decoder_out.get("sdm_pred"),
            "uncertainty_map": decoder_out.get("uncertainty_map"),
            "coarse_mask": decoder_out["coarse_mask"],
            "morph_prompt": morph_prompt,
            "challenge_vector": challenge_vec,
            "aux_maps": pre_aux_maps,
        }

        # Pass through ground-truth when provided (for loss computation).
        if mask is not None:
            outputs["mask"] = mask
        if edge is not None:
            outputs["edge"] = edge
        if sdm is not None:
            outputs["sdm"] = sdm
        if label is not None:
            outputs["label"] = label

        return outputs
