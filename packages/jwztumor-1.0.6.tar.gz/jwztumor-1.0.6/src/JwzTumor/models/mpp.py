"""
MorphologyProxyPrompt (MPP)
============================
Estimates morphological properties from LABDG-Pre auxiliary maps and encoder
features, producing a learned prompt vector and a challenge vector that
characterize lesion difficulty.

Used by:
    - BoundaryRegionDecoder (FiLM conditioning via morph_prompt)
    - MPTCHead (concatenated with stream features before classification)

Config keys consumed (``config.model``):
    - prompt_dim    -- output dimension of the morphological prompt (default 128)
    - challenge_dim -- output dimension of the challenge vector (default 8)
"""
from typing import Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F

import logging

logger = logging.getLogger(__name__)

# Number of raw statistics extracted from the auxiliary maps.
_NUM_RAW_STATS = 6  # area_ratio, center_x, center_y, edge_density,
                     # mean_texture, mean_attenuation


class MorphologyProxyPrompt(nn.Module):
    """Compute a morphology prompt and difficulty challenge vector from
    LABDG-Pre auxiliary maps.

    The module extracts six lightweight statistics from the pre-network's
    auxiliary outputs (coarse mask, edge map, texture map, attenuation map),
    passes them through an MLP to produce ``morph_prompt``, and through a
    second MLP branch to produce ``challenge_vector``.

    Args:
        config: A :class:`Config` object.  The relevant sub-config is
            ``config.model`` which must expose ``prompt_dim`` and
            ``challenge_dim`` attributes.

    Shape:
        - pre_aux_maps: dict with keys ``coarse_mask``, ``edge_map``,
          ``texture``, ``attenuation``, each a Tensor of shape ``[B, 1, H, W]``.
        - encoder_features: list of Tensors from the encoder (used only for
          shape inference in this MVP version).
        - Output: ``(morph_prompt [B, prompt_dim], challenge_vector [B, challenge_dim])``
    """

    def __init__(self, config):
        super().__init__()

        model_cfg = config.model
        self.prompt_dim: int = getattr(model_cfg, "prompt_dim", 128)
        self.challenge_dim: int = getattr(model_cfg, "challenge_dim", 8)

        hidden_dim = max(32, (self.prompt_dim + _NUM_RAW_STATS) // 2)

        # --- MLP: raw stats -> morph_prompt ---
        self.prompt_mlp = nn.Sequential(
            nn.Linear(_NUM_RAW_STATS, hidden_dim),
            nn.ReLU(inplace=True),
            nn.Linear(hidden_dim, self.prompt_dim),
        )

        # --- MLP branch: raw stats -> challenge_vector ---
        self.challenge_mlp = nn.Sequential(
            nn.Linear(_NUM_RAW_STATS, hidden_dim),
            nn.ReLU(inplace=True),
            nn.Linear(hidden_dim, self.challenge_dim),
        )

        self._reset_parameters()

    # -----------------------------------------------------------------
    # Initialisation
    # -----------------------------------------------------------------

    def _reset_parameters(self) -> None:
        """Initialize linear layers with Kaiming normal for ReLU networks."""
        for module in self.modules():
            if isinstance(module, nn.Linear):
                nn.init.kaiming_normal_(module.weight, nonlinearity="relu")
                if module.bias is not None:
                    nn.init.zeros_(module.bias)

    # -----------------------------------------------------------------
    # Statistic extraction helpers
    # -----------------------------------------------------------------

    @staticmethod
    def _extract_stats(
        coarse_mask: torch.Tensor,
        edge_map: torch.Tensor,
        texture: torch.Tensor,
        attenuation: torch.Tensor,
    ) -> torch.Tensor:
        """Extract six per-sample morphological statistics.

        All input tensors are expected to have shape ``[B, 1, H, W]``.
        Returns a Tensor of shape ``[B, 6]`` with columns:
            0. area_ratio   -- fraction of foreground pixels in the coarse mask.
            1. center_x     -- normalised x-centroid of the mask.
            2. center_y     -- normalised y-centroid of the mask.
            3. edge_density -- mean of the edge map (foreground region only).
            4. mean_texture -- mean intensity of the texture map.
            5. mean_attenuation -- mean intensity of the attenuation map.

        Args:
            coarse_mask:  Coarse segmentation mask from LABDG-Pre.
            edge_map:     Edge / boundary probability map from LABDG-Pre.
            texture:      Texture response map from LABDG-Pre.
            attenuation:  Attenuation / shadow map from LABDG-Pre.

        Returns:
            Tensor of shape ``[B, 6]``.
        """
        B, _, H, W = coarse_mask.shape

        # Guard against all-zero masks to avoid division by zero.
        eps = 1e-8

        # 0 -- area ratio
        area_ratio = coarse_mask.mean(dim=(1, 2, 3))  # [B]

        # 1, 2 -- normalised centroid
        y_grid = torch.linspace(0.0, 1.0, H, device=coarse_mask.device, dtype=coarse_mask.dtype)
        x_grid = torch.linspace(0.0, 1.0, W, device=coarse_mask.device, dtype=coarse_mask.dtype)
        grid_y, grid_x = torch.meshgrid(y_grid, x_grid, indexing="ij")  # [H, W]

        mask_sum = coarse_mask[:, 0].sum(dim=(1, 2)).clamp(min=eps)  # [B]
        center_y = (coarse_mask[:, 0] * grid_y.unsqueeze(0)).sum(dim=(1, 2)) / mask_sum  # [B]
        center_x = (coarse_mask[:, 0] * grid_x.unsqueeze(0)).sum(dim=(1, 2)) / mask_sum  # [B]

        # 3 -- edge density (within masked region or global fallback)
        foreground = (coarse_mask[:, 0] > 0.5).float()
        fg_pixel_count = foreground.sum(dim=(1, 2)).clamp(min=eps)
        edge_density = (edge_map[:, 0] * foreground).sum(dim=(1, 2)) / fg_pixel_count  # [B]

        # 4 -- mean texture
        mean_texture = texture.mean(dim=(1, 2, 3))  # [B]

        # 5 -- mean attenuation
        mean_attenuation = attenuation.mean(dim=(1, 2, 3))  # [B]

        stats = torch.stack(
            [area_ratio, center_x, center_y, edge_density, mean_texture, mean_attenuation],
            dim=1,
        )  # [B, 6]

        # Replace NaN / Inf from edge cases with zeros.
        stats = torch.nan_to_num(stats, nan=0.0, posinf=1.0, neginf=0.0)

        return stats

    # -----------------------------------------------------------------
    # Forward
    # -----------------------------------------------------------------

    def forward(
        self,
        pre_aux_maps: dict,
        encoder_features: list,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """Produce morphology prompt and challenge vector.

        Args:
            pre_aux_maps: Dictionary of auxiliary maps from LABDG-Pre.
                Expected keys: ``"coarse_mask"``, ``"edge_map"``,
                ``"texture"``, ``"attenuation"``.  Each value is a
                ``[B, 1, H, W]`` float tensor.
            encoder_features: List of encoder feature maps (accepted but
                not used in this MVP implementation).

        Returns:
            A tuple of:

            - **morph_prompt** -- Tensor ``[B, prompt_dim]``, the learned
              morphological representation.
            - **challenge_vector** -- Tensor ``[B, challenge_dim]``,
              a compact encoding of lesion difficulty.
        """
        coarse_mask = pre_aux_maps.get("coarse_mask")
        edge_map = pre_aux_maps.get("edge_map")
        texture = pre_aux_maps.get("texture")
        attenuation = pre_aux_maps.get("attenuation")

        # Build fallback zero tensors when a key is missing.
        if coarse_mask is None:
            raise ValueError("pre_aux_maps must contain 'coarse_map' key")
        device = coarse_mask.device
        B = coarse_mask.shape[0]
        H, W = coarse_mask.shape[2], coarse_mask.shape[3]
        zeros = coarse_mask.new_zeros(B, 1, H, W)

        edge_map = edge_map if edge_map is not None else zeros
        texture = texture if texture is not None else zeros
        attenuation = attenuation if attenuation is not None else zeros

        stats = self._extract_stats(coarse_mask, edge_map, texture, attenuation)  # [B, 6]

        morph_prompt = self.prompt_mlp(stats)       # [B, prompt_dim]
        challenge_vector = self.challenge_mlp(stats)  # [B, challenge_dim]

        return morph_prompt, challenge_vector
