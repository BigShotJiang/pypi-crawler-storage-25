"""
LABDG Preprocessor -- Learnable Preprocessing Frontend
======================================================
Generates structured priors (z_pre) and auxiliary maps from raw breast
ultrasound images.  This is the MVP version with simplified but
shape-correct implementations for every map.

Outputs
-------
z_pre : Tensor [B, pre_channels, H, W]
    Compressed representation passed to the downstream encoder.

aux_maps : dict with the following 10 keys, each [B, 1, H, W]
    raw_view       -- identity pass-through of the input
    enhanced_view  -- shallow 3x3 conv + ReLU enhancement
    coarse_mask    -- rough lesion probability (sigmoid)
    center_heatmap -- centre-of-lesion heatmap (sigmoid)
    scale_map      -- normalised scale estimate (sigmoid)
    artifact_mask  -- artefact probability or zero placeholder
    edge           -- Sobel-like gradient magnitude on enhanced_view
    speckle        -- local variance of the raw input
    texture        -- texture energy (mean of squared local patches)
    attenuation    -- column-wise average projection (simulating
                      posterior attenuation)
"""

import logging
from typing import Dict, Optional, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F

logger = logging.getLogger(__name__)

__all__ = ["LABDGPreprocessor"]


# ---------------------------------------------------------------------------
# Utility helpers (module-level so they are easily testable)
# ---------------------------------------------------------------------------

def _sobel_gradient(x: torch.Tensor) -> torch.Tensor:
    """Compute gradient magnitude using 3x3 Sobel-like kernels.

    Args:
        x: Tensor of shape [B, 1, H, W].

    Returns:
        Gradient magnitude [B, 1, H, W].
    """
    # Sobel kernels -- central-difference gradient approximators
    sobel_x = torch.tensor(
        [[-1, 0, 1], [-2, 0, 2], [-1, 0, 1]],
        dtype=x.dtype,
        device=x.device,
    ).reshape(1, 1, 3, 3)

    sobel_y = torch.tensor(
        [[-1, -2, -1], [0, 0, 0], [1, 2, 1]],
        dtype=x.dtype,
        device=x.device,
    ).reshape(1, 1, 3, 3)

    gx = F.conv2d(x, sobel_x, padding=1)
    gy = F.conv2d(x, sobel_y, padding=1)
    return torch.sqrt(gx * gx + gy * gy + 1e-8)


def _local_variance(x: torch.Tensor, kernel_size: int = 5) -> torch.Tensor:
    """Estimate local variance (speckle proxy) via the identity
    Var(X) = E[X^2] - E[X]^2 computed with average pooling.

    Args:
        x: Tensor [B, 1, H, W].
        kernel_size: Side length of the averaging window.

    Returns:
        Local variance [B, 1, H, W].
    """
    pad = kernel_size // 2
    x_sq = x * x
    mean_x = F.avg_pool2d(x, kernel_size, stride=1, padding=pad)
    mean_xsq = F.avg_pool2d(x_sq, kernel_size, stride=1, padding=pad)
    var = mean_xsq - mean_x * mean_x
    return var.clamp(min=0.0)


def _texture_energy(x: torch.Tensor, kernel_size: int = 7) -> torch.Tensor:
    """Compute texture energy as the mean of squared values in a local
    neighbourhood (Law's texture energy inspired).

    Args:
        x: Tensor [B, 1, H, W].
        kernel_size: Side length of the averaging window.

    Returns:
        Texture energy map [B, 1, H, W].
    """
    pad = kernel_size // 2
    x_sq = x * x
    energy = F.avg_pool2d(x_sq, kernel_size, stride=1, padding=pad)
    return energy


def _column_attenuation(x: torch.Tensor) -> torch.Tensor:
    """Simulate posterior acoustic attenuation by column-wise (vertical)
    average projection broadcast across rows.

    For each column, the attenuation estimate is the running average from
    top to bottom, which approximates the cumulative signal loss with depth.

    Args:
        x: Tensor [B, 1, H, W].

    Returns:
        Attenuation map [B, 1, H, W].
    """
    # Cumulative mean along height dimension (dim=2)
    B, C, H, W = x.shape
    cumsum = torch.cumsum(x, dim=2)
    arange_h = torch.arange(1, H + 1, dtype=x.dtype, device=x.device)
    arange_h = arange_h.view(1, 1, H, 1)
    cummean = cumsum / arange_h
    return cummean


# ---------------------------------------------------------------------------
# Shallow Convolutional Head (reused for several outputs)
# ---------------------------------------------------------------------------

class _ShallowConvHead(nn.Module):
    """Two-layer shallow convolution producing a single-channel map with
    sigmoid activation.  Used for coarse_mask, center_heatmap, scale_map,
    and (optionally) artifact_mask."""

    def __init__(self, in_channels: int, mid_channels: int = 8):
        super().__init__()
        self.conv = nn.Sequential(
            nn.Conv2d(in_channels, mid_channels, kernel_size=3, padding=1, bias=False),
            nn.BatchNorm2d(mid_channels),
            nn.ReLU(inplace=True),
            nn.Conv2d(mid_channels, 1, kernel_size=1, bias=True),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """Returns sigmoid-activated single-channel map [B, 1, H, W]."""
        return torch.sigmoid(self.conv(x))


# ---------------------------------------------------------------------------
# LABDGPreprocessor
# ---------------------------------------------------------------------------

class LABDGPreprocessor(nn.Module):
    """Learnable preprocessing frontend for breast ultrasound images.

    Takes a raw grayscale image tensor and produces:
      * ``z_pre`` -- a compressed multi-channel prior for the encoder.
      * ``aux_maps`` -- a dict of 10 single-channel auxiliary maps used
        by downstream supervision and visualisation.

    Args:
        config: Configuration object with the following attributes
            (defaults from :class:`ModelConfig`):
            - ``model.pre_channels``          (int, default 16)
            - ``model.raw_input_channels``     (int, default 1)
            - ``model.use_artifact_head``      (bool, default True)
            - ``model.use_center_scale_head``  (bool, default True)
    """

    AUX_MAP_KEYS: Tuple[str, ...] = (
        "raw_view",
        "enhanced_view",
        "coarse_mask",
        "center_heatmap",
        "scale_map",
        "artifact_mask",
        "edge",
        "speckle",
        "texture",
        "attenuation",
    )
    """Canonical key set for the auxiliary maps dictionary."""

    def __init__(self, config):
        super().__init__()

        model_cfg = config.model
        self.pre_channels: int = getattr(model_cfg, "pre_channels", 16)
        self.raw_input_channels: int = getattr(model_cfg, "raw_input_channels", 1)
        self.use_artifact_head: bool = getattr(model_cfg, "use_artifact_head", True)
        self.use_center_scale_head: bool = getattr(model_cfg, "use_center_scale_head", True)

        in_ch = self.raw_input_channels  # typically 1

        # -- enhanced_view: shallow 3x3 conv + ReLU ----------------------
        self.enhance_conv = nn.Sequential(
            nn.Conv2d(in_ch, 8, kernel_size=3, padding=1, bias=False),
            nn.BatchNorm2d(8),
            nn.ReLU(inplace=True),
            nn.Conv2d(8, 1, kernel_size=3, padding=1, bias=True),
        )

        # -- coarse_mask -------------------------------------------------
        self.coarse_head = _ShallowConvHead(in_ch, mid_channels=8)

        # -- center_heatmap & scale_map (optional) -----------------------
        if self.use_center_scale_head:
            self.center_head = _ShallowConvHead(in_ch, mid_channels=8)
            self.scale_head = _ShallowConvHead(in_ch, mid_channels=8)
        else:
            # Create trivial modules so forward() doesn't need branching
            self.center_head = None
            self.scale_head = None

        # -- artifact_mask (optional) ------------------------------------
        if self.use_artifact_head:
            self.artifact_head = _ShallowConvHead(in_ch, mid_channels=4)
        else:
            self.artifact_head = None

        # -- z_pre compression -------------------------------------------
        # Concatenation of [raw_view(1), enhanced_view(1), edge(1),
        #                    speckle(1), texture(1), attenuation(1),
        #                    coarse_mask(1)] = 7 channels
        self.compress_in_channels: int = 7
        self.compress = nn.Sequential(
            nn.Conv2d(self.compress_in_channels, self.pre_channels,
                      kernel_size=1, bias=False),
            nn.BatchNorm2d(self.pre_channels),
            nn.ReLU(inplace=True),
        )

        logger.info(
            "LABDGPreprocessor initialised -- pre_channels=%d, "
            "artifact_head=%s, center_scale_head=%s",
            self.pre_channels,
            self.use_artifact_head,
            self.use_center_scale_head,
        )

    # ------------------------------------------------------------------
    # Forward
    # ------------------------------------------------------------------

    def forward(
        self,
        image: torch.Tensor,
        meta: Optional[Dict] = None,
    ) -> Tuple[torch.Tensor, Dict[str, torch.Tensor]]:
        """Run the learnable preprocessing frontend.

        Args:
            image: Raw input tensor [B, 1, H, W] (grayscale, normalised
                to approximately [0, 1]).
            meta: Optional metadata dict (reserved for future use, e.g.
                domain labels or scan parameters).

        Returns:
            Tuple of:
              - z_pre: Tensor [B, pre_channels, H, W]
              - aux_maps: dict mapping each of the 10 canonical keys to
                a tensor of shape [B, 1, H, W].
        """
        _ = meta  # reserved for future use

        B, C, H, W = image.shape

        # ---- 1. raw_view (identity) ------------------------------------
        raw_view = image

        # ---- 2. enhanced_view ------------------------------------------
        enhanced_view = self.enhance_conv(raw_view)

        # ---- 3. coarse_mask --------------------------------------------
        coarse_mask = self.coarse_head(raw_view)

        # ---- 4. center_heatmap -----------------------------------------
        if self.center_head is not None:
            center_heatmap = self.center_head(raw_view)
        else:
            center_heatmap = torch.zeros(B, 1, H, W, device=image.device,
                                         dtype=image.dtype)

        # ---- 5. scale_map ----------------------------------------------
        if self.scale_head is not None:
            scale_map = self.scale_head(raw_view)
        else:
            scale_map = torch.ones(B, 1, H, W, device=image.device,
                                   dtype=image.dtype) * 0.5

        # ---- 6. artifact_mask ------------------------------------------
        if self.artifact_head is not None:
            artifact_mask = self.artifact_head(raw_view)
        else:
            artifact_mask = torch.zeros(B, 1, H, W, device=image.device,
                                        dtype=image.dtype)

        # ---- 7. G_edge -- Sobel gradient on enhanced_view --------------
        edge = _sobel_gradient(enhanced_view)

        # ---- 8. V_speckle -- local variance of input -------------------
        speckle = _local_variance(raw_view)

        # ---- 9. T_tex -- texture energy --------------------------------
        texture = _texture_energy(raw_view)

        # ---- 10. A_depth -- column-wise attenuation --------------------
        attenuation = _column_attenuation(raw_view)

        # ---- Assemble aux_maps -----------------------------------------
        aux_maps: Dict[str, torch.Tensor] = {
            "raw_view": raw_view,
            "enhanced_view": enhanced_view,
            "coarse_mask": coarse_mask,
            "center_heatmap": center_heatmap,
            "scale_map": scale_map,
            "artifact_mask": artifact_mask,
            "edge": edge,
            "speckle": speckle,
            "texture": texture,
            "attenuation": attenuation,
        }

        # ---- z_pre: 1x1 compression from concatenated maps -------------
        concat_features = torch.cat([
            raw_view,
            enhanced_view,
            edge,
            speckle,
            texture,
            attenuation,
            coarse_mask,
        ], dim=1)  # [B, 7, H, W]

        z_pre = self.compress(concat_features)  # [B, pre_channels, H, W]

        return z_pre, aux_maps
