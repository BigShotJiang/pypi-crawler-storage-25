"""
DGBCEncoder -- CNN-Mamba Hybrid Multi-Scale Encoder
====================================================

A four-stage encoder that progressively downsamples the input feature map
while extracting multi-scale representations.  The first two stages use
standard residual convolution blocks, while the latter two stages employ a
lightweight Mamba-like selective-scan approximation (Conv1d-based attention).

A Cross-Scale Interaction Bridge (CSIB) fuses all four stage outputs into a
unified bridge feature for downstream decoding.

Typical usage::

    encoder = DGBCEncoder(config)
    bridge_feat, stage_feats = encoder(z_pre)   # z_pre: [B, C_in, H, W]

References
----------
The Mamba-like block is a lightweight approximation inspired by:
    Gu, A. & Dao, T. "Mamba: Linear-Time Sequence Modeling with
    Selective State Spaces", arXiv:2312.00752, 2023.
"""

from __future__ import annotations

import logging
from typing import List, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch import Tensor

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Residual Convolution Block
# ---------------------------------------------------------------------------

class ResidualConvBlock(nn.Module):
    """Two-conv residual block with BatchNorm and ReLU.

    Architecture::

        input --> Conv3x3 --> BN --> ReLU --> Conv3x3 --> BN --> (+input) --> ReLU

    Parameters
    ----------
    in_channels : int
        Number of input channels.
    out_channels : int
        Number of output channels.
    stride : int
        Stride for the first convolution (spatial downsampling).
    """

    def __init__(self, in_channels: int, out_channels: int, stride: int = 1):
        super().__init__()
        self.conv1 = nn.Conv2d(
            in_channels, out_channels, kernel_size=3,
            stride=stride, padding=1, bias=False,
        )
        self.bn1 = nn.BatchNorm2d(out_channels)
        self.conv2 = nn.Conv2d(
            out_channels, out_channels, kernel_size=3,
            stride=1, padding=1, bias=False,
        )
        self.bn2 = nn.BatchNorm2d(out_channels)
        self.relu = nn.ReLU(inplace=True)

        # Skip connection: 1x1 conv to match channels/stride when needed.
        self.skip = nn.Identity()
        if stride != 1 or in_channels != out_channels:
            self.skip = nn.Sequential(
                nn.Conv2d(in_channels, out_channels, kernel_size=1,
                          stride=stride, bias=False),
                nn.BatchNorm2d(out_channels),
            )

    def forward(self, x: Tensor) -> Tensor:
        identity = self.skip(x)
        out = self.relu(self.bn1(self.conv1(x)))
        out = self.bn2(self.conv2(out))
        out = self.relu(out + identity)
        return out


# ---------------------------------------------------------------------------
# Lightweight Mamba-like Block
# ---------------------------------------------------------------------------

class LightweightMambaBlock(nn.Module):
    """Lightweight Mamba-like selective-scan approximation using Conv1d.

    This is **not** a full Mamba implementation.  Instead it uses a
    local-global attention mechanism built from depthwise Conv1d to approximate
    the selective-scan behaviour at a fraction of the compute cost.

    The input spatial map is treated as a 1-D sequence along the height axis
    (after height-first flattening of the width dimension).

    Parameters
    ----------
    channels : int
        Number of input/output channels.
    stride : int
        Spatial stride applied via an initial strided convolution.
    seq_expand_ratio : float
        Expansion ratio for the internal sequential hidden dimension.
    """

    def __init__(
        self,
        channels: int,
        stride: int = 1,
        seq_expand_ratio: float = 2.0,
    ):
        super().__init__()
        self.channels = channels
        hidden_dim = int(channels * seq_expand_ratio)

        # Stride downsampling via 3x3 conv when stride > 1.
        if stride > 1:
            self.downsample = nn.Conv2d(
                channels, channels, kernel_size=3,
                stride=stride, padding=1, bias=False,
            )
        else:
            self.downsample = nn.Identity()

        # Input projection.
        self.in_proj = nn.Linear(channels, hidden_dim)

        # Selective-scan approximation: depthwise Conv1d for local context.
        self.dw_conv_local = nn.Conv1d(
            hidden_dim, hidden_dim, kernel_size=5,
            padding=2, groups=hidden_dim, bias=True,
        )

        # Gate projection (similar to Mamba's selective gate).
        self.gate_proj = nn.Linear(hidden_dim, hidden_dim)

        # Output projection.
        self.out_proj = nn.Linear(hidden_dim, channels)

        # Layer norms.
        self.norm = nn.LayerNorm(channels)
        self.norm_out = nn.LayerNorm(channels)

    def forward(self, x: Tensor) -> Tensor:
        """Forward pass.

        Parameters
        ----------
        x : Tensor [B, C, H, W]

        Returns
        -------
        Tensor [B, C, H', W']  (H' = H // stride, W' = W // stride)
        """
        B, C, H, W = x.shape

        # Optional spatial downsample.
        x = self.downsample(x)
        _, _, Hd, Wd = x.shape

        # Residual branch.
        residual = x

        # Normalise.
        x = x.permute(0, 2, 3, 1)            # [B, Hd, Wd, C]
        x = self.norm(x)
        x = x.reshape(B, Hd * Wd, C)         # [B, Hd*Wd, C]

        # Input projection -> hidden dim.
        x = self.in_proj(x)                   # [B, L, hidden]

        # Selective-scan approximation via 1-D local convolution.
        x = x.transpose(1, 2)                 # [B, hidden, L]
        x = self.dw_conv_local(x)             # local context
        x = F.silu(x)

        # Gate.
        x = x.transpose(1, 2)                 # [B, L, hidden]
        gate = torch.sigmoid(self.gate_proj(x))
        x = x * gate

        # Output projection.
        x = self.out_proj(x)                  # [B, L, C]

        # Reshape back.
        x = x.reshape(B, Hd, Wd, self.channels)
        x = self.norm_out(x)
        x = x.permute(0, 3, 1, 2)             # [B, C, Hd, Wd]

        return x + residual


# ---------------------------------------------------------------------------
# Cross-Scale Interaction Bridge (CSIB)
# ---------------------------------------------------------------------------

class CrossScaleInteractionBridge(nn.Module):
    """Fuse multi-scale stage features into a single bridge representation.

    Each stage feature is projected to ``bridge_channels`` via a 1x1 conv,
    upsampled to the *largest* (i.e. Stage-1) spatial resolution, and summed.
    A final 3x3 conv refines the fused feature.

    Parameters
    ----------
    stage_channels : list[int]
        Channel counts for each stage (e.g. ``[64, 128, 256, 512]``).
    bridge_channels : int
        Common channel dimension used for fusion.
    """

    def __init__(self, stage_channels: List[int], bridge_channels: int = 256):
        super().__init__()
        self.bridge_channels = bridge_channels

        # Per-stage 1x1 projection.
        self.projections = nn.ModuleList([
            nn.Sequential(
                nn.Conv2d(c, bridge_channels, kernel_size=1, bias=False),
                nn.BatchNorm2d(bridge_channels),
                nn.ReLU(inplace=True),
            )
            for c in stage_channels
        ])

        # Refinement conv.
        self.refine = nn.Sequential(
            nn.Conv2d(bridge_channels, bridge_channels, kernel_size=3,
                      padding=1, bias=False),
            nn.BatchNorm2d(bridge_channels),
            nn.ReLU(inplace=True),
        )

    def forward(self, stage_feats: List[Tensor]) -> Tensor:
        """Fuse stage features.

        Parameters
        ----------
        stage_feats : list[Tensor]
            Four tensors of decreasing spatial resolution.

        Returns
        -------
        Tensor [B, bridge_channels, H_s1, W_s1]
        """
        target_h, target_w = stage_feats[0].shape[2], stage_feats[0].shape[3]
        fused = None
        for feat, proj in zip(stage_feats, self.projections):
            p = proj(feat)
            if p.shape[2] != target_h or p.shape[3] != target_w:
                p = F.interpolate(
                    p, size=(target_h, target_w),
                    mode="bilinear", align_corners=False,
                )
            fused = p if fused is None else fused + p
        return self.refine(fused)


# ---------------------------------------------------------------------------
# DGBCEncoder
# ---------------------------------------------------------------------------

class DGBCEncoder(nn.Module):
    """CNN-Mamba hybrid multi-scale encoder (DGBCEncoder).

    The encoder processes an input feature map ``z_pre`` through four stages:

    * **Stage 1** -- :class:`ResidualConvBlock` -> C=64,  stride=2
    * **Stage 2** -- :class:`ResidualConvBlock` -> C=128, stride=2
    * **Stage 3** -- :class:`LightweightMambaBlock` -> C=256, stride=2
    * **Stage 4** -- :class:`LightweightMambaBlock` -> C=512, stride=2

    After the four stages, a :class:`CrossScaleInteractionBridge` fuses all
    stage features into a unified bridge representation.

    Parameters
    ----------
    config : Config
        Application configuration object.  The following fields are read
        from ``config.model``:

        * ``encoder_input_channels`` (int, default 16)
        * ``encoder_channels`` (list[int], default ``[64, 128, 256, 512]``)
        * ``use_mamba`` (bool, default True)
        * ``mamba_impl`` (str, default ``"mamba_like"``)
    """

    _DEFAULT_CHANNELS = [64, 128, 256, 512]

    def __init__(self, config):
        super().__init__()

        model_cfg = config.model
        self.in_channels: int = getattr(model_cfg, "encoder_input_channels", 16)
        self.channels: List[int] = list(
            getattr(model_cfg, "encoder_channels", self._DEFAULT_CHANNELS)
        )
        self.use_mamba: bool = getattr(model_cfg, "use_mamba", True)
        self.mamba_impl: str = getattr(model_cfg, "mamba_impl", "mamba_like")

        assert len(self.channels) == 4, (
            f"encoder_channels must have 4 elements, got {len(self.channels)}"
        )

        c1, c2, c3, c4 = self.channels

        # Stage 1: ResidualConvBlock
        self.stage1 = ResidualConvBlock(self.in_channels, c1, stride=2)

        # Stage 2: ResidualConvBlock
        self.stage2 = ResidualConvBlock(c1, c2, stride=2)

        # Stage 3 & 4: Mamba-like or fallback ResidualConvBlock
        if self.use_mamba:
            self.stage3 = LightweightMambaBlock(c2, stride=2)
            # The LightweightMambaBlock keeps channels unchanged internally,
            # so we project c2 -> c3 before entering stage 4.
            self.stage3_proj = nn.Sequential(
                nn.Conv2d(c2, c3, kernel_size=1, bias=False),
                nn.BatchNorm2d(c3),
                nn.ReLU(inplace=True),
            )
            self.stage4 = LightweightMambaBlock(c3, stride=2)
            self.stage4_proj = nn.Sequential(
                nn.Conv2d(c3, c4, kernel_size=1, bias=False),
                nn.BatchNorm2d(c4),
                nn.ReLU(inplace=True),
            )
        else:
            self.stage3 = ResidualConvBlock(c2, c3, stride=2)
            self.stage3_proj = nn.Identity()
            self.stage4 = ResidualConvBlock(c3, c4, stride=2)
            self.stage4_proj = nn.Identity()

        # Stage 3 has a channel output of c3 after projection; we need to
        # record the actual channel counts for the bridge.
        stage_out_channels = [
            c1,
            c2,
            c3,  # after stage3_proj
            c4,  # after stage4_proj
        ]

        # Cross-Scale Interaction Bridge
        bridge_channels = c3  # use the third-stage channel count as bridge dim
        self.csib = CrossScaleInteractionBridge(stage_out_channels, bridge_channels)

        self._bridge_channels = bridge_channels
        self._stage_out_channels = stage_out_channels

        logger.info(
            "DGBCEncoder initialised: in=%d, channels=%s, mamba=%s, impl=%s",
            self.in_channels, self.channels, self.use_mamba, self.mamba_impl,
        )

    @property
    def bridge_channels(self) -> int:
        """Channel dimension of the fused bridge feature."""
        return self._bridge_channels

    @property
    def stage_out_channels(self) -> List[int]:
        """Output channel list for the four stages."""
        return list(self._stage_out_channels)

    def forward(
        self, z_pre: Tensor,
    ) -> Tuple[Tensor, List[Tensor]]:
        """Run the full encoder.

        Parameters
        ----------
        z_pre : Tensor [B, C_in, H, W]
            Pre-processed feature map (output of LABDG-Pre).

        Returns
        -------
        bridge_feat : Tensor [B, bridge_channels, H/2, W/2]
            Fused multi-scale bridge feature at the Stage-1 resolution.
        stage_feats : list[Tensor]
            Four feature maps of decreasing spatial resolution:

            * ``s1``  [B, 64,  H/2,  W/2]
            * ``s2``  [B, 128, H/4,  W/4]
            * ``s3``  [B, 256, H/8,  W/8]
            * ``s4``  [B, 512, H/16, W/16]
        """
        s1 = self.stage1(z_pre)
        s2 = self.stage2(s1)
        s3_raw = self.stage3(s2)
        s3 = self.stage3_proj(s3_raw)
        s4_raw = self.stage4(s3)
        s4 = self.stage4_proj(s4_raw)

        stage_feats = [s1, s2, s3, s4]
        bridge_feat = self.csib(stage_feats)

        return bridge_feat, stage_feats
