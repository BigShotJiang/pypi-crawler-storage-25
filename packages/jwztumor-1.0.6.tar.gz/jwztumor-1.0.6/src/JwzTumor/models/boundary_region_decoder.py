"""
BoundaryRegionDecoder
=====================
Region-boundary dual decoder with uncertainty head.

Takes the bridge feature (deepest encoder output) and a list of stage-wise
encoder features, upsamples them through two parallel branches (region and
boundary), and optionally produces edge, signed-distance-map (SDM), and
uncertainty predictions.

Morphological prompt conditioning is applied via FiLM (Feature-wise Linear
Modulation) layers at the mid-level of both branches.

Config keys consumed (``config.model``):
    - encoder_channels   -- list of channel counts per encoder stage
                            (default ``[64, 128, 256, 512]``)
    - prompt_dim         -- dimension of the morphology prompt vector
    - use_edge_head      -- whether to produce edge predictions
    - use_sdm_head       -- whether to produce SDM predictions
    - use_uncertainty_head -- whether to produce uncertainty predictions
"""
from typing import List, Optional, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F

import logging

logger = logging.getLogger(__name__)


# -----------------------------------------------------------------
# FiLM conditioning block
# -----------------------------------------------------------------

class FiLMLayer(nn.Module):
    """Feature-wise Linear Modulation: ``gamma * x + beta``.

    The modulation parameters (gamma, beta) are produced from a conditioning
    vector via a lightweight linear projection.

    Args:
        cond_dim:  Dimension of the conditioning vector.
        feat_dim:  Number of channels in the feature map to be modulated.
    """

    def __init__(self, cond_dim: int, feat_dim: int):
        super().__init__()
        self.gamma_fc = nn.Linear(cond_dim, feat_dim)
        self.beta_fc = nn.Linear(cond_dim, feat_dim)

    def forward(self, feat: torch.Tensor, cond: torch.Tensor) -> torch.Tensor:
        """Apply FiLM modulation.

        Args:
            feat: Feature map ``[B, C, H, W]``.
            cond: Conditioning vector ``[B, cond_dim]``.

        Returns:
            Modulated feature map ``[B, C, H, W]``.
        """
        gamma = self.gamma_fc(cond).unsqueeze(-1).unsqueeze(-1)  # [B, C, 1, 1]
        beta = self.beta_fc(cond).unsqueeze(-1).unsqueeze(-1)    # [B, C, 1, 1]
        return gamma * feat + beta


# -----------------------------------------------------------------
# Conv + BN + ReLU building block
# -----------------------------------------------------------------

class ConvBNReLU(nn.Module):
    """Conv2d -> BatchNorm2d -> ReLU."""

    def __init__(self, in_ch: int, out_ch: int, kernel_size: int = 3):
        super().__init__()
        padding = kernel_size // 2
        self.block = nn.Sequential(
            nn.Conv2d(in_ch, out_ch, kernel_size=kernel_size, padding=padding, bias=False),
            nn.BatchNorm2d(out_ch),
            nn.ReLU(inplace=True),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.block(x)


# -----------------------------------------------------------------
# Upsample block (ConvTranspose2d + skip connection)
# -----------------------------------------------------------------

class UpsampleBlock(nn.Module):
    """Upsample by factor of 2, optionally fuse with a skip connection.

    Args:
        in_ch:   Input channels (from the previous, deeper level).
        skip_ch: Channels from the encoder skip connection.
                 Use 0 to indicate no skip connection.
        out_ch:  Output channels after convolution.
    """

    def __init__(self, in_ch: int, skip_ch: int, out_ch: int):
        super().__init__()
        self.up = nn.ConvTranspose2d(in_ch, out_ch, kernel_size=2, stride=2)
        conv_in = out_ch + skip_ch if skip_ch > 0 else out_ch
        self.conv = ConvBNReLU(conv_in, out_ch)

    def forward(
        self, x: torch.Tensor, skip: Optional[torch.Tensor] = None
    ) -> torch.Tensor:
        """Forward pass.

        Args:
            x:    Feature from the deeper level ``[B, C_in, H, W]``.
            skip: Optional skip feature ``[B, C_skip, 2H, 2W]``.

        Returns:
            Upsampled feature ``[B, C_out, 2H, 2W]``.
        """
        x = self.up(x)  # [B, out_ch, 2H, 2W]
        if skip is not None:
            # Handle minor size mismatch due to odd spatial dimensions.
            if x.shape[2:] != skip.shape[2:]:
                x = F.interpolate(
                    x, size=skip.shape[2:], mode="bilinear", align_corners=False
                )
            x = torch.cat([x, skip], dim=1)
        return self.conv(x)


# -----------------------------------------------------------------
# Main decoder
# -----------------------------------------------------------------

class BoundaryRegionDecoder(nn.Module):
    """Region-boundary dual decoder with optional edge, SDM, and uncertainty
    heads.

    The decoder accepts a bridge feature (from the deepest encoder level) and
    a list of stage-wise encoder features ordered from shallowest to deepest.
    Two parallel upsampling paths are built:

    * **Region branch** -- produces the primary segmentation logits.
    * **Boundary branch** -- produces edge logits and an SDM prediction.

    A shared uncertainty head operates on the concatenated features from both
    branches.

    The morphological prompt is injected at the mid-level of each branch via
    FiLM conditioning layers.

    Args:
        config: A :class:`Config` object.  Relevant sub-config:
            ``config.model``.

    Shape:
        - bridge_feat: ``[B, C_bridge, H_b, W_b]``
        - stage_feats: list of 4 Tensors (shallowest to deepest), spatial
          sizes ``[(H_b*8, W_b*8), (H_b*4, W_b*4), (H_b*2, W_b*2), (H_b, W_b)]``
        - morph_prompt: ``[B, prompt_dim]``
        - Output: ``(seg_logits, edge_logits, sdm_pred, uncertainty_map)``
          all ``[B, 1, H_out, W_out]`` where ``H_out = H_b * 8``.
    """

    def __init__(self, config):
        super().__init__()

        model_cfg = config.model
        self.encoder_channels: List[int] = list(
            getattr(model_cfg, "encoder_channels", [64, 128, 256, 512])
        )
        self.prompt_dim: int = getattr(model_cfg, "prompt_dim", 128)
        self.use_edge_head: bool = getattr(model_cfg, "use_edge_head", True)
        self.use_sdm_head: bool = getattr(model_cfg, "use_sdm_head", True)
        self.use_uncertainty_head: bool = getattr(
            model_cfg, "use_uncertainty_head", True
        )

        enc = self.encoder_channels  # shorthand: [C0, C1, C2, C3] (shallow->deep)
        assert len(enc) == 4, (
            f"BoundaryRegionDecoder expects exactly 4 encoder channel levels, "
            f"got {len(enc)}"
        )
        bridge_ch = enc[-1]  # C3

        # ------------------------------------------------------------------
        # Region branch (3 upsample stages: bridge -> 1/4 -> 1/2 -> full)
        # ------------------------------------------------------------------
        mid_ch = enc[1]  # 128 -- mid-level channel width

        self.region_up1 = UpsampleBlock(bridge_ch, enc[2], enc[2])
        self.region_film1 = FiLMLayer(self.prompt_dim, enc[2])
        self.region_up2 = UpsampleBlock(enc[2], enc[1], enc[1])
        self.region_up3 = UpsampleBlock(enc[1], enc[0], enc[0])

        self.region_head = nn.Conv2d(enc[0], 1, kernel_size=1)

        # ------------------------------------------------------------------
        # Boundary branch (parallel path)
        # ------------------------------------------------------------------
        self.boundary_up1 = UpsampleBlock(bridge_ch, enc[2], enc[2])
        self.boundary_film1 = FiLMLayer(self.prompt_dim, enc[2])
        self.boundary_up2 = UpsampleBlock(enc[2], enc[1], enc[1])
        self.boundary_up3 = UpsampleBlock(enc[1], enc[0], enc[0])

        if self.use_edge_head:
            self.edge_head = nn.Conv2d(enc[0], 1, kernel_size=1)
        else:
            self.edge_head = None

        if self.use_sdm_head:
            self.sdm_head = nn.Conv2d(enc[0], 1, kernel_size=1)
        else:
            self.sdm_head = None

        # ------------------------------------------------------------------
        # Uncertainty head (operates on concatenated region + boundary at
        # the shallowest level)
        # ------------------------------------------------------------------
        if self.use_uncertainty_head:
            self.uncertainty_conv = nn.Sequential(
                ConvBNReLU(enc[0] * 2, enc[0]),
                nn.Conv2d(enc[0], 1, kernel_size=1),
            )
        else:
            self.uncertainty_conv = None

        self._reset_parameters()

    # -----------------------------------------------------------------
    # Initialisation
    # -----------------------------------------------------------------

    def _reset_parameters(self) -> None:
        """Initialize conv/linear weights with Kaiming normal."""
        for module in self.modules():
            if isinstance(module, (nn.Conv2d, nn.ConvTranspose2d, nn.Linear)):
                nn.init.kaiming_normal_(module.weight, nonlinearity="relu")
                if module.bias is not None:
                    nn.init.zeros_(module.bias)
            elif isinstance(module, nn.BatchNorm2d):
                nn.init.ones_(module.weight)
                nn.init.zeros_(module.bias)

    # -----------------------------------------------------------------
    # Forward
    # -----------------------------------------------------------------

    def forward(
        self,
        bridge_feat: torch.Tensor,
        stage_feats: List[torch.Tensor],
        morph_prompt: torch.Tensor,
    ) -> Tuple[torch.Tensor, Optional[torch.Tensor], Optional[torch.Tensor], Optional[torch.Tensor]]:
        """Decode bridge + encoder features into segmentation and boundary
        outputs.

        Args:
            bridge_feat:  Deepest encoder / bridge feature ``[B, C3, H_b, W_b]``.
            stage_feats:  List of 4 encoder stage features ordered shallowest
                          to deepest.  ``stage_feats[0]`` has the highest
                          spatial resolution.
            morph_prompt: Morphology prompt vector ``[B, prompt_dim]`` from MPP.

        Returns:
            A 4-tuple:

            - **seg_logits** ``[B, 1, H, W]`` -- region segmentation logits.
            - **edge_logits** ``[B, 1, H, W]`` or ``None`` -- boundary edge
              logits (``None`` if ``use_edge_head`` is ``False``).
            - **sdm_pred** ``[B, 1, H, W]`` or ``None`` -- signed distance
              map prediction (``None`` if ``use_sdm_head`` is ``False``).
            - **uncertainty_map** ``[B, 1, H, W]`` or ``None`` -- pixel-wise
              uncertainty (``None`` if ``use_uncertainty_head`` is ``False``).
        """
        # stage_feats: [feat_s0, feat_s1, feat_s2, feat_s3]
        #   s0 = shallowest (largest spatial), s3 = deepest (smallest spatial)
        #   Skip connections are from s2 (for up1), s1 (for up2), s0 (for up3)
        feat_s0, feat_s1, feat_s2, _feat_s3 = stage_feats

        # --- Region branch ---
        r = self.region_up1(bridge_feat, skip=feat_s2)   # [B, C2, H*2, W*2]
        r = self.region_film1(r, morph_prompt)
        r = self.region_up2(r, skip=feat_s1)             # [B, C1, H*4, W*4]
        r = self.region_up3(r, skip=feat_s0)             # [B, C0, H*8, W*8]
        seg_logits = self.region_head(r)                  # [B, 1, H, W]

        # --- Boundary branch ---
        b = self.boundary_up1(bridge_feat, skip=feat_s2)
        b = self.boundary_film1(b, morph_prompt)
        b = self.boundary_up2(b, skip=feat_s1)
        b = self.boundary_up3(b, skip=feat_s0)

        edge_logits = self.edge_head(b) if self.edge_head is not None else None
        sdm_pred = self.sdm_head(b) if self.sdm_head is not None else None

        # --- Uncertainty head ---
        if self.uncertainty_conv is not None:
            combined = torch.cat([r, b], dim=1)  # [B, 2*C0, H, W]
            uncertainty_map = self.uncertainty_conv(combined)  # [B, 1, H, W]
        else:
            uncertainty_map = None

        return seg_logits, edge_logits, sdm_pred, uncertainty_map
