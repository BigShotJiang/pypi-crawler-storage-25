"""Segmentation metrics for JwzTumor."""
import logging
from typing import Dict

import numpy as np
from scipy import ndimage

logger = logging.getLogger(__name__)


def compute_segmentation_metrics(
    pred_mask: np.ndarray,
    gt_mask: np.ndarray,
    voxel_spacing: tuple = (1.0, 1.0),
) -> Dict[str, float]:
    """Compute segmentation metrics.

    Args:
        pred_mask: Predicted binary mask [H, W].
        gt_mask: Ground truth binary mask [H, W].
        voxel_spacing: Pixel spacing.

    Returns:
        Dict of metric_name -> value.
    """
    pred = (pred_mask > 0).astype(np.float32)
    gt = (gt_mask > 0).astype(np.float32)

    if pred.sum() == 0 and gt.sum() == 0:
        return {"dice": 1.0, "iou": 1.0, "hd95": 0.0,
                "boundary_f1": 1.0, "precision": 1.0, "recall": 1.0}
    if pred.sum() == 0 or gt.sum() == 0:
        return {"dice": 0.0, "iou": 0.0, "hd95": float("inf"),
                "boundary_f1": 0.0, "precision": 0.0, "recall": 0.0}

    # Dice
    intersection = (pred * gt).sum()
    dice = 2 * intersection / (pred.sum() + gt.sum())

    # IoU
    union = pred.sum() + gt.sum() - intersection
    iou = intersection / max(union, 1)

    # HD95
    hd95 = compute_hd95(pred, gt, voxel_spacing)

    # Boundary F1
    boundary_f1 = compute_boundary_f1(pred, gt)

    # Precision / Recall
    precision = intersection / max(pred.sum(), 1)
    recall = intersection / max(gt.sum(), 1)

    return {
        "dice": float(dice),
        "iou": float(iou),
        "hd95": float(hd95),
        "boundary_f1": float(boundary_f1),
        "precision": float(precision),
        "recall": float(recall),
    }


def compute_hd95(pred: np.ndarray, gt: np.ndarray, spacing: tuple = (1.0, 1.0)) -> float:
    """Compute 95th percentile Hausdorff Distance."""
    pred_border = _extract_border(pred)
    gt_border = _extract_border(gt)

    if pred_border.sum() == 0 or gt_border.sum() == 0:
        return float("inf")

    pred_points = np.argwhere(pred_border > 0).astype(np.float64)
    gt_points = np.argwhere(gt_border > 0).astype(np.float64)

    # Scale by spacing
    pred_points = pred_points * np.array(spacing)
    gt_points = gt_points * np.array(spacing)

    from scipy.spatial.distance import cdist
    distances = cdist(pred_points, gt_points)

    hd_pred = np.percentile(distances.min(axis=1), 95)
    hd_gt = np.percentile(distances.min(axis=0), 95)

    return max(hd_pred, hd_gt)


def compute_boundary_f1(pred: np.ndarray, gt: np.ndarray, tolerance: int = 2) -> float:
    """Compute Boundary F1 score."""
    pred_border = _extract_border(pred)
    gt_border = _extract_border(gt)

    if pred_border.sum() == 0 and gt_border.sum() == 0:
        return 1.0
    if pred_border.sum() == 0 or gt_border.sum() == 0:
        return 0.0

    # Dilate borders for tolerance
    gt_dilated = ndimage.binary_dilation(gt_border, iterations=tolerance)
    pred_dilated = ndimage.binary_dilation(pred_border, iterations=tolerance)

    # Precision: how many pred border pixels near gt border
    precision = (pred_border * gt_dilated).sum() / max(pred_border.sum(), 1)
    # Recall: how many gt border pixels near pred border
    recall = (gt_border * pred_dilated).sum() / max(gt_border.sum(), 1)

    f1 = 2 * precision * recall / max(precision + recall, 1e-8)
    return float(f1)


def _extract_border(mask: np.ndarray, width: int = 1) -> np.ndarray:
    """Extract border of binary mask."""
    binary = (mask > 0).astype(np.float32)
    dilated = ndimage.binary_dilation(binary, iterations=width).astype(np.float32)
    eroded = ndimage.binary_erosion(binary, iterations=width).astype(np.float32)
    border = dilated - eroded
    return (border > 0).astype(np.float32)
