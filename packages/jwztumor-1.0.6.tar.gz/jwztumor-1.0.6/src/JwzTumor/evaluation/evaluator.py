"""Unified evaluator for JwzTumor."""
import logging
from pathlib import Path
from typing import Any, Dict, List, Optional

import numpy as np

from .classification_metrics import compute_classification_metrics
from .segmentation_metrics import compute_segmentation_metrics
from ..utils.io import save_json, save_predictions_csv

logger = logging.getLogger(__name__)


class Evaluator:
    """Unified evaluator for classification and segmentation metrics."""

    def __init__(self, config):
        self.config = config

    def evaluate_predictions(
        self,
        predictions: List[Dict[str, Any]],
        output_dir: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Evaluate predictions against ground truth.

        Args:
            predictions: List of prediction dicts from predictor.
            output_dir: Optional output directory for metrics.

        Returns:
            Dict with classification and segmentation metrics.
        """
        y_true_cls = []
        y_prob_cls = []
        dice_scores = []
        iou_scores = []

        for pred in predictions:
            # Classification
            if pred.get("true_label") is not None and pred.get("prob_malignant") is not None:
                y_true_cls.append(pred["true_label"])
                y_prob_cls.append(pred["prob_malignant"])

            # Segmentation
            if pred.get("seg_mask_restored") is not None:
                try:
                    from ..data.busi_dataset import BUSIDataset
                    # Load GT mask if available
                    mask_path = pred.get("meta", {}).get("mask_path")
                    if mask_path and isinstance(mask_path, str):
                        from PIL import Image
                        gt = np.array(Image.open(mask_path))
                        from ..data.mask_utils import binarize_mask
                        gt = binarize_mask(gt.astype(np.float32))
                        pred_mask = pred["seg_mask_restored"].numpy()
                        if pred_mask.ndim == 3:
                            pred_mask = pred_mask[0]
                        seg_metrics = compute_segmentation_metrics(pred_mask, gt)
                        dice_scores.append(seg_metrics["dice"])
                        iou_scores.append(seg_metrics["iou"])
                except Exception as e:
                    logger.debug("Segmentation eval failed for %s: %s", pred.get("image_id"), e)

        result = {"dataset": {"name": self.config.dataset.test_name}}

        # Classification metrics
        if y_true_cls and len(set(y_true_cls)) > 1:
            cls_metrics = compute_classification_metrics(
                np.array(y_true_cls), np.array(y_prob_cls)
            )
            result["classification"] = cls_metrics
        else:
            result["classification"] = {}

        # Segmentation metrics
        if dice_scores:
            result["segmentation"] = {
                "dice": float(np.mean(dice_scores)),
                "iou": float(np.mean(iou_scores)),
                "num_samples": len(dice_scores),
            }
        else:
            result["segmentation"] = {}

        # Dataset stats
        result["dataset"]["num_images"] = len(predictions)
        benign = sum(1 for p in predictions if p.get("true_label") == 0)
        malignant = sum(1 for p in predictions if p.get("true_label") == 1)
        result["dataset"]["num_benign"] = benign
        result["dataset"]["num_malignant"] = malignant

        # Save
        if output_dir:
            output_dir = Path(output_dir)
            output_dir.mkdir(parents=True, exist_ok=True)
            save_json(result, output_dir / "metrics.json")

        return result
