"""Classification losses for multi-task breast ultrasound diagnosis.

Provides:
    - AsymmetricFocalLoss: Focal loss with asymmetric alpha weighting that
      puts higher emphasis on the malignant class to improve recall.
    - FocalLoss: Standard focal loss with configurable alpha and gamma.

Both losses are designed for binary classification (benign / malignant) and
operate on logits for numerical stability.

All losses are proper ``nn.Module`` subclasses with differentiable
``forward()`` methods that support backpropagation.
"""
import torch
import torch.nn as nn
import torch.nn.functional as F

__all__ = ["AsymmetricFocalLoss", "FocalLoss"]


# ---------------------------------------------------------------------------
# FocalLoss
# ---------------------------------------------------------------------------

class FocalLoss(nn.Module):
    """Standard focal loss for binary classification.

    ``FL(p_t) = -alpha_t * (1 - p_t)^gamma * log(p_t)``

    The focal term ``(1 - p_t)^gamma`` down-weights well-classified examples
    and focuses the optimiser on hard, misclassified samples.

    Args:
        alpha: Class-balancing weight for the positive class.  The negative
            class receives weight ``1 - alpha``.
        gamma: Focusing parameter.  ``gamma = 0`` recovers standard
            cross-entropy; higher values increase the focus on hard examples.
        reduction: ``"mean"`` or ``"sum"``.
    """

    def __init__(
        self,
        alpha: float = 0.25,
        gamma: float = 2.0,
        reduction: str = "mean",
    ):
        super().__init__()
        self.alpha = alpha
        self.gamma = gamma
        self.reduction = reduction

    def forward(
        self,
        pred_logits: torch.Tensor,
        targets: torch.Tensor,
    ) -> torch.Tensor:
        """Compute focal loss.

        Args:
            pred_logits: Raw logits from the model, shape ``[B]``.
            targets: Binary labels, shape ``[B]`` (0 = benign, 1 = malignant).

        Returns:
            Scalar loss value.
        """
        pred_probs = torch.sigmoid(pred_logits)
        bce = F.binary_cross_entropy_with_logits(
            pred_logits, targets.float(), reduction="none"
        )
        p_t = targets * pred_probs + (1.0 - targets) * (1.0 - pred_probs)
        focal_weight = (1.0 - p_t) ** self.gamma
        alpha_t = targets * self.alpha + (1.0 - targets) * (1.0 - self.alpha)
        loss = alpha_t * focal_weight * bce

        if self.reduction == "mean":
            return loss.mean()
        return loss.sum()


# ---------------------------------------------------------------------------
# AsymmetricFocalLoss
# ---------------------------------------------------------------------------

class AsymmetricFocalLoss(nn.Module):
    """Asymmetric focal loss with per-class alpha and gamma.

    Unlike :class:`FocalLoss` which uses a single ``alpha`` and ``gamma``
    for both classes, this variant allows separate weighting:

    * **Benign (class 0)**: weighted by ``alpha_benign`` with focusing
      parameter ``gamma_benign``.
    * **Malignant (class 1)**: weighted by ``alpha_malignant`` with
      focusing parameter ``gamma_malignant``.

    Setting ``alpha_malignant > alpha_benign`` and/or
    ``gamma_malignant > gamma_benign`` places more optimisation emphasis on
    the malignant class, directly improving sensitivity (recall) for cancer
    detection -- a critical clinical requirement.

    Args:
        alpha_benign: Weight for the benign class (class 0).
        alpha_malignant: Weight for the malignant class (class 1).
            Should be higher than ``alpha_benign`` to prioritise recall.
        gamma_benign: Focusing parameter for benign samples.
        gamma_malignant: Focusing parameter for malignant samples.
            Higher values focus more on hard malignant cases.
        reduction: ``"mean"`` or ``"sum"``.
    """

    def __init__(
        self,
        alpha_benign: float = 0.25,
        alpha_malignant: float = 0.75,
        gamma_benign: float = 1.0,
        gamma_malignant: float = 2.0,
        reduction: str = "mean",
    ):
        super().__init__()
        self.alpha_benign = alpha_benign
        self.alpha_malignant = alpha_malignant
        self.gamma_benign = gamma_benign
        self.gamma_malignant = gamma_malignant
        self.reduction = reduction

    def forward(
        self,
        pred_logits: torch.Tensor,
        targets: torch.Tensor,
    ) -> torch.Tensor:
        """Compute asymmetric focal loss.

        Args:
            pred_logits: Raw logits from the model, shape ``[B]`` or ``[B, 2]``.
                If [B, 2], uses malignant class (index 1) logit.
            targets: Binary labels, shape ``[B]`` (0 = benign, 1 = malignant).

        Returns:
            Scalar loss value.
        """
        targets_float = targets.float()

        # Handle [B, 2] logits (multi-class) by extracting malignant logit
        if pred_logits.dim() > 1 and pred_logits.shape[-1] > 1:
            pred_logits = pred_logits[:, 1]  # [B, 2] -> [B]

        pred_probs = torch.sigmoid(pred_logits)

        # BCE per sample
        bce = F.binary_cross_entropy_with_logits(
            pred_logits, targets_float, reduction="none"
        )

        # Probability of the true class
        p_t = targets_float * pred_probs + (1.0 - targets_float) * (1.0 - pred_probs)

        # Per-class gamma
        gamma = targets_float * self.gamma_malignant + (1.0 - targets_float) * self.gamma_benign
        focal_weight = (1.0 - p_t) ** gamma

        # Per-class alpha
        alpha = targets_float * self.alpha_malignant + (1.0 - targets_float) * self.alpha_benign

        loss = alpha * focal_weight * bce

        if self.reduction == "mean":
            return loss.mean()
        return loss.sum()
