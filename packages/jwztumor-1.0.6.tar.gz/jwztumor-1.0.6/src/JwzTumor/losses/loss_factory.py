"""Multi-task loss factory for breast ultrasound diagnosis.

Provides:
    - MultiTaskLossFactory: Creates the combined loss function based on the
      current training stage, with support for uncertainty weighting and
      dynamic component selection.

The factory maps the training stage to the appropriate subset of losses:

* ``pretrain_pre``   -- L_pre only
* ``pretrain_seg``   -- L_seg + L_edge + L_sdm
* ``train_cls``      -- L_cls + L_auc + L_unc
* ``finetune_all``   -- all losses

When ``has_mask=False`` for a batch, segmentation-related losses (seg,
edge, SDM) are automatically skipped so that unlabeled data can still
contribute through classification and AUC objectives.

Uncertainty weighting (Kendall et al., 2018) learns task-dependent
homoscedastic noise parameters to automatically balance the loss terms.
"""
import logging
import math
from typing import Any, Dict

import torch
import torch.nn as nn

from .segmentation_losses import DiceBCELoss, DiceFocalLoss
from .boundary_losses import BoundaryBCELoss, BoundaryDiceLoss
from .classification_losses import AsymmetricFocalLoss, FocalLoss
from .auc_losses import AUCMarginLoss
from .consistency_losses import ConsistencyLoss
from .pre_losses import PreLoss

logger = logging.getLogger(__name__)

__all__ = ["MultiTaskLossFactory"]


class MultiTaskLossFactory(nn.Module):
    """Factory that builds and applies the correct composite loss.

    On construction the factory reads the :class:`LossConfig` to instantiate
    the required loss modules.  During forward it selects the active subset
    according to the current training stage, applies per-task weighting,
    and optionally uses learned uncertainty weights.

    Args:
        config: A :class:`Config` object (or any object with ``loss`` and
            ``training`` attributes).

    Attributes:
        loss_dict: A flat dictionary ``{name: loss_value}`` populated after
            each ``forward()`` call, useful for logging.
    """

    # Mapping from stage name to the set of active loss components
    _STAGE_COMPONENTS = {
        "pretrain_pre": {"pre"},
        "pretrain_seg": {"seg", "edge", "sdm"},
        "train_cls": {"cls", "auc", "unc"},
        "finetune_all": {"seg", "edge", "sdm", "cls", "auc", "cons", "pre", "unc"},
    }

    def __init__(self, config: Any):
        super().__init__()
        self.loss_config = config.loss
        self.training_config = config.training

        # ------------------------------------------------------------------
        # Instantiate loss modules
        # ------------------------------------------------------------------
        self._build_losses()

        # ------------------------------------------------------------------
        # Uncertainty weighting parameters (learned log-variance per task)
        # ------------------------------------------------------------------
        self.use_uncertainty_weighting = self.loss_config.use_uncertainty_weighting
        if self.use_uncertainty_weighting:
            n_tasks = 7  # seg, edge, sdm, cls, auc, cons, pre
            self.log_vars = nn.Parameter(torch.zeros(n_tasks))

        # Last computed per-loss breakdown
        self.loss_dict: Dict[str, torch.Tensor] = {}

    # ------------------------------------------------------------------
    # Private: build individual loss modules
    # ------------------------------------------------------------------

    def _build_losses(self) -> None:
        """Instantiate all loss modules from config."""
        lc = self.loss_config

        # Segmentation loss
        if lc.seg_loss == "dice_bce":
            self.seg_loss = DiceBCELoss(
                dice_weight=lc.dice_weight,
                bce_weight=lc.bce_weight,
            )
        elif lc.seg_loss == "dice_focal":
            self.seg_loss = DiceFocalLoss(
                alpha=lc.focal_alpha,
                gamma=lc.focal_gamma,
            )
        else:
            logger.warning(
                "Unknown seg_loss '%s', falling back to DiceBCELoss", lc.seg_loss
            )
            self.seg_loss = DiceBCELoss(
                dice_weight=lc.dice_weight,
                bce_weight=lc.bce_weight,
            )

        # Edge / boundary loss
        if lc.edge_loss == "boundary_dice":
            self.edge_loss = BoundaryDiceLoss()
        else:
            self.edge_loss = BoundaryBCELoss()

        # SDM loss (simple L1 / Smooth L1)
        self.sdm_loss = nn.SmoothL1Loss()

        # Classification loss
        if lc.cls_loss == "asymmetric_focal":
            self.cls_loss = AsymmetricFocalLoss()
        else:
            self.cls_loss = FocalLoss(alpha=lc.focal_alpha, gamma=lc.focal_gamma)

        # AUC loss
        if lc.use_auc_loss:
            self.auc_loss = AUCMarginLoss()
        else:
            self.auc_loss = None

        # Consistency loss
        self.cons_loss = ConsistencyLoss()

        # Pre-training loss
        self.pre_loss = PreLoss()

    # ------------------------------------------------------------------
    # Private: uncertainty weighting
    # ------------------------------------------------------------------

    def _apply_uncertainty_weight(
        self,
        raw_loss: torch.Tensor,
        task_index: int,
    ) -> torch.Tensor:
        """Apply learned uncertainty weighting.

        Following Kendall et al. (2018), the weighted loss for task *i* is:
        ``L_i / (2 * sigma_i^2) + log(sigma_i)``
        where ``sigma_i = exp(0.5 * log_var_i)``.

        Args:
            raw_loss: Unweighted loss value.
            task_index: Index into ``self.log_vars``.

        Returns:
            Weighted loss value.
        """
        if not self.use_uncertainty_weighting:
            return raw_loss
        precision = torch.exp(-self.log_vars[task_index])
        return precision * raw_loss + 0.5 * self.log_vars[task_index]

    # ------------------------------------------------------------------
    # Forward
    # ------------------------------------------------------------------

    def forward(
        self,
        outputs: Dict[str, Any],
        batch: Dict[str, Any],
    ) -> Dict[str, Any]:
        """Compute the composite loss for the current batch and stage.

        Args:
            outputs: Model output dictionary.  Expected keys depend on the
                stage but commonly include:

                - ``"seg_logits"``        -- segmentation logits ``[B,1,H,W]``
                - ``"edge_logits"``       -- edge logits ``[B,1,H,W]``
                - ``"sdm_pred"``          -- SDM prediction ``[B,1,H,W]``
                - ``"cls_logits"``        -- classification logits ``[B]``
                - ``"uncertainty"``       -- uncertainty map ``[B,1,H,W]``
                - ``"cls_logits_aug"``    -- augmented view classification logits
                - ``"seg_logits_aug"``    -- augmented view segmentation logits
                - ``"pred_boundary"``     -- boundary prediction
                - ``"pred_texture"``      -- texture prediction
                - ``"pred_prior"``        -- coarse prior prediction

            batch: Input batch dictionary from the data loader, expected
                keys include ``"mask"``, ``"edge"``, ``"sdm"``, ``"label"``,
                ``"has_mask"``, ``"image"``.

        Returns:
            Dictionary with:

            - ``"total_loss"``: scalar combined loss for ``.backward()``.
            - ``"loss_dict"``: flat ``{name: value}`` for logging.
        """
        self.loss_dict = {}

        stage = self.training_config.stage
        components = self._STAGE_COMPONENTS.get(stage, self._STAGE_COMPONENTS["finetune_all"])

        has_mask = batch.get("has_mask", None)
        # has_mask is [B] tensor; check if ANY sample has a mask
        if has_mask is not None:
            has_any_mask = has_mask.sum().item() > 0
        else:
            # If has_mask key is missing, assume masks are present
            has_any_mask = True

        total_loss = torch.tensor(0.0, device=_get_device(outputs))

        # ----------------------------------------------------------
        # Segmentation loss
        # ----------------------------------------------------------
        if "seg" in components and has_any_mask:
            seg_logits = outputs.get("seg_logits")
            mask_target = batch.get("mask")
            if seg_logits is not None and mask_target is not None:
                raw = self.seg_loss(seg_logits, mask_target)
                weighted = self._apply_uncertainty_weight(raw, 0)
                total_loss = total_loss + weighted
                self.loss_dict["seg_loss"] = raw.detach()

        # ----------------------------------------------------------
        # Edge / boundary loss
        # ----------------------------------------------------------
        if "edge" in components and has_any_mask:
            edge_logits = outputs.get("edge_logits")
            mask_target = batch.get("mask")
            edge_target = batch.get("edge")
            if edge_logits is not None and mask_target is not None:
                raw = self.edge_loss(edge_logits, mask_target, edge_target)
                weighted = self._apply_uncertainty_weight(raw, 1)
                total_loss = total_loss + self.loss_config.lambda_edge * weighted
                self.loss_dict["edge_loss"] = raw.detach()

        # ----------------------------------------------------------
        # SDM loss
        # ----------------------------------------------------------
        if "sdm" in components and has_any_mask:
            sdm_pred = outputs.get("sdm_pred")
            sdm_target = batch.get("sdm")
            if sdm_pred is not None and sdm_target is not None:
                raw = self.sdm_loss(sdm_pred, sdm_target)
                weighted = self._apply_uncertainty_weight(raw, 2)
                total_loss = total_loss + self.loss_config.lambda_sdm * weighted
                self.loss_dict["sdm_loss"] = raw.detach()

        # ----------------------------------------------------------
        # Classification loss
        # ----------------------------------------------------------
        if "cls" in components:
            cls_logits = outputs.get("cls_logits")
            labels = batch.get("label")
            if cls_logits is not None and labels is not None:
                raw = self.cls_loss(cls_logits, labels)
                weighted = self._apply_uncertainty_weight(raw, 3)
                total_loss = total_loss + self.loss_config.lambda_cls * weighted
                self.loss_dict["cls_loss"] = raw.detach()

        # ----------------------------------------------------------
        # AUC loss
        # ----------------------------------------------------------
        if "auc" in components and self.auc_loss is not None:
            cls_logits = outputs.get("cls_logits")
            labels = batch.get("label")
            if cls_logits is not None and labels is not None:
                # cls_logits is [B, 2] from MPTCHead; extract malignant probability
                if cls_logits.dim() > 1 and cls_logits.shape[-1] > 1:
                    pred_probs = torch.softmax(cls_logits, dim=-1)[:, 1]
                else:
                    pred_probs = torch.sigmoid(cls_logits)
                raw = self.auc_loss(pred_probs, labels)
                weighted = self._apply_uncertainty_weight(raw, 4)
                total_loss = total_loss + self.loss_config.lambda_auc * weighted
                self.loss_dict["auc_loss"] = raw.detach()

        # ----------------------------------------------------------
        # Consistency loss
        # ----------------------------------------------------------
        if "cons" in components:
            cls_logits = outputs.get("cls_logits")
            cls_logits_aug = outputs.get("cls_logits_aug")
            seg_logits = outputs.get("seg_logits")
            seg_logits_aug = outputs.get("seg_logits_aug")
            if cls_logits is not None and cls_logits_aug is not None:
                raw = self.cons_loss(
                    cls_logits, cls_logits_aug,
                    seg_logits, seg_logits_aug,
                )
                weighted = self._apply_uncertainty_weight(raw, 5)
                total_loss = total_loss + self.loss_config.lambda_cons * weighted
                self.loss_dict["cons_loss"] = raw.detach()

        # ----------------------------------------------------------
        # Pre-training loss
        # ----------------------------------------------------------
        if "pre" in components:
            raw = self.pre_loss(
                pred_boundary=outputs.get("pred_boundary"),
                edge_target=batch.get("edge"),
                pred_texture=outputs.get("pred_texture"),
                image=batch.get("image"),
                pred_prior=outputs.get("pred_prior"),
                mask_target=batch.get("mask"),
            )
            weighted = self._apply_uncertainty_weight(raw, 6)
            total_loss = total_loss + self.loss_config.lambda_pre * weighted
            self.loss_dict["pre_loss"] = raw.detach()

        # ----------------------------------------------------------
        # Uncertainty regularisation
        # ----------------------------------------------------------
        if "unc" in components:
            uncertainty = outputs.get("uncertainty_map")
            if uncertainty is not None:
                # Minimise mean uncertainty as a regularisation signal
                raw = uncertainty.mean()
                total_loss = total_loss + self.loss_config.lambda_unc * raw
                self.loss_dict["unc_loss"] = raw.detach()

        # ----------------------------------------------------------
        # Ensure total_loss is a proper leaf-like tensor for backprop
        # ----------------------------------------------------------
        if not total_loss.requires_grad and total_loss.item() == 0.0:
            # Provide a zero-loss with gradient connectivity so that
            # .backward() does not fail on empty batches.
            dummy = next(
                (v for v in outputs.values() if isinstance(v, torch.Tensor) and v.requires_grad),
                None,
            )
            if dummy is not None:
                total_loss = (dummy.sum() * 0.0) + total_loss

        self.loss_dict["total_loss"] = total_loss.detach()

        return {
            "total_loss": total_loss,
            "loss_dict": self.loss_dict,
        }


# ---------------------------------------------------------------------------
# Utility
# ---------------------------------------------------------------------------

def _get_device(outputs: Dict[str, Any]) -> torch.device:
    """Infer the device from model outputs."""
    for v in outputs.values():
        if isinstance(v, torch.Tensor):
            return v.device
    return torch.device("cpu")
