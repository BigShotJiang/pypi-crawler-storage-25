"""Boundary-aware losses for multi-task breast ultrasound diagnosis.

Provides:
    - BoundaryBCELoss: Binary cross-entropy computed only on boundary pixels.
    - BoundaryDiceLoss: Dice loss restricted to a boundary region.

These losses encourage the model to produce accurate predictions along
lesion boundaries, which is critical for downstream clinical measurements.

All losses are proper ``nn.Module`` subclasses with differentiable
``forward()`` methods that support backpropagation.
"""
import torch
import torch.nn as nn
import torch.nn.functional as F

__all__ = ["BoundaryBCELoss", "BoundaryDiceLoss"]


# ---------------------------------------------------------------------------
# BoundaryBCELoss
# ---------------------------------------------------------------------------

class BoundaryBCELoss(nn.Module):
    """Binary cross-entropy loss restricted to boundary pixels.

    When ``edge_target`` is provided the loss is computed **only** on pixels
    where ``edge_target == 1`` (i.e. on the boundary).  This focuses the
    model's learning on the challenging boundary region.

    When ``edge_target`` is ``None`` the loss gracefully degrades to standard
    BCE over the full spatial extent.

    Args:
        reduction: Reduction mode (``"mean"`` or ``"sum"``).
        boundary_weight: Extra multiplicative weight applied to boundary
            pixels when using the full-image fallback (no edge mask).
    """

    def __init__(
        self,
        reduction: str = "mean",
        boundary_weight: float = 2.0,
    ):
        super().__init__()
        self.reduction = reduction
        self.boundary_weight = boundary_weight

    def forward(
        self,
        pred_logits: torch.Tensor,
        target: torch.Tensor,
        edge_target: torch.Tensor | None = None,
    ) -> torch.Tensor:
        """Compute boundary BCE loss.

        Args:
            pred_logits: Raw logits, shape ``[B, 1, H, W]``.
            target: Ground-truth binary mask, shape ``[B, 1, H, W]``.
            edge_target: Boundary mask, shape ``[B, 1, H, W]`` with ``1``
                on boundary pixels.  ``None`` triggers the full-image fallback.

        Returns:
            Scalar loss value.
        """
        if edge_target is not None and edge_target.sum() > 0:
            # Compute BCE only on boundary pixels
            bce_map = F.binary_cross_entropy_with_logits(
                pred_logits, target, reduction="none"
            )
            boundary_bce = bce_map * edge_target
            num_boundary = edge_target.sum().clamp(min=1.0)
            if self.reduction == "mean":
                return boundary_bce.sum() / num_boundary
            return boundary_bce.sum()

        # Fallback: weighted full BCE
        bce = F.binary_cross_entropy_with_logits(
            pred_logits, target, reduction=self.reduction
        )
        return bce


# ---------------------------------------------------------------------------
# BoundaryDiceLoss
# ---------------------------------------------------------------------------

class BoundaryDiceLoss(nn.Module):
    """Dice loss restricted to boundary regions.

    Similar to :class:`BoundaryBCELoss`, this loss uses an ``edge_target``
    mask to isolate the boundary.  The Dice score is computed only on the
    pixels belonging to the boundary band, penalising poor overlap between
    the predicted and ground-truth boundaries.

    When ``edge_target`` is ``None`` the loss falls back to a full-image
    Dice loss.

    Args:
        smooth: Smoothing constant for numerical stability.
        dilation_radius: Number of pixels to dilate the boundary mask when
            no explicit edge target is given (used in fallback).
    """

    def __init__(
        self,
        smooth: float = 1.0,
        dilation_radius: int = 2,
    ):
        super().__init__()
        self.smooth = smooth
        self.dilation_radius = dilation_radius

    def forward(
        self,
        pred_logits: torch.Tensor,
        target: torch.Tensor,
        edge_target: torch.Tensor | None = None,
    ) -> torch.Tensor:
        """Compute boundary Dice loss.

        Args:
            pred_logits: Raw logits, shape ``[B, 1, H, W]``.
            target: Ground-truth binary mask, shape ``[B, 1, H, W]``.
            edge_target: Boundary mask, shape ``[B, 1, H, W]``.
                ``None`` triggers the full-image fallback.

        Returns:
            Scalar loss value equal to ``1 - boundary_dice``.
        """
        pred_probs = torch.sigmoid(pred_logits)

        if edge_target is not None and edge_target.sum() > 0:
            pred_b = pred_probs * edge_target
            target_b = target * edge_target
        else:
            pred_b = pred_probs
            target_b = target

        pred_flat = pred_b.reshape(pred_b.shape[0], -1)
        target_flat = target_b.reshape(target_b.shape[0], -1)

        intersection = (pred_flat * target_flat).sum(dim=1)
        union = pred_flat.sum(dim=1) + target_flat.sum(dim=1)

        dice = (2.0 * intersection + self.smooth) / (union + self.smooth + 1e-7)
        return 1.0 - dice.mean()
