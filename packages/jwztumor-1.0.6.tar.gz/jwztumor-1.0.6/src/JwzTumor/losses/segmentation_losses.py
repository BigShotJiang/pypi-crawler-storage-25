"""Segmentation losses for multi-task breast ultrasound diagnosis.

Provides:
    - DiceBCELoss: Weighted combination of Dice loss and binary cross-entropy.
    - DiceFocalLoss: Combination of Dice loss and focal loss.

All losses are proper ``nn.Module`` subclasses with differentiable
``forward()`` methods that support backpropagation.
"""
import torch
import torch.nn as nn
import torch.nn.functional as F

__all__ = ["DiceBCELoss", "DiceFocalLoss"]


# ---------------------------------------------------------------------------
# Helper
# ---------------------------------------------------------------------------

def _soft_dice_score(
    pred: torch.Tensor,
    target: torch.Tensor,
    smooth: float = 1.0,
    eps: float = 1e-7,
) -> torch.Tensor:
    """Compute soft Dice score between prediction and target.

    Args:
        pred: Predicted probabilities, shape ``[B, 1, H, W]`` or ``[B, H, W]``.
        target: Ground-truth binary mask, same shape as *pred*.
        smooth: Laplace smoothing constant added to numerator and denominator.
        eps: Small constant for numerical stability.

    Returns:
        Scalar Dice score averaged over the batch.
    """
    pred_flat = pred.reshape(pred.shape[0], -1)
    target_flat = target.reshape(target.shape[0], -1)
    intersection = (pred_flat * target_flat).sum(dim=1)
    union = pred_flat.sum(dim=1) + target_flat.sum(dim=1)
    dice = (2.0 * intersection + smooth) / (union + smooth + eps)
    return dice.mean()


# ---------------------------------------------------------------------------
# DiceBCELoss
# ---------------------------------------------------------------------------

class DiceBCELoss(nn.Module):
    """Combined Dice and Binary Cross-Entropy loss.

    ``loss = dice_weight * (1 - dice_score) + bce_weight * BCE``

    This combination leverages the region-level overlap measured by Dice
    together with the pixel-level probabilistic objective of BCE, which is
    especially effective for medical image segmentation where class imbalance
    is common.

    Args:
        dice_weight: Weight for the Dice component.
        bce_weight: Weight for the BCE component.
        smooth: Smoothing factor for the Dice computation.
        pos_weight: Optional positive-class weight passed to
            ``F.binary_cross_entropy_with_logits``.  Useful when the
            foreground region is significantly smaller than the background.
    """

    def __init__(
        self,
        dice_weight: float = 0.5,
        bce_weight: float = 0.5,
        smooth: float = 1.0,
        pos_weight: float | None = None,
    ):
        super().__init__()
        self.dice_weight = dice_weight
        self.bce_weight = bce_weight
        self.smooth = smooth
        self.register_buffer(
            "pos_weight",
            torch.tensor([pos_weight]) if pos_weight is not None else None,
        )

    def forward(
        self,
        pred_logits: torch.Tensor,
        target: torch.Tensor,
    ) -> torch.Tensor:
        """Compute the combined Dice + BCE loss.

        Args:
            pred_logits: Raw logits from the model, shape ``[B, 1, H, W]``.
            target: Ground-truth binary mask, shape ``[B, 1, H, W]``.

        Returns:
            Scalar loss value.
        """
        pred_probs = torch.sigmoid(pred_logits)

        # Dice component
        dice_score = _soft_dice_score(pred_probs, target, smooth=self.smooth)
        dice_loss = 1.0 - dice_score

        # BCE component (operates on logits for numerical stability)
        kwargs: dict = {}
        if self.pos_weight is not None:
            kwargs["pos_weight"] = self.pos_weight
        bce = F.binary_cross_entropy_with_logits(pred_logits, target, **kwargs)

        return self.dice_weight * dice_loss + self.bce_weight * bce


# ---------------------------------------------------------------------------
# DiceFocalLoss
# ---------------------------------------------------------------------------

class DiceFocalLoss(nn.Module):
    """Combined Dice and Focal loss.

    ``loss = (1 - dice_score) + focal_loss``

    The focal component down-weights easy negatives and focuses learning on
    hard pixels, complementing the region-level Dice loss.

    Args:
        alpha: Balancing factor for the focal loss.  ``alpha`` weights the
            positive class; ``1 - alpha`` weights the negative class.
        gamma: Focusing parameter that reduces the relative loss for
            well-classified examples, putting more focus on hard examples.
        smooth: Smoothing factor for the Dice computation.
    """

    def __init__(
        self,
        alpha: float = 0.25,
        gamma: float = 2.0,
        smooth: float = 1.0,
    ):
        super().__init__()
        self.alpha = alpha
        self.gamma = gamma
        self.smooth = smooth

    def _focal_loss(
        self,
        pred_logits: torch.Tensor,
        target: torch.Tensor,
    ) -> torch.Tensor:
        """Compute focal loss on logits.

        Args:
            pred_logits: Raw logits, shape ``[B, 1, H, W]``.
            target: Binary targets, same shape.

        Returns:
            Scalar focal loss.
        """
        pred_probs = torch.sigmoid(pred_logits)
        bce = F.binary_cross_entropy_with_logits(
            pred_logits, target, reduction="none"
        )
        p_t = target * pred_probs + (1.0 - target) * (1.0 - pred_probs)
        # Modulating factor
        focal_weight = (1.0 - p_t) ** self.gamma
        # Alpha weighting
        alpha_t = target * self.alpha + (1.0 - target) * (1.0 - self.alpha)
        loss = alpha_t * focal_weight * bce
        return loss.mean()

    def forward(
        self,
        pred_logits: torch.Tensor,
        target: torch.Tensor,
    ) -> torch.Tensor:
        """Compute the combined Dice + Focal loss.

        Args:
            pred_logits: Raw logits from the model, shape ``[B, 1, H, W]``.
            target: Ground-truth binary mask, shape ``[B, 1, H, W]``.

        Returns:
            Scalar loss value.
        """
        pred_probs = torch.sigmoid(pred_logits)
        dice_score = _soft_dice_score(pred_probs, target, smooth=self.smooth)
        dice_loss = 1.0 - dice_score
        focal = self._focal_loss(pred_logits, target)
        return dice_loss + focal
