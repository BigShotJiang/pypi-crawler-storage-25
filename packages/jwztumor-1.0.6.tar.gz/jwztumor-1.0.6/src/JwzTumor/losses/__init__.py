"""Loss function modules for JwzTumor multi-task training.

Provides segmentation, boundary, classification, AUC, consistency, and
pre-training losses, along with a factory that combines them according
to the current training stage.
"""
from .segmentation_losses import DiceBCELoss, DiceFocalLoss
from .boundary_losses import BoundaryBCELoss, BoundaryDiceLoss
from .classification_losses import AsymmetricFocalLoss, FocalLoss
from .auc_losses import AUCMarginLoss
from .consistency_losses import ConsistencyLoss
from .pre_losses import PreLoss
from .loss_factory import MultiTaskLossFactory

__all__ = [
    "DiceBCELoss",
    "DiceFocalLoss",
    "BoundaryBCELoss",
    "BoundaryDiceLoss",
    "AsymmetricFocalLoss",
    "FocalLoss",
    "AUCMarginLoss",
    "ConsistencyLoss",
    "PreLoss",
    "MultiTaskLossFactory",
]
