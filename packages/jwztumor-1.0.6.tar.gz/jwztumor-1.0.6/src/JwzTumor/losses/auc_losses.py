"""AUC-optimising losses for multi-task breast ultrasound diagnosis.

Provides:
    - AUCMarginLoss: Pairwise hinge ranking loss that directly optimises the
      Area Under the ROC Curve.

Unlike surrogate losses (e.g. cross-entropy) that only indirectly improve
AUC, :class:`AUCMarginLoss` operates on positive-negative score pairs and
enforces a margin between them.  This yields a differentiable objective
that is tightly aligned with the AUC metric itself.

All losses are proper ``nn.Module`` subclasses with differentiable
``forward()`` methods that support backpropagation.
"""
import torch
import torch.nn as nn

__all__ = ["AUCMarginLoss"]


class AUCMarginLoss(nn.Module):
    """Pairwise hinge ranking loss for direct AUC optimisation.

    For every positive-negative pair in the batch, the loss encourages the
    positive (malignant) score to exceed the negative (benign) score by at
    least ``margin``:

    ``loss = mean(max(0, margin - (pos_score - neg_score)))``

    This is a differentiable surrogate for the Wilcoxon–Mann–Whitney
    statistic underlying AUC.  Because it compares all positive-negative
    pairs within each mini-batch it provides a meaningful gradient signal
    even when the batch is imbalanced.

    Args:
        margin: Desired score gap between positive and negative pairs.
            Larger margins yield tighter ROC curves but may slow convergence.
    """

    def __init__(self, margin: float = 1.0):
        super().__init__()
        self.margin = margin

    def forward(
        self,
        pred_probs: torch.Tensor,
        labels: torch.Tensor,
    ) -> torch.Tensor:
        """Compute the pairwise AUC margin loss.

        Args:
            pred_probs: Predicted probabilities for the malignant class,
                shape ``[B]``.  These should already be passed through
                sigmoid or softmax.
            labels: Ground-truth binary labels, shape ``[B]``
                (0 = benign, 1 = malignant).

        Returns:
            Scalar loss value.  Returns ``0.0`` (with gradient) if the batch
            contains only positives or only negatives.
        """
        pos_mask = labels == 1
        neg_mask = labels == 0

        n_pos = pos_mask.sum()
        n_neg = neg_mask.sum()

        if n_pos == 0 or n_neg == 0:
            return torch.tensor(
                0.0, requires_grad=True, device=pred_probs.device
            )

        pos_probs = pred_probs[pos_mask]   # [N_pos]
        neg_probs = pred_probs[neg_mask]   # [N_neg]

        # Pairwise differences: each row is a positive, each column a negative.
        # We want pos_score - neg_score >= margin.
        diff = pos_probs.unsqueeze(1) - neg_probs.unsqueeze(0)  # [N_pos, N_neg]

        # Hinge: penalise pairs where the gap is smaller than the margin.
        loss = torch.clamp(self.margin - diff, min=0.0).mean()
        return loss
