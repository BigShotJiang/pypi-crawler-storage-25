"""Consistency losses for multi-task breast ultrasound diagnosis.

Provides:
    - ConsistencyLoss: Encourages consistent predictions under input
      augmentations using KL-divergence on classification probabilities and
      MSE on segmentation maps.

Regularising the model to produce stable predictions across different views
or augmentations of the same image improves generalisation, particularly
in the semi-supervised / limited-label setting common in medical imaging.

All losses are proper ``nn.Module`` subclasses with differentiable
``forward()`` methods that support backpropagation.
"""
import torch
import torch.nn as nn
import torch.nn.functional as F

__all__ = ["ConsistencyLoss"]


class ConsistencyLoss(nn.Module):
    """Consistency regularisation between original and augmented predictions.

    Given two sets of outputs (original and augmented), the total loss is:

    ``L_cons = kl_weight * KL(p_orig || p_aug) + mse_weight * MSE(seg_orig, seg_aug)``

    The KL term forces the classification distributions to agree, while the
    MSE term forces the segmentation maps to be spatially consistent.

    Args:
        kl_weight: Weight for the KL-divergence classification term.
        mse_weight: Weight for the MSE segmentation term.
        temperature: Temperature for softening probability distributions
            before computing KL divergence.
    """

    def __init__(
        self,
        kl_weight: float = 1.0,
        mse_weight: float = 1.0,
        temperature: float = 1.0,
    ):
        super().__init__()
        self.kl_weight = kl_weight
        self.mse_weight = mse_weight
        self.temperature = temperature

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _kl_classification(
        self,
        logits_orig: torch.Tensor,
        logits_aug: torch.Tensor,
    ) -> torch.Tensor:
        """KL divergence between two Bernoulli distributions.

        Args:
            logits_orig: Classification logits for the original view, ``[B]``.
            logits_aug: Classification logits for the augmented view, ``[B]``.

        Returns:
            Scalar KL divergence averaged over the batch.
        """
        # Soften probabilities with temperature
        p_orig = torch.sigmoid(logits_orig / self.temperature)
        p_aug = torch.sigmoid(logits_aug / self.temperature)

        # Clamp to avoid log(0)
        p_orig = p_orig.clamp(min=1e-6, max=1.0 - 1e-6)
        p_aug = p_aug.clamp(min=1e-6, max=1.0 - 1e-6)

        # KL(P || Q) for Bernoulli distributions
        kl = (
            p_orig * (torch.log(p_orig) - torch.log(p_aug))
            + (1.0 - p_orig) * (torch.log(1.0 - p_orig) - torch.log(1.0 - p_aug))
        )
        return kl.mean() * (self.temperature ** 2)

    def _mse_segmentation(
        self,
        seg_orig: torch.Tensor,
        seg_aug: torch.Tensor,
    ) -> torch.Tensor:
        """MSE between original and augmented segmentation maps.

        Args:
            seg_orig: Segmentation probabilities for the original view,
                ``[B, 1, H, W]``.
            seg_aug: Segmentation probabilities for the augmented view,
                ``[B, 1, H, W]``.

        Returns:
            Scalar MSE averaged over all elements.
        """
        return F.mse_loss(seg_orig, seg_aug)

    # ------------------------------------------------------------------
    # Forward
    # ------------------------------------------------------------------

    def forward(
        self,
        cls_logits_orig: torch.Tensor,
        cls_logits_aug: torch.Tensor,
        seg_logits_orig: torch.Tensor | None = None,
        seg_logits_aug: torch.Tensor | None = None,
    ) -> torch.Tensor:
        """Compute the combined consistency loss.

        Args:
            cls_logits_orig: Classification logits for original view, ``[B]``.
            cls_logits_aug: Classification logits for augmented view, ``[B]``.
            seg_logits_orig: Segmentation logits for original view,
                ``[B, 1, H, W]`` or ``None`` to skip the MSE term.
            seg_logits_aug: Segmentation logits for augmented view,
                ``[B, 1, H, W]`` or ``None`` to skip the MSE term.

        Returns:
            Scalar consistency loss.
        """
        loss = self.kl_weight * self._kl_classification(
            cls_logits_orig, cls_logits_aug
        )

        if seg_logits_orig is not None and seg_logits_aug is not None:
            seg_orig_probs = torch.sigmoid(seg_logits_orig)
            seg_aug_probs = torch.sigmoid(seg_logits_aug)
            loss = loss + self.mse_weight * self._mse_segmentation(
                seg_orig_probs, seg_aug_probs
            )

        return loss
