"""Pre-training losses for multi-task breast ultrasound diagnosis.

Provides:
    - PreLoss: Boundary preservation + texture consistency + coarse prior
      consistency, implemented as an MVP using MSE between predicted and
      target quantities.

This loss is used during the ``pretrain_pre`` stage to bootstrap the
network's encoder and auxiliary heads before the full multi-task training
begins.

All losses are proper ``nn.Module`` subclasses with differentiable
``forward()`` methods that support backpropagation.
"""
import torch
import torch.nn as nn
import torch.nn.functional as F

__all__ = ["PreLoss"]


class PreLoss(nn.Module):
    """Pre-training loss combining boundary, texture, and prior consistency.

    The total loss is:

    ``L_pre = w_boundary * L_boundary + w_texture * L_texture + w_prior * L_prior``

    where each component is implemented as a simplified MSE objective:

    * **Boundary preservation** (``L_boundary``): MSE between the predicted
      edge/heat map and the ground-truth boundary target.
    * **Texture consistency** (``L_texture``): MSE between a predicted
      texture feature map and a derived texture target (e.g. local variance
      of the input image).
    * **Coarse prior consistency** (``L_prior``): MSE between the predicted
      coarse segmentation prior and a down-sampled, smoothed version of the
      ground-truth mask.

    This MVP formulation keeps the pre-training stage lightweight while
    still providing meaningful gradient signals to the encoder backbone.

    Args:
        w_boundary: Weight for the boundary preservation term.
        w_texture: Weight for the texture consistency term.
        w_prior: Weight for the coarse prior consistency term.
    """

    def __init__(
        self,
        w_boundary: float = 1.0,
        w_texture: float = 0.5,
        w_prior: float = 1.0,
    ):
        super().__init__()
        self.w_boundary = w_boundary
        self.w_texture = w_texture
        self.w_prior = w_prior

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _boundary_preservation(
        pred_boundary: torch.Tensor,
        edge_target: torch.Tensor,
    ) -> torch.Tensor:
        """MSE between predicted boundary and ground-truth edge target.

        Args:
            pred_boundary: Predicted boundary map (after sigmoid),
                shape ``[B, 1, H, W]``.
            edge_target: Ground-truth boundary, shape ``[B, 1, H, W]``.

        Returns:
            Scalar MSE loss.
        """
        return F.mse_loss(pred_boundary, edge_target)

    @staticmethod
    def _texture_consistency(
        pred_texture: torch.Tensor,
        image: torch.Tensor,
    ) -> torch.Tensor:
        """MSE between predicted texture features and a simple texture proxy.

        The texture proxy is computed as the local variance of the input
        image, a fast differentiable approximation that does not require
        additional labels.

        Args:
            pred_texture: Predicted texture map, shape ``[B, C, H, W]``.
            image: Input image, shape ``[B, 1, H, W]``.

        Returns:
            Scalar MSE loss.  If channel dimensions do not match, a
            projection is applied via adaptive average pooling.
        """
        # Compute local variance as a simple texture proxy
        # Use a 3x3 uniform filter to get local mean, then compute variance
        kernel_size = 3
        padding = kernel_size // 2

        # Local mean via average pooling then upsampling back
        local_mean = F.avg_pool2d(
            image, kernel_size=kernel_size, stride=1, padding=padding
        )
        local_sq_mean = F.avg_pool2d(
            image ** 2, kernel_size=kernel_size, stride=1, padding=padding
        )
        local_var = local_sq_mean - local_mean ** 2
        local_var = local_var.clamp(min=0.0)

        # If pred_texture has more channels, average them for comparison
        if pred_texture.shape[1] != local_var.shape[1]:
            pred_texture_proj = pred_texture.mean(dim=1, keepdim=True)
        else:
            pred_texture_proj = pred_texture

        # Match spatial dimensions
        if pred_texture_proj.shape[2:] != local_var.shape[2:]:
            local_var = F.interpolate(
                local_var,
                size=pred_texture_proj.shape[2:],
                mode="bilinear",
                align_corners=False,
            )

        return F.mse_loss(pred_texture_proj, local_var.detach())

    @staticmethod
    def _coarse_prior_consistency(
        pred_prior: torch.Tensor,
        mask_target: torch.Tensor,
        downsample_factor: int = 4,
    ) -> torch.Tensor:
        """MSE between predicted coarse prior and down-sampled mask.

        The coarse prior target is obtained by down-sampling and smoothing
        the ground-truth mask, encouraging the network to learn a coarse
        localisation of the lesion before refining boundaries.

        Args:
            pred_prior: Predicted coarse prior (after sigmoid),
                shape ``[B, 1, H, W]``.
            mask_target: Ground-truth binary mask, shape ``[B, 1, H, W]``.
            downsample_factor: Factor by which to downsample the mask target.

        Returns:
            Scalar MSE loss.
        """
        h, w = mask_target.shape[2], mask_target.shape[3]
        target_h = max(h // downsample_factor, 1)
        target_w = max(w // downsample_factor, 1)

        # Downsample the mask
        coarse_target = F.interpolate(
            mask_target,
            size=(target_h, target_w),
            mode="bilinear",
            align_corners=False,
        )
        # Smooth with a Gaussian-like blur (average pooling)
        if target_h >= 3 and target_w >= 3:
            coarse_target = F.avg_pool2d(
                coarse_target, kernel_size=3, stride=1, padding=1
            )

        # Upsample back to match prediction
        coarse_target = F.interpolate(
            coarse_target,
            size=pred_prior.shape[2:],
            mode="bilinear",
            align_corners=False,
        )

        return F.mse_loss(pred_prior, coarse_target.detach())

    # ------------------------------------------------------------------
    # Forward
    # ------------------------------------------------------------------

    def forward(
        self,
        pred_boundary: torch.Tensor | None = None,
        edge_target: torch.Tensor | None = None,
        pred_texture: torch.Tensor | None = None,
        image: torch.Tensor | None = None,
        pred_prior: torch.Tensor | None = None,
        mask_target: torch.Tensor | None = None,
    ) -> torch.Tensor:
        """Compute the combined pre-training loss.

        Each component is included only when the required arguments are
        provided (not ``None``).  This allows flexible use in different
        pre-training configurations.

        Args:
            pred_boundary: Predicted boundary map ``[B, 1, H, W]``.
            edge_target: Ground-truth boundary ``[B, 1, H, W]``.
            pred_texture: Predicted texture map ``[B, C, H, W]``.
            image: Input image ``[B, 1, H, W]``.
            pred_prior: Predicted coarse prior ``[B, 1, H, W]``.
            mask_target: Ground-truth binary mask ``[B, 1, H, W]``.

        Returns:
            Scalar pre-training loss.  Returns ``0.0`` (with gradient) if
            none of the components can be computed.
        """
        loss = torch.tensor(0.0, device="cpu")
        has_component = False

        if pred_boundary is not None and edge_target is not None:
            loss = loss + self.w_boundary * self._boundary_preservation(
                pred_boundary, edge_target
            )
            has_component = True

        if pred_texture is not None and image is not None:
            loss = loss + self.w_texture * self._texture_consistency(
                pred_texture, image
            )
            has_component = True

        if pred_prior is not None and mask_target is not None:
            loss = loss + self.w_prior * self._coarse_prior_consistency(
                pred_prior, mask_target
            )
            has_component = True

        if not has_component:
            return torch.tensor(0.0, requires_grad=True)

        return loss
