"""Logging configuration for JwzTumor."""
import logging
import sys
from pathlib import Path
from typing import Optional


def setup_logging(
    level: int = logging.INFO,
    log_file: Optional[str] = None,
    log_dir: Optional[str] = None,
    experiment_name: str = "",
    use_rich: bool = False,
) -> None:
    """Configure logging with console and optional file output.

    Args:
        level: Logging level.
        log_file: Optional log file path.
        log_dir: Optional log directory (creates train.log inside).
        experiment_name: Optional experiment name for log file.
        use_rich: If True, use Rich console handlers instead of plain text.
    """
    fmt = "%(asctime)s | %(levelname)-8s | %(name)s | %(message)s"
    datefmt = "%Y-%m-%d %H:%M:%S"

    handlers: list[logging.Handler] = []

    # Console handler
    if use_rich:
        from .rich_display import get_active_display

        active_display = get_active_display()
        if active_display is not None:
            # Verbose mode: route logs into the live display panel
            from .rich_display import LiveDisplayLogHandler

            console_handler = LiveDisplayLogHandler(active_display)
            console_handler.setFormatter(
                logging.Formatter("%(asctime)s %(message)s", datefmt="%H:%M:%S")
            )
        else:
            # Non-verbose Rich mode: pretty console output
            from rich.console import Console
            from rich.logging import RichHandler

            console_handler = RichHandler(
                console=Console(stderr=True),
                show_time=True,
                show_path=False,
                markup=True,
            )
    else:
        console_handler = logging.StreamHandler(sys.stdout)
        console_handler.setFormatter(logging.Formatter(fmt, datefmt))

    console_handler.setLevel(level)
    handlers.append(console_handler)

    # File handler
    if log_file:
        if use_rich:
            from .rich_display import setup_file_log
            file_handle = setup_file_log(log_file)
            fh = logging.StreamHandler(file_handle)
        else:
            fh = logging.FileHandler(log_file, encoding="utf-8")
        fh.setFormatter(logging.Formatter(fmt, datefmt))
        fh.setLevel(level)
        handlers.append(fh)
    elif log_dir:
        log_path = Path(log_dir)
        log_path.mkdir(parents=True, exist_ok=True)
        fname = f"{experiment_name}.log" if experiment_name else "train.log"
        if use_rich:
            from .rich_display import setup_file_log
            file_handle = setup_file_log(str(log_path / fname))
            fh = logging.StreamHandler(file_handle)
        else:
            fh = logging.FileHandler(log_path / fname, encoding="utf-8")
        fh.setFormatter(logging.Formatter(fmt, datefmt))
        fh.setLevel(level)
        handlers.append(fh)

    logging.basicConfig(
        level=level,
        format=fmt,
        datefmt=datefmt,
        handlers=handlers,
        force=True,
    )

    # Quieten overly verbose libraries
    logging.getLogger("PIL").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)
