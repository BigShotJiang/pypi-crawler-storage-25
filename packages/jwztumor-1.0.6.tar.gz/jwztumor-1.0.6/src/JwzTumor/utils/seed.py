"""Seeding utilities for reproducibility."""
import os
import random
import logging

import numpy as np
import torch

logger = logging.getLogger(__name__)


def set_seed(seed: int = 42, deterministic: bool = False) -> None:
    """Set random seeds for all relevant libraries.

    Args:
        seed: Random seed value.
        deterministic: If True, enable deterministic CUDA operations.
    """
    random.seed(seed)
    os.environ["PYTHONHASHSEED"] = str(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)

    if deterministic:
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False
        os.environ["CUBLAS_WORKSPACE_CONFIG"] = ":4096:8"
    else:
        torch.backends.cudnn.benchmark = True

    logger.info("Seed set to %d (deterministic=%s)", seed, deterministic)


def get_seed_generator(seed: int = 42):
    """Return a namespace with the seed for worker init."""
    import types
    g = types.SimpleNamespace(seed=seed)
    return g
