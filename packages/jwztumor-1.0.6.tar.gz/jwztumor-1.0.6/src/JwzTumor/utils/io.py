"""File I/O utilities for JwzTumor."""
import json
import csv
import logging
from pathlib import Path
from typing import Any, Dict, List, Optional, Union

import numpy as np
import torch

logger = logging.getLogger(__name__)


def save_json(data: Dict[str, Any], path: Union[str, Path]) -> None:
    """Save dict to JSON file."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False, default=_json_default)
    logger.debug("JSON saved to %s", path)


def load_json(path: Union[str, Path]) -> Dict[str, Any]:
    """Load dict from JSON file."""
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def save_predictions_csv(
    rows: List[Dict[str, Any]],
    path: Union[str, Path],
) -> None:
    """Save predictions to CSV file."""
    if not rows:
        return
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fieldnames = list(rows[0].keys())
    with open(path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)
    logger.info("Predictions saved to %s (%d rows)", path, len(rows))


def save_tensor_as_image(
    tensor: torch.Tensor,
    path: Union[str, Path],
) -> None:
    """Save a 2D tensor [H, W] or [1, H, W] as a PNG image."""
    try:
        from PIL import Image
    except ImportError:
        logger.warning("PIL not available, cannot save image to %s", path)
        return

    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)

    arr = tensor.detach().cpu().numpy()
    if arr.ndim == 3 and arr.shape[0] == 1:
        arr = arr[0]

    arr = np.clip(arr * 255, 0, 255).astype(np.uint8)
    img = Image.fromarray(arr, mode="L")
    img.save(str(path))


def save_checkpoint(
    state_dict: Dict[str, Any],
    path: Union[str, Path],
) -> None:
    """Save model checkpoint."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    torch.save(state_dict, str(path))
    logger.info("Checkpoint saved to %s", path)


def load_checkpoint(
    path: Union[str, Path],
    map_location: str = "cpu",
) -> Dict[str, Any]:
    """Load model checkpoint."""
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"Checkpoint not found: {path}")
    return torch.load(str(path), map_location=map_location, weights_only=False)


def _json_default(obj: Any) -> Any:
    """JSON serialization fallback."""
    if isinstance(obj, (np.integer,)):
        return int(obj)
    if isinstance(obj, (np.floating,)):
        return float(obj)
    if isinstance(obj, np.ndarray):
        return obj.tolist()
    if isinstance(obj, torch.Tensor):
        return obj.detach().cpu().tolist()
    if isinstance(obj, Path):
        return str(obj)
    raise TypeError(f"Object of type {type(obj)} is not JSON serializable")
