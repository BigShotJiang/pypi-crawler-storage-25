"""Module registry for JwzTumor."""
from typing import Any, Callable, Dict, Type

_REGISTRY: Dict[str, Dict[str, Any]] = {}


def register(category: str, name: str):
    """Decorator to register a class or function under a category and name.

    Usage:
        @register("loss", "dice_bce")
        class DiceBCELoss(nn.Module): ...
    """
    def decorator(cls_or_fn):
        if category not in _REGISTRY:
            _REGISTRY[category] = {}
        _REGISTRY[category][name] = cls_or_fn
        return cls_or_fn
    return decorator


def get(category: str, name: str) -> Any:
    """Retrieve a registered item by category and name."""
    if category not in _REGISTRY or name not in _REGISTRY[category]:
        raise KeyError(f"'{name}' not found in registry category '{category}'")
    return _REGISTRY[category][name]


def list_available(category: str) -> list:
    """List all registered names in a category."""
    return list(_REGISTRY.get(category, {}).keys())


def get_registry() -> Dict[str, Dict[str, Any]]:
    """Return the full registry dict."""
    return _REGISTRY
