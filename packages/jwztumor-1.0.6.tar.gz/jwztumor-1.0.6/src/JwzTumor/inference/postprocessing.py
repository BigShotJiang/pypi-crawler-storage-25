"""Post-processing for segmentation and classification outputs."""
import logging
from typing import Dict, Optional

import numpy as np
import torch

from ..data.mask_utils import largest_connected_component, remove_small_regions

logger = logging.getLogger(__name__)


def postprocess_segmentation(
    seg_prob: torch.Tensor,
    threshold: float = 0.5,
    use_largest_component: bool = True,
    min_region_size: int = 100,
) -> torch.Tensor:
    """Post-process segmentation probability map.

    Steps:
        1. Threshold
        2. Largest connected component
        3. Small region removal

    Args:
        seg_prob: [B, 1, H, W] or [1, H, W] probability map.
        threshold: Binarization threshold.
        use_largest_component: Keep only largest component.
        min_region_size: Minimum region size in pixels.

    Returns:
        Binary mask tensor.
    """
    if seg_prob.dim() == 3:
        seg_prob = seg_prob.unsqueeze(0)

    mask = (seg_prob >= threshold).float()

    result = mask.clone()
    for i in range(result.shape[0]):
        m = result[i, 0].numpy()
        if use_largest_component:
            m = largest_connected_component(m)
        m = remove_small_regions(m, min_size=min_region_size)
        result[i, 0] = torch.from_numpy(m)

    return result


def postprocess_classification(
    cls_prob: torch.Tensor,
    temperature: float = 1.0,
) -> Dict[str, any]:
    """Post-process classification probabilities.

    Args:
        cls_prob: [2] or [B, 2] probability tensor.
        temperature: Temperature scaling factor.

    Returns:
        Dict with pred_label, prob_benign, prob_malignant.
    """
    if cls_prob.dim() == 1:
        cls_prob = cls_prob.unsqueeze(0)

    # Temperature scaling
    if temperature != 1.0:
        logits = torch.log(cls_prob + 1e-8) / temperature
        cls_prob = torch.softmax(logits, dim=-1)

    prob = cls_prob[0]
    pred_label = int(prob.argmax().item())
    prob_benign = float(prob[0].item())
    prob_malignant = float(prob[1].item())

    return {
        "pred_label": pred_label,
        "prob_benign": prob_benign,
        "prob_malignant": prob_malignant,
    }


def threshold_search(
    probs: np.ndarray,
    labels: np.ndarray,
    metric: str = "f1",
    num_thresholds: int = 100,
) -> float:
    """Search for optimal threshold on validation data.

    Args:
        probs: Predicted probabilities for malignant class.
        labels: True binary labels.
        metric: Metric to optimize ("f1", "sensitivity", "dice").
        num_thresholds: Number of thresholds to evaluate.

    Returns:
        Optimal threshold value.
    """
    from sklearn.metrics import f1_score

    best_threshold = 0.5
    best_score = 0.0

    for t in np.linspace(0.1, 0.9, num_thresholds):
        preds = (probs >= t).astype(int)
        if metric == "f1":
            score = f1_score(labels, preds, zero_division=0)
        elif metric == "sensitivity":
            tp = ((preds == 1) & (labels == 1)).sum()
            fn = ((preds == 0) & (labels == 1)).sum()
            score = tp / max(tp + fn, 1)
        else:
            score = f1_score(labels, preds, zero_division=0)

        if score > best_score:
            best_score = score
            best_threshold = float(t)

    logger.info("Optimal threshold: %.3f (score=%.4f)", best_threshold, best_score)
    return best_threshold
