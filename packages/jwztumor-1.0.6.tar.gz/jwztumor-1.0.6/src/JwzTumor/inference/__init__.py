"""Inference modules for JwzTumor."""
