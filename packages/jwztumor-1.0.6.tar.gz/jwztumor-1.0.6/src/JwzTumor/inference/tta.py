"""Test-Time Augmentation for JwzTumor."""
import logging
from typing import Dict, List, Optional

import torch
import torch.nn as nn

logger = logging.getLogger(__name__)


def apply_tta(
    model: nn.Module,
    images: torch.Tensor,
    scales: Optional[List[float]] = None,
    use_flip: bool = True,
    device: Optional[torch.device] = None,
) -> Dict[str, torch.Tensor]:
    """Apply Test-Time Augmentation and aggregate predictions.

    Args:
        model: Model in eval mode.
        images: Input images [B, C, H, W].
        scales: List of scale factors (default [0.9, 1.0, 1.1]).
        use_flip: Whether to include horizontal flip.
        device: Device to run on.

    Returns:
        Aggregated outputs dict.
    """
    scales = scales or [0.9, 1.0, 1.1]
    device = device or next(model.parameters()).device

    all_cls_probs = []
    all_seg_probs = []
    all_edge_probs = []
    all_sdm_preds = []
    all_uncertainties = []

    with torch.no_grad():
        for scale in scales:
            # Scale input
            if abs(scale - 1.0) > 0.01:
                import torch.nn.functional as F
                _, _, h, w = images.shape
                new_h, new_w = int(h * scale), int(w * scale)
                scaled = F.interpolate(images, size=(new_h, new_w), mode="bilinear", align_corners=False)
                # Pad back to original size
                if new_h < h or new_w < w:
                    pad_h = h - new_h
                    pad_w = w - new_w
                    scaled = F.pad(scaled, [pad_w // 2, pad_w - pad_w // 2, pad_h // 2, pad_h - pad_h // 2])
                else:
                    scaled = scaled[:, :, :h, :w]
            else:
                scaled = images

            for do_flip in ([False, True] if use_flip else [False]):
                x = scaled
                if do_flip:
                    x = torch.flip(x, [-1])

                x = x.to(device)
                outputs = model(x)

                # Reverse flip
                if do_flip:
                    for key in ["seg_prob", "edge_prob", "sdm_pred", "uncertainty_map"]:
                        if key in outputs:
                            outputs[key] = torch.flip(outputs[key], [-1])

                # Reverse scale
                if abs(scale - 1.0) > 0.01:
                    for key in ["seg_prob", "edge_prob", "sdm_pred", "uncertainty_map"]:
                        if key in outputs:
                            outputs[key] = F.interpolate(
                                outputs[key], size=(h, w),
                                mode="bilinear", align_corners=False,
                            )

                # Collect
                if "cls_prob" in outputs:
                    all_cls_probs.append(outputs["cls_prob"].cpu())
                if "seg_prob" in outputs:
                    all_seg_probs.append(outputs["seg_prob"].cpu())
                if "edge_prob" in outputs:
                    all_edge_probs.append(outputs["edge_prob"].cpu())
                if "sdm_pred" in outputs:
                    all_sdm_preds.append(outputs["sdm_pred"].cpu())
                if "uncertainty_map" in outputs:
                    all_uncertainties.append(outputs["uncertainty_map"].cpu())

    # Aggregate by averaging
    result = {}
    if all_cls_probs:
        result["cls_prob"] = torch.stack(all_cls_probs).mean(dim=0)
    if all_seg_probs:
        result["seg_prob"] = torch.stack(all_seg_probs).mean(dim=0)
    if all_edge_probs:
        result["edge_prob"] = torch.stack(all_edge_probs).mean(dim=0)
    if all_sdm_preds:
        result["sdm_pred"] = torch.stack(all_sdm_preds).mean(dim=0)
    if all_uncertainties:
        result["uncertainty_map"] = torch.stack(all_uncertainties).mean(dim=0)

    logger.debug("TTA: %d views aggregated", len(all_cls_probs))
    return result
