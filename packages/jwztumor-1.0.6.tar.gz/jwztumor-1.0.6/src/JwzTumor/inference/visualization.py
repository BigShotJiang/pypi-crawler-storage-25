"""Visualization utilities for JwzTumor predictions."""
import logging
from pathlib import Path
from typing import Any, Dict, List, Optional

import numpy as np
import torch

from ..utils.io import save_tensor_as_image, save_predictions_csv, save_json

logger = logging.getLogger(__name__)


def save_prediction_outputs(
    predictions: List[Dict[str, Any]],
    output_dir: Path,
) -> None:
    """Save all prediction outputs to disk.

    Creates:
        predictions.csv
        masks/, edges/, uncertainty/, overlays/
    """
    output_dir = Path(output_dir)
    csv_rows = []

    for pred in predictions:
        image_id = pred.get("image_id", "unknown")
        safe_id = image_id.replace(" ", "_").replace("(", "").replace(")", "")

        row = {
            "image_id": image_id,
            "pred_label": pred.get("pred_label", -1),
            "prob_benign": pred.get("prob_benign", 0),
            "prob_malignant": pred.get("prob_malignant", 0),
            "true_label": pred.get("true_label"),
        }

        # Save segmentation mask
        if pred.get("seg_mask") is not None:
            mask_dir = output_dir / "masks"
            mask_dir.mkdir(exist_ok=True)
            save_tensor_as_image(pred["seg_mask"], mask_dir / f"{safe_id}_mask.png")
            row["mask_path"] = str(mask_dir / f"{safe_id}_mask.png")

        # Save edge map
        if pred.get("edge_prob") is not None:
            edge_dir = output_dir / "edges"
            edge_dir.mkdir(exist_ok=True)
            save_tensor_as_image(pred["edge_prob"], edge_dir / f"{safe_id}_edge.png")
            row["edge_path"] = str(edge_dir / f"{safe_id}_edge.png")

        # Save uncertainty
        if pred.get("uncertainty_map") is not None:
            unc_dir = output_dir / "uncertainty"
            unc_dir.mkdir(exist_ok=True)
            save_tensor_as_image(pred["uncertainty_map"], unc_dir / f"{safe_id}_unc.png")
            row["uncertainty_path"] = str(unc_dir / f"{safe_id}_unc.png")

        # Save overlay
        if pred.get("seg_mask") is not None:
            overlay_dir = output_dir / "overlays"
            overlay_dir.mkdir(exist_ok=True)
            try:
                overlay = create_overlay(pred)
                save_tensor_as_image(overlay, overlay_dir / f"{safe_id}_overlay.png")
                row["overlay_path"] = str(overlay_dir / f"{safe_id}_overlay.png")
            except Exception as e:
                logger.debug("Overlay failed for %s: %s", image_id, e)

        csv_rows.append(row)

    # Save CSV
    save_predictions_csv(csv_rows, output_dir / "predictions.csv")


def create_overlay(pred: Dict[str, Any]) -> torch.Tensor:
    """Create overlay visualization from prediction.

    Returns:
        [H, W] tensor with overlay (grayscale).
    """
    seg_mask = pred.get("seg_mask", None)
    if seg_mask is None:
        return torch.zeros(1, 64, 64)

    if seg_mask.dim() == 3:
        seg_mask = seg_mask[0]

    # Simple overlay: highlight segmentation boundary
    overlay = torch.zeros_like(seg_mask)
    overlay[seg_mask > 0.5] = 0.7
    return overlay
