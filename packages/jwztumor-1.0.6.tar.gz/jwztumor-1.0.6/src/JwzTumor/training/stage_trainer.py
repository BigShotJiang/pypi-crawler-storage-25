"""Stage-aware trainer for JwzTumor multi-task training."""
import copy
import logging
import time
from pathlib import Path
from typing import Dict, Optional

import torch
import torch.nn as nn

from .callbacks import EarlyStopping, MultiMetricCheckpoint
from .scheduler import create_optimizer, create_scheduler, apply_freeze

logger = logging.getLogger(__name__)


class StageTrainer:
    """Trainer with stage-aware loss computation, freezing, and multi-metric tracking.

    Supports four training stages:
        - pretrain_pre: LABDG-Pre only
        - pretrain_seg: DGBC-MTLNet segmentation only
        - train_cls: MPTC-Head classification only
        - finetune_all: End-to-end joint fine-tuning
    """

    def __init__(
        self,
        config,
        model: nn.Module,
        train_loader,
        val_loader,
        test_loader=None,
        loss_factory=None,
        display=None,
        start_epoch: int = 0,
        optimizer_state=None,
        scheduler_state=None,
        scaler_state=None,
        history=None,
        best_values=None,
    ):
        self.config = config
        self.model = model
        self.train_loader = train_loader
        self.val_loader = val_loader
        self.test_loader = test_loader
        self.loss_factory = loss_factory
        self.display = display

        self.stage = config.training.stage
        self.epochs = config.training.epochs
        self.current_epoch = start_epoch

        # Device
        device_str = config.training.device
        if device_str == "auto":
            device_str = "cuda" if torch.cuda.is_available() else "cpu"
        self.device = torch.device(device_str)
        self.model.to(self.device)

        # Apply freezing for current stage
        apply_freeze(self.model, self.stage, config)

        # Optimizer & Scheduler
        self.optimizer = create_optimizer(self.model, config, stage=self.stage)
        self.scheduler = create_scheduler(
            self.optimizer, config,
            steps_per_epoch=len(train_loader) if train_loader else 1,
        )

        # Restore optimizer & scheduler state from checkpoint
        if optimizer_state is not None:
            self.optimizer.load_state_dict(optimizer_state)
            logger.info("Restored optimizer state from checkpoint")
        if scheduler_state is not None and self.scheduler is not None:
            self.scheduler.load_state_dict(scheduler_state)
            logger.info("Restored scheduler state from checkpoint")

        # AMP
        self.use_amp = config.training.mixed_precision and self.device.type == "cuda"
        self.scaler = torch.amp.GradScaler("cuda") if self.use_amp else None

        # Restore scaler state
        if scaler_state is not None and self.scaler is not None:
            self.scaler.load_state_dict(scaler_state)
            logger.info("Restored GradScaler state from checkpoint")

        # Checkpointing
        ckpt_cfg = config.checkpoint
        monitor_metrics = {}
        if ckpt_cfg.save_best_auc:
            monitor_metrics["val_auc"] = {"mode": "max"}
        if ckpt_cfg.save_best_acc:
            monitor_metrics["val_accuracy"] = {"mode": "max"}
        if ckpt_cfg.save_best_f1:
            monitor_metrics["val_f1"] = {"mode": "max"}
        if ckpt_cfg.save_best_sensitivity:
            monitor_metrics["val_sensitivity"] = {"mode": "max"}
        if ckpt_cfg.save_best_dice:
            monitor_metrics["val_dice"] = {"mode": "max"}

        exp_dir = Path(config.experiment.save_dir) / config.experiment.name
        self.checkpoint_callback = MultiMetricCheckpoint(
            checkpoint_dir=str(exp_dir / "checkpoints"),
            monitor_metrics=monitor_metrics,
        )

        # Restore best_values into checkpoint callback
        if best_values is not None:
            self.checkpoint_callback.best_values = dict(best_values)
            logger.info("Restored best_values: %s", best_values)

        # Early stopping
        es_cfg = config.monitoring.early_stopping
        self.early_stopping = None
        if es_cfg.get("enabled", True):
            self.early_stopping = EarlyStopping(
                patience=es_cfg.get("patience", 10),
                min_delta=es_cfg.get("min_delta", 0.001),
                mode=es_cfg.get("mode", "min"),
            )

        # State
        self.history = list(history) if history else []

    def train(self) -> Dict:
        """Run the full training loop. Returns summary dict."""
        from ..utils.rich_display import print_epoch_summary

        logger.info(
            "Starting stage=%s, epochs=%d, device=%s, amp=%s",
            self.stage, self.epochs, self.device, self.use_amp,
        )

        for epoch in range(self.current_epoch, self.epochs):
            self.current_epoch = epoch
            t0 = time.time()

            train_metrics = self._train_epoch(epoch)
            val_metrics = self._validate_epoch()

            combined = {**train_metrics, **val_metrics}
            combined["epoch"] = epoch + 1  # 1-based for display
            combined["lr"] = self.optimizer.param_groups[0]["lr"]
            combined["epoch_time"] = time.time() - t0
            combined["stage"] = self.stage

            # File logging
            train_parts = [f"{k}={v:.4f}" for k, v in train_metrics.items() if isinstance(v, float)]
            val_parts = [f"{k}={v:.4f}" for k, v in val_metrics.items() if isinstance(v, float)]
            logger.info(
                "[%s] Epoch %d/%d  train: %s | val: %s | lr=%s | time=%.1fs",
                self.stage, epoch + 1, self.epochs,
                " | ".join(train_parts) if train_parts else "N/A",
                " | ".join(val_parts) if val_parts else "N/A",
                f"{combined['lr']:.1e}" if combined["lr"] < 0.001 else f"{combined['lr']:.6f}",
                combined["epoch_time"],
            )

            # Rich epoch summary table (stderr)
            print_epoch_summary(epoch + 1, self.epochs, self.stage, combined)

            self.history.append(combined)

            # Update display with key metrics
            if self.display is not None:
                postfix_parts = []
                for key in ("train_loss", "val_loss", "val_auc", "val_dice", "val_f1"):
                    val = combined.get(key)
                    if val is not None and isinstance(val, float):
                        postfix_parts.append(f"{key}={val:.4f}")
                lr = combined.get("lr")
                if lr is not None:
                    postfix_parts.append(f"lr={lr:.1e}" if lr < 0.001 else f"lr={lr:.4f}")
                self.display.update_progress(
                    advance=1,
                    postfix="  ".join(postfix_parts),
                )

            # Checkpoints (save epoch as 1-based)
            self.checkpoint_callback(
                metrics=combined,
                model_state=self.model.state_dict(),
                optimizer_state=self.optimizer.state_dict(),
                scheduler_state=self.scheduler.state_dict() if self.scheduler else None,
                scaler_state=self.scaler.state_dict() if self.scaler else None,
                epoch=epoch,
                config_snapshot=self.config.config_snapshot(),
                history=self.history,
                best_values=dict(self.checkpoint_callback.best_values),
            )

            # Early stopping
            if self.early_stopping is not None:
                monitor_val = combined.get(
                    self.config.monitoring.early_stopping.get("metric", "val_loss")
                )
                if monitor_val is not None and self.early_stopping(monitor_val):
                    break

            # Scheduler step
            if self.scheduler is not None:
                if isinstance(self.scheduler, torch.optim.lr_scheduler.ReduceLROnPlateau):
                    self.scheduler.step(combined.get("val_loss", 0))
                else:
                    self.scheduler.step()

        return {
            "stage": self.stage,
            "total_epochs": len(self.history),
            "history": self.history,
        }

    def _train_epoch(self, epoch: int) -> Dict:
        """Run one training epoch."""
        self.model.train()
        total_loss = 0.0
        num_batches = 0

        accum = max(1, self.config.training.accumulate_grad_batches)
        grad_clip = self.config.training.gradient_clip_val
        num_batches_total = len(self.train_loader)

        for batch_idx, batch in enumerate(self.train_loader):
            # Move all relevant tensors to device in-place
            images = batch["image"].to(self.device, non_blocking=True)
            batch["image"] = images
            labels = batch["label"].to(self.device, non_blocking=True)
            batch["label"] = labels
            masks = batch.get("mask", None)
            edges = batch.get("edge", None)
            sdms = batch.get("sdm", None)
            has_masks = batch.get("has_mask", None)

            if masks is not None:
                masks = masks.to(self.device, non_blocking=True)
                batch["mask"] = masks
            if edges is not None:
                edges = edges.to(self.device, non_blocking=True)
                batch["edge"] = edges
            if sdms is not None:
                sdms = sdms.to(self.device, non_blocking=True)
                batch["sdm"] = sdms
            if has_masks is not None:
                batch["has_mask"] = has_masks.to(self.device)

            # Forward + backward
            if self.use_amp:
                with torch.amp.autocast("cuda"):
                    outputs = self.model(images, masks, edges, sdms, labels)
                    loss = self._compute_loss(outputs, batch)
                self.scaler.scale(loss / accum).backward()

                should_step = (batch_idx + 1) % accum == 0 or (batch_idx + 1) == num_batches_total
                if should_step:
                    if grad_clip > 0:
                        self.scaler.unscale_(self.optimizer)
                        nn.utils.clip_grad_norm_(self.model.parameters(), grad_clip)
                    self.scaler.step(self.optimizer)
                    self.scaler.update()
                    self.optimizer.zero_grad(set_to_none=True)
            else:
                outputs = self.model(images, masks, edges, sdms, labels)
                loss = self._compute_loss(outputs, batch)
                (loss / accum).backward()

                should_step = (batch_idx + 1) % accum == 0 or (batch_idx + 1) == num_batches_total
                if should_step:
                    if grad_clip > 0:
                        nn.utils.clip_grad_norm_(self.model.parameters(), grad_clip)
                    self.optimizer.step()
                    self.optimizer.zero_grad(set_to_none=True)

            total_loss += loss.item()
            num_batches += 1

            # Update batch-level postfix on display
            if self.display is not None and (batch_idx + 1) % 5 == 0:
                avg_so_far = total_loss / num_batches
                self.display.set_postfix(
                    f"train batch {batch_idx+1}/{num_batches_total}  loss={avg_so_far:.4f}"
                )

        avg_loss = total_loss / max(num_batches, 1)
        return {"train_loss": avg_loss}

    def _validate_epoch(self) -> Dict:
        """Run validation."""
        self.model.eval()
        total_loss = 0.0
        num_batches = 0
        all_cls_probs = []
        all_labels = []
        all_dice = []

        with torch.no_grad():
            for batch in self.val_loader:
                images = batch["image"].to(self.device, non_blocking=True)
                batch["image"] = images
                labels = batch["label"].to(self.device, non_blocking=True)
                batch["label"] = labels
                masks = batch.get("mask")
                edges = batch.get("edge")
                sdms = batch.get("sdm")

                if masks is not None:
                    masks = masks.to(self.device, non_blocking=True)
                    batch["mask"] = masks
                if edges is not None:
                    edges = edges.to(self.device, non_blocking=True)
                    batch["edge"] = edges
                if sdms is not None:
                    sdms = sdms.to(self.device, non_blocking=True)
                    batch["sdm"] = sdms

                outputs = self.model(images, masks, edges, sdms, labels)
                loss = self._compute_loss(outputs, batch)
                total_loss += loss.item()
                num_batches += 1

                # Update validation batch progress on display
                if self.display is not None and (num_batches % 5 == 0):
                    avg_so_far = total_loss / num_batches
                    self.display.set_postfix(
                        f"val batch {num_batches}/{len(self.val_loader)}  val_loss={avg_so_far:.4f}"
                    )

                # Collect predictions
                if "cls_prob" in outputs:
                    probs = outputs["cls_prob"][:, 1].cpu().numpy()
                    all_cls_probs.extend(probs.tolist())
                    all_labels.extend(labels.cpu().numpy().tolist())

                if "seg_prob" in outputs and masks is not None:
                    seg = (outputs["seg_prob"] > 0.5).float()
                    intersection = (seg * masks).sum()
                    union = seg.sum() + masks.sum()
                    if union > 0:
                        all_dice.append((2 * intersection / union).item())

        import numpy as np
        avg_loss = total_loss / max(num_batches, 1)
        metrics = {"val_loss": avg_loss}

        # Classification metrics
        if len(all_cls_probs) > 0 and len(set(all_labels)) > 1:
            y_true = np.array(all_labels)
            y_prob = np.array(all_cls_probs)
            y_pred = (y_prob >= 0.5).astype(int)

            metrics["val_accuracy"] = float((y_true == y_pred).mean())

            try:
                from sklearn.metrics import roc_auc_score
                metrics["val_auc"] = float(roc_auc_score(y_true, y_prob))
            except (ImportError, ValueError):
                pass

            tp = ((y_pred == 1) & (y_true == 1)).sum()
            fn = ((y_pred == 0) & (y_true == 1)).sum()
            fp = ((y_pred == 1) & (y_true == 0)).sum()
            tn = ((y_pred == 0) & (y_true == 0)).sum()

            sensitivity = tp / max(tp + fn, 1)
            specificity = tn / max(tn + fp, 1)
            precision = tp / max(tp + fp, 1)
            f1 = 2 * precision * sensitivity / max(precision + sensitivity, 1e-8)

            metrics["val_sensitivity"] = float(sensitivity)
            metrics["val_specificity"] = float(specificity)
            metrics["val_precision"] = float(precision)
            metrics["val_f1"] = float(f1)

        # Segmentation metrics
        if all_dice:
            metrics["val_dice"] = float(np.mean(all_dice))

        return metrics

    def _compute_loss(self, outputs: Dict, batch: Dict) -> torch.Tensor:
        """Compute loss using the loss factory or a simple fallback."""
        if self.loss_factory is not None:
            result = self.loss_factory(outputs, batch)
            if isinstance(result, dict):
                self._last_loss_dict = result.get("loss_dict", {})
                return result["total_loss"]
            return result

        # Fallback: simple combined loss
        has_mask = batch.get("has_mask")
        labels = batch["label"].to(self.device)
        masks = batch.get("mask")
        if masks is not None:
            masks = masks.to(self.device)

        loss = torch.tensor(0.0, device=self.device, requires_grad=True)

        # Classification loss
        if "cls_logits" in outputs and self.stage in ("train_cls", "finetune_all"):
            cls_loss = nn.functional.cross_entropy(outputs["cls_logits"], labels)
            loss = loss + cls_loss

        # Segmentation loss
        if "seg_logits" in outputs and masks is not None and self.stage in ("pretrain_seg", "finetune_all"):
            seg_loss = nn.functional.binary_cross_entropy_with_logits(
                outputs["seg_logits"], masks, reduction="mean"
            )
            loss = loss + seg_loss

        return loss
