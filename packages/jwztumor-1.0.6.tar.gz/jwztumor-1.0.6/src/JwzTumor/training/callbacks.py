"""Early stopping and checkpoint callbacks for JwzTumor."""
import logging
from pathlib import Path
from typing import Dict, Optional
from copy import deepcopy

import torch

logger = logging.getLogger(__name__)


class EarlyStopping:
    """Early stopping callback based on a monitored metric."""

    def __init__(
        self,
        patience: int = 10,
        min_delta: float = 0.001,
        mode: str = "min",
    ):
        self.patience = patience
        self.min_delta = min_delta
        self.mode = mode
        self.counter = 0
        self.best_score: Optional[float] = None
        self.should_stop = False

    def __call__(self, metric_value: float) -> bool:
        """Check if training should stop.

        Returns:
            True if training should stop.
        """
        if self.best_score is None:
            self.best_score = metric_value
            return False

        if self.mode == "min":
            improved = metric_value < (self.best_score - self.min_delta)
        else:
            improved = metric_value > (self.best_score + self.min_delta)

        if improved:
            self.best_score = metric_value
            self.counter = 0
        else:
            self.counter += 1
            if self.counter >= self.patience:
                self.should_stop = True
                logger.info(
                    "Early stopping triggered after %d epochs without improvement",
                    self.patience,
                )
                return True

        return False


class MultiMetricCheckpoint:
    """Checkpoint callback that saves best models for multiple metrics."""

    def __init__(
        self,
        checkpoint_dir: str,
        monitor_metrics: Optional[Dict[str, Dict]] = None,
    ):
        """
        Args:
            checkpoint_dir: Directory to save checkpoints.
            monitor_metrics: Dict of {metric_name: {"mode": "max"/"min"}}.
        """
        self.checkpoint_dir = Path(checkpoint_dir)
        self.checkpoint_dir.mkdir(parents=True, exist_ok=True)
        self.monitor_metrics = monitor_metrics or {
            "val_auc": {"mode": "max"},
        }
        self.best_values: Dict[str, float] = {}

    def __call__(
        self,
        metrics: Dict[str, float],
        model_state: Dict,
        optimizer_state: Optional[Dict] = None,
        scheduler_state: Optional[Dict] = None,
        scaler_state: Optional[Dict] = None,
        epoch: int = 0,
        config_snapshot: Optional[Dict] = None,
        history: Optional[list] = None,
        best_values: Optional[Dict[str, float]] = None,
    ) -> Dict[str, bool]:
        """Check and save checkpoints if metrics improved.

        Returns:
            Dict of {metric_name: was_saved}.
        """
        saved = {}
        checkpoint = {
            "epoch": epoch,
            "model_state_dict": model_state,
            "config_snapshot": config_snapshot,
        }
        if optimizer_state is not None:
            checkpoint["optimizer_state_dict"] = optimizer_state
        if scheduler_state is not None:
            checkpoint["scheduler_state_dict"] = scheduler_state
        if scaler_state is not None:
            checkpoint["scaler_state_dict"] = scaler_state
        if history is not None:
            checkpoint["history"] = history
        if best_values is not None:
            checkpoint["best_values"] = best_values

        for metric_name, cfg in self.monitor_metrics.items():
            mode = cfg.get("mode", "max")
            val = metrics.get(metric_name)
            if val is None:
                continue

            is_best = False
            if metric_name not in self.best_values:
                is_best = True
            elif mode == "max" and val > self.best_values[metric_name]:
                is_best = True
            elif mode == "min" and val < self.best_values[metric_name]:
                is_best = True

            if is_best:
                self.best_values[metric_name] = val
                fname = f"best_{metric_name.replace('val_', '')}.ckpt"
                path = self.checkpoint_dir / fname
                torch.save(checkpoint, str(path))
                logger.info("Saved best %s: %.6f -> %s", metric_name, val, path)

            saved[metric_name] = is_best

        # Always save latest
        latest_path = self.checkpoint_dir / "latest_model.ckpt"
        torch.save(checkpoint, str(latest_path))

        return saved
