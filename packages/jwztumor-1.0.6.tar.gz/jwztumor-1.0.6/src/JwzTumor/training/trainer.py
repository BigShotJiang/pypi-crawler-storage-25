"""Main trainer module - re-exports StageTrainer."""
from .stage_trainer import StageTrainer

__all__ = ["StageTrainer"]
