"""Training modules for JwzTumor."""
