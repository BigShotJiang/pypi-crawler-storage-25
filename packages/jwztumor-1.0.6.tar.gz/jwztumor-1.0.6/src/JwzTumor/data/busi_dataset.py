"""BUSI Dataset class for JwzTumor."""
import os
import re
import logging
from pathlib import Path
from typing import Any, Dict, List, Optional

import numpy as np
import torch
from torch.utils.data import Dataset

from .preprocessing import BreastUSPreprocessor
from .mask_utils import binarize_mask, union_masks, generate_edge_target, generate_sdm_target
from .augmentation import BreastUSAugmentation
from .cache import DatasetCache

logger = logging.getLogger(__name__)


class BUSIDataset(Dataset):
    """Dataset_BUSI_with_GT dataset.

    Handles:
        - Directory-based labels (benign=0, malignant=1)
        - Multi-mask OR union for BUSI images
        - Skip normal-不使用 folder
        - RGB to grayscale conversion

    Sample dict keys same as BUSBRADataset.
    """

    def __init__(
        self,
        data_root: str,
        classes: Optional[List[str]] = None,
        ignore_classes: Optional[List[str]] = None,
        preprocessor: Optional[BreastUSPreprocessor] = None,
        augmentation: Optional[BreastUSAugmentation] = None,
        cache: Optional[DatasetCache] = None,
        label_mapping: Optional[Dict[str, int]] = None,
        is_train: bool = False,
    ):
        self.data_root = Path(data_root)
        self.classes = classes or ["benign", "malignant"]
        self.ignore_classes = ignore_classes or ["normal-不使用", "normal"]
        self.preprocessor = preprocessor or BreastUSPreprocessor()
        self.augmentation = augmentation if is_train else None
        self.cache = cache
        self.label_mapping = label_mapping or {"benign": 0, "malignant": 1}
        self.is_train = is_train

        # Build sample list
        self.samples = self._build_sample_list()

        logger.info(
            "BUSI %s: %d samples from %s",
            "train" if is_train else "test",
            len(self.samples),
            self.data_root,
        )

    def _build_sample_list(self) -> List[Dict[str, Any]]:
        """Build sample list from directory structure."""
        samples = []

        for cls_name in self.classes:
            cls_dir = self.data_root / cls_name
            if not cls_dir.exists():
                logger.warning("Class directory not found: %s", cls_dir)
                continue

            label = self.label_mapping.get(cls_name, -1)
            if label < 0:
                logger.warning("Unknown class label: %s", cls_name)
                continue

            # Find original images (exclude masks)
            all_files = sorted(cls_dir.glob("*.png"))
            originals = [f for f in all_files if "_mask" not in f.name]

            for orig_path in originals:
                base = orig_path.stem
                # Find all masks for this image
                masks = sorted(cls_dir.glob(f"{re.escape(base)}_mask*.png"))
                mask_paths = [str(m) for m in masks]

                # Extract index from filename like "benign (1)"
                match = re.search(r"\((\d+)\)", base)
                idx = match.group(1) if match else "0"

                sample_info = {
                    "image_id": f"{cls_name}_{idx}",
                    "case_id": f"{cls_name}_{idx}",
                    "patient_id": f"{cls_name}_{idx}",
                    "label": label,
                    "domain": "BUSI",
                    "domain_id": 4,
                    "device": None,
                    "side": None,
                    "birads": None,
                    "histology": None,
                    "image_path": str(orig_path),
                    "mask_path": mask_paths if mask_paths else None,
                    "mask_count": len(mask_paths),
                    "bbox": None,
                }
                samples.append(sample_info)

        return samples

    def __len__(self) -> int:
        return len(self.samples)

    def __getitem__(self, idx: int) -> Dict[str, Any]:
        """Load and preprocess a single sample."""
        info = self.samples[idx]

        # Try cache
        if self.cache is not None:
            cached = self.cache.get(info["image_path"])
            if cached is not None:
                if self.augmentation is not None and self.is_train:
                    cached["image"], cached["mask"], cached["edge"], cached["sdm"] = \
                        self.augmentation(cached["image"], cached["mask"], cached["edge"], cached["sdm"])
                cached.update(info)
                return cached

        # Read image
        image = self._read_image(info["image_path"])

        # Read and merge masks
        mask = None
        if info["mask_path"] is not None and len(info["mask_path"]) > 0:
            masks = [self._read_mask(p) for p in info["mask_path"]]
            # Binarize in original size then OR union
            masks = [binarize_mask(m) for m in masks]
            mask = union_masks(masks)

        # Preprocess
        processed = self.preprocessor.process_train(image, mask, info["label"])

        # Apply augmentation
        if self.augmentation is not None and self.is_train:
            processed["image"], processed["mask"], processed["edge"], processed["sdm"] = \
                self.augmentation(
                    processed["image"], processed["mask"],
                    processed["edge"], processed["sdm"],
                )

        # Cache deterministic result
        if self.cache is not None and not self.is_train:
            cache_data = {k: v for k, v in processed.items()
                         if k in ("image", "mask", "edge", "sdm", "label", "has_mask")}
            self.cache.put(info["image_path"], cache_data)

        # Merge metadata
        result = {
            "image": processed["image"],
            "mask": processed["mask"],
            "edge": processed["edge"],
            "sdm": processed["sdm"],
            "label": processed["label"],
            "has_mask": processed["has_mask"],
            "original_size": processed["original_size"],
            "input_size": processed["input_size"],
            "resize_scale": processed["resize_scale"],
            "pad_info": processed["pad_info"],
            "restore_required": processed["restore_required"],
        }
        result.update(info)

        return result

    @staticmethod
    def _read_image(path: str) -> np.ndarray:
        """Read image from file."""
        try:
            from PIL import Image
            img = Image.open(path)
            return np.array(img)
        except ImportError:
            import cv2
            return cv2.imread(path, cv2.IMREAD_UNCHANGED)

    @staticmethod
    def _read_mask(path: str) -> np.ndarray:
        """Read mask from file."""
        try:
            from PIL import Image
            img = Image.open(path)
            return np.array(img)
        except ImportError:
            import cv2
            return cv2.imread(path, cv2.IMREAD_GRAYSCALE)
