"""Preprocessing pipeline for JwzTumor breast ultrasound images."""
import logging
from typing import Dict, Optional, Tuple

import numpy as np
import torch
from scipy import ndimage

from .mask_utils import binarize_mask, generate_edge_target, generate_sdm_target

logger = logging.getLogger(__name__)


class BreastUSPreprocessor:
    """Deterministic preprocessing for breast ultrasound images.

    Pipeline:
        1. Read image -> convert to grayscale if needed
        2. Convert to float32
        3. Effective imaging field extraction (crop black borders)
        4. Artifact detection interface (MVP: placeholder)
        5. Quantile clipping (p_low=0.5, p_high=99.5)
        6. Log compression
        7. Normalize to [0, 1]
        8. ResizeLongestSide + reflection padding
        9. Synchronous mask transform (nearest interpolation)
        10. Generate edge target and SDM target from final mask
    """

    def __init__(
        self,
        model_input_size: int = 512,
        p_low: float = 0.5,
        p_high: float = 99.5,
        pad_mode: str = "reflection",
        image_interpolation: str = "bilinear",
        mask_interpolation: str = "nearest",
        edge_width: int = 5,
    ):
        self.model_input_size = model_input_size
        self.p_low = p_low
        self.p_high = p_high
        self.pad_mode = pad_mode
        self.image_interpolation = image_interpolation
        self.mask_interpolation = mask_interpolation
        self.edge_width = edge_width

    def process_train(
        self,
        image: np.ndarray,
        mask: Optional[np.ndarray] = None,
        label: Optional[int] = None,
    ) -> Dict[str, torch.Tensor]:
        """Process training sample (image + mask + label).

        Args:
            image: Raw image array [H, W] or [H, W, C].
            mask: Raw mask array [H, W], optional.
            label: Classification label, optional.

        Returns:
            Dict with image, mask, edge, sdm, label, meta tensors.
        """
        return self._process(image, mask, label, is_train=True)

    def process_infer(
        self,
        image: np.ndarray,
    ) -> Dict[str, torch.Tensor]:
        """Process inference sample (image only).

        Args:
            image: Raw image array [H, W] or [H, W, C].

        Returns:
            Dict with image, mask(zeros), edge(zeros), sdm(zeros), meta.
        """
        return self._process(image, None, None, is_train=False)

    def _process(
        self,
        image: np.ndarray,
        mask: Optional[np.ndarray],
        label: Optional[int],
        is_train: bool,
    ) -> Dict[str, torch.Tensor]:
        """Core preprocessing pipeline."""
        original_size = image.shape[:2]

        # 1. Convert to grayscale
        image = self._to_grayscale(image)

        # 2. Float32
        image = image.astype(np.float32)

        # 3. Effective field extraction (remove black borders)
        image, crop_offset = self._crop_black_borders(image)

        # 4. Artifact detection interface (MVP: pass-through)
        artifact_mask = self._detect_artifacts(image)

        # 5. Quantile clipping
        image = self._quantile_clip(image)

        # 6. Log compression
        image = self._log_compress(image)

        # 7. Normalize to [0, 1]
        image = self._normalize(image)

        # 8. ResizeLongestSide + reflection padding
        image, resize_scale, pad_info = self._resize_and_pad(image)

        input_size = image.shape  # (H_in, W_in) after pad

        # Process mask
        has_mask = mask is not None
        if has_mask:
            # Adjust mask for crop
            mask = self._to_grayscale(mask.astype(np.float32))
            mask = binarize_mask(mask)
            # Crop mask with same offset
            if crop_offset:
                t, b, l, r = crop_offset
                mask = mask[t:mask.shape[0]-b, l:mask.shape[1]-r]
            # Resize and pad mask
            mask, _, _ = self._resize_and_pad(
                mask, is_mask=True
            )
            mask = binarize_mask(mask)
        else:
            mask = np.zeros(input_size, dtype=np.float32)

        # Generate edge and SDM from final mask
        edge = generate_edge_target(mask, width=self.edge_width)
        sdm = generate_sdm_target(mask)

        # Convert to tensors [1, H, W]
        image_tensor = torch.from_numpy(image).unsqueeze(0)
        mask_tensor = torch.from_numpy(mask).unsqueeze(0)
        edge_tensor = torch.from_numpy(edge).unsqueeze(0)
        sdm_tensor = torch.from_numpy(sdm).unsqueeze(0)

        result = {
            "image": image_tensor,
            "mask": mask_tensor,
            "edge": edge_tensor,
            "sdm": sdm_tensor,
            "has_mask": torch.tensor(has_mask),
            "original_size": original_size,
            "input_size": input_size,
            "resize_scale": resize_scale,
            "pad_info": pad_info,
            "restore_required": True,
        }

        if label is not None:
            result["label"] = torch.tensor(label, dtype=torch.long)
        else:
            result["label"] = torch.tensor(-1, dtype=torch.long)

        return result

    @staticmethod
    def _to_grayscale(img: np.ndarray) -> np.ndarray:
        """Convert RGB to grayscale if needed."""
        if img.ndim == 3 and img.shape[2] == 3:
            return (0.299 * img[:, :, 0] + 0.587 * img[:, :, 1] + 0.114 * img[:, :, 2]).astype(np.float32)
        if img.ndim == 3 and img.shape[2] == 1:
            return img[:, :, 0].astype(np.float32)
        return img.astype(np.float32) if img.dtype != np.float32 else img

    @staticmethod
    def _crop_black_borders(
        img: np.ndarray, threshold: float = 0.01
    ) -> Tuple[np.ndarray, Optional[Tuple[int, int, int, int]]]:
        """Crop black borders from image."""
        if img.max() < threshold:
            return img, None

        row_max = img.max(axis=1)
        col_max = img.max(axis=0)

        rows = np.where(row_max > threshold)[0]
        cols = np.where(col_max > threshold)[0]

        if len(rows) == 0 or len(cols) == 0:
            return img, None

        top = rows[0]
        bottom = img.shape[0] - rows[-1] - 1
        left = cols[0]
        right = img.shape[1] - cols[-1] - 1

        cropped = img[rows[0]:rows[-1]+1, cols[0]:cols[-1]+1]

        if cropped.shape[0] < 8 or cropped.shape[1] < 8:
            return img, None

        offset = (top, bottom, left, right)
        return cropped, offset

    @staticmethod
    def _detect_artifacts(img: np.ndarray) -> np.ndarray:
        """Detect artifacts (text, markers, etc.) in image.

        MVP: returns zero mask. Full version will implement
        explicit text/arrow/marker detection.
        """
        return np.zeros(img.shape[:2], dtype=np.float32)

    def _quantile_clip(self, img: np.ndarray) -> np.ndarray:
        """Apply quantile clipping."""
        lo = np.percentile(img, self.p_low)
        hi = np.percentile(img, self.p_high)
        if hi - lo < 1e-6:
            return img
        return np.clip(img, lo, hi)

    @staticmethod
    def _log_compress(img: np.ndarray) -> np.ndarray:
        """Apply log compression to reduce dynamic range."""
        img = img - img.min() + 1e-6
        return np.log1p(img)

    @staticmethod
    def _normalize(img: np.ndarray) -> np.ndarray:
        """Normalize to [0, 1]."""
        lo = img.min()
        hi = img.max()
        if hi - lo < 1e-6:
            return np.zeros_like(img)
        return (img - lo) / (hi - lo)

    def _resize_and_pad(
        self,
        img: np.ndarray,
        is_mask: bool = False,
    ) -> Tuple[np.ndarray, float, Dict[str, int]]:
        """Resize longest side and pad to square.

        Args:
            img: Image or mask [H, W].
            is_mask: If True, use nearest interpolation.

        Returns:
            (padded_img, resize_scale, pad_info)
        """
        h, w = img.shape[:2]
        target = self.model_input_size
        scale = target / max(h, w)

        new_h = int(round(h * scale))
        new_w = int(round(w * scale))
        # Ensure dimensions don't exceed target
        new_h = min(new_h, target)
        new_w = min(new_w, target)

        try:
            from PIL import Image
            order = Image.NEAREST if is_mask else Image.BILINEAR
            pil_img = Image.fromarray((img * 255).astype(np.uint8) if not is_mask else (img > 0).astype(np.uint8) * 255)
            pil_resized = pil_img.resize((new_w, new_h), order)
            resized = np.array(pil_resized).astype(np.float32)
            if not is_mask:
                resized = resized / 255.0
            else:
                resized = (resized > 127).astype(np.float32)
        except ImportError:
            from scipy.ndimage import zoom as scipy_zoom
            order = 0 if is_mask else 1
            resized = scipy_zoom(img, (new_h / h, new_w / w), order=order).astype(np.float32)

        # Pad to square
        pad_top = (target - new_h) // 2
        pad_bottom = target - new_h - pad_top
        pad_left = (target - new_w) // 2
        pad_right = target - new_w - pad_left

        pad_info = {
            "top": pad_top,
            "bottom": pad_bottom,
            "left": pad_left,
            "right": pad_right,
        }

        if self.pad_mode == "reflection":
            padded = np.pad(
                resized,
                ((pad_top, pad_bottom), (pad_left, pad_right)),
                mode="reflect",
            )
        else:
            padded = np.pad(
                resized,
                ((pad_top, pad_bottom), (pad_left, pad_right)),
                mode="constant",
                constant_values=0,
            )

        return padded, scale, pad_info


class RestoreTransform:
    """Reverse the preprocessing transforms for output maps."""

    def __init__(self, pad_info: Dict[str, int], resize_scale: float, original_size: Tuple[int, int]):
        self.pad_info = pad_info
        self.resize_scale = resize_scale
        self.original_size = original_size

    def __call__(self, tensor: torch.Tensor) -> torch.Tensor:
        """Restore a [1, H, W] or [H, W] tensor to original size.

        Steps: remove padding -> resize back to original size.
        """
        if tensor.dim() == 3:
            tensor = tensor.unsqueeze(0)  # [1, 1, H, W]

        p = self.pad_info
        if p["top"] > 0 or p["bottom"] > 0 or p["left"] > 0 or p["right"] > 0:
            h = tensor.shape[2]
            w = tensor.shape[3]
            tensor = tensor[:, :, p["top"]:h - p["bottom"], p["left"]:w - p["right"]]

        orig_h, orig_w = self.original_size
        if tensor.shape[2] != orig_h or tensor.shape[3] != orig_w:
            import torch.nn.functional as F
            tensor = F.interpolate(
                tensor,
                size=(orig_h, orig_w),
                mode="bilinear",
                align_corners=False,
            )

        return tensor.squeeze(0)  # [1, H, W]
