"""Data splitting utilities for BUSBRA cross-validation."""
import logging
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import pandas as pd
import numpy as np

from ..utils.config import DEVICE_DOMAIN_MAP

logger = logging.getLogger(__name__)


def load_cv_splits(
    cv_file: str,
    fold: int = 1,
    case_level: bool = True,
) -> Tuple[List[str], List[str]]:
    """Load cross-validation splits from official CSV.

    Args:
        cv_file: Path to 5-fold-cv.csv or 10-fold-cv.csv.
        fold: Fold number (1-based).
        case_level: If True, return case IDs; if False, return image IDs.

    Returns:
        (train_ids, val_ids) tuples.
    """
    cv_path = Path(cv_file)
    if not cv_path.exists():
        raise FileNotFoundError(f"CV file not found: {cv_path}")

    df = pd.read_csv(cv_path)

    # CV file columns: ID, Pathology, kFold, valid_1, ..., valid_N
    # Convention: NaN in valid_N → validation set for fold N
    #             non-NaN (0 or 1) → training set for fold N
    col = f"valid_{fold}"

    if col not in df.columns:
        raise ValueError(
            f"Column '{col}' not found in CV file. "
            f"Available: {list(df.columns)}"
        )

    val_mask = df[col].isna()
    train_mask = df[col].notna()

    if "ID" not in df.columns:
        raise ValueError("CV file must have an 'ID' column")

    if case_level:
        # Extract case number from ID pattern: bus_{num}-{side} → case num
        def _id_to_case(image_id: str) -> int:
            return int(image_id.split("_")[1].split("-")[0])

        train_ids = sorted(set(_id_to_case(x) for x in df.loc[train_mask, "ID"]))
        val_ids = sorted(set(_id_to_case(x) for x in df.loc[val_mask, "ID"]))
    else:
        train_ids = df.loc[train_mask, "ID"].tolist()
        val_ids = df.loc[val_mask, "ID"].tolist()

    logger.info("CV fold %d: train=%d, val=%d", fold, len(train_ids), len(val_ids))
    return train_ids, val_ids


def check_case_leakage(
    csv_path: str,
    train_ids: List[str],
    val_ids: List[str],
) -> bool:
    """Check if any case appears in both train and val sets.

    Returns:
        True if leakage detected.
    """
    train_set = set(train_ids)
    val_set = set(val_ids)
    overlap = train_set & val_set
    if overlap:
        logger.warning("Case leakage detected! Overlapping cases: %s", overlap)
        return True
    return False


def get_device_domain_id(device_str: str) -> int:
    """Map device string to domain_id."""
    return DEVICE_DOMAIN_MAP.get(device_str, -1)
