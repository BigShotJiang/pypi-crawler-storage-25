"""Dataset cache for JwzTumor - supports ram/disk/none modes."""
import os
import logging
import hashlib
from pathlib import Path
from typing import Any, Dict, Optional

import numpy as np
import torch

logger = logging.getLogger(__name__)


class DatasetCache:
    """Cache for preprocessed dataset samples.

    Only caches deterministic preprocessing results, NOT random augmentation outputs.

    Modes:
        - "ram": Cache in memory (dict of tensors)
        - "disk": Cache on disk (torch files in cache directory)
        - "none": No caching
    """

    def __init__(
        self,
        mode: str = "ram",
        cache_dir: Optional[str] = None,
        max_items: Optional[int] = None,
    ):
        self.mode = mode.lower()
        self.cache_dir = Path(cache_dir) if cache_dir else Path("cache")
        self.max_items = max_items
        self._ram_cache: Dict[str, Dict[str, Any]] = {}
        self.hits = 0
        self.misses = 0

        if self.mode == "disk":
            self.cache_dir.mkdir(parents=True, exist_ok=True)

    def _make_key(self, image_path: str) -> str:
        """Generate cache key from image path."""
        return hashlib.md5(str(image_path).encode()).hexdigest()

    def get(self, image_path: str) -> Optional[Dict[str, Any]]:
        """Retrieve cached sample."""
        if self.mode == "none":
            return None

        key = self._make_key(image_path)

        if self.mode == "ram":
            if key in self._ram_cache:
                self.hits += 1
                return self._ram_cache[key]
            self.misses += 1
            return None

        if self.mode == "disk":
            cache_path = self.cache_dir / f"{key}.pt"
            if cache_path.exists():
                self.hits += 1
                return torch.load(str(cache_path), weights_only=False)
            self.misses += 1
            return None

        return None

    def put(self, image_path: str, data: Dict[str, Any]) -> None:
        """Store preprocessed sample in cache.

        Only caches deterministic results. Will NOT cache
        random augmentation outputs.
        """
        if self.mode == "none":
            return

        key = self._make_key(image_path)

        if self.mode == "ram":
            if self.max_items and len(self._ram_cache) >= self.max_items:
                # Remove oldest entry
                oldest_key = next(iter(self._ram_cache))
                del self._ram_cache[oldest_key]
            self._ram_cache[key] = data

        elif self.mode == "disk":
            cache_path = self.cache_dir / f"{key}.pt"
            torch.save(data, str(cache_path))

    def clear(self) -> None:
        """Clear all cached data."""
        if self.mode == "ram":
            self._ram_cache.clear()
        elif self.mode == "disk":
            for f in self.cache_dir.glob("*.pt"):
                f.unlink()

        self.hits = 0
        self.misses = 0

    def stats(self) -> Dict[str, int]:
        """Return cache statistics."""
        return {
            "mode": self.mode,
            "hits": self.hits,
            "misses": self.misses,
            "size": len(self._ram_cache) if self.mode == "ram" else -1,
        }
