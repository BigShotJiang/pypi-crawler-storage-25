"""Custom collate function for multi-task JwzTumor batches."""
import torch
from typing import Any, Dict, List


def multitask_collate_fn(batch: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Custom collate for multi-task breast ultrasound samples.

    Stack tensor fields, keep strings and dicts as lists.

    Args:
        batch: List of sample dicts from dataset __getitem__.

    Returns:
        Batch dict with stacked tensors and list metadata.
    """
    if not batch:
        return {}

    result = {}
    sample = batch[0]

    tensor_keys = [
        "image", "mask", "edge", "sdm",
    ]
    scalar_tensor_keys = ["label", "has_mask"]

    for key in tensor_keys:
        if key in sample and sample[key] is not None:
            result[key] = torch.stack([s[key] for s in batch])

    for key in scalar_tensor_keys:
        if key in sample and sample[key] is not None:
            vals = [s[key] for s in batch]
            if all(isinstance(v, torch.Tensor) for v in vals):
                result[key] = torch.stack(vals)
            else:
                result[key] = torch.tensor(vals, dtype=torch.long)

    # List fields (strings, dicts, tuples, etc.)
    list_keys = [
        "image_id", "case_id", "patient_id", "domain",
        "device", "side", "histology", "image_path", "mask_path",
    ]

    for key in list_keys:
        if key in sample:
            result[key] = [s.get(key) for s in batch]

    # Numeric/dict fields that should be lists
    list_value_keys = [
        "domain_id", "birads", "mask_count",
        "original_size", "input_size",
    ]

    for key in list_value_keys:
        if key in sample:
            vals = [s.get(key) for s in batch]
            # Try to stack if all tensors
            if all(isinstance(v, torch.Tensor) for v in vals):
                result[key] = torch.stack(vals)
            else:
                result[key] = vals

    # Dict fields
    dict_keys = ["pad_info", "bbox"]
    for key in dict_keys:
        if key in sample:
            result[key] = [s.get(key) for s in batch]

    # Boolean/float fields
    if "resize_scale" in sample:
        scales = [s.get("resize_scale", 1.0) for s in batch]
        result["resize_scale"] = torch.tensor(scales, dtype=torch.float32)

    if "restore_required" in sample:
        result["restore_required"] = [s.get("restore_required", True) for s in batch]

    # Meta dict for convenient access
    result["meta"] = []
    for s in batch:
        meta = {}
        for mk in ["original_size", "input_size", "resize_scale", "pad_info",
                     "image_id", "case_id", "patient_id", "domain", "domain_id",
                     "device", "side", "image_path", "mask_path", "mask_count",
                     "restore_required"]:
            if mk in s:
                meta[mk] = s[mk]
        result["meta"].append(meta)

    return result
