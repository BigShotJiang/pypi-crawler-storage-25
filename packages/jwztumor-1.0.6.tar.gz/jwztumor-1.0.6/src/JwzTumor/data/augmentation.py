"""Data augmentation pipeline for JwzTumor breast ultrasound images."""
import logging
from typing import Dict, Optional, Tuple

import numpy as np
import torch

logger = logging.getLogger(__name__)


class BreastUSAugmentation:
    """Medical ultrasound specific augmentation pipeline.

    All geometric augmentations must synchronously transform image, mask, edge, sdm.
    Non-geometric augmentations only affect image.
    """

    def __init__(self, config=None):
        self.config = config
        self.enabled = config is not None

    def __call__(
        self,
        image: torch.Tensor,
        mask: torch.Tensor,
        edge: torch.Tensor,
        sdm: torch.Tensor,
    ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
        """Apply augmentation pipeline.

        Args:
            image: [1, H, W] image tensor.
            mask: [1, H, W] mask tensor.
            edge: [1, H, W] edge tensor.
            sdm: [1, H, W] sdm tensor.

        Returns:
            Augmented (image, mask, edge, sdm).
        """
        if not self.enabled:
            return image, mask, edge, sdm

        # Geometric augmentations (synchronous)
        image, mask, edge, sdm = self._apply_geometric(image, mask, edge, sdm)

        # Regenerate edge/sdm from final mask after geometric transforms
        # (as per Phase 2 correction)
        if self._should_regenerate_targets():
            mask_np = mask[0].numpy()
            from .mask_utils import generate_edge_target, generate_sdm_target
            edge_np = generate_edge_target(mask_np)
            sdm_np = generate_sdm_target(mask_np)
            edge = torch.from_numpy(edge_np).unsqueeze(0)
            sdm = torch.from_numpy(sdm_np).unsqueeze(0)

        # Intensity augmentations (image only)
        image = self._apply_intensity(image)

        return image, mask, edge, sdm

    def _should_regenerate_targets(self) -> bool:
        """Whether to regenerate edge/sdm from mask after geometric augmentation."""
        cfg = self.config
        if cfg is None:
            return False
        return getattr(cfg, "random_rotation_degree", 0) > 0 or getattr(cfg, "random_elastic", False)

    def _apply_geometric(
        self,
        image: torch.Tensor,
        mask: torch.Tensor,
        edge: torch.Tensor,
        sdm: torch.Tensor,
    ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
        """Geometric augmentations applied synchronously."""
        cfg = self.config

        # Random horizontal flip
        if getattr(cfg, "random_horizontal_flip", True):
            if np.random.random() > 0.5:
                image = torch.flip(image, [-1])
                mask = torch.flip(mask, [-1])
                edge = torch.flip(edge, [-1])
                sdm = torch.flip(sdm, [-1])

        # Random rotation (small angle)
        max_deg = getattr(cfg, "random_rotation_degree", 10)
        if max_deg > 0:
            angle = np.random.uniform(-max_deg, max_deg)
            image = self._rotate_tensor(image, angle, mode="bilinear")
            mask = self._rotate_tensor(mask, angle, mode="nearest")

        # Random scale and shift
        if getattr(cfg, "random_scale_shift", True):
            scale = np.random.uniform(0.9, 1.1)
            shift_x = np.random.randint(-10, 11)
            shift_y = np.random.randint(-10, 11)
            image = self._scale_shift_tensor(image, scale, shift_x, shift_y, mode="bilinear")
            mask = self._scale_shift_tensor(mask, scale, shift_x, shift_y, mode="nearest")

        return image, mask, edge, sdm

    def _apply_intensity(self, image: torch.Tensor) -> torch.Tensor:
        """Intensity augmentations (image only)."""
        cfg = self.config
        img = image.clone()

        # Speckle noise injection
        if getattr(cfg, "speckle_noise", True):
            noise_std = np.random.uniform(0.01, 0.05)
            speckle = torch.randn_like(img) * noise_std
            img = img + img * speckle

        # Gamma adjustment
        if getattr(cfg, "gamma_adjustment", True):
            gamma = np.random.uniform(0.8, 1.2)
            img = torch.pow(img.clamp(0, 1), gamma)

        # Contrast adjustment
        if getattr(cfg, "contrast_adjustment", True):
            factor = np.random.uniform(0.85, 1.15)
            mean = img.mean()
            img = (img - mean) * factor + mean

        # Brightness/gain
        if getattr(cfg, "brightness_gain", True):
            gain = np.random.uniform(0.9, 1.1)
            img = img * gain

        # Random blur
        blur_prob = getattr(cfg, "random_blur_prob", 0.1)
        if np.random.random() < blur_prob:
            img = self._gaussian_blur(img)

        # Coarse dropout (low probability, avoid lesion center)
        dropout_prob = getattr(cfg, "coarse_dropout_prob", 0.05)
        if np.random.random() < dropout_prob:
            img = self._coarse_dropout(img)

        return img.clamp(0, 1)

    @staticmethod
    def _rotate_tensor(
        tensor: torch.Tensor,
        angle: float,
        mode: str = "bilinear",
    ) -> torch.Tensor:
        """Rotate a tensor by angle degrees."""
        try:
            import torchvision.transforms.functional as TF
            import math
            angle_rad = math.degrees(math.radians(angle))
            return TF.rotate(
                tensor.unsqueeze(0) if tensor.dim() == 3 else tensor,
                angle,
                interpolation=TF.InterpolationMode.NEAREST if mode == "nearest" else TF.InterpolationMode.BILINEAR,
                fill=0,
            ).squeeze(0) if tensor.dim() == 3 else TF.rotate(tensor, angle, fill=0)
        except ImportError:
            return tensor

    @staticmethod
    def _scale_shift_tensor(
        tensor: torch.Tensor,
        scale: float,
        shift_x: int,
        shift_y: int,
        mode: str = "bilinear",
    ) -> torch.Tensor:
        """Apply scale and shift to tensor."""
        try:
            import torch.nn.functional as F
            if abs(scale - 1.0) > 0.01:
                _, h, w = tensor.shape
                new_h, new_w = int(h * scale), int(w * scale)
                resized = F.interpolate(
                    tensor.unsqueeze(0),
                    size=(new_h, new_w),
                    mode=mode if mode != "nearest" else "nearest",
                    align_corners=False if mode != "nearest" else None,
                ).squeeze(0)
                # Pad or crop back to original size
                if new_h < h or new_w < w:
                    pad_h = max(h - new_h, 0)
                    pad_w = max(w - new_w, 0)
                    resized = F.pad(resized, (pad_w // 2, pad_w - pad_w // 2, pad_h // 2, pad_h - pad_h // 2))
                tensor = resized[:, :h, :w]
            return tensor
        except Exception:
            return tensor

    @staticmethod
    def _gaussian_blur(tensor: torch.Tensor, kernel_size: int = 3) -> torch.Tensor:
        """Apply Gaussian blur to tensor."""
        try:
            import torchvision.transforms.functional as TF
            return TF.gaussian_blur(tensor, kernel_size=[kernel_size, kernel_size])
        except ImportError:
            return tensor

    @staticmethod
    def _coarse_dropout(
        tensor: torch.Tensor,
        max_holes: int = 4,
        max_size: int = 16,
    ) -> torch.Tensor:
        """Apply coarse dropout, avoiding lesion center area."""
        result = tensor.clone()
        _, h, w = result.shape
        n_holes = np.random.randint(1, max_holes + 1)
        for _ in range(n_holes):
            hole_h = np.random.randint(4, max_size)
            hole_w = np.random.randint(4, max_size)
            y = np.random.randint(0, h - hole_h)
            x = np.random.randint(0, w - hole_w)
            result[:, y:y + hole_h, x:x + hole_w] = 0
        return result
