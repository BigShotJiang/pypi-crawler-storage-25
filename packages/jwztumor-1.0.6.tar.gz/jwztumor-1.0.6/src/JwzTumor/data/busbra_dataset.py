"""BUSBRA Dataset class for JwzTumor."""
import os
import logging
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import pandas as pd
import torch
from torch.utils.data import Dataset

from .preprocessing import BreastUSPreprocessor
from .mask_utils import binarize_mask, generate_edge_target, generate_sdm_target
from .augmentation import BreastUSAugmentation
from .cache import DatasetCache
from .collate import multitask_collate_fn
from .split_utils import load_cv_splits, get_device_domain_id

logger = logging.getLogger(__name__)

# Known bad samples with dimension mismatches
KNOWN_BAD_SAMPLES = ["bus_0856-l", "bus_0857-r", "bus_0912-l", "bus_0990-l"]


class BUSBRADataset(Dataset):
    """BUSBRA breast ultrasound dataset.

    Handles:
        - Image-mask pairing (bus_* -> mask_*)
        - CSV label loading (Pathology -> benign=0, malignant=1)
        - Cross-validation fold splitting
        - Case-level split (no leak)
        - Device domain mapping
        - Data caching

    Sample dict keys:
        image, mask, edge, sdm, label, has_mask,
        image_id, case_id, patient_id, domain, domain_id,
        device, side, bbox, birads, histology,
        original_size, input_size, resize_scale, pad_info,
        image_path, mask_path, mask_count
    """

    def __init__(
        self,
        data_root: str,
        csv_path: Optional[str] = None,
        image_dir: str = "Images",
        mask_dir: str = "Masks",
        sample_ids: Optional[List[str]] = None,
        case_ids: Optional[List[str]] = None,
        preprocessor: Optional[BreastUSPreprocessor] = None,
        augmentation: Optional[BreastUSAugmentation] = None,
        cache: Optional[DatasetCache] = None,
        label_mapping: Optional[Dict[str, int]] = None,
        is_train: bool = True,
    ):
        self.data_root = Path(data_root)
        self.image_dir = self.data_root / image_dir
        self.mask_dir = self.data_root / mask_dir
        self.preprocessor = preprocessor or BreastUSPreprocessor()
        self.augmentation = augmentation if is_train else None
        self.cache = cache
        self.label_mapping = label_mapping or {"benign": 0, "malignant": 1}
        self.is_train = is_train

        # Load CSV
        if csv_path is None:
            csv_path = self.data_root / "bus_data.csv"
        else:
            csv_path = Path(csv_path)

        self.df = pd.read_csv(csv_path) if csv_path.exists() else pd.DataFrame()

        # Filter samples
        if case_ids is not None:
            self.df = self.df[self.df["Case"].isin(case_ids)]
        elif sample_ids is not None:
            self.df = self.df[self.df["ID"].isin(sample_ids)]

        # Build sample list
        self.samples = self._build_sample_list()

        logger.info(
            "BUSBRA %s: %d samples from %s",
            "train" if is_train else "val/test",
            len(self.samples),
            self.data_root,
        )

    def _build_sample_list(self) -> List[Dict[str, Any]]:
        """Build list of sample info dicts from CSV and files."""
        samples = []
        for _, row in self.df.iterrows():
            img_id = str(row["ID"])
            # CSV ID already contains the full prefix, e.g. "bus_0001-l"
            # Check for known bad samples
            if any(b in img_id for b in KNOWN_BAD_SAMPLES):
                logger.warning("Known dimension mismatch sample: %s", img_id)

            # Construct paths
            # Image: bus_0001-l.png
            img_name = f"{img_id}.png"
            img_path = self.image_dir / img_name
            # Mask: mask_0001-l.png (strip "bus_" prefix from ID)
            mask_suffix = img_id.removeprefix("bus_")
            mask_name = f"mask_{mask_suffix}.png"
            mask_path = self.mask_dir / mask_name

            if not img_path.exists():
                logger.debug("Image not found: %s", img_path)
                continue

            # Parse label
            pathology = str(row.get("Pathology", "unknown")).lower()
            label = self.label_mapping.get(pathology, -1)

            # Parse metadata
            device = row.get("Device", "unknown")
            domain_id = get_device_domain_id(str(device))

            sample_info = {
                "image_id": img_id,
                "case_id": str(row.get("Case", img_id)),
                "patient_id": str(row.get("Case", img_id)),
                "label": label,
                "domain": str(device),
                "domain_id": domain_id,
                "device": str(device),
                "side": str(row.get("Side", "")),
                "birads": row.get("BIRADS", None),
                "histology": row.get("Histology", None),
                "image_path": str(img_path),
                "mask_path": str(mask_path) if mask_path.exists() else None,
                "mask_count": 1 if mask_path.exists() else 0,
            }

            # Parse bbox if available
            bbox = row.get("BBOX", None)
            if bbox is not None and pd.notna(bbox):
                try:
                    parts = [float(x) for x in str(bbox).split()]
                    sample_info["bbox"] = parts[:4]
                except (ValueError, TypeError):
                    sample_info["bbox"] = None
            else:
                sample_info["bbox"] = None

            samples.append(sample_info)

        return samples

    def __len__(self) -> int:
        return len(self.samples)

    def __getitem__(self, idx: int) -> Dict[str, Any]:
        """Load and preprocess a single sample."""
        info = self.samples[idx]

        # Try cache
        if self.cache is not None:
            cached = self.cache.get(info["image_path"])
            if cached is not None:
                # Apply augmentation to cached data if training
                if self.augmentation is not None and self.is_train:
                    cached["image"], cached["mask"], cached["edge"], cached["sdm"] = \
                        self.augmentation(cached["image"], cached["mask"], cached["edge"], cached["sdm"])
                # Add metadata
                cached.update(info)
                return cached

        # Read image
        image = self._read_image(info["image_path"])

        # Read mask
        mask = None
        if info["mask_path"] is not None:
            mask = self._read_mask(info["mask_path"])

        # Preprocess
        processed = self.preprocessor.process_train(image, mask, info["label"])

        # Apply augmentation
        if self.augmentation is not None and self.is_train:
            processed["image"], processed["mask"], processed["edge"], processed["sdm"] = \
                self.augmentation(
                    processed["image"], processed["mask"],
                    processed["edge"], processed["sdm"],
                )

        # Cache the result (only deterministic part)
        if self.cache is not None and not self.is_train:
            cache_data = {k: v for k, v in processed.items()
                         if k in ("image", "mask", "edge", "sdm", "label", "has_mask")}
            self.cache.put(info["image_path"], cache_data)

        # Merge metadata
        result = {
            "image": processed["image"],
            "mask": processed["mask"],
            "edge": processed["edge"],
            "sdm": processed["sdm"],
            "label": processed["label"],
            "has_mask": processed["has_mask"],
            "original_size": processed["original_size"],
            "input_size": processed["input_size"],
            "resize_scale": processed["resize_scale"],
            "pad_info": processed["pad_info"],
            "restore_required": processed["restore_required"],
        }
        result.update(info)

        return result

    @staticmethod
    def _read_image(path: str) -> np.ndarray:
        """Read image from file."""
        try:
            from PIL import Image
            img = Image.open(path)
            return np.array(img)
        except ImportError:
            import cv2
            return cv2.imread(path, cv2.IMREAD_UNCHANGED)

    @staticmethod
    def _read_mask(path: str) -> np.ndarray:
        """Read mask from file."""
        try:
            from PIL import Image
            img = Image.open(path)
            return np.array(img)
        except ImportError:
            import cv2
            return cv2.imread(path, cv2.IMREAD_GRAYSCALE)
