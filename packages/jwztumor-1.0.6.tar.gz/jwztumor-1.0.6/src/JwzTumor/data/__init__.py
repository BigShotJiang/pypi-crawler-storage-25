"""Data modules for JwzTumor."""
