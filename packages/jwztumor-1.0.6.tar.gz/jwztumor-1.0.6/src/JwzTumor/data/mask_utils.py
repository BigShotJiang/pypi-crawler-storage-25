"""Mask utility functions for JwzTumor."""
import numpy as np
import torch
from scipy import ndimage
from typing import Optional, Tuple

import logging

logger = logging.getLogger(__name__)


def binarize_mask(mask: np.ndarray) -> np.ndarray:
    """Binarize mask: mask > 0 -> 1, else 0."""
    return (mask > 0).astype(np.float32)


def union_masks(masks: list) -> np.ndarray:
    """Compute pixel-wise OR union of multiple binary masks.

    Args:
        masks: List of numpy arrays, each [H, W] binary mask.

    Returns:
        Union mask [H, W].
    """
    if not masks:
        raise ValueError("No masks provided for union")
    result = np.zeros_like(masks[0], dtype=np.float32)
    for m in masks:
        result = np.maximum(result, binarize_mask(m))
    return result


def generate_edge_target(mask: np.ndarray, width: int = 5) -> np.ndarray:
    """Generate edge target from binary mask using morphological gradient.

    Args:
        mask: Binary mask [H, W], values in {0, 1}.
        width: Edge width in pixels.

    Returns:
        Edge map [H, W], values in {0, 1}.
    """
    binary = (mask > 0).astype(np.float32)
    if binary.sum() == 0:
        return np.zeros_like(binary)

    dilated = ndimage.binary_dilation(binary, iterations=width).astype(np.float32)
    eroded = ndimage.binary_erosion(binary, iterations=width).astype(np.float32)
    edge = dilated - eroded
    return (edge > 0).astype(np.float32)


def generate_sdm_target(mask: np.ndarray) -> np.ndarray:
    """Generate Signed Distance Map from binary mask.

    Args:
        mask: Binary mask [H, W], values in {0, 1}.

    Returns:
        SDM [H, W], positive inside, negative outside.
    """
    binary = (mask > 0).astype(np.float32)
    if binary.sum() == 0:
        return np.zeros_like(binary, dtype=np.float32)
    if binary.min() == 1.0:
        # Entire image is foreground
        h, w = binary.shape
        y, x = np.mgrid[:h, :w]
        d = np.minimum(
            np.minimum(y + 1, h - y),
            np.minimum(x + 1, w - x)
        ).astype(np.float32)
        return d

    dist_outside = ndimage.distance_transform_edt(1.0 - binary)
    dist_inside = ndimage.distance_transform_edt(binary)
    sdm = dist_inside - dist_outside
    return sdm.astype(np.float32)


def largest_connected_component(mask: np.ndarray) -> np.ndarray:
    """Keep only the largest connected component in a binary mask.

    Args:
        mask: Binary mask [H, W].

    Returns:
        Mask with only the largest component.
    """
    binary = (mask > 0).astype(np.int32)
    if binary.sum() == 0:
        return np.zeros_like(binary, dtype=np.float32)

    labeled, num_features = ndimage.label(binary)
    if num_features <= 1:
        return binary.astype(np.float32)

    sizes = ndimage.sum(binary, labeled, range(1, num_features + 1))
    max_label = np.argmax(sizes) + 1
    return (labeled == max_label).astype(np.float32)


def remove_small_regions(mask: np.ndarray, min_size: int = 100) -> np.ndarray:
    """Remove small connected regions from binary mask.

    Args:
        mask: Binary mask [H, W].
        min_size: Minimum region size in pixels.

    Returns:
        Cleaned mask.
    """
    binary = (mask > 0).astype(np.int32)
    if binary.sum() == 0:
        return np.zeros_like(binary, dtype=np.float32)

    labeled, num_features = ndimage.label(binary)
    sizes = ndimage.sum(binary, labeled, range(1, num_features + 1))
    for i, size in enumerate(sizes):
        if size < min_size:
            binary[labeled == (i + 1)] = 0

    return binary.astype(np.float32)


def compute_foreground_ratio(mask: np.ndarray) -> float:
    """Compute foreground ratio of a binary mask."""
    return float((mask > 0).sum()) / max(mask.size, 1)
