"""Dataset auditing utilities for JwzTumor."""
import os
import logging
from pathlib import Path
from typing import Any, Dict, List, Optional

import numpy as np
import pandas as pd

from .mask_utils import binarize_mask, compute_foreground_ratio

logger = logging.getLogger(__name__)


def audit_busbra(
    data_root: str,
    csv_path: Optional[str] = None,
) -> Dict[str, Any]:
    """Audit BUSBRA dataset.

    Checks:
        - Image-mask pairing
        - CSV width/height vs actual image dimensions
        - Case-level data leak check
        - Device to domain_id mapping
        - Label distribution

    Args:
        data_root: Root directory of BUSBRA.
        csv_path: Path to bus_data.csv (default: data_root/bus_data.csv).

    Returns:
        Audit summary dict.
    """
    data_root = Path(data_root)
    if csv_path is None:
        csv_path = data_root / "bus_data.csv"
    else:
        csv_path = Path(csv_path)

    result = {
        "dataset": "BUSBRA",
        "data_root": str(data_root),
        "issues": [],
        "warnings": [],
        "stats": {},
    }

    # Check CSV exists
    if not csv_path.exists():
        result["issues"].append(f"CSV not found: {csv_path}")
        return result

    df = pd.read_csv(csv_path)

    # Basic stats
    result["stats"]["total_samples"] = len(df)
    result["stats"]["total_cases"] = df["Case"].nunique() if "Case" in df.columns else -1
    if "Pathology" in df.columns:
        result["stats"]["label_distribution"] = df["Pathology"].value_counts().to_dict()

    # Check image-mask pairing
    image_dir = data_root / "Images"
    mask_dir = data_root / "Masks"
    if image_dir.exists() and mask_dir.exists():
        images = sorted(image_dir.glob("bus_*.png"))
        masks = sorted(mask_dir.glob("mask_*.png"))

        image_ids = {f.stem.replace("bus_", ""): f for f in images}
        mask_ids = {f.stem.replace("mask_", ""): f for f in masks}

        unpaired_images = set(image_ids.keys()) - set(mask_ids.keys())
        unpaired_masks = set(mask_ids.keys()) - set(image_ids.keys())

        if unpaired_images:
            result["warnings"].append(f"Unpaired images (no mask): {sorted(unpaired_images)[:10]}")
        if unpaired_masks:
            result["warnings"].append(f"Unpaired masks (no image): {sorted(unpaired_masks)[:10]}")

        result["stats"]["images"] = len(images)
        result["stats"]["masks"] = len(masks)
        result["stats"]["paired"] = len(set(image_ids.keys()) & set(mask_ids.keys()))

    # Check CSV dimensions vs actual
    if "Width" in df.columns and "Height" in df.columns:
        dim_mismatches = []
        for _, row in df.iterrows():
            img_id = row["ID"]
            img_path = image_dir / f"bus_{img_id}.png"
            if img_path.exists():
                try:
                    from PIL import Image
                    with Image.open(img_path) as im:
                        w, h = im.size
                    csv_w, csv_h = row["Width"], row["Height"]
                    if w != csv_w or h != csv_h:
                        dim_mismatches.append(img_id)
                except Exception:
                    pass
        if dim_mismatches:
            result["warnings"].append(
                f"CSV dimension mismatch for {len(dim_mismatches)} samples: {dim_mismatches[:5]}"
            )

    # Case-level leak check
    if "Case" in df.columns and "Pathology" in df.columns:
        case_labels = df.groupby("Case")["Pathology"].nunique()
        multi_label_cases = case_labels[case_labels > 1].tolist()
        if multi_label_cases:
            result["issues"].append(
                f"Cases with mixed labels (potential leak): {multi_label_cases[:5]}"
            )

    return result


def audit_busi(
    data_root: str,
) -> Dict[str, Any]:
    """Audit BUSI dataset.

    Checks:
        - Benign/malignant image count
        - Normal folder skip
        - Multi-mask identification
        - Image channels
        - Size statistics
        - Mask foreground ratio

    Args:
        data_root: Root directory of Dataset_BUSI_with_GT.

    Returns:
        Audit summary dict.
    """
    data_root = Path(data_root)
    result = {
        "dataset": "BUSI",
        "data_root": str(data_root),
        "issues": [],
        "warnings": [],
        "stats": {},
    }

    for cls_name in ["benign", "malignant"]:
        cls_dir = data_root / cls_name
        if not cls_dir.exists():
            result["issues"].append(f"Class directory not found: {cls_dir}")
            continue

        # Find original images (exclude masks)
        all_files = sorted(cls_dir.glob("*.png"))
        originals = [f for f in all_files if "_mask" not in f.name]

        # Find multi-mask images
        multi_mask_count = 0
        for orig in originals:
            base = orig.stem
            masks = list(cls_dir.glob(f"{base}_mask*.png"))
            if len(masks) > 1:
                multi_mask_count += 1

        result["stats"][f"{cls_name}_images"] = len(originals)
        result["stats"][f"{cls_name}_multi_mask"] = multi_mask_count

    # Check normal folder
    normal_dir = data_root / "normal"
    normal_dir_alt = data_root / "normal-不使用"
    if normal_dir.exists():
        normal_count = len(list(normal_dir.glob("*.png")))
        result["warnings"].append(f"Normal folder exists with {normal_count} images (should be skipped)")
    if normal_dir_alt.exists():
        normal_count = len(list(normal_dir_alt.glob("*.png")))
        result["stats"]["normal_skipped"] = normal_count

    return result


def audit_dataset(data_root: str) -> Dict[str, Any]:
    """Run full dataset audit.

    Args:
        data_root: Root directory containing BUSBRA/ and Dataset_BUSI_with_GT/.

    Returns:
        Combined audit summary.
    """
    data_root = Path(data_root)
    result = {
        "data_root": str(data_root),
        "datasets": {},
        "summary": {},
    }

    busbra_root = data_root / "BUSBRA"
    if busbra_root.exists():
        result["datasets"]["BUSBRA"] = audit_busbra(str(busbra_root))

    busi_root = data_root / "Dataset_BUSI_with_GT"
    if busi_root.exists():
        result["datasets"]["BUSI"] = audit_busi(str(busi_root))

    # Summary
    total_issues = sum(
        len(d.get("issues", [])) for d in result["datasets"].values()
    )
    total_warnings = sum(
        len(d.get("warnings", [])) for d in result["datasets"].values()
    )
    result["summary"]["total_issues"] = total_issues
    result["summary"]["total_warnings"] = total_warnings

    return result
