"""JwzTumor: Breast ultrasound benign-malignant diagnosis with segmentation-assisted multi-task learning."""

from .__version__ import __version__

__all__ = ["__version__"]
