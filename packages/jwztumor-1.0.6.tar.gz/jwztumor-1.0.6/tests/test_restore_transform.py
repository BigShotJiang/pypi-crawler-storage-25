"""Tests for restore transform."""
import pytest
import torch
import numpy as np

from JwzTumor.data.preprocessing import RestoreTransform


def test_restore_identity():
    """Test restore with no padding and no resize."""
    restore = RestoreTransform(
        pad_info={"top": 0, "bottom": 0, "left": 0, "right": 0},
        resize_scale=1.0,
        original_size=(32, 32),
    )
    tensor = torch.ones(1, 1, 32, 32)
    result = restore(tensor)
    assert result.shape == (1, 32, 32)


def test_restore_with_padding():
    """Test restore removes padding."""
    restore = RestoreTransform(
        pad_info={"top": 4, "bottom": 4, "left": 8, "right": 8},
        resize_scale=1.0,
        original_size=(24, 16),
    )
    tensor = torch.ones(1, 1, 32, 32)
    result = restore(tensor)
    assert result.shape == (1, 24, 16)


def test_restore_preserves_values():
    """Test restore preserves tensor values."""
    restore = RestoreTransform(
        pad_info={"top": 0, "bottom": 0, "left": 0, "right": 0},
        resize_scale=1.0,
        original_size=(8, 8),
    )
    tensor = torch.zeros(1, 1, 8, 8)
    tensor[0, 0, 3:5, 3:5] = 1.0
    result = restore(tensor)
    assert result[0, 3, 3] == 1.0
    assert result[0, 0, 0] == 0.0
