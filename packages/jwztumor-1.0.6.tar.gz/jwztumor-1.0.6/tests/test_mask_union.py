"""Tests for mask union utilities."""
import pytest
import numpy as np

from JwzTumor.data.mask_utils import (
    binarize_mask, union_masks, generate_edge_target,
    generate_sdm_target, largest_connected_component,
    remove_small_regions, compute_foreground_ratio,
)


def test_binarize_mask():
    mask = np.array([[0, 128, 255], [1, 0, 50]], dtype=np.float32)
    result = binarize_mask(mask)
    assert result.dtype == np.float32
    assert (result == np.array([[0, 1, 1], [1, 0, 1]], dtype=np.float32)).all()


def test_union_masks():
    m1 = np.array([[1, 0], [0, 0]], dtype=np.float32)
    m2 = np.array([[0, 1], [0, 0]], dtype=np.float32)
    result = union_masks([m1, m2])
    expected = np.array([[1, 1], [0, 0]], dtype=np.float32)
    assert (result == expected).all()


def test_union_masks_single():
    m = np.array([[1, 0], [0, 1]], dtype=np.float32)
    result = union_masks([m])
    assert (result == m).all()


def test_union_masks_empty():
    with pytest.raises(ValueError):
        union_masks([])


def test_edge_target():
    mask = np.zeros((32, 32), dtype=np.float32)
    mask[10:20, 10:20] = 1.0
    edge = generate_edge_target(mask, width=2)
    assert edge.shape == (32, 32)
    assert edge.dtype == np.float32
    # Edge should be non-zero
    assert edge.sum() > 0
    # Edge should be binary
    assert set(np.unique(edge)).issubset({0.0, 1.0})


def test_edge_target_empty():
    mask = np.zeros((16, 16), dtype=np.float32)
    edge = generate_edge_target(mask)
    assert edge.sum() == 0


def test_sdm_target():
    mask = np.zeros((32, 32), dtype=np.float32)
    mask[10:20, 10:20] = 1.0
    sdm = generate_sdm_target(mask)
    assert sdm.shape == (32, 32)
    # Inside should be positive
    assert sdm[15, 15] > 0
    # Outside should be negative
    assert sdm[0, 0] < 0


def test_largest_connected_component():
    mask = np.zeros((32, 32), dtype=np.float32)
    mask[2:5, 2:5] = 1.0   # small component
    mask[15:25, 15:25] = 1.0  # large component
    result = largest_connected_component(mask)
    assert result.sum() == 100  # 10x10 large component only


def test_remove_small_regions():
    mask = np.zeros((32, 32), dtype=np.float32)
    mask[2:4, 2:4] = 1.0   # 4 pixels, too small
    mask[10:20, 10:20] = 1.0  # 100 pixels
    result = remove_small_regions(mask, min_size=10)
    assert result.sum() == 100


def test_foreground_ratio():
    mask = np.zeros((10, 10), dtype=np.float32)
    mask[:5, :5] = 1.0
    ratio = compute_foreground_ratio(mask)
    assert abs(ratio - 0.25) < 1e-6
