"""Tests for BUSI dataset."""
import pytest


def test_busi_dataset_import():
    """Test BUSI dataset can be imported."""
    from JwzTumor.data.busi_dataset import BUSIDataset
    assert BUSIDataset is not None


def test_busi_skip_normal():
    """Test that normal class is properly ignored."""
    from JwzTumor.data.busi_dataset import BUSIDataset
    import tempfile, os

    with tempfile.TemporaryDirectory() as tmpdir:
        benign_dir = os.path.join(tmpdir, "benign")
        os.makedirs(benign_dir)

        # Create a dummy image
        from PIL import Image
        img = Image.fromarray(np.zeros((64, 64), dtype=np.uint8))
        img.save(os.path.join(benign_dir, "benign (1).png"))

        ds = BUSIDataset(
            data_root=tmpdir,
            classes=["benign", "malignant"],
            ignore_classes=["normal-不使用"],
        )
        assert len(ds) == 1
        assert ds.samples[0]["label"] == 0  # benign
        assert ds.samples[0]["domain_id"] == 4  # BUSI


def test_busi_rgb_to_grayscale():
    """Test that BUSI RGB images are converted to grayscale."""
    from JwzTumor.data.busi_dataset import BUSIDataset
    assert BUSIDataset is not None  # Import test - actual RGB test requires real data


import numpy as np
