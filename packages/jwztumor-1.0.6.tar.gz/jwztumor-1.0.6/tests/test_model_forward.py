"""Tests for full model forward pass."""
import pytest
import torch
import types


def _make_config():
    """Create minimal config for model testing."""
    cfg = types.SimpleNamespace()
    cfg.model = types.SimpleNamespace(
        name="LABDG_DGBC_MTLNet_MPTC",
        raw_input_channels=1,
        pre_channels=16,
        encoder_input_channels=16,
        encoder_channels=[64, 128, 256, 512],
        prompt_dim=128,
        challenge_dim=8,
        use_mamba=True,
        mamba_impl="mamba_like",
        use_real_mamba=False,
        use_mpp=True,
        use_edge_head=True,
        use_sdm_head=True,
        use_uncertainty_head=True,
        use_artifact_head=True,
        use_center_scale_head=True,
        use_peritumoral_ring=True,
        ring_radius_min=8,
        ring_radius_max=16,
        boundary_width=5,
        dropout=0.2,
    )
    cfg.dataset = types.SimpleNamespace(
        num_classes=2,
        model_input_size=64,
    )
    return cfg


def test_model_forward_output_keys():
    """Test that model forward returns all required output keys."""
    from JwzTumor.models.model_factory import create_model

    config = _make_config()
    model = create_model(config)
    model.eval()

    image = torch.randn(2, 1, 64, 64)
    with torch.no_grad():
        outputs = model(image)

    required_keys = [
        "cls_logits", "cls_prob",
        "seg_logits", "seg_prob",
        "edge_logits", "edge_prob",
        "sdm_pred", "uncertainty_map",
        "coarse_mask", "morph_prompt",
        "challenge_vector", "aux_maps",
    ]
    for key in required_keys:
        assert key in outputs, f"Missing output key: {key}"


def test_model_forward_shapes():
    """Test output tensor shapes."""
    from JwzTumor.models.model_factory import create_model

    config = _make_config()
    model = create_model(config)
    model.eval()

    image = torch.randn(2, 1, 64, 64)
    with torch.no_grad():
        outputs = model(image)

    assert outputs["cls_logits"].shape == (2, 2)
    assert outputs["cls_prob"].shape == (2, 2)
    assert outputs["seg_prob"].shape[0] == 2
    assert outputs["seg_prob"].shape[1] == 1
    assert outputs["morph_prompt"].shape[0] == 2


def test_model_cls_prob_sums_to_one():
    """Test that classification probabilities sum to 1."""
    from JwzTumor.models.model_factory import create_model

    config = _make_config()
    model = create_model(config)
    model.eval()

    image = torch.randn(2, 1, 64, 64)
    with torch.no_grad():
        outputs = model(image)

    sums = outputs["cls_prob"].sum(dim=-1)
    assert torch.allclose(sums, torch.ones(2), atol=1e-5)


def test_model_gradient_flow():
    """Test that gradients flow through the full model."""
    from JwzTumor.models.model_factory import create_model

    config = _make_config()
    model = create_model(config)

    image = torch.randn(1, 1, 64, 64)
    mask = torch.zeros(1, 1, 64, 64)
    mask[0, 0, 20:40, 20:40] = 1.0
    label = torch.tensor([1])

    outputs = model(image, mask=mask, label=label)
    loss = outputs["cls_logits"].sum() + outputs["seg_prob"].sum()
    loss.backward()

    # Check at least some parameters have gradients
    has_grad = any(p.grad is not None for p in model.parameters() if p.requires_grad)
    assert has_grad, "No gradients flowing through model"
