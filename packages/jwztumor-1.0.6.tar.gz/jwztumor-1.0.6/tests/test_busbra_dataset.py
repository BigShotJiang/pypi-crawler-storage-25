"""Tests for BUSBRA dataset."""
import pytest
import numpy as np
from unittest.mock import MagicMock, patch


def test_busbra_dataset_import():
    """Test BUSBRA dataset can be imported."""
    from JwzTumor.data.busbra_dataset import BUSBRADataset
    assert BUSBRADataset is not None


def test_busbra_sample_list_empty():
    """Test BUSBRA with no matching files returns empty."""
    from JwzTumor.data.busbra_dataset import BUSBRADataset
    import tempfile, os
    with tempfile.TemporaryDirectory() as tmpdir:
        os.makedirs(os.path.join(tmpdir, "Images"))
        os.makedirs(os.path.join(tmpdir, "Masks"))
        # Create empty CSV
        import pandas as pd
        csv_path = os.path.join(tmpdir, "bus_data.csv")
        pd.DataFrame(columns=["ID", "Case", "Pathology"]).to_csv(csv_path, index=False)

        ds = BUSBRADataset(data_root=tmpdir, csv_path=csv_path, is_train=False)
        assert len(ds) == 0
