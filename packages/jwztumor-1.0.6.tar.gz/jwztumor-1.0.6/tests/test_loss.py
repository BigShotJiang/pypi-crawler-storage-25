"""Tests for loss functions."""
import pytest
import torch


def test_seg_loss_import():
    from JwzTumor.losses.segmentation_losses import DiceBCELoss
    loss_fn = DiceBCELoss()
    pred = torch.sigmoid(torch.randn(2, 1, 16, 16, requires_grad=True))
    target = torch.zeros(2, 1, 16, 16)
    target[0, 0, 4:8, 4:8] = 1.0
    loss = loss_fn(pred, target)
    assert loss.item() >= 0


def test_boundary_loss_import():
    from JwzTumor.losses.boundary_losses import BoundaryBCELoss
    loss_fn = BoundaryBCELoss()
    pred = torch.sigmoid(torch.randn(2, 1, 16, 16))
    target = torch.zeros(2, 1, 16, 16)
    target[0, 0, 7:9, 4:12] = 1.0
    loss = loss_fn(pred, target)
    assert loss.item() >= 0


def test_classification_loss_import():
    from JwzTumor.losses.classification_losses import AsymmetricFocalLoss
    loss_fn = AsymmetricFocalLoss()
    logits = torch.randn(4, 2, requires_grad=True)
    labels = torch.tensor([0, 1, 1, 0])
    loss = loss_fn(logits, labels)
    assert loss.item() >= 0


def test_auc_loss_functional():
    """AUC loss MUST be functional (not dummy)."""
    from JwzTumor.losses.auc_losses import AUCMarginLoss
    loss_fn = AUCMarginLoss(margin=1.0)

    # Well separated: malignant probs >> benign probs with margin > 1.0
    probs = torch.tensor([0.0, 0.0, 1.0, 1.0], requires_grad=True)
    labels = torch.tensor([0, 0, 1, 1])
    loss = loss_fn(probs, labels)
    assert loss.item() == 0.0, f"Perfect separation (margin satisfied) should give 0 loss, got {loss.item()}"

    # Bad separation
    probs_bad = torch.tensor([0.9, 0.8, 0.1, 0.2], requires_grad=True)
    loss_bad = loss_fn(probs_bad, labels)
    assert loss_bad.item() > 0, f"Bad separation should give positive loss"
    loss_bad.backward()
    assert probs_bad.grad is not None, "AUC loss must be differentiable"


def test_loss_factory_import():
    from JwzTumor.losses.loss_factory import MultiTaskLossFactory
    assert MultiTaskLossFactory is not None
