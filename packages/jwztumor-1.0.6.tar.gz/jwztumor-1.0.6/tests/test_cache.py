"""Tests for DatasetCache."""
import pytest
import torch

from JwzTumor.data.cache import DatasetCache


def test_cache_ram_mode():
    cache = DatasetCache(mode="ram")
    data = {"image": torch.randn(1, 64, 64), "label": torch.tensor(1)}
    cache.put("test_image.png", data)
    retrieved = cache.get("test_image.png")
    assert retrieved is not None
    assert retrieved["label"].item() == 1


def test_cache_none_mode():
    cache = DatasetCache(mode="none")
    data = {"image": torch.randn(1, 64, 64)}
    cache.put("test.png", data)
    assert cache.get("test.png") is None


def test_cache_miss():
    cache = DatasetCache(mode="ram")
    assert cache.get("nonexistent.png") is None


def test_cache_stats():
    cache = DatasetCache(mode="ram")
    data = {"x": torch.tensor(1)}
    cache.put("a.png", data)
    cache.get("a.png")  # hit
    cache.get("b.png")  # miss
    stats = cache.stats()
    assert stats["hits"] == 1
    assert stats["misses"] == 1
    assert stats["size"] == 1


def test_cache_clear():
    cache = DatasetCache(mode="ram")
    cache.put("a.png", {"x": torch.tensor(1)})
    cache.clear()
    assert cache.get("a.png") is None
    assert cache.stats()["size"] == 0
