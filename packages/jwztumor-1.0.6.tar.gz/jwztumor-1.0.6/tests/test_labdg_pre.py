"""Tests for LABDG-Pre model."""
import pytest
import torch

from JwzTumor.models.labdg_pre import LABDGPreprocessor


def _make_config(pre_channels=16, use_artifact_head=True, use_center_scale_head=True):
    """Create a minimal config for LABDG-Pre testing."""
    import types
    cfg = types.SimpleNamespace()
    cfg.model = types.SimpleNamespace(
        pre_channels=pre_channels,
        raw_input_channels=1,
        use_artifact_head=use_artifact_head,
        use_center_scale_head=use_center_scale_head,
    )
    return cfg


def test_labdg_pre_output_shapes():
    config = _make_config()
    model = LABDGPreprocessor(config)
    image = torch.randn(2, 1, 64, 64)
    z_pre, aux_maps = model(image)

    assert z_pre.shape == (2, 16, 64, 64), f"Expected [2,16,64,64], got {z_pre.shape}"


def test_labdg_pre_aux_maps_complete():
    config = _make_config()
    model = LABDGPreprocessor(config)
    image = torch.randn(2, 1, 64, 64)
    _, aux_maps = model(image)

    required_keys = [
        "raw_view", "enhanced_view", "coarse_mask",
        "center_heatmap", "scale_map", "artifact_mask",
        "edge", "speckle", "texture", "attenuation",
    ]
    for key in required_keys:
        assert key in aux_maps, f"Missing aux_map key: {key}"
        assert aux_maps[key].shape == (2, 1, 64, 64), f"{key} shape wrong: {aux_maps[key].shape}"


def test_labdg_pre_different_channels():
    config = _make_config(pre_channels=32)
    model = LABDGPreprocessor(config)
    image = torch.randn(1, 1, 32, 32)
    z_pre, _ = model(image)
    assert z_pre.shape == (1, 32, 32, 32)


def test_labdg_pre_disabled_heads():
    config = _make_config(use_artifact_head=False, use_center_scale_head=False)
    model = LABDGPreprocessor(config)
    image = torch.randn(1, 1, 32, 32)
    z_pre, aux_maps = model(image)
    assert z_pre.shape == (1, 16, 32, 32)
    # artifact_mask should be zeros
    assert aux_maps["artifact_mask"].sum() == 0


def test_labdg_pre_gradient_flow():
    config = _make_config()
    model = LABDGPreprocessor(config)
    image = torch.randn(1, 1, 32, 32, requires_grad=True)
    z_pre, _ = model(image)
    loss = z_pre.sum()
    loss.backward()
    assert image.grad is not None
