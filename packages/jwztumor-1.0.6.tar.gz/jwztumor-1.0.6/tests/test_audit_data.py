"""Tests for dataset audit functionality."""
import pytest
import os
import tempfile
import numpy as np
from PIL import Image


def test_audit_busi_import():
    from JwzTumor.data.audit import audit_busi
    assert audit_busi is not None


def test_audit_busbra_import():
    from JwzTumor.data.audit import audit_busbra
    assert audit_busbra is not None


def test_audit_dataset_import():
    from JwzTumor.data.audit import audit_dataset
    assert audit_dataset is not None


def test_audit_busi_basic():
    """Test BUSI audit with mock directory structure."""
    from JwzTumor.data.audit import audit_busi

    with tempfile.TemporaryDirectory() as tmpdir:
        # Create benign directory
        benign_dir = os.path.join(tmpdir, "benign")
        os.makedirs(benign_dir)

        # Create dummy image and mask
        img = Image.fromarray(np.zeros((64, 64), dtype=np.uint8))
        img.save(os.path.join(benign_dir, "benign (1).png"))
        img.save(os.path.join(benign_dir, "benign (1)_mask.png"))

        result = audit_busi(tmpdir)
        assert result["dataset"] == "BUSI"
        assert result["stats"]["benign_images"] == 1
        assert "issues" in result


def test_audit_busi_normal_skip():
    """Test that normal folder is detected."""
    from JwzTumor.data.audit import audit_busi

    with tempfile.TemporaryDirectory() as tmpdir:
        normal_dir = os.path.join(tmpdir, "normal-不使用")
        os.makedirs(normal_dir)
        img = Image.fromarray(np.zeros((32, 32), dtype=np.uint8))
        img.save(os.path.join(normal_dir, "normal (1).png"))

        result = audit_busi(tmpdir)
        assert result["stats"].get("normal_skipped", 0) == 1
