"""Tests for metrics computation."""
import pytest
import numpy as np

from JwzTumor.evaluation.classification_metrics import compute_classification_metrics
from JwzTumor.evaluation.segmentation_metrics import compute_segmentation_metrics


def test_classification_metrics_perfect():
    y_true = np.array([0, 0, 1, 1])
    y_prob = np.array([0.1, 0.2, 0.8, 0.9])
    metrics = compute_classification_metrics(y_true, y_prob)
    assert metrics["accuracy"] == 1.0
    assert metrics["sensitivity"] == 1.0
    assert metrics["specificity"] == 1.0
    assert metrics["f1"] == 1.0


def test_classification_metrics_imperfect():
    y_true = np.array([0, 0, 1, 1, 1])
    y_prob = np.array([0.3, 0.8, 0.6, 0.7, 0.2])
    metrics = compute_classification_metrics(y_true, y_prob)
    assert 0 <= metrics["accuracy"] <= 1
    assert 0 <= metrics["sensitivity"] <= 1


def test_segmentation_metrics_perfect():
    mask = np.zeros((32, 32), dtype=np.float32)
    mask[10:20, 10:20] = 1.0
    metrics = compute_segmentation_metrics(mask, mask)
    assert metrics["dice"] == 1.0
    assert metrics["iou"] == 1.0


def test_segmentation_metrics_no_overlap():
    pred = np.zeros((32, 32), dtype=np.float32)
    pred[:10, :10] = 1.0
    gt = np.zeros((32, 32), dtype=np.float32)
    gt[20:30, 20:30] = 1.0
    metrics = compute_segmentation_metrics(pred, gt)
    assert metrics["dice"] == 0.0
    assert metrics["iou"] == 0.0


def test_config_load():
    from JwzTumor.utils.config import Config
    import tempfile, os
    config = Config()
    assert config.model.name == "LABDG_DGBC_MTLNet_MPTC"
    assert config.dataset.model_input_size == 512
    assert config.training.batch_size == 8
