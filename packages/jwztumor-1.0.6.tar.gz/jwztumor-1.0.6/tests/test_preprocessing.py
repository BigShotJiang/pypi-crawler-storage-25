"""Tests for preprocessing pipeline."""
import pytest
import numpy as np

from JwzTumor.data.preprocessing import BreastUSPreprocessor, RestoreTransform


def test_preprocessor_creation():
    preprocessor = BreastUSPreprocessor(model_input_size=128)
    assert preprocessor.model_input_size == 128


def test_preprocess_grayscale():
    preprocessor = BreastUSPreprocessor(model_input_size=64)
    image = np.random.rand(100, 80).astype(np.float32) * 255
    result = preprocessor.process_infer(image)
    assert "image" in result
    assert result["image"].shape == (1, 64, 64)
    assert result["original_size"] == (100, 80)


def test_preprocess_rgb():
    preprocessor = BreastUSPreprocessor(model_input_size=64)
    image = np.random.randint(0, 255, (100, 80, 3), dtype=np.uint8)
    result = preprocessor.process_infer(image)
    assert result["image"].shape == (1, 64, 64)


def test_preprocess_with_mask():
    preprocessor = BreastUSPreprocessor(model_input_size=64)
    image = np.random.rand(100, 80).astype(np.float32) * 255
    mask = np.zeros((100, 80), dtype=np.float32)
    mask[30:70, 20:60] = 1.0
    result = preprocessor.process_train(image, mask, label=1)
    assert result["image"].shape == (1, 64, 64)
    assert result["mask"].shape == (1, 64, 64)
    assert result["edge"].shape == (1, 64, 64)
    assert result["sdm"].shape == (1, 64, 64)
    assert result["label"].item() == 1
    assert result["has_mask"].item() is True


def test_preprocess_no_mask():
    preprocessor = BreastUSPreprocessor(model_input_size=64)
    image = np.random.rand(100, 80).astype(np.float32) * 255
    result = preprocessor.process_train(image, None, label=0)
    assert result["has_mask"].item() is False
    assert result["mask"].sum() == 0


def test_restore_transform():
    pad_info = {"top": 10, "bottom": 10, "left": 20, "bottom": 20}
    pad_info = {"top": 10, "bottom": 10, "left": 20, "right": 20}
    restore = RestoreTransform(
        pad_info=pad_info,
        resize_scale=0.5,
        original_size=(100, 80),
    )
    # Simulate a model output [1, 1, 128, 128]
    import torch
    tensor = torch.ones(1, 1, 128, 128)
    restored = restore(tensor)
    assert restored.shape[1] == 100 or restored.shape[1] == 80  # Restored to near original


def test_normalize_output_range():
    preprocessor = BreastUSPreprocessor(model_input_size=64)
    image = np.random.rand(50, 50).astype(np.float32) * 255
    result = preprocessor.process_infer(image)
    assert result["image"].min() >= 0
    assert result["image"].max() <= 1
