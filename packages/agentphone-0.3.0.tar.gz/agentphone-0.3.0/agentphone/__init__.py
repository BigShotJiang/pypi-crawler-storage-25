"""
AgentPhone Python SDK

Give your AI agents phone numbers, SMS, and voice calls.

Usage::

    import os
    from agentphone import AgentPhone

    client = AgentPhone(api_key=os.environ["AGENTPHONE_API_KEY"])
    number = client.numbers.buy(country="US")
    call = client.calls.make_conversation(
        agent_id="...",
        to_number="+14155551234",
        topic="Schedule a dentist appointment for next Tuesday at 2pm",
    )
"""

from .async_client import AsyncAgentPhone
from .client import AgentPhone
from ._http import AgentPhoneError, AuthenticationError, NotFoundError, RateLimitError
from .models import (
    Agent,
    AgentList,
    AgentNumber,
    Call,
    CallList,
    CallTranscript,
    Conversation,
    ConversationList,
    ConversationMessage,
    DailyUsage,
    DailyUsagePoint,
    Message,
    MessageList,
    MonthlyUsage,
    MonthlyUsagePoint,
    NumberLimits,
    PhoneNumber,
    PhoneNumberList,
    PlanInfo,
    PlanLimits,
    Usage,
    UsageStats,
    Webhook,
    WebhookDelivery,
    WebhookDeliveryStats,
    WebhookEvent,
    WebhookEventData,
    WebhookHistoryItem,
)
from .webhook import WebhookVerificationError, construct_event, verify_webhook

__version__ = "0.2.0"

__all__ = [
    # Clients
    "AgentPhone",
    "AsyncAgentPhone",
    # Errors
    "AgentPhoneError",
    "AuthenticationError",
    "NotFoundError",
    "RateLimitError",
    "WebhookVerificationError",
    # Webhook helpers
    "verify_webhook",
    "construct_event",
    # Models
    "Agent",
    "AgentList",
    "AgentNumber",
    "Call",
    "CallList",
    "CallTranscript",
    "Conversation",
    "ConversationList",
    "ConversationMessage",
    "DailyUsage",
    "DailyUsagePoint",
    "Message",
    "MessageList",
    "MonthlyUsage",
    "MonthlyUsagePoint",
    "NumberLimits",
    "PhoneNumber",
    "PhoneNumberList",
    "PlanInfo",
    "PlanLimits",
    "Usage",
    "UsageStats",
    "Webhook",
    "WebhookDelivery",
    "WebhookDeliveryStats",
    "WebhookEvent",
    "WebhookEventData",
    "WebhookHistoryItem",
]
