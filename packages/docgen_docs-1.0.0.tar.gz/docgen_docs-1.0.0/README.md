# 🧪 Emperor Test Generator

ذكاء اصطناعي لتوليد اختبارات Python تلقائياً مع إصلاح ذاتي.

## التثبيت

```bash
pip install -e ~/docgen-emperor
```

الاستخدام

```bash
docgen-test --login <API_KEY>
docgen-test src/
docgen-test https://github.com/user/repo
docgen-test -r
```

المميزات

· ✅ Unit + Integration + Scenario Tests
· ✅ 15 محاولة إصلاح تلقائي
· ✅ 5 مستويات إصلاح
· ✅ ذاكرة تتعلم
· ✅ دعم GitHub عام وخاص
  EOF

2. LICENSE

cat > LICENSE << 'EOF'
MIT License

Copyright (c) 2025 DocGen

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND.
