from setuptools import setup, find_packages

setup(
    name="docgen-docs",
    version="1.0.0",
    packages=find_packages(),
    install_requires=["requests>=2.28.0"],
    entry_points={
        "console_scripts": [
            "docgen-docs=docgen_docs.cli:main",
        ],
    },
)
