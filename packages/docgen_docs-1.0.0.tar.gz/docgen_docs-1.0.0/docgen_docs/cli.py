#!/usr/bin/env python3
"""DocGen Docs CLI v3.1 - Hybrid AI + GitHub + Lang + Private"""
import sys, os
from pathlib import Path
from .generator import HybridDocGenerator
from .auth import check_subscription, get_api_key, login, increment_usage

def main():
    args = sys.argv[1:]
    lang = 'ar'
    token = None
    mode = 'all'
    target = '.'
    
    # Parse flags
    i = 0
    while i < len(args):
        if args[i] == '--login':
            key = args[i+1] if i+1 < len(args) else ''
            ok, msg = login(key)
            if ok:
                from .auth import check_subscription
                sub = check_subscription()
                tier = sub.get('tier', 'free')
                tier_labels = {'free':'مجاني','basic':'أساسي','pro':'برو','unlimited':'غير محدود'}
                print(f"""
\033[32m╔══════════════════════════════════════════════╗
║      📄 DocGen Docs v3.1                     ║
║                                              ║
║  ✅ {msg}                     ║
║  👤 {sub.get('username','')} | 💎 {tier_labels.get(tier, tier)} | 📊 {sub.get('daily_used',0)}/{sub.get('daily_limit',5)}                        ║
║                                              ║
║  يولّد التوثيقات بالذكاء الاصطناعي             ║
╚══════════════════════════════════════════════╝\033[0m

  docgen-docs <path>              توثيق محلي
  docgen-docs <github-url>        توثيق GitHub عام
  docgen-docs <url> --token=ghp_  توثيق GitHub خاص
  docgen-docs --readme --lang=en  README إنجليزي
  docgen-docs --api --lang=ar     API Docs عربي
  docgen-docs --wiki <path>       Wiki
""")
            else:
                print(f"❌ {msg}")
            return
        elif args[i] == '--lang' or args[i].startswith('--lang='):
            if '=' in args[i]:
                lang = args[i].split('=',1)[1]
            else:
                lang = args[i+1] if i+1 < len(args) else 'ar'
            i += 2
            continue
        elif args[i] == '--token' or args[i].startswith('--token='):
            if '=' in args[i]:
                token = args[i].split('=',1)[1]
            else:
                token = args[i+1] if i+1 < len(args) else None
            i += 2
            continue
        elif args[i] in ('--readme', '--api', '--wiki'):
            mode = args[i][2:]
            i += 1
            continue
        elif not args[i].startswith('--'):
            target = args[i]
            i += 1
            continue
        i += 1
    
    # تحقق من تسجيل الدخول
    from .auth import check_subscription
    sub = check_subscription()
    
    if len(sys.argv) < 2:
        if sub['allowed']:
            print("📄 DocGen Docs v3.1 - جاهز!")
            print("")
            print("  docgen-docs .                  توثيق المشروع الحالي")
            print("  docgen-docs src/               توثيق مجلد")
            print("  docgen-docs github.com/repo    توثيق مستودع GitHub")
            print("  docgen-docs --readme --lang=en README إنجليزي")
            return
        if not sub['allowed']:
            print("❌ يجب تسجيل الدخول أولاً")
            print("   ١. افتح http://127.0.0.1:5000/api-keys")
            print("   ٢. نسخ API Key")
            print("   ٣. docgen-docs --login <API_KEY>")
            return
        print("📄 DocGen Docs v3.1")
        print("  docgen-docs <path>              توثيق محلي")
        print("  docgen-docs <github-url>        توثيق GitHub عام")
        print("  docgen-docs <url> --token=ghp_  توثيق GitHub خاص")
        print("  docgen-docs --readme --lang=en  README إنجليزي")
        print("  docgen-docs --api --lang=ar     API Docs عربي")
        print("  docgen-docs --wiki <path>       Wiki")
        print("  docgen-docs --login <KEY>       تسجيل الدخول")
        return

    sub = check_subscription()
    if not sub['allowed']:
        print(f"❌ {sub['reason']}")
        return

    gen = HybridDocGenerator(lang=lang)

    # GitHub
    if 'github.com' in target:
        print(f"🔄 Cloning {target}...")
        out = gen.generate_from_github(target, token=token)
        print(f"✅ Docs: {out}")
        increment_usage()
        return

    # Local
    target_path = target
    output_dir = f"{target}/docs" if os.path.isdir(target) else f"{Path(target).parent}/docs"
    
    print(f"📄 Generating {mode} docs in {lang.upper()} for: {target}")
    
    if mode == 'readme':
        r = gen.generate_readme(target_path, output_dir)
        print(f"✅ README: {r}")
    elif mode == 'api':
        a = gen.generate_api_docs(target_path, output_dir)
        print(f"✅ API Docs: {a}")
    elif mode == 'wiki':
        w = gen.generate_wiki(target_path, output_dir)
        print(f"✅ Wiki: {w}")
    else:
        r = gen.generate_readme(target_path, output_dir)
        a = gen.generate_api_docs(target_path, output_dir)
        w = gen.generate_wiki(target_path, output_dir)
        if r: print(f"✅ README: {r}")
        if a: print(f"✅ API Docs: {a}")
        if w: print(f"✅ Wiki: {w}")

    increment_usage()

if __name__ == '__main__':
    main()
