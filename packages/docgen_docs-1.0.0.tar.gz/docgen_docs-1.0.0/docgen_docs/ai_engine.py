"""AI Hybrid Engine - 84 keys, 3 providers, auto-fallback"""
import json, random, httpx
from pathlib import Path

class HybridAI:
    def __init__(self):
        self.keys = self.load_keys()
        self.current_groq = 0
        self.current_gemini = 0
        self.current_openrouter = 0
    
    def load_keys(self):
        path = Path.home() / 'working_keys.json'
        if path.exists():
            return json.loads(path.read_text())
        return {}
    
    def ask_groq(self, prompt):
        keys = self.keys.get('groq', {}).get('keys', [])
        for _ in range(len(keys)):
            key = keys[self.current_groq % len(keys)]
            self.current_groq += 1
            try:
                r = httpx.post('https://api.groq.com/openai/v1/chat/completions',
                    headers={'Authorization': f'Bearer {key}'},
                    json={'model':'llama-3.1-8b-instant','messages':[{'role':'user','content':prompt}],'max_tokens':500},
                    timeout=15)
                if r.status_code == 200:
                    return r.json()['choices'][0]['message']['content']
            except: continue
        return None
    
    def ask_gemini(self, prompt):
        keys = self.keys.get('gemini', {}).get('keys', [])
        for _ in range(len(keys)):
            key = keys[self.current_gemini % len(keys)]
            self.current_gemini += 1
            try:
                r = httpx.post(
                    f'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key={key}',
                    json={'contents':[{'parts':[{'text':prompt}]}]},
                    timeout=15)
                if r.status_code == 200:
                    return r.json()['candidates'][0]['content']['parts'][0]['text']
            except: continue
        return None
    
    def ask(self, prompt, tier='free'):
        # Tier-based routing
        if tier == 'free':
            return self.ask_groq(prompt)
        elif tier == 'basic':
            return self.ask_gemini(prompt)
        else:
            result = self.ask_gemini(prompt) or self.ask_groq(prompt)
            if not result and tier == 'unlimited':
                result = self.ask_openrouter(prompt)
            return result
