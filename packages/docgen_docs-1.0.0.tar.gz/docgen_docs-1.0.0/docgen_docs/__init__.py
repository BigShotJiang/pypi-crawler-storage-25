"""DocGen Docs - AI Documentation Generator"""
__version__ = "1.0.0"
