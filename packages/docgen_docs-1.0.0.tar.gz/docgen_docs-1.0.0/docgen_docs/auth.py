"""التحقق من اشتراك المستخدم"""
import os, json, requests
from pathlib import Path

CONFIG_FILE = Path.home() / '.docgen_config.json'
API_BASE = 'http://127.0.0.1:5000'

def get_api_key():
    if CONFIG_FILE.exists():
        with open(CONFIG_FILE) as f:
            config = json.load(f)
            return config.get('api_key', '')
    return ''

def save_api_key(api_key):
    config = {}
    if CONFIG_FILE.exists():
        with open(CONFIG_FILE) as f:
            config = json.load(f)
    config['api_key'] = api_key
    with open(CONFIG_FILE, 'w') as f:
        json.dump(config, f)

def check_subscription():
    api_key = get_api_key()
    if not api_key:
        return {'allowed': False, 'reason': 'يجب تسجيل الدخول. استخدم: docgen-test --login'}
    
    try:
        r = requests.get(f'{API_BASE}/me', headers={'X-API-Key': api_key}, timeout=5)
        if r.status_code != 200:
            return {'allowed': False, 'reason': 'API key غير صالح'}
        
        data = r.json()
        usage = data.get('usage', {})
        
        return {
            'allowed': True,
            'tier': 'pro',
            'daily_used': usage.get('daily_used', 0),
            'daily_limit': 999,
            'remaining': 999
        }
    except:
        return {'allowed': False, 'reason': 'لا يمكن الاتصال بالخادم'}

def login(api_key):
    try:
        r = requests.get(f'{API_BASE}/me', headers={'X-API-Key': api_key}, timeout=5)
        if r.status_code == 200:
            save_api_key(api_key)
            return True, 'تم تسجيل الدخول بنجاح'
        return False, 'API key غير صالح'
    except:
        return False, 'لا يمكن الاتصال بالخادم'

def increment_usage():
    """تحديث عداد الاستخدام"""
    api_key = get_api_key()
    if not api_key:
        return
    try:
        requests.post(f'{API_BASE}/me/usage/increment',
                     headers={'X-API-Key': api_key}, timeout=5)
    except:
        pass
