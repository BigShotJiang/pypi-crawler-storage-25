"""Hybrid Doc Generator v3.0 - AI + Regex Fallback + GitHub"""
import os, json, ast, random, urllib.request, subprocess, tempfile, shutil, re
from pathlib import Path
from datetime import datetime, timezone

class HybridDocGenerator:
    def __init__(self, lang='ar'):
        self.lang = lang
        self.ai_tried = 0
        self.ai_success = 0
        self.regex_used = 0
    
    def get_keys(self, prefix):
        keys = []
        for i in range(1, 100):
            key = os.getenv(f'{prefix}_{i}')
            if key: keys.append(key)
            else: break
        return keys
    
    def ask_openrouter(self, prompt):
        keys = self.get_keys('OR_KEY')
        random.shuffle(keys)
        for key in keys[:5]:
            try:
                data = json.dumps({
                    'model': 'google/gemini-2.0-flash-001',
                    'messages': [{'role':'user','content':prompt}],
                    'max_tokens': 500
                }).encode()
                req = urllib.request.Request(
                    'https://openrouter.ai/api/v1/chat/completions',
                    data=data,
                    headers={
                        'Authorization': f'Bearer {key}',
                        'Content-Type': 'application/json',
                        'HTTP-Referer': 'http://127.0.0.1:5000',
                        'X-Title': 'DocGen'
                    })
                with urllib.request.urlopen(req, timeout=20) as r:
                    self.ai_tried += 1
                    self.ai_success += 1
                    return json.loads(r.read())['choices'][0]['message']['content']
            except: continue
        return None
    
    def ask_gemini(self, prompt):
        keys = self.get_keys('GEMINI_KEY')
        random.shuffle(keys)
        for key in keys[:5]:
            try:
                data = json.dumps({'contents': [{'parts': [{'text': prompt}]}]}).encode()
                req = urllib.request.Request(
                    f'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key={key}',
                    data=data, headers={'Content-Type': 'application/json'})
                with urllib.request.urlopen(req, timeout=20) as r:
                    self.ai_tried += 1
                    self.ai_success += 1
                    return json.loads(r.read())['candidates'][0]['content']['parts'][0]['text']
            except: continue
        return None
    
    def ask_groq(self, prompt):
        keys = self.get_keys('GROQ_KEY')
        random.shuffle(keys)
        for key in keys[:5]:
            try:
                data = json.dumps({
                    'model': 'llama-3.1-8b-instant',
                    'messages': [{'role':'user','content':prompt}],
                    'max_tokens': 500
                }).encode()
                req = urllib.request.Request(
                    'https://api.groq.com/openai/v1/chat/completions',
                    data=data, headers={'Authorization': f'Bearer {key}', 'Content-Type': 'application/json'})
                with urllib.request.urlopen(req, timeout=20) as r:
                    self.ai_tried += 1
                    self.ai_success += 1
                    return json.loads(r.read())['choices'][0]['message']['content']
            except: continue
        return None
    
    def ask_ai(self, prompt):
        """هجين 3 طبقات"""
        for func in [self.ask_openrouter, self.ask_gemini, self.ask_groq]:
            result = func(prompt)
            if result: return result
        return None
    
    def _analyze_files(self, target_path):
        """تحليل الملفات - دوال وكلاسات"""
        path = Path(target_path)
        files = list(path.rglob('*.py')) if path.is_dir() else [path]
        if not files: return [], [], []
        
        all_funcs = []
        all_classes = []
        imports = set()
        
        for f in files[:50]:
            try:
                tree = ast.parse(f.read_text())
                for node in ast.walk(tree):
                    if isinstance(node, ast.FunctionDef) and not node.name.startswith('_'):
                        args = [a.arg for a in node.args.args]
                        returns = 'None'
                        for n in ast.walk(node):
                            if isinstance(n, ast.Return) and n.value: returns = '...'; break
                        doc = ast.get_docstring(node) or ''
                        all_funcs.append({
                            'name': node.name, 'args': args, 'returns': returns,
                            'doc': doc, 'file': f.name, 'line': node.lineno
                        })
                    elif isinstance(node, ast.ClassDef):
                        all_classes.append({'name': node.name, 'file': f.name, 'line': node.lineno})
                    elif isinstance(node, ast.Import):
                        for alias in node.names: imports.add(alias.name)
                    elif isinstance(node, ast.ImportFrom):
                        for alias in node.names: imports.add(alias.name)
            except: pass
        
        return files, all_funcs, all_classes, list(imports)
    
    def generate_readme(self, target_path, output_dir):
        """README احترافي"""
        files, funcs, classes, imports = self._analyze_files(target_path)
        if not files: return None
        
        path = Path(target_path)
        project_name = path.name
        
        # AI يكتب README
        func_names = [f['name'] for f in funcs[:20]]
        class_names = [c['name'] for c in classes[:10]]
        
        lang_text = 'Arabic' if self.lang == 'ar' else 'English'
        prompt = f"""Write professional README.md in {lang_text} for: {project_name}
        Files: {len(files)} | Functions: {len(funcs)} | Classes: {len(classes)}
        Key functions: {', '.join(func_names[:10])}
        Key classes: {', '.join(class_names[:5])}
        
        Include:
        1. وصف المشروع
        2. التثبيت (pip install)
        3. استخدام سريع مع مثال كود
        4. المميزات
        5. هيكل المشروع"""
        
        ai_content = self.ask_ai(prompt)
        
        if ai_content:
            content = f"# {project_name}\n\n{ai_content}"
        else:
            # فالباك Regex
            self.regex_used += 1
            content = f"# {project_name}\n\n"
            content += f"**{len(files)} files** | **{len(funcs)} functions** | **{len(classes)} classes**\n\n"
            content += "## 📁 Files\n\n"
            for f in files[:20]: content += f"- `{f.name}`\n"
            content += "\n## ⚡ Functions\n\n"
            for fn in funcs[:20]: content += f"- `{fn['name']}({', '.join(fn['args'])})`\n"
        
        content += f"\n\n---\n*Generated by DocGen | {datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M')}*"
        
        readme_path = Path(output_dir) / 'README.md'
        readme_path.parent.mkdir(parents=True, exist_ok=True)
        readme_path.write_text(content, encoding='utf-8')
        return str(readme_path)
    
    def generate_api_docs(self, target_path, output_dir):
        """API Docs مع شرح + أمثلة"""
        files, funcs, classes, imports = self._analyze_files(target_path)
        if not files: return None
        
        path = Path(target_path)
        content = f"# API Documentation - {path.name}\n\n"
        content += f"**Functions:** {len(funcs)} | **Classes:** {len(classes)}\n\n"
        
        # قسم الكلاسات
        if classes:
            content += "## 📦 Classes\n\n"
            for cls in classes[:10]:
                content += f"### `{cls['name']}`\n"
                content += f"- 📁 `{cls['file']}:{cls['line']}`\n\n"
        
        # قسم الدوال
        if funcs:
            content += "## ⚡ Functions\n\n"
            for func in funcs[:30]:
                args_str = ', '.join(func['args'])
                content += f"### `{func['name']}({args_str})`\n\n"
                content += f"- 📁 `{func['file']}:{func['line']}`\n"
                
                # AI يشرح الدالة
                if func['args']:
                    prompt = f"Describe this Python function in one line ({'Arabic' if self.lang == 'ar' else 'English'}): def {func['name']}({args_str})"
                    ai_desc = self.ask_ai(prompt)
                    if ai_desc:
                        content += f"- 💡 {ai_desc.strip()}\n"
                
                if func['doc']:
                    content += f"- 📝 `{func['doc'][:100]}`\n"
                
                content += "\n**Parameters:** "
                if func['args']:
                    for arg in func['args']:
                        content += f"`{arg}`, "
                    content = content.rstrip(', ')
                else:
                    content += "None"
                
                content += f"\n**Returns:** `{func['returns']}`\n\n"
                content += "```python\n# Usage example\n"
                if func['args']:
                    example_args = ', '.join([f'"{a}"' for a in func['args']])
                    content += f"result = {func['name']}({example_args})\n"
                else:
                    content += f"result = {func['name']}()\n"
                content += "```\n\n"
        
        content += f"\n\n---\n*Generated by DocGen | {datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M')}*"
        
        api_path = Path(output_dir) / 'API_DOCS.md'
        api_path.parent.mkdir(parents=True, exist_ok=True)
        api_path.write_text(content, encoding='utf-8')
        return str(api_path)
    
    def generate_wiki(self, target_path, output_dir):
        """Wiki كامل"""
        files, funcs, classes, imports = self._analyze_files(target_path)
        path = Path(target_path)
        
        content = f"# Wiki - {path.name}\n\n"
        content += "## 🏠 الرئيسية\n\n"
        content += f"هذا الويكي يوثق مشروع **{path.name}**.\n\n"
        
        content += "## 📁 هيكل المشروع\n\n```\n"
        for f in files[:30]:
            content += f"{f.name}\n"
        content += "```\n\n"
        
        content += "## ⚡ الوظائف الرئيسية\n\n"
        for func in funcs[:20]:
            content += f"### {func['name']}()\n"
            if func['doc']:
                content += f"{func['doc']}\n\n"
            content += f"📁 `{func['file']}:{func['line']}`\n\n"
        
        content += f"\n\n---\n*Generated by DocGen | {datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M')}*"
        
        wiki_path = Path(output_dir) / 'WIKI.md'
        wiki_path.parent.mkdir(parents=True, exist_ok=True)
        wiki_path.write_text(content, encoding='utf-8')
        return str(wiki_path)
    
    def generate_from_github(self, url, output_base=None, token=None):
        """توليد من GitHub - يدعم عام وخاص"""
        import subprocess, tempfile, shutil
        from pathlib import Path
        
        tmp = tempfile.mkdtemp()
        
        # بناء رابط مع token للمستودعات الخاصة
        if token and 'github.com' in url:
            parts = url.rstrip('/').split('/')
            clone_url = f'https://x-access-token:{token}@github.com/{parts[-2]}/{parts[-1].replace(".git","")}.git'
        else:
            clone_url = url
        
        subprocess.run(['git', 'clone', '--depth', '1', clone_url, tmp], capture_output=True, timeout=60)
        """توليد من GitHub"""
        tmp = tempfile.mkdtemp()
        subprocess.run(['git', 'clone', '--depth', '1', url, tmp], capture_output=True, timeout=60)
        
        docs_dir = f'{tmp}/docs'
        r = self.generate_readme(tmp, docs_dir)
        a = self.generate_api_docs(tmp, docs_dir)
        w = self.generate_wiki(tmp, docs_dir)
        
        repo_name = url.rstrip('/').split('/')[-1].replace('.git', '')
        final = Path(output_base or Path.home()) / repo_name / 'docs'
        final.mkdir(parents=True, exist_ok=True)
        
        if r: shutil.copy(r, final / 'README.md')
        if a: shutil.copy(a, final / 'API_DOCS.md')
        if w: shutil.copy(w, final / 'WIKI.md')
        
        shutil.rmtree(tmp, ignore_errors=True)
        return str(final)
