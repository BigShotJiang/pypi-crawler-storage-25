# tibet-tools

**MCP Tools for Claude Code** — Browse, install, and manage 20+ AI tools from the HumoticaOS ecosystem.

```bash
pip install tibet-tools
tibet-tools init
```

That's it. You now have 8 slash commands in Claude Code:

| Command | What it does |
|---------|-------------|
| `/install` | Browse & install MCP servers from the marketplace |
| `/agents` | See online AI agents, send messages via I-Poll |
| `/triage` | Review & approve/reject pending triage items |
| `/health` | Quick health check of the entire stack |
| `/bridge` | Talk to Gemini, GPT, or Ollama via MCP bridges |
| `/phantom` | Seal or resume AI sessions across devices |
| `/vaults` | Manage TIBET time-locked vaults |
| `/trust` | Check trust scores, verify TIBET tokens |

## Marketplace

**20 MCP servers** across 6 categories with **162 tools** total:

| Category | Servers | Tools |
|----------|---------|-------|
| Core TIBET | 3 | 26 |
| AI Bridges | 3 | 12 |
| Security | 4 | 16 |
| Communication | 4 | 41 |
| Data & Memory | 2 | 38 |
| Operations | 4 | 29 |

## CLI Usage

```bash
# Install slash commands into your project
tibet-tools init

# Browse available MCP servers
tibet-tools list

# Filter by category
tibet-tools list --category core_tibet

# Details about a specific server
tibet-tools info tibet-triage

# Search by keyword
tibet-tools search provenance

# List categories
tibet-tools categories
```

## How It Works

1. `tibet-tools init` copies slash command definitions (`.md` files) into your project's `.claude/commands/` directory
2. Claude Code automatically picks up these commands as `/slash-commands`
3. Each command instructs Claude how to use the MCP tools interactively
4. Every action creates a TIBET provenance token for audit

## What's TIBET?

**Traceable Intent-Based Event Tokens** — an open standard for AI provenance currently in IETF standardization.

Every AI action becomes a cryptographically signed token with four dimensions:
- **ERIN** — What's IN the action (content)
- **ERAAN** — What's attached (dependencies)
- **EROMHEEN** — Context around it (environment)
- **ERACHTER** — Intent behind it (why)

Five IETF Internet-Drafts:
- `draft-vandemeent-tibet-provenance`
- `draft-vandemeent-jis-identity`
- `draft-vandemeent-upip-process-integrity`
- `draft-vandemeent-rvp-continuous-verification`
- `draft-vandemeent-ains-discovery`

## Requirements

- Python 3.10+
- Claude Code CLI
- Optional: `pip install tibet-tools[interactive]` for InquirerPy prompts
- Optional: `pip install tibet-tools[full]` for TIBET token integration

## Part of HumoticaOS

90,000+ downloads · 111 countries · 5 IETF Internet-Drafts

[humotica.com](https://humotica.com)

## License

MIT
