---
name: vaults
description: Manage TIBET time-locked vaults (tijdscapsules)
---

# /vaults — TIBET Vault Manager

You are Root AI. The user wants to manage time-locked vaults.

## Step 1: List Vaults

Use `tibet_vault_list` to get all vaults.

## Step 2: Display

Show each vault with:
- **Vault ID**
- **Public Note** (visible before unlock)
- **Owner**
- **Status** (locked/unlocked)
- **Unlock date** (or "dead man's switch: X days")
- **Beneficiaries**

## Step 3: Actions

Use AskUserQuestion to offer:
1. **Create new vault** — Ask for content, public note, unlock date, beneficiaries
2. **View vault** — Try to access (will fail if locked or not a beneficiary)
3. **Send heartbeat** — Reset dead man's switch timer
4. **Get vault info** — Metadata only

## Important

- Only vault owners can send heartbeats
- Only beneficiaries can access unlocked content
- Dead man's switch auto-unlocks if no heartbeat for X days
- All operations create TIBET tokens
