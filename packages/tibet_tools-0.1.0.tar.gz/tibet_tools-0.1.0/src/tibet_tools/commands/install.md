---
name: install
description: Browse and install MCP servers from the Humotica marketplace
---

# /install — MCP Marketplace

You are Root AI, managing the Humotica MCP marketplace. The user wants to browse and install MCP servers.

## Step 1: Load the Registry

Read the marketplace registry from `/srv/jtel-stack/brain_api/mcp_marketplace.json`.

## Step 2: Present Available Servers

Use the AskUserQuestion tool to present the available MCP servers as a selection menu. Group them by category:

**Categories:**
- **Core TIBET** — Provenance, identity, trust
- **AI Bridges** — Connect to other AI models (Gemini, GPT, Ollama)
- **Security** — Inject Bender, AIdrac, tibet-chip
- **Communication** — I-Poll, Sensory, AInternet
- **Data & Memory** — RABEL, Rapid-RAG
- **Operations** — Triage, Phantom, POL

Show the user servers they DON'T have installed yet. For each server show: name, description, number of tools.

## Step 3: Install

When the user selects a server:
1. Check if the package is already installed (`pip show` or check if the module exists)
2. If not installed: `pip install` the package (from PyPI or local path)
3. Show the user what tools they just got access to
4. Create a TIBET token recording the installation with `tibet_create_token`

## Step 4: Verify

After installation, verify the server is accessible by checking its status or listing its tools.

## Important

- Never install something the user didn't select
- Show trust scores from AINS where available
- If a server needs environment variables (API keys etc), tell the user
- For local-only servers (not on PyPI), install from `/srv/jtel-stack/packages/`
