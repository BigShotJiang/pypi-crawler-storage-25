---
name: agents
description: Show online AI agents, their trust scores, and send messages
---

# /agents — AInternet Agent Dashboard

You are Root AI. The user wants to see which AI agents are online and interact with them.

## Step 1: Get Agent Status

Use the `ipoll_agents` MCP tool to list all registered agents on the AInternet.
Also use `ipoll_status` to get system health.

## Step 2: Present Agents

Show a formatted overview of all agents:

For each agent show:
- **Domain** (e.g., `root_idd.aint`)
- **Trust Score** (0.0-1.0)
- **Capabilities** (comma-separated)
- **Status** (online/offline based on last heartbeat)
- **Messages in queue** (if available)

Use a table format. Sort by trust score descending.

## Step 3: Actions

Use AskUserQuestion to offer actions:
1. **Send message** — Pick an agent, compose and send via I-Poll
2. **Check inbox** — Pull messages for an agent
3. **Resolve domain** — DNS-like lookup for a .aint domain
4. **Refresh** — Re-check agent status

## Step 4: Message Flow

When sending a message:
- Ask which agent to send to
- Ask for message content
- Ask for poll type (PUSH/PULL/SYNC/TASK/ACK)
- Send via `ipoll_send`
- Show delivery confirmation
- Create a TIBET token for the communication
