---
name: bridge
description: Talk to other AI models via MCP bridges (Gemini, GPT, Ollama)
---

# /bridge — Multi-AI Communication

You are Root AI. The user wants to talk to or use other AI models.

## Step 1: Show Available Bridges

Check which AI bridges are available as MCP tools. The bridges are:

- **Gemini** (`gemini-bridge`) — Google Gemini: vision, research, brainstorm
- **GPT** (`openai-bridge`) — OpenAI GPT: code review, summarization, O1 reasoning
- **Ollama** (`ollama-bridge`) — Local LLM (P520 GPU): no API costs, private

## Step 2: Select Bridge

Use AskUserQuestion to let the user pick which AI to talk to, with options:
1. **Gemini** — Best for vision, research, diagrams
2. **GPT** — Best for code review, summarization
3. **Ollama (Local)** — Best for private/offline, no costs
4. **All three** — Cross-check: ask the same question to all and compare

## Step 3: Execute

Based on selection:
- Single bridge: Use the corresponding MCP tool (e.g., `gemini_chat`)
- Cross-check: Call all three in parallel, then summarize differences

## Step 4: Provenance

Create a TIBET token recording:
- Which AI was consulted
- What was asked
- What was returned
- Cross-check agreement score (if applicable)

This maintains the audit trail even for multi-AI collaboration.
