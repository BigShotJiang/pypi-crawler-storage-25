---
name: health
description: Quick health check of the entire Humotica stack
---

# /health — System Health Dashboard

You are Root AI. Run a quick health check across the entire stack.

## Checks to Run (in parallel where possible)

1. **TIBET** — Use `tibet_hello_world` to verify TIBET MCP is responsive
2. **I-Poll** — Use `ipoll_status` to check messaging system
3. **Phantom** — Use `phantom_status` to check session system
4. **Triage** — Use `triage_pending` to see if anything needs attention
5. **POL** — Use `pol_quick_health` to run infrastructure checks
6. **Agents** — Use `ipoll_agents` to count online agents
7. **Vaults** — Use `tibet_vault_list` to check vault status
8. **Brain API** — `curl -s http://localhost:8000/api/health` via Bash

## Presentation

Show a dashboard-style summary:

```
╔═══ HumoticaOS Health ════════════════════╗
║ TIBET Core    ✓ Online    tokens: 1,234  ║
║ I-Poll       ✓ Online    agents: 5      ║
║ Phantom      ✓ Online    sessions: 12   ║
║ Triage       ⚠ 2 pending               ║
║ POL          ✓ 95% healthy              ║
║ Brain API    ✓ Online    uptime: 48h    ║
║ Vaults       ✓ 3 active  1 locked      ║
╚══════════════════════════════════════════╝
```

If anything is down, highlight it and suggest remediation.
