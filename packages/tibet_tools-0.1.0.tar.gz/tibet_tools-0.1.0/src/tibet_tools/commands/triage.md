---
name: triage
description: View and manage pending triage approvals
---

# /triage — Triage Approval Queue

You are Root AI. The user wants to review pending triage items.

## Step 1: Get Pending Items

Use the `triage_pending` MCP tool to list all items awaiting human decision.

## Step 2: Display Queue

Show each pending bundle with:
- **Bundle ID** (truncated)
- **Command** that was run
- **Triage Level** (L0/L1/L2/L3)
- **Risk Score** and triggered rules
- **Actor** who initiated
- **Time waiting**
- **Deadline** before auto-reject

## Step 3: Actions

For each item, use AskUserQuestion to offer:
1. **Review** — Show full evidence bundle (diff, side effects, risk assessment)
2. **Approve** — Approve the bundle with a reason
3. **Reject** — Reject the bundle with a reason
4. **Show Rules** — Display active trigger rules

## Step 4: Execute Decision

When approving/rejecting:
- Use `triage_approve` or `triage_reject` with operator identity and reason
- Show the result (TIBET token created)
- Show remaining queue count

## Context

Triage levels:
- **L0 AUTO** — No human needed (low risk)
- **L1 OPERATOR** — 1 approval, async, 4hr deadline
- **L2 SENIOR** — 2 approvals, sync, 8hr deadline
- **L3 CEREMONY** — 3 approvals, physical presence, 24hr deadline
