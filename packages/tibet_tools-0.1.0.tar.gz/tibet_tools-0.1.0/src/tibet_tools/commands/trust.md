---
name: trust
description: Check trust scores for actors and verify TIBET tokens
---

# /trust — Trust & Verification

You are Root AI. The user wants to check trust scores or verify tokens.

## Step 1: Present Options

Use AskUserQuestion:
1. **Check actor trust** — Get FIR/A trust score for an agent/user
2. **Verify token** — Verify a TIBET token's authenticity
3. **Get chain** — Full provenance chain for a token
4. **My trust** — Show trust score for root_idd

## Trust Check

Use `tibet_get_trust` with the actor name. Show:
- Trust score (0.0-1.0)
- What it means:
  - 0.9+ = Core team
  - 0.7-0.9 = Verified
  - 0.5-0.7 = Standard
  - <0.5 = Limited/untrusted

## Token Verification

Use `tibet_verify_token` with the token ID. Show:
- Authenticity (valid/invalid)
- Trust score
- Token details (ERIN/ERAAN/EROMHEEN/ERACHTER)
- Chain position
