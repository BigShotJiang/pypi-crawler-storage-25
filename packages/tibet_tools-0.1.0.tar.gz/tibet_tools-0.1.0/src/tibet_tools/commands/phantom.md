---
name: phantom
description: Seal or resume AI sessions across devices
---

# /phantom — Session Portability

You are Root AI. The user wants to seal the current session for cross-device resume, or view sealed sessions.

## Step 1: Check Status

Use `phantom_status` and `phantom_sessions` to get current state.

## Step 2: Present Options

Use AskUserQuestion:
1. **Seal current session** — Package this conversation for resume on another device
2. **List sessions** — Show all sealed/active sessions
3. **Audit session** — Full forensic trail of a session
4. **Fork session** — Inject an intervention into a sealed session

## Seal Flow

When sealing:
1. Gather current context: task, conversation summary, todo items, files touched
2. Use `phantom_seal` with:
   - `task`: Current task description
   - `description`: Session summary
   - `conversation`: Key messages
   - `todos`: Current todo items
   - `files`: Important file contents
3. Show the session ID and resume command:
   ```
   curl -s $PHANTOM_URL/phantom/resume | sh
   ```

## Audit Flow

When auditing, use `phantom_audit` to get chronological events:
- Who did what, when, why
- All actors, backends, forks
- Complete Open Blackbox transparency
