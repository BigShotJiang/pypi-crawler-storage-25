"""tibet-tools — MCP Tools for Claude Code.

Browse, install, and manage 20+ AI tools from the HumoticaOS ecosystem.
Every action tracked with TIBET provenance.

Usage:
    pip install tibet-tools
    tibet-tools init          # Install slash commands into your project
    tibet-tools list          # Browse available MCP servers
    tibet-tools info <name>   # Details about a specific server

Slash commands added to .claude/commands/:
    /install   — Interactive MCP server installer
    /agents    — AInternet agent dashboard
    /triage    — Approval queue manager
    /health    — System health check
    /bridge    — Multi-AI communication
    /phantom   — Session portability
    /vaults    — Time-locked vaults
    /trust     — Trust scores & token verification
"""

__version__ = "0.1.0"
