"""tibet-tools CLI — MCP Tools for Claude Code."""

import argparse
import json
import os
import shutil
import sys
from pathlib import Path


def _get_registry() -> dict:
    """Load the embedded marketplace registry."""
    reg_path = Path(__file__).parent / "data" / "registry.json"
    if not reg_path.exists():
        print(f"Error: Registry not found at {reg_path}", file=sys.stderr)
        sys.exit(1)
    with open(reg_path) as f:
        return json.load(f)


def _get_commands_dir() -> Path:
    """Get the directory containing embedded slash commands."""
    return Path(__file__).parent / "commands"


def _find_project_root() -> Path:
    """Find project root by looking for .git, .claude, or pyproject.toml."""
    cwd = Path.cwd()
    for parent in [cwd] + list(cwd.parents):
        if (parent / ".git").exists():
            return parent
        if (parent / ".claude").exists():
            return parent
        if (parent / "pyproject.toml").exists():
            return parent
    return cwd


def _category_display(cat_id: str, categories: dict) -> str:
    """Get display name for a category."""
    cat = categories.get(cat_id, {})
    return cat.get("name", cat_id)


def _trust_bar(score: float) -> str:
    """Render a trust score as a visual bar."""
    filled = int(score * 10)
    empty = 10 - filled
    return f"[{'█' * filled}{'░' * empty}] {score:.2f}"


def cmd_init(args):
    """Install slash commands into your project's .claude/commands/."""
    project_root = args.project or _find_project_root()
    project_root = Path(project_root)

    commands_dest = project_root / ".claude" / "commands"
    commands_dest.mkdir(parents=True, exist_ok=True)

    commands_src = _get_commands_dir()
    if not commands_src.exists():
        print("Error: No commands found in package", file=sys.stderr)
        sys.exit(1)

    installed = []
    skipped = []
    for cmd_file in sorted(commands_src.glob("*.md")):
        dest = commands_dest / cmd_file.name
        if dest.exists() and not args.force:
            skipped.append(cmd_file.stem)
            continue
        shutil.copy2(cmd_file, dest)
        installed.append(cmd_file.stem)

    # Also install the registry for /install to use
    data_dest = project_root / ".claude" / "marketplace"
    data_dest.mkdir(parents=True, exist_ok=True)
    reg_src = Path(__file__).parent / "data" / "registry.json"
    if reg_src.exists():
        shutil.copy2(reg_src, data_dest / "registry.json")

    print()
    print("╔═══════════════════════════════════════════════╗")
    print("║   tibet-tools — Slash Commands Installed        ║")
    print("╚═══════════════════════════════════════════════╝")
    print()

    if installed:
        print(f"  Installed {len(installed)} commands to {commands_dest}/")
        print()
        for name in installed:
            print(f"    /{name}")
        print()

    if skipped:
        print(f"  Skipped {len(skipped)} (already exist, use --force to overwrite):")
        for name in skipped:
            print(f"    /{name}")
        print()

    print("  Usage in Claude Code:")
    print("    /install   — Browse & install MCP servers")
    print("    /agents    — See online AI agents")
    print("    /health    — System health check")
    print("    /triage    — Approval queue")
    print()
    print(f"  Project: {project_root}")
    print()


def cmd_list(args):
    """List available MCP servers."""
    reg = _get_registry()
    categories = reg.get("categories", {})
    servers = reg.get("servers", [])

    if args.category:
        servers = [s for s in servers if s["category"] == args.category]

    if args.json:
        print(json.dumps(servers, indent=2))
        return

    total_tools = sum(s["tools"] for s in servers)

    print()
    print("╔═══════════════════════════════════════════════════════════════╗")
    print(f"║   Humotica MCP Marketplace — {len(servers)} servers, {total_tools} tools{' ' * (16 - len(str(total_tools)) - len(str(len(servers))))}║")
    print("╚═══════════════════════════════════════════════════════════════╝")
    print()

    # Group by category
    grouped = {}
    for s in servers:
        cat = s["category"]
        if cat not in grouped:
            grouped[cat] = []
        grouped[cat].append(s)

    for cat_id in categories:
        if cat_id not in grouped:
            continue
        cat_servers = grouped[cat_id]
        cat_name = _category_display(cat_id, categories)
        print(f"  ─── {cat_name} {'─' * (55 - len(cat_name))}")
        print()
        for s in cat_servers:
            trust = _trust_bar(s["trust_score"])
            gpu = " [GPU]" if s.get("requires_gpu") else ""
            aint = f" ({s['aint_domain']})" if s.get("aint_domain") else ""
            print(f"    {s['name']:25s} {s['tools']:2d} tools  {trust}{gpu}{aint}")
            print(f"    {'':25s} {s['description'][:55]}")
            print()

    print(f"  Install: tibet-tools init")
    print(f"  Details: tibet-tools info <server-id>")
    print()


def cmd_info(args):
    """Show detailed info about a server."""
    reg = _get_registry()
    categories = reg.get("categories", {})

    server = None
    for s in reg["servers"]:
        if s["id"] == args.server or s["name"].lower() == args.server.lower():
            server = s
            break

    if not server:
        print(f"Server '{args.server}' not found.", file=sys.stderr)
        print(f"Use 'tibet-tools list' to see available servers.", file=sys.stderr)
        sys.exit(1)

    if args.json:
        print(json.dumps(server, indent=2))
        return

    cat_name = _category_display(server["category"], categories)

    print()
    print(f"  ╔═══ {server['name']} ═{'═' * (40 - len(server['name']))}╗")
    print(f"  ║")
    print(f"  ║  {server['description']}")
    print(f"  ║")
    print(f"  ║  Category:    {cat_name}")
    print(f"  ║  Version:     {server['version']}")
    print(f"  ║  Trust:       {_trust_bar(server['trust_score'])}")
    print(f"  ║  Tools:       {server['tools']}")

    if server.get("aint_domain"):
        print(f"  ║  AInternet:   {server['aint_domain']}")

    if server.get("pypi_package"):
        print(f"  ║  PyPI:        pip install {server['pypi_package']}")

    if server.get("requires_gpu"):
        print(f"  ║  GPU:         Required")

    print(f"  ║")
    print(f"  ║  Tools available:")

    for tool in server.get("tool_names", []):
        print(f"  ║    • {tool}")

    if server.get("env_vars"):
        print(f"  ║")
        print(f"  ║  Required env vars:")
        for var in server["env_vars"]:
            print(f"  ║    ${var}")

    print(f"  ║")

    if server.get("local_path"):
        print(f"  ║  Source:      {server['local_path']}")

    print(f"  ╚{'═' * 48}╝")
    print()


def cmd_categories(args):
    """List marketplace categories."""
    reg = _get_registry()
    categories = reg.get("categories", {})
    servers = reg.get("servers", [])

    counts = {}
    tools = {}
    for s in servers:
        cat = s["category"]
        counts[cat] = counts.get(cat, 0) + 1
        tools[cat] = tools.get(cat, 0) + s["tools"]

    print()
    print("  MCP Marketplace Categories")
    print("  ──────────────────────────────────────")
    for cat_id, cat in categories.items():
        c = counts.get(cat_id, 0)
        t = tools.get(cat_id, 0)
        print(f"    {cat['name']:20s}  {c} servers  {t} tools")
        print(f"    {'':20s}  {cat['description']}")
        print()

    print(f"  Filter: tibet-tools list --category core_tibet")
    print()


def cmd_search(args):
    """Search for servers by keyword."""
    reg = _get_registry()
    query = args.query.lower()

    results = []
    for s in reg["servers"]:
        searchable = f"{s['name']} {s['description']} {' '.join(s.get('tool_names', []))}".lower()
        if query in searchable:
            results.append(s)

    if not results:
        print(f"  No servers matching '{args.query}'")
        return

    print(f"\n  Found {len(results)} server(s) matching '{args.query}':\n")
    for s in results:
        print(f"    {s['name']:25s} {s['tools']:2d} tools  trust:{s['trust_score']}")
        print(f"    {'':25s} {s['description'][:55]}")
        print()


def main():
    parser = argparse.ArgumentParser(
        prog="tibet-tools",
        description="MCP Tools for Claude Code — browse, install, and manage AI tools",
    )
    parser.add_argument("--version", action="version", version=f"%(prog)s 0.1.0")

    sub = parser.add_subparsers(dest="command", help="Available commands")

    # init
    p_init = sub.add_parser("init", help="Install slash commands into your project")
    p_init.add_argument("--project", "-p", help="Project root directory (auto-detected)")
    p_init.add_argument("--force", "-f", action="store_true", help="Overwrite existing commands")
    p_init.set_defaults(func=cmd_init)

    # list
    p_list = sub.add_parser("list", help="List available MCP servers")
    p_list.add_argument("--category", "-c", help="Filter by category")
    p_list.add_argument("--json", "-j", action="store_true", help="Output as JSON")
    p_list.set_defaults(func=cmd_list)

    # info
    p_info = sub.add_parser("info", help="Show details about a server")
    p_info.add_argument("server", help="Server ID or name")
    p_info.add_argument("--json", "-j", action="store_true", help="Output as JSON")
    p_info.set_defaults(func=cmd_info)

    # categories
    p_cats = sub.add_parser("categories", help="List marketplace categories")
    p_cats.set_defaults(func=cmd_categories)

    # search
    p_search = sub.add_parser("search", help="Search for servers by keyword")
    p_search.add_argument("query", help="Search query")
    p_search.set_defaults(func=cmd_search)

    args = parser.parse_args()

    if not args.command:
        # Default: show a quick overview
        print()
        print("  tibet-tools — MCP Tools for Claude Code")
        print("  ────────────────────────────────────────")
        print()
        print("  Commands:")
        print("    tibet-tools init          Install slash commands into your project")
        print("    tibet-tools list          Browse available MCP servers")
        print("    tibet-tools info <name>   Details about a specific server")
        print("    tibet-tools categories    List server categories")
        print("    tibet-tools search <q>    Search by keyword")
        print()
        print("  Quick start:")
        print("    cd your-project")
        print("    tibet-tools init")
        print("    # Now use /install, /agents, /health etc. in Claude Code")
        print()
        return

    args.func(args)


if __name__ == "__main__":
    main()
