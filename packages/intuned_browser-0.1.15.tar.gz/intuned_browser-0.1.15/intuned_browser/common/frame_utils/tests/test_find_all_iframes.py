"""Tests for FrameTree class."""

import asyncio
import time

import pytest
from playwright.async_api import async_playwright

from intuned_browser.common.frame_utils import FrameTree


class TestFrameTree:
    """Test the FrameTree class"""

    @pytest.mark.asyncio
    async def test_frame_tree_basic(self):
        """Test basic frame discovery"""
        async with async_playwright() as pw:
            browser = await pw.chromium.launch(headless=True)
            page = await browser.new_page()

            await page.set_content(
                """
                <html>
                    <body element_id="main-body">
                        <h1>Main Content</h1>
                        <iframe id="iframe-1"
                                element_id="iframe-1-id"
                                src="data:text/html,<html><body><h2>Iframe 1</h2></body></html>"
                                width="300"
                                height="200">
                        </iframe>
                        <iframe id="iframe-2"
                                element_id="iframe-2-id"
                                src="data:text/html,<html><body><h2>Iframe 2</h2></body></html>"
                                width="300"
                                height="200">
                        </iframe>
                    </body>
                </html>
            """,
                wait_until="domcontentloaded",
            )

            iframe_tree = await FrameTree.from_root(page)
            iframe_nodes = list(iframe_tree.tree)

            # Should find 2 top-level frames
            assert len(iframe_nodes) == 2
            assert iframe_nodes[0].frame is not None
            assert iframe_nodes[1].frame is not None

            # No nested frames
            assert len(list(iframe_nodes[0].nested_iframes)) == 0
            assert len(list(iframe_nodes[1].nested_iframes)) == 0

            await browser.close()

    @pytest.mark.asyncio
    async def test_frame_tree_nested(self):
        """Test nested frame discovery"""
        async with async_playwright() as pw:
            browser = await pw.chromium.launch(headless=True)
            page = await browser.new_page()

            await page.set_content(
                """
                <html>
                    <body element_id="main-body">
                        <h1>Main Content</h1>
                        <iframe id="outer-iframe"
                                element_id="outer-iframe-id"
                                src="data:text/html,<html><body><h2>Outer</h2><iframe element_id='inner-iframe-id' src='data:text/html,<html><body><h3>Inner</h3></body></html>'></iframe></body></html>"
                                width="400"
                                height="300">
                        </iframe>
                    </body>
                </html>
            """,
                wait_until="domcontentloaded",
            )

            iframe_tree = await FrameTree.from_root(page)
            iframe_nodes = list(iframe_tree.tree)

            # Should find 1 top-level frame
            assert len(iframe_nodes) == 1

            # Should have 1 nested frame
            assert len(list(iframe_nodes[0].nested_iframes)) == 1

            # Nested frame should have no further nesting
            assert len(list(list(iframe_nodes[0].nested_iframes)[0].nested_iframes)) == 0

            await browser.close()

    @pytest.mark.asyncio
    async def test_frame_tree_empty_page(self):
        """Test with page that has no frames"""
        async with async_playwright() as pw:
            browser = await pw.chromium.launch(headless=True)
            page = await browser.new_page()

            await page.set_content(
                """
                <html>
                    <body element_id="main-body">
                        <h1>Main Content</h1>
                        <p>No frames here</p>
                    </body>
                </html>
            """,
                wait_until="domcontentloaded",
            )

            iframe_tree = await FrameTree.from_root(page)
            iframe_nodes = list(iframe_tree.tree)

            # Should find no frames
            assert len(iframe_nodes) == 0

            await browser.close()

    @pytest.mark.asyncio
    async def test_frame_tree_with_problematic_srcs(self):
        async with async_playwright() as pw:
            browser = await pw.chromium.launch(headless=True)
            page = await browser.new_page()

            await page.set_content(
                """
                <html>
                    <body>
                        <h1>Main Content</h1>
                        <iframe id="javascript-iframe"
                                src="javascript:"
                                width="300"
                                height="200">
                        </iframe>
                        <iframe id="blob-iframe"
                                src="blob:null/invalid"
                                width="300"
                                height="200">
                        </iframe>
                        <iframe id="about-blank-iframe"
                                src="about:blank"
                                width="300"
                                height="200">
                        </iframe>
                    </body>
                </html>
            """,
                wait_until="domcontentloaded",
                timeout=5000,
            )

            async def test():
                start_time = time.time()
                iframe_tree = await FrameTree.from_root(page, iframe_timeout=2.0)
                iframe_nodes = list(iframe_tree.tree)
                elapsed_time = time.time() - start_time
                return iframe_nodes, elapsed_time

            iframe_nodes, elapsed_time = await asyncio.wait_for(test(), timeout=10.0)

            # Should complete quickly (3 frames × 2s timeout = max ~6s + overhead)
            assert elapsed_time < 10.0, f"Function took too long: {elapsed_time} seconds"

            # Problematic frames (javascript:, blob:null/invalid) should timeout and be skipped
            # Only about:blank should be returned since it's the only usable one
            assert len(iframe_nodes) <= 3

            # Verify the returned frame is actually usable
            count = await asyncio.wait_for(
                iframe_nodes[0].frame.locator("*").count(),
                timeout=2.0,
            )
            assert count >= 0  # Just verify it doesn't hang

            await browser.close()

    @pytest.mark.asyncio
    async def test_frame_tree_srcdoc(self):
        """Test iframes with srcdoc attribute"""
        async with async_playwright() as pw:
            browser = await pw.chromium.launch(headless=True)
            page = await browser.new_page()

            await page.set_content(
                """
                <html>
                    <body element_id="main-body">
                        <h1>Main Content</h1>
                        <iframe id="srcdoc-iframe"
                                element_id="srcdoc-iframe-id"
                                srcdoc="<html><body><h2>Srcdoc Content</h2></body></html>"
                                width="300"
                                height="200">
                        </iframe>
                    </body>
                </html>
            """,
                wait_until="domcontentloaded",
            )

            iframe_tree = await FrameTree.from_root(page)
            iframe_nodes = list(iframe_tree.tree)

            # Should find the srcdoc frame
            assert len(iframe_nodes) == 1

            await browser.close()

    @pytest.mark.asyncio
    async def test_frame_tree_legacy_frames(self):
        """Test legacy <frame> elements within <frameset>"""
        async with async_playwright() as pw:
            browser = await pw.chromium.launch(headless=True)
            page = await browser.new_page()

            # Legacy frameset with frame elements
            await page.set_content(
                """
                <html>
                    <head><title>Legacy Frameset</title></head>
                    <frameset cols="50%,50%">
                        <frame id="frame-1"
                               element_id="frame-1-id"
                               src="data:text/html,<html><body><h2>Frame 1</h2></body></html>">
                        </frame>
                        <frame id="frame-2"
                               element_id="frame-2-id"
                               src="data:text/html,<html><body><h2>Frame 2</h2></body></html>">
                        </frame>
                    </frameset>
                </html>
            """,
                wait_until="domcontentloaded",
            )

            iframe_tree = await FrameTree.from_root(page)
            iframe_nodes = list(iframe_tree.tree)

            # Should find 2 legacy frame elements
            # Note: Some browsers may not support frameset, so we check for at least 0
            # Modern browsers may convert frameset to iframes or not support it at all
            assert len(iframe_nodes) >= 0
            # If frames are found, they should have valid frame objects
            for node in iframe_nodes:
                assert node.frame is not None

            await browser.close()

    @pytest.mark.asyncio
    async def test_frame_tree_sandbox_allows_async_scripts(self):
        """Test that allows_async_scripts flag correctly identifies sandboxed iframes"""
        async with async_playwright() as pw:
            browser = await pw.chromium.launch(headless=True)
            page = await browser.new_page()

            await page.set_content(
                """
                <html>
                    <body element_id="main-body">
                        <h1>Main Content</h1>
                        <iframe id="sandboxed-iframe"
                                element_id="sandboxed-iframe-id"
                                sandbox="allow-same-origin"
                                srcdoc="<html><body><h2>Sandboxed Iframe</h2></body></html>"
                                width="300"
                                height="200">
                        </iframe>
                        <iframe id="normal-iframe"
                                element_id="normal-iframe-id"
                                srcdoc="<html><body><h2>Normal Iframe</h2></body></html>"
                                width="300"
                                height="200">
                        </iframe>
                    </body>
                </html>
            """,
                wait_until="domcontentloaded",
            )

            iframe_tree = await FrameTree.from_root(page)
            iframe_nodes = list(iframe_tree.tree)

            # Should find 2 top-level frames
            assert len(iframe_nodes) == 2

            # Find the sandboxed frame and normal frame by checking their element IDs
            sandboxed_node = None
            normal_node = None

            for node in iframe_nodes:
                try:
                    iframe_element = await node.frame.frame_element()
                    iframe_id = await iframe_element.get_attribute("id")
                    if iframe_id == "sandboxed-iframe":
                        sandboxed_node = node
                    elif iframe_id == "normal-iframe":
                        normal_node = node
                except Exception:
                    continue

            # The sandboxed frame should not allow async scripts
            assert sandboxed_node is not None, "Should find sandboxed frame"
            assert (
                sandboxed_node.allows_async_scripts is False
            ), "Sandboxed frame without allow-scripts should have allows_async_scripts=False"

            # The normal frame should allow async scripts
            assert normal_node is not None, "Should find normal iframe"
            assert normal_node.allows_async_scripts is True, "Normal frame should have allows_async_scripts=True"

            await browser.close()

    @pytest.mark.asyncio
    async def test_frame_tree_locator_only_finds_frames_within_scope(self):
        """Test that passing a Locator only finds frames within that element, not siblings"""
        async with async_playwright() as pw:
            browser = await pw.chromium.launch(headless=True)
            page = await browser.new_page()

            await page.set_content(
                """
                <html>
                    <body>
                        <div id="container">
                            <iframe id="inside-iframe"
                                    src="data:text/html,<html><body><h2>Inside</h2></body></html>"
                                    width="300"
                                    height="200">
                            </iframe>
                        </div>
                        <iframe id="outside-iframe"
                                src="data:text/html,<html><body><h2>Outside</h2></body></html>"
                                width="300"
                                height="200">
                        </iframe>
                    </body>
                </html>
            """,
                wait_until="domcontentloaded",
            )

            # Search within the container only
            container_locator = page.locator("#container")
            iframe_tree = await FrameTree.from_root(container_locator)
            iframe_nodes = list(iframe_tree.tree)

            # Should only find the frame inside the container
            assert len(iframe_nodes) == 1
            iframe_element = await iframe_nodes[0].frame.frame_element()
            iframe_id = await iframe_element.get_attribute("id")
            assert iframe_id == "inside-iframe"

            # Verify that searching the whole page finds both
            all_iframe_tree = await FrameTree.from_root(page)
            all_iframe_nodes = list(all_iframe_tree.tree)
            assert len(all_iframe_nodes) == 2

            await browser.close()

    @pytest.mark.asyncio
    async def test_skip_detached_frames_mid_loop(self):
        """Test that detached frames are skipped during iteration"""
        async with async_playwright() as pw:
            browser = await pw.chromium.launch(headless=True)
            page = await browser.new_page()

            await page.set_content(
                """
                <html>
                    <body>
                        <h1>Main Content</h1>
                        <iframe id="iframe-1"
                                src="data:text/html,<html><body><h2>Iframe 1</h2></body></html>"
                                width="300"
                                height="200">
                        </iframe>
                        <iframe id="iframe-3"
                                src="data:text/html,<html><body><h2>Iframe 3</h2></body></html>"
                                width="300"
                                height="200">
                        </iframe>
                        <iframe id="iframe-to-remove"
                                src="data:text/html,<html><body><h2>Iframe to Remove</h2></body></html>"
                                width="300"
                                height="200">
                        </iframe>
                    </body>
                </html>
            """,
                wait_until="domcontentloaded",
            )

            iframe_tree = await FrameTree.from_root(page)

            # Schedule removal of the middle iframe after 1 second
            async def remove_iframe_after_delay():
                await asyncio.sleep(1)
                await page.evaluate('document.getElementById("iframe-to-remove").remove()')

            removal_task = asyncio.create_task(remove_iframe_after_delay())

            # Iterate through the tree with delays, simulating slow processing
            # The tree property should skip detached frames dynamically
            collected_ids = []
            for node in iframe_tree.tree:
                iframe_element = await node.frame.frame_element()
                iframe_id = await iframe_element.get_attribute("id")
                collected_ids.append(iframe_id)
                await asyncio.sleep(1)

            await removal_task

            # The detached iframe should have been skipped
            assert "iframe-to-remove" not in collected_ids
            # But other iframes should still be collected
            assert "iframe-1" in collected_ids
            assert "iframe-3" in collected_ids

            await browser.close()


class TestFrameTreeSkipsUselessIframes:
    @pytest.mark.asyncio
    async def test_skips_pixel_iframe_with_zero_dimensions(self):
        """Test that iframes with 0x0 dimensions are skipped"""
        async with async_playwright() as pw:
            browser = await pw.chromium.launch(headless=True)
            page = await browser.new_page()

            await page.set_content(
                """
                <html>
                    <body>
                        <h1>Main Content</h1>
                        <iframe id="normal-iframe"
                                src="data:text/html,<html><body><h2>Normal</h2></body></html>"
                                width="300"
                                height="200">
                        </iframe>
                        <iframe id="pixel-iframe"
                                src="data:text/html,<html><body></body></html>"
                                width="0"
                                height="0">
                        </iframe>
                    </body>
                </html>
            """,
                wait_until="domcontentloaded",
            )

            iframe_tree = await FrameTree.from_root(page)
            iframe_nodes = list(iframe_tree.tree)

            # Should only find the normal iframe, pixel iframe should be skipped
            assert len(iframe_nodes) == 1
            iframe_element = await iframe_nodes[0].frame.frame_element()
            iframe_id = await iframe_element.get_attribute("id")
            assert iframe_id == "normal-iframe"

            await browser.close()

    @pytest.mark.asyncio
    async def test_skips_pixel_iframe_with_one_dimensions(self):
        """Test that iframes with 1x1 dimensions are skipped"""
        async with async_playwright() as pw:
            browser = await pw.chromium.launch(headless=True)
            page = await browser.new_page()

            await page.set_content(
                """
                <html>
                    <body>
                        <h1>Main Content</h1>
                        <iframe id="normal-iframe"
                                src="data:text/html,<html><body><h2>Normal</h2></body></html>"
                                width="300"
                                height="200">
                        </iframe>
                        <iframe id="pixel-iframe-1x1"
                                src="data:text/html,<html><body></body></html>"
                                width="1"
                                height="1">
                        </iframe>
                    </body>
                </html>
            """,
                wait_until="domcontentloaded",
            )

            iframe_tree = await FrameTree.from_root(page)
            iframe_nodes = list(iframe_tree.tree)

            assert len(iframe_nodes) == 1
            iframe_element = await iframe_nodes[0].frame.frame_element()
            iframe_id = await iframe_element.get_attribute("id")
            assert iframe_id == "normal-iframe"

            await browser.close()

    @pytest.mark.asyncio
    async def test_skips_pixel_iframe_with_style_dimensions(self):
        """Test that iframes with 0/1 dimensions in style attribute are skipped"""
        async with async_playwright() as pw:
            browser = await pw.chromium.launch(headless=True)
            page = await browser.new_page()

            await page.set_content(
                """
                <html>
                    <body>
                        <h1>Main Content</h1>
                        <iframe id="normal-iframe"
                                src="data:text/html,<html><body><h2>Normal</h2></body></html>"
                                width="300"
                                height="200">
                        </iframe>
                        <iframe id="pixel-iframe-style"
                                src="data:text/html,<html><body></body></html>"
                                style="width: 0; height: 0; display: none;">
                        </iframe>
                    </body>
                </html>
            """,
                wait_until="domcontentloaded",
            )

            iframe_tree = await FrameTree.from_root(page)
            iframe_nodes = list(iframe_tree.tree)

            assert len(iframe_nodes) == 1
            iframe_element = await iframe_nodes[0].frame.frame_element()
            iframe_id = await iframe_element.get_attribute("id")
            assert iframe_id == "normal-iframe"

            await browser.close()

    @pytest.mark.asyncio
    async def test_skips_recaptcha_iframe(self):
        """Test that reCAPTCHA iframes are skipped"""
        async with async_playwright() as pw:
            browser = await pw.chromium.launch(headless=True)
            page = await browser.new_page()

            await page.set_content(
                """
                <html>
                    <body>
                        <h1>Main Content</h1>
                        <iframe id="normal-iframe"
                                src="data:text/html,<html><body><h2>Normal</h2></body></html>"
                                width="300"
                                height="200">
                        </iframe>
                        <iframe id="recaptcha-iframe"
                                src="https://www.google.com/recaptcha/api2/anchor"
                                width="300"
                                height="78">
                        </iframe>
                    </body>
                </html>
            """,
                wait_until="domcontentloaded",
            )

            iframe_tree = await FrameTree.from_root(page)
            iframe_nodes = list(iframe_tree.tree)

            assert len(iframe_nodes) == 1
            iframe_element = await iframe_nodes[0].frame.frame_element()
            iframe_id = await iframe_element.get_attribute("id")
            assert iframe_id == "normal-iframe"

            await browser.close()

    @pytest.mark.asyncio
    async def test_skips_cloudflare_turnstile_iframe(self):
        """Test that Cloudflare Turnstile iframes are skipped"""
        async with async_playwright() as pw:
            browser = await pw.chromium.launch(headless=True)
            page = await browser.new_page()

            await page.set_content(
                """
                <html>
                    <body>
                        <h1>Main Content</h1>
                        <iframe id="normal-iframe"
                                src="data:text/html,<html><body><h2>Normal</h2></body></html>"
                                width="300"
                                height="200">
                        </iframe>
                        <iframe id="turnstile-iframe"
                                src="https://challenges.cloudflare.com/turnstile/v0/g/abc123"
                                width="300"
                                height="65">
                        </iframe>
                    </body>
                </html>
            """,
                wait_until="domcontentloaded",
            )

            iframe_tree = await FrameTree.from_root(page)
            iframe_nodes = list(iframe_tree.tree)

            assert len(iframe_nodes) == 1
            iframe_element = await iframe_nodes[0].frame.frame_element()
            iframe_id = await iframe_element.get_attribute("id")
            assert iframe_id == "normal-iframe"

            await browser.close()

    @pytest.mark.asyncio
    async def test_skips_facebook_pixel_iframe(self):
        """Test that Facebook pixel tracking iframes are skipped"""
        async with async_playwright() as pw:
            browser = await pw.chromium.launch(headless=True)
            page = await browser.new_page()

            await page.set_content(
                """
                <html>
                    <body>
                        <h1>Main Content</h1>
                        <iframe id="normal-iframe"
                                src="data:text/html,<html><body><h2>Normal</h2></body></html>"
                                width="300"
                                height="200">
                        </iframe>
                        <iframe id="fb-pixel-iframe"
                                src="https://www.facebook.com/tr?id=123456789"
                                width="300"
                                height="200">
                        </iframe>
                    </body>
                </html>
            """,
                wait_until="domcontentloaded",
            )

            iframe_tree = await FrameTree.from_root(page)
            iframe_nodes = list(iframe_tree.tree)

            assert len(iframe_nodes) == 1
            iframe_element = await iframe_nodes[0].frame.frame_element()
            iframe_id = await iframe_element.get_attribute("id")
            assert iframe_id == "normal-iframe"

            await browser.close()

    @pytest.mark.asyncio
    async def test_skips_doubleclick_iframe(self):
        """Test that DoubleClick tracking iframes are skipped"""
        async with async_playwright() as pw:
            browser = await pw.chromium.launch(headless=True)
            page = await browser.new_page()

            await page.set_content(
                """
                <html>
                    <body>
                        <h1>Main Content</h1>
                        <iframe id="normal-iframe"
                                src="data:text/html,<html><body><h2>Normal</h2></body></html>"
                                width="300"
                                height="200">
                        </iframe>
                        <iframe id="doubleclick-iframe"
                                src="https://ad.doubleclick.net/ddm/trackimp/abc123"
                                width="300"
                                height="200">
                        </iframe>
                    </body>
                </html>
            """,
                wait_until="domcontentloaded",
            )

            iframe_tree = await FrameTree.from_root(page)
            iframe_nodes = list(iframe_tree.tree)

            assert len(iframe_nodes) == 1
            iframe_element = await iframe_nodes[0].frame.frame_element()
            iframe_id = await iframe_element.get_attribute("id")
            assert iframe_id == "normal-iframe"

            await browser.close()

    @pytest.mark.asyncio
    async def test_skips_multiple_useless_iframes(self):
        """Test that multiple pixel and captcha iframes are all skipped"""
        async with async_playwright() as pw:
            browser = await pw.chromium.launch(headless=True)
            page = await browser.new_page()

            await page.set_content(
                """
                <html>
                    <body>
                        <h1>Main Content</h1>
                        <iframe id="normal-iframe-1"
                                src="data:text/html,<html><body><h2>Normal 1</h2></body></html>"
                                width="300"
                                height="200">
                        </iframe>
                        <iframe id="pixel-0x0"
                                src="data:text/html,<html><body></body></html>"
                                width="0"
                                height="0">
                        </iframe>
                        <iframe id="normal-iframe-2"
                                src="data:text/html,<html><body><h2>Normal 2</h2></body></html>"
                                width="400"
                                height="300">
                        </iframe>
                        <iframe id="recaptcha"
                                src="https://www.google.com/recaptcha/api2/anchor"
                                width="300"
                                height="78">
                        </iframe>
                        <iframe id="fb-pixel"
                                src="https://www.facebook.com/tr?id=123"
                                width="1"
                                height="1">
                        </iframe>
                    </body>
                </html>
            """,
                wait_until="domcontentloaded",
            )

            iframe_tree = await FrameTree.from_root(page)
            iframe_nodes = list(iframe_tree.tree)

            # Should only find the 2 normal iframes
            assert len(iframe_nodes) == 2
            iframe_ids = []
            for node in iframe_nodes:
                el = await node.frame.frame_element()
                iframe_ids.append(await el.get_attribute("id"))
            assert "normal-iframe-1" in iframe_ids
            assert "normal-iframe-2" in iframe_ids

            await browser.close()

    @pytest.mark.asyncio
    async def test_skips_nested_pixel_iframes(self):
        """Test that nested pixel iframes are also skipped"""
        async with async_playwright() as pw:
            browser = await pw.chromium.launch(headless=True)
            page = await browser.new_page()

            # Outer iframe contains a normal nested iframe and a pixel nested iframe
            nested_content = (
                "<html><body><h2>Outer Content</h2>"
                "<iframe id='nested-normal' src='data:text/html,<html><body><h3>Nested Normal</h3></body></html>' width='200' height='100'></iframe>"
                "<iframe id='nested-pixel' src='data:text/html,<html><body></body></html>' width='0' height='0'></iframe>"
                "</body></html>"
            ).replace("'", "%27")

            await page.set_content(
                f"""
                <html>
                    <body>
                        <h1>Main Content</h1>
                        <iframe id="outer-iframe"
                                src="data:text/html,{nested_content}"
                                width="400"
                                height="300">
                        </iframe>
                    </body>
                </html>
            """,
                wait_until="domcontentloaded",
            )

            iframe_tree = await FrameTree.from_root(page)
            iframe_nodes = list(iframe_tree.tree)

            # Should find the outer iframe
            assert len(iframe_nodes) == 1
            outer_el = await iframe_nodes[0].frame.frame_element()
            outer_id = await outer_el.get_attribute("id")
            assert outer_id == "outer-iframe"

            # Outer iframe should have only 1 nested iframe (the normal one, not the pixel one)
            assert len(list(iframe_nodes[0].nested_iframes)) == 1
            nested_el = await list(iframe_nodes[0].nested_iframes)[0].frame.frame_element()
            nested_id = await nested_el.get_attribute("id")
            assert nested_id == "nested-normal"

            await browser.close()

    @pytest.mark.asyncio
    async def test_keeps_iframes_without_dimensions(self):
        """Test that iframes without explicit dimensions are kept (not skipped)"""
        async with async_playwright() as pw:
            browser = await pw.chromium.launch(headless=True)
            page = await browser.new_page()

            await page.set_content(
                """
                <html>
                    <body>
                        <h1>Main Content</h1>
                        <iframe id="no-dimensions-iframe"
                                src="data:text/html,<html><body><h2>No Dimensions</h2></body></html>">
                        </iframe>
                        <iframe id="normal-iframe"
                                src="data:text/html,<html><body><h2>Normal</h2></body></html>"
                                width="300"
                                height="200">
                        </iframe>
                    </body>
                </html>
            """,
                wait_until="domcontentloaded",
            )

            iframe_tree = await FrameTree.from_root(page)
            iframe_nodes = list(iframe_tree.tree)

            # Both iframes should be kept
            assert len(iframe_nodes) == 2

            await browser.close()

    @pytest.mark.asyncio
    async def test_captcha_detection_is_case_insensitive(self):
        """Test that captcha URL detection is case-insensitive"""
        async with async_playwright() as pw:
            browser = await pw.chromium.launch(headless=True)
            page = await browser.new_page()

            await page.set_content(
                """
                <html>
                    <body>
                        <h1>Main Content</h1>
                        <iframe id="normal-iframe"
                                src="data:text/html,<html><body><h2>Normal</h2></body></html>"
                                width="300"
                                height="200">
                        </iframe>
                        <iframe id="recaptcha-uppercase"
                                src="https://www.GOOGLE.COM/RECAPTCHA/api2/anchor"
                                width="300"
                                height="78">
                        </iframe>
                    </body>
                </html>
            """,
                wait_until="domcontentloaded",
            )

            iframe_tree = await FrameTree.from_root(page)
            iframe_nodes = list(iframe_tree.tree)

            assert len(iframe_nodes) == 1
            iframe_element = await iframe_nodes[0].frame.frame_element()
            iframe_id = await iframe_element.get_attribute("id")
            assert iframe_id == "normal-iframe"

            await browser.close()
