import time
from pathlib import Path

import bs4
import pytest
from playwright.async_api import async_playwright
from playwright.async_api import Frame
from playwright.async_api import Locator
from playwright.async_api import Page

from intuned_browser.common.frame_utils import get_content_with_nested_iframes


async def get_test_page_with_iframes(wait_for_dynamic_content: bool = False):
    playwright = await async_playwright().start()
    browser = await playwright.chromium.launch(headless=True)
    context = await browser.new_context()
    page = await context.new_page()

    test_html_path = Path(__file__).parent / "fixtures" / "test_with_iframes.html"
    test_html_path = test_html_path.resolve()
    await page.goto(f"file://{test_html_path}")

    if wait_for_dynamic_content:
        await page.wait_for_timeout(1500)  # Wait for dynamic iframe\

    return page


class TestGetContentWithNestedIframes:
    """Test the iframe utilities"""

    @pytest.mark.asyncio
    async def test_get_content_with_nested_iframes_basic(self):
        """Test basic iframe content inclusion"""
        page = await get_test_page_with_iframes()

        content = await get_content_with_nested_iframes(page)

        # Verify iframe content is included
        assert "Static Iframe Content" in content
        assert "Srcdoc Iframe" in content
        assert "Outer Iframe" in content

        # Verify iframe elements are preserved (like browser dev tools)
        iframe_count = content.count("<iframe")
        assert iframe_count >= 4, f"Expected at least 4 iframe tags, found {iframe_count}"

        # Verify that content is actually nested inside iframe tags
        assert 'id="static-iframe"' in content
        assert "<h2>Static Iframe Content</h2>" in content
        assert "iframe-element" in content
        assert "srcdoc-span" in content

    @pytest.mark.asyncio
    async def test_get_content_with_nested_iframes_nested(self):
        """Test nested iframe content inclusion"""
        page = await get_test_page_with_iframes()

        content = await get_content_with_nested_iframes(page)

        # Verify nested iframe content is included
        assert "Outer Iframe" in content
        assert "Inner Iframe" in content
        assert "Deep Element" in content

        # Verify iframe elements are preserved (like browser dev tools)
        iframe_count = content.count("<iframe")
        assert iframe_count >= 4, f"Expected at least 4 iframe tags, found {iframe_count}"

        # Verify nested iframe content is nested inside iframe elements
        assert "deep-element" in content

    @pytest.mark.asyncio
    async def test_get_content_with_nested_iframes_dynamic(self):
        """Test dynamically created iframe content inclusion"""
        page = await get_test_page_with_iframes(wait_for_dynamic_content=True)

        content = await get_content_with_nested_iframes(page)

        # Verify dynamic iframe content is included
        assert "Dynamic Iframe" in content
        assert "dynamic-element" in content

    @pytest.mark.asyncio
    async def test_get_content_with_nested_iframes_empty_iframe(self):
        """Test empty iframe handling"""
        page = await get_test_page_with_iframes()

        content = await get_content_with_nested_iframes(page)

        # Empty iframe should be handled gracefully (no content to include)
        # The iframe element should remain since it has no content to replace
        assert "empty-iframe-id" in content
        assert content.count("empty-iframe-id") == 1

    @pytest.mark.asyncio
    async def test_get_content_with_nested_iframes_main_content_preserved(self):
        """Test that main page content is preserved"""
        page = await get_test_page_with_iframes()

        content = await get_content_with_nested_iframes(page)

        # Verify main page content is preserved
        assert "Main Page Content" in content
        assert "This is the main page content" in content
        assert "content-after-iframes" in content
        assert "Item 1" in content
        assert "Item 2" in content

    @pytest.mark.asyncio
    async def test_get_content_with_nested_iframes_cross_origin_iframe(self):
        """Test that cross-origin iframes are handled gracefully"""
        playwright = await async_playwright().start()
        browser = await playwright.chromium.launch(headless=True)
        context = await browser.new_context()
        page = await context.new_page()

        # Create a page with a cross-origin iframe (will fail to access)
        # Using example.com as a cross-origin source
        await page.set_content("""
            <html>
                <body element_id="main-body">
                    <h1>Main Content</h1>
                    <iframe id="cross-origin-iframe"
                            element_id="cross-origin-id"
                            src="https://example.com"
                            width="300"
                            height="200">
                    </iframe>
                    <p>Content after iframe</p>
                </body>
            </html>
        """)

        # Wait a bit for iframe to attempt loading
        await page.wait_for_timeout(500)

        content = await get_content_with_nested_iframes(page)

        # Verify main content is preserved even if cross-origin iframe fails
        assert "Main Content" in content
        assert "Content after iframe" in content
        assert "cross-origin-id" in content

        await browser.close()
        await playwright.stop()

    @pytest.mark.asyncio
    async def test_get_content_with_nested_iframes_malformed_iframe_html(self):
        """Test handling of malformed HTML in iframe content"""
        playwright = await async_playwright().start()
        browser = await playwright.chromium.launch(headless=True)
        context = await browser.new_context()
        page = await context.new_page()

        # Create a page with malformed HTML in iframe
        await page.set_content("""
            <html>
                <body element_id="main-body">
                    <h1>Malformed HTML Test</h1>
                    <iframe id="malformed-iframe"
                            element_id="malformed-id"
                            srcdoc="<html><body><h2>Malformed</h2><p>Unclosed tag<div>Missing closing</p></body></html>"
                            width="300"
                            height="200">
                    </iframe>
                </body>
            </html>
        """)

        # Should not crash even with malformed HTML
        content = await get_content_with_nested_iframes(page)

        # Verify main content is preserved
        assert "Malformed HTML Test" in content
        assert "malformed-id" in content
        # The malformed content should still be processed (BeautifulSoup is forgiving)
        assert "Malformed" in content

        await browser.close()
        await playwright.stop()

    @pytest.mark.asyncio
    async def test_get_content_with_nested_iframes_problematic_iframe_srcs(self):
        """Test handling of iframes that cause hanging (javascript:, blob:null/invalid)"""
        playwright = await async_playwright().start()
        browser = await playwright.chromium.launch(headless=True)
        context = await browser.new_context()
        page = await context.new_page()

        # Create a page with iframe sources that cause hanging
        # Use 'domcontentloaded' instead of 'commit' to avoid waiting for iframe loads
        await page.set_content(
            """
            <html>
                <body element_id="main-body">
                    <h1>Main Content</h1>
                    <iframe id="empty-javascript-iframe"
                            element_id="empty-javascript-id"
                            src="javascript:"
                            width="300"
                            height="200">
                    </iframe>
                    <iframe id="invalid-blob-iframe"
                            element_id="invalid-blob-id"
                            src="blob:null/invalid"
                            width="300"
                            height="200">
                    </iframe>
                    <p>Content after iframes</p>
                </body>
            </html>
        """,
            wait_until="domcontentloaded",
            timeout=5000,
        )

        start_time = time.time()
        content = await get_content_with_nested_iframes(page, iframe_timeout=2.0)
        elapsed_time = time.time() - start_time

        # Should complete without indefinite hanging
        # 2 iframes with problematic sources, each triggers 2 timeouts:
        # - Timeout counting nested iframes (2s each)
        # - Timeout getting content (2s each)
        # Total: 2 iframes × (2s + 2s) = 8s, plus overhead should be under 10s
        assert elapsed_time < 10.0, f"Function took too long (likely hung): {elapsed_time} seconds"

        # Verify main content is preserved even if iframes timeout
        assert "Main Content" in content
        assert "Content after iframes" in content

        # Verify iframe element_ids are present (the iframe elements themselves remain)
        assert "empty-javascript-id" in content
        assert "invalid-blob-id" in content

        await browser.close()
        await playwright.stop()

    @pytest.mark.asyncio
    async def test_get_content_with_nested_iframes_legacy_frames(self):
        """Test legacy <frame> elements within <frameset>"""
        playwright = await async_playwright().start()
        browser = await playwright.chromium.launch(headless=True)
        context = await browser.new_context()
        page = await context.new_page()

        # Legacy frameset with frame elements
        await page.set_content(
            """
            <html>
                <head><title>Legacy Frameset</title></head>
                <frameset cols="50%,50%">
                    <frame id="frame-1"
                           element_id="frame-1-id"
                           src="data:text/html,<html><body><h2>Frame 1</h2><p>Frame 1 Content</p></body></html>">
                    </frame>
                    <frame id="frame-2"
                           element_id="frame-2-id"
                           src="data:text/html,<html><body><h2>Frame 2</h2><p>Frame 2 Content</p></body></html>">
                    </frame>
                </frameset>
            </html>
        """,
            wait_until="domcontentloaded",
        )

        content = await get_content_with_nested_iframes(page)

        assert "frame-1-id" in content or "frame-2-id" in content or len(content) > 0

        await browser.close()
        await playwright.stop()

    @pytest.mark.asyncio
    async def test_get_content_with_nested_iframes_custom_extractor_skip_tags(self):
        playwright = await async_playwright().start()
        browser = await playwright.chromium.launch(headless=True)
        context = await browser.new_context()
        page = await context.new_page()

        # Create a page with iframes containing <p> tags
        await page.set_content(
            """
            <html>
                <body element_id="main-body">
                    <h1>Main Content</h1>
                    <p>This is main page paragraph that should remain.</p>
                    <iframe id="test-iframe"
                            element_id="test-iframe-id"
                            srcdoc="<html><body><h2>Iframe Title</h2><p>This paragraph should be removed.</p><div>This div should remain.</div><p>Another paragraph to remove.</p></body></html>"
                            width="300"
                            height="200">
                    </iframe>
                    <p>Another main page paragraph that should remain.</p>
                </body>
            </html>
        """,
            wait_until="domcontentloaded",
        )

        # Custom extractor that removes <p> tags from HTML
        async def custom_extractor(root: Page | Frame | Locator) -> str:
            if isinstance(root, Page | Frame):
                html_content = await root.content()
            else:
                html_content = await root.evaluate("el => el.outerHTML")

            # Parse and remove <p> tags
            soup = bs4.BeautifulSoup(html_content, "html.parser")
            for p_tag in soup.find_all("p"):
                p_tag.decompose()  # Remove the tag completely

            return str(soup)

        content = await get_content_with_nested_iframes(page, html_content_extractor=custom_extractor)

        # Verify main content structure is preserved
        assert "Main Content" in content
        assert "test-iframe-id" in content

        # Verify iframe content is included (h2 and div should remain)
        assert "Iframe Title" in content
        assert "This div should remain" in content

        # Verify that <p> tags are removed from iframe content
        # Find the iframe section in the content
        iframe_start = content.find('id="test-iframe"')
        assert iframe_start != -1, "Iframe should be present in content"

        # Extract the content inside the iframe (between <iframe> and </iframe>)
        # The iframe content is nested inside the iframe tag
        iframe_end_tag = content.find("</iframe", iframe_start)
        assert iframe_end_tag != -1, "Iframe closing tag should be present"

        # Get the content inside the iframe
        iframe_inner_start = content.find(">", iframe_start) + 1
        iframe_inner_content = content[iframe_inner_start:iframe_end_tag]

        # Verify that <p> tags are not present in iframe content
        assert "<p>" not in iframe_inner_content, "Iframe should not contain <p> tags"
        assert "This paragraph should be removed" not in iframe_inner_content
        assert "Another paragraph to remove" not in iframe_inner_content

        # Verify that other tags are still present
        assert "<h2>Iframe Title</h2>" in iframe_inner_content
        assert "<div>This div should remain.</div>" in iframe_inner_content

        await browser.close()
        await playwright.stop()
