"""Stitch iframe contents into a single DOM."""

import logging
import uuid
from collections.abc import Awaitable
from collections.abc import Callable

import bs4
from bs4.element import Tag
from playwright.async_api import Frame
from playwright.async_api import Locator
from playwright.async_api import Page

from .frame_tree import FrameNode
from .frame_tree import FrameTree
from .utils import IFRAME_REPLACEMENT_TAG
from .utils import IFRAME_TAGS

logger = logging.getLogger(__name__)


async def stitch_iframe_contents(
    iframe_tree: FrameTree,
    extract_html: Callable[[Page | Frame | Locator], Awaitable[str]] | None = None,
) -> bs4.BeautifulSoup:
    """
    Stitch iframe contents into a single soup.

    Args:
        iframe_tree: FrameTree containing the root and tree structure
        extract_html: Callback to extract HTML from a frame. This will be called on each frame in the tree.
            If not provided, extract_html will be a simple .content() call.
    """
    if extract_html is None:

        async def _default_extract_html(root: Page | Frame | Locator) -> str:
            if isinstance(root, Page | Frame):
                return await root.content()
            else:
                return await root.evaluate("el => el.outerHTML")

        extract_html = _default_extract_html

    frame_to_marker: dict[Frame, str] = {}

    # Add markers
    for node in iframe_tree.nodes:
        try:
            marker_id = f"iframe-{uuid.uuid4().hex[:8]}"
            await node.frame_element.evaluate(
                "(el, marker) => el.setAttribute('data-iframe-marker', marker)",
                marker_id,
            )
            frame_to_marker[node.frame] = marker_id
        except Exception as e:
            logger.warning(f"Error adding marker to iframe: {e}")

    try:
        root = iframe_tree.root
        root_content = await extract_html(root)

        frame_contents: dict[Frame, str] = {}
        for node in iframe_tree.nodes:
            try:
                frame_contents[node.frame] = await extract_html(node.frame)
            except Exception as e:
                logger.warning(f"Error extracting content from frame: {e}")

        # Stitch using the markers
        main_soup = bs4.BeautifulSoup(root_content, "html.parser")
        for iframe_node in iframe_tree.tree:
            _stitch_iframe_recursive(main_soup, iframe_node, frame_contents, frame_to_marker)

        return main_soup

    finally:
        # Clean up markers
        for node in iframe_tree.nodes:
            try:
                await node.frame_element.evaluate("(el) => el.removeAttribute('data-iframe-marker')")
            except Exception as e:
                logger.warning(f"Error removing marker from iframe: {e}")


def _stitch_iframe_recursive(
    parent_soup: bs4.BeautifulSoup,
    iframe_node: FrameNode,
    frame_contents: dict[Frame, str],
    frame_to_marker: dict[Frame, str],
) -> None:
    content = frame_contents.get(iframe_node.frame)
    if content is None:
        logger.warning(f"No content found for frame {iframe_node.frame}")
        return

    marker_id = frame_to_marker.get(iframe_node.frame)
    if not marker_id:
        logger.warning(f"No marker found for frame {iframe_node.frame}")
        return

    iframe_element = parent_soup.find(IFRAME_TAGS, attrs={"data-iframe-marker": marker_id})
    if not iframe_element or not isinstance(iframe_element, Tag):
        logger.warning(f"Could not find iframe element with marker {marker_id} in soup")
        return

    frame_soup = bs4.BeautifulSoup(content, "html.parser")
    html_element = frame_soup.find("html")

    if not html_element:
        logger.warning(f"No html element found in iframe {marker_id}")
        return

    for nested_node in iframe_node.nested_iframes:
        _stitch_iframe_recursive(frame_soup, nested_node, frame_contents, frame_to_marker)

    if "data-iframe-marker" in iframe_element.attrs:
        del iframe_element.attrs["data-iframe-marker"]

    # Extract body content to avoid nested <html> tags
    body_element = frame_soup.find("body")
    iframe_element.clear()

    if body_element:
        # Append all children of body to iframe, not the body element itself
        for child in list(body_element.children):
            iframe_element.append(child)
    else:
        # Fallback: append the html element if no body found
        iframe_element.append(html_element)

    # Replace iframe tag with custom tag to make it valid HTML
    # (iframes can't normally have HTML children)
    original_tag_name = iframe_element.name
    if original_tag_name in IFRAME_REPLACEMENT_TAG:
        iframe_element.name = IFRAME_REPLACEMENT_TAG[original_tag_name]
