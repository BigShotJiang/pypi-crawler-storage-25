"""Frame tree for representing iframe hierarchy."""

import asyncio
import logging
from collections.abc import Iterator
from dataclasses import dataclass

from playwright.async_api import ElementHandle
from playwright.async_api import Frame
from playwright.async_api import Locator
from playwright.async_api import Page

from .check_frame_allows_async_scripts import check_frame_allows_async_scripts
from .utils import find_top_level_iframe_elements

logger = logging.getLogger(__name__)


@dataclass
class FrameNode:
    """Represents a frame in a tree structure.

    Attributes:
        frame: The Playwright Frame object for this iframe
        frame_element: The ElementHandle for the iframe element.
            This gives you access to the iframe element itself in its parent frame's DOM.
        nested_iframes: List of nested iframe nodes within this iframe
        allows_async_scripts: Whether this iframe allows asynchronous script operations.
            Synchronous code (e.g., via frame.evaluate()) can still execute even when this is False.
            However, when False, asynchronous operations like event listeners, callbacks,
            setTimeout, and promises do not work at all in the iframe.
    """

    frame: Frame
    frame_element: ElementHandle
    allows_async_scripts: bool

    _nested_iframes: list["FrameNode"]

    @property
    def nested_iframes(self) -> Iterator["FrameNode"]:
        """Yields nested iframe nodes, skipping detached frames.
        Do not eagerly load all frames with list() or similar."""
        for node in self._nested_iframes:
            if node.frame.is_detached():
                logger.warning(f"Detached frame skipped: {node.frame}")
                continue
            yield node


@dataclass
class FrameTree:
    root: Page | Frame | Locator
    _tree: list[FrameNode]

    @property
    def tree(self) -> Iterator[FrameNode]:
        """Yields top-level frame nodes, skipping detached frames.
        Do not eagerly load all frames with list() or similar."""
        for node in self._tree:
            if node.frame.is_detached():
                logger.warning(f"Detached frame skipped: {node.frame}")
                continue
            yield node

    @property
    def nodes(self) -> Iterator[FrameNode]:
        """Yields all nodes in the tree (flattened), skipping detached frames.
        Do not eagerly load all frames with list() or similar."""
        for node in self.tree:
            yield node
            yield from self._traverse_nested(node)

    def _traverse_nested(self, node: FrameNode) -> Iterator[FrameNode]:
        for child in node.nested_iframes:
            yield child
            yield from self._traverse_nested(child)

    @staticmethod
    async def from_root(
        root: Page | Frame | Locator,
        iframe_timeout: float = 10.0,
        skip_useless: bool = True,
    ) -> "FrameTree":
        """
        Recursively get all frames from a root as a tree structure.
        Skips iframes that hang due to problematic sources.
        Using this function is safer than manually fetching iframes since it handles the hanging issue.

        Args:
            root: The Page, Frame, or Locator to start the search from
            iframe_timeout: Timeout in seconds for accessing iframe content
            skip_useless: If True, skips captcha and tracking pixel iframes (provides performance boost)

        Returns:
            Returns a list of top-level iframe nodes, where each node contains its frame and any nested iframes.
        """
        processed: set[Frame] = set()
        tree = await _process_frame_recursive(
            root=root,
            processed_frames=processed,
            iframe_timeout=iframe_timeout,
            skip_useless=skip_useless,
        )
        return FrameTree(root=root, _tree=tree)


async def _process_frame_recursive(
    root: Page | Frame | Locator,
    processed_frames: set[Frame],
    iframe_timeout: float,
    skip_useless: bool,
) -> list[FrameNode]:
    if isinstance(root, Frame) and root in processed_frames:
        return []
    if isinstance(root, Frame):
        processed_frames.add(root)

    iframe_nodes: list[FrameNode] = []

    try:
        try:
            iframe_handles = await asyncio.wait_for(
                find_top_level_iframe_elements(root, skip_useless=skip_useless),
                timeout=iframe_timeout,
            )
        except TimeoutError:
            logger.error("Timeout finding iframe elements, skipping")
            return []

        if not iframe_handles:
            return []

        logger.debug(f"Found {len(iframe_handles)} iframe elements to process")
        for iframe_handle in iframe_handles:
            try:
                iframe_node = await asyncio.wait_for(
                    _process_single_iframe(
                        iframe_handle=iframe_handle,
                        processed_frames=processed_frames,
                        iframe_timeout=iframe_timeout,
                        skip_useless=skip_useless,
                    ),
                    timeout=iframe_timeout,
                )

                if iframe_node is not None:
                    iframe_nodes.append(iframe_node)

            except TimeoutError:
                logger.error("Timeout processing iframe, skipping")
                continue
            except Exception as e:
                logger.error(f"Error processing iframe: {e}", exc_info=False)
                continue

    except Exception as e:
        logger.error(f"Error processing frames in context: {e}", exc_info=True)

    return iframe_nodes


async def _process_single_iframe(
    iframe_handle: ElementHandle,
    processed_frames: set[Frame],
    iframe_timeout: float,
    skip_useless: bool,
) -> FrameNode | None:
    """Process a single iframe ElementHandle into a FrameNode."""
    content_frame = await iframe_handle.content_frame()
    if not content_frame:
        logger.error("Could not access content_frame for iframe")
        return None

    if content_frame in processed_frames:
        return None

    allows_async_scripts = await check_frame_allows_async_scripts(iframe_handle)

    nested_iframes = await _process_frame_recursive(
        root=content_frame,
        processed_frames=processed_frames,
        iframe_timeout=iframe_timeout,
        skip_useless=skip_useless,
    )

    return FrameNode(
        frame=content_frame,
        frame_element=iframe_handle,
        _nested_iframes=nested_iframes,
        allows_async_scripts=allows_async_scripts,
    )
