"""Frame utilities for iframe handling."""

from .check_frame_allows_async_scripts import check_frame_allows_async_scripts
from .frame_tree import FrameNode
from .frame_tree import FrameTree
from .get_container_frame import get_container_frame
from .get_content_with_nested_iframes import get_content_with_nested_iframes
from .stitch_iframe import stitch_iframe_contents
from .utils import ALL_IFRAMES_CSS_SELECTOR
from .utils import find_top_level_iframe_elements
from .utils import IFRAME_TAGS

__all__ = [
    "check_frame_allows_async_scripts",
    "get_container_frame",
    "get_content_with_nested_iframes",
    "stitch_iframe_contents",
    "FrameNode",
    "FrameTree",
    "IFRAME_TAGS",
    "ALL_IFRAMES_CSS_SELECTOR",
    "find_top_level_iframe_elements",
]
