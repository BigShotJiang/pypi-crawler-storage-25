"""Get content with nested iframes stitched together."""

from collections.abc import Awaitable
from collections.abc import Callable

from playwright.async_api import Frame
from playwright.async_api import Locator
from playwright.async_api import Page

from .frame_tree import FrameTree
from .stitch_iframe import stitch_iframe_contents

HtmlContentExtractor = Callable[[Page | Frame | Locator], Awaitable[str]]


async def get_content_with_nested_iframes(
    root: Page | Frame | Locator,
    iframe_timeout: float = 10.0,
    html_content_extractor: HtmlContentExtractor | None = None,
) -> str:
    """
    Get HTML content string of a given root and all nested iframes recursively, then stitches them together.

    This function processes a page or frame and includes any nested iframe content by nesting it inside
    the iframe elements themselves, similar to how browser developer tools display
    iframe content. This allows for a unified DOM inspection experience.

    Args:
        root: The root context to search from (Page, Frame, or Locator)
        iframe_timeout: Timeout in seconds for accessing iframe element, since it might hang due to problematic iframe sources
        html_content_extractor: Optional function to extract HTML content from a Page, Frame, or Locator.
            If not provided, defaults to using `.content()` for Page/Frame and `.evaluate("el => el.outerHTML")` for Locator.
            This is useful if you want to extract the HTML with custom logic, e.g. removing certain tags or attributes.

    Returns:
        HTML string with all nested iframes included in the content.

    Example:
        ```python
        # Basic usage
        content = await get_content_with_nested_iframes(page)

        # With custom HTML extractor
        async def custom_extractor(root):
            html = await root.content() if isinstance(root, Page | Frame) else await root.evaluate("el => el.outerHTML")
            soup = BeautifulSoup(html, "html.parser")
            for script in soup.find_all("script"):
                script.decompose()
            return str(soup)

        content = await get_content_with_nested_iframes(page, html_content_extractor=custom_extractor)
        ```
    """
    # Build the iframe tree structure
    iframe_tree = await FrameTree.from_root(
        root=root,
        iframe_timeout=iframe_timeout,
        skip_useless=True,
    )

    # Stitch iframe contents together
    soup = await stitch_iframe_contents(
        iframe_tree=iframe_tree,
        extract_html=html_content_extractor,
    )

    return str(soup)
