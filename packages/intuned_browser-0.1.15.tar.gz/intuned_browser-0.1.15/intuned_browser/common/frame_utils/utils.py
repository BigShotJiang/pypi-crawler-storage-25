"""Frame utilities for finding iframe elements."""

import json

from playwright.async_api import ElementHandle
from playwright.async_api import Frame
from playwright.async_api import Locator
from playwright.async_api import Page

IFRAME_TAGS = [
    "iframe",
    "frame",
]

ALL_IFRAMES_CSS_SELECTOR = ", ".join(IFRAME_TAGS)

IFRAME_SRC_ATTRS = [
    "src",
    "data-src",
    "data-lazy-src",
    "data-original-src",
    "data-url",
    "data-iframe-src",
]


IFRAME_CAPTCHA_SRC_PATTERNS = [
    # reCAPTCHA
    "google.com/recaptcha",
    "recaptcha.net/recaptcha",
    "gstatic.com/recaptcha",
    # hCaptcha
    "hcaptcha.com",
    "hcaptcha.net",
    # FunCaptcha/Arkose Labs
    "funcaptcha.com",
    "arkoselabs.com",
    # Cloudflare
    "challenges.cloudflare.com",
    "cloudflare.com/cdn-cgi/challenge",
    "cloudflare.com/turnstile",
    # GeeTest
    "geetest.com",
    # AWS WAF
    "awswaf",
    "aws-waf",
    # LeminCaptcha
    "leminnow.com",
    # Generic
    "captcha",
]

IFRAME_PIXEL_SRC_DOMAINS = [
    "facebook.com/tr",
    "doubleclick.net",
    "google-analytics.com",
    "bat.bing.com",
    "analytics.twitter.com",
    "px.ads.linkedin.com",
    "t.co/i/adsct",
    "adsrvr.org",
    "demdex.net",
    "crwdcntrl.net",
]

IFRAME_REPLACEMENT_TAG = {
    "iframe": "iframe-content",
    "frame": "frame-content",
}


async def find_top_level_iframe_elements(
    root: Page | Frame | Locator,
    skip_useless: bool = True,
) -> list[ElementHandle]:
    """
    Find all top-level iframe elements in a page/frame/locator, returning ElementHandles.
    This happens in one evaluate call for performance and no race condition risks.

    Args:
        root: The Page, Frame, or Locator to search in
        skip_useless: If True, filters out captcha and pixel iframes

    Returns:
        List of ElementHandles for the iframe elements
    """
    if skip_useless:
        js_code = f"""(root) => {{
    const srcAttrs = {json.dumps(IFRAME_SRC_ATTRS)};
    const captchaPatterns = {json.dumps([p.lower() for p in IFRAME_CAPTCHA_SRC_PATTERNS])};
    const pixelDomains = {json.dumps(IFRAME_PIXEL_SRC_DOMAINS)};

    return Array.from(root.querySelectorAll('{ALL_IFRAMES_CSS_SELECTOR}')).filter(el => {{
        let url = '';
        for (const attr of srcAttrs) {{
            const val = el.getAttribute(attr);
            if (val) {{ url = val; break; }}
        }}
        const urlLower = url.toLowerCase();

        if (captchaPatterns.some(p => urlLower.includes(p))) return false;
        if (pixelDomains.some(d => urlLower.includes(d))) return false;

        const w = el.getAttribute('width');
        const h = el.getAttribute('height');
        const style = el.getAttribute('style') || '';

        const parseNum = (val) => {{
            if (!val) return null;
            const str = String(val).trim();
            if (/[%a-zA-Z]/.test(str)) return null;
            const n = parseFloat(str);
            return isNaN(n) ? null : n;
        }};

        let width = parseNum(w);
        let height = parseNum(h);

        if (width === null) {{
            const wMatch = style.match(/width\\s*:\\s*(\\d+)/);
            if (wMatch) width = parseFloat(wMatch[1]);
        }}
        if (height === null) {{
            const hMatch = style.match(/height\\s*:\\s*(\\d+)/);
            if (hMatch) height = parseFloat(hMatch[1]);
        }}

        return !(width === 0 || width === 1 || height === 0 || height === 1);
    }});
}}"""
    else:
        js_code = f"(root) => Array.from(root.querySelectorAll('{ALL_IFRAMES_CSS_SELECTOR}'))"

    if isinstance(root, Locator):
        element = await root.element_handle()
        if not element:
            return []
        array_handle = await element.evaluate_handle(js_code)
    else:
        array_handle = await root.evaluate_handle(f"() => ({js_code})(document)")

    properties = await array_handle.get_properties()

    handles: list[ElementHandle] = []
    for js_handle in properties.values():
        el = js_handle.as_element()
        if el:
            handles.append(el)

    return handles
