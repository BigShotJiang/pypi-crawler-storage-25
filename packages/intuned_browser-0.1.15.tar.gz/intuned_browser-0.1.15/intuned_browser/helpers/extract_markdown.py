import mdformat
from playwright.async_api import Locator
from playwright.async_api import Page

from intuned_browser.common.evaluate_with_intuned import evaluate_with_intuned
from intuned_browser.common.frame_utils import get_content_with_nested_iframes


async def extract_markdown(source: Page | Locator) -> str:
    html_content = await get_content_with_nested_iframes(source)

    if isinstance(source, Page):
        md = await evaluate_with_intuned(
            source,
            """(html) => {
                const parser = new DOMParser();
                const doc = parser.parseFromString(html, 'text/html');
                const body = doc.body || doc.documentElement;
                return window.__INTUNED__.convertElementToMarkdown(body);
            }""",
            html_content,
        )
    else:
        md = await evaluate_with_intuned(
            source.page,
            """(html) => {
                const parser = new DOMParser();
                const doc = parser.parseFromString(html, 'text/html');
                const element = doc.body?.firstElementChild || doc.documentElement.firstElementChild || doc.documentElement;
                return window.__INTUNED__.convertElementToMarkdown(element);
            }""",
            html_content,
        )

    return mdformat.text(md)
