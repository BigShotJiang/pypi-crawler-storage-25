import pytest
from _intuned_runtime_internal import launch_chromium

from intuned_browser import extract_markdown


class TestToMarkdown:
    """Tests for the extract_markdown function."""

    @pytest.mark.asyncio
    async def test_locator_conversion(self):
        """Test converting Playwright locator to markdown."""
        async with launch_chromium(headless=True) as (_, page):
            # Create a test page with content
            await page.set_content("""
               <html>
                   <body>
                       <div id="test-content">
                           <h2>Test Header</h2>
                           <p>Test paragraph with <em>italic</em> text.</p>
                       </div>
                   </body>
               </html>
           """)

            locator = page.locator("#test-content")
            result = await extract_markdown(locator)

            assert "## Test Header" in result
            assert "Test paragraph with _italic_ text." in result

    @pytest.mark.asyncio
    async def test_locator_with_nested_elements(self):
        """Test converting locator with nested elements to markdown."""
        async with launch_chromium(headless=True) as (_, page):
            await page.set_content("""
               <html>
                   <body>
                       <article id="article">
                           <header>
                               <h1>Article Title</h1>
                               <p class="meta">By Author Name</p>
                           </header>
                           <section>
                               <p>First paragraph of content.</p>
                               <p>Second paragraph with <code>inline code</code>.</p>
                           </section>
                       </article>
                   </body>
               </html>
           """)

            locator = page.locator("#article")
            result = await extract_markdown(locator)

            assert "# Article Title" in result
            assert "By Author Name" in result
            assert "First paragraph of content." in result
            assert "`inline code`" in result

    @pytest.mark.asyncio
    async def test_convert_page_to_markdown(self):
        """Test converting page to markdown."""
        async with launch_chromium(headless=True) as (_, page):
            await page.set_content("""
               <html>
                   <body>
                       <div id="test-content">
                           <h2>Test Header</h2>
                           <p>Test paragraph with <em>italic</em> text.</p>
                           </div>
                       </body>
                   </html>
               """)

            result = await extract_markdown(page)

            assert "## Test Header" in result
            assert "Test paragraph with _italic_ text." in result

    @pytest.mark.asyncio
    async def test_extract_markdown_from_locator_with_iframe(self):
        """Test extracting markdown from a locator that contains an iframe."""
        async with launch_chromium(headless=True) as (_, page):
            await page.set_content("""
               <html>
                   <body>
                       <div id="outside">
                           <h1>Outside Content</h1>
                       </div>
                       <div id="container">
                           <h2>Container Header</h2>
                           <iframe id="nested-iframe" srcdoc="<html><body><h3>Nested Iframe</h3><p>Nested content</p></body></html>"></iframe>
                           <p>After iframe</p>
                       </div>
                   </body>
               </html>
           """)

            # Wait for iframe to load
            await page.wait_for_selector("#nested-iframe")
            await page.frame_locator("#nested-iframe").locator("body").wait_for()

            # Extract markdown from just the container with iframe
            locator = page.locator("#container")
            result = await extract_markdown(locator)

            # Should contain container content and iframe content
            assert "## Container Header" in result
            assert "### Nested Iframe" in result
            assert "Nested content" in result
            assert "After iframe" in result
            # Should NOT contain outside content
            assert "Outside Content" not in result

    @pytest.mark.asyncio
    async def test_extract_markdown_page_with_multiple_iframes(self):
        """Test extracting markdown from a page with multiple iframes."""
        async with launch_chromium(headless=True) as (_, page):
            await page.set_content("""
               <html>
                   <body>
                       <h1>Main Page</h1>
                       <p>This is the main content.</p>

                       <iframe id="iframe-1" srcdoc="<html><body><h2>Iframe 1</h2><p>Content in iframe 1</p></body></html>"></iframe>

                       <iframe id="iframe-2" srcdoc="<html><body><h2>Iframe 2</h2><p>Content in iframe 2</p></body></html>"></iframe>

                       <p>Footer content</p>
                   </body>
               </html>
           """)

            # Wait for iframes to load
            await page.wait_for_selector("#iframe-1")
            await page.frame_locator("#iframe-1").locator("body").wait_for()
            await page.wait_for_selector("#iframe-2")
            await page.frame_locator("#iframe-2").locator("body").wait_for()

            result = await extract_markdown(page)

            # Should contain main page content
            assert "# Main Page" in result
            assert "This is the main content" in result
            assert "Footer content" in result

            # Should contain both iframe contents
            assert "## Iframe 1" in result
            assert "Content in iframe 1" in result
            assert "## Iframe 2" in result
            assert "Content in iframe 2" in result

    @pytest.mark.asyncio
    async def test_extract_markdown_nested_iframes(self):
        """Test extracting markdown from nested iframes (iframe inside iframe)."""
        async with launch_chromium(headless=True) as (_, page):
            await page.set_content("""
               <html>
                   <body>
                       <h1>Main Page</h1>

                       <iframe id="outer-iframe"
                               srcdoc="<html><body><h2>Outer Iframe</h2><p>Outer content</p><iframe id='inner-iframe' srcdoc='&lt;html&gt;&lt;body&gt;&lt;h3&gt;Inner Iframe&lt;/h3&gt;&lt;p&gt;Inner content&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;'></iframe></body></html>">
                       </iframe>

                       <p>After iframes</p>
                   </body>
               </html>
           """)

            # Wait for outer iframe
            await page.wait_for_selector("#outer-iframe")
            await page.frame_locator("#outer-iframe").locator("body").wait_for()

            # Wait for inner iframe (nested inside outer)
            await page.frame_locator("#outer-iframe").frame_locator("#inner-iframe").locator("body").wait_for()

            result = await extract_markdown(page)

            # Should contain all levels of content
            assert "# Main Page" in result
            assert "## Outer Iframe" in result
            assert "Outer content" in result
            assert "### Inner Iframe" in result
            assert "Inner content" in result
            assert "After iframes" in result
