import logging

import pytest
from _intuned_runtime_internal import launch_chromium

from intuned_browser.common.frame_utils import get_content_with_nested_iframes
from intuned_browser.helpers.utils import get_simplified_html  # type: ignore


@pytest.mark.asyncio
@pytest.mark.headed12
async def test_basic_html_simplification():
    async with launch_chromium(headless=True) as (_, page):
        await page.set_content("""
        <html>
        <head><title>Basic Test</title></head>
        <body>
            <h1>Main Heading</h1>
            <p>This is a paragraph with some text content.</p>
            <div>
                <span>Nested content</span>
                <ul>
                    <li>List item 1</li>
                    <li>List item 2</li>
                </ul>
            </div>
            <img src="test.jpg" alt="Test image">
        </body>
        </html>
        """)
        await page.wait_for_timeout(1000)

        body_locator = page.locator("body")
        simplified_html = await get_simplified_html(body_locator)

        logging.info(simplified_html)
        assert simplified_html
        assert "<body" in simplified_html


@pytest.mark.asyncio
async def test_with_interactive_elements():
    async with launch_chromium(headless=True) as (_, page):
        await page.set_content("""
        <html>
        <body>
            <form>
                <input type="text" name="username" placeholder="Enter username">
                <input type="password" name="password" placeholder="Enter password">
                <textarea name="comments" placeholder="Your comments"></textarea>
                <select name="country">
                    <option value="us">United States</option>
                    <option value="uk">United Kingdom</option>
                </select>
                <button type="submit">Submit</button>
                <button type="button" onclick="alert('clicked')">Click Me</button>
            </form>
            <a href="https://example.com">Link to example</a>
            <div style="cursor: pointer;">Clickable div</div>
            <span onmousedown="console.log('mouse down')">Mouse event span</span>
        </body>
        </html>
        """)
        await page.wait_for_timeout(2000)

        body_locator = page.locator("body")
        simplified_html = await get_simplified_html(body_locator)

        logging.info(simplified_html)
        assert simplified_html
        # Should contain interactive elements like input, button
        assert any(tag in simplified_html.lower() for tag in ["input", "button", "textarea"])


@pytest.mark.asyncio
async def test_with_options():
    async with launch_chromium(headless=True) as (_, page):
        await page.set_content("""
        <html>
        <body>
            <div onclick="handleClick()">Clickable content</div>
            <button onclick="submitForm()">Submit Form</button>
            <a href="#" onclick="navigate()">Navigation Link</a>
            <span onmouseup="handleMouse()">Mouse handler</span>
            <div onkeydown="handleKey()">Key handler</div>
            <p>Regular paragraph with lots of text content that should be included as content prop</p>
            <article>
                <h2>Article Title</h2>
                <p>Article content with meaningful text that should be preserved</p>
            </article>
        </body>
        </html>
        """)
        await page.wait_for_timeout(1000)

        body_locator = page.locator("body")
        simplified_html = await get_simplified_html(
            body_locator, options={"should_include_on_click": True, "should_include_content_as_prop": True}
        )

        print(simplified_html)
        assert simplified_html
        assert "<body" in simplified_html
        # Should include onclick attributes when option is enabled
        assert "onclick" in simplified_html
        # Should include content as attribute when option is enabled
        assert "content=" in simplified_html


@pytest.mark.asyncio
async def test_invisible_elements_filtered():
    async with launch_chromium(headless=True) as (_, page):
        # Create a page with hidden elements
        await page.set_content("""
        <html>
        <body>
            <div style="display: none;">Hidden div</div>
            <div>Visible div</div>
            <button style="visibility: hidden;">Hidden button</button>
            <button>Visible button</button>
            <span style="opacity: 0;">Invisible span</span>
            <span>Visible span</span>
            <p style="display: block;">Visible paragraph</p>
        </body>
        </html>
        """)

        body_locator = page.locator("body")
        simplified_html = await get_simplified_html(body_locator, options={"keep_only_visible_elements": True})

        logging.info(simplified_html)
        assert "Visible div" in simplified_html or "visible" in simplified_html.lower()
        assert "Hidden div" not in simplified_html
        assert "Hidden button" not in simplified_html
        assert "Invisible span" not in simplified_html


@pytest.mark.asyncio
async def test_full_html_element():
    async with launch_chromium(headless=True) as (_, page):
        await page.set_content("""
        <html lang="en">
        <head>
            <title>Full HTML Test</title>
            <meta charset="UTF-8">
        </head>
        <body>
            <header>
                <h1>Website Header</h1>
                <nav>
                    <a href="/">Home</a>
                    <a href="/about">About</a>
                </nav>
            </header>
            <main>
                <section>
                    <h2>Main Section</h2>
                    <p>Main content area</p>
                </section>
            </main>
            <footer>
                <p>&copy; 2024 Test Site</p>
            </footer>
        </body>
        </html>
        """)
        await page.wait_for_timeout(1000)

        simplified_html = await get_simplified_html(page)

        logging.info(simplified_html)
        assert simplified_html
        assert simplified_html.startswith("<html")


@pytest.mark.asyncio
async def test_allowed_attributes():
    async with launch_chromium(headless=True) as (_, page):
        await page.set_content("""
        <html>
        <body>
            <div aria-label="Main content area" data-testid="main-div" data-custom="value">
                <input type="text" name="search" placeholder="Search..." value="test value">
                <button role="button" title="Submit search">Search</button>
                <a href="https://example.com" id="main-link">External Link</a>
                <img src="test.jpg" alt="Test image" data-src="fallback.jpg">
            </div>
            <form data-form-id="contact">
                <input type="email" name="email" placeholder="Your email">
                <textarea name="message" placeholder="Your message" title="Message field"></textarea>
            </form>
        </body>
        </html>
        """)

        body_locator = page.locator("body")
        simplified_html = await get_simplified_html(body_locator)

        logging.info(simplified_html)
        assert simplified_html
        # Should preserve allowed attributes
        assert "aria-label=" in simplified_html
        assert "data-" in simplified_html
        assert "name=" in simplified_html
        assert "type=" in simplified_html
        assert "placeholder=" in simplified_html
        assert "role=" in simplified_html
        assert "title=" in simplified_html
        assert "href=" in simplified_html
        assert "id=" in simplified_html
        assert "alt=" in simplified_html


@pytest.mark.asyncio
async def test_input_with_values():
    async with launch_chromium(headless=True) as (_, page):
        await page.set_content("""
        <html>
        <body>
            <form>
                <input type="text" name="filled" value="has value" style="display: none;">
                <input type="text" name="empty" value="" style="display: none;">
                <input type="hidden" name="hidden" value="hidden value">
                <input type="text" name="visible" value="visible value">
            </form>
        </body>
        </html>
        """)

        body_locator = page.locator("body")
        simplified_html = await get_simplified_html(body_locator)

        logging.info(simplified_html)
        assert simplified_html
        # Should include hidden inputs with values even when keep_only_visible_elements is True
        assert 'value="has value"' in simplified_html or "has value" in simplified_html
        assert 'value="hidden value"' in simplified_html or "hidden value" in simplified_html


@pytest.mark.asyncio
async def test_iframe_content_inclusion():
    """Test that iframe content is included when using get_content_with_nested_iframes with get_simplified_html"""
    async with launch_chromium(headless=True) as (_, page):
        await page.set_content("""
        <html>
        <body>
            <div>Main page content</div>
            <iframe id="test-iframe" srcdoc="
                <html>
                <body>
                    <h1>Iframe Title</h1>
                    <p>This is content inside the iframe</p>
                    <button>Iframe Button</button>
                    <input type='text' name='iframe-input' value='iframe value'>
                </body>
                </html>
            "></iframe>
            <div>Content after iframe</div>
        </body>
        </html>
        """)

        await page.wait_for_timeout(1000)

        iframe = page.frame_locator("#test-iframe")
        await iframe.locator("h1").wait_for(state="visible", timeout=5000)

        body_locator = page.locator("body")

        simplified_html_no_iframe = await get_simplified_html(body_locator)

        simplified_html_with_iframe = await get_content_with_nested_iframes(
            body_locator, html_content_extractor=get_simplified_html
        )

        assert "Main page content" in simplified_html_no_iframe
        assert "Main page content" in simplified_html_with_iframe

        assert "Iframe Title" not in simplified_html_no_iframe
        assert "This is content inside the iframe" not in simplified_html_no_iframe
        assert "Iframe Button" not in simplified_html_no_iframe

        assert (
            "Iframe Title" in simplified_html_with_iframe
        ), "Iframe content should be included when using get_content_with_nested_iframes"
        assert (
            "This is content inside the iframe" in simplified_html_with_iframe
        ), "Iframe content should be included when using get_content_with_nested_iframes"
        assert "Iframe Button" in simplified_html_with_iframe, "Iframe interactive elements should be included"


@pytest.mark.asyncio
async def test_cross_origin_iframe_handling():
    async with launch_chromium(headless=True) as (_, page):
        _ = await page.goto("about:blank")

        # Create a page with a cross-origin iframe
        await page.set_content("""
        <html>
        <body>
            <div>Main page content</div>
            <iframe id="cross-origin-iframe" src="https://example.com">
                <p>Iframe content</p>
            </iframe>
            <div>Content after iframe</div>
        </body>
        </html>
        """)

        await page.wait_for_timeout(2000)

        iframe = page.frame_locator("#cross-origin-iframe")
        await iframe.locator("body").wait_for(state="attached", timeout=5000)

        body_locator = page.locator("body")

        simplified_html_no_iframe = await get_simplified_html(body_locator)

        simplified_html_with_iframe = await get_content_with_nested_iframes(
            body_locator, html_content_extractor=get_simplified_html
        )

        assert "Main page content" in simplified_html_no_iframe
        assert "Main page content" in simplified_html_with_iframe

        assert "iframe" in simplified_html_with_iframe.lower() or "<iframe" in simplified_html_with_iframe

        # Based on actual example.com content
        assert (
            "Example Domain" in simplified_html_with_iframe
        ), "Cross-origin iframe content should be included when accessible"
        assert (
            "This domain is for use in documentation examples" in simplified_html_with_iframe
        ), "Cross-origin iframe content should be included when accessible"
        assert "Learn more" in simplified_html_with_iframe, "Cross-origin iframe links should be included"
