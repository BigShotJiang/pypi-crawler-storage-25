import pytest
from _intuned_runtime_internal import launch_chromium

from intuned_browser.ai.utils.matching.matching import create_matches_mapping
from intuned_browser.ai.utils.matching.matching import validate_matches_mapping

# Test HTML templates
PRODUCT_V1_HTML = """
<html>
<body>
  <div class="product">
    <h2 class="title">iPhone 14 Pro</h2>
    <div class="price">$999</div>
    <div class="stock">In Stock</div>
  </div>
</body>
</html>
"""

PRODUCT_V2_MODIFIED_CONTENT = """
<html>
<body>
  <div class="product">
    <h2 class="title">iPhone 15 Pro</h2>
    <div class="price">$1099</div>
    <div class="stock">In Stock</div>
  </div>
</body>
</html>
"""

PRODUCT_WITH_FOOTER = """
<html>
<body>
  <div class="product">
    <h2 class="title">iPhone 14 Pro</h2>
    <div class="price">$999</div>
    <div class="stock">In Stock</div>
  </div>
  <footer>
    <div class="copyright">© 2024 Store</div>
    <div class="links">Privacy | Terms</div>
  </footer>
</body>
</html>
"""

PRODUCT_WITH_HEADER = """
<html>
<body>
  <header>
    <div class="banner">New Arrival!</div>
  </header>
  <div class="product">
    <h2 class="title">iPhone 14 Pro</h2>
    <div class="price">$999</div>
    <div class="stock">In Stock</div>
  </div>
</body>
</html>
"""

IFRAME_V1_HTML = """
<html>
<body>
  <div class="product">
    <h2 class="title">iPhone 14 Pro</h2>
    <div class="price">$999</div>
  </div>
  <iframe id="details-frame" srcdoc='
    <html>
      <body>
        <div class="stock">In Stock</div>
        <div class="rating">4.5 stars</div>
      </body>
    </html>
  '></iframe>
</body>
</html>
"""

IFRAME_V2_MODIFIED_IFRAME = """
<html>
<body>
  <div class="product">
    <h2 class="title">iPhone 14 Pro</h2>
    <div class="price">$999</div>
  </div>
  <iframe id="details-frame" srcdoc='
    <html>
      <body>
        <div class="stock">Out of Stock</div>
        <div class="rating">4.5 stars</div>
      </body>
    </html>
  '></iframe>
</body>
</html>
"""

IFRAME_WITH_EXTRA_CONTENT = """
<html>
<body>
  <div class="product">
    <h2 class="title">iPhone 14 Pro</h2>
    <div class="price">$999</div>
  </div>
  <iframe id="details-frame" srcdoc='
    <html>
      <body>
        <div class="stock">In Stock</div>
        <div class="rating">4.5 stars</div>
        <div class="reviews">100+ reviews</div>
      </body>
    </html>
  '></iframe>
</body>
</html>
"""


class TestValidateMatchesMapping:
    """Test validate_matches_mapping functionality."""

    @pytest.mark.asyncio
    async def test_validate_unchanged_content_returns_true(self):
        """Test that validation returns True when content hasn't changed."""

        async with launch_chromium(headless=True) as (_, page):
            await page.set_content(PRODUCT_V1_HTML)

            # Create initial mapping
            extracted_data = {
                "title": "iPhone 14 Pro",
                "price": "$999",
                "stock": "In Stock",
            }
            cached_mapping = await create_matches_mapping(page, extracted_data)

            # Validate should return True (content unchanged)
            is_valid = await validate_matches_mapping(page, cached_mapping)
            assert is_valid is True

    @pytest.mark.asyncio
    async def test_validate_changed_content_returns_false(self):
        """Test that validation returns False when extracted content changes."""

        async with launch_chromium(headless=True) as (_, page):
            # Create mapping with original content
            await page.set_content(PRODUCT_V1_HTML)
            extracted_data = {
                "title": "iPhone 14 Pro",
                "price": "$999",
            }
            cached_mapping = await create_matches_mapping(page, extracted_data)

            # Change content (title and price changed)
            await page.set_content(PRODUCT_V2_MODIFIED_CONTENT)

            # Validation should fail
            is_valid = await validate_matches_mapping(page, cached_mapping)
            assert is_valid is False

    @pytest.mark.asyncio
    async def test_validate_irrelevant_changes_returns_true(self):
        """Test that adding irrelevant elements (footer) doesn't invalidate mapping."""

        async with launch_chromium(headless=True) as (_, page):
            # Create mapping with original content
            await page.set_content(PRODUCT_V1_HTML)
            extracted_data = {
                "title": "iPhone 14 Pro",
                "price": "$999",
            }
            cached_mapping = await create_matches_mapping(page, extracted_data)

            # Add footer (doesn't affect extracted data)
            await page.set_content(PRODUCT_WITH_FOOTER)

            # Validation should still pass
            is_valid = await validate_matches_mapping(page, cached_mapping)
            assert is_valid is True

    @pytest.mark.asyncio
    async def test_validate_header_addition(self):
        """Test validation when header is added at top of page."""

        async with launch_chromium(headless=True) as (_, page):
            # Create mapping with original content
            await page.set_content(PRODUCT_V1_HTML)
            extracted_data = {
                "title": "iPhone 14 Pro",
                "price": "$999",
            }
            cached_mapping = await create_matches_mapping(page, extracted_data)

            # Add header at top
            await page.set_content(PRODUCT_WITH_HEADER)

            # The matched values are still present, so validation should pass
            # (We're not validating xpath structure, just that matches still exist)
            is_valid = await validate_matches_mapping(page, cached_mapping)
            assert is_valid is True

    @pytest.mark.asyncio
    async def test_validate_iframe_content_unchanged(self):
        """Test that validation works with iframe content."""

        async with launch_chromium(headless=True) as (_, page):
            await page.set_content(IFRAME_V1_HTML)
            await page.wait_for_selector("#details-frame")

            # Create mapping including iframe content
            extracted_data = {
                "title": "iPhone 14 Pro",
                "price": "$999",
                "stock": "In Stock",
                "rating": "4.5 stars",
            }
            cached_mapping = await create_matches_mapping(page, extracted_data)

            # Validate should pass (content unchanged)
            is_valid = await validate_matches_mapping(page, cached_mapping)
            assert is_valid is True

    @pytest.mark.asyncio
    async def test_validate_iframe_content_changed(self):
        """Test that validation fails when iframe content changes."""

        async with launch_chromium(headless=True) as (_, page):
            # Create mapping with original iframe
            await page.set_content(IFRAME_V1_HTML)
            await page.wait_for_selector("#details-frame")

            extracted_data = {
                "stock": "In Stock",
                "rating": "4.5 stars",
            }
            cached_mapping = await create_matches_mapping(page, extracted_data)

            # Change iframe content (stock changed)
            await page.set_content(IFRAME_V2_MODIFIED_IFRAME)
            await page.wait_for_selector("#details-frame")

            # Validation should fail
            is_valid = await validate_matches_mapping(page, cached_mapping)
            assert is_valid is False

    @pytest.mark.asyncio
    async def test_validate_iframe_extra_content_added(self):
        """Test validation when extra content is added to iframe."""

        async with launch_chromium(headless=True) as (_, page):
            # Create mapping with original iframe
            await page.set_content(IFRAME_V1_HTML)
            await page.wait_for_selector("#details-frame")

            extracted_data = {
                "stock": "In Stock",
                "rating": "4.5 stars",
            }
            cached_mapping = await create_matches_mapping(page, extracted_data)

            # Add extra content to iframe (doesn't affect extracted data)
            await page.set_content(IFRAME_WITH_EXTRA_CONTENT)
            await page.wait_for_selector("#details-frame")

            # Validation should still pass
            is_valid = await validate_matches_mapping(page, cached_mapping)
            assert is_valid is True

    @pytest.mark.asyncio
    async def test_validate_partial_content_change(self):
        """Test validation when only some extracted values change."""

        async with launch_chromium(headless=True) as (_, page):
            # Create mapping with all three values
            await page.set_content(PRODUCT_V1_HTML)
            extracted_data = {
                "title": "iPhone 14 Pro",
                "price": "$999",
                "stock": "In Stock",
            }
            cached_mapping = await create_matches_mapping(page, extracted_data)

            # Change only title and price (stock remains same)
            await page.set_content(PRODUCT_V2_MODIFIED_CONTENT)

            # Validation should fail because title and price changed
            is_valid = await validate_matches_mapping(page, cached_mapping)
            assert is_valid is False

    @pytest.mark.asyncio
    async def test_validate_empty_mapping_returns_true(self):
        """Test that validating empty mapping returns True."""

        async with launch_chromium(headless=True) as (_, page):
            await page.set_content(PRODUCT_V1_HTML)

            # Empty mapping should always be valid
            empty_mapping = {}
            is_valid = await validate_matches_mapping(page, empty_mapping)
            assert is_valid is True

    @pytest.mark.asyncio
    async def test_validate_with_completely_different_page(self):
        """Test validation when page content is completely different."""

        async with launch_chromium(headless=True) as (_, page):
            # Create mapping with product page
            await page.set_content(PRODUCT_V1_HTML)
            extracted_data = {
                "title": "iPhone 14 Pro",
                "price": "$999",
            }
            cached_mapping = await create_matches_mapping(page, extracted_data)

            # Load completely different page
            different_page = """
            <html>
            <body>
                <div class="article">
                <h1>About Us</h1>
                <p>We are a company...</p>
                </div>
            </body>
            </html>
            """
            await page.set_content(different_page)

            # Validation should fail
            is_valid = await validate_matches_mapping(page, cached_mapping)
            assert is_valid is False

    @pytest.mark.asyncio
    async def test_validate_mapping_consistency(self):
        """Test that validation is consistent across multiple calls."""

        async with launch_chromium(headless=True) as (_, page):
            await page.set_content(PRODUCT_V1_HTML)

            extracted_data = {
                "title": "iPhone 14 Pro",
                "price": "$999",
            }
            cached_mapping = await create_matches_mapping(page, extracted_data)

            # Validate multiple times - should all return True
            is_valid_1 = await validate_matches_mapping(page, cached_mapping)
            is_valid_2 = await validate_matches_mapping(page, cached_mapping)
            is_valid_3 = await validate_matches_mapping(page, cached_mapping)

            assert is_valid_1 is True
            assert is_valid_2 is True
            assert is_valid_3 is True
