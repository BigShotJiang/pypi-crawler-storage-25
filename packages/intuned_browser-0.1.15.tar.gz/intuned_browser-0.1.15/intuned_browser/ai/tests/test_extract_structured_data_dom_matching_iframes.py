"""
Tests for extract_structured_data with DOM matching and caching in iframes.

These tests verify that the intelligent caching system correctly handles DOM changes:
- Returns cached results when XPath to extracted elements is unchanged
- Invalidates cache when XPath changes due to DOM structure modifications
- Works correctly with nested iframe content
"""

from unittest.mock import patch

import pytest
from dotenv import load_dotenv
from pydantic import BaseModel
from pydantic import Field

# Optional imports with warning
try:
    from _intuned_runtime_internal import launch_chromium
    from _intuned_runtime_internal.context.context import IntunedContext
    from _intuned_runtime_internal.types.run_types import IntunedRunContext
except ImportError:
    launch_chromium = None
    IntunedContext = None
    IntunedRunContext = None
    import logging

    logging.warning("Runtime dependencies are not available. Some test features will be disabled.")

from intuned_browser.ai import extract_structured_data

load_dotenv()


class ProductData(BaseModel):
    """Product model for DOM matching tests"""

    name: str = Field(description="Product name")
    price: str = Field(description="Product price")
    stock: str = Field(description="Stock status")


class ListItem(BaseModel):
    """List item model for iframe tests"""

    title: str = Field(description="Item title")
    description: str = Field(description="Item description")


class MockCache:
    """Mock cache for testing that tracks get/set calls"""

    def __init__(self):
        self.storage = {}
        self.get_calls = []
        self.set_calls = []
        self.cache_hits = 0
        self.cache_misses = 0

    async def get(self, key: str):
        """Mock cache get - returns stored value or None"""
        self.get_calls.append(key)
        value = self.storage.get(key)
        if value is not None:
            self.cache_hits += 1
        else:
            self.cache_misses += 1
        return value

    async def set(self, key: str, value):
        """Mock cache set - stores value in memory"""
        self.set_calls.append((key, value))
        self.storage[key] = value


@pytest.mark.skip
@pytest.mark.skipif(IntunedContext is None or launch_chromium is None, reason="Runtime dependencies not available")
class TestDOMMatchingWithIframes:
    """Test DOM matching and caching behavior with iframes"""

    @pytest.mark.asyncio
    async def test_cache_valid_when_element_added_after_iframe(self):
        """
        Test that cache is VALID when an element is added AFTER the iframe.
        The XPath to the extracted element inside the iframe should remain unchanged.
        """
        if IntunedContext is None or launch_chromium is None:
            pytest.skip("Runtime dependencies not available")

        # Mock the cache to avoid backend dependencies
        mock_cache = MockCache()

        with patch("intuned_browser.ai.extract_structured_data.cache", mock_cache):
            with IntunedContext() as ctx:
                ctx.run_context = IntunedRunContext(  # type: ignore
                    job_id="test-dom-cache-valid-after",
                    job_run_id="eb722252-e932-4658-ac35-c846ed5b4f44",
                    run_id="yyPCx2XF7Eu9nda",
                    auth_session_id=None,
                )
                async with launch_chromium(headless=True) as (_, page):
                    # Initial HTML with iframe containing data to extract
                    initial_html = """
                    <html>
                    <body>
                        <h1>Product Page</h1>
                        <iframe id="product-data" srcdoc='
                            <ul class="product-list">
                                <li class="product-item">
                                    <span class="name">iPhone 15</span>
                                    <span class="price">$999</span>
                                    <span class="stock">In Stock</span>
                                </li>
                            </ul>
                        '></iframe>
                    </body>
                    </html>
                    """

                    await page.set_content(initial_html, wait_until="domcontentloaded")
                    await page.wait_for_timeout(500)  # Wait for iframe to load

                    # First extraction - should call AI
                    result1 = await extract_structured_data(
                        source=page,
                        data_schema=ProductData,
                        strategy="HTML",
                        prompt="Extract the product information from the page",
                        enable_dom_matching=True,
                        enable_cache=True,
                        model="claude-haiku-4-5-20251001",
                    )

                    assert result1 is not None
                    result1 = ProductData(**result1)
                    assert result1.name == "iPhone 15"
                    assert result1.price == "$999"
                    assert result1.stock == "In Stock"

                    # Modify HTML - add element AFTER iframe
                    modified_html = """
                    <html>
                    <body>
                        <h1>Product Page</h1>
                        <iframe id="product-data" srcdoc='
                            <ul class="product-list">
                                <li class="product-item">
                                    <span class="name">iPhone 15</span>
                                    <span class="price">$999</span>
                                    <span class="stock">In Stock</span>
                                </li>
                            </ul>
                        '></iframe>
                        <!-- NEW ELEMENT ADDED AFTER IFRAME -->
                        <footer>
                            <p>Footer content added</p>
                        </footer>
                    </body>
                    </html>
                    """

                    await page.set_content(modified_html, wait_until="domcontentloaded")
                    await page.wait_for_timeout(500)  # Wait for iframe to load

                    # Second extraction - should return CACHED result
                    # because XPath inside iframe is unchanged
                    result2 = await extract_structured_data(
                        source=page,
                        data_schema=ProductData,
                        strategy="HTML",
                        prompt="Extract the product information from the page",
                        enable_dom_matching=True,
                        enable_cache=True,
                        model="claude-haiku-4-5-20251001",
                    )

                    assert result2 is not None
                    result2 = ProductData(**result2)
                    assert result2.name == "iPhone 15"
                    assert result2.price == "$999"
                    assert result2.stock == "In Stock"

                    # Results should be identical (from cache)
                    assert result1.model_dump() == result2.model_dump()

                    # Verify cache was used (should have 2 get calls and 1 set call)
                    # First call: cache miss, AI called, result cached
                    # Second call: cache hit, return cached result
                    assert (
                        len(mock_cache.get_calls) == 2
                    ), f"Expected 2 cache get calls, got {len(mock_cache.get_calls)}"
                    assert len(mock_cache.set_calls) == 1, f"Expected 1 cache set call, got {len(mock_cache.set_calls)}"

    @pytest.mark.asyncio
    async def test_cache_invalid_when_element_added_before_target_in_iframe(self):
        """
        Test that cache is INVALID when an element is added BEFORE the target element
        inside the iframe. The XPath to the extracted element changes.
        """
        if IntunedContext is None or launch_chromium is None:
            pytest.skip("Runtime dependencies not available")

        mock_cache = MockCache()

        with patch("intuned_browser.ai.extract_structured_data.cache", mock_cache):
            with IntunedContext() as ctx:
                ctx.run_context = IntunedRunContext(  # type: ignore
                    job_id="test-dom-cache-invalid-before",
                    job_run_id="eb722252-e932-4658-ac35-c846ed5b4f44",
                    run_id="yyPCx2XF7Eu9nda",
                    auth_session_id=None,
                )
                async with launch_chromium(headless=True) as (_, page):
                    # Initial HTML with iframe containing data to extract
                    initial_html = """
                    <html>
                    <body>
                        <h1>Items Page</h1>
                        <iframe id="items-data" srcdoc='
                            <ul class="item-list">
                                <li class="item" data-id="target">
                                    <span class="title">Target Item</span>
                                    <span class="desc">This is the target item to extract</span>
                                </li>
                            </ul>
                        '></iframe>
                    </body>
                    </html>
                    """

                    await page.set_content(initial_html, wait_until="domcontentloaded")
                    await page.wait_for_timeout(500)

                    # First extraction
                    result1 = await extract_structured_data(
                        source=page,
                        data_schema=ListItem,
                        strategy="HTML",
                        prompt="Extract the item information",
                        enable_dom_matching=True,
                        enable_cache=True,
                        model="claude-haiku-4-5-20251001",
                    )

                    assert result1 is not None
                    result1 = ListItem(**result1)
                    assert result1.title.casefold() == "Target Item".casefold()
                    assert result1.description.casefold() == "This is the target item to extract".casefold()

                    # Modify HTML - add element BEFORE target inside iframe
                    # This changes the XPath to the target element
                    modified_html = """
                    <html>
                    <body>
                        <h1>Items Page</h1>
                        <iframe id="items-data" srcdoc='
                            <ul class="item-list">
                                <!-- NEW ELEMENT ADDED BEFORE TARGET -->
                                <li class="item" data-id="new">
                                    <span class="title">New Item</span>
                                    <span class="desc">This is a new item added before target</span>
                                </li>
                                <li class="item" data-id="target">
                                    <span class="title">Target Item</span>
                                    <span class="desc">This is the target item to extract</span>
                                </li>
                            </ul>
                        '></iframe>
                    </body>
                    </html>
                    """

                    await page.set_content(modified_html, wait_until="domcontentloaded")
                    await page.wait_for_timeout(500)

                    # Second extraction - should NOT use cache because XPath changed
                    result2 = await extract_structured_data(
                        source=page,
                        data_schema=ListItem,
                        strategy="HTML",
                        prompt="Extract the item information",
                        enable_dom_matching=True,
                        enable_cache=True,
                        model="claude-haiku-4-5-20251001",
                    )

                    assert result2 is not None
                    # The extraction should still find the target item
                    # (might find either one depending on prompt, but should not use cache)
                    result2 = ListItem(**result2)
                    assert result2.title.casefold() in ["Target Item".casefold(), "New Item".casefold()]

                    # Verify cache behavior with XPath invalidation
                    # First call: cache miss → AI extraction → result cached with XPath
                    # Second call: cache HIT → XPath validation FAILS (element moved) → AI re-extraction → new result cached
                    # Result: 2 get calls, 1 hit, 1 miss, 2 set calls
                    assert (
                        len(mock_cache.get_calls) == 2
                    ), f"Expected 2 cache get calls, got {len(mock_cache.get_calls)}"
                    assert (
                        len(mock_cache.set_calls) == 2
                    ), f"Expected 2 cache set calls, got {len(mock_cache.set_calls)}"
                    assert (
                        mock_cache.cache_hits == 1
                    ), f"Expected 1 cache hit (with failed validation), got {mock_cache.cache_hits}"
                    assert mock_cache.cache_misses == 1, f"Expected 1 cache miss, got {mock_cache.cache_misses}"

    @pytest.mark.asyncio
    async def test_cache_invalid_when_element_removed_before_target_in_iframe(self):
        """
        Test that cache is INVALID when an element is removed BEFORE the target element
        inside the iframe. The XPath to the extracted element changes.
        """
        if IntunedContext is None or launch_chromium is None:
            pytest.skip("Runtime dependencies not available")

        mock_cache = MockCache()

        with patch("intuned_browser.ai.extract_structured_data.cache", mock_cache):
            with IntunedContext() as ctx:
                ctx.run_context = IntunedRunContext(  # type: ignore
                    job_id="test-dom-cache-invalid-removed",
                    job_run_id="eb722252-e932-4658-ac35-c846ed5b4f44",
                    run_id="yyPCx2XF7Eu9nda",
                    auth_session_id=None,
                )
                async with launch_chromium(headless=True) as (_, page):
                    # Initial HTML with multiple items, target is second
                    initial_html = """
                    <html>
                    <body>
                        <iframe id="items-data" srcdoc='
                            <ul class="item-list">
                                <li class="item" data-id="first">
                                    <span class="title">First Item</span>
                                    <span class="desc">First item description</span>
                                </li>
                                <li class="item" data-id="target">
                                    <span class="title">Second Item (Target)</span>
                                    <span class="desc">Target item description</span>
                                </li>
                            </ul>
                        '></iframe>
                    </body>
                    </html>
                    """

                    await page.set_content(initial_html, wait_until="domcontentloaded")
                    await page.wait_for_timeout(500)

                    # First extraction - extract second item
                    result1 = await extract_structured_data(
                        source=page,
                        data_schema=ListItem,
                        strategy="HTML",
                        prompt="Extract the second item information (the target item)",
                        enable_dom_matching=True,
                        enable_cache=True,
                        model="claude-haiku-4-5-20251001",
                    )

                    assert result1 is not None
                    result1 = ListItem(**result1)
                    assert "Second Item" in result1.title or "Target" in result1.title

                    # Remove first item - this changes XPath of second item from li[2] to li[1]
                    modified_html = """
                    <html>
                    <body>
                        <iframe id="items-data" srcdoc='
                            <ul class="item-list">
                                <!-- FIRST ITEM REMOVED -->
                                <li class="item" data-id="target">
                                    <span class="title">Second Item (Target)</span>
                                    <span class="desc">Target item description</span>
                                </li>
                            </ul>
                        '></iframe>
                    </body>
                    </html>
                    """

                    await page.set_content(modified_html, wait_until="domcontentloaded")
                    await page.wait_for_timeout(500)

                    # Second extraction - should NOT use cache because XPath changed
                    result2 = await extract_structured_data(
                        source=page,
                        data_schema=ListItem,
                        strategy="HTML",
                        prompt="Extract the second item information (the target item)",
                        enable_dom_matching=True,
                        enable_cache=True,
                        model="claude-haiku-4-5-20251001",
                    )

                    assert result2 is not None
                    result2 = ListItem(**result2)
                    # Should still extract the same content, but not from cache
                    assert "Second Item" in result2.title or "Target" in result2.title

                    # Verify cache behavior with XPath invalidation (element removed, XPath changed)
                    # First call: cache miss → AI extraction → result cached with XPath
                    # Second call: cache HIT → XPath validation FAILS (li[2] → li[1]) → AI re-extraction → new result cached
                    # Result: 2 get calls, 1 hit, 1 miss, 2 set calls
                    assert (
                        len(mock_cache.get_calls) == 2
                    ), f"Expected 2 cache get calls, got {len(mock_cache.get_calls)}"
                    assert (
                        len(mock_cache.set_calls) == 2
                    ), f"Expected 2 cache set calls, got {len(mock_cache.set_calls)}"
                    assert (
                        mock_cache.cache_hits == 1
                    ), f"Expected 1 cache hit (with failed validation), got {mock_cache.cache_hits}"
                    assert mock_cache.cache_misses == 1, f"Expected 1 cache miss, got {mock_cache.cache_misses}"

    @pytest.mark.asyncio
    async def test_cache_valid_with_nested_iframes_and_trailing_elements(self):
        """
        Test cache validity with nested iframes when elements are added after the nested structure.
        XPath inside nested iframes should remain valid.
        """
        if IntunedContext is None or launch_chromium is None:
            pytest.skip("Runtime dependencies not available")

        mock_cache = MockCache()

        with patch("intuned_browser.ai.extract_structured_data.cache", mock_cache):
            with IntunedContext() as ctx:
                ctx.run_context = IntunedRunContext(  # type: ignore
                    job_id="test-dom-cache-nested",
                    job_run_id="test-run-004",
                    run_id="cache_valid_nested_trailing",
                    auth_session_id=None,
                )
                async with launch_chromium(headless=True) as (_, page):
                    # Initial HTML with nested iframes
                    initial_html = """
                    <html>
                    <body>
                    <h1>Nested Iframe Test</h1>
                    <iframe id="outer" srcdoc='
                        <div class="outer-container">
                            <h2>Outer Frame</h2>
                            <iframe id="inner" srcdoc="
                                <ul class=&quot;product-list&quot;>
                                    <li class=&quot;product&quot;>
                                        <span class=&quot;name&quot;>Nested Product</span>
                                        <span class=&quot;price&quot;>$599</span>
                                        <span class=&quot;stock&quot;>Available</span>
                                    </li>
                                </ul>
                            "></iframe>
                        </div>
                    '></iframe>
                    </body>
                    </html>
                    """

                    await page.set_content(initial_html, wait_until="domcontentloaded")
                    await page.wait_for_timeout(1000)  # Extra time for nested iframe

                    # First extraction from nested iframe
                    result1 = await extract_structured_data(
                        source=page,
                        data_schema=ProductData,
                        strategy="HTML",
                        prompt="Extract the product information from the nested iframe",
                        enable_dom_matching=True,
                        enable_cache=True,
                        model="claude-haiku-4-5-20251001",
                    )

                    assert result1 is not None
                    result1 = ProductData(**result1)
                    assert result1.name == "Nested Product"
                    assert result1.price == "$599"

                    # Add element AFTER nested iframe structure
                    modified_html = """
                    <html>
                    <body>
                    <h1>Nested Iframe Test</h1>
                    <iframe id="outer" srcdoc='
                        <div class="outer-container">
                            <h2>Outer Frame</h2>
                            <iframe id="inner" srcdoc="
                                <ul class=&quot;product-list&quot;>
                                    <li class=&quot;product&quot;>
                                        <span class=&quot;name&quot;>Nested Product</span>
                                        <span class=&quot;price&quot;>$599</span>
                                        <span class=&quot;stock&quot;>Available</span>
                                    </li>
                                </ul>
                            "></iframe>
                        </div>
                    '></iframe>
                    <!-- NEW FOOTER ADDED AFTER ENTIRE NESTED STRUCTURE -->
                    <footer>
                        <p>Footer after nested iframes</p>
                    </footer>
                    </body>
                    </html>
                    """

                    await page.set_content(modified_html, wait_until="domcontentloaded")
                    await page.wait_for_timeout(1000)

                    # Second extraction - should use cache (XPath inside nested iframe unchanged)
                    result2 = await extract_structured_data(
                        source=page,
                        data_schema=ProductData,
                        strategy="HTML",
                        prompt="Extract the product information from the nested iframe",
                        enable_dom_matching=True,
                        enable_cache=True,
                        model="claude-haiku-4-5-20251001",
                    )

                    assert result2 is not None
                    result2 = ProductData(**result2)
                    assert result2.model_dump() == result1.model_dump()

                    # Cache valid - XPath inside nested iframe unchanged after adding trailing element
                    assert len(mock_cache.get_calls) == 2, f"Expected 2 get calls, got {len(mock_cache.get_calls)}"
                    assert len(mock_cache.set_calls) == 1, f"Expected 1 set call, got {len(mock_cache.set_calls)}"
                    assert mock_cache.cache_hits == 1, f"Expected 1 cache hit, got {mock_cache.cache_hits}"
                    assert mock_cache.cache_misses == 1, f"Expected 1 cache miss, got {mock_cache.cache_misses}"

    @pytest.mark.asyncio
    async def test_cache_with_markdown_strategy_and_iframes(self):
        """
        Test DOM matching and caching with MARKDOWN strategy and iframes.
        """
        if IntunedContext is None or launch_chromium is None:
            pytest.skip("Runtime dependencies not available")

        mock_cache = MockCache()

        with patch("intuned_browser.ai.extract_structured_data.cache", mock_cache):
            with IntunedContext() as ctx:
                ctx.run_context = IntunedRunContext(  # type: ignore
                    job_id="test-dom-cache-markdown",
                    job_run_id="test-run-005",
                    run_id="cache_markdown_strategy",
                    auth_session_id=None,
                )
                async with launch_chromium(headless=True) as (_, page):
                    initial_html = """
                    <html>
                    <body>
                    <article>
                        <h1>Article Title</h1>
                        <iframe id="content" srcdoc='
                            <div class="article-content">
                                <p class="highlight">
                                    <strong class="title">Key Point</strong>
                                    <span class="desc">Important information here</span>
                                </p>
                            </div>
                        '></iframe>
                    </article>
                    </body>
                    </html>
                    """

                    await page.set_content(initial_html, wait_until="domcontentloaded")
                    await page.wait_for_timeout(500)

                    # First extraction with MARKDOWN strategy
                    result1 = await extract_structured_data(
                        source=page,
                        data_schema=ListItem,
                        strategy="MARKDOWN",
                        prompt="Extract the title and description from the highlighted paragraph.",
                        enable_dom_matching=True,
                        enable_cache=True,
                        model="claude-haiku-4-5-20251001",
                    )

                    assert result1 is not None
                    result1 = ListItem(**result1)
                    # AI should extract content from the highlighted paragraph inside the iframe
                    assert "Article Title".casefold() in result1.title.casefold()
                    assert "Important information".casefold() in result1.description.casefold()

                    # Add element after iframe
                    modified_html = """
                    <html>
                    <body>
                    <article>
                        <h1>Article Title</h1>
                        <iframe id="content" srcdoc='
                            <div class="article-content">
                                <p class="highlight">
                                    <strong class="title">Key Point</strong>
                                    <span class="desc">Important information here</span>
                                </p>
                            </div>
                        '></iframe>
                    </article>
                    <aside>Related articles</aside>
                    </body>
                    </html>
                    """

                    await page.set_content(modified_html, wait_until="domcontentloaded")
                    await page.wait_for_timeout(500)

                    # Should use cache
                    result2 = await extract_structured_data(
                        source=page,
                        data_schema=ListItem,
                        strategy="MARKDOWN",
                        prompt="Extract the title and description from the highlighted paragraph.",
                        enable_dom_matching=True,
                        enable_cache=True,
                        model="claude-haiku-4-5-20251001",
                    )

                    assert result2 is not None
                    result2 = ListItem(**result2)
                    assert result2.model_dump() == result1.model_dump()

                    # Cache valid with MARKDOWN strategy - XPath unchanged after adding trailing element
                    assert len(mock_cache.get_calls) == 2, f"Expected 2 get calls, got {len(mock_cache.get_calls)}"
                    assert len(mock_cache.set_calls) == 1, f"Expected 1 set call, got {len(mock_cache.set_calls)}"
                    assert mock_cache.cache_hits == 1, f"Expected 1 cache hit, got {mock_cache.cache_hits}"
                    assert mock_cache.cache_misses == 1, f"Expected 1 cache miss, got {mock_cache.cache_misses}"
