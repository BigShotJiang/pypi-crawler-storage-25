import pytest
from _intuned_runtime_internal import launch_chromium

from intuned_browser.ai.utils.matching.matching import create_matches_mapping

# Test HTML templates
SIMPLE_PRODUCT_HTML = """
<html>
<body>
  <div class="product">
    <h2 class="title">iPhone 14 Pro</h2>
    <div class="price">$999</div>
    <div class="stock">In Stock</div>
  </div>
</body>
</html>
"""

MULTIPLE_PRODUCTS_HTML = """
<html>
<body>
  <div class="product" id="p1">
    <h2 class="title">iPhone 14 Pro</h2>
    <div class="price">$999</div>
  </div>
  <div class="product" id="p2">
    <h2 class="title">MacBook Air M2</h2>
    <div class="price">$1199</div>
  </div>
</body>
</html>
"""

PRODUCT_WITH_IFRAME_HTML = """
<html>
<body>
  <div class="product">
    <h2 class="title">iPhone 14 Pro</h2>
    <div class="price">$999</div>
  </div>
  <iframe id="details-frame" srcdoc='
    <html>
      <body>
        <div class="stock">In Stock</div>
        <div class="rating">4.5 stars</div>
      </body>
    </html>
  '></iframe>
</body>
</html>
"""

DUPLICATE_TEXT_HTML = """
<html>
<body>
  <div class="header">
    <span class="price">$999</span>
  </div>
  <div class="product">
    <h2 class="title">iPhone 14 Pro</h2>
    <div class="price">$999</div>
  </div>
  <div class="footer">
    <span class="disclaimer">Starting at $999</span>
  </div>
</body>
</html>
"""


class TestCreateMatchesMapping:
    """Test create_matches_mapping functionality."""

    @pytest.mark.asyncio
    async def test_create_mapping_for_dict_data(self):
        """Test creating matches mapping for dictionary extraction data."""

        async with launch_chromium(headless=True) as (_, page):
            await page.set_content(SIMPLE_PRODUCT_HTML)

            extracted_data = {
                "title": "iPhone 14 Pro",
                "price": "$999",
                "stock": "In Stock",
            }

            mapping = await create_matches_mapping(page, extracted_data)

            # Should have mappings for all extracted values
            assert "iPhone 14 Pro" in mapping
            assert "$999" in mapping
            assert "In Stock" in mapping

            # Each mapping should be a list of match results
            for _value, matches in mapping.items():
                assert isinstance(matches, list)
                assert len(matches) > 0

                # Each match should have xpath and matched_value
                for match in matches:
                    assert "xpath" in match
                    assert "matched_value" in match
                    assert isinstance(match["xpath"], str)
                    assert isinstance(match["matched_value"], str)

            # Verify specific matched values
            assert mapping["iPhone 14 Pro"][0]["matched_value"] == "iPhone 14 Pro"
            assert mapping["$999"][0]["matched_value"] == "$999"
            assert mapping["In Stock"][0]["matched_value"] == "In Stock"

    @pytest.mark.asyncio
    async def test_create_mapping_for_list_of_strings(self):
        """Test creating matches mapping for list of strings."""

        async with launch_chromium(headless=True) as (_, page):
            await page.set_content(SIMPLE_PRODUCT_HTML)

            extracted_data = ["iPhone 14 Pro", "$999", "In Stock"]

            mapping = await create_matches_mapping(page, extracted_data)

            # Should have mappings for all strings
            assert len(mapping) == 3
            assert "iPhone 14 Pro" in mapping
            assert "$999" in mapping
            assert "In Stock" in mapping

            # Verify matched values are correct
            assert mapping["iPhone 14 Pro"][0]["matched_value"] == "iPhone 14 Pro"
            assert mapping["$999"][0]["matched_value"] == "$999"

    @pytest.mark.asyncio
    async def test_create_mapping_for_list_of_dicts(self):
        """Test creating matches mapping for list of dictionaries."""

        async with launch_chromium(headless=True) as (_, page):
            await page.set_content(MULTIPLE_PRODUCTS_HTML)

            extracted_data = [
                {"title": "iPhone 14 Pro", "price": "$999"},
                {"title": "MacBook Air M2", "price": "$1199"},
            ]

            mapping = await create_matches_mapping(page, extracted_data)

            # Should have mappings for all unique values
            assert "iPhone 14 Pro" in mapping
            assert "$999" in mapping
            assert "MacBook Air M2" in mapping
            assert "$1199" in mapping

            # Verify each unique value has at least one match
            assert len(mapping["iPhone 14 Pro"]) >= 1
            assert len(mapping["MacBook Air M2"]) >= 1
            # Verify matched values are correct
            assert mapping["iPhone 14 Pro"][0]["matched_value"] == "iPhone 14 Pro"
            assert mapping["MacBook Air M2"][0]["matched_value"] == "MacBook Air M2"

    @pytest.mark.asyncio
    async def test_create_mapping_with_iframe_content(self):
        """Test that mapping includes matches from iframe content."""

        async with launch_chromium(headless=True) as (_, page):
            await page.set_content(PRODUCT_WITH_IFRAME_HTML)
            await page.wait_for_selector("#details-frame")

            extracted_data = {
                "title": "iPhone 14 Pro",
                "price": "$999",
                "stock": "In Stock",
                "rating": "4.5 stars",
            }

            mapping = await create_matches_mapping(page, extracted_data)

            # Main content should be found
            assert "iPhone 14 Pro" in mapping
            assert "$999" in mapping

            # Iframe content should also be found
            assert "In Stock" in mapping
            assert "4.5 stars" in mapping

            # Verify iframe content has matches
            assert len(mapping["In Stock"]) > 0
            assert len(mapping["4.5 stars"]) > 0

            # Verify matched values from iframe are correct
            assert mapping["In Stock"][0]["matched_value"] == "In Stock"
            assert mapping["4.5 stars"][0]["matched_value"] == "4.5 stars"

    @pytest.mark.asyncio
    async def test_create_mapping_with_duplicate_text(self):
        """Test that mapping correctly handles duplicate text in multiple locations."""

        async with launch_chromium(headless=True) as (_, page):
            await page.set_content(DUPLICATE_TEXT_HTML)

            extracted_data = {
                "title": "iPhone 14 Pro",
                "price": "$999",
            }

            mapping = await create_matches_mapping(page, extracted_data)

            # $999 appears multiple times in the page
            assert "$999" in mapping

            # Should have multiple matches for $999
            price_matches = mapping["$999"]
            # At least 2 matches (header and product sections)
            assert len(price_matches) >= 2

            # Get unique xpaths - some might be duplicated by the matching function
            xpaths = [match["xpath"] for match in price_matches]
            unique_xpaths = set(xpaths)
            # Should have at least 2 different xpaths (header, product, maybe footer)
            assert len(unique_xpaths) >= 2

            # All matches should have the same matched_value
            assert all(match["matched_value"] == "$999" for match in price_matches)
            # All xpaths should be non-empty
            assert all(len(match["xpath"]) > 0 for match in price_matches)

    @pytest.mark.asyncio
    async def test_create_mapping_with_empty_data(self):
        """Test creating mapping with empty extraction data."""

        async with launch_chromium(headless=True) as (_, page):
            await page.set_content(SIMPLE_PRODUCT_HTML)

            # Empty dict
            mapping = await create_matches_mapping(page, {})
            assert mapping == {}
            assert len(mapping) == 0

            # Empty list
            mapping = await create_matches_mapping(page, [])
            assert mapping == {}
            assert len(mapping) == 0

    @pytest.mark.asyncio
    async def test_mapping_structure_consistency(self):
        """Test that mapping structure is consistent across different data types."""

        async with launch_chromium(headless=True) as (_, page):
            await page.set_content(SIMPLE_PRODUCT_HTML)

            # Test with dict
            dict_data = {"title": "iPhone 14 Pro"}
            dict_mapping = await create_matches_mapping(page, dict_data)

            # Test with list of strings
            list_data = ["iPhone 14 Pro"]
            list_mapping = await create_matches_mapping(page, list_data)

            # Both should have same structure for "iPhone 14 Pro"
            assert "iPhone 14 Pro" in dict_mapping
            assert "iPhone 14 Pro" in list_mapping

            # Structure should be identical
            dict_matches = dict_mapping["iPhone 14 Pro"]
            list_matches = list_mapping["iPhone 14 Pro"]

            assert len(dict_matches) == len(list_matches)
            for i, match in enumerate(dict_matches):
                assert match["xpath"] == list_matches[i]["xpath"]
                assert match["matched_value"] == list_matches[i]["matched_value"]

            # Verify matched values are "iPhone 14 Pro"
            assert dict_matches[0]["matched_value"] == "iPhone 14 Pro"
            assert list_matches[0]["matched_value"] == "iPhone 14 Pro"
