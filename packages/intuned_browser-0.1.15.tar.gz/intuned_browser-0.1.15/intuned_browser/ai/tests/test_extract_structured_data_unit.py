import logging
from typing import Any
from unittest.mock import AsyncMock
from unittest.mock import patch

import pytest

# only run if runtime is avaliable because it is an optional dependency
try:
    from _intuned_runtime_internal import launch_chromium

except ImportError:
    launch_chromium = None
    logging.warning("Runtime dependencies are not available. Some test features will be disabled.")

from intuned_browser.ai.extract_structured_data import extract_structured_data
from intuned_browser.ai.types import ExtractDataOutput

PRODUCT_TEMPLATE = """
<html>
<body>
  <div class="product">
    <h2 class="title">iPhone 14 Pro</h2>
    <div class="price">$999</div>
    <div class="stock">In Stock</div>
  </div>
</body>
</html>
"""

PRODUCT_TEMPLATE_WITH_IFRAME = """
<html>
<body>
  <div class="product">
    <h2 class="title">iPhone 14 Pro</h2>
    <div class="price">$999</div>
  </div>
  <iframe id="details-frame" srcdoc='
    <html>
      <body>
        <div class="stock">In Stock</div>
        <div class="extra">Extra Info</div>
      </body>
    </html>
  '></iframe>
</body>
</html>
"""

PRODUCT_TEMPLATE_WITH_FOOTER = """
<html>
<body>
  <div class="product">
    <h2 class="title">iPhone 14 Pro</h2>
    <div class="price">$999</div>
    <div class="stock">In Stock</div>
  </div>
  <footer>
    <div class="copyright">© 2024 Store</div>
  </footer>
</body>
</html>
"""

PRODUCT_TEMPLATE_WITH_HEADER = """
<html>
<body>
  <header>
    <div class="new-banner">New Item!</div>
  </header>
  <div class="product">
    <h2 class="title">iPhone 14 Pro</h2>
    <div class="price">$999</div>
    <div class="stock">In Stock</div>
  </div>
</body>
</html>
"""

PRODUCT_TEMPLATE_MODIFIED = """
<html>
<body>
  <div class="product">
    <h2 class="title">iPhone 15 Pro</h2>
    <div class="price">$1099</div>
    <div class="stock">In Stock</div>
  </div>
</body>
</html>
"""

logger = logging.getLogger(__name__)


class MockCache:
    """Mock cache that tracks get/set calls."""

    def __init__(self):
        self.storage: dict[str, Any] = {}
        self.get_calls: list[str] = []
        self.set_calls: list[tuple[str, Any]] = []

    async def get(self, key: str) -> Any:
        """Get value from cache and track the call."""
        self.get_calls.append(key)
        return self.storage.get(key)

    async def set(self, key: str, value: Any) -> None:
        """Set value in cache and track the call."""
        self.set_calls.append((key, value))
        self.storage[key] = value

    def reset_tracking(self):
        """Reset call tracking (but keep storage)."""
        self.get_calls = []
        self.set_calls = []

    def clear(self):
        """Clear all storage and tracking."""
        self.storage = {}
        self.get_calls = []
        self.set_calls = []


# Global mock cache instance
mock_cache = MockCache()


@pytest.fixture(autouse=True)
def reset_mock_cache():
    """Reset mock cache before each test."""
    mock_cache.clear()
    yield
    mock_cache.clear()


def create_mock_ai_extraction(extracted_data: dict[str, Any]) -> AsyncMock:
    """
    Create a mock AI extraction function that returns the specified data.

    Args:
        extracted_data: The data to return from the mock extraction

    Returns:
        AsyncMock configured to return ExtractDataOutput with the provided data
    """
    mock = AsyncMock(return_value=ExtractDataOutput(extracted_data=extracted_data))
    return mock


@pytest.mark.asyncio
async def test_cache_miss_then_hit():
    """Test that first call misses cache, second call hits it."""
    async with launch_chromium(headless=True) as (_, page):
        await page.set_content(PRODUCT_TEMPLATE)

        schema = {
            "type": "object",
            "properties": {
                "title": {"type": "string"},
                "price": {"type": "string"},
            },
            "required": ["title", "price"],
        }

        # Mock AI to return specific product data
        mock_ai = create_mock_ai_extraction({"title": "iPhone 14 Pro", "price": "$999"})

        with patch("intuned_browser.ai.extract_structured_data.cache", mock_cache):
            with patch(
                "intuned_browser.ai.extract_structured_data.extract_structured_data_using_ai",
                mock_ai,
            ):
                # First extraction - should miss cache
                result1 = await extract_structured_data(
                    source=page,
                    data_schema=schema,
                    prompt="Extract product data",
                    strategy="HTML",
                    enable_dom_matching=False,
                    enable_cache=True,
                )

                assert result1["title"] == "iPhone 14 Pro"
                assert result1["price"] == "$999"
                assert len(mock_cache.get_calls) == 1  # Cache miss
                assert len(mock_cache.set_calls) == 1  # Cache set

                mock_cache.reset_tracking()

                # Second extraction with same params - should hit cache
                result2 = await extract_structured_data(
                    source=page,
                    data_schema=schema,
                    prompt="Extract product data",
                    strategy="HTML",
                    enable_dom_matching=False,
                    enable_cache=True,
                )

                assert result2 == result1
                assert len(mock_cache.get_calls) == 1  # Cache hit
                assert len(mock_cache.set_calls) == 0  # No new cache set


@pytest.mark.asyncio
async def test_dom_matching_creates_xpath_mapping():
    """Test that enabling DOM matching creates xpath mapping in cache."""
    async with launch_chromium(headless=True) as (_, page):
        await page.set_content(PRODUCT_TEMPLATE)

        schema = {
            "type": "object",
            "properties": {
                "title": {"type": "string"},
                "price": {"type": "string"},
            },
            "required": ["title", "price"],
        }

        # Mock AI to return specific product data
        mock_ai = create_mock_ai_extraction({"title": "iPhone 14 Pro", "price": "$999"})

        with patch("intuned_browser.ai.extract_structured_data.cache", mock_cache):
            with patch(
                "intuned_browser.ai.extract_structured_data.extract_structured_data_using_ai",
                mock_ai,
            ):
                result = await extract_structured_data(
                    source=page,
                    data_schema=schema,
                    prompt="Extract product data",
                    strategy="HTML",
                    enable_dom_matching=True,
                    enable_cache=True,
                )

                assert result["title"] == "iPhone 14 Pro"
                assert result["price"] == "$999"

                # Check that cache contains xpath mapping
                assert len(mock_cache.set_calls) == 1
                cached_value = mock_cache.set_calls[0][1]

                assert isinstance(cached_value, dict)
                assert "result" in cached_value
                assert "matchesMapping" in cached_value
                assert cached_value["result"] == result

                # Check xpath mapping structure
                matches_mapping = cached_value["matchesMapping"]
                assert isinstance(matches_mapping, dict)

                # Should have xpaths for extracted values
                assert "iPhone 14 Pro" in matches_mapping
                assert "$999" in matches_mapping

                # Each value should map to a list of xpaths
                for _value, xpaths in matches_mapping.items():
                    assert isinstance(xpaths, list)
                    assert len(xpaths) > 0
                    for xpath in xpaths:
                        assert isinstance(xpath, dict)


@pytest.mark.asyncio
async def test_xpath_validation_on_cache_hit():
    """Test that cached xpath mapping is validated on cache hit."""
    async with launch_chromium(headless=True) as (_, page):
        await page.set_content(PRODUCT_TEMPLATE)

        schema = {
            "type": "object",
            "properties": {
                "title": {"type": "string"},
                "price": {"type": "string"},
            },
            "required": ["title", "price"],
        }

        # Mock AI to return specific product data
        mock_ai = create_mock_ai_extraction({"title": "iPhone 14 Pro", "price": "$999"})

        with patch("intuned_browser.ai.extract_structured_data.cache", mock_cache):
            with patch(
                "intuned_browser.ai.extract_structured_data.extract_structured_data_using_ai",
                mock_ai,
            ):
                # First extraction - creates cache
                result1 = await extract_structured_data(
                    source=page,
                    data_schema=schema,
                    prompt="Extract product data",
                    strategy="HTML",
                    enable_dom_matching=True,
                    enable_cache=True,
                )

                mock_cache.reset_tracking()

                # Second extraction - should validate xpath and return cached result
                result2 = await extract_structured_data(
                    source=page,
                    data_schema=schema,
                    prompt="Extract product data",
                    strategy="HTML",
                    enable_dom_matching=True,
                    enable_cache=True,
                )

                assert result2 == result1
                assert len(mock_cache.get_calls) == 1  # Cache hit


@pytest.mark.asyncio
async def test_cache_invalidation_on_content_change():
    """Test that cache is invalidated when element content changes."""
    async with launch_chromium(headless=True) as (_, page):
        await page.set_content(PRODUCT_TEMPLATE)

        schema = {
            "type": "object",
            "properties": {
                "title": {"type": "string"},
                "price": {"type": "string"},
            },
            "required": ["title", "price"],
        }

        # First mock: return iPhone 14 Pro data
        mock_ai_first = create_mock_ai_extraction({"title": "iPhone 14 Pro", "price": "$999"})

        # Second mock: return iPhone 15 Pro data (after content changes)
        mock_ai_second = create_mock_ai_extraction({"title": "iPhone 15 Pro", "price": "$1099"})

        with patch("intuned_browser.ai.extract_structured_data.cache", mock_cache):
            with patch(
                "intuned_browser.ai.extract_structured_data.extract_structured_data_using_ai",
                mock_ai_first,
            ):
                # First extraction
                result1 = await extract_structured_data(
                    source=page,
                    data_schema=schema,
                    prompt="Extract product data",
                    strategy="HTML",
                    enable_dom_matching=True,
                    enable_cache=True,
                )

                assert result1["title"] == "iPhone 14 Pro"
                assert result1["price"] == "$999"

                mock_cache.reset_tracking()

            # Modify content - this should invalidate cache
            await page.set_content(PRODUCT_TEMPLATE_MODIFIED)

            with patch(
                "intuned_browser.ai.extract_structured_data.extract_structured_data_using_ai",
                mock_ai_second,
            ):
                # Second extraction - xpath validation should fail, new extraction needed
                result2 = await extract_structured_data(
                    source=page,
                    data_schema=schema,
                    prompt="Extract product data",
                    strategy="HTML",
                    enable_dom_matching=True,
                    enable_cache=True,
                )

                assert result2["title"] == "iPhone 15 Pro"
                assert result2["price"] == "$1099"
                assert result2 != result1

                # Should have made a new extraction and cache set
                assert len(mock_cache.set_calls) == 1


@pytest.mark.asyncio
async def test_irrelevant_dom_changes_dont_invalidate_cache():
    """Test that adding irrelevant elements (footer) doesn't invalidate cache."""
    async with launch_chromium(headless=True) as (_, page):
        await page.set_content(PRODUCT_TEMPLATE)

        schema = {
            "type": "object",
            "properties": {
                "title": {"type": "string"},
                "price": {"type": "string"},
            },
            "required": ["title", "price"],
        }

        # Mock AI to return same product data for both calls
        mock_ai = create_mock_ai_extraction({"title": "iPhone 14 Pro", "price": "$999"})

        with patch("intuned_browser.ai.extract_structured_data.cache", mock_cache):
            with patch(
                "intuned_browser.ai.extract_structured_data.extract_structured_data_using_ai",
                mock_ai,
            ):
                # First extraction
                result1 = await extract_structured_data(
                    source=page,
                    data_schema=schema,
                    prompt="Extract product data",
                    strategy="HTML",
                    enable_dom_matching=True,
                    enable_cache=True,
                )

                mock_cache.reset_tracking()

                # Add footer (irrelevant element at bottom)
                await page.set_content(PRODUCT_TEMPLATE_WITH_FOOTER)

                # Second extraction - should still use cache since product data unchanged
                result2 = await extract_structured_data(
                    source=page,
                    data_schema=schema,
                    prompt="Extract product data",
                    strategy="HTML",
                    enable_dom_matching=True,
                    enable_cache=True,
                )

                assert result2 == result1
                assert len(mock_cache.get_calls) == 1  # Cache hit
                # Xpath should still be valid since product elements unchanged


@pytest.mark.asyncio
async def test_header_addition_affects_xpath():
    """Test that adding element at top invalidates cache due to xpath change."""
    async with launch_chromium(headless=True) as (_, page):
        await page.set_content(PRODUCT_TEMPLATE)

        schema = {
            "type": "object",
            "properties": {
                "title": {"type": "string"},
                "price": {"type": "string"},
            },
            "required": ["title", "price"],
        }

        # Mock AI to return same product data for both calls
        mock_ai = create_mock_ai_extraction({"title": "iPhone 14 Pro", "price": "$999"})

        with patch("intuned_browser.ai.extract_structured_data.cache", mock_cache):
            with patch(
                "intuned_browser.ai.extract_structured_data.extract_structured_data_using_ai",
                mock_ai,
            ):
                # First extraction
                result1 = await extract_structured_data(
                    source=page,
                    data_schema=schema,
                    prompt="Extract product data",
                    strategy="HTML",
                    enable_dom_matching=True,
                    enable_cache=True,
                )

                mock_cache.reset_tracking()

                # Add header (element at top might change xpaths)
                await page.set_content(PRODUCT_TEMPLATE_WITH_HEADER)

                # Second extraction - xpaths may have changed
                result2 = await extract_structured_data(
                    source=page,
                    data_schema=schema,
                    prompt="Extract product data",
                    strategy="HTML",
                    enable_dom_matching=True,
                    enable_cache=True,
                )

                # Content is same so results should match
                assert result2["title"] == result1["title"]
                assert result2["price"] == result1["price"]


@pytest.mark.asyncio
async def test_cache_with_iframe_elements():
    """Test xpath mapping works with elements inside iframes."""
    async with launch_chromium(headless=True) as (_, page):
        await page.set_content(PRODUCT_TEMPLATE_WITH_IFRAME)

        # Wait for iframe to load
        await page.wait_for_selector("#details-frame")

        schema = {
            "type": "object",
            "properties": {
                "title": {"type": "string"},
                "price": {"type": "string"},
                "stock": {"type": "string"},
            },
            "required": ["title", "price", "stock"],
        }

        # Mock AI to return product data including iframe content
        mock_ai = create_mock_ai_extraction({"title": "iPhone 14 Pro", "price": "$999", "stock": "In Stock"})

        with patch("intuned_browser.ai.extract_structured_data.cache", mock_cache):
            with patch(
                "intuned_browser.ai.extract_structured_data.extract_structured_data_using_ai",
                mock_ai,
            ):
                # First extraction - should extract from both main page and iframe
                result1 = await extract_structured_data(
                    source=page,
                    data_schema=schema,
                    prompt="Extract product data",
                    strategy="HTML",
                    enable_dom_matching=True,
                    enable_cache=True,
                )

                assert result1["title"] == "iPhone 14 Pro"
                assert result1["price"] == "$999"
                assert result1["stock"] == "In Stock"

                # Check xpath mapping includes iframe elements
                cached_value = mock_cache.set_calls[0][1]
                matches_mapping = cached_value["matchesMapping"]

                # Stock is in iframe, should have xpath
                assert "In Stock" in matches_mapping


@pytest.mark.asyncio
async def test_iframe_content_change_invalidates_cache():
    """Test that changing iframe content invalidates cache properly."""
    async with launch_chromium(headless=True) as (_, page):
        iframe_html_v1 = """
        <html>
        <body>
            <div class="product">
            <h2 class="title">iPhone 14 Pro</h2>
            <div class="price">$999</div>
            </div>
            <iframe id="details-frame" srcdoc='
            <html>
                <body>
                <div class="stock">In Stock</div>
                </body>
            </html>
            '></iframe>
        </body>
        </html>
        """

        iframe_html_v2 = """
        <html>
        <body>
            <div class="product">
            <h2 class="title">iPhone 14 Pro</h2>
            <div class="price">$999</div>
            </div>
            <iframe id="details-frame" srcdoc='
            <html>
                <body>
                <div class="stock">Out of Stock</div>
                </body>
            </html>
            '></iframe>
        </body>
        </html>
        """

        await page.set_content(iframe_html_v1)
        await page.wait_for_selector("#details-frame")

        schema = {
            "type": "object",
            "properties": {
                "title": {"type": "string"},
                "price": {"type": "string"},
                "stock": {"type": "string"},
            },
            "required": ["title", "price", "stock"],
        }

        # First mock: In Stock
        mock_ai_first = create_mock_ai_extraction({"title": "iPhone 14 Pro", "price": "$999", "stock": "In Stock"})

        # Second mock: Out of Stock
        mock_ai_second = create_mock_ai_extraction({"title": "iPhone 14 Pro", "price": "$999", "stock": "Out of Stock"})

        with patch("intuned_browser.ai.extract_structured_data.cache", mock_cache):
            with patch(
                "intuned_browser.ai.extract_structured_data.extract_structured_data_using_ai",
                mock_ai_first,
            ):
                # First extraction
                result1 = await extract_structured_data(
                    source=page,
                    data_schema=schema,
                    prompt="Extract product data",
                    strategy="HTML",
                    enable_dom_matching=True,
                    enable_cache=True,
                )

                assert result1["stock"] == "In Stock"

                mock_cache.reset_tracking()

            # Change iframe content
            await page.set_content(iframe_html_v2)
            await page.wait_for_selector("#details-frame")

            with patch(
                "intuned_browser.ai.extract_structured_data.extract_structured_data_using_ai",
                mock_ai_second,
            ):
                # Second extraction - should detect change in iframe
                result2 = await extract_structured_data(
                    source=page,
                    data_schema=schema,
                    prompt="Extract product data",
                    strategy="HTML",
                    enable_dom_matching=True,
                    enable_cache=True,
                )

                assert result2["stock"] == "Out of Stock"
                assert result2 != result1


@pytest.mark.asyncio
async def test_cache_disabled():
    """Test that disabling cache prevents caching."""
    async with launch_chromium(headless=True) as (_, page):
        await page.set_content(PRODUCT_TEMPLATE)

        schema = {
            "type": "object",
            "properties": {
                "title": {"type": "string"},
                "price": {"type": "string"},
            },
            "required": ["title", "price"],
        }

        # Mock AI to return product data
        mock_ai = create_mock_ai_extraction({"title": "iPhone 14 Pro", "price": "$999"})

        with patch("intuned_browser.ai.extract_structured_data.cache", mock_cache):
            with patch(
                "intuned_browser.ai.extract_structured_data.extract_structured_data_using_ai",
                mock_ai,
            ):
                # First extraction with cache disabled
                result1 = await extract_structured_data(
                    source=page,
                    data_schema=schema,
                    prompt="Extract product data",
                    strategy="HTML",
                    enable_dom_matching=False,
                    enable_cache=False,
                )

                assert result1["title"] == "iPhone 14 Pro"
                assert len(mock_cache.get_calls) == 0  # No cache get
                assert len(mock_cache.set_calls) == 0  # No cache set

                # Second extraction with cache disabled
                result2 = await extract_structured_data(
                    source=page,
                    data_schema=schema,
                    prompt="Extract product data",
                    strategy="HTML",
                    enable_dom_matching=False,
                    enable_cache=False,
                )

                assert result2 == result1
                assert len(mock_cache.get_calls) == 0  # Still no cache operations
                assert len(mock_cache.set_calls) == 0


@pytest.mark.asyncio
async def test_different_prompts_create_different_cache_keys():
    """Test that different prompts result in different cache entries."""
    async with launch_chromium(headless=True) as (_, page):
        await page.set_content(PRODUCT_TEMPLATE)

        schema = {
            "type": "object",
            "properties": {
                "title": {"type": "string"},
                "price": {"type": "string"},
            },
            "required": ["title", "price"],
        }

        # Mock AI to return product data
        mock_ai = create_mock_ai_extraction({"title": "iPhone 14 Pro", "price": "$999"})

        with patch("intuned_browser.ai.extract_structured_data.cache", mock_cache):
            with patch(
                "intuned_browser.ai.extract_structured_data.extract_structured_data_using_ai",
                mock_ai,
            ):
                # First extraction with prompt A
                await extract_structured_data(
                    source=page,
                    data_schema=schema,
                    prompt="Extract product data carefully",
                    strategy="HTML",
                    enable_dom_matching=False,
                    enable_cache=True,
                )

                first_cache_key = mock_cache.set_calls[0][0]
                mock_cache.reset_tracking()

                # Second extraction with prompt B
                await extract_structured_data(
                    source=page,
                    data_schema=schema,
                    prompt="Extract product information quickly",
                    strategy="HTML",
                    enable_dom_matching=False,
                    enable_cache=True,
                )

                # Should create new cache entry with different key
                assert len(mock_cache.get_calls) == 1  # Cache miss
                assert len(mock_cache.set_calls) == 1  # New cache set

                second_cache_key = mock_cache.set_calls[0][0]
                assert first_cache_key != second_cache_key


@pytest.mark.asyncio
async def test_cache_tracks_multiple_operations():
    """Test that cache correctly tracks multiple get/set operations."""
    async with launch_chromium(headless=True) as (_, page):
        await page.set_content(PRODUCT_TEMPLATE)

        schema = {
            "type": "object",
            "properties": {
                "title": {"type": "string"},
            },
            "required": ["title"],
        }

        # Mock AI to return product data
        mock_ai = create_mock_ai_extraction({"title": "iPhone 14 Pro"})

        with patch("intuned_browser.ai.extract_structured_data.cache", mock_cache):
            with patch(
                "intuned_browser.ai.extract_structured_data.extract_structured_data_using_ai",
                mock_ai,
            ):
                # Call 1: Cache miss + set
                await extract_structured_data(
                    source=page,
                    data_schema=schema,
                    prompt="Prompt 1",
                    strategy="HTML",
                    enable_cache=True,
                )

                assert len(mock_cache.get_calls) == 1
                assert len(mock_cache.set_calls) == 1

                # Call 2: Cache hit (same prompt)
                await extract_structured_data(
                    source=page,
                    data_schema=schema,
                    prompt="Prompt 1",
                    strategy="HTML",
                    enable_cache=True,
                )

                assert len(mock_cache.get_calls) == 2
                assert len(mock_cache.set_calls) == 1  # No new set

                # Call 3: Cache miss + set (different prompt)
                await extract_structured_data(
                    source=page,
                    data_schema=schema,
                    prompt="Prompt 2",
                    strategy="HTML",
                    enable_cache=True,
                )

                assert len(mock_cache.get_calls) == 3
                assert len(mock_cache.set_calls) == 2

                # Call 4: Cache hit (prompt 2)
                await extract_structured_data(
                    source=page,
                    data_schema=schema,
                    prompt="Prompt 2",
                    strategy="HTML",
                    enable_cache=True,
                )

                assert len(mock_cache.get_calls) == 4
                assert len(mock_cache.set_calls) == 2  # No new set
