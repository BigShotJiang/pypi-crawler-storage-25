"""
AppointmentLib - Patient Appointment Scheduler Library
A Python OOP library for managing healthcare appointments.
Provides appointment validation, status management, conflict detection and scheduling.
Built for NCI MSc Cloud Computing - Cloud Platform Programming Project.
"""

class Appointment:
    """Represents a patient appointment with validation and status management."""

    def __init__(self, patient_id, doctor_id, date_time, notes=""):
        """
        Initialise a new appointment.
        :param patient_id: Unique patient identifier
        :param doctor_id: Unique doctor identifier
        :param date_time: Appointment date and time in YYYY-MM-DDTHH:MM format
        :param notes: Optional notes for the appointment
        """
        self.patient_id = patient_id
        self.doctor_id = doctor_id
        self.date_time = date_time
        self.notes = notes
        self.status = "scheduled"
        if not self.validate():
            raise ValueError("Invalid appointment data")

    def validate(self):
        """Validate that patient_id, doctor_id and date_time are correct."""
        if not self.patient_id or not self.doctor_id:
            return False
        if not self._is_valid_date(self.date_time):
            return False
        return True

    def _is_valid_date(self, dt):
        """Check date format is exactly YYYY-MM-DDTHH:MM (16 characters)."""
        if len(dt) != 16:
            return False
        if dt[4] != "-" or dt[7] != "-" or dt[10] != "T" or dt[13] != ":":
            return False
        return True

    def to_json(self):
        """Serialize appointment details to a JSON string."""
        import json
        return json.dumps({
            "patientId": self.patient_id,
            "doctorId": self.doctor_id,
            "dateTime": self.date_time,
            "status": self.status,
            "notes": self.notes
        })

    def cancel(self):
        """Cancel the appointment by setting status to cancelled."""
        self.status = "cancelled"

    def complete(self):
        """Mark the appointment as completed."""
        self.status = "completed"

    def get_status(self):
        """Return current status of the appointment."""
        return self.status

    def get_patient_id(self):
        """Return the patient identifier."""
        return self.patient_id

    def get_doctor_id(self):
        """Return the doctor identifier."""
        return self.doctor_id

    def get_date_time(self):
        """Return the appointment date and time."""
        return self.date_time

    def __repr__(self):
        return f"Appointment({self.patient_id}, {self.doctor_id}, {self.date_time}, {self.status})"


class AppointmentScheduler:
    """Manages a collection of appointments with conflict detection and filtering."""

    def __init__(self):
        """Initialise an empty scheduler."""
        self.appointments = []

    def add_appointment(self, appointment):
        """Add a new appointment to the scheduler."""
        self.appointments.append(appointment)

    def get_by_patient(self, patient_id):
        """Return all appointments for a specific patient."""
        return [a for a in self.appointments if a.patient_id == patient_id]

    def get_by_doctor(self, doctor_id):
        """Return all appointments for a specific doctor."""
        return [a for a in self.appointments if a.doctor_id == doctor_id]

    def has_conflict(self, doctor_id, date_time):
        """
        Check if a doctor already has a scheduled appointment at the given time.
        Returns True if conflict exists, False otherwise.
        """
        return any(
            a.doctor_id == doctor_id and
            a.date_time == date_time and
            a.status == "scheduled"
            for a in self.appointments
        )

    def get_total_count(self):
        """Return total number of appointments in the scheduler."""
        return len(self.appointments)

    def summarize(self):
        """Return a summary string of all appointments."""
        return f"Total appointments: {len(self.appointments)}"
