# AppointmentLib

A Python OOP library for managing patient appointments in a healthcare scheduling system.
Built for NCI MSc Cloud Computing - Cloud Platform Programming Project.

## Installation
pip install appointmentlib-gopi

## Classes

### Appointment
Manages individual appointment records with validation and status management.

### AppointmentScheduler
Manages collections of appointments with conflict detection and filtering.

## Usage

from appointmentlib import Appointment, AppointmentScheduler

appt = Appointment("PAT001", "DOC001", "2026-04-20T10:00", "Annual checkup")
print(appt.get_status())  # scheduled

scheduler = AppointmentScheduler()
scheduler.add_appointment(appt)
print(scheduler.summarize())  # Total appointments: 1
print(scheduler.has_conflict("DOC001", "2026-04-20T10:00"))  # True
