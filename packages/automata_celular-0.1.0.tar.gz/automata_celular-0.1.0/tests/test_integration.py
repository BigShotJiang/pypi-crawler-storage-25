"""Pruebas de integracion para el automata celular."""

import pytest
import numpy as np
from automata_celular import ac1


def test_sierpinski_pattern():
    """Verifica que la regla 90 produce el triangulo de Sierpinski."""
    resultado = ac1(regla=90, E0="central", alto=10, ancho=21, guardar=False)
    # El triangulo de Sierpinski tiene propiedades especificas de simetria
    assert np.all(resultado[:, :] == resultado[:, ::-1])  # Simetria especular


def test_different_regimes():
    """Prueba diferentes tipos de comportamiento segun la regla."""
    # Regla caotica (Clase 3)
    caotica = ac1(regla=30, E0="azar", alto=20, ancho=40, guardar=False)
    
    # Regla periodica (Clase 2)
    periodica = ac1(regla=4, E0="central", alto=20, ancho=40, guardar=False)
    
    # Ambas deberian producir resultados diferentes
    assert not np.array_equal(caotica, periodica)


def test_custom_initial_state():
    """Prueba estado inicial personalizado."""
    patron = "10101"
    resultado = ac1(regla=90, E0=patron, alto=10, ancho=len(patron), guardar=False)
    # Verifica que la primera fila coincida con el patron
    assert np.array_equal(resultado[0, :], np.array([1,0,1,0,1]))