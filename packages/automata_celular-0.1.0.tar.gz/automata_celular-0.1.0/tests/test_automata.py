"""Pruebas unitarias para el autómata celular."""

import pytest
import numpy as np
from automata_celular import f, ac1


def test_f_basic():
    """Prueba la función f con diferentes configuraciones."""
    # Regla 90 (01011010 en binario)
    assert f(1, 0, 1, 90) == 1  # 101 en binario = 5
    assert f(1, 1, 1, 90) == 0
    assert f(0, 0, 0, 90) == 0


def test_f_all_combinations():
    """Prueba todas las combinaciones para una regla."""
    # Regla 30 (00011110 en binario)
    # 111=7, 110=6, 101=5, 100=4, 011=3, 010=2, 001=1, 000=0
    regla_30 = 30  # 00011110
    assert f(1, 1, 1, regla_30) == 0  # bit 7
    assert f(1, 1, 0, regla_30) == 0  # bit 6
    assert f(1, 0, 1, regla_30) == 0  # bit 5
    assert f(1, 0, 0, regla_30) == 1  # bit 4
    assert f(0, 1, 1, regla_30) == 1  # bit 3
    assert f(0, 1, 0, regla_30) == 1  # bit 2
    assert f(0, 0, 1, regla_30) == 1  # bit 1
    assert f(0, 0, 0, regla_30) == 0  # bit 0


def test_ac1_returns_array():
    """Prueba que ac1 devuelve un array numpy."""
    resultado = ac1(regla=90, E0="central", alto=10, ancho=20)
    assert isinstance(resultado, np.ndarray)
    assert resultado.shape == (10, 20)


def test_ac1_initial_conditions():
    """Prueba diferentes condiciones iniciales."""
    # Estado central
    resultado = ac1(regla=90, E0="central", alto=5, ancho=10)
    assert resultado[0, 5] == 1  # Centro debería ser 1
    
    # Estado aleatorio
    resultado = ac1(regla=90, E0="azar", alto=5, ancho=10)
    assert np.sum(resultado[0]) > 0  # Debería tener algunos 1s