python
"""Pruebas unitarias para el automata celular."""