# Autómata Celular 1D (Visualización 2D)

Este proyecto implementa un autómata celular unidimensional basado en las reglas de Wolfram, extendido a una representación bidimensional para su visualización en el tiempo.

## Descripción

El sistema simula la evolución de un autómata celular donde cada celda toma valores binarios (0 o 1) y su estado futuro depende de su vecindario inmediato (izquierda, centro, derecha) en la iteración anterior.

La evolución se representa como una matriz donde:

* Las columnas representan el espacio.
* Las filas representan el tiempo.

## Reglas de Wolfram

Las reglas de Wolfram definen cómo evoluciona cada celda en función de su vecindario de tres celdas `(izquierda, centro, derecha)`. Existen 256 reglas posibles (de 0 a 255).

Cada regla se construye interpretando un número en binario que indica el resultado para cada combinación posible:

Vecindarios posibles:

``` pythion
111 110 101 100 011 010 001 000
```

### Ejemplo: Regla 30

``` python
Regla 30 (binario): 00011110

111 → 0
110 → 0
101 → 0
100 → 1
011 → 1
010 → 1
001 → 1
000 → 0
```

Uso en el código:

```python
ac1(30, "central", alto=100, ancho=100)
```

Comportamiento: genera patrones caóticos y pseudoaleatorios.

---

### Ejemplo: Regla 90

``` python
Regla 90 (binario): 01011010

111 → 0
110 → 1
101 → 0
100 → 1
011 → 1
010 → 0
001 → 1
000 → 0
```

Uso:

```python
ac1(90, "central", alto=100, ancho=100)
```

Comportamiento: genera patrones fractales tipo triángulo de Sierpinski.

---

### Ejemplo: Regla 110

``` python
Regla 110 (binario): 01101110

111 → 0
110 → 1
101 → 1
100 → 0
011 → 1
010 → 1
001 → 1
000 → 0
```

Uso:

```python
ac1(110, "central", alto=100, ancho=100)
```

Comportamiento: complejidad intermedia; es Turing-completa.

---

### Ejemplo: Regla 184

``` pthon
Regla 184 (binario): 10111000

111 → 1
110 → 0
101 → 1
100 → 1
011 → 1
010 → 0
001 → 0
000 → 0
```

Uso:

```python
ac1(184, "central", alto=100, ancho=100)
```

Comportamiento: modela flujo de tráfico (conservación de "partículas").

---

## Requisitos

* Python 3.x
* numpy
* matplotlib

Instalación de dependencias:

```bash
pip install numpy matplotlib
```

## Estructura del Código

### Función `f(x, y, z, regla)`

Aplica una regla de autómata celular de Wolfram a un triplete de celdas.

**Parámetros:**

* `x, y, z` (int): Valores de las celdas vecinas (0 o 1).
* `regla` (int): Número de regla de Wolfram (entre 0 y 255).

**Retorna:**

* `int`: Nuevo valor de la celda central (0 o 1).

**Ejemplo:**

```python
f(1, 0, 1, 90)
```

---

### Función `ac1(regla=135, E0="azar", alto=100, ancho=100, guardar=False, filename=None)`

Ejecuta la simulación del autómata celular y genera una visualización.

**Parámetros:**

* `regla` (int): Regla de Wolfram (0-255). Default: 135.
* `E0` (str o int): Estado inicial:

  * `"azar"`: estado aleatorio.
  * `"central"`: un único 1 en el centro.
  * String binario (ej: `"0111000"`): patrón personalizado.
* `alto` (int): Número de filas (iteraciones temporales).
* `ancho` (int): Número de columnas (espacio).
* `guardar` (bool): Si es `True`, guarda la imagen.
* `filename` (str): Nombre del archivo de salida.

**Retorna:**

* `numpy.ndarray`: Matriz resultante del autómata.

**Ejemplos:**

```python
ac1(90, "central", alto=50, ancho=100)
ac1(30, "azar", alto=100, ancho=200)
```

## Funcionamiento

1. Se inicializa una matriz de tamaño `(alto, ancho)` con ceros.
2. Se define la primera fila según el parámetro `E0`.
3. Se itera sobre cada fila aplicando la regla a cada celda.
4. Se consideran condiciones periódicas en los bordes (envoltura).
5. Se visualiza el resultado como una imagen usando `matplotlib`.

## Visualización

El resultado se muestra como una imagen donde:

* El eje X representa el espacio.
* El eje Y representa el tiempo.
* El color indica el estado de cada celda.

Si `guardar=True`, la imagen se guarda en archivo; de lo contrario, se muestra en pantalla.

## Notas

* Se utiliza una semilla fija (`np.random.seed(42)`) para garantizar reproducibilidad en el estado inicial aleatorio.
* El uso de condiciones de frontera periódicas permite simular un espacio continuo sin bordes.

Preguntas Frecuentes

P: Qué significan los números de reglas?
R: Cada regla es un número de 0 a 255 que codifica el comportamiento de 8 posibles combinaciones de vecinos (2^3 = 8). El número en binario determina el nuevo estado para cada combinación.

P: Cómo funcionan las condiciones de borde?
R: Se utilizan condiciones de borde envolventes (toroidales), donde el borde izquierdo se conecta con el derecho y viceversa.

P: Puedo usar esto en tiempo real?
R: Sí, la implementación es eficiente con NumPy, pero la visualización puede ser lenta para matrices muy grandes. Para simulaciones en tiempo real, se recomienda usar dimensiones pequeñas.

P: Cómo elijo la mejor regla para mi proyecto?
R: Depende de tu objetivo. Usa reglas Clase 3 para aleatoriedad, Clase 2 para patrones simples, Clase 4 para comportamiento complejo.

P: El estado inicial "azar" es realmente aleatorio?
R: Sí, usa numpy.random.randint, pero se fija una semilla (seed=42) para reproducibilidad. Puedes modificar el código si necesitas aleatoriedad pura.


## Licencia

Este proyecto está licenciado bajo la GNU General Public License v3.0 (GPL-3.0).

Esto significa que:

Puedes usar, modificar y distribuir el código libremente.
Cualquier trabajo derivado debe mantener la misma licencia.
Debes incluir una copia de la licencia en cualquier redistribución.

Para más detalles, consulta el archivo LICENSE o visita:
https://www.gnu.org/licenses/gpl-3.0.html

