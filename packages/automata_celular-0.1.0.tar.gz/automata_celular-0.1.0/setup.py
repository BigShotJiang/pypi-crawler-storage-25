"""Configuración del paquete para PyPi."""

from setuptools import setup, find_packages
import os

# Lee el README.md si existe
long_description = ""
if os.path.exists("README.md"):
    with open("README.md", "r", encoding="utf-8") as fh:
        long_description = fh.read()

# Lee requirements.txt si existe
requirements = []
if os.path.exists("requirements.txt"):
    with open("requirements.txt", "r", encoding="utf-8") as fh:
        requirements = fh.read().splitlines()
else:
    # Dependencias por defecto
    requirements = ["numpy>=1.19.0", "matplotlib>=3.3.0"]

setup(
    name="automata-celular",
    version="0.1.0",
    author="Juan Gracia Sercado",
    author_email="jfractal.gnuista@gmail.com",
    description="Implementación de autómata celular 1D con reglas de Wolfram",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/juangracia/automata-celular",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "License :: OSI Approved :: GNU General Public License v3 (GPLv3)",
        "Operating System :: OS Independent",
        "Topic :: Scientific/Engineering :: Mathematics",
        "Topic :: Scientific/Engineering :: Visualization",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
    ],
    python_requires=">=3.8",
    install_requires=requirements,
    include_package_data=True,
    zip_safe=False,
    
)