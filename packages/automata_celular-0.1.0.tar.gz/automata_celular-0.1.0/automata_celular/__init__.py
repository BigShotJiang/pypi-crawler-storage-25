"""
Automata Celular 1D - Implementación de reglas de Wolfram

Copyright (C) 2024 Juan Gracia Sercado

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
"""

from .automata import f, ac1
from .version import __version__, __license__, __author__, __email__

__all__ = ['f', 'ac1', '__version__', '__license__', '__author__', '__email__']