"""Versión del paquete bajo licencia GPL-3.0."""

__version__ = "0.1.0"
__license__ = "GNU General Public License v3.0 (GPL-3.0)"
__author__ = "Juan Gracia Sercado"
__email__ = "jfractal.gnuista@gmail.com"