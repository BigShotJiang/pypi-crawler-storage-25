"""Módulo principal con la implementación del autómata celular."""

# Importamos numpy para manejo eficiente de arreglos y operaciones numéricas
import numpy as np
# Importamos matplotlib para graficar los resultados
import matplotlib.pyplot as plt
# Importamos cm para mapas de color
from matplotlib import cm


def f(x, y, z, regla):
    """
    Aplica la regla de autómata celular a un triplete de celdas.
    
    Parameters
    ----------
    x, y, z : int
        Valores de las celdas vecinas (0 o 1)
    regla : int
        Número entero que define la regla de Wolfram (0-255)
    
    Returns
    -------
    int
        Nuevo valor de la celda central según la regla (0 o 1)
    
    Examples
    --------
    >>> f(1, 0, 1, 90)
    1
    """
    # Calcula el índice en la regla usando bits: x*4 + y*2 + z*1
    # y devuelve si ese bit está activo en la regla
    return (regla >> (x << 2 | y << 1 | z)) & 1


def ac1(regla=135, E0="azar", alto=100, ancho=100, guardar=False, filename=None):
    """
    Ejecuta el autómata celular 1D extendido a 2D para graficar.
    
    Parameters
    ----------
    regla : int, optional
        Número de regla de Wolfram (0-255), por defecto 135
    E0 : str or int, optional
        Estado inicial. Puede ser:
        - "azar": estado inicial aleatorio
        - "central": un 1 en el centro de la primera fila
        - String de 0 y 1 (ej: "0111000"): usa ese patrón como primera fila
        Por defecto "azar"
    alto : int, optional
        Número de filas (tiempo), por defecto 100
    ancho : int, optional
        Número de columnas (espacio), por defecto 100
    guardar : bool, optional
        Si es True, guarda la figura en lugar de mostrarla, por defecto False
    filename : str, optional
        Nombre del archivo para guardar la figura (si guardar=True)
    
    Returns
    -------
    numpy.ndarray
        Matriz resultante del autómata
    
    Examples
    --------
    >>> ac1(90, "central", alto=50, ancho=100)
    >>> ac1(30, "azar", alto=100, ancho=200)
    """
    # Creamos la figura con tamaño proporcional
    fig = plt.figure(figsize=(ancho / 10, alto / 10))

    # Creamos la matriz del autómata, inicialmente todo falso (0)
    E = np.zeros((alto, ancho), dtype=np.bool_)

    # Definimos el estado inicial
    if E0 == "central":
        # Colocamos un 1 en el centro de la primera fila
        E[0, int(ancho / 2)] = 1
    elif isinstance(E0, str) and len(E0) > 0 and E0[0] in ['0', '1']:
        # Si E0 es un string de 0 y 1, lo usamos como fila inicial
        ancho = len(E0)  # Ajustamos el ancho al tamaño del string
        E = np.zeros((alto, ancho), dtype=np.bool_)
        E[0, :] = np.array(list(E0), dtype=int)
    else:
        # Estado inicial aleatorio: valores 0 o 1
        np.random.seed(42)  # Para reproducibilidad
        E[0, :] = np.random.randint(0, 2, ancho)

    # Iteramos sobre cada fila (excepto la primera)
    for i in range(1, alto):
        # Para cada columna (excepto los bordes)
        for j in range(1, ancho - 1):
            # Calculamos el valor de la celda usando sus 3 vecinos de la fila anterior
            E[i, j] = f(E[i - 1, j - 1], E[i - 1, j], E[i - 1, j + 1], regla)

        # Bordes: primera y última columna (considerando envoltura)
        E[i, 0] = f(E[i - 1, ancho - 1], E[i - 1, 0], E[i - 1, 1], regla)
        E[i, ancho - 1] = f(E[i - 1, ancho - 2], E[i - 1, ancho - 1], E[i - 1, 0], regla)

    # Mostramos o guardamos la matriz resultante como imagen
    plt.imshow(E, cmap=cm.Blues)
    plt.title(f"Regla {regla}")
    plt.xlabel("Espacio")
    plt.ylabel("Tiempo")
    
    if guardar and filename:
        plt.savefig(filename, dpi=150, bbox_inches='tight')
    else:
        plt.show()
    
    return E