"""
Shared response processing logic for HTTP responses.

This module provides common response validation and parsing logic used by both
sync and async implementations.
"""

from __future__ import annotations

from typing import TYPE_CHECKING
from urllib.parse import urlparse

from ..exceptions import DiscoveryException
from .discovery_policy import DiscoveryPolicy
from .models import (
    AuthorizationCodeTokenResponse,
    ClientCredentialsTokenResponse,
    DiscoveryDocumentResponse,
    JwksResponse,
    RefreshTokenResponse,
    TokenIntrospectionResponse,
    UserInfoResponse,
)
from .parsers import jwks_from_dict
from .validators import (
    validate_https_url_with_policy,
    validate_issuer_with_policy,
    validate_parameter_values,
    validate_required_parameters,
)


if TYPE_CHECKING:
    import httpx


def _get_url_authority(url: str) -> str:
    """Extract scheme://host from a URL, lowercased per RFC 3986 §3.2.2."""
    if not url:
        return ""
    parsed = urlparse(url)
    return f"{parsed.scheme}://{parsed.netloc}".lower()


def _validate_endpoint_authority(
    url: str,
    parameter_name: str,
    response_json: dict,
    policy: DiscoveryPolicy,
) -> None:
    """Validate that an endpoint URL's authority matches expected values.

    The expected authority is ``policy.authority`` when set, or derived from
    the discovery document's ``issuer``. Additional allowed authorities come
    from ``policy.additional_endpoint_base_addresses``.

    Raises:
        DiscoveryException: If the endpoint URL's authority does not match.
    """

    ep_authority = _get_url_authority(url)

    # Build allowed authorities set (case-insensitive per RFC 3986 §3.2.2)
    if policy.authority:
        allowed = {_get_url_authority(policy.authority)}
    else:
        issuer = response_json.get("issuer", "")
        allowed = {_get_url_authority(issuer)} if issuer else set()

    for addr in policy.additional_endpoint_base_addresses or []:
        allowed.add(_get_url_authority(addr))

    # Discard empty string from set (from empty URLs)
    allowed.discard("")

    if not allowed:
        raise DiscoveryException(
            f"Cannot validate {parameter_name} authority: "
            f"no authority constraint available (issuer is empty and "
            f"no policy.authority or additional_endpoint_base_addresses set)"
        )

    if ep_authority not in allowed:
        raise DiscoveryException(
            f"{parameter_name} authority '{ep_authority}' does not match "
            f"expected authorities: {sorted(allowed)}"
        )


def validate_and_parse_discovery_response(
    response: httpx.Response,
    policy: DiscoveryPolicy | None = None,
) -> dict:
    """
    Validate and parse discovery document HTTP response.

    Args:
        response: HTTP response from discovery endpoint
        policy: Optional discovery policy for configurable validation.
            When ``None``, strict defaults apply.

    Returns:
        dict: Parsed discovery document JSON

    Raises:
        DiscoveryException: If response is invalid
    """
    # Check content type - extract media type before any parameters (e.g., charset)
    content_type_header = response.headers.get("Content-Type", "")
    media_type = content_type_header.split(";")[0].strip().lower()
    if media_type != "application/json":
        raise DiscoveryException(
            f"Invalid content type. Expected application/json, got: "
            f"{response.headers.get('Content-Type', 'unknown')}"
        )

    # Parse JSON
    try:
        response_json = response.json()
    except ValueError as e:
        raise DiscoveryException(f"Invalid JSON response: {e!s}") from e

    # Validate required parameters
    validate_required_parameters(response_json)

    # Validate issuer format (policy-aware)
    validate_issuer_with_policy(response_json.get("issuer", ""), policy)

    # Validate parameter values
    validate_parameter_values(response_json)

    # Enforce require_key_set policy
    if (policy is None or policy.require_key_set) and not response_json.get(
        "jwks_uri"
    ):
        raise DiscoveryException(
            "Discovery document does not contain a jwks_uri, "
            "required by policy (require_key_set=True)"
        )

    # Normalize policy for endpoint validation: treat None as strict defaults
    effective_policy = policy if policy is not None else DiscoveryPolicy()

    # Validate endpoint URLs (policy-aware)
    _endpoint_names = [
        "jwks_uri",
        "authorization_endpoint",
        "token_endpoint",
        "userinfo_endpoint",
        "registration_endpoint",
        "introspection_endpoint",
    ]
    for ep_name in _endpoint_names:
        ep_url = response_json.get(ep_name)
        validate_https_url_with_policy(ep_url, ep_name, policy)
        # Validate endpoint authority when explicitly configured
        if ep_url and effective_policy.authority:
            _validate_endpoint_authority(
                ep_url, ep_name, response_json, effective_policy
            )

    return response_json


def build_discovery_response(
    response_json: dict,
) -> DiscoveryDocumentResponse:
    """
    Build DiscoveryDocumentResponse from validated JSON.

    Args:
        response_json: Validated discovery document JSON

    Returns:
        DiscoveryDocumentResponse: Success response with discovery data
    """
    return DiscoveryDocumentResponse(
        # Core OpenID Connect endpoints
        issuer=response_json.get("issuer"),
        jwks_uri=response_json.get("jwks_uri"),
        authorization_endpoint=response_json.get("authorization_endpoint"),
        token_endpoint=response_json.get("token_endpoint"),
        # Required properties from OpenID Connect Discovery 1.0 specification
        response_types_supported=response_json.get(
            "response_types_supported",
        ),
        subject_types_supported=response_json.get(
            "subject_types_supported",
        ),
        id_token_signing_alg_values_supported=response_json.get(
            "id_token_signing_alg_values_supported",
        ),
        # Common optional properties
        userinfo_endpoint=response_json.get("userinfo_endpoint"),
        registration_endpoint=response_json.get("registration_endpoint"),
        introspection_endpoint=response_json.get("introspection_endpoint"),
        scopes_supported=response_json.get("scopes_supported"),
        response_modes_supported=response_json.get(
            "response_modes_supported",
        ),
        grant_types_supported=response_json.get("grant_types_supported"),
        acr_values_supported=response_json.get("acr_values_supported"),
        # Cryptographic algorithm support
        id_token_encryption_alg_values_supported=response_json.get(
            "id_token_encryption_alg_values_supported",
        ),
        id_token_encryption_enc_values_supported=response_json.get(
            "id_token_encryption_enc_values_supported",
        ),
        userinfo_signing_alg_values_supported=response_json.get(
            "userinfo_signing_alg_values_supported",
        ),
        userinfo_encryption_alg_values_supported=response_json.get(
            "userinfo_encryption_alg_values_supported",
        ),
        userinfo_encryption_enc_values_supported=response_json.get(
            "userinfo_encryption_enc_values_supported",
        ),
        request_object_signing_alg_values_supported=response_json.get(
            "request_object_signing_alg_values_supported",
        ),
        request_object_encryption_alg_values_supported=response_json.get(
            "request_object_encryption_alg_values_supported",
        ),
        request_object_encryption_enc_values_supported=response_json.get(
            "request_object_encryption_enc_values_supported",
        ),
        # Token endpoint authentication
        token_endpoint_auth_methods_supported=response_json.get(
            "token_endpoint_auth_methods_supported",
        ),
        # PKCE support
        code_challenge_methods_supported=response_json.get(
            "code_challenge_methods_supported",
        ),
        token_endpoint_auth_signing_alg_values_supported=response_json.get(
            "token_endpoint_auth_signing_alg_values_supported",
        ),
        # Display and UI
        display_values_supported=response_json.get(
            "display_values_supported",
        ),
        claim_types_supported=response_json.get("claim_types_supported"),
        claims_supported=response_json.get("claims_supported"),
        claims_locales_supported=response_json.get(
            "claims_locales_supported",
        ),
        ui_locales_supported=response_json.get("ui_locales_supported"),
        # Feature support flags
        claims_parameter_supported=response_json.get(
            "claims_parameter_supported",
        ),
        request_parameter_supported=response_json.get(
            "request_parameter_supported",
        ),
        request_uri_parameter_supported=response_json.get(
            "request_uri_parameter_supported",
        ),
        require_request_uri_registration=response_json.get(
            "require_request_uri_registration",
        ),
        # Documentation and policy
        service_documentation=response_json.get("service_documentation"),
        op_policy_uri=response_json.get("op_policy_uri"),
        op_tos_uri=response_json.get("op_tos_uri"),
        is_successful=True,
    )


def parse_jwks_response(response: httpx.Response) -> JwksResponse:
    """
    Parse JWKS HTTP response.

    Args:
        response: HTTP response from JWKS endpoint

    Returns:
        JwksResponse: Parsed JWKS response with keys
    """
    if response.is_success:
        response_json = response.json()
        keys = [jwks_from_dict(key) for key in response_json["keys"]]
        return JwksResponse(is_successful=True, keys=keys)

    error_msg = (
        f"JSON web keys request failed with status code: "
        f"{response.status_code}. Response Content: {response.content}"
    )
    return JwksResponse(
        is_successful=False,
        error=error_msg,
    )


def parse_token_response(
    response: httpx.Response,
) -> ClientCredentialsTokenResponse:
    """
    Parse token HTTP response.

    Args:
        response: HTTP response from token endpoint

    Returns:
        ClientCredentialsTokenResponse: Parsed token response
    """
    if response.is_success:
        response_json = response.json()
        return ClientCredentialsTokenResponse(
            is_successful=True,
            token=response_json,
        )

    error_msg = (
        f"Token generation request failed with status code: "
        f"{response.status_code}. Response Content: {response.content}"
    )
    return ClientCredentialsTokenResponse(
        is_successful=False,
        error=error_msg,
    )


def parse_auth_code_token_response(
    response: httpx.Response,
) -> AuthorizationCodeTokenResponse:
    """Parse authorization code token exchange HTTP response."""
    if response.is_success:
        return AuthorizationCodeTokenResponse(
            is_successful=True,
            token=response.json(),
        )

    error_msg = (
        f"Authorization code token exchange failed with status code: "
        f"{response.status_code}. Response Content: {response.content}"
    )
    return AuthorizationCodeTokenResponse(
        is_successful=False,
        error=error_msg,
    )


def parse_refresh_token_response(
    response: httpx.Response,
) -> RefreshTokenResponse:
    """Parse refresh token grant HTTP response."""
    if response.is_success:
        return RefreshTokenResponse(is_successful=True, token=response.json())

    error_msg = (
        f"Token refresh failed with status code: "
        f"{response.status_code}. Response Content: {response.content}"
    )
    return RefreshTokenResponse(is_successful=False, error=error_msg)


def parse_introspection_response(
    response: httpx.Response,
) -> TokenIntrospectionResponse:
    """Parse token introspection HTTP response (RFC 7662)."""
    if response.is_success:
        data = response.json()
        if not isinstance(data, dict):
            return TokenIntrospectionResponse(
                is_successful=False,
                error=f"Introspection response is not a JSON object: {type(data).__name__}",
            )
        return TokenIntrospectionResponse(
            is_successful=True,
            claims=data,
        )

    error_msg = (
        f"Token introspection failed with status code: "
        f"{response.status_code}. Response Content: {response.content}"
    )
    return TokenIntrospectionResponse(is_successful=False, error=error_msg)


def parse_userinfo_response(response: httpx.Response) -> UserInfoResponse:
    """
    Parse UserInfo HTTP response.

    Supports Content-Type detection per OIDC Core 1.0 Section 5.3.2/5.3.3:
    - application/json: Claims extracted as dict
    - application/jwt: Raw JWT string stored for caller to decode/validate

    Args:
        response: HTTP response from UserInfo endpoint

    Returns:
        UserInfoResponse: Parsed response with claims or raw JWT
    """
    if not response.is_success:
        error_msg = (
            f"UserInfo request failed with status code: "
            f"{response.status_code}. Response Content: {response.content}"
        )
        return UserInfoResponse(
            is_successful=False,
            error=error_msg,
        )

    content_type = response.headers.get("Content-Type", "")
    media_type = content_type.split(";")[0].strip().lower()

    if media_type == "application/jwt":
        return UserInfoResponse(
            is_successful=True,
            raw=response.text,
        )

    # Default to JSON parsing (application/json or unspecified)
    claims = response.json()
    return UserInfoResponse(
        is_successful=True,
        claims=claims,
    )


__all__ = [
    "build_discovery_response",
    "parse_auth_code_token_response",
    "parse_introspection_response",
    "parse_jwks_response",
    "parse_token_response",
    "parse_userinfo_response",
    "validate_and_parse_discovery_response",
]
