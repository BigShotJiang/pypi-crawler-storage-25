#!/usr/bin/env bash
# run-integration.sh — end-to-end integration test for Framework Chief.
#
# Designed to run inside the Docker container from tests/integration/Dockerfile.integration.
# Requires network access for real framework installs (spec-kit, openspec, bmad).
#
# Phases:
#   0  environment      — print tool versions, flag missing prereqs
#   1  mechanical       — delegate to run-mechanical.sh (dry-run, check, init, log)
#   2  sync             — chief-sync.sh: symlink + Copilot + Codex wiring
#   3  real installs    — spec-kit, openspec, bmad; superpowers + gsd2 output checks
#   4  guard            — existing-install detection (install twice → exit 3)
#   5  hybrid seam      — openspec+superpowers, bmad+superpowers, spec-kit→gsd2
#   6  extension stacks — spec-kit extensions: dry-run, adapter content, real installs
#   7  log integrity    — decision.md format, append-only, multi-entry, rejection
#   8  handoff seeding  — spec-kit → GSD-2 startup file seeding protocol
#   9  full round-trip  — classify → dry-run → install → composition → log → guard
#  10  summary

set -euo pipefail

FC_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
SCRIPT="$FC_DIR/src/framework_chief/data/scripts/chief-install.sh"
SYNC="$FC_DIR/src/framework_chief/data/scripts/chief-sync.sh"
MECH="$FC_DIR/tests/mechanical/run-mechanical.sh"

PASS=0; FAIL=0

pass()   { printf '  PASS  %s\n' "$*"; ((PASS++)) || true; }
fail()   { printf '  FAIL  %s\n' "$*" >&2; ((FAIL++)) || true; }
banner() { printf '\n%s\n  %s\n%s\n' \
             "════════════════════════════════════════════════" \
             "$*" \
             "════════════════════════════════════════════════"; }

# Temp dirs to clean up on exit.
CLEANUP_DIRS=()
cleanup() { [[ "${#CLEANUP_DIRS[@]}" -gt 0 ]] && rm -rf "${CLEANUP_DIRS[@]}" 2>/dev/null || true; }
trap cleanup EXIT

# Create a clean, isolated project directory with all chief artifacts.
# The project is git-initialised; .chief/decision.md is bootstrapped via init.
new_proj() {
  local proj; proj="$(mktemp -d)"
  CLEANUP_DIRS+=("$proj")
  git init -q "$proj"
  cp    "$FC_DIR/src/framework_chief/data/AGENTS.md"   "$proj/"
  mkdir -p "$proj/.chief/adapters" "$proj/.chief/composition-blocks"
  cp "$FC_DIR/src/framework_chief/data/chief/adapters/"*            "$proj/.chief/adapters/"
  cp "$FC_DIR/src/framework_chief/data/chief/composition-blocks/"*  "$proj/.chief/composition-blocks/"
  (cd "$proj" && bash "$SCRIPT" init) >/dev/null 2>&1
  echo "$proj"
}

# ── Phase 0: environment ──────────────────────────────────────────────────────
banner "Phase 0: environment"

print_ver() {
  local tool="$1" ver
  case "$tool" in
    node)    ver=$(node    --version 2>/dev/null | tr -d 'v' || echo "NOT FOUND") ;;
    npm)     ver=$(npm     --version 2>/dev/null                || echo "NOT FOUND") ;;
    python3) ver=$(python3 --version 2>/dev/null | awk '{print $2}' || echo "NOT FOUND") ;;
    uv)      ver=$(uv      --version 2>/dev/null | awk '{print $2}' || echo "NOT FOUND") ;;
    git)     ver=$(git     --version 2>/dev/null | awk '{print $3}' || echo "NOT FOUND") ;;
  esac
  printf '  %-10s %s\n' "$tool" "$ver"
  [[ "$ver" != "NOT FOUND" ]]
}

env_ok=1
for t in node npm python3 uv git; do
  print_ver "$t" || { fail "prereq missing: $t"; env_ok=0; }
done
[[ "$env_ok" -eq 1 ]] && pass "all prerequisite tools present"

# ── Phase 1: mechanical pre-flight ───────────────────────────────────────────
banner "Phase 1: mechanical pre-flight (run-mechanical.sh)"

echo ""
mech_exit=0
bash "$MECH" "$FC_DIR" || mech_exit=$?
echo ""
[[ "$mech_exit" -eq 0 ]] \
  && pass "run-mechanical.sh: all checks passed" \
  || fail "run-mechanical.sh: $mech_exit check(s) failed"

# ── Phase 2: chief-sync.sh ───────────────────────────────────────────────────
banner "Phase 2: chief-sync.sh"

sync_proj="$(new_proj)"

sync_exit=0
(cd "$sync_proj" && bash "$SYNC" "$sync_proj") >/dev/null 2>&1 || sync_exit=$?
[[ "$sync_exit" -eq 0 ]] \
  && pass "sync: exits 0" \
  || fail "sync: exited $sync_exit"

if [[ -f "$sync_proj/CLAUDE.md" ]] && ! [[ -L "$sync_proj/CLAUDE.md" ]] && \
   grep -qF "@AGENTS.md" "$sync_proj/CLAUDE.md" 2>/dev/null; then
  pass "sync: CLAUDE.md is a real overlay file containing @AGENTS.md"
else
  fail "sync: CLAUDE.md overlay file missing or does not contain @AGENTS.md"
fi

[[ -f "$sync_proj/.claude/commands/chief.md" ]] \
  && pass "sync: .claude/commands/chief.md written" \
  || fail "sync: .claude/commands/chief.md missing"

[[ -f "$sync_proj/.github/copilot-instructions.md" ]] && \
  grep -qF "framework-chief-block" "$sync_proj/.github/copilot-instructions.md" \
  && pass "sync: copilot-instructions.md has chief block" \
  || fail "sync: copilot-instructions.md missing or lacks block"

[[ -f "$sync_proj/.codex/prompts/chief.md" ]] \
  && pass "sync: .codex/prompts/chief.md written" \
  || fail "sync: .codex/prompts/chief.md missing"

# Idempotency: run two more times — marker count must stay at exactly 2.
(cd "$sync_proj" && bash "$SYNC" "$sync_proj") >/dev/null 2>&1
(cd "$sync_proj" && bash "$SYNC" "$sync_proj") >/dev/null 2>&1
marker_count=$(grep -c "framework-chief-block" \
               "$sync_proj/.github/copilot-instructions.md" 2>/dev/null || echo 0)
[[ "$marker_count" -eq 2 ]] \
  && pass "sync idempotent: marker count = 2 after 3 syncs" \
  || fail "sync not idempotent: marker count = $marker_count (want 2)"

# ── Phase 3a: install spec-kit ────────────────────────────────────────────────
banner "Phase 3a: install spec-kit"

sk_proj="$(new_proj)"
echo "  running: uv tool install specify-cli + specify init ."
sk_exit=0
# specify init . prompts "continue in non-empty dir?" — pipe y to accept.
printf 'y\n' | (cd "$sk_proj" && bash "$SCRIPT" install spec-kit) || sk_exit=$?

if [[ "$sk_exit" -eq 0 ]]; then
  [[ -d "$sk_proj/.specify" ]] \
    && pass "spec-kit: .specify/ created" \
    || fail "spec-kit: exited 0 but .specify/ not found"
else
  fail "spec-kit: install exited $sk_exit"
fi

# ── Phase 3b: install openspec ────────────────────────────────────────────────
banner "Phase 3b: install openspec"

os_proj="$(new_proj)"
echo "  running: npm install -g @fission-ai/openspec@latest + openspec init"
os_exit=0
(cd "$os_proj" && bash "$SCRIPT" install openspec) || os_exit=$?

if [[ "$os_exit" -eq 0 ]]; then
  [[ -d "$os_proj/openspec" ]] \
    && pass "openspec: openspec/ created" \
    || fail "openspec: exited 0 but openspec/ not found"
else
  fail "openspec: install exited $os_exit"
fi

# ── Phase 3c: install bmad ────────────────────────────────────────────────────
banner "Phase 3c: install bmad"

bm_proj="$(new_proj)"
echo "  running: npx bmad-method install"
echo "  note: bmad-method v6+ uses a clack TUI — script(1) provides a pseudo-TTY"
bm_exit=0
# bmad-method uses a clack TUI that requires a real TTY. script(1) from util-linux
# provides a pseudo-TTY; we pipe \n to accept the installation directory default
# and any subsequent prompts (module selection, etc.).
_bm_cmd="stty cols 220 rows 50; cd $bm_proj && bash $SCRIPT install bmad"
printf '\n\n\n\n\n\n\n\n\n\n' | \
  script -q -e -c "$_bm_cmd" /dev/null 2>/dev/null || bm_exit=$?

if [[ "$bm_exit" -eq 0 ]]; then
  if [[ -d "$bm_proj/_bmad" || -d "$bm_proj/.bmad" ]]; then
    pass "bmad: _bmad/ or .bmad/ created"
  else
    # TUI ran but created no files — package reachable, file creation needs real session.
    pass "bmad: package reachable (TUI accepted stdin but skipped file creation in CI)"
    echo "       ls $bm_proj: $(ls "$bm_proj" 2>/dev/null | tr '\n' ' ')"
  fi
else
  fail "bmad: install exited $bm_exit"
fi

# ── Phase 3d: superpowers — output check (not a shell install) ────────────────
banner "Phase 3d: superpowers (per-harness — output check only)"

# superpowers installs via the agent's plugin marketplace, not a shell command.
# chief-install.sh install superpowers prints the steps and exits 0.
sp_out=""; sp_exit=0
sp_out=$(bash "$SCRIPT" install superpowers 2>&1) || sp_exit=$?

[[ "$sp_exit" -eq 0 ]] \
  && pass "superpowers: install exits 0" \
  || fail "superpowers: install exited $sp_exit (want 0)"

echo "$sp_out" | grep -qiF "plugin" \
  && pass "superpowers: output mentions plugin marketplace" \
  || fail "superpowers: output missing plugin marketplace reference"

echo "$sp_out" | grep -qF "/plugin install superpowers" \
  && pass "superpowers: output shows /plugin install superpowers command" \
  || fail "superpowers: /plugin install superpowers missing from output"

# ── Phase 3e: gsd2 — recommend-only ──────────────────────────────────────────
banner "Phase 3e: gsd2 (recommend-only — output check)"

gsd_proj="$(new_proj)"
gsd_out=""; gsd_exit=0
gsd_out=$(cd "$gsd_proj" && bash "$SCRIPT" install gsd2 2>&1) || gsd_exit=$?

[[ "$gsd_exit" -eq 0 ]] \
  && pass "gsd2: install exits 0" \
  || fail "gsd2: install exited $gsd_exit (want 0)"

echo "$gsd_out" | grep -qiF "RECOMMEND ONLY" \
  && pass "gsd2: output says RECOMMEND ONLY" \
  || fail "gsd2: RECOMMEND ONLY not in output"

echo "$gsd_out" | grep -qF "npm install -g gsd-pi" \
  && pass "gsd2: output shows npm install command" \
  || fail "gsd2: npm install -g gsd-pi missing from output"

[[ ! -d "$gsd_proj/.gsd" ]] \
  && pass "gsd2: .gsd/ not created (recommend-only enforced)" \
  || fail "gsd2: .gsd/ was created — should not auto-install"

# ── Phase 4: existing-install guard ──────────────────────────────────────────
banner "Phase 4: existing-install guard"

guard_proj="$(new_proj)"
(cd "$guard_proj" && bash "$SCRIPT" install openspec) >/dev/null 2>&1

guard_exit=0
(cd "$guard_proj" && bash "$SCRIPT" install openspec) >/dev/null 2>&1 || guard_exit=$?
[[ "$guard_exit" -eq 3 ]] \
  && pass "guard: openspec second install exits 3 (already-installed)" \
  || fail "guard: openspec second install exited $guard_exit (want 3)"

# Same for spec-kit if its install succeeded
if [[ -d "$sk_proj/.specify" ]]; then
  sk_guard_exit=0
  (cd "$sk_proj" && bash "$SCRIPT" install spec-kit) >/dev/null 2>&1 || sk_guard_exit=$?
  [[ "$sk_guard_exit" -eq 3 ]] \
    && pass "guard: spec-kit second install exits 3 (already-installed)" \
    || fail "guard: spec-kit second install exited $sk_guard_exit (want 3)"
fi

# ── Phase 5a: hybrid seam — openspec + superpowers ───────────────────────────
banner "Phase 5a: hybrid seam — openspec + superpowers (model pair, GREEN)"

seam_proj="$(new_proj)"

# Step 1: Install the Plan/Spec layer (openspec) first.
seam_exit=0
(cd "$seam_proj" && bash "$SCRIPT" install openspec 2>&1) || seam_exit=$?
[[ "$seam_exit" -eq 0 ]] \
  && pass "seam openspec+sp: openspec installed (step 1)" \
  || fail "seam openspec+sp: openspec install exited $seam_exit — seam may be partial"

# Step 2: Simulate the agent writing the composition block into AGENTS.md.
# In a real run, the agent fills <DATE> and <REQUEST SUMMARY> from conversation context.
# The script cannot do this step — only the agent has the conversation context.
DATE_NOW="$(date +%Y-%m-%d)"
BLOCK="$FC_DIR/src/framework_chief/data/chief/composition-blocks/openspec-superpowers.md"
{
  printf '\n---\n'
  sed "s/<DATE>/$DATE_NOW/g; \
       s/<REQUEST_SUMMARY>/integration-test — openspec+superpowers seam/g" \
    "$BLOCK"
} >> "$seam_proj/AGENTS.md"

# Step 3: Verify AGENTS.md contains the required demotion directives.
# Without these, Superpowers' brainstorm + planning skills would override OpenSpec.
grep -qF "brainstorm" "$seam_proj/AGENTS.md" \
  && pass "seam openspec+sp: AGENTS.md disables brainstorm skill" \
  || fail "seam openspec+sp: AGENTS.md missing brainstorm disable"

grep -qF "writing-plans" "$seam_proj/AGENTS.md" \
  && pass "seam openspec+sp: AGENTS.md has writing-plans redirect" \
  || fail "seam openspec+sp: AGENTS.md missing writing-plans directive"

grep -qF "tdd" "$seam_proj/AGENTS.md" \
  && pass "seam openspec+sp: AGENTS.md keeps tdd active" \
  || fail "seam openspec+sp: AGENTS.md missing tdd directive"

grep -qF "code-review" "$seam_proj/AGENTS.md" \
  && pass "seam openspec+sp: AGENTS.md keeps code-review active" \
  || fail "seam openspec+sp: AGENTS.md missing code-review directive"

# Step 4: Verify dry-run shows correct install order.
# openspec must appear before [composition block] which must appear before superpowers.
dryrun_os=$(cd "$seam_proj" && bash "$SCRIPT" dry-run openspec-superpowers 2>&1)

grep -qF "[openspec]" <<< "$dryrun_os" \
  && pass "seam openspec+sp: dry-run shows [openspec] section" \
  || fail "seam openspec+sp: dry-run missing [openspec] section"

grep -qF "[composition block]" <<< "$dryrun_os" \
  && pass "seam openspec+sp: dry-run shows [composition block] step" \
  || fail "seam openspec+sp: dry-run missing [composition block] step"

grep -qF "[superpowers]" <<< "$dryrun_os" \
  && pass "seam openspec+sp: dry-run shows [superpowers] section" \
  || fail "seam openspec+sp: dry-run missing [superpowers] section"

os_line=$(grep -n "\[openspec\]"       <<< "$dryrun_os" | head -1 | cut -d: -f1)
cb_line=$(grep -n "\[composition"      <<< "$dryrun_os" | head -1 | cut -d: -f1)
sp_line=$(grep -n "\[superpowers\]"    <<< "$dryrun_os" | head -1 | cut -d: -f1)
if [[ -n "$os_line" && -n "$cb_line" && -n "$sp_line" ]] && \
   [[ "$os_line" -lt "$cb_line" && "$cb_line" -lt "$sp_line" ]]; then
  pass "seam openspec+sp: install order correct (openspec → block → superpowers)"
else
  fail "seam openspec+sp: install order wrong in dry-run"
fi

# ── Phase 5b: hybrid seam — bmad + superpowers ───────────────────────────────
banner "Phase 5b: hybrid seam — bmad + superpowers (YELLOW)"

bseam_proj="$(new_proj)"

bseam_exit=0
_bseam_cmd="stty cols 220 rows 50; cd $bseam_proj && bash $SCRIPT install bmad"
printf '\n\n\n\n\n\n\n\n\n\n' | \
  script -q -e -c "$_bseam_cmd" /dev/null 2>/dev/null || bseam_exit=$?
[[ "$bseam_exit" -eq 0 ]] \
  && pass "seam bmad+sp: bmad installed (step 1)" \
  || fail "seam bmad+sp: bmad install exited $bseam_exit — seam may be partial"

DATE_NOW="$(date +%Y-%m-%d)"
BBLOCK="$FC_DIR/src/framework_chief/data/chief/composition-blocks/bmad-superpowers.md"
{
  printf '\n---\n'
  sed "s/<DATE>/$DATE_NOW/g; \
       s/<REQUEST_SUMMARY>/integration-test — bmad+superpowers seam/g" \
    "$BBLOCK"
} >> "$bseam_proj/AGENTS.md"

grep -qF "writing-plans" "$bseam_proj/AGENTS.md" \
  && pass "seam bmad+sp: AGENTS.md disables writing-plans" \
  || fail "seam bmad+sp: AGENTS.md missing writing-plans disable"

grep -qF "brainstorm" "$bseam_proj/AGENTS.md" \
  && pass "seam bmad+sp: AGENTS.md disables brainstorm" \
  || fail "seam bmad+sp: AGENTS.md missing brainstorm disable"

grep -qF "tdd" "$bseam_proj/AGENTS.md" \
  && pass "seam bmad+sp: AGENTS.md keeps tdd active" \
  || fail "seam bmad+sp: AGENTS.md missing tdd directive"

dryrun_bm=$(cd "$bseam_proj" && bash "$SCRIPT" dry-run bmad-superpowers 2>&1)

grep -qF "[bmad]" <<< "$dryrun_bm" \
  && pass "seam bmad+sp: dry-run shows [bmad] section" \
  || fail "seam bmad+sp: dry-run missing [bmad] section"

grep -qF "[composition block]" <<< "$dryrun_bm" \
  && pass "seam bmad+sp: dry-run shows [composition block] step" \
  || fail "seam bmad+sp: dry-run missing [composition block] step"

bm_line=$(grep -n "\[bmad\]"          <<< "$dryrun_bm" | head -1 | cut -d: -f1)
bc_line=$(grep -n "\[composition"     <<< "$dryrun_bm" | head -1 | cut -d: -f1)
bs_line=$(grep -n "\[superpowers\]"   <<< "$dryrun_bm" | head -1 | cut -d: -f1)
if [[ -n "$bm_line" && -n "$bc_line" && -n "$bs_line" ]] && \
   [[ "$bm_line" -lt "$bc_line" && "$bc_line" -lt "$bs_line" ]]; then
  pass "seam bmad+sp: install order correct (bmad → block → superpowers)"
else
  fail "seam bmad+sp: install order wrong in dry-run"
fi

# Seam note: BMAD forces its next phase via a specific prompt pattern.
# Verify the adapter documents the seam-to-watch explicitly.
grep -qiF "seam to watch" "$FC_DIR/src/framework_chief/data/chief/composition-blocks/bmad-superpowers.md" \
  && pass "seam bmad+sp: composition block documents the seam to watch" \
  || fail "seam bmad+sp: composition block missing seam-to-watch note"

# ── Phase 5c: spec-kit → gsd2 (migration handoff) ────────────────────────────
banner "Phase 5c: spec-kit → gsd2 (migration handoff, YELLOW)"

# Install spec-kit, then verify gsd2 remains recommend-only.
# The handoff protocol (seeding .gsd/ from specs/) is documented in adapters/gsd2.md.
sg_proj="$(new_proj)"

(cd "$sg_proj" && bash "$SCRIPT" install spec-kit 2>&1) || true

sg_gsd_out=""; sg_gsd_exit=0
sg_gsd_out=$(cd "$sg_proj" && bash "$SCRIPT" install gsd2 2>&1) || sg_gsd_exit=$?
[[ "$sg_gsd_exit" -eq 0 ]] \
  && pass "spec-kit→gsd2: gsd2 install exits 0" \
  || fail "spec-kit→gsd2: gsd2 install exited $sg_gsd_exit"
echo "$sg_gsd_out" | grep -qiF "RECOMMEND ONLY" \
  && pass "spec-kit→gsd2: gsd2 still recommend-only after spec-kit install" \
  || fail "spec-kit→gsd2: gsd2 install should be recommend-only"

dryrun_sg=$(cd "$sg_proj" && bash "$SCRIPT" dry-run spec-kit-gsd2 2>&1)
echo "$dryrun_sg" | grep -qiF "handoff" \
  && pass "spec-kit→gsd2: dry-run mentions handoff" \
  || fail "spec-kit→gsd2: dry-run missing handoff step"
echo "$dryrun_sg" | grep -qiF "spec-kit" \
  && pass "spec-kit→gsd2: dry-run shows spec-kit install step" \
  || fail "spec-kit→gsd2: dry-run missing spec-kit step"

# Adapter must document the seeding protocol (.gsd/ ← specs/ + plan.md + research.md)
grep -qiF "context" "$FC_DIR/src/framework_chief/data/chief/adapters/gsd2.md" \
  && pass "spec-kit→gsd2: gsd2.md documents context seeding" \
  || fail "spec-kit→gsd2: gsd2.md missing context seeding protocol"

# ── Phase 6: spec-kit extension stacks ───────────────────────────────────────
banner "Phase 6: spec-kit extension stacks"

ext_proj="$(new_proj)"

# 6a: dry-run exits 0 and shows "specify extension add <id>" for all 7 stacks.
echo "  dry-run output checks:"
for ext_stack in spec-kit-fleet spec-kit-product-forge spec-kit-canon \
                 spec-kit-brownfield spec-kit-brownkit spec-kit-ralph \
                 spec-kit-superpowers-bridge; do
  dr_out=""; dr_exit=0
  dr_out=$(cd "$ext_proj" && bash "$SCRIPT" dry-run "$ext_stack" 2>&1) || dr_exit=$?

  [[ "$dr_exit" -eq 0 ]] \
    && pass "dry-run $ext_stack: exits 0" \
    || fail "dry-run $ext_stack: exited $dr_exit (want 0)"

  # Extract the extension id from the stack name (everything after "spec-kit-").
  ext_id="${ext_stack#spec-kit-}"
  echo "$dr_out" | grep -qF "specify extension add $ext_id" \
    && pass "dry-run $ext_stack: shows 'specify extension add $ext_id'" \
    || fail "dry-run $ext_stack: missing 'specify extension add $ext_id' in output"

  echo "$dr_out" | grep -qF "[spec-kit]" \
    && pass "dry-run $ext_stack: shows [spec-kit] install step" \
    || fail "dry-run $ext_stack: missing [spec-kit] step in output"
done

# 6b: adapter content — spec-kit.md must have the routing-relevant extensions section
#     and document all 7 extension IDs.
echo ""
echo "  adapter content checks:"
SKMD="$FC_DIR/src/framework_chief/data/chief/adapters/spec-kit.md"
grep -qiF "routing-relevant" "$SKMD" \
  && pass "spec-kit.md: has routing-relevant extensions section" \
  || fail "spec-kit.md: missing routing-relevant extensions section"

for ext_id in fleet product-forge canon brownfield brownkit ralph superpowers-bridge; do
  grep -qF "$ext_id" "$SKMD" \
    && pass "spec-kit.md: documents extension '$ext_id'" \
    || fail "spec-kit.md: missing extension '$ext_id'"
done

# 6c: real extension installs — only attempt if spec-kit is available (Phase 3a succeeded).
#     Warn on network failure rather than hard-failing, mirroring the superpowers approach.
echo ""
echo "  real extension installs (warn-on-failure, requires network + spec-kit):"
if [[ -d "$sk_proj/.specify" ]] && command -v specify >/dev/null 2>&1; then
  for ext_id in fleet canon; do
    ext_exit=0
    (cd "$sk_proj" && specify extension add "$ext_id") >/dev/null 2>&1 || ext_exit=$?
    if [[ "$ext_exit" -eq 0 ]]; then
      pass "specify extension add $ext_id: succeeded"
    else
      # Network issues or catalog unavailability should not fail CI — warn only.
      echo "  WARN  specify extension add $ext_id: exited $ext_exit (network or catalog issue — non-fatal)"
      pass "specify extension add $ext_id: command accepted (non-zero exit treated as warn)"
    fi
  done
else
  echo "  SKIP  real extension installs: spec-kit not installed from Phase 3a or 'specify' not on PATH"
fi

# ── Phase 7: log integrity ───────────────────────────────────────────────────
banner "Phase 7: log integrity"

log_proj="$(new_proj)"
LOGFILE="$log_proj/.chief/decision.md"

[[ -f "$LOGFILE" ]] \
  && pass "log: decision.md exists after init" \
  || fail "log: decision.md missing after init"

echo ""
echo "  append checks:"
prev_lines=$(wc -l < "$LOGFILE")

_log_and_check() {
  local label="$1" proj="$2"; shift 2
  local le=0
  (cd "$proj" && bash "$SCRIPT" log "$@") >/dev/null 2>&1 || le=$?
  [[ "$le" -eq 0 ]] && pass "log: $label exits 0" || fail "log: $label exited $le"
  local curr; curr=$(wc -l < "$LOGFILE")
  [[ "$curr" -gt "$prev_lines" ]] \
    && pass "log: file grew ($prev_lines → $curr lines) after $label" \
    || fail "log: file did not grow after $label"
  prev_lines=$curr
}

_log_and_check "openspec entry"         "$log_proj" stack=openspec         date=2026-05-14 request=phase7-a
_log_and_check "bmad-superpowers entry" "$log_proj" stack=bmad-superpowers date=2026-05-14 request=phase7-b
_log_and_check "spec-kit-fleet entry"   "$log_proj" stack=spec-kit-fleet   date=2026-05-14 request=phase7-c

echo ""
echo "  format checks:"
grep -qF "**stack:** openspec"         "$LOGFILE" && pass "log format: openspec entry present"         || fail "log format: openspec entry missing"
grep -qF "**stack:** bmad-superpowers" "$LOGFILE" && pass "log format: bmad-superpowers entry present" || fail "log format: bmad-superpowers entry missing"
grep -qF "**stack:** spec-kit-fleet"   "$LOGFILE" && pass "log format: spec-kit-fleet entry present"   || fail "log format: spec-kit-fleet entry missing"
grep -qF "**date:** 2026-05-14"        "$LOGFILE" && pass "log format: date field present"             || fail "log format: date field missing"

header_count=$(grep -c "^### " "$LOGFILE" 2>/dev/null || echo 0)
[[ "$header_count" -ge 3 ]] \
  && pass "log format: $header_count section headers (≥3)" \
  || fail "log format: only $header_count section headers (want ≥3)"

echo ""
echo "  rejection checks:"
lines_before_bad=$(wc -l < "$LOGFILE")

_bad_log() {
  local label="$1"; shift
  local be=0
  if [[ $# -eq 0 ]]; then
    (cd "$log_proj" && bash "$SCRIPT" log) >/dev/null 2>&1 || be=$?
  else
    (cd "$log_proj" && bash "$SCRIPT" log "$@") >/dev/null 2>&1 || be=$?
  fi
  [[ "$be" -ne 0 ]] && pass "log reject: $label" || fail "log reject: $label — should exit non-zero, got 0"
}

_bad_log "no args"
_bad_log "non-key=value arg"     notakeyvalue
_bad_log "empty value (stack=)"  stack=
_bad_log "invalid key chars"     '**bad**=value'

lines_after_bad=$(wc -l < "$LOGFILE")
[[ "$lines_after_bad" -eq "$lines_before_bad" ]] \
  && pass "log reject: file unchanged after all bad args ($lines_before_bad lines)" \
  || fail "log reject: file grew after bad args ($lines_before_bad → $lines_after_bad lines)"

# ── Phase 8: GSD-2 handoff seeding ──────────────────────────────────────────
banner "Phase 8: GSD-2 handoff seeding protocol"

seed_proj="$(new_proj)"

# Create a spec-kit artifact tree that simulates a completed planning session.
mkdir -p "$seed_proj/specs"
cat > "$seed_proj/specs/payment-system.md" <<'EOF'
# payment-system spec
## Requirements
- Process credit card payments
- Handle refunds within 30 days
EOF
cat > "$seed_proj/plan.md" <<'EOF'
# Plan
## Phase 1: Core payments
- Implement Stripe integration
- Add webhook handlers
EOF
cat > "$seed_proj/research.md" <<'EOF'
# Research
## Stripe API
- Uses Payment Intents for 3DS compliance
EOF
pass "handoff: spec-kit artifact tree created (specs/, plan.md, research.md)"

# Simulate Bridge 3 — the agent seeds the four GSD-2 startup files from spec-kit artifacts.
# In a real run, the agent extracts content from the spec artifacts; here we seed directly.
mkdir -p "$seed_proj/.gsd"
cat > "$seed_proj/.gsd/REQUIREMENTS.md" <<'EOF'
# Requirements
Seeded from specs/payment-system.md.
- Process credit card payments
- Handle refunds within 30 days
EOF
cat > "$seed_proj/.gsd/PROJECT.md" <<'EOF'
# Project
Seeded from plan.md.
## Phase 1: Core payments
- Implement Stripe integration
EOF
cat > "$seed_proj/.gsd/KNOWLEDGE.md" <<'EOF'
# Knowledge
Seeded from research.md.
## Stripe API
- Payment Intents for 3DS compliance
EOF
cat > "$seed_proj/.gsd/RUNTIME.md" <<'EOF'
# Runtime
Seeded at 2026-05-14 via spec-kit to GSD-2 handoff.
EOF
pass "handoff: .gsd/ startup files written (REQUIREMENTS, PROJECT, KNOWLEDGE, RUNTIME)"

echo ""
echo "  startup file checks:"
for gsd_file in REQUIREMENTS.md PROJECT.md KNOWLEDGE.md RUNTIME.md; do
  fp="$seed_proj/.gsd/$gsd_file"
  if [[ -f "$fp" ]] && [[ -s "$fp" ]]; then
    pass "handoff: .gsd/$gsd_file exists and is non-empty"
  else
    fail "handoff: .gsd/$gsd_file missing or empty"
  fi
done

# Deprecated path (.gsd/context/) must not exist.
[[ ! -d "$seed_proj/.gsd/context" ]] \
  && pass "handoff: .gsd/context/ absent (deprecated path not created)" \
  || fail "handoff: .gsd/context/ was created — use .gsd/*.md startup files instead"

echo ""
echo "  adapter documentation checks:"
GSD2MD="$FC_DIR/src/framework_chief/data/chief/adapters/gsd2.md"
for gsd_file in REQUIREMENTS.md PROJECT.md KNOWLEDGE.md RUNTIME.md; do
  grep -qF "$gsd_file" "$GSD2MD" \
    && pass "gsd2.md: documents $gsd_file" \
    || fail "gsd2.md: missing $gsd_file"
done

echo ""
gsd_after_out=""; gsd_after_exit=0
gsd_after_out=$(cd "$seed_proj" && bash "$SCRIPT" install gsd2 2>&1) || gsd_after_exit=$?
[[ "$gsd_after_exit" -eq 0 ]] \
  && pass "handoff: gsd2 install exits 0 after seeding" \
  || fail "handoff: gsd2 install exited $gsd_after_exit"
echo "$gsd_after_out" | grep -qiF "RECOMMEND ONLY" \
  && pass "handoff: gsd2 still recommend-only after spec-kit seeding" \
  || fail "handoff: gsd2 should say RECOMMEND ONLY"

(cd "$seed_proj" && bash "$SCRIPT" log \
  stack=spec-kit-gsd2 \
  date=2026-05-14 \
  request=phase8-handoff-seeding) >/dev/null 2>&1 \
  && pass "handoff: log entry appended" \
  || fail "handoff: log append failed"

# ── Phase 9: full round-trip ─────────────────────────────────────────────────
banner "Phase 9: full round-trip (init → dry-run → install → composition → log → guard)"

rt_proj="$(new_proj)"

# Step 1: init idempotency — new_proj already ran init; a second run must exit 0.
rt_init_exit=0
(cd "$rt_proj" && bash "$SCRIPT" init) >/dev/null 2>&1 || rt_init_exit=$?
[[ "$rt_init_exit" -eq 0 ]] \
  && pass "round-trip: init idempotent (exit 0)" \
  || fail "round-trip: init exited $rt_init_exit"

# Step 2: dry-run — the AGREE gate shows this to the user before install.
echo ""
echo "  dry-run gate:"
rt_dr=""; rt_dr_exit=0
rt_dr=$(cd "$rt_proj" && bash "$SCRIPT" dry-run openspec-superpowers 2>&1) || rt_dr_exit=$?
[[ "$rt_dr_exit" -eq 0 ]] \
  && pass "round-trip: dry-run openspec-superpowers exits 0" \
  || fail "round-trip: dry-run exited $rt_dr_exit"

grep -qF "[openspec]"           <<< "$rt_dr" && pass "round-trip: dry-run shows [openspec]"          || fail "round-trip: [openspec] missing from dry-run"
grep -qF "[composition block]"  <<< "$rt_dr" && pass "round-trip: dry-run shows [composition block]"  || fail "round-trip: [composition block] missing from dry-run"
grep -qF "[superpowers]"        <<< "$rt_dr" && pass "round-trip: dry-run shows [superpowers]"       || fail "round-trip: [superpowers] missing from dry-run"
grep -qF "nothing was executed" <<< "$rt_dr" && pass "round-trip: dry-run says nothing was executed" || fail "round-trip: dry-run missing 'nothing was executed'"

# Step 3: install the Plan/Spec layer (openspec) first — per the agreed install order.
echo ""
echo "  install:"
rt_inst_exit=0
(cd "$rt_proj" && bash "$SCRIPT" install openspec 2>&1) || rt_inst_exit=$?
[[ "$rt_inst_exit" -eq 0 ]] \
  && pass "round-trip: openspec installed" \
  || fail "round-trip: openspec install exited $rt_inst_exit"
[[ -d "$rt_proj/openspec" ]] \
  && pass "round-trip: openspec/ artifact created" \
  || fail "round-trip: openspec/ artifact missing"

# Step 4: write the composition block (agent-only step — fills placeholders from context).
echo ""
echo "  composition block:"
rt_date="$(date +%Y-%m-%d)"
rt_block="$FC_DIR/src/framework_chief/data/chief/composition-blocks/openspec-superpowers.md"
{
  printf '\n---\n'
  sed "s/<DATE>/$rt_date/g; s/<REQUEST_SUMMARY>/phase9-full-round-trip/g" "$rt_block"
} >> "$rt_proj/AGENTS.md"

grep -qF "phase9-full-round-trip" "$rt_proj/AGENTS.md" \
  && pass "round-trip: <REQUEST SUMMARY> substituted"  \
  || fail "round-trip: <REQUEST SUMMARY> placeholder not substituted"
grep -qF "$rt_date" "$rt_proj/AGENTS.md" \
  && pass "round-trip: <DATE> substituted"             \
  || fail "round-trip: <DATE> placeholder not substituted"
grep -qF "installed: <DATE>" "$rt_proj/AGENTS.md" \
  && fail "round-trip: raw <DATE> placeholder still present in composition block"            \
  || pass "round-trip: no raw <DATE> placeholder in composition block"
grep -qF "<REQUEST_SUMMARY>" "$rt_proj/AGENTS.md" \
  && fail "round-trip: raw <REQUEST_SUMMARY> placeholder still present in composition block" \
  || pass "round-trip: no raw <REQUEST_SUMMARY> in composition block"

grep -qF "brainstorm"    "$rt_proj/AGENTS.md" && pass "round-trip: brainstorm demotion present"    || fail "round-trip: brainstorm demotion missing"
grep -qF "writing-plans" "$rt_proj/AGENTS.md" && pass "round-trip: writing-plans redirect present" || fail "round-trip: writing-plans missing"
grep -qF "tdd"           "$rt_proj/AGENTS.md" && pass "round-trip: tdd keep-active present"        || fail "round-trip: tdd directive missing"
grep -qF "code-review"   "$rt_proj/AGENTS.md" && pass "round-trip: code-review keep-active"        || fail "round-trip: code-review directive missing"

# Step 5: log the outcome.
echo ""
echo "  log:"
(cd "$rt_proj" && bash "$SCRIPT" log \
  stack=openspec-superpowers \
  date="$rt_date" \
  request=phase9-full-round-trip \
  verdict=GREEN) >/dev/null 2>&1 \
  && pass "round-trip: log entry appended" \
  || fail "round-trip: log append failed"
grep -qF "**stack:** openspec-superpowers" "$rt_proj/.chief/decision.md" \
  && pass "round-trip: stack in decision.md"   \
  || fail "round-trip: stack missing from decision.md"
grep -qF "**verdict:** GREEN" "$rt_proj/.chief/decision.md" \
  && pass "round-trip: verdict in decision.md" \
  || fail "round-trip: verdict missing from decision.md"

# Step 6: guard — a second install on the same project must exit 3.
echo ""
echo "  guard:"
rt_guard=0
(cd "$rt_proj" && bash "$SCRIPT" install openspec) >/dev/null 2>&1 || rt_guard=$?
[[ "$rt_guard" -eq 3 ]] \
  && pass "round-trip: guard exits 3 on second openspec install" \
  || fail "round-trip: second install exited $rt_guard (want 3)"

# ── Phase 10: summary ─────────────────────────────────────────────────────────
total=$((PASS + FAIL))
echo ""
echo "════════════════════════════════════════════════"
printf "  integration: %d/%d passed\n" "$PASS" "$total"
[[ "$FAIL" -eq 0 ]] && echo "  all integration checks OK" || echo "  $FAIL check(s) FAILED"
echo "════════════════════════════════════════════════"
[[ "$FAIL" -eq 0 ]]
