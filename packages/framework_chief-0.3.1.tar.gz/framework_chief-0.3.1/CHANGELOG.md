# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/).

---

## [0.3.1] — 2026-05-22

### Fixed
- `.gitattributes` — `*.ps1 text eol=crlf` rule ensures PowerShell scripts are always
  checked out / packaged with CRLF line endings; `powershell.exe` v5.1 fails to parse
  here-strings with LF-only line endings (closes #9).
- `phases.py` — `_exec_copy_scripts` now normalises deployed `.ps1` files to CRLF on
  Windows as a safety net for users with existing LF-only installs.
- `chief-install.ps1` — `Run` helper: replaced invalid `@Command[1..]` splatting-with-
  index syntax with destructuring assignment (`$exe, $rest = $Command; & $exe @rest`);
  `$key:` in a double-quoted string now written as `${key}:` to avoid the colon being
  parsed as a scope qualifier. Both were parse errors under `pwsh` 7+.
- `chief-install.ps1` — `Invoke-Install`: replaced `Invoke-Expression $cmd` (unsafe
  string eval, security finding) with `$exe, $rest = $cmd -split '\s+'; & $exe @rest`,
  consistent with the `Run` helper pattern.
- `chief-install.ps1` — `Invoke-Log`: renamed `param([string[]]$Args)` to
  `param([string[]]$Pairs = @())` — `$Args`/`$args` is a PowerShell automatic variable;
  using it as a named parameter under `Set-StrictMode -Version Latest` caused the
  parameter to appear null, so zero-arg validation silently short-circuited. Changed the
  zero-arg guard to `-not $Pairs` to handle the null-vs-empty-array distinction correctly.
- `chief-install.ps1` — `Miss` and `Err` helpers: replaced `Write-Error` with
  `$host.UI.WriteErrorLine()`. With `$ErrorActionPreference = 'Stop'` at the top of the
  script, `Write-Error` throws a terminating exception before any subsequent `exit N` or
  `$fail = 1` line can execute, causing `check bogus-framework` to exit 1 instead of 2
  and prereq-miss paths to exit 1 before setting `$fail`. `$host.UI.WriteErrorLine()`
  writes to stderr without throwing, so explicit exit codes are correctly honoured.

---

## [0.3.0] — 2026-05-22

### Added
- `src/framework_chief/_shell.py` — `_shell_cmd()` auto-detects the right interpreter at runtime (`pwsh`/`powershell` on Windows, `bash` elsewhere) and returns a ready-to-pass argument prefix; `_split_cmd()` uses `.split()` on Windows instead of `shlex.split()` to avoid POSIX quoting issues with Windows paths. Single dispatch point; all callsites import from here — no hardcoded `"bash"` anywhere.
- `src/framework_chief/data/scripts/chief-install.ps1` and `chief-sync.ps1` — faithful PowerShell 7+ ports of the bash originals, bundled so `chief init` deploys them alongside the `.sh` versions on every platform.
- CI unit job extended to a matrix `[ubuntu-latest, windows-latest]` — Python shell-dispatch verified on both platforms.
- `tests/unit/test_shell.py` — 14 tests covering all branches of `_shell_cmd` and `_split_cmd`: platform mocking, `pwsh`/`powershell` discovery order, fallback to `bash`, `RuntimeError` when nothing is found.
- `tests/unit/test_phases.py` extended with 5 new tests: `always_run=True` bypasses the skip guard even when the artifact exists; `always_run=False` still skips; `copy_scripts` phase asserts `always_run=True` (so `.ps1` upgrades propagate); `_exec_wire_agents` returns `failed` on `RuntimeError` and on `FileNotFoundError`.
- `tests/unit/test_cli.py` — 2 tests for `cmd_sync`: both `RuntimeError` and `FileNotFoundError` from `_shell_cmd` return exit code 127.
- `tests/mechanical/run-mechanical.ps1` — PowerShell 7+ port of `run-mechanical.sh`; covers `chief-sync.ps1` idempotency (3 runs, exit 0), CLAUDE.md overlay correctness, Copilot marker count, `.claude/commands/chief.md`, `.codex/prompts/chief.md`, `--ai` isolation for each target (claude/copilot/codex), and non-zero exit on missing `AGENTS.md`.
- CI `mechanical-ps1` job on `windows-latest` — runs `tests/mechanical/run-mechanical.ps1` via `pwsh`, 10-minute cap.
- `docs/adrs/ADR-0008-shell-auto-detect.md` — records the decision to use auto-detect instead of an explicit `--shell` flag, the rationale, and the `.ps1` sibling extension contract.

### Changed
- `cli.py` and `phases.py` — all subprocess invocations now go through `_shell_cmd()` / `_split_cmd()` instead of hardcoded `["bash", ...]` / `shlex.split()`.
- `cmd_sync` in `cli.py` now catches `RuntimeError` (raised by `_shell_cmd` when no interpreter is found) in addition to `FileNotFoundError`, returning 127 in both cases.

### Removed
- Root `scripts/` directory deleted — was a duplicate of `src/framework_chief/data/scripts/` with no tooling pointing at it. The authoritative copies live in `data/scripts/` and are what `chief init` deploys.

---

## [0.2.0] — 2026-05-19

### Added
- `chief route` subcommand — conversational stack routing from the terminal without opening an agent session. Sends the project description to an AI provider (Anthropic, OpenAI, or GitHub Models) with `AGENTS.md` as the system prompt, runs the classify → clarify → agree loop, and prints the recommended stack with next-step commands on AGREE. Requires `pip install 'framework-chief[route]'`.
- Multi-provider support in `chief route`: `--provider anthropic` (default, Claude), `--provider openai` (GPT-4o), `--provider github` (GitHub Copilot via GitHub Models API). `--model` flag overrides the provider default.
- Loading spinner (`Rich console.status()`) in `chief route` — animated dots while the API call is in-flight; disappears cleanly when the response arrives.
- Sentinel hardening in `route.py`: `_strip_fenced_blocks()` prevents false sentinel matches inside code blocks; `_VALID_STATES` / `_VALID_VERDICT_PATTERNS` frozensets validate state and verdict values before acting on them; `MAX_SENTINEL_RETRIES = 3` and `MAX_LOOP_ITERATIONS = 20` guard against stuck loops; 4-tuple `_strip_sentinel` return surfaces error messages for malformed sentinels without crashing.
- `compose.py` hardening: `_AUTO_RESOLVERS` dispatch table (keyed by placeholder name) replaces the flat resolver that returned today's date for any auto placeholder; bidirectional placeholder validation checks declared-in-meta ↔ body-token agreement in both directions; post-resolver leakage check raises `CompositionError` if a `required` token survives unfilled; atomic file write via `tempfile.NamedTemporaryFile` + `Path.replace()` prevents partial writes from corrupting AGENTS.md; empty body guard rejects blocks with no content before reaching the resolver pass.
- 6 new unit tests in `tests/unit/test_compose.py` covering: `_AUTO_RESOLVERS` dispatch, unknown auto placeholder error, bidirectional validation (both directions), post-resolver leakage, atomic write behaviour.
- Unit test suite for four pure domain modules — `checks`, `compose`, `decision_log`, `phases` — 92 tests, ~0.5 s, no subprocess, no LLM required
- `tests/unit/test_registry.py` — REGISTRY consistency tests (replaces `test_cli.py`)
- `tests/unit/test_checks.py` — prereq check logic and version string parsing (14 tests)
- `tests/unit/test_compose.py` — composition block apply, resolver logic, monkeypatched block dir (10 tests)
- `tests/unit/test_decision_log.py` — append-only log bootstrap, parse-and-append, last-stack query (12 tests)
- `tests/unit/test_phases.py` — phase checkpointing: skip / run / force / symlink (8 tests)
- `unit` CI job in `.github/workflows/ci.yml` — `uv run pytest tests/unit/ -v`, no Docker, 5 min cap
- README: `chief route` and `chief compose` documented in the Advanced CLI `<details>` block with provider options and usage examples
- README: "What it looks like" — concrete example interaction (classify → agree → install)
- README: "The five frameworks" — one-row mini-glossary so the routing table has grounding
- README: "Prerequisites" table (Python, uv, git, Node)
- README: "Get started" revamped as a three-step flow with per-agent wiring table and advanced CLI in `<details>`
- `CONTRIBUTING.md` — routing eval harness, test layer architecture, CI setup, development workflow
- `CHANGELOG.md` (this file)

### Changed
- `max_tokens` raised from 2048 → 4096 in both `_call_anthropic` and `_call_openai` — long AGREE responses (especially BMAD + Superpowers with full composition block) were silently truncated at the old limit.
- README "Status" updated to reflect the full Python CLI surface including `route` (AI API calls) and `compose` (atomic AGENTS.md writes); version label bumped from `v0` to `v0.1`
- `tests/unit/test_cli.py` renamed to `tests/unit/test_registry.py` — filename now matches what is tested
- README "Status" trimmed to v0 disclaimer + two seams-to-watch; eval harness details moved to `CONTRIBUTING.md`
- README "What's in the box" updated to reflect all five unit test files and the new CI job

---

## [0.1.0] — 2026-05-14

### Added

**Core routing model**
- `AGENTS.md` — rubric, three-slot model, compatibility matrix, bridge descriptions, and the full classify → clarify → agree → install loop with the human gate
- Five framework adapters (`spec-kit`, `OpenSpec`, `BMAD`, `GSD-2`, `Superpowers`) covering prereqs, detection markers, install commands, and composition notes
- Composition blocks for GREEN and YELLOW hybrids: `openspec-superpowers.md`, `bmad-superpowers.md`

**CLI and Python package**
- `src/framework_chief/` — `cli.py`, `stacks.py`, `checks.py`, `compose.py`, `decision_log.py`, `phases.py`, `project.py`, `renderer.py`
- `pyproject.toml` — package definition, `chief` entry point, uv toolchain, Python 3.11+ requirement
- `scripts/chief-install.sh` — prereq check, dry-run, install, and decision-log subcommands
- `scripts/chief-sync.sh` — propagates `AGENTS.md` to `CLAUDE.md` (symlink), `.github/copilot-instructions.md`, `.codex/prompts`

**Test infrastructure**
- Mechanical tests (`tests/mechanical/run-mechanical.sh`) — bash-only, no Docker, no LLM; dry-run exit codes, check prereqs, init idempotency, log validation, sync marker count
- Integration tests (`tests/integration/`) — full install round-trips in Docker (node:20-bookworm + uv), phases 0–10 including log integrity, GSD-2 handoff seeding, and spec-kit → GSD-2 round-trip
- Demo workflow (`tests/integration/demo-workflow.sh`) — seven end-to-end scenarios (A–G): OpenSpec solo, OpenSpec + Superpowers (GREEN), BMAD + Superpowers (YELLOW), spec-kit solo, spec-kit + canon, spec-kit + fleet (CLARIFY path), BMAD + OpenSpec RED refusal
- `tests/eval/routing-cases.md` — 28 routing cases covering direct routes, CLARIFY paths, RED refusals, YELLOW pairs, edge cases, and all spec-kit extensions
- `tests/eval/eval-routing.py` — automated routing eval harness; sends each case to the Claude API, parses the `CHIEF_EVAL` sentinel, compares state + verdict against expected

**CI**
- `.github/workflows/ci.yml` — mechanical + integration + demo jobs on push/PR to main
- `.github/workflows/routing-eval.yml` — routing eval on `AGENTS.md` or routing-cases changes (requires `ANTHROPIC_API_KEY` secret)

**Documentation and design**
- ADRs 0001–0006 covering: Python registry dispatch, YAML front-matter adapters, compose subcommand, init phase pipeline, Python test seam, Claude overlay model
- Decision flow diagram (`docs/assets/decision-flow.svg`)
- `docs/context/` — domain glossary

### Fixed
- Sync tests now run unconditionally; previously skipped when `CLAUDE.md` was gitignored (meta-repo context). Replaced with temp-project approach using `mktemp -d` + `git init`.

### Changed
- Composition block templates now include `superpowers_version` (and `bmad_version` for the BMAD pair) — version mismatches surface as stale fields rather than silently ignored skill names
