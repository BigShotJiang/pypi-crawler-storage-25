from typing_extensions import Sequence
from dataclasses import dataclass
from datetime import datetime
from decimal import Decimal
import asyncio

from trading_sdk.reporting import Snapshots as _Snapshots, Snapshot
from hyperliquid import Info

@dataclass
class Snapshots(_Snapshots):
  info: Info
  address: str

  @classmethod
  def http(cls, address: str, *, validate: bool = True, mainnet: bool = True):
    info = Info.http(validate=validate, mainnet=mainnet)
    return cls(info, address)
  
  @classmethod
  def ws(cls, address: str, *, validate: bool = True, mainnet: bool = True):
    info = Info.ws(validate=validate, mainnet=mainnet)
    return cls(info, address)

  async def spot_snapshots(self):
    spot = await self.info.spot_clearinghouse_state(self.address)
    time = datetime.now().astimezone()
    return [
      Snapshot(asset=balance['coin'], time=time, qty=Decimal(balance['total']), kind='currency')
      for balance in spot['balances']
    ]

  async def dex_snapshots(self, dex: str | None):
    state = await self.info.clearinghouse_state(self.address, dex=dex)
    time = datetime.now().astimezone()
    return [
      Snapshot(asset=p['position']['coin'], time=time, qty=Decimal(p['position']['szi']), kind='future')
      for p in state['assetPositions']
    ]

  async def perp_snapshots(self):
    dexs = await self.info.perp_dexs()
    nested_snapshots = await asyncio.gather(*[
      self.dex_snapshots(dex and dex['name'])
      for dex in dexs
    ])
    return [s for ss in nested_snapshots for s in ss]

  async def snapshots(self, assets: Sequence[str] = []) -> list[Snapshot]:
    spot_snaps, perp_snaps = await asyncio.gather(
      self.spot_snapshots(),
      self.perp_snapshots(),
    )
    return spot_snaps + perp_snaps