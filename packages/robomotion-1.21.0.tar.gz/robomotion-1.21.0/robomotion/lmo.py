import json
import os
import shutil
import sys
import tempfile
import threading
import time

import xxhash
import zstandard as zstd

MAGIC = 20260301
THRESHOLD = 4096  # 4KB

# On Windows, MoveFileEx and CreateFile interact through share modes:
# Python's built-in open() omits FILE_SHARE_DELETE, so a concurrent reader
# prevents the writer's os.replace (PermissionError "Access is denied"),
# and a rename-in-flight briefly blocks new opens. POSIX rename(2) has no
# such race. Retry transient share violations with exponential backoff.
_IS_WINDOWS = sys.platform == "win32"
_MAX_FILE_RETRIES = 16
_INITIAL_FILE_BACKOFF = 0.0001  # 100 us
_MAX_FILE_BACKOFF = 0.008  # 8 ms


def _retry_share_violation(op):
    """Run ``op`` retrying transient Windows PermissionErrors. No-op on POSIX."""
    if not _IS_WINDOWS:
        return op()
    backoff = _INITIAL_FILE_BACKOFF
    last_err = None
    for _ in range(_MAX_FILE_RETRIES):
        try:
            return op()
        except PermissionError as exc:
            last_err = exc
            time.sleep(backoff)
            backoff = min(backoff * 2, _MAX_FILE_BACKOFF)
    raise last_err


class Store:
    """Content-addressed, zstd-compressed blob store.
    Mirrors Go's lmo.Store — all operations are methods on this class.
    """

    def __init__(self, config_dir, store_root=None):
        self.config_dir = config_dir
        # store_root is the directory that contains robots/<rid>/flows/<fid>/blobs/...
        # Defaults to <config_dir>/store (host mode); inside the Hermes/ADK
        # sandbox the launcher sets ROBOMOTION_LMO_STORE_DIR so this points
        # at the bind-mounted host store instead of the container-local path.
        self.store_root = store_root or os.path.join(config_dir, "store")
        self.rel_path = ""
        self._compressor = zstd.ZstdCompressor()
        self._decompressor = zstd.ZstdDecompressor()
        # python-zstandard's ZstdCompressor/ZstdDecompressor instances are
        # documented as not thread-safe. Serialize codec calls so concurrent
        # put_blob/get_blob from different threads can't corrupt each other.
        self._codec_lock = threading.Lock()

    def set_rel_path(self, rel_path):
        """Set the relative path and create the blobs directory.

        rel_path uses forward-slash separators (it is the protocol value that
        appears in BlobRef envelopes' ``__path`` field — cross-SDK
        compatibility requires forward slashes). Filesystem paths are built
        via ``_fs_join`` which splits on ``/`` so the OS-native separator is
        used on disk.
        """
        self.rel_path = rel_path
        blob_dir = self._fs_join("store", rel_path, "blobs")
        os.makedirs(blob_dir, exist_ok=True)

    def _fs_join(self, *parts):
        """Join path components into an OS-native filesystem path.

        Each component may itself contain ``/`` segments (e.g. rel_path is
        ``"robots/<rid>/flows/<fid>"``); those are split so os.path.join
        produces a clean path with one separator style.

        A leading "store" component is rewritten to self.store_root so the
        sandbox-mode env override (ROBOMOTION_LMO_STORE_DIR) takes effect
        without changing every callsite. All existing callers pass "store"
        as the first part — set_rel_path, _blob_path_local, _blob_path_for,
        and purge — so this rewrite is transparent.
        """
        if parts and parts[0] == "store":
            segments = [self.store_root]
            rest = parts[1:]
        else:
            segments = [self.config_dir]
            rest = parts
        for p in rest:
            segments.extend(p.split("/"))
        return os.path.join(*segments)

    # ── blob I/O ──

    def put_blob(self, data):
        """Store data as a zstd-compressed blob. Returns its XXH3-128 ref.

        If a non-empty blob already exists at the target path, dedup skips
        writing.

        Atomic write: compressed bytes go to a unique tmp file in the same
        directory then ``os.replace`` onto the final path. This eliminates the
        race where a concurrent reader sees the file mid-write and either
        dedup-skips with partial bytes or reads truncated content — surfacing
        upstream as a zstd "unexpected EOF" decompress error.

        Dedup verifies the existing file is non-empty before trusting it. A
        zero-byte file (left by a prior crash before this fix, or by an
        unrelated tool) is rewritten rather than honored.
        """
        ref = _hash_ref(data)
        p = self._blob_path_local(ref)
        try:
            if os.path.getsize(p) > 0:
                return ref  # already exists, non-empty — trust it
        except OSError:
            pass  # missing or unreadable — fall through to write

        directory = os.path.dirname(p)
        os.makedirs(directory, exist_ok=True)

        with self._codec_lock:
            compressed = self._compressor.compress(data)

        tmp_fd, tmp_path = tempfile.mkstemp(prefix=".tmp-", dir=directory)
        try:
            with os.fdopen(tmp_fd, "wb") as f:
                f.write(compressed)
            try:
                _retry_share_violation(lambda: os.replace(tmp_path, p))
            except PermissionError:
                # Windows: another writer beat us to the destination and
                # readers hold it open without FILE_SHARE_DELETE. Content is
                # addressed by hash, so a non-empty file at p has the same
                # bytes we'd write — accept as dedup win.
                try:
                    if os.path.getsize(p) > 0:
                        try:
                            os.remove(tmp_path)
                        except OSError:
                            pass
                        return ref
                except OSError:
                    pass
                raise
        except Exception:
            try:
                os.remove(tmp_path)
            except OSError:
                pass
            raise
        return ref

    def get_blob(self, ref, rel_path):
        """Read and decompress a blob identified by its ref and rel_path."""
        p = self._blob_path_for(ref, rel_path)

        def _read():
            with open(p, "rb") as f:
                return f.read()

        compressed = _retry_share_violation(_read)
        with self._codec_lock:
            return self._decompressor.decompress(compressed)

    def _blob_path_local(self, ref):
        """Compute filesystem path for writes using self.rel_path."""
        h = ref.removeprefix("xxh3:")
        return self._fs_join("store", self.rel_path, "blobs", h[:2], h[2:])

    def _blob_path_for(self, ref, rel_path):
        """Compute filesystem path for reads using given rel_path."""
        h = ref.removeprefix("xxh3:")
        return self._fs_join("store", rel_path, "blobs", h[:2], h[2:])

    # ── Pack ──

    def pack(self, payload):
        """Walk the JSON payload, extract fields >= Threshold as blobs,
        replace them with BlobRef markers. Returns modified bytes or
        the original if nothing was extracted."""
        if self.rel_path == "":
            return payload

        try:
            msg = json.loads(payload)
        except (json.JSONDecodeError, UnicodeDecodeError):
            return payload

        if not isinstance(msg, dict):
            return payload

        modified = False
        for key, value in list(msg.items()):
            new_val, changed = self._extract_field(value)
            if changed:
                msg[key] = new_val
                modified = True

        if not modified:
            return payload

        return json.dumps(msg, separators=(",", ":"), ensure_ascii=False).encode("utf-8")

    def _extract_field(self, value):
        """Process a single JSON value. Returns (new_value, changed).
        Objects: recurse into children. Large arrays/strings/numbers: extract.
        Existing BlobRefs: keep as-is."""
        if is_blob_ref(value):
            return value, False

        raw = json.dumps(value, separators=(",", ":"), ensure_ascii=False)
        raw_bytes = raw.encode("utf-8")

        # Object: recurse into children
        if isinstance(value, dict):
            return self._extract_object(value, raw_bytes)

        # Array or scalar: extract if large
        if len(raw_bytes) >= THRESHOLD:
            ref = self.put_blob(raw_bytes)
            return self._build_blob_ref(ref, raw_bytes, value), True

        return value, False

    def _extract_object(self, obj, raw_bytes):
        """Recurse into a JSON object, extracting large leaves."""
        if len(raw_bytes) < THRESHOLD:
            return obj, False

        modified = False
        out = {}
        for key, child in obj.items():
            new_val, changed = self._extract_field(child)
            if changed:
                out[key] = new_val
                modified = True
            else:
                out[key] = child

        if not modified:
            # Object is large but no individual children were large enough.
            # Extract the whole object as a single blob.
            ref = self.put_blob(raw_bytes)
            return self._build_blob_ref(ref, raw_bytes, obj), True

        return out, True

    # ── Resolve ──

    def resolve(self, data, key):
        """Lazy single-field resolution. Tries direct path first; if it hits
        a BlobRef, resolves it and continues with remaining path segments.

        Each `_resolve_ref` call goes through `_fully_resolve_ref`, which
        loops while the result is itself a BlobRef envelope. This handles
        double-nested envelopes — same pathology as resolve_all's recursive
        fix, applied to the singular path-based variant."""
        try:
            msg = json.loads(data)
        except (json.JSONDecodeError, UnicodeDecodeError):
            return None

        if not isinstance(msg, dict):
            return None

        parts = key.split(".")
        current = msg
        for part in parts:
            if isinstance(current, dict):
                if is_blob_ref(current):
                    current = self._fully_resolve_ref(current)
                    if isinstance(current, dict) and part in current:
                        current = current[part]
                    else:
                        return None
                elif part in current:
                    current = current[part]
                else:
                    return None
            elif isinstance(current, list):
                try:
                    current = current[int(part)]
                except (ValueError, IndexError):
                    return None
            else:
                return None

        if isinstance(current, dict) and is_blob_ref(current):
            current = self._fully_resolve_ref(current)

        return current

    def _fully_resolve_ref(self, blob_ref):
        """Wrap _resolve_ref in a depth-bounded loop so that a blob whose
        content is itself a BlobRef envelope (or a chain of them) gets
        fully unwrapped. Naturally-produced chains via Pack are bounded;
        the limit is a defensive guard against pathological inputs."""
        max_resolve_depth = 32
        current = blob_ref
        for _ in range(max_resolve_depth):
            if not (isinstance(current, dict) and is_blob_ref(current)):
                return current
            current = self._resolve_ref(current)
        raise RuntimeError(
            f"lmo: BlobRef chain exceeded max resolve depth {max_resolve_depth} "
            "(possible cycle or pathological input)"
        )

    def resolve_all(self, data):
        """Eagerly resolve every BlobRef in the payload. Returns modified
        bytes, or the original if no BlobRefs are found."""
        try:
            msg = json.loads(data)
        except (json.JSONDecodeError, UnicodeDecodeError):
            return data

        if not isinstance(msg, dict):
            return data

        modified = False
        for key, value in list(msg.items()):
            new_val, changed = self._resolve_value(value)
            if changed:
                msg[key] = new_val
                modified = True

        if not modified:
            return data

        return json.dumps(msg, separators=(",", ":"), ensure_ascii=False).encode("utf-8")

    def _resolve_value(self, value):
        """Resolve a single value. Returns (new_value, changed).
        BlobRefs -> decompressed data. Nested objects -> recurse.

        After resolving a BlobRef we recurse into the result so nested
        BlobRefs (left behind when an outer container was packed whole by
        extractObject's !modified branch) are also unwrapped. Without this
        the inner ref surfaces to user code as a stub dict and crashes
        with AttributeError on .append() etc.
        """
        if is_blob_ref(value):
            resolved = self._resolve_ref(value)
            nested, _ = self._resolve_value(resolved)
            return nested, True

        if isinstance(value, dict):
            modified = False
            out = {}
            for k, v in value.items():
                new_val, changed = self._resolve_value(v)
                if changed:
                    out[k] = new_val
                    modified = True
                else:
                    out[k] = v
            if modified:
                return out, True
            return value, False

        # Array: recurse so a BlobRef envelope sitting as a list element
        # (e.g. user code did arr.append(msg.alreadyPackedField) and arr
        # later crossed the LMO threshold and was packed whole) is also
        # unwrapped. Without this the inner envelope surfaces to user code
        # as a stub dict and crashes with AttributeError downstream.
        if isinstance(value, list):
            modified = False
            out = []
            for v in value:
                new_val, changed = self._resolve_value(v)
                if changed:
                    out.append(new_val)
                    modified = True
                else:
                    out.append(v)
            if modified:
                return out, True
            return value, False

        return value, False

    def _resolve_ref(self, blob_ref):
        """Fetch and decompress a BlobRef, return parsed JSON value."""
        ref = blob_ref["__ref"]
        rel_path = blob_ref.get("__path", self.rel_path)
        data = self.get_blob(ref, rel_path)
        return json.loads(data)

    # ── BlobRef helpers ──

    def _build_blob_ref(self, ref, raw_bytes, value):
        """Build a BlobRef marker dict."""
        br = {
            "__ref": ref,
            "__magic": MAGIC,
            "__size": len(raw_bytes),
            "__path": self.rel_path,
            "__type": _json_type(value),
        }
        t = br["__type"]
        if t == "array":
            br["__len"] = len(value)
        elif t == "string":
            br["__len"] = len(value)
        return br

    # ── lifecycle ──

    def purge(self):
        """Remove the store directory for the current rel_path."""
        path = self._fs_join("store", self.rel_path)
        shutil.rmtree(path, ignore_errors=True)

    def close(self):
        """Release resources."""
        pass


# ── module-level helpers ──

def is_blob_ref(value):
    """Check if value is a BlobRef marker dict."""
    return (
        isinstance(value, dict)
        and value.get("__magic") == MAGIC
        and bool(value.get("__ref"))
    )


def _hash_ref(data):
    """Compute XXH3-128 hash -> 'xxh3:{32hex}'. Canonical big-endian,
    matches Go's zeebo/xxh3."""
    digest = xxhash.xxh3_128_digest(data)
    return "xxh3:" + digest.hex()


def _json_type(value):
    """Map Python type to JSON type string (matches Go buildBlobRef)."""
    if isinstance(value, list):
        return "array"
    if isinstance(value, dict):
        return "object"
    if isinstance(value, str):
        return "string"
    if isinstance(value, bool):
        return "boolean"
    if isinstance(value, (int, float)):
        return "number"
    return ""


# ── module-level singleton (mirrors Go lmo_rt.go) ──

_store = None


def init_lmo():
    """Initialize the LMO store using lmo_store_path from GetRobotInfo().
    The deskbot owns the path convention — the plugin treats it as opaque."""
    global _store
    if _store is not None:
        _store.close()
        _store = None

    from robomotion.runtime import Runtime
    from robomotion.utils import get_config_dir

    robot_info = Runtime.get_robot_info()
    rel_path = str(robot_info.get("lmo_store_path", ""))

    # In the Hermes/ADK sandbox the launcher bind-mounts the host's
    # per-flow blob dir under /opt/robomotion/lmo-store and exports its
    # absolute container path here. Unset (host mode) → fall through to
    # <config_dir>/store, preserving prior behaviour.
    store_root = os.environ.get("ROBOMOTION_LMO_STORE_DIR") or None
    _store = Store(get_config_dir(), store_root=store_root)
    if rel_path:
        _store.set_rel_path(rel_path)


def lmo_active():
    """Return True if the LMO store is initialized."""
    return _store is not None


def pack_value(value):
    """Pack a value using recursive extraction (matches Go PackValue).
    Returns (packed_value, True) if packing occurred, (None, False) otherwise."""
    if _store is None or _store.rel_path == "":
        return None, False

    raw = json.dumps(value, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
    if len(raw) < THRESHOLD:
        return None, False

    result = _store.pack(raw)
    if result is raw:
        return None, False

    packed = json.loads(result)
    return packed, True




def resolve_blob_ref_value(blob_ref_map):
    """Resolve a BlobRef value, learning rel_path from the BlobRef if needed
    (matches Go ResolveBlobRefValue)."""
    if _store is None:
        return None

    ref = blob_ref_map.get("__ref", "")
    path = blob_ref_map.get("__path", "")

    # Learn rel_path from BlobRef if store doesn't have one yet
    if _store.rel_path == "" and path:
        _store.set_rel_path(path)

    rel_path = path if path else _store.rel_path
    data = _store.get_blob(ref, rel_path)
    return json.loads(data)


def lmo_pack(payload):
    """Pack payload bytes, extracting large fields as blobs. No-op if store is None or LMO not capable."""
    if _store is None:
        return payload
    from robomotion.capabilities import has_capability, Capability
    if not has_capability(Capability.CapabilityLMO):
        return payload
    return _store.pack(payload)


def lmo_resolve(data, key):
    """Lazily resolve a single field. No-op if store is None."""
    if _store is None:
        return None
    return _store.resolve(data, key)


def lmo_resolve_subtree(data, key):
    """Resolve a field and all nested BlobRefs within the result.
    Use this when the caller needs fully materialized data (e.g. an object
    whose children may individually be BlobRefs)."""
    if _store is None:
        return None
    result = _store.resolve(data, key)
    if result is None:
        return None
    if isinstance(result, dict):
        resolved, changed = _store._resolve_value(result)
        return resolved if changed else result
    return result


def lmo_resolve_all(data):
    """Eagerly resolve all BlobRefs. No-op if store is None."""
    if _store is None:
        return data
    return _store.resolve_all(data)


def close_lmo():
    """Close the store."""
    global _store
    if _store is not None:
        _store.close()
        _store = None
