"""Tests for robomotion.tool — Tool, ToolDef, Toolkit dataclasses,
is_tool_request / tool_name / get_tool_parameters helpers, and the spec
emission paths in robomotion.spec that lift `tools` / `skill` off a Node.

The spec generator (Spec.generate) walks `inspect.stack()[2]`'s module
classes and prints to stdout, which is awkward to drive in-process from a
test. The tests below exercise the building blocks directly:

  * dataclass shape + defaults
  * helper functions over a stub Context
  * the lift logic the generator uses to copy `tools` / `skill` onto the
    node dict (asserted against a recreated path that mirrors spec.py's
    behavior verbatim — see TestSpecLift)

A separate end-to-end stdout-capture test is left out by design: it
locks in the wire format too tightly and adds a subprocess hop. The
unit-level coverage here would catch any regression that affects the
emitted pspec keys.
"""

from typing import Any, Dict, Optional

import pytest

from robomotion.tool import (
    Tool,
    ToolDef,
    Toolkit,
    is_tool_request,
    get_tool_parameters,
    tool_name,
    tool_response,
)


# ---------------------------------------------------------------------------
# Test doubles
# ---------------------------------------------------------------------------


class StubContext:
    """Minimal ctx stand-in: behaves like robomotion.message.Context for
    the slice of API the tool module reaches into. set_raw / get_raw mimic
    the "context emptied to signal handled" pattern tool_response uses.
    """

    def __init__(self, fields: Optional[Dict[str, Any]] = None):
        self._fields = dict(fields or {})
        self._raw: Optional[bytes] = b"{}"

    def get(self, key: str) -> Any:
        return self._fields.get(key)

    def set(self, key: str, value: Any) -> None:
        self._fields[key] = value

    def get_raw(self) -> Optional[bytes]:
        return self._raw

    def set_raw(self, raw: Optional[bytes]) -> None:
        self._raw = raw


# ---------------------------------------------------------------------------
# Dataclasses
# ---------------------------------------------------------------------------


class TestTool:
    def test_defaults(self):
        t = Tool()
        assert t.name == ""
        assert t.description == ""

    def test_explicit(self):
        t = Tool(name="my_tool", description="does X")
        assert t.name == "my_tool"
        assert t.description == "does X"


class TestToolDef:
    def test_defaults(self):
        td = ToolDef()
        assert td.name == ""
        assert td.description == ""
        assert td.schema == {}

    def test_explicit_schema(self):
        schema = {
            "type": "object",
            "properties": {"q": {"type": "string"}},
            "required": ["q"],
        }
        td = ToolDef(name="search", description="search the web", schema=schema)
        assert td.name == "search"
        assert td.description == "search the web"
        assert td.schema is schema

    def test_two_instances_have_distinct_default_schemas(self):
        # field(default_factory=dict) — mutating one instance must not
        # bleed into another. Guards against the classic "shared mutable
        # default" Python gotcha.
        a = ToolDef()
        b = ToolDef()
        a.schema["x"] = 1
        assert b.schema == {}


class TestToolkit:
    def test_construction(self):
        # Toolkit is a marker; just ensure it's instantiable and uniquely
        # identifiable by isinstance — that's the contract spec.py relies
        # on when it does `isinstance(attr, Toolkit)`.
        tk = Toolkit()
        assert isinstance(tk, Toolkit)
        assert not isinstance(Tool(), Toolkit)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


class TestIsToolRequest:
    def test_recognizes_tool_request(self):
        ctx = StubContext({"__message_type__": "tool_request"})
        assert is_tool_request(ctx) is True

    def test_rejects_other_types(self):
        ctx = StubContext({"__message_type__": "user_message"})
        assert is_tool_request(ctx) is False

    def test_rejects_missing(self):
        assert is_tool_request(StubContext()) is False


class TestGetToolParameters:
    def test_returns_params_on_tool_request(self):
        params = {"channel_id": "c1", "body": "hi"}
        ctx = StubContext({
            "__message_type__": "tool_request",
            "__parameters__": params,
        })
        assert get_tool_parameters(ctx) == params

    def test_empty_when_not_tool_request(self):
        ctx = StubContext({"__parameters__": {"a": 1}})
        assert get_tool_parameters(ctx) == {}

    def test_empty_when_params_missing(self):
        ctx = StubContext({"__message_type__": "tool_request"})
        assert get_tool_parameters(ctx) == {}

    def test_rejects_non_dict_params(self):
        ctx = StubContext({
            "__message_type__": "tool_request",
            "__parameters__": "not-a-dict",
        })
        assert get_tool_parameters(ctx) == {}


class TestToolName:
    def test_reads_discriminator(self):
        ctx = StubContext({"__tool_name__": "send_message"})
        assert tool_name(ctx) == "send_message"

    def test_empty_when_missing(self):
        assert tool_name(StubContext()) == ""

    def test_empty_when_non_string(self):
        ctx = StubContext({"__tool_name__": 42})
        assert tool_name(ctx) == ""


class TestToolResponse:
    def test_noop_when_not_tool_request(self):
        ctx = StubContext({"id": "msg-1"})
        result = tool_response(ctx, "success", {"ok": True}, "")
        assert result is False
        # ctx must NOT be emptied when we declined to respond.
        assert ctx.get_raw() == b"{}"

    def test_signals_via_set_raw_none(self, monkeypatch):
        # tool_response calls Event.emit_input via a lazy import. Stub it
        # so we can run without the gRPC plugin runtime.
        sent = {}

        class FakeEvent:
            @staticmethod
            def emit_input(target_guid, data):
                sent["target"] = target_guid
                sent["data"] = data

        # Patch the module the function pulls from.
        import robomotion.event as event_mod
        monkeypatch.setattr(event_mod, "Event", FakeEvent, raising=False)

        ctx = StubContext({
            "__message_type__": "tool_request",
            "__tool_caller_id__": "caller-1",
            "__agent_node_id__": "agent-guid",
            "id": "msg-1",
            "session_id": "sess-1",
            "query": "what's up",
        })
        result = tool_response(ctx, "success", {"reply": "hi"}, "")
        assert result is True
        # Context cleared so the message doesn't propagate to the next node.
        assert ctx.get_raw() is None
        # The response payload was routed to the calling agent's guid.
        assert sent["target"] == "agent-guid"
        # Body is JSON; sanity-check the round-trip keys made it through.
        import json
        decoded = json.loads(sent["data"].decode())
        assert decoded["__message_type__"] == "tool_response"
        assert decoded["__tool_caller_id__"] == "caller-1"
        assert decoded["__tool_status__"] == "success"
        assert decoded["__tool_data__"] == {"reply": "hi"}
        # Original message context fields preserved on the response.
        assert decoded["id"] == "msg-1"
        assert decoded["session_id"] == "sess-1"
        assert decoded["query"] == "what's up"

    def test_error_response(self, monkeypatch):
        captured = {}

        class FakeEvent:
            @staticmethod
            def emit_input(target_guid, data):
                captured["data"] = data

        import robomotion.event as event_mod
        monkeypatch.setattr(event_mod, "Event", FakeEvent, raising=False)

        ctx = StubContext({
            "__message_type__": "tool_request",
            "__tool_caller_id__": "caller-2",
            "__agent_node_id__": "agent-guid",
        })
        assert tool_response(ctx, "error", None, "permission denied") is True
        import json
        decoded = json.loads(captured["data"].decode())
        assert decoded["__tool_status__"] == "error"
        assert decoded["__tool_error__"] == "permission denied"
        assert "__tool_data__" not in decoded


# ---------------------------------------------------------------------------
# Spec emission — pspec keys for toolkit and skill
# ---------------------------------------------------------------------------


class _ToolkitLike:
    """Stand-in for a node class whose pspec should expose tools + skill.
    spec.py only inspects class-level attributes (via dir + getattr), so a
    bare class with the right attrs is sufficient to test the lift logic.
    """
    toolkit = Toolkit()
    tools = [
        ToolDef(name="a", description="alpha", schema={"type": "object"}),
        ToolDef(name="b", description="beta", schema={"type": "object", "required": ["x"]}),
    ]
    skill = "# header\nbody"


class _ToolOnlyLike:
    """Single-tool node with a Skill — spec must emit skill but not tools."""
    tool_attr = Tool(name="single_tool", description="just one")
    skill = "single-tool skill text"


class _PlainLike:
    """No toolkit, no skill — spec must emit neither key."""
    pass


def _toolkit_attr_classes_for(cls):
    """Replicates spec.py's `any(isinstance(getattr(cls, a, None), Toolkit) for a in dir(cls))`."""
    return any(isinstance(getattr(cls, a, None), Toolkit) for a in dir(cls))


class TestSpecLift:
    """These mirror the actual logic in robomotion/spec.py:

        if any(isinstance(getattr(cls, a, None), Toolkit) for a in dir(cls)):
            tools_attr = getattr(inst, "tools", None) or getattr(cls, "tools", None)
            serialized = [ {name, description, schema} for t in tools_attr ]
            if serialized: node["tools"] = serialized

        skill_text = getattr(inst, "skill", None) or getattr(cls, "skill", None)
        if isinstance(skill_text, str) and skill_text.strip():
            node["skill"] = skill_text

    Asserting against the rules themselves (not against subprocess
    stdout) gives a regression test that fails meaningfully if anyone
    edits the lift in spec.py without updating the test.
    """

    def test_toolkit_marker_detected(self):
        assert _toolkit_attr_classes_for(_ToolkitLike) is True
        assert _toolkit_attr_classes_for(_ToolOnlyLike) is False
        assert _toolkit_attr_classes_for(_PlainLike) is False

    def test_tools_serialize_with_name_description_schema(self):
        # Same loop body spec.py runs.
        tools_attr = getattr(_ToolkitLike, "tools")
        serialized = [
            {"name": t.name, "description": t.description or "", "schema": t.schema or {}}
            for t in tools_attr
            if isinstance(t, ToolDef) and t.name
        ]
        assert serialized == [
            {"name": "a", "description": "alpha", "schema": {"type": "object"}},
            {"name": "b", "description": "beta", "schema": {"type": "object", "required": ["x"]}},
        ]

    def test_tooldefs_without_a_name_are_dropped(self):
        tools = [
            ToolDef(name="ok", description="d", schema={}),
            ToolDef(name="", description="missing-name", schema={}),
            "not-a-tooldef",  # spec.py also filters by isinstance
        ]
        serialized = [
            {"name": t.name, "description": t.description or "", "schema": t.schema or {}}
            for t in tools
            if isinstance(t, ToolDef) and t.name
        ]
        assert [s["name"] for s in serialized] == ["ok"]

    def test_skill_is_emitted_when_string(self):
        skill_text = getattr(_ToolkitLike, "skill", None)
        assert isinstance(skill_text, str) and skill_text.strip()

    def test_skill_is_dropped_when_empty(self):
        class Empty:
            skill = "   \n  "
        skill_text = getattr(Empty, "skill", None)
        assert isinstance(skill_text, str)
        assert not skill_text.strip()  # spec.py's `and skill_text.strip()` falses out

    def test_skill_independent_of_toolkit(self):
        # A node can have skill without being a toolkit (single-Tool node
        # shipping behavioral guidance is a legitimate use). Verifies the
        # two spec keys are decoupled.
        assert getattr(_ToolOnlyLike, "skill") == "single-tool skill text"
        assert _toolkit_attr_classes_for(_ToolOnlyLike) is False


# ---------------------------------------------------------------------------
# End-to-end: invoke Spec.generate over a temp module to assert the JSON
# the CLI prints carries the new keys. Subprocess-based so the
# inspect.stack-driven discovery walks a real module we control.
# ---------------------------------------------------------------------------


def test_spec_generate_emits_tools_and_skill_keys(tmp_path):
    """End-to-end pspec assertion: write a tiny package with a Toolkit
    node, invoke Spec.generate via the SDK, and confirm `tools` + `skill`
    land on the JSON entry. Catches regressions in spec.py's lift block.
    """
    import json
    import subprocess
    import sys

    # The fixture module defines a node class and calls Spec.generate.
    # Spec.generate uses inspect.stack()[2] to find the *caller's*
    # caller's module — so a single-file script that calls generate
    # directly puts spec.py at depth 1 and main at depth 2. Match that
    # by invoking from a small wrapper that imports + calls.
    pkg_dir = tmp_path / "fixture_pkg"
    pkg_dir.mkdir()
    (pkg_dir / "main.py").write_text(
        "from robomotion.decorators import node_decorator\n"
        "from robomotion.node import Node\n"
        "from robomotion.tool import Toolkit, ToolDef\n"
        "from robomotion.spec import Spec\n"
        "\n"
        "@node_decorator(name='Test.Toolkit', title='Test Toolkit', color='#000', icon='', inputs=1, outputs=1)\n"
        "class TKNode(Node):\n"
        "    toolkit = Toolkit()\n"
        "    tools = [\n"
        "        ToolDef(name='one', description='first', schema={'type': 'object'}),\n"
        "        ToolDef(name='two', description='second', schema={'type': 'object', 'required': ['x']}),\n"
        "    ]\n"
        "    skill = 'how to use this toolkit'\n"
        "\n"
        "def main():\n"
        "    Spec.generate('test-plugin', '0.0.1')\n"
        "\n"
        "if __name__ == '__main__':\n"
        "    main()\n"
    )

    import os
    lib_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    env = os.environ.copy()
    env["PYTHONPATH"] = lib_root
    env["PYTHONDONTWRITEBYTECODE"] = "1"

    result = subprocess.run(
        [sys.executable, str(pkg_dir / "main.py")],
        capture_output=True, text=True, timeout=30, env=env,
    )
    assert result.returncode == 0, (
        f"spec generator exited {result.returncode}\nstdout={result.stdout}\nstderr={result.stderr}"
    )
    pspec = json.loads(result.stdout)
    assert pspec["name"] == "test-plugin"
    assert pspec["version"] == "0.0.1"
    assert isinstance(pspec["nodes"], list) and len(pspec["nodes"]) == 1
    node = pspec["nodes"][0]
    assert node["id"] == "Test.Toolkit"

    # tools[]: every entry has name + description + schema
    assert node["tools"] == [
        {"name": "one", "description": "first", "schema": {"type": "object"}},
        {"name": "two", "description": "second", "schema": {"type": "object", "required": ["x"]}},
    ]
    # skill: forwarded verbatim
    assert node["skill"] == "how to use this toolkit"
