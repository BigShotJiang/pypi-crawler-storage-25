# upvertex-huawei

Namespace reservation for UpVertex Inc. (www.upvertex.com)