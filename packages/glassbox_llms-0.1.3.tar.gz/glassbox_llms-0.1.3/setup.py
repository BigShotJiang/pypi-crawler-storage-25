from setuptools import setup, find_packages

setup(
    name="glassboxllms",
    version="0.1.0",
    packages=find_packages(),
    python_requires=">=3.10",
)