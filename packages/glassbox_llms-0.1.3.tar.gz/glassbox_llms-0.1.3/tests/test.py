from transformers import AutoTokenizer
# Replace 'gpt2' with whatever model your tests are actually using
tokenizer = AutoTokenizer.from_pretrained("gpt2")
print("Tokenizer loaded successfully!")