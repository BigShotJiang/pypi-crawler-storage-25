"""
Integration tests for the probes pipeline.

Tests the full flow: load model -> extract activations (ActivationStore) ->
fit LinearProbe -> evaluate. Uses a small HuggingFace model to keep runtime reasonable.
"""
import os
import shutil
import pytest
import numpy as np



from glassboxllms.primitives.probes import ActivationStore, LinearProbe
from glassboxllms.primitives.probes.activation_store import get_layer_names


TEST_CACHE = "./test_probe_cache"


@pytest.fixture(scope="module")
def model_and_tokenizer():
    """Load a small HF model once per module (shared across tests)."""
    from transformers import AutoModel, AutoTokenizer
    model_name = os.environ.get("GLASSBOX_TEST_MODEL", "prajjwal1/bert-tiny")

    # Add use_fast=False here
    tokenizer = AutoTokenizer.from_pretrained(model_name, use_fast=False) 
    model = AutoModel.from_pretrained(model_name)
    model.eval()
    return model, tokenizer


@pytest.fixture(autouse=True)
def cleanup_cache():
    if os.path.exists(TEST_CACHE):
        shutil.rmtree(TEST_CACHE)
    yield
    if os.path.exists(TEST_CACHE):
        shutil.rmtree(TEST_CACHE)


@pytest.mark.integration
def test_activation_store_extract_and_list_layers(model_and_tokenizer):
    """ActivationStore extracts activations and list_layers returns valid names."""
    model, tokenizer = model_and_tokenizer
    store = ActivationStore(model)

    layers = store.list_layers()
    assert len(layers) > 0
    # Use a subset so we have a valid layer name
    target = layers[0] if layers else "bert.encoder.layer.0"
    if target not in layers:
        target = layers[0]

    texts = ["Hello world", "Goodbye world"]
    result = store.extract(texts, tokenizer, layers=[target], pooling="mean")

    assert target in result
    arr = result[target]
    assert arr.ndim == 2
    assert arr.shape[0] == 2
    assert arr.dtype == np.floating


@pytest.mark.integration
def test_activation_store_pooling_options(model_and_tokenizer):
    """ActivationStore respects pooling='cls' and 'last'."""
    model, tokenizer = model_and_tokenizer
    store = ActivationStore(model)
    layers = store.list_layers()
    assert len(layers) > 0
    layer = layers[0]

    texts = ["Single sentence here."]
    for pooling in ("mean", "cls", "last"):
        out = store.extract(texts, tokenizer, layers=[layer], pooling=pooling)
        assert layer in out
        assert out[layer].ndim == 2 and out[layer].shape[0] == 1


@pytest.mark.integration
def test_get_layer_names_utility(model_and_tokenizer):
    """get_layer_names returns filtered layer names."""
    model, _ = model_and_tokenizer
    all_names = get_layer_names(model, "all")
    assert len(all_names) > 0
    # BERT-tiny has encoder layers
    attention = get_layer_names(model, "attention")
    # May be empty on very small models; at least no crash
    assert isinstance(attention, list)


@pytest.mark.integration
def test_probe_fit_evaluate_pipeline(model_and_tokenizer):
    """Full pipeline: extract -> fit LinearProbe (logistic) -> evaluate."""
    model, tokenizer = model_and_tokenizer
    store = ActivationStore(model)
    layers = store.list_layers()
    assert len(layers) > 0
    layer = layers[0]

    # Minimal labeled data (binary)
    train_texts = ["good great nice", "bad awful terrible"]
    train_labels = np.array([1, 0])
    test_texts = ["wonderful", "horrible"]
    test_labels = np.array([1, 0])

    train_acts = store.extract(train_texts, tokenizer, layers=[layer], pooling="mean")
    test_acts = store.extract(test_texts, tokenizer, layers=[layer], pooling="mean")

    probe = LinearProbe(
        layer=layer,
        direction="sentiment",
        model_type="logistic",
        normalize=True,
    )
    probe.fit(train_acts[layer], train_labels)
    result = probe.evaluate(test_acts[layer], test_labels)

    assert hasattr(result, "accuracy")
    assert 0 <= result.accuracy <= 1
    assert result.f1 is not None
    assert probe.is_fitted
    direction = probe.get_direction()
    assert direction.ndim >= 1 and direction.size > 0


@pytest.mark.integration
def test_probe_linear_regression_pipeline(model_and_tokenizer):
    """Linear regression probe: fit and evaluate on continuous targets."""
    model, tokenizer = model_and_tokenizer
    store = ActivationStore(model)
    layers = store.list_layers()
    assert len(layers) > 0
    layer = layers[0]

    train_texts = ["a", "b", "c", "d"]
    train_labels = np.array([0.0, 0.33, 0.66, 1.0])
    train_acts = store.extract(train_texts, tokenizer, layers=[layer], pooling="mean")

    probe = LinearProbe(
        layer=layer,
        direction="intensity",
        model_type="linear",
        normalize=True,
    )
    probe.fit(train_acts[layer], train_labels)
    pred = probe.predict(train_acts[layer])
    assert pred.shape == (4,)
    result = probe.evaluate(train_acts[layer], train_labels)
    assert result.explained_variance is not None


@pytest.mark.integration
def test_probe_pca_unsupervised(model_and_tokenizer):
    """PCA probe fits without labels and returns components."""
    model, tokenizer = model_and_tokenizer
    store = ActivationStore(model)
    layers = store.list_layers()
    assert len(layers) > 0
    layer = layers[0]

    texts = ["first", "second", "third", "fourth", "fifth"]
    acts = store.extract(texts, tokenizer, layers=[layer], pooling="mean")

    probe = LinearProbe(
        layer=layer,
        direction="structure",
        model_type="pca",
        n_components=2,
        normalize=True,
    )
    probe.fit(acts[layer])
    transformed = probe.predict(acts[layer])
    assert transformed.shape[0] == 5
    assert transformed.shape[1] == 2
    result = probe.evaluate(acts[layer], np.zeros(5))  # labels ignored for PCA
    assert result.explained_variance is not None
