"""
Integration tests for the instrumentation layer.

Validates the full lifecycle of ActivationStore against real nn.Module instances:
hook registration, multi-layer capture, buffer-to-disk flushing, state persistence
and reload, cache clearing, and token-indexed retrieval. Uses a self-contained
TinyMLP to avoid any HuggingFace dependency.
"""

import os
import shutil
import pytest
import torch
import torch.nn as nn

from glassboxllms.instrumentation.activations import ActivationStore, HAS_SAFETENSORS

pytestmark = pytest.mark.integration

TEST_DIR = "./test_integration_activations"
LAYER_0 = "blocks.0.mlp"
LAYER_1 = "blocks.1.mlp"


@pytest.fixture(autouse=True)
def cleanup():
    if os.path.exists(TEST_DIR):
        shutil.rmtree(TEST_DIR)
    yield
    if os.path.exists(TEST_DIR):
        shutil.rmtree(TEST_DIR)


class TinyMLP(nn.Module):
    """Minimal stack of modules so we can register hooks by name."""

    def __init__(self, dim=8, num_blocks=2):
        super().__init__()
        self.blocks = nn.ModuleList([
            nn.Sequential(
                nn.Linear(dim, dim * 2),
                nn.ReLU(),
                nn.Linear(dim * 2, dim),
            )
            for _ in range(num_blocks)
        ])

    def forward(self, x):
        for block in self.blocks:
            x = x + block(x)
        return x


@pytest.fixture
def tiny_model():
    return TinyMLP(dim=8, num_blocks=2)


@pytest.fixture
def store():
    """ActivationStore with small buffer to trigger disk flush."""
    return ActivationStore(device="cpu", storage_dir=TEST_DIR, buffer_size=3)


def test_instrumentation_store_hook_on_real_module(tiny_model, store):
    """Register store hook on a real nn.Module and run forward; verify activations saved."""
    hook = store.create_hook(LAYER_0)
    # Register on the first block's last linear (output of block)
    target = tiny_model.blocks[0][2]  # nn.Linear
    handle = target.register_forward_hook(hook)

    x = torch.randn(2, 8)
    with torch.no_grad():
        _ = tiny_model(x)

    handle.remove()

    all_acts = store.get_all(LAYER_0)
    assert all_acts.shape[0] == 1  # one batch through one hook
    assert all_acts.shape[-1] == 8


def test_instrumentation_store_multiple_layers(tiny_model, store):
    """Capture activations from two layers in one forward pass."""
    hook0 = store.create_hook(LAYER_0)
    hook1 = store.create_hook(LAYER_1)
    h0 = tiny_model.blocks[0][2].register_forward_hook(hook0)
    h1 = tiny_model.blocks[1][2].register_forward_hook(hook1)

    x = torch.randn(1, 8)
    with torch.no_grad():
        _ = tiny_model(x)

    h0.remove()
    h1.remove()

    a0 = store.get_all(LAYER_0)
    a1 = store.get_all(LAYER_1)
    assert a0.numel() > 0 and a1.numel() > 0
    assert a0.shape[-1] == 8 and a1.shape[-1] == 8


def test_instrumentation_store_buffer_flush_to_disk(store):
    """Filling buffer flushes to disk and get_all still returns correct data."""
    for i in range(5):
        store.save(LAYER_0, torch.full((1, 4), float(i)))

    # buffer_size=3, 5 saves → one flush at 3 items, 2 remain in buffer
    assert len(store._buffer[LAYER_0]) == 2
    assert len(store._disk_manifest[LAYER_0]) >= 1

    all_acts = store.get_all(LAYER_0)
    assert all_acts.shape[0] == 5
    assert all_acts.shape[-1] == 4

def test_instrumentation_store_persist_and_reload(store):
    """persist_to_disk writes state; reloaded state matches."""
    store.save(LAYER_0, torch.randn(2, 6))
    store.save(LAYER_0, torch.randn(1, 6))
    path = os.path.join(TEST_DIR, "state.pt")
    store.persist_to_disk("state.pt")
    assert os.path.exists(path)

    loaded = torch.load(path, map_location="cpu")
    assert "data" in loaded and LAYER_0 in loaded["data"]
    assert loaded["data"][LAYER_0][0].shape == (2, 6)
    assert loaded["data"][LAYER_0][1].shape == (1, 6)


def test_instrumentation_store_clear_removes_buffer_and_metadata(store):
    """clear() wipes buffer and metadata."""
    store.save(LAYER_0, torch.randn(1, 4))
    store.clear()
    assert len(store._buffer) == 0
    assert len(store._metadata_index) == 0
    out = store.get_all(LAYER_0)
    assert out.numel() == 0


def test_instrumentation_store_token_indexing_in_ram(store):
    """When using token_idx, get_by_token returns correct slice (RAM-only)."""
    store.save(LAYER_0, torch.randn(1, 5), token_idx=0)
    store.save(LAYER_0, torch.randn(1, 5), token_idx=0)
    store.save(LAYER_0, torch.randn(1, 5), token_idx=1)

    t0 = store.get_by_token(LAYER_0, 0)
    t1 = store.get_by_token(LAYER_0, 1)
    assert t0.shape[0] == 2 and t1.shape[0] == 1
    assert t0.shape[-1] == 5
