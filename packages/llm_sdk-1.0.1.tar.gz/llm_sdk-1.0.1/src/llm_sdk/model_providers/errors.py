from typing import Optional


class InvokeError(ValueError):
    """Base class for all LLM exceptions."""

    description: Optional[str] = None

    def __init__(self, description: Optional[str] = None) -> None:
        self.description = description

    def __str__(self):
        return self.description or self.__class__.__name__


class InvokeServerUnavailableError(InvokeError):
    """Raised when the Invoke returns server unavailable error."""

    description = "Server Unavailable Error"


class CredentialsValidateFailedError(ValueError):
    """
    Credentials validate failed error
    """

    pass


class InternalServerError(Exception):
    pass


class InvalidAuthenticationError(Exception):
    pass


class InvalidAPIKeyError(Exception):
    pass


class RateLimitReachedError(Exception):
    pass


class InsufficientAccountBalanceError(Exception):
    pass


class BadRequestError(Exception):
    pass
