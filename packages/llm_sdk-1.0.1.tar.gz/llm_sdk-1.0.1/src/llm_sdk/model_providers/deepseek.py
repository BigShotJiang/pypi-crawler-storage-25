from typing import Any, AsyncGenerator, Dict, Iterator, List, Optional, Type, Union

from langchain_core.language_models.base import LanguageModelInput
from langchain_core.language_models.chat_models import BaseChatModel
from langchain_core.messages.base import BaseMessage, BaseMessageChunk
from langchain_core.runnables import Runnable, RunnableLambda
from langchain_core.runnables.config import RunnableConfig
from langchain_core.tools import BaseTool
from langchain_deepseek import ChatDeepSeek
from pydantic.main import BaseModel

from llm_sdk.model_providers.aes import AESCipher
from llm_sdk.model_providers.base import AIModel

import logging

logger = logging.getLogger(__name__)


class DeepseekLargeLanguageModel(AIModel):

    _model: Optional[BaseChatModel] = None

    def __init__(self, model_name: str, credential: Dict, app_id: Optional[str] = None):
        super().__init__()

        if app_id is None:
            raise ValueError("app_id is required")
        try:
            aes_client = AESCipher(app_id)
            # decrypt credential
            if credential.get("api_key"):
                credential["api_key"] = aes_client.decrypt(credential["api_key"])
        except Exception as e:
            logger.warning(f"decrypt credential failed: {e}, use original key")

        self._credential = credential
        self._model_name = model_name
        self._model = ChatDeepSeek(
            model=model_name if model_name else "deepseek-chat",
            temperature=0,
            max_tokens=None,
            timeout=None,
            max_retries=2,
            api_key=credential.get("api_key", ""),
        )

    def invoke(
        self,
        input_dict: Union[List[BaseMessage], List[str], str],
        config: Optional[RunnableConfig] = None,
        **kwargs,
    ) -> Any:
        return self._model.invoke(input_dict, config=config, **kwargs)

    async def ainvoke(
        self,
        input_dict: Union[List[BaseMessage], List[str], str],
        config: Optional[RunnableConfig] = None,
        **kwargs,
    ) -> Any:
        return await self._model.ainvoke(input_dict, config=config, **kwargs)

    def stream(
        self, input_dict: List[BaseMessage], config: Optional[RunnableConfig] = None, **kwargs
    ) -> Iterator[BaseMessageChunk]:
        self._model.stream(input_dict, config=config, **kwargs)

    async def astream(
        self, input_dict: List[BaseMessage], config: Optional[RunnableConfig] = None, **kwargs
    ) -> AsyncGenerator[BaseMessageChunk, None]:
        async for chunk in self._model.astream(input_dict, config=config, **kwargs):
            yield chunk

    def bind_tools(self, tools: List[BaseTool], **kwargs) -> "AIModel":
        self._tools = tools
        if self._model is not None:
            self._model = self._model.bind_tools(tools, **kwargs)
        return self

    def with_structured_output(self, schema: Union[Dict, Type[BaseModel]], **kwargs) -> Runnable:
        def wrapper(input_data: LanguageModelInput, config: Optional[RunnableConfig] = None):
            structured_llm = self._model.with_structured_output(schema=schema, **kwargs)

            return structured_llm.invoke(input_data, config=config)

        return RunnableLambda(wrapper)

    def unified_credential(self) -> Dict:
        return {
            "openai_api_key": self._credential.get("api_key", ""),
            "openai_api_type": "deepseek",
            "openai_api_deployment": self._model_name,
            "timeout": self._credential.get("timeout", 60),
            "max_retries": self._credential.get("max_retries", 1),
            "temperature": self._credential.get("temperature", 0.7),
        }
