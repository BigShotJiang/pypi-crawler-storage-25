"""meta_memcache.events"""
