"""meta_memcache.base"""
