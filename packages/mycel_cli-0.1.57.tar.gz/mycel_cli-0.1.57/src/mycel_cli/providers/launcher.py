from __future__ import annotations

import os
import shutil
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Mapping, TextIO

from ..binding_resolver import (
    BindingResolutionError,
    IdentitySelectionSkipped,
    resolve_binding,
)
from ..cli_runtime import current_cli_bin, current_cli_command
from ..debug_log import log_debug_event
from ..identity_store import IdentityStore
from .hooks import ensure_provider_hooks, provider_hook_status

NATIVE_INSPECTION_ARGS = frozenset({"--help", "-h", "--version", "-V"})
MYCEL_STATUS_ARG = "--mycel-status"
MYCEL_STATUS_JSON_ARG = "--json"


@dataclass(frozen=True)
class ProviderLaunch:
    command: list[str]
    env: dict[str, str]


@dataclass(frozen=True)
class ParsedProviderArgs:
    local_id: str | None
    native_args: list[str]


def build_provider_launch(
    *,
    provider: str,
    provider_args: list[str],
    cwd: Path,
    environ: Mapping[str, str] | None = None,
    stdin: TextIO | None = None,
    stdout: TextIO | None = None,
) -> ProviderLaunch:
    parsed_args = _parse_provider_args(provider, provider_args)
    env = dict(environ or os.environ)
    if parsed_args.local_id is None and _is_native_inspection(parsed_args.native_args):
        binary = shutil.which(provider)
        if binary is None:
            raise RuntimeError(f"native command not found: {provider}")
        return ProviderLaunch(command=[binary, *parsed_args.native_args], env=env)

    store = IdentityStore.from_env()
    try:
        binding = resolve_binding(
            store=store,
            cwd=cwd,
            provider=provider,
            interactive=parsed_args.local_id is None,
            local_id=parsed_args.local_id,
            stdin=stdin,
            stdout=stdout,
        )
    except IdentitySelectionSkipped:
        binary = _native_binary(provider)
        return _bootstrap_provider_launch(
            provider=provider,
            binary=binary,
            native_args=parsed_args.native_args,
            env=env,
            store=store,
            stdout=stdout,
        )
    except BindingResolutionError as exc:
        if parsed_args.local_id is not None or exc.reason != "missing":
            raise
        binary = _native_binary(provider)
        return _bootstrap_provider_launch(
            provider=provider,
            binary=binary,
            native_args=parsed_args.native_args,
            env=env,
            store=store,
            stdout=stdout,
        )
    binary = _native_binary(provider)
    local_id = str(binding["local_id"])
    source = str(binding.get("source") or "unknown")
    ensure_provider_hooks(provider=provider)
    store.add_cwd_identity(cwd, local_id)
    if stdout is not None:
        stdout.write(f"Using Mycel identity: {local_id} (source: {source})\n")
    log_debug_event(
        "provider-launch",
        "provider.identity.resolved",
        local_id=local_id,
        details={"provider": provider, "source": source, "cwd": str(cwd)},
    )

    env["MYCEL_HOME"] = str(store.root)
    env["MYCEL_LOCAL_ID"] = local_id
    env["MYCEL_PROVIDER"] = provider
    _bind_cli_command(env)
    native_args = list(parsed_args.native_args)
    return ProviderLaunch(command=[binary, *native_args], env=env)


def _native_binary(provider: str) -> str:
    binary = shutil.which(provider)
    if binary is None:
        raise RuntimeError(f"native command not found: {provider}")
    return binary


def _bootstrap_provider_launch(
    *,
    provider: str,
    binary: str,
    native_args: list[str],
    env: dict[str, str],
    store: IdentityStore,
    stdout: TextIO | None,
) -> ProviderLaunch:
    ensure_provider_hooks(provider=provider)
    env["MYCEL_HOME"] = str(store.root)
    env["MYCEL_PROVIDER"] = provider
    env["MYCEL_BOOTSTRAP_SURFACE_ID"] = uuid.uuid4().hex
    env.pop("MYCEL_LOCAL_ID", None)
    _bind_cli_command(env)
    if stdout is not None:
        stdout.write(
            f"Starting {provider.title()} without a Mycel identity. "
            "Use the Mycel hook guidance inside this session to create one.\n"
        )
    log_debug_event(
        "provider-launch",
        "provider.bootstrap.started",
        details={"provider": provider},
    )
    return ProviderLaunch(command=[binary, *native_args], env=env)


def is_provider_status_request(provider_args: list[str]) -> bool:
    return tuple(provider_args) in {
        (MYCEL_STATUS_ARG,),
        (MYCEL_STATUS_ARG, MYCEL_STATUS_JSON_ARG),
    }


def provider_status_json_requested(provider_args: list[str]) -> bool:
    return tuple(provider_args) == (MYCEL_STATUS_ARG, MYCEL_STATUS_JSON_ARG)


def provider_status(
    *,
    provider: str,
    cwd: Path,
    environ: Mapping[str, str] | None = None,
) -> dict[str, object]:
    env = dict(environ or os.environ)
    store = IdentityStore.from_env()
    binary = shutil.which(provider)
    hook_status = provider_hook_status(provider=provider)
    cwd_identities = [
        local_id
        for local_id in store.cwd_identities(cwd)
        if _identity_matches_provider(store, local_id, provider)
    ]
    status: dict[str, object] = {
        "provider": provider,
        "identity": {
            "current_process": _current_process_identity(store, provider, env),
            "cwd": cwd_identities,
        },
        "native_command": {
            "available": binary is not None,
            "path": binary,
        },
        "hooks": {
            "installed": hook_status["installed"],
            "path": hook_status["script"],
        },
    }
    return status


def format_provider_status(status: Mapping[str, object]) -> str:
    identity = status["identity"]
    native_command = status["native_command"]
    hooks = status["hooks"]
    assert isinstance(identity, Mapping)
    assert isinstance(native_command, Mapping)
    assert isinstance(hooks, Mapping)

    current_process = identity["current_process"] or "none"
    cwd_identities = identity["cwd"]
    if isinstance(cwd_identities, list) and cwd_identities:
        folder_identities = ", ".join(str(item) for item in cwd_identities)
    else:
        folder_identities = "none"

    native_path = native_command["path"]
    native_status = str(native_path) if native_command["available"] else "missing"
    hook_status = "installed" if hooks["installed"] else "not installed"
    return (
        f"Provider: {status['provider']}\n"
        f"Current process identity: {current_process}\n"
        f"Folder identities: {folder_identities}\n"
        f"Native command: {native_status}\n"
        f"Hook: {hook_status}\n"
        f"Hook path: {hooks['path']}\n"
        "Use --mycel-status --json for machine-readable output.\n"
    )


def _is_native_inspection(provider_args: list[str]) -> bool:
    return len(provider_args) == 1 and provider_args[0] in NATIVE_INSPECTION_ARGS


def _parse_provider_args(provider: str, provider_args: list[str]) -> ParsedProviderArgs:
    local_id: str | None = None
    remaining = list(provider_args)
    native_args: list[str] = []
    while remaining:
        item = remaining.pop(0)
        if item == "--":
            native_args.extend(remaining)
            break
        if item == "--identity":
            if not remaining or remaining[0] == "--":
                raise RuntimeError(f"{item} requires a local identity id")
            local_id = remaining.pop(0)
            continue
        native_args.append(item)
        native_args.extend(remaining)
        break
    if not provider_args:
        return ParsedProviderArgs(local_id=None, native_args=[])
    return ParsedProviderArgs(local_id=local_id, native_args=native_args)


def _bind_cli_command(env: dict[str, str]) -> None:
    command = current_cli_command()
    env["MYCEL_CLI_COMMAND"] = command
    cli_bin = current_cli_bin()
    if cli_bin is None:
        return
    env["MYCEL_CLI_BIN"] = str(cli_bin)
    env["PATH"] = os.pathsep.join([str(cli_bin), env.get("PATH", "")])


def _identity_matches_provider(
    store: IdentityStore,
    local_id: str,
    provider: str,
) -> bool:
    try:
        identity = store.get_identity(local_id)
    except RuntimeError:
        return False
    return identity.get("provider") == provider


def _current_process_identity(
    store: IdentityStore,
    provider: str,
    env: Mapping[str, str],
) -> str | None:
    local_id = env.get("MYCEL_LOCAL_ID")
    if local_id is None:
        return None
    if env.get("MYCEL_PROVIDER") not in {None, provider}:
        return None
    if not _identity_matches_provider(store, local_id, provider):
        return None
    return local_id
