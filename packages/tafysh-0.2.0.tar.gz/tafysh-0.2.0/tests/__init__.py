"""Tests for TafySH."""
