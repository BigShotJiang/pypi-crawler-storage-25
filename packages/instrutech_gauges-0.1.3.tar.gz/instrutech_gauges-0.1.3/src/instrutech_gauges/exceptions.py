from __future__ import annotations


class InstruTechError(Exception):
    """Base class for driver errors."""


class InstruTechProtocolError(InstruTechError):
    """Raised when response framing/format is invalid."""


class InstruTechDeviceError(InstruTechError):
    """Raised when the device returns an explicit error response ('?...')."""

    def __init__(self, code: str, message: str, raw: str):
        super().__init__(f"InstruTech device error {code}: {message} (raw={raw!r})")
        self.code = code
        self.message = message
        self.raw = raw


class InstruTechTimeoutError(InstruTechError):
    """Raised when no response arrives before timeout."""


class InstruTechReconfigureError(InstruTechError):
    """Raised when comm reconfiguration was attempted but relink failed."""


class InstruTechUnsupportedCommandError(InstruTechError):
    """Raised when optional command families are unsupported."""


class InstruTechUnsupportedTransportOperationError(InstruTechError):
    """Raised when a command is invalid for the current transport mode."""
