from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Literal

from .base import InstruTechAsciiGauge
from .exceptions import (
    InstruTechDeviceError,
    InstruTechProtocolError,
    InstruTechUnsupportedCommandError,
)
from .transport import BaseTransport


class PressureUnit(str, Enum):
    TORR = "T"
    MBAR = "M"
    PASCAL = "P"


class EmissionSetting(int, Enum):
    U100 = 0  # 100 uA
    MA4 = 1  # 4 mA


class RelayName(str, Enum):
    I = "I"
    A = "A"
    B = "B"


@dataclass(frozen=True)
class IGM402TripPoint:
    mode: Literal["on_below", "off_above"]
    value_torr: float


class HornetIGM402(InstruTechAsciiGauge):
    def __init__(
        self,
        transport: BaseTransport,
        *,
        address: int = 1,
        node: int | None = None,
        min_cmd_interval_s: float = 0.05,
    ) -> None:
        if node is not None:
            address = node
        super().__init__(
            transport, address=address, min_cmd_interval_s=min_cmd_interval_s
        )
        self.supports_ru: bool = False
        self.supports_rdig: bool = False

    def open(self, *, probe: bool = True) -> None:
        super().open(probe=probe)
        if probe:
            self._probe_capabilities()

    def _probe_capabilities(self) -> None:
        try:
            _ = self.read_pressure_unit()
            self.supports_ru = True
        except InstruTechUnsupportedCommandError:
            self.supports_ru = False

        try:
            _ = self.read_ig_ion_current_a()
            self.supports_rdig = True
        except InstruTechUnsupportedCommandError:
            self.supports_rdig = False

    @staticmethod
    def _is_syntax_error(exc: InstruTechDeviceError) -> bool:
        text = f"{exc.code} {exc.message}".upper()
        return "SYNTX" in text

    # --------------------- basic ---------------------
    def read_ig_pressure_torr(self) -> float:
        return self.read_pressure_torr()

    def read_system_pressure_torr(self) -> float:
        return self.query_float("RDS")

    def read_cg_pressure_torr(self, cg: Literal[1, 2]) -> float:
        return self.query_float(f"RDCG{cg}")

    # --------------------- ig / degas ---------------------
    def ig_on(self) -> None:
        self.command_prog_ok("IG1")

    def ig_off(self) -> None:
        self.command_prog_ok("IG0")

    def read_ig_on(self) -> bool:
        return self._payload_bool_status(
            self.query("IGS"), true_text="1 IG ON", false_text="0 IG OFF"
        )

    def degas_on(self) -> None:
        self.command_prog_ok("DG1")

    def degas_off(self) -> None:
        self.command_prog_ok("DG0")

    def read_degas_on(self) -> bool:
        return self._payload_bool_status(
            self.query("DGS"), true_text="1 DG ON", false_text="0 DG OFF"
        )

    def read_ig_status_code(self) -> str:
        return self.query("RS")

    # --------------------- emission ---------------------
    def read_emission_setting(self) -> EmissionSetting:
        token = self._payload_token(self.query("SES"))
        normalized = token.upper().replace(" ", "")
        if normalized.startswith(("0.1MA", "0.10MA", "100UA")):
            return EmissionSetting.U100
        if normalized.startswith(("4.0MA", "4MA")):
            return EmissionSetting.MA4
        raise InstruTechProtocolError(f"Invalid emission setting payload: {token!r}")

    def set_emission(self, setting: EmissionSetting) -> None:
        self.command_prog_ok(f"SE{int(setting)}")

    def set_filament(self, filament: Literal[1, 2]) -> None:
        self.command_prog_ok(f"SF{filament}")

    # --------------------- relays ---------------------
    def set_trip_point(
        self,
        relay: RelayName,
        mode: Literal["on_below", "off_above"],
        value_torr: float,
    ) -> None:
        sign = "+" if mode == "on_below" else "-"
        val = f"{abs(value_torr):.2E}"

        if relay == RelayName.I:
            cmd = f"SL{sign}{val}"
        elif relay == RelayName.A:
            cmd = f"SLA{sign}{val}"
        elif relay == RelayName.B:
            cmd = f"SLB{sign}{val}"
        else:
            raise ValueError(f"Unknown relay {relay}")

        self.command_prog_ok(cmd)

    def read_trip_point(
        self,
        relay: RelayName,
        mode: Literal["on_below", "off_above"],
    ) -> IGM402TripPoint:
        sign = "+" if mode == "on_below" else "-"

        if relay == RelayName.I:
            cmd = f"RL{sign}"
        elif relay == RelayName.A:
            cmd = f"RLA{sign}"
        elif relay == RelayName.B:
            cmd = f"RLB{sign}"
        else:
            raise ValueError(f"Unknown relay {relay}")

        return IGM402TripPoint(mode=mode, value_torr=self.query_float(cmd))

    # --------------------- units ---------------------
    def require_ru(self) -> None:
        if not self.supports_ru:
            raise InstruTechUnsupportedCommandError(
                "RU/SU commands not supported by this firmware."
            )

    def read_pressure_unit(self) -> PressureUnit:
        try:
            token = self._payload_token(self.query("RU"))
        except InstruTechDeviceError as exc:
            if self._is_syntax_error(exc):
                raise InstruTechUnsupportedCommandError(
                    "RU/SU commands not supported by this firmware."
                ) from exc
            raise
        token = token.upper()
        token = {"TORR": "T", "MBAR": "M", "PASCAL": "P"}.get(token, token)
        try:
            return PressureUnit(token)
        except ValueError as exc:
            raise InstruTechProtocolError(
                f"Invalid pressure unit payload: {token!r}"
            ) from exc

    def set_pressure_unit(self, unit: PressureUnit) -> None:
        self.command_prog_ok(f"SU{unit.value}")

    # --------------------- CG calibration ---------------------
    def set_cg_zero(self, cg: Literal[1, 2], value_torr: float = 0.0) -> None:
        suffix = "A" if cg == 1 else "B"
        self.command_prog_ok(f"TZ{suffix} {value_torr:.2E}")

    def set_cg_span(self, cg: Literal[1, 2], value_torr: float = 760.0) -> None:
        suffix = "A" if cg == 1 else "B"
        self.command_prog_ok(f"TS{suffix}{value_torr:.2E}")

    # --------------------- optional RDIG* ---------------------
    def require_rdig(self) -> None:
        if not self.supports_rdig:
            raise InstruTechUnsupportedCommandError(
                "RDIG* commands not supported by this firmware."
            )

    def read_ig_ion_current_a(self) -> float:
        try:
            return self.query_float("RDIGC")
        except InstruTechDeviceError as exc:
            if self._is_syntax_error(exc):
                raise InstruTechUnsupportedCommandError(
                    "RDIG* commands not supported by this firmware."
                ) from exc
            raise

    def read_ig_emission_current_a(self) -> float:
        try:
            return self.query_float("RDIGE")
        except InstruTechDeviceError as exc:
            if self._is_syntax_error(exc):
                raise InstruTechUnsupportedCommandError(
                    "RDIG* commands not supported by this firmware."
                ) from exc
            raise

    def read_ig_filament_voltage_v(self) -> float:
        try:
            return self.query_float("RDIGV")
        except InstruTechDeviceError as exc:
            if self._is_syntax_error(exc):
                raise InstruTechUnsupportedCommandError(
                    "RDIG* commands not supported by this firmware."
                ) from exc
            raise

    def read_ig_filament_current_a(self) -> float:
        try:
            return self.query_float("RDIGA")
        except InstruTechDeviceError as exc:
            if self._is_syntax_error(exc):
                raise InstruTechUnsupportedCommandError(
                    "RDIG* commands not supported by this firmware."
                ) from exc
            raise

    # --------------------- comm changes ---------------------
    def unlock_comm_programming(self) -> None:
        self.command_prog_ok("UNL")

    def toggle_unl_function(self) -> bool:
        return self._payload_token(self.query("TLU")) == "1"

    def _before_serial_reconfigure(self) -> None:
        try:
            self.unlock_comm_programming()
        except InstruTechDeviceError as exc:
            if self._is_syntax_error(exc):
                # UL_OFF mode: UNL intentionally unsupported and not required.
                return
            raise

    # Keep defaults compatible with existing Hornet behavior:
    # commands take effect immediately and no reset is sent.
    def set_baud(
        self,
        baud: int,
        *,
        verify: bool = True,
        relink_retries: int = 3,
        relink_delay_s: float = 0.2,
        reset_after: bool = False,
    ) -> None:
        super().set_baud(
            baud,
            verify=verify,
            relink_retries=relink_retries,
            relink_delay_s=relink_delay_s,
            reset_after=reset_after,
        )

    def set_parity(
        self,
        parity: Literal["N", "O", "E"],
        *,
        verify: bool = True,
        relink_retries: int = 3,
        relink_delay_s: float = 0.2,
        reset_after: bool = False,
    ) -> None:
        data_bits: Literal[7, 8] = 8 if parity.upper() == "N" else 7
        super().set_parity(
            parity,
            verify=verify,
            relink_retries=relink_retries,
            relink_delay_s=relink_delay_s,
            reset_after=reset_after,
            data_bits=data_bits,
        )

    def set_serial_comm(
        self,
        *,
        baud: int | None = None,
        parity: Literal["N", "O", "E"] | None = None,
        verify_each_step: bool = True,
        relink_retries: int = 3,
        relink_delay_s: float = 0.2,
        reset_after: bool = False,
    ) -> None:
        super().set_serial_comm(
            baud=baud,
            parity=parity,
            verify_each_step=verify_each_step,
            relink_retries=relink_retries,
            relink_delay_s=relink_delay_s,
            reset_after=reset_after,
        )
