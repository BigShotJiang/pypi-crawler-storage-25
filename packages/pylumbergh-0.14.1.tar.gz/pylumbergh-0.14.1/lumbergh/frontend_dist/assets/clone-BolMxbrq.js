import{b as r}from"./graph-CYx5BOgD.js";var e=4;function a(o){return r(o,e)}export{a as c};
