"""Segmenter based on Spacy"""

__version__ = "1.6.40"
