export const CHAT_SIDE_PANEL_ID = 'JupyterlabChat:sidepanel';
export const CHAT_COMMAND_ID = 'jupyterlab-chat:openWithMessage';

export const VALIDATION_LIMITS = {
  PROMPT_MAX_LENGTH: 1000,
};

export const ERROR_MESSAGES = {
  MISSING_PROMPT: 'The "prompt" parameter is required',
  INVALID_INPUT: 'Invalid input detected. Please check your parameters.',
  PROMPT_TOO_LONG: `Prompt exceeds maximum length of ${VALIDATION_LIMITS.PROMPT_MAX_LENGTH} characters`,
};

export const DIALOG_CONFIG = {
  TITLE: 'Run prompt',
  BODY_PREFIX: 'The following prompt will run in Jupyter AI:',
  ACCEPT_LABEL: 'Run',
  DECLINE_LABEL: 'Cancel',
};

export const QUERY_PARAMS = {
  COMMAND: 'command',
  PROMPT: 'prompt',
};

export const COMMAND_ID = 'conversation:start-deeplink';

// Allowlist of valid command parameter values for deeplink URLs
export const VALID_COMMANDS = ['start-conversation'] as const;

export const TEMPLATE_VAR_PATTERN = /\{([a-zA-Z0-9_]+)\}/g;
