import { JupyterFrontEnd, JupyterFrontEndPlugin, IRouter } from '@jupyterlab/application';
import { URLExt } from '@jupyterlab/coreutils';
import { Dialog, showDialog, showErrorMessage } from '@jupyterlab/apputils';
import { Widget } from '@lumino/widgets';
import { getLoggerForPlugin, pluginIds } from '../../constants';
import { ILogger } from '../LoggerPlugin';
import { i18nStrings } from '../../constants/i18nStrings';
import {
  COMMAND_ID,
  CHAT_COMMAND_ID,
  CHAT_SIDE_PANEL_ID,
  DIALOG_CONFIG,
  ERROR_MESSAGES,
  QUERY_PARAMS,
  VALID_COMMANDS,
} from './constants';
import { ValidationError, sanitizeQueryParam, validatePrompt, substituteTemplateVariables } from './utils';

const i18nErrorStrings = i18nStrings.ConversationDeeplinking.errorDialog;

// IRouter pattern could be matched arbitrary number of times.
// This flag ensures we only trigger the deeplink dialog once per page load.
let hasExecuted = false;

/**
 * Handles the deeplink command execution.
 * Extracts query parameters from the current URL, validates and sanitizes them,
 * performs template variable substitution, and prepares the prompt for dialog display.
 * @param app - JupyterFrontEnd application instance for executing commands
 * @param router - IRouter service for accessing current URL state
 * @param logger - ILogger service for logging
 * @returns The substituted prompt string, or undefined if execution was skipped or failed
 */
const handleDeeplinkCommand = async (
  app: JupyterFrontEnd,
  router: IRouter,
  logger: ILogger,
): Promise<string | undefined> => {
  // Single execution pattern: return early if already executed
  if (hasExecuted) {
    return undefined;
  }
  hasExecuted = true;

  try {
    const { search } = router.current;
    const queryParams = search ? URLExt.queryStringToObject(search) : {};

    // Validate command parameter against allowlist
    const command = queryParams[QUERY_PARAMS.COMMAND];
    if (!VALID_COMMANDS.includes(command as (typeof VALID_COMMANDS)[number])) {
      throw new ValidationError(ERROR_MESSAGES.INVALID_INPUT);
    }

    // Check if prompt parameter exists
    if (!queryParams[QUERY_PARAMS.PROMPT]) {
      throw new ValidationError(ERROR_MESSAGES.MISSING_PROMPT);
    }

    // Sanitize all query parameters
    const sanitizedParams: Record<string, string> = {};
    for (const [key, value] of Object.entries(queryParams)) {
      if (value === undefined) continue;
      try {
        sanitizedParams[key] = sanitizeQueryParam(value, key);
      } catch (e) {
        logger.error({
          Message: `Sanitization failed for parameter "${key}"`,
          Error: e instanceof Error ? e : new Error(String(e)),
        });
        throw new ValidationError(ERROR_MESSAGES.INVALID_INPUT);
      }
    }

    // Validate prompt
    validatePrompt(sanitizedParams[QUERY_PARAMS.PROMPT]);

    // Substitute template variables in the prompt
    const substitutedPrompt = substituteTemplateVariables(sanitizedParams[QUERY_PARAMS.PROMPT], sanitizedParams);

    // Show dialog non-blocking so JupyterLab continues loading in the background
    showConversationDialog(substitutedPrompt)
      .then(async (result) => {
        // Clean all deeplink query params from URL to prevent re-trigger on refresh
        const cleanUrl = new URL(window.location.href);
        cleanUrl.search = '';
        window.history.replaceState({}, '', cleanUrl.toString());

        if (result.button.accept) {
          await app.commands.execute(CHAT_COMMAND_ID, {
            name: `deeplink-conversation-${new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19)}`,
            path: '',
            inSidePanel: true,
            input: substitutedPrompt,
            autoSend: true,
          });

          setTimeout(() => {
            app.shell.activateById(CHAT_SIDE_PANEL_ID);
          }, 500);

          logger.info({ Message: 'Conversation deeplink command executed' });
        } else {
          logger.info({ Message: 'Conversation deeplink command declined by user' });
        }
      })
      .catch((dialogError) => {
        logger.error({
          Message: 'Error in deeplink dialog handler',
          Error: dialogError instanceof Error ? dialogError : new Error(String(dialogError)),
        });
      });

    return substitutedPrompt;
  } catch (error) {
    if (error instanceof ValidationError) {
      await showErrorMessage(i18nErrorStrings.errorTitle, { message: error.message });
      logger.warn({ Message: 'Validation error in deeplink handler', Error: error });
    } else {
      await showErrorMessage(i18nErrorStrings.errorTitle, { message: i18nErrorStrings.defaultErrorMessage });
      logger.error({
        Message: 'Unexpected error in deeplink handler',
        Error: error instanceof Error ? error : new Error(String(error)),
      });
    }
    return undefined;
  }
};

/**
 * Displays a modal dialog with the substituted prompt text and Accept/Decline buttons.
 * Uses text-only rendering for the body content to prevent XSS.
 * @param substitutedPrompt - The prompt text with template variables already substituted
 * @returns The dialog result indicating whether the user clicked Accept or Decline
 */
const showConversationDialog = async (substitutedPrompt: string): Promise<Dialog.IResult<string>> => {
  const bodyNode = document.createElement('div');

  const prefixEl = document.createElement('p');
  prefixEl.textContent = DIALOG_CONFIG.BODY_PREFIX;
  bodyNode.appendChild(prefixEl);

  const promptEl = document.createElement('p');
  promptEl.textContent = substitutedPrompt;
  promptEl.style.fontWeight = 'bold';
  bodyNode.appendChild(promptEl);

  const bodyWidget = new Widget({ node: bodyNode });

  return showDialog<string>({
    title: DIALOG_CONFIG.TITLE,
    body: bodyWidget,
    buttons: [
      Dialog.cancelButton({ label: DIALOG_CONFIG.DECLINE_LABEL }),
      Dialog.okButton({ label: DIALOG_CONFIG.ACCEPT_LABEL }),
    ],
  });
};

/**
 * Plugin to handle conversation deeplink URLs.
 * Registers a router pattern to match ?command=start-conversation and
 * triggers a modal dialog for the user to confirm or decline the conversation.
 */
const ConversationDeeplinkingPlugin: JupyterFrontEndPlugin<void> = {
  id: pluginIds.ConversationDeeplinkingPlugin,
  requires: [IRouter, ILogger],
  autoStart: true,
  activate: async (app: JupyterFrontEnd, router: IRouter, baseLogger: ILogger) => {
    const { commands } = app;
    const logger = getLoggerForPlugin(baseLogger, pluginIds.ConversationDeeplinkingPlugin);

    logger.info({ Message: 'Conversation Deeplink Plugin activated' });

    commands.addCommand(COMMAND_ID, {
      execute: () => handleDeeplinkCommand(app, router, logger),
    });

    router.register({
      command: COMMAND_ID,
      pattern: new RegExp('[?&]command=[^&]+'),

      rank: 10,
    });
  },
};

export { ConversationDeeplinkingPlugin, handleDeeplinkCommand, showConversationDialog };
