import {
  containsDangerousPatterns,
  stripHtmlTags,
  validatePrompt,
  sanitizeQueryParam,
  substituteTemplateVariables,
  ValidationError,
} from '../utils';
import { ERROR_MESSAGES, VALIDATION_LIMITS } from '../constants';

describe('containsDangerousPatterns', () => {
  it('should detect HTML tags', () => {
    expect(containsDangerousPatterns('<script>alert("xss")</script>')).toBe(true);
    expect(containsDangerousPatterns('<iframe src="evil.com">')).toBe(true);
    expect(containsDangerousPatterns('<object data="evil">')).toBe(true);
    expect(containsDangerousPatterns('<embed src="evil">')).toBe(true);
  });

  it('should detect JavaScript protocol handlers', () => {
    expect(containsDangerousPatterns('javascript:alert(1)')).toBe(true);
    expect(containsDangerousPatterns('data:text/html,<h1>hi</h1>')).toBe(true);
    expect(containsDangerousPatterns('data:text/javascript,alert(1)')).toBe(true);
    expect(containsDangerousPatterns('vbscript:MsgBox("xss")')).toBe(true);
  });

  it('should detect event handler attributes', () => {
    expect(containsDangerousPatterns('onclick=alert(1)')).toBe(true);
    expect(containsDangerousPatterns('onerror=alert(1)')).toBe(true);
    expect(containsDangerousPatterns('onload =alert(1)')).toBe(true);
  });

  it('should return false for safe text', () => {
    expect(containsDangerousPatterns('Hello world')).toBe(false);
    expect(containsDangerousPatterns('model-v2.1')).toBe(false);
    expect(containsDangerousPatterns('Explain the model {model_id}')).toBe(false);
  });
});

describe('validatePrompt', () => {
  it('should return true for valid prompt within length limit', () => {
    expect(validatePrompt('Hello')).toBe(true);
  });

  it('should return true for prompt exactly at the limit', () => {
    const prompt = 'a'.repeat(VALIDATION_LIMITS.PROMPT_MAX_LENGTH);
    expect(validatePrompt(prompt)).toBe(true);
  });

  it('should throw ValidationError for prompt exceeding length limit', () => {
    const prompt = 'a'.repeat(VALIDATION_LIMITS.PROMPT_MAX_LENGTH + 1);
    expect(() => validatePrompt(prompt)).toThrow(ValidationError);
    expect(() => validatePrompt(prompt)).toThrow(ERROR_MESSAGES.PROMPT_TOO_LONG);
  });
});

describe('sanitizeQueryParam', () => {
  it('should return escaped value for safe input', () => {
    expect(sanitizeQueryParam('Hello world', 'prompt')).toBe('Hello world');
  });

  it('should preserve special characters in safe input', () => {
    expect(sanitizeQueryParam('a & b', 'prompt')).toBe('a & b');
  });

  it('should strip HTML tags and return clean text', () => {
    expect(sanitizeQueryParam('<script>alert(1)</script>', 'prompt')).toBe('alert(1)');
  });

  it('should strip script tags from prompt with template variables', () => {
    expect(sanitizeQueryParam('Start model customization for {model_id} <script="test.js">', 'prompt')).toBe(
      'Start model customization for {model_id} ',
    );
  });

  it('should strip html tags from prompt with template variables', () => {
    expect(sanitizeQueryParam('Start model customization for {model_id} <html="hacked">', 'prompt')).toBe(
      'Start model customization for {model_id} ',
    );
  });

  it('should pass through clean prompt with template variables unchanged', () => {
    expect(sanitizeQueryParam('Start model customization for {model_id}', 'prompt')).toBe(
      'Start model customization for {model_id}',
    );
  });

  it('should throw ValidationError for input with JavaScript protocol', () => {
    expect(() => sanitizeQueryParam('javascript:alert(1)', 'prompt')).toThrow(ValidationError);
  });

  it('should throw ValidationError for input with event handlers', () => {
    expect(() => sanitizeQueryParam('onclick=alert(1)', 'prompt')).toThrow(ValidationError);
  });

  it('should throw ValidationError for data:text/javascript URI', () => {
    expect(() => sanitizeQueryParam('data:text/javascript,alert(1)', 'prompt')).toThrow(ValidationError);
  });

  it('should throw ValidationError for vbscript: protocol', () => {
    expect(() => sanitizeQueryParam('vbscript:MsgBox("xss")', 'prompt')).toThrow(ValidationError);
  });

  it('should include parameter name in error message', () => {
    expect(() => sanitizeQueryParam('javascript:void(0)', 'myParam')).toThrow('(parameter: myParam)');
  });
});

describe('stripHtmlTags', () => {
  it('should remove script tags', () => {
    expect(stripHtmlTags('hello <script>alert(1)</script> world')).toBe('hello alert(1) world');
  });

  it('should remove tags with attributes', () => {
    expect(stripHtmlTags('text <html="hacked"> more')).toBe('text  more');
  });

  it('should remove self-closing tags', () => {
    expect(stripHtmlTags('text <br/> more')).toBe('text  more');
  });

  it('should return unchanged text when no tags present', () => {
    expect(stripHtmlTags('Hello {model_id}')).toBe('Hello {model_id}');
  });
});

describe('substituteTemplateVariables', () => {
  it('should substitute a single template variable', () => {
    const result = substituteTemplateVariables('Hello {name}', { name: 'World' });
    expect(result).toBe('Hello World');
  });

  it('should substitute multiple template variables', () => {
    const result = substituteTemplateVariables('Model {model_id} version {version}', {
      model_id: 'claude-v2',
      version: '1.0',
    });
    expect(result).toBe('Model claude-v2 version 1.0');
  });

  it('should leave template variables unchanged when no corresponding parameter exists', () => {
    const result = substituteTemplateVariables('Hello {name}', {});
    expect(result).toBe('Hello {name}');
  });

  it('should substitute some variables and leave others unchanged', () => {
    const result = substituteTemplateVariables('{greeting} {name}', { greeting: 'Hi' });
    expect(result).toBe('Hi {name}');
  });

  it('should return the same string if no template variables exist', () => {
    const result = substituteTemplateVariables('Hello world', { name: 'test' });
    expect(result).toBe('Hello world');
  });
});
