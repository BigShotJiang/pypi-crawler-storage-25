import { Notification } from '@jupyterlab/apputils';
import { pluginIds } from '../../../constants';

const mockMakeRequest = jest.fn();
const mockMakeSettings = jest.fn().mockReturnValue({ baseUrl: 'http://localhost:8888/' });

jest.mock('@jupyterlab/application', () => ({
  JupyterFrontEnd: jest.fn(),
  JupyterFrontEndPlugin: jest.fn(),
}));

jest.mock('@jupyterlab/apputils', () => ({
  Notification: {
    info: jest.fn(),
  },
}));

jest.mock('@jupyterlab/ui-components', () => ({
  LabIcon: jest.fn().mockImplementation(() => ({ name: 'mock-icon' })),
}));

jest.mock('../../../components/icons', () => ({
  aiChatIcon: { name: 'mock-ai-chat-icon' },
}));

jest.mock('@jupyterlab/services', () => ({
  ServerConnection: {
    makeRequest: (...args: unknown[]) => mockMakeRequest(...args),
    makeSettings: (...args: unknown[]) => mockMakeSettings(...args),
  },
}));

jest.mock('@jupyterlab/coreutils', () => ({
  URLExt: { join: (...parts: string[]) => parts.join('/').replace(/\/+/g, '/') },
}));

jest.mock('../../../constants/fetchapi', () => ({
  SAGEMAKER_AUTH_DETAILS_ENDPOINT: '/aws/sagemaker/api/auth-details',
}));

jest.mock('../../../types', () => ({
  AppEnvironment: {
    SMStudio: 'SageMaker Studio',
    SMStudioSSO: 'SageMaker Studio SSO',
    MD_IAM: 'MD_IAM',
    MD_IDC: 'MD_IDC',
    MD_SAML: 'MD_SAML',
  },
}));

jest.mock('../constants', () => ({
  CHAT_SIDE_PANEL_ID: 'JupyterlabChat:sidepanel',
  CHAT_COMMAND_ID: 'jupyterlab-chat:openWithMessage',
}));

const mockLogger = {
  fatal: jest.fn().mockResolvedValue(undefined),
  error: jest.fn().mockResolvedValue(undefined),
  warn: jest.fn().mockResolvedValue(undefined),
  info: jest.fn().mockResolvedValue(undefined),
  debug: jest.fn().mockResolvedValue(undefined),
  trace: jest.fn().mockResolvedValue(undefined),
  child: jest.fn().mockReturnThis(),
};

jest.mock('../../../constants', () => ({
  pluginIds: {
    ConversationAnnouncementPlugin: '@amzn/sagemaker-jupyterlab-extension-common:conversation-announcement',
  },
  getLoggerForPlugin: jest.fn(() => mockLogger),
}));

jest.mock('../../LoggerPlugin', () => ({
  ILogger: { name: 'ILogger' },
}));

function mockAuthResponse(environment: string) {
  mockMakeRequest.mockResolvedValue({
    json: () => Promise.resolve({ environment, isQDeveloperEnabled: true }),
  });
}

describe('ConversationAnnouncementPlugin', () => {
  // eslint-disable-next-line @typescript-eslint/no-var-requires
  let ConversationAnnouncementPlugin: typeof import('../ConversationAnnouncementPlugin').ConversationAnnouncementPlugin;

  const mockHasCommand = jest.fn();
  const mockActivateById = jest.fn();
  const mockChatPanelTitle = { icon: null };
  const mockChatPanel = { id: 'JupyterlabChat:sidepanel', title: mockChatPanelTitle };
  let restoredPromise: Promise<void>;
  let mockApp: any; // eslint-disable-line @typescript-eslint/no-explicit-any

  let localStorageMock: Record<string, string>;

  beforeEach(() => {
    jest.clearAllMocks();
    localStorageMock = {};
    jest.spyOn(Storage.prototype, 'getItem').mockImplementation((key) => localStorageMock[key] ?? null);
    jest.spyOn(Storage.prototype, 'setItem').mockImplementation((key, value) => {
      localStorageMock[key] = value;
    });

    mockHasCommand.mockReturnValue(true);
    mockChatPanelTitle.icon = null;
    restoredPromise = Promise.resolve();
    mockApp = {
      restored: restoredPromise,
      shell: {
        activateById: mockActivateById,
        widgets: jest.fn(() => [mockChatPanel][Symbol.iterator]()),
      },
      commands: { hasCommand: mockHasCommand },
    };

    mockAuthResponse('SageMaker Studio SSO');

    jest.isolateModules(() => {
      // eslint-disable-next-line @typescript-eslint/no-var-requires
      const mod = require('../ConversationAnnouncementPlugin');
      ConversationAnnouncementPlugin = mod.ConversationAnnouncementPlugin;
    });
  });

  afterEach(() => {
    jest.restoreAllMocks();
  });

  const activate = async () => {
    ConversationAnnouncementPlugin.activate(mockApp, mockLogger as any); // eslint-disable-line @typescript-eslint/no-explicit-any
    await restoredPromise;
    await Promise.resolve();
    await Promise.resolve();
  };

  it('should have correct plugin configuration', () => {
    expect(ConversationAnnouncementPlugin.id).toBe(pluginIds.ConversationAnnouncementPlugin);
    expect(ConversationAnnouncementPlugin.autoStart).toBe(true);
  });

  it('should show notification in SageMaker Studio SSO with chat available', async () => {
    await activate();

    expect(Notification.info).toHaveBeenCalledWith(
      expect.stringContaining('Agentic assistants with SageMaker AI Skills'),
      expect.objectContaining({
        autoClose: false,
        actions: expect.arrayContaining([expect.objectContaining({ label: 'Get Started' })]),
      }),
    );
    expect(mockLogger.info).toHaveBeenCalledWith(
      expect.objectContaining({ Message: 'AI chat announcement notification displayed' }),
    );
  });

  it('should show notification in SageMaker Studio (non-SSO)', async () => {
    mockAuthResponse('SageMaker Studio');
    await activate();

    expect(Notification.info).toHaveBeenCalled();
  });

  it('should not show notification when already dismissed', async () => {
    localStorageMock['notification_seen_conversation_announcement'] = 'true';
    await activate();

    expect(Notification.info).not.toHaveBeenCalled();
    expect(mockLogger.debug).toHaveBeenCalledWith(
      expect.objectContaining({ Message: 'Announcement already dismissed, skipping notification' }),
    );
  });

  it('should not show notification when chat plugin is not available', async () => {
    mockHasCommand.mockReturnValue(false);
    await activate();

    expect(Notification.info).not.toHaveBeenCalled();
    expect(mockLogger.debug).toHaveBeenCalledWith(
      expect.objectContaining({ Message: 'Chat plugin not available, skipping' }),
    );
  });

  it('should not show notification when not in SageMaker Studio', async () => {
    mockAuthResponse('MD_IAM');
    await activate();

    expect(Notification.info).not.toHaveBeenCalled();
    expect(mockLogger.debug).toHaveBeenCalledWith(
      expect.objectContaining({ Message: 'Not in SageMaker Studio environment, skipping' }),
    );
  });

  it('should not show notification when auth-details API fails', async () => {
    mockMakeRequest.mockRejectedValue(new Error('Network error'));
    await activate();

    expect(Notification.info).not.toHaveBeenCalled();
  });

  it('should not show notification when auth-details request times out', async () => {
    const abortError = new DOMException('The operation was aborted', 'AbortError');
    mockMakeRequest.mockRejectedValue(abortError);
    await activate();

    expect(Notification.info).not.toHaveBeenCalled();
  });

  it('should set dismissed flag in localStorage', async () => {
    await activate();

    expect(localStorage.setItem).toHaveBeenCalledWith('notification_seen_conversation_announcement', 'true');
  });

  it('should open chat panel when Get Started is clicked', async () => {
    await activate();

    const call = (Notification.info as jest.Mock).mock.calls[0];
    const getStartedAction = call[1].actions[0];
    getStartedAction.callback();

    expect(mockActivateById).toHaveBeenCalledWith('JupyterlabChat:sidepanel');
    expect(mockLogger.info).toHaveBeenCalledWith(
      expect.objectContaining({ Message: 'User clicked Get Started on AI chat announcement' }),
    );
  });

  it('should swap chat panel icon when conditions are met', async () => {
    await activate();

    expect(mockChatPanelTitle.icon).toEqual({ name: 'mock-ai-chat-icon' });
    expect(mockLogger.info).toHaveBeenCalledWith(expect.objectContaining({ Message: 'Chat panel icon updated' }));
  });

  it('should swap icon even when notification is already dismissed', async () => {
    localStorageMock['notification_seen_conversation_announcement'] = 'true';
    await activate();

    expect(mockChatPanelTitle.icon).toEqual({ name: 'mock-ai-chat-icon' });
  });

  it('should not swap icon when not in SageMaker Studio', async () => {
    mockAuthResponse('MD_IAM');
    await activate();

    expect(mockChatPanelTitle.icon).toBeNull();
  });

  it('should not swap icon when chat plugin is not available', async () => {
    mockHasCommand.mockReturnValue(false);
    await activate();

    expect(mockChatPanelTitle.icon).toBeNull();
  });

  it('should log error when app.restored rejects', async () => {
    const error = new Error('Restore failed');
    mockApp.restored = Promise.reject(error);

    ConversationAnnouncementPlugin.activate(mockApp, mockLogger as any); // eslint-disable-line @typescript-eslint/no-explicit-any
    await Promise.resolve();
    await Promise.resolve();

    expect(mockLogger.error).toHaveBeenCalledWith(
      expect.objectContaining({ Message: 'Error in ConversationAnnouncementPlugin' }),
    );
  });
});
