import { IRouter } from '@jupyterlab/application';
import { URLExt } from '@jupyterlab/coreutils';
import { showDialog, showErrorMessage } from '@jupyterlab/apputils';
import { COMMAND_ID, DIALOG_CONFIG } from '../constants';
import { pluginIds } from '../../../constants';

jest.mock('@jupyterlab/application', () => ({
  JupyterFrontEnd: jest.fn(),
  JupyterFrontEndPlugin: jest.fn(),
  IRouter: {
    name: 'IRouter',
  },
}));

jest.mock('@jupyterlab/coreutils', () => ({
  URLExt: {
    queryStringToObject: jest.fn(),
  },
}));

jest.mock('@jupyterlab/apputils', () => ({
  Dialog: {
    okButton: jest.fn(({ label }: { label: string }) => ({ label })),
    cancelButton: jest.fn(({ label }: { label: string }) => ({ label })),
  },
  showDialog: jest.fn(),
  showErrorMessage: jest.fn(),
}));

const mockLogger = {
  fatal: jest.fn().mockResolvedValue(undefined),
  error: jest.fn().mockResolvedValue(undefined),
  warn: jest.fn().mockResolvedValue(undefined),
  info: jest.fn().mockResolvedValue(undefined),
  debug: jest.fn().mockResolvedValue(undefined),
  trace: jest.fn().mockResolvedValue(undefined),
  child: jest.fn().mockReturnThis(),
};

jest.mock('../../../constants', () => ({
  pluginIds: {
    ConversationDeeplinkingPlugin: '@amzn/sagemaker-jupyterlab-extension-common:conversation-deeplinking',
    LoggerPlugin: '@amzn/sagemaker-jupyterlab-extension-common:logger',
  },
  getLoggerForPlugin: jest.fn((_baseLogger: any, _pluginId: string) => mockLogger),
}));

jest.mock('../../../constants/i18nStrings', () => ({
  i18nStrings: {
    ConversationDeeplinking: {
      errorDialog: {
        errorTitle: 'Error',
        defaultErrorMessage: 'An unexpected error occurred',
      },
    },
  },
}));

jest.mock('../../LoggerPlugin', () => ({
  ILogger: {
    name: 'ILogger',
  },
}));

describe('handleDeeplinkCommand', () => {
  let handleDeeplinkCommand: typeof import('../DeeplinkingPlugin').handleDeeplinkCommand;

  const mockExecute = jest.fn().mockResolvedValue(undefined);
  const mockActivateById = jest.fn();
  const mockApp = {
    commands: { execute: mockExecute, addCommand: jest.fn() },
    shell: { activateById: mockActivateById },
  } as any;

  const createMockRouter = (search: string): IRouter =>
    ({
      current: { search, request: '', path: '' },
      register: jest.fn(),
      route: jest.fn(),
      navigate: jest.fn(),
      routed: { connect: jest.fn(), disconnect: jest.fn() },
      base: '',
      stop: { connect: jest.fn(), disconnect: jest.fn() },
    } as unknown as IRouter);

  beforeEach(() => {
    jest.clearAllMocks();
    // Re-import the module to reset the hasExecuted flag
    jest.isolateModules(() => {
      // eslint-disable-next-line @typescript-eslint/no-var-requires
      const mod = require('../DeeplinkingPlugin');
      handleDeeplinkCommand = mod.handleDeeplinkCommand;
    });
  });

  it('should show error when query params are empty', async () => {
    const mockRouter = createMockRouter('');
    (URLExt.queryStringToObject as jest.Mock).mockReturnValue({});

    const result = await handleDeeplinkCommand(mockApp, mockRouter, mockLogger as any);

    expect(result).toBeUndefined();
    expect(showErrorMessage).toHaveBeenCalled();
  });

  it('should return undefined when command is not start-conversation', async () => {
    const mockRouter = createMockRouter('?command=other');
    (URLExt.queryStringToObject as jest.Mock).mockReturnValue({ command: 'other' });

    const result = await handleDeeplinkCommand(mockApp, mockRouter, mockLogger as any);

    expect(result).toBeUndefined();
    expect(showDialog).not.toHaveBeenCalled();
  });

  it('should return undefined when command contains injection attempt', async () => {
    const mockRouter = createMockRouter('?command=start-conversation%22%3Bimport%20os');
    (URLExt.queryStringToObject as jest.Mock).mockReturnValue({ command: 'start-conversation";import os' });

    const result = await handleDeeplinkCommand(mockApp, mockRouter, mockLogger as any);

    expect(result).toBeUndefined();
    expect(showDialog).not.toHaveBeenCalled();
  });

  it('should show error when prompt parameter is missing', async () => {
    const mockRouter = createMockRouter('?command=start-conversation');
    (URLExt.queryStringToObject as jest.Mock).mockReturnValue({ command: 'start-conversation' });

    const result = await handleDeeplinkCommand(mockApp, mockRouter, mockLogger as any);

    expect(result).toBeUndefined();
    expect(showErrorMessage).toHaveBeenCalled();
  });

  it('should display dialog with substituted prompt on valid input', async () => {
    const mockRouter = createMockRouter('?command=start-conversation&prompt=Hello%20{model_id}&model_id=claude-v2');
    (URLExt.queryStringToObject as jest.Mock).mockReturnValue({
      command: 'start-conversation',
      prompt: 'Hello {model_id}',
      model_id: 'claude-v2',
    });
    (showDialog as jest.Mock).mockResolvedValue({ button: { accept: true } });

    const result = await handleDeeplinkCommand(mockApp, mockRouter, mockLogger as any);

    expect(result).toBe('Hello claude-v2');
    const dialogCall = (showDialog as jest.Mock).mock.calls[0][0];
    expect(dialogCall.title).toBe(DIALOG_CONFIG.TITLE);
    expect(dialogCall.body.node.textContent).toContain(DIALOG_CONFIG.BODY_PREFIX);
    expect(dialogCall.body.node.textContent).toContain('Hello claude-v2');
  });

  it('should substitute model_id in prompt for real model IDs', async () => {
    const mockRouter = createMockRouter(
      '?command=start-conversation&prompt=Start%20model%20customization%20for%20%7Bmodel_id%7D&model_id=meta-vlm-llama-4-scout-17b-16e-instruct',
    );
    (URLExt.queryStringToObject as jest.Mock).mockReturnValue({
      command: 'start-conversation',
      prompt: 'Start model customization for {model_id}',
      model_id: 'meta-vlm-llama-4-scout-17b-16e-instruct',
    });
    (showDialog as jest.Mock).mockResolvedValue({ button: { accept: true } });

    const result = await handleDeeplinkCommand(mockApp, mockRouter, mockLogger as any);

    expect(result).toBe('Start model customization for meta-vlm-llama-4-scout-17b-16e-instruct');
    const dialogCall = (showDialog as jest.Mock).mock.calls[0][0];
    expect(dialogCall.title).toBe(DIALOG_CONFIG.TITLE);
    expect(dialogCall.body.node.textContent).toContain(DIALOG_CONFIG.BODY_PREFIX);
    expect(dialogCall.body.node.textContent).toContain(
      'Start model customization for meta-vlm-llama-4-scout-17b-16e-instruct',
    );
  });

  it('should open chat with prompt when user clicks Accept', async () => {
    const mockRouter = createMockRouter('?command=start-conversation&prompt=Test%20prompt');
    (URLExt.queryStringToObject as jest.Mock).mockReturnValue({
      command: 'start-conversation',
      prompt: 'Test prompt',
    });
    const dialogPromise = Promise.resolve({ button: { accept: true } });
    (showDialog as jest.Mock).mockReturnValue(dialogPromise);

    jest.useFakeTimers();

    await handleDeeplinkCommand(mockApp, mockRouter, mockLogger as any);

    // Flush the .then() chain by awaiting the same promise the code uses
    await dialogPromise;
    // One more tick for the async callback inside .then()
    await Promise.resolve();

    expect(mockExecute).toHaveBeenCalledWith(
      'jupyterlab-chat:openWithMessage',
      expect.objectContaining({
        name: expect.stringMatching(/^deeplink-conversation-\d{4}-\d{2}-\d{2}T\d{2}-\d{2}-\d{2}$/),
        path: '',
        inSidePanel: true,
        input: 'Test prompt',
        autoSend: true,
      }),
    );

    // The await inside .then() for execute needs another microtask flush
    // before setTimeout(500) gets scheduled
    await Promise.resolve();

    jest.advanceTimersByTime(500);
    expect(mockActivateById).toHaveBeenCalledWith('JupyterlabChat:sidepanel');
    jest.useRealTimers();
  });

  it('should not open chat when user clicks Decline', async () => {
    const mockRouter = createMockRouter('?command=start-conversation&prompt=Test%20prompt');
    (URLExt.queryStringToObject as jest.Mock).mockReturnValue({
      command: 'start-conversation',
      prompt: 'Test prompt',
    });
    const dialogPromise = Promise.resolve({ button: { accept: false } });
    (showDialog as jest.Mock).mockReturnValue(dialogPromise);

    await handleDeeplinkCommand(mockApp, mockRouter, mockLogger as any);

    // Flush the .then() chain
    await dialogPromise;
    await Promise.resolve();

    expect(mockExecute).not.toHaveBeenCalled();
    expect(mockActivateById).not.toHaveBeenCalled();
  });

  it('should only execute once (single execution pattern)', async () => {
    const mockRouter = createMockRouter('?command=start-conversation&prompt=Test');
    (URLExt.queryStringToObject as jest.Mock).mockReturnValue({
      command: 'start-conversation',
      prompt: 'Test',
    });
    (showDialog as jest.Mock).mockResolvedValue({ button: { accept: false } });

    // First call should execute
    await handleDeeplinkCommand(mockApp, mockRouter, mockLogger as any);
    expect(showDialog).toHaveBeenCalledTimes(1);

    // Second call should return early
    const result = await handleDeeplinkCommand(mockApp, mockRouter, mockLogger as any);
    expect(result).toBeUndefined();
    expect(showDialog).toHaveBeenCalledTimes(1);
  });

  it('should strip HTML tags from input and show dialog with clean text', async () => {
    const mockRouter = createMockRouter('?command=start-conversation&prompt=<script>alert(1)</script>');
    (URLExt.queryStringToObject as jest.Mock).mockReturnValue({
      command: 'start-conversation',
      prompt: '<script>alert(1)</script>',
    });
    (showDialog as jest.Mock).mockResolvedValue({ button: { accept: false } });

    const result = await handleDeeplinkCommand(mockApp, mockRouter, mockLogger as any);

    expect(result).toBe('alert(1)');
    expect(showDialog).toHaveBeenCalled();
  });

  it('should log error for unexpected errors', async () => {
    const mockRouter = createMockRouter('?command=start-conversation&prompt=Test');
    (URLExt.queryStringToObject as jest.Mock).mockImplementation(() => {
      throw new Error('Unexpected');
    });

    const result = await handleDeeplinkCommand(mockApp, mockRouter, mockLogger as any);

    expect(result).toBeUndefined();
    expect(showErrorMessage).toHaveBeenCalled();
    expect(mockLogger.error).toHaveBeenCalled();
  });
});

describe('ConversationDeeplinkingPlugin', () => {
  let ConversationDeeplinkingPlugin: typeof import('../DeeplinkingPlugin').ConversationDeeplinkingPlugin;

  beforeEach(() => {
    jest.clearAllMocks();
    jest.isolateModules(() => {
      // eslint-disable-next-line @typescript-eslint/no-var-requires
      const mod = require('../DeeplinkingPlugin');
      ConversationDeeplinkingPlugin = mod.ConversationDeeplinkingPlugin;
    });
  });

  it('should have correct plugin configuration', () => {
    expect(ConversationDeeplinkingPlugin.id).toBe(pluginIds.ConversationDeeplinkingPlugin);
    expect(ConversationDeeplinkingPlugin.autoStart).toBe(true);
  });

  it('should register command and router pattern on activation', async () => {
    const mockAddCommand = jest.fn();
    const mockRegister = jest.fn();

    const mockApp = {
      commands: { addCommand: mockAddCommand },
      restored: Promise.resolve(),
    } as any;

    const mockRouter = {
      register: mockRegister,
      current: { search: '', request: '', path: '' },
    } as unknown as IRouter;

    await ConversationDeeplinkingPlugin.activate(mockApp, mockRouter, mockLogger as any);

    expect(mockAddCommand).toHaveBeenCalledWith(COMMAND_ID, expect.objectContaining({ execute: expect.any(Function) }));
    expect(mockRegister).toHaveBeenCalledWith(
      expect.objectContaining({
        command: COMMAND_ID,
        pattern: expect.any(RegExp),
      }),
    );
  });
});
