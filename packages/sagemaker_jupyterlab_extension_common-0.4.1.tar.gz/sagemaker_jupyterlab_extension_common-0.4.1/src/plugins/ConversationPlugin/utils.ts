/**
 * Utility functions for conversation deeplink plugin
 * Includes input sanitization, validation, and template substitution
 */

import { ERROR_MESSAGES, VALIDATION_LIMITS, TEMPLATE_VAR_PATTERN } from './constants';

/**
 * Custom error class for validation failures
 */
export class ValidationError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'ValidationError';
  }
}

// Validation patterns
const HTML_TAG_PATTERN = /<[^>]+>/i;
const JS_PROTOCOL_PATTERN = /javascript:|data:|vbscript:/i;
const EVENT_HANDLER_PATTERN = /on\w+\s*=/i;

/**
 * Checks if text contains dangerous patterns (HTML tags, JS protocols, event handlers)
 * @param text - Text to check for dangerous patterns
 * @returns true if dangerous patterns are found, false otherwise
 */
export function containsDangerousPatterns(text: string): boolean {
  return HTML_TAG_PATTERN.test(text) || JS_PROTOCOL_PATTERN.test(text) || EVENT_HANDLER_PATTERN.test(text);
}

/**
 * Validates prompt parameter length
 * @param prompt - Prompt text to validate
 * @returns true if valid
 * @throws ValidationError if prompt exceeds maximum length
 */
export function validatePrompt(prompt: string): boolean {
  if (prompt.length > VALIDATION_LIMITS.PROMPT_MAX_LENGTH) {
    throw new ValidationError(ERROR_MESSAGES.PROMPT_TOO_LONG);
  }
  return true;
}

/**
 * Strips HTML tags from text
 * @param text - Text to strip HTML tags from
 * @returns Text with HTML tags removed
 */
export function stripHtmlTags(text: string): string {
  return text.replace(/<[^>]*>/gi, '');
}

/**
 * Sanitizes and validates a query parameter value.
 * Strips HTML tags from the input, then rejects if JS protocols or event handlers remain.
 * @param value - Raw query parameter value
 * @param paramName - Name of the parameter (for error messages)
 * @returns Sanitized value with HTML tags stripped
 * @throws ValidationError if value contains JS protocols or event handlers after stripping
 */
export function sanitizeQueryParam(value: string, paramName: string): string {
  // Strip HTML tags first
  const stripped = stripHtmlTags(value);

  // Reject if JS protocols or event handlers remain after stripping
  if (containsDangerousPatterns(stripped)) {
    throw new ValidationError(`${ERROR_MESSAGES.INVALID_INPUT} (parameter: ${paramName})`);
  }

  return stripped;
}

/**
 * Substitutes template variables in prompt with parameter values
 * Template variables are in the format {variable_name}
 * If no corresponding parameter exists, the template variable is left unchanged
 * @param prompt - Prompt text with template variables
 * @param params - Query parameters for substitution
 * @returns Prompt with variables substituted
 */
export function substituteTemplateVariables(prompt: string, params: Record<string, string>): string {
  return prompt.replace(TEMPLATE_VAR_PATTERN, (match, varName) => {
    // If parameter exists, return its value; otherwise keep the template variable
    return params[varName] !== undefined ? params[varName] : match;
  });
}
