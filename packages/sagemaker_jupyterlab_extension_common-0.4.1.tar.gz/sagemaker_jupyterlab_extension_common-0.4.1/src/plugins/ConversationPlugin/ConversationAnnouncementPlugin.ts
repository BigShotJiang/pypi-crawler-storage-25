import { JupyterFrontEnd, JupyterFrontEndPlugin } from '@jupyterlab/application';
import { Notification } from '@jupyterlab/apputils';
import { ServerConnection } from '@jupyterlab/services';
import { URLExt } from '@jupyterlab/coreutils';
import { getLoggerForPlugin, pluginIds } from '../../constants';
import { SAGEMAKER_AUTH_DETAILS_ENDPOINT } from '../../constants/fetchapi';
import { ILogger } from '../LoggerPlugin';
import { AppEnvironment, AuthDetailsOutput } from '../../types';
import { CHAT_SIDE_PANEL_ID, CHAT_COMMAND_ID } from './constants';
import { aiChatIcon } from '../../components/icons';

const STORAGE_KEY = 'notification_seen_conversation_announcement';
const API_TIMEOUT_MS = 5000;
const SM_STUDIO_ENVIRONMENTS = [AppEnvironment.SMStudio, AppEnvironment.SMStudioSSO];

/** Checks if the current environment is SageMaker Studio via the auth-details API. */
async function isSageMakerStudio(): Promise<boolean> {
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), API_TIMEOUT_MS);
  try {
    const settings = ServerConnection.makeSettings({});
    const url = URLExt.join(settings.baseUrl, SAGEMAKER_AUTH_DETAILS_ENDPOINT);
    const response = await ServerConnection.makeRequest(url, { method: 'POST', signal: controller.signal }, settings);
    clearTimeout(timeoutId);
    const details = (await response.json()) as AuthDetailsOutput;
    return SM_STUDIO_ENVIRONMENTS.includes(details.environment);
  } catch {
    clearTimeout(timeoutId);
    return false;
  }
}

/** Swaps the chat panel icon if the panel is found in the shell. */
function updateChatPanelIcon(app: JupyterFrontEnd, logger: ReturnType<typeof getLoggerForPlugin>) {
  const widgets = [...Array.from(app.shell.widgets('left')), ...Array.from(app.shell.widgets('right'))];
  const chatPanel = widgets.find((w) => w.id === CHAT_SIDE_PANEL_ID);
  if (chatPanel) {
    chatPanel.title.icon = aiChatIcon;
    logger.info({ Message: 'Chat panel icon updated' });
  }
}

/** Shows the AI chat announcement if the user hasn't dismissed it, chat is available, and we're in SM Studio. */
async function showAnnouncementIfNeeded(app: JupyterFrontEnd, logger: ReturnType<typeof getLoggerForPlugin>) {
  if (!app.commands.hasCommand(CHAT_COMMAND_ID)) {
    logger.debug({ Message: 'Chat plugin not available, skipping' });
    return;
  }

  if (!(await isSageMakerStudio())) {
    logger.debug({ Message: 'Not in SageMaker Studio environment, skipping' });
    return;
  }

  updateChatPanelIcon(app, logger);

  if (localStorage.getItem(STORAGE_KEY)) {
    logger.debug({ Message: 'Announcement already dismissed, skipping notification' });
    return;
  }

  localStorage.setItem(STORAGE_KEY, 'true');

  Notification.info(
    'Agentic assistants with SageMaker AI Skills preinstalled. Accelerate your ML workflows with Kiro or your own agent.',
    {
      autoClose: false,
      actions: [
        {
          label: 'Get Started',
          caption: 'Open AI chat panel',
          displayType: 'accent',
          callback: () => {
            logger.info({ Message: 'User clicked Get Started on AI chat announcement' });
            app.shell.activateById(CHAT_SIDE_PANEL_ID);
          },
        },
      ],
    },
  );

  logger.info({ Message: 'AI chat announcement notification displayed' });
}

/** One-time announcement plugin for AI chat availability in SageMaker Studio. */
const ConversationAnnouncementPlugin: JupyterFrontEndPlugin<void> = {
  id: pluginIds.ConversationAnnouncementPlugin,
  requires: [ILogger],
  autoStart: true,
  activate: (app: JupyterFrontEnd, baseLogger: ILogger) => {
    const logger = getLoggerForPlugin(baseLogger, pluginIds.ConversationAnnouncementPlugin);
    logger.info({ Message: 'ConversationAnnouncementPlugin activated' });

    app.restored
      .then(() => showAnnouncementIfNeeded(app, logger))
      .catch((error) => {
        logger.error({ Message: 'Error in ConversationAnnouncementPlugin', Error: error as Error });
      });
  },
};

export { ConversationAnnouncementPlugin };
