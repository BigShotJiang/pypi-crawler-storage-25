import platform
import sys
import logging
import os
import traceback
import pytest
from datetime import datetime
from unittest.mock import patch, mock_open

from sagemaker_jupyterlab_extension_common.constants import (
    SERVER_LOG_SCHEMA,
    HANDLER_METRICS_SCHEMA,
    LOGFILE_ENV_NAME,
    SERVER_LOG_FILE_NAME,
    API_LOG_FILE_NAME,
    JUPYTERLAB_PERFORMANCE_METRICS_LOG_SCHEMA,
    JUPYTERLAB_METRICS_LOG_FILE_NAME,
)
from sagemaker_jupyterlab_extension_common.logging.logging_utils import (
    get_operational_logger,
    get_eventlog,
    OperationalLoggingHandler,
    register_operational_handler_on_event_logger,
    ACPEventFilter,
    create_ui_eventlogger,
    SchemaDocument,
    HandlerLogMixin,
)

from .utils import (
    get_last_entry,
)


# TODO: debug the issue, succeeds in dryrun build
@pytest.mark.skipif(platform.system() == "Darwin", reason="Test skipped on macOS")
@patch("sagemaker_jupyterlab_extension_common.logging.logging_utils.get_domain_id")
@patch("sagemaker_jupyterlab_extension_common.logging.logging_utils.get_aws_account_id")
@patch("sagemaker_jupyterlab_extension_common.logging.logging_utils.get_space_name")
def test_operational_logger_valid_event_success(
    mock_space,
    mock_aws_account,
    mock_domain,
):
    mock_space.return_value = "default-space"
    mock_domain.return_value = "d-jk12345678"
    mock_aws_account.return_value = "1234567890"

    # create logger oject
    obj = object()
    logger = get_operational_logger(
        obj, eventlog=get_eventlog(), extension_name="TestEXT", extension_version="1.0"
    )
    logger.setLevel(logging.INFO)
    additional_data = {"Component": "MyTestComponent"}
    # Additional non required attributes can be set by passing dictionary to extra attribute in log.
    logger.info("test_logger", extra=additional_data)

    # read the log file
    data = get_last_entry(SERVER_LOG_FILE_NAME)

    assert data["__schema__"] == SERVER_LOG_SCHEMA
    assert data["Level"] == "INFO"
    assert data["Message"] == "test_logger"
    assert data["Context"]["ExtensionName"] == "TestEXT"
    assert data["Context"]["ExtensionVersion"] == "1.0"
    assert data["Context"]["SpaceName"] == "default-space"
    assert data["Context"]["AccountId"] == "1234567890"
    assert data["Context"]["DomainId"] == "d-jk12345678"
    assert data["Context"]["Component"] == "MyTestComponent"

    # Should add OperationLogging handler once only
    logger = get_operational_logger(obj, eventlog=get_eventlog())
    handlerCount = len(
        list(
            filter(lambda x: isinstance(x, OperationalLoggingHandler), logger.handlers)
        )
    )
    assert handlerCount == 1


# ---------------------------------------------------------------------------
#  TestMixin and Logging
#  Note:** This test case is still failing and we are investingating. To unblock for the
#  pen-test we are disabling the test, will continue debugging.
# ---------------------------------------------------------------------------


class TestExtensionLogMixin(HandlerLogMixin):
    jl_extension_name = "test_ext_name"
    jl_extension_version = "1.0"


@patch("sagemaker_jupyterlab_extension_common.logging.logging_utils.get_domain_id")
@patch("sagemaker_jupyterlab_extension_common.logging.logging_utils.get_aws_account_id")
@patch("sagemaker_jupyterlab_extension_common.logging.logging_utils.get_space_name")
def _test_logging_mixin(
    mock_space,
    mock_aws_account,
    mock_domain,
):
    mock_space.return_value = "default-space"
    mock_domain.return_value = "d-jk12345678"
    mock_aws_account.return_value = "1234567890"

    logger = TestExtensionLogMixin()
    logger.log.error("MyTestErrorLog")

    data = get_last_entry(SERVER_LOG_FILE_NAME)
    assert data["__schema__"] == SERVER_LOG_SCHEMA
    assert data["Level"] == "ERROR"
    assert data["Message"] == "MyTestErrorLog"
    assert data["Context"]["ExtensionName"] == "test_ext_name"
    assert data["Context"]["ExtensionVersion"] == "1.0"
    assert data["Context"]["SpaceName"] == "default-space"
    assert data["Context"]["AccountId"] == "1234567890"
    assert data["Context"]["DomainId"] == "d-jk12345678"


@patch("sagemaker_jupyterlab_extension_common.logging.logging_utils.get_domain_id")
@patch("sagemaker_jupyterlab_extension_common.logging.logging_utils.get_aws_account_id")
@patch("sagemaker_jupyterlab_extension_common.logging.logging_utils.get_space_name")
@patch("sagemaker_jupyterlab_extension_common.logging.logging_utils._get_event_capsule")
def test_operational_logger_invalid_event_failure(
    mock_event_data,
    mock_space,
    mock_aws_account,
    mock_domain,
):
    mock_space.return_value = "default-space"
    mock_domain.return_value = "d-jk12345678"
    mock_aws_account.return_value = "1234567890"
    mock_event_data.return_value = dict(Context={})

    obj = object()
    logger = get_operational_logger(obj, eventlog=get_eventlog())
    logger.setLevel(logging.INFO)
    exception = None
    try:
        logger.info("This event is invalid")
    except Exception as ex:
        exception = ex

    assert exception.__class__.__name__ == "ValidationError"


# ---------------------------------------------------------------------------
#  MetricWriter testing
# ---------------------------------------------------------------------------


class NewExtensionLogMixin(HandlerLogMixin):
    jl_extension_name = "new_extension"
    jl_extension_version = "2.0"


# TODO: debug the issue, succeeds in dryrun build
@pytest.mark.skipif(platform.system() == "Darwin", reason="Test skipped on macOS")
@patch("sagemaker_jupyterlab_extension_common.logging.logging_utils.get_domain_id")
@patch("sagemaker_jupyterlab_extension_common.logging.logging_utils.get_aws_account_id")
@patch("sagemaker_jupyterlab_extension_common.logging.logging_utils.get_space_name")
def test_metric_logger(
    mock_space,
    mock_aws_account,
    mock_domain,
):
    mock_space.return_value = "default-space"
    mock_domain.return_value = "d-jk12345678"
    mock_aws_account.return_value = "1234567890"

    error_context = {
        "MetricName": "Error",
        "MetricValue": 1,
        "MetricUnit": "Count",
        "Dimensions": [
            {
                "Operation": "DescribeCluster",
            },
        ],
    }

    metricWriter = TestExtensionLogMixin()

    # write error metric
    metricWriter.metric.put_error("DescribeCluster", **error_context)

    data = get_last_entry(API_LOG_FILE_NAME)
    assert data["__schema__"] == HANDLER_METRICS_SCHEMA
    assert data["Fault"] == 0
    assert data["Context"]["ExtensionName"] == "test_ext_name"
    assert data["Context"]["ExtensionVersion"] == "1.0"
    assert data["Context"]["SpaceName"] == "default-space"
    assert data["Context"]["AccountId"] == "1234567890"
    assert data["Context"]["DomainId"] == "d-jk12345678"
    assert data["Operation"] == "DescribeCluster"
    assert data["Error"] == 1
    assert data["_aws"]["Timestamp"] > 0
    timestamp = data["_aws"]["Timestamp"]
    assert data["_aws"] == {
        "Timestamp": timestamp,
        "CloudWatchMetrics": [
            {
                "Dimensions": [["Operation"]],
                "Metrics": [{"Name": "Error", "Unit": "Count"}],
                "Namespace": "JupyterServer",
            }
        ],
    }

    fault_context = {
        "MetricName": "Fault",
        "MetricValue": 1,
        "MetricUnit": "Count",
        "Dimensions": [
            {
                "Operation": "ListCLuster",
            },
        ],
    }

    # Write a fault metric
    metricWriter.metric.put_fault("ListCLuster", **fault_context)

    data = get_last_entry(API_LOG_FILE_NAME)
    assert data["__schema__"] == HANDLER_METRICS_SCHEMA
    assert data["Context"]["ExtensionName"] == "test_ext_name"
    assert data["Context"]["ExtensionVersion"] == "1.0"
    assert data["Context"]["SpaceName"] == "default-space"
    assert data["Context"]["AccountId"] == "1234567890"
    assert data["Context"]["DomainId"] == "d-jk12345678"
    assert data["Operation"] == "ListCLuster"
    assert data["Error"] == 0
    assert data["Fault"] == 1
    assert data["_aws"]["Timestamp"] > 0
    timestamp = data["_aws"]["Timestamp"]
    # to verify aws object, reading timestamp from record and assigning in object as value to Timestamp
    assert data["_aws"] == {
        "Timestamp": timestamp,
        "CloudWatchMetrics": [
            {
                "Dimensions": [["Operation"]],
                "Metrics": [{"Name": "Fault", "Unit": "Count"}],
                "Namespace": "JupyterServer",
            }
        ],
    }

    invalid_context = {
        "MetricName": "Transaction",
        "MetricValue": 1,
        "MetricUnit": "Count",
        "Dimensions": [
            {
                "Operation": "CreatePersistentUI",
            },
        ],
    }

    # Invlaid metric name results into validation error
    metricWriter.metric.put_fault("CreatePersistentUI", **invalid_context)
    data = get_last_entry(API_LOG_FILE_NAME)

    # verify last operation is still fault
    assert data["Operation"] == "ListCLuster"
    assert data["Fault"] == 1

    """"Test Metric logging for Additional extension"""

    metricWriter2 = NewExtensionLogMixin()

    fault_context_new = {
        "MetricName": "Fault",
        "MetricValue": 1,
        "MetricUnit": "Count",
        "Dimensions": [
            {
                "Operation": "DescribePersistentUI",
            },
        ],
    }

    metricWriter2.metric.put_fault("DescribePersistentUI", **fault_context_new)
    data = get_last_entry(API_LOG_FILE_NAME)

    # verify last operation is still fault
    assert data["Operation"] == "DescribePersistentUI"
    assert data["Fault"] == 1


# TODO: debug the issue, succeeds in dryrun build
@pytest.mark.skipif(platform.system() == "Darwin", reason="Test skipped on macOS")
@patch("sagemaker_jupyterlab_extension_common.logging.logging_utils.get_domain_id")
@patch("sagemaker_jupyterlab_extension_common.logging.logging_utils.get_aws_account_id")
@patch("sagemaker_jupyterlab_extension_common.logging.logging_utils.get_space_name")
def test_ui_event_logger_valid_event_success(
    mock_space,
    mock_aws_account,
    mock_domain,
):
    mock_space.return_value = "default-space"
    mock_domain.return_value = "d-jk12345678"
    mock_aws_account.return_value = "1234567890"

    # ---------------------------------------------------------------------------
    # Test logging the performance metrics
    # ---------------------------------------------------------------------------

    # create logger oject
    logger = create_ui_eventlogger(
        [
            SchemaDocument.JupyterLabPerformanceMetrics,
        ]
    )

    perf_metrics_event_data = {
        "Message": "Internal server error occurred",
        "Level": "INFO",
        "Context": {
            "SessionId": "someSessionId",
            "ExtensionName": "UIExtension",
            "ExtensionVersion": "1.0",
        },
    }

    logger.emit(
        schema_id=JUPYTERLAB_PERFORMANCE_METRICS_LOG_SCHEMA,
        data=perf_metrics_event_data,
        timestamp_override=datetime.utcnow(),
    )

    data = get_last_entry(JUPYTERLAB_METRICS_LOG_FILE_NAME)

    assert data["__schema__"] == JUPYTERLAB_PERFORMANCE_METRICS_LOG_SCHEMA
    assert data["Level"] == "INFO"
    assert data["Message"] == "Internal server error occurred"
    assert data["Context"]["ExtensionName"] == "UIExtension"
    assert data["Context"]["ExtensionVersion"] == "1.0"


# ---------------------------------------------------------------------------
#  register_operational_handler_on_event_logger tests
# ---------------------------------------------------------------------------


class TestRegisterOperationalHandlerOnEventLogger:
    """Tests for register_operational_handler_on_event_logger."""

    def test_registers_handler_on_event_logger(self):
        """Verify a file handler is registered on the event logger."""
        event_logger = get_eventlog()
        initial_handler_count = len(event_logger.handlers)

        register_operational_handler_on_event_logger(event_logger)

        assert len(event_logger.handlers) == initial_handler_count + 1

    def test_handler_has_acp_event_filter(self):
        """Verify the registered handler has an ACPEventFilter attached."""
        event_logger = get_eventlog()

        register_operational_handler_on_event_logger(event_logger)

        # The last registered handler should have the ACPEventFilter
        last_handler = event_logger.handlers[-1]
        acp_filters = [f for f in last_handler.filters if isinstance(f, ACPEventFilter)]
        assert len(acp_filters) == 1

    def test_registers_operational_schema(self):
        """Verify the Operational schema is registered on the event logger."""
        event_logger = get_eventlog()

        register_operational_handler_on_event_logger(event_logger)

        # Schema should be registered — registering again should raise
        schema_path = SchemaDocument.Operational.get_schema_file_path()
        from jupyter_events.schema_registry import SchemaRegistryException

        with pytest.raises(SchemaRegistryException):
            event_logger.register_event_schema(schema_path)

    def test_schema_already_registered_does_not_raise(self):
        """If schema is already registered, the function should not raise."""
        event_logger = get_eventlog()

        # Register once
        register_operational_handler_on_event_logger(event_logger)

        # Register again — should not raise
        register_operational_handler_on_event_logger(event_logger)

    def test_schema_already_registered_logs_debug(self):
        """When schema is already registered, a debug message should be logged."""
        event_logger = get_eventlog()

        # Register once to populate the schema
        register_operational_handler_on_event_logger(event_logger)

        # Register again and verify debug log
        with patch(
            "sagemaker_jupyterlab_extension_common.logging.logging_utils.logging"
        ) as mock_logging:
            mock_logger = mock_logging.getLogger.return_value
            register_operational_handler_on_event_logger(event_logger)
            mock_logger.debug.assert_called_once()
            args = mock_logger.debug.call_args[0]
            assert "Event schema registration skipped" in args[0]


# ---------------------------------------------------------------------------
#  ACPEventFilter tests
# ---------------------------------------------------------------------------


class TestACPEventFilter:
    """Tests for the ACPEventFilter logging filter."""

    def setup_method(self):
        self.filter = ACPEventFilter()

    def test_allows_acp_telemetry_event(self):
        """Events with the ACP schema ID should pass the filter."""
        record = logging.LogRecord(
            name="test",
            level=logging.INFO,
            pathname="",
            lineno=0,
            msg={"__schema__": ACPEventFilter.ACP_SCHEMA_ID},
            args=None,
            exc_info=None,
        )
        assert self.filter.filter(record) is True

    def test_rejects_non_acp_event(self):
        """Events with a different schema ID should be rejected."""
        record = logging.LogRecord(
            name="test",
            level=logging.INFO,
            pathname="",
            lineno=0,
            msg={"__schema__": "http://some.other.schema"},
            args=None,
            exc_info=None,
        )
        assert self.filter.filter(record) is False

    def test_rejects_event_without_schema(self):
        """Events without a __schema__ key should be rejected."""
        record = logging.LogRecord(
            name="test",
            level=logging.INFO,
            pathname="",
            lineno=0,
            msg={"Level": "INFO", "Message": "hello"},
            args=None,
            exc_info=None,
        )
        assert self.filter.filter(record) is False

    def test_rejects_string_message(self):
        """Plain string log messages should be rejected."""
        record = logging.LogRecord(
            name="test",
            level=logging.INFO,
            pathname="",
            lineno=0,
            msg="just a string",
            args=None,
            exc_info=None,
        )
        assert self.filter.filter(record) is False

    def test_rejects_none_message(self):
        """None message should be rejected."""
        record = logging.LogRecord(
            name="test",
            level=logging.INFO,
            pathname="",
            lineno=0,
            msg=None,
            args=None,
            exc_info=None,
        )
        assert self.filter.filter(record) is False
