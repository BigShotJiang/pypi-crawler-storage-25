"""Tests for PAL by Activity (Phase 1, Task 1.4)."""

from decimal import Decimal

import pytest

from src.computation.schedule_e import PALResult, compute_pal_by_activity, compute_pal_allowance


class TestPALByActivity:
    """Test per-activity PAL computation."""

    def test_single_loss_activity_under_allowance(self):
        """Single activity with loss under $25K allowance → fully allowed."""
        results = compute_pal_by_activity(
            activities=[{"activity_id": "rental_1", "net_income": Decimal("-15000")}],
            magi=Decimal("80000"),
            filing_status="married_filing_jointly",
        )
        assert len(results) == 1
        r = results[0]
        assert r.activity_id == "rental_1"
        assert r.allowed_loss == Decimal("-15000")
        assert r.suspended_loss == Decimal("0")

    def test_single_loss_activity_over_allowance(self):
        """Single activity with loss over $25K allowance → partial suspension."""
        results = compute_pal_by_activity(
            activities=[{"activity_id": "rental_1", "net_income": Decimal("-40000")}],
            magi=Decimal("80000"),
            filing_status="married_filing_jointly",
        )
        r = results[0]
        assert r.allowed_loss == Decimal("-25000")
        assert r.suspended_loss == Decimal("-15000")

    def test_two_loss_activities_pro_rata(self):
        """Two loss activities share the $25K allowance pro-rata."""
        results = compute_pal_by_activity(
            activities=[
                {"activity_id": "rental_1", "net_income": Decimal("-20000")},
                {"activity_id": "rental_2", "net_income": Decimal("-30000")},
            ],
            magi=Decimal("80000"),
            filing_status="married_filing_jointly",
        )
        by_id = {r.activity_id: r for r in results}
        # Total loss = 50000, allowance = 25000
        # rental_1 share: 20000/50000 * 25000 = 10000
        # rental_2 share: 30000/50000 * 25000 = 15000
        assert by_id["rental_1"].allowed_loss == Decimal("-10000")
        assert by_id["rental_1"].suspended_loss == Decimal("-10000")
        assert by_id["rental_2"].allowed_loss == Decimal("-15000")
        assert by_id["rental_2"].suspended_loss == Decimal("-15000")

    def test_disposition_releases_all_suspended(self):
        """IRC §469(g): Disposition releases all prior suspended losses."""
        results = compute_pal_by_activity(
            activities=[
                {"activity_id": "rental_1", "net_income": Decimal("-5000")},
            ],
            magi=Decimal("80000"),
            filing_status="married_filing_jointly",
            prior_suspended={"rental_1": Decimal("-30000")},
            disposed_activities={"rental_1"},
        )
        r = results[0]
        # On disposition, everything is released: -5000 + (-30000) = -35000
        assert r.gross_income == Decimal("-35000")
        assert r.suspended_loss == Decimal("0")

    def test_prior_suspended_combined_with_current(self):
        """Prior suspended losses combine with current year income."""
        results = compute_pal_by_activity(
            activities=[{"activity_id": "rental_1", "net_income": Decimal("10000")}],
            magi=Decimal("80000"),
            filing_status="married_filing_jointly",
            prior_suspended={"rental_1": Decimal("-8000")},
        )
        r = results[0]
        # Combined: 10000 + (-8000) = 2000 (net positive)
        assert r.gross_income == Decimal("2000")
        assert r.suspended_loss == Decimal("0")

    def test_prior_suspended_still_negative(self):
        """Prior suspended + current still negative → partially allowed."""
        results = compute_pal_by_activity(
            activities=[{"activity_id": "rental_1", "net_income": Decimal("5000")}],
            magi=Decimal("80000"),
            filing_status="married_filing_jointly",
            prior_suspended={"rental_1": Decimal("-20000")},
        )
        r = results[0]
        # Combined: 5000 + (-20000) = -15000
        # Allowance = 25000, fully covers -15000
        assert r.allowed_loss == Decimal("-15000")
        assert r.suspended_loss == Decimal("0")

    def test_mfs_zero_allowance(self):
        """MFS gets $0 allowance — all losses suspended."""
        results = compute_pal_by_activity(
            activities=[{"activity_id": "rental_1", "net_income": Decimal("-10000")}],
            magi=Decimal("80000"),
            filing_status="married_filing_separately",
        )
        r = results[0]
        assert r.allowed_loss == Decimal("0")
        assert r.suspended_loss == Decimal("-10000")

    def test_high_magi_phaseout(self):
        """MAGI $130K → allowance = $25K - ($130K - $100K)*0.5 = $10K."""
        results = compute_pal_by_activity(
            activities=[{"activity_id": "rental_1", "net_income": Decimal("-20000")}],
            magi=Decimal("130000"),
            filing_status="married_filing_jointly",
        )
        r = results[0]
        assert r.allowed_loss == Decimal("-10000")
        assert r.suspended_loss == Decimal("-10000")

    def test_magi_above_150k_no_allowance(self):
        """MAGI >= $150K → $0 allowance."""
        results = compute_pal_by_activity(
            activities=[{"activity_id": "rental_1", "net_income": Decimal("-20000")}],
            magi=Decimal("200000"),
            filing_status="married_filing_jointly",
        )
        r = results[0]
        assert r.allowed_loss == Decimal("0")
        assert r.suspended_loss == Decimal("-20000")

    def test_mix_profit_and_loss_activities(self):
        """Profitable activity is unaffected; loss activity uses allowance."""
        results = compute_pal_by_activity(
            activities=[
                {"activity_id": "rental_1", "net_income": Decimal("5000")},
                {"activity_id": "rental_2", "net_income": Decimal("-15000")},
            ],
            magi=Decimal("80000"),
            filing_status="married_filing_jointly",
        )
        by_id = {r.activity_id: r for r in results}
        assert by_id["rental_1"].gross_income == Decimal("5000")
        assert by_id["rental_1"].suspended_loss == Decimal("0")
        assert by_id["rental_2"].allowed_loss == Decimal("-15000")
        assert by_id["rental_2"].suspended_loss == Decimal("0")
