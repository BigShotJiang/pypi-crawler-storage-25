"""Tests for Excess FICA Refund (Phase 1, Task 1.5)."""

from decimal import Decimal

import pytest

from src.computation.credits import compute_excess_fica_refund
from src.core.return_processor import ReturnProcessor
from src.core.tax_constants import get_constants


class TestExcessFICARefund:
    """Test excess Social Security tax refund from multiple W-2s."""

    def test_single_w2_no_excess(self):
        """Single W-2 under wage base → no refund."""
        tc = get_constants(2024)
        result = compute_excess_fica_refund(
            ss_taxes_withheld=[Decimal("8000")],
            tc=tc,
        )
        # Max SS tax 2024: 168600 * 0.062 = 10453.20
        assert result == Decimal("0")

    def test_single_w2_at_max(self):
        """Single W-2 at exact max → no refund."""
        tc = get_constants(2024)
        max_ss = Decimal("168600") * Decimal("0.062")
        result = compute_excess_fica_refund(
            ss_taxes_withheld=[max_ss],
            tc=tc,
        )
        assert result == Decimal("0")

    def test_two_w2s_excess(self):
        """Two W-2s both withholding full SS tax → excess refunded."""
        tc = get_constants(2024)
        max_ss = Decimal("168600") * Decimal("0.062")  # 10453.20
        result = compute_excess_fica_refund(
            ss_taxes_withheld=[max_ss, max_ss],
            tc=tc,
        )
        assert result == max_ss  # Double max - single max = single max

    def test_partial_excess(self):
        """Two W-2s with partial overlap → partial refund."""
        tc = get_constants(2024)
        max_ss = Decimal("168600") * Decimal("0.062")  # 10453.20
        result = compute_excess_fica_refund(
            ss_taxes_withheld=[Decimal("8000"), Decimal("8000")],
            tc=tc,
        )
        # Total: 16000, max: 10453.20, excess: 5546.80
        assert result == Decimal("16000") - max_ss

    def test_empty_list(self):
        """No W-2s → no refund."""
        tc = get_constants(2024)
        result = compute_excess_fica_refund(
            ss_taxes_withheld=[],
            tc=tc,
        )
        assert result == Decimal("0")

    def test_2025_wage_base(self):
        """2025 has higher wage base ($176,100)."""
        tc = get_constants(2025)
        max_ss_2025 = Decimal("176100") * Decimal("0.062")  # 10918.20
        result = compute_excess_fica_refund(
            ss_taxes_withheld=[max_ss_2025, max_ss_2025],
            tc=tc,
        )
        assert result == max_ss_2025


class TestExcessFICAWiredIntoCalculate:
    """Test that excess FICA flows through ReturnProcessor.calculate()."""

    def test_excess_fica_increases_payments(self):
        """Excess FICA is added to total_payments as a refundable credit."""
        proc = ReturnProcessor(tax_year=2024)
        proc.set_filing_status("married_filing_jointly")
        # Two W-2s with full SS withholding
        max_ss = Decimal("168600") * Decimal("0.062")  # 10453.20
        # Primary has 2 W-2s, each at max SS → excess for primary
        proc.add_w2(
            wages=Decimal("170000"), federal_withheld=Decimal("30000"),
            ss_wages=Decimal("168600"), ss_tax=max_ss,
            medicare_wages=Decimal("170000"),
        )
        proc.add_w2(
            wages=Decimal("50000"), federal_withheld=Decimal("5000"),
            ss_wages=Decimal("50000"), ss_tax=Decimal("3100"),
            medicare_wages=Decimal("50000"),
        )
        result = proc.calculate()
        # Primary: 10,453.20 + 3,100 = 13,553.20, max = 10,453.20, excess = 3,100
        assert result.excess_fica_refund == Decimal("3100")
        assert result.total_payments == Decimal("35000") + Decimal("3100")

    def test_no_excess_fica_single_w2(self):
        """Single W-2 at normal wages → no excess FICA."""
        proc = ReturnProcessor(tax_year=2024)
        proc.set_filing_status("single")
        proc.add_w2(
            wages=Decimal("100000"), federal_withheld=Decimal("15000"),
            ss_wages=Decimal("100000"), ss_tax=Decimal("6200"),
            medicare_wages=Decimal("100000"),
        )
        result = proc.calculate()
        assert result.excess_fica_refund == Decimal("0")
