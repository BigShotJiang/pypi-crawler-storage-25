from decimal import Decimal
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

from computation.federal_tax import compute_bracket_tax, get_rounded_taxable_income
from computation.schedule_d import calculate_ltcg_tax
from core.return_processor import ReturnProcessor
from src.models.prior_year import PriorYearData


def test_schedule_e_uses_per_property_depreciation():
    processor = ReturnProcessor(tax_year=2025)
    processor.set_filing_status("married_filing_jointly")
    processor.add_w2(wages=Decimal("100000"), medicare_wages=Decimal("100000"))
    processor.set_rental_income(Decimal("999999"))
    processor.add_schedule_e(
        address="123 Main St",
        rental_income=Decimal("24000"),
        mortgage_interest=Decimal("8000"),
        taxes=Decimal("4000"),
        insurance=Decimal("1500"),
        repairs=Decimal("500"),
        utilities=Decimal("500"),
        depreciation=Decimal("10000"),
        hoa=Decimal("1000"),
    )

    result = processor.calculate()

    assert result.rental_income == Decimal("-1500")
    assert result.schedule_e_properties[0]["depreciation"] == Decimal("10000")
    assert result.schedule_e_properties[0]["net_income"] == Decimal("-1500")


def test_ltcg_and_qualified_dividends_use_preferential_rates():
    processor = ReturnProcessor(tax_year=2025)
    processor.set_filing_status("married_filing_jointly")
    processor.add_w2(wages=Decimal("100000"), medicare_wages=Decimal("100000"))
    processor.add_1099_div(ordinary=Decimal("10000"), qualified=Decimal("10000"))
    processor.set_capital_gains(short_term=Decimal("0"), long_term=Decimal("50000"))

    result = processor.calculate()
    brackets = processor._get_brackets(result.filing_status)
    preferential_income = Decimal("60000")
    ordinary_taxable = result.taxable_income - preferential_income
    expected = compute_bracket_tax(
        get_rounded_taxable_income(ordinary_taxable),
        brackets,
    ) + calculate_ltcg_tax(result.taxable_income, preferential_income, is_mfj=True)

    assert result.tax_from_brackets == expected
    assert result.tax_from_brackets < compute_bracket_tax(
        get_rounded_taxable_income(result.taxable_income),
        brackets,
    )


def test_massachusetts_tax_separates_short_term_gains_and_schedule_b_exemption():
    processor = ReturnProcessor(tax_year=2025)
    processor.set_filing_status("married_filing_jointly")
    processor.add_w2(wages=Decimal("50000"), medicare_wages=Decimal("50000"))
    processor.add_1099_int(interest=Decimal("300"))
    processor.add_1099_div(ordinary=Decimal("100"))
    processor.set_capital_gains(short_term=Decimal("10000"), long_term=Decimal("0"))

    result = processor.calculate()

    assert result.state_taxable_income == Decimal("51400")
    assert result.state_tax == Decimal("3270")


def test_salt_cap_phases_down_to_ten_thousand_for_high_agi():
    processor = ReturnProcessor(tax_year=2025)
    processor.set_filing_status("married_filing_jointly")
    processor.add_w2(wages=Decimal("600000"), medicare_wages=Decimal("600000"))
    processor.set_itemized_deductions(
        state_tax=Decimal("50000"),
        property_tax=Decimal("20000"),
    )

    result = processor.calculate()

    assert result.itemized_deduction == Decimal("10000")


def test_multiple_primary_mortgages_are_prorated_individually():
    processor = ReturnProcessor(tax_year=2025)
    processor.set_filing_status("married_filing_jointly")
    processor.add_w2(wages=Decimal("300000"), medicare_wages=Decimal("300000"))
    processor.set_itemized_deductions()
    processor.add_mortgage(
        loan_id="loan-1",
        interest_amount=Decimal("20000"),
        outstanding_balance=Decimal("1000000"),
        origination_date="2020-01-01",
        is_primary_residence=True,
        property_address="1 Home St",
    )
    processor.add_mortgage(
        loan_id="loan-2",
        interest_amount=Decimal("10000"),
        outstanding_balance=Decimal("500000"),
        origination_date="2016-01-01",
        is_primary_residence=True,
        property_address="1 Home St",
    )
    processor.add_mortgage(
        loan_id="loan-3",
        interest_amount=Decimal("12000"),
        outstanding_balance=Decimal("800000"),
        origination_date="2021-01-01",
        is_primary_residence=False,
        property_address="2 Rental Ave",
    )

    result = processor.calculate()

    # IRC §163(h)(3): $750K limit is AGGREGATE across all primary mortgages
    # Primary: $1M + $500K = $1.5M balance, $750K limit → ratio 0.5 → $15,000
    # Non-primary: $800K, post-TCJA $750K limit → ratio 750/800 → $11,250
    # Total: $26,250
    assert result.itemized_deduction == Decimal("26250")


def test_disposed_activity_releases_suspended_losses_into_taxable_income():
    processor = ReturnProcessor(tax_year=2024)
    processor.set_filing_status("married_filing_jointly")
    processor.add_w2(wages=Decimal("200000"), medicare_wages=Decimal("200000"))
    processor.add_schedule_e(
        address="1 Sold Rental Way",
        activity_id="sold_rental",
        disposed=True,
        rental_income=Decimal("5000"),
        repairs=Decimal("10000"),
    )

    baseline = processor.calculate()

    processor_with_prior = ReturnProcessor(tax_year=2024)
    processor_with_prior.set_filing_status("married_filing_jointly")
    processor_with_prior.add_w2(
        wages=Decimal("200000"),
        medicare_wages=Decimal("200000"),
    )
    processor_with_prior.add_schedule_e(
        address="1 Sold Rental Way",
        activity_id="sold_rental",
        disposed=True,
        rental_income=Decimal("5000"),
        repairs=Decimal("10000"),
    )
    processor_with_prior.set_prior_year_data(
        PriorYearData(
            tax_year=2023,
            suspended_passive_losses={"sold_rental": Decimal("-30000")},
        )
    )

    result = processor_with_prior.calculate()

    assert baseline.rental_income == Decimal("-5000")
    assert result.rental_income == Decimal("-35000")
    assert result.suspended_passive_losses_next == {}
    assert result.taxable_income == baseline.taxable_income - Decimal("30000")
    assert result.total_tax < baseline.total_tax


def test_multi_property_pal_changes_tax_vs_aggregate_rental_treatment():
    per_activity = ReturnProcessor(tax_year=2024)
    per_activity.set_filing_status("married_filing_jointly")
    per_activity.add_w2(wages=Decimal("200000"), medicare_wages=Decimal("200000"))
    per_activity.add_schedule_e(
        address="10 Cash Flow Ave",
        activity_id="profit_rental",
        rental_income=Decimal("35000"),
        mortgage_interest=Decimal("10000"),
        taxes=Decimal("5000"),
    )
    per_activity.add_schedule_e(
        address="20 Rehab Rd",
        activity_id="loss_rental",
        rental_income=Decimal("10000"),
        repairs=Decimal("20000"),
    )
    per_activity.set_prior_year_data(
        PriorYearData(
            tax_year=2023,
            suspended_passive_losses={"loss_rental": Decimal("-30000")},
        )
    )

    aggregate = ReturnProcessor(tax_year=2024)
    aggregate.set_filing_status("married_filing_jointly")
    aggregate.add_w2(wages=Decimal("200000"), medicare_wages=Decimal("200000"))
    aggregate.set_rental_income(Decimal("10000"))
    aggregate.set_prior_year_data(
        PriorYearData(
            tax_year=2023,
            suspended_passive_losses={"loss_rental": Decimal("-30000")},
        )
    )

    per_activity_result = per_activity.calculate()
    aggregate_result = aggregate.calculate()

    assert per_activity_result.rental_income == Decimal("20000")
    assert per_activity_result.suspended_passive_losses_next == {
        "loss_rental": Decimal("-40000")
    }
    assert per_activity_result.taxable_income == aggregate_result.taxable_income + Decimal("10000")
    assert per_activity_result.total_tax > aggregate_result.total_tax
