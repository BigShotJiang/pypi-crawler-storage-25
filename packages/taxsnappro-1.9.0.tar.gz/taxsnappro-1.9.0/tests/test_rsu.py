"""Tests for RSU/ESPP basis warning and correction."""

from decimal import Decimal

import pytest

from src.computation.rsu import (
    apply_basis_correction,
    detect_rsu_basis_issues,
    generate_rsu_annotations,
)
from src.models.documents import Form1099B


def _make_1099b(
    proceeds: Decimal,
    cost_basis: Decimal = Decimal("0"),
    basis_reported: bool = True,
    description: str = "GOOG",
    is_short_term: bool = False,
    wash_sale_loss: Decimal = Decimal("0"),
) -> Form1099B:
    return Form1099B(
        broker_name="Schwab",
        description=description,
        proceeds=proceeds,
        cost_basis=cost_basis,
        basis_reported_to_irs=basis_reported,
        is_short_term=is_short_term,
        wash_sale_loss=wash_sale_loss,
    )


class TestDetectRSUBasisIssues:
    def test_zero_basis_not_reported_flagged(self):
        txns = [_make_1099b(Decimal("50000"), Decimal("0"), basis_reported=False)]
        issues = detect_rsu_basis_issues(txns)
        assert len(issues) == 1
        assert issues[0].estimated_overstatement == Decimal("50000")
        assert issues[0].transaction_index == 0

    def test_small_basis_not_reported_flagged(self):
        """Basis < 10% of proceeds should be flagged."""
        txns = [_make_1099b(Decimal("50000"), Decimal("100"), basis_reported=False)]
        issues = detect_rsu_basis_issues(txns)
        assert len(issues) == 1
        assert issues[0].estimated_overstatement == Decimal("49900")

    def test_basis_reported_not_flagged(self):
        """Basis reported to IRS — not an RSU issue."""
        txns = [_make_1099b(Decimal("50000"), Decimal("0"), basis_reported=True)]
        issues = detect_rsu_basis_issues(txns)
        assert len(issues) == 0

    def test_reasonable_basis_not_flagged(self):
        """Basis > 10% of proceeds and not reported — could be legit."""
        txns = [_make_1099b(Decimal("50000"), Decimal("40000"), basis_reported=False)]
        issues = detect_rsu_basis_issues(txns)
        assert len(issues) == 0

    def test_multiple_transactions_mixed(self):
        """Mix of flagged and non-flagged transactions."""
        txns = [
            _make_1099b(Decimal("50000"), Decimal("0"), basis_reported=False, description="RSU-1"),
            _make_1099b(Decimal("30000"), Decimal("25000"), basis_reported=True, description="AAPL"),
            _make_1099b(Decimal("20000"), Decimal("500"), basis_reported=False, description="RSU-2"),
        ]
        issues = detect_rsu_basis_issues(txns)
        assert len(issues) == 2
        assert issues[0].description == "RSU-1"
        assert issues[1].description == "RSU-2"

    def test_zero_proceeds_not_flagged(self):
        """Zero proceeds — nothing to flag."""
        txns = [_make_1099b(Decimal("0"), Decimal("0"), basis_reported=False)]
        issues = detect_rsu_basis_issues(txns)
        assert len(issues) == 0

    def test_custom_threshold(self):
        """Custom threshold — 50% ratio."""
        txns = [_make_1099b(Decimal("50000"), Decimal("20000"), basis_reported=False)]
        # 20000/50000 = 0.40, which is < 0.50 threshold
        issues = detect_rsu_basis_issues(txns, basis_threshold_ratio=Decimal("0.50"))
        assert len(issues) == 1

    def test_short_term_flag_preserved(self):
        txns = [_make_1099b(Decimal("10000"), Decimal("0"), basis_reported=False, is_short_term=True)]
        issues = detect_rsu_basis_issues(txns)
        assert issues[0].is_short_term is True


class TestApplyBasisCorrection:
    def test_basic_correction(self):
        txn = _make_1099b(Decimal("50000"), Decimal("0"), basis_reported=False)
        corrected = apply_basis_correction(txn, Decimal("35000"))
        assert corrected.cost_basis == Decimal("35000")
        assert corrected.gain_loss == Decimal("15000")

    def test_correction_with_wash_sale(self):
        txn = _make_1099b(
            Decimal("50000"), Decimal("0"),
            basis_reported=False, wash_sale_loss=Decimal("2000"),
        )
        corrected = apply_basis_correction(txn, Decimal("35000"))
        assert corrected.gain_loss == Decimal("13000")  # 50000 - 35000 - 2000

    def test_negative_basis_raises(self):
        txn = _make_1099b(Decimal("50000"), Decimal("0"), basis_reported=False)
        with pytest.raises(ValueError, match="negative"):
            apply_basis_correction(txn, Decimal("-100"))

    def test_correction_preserves_metadata(self):
        txn = _make_1099b(Decimal("50000"), Decimal("0"), basis_reported=False, description="MSFT RSU")
        corrected = apply_basis_correction(txn, Decimal("40000"))
        assert corrected.broker_name == "Schwab"
        assert corrected.description == "MSFT RSU"
        assert corrected.basis_reported_to_irs is False


class TestGenerateAnnotations:
    def test_annotations_generated(self):
        txns = [_make_1099b(Decimal("50000"), Decimal("0"), basis_reported=False)]
        issues = detect_rsu_basis_issues(txns)
        annotations = generate_rsu_annotations(issues)
        assert len(annotations) == 1
        assert annotations[0].category == "rsu_basis_warning"
        assert annotations[0].severity == "important"
        assert annotations[0].action_required is True
        assert annotations[0].impact == Decimal("50000")

    def test_no_issues_no_annotations(self):
        annotations = generate_rsu_annotations([])
        assert len(annotations) == 0
